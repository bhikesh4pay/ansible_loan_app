<?php

function scrubdata($xml, $fields)
{
	$sxml = new SimpleXMLElement($xml);
	
	$ar = explode('|',$fields);
	
	foreach($ar as $field)
	{
		$sz = strlen($sxml->$field);
		if ($sz > 0)
			$sxml->$field = str_pad('',$sz,"1234567890");
	}
	
	return $sxml->asXML();
}

?>
