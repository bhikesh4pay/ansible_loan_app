<?php

require('../Lib/Array2XML.php');
require('../Lib/XML2Array.php');

    class Elavon
    {
        protected $location;
        protected $merchantid;
        protected $userid;
        protected $pin;
        protected $testmode;

        public function __construct($loc, $merchantid, $userid, $pin, $testmode)
        {
            $this->location = $loc;
            $this->merchantid = $merchantid;
            $this->userid = $userid;
            $this->pin = $pin;
            $this->testmode = $testmode;
        }

        public function request($transaction_type, $amount, $cc_expiry, $cc_number, $cardholder_name_first, $cardholder_name_last, $cvv, $reference_no)
        {
            $fields = array(
                    'ssl_merchant_id'=>$this->merchantid,
                    'ssl_user_id'=>$this->userid,
                    'ssl_pin'=>$this->pin,
                    'ssl_test_mode'=>$this->testmode,
                    'ssl_transaction_type'=>urlencode($transaction_type),
                    'ssl_card_number'=>urlencode($cc_number),
                    'ssl_exp_date'=>urlencode($cc_expiry),
                    'ssl_amount'=>urlencode($amount),
                    'ssl_first_name'=>$cardholder_name_first,
                    'ssl_last_name'=>$cardholder_name_last,
                    'ssl_cvv2cvc2'=>$cvv,
                    'ssl_invoice_number'=>$reference_no,
                    'ssl_cvv2cvc2_indicator' => 1
                );

            // Convert array into string
            $xml = Array2XML::createXML('txn', $fields);
            $xml->formatOutput = false;
            $tmpoutput = $xml->saveXML();	// saves data in string format

            $tmpoutput = str_replace('<?xml version="1.0" encoding="UTF-8"?>', "", $tmpoutput);
            $postData = "xmldata=".URLEncode($tmpoutput);

            $ch = curl_init();
            curl_setopt($ch, CURLOPT_URL, $this->location);
            curl_setopt($ch, CURLOPT_POST, 1);
            curl_setopt($ch, CURLOPT_POSTFIELDS, $postData);

            curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
            curl_setopt($ch, CURLOPT_VERBOSE, 0);
            curl_setopt($ch, CURLOPT_HEADER, 1);

            if (defined('IGNORE_SSL_4PAY')) {
                curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 0);
                curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0);
            }

            $result = curl_exec($ch);

            //extract result into a variable
            $header_size = curl_getinfo($ch, CURLINFO_HEADER_SIZE);
            $body = substr($result, $header_size);


            curl_close($ch);

            $array = XML2Array::createArray($body);
            return $array['txn'];
        }
    }
?>
