<?php

if (!function_exists ( 'hex2bin' ))
{
define('HEX2BIN_WS', " \t\n\r");
function hex2bin($hex_string) {
    $pos = 0;
    $result = '';
    while ($pos < strlen($hex_string)) {
      if (strpos(HEX2BIN_WS, $hex_string{$pos}) !== FALSE) {
        $pos++;
      } else {
        $code = hexdec(substr($hex_string, $pos, 2));
        $pos = $pos + 2;
        $result .= chr($code); 
      }
    }
    return $result;
}
}
?>