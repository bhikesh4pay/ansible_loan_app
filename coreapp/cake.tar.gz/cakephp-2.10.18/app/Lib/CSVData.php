<?php

class CSVData
{
    public $file;
    public $data;
    public $fp;
    public $caption=true;
    public function CSVData($file='')
    {
        if ($file!='') {
            getData($file);
        }
    }
    public function getData($file)
    {
        //echo $file;

        $this->fp=fopen($file, 'r');
        $this->readCSV();
        fclose($this->fp);
    }
    private function readCSV()
    {
        if ($this->caption==true) {
            if (($captions=fgetcsv($this->fp, 1000, ","))==false) {
                return false;
            }
        }
        $row=0;
        while (($data = fgetcsv($this->fp, 1000, ",")) !== false) {
            for ($c=0; $c < count($data); $c++) {
                $this->data[$row][$c]=$data[$c];
                if ($this->caption==true) {
                    $this->data[$row][$captions[$c]]=$data[$c];
                }
            }
            $row++;
        }
    }
}

