<?php
/**
 * This file is part of the Elephant.io package
 *
 * For the full copyright and license information, please view the LICENSE file
 * that was distributed with this source code.
 *
 * @copyright Wisembly
 * @license   http://www.opensource.org/licenses/MIT-License MIT License
 */

use ElephantIO\Client;
use ElephantIO\Engine\SocketIO\Version2X;

require __DIR__ . '/../../../../autoload.php';

$client = new Client(new Version2X('https://localhost:3000', ['token' => 'mysecretclienttoken']));

$client->initialize();
$client->emit('createMessage', ['name' => 'Shafik',
								'room' => '58EB46131AC4BC630811C38E962E4681445D05936B8F42801E5F70123B7B83CD',
								'text' => 'Hello from PHP',
								'passwd' => 'mysecretwritetoken']);
$client->close();
