<?php

App::import('model', 'Gateway');

//	require('/var/www/cloudabm.com/cakephp-4.x/app//src/Lib/randomGenerator.php');

    class ZOOM
    {
        protected $location;
        protected $partnerid;
        protected $networkid;
        protected $tmchk;

        public function __construct($gatewayid)
        {
            $this->gatewayid = $gatewayid;
            $this->location = '';
            $this->apikey = '';
        }

        public function request($senderproxy, $receiverproxy, $amount, $currcode, $comment, $logenabled, $logfile)
        {
            // current code is not used in this itteration. Everything is assumed to be in TZS. Validate and reject if that is not the case
            //echo 'I am here';
            //echo $this->gatewayid;

            $Gateway = new Gateway();
            $GatewaySearch = array('id'=>  $this->gatewayid);

            //print_r($GatewaySearch);

            $query = $Gateway->find('all', array('conditions' => $GatewaySearch));
            $query->disableHydration();
            $GatewayRec = $query->first();


            // print_r($GatewayRec);
            //echo '=============';

            if ($query->count() != 1) {
                return array('callStatus' => '0',
                            'error' => '10560-1',
                            'msg' => 'Can not find gateway details');
            } else {
                //------
                $x = array( 'senderproxy' => $senderproxy,
                             'receiverproxy' => $receiverproxy,
                             'amount' => $amount,
                             'comment' => $comment,
                             'apiKey' => $GatewayRec['field2value']);

                $y = json_encode($x);

                //print_r($y);

                $ch = curl_init();
                curl_setopt($ch, CURLOPT_URL, $GatewayRec['field1value'].'/acct-to-acct-transfer');
                curl_setopt($ch, CURLOPT_POST, true);
                curl_setopt($ch, CURLOPT_POSTFIELDS, $y);
                curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);

                curl_setopt($ch, CURLOPT_HTTPHEADER, array('Content-Type: application/json'));

                curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
                // curl_setopt($ch, CURLOPT_SSL_VERIFYHOST,  2);

                $response = curl_exec($ch);

                if (curl_errno($ch)) {
                    curl_close($ch);

                    return array('status' => '0',
                                 'errorNo' => '10560-2',
                                 'msg' => 'Lookup Service not available');
                } else {
                    $responsearry = json_decode($response, true);
                    //echo '-------------------------';
                    //print_r($responsearry);
                    //echo '=========================';

                    if (!isset($responsearry['SystemResponse']['responseCode']) || $responsearry['SystemResponse']['responseCode'] != 0 ||
                         isset($responsearry['FISResponse']['ErrorNumber'])) {
                        if (isset($responsearry['FISResponse']['ErrorNumber'])) {
                            $errmsg = $responsearry['FISResponse']['ErrorNumber'].' - '.$responsearry['FISResponse']['ErrorDescription'];
                        } else {
                            $errmsg = 'Could not find card details';
                        }


                        return array('status' => '0',
                                     'errorNo' => '10560-3',
                                     'msg' => $errmsg);
                    } else {
                        curl_close($ch);

                        //			print_r($responsearry);

                        return array('status' => '1',
                                     'txn_id' => $responsearry['FISResponse']['Retrievalrefno'],
                                     'amount' => $amount,
                                     'approval_code' => 'OK',
                                     'currID' => $currcode,
                                     'txn_time' => '1970-01-01 00:00:01',
                                     'result_message' => 'APPROVED');
                    }
                }

                //-------
            }
        }
    }
?>
