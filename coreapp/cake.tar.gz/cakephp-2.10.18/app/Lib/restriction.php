<?php

class restriction {

	function run($location, $restrictionid, $userid, $snodeid, $snodeurl, $langid, $otherdata)
	{

		$arr['location'] = $location ; 
		$arr['restrictionid'] = $restrictionid ; 
		$arr['userid'] = $userid ; 
		$arr['snodeid'] = $snodeid ; 
		$arr['snodeurl'] = $snodeurl ; 
		$arr['langid'] = $langid ; 
		$arr['otherdata'] = $otherdata ; 
	
		$this->restriction = $this->Components->load('_restriction'.$arr['restrictionid']);
		$rt = $this->restriction->run($arr);	
		return $rt;
	}


}