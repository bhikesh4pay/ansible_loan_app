<?php

require_once(__DIR__ . '/../autoload.php');

$MessageBird = new \MessageBird\Client('live_bGA8LE1PmZvBEh448zaTD5Rz8'); // Set your own API access key here.

$Message             = new \MessageBird\Objects\Message();
$Message->originator = 'mohamed';
$Message->recipients = array(14166489253);
$Message->body = 'This is a test message - Shafik.';


try {
    $MessageResult = $MessageBird->messages->create($Message);
    var_dump($MessageResult);

} catch (\MessageBird\Exceptions\AuthenticateException $e) {
    // That means that your accessKey is unknown
    var_dump($e);
    echo 'wrong login';

} catch (\MessageBird\Exceptions\BalanceException $e) {
    // That means that you are out of credits, so do something about it.
    echo 'no balance';

} catch (\Exception $e) {
    echo $e->getMessage();
}
