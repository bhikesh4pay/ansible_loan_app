<?php

namespace MessageBird\Exceptions;

/**
 * Class BalanceException
 *
 * @package MessageBird\Exceptions
 */
class BalanceException extends MessageBirdException
{

}
