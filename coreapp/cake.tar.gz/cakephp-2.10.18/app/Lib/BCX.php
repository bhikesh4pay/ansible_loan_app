<?php

//	require('../Lib/randomGenerator.php');

    class BCX
    {
        protected $location;
        protected $partnerid;
        protected $networkid;
        protected $tmchk;

        public function __construct($loc, $partnerid, $networkid)
        {
            $this->location = $loc;
            $this->partnerid = $partnerid;
            $this->networkid = $networkid;
        }

        public function request($binno, $customeraccountno, $refno, $merchantid, $merchantrefno, $phonenumber, $amount, $currcode, $logenabled, $logfile, $merchantname, $payee, $externalcode, $custacc)
        {

            //echo $this->location;

            //------------------
            $senddata = '<com.fp.agent.busobjects.MakePaymentRequest>
						 <networkId>'.$this->networkid.'</networkId>
						  <partnerId>'.$this->partnerid.'</partnerId>
						  <bin>'.$binno.'</bin>
						  <customerAccountNo>'.$customeraccountno.'</customerAccountNo>
						  <transRefNo>'.$refno.'</transRefNo>
						  <merchantName>'.$externalcode.'</merchantName>
						  <merchantTransRefNo>'.$merchantrefno.'</merchantTransRefNo>
						  <utilityRefNo>'.$custacc.'</utilityRefNo>
						  <amount>'.$amount.'</amount>
						  <phoneNumber>'.$phonenumber.'</phoneNumber>
						  <payee>'.$payee.'</payee>
						  <currencyCode>'.$this->convertToISO($currcode).'</currencyCode>
						  </com.fp.agent.busobjects.MakePaymentRequest>';

            //echo $senddata;
            if ($logenabled) {
                $logfile->append($this->tmchk . '<Sent to gateway>=>' .$senddata."\n");
            }

            $ch = curl_init();
            curl_setopt($ch, CURLOPT_URL, $this->location.'/makePayment.xml');
            curl_setopt($ch, CURLOPT_POST, true);
            curl_setopt($ch, CURLOPT_POSTFIELDS, $senddata);
            curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);

            curl_setopt($ch, CURLOPT_HTTPHEADER, array(
                        'Content-Type: text/xml',
                        'Content-Length: ' . strlen($senddata)));

            curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
            // curl_setopt($ch, CURLOPT_SSL_VERIFYHOST,  2);


            $response = curl_exec($ch);

            // print_r($response);

            if (curl_errno($ch)) {
                curl_close($ch);

                return array('status' => '0',
                             'error' => '10595-5',
                             'msg' => 'Lookup Service not available');
            } else {
                curl_close($ch);

                $xmlReply = Xml::build($response, array('return' => 'domdocument'));
                $xmlReplyArray = Xml::toArray($xmlReply);

                if ($logenabled) {
                    $logfile->append($this->tmchk . '<Output from gateway>=>' .print_r($xmlReplyArray, true)."\n");
                }


                $xmlReplyArray1 = $xmlReplyArray['com.fp.agent.busobjects.MakePaymentResponse'];
                //				print_r($xmlReplyArray1);
            }

            if (!isset($xmlReplyArray1['switchErrorDesc'])) {
                $xmlReplyArray1['switchErrorDesc'] = $xmlReplyArray1['switchErrorCode'];
            }

            if ($xmlReplyArray1['status'] != 1) {
                return array('status' => '0',
                             'error' => '10595-6'.'-'.$xmlReplyArray1['switchErrorCode'],
                             'msg' => 'Payment Failed - '.$xmlReplyArray1['switchErrorDesc']);
            } else {

    //			print_r($xmlReplyArray1);


                /*  				$xmlReplyArray1['specialMessage'] = '{"VAT 18%":"73.77","Meter":"43146820980","Owner":"TANESCO","Amount":"409.84","Curency":"TZS","REA 3%":"12.29","status":"Success","TrxStsCode":"7101","TrxSts":"GS","EWURA 1%":"4.10","RcptNum":"990061828619325605","Tax":"0.00","taxDetail":"VAT 18% TSH 73.77 EWURA 1% TSH 4.10 REA 3% TSH 12.29","Token":"36339812847388620927","TrxId":"EC100251534791","code":"200","Units":"1.5"}';
                 */
                $date = new DateTime();
                $date->setTimezone(new DateTimeZone('Africa/Dar_es_Salaam'));
                $date->format('Y-m-d H:i');

                if (!isset($xmlReplyArray1['specialMessage'])) {
                    $xmlReplyArray1['specialMessage'] = '';
                }


                return array('status' => '1',
                             'txn_id' => $xmlReplyArray1['confirmationNo'],
                             'amount' => $amount,
                             'approval_code' => 'OK',
                             'currID' => 'TZS',
                             'txn_time' => $date->format('Y-m-d H:i'), //'1970-01-01 00:00:01',
                             'result_message' => 'APPROVED',
                             'specialMessage' => $xmlReplyArray1['specialMessage'] );
            }
        }


        public function convertToISO($curr)
        {
            $cond['conditions'] = array( "currCode" => $curr);

            $Curr = new Curr();
            $query = $Curr->find('all', $cond);
            $query->disableHydration();
            $currRec = $query->first();


            if ($query->count() == 0) {
                return false;
            } else {

//				print_r($currRec);

                return $currRec['isonumeric'];
            }
        }
    }
?>
