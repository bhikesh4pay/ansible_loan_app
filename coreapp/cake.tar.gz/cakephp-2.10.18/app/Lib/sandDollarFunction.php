<?php

/**
* Generated token for headers
*/
function generateToken($deviceId, $authSecret, $iat, $exp) {
	$payload = new stdClass();
	$payload->deviceId = $deviceId;
	$payload->exp = $exp;
	$payload->iat = $iat;

	return JWT::encode($payload, $authSecret);
}

function decrypt($payload, $privateKey){
	$decryptedPayload = '';
    openssl_private_decrypt(base64_decode($payload), $decryptedPayload, $privateKey);
    return $decryptedPayload;
}

/**
   * Generated send transaction payload. Keys are ordered alphabetically
*/
function generatePayload($receiverDeviceNo, $amount, $sendAsCustomName, $uniqid) {
	$payload = new stdClass();
	$payload->paymentRequestId = $uniqid;
	$payload->receiverDeviceNo = $receiverDeviceNo;
	$payload->sendAmount = $amount;
	$payload->sendAsCustomName = $sendAsCustomName;

	return $payload;
}

function generateTransReceivePayload($pin, $otp, $sQRCode, $receiveAmount,$uniqid) {

	$payload = new stdClass();
	$payload->otp = $otp;
	$payload->pin = $pin;
	$payload->paymentRequestId = $uniqid;
	$payload->receiveAmount = $receiveAmount;
	$payload->sQRCode = $sQRCode;

	return $payload;
}

/**
   * Sign payload with SHA256 algorithm
*/
function sign($payload, $privateKey) {
	openssl_sign(json_encode($payload), $signature, $privateKey, OPENSSL_ALGO_SHA256);
	return base64_encode($signature);
}

function signTwo($payload, $privateKey) {
	openssl_sign(htmlspecialchars_decode(json_encode($payload, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES)), $signature, $privateKey, OPENSSL_ALGO_SHA256);
	return base64_encode($signature);
}





?>