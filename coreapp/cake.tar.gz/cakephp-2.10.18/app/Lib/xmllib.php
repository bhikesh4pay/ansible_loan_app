<?php

class xmllib 
{

	function libxml_display_error($error)
	{
		$return = "<br/>\n";
		switch ($error->level) {
		case LIBXML_ERR_WARNING:
			$return .= "<b>Warning $error->code</b>: ";
			break;
		case LIBXML_ERR_ERROR:
			$return .= "<b>Error $error->code</b>: ";
			break;
		case LIBXML_ERR_FATAL:
			$return .= "<b>Fatal Error $error->code</b>: ";
			break;
		}
		$return .= trim($error->message);
		if ($error->file) {
			$return .= " in <b>$error->file</b>";
		}
		$return .= " on line <b>$error->line</b>\n";
		return $return;
	}

	public function libxml_display_errors($errors) {
		$errArray = Array();
		foreach ($errors as $error) {
			array_push($errArray, $this->libxml_display_error($error));
		}
		libxml_clear_errors();
		return $errArray;
	}
}
?>