<?php

function addQuotes($str){
	return "'$str'";
}

?>