<?php


		$pagecount = $pdf->setSourceFile('../pdf/templates/nssfinvoicetemplate.pdf'); // template name
		$outputfilename = '../pdf/output/sample.pdf'; // output file name
		$tplidx = $pdf->importPage(1, '/MediaBox'); // Standard

		// Start populating data
		$pdf->addPage();
		$pdf->useTemplate($tplidx, 0, 0, 0,0,true);

		$pdf->SetFont('Arial'); 
		$pdf->SetFontSize(9); 
		$pdf->SetTextColor(0,0,0); 

		$pdf->SetXY(20, 95); 
		$pdf->Write(0, $varsarray[3].' '.$varsarray[4].' '.$varsarray[5]);  // First Name

		$lineno = 99;
		$pdf->SetXY(20, $lineno); 
		$pdf->Write(0, $varsarray[6]);  // Address Line 1
		$lineno = $lineno + 4;

		if (!empty($varsarray[7]))
		{
			$pdf->SetXY(20, $lineno); 
			$pdf->Write(0, $varsarray[7]);  // Address Line 2
			$lineno = $lineno + 4;
		}

		$pdf->SetXY(20, $lineno); 
		$pdf->Write(0, $varsarray[8].' '.$varsarray[9]);  // City and Province
		$lineno = $lineno + 4;

		$pdf->SetXY(20, $lineno); 
		$pdf->Write(0, $varsarray[10]);  // Country
		$lineno = $lineno + 4;

		$pdf->SetXY(20, $lineno); 
		$pdf->Write(0, $varsarray[11]);  // Postal Code
		$lineno = $lineno + 4;

		$pdf->SetXY(25, 178); 
		$pdf->Write(0, $varsarray[17]);  // Quantity

		$pdf->SetXY(56, 178); 
		$pdf->Write(0, urldecode($varsarray[18]));  // Desc

		$pdf->SetXY(125, 178); 
		$pdf->Cell(35, $h=0, $txt=$varsarray[16].' '.number_format($varsarray[19], 2, ".", ","), $border=0, $ln=0, $align='R', $fill=false, $link='');

		$pdf->SetXY(161, 178); 
		$pdf->Cell(35, $h=0, $txt=$varsarray[16].' '.number_format($varsarray[20], 2, ".", ","), $border=0, $ln=0, $align='R', $fill=false, $link='');


		$pdf->SetXY(161, 201); 
		$pdf->Cell(35, $h=0, $txt=number_format($varsarray[12], 2, ".", ","), $border=0, $ln=0, $align='R', $fill=false, $link='');

		$pdf->SetXY(161, 209); 
		$pdf->Cell(35, $h=0, $txt=number_format($varsarray[13], 2, ".", ","), $border=0, $ln=0, $align='R', $fill=false, $link='');

		$pdf->SetXY(161, 216); 
		$pdf->Cell(35, $h=0, $txt=$varsarray[16].' '.number_format($varsarray[14], 2, ".", ","), $border=0, $ln=0, $align='R', $fill=false, $link='');

		$pdf->SetXY(161, 223); 
		$pdf->Cell(35, $h=0, $txt=$varsarray[15], $border=0, $ln=0, $align='R', $fill=false, $link='');
		

		$pdf->SetTextColor(255,255,255); 

		$pdf->SetFontSize(11); 
		$pdf->SetXY(41, 74.5); 
		$pdf->Write(0, $varsarray[1]);  // Invoice Number
		
		$pdf->SetXY(158, 74.5); 
		$pdf->Cell(35, $h=0, $txt=$varsarray[2], $border=0, $ln=0, $align='R', $fill=false, $link='');

?>