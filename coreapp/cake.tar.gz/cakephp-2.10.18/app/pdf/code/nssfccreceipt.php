<?php


		$pagecount = $pdf->setSourceFile('../pdf/templates/nssfccreceipttemplate.pdf'); // template name
		$outputfilename = '../pdf/output/ccreceipt'.$randcode.'.pdf'; // output file name
		$tplidx = $pdf->importPage(1, '/MediaBox'); // Standard

		// Start populating data
		$pdf->addPage();
		$pdf->useTemplate($tplidx, 0, 0, 0,0,true);

		$pdf->SetFont('Arial'); 
		$pdf->SetFontSize(9); 
		$pdf->SetTextColor(0,0,0); 

		$pdf->SetXY(24.5, 50); 
		$pdf->Write(0, $varsarray[0]);  // Merchant Name

		$lineno = 54;
		$pdf->SetXY(24.5, $lineno); 
		$pdf->Write(0, $varsarray[1]);  // Address Line 1
		$lineno = $lineno + 4;

		if (!empty($varsarray[7]))
		{
			$pdf->SetXY(24.5, $lineno); 
			$pdf->Write(0, $varsarray[2]);  // Address Line 2
			$lineno = $lineno + 4;
		}

		$pdf->SetXY(24.5, $lineno); 
		$pdf->Write(0, $varsarray[3].' '.$varsarray[4]);  // City and Province
		$lineno = $lineno + 4;

		$pdf->SetXY(24.5, $lineno); 
		$pdf->Write(0, $varsarray[5]);  // Country
		$lineno = $lineno + 4;

		$pdf->SetXY(24.5, $lineno); 
		$pdf->Write(0, $varsarray[6]);  // Postal Code
		$lineno = $lineno + 4;

		$pdf->SetXY(24.5, 90); 
		
		$pdf->SetFontSize(8); 
		$pdf->MultiCell(0,5,$varsarray[8]); // Receipt

?>