<?php


		$pagecount = $pdf->setSourceFile('../pdf/templates/paiycc.pdf'); // template name
		$outputfilename = '../pdf/output/ccreceipt'.$randcode.'.pdf'; // output file name
		$tplidx = $pdf->importPage(1, '/MediaBox'); // Standard

		// Start populating data
		$pdf->addPage();
		$pdf->useTemplate($tplidx, 0, 0, 0,0,true);

		// Atribute positions
		// 0 - Customer Name
		// 1 - Date
		// 2 - amount
		// 3 - Item description
		// 4 - Mode of payment
		// 5 - Receipt

		$pdf->SetFont('Arial'); 
		$pdf->SetFontSize(12); 
		$pdf->SetTextColor(0,0,0); 

		$lineno = 68;
		$pdf->SetXY(24.5, $lineno); 
		$pdf->Write(0, $varsarray[0]);  // Customer Name
		$lineno = $lineno + 5;

		$pdf->SetXY(24.5, $lineno); 
		$pdf->Write(0, $varsarray[3]);  // Date
		$lineno = $lineno + 5;


		$text = 'Thank you for your payment of $'.$varsarray[2].' for purchasing gift card(s).';
		$pdf->SetXY(24.5, $lineno); 
	//	$pdf->Write(0, $text); 
		$pdf->MultiCell(0,5,$text);		
		$lineno = $lineno + 4;

		$pdf->SetXY(24.5, 95); 
		
		$pdf->SetFont('Courier'); 
		$pdf->SetFontSize(9); 

		$pdf->MultiCell(0,5,$varsarray[4]); // Receipt

?>