<?php


		$pagecount = $pdf->setSourceFile('../pdf/templates/ccreceipttemplate.pdf'); // template name
		$outputfilename = '../pdf/output/ccreceipt'.$varsarray[7].'.pdf'; // output file name
		$tplidx = $pdf->importPage(1, '/MediaBox'); // Standard

		// Start populating data
		$pdf->addPage();
		$pdf->useTemplate($tplidx, 0, 0, 0,0,true);

		$pdf->SetFont('Arial'); 
		$pdf->SetFontSize(9); 
		$pdf->SetTextColor(0,0,0); 

		$lineno = 46;
		$pdf->SetXY(24.5, $lineno); 
		$pdf->Write(0, $varsarray[0]);  // Merchant Name

		$lineno = $lineno + 4;
		$pdf->SetXY(24.5, $lineno); 
		$pdf->Write(0, $varsarray[1]);  // Address Line 1
		

		if (!empty($varsarray[2]))
		{
			$lineno = $lineno + 4;
			$pdf->SetXY(24.5, $lineno); 
			$pdf->Write(0, $varsarray[2]);  // Address Line 2
			$lineno = $lineno + 4;
		}

		$pdf->SetXY(24.5, $lineno); 
		$pdf->Write(0, $varsarray[3].' '.$varsarray[4]);  // City and Province
		$lineno = $lineno + 4;

		$pdf->SetXY(24.5, $lineno); 
		$pdf->Write(0, $varsarray[5].' '.$varsarray[6]);  // Postal code + Country

		$lineno = $lineno + 6;
		$pdf->SetXY(24.5, $lineno); 
		$pdf->Write(0, $varsarray[7]);  // Date

		if (!empty($varsarray[8]))
		{
			$lineno = $lineno + 6;
			$pdf->SetXY(24.5, $lineno); 
			$pdf->Write(0, $varsarray[8]);  // Customer Name
		}

		if (!empty($varsarray[9]))
		{
			$lineno = $lineno + 4;
			$pdf->SetXY(24.5, $lineno); 
			$pdf->Write(0, $varsarray[9]);  // Customer Contact Name
		}
			
		$lineno = $lineno + 4;
		$pdf->SetXY(24.5, $lineno); 
		$pdf->Write(0, $varsarray[10]);  // Customer Address Line 1

		if (!empty($varsarray[11]))
		{
			$lineno = $lineno + 4;
			$pdf->SetXY(24.5, $lineno); 
			$pdf->Write(0, $varsarray[11]);  // Customer Address Line 2
		}

		$lineno = $lineno + 4;
		$pdf->SetXY(24.5, $lineno); 
		$pdf->Write(0, rtrim($varsarray[12]).' '.$varsarray[13]);  // Customer City and Province

		$lineno = $lineno + 4;
		$pdf->SetXY(24.5, $lineno); 
		$pdf->Write(0, $varsarray[14].' '.$varsarray[15]);  // postal code + Customer Country

		$lineno = $lineno + 18;
		$pdf->SetXY(24.5, $lineno); 
		$pdf->Write(0, $varsarray[16]);  // Thannk you and item message
		
	
		$lineno = $lineno + 6;
		$pdf->SetXY(24.5, $lineno); 
		$pdf->SetFont('Courier'); 
		$pdf->SetFontSize(9); 
		$pdf->MultiCell(0,5,$varsarray[17]); // Receipt
        
?>