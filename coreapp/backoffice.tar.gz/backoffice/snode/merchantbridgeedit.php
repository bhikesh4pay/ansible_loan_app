<?php
namespace PHPMaker2020\_4payadmin;

// Autoload
include_once "autoload.php";

// Session
if (session_status() !== PHP_SESSION_ACTIVE)
	\Delight\Cookie\Session::start(Config("COOKIE_SAMESITE")); // Init session data

// Output buffering
ob_start();
?>
<?php

// Write header
WriteHeader(FALSE);

// Create page object
$merchantbridge_edit = new merchantbridge_edit();

// Run the page
$merchantbridge_edit->run();

// Setup login status
SetupLoginStatus();
SetClientVar("login", LoginStatus());

// Global Page Rendering event (in userfn*.php)
Page_Rendering();

// Page Rendering event
$merchantbridge_edit->Page_Render();
?>
<?php include_once "header.php"; ?>
<script>
var fmerchantbridgeedit, currentPageID;
loadjs.ready("head", function() {

	// Form object
	currentPageID = ew.PAGE_ID = "edit";
	fmerchantbridgeedit = currentForm = new ew.Form("fmerchantbridgeedit", "edit");

	// Validate form
	fmerchantbridgeedit.validate = function() {
		if (!this.validateRequired)
			return true; // Ignore validation
		var $ = jQuery, fobj = this.getForm(), $fobj = $(fobj);
		if ($fobj.find("#confirm").val() == "confirm")
			return true;
		var elm, felm, uelm, addcnt = 0;
		var $k = $fobj.find("#" + this.formKeyCountName); // Get key_count
		var rowcnt = ($k[0]) ? parseInt($k.val(), 10) : 1;
		var startcnt = (rowcnt == 0) ? 0 : 1; // Check rowcnt == 0 => Inline-Add
		var gridinsert = ["insert", "gridinsert"].includes($fobj.find("#action").val()) && $k[0];
		for (var i = startcnt; i <= rowcnt; i++) {
			var infix = ($k[0]) ? String(i) : "";
			$fobj.data("rowindex", infix);
			<?php if ($merchantbridge_edit->posfullid->Required) { ?>
				elm = this.getElements("x" + infix + "_posfullid");
				if (elm && !ew.isHidden(elm) && !ew.hasValue(elm))
					return this.onError(elm, "<?php echo JsEncode(str_replace("%s", $merchantbridge_edit->posfullid->caption(), $merchantbridge_edit->posfullid->RequiredErrorMessage)) ?>");
			<?php } ?>
			<?php if ($merchantbridge_edit->bridgefullid->Required) { ?>
				elm = this.getElements("x" + infix + "_bridgefullid");
				if (elm && !ew.isHidden(elm) && !ew.hasValue(elm))
					return this.onError(elm, "<?php echo JsEncode(str_replace("%s", $merchantbridge_edit->bridgefullid->caption(), $merchantbridge_edit->bridgefullid->RequiredErrorMessage)) ?>");
			<?php } ?>
			<?php if ($merchantbridge_edit->merchantid->Required) { ?>
				elm = this.getElements("x" + infix + "_merchantid");
				if (elm && !ew.isHidden(elm) && !ew.hasValue(elm))
					return this.onError(elm, "<?php echo JsEncode(str_replace("%s", $merchantbridge_edit->merchantid->caption(), $merchantbridge_edit->merchantid->RequiredErrorMessage)) ?>");
			<?php } ?>
				elm = this.getElements("x" + infix + "_merchantid");
				if (elm && !ew.checkInteger(elm.value))
					return this.onError(elm, "<?php echo JsEncode($merchantbridge_edit->merchantid->errorMessage()) ?>");

				// Call Form_CustomValidate event
				if (!this.Form_CustomValidate(fobj))
					return false;
		}

		// Process detail forms
		var dfs = $fobj.find("input[name='detailpage']").get();
		for (var i = 0; i < dfs.length; i++) {
			var df = dfs[i], val = df.value;
			if (val && ew.forms[val])
				if (!ew.forms[val].validate())
					return false;
		}
		return true;
	}

	// Form_CustomValidate
	fmerchantbridgeedit.Form_CustomValidate = function(fobj) { // DO NOT CHANGE THIS LINE!

		// Your custom validation code here, return false if invalid.
		return true;
	}

	// Use JavaScript validation or not
	fmerchantbridgeedit.validateRequired = <?php echo Config("CLIENT_VALIDATE") ? "true" : "false" ?>;

	// Dynamic selection lists
	loadjs.done("fmerchantbridgeedit");
});
</script>
<script>
loadjs.ready("head", function() {

	// Client script
	// Write your client script here, no need to add script tags.

});
</script>
<?php $merchantbridge_edit->showPageHeader(); ?>
<?php
$merchantbridge_edit->showMessage();
?>
<form name="fmerchantbridgeedit" id="fmerchantbridgeedit" class="<?php echo $merchantbridge_edit->FormClassName ?>" action="<?php echo CurrentPageName() ?>" method="post">
<?php if ($Page->CheckToken) { ?>
<input type="hidden" name="<?php echo Config("TOKEN_NAME") ?>" value="<?php echo $Page->Token ?>">
<?php } ?>
<input type="hidden" name="t" value="merchantbridge">
<input type="hidden" name="action" id="action" value="update">
<input type="hidden" name="modal" value="<?php echo (int)$merchantbridge_edit->IsModal ?>">
<div class="ew-edit-div"><!-- page* -->
<?php if ($merchantbridge_edit->posfullid->Visible) { // posfullid ?>
	<div id="r_posfullid" class="form-group row">
		<label id="elh_merchantbridge_posfullid" for="x_posfullid" class="<?php echo $merchantbridge_edit->LeftColumnClass ?>"><?php echo $merchantbridge_edit->posfullid->caption() ?><?php echo $merchantbridge_edit->posfullid->Required ? $Language->phrase("FieldRequiredIndicator") : "" ?></label>
		<div class="<?php echo $merchantbridge_edit->RightColumnClass ?>"><div <?php echo $merchantbridge_edit->posfullid->cellAttributes() ?>>
<input type="text" data-table="merchantbridge" data-field="x_posfullid" name="x_posfullid" id="x_posfullid" size="30" maxlength="25" placeholder="<?php echo HtmlEncode($merchantbridge_edit->posfullid->getPlaceHolder()) ?>" value="<?php echo $merchantbridge_edit->posfullid->EditValue ?>"<?php echo $merchantbridge_edit->posfullid->editAttributes() ?>>
<input type="hidden" data-table="merchantbridge" data-field="x_posfullid" name="o_posfullid" id="o_posfullid" value="<?php echo HtmlEncode($merchantbridge_edit->posfullid->OldValue != null ? $merchantbridge_edit->posfullid->OldValue : $merchantbridge_edit->posfullid->CurrentValue) ?>">
<?php echo $merchantbridge_edit->posfullid->CustomMsg ?></div></div>
	</div>
<?php } ?>
<?php if ($merchantbridge_edit->bridgefullid->Visible) { // bridgefullid ?>
	<div id="r_bridgefullid" class="form-group row">
		<label id="elh_merchantbridge_bridgefullid" for="x_bridgefullid" class="<?php echo $merchantbridge_edit->LeftColumnClass ?>"><?php echo $merchantbridge_edit->bridgefullid->caption() ?><?php echo $merchantbridge_edit->bridgefullid->Required ? $Language->phrase("FieldRequiredIndicator") : "" ?></label>
		<div class="<?php echo $merchantbridge_edit->RightColumnClass ?>"><div <?php echo $merchantbridge_edit->bridgefullid->cellAttributes() ?>>
<input type="text" data-table="merchantbridge" data-field="x_bridgefullid" name="x_bridgefullid" id="x_bridgefullid" size="30" maxlength="25" placeholder="<?php echo HtmlEncode($merchantbridge_edit->bridgefullid->getPlaceHolder()) ?>" value="<?php echo $merchantbridge_edit->bridgefullid->EditValue ?>"<?php echo $merchantbridge_edit->bridgefullid->editAttributes() ?>>
<input type="hidden" data-table="merchantbridge" data-field="x_bridgefullid" name="o_bridgefullid" id="o_bridgefullid" value="<?php echo HtmlEncode($merchantbridge_edit->bridgefullid->OldValue != null ? $merchantbridge_edit->bridgefullid->OldValue : $merchantbridge_edit->bridgefullid->CurrentValue) ?>">
<?php echo $merchantbridge_edit->bridgefullid->CustomMsg ?></div></div>
	</div>
<?php } ?>
<?php if ($merchantbridge_edit->merchantid->Visible) { // merchantid ?>
	<div id="r_merchantid" class="form-group row">
		<label id="elh_merchantbridge_merchantid" for="x_merchantid" class="<?php echo $merchantbridge_edit->LeftColumnClass ?>"><?php echo $merchantbridge_edit->merchantid->caption() ?><?php echo $merchantbridge_edit->merchantid->Required ? $Language->phrase("FieldRequiredIndicator") : "" ?></label>
		<div class="<?php echo $merchantbridge_edit->RightColumnClass ?>"><div <?php echo $merchantbridge_edit->merchantid->cellAttributes() ?>>
<span id="el_merchantbridge_merchantid">
<input type="text" data-table="merchantbridge" data-field="x_merchantid" name="x_merchantid" id="x_merchantid" size="30" placeholder="<?php echo HtmlEncode($merchantbridge_edit->merchantid->getPlaceHolder()) ?>" value="<?php echo $merchantbridge_edit->merchantid->EditValue ?>"<?php echo $merchantbridge_edit->merchantid->editAttributes() ?>>
</span>
<?php echo $merchantbridge_edit->merchantid->CustomMsg ?></div></div>
	</div>
<?php } ?>
</div><!-- /page* -->
<?php if (!$merchantbridge_edit->IsModal) { ?>
<div class="form-group row"><!-- buttons .form-group -->
	<div class="<?php echo $merchantbridge_edit->OffsetColumnClass ?>"><!-- buttons offset -->
<button class="btn btn-primary ew-btn" name="btn-action" id="btn-action" type="submit"><?php echo $Language->phrase("SaveBtn") ?></button>
<button class="btn btn-default ew-btn" name="btn-cancel" id="btn-cancel" type="button" data-href="<?php echo $merchantbridge_edit->getReturnUrl() ?>"><?php echo $Language->phrase("CancelBtn") ?></button>
	</div><!-- /buttons offset -->
</div><!-- /buttons .form-group -->
<?php } ?>
</form>
<?php
$merchantbridge_edit->showPageFooter();
if (Config("DEBUG"))
	echo GetDebugMessage();
?>
<script>
loadjs.ready("load", function() {

	// Startup script
	// Write your table-specific startup script here
	// console.log("page loaded");

});
</script>
<?php include_once "footer.php"; ?>
<?php
$merchantbridge_edit->terminate();
?>