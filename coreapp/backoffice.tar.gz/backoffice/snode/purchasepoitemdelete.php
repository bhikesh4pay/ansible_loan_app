<?php
namespace PHPMaker2020\_4payadmin;

// Autoload
include_once "autoload.php";

// Session
if (session_status() !== PHP_SESSION_ACTIVE)
	\Delight\Cookie\Session::start(Config("COOKIE_SAMESITE")); // Init session data

// Output buffering
ob_start();
?>
<?php

// Write header
WriteHeader(FALSE);

// Create page object
$purchasepoitem_delete = new purchasepoitem_delete();

// Run the page
$purchasepoitem_delete->run();

// Setup login status
SetupLoginStatus();
SetClientVar("login", LoginStatus());

// Global Page Rendering event (in userfn*.php)
Page_Rendering();

// Page Rendering event
$purchasepoitem_delete->Page_Render();
?>
<?php include_once "header.php"; ?>
<script>
var fpurchasepoitemdelete, currentPageID;
loadjs.ready("head", function() {

	// Form object
	currentPageID = ew.PAGE_ID = "delete";
	fpurchasepoitemdelete = currentForm = new ew.Form("fpurchasepoitemdelete", "delete");
	loadjs.done("fpurchasepoitemdelete");
});
</script>
<script>
loadjs.ready("head", function() {

	// Client script
	// Write your client script here, no need to add script tags.

});
</script>
<?php $purchasepoitem_delete->showPageHeader(); ?>
<?php
$purchasepoitem_delete->showMessage();
?>
<form name="fpurchasepoitemdelete" id="fpurchasepoitemdelete" class="form-inline ew-form ew-delete-form" action="<?php echo CurrentPageName() ?>" method="post">
<?php if ($Page->CheckToken) { ?>
<input type="hidden" name="<?php echo Config("TOKEN_NAME") ?>" value="<?php echo $Page->Token ?>">
<?php } ?>
<input type="hidden" name="t" value="purchasepoitem">
<input type="hidden" name="action" id="action" value="delete">
<?php foreach ($purchasepoitem_delete->RecKeys as $key) { ?>
<?php $keyvalue = is_array($key) ? implode(Config("COMPOSITE_KEY_SEPARATOR"), $key) : $key; ?>
<input type="hidden" name="key_m[]" value="<?php echo HtmlEncode($keyvalue) ?>">
<?php } ?>
<div class="card ew-card ew-grid">
<div class="<?php echo ResponsiveTableClass() ?>card-body ew-grid-middle-panel">
<table class="table ew-table">
	<thead>
	<tr class="ew-table-header">
<?php if ($purchasepoitem_delete->itemid->Visible) { // itemid ?>
		<th class="<?php echo $purchasepoitem_delete->itemid->headerCellClass() ?>"><span id="elh_purchasepoitem_itemid" class="purchasepoitem_itemid"><?php echo $purchasepoitem_delete->itemid->caption() ?></span></th>
<?php } ?>
<?php if ($purchasepoitem_delete->poid->Visible) { // poid ?>
		<th class="<?php echo $purchasepoitem_delete->poid->headerCellClass() ?>"><span id="elh_purchasepoitem_poid" class="purchasepoitem_poid"><?php echo $purchasepoitem_delete->poid->caption() ?></span></th>
<?php } ?>
<?php if ($purchasepoitem_delete->cardpiid->Visible) { // cardpiid ?>
		<th class="<?php echo $purchasepoitem_delete->cardpiid->headerCellClass() ?>"><span id="elh_purchasepoitem_cardpiid" class="purchasepoitem_cardpiid"><?php echo $purchasepoitem_delete->cardpiid->caption() ?></span></th>
<?php } ?>
<?php if ($purchasepoitem_delete->currcode->Visible) { // currcode ?>
		<th class="<?php echo $purchasepoitem_delete->currcode->headerCellClass() ?>"><span id="elh_purchasepoitem_currcode" class="purchasepoitem_currcode"><?php echo $purchasepoitem_delete->currcode->caption() ?></span></th>
<?php } ?>
<?php if ($purchasepoitem_delete->denom->Visible) { // denom ?>
		<th class="<?php echo $purchasepoitem_delete->denom->headerCellClass() ?>"><span id="elh_purchasepoitem_denom" class="purchasepoitem_denom"><?php echo $purchasepoitem_delete->denom->caption() ?></span></th>
<?php } ?>
<?php if ($purchasepoitem_delete->status->Visible) { // status ?>
		<th class="<?php echo $purchasepoitem_delete->status->headerCellClass() ?>"><span id="elh_purchasepoitem_status" class="purchasepoitem_status"><?php echo $purchasepoitem_delete->status->caption() ?></span></th>
<?php } ?>
<?php if ($purchasepoitem_delete->userpi_id->Visible) { // userpi_id ?>
		<th class="<?php echo $purchasepoitem_delete->userpi_id->headerCellClass() ?>"><span id="elh_purchasepoitem_userpi_id" class="purchasepoitem_userpi_id"><?php echo $purchasepoitem_delete->userpi_id->caption() ?></span></th>
<?php } ?>
<?php if ($purchasepoitem_delete->initiate_pi_transfer->Visible) { // initiate_pi_transfer ?>
		<th class="<?php echo $purchasepoitem_delete->initiate_pi_transfer->headerCellClass() ?>"><span id="elh_purchasepoitem_initiate_pi_transfer" class="purchasepoitem_initiate_pi_transfer"><?php echo $purchasepoitem_delete->initiate_pi_transfer->caption() ?></span></th>
<?php } ?>
<?php if ($purchasepoitem_delete->is_email_send->Visible) { // is_email_send ?>
		<th class="<?php echo $purchasepoitem_delete->is_email_send->headerCellClass() ?>"><span id="elh_purchasepoitem_is_email_send" class="purchasepoitem_is_email_send"><?php echo $purchasepoitem_delete->is_email_send->caption() ?></span></th>
<?php } ?>
	</tr>
	</thead>
	<tbody>
<?php
$purchasepoitem_delete->RecordCount = 0;
$i = 0;
while (!$purchasepoitem_delete->Recordset->EOF) {
	$purchasepoitem_delete->RecordCount++;
	$purchasepoitem_delete->RowCount++;

	// Set row properties
	$purchasepoitem->resetAttributes();
	$purchasepoitem->RowType = ROWTYPE_VIEW; // View

	// Get the field contents
	$purchasepoitem_delete->loadRowValues($purchasepoitem_delete->Recordset);

	// Render row
	$purchasepoitem_delete->renderRow();
?>
	<tr <?php echo $purchasepoitem->rowAttributes() ?>>
<?php if ($purchasepoitem_delete->itemid->Visible) { // itemid ?>
		<td <?php echo $purchasepoitem_delete->itemid->cellAttributes() ?>>
<span id="el<?php echo $purchasepoitem_delete->RowCount ?>_purchasepoitem_itemid" class="purchasepoitem_itemid">
<span<?php echo $purchasepoitem_delete->itemid->viewAttributes() ?>><?php echo $purchasepoitem_delete->itemid->getViewValue() ?></span>
</span>
</td>
<?php } ?>
<?php if ($purchasepoitem_delete->poid->Visible) { // poid ?>
		<td <?php echo $purchasepoitem_delete->poid->cellAttributes() ?>>
<span id="el<?php echo $purchasepoitem_delete->RowCount ?>_purchasepoitem_poid" class="purchasepoitem_poid">
<span<?php echo $purchasepoitem_delete->poid->viewAttributes() ?>><?php echo $purchasepoitem_delete->poid->getViewValue() ?></span>
</span>
</td>
<?php } ?>
<?php if ($purchasepoitem_delete->cardpiid->Visible) { // cardpiid ?>
		<td <?php echo $purchasepoitem_delete->cardpiid->cellAttributes() ?>>
<span id="el<?php echo $purchasepoitem_delete->RowCount ?>_purchasepoitem_cardpiid" class="purchasepoitem_cardpiid">
<span<?php echo $purchasepoitem_delete->cardpiid->viewAttributes() ?>><?php echo $purchasepoitem_delete->cardpiid->getViewValue() ?></span>
</span>
</td>
<?php } ?>
<?php if ($purchasepoitem_delete->currcode->Visible) { // currcode ?>
		<td <?php echo $purchasepoitem_delete->currcode->cellAttributes() ?>>
<span id="el<?php echo $purchasepoitem_delete->RowCount ?>_purchasepoitem_currcode" class="purchasepoitem_currcode">
<span<?php echo $purchasepoitem_delete->currcode->viewAttributes() ?>><?php echo $purchasepoitem_delete->currcode->getViewValue() ?></span>
</span>
</td>
<?php } ?>
<?php if ($purchasepoitem_delete->denom->Visible) { // denom ?>
		<td <?php echo $purchasepoitem_delete->denom->cellAttributes() ?>>
<span id="el<?php echo $purchasepoitem_delete->RowCount ?>_purchasepoitem_denom" class="purchasepoitem_denom">
<span<?php echo $purchasepoitem_delete->denom->viewAttributes() ?>><?php echo $purchasepoitem_delete->denom->getViewValue() ?></span>
</span>
</td>
<?php } ?>
<?php if ($purchasepoitem_delete->status->Visible) { // status ?>
		<td <?php echo $purchasepoitem_delete->status->cellAttributes() ?>>
<span id="el<?php echo $purchasepoitem_delete->RowCount ?>_purchasepoitem_status" class="purchasepoitem_status">
<span<?php echo $purchasepoitem_delete->status->viewAttributes() ?>><?php echo $purchasepoitem_delete->status->getViewValue() ?></span>
</span>
</td>
<?php } ?>
<?php if ($purchasepoitem_delete->userpi_id->Visible) { // userpi_id ?>
		<td <?php echo $purchasepoitem_delete->userpi_id->cellAttributes() ?>>
<span id="el<?php echo $purchasepoitem_delete->RowCount ?>_purchasepoitem_userpi_id" class="purchasepoitem_userpi_id">
<span<?php echo $purchasepoitem_delete->userpi_id->viewAttributes() ?>><?php echo $purchasepoitem_delete->userpi_id->getViewValue() ?></span>
</span>
</td>
<?php } ?>
<?php if ($purchasepoitem_delete->initiate_pi_transfer->Visible) { // initiate_pi_transfer ?>
		<td <?php echo $purchasepoitem_delete->initiate_pi_transfer->cellAttributes() ?>>
<span id="el<?php echo $purchasepoitem_delete->RowCount ?>_purchasepoitem_initiate_pi_transfer" class="purchasepoitem_initiate_pi_transfer">
<span<?php echo $purchasepoitem_delete->initiate_pi_transfer->viewAttributes() ?>><?php echo $purchasepoitem_delete->initiate_pi_transfer->getViewValue() ?></span>
</span>
</td>
<?php } ?>
<?php if ($purchasepoitem_delete->is_email_send->Visible) { // is_email_send ?>
		<td <?php echo $purchasepoitem_delete->is_email_send->cellAttributes() ?>>
<span id="el<?php echo $purchasepoitem_delete->RowCount ?>_purchasepoitem_is_email_send" class="purchasepoitem_is_email_send">
<span<?php echo $purchasepoitem_delete->is_email_send->viewAttributes() ?>><?php echo $purchasepoitem_delete->is_email_send->getViewValue() ?></span>
</span>
</td>
<?php } ?>
	</tr>
<?php
	$purchasepoitem_delete->Recordset->moveNext();
}
$purchasepoitem_delete->Recordset->close();
?>
</tbody>
</table>
</div>
</div>
<div>
<button class="btn btn-primary ew-btn" name="btn-action" id="btn-action" type="submit"><?php echo $Language->phrase("DeleteBtn") ?></button>
<button class="btn btn-default ew-btn" name="btn-cancel" id="btn-cancel" type="button" data-href="<?php echo $purchasepoitem_delete->getReturnUrl() ?>"><?php echo $Language->phrase("CancelBtn") ?></button>
</div>
</form>
<?php
$purchasepoitem_delete->showPageFooter();
if (Config("DEBUG"))
	echo GetDebugMessage();
?>
<script>
loadjs.ready("load", function() {

	// Startup script
	// Write your table-specific startup script here
	// console.log("page loaded");

});
</script>
<?php include_once "footer.php"; ?>
<?php
$purchasepoitem_delete->terminate();
?>