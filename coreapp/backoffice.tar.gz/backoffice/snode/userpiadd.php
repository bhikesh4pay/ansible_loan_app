<?php
namespace PHPMaker2020\_4payadmin;

// Autoload
include_once "autoload.php";

// Session
if (session_status() !== PHP_SESSION_ACTIVE)
	\Delight\Cookie\Session::start(Config("COOKIE_SAMESITE")); // Init session data

// Output buffering
ob_start();
?>
<?php

// Write header
WriteHeader(FALSE);

// Create page object
$userpi_add = new userpi_add();

// Run the page
$userpi_add->run();

// Setup login status
SetupLoginStatus();
SetClientVar("login", LoginStatus());

// Global Page Rendering event (in userfn*.php)
Page_Rendering();

// Page Rendering event
$userpi_add->Page_Render();
?>
<?php include_once "header.php"; ?>
<script>
var fuserpiadd, currentPageID;
loadjs.ready("head", function() {

	// Form object
	currentPageID = ew.PAGE_ID = "add";
	fuserpiadd = currentForm = new ew.Form("fuserpiadd", "add");

	// Validate form
	fuserpiadd.validate = function() {
		if (!this.validateRequired)
			return true; // Ignore validation
		var $ = jQuery, fobj = this.getForm(), $fobj = $(fobj);
		if ($fobj.find("#confirm").val() == "confirm")
			return true;
		var elm, felm, uelm, addcnt = 0;
		var $k = $fobj.find("#" + this.formKeyCountName); // Get key_count
		var rowcnt = ($k[0]) ? parseInt($k.val(), 10) : 1;
		var startcnt = (rowcnt == 0) ? 0 : 1; // Check rowcnt == 0 => Inline-Add
		var gridinsert = ["insert", "gridinsert"].includes($fobj.find("#action").val()) && $k[0];
		for (var i = startcnt; i <= rowcnt; i++) {
			var infix = ($k[0]) ? String(i) : "";
			$fobj.data("rowindex", infix);
			<?php if ($userpi_add->_userid->Required) { ?>
				elm = this.getElements("x" + infix + "__userid");
				if (elm && !ew.isHidden(elm) && !ew.hasValue(elm))
					return this.onError(elm, "<?php echo JsEncode(str_replace("%s", $userpi_add->_userid->caption(), $userpi_add->_userid->RequiredErrorMessage)) ?>");
			<?php } ?>
				elm = this.getElements("x" + infix + "__userid");
				if (elm && !ew.checkInteger(elm.value))
					return this.onError(elm, "<?php echo JsEncode($userpi_add->_userid->errorMessage()) ?>");
			<?php if ($userpi_add->cardno->Required) { ?>
				elm = this.getElements("x" + infix + "_cardno");
				if (elm && !ew.isHidden(elm) && !ew.hasValue(elm))
					return this.onError(elm, "<?php echo JsEncode(str_replace("%s", $userpi_add->cardno->caption(), $userpi_add->cardno->RequiredErrorMessage)) ?>");
			<?php } ?>
			<?php if ($userpi_add->lastupdated->Required) { ?>
				elm = this.getElements("x" + infix + "_lastupdated");
				if (elm && !ew.isHidden(elm) && !ew.hasValue(elm))
					return this.onError(elm, "<?php echo JsEncode(str_replace("%s", $userpi_add->lastupdated->caption(), $userpi_add->lastupdated->RequiredErrorMessage)) ?>");
			<?php } ?>
				elm = this.getElements("x" + infix + "_lastupdated");
				if (elm && !ew.checkUSDate(elm.value))
					return this.onError(elm, "<?php echo JsEncode($userpi_add->lastupdated->errorMessage()) ?>");
			<?php if ($userpi_add->piid->Required) { ?>
				elm = this.getElements("x" + infix + "_piid");
				if (elm && !ew.isHidden(elm) && !ew.hasValue(elm))
					return this.onError(elm, "<?php echo JsEncode(str_replace("%s", $userpi_add->piid->caption(), $userpi_add->piid->RequiredErrorMessage)) ?>");
			<?php } ?>
			<?php if ($userpi_add->deleted->Required) { ?>
				elm = this.getElements("x" + infix + "_deleted");
				if (elm && !ew.isHidden(elm) && !ew.hasValue(elm))
					return this.onError(elm, "<?php echo JsEncode(str_replace("%s", $userpi_add->deleted->caption(), $userpi_add->deleted->RequiredErrorMessage)) ?>");
			<?php } ?>
			<?php if ($userpi_add->currcode->Required) { ?>
				elm = this.getElements("x" + infix + "_currcode");
				if (elm && !ew.isHidden(elm) && !ew.hasValue(elm))
					return this.onError(elm, "<?php echo JsEncode(str_replace("%s", $userpi_add->currcode->caption(), $userpi_add->currcode->RequiredErrorMessage)) ?>");
			<?php } ?>
			<?php if ($userpi_add->friendlyname->Required) { ?>
				elm = this.getElements("x" + infix + "_friendlyname");
				if (elm && !ew.isHidden(elm) && !ew.hasValue(elm))
					return this.onError(elm, "<?php echo JsEncode(str_replace("%s", $userpi_add->friendlyname->caption(), $userpi_add->friendlyname->RequiredErrorMessage)) ?>");
			<?php } ?>
			<?php if ($userpi_add->verified->Required) { ?>
				elm = this.getElements("x" + infix + "_verified");
				if (elm && !ew.isHidden(elm) && !ew.hasValue(elm))
					return this.onError(elm, "<?php echo JsEncode(str_replace("%s", $userpi_add->verified->caption(), $userpi_add->verified->RequiredErrorMessage)) ?>");
			<?php } ?>
			<?php if ($userpi_add->addeddatetime->Required) { ?>
				elm = this.getElements("x" + infix + "_addeddatetime");
				if (elm && !ew.isHidden(elm) && !ew.hasValue(elm))
					return this.onError(elm, "<?php echo JsEncode(str_replace("%s", $userpi_add->addeddatetime->caption(), $userpi_add->addeddatetime->RequiredErrorMessage)) ?>");
			<?php } ?>
				elm = this.getElements("x" + infix + "_addeddatetime");
				if (elm && !ew.checkDateDef(elm.value))
					return this.onError(elm, "<?php echo JsEncode($userpi_add->addeddatetime->errorMessage()) ?>");
			<?php if ($userpi_add->piexpirytime->Required) { ?>
				elm = this.getElements("x" + infix + "_piexpirytime");
				if (elm && !ew.isHidden(elm) && !ew.hasValue(elm))
					return this.onError(elm, "<?php echo JsEncode(str_replace("%s", $userpi_add->piexpirytime->caption(), $userpi_add->piexpirytime->RequiredErrorMessage)) ?>");
			<?php } ?>
				elm = this.getElements("x" + infix + "_piexpirytime");
				if (elm && !ew.checkDateDef(elm.value))
					return this.onError(elm, "<?php echo JsEncode($userpi_add->piexpirytime->errorMessage()) ?>");
			<?php if ($userpi_add->verifiedtime->Required) { ?>
				elm = this.getElements("x" + infix + "_verifiedtime");
				if (elm && !ew.isHidden(elm) && !ew.hasValue(elm))
					return this.onError(elm, "<?php echo JsEncode(str_replace("%s", $userpi_add->verifiedtime->caption(), $userpi_add->verifiedtime->RequiredErrorMessage)) ?>");
			<?php } ?>
				elm = this.getElements("x" + infix + "_verifiedtime");
				if (elm && !ew.checkDateDef(elm.value))
					return this.onError(elm, "<?php echo JsEncode($userpi_add->verifiedtime->errorMessage()) ?>");
			<?php if ($userpi_add->vaultid->Required) { ?>
				elm = this.getElements("x" + infix + "_vaultid");
				if (elm && !ew.isHidden(elm) && !ew.hasValue(elm))
					return this.onError(elm, "<?php echo JsEncode(str_replace("%s", $userpi_add->vaultid->caption(), $userpi_add->vaultid->RequiredErrorMessage)) ?>");
			<?php } ?>
			<?php if ($userpi_add->defaultpi->Required) { ?>
				elm = this.getElements("x" + infix + "_defaultpi");
				if (elm && !ew.isHidden(elm) && !ew.hasValue(elm))
					return this.onError(elm, "<?php echo JsEncode(str_replace("%s", $userpi_add->defaultpi->caption(), $userpi_add->defaultpi->RequiredErrorMessage)) ?>");
			<?php } ?>
			<?php if ($userpi_add->acctID->Required) { ?>
				elm = this.getElements("x" + infix + "_acctID");
				if (elm && !ew.isHidden(elm) && !ew.hasValue(elm))
					return this.onError(elm, "<?php echo JsEncode(str_replace("%s", $userpi_add->acctID->caption(), $userpi_add->acctID->RequiredErrorMessage)) ?>");
			<?php } ?>
				elm = this.getElements("x" + infix + "_acctID");
				if (elm && !ew.checkInteger(elm.value))
					return this.onError(elm, "<?php echo JsEncode($userpi_add->acctID->errorMessage()) ?>");
			<?php if ($userpi_add->addedbyuserid->Required) { ?>
				elm = this.getElements("x" + infix + "_addedbyuserid");
				if (elm && !ew.isHidden(elm) && !ew.hasValue(elm))
					return this.onError(elm, "<?php echo JsEncode(str_replace("%s", $userpi_add->addedbyuserid->caption(), $userpi_add->addedbyuserid->RequiredErrorMessage)) ?>");
			<?php } ?>
				elm = this.getElements("x" + infix + "_addedbyuserid");
				if (elm && !ew.checkInteger(elm.value))
					return this.onError(elm, "<?php echo JsEncode($userpi_add->addedbyuserid->errorMessage()) ?>");
			<?php if ($userpi_add->pendingtransfer->Required) { ?>
				elm = this.getElements("x" + infix + "_pendingtransfer");
				if (elm && !ew.isHidden(elm) && !ew.hasValue(elm))
					return this.onError(elm, "<?php echo JsEncode(str_replace("%s", $userpi_add->pendingtransfer->caption(), $userpi_add->pendingtransfer->RequiredErrorMessage)) ?>");
			<?php } ?>
			<?php if ($userpi_add->purchaseid->Required) { ?>
				elm = this.getElements("x" + infix + "_purchaseid");
				if (elm && !ew.isHidden(elm) && !ew.hasValue(elm))
					return this.onError(elm, "<?php echo JsEncode(str_replace("%s", $userpi_add->purchaseid->caption(), $userpi_add->purchaseid->RequiredErrorMessage)) ?>");
			<?php } ?>
				elm = this.getElements("x" + infix + "_purchaseid");
				if (elm && !ew.checkInteger(elm.value))
					return this.onError(elm, "<?php echo JsEncode($userpi_add->purchaseid->errorMessage()) ?>");
			<?php if ($userpi_add->paymentid->Required) { ?>
				elm = this.getElements("x" + infix + "_paymentid");
				if (elm && !ew.isHidden(elm) && !ew.hasValue(elm))
					return this.onError(elm, "<?php echo JsEncode(str_replace("%s", $userpi_add->paymentid->caption(), $userpi_add->paymentid->RequiredErrorMessage)) ?>");
			<?php } ?>
				elm = this.getElements("x" + infix + "_paymentid");
				if (elm && !ew.checkInteger(elm.value))
					return this.onError(elm, "<?php echo JsEncode($userpi_add->paymentid->errorMessage()) ?>");
			<?php if ($userpi_add->others->Required) { ?>
				elm = this.getElements("x" + infix + "_others");
				if (elm && !ew.isHidden(elm) && !ew.hasValue(elm))
					return this.onError(elm, "<?php echo JsEncode(str_replace("%s", $userpi_add->others->caption(), $userpi_add->others->RequiredErrorMessage)) ?>");
			<?php } ?>
			<?php if ($userpi_add->others2->Required) { ?>
				elm = this.getElements("x" + infix + "_others2");
				if (elm && !ew.isHidden(elm) && !ew.hasValue(elm))
					return this.onError(elm, "<?php echo JsEncode(str_replace("%s", $userpi_add->others2->caption(), $userpi_add->others2->RequiredErrorMessage)) ?>");
			<?php } ?>
			<?php if ($userpi_add->pinhash->Required) { ?>
				elm = this.getElements("x" + infix + "_pinhash");
				if (elm && !ew.isHidden(elm) && !ew.hasValue(elm))
					return this.onError(elm, "<?php echo JsEncode(str_replace("%s", $userpi_add->pinhash->caption(), $userpi_add->pinhash->RequiredErrorMessage)) ?>");
			<?php } ?>
			<?php if ($userpi_add->pinexpiry->Required) { ?>
				elm = this.getElements("x" + infix + "_pinexpiry");
				if (elm && !ew.isHidden(elm) && !ew.hasValue(elm))
					return this.onError(elm, "<?php echo JsEncode(str_replace("%s", $userpi_add->pinexpiry->caption(), $userpi_add->pinexpiry->RequiredErrorMessage)) ?>");
			<?php } ?>
				elm = this.getElements("x" + infix + "_pinexpiry");
				if (elm && !ew.checkDateDef(elm.value))
					return this.onError(elm, "<?php echo JsEncode($userpi_add->pinexpiry->errorMessage()) ?>");
			<?php if ($userpi_add->deletiontime->Required) { ?>
				elm = this.getElements("x" + infix + "_deletiontime");
				if (elm && !ew.isHidden(elm) && !ew.hasValue(elm))
					return this.onError(elm, "<?php echo JsEncode(str_replace("%s", $userpi_add->deletiontime->caption(), $userpi_add->deletiontime->RequiredErrorMessage)) ?>");
			<?php } ?>
				elm = this.getElements("x" + infix + "_deletiontime");
				if (elm && !ew.checkDateDef(elm.value))
					return this.onError(elm, "<?php echo JsEncode($userpi_add->deletiontime->errorMessage()) ?>");
			<?php if ($userpi_add->servicefeeexempted->Required) { ?>
				elm = this.getElements("x" + infix + "_servicefeeexempted");
				if (elm && !ew.isHidden(elm) && !ew.hasValue(elm))
					return this.onError(elm, "<?php echo JsEncode(str_replace("%s", $userpi_add->servicefeeexempted->caption(), $userpi_add->servicefeeexempted->RequiredErrorMessage)) ?>");
			<?php } ?>
			<?php if ($userpi_add->purposeofaccount->Required) { ?>
				elm = this.getElements("x" + infix + "_purposeofaccount");
				if (elm && !ew.isHidden(elm) && !ew.hasValue(elm))
					return this.onError(elm, "<?php echo JsEncode(str_replace("%s", $userpi_add->purposeofaccount->caption(), $userpi_add->purposeofaccount->RequiredErrorMessage)) ?>");
			<?php } ?>
			<?php if ($userpi_add->extendedfields->Required) { ?>
				elm = this.getElements("x" + infix + "_extendedfields");
				if (elm && !ew.isHidden(elm) && !ew.hasValue(elm))
					return this.onError(elm, "<?php echo JsEncode(str_replace("%s", $userpi_add->extendedfields->caption(), $userpi_add->extendedfields->RequiredErrorMessage)) ?>");
			<?php } ?>

				// Call Form_CustomValidate event
				if (!this.Form_CustomValidate(fobj))
					return false;
		}

		// Process detail forms
		var dfs = $fobj.find("input[name='detailpage']").get();
		for (var i = 0; i < dfs.length; i++) {
			var df = dfs[i], val = df.value;
			if (val && ew.forms[val])
				if (!ew.forms[val].validate())
					return false;
		}
		return true;
	}

	// Form_CustomValidate
	fuserpiadd.Form_CustomValidate = function(fobj) { // DO NOT CHANGE THIS LINE!

		// Your custom validation code here, return false if invalid.
		return true;
	}

	// Use JavaScript validation or not
	fuserpiadd.validateRequired = <?php echo Config("CLIENT_VALIDATE") ? "true" : "false" ?>;

	// Dynamic selection lists
	fuserpiadd.lists["x_piid"] = <?php echo $userpi_add->piid->Lookup->toClientList($userpi_add) ?>;
	fuserpiadd.lists["x_piid"].options = <?php echo JsonEncode($userpi_add->piid->lookupOptions()) ?>;
	fuserpiadd.lists["x_deleted"] = <?php echo $userpi_add->deleted->Lookup->toClientList($userpi_add) ?>;
	fuserpiadd.lists["x_deleted"].options = <?php echo JsonEncode($userpi_add->deleted->options(FALSE, TRUE)) ?>;
	fuserpiadd.lists["x_currcode"] = <?php echo $userpi_add->currcode->Lookup->toClientList($userpi_add) ?>;
	fuserpiadd.lists["x_currcode"].options = <?php echo JsonEncode($userpi_add->currcode->lookupOptions()) ?>;
	fuserpiadd.lists["x_verified"] = <?php echo $userpi_add->verified->Lookup->toClientList($userpi_add) ?>;
	fuserpiadd.lists["x_verified"].options = <?php echo JsonEncode($userpi_add->verified->lookupOptions()) ?>;
	fuserpiadd.lists["x_vaultid"] = <?php echo $userpi_add->vaultid->Lookup->toClientList($userpi_add) ?>;
	fuserpiadd.lists["x_vaultid"].options = <?php echo JsonEncode($userpi_add->vaultid->lookupOptions()) ?>;
	fuserpiadd.lists["x_defaultpi"] = <?php echo $userpi_add->defaultpi->Lookup->toClientList($userpi_add) ?>;
	fuserpiadd.lists["x_defaultpi"].options = <?php echo JsonEncode($userpi_add->defaultpi->lookupOptions()) ?>;
	fuserpiadd.lists["x_pendingtransfer"] = <?php echo $userpi_add->pendingtransfer->Lookup->toClientList($userpi_add) ?>;
	fuserpiadd.lists["x_pendingtransfer"].options = <?php echo JsonEncode($userpi_add->pendingtransfer->lookupOptions()) ?>;
	fuserpiadd.lists["x_servicefeeexempted"] = <?php echo $userpi_add->servicefeeexempted->Lookup->toClientList($userpi_add) ?>;
	fuserpiadd.lists["x_servicefeeexempted"].options = <?php echo JsonEncode($userpi_add->servicefeeexempted->lookupOptions()) ?>;
	fuserpiadd.lists["x_purposeofaccount"] = <?php echo $userpi_add->purposeofaccount->Lookup->toClientList($userpi_add) ?>;
	fuserpiadd.lists["x_purposeofaccount"].options = <?php echo JsonEncode($userpi_add->purposeofaccount->lookupOptions()) ?>;
	loadjs.done("fuserpiadd");
});
</script>
<script>
loadjs.ready("head", function() {

	// Client script
	// Write your client script here, no need to add script tags.

});
</script>
<?php $userpi_add->showPageHeader(); ?>
<?php
$userpi_add->showMessage();
?>
<form name="fuserpiadd" id="fuserpiadd" class="<?php echo $userpi_add->FormClassName ?>" action="<?php echo CurrentPageName() ?>" method="post">
<?php if ($Page->CheckToken) { ?>
<input type="hidden" name="<?php echo Config("TOKEN_NAME") ?>" value="<?php echo $Page->Token ?>">
<?php } ?>
<input type="hidden" name="t" value="userpi">
<input type="hidden" name="action" id="action" value="insert">
<input type="hidden" name="modal" value="<?php echo (int)$userpi_add->IsModal ?>">
<?php if ($userpi->getCurrentMasterTable() == "user") { ?>
<input type="hidden" name="<?php echo Config("TABLE_SHOW_MASTER") ?>" value="user">
<input type="hidden" name="fk_id" value="<?php echo HtmlEncode($userpi_add->_userid->getSessionValue()) ?>">
<?php } ?>
<div class="ew-add-div"><!-- page* -->
<?php if ($userpi_add->_userid->Visible) { // userid ?>
	<div id="r__userid" class="form-group row">
		<label id="elh_userpi__userid" for="x__userid" class="<?php echo $userpi_add->LeftColumnClass ?>"><?php echo $userpi_add->_userid->caption() ?><?php echo $userpi_add->_userid->Required ? $Language->phrase("FieldRequiredIndicator") : "" ?></label>
		<div class="<?php echo $userpi_add->RightColumnClass ?>"><div <?php echo $userpi_add->_userid->cellAttributes() ?>>
<?php if ($userpi_add->_userid->getSessionValue() != "") { ?>
<span id="el_userpi__userid">
<span<?php echo $userpi_add->_userid->viewAttributes() ?>><?php if (!EmptyString($userpi_add->_userid->ViewValue) && $userpi_add->_userid->linkAttributes() != "") { ?>
<a<?php echo $userpi_add->_userid->linkAttributes() ?>><input type="text" readonly class="form-control-plaintext" value="<?php echo HtmlEncode(RemoveHtml($userpi_add->_userid->ViewValue)) ?>"></a>
<?php } else { ?>
<input type="text" readonly class="form-control-plaintext" value="<?php echo HtmlEncode(RemoveHtml($userpi_add->_userid->ViewValue)) ?>">
<?php } ?></span>
</span>
<input type="hidden" id="x__userid" name="x__userid" value="<?php echo HtmlEncode($userpi_add->_userid->CurrentValue) ?>">
<?php } else { ?>
<span id="el_userpi__userid">
<input type="text" data-table="userpi" data-field="x__userid" name="x__userid" id="x__userid" size="30" placeholder="<?php echo HtmlEncode($userpi_add->_userid->getPlaceHolder()) ?>" value="<?php echo $userpi_add->_userid->EditValue ?>"<?php echo $userpi_add->_userid->editAttributes() ?>>
</span>
<?php } ?>
<?php echo $userpi_add->_userid->CustomMsg ?></div></div>
	</div>
<?php } ?>
<?php if ($userpi_add->cardno->Visible) { // cardno ?>
	<div id="r_cardno" class="form-group row">
		<label id="elh_userpi_cardno" for="x_cardno" class="<?php echo $userpi_add->LeftColumnClass ?>"><?php echo $userpi_add->cardno->caption() ?><?php echo $userpi_add->cardno->Required ? $Language->phrase("FieldRequiredIndicator") : "" ?></label>
		<div class="<?php echo $userpi_add->RightColumnClass ?>"><div <?php echo $userpi_add->cardno->cellAttributes() ?>>
<span id="el_userpi_cardno">
<input type="text" data-table="userpi" data-field="x_cardno" name="x_cardno" id="x_cardno" size="30" maxlength="50" placeholder="<?php echo HtmlEncode($userpi_add->cardno->getPlaceHolder()) ?>" value="<?php echo $userpi_add->cardno->EditValue ?>"<?php echo $userpi_add->cardno->editAttributes() ?>>
</span>
<?php echo $userpi_add->cardno->CustomMsg ?></div></div>
	</div>
<?php } ?>
<?php if ($userpi_add->lastupdated->Visible) { // lastupdated ?>
	<div id="r_lastupdated" class="form-group row">
		<label id="elh_userpi_lastupdated" for="x_lastupdated" class="<?php echo $userpi_add->LeftColumnClass ?>"><?php echo $userpi_add->lastupdated->caption() ?><?php echo $userpi_add->lastupdated->Required ? $Language->phrase("FieldRequiredIndicator") : "" ?></label>
		<div class="<?php echo $userpi_add->RightColumnClass ?>"><div <?php echo $userpi_add->lastupdated->cellAttributes() ?>>
<span id="el_userpi_lastupdated">
<input type="text" data-table="userpi" data-field="x_lastupdated" data-format="10" name="x_lastupdated" id="x_lastupdated" placeholder="<?php echo HtmlEncode($userpi_add->lastupdated->getPlaceHolder()) ?>" value="<?php echo $userpi_add->lastupdated->EditValue ?>"<?php echo $userpi_add->lastupdated->editAttributes() ?>>
</span>
<?php echo $userpi_add->lastupdated->CustomMsg ?></div></div>
	</div>
<?php } ?>
<?php if ($userpi_add->piid->Visible) { // piid ?>
	<div id="r_piid" class="form-group row">
		<label id="elh_userpi_piid" for="x_piid" class="<?php echo $userpi_add->LeftColumnClass ?>"><?php echo $userpi_add->piid->caption() ?><?php echo $userpi_add->piid->Required ? $Language->phrase("FieldRequiredIndicator") : "" ?></label>
		<div class="<?php echo $userpi_add->RightColumnClass ?>"><div <?php echo $userpi_add->piid->cellAttributes() ?>>
<span id="el_userpi_piid">
<div class="input-group">
	<select class="custom-select ew-custom-select" data-table="userpi" data-field="x_piid" data-value-separator="<?php echo $userpi_add->piid->displayValueSeparatorAttribute() ?>" id="x_piid" name="x_piid"<?php echo $userpi_add->piid->editAttributes() ?>>
			<?php echo $userpi_add->piid->selectOptionListHtml("x_piid") ?>
		</select>
</div>
<?php echo $userpi_add->piid->Lookup->getParamTag($userpi_add, "p_x_piid") ?>
</span>
<?php echo $userpi_add->piid->CustomMsg ?></div></div>
	</div>
<?php } ?>
<?php if ($userpi_add->deleted->Visible) { // deleted ?>
	<div id="r_deleted" class="form-group row">
		<label id="elh_userpi_deleted" for="x_deleted" class="<?php echo $userpi_add->LeftColumnClass ?>"><?php echo $userpi_add->deleted->caption() ?><?php echo $userpi_add->deleted->Required ? $Language->phrase("FieldRequiredIndicator") : "" ?></label>
		<div class="<?php echo $userpi_add->RightColumnClass ?>"><div <?php echo $userpi_add->deleted->cellAttributes() ?>>
<span id="el_userpi_deleted">
<div class="input-group">
	<select class="custom-select ew-custom-select" data-table="userpi" data-field="x_deleted" data-value-separator="<?php echo $userpi_add->deleted->displayValueSeparatorAttribute() ?>" id="x_deleted" name="x_deleted"<?php echo $userpi_add->deleted->editAttributes() ?>>
			<?php echo $userpi_add->deleted->selectOptionListHtml("x_deleted") ?>
		</select>
</div>
</span>
<?php echo $userpi_add->deleted->CustomMsg ?></div></div>
	</div>
<?php } ?>
<?php if ($userpi_add->currcode->Visible) { // currcode ?>
	<div id="r_currcode" class="form-group row">
		<label id="elh_userpi_currcode" for="x_currcode" class="<?php echo $userpi_add->LeftColumnClass ?>"><?php echo $userpi_add->currcode->caption() ?><?php echo $userpi_add->currcode->Required ? $Language->phrase("FieldRequiredIndicator") : "" ?></label>
		<div class="<?php echo $userpi_add->RightColumnClass ?>"><div <?php echo $userpi_add->currcode->cellAttributes() ?>>
<span id="el_userpi_currcode">
<div class="input-group">
	<select class="custom-select ew-custom-select" data-table="userpi" data-field="x_currcode" data-value-separator="<?php echo $userpi_add->currcode->displayValueSeparatorAttribute() ?>" id="x_currcode" name="x_currcode"<?php echo $userpi_add->currcode->editAttributes() ?>>
			<?php echo $userpi_add->currcode->selectOptionListHtml("x_currcode") ?>
		</select>
</div>
<?php echo $userpi_add->currcode->Lookup->getParamTag($userpi_add, "p_x_currcode") ?>
</span>
<?php echo $userpi_add->currcode->CustomMsg ?></div></div>
	</div>
<?php } ?>
<?php if ($userpi_add->friendlyname->Visible) { // friendlyname ?>
	<div id="r_friendlyname" class="form-group row">
		<label id="elh_userpi_friendlyname" for="x_friendlyname" class="<?php echo $userpi_add->LeftColumnClass ?>"><?php echo $userpi_add->friendlyname->caption() ?><?php echo $userpi_add->friendlyname->Required ? $Language->phrase("FieldRequiredIndicator") : "" ?></label>
		<div class="<?php echo $userpi_add->RightColumnClass ?>"><div <?php echo $userpi_add->friendlyname->cellAttributes() ?>>
<span id="el_userpi_friendlyname">
<input type="text" data-table="userpi" data-field="x_friendlyname" name="x_friendlyname" id="x_friendlyname" size="30" maxlength="20" placeholder="<?php echo HtmlEncode($userpi_add->friendlyname->getPlaceHolder()) ?>" value="<?php echo $userpi_add->friendlyname->EditValue ?>"<?php echo $userpi_add->friendlyname->editAttributes() ?>>
</span>
<?php echo $userpi_add->friendlyname->CustomMsg ?></div></div>
	</div>
<?php } ?>
<?php if ($userpi_add->verified->Visible) { // verified ?>
	<div id="r_verified" class="form-group row">
		<label id="elh_userpi_verified" class="<?php echo $userpi_add->LeftColumnClass ?>"><?php echo $userpi_add->verified->caption() ?><?php echo $userpi_add->verified->Required ? $Language->phrase("FieldRequiredIndicator") : "" ?></label>
		<div class="<?php echo $userpi_add->RightColumnClass ?>"><div <?php echo $userpi_add->verified->cellAttributes() ?>>
<span id="el_userpi_verified">
<div id="tp_x_verified" class="ew-template"><input type="radio" class="custom-control-input" data-table="userpi" data-field="x_verified" data-value-separator="<?php echo $userpi_add->verified->displayValueSeparatorAttribute() ?>" name="x_verified" id="x_verified" value="{value}"<?php echo $userpi_add->verified->editAttributes() ?>></div>
<div id="dsl_x_verified" data-repeatcolumn="5" class="ew-item-list d-none"><div>
<?php echo $userpi_add->verified->radioButtonListHtml(FALSE, "x_verified") ?>
</div></div>
<?php echo $userpi_add->verified->Lookup->getParamTag($userpi_add, "p_x_verified") ?>
</span>
<?php echo $userpi_add->verified->CustomMsg ?></div></div>
	</div>
<?php } ?>
<?php if ($userpi_add->addeddatetime->Visible) { // addeddatetime ?>
	<div id="r_addeddatetime" class="form-group row">
		<label id="elh_userpi_addeddatetime" for="x_addeddatetime" class="<?php echo $userpi_add->LeftColumnClass ?>"><?php echo $userpi_add->addeddatetime->caption() ?><?php echo $userpi_add->addeddatetime->Required ? $Language->phrase("FieldRequiredIndicator") : "" ?></label>
		<div class="<?php echo $userpi_add->RightColumnClass ?>"><div <?php echo $userpi_add->addeddatetime->cellAttributes() ?>>
<span id="el_userpi_addeddatetime">
<input type="text" data-table="userpi" data-field="x_addeddatetime" name="x_addeddatetime" id="x_addeddatetime" maxlength="19" placeholder="<?php echo HtmlEncode($userpi_add->addeddatetime->getPlaceHolder()) ?>" value="<?php echo $userpi_add->addeddatetime->EditValue ?>"<?php echo $userpi_add->addeddatetime->editAttributes() ?>>
<?php if (!$userpi_add->addeddatetime->ReadOnly && !$userpi_add->addeddatetime->Disabled && !isset($userpi_add->addeddatetime->EditAttrs["readonly"]) && !isset($userpi_add->addeddatetime->EditAttrs["disabled"])) { ?>
<script>
loadjs.ready(["fuserpiadd", "datetimepicker"], function() {
	ew.createDateTimePicker("fuserpiadd", "x_addeddatetime", {"ignoreReadonly":true,"useCurrent":false,"format":0});
});
</script>
<?php } ?>
</span>
<?php echo $userpi_add->addeddatetime->CustomMsg ?></div></div>
	</div>
<?php } ?>
<?php if ($userpi_add->piexpirytime->Visible) { // piexpirytime ?>
	<div id="r_piexpirytime" class="form-group row">
		<label id="elh_userpi_piexpirytime" for="x_piexpirytime" class="<?php echo $userpi_add->LeftColumnClass ?>"><?php echo $userpi_add->piexpirytime->caption() ?><?php echo $userpi_add->piexpirytime->Required ? $Language->phrase("FieldRequiredIndicator") : "" ?></label>
		<div class="<?php echo $userpi_add->RightColumnClass ?>"><div <?php echo $userpi_add->piexpirytime->cellAttributes() ?>>
<span id="el_userpi_piexpirytime">
<input type="text" data-table="userpi" data-field="x_piexpirytime" data-format="1" name="x_piexpirytime" id="x_piexpirytime" maxlength="19" placeholder="<?php echo HtmlEncode($userpi_add->piexpirytime->getPlaceHolder()) ?>" value="<?php echo $userpi_add->piexpirytime->EditValue ?>"<?php echo $userpi_add->piexpirytime->editAttributes() ?>>
<?php if (!$userpi_add->piexpirytime->ReadOnly && !$userpi_add->piexpirytime->Disabled && !isset($userpi_add->piexpirytime->EditAttrs["readonly"]) && !isset($userpi_add->piexpirytime->EditAttrs["disabled"])) { ?>
<script>
loadjs.ready(["fuserpiadd", "datetimepicker"], function() {
	ew.createDateTimePicker("fuserpiadd", "x_piexpirytime", {"ignoreReadonly":true,"useCurrent":false,"format":1});
});
</script>
<?php } ?>
</span>
<?php echo $userpi_add->piexpirytime->CustomMsg ?></div></div>
	</div>
<?php } ?>
<?php if ($userpi_add->verifiedtime->Visible) { // verifiedtime ?>
	<div id="r_verifiedtime" class="form-group row">
		<label id="elh_userpi_verifiedtime" for="x_verifiedtime" class="<?php echo $userpi_add->LeftColumnClass ?>"><?php echo $userpi_add->verifiedtime->caption() ?><?php echo $userpi_add->verifiedtime->Required ? $Language->phrase("FieldRequiredIndicator") : "" ?></label>
		<div class="<?php echo $userpi_add->RightColumnClass ?>"><div <?php echo $userpi_add->verifiedtime->cellAttributes() ?>>
<span id="el_userpi_verifiedtime">
<input type="text" data-table="userpi" data-field="x_verifiedtime" data-format="1" name="x_verifiedtime" id="x_verifiedtime" placeholder="<?php echo HtmlEncode($userpi_add->verifiedtime->getPlaceHolder()) ?>" value="<?php echo $userpi_add->verifiedtime->EditValue ?>"<?php echo $userpi_add->verifiedtime->editAttributes() ?>>
<?php if (!$userpi_add->verifiedtime->ReadOnly && !$userpi_add->verifiedtime->Disabled && !isset($userpi_add->verifiedtime->EditAttrs["readonly"]) && !isset($userpi_add->verifiedtime->EditAttrs["disabled"])) { ?>
<script>
loadjs.ready(["fuserpiadd", "datetimepicker"], function() {
	ew.createDateTimePicker("fuserpiadd", "x_verifiedtime", {"ignoreReadonly":true,"useCurrent":false,"format":1});
});
</script>
<?php } ?>
</span>
<?php echo $userpi_add->verifiedtime->CustomMsg ?></div></div>
	</div>
<?php } ?>
<?php if ($userpi_add->vaultid->Visible) { // vaultid ?>
	<div id="r_vaultid" class="form-group row">
		<label id="elh_userpi_vaultid" for="x_vaultid" class="<?php echo $userpi_add->LeftColumnClass ?>"><?php echo $userpi_add->vaultid->caption() ?><?php echo $userpi_add->vaultid->Required ? $Language->phrase("FieldRequiredIndicator") : "" ?></label>
		<div class="<?php echo $userpi_add->RightColumnClass ?>"><div <?php echo $userpi_add->vaultid->cellAttributes() ?>>
<span id="el_userpi_vaultid">
<div class="input-group">
	<select class="custom-select ew-custom-select" data-table="userpi" data-field="x_vaultid" data-value-separator="<?php echo $userpi_add->vaultid->displayValueSeparatorAttribute() ?>" id="x_vaultid" name="x_vaultid"<?php echo $userpi_add->vaultid->editAttributes() ?>>
			<?php echo $userpi_add->vaultid->selectOptionListHtml("x_vaultid") ?>
		</select>
</div>
<?php echo $userpi_add->vaultid->Lookup->getParamTag($userpi_add, "p_x_vaultid") ?>
</span>
<?php echo $userpi_add->vaultid->CustomMsg ?></div></div>
	</div>
<?php } ?>
<?php if ($userpi_add->defaultpi->Visible) { // defaultpi ?>
	<div id="r_defaultpi" class="form-group row">
		<label id="elh_userpi_defaultpi" class="<?php echo $userpi_add->LeftColumnClass ?>"><?php echo $userpi_add->defaultpi->caption() ?><?php echo $userpi_add->defaultpi->Required ? $Language->phrase("FieldRequiredIndicator") : "" ?></label>
		<div class="<?php echo $userpi_add->RightColumnClass ?>"><div <?php echo $userpi_add->defaultpi->cellAttributes() ?>>
<span id="el_userpi_defaultpi">
<div id="tp_x_defaultpi" class="ew-template"><input type="radio" class="custom-control-input" data-table="userpi" data-field="x_defaultpi" data-value-separator="<?php echo $userpi_add->defaultpi->displayValueSeparatorAttribute() ?>" name="x_defaultpi" id="x_defaultpi" value="{value}"<?php echo $userpi_add->defaultpi->editAttributes() ?>></div>
<div id="dsl_x_defaultpi" data-repeatcolumn="5" class="ew-item-list d-none"><div>
<?php echo $userpi_add->defaultpi->radioButtonListHtml(FALSE, "x_defaultpi") ?>
</div></div>
<?php echo $userpi_add->defaultpi->Lookup->getParamTag($userpi_add, "p_x_defaultpi") ?>
</span>
<?php echo $userpi_add->defaultpi->CustomMsg ?></div></div>
	</div>
<?php } ?>
<?php if ($userpi_add->acctID->Visible) { // acctID ?>
	<div id="r_acctID" class="form-group row">
		<label id="elh_userpi_acctID" for="x_acctID" class="<?php echo $userpi_add->LeftColumnClass ?>"><?php echo $userpi_add->acctID->caption() ?><?php echo $userpi_add->acctID->Required ? $Language->phrase("FieldRequiredIndicator") : "" ?></label>
		<div class="<?php echo $userpi_add->RightColumnClass ?>"><div <?php echo $userpi_add->acctID->cellAttributes() ?>>
<span id="el_userpi_acctID">
<input type="text" data-table="userpi" data-field="x_acctID" name="x_acctID" id="x_acctID" size="30" maxlength="12" placeholder="<?php echo HtmlEncode($userpi_add->acctID->getPlaceHolder()) ?>" value="<?php echo $userpi_add->acctID->EditValue ?>"<?php echo $userpi_add->acctID->editAttributes() ?>>
</span>
<?php echo $userpi_add->acctID->CustomMsg ?></div></div>
	</div>
<?php } ?>
<?php if ($userpi_add->addedbyuserid->Visible) { // addedbyuserid ?>
	<div id="r_addedbyuserid" class="form-group row">
		<label id="elh_userpi_addedbyuserid" for="x_addedbyuserid" class="<?php echo $userpi_add->LeftColumnClass ?>"><?php echo $userpi_add->addedbyuserid->caption() ?><?php echo $userpi_add->addedbyuserid->Required ? $Language->phrase("FieldRequiredIndicator") : "" ?></label>
		<div class="<?php echo $userpi_add->RightColumnClass ?>"><div <?php echo $userpi_add->addedbyuserid->cellAttributes() ?>>
<span id="el_userpi_addedbyuserid">
<input type="text" data-table="userpi" data-field="x_addedbyuserid" name="x_addedbyuserid" id="x_addedbyuserid" size="30" maxlength="12" placeholder="<?php echo HtmlEncode($userpi_add->addedbyuserid->getPlaceHolder()) ?>" value="<?php echo $userpi_add->addedbyuserid->EditValue ?>"<?php echo $userpi_add->addedbyuserid->editAttributes() ?>>
</span>
<?php echo $userpi_add->addedbyuserid->CustomMsg ?></div></div>
	</div>
<?php } ?>
<?php if ($userpi_add->pendingtransfer->Visible) { // pendingtransfer ?>
	<div id="r_pendingtransfer" class="form-group row">
		<label id="elh_userpi_pendingtransfer" for="x_pendingtransfer" class="<?php echo $userpi_add->LeftColumnClass ?>"><?php echo $userpi_add->pendingtransfer->caption() ?><?php echo $userpi_add->pendingtransfer->Required ? $Language->phrase("FieldRequiredIndicator") : "" ?></label>
		<div class="<?php echo $userpi_add->RightColumnClass ?>"><div <?php echo $userpi_add->pendingtransfer->cellAttributes() ?>>
<span id="el_userpi_pendingtransfer">
<div class="input-group">
	<select class="custom-select ew-custom-select" data-table="userpi" data-field="x_pendingtransfer" data-value-separator="<?php echo $userpi_add->pendingtransfer->displayValueSeparatorAttribute() ?>" id="x_pendingtransfer" name="x_pendingtransfer"<?php echo $userpi_add->pendingtransfer->editAttributes() ?>>
			<?php echo $userpi_add->pendingtransfer->selectOptionListHtml("x_pendingtransfer") ?>
		</select>
</div>
<?php echo $userpi_add->pendingtransfer->Lookup->getParamTag($userpi_add, "p_x_pendingtransfer") ?>
</span>
<?php echo $userpi_add->pendingtransfer->CustomMsg ?></div></div>
	</div>
<?php } ?>
<?php if ($userpi_add->purchaseid->Visible) { // purchaseid ?>
	<div id="r_purchaseid" class="form-group row">
		<label id="elh_userpi_purchaseid" for="x_purchaseid" class="<?php echo $userpi_add->LeftColumnClass ?>"><?php echo $userpi_add->purchaseid->caption() ?><?php echo $userpi_add->purchaseid->Required ? $Language->phrase("FieldRequiredIndicator") : "" ?></label>
		<div class="<?php echo $userpi_add->RightColumnClass ?>"><div <?php echo $userpi_add->purchaseid->cellAttributes() ?>>
<span id="el_userpi_purchaseid">
<input type="text" data-table="userpi" data-field="x_purchaseid" name="x_purchaseid" id="x_purchaseid" size="30" maxlength="12" placeholder="<?php echo HtmlEncode($userpi_add->purchaseid->getPlaceHolder()) ?>" value="<?php echo $userpi_add->purchaseid->EditValue ?>"<?php echo $userpi_add->purchaseid->editAttributes() ?>>
</span>
<?php echo $userpi_add->purchaseid->CustomMsg ?></div></div>
	</div>
<?php } ?>
<?php if ($userpi_add->paymentid->Visible) { // paymentid ?>
	<div id="r_paymentid" class="form-group row">
		<label id="elh_userpi_paymentid" for="x_paymentid" class="<?php echo $userpi_add->LeftColumnClass ?>"><?php echo $userpi_add->paymentid->caption() ?><?php echo $userpi_add->paymentid->Required ? $Language->phrase("FieldRequiredIndicator") : "" ?></label>
		<div class="<?php echo $userpi_add->RightColumnClass ?>"><div <?php echo $userpi_add->paymentid->cellAttributes() ?>>
<span id="el_userpi_paymentid">
<input type="text" data-table="userpi" data-field="x_paymentid" name="x_paymentid" id="x_paymentid" size="30" maxlength="12" placeholder="<?php echo HtmlEncode($userpi_add->paymentid->getPlaceHolder()) ?>" value="<?php echo $userpi_add->paymentid->EditValue ?>"<?php echo $userpi_add->paymentid->editAttributes() ?>>
</span>
<?php echo $userpi_add->paymentid->CustomMsg ?></div></div>
	</div>
<?php } ?>
<?php if ($userpi_add->others->Visible) { // others ?>
	<div id="r_others" class="form-group row">
		<label id="elh_userpi_others" for="x_others" class="<?php echo $userpi_add->LeftColumnClass ?>"><?php echo $userpi_add->others->caption() ?><?php echo $userpi_add->others->Required ? $Language->phrase("FieldRequiredIndicator") : "" ?></label>
		<div class="<?php echo $userpi_add->RightColumnClass ?>"><div <?php echo $userpi_add->others->cellAttributes() ?>>
<span id="el_userpi_others">
<textarea data-table="userpi" data-field="x_others" name="x_others" id="x_others" cols="35" rows="4" placeholder="<?php echo HtmlEncode($userpi_add->others->getPlaceHolder()) ?>"<?php echo $userpi_add->others->editAttributes() ?>><?php echo $userpi_add->others->EditValue ?></textarea>
</span>
<?php echo $userpi_add->others->CustomMsg ?></div></div>
	</div>
<?php } ?>
<?php if ($userpi_add->others2->Visible) { // others2 ?>
	<div id="r_others2" class="form-group row">
		<label id="elh_userpi_others2" for="x_others2" class="<?php echo $userpi_add->LeftColumnClass ?>"><?php echo $userpi_add->others2->caption() ?><?php echo $userpi_add->others2->Required ? $Language->phrase("FieldRequiredIndicator") : "" ?></label>
		<div class="<?php echo $userpi_add->RightColumnClass ?>"><div <?php echo $userpi_add->others2->cellAttributes() ?>>
<span id="el_userpi_others2">
<textarea data-table="userpi" data-field="x_others2" name="x_others2" id="x_others2" cols="35" rows="4" placeholder="<?php echo HtmlEncode($userpi_add->others2->getPlaceHolder()) ?>"<?php echo $userpi_add->others2->editAttributes() ?>><?php echo $userpi_add->others2->EditValue ?></textarea>
</span>
<?php echo $userpi_add->others2->CustomMsg ?></div></div>
	</div>
<?php } ?>
<?php if ($userpi_add->pinhash->Visible) { // pinhash ?>
	<div id="r_pinhash" class="form-group row">
		<label id="elh_userpi_pinhash" for="x_pinhash" class="<?php echo $userpi_add->LeftColumnClass ?>"><?php echo $userpi_add->pinhash->caption() ?><?php echo $userpi_add->pinhash->Required ? $Language->phrase("FieldRequiredIndicator") : "" ?></label>
		<div class="<?php echo $userpi_add->RightColumnClass ?>"><div <?php echo $userpi_add->pinhash->cellAttributes() ?>>
<span id="el_userpi_pinhash">
<div class="input-group"><input type="password" name="x_pinhash" id="x_pinhash" autocomplete="new-password" data-field="x_pinhash" size="30" maxlength="200" placeholder="<?php echo HtmlEncode($userpi_add->pinhash->getPlaceHolder()) ?>"<?php echo $userpi_add->pinhash->editAttributes() ?>><div class="input-group-append"><button type="button" class="btn btn-default ew-toggle-password" onclick="ew.togglePassword(event);"><i class="fas fa-eye"></i></button></div></div>
</span>
<?php echo $userpi_add->pinhash->CustomMsg ?></div></div>
	</div>
<?php } ?>
<?php if ($userpi_add->pinexpiry->Visible) { // pinexpiry ?>
	<div id="r_pinexpiry" class="form-group row">
		<label id="elh_userpi_pinexpiry" for="x_pinexpiry" class="<?php echo $userpi_add->LeftColumnClass ?>"><?php echo $userpi_add->pinexpiry->caption() ?><?php echo $userpi_add->pinexpiry->Required ? $Language->phrase("FieldRequiredIndicator") : "" ?></label>
		<div class="<?php echo $userpi_add->RightColumnClass ?>"><div <?php echo $userpi_add->pinexpiry->cellAttributes() ?>>
<span id="el_userpi_pinexpiry">
<input type="text" data-table="userpi" data-field="x_pinexpiry" name="x_pinexpiry" id="x_pinexpiry" maxlength="10" placeholder="<?php echo HtmlEncode($userpi_add->pinexpiry->getPlaceHolder()) ?>" value="<?php echo $userpi_add->pinexpiry->EditValue ?>"<?php echo $userpi_add->pinexpiry->editAttributes() ?>>
<?php if (!$userpi_add->pinexpiry->ReadOnly && !$userpi_add->pinexpiry->Disabled && !isset($userpi_add->pinexpiry->EditAttrs["readonly"]) && !isset($userpi_add->pinexpiry->EditAttrs["disabled"])) { ?>
<script>
loadjs.ready(["fuserpiadd", "datetimepicker"], function() {
	ew.createDateTimePicker("fuserpiadd", "x_pinexpiry", {"ignoreReadonly":true,"useCurrent":false,"format":0});
});
</script>
<?php } ?>
</span>
<?php echo $userpi_add->pinexpiry->CustomMsg ?></div></div>
	</div>
<?php } ?>
<?php if ($userpi_add->deletiontime->Visible) { // deletiontime ?>
	<div id="r_deletiontime" class="form-group row">
		<label id="elh_userpi_deletiontime" for="x_deletiontime" class="<?php echo $userpi_add->LeftColumnClass ?>"><?php echo $userpi_add->deletiontime->caption() ?><?php echo $userpi_add->deletiontime->Required ? $Language->phrase("FieldRequiredIndicator") : "" ?></label>
		<div class="<?php echo $userpi_add->RightColumnClass ?>"><div <?php echo $userpi_add->deletiontime->cellAttributes() ?>>
<span id="el_userpi_deletiontime">
<input type="text" data-table="userpi" data-field="x_deletiontime" data-format="2" name="x_deletiontime" id="x_deletiontime" maxlength="19" placeholder="<?php echo HtmlEncode($userpi_add->deletiontime->getPlaceHolder()) ?>" value="<?php echo $userpi_add->deletiontime->EditValue ?>"<?php echo $userpi_add->deletiontime->editAttributes() ?>>
<?php if (!$userpi_add->deletiontime->ReadOnly && !$userpi_add->deletiontime->Disabled && !isset($userpi_add->deletiontime->EditAttrs["readonly"]) && !isset($userpi_add->deletiontime->EditAttrs["disabled"])) { ?>
<script>
loadjs.ready(["fuserpiadd", "datetimepicker"], function() {
	ew.createDateTimePicker("fuserpiadd", "x_deletiontime", {"ignoreReadonly":true,"useCurrent":false,"format":2});
});
</script>
<?php } ?>
</span>
<?php echo $userpi_add->deletiontime->CustomMsg ?></div></div>
	</div>
<?php } ?>
<?php if ($userpi_add->servicefeeexempted->Visible) { // servicefeeexempted ?>
	<div id="r_servicefeeexempted" class="form-group row">
		<label id="elh_userpi_servicefeeexempted" for="x_servicefeeexempted" class="<?php echo $userpi_add->LeftColumnClass ?>"><?php echo $userpi_add->servicefeeexempted->caption() ?><?php echo $userpi_add->servicefeeexempted->Required ? $Language->phrase("FieldRequiredIndicator") : "" ?></label>
		<div class="<?php echo $userpi_add->RightColumnClass ?>"><div <?php echo $userpi_add->servicefeeexempted->cellAttributes() ?>>
<span id="el_userpi_servicefeeexempted">
<div class="input-group">
	<select class="custom-select ew-custom-select" data-table="userpi" data-field="x_servicefeeexempted" data-value-separator="<?php echo $userpi_add->servicefeeexempted->displayValueSeparatorAttribute() ?>" id="x_servicefeeexempted" name="x_servicefeeexempted"<?php echo $userpi_add->servicefeeexempted->editAttributes() ?>>
			<?php echo $userpi_add->servicefeeexempted->selectOptionListHtml("x_servicefeeexempted") ?>
		</select>
</div>
<?php echo $userpi_add->servicefeeexempted->Lookup->getParamTag($userpi_add, "p_x_servicefeeexempted") ?>
</span>
<?php echo $userpi_add->servicefeeexempted->CustomMsg ?></div></div>
	</div>
<?php } ?>
<?php if ($userpi_add->purposeofaccount->Visible) { // purposeofaccount ?>
	<div id="r_purposeofaccount" class="form-group row">
		<label id="elh_userpi_purposeofaccount" for="x_purposeofaccount" class="<?php echo $userpi_add->LeftColumnClass ?>"><?php echo $userpi_add->purposeofaccount->caption() ?><?php echo $userpi_add->purposeofaccount->Required ? $Language->phrase("FieldRequiredIndicator") : "" ?></label>
		<div class="<?php echo $userpi_add->RightColumnClass ?>"><div <?php echo $userpi_add->purposeofaccount->cellAttributes() ?>>
<span id="el_userpi_purposeofaccount">
<div class="input-group">
	<select class="custom-select ew-custom-select" data-table="userpi" data-field="x_purposeofaccount" data-value-separator="<?php echo $userpi_add->purposeofaccount->displayValueSeparatorAttribute() ?>" id="x_purposeofaccount" name="x_purposeofaccount"<?php echo $userpi_add->purposeofaccount->editAttributes() ?>>
			<?php echo $userpi_add->purposeofaccount->selectOptionListHtml("x_purposeofaccount") ?>
		</select>
</div>
<?php echo $userpi_add->purposeofaccount->Lookup->getParamTag($userpi_add, "p_x_purposeofaccount") ?>
</span>
<?php echo $userpi_add->purposeofaccount->CustomMsg ?></div></div>
	</div>
<?php } ?>
<?php if ($userpi_add->extendedfields->Visible) { // extendedfields ?>
	<div id="r_extendedfields" class="form-group row">
		<label id="elh_userpi_extendedfields" for="x_extendedfields" class="<?php echo $userpi_add->LeftColumnClass ?>"><?php echo $userpi_add->extendedfields->caption() ?><?php echo $userpi_add->extendedfields->Required ? $Language->phrase("FieldRequiredIndicator") : "" ?></label>
		<div class="<?php echo $userpi_add->RightColumnClass ?>"><div <?php echo $userpi_add->extendedfields->cellAttributes() ?>>
<span id="el_userpi_extendedfields">
<textarea data-table="userpi" data-field="x_extendedfields" name="x_extendedfields" id="x_extendedfields" cols="35" rows="4" placeholder="<?php echo HtmlEncode($userpi_add->extendedfields->getPlaceHolder()) ?>"<?php echo $userpi_add->extendedfields->editAttributes() ?>><?php echo $userpi_add->extendedfields->EditValue ?></textarea>
</span>
<?php echo $userpi_add->extendedfields->CustomMsg ?></div></div>
	</div>
<?php } ?>
</div><!-- /page* -->
<?php
	if (in_array("feehistory", explode(",", $userpi->getCurrentDetailTable())) && $feehistory->DetailAdd) {
?>
<?php if ($userpi->getCurrentDetailTable() != "") { ?>
<h4 class="ew-detail-caption"><?php echo $Language->tablePhrase("feehistory", "TblCaption") ?></h4>
<?php } ?>
<?php include_once "feehistorygrid.php" ?>
<?php } ?>
<?php
	if (in_array("useritem", explode(",", $userpi->getCurrentDetailTable())) && $useritem->DetailAdd) {
?>
<?php if ($userpi->getCurrentDetailTable() != "") { ?>
<h4 class="ew-detail-caption"><?php echo $Language->tablePhrase("useritem", "TblCaption") ?></h4>
<?php } ?>
<?php include_once "useritemgrid.php" ?>
<?php } ?>
<?php if (!$userpi_add->IsModal) { ?>
<div class="form-group row"><!-- buttons .form-group -->
	<div class="<?php echo $userpi_add->OffsetColumnClass ?>"><!-- buttons offset -->
<button class="btn btn-primary ew-btn" name="btn-action" id="btn-action" type="submit"><?php echo $Language->phrase("AddBtn") ?></button>
<button class="btn btn-default ew-btn" name="btn-cancel" id="btn-cancel" type="button" data-href="<?php echo $userpi_add->getReturnUrl() ?>"><?php echo $Language->phrase("CancelBtn") ?></button>
	</div><!-- /buttons offset -->
</div><!-- /buttons .form-group -->
<?php } ?>
</form>
<?php
$userpi_add->showPageFooter();
if (Config("DEBUG"))
	echo GetDebugMessage();
?>
<script>
loadjs.ready("load", function() {

	// Startup script
	// Write your table-specific startup script here
	// console.log("page loaded");

});
</script>
<?php include_once "footer.php"; ?>
<?php
$userpi_add->terminate();
?>