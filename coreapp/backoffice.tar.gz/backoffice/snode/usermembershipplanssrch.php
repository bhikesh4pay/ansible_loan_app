<?php
namespace PHPMaker2020\_4payadmin;

// Autoload
include_once "autoload.php";

// Session
if (session_status() !== PHP_SESSION_ACTIVE)
	\Delight\Cookie\Session::start(Config("COOKIE_SAMESITE")); // Init session data

// Output buffering
ob_start();
?>
<?php

// Write header
WriteHeader(FALSE);

// Create page object
$usermembershipplans_search = new usermembershipplans_search();

// Run the page
$usermembershipplans_search->run();

// Setup login status
SetupLoginStatus();
SetClientVar("login", LoginStatus());

// Global Page Rendering event (in userfn*.php)
Page_Rendering();

// Page Rendering event
$usermembershipplans_search->Page_Render();
?>
<?php include_once "header.php"; ?>
<script>
var fusermembershipplanssearch, currentPageID;
loadjs.ready("head", function() {

	// Form object for search
	<?php if ($usermembershipplans_search->IsModal) { ?>
	fusermembershipplanssearch = currentAdvancedSearchForm = new ew.Form("fusermembershipplanssearch", "search");
	<?php } else { ?>
	fusermembershipplanssearch = currentForm = new ew.Form("fusermembershipplanssearch", "search");
	<?php } ?>
	currentPageID = ew.PAGE_ID = "search";

	// Validate function for search
	fusermembershipplanssearch.validate = function(fobj) {
		if (!this.validateRequired)
			return true; // Ignore validation
		fobj = fobj || this._form;
		var infix = "";
		elm = this.getElements("x" + infix + "_memberid");
		if (elm && !ew.checkInteger(elm.value))
			return this.onError(elm, "<?php echo JsEncode($usermembershipplans_search->memberid->errorMessage()) ?>");
		elm = this.getElements("x" + infix + "_merchantid");
		if (elm && !ew.checkInteger(elm.value))
			return this.onError(elm, "<?php echo JsEncode($usermembershipplans_search->merchantid->errorMessage()) ?>");
		elm = this.getElements("x" + infix + "_planid");
		if (elm && !ew.checkInteger(elm.value))
			return this.onError(elm, "<?php echo JsEncode($usermembershipplans_search->planid->errorMessage()) ?>");
		elm = this.getElements("x" + infix + "_planstatus");
		if (elm && !ew.checkInteger(elm.value))
			return this.onError(elm, "<?php echo JsEncode($usermembershipplans_search->planstatus->errorMessage()) ?>");

		// Call Form_CustomValidate event
		if (!this.Form_CustomValidate(fobj))
			return false;
		return true;
	}

	// Form_CustomValidate
	fusermembershipplanssearch.Form_CustomValidate = function(fobj) { // DO NOT CHANGE THIS LINE!

		// Your custom validation code here, return false if invalid.
		return true;
	}

	// Use JavaScript validation or not
	fusermembershipplanssearch.validateRequired = <?php echo Config("CLIENT_VALIDATE") ? "true" : "false" ?>;

	// Dynamic selection lists
	loadjs.done("fusermembershipplanssearch");
});
</script>
<script>
loadjs.ready("head", function() {

	// Client script
	// Write your client script here, no need to add script tags.

});
</script>
<?php $usermembershipplans_search->showPageHeader(); ?>
<?php
$usermembershipplans_search->showMessage();
?>
<form name="fusermembershipplanssearch" id="fusermembershipplanssearch" class="<?php echo $usermembershipplans_search->FormClassName ?>" action="<?php echo CurrentPageName() ?>" method="post">
<?php if ($Page->CheckToken) { ?>
<input type="hidden" name="<?php echo Config("TOKEN_NAME") ?>" value="<?php echo $Page->Token ?>">
<?php } ?>
<input type="hidden" name="t" value="usermembershipplans">
<input type="hidden" name="action" id="action" value="search">
<input type="hidden" name="modal" value="<?php echo (int)$usermembershipplans_search->IsModal ?>">
<div class="ew-search-div"><!-- page* -->
<?php if ($usermembershipplans_search->memberid->Visible) { // memberid ?>
	<div id="r_memberid" class="form-group row">
		<label for="x_memberid" class="<?php echo $usermembershipplans_search->LeftColumnClass ?>"><span id="elh_usermembershipplans_memberid"><?php echo $usermembershipplans_search->memberid->caption() ?></span>
		<span class="ew-search-operator">
<?php echo $Language->phrase("=") ?>
<input type="hidden" name="z_memberid" id="z_memberid" value="=">
</span>
		</label>
		<div class="<?php echo $usermembershipplans_search->RightColumnClass ?>"><div <?php echo $usermembershipplans_search->memberid->cellAttributes() ?>>
			<span id="el_usermembershipplans_memberid" class="ew-search-field">
<input type="text" data-table="usermembershipplans" data-field="x_memberid" name="x_memberid" id="x_memberid" size="30" placeholder="<?php echo HtmlEncode($usermembershipplans_search->memberid->getPlaceHolder()) ?>" value="<?php echo $usermembershipplans_search->memberid->EditValue ?>"<?php echo $usermembershipplans_search->memberid->editAttributes() ?>>
</span>
		</div></div>
	</div>
<?php } ?>
<?php if ($usermembershipplans_search->merchantid->Visible) { // merchantid ?>
	<div id="r_merchantid" class="form-group row">
		<label for="x_merchantid" class="<?php echo $usermembershipplans_search->LeftColumnClass ?>"><span id="elh_usermembershipplans_merchantid"><?php echo $usermembershipplans_search->merchantid->caption() ?></span>
		<span class="ew-search-operator">
<?php echo $Language->phrase("=") ?>
<input type="hidden" name="z_merchantid" id="z_merchantid" value="=">
</span>
		</label>
		<div class="<?php echo $usermembershipplans_search->RightColumnClass ?>"><div <?php echo $usermembershipplans_search->merchantid->cellAttributes() ?>>
			<span id="el_usermembershipplans_merchantid" class="ew-search-field">
<input type="text" data-table="usermembershipplans" data-field="x_merchantid" name="x_merchantid" id="x_merchantid" size="30" placeholder="<?php echo HtmlEncode($usermembershipplans_search->merchantid->getPlaceHolder()) ?>" value="<?php echo $usermembershipplans_search->merchantid->EditValue ?>"<?php echo $usermembershipplans_search->merchantid->editAttributes() ?>>
</span>
		</div></div>
	</div>
<?php } ?>
<?php if ($usermembershipplans_search->planid->Visible) { // planid ?>
	<div id="r_planid" class="form-group row">
		<label for="x_planid" class="<?php echo $usermembershipplans_search->LeftColumnClass ?>"><span id="elh_usermembershipplans_planid"><?php echo $usermembershipplans_search->planid->caption() ?></span>
		<span class="ew-search-operator">
<?php echo $Language->phrase("=") ?>
<input type="hidden" name="z_planid" id="z_planid" value="=">
</span>
		</label>
		<div class="<?php echo $usermembershipplans_search->RightColumnClass ?>"><div <?php echo $usermembershipplans_search->planid->cellAttributes() ?>>
			<span id="el_usermembershipplans_planid" class="ew-search-field">
<input type="text" data-table="usermembershipplans" data-field="x_planid" name="x_planid" id="x_planid" size="30" placeholder="<?php echo HtmlEncode($usermembershipplans_search->planid->getPlaceHolder()) ?>" value="<?php echo $usermembershipplans_search->planid->EditValue ?>"<?php echo $usermembershipplans_search->planid->editAttributes() ?>>
</span>
		</div></div>
	</div>
<?php } ?>
<?php if ($usermembershipplans_search->planstatus->Visible) { // planstatus ?>
	<div id="r_planstatus" class="form-group row">
		<label for="x_planstatus" class="<?php echo $usermembershipplans_search->LeftColumnClass ?>"><span id="elh_usermembershipplans_planstatus"><?php echo $usermembershipplans_search->planstatus->caption() ?></span>
		<span class="ew-search-operator">
<?php echo $Language->phrase("=") ?>
<input type="hidden" name="z_planstatus" id="z_planstatus" value="=">
</span>
		</label>
		<div class="<?php echo $usermembershipplans_search->RightColumnClass ?>"><div <?php echo $usermembershipplans_search->planstatus->cellAttributes() ?>>
			<span id="el_usermembershipplans_planstatus" class="ew-search-field">
<input type="text" data-table="usermembershipplans" data-field="x_planstatus" name="x_planstatus" id="x_planstatus" size="30" placeholder="<?php echo HtmlEncode($usermembershipplans_search->planstatus->getPlaceHolder()) ?>" value="<?php echo $usermembershipplans_search->planstatus->EditValue ?>"<?php echo $usermembershipplans_search->planstatus->editAttributes() ?>>
</span>
		</div></div>
	</div>
<?php } ?>
</div><!-- /page* -->
<?php if (!$usermembershipplans_search->IsModal) { ?>
<div class="form-group row"><!-- buttons .form-group -->
	<div class="<?php echo $usermembershipplans_search->OffsetColumnClass ?>"><!-- buttons offset -->
<button class="btn btn-primary ew-btn" name="btn-action" id="btn-action" type="submit"><?php echo $Language->phrase("Search") ?></button>
<button class="btn btn-default ew-btn" name="btn-reset" id="btn-reset" type="button" onclick="ew.clearForm(this.form);"><?php echo $Language->phrase("Reset") ?></button>
	</div><!-- /buttons offset -->
</div><!-- /buttons .form-group -->
<?php } ?>
</form>
<?php
$usermembershipplans_search->showPageFooter();
if (Config("DEBUG"))
	echo GetDebugMessage();
?>
<script>
loadjs.ready("load", function() {

	// Startup script
	// Write your table-specific startup script here
	// console.log("page loaded");

});
</script>
<?php include_once "footer.php"; ?>
<?php
$usermembershipplans_search->terminate();
?>