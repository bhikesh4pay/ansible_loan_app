<?php
namespace PHPMaker2020\_4payadmin;

// Autoload
include_once "autoload.php";

// Session
if (session_status() !== PHP_SESSION_ACTIVE)
	\Delight\Cookie\Session::start(Config("COOKIE_SAMESITE")); // Init session data

// Output buffering
ob_start();
?>
<?php

// Write header
WriteHeader(FALSE);

// Create page object
$billacclookup_edit = new billacclookup_edit();

// Run the page
$billacclookup_edit->run();

// Setup login status
SetupLoginStatus();
SetClientVar("login", LoginStatus());

// Global Page Rendering event (in userfn*.php)
Page_Rendering();

// Page Rendering event
$billacclookup_edit->Page_Render();
?>
<?php include_once "header.php"; ?>
<script>
var fbillacclookupedit, currentPageID;
loadjs.ready("head", function() {

	// Form object
	currentPageID = ew.PAGE_ID = "edit";
	fbillacclookupedit = currentForm = new ew.Form("fbillacclookupedit", "edit");

	// Validate form
	fbillacclookupedit.validate = function() {
		if (!this.validateRequired)
			return true; // Ignore validation
		var $ = jQuery, fobj = this.getForm(), $fobj = $(fobj);
		if ($fobj.find("#confirm").val() == "confirm")
			return true;
		var elm, felm, uelm, addcnt = 0;
		var $k = $fobj.find("#" + this.formKeyCountName); // Get key_count
		var rowcnt = ($k[0]) ? parseInt($k.val(), 10) : 1;
		var startcnt = (rowcnt == 0) ? 0 : 1; // Check rowcnt == 0 => Inline-Add
		var gridinsert = ["insert", "gridinsert"].includes($fobj.find("#action").val()) && $k[0];
		for (var i = startcnt; i <= rowcnt; i++) {
			var infix = ($k[0]) ? String(i) : "";
			$fobj.data("rowindex", infix);
			<?php if ($billacclookup_edit->recid->Required) { ?>
				elm = this.getElements("x" + infix + "_recid");
				if (elm && !ew.isHidden(elm) && !ew.hasValue(elm))
					return this.onError(elm, "<?php echo JsEncode(str_replace("%s", $billacclookup_edit->recid->caption(), $billacclookup_edit->recid->RequiredErrorMessage)) ?>");
			<?php } ?>
			<?php if ($billacclookup_edit->logtime->Required) { ?>
				elm = this.getElements("x" + infix + "_logtime");
				if (elm && !ew.isHidden(elm) && !ew.hasValue(elm))
					return this.onError(elm, "<?php echo JsEncode(str_replace("%s", $billacclookup_edit->logtime->caption(), $billacclookup_edit->logtime->RequiredErrorMessage)) ?>");
			<?php } ?>
				elm = this.getElements("x" + infix + "_logtime");
				if (elm && !ew.checkDateDef(elm.value))
					return this.onError(elm, "<?php echo JsEncode($billacclookup_edit->logtime->errorMessage()) ?>");
			<?php if ($billacclookup_edit->_userid->Required) { ?>
				elm = this.getElements("x" + infix + "__userid");
				if (elm && !ew.isHidden(elm) && !ew.hasValue(elm))
					return this.onError(elm, "<?php echo JsEncode(str_replace("%s", $billacclookup_edit->_userid->caption(), $billacclookup_edit->_userid->RequiredErrorMessage)) ?>");
			<?php } ?>
				elm = this.getElements("x" + infix + "__userid");
				if (elm && !ew.checkInteger(elm.value))
					return this.onError(elm, "<?php echo JsEncode($billacclookup_edit->_userid->errorMessage()) ?>");
			<?php if ($billacclookup_edit->serviceid->Required) { ?>
				elm = this.getElements("x" + infix + "_serviceid");
				if (elm && !ew.isHidden(elm) && !ew.hasValue(elm))
					return this.onError(elm, "<?php echo JsEncode(str_replace("%s", $billacclookup_edit->serviceid->caption(), $billacclookup_edit->serviceid->RequiredErrorMessage)) ?>");
			<?php } ?>
				elm = this.getElements("x" + infix + "_serviceid");
				if (elm && !ew.checkInteger(elm.value))
					return this.onError(elm, "<?php echo JsEncode($billacclookup_edit->serviceid->errorMessage()) ?>");
			<?php if ($billacclookup_edit->billaccountno->Required) { ?>
				elm = this.getElements("x" + infix + "_billaccountno");
				if (elm && !ew.isHidden(elm) && !ew.hasValue(elm))
					return this.onError(elm, "<?php echo JsEncode(str_replace("%s", $billacclookup_edit->billaccountno->caption(), $billacclookup_edit->billaccountno->RequiredErrorMessage)) ?>");
			<?php } ?>

				// Call Form_CustomValidate event
				if (!this.Form_CustomValidate(fobj))
					return false;
		}

		// Process detail forms
		var dfs = $fobj.find("input[name='detailpage']").get();
		for (var i = 0; i < dfs.length; i++) {
			var df = dfs[i], val = df.value;
			if (val && ew.forms[val])
				if (!ew.forms[val].validate())
					return false;
		}
		return true;
	}

	// Form_CustomValidate
	fbillacclookupedit.Form_CustomValidate = function(fobj) { // DO NOT CHANGE THIS LINE!

		// Your custom validation code here, return false if invalid.
		return true;
	}

	// Use JavaScript validation or not
	fbillacclookupedit.validateRequired = <?php echo Config("CLIENT_VALIDATE") ? "true" : "false" ?>;

	// Dynamic selection lists
	loadjs.done("fbillacclookupedit");
});
</script>
<script>
loadjs.ready("head", function() {

	// Client script
	// Write your client script here, no need to add script tags.

});
</script>
<?php $billacclookup_edit->showPageHeader(); ?>
<?php
$billacclookup_edit->showMessage();
?>
<form name="fbillacclookupedit" id="fbillacclookupedit" class="<?php echo $billacclookup_edit->FormClassName ?>" action="<?php echo CurrentPageName() ?>" method="post">
<?php if ($Page->CheckToken) { ?>
<input type="hidden" name="<?php echo Config("TOKEN_NAME") ?>" value="<?php echo $Page->Token ?>">
<?php } ?>
<input type="hidden" name="t" value="billacclookup">
<input type="hidden" name="action" id="action" value="update">
<input type="hidden" name="modal" value="<?php echo (int)$billacclookup_edit->IsModal ?>">
<div class="ew-edit-div"><!-- page* -->
<?php if ($billacclookup_edit->recid->Visible) { // recid ?>
	<div id="r_recid" class="form-group row">
		<label id="elh_billacclookup_recid" class="<?php echo $billacclookup_edit->LeftColumnClass ?>"><?php echo $billacclookup_edit->recid->caption() ?><?php echo $billacclookup_edit->recid->Required ? $Language->phrase("FieldRequiredIndicator") : "" ?></label>
		<div class="<?php echo $billacclookup_edit->RightColumnClass ?>"><div <?php echo $billacclookup_edit->recid->cellAttributes() ?>>
<span id="el_billacclookup_recid">
<span<?php echo $billacclookup_edit->recid->viewAttributes() ?>><input type="text" readonly class="form-control-plaintext" value="<?php echo HtmlEncode(RemoveHtml($billacclookup_edit->recid->EditValue)) ?>"></span>
</span>
<input type="hidden" data-table="billacclookup" data-field="x_recid" name="x_recid" id="x_recid" value="<?php echo HtmlEncode($billacclookup_edit->recid->CurrentValue) ?>">
<?php echo $billacclookup_edit->recid->CustomMsg ?></div></div>
	</div>
<?php } ?>
<?php if ($billacclookup_edit->logtime->Visible) { // logtime ?>
	<div id="r_logtime" class="form-group row">
		<label id="elh_billacclookup_logtime" for="x_logtime" class="<?php echo $billacclookup_edit->LeftColumnClass ?>"><?php echo $billacclookup_edit->logtime->caption() ?><?php echo $billacclookup_edit->logtime->Required ? $Language->phrase("FieldRequiredIndicator") : "" ?></label>
		<div class="<?php echo $billacclookup_edit->RightColumnClass ?>"><div <?php echo $billacclookup_edit->logtime->cellAttributes() ?>>
<span id="el_billacclookup_logtime">
<input type="text" data-table="billacclookup" data-field="x_logtime" data-format="1" name="x_logtime" id="x_logtime" placeholder="<?php echo HtmlEncode($billacclookup_edit->logtime->getPlaceHolder()) ?>" value="<?php echo $billacclookup_edit->logtime->EditValue ?>"<?php echo $billacclookup_edit->logtime->editAttributes() ?>>
<?php if (!$billacclookup_edit->logtime->ReadOnly && !$billacclookup_edit->logtime->Disabled && !isset($billacclookup_edit->logtime->EditAttrs["readonly"]) && !isset($billacclookup_edit->logtime->EditAttrs["disabled"])) { ?>
<script>
loadjs.ready(["fbillacclookupedit", "datetimepicker"], function() {
	ew.createDateTimePicker("fbillacclookupedit", "x_logtime", {"ignoreReadonly":true,"useCurrent":false,"format":1});
});
</script>
<?php } ?>
</span>
<?php echo $billacclookup_edit->logtime->CustomMsg ?></div></div>
	</div>
<?php } ?>
<?php if ($billacclookup_edit->_userid->Visible) { // userid ?>
	<div id="r__userid" class="form-group row">
		<label id="elh_billacclookup__userid" for="x__userid" class="<?php echo $billacclookup_edit->LeftColumnClass ?>"><?php echo $billacclookup_edit->_userid->caption() ?><?php echo $billacclookup_edit->_userid->Required ? $Language->phrase("FieldRequiredIndicator") : "" ?></label>
		<div class="<?php echo $billacclookup_edit->RightColumnClass ?>"><div <?php echo $billacclookup_edit->_userid->cellAttributes() ?>>
<span id="el_billacclookup__userid">
<input type="text" data-table="billacclookup" data-field="x__userid" name="x__userid" id="x__userid" size="30" placeholder="<?php echo HtmlEncode($billacclookup_edit->_userid->getPlaceHolder()) ?>" value="<?php echo $billacclookup_edit->_userid->EditValue ?>"<?php echo $billacclookup_edit->_userid->editAttributes() ?>>
</span>
<?php echo $billacclookup_edit->_userid->CustomMsg ?></div></div>
	</div>
<?php } ?>
<?php if ($billacclookup_edit->serviceid->Visible) { // serviceid ?>
	<div id="r_serviceid" class="form-group row">
		<label id="elh_billacclookup_serviceid" for="x_serviceid" class="<?php echo $billacclookup_edit->LeftColumnClass ?>"><?php echo $billacclookup_edit->serviceid->caption() ?><?php echo $billacclookup_edit->serviceid->Required ? $Language->phrase("FieldRequiredIndicator") : "" ?></label>
		<div class="<?php echo $billacclookup_edit->RightColumnClass ?>"><div <?php echo $billacclookup_edit->serviceid->cellAttributes() ?>>
<span id="el_billacclookup_serviceid">
<input type="text" data-table="billacclookup" data-field="x_serviceid" name="x_serviceid" id="x_serviceid" size="30" placeholder="<?php echo HtmlEncode($billacclookup_edit->serviceid->getPlaceHolder()) ?>" value="<?php echo $billacclookup_edit->serviceid->EditValue ?>"<?php echo $billacclookup_edit->serviceid->editAttributes() ?>>
</span>
<?php echo $billacclookup_edit->serviceid->CustomMsg ?></div></div>
	</div>
<?php } ?>
<?php if ($billacclookup_edit->billaccountno->Visible) { // billaccountno ?>
	<div id="r_billaccountno" class="form-group row">
		<label id="elh_billacclookup_billaccountno" for="x_billaccountno" class="<?php echo $billacclookup_edit->LeftColumnClass ?>"><?php echo $billacclookup_edit->billaccountno->caption() ?><?php echo $billacclookup_edit->billaccountno->Required ? $Language->phrase("FieldRequiredIndicator") : "" ?></label>
		<div class="<?php echo $billacclookup_edit->RightColumnClass ?>"><div <?php echo $billacclookup_edit->billaccountno->cellAttributes() ?>>
<span id="el_billacclookup_billaccountno">
<input type="text" data-table="billacclookup" data-field="x_billaccountno" name="x_billaccountno" id="x_billaccountno" size="30" maxlength="20" placeholder="<?php echo HtmlEncode($billacclookup_edit->billaccountno->getPlaceHolder()) ?>" value="<?php echo $billacclookup_edit->billaccountno->EditValue ?>"<?php echo $billacclookup_edit->billaccountno->editAttributes() ?>>
</span>
<?php echo $billacclookup_edit->billaccountno->CustomMsg ?></div></div>
	</div>
<?php } ?>
</div><!-- /page* -->
<?php if (!$billacclookup_edit->IsModal) { ?>
<div class="form-group row"><!-- buttons .form-group -->
	<div class="<?php echo $billacclookup_edit->OffsetColumnClass ?>"><!-- buttons offset -->
<button class="btn btn-primary ew-btn" name="btn-action" id="btn-action" type="submit"><?php echo $Language->phrase("SaveBtn") ?></button>
<button class="btn btn-default ew-btn" name="btn-cancel" id="btn-cancel" type="button" data-href="<?php echo $billacclookup_edit->getReturnUrl() ?>"><?php echo $Language->phrase("CancelBtn") ?></button>
	</div><!-- /buttons offset -->
</div><!-- /buttons .form-group -->
<?php } ?>
</form>
<?php
$billacclookup_edit->showPageFooter();
if (Config("DEBUG"))
	echo GetDebugMessage();
?>
<script>
loadjs.ready("load", function() {

	// Startup script
	// Write your table-specific startup script here
	// console.log("page loaded");

});
</script>
<?php include_once "footer.php"; ?>
<?php
$billacclookup_edit->terminate();
?>