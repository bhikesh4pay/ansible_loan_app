<?php
namespace PHPMaker2020\_4payadmin;

// Autoload
include_once "autoload.php";

// Session
if (session_status() !== PHP_SESSION_ACTIVE)
	\Delight\Cookie\Session::start(Config("COOKIE_SAMESITE")); // Init session data

// Output buffering
ob_start();
?>
<?php

// Write header
WriteHeader(FALSE);

// Create page object
$loantierhistory_delete = new loantierhistory_delete();

// Run the page
$loantierhistory_delete->run();

// Setup login status
SetupLoginStatus();
SetClientVar("login", LoginStatus());

// Global Page Rendering event (in userfn*.php)
Page_Rendering();

// Page Rendering event
$loantierhistory_delete->Page_Render();
?>
<?php include_once "header.php"; ?>
<script>
var floantierhistorydelete, currentPageID;
loadjs.ready("head", function() {

	// Form object
	currentPageID = ew.PAGE_ID = "delete";
	floantierhistorydelete = currentForm = new ew.Form("floantierhistorydelete", "delete");
	loadjs.done("floantierhistorydelete");
});
</script>
<script>
loadjs.ready("head", function() {

	// Client script
	// Write your client script here, no need to add script tags.

});
</script>
<?php $loantierhistory_delete->showPageHeader(); ?>
<?php
$loantierhistory_delete->showMessage();
?>
<form name="floantierhistorydelete" id="floantierhistorydelete" class="form-inline ew-form ew-delete-form" action="<?php echo CurrentPageName() ?>" method="post">
<?php if ($Page->CheckToken) { ?>
<input type="hidden" name="<?php echo Config("TOKEN_NAME") ?>" value="<?php echo $Page->Token ?>">
<?php } ?>
<input type="hidden" name="t" value="loantierhistory">
<input type="hidden" name="action" id="action" value="delete">
<?php foreach ($loantierhistory_delete->RecKeys as $key) { ?>
<?php $keyvalue = is_array($key) ? implode(Config("COMPOSITE_KEY_SEPARATOR"), $key) : $key; ?>
<input type="hidden" name="key_m[]" value="<?php echo HtmlEncode($keyvalue) ?>">
<?php } ?>
<div class="card ew-card ew-grid">
<div class="<?php echo ResponsiveTableClass() ?>card-body ew-grid-middle-panel">
<table class="table ew-table">
	<thead>
	<tr class="ew-table-header">
<?php if ($loantierhistory_delete->changeid->Visible) { // changeid ?>
		<th class="<?php echo $loantierhistory_delete->changeid->headerCellClass() ?>"><span id="elh_loantierhistory_changeid" class="loantierhistory_changeid"><?php echo $loantierhistory_delete->changeid->caption() ?></span></th>
<?php } ?>
<?php if ($loantierhistory_delete->_userid->Visible) { // userid ?>
		<th class="<?php echo $loantierhistory_delete->_userid->headerCellClass() ?>"><span id="elh_loantierhistory__userid" class="loantierhistory__userid"><?php echo $loantierhistory_delete->_userid->caption() ?></span></th>
<?php } ?>
<?php if ($loantierhistory_delete->curr->Visible) { // curr ?>
		<th class="<?php echo $loantierhistory_delete->curr->headerCellClass() ?>"><span id="elh_loantierhistory_curr" class="loantierhistory_curr"><?php echo $loantierhistory_delete->curr->caption() ?></span></th>
<?php } ?>
<?php if ($loantierhistory_delete->fromtier->Visible) { // fromtier ?>
		<th class="<?php echo $loantierhistory_delete->fromtier->headerCellClass() ?>"><span id="elh_loantierhistory_fromtier" class="loantierhistory_fromtier"><?php echo $loantierhistory_delete->fromtier->caption() ?></span></th>
<?php } ?>
<?php if ($loantierhistory_delete->totier->Visible) { // totier ?>
		<th class="<?php echo $loantierhistory_delete->totier->headerCellClass() ?>"><span id="elh_loantierhistory_totier" class="loantierhistory_totier"><?php echo $loantierhistory_delete->totier->caption() ?></span></th>
<?php } ?>
<?php if ($loantierhistory_delete->changedate->Visible) { // changedate ?>
		<th class="<?php echo $loantierhistory_delete->changedate->headerCellClass() ?>"><span id="elh_loantierhistory_changedate" class="loantierhistory_changedate"><?php echo $loantierhistory_delete->changedate->caption() ?></span></th>
<?php } ?>
	</tr>
	</thead>
	<tbody>
<?php
$loantierhistory_delete->RecordCount = 0;
$i = 0;
while (!$loantierhistory_delete->Recordset->EOF) {
	$loantierhistory_delete->RecordCount++;
	$loantierhistory_delete->RowCount++;

	// Set row properties
	$loantierhistory->resetAttributes();
	$loantierhistory->RowType = ROWTYPE_VIEW; // View

	// Get the field contents
	$loantierhistory_delete->loadRowValues($loantierhistory_delete->Recordset);

	// Render row
	$loantierhistory_delete->renderRow();
?>
	<tr <?php echo $loantierhistory->rowAttributes() ?>>
<?php if ($loantierhistory_delete->changeid->Visible) { // changeid ?>
		<td <?php echo $loantierhistory_delete->changeid->cellAttributes() ?>>
<span id="el<?php echo $loantierhistory_delete->RowCount ?>_loantierhistory_changeid" class="loantierhistory_changeid">
<span<?php echo $loantierhistory_delete->changeid->viewAttributes() ?>><?php echo $loantierhistory_delete->changeid->getViewValue() ?></span>
</span>
</td>
<?php } ?>
<?php if ($loantierhistory_delete->_userid->Visible) { // userid ?>
		<td <?php echo $loantierhistory_delete->_userid->cellAttributes() ?>>
<span id="el<?php echo $loantierhistory_delete->RowCount ?>_loantierhistory__userid" class="loantierhistory__userid">
<span<?php echo $loantierhistory_delete->_userid->viewAttributes() ?>><?php if (!EmptyString($loantierhistory_delete->_userid->getViewValue()) && $loantierhistory_delete->_userid->linkAttributes() != "") { ?>
<a<?php echo $loantierhistory_delete->_userid->linkAttributes() ?>><?php echo $loantierhistory_delete->_userid->getViewValue() ?></a>
<?php } else { ?>
<?php echo $loantierhistory_delete->_userid->getViewValue() ?>
<?php } ?></span>
</span>
</td>
<?php } ?>
<?php if ($loantierhistory_delete->curr->Visible) { // curr ?>
		<td <?php echo $loantierhistory_delete->curr->cellAttributes() ?>>
<span id="el<?php echo $loantierhistory_delete->RowCount ?>_loantierhistory_curr" class="loantierhistory_curr">
<span<?php echo $loantierhistory_delete->curr->viewAttributes() ?>><?php echo $loantierhistory_delete->curr->getViewValue() ?></span>
</span>
</td>
<?php } ?>
<?php if ($loantierhistory_delete->fromtier->Visible) { // fromtier ?>
		<td <?php echo $loantierhistory_delete->fromtier->cellAttributes() ?>>
<span id="el<?php echo $loantierhistory_delete->RowCount ?>_loantierhistory_fromtier" class="loantierhistory_fromtier">
<span<?php echo $loantierhistory_delete->fromtier->viewAttributes() ?>><?php echo $loantierhistory_delete->fromtier->getViewValue() ?></span>
</span>
</td>
<?php } ?>
<?php if ($loantierhistory_delete->totier->Visible) { // totier ?>
		<td <?php echo $loantierhistory_delete->totier->cellAttributes() ?>>
<span id="el<?php echo $loantierhistory_delete->RowCount ?>_loantierhistory_totier" class="loantierhistory_totier">
<span<?php echo $loantierhistory_delete->totier->viewAttributes() ?>><?php echo $loantierhistory_delete->totier->getViewValue() ?></span>
</span>
</td>
<?php } ?>
<?php if ($loantierhistory_delete->changedate->Visible) { // changedate ?>
		<td <?php echo $loantierhistory_delete->changedate->cellAttributes() ?>>
<span id="el<?php echo $loantierhistory_delete->RowCount ?>_loantierhistory_changedate" class="loantierhistory_changedate">
<span<?php echo $loantierhistory_delete->changedate->viewAttributes() ?>><?php echo $loantierhistory_delete->changedate->getViewValue() ?></span>
</span>
</td>
<?php } ?>
	</tr>
<?php
	$loantierhistory_delete->Recordset->moveNext();
}
$loantierhistory_delete->Recordset->close();
?>
</tbody>
</table>
</div>
</div>
<div>
<button class="btn btn-primary ew-btn" name="btn-action" id="btn-action" type="submit"><?php echo $Language->phrase("DeleteBtn") ?></button>
<button class="btn btn-default ew-btn" name="btn-cancel" id="btn-cancel" type="button" data-href="<?php echo $loantierhistory_delete->getReturnUrl() ?>"><?php echo $Language->phrase("CancelBtn") ?></button>
</div>
</form>
<?php
$loantierhistory_delete->showPageFooter();
if (Config("DEBUG"))
	echo GetDebugMessage();
?>
<script>
loadjs.ready("load", function() {

	// Startup script
	// Write your table-specific startup script here
	// console.log("page loaded");

});
</script>
<?php include_once "footer.php"; ?>
<?php
$loantierhistory_delete->terminate();
?>