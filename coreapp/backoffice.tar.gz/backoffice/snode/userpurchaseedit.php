<?php
namespace PHPMaker2020\_4payadmin;

// Autoload
include_once "autoload.php";

// Session
if (session_status() !== PHP_SESSION_ACTIVE)
	\Delight\Cookie\Session::start(Config("COOKIE_SAMESITE")); // Init session data

// Output buffering
ob_start();
?>
<?php

// Write header
WriteHeader(FALSE);

// Create page object
$userpurchase_edit = new userpurchase_edit();

// Run the page
$userpurchase_edit->run();

// Setup login status
SetupLoginStatus();
SetClientVar("login", LoginStatus());

// Global Page Rendering event (in userfn*.php)
Page_Rendering();

// Page Rendering event
$userpurchase_edit->Page_Render();
?>
<?php include_once "header.php"; ?>
<script>
var fuserpurchaseedit, currentPageID;
loadjs.ready("head", function() {

	// Form object
	currentPageID = ew.PAGE_ID = "edit";
	fuserpurchaseedit = currentForm = new ew.Form("fuserpurchaseedit", "edit");

	// Validate form
	fuserpurchaseedit.validate = function() {
		if (!this.validateRequired)
			return true; // Ignore validation
		var $ = jQuery, fobj = this.getForm(), $fobj = $(fobj);
		if ($fobj.find("#confirm").val() == "confirm")
			return true;
		var elm, felm, uelm, addcnt = 0;
		var $k = $fobj.find("#" + this.formKeyCountName); // Get key_count
		var rowcnt = ($k[0]) ? parseInt($k.val(), 10) : 1;
		var startcnt = (rowcnt == 0) ? 0 : 1; // Check rowcnt == 0 => Inline-Add
		var gridinsert = ["insert", "gridinsert"].includes($fobj.find("#action").val()) && $k[0];
		for (var i = startcnt; i <= rowcnt; i++) {
			var infix = ($k[0]) ? String(i) : "";
			$fobj.data("rowindex", infix);
			<?php if ($userpurchase_edit->purchaseid->Required) { ?>
				elm = this.getElements("x" + infix + "_purchaseid");
				if (elm && !ew.isHidden(elm) && !ew.hasValue(elm))
					return this.onError(elm, "<?php echo JsEncode(str_replace("%s", $userpurchase_edit->purchaseid->caption(), $userpurchase_edit->purchaseid->RequiredErrorMessage)) ?>");
			<?php } ?>
			<?php if ($userpurchase_edit->_userid->Required) { ?>
				elm = this.getElements("x" + infix + "__userid");
				if (elm && !ew.isHidden(elm) && !ew.hasValue(elm))
					return this.onError(elm, "<?php echo JsEncode(str_replace("%s", $userpurchase_edit->_userid->caption(), $userpurchase_edit->_userid->RequiredErrorMessage)) ?>");
			<?php } ?>
				elm = this.getElements("x" + infix + "__userid");
				if (elm && !ew.checkInteger(elm.value))
					return this.onError(elm, "<?php echo JsEncode($userpurchase_edit->_userid->errorMessage()) ?>");
			<?php if ($userpurchase_edit->merchantnodeid->Required) { ?>
				elm = this.getElements("x" + infix + "_merchantnodeid");
				if (elm && !ew.isHidden(elm) && !ew.hasValue(elm))
					return this.onError(elm, "<?php echo JsEncode(str_replace("%s", $userpurchase_edit->merchantnodeid->caption(), $userpurchase_edit->merchantnodeid->RequiredErrorMessage)) ?>");
			<?php } ?>
				elm = this.getElements("x" + infix + "_merchantnodeid");
				if (elm && !ew.checkInteger(elm.value))
					return this.onError(elm, "<?php echo JsEncode($userpurchase_edit->merchantnodeid->errorMessage()) ?>");
			<?php if ($userpurchase_edit->merchantid->Required) { ?>
				elm = this.getElements("x" + infix + "_merchantid");
				if (elm && !ew.isHidden(elm) && !ew.hasValue(elm))
					return this.onError(elm, "<?php echo JsEncode(str_replace("%s", $userpurchase_edit->merchantid->caption(), $userpurchase_edit->merchantid->RequiredErrorMessage)) ?>");
			<?php } ?>
				elm = this.getElements("x" + infix + "_merchantid");
				if (elm && !ew.checkInteger(elm.value))
					return this.onError(elm, "<?php echo JsEncode($userpurchase_edit->merchantid->errorMessage()) ?>");
			<?php if ($userpurchase_edit->merchantbusinessname->Required) { ?>
				elm = this.getElements("x" + infix + "_merchantbusinessname");
				if (elm && !ew.isHidden(elm) && !ew.hasValue(elm))
					return this.onError(elm, "<?php echo JsEncode(str_replace("%s", $userpurchase_edit->merchantbusinessname->caption(), $userpurchase_edit->merchantbusinessname->RequiredErrorMessage)) ?>");
			<?php } ?>
			<?php if ($userpurchase_edit->merchanttransferid->Required) { ?>
				elm = this.getElements("x" + infix + "_merchanttransferid");
				if (elm && !ew.isHidden(elm) && !ew.hasValue(elm))
					return this.onError(elm, "<?php echo JsEncode(str_replace("%s", $userpurchase_edit->merchanttransferid->caption(), $userpurchase_edit->merchanttransferid->RequiredErrorMessage)) ?>");
			<?php } ?>
				elm = this.getElements("x" + infix + "_merchanttransferid");
				if (elm && !ew.checkInteger(elm.value))
					return this.onError(elm, "<?php echo JsEncode($userpurchase_edit->merchanttransferid->errorMessage()) ?>");
			<?php if ($userpurchase_edit->merchantuserid->Required) { ?>
				elm = this.getElements("x" + infix + "_merchantuserid");
				if (elm && !ew.isHidden(elm) && !ew.hasValue(elm))
					return this.onError(elm, "<?php echo JsEncode(str_replace("%s", $userpurchase_edit->merchantuserid->caption(), $userpurchase_edit->merchantuserid->RequiredErrorMessage)) ?>");
			<?php } ?>
				elm = this.getElements("x" + infix + "_merchantuserid");
				if (elm && !ew.checkInteger(elm.value))
					return this.onError(elm, "<?php echo JsEncode($userpurchase_edit->merchantuserid->errorMessage()) ?>");
			<?php if ($userpurchase_edit->purchasedate->Required) { ?>
				elm = this.getElements("x" + infix + "_purchasedate");
				if (elm && !ew.isHidden(elm) && !ew.hasValue(elm))
					return this.onError(elm, "<?php echo JsEncode(str_replace("%s", $userpurchase_edit->purchasedate->caption(), $userpurchase_edit->purchasedate->RequiredErrorMessage)) ?>");
			<?php } ?>
				elm = this.getElements("x" + infix + "_purchasedate");
				if (elm && !ew.checkDateDef(elm.value))
					return this.onError(elm, "<?php echo JsEncode($userpurchase_edit->purchasedate->errorMessage()) ?>");
			<?php if ($userpurchase_edit->txid->Required) { ?>
				elm = this.getElements("x" + infix + "_txid");
				if (elm && !ew.isHidden(elm) && !ew.hasValue(elm))
					return this.onError(elm, "<?php echo JsEncode(str_replace("%s", $userpurchase_edit->txid->caption(), $userpurchase_edit->txid->RequiredErrorMessage)) ?>");
			<?php } ?>
			<?php if ($userpurchase_edit->userpi->Required) { ?>
				elm = this.getElements("x" + infix + "_userpi");
				if (elm && !ew.isHidden(elm) && !ew.hasValue(elm))
					return this.onError(elm, "<?php echo JsEncode(str_replace("%s", $userpurchase_edit->userpi->caption(), $userpurchase_edit->userpi->RequiredErrorMessage)) ?>");
			<?php } ?>
				elm = this.getElements("x" + infix + "_userpi");
				if (elm && !ew.checkInteger(elm.value))
					return this.onError(elm, "<?php echo JsEncode($userpurchase_edit->userpi->errorMessage()) ?>");
			<?php if ($userpurchase_edit->otherconfirmref->Required) { ?>
				elm = this.getElements("x" + infix + "_otherconfirmref");
				if (elm && !ew.isHidden(elm) && !ew.hasValue(elm))
					return this.onError(elm, "<?php echo JsEncode(str_replace("%s", $userpurchase_edit->otherconfirmref->caption(), $userpurchase_edit->otherconfirmref->RequiredErrorMessage)) ?>");
			<?php } ?>
			<?php if ($userpurchase_edit->currencycode->Required) { ?>
				elm = this.getElements("x" + infix + "_currencycode");
				if (elm && !ew.isHidden(elm) && !ew.hasValue(elm))
					return this.onError(elm, "<?php echo JsEncode(str_replace("%s", $userpurchase_edit->currencycode->caption(), $userpurchase_edit->currencycode->RequiredErrorMessage)) ?>");
			<?php } ?>
			<?php if ($userpurchase_edit->purchaseamount->Required) { ?>
				elm = this.getElements("x" + infix + "_purchaseamount");
				if (elm && !ew.isHidden(elm) && !ew.hasValue(elm))
					return this.onError(elm, "<?php echo JsEncode(str_replace("%s", $userpurchase_edit->purchaseamount->caption(), $userpurchase_edit->purchaseamount->RequiredErrorMessage)) ?>");
			<?php } ?>
				elm = this.getElements("x" + infix + "_purchaseamount");
				if (elm && !ew.checkNumber(elm.value))
					return this.onError(elm, "<?php echo JsEncode($userpurchase_edit->purchaseamount->errorMessage()) ?>");
			<?php if ($userpurchase_edit->tipamount->Required) { ?>
				elm = this.getElements("x" + infix + "_tipamount");
				if (elm && !ew.isHidden(elm) && !ew.hasValue(elm))
					return this.onError(elm, "<?php echo JsEncode(str_replace("%s", $userpurchase_edit->tipamount->caption(), $userpurchase_edit->tipamount->RequiredErrorMessage)) ?>");
			<?php } ?>
				elm = this.getElements("x" + infix + "_tipamount");
				if (elm && !ew.checkNumber(elm.value))
					return this.onError(elm, "<?php echo JsEncode($userpurchase_edit->tipamount->errorMessage()) ?>");
			<?php if ($userpurchase_edit->merchantfees->Required) { ?>
				elm = this.getElements("x" + infix + "_merchantfees");
				if (elm && !ew.isHidden(elm) && !ew.hasValue(elm))
					return this.onError(elm, "<?php echo JsEncode(str_replace("%s", $userpurchase_edit->merchantfees->caption(), $userpurchase_edit->merchantfees->RequiredErrorMessage)) ?>");
			<?php } ?>
				elm = this.getElements("x" + infix + "_merchantfees");
				if (elm && !ew.checkNumber(elm.value))
					return this.onError(elm, "<?php echo JsEncode($userpurchase_edit->merchantfees->errorMessage()) ?>");
			<?php if ($userpurchase_edit->consumerfees->Required) { ?>
				elm = this.getElements("x" + infix + "_consumerfees");
				if (elm && !ew.isHidden(elm) && !ew.hasValue(elm))
					return this.onError(elm, "<?php echo JsEncode(str_replace("%s", $userpurchase_edit->consumerfees->caption(), $userpurchase_edit->consumerfees->RequiredErrorMessage)) ?>");
			<?php } ?>
				elm = this.getElements("x" + infix + "_consumerfees");
				if (elm && !ew.checkNumber(elm.value))
					return this.onError(elm, "<?php echo JsEncode($userpurchase_edit->consumerfees->errorMessage()) ?>");
			<?php if ($userpurchase_edit->transferid->Required) { ?>
				elm = this.getElements("x" + infix + "_transferid");
				if (elm && !ew.isHidden(elm) && !ew.hasValue(elm))
					return this.onError(elm, "<?php echo JsEncode(str_replace("%s", $userpurchase_edit->transferid->caption(), $userpurchase_edit->transferid->RequiredErrorMessage)) ?>");
			<?php } ?>
				elm = this.getElements("x" + infix + "_transferid");
				if (elm && !ew.checkInteger(elm.value))
					return this.onError(elm, "<?php echo JsEncode($userpurchase_edit->transferid->errorMessage()) ?>");
			<?php if ($userpurchase_edit->merchantSurcharge->Required) { ?>
				elm = this.getElements("x" + infix + "_merchantSurcharge");
				if (elm && !ew.isHidden(elm) && !ew.hasValue(elm))
					return this.onError(elm, "<?php echo JsEncode(str_replace("%s", $userpurchase_edit->merchantSurcharge->caption(), $userpurchase_edit->merchantSurcharge->RequiredErrorMessage)) ?>");
			<?php } ?>
				elm = this.getElements("x" + infix + "_merchantSurcharge");
				if (elm && !ew.checkNumber(elm.value))
					return this.onError(elm, "<?php echo JsEncode($userpurchase_edit->merchantSurcharge->errorMessage()) ?>");
			<?php if ($userpurchase_edit->taxAmount->Required) { ?>
				elm = this.getElements("x" + infix + "_taxAmount");
				if (elm && !ew.isHidden(elm) && !ew.hasValue(elm))
					return this.onError(elm, "<?php echo JsEncode(str_replace("%s", $userpurchase_edit->taxAmount->caption(), $userpurchase_edit->taxAmount->RequiredErrorMessage)) ?>");
			<?php } ?>
				elm = this.getElements("x" + infix + "_taxAmount");
				if (elm && !ew.checkNumber(elm.value))
					return this.onError(elm, "<?php echo JsEncode($userpurchase_edit->taxAmount->errorMessage()) ?>");
			<?php if ($userpurchase_edit->totalAmounForCustomer->Required) { ?>
				elm = this.getElements("x" + infix + "_totalAmounForCustomer");
				if (elm && !ew.isHidden(elm) && !ew.hasValue(elm))
					return this.onError(elm, "<?php echo JsEncode(str_replace("%s", $userpurchase_edit->totalAmounForCustomer->caption(), $userpurchase_edit->totalAmounForCustomer->RequiredErrorMessage)) ?>");
			<?php } ?>
				elm = this.getElements("x" + infix + "_totalAmounForCustomer");
				if (elm && !ew.checkNumber(elm.value))
					return this.onError(elm, "<?php echo JsEncode($userpurchase_edit->totalAmounForCustomer->errorMessage()) ?>");
			<?php if ($userpurchase_edit->feeid->Required) { ?>
				elm = this.getElements("x" + infix + "_feeid");
				if (elm && !ew.isHidden(elm) && !ew.hasValue(elm))
					return this.onError(elm, "<?php echo JsEncode(str_replace("%s", $userpurchase_edit->feeid->caption(), $userpurchase_edit->feeid->RequiredErrorMessage)) ?>");
			<?php } ?>
				elm = this.getElements("x" + infix + "_feeid");
				if (elm && !ew.checkInteger(elm.value))
					return this.onError(elm, "<?php echo JsEncode($userpurchase_edit->feeid->errorMessage()) ?>");
			<?php if ($userpurchase_edit->ratetabletype->Required) { ?>
				elm = this.getElements("x" + infix + "_ratetabletype");
				if (elm && !ew.isHidden(elm) && !ew.hasValue(elm))
					return this.onError(elm, "<?php echo JsEncode(str_replace("%s", $userpurchase_edit->ratetabletype->caption(), $userpurchase_edit->ratetabletype->RequiredErrorMessage)) ?>");
			<?php } ?>
				elm = this.getElements("x" + infix + "_ratetabletype");
				if (elm && !ew.checkInteger(elm.value))
					return this.onError(elm, "<?php echo JsEncode($userpurchase_edit->ratetabletype->errorMessage()) ?>");
			<?php if ($userpurchase_edit->itemdesc->Required) { ?>
				elm = this.getElements("x" + infix + "_itemdesc");
				if (elm && !ew.isHidden(elm) && !ew.hasValue(elm))
					return this.onError(elm, "<?php echo JsEncode(str_replace("%s", $userpurchase_edit->itemdesc->caption(), $userpurchase_edit->itemdesc->RequiredErrorMessage)) ?>");
			<?php } ?>
			<?php if ($userpurchase_edit->shoppingCartID->Required) { ?>
				elm = this.getElements("x" + infix + "_shoppingCartID");
				if (elm && !ew.isHidden(elm) && !ew.hasValue(elm))
					return this.onError(elm, "<?php echo JsEncode(str_replace("%s", $userpurchase_edit->shoppingCartID->caption(), $userpurchase_edit->shoppingCartID->RequiredErrorMessage)) ?>");
			<?php } ?>
			<?php if ($userpurchase_edit->merchantRefID->Required) { ?>
				elm = this.getElements("x" + infix + "_merchantRefID");
				if (elm && !ew.isHidden(elm) && !ew.hasValue(elm))
					return this.onError(elm, "<?php echo JsEncode(str_replace("%s", $userpurchase_edit->merchantRefID->caption(), $userpurchase_edit->merchantRefID->RequiredErrorMessage)) ?>");
			<?php } ?>
			<?php if ($userpurchase_edit->refunded->Required) { ?>
				elm = this.getElements("x" + infix + "_refunded");
				if (elm && !ew.isHidden(elm) && !ew.hasValue(elm))
					return this.onError(elm, "<?php echo JsEncode(str_replace("%s", $userpurchase_edit->refunded->caption(), $userpurchase_edit->refunded->RequiredErrorMessage)) ?>");
			<?php } ?>
			<?php if ($userpurchase_edit->tokenid->Required) { ?>
				elm = this.getElements("x" + infix + "_tokenid");
				if (elm && !ew.isHidden(elm) && !ew.hasValue(elm))
					return this.onError(elm, "<?php echo JsEncode(str_replace("%s", $userpurchase_edit->tokenid->caption(), $userpurchase_edit->tokenid->RequiredErrorMessage)) ?>");
			<?php } ?>
			<?php if ($userpurchase_edit->cardno->Required) { ?>
				elm = this.getElements("x" + infix + "_cardno");
				if (elm && !ew.isHidden(elm) && !ew.hasValue(elm))
					return this.onError(elm, "<?php echo JsEncode(str_replace("%s", $userpurchase_edit->cardno->caption(), $userpurchase_edit->cardno->RequiredErrorMessage)) ?>");
			<?php } ?>
			<?php if ($userpurchase_edit->vaultid->Required) { ?>
				elm = this.getElements("x" + infix + "_vaultid");
				if (elm && !ew.isHidden(elm) && !ew.hasValue(elm))
					return this.onError(elm, "<?php echo JsEncode(str_replace("%s", $userpurchase_edit->vaultid->caption(), $userpurchase_edit->vaultid->RequiredErrorMessage)) ?>");
			<?php } ?>
				elm = this.getElements("x" + infix + "_vaultid");
				if (elm && !ew.checkInteger(elm.value))
					return this.onError(elm, "<?php echo JsEncode($userpurchase_edit->vaultid->errorMessage()) ?>");
			<?php if ($userpurchase_edit->refundrequested->Required) { ?>
				elm = this.getElements("x" + infix + "_refundrequested");
				if (elm && !ew.isHidden(elm) && !ew.hasValue(elm))
					return this.onError(elm, "<?php echo JsEncode(str_replace("%s", $userpurchase_edit->refundrequested->caption(), $userpurchase_edit->refundrequested->RequiredErrorMessage)) ?>");
			<?php } ?>
				elm = this.getElements("x" + infix + "_refundrequested");
				if (elm && !ew.checkInteger(elm.value))
					return this.onError(elm, "<?php echo JsEncode($userpurchase_edit->refundrequested->errorMessage()) ?>");
			<?php if ($userpurchase_edit->refundrequesttxid->Required) { ?>
				elm = this.getElements("x" + infix + "_refundrequesttxid");
				if (elm && !ew.isHidden(elm) && !ew.hasValue(elm))
					return this.onError(elm, "<?php echo JsEncode(str_replace("%s", $userpurchase_edit->refundrequesttxid->caption(), $userpurchase_edit->refundrequesttxid->RequiredErrorMessage)) ?>");
			<?php } ?>
			<?php if ($userpurchase_edit->feesystemshare->Required) { ?>
				elm = this.getElements("x" + infix + "_feesystemshare");
				if (elm && !ew.isHidden(elm) && !ew.hasValue(elm))
					return this.onError(elm, "<?php echo JsEncode(str_replace("%s", $userpurchase_edit->feesystemshare->caption(), $userpurchase_edit->feesystemshare->RequiredErrorMessage)) ?>");
			<?php } ?>
				elm = this.getElements("x" + infix + "_feesystemshare");
				if (elm && !ew.checkNumber(elm.value))
					return this.onError(elm, "<?php echo JsEncode($userpurchase_edit->feesystemshare->errorMessage()) ?>");
			<?php if ($userpurchase_edit->feeexternalshare->Required) { ?>
				elm = this.getElements("x" + infix + "_feeexternalshare");
				if (elm && !ew.isHidden(elm) && !ew.hasValue(elm))
					return this.onError(elm, "<?php echo JsEncode(str_replace("%s", $userpurchase_edit->feeexternalshare->caption(), $userpurchase_edit->feeexternalshare->RequiredErrorMessage)) ?>");
			<?php } ?>
				elm = this.getElements("x" + infix + "_feeexternalshare");
				if (elm && !ew.checkNumber(elm.value))
					return this.onError(elm, "<?php echo JsEncode($userpurchase_edit->feeexternalshare->errorMessage()) ?>");
			<?php if ($userpurchase_edit->feefranchiseeshare->Required) { ?>
				elm = this.getElements("x" + infix + "_feefranchiseeshare");
				if (elm && !ew.isHidden(elm) && !ew.hasValue(elm))
					return this.onError(elm, "<?php echo JsEncode(str_replace("%s", $userpurchase_edit->feefranchiseeshare->caption(), $userpurchase_edit->feefranchiseeshare->RequiredErrorMessage)) ?>");
			<?php } ?>
				elm = this.getElements("x" + infix + "_feefranchiseeshare");
				if (elm && !ew.checkNumber(elm.value))
					return this.onError(elm, "<?php echo JsEncode($userpurchase_edit->feefranchiseeshare->errorMessage()) ?>");
			<?php if ($userpurchase_edit->feeresellershare->Required) { ?>
				elm = this.getElements("x" + infix + "_feeresellershare");
				if (elm && !ew.isHidden(elm) && !ew.hasValue(elm))
					return this.onError(elm, "<?php echo JsEncode(str_replace("%s", $userpurchase_edit->feeresellershare->caption(), $userpurchase_edit->feeresellershare->RequiredErrorMessage)) ?>");
			<?php } ?>
				elm = this.getElements("x" + infix + "_feeresellershare");
				if (elm && !ew.checkNumber(elm.value))
					return this.onError(elm, "<?php echo JsEncode($userpurchase_edit->feeresellershare->errorMessage()) ?>");
			<?php if ($userpurchase_edit->_key->Required) { ?>
				elm = this.getElements("x" + infix + "__key");
				if (elm && !ew.isHidden(elm) && !ew.hasValue(elm))
					return this.onError(elm, "<?php echo JsEncode(str_replace("%s", $userpurchase_edit->_key->caption(), $userpurchase_edit->_key->RequiredErrorMessage)) ?>");
			<?php } ?>
			<?php if ($userpurchase_edit->serviceFeeToCustomerbk1amt->Required) { ?>
				elm = this.getElements("x" + infix + "_serviceFeeToCustomerbk1amt");
				if (elm && !ew.isHidden(elm) && !ew.hasValue(elm))
					return this.onError(elm, "<?php echo JsEncode(str_replace("%s", $userpurchase_edit->serviceFeeToCustomerbk1amt->caption(), $userpurchase_edit->serviceFeeToCustomerbk1amt->RequiredErrorMessage)) ?>");
			<?php } ?>
				elm = this.getElements("x" + infix + "_serviceFeeToCustomerbk1amt");
				if (elm && !ew.checkNumber(elm.value))
					return this.onError(elm, "<?php echo JsEncode($userpurchase_edit->serviceFeeToCustomerbk1amt->errorMessage()) ?>");
			<?php if ($userpurchase_edit->serviceFeeToCustomerbk1type->Required) { ?>
				elm = this.getElements("x" + infix + "_serviceFeeToCustomerbk1type");
				if (elm && !ew.isHidden(elm) && !ew.hasValue(elm))
					return this.onError(elm, "<?php echo JsEncode(str_replace("%s", $userpurchase_edit->serviceFeeToCustomerbk1type->caption(), $userpurchase_edit->serviceFeeToCustomerbk1type->RequiredErrorMessage)) ?>");
			<?php } ?>
			<?php if ($userpurchase_edit->serviceFeeToCustomerbk2amt->Required) { ?>
				elm = this.getElements("x" + infix + "_serviceFeeToCustomerbk2amt");
				if (elm && !ew.isHidden(elm) && !ew.hasValue(elm))
					return this.onError(elm, "<?php echo JsEncode(str_replace("%s", $userpurchase_edit->serviceFeeToCustomerbk2amt->caption(), $userpurchase_edit->serviceFeeToCustomerbk2amt->RequiredErrorMessage)) ?>");
			<?php } ?>
				elm = this.getElements("x" + infix + "_serviceFeeToCustomerbk2amt");
				if (elm && !ew.checkNumber(elm.value))
					return this.onError(elm, "<?php echo JsEncode($userpurchase_edit->serviceFeeToCustomerbk2amt->errorMessage()) ?>");
			<?php if ($userpurchase_edit->serviceFeeToCustomerbk2type->Required) { ?>
				elm = this.getElements("x" + infix + "_serviceFeeToCustomerbk2type");
				if (elm && !ew.isHidden(elm) && !ew.hasValue(elm))
					return this.onError(elm, "<?php echo JsEncode(str_replace("%s", $userpurchase_edit->serviceFeeToCustomerbk2type->caption(), $userpurchase_edit->serviceFeeToCustomerbk2type->RequiredErrorMessage)) ?>");
			<?php } ?>
			<?php if ($userpurchase_edit->serviceFeeToCustomerbk3amt->Required) { ?>
				elm = this.getElements("x" + infix + "_serviceFeeToCustomerbk3amt");
				if (elm && !ew.isHidden(elm) && !ew.hasValue(elm))
					return this.onError(elm, "<?php echo JsEncode(str_replace("%s", $userpurchase_edit->serviceFeeToCustomerbk3amt->caption(), $userpurchase_edit->serviceFeeToCustomerbk3amt->RequiredErrorMessage)) ?>");
			<?php } ?>
				elm = this.getElements("x" + infix + "_serviceFeeToCustomerbk3amt");
				if (elm && !ew.checkNumber(elm.value))
					return this.onError(elm, "<?php echo JsEncode($userpurchase_edit->serviceFeeToCustomerbk3amt->errorMessage()) ?>");
			<?php if ($userpurchase_edit->serviceFeeToCustomerbk3type->Required) { ?>
				elm = this.getElements("x" + infix + "_serviceFeeToCustomerbk3type");
				if (elm && !ew.isHidden(elm) && !ew.hasValue(elm))
					return this.onError(elm, "<?php echo JsEncode(str_replace("%s", $userpurchase_edit->serviceFeeToCustomerbk3type->caption(), $userpurchase_edit->serviceFeeToCustomerbk3type->RequiredErrorMessage)) ?>");
			<?php } ?>
			<?php if ($userpurchase_edit->taxAmountbk1amt->Required) { ?>
				elm = this.getElements("x" + infix + "_taxAmountbk1amt");
				if (elm && !ew.isHidden(elm) && !ew.hasValue(elm))
					return this.onError(elm, "<?php echo JsEncode(str_replace("%s", $userpurchase_edit->taxAmountbk1amt->caption(), $userpurchase_edit->taxAmountbk1amt->RequiredErrorMessage)) ?>");
			<?php } ?>
				elm = this.getElements("x" + infix + "_taxAmountbk1amt");
				if (elm && !ew.checkNumber(elm.value))
					return this.onError(elm, "<?php echo JsEncode($userpurchase_edit->taxAmountbk1amt->errorMessage()) ?>");
			<?php if ($userpurchase_edit->taxAmountbk1type->Required) { ?>
				elm = this.getElements("x" + infix + "_taxAmountbk1type");
				if (elm && !ew.isHidden(elm) && !ew.hasValue(elm))
					return this.onError(elm, "<?php echo JsEncode(str_replace("%s", $userpurchase_edit->taxAmountbk1type->caption(), $userpurchase_edit->taxAmountbk1type->RequiredErrorMessage)) ?>");
			<?php } ?>
			<?php if ($userpurchase_edit->taxAmountbk2amt->Required) { ?>
				elm = this.getElements("x" + infix + "_taxAmountbk2amt");
				if (elm && !ew.isHidden(elm) && !ew.hasValue(elm))
					return this.onError(elm, "<?php echo JsEncode(str_replace("%s", $userpurchase_edit->taxAmountbk2amt->caption(), $userpurchase_edit->taxAmountbk2amt->RequiredErrorMessage)) ?>");
			<?php } ?>
				elm = this.getElements("x" + infix + "_taxAmountbk2amt");
				if (elm && !ew.checkNumber(elm.value))
					return this.onError(elm, "<?php echo JsEncode($userpurchase_edit->taxAmountbk2amt->errorMessage()) ?>");
			<?php if ($userpurchase_edit->taxAmountbk2type->Required) { ?>
				elm = this.getElements("x" + infix + "_taxAmountbk2type");
				if (elm && !ew.isHidden(elm) && !ew.hasValue(elm))
					return this.onError(elm, "<?php echo JsEncode(str_replace("%s", $userpurchase_edit->taxAmountbk2type->caption(), $userpurchase_edit->taxAmountbk2type->RequiredErrorMessage)) ?>");
			<?php } ?>
			<?php if ($userpurchase_edit->taxAmountbk3amt->Required) { ?>
				elm = this.getElements("x" + infix + "_taxAmountbk3amt");
				if (elm && !ew.isHidden(elm) && !ew.hasValue(elm))
					return this.onError(elm, "<?php echo JsEncode(str_replace("%s", $userpurchase_edit->taxAmountbk3amt->caption(), $userpurchase_edit->taxAmountbk3amt->RequiredErrorMessage)) ?>");
			<?php } ?>
				elm = this.getElements("x" + infix + "_taxAmountbk3amt");
				if (elm && !ew.checkNumber(elm.value))
					return this.onError(elm, "<?php echo JsEncode($userpurchase_edit->taxAmountbk3amt->errorMessage()) ?>");
			<?php if ($userpurchase_edit->taxAmountbk3type->Required) { ?>
				elm = this.getElements("x" + infix + "_taxAmountbk3type");
				if (elm && !ew.isHidden(elm) && !ew.hasValue(elm))
					return this.onError(elm, "<?php echo JsEncode(str_replace("%s", $userpurchase_edit->taxAmountbk3type->caption(), $userpurchase_edit->taxAmountbk3type->RequiredErrorMessage)) ?>");
			<?php } ?>
			<?php if ($userpurchase_edit->originalpurchaseamount->Required) { ?>
				elm = this.getElements("x" + infix + "_originalpurchaseamount");
				if (elm && !ew.isHidden(elm) && !ew.hasValue(elm))
					return this.onError(elm, "<?php echo JsEncode(str_replace("%s", $userpurchase_edit->originalpurchaseamount->caption(), $userpurchase_edit->originalpurchaseamount->RequiredErrorMessage)) ?>");
			<?php } ?>
				elm = this.getElements("x" + infix + "_originalpurchaseamount");
				if (elm && !ew.checkNumber(elm.value))
					return this.onError(elm, "<?php echo JsEncode($userpurchase_edit->originalpurchaseamount->errorMessage()) ?>");
			<?php if ($userpurchase_edit->discountamount->Required) { ?>
				elm = this.getElements("x" + infix + "_discountamount");
				if (elm && !ew.isHidden(elm) && !ew.hasValue(elm))
					return this.onError(elm, "<?php echo JsEncode(str_replace("%s", $userpurchase_edit->discountamount->caption(), $userpurchase_edit->discountamount->RequiredErrorMessage)) ?>");
			<?php } ?>
				elm = this.getElements("x" + infix + "_discountamount");
				if (elm && !ew.checkNumber(elm.value))
					return this.onError(elm, "<?php echo JsEncode($userpurchase_edit->discountamount->errorMessage()) ?>");
			<?php if ($userpurchase_edit->discountpercentage->Required) { ?>
				elm = this.getElements("x" + infix + "_discountpercentage");
				if (elm && !ew.isHidden(elm) && !ew.hasValue(elm))
					return this.onError(elm, "<?php echo JsEncode(str_replace("%s", $userpurchase_edit->discountpercentage->caption(), $userpurchase_edit->discountpercentage->RequiredErrorMessage)) ?>");
			<?php } ?>
				elm = this.getElements("x" + infix + "_discountpercentage");
				if (elm && !ew.checkInteger(elm.value))
					return this.onError(elm, "<?php echo JsEncode($userpurchase_edit->discountpercentage->errorMessage()) ?>");
			<?php if ($userpurchase_edit->txgroupid->Required) { ?>
				elm = this.getElements("x" + infix + "_txgroupid");
				if (elm && !ew.isHidden(elm) && !ew.hasValue(elm))
					return this.onError(elm, "<?php echo JsEncode(str_replace("%s", $userpurchase_edit->txgroupid->caption(), $userpurchase_edit->txgroupid->RequiredErrorMessage)) ?>");
			<?php } ?>
				elm = this.getElements("x" + infix + "_txgroupid");
				if (elm && !ew.checkInteger(elm.value))
					return this.onError(elm, "<?php echo JsEncode($userpurchase_edit->txgroupid->errorMessage()) ?>");
			<?php if ($userpurchase_edit->success_status->Required) { ?>
				elm = this.getElements("x" + infix + "_success_status");
				if (elm && !ew.isHidden(elm) && !ew.hasValue(elm))
					return this.onError(elm, "<?php echo JsEncode(str_replace("%s", $userpurchase_edit->success_status->caption(), $userpurchase_edit->success_status->RequiredErrorMessage)) ?>");
			<?php } ?>
			<?php if ($userpurchase_edit->error_msg->Required) { ?>
				elm = this.getElements("x" + infix + "_error_msg");
				if (elm && !ew.isHidden(elm) && !ew.hasValue(elm))
					return this.onError(elm, "<?php echo JsEncode(str_replace("%s", $userpurchase_edit->error_msg->caption(), $userpurchase_edit->error_msg->RequiredErrorMessage)) ?>");
			<?php } ?>
			<?php if ($userpurchase_edit->userpiid->Required) { ?>
				elm = this.getElements("x" + infix + "_userpiid");
				if (elm && !ew.isHidden(elm) && !ew.hasValue(elm))
					return this.onError(elm, "<?php echo JsEncode(str_replace("%s", $userpurchase_edit->userpiid->caption(), $userpurchase_edit->userpiid->RequiredErrorMessage)) ?>");
			<?php } ?>
				elm = this.getElements("x" + infix + "_userpiid");
				if (elm && !ew.checkInteger(elm.value))
					return this.onError(elm, "<?php echo JsEncode($userpurchase_edit->userpiid->errorMessage()) ?>");
			<?php if ($userpurchase_edit->notes->Required) { ?>
				elm = this.getElements("x" + infix + "_notes");
				if (elm && !ew.isHidden(elm) && !ew.hasValue(elm))
					return this.onError(elm, "<?php echo JsEncode(str_replace("%s", $userpurchase_edit->notes->caption(), $userpurchase_edit->notes->RequiredErrorMessage)) ?>");
			<?php } ?>
			<?php if ($userpurchase_edit->lastpurchasereaddate->Required) { ?>
				elm = this.getElements("x" + infix + "_lastpurchasereaddate");
				if (elm && !ew.isHidden(elm) && !ew.hasValue(elm))
					return this.onError(elm, "<?php echo JsEncode(str_replace("%s", $userpurchase_edit->lastpurchasereaddate->caption(), $userpurchase_edit->lastpurchasereaddate->RequiredErrorMessage)) ?>");
			<?php } ?>
				elm = this.getElements("x" + infix + "_lastpurchasereaddate");
				if (elm && !ew.checkDateDef(elm.value))
					return this.onError(elm, "<?php echo JsEncode($userpurchase_edit->lastpurchasereaddate->errorMessage()) ?>");
			<?php if ($userpurchase_edit->retryapicount->Required) { ?>
				elm = this.getElements("x" + infix + "_retryapicount");
				if (elm && !ew.isHidden(elm) && !ew.hasValue(elm))
					return this.onError(elm, "<?php echo JsEncode(str_replace("%s", $userpurchase_edit->retryapicount->caption(), $userpurchase_edit->retryapicount->RequiredErrorMessage)) ?>");
			<?php } ?>
				elm = this.getElements("x" + infix + "_retryapicount");
				if (elm && !ew.checkInteger(elm.value))
					return this.onError(elm, "<?php echo JsEncode($userpurchase_edit->retryapicount->errorMessage()) ?>");

				// Call Form_CustomValidate event
				if (!this.Form_CustomValidate(fobj))
					return false;
		}

		// Process detail forms
		var dfs = $fobj.find("input[name='detailpage']").get();
		for (var i = 0; i < dfs.length; i++) {
			var df = dfs[i], val = df.value;
			if (val && ew.forms[val])
				if (!ew.forms[val].validate())
					return false;
		}
		return true;
	}

	// Form_CustomValidate
	fuserpurchaseedit.Form_CustomValidate = function(fobj) { // DO NOT CHANGE THIS LINE!

		// Your custom validation code here, return false if invalid.
		return true;
	}

	// Use JavaScript validation or not
	fuserpurchaseedit.validateRequired = <?php echo Config("CLIENT_VALIDATE") ? "true" : "false" ?>;

	// Multi-Page
	fuserpurchaseedit.multiPage = new ew.MultiPage("fuserpurchaseedit");

	// Dynamic selection lists
	fuserpurchaseedit.lists["x_userpi"] = <?php echo $userpurchase_edit->userpi->Lookup->toClientList($userpurchase_edit) ?>;
	fuserpurchaseedit.lists["x_userpi"].options = <?php echo JsonEncode($userpurchase_edit->userpi->lookupOptions()) ?>;
	fuserpurchaseedit.autoSuggests["x_userpi"] = <?php echo json_encode(["data" => "ajax=autosuggest"]) ?>;
	fuserpurchaseedit.lists["x_refunded"] = <?php echo $userpurchase_edit->refunded->Lookup->toClientList($userpurchase_edit) ?>;
	fuserpurchaseedit.lists["x_refunded"].options = <?php echo JsonEncode($userpurchase_edit->refunded->options(FALSE, TRUE)) ?>;
	fuserpurchaseedit.lists["x_success_status"] = <?php echo $userpurchase_edit->success_status->Lookup->toClientList($userpurchase_edit) ?>;
	fuserpurchaseedit.lists["x_success_status"].options = <?php echo JsonEncode($userpurchase_edit->success_status->options(FALSE, TRUE)) ?>;
	loadjs.done("fuserpurchaseedit");
});
</script>
<script>
loadjs.ready("head", function() {

	// Client script
	// Write your client script here, no need to add script tags.

});
</script>
<?php $userpurchase_edit->showPageHeader(); ?>
<?php
$userpurchase_edit->showMessage();
?>
<form name="fuserpurchaseedit" id="fuserpurchaseedit" class="<?php echo $userpurchase_edit->FormClassName ?>" action="<?php echo CurrentPageName() ?>" method="post">
<?php if ($Page->CheckToken) { ?>
<input type="hidden" name="<?php echo Config("TOKEN_NAME") ?>" value="<?php echo $Page->Token ?>">
<?php } ?>
<input type="hidden" name="t" value="userpurchase">
<input type="hidden" name="action" id="action" value="update">
<input type="hidden" name="modal" value="<?php echo (int)$userpurchase_edit->IsModal ?>">
<?php if ($userpurchase->getCurrentMasterTable() == "user") { ?>
<input type="hidden" name="<?php echo Config("TABLE_SHOW_MASTER") ?>" value="user">
<input type="hidden" name="fk_id" value="<?php echo HtmlEncode($userpurchase_edit->_userid->getSessionValue()) ?>">
<?php } ?>
<div class="ew-multi-page"><!-- multi-page -->
<div class="ew-nav-tabs" id="userpurchase_edit"><!-- multi-page tabs -->
	<ul class="<?php echo $userpurchase_edit->MultiPages->navStyle() ?>">
		<li class="nav-item"><a class="nav-link<?php echo $userpurchase_edit->MultiPages->pageStyle(1) ?>" href="#tab_userpurchase1" data-toggle="tab"><?php echo $userpurchase->pageCaption(1) ?></a></li>
		<li class="nav-item"><a class="nav-link<?php echo $userpurchase_edit->MultiPages->pageStyle(2) ?>" href="#tab_userpurchase2" data-toggle="tab"><?php echo $userpurchase->pageCaption(2) ?></a></li>
		<li class="nav-item"><a class="nav-link<?php echo $userpurchase_edit->MultiPages->pageStyle(3) ?>" href="#tab_userpurchase3" data-toggle="tab"><?php echo $userpurchase->pageCaption(3) ?></a></li>
	</ul>
	<div class="tab-content"><!-- multi-page tabs .tab-content -->
		<div class="tab-pane<?php echo $userpurchase_edit->MultiPages->pageStyle(1) ?>" id="tab_userpurchase1"><!-- multi-page .tab-pane -->
<div class="ew-edit-div"><!-- page* -->
<?php if ($userpurchase_edit->purchaseid->Visible) { // purchaseid ?>
	<div id="r_purchaseid" class="form-group row">
		<label id="elh_userpurchase_purchaseid" class="<?php echo $userpurchase_edit->LeftColumnClass ?>"><?php echo $userpurchase_edit->purchaseid->caption() ?><?php echo $userpurchase_edit->purchaseid->Required ? $Language->phrase("FieldRequiredIndicator") : "" ?></label>
		<div class="<?php echo $userpurchase_edit->RightColumnClass ?>"><div <?php echo $userpurchase_edit->purchaseid->cellAttributes() ?>>
<span id="el_userpurchase_purchaseid">
<span<?php echo $userpurchase_edit->purchaseid->viewAttributes() ?>><?php if (!EmptyString($userpurchase_edit->purchaseid->EditValue) && $userpurchase_edit->purchaseid->linkAttributes() != "") { ?>
<a<?php echo $userpurchase_edit->purchaseid->linkAttributes() ?>><input type="text" readonly class="form-control-plaintext" value="<?php echo HtmlEncode(RemoveHtml($userpurchase_edit->purchaseid->EditValue)) ?>"></a>
<?php } else { ?>
<input type="text" readonly class="form-control-plaintext" value="<?php echo HtmlEncode(RemoveHtml($userpurchase_edit->purchaseid->EditValue)) ?>">
<?php } ?></span>
</span>
<input type="hidden" data-table="userpurchase" data-field="x_purchaseid" data-page="1" name="x_purchaseid" id="x_purchaseid" value="<?php echo HtmlEncode($userpurchase_edit->purchaseid->CurrentValue) ?>">
<?php echo $userpurchase_edit->purchaseid->CustomMsg ?></div></div>
	</div>
<?php } ?>
<?php if ($userpurchase_edit->_userid->Visible) { // userid ?>
	<div id="r__userid" class="form-group row">
		<label id="elh_userpurchase__userid" for="x__userid" class="<?php echo $userpurchase_edit->LeftColumnClass ?>"><?php echo $userpurchase_edit->_userid->caption() ?><?php echo $userpurchase_edit->_userid->Required ? $Language->phrase("FieldRequiredIndicator") : "" ?></label>
		<div class="<?php echo $userpurchase_edit->RightColumnClass ?>"><div <?php echo $userpurchase_edit->_userid->cellAttributes() ?>>
<?php if ($userpurchase_edit->_userid->getSessionValue() != "") { ?>
<span id="el_userpurchase__userid">
<span<?php echo $userpurchase_edit->_userid->viewAttributes() ?>><?php if (!EmptyString($userpurchase_edit->_userid->ViewValue) && $userpurchase_edit->_userid->linkAttributes() != "") { ?>
<a<?php echo $userpurchase_edit->_userid->linkAttributes() ?>><input type="text" readonly class="form-control-plaintext" value="<?php echo HtmlEncode(RemoveHtml($userpurchase_edit->_userid->ViewValue)) ?>"></a>
<?php } else { ?>
<input type="text" readonly class="form-control-plaintext" value="<?php echo HtmlEncode(RemoveHtml($userpurchase_edit->_userid->ViewValue)) ?>">
<?php } ?></span>
</span>
<input type="hidden" id="x__userid" name="x__userid" value="<?php echo HtmlEncode($userpurchase_edit->_userid->CurrentValue) ?>">
<?php } else { ?>
<span id="el_userpurchase__userid">
<input type="text" data-table="userpurchase" data-field="x__userid" data-page="1" name="x__userid" id="x__userid" size="30" placeholder="<?php echo HtmlEncode($userpurchase_edit->_userid->getPlaceHolder()) ?>" value="<?php echo $userpurchase_edit->_userid->EditValue ?>"<?php echo $userpurchase_edit->_userid->editAttributes() ?>>
</span>
<?php } ?>
<?php echo $userpurchase_edit->_userid->CustomMsg ?></div></div>
	</div>
<?php } ?>
<?php if ($userpurchase_edit->merchantnodeid->Visible) { // merchantnodeid ?>
	<div id="r_merchantnodeid" class="form-group row">
		<label id="elh_userpurchase_merchantnodeid" for="x_merchantnodeid" class="<?php echo $userpurchase_edit->LeftColumnClass ?>"><?php echo $userpurchase_edit->merchantnodeid->caption() ?><?php echo $userpurchase_edit->merchantnodeid->Required ? $Language->phrase("FieldRequiredIndicator") : "" ?></label>
		<div class="<?php echo $userpurchase_edit->RightColumnClass ?>"><div <?php echo $userpurchase_edit->merchantnodeid->cellAttributes() ?>>
<span id="el_userpurchase_merchantnodeid">
<input type="text" data-table="userpurchase" data-field="x_merchantnodeid" data-page="1" name="x_merchantnodeid" id="x_merchantnodeid" size="30" placeholder="<?php echo HtmlEncode($userpurchase_edit->merchantnodeid->getPlaceHolder()) ?>" value="<?php echo $userpurchase_edit->merchantnodeid->EditValue ?>"<?php echo $userpurchase_edit->merchantnodeid->editAttributes() ?>>
</span>
<?php echo $userpurchase_edit->merchantnodeid->CustomMsg ?></div></div>
	</div>
<?php } ?>
<?php if ($userpurchase_edit->merchantid->Visible) { // merchantid ?>
	<div id="r_merchantid" class="form-group row">
		<label id="elh_userpurchase_merchantid" for="x_merchantid" class="<?php echo $userpurchase_edit->LeftColumnClass ?>"><?php echo $userpurchase_edit->merchantid->caption() ?><?php echo $userpurchase_edit->merchantid->Required ? $Language->phrase("FieldRequiredIndicator") : "" ?></label>
		<div class="<?php echo $userpurchase_edit->RightColumnClass ?>"><div <?php echo $userpurchase_edit->merchantid->cellAttributes() ?>>
<span id="el_userpurchase_merchantid">
<input type="text" data-table="userpurchase" data-field="x_merchantid" data-page="1" name="x_merchantid" id="x_merchantid" size="30" placeholder="<?php echo HtmlEncode($userpurchase_edit->merchantid->getPlaceHolder()) ?>" value="<?php echo $userpurchase_edit->merchantid->EditValue ?>"<?php echo $userpurchase_edit->merchantid->editAttributes() ?>>
</span>
<?php echo $userpurchase_edit->merchantid->CustomMsg ?></div></div>
	</div>
<?php } ?>
<?php if ($userpurchase_edit->merchantbusinessname->Visible) { // merchantbusinessname ?>
	<div id="r_merchantbusinessname" class="form-group row">
		<label id="elh_userpurchase_merchantbusinessname" for="x_merchantbusinessname" class="<?php echo $userpurchase_edit->LeftColumnClass ?>"><?php echo $userpurchase_edit->merchantbusinessname->caption() ?><?php echo $userpurchase_edit->merchantbusinessname->Required ? $Language->phrase("FieldRequiredIndicator") : "" ?></label>
		<div class="<?php echo $userpurchase_edit->RightColumnClass ?>"><div <?php echo $userpurchase_edit->merchantbusinessname->cellAttributes() ?>>
<span id="el_userpurchase_merchantbusinessname">
<input type="text" data-table="userpurchase" data-field="x_merchantbusinessname" data-page="1" name="x_merchantbusinessname" id="x_merchantbusinessname" size="30" maxlength="60" placeholder="<?php echo HtmlEncode($userpurchase_edit->merchantbusinessname->getPlaceHolder()) ?>" value="<?php echo $userpurchase_edit->merchantbusinessname->EditValue ?>"<?php echo $userpurchase_edit->merchantbusinessname->editAttributes() ?>>
</span>
<?php echo $userpurchase_edit->merchantbusinessname->CustomMsg ?></div></div>
	</div>
<?php } ?>
<?php if ($userpurchase_edit->merchanttransferid->Visible) { // merchanttransferid ?>
	<div id="r_merchanttransferid" class="form-group row">
		<label id="elh_userpurchase_merchanttransferid" for="x_merchanttransferid" class="<?php echo $userpurchase_edit->LeftColumnClass ?>"><?php echo $userpurchase_edit->merchanttransferid->caption() ?><?php echo $userpurchase_edit->merchanttransferid->Required ? $Language->phrase("FieldRequiredIndicator") : "" ?></label>
		<div class="<?php echo $userpurchase_edit->RightColumnClass ?>"><div <?php echo $userpurchase_edit->merchanttransferid->cellAttributes() ?>>
<span id="el_userpurchase_merchanttransferid">
<input type="text" data-table="userpurchase" data-field="x_merchanttransferid" data-page="1" name="x_merchanttransferid" id="x_merchanttransferid" size="30" placeholder="<?php echo HtmlEncode($userpurchase_edit->merchanttransferid->getPlaceHolder()) ?>" value="<?php echo $userpurchase_edit->merchanttransferid->EditValue ?>"<?php echo $userpurchase_edit->merchanttransferid->editAttributes() ?>>
</span>
<?php echo $userpurchase_edit->merchanttransferid->CustomMsg ?></div></div>
	</div>
<?php } ?>
<?php if ($userpurchase_edit->merchantuserid->Visible) { // merchantuserid ?>
	<div id="r_merchantuserid" class="form-group row">
		<label id="elh_userpurchase_merchantuserid" for="x_merchantuserid" class="<?php echo $userpurchase_edit->LeftColumnClass ?>"><?php echo $userpurchase_edit->merchantuserid->caption() ?><?php echo $userpurchase_edit->merchantuserid->Required ? $Language->phrase("FieldRequiredIndicator") : "" ?></label>
		<div class="<?php echo $userpurchase_edit->RightColumnClass ?>"><div <?php echo $userpurchase_edit->merchantuserid->cellAttributes() ?>>
<span id="el_userpurchase_merchantuserid">
<input type="text" data-table="userpurchase" data-field="x_merchantuserid" data-page="1" name="x_merchantuserid" id="x_merchantuserid" size="30" placeholder="<?php echo HtmlEncode($userpurchase_edit->merchantuserid->getPlaceHolder()) ?>" value="<?php echo $userpurchase_edit->merchantuserid->EditValue ?>"<?php echo $userpurchase_edit->merchantuserid->editAttributes() ?>>
</span>
<?php echo $userpurchase_edit->merchantuserid->CustomMsg ?></div></div>
	</div>
<?php } ?>
<?php if ($userpurchase_edit->purchasedate->Visible) { // purchasedate ?>
	<div id="r_purchasedate" class="form-group row">
		<label id="elh_userpurchase_purchasedate" for="x_purchasedate" class="<?php echo $userpurchase_edit->LeftColumnClass ?>"><?php echo $userpurchase_edit->purchasedate->caption() ?><?php echo $userpurchase_edit->purchasedate->Required ? $Language->phrase("FieldRequiredIndicator") : "" ?></label>
		<div class="<?php echo $userpurchase_edit->RightColumnClass ?>"><div <?php echo $userpurchase_edit->purchasedate->cellAttributes() ?>>
<span id="el_userpurchase_purchasedate">
<input type="text" data-table="userpurchase" data-field="x_purchasedate" data-page="1" data-format="1" name="x_purchasedate" id="x_purchasedate" placeholder="<?php echo HtmlEncode($userpurchase_edit->purchasedate->getPlaceHolder()) ?>" value="<?php echo $userpurchase_edit->purchasedate->EditValue ?>"<?php echo $userpurchase_edit->purchasedate->editAttributes() ?>>
<?php if (!$userpurchase_edit->purchasedate->ReadOnly && !$userpurchase_edit->purchasedate->Disabled && !isset($userpurchase_edit->purchasedate->EditAttrs["readonly"]) && !isset($userpurchase_edit->purchasedate->EditAttrs["disabled"])) { ?>
<script>
loadjs.ready(["fuserpurchaseedit", "datetimepicker"], function() {
	ew.createDateTimePicker("fuserpurchaseedit", "x_purchasedate", {"ignoreReadonly":true,"useCurrent":false,"format":1});
});
</script>
<?php } ?>
</span>
<?php echo $userpurchase_edit->purchasedate->CustomMsg ?></div></div>
	</div>
<?php } ?>
<?php if ($userpurchase_edit->txid->Visible) { // txid ?>
	<div id="r_txid" class="form-group row">
		<label id="elh_userpurchase_txid" for="x_txid" class="<?php echo $userpurchase_edit->LeftColumnClass ?>"><?php echo $userpurchase_edit->txid->caption() ?><?php echo $userpurchase_edit->txid->Required ? $Language->phrase("FieldRequiredIndicator") : "" ?></label>
		<div class="<?php echo $userpurchase_edit->RightColumnClass ?>"><div <?php echo $userpurchase_edit->txid->cellAttributes() ?>>
<span id="el_userpurchase_txid">
<input type="text" data-table="userpurchase" data-field="x_txid" data-page="1" name="x_txid" id="x_txid" size="30" maxlength="10" placeholder="<?php echo HtmlEncode($userpurchase_edit->txid->getPlaceHolder()) ?>" value="<?php echo $userpurchase_edit->txid->EditValue ?>"<?php echo $userpurchase_edit->txid->editAttributes() ?>>
</span>
<?php echo $userpurchase_edit->txid->CustomMsg ?></div></div>
	</div>
<?php } ?>
<?php if ($userpurchase_edit->userpi->Visible) { // userpi ?>
	<div id="r_userpi" class="form-group row">
		<label id="elh_userpurchase_userpi" class="<?php echo $userpurchase_edit->LeftColumnClass ?>"><?php echo $userpurchase_edit->userpi->caption() ?><?php echo $userpurchase_edit->userpi->Required ? $Language->phrase("FieldRequiredIndicator") : "" ?></label>
		<div class="<?php echo $userpurchase_edit->RightColumnClass ?>"><div <?php echo $userpurchase_edit->userpi->cellAttributes() ?>>
<span id="el_userpurchase_userpi">
<?php
$onchange = $userpurchase_edit->userpi->EditAttrs->prepend("onchange", "");
$onchange = ($onchange) ? ' onchange="' . JsEncode($onchange) . '"' : '';
$userpurchase_edit->userpi->EditAttrs["onchange"] = "";
?>
<span id="as_x_userpi">
	<input type="text" class="form-control" name="sv_x_userpi" id="sv_x_userpi" value="<?php echo RemoveHtml($userpurchase_edit->userpi->EditValue) ?>" size="30" placeholder="<?php echo HtmlEncode($userpurchase_edit->userpi->getPlaceHolder()) ?>" data-placeholder="<?php echo HtmlEncode($userpurchase_edit->userpi->getPlaceHolder()) ?>"<?php echo $userpurchase_edit->userpi->editAttributes() ?>>
</span>
<input type="hidden" data-table="userpurchase" data-field="x_userpi" data-page="1" data-value-separator="<?php echo $userpurchase_edit->userpi->displayValueSeparatorAttribute() ?>" name="x_userpi" id="x_userpi" value="<?php echo HtmlEncode($userpurchase_edit->userpi->CurrentValue) ?>"<?php echo $onchange ?>>
<script>
loadjs.ready(["fuserpurchaseedit"], function() {
	fuserpurchaseedit.createAutoSuggest({"id":"x_userpi","forceSelect":false});
});
</script>
<?php echo $userpurchase_edit->userpi->Lookup->getParamTag($userpurchase_edit, "p_x_userpi") ?>
</span>
<?php echo $userpurchase_edit->userpi->CustomMsg ?></div></div>
	</div>
<?php } ?>
<?php if ($userpurchase_edit->currencycode->Visible) { // currencycode ?>
	<div id="r_currencycode" class="form-group row">
		<label id="elh_userpurchase_currencycode" for="x_currencycode" class="<?php echo $userpurchase_edit->LeftColumnClass ?>"><?php echo $userpurchase_edit->currencycode->caption() ?><?php echo $userpurchase_edit->currencycode->Required ? $Language->phrase("FieldRequiredIndicator") : "" ?></label>
		<div class="<?php echo $userpurchase_edit->RightColumnClass ?>"><div <?php echo $userpurchase_edit->currencycode->cellAttributes() ?>>
<span id="el_userpurchase_currencycode">
<input type="text" data-table="userpurchase" data-field="x_currencycode" data-page="1" name="x_currencycode" id="x_currencycode" size="10" maxlength="3" placeholder="<?php echo HtmlEncode($userpurchase_edit->currencycode->getPlaceHolder()) ?>" value="<?php echo $userpurchase_edit->currencycode->EditValue ?>"<?php echo $userpurchase_edit->currencycode->editAttributes() ?>>
</span>
<?php echo $userpurchase_edit->currencycode->CustomMsg ?></div></div>
	</div>
<?php } ?>
<?php if ($userpurchase_edit->purchaseamount->Visible) { // purchaseamount ?>
	<div id="r_purchaseamount" class="form-group row">
		<label id="elh_userpurchase_purchaseamount" for="x_purchaseamount" class="<?php echo $userpurchase_edit->LeftColumnClass ?>"><?php echo $userpurchase_edit->purchaseamount->caption() ?><?php echo $userpurchase_edit->purchaseamount->Required ? $Language->phrase("FieldRequiredIndicator") : "" ?></label>
		<div class="<?php echo $userpurchase_edit->RightColumnClass ?>"><div <?php echo $userpurchase_edit->purchaseamount->cellAttributes() ?>>
<span id="el_userpurchase_purchaseamount">
<input type="text" data-table="userpurchase" data-field="x_purchaseamount" data-page="1" name="x_purchaseamount" id="x_purchaseamount" size="30" placeholder="<?php echo HtmlEncode($userpurchase_edit->purchaseamount->getPlaceHolder()) ?>" value="<?php echo $userpurchase_edit->purchaseamount->EditValue ?>"<?php echo $userpurchase_edit->purchaseamount->editAttributes() ?>>
</span>
<?php echo $userpurchase_edit->purchaseamount->CustomMsg ?></div></div>
	</div>
<?php } ?>
<?php if ($userpurchase_edit->tipamount->Visible) { // tipamount ?>
	<div id="r_tipamount" class="form-group row">
		<label id="elh_userpurchase_tipamount" for="x_tipamount" class="<?php echo $userpurchase_edit->LeftColumnClass ?>"><?php echo $userpurchase_edit->tipamount->caption() ?><?php echo $userpurchase_edit->tipamount->Required ? $Language->phrase("FieldRequiredIndicator") : "" ?></label>
		<div class="<?php echo $userpurchase_edit->RightColumnClass ?>"><div <?php echo $userpurchase_edit->tipamount->cellAttributes() ?>>
<span id="el_userpurchase_tipamount">
<input type="text" data-table="userpurchase" data-field="x_tipamount" data-page="1" name="x_tipamount" id="x_tipamount" size="30" placeholder="<?php echo HtmlEncode($userpurchase_edit->tipamount->getPlaceHolder()) ?>" value="<?php echo $userpurchase_edit->tipamount->EditValue ?>"<?php echo $userpurchase_edit->tipamount->editAttributes() ?>>
</span>
<?php echo $userpurchase_edit->tipamount->CustomMsg ?></div></div>
	</div>
<?php } ?>
<?php if ($userpurchase_edit->merchantfees->Visible) { // merchantfees ?>
	<div id="r_merchantfees" class="form-group row">
		<label id="elh_userpurchase_merchantfees" for="x_merchantfees" class="<?php echo $userpurchase_edit->LeftColumnClass ?>"><?php echo $userpurchase_edit->merchantfees->caption() ?><?php echo $userpurchase_edit->merchantfees->Required ? $Language->phrase("FieldRequiredIndicator") : "" ?></label>
		<div class="<?php echo $userpurchase_edit->RightColumnClass ?>"><div <?php echo $userpurchase_edit->merchantfees->cellAttributes() ?>>
<span id="el_userpurchase_merchantfees">
<input type="text" data-table="userpurchase" data-field="x_merchantfees" data-page="1" name="x_merchantfees" id="x_merchantfees" size="30" placeholder="<?php echo HtmlEncode($userpurchase_edit->merchantfees->getPlaceHolder()) ?>" value="<?php echo $userpurchase_edit->merchantfees->EditValue ?>"<?php echo $userpurchase_edit->merchantfees->editAttributes() ?>>
</span>
<?php echo $userpurchase_edit->merchantfees->CustomMsg ?></div></div>
	</div>
<?php } ?>
<?php if ($userpurchase_edit->transferid->Visible) { // transferid ?>
	<div id="r_transferid" class="form-group row">
		<label id="elh_userpurchase_transferid" for="x_transferid" class="<?php echo $userpurchase_edit->LeftColumnClass ?>"><?php echo $userpurchase_edit->transferid->caption() ?><?php echo $userpurchase_edit->transferid->Required ? $Language->phrase("FieldRequiredIndicator") : "" ?></label>
		<div class="<?php echo $userpurchase_edit->RightColumnClass ?>"><div <?php echo $userpurchase_edit->transferid->cellAttributes() ?>>
<span id="el_userpurchase_transferid">
<input type="text" data-table="userpurchase" data-field="x_transferid" data-page="1" name="x_transferid" id="x_transferid" size="30" placeholder="<?php echo HtmlEncode($userpurchase_edit->transferid->getPlaceHolder()) ?>" value="<?php echo $userpurchase_edit->transferid->EditValue ?>"<?php echo $userpurchase_edit->transferid->editAttributes() ?>>
</span>
<?php echo $userpurchase_edit->transferid->CustomMsg ?></div></div>
	</div>
<?php } ?>
<?php if ($userpurchase_edit->merchantSurcharge->Visible) { // merchantSurcharge ?>
	<div id="r_merchantSurcharge" class="form-group row">
		<label id="elh_userpurchase_merchantSurcharge" for="x_merchantSurcharge" class="<?php echo $userpurchase_edit->LeftColumnClass ?>"><?php echo $userpurchase_edit->merchantSurcharge->caption() ?><?php echo $userpurchase_edit->merchantSurcharge->Required ? $Language->phrase("FieldRequiredIndicator") : "" ?></label>
		<div class="<?php echo $userpurchase_edit->RightColumnClass ?>"><div <?php echo $userpurchase_edit->merchantSurcharge->cellAttributes() ?>>
<span id="el_userpurchase_merchantSurcharge">
<input type="text" data-table="userpurchase" data-field="x_merchantSurcharge" data-page="1" name="x_merchantSurcharge" id="x_merchantSurcharge" size="30" placeholder="<?php echo HtmlEncode($userpurchase_edit->merchantSurcharge->getPlaceHolder()) ?>" value="<?php echo $userpurchase_edit->merchantSurcharge->EditValue ?>"<?php echo $userpurchase_edit->merchantSurcharge->editAttributes() ?>>
</span>
<?php echo $userpurchase_edit->merchantSurcharge->CustomMsg ?></div></div>
	</div>
<?php } ?>
<?php if ($userpurchase_edit->taxAmount->Visible) { // taxAmount ?>
	<div id="r_taxAmount" class="form-group row">
		<label id="elh_userpurchase_taxAmount" for="x_taxAmount" class="<?php echo $userpurchase_edit->LeftColumnClass ?>"><?php echo $userpurchase_edit->taxAmount->caption() ?><?php echo $userpurchase_edit->taxAmount->Required ? $Language->phrase("FieldRequiredIndicator") : "" ?></label>
		<div class="<?php echo $userpurchase_edit->RightColumnClass ?>"><div <?php echo $userpurchase_edit->taxAmount->cellAttributes() ?>>
<span id="el_userpurchase_taxAmount">
<input type="text" data-table="userpurchase" data-field="x_taxAmount" data-page="1" name="x_taxAmount" id="x_taxAmount" size="30" placeholder="<?php echo HtmlEncode($userpurchase_edit->taxAmount->getPlaceHolder()) ?>" value="<?php echo $userpurchase_edit->taxAmount->EditValue ?>"<?php echo $userpurchase_edit->taxAmount->editAttributes() ?>>
</span>
<?php echo $userpurchase_edit->taxAmount->CustomMsg ?></div></div>
	</div>
<?php } ?>
<?php if ($userpurchase_edit->totalAmounForCustomer->Visible) { // totalAmounForCustomer ?>
	<div id="r_totalAmounForCustomer" class="form-group row">
		<label id="elh_userpurchase_totalAmounForCustomer" for="x_totalAmounForCustomer" class="<?php echo $userpurchase_edit->LeftColumnClass ?>"><?php echo $userpurchase_edit->totalAmounForCustomer->caption() ?><?php echo $userpurchase_edit->totalAmounForCustomer->Required ? $Language->phrase("FieldRequiredIndicator") : "" ?></label>
		<div class="<?php echo $userpurchase_edit->RightColumnClass ?>"><div <?php echo $userpurchase_edit->totalAmounForCustomer->cellAttributes() ?>>
<span id="el_userpurchase_totalAmounForCustomer">
<input type="text" data-table="userpurchase" data-field="x_totalAmounForCustomer" data-page="1" name="x_totalAmounForCustomer" id="x_totalAmounForCustomer" size="30" placeholder="<?php echo HtmlEncode($userpurchase_edit->totalAmounForCustomer->getPlaceHolder()) ?>" value="<?php echo $userpurchase_edit->totalAmounForCustomer->EditValue ?>"<?php echo $userpurchase_edit->totalAmounForCustomer->editAttributes() ?>>
</span>
<?php echo $userpurchase_edit->totalAmounForCustomer->CustomMsg ?></div></div>
	</div>
<?php } ?>
<?php if ($userpurchase_edit->cardno->Visible) { // cardno ?>
	<div id="r_cardno" class="form-group row">
		<label id="elh_userpurchase_cardno" for="x_cardno" class="<?php echo $userpurchase_edit->LeftColumnClass ?>"><?php echo $userpurchase_edit->cardno->caption() ?><?php echo $userpurchase_edit->cardno->Required ? $Language->phrase("FieldRequiredIndicator") : "" ?></label>
		<div class="<?php echo $userpurchase_edit->RightColumnClass ?>"><div <?php echo $userpurchase_edit->cardno->cellAttributes() ?>>
<span id="el_userpurchase_cardno">
<input type="text" data-table="userpurchase" data-field="x_cardno" data-page="1" name="x_cardno" id="x_cardno" size="30" maxlength="4" placeholder="<?php echo HtmlEncode($userpurchase_edit->cardno->getPlaceHolder()) ?>" value="<?php echo $userpurchase_edit->cardno->EditValue ?>"<?php echo $userpurchase_edit->cardno->editAttributes() ?>>
</span>
<?php echo $userpurchase_edit->cardno->CustomMsg ?></div></div>
	</div>
<?php } ?>
<?php if ($userpurchase_edit->_key->Visible) { // key ?>
	<div id="r__key" class="form-group row">
		<label id="elh_userpurchase__key" for="x__key" class="<?php echo $userpurchase_edit->LeftColumnClass ?>"><?php echo $userpurchase_edit->_key->caption() ?><?php echo $userpurchase_edit->_key->Required ? $Language->phrase("FieldRequiredIndicator") : "" ?></label>
		<div class="<?php echo $userpurchase_edit->RightColumnClass ?>"><div <?php echo $userpurchase_edit->_key->cellAttributes() ?>>
<span id="el_userpurchase__key">
<textarea data-table="userpurchase" data-field="x__key" data-page="1" name="x__key" id="x__key" cols="35" rows="4" placeholder="<?php echo HtmlEncode($userpurchase_edit->_key->getPlaceHolder()) ?>"<?php echo $userpurchase_edit->_key->editAttributes() ?>><?php echo $userpurchase_edit->_key->EditValue ?></textarea>
</span>
<?php echo $userpurchase_edit->_key->CustomMsg ?></div></div>
	</div>
<?php } ?>
<?php if ($userpurchase_edit->serviceFeeToCustomerbk1amt->Visible) { // serviceFeeToCustomerbk1amt ?>
	<div id="r_serviceFeeToCustomerbk1amt" class="form-group row">
		<label id="elh_userpurchase_serviceFeeToCustomerbk1amt" for="x_serviceFeeToCustomerbk1amt" class="<?php echo $userpurchase_edit->LeftColumnClass ?>"><?php echo $userpurchase_edit->serviceFeeToCustomerbk1amt->caption() ?><?php echo $userpurchase_edit->serviceFeeToCustomerbk1amt->Required ? $Language->phrase("FieldRequiredIndicator") : "" ?></label>
		<div class="<?php echo $userpurchase_edit->RightColumnClass ?>"><div <?php echo $userpurchase_edit->serviceFeeToCustomerbk1amt->cellAttributes() ?>>
<span id="el_userpurchase_serviceFeeToCustomerbk1amt">
<input type="text" data-table="userpurchase" data-field="x_serviceFeeToCustomerbk1amt" data-page="1" name="x_serviceFeeToCustomerbk1amt" id="x_serviceFeeToCustomerbk1amt" size="30" maxlength="22" placeholder="<?php echo HtmlEncode($userpurchase_edit->serviceFeeToCustomerbk1amt->getPlaceHolder()) ?>" value="<?php echo $userpurchase_edit->serviceFeeToCustomerbk1amt->EditValue ?>"<?php echo $userpurchase_edit->serviceFeeToCustomerbk1amt->editAttributes() ?>>
</span>
<?php echo $userpurchase_edit->serviceFeeToCustomerbk1amt->CustomMsg ?></div></div>
	</div>
<?php } ?>
<?php if ($userpurchase_edit->serviceFeeToCustomerbk1type->Visible) { // serviceFeeToCustomerbk1type ?>
	<div id="r_serviceFeeToCustomerbk1type" class="form-group row">
		<label id="elh_userpurchase_serviceFeeToCustomerbk1type" for="x_serviceFeeToCustomerbk1type" class="<?php echo $userpurchase_edit->LeftColumnClass ?>"><?php echo $userpurchase_edit->serviceFeeToCustomerbk1type->caption() ?><?php echo $userpurchase_edit->serviceFeeToCustomerbk1type->Required ? $Language->phrase("FieldRequiredIndicator") : "" ?></label>
		<div class="<?php echo $userpurchase_edit->RightColumnClass ?>"><div <?php echo $userpurchase_edit->serviceFeeToCustomerbk1type->cellAttributes() ?>>
<span id="el_userpurchase_serviceFeeToCustomerbk1type">
<input type="text" data-table="userpurchase" data-field="x_serviceFeeToCustomerbk1type" data-page="1" name="x_serviceFeeToCustomerbk1type" id="x_serviceFeeToCustomerbk1type" size="30" maxlength="15" placeholder="<?php echo HtmlEncode($userpurchase_edit->serviceFeeToCustomerbk1type->getPlaceHolder()) ?>" value="<?php echo $userpurchase_edit->serviceFeeToCustomerbk1type->EditValue ?>"<?php echo $userpurchase_edit->serviceFeeToCustomerbk1type->editAttributes() ?>>
</span>
<?php echo $userpurchase_edit->serviceFeeToCustomerbk1type->CustomMsg ?></div></div>
	</div>
<?php } ?>
<?php if ($userpurchase_edit->serviceFeeToCustomerbk2amt->Visible) { // serviceFeeToCustomerbk2amt ?>
	<div id="r_serviceFeeToCustomerbk2amt" class="form-group row">
		<label id="elh_userpurchase_serviceFeeToCustomerbk2amt" for="x_serviceFeeToCustomerbk2amt" class="<?php echo $userpurchase_edit->LeftColumnClass ?>"><?php echo $userpurchase_edit->serviceFeeToCustomerbk2amt->caption() ?><?php echo $userpurchase_edit->serviceFeeToCustomerbk2amt->Required ? $Language->phrase("FieldRequiredIndicator") : "" ?></label>
		<div class="<?php echo $userpurchase_edit->RightColumnClass ?>"><div <?php echo $userpurchase_edit->serviceFeeToCustomerbk2amt->cellAttributes() ?>>
<span id="el_userpurchase_serviceFeeToCustomerbk2amt">
<input type="text" data-table="userpurchase" data-field="x_serviceFeeToCustomerbk2amt" data-page="1" name="x_serviceFeeToCustomerbk2amt" id="x_serviceFeeToCustomerbk2amt" size="30" maxlength="22" placeholder="<?php echo HtmlEncode($userpurchase_edit->serviceFeeToCustomerbk2amt->getPlaceHolder()) ?>" value="<?php echo $userpurchase_edit->serviceFeeToCustomerbk2amt->EditValue ?>"<?php echo $userpurchase_edit->serviceFeeToCustomerbk2amt->editAttributes() ?>>
</span>
<?php echo $userpurchase_edit->serviceFeeToCustomerbk2amt->CustomMsg ?></div></div>
	</div>
<?php } ?>
<?php if ($userpurchase_edit->serviceFeeToCustomerbk2type->Visible) { // serviceFeeToCustomerbk2type ?>
	<div id="r_serviceFeeToCustomerbk2type" class="form-group row">
		<label id="elh_userpurchase_serviceFeeToCustomerbk2type" for="x_serviceFeeToCustomerbk2type" class="<?php echo $userpurchase_edit->LeftColumnClass ?>"><?php echo $userpurchase_edit->serviceFeeToCustomerbk2type->caption() ?><?php echo $userpurchase_edit->serviceFeeToCustomerbk2type->Required ? $Language->phrase("FieldRequiredIndicator") : "" ?></label>
		<div class="<?php echo $userpurchase_edit->RightColumnClass ?>"><div <?php echo $userpurchase_edit->serviceFeeToCustomerbk2type->cellAttributes() ?>>
<span id="el_userpurchase_serviceFeeToCustomerbk2type">
<input type="text" data-table="userpurchase" data-field="x_serviceFeeToCustomerbk2type" data-page="1" name="x_serviceFeeToCustomerbk2type" id="x_serviceFeeToCustomerbk2type" size="30" maxlength="15" placeholder="<?php echo HtmlEncode($userpurchase_edit->serviceFeeToCustomerbk2type->getPlaceHolder()) ?>" value="<?php echo $userpurchase_edit->serviceFeeToCustomerbk2type->EditValue ?>"<?php echo $userpurchase_edit->serviceFeeToCustomerbk2type->editAttributes() ?>>
</span>
<?php echo $userpurchase_edit->serviceFeeToCustomerbk2type->CustomMsg ?></div></div>
	</div>
<?php } ?>
<?php if ($userpurchase_edit->serviceFeeToCustomerbk3amt->Visible) { // serviceFeeToCustomerbk3amt ?>
	<div id="r_serviceFeeToCustomerbk3amt" class="form-group row">
		<label id="elh_userpurchase_serviceFeeToCustomerbk3amt" for="x_serviceFeeToCustomerbk3amt" class="<?php echo $userpurchase_edit->LeftColumnClass ?>"><?php echo $userpurchase_edit->serviceFeeToCustomerbk3amt->caption() ?><?php echo $userpurchase_edit->serviceFeeToCustomerbk3amt->Required ? $Language->phrase("FieldRequiredIndicator") : "" ?></label>
		<div class="<?php echo $userpurchase_edit->RightColumnClass ?>"><div <?php echo $userpurchase_edit->serviceFeeToCustomerbk3amt->cellAttributes() ?>>
<span id="el_userpurchase_serviceFeeToCustomerbk3amt">
<input type="text" data-table="userpurchase" data-field="x_serviceFeeToCustomerbk3amt" data-page="1" name="x_serviceFeeToCustomerbk3amt" id="x_serviceFeeToCustomerbk3amt" size="30" maxlength="22" placeholder="<?php echo HtmlEncode($userpurchase_edit->serviceFeeToCustomerbk3amt->getPlaceHolder()) ?>" value="<?php echo $userpurchase_edit->serviceFeeToCustomerbk3amt->EditValue ?>"<?php echo $userpurchase_edit->serviceFeeToCustomerbk3amt->editAttributes() ?>>
</span>
<?php echo $userpurchase_edit->serviceFeeToCustomerbk3amt->CustomMsg ?></div></div>
	</div>
<?php } ?>
<?php if ($userpurchase_edit->serviceFeeToCustomerbk3type->Visible) { // serviceFeeToCustomerbk3type ?>
	<div id="r_serviceFeeToCustomerbk3type" class="form-group row">
		<label id="elh_userpurchase_serviceFeeToCustomerbk3type" for="x_serviceFeeToCustomerbk3type" class="<?php echo $userpurchase_edit->LeftColumnClass ?>"><?php echo $userpurchase_edit->serviceFeeToCustomerbk3type->caption() ?><?php echo $userpurchase_edit->serviceFeeToCustomerbk3type->Required ? $Language->phrase("FieldRequiredIndicator") : "" ?></label>
		<div class="<?php echo $userpurchase_edit->RightColumnClass ?>"><div <?php echo $userpurchase_edit->serviceFeeToCustomerbk3type->cellAttributes() ?>>
<span id="el_userpurchase_serviceFeeToCustomerbk3type">
<input type="text" data-table="userpurchase" data-field="x_serviceFeeToCustomerbk3type" data-page="1" name="x_serviceFeeToCustomerbk3type" id="x_serviceFeeToCustomerbk3type" size="30" maxlength="15" placeholder="<?php echo HtmlEncode($userpurchase_edit->serviceFeeToCustomerbk3type->getPlaceHolder()) ?>" value="<?php echo $userpurchase_edit->serviceFeeToCustomerbk3type->EditValue ?>"<?php echo $userpurchase_edit->serviceFeeToCustomerbk3type->editAttributes() ?>>
</span>
<?php echo $userpurchase_edit->serviceFeeToCustomerbk3type->CustomMsg ?></div></div>
	</div>
<?php } ?>
<?php if ($userpurchase_edit->taxAmountbk1amt->Visible) { // taxAmountbk1amt ?>
	<div id="r_taxAmountbk1amt" class="form-group row">
		<label id="elh_userpurchase_taxAmountbk1amt" for="x_taxAmountbk1amt" class="<?php echo $userpurchase_edit->LeftColumnClass ?>"><?php echo $userpurchase_edit->taxAmountbk1amt->caption() ?><?php echo $userpurchase_edit->taxAmountbk1amt->Required ? $Language->phrase("FieldRequiredIndicator") : "" ?></label>
		<div class="<?php echo $userpurchase_edit->RightColumnClass ?>"><div <?php echo $userpurchase_edit->taxAmountbk1amt->cellAttributes() ?>>
<span id="el_userpurchase_taxAmountbk1amt">
<input type="text" data-table="userpurchase" data-field="x_taxAmountbk1amt" data-page="1" name="x_taxAmountbk1amt" id="x_taxAmountbk1amt" size="30" maxlength="22" placeholder="<?php echo HtmlEncode($userpurchase_edit->taxAmountbk1amt->getPlaceHolder()) ?>" value="<?php echo $userpurchase_edit->taxAmountbk1amt->EditValue ?>"<?php echo $userpurchase_edit->taxAmountbk1amt->editAttributes() ?>>
</span>
<?php echo $userpurchase_edit->taxAmountbk1amt->CustomMsg ?></div></div>
	</div>
<?php } ?>
<?php if ($userpurchase_edit->taxAmountbk1type->Visible) { // taxAmountbk1type ?>
	<div id="r_taxAmountbk1type" class="form-group row">
		<label id="elh_userpurchase_taxAmountbk1type" for="x_taxAmountbk1type" class="<?php echo $userpurchase_edit->LeftColumnClass ?>"><?php echo $userpurchase_edit->taxAmountbk1type->caption() ?><?php echo $userpurchase_edit->taxAmountbk1type->Required ? $Language->phrase("FieldRequiredIndicator") : "" ?></label>
		<div class="<?php echo $userpurchase_edit->RightColumnClass ?>"><div <?php echo $userpurchase_edit->taxAmountbk1type->cellAttributes() ?>>
<span id="el_userpurchase_taxAmountbk1type">
<input type="text" data-table="userpurchase" data-field="x_taxAmountbk1type" data-page="1" name="x_taxAmountbk1type" id="x_taxAmountbk1type" size="30" maxlength="15" placeholder="<?php echo HtmlEncode($userpurchase_edit->taxAmountbk1type->getPlaceHolder()) ?>" value="<?php echo $userpurchase_edit->taxAmountbk1type->EditValue ?>"<?php echo $userpurchase_edit->taxAmountbk1type->editAttributes() ?>>
</span>
<?php echo $userpurchase_edit->taxAmountbk1type->CustomMsg ?></div></div>
	</div>
<?php } ?>
<?php if ($userpurchase_edit->taxAmountbk2amt->Visible) { // taxAmountbk2amt ?>
	<div id="r_taxAmountbk2amt" class="form-group row">
		<label id="elh_userpurchase_taxAmountbk2amt" for="x_taxAmountbk2amt" class="<?php echo $userpurchase_edit->LeftColumnClass ?>"><?php echo $userpurchase_edit->taxAmountbk2amt->caption() ?><?php echo $userpurchase_edit->taxAmountbk2amt->Required ? $Language->phrase("FieldRequiredIndicator") : "" ?></label>
		<div class="<?php echo $userpurchase_edit->RightColumnClass ?>"><div <?php echo $userpurchase_edit->taxAmountbk2amt->cellAttributes() ?>>
<span id="el_userpurchase_taxAmountbk2amt">
<input type="text" data-table="userpurchase" data-field="x_taxAmountbk2amt" data-page="1" name="x_taxAmountbk2amt" id="x_taxAmountbk2amt" size="30" maxlength="22" placeholder="<?php echo HtmlEncode($userpurchase_edit->taxAmountbk2amt->getPlaceHolder()) ?>" value="<?php echo $userpurchase_edit->taxAmountbk2amt->EditValue ?>"<?php echo $userpurchase_edit->taxAmountbk2amt->editAttributes() ?>>
</span>
<?php echo $userpurchase_edit->taxAmountbk2amt->CustomMsg ?></div></div>
	</div>
<?php } ?>
<?php if ($userpurchase_edit->taxAmountbk2type->Visible) { // taxAmountbk2type ?>
	<div id="r_taxAmountbk2type" class="form-group row">
		<label id="elh_userpurchase_taxAmountbk2type" for="x_taxAmountbk2type" class="<?php echo $userpurchase_edit->LeftColumnClass ?>"><?php echo $userpurchase_edit->taxAmountbk2type->caption() ?><?php echo $userpurchase_edit->taxAmountbk2type->Required ? $Language->phrase("FieldRequiredIndicator") : "" ?></label>
		<div class="<?php echo $userpurchase_edit->RightColumnClass ?>"><div <?php echo $userpurchase_edit->taxAmountbk2type->cellAttributes() ?>>
<span id="el_userpurchase_taxAmountbk2type">
<input type="text" data-table="userpurchase" data-field="x_taxAmountbk2type" data-page="1" name="x_taxAmountbk2type" id="x_taxAmountbk2type" size="30" maxlength="15" placeholder="<?php echo HtmlEncode($userpurchase_edit->taxAmountbk2type->getPlaceHolder()) ?>" value="<?php echo $userpurchase_edit->taxAmountbk2type->EditValue ?>"<?php echo $userpurchase_edit->taxAmountbk2type->editAttributes() ?>>
</span>
<?php echo $userpurchase_edit->taxAmountbk2type->CustomMsg ?></div></div>
	</div>
<?php } ?>
<?php if ($userpurchase_edit->taxAmountbk3amt->Visible) { // taxAmountbk3amt ?>
	<div id="r_taxAmountbk3amt" class="form-group row">
		<label id="elh_userpurchase_taxAmountbk3amt" for="x_taxAmountbk3amt" class="<?php echo $userpurchase_edit->LeftColumnClass ?>"><?php echo $userpurchase_edit->taxAmountbk3amt->caption() ?><?php echo $userpurchase_edit->taxAmountbk3amt->Required ? $Language->phrase("FieldRequiredIndicator") : "" ?></label>
		<div class="<?php echo $userpurchase_edit->RightColumnClass ?>"><div <?php echo $userpurchase_edit->taxAmountbk3amt->cellAttributes() ?>>
<span id="el_userpurchase_taxAmountbk3amt">
<input type="text" data-table="userpurchase" data-field="x_taxAmountbk3amt" data-page="1" name="x_taxAmountbk3amt" id="x_taxAmountbk3amt" size="30" maxlength="22" placeholder="<?php echo HtmlEncode($userpurchase_edit->taxAmountbk3amt->getPlaceHolder()) ?>" value="<?php echo $userpurchase_edit->taxAmountbk3amt->EditValue ?>"<?php echo $userpurchase_edit->taxAmountbk3amt->editAttributes() ?>>
</span>
<?php echo $userpurchase_edit->taxAmountbk3amt->CustomMsg ?></div></div>
	</div>
<?php } ?>
<?php if ($userpurchase_edit->taxAmountbk3type->Visible) { // taxAmountbk3type ?>
	<div id="r_taxAmountbk3type" class="form-group row">
		<label id="elh_userpurchase_taxAmountbk3type" for="x_taxAmountbk3type" class="<?php echo $userpurchase_edit->LeftColumnClass ?>"><?php echo $userpurchase_edit->taxAmountbk3type->caption() ?><?php echo $userpurchase_edit->taxAmountbk3type->Required ? $Language->phrase("FieldRequiredIndicator") : "" ?></label>
		<div class="<?php echo $userpurchase_edit->RightColumnClass ?>"><div <?php echo $userpurchase_edit->taxAmountbk3type->cellAttributes() ?>>
<span id="el_userpurchase_taxAmountbk3type">
<input type="text" data-table="userpurchase" data-field="x_taxAmountbk3type" data-page="1" name="x_taxAmountbk3type" id="x_taxAmountbk3type" size="30" maxlength="15" placeholder="<?php echo HtmlEncode($userpurchase_edit->taxAmountbk3type->getPlaceHolder()) ?>" value="<?php echo $userpurchase_edit->taxAmountbk3type->EditValue ?>"<?php echo $userpurchase_edit->taxAmountbk3type->editAttributes() ?>>
</span>
<?php echo $userpurchase_edit->taxAmountbk3type->CustomMsg ?></div></div>
	</div>
<?php } ?>
<?php if ($userpurchase_edit->originalpurchaseamount->Visible) { // originalpurchaseamount ?>
	<div id="r_originalpurchaseamount" class="form-group row">
		<label id="elh_userpurchase_originalpurchaseamount" for="x_originalpurchaseamount" class="<?php echo $userpurchase_edit->LeftColumnClass ?>"><?php echo $userpurchase_edit->originalpurchaseamount->caption() ?><?php echo $userpurchase_edit->originalpurchaseamount->Required ? $Language->phrase("FieldRequiredIndicator") : "" ?></label>
		<div class="<?php echo $userpurchase_edit->RightColumnClass ?>"><div <?php echo $userpurchase_edit->originalpurchaseamount->cellAttributes() ?>>
<span id="el_userpurchase_originalpurchaseamount">
<input type="text" data-table="userpurchase" data-field="x_originalpurchaseamount" data-page="1" name="x_originalpurchaseamount" id="x_originalpurchaseamount" size="30" maxlength="22" placeholder="<?php echo HtmlEncode($userpurchase_edit->originalpurchaseamount->getPlaceHolder()) ?>" value="<?php echo $userpurchase_edit->originalpurchaseamount->EditValue ?>"<?php echo $userpurchase_edit->originalpurchaseamount->editAttributes() ?>>
</span>
<?php echo $userpurchase_edit->originalpurchaseamount->CustomMsg ?></div></div>
	</div>
<?php } ?>
<?php if ($userpurchase_edit->discountamount->Visible) { // discountamount ?>
	<div id="r_discountamount" class="form-group row">
		<label id="elh_userpurchase_discountamount" for="x_discountamount" class="<?php echo $userpurchase_edit->LeftColumnClass ?>"><?php echo $userpurchase_edit->discountamount->caption() ?><?php echo $userpurchase_edit->discountamount->Required ? $Language->phrase("FieldRequiredIndicator") : "" ?></label>
		<div class="<?php echo $userpurchase_edit->RightColumnClass ?>"><div <?php echo $userpurchase_edit->discountamount->cellAttributes() ?>>
<span id="el_userpurchase_discountamount">
<input type="text" data-table="userpurchase" data-field="x_discountamount" data-page="1" name="x_discountamount" id="x_discountamount" size="30" maxlength="22" placeholder="<?php echo HtmlEncode($userpurchase_edit->discountamount->getPlaceHolder()) ?>" value="<?php echo $userpurchase_edit->discountamount->EditValue ?>"<?php echo $userpurchase_edit->discountamount->editAttributes() ?>>
</span>
<?php echo $userpurchase_edit->discountamount->CustomMsg ?></div></div>
	</div>
<?php } ?>
<?php if ($userpurchase_edit->discountpercentage->Visible) { // discountpercentage ?>
	<div id="r_discountpercentage" class="form-group row">
		<label id="elh_userpurchase_discountpercentage" for="x_discountpercentage" class="<?php echo $userpurchase_edit->LeftColumnClass ?>"><?php echo $userpurchase_edit->discountpercentage->caption() ?><?php echo $userpurchase_edit->discountpercentage->Required ? $Language->phrase("FieldRequiredIndicator") : "" ?></label>
		<div class="<?php echo $userpurchase_edit->RightColumnClass ?>"><div <?php echo $userpurchase_edit->discountpercentage->cellAttributes() ?>>
<span id="el_userpurchase_discountpercentage">
<input type="text" data-table="userpurchase" data-field="x_discountpercentage" data-page="1" name="x_discountpercentage" id="x_discountpercentage" size="30" maxlength="1" placeholder="<?php echo HtmlEncode($userpurchase_edit->discountpercentage->getPlaceHolder()) ?>" value="<?php echo $userpurchase_edit->discountpercentage->EditValue ?>"<?php echo $userpurchase_edit->discountpercentage->editAttributes() ?>>
</span>
<?php echo $userpurchase_edit->discountpercentage->CustomMsg ?></div></div>
	</div>
<?php } ?>
<?php if ($userpurchase_edit->txgroupid->Visible) { // txgroupid ?>
	<div id="r_txgroupid" class="form-group row">
		<label id="elh_userpurchase_txgroupid" for="x_txgroupid" class="<?php echo $userpurchase_edit->LeftColumnClass ?>"><?php echo $userpurchase_edit->txgroupid->caption() ?><?php echo $userpurchase_edit->txgroupid->Required ? $Language->phrase("FieldRequiredIndicator") : "" ?></label>
		<div class="<?php echo $userpurchase_edit->RightColumnClass ?>"><div <?php echo $userpurchase_edit->txgroupid->cellAttributes() ?>>
<span id="el_userpurchase_txgroupid">
<input type="text" data-table="userpurchase" data-field="x_txgroupid" data-page="1" name="x_txgroupid" id="x_txgroupid" size="30" maxlength="15" placeholder="<?php echo HtmlEncode($userpurchase_edit->txgroupid->getPlaceHolder()) ?>" value="<?php echo $userpurchase_edit->txgroupid->EditValue ?>"<?php echo $userpurchase_edit->txgroupid->editAttributes() ?>>
</span>
<?php echo $userpurchase_edit->txgroupid->CustomMsg ?></div></div>
	</div>
<?php } ?>
<?php if ($userpurchase_edit->success_status->Visible) { // success_status ?>
	<div id="r_success_status" class="form-group row">
		<label id="elh_userpurchase_success_status" for="x_success_status" class="<?php echo $userpurchase_edit->LeftColumnClass ?>"><?php echo $userpurchase_edit->success_status->caption() ?><?php echo $userpurchase_edit->success_status->Required ? $Language->phrase("FieldRequiredIndicator") : "" ?></label>
		<div class="<?php echo $userpurchase_edit->RightColumnClass ?>"><div <?php echo $userpurchase_edit->success_status->cellAttributes() ?>>
<span id="el_userpurchase_success_status">
<div class="input-group">
	<select class="custom-select ew-custom-select" data-table="userpurchase" data-field="x_success_status" data-page="1" data-value-separator="<?php echo $userpurchase_edit->success_status->displayValueSeparatorAttribute() ?>" id="x_success_status" name="x_success_status"<?php echo $userpurchase_edit->success_status->editAttributes() ?>>
			<?php echo $userpurchase_edit->success_status->selectOptionListHtml("x_success_status") ?>
		</select>
</div>
</span>
<?php echo $userpurchase_edit->success_status->CustomMsg ?></div></div>
	</div>
<?php } ?>
<?php if ($userpurchase_edit->error_msg->Visible) { // error_msg ?>
	<div id="r_error_msg" class="form-group row">
		<label id="elh_userpurchase_error_msg" for="x_error_msg" class="<?php echo $userpurchase_edit->LeftColumnClass ?>"><?php echo $userpurchase_edit->error_msg->caption() ?><?php echo $userpurchase_edit->error_msg->Required ? $Language->phrase("FieldRequiredIndicator") : "" ?></label>
		<div class="<?php echo $userpurchase_edit->RightColumnClass ?>"><div <?php echo $userpurchase_edit->error_msg->cellAttributes() ?>>
<span id="el_userpurchase_error_msg">
<input type="text" data-table="userpurchase" data-field="x_error_msg" data-page="1" name="x_error_msg" id="x_error_msg" size="30" maxlength="255" placeholder="<?php echo HtmlEncode($userpurchase_edit->error_msg->getPlaceHolder()) ?>" value="<?php echo $userpurchase_edit->error_msg->EditValue ?>"<?php echo $userpurchase_edit->error_msg->editAttributes() ?>>
</span>
<?php echo $userpurchase_edit->error_msg->CustomMsg ?></div></div>
	</div>
<?php } ?>
<?php if ($userpurchase_edit->userpiid->Visible) { // userpiid ?>
	<div id="r_userpiid" class="form-group row">
		<label id="elh_userpurchase_userpiid" for="x_userpiid" class="<?php echo $userpurchase_edit->LeftColumnClass ?>"><?php echo $userpurchase_edit->userpiid->caption() ?><?php echo $userpurchase_edit->userpiid->Required ? $Language->phrase("FieldRequiredIndicator") : "" ?></label>
		<div class="<?php echo $userpurchase_edit->RightColumnClass ?>"><div <?php echo $userpurchase_edit->userpiid->cellAttributes() ?>>
<span id="el_userpurchase_userpiid">
<input type="text" data-table="userpurchase" data-field="x_userpiid" data-page="1" name="x_userpiid" id="x_userpiid" size="30" maxlength="5" placeholder="<?php echo HtmlEncode($userpurchase_edit->userpiid->getPlaceHolder()) ?>" value="<?php echo $userpurchase_edit->userpiid->EditValue ?>"<?php echo $userpurchase_edit->userpiid->editAttributes() ?>>
</span>
<?php echo $userpurchase_edit->userpiid->CustomMsg ?></div></div>
	</div>
<?php } ?>
<?php if ($userpurchase_edit->notes->Visible) { // notes ?>
	<div id="r_notes" class="form-group row">
		<label id="elh_userpurchase_notes" for="x_notes" class="<?php echo $userpurchase_edit->LeftColumnClass ?>"><?php echo $userpurchase_edit->notes->caption() ?><?php echo $userpurchase_edit->notes->Required ? $Language->phrase("FieldRequiredIndicator") : "" ?></label>
		<div class="<?php echo $userpurchase_edit->RightColumnClass ?>"><div <?php echo $userpurchase_edit->notes->cellAttributes() ?>>
<span id="el_userpurchase_notes">
<input type="text" data-table="userpurchase" data-field="x_notes" data-page="1" name="x_notes" id="x_notes" size="30" maxlength="255" placeholder="<?php echo HtmlEncode($userpurchase_edit->notes->getPlaceHolder()) ?>" value="<?php echo $userpurchase_edit->notes->EditValue ?>"<?php echo $userpurchase_edit->notes->editAttributes() ?>>
</span>
<?php echo $userpurchase_edit->notes->CustomMsg ?></div></div>
	</div>
<?php } ?>
<?php if ($userpurchase_edit->lastpurchasereaddate->Visible) { // lastpurchasereaddate ?>
	<div id="r_lastpurchasereaddate" class="form-group row">
		<label id="elh_userpurchase_lastpurchasereaddate" for="x_lastpurchasereaddate" class="<?php echo $userpurchase_edit->LeftColumnClass ?>"><?php echo $userpurchase_edit->lastpurchasereaddate->caption() ?><?php echo $userpurchase_edit->lastpurchasereaddate->Required ? $Language->phrase("FieldRequiredIndicator") : "" ?></label>
		<div class="<?php echo $userpurchase_edit->RightColumnClass ?>"><div <?php echo $userpurchase_edit->lastpurchasereaddate->cellAttributes() ?>>
<span id="el_userpurchase_lastpurchasereaddate">
<input type="text" data-table="userpurchase" data-field="x_lastpurchasereaddate" data-page="1" name="x_lastpurchasereaddate" id="x_lastpurchasereaddate" maxlength="19" placeholder="<?php echo HtmlEncode($userpurchase_edit->lastpurchasereaddate->getPlaceHolder()) ?>" value="<?php echo $userpurchase_edit->lastpurchasereaddate->EditValue ?>"<?php echo $userpurchase_edit->lastpurchasereaddate->editAttributes() ?>>
<?php if (!$userpurchase_edit->lastpurchasereaddate->ReadOnly && !$userpurchase_edit->lastpurchasereaddate->Disabled && !isset($userpurchase_edit->lastpurchasereaddate->EditAttrs["readonly"]) && !isset($userpurchase_edit->lastpurchasereaddate->EditAttrs["disabled"])) { ?>
<script>
loadjs.ready(["fuserpurchaseedit", "datetimepicker"], function() {
	ew.createDateTimePicker("fuserpurchaseedit", "x_lastpurchasereaddate", {"ignoreReadonly":true,"useCurrent":false,"format":0});
});
</script>
<?php } ?>
</span>
<?php echo $userpurchase_edit->lastpurchasereaddate->CustomMsg ?></div></div>
	</div>
<?php } ?>
<?php if ($userpurchase_edit->retryapicount->Visible) { // retryapicount ?>
	<div id="r_retryapicount" class="form-group row">
		<label id="elh_userpurchase_retryapicount" for="x_retryapicount" class="<?php echo $userpurchase_edit->LeftColumnClass ?>"><?php echo $userpurchase_edit->retryapicount->caption() ?><?php echo $userpurchase_edit->retryapicount->Required ? $Language->phrase("FieldRequiredIndicator") : "" ?></label>
		<div class="<?php echo $userpurchase_edit->RightColumnClass ?>"><div <?php echo $userpurchase_edit->retryapicount->cellAttributes() ?>>
<span id="el_userpurchase_retryapicount">
<input type="text" data-table="userpurchase" data-field="x_retryapicount" data-page="1" name="x_retryapicount" id="x_retryapicount" size="30" maxlength="1" placeholder="<?php echo HtmlEncode($userpurchase_edit->retryapicount->getPlaceHolder()) ?>" value="<?php echo $userpurchase_edit->retryapicount->EditValue ?>"<?php echo $userpurchase_edit->retryapicount->editAttributes() ?>>
</span>
<?php echo $userpurchase_edit->retryapicount->CustomMsg ?></div></div>
	</div>
<?php } ?>
</div><!-- /page* -->
		</div><!-- /multi-page .tab-pane -->
		<div class="tab-pane<?php echo $userpurchase_edit->MultiPages->pageStyle(2) ?>" id="tab_userpurchase2"><!-- multi-page .tab-pane -->
<div class="ew-edit-div"><!-- page* -->
<?php if ($userpurchase_edit->consumerfees->Visible) { // consumerfees ?>
	<div id="r_consumerfees" class="form-group row">
		<label id="elh_userpurchase_consumerfees" for="x_consumerfees" class="<?php echo $userpurchase_edit->LeftColumnClass ?>"><?php echo $userpurchase_edit->consumerfees->caption() ?><?php echo $userpurchase_edit->consumerfees->Required ? $Language->phrase("FieldRequiredIndicator") : "" ?></label>
		<div class="<?php echo $userpurchase_edit->RightColumnClass ?>"><div <?php echo $userpurchase_edit->consumerfees->cellAttributes() ?>>
<span id="el_userpurchase_consumerfees">
<input type="text" data-table="userpurchase" data-field="x_consumerfees" data-page="2" name="x_consumerfees" id="x_consumerfees" size="30" placeholder="<?php echo HtmlEncode($userpurchase_edit->consumerfees->getPlaceHolder()) ?>" value="<?php echo $userpurchase_edit->consumerfees->EditValue ?>"<?php echo $userpurchase_edit->consumerfees->editAttributes() ?>>
</span>
<?php echo $userpurchase_edit->consumerfees->CustomMsg ?></div></div>
	</div>
<?php } ?>
<?php if ($userpurchase_edit->feeid->Visible) { // feeid ?>
	<div id="r_feeid" class="form-group row">
		<label id="elh_userpurchase_feeid" for="x_feeid" class="<?php echo $userpurchase_edit->LeftColumnClass ?>"><?php echo $userpurchase_edit->feeid->caption() ?><?php echo $userpurchase_edit->feeid->Required ? $Language->phrase("FieldRequiredIndicator") : "" ?></label>
		<div class="<?php echo $userpurchase_edit->RightColumnClass ?>"><div <?php echo $userpurchase_edit->feeid->cellAttributes() ?>>
<span id="el_userpurchase_feeid">
<input type="text" data-table="userpurchase" data-field="x_feeid" data-page="2" name="x_feeid" id="x_feeid" size="30" placeholder="<?php echo HtmlEncode($userpurchase_edit->feeid->getPlaceHolder()) ?>" value="<?php echo $userpurchase_edit->feeid->EditValue ?>"<?php echo $userpurchase_edit->feeid->editAttributes() ?>>
</span>
<?php echo $userpurchase_edit->feeid->CustomMsg ?></div></div>
	</div>
<?php } ?>
<?php if ($userpurchase_edit->ratetabletype->Visible) { // ratetabletype ?>
	<div id="r_ratetabletype" class="form-group row">
		<label id="elh_userpurchase_ratetabletype" for="x_ratetabletype" class="<?php echo $userpurchase_edit->LeftColumnClass ?>"><?php echo $userpurchase_edit->ratetabletype->caption() ?><?php echo $userpurchase_edit->ratetabletype->Required ? $Language->phrase("FieldRequiredIndicator") : "" ?></label>
		<div class="<?php echo $userpurchase_edit->RightColumnClass ?>"><div <?php echo $userpurchase_edit->ratetabletype->cellAttributes() ?>>
<span id="el_userpurchase_ratetabletype">
<input type="text" data-table="userpurchase" data-field="x_ratetabletype" data-page="2" name="x_ratetabletype" id="x_ratetabletype" size="30" placeholder="<?php echo HtmlEncode($userpurchase_edit->ratetabletype->getPlaceHolder()) ?>" value="<?php echo $userpurchase_edit->ratetabletype->EditValue ?>"<?php echo $userpurchase_edit->ratetabletype->editAttributes() ?>>
</span>
<?php echo $userpurchase_edit->ratetabletype->CustomMsg ?></div></div>
	</div>
<?php } ?>
<?php if ($userpurchase_edit->feesystemshare->Visible) { // feesystemshare ?>
	<div id="r_feesystemshare" class="form-group row">
		<label id="elh_userpurchase_feesystemshare" for="x_feesystemshare" class="<?php echo $userpurchase_edit->LeftColumnClass ?>"><?php echo $userpurchase_edit->feesystemshare->caption() ?><?php echo $userpurchase_edit->feesystemshare->Required ? $Language->phrase("FieldRequiredIndicator") : "" ?></label>
		<div class="<?php echo $userpurchase_edit->RightColumnClass ?>"><div <?php echo $userpurchase_edit->feesystemshare->cellAttributes() ?>>
<span id="el_userpurchase_feesystemshare">
<input type="text" data-table="userpurchase" data-field="x_feesystemshare" data-page="2" name="x_feesystemshare" id="x_feesystemshare" size="30" placeholder="<?php echo HtmlEncode($userpurchase_edit->feesystemshare->getPlaceHolder()) ?>" value="<?php echo $userpurchase_edit->feesystemshare->EditValue ?>"<?php echo $userpurchase_edit->feesystemshare->editAttributes() ?>>
</span>
<?php echo $userpurchase_edit->feesystemshare->CustomMsg ?></div></div>
	</div>
<?php } ?>
<?php if ($userpurchase_edit->feeexternalshare->Visible) { // feeexternalshare ?>
	<div id="r_feeexternalshare" class="form-group row">
		<label id="elh_userpurchase_feeexternalshare" for="x_feeexternalshare" class="<?php echo $userpurchase_edit->LeftColumnClass ?>"><?php echo $userpurchase_edit->feeexternalshare->caption() ?><?php echo $userpurchase_edit->feeexternalshare->Required ? $Language->phrase("FieldRequiredIndicator") : "" ?></label>
		<div class="<?php echo $userpurchase_edit->RightColumnClass ?>"><div <?php echo $userpurchase_edit->feeexternalshare->cellAttributes() ?>>
<span id="el_userpurchase_feeexternalshare">
<input type="text" data-table="userpurchase" data-field="x_feeexternalshare" data-page="2" name="x_feeexternalshare" id="x_feeexternalshare" size="30" placeholder="<?php echo HtmlEncode($userpurchase_edit->feeexternalshare->getPlaceHolder()) ?>" value="<?php echo $userpurchase_edit->feeexternalshare->EditValue ?>"<?php echo $userpurchase_edit->feeexternalshare->editAttributes() ?>>
</span>
<?php echo $userpurchase_edit->feeexternalshare->CustomMsg ?></div></div>
	</div>
<?php } ?>
<?php if ($userpurchase_edit->feefranchiseeshare->Visible) { // feefranchiseeshare ?>
	<div id="r_feefranchiseeshare" class="form-group row">
		<label id="elh_userpurchase_feefranchiseeshare" for="x_feefranchiseeshare" class="<?php echo $userpurchase_edit->LeftColumnClass ?>"><?php echo $userpurchase_edit->feefranchiseeshare->caption() ?><?php echo $userpurchase_edit->feefranchiseeshare->Required ? $Language->phrase("FieldRequiredIndicator") : "" ?></label>
		<div class="<?php echo $userpurchase_edit->RightColumnClass ?>"><div <?php echo $userpurchase_edit->feefranchiseeshare->cellAttributes() ?>>
<span id="el_userpurchase_feefranchiseeshare">
<input type="text" data-table="userpurchase" data-field="x_feefranchiseeshare" data-page="2" name="x_feefranchiseeshare" id="x_feefranchiseeshare" size="30" placeholder="<?php echo HtmlEncode($userpurchase_edit->feefranchiseeshare->getPlaceHolder()) ?>" value="<?php echo $userpurchase_edit->feefranchiseeshare->EditValue ?>"<?php echo $userpurchase_edit->feefranchiseeshare->editAttributes() ?>>
</span>
<?php echo $userpurchase_edit->feefranchiseeshare->CustomMsg ?></div></div>
	</div>
<?php } ?>
<?php if ($userpurchase_edit->feeresellershare->Visible) { // feeresellershare ?>
	<div id="r_feeresellershare" class="form-group row">
		<label id="elh_userpurchase_feeresellershare" for="x_feeresellershare" class="<?php echo $userpurchase_edit->LeftColumnClass ?>"><?php echo $userpurchase_edit->feeresellershare->caption() ?><?php echo $userpurchase_edit->feeresellershare->Required ? $Language->phrase("FieldRequiredIndicator") : "" ?></label>
		<div class="<?php echo $userpurchase_edit->RightColumnClass ?>"><div <?php echo $userpurchase_edit->feeresellershare->cellAttributes() ?>>
<span id="el_userpurchase_feeresellershare">
<input type="text" data-table="userpurchase" data-field="x_feeresellershare" data-page="2" name="x_feeresellershare" id="x_feeresellershare" size="30" placeholder="<?php echo HtmlEncode($userpurchase_edit->feeresellershare->getPlaceHolder()) ?>" value="<?php echo $userpurchase_edit->feeresellershare->EditValue ?>"<?php echo $userpurchase_edit->feeresellershare->editAttributes() ?>>
</span>
<?php echo $userpurchase_edit->feeresellershare->CustomMsg ?></div></div>
	</div>
<?php } ?>
</div><!-- /page* -->
		</div><!-- /multi-page .tab-pane -->
		<div class="tab-pane<?php echo $userpurchase_edit->MultiPages->pageStyle(3) ?>" id="tab_userpurchase3"><!-- multi-page .tab-pane -->
<div class="ew-edit-div"><!-- page* -->
<?php if ($userpurchase_edit->otherconfirmref->Visible) { // otherconfirmref ?>
	<div id="r_otherconfirmref" class="form-group row">
		<label id="elh_userpurchase_otherconfirmref" for="x_otherconfirmref" class="<?php echo $userpurchase_edit->LeftColumnClass ?>"><?php echo $userpurchase_edit->otherconfirmref->caption() ?><?php echo $userpurchase_edit->otherconfirmref->Required ? $Language->phrase("FieldRequiredIndicator") : "" ?></label>
		<div class="<?php echo $userpurchase_edit->RightColumnClass ?>"><div <?php echo $userpurchase_edit->otherconfirmref->cellAttributes() ?>>
<span id="el_userpurchase_otherconfirmref">
<input type="text" data-table="userpurchase" data-field="x_otherconfirmref" data-page="3" name="x_otherconfirmref" id="x_otherconfirmref" size="30" maxlength="100" placeholder="<?php echo HtmlEncode($userpurchase_edit->otherconfirmref->getPlaceHolder()) ?>" value="<?php echo $userpurchase_edit->otherconfirmref->EditValue ?>"<?php echo $userpurchase_edit->otherconfirmref->editAttributes() ?>>
</span>
<?php echo $userpurchase_edit->otherconfirmref->CustomMsg ?></div></div>
	</div>
<?php } ?>
<?php if ($userpurchase_edit->itemdesc->Visible) { // itemdesc ?>
	<div id="r_itemdesc" class="form-group row">
		<label id="elh_userpurchase_itemdesc" for="x_itemdesc" class="<?php echo $userpurchase_edit->LeftColumnClass ?>"><?php echo $userpurchase_edit->itemdesc->caption() ?><?php echo $userpurchase_edit->itemdesc->Required ? $Language->phrase("FieldRequiredIndicator") : "" ?></label>
		<div class="<?php echo $userpurchase_edit->RightColumnClass ?>"><div <?php echo $userpurchase_edit->itemdesc->cellAttributes() ?>>
<span id="el_userpurchase_itemdesc">
<input type="text" data-table="userpurchase" data-field="x_itemdesc" data-page="3" name="x_itemdesc" id="x_itemdesc" size="30" maxlength="100" placeholder="<?php echo HtmlEncode($userpurchase_edit->itemdesc->getPlaceHolder()) ?>" value="<?php echo $userpurchase_edit->itemdesc->EditValue ?>"<?php echo $userpurchase_edit->itemdesc->editAttributes() ?>>
</span>
<?php echo $userpurchase_edit->itemdesc->CustomMsg ?></div></div>
	</div>
<?php } ?>
<?php if ($userpurchase_edit->shoppingCartID->Visible) { // shoppingCartID ?>
	<div id="r_shoppingCartID" class="form-group row">
		<label id="elh_userpurchase_shoppingCartID" for="x_shoppingCartID" class="<?php echo $userpurchase_edit->LeftColumnClass ?>"><?php echo $userpurchase_edit->shoppingCartID->caption() ?><?php echo $userpurchase_edit->shoppingCartID->Required ? $Language->phrase("FieldRequiredIndicator") : "" ?></label>
		<div class="<?php echo $userpurchase_edit->RightColumnClass ?>"><div <?php echo $userpurchase_edit->shoppingCartID->cellAttributes() ?>>
<span id="el_userpurchase_shoppingCartID">
<input type="text" data-table="userpurchase" data-field="x_shoppingCartID" data-page="3" name="x_shoppingCartID" id="x_shoppingCartID" size="30" maxlength="20" placeholder="<?php echo HtmlEncode($userpurchase_edit->shoppingCartID->getPlaceHolder()) ?>" value="<?php echo $userpurchase_edit->shoppingCartID->EditValue ?>"<?php echo $userpurchase_edit->shoppingCartID->editAttributes() ?>>
</span>
<?php echo $userpurchase_edit->shoppingCartID->CustomMsg ?></div></div>
	</div>
<?php } ?>
<?php if ($userpurchase_edit->merchantRefID->Visible) { // merchantRefID ?>
	<div id="r_merchantRefID" class="form-group row">
		<label id="elh_userpurchase_merchantRefID" for="x_merchantRefID" class="<?php echo $userpurchase_edit->LeftColumnClass ?>"><?php echo $userpurchase_edit->merchantRefID->caption() ?><?php echo $userpurchase_edit->merchantRefID->Required ? $Language->phrase("FieldRequiredIndicator") : "" ?></label>
		<div class="<?php echo $userpurchase_edit->RightColumnClass ?>"><div <?php echo $userpurchase_edit->merchantRefID->cellAttributes() ?>>
<span id="el_userpurchase_merchantRefID">
<input type="text" data-table="userpurchase" data-field="x_merchantRefID" data-page="3" name="x_merchantRefID" id="x_merchantRefID" size="30" maxlength="30" placeholder="<?php echo HtmlEncode($userpurchase_edit->merchantRefID->getPlaceHolder()) ?>" value="<?php echo $userpurchase_edit->merchantRefID->EditValue ?>"<?php echo $userpurchase_edit->merchantRefID->editAttributes() ?>>
</span>
<?php echo $userpurchase_edit->merchantRefID->CustomMsg ?></div></div>
	</div>
<?php } ?>
<?php if ($userpurchase_edit->refunded->Visible) { // refunded ?>
	<div id="r_refunded" class="form-group row">
		<label id="elh_userpurchase_refunded" for="x_refunded" class="<?php echo $userpurchase_edit->LeftColumnClass ?>"><?php echo $userpurchase_edit->refunded->caption() ?><?php echo $userpurchase_edit->refunded->Required ? $Language->phrase("FieldRequiredIndicator") : "" ?></label>
		<div class="<?php echo $userpurchase_edit->RightColumnClass ?>"><div <?php echo $userpurchase_edit->refunded->cellAttributes() ?>>
<span id="el_userpurchase_refunded">
<div class="input-group">
	<select class="custom-select ew-custom-select" data-table="userpurchase" data-field="x_refunded" data-page="3" data-value-separator="<?php echo $userpurchase_edit->refunded->displayValueSeparatorAttribute() ?>" id="x_refunded" name="x_refunded"<?php echo $userpurchase_edit->refunded->editAttributes() ?>>
			<?php echo $userpurchase_edit->refunded->selectOptionListHtml("x_refunded") ?>
		</select>
</div>
</span>
<?php echo $userpurchase_edit->refunded->CustomMsg ?></div></div>
	</div>
<?php } ?>
<?php if ($userpurchase_edit->tokenid->Visible) { // tokenid ?>
	<div id="r_tokenid" class="form-group row">
		<label id="elh_userpurchase_tokenid" for="x_tokenid" class="<?php echo $userpurchase_edit->LeftColumnClass ?>"><?php echo $userpurchase_edit->tokenid->caption() ?><?php echo $userpurchase_edit->tokenid->Required ? $Language->phrase("FieldRequiredIndicator") : "" ?></label>
		<div class="<?php echo $userpurchase_edit->RightColumnClass ?>"><div <?php echo $userpurchase_edit->tokenid->cellAttributes() ?>>
<span id="el_userpurchase_tokenid">
<input type="text" data-table="userpurchase" data-field="x_tokenid" data-page="3" name="x_tokenid" id="x_tokenid" size="30" maxlength="50" placeholder="<?php echo HtmlEncode($userpurchase_edit->tokenid->getPlaceHolder()) ?>" value="<?php echo $userpurchase_edit->tokenid->EditValue ?>"<?php echo $userpurchase_edit->tokenid->editAttributes() ?>>
</span>
<?php echo $userpurchase_edit->tokenid->CustomMsg ?></div></div>
	</div>
<?php } ?>
<?php if ($userpurchase_edit->vaultid->Visible) { // vaultid ?>
	<div id="r_vaultid" class="form-group row">
		<label id="elh_userpurchase_vaultid" for="x_vaultid" class="<?php echo $userpurchase_edit->LeftColumnClass ?>"><?php echo $userpurchase_edit->vaultid->caption() ?><?php echo $userpurchase_edit->vaultid->Required ? $Language->phrase("FieldRequiredIndicator") : "" ?></label>
		<div class="<?php echo $userpurchase_edit->RightColumnClass ?>"><div <?php echo $userpurchase_edit->vaultid->cellAttributes() ?>>
<span id="el_userpurchase_vaultid">
<input type="text" data-table="userpurchase" data-field="x_vaultid" data-page="3" name="x_vaultid" id="x_vaultid" size="30" placeholder="<?php echo HtmlEncode($userpurchase_edit->vaultid->getPlaceHolder()) ?>" value="<?php echo $userpurchase_edit->vaultid->EditValue ?>"<?php echo $userpurchase_edit->vaultid->editAttributes() ?>>
</span>
<?php echo $userpurchase_edit->vaultid->CustomMsg ?></div></div>
	</div>
<?php } ?>
<?php if ($userpurchase_edit->refundrequested->Visible) { // refundrequested ?>
	<div id="r_refundrequested" class="form-group row">
		<label id="elh_userpurchase_refundrequested" for="x_refundrequested" class="<?php echo $userpurchase_edit->LeftColumnClass ?>"><?php echo $userpurchase_edit->refundrequested->caption() ?><?php echo $userpurchase_edit->refundrequested->Required ? $Language->phrase("FieldRequiredIndicator") : "" ?></label>
		<div class="<?php echo $userpurchase_edit->RightColumnClass ?>"><div <?php echo $userpurchase_edit->refundrequested->cellAttributes() ?>>
<span id="el_userpurchase_refundrequested">
<input type="text" data-table="userpurchase" data-field="x_refundrequested" data-page="3" name="x_refundrequested" id="x_refundrequested" size="30" placeholder="<?php echo HtmlEncode($userpurchase_edit->refundrequested->getPlaceHolder()) ?>" value="<?php echo $userpurchase_edit->refundrequested->EditValue ?>"<?php echo $userpurchase_edit->refundrequested->editAttributes() ?>>
</span>
<?php echo $userpurchase_edit->refundrequested->CustomMsg ?></div></div>
	</div>
<?php } ?>
<?php if ($userpurchase_edit->refundrequesttxid->Visible) { // refundrequesttxid ?>
	<div id="r_refundrequesttxid" class="form-group row">
		<label id="elh_userpurchase_refundrequesttxid" for="x_refundrequesttxid" class="<?php echo $userpurchase_edit->LeftColumnClass ?>"><?php echo $userpurchase_edit->refundrequesttxid->caption() ?><?php echo $userpurchase_edit->refundrequesttxid->Required ? $Language->phrase("FieldRequiredIndicator") : "" ?></label>
		<div class="<?php echo $userpurchase_edit->RightColumnClass ?>"><div <?php echo $userpurchase_edit->refundrequesttxid->cellAttributes() ?>>
<span id="el_userpurchase_refundrequesttxid">
<input type="text" data-table="userpurchase" data-field="x_refundrequesttxid" data-page="3" name="x_refundrequesttxid" id="x_refundrequesttxid" size="30" maxlength="9" placeholder="<?php echo HtmlEncode($userpurchase_edit->refundrequesttxid->getPlaceHolder()) ?>" value="<?php echo $userpurchase_edit->refundrequesttxid->EditValue ?>"<?php echo $userpurchase_edit->refundrequesttxid->editAttributes() ?>>
</span>
<?php echo $userpurchase_edit->refundrequesttxid->CustomMsg ?></div></div>
	</div>
<?php } ?>
</div><!-- /page* -->
		</div><!-- /multi-page .tab-pane -->
	</div><!-- /multi-page tabs .tab-content -->
</div><!-- /multi-page tabs -->
</div><!-- /multi-page -->
<?php
	if (in_array("userpurchasepayment", explode(",", $userpurchase->getCurrentDetailTable())) && $userpurchasepayment->DetailEdit) {
?>
<?php if ($userpurchase->getCurrentDetailTable() != "") { ?>
<h4 class="ew-detail-caption"><?php echo $Language->tablePhrase("userpurchasepayment", "TblCaption") ?></h4>
<?php } ?>
<?php include_once "userpurchasepaymentgrid.php" ?>
<?php } ?>
<?php
	if (in_array("userpurchasereturn", explode(",", $userpurchase->getCurrentDetailTable())) && $userpurchasereturn->DetailEdit) {
?>
<?php if ($userpurchase->getCurrentDetailTable() != "") { ?>
<h4 class="ew-detail-caption"><?php echo $Language->tablePhrase("userpurchasereturn", "TblCaption") ?></h4>
<?php } ?>
<?php include_once "userpurchasereturngrid.php" ?>
<?php } ?>
<?php
	if (in_array("vbillinghistory", explode(",", $userpurchase->getCurrentDetailTable())) && $vbillinghistory->DetailEdit) {
?>
<?php if ($userpurchase->getCurrentDetailTable() != "") { ?>
<h4 class="ew-detail-caption"><?php echo $Language->tablePhrase("vbillinghistory", "TblCaption") ?></h4>
<?php } ?>
<?php include_once "vbillinghistorygrid.php" ?>
<?php } ?>
<?php if (!$userpurchase_edit->IsModal) { ?>
<div class="form-group row"><!-- buttons .form-group -->
	<div class="<?php echo $userpurchase_edit->OffsetColumnClass ?>"><!-- buttons offset -->
<button class="btn btn-primary ew-btn" name="btn-action" id="btn-action" type="submit"><?php echo $Language->phrase("SaveBtn") ?></button>
<button class="btn btn-default ew-btn" name="btn-cancel" id="btn-cancel" type="button" data-href="<?php echo $userpurchase_edit->getReturnUrl() ?>"><?php echo $Language->phrase("CancelBtn") ?></button>
	</div><!-- /buttons offset -->
</div><!-- /buttons .form-group -->
<?php } ?>
</form>
<?php
$userpurchase_edit->showPageFooter();
if (Config("DEBUG"))
	echo GetDebugMessage();
?>
<script>
loadjs.ready("load", function() {

	// Startup script
	// Write your table-specific startup script here
	// console.log("page loaded");

});
</script>
<?php include_once "footer.php"; ?>
<?php
$userpurchase_edit->terminate();
?>