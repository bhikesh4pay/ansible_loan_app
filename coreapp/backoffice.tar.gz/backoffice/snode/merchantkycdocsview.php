<?php
namespace PHPMaker2020\_4payadmin;

// Autoload
include_once "autoload.php";

// Session
if (session_status() !== PHP_SESSION_ACTIVE)
	\Delight\Cookie\Session::start(Config("COOKIE_SAMESITE")); // Init session data

// Output buffering
ob_start();
?>
<?php

// Write header
WriteHeader(FALSE);

// Create page object
$merchantkycdocs_view = new merchantkycdocs_view();

// Run the page
$merchantkycdocs_view->run();

// Setup login status
SetupLoginStatus();
SetClientVar("login", LoginStatus());

// Global Page Rendering event (in userfn*.php)
Page_Rendering();

// Page Rendering event
$merchantkycdocs_view->Page_Render();
?>
<?php include_once "header.php"; ?>
<?php if (!$merchantkycdocs_view->isExport()) { ?>
<script>
var fmerchantkycdocsview, currentPageID;
loadjs.ready("head", function() {

	// Form object
	currentPageID = ew.PAGE_ID = "view";
	fmerchantkycdocsview = currentForm = new ew.Form("fmerchantkycdocsview", "view");
	loadjs.done("fmerchantkycdocsview");
});
</script>
<script>
loadjs.ready("head", function() {

	// Client script
	// Write your client script here, no need to add script tags.

});
</script>
<?php } ?>
<?php if (!$merchantkycdocs_view->isExport()) { ?>
<div class="btn-toolbar ew-toolbar">
<?php $merchantkycdocs_view->ExportOptions->render("body") ?>
<?php $merchantkycdocs_view->OtherOptions->render("body") ?>
<div class="clearfix"></div>
</div>
<?php } ?>
<?php $merchantkycdocs_view->showPageHeader(); ?>
<?php
$merchantkycdocs_view->showMessage();
?>
<form name="fmerchantkycdocsview" id="fmerchantkycdocsview" class="form-inline ew-form ew-view-form" action="<?php echo CurrentPageName() ?>" method="post">
<?php if ($Page->CheckToken) { ?>
<input type="hidden" name="<?php echo Config("TOKEN_NAME") ?>" value="<?php echo $Page->Token ?>">
<?php } ?>
<input type="hidden" name="t" value="merchantkycdocs">
<input type="hidden" name="modal" value="<?php echo (int)$merchantkycdocs_view->IsModal ?>">
<table class="table table-striped table-sm ew-view-table">
<?php if ($merchantkycdocs_view->docid->Visible) { // docid ?>
	<tr id="r_docid">
		<td class="<?php echo $merchantkycdocs_view->TableLeftColumnClass ?>"><span id="elh_merchantkycdocs_docid"><?php echo $merchantkycdocs_view->docid->caption() ?></span></td>
		<td data-name="docid" <?php echo $merchantkycdocs_view->docid->cellAttributes() ?>>
<span id="el_merchantkycdocs_docid">
<span<?php echo $merchantkycdocs_view->docid->viewAttributes() ?>><?php echo $merchantkycdocs_view->docid->getViewValue() ?></span>
</span>
</td>
	</tr>
<?php } ?>
<?php if ($merchantkycdocs_view->_userid->Visible) { // userid ?>
	<tr id="r__userid">
		<td class="<?php echo $merchantkycdocs_view->TableLeftColumnClass ?>"><span id="elh_merchantkycdocs__userid"><?php echo $merchantkycdocs_view->_userid->caption() ?></span></td>
		<td data-name="_userid" <?php echo $merchantkycdocs_view->_userid->cellAttributes() ?>>
<span id="el_merchantkycdocs__userid">
<span<?php echo $merchantkycdocs_view->_userid->viewAttributes() ?>><?php echo $merchantkycdocs_view->_userid->getViewValue() ?></span>
</span>
</td>
	</tr>
<?php } ?>
<?php if ($merchantkycdocs_view->dockey->Visible) { // dockey ?>
	<tr id="r_dockey">
		<td class="<?php echo $merchantkycdocs_view->TableLeftColumnClass ?>"><span id="elh_merchantkycdocs_dockey"><?php echo $merchantkycdocs_view->dockey->caption() ?></span></td>
		<td data-name="dockey" <?php echo $merchantkycdocs_view->dockey->cellAttributes() ?>>
<span id="el_merchantkycdocs_dockey">
<span<?php echo $merchantkycdocs_view->dockey->viewAttributes() ?>><?php echo $merchantkycdocs_view->dockey->getViewValue() ?></span>
</span>
</td>
	</tr>
<?php } ?>
<?php if ($merchantkycdocs_view->name->Visible) { // name ?>
	<tr id="r_name">
		<td class="<?php echo $merchantkycdocs_view->TableLeftColumnClass ?>"><span id="elh_merchantkycdocs_name"><?php echo $merchantkycdocs_view->name->caption() ?></span></td>
		<td data-name="name" <?php echo $merchantkycdocs_view->name->cellAttributes() ?>>
<span id="el_merchantkycdocs_name">
<span<?php echo $merchantkycdocs_view->name->viewAttributes() ?>><?php echo $merchantkycdocs_view->name->getViewValue() ?></span>
</span>
</td>
	</tr>
<?php } ?>
<?php if ($merchantkycdocs_view->expirydate->Visible) { // expirydate ?>
	<tr id="r_expirydate">
		<td class="<?php echo $merchantkycdocs_view->TableLeftColumnClass ?>"><span id="elh_merchantkycdocs_expirydate"><?php echo $merchantkycdocs_view->expirydate->caption() ?></span></td>
		<td data-name="expirydate" <?php echo $merchantkycdocs_view->expirydate->cellAttributes() ?>>
<span id="el_merchantkycdocs_expirydate">
<span<?php echo $merchantkycdocs_view->expirydate->viewAttributes() ?>><?php echo $merchantkycdocs_view->expirydate->getViewValue() ?></span>
</span>
</td>
	</tr>
<?php } ?>
<?php if ($merchantkycdocs_view->deleted->Visible) { // deleted ?>
	<tr id="r_deleted">
		<td class="<?php echo $merchantkycdocs_view->TableLeftColumnClass ?>"><span id="elh_merchantkycdocs_deleted"><?php echo $merchantkycdocs_view->deleted->caption() ?></span></td>
		<td data-name="deleted" <?php echo $merchantkycdocs_view->deleted->cellAttributes() ?>>
<span id="el_merchantkycdocs_deleted">
<span<?php echo $merchantkycdocs_view->deleted->viewAttributes() ?>><?php echo $merchantkycdocs_view->deleted->getViewValue() ?></span>
</span>
</td>
	</tr>
<?php } ?>
<?php if ($merchantkycdocs_view->visible->Visible) { // visible ?>
	<tr id="r_visible">
		<td class="<?php echo $merchantkycdocs_view->TableLeftColumnClass ?>"><span id="elh_merchantkycdocs_visible"><?php echo $merchantkycdocs_view->visible->caption() ?></span></td>
		<td data-name="visible" <?php echo $merchantkycdocs_view->visible->cellAttributes() ?>>
<span id="el_merchantkycdocs_visible">
<span<?php echo $merchantkycdocs_view->visible->viewAttributes() ?>><?php echo $merchantkycdocs_view->visible->getViewValue() ?></span>
</span>
</td>
	</tr>
<?php } ?>
<?php if ($merchantkycdocs_view->doctype->Visible) { // doctype ?>
	<tr id="r_doctype">
		<td class="<?php echo $merchantkycdocs_view->TableLeftColumnClass ?>"><span id="elh_merchantkycdocs_doctype"><?php echo $merchantkycdocs_view->doctype->caption() ?></span></td>
		<td data-name="doctype" <?php echo $merchantkycdocs_view->doctype->cellAttributes() ?>>
<span id="el_merchantkycdocs_doctype">
<span<?php echo $merchantkycdocs_view->doctype->viewAttributes() ?>><?php echo $merchantkycdocs_view->doctype->getViewValue() ?></span>
</span>
</td>
	</tr>
<?php } ?>
<?php if ($merchantkycdocs_view->groupid->Visible) { // groupid ?>
	<tr id="r_groupid">
		<td class="<?php echo $merchantkycdocs_view->TableLeftColumnClass ?>"><span id="elh_merchantkycdocs_groupid"><?php echo $merchantkycdocs_view->groupid->caption() ?></span></td>
		<td data-name="groupid" <?php echo $merchantkycdocs_view->groupid->cellAttributes() ?>>
<span id="el_merchantkycdocs_groupid">
<span<?php echo $merchantkycdocs_view->groupid->viewAttributes() ?>><?php echo $merchantkycdocs_view->groupid->getViewValue() ?></span>
</span>
</td>
	</tr>
<?php } ?>
<?php if ($merchantkycdocs_view->creationtime->Visible) { // creationtime ?>
	<tr id="r_creationtime">
		<td class="<?php echo $merchantkycdocs_view->TableLeftColumnClass ?>"><span id="elh_merchantkycdocs_creationtime"><?php echo $merchantkycdocs_view->creationtime->caption() ?></span></td>
		<td data-name="creationtime" <?php echo $merchantkycdocs_view->creationtime->cellAttributes() ?>>
<span id="el_merchantkycdocs_creationtime">
<span<?php echo $merchantkycdocs_view->creationtime->viewAttributes() ?>><?php echo $merchantkycdocs_view->creationtime->getViewValue() ?></span>
</span>
</td>
	</tr>
<?php } ?>
</table>
</form>
<?php
$merchantkycdocs_view->showPageFooter();
if (Config("DEBUG"))
	echo GetDebugMessage();
?>
<?php if (!$merchantkycdocs_view->isExport()) { ?>
<script>
loadjs.ready("load", function() {

	// Startup script
	// Write your table-specific startup script here
	// console.log("page loaded");

});
</script>
<?php } ?>
<?php include_once "footer.php"; ?>
<?php
$merchantkycdocs_view->terminate();
?>