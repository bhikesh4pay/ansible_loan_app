<?php
namespace PHPMaker2020\_4payadmin;

// Autoload
include_once "autoload.php";

// Session
if (session_status() !== PHP_SESSION_ACTIVE)
	\Delight\Cookie\Session::start(Config("COOKIE_SAMESITE")); // Init session data

// Output buffering
ob_start();
?>
<?php

// Write header
WriteHeader(FALSE);

// Create page object
$useremailaccount_list = new useremailaccount_list();

// Run the page
$useremailaccount_list->run();

// Setup login status
SetupLoginStatus();
SetClientVar("login", LoginStatus());

// Global Page Rendering event (in userfn*.php)
Page_Rendering();

// Page Rendering event
$useremailaccount_list->Page_Render();
?>
<?php include_once "header.php"; ?>
<?php if (!$useremailaccount_list->isExport()) { ?>
<script>
var fuseremailaccountlist, currentPageID;
loadjs.ready("head", function() {

	// Form object
	currentPageID = ew.PAGE_ID = "list";
	fuseremailaccountlist = currentForm = new ew.Form("fuseremailaccountlist", "list");
	fuseremailaccountlist.formKeyCountName = '<?php echo $useremailaccount_list->FormKeyCountName ?>';
	loadjs.done("fuseremailaccountlist");
});
var fuseremailaccountlistsrch;
loadjs.ready("head", function() {

	// Form object for search
	fuseremailaccountlistsrch = currentSearchForm = new ew.Form("fuseremailaccountlistsrch");

	// Dynamic selection lists
	// Filters

	fuseremailaccountlistsrch.filterList = <?php echo $useremailaccount_list->getFilterList() ?>;

	// Init search panel as collapsed
	fuseremailaccountlistsrch.initSearchPanel = true;
	loadjs.done("fuseremailaccountlistsrch");
});
</script>
<style type="text/css">
.ew-table-preview-row { /* main table preview row color */
	background-color: #FFFFFF; /* preview row color */
}
.ew-table-preview-row .ew-grid {
	display: table;
}
</style>
<div id="ew-preview" class="d-none"><!-- preview -->
	<div class="ew-nav-tabs"><!-- .ew-nav-tabs -->
		<ul class="nav nav-tabs"></ul>
		<div class="tab-content"><!-- .tab-content -->
			<div class="tab-pane fade active show"></div>
		</div><!-- /.tab-content -->
	</div><!-- /.ew-nav-tabs -->
</div><!-- /preview -->
<script>
loadjs.ready("head", function() {
	ew.PREVIEW_PLACEMENT = ew.CSS_FLIP ? "right" : "left";
	ew.PREVIEW_SINGLE_ROW = false;
	ew.PREVIEW_OVERLAY = false;
	loadjs("js/ewpreview.js", "preview");
});
</script>
<script>
loadjs.ready("head", function() {

	// Client script
	// Write your client script here, no need to add script tags.

});
</script>
<?php } ?>
<?php if (!$useremailaccount_list->isExport()) { ?>
<div class="btn-toolbar ew-toolbar">
<?php if ($useremailaccount_list->TotalRecords > 0 && $useremailaccount_list->ExportOptions->visible()) { ?>
<?php $useremailaccount_list->ExportOptions->render("body") ?>
<?php } ?>
<?php if ($useremailaccount_list->ImportOptions->visible()) { ?>
<?php $useremailaccount_list->ImportOptions->render("body") ?>
<?php } ?>
<?php if ($useremailaccount_list->SearchOptions->visible()) { ?>
<?php $useremailaccount_list->SearchOptions->render("body") ?>
<?php } ?>
<?php if ($useremailaccount_list->FilterOptions->visible()) { ?>
<?php $useremailaccount_list->FilterOptions->render("body") ?>
<?php } ?>
<div class="clearfix"></div>
</div>
<?php } ?>
<?php if (!$useremailaccount_list->isExport() || Config("EXPORT_MASTER_RECORD") && $useremailaccount_list->isExport("print")) { ?>
<?php
if ($useremailaccount_list->DbMasterFilter != "" && $useremailaccount->getCurrentMasterTable() == "user") {
	if ($useremailaccount_list->MasterRecordExists) {
		include_once "usermaster.php";
	}
}
?>
<?php } ?>
<?php
$useremailaccount_list->renderOtherOptions();
?>
<?php if ($Security->CanSearch()) { ?>
<?php if (!$useremailaccount_list->isExport() && !$useremailaccount->CurrentAction) { ?>
<form name="fuseremailaccountlistsrch" id="fuseremailaccountlistsrch" class="form-inline ew-form ew-ext-search-form" action="<?php echo CurrentPageName() ?>">
<div id="fuseremailaccountlistsrch-search-panel" class="<?php echo $useremailaccount_list->SearchPanelClass ?>">
<input type="hidden" name="cmd" value="search">
<input type="hidden" name="t" value="useremailaccount">
	<div class="ew-extended-search">
<div id="xsr_<?php echo $useremailaccount_list->SearchRowCount + 1 ?>" class="ew-row d-sm-flex">
	<div class="ew-quick-search input-group">
		<input type="text" name="<?php echo Config("TABLE_BASIC_SEARCH") ?>" id="<?php echo Config("TABLE_BASIC_SEARCH") ?>" class="form-control" value="<?php echo HtmlEncode($useremailaccount_list->BasicSearch->getKeyword()) ?>" placeholder="<?php echo HtmlEncode($Language->phrase("Search")) ?>">
		<input type="hidden" name="<?php echo Config("TABLE_BASIC_SEARCH_TYPE") ?>" id="<?php echo Config("TABLE_BASIC_SEARCH_TYPE") ?>" value="<?php echo HtmlEncode($useremailaccount_list->BasicSearch->getType()) ?>">
		<div class="input-group-append">
			<button class="btn btn-primary" name="btn-submit" id="btn-submit" type="submit"><?php echo $Language->phrase("SearchBtn") ?></button>
			<button type="button" data-toggle="dropdown" class="btn btn-primary dropdown-toggle dropdown-toggle-split" aria-haspopup="true" aria-expanded="false"><span id="searchtype"><?php echo $useremailaccount_list->BasicSearch->getTypeNameShort() ?></span></button>
			<div class="dropdown-menu dropdown-menu-right">
				<a class="dropdown-item<?php if ($useremailaccount_list->BasicSearch->getType() == "") { ?> active<?php } ?>" href="#" onclick="return ew.setSearchType(this);"><?php echo $Language->phrase("QuickSearchAuto") ?></a>
				<a class="dropdown-item<?php if ($useremailaccount_list->BasicSearch->getType() == "=") { ?> active<?php } ?>" href="#" onclick="return ew.setSearchType(this, '=');"><?php echo $Language->phrase("QuickSearchExact") ?></a>
				<a class="dropdown-item<?php if ($useremailaccount_list->BasicSearch->getType() == "AND") { ?> active<?php } ?>" href="#" onclick="return ew.setSearchType(this, 'AND');"><?php echo $Language->phrase("QuickSearchAll") ?></a>
				<a class="dropdown-item<?php if ($useremailaccount_list->BasicSearch->getType() == "OR") { ?> active<?php } ?>" href="#" onclick="return ew.setSearchType(this, 'OR');"><?php echo $Language->phrase("QuickSearchAny") ?></a>
			</div>
		</div>
	</div>
</div>
	</div><!-- /.ew-extended-search -->
</div><!-- /.ew-search-panel -->
</form>
<?php } ?>
<?php } ?>
<?php $useremailaccount_list->showPageHeader(); ?>
<?php
$useremailaccount_list->showMessage();
?>
<?php if ($useremailaccount_list->TotalRecords > 0 || $useremailaccount->CurrentAction) { ?>
<div class="card ew-card ew-grid<?php if ($useremailaccount_list->isAddOrEdit()) { ?> ew-grid-add-edit<?php } ?> useremailaccount">
<form name="fuseremailaccountlist" id="fuseremailaccountlist" class="form-inline ew-form ew-list-form" action="<?php echo CurrentPageName() ?>" method="post">
<?php if ($Page->CheckToken) { ?>
<input type="hidden" name="<?php echo Config("TOKEN_NAME") ?>" value="<?php echo $Page->Token ?>">
<?php } ?>
<input type="hidden" name="t" value="useremailaccount">
<?php if ($useremailaccount->getCurrentMasterTable() == "user" && $useremailaccount->CurrentAction) { ?>
<input type="hidden" name="<?php echo Config("TABLE_SHOW_MASTER") ?>" value="user">
<input type="hidden" name="fk_id" value="<?php echo HtmlEncode($useremailaccount_list->_userID->getSessionValue()) ?>">
<?php } ?>
<div id="gmp_useremailaccount" class="<?php echo ResponsiveTableClass() ?>card-body ew-grid-middle-panel">
<?php if ($useremailaccount_list->TotalRecords > 0 || $useremailaccount_list->isGridEdit()) { ?>
<table id="tbl_useremailaccountlist" class="table ew-table"><!-- .ew-table -->
<thead>
	<tr class="ew-table-header">
<?php

// Header row
$useremailaccount->RowType = ROWTYPE_HEADER;

// Render list options
$useremailaccount_list->renderListOptions();

// Render list options (header, left)
$useremailaccount_list->ListOptions->render("header", "left");
?>
<?php if ($useremailaccount_list->_userID->Visible) { // userID ?>
	<?php if ($useremailaccount_list->SortUrl($useremailaccount_list->_userID) == "") { ?>
		<th data-name="_userID" class="<?php echo $useremailaccount_list->_userID->headerCellClass() ?>"><div id="elh_useremailaccount__userID" class="useremailaccount__userID"><div class="ew-table-header-caption"><?php echo $useremailaccount_list->_userID->caption() ?></div></div></th>
	<?php } else { ?>
		<th data-name="_userID" class="<?php echo $useremailaccount_list->_userID->headerCellClass() ?>"><div class="ew-pointer" onclick="ew.sort(event, '<?php echo $useremailaccount_list->SortUrl($useremailaccount_list->_userID) ?>', 1);"><div id="elh_useremailaccount__userID" class="useremailaccount__userID">
			<div class="ew-table-header-btn"><span class="ew-table-header-caption"><?php echo $useremailaccount_list->_userID->caption() ?></span><span class="ew-table-header-sort"><?php if ($useremailaccount_list->_userID->getSort() == "ASC") { ?><i class="fas fa-sort-up"></i><?php } elseif ($useremailaccount_list->_userID->getSort() == "DESC") { ?><i class="fas fa-sort-down"></i><?php } ?></span></div>
		</div></div></th>
	<?php } ?>
<?php } ?>
<?php if ($useremailaccount_list->emailAccount->Visible) { // emailAccount ?>
	<?php if ($useremailaccount_list->SortUrl($useremailaccount_list->emailAccount) == "") { ?>
		<th data-name="emailAccount" class="<?php echo $useremailaccount_list->emailAccount->headerCellClass() ?>"><div id="elh_useremailaccount_emailAccount" class="useremailaccount_emailAccount"><div class="ew-table-header-caption"><?php echo $useremailaccount_list->emailAccount->caption() ?></div></div></th>
	<?php } else { ?>
		<th data-name="emailAccount" class="<?php echo $useremailaccount_list->emailAccount->headerCellClass() ?>"><div class="ew-pointer" onclick="ew.sort(event, '<?php echo $useremailaccount_list->SortUrl($useremailaccount_list->emailAccount) ?>', 1);"><div id="elh_useremailaccount_emailAccount" class="useremailaccount_emailAccount">
			<div class="ew-table-header-btn"><span class="ew-table-header-caption"><?php echo $useremailaccount_list->emailAccount->caption() ?><?php echo $Language->phrase("SrchLegend") ?></span><span class="ew-table-header-sort"><?php if ($useremailaccount_list->emailAccount->getSort() == "ASC") { ?><i class="fas fa-sort-up"></i><?php } elseif ($useremailaccount_list->emailAccount->getSort() == "DESC") { ?><i class="fas fa-sort-down"></i><?php } ?></span></div>
		</div></div></th>
	<?php } ?>
<?php } ?>
<?php if ($useremailaccount_list->dateAdded->Visible) { // dateAdded ?>
	<?php if ($useremailaccount_list->SortUrl($useremailaccount_list->dateAdded) == "") { ?>
		<th data-name="dateAdded" class="<?php echo $useremailaccount_list->dateAdded->headerCellClass() ?>"><div id="elh_useremailaccount_dateAdded" class="useremailaccount_dateAdded"><div class="ew-table-header-caption"><?php echo $useremailaccount_list->dateAdded->caption() ?></div></div></th>
	<?php } else { ?>
		<th data-name="dateAdded" class="<?php echo $useremailaccount_list->dateAdded->headerCellClass() ?>"><div class="ew-pointer" onclick="ew.sort(event, '<?php echo $useremailaccount_list->SortUrl($useremailaccount_list->dateAdded) ?>', 1);"><div id="elh_useremailaccount_dateAdded" class="useremailaccount_dateAdded">
			<div class="ew-table-header-btn"><span class="ew-table-header-caption"><?php echo $useremailaccount_list->dateAdded->caption() ?></span><span class="ew-table-header-sort"><?php if ($useremailaccount_list->dateAdded->getSort() == "ASC") { ?><i class="fas fa-sort-up"></i><?php } elseif ($useremailaccount_list->dateAdded->getSort() == "DESC") { ?><i class="fas fa-sort-down"></i><?php } ?></span></div>
		</div></div></th>
	<?php } ?>
<?php } ?>
<?php if ($useremailaccount_list->confirmationReceived->Visible) { // confirmationReceived ?>
	<?php if ($useremailaccount_list->SortUrl($useremailaccount_list->confirmationReceived) == "") { ?>
		<th data-name="confirmationReceived" class="<?php echo $useremailaccount_list->confirmationReceived->headerCellClass() ?>"><div id="elh_useremailaccount_confirmationReceived" class="useremailaccount_confirmationReceived"><div class="ew-table-header-caption"><?php echo $useremailaccount_list->confirmationReceived->caption() ?></div></div></th>
	<?php } else { ?>
		<th data-name="confirmationReceived" class="<?php echo $useremailaccount_list->confirmationReceived->headerCellClass() ?>"><div class="ew-pointer" onclick="ew.sort(event, '<?php echo $useremailaccount_list->SortUrl($useremailaccount_list->confirmationReceived) ?>', 1);"><div id="elh_useremailaccount_confirmationReceived" class="useremailaccount_confirmationReceived">
			<div class="ew-table-header-btn"><span class="ew-table-header-caption"><?php echo $useremailaccount_list->confirmationReceived->caption() ?></span><span class="ew-table-header-sort"><?php if ($useremailaccount_list->confirmationReceived->getSort() == "ASC") { ?><i class="fas fa-sort-up"></i><?php } elseif ($useremailaccount_list->confirmationReceived->getSort() == "DESC") { ?><i class="fas fa-sort-down"></i><?php } ?></span></div>
		</div></div></th>
	<?php } ?>
<?php } ?>
<?php if ($useremailaccount_list->active->Visible) { // active ?>
	<?php if ($useremailaccount_list->SortUrl($useremailaccount_list->active) == "") { ?>
		<th data-name="active" class="<?php echo $useremailaccount_list->active->headerCellClass() ?>"><div id="elh_useremailaccount_active" class="useremailaccount_active"><div class="ew-table-header-caption"><?php echo $useremailaccount_list->active->caption() ?></div></div></th>
	<?php } else { ?>
		<th data-name="active" class="<?php echo $useremailaccount_list->active->headerCellClass() ?>"><div class="ew-pointer" onclick="ew.sort(event, '<?php echo $useremailaccount_list->SortUrl($useremailaccount_list->active) ?>', 1);"><div id="elh_useremailaccount_active" class="useremailaccount_active">
			<div class="ew-table-header-btn"><span class="ew-table-header-caption"><?php echo $useremailaccount_list->active->caption() ?></span><span class="ew-table-header-sort"><?php if ($useremailaccount_list->active->getSort() == "ASC") { ?><i class="fas fa-sort-up"></i><?php } elseif ($useremailaccount_list->active->getSort() == "DESC") { ?><i class="fas fa-sort-down"></i><?php } ?></span></div>
		</div></div></th>
	<?php } ?>
<?php } ?>
<?php

// Render list options (header, right)
$useremailaccount_list->ListOptions->render("header", "right");
?>
	</tr>
</thead>
<tbody>
<?php
if ($useremailaccount_list->ExportAll && $useremailaccount_list->isExport()) {
	$useremailaccount_list->StopRecord = $useremailaccount_list->TotalRecords;
} else {

	// Set the last record to display
	if ($useremailaccount_list->TotalRecords > $useremailaccount_list->StartRecord + $useremailaccount_list->DisplayRecords - 1)
		$useremailaccount_list->StopRecord = $useremailaccount_list->StartRecord + $useremailaccount_list->DisplayRecords - 1;
	else
		$useremailaccount_list->StopRecord = $useremailaccount_list->TotalRecords;
}
$useremailaccount_list->RecordCount = $useremailaccount_list->StartRecord - 1;
if ($useremailaccount_list->Recordset && !$useremailaccount_list->Recordset->EOF) {
	$useremailaccount_list->Recordset->moveFirst();
	$selectLimit = $useremailaccount_list->UseSelectLimit;
	if (!$selectLimit && $useremailaccount_list->StartRecord > 1)
		$useremailaccount_list->Recordset->move($useremailaccount_list->StartRecord - 1);
} elseif (!$useremailaccount->AllowAddDeleteRow && $useremailaccount_list->StopRecord == 0) {
	$useremailaccount_list->StopRecord = $useremailaccount->GridAddRowCount;
}

// Initialize aggregate
$useremailaccount->RowType = ROWTYPE_AGGREGATEINIT;
$useremailaccount->resetAttributes();
$useremailaccount_list->renderRow();
while ($useremailaccount_list->RecordCount < $useremailaccount_list->StopRecord) {
	$useremailaccount_list->RecordCount++;
	if ($useremailaccount_list->RecordCount >= $useremailaccount_list->StartRecord) {
		$useremailaccount_list->RowCount++;

		// Set up key count
		$useremailaccount_list->KeyCount = $useremailaccount_list->RowIndex;

		// Init row class and style
		$useremailaccount->resetAttributes();
		$useremailaccount->CssClass = "";
		if ($useremailaccount_list->isGridAdd()) {
		} else {
			$useremailaccount_list->loadRowValues($useremailaccount_list->Recordset); // Load row values
		}
		$useremailaccount->RowType = ROWTYPE_VIEW; // Render view

		// Set up row id / data-rowindex
		$useremailaccount->RowAttrs->merge(["data-rowindex" => $useremailaccount_list->RowCount, "id" => "r" . $useremailaccount_list->RowCount . "_useremailaccount", "data-rowtype" => $useremailaccount->RowType]);

		// Render row
		$useremailaccount_list->renderRow();

		// Render list options
		$useremailaccount_list->renderListOptions();
?>
	<tr <?php echo $useremailaccount->rowAttributes() ?>>
<?php

// Render list options (body, left)
$useremailaccount_list->ListOptions->render("body", "left", $useremailaccount_list->RowCount);
?>
	<?php if ($useremailaccount_list->_userID->Visible) { // userID ?>
		<td data-name="_userID" <?php echo $useremailaccount_list->_userID->cellAttributes() ?>>
<span id="el<?php echo $useremailaccount_list->RowCount ?>_useremailaccount__userID">
<span<?php echo $useremailaccount_list->_userID->viewAttributes() ?>><?php if (!EmptyString($useremailaccount_list->_userID->getViewValue()) && $useremailaccount_list->_userID->linkAttributes() != "") { ?>
<a<?php echo $useremailaccount_list->_userID->linkAttributes() ?>><?php echo $useremailaccount_list->_userID->getViewValue() ?></a>
<?php } else { ?>
<?php echo $useremailaccount_list->_userID->getViewValue() ?>
<?php } ?></span>
</span>
</td>
	<?php } ?>
	<?php if ($useremailaccount_list->emailAccount->Visible) { // emailAccount ?>
		<td data-name="emailAccount" <?php echo $useremailaccount_list->emailAccount->cellAttributes() ?>>
<span id="el<?php echo $useremailaccount_list->RowCount ?>_useremailaccount_emailAccount">
<span<?php echo $useremailaccount_list->emailAccount->viewAttributes() ?>><?php echo $useremailaccount_list->emailAccount->getViewValue() ?></span>
</span>
</td>
	<?php } ?>
	<?php if ($useremailaccount_list->dateAdded->Visible) { // dateAdded ?>
		<td data-name="dateAdded" <?php echo $useremailaccount_list->dateAdded->cellAttributes() ?>>
<span id="el<?php echo $useremailaccount_list->RowCount ?>_useremailaccount_dateAdded">
<span<?php echo $useremailaccount_list->dateAdded->viewAttributes() ?>><?php echo $useremailaccount_list->dateAdded->getViewValue() ?></span>
</span>
</td>
	<?php } ?>
	<?php if ($useremailaccount_list->confirmationReceived->Visible) { // confirmationReceived ?>
		<td data-name="confirmationReceived" <?php echo $useremailaccount_list->confirmationReceived->cellAttributes() ?>>
<span id="el<?php echo $useremailaccount_list->RowCount ?>_useremailaccount_confirmationReceived">
<span<?php echo $useremailaccount_list->confirmationReceived->viewAttributes() ?>><?php echo $useremailaccount_list->confirmationReceived->getViewValue() ?></span>
</span>
</td>
	<?php } ?>
	<?php if ($useremailaccount_list->active->Visible) { // active ?>
		<td data-name="active" <?php echo $useremailaccount_list->active->cellAttributes() ?>>
<span id="el<?php echo $useremailaccount_list->RowCount ?>_useremailaccount_active">
<span<?php echo $useremailaccount_list->active->viewAttributes() ?>><?php echo $useremailaccount_list->active->getViewValue() ?></span>
</span>
</td>
	<?php } ?>
<?php

// Render list options (body, right)
$useremailaccount_list->ListOptions->render("body", "right", $useremailaccount_list->RowCount);
?>
	</tr>
<?php
	}
	if (!$useremailaccount_list->isGridAdd())
		$useremailaccount_list->Recordset->moveNext();
}
?>
</tbody>
</table><!-- /.ew-table -->
<?php } ?>
</div><!-- /.ew-grid-middle-panel -->
<?php if (!$useremailaccount->CurrentAction) { ?>
<input type="hidden" name="action" id="action" value="">
<?php } ?>
</form><!-- /.ew-list-form -->
<?php

// Close recordset
if ($useremailaccount_list->Recordset)
	$useremailaccount_list->Recordset->Close();
?>
<?php if (!$useremailaccount_list->isExport()) { ?>
<div class="card-footer ew-grid-lower-panel">
<?php if (!$useremailaccount_list->isGridAdd()) { ?>
<form name="ew-pager-form" class="form-inline ew-form ew-pager-form" action="<?php echo CurrentPageName() ?>">
<?php echo $useremailaccount_list->Pager->render() ?>
</form>
<?php } ?>
<div class="ew-list-other-options">
<?php $useremailaccount_list->OtherOptions->render("body", "bottom") ?>
</div>
<div class="clearfix"></div>
</div>
<?php } ?>
</div><!-- /.ew-grid -->
<?php } ?>
<?php if ($useremailaccount_list->TotalRecords == 0 && !$useremailaccount->CurrentAction) { // Show other options ?>
<div class="ew-list-other-options">
<?php $useremailaccount_list->OtherOptions->render("body") ?>
</div>
<div class="clearfix"></div>
<?php } ?>
<?php
$useremailaccount_list->showPageFooter();
if (Config("DEBUG"))
	echo GetDebugMessage();
?>
<?php if (!$useremailaccount_list->isExport()) { ?>
<script>
loadjs.ready("load", function() {

	// Startup script
	// Write your table-specific startup script here
	// console.log("page loaded");

});
</script>
<?php } ?>
<?php include_once "footer.php"; ?>
<?php
$useremailaccount_list->terminate();
?>