<?php
namespace PHPMaker2020\_4payadmin;

// Write header
WriteHeader(FALSE);

// Create page object
if (!isset($userdevices_grid))
	$userdevices_grid = new userdevices_grid();

// Run the page
$userdevices_grid->run();

// Setup login status
SetupLoginStatus();
SetClientVar("login", LoginStatus());

// Global Page Rendering event (in userfn*.php)
Page_Rendering();

// Page Rendering event
$userdevices_grid->Page_Render();
?>
<?php if (!$userdevices_grid->isExport()) { ?>
<script>
var fuserdevicesgrid, currentPageID;
loadjs.ready("head", function() {

	// Form object
	fuserdevicesgrid = new ew.Form("fuserdevicesgrid", "grid");
	fuserdevicesgrid.formKeyCountName = '<?php echo $userdevices_grid->FormKeyCountName ?>';

	// Validate form
	fuserdevicesgrid.validate = function() {
		if (!this.validateRequired)
			return true; // Ignore validation
		var $ = jQuery, fobj = this.getForm(), $fobj = $(fobj);
		if ($fobj.find("#confirm").val() == "confirm")
			return true;
		var elm, felm, uelm, addcnt = 0;
		var $k = $fobj.find("#" + this.formKeyCountName); // Get key_count
		var rowcnt = ($k[0]) ? parseInt($k.val(), 10) : 1;
		var startcnt = (rowcnt == 0) ? 0 : 1; // Check rowcnt == 0 => Inline-Add
		var gridinsert = ["insert", "gridinsert"].includes($fobj.find("#action").val()) && $k[0];
		for (var i = startcnt; i <= rowcnt; i++) {
			var infix = ($k[0]) ? String(i) : "";
			$fobj.data("rowindex", infix);
			var checkrow = (gridinsert) ? !this.emptyRow(infix) : true;
			if (checkrow) {
				addcnt++;
			<?php if ($userdevices_grid->id->Required) { ?>
				elm = this.getElements("x" + infix + "_id");
				if (elm && !ew.isHidden(elm) && !ew.hasValue(elm))
					return this.onError(elm, "<?php echo JsEncode(str_replace("%s", $userdevices_grid->id->caption(), $userdevices_grid->id->RequiredErrorMessage)) ?>");
			<?php } ?>
			<?php if ($userdevices_grid->deviceid->Required) { ?>
				elm = this.getElements("x" + infix + "_deviceid");
				if (elm && !ew.isHidden(elm) && !ew.hasValue(elm))
					return this.onError(elm, "<?php echo JsEncode(str_replace("%s", $userdevices_grid->deviceid->caption(), $userdevices_grid->deviceid->RequiredErrorMessage)) ?>");
			<?php } ?>
			<?php if ($userdevices_grid->_userid->Required) { ?>
				elm = this.getElements("x" + infix + "__userid");
				if (elm && !ew.isHidden(elm) && !ew.hasValue(elm))
					return this.onError(elm, "<?php echo JsEncode(str_replace("%s", $userdevices_grid->_userid->caption(), $userdevices_grid->_userid->RequiredErrorMessage)) ?>");
			<?php } ?>
				elm = this.getElements("x" + infix + "__userid");
				if (elm && !ew.checkInteger(elm.value))
					return this.onError(elm, "<?php echo JsEncode($userdevices_grid->_userid->errorMessage()) ?>");
			<?php if ($userdevices_grid->devicetoken->Required) { ?>
				elm = this.getElements("x" + infix + "_devicetoken");
				if (elm && !ew.isHidden(elm) && !ew.hasValue(elm))
					return this.onError(elm, "<?php echo JsEncode(str_replace("%s", $userdevices_grid->devicetoken->caption(), $userdevices_grid->devicetoken->RequiredErrorMessage)) ?>");
			<?php } ?>
			<?php if ($userdevices_grid->devicetype->Required) { ?>
				elm = this.getElements("x" + infix + "_devicetype");
				if (elm && !ew.isHidden(elm) && !ew.hasValue(elm))
					return this.onError(elm, "<?php echo JsEncode(str_replace("%s", $userdevices_grid->devicetype->caption(), $userdevices_grid->devicetype->RequiredErrorMessage)) ?>");
			<?php } ?>
			<?php if ($userdevices_grid->franchiseeid->Required) { ?>
				elm = this.getElements("x" + infix + "_franchiseeid");
				if (elm && !ew.isHidden(elm) && !ew.hasValue(elm))
					return this.onError(elm, "<?php echo JsEncode(str_replace("%s", $userdevices_grid->franchiseeid->caption(), $userdevices_grid->franchiseeid->RequiredErrorMessage)) ?>");
			<?php } ?>
				elm = this.getElements("x" + infix + "_franchiseeid");
				if (elm && !ew.checkInteger(elm.value))
					return this.onError(elm, "<?php echo JsEncode($userdevices_grid->franchiseeid->errorMessage()) ?>");
			<?php if ($userdevices_grid->active->Required) { ?>
				elm = this.getElements("x" + infix + "_active");
				if (elm && !ew.isHidden(elm) && !ew.hasValue(elm))
					return this.onError(elm, "<?php echo JsEncode(str_replace("%s", $userdevices_grid->active->caption(), $userdevices_grid->active->RequiredErrorMessage)) ?>");
			<?php } ?>
			<?php if ($userdevices_grid->enrolledtime->Required) { ?>
				elm = this.getElements("x" + infix + "_enrolledtime");
				if (elm && !ew.isHidden(elm) && !ew.hasValue(elm))
					return this.onError(elm, "<?php echo JsEncode(str_replace("%s", $userdevices_grid->enrolledtime->caption(), $userdevices_grid->enrolledtime->RequiredErrorMessage)) ?>");
			<?php } ?>
				elm = this.getElements("x" + infix + "_enrolledtime");
				if (elm && !ew.checkDateDef(elm.value))
					return this.onError(elm, "<?php echo JsEncode($userdevices_grid->enrolledtime->errorMessage()) ?>");
			<?php if ($userdevices_grid->lastlogin->Required) { ?>
				elm = this.getElements("x" + infix + "_lastlogin");
				if (elm && !ew.isHidden(elm) && !ew.hasValue(elm))
					return this.onError(elm, "<?php echo JsEncode(str_replace("%s", $userdevices_grid->lastlogin->caption(), $userdevices_grid->lastlogin->RequiredErrorMessage)) ?>");
			<?php } ?>
				elm = this.getElements("x" + infix + "_lastlogin");
				if (elm && !ew.checkDateDef(elm.value))
					return this.onError(elm, "<?php echo JsEncode($userdevices_grid->lastlogin->errorMessage()) ?>");

				// Call Form_CustomValidate event
				if (!this.Form_CustomValidate(fobj))
					return false;
			} // End Grid Add checking
		}
		return true;
	}

	// Check empty row
	fuserdevicesgrid.emptyRow = function(infix) {
		var fobj = this._form;
		if (ew.valueChanged(fobj, infix, "deviceid", false)) return false;
		if (ew.valueChanged(fobj, infix, "_userid", false)) return false;
		if (ew.valueChanged(fobj, infix, "devicetoken", false)) return false;
		if (ew.valueChanged(fobj, infix, "devicetype", false)) return false;
		if (ew.valueChanged(fobj, infix, "franchiseeid", false)) return false;
		if (ew.valueChanged(fobj, infix, "active", false)) return false;
		if (ew.valueChanged(fobj, infix, "enrolledtime", false)) return false;
		if (ew.valueChanged(fobj, infix, "lastlogin", false)) return false;
		return true;
	}

	// Form_CustomValidate
	fuserdevicesgrid.Form_CustomValidate = function(fobj) { // DO NOT CHANGE THIS LINE!

		// Your custom validation code here, return false if invalid.
		return true;
	}

	// Use JavaScript validation or not
	fuserdevicesgrid.validateRequired = <?php echo Config("CLIENT_VALIDATE") ? "true" : "false" ?>;

	// Dynamic selection lists
	fuserdevicesgrid.lists["x_active"] = <?php echo $userdevices_grid->active->Lookup->toClientList($userdevices_grid) ?>;
	fuserdevicesgrid.lists["x_active"].options = <?php echo JsonEncode($userdevices_grid->active->lookupOptions()) ?>;
	loadjs.done("fuserdevicesgrid");
});
</script>
<?php } ?>
<?php
$userdevices_grid->renderOtherOptions();
?>
<?php if ($userdevices_grid->TotalRecords > 0 || $userdevices->CurrentAction) { ?>
<div class="card ew-card ew-grid<?php if ($userdevices_grid->isAddOrEdit()) { ?> ew-grid-add-edit<?php } ?> userdevices">
<div id="fuserdevicesgrid" class="ew-form ew-list-form form-inline">
<div id="gmp_userdevices" class="<?php echo ResponsiveTableClass() ?>card-body ew-grid-middle-panel">
<table id="tbl_userdevicesgrid" class="table ew-table"><!-- .ew-table -->
<thead>
	<tr class="ew-table-header">
<?php

// Header row
$userdevices->RowType = ROWTYPE_HEADER;

// Render list options
$userdevices_grid->renderListOptions();

// Render list options (header, left)
$userdevices_grid->ListOptions->render("header", "left");
?>
<?php if ($userdevices_grid->id->Visible) { // id ?>
	<?php if ($userdevices_grid->SortUrl($userdevices_grid->id) == "") { ?>
		<th data-name="id" class="<?php echo $userdevices_grid->id->headerCellClass() ?>"><div id="elh_userdevices_id" class="userdevices_id"><div class="ew-table-header-caption"><?php echo $userdevices_grid->id->caption() ?></div></div></th>
	<?php } else { ?>
		<th data-name="id" class="<?php echo $userdevices_grid->id->headerCellClass() ?>"><div><div id="elh_userdevices_id" class="userdevices_id">
			<div class="ew-table-header-btn"><span class="ew-table-header-caption"><?php echo $userdevices_grid->id->caption() ?></span><span class="ew-table-header-sort"><?php if ($userdevices_grid->id->getSort() == "ASC") { ?><i class="fas fa-sort-up"></i><?php } elseif ($userdevices_grid->id->getSort() == "DESC") { ?><i class="fas fa-sort-down"></i><?php } ?></span></div>
		</div></div></th>
	<?php } ?>
<?php } ?>
<?php if ($userdevices_grid->deviceid->Visible) { // deviceid ?>
	<?php if ($userdevices_grid->SortUrl($userdevices_grid->deviceid) == "") { ?>
		<th data-name="deviceid" class="<?php echo $userdevices_grid->deviceid->headerCellClass() ?>"><div id="elh_userdevices_deviceid" class="userdevices_deviceid"><div class="ew-table-header-caption"><?php echo $userdevices_grid->deviceid->caption() ?></div></div></th>
	<?php } else { ?>
		<th data-name="deviceid" class="<?php echo $userdevices_grid->deviceid->headerCellClass() ?>"><div><div id="elh_userdevices_deviceid" class="userdevices_deviceid">
			<div class="ew-table-header-btn"><span class="ew-table-header-caption"><?php echo $userdevices_grid->deviceid->caption() ?></span><span class="ew-table-header-sort"><?php if ($userdevices_grid->deviceid->getSort() == "ASC") { ?><i class="fas fa-sort-up"></i><?php } elseif ($userdevices_grid->deviceid->getSort() == "DESC") { ?><i class="fas fa-sort-down"></i><?php } ?></span></div>
		</div></div></th>
	<?php } ?>
<?php } ?>
<?php if ($userdevices_grid->_userid->Visible) { // userid ?>
	<?php if ($userdevices_grid->SortUrl($userdevices_grid->_userid) == "") { ?>
		<th data-name="_userid" class="<?php echo $userdevices_grid->_userid->headerCellClass() ?>"><div id="elh_userdevices__userid" class="userdevices__userid"><div class="ew-table-header-caption"><?php echo $userdevices_grid->_userid->caption() ?></div></div></th>
	<?php } else { ?>
		<th data-name="_userid" class="<?php echo $userdevices_grid->_userid->headerCellClass() ?>"><div><div id="elh_userdevices__userid" class="userdevices__userid">
			<div class="ew-table-header-btn"><span class="ew-table-header-caption"><?php echo $userdevices_grid->_userid->caption() ?></span><span class="ew-table-header-sort"><?php if ($userdevices_grid->_userid->getSort() == "ASC") { ?><i class="fas fa-sort-up"></i><?php } elseif ($userdevices_grid->_userid->getSort() == "DESC") { ?><i class="fas fa-sort-down"></i><?php } ?></span></div>
		</div></div></th>
	<?php } ?>
<?php } ?>
<?php if ($userdevices_grid->devicetoken->Visible) { // devicetoken ?>
	<?php if ($userdevices_grid->SortUrl($userdevices_grid->devicetoken) == "") { ?>
		<th data-name="devicetoken" class="<?php echo $userdevices_grid->devicetoken->headerCellClass() ?>"><div id="elh_userdevices_devicetoken" class="userdevices_devicetoken"><div class="ew-table-header-caption"><?php echo $userdevices_grid->devicetoken->caption() ?></div></div></th>
	<?php } else { ?>
		<th data-name="devicetoken" class="<?php echo $userdevices_grid->devicetoken->headerCellClass() ?>"><div><div id="elh_userdevices_devicetoken" class="userdevices_devicetoken">
			<div class="ew-table-header-btn"><span class="ew-table-header-caption"><?php echo $userdevices_grid->devicetoken->caption() ?></span><span class="ew-table-header-sort"><?php if ($userdevices_grid->devicetoken->getSort() == "ASC") { ?><i class="fas fa-sort-up"></i><?php } elseif ($userdevices_grid->devicetoken->getSort() == "DESC") { ?><i class="fas fa-sort-down"></i><?php } ?></span></div>
		</div></div></th>
	<?php } ?>
<?php } ?>
<?php if ($userdevices_grid->devicetype->Visible) { // devicetype ?>
	<?php if ($userdevices_grid->SortUrl($userdevices_grid->devicetype) == "") { ?>
		<th data-name="devicetype" class="<?php echo $userdevices_grid->devicetype->headerCellClass() ?>"><div id="elh_userdevices_devicetype" class="userdevices_devicetype"><div class="ew-table-header-caption"><?php echo $userdevices_grid->devicetype->caption() ?></div></div></th>
	<?php } else { ?>
		<th data-name="devicetype" class="<?php echo $userdevices_grid->devicetype->headerCellClass() ?>"><div><div id="elh_userdevices_devicetype" class="userdevices_devicetype">
			<div class="ew-table-header-btn"><span class="ew-table-header-caption"><?php echo $userdevices_grid->devicetype->caption() ?></span><span class="ew-table-header-sort"><?php if ($userdevices_grid->devicetype->getSort() == "ASC") { ?><i class="fas fa-sort-up"></i><?php } elseif ($userdevices_grid->devicetype->getSort() == "DESC") { ?><i class="fas fa-sort-down"></i><?php } ?></span></div>
		</div></div></th>
	<?php } ?>
<?php } ?>
<?php if ($userdevices_grid->franchiseeid->Visible) { // franchiseeid ?>
	<?php if ($userdevices_grid->SortUrl($userdevices_grid->franchiseeid) == "") { ?>
		<th data-name="franchiseeid" class="<?php echo $userdevices_grid->franchiseeid->headerCellClass() ?>"><div id="elh_userdevices_franchiseeid" class="userdevices_franchiseeid"><div class="ew-table-header-caption"><?php echo $userdevices_grid->franchiseeid->caption() ?></div></div></th>
	<?php } else { ?>
		<th data-name="franchiseeid" class="<?php echo $userdevices_grid->franchiseeid->headerCellClass() ?>"><div><div id="elh_userdevices_franchiseeid" class="userdevices_franchiseeid">
			<div class="ew-table-header-btn"><span class="ew-table-header-caption"><?php echo $userdevices_grid->franchiseeid->caption() ?></span><span class="ew-table-header-sort"><?php if ($userdevices_grid->franchiseeid->getSort() == "ASC") { ?><i class="fas fa-sort-up"></i><?php } elseif ($userdevices_grid->franchiseeid->getSort() == "DESC") { ?><i class="fas fa-sort-down"></i><?php } ?></span></div>
		</div></div></th>
	<?php } ?>
<?php } ?>
<?php if ($userdevices_grid->active->Visible) { // active ?>
	<?php if ($userdevices_grid->SortUrl($userdevices_grid->active) == "") { ?>
		<th data-name="active" class="<?php echo $userdevices_grid->active->headerCellClass() ?>"><div id="elh_userdevices_active" class="userdevices_active"><div class="ew-table-header-caption"><?php echo $userdevices_grid->active->caption() ?></div></div></th>
	<?php } else { ?>
		<th data-name="active" class="<?php echo $userdevices_grid->active->headerCellClass() ?>"><div><div id="elh_userdevices_active" class="userdevices_active">
			<div class="ew-table-header-btn"><span class="ew-table-header-caption"><?php echo $userdevices_grid->active->caption() ?></span><span class="ew-table-header-sort"><?php if ($userdevices_grid->active->getSort() == "ASC") { ?><i class="fas fa-sort-up"></i><?php } elseif ($userdevices_grid->active->getSort() == "DESC") { ?><i class="fas fa-sort-down"></i><?php } ?></span></div>
		</div></div></th>
	<?php } ?>
<?php } ?>
<?php if ($userdevices_grid->enrolledtime->Visible) { // enrolledtime ?>
	<?php if ($userdevices_grid->SortUrl($userdevices_grid->enrolledtime) == "") { ?>
		<th data-name="enrolledtime" class="<?php echo $userdevices_grid->enrolledtime->headerCellClass() ?>"><div id="elh_userdevices_enrolledtime" class="userdevices_enrolledtime"><div class="ew-table-header-caption"><?php echo $userdevices_grid->enrolledtime->caption() ?></div></div></th>
	<?php } else { ?>
		<th data-name="enrolledtime" class="<?php echo $userdevices_grid->enrolledtime->headerCellClass() ?>"><div><div id="elh_userdevices_enrolledtime" class="userdevices_enrolledtime">
			<div class="ew-table-header-btn"><span class="ew-table-header-caption"><?php echo $userdevices_grid->enrolledtime->caption() ?></span><span class="ew-table-header-sort"><?php if ($userdevices_grid->enrolledtime->getSort() == "ASC") { ?><i class="fas fa-sort-up"></i><?php } elseif ($userdevices_grid->enrolledtime->getSort() == "DESC") { ?><i class="fas fa-sort-down"></i><?php } ?></span></div>
		</div></div></th>
	<?php } ?>
<?php } ?>
<?php if ($userdevices_grid->lastlogin->Visible) { // lastlogin ?>
	<?php if ($userdevices_grid->SortUrl($userdevices_grid->lastlogin) == "") { ?>
		<th data-name="lastlogin" class="<?php echo $userdevices_grid->lastlogin->headerCellClass() ?>"><div id="elh_userdevices_lastlogin" class="userdevices_lastlogin"><div class="ew-table-header-caption"><?php echo $userdevices_grid->lastlogin->caption() ?></div></div></th>
	<?php } else { ?>
		<th data-name="lastlogin" class="<?php echo $userdevices_grid->lastlogin->headerCellClass() ?>"><div><div id="elh_userdevices_lastlogin" class="userdevices_lastlogin">
			<div class="ew-table-header-btn"><span class="ew-table-header-caption"><?php echo $userdevices_grid->lastlogin->caption() ?></span><span class="ew-table-header-sort"><?php if ($userdevices_grid->lastlogin->getSort() == "ASC") { ?><i class="fas fa-sort-up"></i><?php } elseif ($userdevices_grid->lastlogin->getSort() == "DESC") { ?><i class="fas fa-sort-down"></i><?php } ?></span></div>
		</div></div></th>
	<?php } ?>
<?php } ?>
<?php

// Render list options (header, right)
$userdevices_grid->ListOptions->render("header", "right");
?>
	</tr>
</thead>
<tbody>
<?php
$userdevices_grid->StartRecord = 1;
$userdevices_grid->StopRecord = $userdevices_grid->TotalRecords; // Show all records

// Restore number of post back records
if ($CurrentForm && ($userdevices->isConfirm() || $userdevices_grid->EventCancelled)) {
	$CurrentForm->Index = -1;
	if ($CurrentForm->hasValue($userdevices_grid->FormKeyCountName) && ($userdevices_grid->isGridAdd() || $userdevices_grid->isGridEdit() || $userdevices->isConfirm())) {
		$userdevices_grid->KeyCount = $CurrentForm->getValue($userdevices_grid->FormKeyCountName);
		$userdevices_grid->StopRecord = $userdevices_grid->StartRecord + $userdevices_grid->KeyCount - 1;
	}
}
$userdevices_grid->RecordCount = $userdevices_grid->StartRecord - 1;
if ($userdevices_grid->Recordset && !$userdevices_grid->Recordset->EOF) {
	$userdevices_grid->Recordset->moveFirst();
	$selectLimit = $userdevices_grid->UseSelectLimit;
	if (!$selectLimit && $userdevices_grid->StartRecord > 1)
		$userdevices_grid->Recordset->move($userdevices_grid->StartRecord - 1);
} elseif (!$userdevices->AllowAddDeleteRow && $userdevices_grid->StopRecord == 0) {
	$userdevices_grid->StopRecord = $userdevices->GridAddRowCount;
}

// Initialize aggregate
$userdevices->RowType = ROWTYPE_AGGREGATEINIT;
$userdevices->resetAttributes();
$userdevices_grid->renderRow();
if ($userdevices_grid->isGridAdd())
	$userdevices_grid->RowIndex = 0;
if ($userdevices_grid->isGridEdit())
	$userdevices_grid->RowIndex = 0;
while ($userdevices_grid->RecordCount < $userdevices_grid->StopRecord) {
	$userdevices_grid->RecordCount++;
	if ($userdevices_grid->RecordCount >= $userdevices_grid->StartRecord) {
		$userdevices_grid->RowCount++;
		if ($userdevices_grid->isGridAdd() || $userdevices_grid->isGridEdit() || $userdevices->isConfirm()) {
			$userdevices_grid->RowIndex++;
			$CurrentForm->Index = $userdevices_grid->RowIndex;
			if ($CurrentForm->hasValue($userdevices_grid->FormActionName) && ($userdevices->isConfirm() || $userdevices_grid->EventCancelled))
				$userdevices_grid->RowAction = strval($CurrentForm->getValue($userdevices_grid->FormActionName));
			elseif ($userdevices_grid->isGridAdd())
				$userdevices_grid->RowAction = "insert";
			else
				$userdevices_grid->RowAction = "";
		}

		// Set up key count
		$userdevices_grid->KeyCount = $userdevices_grid->RowIndex;

		// Init row class and style
		$userdevices->resetAttributes();
		$userdevices->CssClass = "";
		if ($userdevices_grid->isGridAdd()) {
			if ($userdevices->CurrentMode == "copy") {
				$userdevices_grid->loadRowValues($userdevices_grid->Recordset); // Load row values
				$userdevices_grid->setRecordKey($userdevices_grid->RowOldKey, $userdevices_grid->Recordset); // Set old record key
			} else {
				$userdevices_grid->loadRowValues(); // Load default values
				$userdevices_grid->RowOldKey = ""; // Clear old key value
			}
		} else {
			$userdevices_grid->loadRowValues($userdevices_grid->Recordset); // Load row values
		}
		$userdevices->RowType = ROWTYPE_VIEW; // Render view
		if ($userdevices_grid->isGridAdd()) // Grid add
			$userdevices->RowType = ROWTYPE_ADD; // Render add
		if ($userdevices_grid->isGridAdd() && $userdevices->EventCancelled && !$CurrentForm->hasValue("k_blankrow")) // Insert failed
			$userdevices_grid->restoreCurrentRowFormValues($userdevices_grid->RowIndex); // Restore form values
		if ($userdevices_grid->isGridEdit()) { // Grid edit
			if ($userdevices->EventCancelled)
				$userdevices_grid->restoreCurrentRowFormValues($userdevices_grid->RowIndex); // Restore form values
			if ($userdevices_grid->RowAction == "insert")
				$userdevices->RowType = ROWTYPE_ADD; // Render add
			else
				$userdevices->RowType = ROWTYPE_EDIT; // Render edit
		}
		if ($userdevices_grid->isGridEdit() && ($userdevices->RowType == ROWTYPE_EDIT || $userdevices->RowType == ROWTYPE_ADD) && $userdevices->EventCancelled) // Update failed
			$userdevices_grid->restoreCurrentRowFormValues($userdevices_grid->RowIndex); // Restore form values
		if ($userdevices->RowType == ROWTYPE_EDIT) // Edit row
			$userdevices_grid->EditRowCount++;
		if ($userdevices->isConfirm()) // Confirm row
			$userdevices_grid->restoreCurrentRowFormValues($userdevices_grid->RowIndex); // Restore form values

		// Set up row id / data-rowindex
		$userdevices->RowAttrs->merge(["data-rowindex" => $userdevices_grid->RowCount, "id" => "r" . $userdevices_grid->RowCount . "_userdevices", "data-rowtype" => $userdevices->RowType]);

		// Render row
		$userdevices_grid->renderRow();

		// Render list options
		$userdevices_grid->renderListOptions();

		// Skip delete row / empty row for confirm page
		if ($userdevices_grid->RowAction != "delete" && $userdevices_grid->RowAction != "insertdelete" && !($userdevices_grid->RowAction == "insert" && $userdevices->isConfirm() && $userdevices_grid->emptyRow())) {
?>
	<tr <?php echo $userdevices->rowAttributes() ?>>
<?php

// Render list options (body, left)
$userdevices_grid->ListOptions->render("body", "left", $userdevices_grid->RowCount);
?>
	<?php if ($userdevices_grid->id->Visible) { // id ?>
		<td data-name="id" <?php echo $userdevices_grid->id->cellAttributes() ?>>
<?php if ($userdevices->RowType == ROWTYPE_ADD) { // Add record ?>
<span id="el<?php echo $userdevices_grid->RowCount ?>_userdevices_id" class="form-group"></span>
<input type="hidden" data-table="userdevices" data-field="x_id" name="o<?php echo $userdevices_grid->RowIndex ?>_id" id="o<?php echo $userdevices_grid->RowIndex ?>_id" value="<?php echo HtmlEncode($userdevices_grid->id->OldValue) ?>">
<?php } ?>
<?php if ($userdevices->RowType == ROWTYPE_EDIT) { // Edit record ?>
<span id="el<?php echo $userdevices_grid->RowCount ?>_userdevices_id" class="form-group">
<span<?php echo $userdevices_grid->id->viewAttributes() ?>><input type="text" readonly class="form-control-plaintext" value="<?php echo HtmlEncode(RemoveHtml($userdevices_grid->id->EditValue)) ?>"></span>
</span>
<input type="hidden" data-table="userdevices" data-field="x_id" name="x<?php echo $userdevices_grid->RowIndex ?>_id" id="x<?php echo $userdevices_grid->RowIndex ?>_id" value="<?php echo HtmlEncode($userdevices_grid->id->CurrentValue) ?>">
<?php } ?>
<?php if ($userdevices->RowType == ROWTYPE_VIEW) { // View record ?>
<span id="el<?php echo $userdevices_grid->RowCount ?>_userdevices_id">
<span<?php echo $userdevices_grid->id->viewAttributes() ?>><?php echo $userdevices_grid->id->getViewValue() ?></span>
</span>
<?php if (!$userdevices->isConfirm()) { ?>
<input type="hidden" data-table="userdevices" data-field="x_id" name="x<?php echo $userdevices_grid->RowIndex ?>_id" id="x<?php echo $userdevices_grid->RowIndex ?>_id" value="<?php echo HtmlEncode($userdevices_grid->id->FormValue) ?>">
<input type="hidden" data-table="userdevices" data-field="x_id" name="o<?php echo $userdevices_grid->RowIndex ?>_id" id="o<?php echo $userdevices_grid->RowIndex ?>_id" value="<?php echo HtmlEncode($userdevices_grid->id->OldValue) ?>">
<?php } else { ?>
<input type="hidden" data-table="userdevices" data-field="x_id" name="fuserdevicesgrid$x<?php echo $userdevices_grid->RowIndex ?>_id" id="fuserdevicesgrid$x<?php echo $userdevices_grid->RowIndex ?>_id" value="<?php echo HtmlEncode($userdevices_grid->id->FormValue) ?>">
<input type="hidden" data-table="userdevices" data-field="x_id" name="fuserdevicesgrid$o<?php echo $userdevices_grid->RowIndex ?>_id" id="fuserdevicesgrid$o<?php echo $userdevices_grid->RowIndex ?>_id" value="<?php echo HtmlEncode($userdevices_grid->id->OldValue) ?>">
<?php } ?>
<?php } ?>
</td>
	<?php } ?>
	<?php if ($userdevices_grid->deviceid->Visible) { // deviceid ?>
		<td data-name="deviceid" <?php echo $userdevices_grid->deviceid->cellAttributes() ?>>
<?php if ($userdevices->RowType == ROWTYPE_ADD) { // Add record ?>
<span id="el<?php echo $userdevices_grid->RowCount ?>_userdevices_deviceid" class="form-group">
<input type="text" data-table="userdevices" data-field="x_deviceid" name="x<?php echo $userdevices_grid->RowIndex ?>_deviceid" id="x<?php echo $userdevices_grid->RowIndex ?>_deviceid" size="30" maxlength="255" placeholder="<?php echo HtmlEncode($userdevices_grid->deviceid->getPlaceHolder()) ?>" value="<?php echo $userdevices_grid->deviceid->EditValue ?>"<?php echo $userdevices_grid->deviceid->editAttributes() ?>>
</span>
<input type="hidden" data-table="userdevices" data-field="x_deviceid" name="o<?php echo $userdevices_grid->RowIndex ?>_deviceid" id="o<?php echo $userdevices_grid->RowIndex ?>_deviceid" value="<?php echo HtmlEncode($userdevices_grid->deviceid->OldValue) ?>">
<?php } ?>
<?php if ($userdevices->RowType == ROWTYPE_EDIT) { // Edit record ?>
<span id="el<?php echo $userdevices_grid->RowCount ?>_userdevices_deviceid" class="form-group">
<input type="text" data-table="userdevices" data-field="x_deviceid" name="x<?php echo $userdevices_grid->RowIndex ?>_deviceid" id="x<?php echo $userdevices_grid->RowIndex ?>_deviceid" size="30" maxlength="255" placeholder="<?php echo HtmlEncode($userdevices_grid->deviceid->getPlaceHolder()) ?>" value="<?php echo $userdevices_grid->deviceid->EditValue ?>"<?php echo $userdevices_grid->deviceid->editAttributes() ?>>
</span>
<?php } ?>
<?php if ($userdevices->RowType == ROWTYPE_VIEW) { // View record ?>
<span id="el<?php echo $userdevices_grid->RowCount ?>_userdevices_deviceid">
<span<?php echo $userdevices_grid->deviceid->viewAttributes() ?>><?php echo $userdevices_grid->deviceid->getViewValue() ?></span>
</span>
<?php if (!$userdevices->isConfirm()) { ?>
<input type="hidden" data-table="userdevices" data-field="x_deviceid" name="x<?php echo $userdevices_grid->RowIndex ?>_deviceid" id="x<?php echo $userdevices_grid->RowIndex ?>_deviceid" value="<?php echo HtmlEncode($userdevices_grid->deviceid->FormValue) ?>">
<input type="hidden" data-table="userdevices" data-field="x_deviceid" name="o<?php echo $userdevices_grid->RowIndex ?>_deviceid" id="o<?php echo $userdevices_grid->RowIndex ?>_deviceid" value="<?php echo HtmlEncode($userdevices_grid->deviceid->OldValue) ?>">
<?php } else { ?>
<input type="hidden" data-table="userdevices" data-field="x_deviceid" name="fuserdevicesgrid$x<?php echo $userdevices_grid->RowIndex ?>_deviceid" id="fuserdevicesgrid$x<?php echo $userdevices_grid->RowIndex ?>_deviceid" value="<?php echo HtmlEncode($userdevices_grid->deviceid->FormValue) ?>">
<input type="hidden" data-table="userdevices" data-field="x_deviceid" name="fuserdevicesgrid$o<?php echo $userdevices_grid->RowIndex ?>_deviceid" id="fuserdevicesgrid$o<?php echo $userdevices_grid->RowIndex ?>_deviceid" value="<?php echo HtmlEncode($userdevices_grid->deviceid->OldValue) ?>">
<?php } ?>
<?php } ?>
</td>
	<?php } ?>
	<?php if ($userdevices_grid->_userid->Visible) { // userid ?>
		<td data-name="_userid" <?php echo $userdevices_grid->_userid->cellAttributes() ?>>
<?php if ($userdevices->RowType == ROWTYPE_ADD) { // Add record ?>
<?php if ($userdevices_grid->_userid->getSessionValue() != "") { ?>
<span id="el<?php echo $userdevices_grid->RowCount ?>_userdevices__userid" class="form-group">
<span<?php echo $userdevices_grid->_userid->viewAttributes() ?>><input type="text" readonly class="form-control-plaintext" value="<?php echo HtmlEncode(RemoveHtml($userdevices_grid->_userid->ViewValue)) ?>"></span>
</span>
<input type="hidden" id="x<?php echo $userdevices_grid->RowIndex ?>__userid" name="x<?php echo $userdevices_grid->RowIndex ?>__userid" value="<?php echo HtmlEncode($userdevices_grid->_userid->CurrentValue) ?>">
<?php } else { ?>
<span id="el<?php echo $userdevices_grid->RowCount ?>_userdevices__userid" class="form-group">
<input type="text" data-table="userdevices" data-field="x__userid" name="x<?php echo $userdevices_grid->RowIndex ?>__userid" id="x<?php echo $userdevices_grid->RowIndex ?>__userid" size="30" maxlength="12" placeholder="<?php echo HtmlEncode($userdevices_grid->_userid->getPlaceHolder()) ?>" value="<?php echo $userdevices_grid->_userid->EditValue ?>"<?php echo $userdevices_grid->_userid->editAttributes() ?>>
</span>
<?php } ?>
<input type="hidden" data-table="userdevices" data-field="x__userid" name="o<?php echo $userdevices_grid->RowIndex ?>__userid" id="o<?php echo $userdevices_grid->RowIndex ?>__userid" value="<?php echo HtmlEncode($userdevices_grid->_userid->OldValue) ?>">
<?php } ?>
<?php if ($userdevices->RowType == ROWTYPE_EDIT) { // Edit record ?>
<?php if ($userdevices_grid->_userid->getSessionValue() != "") { ?>
<span id="el<?php echo $userdevices_grid->RowCount ?>_userdevices__userid" class="form-group">
<span<?php echo $userdevices_grid->_userid->viewAttributes() ?>><input type="text" readonly class="form-control-plaintext" value="<?php echo HtmlEncode(RemoveHtml($userdevices_grid->_userid->ViewValue)) ?>"></span>
</span>
<input type="hidden" id="x<?php echo $userdevices_grid->RowIndex ?>__userid" name="x<?php echo $userdevices_grid->RowIndex ?>__userid" value="<?php echo HtmlEncode($userdevices_grid->_userid->CurrentValue) ?>">
<?php } else { ?>
<span id="el<?php echo $userdevices_grid->RowCount ?>_userdevices__userid" class="form-group">
<input type="text" data-table="userdevices" data-field="x__userid" name="x<?php echo $userdevices_grid->RowIndex ?>__userid" id="x<?php echo $userdevices_grid->RowIndex ?>__userid" size="30" maxlength="12" placeholder="<?php echo HtmlEncode($userdevices_grid->_userid->getPlaceHolder()) ?>" value="<?php echo $userdevices_grid->_userid->EditValue ?>"<?php echo $userdevices_grid->_userid->editAttributes() ?>>
</span>
<?php } ?>
<?php } ?>
<?php if ($userdevices->RowType == ROWTYPE_VIEW) { // View record ?>
<span id="el<?php echo $userdevices_grid->RowCount ?>_userdevices__userid">
<span<?php echo $userdevices_grid->_userid->viewAttributes() ?>><?php echo $userdevices_grid->_userid->getViewValue() ?></span>
</span>
<?php if (!$userdevices->isConfirm()) { ?>
<input type="hidden" data-table="userdevices" data-field="x__userid" name="x<?php echo $userdevices_grid->RowIndex ?>__userid" id="x<?php echo $userdevices_grid->RowIndex ?>__userid" value="<?php echo HtmlEncode($userdevices_grid->_userid->FormValue) ?>">
<input type="hidden" data-table="userdevices" data-field="x__userid" name="o<?php echo $userdevices_grid->RowIndex ?>__userid" id="o<?php echo $userdevices_grid->RowIndex ?>__userid" value="<?php echo HtmlEncode($userdevices_grid->_userid->OldValue) ?>">
<?php } else { ?>
<input type="hidden" data-table="userdevices" data-field="x__userid" name="fuserdevicesgrid$x<?php echo $userdevices_grid->RowIndex ?>__userid" id="fuserdevicesgrid$x<?php echo $userdevices_grid->RowIndex ?>__userid" value="<?php echo HtmlEncode($userdevices_grid->_userid->FormValue) ?>">
<input type="hidden" data-table="userdevices" data-field="x__userid" name="fuserdevicesgrid$o<?php echo $userdevices_grid->RowIndex ?>__userid" id="fuserdevicesgrid$o<?php echo $userdevices_grid->RowIndex ?>__userid" value="<?php echo HtmlEncode($userdevices_grid->_userid->OldValue) ?>">
<?php } ?>
<?php } ?>
</td>
	<?php } ?>
	<?php if ($userdevices_grid->devicetoken->Visible) { // devicetoken ?>
		<td data-name="devicetoken" <?php echo $userdevices_grid->devicetoken->cellAttributes() ?>>
<?php if ($userdevices->RowType == ROWTYPE_ADD) { // Add record ?>
<span id="el<?php echo $userdevices_grid->RowCount ?>_userdevices_devicetoken" class="form-group">
<input type="text" data-table="userdevices" data-field="x_devicetoken" name="x<?php echo $userdevices_grid->RowIndex ?>_devicetoken" id="x<?php echo $userdevices_grid->RowIndex ?>_devicetoken" size="30" maxlength="255" placeholder="<?php echo HtmlEncode($userdevices_grid->devicetoken->getPlaceHolder()) ?>" value="<?php echo $userdevices_grid->devicetoken->EditValue ?>"<?php echo $userdevices_grid->devicetoken->editAttributes() ?>>
</span>
<input type="hidden" data-table="userdevices" data-field="x_devicetoken" name="o<?php echo $userdevices_grid->RowIndex ?>_devicetoken" id="o<?php echo $userdevices_grid->RowIndex ?>_devicetoken" value="<?php echo HtmlEncode($userdevices_grid->devicetoken->OldValue) ?>">
<?php } ?>
<?php if ($userdevices->RowType == ROWTYPE_EDIT) { // Edit record ?>
<span id="el<?php echo $userdevices_grid->RowCount ?>_userdevices_devicetoken" class="form-group">
<input type="text" data-table="userdevices" data-field="x_devicetoken" name="x<?php echo $userdevices_grid->RowIndex ?>_devicetoken" id="x<?php echo $userdevices_grid->RowIndex ?>_devicetoken" size="30" maxlength="255" placeholder="<?php echo HtmlEncode($userdevices_grid->devicetoken->getPlaceHolder()) ?>" value="<?php echo $userdevices_grid->devicetoken->EditValue ?>"<?php echo $userdevices_grid->devicetoken->editAttributes() ?>>
</span>
<?php } ?>
<?php if ($userdevices->RowType == ROWTYPE_VIEW) { // View record ?>
<span id="el<?php echo $userdevices_grid->RowCount ?>_userdevices_devicetoken">
<span<?php echo $userdevices_grid->devicetoken->viewAttributes() ?>><?php echo $userdevices_grid->devicetoken->getViewValue() ?></span>
</span>
<?php if (!$userdevices->isConfirm()) { ?>
<input type="hidden" data-table="userdevices" data-field="x_devicetoken" name="x<?php echo $userdevices_grid->RowIndex ?>_devicetoken" id="x<?php echo $userdevices_grid->RowIndex ?>_devicetoken" value="<?php echo HtmlEncode($userdevices_grid->devicetoken->FormValue) ?>">
<input type="hidden" data-table="userdevices" data-field="x_devicetoken" name="o<?php echo $userdevices_grid->RowIndex ?>_devicetoken" id="o<?php echo $userdevices_grid->RowIndex ?>_devicetoken" value="<?php echo HtmlEncode($userdevices_grid->devicetoken->OldValue) ?>">
<?php } else { ?>
<input type="hidden" data-table="userdevices" data-field="x_devicetoken" name="fuserdevicesgrid$x<?php echo $userdevices_grid->RowIndex ?>_devicetoken" id="fuserdevicesgrid$x<?php echo $userdevices_grid->RowIndex ?>_devicetoken" value="<?php echo HtmlEncode($userdevices_grid->devicetoken->FormValue) ?>">
<input type="hidden" data-table="userdevices" data-field="x_devicetoken" name="fuserdevicesgrid$o<?php echo $userdevices_grid->RowIndex ?>_devicetoken" id="fuserdevicesgrid$o<?php echo $userdevices_grid->RowIndex ?>_devicetoken" value="<?php echo HtmlEncode($userdevices_grid->devicetoken->OldValue) ?>">
<?php } ?>
<?php } ?>
</td>
	<?php } ?>
	<?php if ($userdevices_grid->devicetype->Visible) { // devicetype ?>
		<td data-name="devicetype" <?php echo $userdevices_grid->devicetype->cellAttributes() ?>>
<?php if ($userdevices->RowType == ROWTYPE_ADD) { // Add record ?>
<span id="el<?php echo $userdevices_grid->RowCount ?>_userdevices_devicetype" class="form-group">
<input type="text" data-table="userdevices" data-field="x_devicetype" name="x<?php echo $userdevices_grid->RowIndex ?>_devicetype" id="x<?php echo $userdevices_grid->RowIndex ?>_devicetype" size="30" maxlength="50" placeholder="<?php echo HtmlEncode($userdevices_grid->devicetype->getPlaceHolder()) ?>" value="<?php echo $userdevices_grid->devicetype->EditValue ?>"<?php echo $userdevices_grid->devicetype->editAttributes() ?>>
</span>
<input type="hidden" data-table="userdevices" data-field="x_devicetype" name="o<?php echo $userdevices_grid->RowIndex ?>_devicetype" id="o<?php echo $userdevices_grid->RowIndex ?>_devicetype" value="<?php echo HtmlEncode($userdevices_grid->devicetype->OldValue) ?>">
<?php } ?>
<?php if ($userdevices->RowType == ROWTYPE_EDIT) { // Edit record ?>
<span id="el<?php echo $userdevices_grid->RowCount ?>_userdevices_devicetype" class="form-group">
<input type="text" data-table="userdevices" data-field="x_devicetype" name="x<?php echo $userdevices_grid->RowIndex ?>_devicetype" id="x<?php echo $userdevices_grid->RowIndex ?>_devicetype" size="30" maxlength="50" placeholder="<?php echo HtmlEncode($userdevices_grid->devicetype->getPlaceHolder()) ?>" value="<?php echo $userdevices_grid->devicetype->EditValue ?>"<?php echo $userdevices_grid->devicetype->editAttributes() ?>>
</span>
<?php } ?>
<?php if ($userdevices->RowType == ROWTYPE_VIEW) { // View record ?>
<span id="el<?php echo $userdevices_grid->RowCount ?>_userdevices_devicetype">
<span<?php echo $userdevices_grid->devicetype->viewAttributes() ?>><?php echo $userdevices_grid->devicetype->getViewValue() ?></span>
</span>
<?php if (!$userdevices->isConfirm()) { ?>
<input type="hidden" data-table="userdevices" data-field="x_devicetype" name="x<?php echo $userdevices_grid->RowIndex ?>_devicetype" id="x<?php echo $userdevices_grid->RowIndex ?>_devicetype" value="<?php echo HtmlEncode($userdevices_grid->devicetype->FormValue) ?>">
<input type="hidden" data-table="userdevices" data-field="x_devicetype" name="o<?php echo $userdevices_grid->RowIndex ?>_devicetype" id="o<?php echo $userdevices_grid->RowIndex ?>_devicetype" value="<?php echo HtmlEncode($userdevices_grid->devicetype->OldValue) ?>">
<?php } else { ?>
<input type="hidden" data-table="userdevices" data-field="x_devicetype" name="fuserdevicesgrid$x<?php echo $userdevices_grid->RowIndex ?>_devicetype" id="fuserdevicesgrid$x<?php echo $userdevices_grid->RowIndex ?>_devicetype" value="<?php echo HtmlEncode($userdevices_grid->devicetype->FormValue) ?>">
<input type="hidden" data-table="userdevices" data-field="x_devicetype" name="fuserdevicesgrid$o<?php echo $userdevices_grid->RowIndex ?>_devicetype" id="fuserdevicesgrid$o<?php echo $userdevices_grid->RowIndex ?>_devicetype" value="<?php echo HtmlEncode($userdevices_grid->devicetype->OldValue) ?>">
<?php } ?>
<?php } ?>
</td>
	<?php } ?>
	<?php if ($userdevices_grid->franchiseeid->Visible) { // franchiseeid ?>
		<td data-name="franchiseeid" <?php echo $userdevices_grid->franchiseeid->cellAttributes() ?>>
<?php if ($userdevices->RowType == ROWTYPE_ADD) { // Add record ?>
<span id="el<?php echo $userdevices_grid->RowCount ?>_userdevices_franchiseeid" class="form-group">
<input type="text" data-table="userdevices" data-field="x_franchiseeid" name="x<?php echo $userdevices_grid->RowIndex ?>_franchiseeid" id="x<?php echo $userdevices_grid->RowIndex ?>_franchiseeid" size="30" maxlength="3" placeholder="<?php echo HtmlEncode($userdevices_grid->franchiseeid->getPlaceHolder()) ?>" value="<?php echo $userdevices_grid->franchiseeid->EditValue ?>"<?php echo $userdevices_grid->franchiseeid->editAttributes() ?>>
</span>
<input type="hidden" data-table="userdevices" data-field="x_franchiseeid" name="o<?php echo $userdevices_grid->RowIndex ?>_franchiseeid" id="o<?php echo $userdevices_grid->RowIndex ?>_franchiseeid" value="<?php echo HtmlEncode($userdevices_grid->franchiseeid->OldValue) ?>">
<?php } ?>
<?php if ($userdevices->RowType == ROWTYPE_EDIT) { // Edit record ?>
<span id="el<?php echo $userdevices_grid->RowCount ?>_userdevices_franchiseeid" class="form-group">
<input type="text" data-table="userdevices" data-field="x_franchiseeid" name="x<?php echo $userdevices_grid->RowIndex ?>_franchiseeid" id="x<?php echo $userdevices_grid->RowIndex ?>_franchiseeid" size="30" maxlength="3" placeholder="<?php echo HtmlEncode($userdevices_grid->franchiseeid->getPlaceHolder()) ?>" value="<?php echo $userdevices_grid->franchiseeid->EditValue ?>"<?php echo $userdevices_grid->franchiseeid->editAttributes() ?>>
</span>
<?php } ?>
<?php if ($userdevices->RowType == ROWTYPE_VIEW) { // View record ?>
<span id="el<?php echo $userdevices_grid->RowCount ?>_userdevices_franchiseeid">
<span<?php echo $userdevices_grid->franchiseeid->viewAttributes() ?>><?php echo $userdevices_grid->franchiseeid->getViewValue() ?></span>
</span>
<?php if (!$userdevices->isConfirm()) { ?>
<input type="hidden" data-table="userdevices" data-field="x_franchiseeid" name="x<?php echo $userdevices_grid->RowIndex ?>_franchiseeid" id="x<?php echo $userdevices_grid->RowIndex ?>_franchiseeid" value="<?php echo HtmlEncode($userdevices_grid->franchiseeid->FormValue) ?>">
<input type="hidden" data-table="userdevices" data-field="x_franchiseeid" name="o<?php echo $userdevices_grid->RowIndex ?>_franchiseeid" id="o<?php echo $userdevices_grid->RowIndex ?>_franchiseeid" value="<?php echo HtmlEncode($userdevices_grid->franchiseeid->OldValue) ?>">
<?php } else { ?>
<input type="hidden" data-table="userdevices" data-field="x_franchiseeid" name="fuserdevicesgrid$x<?php echo $userdevices_grid->RowIndex ?>_franchiseeid" id="fuserdevicesgrid$x<?php echo $userdevices_grid->RowIndex ?>_franchiseeid" value="<?php echo HtmlEncode($userdevices_grid->franchiseeid->FormValue) ?>">
<input type="hidden" data-table="userdevices" data-field="x_franchiseeid" name="fuserdevicesgrid$o<?php echo $userdevices_grid->RowIndex ?>_franchiseeid" id="fuserdevicesgrid$o<?php echo $userdevices_grid->RowIndex ?>_franchiseeid" value="<?php echo HtmlEncode($userdevices_grid->franchiseeid->OldValue) ?>">
<?php } ?>
<?php } ?>
</td>
	<?php } ?>
	<?php if ($userdevices_grid->active->Visible) { // active ?>
		<td data-name="active" <?php echo $userdevices_grid->active->cellAttributes() ?>>
<?php if ($userdevices->RowType == ROWTYPE_ADD) { // Add record ?>
<span id="el<?php echo $userdevices_grid->RowCount ?>_userdevices_active" class="form-group">
<div id="tp_x<?php echo $userdevices_grid->RowIndex ?>_active" class="ew-template"><input type="radio" class="custom-control-input" data-table="userdevices" data-field="x_active" data-value-separator="<?php echo $userdevices_grid->active->displayValueSeparatorAttribute() ?>" name="x<?php echo $userdevices_grid->RowIndex ?>_active" id="x<?php echo $userdevices_grid->RowIndex ?>_active" value="{value}"<?php echo $userdevices_grid->active->editAttributes() ?>></div>
<div id="dsl_x<?php echo $userdevices_grid->RowIndex ?>_active" data-repeatcolumn="5" class="ew-item-list d-none"><div>
<?php echo $userdevices_grid->active->radioButtonListHtml(FALSE, "x{$userdevices_grid->RowIndex}_active") ?>
</div></div>
<?php echo $userdevices_grid->active->Lookup->getParamTag($userdevices_grid, "p_x" . $userdevices_grid->RowIndex . "_active") ?>
</span>
<input type="hidden" data-table="userdevices" data-field="x_active" name="o<?php echo $userdevices_grid->RowIndex ?>_active" id="o<?php echo $userdevices_grid->RowIndex ?>_active" value="<?php echo HtmlEncode($userdevices_grid->active->OldValue) ?>">
<?php } ?>
<?php if ($userdevices->RowType == ROWTYPE_EDIT) { // Edit record ?>
<span id="el<?php echo $userdevices_grid->RowCount ?>_userdevices_active" class="form-group">
<div id="tp_x<?php echo $userdevices_grid->RowIndex ?>_active" class="ew-template"><input type="radio" class="custom-control-input" data-table="userdevices" data-field="x_active" data-value-separator="<?php echo $userdevices_grid->active->displayValueSeparatorAttribute() ?>" name="x<?php echo $userdevices_grid->RowIndex ?>_active" id="x<?php echo $userdevices_grid->RowIndex ?>_active" value="{value}"<?php echo $userdevices_grid->active->editAttributes() ?>></div>
<div id="dsl_x<?php echo $userdevices_grid->RowIndex ?>_active" data-repeatcolumn="5" class="ew-item-list d-none"><div>
<?php echo $userdevices_grid->active->radioButtonListHtml(FALSE, "x{$userdevices_grid->RowIndex}_active") ?>
</div></div>
<?php echo $userdevices_grid->active->Lookup->getParamTag($userdevices_grid, "p_x" . $userdevices_grid->RowIndex . "_active") ?>
</span>
<?php } ?>
<?php if ($userdevices->RowType == ROWTYPE_VIEW) { // View record ?>
<span id="el<?php echo $userdevices_grid->RowCount ?>_userdevices_active">
<span<?php echo $userdevices_grid->active->viewAttributes() ?>><?php echo $userdevices_grid->active->getViewValue() ?></span>
</span>
<?php if (!$userdevices->isConfirm()) { ?>
<input type="hidden" data-table="userdevices" data-field="x_active" name="x<?php echo $userdevices_grid->RowIndex ?>_active" id="x<?php echo $userdevices_grid->RowIndex ?>_active" value="<?php echo HtmlEncode($userdevices_grid->active->FormValue) ?>">
<input type="hidden" data-table="userdevices" data-field="x_active" name="o<?php echo $userdevices_grid->RowIndex ?>_active" id="o<?php echo $userdevices_grid->RowIndex ?>_active" value="<?php echo HtmlEncode($userdevices_grid->active->OldValue) ?>">
<?php } else { ?>
<input type="hidden" data-table="userdevices" data-field="x_active" name="fuserdevicesgrid$x<?php echo $userdevices_grid->RowIndex ?>_active" id="fuserdevicesgrid$x<?php echo $userdevices_grid->RowIndex ?>_active" value="<?php echo HtmlEncode($userdevices_grid->active->FormValue) ?>">
<input type="hidden" data-table="userdevices" data-field="x_active" name="fuserdevicesgrid$o<?php echo $userdevices_grid->RowIndex ?>_active" id="fuserdevicesgrid$o<?php echo $userdevices_grid->RowIndex ?>_active" value="<?php echo HtmlEncode($userdevices_grid->active->OldValue) ?>">
<?php } ?>
<?php } ?>
</td>
	<?php } ?>
	<?php if ($userdevices_grid->enrolledtime->Visible) { // enrolledtime ?>
		<td data-name="enrolledtime" <?php echo $userdevices_grid->enrolledtime->cellAttributes() ?>>
<?php if ($userdevices->RowType == ROWTYPE_ADD) { // Add record ?>
<span id="el<?php echo $userdevices_grid->RowCount ?>_userdevices_enrolledtime" class="form-group">
<input type="text" data-table="userdevices" data-field="x_enrolledtime" name="x<?php echo $userdevices_grid->RowIndex ?>_enrolledtime" id="x<?php echo $userdevices_grid->RowIndex ?>_enrolledtime" maxlength="19" placeholder="<?php echo HtmlEncode($userdevices_grid->enrolledtime->getPlaceHolder()) ?>" value="<?php echo $userdevices_grid->enrolledtime->EditValue ?>"<?php echo $userdevices_grid->enrolledtime->editAttributes() ?>>
<?php if (!$userdevices_grid->enrolledtime->ReadOnly && !$userdevices_grid->enrolledtime->Disabled && !isset($userdevices_grid->enrolledtime->EditAttrs["readonly"]) && !isset($userdevices_grid->enrolledtime->EditAttrs["disabled"])) { ?>
<script>
loadjs.ready(["fuserdevicesgrid", "datetimepicker"], function() {
	ew.createDateTimePicker("fuserdevicesgrid", "x<?php echo $userdevices_grid->RowIndex ?>_enrolledtime", {"ignoreReadonly":true,"useCurrent":false,"format":0});
});
</script>
<?php } ?>
</span>
<input type="hidden" data-table="userdevices" data-field="x_enrolledtime" name="o<?php echo $userdevices_grid->RowIndex ?>_enrolledtime" id="o<?php echo $userdevices_grid->RowIndex ?>_enrolledtime" value="<?php echo HtmlEncode($userdevices_grid->enrolledtime->OldValue) ?>">
<?php } ?>
<?php if ($userdevices->RowType == ROWTYPE_EDIT) { // Edit record ?>
<span id="el<?php echo $userdevices_grid->RowCount ?>_userdevices_enrolledtime" class="form-group">
<input type="text" data-table="userdevices" data-field="x_enrolledtime" name="x<?php echo $userdevices_grid->RowIndex ?>_enrolledtime" id="x<?php echo $userdevices_grid->RowIndex ?>_enrolledtime" maxlength="19" placeholder="<?php echo HtmlEncode($userdevices_grid->enrolledtime->getPlaceHolder()) ?>" value="<?php echo $userdevices_grid->enrolledtime->EditValue ?>"<?php echo $userdevices_grid->enrolledtime->editAttributes() ?>>
<?php if (!$userdevices_grid->enrolledtime->ReadOnly && !$userdevices_grid->enrolledtime->Disabled && !isset($userdevices_grid->enrolledtime->EditAttrs["readonly"]) && !isset($userdevices_grid->enrolledtime->EditAttrs["disabled"])) { ?>
<script>
loadjs.ready(["fuserdevicesgrid", "datetimepicker"], function() {
	ew.createDateTimePicker("fuserdevicesgrid", "x<?php echo $userdevices_grid->RowIndex ?>_enrolledtime", {"ignoreReadonly":true,"useCurrent":false,"format":0});
});
</script>
<?php } ?>
</span>
<?php } ?>
<?php if ($userdevices->RowType == ROWTYPE_VIEW) { // View record ?>
<span id="el<?php echo $userdevices_grid->RowCount ?>_userdevices_enrolledtime">
<span<?php echo $userdevices_grid->enrolledtime->viewAttributes() ?>><?php echo $userdevices_grid->enrolledtime->getViewValue() ?></span>
</span>
<?php if (!$userdevices->isConfirm()) { ?>
<input type="hidden" data-table="userdevices" data-field="x_enrolledtime" name="x<?php echo $userdevices_grid->RowIndex ?>_enrolledtime" id="x<?php echo $userdevices_grid->RowIndex ?>_enrolledtime" value="<?php echo HtmlEncode($userdevices_grid->enrolledtime->FormValue) ?>">
<input type="hidden" data-table="userdevices" data-field="x_enrolledtime" name="o<?php echo $userdevices_grid->RowIndex ?>_enrolledtime" id="o<?php echo $userdevices_grid->RowIndex ?>_enrolledtime" value="<?php echo HtmlEncode($userdevices_grid->enrolledtime->OldValue) ?>">
<?php } else { ?>
<input type="hidden" data-table="userdevices" data-field="x_enrolledtime" name="fuserdevicesgrid$x<?php echo $userdevices_grid->RowIndex ?>_enrolledtime" id="fuserdevicesgrid$x<?php echo $userdevices_grid->RowIndex ?>_enrolledtime" value="<?php echo HtmlEncode($userdevices_grid->enrolledtime->FormValue) ?>">
<input type="hidden" data-table="userdevices" data-field="x_enrolledtime" name="fuserdevicesgrid$o<?php echo $userdevices_grid->RowIndex ?>_enrolledtime" id="fuserdevicesgrid$o<?php echo $userdevices_grid->RowIndex ?>_enrolledtime" value="<?php echo HtmlEncode($userdevices_grid->enrolledtime->OldValue) ?>">
<?php } ?>
<?php } ?>
</td>
	<?php } ?>
	<?php if ($userdevices_grid->lastlogin->Visible) { // lastlogin ?>
		<td data-name="lastlogin" <?php echo $userdevices_grid->lastlogin->cellAttributes() ?>>
<?php if ($userdevices->RowType == ROWTYPE_ADD) { // Add record ?>
<span id="el<?php echo $userdevices_grid->RowCount ?>_userdevices_lastlogin" class="form-group">
<input type="text" data-table="userdevices" data-field="x_lastlogin" name="x<?php echo $userdevices_grid->RowIndex ?>_lastlogin" id="x<?php echo $userdevices_grid->RowIndex ?>_lastlogin" maxlength="19" placeholder="<?php echo HtmlEncode($userdevices_grid->lastlogin->getPlaceHolder()) ?>" value="<?php echo $userdevices_grid->lastlogin->EditValue ?>"<?php echo $userdevices_grid->lastlogin->editAttributes() ?>>
<?php if (!$userdevices_grid->lastlogin->ReadOnly && !$userdevices_grid->lastlogin->Disabled && !isset($userdevices_grid->lastlogin->EditAttrs["readonly"]) && !isset($userdevices_grid->lastlogin->EditAttrs["disabled"])) { ?>
<script>
loadjs.ready(["fuserdevicesgrid", "datetimepicker"], function() {
	ew.createDateTimePicker("fuserdevicesgrid", "x<?php echo $userdevices_grid->RowIndex ?>_lastlogin", {"ignoreReadonly":true,"useCurrent":false,"format":0});
});
</script>
<?php } ?>
</span>
<input type="hidden" data-table="userdevices" data-field="x_lastlogin" name="o<?php echo $userdevices_grid->RowIndex ?>_lastlogin" id="o<?php echo $userdevices_grid->RowIndex ?>_lastlogin" value="<?php echo HtmlEncode($userdevices_grid->lastlogin->OldValue) ?>">
<?php } ?>
<?php if ($userdevices->RowType == ROWTYPE_EDIT) { // Edit record ?>
<span id="el<?php echo $userdevices_grid->RowCount ?>_userdevices_lastlogin" class="form-group">
<input type="text" data-table="userdevices" data-field="x_lastlogin" name="x<?php echo $userdevices_grid->RowIndex ?>_lastlogin" id="x<?php echo $userdevices_grid->RowIndex ?>_lastlogin" maxlength="19" placeholder="<?php echo HtmlEncode($userdevices_grid->lastlogin->getPlaceHolder()) ?>" value="<?php echo $userdevices_grid->lastlogin->EditValue ?>"<?php echo $userdevices_grid->lastlogin->editAttributes() ?>>
<?php if (!$userdevices_grid->lastlogin->ReadOnly && !$userdevices_grid->lastlogin->Disabled && !isset($userdevices_grid->lastlogin->EditAttrs["readonly"]) && !isset($userdevices_grid->lastlogin->EditAttrs["disabled"])) { ?>
<script>
loadjs.ready(["fuserdevicesgrid", "datetimepicker"], function() {
	ew.createDateTimePicker("fuserdevicesgrid", "x<?php echo $userdevices_grid->RowIndex ?>_lastlogin", {"ignoreReadonly":true,"useCurrent":false,"format":0});
});
</script>
<?php } ?>
</span>
<?php } ?>
<?php if ($userdevices->RowType == ROWTYPE_VIEW) { // View record ?>
<span id="el<?php echo $userdevices_grid->RowCount ?>_userdevices_lastlogin">
<span<?php echo $userdevices_grid->lastlogin->viewAttributes() ?>><?php echo $userdevices_grid->lastlogin->getViewValue() ?></span>
</span>
<?php if (!$userdevices->isConfirm()) { ?>
<input type="hidden" data-table="userdevices" data-field="x_lastlogin" name="x<?php echo $userdevices_grid->RowIndex ?>_lastlogin" id="x<?php echo $userdevices_grid->RowIndex ?>_lastlogin" value="<?php echo HtmlEncode($userdevices_grid->lastlogin->FormValue) ?>">
<input type="hidden" data-table="userdevices" data-field="x_lastlogin" name="o<?php echo $userdevices_grid->RowIndex ?>_lastlogin" id="o<?php echo $userdevices_grid->RowIndex ?>_lastlogin" value="<?php echo HtmlEncode($userdevices_grid->lastlogin->OldValue) ?>">
<?php } else { ?>
<input type="hidden" data-table="userdevices" data-field="x_lastlogin" name="fuserdevicesgrid$x<?php echo $userdevices_grid->RowIndex ?>_lastlogin" id="fuserdevicesgrid$x<?php echo $userdevices_grid->RowIndex ?>_lastlogin" value="<?php echo HtmlEncode($userdevices_grid->lastlogin->FormValue) ?>">
<input type="hidden" data-table="userdevices" data-field="x_lastlogin" name="fuserdevicesgrid$o<?php echo $userdevices_grid->RowIndex ?>_lastlogin" id="fuserdevicesgrid$o<?php echo $userdevices_grid->RowIndex ?>_lastlogin" value="<?php echo HtmlEncode($userdevices_grid->lastlogin->OldValue) ?>">
<?php } ?>
<?php } ?>
</td>
	<?php } ?>
<?php

// Render list options (body, right)
$userdevices_grid->ListOptions->render("body", "right", $userdevices_grid->RowCount);
?>
	</tr>
<?php if ($userdevices->RowType == ROWTYPE_ADD || $userdevices->RowType == ROWTYPE_EDIT) { ?>
<script>
loadjs.ready(["fuserdevicesgrid", "load"], function() {
	fuserdevicesgrid.updateLists(<?php echo $userdevices_grid->RowIndex ?>);
});
</script>
<?php } ?>
<?php
	}
	} // End delete row checking
	if (!$userdevices_grid->isGridAdd() || $userdevices->CurrentMode == "copy")
		if (!$userdevices_grid->Recordset->EOF)
			$userdevices_grid->Recordset->moveNext();
}
?>
<?php
	if ($userdevices->CurrentMode == "add" || $userdevices->CurrentMode == "copy" || $userdevices->CurrentMode == "edit") {
		$userdevices_grid->RowIndex = '$rowindex$';
		$userdevices_grid->loadRowValues();

		// Set row properties
		$userdevices->resetAttributes();
		$userdevices->RowAttrs->merge(["data-rowindex" => $userdevices_grid->RowIndex, "id" => "r0_userdevices", "data-rowtype" => ROWTYPE_ADD]);
		$userdevices->RowAttrs->appendClass("ew-template");
		$userdevices->RowType = ROWTYPE_ADD;

		// Render row
		$userdevices_grid->renderRow();

		// Render list options
		$userdevices_grid->renderListOptions();
		$userdevices_grid->StartRowCount = 0;
?>
	<tr <?php echo $userdevices->rowAttributes() ?>>
<?php

// Render list options (body, left)
$userdevices_grid->ListOptions->render("body", "left", $userdevices_grid->RowIndex);
?>
	<?php if ($userdevices_grid->id->Visible) { // id ?>
		<td data-name="id">
<?php if (!$userdevices->isConfirm()) { ?>
<span id="el$rowindex$_userdevices_id" class="form-group userdevices_id"></span>
<?php } else { ?>
<span id="el$rowindex$_userdevices_id" class="form-group userdevices_id">
<span<?php echo $userdevices_grid->id->viewAttributes() ?>><input type="text" readonly class="form-control-plaintext" value="<?php echo HtmlEncode(RemoveHtml($userdevices_grid->id->ViewValue)) ?>"></span>
</span>
<input type="hidden" data-table="userdevices" data-field="x_id" name="x<?php echo $userdevices_grid->RowIndex ?>_id" id="x<?php echo $userdevices_grid->RowIndex ?>_id" value="<?php echo HtmlEncode($userdevices_grid->id->FormValue) ?>">
<?php } ?>
<input type="hidden" data-table="userdevices" data-field="x_id" name="o<?php echo $userdevices_grid->RowIndex ?>_id" id="o<?php echo $userdevices_grid->RowIndex ?>_id" value="<?php echo HtmlEncode($userdevices_grid->id->OldValue) ?>">
</td>
	<?php } ?>
	<?php if ($userdevices_grid->deviceid->Visible) { // deviceid ?>
		<td data-name="deviceid">
<?php if (!$userdevices->isConfirm()) { ?>
<span id="el$rowindex$_userdevices_deviceid" class="form-group userdevices_deviceid">
<input type="text" data-table="userdevices" data-field="x_deviceid" name="x<?php echo $userdevices_grid->RowIndex ?>_deviceid" id="x<?php echo $userdevices_grid->RowIndex ?>_deviceid" size="30" maxlength="255" placeholder="<?php echo HtmlEncode($userdevices_grid->deviceid->getPlaceHolder()) ?>" value="<?php echo $userdevices_grid->deviceid->EditValue ?>"<?php echo $userdevices_grid->deviceid->editAttributes() ?>>
</span>
<?php } else { ?>
<span id="el$rowindex$_userdevices_deviceid" class="form-group userdevices_deviceid">
<span<?php echo $userdevices_grid->deviceid->viewAttributes() ?>><input type="text" readonly class="form-control-plaintext" value="<?php echo HtmlEncode(RemoveHtml($userdevices_grid->deviceid->ViewValue)) ?>"></span>
</span>
<input type="hidden" data-table="userdevices" data-field="x_deviceid" name="x<?php echo $userdevices_grid->RowIndex ?>_deviceid" id="x<?php echo $userdevices_grid->RowIndex ?>_deviceid" value="<?php echo HtmlEncode($userdevices_grid->deviceid->FormValue) ?>">
<?php } ?>
<input type="hidden" data-table="userdevices" data-field="x_deviceid" name="o<?php echo $userdevices_grid->RowIndex ?>_deviceid" id="o<?php echo $userdevices_grid->RowIndex ?>_deviceid" value="<?php echo HtmlEncode($userdevices_grid->deviceid->OldValue) ?>">
</td>
	<?php } ?>
	<?php if ($userdevices_grid->_userid->Visible) { // userid ?>
		<td data-name="_userid">
<?php if (!$userdevices->isConfirm()) { ?>
<?php if ($userdevices_grid->_userid->getSessionValue() != "") { ?>
<span id="el$rowindex$_userdevices__userid" class="form-group userdevices__userid">
<span<?php echo $userdevices_grid->_userid->viewAttributes() ?>><input type="text" readonly class="form-control-plaintext" value="<?php echo HtmlEncode(RemoveHtml($userdevices_grid->_userid->ViewValue)) ?>"></span>
</span>
<input type="hidden" id="x<?php echo $userdevices_grid->RowIndex ?>__userid" name="x<?php echo $userdevices_grid->RowIndex ?>__userid" value="<?php echo HtmlEncode($userdevices_grid->_userid->CurrentValue) ?>">
<?php } else { ?>
<span id="el$rowindex$_userdevices__userid" class="form-group userdevices__userid">
<input type="text" data-table="userdevices" data-field="x__userid" name="x<?php echo $userdevices_grid->RowIndex ?>__userid" id="x<?php echo $userdevices_grid->RowIndex ?>__userid" size="30" maxlength="12" placeholder="<?php echo HtmlEncode($userdevices_grid->_userid->getPlaceHolder()) ?>" value="<?php echo $userdevices_grid->_userid->EditValue ?>"<?php echo $userdevices_grid->_userid->editAttributes() ?>>
</span>
<?php } ?>
<?php } else { ?>
<span id="el$rowindex$_userdevices__userid" class="form-group userdevices__userid">
<span<?php echo $userdevices_grid->_userid->viewAttributes() ?>><input type="text" readonly class="form-control-plaintext" value="<?php echo HtmlEncode(RemoveHtml($userdevices_grid->_userid->ViewValue)) ?>"></span>
</span>
<input type="hidden" data-table="userdevices" data-field="x__userid" name="x<?php echo $userdevices_grid->RowIndex ?>__userid" id="x<?php echo $userdevices_grid->RowIndex ?>__userid" value="<?php echo HtmlEncode($userdevices_grid->_userid->FormValue) ?>">
<?php } ?>
<input type="hidden" data-table="userdevices" data-field="x__userid" name="o<?php echo $userdevices_grid->RowIndex ?>__userid" id="o<?php echo $userdevices_grid->RowIndex ?>__userid" value="<?php echo HtmlEncode($userdevices_grid->_userid->OldValue) ?>">
</td>
	<?php } ?>
	<?php if ($userdevices_grid->devicetoken->Visible) { // devicetoken ?>
		<td data-name="devicetoken">
<?php if (!$userdevices->isConfirm()) { ?>
<span id="el$rowindex$_userdevices_devicetoken" class="form-group userdevices_devicetoken">
<input type="text" data-table="userdevices" data-field="x_devicetoken" name="x<?php echo $userdevices_grid->RowIndex ?>_devicetoken" id="x<?php echo $userdevices_grid->RowIndex ?>_devicetoken" size="30" maxlength="255" placeholder="<?php echo HtmlEncode($userdevices_grid->devicetoken->getPlaceHolder()) ?>" value="<?php echo $userdevices_grid->devicetoken->EditValue ?>"<?php echo $userdevices_grid->devicetoken->editAttributes() ?>>
</span>
<?php } else { ?>
<span id="el$rowindex$_userdevices_devicetoken" class="form-group userdevices_devicetoken">
<span<?php echo $userdevices_grid->devicetoken->viewAttributes() ?>><input type="text" readonly class="form-control-plaintext" value="<?php echo HtmlEncode(RemoveHtml($userdevices_grid->devicetoken->ViewValue)) ?>"></span>
</span>
<input type="hidden" data-table="userdevices" data-field="x_devicetoken" name="x<?php echo $userdevices_grid->RowIndex ?>_devicetoken" id="x<?php echo $userdevices_grid->RowIndex ?>_devicetoken" value="<?php echo HtmlEncode($userdevices_grid->devicetoken->FormValue) ?>">
<?php } ?>
<input type="hidden" data-table="userdevices" data-field="x_devicetoken" name="o<?php echo $userdevices_grid->RowIndex ?>_devicetoken" id="o<?php echo $userdevices_grid->RowIndex ?>_devicetoken" value="<?php echo HtmlEncode($userdevices_grid->devicetoken->OldValue) ?>">
</td>
	<?php } ?>
	<?php if ($userdevices_grid->devicetype->Visible) { // devicetype ?>
		<td data-name="devicetype">
<?php if (!$userdevices->isConfirm()) { ?>
<span id="el$rowindex$_userdevices_devicetype" class="form-group userdevices_devicetype">
<input type="text" data-table="userdevices" data-field="x_devicetype" name="x<?php echo $userdevices_grid->RowIndex ?>_devicetype" id="x<?php echo $userdevices_grid->RowIndex ?>_devicetype" size="30" maxlength="50" placeholder="<?php echo HtmlEncode($userdevices_grid->devicetype->getPlaceHolder()) ?>" value="<?php echo $userdevices_grid->devicetype->EditValue ?>"<?php echo $userdevices_grid->devicetype->editAttributes() ?>>
</span>
<?php } else { ?>
<span id="el$rowindex$_userdevices_devicetype" class="form-group userdevices_devicetype">
<span<?php echo $userdevices_grid->devicetype->viewAttributes() ?>><input type="text" readonly class="form-control-plaintext" value="<?php echo HtmlEncode(RemoveHtml($userdevices_grid->devicetype->ViewValue)) ?>"></span>
</span>
<input type="hidden" data-table="userdevices" data-field="x_devicetype" name="x<?php echo $userdevices_grid->RowIndex ?>_devicetype" id="x<?php echo $userdevices_grid->RowIndex ?>_devicetype" value="<?php echo HtmlEncode($userdevices_grid->devicetype->FormValue) ?>">
<?php } ?>
<input type="hidden" data-table="userdevices" data-field="x_devicetype" name="o<?php echo $userdevices_grid->RowIndex ?>_devicetype" id="o<?php echo $userdevices_grid->RowIndex ?>_devicetype" value="<?php echo HtmlEncode($userdevices_grid->devicetype->OldValue) ?>">
</td>
	<?php } ?>
	<?php if ($userdevices_grid->franchiseeid->Visible) { // franchiseeid ?>
		<td data-name="franchiseeid">
<?php if (!$userdevices->isConfirm()) { ?>
<span id="el$rowindex$_userdevices_franchiseeid" class="form-group userdevices_franchiseeid">
<input type="text" data-table="userdevices" data-field="x_franchiseeid" name="x<?php echo $userdevices_grid->RowIndex ?>_franchiseeid" id="x<?php echo $userdevices_grid->RowIndex ?>_franchiseeid" size="30" maxlength="3" placeholder="<?php echo HtmlEncode($userdevices_grid->franchiseeid->getPlaceHolder()) ?>" value="<?php echo $userdevices_grid->franchiseeid->EditValue ?>"<?php echo $userdevices_grid->franchiseeid->editAttributes() ?>>
</span>
<?php } else { ?>
<span id="el$rowindex$_userdevices_franchiseeid" class="form-group userdevices_franchiseeid">
<span<?php echo $userdevices_grid->franchiseeid->viewAttributes() ?>><input type="text" readonly class="form-control-plaintext" value="<?php echo HtmlEncode(RemoveHtml($userdevices_grid->franchiseeid->ViewValue)) ?>"></span>
</span>
<input type="hidden" data-table="userdevices" data-field="x_franchiseeid" name="x<?php echo $userdevices_grid->RowIndex ?>_franchiseeid" id="x<?php echo $userdevices_grid->RowIndex ?>_franchiseeid" value="<?php echo HtmlEncode($userdevices_grid->franchiseeid->FormValue) ?>">
<?php } ?>
<input type="hidden" data-table="userdevices" data-field="x_franchiseeid" name="o<?php echo $userdevices_grid->RowIndex ?>_franchiseeid" id="o<?php echo $userdevices_grid->RowIndex ?>_franchiseeid" value="<?php echo HtmlEncode($userdevices_grid->franchiseeid->OldValue) ?>">
</td>
	<?php } ?>
	<?php if ($userdevices_grid->active->Visible) { // active ?>
		<td data-name="active">
<?php if (!$userdevices->isConfirm()) { ?>
<span id="el$rowindex$_userdevices_active" class="form-group userdevices_active">
<div id="tp_x<?php echo $userdevices_grid->RowIndex ?>_active" class="ew-template"><input type="radio" class="custom-control-input" data-table="userdevices" data-field="x_active" data-value-separator="<?php echo $userdevices_grid->active->displayValueSeparatorAttribute() ?>" name="x<?php echo $userdevices_grid->RowIndex ?>_active" id="x<?php echo $userdevices_grid->RowIndex ?>_active" value="{value}"<?php echo $userdevices_grid->active->editAttributes() ?>></div>
<div id="dsl_x<?php echo $userdevices_grid->RowIndex ?>_active" data-repeatcolumn="5" class="ew-item-list d-none"><div>
<?php echo $userdevices_grid->active->radioButtonListHtml(FALSE, "x{$userdevices_grid->RowIndex}_active") ?>
</div></div>
<?php echo $userdevices_grid->active->Lookup->getParamTag($userdevices_grid, "p_x" . $userdevices_grid->RowIndex . "_active") ?>
</span>
<?php } else { ?>
<span id="el$rowindex$_userdevices_active" class="form-group userdevices_active">
<span<?php echo $userdevices_grid->active->viewAttributes() ?>><input type="text" readonly class="form-control-plaintext" value="<?php echo HtmlEncode(RemoveHtml($userdevices_grid->active->ViewValue)) ?>"></span>
</span>
<input type="hidden" data-table="userdevices" data-field="x_active" name="x<?php echo $userdevices_grid->RowIndex ?>_active" id="x<?php echo $userdevices_grid->RowIndex ?>_active" value="<?php echo HtmlEncode($userdevices_grid->active->FormValue) ?>">
<?php } ?>
<input type="hidden" data-table="userdevices" data-field="x_active" name="o<?php echo $userdevices_grid->RowIndex ?>_active" id="o<?php echo $userdevices_grid->RowIndex ?>_active" value="<?php echo HtmlEncode($userdevices_grid->active->OldValue) ?>">
</td>
	<?php } ?>
	<?php if ($userdevices_grid->enrolledtime->Visible) { // enrolledtime ?>
		<td data-name="enrolledtime">
<?php if (!$userdevices->isConfirm()) { ?>
<span id="el$rowindex$_userdevices_enrolledtime" class="form-group userdevices_enrolledtime">
<input type="text" data-table="userdevices" data-field="x_enrolledtime" name="x<?php echo $userdevices_grid->RowIndex ?>_enrolledtime" id="x<?php echo $userdevices_grid->RowIndex ?>_enrolledtime" maxlength="19" placeholder="<?php echo HtmlEncode($userdevices_grid->enrolledtime->getPlaceHolder()) ?>" value="<?php echo $userdevices_grid->enrolledtime->EditValue ?>"<?php echo $userdevices_grid->enrolledtime->editAttributes() ?>>
<?php if (!$userdevices_grid->enrolledtime->ReadOnly && !$userdevices_grid->enrolledtime->Disabled && !isset($userdevices_grid->enrolledtime->EditAttrs["readonly"]) && !isset($userdevices_grid->enrolledtime->EditAttrs["disabled"])) { ?>
<script>
loadjs.ready(["fuserdevicesgrid", "datetimepicker"], function() {
	ew.createDateTimePicker("fuserdevicesgrid", "x<?php echo $userdevices_grid->RowIndex ?>_enrolledtime", {"ignoreReadonly":true,"useCurrent":false,"format":0});
});
</script>
<?php } ?>
</span>
<?php } else { ?>
<span id="el$rowindex$_userdevices_enrolledtime" class="form-group userdevices_enrolledtime">
<span<?php echo $userdevices_grid->enrolledtime->viewAttributes() ?>><input type="text" readonly class="form-control-plaintext" value="<?php echo HtmlEncode(RemoveHtml($userdevices_grid->enrolledtime->ViewValue)) ?>"></span>
</span>
<input type="hidden" data-table="userdevices" data-field="x_enrolledtime" name="x<?php echo $userdevices_grid->RowIndex ?>_enrolledtime" id="x<?php echo $userdevices_grid->RowIndex ?>_enrolledtime" value="<?php echo HtmlEncode($userdevices_grid->enrolledtime->FormValue) ?>">
<?php } ?>
<input type="hidden" data-table="userdevices" data-field="x_enrolledtime" name="o<?php echo $userdevices_grid->RowIndex ?>_enrolledtime" id="o<?php echo $userdevices_grid->RowIndex ?>_enrolledtime" value="<?php echo HtmlEncode($userdevices_grid->enrolledtime->OldValue) ?>">
</td>
	<?php } ?>
	<?php if ($userdevices_grid->lastlogin->Visible) { // lastlogin ?>
		<td data-name="lastlogin">
<?php if (!$userdevices->isConfirm()) { ?>
<span id="el$rowindex$_userdevices_lastlogin" class="form-group userdevices_lastlogin">
<input type="text" data-table="userdevices" data-field="x_lastlogin" name="x<?php echo $userdevices_grid->RowIndex ?>_lastlogin" id="x<?php echo $userdevices_grid->RowIndex ?>_lastlogin" maxlength="19" placeholder="<?php echo HtmlEncode($userdevices_grid->lastlogin->getPlaceHolder()) ?>" value="<?php echo $userdevices_grid->lastlogin->EditValue ?>"<?php echo $userdevices_grid->lastlogin->editAttributes() ?>>
<?php if (!$userdevices_grid->lastlogin->ReadOnly && !$userdevices_grid->lastlogin->Disabled && !isset($userdevices_grid->lastlogin->EditAttrs["readonly"]) && !isset($userdevices_grid->lastlogin->EditAttrs["disabled"])) { ?>
<script>
loadjs.ready(["fuserdevicesgrid", "datetimepicker"], function() {
	ew.createDateTimePicker("fuserdevicesgrid", "x<?php echo $userdevices_grid->RowIndex ?>_lastlogin", {"ignoreReadonly":true,"useCurrent":false,"format":0});
});
</script>
<?php } ?>
</span>
<?php } else { ?>
<span id="el$rowindex$_userdevices_lastlogin" class="form-group userdevices_lastlogin">
<span<?php echo $userdevices_grid->lastlogin->viewAttributes() ?>><input type="text" readonly class="form-control-plaintext" value="<?php echo HtmlEncode(RemoveHtml($userdevices_grid->lastlogin->ViewValue)) ?>"></span>
</span>
<input type="hidden" data-table="userdevices" data-field="x_lastlogin" name="x<?php echo $userdevices_grid->RowIndex ?>_lastlogin" id="x<?php echo $userdevices_grid->RowIndex ?>_lastlogin" value="<?php echo HtmlEncode($userdevices_grid->lastlogin->FormValue) ?>">
<?php } ?>
<input type="hidden" data-table="userdevices" data-field="x_lastlogin" name="o<?php echo $userdevices_grid->RowIndex ?>_lastlogin" id="o<?php echo $userdevices_grid->RowIndex ?>_lastlogin" value="<?php echo HtmlEncode($userdevices_grid->lastlogin->OldValue) ?>">
</td>
	<?php } ?>
<?php

// Render list options (body, right)
$userdevices_grid->ListOptions->render("body", "right", $userdevices_grid->RowIndex);
?>
<script>
loadjs.ready(["fuserdevicesgrid", "load"], function() {
	fuserdevicesgrid.updateLists(<?php echo $userdevices_grid->RowIndex ?>);
});
</script>
	</tr>
<?php
	}
?>
</tbody>
</table><!-- /.ew-table -->
</div><!-- /.ew-grid-middle-panel -->
<?php if ($userdevices->CurrentMode == "add" || $userdevices->CurrentMode == "copy") { ?>
<input type="hidden" name="<?php echo $userdevices_grid->FormKeyCountName ?>" id="<?php echo $userdevices_grid->FormKeyCountName ?>" value="<?php echo $userdevices_grid->KeyCount ?>">
<?php echo $userdevices_grid->MultiSelectKey ?>
<?php } ?>
<?php if ($userdevices->CurrentMode == "edit") { ?>
<input type="hidden" name="<?php echo $userdevices_grid->FormKeyCountName ?>" id="<?php echo $userdevices_grid->FormKeyCountName ?>" value="<?php echo $userdevices_grid->KeyCount ?>">
<?php echo $userdevices_grid->MultiSelectKey ?>
<?php } ?>
<?php if ($userdevices->CurrentMode == "") { ?>
<input type="hidden" name="action" id="action" value="">
<?php } ?>
<input type="hidden" name="detailpage" value="fuserdevicesgrid">
</div><!-- /.ew-list-form -->
<?php

// Close recordset
if ($userdevices_grid->Recordset)
	$userdevices_grid->Recordset->Close();
?>
<?php if ($userdevices_grid->ShowOtherOptions) { ?>
<div class="card-footer ew-grid-lower-panel">
<?php $userdevices_grid->OtherOptions->render("body", "bottom") ?>
</div>
<div class="clearfix"></div>
<?php } ?>
</div><!-- /.ew-grid -->
<?php } ?>
<?php if ($userdevices_grid->TotalRecords == 0 && !$userdevices->CurrentAction) { // Show other options ?>
<div class="ew-list-other-options">
<?php $userdevices_grid->OtherOptions->render("body") ?>
</div>
<div class="clearfix"></div>
<?php } ?>
<?php if (!$userdevices_grid->isExport()) { ?>
<script>
loadjs.ready("load", function() {

	// Startup script
	// Write your table-specific startup script here
	// console.log("page loaded");

});
</script>
<?php } ?>
<?php
$userdevices_grid->terminate();
?>