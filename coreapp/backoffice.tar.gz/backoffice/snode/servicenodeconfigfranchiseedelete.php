<?php
namespace PHPMaker2020\_4payadmin;

// Autoload
include_once "autoload.php";

// Session
if (session_status() !== PHP_SESSION_ACTIVE)
	\Delight\Cookie\Session::start(Config("COOKIE_SAMESITE")); // Init session data

// Output buffering
ob_start();
?>
<?php

// Write header
WriteHeader(FALSE);

// Create page object
$servicenodeconfigfranchisee_delete = new servicenodeconfigfranchisee_delete();

// Run the page
$servicenodeconfigfranchisee_delete->run();

// Setup login status
SetupLoginStatus();
SetClientVar("login", LoginStatus());

// Global Page Rendering event (in userfn*.php)
Page_Rendering();

// Page Rendering event
$servicenodeconfigfranchisee_delete->Page_Render();
?>
<?php include_once "header.php"; ?>
<script>
var fservicenodeconfigfranchiseedelete, currentPageID;
loadjs.ready("head", function() {

	// Form object
	currentPageID = ew.PAGE_ID = "delete";
	fservicenodeconfigfranchiseedelete = currentForm = new ew.Form("fservicenodeconfigfranchiseedelete", "delete");
	loadjs.done("fservicenodeconfigfranchiseedelete");
});
</script>
<script>
loadjs.ready("head", function() {

	// Client script
	// Write your client script here, no need to add script tags.

});
</script>
<?php $servicenodeconfigfranchisee_delete->showPageHeader(); ?>
<?php
$servicenodeconfigfranchisee_delete->showMessage();
?>
<form name="fservicenodeconfigfranchiseedelete" id="fservicenodeconfigfranchiseedelete" class="form-inline ew-form ew-delete-form" action="<?php echo CurrentPageName() ?>" method="post">
<?php if ($Page->CheckToken) { ?>
<input type="hidden" name="<?php echo Config("TOKEN_NAME") ?>" value="<?php echo $Page->Token ?>">
<?php } ?>
<input type="hidden" name="t" value="servicenodeconfigfranchisee">
<input type="hidden" name="action" id="action" value="delete">
<?php foreach ($servicenodeconfigfranchisee_delete->RecKeys as $key) { ?>
<?php $keyvalue = is_array($key) ? implode(Config("COMPOSITE_KEY_SEPARATOR"), $key) : $key; ?>
<input type="hidden" name="key_m[]" value="<?php echo HtmlEncode($keyvalue) ?>">
<?php } ?>
<div class="card ew-card ew-grid">
<div class="<?php echo ResponsiveTableClass() ?>card-body ew-grid-middle-panel">
<table class="table ew-table">
	<thead>
	<tr class="ew-table-header">
<?php if ($servicenodeconfigfranchisee_delete->configID->Visible) { // configID ?>
		<th class="<?php echo $servicenodeconfigfranchisee_delete->configID->headerCellClass() ?>"><span id="elh_servicenodeconfigfranchisee_configID" class="servicenodeconfigfranchisee_configID"><?php echo $servicenodeconfigfranchisee_delete->configID->caption() ?></span></th>
<?php } ?>
<?php if ($servicenodeconfigfranchisee_delete->franchiseeid->Visible) { // franchiseeid ?>
		<th class="<?php echo $servicenodeconfigfranchisee_delete->franchiseeid->headerCellClass() ?>"><span id="elh_servicenodeconfigfranchisee_franchiseeid" class="servicenodeconfigfranchisee_franchiseeid"><?php echo $servicenodeconfigfranchisee_delete->franchiseeid->caption() ?></span></th>
<?php } ?>
<?php if ($servicenodeconfigfranchisee_delete->value1->Visible) { // value1 ?>
		<th class="<?php echo $servicenodeconfigfranchisee_delete->value1->headerCellClass() ?>"><span id="elh_servicenodeconfigfranchisee_value1" class="servicenodeconfigfranchisee_value1"><?php echo $servicenodeconfigfranchisee_delete->value1->caption() ?></span></th>
<?php } ?>
<?php if ($servicenodeconfigfranchisee_delete->value2->Visible) { // value2 ?>
		<th class="<?php echo $servicenodeconfigfranchisee_delete->value2->headerCellClass() ?>"><span id="elh_servicenodeconfigfranchisee_value2" class="servicenodeconfigfranchisee_value2"><?php echo $servicenodeconfigfranchisee_delete->value2->caption() ?></span></th>
<?php } ?>
<?php if ($servicenodeconfigfranchisee_delete->value3->Visible) { // value3 ?>
		<th class="<?php echo $servicenodeconfigfranchisee_delete->value3->headerCellClass() ?>"><span id="elh_servicenodeconfigfranchisee_value3" class="servicenodeconfigfranchisee_value3"><?php echo $servicenodeconfigfranchisee_delete->value3->caption() ?></span></th>
<?php } ?>
	</tr>
	</thead>
	<tbody>
<?php
$servicenodeconfigfranchisee_delete->RecordCount = 0;
$i = 0;
while (!$servicenodeconfigfranchisee_delete->Recordset->EOF) {
	$servicenodeconfigfranchisee_delete->RecordCount++;
	$servicenodeconfigfranchisee_delete->RowCount++;

	// Set row properties
	$servicenodeconfigfranchisee->resetAttributes();
	$servicenodeconfigfranchisee->RowType = ROWTYPE_VIEW; // View

	// Get the field contents
	$servicenodeconfigfranchisee_delete->loadRowValues($servicenodeconfigfranchisee_delete->Recordset);

	// Render row
	$servicenodeconfigfranchisee_delete->renderRow();
?>
	<tr <?php echo $servicenodeconfigfranchisee->rowAttributes() ?>>
<?php if ($servicenodeconfigfranchisee_delete->configID->Visible) { // configID ?>
		<td <?php echo $servicenodeconfigfranchisee_delete->configID->cellAttributes() ?>>
<span id="el<?php echo $servicenodeconfigfranchisee_delete->RowCount ?>_servicenodeconfigfranchisee_configID" class="servicenodeconfigfranchisee_configID">
<span<?php echo $servicenodeconfigfranchisee_delete->configID->viewAttributes() ?>><?php echo $servicenodeconfigfranchisee_delete->configID->getViewValue() ?></span>
</span>
</td>
<?php } ?>
<?php if ($servicenodeconfigfranchisee_delete->franchiseeid->Visible) { // franchiseeid ?>
		<td <?php echo $servicenodeconfigfranchisee_delete->franchiseeid->cellAttributes() ?>>
<span id="el<?php echo $servicenodeconfigfranchisee_delete->RowCount ?>_servicenodeconfigfranchisee_franchiseeid" class="servicenodeconfigfranchisee_franchiseeid">
<span<?php echo $servicenodeconfigfranchisee_delete->franchiseeid->viewAttributes() ?>><?php echo $servicenodeconfigfranchisee_delete->franchiseeid->getViewValue() ?></span>
</span>
</td>
<?php } ?>
<?php if ($servicenodeconfigfranchisee_delete->value1->Visible) { // value1 ?>
		<td <?php echo $servicenodeconfigfranchisee_delete->value1->cellAttributes() ?>>
<span id="el<?php echo $servicenodeconfigfranchisee_delete->RowCount ?>_servicenodeconfigfranchisee_value1" class="servicenodeconfigfranchisee_value1">
<span<?php echo $servicenodeconfigfranchisee_delete->value1->viewAttributes() ?>><?php echo $servicenodeconfigfranchisee_delete->value1->getViewValue() ?></span>
</span>
</td>
<?php } ?>
<?php if ($servicenodeconfigfranchisee_delete->value2->Visible) { // value2 ?>
		<td <?php echo $servicenodeconfigfranchisee_delete->value2->cellAttributes() ?>>
<span id="el<?php echo $servicenodeconfigfranchisee_delete->RowCount ?>_servicenodeconfigfranchisee_value2" class="servicenodeconfigfranchisee_value2">
<span<?php echo $servicenodeconfigfranchisee_delete->value2->viewAttributes() ?>><?php echo $servicenodeconfigfranchisee_delete->value2->getViewValue() ?></span>
</span>
</td>
<?php } ?>
<?php if ($servicenodeconfigfranchisee_delete->value3->Visible) { // value3 ?>
		<td <?php echo $servicenodeconfigfranchisee_delete->value3->cellAttributes() ?>>
<span id="el<?php echo $servicenodeconfigfranchisee_delete->RowCount ?>_servicenodeconfigfranchisee_value3" class="servicenodeconfigfranchisee_value3">
<span<?php echo $servicenodeconfigfranchisee_delete->value3->viewAttributes() ?>><?php echo $servicenodeconfigfranchisee_delete->value3->getViewValue() ?></span>
</span>
</td>
<?php } ?>
	</tr>
<?php
	$servicenodeconfigfranchisee_delete->Recordset->moveNext();
}
$servicenodeconfigfranchisee_delete->Recordset->close();
?>
</tbody>
</table>
</div>
</div>
<div>
<button class="btn btn-primary ew-btn" name="btn-action" id="btn-action" type="submit"><?php echo $Language->phrase("DeleteBtn") ?></button>
<button class="btn btn-default ew-btn" name="btn-cancel" id="btn-cancel" type="button" data-href="<?php echo $servicenodeconfigfranchisee_delete->getReturnUrl() ?>"><?php echo $Language->phrase("CancelBtn") ?></button>
</div>
</form>
<?php
$servicenodeconfigfranchisee_delete->showPageFooter();
if (Config("DEBUG"))
	echo GetDebugMessage();
?>
<script>
loadjs.ready("load", function() {

	// Startup script
	// Write your table-specific startup script here
	// console.log("page loaded");

});
</script>
<?php include_once "footer.php"; ?>
<?php
$servicenodeconfigfranchisee_delete->terminate();
?>