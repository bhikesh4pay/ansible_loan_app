<?php
namespace PHPMaker2020\_4payadmin;

// Autoload
include_once "autoload.php";

// Session
if (session_status() !== PHP_SESSION_ACTIVE)
	\Delight\Cookie\Session::start(Config("COOKIE_SAMESITE")); // Init session data

// Output buffering
ob_start();
?>
<?php

// Write header
WriteHeader(FALSE);

// Create page object
$vcctransactions_search = new vcctransactions_search();

// Run the page
$vcctransactions_search->run();

// Setup login status
SetupLoginStatus();
SetClientVar("login", LoginStatus());

// Global Page Rendering event (in userfn*.php)
Page_Rendering();

// Page Rendering event
$vcctransactions_search->Page_Render();
?>
<?php include_once "header.php"; ?>
<script>
var fvcctransactionssearch, currentPageID;
loadjs.ready("head", function() {

	// Form object for search
	<?php if ($vcctransactions_search->IsModal) { ?>
	fvcctransactionssearch = currentAdvancedSearchForm = new ew.Form("fvcctransactionssearch", "search");
	<?php } else { ?>
	fvcctransactionssearch = currentForm = new ew.Form("fvcctransactionssearch", "search");
	<?php } ?>
	currentPageID = ew.PAGE_ID = "search";

	// Validate function for search
	fvcctransactionssearch.validate = function(fobj) {
		if (!this.validateRequired)
			return true; // Ignore validation
		fobj = fobj || this._form;
		var infix = "";
		elm = this.getElements("x" + infix + "_id");
		if (elm && !ew.checkInteger(elm.value))
			return this.onError(elm, "<?php echo JsEncode($vcctransactions_search->id->errorMessage()) ?>");
		elm = this.getElements("x" + infix + "_datecreated");
		if (elm && !ew.checkDateDef(elm.value))
			return this.onError(elm, "<?php echo JsEncode($vcctransactions_search->datecreated->errorMessage()) ?>");
		elm = this.getElements("x" + infix + "_brokerid");
		if (elm && !ew.checkInteger(elm.value))
			return this.onError(elm, "<?php echo JsEncode($vcctransactions_search->brokerid->errorMessage()) ?>");
		elm = this.getElements("x" + infix + "_requestorid");
		if (elm && !ew.checkInteger(elm.value))
			return this.onError(elm, "<?php echo JsEncode($vcctransactions_search->requestorid->errorMessage()) ?>");
		elm = this.getElements("x" + infix + "_requestor4payuser");
		if (elm && !ew.checkInteger(elm.value))
			return this.onError(elm, "<?php echo JsEncode($vcctransactions_search->requestor4payuser->errorMessage()) ?>");
		elm = this.getElements("x" + infix + "_recipientid");
		if (elm && !ew.checkInteger(elm.value))
			return this.onError(elm, "<?php echo JsEncode($vcctransactions_search->recipientid->errorMessage()) ?>");
		elm = this.getElements("x" + infix + "_recipient4payuser");
		if (elm && !ew.checkInteger(elm.value))
			return this.onError(elm, "<?php echo JsEncode($vcctransactions_search->recipient4payuser->errorMessage()) ?>");
		elm = this.getElements("x" + infix + "_saleid");
		if (elm && !ew.checkInteger(elm.value))
			return this.onError(elm, "<?php echo JsEncode($vcctransactions_search->saleid->errorMessage()) ?>");
		elm = this.getElements("x" + infix + "_operatorid");
		if (elm && !ew.checkInteger(elm.value))
			return this.onError(elm, "<?php echo JsEncode($vcctransactions_search->operatorid->errorMessage()) ?>");
		elm = this.getElements("x" + infix + "_amount");
		if (elm && !ew.checkNumber(elm.value))
			return this.onError(elm, "<?php echo JsEncode($vcctransactions_search->amount->errorMessage()) ?>");

		// Call Form_CustomValidate event
		if (!this.Form_CustomValidate(fobj))
			return false;
		return true;
	}

	// Form_CustomValidate
	fvcctransactionssearch.Form_CustomValidate = function(fobj) { // DO NOT CHANGE THIS LINE!

		// Your custom validation code here, return false if invalid.
		return true;
	}

	// Use JavaScript validation or not
	fvcctransactionssearch.validateRequired = <?php echo Config("CLIENT_VALIDATE") ? "true" : "false" ?>;

	// Dynamic selection lists
	loadjs.done("fvcctransactionssearch");
});
</script>
<script>
loadjs.ready("head", function() {

	// Client script
	// Write your client script here, no need to add script tags.

});
</script>
<?php $vcctransactions_search->showPageHeader(); ?>
<?php
$vcctransactions_search->showMessage();
?>
<form name="fvcctransactionssearch" id="fvcctransactionssearch" class="<?php echo $vcctransactions_search->FormClassName ?>" action="<?php echo CurrentPageName() ?>" method="post">
<?php if ($Page->CheckToken) { ?>
<input type="hidden" name="<?php echo Config("TOKEN_NAME") ?>" value="<?php echo $Page->Token ?>">
<?php } ?>
<input type="hidden" name="t" value="vcctransactions">
<input type="hidden" name="action" id="action" value="search">
<input type="hidden" name="modal" value="<?php echo (int)$vcctransactions_search->IsModal ?>">
<div class="ew-search-div"><!-- page* -->
<?php if ($vcctransactions_search->id->Visible) { // id ?>
	<div id="r_id" class="form-group row">
		<label for="x_id" class="<?php echo $vcctransactions_search->LeftColumnClass ?>"><span id="elh_vcctransactions_id"><?php echo $vcctransactions_search->id->caption() ?></span>
		<span class="ew-search-operator">
<?php echo $Language->phrase("=") ?>
<input type="hidden" name="z_id" id="z_id" value="=">
</span>
		</label>
		<div class="<?php echo $vcctransactions_search->RightColumnClass ?>"><div <?php echo $vcctransactions_search->id->cellAttributes() ?>>
			<span id="el_vcctransactions_id" class="ew-search-field">
<input type="text" data-table="vcctransactions" data-field="x_id" name="x_id" id="x_id" placeholder="<?php echo HtmlEncode($vcctransactions_search->id->getPlaceHolder()) ?>" value="<?php echo $vcctransactions_search->id->EditValue ?>"<?php echo $vcctransactions_search->id->editAttributes() ?>>
</span>
		</div></div>
	</div>
<?php } ?>
<?php if ($vcctransactions_search->datecreated->Visible) { // datecreated ?>
	<div id="r_datecreated" class="form-group row">
		<label for="x_datecreated" class="<?php echo $vcctransactions_search->LeftColumnClass ?>"><span id="elh_vcctransactions_datecreated"><?php echo $vcctransactions_search->datecreated->caption() ?></span>
		<span class="ew-search-operator">
<?php echo $Language->phrase("=") ?>
<input type="hidden" name="z_datecreated" id="z_datecreated" value="=">
</span>
		</label>
		<div class="<?php echo $vcctransactions_search->RightColumnClass ?>"><div <?php echo $vcctransactions_search->datecreated->cellAttributes() ?>>
			<span id="el_vcctransactions_datecreated" class="ew-search-field">
<input type="text" data-table="vcctransactions" data-field="x_datecreated" name="x_datecreated" id="x_datecreated" placeholder="<?php echo HtmlEncode($vcctransactions_search->datecreated->getPlaceHolder()) ?>" value="<?php echo $vcctransactions_search->datecreated->EditValue ?>"<?php echo $vcctransactions_search->datecreated->editAttributes() ?>>
</span>
		</div></div>
	</div>
<?php } ?>
<?php if ($vcctransactions_search->brokerid->Visible) { // brokerid ?>
	<div id="r_brokerid" class="form-group row">
		<label for="x_brokerid" class="<?php echo $vcctransactions_search->LeftColumnClass ?>"><span id="elh_vcctransactions_brokerid"><?php echo $vcctransactions_search->brokerid->caption() ?></span>
		<span class="ew-search-operator">
<?php echo $Language->phrase("=") ?>
<input type="hidden" name="z_brokerid" id="z_brokerid" value="=">
</span>
		</label>
		<div class="<?php echo $vcctransactions_search->RightColumnClass ?>"><div <?php echo $vcctransactions_search->brokerid->cellAttributes() ?>>
			<span id="el_vcctransactions_brokerid" class="ew-search-field">
<input type="text" data-table="vcctransactions" data-field="x_brokerid" name="x_brokerid" id="x_brokerid" size="30" placeholder="<?php echo HtmlEncode($vcctransactions_search->brokerid->getPlaceHolder()) ?>" value="<?php echo $vcctransactions_search->brokerid->EditValue ?>"<?php echo $vcctransactions_search->brokerid->editAttributes() ?>>
</span>
		</div></div>
	</div>
<?php } ?>
<?php if ($vcctransactions_search->requestorid->Visible) { // requestorid ?>
	<div id="r_requestorid" class="form-group row">
		<label for="x_requestorid" class="<?php echo $vcctransactions_search->LeftColumnClass ?>"><span id="elh_vcctransactions_requestorid"><?php echo $vcctransactions_search->requestorid->caption() ?></span>
		<span class="ew-search-operator">
<?php echo $Language->phrase("=") ?>
<input type="hidden" name="z_requestorid" id="z_requestorid" value="=">
</span>
		</label>
		<div class="<?php echo $vcctransactions_search->RightColumnClass ?>"><div <?php echo $vcctransactions_search->requestorid->cellAttributes() ?>>
			<span id="el_vcctransactions_requestorid" class="ew-search-field">
<input type="text" data-table="vcctransactions" data-field="x_requestorid" name="x_requestorid" id="x_requestorid" size="30" placeholder="<?php echo HtmlEncode($vcctransactions_search->requestorid->getPlaceHolder()) ?>" value="<?php echo $vcctransactions_search->requestorid->EditValue ?>"<?php echo $vcctransactions_search->requestorid->editAttributes() ?>>
</span>
		</div></div>
	</div>
<?php } ?>
<?php if ($vcctransactions_search->requestor4payuser->Visible) { // requestor4payuser ?>
	<div id="r_requestor4payuser" class="form-group row">
		<label for="x_requestor4payuser" class="<?php echo $vcctransactions_search->LeftColumnClass ?>"><span id="elh_vcctransactions_requestor4payuser"><?php echo $vcctransactions_search->requestor4payuser->caption() ?></span>
		<span class="ew-search-operator">
<?php echo $Language->phrase("=") ?>
<input type="hidden" name="z_requestor4payuser" id="z_requestor4payuser" value="=">
</span>
		</label>
		<div class="<?php echo $vcctransactions_search->RightColumnClass ?>"><div <?php echo $vcctransactions_search->requestor4payuser->cellAttributes() ?>>
			<span id="el_vcctransactions_requestor4payuser" class="ew-search-field">
<input type="text" data-table="vcctransactions" data-field="x_requestor4payuser" name="x_requestor4payuser" id="x_requestor4payuser" size="30" placeholder="<?php echo HtmlEncode($vcctransactions_search->requestor4payuser->getPlaceHolder()) ?>" value="<?php echo $vcctransactions_search->requestor4payuser->EditValue ?>"<?php echo $vcctransactions_search->requestor4payuser->editAttributes() ?>>
</span>
		</div></div>
	</div>
<?php } ?>
<?php if ($vcctransactions_search->recipientid->Visible) { // recipientid ?>
	<div id="r_recipientid" class="form-group row">
		<label for="x_recipientid" class="<?php echo $vcctransactions_search->LeftColumnClass ?>"><span id="elh_vcctransactions_recipientid"><?php echo $vcctransactions_search->recipientid->caption() ?></span>
		<span class="ew-search-operator">
<?php echo $Language->phrase("=") ?>
<input type="hidden" name="z_recipientid" id="z_recipientid" value="=">
</span>
		</label>
		<div class="<?php echo $vcctransactions_search->RightColumnClass ?>"><div <?php echo $vcctransactions_search->recipientid->cellAttributes() ?>>
			<span id="el_vcctransactions_recipientid" class="ew-search-field">
<input type="text" data-table="vcctransactions" data-field="x_recipientid" name="x_recipientid" id="x_recipientid" size="30" placeholder="<?php echo HtmlEncode($vcctransactions_search->recipientid->getPlaceHolder()) ?>" value="<?php echo $vcctransactions_search->recipientid->EditValue ?>"<?php echo $vcctransactions_search->recipientid->editAttributes() ?>>
</span>
		</div></div>
	</div>
<?php } ?>
<?php if ($vcctransactions_search->recipient4payuser->Visible) { // recipient4payuser ?>
	<div id="r_recipient4payuser" class="form-group row">
		<label for="x_recipient4payuser" class="<?php echo $vcctransactions_search->LeftColumnClass ?>"><span id="elh_vcctransactions_recipient4payuser"><?php echo $vcctransactions_search->recipient4payuser->caption() ?></span>
		<span class="ew-search-operator">
<?php echo $Language->phrase("=") ?>
<input type="hidden" name="z_recipient4payuser" id="z_recipient4payuser" value="=">
</span>
		</label>
		<div class="<?php echo $vcctransactions_search->RightColumnClass ?>"><div <?php echo $vcctransactions_search->recipient4payuser->cellAttributes() ?>>
			<span id="el_vcctransactions_recipient4payuser" class="ew-search-field">
<input type="text" data-table="vcctransactions" data-field="x_recipient4payuser" name="x_recipient4payuser" id="x_recipient4payuser" size="30" placeholder="<?php echo HtmlEncode($vcctransactions_search->recipient4payuser->getPlaceHolder()) ?>" value="<?php echo $vcctransactions_search->recipient4payuser->EditValue ?>"<?php echo $vcctransactions_search->recipient4payuser->editAttributes() ?>>
</span>
		</div></div>
	</div>
<?php } ?>
<?php if ($vcctransactions_search->refno1->Visible) { // refno1 ?>
	<div id="r_refno1" class="form-group row">
		<label for="x_refno1" class="<?php echo $vcctransactions_search->LeftColumnClass ?>"><span id="elh_vcctransactions_refno1"><?php echo $vcctransactions_search->refno1->caption() ?></span>
		<span class="ew-search-operator">
<?php echo $Language->phrase("LIKE") ?>
<input type="hidden" name="z_refno1" id="z_refno1" value="LIKE">
</span>
		</label>
		<div class="<?php echo $vcctransactions_search->RightColumnClass ?>"><div <?php echo $vcctransactions_search->refno1->cellAttributes() ?>>
			<span id="el_vcctransactions_refno1" class="ew-search-field">
<input type="text" data-table="vcctransactions" data-field="x_refno1" name="x_refno1" id="x_refno1" size="30" maxlength="20" placeholder="<?php echo HtmlEncode($vcctransactions_search->refno1->getPlaceHolder()) ?>" value="<?php echo $vcctransactions_search->refno1->EditValue ?>"<?php echo $vcctransactions_search->refno1->editAttributes() ?>>
</span>
		</div></div>
	</div>
<?php } ?>
<?php if ($vcctransactions_search->refno2->Visible) { // refno2 ?>
	<div id="r_refno2" class="form-group row">
		<label for="x_refno2" class="<?php echo $vcctransactions_search->LeftColumnClass ?>"><span id="elh_vcctransactions_refno2"><?php echo $vcctransactions_search->refno2->caption() ?></span>
		<span class="ew-search-operator">
<?php echo $Language->phrase("LIKE") ?>
<input type="hidden" name="z_refno2" id="z_refno2" value="LIKE">
</span>
		</label>
		<div class="<?php echo $vcctransactions_search->RightColumnClass ?>"><div <?php echo $vcctransactions_search->refno2->cellAttributes() ?>>
			<span id="el_vcctransactions_refno2" class="ew-search-field">
<input type="text" data-table="vcctransactions" data-field="x_refno2" name="x_refno2" id="x_refno2" size="30" maxlength="20" placeholder="<?php echo HtmlEncode($vcctransactions_search->refno2->getPlaceHolder()) ?>" value="<?php echo $vcctransactions_search->refno2->EditValue ?>"<?php echo $vcctransactions_search->refno2->editAttributes() ?>>
</span>
		</div></div>
	</div>
<?php } ?>
<?php if ($vcctransactions_search->saleid->Visible) { // saleid ?>
	<div id="r_saleid" class="form-group row">
		<label for="x_saleid" class="<?php echo $vcctransactions_search->LeftColumnClass ?>"><span id="elh_vcctransactions_saleid"><?php echo $vcctransactions_search->saleid->caption() ?></span>
		<span class="ew-search-operator">
<?php echo $Language->phrase("=") ?>
<input type="hidden" name="z_saleid" id="z_saleid" value="=">
</span>
		</label>
		<div class="<?php echo $vcctransactions_search->RightColumnClass ?>"><div <?php echo $vcctransactions_search->saleid->cellAttributes() ?>>
			<span id="el_vcctransactions_saleid" class="ew-search-field">
<input type="text" data-table="vcctransactions" data-field="x_saleid" name="x_saleid" id="x_saleid" size="30" maxlength="15" placeholder="<?php echo HtmlEncode($vcctransactions_search->saleid->getPlaceHolder()) ?>" value="<?php echo $vcctransactions_search->saleid->EditValue ?>"<?php echo $vcctransactions_search->saleid->editAttributes() ?>>
</span>
		</div></div>
	</div>
<?php } ?>
<?php if ($vcctransactions_search->operatorid->Visible) { // operatorid ?>
	<div id="r_operatorid" class="form-group row">
		<label for="x_operatorid" class="<?php echo $vcctransactions_search->LeftColumnClass ?>"><span id="elh_vcctransactions_operatorid"><?php echo $vcctransactions_search->operatorid->caption() ?></span>
		<span class="ew-search-operator">
<?php echo $Language->phrase("=") ?>
<input type="hidden" name="z_operatorid" id="z_operatorid" value="=">
</span>
		</label>
		<div class="<?php echo $vcctransactions_search->RightColumnClass ?>"><div <?php echo $vcctransactions_search->operatorid->cellAttributes() ?>>
			<span id="el_vcctransactions_operatorid" class="ew-search-field">
<input type="text" data-table="vcctransactions" data-field="x_operatorid" name="x_operatorid" id="x_operatorid" size="30" maxlength="12" placeholder="<?php echo HtmlEncode($vcctransactions_search->operatorid->getPlaceHolder()) ?>" value="<?php echo $vcctransactions_search->operatorid->EditValue ?>"<?php echo $vcctransactions_search->operatorid->editAttributes() ?>>
</span>
		</div></div>
	</div>
<?php } ?>
<?php if ($vcctransactions_search->branchname->Visible) { // branchname ?>
	<div id="r_branchname" class="form-group row">
		<label for="x_branchname" class="<?php echo $vcctransactions_search->LeftColumnClass ?>"><span id="elh_vcctransactions_branchname"><?php echo $vcctransactions_search->branchname->caption() ?></span>
		<span class="ew-search-operator">
<?php echo $Language->phrase("LIKE") ?>
<input type="hidden" name="z_branchname" id="z_branchname" value="LIKE">
</span>
		</label>
		<div class="<?php echo $vcctransactions_search->RightColumnClass ?>"><div <?php echo $vcctransactions_search->branchname->cellAttributes() ?>>
			<span id="el_vcctransactions_branchname" class="ew-search-field">
<input type="text" data-table="vcctransactions" data-field="x_branchname" name="x_branchname" id="x_branchname" size="30" maxlength="50" placeholder="<?php echo HtmlEncode($vcctransactions_search->branchname->getPlaceHolder()) ?>" value="<?php echo $vcctransactions_search->branchname->EditValue ?>"<?php echo $vcctransactions_search->branchname->editAttributes() ?>>
</span>
		</div></div>
	</div>
<?php } ?>
<?php if ($vcctransactions_search->operatorname->Visible) { // operatorname ?>
	<div id="r_operatorname" class="form-group row">
		<label for="x_operatorname" class="<?php echo $vcctransactions_search->LeftColumnClass ?>"><span id="elh_vcctransactions_operatorname"><?php echo $vcctransactions_search->operatorname->caption() ?></span>
		<span class="ew-search-operator">
<?php echo $Language->phrase("LIKE") ?>
<input type="hidden" name="z_operatorname" id="z_operatorname" value="LIKE">
</span>
		</label>
		<div class="<?php echo $vcctransactions_search->RightColumnClass ?>"><div <?php echo $vcctransactions_search->operatorname->cellAttributes() ?>>
			<span id="el_vcctransactions_operatorname" class="ew-search-field">
<input type="text" data-table="vcctransactions" data-field="x_operatorname" name="x_operatorname" id="x_operatorname" size="30" maxlength="50" placeholder="<?php echo HtmlEncode($vcctransactions_search->operatorname->getPlaceHolder()) ?>" value="<?php echo $vcctransactions_search->operatorname->EditValue ?>"<?php echo $vcctransactions_search->operatorname->editAttributes() ?>>
</span>
		</div></div>
	</div>
<?php } ?>
<?php if ($vcctransactions_search->customername->Visible) { // customername ?>
	<div id="r_customername" class="form-group row">
		<label for="x_customername" class="<?php echo $vcctransactions_search->LeftColumnClass ?>"><span id="elh_vcctransactions_customername"><?php echo $vcctransactions_search->customername->caption() ?></span>
		<span class="ew-search-operator">
<?php echo $Language->phrase("LIKE") ?>
<input type="hidden" name="z_customername" id="z_customername" value="LIKE">
</span>
		</label>
		<div class="<?php echo $vcctransactions_search->RightColumnClass ?>"><div <?php echo $vcctransactions_search->customername->cellAttributes() ?>>
			<span id="el_vcctransactions_customername" class="ew-search-field">
<input type="text" data-table="vcctransactions" data-field="x_customername" name="x_customername" id="x_customername" size="30" maxlength="80" placeholder="<?php echo HtmlEncode($vcctransactions_search->customername->getPlaceHolder()) ?>" value="<?php echo $vcctransactions_search->customername->EditValue ?>"<?php echo $vcctransactions_search->customername->editAttributes() ?>>
</span>
		</div></div>
	</div>
<?php } ?>
<?php if ($vcctransactions_search->amount->Visible) { // amount ?>
	<div id="r_amount" class="form-group row">
		<label for="x_amount" class="<?php echo $vcctransactions_search->LeftColumnClass ?>"><span id="elh_vcctransactions_amount"><?php echo $vcctransactions_search->amount->caption() ?></span>
		<span class="ew-search-operator">
<?php echo $Language->phrase("=") ?>
<input type="hidden" name="z_amount" id="z_amount" value="=">
</span>
		</label>
		<div class="<?php echo $vcctransactions_search->RightColumnClass ?>"><div <?php echo $vcctransactions_search->amount->cellAttributes() ?>>
			<span id="el_vcctransactions_amount" class="ew-search-field">
<input type="text" data-table="vcctransactions" data-field="x_amount" name="x_amount" id="x_amount" size="30" maxlength="12" placeholder="<?php echo HtmlEncode($vcctransactions_search->amount->getPlaceHolder()) ?>" value="<?php echo $vcctransactions_search->amount->EditValue ?>"<?php echo $vcctransactions_search->amount->editAttributes() ?>>
</span>
		</div></div>
	</div>
<?php } ?>
</div><!-- /page* -->
<?php if (!$vcctransactions_search->IsModal) { ?>
<div class="form-group row"><!-- buttons .form-group -->
	<div class="<?php echo $vcctransactions_search->OffsetColumnClass ?>"><!-- buttons offset -->
<button class="btn btn-primary ew-btn" name="btn-action" id="btn-action" type="submit"><?php echo $Language->phrase("Search") ?></button>
<button class="btn btn-default ew-btn" name="btn-reset" id="btn-reset" type="button" onclick="ew.clearForm(this.form);"><?php echo $Language->phrase("Reset") ?></button>
	</div><!-- /buttons offset -->
</div><!-- /buttons .form-group -->
<?php } ?>
</form>
<?php
$vcctransactions_search->showPageFooter();
if (Config("DEBUG"))
	echo GetDebugMessage();
?>
<script>
loadjs.ready("load", function() {

	// Startup script
	// Write your table-specific startup script here
	// console.log("page loaded");

});
</script>
<?php include_once "footer.php"; ?>
<?php
$vcctransactions_search->terminate();
?>