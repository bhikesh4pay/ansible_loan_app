<?php
namespace PHPMaker2020\_4payadmin;

// Autoload
include_once "autoload.php";

// Session
if (session_status() !== PHP_SESSION_ACTIVE)
	\Delight\Cookie\Session::start(Config("COOKIE_SAMESITE")); // Init session data

// Output buffering
ob_start();
?>
<?php

// Write header
WriteHeader(FALSE, "utf-8");

// Create page object
$loanpaymentplan_preview = new loanpaymentplan_preview();

// Run the page
$loanpaymentplan_preview->run();

// Setup login status
SetupLoginStatus();
SetClientVar("login", LoginStatus());

// Global Page Rendering event (in userfn*.php)
Page_Rendering();

// Page Rendering event
$loanpaymentplan_preview->Page_Render();
?>
<?php $loanpaymentplan_preview->showPageHeader(); ?>
<?php if ($loanpaymentplan_preview->TotalRecords > 0) { ?>
<div class="card ew-grid loanpaymentplan"><!-- .card -->
<div class="<?php echo ResponsiveTableClass() ?>card-body ew-grid-middle-panel ew-preview-middle-panel"><!-- .table-responsive -->
<table class="table ew-table ew-preview-table"><!-- .table -->
	<thead><!-- Table header -->
		<tr class="ew-table-header">
<?php

// Render list options
$loanpaymentplan_preview->renderListOptions();

// Render list options (header, left)
$loanpaymentplan_preview->ListOptions->render("header", "left");
?>
<?php if ($loanpaymentplan_preview->paymentplanid->Visible) { // paymentplanid ?>
	<?php if ($loanpaymentplan->SortUrl($loanpaymentplan_preview->paymentplanid) == "") { ?>
		<th class="<?php echo $loanpaymentplan_preview->paymentplanid->headerCellClass() ?>"><?php echo $loanpaymentplan_preview->paymentplanid->caption() ?></th>
	<?php } else { ?>
		<th class="<?php echo $loanpaymentplan_preview->paymentplanid->headerCellClass() ?>"><div class="ew-pointer" data-sort="<?php echo HtmlEncode($loanpaymentplan_preview->paymentplanid->Name) ?>" data-sort-order="<?php echo $loanpaymentplan_preview->SortField == $loanpaymentplan_preview->paymentplanid->Name && $loanpaymentplan_preview->SortOrder == "ASC" ? "DESC" : "ASC" ?>">
			<div class="ew-table-header-btn"><span class="ew-table-header-caption"><?php echo $loanpaymentplan_preview->paymentplanid->caption() ?></span><span class="ew-table-header-sort"><?php if ($loanpaymentplan_preview->SortField == $loanpaymentplan_preview->paymentplanid->Name) { ?><?php if ($loanpaymentplan_preview->SortOrder == "ASC") { ?><i class="fas fa-sort-up"></i><?php } elseif ($loanpaymentplan_preview->SortOrder == "DESC") { ?><i class="fas fa-sort-down"></i><?php } ?><?php } ?></span>
		</div></div></th>
	<?php } ?>
<?php } ?>
<?php if ($loanpaymentplan_preview->termno->Visible) { // termno ?>
	<?php if ($loanpaymentplan->SortUrl($loanpaymentplan_preview->termno) == "") { ?>
		<th class="<?php echo $loanpaymentplan_preview->termno->headerCellClass() ?>"><?php echo $loanpaymentplan_preview->termno->caption() ?></th>
	<?php } else { ?>
		<th class="<?php echo $loanpaymentplan_preview->termno->headerCellClass() ?>"><div class="ew-pointer" data-sort="<?php echo HtmlEncode($loanpaymentplan_preview->termno->Name) ?>" data-sort-order="<?php echo $loanpaymentplan_preview->SortField == $loanpaymentplan_preview->termno->Name && $loanpaymentplan_preview->SortOrder == "ASC" ? "DESC" : "ASC" ?>">
			<div class="ew-table-header-btn"><span class="ew-table-header-caption"><?php echo $loanpaymentplan_preview->termno->caption() ?></span><span class="ew-table-header-sort"><?php if ($loanpaymentplan_preview->SortField == $loanpaymentplan_preview->termno->Name) { ?><?php if ($loanpaymentplan_preview->SortOrder == "ASC") { ?><i class="fas fa-sort-up"></i><?php } elseif ($loanpaymentplan_preview->SortOrder == "DESC") { ?><i class="fas fa-sort-down"></i><?php } ?><?php } ?></span>
		</div></div></th>
	<?php } ?>
<?php } ?>
<?php if ($loanpaymentplan_preview->paymentduedate->Visible) { // paymentduedate ?>
	<?php if ($loanpaymentplan->SortUrl($loanpaymentplan_preview->paymentduedate) == "") { ?>
		<th class="<?php echo $loanpaymentplan_preview->paymentduedate->headerCellClass() ?>"><?php echo $loanpaymentplan_preview->paymentduedate->caption() ?></th>
	<?php } else { ?>
		<th class="<?php echo $loanpaymentplan_preview->paymentduedate->headerCellClass() ?>"><div class="ew-pointer" data-sort="<?php echo HtmlEncode($loanpaymentplan_preview->paymentduedate->Name) ?>" data-sort-order="<?php echo $loanpaymentplan_preview->SortField == $loanpaymentplan_preview->paymentduedate->Name && $loanpaymentplan_preview->SortOrder == "ASC" ? "DESC" : "ASC" ?>">
			<div class="ew-table-header-btn"><span class="ew-table-header-caption"><?php echo $loanpaymentplan_preview->paymentduedate->caption() ?></span><span class="ew-table-header-sort"><?php if ($loanpaymentplan_preview->SortField == $loanpaymentplan_preview->paymentduedate->Name) { ?><?php if ($loanpaymentplan_preview->SortOrder == "ASC") { ?><i class="fas fa-sort-up"></i><?php } elseif ($loanpaymentplan_preview->SortOrder == "DESC") { ?><i class="fas fa-sort-down"></i><?php } ?><?php } ?></span>
		</div></div></th>
	<?php } ?>
<?php } ?>
<?php if ($loanpaymentplan_preview->outstandingprincipal->Visible) { // outstandingprincipal ?>
	<?php if ($loanpaymentplan->SortUrl($loanpaymentplan_preview->outstandingprincipal) == "") { ?>
		<th class="<?php echo $loanpaymentplan_preview->outstandingprincipal->headerCellClass() ?>"><?php echo $loanpaymentplan_preview->outstandingprincipal->caption() ?></th>
	<?php } else { ?>
		<th class="<?php echo $loanpaymentplan_preview->outstandingprincipal->headerCellClass() ?>"><div class="ew-pointer" data-sort="<?php echo HtmlEncode($loanpaymentplan_preview->outstandingprincipal->Name) ?>" data-sort-order="<?php echo $loanpaymentplan_preview->SortField == $loanpaymentplan_preview->outstandingprincipal->Name && $loanpaymentplan_preview->SortOrder == "ASC" ? "DESC" : "ASC" ?>">
			<div class="ew-table-header-btn"><span class="ew-table-header-caption"><?php echo $loanpaymentplan_preview->outstandingprincipal->caption() ?></span><span class="ew-table-header-sort"><?php if ($loanpaymentplan_preview->SortField == $loanpaymentplan_preview->outstandingprincipal->Name) { ?><?php if ($loanpaymentplan_preview->SortOrder == "ASC") { ?><i class="fas fa-sort-up"></i><?php } elseif ($loanpaymentplan_preview->SortOrder == "DESC") { ?><i class="fas fa-sort-down"></i><?php } ?><?php } ?></span>
		</div></div></th>
	<?php } ?>
<?php } ?>
<?php if ($loanpaymentplan_preview->outsandinginterest->Visible) { // outsandinginterest ?>
	<?php if ($loanpaymentplan->SortUrl($loanpaymentplan_preview->outsandinginterest) == "") { ?>
		<th class="<?php echo $loanpaymentplan_preview->outsandinginterest->headerCellClass() ?>"><?php echo $loanpaymentplan_preview->outsandinginterest->caption() ?></th>
	<?php } else { ?>
		<th class="<?php echo $loanpaymentplan_preview->outsandinginterest->headerCellClass() ?>"><div class="ew-pointer" data-sort="<?php echo HtmlEncode($loanpaymentplan_preview->outsandinginterest->Name) ?>" data-sort-order="<?php echo $loanpaymentplan_preview->SortField == $loanpaymentplan_preview->outsandinginterest->Name && $loanpaymentplan_preview->SortOrder == "ASC" ? "DESC" : "ASC" ?>">
			<div class="ew-table-header-btn"><span class="ew-table-header-caption"><?php echo $loanpaymentplan_preview->outsandinginterest->caption() ?></span><span class="ew-table-header-sort"><?php if ($loanpaymentplan_preview->SortField == $loanpaymentplan_preview->outsandinginterest->Name) { ?><?php if ($loanpaymentplan_preview->SortOrder == "ASC") { ?><i class="fas fa-sort-up"></i><?php } elseif ($loanpaymentplan_preview->SortOrder == "DESC") { ?><i class="fas fa-sort-down"></i><?php } ?><?php } ?></span>
		</div></div></th>
	<?php } ?>
<?php } ?>
<?php if ($loanpaymentplan_preview->paymentprincipal->Visible) { // paymentprincipal ?>
	<?php if ($loanpaymentplan->SortUrl($loanpaymentplan_preview->paymentprincipal) == "") { ?>
		<th class="<?php echo $loanpaymentplan_preview->paymentprincipal->headerCellClass() ?>"><?php echo $loanpaymentplan_preview->paymentprincipal->caption() ?></th>
	<?php } else { ?>
		<th class="<?php echo $loanpaymentplan_preview->paymentprincipal->headerCellClass() ?>"><div class="ew-pointer" data-sort="<?php echo HtmlEncode($loanpaymentplan_preview->paymentprincipal->Name) ?>" data-sort-order="<?php echo $loanpaymentplan_preview->SortField == $loanpaymentplan_preview->paymentprincipal->Name && $loanpaymentplan_preview->SortOrder == "ASC" ? "DESC" : "ASC" ?>">
			<div class="ew-table-header-btn"><span class="ew-table-header-caption"><?php echo $loanpaymentplan_preview->paymentprincipal->caption() ?></span><span class="ew-table-header-sort"><?php if ($loanpaymentplan_preview->SortField == $loanpaymentplan_preview->paymentprincipal->Name) { ?><?php if ($loanpaymentplan_preview->SortOrder == "ASC") { ?><i class="fas fa-sort-up"></i><?php } elseif ($loanpaymentplan_preview->SortOrder == "DESC") { ?><i class="fas fa-sort-down"></i><?php } ?><?php } ?></span>
		</div></div></th>
	<?php } ?>
<?php } ?>
<?php if ($loanpaymentplan_preview->paymentinterest->Visible) { // paymentinterest ?>
	<?php if ($loanpaymentplan->SortUrl($loanpaymentplan_preview->paymentinterest) == "") { ?>
		<th class="<?php echo $loanpaymentplan_preview->paymentinterest->headerCellClass() ?>"><?php echo $loanpaymentplan_preview->paymentinterest->caption() ?></th>
	<?php } else { ?>
		<th class="<?php echo $loanpaymentplan_preview->paymentinterest->headerCellClass() ?>"><div class="ew-pointer" data-sort="<?php echo HtmlEncode($loanpaymentplan_preview->paymentinterest->Name) ?>" data-sort-order="<?php echo $loanpaymentplan_preview->SortField == $loanpaymentplan_preview->paymentinterest->Name && $loanpaymentplan_preview->SortOrder == "ASC" ? "DESC" : "ASC" ?>">
			<div class="ew-table-header-btn"><span class="ew-table-header-caption"><?php echo $loanpaymentplan_preview->paymentinterest->caption() ?></span><span class="ew-table-header-sort"><?php if ($loanpaymentplan_preview->SortField == $loanpaymentplan_preview->paymentinterest->Name) { ?><?php if ($loanpaymentplan_preview->SortOrder == "ASC") { ?><i class="fas fa-sort-up"></i><?php } elseif ($loanpaymentplan_preview->SortOrder == "DESC") { ?><i class="fas fa-sort-down"></i><?php } ?><?php } ?></span>
		</div></div></th>
	<?php } ?>
<?php } ?>
<?php if ($loanpaymentplan_preview->paidprincipal->Visible) { // paidprincipal ?>
	<?php if ($loanpaymentplan->SortUrl($loanpaymentplan_preview->paidprincipal) == "") { ?>
		<th class="<?php echo $loanpaymentplan_preview->paidprincipal->headerCellClass() ?>"><?php echo $loanpaymentplan_preview->paidprincipal->caption() ?></th>
	<?php } else { ?>
		<th class="<?php echo $loanpaymentplan_preview->paidprincipal->headerCellClass() ?>"><div class="ew-pointer" data-sort="<?php echo HtmlEncode($loanpaymentplan_preview->paidprincipal->Name) ?>" data-sort-order="<?php echo $loanpaymentplan_preview->SortField == $loanpaymentplan_preview->paidprincipal->Name && $loanpaymentplan_preview->SortOrder == "ASC" ? "DESC" : "ASC" ?>">
			<div class="ew-table-header-btn"><span class="ew-table-header-caption"><?php echo $loanpaymentplan_preview->paidprincipal->caption() ?></span><span class="ew-table-header-sort"><?php if ($loanpaymentplan_preview->SortField == $loanpaymentplan_preview->paidprincipal->Name) { ?><?php if ($loanpaymentplan_preview->SortOrder == "ASC") { ?><i class="fas fa-sort-up"></i><?php } elseif ($loanpaymentplan_preview->SortOrder == "DESC") { ?><i class="fas fa-sort-down"></i><?php } ?><?php } ?></span>
		</div></div></th>
	<?php } ?>
<?php } ?>
<?php if ($loanpaymentplan_preview->paidinterest->Visible) { // paidinterest ?>
	<?php if ($loanpaymentplan->SortUrl($loanpaymentplan_preview->paidinterest) == "") { ?>
		<th class="<?php echo $loanpaymentplan_preview->paidinterest->headerCellClass() ?>"><?php echo $loanpaymentplan_preview->paidinterest->caption() ?></th>
	<?php } else { ?>
		<th class="<?php echo $loanpaymentplan_preview->paidinterest->headerCellClass() ?>"><div class="ew-pointer" data-sort="<?php echo HtmlEncode($loanpaymentplan_preview->paidinterest->Name) ?>" data-sort-order="<?php echo $loanpaymentplan_preview->SortField == $loanpaymentplan_preview->paidinterest->Name && $loanpaymentplan_preview->SortOrder == "ASC" ? "DESC" : "ASC" ?>">
			<div class="ew-table-header-btn"><span class="ew-table-header-caption"><?php echo $loanpaymentplan_preview->paidinterest->caption() ?></span><span class="ew-table-header-sort"><?php if ($loanpaymentplan_preview->SortField == $loanpaymentplan_preview->paidinterest->Name) { ?><?php if ($loanpaymentplan_preview->SortOrder == "ASC") { ?><i class="fas fa-sort-up"></i><?php } elseif ($loanpaymentplan_preview->SortOrder == "DESC") { ?><i class="fas fa-sort-down"></i><?php } ?><?php } ?></span>
		</div></div></th>
	<?php } ?>
<?php } ?>
<?php if ($loanpaymentplan_preview->status->Visible) { // status ?>
	<?php if ($loanpaymentplan->SortUrl($loanpaymentplan_preview->status) == "") { ?>
		<th class="<?php echo $loanpaymentplan_preview->status->headerCellClass() ?>"><?php echo $loanpaymentplan_preview->status->caption() ?></th>
	<?php } else { ?>
		<th class="<?php echo $loanpaymentplan_preview->status->headerCellClass() ?>"><div class="ew-pointer" data-sort="<?php echo HtmlEncode($loanpaymentplan_preview->status->Name) ?>" data-sort-order="<?php echo $loanpaymentplan_preview->SortField == $loanpaymentplan_preview->status->Name && $loanpaymentplan_preview->SortOrder == "ASC" ? "DESC" : "ASC" ?>">
			<div class="ew-table-header-btn"><span class="ew-table-header-caption"><?php echo $loanpaymentplan_preview->status->caption() ?></span><span class="ew-table-header-sort"><?php if ($loanpaymentplan_preview->SortField == $loanpaymentplan_preview->status->Name) { ?><?php if ($loanpaymentplan_preview->SortOrder == "ASC") { ?><i class="fas fa-sort-up"></i><?php } elseif ($loanpaymentplan_preview->SortOrder == "DESC") { ?><i class="fas fa-sort-down"></i><?php } ?><?php } ?></span>
		</div></div></th>
	<?php } ?>
<?php } ?>
<?php

// Render list options (header, right)
$loanpaymentplan_preview->ListOptions->render("header", "right");
?>
		</tr>
	</thead>
	<tbody><!-- Table body -->
<?php
$loanpaymentplan_preview->RecCount = 0;
$loanpaymentplan_preview->RowCount = 0;
while ($loanpaymentplan_preview->Recordset && !$loanpaymentplan_preview->Recordset->EOF) {

	// Init row class and style
	$loanpaymentplan_preview->RecCount++;
	$loanpaymentplan_preview->RowCount++;
	$loanpaymentplan_preview->CssStyle = "";
	$loanpaymentplan_preview->loadListRowValues($loanpaymentplan_preview->Recordset);

	// Render row
	$loanpaymentplan->RowType = ROWTYPE_PREVIEW; // Preview record
	$loanpaymentplan_preview->resetAttributes();
	$loanpaymentplan_preview->renderListRow();

	// Render list options
	$loanpaymentplan_preview->renderListOptions();
?>
	<tr <?php echo $loanpaymentplan->rowAttributes() ?>>
<?php

// Render list options (body, left)
$loanpaymentplan_preview->ListOptions->render("body", "left", $loanpaymentplan_preview->RowCount);
?>
<?php if ($loanpaymentplan_preview->paymentplanid->Visible) { // paymentplanid ?>
		<!-- paymentplanid -->
		<td<?php echo $loanpaymentplan_preview->paymentplanid->cellAttributes() ?>>
<span<?php echo $loanpaymentplan_preview->paymentplanid->viewAttributes() ?>><?php echo $loanpaymentplan_preview->paymentplanid->getViewValue() ?></span>
</td>
<?php } ?>
<?php if ($loanpaymentplan_preview->termno->Visible) { // termno ?>
		<!-- termno -->
		<td<?php echo $loanpaymentplan_preview->termno->cellAttributes() ?>>
<span<?php echo $loanpaymentplan_preview->termno->viewAttributes() ?>><?php echo $loanpaymentplan_preview->termno->getViewValue() ?></span>
</td>
<?php } ?>
<?php if ($loanpaymentplan_preview->paymentduedate->Visible) { // paymentduedate ?>
		<!-- paymentduedate -->
		<td<?php echo $loanpaymentplan_preview->paymentduedate->cellAttributes() ?>>
<span<?php echo $loanpaymentplan_preview->paymentduedate->viewAttributes() ?>><?php echo $loanpaymentplan_preview->paymentduedate->getViewValue() ?></span>
</td>
<?php } ?>
<?php if ($loanpaymentplan_preview->outstandingprincipal->Visible) { // outstandingprincipal ?>
		<!-- outstandingprincipal -->
		<td<?php echo $loanpaymentplan_preview->outstandingprincipal->cellAttributes() ?>>
<span<?php echo $loanpaymentplan_preview->outstandingprincipal->viewAttributes() ?>><?php echo $loanpaymentplan_preview->outstandingprincipal->getViewValue() ?></span>
</td>
<?php } ?>
<?php if ($loanpaymentplan_preview->outsandinginterest->Visible) { // outsandinginterest ?>
		<!-- outsandinginterest -->
		<td<?php echo $loanpaymentplan_preview->outsandinginterest->cellAttributes() ?>>
<span<?php echo $loanpaymentplan_preview->outsandinginterest->viewAttributes() ?>><?php echo $loanpaymentplan_preview->outsandinginterest->getViewValue() ?></span>
</td>
<?php } ?>
<?php if ($loanpaymentplan_preview->paymentprincipal->Visible) { // paymentprincipal ?>
		<!-- paymentprincipal -->
		<td<?php echo $loanpaymentplan_preview->paymentprincipal->cellAttributes() ?>>
<span<?php echo $loanpaymentplan_preview->paymentprincipal->viewAttributes() ?>><?php echo $loanpaymentplan_preview->paymentprincipal->getViewValue() ?></span>
</td>
<?php } ?>
<?php if ($loanpaymentplan_preview->paymentinterest->Visible) { // paymentinterest ?>
		<!-- paymentinterest -->
		<td<?php echo $loanpaymentplan_preview->paymentinterest->cellAttributes() ?>>
<span<?php echo $loanpaymentplan_preview->paymentinterest->viewAttributes() ?>><?php echo $loanpaymentplan_preview->paymentinterest->getViewValue() ?></span>
</td>
<?php } ?>
<?php if ($loanpaymentplan_preview->paidprincipal->Visible) { // paidprincipal ?>
		<!-- paidprincipal -->
		<td<?php echo $loanpaymentplan_preview->paidprincipal->cellAttributes() ?>>
<span<?php echo $loanpaymentplan_preview->paidprincipal->viewAttributes() ?>><?php echo $loanpaymentplan_preview->paidprincipal->getViewValue() ?></span>
</td>
<?php } ?>
<?php if ($loanpaymentplan_preview->paidinterest->Visible) { // paidinterest ?>
		<!-- paidinterest -->
		<td<?php echo $loanpaymentplan_preview->paidinterest->cellAttributes() ?>>
<span<?php echo $loanpaymentplan_preview->paidinterest->viewAttributes() ?>><?php echo $loanpaymentplan_preview->paidinterest->getViewValue() ?></span>
</td>
<?php } ?>
<?php if ($loanpaymentplan_preview->status->Visible) { // status ?>
		<!-- status -->
		<td<?php echo $loanpaymentplan_preview->status->cellAttributes() ?>>
<span<?php echo $loanpaymentplan_preview->status->viewAttributes() ?>><?php echo $loanpaymentplan_preview->status->getViewValue() ?></span>
</td>
<?php } ?>
<?php

// Render list options (body, right)
$loanpaymentplan_preview->ListOptions->render("body", "right", $loanpaymentplan_preview->RowCount);
?>
	</tr>
<?php
	$loanpaymentplan_preview->Recordset->MoveNext();
} // while
?>
	</tbody>
</table><!-- /.table -->
</div><!-- /.table-responsive -->
<div class="card-footer ew-grid-lower-panel ew-preview-lower-panel"><!-- .card-footer -->
<?php echo $loanpaymentplan_preview->Pager->render() ?>
<?php } else { // No record ?>
<div class="card no-border">
<div class="ew-detail-count"><?php echo $Language->phrase("NoRecord") ?></div>
<?php } ?>
<div class="ew-preview-other-options">
<?php
	foreach ($loanpaymentplan_preview->OtherOptions as $option)
		$option->render("body");
?>
</div>
<?php if ($loanpaymentplan_preview->TotalRecords > 0) { ?>
<div class="clearfix"></div>
</div><!-- /.card-footer -->
<?php } ?>
</div><!-- /.card -->
<?php
$loanpaymentplan_preview->showPageFooter();
if (Config("DEBUG"))
	echo GetDebugMessage();
?>
<?php
if ($loanpaymentplan_preview->Recordset)
	$loanpaymentplan_preview->Recordset->Close();

// Output
$content = ob_get_contents();
ob_end_clean();
echo ConvertToUtf8($content);
?>
<?php
$loanpaymentplan_preview->terminate();
?>