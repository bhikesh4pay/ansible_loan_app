<?php
namespace PHPMaker2020\_4payadmin;

// Autoload
include_once "autoload.php";

// Session
if (session_status() !== PHP_SESSION_ACTIVE)
	\Delight\Cookie\Session::start(Config("COOKIE_SAMESITE")); // Init session data

// Output buffering
ob_start();
?>
<?php

// Write header
WriteHeader(FALSE);

// Create page object
$loanpayments_search = new loanpayments_search();

// Run the page
$loanpayments_search->run();

// Setup login status
SetupLoginStatus();
SetClientVar("login", LoginStatus());

// Global Page Rendering event (in userfn*.php)
Page_Rendering();

// Page Rendering event
$loanpayments_search->Page_Render();
?>
<?php include_once "header.php"; ?>
<script>
var floanpaymentssearch, currentPageID;
loadjs.ready("head", function() {

	// Form object for search
	<?php if ($loanpayments_search->IsModal) { ?>
	floanpaymentssearch = currentAdvancedSearchForm = new ew.Form("floanpaymentssearch", "search");
	<?php } else { ?>
	floanpaymentssearch = currentForm = new ew.Form("floanpaymentssearch", "search");
	<?php } ?>
	currentPageID = ew.PAGE_ID = "search";

	// Validate function for search
	floanpaymentssearch.validate = function(fobj) {
		if (!this.validateRequired)
			return true; // Ignore validation
		fobj = fobj || this._form;
		var infix = "";
		elm = this.getElements("x" + infix + "_paymentid");
		if (elm && !ew.checkInteger(elm.value))
			return this.onError(elm, "<?php echo JsEncode($loanpayments_search->paymentid->errorMessage()) ?>");
		elm = this.getElements("x" + infix + "_paymentdate");
		if (elm && !ew.checkDateDef(elm.value))
			return this.onError(elm, "<?php echo JsEncode($loanpayments_search->paymentdate->errorMessage()) ?>");
		elm = this.getElements("x" + infix + "__userid");
		if (elm && !ew.checkInteger(elm.value))
			return this.onError(elm, "<?php echo JsEncode($loanpayments_search->_userid->errorMessage()) ?>");
		elm = this.getElements("x" + infix + "_paymentamount");
		if (elm && !ew.checkNumber(elm.value))
			return this.onError(elm, "<?php echo JsEncode($loanpayments_search->paymentamount->errorMessage()) ?>");
		elm = this.getElements("x" + infix + "_amountapplied");
		if (elm && !ew.checkNumber(elm.value))
			return this.onError(elm, "<?php echo JsEncode($loanpayments_search->amountapplied->errorMessage()) ?>");
		elm = this.getElements("x" + infix + "_residualamount");
		if (elm && !ew.checkNumber(elm.value))
			return this.onError(elm, "<?php echo JsEncode($loanpayments_search->residualamount->errorMessage()) ?>");
		elm = this.getElements("x" + infix + "_principleamountapplied");
		if (elm && !ew.checkNumber(elm.value))
			return this.onError(elm, "<?php echo JsEncode($loanpayments_search->principleamountapplied->errorMessage()) ?>");
		elm = this.getElements("x" + infix + "_feesamountapplied");
		if (elm && !ew.checkNumber(elm.value))
			return this.onError(elm, "<?php echo JsEncode($loanpayments_search->feesamountapplied->errorMessage()) ?>");
		elm = this.getElements("x" + infix + "_latefeesamountapplied");
		if (elm && !ew.checkNumber(elm.value))
			return this.onError(elm, "<?php echo JsEncode($loanpayments_search->latefeesamountapplied->errorMessage()) ?>");
		elm = this.getElements("x" + infix + "_loanid");
		if (elm && !ew.checkInteger(elm.value))
			return this.onError(elm, "<?php echo JsEncode($loanpayments_search->loanid->errorMessage()) ?>");
		elm = this.getElements("x" + infix + "_lastreconciledate");
		if (elm && !ew.checkDateDef(elm.value))
			return this.onError(elm, "<?php echo JsEncode($loanpayments_search->lastreconciledate->errorMessage()) ?>");

		// Call Form_CustomValidate event
		if (!this.Form_CustomValidate(fobj))
			return false;
		return true;
	}

	// Form_CustomValidate
	floanpaymentssearch.Form_CustomValidate = function(fobj) { // DO NOT CHANGE THIS LINE!

		// Your custom validation code here, return false if invalid.
		return true;
	}

	// Use JavaScript validation or not
	floanpaymentssearch.validateRequired = <?php echo Config("CLIENT_VALIDATE") ? "true" : "false" ?>;

	// Dynamic selection lists
	floanpaymentssearch.lists["x_currcode"] = <?php echo $loanpayments_search->currcode->Lookup->toClientList($loanpayments_search) ?>;
	floanpaymentssearch.lists["x_currcode"].options = <?php echo JsonEncode($loanpayments_search->currcode->lookupOptions()) ?>;
	floanpaymentssearch.lists["x_latefeesonly"] = <?php echo $loanpayments_search->latefeesonly->Lookup->toClientList($loanpayments_search) ?>;
	floanpaymentssearch.lists["x_latefeesonly"].options = <?php echo JsonEncode($loanpayments_search->latefeesonly->options(FALSE, TRUE)) ?>;
	floanpaymentssearch.lists["x_lockflag"] = <?php echo $loanpayments_search->lockflag->Lookup->toClientList($loanpayments_search) ?>;
	floanpaymentssearch.lists["x_lockflag"].options = <?php echo JsonEncode($loanpayments_search->lockflag->options(FALSE, TRUE)) ?>;
	loadjs.done("floanpaymentssearch");
});
</script>
<script>
loadjs.ready("head", function() {

	// Client script
	// Write your client script here, no need to add script tags.

});
</script>
<?php $loanpayments_search->showPageHeader(); ?>
<?php
$loanpayments_search->showMessage();
?>
<form name="floanpaymentssearch" id="floanpaymentssearch" class="<?php echo $loanpayments_search->FormClassName ?>" action="<?php echo CurrentPageName() ?>" method="post">
<?php if ($Page->CheckToken) { ?>
<input type="hidden" name="<?php echo Config("TOKEN_NAME") ?>" value="<?php echo $Page->Token ?>">
<?php } ?>
<input type="hidden" name="t" value="loanpayments">
<input type="hidden" name="action" id="action" value="search">
<input type="hidden" name="modal" value="<?php echo (int)$loanpayments_search->IsModal ?>">
<div class="ew-search-div"><!-- page* -->
<?php if ($loanpayments_search->paymentid->Visible) { // paymentid ?>
	<div id="r_paymentid" class="form-group row">
		<label for="x_paymentid" class="<?php echo $loanpayments_search->LeftColumnClass ?>"><span id="elh_loanpayments_paymentid"><?php echo $loanpayments_search->paymentid->caption() ?></span>
		<span class="ew-search-operator">
<?php echo $Language->phrase("=") ?>
<input type="hidden" name="z_paymentid" id="z_paymentid" value="=">
</span>
		</label>
		<div class="<?php echo $loanpayments_search->RightColumnClass ?>"><div <?php echo $loanpayments_search->paymentid->cellAttributes() ?>>
			<span id="el_loanpayments_paymentid" class="ew-search-field">
<input type="text" data-table="loanpayments" data-field="x_paymentid" name="x_paymentid" id="x_paymentid" placeholder="<?php echo HtmlEncode($loanpayments_search->paymentid->getPlaceHolder()) ?>" value="<?php echo $loanpayments_search->paymentid->EditValue ?>"<?php echo $loanpayments_search->paymentid->editAttributes() ?>>
</span>
		</div></div>
	</div>
<?php } ?>
<?php if ($loanpayments_search->paymentdate->Visible) { // paymentdate ?>
	<div id="r_paymentdate" class="form-group row">
		<label for="x_paymentdate" class="<?php echo $loanpayments_search->LeftColumnClass ?>"><span id="elh_loanpayments_paymentdate"><?php echo $loanpayments_search->paymentdate->caption() ?></span>
		<span class="ew-search-operator">
<?php echo $Language->phrase("=") ?>
<input type="hidden" name="z_paymentdate" id="z_paymentdate" value="=">
</span>
		</label>
		<div class="<?php echo $loanpayments_search->RightColumnClass ?>"><div <?php echo $loanpayments_search->paymentdate->cellAttributes() ?>>
			<span id="el_loanpayments_paymentdate" class="ew-search-field">
<input type="text" data-table="loanpayments" data-field="x_paymentdate" data-format="1" name="x_paymentdate" id="x_paymentdate" placeholder="<?php echo HtmlEncode($loanpayments_search->paymentdate->getPlaceHolder()) ?>" value="<?php echo $loanpayments_search->paymentdate->EditValue ?>"<?php echo $loanpayments_search->paymentdate->editAttributes() ?>>
<?php if (!$loanpayments_search->paymentdate->ReadOnly && !$loanpayments_search->paymentdate->Disabled && !isset($loanpayments_search->paymentdate->EditAttrs["readonly"]) && !isset($loanpayments_search->paymentdate->EditAttrs["disabled"])) { ?>
<script>
loadjs.ready(["floanpaymentssearch", "datetimepicker"], function() {
	ew.createDateTimePicker("floanpaymentssearch", "x_paymentdate", {"ignoreReadonly":true,"useCurrent":false,"format":1});
});
</script>
<?php } ?>
</span>
		</div></div>
	</div>
<?php } ?>
<?php if ($loanpayments_search->_userid->Visible) { // userid ?>
	<div id="r__userid" class="form-group row">
		<label for="x__userid" class="<?php echo $loanpayments_search->LeftColumnClass ?>"><span id="elh_loanpayments__userid"><?php echo $loanpayments_search->_userid->caption() ?></span>
		<span class="ew-search-operator">
<?php echo $Language->phrase("=") ?>
<input type="hidden" name="z__userid" id="z__userid" value="=">
</span>
		</label>
		<div class="<?php echo $loanpayments_search->RightColumnClass ?>"><div <?php echo $loanpayments_search->_userid->cellAttributes() ?>>
			<span id="el_loanpayments__userid" class="ew-search-field">
<input type="text" data-table="loanpayments" data-field="x__userid" name="x__userid" id="x__userid" size="30" placeholder="<?php echo HtmlEncode($loanpayments_search->_userid->getPlaceHolder()) ?>" value="<?php echo $loanpayments_search->_userid->EditValue ?>"<?php echo $loanpayments_search->_userid->editAttributes() ?>>
</span>
		</div></div>
	</div>
<?php } ?>
<?php if ($loanpayments_search->currcode->Visible) { // currcode ?>
	<div id="r_currcode" class="form-group row">
		<label for="x_currcode" class="<?php echo $loanpayments_search->LeftColumnClass ?>"><span id="elh_loanpayments_currcode"><?php echo $loanpayments_search->currcode->caption() ?></span>
		<span class="ew-search-operator">
<?php echo $Language->phrase("LIKE") ?>
<input type="hidden" name="z_currcode" id="z_currcode" value="LIKE">
</span>
		</label>
		<div class="<?php echo $loanpayments_search->RightColumnClass ?>"><div <?php echo $loanpayments_search->currcode->cellAttributes() ?>>
			<span id="el_loanpayments_currcode" class="ew-search-field">
<div class="input-group">
	<select class="custom-select ew-custom-select" data-table="loanpayments" data-field="x_currcode" data-value-separator="<?php echo $loanpayments_search->currcode->displayValueSeparatorAttribute() ?>" id="x_currcode" name="x_currcode"<?php echo $loanpayments_search->currcode->editAttributes() ?>>
			<?php echo $loanpayments_search->currcode->selectOptionListHtml("x_currcode") ?>
		</select>
</div>
<?php echo $loanpayments_search->currcode->Lookup->getParamTag($loanpayments_search, "p_x_currcode") ?>
</span>
		</div></div>
	</div>
<?php } ?>
<?php if ($loanpayments_search->paymentamount->Visible) { // paymentamount ?>
	<div id="r_paymentamount" class="form-group row">
		<label for="x_paymentamount" class="<?php echo $loanpayments_search->LeftColumnClass ?>"><span id="elh_loanpayments_paymentamount"><?php echo $loanpayments_search->paymentamount->caption() ?></span>
		<span class="ew-search-operator">
<?php echo $Language->phrase("=") ?>
<input type="hidden" name="z_paymentamount" id="z_paymentamount" value="=">
</span>
		</label>
		<div class="<?php echo $loanpayments_search->RightColumnClass ?>"><div <?php echo $loanpayments_search->paymentamount->cellAttributes() ?>>
			<span id="el_loanpayments_paymentamount" class="ew-search-field">
<input type="text" data-table="loanpayments" data-field="x_paymentamount" name="x_paymentamount" id="x_paymentamount" size="30" placeholder="<?php echo HtmlEncode($loanpayments_search->paymentamount->getPlaceHolder()) ?>" value="<?php echo $loanpayments_search->paymentamount->EditValue ?>"<?php echo $loanpayments_search->paymentamount->editAttributes() ?>>
</span>
		</div></div>
	</div>
<?php } ?>
<?php if ($loanpayments_search->amountapplied->Visible) { // amountapplied ?>
	<div id="r_amountapplied" class="form-group row">
		<label for="x_amountapplied" class="<?php echo $loanpayments_search->LeftColumnClass ?>"><span id="elh_loanpayments_amountapplied"><?php echo $loanpayments_search->amountapplied->caption() ?></span>
		<span class="ew-search-operator">
<?php echo $Language->phrase("=") ?>
<input type="hidden" name="z_amountapplied" id="z_amountapplied" value="=">
</span>
		</label>
		<div class="<?php echo $loanpayments_search->RightColumnClass ?>"><div <?php echo $loanpayments_search->amountapplied->cellAttributes() ?>>
			<span id="el_loanpayments_amountapplied" class="ew-search-field">
<input type="text" data-table="loanpayments" data-field="x_amountapplied" name="x_amountapplied" id="x_amountapplied" size="30" placeholder="<?php echo HtmlEncode($loanpayments_search->amountapplied->getPlaceHolder()) ?>" value="<?php echo $loanpayments_search->amountapplied->EditValue ?>"<?php echo $loanpayments_search->amountapplied->editAttributes() ?>>
</span>
		</div></div>
	</div>
<?php } ?>
<?php if ($loanpayments_search->residualamount->Visible) { // residualamount ?>
	<div id="r_residualamount" class="form-group row">
		<label for="x_residualamount" class="<?php echo $loanpayments_search->LeftColumnClass ?>"><span id="elh_loanpayments_residualamount"><?php echo $loanpayments_search->residualamount->caption() ?></span>
		<span class="ew-search-operator">
<?php echo $Language->phrase("=") ?>
<input type="hidden" name="z_residualamount" id="z_residualamount" value="=">
</span>
		</label>
		<div class="<?php echo $loanpayments_search->RightColumnClass ?>"><div <?php echo $loanpayments_search->residualamount->cellAttributes() ?>>
			<span id="el_loanpayments_residualamount" class="ew-search-field">
<input type="text" data-table="loanpayments" data-field="x_residualamount" name="x_residualamount" id="x_residualamount" size="30" placeholder="<?php echo HtmlEncode($loanpayments_search->residualamount->getPlaceHolder()) ?>" value="<?php echo $loanpayments_search->residualamount->EditValue ?>"<?php echo $loanpayments_search->residualamount->editAttributes() ?>>
</span>
		</div></div>
	</div>
<?php } ?>
<?php if ($loanpayments_search->externalrefno->Visible) { // externalrefno ?>
	<div id="r_externalrefno" class="form-group row">
		<label for="x_externalrefno" class="<?php echo $loanpayments_search->LeftColumnClass ?>"><span id="elh_loanpayments_externalrefno"><?php echo $loanpayments_search->externalrefno->caption() ?></span>
		<span class="ew-search-operator">
<?php echo $Language->phrase("LIKE") ?>
<input type="hidden" name="z_externalrefno" id="z_externalrefno" value="LIKE">
</span>
		</label>
		<div class="<?php echo $loanpayments_search->RightColumnClass ?>"><div <?php echo $loanpayments_search->externalrefno->cellAttributes() ?>>
			<span id="el_loanpayments_externalrefno" class="ew-search-field">
<input type="text" data-table="loanpayments" data-field="x_externalrefno" name="x_externalrefno" id="x_externalrefno" size="30" maxlength="50" placeholder="<?php echo HtmlEncode($loanpayments_search->externalrefno->getPlaceHolder()) ?>" value="<?php echo $loanpayments_search->externalrefno->EditValue ?>"<?php echo $loanpayments_search->externalrefno->editAttributes() ?>>
</span>
		</div></div>
	</div>
<?php } ?>
<?php if ($loanpayments_search->principleamountapplied->Visible) { // principleamountapplied ?>
	<div id="r_principleamountapplied" class="form-group row">
		<label for="x_principleamountapplied" class="<?php echo $loanpayments_search->LeftColumnClass ?>"><span id="elh_loanpayments_principleamountapplied"><?php echo $loanpayments_search->principleamountapplied->caption() ?></span>
		<span class="ew-search-operator">
<?php echo $Language->phrase("=") ?>
<input type="hidden" name="z_principleamountapplied" id="z_principleamountapplied" value="=">
</span>
		</label>
		<div class="<?php echo $loanpayments_search->RightColumnClass ?>"><div <?php echo $loanpayments_search->principleamountapplied->cellAttributes() ?>>
			<span id="el_loanpayments_principleamountapplied" class="ew-search-field">
<input type="text" data-table="loanpayments" data-field="x_principleamountapplied" name="x_principleamountapplied" id="x_principleamountapplied" size="30" maxlength="15" placeholder="<?php echo HtmlEncode($loanpayments_search->principleamountapplied->getPlaceHolder()) ?>" value="<?php echo $loanpayments_search->principleamountapplied->EditValue ?>"<?php echo $loanpayments_search->principleamountapplied->editAttributes() ?>>
</span>
		</div></div>
	</div>
<?php } ?>
<?php if ($loanpayments_search->feesamountapplied->Visible) { // feesamountapplied ?>
	<div id="r_feesamountapplied" class="form-group row">
		<label for="x_feesamountapplied" class="<?php echo $loanpayments_search->LeftColumnClass ?>"><span id="elh_loanpayments_feesamountapplied"><?php echo $loanpayments_search->feesamountapplied->caption() ?></span>
		<span class="ew-search-operator">
<?php echo $Language->phrase("=") ?>
<input type="hidden" name="z_feesamountapplied" id="z_feesamountapplied" value="=">
</span>
		</label>
		<div class="<?php echo $loanpayments_search->RightColumnClass ?>"><div <?php echo $loanpayments_search->feesamountapplied->cellAttributes() ?>>
			<span id="el_loanpayments_feesamountapplied" class="ew-search-field">
<input type="text" data-table="loanpayments" data-field="x_feesamountapplied" name="x_feesamountapplied" id="x_feesamountapplied" size="30" maxlength="15" placeholder="<?php echo HtmlEncode($loanpayments_search->feesamountapplied->getPlaceHolder()) ?>" value="<?php echo $loanpayments_search->feesamountapplied->EditValue ?>"<?php echo $loanpayments_search->feesamountapplied->editAttributes() ?>>
</span>
		</div></div>
	</div>
<?php } ?>
<?php if ($loanpayments_search->latefeesamountapplied->Visible) { // latefeesamountapplied ?>
	<div id="r_latefeesamountapplied" class="form-group row">
		<label for="x_latefeesamountapplied" class="<?php echo $loanpayments_search->LeftColumnClass ?>"><span id="elh_loanpayments_latefeesamountapplied"><?php echo $loanpayments_search->latefeesamountapplied->caption() ?></span>
		<span class="ew-search-operator">
<?php echo $Language->phrase("=") ?>
<input type="hidden" name="z_latefeesamountapplied" id="z_latefeesamountapplied" value="=">
</span>
		</label>
		<div class="<?php echo $loanpayments_search->RightColumnClass ?>"><div <?php echo $loanpayments_search->latefeesamountapplied->cellAttributes() ?>>
			<span id="el_loanpayments_latefeesamountapplied" class="ew-search-field">
<input type="text" data-table="loanpayments" data-field="x_latefeesamountapplied" name="x_latefeesamountapplied" id="x_latefeesamountapplied" size="30" maxlength="15" placeholder="<?php echo HtmlEncode($loanpayments_search->latefeesamountapplied->getPlaceHolder()) ?>" value="<?php echo $loanpayments_search->latefeesamountapplied->EditValue ?>"<?php echo $loanpayments_search->latefeesamountapplied->editAttributes() ?>>
</span>
		</div></div>
	</div>
<?php } ?>
<?php if ($loanpayments_search->loanid->Visible) { // loanid ?>
	<div id="r_loanid" class="form-group row">
		<label for="x_loanid" class="<?php echo $loanpayments_search->LeftColumnClass ?>"><span id="elh_loanpayments_loanid"><?php echo $loanpayments_search->loanid->caption() ?></span>
		<span class="ew-search-operator">
<?php echo $Language->phrase("=") ?>
<input type="hidden" name="z_loanid" id="z_loanid" value="=">
</span>
		</label>
		<div class="<?php echo $loanpayments_search->RightColumnClass ?>"><div <?php echo $loanpayments_search->loanid->cellAttributes() ?>>
			<span id="el_loanpayments_loanid" class="ew-search-field">
<input type="text" data-table="loanpayments" data-field="x_loanid" name="x_loanid" id="x_loanid" size="30" maxlength="12" placeholder="<?php echo HtmlEncode($loanpayments_search->loanid->getPlaceHolder()) ?>" value="<?php echo $loanpayments_search->loanid->EditValue ?>"<?php echo $loanpayments_search->loanid->editAttributes() ?>>
</span>
		</div></div>
	</div>
<?php } ?>
<?php if ($loanpayments_search->latefeesonly->Visible) { // latefeesonly ?>
	<div id="r_latefeesonly" class="form-group row">
		<label for="x_latefeesonly" class="<?php echo $loanpayments_search->LeftColumnClass ?>"><span id="elh_loanpayments_latefeesonly"><?php echo $loanpayments_search->latefeesonly->caption() ?></span>
		<span class="ew-search-operator">
<?php echo $Language->phrase("=") ?>
<input type="hidden" name="z_latefeesonly" id="z_latefeesonly" value="=">
</span>
		</label>
		<div class="<?php echo $loanpayments_search->RightColumnClass ?>"><div <?php echo $loanpayments_search->latefeesonly->cellAttributes() ?>>
			<span id="el_loanpayments_latefeesonly" class="ew-search-field">
<div class="input-group">
	<select class="custom-select ew-custom-select" data-table="loanpayments" data-field="x_latefeesonly" data-value-separator="<?php echo $loanpayments_search->latefeesonly->displayValueSeparatorAttribute() ?>" id="x_latefeesonly" name="x_latefeesonly"<?php echo $loanpayments_search->latefeesonly->editAttributes() ?>>
			<?php echo $loanpayments_search->latefeesonly->selectOptionListHtml("x_latefeesonly") ?>
		</select>
</div>
</span>
		</div></div>
	</div>
<?php } ?>
<?php if ($loanpayments_search->lockflag->Visible) { // lockflag ?>
	<div id="r_lockflag" class="form-group row">
		<label class="<?php echo $loanpayments_search->LeftColumnClass ?>"><span id="elh_loanpayments_lockflag"><?php echo $loanpayments_search->lockflag->caption() ?></span>
		<span class="ew-search-operator">
<?php echo $Language->phrase("=") ?>
<input type="hidden" name="z_lockflag" id="z_lockflag" value="=">
</span>
		</label>
		<div class="<?php echo $loanpayments_search->RightColumnClass ?>"><div <?php echo $loanpayments_search->lockflag->cellAttributes() ?>>
			<span id="el_loanpayments_lockflag" class="ew-search-field">
<div id="tp_x_lockflag" class="ew-template"><input type="radio" class="custom-control-input" data-table="loanpayments" data-field="x_lockflag" data-value-separator="<?php echo $loanpayments_search->lockflag->displayValueSeparatorAttribute() ?>" name="x_lockflag" id="x_lockflag" value="{value}"<?php echo $loanpayments_search->lockflag->editAttributes() ?>></div>
<div id="dsl_x_lockflag" data-repeatcolumn="5" class="ew-item-list d-none"><div>
<?php echo $loanpayments_search->lockflag->radioButtonListHtml(FALSE, "x_lockflag") ?>
</div></div>
</span>
		</div></div>
	</div>
<?php } ?>
<?php if ($loanpayments_search->lastreconciledate->Visible) { // lastreconciledate ?>
	<div id="r_lastreconciledate" class="form-group row">
		<label for="x_lastreconciledate" class="<?php echo $loanpayments_search->LeftColumnClass ?>"><span id="elh_loanpayments_lastreconciledate"><?php echo $loanpayments_search->lastreconciledate->caption() ?></span>
		<span class="ew-search-operator">
<?php echo $Language->phrase("=") ?>
<input type="hidden" name="z_lastreconciledate" id="z_lastreconciledate" value="=">
</span>
		</label>
		<div class="<?php echo $loanpayments_search->RightColumnClass ?>"><div <?php echo $loanpayments_search->lastreconciledate->cellAttributes() ?>>
			<span id="el_loanpayments_lastreconciledate" class="ew-search-field">
<input type="text" data-table="loanpayments" data-field="x_lastreconciledate" name="x_lastreconciledate" id="x_lastreconciledate" maxlength="19" placeholder="<?php echo HtmlEncode($loanpayments_search->lastreconciledate->getPlaceHolder()) ?>" value="<?php echo $loanpayments_search->lastreconciledate->EditValue ?>"<?php echo $loanpayments_search->lastreconciledate->editAttributes() ?>>
<?php if (!$loanpayments_search->lastreconciledate->ReadOnly && !$loanpayments_search->lastreconciledate->Disabled && !isset($loanpayments_search->lastreconciledate->EditAttrs["readonly"]) && !isset($loanpayments_search->lastreconciledate->EditAttrs["disabled"])) { ?>
<script>
loadjs.ready(["floanpaymentssearch", "datetimepicker"], function() {
	ew.createDateTimePicker("floanpaymentssearch", "x_lastreconciledate", {"ignoreReadonly":true,"useCurrent":false,"format":0});
});
</script>
<?php } ?>
</span>
		</div></div>
	</div>
<?php } ?>
</div><!-- /page* -->
<?php if (!$loanpayments_search->IsModal) { ?>
<div class="form-group row"><!-- buttons .form-group -->
	<div class="<?php echo $loanpayments_search->OffsetColumnClass ?>"><!-- buttons offset -->
<button class="btn btn-primary ew-btn" name="btn-action" id="btn-action" type="submit"><?php echo $Language->phrase("Search") ?></button>
<button class="btn btn-default ew-btn" name="btn-reset" id="btn-reset" type="button" onclick="ew.clearForm(this.form);"><?php echo $Language->phrase("Reset") ?></button>
	</div><!-- /buttons offset -->
</div><!-- /buttons .form-group -->
<?php } ?>
</form>
<?php
$loanpayments_search->showPageFooter();
if (Config("DEBUG"))
	echo GetDebugMessage();
?>
<script>
loadjs.ready("load", function() {

	// Startup script
	// Write your table-specific startup script here
	// console.log("page loaded");

});
</script>
<?php include_once "footer.php"; ?>
<?php
$loanpayments_search->terminate();
?>