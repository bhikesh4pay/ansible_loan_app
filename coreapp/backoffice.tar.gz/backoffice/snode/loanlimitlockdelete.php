<?php
namespace PHPMaker2020\_4payadmin;

// Autoload
include_once "autoload.php";

// Session
if (session_status() !== PHP_SESSION_ACTIVE)
	\Delight\Cookie\Session::start(Config("COOKIE_SAMESITE")); // Init session data

// Output buffering
ob_start();
?>
<?php

// Write header
WriteHeader(FALSE);

// Create page object
$loanlimitlock_delete = new loanlimitlock_delete();

// Run the page
$loanlimitlock_delete->run();

// Setup login status
SetupLoginStatus();
SetClientVar("login", LoginStatus());

// Global Page Rendering event (in userfn*.php)
Page_Rendering();

// Page Rendering event
$loanlimitlock_delete->Page_Render();
?>
<?php include_once "header.php"; ?>
<script>
var floanlimitlockdelete, currentPageID;
loadjs.ready("head", function() {

	// Form object
	currentPageID = ew.PAGE_ID = "delete";
	floanlimitlockdelete = currentForm = new ew.Form("floanlimitlockdelete", "delete");
	loadjs.done("floanlimitlockdelete");
});
</script>
<script>
loadjs.ready("head", function() {

	// Client script
	// Write your client script here, no need to add script tags.

});
</script>
<?php $loanlimitlock_delete->showPageHeader(); ?>
<?php
$loanlimitlock_delete->showMessage();
?>
<form name="floanlimitlockdelete" id="floanlimitlockdelete" class="form-inline ew-form ew-delete-form" action="<?php echo CurrentPageName() ?>" method="post">
<?php if ($Page->CheckToken) { ?>
<input type="hidden" name="<?php echo Config("TOKEN_NAME") ?>" value="<?php echo $Page->Token ?>">
<?php } ?>
<input type="hidden" name="t" value="loanlimitlock">
<input type="hidden" name="action" id="action" value="delete">
<?php foreach ($loanlimitlock_delete->RecKeys as $key) { ?>
<?php $keyvalue = is_array($key) ? implode(Config("COMPOSITE_KEY_SEPARATOR"), $key) : $key; ?>
<input type="hidden" name="key_m[]" value="<?php echo HtmlEncode($keyvalue) ?>">
<?php } ?>
<div class="card ew-card ew-grid">
<div class="<?php echo ResponsiveTableClass() ?>card-body ew-grid-middle-panel">
<table class="table ew-table">
	<thead>
	<tr class="ew-table-header">
<?php if ($loanlimitlock_delete->_userid->Visible) { // userid ?>
		<th class="<?php echo $loanlimitlock_delete->_userid->headerCellClass() ?>"><span id="elh_loanlimitlock__userid" class="loanlimitlock__userid"><?php echo $loanlimitlock_delete->_userid->caption() ?></span></th>
<?php } ?>
<?php if ($loanlimitlock_delete->currency->Visible) { // currency ?>
		<th class="<?php echo $loanlimitlock_delete->currency->headerCellClass() ?>"><span id="elh_loanlimitlock_currency" class="loanlimitlock_currency"><?php echo $loanlimitlock_delete->currency->caption() ?></span></th>
<?php } ?>
<?php if ($loanlimitlock_delete->locktime->Visible) { // locktime ?>
		<th class="<?php echo $loanlimitlock_delete->locktime->headerCellClass() ?>"><span id="elh_loanlimitlock_locktime" class="loanlimitlock_locktime"><?php echo $loanlimitlock_delete->locktime->caption() ?></span></th>
<?php } ?>
	</tr>
	</thead>
	<tbody>
<?php
$loanlimitlock_delete->RecordCount = 0;
$i = 0;
while (!$loanlimitlock_delete->Recordset->EOF) {
	$loanlimitlock_delete->RecordCount++;
	$loanlimitlock_delete->RowCount++;

	// Set row properties
	$loanlimitlock->resetAttributes();
	$loanlimitlock->RowType = ROWTYPE_VIEW; // View

	// Get the field contents
	$loanlimitlock_delete->loadRowValues($loanlimitlock_delete->Recordset);

	// Render row
	$loanlimitlock_delete->renderRow();
?>
	<tr <?php echo $loanlimitlock->rowAttributes() ?>>
<?php if ($loanlimitlock_delete->_userid->Visible) { // userid ?>
		<td <?php echo $loanlimitlock_delete->_userid->cellAttributes() ?>>
<span id="el<?php echo $loanlimitlock_delete->RowCount ?>_loanlimitlock__userid" class="loanlimitlock__userid">
<span<?php echo $loanlimitlock_delete->_userid->viewAttributes() ?>><?php echo $loanlimitlock_delete->_userid->getViewValue() ?></span>
</span>
</td>
<?php } ?>
<?php if ($loanlimitlock_delete->currency->Visible) { // currency ?>
		<td <?php echo $loanlimitlock_delete->currency->cellAttributes() ?>>
<span id="el<?php echo $loanlimitlock_delete->RowCount ?>_loanlimitlock_currency" class="loanlimitlock_currency">
<span<?php echo $loanlimitlock_delete->currency->viewAttributes() ?>><?php echo $loanlimitlock_delete->currency->getViewValue() ?></span>
</span>
</td>
<?php } ?>
<?php if ($loanlimitlock_delete->locktime->Visible) { // locktime ?>
		<td <?php echo $loanlimitlock_delete->locktime->cellAttributes() ?>>
<span id="el<?php echo $loanlimitlock_delete->RowCount ?>_loanlimitlock_locktime" class="loanlimitlock_locktime">
<span<?php echo $loanlimitlock_delete->locktime->viewAttributes() ?>><?php echo $loanlimitlock_delete->locktime->getViewValue() ?></span>
</span>
</td>
<?php } ?>
	</tr>
<?php
	$loanlimitlock_delete->Recordset->moveNext();
}
$loanlimitlock_delete->Recordset->close();
?>
</tbody>
</table>
</div>
</div>
<div>
<button class="btn btn-primary ew-btn" name="btn-action" id="btn-action" type="submit"><?php echo $Language->phrase("DeleteBtn") ?></button>
<button class="btn btn-default ew-btn" name="btn-cancel" id="btn-cancel" type="button" data-href="<?php echo $loanlimitlock_delete->getReturnUrl() ?>"><?php echo $Language->phrase("CancelBtn") ?></button>
</div>
</form>
<?php
$loanlimitlock_delete->showPageFooter();
if (Config("DEBUG"))
	echo GetDebugMessage();
?>
<script>
loadjs.ready("load", function() {

	// Startup script
	// Write your table-specific startup script here
	// console.log("page loaded");

});
</script>
<?php include_once "footer.php"; ?>
<?php
$loanlimitlock_delete->terminate();
?>