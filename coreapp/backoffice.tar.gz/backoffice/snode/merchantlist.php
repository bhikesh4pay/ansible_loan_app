<?php
namespace PHPMaker2020\_4payadmin;

// Autoload
include_once "autoload.php";

// Session
if (session_status() !== PHP_SESSION_ACTIVE)
	\Delight\Cookie\Session::start(Config("COOKIE_SAMESITE")); // Init session data

// Output buffering
ob_start();
?>
<?php

// Write header
WriteHeader(FALSE);

// Create page object
$merchant_list = new merchant_list();

// Run the page
$merchant_list->run();

// Setup login status
SetupLoginStatus();
SetClientVar("login", LoginStatus());

// Global Page Rendering event (in userfn*.php)
Page_Rendering();

// Page Rendering event
$merchant_list->Page_Render();
?>
<?php include_once "header.php"; ?>
<?php if (!$merchant_list->isExport()) { ?>
<script>
var fmerchantlist, currentPageID;
loadjs.ready("head", function() {

	// Form object
	currentPageID = ew.PAGE_ID = "list";
	fmerchantlist = currentForm = new ew.Form("fmerchantlist", "list");
	fmerchantlist.formKeyCountName = '<?php echo $merchant_list->FormKeyCountName ?>';
	loadjs.done("fmerchantlist");
});
var fmerchantlistsrch;
loadjs.ready("head", function() {

	// Form object for search
	fmerchantlistsrch = currentSearchForm = new ew.Form("fmerchantlistsrch");

	// Dynamic selection lists
	// Filters

	fmerchantlistsrch.filterList = <?php echo $merchant_list->getFilterList() ?>;

	// Init search panel as collapsed
	fmerchantlistsrch.initSearchPanel = true;
	loadjs.done("fmerchantlistsrch");
});
</script>
<style type="text/css">
.ew-table-preview-row { /* main table preview row color */
	background-color: #FFFFFF; /* preview row color */
}
.ew-table-preview-row .ew-grid {
	display: table;
}
</style>
<div id="ew-preview" class="d-none"><!-- preview -->
	<div class="ew-nav-tabs"><!-- .ew-nav-tabs -->
		<ul class="nav nav-tabs"></ul>
		<div class="tab-content"><!-- .tab-content -->
			<div class="tab-pane fade active show"></div>
		</div><!-- /.tab-content -->
	</div><!-- /.ew-nav-tabs -->
</div><!-- /preview -->
<script>
loadjs.ready("head", function() {
	ew.PREVIEW_PLACEMENT = ew.CSS_FLIP ? "right" : "left";
	ew.PREVIEW_SINGLE_ROW = false;
	ew.PREVIEW_OVERLAY = false;
	loadjs("js/ewpreview.js", "preview");
});
</script>
<script>
loadjs.ready("head", function() {

	// Client script
	// Write your client script here, no need to add script tags.

});
</script>
<?php } ?>
<?php if (!$merchant_list->isExport()) { ?>
<div class="btn-toolbar ew-toolbar">
<?php if ($merchant_list->TotalRecords > 0 && $merchant_list->ExportOptions->visible()) { ?>
<?php $merchant_list->ExportOptions->render("body") ?>
<?php } ?>
<?php if ($merchant_list->ImportOptions->visible()) { ?>
<?php $merchant_list->ImportOptions->render("body") ?>
<?php } ?>
<?php if ($merchant_list->SearchOptions->visible()) { ?>
<?php $merchant_list->SearchOptions->render("body") ?>
<?php } ?>
<?php if ($merchant_list->FilterOptions->visible()) { ?>
<?php $merchant_list->FilterOptions->render("body") ?>
<?php } ?>
<div class="clearfix"></div>
</div>
<?php } ?>
<?php
$merchant_list->renderOtherOptions();
?>
<?php if ($Security->CanSearch()) { ?>
<?php if (!$merchant_list->isExport() && !$merchant->CurrentAction) { ?>
<form name="fmerchantlistsrch" id="fmerchantlistsrch" class="form-inline ew-form ew-ext-search-form" action="<?php echo CurrentPageName() ?>">
<div id="fmerchantlistsrch-search-panel" class="<?php echo $merchant_list->SearchPanelClass ?>">
<input type="hidden" name="cmd" value="search">
<input type="hidden" name="t" value="merchant">
	<div class="ew-extended-search">
<div id="xsr_<?php echo $merchant_list->SearchRowCount + 1 ?>" class="ew-row d-sm-flex">
	<div class="ew-quick-search input-group">
		<input type="text" name="<?php echo Config("TABLE_BASIC_SEARCH") ?>" id="<?php echo Config("TABLE_BASIC_SEARCH") ?>" class="form-control" value="<?php echo HtmlEncode($merchant_list->BasicSearch->getKeyword()) ?>" placeholder="<?php echo HtmlEncode($Language->phrase("Search")) ?>">
		<input type="hidden" name="<?php echo Config("TABLE_BASIC_SEARCH_TYPE") ?>" id="<?php echo Config("TABLE_BASIC_SEARCH_TYPE") ?>" value="<?php echo HtmlEncode($merchant_list->BasicSearch->getType()) ?>">
		<div class="input-group-append">
			<button class="btn btn-primary" name="btn-submit" id="btn-submit" type="submit"><?php echo $Language->phrase("SearchBtn") ?></button>
			<button type="button" data-toggle="dropdown" class="btn btn-primary dropdown-toggle dropdown-toggle-split" aria-haspopup="true" aria-expanded="false"><span id="searchtype"><?php echo $merchant_list->BasicSearch->getTypeNameShort() ?></span></button>
			<div class="dropdown-menu dropdown-menu-right">
				<a class="dropdown-item<?php if ($merchant_list->BasicSearch->getType() == "") { ?> active<?php } ?>" href="#" onclick="return ew.setSearchType(this);"><?php echo $Language->phrase("QuickSearchAuto") ?></a>
				<a class="dropdown-item<?php if ($merchant_list->BasicSearch->getType() == "=") { ?> active<?php } ?>" href="#" onclick="return ew.setSearchType(this, '=');"><?php echo $Language->phrase("QuickSearchExact") ?></a>
				<a class="dropdown-item<?php if ($merchant_list->BasicSearch->getType() == "AND") { ?> active<?php } ?>" href="#" onclick="return ew.setSearchType(this, 'AND');"><?php echo $Language->phrase("QuickSearchAll") ?></a>
				<a class="dropdown-item<?php if ($merchant_list->BasicSearch->getType() == "OR") { ?> active<?php } ?>" href="#" onclick="return ew.setSearchType(this, 'OR');"><?php echo $Language->phrase("QuickSearchAny") ?></a>
			</div>
		</div>
	</div>
</div>
	</div><!-- /.ew-extended-search -->
</div><!-- /.ew-search-panel -->
</form>
<?php } ?>
<?php } ?>
<?php $merchant_list->showPageHeader(); ?>
<?php
$merchant_list->showMessage();
?>
<?php if ($merchant_list->TotalRecords > 0 || $merchant->CurrentAction) { ?>
<div class="card ew-card ew-grid<?php if ($merchant_list->isAddOrEdit()) { ?> ew-grid-add-edit<?php } ?> merchant">
<form name="fmerchantlist" id="fmerchantlist" class="form-inline ew-form ew-list-form" action="<?php echo CurrentPageName() ?>" method="post">
<?php if ($Page->CheckToken) { ?>
<input type="hidden" name="<?php echo Config("TOKEN_NAME") ?>" value="<?php echo $Page->Token ?>">
<?php } ?>
<input type="hidden" name="t" value="merchant">
<div id="gmp_merchant" class="<?php echo ResponsiveTableClass() ?>card-body ew-grid-middle-panel">
<?php if ($merchant_list->TotalRecords > 0 || $merchant_list->isGridEdit()) { ?>
<table id="tbl_merchantlist" class="table ew-table"><!-- .ew-table -->
<thead>
	<tr class="ew-table-header">
<?php

// Header row
$merchant->RowType = ROWTYPE_HEADER;

// Render list options
$merchant_list->renderListOptions();

// Render list options (header, left)
$merchant_list->ListOptions->render("header", "left");
?>
<?php if ($merchant_list->_userid->Visible) { // userid ?>
	<?php if ($merchant_list->SortUrl($merchant_list->_userid) == "") { ?>
		<th data-name="_userid" class="<?php echo $merchant_list->_userid->headerCellClass() ?>"><div id="elh_merchant__userid" class="merchant__userid"><div class="ew-table-header-caption"><?php echo $merchant_list->_userid->caption() ?></div></div></th>
	<?php } else { ?>
		<th data-name="_userid" class="<?php echo $merchant_list->_userid->headerCellClass() ?>"><div class="ew-pointer" onclick="ew.sort(event, '<?php echo $merchant_list->SortUrl($merchant_list->_userid) ?>', 1);"><div id="elh_merchant__userid" class="merchant__userid">
			<div class="ew-table-header-btn"><span class="ew-table-header-caption"><?php echo $merchant_list->_userid->caption() ?><?php echo $Language->phrase("SrchLegend") ?></span><span class="ew-table-header-sort"><?php if ($merchant_list->_userid->getSort() == "ASC") { ?><i class="fas fa-sort-up"></i><?php } elseif ($merchant_list->_userid->getSort() == "DESC") { ?><i class="fas fa-sort-down"></i><?php } ?></span></div>
		</div></div></th>
	<?php } ?>
<?php } ?>
<?php if ($merchant_list->businessname->Visible) { // businessname ?>
	<?php if ($merchant_list->SortUrl($merchant_list->businessname) == "") { ?>
		<th data-name="businessname" class="<?php echo $merchant_list->businessname->headerCellClass() ?>"><div id="elh_merchant_businessname" class="merchant_businessname"><div class="ew-table-header-caption"><?php echo $merchant_list->businessname->caption() ?></div></div></th>
	<?php } else { ?>
		<th data-name="businessname" class="<?php echo $merchant_list->businessname->headerCellClass() ?>"><div class="ew-pointer" onclick="ew.sort(event, '<?php echo $merchant_list->SortUrl($merchant_list->businessname) ?>', 1);"><div id="elh_merchant_businessname" class="merchant_businessname">
			<div class="ew-table-header-btn"><span class="ew-table-header-caption"><?php echo $merchant_list->businessname->caption() ?><?php echo $Language->phrase("SrchLegend") ?></span><span class="ew-table-header-sort"><?php if ($merchant_list->businessname->getSort() == "ASC") { ?><i class="fas fa-sort-up"></i><?php } elseif ($merchant_list->businessname->getSort() == "DESC") { ?><i class="fas fa-sort-down"></i><?php } ?></span></div>
		</div></div></th>
	<?php } ?>
<?php } ?>
<?php if ($merchant_list->active->Visible) { // active ?>
	<?php if ($merchant_list->SortUrl($merchant_list->active) == "") { ?>
		<th data-name="active" class="<?php echo $merchant_list->active->headerCellClass() ?>"><div id="elh_merchant_active" class="merchant_active"><div class="ew-table-header-caption"><?php echo $merchant_list->active->caption() ?></div></div></th>
	<?php } else { ?>
		<th data-name="active" class="<?php echo $merchant_list->active->headerCellClass() ?>"><div class="ew-pointer" onclick="ew.sort(event, '<?php echo $merchant_list->SortUrl($merchant_list->active) ?>', 1);"><div id="elh_merchant_active" class="merchant_active">
			<div class="ew-table-header-btn"><span class="ew-table-header-caption"><?php echo $merchant_list->active->caption() ?></span><span class="ew-table-header-sort"><?php if ($merchant_list->active->getSort() == "ASC") { ?><i class="fas fa-sort-up"></i><?php } elseif ($merchant_list->active->getSort() == "DESC") { ?><i class="fas fa-sort-down"></i><?php } ?></span></div>
		</div></div></th>
	<?php } ?>
<?php } ?>
<?php if ($merchant_list->businessphoneno->Visible) { // businessphoneno ?>
	<?php if ($merchant_list->SortUrl($merchant_list->businessphoneno) == "") { ?>
		<th data-name="businessphoneno" class="<?php echo $merchant_list->businessphoneno->headerCellClass() ?>"><div id="elh_merchant_businessphoneno" class="merchant_businessphoneno"><div class="ew-table-header-caption"><?php echo $merchant_list->businessphoneno->caption() ?></div></div></th>
	<?php } else { ?>
		<th data-name="businessphoneno" class="<?php echo $merchant_list->businessphoneno->headerCellClass() ?>"><div class="ew-pointer" onclick="ew.sort(event, '<?php echo $merchant_list->SortUrl($merchant_list->businessphoneno) ?>', 1);"><div id="elh_merchant_businessphoneno" class="merchant_businessphoneno">
			<div class="ew-table-header-btn"><span class="ew-table-header-caption"><?php echo $merchant_list->businessphoneno->caption() ?><?php echo $Language->phrase("SrchLegend") ?></span><span class="ew-table-header-sort"><?php if ($merchant_list->businessphoneno->getSort() == "ASC") { ?><i class="fas fa-sort-up"></i><?php } elseif ($merchant_list->businessphoneno->getSort() == "DESC") { ?><i class="fas fa-sort-down"></i><?php } ?></span></div>
		</div></div></th>
	<?php } ?>
<?php } ?>
<?php if ($merchant_list->businesscity->Visible) { // businesscity ?>
	<?php if ($merchant_list->SortUrl($merchant_list->businesscity) == "") { ?>
		<th data-name="businesscity" class="<?php echo $merchant_list->businesscity->headerCellClass() ?>"><div id="elh_merchant_businesscity" class="merchant_businesscity"><div class="ew-table-header-caption"><?php echo $merchant_list->businesscity->caption() ?></div></div></th>
	<?php } else { ?>
		<th data-name="businesscity" class="<?php echo $merchant_list->businesscity->headerCellClass() ?>"><div class="ew-pointer" onclick="ew.sort(event, '<?php echo $merchant_list->SortUrl($merchant_list->businesscity) ?>', 1);"><div id="elh_merchant_businesscity" class="merchant_businesscity">
			<div class="ew-table-header-btn"><span class="ew-table-header-caption"><?php echo $merchant_list->businesscity->caption() ?><?php echo $Language->phrase("SrchLegend") ?></span><span class="ew-table-header-sort"><?php if ($merchant_list->businesscity->getSort() == "ASC") { ?><i class="fas fa-sort-up"></i><?php } elseif ($merchant_list->businesscity->getSort() == "DESC") { ?><i class="fas fa-sort-down"></i><?php } ?></span></div>
		</div></div></th>
	<?php } ?>
<?php } ?>
<?php if ($merchant_list->businesscountry->Visible) { // businesscountry ?>
	<?php if ($merchant_list->SortUrl($merchant_list->businesscountry) == "") { ?>
		<th data-name="businesscountry" class="<?php echo $merchant_list->businesscountry->headerCellClass() ?>"><div id="elh_merchant_businesscountry" class="merchant_businesscountry"><div class="ew-table-header-caption"><?php echo $merchant_list->businesscountry->caption() ?></div></div></th>
	<?php } else { ?>
		<th data-name="businesscountry" class="<?php echo $merchant_list->businesscountry->headerCellClass() ?>"><div class="ew-pointer" onclick="ew.sort(event, '<?php echo $merchant_list->SortUrl($merchant_list->businesscountry) ?>', 1);"><div id="elh_merchant_businesscountry" class="merchant_businesscountry">
			<div class="ew-table-header-btn"><span class="ew-table-header-caption"><?php echo $merchant_list->businesscountry->caption() ?></span><span class="ew-table-header-sort"><?php if ($merchant_list->businesscountry->getSort() == "ASC") { ?><i class="fas fa-sort-up"></i><?php } elseif ($merchant_list->businesscountry->getSort() == "DESC") { ?><i class="fas fa-sort-down"></i><?php } ?></span></div>
		</div></div></th>
	<?php } ?>
<?php } ?>
<?php if ($merchant_list->businessstate->Visible) { // businessstate ?>
	<?php if ($merchant_list->SortUrl($merchant_list->businessstate) == "") { ?>
		<th data-name="businessstate" class="<?php echo $merchant_list->businessstate->headerCellClass() ?>"><div id="elh_merchant_businessstate" class="merchant_businessstate"><div class="ew-table-header-caption"><?php echo $merchant_list->businessstate->caption() ?></div></div></th>
	<?php } else { ?>
		<th data-name="businessstate" class="<?php echo $merchant_list->businessstate->headerCellClass() ?>"><div class="ew-pointer" onclick="ew.sort(event, '<?php echo $merchant_list->SortUrl($merchant_list->businessstate) ?>', 1);"><div id="elh_merchant_businessstate" class="merchant_businessstate">
			<div class="ew-table-header-btn"><span class="ew-table-header-caption"><?php echo $merchant_list->businessstate->caption() ?></span><span class="ew-table-header-sort"><?php if ($merchant_list->businessstate->getSort() == "ASC") { ?><i class="fas fa-sort-up"></i><?php } elseif ($merchant_list->businessstate->getSort() == "DESC") { ?><i class="fas fa-sort-down"></i><?php } ?></span></div>
		</div></div></th>
	<?php } ?>
<?php } ?>
<?php

// Render list options (header, right)
$merchant_list->ListOptions->render("header", "right");
?>
	</tr>
</thead>
<tbody>
<?php
if ($merchant_list->ExportAll && $merchant_list->isExport()) {
	$merchant_list->StopRecord = $merchant_list->TotalRecords;
} else {

	// Set the last record to display
	if ($merchant_list->TotalRecords > $merchant_list->StartRecord + $merchant_list->DisplayRecords - 1)
		$merchant_list->StopRecord = $merchant_list->StartRecord + $merchant_list->DisplayRecords - 1;
	else
		$merchant_list->StopRecord = $merchant_list->TotalRecords;
}
$merchant_list->RecordCount = $merchant_list->StartRecord - 1;
if ($merchant_list->Recordset && !$merchant_list->Recordset->EOF) {
	$merchant_list->Recordset->moveFirst();
	$selectLimit = $merchant_list->UseSelectLimit;
	if (!$selectLimit && $merchant_list->StartRecord > 1)
		$merchant_list->Recordset->move($merchant_list->StartRecord - 1);
} elseif (!$merchant->AllowAddDeleteRow && $merchant_list->StopRecord == 0) {
	$merchant_list->StopRecord = $merchant->GridAddRowCount;
}

// Initialize aggregate
$merchant->RowType = ROWTYPE_AGGREGATEINIT;
$merchant->resetAttributes();
$merchant_list->renderRow();
while ($merchant_list->RecordCount < $merchant_list->StopRecord) {
	$merchant_list->RecordCount++;
	if ($merchant_list->RecordCount >= $merchant_list->StartRecord) {
		$merchant_list->RowCount++;

		// Set up key count
		$merchant_list->KeyCount = $merchant_list->RowIndex;

		// Init row class and style
		$merchant->resetAttributes();
		$merchant->CssClass = "";
		if ($merchant_list->isGridAdd()) {
		} else {
			$merchant_list->loadRowValues($merchant_list->Recordset); // Load row values
		}
		$merchant->RowType = ROWTYPE_VIEW; // Render view

		// Set up row id / data-rowindex
		$merchant->RowAttrs->merge(["data-rowindex" => $merchant_list->RowCount, "id" => "r" . $merchant_list->RowCount . "_merchant", "data-rowtype" => $merchant->RowType]);

		// Render row
		$merchant_list->renderRow();

		// Render list options
		$merchant_list->renderListOptions();
?>
	<tr <?php echo $merchant->rowAttributes() ?>>
<?php

// Render list options (body, left)
$merchant_list->ListOptions->render("body", "left", $merchant_list->RowCount);
?>
	<?php if ($merchant_list->_userid->Visible) { // userid ?>
		<td data-name="_userid" <?php echo $merchant_list->_userid->cellAttributes() ?>>
<span id="el<?php echo $merchant_list->RowCount ?>_merchant__userid">
<span<?php echo $merchant_list->_userid->viewAttributes() ?>><?php if (!EmptyString($merchant_list->_userid->getViewValue()) && $merchant_list->_userid->linkAttributes() != "") { ?>
<a<?php echo $merchant_list->_userid->linkAttributes() ?>><?php echo $merchant_list->_userid->getViewValue() ?></a>
<?php } else { ?>
<?php echo $merchant_list->_userid->getViewValue() ?>
<?php } ?></span>
</span>
</td>
	<?php } ?>
	<?php if ($merchant_list->businessname->Visible) { // businessname ?>
		<td data-name="businessname" <?php echo $merchant_list->businessname->cellAttributes() ?>>
<span id="el<?php echo $merchant_list->RowCount ?>_merchant_businessname">
<span<?php echo $merchant_list->businessname->viewAttributes() ?>><?php echo $merchant_list->businessname->getViewValue() ?></span>
</span>
</td>
	<?php } ?>
	<?php if ($merchant_list->active->Visible) { // active ?>
		<td data-name="active" <?php echo $merchant_list->active->cellAttributes() ?>>
<span id="el<?php echo $merchant_list->RowCount ?>_merchant_active">
<span<?php echo $merchant_list->active->viewAttributes() ?>><?php echo $merchant_list->active->getViewValue() ?></span>
</span>
</td>
	<?php } ?>
	<?php if ($merchant_list->businessphoneno->Visible) { // businessphoneno ?>
		<td data-name="businessphoneno" <?php echo $merchant_list->businessphoneno->cellAttributes() ?>>
<span id="el<?php echo $merchant_list->RowCount ?>_merchant_businessphoneno">
<span<?php echo $merchant_list->businessphoneno->viewAttributes() ?>><?php echo $merchant_list->businessphoneno->getViewValue() ?></span>
</span>
</td>
	<?php } ?>
	<?php if ($merchant_list->businesscity->Visible) { // businesscity ?>
		<td data-name="businesscity" <?php echo $merchant_list->businesscity->cellAttributes() ?>>
<span id="el<?php echo $merchant_list->RowCount ?>_merchant_businesscity">
<span<?php echo $merchant_list->businesscity->viewAttributes() ?>><?php echo $merchant_list->businesscity->getViewValue() ?></span>
</span>
</td>
	<?php } ?>
	<?php if ($merchant_list->businesscountry->Visible) { // businesscountry ?>
		<td data-name="businesscountry" <?php echo $merchant_list->businesscountry->cellAttributes() ?>>
<span id="el<?php echo $merchant_list->RowCount ?>_merchant_businesscountry">
<span<?php echo $merchant_list->businesscountry->viewAttributes() ?>><?php echo $merchant_list->businesscountry->getViewValue() ?></span>
</span>
</td>
	<?php } ?>
	<?php if ($merchant_list->businessstate->Visible) { // businessstate ?>
		<td data-name="businessstate" <?php echo $merchant_list->businessstate->cellAttributes() ?>>
<span id="el<?php echo $merchant_list->RowCount ?>_merchant_businessstate">
<span<?php echo $merchant_list->businessstate->viewAttributes() ?>><?php echo $merchant_list->businessstate->getViewValue() ?></span>
</span>
</td>
	<?php } ?>
<?php

// Render list options (body, right)
$merchant_list->ListOptions->render("body", "right", $merchant_list->RowCount);
?>
	</tr>
<?php
	}
	if (!$merchant_list->isGridAdd())
		$merchant_list->Recordset->moveNext();
}
?>
</tbody>
</table><!-- /.ew-table -->
<?php } ?>
</div><!-- /.ew-grid-middle-panel -->
<?php if (!$merchant->CurrentAction) { ?>
<input type="hidden" name="action" id="action" value="">
<?php } ?>
</form><!-- /.ew-list-form -->
<?php

// Close recordset
if ($merchant_list->Recordset)
	$merchant_list->Recordset->Close();
?>
<?php if (!$merchant_list->isExport()) { ?>
<div class="card-footer ew-grid-lower-panel">
<?php if (!$merchant_list->isGridAdd()) { ?>
<form name="ew-pager-form" class="form-inline ew-form ew-pager-form" action="<?php echo CurrentPageName() ?>">
<?php echo $merchant_list->Pager->render() ?>
</form>
<?php } ?>
<div class="ew-list-other-options">
<?php $merchant_list->OtherOptions->render("body", "bottom") ?>
</div>
<div class="clearfix"></div>
</div>
<?php } ?>
</div><!-- /.ew-grid -->
<?php } ?>
<?php if ($merchant_list->TotalRecords == 0 && !$merchant->CurrentAction) { // Show other options ?>
<div class="ew-list-other-options">
<?php $merchant_list->OtherOptions->render("body") ?>
</div>
<div class="clearfix"></div>
<?php } ?>
<?php
$merchant_list->showPageFooter();
if (Config("DEBUG"))
	echo GetDebugMessage();
?>
<?php if (!$merchant_list->isExport()) { ?>
<script>
loadjs.ready("load", function() {

	// Startup script
	// Write your table-specific startup script here
	// console.log("page loaded");

});
</script>
<?php } ?>
<?php include_once "footer.php"; ?>
<?php
$merchant_list->terminate();
?>