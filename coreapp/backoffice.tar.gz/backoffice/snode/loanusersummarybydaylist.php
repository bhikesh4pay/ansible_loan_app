<?php
namespace PHPMaker2020\_4payadmin;

// Autoload
include_once "autoload.php";

// Session
if (session_status() !== PHP_SESSION_ACTIVE)
	\Delight\Cookie\Session::start(Config("COOKIE_SAMESITE")); // Init session data

// Output buffering
ob_start();
?>
<?php

// Write header
WriteHeader(FALSE);

// Create page object
$loanusersummarybyday_list = new loanusersummarybyday_list();

// Run the page
$loanusersummarybyday_list->run();

// Setup login status
SetupLoginStatus();
SetClientVar("login", LoginStatus());

// Global Page Rendering event (in userfn*.php)
Page_Rendering();

// Page Rendering event
$loanusersummarybyday_list->Page_Render();
?>
<?php include_once "header.php"; ?>
<?php if (!$loanusersummarybyday_list->isExport()) { ?>
<script>
var floanusersummarybydaylist, currentPageID;
loadjs.ready("head", function() {

	// Form object
	currentPageID = ew.PAGE_ID = "list";
	floanusersummarybydaylist = currentForm = new ew.Form("floanusersummarybydaylist", "list");
	floanusersummarybydaylist.formKeyCountName = '<?php echo $loanusersummarybyday_list->FormKeyCountName ?>';
	loadjs.done("floanusersummarybydaylist");
});
var floanusersummarybydaylistsrch;
loadjs.ready("head", function() {

	// Form object for search
	floanusersummarybydaylistsrch = currentSearchForm = new ew.Form("floanusersummarybydaylistsrch");

	// Dynamic selection lists
	// Filters

	floanusersummarybydaylistsrch.filterList = <?php echo $loanusersummarybyday_list->getFilterList() ?>;
	loadjs.done("floanusersummarybydaylistsrch");
});
</script>
<style type="text/css">
.ew-table-preview-row { /* main table preview row color */
	background-color: #FFFFFF; /* preview row color */
}
.ew-table-preview-row .ew-grid {
	display: table;
}
</style>
<div id="ew-preview" class="d-none"><!-- preview -->
	<div class="ew-nav-tabs"><!-- .ew-nav-tabs -->
		<ul class="nav nav-tabs"></ul>
		<div class="tab-content"><!-- .tab-content -->
			<div class="tab-pane fade active show"></div>
		</div><!-- /.tab-content -->
	</div><!-- /.ew-nav-tabs -->
</div><!-- /preview -->
<script>
loadjs.ready("head", function() {
	ew.PREVIEW_PLACEMENT = ew.CSS_FLIP ? "right" : "left";
	ew.PREVIEW_SINGLE_ROW = false;
	ew.PREVIEW_OVERLAY = false;
	loadjs("js/ewpreview.js", "preview");
});
</script>
<script>
loadjs.ready("head", function() {

	// Client script
	// Write your client script here, no need to add script tags.

});
</script>
<?php } ?>
<?php if (!$loanusersummarybyday_list->isExport()) { ?>
<div class="btn-toolbar ew-toolbar">
<?php if ($loanusersummarybyday_list->TotalRecords > 0 && $loanusersummarybyday_list->ExportOptions->visible()) { ?>
<?php $loanusersummarybyday_list->ExportOptions->render("body") ?>
<?php } ?>
<?php if ($loanusersummarybyday_list->ImportOptions->visible()) { ?>
<?php $loanusersummarybyday_list->ImportOptions->render("body") ?>
<?php } ?>
<?php if ($loanusersummarybyday_list->SearchOptions->visible()) { ?>
<?php $loanusersummarybyday_list->SearchOptions->render("body") ?>
<?php } ?>
<?php if ($loanusersummarybyday_list->FilterOptions->visible()) { ?>
<?php $loanusersummarybyday_list->FilterOptions->render("body") ?>
<?php } ?>
<div class="clearfix"></div>
</div>
<?php } ?>
<?php if (!$loanusersummarybyday_list->isExport() || Config("EXPORT_MASTER_RECORD") && $loanusersummarybyday_list->isExport("print")) { ?>
<?php
if ($loanusersummarybyday_list->DbMasterFilter != "" && $loanusersummarybyday->getCurrentMasterTable() == "loanlimits") {
	if ($loanusersummarybyday_list->MasterRecordExists) {
		include_once "loanlimitsmaster.php";
	}
}
?>
<?php } ?>
<?php
$loanusersummarybyday_list->renderOtherOptions();
?>
<?php $loanusersummarybyday_list->showPageHeader(); ?>
<?php
$loanusersummarybyday_list->showMessage();
?>
<?php if ($loanusersummarybyday_list->TotalRecords > 0 || $loanusersummarybyday->CurrentAction) { ?>
<div class="card ew-card ew-grid<?php if ($loanusersummarybyday_list->isAddOrEdit()) { ?> ew-grid-add-edit<?php } ?> loanusersummarybyday">
<form name="floanusersummarybydaylist" id="floanusersummarybydaylist" class="form-inline ew-form ew-list-form" action="<?php echo CurrentPageName() ?>" method="post">
<?php if ($Page->CheckToken) { ?>
<input type="hidden" name="<?php echo Config("TOKEN_NAME") ?>" value="<?php echo $Page->Token ?>">
<?php } ?>
<input type="hidden" name="t" value="loanusersummarybyday">
<?php if ($loanusersummarybyday->getCurrentMasterTable() == "loanlimits" && $loanusersummarybyday->CurrentAction) { ?>
<input type="hidden" name="<?php echo Config("TABLE_SHOW_MASTER") ?>" value="loanlimits">
<input type="hidden" name="fk__userid" value="<?php echo HtmlEncode($loanusersummarybyday_list->_userid->getSessionValue()) ?>">
<input type="hidden" name="fk_currcode" value="<?php echo HtmlEncode($loanusersummarybyday_list->currcode->getSessionValue()) ?>">
<?php } ?>
<div id="gmp_loanusersummarybyday" class="<?php echo ResponsiveTableClass() ?>card-body ew-grid-middle-panel">
<?php if ($loanusersummarybyday_list->TotalRecords > 0 || $loanusersummarybyday_list->isGridEdit()) { ?>
<table id="tbl_loanusersummarybydaylist" class="table ew-table"><!-- .ew-table -->
<thead>
	<tr class="ew-table-header">
<?php

// Header row
$loanusersummarybyday->RowType = ROWTYPE_HEADER;

// Render list options
$loanusersummarybyday_list->renderListOptions();

// Render list options (header, left)
$loanusersummarybyday_list->ListOptions->render("header", "left");
?>
<?php if ($loanusersummarybyday_list->_userid->Visible) { // userid ?>
	<?php if ($loanusersummarybyday_list->SortUrl($loanusersummarybyday_list->_userid) == "") { ?>
		<th data-name="_userid" class="<?php echo $loanusersummarybyday_list->_userid->headerCellClass() ?>"><div id="elh_loanusersummarybyday__userid" class="loanusersummarybyday__userid"><div class="ew-table-header-caption"><?php echo $loanusersummarybyday_list->_userid->caption() ?></div></div></th>
	<?php } else { ?>
		<th data-name="_userid" class="<?php echo $loanusersummarybyday_list->_userid->headerCellClass() ?>"><div class="ew-pointer" onclick="ew.sort(event, '<?php echo $loanusersummarybyday_list->SortUrl($loanusersummarybyday_list->_userid) ?>', 1);"><div id="elh_loanusersummarybyday__userid" class="loanusersummarybyday__userid">
			<div class="ew-table-header-btn"><span class="ew-table-header-caption"><?php echo $loanusersummarybyday_list->_userid->caption() ?></span><span class="ew-table-header-sort"><?php if ($loanusersummarybyday_list->_userid->getSort() == "ASC") { ?><i class="fas fa-sort-up"></i><?php } elseif ($loanusersummarybyday_list->_userid->getSort() == "DESC") { ?><i class="fas fa-sort-down"></i><?php } ?></span></div>
		</div></div></th>
	<?php } ?>
<?php } ?>
<?php if ($loanusersummarybyday_list->currcode->Visible) { // currcode ?>
	<?php if ($loanusersummarybyday_list->SortUrl($loanusersummarybyday_list->currcode) == "") { ?>
		<th data-name="currcode" class="<?php echo $loanusersummarybyday_list->currcode->headerCellClass() ?>"><div id="elh_loanusersummarybyday_currcode" class="loanusersummarybyday_currcode"><div class="ew-table-header-caption"><?php echo $loanusersummarybyday_list->currcode->caption() ?></div></div></th>
	<?php } else { ?>
		<th data-name="currcode" class="<?php echo $loanusersummarybyday_list->currcode->headerCellClass() ?>"><div class="ew-pointer" onclick="ew.sort(event, '<?php echo $loanusersummarybyday_list->SortUrl($loanusersummarybyday_list->currcode) ?>', 1);"><div id="elh_loanusersummarybyday_currcode" class="loanusersummarybyday_currcode">
			<div class="ew-table-header-btn"><span class="ew-table-header-caption"><?php echo $loanusersummarybyday_list->currcode->caption() ?></span><span class="ew-table-header-sort"><?php if ($loanusersummarybyday_list->currcode->getSort() == "ASC") { ?><i class="fas fa-sort-up"></i><?php } elseif ($loanusersummarybyday_list->currcode->getSort() == "DESC") { ?><i class="fas fa-sort-down"></i><?php } ?></span></div>
		</div></div></th>
	<?php } ?>
<?php } ?>
<?php if ($loanusersummarybyday_list->loandate->Visible) { // loandate ?>
	<?php if ($loanusersummarybyday_list->SortUrl($loanusersummarybyday_list->loandate) == "") { ?>
		<th data-name="loandate" class="<?php echo $loanusersummarybyday_list->loandate->headerCellClass() ?>"><div id="elh_loanusersummarybyday_loandate" class="loanusersummarybyday_loandate"><div class="ew-table-header-caption"><?php echo $loanusersummarybyday_list->loandate->caption() ?></div></div></th>
	<?php } else { ?>
		<th data-name="loandate" class="<?php echo $loanusersummarybyday_list->loandate->headerCellClass() ?>"><div class="ew-pointer" onclick="ew.sort(event, '<?php echo $loanusersummarybyday_list->SortUrl($loanusersummarybyday_list->loandate) ?>', 1);"><div id="elh_loanusersummarybyday_loandate" class="loanusersummarybyday_loandate">
			<div class="ew-table-header-btn"><span class="ew-table-header-caption"><?php echo $loanusersummarybyday_list->loandate->caption() ?></span><span class="ew-table-header-sort"><?php if ($loanusersummarybyday_list->loandate->getSort() == "ASC") { ?><i class="fas fa-sort-up"></i><?php } elseif ($loanusersummarybyday_list->loandate->getSort() == "DESC") { ?><i class="fas fa-sort-down"></i><?php } ?></span></div>
		</div></div></th>
	<?php } ?>
<?php } ?>
<?php if ($loanusersummarybyday_list->amount->Visible) { // amount ?>
	<?php if ($loanusersummarybyday_list->SortUrl($loanusersummarybyday_list->amount) == "") { ?>
		<th data-name="amount" class="<?php echo $loanusersummarybyday_list->amount->headerCellClass() ?>"><div id="elh_loanusersummarybyday_amount" class="loanusersummarybyday_amount"><div class="ew-table-header-caption"><?php echo $loanusersummarybyday_list->amount->caption() ?></div></div></th>
	<?php } else { ?>
		<th data-name="amount" class="<?php echo $loanusersummarybyday_list->amount->headerCellClass() ?>"><div class="ew-pointer" onclick="ew.sort(event, '<?php echo $loanusersummarybyday_list->SortUrl($loanusersummarybyday_list->amount) ?>', 1);"><div id="elh_loanusersummarybyday_amount" class="loanusersummarybyday_amount">
			<div class="ew-table-header-btn"><span class="ew-table-header-caption"><?php echo $loanusersummarybyday_list->amount->caption() ?></span><span class="ew-table-header-sort"><?php if ($loanusersummarybyday_list->amount->getSort() == "ASC") { ?><i class="fas fa-sort-up"></i><?php } elseif ($loanusersummarybyday_list->amount->getSort() == "DESC") { ?><i class="fas fa-sort-down"></i><?php } ?></span></div>
		</div></div></th>
	<?php } ?>
<?php } ?>
<?php

// Render list options (header, right)
$loanusersummarybyday_list->ListOptions->render("header", "right");
?>
	</tr>
</thead>
<tbody>
<?php
if ($loanusersummarybyday_list->ExportAll && $loanusersummarybyday_list->isExport()) {
	$loanusersummarybyday_list->StopRecord = $loanusersummarybyday_list->TotalRecords;
} else {

	// Set the last record to display
	if ($loanusersummarybyday_list->TotalRecords > $loanusersummarybyday_list->StartRecord + $loanusersummarybyday_list->DisplayRecords - 1)
		$loanusersummarybyday_list->StopRecord = $loanusersummarybyday_list->StartRecord + $loanusersummarybyday_list->DisplayRecords - 1;
	else
		$loanusersummarybyday_list->StopRecord = $loanusersummarybyday_list->TotalRecords;
}
$loanusersummarybyday_list->RecordCount = $loanusersummarybyday_list->StartRecord - 1;
if ($loanusersummarybyday_list->Recordset && !$loanusersummarybyday_list->Recordset->EOF) {
	$loanusersummarybyday_list->Recordset->moveFirst();
	$selectLimit = $loanusersummarybyday_list->UseSelectLimit;
	if (!$selectLimit && $loanusersummarybyday_list->StartRecord > 1)
		$loanusersummarybyday_list->Recordset->move($loanusersummarybyday_list->StartRecord - 1);
} elseif (!$loanusersummarybyday->AllowAddDeleteRow && $loanusersummarybyday_list->StopRecord == 0) {
	$loanusersummarybyday_list->StopRecord = $loanusersummarybyday->GridAddRowCount;
}

// Initialize aggregate
$loanusersummarybyday->RowType = ROWTYPE_AGGREGATEINIT;
$loanusersummarybyday->resetAttributes();
$loanusersummarybyday_list->renderRow();
while ($loanusersummarybyday_list->RecordCount < $loanusersummarybyday_list->StopRecord) {
	$loanusersummarybyday_list->RecordCount++;
	if ($loanusersummarybyday_list->RecordCount >= $loanusersummarybyday_list->StartRecord) {
		$loanusersummarybyday_list->RowCount++;

		// Set up key count
		$loanusersummarybyday_list->KeyCount = $loanusersummarybyday_list->RowIndex;

		// Init row class and style
		$loanusersummarybyday->resetAttributes();
		$loanusersummarybyday->CssClass = "";
		if ($loanusersummarybyday_list->isGridAdd()) {
		} else {
			$loanusersummarybyday_list->loadRowValues($loanusersummarybyday_list->Recordset); // Load row values
		}
		$loanusersummarybyday->RowType = ROWTYPE_VIEW; // Render view

		// Set up row id / data-rowindex
		$loanusersummarybyday->RowAttrs->merge(["data-rowindex" => $loanusersummarybyday_list->RowCount, "id" => "r" . $loanusersummarybyday_list->RowCount . "_loanusersummarybyday", "data-rowtype" => $loanusersummarybyday->RowType]);

		// Render row
		$loanusersummarybyday_list->renderRow();

		// Render list options
		$loanusersummarybyday_list->renderListOptions();
?>
	<tr <?php echo $loanusersummarybyday->rowAttributes() ?>>
<?php

// Render list options (body, left)
$loanusersummarybyday_list->ListOptions->render("body", "left", $loanusersummarybyday_list->RowCount);
?>
	<?php if ($loanusersummarybyday_list->_userid->Visible) { // userid ?>
		<td data-name="_userid" <?php echo $loanusersummarybyday_list->_userid->cellAttributes() ?>>
<span id="el<?php echo $loanusersummarybyday_list->RowCount ?>_loanusersummarybyday__userid">
<span<?php echo $loanusersummarybyday_list->_userid->viewAttributes() ?>><?php echo $loanusersummarybyday_list->_userid->getViewValue() ?></span>
</span>
</td>
	<?php } ?>
	<?php if ($loanusersummarybyday_list->currcode->Visible) { // currcode ?>
		<td data-name="currcode" <?php echo $loanusersummarybyday_list->currcode->cellAttributes() ?>>
<span id="el<?php echo $loanusersummarybyday_list->RowCount ?>_loanusersummarybyday_currcode">
<span<?php echo $loanusersummarybyday_list->currcode->viewAttributes() ?>><?php echo $loanusersummarybyday_list->currcode->getViewValue() ?></span>
</span>
</td>
	<?php } ?>
	<?php if ($loanusersummarybyday_list->loandate->Visible) { // loandate ?>
		<td data-name="loandate" <?php echo $loanusersummarybyday_list->loandate->cellAttributes() ?>>
<span id="el<?php echo $loanusersummarybyday_list->RowCount ?>_loanusersummarybyday_loandate">
<span<?php echo $loanusersummarybyday_list->loandate->viewAttributes() ?>><?php echo $loanusersummarybyday_list->loandate->getViewValue() ?></span>
</span>
</td>
	<?php } ?>
	<?php if ($loanusersummarybyday_list->amount->Visible) { // amount ?>
		<td data-name="amount" <?php echo $loanusersummarybyday_list->amount->cellAttributes() ?>>
<span id="el<?php echo $loanusersummarybyday_list->RowCount ?>_loanusersummarybyday_amount">
<span<?php echo $loanusersummarybyday_list->amount->viewAttributes() ?>><?php echo $loanusersummarybyday_list->amount->getViewValue() ?></span>
</span>
</td>
	<?php } ?>
<?php

// Render list options (body, right)
$loanusersummarybyday_list->ListOptions->render("body", "right", $loanusersummarybyday_list->RowCount);
?>
	</tr>
<?php
	}
	if (!$loanusersummarybyday_list->isGridAdd())
		$loanusersummarybyday_list->Recordset->moveNext();
}
?>
</tbody>
</table><!-- /.ew-table -->
<?php } ?>
</div><!-- /.ew-grid-middle-panel -->
<?php if (!$loanusersummarybyday->CurrentAction) { ?>
<input type="hidden" name="action" id="action" value="">
<?php } ?>
</form><!-- /.ew-list-form -->
<?php

// Close recordset
if ($loanusersummarybyday_list->Recordset)
	$loanusersummarybyday_list->Recordset->Close();
?>
<?php if (!$loanusersummarybyday_list->isExport()) { ?>
<div class="card-footer ew-grid-lower-panel">
<?php if (!$loanusersummarybyday_list->isGridAdd()) { ?>
<form name="ew-pager-form" class="form-inline ew-form ew-pager-form" action="<?php echo CurrentPageName() ?>">
<?php echo $loanusersummarybyday_list->Pager->render() ?>
</form>
<?php } ?>
<div class="ew-list-other-options">
<?php $loanusersummarybyday_list->OtherOptions->render("body", "bottom") ?>
</div>
<div class="clearfix"></div>
</div>
<?php } ?>
</div><!-- /.ew-grid -->
<?php } ?>
<?php if ($loanusersummarybyday_list->TotalRecords == 0 && !$loanusersummarybyday->CurrentAction) { // Show other options ?>
<div class="ew-list-other-options">
<?php $loanusersummarybyday_list->OtherOptions->render("body") ?>
</div>
<div class="clearfix"></div>
<?php } ?>
<?php
$loanusersummarybyday_list->showPageFooter();
if (Config("DEBUG"))
	echo GetDebugMessage();
?>
<?php if (!$loanusersummarybyday_list->isExport()) { ?>
<script>
loadjs.ready("load", function() {

	// Startup script
	// Write your table-specific startup script here
	// console.log("page loaded");

});
</script>
<?php } ?>
<?php include_once "footer.php"; ?>
<?php
$loanusersummarybyday_list->terminate();
?>