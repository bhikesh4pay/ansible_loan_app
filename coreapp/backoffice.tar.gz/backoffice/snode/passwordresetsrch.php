<?php
namespace PHPMaker2020\_4payadmin;

// Autoload
include_once "autoload.php";

// Session
if (session_status() !== PHP_SESSION_ACTIVE)
	\Delight\Cookie\Session::start(Config("COOKIE_SAMESITE")); // Init session data

// Output buffering
ob_start();
?>
<?php

// Write header
WriteHeader(FALSE);

// Create page object
$passwordreset_search = new passwordreset_search();

// Run the page
$passwordreset_search->run();

// Setup login status
SetupLoginStatus();
SetClientVar("login", LoginStatus());

// Global Page Rendering event (in userfn*.php)
Page_Rendering();

// Page Rendering event
$passwordreset_search->Page_Render();
?>
<?php include_once "header.php"; ?>
<script>
var fpasswordresetsearch, currentPageID;
loadjs.ready("head", function() {

	// Form object for search
	<?php if ($passwordreset_search->IsModal) { ?>
	fpasswordresetsearch = currentAdvancedSearchForm = new ew.Form("fpasswordresetsearch", "search");
	<?php } else { ?>
	fpasswordresetsearch = currentForm = new ew.Form("fpasswordresetsearch", "search");
	<?php } ?>
	currentPageID = ew.PAGE_ID = "search";

	// Validate function for search
	fpasswordresetsearch.validate = function(fobj) {
		if (!this.validateRequired)
			return true; // Ignore validation
		fobj = fobj || this._form;
		var infix = "";
		elm = this.getElements("x" + infix + "_id");
		if (elm && !ew.checkInteger(elm.value))
			return this.onError(elm, "<?php echo JsEncode($passwordreset_search->id->errorMessage()) ?>");
		elm = this.getElements("x" + infix + "_creationtime");
		if (elm && !ew.checkDateDef(elm.value))
			return this.onError(elm, "<?php echo JsEncode($passwordreset_search->creationtime->errorMessage()) ?>");

		// Call Form_CustomValidate event
		if (!this.Form_CustomValidate(fobj))
			return false;
		return true;
	}

	// Form_CustomValidate
	fpasswordresetsearch.Form_CustomValidate = function(fobj) { // DO NOT CHANGE THIS LINE!

		// Your custom validation code here, return false if invalid.
		return true;
	}

	// Use JavaScript validation or not
	fpasswordresetsearch.validateRequired = <?php echo Config("CLIENT_VALIDATE") ? "true" : "false" ?>;

	// Dynamic selection lists
	loadjs.done("fpasswordresetsearch");
});
</script>
<script>
loadjs.ready("head", function() {

	// Client script
	// Write your client script here, no need to add script tags.

});
</script>
<?php $passwordreset_search->showPageHeader(); ?>
<?php
$passwordreset_search->showMessage();
?>
<form name="fpasswordresetsearch" id="fpasswordresetsearch" class="<?php echo $passwordreset_search->FormClassName ?>" action="<?php echo CurrentPageName() ?>" method="post">
<?php if ($Page->CheckToken) { ?>
<input type="hidden" name="<?php echo Config("TOKEN_NAME") ?>" value="<?php echo $Page->Token ?>">
<?php } ?>
<input type="hidden" name="t" value="passwordreset">
<input type="hidden" name="action" id="action" value="search">
<input type="hidden" name="modal" value="<?php echo (int)$passwordreset_search->IsModal ?>">
<div class="ew-search-div"><!-- page* -->
<?php if ($passwordreset_search->id->Visible) { // id ?>
	<div id="r_id" class="form-group row">
		<label for="x_id" class="<?php echo $passwordreset_search->LeftColumnClass ?>"><span id="elh_passwordreset_id"><?php echo $passwordreset_search->id->caption() ?></span>
		<span class="ew-search-operator">
<?php echo $Language->phrase("=") ?>
<input type="hidden" name="z_id" id="z_id" value="=">
</span>
		</label>
		<div class="<?php echo $passwordreset_search->RightColumnClass ?>"><div <?php echo $passwordreset_search->id->cellAttributes() ?>>
			<span id="el_passwordreset_id" class="ew-search-field">
<input type="text" data-table="passwordreset" data-field="x_id" name="x_id" id="x_id" size="30" placeholder="<?php echo HtmlEncode($passwordreset_search->id->getPlaceHolder()) ?>" value="<?php echo $passwordreset_search->id->EditValue ?>"<?php echo $passwordreset_search->id->editAttributes() ?>>
</span>
		</div></div>
	</div>
<?php } ?>
<?php if ($passwordreset_search->_token->Visible) { // token ?>
	<div id="r__token" class="form-group row">
		<label for="x__token" class="<?php echo $passwordreset_search->LeftColumnClass ?>"><span id="elh_passwordreset__token"><?php echo $passwordreset_search->_token->caption() ?></span>
		<span class="ew-search-operator">
<?php echo $Language->phrase("LIKE") ?>
<input type="hidden" name="z__token" id="z__token" value="LIKE">
</span>
		</label>
		<div class="<?php echo $passwordreset_search->RightColumnClass ?>"><div <?php echo $passwordreset_search->_token->cellAttributes() ?>>
			<span id="el_passwordreset__token" class="ew-search-field">
<input type="text" data-table="passwordreset" data-field="x__token" name="x__token" id="x__token" size="35" placeholder="<?php echo HtmlEncode($passwordreset_search->_token->getPlaceHolder()) ?>" value="<?php echo $passwordreset_search->_token->EditValue ?>"<?php echo $passwordreset_search->_token->editAttributes() ?>>
</span>
		</div></div>
	</div>
<?php } ?>
<?php if ($passwordreset_search->creationtime->Visible) { // creationtime ?>
	<div id="r_creationtime" class="form-group row">
		<label for="x_creationtime" class="<?php echo $passwordreset_search->LeftColumnClass ?>"><span id="elh_passwordreset_creationtime"><?php echo $passwordreset_search->creationtime->caption() ?></span>
		<span class="ew-search-operator">
<?php echo $Language->phrase("=") ?>
<input type="hidden" name="z_creationtime" id="z_creationtime" value="=">
</span>
		</label>
		<div class="<?php echo $passwordreset_search->RightColumnClass ?>"><div <?php echo $passwordreset_search->creationtime->cellAttributes() ?>>
			<span id="el_passwordreset_creationtime" class="ew-search-field">
<input type="text" data-table="passwordreset" data-field="x_creationtime" name="x_creationtime" id="x_creationtime" placeholder="<?php echo HtmlEncode($passwordreset_search->creationtime->getPlaceHolder()) ?>" value="<?php echo $passwordreset_search->creationtime->EditValue ?>"<?php echo $passwordreset_search->creationtime->editAttributes() ?>>
</span>
		</div></div>
	</div>
<?php } ?>
</div><!-- /page* -->
<?php if (!$passwordreset_search->IsModal) { ?>
<div class="form-group row"><!-- buttons .form-group -->
	<div class="<?php echo $passwordreset_search->OffsetColumnClass ?>"><!-- buttons offset -->
<button class="btn btn-primary ew-btn" name="btn-action" id="btn-action" type="submit"><?php echo $Language->phrase("Search") ?></button>
<button class="btn btn-default ew-btn" name="btn-reset" id="btn-reset" type="button" onclick="ew.clearForm(this.form);"><?php echo $Language->phrase("Reset") ?></button>
	</div><!-- /buttons offset -->
</div><!-- /buttons .form-group -->
<?php } ?>
</form>
<?php
$passwordreset_search->showPageFooter();
if (Config("DEBUG"))
	echo GetDebugMessage();
?>
<script>
loadjs.ready("load", function() {

	// Startup script
	// Write your table-specific startup script here
	// console.log("page loaded");

});
</script>
<?php include_once "footer.php"; ?>
<?php
$passwordreset_search->terminate();
?>