<?php
namespace PHPMaker2020\_4payadmin;

// Autoload
include_once "autoload.php";

// Session
if (session_status() !== PHP_SESSION_ACTIVE)
	\Delight\Cookie\Session::start(Config("COOKIE_SAMESITE")); // Init session data

// Output buffering
ob_start();
?>
<?php

// Write header
WriteHeader(FALSE);

// Create page object
$loanrequests_list = new loanrequests_list();

// Run the page
$loanrequests_list->run();

// Setup login status
SetupLoginStatus();
SetClientVar("login", LoginStatus());

// Global Page Rendering event (in userfn*.php)
Page_Rendering();

// Page Rendering event
$loanrequests_list->Page_Render();
?>
<?php include_once "header.php"; ?>
<?php if (!$loanrequests_list->isExport()) { ?>
<script>
var floanrequestslist, currentPageID;
loadjs.ready("head", function() {

	// Form object
	currentPageID = ew.PAGE_ID = "list";
	floanrequestslist = currentForm = new ew.Form("floanrequestslist", "list");
	floanrequestslist.formKeyCountName = '<?php echo $loanrequests_list->FormKeyCountName ?>';
	loadjs.done("floanrequestslist");
});
var floanrequestslistsrch;
loadjs.ready("head", function() {

	// Form object for search
	floanrequestslistsrch = currentSearchForm = new ew.Form("floanrequestslistsrch");

	// Dynamic selection lists
	// Filters

	floanrequestslistsrch.filterList = <?php echo $loanrequests_list->getFilterList() ?>;
	loadjs.done("floanrequestslistsrch");
});
</script>
<style type="text/css">
.ew-table-preview-row { /* main table preview row color */
	background-color: #FFFFFF; /* preview row color */
}
.ew-table-preview-row .ew-grid {
	display: table;
}
</style>
<div id="ew-preview" class="d-none"><!-- preview -->
	<div class="ew-nav-tabs"><!-- .ew-nav-tabs -->
		<ul class="nav nav-tabs"></ul>
		<div class="tab-content"><!-- .tab-content -->
			<div class="tab-pane fade active show"></div>
		</div><!-- /.tab-content -->
	</div><!-- /.ew-nav-tabs -->
</div><!-- /preview -->
<script>
loadjs.ready("head", function() {
	ew.PREVIEW_PLACEMENT = ew.CSS_FLIP ? "right" : "left";
	ew.PREVIEW_SINGLE_ROW = false;
	ew.PREVIEW_OVERLAY = false;
	loadjs("js/ewpreview.js", "preview");
});
</script>
<script>
loadjs.ready("head", function() {

	// Client script
	// Write your client script here, no need to add script tags.

});
</script>
<?php } ?>
<?php if (!$loanrequests_list->isExport()) { ?>
<div class="btn-toolbar ew-toolbar">
<?php if ($loanrequests_list->TotalRecords > 0 && $loanrequests_list->ExportOptions->visible()) { ?>
<?php $loanrequests_list->ExportOptions->render("body") ?>
<?php } ?>
<?php if ($loanrequests_list->ImportOptions->visible()) { ?>
<?php $loanrequests_list->ImportOptions->render("body") ?>
<?php } ?>
<?php if ($loanrequests_list->SearchOptions->visible()) { ?>
<?php $loanrequests_list->SearchOptions->render("body") ?>
<?php } ?>
<?php if ($loanrequests_list->FilterOptions->visible()) { ?>
<?php $loanrequests_list->FilterOptions->render("body") ?>
<?php } ?>
<div class="clearfix"></div>
</div>
<?php } ?>
<?php if (!$loanrequests_list->isExport() || Config("EXPORT_MASTER_RECORD") && $loanrequests_list->isExport("print")) { ?>
<?php
if ($loanrequests_list->DbMasterFilter != "" && $loanrequests->getCurrentMasterTable() == "loanlimits") {
	if ($loanrequests_list->MasterRecordExists) {
		include_once "loanlimitsmaster.php";
	}
}
?>
<?php } ?>
<?php
$loanrequests_list->renderOtherOptions();
?>
<?php $loanrequests_list->showPageHeader(); ?>
<?php
$loanrequests_list->showMessage();
?>
<?php if ($loanrequests_list->TotalRecords > 0 || $loanrequests->CurrentAction) { ?>
<div class="card ew-card ew-grid<?php if ($loanrequests_list->isAddOrEdit()) { ?> ew-grid-add-edit<?php } ?> loanrequests">
<form name="floanrequestslist" id="floanrequestslist" class="form-inline ew-form ew-list-form" action="<?php echo CurrentPageName() ?>" method="post">
<?php if ($Page->CheckToken) { ?>
<input type="hidden" name="<?php echo Config("TOKEN_NAME") ?>" value="<?php echo $Page->Token ?>">
<?php } ?>
<input type="hidden" name="t" value="loanrequests">
<?php if ($loanrequests->getCurrentMasterTable() == "loanlimits" && $loanrequests->CurrentAction) { ?>
<input type="hidden" name="<?php echo Config("TABLE_SHOW_MASTER") ?>" value="loanlimits">
<input type="hidden" name="fk__userid" value="<?php echo HtmlEncode($loanrequests_list->_userid->getSessionValue()) ?>">
<input type="hidden" name="fk_currcode" value="<?php echo HtmlEncode($loanrequests_list->currcode->getSessionValue()) ?>">
<?php } ?>
<div id="gmp_loanrequests" class="<?php echo ResponsiveTableClass() ?>card-body ew-grid-middle-panel">
<?php if ($loanrequests_list->TotalRecords > 0 || $loanrequests_list->isGridEdit()) { ?>
<table id="tbl_loanrequestslist" class="table ew-table"><!-- .ew-table -->
<thead>
	<tr class="ew-table-header">
<?php

// Header row
$loanrequests->RowType = ROWTYPE_HEADER;

// Render list options
$loanrequests_list->renderListOptions();

// Render list options (header, left)
$loanrequests_list->ListOptions->render("header", "left");
?>
<?php if ($loanrequests_list->requestid->Visible) { // requestid ?>
	<?php if ($loanrequests_list->SortUrl($loanrequests_list->requestid) == "") { ?>
		<th data-name="requestid" class="<?php echo $loanrequests_list->requestid->headerCellClass() ?>"><div id="elh_loanrequests_requestid" class="loanrequests_requestid"><div class="ew-table-header-caption"><?php echo $loanrequests_list->requestid->caption() ?></div></div></th>
	<?php } else { ?>
		<th data-name="requestid" class="<?php echo $loanrequests_list->requestid->headerCellClass() ?>"><div class="ew-pointer" onclick="ew.sort(event, '<?php echo $loanrequests_list->SortUrl($loanrequests_list->requestid) ?>', 1);"><div id="elh_loanrequests_requestid" class="loanrequests_requestid">
			<div class="ew-table-header-btn"><span class="ew-table-header-caption"><?php echo $loanrequests_list->requestid->caption() ?></span><span class="ew-table-header-sort"><?php if ($loanrequests_list->requestid->getSort() == "ASC") { ?><i class="fas fa-sort-up"></i><?php } elseif ($loanrequests_list->requestid->getSort() == "DESC") { ?><i class="fas fa-sort-down"></i><?php } ?></span></div>
		</div></div></th>
	<?php } ?>
<?php } ?>
<?php if ($loanrequests_list->requestdate->Visible) { // requestdate ?>
	<?php if ($loanrequests_list->SortUrl($loanrequests_list->requestdate) == "") { ?>
		<th data-name="requestdate" class="<?php echo $loanrequests_list->requestdate->headerCellClass() ?>"><div id="elh_loanrequests_requestdate" class="loanrequests_requestdate"><div class="ew-table-header-caption"><?php echo $loanrequests_list->requestdate->caption() ?></div></div></th>
	<?php } else { ?>
		<th data-name="requestdate" class="<?php echo $loanrequests_list->requestdate->headerCellClass() ?>"><div class="ew-pointer" onclick="ew.sort(event, '<?php echo $loanrequests_list->SortUrl($loanrequests_list->requestdate) ?>', 1);"><div id="elh_loanrequests_requestdate" class="loanrequests_requestdate">
			<div class="ew-table-header-btn"><span class="ew-table-header-caption"><?php echo $loanrequests_list->requestdate->caption() ?></span><span class="ew-table-header-sort"><?php if ($loanrequests_list->requestdate->getSort() == "ASC") { ?><i class="fas fa-sort-up"></i><?php } elseif ($loanrequests_list->requestdate->getSort() == "DESC") { ?><i class="fas fa-sort-down"></i><?php } ?></span></div>
		</div></div></th>
	<?php } ?>
<?php } ?>
<?php if ($loanrequests_list->_userid->Visible) { // userid ?>
	<?php if ($loanrequests_list->SortUrl($loanrequests_list->_userid) == "") { ?>
		<th data-name="_userid" class="<?php echo $loanrequests_list->_userid->headerCellClass() ?>"><div id="elh_loanrequests__userid" class="loanrequests__userid"><div class="ew-table-header-caption"><?php echo $loanrequests_list->_userid->caption() ?></div></div></th>
	<?php } else { ?>
		<th data-name="_userid" class="<?php echo $loanrequests_list->_userid->headerCellClass() ?>"><div class="ew-pointer" onclick="ew.sort(event, '<?php echo $loanrequests_list->SortUrl($loanrequests_list->_userid) ?>', 1);"><div id="elh_loanrequests__userid" class="loanrequests__userid">
			<div class="ew-table-header-btn"><span class="ew-table-header-caption"><?php echo $loanrequests_list->_userid->caption() ?></span><span class="ew-table-header-sort"><?php if ($loanrequests_list->_userid->getSort() == "ASC") { ?><i class="fas fa-sort-up"></i><?php } elseif ($loanrequests_list->_userid->getSort() == "DESC") { ?><i class="fas fa-sort-down"></i><?php } ?></span></div>
		</div></div></th>
	<?php } ?>
<?php } ?>
<?php if ($loanrequests_list->currcode->Visible) { // currcode ?>
	<?php if ($loanrequests_list->SortUrl($loanrequests_list->currcode) == "") { ?>
		<th data-name="currcode" class="<?php echo $loanrequests_list->currcode->headerCellClass() ?>"><div id="elh_loanrequests_currcode" class="loanrequests_currcode"><div class="ew-table-header-caption"><?php echo $loanrequests_list->currcode->caption() ?></div></div></th>
	<?php } else { ?>
		<th data-name="currcode" class="<?php echo $loanrequests_list->currcode->headerCellClass() ?>"><div class="ew-pointer" onclick="ew.sort(event, '<?php echo $loanrequests_list->SortUrl($loanrequests_list->currcode) ?>', 1);"><div id="elh_loanrequests_currcode" class="loanrequests_currcode">
			<div class="ew-table-header-btn"><span class="ew-table-header-caption"><?php echo $loanrequests_list->currcode->caption() ?></span><span class="ew-table-header-sort"><?php if ($loanrequests_list->currcode->getSort() == "ASC") { ?><i class="fas fa-sort-up"></i><?php } elseif ($loanrequests_list->currcode->getSort() == "DESC") { ?><i class="fas fa-sort-down"></i><?php } ?></span></div>
		</div></div></th>
	<?php } ?>
<?php } ?>
<?php if ($loanrequests_list->requestamount->Visible) { // requestamount ?>
	<?php if ($loanrequests_list->SortUrl($loanrequests_list->requestamount) == "") { ?>
		<th data-name="requestamount" class="<?php echo $loanrequests_list->requestamount->headerCellClass() ?>"><div id="elh_loanrequests_requestamount" class="loanrequests_requestamount"><div class="ew-table-header-caption"><?php echo $loanrequests_list->requestamount->caption() ?></div></div></th>
	<?php } else { ?>
		<th data-name="requestamount" class="<?php echo $loanrequests_list->requestamount->headerCellClass() ?>"><div class="ew-pointer" onclick="ew.sort(event, '<?php echo $loanrequests_list->SortUrl($loanrequests_list->requestamount) ?>', 1);"><div id="elh_loanrequests_requestamount" class="loanrequests_requestamount">
			<div class="ew-table-header-btn"><span class="ew-table-header-caption"><?php echo $loanrequests_list->requestamount->caption() ?></span><span class="ew-table-header-sort"><?php if ($loanrequests_list->requestamount->getSort() == "ASC") { ?><i class="fas fa-sort-up"></i><?php } elseif ($loanrequests_list->requestamount->getSort() == "DESC") { ?><i class="fas fa-sort-down"></i><?php } ?></span></div>
		</div></div></th>
	<?php } ?>
<?php } ?>
<?php if ($loanrequests_list->requestoruserid->Visible) { // requestoruserid ?>
	<?php if ($loanrequests_list->SortUrl($loanrequests_list->requestoruserid) == "") { ?>
		<th data-name="requestoruserid" class="<?php echo $loanrequests_list->requestoruserid->headerCellClass() ?>"><div id="elh_loanrequests_requestoruserid" class="loanrequests_requestoruserid"><div class="ew-table-header-caption"><?php echo $loanrequests_list->requestoruserid->caption() ?></div></div></th>
	<?php } else { ?>
		<th data-name="requestoruserid" class="<?php echo $loanrequests_list->requestoruserid->headerCellClass() ?>"><div class="ew-pointer" onclick="ew.sort(event, '<?php echo $loanrequests_list->SortUrl($loanrequests_list->requestoruserid) ?>', 1);"><div id="elh_loanrequests_requestoruserid" class="loanrequests_requestoruserid">
			<div class="ew-table-header-btn"><span class="ew-table-header-caption"><?php echo $loanrequests_list->requestoruserid->caption() ?></span><span class="ew-table-header-sort"><?php if ($loanrequests_list->requestoruserid->getSort() == "ASC") { ?><i class="fas fa-sort-up"></i><?php } elseif ($loanrequests_list->requestoruserid->getSort() == "DESC") { ?><i class="fas fa-sort-down"></i><?php } ?></span></div>
		</div></div></th>
	<?php } ?>
<?php } ?>
<?php if ($loanrequests_list->externalrefno->Visible) { // externalrefno ?>
	<?php if ($loanrequests_list->SortUrl($loanrequests_list->externalrefno) == "") { ?>
		<th data-name="externalrefno" class="<?php echo $loanrequests_list->externalrefno->headerCellClass() ?>"><div id="elh_loanrequests_externalrefno" class="loanrequests_externalrefno"><div class="ew-table-header-caption"><?php echo $loanrequests_list->externalrefno->caption() ?></div></div></th>
	<?php } else { ?>
		<th data-name="externalrefno" class="<?php echo $loanrequests_list->externalrefno->headerCellClass() ?>"><div class="ew-pointer" onclick="ew.sort(event, '<?php echo $loanrequests_list->SortUrl($loanrequests_list->externalrefno) ?>', 1);"><div id="elh_loanrequests_externalrefno" class="loanrequests_externalrefno">
			<div class="ew-table-header-btn"><span class="ew-table-header-caption"><?php echo $loanrequests_list->externalrefno->caption() ?></span><span class="ew-table-header-sort"><?php if ($loanrequests_list->externalrefno->getSort() == "ASC") { ?><i class="fas fa-sort-up"></i><?php } elseif ($loanrequests_list->externalrefno->getSort() == "DESC") { ?><i class="fas fa-sort-down"></i><?php } ?></span></div>
		</div></div></th>
	<?php } ?>
<?php } ?>
<?php if ($loanrequests_list->issued->Visible) { // issued ?>
	<?php if ($loanrequests_list->SortUrl($loanrequests_list->issued) == "") { ?>
		<th data-name="issued" class="<?php echo $loanrequests_list->issued->headerCellClass() ?>"><div id="elh_loanrequests_issued" class="loanrequests_issued"><div class="ew-table-header-caption"><?php echo $loanrequests_list->issued->caption() ?></div></div></th>
	<?php } else { ?>
		<th data-name="issued" class="<?php echo $loanrequests_list->issued->headerCellClass() ?>"><div class="ew-pointer" onclick="ew.sort(event, '<?php echo $loanrequests_list->SortUrl($loanrequests_list->issued) ?>', 1);"><div id="elh_loanrequests_issued" class="loanrequests_issued">
			<div class="ew-table-header-btn"><span class="ew-table-header-caption"><?php echo $loanrequests_list->issued->caption() ?></span><span class="ew-table-header-sort"><?php if ($loanrequests_list->issued->getSort() == "ASC") { ?><i class="fas fa-sort-up"></i><?php } elseif ($loanrequests_list->issued->getSort() == "DESC") { ?><i class="fas fa-sort-down"></i><?php } ?></span></div>
		</div></div></th>
	<?php } ?>
<?php } ?>
<?php if ($loanrequests_list->termtype->Visible) { // termtype ?>
	<?php if ($loanrequests_list->SortUrl($loanrequests_list->termtype) == "") { ?>
		<th data-name="termtype" class="<?php echo $loanrequests_list->termtype->headerCellClass() ?>"><div id="elh_loanrequests_termtype" class="loanrequests_termtype"><div class="ew-table-header-caption"><?php echo $loanrequests_list->termtype->caption() ?></div></div></th>
	<?php } else { ?>
		<th data-name="termtype" class="<?php echo $loanrequests_list->termtype->headerCellClass() ?>"><div class="ew-pointer" onclick="ew.sort(event, '<?php echo $loanrequests_list->SortUrl($loanrequests_list->termtype) ?>', 1);"><div id="elh_loanrequests_termtype" class="loanrequests_termtype">
			<div class="ew-table-header-btn"><span class="ew-table-header-caption"><?php echo $loanrequests_list->termtype->caption() ?></span><span class="ew-table-header-sort"><?php if ($loanrequests_list->termtype->getSort() == "ASC") { ?><i class="fas fa-sort-up"></i><?php } elseif ($loanrequests_list->termtype->getSort() == "DESC") { ?><i class="fas fa-sort-down"></i><?php } ?></span></div>
		</div></div></th>
	<?php } ?>
<?php } ?>
<?php

// Render list options (header, right)
$loanrequests_list->ListOptions->render("header", "right");
?>
	</tr>
</thead>
<tbody>
<?php
if ($loanrequests_list->ExportAll && $loanrequests_list->isExport()) {
	$loanrequests_list->StopRecord = $loanrequests_list->TotalRecords;
} else {

	// Set the last record to display
	if ($loanrequests_list->TotalRecords > $loanrequests_list->StartRecord + $loanrequests_list->DisplayRecords - 1)
		$loanrequests_list->StopRecord = $loanrequests_list->StartRecord + $loanrequests_list->DisplayRecords - 1;
	else
		$loanrequests_list->StopRecord = $loanrequests_list->TotalRecords;
}
$loanrequests_list->RecordCount = $loanrequests_list->StartRecord - 1;
if ($loanrequests_list->Recordset && !$loanrequests_list->Recordset->EOF) {
	$loanrequests_list->Recordset->moveFirst();
	$selectLimit = $loanrequests_list->UseSelectLimit;
	if (!$selectLimit && $loanrequests_list->StartRecord > 1)
		$loanrequests_list->Recordset->move($loanrequests_list->StartRecord - 1);
} elseif (!$loanrequests->AllowAddDeleteRow && $loanrequests_list->StopRecord == 0) {
	$loanrequests_list->StopRecord = $loanrequests->GridAddRowCount;
}

// Initialize aggregate
$loanrequests->RowType = ROWTYPE_AGGREGATEINIT;
$loanrequests->resetAttributes();
$loanrequests_list->renderRow();
while ($loanrequests_list->RecordCount < $loanrequests_list->StopRecord) {
	$loanrequests_list->RecordCount++;
	if ($loanrequests_list->RecordCount >= $loanrequests_list->StartRecord) {
		$loanrequests_list->RowCount++;

		// Set up key count
		$loanrequests_list->KeyCount = $loanrequests_list->RowIndex;

		// Init row class and style
		$loanrequests->resetAttributes();
		$loanrequests->CssClass = "";
		if ($loanrequests_list->isGridAdd()) {
		} else {
			$loanrequests_list->loadRowValues($loanrequests_list->Recordset); // Load row values
		}
		$loanrequests->RowType = ROWTYPE_VIEW; // Render view

		// Set up row id / data-rowindex
		$loanrequests->RowAttrs->merge(["data-rowindex" => $loanrequests_list->RowCount, "id" => "r" . $loanrequests_list->RowCount . "_loanrequests", "data-rowtype" => $loanrequests->RowType]);

		// Render row
		$loanrequests_list->renderRow();

		// Render list options
		$loanrequests_list->renderListOptions();
?>
	<tr <?php echo $loanrequests->rowAttributes() ?>>
<?php

// Render list options (body, left)
$loanrequests_list->ListOptions->render("body", "left", $loanrequests_list->RowCount);
?>
	<?php if ($loanrequests_list->requestid->Visible) { // requestid ?>
		<td data-name="requestid" <?php echo $loanrequests_list->requestid->cellAttributes() ?>>
<span id="el<?php echo $loanrequests_list->RowCount ?>_loanrequests_requestid">
<span<?php echo $loanrequests_list->requestid->viewAttributes() ?>><?php echo $loanrequests_list->requestid->getViewValue() ?></span>
</span>
</td>
	<?php } ?>
	<?php if ($loanrequests_list->requestdate->Visible) { // requestdate ?>
		<td data-name="requestdate" <?php echo $loanrequests_list->requestdate->cellAttributes() ?>>
<span id="el<?php echo $loanrequests_list->RowCount ?>_loanrequests_requestdate">
<span<?php echo $loanrequests_list->requestdate->viewAttributes() ?>><?php echo $loanrequests_list->requestdate->getViewValue() ?></span>
</span>
</td>
	<?php } ?>
	<?php if ($loanrequests_list->_userid->Visible) { // userid ?>
		<td data-name="_userid" <?php echo $loanrequests_list->_userid->cellAttributes() ?>>
<span id="el<?php echo $loanrequests_list->RowCount ?>_loanrequests__userid">
<span<?php echo $loanrequests_list->_userid->viewAttributes() ?>><?php if (!EmptyString($loanrequests_list->_userid->getViewValue()) && $loanrequests_list->_userid->linkAttributes() != "") { ?>
<a<?php echo $loanrequests_list->_userid->linkAttributes() ?>><?php echo $loanrequests_list->_userid->getViewValue() ?></a>
<?php } else { ?>
<?php echo $loanrequests_list->_userid->getViewValue() ?>
<?php } ?></span>
</span>
</td>
	<?php } ?>
	<?php if ($loanrequests_list->currcode->Visible) { // currcode ?>
		<td data-name="currcode" <?php echo $loanrequests_list->currcode->cellAttributes() ?>>
<span id="el<?php echo $loanrequests_list->RowCount ?>_loanrequests_currcode">
<span<?php echo $loanrequests_list->currcode->viewAttributes() ?>><?php echo $loanrequests_list->currcode->getViewValue() ?></span>
</span>
</td>
	<?php } ?>
	<?php if ($loanrequests_list->requestamount->Visible) { // requestamount ?>
		<td data-name="requestamount" <?php echo $loanrequests_list->requestamount->cellAttributes() ?>>
<span id="el<?php echo $loanrequests_list->RowCount ?>_loanrequests_requestamount">
<span<?php echo $loanrequests_list->requestamount->viewAttributes() ?>><?php echo $loanrequests_list->requestamount->getViewValue() ?></span>
</span>
</td>
	<?php } ?>
	<?php if ($loanrequests_list->requestoruserid->Visible) { // requestoruserid ?>
		<td data-name="requestoruserid" <?php echo $loanrequests_list->requestoruserid->cellAttributes() ?>>
<span id="el<?php echo $loanrequests_list->RowCount ?>_loanrequests_requestoruserid">
<span<?php echo $loanrequests_list->requestoruserid->viewAttributes() ?>><?php echo $loanrequests_list->requestoruserid->getViewValue() ?></span>
</span>
</td>
	<?php } ?>
	<?php if ($loanrequests_list->externalrefno->Visible) { // externalrefno ?>
		<td data-name="externalrefno" <?php echo $loanrequests_list->externalrefno->cellAttributes() ?>>
<span id="el<?php echo $loanrequests_list->RowCount ?>_loanrequests_externalrefno">
<span<?php echo $loanrequests_list->externalrefno->viewAttributes() ?>><?php echo $loanrequests_list->externalrefno->getViewValue() ?></span>
</span>
</td>
	<?php } ?>
	<?php if ($loanrequests_list->issued->Visible) { // issued ?>
		<td data-name="issued" <?php echo $loanrequests_list->issued->cellAttributes() ?>>
<span id="el<?php echo $loanrequests_list->RowCount ?>_loanrequests_issued">
<span<?php echo $loanrequests_list->issued->viewAttributes() ?>><?php echo $loanrequests_list->issued->getViewValue() ?></span>
</span>
</td>
	<?php } ?>
	<?php if ($loanrequests_list->termtype->Visible) { // termtype ?>
		<td data-name="termtype" <?php echo $loanrequests_list->termtype->cellAttributes() ?>>
<span id="el<?php echo $loanrequests_list->RowCount ?>_loanrequests_termtype">
<span<?php echo $loanrequests_list->termtype->viewAttributes() ?>><?php echo $loanrequests_list->termtype->getViewValue() ?></span>
</span>
</td>
	<?php } ?>
<?php

// Render list options (body, right)
$loanrequests_list->ListOptions->render("body", "right", $loanrequests_list->RowCount);
?>
	</tr>
<?php
	}
	if (!$loanrequests_list->isGridAdd())
		$loanrequests_list->Recordset->moveNext();
}
?>
</tbody>
</table><!-- /.ew-table -->
<?php } ?>
</div><!-- /.ew-grid-middle-panel -->
<?php if (!$loanrequests->CurrentAction) { ?>
<input type="hidden" name="action" id="action" value="">
<?php } ?>
</form><!-- /.ew-list-form -->
<?php

// Close recordset
if ($loanrequests_list->Recordset)
	$loanrequests_list->Recordset->Close();
?>
<?php if (!$loanrequests_list->isExport()) { ?>
<div class="card-footer ew-grid-lower-panel">
<?php if (!$loanrequests_list->isGridAdd()) { ?>
<form name="ew-pager-form" class="form-inline ew-form ew-pager-form" action="<?php echo CurrentPageName() ?>">
<?php echo $loanrequests_list->Pager->render() ?>
</form>
<?php } ?>
<div class="ew-list-other-options">
<?php $loanrequests_list->OtherOptions->render("body", "bottom") ?>
</div>
<div class="clearfix"></div>
</div>
<?php } ?>
</div><!-- /.ew-grid -->
<?php } ?>
<?php if ($loanrequests_list->TotalRecords == 0 && !$loanrequests->CurrentAction) { // Show other options ?>
<div class="ew-list-other-options">
<?php $loanrequests_list->OtherOptions->render("body") ?>
</div>
<div class="clearfix"></div>
<?php } ?>
<?php
$loanrequests_list->showPageFooter();
if (Config("DEBUG"))
	echo GetDebugMessage();
?>
<?php if (!$loanrequests_list->isExport()) { ?>
<script>
loadjs.ready("load", function() {

	// Startup script
	// Write your table-specific startup script here
	// console.log("page loaded");

});
</script>
<?php } ?>
<?php include_once "footer.php"; ?>
<?php
$loanrequests_list->terminate();
?>