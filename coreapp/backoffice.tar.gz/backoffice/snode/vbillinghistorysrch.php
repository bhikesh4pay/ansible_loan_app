<?php
namespace PHPMaker2020\_4payadmin;

// Autoload
include_once "autoload.php";

// Session
if (session_status() !== PHP_SESSION_ACTIVE)
	\Delight\Cookie\Session::start(Config("COOKIE_SAMESITE")); // Init session data

// Output buffering
ob_start();
?>
<?php

// Write header
WriteHeader(FALSE);

// Create page object
$vbillinghistory_search = new vbillinghistory_search();

// Run the page
$vbillinghistory_search->run();

// Setup login status
SetupLoginStatus();
SetClientVar("login", LoginStatus());

// Global Page Rendering event (in userfn*.php)
Page_Rendering();

// Page Rendering event
$vbillinghistory_search->Page_Render();
?>
<?php include_once "header.php"; ?>
<script>
var fvbillinghistorysearch, currentPageID;
loadjs.ready("head", function() {

	// Form object for search
	<?php if ($vbillinghistory_search->IsModal) { ?>
	fvbillinghistorysearch = currentAdvancedSearchForm = new ew.Form("fvbillinghistorysearch", "search");
	<?php } else { ?>
	fvbillinghistorysearch = currentForm = new ew.Form("fvbillinghistorysearch", "search");
	<?php } ?>
	currentPageID = ew.PAGE_ID = "search";

	// Validate function for search
	fvbillinghistorysearch.validate = function(fobj) {
		if (!this.validateRequired)
			return true; // Ignore validation
		fobj = fobj || this._form;
		var infix = "";
		elm = this.getElements("x" + infix + "_recid");
		if (elm && !ew.checkInteger(elm.value))
			return this.onError(elm, "<?php echo JsEncode($vbillinghistory_search->recid->errorMessage()) ?>");
		elm = this.getElements("x" + infix + "_brokerid");
		if (elm && !ew.checkInteger(elm.value))
			return this.onError(elm, "<?php echo JsEncode($vbillinghistory_search->brokerid->errorMessage()) ?>");
		elm = this.getElements("x" + infix + "_transdate");
		if (elm && !ew.checkDateDef(elm.value))
			return this.onError(elm, "<?php echo JsEncode($vbillinghistory_search->transdate->errorMessage()) ?>");
		elm = this.getElements("x" + infix + "_amount");
		if (elm && !ew.checkNumber(elm.value))
			return this.onError(elm, "<?php echo JsEncode($vbillinghistory_search->amount->errorMessage()) ?>");
		elm = this.getElements("x" + infix + "_balance");
		if (elm && !ew.checkNumber(elm.value))
			return this.onError(elm, "<?php echo JsEncode($vbillinghistory_search->balance->errorMessage()) ?>");
		elm = this.getElements("x" + infix + "__userid");
		if (elm && !ew.checkInteger(elm.value))
			return this.onError(elm, "<?php echo JsEncode($vbillinghistory_search->_userid->errorMessage()) ?>");
		elm = this.getElements("x" + infix + "_parentuserid");
		if (elm && !ew.checkInteger(elm.value))
			return this.onError(elm, "<?php echo JsEncode($vbillinghistory_search->parentuserid->errorMessage()) ?>");
		elm = this.getElements("x" + infix + "_feeid");
		if (elm && !ew.checkInteger(elm.value))
			return this.onError(elm, "<?php echo JsEncode($vbillinghistory_search->feeid->errorMessage()) ?>");
		elm = this.getElements("x" + infix + "__tabletype");
		if (elm && !ew.checkInteger(elm.value))
			return this.onError(elm, "<?php echo JsEncode($vbillinghistory_search->_tabletype->errorMessage()) ?>");
		elm = this.getElements("x" + infix + "_feemerchanttotal");
		if (elm && !ew.checkNumber(elm.value))
			return this.onError(elm, "<?php echo JsEncode($vbillinghistory_search->feemerchanttotal->errorMessage()) ?>");
		elm = this.getElements("x" + infix + "_feeconsumertotal");
		if (elm && !ew.checkNumber(elm.value))
			return this.onError(elm, "<?php echo JsEncode($vbillinghistory_search->feeconsumertotal->errorMessage()) ?>");
		elm = this.getElements("x" + infix + "_feesystemtotal");
		if (elm && !ew.checkNumber(elm.value))
			return this.onError(elm, "<?php echo JsEncode($vbillinghistory_search->feesystemtotal->errorMessage()) ?>");
		elm = this.getElements("x" + infix + "_feeexternaltotal");
		if (elm && !ew.checkNumber(elm.value))
			return this.onError(elm, "<?php echo JsEncode($vbillinghistory_search->feeexternaltotal->errorMessage()) ?>");
		elm = this.getElements("x" + infix + "_feefranchiseetotal");
		if (elm && !ew.checkNumber(elm.value))
			return this.onError(elm, "<?php echo JsEncode($vbillinghistory_search->feefranchiseetotal->errorMessage()) ?>");
		elm = this.getElements("x" + infix + "_feeresellertotal");
		if (elm && !ew.checkNumber(elm.value))
			return this.onError(elm, "<?php echo JsEncode($vbillinghistory_search->feeresellertotal->errorMessage()) ?>");
		elm = this.getElements("x" + infix + "_taxamount");
		if (elm && !ew.checkNumber(elm.value))
			return this.onError(elm, "<?php echo JsEncode($vbillinghistory_search->taxamount->errorMessage()) ?>");
		elm = this.getElements("x" + infix + "_totalamount");
		if (elm && !ew.checkNumber(elm.value))
			return this.onError(elm, "<?php echo JsEncode($vbillinghistory_search->totalamount->errorMessage()) ?>");
		elm = this.getElements("x" + infix + "_taxperc");
		if (elm && !ew.checkNumber(elm.value))
			return this.onError(elm, "<?php echo JsEncode($vbillinghistory_search->taxperc->errorMessage()) ?>");
		elm = this.getElements("x" + infix + "_purchaseid");
		if (elm && !ew.checkInteger(elm.value))
			return this.onError(elm, "<?php echo JsEncode($vbillinghistory_search->purchaseid->errorMessage()) ?>");
		elm = this.getElements("x" + infix + "_paymentid");
		if (elm && !ew.checkInteger(elm.value))
			return this.onError(elm, "<?php echo JsEncode($vbillinghistory_search->paymentid->errorMessage()) ?>");
		elm = this.getElements("x" + infix + "_transgroupid");
		if (elm && !ew.checkInteger(elm.value))
			return this.onError(elm, "<?php echo JsEncode($vbillinghistory_search->transgroupid->errorMessage()) ?>");

		// Call Form_CustomValidate event
		if (!this.Form_CustomValidate(fobj))
			return false;
		return true;
	}

	// Form_CustomValidate
	fvbillinghistorysearch.Form_CustomValidate = function(fobj) { // DO NOT CHANGE THIS LINE!

		// Your custom validation code here, return false if invalid.
		return true;
	}

	// Use JavaScript validation or not
	fvbillinghistorysearch.validateRequired = <?php echo Config("CLIENT_VALIDATE") ? "true" : "false" ?>;

	// Dynamic selection lists
	fvbillinghistorysearch.lists["x_brokeremail"] = <?php echo $vbillinghistory_search->brokeremail->Lookup->toClientList($vbillinghistory_search) ?>;
	fvbillinghistorysearch.lists["x_brokeremail"].options = <?php echo JsonEncode($vbillinghistory_search->brokeremail->lookupOptions()) ?>;
	fvbillinghistorysearch.autoSuggests["x_brokeremail"] = <?php echo json_encode(["data" => "ajax=autosuggest"]) ?>;
	fvbillinghistorysearch.lists["x_serviceid[]"] = <?php echo $vbillinghistory_search->serviceid->Lookup->toClientList($vbillinghistory_search) ?>;
	fvbillinghistorysearch.lists["x_serviceid[]"].options = <?php echo JsonEncode($vbillinghistory_search->serviceid->lookupOptions()) ?>;
	fvbillinghistorysearch.lists["x_success"] = <?php echo $vbillinghistory_search->success->Lookup->toClientList($vbillinghistory_search) ?>;
	fvbillinghistorysearch.lists["x_success"].options = <?php echo JsonEncode($vbillinghistory_search->success->options(FALSE, TRUE)) ?>;
	fvbillinghistorysearch.lists["x_paymenttype"] = <?php echo $vbillinghistory_search->paymenttype->Lookup->toClientList($vbillinghistory_search) ?>;
	fvbillinghistorysearch.lists["x_paymenttype"].options = <?php echo JsonEncode($vbillinghistory_search->paymenttype->options(FALSE, TRUE)) ?>;
	fvbillinghistorysearch.lists["x_department"] = <?php echo $vbillinghistory_search->department->Lookup->toClientList($vbillinghistory_search) ?>;
	fvbillinghistorysearch.lists["x_department"].options = <?php echo JsonEncode($vbillinghistory_search->department->lookupOptions()) ?>;
	loadjs.done("fvbillinghistorysearch");
});
</script>
<script>
loadjs.ready("head", function() {

	// Client script
	// Write your client script here, no need to add script tags.

});
</script>
<?php $vbillinghistory_search->showPageHeader(); ?>
<?php
$vbillinghistory_search->showMessage();
?>
<form name="fvbillinghistorysearch" id="fvbillinghistorysearch" class="<?php echo $vbillinghistory_search->FormClassName ?>" action="<?php echo CurrentPageName() ?>" method="post">
<?php if ($Page->CheckToken) { ?>
<input type="hidden" name="<?php echo Config("TOKEN_NAME") ?>" value="<?php echo $Page->Token ?>">
<?php } ?>
<input type="hidden" name="t" value="vbillinghistory">
<input type="hidden" name="action" id="action" value="search">
<input type="hidden" name="modal" value="<?php echo (int)$vbillinghistory_search->IsModal ?>">
<div class="ew-multi-page"><!-- multi-page -->
<div class="ew-nav-tabs" id="vbillinghistory_search"><!-- multi-page tabs -->
	<ul class="<?php echo $vbillinghistory_search->MultiPages->navStyle() ?>">
		<li class="nav-item"><a class="nav-link<?php echo $vbillinghistory_search->MultiPages->pageStyle(1) ?>" href="#tab_vbillinghistory1" data-toggle="tab"><?php echo $vbillinghistory->pageCaption(1) ?></a></li>
		<li class="nav-item"><a class="nav-link<?php echo $vbillinghistory_search->MultiPages->pageStyle(2) ?>" href="#tab_vbillinghistory2" data-toggle="tab"><?php echo $vbillinghistory->pageCaption(2) ?></a></li>
		<li class="nav-item"><a class="nav-link<?php echo $vbillinghistory_search->MultiPages->pageStyle(3) ?>" href="#tab_vbillinghistory3" data-toggle="tab"><?php echo $vbillinghistory->pageCaption(3) ?></a></li>
	</ul>
	<div class="tab-content"><!-- multi-page tabs .tab-content -->
		<div class="tab-pane<?php echo $vbillinghistory_search->MultiPages->pageStyle(1) ?>" id="tab_vbillinghistory1"><!-- multi-page .tab-pane -->
<div class="ew-search-div"><!-- page* -->
<?php if ($vbillinghistory_search->recid->Visible) { // recid ?>
	<div id="r_recid" class="form-group row">
		<label for="x_recid" class="<?php echo $vbillinghistory_search->LeftColumnClass ?>"><span id="elh_vbillinghistory_recid"><?php echo $vbillinghistory_search->recid->caption() ?></span>
		<span class="ew-search-operator">
<?php echo $Language->phrase("=") ?>
<input type="hidden" name="z_recid" id="z_recid" value="=">
</span>
		</label>
		<div class="<?php echo $vbillinghistory_search->RightColumnClass ?>"><div <?php echo $vbillinghistory_search->recid->cellAttributes() ?>>
			<span id="el_vbillinghistory_recid" class="ew-search-field">
<input type="text" data-table="vbillinghistory" data-field="x_recid" data-page="1" name="x_recid" id="x_recid" placeholder="<?php echo HtmlEncode($vbillinghistory_search->recid->getPlaceHolder()) ?>" value="<?php echo $vbillinghistory_search->recid->EditValue ?>"<?php echo $vbillinghistory_search->recid->editAttributes() ?>>
</span>
		</div></div>
	</div>
<?php } ?>
<?php if ($vbillinghistory_search->brokeremail->Visible) { // brokeremail ?>
	<div id="r_brokeremail" class="form-group row">
		<label class="<?php echo $vbillinghistory_search->LeftColumnClass ?>"><span id="elh_vbillinghistory_brokeremail"><?php echo $vbillinghistory_search->brokeremail->caption() ?></span>
		<span class="ew-search-operator">
<?php echo $Language->phrase("LIKE") ?>
<input type="hidden" name="z_brokeremail" id="z_brokeremail" value="LIKE">
</span>
		</label>
		<div class="<?php echo $vbillinghistory_search->RightColumnClass ?>"><div <?php echo $vbillinghistory_search->brokeremail->cellAttributes() ?>>
			<span id="el_vbillinghistory_brokeremail" class="ew-search-field">
<?php
$onchange = $vbillinghistory_search->brokeremail->EditAttrs->prepend("onchange", "");
$onchange = ($onchange) ? ' onchange="' . JsEncode($onchange) . '"' : '';
$vbillinghistory_search->brokeremail->EditAttrs["onchange"] = "";
?>
<span id="as_x_brokeremail">
	<input type="text" class="form-control" name="sv_x_brokeremail" id="sv_x_brokeremail" value="<?php echo RemoveHtml($vbillinghistory_search->brokeremail->EditValue) ?>" size="30" maxlength="60" placeholder="<?php echo HtmlEncode($vbillinghistory_search->brokeremail->getPlaceHolder()) ?>" data-placeholder="<?php echo HtmlEncode($vbillinghistory_search->brokeremail->getPlaceHolder()) ?>"<?php echo $vbillinghistory_search->brokeremail->editAttributes() ?>>
</span>
<input type="hidden" data-table="vbillinghistory" data-field="x_brokeremail" data-page="1" data-value-separator="<?php echo $vbillinghistory_search->brokeremail->displayValueSeparatorAttribute() ?>" name="x_brokeremail" id="x_brokeremail" value="<?php echo HtmlEncode($vbillinghistory_search->brokeremail->AdvancedSearch->SearchValue) ?>"<?php echo $onchange ?>>
<script>
loadjs.ready(["fvbillinghistorysearch"], function() {
	fvbillinghistorysearch.createAutoSuggest({"id":"x_brokeremail","forceSelect":false});
});
</script>
<?php echo $vbillinghistory_search->brokeremail->Lookup->getParamTag($vbillinghistory_search, "p_x_brokeremail") ?>
</span>
		</div></div>
	</div>
<?php } ?>
<?php if ($vbillinghistory_search->brokerid->Visible) { // brokerid ?>
	<div id="r_brokerid" class="form-group row">
		<label for="x_brokerid" class="<?php echo $vbillinghistory_search->LeftColumnClass ?>"><span id="elh_vbillinghistory_brokerid"><?php echo $vbillinghistory_search->brokerid->caption() ?></span>
		<span class="ew-search-operator">
<?php echo $Language->phrase("=") ?>
<input type="hidden" name="z_brokerid" id="z_brokerid" value="=">
</span>
		</label>
		<div class="<?php echo $vbillinghistory_search->RightColumnClass ?>"><div <?php echo $vbillinghistory_search->brokerid->cellAttributes() ?>>
			<span id="el_vbillinghistory_brokerid" class="ew-search-field">
<input type="text" data-table="vbillinghistory" data-field="x_brokerid" data-page="1" name="x_brokerid" id="x_brokerid" size="30" placeholder="<?php echo HtmlEncode($vbillinghistory_search->brokerid->getPlaceHolder()) ?>" value="<?php echo $vbillinghistory_search->brokerid->EditValue ?>"<?php echo $vbillinghistory_search->brokerid->editAttributes() ?>>
</span>
		</div></div>
	</div>
<?php } ?>
<?php if ($vbillinghistory_search->transdate->Visible) { // transdate ?>
	<div id="r_transdate" class="form-group row">
		<label for="x_transdate" class="<?php echo $vbillinghistory_search->LeftColumnClass ?>"><span id="elh_vbillinghistory_transdate"><?php echo $vbillinghistory_search->transdate->caption() ?></span>
		<span class="ew-search-operator">
<?php echo $Language->phrase("BETWEEN") ?>
<input type="hidden" name="z_transdate" id="z_transdate" value="BETWEEN">
</span>
		</label>
		<div class="<?php echo $vbillinghistory_search->RightColumnClass ?>"><div <?php echo $vbillinghistory_search->transdate->cellAttributes() ?>>
			<span id="el_vbillinghistory_transdate" class="ew-search-field">
<input type="text" data-table="vbillinghistory" data-field="x_transdate" data-page="1" data-format="2" name="x_transdate" id="x_transdate" placeholder="<?php echo HtmlEncode($vbillinghistory_search->transdate->getPlaceHolder()) ?>" value="<?php echo $vbillinghistory_search->transdate->EditValue ?>"<?php echo $vbillinghistory_search->transdate->editAttributes() ?>>
<?php if (!$vbillinghistory_search->transdate->ReadOnly && !$vbillinghistory_search->transdate->Disabled && !isset($vbillinghistory_search->transdate->EditAttrs["readonly"]) && !isset($vbillinghistory_search->transdate->EditAttrs["disabled"])) { ?>
<script>
loadjs.ready(["fvbillinghistorysearch", "datetimepicker"], function() {
	ew.createDateTimePicker("fvbillinghistorysearch", "x_transdate", {"ignoreReadonly":true,"useCurrent":false,"format":2});
});
</script>
<?php } ?>
</span>
			<span class="ew-search-and"><label><?php echo $Language->phrase("AND") ?></label></span>
			<span id="el2_vbillinghistory_transdate" class="ew-search-field2">
<input type="text" data-table="vbillinghistory" data-field="x_transdate" data-page="1" data-format="2" name="y_transdate" id="y_transdate" placeholder="<?php echo HtmlEncode($vbillinghistory_search->transdate->getPlaceHolder()) ?>" value="<?php echo $vbillinghistory_search->transdate->EditValue2 ?>"<?php echo $vbillinghistory_search->transdate->editAttributes() ?>>
<?php if (!$vbillinghistory_search->transdate->ReadOnly && !$vbillinghistory_search->transdate->Disabled && !isset($vbillinghistory_search->transdate->EditAttrs["readonly"]) && !isset($vbillinghistory_search->transdate->EditAttrs["disabled"])) { ?>
<script>
loadjs.ready(["fvbillinghistorysearch", "datetimepicker"], function() {
	ew.createDateTimePicker("fvbillinghistorysearch", "y_transdate", {"ignoreReadonly":true,"useCurrent":false,"format":2});
});
</script>
<?php } ?>
</span>
		</div></div>
	</div>
<?php } ?>
<?php if ($vbillinghistory_search->serviceid->Visible) { // serviceid ?>
	<div id="r_serviceid" class="form-group row">
		<label class="<?php echo $vbillinghistory_search->LeftColumnClass ?>"><span id="elh_vbillinghistory_serviceid"><?php echo $vbillinghistory_search->serviceid->caption() ?></span>
		<span class="ew-search-operator">
<?php echo $Language->phrase("=") ?>
<input type="hidden" name="z_serviceid" id="z_serviceid" value="=">
</span>
		</label>
		<div class="<?php echo $vbillinghistory_search->RightColumnClass ?>"><div <?php echo $vbillinghistory_search->serviceid->cellAttributes() ?>>
			<span id="el_vbillinghistory_serviceid" class="ew-search-field">
<div class="btn-group ew-dropdown-list" role="group">
	<div class="btn-group" role="group">
		<button type="button" class="btn form-control dropdown-toggle ew-dropdown-toggle" aria-haspopup="true" aria-expanded="false"<?php if ($vbillinghistory_search->serviceid->ReadOnly) { ?> readonly<?php } else { ?>data-toggle="dropdown"<?php } ?>><?php echo $vbillinghistory_search->serviceid->AdvancedSearch->ViewValue ?></button>
		<div id="dsl_x_serviceid" data-repeatcolumn="5" class="dropdown-menu">
			<div class="ew-items" style="overflow-x: hidden;">
<?php echo $vbillinghistory_search->serviceid->checkBoxListHtml(TRUE, "x_serviceid[]", 1) ?>
			</div><!-- /.ew-items -->
		</div><!-- /.dropdown-menu -->
		<div id="tp_x_serviceid" class="ew-template"><input type="checkbox" class="custom-control-input" data-table="vbillinghistory" data-field="x_serviceid" data-page="1" data-value-separator="<?php echo $vbillinghistory_search->serviceid->displayValueSeparatorAttribute() ?>" name="x_serviceid[]" id="x_serviceid[]" value="{value}"<?php echo $vbillinghistory_search->serviceid->editAttributes() ?>></div>
	</div><!-- /.btn-group -->
	<?php if (!$vbillinghistory_search->serviceid->ReadOnly) { ?>
	<button type="button" class="btn btn-default ew-dropdown-clear" disabled>
		<i class="fas fa-times ew-icon"></i>
	</button>
	<?php } ?>
</div><!-- /.ew-dropdown-list -->
<?php echo $vbillinghistory_search->serviceid->Lookup->getParamTag($vbillinghistory_search, "p_x_serviceid") ?>
</span>
		</div></div>
	</div>
<?php } ?>
<?php if ($vbillinghistory_search->customeracctno->Visible) { // customeracctno ?>
	<div id="r_customeracctno" class="form-group row">
		<label for="x_customeracctno" class="<?php echo $vbillinghistory_search->LeftColumnClass ?>"><span id="elh_vbillinghistory_customeracctno"><?php echo $vbillinghistory_search->customeracctno->caption() ?></span>
		<span class="ew-search-operator">
<?php echo $Language->phrase("LIKE") ?>
<input type="hidden" name="z_customeracctno" id="z_customeracctno" value="LIKE">
</span>
		</label>
		<div class="<?php echo $vbillinghistory_search->RightColumnClass ?>"><div <?php echo $vbillinghistory_search->customeracctno->cellAttributes() ?>>
			<span id="el_vbillinghistory_customeracctno" class="ew-search-field">
<input type="text" data-table="vbillinghistory" data-field="x_customeracctno" data-page="1" name="x_customeracctno" id="x_customeracctno" size="30" maxlength="20" placeholder="<?php echo HtmlEncode($vbillinghistory_search->customeracctno->getPlaceHolder()) ?>" value="<?php echo $vbillinghistory_search->customeracctno->EditValue ?>"<?php echo $vbillinghistory_search->customeracctno->editAttributes() ?>>
</span>
		</div></div>
	</div>
<?php } ?>
<?php if ($vbillinghistory_search->refno->Visible) { // refno ?>
	<div id="r_refno" class="form-group row">
		<label for="x_refno" class="<?php echo $vbillinghistory_search->LeftColumnClass ?>"><span id="elh_vbillinghistory_refno"><?php echo $vbillinghistory_search->refno->caption() ?></span>
		<span class="ew-search-operator">
<?php echo $Language->phrase("LIKE") ?>
<input type="hidden" name="z_refno" id="z_refno" value="LIKE">
</span>
		</label>
		<div class="<?php echo $vbillinghistory_search->RightColumnClass ?>"><div <?php echo $vbillinghistory_search->refno->cellAttributes() ?>>
			<span id="el_vbillinghistory_refno" class="ew-search-field">
<input type="text" data-table="vbillinghistory" data-field="x_refno" data-page="1" name="x_refno" id="x_refno" size="30" maxlength="20" placeholder="<?php echo HtmlEncode($vbillinghistory_search->refno->getPlaceHolder()) ?>" value="<?php echo $vbillinghistory_search->refno->EditValue ?>"<?php echo $vbillinghistory_search->refno->editAttributes() ?>>
</span>
		</div></div>
	</div>
<?php } ?>
<?php if ($vbillinghistory_search->currcode->Visible) { // currcode ?>
	<div id="r_currcode" class="form-group row">
		<label for="x_currcode" class="<?php echo $vbillinghistory_search->LeftColumnClass ?>"><span id="elh_vbillinghistory_currcode"><?php echo $vbillinghistory_search->currcode->caption() ?></span>
		<span class="ew-search-operator">
<?php echo $Language->phrase("LIKE") ?>
<input type="hidden" name="z_currcode" id="z_currcode" value="LIKE">
</span>
		</label>
		<div class="<?php echo $vbillinghistory_search->RightColumnClass ?>"><div <?php echo $vbillinghistory_search->currcode->cellAttributes() ?>>
			<span id="el_vbillinghistory_currcode" class="ew-search-field">
<input type="text" data-table="vbillinghistory" data-field="x_currcode" data-page="1" name="x_currcode" id="x_currcode" size="30" maxlength="3" placeholder="<?php echo HtmlEncode($vbillinghistory_search->currcode->getPlaceHolder()) ?>" value="<?php echo $vbillinghistory_search->currcode->EditValue ?>"<?php echo $vbillinghistory_search->currcode->editAttributes() ?>>
</span>
		</div></div>
	</div>
<?php } ?>
<?php if ($vbillinghistory_search->amount->Visible) { // amount ?>
	<div id="r_amount" class="form-group row">
		<label for="x_amount" class="<?php echo $vbillinghistory_search->LeftColumnClass ?>"><span id="elh_vbillinghistory_amount"><?php echo $vbillinghistory_search->amount->caption() ?></span>
		<span class="ew-search-operator">
<?php echo $Language->phrase("=") ?>
<input type="hidden" name="z_amount" id="z_amount" value="=">
</span>
		</label>
		<div class="<?php echo $vbillinghistory_search->RightColumnClass ?>"><div <?php echo $vbillinghistory_search->amount->cellAttributes() ?>>
			<span id="el_vbillinghistory_amount" class="ew-search-field">
<input type="text" data-table="vbillinghistory" data-field="x_amount" data-page="1" name="x_amount" id="x_amount" size="30" placeholder="<?php echo HtmlEncode($vbillinghistory_search->amount->getPlaceHolder()) ?>" value="<?php echo $vbillinghistory_search->amount->EditValue ?>"<?php echo $vbillinghistory_search->amount->editAttributes() ?>>
</span>
		</div></div>
	</div>
<?php } ?>
<?php if ($vbillinghistory_search->balance->Visible) { // balance ?>
	<div id="r_balance" class="form-group row">
		<label for="x_balance" class="<?php echo $vbillinghistory_search->LeftColumnClass ?>"><span id="elh_vbillinghistory_balance"><?php echo $vbillinghistory_search->balance->caption() ?></span>
		<span class="ew-search-operator">
<?php echo $Language->phrase("=") ?>
<input type="hidden" name="z_balance" id="z_balance" value="=">
</span>
		</label>
		<div class="<?php echo $vbillinghistory_search->RightColumnClass ?>"><div <?php echo $vbillinghistory_search->balance->cellAttributes() ?>>
			<span id="el_vbillinghistory_balance" class="ew-search-field">
<input type="text" data-table="vbillinghistory" data-field="x_balance" data-page="1" name="x_balance" id="x_balance" size="30" placeholder="<?php echo HtmlEncode($vbillinghistory_search->balance->getPlaceHolder()) ?>" value="<?php echo $vbillinghistory_search->balance->EditValue ?>"<?php echo $vbillinghistory_search->balance->editAttributes() ?>>
</span>
		</div></div>
	</div>
<?php } ?>
<?php if ($vbillinghistory_search->confcode->Visible) { // confcode ?>
	<div id="r_confcode" class="form-group row">
		<label for="x_confcode" class="<?php echo $vbillinghistory_search->LeftColumnClass ?>"><span id="elh_vbillinghistory_confcode"><?php echo $vbillinghistory_search->confcode->caption() ?></span>
		<span class="ew-search-operator">
<?php echo $Language->phrase("LIKE") ?>
<input type="hidden" name="z_confcode" id="z_confcode" value="LIKE">
</span>
		</label>
		<div class="<?php echo $vbillinghistory_search->RightColumnClass ?>"><div <?php echo $vbillinghistory_search->confcode->cellAttributes() ?>>
			<span id="el_vbillinghistory_confcode" class="ew-search-field">
<input type="text" data-table="vbillinghistory" data-field="x_confcode" data-page="1" name="x_confcode" id="x_confcode" size="30" maxlength="20" placeholder="<?php echo HtmlEncode($vbillinghistory_search->confcode->getPlaceHolder()) ?>" value="<?php echo $vbillinghistory_search->confcode->EditValue ?>"<?php echo $vbillinghistory_search->confcode->editAttributes() ?>>
</span>
		</div></div>
	</div>
<?php } ?>
<?php if ($vbillinghistory_search->success->Visible) { // success ?>
	<div id="r_success" class="form-group row">
		<label for="x_success" class="<?php echo $vbillinghistory_search->LeftColumnClass ?>"><span id="elh_vbillinghistory_success"><?php echo $vbillinghistory_search->success->caption() ?></span>
		<span class="ew-search-operator">
<?php echo $Language->phrase("=") ?>
<input type="hidden" name="z_success" id="z_success" value="=">
</span>
		</label>
		<div class="<?php echo $vbillinghistory_search->RightColumnClass ?>"><div <?php echo $vbillinghistory_search->success->cellAttributes() ?>>
			<span id="el_vbillinghistory_success" class="ew-search-field">
<div class="input-group">
	<select class="custom-select ew-custom-select" data-table="vbillinghistory" data-field="x_success" data-page="1" data-value-separator="<?php echo $vbillinghistory_search->success->displayValueSeparatorAttribute() ?>" id="x_success" name="x_success"<?php echo $vbillinghistory_search->success->editAttributes() ?>>
			<?php echo $vbillinghistory_search->success->selectOptionListHtml("x_success") ?>
		</select>
</div>
</span>
		</div></div>
	</div>
<?php } ?>
<?php if ($vbillinghistory_search->_userid->Visible) { // userid ?>
	<div id="r__userid" class="form-group row">
		<label for="x__userid" class="<?php echo $vbillinghistory_search->LeftColumnClass ?>"><span id="elh_vbillinghistory__userid"><?php echo $vbillinghistory_search->_userid->caption() ?></span>
		<span class="ew-search-operator">
<?php echo $Language->phrase("=") ?>
<input type="hidden" name="z__userid" id="z__userid" value="=">
</span>
		</label>
		<div class="<?php echo $vbillinghistory_search->RightColumnClass ?>"><div <?php echo $vbillinghistory_search->_userid->cellAttributes() ?>>
			<span id="el_vbillinghistory__userid" class="ew-search-field">
<input type="text" data-table="vbillinghistory" data-field="x__userid" data-page="1" name="x__userid" id="x__userid" size="30" placeholder="<?php echo HtmlEncode($vbillinghistory_search->_userid->getPlaceHolder()) ?>" value="<?php echo $vbillinghistory_search->_userid->EditValue ?>"<?php echo $vbillinghistory_search->_userid->editAttributes() ?>>
</span>
		</div></div>
	</div>
<?php } ?>
<?php if ($vbillinghistory_search->paymenttype->Visible) { // paymenttype ?>
	<div id="r_paymenttype" class="form-group row">
		<label for="x_paymenttype" class="<?php echo $vbillinghistory_search->LeftColumnClass ?>"><span id="elh_vbillinghistory_paymenttype"><?php echo $vbillinghistory_search->paymenttype->caption() ?></span>
		<span class="ew-search-operator">
<?php echo $Language->phrase("=") ?>
<input type="hidden" name="z_paymenttype" id="z_paymenttype" value="=">
</span>
		</label>
		<div class="<?php echo $vbillinghistory_search->RightColumnClass ?>"><div <?php echo $vbillinghistory_search->paymenttype->cellAttributes() ?>>
			<span id="el_vbillinghistory_paymenttype" class="ew-search-field">
<div class="input-group">
	<select class="custom-select ew-custom-select" data-table="vbillinghistory" data-field="x_paymenttype" data-page="1" data-value-separator="<?php echo $vbillinghistory_search->paymenttype->displayValueSeparatorAttribute() ?>" id="x_paymenttype" name="x_paymenttype"<?php echo $vbillinghistory_search->paymenttype->editAttributes() ?>>
			<?php echo $vbillinghistory_search->paymenttype->selectOptionListHtml("x_paymenttype") ?>
		</select>
</div>
</span>
		</div></div>
	</div>
<?php } ?>
<?php if ($vbillinghistory_search->customername->Visible) { // customername ?>
	<div id="r_customername" class="form-group row">
		<label for="x_customername" class="<?php echo $vbillinghistory_search->LeftColumnClass ?>"><span id="elh_vbillinghistory_customername"><?php echo $vbillinghistory_search->customername->caption() ?></span>
		<span class="ew-search-operator">
<?php echo $Language->phrase("LIKE") ?>
<input type="hidden" name="z_customername" id="z_customername" value="LIKE">
</span>
		</label>
		<div class="<?php echo $vbillinghistory_search->RightColumnClass ?>"><div <?php echo $vbillinghistory_search->customername->cellAttributes() ?>>
			<span id="el_vbillinghistory_customername" class="ew-search-field">
<input type="text" data-table="vbillinghistory" data-field="x_customername" data-page="1" name="x_customername" id="x_customername" size="30" maxlength="60" placeholder="<?php echo HtmlEncode($vbillinghistory_search->customername->getPlaceHolder()) ?>" value="<?php echo $vbillinghistory_search->customername->EditValue ?>"<?php echo $vbillinghistory_search->customername->editAttributes() ?>>
</span>
		</div></div>
	</div>
<?php } ?>
<?php if ($vbillinghistory_search->parentuserid->Visible) { // parentuserid ?>
	<div id="r_parentuserid" class="form-group row">
		<label for="x_parentuserid" class="<?php echo $vbillinghistory_search->LeftColumnClass ?>"><span id="elh_vbillinghistory_parentuserid"><?php echo $vbillinghistory_search->parentuserid->caption() ?></span>
		<span class="ew-search-operator">
<?php echo $Language->phrase("=") ?>
<input type="hidden" name="z_parentuserid" id="z_parentuserid" value="=">
</span>
		</label>
		<div class="<?php echo $vbillinghistory_search->RightColumnClass ?>"><div <?php echo $vbillinghistory_search->parentuserid->cellAttributes() ?>>
			<span id="el_vbillinghistory_parentuserid" class="ew-search-field">
<input type="text" data-table="vbillinghistory" data-field="x_parentuserid" data-page="1" name="x_parentuserid" id="x_parentuserid" size="30" placeholder="<?php echo HtmlEncode($vbillinghistory_search->parentuserid->getPlaceHolder()) ?>" value="<?php echo $vbillinghistory_search->parentuserid->EditValue ?>"<?php echo $vbillinghistory_search->parentuserid->editAttributes() ?>>
</span>
		</div></div>
	</div>
<?php } ?>
<?php if ($vbillinghistory_search->businessname->Visible) { // businessname ?>
	<div id="r_businessname" class="form-group row">
		<label for="x_businessname" class="<?php echo $vbillinghistory_search->LeftColumnClass ?>"><span id="elh_vbillinghistory_businessname"><?php echo $vbillinghistory_search->businessname->caption() ?></span>
		<span class="ew-search-operator">
<?php echo $Language->phrase("LIKE") ?>
<input type="hidden" name="z_businessname" id="z_businessname" value="LIKE">
</span>
		</label>
		<div class="<?php echo $vbillinghistory_search->RightColumnClass ?>"><div <?php echo $vbillinghistory_search->businessname->cellAttributes() ?>>
			<span id="el_vbillinghistory_businessname" class="ew-search-field">
<input type="text" data-table="vbillinghistory" data-field="x_businessname" data-page="1" name="x_businessname" id="x_businessname" size="30" maxlength="60" placeholder="<?php echo HtmlEncode($vbillinghistory_search->businessname->getPlaceHolder()) ?>" value="<?php echo $vbillinghistory_search->businessname->EditValue ?>"<?php echo $vbillinghistory_search->businessname->editAttributes() ?>>
</span>
		</div></div>
	</div>
<?php } ?>
<?php if ($vbillinghistory_search->businessphoneno->Visible) { // businessphoneno ?>
	<div id="r_businessphoneno" class="form-group row">
		<label for="x_businessphoneno" class="<?php echo $vbillinghistory_search->LeftColumnClass ?>"><span id="elh_vbillinghistory_businessphoneno"><?php echo $vbillinghistory_search->businessphoneno->caption() ?></span>
		<span class="ew-search-operator">
<?php echo $Language->phrase("LIKE") ?>
<input type="hidden" name="z_businessphoneno" id="z_businessphoneno" value="LIKE">
</span>
		</label>
		<div class="<?php echo $vbillinghistory_search->RightColumnClass ?>"><div <?php echo $vbillinghistory_search->businessphoneno->cellAttributes() ?>>
			<span id="el_vbillinghistory_businessphoneno" class="ew-search-field">
<input type="text" data-table="vbillinghistory" data-field="x_businessphoneno" data-page="1" name="x_businessphoneno" id="x_businessphoneno" size="30" maxlength="15" placeholder="<?php echo HtmlEncode($vbillinghistory_search->businessphoneno->getPlaceHolder()) ?>" value="<?php echo $vbillinghistory_search->businessphoneno->EditValue ?>"<?php echo $vbillinghistory_search->businessphoneno->editAttributes() ?>>
</span>
		</div></div>
	</div>
<?php } ?>
<?php if ($vbillinghistory_search->businessaddress1->Visible) { // businessaddress1 ?>
	<div id="r_businessaddress1" class="form-group row">
		<label for="x_businessaddress1" class="<?php echo $vbillinghistory_search->LeftColumnClass ?>"><span id="elh_vbillinghistory_businessaddress1"><?php echo $vbillinghistory_search->businessaddress1->caption() ?></span>
		<span class="ew-search-operator">
<?php echo $Language->phrase("LIKE") ?>
<input type="hidden" name="z_businessaddress1" id="z_businessaddress1" value="LIKE">
</span>
		</label>
		<div class="<?php echo $vbillinghistory_search->RightColumnClass ?>"><div <?php echo $vbillinghistory_search->businessaddress1->cellAttributes() ?>>
			<span id="el_vbillinghistory_businessaddress1" class="ew-search-field">
<input type="text" data-table="vbillinghistory" data-field="x_businessaddress1" data-page="1" name="x_businessaddress1" id="x_businessaddress1" size="30" maxlength="60" placeholder="<?php echo HtmlEncode($vbillinghistory_search->businessaddress1->getPlaceHolder()) ?>" value="<?php echo $vbillinghistory_search->businessaddress1->EditValue ?>"<?php echo $vbillinghistory_search->businessaddress1->editAttributes() ?>>
</span>
		</div></div>
	</div>
<?php } ?>
<?php if ($vbillinghistory_search->businessaddress2->Visible) { // businessaddress2 ?>
	<div id="r_businessaddress2" class="form-group row">
		<label for="x_businessaddress2" class="<?php echo $vbillinghistory_search->LeftColumnClass ?>"><span id="elh_vbillinghistory_businessaddress2"><?php echo $vbillinghistory_search->businessaddress2->caption() ?></span>
		<span class="ew-search-operator">
<?php echo $Language->phrase("LIKE") ?>
<input type="hidden" name="z_businessaddress2" id="z_businessaddress2" value="LIKE">
</span>
		</label>
		<div class="<?php echo $vbillinghistory_search->RightColumnClass ?>"><div <?php echo $vbillinghistory_search->businessaddress2->cellAttributes() ?>>
			<span id="el_vbillinghistory_businessaddress2" class="ew-search-field">
<input type="text" data-table="vbillinghistory" data-field="x_businessaddress2" data-page="1" name="x_businessaddress2" id="x_businessaddress2" size="30" maxlength="60" placeholder="<?php echo HtmlEncode($vbillinghistory_search->businessaddress2->getPlaceHolder()) ?>" value="<?php echo $vbillinghistory_search->businessaddress2->EditValue ?>"<?php echo $vbillinghistory_search->businessaddress2->editAttributes() ?>>
</span>
		</div></div>
	</div>
<?php } ?>
<?php if ($vbillinghistory_search->businesscity->Visible) { // businesscity ?>
	<div id="r_businesscity" class="form-group row">
		<label for="x_businesscity" class="<?php echo $vbillinghistory_search->LeftColumnClass ?>"><span id="elh_vbillinghistory_businesscity"><?php echo $vbillinghistory_search->businesscity->caption() ?></span>
		<span class="ew-search-operator">
<?php echo $Language->phrase("LIKE") ?>
<input type="hidden" name="z_businesscity" id="z_businesscity" value="LIKE">
</span>
		</label>
		<div class="<?php echo $vbillinghistory_search->RightColumnClass ?>"><div <?php echo $vbillinghistory_search->businesscity->cellAttributes() ?>>
			<span id="el_vbillinghistory_businesscity" class="ew-search-field">
<input type="text" data-table="vbillinghistory" data-field="x_businesscity" data-page="1" name="x_businesscity" id="x_businesscity" size="30" maxlength="60" placeholder="<?php echo HtmlEncode($vbillinghistory_search->businesscity->getPlaceHolder()) ?>" value="<?php echo $vbillinghistory_search->businesscity->EditValue ?>"<?php echo $vbillinghistory_search->businesscity->editAttributes() ?>>
</span>
		</div></div>
	</div>
<?php } ?>
<?php if ($vbillinghistory_search->businessstate->Visible) { // businessstate ?>
	<div id="r_businessstate" class="form-group row">
		<label for="x_businessstate" class="<?php echo $vbillinghistory_search->LeftColumnClass ?>"><span id="elh_vbillinghistory_businessstate"><?php echo $vbillinghistory_search->businessstate->caption() ?></span>
		<span class="ew-search-operator">
<?php echo $Language->phrase("LIKE") ?>
<input type="hidden" name="z_businessstate" id="z_businessstate" value="LIKE">
</span>
		</label>
		<div class="<?php echo $vbillinghistory_search->RightColumnClass ?>"><div <?php echo $vbillinghistory_search->businessstate->cellAttributes() ?>>
			<span id="el_vbillinghistory_businessstate" class="ew-search-field">
<input type="text" data-table="vbillinghistory" data-field="x_businessstate" data-page="1" name="x_businessstate" id="x_businessstate" size="30" maxlength="3" placeholder="<?php echo HtmlEncode($vbillinghistory_search->businessstate->getPlaceHolder()) ?>" value="<?php echo $vbillinghistory_search->businessstate->EditValue ?>"<?php echo $vbillinghistory_search->businessstate->editAttributes() ?>>
</span>
		</div></div>
	</div>
<?php } ?>
<?php if ($vbillinghistory_search->businesscountry->Visible) { // businesscountry ?>
	<div id="r_businesscountry" class="form-group row">
		<label for="x_businesscountry" class="<?php echo $vbillinghistory_search->LeftColumnClass ?>"><span id="elh_vbillinghistory_businesscountry"><?php echo $vbillinghistory_search->businesscountry->caption() ?></span>
		<span class="ew-search-operator">
<?php echo $Language->phrase("LIKE") ?>
<input type="hidden" name="z_businesscountry" id="z_businesscountry" value="LIKE">
</span>
		</label>
		<div class="<?php echo $vbillinghistory_search->RightColumnClass ?>"><div <?php echo $vbillinghistory_search->businesscountry->cellAttributes() ?>>
			<span id="el_vbillinghistory_businesscountry" class="ew-search-field">
<input type="text" data-table="vbillinghistory" data-field="x_businesscountry" data-page="1" name="x_businesscountry" id="x_businesscountry" size="30" maxlength="3" placeholder="<?php echo HtmlEncode($vbillinghistory_search->businesscountry->getPlaceHolder()) ?>" value="<?php echo $vbillinghistory_search->businesscountry->EditValue ?>"<?php echo $vbillinghistory_search->businesscountry->editAttributes() ?>>
</span>
		</div></div>
	</div>
<?php } ?>
<?php if ($vbillinghistory_search->officialdocnumber->Visible) { // officialdocnumber ?>
	<div id="r_officialdocnumber" class="form-group row">
		<label for="x_officialdocnumber" class="<?php echo $vbillinghistory_search->LeftColumnClass ?>"><span id="elh_vbillinghistory_officialdocnumber"><?php echo $vbillinghistory_search->officialdocnumber->caption() ?></span>
		<span class="ew-search-operator">
<?php echo $Language->phrase("LIKE") ?>
<input type="hidden" name="z_officialdocnumber" id="z_officialdocnumber" value="LIKE">
</span>
		</label>
		<div class="<?php echo $vbillinghistory_search->RightColumnClass ?>"><div <?php echo $vbillinghistory_search->officialdocnumber->cellAttributes() ?>>
			<span id="el_vbillinghistory_officialdocnumber" class="ew-search-field">
<input type="text" data-table="vbillinghistory" data-field="x_officialdocnumber" data-page="1" name="x_officialdocnumber" id="x_officialdocnumber" size="30" maxlength="20" placeholder="<?php echo HtmlEncode($vbillinghistory_search->officialdocnumber->getPlaceHolder()) ?>" value="<?php echo $vbillinghistory_search->officialdocnumber->EditValue ?>"<?php echo $vbillinghistory_search->officialdocnumber->editAttributes() ?>>
</span>
		</div></div>
	</div>
<?php } ?>
<?php if ($vbillinghistory_search->branchname->Visible) { // branchname ?>
	<div id="r_branchname" class="form-group row">
		<label for="x_branchname" class="<?php echo $vbillinghistory_search->LeftColumnClass ?>"><span id="elh_vbillinghistory_branchname"><?php echo $vbillinghistory_search->branchname->caption() ?></span>
		<span class="ew-search-operator">
<?php echo $Language->phrase("LIKE") ?>
<input type="hidden" name="z_branchname" id="z_branchname" value="LIKE">
</span>
		</label>
		<div class="<?php echo $vbillinghistory_search->RightColumnClass ?>"><div <?php echo $vbillinghistory_search->branchname->cellAttributes() ?>>
			<span id="el_vbillinghistory_branchname" class="ew-search-field">
<input type="text" data-table="vbillinghistory" data-field="x_branchname" data-page="1" name="x_branchname" id="x_branchname" size="30" maxlength="50" placeholder="<?php echo HtmlEncode($vbillinghistory_search->branchname->getPlaceHolder()) ?>" value="<?php echo $vbillinghistory_search->branchname->EditValue ?>"<?php echo $vbillinghistory_search->branchname->editAttributes() ?>>
</span>
		</div></div>
	</div>
<?php } ?>
<?php if ($vbillinghistory_search->clerkname->Visible) { // clerkname ?>
	<div id="r_clerkname" class="form-group row">
		<label for="x_clerkname" class="<?php echo $vbillinghistory_search->LeftColumnClass ?>"><span id="elh_vbillinghistory_clerkname"><?php echo $vbillinghistory_search->clerkname->caption() ?></span>
		<span class="ew-search-operator">
<?php echo $Language->phrase("LIKE") ?>
<input type="hidden" name="z_clerkname" id="z_clerkname" value="LIKE">
</span>
		</label>
		<div class="<?php echo $vbillinghistory_search->RightColumnClass ?>"><div <?php echo $vbillinghistory_search->clerkname->cellAttributes() ?>>
			<span id="el_vbillinghistory_clerkname" class="ew-search-field">
<input type="text" data-table="vbillinghistory" data-field="x_clerkname" data-page="1" name="x_clerkname" id="x_clerkname" size="30" maxlength="50" placeholder="<?php echo HtmlEncode($vbillinghistory_search->clerkname->getPlaceHolder()) ?>" value="<?php echo $vbillinghistory_search->clerkname->EditValue ?>"<?php echo $vbillinghistory_search->clerkname->editAttributes() ?>>
</span>
		</div></div>
	</div>
<?php } ?>
<?php if ($vbillinghistory_search->taxamount->Visible) { // taxamount ?>
	<div id="r_taxamount" class="form-group row">
		<label for="x_taxamount" class="<?php echo $vbillinghistory_search->LeftColumnClass ?>"><span id="elh_vbillinghistory_taxamount"><?php echo $vbillinghistory_search->taxamount->caption() ?></span>
		<span class="ew-search-operator">
<?php echo $Language->phrase("=") ?>
<input type="hidden" name="z_taxamount" id="z_taxamount" value="=">
</span>
		</label>
		<div class="<?php echo $vbillinghistory_search->RightColumnClass ?>"><div <?php echo $vbillinghistory_search->taxamount->cellAttributes() ?>>
			<span id="el_vbillinghistory_taxamount" class="ew-search-field">
<input type="text" data-table="vbillinghistory" data-field="x_taxamount" data-page="1" name="x_taxamount" id="x_taxamount" size="30" maxlength="12" placeholder="<?php echo HtmlEncode($vbillinghistory_search->taxamount->getPlaceHolder()) ?>" value="<?php echo $vbillinghistory_search->taxamount->EditValue ?>"<?php echo $vbillinghistory_search->taxamount->editAttributes() ?>>
</span>
		</div></div>
	</div>
<?php } ?>
<?php if ($vbillinghistory_search->totalamount->Visible) { // totalamount ?>
	<div id="r_totalamount" class="form-group row">
		<label for="x_totalamount" class="<?php echo $vbillinghistory_search->LeftColumnClass ?>"><span id="elh_vbillinghistory_totalamount"><?php echo $vbillinghistory_search->totalamount->caption() ?></span>
		<span class="ew-search-operator">
<?php echo $Language->phrase("=") ?>
<input type="hidden" name="z_totalamount" id="z_totalamount" value="=">
</span>
		</label>
		<div class="<?php echo $vbillinghistory_search->RightColumnClass ?>"><div <?php echo $vbillinghistory_search->totalamount->cellAttributes() ?>>
			<span id="el_vbillinghistory_totalamount" class="ew-search-field">
<input type="text" data-table="vbillinghistory" data-field="x_totalamount" data-page="1" name="x_totalamount" id="x_totalamount" size="30" maxlength="12" placeholder="<?php echo HtmlEncode($vbillinghistory_search->totalamount->getPlaceHolder()) ?>" value="<?php echo $vbillinghistory_search->totalamount->EditValue ?>"<?php echo $vbillinghistory_search->totalamount->editAttributes() ?>>
</span>
		</div></div>
	</div>
<?php } ?>
<?php if ($vbillinghistory_search->taxperc->Visible) { // taxperc ?>
	<div id="r_taxperc" class="form-group row">
		<label for="x_taxperc" class="<?php echo $vbillinghistory_search->LeftColumnClass ?>"><span id="elh_vbillinghistory_taxperc"><?php echo $vbillinghistory_search->taxperc->caption() ?></span>
		<span class="ew-search-operator">
<?php echo $Language->phrase("=") ?>
<input type="hidden" name="z_taxperc" id="z_taxperc" value="=">
</span>
		</label>
		<div class="<?php echo $vbillinghistory_search->RightColumnClass ?>"><div <?php echo $vbillinghistory_search->taxperc->cellAttributes() ?>>
			<span id="el_vbillinghistory_taxperc" class="ew-search-field">
<input type="text" data-table="vbillinghistory" data-field="x_taxperc" data-page="1" name="x_taxperc" id="x_taxperc" size="30" maxlength="6" placeholder="<?php echo HtmlEncode($vbillinghistory_search->taxperc->getPlaceHolder()) ?>" value="<?php echo $vbillinghistory_search->taxperc->EditValue ?>"<?php echo $vbillinghistory_search->taxperc->editAttributes() ?>>
</span>
		</div></div>
	</div>
<?php } ?>
<?php if ($vbillinghistory_search->department->Visible) { // department ?>
	<div id="r_department" class="form-group row">
		<label for="x_department" class="<?php echo $vbillinghistory_search->LeftColumnClass ?>"><span id="elh_vbillinghistory_department"><?php echo $vbillinghistory_search->department->caption() ?></span>
		<span class="ew-search-operator">
<?php echo $Language->phrase("LIKE") ?>
<input type="hidden" name="z_department" id="z_department" value="LIKE">
</span>
		</label>
		<div class="<?php echo $vbillinghistory_search->RightColumnClass ?>"><div <?php echo $vbillinghistory_search->department->cellAttributes() ?>>
			<span id="el_vbillinghistory_department" class="ew-search-field">
<div class="input-group">
	<select class="custom-select ew-custom-select" data-table="vbillinghistory" data-field="x_department" data-page="1" data-value-separator="<?php echo $vbillinghistory_search->department->displayValueSeparatorAttribute() ?>" id="x_department" name="x_department"<?php echo $vbillinghistory_search->department->editAttributes() ?>>
			<?php echo $vbillinghistory_search->department->selectOptionListHtml("x_department") ?>
		</select>
</div>
<?php echo $vbillinghistory_search->department->Lookup->getParamTag($vbillinghistory_search, "p_x_department") ?>
</span>
		</div></div>
	</div>
<?php } ?>
<?php if ($vbillinghistory_search->purchaseid->Visible) { // purchaseid ?>
	<div id="r_purchaseid" class="form-group row">
		<label for="x_purchaseid" class="<?php echo $vbillinghistory_search->LeftColumnClass ?>"><span id="elh_vbillinghistory_purchaseid"><?php echo $vbillinghistory_search->purchaseid->caption() ?></span>
		<span class="ew-search-operator">
<?php echo $Language->phrase("=") ?>
<input type="hidden" name="z_purchaseid" id="z_purchaseid" value="=">
</span>
		</label>
		<div class="<?php echo $vbillinghistory_search->RightColumnClass ?>"><div <?php echo $vbillinghistory_search->purchaseid->cellAttributes() ?>>
			<span id="el_vbillinghistory_purchaseid" class="ew-search-field">
<input type="text" data-table="vbillinghistory" data-field="x_purchaseid" data-page="1" name="x_purchaseid" id="x_purchaseid" size="30" maxlength="12" placeholder="<?php echo HtmlEncode($vbillinghistory_search->purchaseid->getPlaceHolder()) ?>" value="<?php echo $vbillinghistory_search->purchaseid->EditValue ?>"<?php echo $vbillinghistory_search->purchaseid->editAttributes() ?>>
</span>
		</div></div>
	</div>
<?php } ?>
<?php if ($vbillinghistory_search->paymentid->Visible) { // paymentid ?>
	<div id="r_paymentid" class="form-group row">
		<label for="x_paymentid" class="<?php echo $vbillinghistory_search->LeftColumnClass ?>"><span id="elh_vbillinghistory_paymentid"><?php echo $vbillinghistory_search->paymentid->caption() ?></span>
		<span class="ew-search-operator">
<?php echo $Language->phrase("=") ?>
<input type="hidden" name="z_paymentid" id="z_paymentid" value="=">
</span>
		</label>
		<div class="<?php echo $vbillinghistory_search->RightColumnClass ?>"><div <?php echo $vbillinghistory_search->paymentid->cellAttributes() ?>>
			<span id="el_vbillinghistory_paymentid" class="ew-search-field">
<input type="text" data-table="vbillinghistory" data-field="x_paymentid" data-page="1" name="x_paymentid" id="x_paymentid" size="30" maxlength="12" placeholder="<?php echo HtmlEncode($vbillinghistory_search->paymentid->getPlaceHolder()) ?>" value="<?php echo $vbillinghistory_search->paymentid->EditValue ?>"<?php echo $vbillinghistory_search->paymentid->editAttributes() ?>>
</span>
		</div></div>
	</div>
<?php } ?>
<?php if ($vbillinghistory_search->transgroupid->Visible) { // transgroupid ?>
	<div id="r_transgroupid" class="form-group row">
		<label for="x_transgroupid" class="<?php echo $vbillinghistory_search->LeftColumnClass ?>"><span id="elh_vbillinghistory_transgroupid"><?php echo $vbillinghistory_search->transgroupid->caption() ?></span>
		<span class="ew-search-operator">
<?php echo $Language->phrase("=") ?>
<input type="hidden" name="z_transgroupid" id="z_transgroupid" value="=">
</span>
		</label>
		<div class="<?php echo $vbillinghistory_search->RightColumnClass ?>"><div <?php echo $vbillinghistory_search->transgroupid->cellAttributes() ?>>
			<span id="el_vbillinghistory_transgroupid" class="ew-search-field">
<input type="text" data-table="vbillinghistory" data-field="x_transgroupid" data-page="1" name="x_transgroupid" id="x_transgroupid" size="30" maxlength="12" placeholder="<?php echo HtmlEncode($vbillinghistory_search->transgroupid->getPlaceHolder()) ?>" value="<?php echo $vbillinghistory_search->transgroupid->EditValue ?>"<?php echo $vbillinghistory_search->transgroupid->editAttributes() ?>>
</span>
		</div></div>
	</div>
<?php } ?>
<?php if ($vbillinghistory_search->otherdetails->Visible) { // otherdetails ?>
	<div id="r_otherdetails" class="form-group row">
		<label for="x_otherdetails" class="<?php echo $vbillinghistory_search->LeftColumnClass ?>"><span id="elh_vbillinghistory_otherdetails"><?php echo $vbillinghistory_search->otherdetails->caption() ?></span>
		<span class="ew-search-operator">
<?php echo $Language->phrase("LIKE") ?>
<input type="hidden" name="z_otherdetails" id="z_otherdetails" value="LIKE">
</span>
		</label>
		<div class="<?php echo $vbillinghistory_search->RightColumnClass ?>"><div <?php echo $vbillinghistory_search->otherdetails->cellAttributes() ?>>
			<span id="el_vbillinghistory_otherdetails" class="ew-search-field">
<input type="text" data-table="vbillinghistory" data-field="x_otherdetails" data-page="1" name="x_otherdetails" id="x_otherdetails" size="35" maxlength="350" placeholder="<?php echo HtmlEncode($vbillinghistory_search->otherdetails->getPlaceHolder()) ?>" value="<?php echo $vbillinghistory_search->otherdetails->EditValue ?>"<?php echo $vbillinghistory_search->otherdetails->editAttributes() ?>>
</span>
		</div></div>
	</div>
<?php } ?>
</div><!-- /page* -->
		</div><!-- /multi-page .tab-pane -->
		<div class="tab-pane<?php echo $vbillinghistory_search->MultiPages->pageStyle(2) ?>" id="tab_vbillinghistory2"><!-- multi-page .tab-pane -->
<div class="ew-search-div"><!-- page* -->
<?php if ($vbillinghistory_search->feeid->Visible) { // feeid ?>
	<div id="r_feeid" class="form-group row">
		<label for="x_feeid" class="<?php echo $vbillinghistory_search->LeftColumnClass ?>"><span id="elh_vbillinghistory_feeid"><?php echo $vbillinghistory_search->feeid->caption() ?></span>
		<span class="ew-search-operator">
<?php echo $Language->phrase("=") ?>
<input type="hidden" name="z_feeid" id="z_feeid" value="=">
</span>
		</label>
		<div class="<?php echo $vbillinghistory_search->RightColumnClass ?>"><div <?php echo $vbillinghistory_search->feeid->cellAttributes() ?>>
			<span id="el_vbillinghistory_feeid" class="ew-search-field">
<input type="text" data-table="vbillinghistory" data-field="x_feeid" data-page="2" name="x_feeid" id="x_feeid" size="30" placeholder="<?php echo HtmlEncode($vbillinghistory_search->feeid->getPlaceHolder()) ?>" value="<?php echo $vbillinghistory_search->feeid->EditValue ?>"<?php echo $vbillinghistory_search->feeid->editAttributes() ?>>
</span>
		</div></div>
	</div>
<?php } ?>
<?php if ($vbillinghistory_search->_tabletype->Visible) { // tabletype ?>
	<div id="r__tabletype" class="form-group row">
		<label for="x__tabletype" class="<?php echo $vbillinghistory_search->LeftColumnClass ?>"><span id="elh_vbillinghistory__tabletype"><?php echo $vbillinghistory_search->_tabletype->caption() ?></span>
		<span class="ew-search-operator">
<?php echo $Language->phrase("=") ?>
<input type="hidden" name="z__tabletype" id="z__tabletype" value="=">
</span>
		</label>
		<div class="<?php echo $vbillinghistory_search->RightColumnClass ?>"><div <?php echo $vbillinghistory_search->_tabletype->cellAttributes() ?>>
			<span id="el_vbillinghistory__tabletype" class="ew-search-field">
<input type="text" data-table="vbillinghistory" data-field="x__tabletype" data-page="2" name="x__tabletype" id="x__tabletype" size="30" placeholder="<?php echo HtmlEncode($vbillinghistory_search->_tabletype->getPlaceHolder()) ?>" value="<?php echo $vbillinghistory_search->_tabletype->EditValue ?>"<?php echo $vbillinghistory_search->_tabletype->editAttributes() ?>>
</span>
		</div></div>
	</div>
<?php } ?>
<?php if ($vbillinghistory_search->feemerchanttotal->Visible) { // feemerchanttotal ?>
	<div id="r_feemerchanttotal" class="form-group row">
		<label for="x_feemerchanttotal" class="<?php echo $vbillinghistory_search->LeftColumnClass ?>"><span id="elh_vbillinghistory_feemerchanttotal"><?php echo $vbillinghistory_search->feemerchanttotal->caption() ?></span>
		<span class="ew-search-operator">
<?php echo $Language->phrase("=") ?>
<input type="hidden" name="z_feemerchanttotal" id="z_feemerchanttotal" value="=">
</span>
		</label>
		<div class="<?php echo $vbillinghistory_search->RightColumnClass ?>"><div <?php echo $vbillinghistory_search->feemerchanttotal->cellAttributes() ?>>
			<span id="el_vbillinghistory_feemerchanttotal" class="ew-search-field">
<input type="text" data-table="vbillinghistory" data-field="x_feemerchanttotal" data-page="2" name="x_feemerchanttotal" id="x_feemerchanttotal" size="30" placeholder="<?php echo HtmlEncode($vbillinghistory_search->feemerchanttotal->getPlaceHolder()) ?>" value="<?php echo $vbillinghistory_search->feemerchanttotal->EditValue ?>"<?php echo $vbillinghistory_search->feemerchanttotal->editAttributes() ?>>
</span>
		</div></div>
	</div>
<?php } ?>
<?php if ($vbillinghistory_search->feeconsumertotal->Visible) { // feeconsumertotal ?>
	<div id="r_feeconsumertotal" class="form-group row">
		<label for="x_feeconsumertotal" class="<?php echo $vbillinghistory_search->LeftColumnClass ?>"><span id="elh_vbillinghistory_feeconsumertotal"><?php echo $vbillinghistory_search->feeconsumertotal->caption() ?></span>
		<span class="ew-search-operator">
<?php echo $Language->phrase("=") ?>
<input type="hidden" name="z_feeconsumertotal" id="z_feeconsumertotal" value="=">
</span>
		</label>
		<div class="<?php echo $vbillinghistory_search->RightColumnClass ?>"><div <?php echo $vbillinghistory_search->feeconsumertotal->cellAttributes() ?>>
			<span id="el_vbillinghistory_feeconsumertotal" class="ew-search-field">
<input type="text" data-table="vbillinghistory" data-field="x_feeconsumertotal" data-page="2" name="x_feeconsumertotal" id="x_feeconsumertotal" size="30" placeholder="<?php echo HtmlEncode($vbillinghistory_search->feeconsumertotal->getPlaceHolder()) ?>" value="<?php echo $vbillinghistory_search->feeconsumertotal->EditValue ?>"<?php echo $vbillinghistory_search->feeconsumertotal->editAttributes() ?>>
</span>
		</div></div>
	</div>
<?php } ?>
<?php if ($vbillinghistory_search->feesystemtotal->Visible) { // feesystemtotal ?>
	<div id="r_feesystemtotal" class="form-group row">
		<label for="x_feesystemtotal" class="<?php echo $vbillinghistory_search->LeftColumnClass ?>"><span id="elh_vbillinghistory_feesystemtotal"><?php echo $vbillinghistory_search->feesystemtotal->caption() ?></span>
		<span class="ew-search-operator">
<?php echo $Language->phrase("=") ?>
<input type="hidden" name="z_feesystemtotal" id="z_feesystemtotal" value="=">
</span>
		</label>
		<div class="<?php echo $vbillinghistory_search->RightColumnClass ?>"><div <?php echo $vbillinghistory_search->feesystemtotal->cellAttributes() ?>>
			<span id="el_vbillinghistory_feesystemtotal" class="ew-search-field">
<input type="text" data-table="vbillinghistory" data-field="x_feesystemtotal" data-page="2" name="x_feesystemtotal" id="x_feesystemtotal" size="30" placeholder="<?php echo HtmlEncode($vbillinghistory_search->feesystemtotal->getPlaceHolder()) ?>" value="<?php echo $vbillinghistory_search->feesystemtotal->EditValue ?>"<?php echo $vbillinghistory_search->feesystemtotal->editAttributes() ?>>
</span>
		</div></div>
	</div>
<?php } ?>
<?php if ($vbillinghistory_search->feeexternaltotal->Visible) { // feeexternaltotal ?>
	<div id="r_feeexternaltotal" class="form-group row">
		<label for="x_feeexternaltotal" class="<?php echo $vbillinghistory_search->LeftColumnClass ?>"><span id="elh_vbillinghistory_feeexternaltotal"><?php echo $vbillinghistory_search->feeexternaltotal->caption() ?></span>
		<span class="ew-search-operator">
<?php echo $Language->phrase("=") ?>
<input type="hidden" name="z_feeexternaltotal" id="z_feeexternaltotal" value="=">
</span>
		</label>
		<div class="<?php echo $vbillinghistory_search->RightColumnClass ?>"><div <?php echo $vbillinghistory_search->feeexternaltotal->cellAttributes() ?>>
			<span id="el_vbillinghistory_feeexternaltotal" class="ew-search-field">
<input type="text" data-table="vbillinghistory" data-field="x_feeexternaltotal" data-page="2" name="x_feeexternaltotal" id="x_feeexternaltotal" size="30" placeholder="<?php echo HtmlEncode($vbillinghistory_search->feeexternaltotal->getPlaceHolder()) ?>" value="<?php echo $vbillinghistory_search->feeexternaltotal->EditValue ?>"<?php echo $vbillinghistory_search->feeexternaltotal->editAttributes() ?>>
</span>
		</div></div>
	</div>
<?php } ?>
<?php if ($vbillinghistory_search->feefranchiseetotal->Visible) { // feefranchiseetotal ?>
	<div id="r_feefranchiseetotal" class="form-group row">
		<label for="x_feefranchiseetotal" class="<?php echo $vbillinghistory_search->LeftColumnClass ?>"><span id="elh_vbillinghistory_feefranchiseetotal"><?php echo $vbillinghistory_search->feefranchiseetotal->caption() ?></span>
		<span class="ew-search-operator">
<?php echo $Language->phrase("=") ?>
<input type="hidden" name="z_feefranchiseetotal" id="z_feefranchiseetotal" value="=">
</span>
		</label>
		<div class="<?php echo $vbillinghistory_search->RightColumnClass ?>"><div <?php echo $vbillinghistory_search->feefranchiseetotal->cellAttributes() ?>>
			<span id="el_vbillinghistory_feefranchiseetotal" class="ew-search-field">
<input type="text" data-table="vbillinghistory" data-field="x_feefranchiseetotal" data-page="2" name="x_feefranchiseetotal" id="x_feefranchiseetotal" size="30" placeholder="<?php echo HtmlEncode($vbillinghistory_search->feefranchiseetotal->getPlaceHolder()) ?>" value="<?php echo $vbillinghistory_search->feefranchiseetotal->EditValue ?>"<?php echo $vbillinghistory_search->feefranchiseetotal->editAttributes() ?>>
</span>
		</div></div>
	</div>
<?php } ?>
<?php if ($vbillinghistory_search->feeresellertotal->Visible) { // feeresellertotal ?>
	<div id="r_feeresellertotal" class="form-group row">
		<label for="x_feeresellertotal" class="<?php echo $vbillinghistory_search->LeftColumnClass ?>"><span id="elh_vbillinghistory_feeresellertotal"><?php echo $vbillinghistory_search->feeresellertotal->caption() ?></span>
		<span class="ew-search-operator">
<?php echo $Language->phrase("=") ?>
<input type="hidden" name="z_feeresellertotal" id="z_feeresellertotal" value="=">
</span>
		</label>
		<div class="<?php echo $vbillinghistory_search->RightColumnClass ?>"><div <?php echo $vbillinghistory_search->feeresellertotal->cellAttributes() ?>>
			<span id="el_vbillinghistory_feeresellertotal" class="ew-search-field">
<input type="text" data-table="vbillinghistory" data-field="x_feeresellertotal" data-page="2" name="x_feeresellertotal" id="x_feeresellertotal" size="30" placeholder="<?php echo HtmlEncode($vbillinghistory_search->feeresellertotal->getPlaceHolder()) ?>" value="<?php echo $vbillinghistory_search->feeresellertotal->EditValue ?>"<?php echo $vbillinghistory_search->feeresellertotal->editAttributes() ?>>
</span>
		</div></div>
	</div>
<?php } ?>
</div><!-- /page* -->
		</div><!-- /multi-page .tab-pane -->
		<div class="tab-pane<?php echo $vbillinghistory_search->MultiPages->pageStyle(3) ?>" id="tab_vbillinghistory3"><!-- multi-page .tab-pane -->
<div class="ew-search-div"><!-- page* -->
<?php if ($vbillinghistory_search->billerresponse->Visible) { // billerresponse ?>
	<div id="r_billerresponse" class="form-group row">
		<label for="x_billerresponse" class="<?php echo $vbillinghistory_search->LeftColumnClass ?>"><span id="elh_vbillinghistory_billerresponse"><?php echo $vbillinghistory_search->billerresponse->caption() ?></span>
		<span class="ew-search-operator">
<?php echo $Language->phrase("LIKE") ?>
<input type="hidden" name="z_billerresponse" id="z_billerresponse" value="LIKE">
</span>
		</label>
		<div class="<?php echo $vbillinghistory_search->RightColumnClass ?>"><div <?php echo $vbillinghistory_search->billerresponse->cellAttributes() ?>>
			<span id="el_vbillinghistory_billerresponse" class="ew-search-field">
<input type="text" data-table="vbillinghistory" data-field="x_billerresponse" data-page="3" name="x_billerresponse" id="x_billerresponse" size="35" placeholder="<?php echo HtmlEncode($vbillinghistory_search->billerresponse->getPlaceHolder()) ?>" value="<?php echo $vbillinghistory_search->billerresponse->EditValue ?>"<?php echo $vbillinghistory_search->billerresponse->editAttributes() ?>>
</span>
		</div></div>
	</div>
<?php } ?>
<?php if ($vbillinghistory_search->billingresponse2->Visible) { // billingresponse2 ?>
	<div id="r_billingresponse2" class="form-group row">
		<label for="x_billingresponse2" class="<?php echo $vbillinghistory_search->LeftColumnClass ?>"><span id="elh_vbillinghistory_billingresponse2"><?php echo $vbillinghistory_search->billingresponse2->caption() ?></span>
		<span class="ew-search-operator">
<?php echo $Language->phrase("LIKE") ?>
<input type="hidden" name="z_billingresponse2" id="z_billingresponse2" value="LIKE">
</span>
		</label>
		<div class="<?php echo $vbillinghistory_search->RightColumnClass ?>"><div <?php echo $vbillinghistory_search->billingresponse2->cellAttributes() ?>>
			<span id="el_vbillinghistory_billingresponse2" class="ew-search-field">
<input type="text" data-table="vbillinghistory" data-field="x_billingresponse2" data-page="3" name="x_billingresponse2" id="x_billingresponse2" size="35" placeholder="<?php echo HtmlEncode($vbillinghistory_search->billingresponse2->getPlaceHolder()) ?>" value="<?php echo $vbillinghistory_search->billingresponse2->EditValue ?>"<?php echo $vbillinghistory_search->billingresponse2->editAttributes() ?>>
</span>
		</div></div>
	</div>
<?php } ?>
</div><!-- /page* -->
		</div><!-- /multi-page .tab-pane -->
	</div><!-- /multi-page tabs .tab-content -->
</div><!-- /multi-page tabs -->
</div><!-- /multi-page -->
<?php if (!$vbillinghistory_search->IsModal) { ?>
<div class="form-group row"><!-- buttons .form-group -->
	<div class="<?php echo $vbillinghistory_search->OffsetColumnClass ?>"><!-- buttons offset -->
<button class="btn btn-primary ew-btn" name="btn-action" id="btn-action" type="submit"><?php echo $Language->phrase("Search") ?></button>
<button class="btn btn-default ew-btn" name="btn-reset" id="btn-reset" type="button" onclick="ew.clearForm(this.form);"><?php echo $Language->phrase("Reset") ?></button>
	</div><!-- /buttons offset -->
</div><!-- /buttons .form-group -->
<?php } ?>
</form>
<?php
$vbillinghistory_search->showPageFooter();
if (Config("DEBUG"))
	echo GetDebugMessage();
?>
<script>
loadjs.ready("load", function() {

	// Startup script
	// Write your table-specific startup script here
	// console.log("page loaded");

});
</script>
<?php include_once "footer.php"; ?>
<?php
$vbillinghistory_search->terminate();
?>