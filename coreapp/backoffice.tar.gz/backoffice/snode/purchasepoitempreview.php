<?php
namespace PHPMaker2020\_4payadmin;

// Autoload
include_once "autoload.php";

// Session
if (session_status() !== PHP_SESSION_ACTIVE)
	\Delight\Cookie\Session::start(Config("COOKIE_SAMESITE")); // Init session data

// Output buffering
ob_start();
?>
<?php

// Write header
WriteHeader(FALSE, "utf-8");

// Create page object
$purchasepoitem_preview = new purchasepoitem_preview();

// Run the page
$purchasepoitem_preview->run();

// Setup login status
SetupLoginStatus();
SetClientVar("login", LoginStatus());

// Global Page Rendering event (in userfn*.php)
Page_Rendering();

// Page Rendering event
$purchasepoitem_preview->Page_Render();
?>
<?php $purchasepoitem_preview->showPageHeader(); ?>
<?php if ($purchasepoitem_preview->TotalRecords > 0) { ?>
<div class="card ew-grid purchasepoitem"><!-- .card -->
<div class="<?php echo ResponsiveTableClass() ?>card-body ew-grid-middle-panel ew-preview-middle-panel"><!-- .table-responsive -->
<table class="table ew-table ew-preview-table"><!-- .table -->
	<thead><!-- Table header -->
		<tr class="ew-table-header">
<?php

// Render list options
$purchasepoitem_preview->renderListOptions();

// Render list options (header, left)
$purchasepoitem_preview->ListOptions->render("header", "left");
?>
<?php if ($purchasepoitem_preview->itemid->Visible) { // itemid ?>
	<?php if ($purchasepoitem->SortUrl($purchasepoitem_preview->itemid) == "") { ?>
		<th class="<?php echo $purchasepoitem_preview->itemid->headerCellClass() ?>"><?php echo $purchasepoitem_preview->itemid->caption() ?></th>
	<?php } else { ?>
		<th class="<?php echo $purchasepoitem_preview->itemid->headerCellClass() ?>"><div class="ew-pointer" data-sort="<?php echo HtmlEncode($purchasepoitem_preview->itemid->Name) ?>" data-sort-order="<?php echo $purchasepoitem_preview->SortField == $purchasepoitem_preview->itemid->Name && $purchasepoitem_preview->SortOrder == "ASC" ? "DESC" : "ASC" ?>">
			<div class="ew-table-header-btn"><span class="ew-table-header-caption"><?php echo $purchasepoitem_preview->itemid->caption() ?></span><span class="ew-table-header-sort"><?php if ($purchasepoitem_preview->SortField == $purchasepoitem_preview->itemid->Name) { ?><?php if ($purchasepoitem_preview->SortOrder == "ASC") { ?><i class="fas fa-sort-up"></i><?php } elseif ($purchasepoitem_preview->SortOrder == "DESC") { ?><i class="fas fa-sort-down"></i><?php } ?><?php } ?></span>
		</div></div></th>
	<?php } ?>
<?php } ?>
<?php if ($purchasepoitem_preview->poid->Visible) { // poid ?>
	<?php if ($purchasepoitem->SortUrl($purchasepoitem_preview->poid) == "") { ?>
		<th class="<?php echo $purchasepoitem_preview->poid->headerCellClass() ?>"><?php echo $purchasepoitem_preview->poid->caption() ?></th>
	<?php } else { ?>
		<th class="<?php echo $purchasepoitem_preview->poid->headerCellClass() ?>"><div class="ew-pointer" data-sort="<?php echo HtmlEncode($purchasepoitem_preview->poid->Name) ?>" data-sort-order="<?php echo $purchasepoitem_preview->SortField == $purchasepoitem_preview->poid->Name && $purchasepoitem_preview->SortOrder == "ASC" ? "DESC" : "ASC" ?>">
			<div class="ew-table-header-btn"><span class="ew-table-header-caption"><?php echo $purchasepoitem_preview->poid->caption() ?></span><span class="ew-table-header-sort"><?php if ($purchasepoitem_preview->SortField == $purchasepoitem_preview->poid->Name) { ?><?php if ($purchasepoitem_preview->SortOrder == "ASC") { ?><i class="fas fa-sort-up"></i><?php } elseif ($purchasepoitem_preview->SortOrder == "DESC") { ?><i class="fas fa-sort-down"></i><?php } ?><?php } ?></span>
		</div></div></th>
	<?php } ?>
<?php } ?>
<?php if ($purchasepoitem_preview->cardpiid->Visible) { // cardpiid ?>
	<?php if ($purchasepoitem->SortUrl($purchasepoitem_preview->cardpiid) == "") { ?>
		<th class="<?php echo $purchasepoitem_preview->cardpiid->headerCellClass() ?>"><?php echo $purchasepoitem_preview->cardpiid->caption() ?></th>
	<?php } else { ?>
		<th class="<?php echo $purchasepoitem_preview->cardpiid->headerCellClass() ?>"><div class="ew-pointer" data-sort="<?php echo HtmlEncode($purchasepoitem_preview->cardpiid->Name) ?>" data-sort-order="<?php echo $purchasepoitem_preview->SortField == $purchasepoitem_preview->cardpiid->Name && $purchasepoitem_preview->SortOrder == "ASC" ? "DESC" : "ASC" ?>">
			<div class="ew-table-header-btn"><span class="ew-table-header-caption"><?php echo $purchasepoitem_preview->cardpiid->caption() ?></span><span class="ew-table-header-sort"><?php if ($purchasepoitem_preview->SortField == $purchasepoitem_preview->cardpiid->Name) { ?><?php if ($purchasepoitem_preview->SortOrder == "ASC") { ?><i class="fas fa-sort-up"></i><?php } elseif ($purchasepoitem_preview->SortOrder == "DESC") { ?><i class="fas fa-sort-down"></i><?php } ?><?php } ?></span>
		</div></div></th>
	<?php } ?>
<?php } ?>
<?php if ($purchasepoitem_preview->currcode->Visible) { // currcode ?>
	<?php if ($purchasepoitem->SortUrl($purchasepoitem_preview->currcode) == "") { ?>
		<th class="<?php echo $purchasepoitem_preview->currcode->headerCellClass() ?>"><?php echo $purchasepoitem_preview->currcode->caption() ?></th>
	<?php } else { ?>
		<th class="<?php echo $purchasepoitem_preview->currcode->headerCellClass() ?>"><div class="ew-pointer" data-sort="<?php echo HtmlEncode($purchasepoitem_preview->currcode->Name) ?>" data-sort-order="<?php echo $purchasepoitem_preview->SortField == $purchasepoitem_preview->currcode->Name && $purchasepoitem_preview->SortOrder == "ASC" ? "DESC" : "ASC" ?>">
			<div class="ew-table-header-btn"><span class="ew-table-header-caption"><?php echo $purchasepoitem_preview->currcode->caption() ?></span><span class="ew-table-header-sort"><?php if ($purchasepoitem_preview->SortField == $purchasepoitem_preview->currcode->Name) { ?><?php if ($purchasepoitem_preview->SortOrder == "ASC") { ?><i class="fas fa-sort-up"></i><?php } elseif ($purchasepoitem_preview->SortOrder == "DESC") { ?><i class="fas fa-sort-down"></i><?php } ?><?php } ?></span>
		</div></div></th>
	<?php } ?>
<?php } ?>
<?php if ($purchasepoitem_preview->denom->Visible) { // denom ?>
	<?php if ($purchasepoitem->SortUrl($purchasepoitem_preview->denom) == "") { ?>
		<th class="<?php echo $purchasepoitem_preview->denom->headerCellClass() ?>"><?php echo $purchasepoitem_preview->denom->caption() ?></th>
	<?php } else { ?>
		<th class="<?php echo $purchasepoitem_preview->denom->headerCellClass() ?>"><div class="ew-pointer" data-sort="<?php echo HtmlEncode($purchasepoitem_preview->denom->Name) ?>" data-sort-order="<?php echo $purchasepoitem_preview->SortField == $purchasepoitem_preview->denom->Name && $purchasepoitem_preview->SortOrder == "ASC" ? "DESC" : "ASC" ?>">
			<div class="ew-table-header-btn"><span class="ew-table-header-caption"><?php echo $purchasepoitem_preview->denom->caption() ?></span><span class="ew-table-header-sort"><?php if ($purchasepoitem_preview->SortField == $purchasepoitem_preview->denom->Name) { ?><?php if ($purchasepoitem_preview->SortOrder == "ASC") { ?><i class="fas fa-sort-up"></i><?php } elseif ($purchasepoitem_preview->SortOrder == "DESC") { ?><i class="fas fa-sort-down"></i><?php } ?><?php } ?></span>
		</div></div></th>
	<?php } ?>
<?php } ?>
<?php if ($purchasepoitem_preview->status->Visible) { // status ?>
	<?php if ($purchasepoitem->SortUrl($purchasepoitem_preview->status) == "") { ?>
		<th class="<?php echo $purchasepoitem_preview->status->headerCellClass() ?>"><?php echo $purchasepoitem_preview->status->caption() ?></th>
	<?php } else { ?>
		<th class="<?php echo $purchasepoitem_preview->status->headerCellClass() ?>"><div class="ew-pointer" data-sort="<?php echo HtmlEncode($purchasepoitem_preview->status->Name) ?>" data-sort-order="<?php echo $purchasepoitem_preview->SortField == $purchasepoitem_preview->status->Name && $purchasepoitem_preview->SortOrder == "ASC" ? "DESC" : "ASC" ?>">
			<div class="ew-table-header-btn"><span class="ew-table-header-caption"><?php echo $purchasepoitem_preview->status->caption() ?></span><span class="ew-table-header-sort"><?php if ($purchasepoitem_preview->SortField == $purchasepoitem_preview->status->Name) { ?><?php if ($purchasepoitem_preview->SortOrder == "ASC") { ?><i class="fas fa-sort-up"></i><?php } elseif ($purchasepoitem_preview->SortOrder == "DESC") { ?><i class="fas fa-sort-down"></i><?php } ?><?php } ?></span>
		</div></div></th>
	<?php } ?>
<?php } ?>
<?php if ($purchasepoitem_preview->userpi_id->Visible) { // userpi_id ?>
	<?php if ($purchasepoitem->SortUrl($purchasepoitem_preview->userpi_id) == "") { ?>
		<th class="<?php echo $purchasepoitem_preview->userpi_id->headerCellClass() ?>"><?php echo $purchasepoitem_preview->userpi_id->caption() ?></th>
	<?php } else { ?>
		<th class="<?php echo $purchasepoitem_preview->userpi_id->headerCellClass() ?>"><div class="ew-pointer" data-sort="<?php echo HtmlEncode($purchasepoitem_preview->userpi_id->Name) ?>" data-sort-order="<?php echo $purchasepoitem_preview->SortField == $purchasepoitem_preview->userpi_id->Name && $purchasepoitem_preview->SortOrder == "ASC" ? "DESC" : "ASC" ?>">
			<div class="ew-table-header-btn"><span class="ew-table-header-caption"><?php echo $purchasepoitem_preview->userpi_id->caption() ?></span><span class="ew-table-header-sort"><?php if ($purchasepoitem_preview->SortField == $purchasepoitem_preview->userpi_id->Name) { ?><?php if ($purchasepoitem_preview->SortOrder == "ASC") { ?><i class="fas fa-sort-up"></i><?php } elseif ($purchasepoitem_preview->SortOrder == "DESC") { ?><i class="fas fa-sort-down"></i><?php } ?><?php } ?></span>
		</div></div></th>
	<?php } ?>
<?php } ?>
<?php if ($purchasepoitem_preview->initiate_pi_transfer->Visible) { // initiate_pi_transfer ?>
	<?php if ($purchasepoitem->SortUrl($purchasepoitem_preview->initiate_pi_transfer) == "") { ?>
		<th class="<?php echo $purchasepoitem_preview->initiate_pi_transfer->headerCellClass() ?>"><?php echo $purchasepoitem_preview->initiate_pi_transfer->caption() ?></th>
	<?php } else { ?>
		<th class="<?php echo $purchasepoitem_preview->initiate_pi_transfer->headerCellClass() ?>"><div class="ew-pointer" data-sort="<?php echo HtmlEncode($purchasepoitem_preview->initiate_pi_transfer->Name) ?>" data-sort-order="<?php echo $purchasepoitem_preview->SortField == $purchasepoitem_preview->initiate_pi_transfer->Name && $purchasepoitem_preview->SortOrder == "ASC" ? "DESC" : "ASC" ?>">
			<div class="ew-table-header-btn"><span class="ew-table-header-caption"><?php echo $purchasepoitem_preview->initiate_pi_transfer->caption() ?></span><span class="ew-table-header-sort"><?php if ($purchasepoitem_preview->SortField == $purchasepoitem_preview->initiate_pi_transfer->Name) { ?><?php if ($purchasepoitem_preview->SortOrder == "ASC") { ?><i class="fas fa-sort-up"></i><?php } elseif ($purchasepoitem_preview->SortOrder == "DESC") { ?><i class="fas fa-sort-down"></i><?php } ?><?php } ?></span>
		</div></div></th>
	<?php } ?>
<?php } ?>
<?php if ($purchasepoitem_preview->is_email_send->Visible) { // is_email_send ?>
	<?php if ($purchasepoitem->SortUrl($purchasepoitem_preview->is_email_send) == "") { ?>
		<th class="<?php echo $purchasepoitem_preview->is_email_send->headerCellClass() ?>"><?php echo $purchasepoitem_preview->is_email_send->caption() ?></th>
	<?php } else { ?>
		<th class="<?php echo $purchasepoitem_preview->is_email_send->headerCellClass() ?>"><div class="ew-pointer" data-sort="<?php echo HtmlEncode($purchasepoitem_preview->is_email_send->Name) ?>" data-sort-order="<?php echo $purchasepoitem_preview->SortField == $purchasepoitem_preview->is_email_send->Name && $purchasepoitem_preview->SortOrder == "ASC" ? "DESC" : "ASC" ?>">
			<div class="ew-table-header-btn"><span class="ew-table-header-caption"><?php echo $purchasepoitem_preview->is_email_send->caption() ?></span><span class="ew-table-header-sort"><?php if ($purchasepoitem_preview->SortField == $purchasepoitem_preview->is_email_send->Name) { ?><?php if ($purchasepoitem_preview->SortOrder == "ASC") { ?><i class="fas fa-sort-up"></i><?php } elseif ($purchasepoitem_preview->SortOrder == "DESC") { ?><i class="fas fa-sort-down"></i><?php } ?><?php } ?></span>
		</div></div></th>
	<?php } ?>
<?php } ?>
<?php

// Render list options (header, right)
$purchasepoitem_preview->ListOptions->render("header", "right");
?>
		</tr>
	</thead>
	<tbody><!-- Table body -->
<?php
$purchasepoitem_preview->RecCount = 0;
$purchasepoitem_preview->RowCount = 0;
while ($purchasepoitem_preview->Recordset && !$purchasepoitem_preview->Recordset->EOF) {

	// Init row class and style
	$purchasepoitem_preview->RecCount++;
	$purchasepoitem_preview->RowCount++;
	$purchasepoitem_preview->CssStyle = "";
	$purchasepoitem_preview->loadListRowValues($purchasepoitem_preview->Recordset);

	// Render row
	$purchasepoitem->RowType = ROWTYPE_PREVIEW; // Preview record
	$purchasepoitem_preview->resetAttributes();
	$purchasepoitem_preview->renderListRow();

	// Render list options
	$purchasepoitem_preview->renderListOptions();
?>
	<tr <?php echo $purchasepoitem->rowAttributes() ?>>
<?php

// Render list options (body, left)
$purchasepoitem_preview->ListOptions->render("body", "left", $purchasepoitem_preview->RowCount);
?>
<?php if ($purchasepoitem_preview->itemid->Visible) { // itemid ?>
		<!-- itemid -->
		<td<?php echo $purchasepoitem_preview->itemid->cellAttributes() ?>>
<span<?php echo $purchasepoitem_preview->itemid->viewAttributes() ?>><?php echo $purchasepoitem_preview->itemid->getViewValue() ?></span>
</td>
<?php } ?>
<?php if ($purchasepoitem_preview->poid->Visible) { // poid ?>
		<!-- poid -->
		<td<?php echo $purchasepoitem_preview->poid->cellAttributes() ?>>
<span<?php echo $purchasepoitem_preview->poid->viewAttributes() ?>><?php echo $purchasepoitem_preview->poid->getViewValue() ?></span>
</td>
<?php } ?>
<?php if ($purchasepoitem_preview->cardpiid->Visible) { // cardpiid ?>
		<!-- cardpiid -->
		<td<?php echo $purchasepoitem_preview->cardpiid->cellAttributes() ?>>
<span<?php echo $purchasepoitem_preview->cardpiid->viewAttributes() ?>><?php echo $purchasepoitem_preview->cardpiid->getViewValue() ?></span>
</td>
<?php } ?>
<?php if ($purchasepoitem_preview->currcode->Visible) { // currcode ?>
		<!-- currcode -->
		<td<?php echo $purchasepoitem_preview->currcode->cellAttributes() ?>>
<span<?php echo $purchasepoitem_preview->currcode->viewAttributes() ?>><?php echo $purchasepoitem_preview->currcode->getViewValue() ?></span>
</td>
<?php } ?>
<?php if ($purchasepoitem_preview->denom->Visible) { // denom ?>
		<!-- denom -->
		<td<?php echo $purchasepoitem_preview->denom->cellAttributes() ?>>
<span<?php echo $purchasepoitem_preview->denom->viewAttributes() ?>><?php echo $purchasepoitem_preview->denom->getViewValue() ?></span>
</td>
<?php } ?>
<?php if ($purchasepoitem_preview->status->Visible) { // status ?>
		<!-- status -->
		<td<?php echo $purchasepoitem_preview->status->cellAttributes() ?>>
<span<?php echo $purchasepoitem_preview->status->viewAttributes() ?>><?php echo $purchasepoitem_preview->status->getViewValue() ?></span>
</td>
<?php } ?>
<?php if ($purchasepoitem_preview->userpi_id->Visible) { // userpi_id ?>
		<!-- userpi_id -->
		<td<?php echo $purchasepoitem_preview->userpi_id->cellAttributes() ?>>
<span<?php echo $purchasepoitem_preview->userpi_id->viewAttributes() ?>><?php echo $purchasepoitem_preview->userpi_id->getViewValue() ?></span>
</td>
<?php } ?>
<?php if ($purchasepoitem_preview->initiate_pi_transfer->Visible) { // initiate_pi_transfer ?>
		<!-- initiate_pi_transfer -->
		<td<?php echo $purchasepoitem_preview->initiate_pi_transfer->cellAttributes() ?>>
<span<?php echo $purchasepoitem_preview->initiate_pi_transfer->viewAttributes() ?>><?php echo $purchasepoitem_preview->initiate_pi_transfer->getViewValue() ?></span>
</td>
<?php } ?>
<?php if ($purchasepoitem_preview->is_email_send->Visible) { // is_email_send ?>
		<!-- is_email_send -->
		<td<?php echo $purchasepoitem_preview->is_email_send->cellAttributes() ?>>
<span<?php echo $purchasepoitem_preview->is_email_send->viewAttributes() ?>><?php echo $purchasepoitem_preview->is_email_send->getViewValue() ?></span>
</td>
<?php } ?>
<?php

// Render list options (body, right)
$purchasepoitem_preview->ListOptions->render("body", "right", $purchasepoitem_preview->RowCount);
?>
	</tr>
<?php
	$purchasepoitem_preview->Recordset->MoveNext();
} // while
?>
	</tbody>
</table><!-- /.table -->
</div><!-- /.table-responsive -->
<div class="card-footer ew-grid-lower-panel ew-preview-lower-panel"><!-- .card-footer -->
<?php echo $purchasepoitem_preview->Pager->render() ?>
<?php } else { // No record ?>
<div class="card no-border">
<div class="ew-detail-count"><?php echo $Language->phrase("NoRecord") ?></div>
<?php } ?>
<div class="ew-preview-other-options">
<?php
	foreach ($purchasepoitem_preview->OtherOptions as $option)
		$option->render("body");
?>
</div>
<?php if ($purchasepoitem_preview->TotalRecords > 0) { ?>
<div class="clearfix"></div>
</div><!-- /.card-footer -->
<?php } ?>
</div><!-- /.card -->
<?php
$purchasepoitem_preview->showPageFooter();
if (Config("DEBUG"))
	echo GetDebugMessage();
?>
<?php
if ($purchasepoitem_preview->Recordset)
	$purchasepoitem_preview->Recordset->Close();

// Output
$content = ob_get_contents();
ob_end_clean();
echo ConvertToUtf8($content);
?>
<?php
$purchasepoitem_preview->terminate();
?>