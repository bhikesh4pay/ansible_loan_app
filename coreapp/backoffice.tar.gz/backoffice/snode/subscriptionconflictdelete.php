<?php
namespace PHPMaker2020\_4payadmin;

// Autoload
include_once "autoload.php";

// Session
if (session_status() !== PHP_SESSION_ACTIVE)
	\Delight\Cookie\Session::start(Config("COOKIE_SAMESITE")); // Init session data

// Output buffering
ob_start();
?>
<?php

// Write header
WriteHeader(FALSE);

// Create page object
$subscriptionconflict_delete = new subscriptionconflict_delete();

// Run the page
$subscriptionconflict_delete->run();

// Setup login status
SetupLoginStatus();
SetClientVar("login", LoginStatus());

// Global Page Rendering event (in userfn*.php)
Page_Rendering();

// Page Rendering event
$subscriptionconflict_delete->Page_Render();
?>
<?php include_once "header.php"; ?>
<script>
var fsubscriptionconflictdelete, currentPageID;
loadjs.ready("head", function() {

	// Form object
	currentPageID = ew.PAGE_ID = "delete";
	fsubscriptionconflictdelete = currentForm = new ew.Form("fsubscriptionconflictdelete", "delete");
	loadjs.done("fsubscriptionconflictdelete");
});
</script>
<script>
loadjs.ready("head", function() {

	// Client script
	// Write your client script here, no need to add script tags.

});
</script>
<?php $subscriptionconflict_delete->showPageHeader(); ?>
<?php
$subscriptionconflict_delete->showMessage();
?>
<form name="fsubscriptionconflictdelete" id="fsubscriptionconflictdelete" class="form-inline ew-form ew-delete-form" action="<?php echo CurrentPageName() ?>" method="post">
<?php if ($Page->CheckToken) { ?>
<input type="hidden" name="<?php echo Config("TOKEN_NAME") ?>" value="<?php echo $Page->Token ?>">
<?php } ?>
<input type="hidden" name="t" value="subscriptionconflict">
<input type="hidden" name="action" id="action" value="delete">
<?php foreach ($subscriptionconflict_delete->RecKeys as $key) { ?>
<?php $keyvalue = is_array($key) ? implode(Config("COMPOSITE_KEY_SEPARATOR"), $key) : $key; ?>
<input type="hidden" name="key_m[]" value="<?php echo HtmlEncode($keyvalue) ?>">
<?php } ?>
<div class="card ew-card ew-grid">
<div class="<?php echo ResponsiveTableClass() ?>card-body ew-grid-middle-panel">
<table class="table ew-table">
	<thead>
	<tr class="ew-table-header">
<?php if ($subscriptionconflict_delete->subscriptionid->Visible) { // subscriptionid ?>
		<th class="<?php echo $subscriptionconflict_delete->subscriptionid->headerCellClass() ?>"><span id="elh_subscriptionconflict_subscriptionid" class="subscriptionconflict_subscriptionid"><?php echo $subscriptionconflict_delete->subscriptionid->caption() ?></span></th>
<?php } ?>
<?php if ($subscriptionconflict_delete->othersubscriptionid->Visible) { // othersubscriptionid ?>
		<th class="<?php echo $subscriptionconflict_delete->othersubscriptionid->headerCellClass() ?>"><span id="elh_subscriptionconflict_othersubscriptionid" class="subscriptionconflict_othersubscriptionid"><?php echo $subscriptionconflict_delete->othersubscriptionid->caption() ?></span></th>
<?php } ?>
<?php if ($subscriptionconflict_delete->active->Visible) { // active ?>
		<th class="<?php echo $subscriptionconflict_delete->active->headerCellClass() ?>"><span id="elh_subscriptionconflict_active" class="subscriptionconflict_active"><?php echo $subscriptionconflict_delete->active->caption() ?></span></th>
<?php } ?>
	</tr>
	</thead>
	<tbody>
<?php
$subscriptionconflict_delete->RecordCount = 0;
$i = 0;
while (!$subscriptionconflict_delete->Recordset->EOF) {
	$subscriptionconflict_delete->RecordCount++;
	$subscriptionconflict_delete->RowCount++;

	// Set row properties
	$subscriptionconflict->resetAttributes();
	$subscriptionconflict->RowType = ROWTYPE_VIEW; // View

	// Get the field contents
	$subscriptionconflict_delete->loadRowValues($subscriptionconflict_delete->Recordset);

	// Render row
	$subscriptionconflict_delete->renderRow();
?>
	<tr <?php echo $subscriptionconflict->rowAttributes() ?>>
<?php if ($subscriptionconflict_delete->subscriptionid->Visible) { // subscriptionid ?>
		<td <?php echo $subscriptionconflict_delete->subscriptionid->cellAttributes() ?>>
<span id="el<?php echo $subscriptionconflict_delete->RowCount ?>_subscriptionconflict_subscriptionid" class="subscriptionconflict_subscriptionid">
<span<?php echo $subscriptionconflict_delete->subscriptionid->viewAttributes() ?>><?php echo $subscriptionconflict_delete->subscriptionid->getViewValue() ?></span>
</span>
</td>
<?php } ?>
<?php if ($subscriptionconflict_delete->othersubscriptionid->Visible) { // othersubscriptionid ?>
		<td <?php echo $subscriptionconflict_delete->othersubscriptionid->cellAttributes() ?>>
<span id="el<?php echo $subscriptionconflict_delete->RowCount ?>_subscriptionconflict_othersubscriptionid" class="subscriptionconflict_othersubscriptionid">
<span<?php echo $subscriptionconflict_delete->othersubscriptionid->viewAttributes() ?>><?php echo $subscriptionconflict_delete->othersubscriptionid->getViewValue() ?></span>
</span>
</td>
<?php } ?>
<?php if ($subscriptionconflict_delete->active->Visible) { // active ?>
		<td <?php echo $subscriptionconflict_delete->active->cellAttributes() ?>>
<span id="el<?php echo $subscriptionconflict_delete->RowCount ?>_subscriptionconflict_active" class="subscriptionconflict_active">
<span<?php echo $subscriptionconflict_delete->active->viewAttributes() ?>><?php echo $subscriptionconflict_delete->active->getViewValue() ?></span>
</span>
</td>
<?php } ?>
	</tr>
<?php
	$subscriptionconflict_delete->Recordset->moveNext();
}
$subscriptionconflict_delete->Recordset->close();
?>
</tbody>
</table>
</div>
</div>
<div>
<button class="btn btn-primary ew-btn" name="btn-action" id="btn-action" type="submit"><?php echo $Language->phrase("DeleteBtn") ?></button>
<button class="btn btn-default ew-btn" name="btn-cancel" id="btn-cancel" type="button" data-href="<?php echo $subscriptionconflict_delete->getReturnUrl() ?>"><?php echo $Language->phrase("CancelBtn") ?></button>
</div>
</form>
<?php
$subscriptionconflict_delete->showPageFooter();
if (Config("DEBUG"))
	echo GetDebugMessage();
?>
<script>
loadjs.ready("load", function() {

	// Startup script
	// Write your table-specific startup script here
	// console.log("page loaded");

});
</script>
<?php include_once "footer.php"; ?>
<?php
$subscriptionconflict_delete->terminate();
?>