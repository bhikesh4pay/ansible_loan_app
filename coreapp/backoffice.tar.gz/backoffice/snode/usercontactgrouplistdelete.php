<?php
namespace PHPMaker2020\_4payadmin;

// Autoload
include_once "autoload.php";

// Session
if (session_status() !== PHP_SESSION_ACTIVE)
	\Delight\Cookie\Session::start(Config("COOKIE_SAMESITE")); // Init session data

// Output buffering
ob_start();
?>
<?php

// Write header
WriteHeader(FALSE);

// Create page object
$usercontactgrouplist_delete = new usercontactgrouplist_delete();

// Run the page
$usercontactgrouplist_delete->run();

// Setup login status
SetupLoginStatus();
SetClientVar("login", LoginStatus());

// Global Page Rendering event (in userfn*.php)
Page_Rendering();

// Page Rendering event
$usercontactgrouplist_delete->Page_Render();
?>
<?php include_once "header.php"; ?>
<script>
var fusercontactgrouplistdelete, currentPageID;
loadjs.ready("head", function() {

	// Form object
	currentPageID = ew.PAGE_ID = "delete";
	fusercontactgrouplistdelete = currentForm = new ew.Form("fusercontactgrouplistdelete", "delete");
	loadjs.done("fusercontactgrouplistdelete");
});
</script>
<script>
loadjs.ready("head", function() {

	// Client script
	// Write your client script here, no need to add script tags.

});
</script>
<?php $usercontactgrouplist_delete->showPageHeader(); ?>
<?php
$usercontactgrouplist_delete->showMessage();
?>
<form name="fusercontactgrouplistdelete" id="fusercontactgrouplistdelete" class="form-inline ew-form ew-delete-form" action="<?php echo CurrentPageName() ?>" method="post">
<?php if ($Page->CheckToken) { ?>
<input type="hidden" name="<?php echo Config("TOKEN_NAME") ?>" value="<?php echo $Page->Token ?>">
<?php } ?>
<input type="hidden" name="t" value="usercontactgrouplist">
<input type="hidden" name="action" id="action" value="delete">
<?php foreach ($usercontactgrouplist_delete->RecKeys as $key) { ?>
<?php $keyvalue = is_array($key) ? implode(Config("COMPOSITE_KEY_SEPARATOR"), $key) : $key; ?>
<input type="hidden" name="key_m[]" value="<?php echo HtmlEncode($keyvalue) ?>">
<?php } ?>
<div class="card ew-card ew-grid">
<div class="<?php echo ResponsiveTableClass() ?>card-body ew-grid-middle-panel">
<table class="table ew-table">
	<thead>
	<tr class="ew-table-header">
<?php if ($usercontactgrouplist_delete->groupid->Visible) { // groupid ?>
		<th class="<?php echo $usercontactgrouplist_delete->groupid->headerCellClass() ?>"><span id="elh_usercontactgrouplist_groupid" class="usercontactgrouplist_groupid"><?php echo $usercontactgrouplist_delete->groupid->caption() ?></span></th>
<?php } ?>
<?php if ($usercontactgrouplist_delete->_userid->Visible) { // userid ?>
		<th class="<?php echo $usercontactgrouplist_delete->_userid->headerCellClass() ?>"><span id="elh_usercontactgrouplist__userid" class="usercontactgrouplist__userid"><?php echo $usercontactgrouplist_delete->_userid->caption() ?></span></th>
<?php } ?>
	</tr>
	</thead>
	<tbody>
<?php
$usercontactgrouplist_delete->RecordCount = 0;
$i = 0;
while (!$usercontactgrouplist_delete->Recordset->EOF) {
	$usercontactgrouplist_delete->RecordCount++;
	$usercontactgrouplist_delete->RowCount++;

	// Set row properties
	$usercontactgrouplist->resetAttributes();
	$usercontactgrouplist->RowType = ROWTYPE_VIEW; // View

	// Get the field contents
	$usercontactgrouplist_delete->loadRowValues($usercontactgrouplist_delete->Recordset);

	// Render row
	$usercontactgrouplist_delete->renderRow();
?>
	<tr <?php echo $usercontactgrouplist->rowAttributes() ?>>
<?php if ($usercontactgrouplist_delete->groupid->Visible) { // groupid ?>
		<td <?php echo $usercontactgrouplist_delete->groupid->cellAttributes() ?>>
<span id="el<?php echo $usercontactgrouplist_delete->RowCount ?>_usercontactgrouplist_groupid" class="usercontactgrouplist_groupid">
<span<?php echo $usercontactgrouplist_delete->groupid->viewAttributes() ?>><?php echo $usercontactgrouplist_delete->groupid->getViewValue() ?></span>
</span>
</td>
<?php } ?>
<?php if ($usercontactgrouplist_delete->_userid->Visible) { // userid ?>
		<td <?php echo $usercontactgrouplist_delete->_userid->cellAttributes() ?>>
<span id="el<?php echo $usercontactgrouplist_delete->RowCount ?>_usercontactgrouplist__userid" class="usercontactgrouplist__userid">
<span<?php echo $usercontactgrouplist_delete->_userid->viewAttributes() ?>><?php echo $usercontactgrouplist_delete->_userid->getViewValue() ?></span>
</span>
</td>
<?php } ?>
	</tr>
<?php
	$usercontactgrouplist_delete->Recordset->moveNext();
}
$usercontactgrouplist_delete->Recordset->close();
?>
</tbody>
</table>
</div>
</div>
<div>
<button class="btn btn-primary ew-btn" name="btn-action" id="btn-action" type="submit"><?php echo $Language->phrase("DeleteBtn") ?></button>
<button class="btn btn-default ew-btn" name="btn-cancel" id="btn-cancel" type="button" data-href="<?php echo $usercontactgrouplist_delete->getReturnUrl() ?>"><?php echo $Language->phrase("CancelBtn") ?></button>
</div>
</form>
<?php
$usercontactgrouplist_delete->showPageFooter();
if (Config("DEBUG"))
	echo GetDebugMessage();
?>
<script>
loadjs.ready("load", function() {

	// Startup script
	// Write your table-specific startup script here
	// console.log("page loaded");

});
</script>
<?php include_once "footer.php"; ?>
<?php
$usercontactgrouplist_delete->terminate();
?>