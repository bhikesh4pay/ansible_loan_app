<?php
namespace PHPMaker2020\_4payadmin;

// Autoload
include_once "autoload.php";

// Session
if (session_status() !== PHP_SESSION_ACTIVE)
	\Delight\Cookie\Session::start(Config("COOKIE_SAMESITE")); // Init session data

// Output buffering
ob_start();
?>
<?php

// Write header
WriteHeader(FALSE);

// Create page object
$loanpaymentcancelrequests_delete = new loanpaymentcancelrequests_delete();

// Run the page
$loanpaymentcancelrequests_delete->run();

// Setup login status
SetupLoginStatus();
SetClientVar("login", LoginStatus());

// Global Page Rendering event (in userfn*.php)
Page_Rendering();

// Page Rendering event
$loanpaymentcancelrequests_delete->Page_Render();
?>
<?php include_once "header.php"; ?>
<script>
var floanpaymentcancelrequestsdelete, currentPageID;
loadjs.ready("head", function() {

	// Form object
	currentPageID = ew.PAGE_ID = "delete";
	floanpaymentcancelrequestsdelete = currentForm = new ew.Form("floanpaymentcancelrequestsdelete", "delete");
	loadjs.done("floanpaymentcancelrequestsdelete");
});
</script>
<script>
loadjs.ready("head", function() {

	// Client script
	// Write your client script here, no need to add script tags.

});
</script>
<?php $loanpaymentcancelrequests_delete->showPageHeader(); ?>
<?php
$loanpaymentcancelrequests_delete->showMessage();
?>
<form name="floanpaymentcancelrequestsdelete" id="floanpaymentcancelrequestsdelete" class="form-inline ew-form ew-delete-form" action="<?php echo CurrentPageName() ?>" method="post">
<?php if ($Page->CheckToken) { ?>
<input type="hidden" name="<?php echo Config("TOKEN_NAME") ?>" value="<?php echo $Page->Token ?>">
<?php } ?>
<input type="hidden" name="t" value="loanpaymentcancelrequests">
<input type="hidden" name="action" id="action" value="delete">
<?php foreach ($loanpaymentcancelrequests_delete->RecKeys as $key) { ?>
<?php $keyvalue = is_array($key) ? implode(Config("COMPOSITE_KEY_SEPARATOR"), $key) : $key; ?>
<input type="hidden" name="key_m[]" value="<?php echo HtmlEncode($keyvalue) ?>">
<?php } ?>
<div class="card ew-card ew-grid">
<div class="<?php echo ResponsiveTableClass() ?>card-body ew-grid-middle-panel">
<table class="table ew-table">
	<thead>
	<tr class="ew-table-header">
<?php if ($loanpaymentcancelrequests_delete->requestid->Visible) { // requestid ?>
		<th class="<?php echo $loanpaymentcancelrequests_delete->requestid->headerCellClass() ?>"><span id="elh_loanpaymentcancelrequests_requestid" class="loanpaymentcancelrequests_requestid"><?php echo $loanpaymentcancelrequests_delete->requestid->caption() ?></span></th>
<?php } ?>
<?php if ($loanpaymentcancelrequests_delete->_userid->Visible) { // userid ?>
		<th class="<?php echo $loanpaymentcancelrequests_delete->_userid->headerCellClass() ?>"><span id="elh_loanpaymentcancelrequests__userid" class="loanpaymentcancelrequests__userid"><?php echo $loanpaymentcancelrequests_delete->_userid->caption() ?></span></th>
<?php } ?>
<?php if ($loanpaymentcancelrequests_delete->requestdate->Visible) { // requestdate ?>
		<th class="<?php echo $loanpaymentcancelrequests_delete->requestdate->headerCellClass() ?>"><span id="elh_loanpaymentcancelrequests_requestdate" class="loanpaymentcancelrequests_requestdate"><?php echo $loanpaymentcancelrequests_delete->requestdate->caption() ?></span></th>
<?php } ?>
<?php if ($loanpaymentcancelrequests_delete->requestpaymentid->Visible) { // requestpaymentid ?>
		<th class="<?php echo $loanpaymentcancelrequests_delete->requestpaymentid->headerCellClass() ?>"><span id="elh_loanpaymentcancelrequests_requestpaymentid" class="loanpaymentcancelrequests_requestpaymentid"><?php echo $loanpaymentcancelrequests_delete->requestpaymentid->caption() ?></span></th>
<?php } ?>
<?php if ($loanpaymentcancelrequests_delete->cancellationrequestexternalrefno->Visible) { // cancellationrequestexternalrefno ?>
		<th class="<?php echo $loanpaymentcancelrequests_delete->cancellationrequestexternalrefno->headerCellClass() ?>"><span id="elh_loanpaymentcancelrequests_cancellationrequestexternalrefno" class="loanpaymentcancelrequests_cancellationrequestexternalrefno"><?php echo $loanpaymentcancelrequests_delete->cancellationrequestexternalrefno->caption() ?></span></th>
<?php } ?>
<?php if ($loanpaymentcancelrequests_delete->originalpaymentrequestexternalrefno->Visible) { // originalpaymentrequestexternalrefno ?>
		<th class="<?php echo $loanpaymentcancelrequests_delete->originalpaymentrequestexternalrefno->headerCellClass() ?>"><span id="elh_loanpaymentcancelrequests_originalpaymentrequestexternalrefno" class="loanpaymentcancelrequests_originalpaymentrequestexternalrefno"><?php echo $loanpaymentcancelrequests_delete->originalpaymentrequestexternalrefno->caption() ?></span></th>
<?php } ?>
<?php if ($loanpaymentcancelrequests_delete->cancelledpaymentid->Visible) { // cancelledpaymentid ?>
		<th class="<?php echo $loanpaymentcancelrequests_delete->cancelledpaymentid->headerCellClass() ?>"><span id="elh_loanpaymentcancelrequests_cancelledpaymentid" class="loanpaymentcancelrequests_cancelledpaymentid"><?php echo $loanpaymentcancelrequests_delete->cancelledpaymentid->caption() ?></span></th>
<?php } ?>
<?php if ($loanpaymentcancelrequests_delete->success->Visible) { // success ?>
		<th class="<?php echo $loanpaymentcancelrequests_delete->success->headerCellClass() ?>"><span id="elh_loanpaymentcancelrequests_success" class="loanpaymentcancelrequests_success"><?php echo $loanpaymentcancelrequests_delete->success->caption() ?></span></th>
<?php } ?>
<?php if ($loanpaymentcancelrequests_delete->loanids->Visible) { // loanids ?>
		<th class="<?php echo $loanpaymentcancelrequests_delete->loanids->headerCellClass() ?>"><span id="elh_loanpaymentcancelrequests_loanids" class="loanpaymentcancelrequests_loanids"><?php echo $loanpaymentcancelrequests_delete->loanids->caption() ?></span></th>
<?php } ?>
<?php if ($loanpaymentcancelrequests_delete->markedforqueue->Visible) { // markedforqueue ?>
		<th class="<?php echo $loanpaymentcancelrequests_delete->markedforqueue->headerCellClass() ?>"><span id="elh_loanpaymentcancelrequests_markedforqueue" class="loanpaymentcancelrequests_markedforqueue"><?php echo $loanpaymentcancelrequests_delete->markedforqueue->caption() ?></span></th>
<?php } ?>
<?php if ($loanpaymentcancelrequests_delete->timeclearedfromqueue->Visible) { // timeclearedfromqueue ?>
		<th class="<?php echo $loanpaymentcancelrequests_delete->timeclearedfromqueue->headerCellClass() ?>"><span id="elh_loanpaymentcancelrequests_timeclearedfromqueue" class="loanpaymentcancelrequests_timeclearedfromqueue"><?php echo $loanpaymentcancelrequests_delete->timeclearedfromqueue->caption() ?></span></th>
<?php } ?>
<?php if ($loanpaymentcancelrequests_delete->originalrequestid->Visible) { // originalrequestid ?>
		<th class="<?php echo $loanpaymentcancelrequests_delete->originalrequestid->headerCellClass() ?>"><span id="elh_loanpaymentcancelrequests_originalrequestid" class="loanpaymentcancelrequests_originalrequestid"><?php echo $loanpaymentcancelrequests_delete->originalrequestid->caption() ?></span></th>
<?php } ?>
<?php if ($loanpaymentcancelrequests_delete->currcode->Visible) { // currcode ?>
		<th class="<?php echo $loanpaymentcancelrequests_delete->currcode->headerCellClass() ?>"><span id="elh_loanpaymentcancelrequests_currcode" class="loanpaymentcancelrequests_currcode"><?php echo $loanpaymentcancelrequests_delete->currcode->caption() ?></span></th>
<?php } ?>
	</tr>
	</thead>
	<tbody>
<?php
$loanpaymentcancelrequests_delete->RecordCount = 0;
$i = 0;
while (!$loanpaymentcancelrequests_delete->Recordset->EOF) {
	$loanpaymentcancelrequests_delete->RecordCount++;
	$loanpaymentcancelrequests_delete->RowCount++;

	// Set row properties
	$loanpaymentcancelrequests->resetAttributes();
	$loanpaymentcancelrequests->RowType = ROWTYPE_VIEW; // View

	// Get the field contents
	$loanpaymentcancelrequests_delete->loadRowValues($loanpaymentcancelrequests_delete->Recordset);

	// Render row
	$loanpaymentcancelrequests_delete->renderRow();
?>
	<tr <?php echo $loanpaymentcancelrequests->rowAttributes() ?>>
<?php if ($loanpaymentcancelrequests_delete->requestid->Visible) { // requestid ?>
		<td <?php echo $loanpaymentcancelrequests_delete->requestid->cellAttributes() ?>>
<span id="el<?php echo $loanpaymentcancelrequests_delete->RowCount ?>_loanpaymentcancelrequests_requestid" class="loanpaymentcancelrequests_requestid">
<span<?php echo $loanpaymentcancelrequests_delete->requestid->viewAttributes() ?>><?php echo $loanpaymentcancelrequests_delete->requestid->getViewValue() ?></span>
</span>
</td>
<?php } ?>
<?php if ($loanpaymentcancelrequests_delete->_userid->Visible) { // userid ?>
		<td <?php echo $loanpaymentcancelrequests_delete->_userid->cellAttributes() ?>>
<span id="el<?php echo $loanpaymentcancelrequests_delete->RowCount ?>_loanpaymentcancelrequests__userid" class="loanpaymentcancelrequests__userid">
<span<?php echo $loanpaymentcancelrequests_delete->_userid->viewAttributes() ?>><?php if (!EmptyString($loanpaymentcancelrequests_delete->_userid->getViewValue()) && $loanpaymentcancelrequests_delete->_userid->linkAttributes() != "") { ?>
<a<?php echo $loanpaymentcancelrequests_delete->_userid->linkAttributes() ?>><?php echo $loanpaymentcancelrequests_delete->_userid->getViewValue() ?></a>
<?php } else { ?>
<?php echo $loanpaymentcancelrequests_delete->_userid->getViewValue() ?>
<?php } ?></span>
</span>
</td>
<?php } ?>
<?php if ($loanpaymentcancelrequests_delete->requestdate->Visible) { // requestdate ?>
		<td <?php echo $loanpaymentcancelrequests_delete->requestdate->cellAttributes() ?>>
<span id="el<?php echo $loanpaymentcancelrequests_delete->RowCount ?>_loanpaymentcancelrequests_requestdate" class="loanpaymentcancelrequests_requestdate">
<span<?php echo $loanpaymentcancelrequests_delete->requestdate->viewAttributes() ?>><?php echo $loanpaymentcancelrequests_delete->requestdate->getViewValue() ?></span>
</span>
</td>
<?php } ?>
<?php if ($loanpaymentcancelrequests_delete->requestpaymentid->Visible) { // requestpaymentid ?>
		<td <?php echo $loanpaymentcancelrequests_delete->requestpaymentid->cellAttributes() ?>>
<span id="el<?php echo $loanpaymentcancelrequests_delete->RowCount ?>_loanpaymentcancelrequests_requestpaymentid" class="loanpaymentcancelrequests_requestpaymentid">
<span<?php echo $loanpaymentcancelrequests_delete->requestpaymentid->viewAttributes() ?>><?php echo $loanpaymentcancelrequests_delete->requestpaymentid->getViewValue() ?></span>
</span>
</td>
<?php } ?>
<?php if ($loanpaymentcancelrequests_delete->cancellationrequestexternalrefno->Visible) { // cancellationrequestexternalrefno ?>
		<td <?php echo $loanpaymentcancelrequests_delete->cancellationrequestexternalrefno->cellAttributes() ?>>
<span id="el<?php echo $loanpaymentcancelrequests_delete->RowCount ?>_loanpaymentcancelrequests_cancellationrequestexternalrefno" class="loanpaymentcancelrequests_cancellationrequestexternalrefno">
<span<?php echo $loanpaymentcancelrequests_delete->cancellationrequestexternalrefno->viewAttributes() ?>><?php echo $loanpaymentcancelrequests_delete->cancellationrequestexternalrefno->getViewValue() ?></span>
</span>
</td>
<?php } ?>
<?php if ($loanpaymentcancelrequests_delete->originalpaymentrequestexternalrefno->Visible) { // originalpaymentrequestexternalrefno ?>
		<td <?php echo $loanpaymentcancelrequests_delete->originalpaymentrequestexternalrefno->cellAttributes() ?>>
<span id="el<?php echo $loanpaymentcancelrequests_delete->RowCount ?>_loanpaymentcancelrequests_originalpaymentrequestexternalrefno" class="loanpaymentcancelrequests_originalpaymentrequestexternalrefno">
<span<?php echo $loanpaymentcancelrequests_delete->originalpaymentrequestexternalrefno->viewAttributes() ?>><?php echo $loanpaymentcancelrequests_delete->originalpaymentrequestexternalrefno->getViewValue() ?></span>
</span>
</td>
<?php } ?>
<?php if ($loanpaymentcancelrequests_delete->cancelledpaymentid->Visible) { // cancelledpaymentid ?>
		<td <?php echo $loanpaymentcancelrequests_delete->cancelledpaymentid->cellAttributes() ?>>
<span id="el<?php echo $loanpaymentcancelrequests_delete->RowCount ?>_loanpaymentcancelrequests_cancelledpaymentid" class="loanpaymentcancelrequests_cancelledpaymentid">
<span<?php echo $loanpaymentcancelrequests_delete->cancelledpaymentid->viewAttributes() ?>><?php if (!EmptyString($loanpaymentcancelrequests_delete->cancelledpaymentid->getViewValue()) && $loanpaymentcancelrequests_delete->cancelledpaymentid->linkAttributes() != "") { ?>
<a<?php echo $loanpaymentcancelrequests_delete->cancelledpaymentid->linkAttributes() ?>><?php echo $loanpaymentcancelrequests_delete->cancelledpaymentid->getViewValue() ?></a>
<?php } else { ?>
<?php echo $loanpaymentcancelrequests_delete->cancelledpaymentid->getViewValue() ?>
<?php } ?></span>
</span>
</td>
<?php } ?>
<?php if ($loanpaymentcancelrequests_delete->success->Visible) { // success ?>
		<td <?php echo $loanpaymentcancelrequests_delete->success->cellAttributes() ?>>
<span id="el<?php echo $loanpaymentcancelrequests_delete->RowCount ?>_loanpaymentcancelrequests_success" class="loanpaymentcancelrequests_success">
<span<?php echo $loanpaymentcancelrequests_delete->success->viewAttributes() ?>><?php echo $loanpaymentcancelrequests_delete->success->getViewValue() ?></span>
</span>
</td>
<?php } ?>
<?php if ($loanpaymentcancelrequests_delete->loanids->Visible) { // loanids ?>
		<td <?php echo $loanpaymentcancelrequests_delete->loanids->cellAttributes() ?>>
<span id="el<?php echo $loanpaymentcancelrequests_delete->RowCount ?>_loanpaymentcancelrequests_loanids" class="loanpaymentcancelrequests_loanids">
<span<?php echo $loanpaymentcancelrequests_delete->loanids->viewAttributes() ?>><?php echo $loanpaymentcancelrequests_delete->loanids->getViewValue() ?></span>
</span>
</td>
<?php } ?>
<?php if ($loanpaymentcancelrequests_delete->markedforqueue->Visible) { // markedforqueue ?>
		<td <?php echo $loanpaymentcancelrequests_delete->markedforqueue->cellAttributes() ?>>
<span id="el<?php echo $loanpaymentcancelrequests_delete->RowCount ?>_loanpaymentcancelrequests_markedforqueue" class="loanpaymentcancelrequests_markedforqueue">
<span<?php echo $loanpaymentcancelrequests_delete->markedforqueue->viewAttributes() ?>><?php echo $loanpaymentcancelrequests_delete->markedforqueue->getViewValue() ?></span>
</span>
</td>
<?php } ?>
<?php if ($loanpaymentcancelrequests_delete->timeclearedfromqueue->Visible) { // timeclearedfromqueue ?>
		<td <?php echo $loanpaymentcancelrequests_delete->timeclearedfromqueue->cellAttributes() ?>>
<span id="el<?php echo $loanpaymentcancelrequests_delete->RowCount ?>_loanpaymentcancelrequests_timeclearedfromqueue" class="loanpaymentcancelrequests_timeclearedfromqueue">
<span<?php echo $loanpaymentcancelrequests_delete->timeclearedfromqueue->viewAttributes() ?>><?php echo $loanpaymentcancelrequests_delete->timeclearedfromqueue->getViewValue() ?></span>
</span>
</td>
<?php } ?>
<?php if ($loanpaymentcancelrequests_delete->originalrequestid->Visible) { // originalrequestid ?>
		<td <?php echo $loanpaymentcancelrequests_delete->originalrequestid->cellAttributes() ?>>
<span id="el<?php echo $loanpaymentcancelrequests_delete->RowCount ?>_loanpaymentcancelrequests_originalrequestid" class="loanpaymentcancelrequests_originalrequestid">
<span<?php echo $loanpaymentcancelrequests_delete->originalrequestid->viewAttributes() ?>><?php echo $loanpaymentcancelrequests_delete->originalrequestid->getViewValue() ?></span>
</span>
</td>
<?php } ?>
<?php if ($loanpaymentcancelrequests_delete->currcode->Visible) { // currcode ?>
		<td <?php echo $loanpaymentcancelrequests_delete->currcode->cellAttributes() ?>>
<span id="el<?php echo $loanpaymentcancelrequests_delete->RowCount ?>_loanpaymentcancelrequests_currcode" class="loanpaymentcancelrequests_currcode">
<span<?php echo $loanpaymentcancelrequests_delete->currcode->viewAttributes() ?>><?php echo $loanpaymentcancelrequests_delete->currcode->getViewValue() ?></span>
</span>
</td>
<?php } ?>
	</tr>
<?php
	$loanpaymentcancelrequests_delete->Recordset->moveNext();
}
$loanpaymentcancelrequests_delete->Recordset->close();
?>
</tbody>
</table>
</div>
</div>
<div>
<button class="btn btn-primary ew-btn" name="btn-action" id="btn-action" type="submit"><?php echo $Language->phrase("DeleteBtn") ?></button>
<button class="btn btn-default ew-btn" name="btn-cancel" id="btn-cancel" type="button" data-href="<?php echo $loanpaymentcancelrequests_delete->getReturnUrl() ?>"><?php echo $Language->phrase("CancelBtn") ?></button>
</div>
</form>
<?php
$loanpaymentcancelrequests_delete->showPageFooter();
if (Config("DEBUG"))
	echo GetDebugMessage();
?>
<script>
loadjs.ready("load", function() {

	// Startup script
	// Write your table-specific startup script here
	// console.log("page loaded");

});
</script>
<?php include_once "footer.php"; ?>
<?php
$loanpaymentcancelrequests_delete->terminate();
?>