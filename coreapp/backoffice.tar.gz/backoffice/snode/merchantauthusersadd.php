<?php
namespace PHPMaker2020\_4payadmin;

// Autoload
include_once "autoload.php";

// Session
if (session_status() !== PHP_SESSION_ACTIVE)
	\Delight\Cookie\Session::start(Config("COOKIE_SAMESITE")); // Init session data

// Output buffering
ob_start();
?>
<?php

// Write header
WriteHeader(FALSE);

// Create page object
$merchantauthusers_add = new merchantauthusers_add();

// Run the page
$merchantauthusers_add->run();

// Setup login status
SetupLoginStatus();
SetClientVar("login", LoginStatus());

// Global Page Rendering event (in userfn*.php)
Page_Rendering();

// Page Rendering event
$merchantauthusers_add->Page_Render();
?>
<?php include_once "header.php"; ?>
<script>
var fmerchantauthusersadd, currentPageID;
loadjs.ready("head", function() {

	// Form object
	currentPageID = ew.PAGE_ID = "add";
	fmerchantauthusersadd = currentForm = new ew.Form("fmerchantauthusersadd", "add");

	// Validate form
	fmerchantauthusersadd.validate = function() {
		if (!this.validateRequired)
			return true; // Ignore validation
		var $ = jQuery, fobj = this.getForm(), $fobj = $(fobj);
		if ($fobj.find("#confirm").val() == "confirm")
			return true;
		var elm, felm, uelm, addcnt = 0;
		var $k = $fobj.find("#" + this.formKeyCountName); // Get key_count
		var rowcnt = ($k[0]) ? parseInt($k.val(), 10) : 1;
		var startcnt = (rowcnt == 0) ? 0 : 1; // Check rowcnt == 0 => Inline-Add
		var gridinsert = ["insert", "gridinsert"].includes($fobj.find("#action").val()) && $k[0];
		for (var i = startcnt; i <= rowcnt; i++) {
			var infix = ($k[0]) ? String(i) : "";
			$fobj.data("rowindex", infix);
			<?php if ($merchantauthusers_add->merchantid->Required) { ?>
				elm = this.getElements("x" + infix + "_merchantid");
				if (elm && !ew.isHidden(elm) && !ew.hasValue(elm))
					return this.onError(elm, "<?php echo JsEncode(str_replace("%s", $merchantauthusers_add->merchantid->caption(), $merchantauthusers_add->merchantid->RequiredErrorMessage)) ?>");
			<?php } ?>
				elm = this.getElements("x" + infix + "_merchantid");
				if (elm && !ew.checkInteger(elm.value))
					return this.onError(elm, "<?php echo JsEncode($merchantauthusers_add->merchantid->errorMessage()) ?>");
			<?php if ($merchantauthusers_add->profileid->Required) { ?>
				elm = this.getElements("x" + infix + "_profileid");
				if (elm && !ew.isHidden(elm) && !ew.hasValue(elm))
					return this.onError(elm, "<?php echo JsEncode(str_replace("%s", $merchantauthusers_add->profileid->caption(), $merchantauthusers_add->profileid->RequiredErrorMessage)) ?>");
			<?php } ?>
				elm = this.getElements("x" + infix + "_profileid");
				if (elm && !ew.checkInteger(elm.value))
					return this.onError(elm, "<?php echo JsEncode($merchantauthusers_add->profileid->errorMessage()) ?>");
			<?php if ($merchantauthusers_add->_userid->Required) { ?>
				elm = this.getElements("x" + infix + "__userid");
				if (elm && !ew.isHidden(elm) && !ew.hasValue(elm))
					return this.onError(elm, "<?php echo JsEncode(str_replace("%s", $merchantauthusers_add->_userid->caption(), $merchantauthusers_add->_userid->RequiredErrorMessage)) ?>");
			<?php } ?>
				elm = this.getElements("x" + infix + "__userid");
				if (elm && !ew.checkInteger(elm.value))
					return this.onError(elm, "<?php echo JsEncode($merchantauthusers_add->_userid->errorMessage()) ?>");
			<?php if ($merchantauthusers_add->active->Required) { ?>
				elm = this.getElements("x" + infix + "_active");
				if (elm && !ew.isHidden(elm) && !ew.hasValue(elm))
					return this.onError(elm, "<?php echo JsEncode(str_replace("%s", $merchantauthusers_add->active->caption(), $merchantauthusers_add->active->RequiredErrorMessage)) ?>");
			<?php } ?>
				elm = this.getElements("x" + infix + "_active");
				if (elm && !ew.checkInteger(elm.value))
					return this.onError(elm, "<?php echo JsEncode($merchantauthusers_add->active->errorMessage()) ?>");
			<?php if ($merchantauthusers_add->lastupdatetime->Required) { ?>
				elm = this.getElements("x" + infix + "_lastupdatetime");
				if (elm && !ew.isHidden(elm) && !ew.hasValue(elm))
					return this.onError(elm, "<?php echo JsEncode(str_replace("%s", $merchantauthusers_add->lastupdatetime->caption(), $merchantauthusers_add->lastupdatetime->RequiredErrorMessage)) ?>");
			<?php } ?>
				elm = this.getElements("x" + infix + "_lastupdatetime");
				if (elm && !ew.checkDateDef(elm.value))
					return this.onError(elm, "<?php echo JsEncode($merchantauthusers_add->lastupdatetime->errorMessage()) ?>");
			<?php if ($merchantauthusers_add->lastaccessdate->Required) { ?>
				elm = this.getElements("x" + infix + "_lastaccessdate");
				if (elm && !ew.isHidden(elm) && !ew.hasValue(elm))
					return this.onError(elm, "<?php echo JsEncode(str_replace("%s", $merchantauthusers_add->lastaccessdate->caption(), $merchantauthusers_add->lastaccessdate->RequiredErrorMessage)) ?>");
			<?php } ?>
				elm = this.getElements("x" + infix + "_lastaccessdate");
				if (elm && !ew.checkDateDef(elm.value))
					return this.onError(elm, "<?php echo JsEncode($merchantauthusers_add->lastaccessdate->errorMessage()) ?>");
			<?php if ($merchantauthusers_add->userdata->Required) { ?>
				elm = this.getElements("x" + infix + "_userdata");
				if (elm && !ew.isHidden(elm) && !ew.hasValue(elm))
					return this.onError(elm, "<?php echo JsEncode(str_replace("%s", $merchantauthusers_add->userdata->caption(), $merchantauthusers_add->userdata->RequiredErrorMessage)) ?>");
			<?php } ?>

				// Call Form_CustomValidate event
				if (!this.Form_CustomValidate(fobj))
					return false;
		}

		// Process detail forms
		var dfs = $fobj.find("input[name='detailpage']").get();
		for (var i = 0; i < dfs.length; i++) {
			var df = dfs[i], val = df.value;
			if (val && ew.forms[val])
				if (!ew.forms[val].validate())
					return false;
		}
		return true;
	}

	// Form_CustomValidate
	fmerchantauthusersadd.Form_CustomValidate = function(fobj) { // DO NOT CHANGE THIS LINE!

		// Your custom validation code here, return false if invalid.
		return true;
	}

	// Use JavaScript validation or not
	fmerchantauthusersadd.validateRequired = <?php echo Config("CLIENT_VALIDATE") ? "true" : "false" ?>;

	// Dynamic selection lists
	loadjs.done("fmerchantauthusersadd");
});
</script>
<script>
loadjs.ready("head", function() {

	// Client script
	// Write your client script here, no need to add script tags.

});
</script>
<?php $merchantauthusers_add->showPageHeader(); ?>
<?php
$merchantauthusers_add->showMessage();
?>
<form name="fmerchantauthusersadd" id="fmerchantauthusersadd" class="<?php echo $merchantauthusers_add->FormClassName ?>" action="<?php echo CurrentPageName() ?>" method="post">
<?php if ($Page->CheckToken) { ?>
<input type="hidden" name="<?php echo Config("TOKEN_NAME") ?>" value="<?php echo $Page->Token ?>">
<?php } ?>
<input type="hidden" name="t" value="merchantauthusers">
<input type="hidden" name="action" id="action" value="insert">
<input type="hidden" name="modal" value="<?php echo (int)$merchantauthusers_add->IsModal ?>">
<div class="ew-add-div"><!-- page* -->
<?php if ($merchantauthusers_add->merchantid->Visible) { // merchantid ?>
	<div id="r_merchantid" class="form-group row">
		<label id="elh_merchantauthusers_merchantid" for="x_merchantid" class="<?php echo $merchantauthusers_add->LeftColumnClass ?>"><?php echo $merchantauthusers_add->merchantid->caption() ?><?php echo $merchantauthusers_add->merchantid->Required ? $Language->phrase("FieldRequiredIndicator") : "" ?></label>
		<div class="<?php echo $merchantauthusers_add->RightColumnClass ?>"><div <?php echo $merchantauthusers_add->merchantid->cellAttributes() ?>>
<span id="el_merchantauthusers_merchantid">
<input type="text" data-table="merchantauthusers" data-field="x_merchantid" name="x_merchantid" id="x_merchantid" size="30" placeholder="<?php echo HtmlEncode($merchantauthusers_add->merchantid->getPlaceHolder()) ?>" value="<?php echo $merchantauthusers_add->merchantid->EditValue ?>"<?php echo $merchantauthusers_add->merchantid->editAttributes() ?>>
</span>
<?php echo $merchantauthusers_add->merchantid->CustomMsg ?></div></div>
	</div>
<?php } ?>
<?php if ($merchantauthusers_add->profileid->Visible) { // profileid ?>
	<div id="r_profileid" class="form-group row">
		<label id="elh_merchantauthusers_profileid" for="x_profileid" class="<?php echo $merchantauthusers_add->LeftColumnClass ?>"><?php echo $merchantauthusers_add->profileid->caption() ?><?php echo $merchantauthusers_add->profileid->Required ? $Language->phrase("FieldRequiredIndicator") : "" ?></label>
		<div class="<?php echo $merchantauthusers_add->RightColumnClass ?>"><div <?php echo $merchantauthusers_add->profileid->cellAttributes() ?>>
<span id="el_merchantauthusers_profileid">
<input type="text" data-table="merchantauthusers" data-field="x_profileid" name="x_profileid" id="x_profileid" size="30" placeholder="<?php echo HtmlEncode($merchantauthusers_add->profileid->getPlaceHolder()) ?>" value="<?php echo $merchantauthusers_add->profileid->EditValue ?>"<?php echo $merchantauthusers_add->profileid->editAttributes() ?>>
</span>
<?php echo $merchantauthusers_add->profileid->CustomMsg ?></div></div>
	</div>
<?php } ?>
<?php if ($merchantauthusers_add->_userid->Visible) { // userid ?>
	<div id="r__userid" class="form-group row">
		<label id="elh_merchantauthusers__userid" for="x__userid" class="<?php echo $merchantauthusers_add->LeftColumnClass ?>"><?php echo $merchantauthusers_add->_userid->caption() ?><?php echo $merchantauthusers_add->_userid->Required ? $Language->phrase("FieldRequiredIndicator") : "" ?></label>
		<div class="<?php echo $merchantauthusers_add->RightColumnClass ?>"><div <?php echo $merchantauthusers_add->_userid->cellAttributes() ?>>
<span id="el_merchantauthusers__userid">
<input type="text" data-table="merchantauthusers" data-field="x__userid" name="x__userid" id="x__userid" size="30" placeholder="<?php echo HtmlEncode($merchantauthusers_add->_userid->getPlaceHolder()) ?>" value="<?php echo $merchantauthusers_add->_userid->EditValue ?>"<?php echo $merchantauthusers_add->_userid->editAttributes() ?>>
</span>
<?php echo $merchantauthusers_add->_userid->CustomMsg ?></div></div>
	</div>
<?php } ?>
<?php if ($merchantauthusers_add->active->Visible) { // active ?>
	<div id="r_active" class="form-group row">
		<label id="elh_merchantauthusers_active" for="x_active" class="<?php echo $merchantauthusers_add->LeftColumnClass ?>"><?php echo $merchantauthusers_add->active->caption() ?><?php echo $merchantauthusers_add->active->Required ? $Language->phrase("FieldRequiredIndicator") : "" ?></label>
		<div class="<?php echo $merchantauthusers_add->RightColumnClass ?>"><div <?php echo $merchantauthusers_add->active->cellAttributes() ?>>
<span id="el_merchantauthusers_active">
<input type="text" data-table="merchantauthusers" data-field="x_active" name="x_active" id="x_active" size="30" placeholder="<?php echo HtmlEncode($merchantauthusers_add->active->getPlaceHolder()) ?>" value="<?php echo $merchantauthusers_add->active->EditValue ?>"<?php echo $merchantauthusers_add->active->editAttributes() ?>>
</span>
<?php echo $merchantauthusers_add->active->CustomMsg ?></div></div>
	</div>
<?php } ?>
<?php if ($merchantauthusers_add->lastupdatetime->Visible) { // lastupdatetime ?>
	<div id="r_lastupdatetime" class="form-group row">
		<label id="elh_merchantauthusers_lastupdatetime" for="x_lastupdatetime" class="<?php echo $merchantauthusers_add->LeftColumnClass ?>"><?php echo $merchantauthusers_add->lastupdatetime->caption() ?><?php echo $merchantauthusers_add->lastupdatetime->Required ? $Language->phrase("FieldRequiredIndicator") : "" ?></label>
		<div class="<?php echo $merchantauthusers_add->RightColumnClass ?>"><div <?php echo $merchantauthusers_add->lastupdatetime->cellAttributes() ?>>
<span id="el_merchantauthusers_lastupdatetime">
<input type="text" data-table="merchantauthusers" data-field="x_lastupdatetime" name="x_lastupdatetime" id="x_lastupdatetime" placeholder="<?php echo HtmlEncode($merchantauthusers_add->lastupdatetime->getPlaceHolder()) ?>" value="<?php echo $merchantauthusers_add->lastupdatetime->EditValue ?>"<?php echo $merchantauthusers_add->lastupdatetime->editAttributes() ?>>
</span>
<?php echo $merchantauthusers_add->lastupdatetime->CustomMsg ?></div></div>
	</div>
<?php } ?>
<?php if ($merchantauthusers_add->lastaccessdate->Visible) { // lastaccessdate ?>
	<div id="r_lastaccessdate" class="form-group row">
		<label id="elh_merchantauthusers_lastaccessdate" for="x_lastaccessdate" class="<?php echo $merchantauthusers_add->LeftColumnClass ?>"><?php echo $merchantauthusers_add->lastaccessdate->caption() ?><?php echo $merchantauthusers_add->lastaccessdate->Required ? $Language->phrase("FieldRequiredIndicator") : "" ?></label>
		<div class="<?php echo $merchantauthusers_add->RightColumnClass ?>"><div <?php echo $merchantauthusers_add->lastaccessdate->cellAttributes() ?>>
<span id="el_merchantauthusers_lastaccessdate">
<input type="text" data-table="merchantauthusers" data-field="x_lastaccessdate" name="x_lastaccessdate" id="x_lastaccessdate" placeholder="<?php echo HtmlEncode($merchantauthusers_add->lastaccessdate->getPlaceHolder()) ?>" value="<?php echo $merchantauthusers_add->lastaccessdate->EditValue ?>"<?php echo $merchantauthusers_add->lastaccessdate->editAttributes() ?>>
</span>
<?php echo $merchantauthusers_add->lastaccessdate->CustomMsg ?></div></div>
	</div>
<?php } ?>
<?php if ($merchantauthusers_add->userdata->Visible) { // userdata ?>
	<div id="r_userdata" class="form-group row">
		<label id="elh_merchantauthusers_userdata" for="x_userdata" class="<?php echo $merchantauthusers_add->LeftColumnClass ?>"><?php echo $merchantauthusers_add->userdata->caption() ?><?php echo $merchantauthusers_add->userdata->Required ? $Language->phrase("FieldRequiredIndicator") : "" ?></label>
		<div class="<?php echo $merchantauthusers_add->RightColumnClass ?>"><div <?php echo $merchantauthusers_add->userdata->cellAttributes() ?>>
<span id="el_merchantauthusers_userdata">
<input type="text" data-table="merchantauthusers" data-field="x_userdata" name="x_userdata" id="x_userdata" size="30" maxlength="50" placeholder="<?php echo HtmlEncode($merchantauthusers_add->userdata->getPlaceHolder()) ?>" value="<?php echo $merchantauthusers_add->userdata->EditValue ?>"<?php echo $merchantauthusers_add->userdata->editAttributes() ?>>
</span>
<?php echo $merchantauthusers_add->userdata->CustomMsg ?></div></div>
	</div>
<?php } ?>
</div><!-- /page* -->
<?php if (!$merchantauthusers_add->IsModal) { ?>
<div class="form-group row"><!-- buttons .form-group -->
	<div class="<?php echo $merchantauthusers_add->OffsetColumnClass ?>"><!-- buttons offset -->
<button class="btn btn-primary ew-btn" name="btn-action" id="btn-action" type="submit"><?php echo $Language->phrase("AddBtn") ?></button>
<button class="btn btn-default ew-btn" name="btn-cancel" id="btn-cancel" type="button" data-href="<?php echo $merchantauthusers_add->getReturnUrl() ?>"><?php echo $Language->phrase("CancelBtn") ?></button>
	</div><!-- /buttons offset -->
</div><!-- /buttons .form-group -->
<?php } ?>
</form>
<?php
$merchantauthusers_add->showPageFooter();
if (Config("DEBUG"))
	echo GetDebugMessage();
?>
<script>
loadjs.ready("load", function() {

	// Startup script
	// Write your table-specific startup script here
	// console.log("page loaded");

});
</script>
<?php include_once "footer.php"; ?>
<?php
$merchantauthusers_add->terminate();
?>