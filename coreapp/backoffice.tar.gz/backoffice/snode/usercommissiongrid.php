<?php
namespace PHPMaker2020\_4payadmin;

// Write header
WriteHeader(FALSE);

// Create page object
if (!isset($usercommission_grid))
	$usercommission_grid = new usercommission_grid();

// Run the page
$usercommission_grid->run();

// Setup login status
SetupLoginStatus();
SetClientVar("login", LoginStatus());

// Global Page Rendering event (in userfn*.php)
Page_Rendering();

// Page Rendering event
$usercommission_grid->Page_Render();
?>
<?php if (!$usercommission_grid->isExport()) { ?>
<script>
var fusercommissiongrid, currentPageID;
loadjs.ready("head", function() {

	// Form object
	fusercommissiongrid = new ew.Form("fusercommissiongrid", "grid");
	fusercommissiongrid.formKeyCountName = '<?php echo $usercommission_grid->FormKeyCountName ?>';

	// Validate form
	fusercommissiongrid.validate = function() {
		if (!this.validateRequired)
			return true; // Ignore validation
		var $ = jQuery, fobj = this.getForm(), $fobj = $(fobj);
		if ($fobj.find("#confirm").val() == "confirm")
			return true;
		var elm, felm, uelm, addcnt = 0;
		var $k = $fobj.find("#" + this.formKeyCountName); // Get key_count
		var rowcnt = ($k[0]) ? parseInt($k.val(), 10) : 1;
		var startcnt = (rowcnt == 0) ? 0 : 1; // Check rowcnt == 0 => Inline-Add
		var gridinsert = ["insert", "gridinsert"].includes($fobj.find("#action").val()) && $k[0];
		for (var i = startcnt; i <= rowcnt; i++) {
			var infix = ($k[0]) ? String(i) : "";
			$fobj.data("rowindex", infix);
			var checkrow = (gridinsert) ? !this.emptyRow(infix) : true;
			if (checkrow) {
				addcnt++;
			<?php if ($usercommission_grid->recid->Required) { ?>
				elm = this.getElements("x" + infix + "_recid");
				if (elm && !ew.isHidden(elm) && !ew.hasValue(elm))
					return this.onError(elm, "<?php echo JsEncode(str_replace("%s", $usercommission_grid->recid->caption(), $usercommission_grid->recid->RequiredErrorMessage)) ?>");
			<?php } ?>
			<?php if ($usercommission_grid->_userid->Required) { ?>
				elm = this.getElements("x" + infix + "__userid");
				if (elm && !ew.isHidden(elm) && !ew.hasValue(elm))
					return this.onError(elm, "<?php echo JsEncode(str_replace("%s", $usercommission_grid->_userid->caption(), $usercommission_grid->_userid->RequiredErrorMessage)) ?>");
			<?php } ?>
				elm = this.getElements("x" + infix + "__userid");
				if (elm && !ew.checkInteger(elm.value))
					return this.onError(elm, "<?php echo JsEncode($usercommission_grid->_userid->errorMessage()) ?>");
			<?php if ($usercommission_grid->userpi->Required) { ?>
				elm = this.getElements("x" + infix + "_userpi");
				if (elm && !ew.isHidden(elm) && !ew.hasValue(elm))
					return this.onError(elm, "<?php echo JsEncode(str_replace("%s", $usercommission_grid->userpi->caption(), $usercommission_grid->userpi->RequiredErrorMessage)) ?>");
			<?php } ?>
				elm = this.getElements("x" + infix + "_userpi");
				if (elm && !ew.checkInteger(elm.value))
					return this.onError(elm, "<?php echo JsEncode($usercommission_grid->userpi->errorMessage()) ?>");
			<?php if ($usercommission_grid->category->Required) { ?>
				elm = this.getElements("x" + infix + "_category");
				if (elm && !ew.isHidden(elm) && !ew.hasValue(elm))
					return this.onError(elm, "<?php echo JsEncode(str_replace("%s", $usercommission_grid->category->caption(), $usercommission_grid->category->RequiredErrorMessage)) ?>");
			<?php } ?>
				elm = this.getElements("x" + infix + "_category");
				if (elm && !ew.checkInteger(elm.value))
					return this.onError(elm, "<?php echo JsEncode($usercommission_grid->category->errorMessage()) ?>");
			<?php if ($usercommission_grid->transactiondate->Required) { ?>
				elm = this.getElements("x" + infix + "_transactiondate");
				if (elm && !ew.isHidden(elm) && !ew.hasValue(elm))
					return this.onError(elm, "<?php echo JsEncode(str_replace("%s", $usercommission_grid->transactiondate->caption(), $usercommission_grid->transactiondate->RequiredErrorMessage)) ?>");
			<?php } ?>
				elm = this.getElements("x" + infix + "_transactiondate");
				if (elm && !ew.checkDateDef(elm.value))
					return this.onError(elm, "<?php echo JsEncode($usercommission_grid->transactiondate->errorMessage()) ?>");
			<?php if ($usercommission_grid->commissionamount->Required) { ?>
				elm = this.getElements("x" + infix + "_commissionamount");
				if (elm && !ew.isHidden(elm) && !ew.hasValue(elm))
					return this.onError(elm, "<?php echo JsEncode(str_replace("%s", $usercommission_grid->commissionamount->caption(), $usercommission_grid->commissionamount->RequiredErrorMessage)) ?>");
			<?php } ?>
				elm = this.getElements("x" + infix + "_commissionamount");
				if (elm && !ew.checkNumber(elm.value))
					return this.onError(elm, "<?php echo JsEncode($usercommission_grid->commissionamount->errorMessage()) ?>");
			<?php if ($usercommission_grid->payoutdate->Required) { ?>
				elm = this.getElements("x" + infix + "_payoutdate");
				if (elm && !ew.isHidden(elm) && !ew.hasValue(elm))
					return this.onError(elm, "<?php echo JsEncode(str_replace("%s", $usercommission_grid->payoutdate->caption(), $usercommission_grid->payoutdate->RequiredErrorMessage)) ?>");
			<?php } ?>
				elm = this.getElements("x" + infix + "_payoutdate");
				if (elm && !ew.checkDateDef(elm.value))
					return this.onError(elm, "<?php echo JsEncode($usercommission_grid->payoutdate->errorMessage()) ?>");
			<?php if ($usercommission_grid->desc->Required) { ?>
				elm = this.getElements("x" + infix + "_desc");
				if (elm && !ew.isHidden(elm) && !ew.hasValue(elm))
					return this.onError(elm, "<?php echo JsEncode(str_replace("%s", $usercommission_grid->desc->caption(), $usercommission_grid->desc->RequiredErrorMessage)) ?>");
			<?php } ?>
			<?php if ($usercommission_grid->paid->Required) { ?>
				elm = this.getElements("x" + infix + "_paid");
				if (elm && !ew.isHidden(elm) && !ew.hasValue(elm))
					return this.onError(elm, "<?php echo JsEncode(str_replace("%s", $usercommission_grid->paid->caption(), $usercommission_grid->paid->RequiredErrorMessage)) ?>");
			<?php } ?>
				elm = this.getElements("x" + infix + "_paid");
				if (elm && !ew.checkInteger(elm.value))
					return this.onError(elm, "<?php echo JsEncode($usercommission_grid->paid->errorMessage()) ?>");

				// Call Form_CustomValidate event
				if (!this.Form_CustomValidate(fobj))
					return false;
			} // End Grid Add checking
		}
		return true;
	}

	// Check empty row
	fusercommissiongrid.emptyRow = function(infix) {
		var fobj = this._form;
		if (ew.valueChanged(fobj, infix, "_userid", false)) return false;
		if (ew.valueChanged(fobj, infix, "userpi", false)) return false;
		if (ew.valueChanged(fobj, infix, "category", false)) return false;
		if (ew.valueChanged(fobj, infix, "transactiondate", false)) return false;
		if (ew.valueChanged(fobj, infix, "commissionamount", false)) return false;
		if (ew.valueChanged(fobj, infix, "payoutdate", false)) return false;
		if (ew.valueChanged(fobj, infix, "desc", false)) return false;
		if (ew.valueChanged(fobj, infix, "paid", false)) return false;
		return true;
	}

	// Form_CustomValidate
	fusercommissiongrid.Form_CustomValidate = function(fobj) { // DO NOT CHANGE THIS LINE!

		// Your custom validation code here, return false if invalid.
		return true;
	}

	// Use JavaScript validation or not
	fusercommissiongrid.validateRequired = <?php echo Config("CLIENT_VALIDATE") ? "true" : "false" ?>;

	// Dynamic selection lists
	fusercommissiongrid.lists["x__userid"] = <?php echo $usercommission_grid->_userid->Lookup->toClientList($usercommission_grid) ?>;
	fusercommissiongrid.lists["x__userid"].options = <?php echo JsonEncode($usercommission_grid->_userid->lookupOptions()) ?>;
	fusercommissiongrid.autoSuggests["x__userid"] = <?php echo json_encode(["data" => "ajax=autosuggest"]) ?>;
	loadjs.done("fusercommissiongrid");
});
</script>
<?php } ?>
<?php
$usercommission_grid->renderOtherOptions();
?>
<?php if ($usercommission_grid->TotalRecords > 0 || $usercommission->CurrentAction) { ?>
<div class="card ew-card ew-grid<?php if ($usercommission_grid->isAddOrEdit()) { ?> ew-grid-add-edit<?php } ?> usercommission">
<div id="fusercommissiongrid" class="ew-form ew-list-form form-inline">
<div id="gmp_usercommission" class="<?php echo ResponsiveTableClass() ?>card-body ew-grid-middle-panel">
<table id="tbl_usercommissiongrid" class="table ew-table"><!-- .ew-table -->
<thead>
	<tr class="ew-table-header">
<?php

// Header row
$usercommission->RowType = ROWTYPE_HEADER;

// Render list options
$usercommission_grid->renderListOptions();

// Render list options (header, left)
$usercommission_grid->ListOptions->render("header", "left");
?>
<?php if ($usercommission_grid->recid->Visible) { // recid ?>
	<?php if ($usercommission_grid->SortUrl($usercommission_grid->recid) == "") { ?>
		<th data-name="recid" class="<?php echo $usercommission_grid->recid->headerCellClass() ?>"><div id="elh_usercommission_recid" class="usercommission_recid"><div class="ew-table-header-caption"><?php echo $usercommission_grid->recid->caption() ?></div></div></th>
	<?php } else { ?>
		<th data-name="recid" class="<?php echo $usercommission_grid->recid->headerCellClass() ?>"><div><div id="elh_usercommission_recid" class="usercommission_recid">
			<div class="ew-table-header-btn"><span class="ew-table-header-caption"><?php echo $usercommission_grid->recid->caption() ?></span><span class="ew-table-header-sort"><?php if ($usercommission_grid->recid->getSort() == "ASC") { ?><i class="fas fa-sort-up"></i><?php } elseif ($usercommission_grid->recid->getSort() == "DESC") { ?><i class="fas fa-sort-down"></i><?php } ?></span></div>
		</div></div></th>
	<?php } ?>
<?php } ?>
<?php if ($usercommission_grid->_userid->Visible) { // userid ?>
	<?php if ($usercommission_grid->SortUrl($usercommission_grid->_userid) == "") { ?>
		<th data-name="_userid" class="<?php echo $usercommission_grid->_userid->headerCellClass() ?>"><div id="elh_usercommission__userid" class="usercommission__userid"><div class="ew-table-header-caption"><?php echo $usercommission_grid->_userid->caption() ?></div></div></th>
	<?php } else { ?>
		<th data-name="_userid" class="<?php echo $usercommission_grid->_userid->headerCellClass() ?>"><div><div id="elh_usercommission__userid" class="usercommission__userid">
			<div class="ew-table-header-btn"><span class="ew-table-header-caption"><?php echo $usercommission_grid->_userid->caption() ?></span><span class="ew-table-header-sort"><?php if ($usercommission_grid->_userid->getSort() == "ASC") { ?><i class="fas fa-sort-up"></i><?php } elseif ($usercommission_grid->_userid->getSort() == "DESC") { ?><i class="fas fa-sort-down"></i><?php } ?></span></div>
		</div></div></th>
	<?php } ?>
<?php } ?>
<?php if ($usercommission_grid->userpi->Visible) { // userpi ?>
	<?php if ($usercommission_grid->SortUrl($usercommission_grid->userpi) == "") { ?>
		<th data-name="userpi" class="<?php echo $usercommission_grid->userpi->headerCellClass() ?>"><div id="elh_usercommission_userpi" class="usercommission_userpi"><div class="ew-table-header-caption"><?php echo $usercommission_grid->userpi->caption() ?></div></div></th>
	<?php } else { ?>
		<th data-name="userpi" class="<?php echo $usercommission_grid->userpi->headerCellClass() ?>"><div><div id="elh_usercommission_userpi" class="usercommission_userpi">
			<div class="ew-table-header-btn"><span class="ew-table-header-caption"><?php echo $usercommission_grid->userpi->caption() ?></span><span class="ew-table-header-sort"><?php if ($usercommission_grid->userpi->getSort() == "ASC") { ?><i class="fas fa-sort-up"></i><?php } elseif ($usercommission_grid->userpi->getSort() == "DESC") { ?><i class="fas fa-sort-down"></i><?php } ?></span></div>
		</div></div></th>
	<?php } ?>
<?php } ?>
<?php if ($usercommission_grid->category->Visible) { // category ?>
	<?php if ($usercommission_grid->SortUrl($usercommission_grid->category) == "") { ?>
		<th data-name="category" class="<?php echo $usercommission_grid->category->headerCellClass() ?>"><div id="elh_usercommission_category" class="usercommission_category"><div class="ew-table-header-caption"><?php echo $usercommission_grid->category->caption() ?></div></div></th>
	<?php } else { ?>
		<th data-name="category" class="<?php echo $usercommission_grid->category->headerCellClass() ?>"><div><div id="elh_usercommission_category" class="usercommission_category">
			<div class="ew-table-header-btn"><span class="ew-table-header-caption"><?php echo $usercommission_grid->category->caption() ?></span><span class="ew-table-header-sort"><?php if ($usercommission_grid->category->getSort() == "ASC") { ?><i class="fas fa-sort-up"></i><?php } elseif ($usercommission_grid->category->getSort() == "DESC") { ?><i class="fas fa-sort-down"></i><?php } ?></span></div>
		</div></div></th>
	<?php } ?>
<?php } ?>
<?php if ($usercommission_grid->transactiondate->Visible) { // transactiondate ?>
	<?php if ($usercommission_grid->SortUrl($usercommission_grid->transactiondate) == "") { ?>
		<th data-name="transactiondate" class="<?php echo $usercommission_grid->transactiondate->headerCellClass() ?>"><div id="elh_usercommission_transactiondate" class="usercommission_transactiondate"><div class="ew-table-header-caption"><?php echo $usercommission_grid->transactiondate->caption() ?></div></div></th>
	<?php } else { ?>
		<th data-name="transactiondate" class="<?php echo $usercommission_grid->transactiondate->headerCellClass() ?>"><div><div id="elh_usercommission_transactiondate" class="usercommission_transactiondate">
			<div class="ew-table-header-btn"><span class="ew-table-header-caption"><?php echo $usercommission_grid->transactiondate->caption() ?></span><span class="ew-table-header-sort"><?php if ($usercommission_grid->transactiondate->getSort() == "ASC") { ?><i class="fas fa-sort-up"></i><?php } elseif ($usercommission_grid->transactiondate->getSort() == "DESC") { ?><i class="fas fa-sort-down"></i><?php } ?></span></div>
		</div></div></th>
	<?php } ?>
<?php } ?>
<?php if ($usercommission_grid->commissionamount->Visible) { // commissionamount ?>
	<?php if ($usercommission_grid->SortUrl($usercommission_grid->commissionamount) == "") { ?>
		<th data-name="commissionamount" class="<?php echo $usercommission_grid->commissionamount->headerCellClass() ?>"><div id="elh_usercommission_commissionamount" class="usercommission_commissionamount"><div class="ew-table-header-caption"><?php echo $usercommission_grid->commissionamount->caption() ?></div></div></th>
	<?php } else { ?>
		<th data-name="commissionamount" class="<?php echo $usercommission_grid->commissionamount->headerCellClass() ?>"><div><div id="elh_usercommission_commissionamount" class="usercommission_commissionamount">
			<div class="ew-table-header-btn"><span class="ew-table-header-caption"><?php echo $usercommission_grid->commissionamount->caption() ?></span><span class="ew-table-header-sort"><?php if ($usercommission_grid->commissionamount->getSort() == "ASC") { ?><i class="fas fa-sort-up"></i><?php } elseif ($usercommission_grid->commissionamount->getSort() == "DESC") { ?><i class="fas fa-sort-down"></i><?php } ?></span></div>
		</div></div></th>
	<?php } ?>
<?php } ?>
<?php if ($usercommission_grid->payoutdate->Visible) { // payoutdate ?>
	<?php if ($usercommission_grid->SortUrl($usercommission_grid->payoutdate) == "") { ?>
		<th data-name="payoutdate" class="<?php echo $usercommission_grid->payoutdate->headerCellClass() ?>"><div id="elh_usercommission_payoutdate" class="usercommission_payoutdate"><div class="ew-table-header-caption"><?php echo $usercommission_grid->payoutdate->caption() ?></div></div></th>
	<?php } else { ?>
		<th data-name="payoutdate" class="<?php echo $usercommission_grid->payoutdate->headerCellClass() ?>"><div><div id="elh_usercommission_payoutdate" class="usercommission_payoutdate">
			<div class="ew-table-header-btn"><span class="ew-table-header-caption"><?php echo $usercommission_grid->payoutdate->caption() ?></span><span class="ew-table-header-sort"><?php if ($usercommission_grid->payoutdate->getSort() == "ASC") { ?><i class="fas fa-sort-up"></i><?php } elseif ($usercommission_grid->payoutdate->getSort() == "DESC") { ?><i class="fas fa-sort-down"></i><?php } ?></span></div>
		</div></div></th>
	<?php } ?>
<?php } ?>
<?php if ($usercommission_grid->desc->Visible) { // desc ?>
	<?php if ($usercommission_grid->SortUrl($usercommission_grid->desc) == "") { ?>
		<th data-name="desc" class="<?php echo $usercommission_grid->desc->headerCellClass() ?>"><div id="elh_usercommission_desc" class="usercommission_desc"><div class="ew-table-header-caption"><?php echo $usercommission_grid->desc->caption() ?></div></div></th>
	<?php } else { ?>
		<th data-name="desc" class="<?php echo $usercommission_grid->desc->headerCellClass() ?>"><div><div id="elh_usercommission_desc" class="usercommission_desc">
			<div class="ew-table-header-btn"><span class="ew-table-header-caption"><?php echo $usercommission_grid->desc->caption() ?></span><span class="ew-table-header-sort"><?php if ($usercommission_grid->desc->getSort() == "ASC") { ?><i class="fas fa-sort-up"></i><?php } elseif ($usercommission_grid->desc->getSort() == "DESC") { ?><i class="fas fa-sort-down"></i><?php } ?></span></div>
		</div></div></th>
	<?php } ?>
<?php } ?>
<?php if ($usercommission_grid->paid->Visible) { // paid ?>
	<?php if ($usercommission_grid->SortUrl($usercommission_grid->paid) == "") { ?>
		<th data-name="paid" class="<?php echo $usercommission_grid->paid->headerCellClass() ?>"><div id="elh_usercommission_paid" class="usercommission_paid"><div class="ew-table-header-caption"><?php echo $usercommission_grid->paid->caption() ?></div></div></th>
	<?php } else { ?>
		<th data-name="paid" class="<?php echo $usercommission_grid->paid->headerCellClass() ?>"><div><div id="elh_usercommission_paid" class="usercommission_paid">
			<div class="ew-table-header-btn"><span class="ew-table-header-caption"><?php echo $usercommission_grid->paid->caption() ?></span><span class="ew-table-header-sort"><?php if ($usercommission_grid->paid->getSort() == "ASC") { ?><i class="fas fa-sort-up"></i><?php } elseif ($usercommission_grid->paid->getSort() == "DESC") { ?><i class="fas fa-sort-down"></i><?php } ?></span></div>
		</div></div></th>
	<?php } ?>
<?php } ?>
<?php

// Render list options (header, right)
$usercommission_grid->ListOptions->render("header", "right");
?>
	</tr>
</thead>
<tbody>
<?php
$usercommission_grid->StartRecord = 1;
$usercommission_grid->StopRecord = $usercommission_grid->TotalRecords; // Show all records

// Restore number of post back records
if ($CurrentForm && ($usercommission->isConfirm() || $usercommission_grid->EventCancelled)) {
	$CurrentForm->Index = -1;
	if ($CurrentForm->hasValue($usercommission_grid->FormKeyCountName) && ($usercommission_grid->isGridAdd() || $usercommission_grid->isGridEdit() || $usercommission->isConfirm())) {
		$usercommission_grid->KeyCount = $CurrentForm->getValue($usercommission_grid->FormKeyCountName);
		$usercommission_grid->StopRecord = $usercommission_grid->StartRecord + $usercommission_grid->KeyCount - 1;
	}
}
$usercommission_grid->RecordCount = $usercommission_grid->StartRecord - 1;
if ($usercommission_grid->Recordset && !$usercommission_grid->Recordset->EOF) {
	$usercommission_grid->Recordset->moveFirst();
	$selectLimit = $usercommission_grid->UseSelectLimit;
	if (!$selectLimit && $usercommission_grid->StartRecord > 1)
		$usercommission_grid->Recordset->move($usercommission_grid->StartRecord - 1);
} elseif (!$usercommission->AllowAddDeleteRow && $usercommission_grid->StopRecord == 0) {
	$usercommission_grid->StopRecord = $usercommission->GridAddRowCount;
}

// Initialize aggregate
$usercommission->RowType = ROWTYPE_AGGREGATEINIT;
$usercommission->resetAttributes();
$usercommission_grid->renderRow();
if ($usercommission_grid->isGridAdd())
	$usercommission_grid->RowIndex = 0;
if ($usercommission_grid->isGridEdit())
	$usercommission_grid->RowIndex = 0;
while ($usercommission_grid->RecordCount < $usercommission_grid->StopRecord) {
	$usercommission_grid->RecordCount++;
	if ($usercommission_grid->RecordCount >= $usercommission_grid->StartRecord) {
		$usercommission_grid->RowCount++;
		if ($usercommission_grid->isGridAdd() || $usercommission_grid->isGridEdit() || $usercommission->isConfirm()) {
			$usercommission_grid->RowIndex++;
			$CurrentForm->Index = $usercommission_grid->RowIndex;
			if ($CurrentForm->hasValue($usercommission_grid->FormActionName) && ($usercommission->isConfirm() || $usercommission_grid->EventCancelled))
				$usercommission_grid->RowAction = strval($CurrentForm->getValue($usercommission_grid->FormActionName));
			elseif ($usercommission_grid->isGridAdd())
				$usercommission_grid->RowAction = "insert";
			else
				$usercommission_grid->RowAction = "";
		}

		// Set up key count
		$usercommission_grid->KeyCount = $usercommission_grid->RowIndex;

		// Init row class and style
		$usercommission->resetAttributes();
		$usercommission->CssClass = "";
		if ($usercommission_grid->isGridAdd()) {
			if ($usercommission->CurrentMode == "copy") {
				$usercommission_grid->loadRowValues($usercommission_grid->Recordset); // Load row values
				$usercommission_grid->setRecordKey($usercommission_grid->RowOldKey, $usercommission_grid->Recordset); // Set old record key
			} else {
				$usercommission_grid->loadRowValues(); // Load default values
				$usercommission_grid->RowOldKey = ""; // Clear old key value
			}
		} else {
			$usercommission_grid->loadRowValues($usercommission_grid->Recordset); // Load row values
		}
		$usercommission->RowType = ROWTYPE_VIEW; // Render view
		if ($usercommission_grid->isGridAdd()) // Grid add
			$usercommission->RowType = ROWTYPE_ADD; // Render add
		if ($usercommission_grid->isGridAdd() && $usercommission->EventCancelled && !$CurrentForm->hasValue("k_blankrow")) // Insert failed
			$usercommission_grid->restoreCurrentRowFormValues($usercommission_grid->RowIndex); // Restore form values
		if ($usercommission_grid->isGridEdit()) { // Grid edit
			if ($usercommission->EventCancelled)
				$usercommission_grid->restoreCurrentRowFormValues($usercommission_grid->RowIndex); // Restore form values
			if ($usercommission_grid->RowAction == "insert")
				$usercommission->RowType = ROWTYPE_ADD; // Render add
			else
				$usercommission->RowType = ROWTYPE_EDIT; // Render edit
		}
		if ($usercommission_grid->isGridEdit() && ($usercommission->RowType == ROWTYPE_EDIT || $usercommission->RowType == ROWTYPE_ADD) && $usercommission->EventCancelled) // Update failed
			$usercommission_grid->restoreCurrentRowFormValues($usercommission_grid->RowIndex); // Restore form values
		if ($usercommission->RowType == ROWTYPE_EDIT) // Edit row
			$usercommission_grid->EditRowCount++;
		if ($usercommission->isConfirm()) // Confirm row
			$usercommission_grid->restoreCurrentRowFormValues($usercommission_grid->RowIndex); // Restore form values

		// Set up row id / data-rowindex
		$usercommission->RowAttrs->merge(["data-rowindex" => $usercommission_grid->RowCount, "id" => "r" . $usercommission_grid->RowCount . "_usercommission", "data-rowtype" => $usercommission->RowType]);

		// Render row
		$usercommission_grid->renderRow();

		// Render list options
		$usercommission_grid->renderListOptions();

		// Skip delete row / empty row for confirm page
		if ($usercommission_grid->RowAction != "delete" && $usercommission_grid->RowAction != "insertdelete" && !($usercommission_grid->RowAction == "insert" && $usercommission->isConfirm() && $usercommission_grid->emptyRow())) {
?>
	<tr <?php echo $usercommission->rowAttributes() ?>>
<?php

// Render list options (body, left)
$usercommission_grid->ListOptions->render("body", "left", $usercommission_grid->RowCount);
?>
	<?php if ($usercommission_grid->recid->Visible) { // recid ?>
		<td data-name="recid" <?php echo $usercommission_grid->recid->cellAttributes() ?>>
<?php if ($usercommission->RowType == ROWTYPE_ADD) { // Add record ?>
<span id="el<?php echo $usercommission_grid->RowCount ?>_usercommission_recid" class="form-group"></span>
<input type="hidden" data-table="usercommission" data-field="x_recid" name="o<?php echo $usercommission_grid->RowIndex ?>_recid" id="o<?php echo $usercommission_grid->RowIndex ?>_recid" value="<?php echo HtmlEncode($usercommission_grid->recid->OldValue) ?>">
<?php } ?>
<?php if ($usercommission->RowType == ROWTYPE_EDIT) { // Edit record ?>
<span id="el<?php echo $usercommission_grid->RowCount ?>_usercommission_recid" class="form-group">
<span<?php echo $usercommission_grid->recid->viewAttributes() ?>><input type="text" readonly class="form-control-plaintext" value="<?php echo HtmlEncode(RemoveHtml($usercommission_grid->recid->EditValue)) ?>"></span>
</span>
<input type="hidden" data-table="usercommission" data-field="x_recid" name="x<?php echo $usercommission_grid->RowIndex ?>_recid" id="x<?php echo $usercommission_grid->RowIndex ?>_recid" value="<?php echo HtmlEncode($usercommission_grid->recid->CurrentValue) ?>">
<?php } ?>
<?php if ($usercommission->RowType == ROWTYPE_VIEW) { // View record ?>
<span id="el<?php echo $usercommission_grid->RowCount ?>_usercommission_recid">
<span<?php echo $usercommission_grid->recid->viewAttributes() ?>><?php echo $usercommission_grid->recid->getViewValue() ?></span>
</span>
<?php if (!$usercommission->isConfirm()) { ?>
<input type="hidden" data-table="usercommission" data-field="x_recid" name="x<?php echo $usercommission_grid->RowIndex ?>_recid" id="x<?php echo $usercommission_grid->RowIndex ?>_recid" value="<?php echo HtmlEncode($usercommission_grid->recid->FormValue) ?>">
<input type="hidden" data-table="usercommission" data-field="x_recid" name="o<?php echo $usercommission_grid->RowIndex ?>_recid" id="o<?php echo $usercommission_grid->RowIndex ?>_recid" value="<?php echo HtmlEncode($usercommission_grid->recid->OldValue) ?>">
<?php } else { ?>
<input type="hidden" data-table="usercommission" data-field="x_recid" name="fusercommissiongrid$x<?php echo $usercommission_grid->RowIndex ?>_recid" id="fusercommissiongrid$x<?php echo $usercommission_grid->RowIndex ?>_recid" value="<?php echo HtmlEncode($usercommission_grid->recid->FormValue) ?>">
<input type="hidden" data-table="usercommission" data-field="x_recid" name="fusercommissiongrid$o<?php echo $usercommission_grid->RowIndex ?>_recid" id="fusercommissiongrid$o<?php echo $usercommission_grid->RowIndex ?>_recid" value="<?php echo HtmlEncode($usercommission_grid->recid->OldValue) ?>">
<?php } ?>
<?php } ?>
</td>
	<?php } ?>
	<?php if ($usercommission_grid->_userid->Visible) { // userid ?>
		<td data-name="_userid" <?php echo $usercommission_grid->_userid->cellAttributes() ?>>
<?php if ($usercommission->RowType == ROWTYPE_ADD) { // Add record ?>
<?php if ($usercommission_grid->_userid->getSessionValue() != "") { ?>
<span id="el<?php echo $usercommission_grid->RowCount ?>_usercommission__userid" class="form-group">
<span<?php echo $usercommission_grid->_userid->viewAttributes() ?>><input type="text" readonly class="form-control-plaintext" value="<?php echo HtmlEncode(RemoveHtml($usercommission_grid->_userid->ViewValue)) ?>"></span>
</span>
<input type="hidden" id="x<?php echo $usercommission_grid->RowIndex ?>__userid" name="x<?php echo $usercommission_grid->RowIndex ?>__userid" value="<?php echo HtmlEncode($usercommission_grid->_userid->CurrentValue) ?>">
<?php } else { ?>
<span id="el<?php echo $usercommission_grid->RowCount ?>_usercommission__userid" class="form-group">
<?php
$onchange = $usercommission_grid->_userid->EditAttrs->prepend("onchange", "");
$onchange = ($onchange) ? ' onchange="' . JsEncode($onchange) . '"' : '';
$usercommission_grid->_userid->EditAttrs["onchange"] = "";
?>
<span id="as_x<?php echo $usercommission_grid->RowIndex ?>__userid">
	<input type="text" class="form-control" name="sv_x<?php echo $usercommission_grid->RowIndex ?>__userid" id="sv_x<?php echo $usercommission_grid->RowIndex ?>__userid" value="<?php echo RemoveHtml($usercommission_grid->_userid->EditValue) ?>" size="30" maxlength="12" placeholder="<?php echo HtmlEncode($usercommission_grid->_userid->getPlaceHolder()) ?>" data-placeholder="<?php echo HtmlEncode($usercommission_grid->_userid->getPlaceHolder()) ?>"<?php echo $usercommission_grid->_userid->editAttributes() ?>>
</span>
<input type="hidden" data-table="usercommission" data-field="x__userid" data-value-separator="<?php echo $usercommission_grid->_userid->displayValueSeparatorAttribute() ?>" name="x<?php echo $usercommission_grid->RowIndex ?>__userid" id="x<?php echo $usercommission_grid->RowIndex ?>__userid" value="<?php echo HtmlEncode($usercommission_grid->_userid->CurrentValue) ?>"<?php echo $onchange ?>>
<script>
loadjs.ready(["fusercommissiongrid"], function() {
	fusercommissiongrid.createAutoSuggest({"id":"x<?php echo $usercommission_grid->RowIndex ?>__userid","forceSelect":false});
});
</script>
<?php echo $usercommission_grid->_userid->Lookup->getParamTag($usercommission_grid, "p_x" . $usercommission_grid->RowIndex . "__userid") ?>
</span>
<?php } ?>
<input type="hidden" data-table="usercommission" data-field="x__userid" name="o<?php echo $usercommission_grid->RowIndex ?>__userid" id="o<?php echo $usercommission_grid->RowIndex ?>__userid" value="<?php echo HtmlEncode($usercommission_grid->_userid->OldValue) ?>">
<?php } ?>
<?php if ($usercommission->RowType == ROWTYPE_EDIT) { // Edit record ?>
<?php if ($usercommission_grid->_userid->getSessionValue() != "") { ?>
<span id="el<?php echo $usercommission_grid->RowCount ?>_usercommission__userid" class="form-group">
<span<?php echo $usercommission_grid->_userid->viewAttributes() ?>><input type="text" readonly class="form-control-plaintext" value="<?php echo HtmlEncode(RemoveHtml($usercommission_grid->_userid->ViewValue)) ?>"></span>
</span>
<input type="hidden" id="x<?php echo $usercommission_grid->RowIndex ?>__userid" name="x<?php echo $usercommission_grid->RowIndex ?>__userid" value="<?php echo HtmlEncode($usercommission_grid->_userid->CurrentValue) ?>">
<?php } else { ?>
<span id="el<?php echo $usercommission_grid->RowCount ?>_usercommission__userid" class="form-group">
<?php
$onchange = $usercommission_grid->_userid->EditAttrs->prepend("onchange", "");
$onchange = ($onchange) ? ' onchange="' . JsEncode($onchange) . '"' : '';
$usercommission_grid->_userid->EditAttrs["onchange"] = "";
?>
<span id="as_x<?php echo $usercommission_grid->RowIndex ?>__userid">
	<input type="text" class="form-control" name="sv_x<?php echo $usercommission_grid->RowIndex ?>__userid" id="sv_x<?php echo $usercommission_grid->RowIndex ?>__userid" value="<?php echo RemoveHtml($usercommission_grid->_userid->EditValue) ?>" size="30" maxlength="12" placeholder="<?php echo HtmlEncode($usercommission_grid->_userid->getPlaceHolder()) ?>" data-placeholder="<?php echo HtmlEncode($usercommission_grid->_userid->getPlaceHolder()) ?>"<?php echo $usercommission_grid->_userid->editAttributes() ?>>
</span>
<input type="hidden" data-table="usercommission" data-field="x__userid" data-value-separator="<?php echo $usercommission_grid->_userid->displayValueSeparatorAttribute() ?>" name="x<?php echo $usercommission_grid->RowIndex ?>__userid" id="x<?php echo $usercommission_grid->RowIndex ?>__userid" value="<?php echo HtmlEncode($usercommission_grid->_userid->CurrentValue) ?>"<?php echo $onchange ?>>
<script>
loadjs.ready(["fusercommissiongrid"], function() {
	fusercommissiongrid.createAutoSuggest({"id":"x<?php echo $usercommission_grid->RowIndex ?>__userid","forceSelect":false});
});
</script>
<?php echo $usercommission_grid->_userid->Lookup->getParamTag($usercommission_grid, "p_x" . $usercommission_grid->RowIndex . "__userid") ?>
</span>
<?php } ?>
<?php } ?>
<?php if ($usercommission->RowType == ROWTYPE_VIEW) { // View record ?>
<span id="el<?php echo $usercommission_grid->RowCount ?>_usercommission__userid">
<span<?php echo $usercommission_grid->_userid->viewAttributes() ?>><?php echo $usercommission_grid->_userid->getViewValue() ?></span>
</span>
<?php if (!$usercommission->isConfirm()) { ?>
<input type="hidden" data-table="usercommission" data-field="x__userid" name="x<?php echo $usercommission_grid->RowIndex ?>__userid" id="x<?php echo $usercommission_grid->RowIndex ?>__userid" value="<?php echo HtmlEncode($usercommission_grid->_userid->FormValue) ?>">
<input type="hidden" data-table="usercommission" data-field="x__userid" name="o<?php echo $usercommission_grid->RowIndex ?>__userid" id="o<?php echo $usercommission_grid->RowIndex ?>__userid" value="<?php echo HtmlEncode($usercommission_grid->_userid->OldValue) ?>">
<?php } else { ?>
<input type="hidden" data-table="usercommission" data-field="x__userid" name="fusercommissiongrid$x<?php echo $usercommission_grid->RowIndex ?>__userid" id="fusercommissiongrid$x<?php echo $usercommission_grid->RowIndex ?>__userid" value="<?php echo HtmlEncode($usercommission_grid->_userid->FormValue) ?>">
<input type="hidden" data-table="usercommission" data-field="x__userid" name="fusercommissiongrid$o<?php echo $usercommission_grid->RowIndex ?>__userid" id="fusercommissiongrid$o<?php echo $usercommission_grid->RowIndex ?>__userid" value="<?php echo HtmlEncode($usercommission_grid->_userid->OldValue) ?>">
<?php } ?>
<?php } ?>
</td>
	<?php } ?>
	<?php if ($usercommission_grid->userpi->Visible) { // userpi ?>
		<td data-name="userpi" <?php echo $usercommission_grid->userpi->cellAttributes() ?>>
<?php if ($usercommission->RowType == ROWTYPE_ADD) { // Add record ?>
<span id="el<?php echo $usercommission_grid->RowCount ?>_usercommission_userpi" class="form-group">
<input type="text" data-table="usercommission" data-field="x_userpi" name="x<?php echo $usercommission_grid->RowIndex ?>_userpi" id="x<?php echo $usercommission_grid->RowIndex ?>_userpi" size="30" maxlength="12" placeholder="<?php echo HtmlEncode($usercommission_grid->userpi->getPlaceHolder()) ?>" value="<?php echo $usercommission_grid->userpi->EditValue ?>"<?php echo $usercommission_grid->userpi->editAttributes() ?>>
</span>
<input type="hidden" data-table="usercommission" data-field="x_userpi" name="o<?php echo $usercommission_grid->RowIndex ?>_userpi" id="o<?php echo $usercommission_grid->RowIndex ?>_userpi" value="<?php echo HtmlEncode($usercommission_grid->userpi->OldValue) ?>">
<?php } ?>
<?php if ($usercommission->RowType == ROWTYPE_EDIT) { // Edit record ?>
<span id="el<?php echo $usercommission_grid->RowCount ?>_usercommission_userpi" class="form-group">
<input type="text" data-table="usercommission" data-field="x_userpi" name="x<?php echo $usercommission_grid->RowIndex ?>_userpi" id="x<?php echo $usercommission_grid->RowIndex ?>_userpi" size="30" maxlength="12" placeholder="<?php echo HtmlEncode($usercommission_grid->userpi->getPlaceHolder()) ?>" value="<?php echo $usercommission_grid->userpi->EditValue ?>"<?php echo $usercommission_grid->userpi->editAttributes() ?>>
</span>
<?php } ?>
<?php if ($usercommission->RowType == ROWTYPE_VIEW) { // View record ?>
<span id="el<?php echo $usercommission_grid->RowCount ?>_usercommission_userpi">
<span<?php echo $usercommission_grid->userpi->viewAttributes() ?>><?php echo $usercommission_grid->userpi->getViewValue() ?></span>
</span>
<?php if (!$usercommission->isConfirm()) { ?>
<input type="hidden" data-table="usercommission" data-field="x_userpi" name="x<?php echo $usercommission_grid->RowIndex ?>_userpi" id="x<?php echo $usercommission_grid->RowIndex ?>_userpi" value="<?php echo HtmlEncode($usercommission_grid->userpi->FormValue) ?>">
<input type="hidden" data-table="usercommission" data-field="x_userpi" name="o<?php echo $usercommission_grid->RowIndex ?>_userpi" id="o<?php echo $usercommission_grid->RowIndex ?>_userpi" value="<?php echo HtmlEncode($usercommission_grid->userpi->OldValue) ?>">
<?php } else { ?>
<input type="hidden" data-table="usercommission" data-field="x_userpi" name="fusercommissiongrid$x<?php echo $usercommission_grid->RowIndex ?>_userpi" id="fusercommissiongrid$x<?php echo $usercommission_grid->RowIndex ?>_userpi" value="<?php echo HtmlEncode($usercommission_grid->userpi->FormValue) ?>">
<input type="hidden" data-table="usercommission" data-field="x_userpi" name="fusercommissiongrid$o<?php echo $usercommission_grid->RowIndex ?>_userpi" id="fusercommissiongrid$o<?php echo $usercommission_grid->RowIndex ?>_userpi" value="<?php echo HtmlEncode($usercommission_grid->userpi->OldValue) ?>">
<?php } ?>
<?php } ?>
</td>
	<?php } ?>
	<?php if ($usercommission_grid->category->Visible) { // category ?>
		<td data-name="category" <?php echo $usercommission_grid->category->cellAttributes() ?>>
<?php if ($usercommission->RowType == ROWTYPE_ADD) { // Add record ?>
<span id="el<?php echo $usercommission_grid->RowCount ?>_usercommission_category" class="form-group">
<input type="text" data-table="usercommission" data-field="x_category" name="x<?php echo $usercommission_grid->RowIndex ?>_category" id="x<?php echo $usercommission_grid->RowIndex ?>_category" size="30" maxlength="2" placeholder="<?php echo HtmlEncode($usercommission_grid->category->getPlaceHolder()) ?>" value="<?php echo $usercommission_grid->category->EditValue ?>"<?php echo $usercommission_grid->category->editAttributes() ?>>
</span>
<input type="hidden" data-table="usercommission" data-field="x_category" name="o<?php echo $usercommission_grid->RowIndex ?>_category" id="o<?php echo $usercommission_grid->RowIndex ?>_category" value="<?php echo HtmlEncode($usercommission_grid->category->OldValue) ?>">
<?php } ?>
<?php if ($usercommission->RowType == ROWTYPE_EDIT) { // Edit record ?>
<span id="el<?php echo $usercommission_grid->RowCount ?>_usercommission_category" class="form-group">
<input type="text" data-table="usercommission" data-field="x_category" name="x<?php echo $usercommission_grid->RowIndex ?>_category" id="x<?php echo $usercommission_grid->RowIndex ?>_category" size="30" maxlength="2" placeholder="<?php echo HtmlEncode($usercommission_grid->category->getPlaceHolder()) ?>" value="<?php echo $usercommission_grid->category->EditValue ?>"<?php echo $usercommission_grid->category->editAttributes() ?>>
</span>
<?php } ?>
<?php if ($usercommission->RowType == ROWTYPE_VIEW) { // View record ?>
<span id="el<?php echo $usercommission_grid->RowCount ?>_usercommission_category">
<span<?php echo $usercommission_grid->category->viewAttributes() ?>><?php echo $usercommission_grid->category->getViewValue() ?></span>
</span>
<?php if (!$usercommission->isConfirm()) { ?>
<input type="hidden" data-table="usercommission" data-field="x_category" name="x<?php echo $usercommission_grid->RowIndex ?>_category" id="x<?php echo $usercommission_grid->RowIndex ?>_category" value="<?php echo HtmlEncode($usercommission_grid->category->FormValue) ?>">
<input type="hidden" data-table="usercommission" data-field="x_category" name="o<?php echo $usercommission_grid->RowIndex ?>_category" id="o<?php echo $usercommission_grid->RowIndex ?>_category" value="<?php echo HtmlEncode($usercommission_grid->category->OldValue) ?>">
<?php } else { ?>
<input type="hidden" data-table="usercommission" data-field="x_category" name="fusercommissiongrid$x<?php echo $usercommission_grid->RowIndex ?>_category" id="fusercommissiongrid$x<?php echo $usercommission_grid->RowIndex ?>_category" value="<?php echo HtmlEncode($usercommission_grid->category->FormValue) ?>">
<input type="hidden" data-table="usercommission" data-field="x_category" name="fusercommissiongrid$o<?php echo $usercommission_grid->RowIndex ?>_category" id="fusercommissiongrid$o<?php echo $usercommission_grid->RowIndex ?>_category" value="<?php echo HtmlEncode($usercommission_grid->category->OldValue) ?>">
<?php } ?>
<?php } ?>
</td>
	<?php } ?>
	<?php if ($usercommission_grid->transactiondate->Visible) { // transactiondate ?>
		<td data-name="transactiondate" <?php echo $usercommission_grid->transactiondate->cellAttributes() ?>>
<?php if ($usercommission->RowType == ROWTYPE_ADD) { // Add record ?>
<span id="el<?php echo $usercommission_grid->RowCount ?>_usercommission_transactiondate" class="form-group">
<input type="text" data-table="usercommission" data-field="x_transactiondate" name="x<?php echo $usercommission_grid->RowIndex ?>_transactiondate" id="x<?php echo $usercommission_grid->RowIndex ?>_transactiondate" maxlength="19" placeholder="<?php echo HtmlEncode($usercommission_grid->transactiondate->getPlaceHolder()) ?>" value="<?php echo $usercommission_grid->transactiondate->EditValue ?>"<?php echo $usercommission_grid->transactiondate->editAttributes() ?>>
<?php if (!$usercommission_grid->transactiondate->ReadOnly && !$usercommission_grid->transactiondate->Disabled && !isset($usercommission_grid->transactiondate->EditAttrs["readonly"]) && !isset($usercommission_grid->transactiondate->EditAttrs["disabled"])) { ?>
<script>
loadjs.ready(["fusercommissiongrid", "datetimepicker"], function() {
	ew.createDateTimePicker("fusercommissiongrid", "x<?php echo $usercommission_grid->RowIndex ?>_transactiondate", {"ignoreReadonly":true,"useCurrent":false,"format":0});
});
</script>
<?php } ?>
</span>
<input type="hidden" data-table="usercommission" data-field="x_transactiondate" name="o<?php echo $usercommission_grid->RowIndex ?>_transactiondate" id="o<?php echo $usercommission_grid->RowIndex ?>_transactiondate" value="<?php echo HtmlEncode($usercommission_grid->transactiondate->OldValue) ?>">
<?php } ?>
<?php if ($usercommission->RowType == ROWTYPE_EDIT) { // Edit record ?>
<span id="el<?php echo $usercommission_grid->RowCount ?>_usercommission_transactiondate" class="form-group">
<input type="text" data-table="usercommission" data-field="x_transactiondate" name="x<?php echo $usercommission_grid->RowIndex ?>_transactiondate" id="x<?php echo $usercommission_grid->RowIndex ?>_transactiondate" maxlength="19" placeholder="<?php echo HtmlEncode($usercommission_grid->transactiondate->getPlaceHolder()) ?>" value="<?php echo $usercommission_grid->transactiondate->EditValue ?>"<?php echo $usercommission_grid->transactiondate->editAttributes() ?>>
<?php if (!$usercommission_grid->transactiondate->ReadOnly && !$usercommission_grid->transactiondate->Disabled && !isset($usercommission_grid->transactiondate->EditAttrs["readonly"]) && !isset($usercommission_grid->transactiondate->EditAttrs["disabled"])) { ?>
<script>
loadjs.ready(["fusercommissiongrid", "datetimepicker"], function() {
	ew.createDateTimePicker("fusercommissiongrid", "x<?php echo $usercommission_grid->RowIndex ?>_transactiondate", {"ignoreReadonly":true,"useCurrent":false,"format":0});
});
</script>
<?php } ?>
</span>
<?php } ?>
<?php if ($usercommission->RowType == ROWTYPE_VIEW) { // View record ?>
<span id="el<?php echo $usercommission_grid->RowCount ?>_usercommission_transactiondate">
<span<?php echo $usercommission_grid->transactiondate->viewAttributes() ?>><?php echo $usercommission_grid->transactiondate->getViewValue() ?></span>
</span>
<?php if (!$usercommission->isConfirm()) { ?>
<input type="hidden" data-table="usercommission" data-field="x_transactiondate" name="x<?php echo $usercommission_grid->RowIndex ?>_transactiondate" id="x<?php echo $usercommission_grid->RowIndex ?>_transactiondate" value="<?php echo HtmlEncode($usercommission_grid->transactiondate->FormValue) ?>">
<input type="hidden" data-table="usercommission" data-field="x_transactiondate" name="o<?php echo $usercommission_grid->RowIndex ?>_transactiondate" id="o<?php echo $usercommission_grid->RowIndex ?>_transactiondate" value="<?php echo HtmlEncode($usercommission_grid->transactiondate->OldValue) ?>">
<?php } else { ?>
<input type="hidden" data-table="usercommission" data-field="x_transactiondate" name="fusercommissiongrid$x<?php echo $usercommission_grid->RowIndex ?>_transactiondate" id="fusercommissiongrid$x<?php echo $usercommission_grid->RowIndex ?>_transactiondate" value="<?php echo HtmlEncode($usercommission_grid->transactiondate->FormValue) ?>">
<input type="hidden" data-table="usercommission" data-field="x_transactiondate" name="fusercommissiongrid$o<?php echo $usercommission_grid->RowIndex ?>_transactiondate" id="fusercommissiongrid$o<?php echo $usercommission_grid->RowIndex ?>_transactiondate" value="<?php echo HtmlEncode($usercommission_grid->transactiondate->OldValue) ?>">
<?php } ?>
<?php } ?>
</td>
	<?php } ?>
	<?php if ($usercommission_grid->commissionamount->Visible) { // commissionamount ?>
		<td data-name="commissionamount" <?php echo $usercommission_grid->commissionamount->cellAttributes() ?>>
<?php if ($usercommission->RowType == ROWTYPE_ADD) { // Add record ?>
<span id="el<?php echo $usercommission_grid->RowCount ?>_usercommission_commissionamount" class="form-group">
<input type="text" data-table="usercommission" data-field="x_commissionamount" name="x<?php echo $usercommission_grid->RowIndex ?>_commissionamount" id="x<?php echo $usercommission_grid->RowIndex ?>_commissionamount" size="30" maxlength="12" placeholder="<?php echo HtmlEncode($usercommission_grid->commissionamount->getPlaceHolder()) ?>" value="<?php echo $usercommission_grid->commissionamount->EditValue ?>"<?php echo $usercommission_grid->commissionamount->editAttributes() ?>>
</span>
<input type="hidden" data-table="usercommission" data-field="x_commissionamount" name="o<?php echo $usercommission_grid->RowIndex ?>_commissionamount" id="o<?php echo $usercommission_grid->RowIndex ?>_commissionamount" value="<?php echo HtmlEncode($usercommission_grid->commissionamount->OldValue) ?>">
<?php } ?>
<?php if ($usercommission->RowType == ROWTYPE_EDIT) { // Edit record ?>
<span id="el<?php echo $usercommission_grid->RowCount ?>_usercommission_commissionamount" class="form-group">
<input type="text" data-table="usercommission" data-field="x_commissionamount" name="x<?php echo $usercommission_grid->RowIndex ?>_commissionamount" id="x<?php echo $usercommission_grid->RowIndex ?>_commissionamount" size="30" maxlength="12" placeholder="<?php echo HtmlEncode($usercommission_grid->commissionamount->getPlaceHolder()) ?>" value="<?php echo $usercommission_grid->commissionamount->EditValue ?>"<?php echo $usercommission_grid->commissionamount->editAttributes() ?>>
</span>
<?php } ?>
<?php if ($usercommission->RowType == ROWTYPE_VIEW) { // View record ?>
<span id="el<?php echo $usercommission_grid->RowCount ?>_usercommission_commissionamount">
<span<?php echo $usercommission_grid->commissionamount->viewAttributes() ?>><?php echo $usercommission_grid->commissionamount->getViewValue() ?></span>
</span>
<?php if (!$usercommission->isConfirm()) { ?>
<input type="hidden" data-table="usercommission" data-field="x_commissionamount" name="x<?php echo $usercommission_grid->RowIndex ?>_commissionamount" id="x<?php echo $usercommission_grid->RowIndex ?>_commissionamount" value="<?php echo HtmlEncode($usercommission_grid->commissionamount->FormValue) ?>">
<input type="hidden" data-table="usercommission" data-field="x_commissionamount" name="o<?php echo $usercommission_grid->RowIndex ?>_commissionamount" id="o<?php echo $usercommission_grid->RowIndex ?>_commissionamount" value="<?php echo HtmlEncode($usercommission_grid->commissionamount->OldValue) ?>">
<?php } else { ?>
<input type="hidden" data-table="usercommission" data-field="x_commissionamount" name="fusercommissiongrid$x<?php echo $usercommission_grid->RowIndex ?>_commissionamount" id="fusercommissiongrid$x<?php echo $usercommission_grid->RowIndex ?>_commissionamount" value="<?php echo HtmlEncode($usercommission_grid->commissionamount->FormValue) ?>">
<input type="hidden" data-table="usercommission" data-field="x_commissionamount" name="fusercommissiongrid$o<?php echo $usercommission_grid->RowIndex ?>_commissionamount" id="fusercommissiongrid$o<?php echo $usercommission_grid->RowIndex ?>_commissionamount" value="<?php echo HtmlEncode($usercommission_grid->commissionamount->OldValue) ?>">
<?php } ?>
<?php } ?>
</td>
	<?php } ?>
	<?php if ($usercommission_grid->payoutdate->Visible) { // payoutdate ?>
		<td data-name="payoutdate" <?php echo $usercommission_grid->payoutdate->cellAttributes() ?>>
<?php if ($usercommission->RowType == ROWTYPE_ADD) { // Add record ?>
<span id="el<?php echo $usercommission_grid->RowCount ?>_usercommission_payoutdate" class="form-group">
<input type="text" data-table="usercommission" data-field="x_payoutdate" name="x<?php echo $usercommission_grid->RowIndex ?>_payoutdate" id="x<?php echo $usercommission_grid->RowIndex ?>_payoutdate" maxlength="10" placeholder="<?php echo HtmlEncode($usercommission_grid->payoutdate->getPlaceHolder()) ?>" value="<?php echo $usercommission_grid->payoutdate->EditValue ?>"<?php echo $usercommission_grid->payoutdate->editAttributes() ?>>
<?php if (!$usercommission_grid->payoutdate->ReadOnly && !$usercommission_grid->payoutdate->Disabled && !isset($usercommission_grid->payoutdate->EditAttrs["readonly"]) && !isset($usercommission_grid->payoutdate->EditAttrs["disabled"])) { ?>
<script>
loadjs.ready(["fusercommissiongrid", "datetimepicker"], function() {
	ew.createDateTimePicker("fusercommissiongrid", "x<?php echo $usercommission_grid->RowIndex ?>_payoutdate", {"ignoreReadonly":true,"useCurrent":false,"format":0});
});
</script>
<?php } ?>
</span>
<input type="hidden" data-table="usercommission" data-field="x_payoutdate" name="o<?php echo $usercommission_grid->RowIndex ?>_payoutdate" id="o<?php echo $usercommission_grid->RowIndex ?>_payoutdate" value="<?php echo HtmlEncode($usercommission_grid->payoutdate->OldValue) ?>">
<?php } ?>
<?php if ($usercommission->RowType == ROWTYPE_EDIT) { // Edit record ?>
<span id="el<?php echo $usercommission_grid->RowCount ?>_usercommission_payoutdate" class="form-group">
<input type="text" data-table="usercommission" data-field="x_payoutdate" name="x<?php echo $usercommission_grid->RowIndex ?>_payoutdate" id="x<?php echo $usercommission_grid->RowIndex ?>_payoutdate" maxlength="10" placeholder="<?php echo HtmlEncode($usercommission_grid->payoutdate->getPlaceHolder()) ?>" value="<?php echo $usercommission_grid->payoutdate->EditValue ?>"<?php echo $usercommission_grid->payoutdate->editAttributes() ?>>
<?php if (!$usercommission_grid->payoutdate->ReadOnly && !$usercommission_grid->payoutdate->Disabled && !isset($usercommission_grid->payoutdate->EditAttrs["readonly"]) && !isset($usercommission_grid->payoutdate->EditAttrs["disabled"])) { ?>
<script>
loadjs.ready(["fusercommissiongrid", "datetimepicker"], function() {
	ew.createDateTimePicker("fusercommissiongrid", "x<?php echo $usercommission_grid->RowIndex ?>_payoutdate", {"ignoreReadonly":true,"useCurrent":false,"format":0});
});
</script>
<?php } ?>
</span>
<?php } ?>
<?php if ($usercommission->RowType == ROWTYPE_VIEW) { // View record ?>
<span id="el<?php echo $usercommission_grid->RowCount ?>_usercommission_payoutdate">
<span<?php echo $usercommission_grid->payoutdate->viewAttributes() ?>><?php echo $usercommission_grid->payoutdate->getViewValue() ?></span>
</span>
<?php if (!$usercommission->isConfirm()) { ?>
<input type="hidden" data-table="usercommission" data-field="x_payoutdate" name="x<?php echo $usercommission_grid->RowIndex ?>_payoutdate" id="x<?php echo $usercommission_grid->RowIndex ?>_payoutdate" value="<?php echo HtmlEncode($usercommission_grid->payoutdate->FormValue) ?>">
<input type="hidden" data-table="usercommission" data-field="x_payoutdate" name="o<?php echo $usercommission_grid->RowIndex ?>_payoutdate" id="o<?php echo $usercommission_grid->RowIndex ?>_payoutdate" value="<?php echo HtmlEncode($usercommission_grid->payoutdate->OldValue) ?>">
<?php } else { ?>
<input type="hidden" data-table="usercommission" data-field="x_payoutdate" name="fusercommissiongrid$x<?php echo $usercommission_grid->RowIndex ?>_payoutdate" id="fusercommissiongrid$x<?php echo $usercommission_grid->RowIndex ?>_payoutdate" value="<?php echo HtmlEncode($usercommission_grid->payoutdate->FormValue) ?>">
<input type="hidden" data-table="usercommission" data-field="x_payoutdate" name="fusercommissiongrid$o<?php echo $usercommission_grid->RowIndex ?>_payoutdate" id="fusercommissiongrid$o<?php echo $usercommission_grid->RowIndex ?>_payoutdate" value="<?php echo HtmlEncode($usercommission_grid->payoutdate->OldValue) ?>">
<?php } ?>
<?php } ?>
</td>
	<?php } ?>
	<?php if ($usercommission_grid->desc->Visible) { // desc ?>
		<td data-name="desc" <?php echo $usercommission_grid->desc->cellAttributes() ?>>
<?php if ($usercommission->RowType == ROWTYPE_ADD) { // Add record ?>
<span id="el<?php echo $usercommission_grid->RowCount ?>_usercommission_desc" class="form-group">
<input type="text" data-table="usercommission" data-field="x_desc" name="x<?php echo $usercommission_grid->RowIndex ?>_desc" id="x<?php echo $usercommission_grid->RowIndex ?>_desc" size="30" maxlength="60" placeholder="<?php echo HtmlEncode($usercommission_grid->desc->getPlaceHolder()) ?>" value="<?php echo $usercommission_grid->desc->EditValue ?>"<?php echo $usercommission_grid->desc->editAttributes() ?>>
</span>
<input type="hidden" data-table="usercommission" data-field="x_desc" name="o<?php echo $usercommission_grid->RowIndex ?>_desc" id="o<?php echo $usercommission_grid->RowIndex ?>_desc" value="<?php echo HtmlEncode($usercommission_grid->desc->OldValue) ?>">
<?php } ?>
<?php if ($usercommission->RowType == ROWTYPE_EDIT) { // Edit record ?>
<span id="el<?php echo $usercommission_grid->RowCount ?>_usercommission_desc" class="form-group">
<input type="text" data-table="usercommission" data-field="x_desc" name="x<?php echo $usercommission_grid->RowIndex ?>_desc" id="x<?php echo $usercommission_grid->RowIndex ?>_desc" size="30" maxlength="60" placeholder="<?php echo HtmlEncode($usercommission_grid->desc->getPlaceHolder()) ?>" value="<?php echo $usercommission_grid->desc->EditValue ?>"<?php echo $usercommission_grid->desc->editAttributes() ?>>
</span>
<?php } ?>
<?php if ($usercommission->RowType == ROWTYPE_VIEW) { // View record ?>
<span id="el<?php echo $usercommission_grid->RowCount ?>_usercommission_desc">
<span<?php echo $usercommission_grid->desc->viewAttributes() ?>><?php echo $usercommission_grid->desc->getViewValue() ?></span>
</span>
<?php if (!$usercommission->isConfirm()) { ?>
<input type="hidden" data-table="usercommission" data-field="x_desc" name="x<?php echo $usercommission_grid->RowIndex ?>_desc" id="x<?php echo $usercommission_grid->RowIndex ?>_desc" value="<?php echo HtmlEncode($usercommission_grid->desc->FormValue) ?>">
<input type="hidden" data-table="usercommission" data-field="x_desc" name="o<?php echo $usercommission_grid->RowIndex ?>_desc" id="o<?php echo $usercommission_grid->RowIndex ?>_desc" value="<?php echo HtmlEncode($usercommission_grid->desc->OldValue) ?>">
<?php } else { ?>
<input type="hidden" data-table="usercommission" data-field="x_desc" name="fusercommissiongrid$x<?php echo $usercommission_grid->RowIndex ?>_desc" id="fusercommissiongrid$x<?php echo $usercommission_grid->RowIndex ?>_desc" value="<?php echo HtmlEncode($usercommission_grid->desc->FormValue) ?>">
<input type="hidden" data-table="usercommission" data-field="x_desc" name="fusercommissiongrid$o<?php echo $usercommission_grid->RowIndex ?>_desc" id="fusercommissiongrid$o<?php echo $usercommission_grid->RowIndex ?>_desc" value="<?php echo HtmlEncode($usercommission_grid->desc->OldValue) ?>">
<?php } ?>
<?php } ?>
</td>
	<?php } ?>
	<?php if ($usercommission_grid->paid->Visible) { // paid ?>
		<td data-name="paid" <?php echo $usercommission_grid->paid->cellAttributes() ?>>
<?php if ($usercommission->RowType == ROWTYPE_ADD) { // Add record ?>
<span id="el<?php echo $usercommission_grid->RowCount ?>_usercommission_paid" class="form-group">
<input type="text" data-table="usercommission" data-field="x_paid" name="x<?php echo $usercommission_grid->RowIndex ?>_paid" id="x<?php echo $usercommission_grid->RowIndex ?>_paid" size="30" maxlength="1" placeholder="<?php echo HtmlEncode($usercommission_grid->paid->getPlaceHolder()) ?>" value="<?php echo $usercommission_grid->paid->EditValue ?>"<?php echo $usercommission_grid->paid->editAttributes() ?>>
</span>
<input type="hidden" data-table="usercommission" data-field="x_paid" name="o<?php echo $usercommission_grid->RowIndex ?>_paid" id="o<?php echo $usercommission_grid->RowIndex ?>_paid" value="<?php echo HtmlEncode($usercommission_grid->paid->OldValue) ?>">
<?php } ?>
<?php if ($usercommission->RowType == ROWTYPE_EDIT) { // Edit record ?>
<span id="el<?php echo $usercommission_grid->RowCount ?>_usercommission_paid" class="form-group">
<input type="text" data-table="usercommission" data-field="x_paid" name="x<?php echo $usercommission_grid->RowIndex ?>_paid" id="x<?php echo $usercommission_grid->RowIndex ?>_paid" size="30" maxlength="1" placeholder="<?php echo HtmlEncode($usercommission_grid->paid->getPlaceHolder()) ?>" value="<?php echo $usercommission_grid->paid->EditValue ?>"<?php echo $usercommission_grid->paid->editAttributes() ?>>
</span>
<?php } ?>
<?php if ($usercommission->RowType == ROWTYPE_VIEW) { // View record ?>
<span id="el<?php echo $usercommission_grid->RowCount ?>_usercommission_paid">
<span<?php echo $usercommission_grid->paid->viewAttributes() ?>><?php echo $usercommission_grid->paid->getViewValue() ?></span>
</span>
<?php if (!$usercommission->isConfirm()) { ?>
<input type="hidden" data-table="usercommission" data-field="x_paid" name="x<?php echo $usercommission_grid->RowIndex ?>_paid" id="x<?php echo $usercommission_grid->RowIndex ?>_paid" value="<?php echo HtmlEncode($usercommission_grid->paid->FormValue) ?>">
<input type="hidden" data-table="usercommission" data-field="x_paid" name="o<?php echo $usercommission_grid->RowIndex ?>_paid" id="o<?php echo $usercommission_grid->RowIndex ?>_paid" value="<?php echo HtmlEncode($usercommission_grid->paid->OldValue) ?>">
<?php } else { ?>
<input type="hidden" data-table="usercommission" data-field="x_paid" name="fusercommissiongrid$x<?php echo $usercommission_grid->RowIndex ?>_paid" id="fusercommissiongrid$x<?php echo $usercommission_grid->RowIndex ?>_paid" value="<?php echo HtmlEncode($usercommission_grid->paid->FormValue) ?>">
<input type="hidden" data-table="usercommission" data-field="x_paid" name="fusercommissiongrid$o<?php echo $usercommission_grid->RowIndex ?>_paid" id="fusercommissiongrid$o<?php echo $usercommission_grid->RowIndex ?>_paid" value="<?php echo HtmlEncode($usercommission_grid->paid->OldValue) ?>">
<?php } ?>
<?php } ?>
</td>
	<?php } ?>
<?php

// Render list options (body, right)
$usercommission_grid->ListOptions->render("body", "right", $usercommission_grid->RowCount);
?>
	</tr>
<?php if ($usercommission->RowType == ROWTYPE_ADD || $usercommission->RowType == ROWTYPE_EDIT) { ?>
<script>
loadjs.ready(["fusercommissiongrid", "load"], function() {
	fusercommissiongrid.updateLists(<?php echo $usercommission_grid->RowIndex ?>);
});
</script>
<?php } ?>
<?php
	}
	} // End delete row checking
	if (!$usercommission_grid->isGridAdd() || $usercommission->CurrentMode == "copy")
		if (!$usercommission_grid->Recordset->EOF)
			$usercommission_grid->Recordset->moveNext();
}
?>
<?php
	if ($usercommission->CurrentMode == "add" || $usercommission->CurrentMode == "copy" || $usercommission->CurrentMode == "edit") {
		$usercommission_grid->RowIndex = '$rowindex$';
		$usercommission_grid->loadRowValues();

		// Set row properties
		$usercommission->resetAttributes();
		$usercommission->RowAttrs->merge(["data-rowindex" => $usercommission_grid->RowIndex, "id" => "r0_usercommission", "data-rowtype" => ROWTYPE_ADD]);
		$usercommission->RowAttrs->appendClass("ew-template");
		$usercommission->RowType = ROWTYPE_ADD;

		// Render row
		$usercommission_grid->renderRow();

		// Render list options
		$usercommission_grid->renderListOptions();
		$usercommission_grid->StartRowCount = 0;
?>
	<tr <?php echo $usercommission->rowAttributes() ?>>
<?php

// Render list options (body, left)
$usercommission_grid->ListOptions->render("body", "left", $usercommission_grid->RowIndex);
?>
	<?php if ($usercommission_grid->recid->Visible) { // recid ?>
		<td data-name="recid">
<?php if (!$usercommission->isConfirm()) { ?>
<span id="el$rowindex$_usercommission_recid" class="form-group usercommission_recid"></span>
<?php } else { ?>
<span id="el$rowindex$_usercommission_recid" class="form-group usercommission_recid">
<span<?php echo $usercommission_grid->recid->viewAttributes() ?>><input type="text" readonly class="form-control-plaintext" value="<?php echo HtmlEncode(RemoveHtml($usercommission_grid->recid->ViewValue)) ?>"></span>
</span>
<input type="hidden" data-table="usercommission" data-field="x_recid" name="x<?php echo $usercommission_grid->RowIndex ?>_recid" id="x<?php echo $usercommission_grid->RowIndex ?>_recid" value="<?php echo HtmlEncode($usercommission_grid->recid->FormValue) ?>">
<?php } ?>
<input type="hidden" data-table="usercommission" data-field="x_recid" name="o<?php echo $usercommission_grid->RowIndex ?>_recid" id="o<?php echo $usercommission_grid->RowIndex ?>_recid" value="<?php echo HtmlEncode($usercommission_grid->recid->OldValue) ?>">
</td>
	<?php } ?>
	<?php if ($usercommission_grid->_userid->Visible) { // userid ?>
		<td data-name="_userid">
<?php if (!$usercommission->isConfirm()) { ?>
<?php if ($usercommission_grid->_userid->getSessionValue() != "") { ?>
<span id="el$rowindex$_usercommission__userid" class="form-group usercommission__userid">
<span<?php echo $usercommission_grid->_userid->viewAttributes() ?>><input type="text" readonly class="form-control-plaintext" value="<?php echo HtmlEncode(RemoveHtml($usercommission_grid->_userid->ViewValue)) ?>"></span>
</span>
<input type="hidden" id="x<?php echo $usercommission_grid->RowIndex ?>__userid" name="x<?php echo $usercommission_grid->RowIndex ?>__userid" value="<?php echo HtmlEncode($usercommission_grid->_userid->CurrentValue) ?>">
<?php } else { ?>
<span id="el$rowindex$_usercommission__userid" class="form-group usercommission__userid">
<?php
$onchange = $usercommission_grid->_userid->EditAttrs->prepend("onchange", "");
$onchange = ($onchange) ? ' onchange="' . JsEncode($onchange) . '"' : '';
$usercommission_grid->_userid->EditAttrs["onchange"] = "";
?>
<span id="as_x<?php echo $usercommission_grid->RowIndex ?>__userid">
	<input type="text" class="form-control" name="sv_x<?php echo $usercommission_grid->RowIndex ?>__userid" id="sv_x<?php echo $usercommission_grid->RowIndex ?>__userid" value="<?php echo RemoveHtml($usercommission_grid->_userid->EditValue) ?>" size="30" maxlength="12" placeholder="<?php echo HtmlEncode($usercommission_grid->_userid->getPlaceHolder()) ?>" data-placeholder="<?php echo HtmlEncode($usercommission_grid->_userid->getPlaceHolder()) ?>"<?php echo $usercommission_grid->_userid->editAttributes() ?>>
</span>
<input type="hidden" data-table="usercommission" data-field="x__userid" data-value-separator="<?php echo $usercommission_grid->_userid->displayValueSeparatorAttribute() ?>" name="x<?php echo $usercommission_grid->RowIndex ?>__userid" id="x<?php echo $usercommission_grid->RowIndex ?>__userid" value="<?php echo HtmlEncode($usercommission_grid->_userid->CurrentValue) ?>"<?php echo $onchange ?>>
<script>
loadjs.ready(["fusercommissiongrid"], function() {
	fusercommissiongrid.createAutoSuggest({"id":"x<?php echo $usercommission_grid->RowIndex ?>__userid","forceSelect":false});
});
</script>
<?php echo $usercommission_grid->_userid->Lookup->getParamTag($usercommission_grid, "p_x" . $usercommission_grid->RowIndex . "__userid") ?>
</span>
<?php } ?>
<?php } else { ?>
<span id="el$rowindex$_usercommission__userid" class="form-group usercommission__userid">
<span<?php echo $usercommission_grid->_userid->viewAttributes() ?>><input type="text" readonly class="form-control-plaintext" value="<?php echo HtmlEncode(RemoveHtml($usercommission_grid->_userid->ViewValue)) ?>"></span>
</span>
<input type="hidden" data-table="usercommission" data-field="x__userid" name="x<?php echo $usercommission_grid->RowIndex ?>__userid" id="x<?php echo $usercommission_grid->RowIndex ?>__userid" value="<?php echo HtmlEncode($usercommission_grid->_userid->FormValue) ?>">
<?php } ?>
<input type="hidden" data-table="usercommission" data-field="x__userid" name="o<?php echo $usercommission_grid->RowIndex ?>__userid" id="o<?php echo $usercommission_grid->RowIndex ?>__userid" value="<?php echo HtmlEncode($usercommission_grid->_userid->OldValue) ?>">
</td>
	<?php } ?>
	<?php if ($usercommission_grid->userpi->Visible) { // userpi ?>
		<td data-name="userpi">
<?php if (!$usercommission->isConfirm()) { ?>
<span id="el$rowindex$_usercommission_userpi" class="form-group usercommission_userpi">
<input type="text" data-table="usercommission" data-field="x_userpi" name="x<?php echo $usercommission_grid->RowIndex ?>_userpi" id="x<?php echo $usercommission_grid->RowIndex ?>_userpi" size="30" maxlength="12" placeholder="<?php echo HtmlEncode($usercommission_grid->userpi->getPlaceHolder()) ?>" value="<?php echo $usercommission_grid->userpi->EditValue ?>"<?php echo $usercommission_grid->userpi->editAttributes() ?>>
</span>
<?php } else { ?>
<span id="el$rowindex$_usercommission_userpi" class="form-group usercommission_userpi">
<span<?php echo $usercommission_grid->userpi->viewAttributes() ?>><input type="text" readonly class="form-control-plaintext" value="<?php echo HtmlEncode(RemoveHtml($usercommission_grid->userpi->ViewValue)) ?>"></span>
</span>
<input type="hidden" data-table="usercommission" data-field="x_userpi" name="x<?php echo $usercommission_grid->RowIndex ?>_userpi" id="x<?php echo $usercommission_grid->RowIndex ?>_userpi" value="<?php echo HtmlEncode($usercommission_grid->userpi->FormValue) ?>">
<?php } ?>
<input type="hidden" data-table="usercommission" data-field="x_userpi" name="o<?php echo $usercommission_grid->RowIndex ?>_userpi" id="o<?php echo $usercommission_grid->RowIndex ?>_userpi" value="<?php echo HtmlEncode($usercommission_grid->userpi->OldValue) ?>">
</td>
	<?php } ?>
	<?php if ($usercommission_grid->category->Visible) { // category ?>
		<td data-name="category">
<?php if (!$usercommission->isConfirm()) { ?>
<span id="el$rowindex$_usercommission_category" class="form-group usercommission_category">
<input type="text" data-table="usercommission" data-field="x_category" name="x<?php echo $usercommission_grid->RowIndex ?>_category" id="x<?php echo $usercommission_grid->RowIndex ?>_category" size="30" maxlength="2" placeholder="<?php echo HtmlEncode($usercommission_grid->category->getPlaceHolder()) ?>" value="<?php echo $usercommission_grid->category->EditValue ?>"<?php echo $usercommission_grid->category->editAttributes() ?>>
</span>
<?php } else { ?>
<span id="el$rowindex$_usercommission_category" class="form-group usercommission_category">
<span<?php echo $usercommission_grid->category->viewAttributes() ?>><input type="text" readonly class="form-control-plaintext" value="<?php echo HtmlEncode(RemoveHtml($usercommission_grid->category->ViewValue)) ?>"></span>
</span>
<input type="hidden" data-table="usercommission" data-field="x_category" name="x<?php echo $usercommission_grid->RowIndex ?>_category" id="x<?php echo $usercommission_grid->RowIndex ?>_category" value="<?php echo HtmlEncode($usercommission_grid->category->FormValue) ?>">
<?php } ?>
<input type="hidden" data-table="usercommission" data-field="x_category" name="o<?php echo $usercommission_grid->RowIndex ?>_category" id="o<?php echo $usercommission_grid->RowIndex ?>_category" value="<?php echo HtmlEncode($usercommission_grid->category->OldValue) ?>">
</td>
	<?php } ?>
	<?php if ($usercommission_grid->transactiondate->Visible) { // transactiondate ?>
		<td data-name="transactiondate">
<?php if (!$usercommission->isConfirm()) { ?>
<span id="el$rowindex$_usercommission_transactiondate" class="form-group usercommission_transactiondate">
<input type="text" data-table="usercommission" data-field="x_transactiondate" name="x<?php echo $usercommission_grid->RowIndex ?>_transactiondate" id="x<?php echo $usercommission_grid->RowIndex ?>_transactiondate" maxlength="19" placeholder="<?php echo HtmlEncode($usercommission_grid->transactiondate->getPlaceHolder()) ?>" value="<?php echo $usercommission_grid->transactiondate->EditValue ?>"<?php echo $usercommission_grid->transactiondate->editAttributes() ?>>
<?php if (!$usercommission_grid->transactiondate->ReadOnly && !$usercommission_grid->transactiondate->Disabled && !isset($usercommission_grid->transactiondate->EditAttrs["readonly"]) && !isset($usercommission_grid->transactiondate->EditAttrs["disabled"])) { ?>
<script>
loadjs.ready(["fusercommissiongrid", "datetimepicker"], function() {
	ew.createDateTimePicker("fusercommissiongrid", "x<?php echo $usercommission_grid->RowIndex ?>_transactiondate", {"ignoreReadonly":true,"useCurrent":false,"format":0});
});
</script>
<?php } ?>
</span>
<?php } else { ?>
<span id="el$rowindex$_usercommission_transactiondate" class="form-group usercommission_transactiondate">
<span<?php echo $usercommission_grid->transactiondate->viewAttributes() ?>><input type="text" readonly class="form-control-plaintext" value="<?php echo HtmlEncode(RemoveHtml($usercommission_grid->transactiondate->ViewValue)) ?>"></span>
</span>
<input type="hidden" data-table="usercommission" data-field="x_transactiondate" name="x<?php echo $usercommission_grid->RowIndex ?>_transactiondate" id="x<?php echo $usercommission_grid->RowIndex ?>_transactiondate" value="<?php echo HtmlEncode($usercommission_grid->transactiondate->FormValue) ?>">
<?php } ?>
<input type="hidden" data-table="usercommission" data-field="x_transactiondate" name="o<?php echo $usercommission_grid->RowIndex ?>_transactiondate" id="o<?php echo $usercommission_grid->RowIndex ?>_transactiondate" value="<?php echo HtmlEncode($usercommission_grid->transactiondate->OldValue) ?>">
</td>
	<?php } ?>
	<?php if ($usercommission_grid->commissionamount->Visible) { // commissionamount ?>
		<td data-name="commissionamount">
<?php if (!$usercommission->isConfirm()) { ?>
<span id="el$rowindex$_usercommission_commissionamount" class="form-group usercommission_commissionamount">
<input type="text" data-table="usercommission" data-field="x_commissionamount" name="x<?php echo $usercommission_grid->RowIndex ?>_commissionamount" id="x<?php echo $usercommission_grid->RowIndex ?>_commissionamount" size="30" maxlength="12" placeholder="<?php echo HtmlEncode($usercommission_grid->commissionamount->getPlaceHolder()) ?>" value="<?php echo $usercommission_grid->commissionamount->EditValue ?>"<?php echo $usercommission_grid->commissionamount->editAttributes() ?>>
</span>
<?php } else { ?>
<span id="el$rowindex$_usercommission_commissionamount" class="form-group usercommission_commissionamount">
<span<?php echo $usercommission_grid->commissionamount->viewAttributes() ?>><input type="text" readonly class="form-control-plaintext" value="<?php echo HtmlEncode(RemoveHtml($usercommission_grid->commissionamount->ViewValue)) ?>"></span>
</span>
<input type="hidden" data-table="usercommission" data-field="x_commissionamount" name="x<?php echo $usercommission_grid->RowIndex ?>_commissionamount" id="x<?php echo $usercommission_grid->RowIndex ?>_commissionamount" value="<?php echo HtmlEncode($usercommission_grid->commissionamount->FormValue) ?>">
<?php } ?>
<input type="hidden" data-table="usercommission" data-field="x_commissionamount" name="o<?php echo $usercommission_grid->RowIndex ?>_commissionamount" id="o<?php echo $usercommission_grid->RowIndex ?>_commissionamount" value="<?php echo HtmlEncode($usercommission_grid->commissionamount->OldValue) ?>">
</td>
	<?php } ?>
	<?php if ($usercommission_grid->payoutdate->Visible) { // payoutdate ?>
		<td data-name="payoutdate">
<?php if (!$usercommission->isConfirm()) { ?>
<span id="el$rowindex$_usercommission_payoutdate" class="form-group usercommission_payoutdate">
<input type="text" data-table="usercommission" data-field="x_payoutdate" name="x<?php echo $usercommission_grid->RowIndex ?>_payoutdate" id="x<?php echo $usercommission_grid->RowIndex ?>_payoutdate" maxlength="10" placeholder="<?php echo HtmlEncode($usercommission_grid->payoutdate->getPlaceHolder()) ?>" value="<?php echo $usercommission_grid->payoutdate->EditValue ?>"<?php echo $usercommission_grid->payoutdate->editAttributes() ?>>
<?php if (!$usercommission_grid->payoutdate->ReadOnly && !$usercommission_grid->payoutdate->Disabled && !isset($usercommission_grid->payoutdate->EditAttrs["readonly"]) && !isset($usercommission_grid->payoutdate->EditAttrs["disabled"])) { ?>
<script>
loadjs.ready(["fusercommissiongrid", "datetimepicker"], function() {
	ew.createDateTimePicker("fusercommissiongrid", "x<?php echo $usercommission_grid->RowIndex ?>_payoutdate", {"ignoreReadonly":true,"useCurrent":false,"format":0});
});
</script>
<?php } ?>
</span>
<?php } else { ?>
<span id="el$rowindex$_usercommission_payoutdate" class="form-group usercommission_payoutdate">
<span<?php echo $usercommission_grid->payoutdate->viewAttributes() ?>><input type="text" readonly class="form-control-plaintext" value="<?php echo HtmlEncode(RemoveHtml($usercommission_grid->payoutdate->ViewValue)) ?>"></span>
</span>
<input type="hidden" data-table="usercommission" data-field="x_payoutdate" name="x<?php echo $usercommission_grid->RowIndex ?>_payoutdate" id="x<?php echo $usercommission_grid->RowIndex ?>_payoutdate" value="<?php echo HtmlEncode($usercommission_grid->payoutdate->FormValue) ?>">
<?php } ?>
<input type="hidden" data-table="usercommission" data-field="x_payoutdate" name="o<?php echo $usercommission_grid->RowIndex ?>_payoutdate" id="o<?php echo $usercommission_grid->RowIndex ?>_payoutdate" value="<?php echo HtmlEncode($usercommission_grid->payoutdate->OldValue) ?>">
</td>
	<?php } ?>
	<?php if ($usercommission_grid->desc->Visible) { // desc ?>
		<td data-name="desc">
<?php if (!$usercommission->isConfirm()) { ?>
<span id="el$rowindex$_usercommission_desc" class="form-group usercommission_desc">
<input type="text" data-table="usercommission" data-field="x_desc" name="x<?php echo $usercommission_grid->RowIndex ?>_desc" id="x<?php echo $usercommission_grid->RowIndex ?>_desc" size="30" maxlength="60" placeholder="<?php echo HtmlEncode($usercommission_grid->desc->getPlaceHolder()) ?>" value="<?php echo $usercommission_grid->desc->EditValue ?>"<?php echo $usercommission_grid->desc->editAttributes() ?>>
</span>
<?php } else { ?>
<span id="el$rowindex$_usercommission_desc" class="form-group usercommission_desc">
<span<?php echo $usercommission_grid->desc->viewAttributes() ?>><input type="text" readonly class="form-control-plaintext" value="<?php echo HtmlEncode(RemoveHtml($usercommission_grid->desc->ViewValue)) ?>"></span>
</span>
<input type="hidden" data-table="usercommission" data-field="x_desc" name="x<?php echo $usercommission_grid->RowIndex ?>_desc" id="x<?php echo $usercommission_grid->RowIndex ?>_desc" value="<?php echo HtmlEncode($usercommission_grid->desc->FormValue) ?>">
<?php } ?>
<input type="hidden" data-table="usercommission" data-field="x_desc" name="o<?php echo $usercommission_grid->RowIndex ?>_desc" id="o<?php echo $usercommission_grid->RowIndex ?>_desc" value="<?php echo HtmlEncode($usercommission_grid->desc->OldValue) ?>">
</td>
	<?php } ?>
	<?php if ($usercommission_grid->paid->Visible) { // paid ?>
		<td data-name="paid">
<?php if (!$usercommission->isConfirm()) { ?>
<span id="el$rowindex$_usercommission_paid" class="form-group usercommission_paid">
<input type="text" data-table="usercommission" data-field="x_paid" name="x<?php echo $usercommission_grid->RowIndex ?>_paid" id="x<?php echo $usercommission_grid->RowIndex ?>_paid" size="30" maxlength="1" placeholder="<?php echo HtmlEncode($usercommission_grid->paid->getPlaceHolder()) ?>" value="<?php echo $usercommission_grid->paid->EditValue ?>"<?php echo $usercommission_grid->paid->editAttributes() ?>>
</span>
<?php } else { ?>
<span id="el$rowindex$_usercommission_paid" class="form-group usercommission_paid">
<span<?php echo $usercommission_grid->paid->viewAttributes() ?>><input type="text" readonly class="form-control-plaintext" value="<?php echo HtmlEncode(RemoveHtml($usercommission_grid->paid->ViewValue)) ?>"></span>
</span>
<input type="hidden" data-table="usercommission" data-field="x_paid" name="x<?php echo $usercommission_grid->RowIndex ?>_paid" id="x<?php echo $usercommission_grid->RowIndex ?>_paid" value="<?php echo HtmlEncode($usercommission_grid->paid->FormValue) ?>">
<?php } ?>
<input type="hidden" data-table="usercommission" data-field="x_paid" name="o<?php echo $usercommission_grid->RowIndex ?>_paid" id="o<?php echo $usercommission_grid->RowIndex ?>_paid" value="<?php echo HtmlEncode($usercommission_grid->paid->OldValue) ?>">
</td>
	<?php } ?>
<?php

// Render list options (body, right)
$usercommission_grid->ListOptions->render("body", "right", $usercommission_grid->RowIndex);
?>
<script>
loadjs.ready(["fusercommissiongrid", "load"], function() {
	fusercommissiongrid.updateLists(<?php echo $usercommission_grid->RowIndex ?>);
});
</script>
	</tr>
<?php
	}
?>
</tbody>
</table><!-- /.ew-table -->
</div><!-- /.ew-grid-middle-panel -->
<?php if ($usercommission->CurrentMode == "add" || $usercommission->CurrentMode == "copy") { ?>
<input type="hidden" name="<?php echo $usercommission_grid->FormKeyCountName ?>" id="<?php echo $usercommission_grid->FormKeyCountName ?>" value="<?php echo $usercommission_grid->KeyCount ?>">
<?php echo $usercommission_grid->MultiSelectKey ?>
<?php } ?>
<?php if ($usercommission->CurrentMode == "edit") { ?>
<input type="hidden" name="<?php echo $usercommission_grid->FormKeyCountName ?>" id="<?php echo $usercommission_grid->FormKeyCountName ?>" value="<?php echo $usercommission_grid->KeyCount ?>">
<?php echo $usercommission_grid->MultiSelectKey ?>
<?php } ?>
<?php if ($usercommission->CurrentMode == "") { ?>
<input type="hidden" name="action" id="action" value="">
<?php } ?>
<input type="hidden" name="detailpage" value="fusercommissiongrid">
</div><!-- /.ew-list-form -->
<?php

// Close recordset
if ($usercommission_grid->Recordset)
	$usercommission_grid->Recordset->Close();
?>
<?php if ($usercommission_grid->ShowOtherOptions) { ?>
<div class="card-footer ew-grid-lower-panel">
<?php $usercommission_grid->OtherOptions->render("body", "bottom") ?>
</div>
<div class="clearfix"></div>
<?php } ?>
</div><!-- /.ew-grid -->
<?php } ?>
<?php if ($usercommission_grid->TotalRecords == 0 && !$usercommission->CurrentAction) { // Show other options ?>
<div class="ew-list-other-options">
<?php $usercommission_grid->OtherOptions->render("body") ?>
</div>
<div class="clearfix"></div>
<?php } ?>
<?php if (!$usercommission_grid->isExport()) { ?>
<script>
loadjs.ready("load", function() {

	// Startup script
	// Write your table-specific startup script here
	// console.log("page loaded");

});
</script>
<?php } ?>
<?php
$usercommission_grid->terminate();
?>