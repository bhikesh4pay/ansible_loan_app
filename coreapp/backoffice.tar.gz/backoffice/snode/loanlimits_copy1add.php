<?php
namespace PHPMaker2020\_4payadmin;

// Autoload
include_once "autoload.php";

// Session
if (session_status() !== PHP_SESSION_ACTIVE)
	\Delight\Cookie\Session::start(Config("COOKIE_SAMESITE")); // Init session data

// Output buffering
ob_start();
?>
<?php

// Write header
WriteHeader(FALSE);

// Create page object
$loanlimits_copy1_add = new loanlimits_copy1_add();

// Run the page
$loanlimits_copy1_add->run();

// Setup login status
SetupLoginStatus();
SetClientVar("login", LoginStatus());

// Global Page Rendering event (in userfn*.php)
Page_Rendering();

// Page Rendering event
$loanlimits_copy1_add->Page_Render();
?>
<?php include_once "header.php"; ?>
<script>
var floanlimits_copy1add, currentPageID;
loadjs.ready("head", function() {

	// Form object
	currentPageID = ew.PAGE_ID = "add";
	floanlimits_copy1add = currentForm = new ew.Form("floanlimits_copy1add", "add");

	// Validate form
	floanlimits_copy1add.validate = function() {
		if (!this.validateRequired)
			return true; // Ignore validation
		var $ = jQuery, fobj = this.getForm(), $fobj = $(fobj);
		if ($fobj.find("#confirm").val() == "confirm")
			return true;
		var elm, felm, uelm, addcnt = 0;
		var $k = $fobj.find("#" + this.formKeyCountName); // Get key_count
		var rowcnt = ($k[0]) ? parseInt($k.val(), 10) : 1;
		var startcnt = (rowcnt == 0) ? 0 : 1; // Check rowcnt == 0 => Inline-Add
		var gridinsert = ["insert", "gridinsert"].includes($fobj.find("#action").val()) && $k[0];
		for (var i = startcnt; i <= rowcnt; i++) {
			var infix = ($k[0]) ? String(i) : "";
			$fobj.data("rowindex", infix);
			<?php if ($loanlimits_copy1_add->_userid->Required) { ?>
				elm = this.getElements("x" + infix + "__userid");
				if (elm && !ew.isHidden(elm) && !ew.hasValue(elm))
					return this.onError(elm, "<?php echo JsEncode(str_replace("%s", $loanlimits_copy1_add->_userid->caption(), $loanlimits_copy1_add->_userid->RequiredErrorMessage)) ?>");
			<?php } ?>
				elm = this.getElements("x" + infix + "__userid");
				if (elm && !ew.checkInteger(elm.value))
					return this.onError(elm, "<?php echo JsEncode($loanlimits_copy1_add->_userid->errorMessage()) ?>");
			<?php if ($loanlimits_copy1_add->currcode->Required) { ?>
				elm = this.getElements("x" + infix + "_currcode");
				if (elm && !ew.isHidden(elm) && !ew.hasValue(elm))
					return this.onError(elm, "<?php echo JsEncode(str_replace("%s", $loanlimits_copy1_add->currcode->caption(), $loanlimits_copy1_add->currcode->RequiredErrorMessage)) ?>");
			<?php } ?>
			<?php if ($loanlimits_copy1_add->eligiblelimit->Required) { ?>
				elm = this.getElements("x" + infix + "_eligiblelimit");
				if (elm && !ew.isHidden(elm) && !ew.hasValue(elm))
					return this.onError(elm, "<?php echo JsEncode(str_replace("%s", $loanlimits_copy1_add->eligiblelimit->caption(), $loanlimits_copy1_add->eligiblelimit->RequiredErrorMessage)) ?>");
			<?php } ?>
				elm = this.getElements("x" + infix + "_eligiblelimit");
				if (elm && !ew.checkNumber(elm.value))
					return this.onError(elm, "<?php echo JsEncode($loanlimits_copy1_add->eligiblelimit->errorMessage()) ?>");
			<?php if ($loanlimits_copy1_add->lastupdatetime->Required) { ?>
				elm = this.getElements("x" + infix + "_lastupdatetime");
				if (elm && !ew.isHidden(elm) && !ew.hasValue(elm))
					return this.onError(elm, "<?php echo JsEncode(str_replace("%s", $loanlimits_copy1_add->lastupdatetime->caption(), $loanlimits_copy1_add->lastupdatetime->RequiredErrorMessage)) ?>");
			<?php } ?>
				elm = this.getElements("x" + infix + "_lastupdatetime");
				if (elm && !ew.checkDateDef(elm.value))
					return this.onError(elm, "<?php echo JsEncode($loanlimits_copy1_add->lastupdatetime->errorMessage()) ?>");

				// Call Form_CustomValidate event
				if (!this.Form_CustomValidate(fobj))
					return false;
		}

		// Process detail forms
		var dfs = $fobj.find("input[name='detailpage']").get();
		for (var i = 0; i < dfs.length; i++) {
			var df = dfs[i], val = df.value;
			if (val && ew.forms[val])
				if (!ew.forms[val].validate())
					return false;
		}
		return true;
	}

	// Form_CustomValidate
	floanlimits_copy1add.Form_CustomValidate = function(fobj) { // DO NOT CHANGE THIS LINE!

		// Your custom validation code here, return false if invalid.
		return true;
	}

	// Use JavaScript validation or not
	floanlimits_copy1add.validateRequired = <?php echo Config("CLIENT_VALIDATE") ? "true" : "false" ?>;

	// Dynamic selection lists
	loadjs.done("floanlimits_copy1add");
});
</script>
<script>
loadjs.ready("head", function() {

	// Client script
	// Write your client script here, no need to add script tags.

});
</script>
<?php $loanlimits_copy1_add->showPageHeader(); ?>
<?php
$loanlimits_copy1_add->showMessage();
?>
<form name="floanlimits_copy1add" id="floanlimits_copy1add" class="<?php echo $loanlimits_copy1_add->FormClassName ?>" action="<?php echo CurrentPageName() ?>" method="post">
<?php if ($Page->CheckToken) { ?>
<input type="hidden" name="<?php echo Config("TOKEN_NAME") ?>" value="<?php echo $Page->Token ?>">
<?php } ?>
<input type="hidden" name="t" value="loanlimits_copy1">
<input type="hidden" name="action" id="action" value="insert">
<input type="hidden" name="modal" value="<?php echo (int)$loanlimits_copy1_add->IsModal ?>">
<div class="ew-add-div"><!-- page* -->
<?php if ($loanlimits_copy1_add->_userid->Visible) { // userid ?>
	<div id="r__userid" class="form-group row">
		<label id="elh_loanlimits_copy1__userid" for="x__userid" class="<?php echo $loanlimits_copy1_add->LeftColumnClass ?>"><?php echo $loanlimits_copy1_add->_userid->caption() ?><?php echo $loanlimits_copy1_add->_userid->Required ? $Language->phrase("FieldRequiredIndicator") : "" ?></label>
		<div class="<?php echo $loanlimits_copy1_add->RightColumnClass ?>"><div <?php echo $loanlimits_copy1_add->_userid->cellAttributes() ?>>
<span id="el_loanlimits_copy1__userid">
<input type="text" data-table="loanlimits_copy1" data-field="x__userid" name="x__userid" id="x__userid" size="30" maxlength="12" placeholder="<?php echo HtmlEncode($loanlimits_copy1_add->_userid->getPlaceHolder()) ?>" value="<?php echo $loanlimits_copy1_add->_userid->EditValue ?>"<?php echo $loanlimits_copy1_add->_userid->editAttributes() ?>>
</span>
<?php echo $loanlimits_copy1_add->_userid->CustomMsg ?></div></div>
	</div>
<?php } ?>
<?php if ($loanlimits_copy1_add->currcode->Visible) { // currcode ?>
	<div id="r_currcode" class="form-group row">
		<label id="elh_loanlimits_copy1_currcode" for="x_currcode" class="<?php echo $loanlimits_copy1_add->LeftColumnClass ?>"><?php echo $loanlimits_copy1_add->currcode->caption() ?><?php echo $loanlimits_copy1_add->currcode->Required ? $Language->phrase("FieldRequiredIndicator") : "" ?></label>
		<div class="<?php echo $loanlimits_copy1_add->RightColumnClass ?>"><div <?php echo $loanlimits_copy1_add->currcode->cellAttributes() ?>>
<span id="el_loanlimits_copy1_currcode">
<input type="text" data-table="loanlimits_copy1" data-field="x_currcode" name="x_currcode" id="x_currcode" size="30" maxlength="3" placeholder="<?php echo HtmlEncode($loanlimits_copy1_add->currcode->getPlaceHolder()) ?>" value="<?php echo $loanlimits_copy1_add->currcode->EditValue ?>"<?php echo $loanlimits_copy1_add->currcode->editAttributes() ?>>
</span>
<?php echo $loanlimits_copy1_add->currcode->CustomMsg ?></div></div>
	</div>
<?php } ?>
<?php if ($loanlimits_copy1_add->eligiblelimit->Visible) { // eligiblelimit ?>
	<div id="r_eligiblelimit" class="form-group row">
		<label id="elh_loanlimits_copy1_eligiblelimit" for="x_eligiblelimit" class="<?php echo $loanlimits_copy1_add->LeftColumnClass ?>"><?php echo $loanlimits_copy1_add->eligiblelimit->caption() ?><?php echo $loanlimits_copy1_add->eligiblelimit->Required ? $Language->phrase("FieldRequiredIndicator") : "" ?></label>
		<div class="<?php echo $loanlimits_copy1_add->RightColumnClass ?>"><div <?php echo $loanlimits_copy1_add->eligiblelimit->cellAttributes() ?>>
<span id="el_loanlimits_copy1_eligiblelimit">
<input type="text" data-table="loanlimits_copy1" data-field="x_eligiblelimit" name="x_eligiblelimit" id="x_eligiblelimit" size="30" maxlength="15" placeholder="<?php echo HtmlEncode($loanlimits_copy1_add->eligiblelimit->getPlaceHolder()) ?>" value="<?php echo $loanlimits_copy1_add->eligiblelimit->EditValue ?>"<?php echo $loanlimits_copy1_add->eligiblelimit->editAttributes() ?>>
</span>
<?php echo $loanlimits_copy1_add->eligiblelimit->CustomMsg ?></div></div>
	</div>
<?php } ?>
<?php if ($loanlimits_copy1_add->lastupdatetime->Visible) { // lastupdatetime ?>
	<div id="r_lastupdatetime" class="form-group row">
		<label id="elh_loanlimits_copy1_lastupdatetime" for="x_lastupdatetime" class="<?php echo $loanlimits_copy1_add->LeftColumnClass ?>"><?php echo $loanlimits_copy1_add->lastupdatetime->caption() ?><?php echo $loanlimits_copy1_add->lastupdatetime->Required ? $Language->phrase("FieldRequiredIndicator") : "" ?></label>
		<div class="<?php echo $loanlimits_copy1_add->RightColumnClass ?>"><div <?php echo $loanlimits_copy1_add->lastupdatetime->cellAttributes() ?>>
<span id="el_loanlimits_copy1_lastupdatetime">
<input type="text" data-table="loanlimits_copy1" data-field="x_lastupdatetime" name="x_lastupdatetime" id="x_lastupdatetime" maxlength="19" placeholder="<?php echo HtmlEncode($loanlimits_copy1_add->lastupdatetime->getPlaceHolder()) ?>" value="<?php echo $loanlimits_copy1_add->lastupdatetime->EditValue ?>"<?php echo $loanlimits_copy1_add->lastupdatetime->editAttributes() ?>>
<?php if (!$loanlimits_copy1_add->lastupdatetime->ReadOnly && !$loanlimits_copy1_add->lastupdatetime->Disabled && !isset($loanlimits_copy1_add->lastupdatetime->EditAttrs["readonly"]) && !isset($loanlimits_copy1_add->lastupdatetime->EditAttrs["disabled"])) { ?>
<script>
loadjs.ready(["floanlimits_copy1add", "datetimepicker"], function() {
	ew.createDateTimePicker("floanlimits_copy1add", "x_lastupdatetime", {"ignoreReadonly":true,"useCurrent":false,"format":0});
});
</script>
<?php } ?>
</span>
<?php echo $loanlimits_copy1_add->lastupdatetime->CustomMsg ?></div></div>
	</div>
<?php } ?>
</div><!-- /page* -->
<?php if (!$loanlimits_copy1_add->IsModal) { ?>
<div class="form-group row"><!-- buttons .form-group -->
	<div class="<?php echo $loanlimits_copy1_add->OffsetColumnClass ?>"><!-- buttons offset -->
<button class="btn btn-primary ew-btn" name="btn-action" id="btn-action" type="submit"><?php echo $Language->phrase("AddBtn") ?></button>
<button class="btn btn-default ew-btn" name="btn-cancel" id="btn-cancel" type="button" data-href="<?php echo $loanlimits_copy1_add->getReturnUrl() ?>"><?php echo $Language->phrase("CancelBtn") ?></button>
	</div><!-- /buttons offset -->
</div><!-- /buttons .form-group -->
<?php } ?>
</form>
<?php
$loanlimits_copy1_add->showPageFooter();
if (Config("DEBUG"))
	echo GetDebugMessage();
?>
<script>
loadjs.ready("load", function() {

	// Startup script
	// Write your table-specific startup script here
	// console.log("page loaded");

});
</script>
<?php include_once "footer.php"; ?>
<?php
$loanlimits_copy1_add->terminate();
?>