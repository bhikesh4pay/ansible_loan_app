<?php
namespace PHPMaker2020\_4payadmin;

// Autoload
include_once "autoload.php";

// Session
if (session_status() !== PHP_SESSION_ACTIVE)
	\Delight\Cookie\Session::start(Config("COOKIE_SAMESITE")); // Init session data

// Output buffering
ob_start();
?>
<?php

// Write header
WriteHeader(FALSE);

// Create page object
$userpoints_search = new userpoints_search();

// Run the page
$userpoints_search->run();

// Setup login status
SetupLoginStatus();
SetClientVar("login", LoginStatus());

// Global Page Rendering event (in userfn*.php)
Page_Rendering();

// Page Rendering event
$userpoints_search->Page_Render();
?>
<?php include_once "header.php"; ?>
<script>
var fuserpointssearch, currentPageID;
loadjs.ready("head", function() {

	// Form object for search
	<?php if ($userpoints_search->IsModal) { ?>
	fuserpointssearch = currentAdvancedSearchForm = new ew.Form("fuserpointssearch", "search");
	<?php } else { ?>
	fuserpointssearch = currentForm = new ew.Form("fuserpointssearch", "search");
	<?php } ?>
	currentPageID = ew.PAGE_ID = "search";

	// Validate function for search
	fuserpointssearch.validate = function(fobj) {
		if (!this.validateRequired)
			return true; // Ignore validation
		fobj = fobj || this._form;
		var infix = "";
		elm = this.getElements("x" + infix + "__userid");
		if (elm && !ew.checkInteger(elm.value))
			return this.onError(elm, "<?php echo JsEncode($userpoints_search->_userid->errorMessage()) ?>");
		elm = this.getElements("x" + infix + "_merchantid");
		if (elm && !ew.checkInteger(elm.value))
			return this.onError(elm, "<?php echo JsEncode($userpoints_search->merchantid->errorMessage()) ?>");
		elm = this.getElements("x" + infix + "_points");
		if (elm && !ew.checkInteger(elm.value))
			return this.onError(elm, "<?php echo JsEncode($userpoints_search->points->errorMessage()) ?>");

		// Call Form_CustomValidate event
		if (!this.Form_CustomValidate(fobj))
			return false;
		return true;
	}

	// Form_CustomValidate
	fuserpointssearch.Form_CustomValidate = function(fobj) { // DO NOT CHANGE THIS LINE!

		// Your custom validation code here, return false if invalid.
		return true;
	}

	// Use JavaScript validation or not
	fuserpointssearch.validateRequired = <?php echo Config("CLIENT_VALIDATE") ? "true" : "false" ?>;

	// Dynamic selection lists
	loadjs.done("fuserpointssearch");
});
</script>
<script>
loadjs.ready("head", function() {

	// Client script
	// Write your client script here, no need to add script tags.

});
</script>
<?php $userpoints_search->showPageHeader(); ?>
<?php
$userpoints_search->showMessage();
?>
<form name="fuserpointssearch" id="fuserpointssearch" class="<?php echo $userpoints_search->FormClassName ?>" action="<?php echo CurrentPageName() ?>" method="post">
<?php if ($Page->CheckToken) { ?>
<input type="hidden" name="<?php echo Config("TOKEN_NAME") ?>" value="<?php echo $Page->Token ?>">
<?php } ?>
<input type="hidden" name="t" value="userpoints">
<input type="hidden" name="action" id="action" value="search">
<input type="hidden" name="modal" value="<?php echo (int)$userpoints_search->IsModal ?>">
<div class="ew-search-div"><!-- page* -->
<?php if ($userpoints_search->_userid->Visible) { // userid ?>
	<div id="r__userid" class="form-group row">
		<label for="x__userid" class="<?php echo $userpoints_search->LeftColumnClass ?>"><span id="elh_userpoints__userid"><?php echo $userpoints_search->_userid->caption() ?></span>
		<span class="ew-search-operator">
<?php echo $Language->phrase("=") ?>
<input type="hidden" name="z__userid" id="z__userid" value="=">
</span>
		</label>
		<div class="<?php echo $userpoints_search->RightColumnClass ?>"><div <?php echo $userpoints_search->_userid->cellAttributes() ?>>
			<span id="el_userpoints__userid" class="ew-search-field">
<input type="text" data-table="userpoints" data-field="x__userid" name="x__userid" id="x__userid" size="30" placeholder="<?php echo HtmlEncode($userpoints_search->_userid->getPlaceHolder()) ?>" value="<?php echo $userpoints_search->_userid->EditValue ?>"<?php echo $userpoints_search->_userid->editAttributes() ?>>
</span>
		</div></div>
	</div>
<?php } ?>
<?php if ($userpoints_search->pointid->Visible) { // pointid ?>
	<div id="r_pointid" class="form-group row">
		<label for="x_pointid" class="<?php echo $userpoints_search->LeftColumnClass ?>"><span id="elh_userpoints_pointid"><?php echo $userpoints_search->pointid->caption() ?></span>
		<span class="ew-search-operator">
<?php echo $Language->phrase("LIKE") ?>
<input type="hidden" name="z_pointid" id="z_pointid" value="LIKE">
</span>
		</label>
		<div class="<?php echo $userpoints_search->RightColumnClass ?>"><div <?php echo $userpoints_search->pointid->cellAttributes() ?>>
			<span id="el_userpoints_pointid" class="ew-search-field">
<input type="text" data-table="userpoints" data-field="x_pointid" name="x_pointid" id="x_pointid" size="30" maxlength="3" placeholder="<?php echo HtmlEncode($userpoints_search->pointid->getPlaceHolder()) ?>" value="<?php echo $userpoints_search->pointid->EditValue ?>"<?php echo $userpoints_search->pointid->editAttributes() ?>>
</span>
		</div></div>
	</div>
<?php } ?>
<?php if ($userpoints_search->merchantid->Visible) { // merchantid ?>
	<div id="r_merchantid" class="form-group row">
		<label for="x_merchantid" class="<?php echo $userpoints_search->LeftColumnClass ?>"><span id="elh_userpoints_merchantid"><?php echo $userpoints_search->merchantid->caption() ?></span>
		<span class="ew-search-operator">
<?php echo $Language->phrase("=") ?>
<input type="hidden" name="z_merchantid" id="z_merchantid" value="=">
</span>
		</label>
		<div class="<?php echo $userpoints_search->RightColumnClass ?>"><div <?php echo $userpoints_search->merchantid->cellAttributes() ?>>
			<span id="el_userpoints_merchantid" class="ew-search-field">
<input type="text" data-table="userpoints" data-field="x_merchantid" name="x_merchantid" id="x_merchantid" size="30" placeholder="<?php echo HtmlEncode($userpoints_search->merchantid->getPlaceHolder()) ?>" value="<?php echo $userpoints_search->merchantid->EditValue ?>"<?php echo $userpoints_search->merchantid->editAttributes() ?>>
</span>
		</div></div>
	</div>
<?php } ?>
<?php if ($userpoints_search->points->Visible) { // points ?>
	<div id="r_points" class="form-group row">
		<label for="x_points" class="<?php echo $userpoints_search->LeftColumnClass ?>"><span id="elh_userpoints_points"><?php echo $userpoints_search->points->caption() ?></span>
		<span class="ew-search-operator">
<?php echo $Language->phrase("=") ?>
<input type="hidden" name="z_points" id="z_points" value="=">
</span>
		</label>
		<div class="<?php echo $userpoints_search->RightColumnClass ?>"><div <?php echo $userpoints_search->points->cellAttributes() ?>>
			<span id="el_userpoints_points" class="ew-search-field">
<input type="text" data-table="userpoints" data-field="x_points" name="x_points" id="x_points" size="30" placeholder="<?php echo HtmlEncode($userpoints_search->points->getPlaceHolder()) ?>" value="<?php echo $userpoints_search->points->EditValue ?>"<?php echo $userpoints_search->points->editAttributes() ?>>
</span>
		</div></div>
	</div>
<?php } ?>
</div><!-- /page* -->
<?php if (!$userpoints_search->IsModal) { ?>
<div class="form-group row"><!-- buttons .form-group -->
	<div class="<?php echo $userpoints_search->OffsetColumnClass ?>"><!-- buttons offset -->
<button class="btn btn-primary ew-btn" name="btn-action" id="btn-action" type="submit"><?php echo $Language->phrase("Search") ?></button>
<button class="btn btn-default ew-btn" name="btn-reset" id="btn-reset" type="button" onclick="ew.clearForm(this.form);"><?php echo $Language->phrase("Reset") ?></button>
	</div><!-- /buttons offset -->
</div><!-- /buttons .form-group -->
<?php } ?>
</form>
<?php
$userpoints_search->showPageFooter();
if (Config("DEBUG"))
	echo GetDebugMessage();
?>
<script>
loadjs.ready("load", function() {

	// Startup script
	// Write your table-specific startup script here
	// console.log("page loaded");

});
</script>
<?php include_once "footer.php"; ?>
<?php
$userpoints_search->terminate();
?>