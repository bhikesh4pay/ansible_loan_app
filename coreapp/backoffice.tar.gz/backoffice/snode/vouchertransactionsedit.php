<?php
namespace PHPMaker2020\_4payadmin;

// Autoload
include_once "autoload.php";

// Session
if (session_status() !== PHP_SESSION_ACTIVE)
	\Delight\Cookie\Session::start(Config("COOKIE_SAMESITE")); // Init session data

// Output buffering
ob_start();
?>
<?php

// Write header
WriteHeader(FALSE);

// Create page object
$vouchertransactions_edit = new vouchertransactions_edit();

// Run the page
$vouchertransactions_edit->run();

// Setup login status
SetupLoginStatus();
SetClientVar("login", LoginStatus());

// Global Page Rendering event (in userfn*.php)
Page_Rendering();

// Page Rendering event
$vouchertransactions_edit->Page_Render();
?>
<?php include_once "header.php"; ?>
<script>
var fvouchertransactionsedit, currentPageID;
loadjs.ready("head", function() {

	// Form object
	currentPageID = ew.PAGE_ID = "edit";
	fvouchertransactionsedit = currentForm = new ew.Form("fvouchertransactionsedit", "edit");

	// Validate form
	fvouchertransactionsedit.validate = function() {
		if (!this.validateRequired)
			return true; // Ignore validation
		var $ = jQuery, fobj = this.getForm(), $fobj = $(fobj);
		if ($fobj.find("#confirm").val() == "confirm")
			return true;
		var elm, felm, uelm, addcnt = 0;
		var $k = $fobj.find("#" + this.formKeyCountName); // Get key_count
		var rowcnt = ($k[0]) ? parseInt($k.val(), 10) : 1;
		var startcnt = (rowcnt == 0) ? 0 : 1; // Check rowcnt == 0 => Inline-Add
		var gridinsert = ["insert", "gridinsert"].includes($fobj.find("#action").val()) && $k[0];
		for (var i = startcnt; i <= rowcnt; i++) {
			var infix = ($k[0]) ? String(i) : "";
			$fobj.data("rowindex", infix);
			<?php if ($vouchertransactions_edit->transid->Required) { ?>
				elm = this.getElements("x" + infix + "_transid");
				if (elm && !ew.isHidden(elm) && !ew.hasValue(elm))
					return this.onError(elm, "<?php echo JsEncode(str_replace("%s", $vouchertransactions_edit->transid->caption(), $vouchertransactions_edit->transid->RequiredErrorMessage)) ?>");
			<?php } ?>
			<?php if ($vouchertransactions_edit->userpi->Required) { ?>
				elm = this.getElements("x" + infix + "_userpi");
				if (elm && !ew.isHidden(elm) && !ew.hasValue(elm))
					return this.onError(elm, "<?php echo JsEncode(str_replace("%s", $vouchertransactions_edit->userpi->caption(), $vouchertransactions_edit->userpi->RequiredErrorMessage)) ?>");
			<?php } ?>
				elm = this.getElements("x" + infix + "_userpi");
				if (elm && !ew.checkInteger(elm.value))
					return this.onError(elm, "<?php echo JsEncode($vouchertransactions_edit->userpi->errorMessage()) ?>");
			<?php if ($vouchertransactions_edit->issuedbyagentid->Required) { ?>
				elm = this.getElements("x" + infix + "_issuedbyagentid");
				if (elm && !ew.isHidden(elm) && !ew.hasValue(elm))
					return this.onError(elm, "<?php echo JsEncode(str_replace("%s", $vouchertransactions_edit->issuedbyagentid->caption(), $vouchertransactions_edit->issuedbyagentid->RequiredErrorMessage)) ?>");
			<?php } ?>
			<?php if ($vouchertransactions_edit->issuedbyoperatorid->Required) { ?>
				elm = this.getElements("x" + infix + "_issuedbyoperatorid");
				if (elm && !ew.isHidden(elm) && !ew.hasValue(elm))
					return this.onError(elm, "<?php echo JsEncode(str_replace("%s", $vouchertransactions_edit->issuedbyoperatorid->caption(), $vouchertransactions_edit->issuedbyoperatorid->RequiredErrorMessage)) ?>");
			<?php } ?>
			<?php if ($vouchertransactions_edit->issueddate->Required) { ?>
				elm = this.getElements("x" + infix + "_issueddate");
				if (elm && !ew.isHidden(elm) && !ew.hasValue(elm))
					return this.onError(elm, "<?php echo JsEncode(str_replace("%s", $vouchertransactions_edit->issueddate->caption(), $vouchertransactions_edit->issueddate->RequiredErrorMessage)) ?>");
			<?php } ?>
				elm = this.getElements("x" + infix + "_issueddate");
				if (elm && !ew.checkDateDef(elm.value))
					return this.onError(elm, "<?php echo JsEncode($vouchertransactions_edit->issueddate->errorMessage()) ?>");
			<?php if ($vouchertransactions_edit->customername->Required) { ?>
				elm = this.getElements("x" + infix + "_customername");
				if (elm && !ew.isHidden(elm) && !ew.hasValue(elm))
					return this.onError(elm, "<?php echo JsEncode(str_replace("%s", $vouchertransactions_edit->customername->caption(), $vouchertransactions_edit->customername->RequiredErrorMessage)) ?>");
			<?php } ?>
			<?php if ($vouchertransactions_edit->phoneno->Required) { ?>
				elm = this.getElements("x" + infix + "_phoneno");
				if (elm && !ew.isHidden(elm) && !ew.hasValue(elm))
					return this.onError(elm, "<?php echo JsEncode(str_replace("%s", $vouchertransactions_edit->phoneno->caption(), $vouchertransactions_edit->phoneno->RequiredErrorMessage)) ?>");
			<?php } ?>
			<?php if ($vouchertransactions_edit->canceledbyagentid->Required) { ?>
				elm = this.getElements("x" + infix + "_canceledbyagentid");
				if (elm && !ew.isHidden(elm) && !ew.hasValue(elm))
					return this.onError(elm, "<?php echo JsEncode(str_replace("%s", $vouchertransactions_edit->canceledbyagentid->caption(), $vouchertransactions_edit->canceledbyagentid->RequiredErrorMessage)) ?>");
			<?php } ?>
				elm = this.getElements("x" + infix + "_canceledbyagentid");
				if (elm && !ew.checkInteger(elm.value))
					return this.onError(elm, "<?php echo JsEncode($vouchertransactions_edit->canceledbyagentid->errorMessage()) ?>");
			<?php if ($vouchertransactions_edit->cancelledbyoperatorid->Required) { ?>
				elm = this.getElements("x" + infix + "_cancelledbyoperatorid");
				if (elm && !ew.isHidden(elm) && !ew.hasValue(elm))
					return this.onError(elm, "<?php echo JsEncode(str_replace("%s", $vouchertransactions_edit->cancelledbyoperatorid->caption(), $vouchertransactions_edit->cancelledbyoperatorid->RequiredErrorMessage)) ?>");
			<?php } ?>
				elm = this.getElements("x" + infix + "_cancelledbyoperatorid");
				if (elm && !ew.checkInteger(elm.value))
					return this.onError(elm, "<?php echo JsEncode($vouchertransactions_edit->cancelledbyoperatorid->errorMessage()) ?>");
			<?php if ($vouchertransactions_edit->cancelleddate->Required) { ?>
				elm = this.getElements("x" + infix + "_cancelleddate");
				if (elm && !ew.isHidden(elm) && !ew.hasValue(elm))
					return this.onError(elm, "<?php echo JsEncode(str_replace("%s", $vouchertransactions_edit->cancelleddate->caption(), $vouchertransactions_edit->cancelleddate->RequiredErrorMessage)) ?>");
			<?php } ?>
				elm = this.getElements("x" + infix + "_cancelleddate");
				if (elm && !ew.checkDateDef(elm.value))
					return this.onError(elm, "<?php echo JsEncode($vouchertransactions_edit->cancelleddate->errorMessage()) ?>");
			<?php if ($vouchertransactions_edit->glnovouchercreation->Required) { ?>
				elm = this.getElements("x" + infix + "_glnovouchercreation");
				if (elm && !ew.isHidden(elm) && !ew.hasValue(elm))
					return this.onError(elm, "<?php echo JsEncode(str_replace("%s", $vouchertransactions_edit->glnovouchercreation->caption(), $vouchertransactions_edit->glnovouchercreation->RequiredErrorMessage)) ?>");
			<?php } ?>
				elm = this.getElements("x" + infix + "_glnovouchercreation");
				if (elm && !ew.checkInteger(elm.value))
					return this.onError(elm, "<?php echo JsEncode($vouchertransactions_edit->glnovouchercreation->errorMessage()) ?>");
			<?php if ($vouchertransactions_edit->glnovouchercancellation->Required) { ?>
				elm = this.getElements("x" + infix + "_glnovouchercancellation");
				if (elm && !ew.isHidden(elm) && !ew.hasValue(elm))
					return this.onError(elm, "<?php echo JsEncode(str_replace("%s", $vouchertransactions_edit->glnovouchercancellation->caption(), $vouchertransactions_edit->glnovouchercancellation->RequiredErrorMessage)) ?>");
			<?php } ?>
				elm = this.getElements("x" + infix + "_glnovouchercancellation");
				if (elm && !ew.checkInteger(elm.value))
					return this.onError(elm, "<?php echo JsEncode($vouchertransactions_edit->glnovouchercancellation->errorMessage()) ?>");
			<?php if ($vouchertransactions_edit->issuedamount->Required) { ?>
				elm = this.getElements("x" + infix + "_issuedamount");
				if (elm && !ew.isHidden(elm) && !ew.hasValue(elm))
					return this.onError(elm, "<?php echo JsEncode(str_replace("%s", $vouchertransactions_edit->issuedamount->caption(), $vouchertransactions_edit->issuedamount->RequiredErrorMessage)) ?>");
			<?php } ?>
				elm = this.getElements("x" + infix + "_issuedamount");
				if (elm && !ew.checkNumber(elm.value))
					return this.onError(elm, "<?php echo JsEncode($vouchertransactions_edit->issuedamount->errorMessage()) ?>");
			<?php if ($vouchertransactions_edit->cancelledamount->Required) { ?>
				elm = this.getElements("x" + infix + "_cancelledamount");
				if (elm && !ew.isHidden(elm) && !ew.hasValue(elm))
					return this.onError(elm, "<?php echo JsEncode(str_replace("%s", $vouchertransactions_edit->cancelledamount->caption(), $vouchertransactions_edit->cancelledamount->RequiredErrorMessage)) ?>");
			<?php } ?>
				elm = this.getElements("x" + infix + "_cancelledamount");
				if (elm && !ew.checkNumber(elm.value))
					return this.onError(elm, "<?php echo JsEncode($vouchertransactions_edit->cancelledamount->errorMessage()) ?>");
			<?php if ($vouchertransactions_edit->currcode->Required) { ?>
				elm = this.getElements("x" + infix + "_currcode");
				if (elm && !ew.isHidden(elm) && !ew.hasValue(elm))
					return this.onError(elm, "<?php echo JsEncode(str_replace("%s", $vouchertransactions_edit->currcode->caption(), $vouchertransactions_edit->currcode->RequiredErrorMessage)) ?>");
			<?php } ?>
			<?php if ($vouchertransactions_edit->paymentmethod->Required) { ?>
				elm = this.getElements("x" + infix + "_paymentmethod");
				if (elm && !ew.isHidden(elm) && !ew.hasValue(elm))
					return this.onError(elm, "<?php echo JsEncode(str_replace("%s", $vouchertransactions_edit->paymentmethod->caption(), $vouchertransactions_edit->paymentmethod->RequiredErrorMessage)) ?>");
			<?php } ?>
			<?php if ($vouchertransactions_edit->paymentdetails->Required) { ?>
				elm = this.getElements("x" + infix + "_paymentdetails");
				if (elm && !ew.isHidden(elm) && !ew.hasValue(elm))
					return this.onError(elm, "<?php echo JsEncode(str_replace("%s", $vouchertransactions_edit->paymentdetails->caption(), $vouchertransactions_edit->paymentdetails->RequiredErrorMessage)) ?>");
			<?php } ?>

				// Call Form_CustomValidate event
				if (!this.Form_CustomValidate(fobj))
					return false;
		}

		// Process detail forms
		var dfs = $fobj.find("input[name='detailpage']").get();
		for (var i = 0; i < dfs.length; i++) {
			var df = dfs[i], val = df.value;
			if (val && ew.forms[val])
				if (!ew.forms[val].validate())
					return false;
		}
		return true;
	}

	// Form_CustomValidate
	fvouchertransactionsedit.Form_CustomValidate = function(fobj) { // DO NOT CHANGE THIS LINE!

		// Your custom validation code here, return false if invalid.
		return true;
	}

	// Use JavaScript validation or not
	fvouchertransactionsedit.validateRequired = <?php echo Config("CLIENT_VALIDATE") ? "true" : "false" ?>;

	// Dynamic selection lists
	fvouchertransactionsedit.lists["x_issuedbyagentid"] = <?php echo $vouchertransactions_edit->issuedbyagentid->Lookup->toClientList($vouchertransactions_edit) ?>;
	fvouchertransactionsedit.lists["x_issuedbyagentid"].options = <?php echo JsonEncode($vouchertransactions_edit->issuedbyagentid->lookupOptions()) ?>;
	fvouchertransactionsedit.lists["x_issuedbyoperatorid"] = <?php echo $vouchertransactions_edit->issuedbyoperatorid->Lookup->toClientList($vouchertransactions_edit) ?>;
	fvouchertransactionsedit.lists["x_issuedbyoperatorid"].options = <?php echo JsonEncode($vouchertransactions_edit->issuedbyoperatorid->lookupOptions()) ?>;
	fvouchertransactionsedit.lists["x_canceledbyagentid"] = <?php echo $vouchertransactions_edit->canceledbyagentid->Lookup->toClientList($vouchertransactions_edit) ?>;
	fvouchertransactionsedit.lists["x_canceledbyagentid"].options = <?php echo JsonEncode($vouchertransactions_edit->canceledbyagentid->lookupOptions()) ?>;
	fvouchertransactionsedit.autoSuggests["x_canceledbyagentid"] = <?php echo json_encode(["data" => "ajax=autosuggest"]) ?>;
	fvouchertransactionsedit.lists["x_cancelledbyoperatorid"] = <?php echo $vouchertransactions_edit->cancelledbyoperatorid->Lookup->toClientList($vouchertransactions_edit) ?>;
	fvouchertransactionsedit.lists["x_cancelledbyoperatorid"].options = <?php echo JsonEncode($vouchertransactions_edit->cancelledbyoperatorid->lookupOptions()) ?>;
	fvouchertransactionsedit.autoSuggests["x_cancelledbyoperatorid"] = <?php echo json_encode(["data" => "ajax=autosuggest"]) ?>;
	fvouchertransactionsedit.lists["x_paymentmethod"] = <?php echo $vouchertransactions_edit->paymentmethod->Lookup->toClientList($vouchertransactions_edit) ?>;
	fvouchertransactionsedit.lists["x_paymentmethod"].options = <?php echo JsonEncode($vouchertransactions_edit->paymentmethod->options(FALSE, TRUE)) ?>;
	loadjs.done("fvouchertransactionsedit");
});
</script>
<script>
loadjs.ready("head", function() {

	// Client script
	// Write your client script here, no need to add script tags.

});
</script>
<?php $vouchertransactions_edit->showPageHeader(); ?>
<?php
$vouchertransactions_edit->showMessage();
?>
<form name="fvouchertransactionsedit" id="fvouchertransactionsedit" class="<?php echo $vouchertransactions_edit->FormClassName ?>" action="<?php echo CurrentPageName() ?>" method="post">
<?php if ($Page->CheckToken) { ?>
<input type="hidden" name="<?php echo Config("TOKEN_NAME") ?>" value="<?php echo $Page->Token ?>">
<?php } ?>
<input type="hidden" name="t" value="vouchertransactions">
<input type="hidden" name="action" id="action" value="update">
<input type="hidden" name="modal" value="<?php echo (int)$vouchertransactions_edit->IsModal ?>">
<div class="ew-edit-div"><!-- page* -->
<?php if ($vouchertransactions_edit->transid->Visible) { // transid ?>
	<div id="r_transid" class="form-group row">
		<label id="elh_vouchertransactions_transid" class="<?php echo $vouchertransactions_edit->LeftColumnClass ?>"><?php echo $vouchertransactions_edit->transid->caption() ?><?php echo $vouchertransactions_edit->transid->Required ? $Language->phrase("FieldRequiredIndicator") : "" ?></label>
		<div class="<?php echo $vouchertransactions_edit->RightColumnClass ?>"><div <?php echo $vouchertransactions_edit->transid->cellAttributes() ?>>
<span id="el_vouchertransactions_transid">
<span<?php echo $vouchertransactions_edit->transid->viewAttributes() ?>><input type="text" readonly class="form-control-plaintext" value="<?php echo HtmlEncode(RemoveHtml($vouchertransactions_edit->transid->EditValue)) ?>"></span>
</span>
<input type="hidden" data-table="vouchertransactions" data-field="x_transid" name="x_transid" id="x_transid" value="<?php echo HtmlEncode($vouchertransactions_edit->transid->CurrentValue) ?>">
<?php echo $vouchertransactions_edit->transid->CustomMsg ?></div></div>
	</div>
<?php } ?>
<?php if ($vouchertransactions_edit->userpi->Visible) { // userpi ?>
	<div id="r_userpi" class="form-group row">
		<label id="elh_vouchertransactions_userpi" for="x_userpi" class="<?php echo $vouchertransactions_edit->LeftColumnClass ?>"><?php echo $vouchertransactions_edit->userpi->caption() ?><?php echo $vouchertransactions_edit->userpi->Required ? $Language->phrase("FieldRequiredIndicator") : "" ?></label>
		<div class="<?php echo $vouchertransactions_edit->RightColumnClass ?>"><div <?php echo $vouchertransactions_edit->userpi->cellAttributes() ?>>
<span id="el_vouchertransactions_userpi">
<input type="text" data-table="vouchertransactions" data-field="x_userpi" name="x_userpi" id="x_userpi" size="30" maxlength="12" placeholder="<?php echo HtmlEncode($vouchertransactions_edit->userpi->getPlaceHolder()) ?>" value="<?php echo $vouchertransactions_edit->userpi->EditValue ?>"<?php echo $vouchertransactions_edit->userpi->editAttributes() ?>>
</span>
<?php echo $vouchertransactions_edit->userpi->CustomMsg ?></div></div>
	</div>
<?php } ?>
<?php if ($vouchertransactions_edit->issuedbyagentid->Visible) { // issuedbyagentid ?>
	<div id="r_issuedbyagentid" class="form-group row">
		<label id="elh_vouchertransactions_issuedbyagentid" for="x_issuedbyagentid" class="<?php echo $vouchertransactions_edit->LeftColumnClass ?>"><?php echo $vouchertransactions_edit->issuedbyagentid->caption() ?><?php echo $vouchertransactions_edit->issuedbyagentid->Required ? $Language->phrase("FieldRequiredIndicator") : "" ?></label>
		<div class="<?php echo $vouchertransactions_edit->RightColumnClass ?>"><div <?php echo $vouchertransactions_edit->issuedbyagentid->cellAttributes() ?>>
<span id="el_vouchertransactions_issuedbyagentid">
<?php $vouchertransactions_edit->issuedbyagentid->EditAttrs->prepend("onchange", "ew.updateOptions.call(this);"); ?>
<div class="input-group ew-lookup-list">
	<div class="form-control ew-lookup-text" tabindex="-1" id="lu_x_issuedbyagentid"><?php echo EmptyValue(strval($vouchertransactions_edit->issuedbyagentid->ViewValue)) ? $Language->phrase("PleaseSelect") : $vouchertransactions_edit->issuedbyagentid->ViewValue ?></div>
	<div class="input-group-append">
		<button type="button" title="<?php echo HtmlEncode(str_replace("%s", RemoveHtml($vouchertransactions_edit->issuedbyagentid->caption()), $Language->phrase("LookupLink", TRUE))) ?>" class="ew-lookup-btn btn btn-default"<?php echo ($vouchertransactions_edit->issuedbyagentid->ReadOnly || $vouchertransactions_edit->issuedbyagentid->Disabled) ? " disabled" : "" ?> onclick="ew.modalLookupShow({lnk:this,el:'x_issuedbyagentid',m:0,n:10});"><i class="fas fa-search ew-icon"></i></button>
	</div>
</div>
<?php echo $vouchertransactions_edit->issuedbyagentid->Lookup->getParamTag($vouchertransactions_edit, "p_x_issuedbyagentid") ?>
<input type="hidden" data-table="vouchertransactions" data-field="x_issuedbyagentid" data-multiple="0" data-lookup="1" data-value-separator="<?php echo $vouchertransactions_edit->issuedbyagentid->displayValueSeparatorAttribute() ?>" name="x_issuedbyagentid" id="x_issuedbyagentid" value="<?php echo $vouchertransactions_edit->issuedbyagentid->CurrentValue ?>"<?php echo $vouchertransactions_edit->issuedbyagentid->editAttributes() ?>>
</span>
<?php echo $vouchertransactions_edit->issuedbyagentid->CustomMsg ?></div></div>
	</div>
<?php } ?>
<?php if ($vouchertransactions_edit->issuedbyoperatorid->Visible) { // issuedbyoperatorid ?>
	<div id="r_issuedbyoperatorid" class="form-group row">
		<label id="elh_vouchertransactions_issuedbyoperatorid" for="x_issuedbyoperatorid" class="<?php echo $vouchertransactions_edit->LeftColumnClass ?>"><?php echo $vouchertransactions_edit->issuedbyoperatorid->caption() ?><?php echo $vouchertransactions_edit->issuedbyoperatorid->Required ? $Language->phrase("FieldRequiredIndicator") : "" ?></label>
		<div class="<?php echo $vouchertransactions_edit->RightColumnClass ?>"><div <?php echo $vouchertransactions_edit->issuedbyoperatorid->cellAttributes() ?>>
<span id="el_vouchertransactions_issuedbyoperatorid">
<div class="input-group ew-lookup-list">
	<div class="form-control ew-lookup-text" tabindex="-1" id="lu_x_issuedbyoperatorid"><?php echo EmptyValue(strval($vouchertransactions_edit->issuedbyoperatorid->ViewValue)) ? $Language->phrase("PleaseSelect") : $vouchertransactions_edit->issuedbyoperatorid->ViewValue ?></div>
	<div class="input-group-append">
		<button type="button" title="<?php echo HtmlEncode(str_replace("%s", RemoveHtml($vouchertransactions_edit->issuedbyoperatorid->caption()), $Language->phrase("LookupLink", TRUE))) ?>" class="ew-lookup-btn btn btn-default"<?php echo ($vouchertransactions_edit->issuedbyoperatorid->ReadOnly || $vouchertransactions_edit->issuedbyoperatorid->Disabled) ? " disabled" : "" ?> onclick="ew.modalLookupShow({lnk:this,el:'x_issuedbyoperatorid',m:0,n:10});"><i class="fas fa-search ew-icon"></i></button>
	</div>
</div>
<?php echo $vouchertransactions_edit->issuedbyoperatorid->Lookup->getParamTag($vouchertransactions_edit, "p_x_issuedbyoperatorid") ?>
<input type="hidden" data-table="vouchertransactions" data-field="x_issuedbyoperatorid" data-multiple="0" data-lookup="1" data-value-separator="<?php echo $vouchertransactions_edit->issuedbyoperatorid->displayValueSeparatorAttribute() ?>" name="x_issuedbyoperatorid" id="x_issuedbyoperatorid" value="<?php echo $vouchertransactions_edit->issuedbyoperatorid->CurrentValue ?>"<?php echo $vouchertransactions_edit->issuedbyoperatorid->editAttributes() ?>>
</span>
<?php echo $vouchertransactions_edit->issuedbyoperatorid->CustomMsg ?></div></div>
	</div>
<?php } ?>
<?php if ($vouchertransactions_edit->issueddate->Visible) { // issueddate ?>
	<div id="r_issueddate" class="form-group row">
		<label id="elh_vouchertransactions_issueddate" for="x_issueddate" class="<?php echo $vouchertransactions_edit->LeftColumnClass ?>"><?php echo $vouchertransactions_edit->issueddate->caption() ?><?php echo $vouchertransactions_edit->issueddate->Required ? $Language->phrase("FieldRequiredIndicator") : "" ?></label>
		<div class="<?php echo $vouchertransactions_edit->RightColumnClass ?>"><div <?php echo $vouchertransactions_edit->issueddate->cellAttributes() ?>>
<span id="el_vouchertransactions_issueddate">
<input type="text" data-table="vouchertransactions" data-field="x_issueddate" data-format="1" name="x_issueddate" id="x_issueddate" maxlength="19" placeholder="<?php echo HtmlEncode($vouchertransactions_edit->issueddate->getPlaceHolder()) ?>" value="<?php echo $vouchertransactions_edit->issueddate->EditValue ?>"<?php echo $vouchertransactions_edit->issueddate->editAttributes() ?>>
<?php if (!$vouchertransactions_edit->issueddate->ReadOnly && !$vouchertransactions_edit->issueddate->Disabled && !isset($vouchertransactions_edit->issueddate->EditAttrs["readonly"]) && !isset($vouchertransactions_edit->issueddate->EditAttrs["disabled"])) { ?>
<script>
loadjs.ready(["fvouchertransactionsedit", "datetimepicker"], function() {
	ew.createDateTimePicker("fvouchertransactionsedit", "x_issueddate", {"ignoreReadonly":true,"useCurrent":false,"format":1});
});
</script>
<?php } ?>
</span>
<?php echo $vouchertransactions_edit->issueddate->CustomMsg ?></div></div>
	</div>
<?php } ?>
<?php if ($vouchertransactions_edit->customername->Visible) { // customername ?>
	<div id="r_customername" class="form-group row">
		<label id="elh_vouchertransactions_customername" for="x_customername" class="<?php echo $vouchertransactions_edit->LeftColumnClass ?>"><?php echo $vouchertransactions_edit->customername->caption() ?><?php echo $vouchertransactions_edit->customername->Required ? $Language->phrase("FieldRequiredIndicator") : "" ?></label>
		<div class="<?php echo $vouchertransactions_edit->RightColumnClass ?>"><div <?php echo $vouchertransactions_edit->customername->cellAttributes() ?>>
<span id="el_vouchertransactions_customername">
<input type="text" data-table="vouchertransactions" data-field="x_customername" name="x_customername" id="x_customername" size="30" maxlength="60" placeholder="<?php echo HtmlEncode($vouchertransactions_edit->customername->getPlaceHolder()) ?>" value="<?php echo $vouchertransactions_edit->customername->EditValue ?>"<?php echo $vouchertransactions_edit->customername->editAttributes() ?>>
</span>
<?php echo $vouchertransactions_edit->customername->CustomMsg ?></div></div>
	</div>
<?php } ?>
<?php if ($vouchertransactions_edit->phoneno->Visible) { // phoneno ?>
	<div id="r_phoneno" class="form-group row">
		<label id="elh_vouchertransactions_phoneno" for="x_phoneno" class="<?php echo $vouchertransactions_edit->LeftColumnClass ?>"><?php echo $vouchertransactions_edit->phoneno->caption() ?><?php echo $vouchertransactions_edit->phoneno->Required ? $Language->phrase("FieldRequiredIndicator") : "" ?></label>
		<div class="<?php echo $vouchertransactions_edit->RightColumnClass ?>"><div <?php echo $vouchertransactions_edit->phoneno->cellAttributes() ?>>
<span id="el_vouchertransactions_phoneno">
<input type="text" data-table="vouchertransactions" data-field="x_phoneno" name="x_phoneno" id="x_phoneno" size="30" maxlength="15" placeholder="<?php echo HtmlEncode($vouchertransactions_edit->phoneno->getPlaceHolder()) ?>" value="<?php echo $vouchertransactions_edit->phoneno->EditValue ?>"<?php echo $vouchertransactions_edit->phoneno->editAttributes() ?>>
</span>
<?php echo $vouchertransactions_edit->phoneno->CustomMsg ?></div></div>
	</div>
<?php } ?>
<?php if ($vouchertransactions_edit->canceledbyagentid->Visible) { // canceledbyagentid ?>
	<div id="r_canceledbyagentid" class="form-group row">
		<label id="elh_vouchertransactions_canceledbyagentid" class="<?php echo $vouchertransactions_edit->LeftColumnClass ?>"><?php echo $vouchertransactions_edit->canceledbyagentid->caption() ?><?php echo $vouchertransactions_edit->canceledbyagentid->Required ? $Language->phrase("FieldRequiredIndicator") : "" ?></label>
		<div class="<?php echo $vouchertransactions_edit->RightColumnClass ?>"><div <?php echo $vouchertransactions_edit->canceledbyagentid->cellAttributes() ?>>
<span id="el_vouchertransactions_canceledbyagentid">
<?php
$onchange = $vouchertransactions_edit->canceledbyagentid->EditAttrs->prepend("onchange", "");
$onchange = ($onchange) ? ' onchange="' . JsEncode($onchange) . '"' : '';
$vouchertransactions_edit->canceledbyagentid->EditAttrs["onchange"] = "";
?>
<span id="as_x_canceledbyagentid">
	<input type="text" class="form-control" name="sv_x_canceledbyagentid" id="sv_x_canceledbyagentid" value="<?php echo RemoveHtml($vouchertransactions_edit->canceledbyagentid->EditValue) ?>" size="30" maxlength="12" placeholder="<?php echo HtmlEncode($vouchertransactions_edit->canceledbyagentid->getPlaceHolder()) ?>" data-placeholder="<?php echo HtmlEncode($vouchertransactions_edit->canceledbyagentid->getPlaceHolder()) ?>"<?php echo $vouchertransactions_edit->canceledbyagentid->editAttributes() ?>>
</span>
<input type="hidden" data-table="vouchertransactions" data-field="x_canceledbyagentid" data-value-separator="<?php echo $vouchertransactions_edit->canceledbyagentid->displayValueSeparatorAttribute() ?>" name="x_canceledbyagentid" id="x_canceledbyagentid" value="<?php echo HtmlEncode($vouchertransactions_edit->canceledbyagentid->CurrentValue) ?>"<?php echo $onchange ?>>
<script>
loadjs.ready(["fvouchertransactionsedit"], function() {
	fvouchertransactionsedit.createAutoSuggest({"id":"x_canceledbyagentid","forceSelect":false});
});
</script>
<?php echo $vouchertransactions_edit->canceledbyagentid->Lookup->getParamTag($vouchertransactions_edit, "p_x_canceledbyagentid") ?>
</span>
<?php echo $vouchertransactions_edit->canceledbyagentid->CustomMsg ?></div></div>
	</div>
<?php } ?>
<?php if ($vouchertransactions_edit->cancelledbyoperatorid->Visible) { // cancelledbyoperatorid ?>
	<div id="r_cancelledbyoperatorid" class="form-group row">
		<label id="elh_vouchertransactions_cancelledbyoperatorid" class="<?php echo $vouchertransactions_edit->LeftColumnClass ?>"><?php echo $vouchertransactions_edit->cancelledbyoperatorid->caption() ?><?php echo $vouchertransactions_edit->cancelledbyoperatorid->Required ? $Language->phrase("FieldRequiredIndicator") : "" ?></label>
		<div class="<?php echo $vouchertransactions_edit->RightColumnClass ?>"><div <?php echo $vouchertransactions_edit->cancelledbyoperatorid->cellAttributes() ?>>
<span id="el_vouchertransactions_cancelledbyoperatorid">
<?php
$onchange = $vouchertransactions_edit->cancelledbyoperatorid->EditAttrs->prepend("onchange", "");
$onchange = ($onchange) ? ' onchange="' . JsEncode($onchange) . '"' : '';
$vouchertransactions_edit->cancelledbyoperatorid->EditAttrs["onchange"] = "";
?>
<span id="as_x_cancelledbyoperatorid">
	<input type="text" class="form-control" name="sv_x_cancelledbyoperatorid" id="sv_x_cancelledbyoperatorid" value="<?php echo RemoveHtml($vouchertransactions_edit->cancelledbyoperatorid->EditValue) ?>" size="30" maxlength="12" placeholder="<?php echo HtmlEncode($vouchertransactions_edit->cancelledbyoperatorid->getPlaceHolder()) ?>" data-placeholder="<?php echo HtmlEncode($vouchertransactions_edit->cancelledbyoperatorid->getPlaceHolder()) ?>"<?php echo $vouchertransactions_edit->cancelledbyoperatorid->editAttributes() ?>>
</span>
<input type="hidden" data-table="vouchertransactions" data-field="x_cancelledbyoperatorid" data-value-separator="<?php echo $vouchertransactions_edit->cancelledbyoperatorid->displayValueSeparatorAttribute() ?>" name="x_cancelledbyoperatorid" id="x_cancelledbyoperatorid" value="<?php echo HtmlEncode($vouchertransactions_edit->cancelledbyoperatorid->CurrentValue) ?>"<?php echo $onchange ?>>
<script>
loadjs.ready(["fvouchertransactionsedit"], function() {
	fvouchertransactionsedit.createAutoSuggest({"id":"x_cancelledbyoperatorid","forceSelect":false});
});
</script>
<?php echo $vouchertransactions_edit->cancelledbyoperatorid->Lookup->getParamTag($vouchertransactions_edit, "p_x_cancelledbyoperatorid") ?>
</span>
<?php echo $vouchertransactions_edit->cancelledbyoperatorid->CustomMsg ?></div></div>
	</div>
<?php } ?>
<?php if ($vouchertransactions_edit->cancelleddate->Visible) { // cancelleddate ?>
	<div id="r_cancelleddate" class="form-group row">
		<label id="elh_vouchertransactions_cancelleddate" for="x_cancelleddate" class="<?php echo $vouchertransactions_edit->LeftColumnClass ?>"><?php echo $vouchertransactions_edit->cancelleddate->caption() ?><?php echo $vouchertransactions_edit->cancelleddate->Required ? $Language->phrase("FieldRequiredIndicator") : "" ?></label>
		<div class="<?php echo $vouchertransactions_edit->RightColumnClass ?>"><div <?php echo $vouchertransactions_edit->cancelleddate->cellAttributes() ?>>
<span id="el_vouchertransactions_cancelleddate">
<input type="text" data-table="vouchertransactions" data-field="x_cancelleddate" data-format="1" name="x_cancelleddate" id="x_cancelleddate" maxlength="19" placeholder="<?php echo HtmlEncode($vouchertransactions_edit->cancelleddate->getPlaceHolder()) ?>" value="<?php echo $vouchertransactions_edit->cancelleddate->EditValue ?>"<?php echo $vouchertransactions_edit->cancelleddate->editAttributes() ?>>
<?php if (!$vouchertransactions_edit->cancelleddate->ReadOnly && !$vouchertransactions_edit->cancelleddate->Disabled && !isset($vouchertransactions_edit->cancelleddate->EditAttrs["readonly"]) && !isset($vouchertransactions_edit->cancelleddate->EditAttrs["disabled"])) { ?>
<script>
loadjs.ready(["fvouchertransactionsedit", "datetimepicker"], function() {
	ew.createDateTimePicker("fvouchertransactionsedit", "x_cancelleddate", {"ignoreReadonly":true,"useCurrent":false,"format":1});
});
</script>
<?php } ?>
</span>
<?php echo $vouchertransactions_edit->cancelleddate->CustomMsg ?></div></div>
	</div>
<?php } ?>
<?php if ($vouchertransactions_edit->glnovouchercreation->Visible) { // glnovouchercreation ?>
	<div id="r_glnovouchercreation" class="form-group row">
		<label id="elh_vouchertransactions_glnovouchercreation" for="x_glnovouchercreation" class="<?php echo $vouchertransactions_edit->LeftColumnClass ?>"><?php echo $vouchertransactions_edit->glnovouchercreation->caption() ?><?php echo $vouchertransactions_edit->glnovouchercreation->Required ? $Language->phrase("FieldRequiredIndicator") : "" ?></label>
		<div class="<?php echo $vouchertransactions_edit->RightColumnClass ?>"><div <?php echo $vouchertransactions_edit->glnovouchercreation->cellAttributes() ?>>
<span id="el_vouchertransactions_glnovouchercreation">
<input type="text" data-table="vouchertransactions" data-field="x_glnovouchercreation" name="x_glnovouchercreation" id="x_glnovouchercreation" size="30" maxlength="12" placeholder="<?php echo HtmlEncode($vouchertransactions_edit->glnovouchercreation->getPlaceHolder()) ?>" value="<?php echo $vouchertransactions_edit->glnovouchercreation->EditValue ?>"<?php echo $vouchertransactions_edit->glnovouchercreation->editAttributes() ?>>
</span>
<?php echo $vouchertransactions_edit->glnovouchercreation->CustomMsg ?></div></div>
	</div>
<?php } ?>
<?php if ($vouchertransactions_edit->glnovouchercancellation->Visible) { // glnovouchercancellation ?>
	<div id="r_glnovouchercancellation" class="form-group row">
		<label id="elh_vouchertransactions_glnovouchercancellation" for="x_glnovouchercancellation" class="<?php echo $vouchertransactions_edit->LeftColumnClass ?>"><?php echo $vouchertransactions_edit->glnovouchercancellation->caption() ?><?php echo $vouchertransactions_edit->glnovouchercancellation->Required ? $Language->phrase("FieldRequiredIndicator") : "" ?></label>
		<div class="<?php echo $vouchertransactions_edit->RightColumnClass ?>"><div <?php echo $vouchertransactions_edit->glnovouchercancellation->cellAttributes() ?>>
<span id="el_vouchertransactions_glnovouchercancellation">
<input type="text" data-table="vouchertransactions" data-field="x_glnovouchercancellation" name="x_glnovouchercancellation" id="x_glnovouchercancellation" size="30" maxlength="12" placeholder="<?php echo HtmlEncode($vouchertransactions_edit->glnovouchercancellation->getPlaceHolder()) ?>" value="<?php echo $vouchertransactions_edit->glnovouchercancellation->EditValue ?>"<?php echo $vouchertransactions_edit->glnovouchercancellation->editAttributes() ?>>
</span>
<?php echo $vouchertransactions_edit->glnovouchercancellation->CustomMsg ?></div></div>
	</div>
<?php } ?>
<?php if ($vouchertransactions_edit->issuedamount->Visible) { // issuedamount ?>
	<div id="r_issuedamount" class="form-group row">
		<label id="elh_vouchertransactions_issuedamount" for="x_issuedamount" class="<?php echo $vouchertransactions_edit->LeftColumnClass ?>"><?php echo $vouchertransactions_edit->issuedamount->caption() ?><?php echo $vouchertransactions_edit->issuedamount->Required ? $Language->phrase("FieldRequiredIndicator") : "" ?></label>
		<div class="<?php echo $vouchertransactions_edit->RightColumnClass ?>"><div <?php echo $vouchertransactions_edit->issuedamount->cellAttributes() ?>>
<span id="el_vouchertransactions_issuedamount">
<input type="text" data-table="vouchertransactions" data-field="x_issuedamount" name="x_issuedamount" id="x_issuedamount" size="30" maxlength="12" placeholder="<?php echo HtmlEncode($vouchertransactions_edit->issuedamount->getPlaceHolder()) ?>" value="<?php echo $vouchertransactions_edit->issuedamount->EditValue ?>"<?php echo $vouchertransactions_edit->issuedamount->editAttributes() ?>>
</span>
<?php echo $vouchertransactions_edit->issuedamount->CustomMsg ?></div></div>
	</div>
<?php } ?>
<?php if ($vouchertransactions_edit->cancelledamount->Visible) { // cancelledamount ?>
	<div id="r_cancelledamount" class="form-group row">
		<label id="elh_vouchertransactions_cancelledamount" for="x_cancelledamount" class="<?php echo $vouchertransactions_edit->LeftColumnClass ?>"><?php echo $vouchertransactions_edit->cancelledamount->caption() ?><?php echo $vouchertransactions_edit->cancelledamount->Required ? $Language->phrase("FieldRequiredIndicator") : "" ?></label>
		<div class="<?php echo $vouchertransactions_edit->RightColumnClass ?>"><div <?php echo $vouchertransactions_edit->cancelledamount->cellAttributes() ?>>
<span id="el_vouchertransactions_cancelledamount">
<input type="text" data-table="vouchertransactions" data-field="x_cancelledamount" name="x_cancelledamount" id="x_cancelledamount" size="30" maxlength="12" placeholder="<?php echo HtmlEncode($vouchertransactions_edit->cancelledamount->getPlaceHolder()) ?>" value="<?php echo $vouchertransactions_edit->cancelledamount->EditValue ?>"<?php echo $vouchertransactions_edit->cancelledamount->editAttributes() ?>>
</span>
<?php echo $vouchertransactions_edit->cancelledamount->CustomMsg ?></div></div>
	</div>
<?php } ?>
<?php if ($vouchertransactions_edit->currcode->Visible) { // currcode ?>
	<div id="r_currcode" class="form-group row">
		<label id="elh_vouchertransactions_currcode" for="x_currcode" class="<?php echo $vouchertransactions_edit->LeftColumnClass ?>"><?php echo $vouchertransactions_edit->currcode->caption() ?><?php echo $vouchertransactions_edit->currcode->Required ? $Language->phrase("FieldRequiredIndicator") : "" ?></label>
		<div class="<?php echo $vouchertransactions_edit->RightColumnClass ?>"><div <?php echo $vouchertransactions_edit->currcode->cellAttributes() ?>>
<span id="el_vouchertransactions_currcode">
<input type="text" data-table="vouchertransactions" data-field="x_currcode" name="x_currcode" id="x_currcode" size="30" maxlength="3" placeholder="<?php echo HtmlEncode($vouchertransactions_edit->currcode->getPlaceHolder()) ?>" value="<?php echo $vouchertransactions_edit->currcode->EditValue ?>"<?php echo $vouchertransactions_edit->currcode->editAttributes() ?>>
</span>
<?php echo $vouchertransactions_edit->currcode->CustomMsg ?></div></div>
	</div>
<?php } ?>
<?php if ($vouchertransactions_edit->paymentmethod->Visible) { // paymentmethod ?>
	<div id="r_paymentmethod" class="form-group row">
		<label id="elh_vouchertransactions_paymentmethod" for="x_paymentmethod" class="<?php echo $vouchertransactions_edit->LeftColumnClass ?>"><?php echo $vouchertransactions_edit->paymentmethod->caption() ?><?php echo $vouchertransactions_edit->paymentmethod->Required ? $Language->phrase("FieldRequiredIndicator") : "" ?></label>
		<div class="<?php echo $vouchertransactions_edit->RightColumnClass ?>"><div <?php echo $vouchertransactions_edit->paymentmethod->cellAttributes() ?>>
<span id="el_vouchertransactions_paymentmethod">
<div class="input-group">
	<select class="custom-select ew-custom-select" data-table="vouchertransactions" data-field="x_paymentmethod" data-value-separator="<?php echo $vouchertransactions_edit->paymentmethod->displayValueSeparatorAttribute() ?>" id="x_paymentmethod" name="x_paymentmethod"<?php echo $vouchertransactions_edit->paymentmethod->editAttributes() ?>>
			<?php echo $vouchertransactions_edit->paymentmethod->selectOptionListHtml("x_paymentmethod") ?>
		</select>
</div>
</span>
<?php echo $vouchertransactions_edit->paymentmethod->CustomMsg ?></div></div>
	</div>
<?php } ?>
<?php if ($vouchertransactions_edit->paymentdetails->Visible) { // paymentdetails ?>
	<div id="r_paymentdetails" class="form-group row">
		<label id="elh_vouchertransactions_paymentdetails" for="x_paymentdetails" class="<?php echo $vouchertransactions_edit->LeftColumnClass ?>"><?php echo $vouchertransactions_edit->paymentdetails->caption() ?><?php echo $vouchertransactions_edit->paymentdetails->Required ? $Language->phrase("FieldRequiredIndicator") : "" ?></label>
		<div class="<?php echo $vouchertransactions_edit->RightColumnClass ?>"><div <?php echo $vouchertransactions_edit->paymentdetails->cellAttributes() ?>>
<span id="el_vouchertransactions_paymentdetails">
<input type="text" data-table="vouchertransactions" data-field="x_paymentdetails" name="x_paymentdetails" id="x_paymentdetails" size="30" maxlength="15" placeholder="<?php echo HtmlEncode($vouchertransactions_edit->paymentdetails->getPlaceHolder()) ?>" value="<?php echo $vouchertransactions_edit->paymentdetails->EditValue ?>"<?php echo $vouchertransactions_edit->paymentdetails->editAttributes() ?>>
</span>
<?php echo $vouchertransactions_edit->paymentdetails->CustomMsg ?></div></div>
	</div>
<?php } ?>
</div><!-- /page* -->
<?php if (!$vouchertransactions_edit->IsModal) { ?>
<div class="form-group row"><!-- buttons .form-group -->
	<div class="<?php echo $vouchertransactions_edit->OffsetColumnClass ?>"><!-- buttons offset -->
<button class="btn btn-primary ew-btn" name="btn-action" id="btn-action" type="submit"><?php echo $Language->phrase("SaveBtn") ?></button>
<button class="btn btn-default ew-btn" name="btn-cancel" id="btn-cancel" type="button" data-href="<?php echo $vouchertransactions_edit->getReturnUrl() ?>"><?php echo $Language->phrase("CancelBtn") ?></button>
	</div><!-- /buttons offset -->
</div><!-- /buttons .form-group -->
<?php } ?>
</form>
<?php
$vouchertransactions_edit->showPageFooter();
if (Config("DEBUG"))
	echo GetDebugMessage();
?>
<script>
loadjs.ready("load", function() {

	// Startup script
	// Write your table-specific startup script here
	// console.log("page loaded");

});
</script>
<?php include_once "footer.php"; ?>
<?php
$vouchertransactions_edit->terminate();
?>