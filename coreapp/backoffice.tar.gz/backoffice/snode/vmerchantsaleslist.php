<?php
namespace PHPMaker2020\_4payadmin;

// Autoload
include_once "autoload.php";

// Session
if (session_status() !== PHP_SESSION_ACTIVE)
	\Delight\Cookie\Session::start(Config("COOKIE_SAMESITE")); // Init session data

// Output buffering
ob_start();
?>
<?php

// Write header
WriteHeader(FALSE);

// Create page object
$vmerchantsales_list = new vmerchantsales_list();

// Run the page
$vmerchantsales_list->run();

// Setup login status
SetupLoginStatus();
SetClientVar("login", LoginStatus());

// Global Page Rendering event (in userfn*.php)
Page_Rendering();

// Page Rendering event
$vmerchantsales_list->Page_Render();
?>
<?php include_once "header.php"; ?>
<?php if (!$vmerchantsales_list->isExport()) { ?>
<script>
var fvmerchantsaleslist, currentPageID;
loadjs.ready("head", function() {

	// Form object
	currentPageID = ew.PAGE_ID = "list";
	fvmerchantsaleslist = currentForm = new ew.Form("fvmerchantsaleslist", "list");
	fvmerchantsaleslist.formKeyCountName = '<?php echo $vmerchantsales_list->FormKeyCountName ?>';
	loadjs.done("fvmerchantsaleslist");
});
var fvmerchantsaleslistsrch;
loadjs.ready("head", function() {

	// Form object for search
	fvmerchantsaleslistsrch = currentSearchForm = new ew.Form("fvmerchantsaleslistsrch");

	// Validate function for search
	fvmerchantsaleslistsrch.validate = function(fobj) {
		if (!this.validateRequired)
			return true; // Ignore validation
		fobj = fobj || this._form;
		var infix = "";
		elm = this.getElements("x" + infix + "_transferTime");
		if (elm && !ew.checkDateDef(elm.value))
			return this.onError(elm, "<?php echo JsEncode($vmerchantsales_list->transferTime->errorMessage()) ?>");
		elm = this.getElements("x" + infix + "_TotalAmountForCustomer");
		if (elm && !ew.checkNumber(elm.value))
			return this.onError(elm, "<?php echo JsEncode($vmerchantsales_list->TotalAmountForCustomer->errorMessage()) ?>");
		elm = this.getElements("x" + infix + "_serviceFeeToMerchant");
		if (elm && !ew.checkNumber(elm.value))
			return this.onError(elm, "<?php echo JsEncode($vmerchantsales_list->serviceFeeToMerchant->errorMessage()) ?>");
		elm = this.getElements("x" + infix + "_TotalAmountForMerchant");
		if (elm && !ew.checkNumber(elm.value))
			return this.onError(elm, "<?php echo JsEncode($vmerchantsales_list->TotalAmountForMerchant->errorMessage()) ?>");

		// Call Form_CustomValidate event
		if (!this.Form_CustomValidate(fobj))
			return false;
		return true;
	}

	// Form_CustomValidate
	fvmerchantsaleslistsrch.Form_CustomValidate = function(fobj) { // DO NOT CHANGE THIS LINE!

		// Your custom validation code here, return false if invalid.
		return true;
	}

	// Use JavaScript validation or not
	fvmerchantsaleslistsrch.validateRequired = <?php echo Config("CLIENT_VALIDATE") ? "true" : "false" ?>;

	// Dynamic selection lists
	fvmerchantsaleslistsrch.lists["x_merchantID"] = <?php echo $vmerchantsales_list->merchantID->Lookup->toClientList($vmerchantsales_list) ?>;
	fvmerchantsaleslistsrch.lists["x_merchantID"].options = <?php echo JsonEncode($vmerchantsales_list->merchantID->lookupOptions()) ?>;
	fvmerchantsaleslistsrch.lists["x_status"] = <?php echo $vmerchantsales_list->status->Lookup->toClientList($vmerchantsales_list) ?>;
	fvmerchantsaleslistsrch.lists["x_status"].options = <?php echo JsonEncode($vmerchantsales_list->status->options(FALSE, TRUE)) ?>;
	fvmerchantsaleslistsrch.lists["x_userpiid"] = <?php echo $vmerchantsales_list->userpiid->Lookup->toClientList($vmerchantsales_list) ?>;
	fvmerchantsaleslistsrch.lists["x_userpiid"].options = <?php echo JsonEncode($vmerchantsales_list->userpiid->lookupOptions()) ?>;

	// Filters
	fvmerchantsaleslistsrch.filterList = <?php echo $vmerchantsales_list->getFilterList() ?>;

	// Init search panel as collapsed
	fvmerchantsaleslistsrch.initSearchPanel = true;
	loadjs.done("fvmerchantsaleslistsrch");
});
</script>
<style type="text/css">
.ew-table-preview-row { /* main table preview row color */
	background-color: #FFFFFF; /* preview row color */
}
.ew-table-preview-row .ew-grid {
	display: table;
}
</style>
<div id="ew-preview" class="d-none"><!-- preview -->
	<div class="ew-nav-tabs"><!-- .ew-nav-tabs -->
		<ul class="nav nav-tabs"></ul>
		<div class="tab-content"><!-- .tab-content -->
			<div class="tab-pane fade active show"></div>
		</div><!-- /.tab-content -->
	</div><!-- /.ew-nav-tabs -->
</div><!-- /preview -->
<script>
loadjs.ready("head", function() {
	ew.PREVIEW_PLACEMENT = ew.CSS_FLIP ? "right" : "left";
	ew.PREVIEW_SINGLE_ROW = false;
	ew.PREVIEW_OVERLAY = false;
	loadjs("js/ewpreview.js", "preview");
});
</script>
<script>
loadjs.ready("head", function() {

	// Client script
	// Write your client script here, no need to add script tags.

});
</script>
<?php } ?>
<?php if (!$vmerchantsales_list->isExport()) { ?>
<div class="btn-toolbar ew-toolbar">
<?php if ($vmerchantsales_list->TotalRecords > 0 && $vmerchantsales_list->ExportOptions->visible()) { ?>
<?php $vmerchantsales_list->ExportOptions->render("body") ?>
<?php } ?>
<?php if ($vmerchantsales_list->ImportOptions->visible()) { ?>
<?php $vmerchantsales_list->ImportOptions->render("body") ?>
<?php } ?>
<?php if ($vmerchantsales_list->SearchOptions->visible()) { ?>
<?php $vmerchantsales_list->SearchOptions->render("body") ?>
<?php } ?>
<?php if ($vmerchantsales_list->FilterOptions->visible()) { ?>
<?php $vmerchantsales_list->FilterOptions->render("body") ?>
<?php } ?>
<div class="clearfix"></div>
</div>
<?php } ?>
<?php
$vmerchantsales_list->renderOtherOptions();
?>
<?php if ($Security->CanSearch()) { ?>
<?php if (!$vmerchantsales_list->isExport() && !$vmerchantsales->CurrentAction) { ?>
<form name="fvmerchantsaleslistsrch" id="fvmerchantsaleslistsrch" class="form-inline ew-form ew-ext-search-form" action="<?php echo CurrentPageName() ?>">
<div id="fvmerchantsaleslistsrch-search-panel" class="<?php echo $vmerchantsales_list->SearchPanelClass ?>">
<input type="hidden" name="cmd" value="search">
<input type="hidden" name="t" value="vmerchantsales">
	<div class="ew-extended-search">
<?php

// Render search row
$vmerchantsales->RowType = ROWTYPE_SEARCH;
$vmerchantsales->resetAttributes();
$vmerchantsales_list->renderRow();
?>
<?php if ($vmerchantsales_list->txid->Visible) { // txid ?>
	<?php
		$vmerchantsales_list->SearchColumnCount++;
		if (($vmerchantsales_list->SearchColumnCount - 1) % $vmerchantsales_list->SearchFieldsPerRow == 0) {
			$vmerchantsales_list->SearchRowCount++;
	?>
<div id="xsr_<?php echo $vmerchantsales_list->SearchRowCount ?>" class="ew-row d-sm-flex">
	<?php
		}
	 ?>
	<div id="xsc_txid" class="ew-cell form-group">
		<label for="x_txid" class="ew-search-caption ew-label"><?php echo $vmerchantsales_list->txid->caption() ?></label>
		<span class="ew-search-operator">
<?php echo $Language->phrase("LIKE") ?>
<input type="hidden" name="z_txid" id="z_txid" value="LIKE">
</span>
		<span id="el_vmerchantsales_txid" class="ew-search-field">
<input type="text" data-table="vmerchantsales" data-field="x_txid" name="x_txid" id="x_txid" size="30" maxlength="10" placeholder="<?php echo HtmlEncode($vmerchantsales_list->txid->getPlaceHolder()) ?>" value="<?php echo $vmerchantsales_list->txid->EditValue ?>"<?php echo $vmerchantsales_list->txid->editAttributes() ?>>
</span>
	</div>
	<?php if ($vmerchantsales_list->SearchColumnCount % $vmerchantsales_list->SearchFieldsPerRow == 0) { ?>
</div>
	<?php } ?>
<?php } ?>
<?php if ($vmerchantsales_list->merchantID->Visible) { // merchantID ?>
	<?php
		$vmerchantsales_list->SearchColumnCount++;
		if (($vmerchantsales_list->SearchColumnCount - 1) % $vmerchantsales_list->SearchFieldsPerRow == 0) {
			$vmerchantsales_list->SearchRowCount++;
	?>
<div id="xsr_<?php echo $vmerchantsales_list->SearchRowCount ?>" class="ew-row d-sm-flex">
	<?php
		}
	 ?>
	<div id="xsc_merchantID" class="ew-cell form-group">
		<label for="x_merchantID" class="ew-search-caption ew-label"><?php echo $vmerchantsales_list->merchantID->caption() ?></label>
		<span class="ew-search-operator">
<?php echo $Language->phrase("=") ?>
<input type="hidden" name="z_merchantID" id="z_merchantID" value="=">
</span>
		<span id="el_vmerchantsales_merchantID" class="ew-search-field">
<div class="input-group">
	<select class="custom-select ew-custom-select" data-table="vmerchantsales" data-field="x_merchantID" data-value-separator="<?php echo $vmerchantsales_list->merchantID->displayValueSeparatorAttribute() ?>" id="x_merchantID" name="x_merchantID"<?php echo $vmerchantsales_list->merchantID->editAttributes() ?>>
			<?php echo $vmerchantsales_list->merchantID->selectOptionListHtml("x_merchantID") ?>
		</select>
</div>
<?php echo $vmerchantsales_list->merchantID->Lookup->getParamTag($vmerchantsales_list, "p_x_merchantID") ?>
</span>
	</div>
	<?php if ($vmerchantsales_list->SearchColumnCount % $vmerchantsales_list->SearchFieldsPerRow == 0) { ?>
</div>
	<?php } ?>
<?php } ?>
<?php if ($vmerchantsales_list->transferTime->Visible) { // transferTime ?>
	<?php
		$vmerchantsales_list->SearchColumnCount++;
		if (($vmerchantsales_list->SearchColumnCount - 1) % $vmerchantsales_list->SearchFieldsPerRow == 0) {
			$vmerchantsales_list->SearchRowCount++;
	?>
<div id="xsr_<?php echo $vmerchantsales_list->SearchRowCount ?>" class="ew-row d-sm-flex">
	<?php
		}
	 ?>
	<div id="xsc_transferTime" class="ew-cell form-group">
		<label for="x_transferTime" class="ew-search-caption ew-label"><?php echo $vmerchantsales_list->transferTime->caption() ?></label>
		<span class="ew-search-operator">
<?php echo $Language->phrase("BETWEEN") ?>
<input type="hidden" name="z_transferTime" id="z_transferTime" value="BETWEEN">
</span>
		<span id="el_vmerchantsales_transferTime" class="ew-search-field">
<input type="text" data-table="vmerchantsales" data-field="x_transferTime" name="x_transferTime" id="x_transferTime" placeholder="<?php echo HtmlEncode($vmerchantsales_list->transferTime->getPlaceHolder()) ?>" value="<?php echo $vmerchantsales_list->transferTime->EditValue ?>"<?php echo $vmerchantsales_list->transferTime->editAttributes() ?>>
<?php if (!$vmerchantsales_list->transferTime->ReadOnly && !$vmerchantsales_list->transferTime->Disabled && !isset($vmerchantsales_list->transferTime->EditAttrs["readonly"]) && !isset($vmerchantsales_list->transferTime->EditAttrs["disabled"])) { ?>
<script>
loadjs.ready(["fvmerchantsaleslistsrch", "datetimepicker"], function() {
	ew.createDateTimePicker("fvmerchantsaleslistsrch", "x_transferTime", {"ignoreReadonly":true,"useCurrent":false,"format":0});
});
</script>
<?php } ?>
</span>
		<span class="ew-search-and"><label><?php echo $Language->phrase("AND") ?></label></span>
		<span id="el2_vmerchantsales_transferTime" class="ew-search-field2">
<input type="text" data-table="vmerchantsales" data-field="x_transferTime" name="y_transferTime" id="y_transferTime" placeholder="<?php echo HtmlEncode($vmerchantsales_list->transferTime->getPlaceHolder()) ?>" value="<?php echo $vmerchantsales_list->transferTime->EditValue2 ?>"<?php echo $vmerchantsales_list->transferTime->editAttributes() ?>>
<?php if (!$vmerchantsales_list->transferTime->ReadOnly && !$vmerchantsales_list->transferTime->Disabled && !isset($vmerchantsales_list->transferTime->EditAttrs["readonly"]) && !isset($vmerchantsales_list->transferTime->EditAttrs["disabled"])) { ?>
<script>
loadjs.ready(["fvmerchantsaleslistsrch", "datetimepicker"], function() {
	ew.createDateTimePicker("fvmerchantsaleslistsrch", "y_transferTime", {"ignoreReadonly":true,"useCurrent":false,"format":0});
});
</script>
<?php } ?>
</span>
	</div>
	<?php if ($vmerchantsales_list->SearchColumnCount % $vmerchantsales_list->SearchFieldsPerRow == 0) { ?>
</div>
	<?php } ?>
<?php } ?>
<?php if ($vmerchantsales_list->status->Visible) { // status ?>
	<?php
		$vmerchantsales_list->SearchColumnCount++;
		if (($vmerchantsales_list->SearchColumnCount - 1) % $vmerchantsales_list->SearchFieldsPerRow == 0) {
			$vmerchantsales_list->SearchRowCount++;
	?>
<div id="xsr_<?php echo $vmerchantsales_list->SearchRowCount ?>" class="ew-row d-sm-flex">
	<?php
		}
	 ?>
	<div id="xsc_status" class="ew-cell form-group">
		<label for="x_status" class="ew-search-caption ew-label"><?php echo $vmerchantsales_list->status->caption() ?></label>
		<span class="ew-search-operator">
<?php echo $Language->phrase("=") ?>
<input type="hidden" name="z_status" id="z_status" value="=">
</span>
		<span id="el_vmerchantsales_status" class="ew-search-field">
<div class="input-group">
	<select class="custom-select ew-custom-select" data-table="vmerchantsales" data-field="x_status" data-value-separator="<?php echo $vmerchantsales_list->status->displayValueSeparatorAttribute() ?>" id="x_status" name="x_status"<?php echo $vmerchantsales_list->status->editAttributes() ?>>
			<?php echo $vmerchantsales_list->status->selectOptionListHtml("x_status") ?>
		</select>
</div>
</span>
	</div>
	<?php if ($vmerchantsales_list->SearchColumnCount % $vmerchantsales_list->SearchFieldsPerRow == 0) { ?>
</div>
	<?php } ?>
<?php } ?>
<?php if ($vmerchantsales_list->currID->Visible) { // currID ?>
	<?php
		$vmerchantsales_list->SearchColumnCount++;
		if (($vmerchantsales_list->SearchColumnCount - 1) % $vmerchantsales_list->SearchFieldsPerRow == 0) {
			$vmerchantsales_list->SearchRowCount++;
	?>
<div id="xsr_<?php echo $vmerchantsales_list->SearchRowCount ?>" class="ew-row d-sm-flex">
	<?php
		}
	 ?>
	<div id="xsc_currID" class="ew-cell form-group">
		<label for="x_currID" class="ew-search-caption ew-label"><?php echo $vmerchantsales_list->currID->caption() ?></label>
		<span class="ew-search-operator">
<?php echo $Language->phrase("=") ?>
<input type="hidden" name="z_currID" id="z_currID" value="=">
</span>
		<span id="el_vmerchantsales_currID" class="ew-search-field">
<input type="text" data-table="vmerchantsales" data-field="x_currID" name="x_currID" id="x_currID" size="30" maxlength="3" placeholder="<?php echo HtmlEncode($vmerchantsales_list->currID->getPlaceHolder()) ?>" value="<?php echo $vmerchantsales_list->currID->EditValue ?>"<?php echo $vmerchantsales_list->currID->editAttributes() ?>>
</span>
	</div>
	<?php if ($vmerchantsales_list->SearchColumnCount % $vmerchantsales_list->SearchFieldsPerRow == 0) { ?>
</div>
	<?php } ?>
<?php } ?>
<?php if ($vmerchantsales_list->TotalAmountForCustomer->Visible) { // TotalAmountForCustomer ?>
	<?php
		$vmerchantsales_list->SearchColumnCount++;
		if (($vmerchantsales_list->SearchColumnCount - 1) % $vmerchantsales_list->SearchFieldsPerRow == 0) {
			$vmerchantsales_list->SearchRowCount++;
	?>
<div id="xsr_<?php echo $vmerchantsales_list->SearchRowCount ?>" class="ew-row d-sm-flex">
	<?php
		}
	 ?>
	<div id="xsc_TotalAmountForCustomer" class="ew-cell form-group">
		<label for="x_TotalAmountForCustomer" class="ew-search-caption ew-label"><?php echo $vmerchantsales_list->TotalAmountForCustomer->caption() ?></label>
		<span class="ew-search-operator">
<select name="z_TotalAmountForCustomer" id="z_TotalAmountForCustomer" class="custom-select" onchange="ew.searchOperatorChanged(this);">
<option value="="<?php echo $vmerchantsales_list->TotalAmountForCustomer->AdvancedSearch->SearchOperator == "=" ? " selected" : "" ?>><?php echo $Language->phrase("EQUAL") ?></option>
<option value="<>"<?php echo $vmerchantsales_list->TotalAmountForCustomer->AdvancedSearch->SearchOperator == "<>" ? " selected" : "" ?>><?php echo $Language->phrase("<>") ?></option>
<option value="<"<?php echo $vmerchantsales_list->TotalAmountForCustomer->AdvancedSearch->SearchOperator == "<" ? " selected" : "" ?>><?php echo $Language->phrase("<") ?></option>
<option value="<="<?php echo $vmerchantsales_list->TotalAmountForCustomer->AdvancedSearch->SearchOperator == "<=" ? " selected" : "" ?>><?php echo $Language->phrase("<=") ?></option>
<option value=">"<?php echo $vmerchantsales_list->TotalAmountForCustomer->AdvancedSearch->SearchOperator == ">" ? " selected" : "" ?>><?php echo $Language->phrase(">") ?></option>
<option value=">="<?php echo $vmerchantsales_list->TotalAmountForCustomer->AdvancedSearch->SearchOperator == ">=" ? " selected" : "" ?>><?php echo $Language->phrase(">=") ?></option>
<option value="BETWEEN"<?php echo $vmerchantsales_list->TotalAmountForCustomer->AdvancedSearch->SearchOperator == "BETWEEN" ? " selected" : "" ?>><?php echo $Language->phrase("BETWEEN") ?></option>
</select>
</span>
		<span id="el_vmerchantsales_TotalAmountForCustomer" class="ew-search-field">
<input type="text" data-table="vmerchantsales" data-field="x_TotalAmountForCustomer" name="x_TotalAmountForCustomer" id="x_TotalAmountForCustomer" size="30" placeholder="<?php echo HtmlEncode($vmerchantsales_list->TotalAmountForCustomer->getPlaceHolder()) ?>" value="<?php echo $vmerchantsales_list->TotalAmountForCustomer->EditValue ?>"<?php echo $vmerchantsales_list->TotalAmountForCustomer->editAttributes() ?>>
</span>
		<span class="ew-search-and d-none"><label><?php echo $Language->phrase("AND") ?></label></span>
		<span id="el2_vmerchantsales_TotalAmountForCustomer" class="ew-search-field2 d-none">
<input type="text" data-table="vmerchantsales" data-field="x_TotalAmountForCustomer" name="y_TotalAmountForCustomer" id="y_TotalAmountForCustomer" size="30" placeholder="<?php echo HtmlEncode($vmerchantsales_list->TotalAmountForCustomer->getPlaceHolder()) ?>" value="<?php echo $vmerchantsales_list->TotalAmountForCustomer->EditValue2 ?>"<?php echo $vmerchantsales_list->TotalAmountForCustomer->editAttributes() ?>>
</span>
	</div>
	<?php if ($vmerchantsales_list->SearchColumnCount % $vmerchantsales_list->SearchFieldsPerRow == 0) { ?>
</div>
	<?php } ?>
<?php } ?>
<?php if ($vmerchantsales_list->serviceFeeToMerchant->Visible) { // serviceFeeToMerchant ?>
	<?php
		$vmerchantsales_list->SearchColumnCount++;
		if (($vmerchantsales_list->SearchColumnCount - 1) % $vmerchantsales_list->SearchFieldsPerRow == 0) {
			$vmerchantsales_list->SearchRowCount++;
	?>
<div id="xsr_<?php echo $vmerchantsales_list->SearchRowCount ?>" class="ew-row d-sm-flex">
	<?php
		}
	 ?>
	<div id="xsc_serviceFeeToMerchant" class="ew-cell form-group">
		<label for="x_serviceFeeToMerchant" class="ew-search-caption ew-label"><?php echo $vmerchantsales_list->serviceFeeToMerchant->caption() ?></label>
		<span class="ew-search-operator">
<select name="z_serviceFeeToMerchant" id="z_serviceFeeToMerchant" class="custom-select" onchange="ew.searchOperatorChanged(this);">
<option value="="<?php echo $vmerchantsales_list->serviceFeeToMerchant->AdvancedSearch->SearchOperator == "=" ? " selected" : "" ?>><?php echo $Language->phrase("EQUAL") ?></option>
<option value="<>"<?php echo $vmerchantsales_list->serviceFeeToMerchant->AdvancedSearch->SearchOperator == "<>" ? " selected" : "" ?>><?php echo $Language->phrase("<>") ?></option>
<option value="<"<?php echo $vmerchantsales_list->serviceFeeToMerchant->AdvancedSearch->SearchOperator == "<" ? " selected" : "" ?>><?php echo $Language->phrase("<") ?></option>
<option value="<="<?php echo $vmerchantsales_list->serviceFeeToMerchant->AdvancedSearch->SearchOperator == "<=" ? " selected" : "" ?>><?php echo $Language->phrase("<=") ?></option>
<option value=">"<?php echo $vmerchantsales_list->serviceFeeToMerchant->AdvancedSearch->SearchOperator == ">" ? " selected" : "" ?>><?php echo $Language->phrase(">") ?></option>
<option value=">="<?php echo $vmerchantsales_list->serviceFeeToMerchant->AdvancedSearch->SearchOperator == ">=" ? " selected" : "" ?>><?php echo $Language->phrase(">=") ?></option>
<option value="BETWEEN"<?php echo $vmerchantsales_list->serviceFeeToMerchant->AdvancedSearch->SearchOperator == "BETWEEN" ? " selected" : "" ?>><?php echo $Language->phrase("BETWEEN") ?></option>
</select>
</span>
		<span id="el_vmerchantsales_serviceFeeToMerchant" class="ew-search-field">
<input type="text" data-table="vmerchantsales" data-field="x_serviceFeeToMerchant" name="x_serviceFeeToMerchant" id="x_serviceFeeToMerchant" size="30" placeholder="<?php echo HtmlEncode($vmerchantsales_list->serviceFeeToMerchant->getPlaceHolder()) ?>" value="<?php echo $vmerchantsales_list->serviceFeeToMerchant->EditValue ?>"<?php echo $vmerchantsales_list->serviceFeeToMerchant->editAttributes() ?>>
</span>
		<span class="ew-search-and d-none"><label><?php echo $Language->phrase("AND") ?></label></span>
		<span id="el2_vmerchantsales_serviceFeeToMerchant" class="ew-search-field2 d-none">
<input type="text" data-table="vmerchantsales" data-field="x_serviceFeeToMerchant" name="y_serviceFeeToMerchant" id="y_serviceFeeToMerchant" size="30" placeholder="<?php echo HtmlEncode($vmerchantsales_list->serviceFeeToMerchant->getPlaceHolder()) ?>" value="<?php echo $vmerchantsales_list->serviceFeeToMerchant->EditValue2 ?>"<?php echo $vmerchantsales_list->serviceFeeToMerchant->editAttributes() ?>>
</span>
	</div>
	<?php if ($vmerchantsales_list->SearchColumnCount % $vmerchantsales_list->SearchFieldsPerRow == 0) { ?>
</div>
	<?php } ?>
<?php } ?>
<?php if ($vmerchantsales_list->TotalAmountForMerchant->Visible) { // TotalAmountForMerchant ?>
	<?php
		$vmerchantsales_list->SearchColumnCount++;
		if (($vmerchantsales_list->SearchColumnCount - 1) % $vmerchantsales_list->SearchFieldsPerRow == 0) {
			$vmerchantsales_list->SearchRowCount++;
	?>
<div id="xsr_<?php echo $vmerchantsales_list->SearchRowCount ?>" class="ew-row d-sm-flex">
	<?php
		}
	 ?>
	<div id="xsc_TotalAmountForMerchant" class="ew-cell form-group">
		<label for="x_TotalAmountForMerchant" class="ew-search-caption ew-label"><?php echo $vmerchantsales_list->TotalAmountForMerchant->caption() ?></label>
		<span class="ew-search-operator">
<select name="z_TotalAmountForMerchant" id="z_TotalAmountForMerchant" class="custom-select" onchange="ew.searchOperatorChanged(this);">
<option value="="<?php echo $vmerchantsales_list->TotalAmountForMerchant->AdvancedSearch->SearchOperator == "=" ? " selected" : "" ?>><?php echo $Language->phrase("EQUAL") ?></option>
<option value="<>"<?php echo $vmerchantsales_list->TotalAmountForMerchant->AdvancedSearch->SearchOperator == "<>" ? " selected" : "" ?>><?php echo $Language->phrase("<>") ?></option>
<option value="<"<?php echo $vmerchantsales_list->TotalAmountForMerchant->AdvancedSearch->SearchOperator == "<" ? " selected" : "" ?>><?php echo $Language->phrase("<") ?></option>
<option value="<="<?php echo $vmerchantsales_list->TotalAmountForMerchant->AdvancedSearch->SearchOperator == "<=" ? " selected" : "" ?>><?php echo $Language->phrase("<=") ?></option>
<option value=">"<?php echo $vmerchantsales_list->TotalAmountForMerchant->AdvancedSearch->SearchOperator == ">" ? " selected" : "" ?>><?php echo $Language->phrase(">") ?></option>
<option value=">="<?php echo $vmerchantsales_list->TotalAmountForMerchant->AdvancedSearch->SearchOperator == ">=" ? " selected" : "" ?>><?php echo $Language->phrase(">=") ?></option>
<option value="BETWEEN"<?php echo $vmerchantsales_list->TotalAmountForMerchant->AdvancedSearch->SearchOperator == "BETWEEN" ? " selected" : "" ?>><?php echo $Language->phrase("BETWEEN") ?></option>
</select>
</span>
		<span id="el_vmerchantsales_TotalAmountForMerchant" class="ew-search-field">
<input type="text" data-table="vmerchantsales" data-field="x_TotalAmountForMerchant" name="x_TotalAmountForMerchant" id="x_TotalAmountForMerchant" size="30" maxlength="21" placeholder="<?php echo HtmlEncode($vmerchantsales_list->TotalAmountForMerchant->getPlaceHolder()) ?>" value="<?php echo $vmerchantsales_list->TotalAmountForMerchant->EditValue ?>"<?php echo $vmerchantsales_list->TotalAmountForMerchant->editAttributes() ?>>
</span>
		<span class="ew-search-and d-none"><label><?php echo $Language->phrase("AND") ?></label></span>
		<span id="el2_vmerchantsales_TotalAmountForMerchant" class="ew-search-field2 d-none">
<input type="text" data-table="vmerchantsales" data-field="x_TotalAmountForMerchant" name="y_TotalAmountForMerchant" id="y_TotalAmountForMerchant" size="30" maxlength="21" placeholder="<?php echo HtmlEncode($vmerchantsales_list->TotalAmountForMerchant->getPlaceHolder()) ?>" value="<?php echo $vmerchantsales_list->TotalAmountForMerchant->EditValue2 ?>"<?php echo $vmerchantsales_list->TotalAmountForMerchant->editAttributes() ?>>
</span>
	</div>
	<?php if ($vmerchantsales_list->SearchColumnCount % $vmerchantsales_list->SearchFieldsPerRow == 0) { ?>
</div>
	<?php } ?>
<?php } ?>
<?php if ($vmerchantsales_list->userpiid->Visible) { // userpiid ?>
	<?php
		$vmerchantsales_list->SearchColumnCount++;
		if (($vmerchantsales_list->SearchColumnCount - 1) % $vmerchantsales_list->SearchFieldsPerRow == 0) {
			$vmerchantsales_list->SearchRowCount++;
	?>
<div id="xsr_<?php echo $vmerchantsales_list->SearchRowCount ?>" class="ew-row d-sm-flex">
	<?php
		}
	 ?>
	<div id="xsc_userpiid" class="ew-cell form-group">
		<label for="x_userpiid" class="ew-search-caption ew-label"><?php echo $vmerchantsales_list->userpiid->caption() ?></label>
		<span class="ew-search-operator">
<?php echo $Language->phrase("=") ?>
<input type="hidden" name="z_userpiid" id="z_userpiid" value="=">
</span>
		<span id="el_vmerchantsales_userpiid" class="ew-search-field">
<div class="input-group">
	<select class="custom-select ew-custom-select" data-table="vmerchantsales" data-field="x_userpiid" data-value-separator="<?php echo $vmerchantsales_list->userpiid->displayValueSeparatorAttribute() ?>" id="x_userpiid" name="x_userpiid"<?php echo $vmerchantsales_list->userpiid->editAttributes() ?>>
			<?php echo $vmerchantsales_list->userpiid->selectOptionListHtml("x_userpiid") ?>
		</select>
</div>
<?php echo $vmerchantsales_list->userpiid->Lookup->getParamTag($vmerchantsales_list, "p_x_userpiid") ?>
</span>
	</div>
	<?php if ($vmerchantsales_list->SearchColumnCount % $vmerchantsales_list->SearchFieldsPerRow == 0) { ?>
</div>
	<?php } ?>
<?php } ?>
<?php if ($vmerchantsales_list->shoppingCartID->Visible) { // shoppingCartID ?>
	<?php
		$vmerchantsales_list->SearchColumnCount++;
		if (($vmerchantsales_list->SearchColumnCount - 1) % $vmerchantsales_list->SearchFieldsPerRow == 0) {
			$vmerchantsales_list->SearchRowCount++;
	?>
<div id="xsr_<?php echo $vmerchantsales_list->SearchRowCount ?>" class="ew-row d-sm-flex">
	<?php
		}
	 ?>
	<div id="xsc_shoppingCartID" class="ew-cell form-group">
		<label for="x_shoppingCartID" class="ew-search-caption ew-label"><?php echo $vmerchantsales_list->shoppingCartID->caption() ?></label>
		<span class="ew-search-operator">
<?php echo $Language->phrase("LIKE") ?>
<input type="hidden" name="z_shoppingCartID" id="z_shoppingCartID" value="LIKE">
</span>
		<span id="el_vmerchantsales_shoppingCartID" class="ew-search-field">
<input type="text" data-table="vmerchantsales" data-field="x_shoppingCartID" name="x_shoppingCartID" id="x_shoppingCartID" size="30" maxlength="20" placeholder="<?php echo HtmlEncode($vmerchantsales_list->shoppingCartID->getPlaceHolder()) ?>" value="<?php echo $vmerchantsales_list->shoppingCartID->EditValue ?>"<?php echo $vmerchantsales_list->shoppingCartID->editAttributes() ?>>
</span>
	</div>
	<?php if ($vmerchantsales_list->SearchColumnCount % $vmerchantsales_list->SearchFieldsPerRow == 0) { ?>
</div>
	<?php } ?>
<?php } ?>
<?php if ($vmerchantsales_list->merchantRefID->Visible) { // merchantRefID ?>
	<?php
		$vmerchantsales_list->SearchColumnCount++;
		if (($vmerchantsales_list->SearchColumnCount - 1) % $vmerchantsales_list->SearchFieldsPerRow == 0) {
			$vmerchantsales_list->SearchRowCount++;
	?>
<div id="xsr_<?php echo $vmerchantsales_list->SearchRowCount ?>" class="ew-row d-sm-flex">
	<?php
		}
	 ?>
	<div id="xsc_merchantRefID" class="ew-cell form-group">
		<label for="x_merchantRefID" class="ew-search-caption ew-label"><?php echo $vmerchantsales_list->merchantRefID->caption() ?></label>
		<span class="ew-search-operator">
<?php echo $Language->phrase("LIKE") ?>
<input type="hidden" name="z_merchantRefID" id="z_merchantRefID" value="LIKE">
</span>
		<span id="el_vmerchantsales_merchantRefID" class="ew-search-field">
<input type="text" data-table="vmerchantsales" data-field="x_merchantRefID" name="x_merchantRefID" id="x_merchantRefID" size="30" maxlength="20" placeholder="<?php echo HtmlEncode($vmerchantsales_list->merchantRefID->getPlaceHolder()) ?>" value="<?php echo $vmerchantsales_list->merchantRefID->EditValue ?>"<?php echo $vmerchantsales_list->merchantRefID->editAttributes() ?>>
</span>
	</div>
	<?php if ($vmerchantsales_list->SearchColumnCount % $vmerchantsales_list->SearchFieldsPerRow == 0) { ?>
</div>
	<?php } ?>
<?php } ?>
	<?php if ($vmerchantsales_list->SearchColumnCount % $vmerchantsales_list->SearchFieldsPerRow > 0) { ?>
</div>
	<?php } ?>
<div id="xsr_<?php echo $vmerchantsales_list->SearchRowCount + 1 ?>" class="ew-row d-sm-flex">
	<div class="ew-quick-search input-group">
		<input type="text" name="<?php echo Config("TABLE_BASIC_SEARCH") ?>" id="<?php echo Config("TABLE_BASIC_SEARCH") ?>" class="form-control" value="<?php echo HtmlEncode($vmerchantsales_list->BasicSearch->getKeyword()) ?>" placeholder="<?php echo HtmlEncode($Language->phrase("Search")) ?>">
		<input type="hidden" name="<?php echo Config("TABLE_BASIC_SEARCH_TYPE") ?>" id="<?php echo Config("TABLE_BASIC_SEARCH_TYPE") ?>" value="<?php echo HtmlEncode($vmerchantsales_list->BasicSearch->getType()) ?>">
		<div class="input-group-append">
			<button class="btn btn-primary" name="btn-submit" id="btn-submit" type="submit"><?php echo $Language->phrase("SearchBtn") ?></button>
			<button type="button" data-toggle="dropdown" class="btn btn-primary dropdown-toggle dropdown-toggle-split" aria-haspopup="true" aria-expanded="false"><span id="searchtype"><?php echo $vmerchantsales_list->BasicSearch->getTypeNameShort() ?></span></button>
			<div class="dropdown-menu dropdown-menu-right">
				<a class="dropdown-item<?php if ($vmerchantsales_list->BasicSearch->getType() == "") { ?> active<?php } ?>" href="#" onclick="return ew.setSearchType(this);"><?php echo $Language->phrase("QuickSearchAuto") ?></a>
				<a class="dropdown-item<?php if ($vmerchantsales_list->BasicSearch->getType() == "=") { ?> active<?php } ?>" href="#" onclick="return ew.setSearchType(this, '=');"><?php echo $Language->phrase("QuickSearchExact") ?></a>
				<a class="dropdown-item<?php if ($vmerchantsales_list->BasicSearch->getType() == "AND") { ?> active<?php } ?>" href="#" onclick="return ew.setSearchType(this, 'AND');"><?php echo $Language->phrase("QuickSearchAll") ?></a>
				<a class="dropdown-item<?php if ($vmerchantsales_list->BasicSearch->getType() == "OR") { ?> active<?php } ?>" href="#" onclick="return ew.setSearchType(this, 'OR');"><?php echo $Language->phrase("QuickSearchAny") ?></a>
			</div>
		</div>
	</div>
</div>
	</div><!-- /.ew-extended-search -->
</div><!-- /.ew-search-panel -->
</form>
<?php } ?>
<?php } ?>
<?php $vmerchantsales_list->showPageHeader(); ?>
<?php
$vmerchantsales_list->showMessage();
?>
<?php if ($vmerchantsales_list->TotalRecords > 0 || $vmerchantsales->CurrentAction) { ?>
<div class="card ew-card ew-grid<?php if ($vmerchantsales_list->isAddOrEdit()) { ?> ew-grid-add-edit<?php } ?> vmerchantsales">
<form name="fvmerchantsaleslist" id="fvmerchantsaleslist" class="form-inline ew-form ew-list-form" action="<?php echo CurrentPageName() ?>" method="post">
<?php if ($Page->CheckToken) { ?>
<input type="hidden" name="<?php echo Config("TOKEN_NAME") ?>" value="<?php echo $Page->Token ?>">
<?php } ?>
<input type="hidden" name="t" value="vmerchantsales">
<div id="gmp_vmerchantsales" class="<?php echo ResponsiveTableClass() ?>card-body ew-grid-middle-panel">
<?php if ($vmerchantsales_list->TotalRecords > 0 || $vmerchantsales_list->isGridEdit()) { ?>
<table id="tbl_vmerchantsaleslist" class="table ew-table"><!-- .ew-table -->
<thead>
	<tr class="ew-table-header">
<?php

// Header row
$vmerchantsales->RowType = ROWTYPE_HEADER;

// Render list options
$vmerchantsales_list->renderListOptions();

// Render list options (header, left)
$vmerchantsales_list->ListOptions->render("header", "left");
?>
<?php if ($vmerchantsales_list->transferID->Visible) { // transferID ?>
	<?php if ($vmerchantsales_list->SortUrl($vmerchantsales_list->transferID) == "") { ?>
		<th data-name="transferID" class="<?php echo $vmerchantsales_list->transferID->headerCellClass() ?>"><div id="elh_vmerchantsales_transferID" class="vmerchantsales_transferID"><div class="ew-table-header-caption"><?php echo $vmerchantsales_list->transferID->caption() ?></div></div></th>
	<?php } else { ?>
		<th data-name="transferID" class="<?php echo $vmerchantsales_list->transferID->headerCellClass() ?>"><div class="ew-pointer" onclick="ew.sort(event, '<?php echo $vmerchantsales_list->SortUrl($vmerchantsales_list->transferID) ?>', 1);"><div id="elh_vmerchantsales_transferID" class="vmerchantsales_transferID">
			<div class="ew-table-header-btn"><span class="ew-table-header-caption"><?php echo $vmerchantsales_list->transferID->caption() ?></span><span class="ew-table-header-sort"><?php if ($vmerchantsales_list->transferID->getSort() == "ASC") { ?><i class="fas fa-sort-up"></i><?php } elseif ($vmerchantsales_list->transferID->getSort() == "DESC") { ?><i class="fas fa-sort-down"></i><?php } ?></span></div>
		</div></div></th>
	<?php } ?>
<?php } ?>
<?php if ($vmerchantsales_list->txid->Visible) { // txid ?>
	<?php if ($vmerchantsales_list->SortUrl($vmerchantsales_list->txid) == "") { ?>
		<th data-name="txid" class="<?php echo $vmerchantsales_list->txid->headerCellClass() ?>"><div id="elh_vmerchantsales_txid" class="vmerchantsales_txid"><div class="ew-table-header-caption"><?php echo $vmerchantsales_list->txid->caption() ?></div></div></th>
	<?php } else { ?>
		<th data-name="txid" class="<?php echo $vmerchantsales_list->txid->headerCellClass() ?>"><div class="ew-pointer" onclick="ew.sort(event, '<?php echo $vmerchantsales_list->SortUrl($vmerchantsales_list->txid) ?>', 1);"><div id="elh_vmerchantsales_txid" class="vmerchantsales_txid">
			<div class="ew-table-header-btn"><span class="ew-table-header-caption"><?php echo $vmerchantsales_list->txid->caption() ?><?php echo $Language->phrase("SrchLegend") ?></span><span class="ew-table-header-sort"><?php if ($vmerchantsales_list->txid->getSort() == "ASC") { ?><i class="fas fa-sort-up"></i><?php } elseif ($vmerchantsales_list->txid->getSort() == "DESC") { ?><i class="fas fa-sort-down"></i><?php } ?></span></div>
		</div></div></th>
	<?php } ?>
<?php } ?>
<?php if ($vmerchantsales_list->merchantID->Visible) { // merchantID ?>
	<?php if ($vmerchantsales_list->SortUrl($vmerchantsales_list->merchantID) == "") { ?>
		<th data-name="merchantID" class="<?php echo $vmerchantsales_list->merchantID->headerCellClass() ?>"><div id="elh_vmerchantsales_merchantID" class="vmerchantsales_merchantID"><div class="ew-table-header-caption"><?php echo $vmerchantsales_list->merchantID->caption() ?></div></div></th>
	<?php } else { ?>
		<th data-name="merchantID" class="<?php echo $vmerchantsales_list->merchantID->headerCellClass() ?>"><div class="ew-pointer" onclick="ew.sort(event, '<?php echo $vmerchantsales_list->SortUrl($vmerchantsales_list->merchantID) ?>', 1);"><div id="elh_vmerchantsales_merchantID" class="vmerchantsales_merchantID">
			<div class="ew-table-header-btn"><span class="ew-table-header-caption"><?php echo $vmerchantsales_list->merchantID->caption() ?></span><span class="ew-table-header-sort"><?php if ($vmerchantsales_list->merchantID->getSort() == "ASC") { ?><i class="fas fa-sort-up"></i><?php } elseif ($vmerchantsales_list->merchantID->getSort() == "DESC") { ?><i class="fas fa-sort-down"></i><?php } ?></span></div>
		</div></div></th>
	<?php } ?>
<?php } ?>
<?php if ($vmerchantsales_list->transferTime->Visible) { // transferTime ?>
	<?php if ($vmerchantsales_list->SortUrl($vmerchantsales_list->transferTime) == "") { ?>
		<th data-name="transferTime" class="<?php echo $vmerchantsales_list->transferTime->headerCellClass() ?>"><div id="elh_vmerchantsales_transferTime" class="vmerchantsales_transferTime"><div class="ew-table-header-caption"><?php echo $vmerchantsales_list->transferTime->caption() ?></div></div></th>
	<?php } else { ?>
		<th data-name="transferTime" class="<?php echo $vmerchantsales_list->transferTime->headerCellClass() ?>"><div class="ew-pointer" onclick="ew.sort(event, '<?php echo $vmerchantsales_list->SortUrl($vmerchantsales_list->transferTime) ?>', 1);"><div id="elh_vmerchantsales_transferTime" class="vmerchantsales_transferTime">
			<div class="ew-table-header-btn"><span class="ew-table-header-caption"><?php echo $vmerchantsales_list->transferTime->caption() ?></span><span class="ew-table-header-sort"><?php if ($vmerchantsales_list->transferTime->getSort() == "ASC") { ?><i class="fas fa-sort-up"></i><?php } elseif ($vmerchantsales_list->transferTime->getSort() == "DESC") { ?><i class="fas fa-sort-down"></i><?php } ?></span></div>
		</div></div></th>
	<?php } ?>
<?php } ?>
<?php if ($vmerchantsales_list->status->Visible) { // status ?>
	<?php if ($vmerchantsales_list->SortUrl($vmerchantsales_list->status) == "") { ?>
		<th data-name="status" class="<?php echo $vmerchantsales_list->status->headerCellClass() ?>"><div id="elh_vmerchantsales_status" class="vmerchantsales_status"><div class="ew-table-header-caption"><?php echo $vmerchantsales_list->status->caption() ?></div></div></th>
	<?php } else { ?>
		<th data-name="status" class="<?php echo $vmerchantsales_list->status->headerCellClass() ?>"><div class="ew-pointer" onclick="ew.sort(event, '<?php echo $vmerchantsales_list->SortUrl($vmerchantsales_list->status) ?>', 1);"><div id="elh_vmerchantsales_status" class="vmerchantsales_status">
			<div class="ew-table-header-btn"><span class="ew-table-header-caption"><?php echo $vmerchantsales_list->status->caption() ?></span><span class="ew-table-header-sort"><?php if ($vmerchantsales_list->status->getSort() == "ASC") { ?><i class="fas fa-sort-up"></i><?php } elseif ($vmerchantsales_list->status->getSort() == "DESC") { ?><i class="fas fa-sort-down"></i><?php } ?></span></div>
		</div></div></th>
	<?php } ?>
<?php } ?>
<?php if ($vmerchantsales_list->currID->Visible) { // currID ?>
	<?php if ($vmerchantsales_list->SortUrl($vmerchantsales_list->currID) == "") { ?>
		<th data-name="currID" class="<?php echo $vmerchantsales_list->currID->headerCellClass() ?>"><div id="elh_vmerchantsales_currID" class="vmerchantsales_currID"><div class="ew-table-header-caption"><?php echo $vmerchantsales_list->currID->caption() ?></div></div></th>
	<?php } else { ?>
		<th data-name="currID" class="<?php echo $vmerchantsales_list->currID->headerCellClass() ?>"><div class="ew-pointer" onclick="ew.sort(event, '<?php echo $vmerchantsales_list->SortUrl($vmerchantsales_list->currID) ?>', 1);"><div id="elh_vmerchantsales_currID" class="vmerchantsales_currID">
			<div class="ew-table-header-btn"><span class="ew-table-header-caption"><?php echo $vmerchantsales_list->currID->caption() ?><?php echo $Language->phrase("SrchLegend") ?></span><span class="ew-table-header-sort"><?php if ($vmerchantsales_list->currID->getSort() == "ASC") { ?><i class="fas fa-sort-up"></i><?php } elseif ($vmerchantsales_list->currID->getSort() == "DESC") { ?><i class="fas fa-sort-down"></i><?php } ?></span></div>
		</div></div></th>
	<?php } ?>
<?php } ?>
<?php if ($vmerchantsales_list->TotalAmountForCustomer->Visible) { // TotalAmountForCustomer ?>
	<?php if ($vmerchantsales_list->SortUrl($vmerchantsales_list->TotalAmountForCustomer) == "") { ?>
		<th data-name="TotalAmountForCustomer" class="<?php echo $vmerchantsales_list->TotalAmountForCustomer->headerCellClass() ?>"><div id="elh_vmerchantsales_TotalAmountForCustomer" class="vmerchantsales_TotalAmountForCustomer"><div class="ew-table-header-caption"><?php echo $vmerchantsales_list->TotalAmountForCustomer->caption() ?></div></div></th>
	<?php } else { ?>
		<th data-name="TotalAmountForCustomer" class="<?php echo $vmerchantsales_list->TotalAmountForCustomer->headerCellClass() ?>"><div class="ew-pointer" onclick="ew.sort(event, '<?php echo $vmerchantsales_list->SortUrl($vmerchantsales_list->TotalAmountForCustomer) ?>', 1);"><div id="elh_vmerchantsales_TotalAmountForCustomer" class="vmerchantsales_TotalAmountForCustomer">
			<div class="ew-table-header-btn"><span class="ew-table-header-caption"><?php echo $vmerchantsales_list->TotalAmountForCustomer->caption() ?></span><span class="ew-table-header-sort"><?php if ($vmerchantsales_list->TotalAmountForCustomer->getSort() == "ASC") { ?><i class="fas fa-sort-up"></i><?php } elseif ($vmerchantsales_list->TotalAmountForCustomer->getSort() == "DESC") { ?><i class="fas fa-sort-down"></i><?php } ?></span></div>
		</div></div></th>
	<?php } ?>
<?php } ?>
<?php if ($vmerchantsales_list->serviceFeeToMerchant->Visible) { // serviceFeeToMerchant ?>
	<?php if ($vmerchantsales_list->SortUrl($vmerchantsales_list->serviceFeeToMerchant) == "") { ?>
		<th data-name="serviceFeeToMerchant" class="<?php echo $vmerchantsales_list->serviceFeeToMerchant->headerCellClass() ?>"><div id="elh_vmerchantsales_serviceFeeToMerchant" class="vmerchantsales_serviceFeeToMerchant"><div class="ew-table-header-caption"><?php echo $vmerchantsales_list->serviceFeeToMerchant->caption() ?></div></div></th>
	<?php } else { ?>
		<th data-name="serviceFeeToMerchant" class="<?php echo $vmerchantsales_list->serviceFeeToMerchant->headerCellClass() ?>"><div class="ew-pointer" onclick="ew.sort(event, '<?php echo $vmerchantsales_list->SortUrl($vmerchantsales_list->serviceFeeToMerchant) ?>', 1);"><div id="elh_vmerchantsales_serviceFeeToMerchant" class="vmerchantsales_serviceFeeToMerchant">
			<div class="ew-table-header-btn"><span class="ew-table-header-caption"><?php echo $vmerchantsales_list->serviceFeeToMerchant->caption() ?></span><span class="ew-table-header-sort"><?php if ($vmerchantsales_list->serviceFeeToMerchant->getSort() == "ASC") { ?><i class="fas fa-sort-up"></i><?php } elseif ($vmerchantsales_list->serviceFeeToMerchant->getSort() == "DESC") { ?><i class="fas fa-sort-down"></i><?php } ?></span></div>
		</div></div></th>
	<?php } ?>
<?php } ?>
<?php if ($vmerchantsales_list->TotalAmountForMerchant->Visible) { // TotalAmountForMerchant ?>
	<?php if ($vmerchantsales_list->SortUrl($vmerchantsales_list->TotalAmountForMerchant) == "") { ?>
		<th data-name="TotalAmountForMerchant" class="<?php echo $vmerchantsales_list->TotalAmountForMerchant->headerCellClass() ?>"><div id="elh_vmerchantsales_TotalAmountForMerchant" class="vmerchantsales_TotalAmountForMerchant"><div class="ew-table-header-caption"><?php echo $vmerchantsales_list->TotalAmountForMerchant->caption() ?></div></div></th>
	<?php } else { ?>
		<th data-name="TotalAmountForMerchant" class="<?php echo $vmerchantsales_list->TotalAmountForMerchant->headerCellClass() ?>"><div class="ew-pointer" onclick="ew.sort(event, '<?php echo $vmerchantsales_list->SortUrl($vmerchantsales_list->TotalAmountForMerchant) ?>', 1);"><div id="elh_vmerchantsales_TotalAmountForMerchant" class="vmerchantsales_TotalAmountForMerchant">
			<div class="ew-table-header-btn"><span class="ew-table-header-caption"><?php echo $vmerchantsales_list->TotalAmountForMerchant->caption() ?></span><span class="ew-table-header-sort"><?php if ($vmerchantsales_list->TotalAmountForMerchant->getSort() == "ASC") { ?><i class="fas fa-sort-up"></i><?php } elseif ($vmerchantsales_list->TotalAmountForMerchant->getSort() == "DESC") { ?><i class="fas fa-sort-down"></i><?php } ?></span></div>
		</div></div></th>
	<?php } ?>
<?php } ?>
<?php if ($vmerchantsales_list->userpiid->Visible) { // userpiid ?>
	<?php if ($vmerchantsales_list->SortUrl($vmerchantsales_list->userpiid) == "") { ?>
		<th data-name="userpiid" class="<?php echo $vmerchantsales_list->userpiid->headerCellClass() ?>"><div id="elh_vmerchantsales_userpiid" class="vmerchantsales_userpiid"><div class="ew-table-header-caption"><?php echo $vmerchantsales_list->userpiid->caption() ?></div></div></th>
	<?php } else { ?>
		<th data-name="userpiid" class="<?php echo $vmerchantsales_list->userpiid->headerCellClass() ?>"><div class="ew-pointer" onclick="ew.sort(event, '<?php echo $vmerchantsales_list->SortUrl($vmerchantsales_list->userpiid) ?>', 1);"><div id="elh_vmerchantsales_userpiid" class="vmerchantsales_userpiid">
			<div class="ew-table-header-btn"><span class="ew-table-header-caption"><?php echo $vmerchantsales_list->userpiid->caption() ?></span><span class="ew-table-header-sort"><?php if ($vmerchantsales_list->userpiid->getSort() == "ASC") { ?><i class="fas fa-sort-up"></i><?php } elseif ($vmerchantsales_list->userpiid->getSort() == "DESC") { ?><i class="fas fa-sort-down"></i><?php } ?></span></div>
		</div></div></th>
	<?php } ?>
<?php } ?>
<?php if ($vmerchantsales_list->shoppingCartID->Visible) { // shoppingCartID ?>
	<?php if ($vmerchantsales_list->SortUrl($vmerchantsales_list->shoppingCartID) == "") { ?>
		<th data-name="shoppingCartID" class="<?php echo $vmerchantsales_list->shoppingCartID->headerCellClass() ?>"><div id="elh_vmerchantsales_shoppingCartID" class="vmerchantsales_shoppingCartID"><div class="ew-table-header-caption"><?php echo $vmerchantsales_list->shoppingCartID->caption() ?></div></div></th>
	<?php } else { ?>
		<th data-name="shoppingCartID" class="<?php echo $vmerchantsales_list->shoppingCartID->headerCellClass() ?>"><div class="ew-pointer" onclick="ew.sort(event, '<?php echo $vmerchantsales_list->SortUrl($vmerchantsales_list->shoppingCartID) ?>', 1);"><div id="elh_vmerchantsales_shoppingCartID" class="vmerchantsales_shoppingCartID">
			<div class="ew-table-header-btn"><span class="ew-table-header-caption"><?php echo $vmerchantsales_list->shoppingCartID->caption() ?><?php echo $Language->phrase("SrchLegend") ?></span><span class="ew-table-header-sort"><?php if ($vmerchantsales_list->shoppingCartID->getSort() == "ASC") { ?><i class="fas fa-sort-up"></i><?php } elseif ($vmerchantsales_list->shoppingCartID->getSort() == "DESC") { ?><i class="fas fa-sort-down"></i><?php } ?></span></div>
		</div></div></th>
	<?php } ?>
<?php } ?>
<?php if ($vmerchantsales_list->merchantRefID->Visible) { // merchantRefID ?>
	<?php if ($vmerchantsales_list->SortUrl($vmerchantsales_list->merchantRefID) == "") { ?>
		<th data-name="merchantRefID" class="<?php echo $vmerchantsales_list->merchantRefID->headerCellClass() ?>"><div id="elh_vmerchantsales_merchantRefID" class="vmerchantsales_merchantRefID"><div class="ew-table-header-caption"><?php echo $vmerchantsales_list->merchantRefID->caption() ?></div></div></th>
	<?php } else { ?>
		<th data-name="merchantRefID" class="<?php echo $vmerchantsales_list->merchantRefID->headerCellClass() ?>"><div class="ew-pointer" onclick="ew.sort(event, '<?php echo $vmerchantsales_list->SortUrl($vmerchantsales_list->merchantRefID) ?>', 1);"><div id="elh_vmerchantsales_merchantRefID" class="vmerchantsales_merchantRefID">
			<div class="ew-table-header-btn"><span class="ew-table-header-caption"><?php echo $vmerchantsales_list->merchantRefID->caption() ?><?php echo $Language->phrase("SrchLegend") ?></span><span class="ew-table-header-sort"><?php if ($vmerchantsales_list->merchantRefID->getSort() == "ASC") { ?><i class="fas fa-sort-up"></i><?php } elseif ($vmerchantsales_list->merchantRefID->getSort() == "DESC") { ?><i class="fas fa-sort-down"></i><?php } ?></span></div>
		</div></div></th>
	<?php } ?>
<?php } ?>
<?php if ($vmerchantsales_list->userpi->Visible) { // userpi ?>
	<?php if ($vmerchantsales_list->SortUrl($vmerchantsales_list->userpi) == "") { ?>
		<th data-name="userpi" class="<?php echo $vmerchantsales_list->userpi->headerCellClass() ?>"><div id="elh_vmerchantsales_userpi" class="vmerchantsales_userpi"><div class="ew-table-header-caption"><?php echo $vmerchantsales_list->userpi->caption() ?></div></div></th>
	<?php } else { ?>
		<th data-name="userpi" class="<?php echo $vmerchantsales_list->userpi->headerCellClass() ?>"><div class="ew-pointer" onclick="ew.sort(event, '<?php echo $vmerchantsales_list->SortUrl($vmerchantsales_list->userpi) ?>', 1);"><div id="elh_vmerchantsales_userpi" class="vmerchantsales_userpi">
			<div class="ew-table-header-btn"><span class="ew-table-header-caption"><?php echo $vmerchantsales_list->userpi->caption() ?></span><span class="ew-table-header-sort"><?php if ($vmerchantsales_list->userpi->getSort() == "ASC") { ?><i class="fas fa-sort-up"></i><?php } elseif ($vmerchantsales_list->userpi->getSort() == "DESC") { ?><i class="fas fa-sort-down"></i><?php } ?></span></div>
		</div></div></th>
	<?php } ?>
<?php } ?>
<?php

// Render list options (header, right)
$vmerchantsales_list->ListOptions->render("header", "right");
?>
	</tr>
</thead>
<tbody>
<?php
if ($vmerchantsales_list->ExportAll && $vmerchantsales_list->isExport()) {
	$vmerchantsales_list->StopRecord = $vmerchantsales_list->TotalRecords;
} else {

	// Set the last record to display
	if ($vmerchantsales_list->TotalRecords > $vmerchantsales_list->StartRecord + $vmerchantsales_list->DisplayRecords - 1)
		$vmerchantsales_list->StopRecord = $vmerchantsales_list->StartRecord + $vmerchantsales_list->DisplayRecords - 1;
	else
		$vmerchantsales_list->StopRecord = $vmerchantsales_list->TotalRecords;
}
$vmerchantsales_list->RecordCount = $vmerchantsales_list->StartRecord - 1;
if ($vmerchantsales_list->Recordset && !$vmerchantsales_list->Recordset->EOF) {
	$vmerchantsales_list->Recordset->moveFirst();
	$selectLimit = $vmerchantsales_list->UseSelectLimit;
	if (!$selectLimit && $vmerchantsales_list->StartRecord > 1)
		$vmerchantsales_list->Recordset->move($vmerchantsales_list->StartRecord - 1);
} elseif (!$vmerchantsales->AllowAddDeleteRow && $vmerchantsales_list->StopRecord == 0) {
	$vmerchantsales_list->StopRecord = $vmerchantsales->GridAddRowCount;
}

// Initialize aggregate
$vmerchantsales->RowType = ROWTYPE_AGGREGATEINIT;
$vmerchantsales->resetAttributes();
$vmerchantsales_list->renderRow();
while ($vmerchantsales_list->RecordCount < $vmerchantsales_list->StopRecord) {
	$vmerchantsales_list->RecordCount++;
	if ($vmerchantsales_list->RecordCount >= $vmerchantsales_list->StartRecord) {
		$vmerchantsales_list->RowCount++;

		// Set up key count
		$vmerchantsales_list->KeyCount = $vmerchantsales_list->RowIndex;

		// Init row class and style
		$vmerchantsales->resetAttributes();
		$vmerchantsales->CssClass = "";
		if ($vmerchantsales_list->isGridAdd()) {
		} else {
			$vmerchantsales_list->loadRowValues($vmerchantsales_list->Recordset); // Load row values
		}
		$vmerchantsales->RowType = ROWTYPE_VIEW; // Render view

		// Set up row id / data-rowindex
		$vmerchantsales->RowAttrs->merge(["data-rowindex" => $vmerchantsales_list->RowCount, "id" => "r" . $vmerchantsales_list->RowCount . "_vmerchantsales", "data-rowtype" => $vmerchantsales->RowType]);

		// Render row
		$vmerchantsales_list->renderRow();

		// Render list options
		$vmerchantsales_list->renderListOptions();
?>
	<tr <?php echo $vmerchantsales->rowAttributes() ?>>
<?php

// Render list options (body, left)
$vmerchantsales_list->ListOptions->render("body", "left", $vmerchantsales_list->RowCount);
?>
	<?php if ($vmerchantsales_list->transferID->Visible) { // transferID ?>
		<td data-name="transferID" <?php echo $vmerchantsales_list->transferID->cellAttributes() ?>>
<span id="el<?php echo $vmerchantsales_list->RowCount ?>_vmerchantsales_transferID">
<span<?php echo $vmerchantsales_list->transferID->viewAttributes() ?>><?php echo $vmerchantsales_list->transferID->getViewValue() ?></span>
</span>
</td>
	<?php } ?>
	<?php if ($vmerchantsales_list->txid->Visible) { // txid ?>
		<td data-name="txid" <?php echo $vmerchantsales_list->txid->cellAttributes() ?>>
<span id="el<?php echo $vmerchantsales_list->RowCount ?>_vmerchantsales_txid">
<span<?php echo $vmerchantsales_list->txid->viewAttributes() ?>><?php echo $vmerchantsales_list->txid->getViewValue() ?></span>
</span>
</td>
	<?php } ?>
	<?php if ($vmerchantsales_list->merchantID->Visible) { // merchantID ?>
		<td data-name="merchantID" <?php echo $vmerchantsales_list->merchantID->cellAttributes() ?>>
<span id="el<?php echo $vmerchantsales_list->RowCount ?>_vmerchantsales_merchantID">
<span<?php echo $vmerchantsales_list->merchantID->viewAttributes() ?>><?php echo $vmerchantsales_list->merchantID->getViewValue() ?></span>
</span>
</td>
	<?php } ?>
	<?php if ($vmerchantsales_list->transferTime->Visible) { // transferTime ?>
		<td data-name="transferTime" <?php echo $vmerchantsales_list->transferTime->cellAttributes() ?>>
<span id="el<?php echo $vmerchantsales_list->RowCount ?>_vmerchantsales_transferTime">
<span<?php echo $vmerchantsales_list->transferTime->viewAttributes() ?>><?php echo $vmerchantsales_list->transferTime->getViewValue() ?></span>
</span>
</td>
	<?php } ?>
	<?php if ($vmerchantsales_list->status->Visible) { // status ?>
		<td data-name="status" <?php echo $vmerchantsales_list->status->cellAttributes() ?>>
<span id="el<?php echo $vmerchantsales_list->RowCount ?>_vmerchantsales_status">
<span<?php echo $vmerchantsales_list->status->viewAttributes() ?>><?php echo $vmerchantsales_list->status->getViewValue() ?></span>
</span>
</td>
	<?php } ?>
	<?php if ($vmerchantsales_list->currID->Visible) { // currID ?>
		<td data-name="currID" <?php echo $vmerchantsales_list->currID->cellAttributes() ?>>
<span id="el<?php echo $vmerchantsales_list->RowCount ?>_vmerchantsales_currID">
<span<?php echo $vmerchantsales_list->currID->viewAttributes() ?>><?php echo $vmerchantsales_list->currID->getViewValue() ?></span>
</span>
</td>
	<?php } ?>
	<?php if ($vmerchantsales_list->TotalAmountForCustomer->Visible) { // TotalAmountForCustomer ?>
		<td data-name="TotalAmountForCustomer" <?php echo $vmerchantsales_list->TotalAmountForCustomer->cellAttributes() ?>>
<span id="el<?php echo $vmerchantsales_list->RowCount ?>_vmerchantsales_TotalAmountForCustomer">
<span<?php echo $vmerchantsales_list->TotalAmountForCustomer->viewAttributes() ?>><?php echo $vmerchantsales_list->TotalAmountForCustomer->getViewValue() ?></span>
</span>
</td>
	<?php } ?>
	<?php if ($vmerchantsales_list->serviceFeeToMerchant->Visible) { // serviceFeeToMerchant ?>
		<td data-name="serviceFeeToMerchant" <?php echo $vmerchantsales_list->serviceFeeToMerchant->cellAttributes() ?>>
<span id="el<?php echo $vmerchantsales_list->RowCount ?>_vmerchantsales_serviceFeeToMerchant">
<span<?php echo $vmerchantsales_list->serviceFeeToMerchant->viewAttributes() ?>><?php echo $vmerchantsales_list->serviceFeeToMerchant->getViewValue() ?></span>
</span>
</td>
	<?php } ?>
	<?php if ($vmerchantsales_list->TotalAmountForMerchant->Visible) { // TotalAmountForMerchant ?>
		<td data-name="TotalAmountForMerchant" <?php echo $vmerchantsales_list->TotalAmountForMerchant->cellAttributes() ?>>
<span id="el<?php echo $vmerchantsales_list->RowCount ?>_vmerchantsales_TotalAmountForMerchant">
<span<?php echo $vmerchantsales_list->TotalAmountForMerchant->viewAttributes() ?>><?php echo $vmerchantsales_list->TotalAmountForMerchant->getViewValue() ?></span>
</span>
</td>
	<?php } ?>
	<?php if ($vmerchantsales_list->userpiid->Visible) { // userpiid ?>
		<td data-name="userpiid" <?php echo $vmerchantsales_list->userpiid->cellAttributes() ?>>
<span id="el<?php echo $vmerchantsales_list->RowCount ?>_vmerchantsales_userpiid">
<span<?php echo $vmerchantsales_list->userpiid->viewAttributes() ?>><?php echo $vmerchantsales_list->userpiid->getViewValue() ?></span>
</span>
</td>
	<?php } ?>
	<?php if ($vmerchantsales_list->shoppingCartID->Visible) { // shoppingCartID ?>
		<td data-name="shoppingCartID" <?php echo $vmerchantsales_list->shoppingCartID->cellAttributes() ?>>
<span id="el<?php echo $vmerchantsales_list->RowCount ?>_vmerchantsales_shoppingCartID">
<span<?php echo $vmerchantsales_list->shoppingCartID->viewAttributes() ?>><?php echo $vmerchantsales_list->shoppingCartID->getViewValue() ?></span>
</span>
</td>
	<?php } ?>
	<?php if ($vmerchantsales_list->merchantRefID->Visible) { // merchantRefID ?>
		<td data-name="merchantRefID" <?php echo $vmerchantsales_list->merchantRefID->cellAttributes() ?>>
<span id="el<?php echo $vmerchantsales_list->RowCount ?>_vmerchantsales_merchantRefID">
<span<?php echo $vmerchantsales_list->merchantRefID->viewAttributes() ?>><?php echo $vmerchantsales_list->merchantRefID->getViewValue() ?></span>
</span>
</td>
	<?php } ?>
	<?php if ($vmerchantsales_list->userpi->Visible) { // userpi ?>
		<td data-name="userpi" <?php echo $vmerchantsales_list->userpi->cellAttributes() ?>>
<span id="el<?php echo $vmerchantsales_list->RowCount ?>_vmerchantsales_userpi">
<span<?php echo $vmerchantsales_list->userpi->viewAttributes() ?>><?php echo $vmerchantsales_list->userpi->getViewValue() ?></span>
</span>
</td>
	<?php } ?>
<?php

// Render list options (body, right)
$vmerchantsales_list->ListOptions->render("body", "right", $vmerchantsales_list->RowCount);
?>
	</tr>
<?php
	}
	if (!$vmerchantsales_list->isGridAdd())
		$vmerchantsales_list->Recordset->moveNext();
}
?>
</tbody>
<?php

// Render aggregate row
$vmerchantsales->RowType = ROWTYPE_AGGREGATE;
$vmerchantsales->resetAttributes();
$vmerchantsales_list->renderRow();
?>
<?php if ($vmerchantsales_list->TotalRecords > 0 && !$vmerchantsales_list->isGridAdd() && !$vmerchantsales_list->isGridEdit()) { ?>
<tfoot><!-- Table footer -->
	<tr class="ew-table-footer">
<?php

// Render list options
$vmerchantsales_list->renderListOptions();

// Render list options (footer, left)
$vmerchantsales_list->ListOptions->render("footer", "left");
?>
	<?php if ($vmerchantsales_list->transferID->Visible) { // transferID ?>
		<td data-name="transferID" class="<?php echo $vmerchantsales_list->transferID->footerCellClass() ?>"><span id="elf_vmerchantsales_transferID" class="vmerchantsales_transferID">
		&nbsp;
		</span></td>
	<?php } ?>
	<?php if ($vmerchantsales_list->txid->Visible) { // txid ?>
		<td data-name="txid" class="<?php echo $vmerchantsales_list->txid->footerCellClass() ?>"><span id="elf_vmerchantsales_txid" class="vmerchantsales_txid">
		&nbsp;
		</span></td>
	<?php } ?>
	<?php if ($vmerchantsales_list->merchantID->Visible) { // merchantID ?>
		<td data-name="merchantID" class="<?php echo $vmerchantsales_list->merchantID->footerCellClass() ?>"><span id="elf_vmerchantsales_merchantID" class="vmerchantsales_merchantID">
		&nbsp;
		</span></td>
	<?php } ?>
	<?php if ($vmerchantsales_list->transferTime->Visible) { // transferTime ?>
		<td data-name="transferTime" class="<?php echo $vmerchantsales_list->transferTime->footerCellClass() ?>"><span id="elf_vmerchantsales_transferTime" class="vmerchantsales_transferTime">
		&nbsp;
		</span></td>
	<?php } ?>
	<?php if ($vmerchantsales_list->status->Visible) { // status ?>
		<td data-name="status" class="<?php echo $vmerchantsales_list->status->footerCellClass() ?>"><span id="elf_vmerchantsales_status" class="vmerchantsales_status">
		&nbsp;
		</span></td>
	<?php } ?>
	<?php if ($vmerchantsales_list->currID->Visible) { // currID ?>
		<td data-name="currID" class="<?php echo $vmerchantsales_list->currID->footerCellClass() ?>"><span id="elf_vmerchantsales_currID" class="vmerchantsales_currID">
		&nbsp;
		</span></td>
	<?php } ?>
	<?php if ($vmerchantsales_list->TotalAmountForCustomer->Visible) { // TotalAmountForCustomer ?>
		<td data-name="TotalAmountForCustomer" class="<?php echo $vmerchantsales_list->TotalAmountForCustomer->footerCellClass() ?>"><span id="elf_vmerchantsales_TotalAmountForCustomer" class="vmerchantsales_TotalAmountForCustomer">
		<span class="ew-aggregate"><?php echo $Language->phrase("TOTAL") ?></span><span class="ew-aggregate-value">
		<?php echo $vmerchantsales_list->TotalAmountForCustomer->ViewValue ?></span>
		</span></td>
	<?php } ?>
	<?php if ($vmerchantsales_list->serviceFeeToMerchant->Visible) { // serviceFeeToMerchant ?>
		<td data-name="serviceFeeToMerchant" class="<?php echo $vmerchantsales_list->serviceFeeToMerchant->footerCellClass() ?>"><span id="elf_vmerchantsales_serviceFeeToMerchant" class="vmerchantsales_serviceFeeToMerchant">
		<span class="ew-aggregate"><?php echo $Language->phrase("TOTAL") ?></span><span class="ew-aggregate-value">
		<?php echo $vmerchantsales_list->serviceFeeToMerchant->ViewValue ?></span>
		</span></td>
	<?php } ?>
	<?php if ($vmerchantsales_list->TotalAmountForMerchant->Visible) { // TotalAmountForMerchant ?>
		<td data-name="TotalAmountForMerchant" class="<?php echo $vmerchantsales_list->TotalAmountForMerchant->footerCellClass() ?>"><span id="elf_vmerchantsales_TotalAmountForMerchant" class="vmerchantsales_TotalAmountForMerchant">
		<span class="ew-aggregate"><?php echo $Language->phrase("TOTAL") ?></span><span class="ew-aggregate-value">
		<?php echo $vmerchantsales_list->TotalAmountForMerchant->ViewValue ?></span>
		</span></td>
	<?php } ?>
	<?php if ($vmerchantsales_list->userpiid->Visible) { // userpiid ?>
		<td data-name="userpiid" class="<?php echo $vmerchantsales_list->userpiid->footerCellClass() ?>"><span id="elf_vmerchantsales_userpiid" class="vmerchantsales_userpiid">
		&nbsp;
		</span></td>
	<?php } ?>
	<?php if ($vmerchantsales_list->shoppingCartID->Visible) { // shoppingCartID ?>
		<td data-name="shoppingCartID" class="<?php echo $vmerchantsales_list->shoppingCartID->footerCellClass() ?>"><span id="elf_vmerchantsales_shoppingCartID" class="vmerchantsales_shoppingCartID">
		&nbsp;
		</span></td>
	<?php } ?>
	<?php if ($vmerchantsales_list->merchantRefID->Visible) { // merchantRefID ?>
		<td data-name="merchantRefID" class="<?php echo $vmerchantsales_list->merchantRefID->footerCellClass() ?>"><span id="elf_vmerchantsales_merchantRefID" class="vmerchantsales_merchantRefID">
		&nbsp;
		</span></td>
	<?php } ?>
	<?php if ($vmerchantsales_list->userpi->Visible) { // userpi ?>
		<td data-name="userpi" class="<?php echo $vmerchantsales_list->userpi->footerCellClass() ?>"><span id="elf_vmerchantsales_userpi" class="vmerchantsales_userpi">
		&nbsp;
		</span></td>
	<?php } ?>
<?php

// Render list options (footer, right)
$vmerchantsales_list->ListOptions->render("footer", "right");
?>
	</tr>
</tfoot>
<?php } ?>
</table><!-- /.ew-table -->
<?php } ?>
</div><!-- /.ew-grid-middle-panel -->
<?php if (!$vmerchantsales->CurrentAction) { ?>
<input type="hidden" name="action" id="action" value="">
<?php } ?>
</form><!-- /.ew-list-form -->
<?php

// Close recordset
if ($vmerchantsales_list->Recordset)
	$vmerchantsales_list->Recordset->Close();
?>
<?php if (!$vmerchantsales_list->isExport()) { ?>
<div class="card-footer ew-grid-lower-panel">
<?php if (!$vmerchantsales_list->isGridAdd()) { ?>
<form name="ew-pager-form" class="form-inline ew-form ew-pager-form" action="<?php echo CurrentPageName() ?>">
<?php echo $vmerchantsales_list->Pager->render() ?>
</form>
<?php } ?>
<div class="ew-list-other-options">
<?php $vmerchantsales_list->OtherOptions->render("body", "bottom") ?>
</div>
<div class="clearfix"></div>
</div>
<?php } ?>
</div><!-- /.ew-grid -->
<?php } ?>
<?php if ($vmerchantsales_list->TotalRecords == 0 && !$vmerchantsales->CurrentAction) { // Show other options ?>
<div class="ew-list-other-options">
<?php $vmerchantsales_list->OtherOptions->render("body") ?>
</div>
<div class="clearfix"></div>
<?php } ?>
<?php
$vmerchantsales_list->showPageFooter();
if (Config("DEBUG"))
	echo GetDebugMessage();
?>
<?php if (!$vmerchantsales_list->isExport()) { ?>
<script>
loadjs.ready("load", function() {

	// Startup script
	// Write your table-specific startup script here
	// console.log("page loaded");

});
</script>
<?php } ?>
<?php include_once "footer.php"; ?>
<?php
$vmerchantsales_list->terminate();
?>