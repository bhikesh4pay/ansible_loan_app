<?php
namespace PHPMaker2020\_4payadmin;

// Autoload
include_once "autoload.php";

// Session
if (session_status() !== PHP_SESSION_ACTIVE)
	\Delight\Cookie\Session::start(Config("COOKIE_SAMESITE")); // Init session data

// Output buffering
ob_start();
?>
<?php

// Write header
WriteHeader(FALSE);

// Create page object
$transrecords_list = new transrecords_list();

// Run the page
$transrecords_list->run();

// Setup login status
SetupLoginStatus();
SetClientVar("login", LoginStatus());

// Global Page Rendering event (in userfn*.php)
Page_Rendering();

// Page Rendering event
$transrecords_list->Page_Render();
?>
<?php include_once "header.php"; ?>
<?php if (!$transrecords_list->isExport()) { ?>
<script>
var ftransrecordslist, currentPageID;
loadjs.ready("head", function() {

	// Form object
	currentPageID = ew.PAGE_ID = "list";
	ftransrecordslist = currentForm = new ew.Form("ftransrecordslist", "list");
	ftransrecordslist.formKeyCountName = '<?php echo $transrecords_list->FormKeyCountName ?>';
	loadjs.done("ftransrecordslist");
});
var ftransrecordslistsrch;
loadjs.ready("head", function() {

	// Form object for search
	ftransrecordslistsrch = currentSearchForm = new ew.Form("ftransrecordslistsrch");

	// Dynamic selection lists
	// Filters

	ftransrecordslistsrch.filterList = <?php echo $transrecords_list->getFilterList() ?>;

	// Init search panel as collapsed
	ftransrecordslistsrch.initSearchPanel = true;
	loadjs.done("ftransrecordslistsrch");
});
</script>
<style type="text/css">
.ew-table-preview-row { /* main table preview row color */
	background-color: #FFFFFF; /* preview row color */
}
.ew-table-preview-row .ew-grid {
	display: table;
}
</style>
<div id="ew-preview" class="d-none"><!-- preview -->
	<div class="ew-nav-tabs"><!-- .ew-nav-tabs -->
		<ul class="nav nav-tabs"></ul>
		<div class="tab-content"><!-- .tab-content -->
			<div class="tab-pane fade active show"></div>
		</div><!-- /.tab-content -->
	</div><!-- /.ew-nav-tabs -->
</div><!-- /preview -->
<script>
loadjs.ready("head", function() {
	ew.PREVIEW_PLACEMENT = ew.CSS_FLIP ? "right" : "left";
	ew.PREVIEW_SINGLE_ROW = false;
	ew.PREVIEW_OVERLAY = false;
	loadjs("js/ewpreview.js", "preview");
});
</script>
<script>
loadjs.ready("head", function() {

	// Client script
	// Write your client script here, no need to add script tags.

});
</script>
<?php } ?>
<?php if (!$transrecords_list->isExport()) { ?>
<div class="btn-toolbar ew-toolbar">
<?php if ($transrecords_list->TotalRecords > 0 && $transrecords_list->ExportOptions->visible()) { ?>
<?php $transrecords_list->ExportOptions->render("body") ?>
<?php } ?>
<?php if ($transrecords_list->ImportOptions->visible()) { ?>
<?php $transrecords_list->ImportOptions->render("body") ?>
<?php } ?>
<?php if ($transrecords_list->SearchOptions->visible()) { ?>
<?php $transrecords_list->SearchOptions->render("body") ?>
<?php } ?>
<?php if ($transrecords_list->FilterOptions->visible()) { ?>
<?php $transrecords_list->FilterOptions->render("body") ?>
<?php } ?>
<div class="clearfix"></div>
</div>
<?php } ?>
<?php
$transrecords_list->renderOtherOptions();
?>
<?php if ($Security->CanSearch()) { ?>
<?php if (!$transrecords_list->isExport() && !$transrecords->CurrentAction) { ?>
<form name="ftransrecordslistsrch" id="ftransrecordslistsrch" class="form-inline ew-form ew-ext-search-form" action="<?php echo CurrentPageName() ?>">
<div id="ftransrecordslistsrch-search-panel" class="<?php echo $transrecords_list->SearchPanelClass ?>">
<input type="hidden" name="cmd" value="search">
<input type="hidden" name="t" value="transrecords">
	<div class="ew-extended-search">
<div id="xsr_<?php echo $transrecords_list->SearchRowCount + 1 ?>" class="ew-row d-sm-flex">
	<div class="ew-quick-search input-group">
		<input type="text" name="<?php echo Config("TABLE_BASIC_SEARCH") ?>" id="<?php echo Config("TABLE_BASIC_SEARCH") ?>" class="form-control" value="<?php echo HtmlEncode($transrecords_list->BasicSearch->getKeyword()) ?>" placeholder="<?php echo HtmlEncode($Language->phrase("Search")) ?>">
		<input type="hidden" name="<?php echo Config("TABLE_BASIC_SEARCH_TYPE") ?>" id="<?php echo Config("TABLE_BASIC_SEARCH_TYPE") ?>" value="<?php echo HtmlEncode($transrecords_list->BasicSearch->getType()) ?>">
		<div class="input-group-append">
			<button class="btn btn-primary" name="btn-submit" id="btn-submit" type="submit"><?php echo $Language->phrase("SearchBtn") ?></button>
			<button type="button" data-toggle="dropdown" class="btn btn-primary dropdown-toggle dropdown-toggle-split" aria-haspopup="true" aria-expanded="false"><span id="searchtype"><?php echo $transrecords_list->BasicSearch->getTypeNameShort() ?></span></button>
			<div class="dropdown-menu dropdown-menu-right">
				<a class="dropdown-item<?php if ($transrecords_list->BasicSearch->getType() == "") { ?> active<?php } ?>" href="#" onclick="return ew.setSearchType(this);"><?php echo $Language->phrase("QuickSearchAuto") ?></a>
				<a class="dropdown-item<?php if ($transrecords_list->BasicSearch->getType() == "=") { ?> active<?php } ?>" href="#" onclick="return ew.setSearchType(this, '=');"><?php echo $Language->phrase("QuickSearchExact") ?></a>
				<a class="dropdown-item<?php if ($transrecords_list->BasicSearch->getType() == "AND") { ?> active<?php } ?>" href="#" onclick="return ew.setSearchType(this, 'AND');"><?php echo $Language->phrase("QuickSearchAll") ?></a>
				<a class="dropdown-item<?php if ($transrecords_list->BasicSearch->getType() == "OR") { ?> active<?php } ?>" href="#" onclick="return ew.setSearchType(this, 'OR');"><?php echo $Language->phrase("QuickSearchAny") ?></a>
			</div>
		</div>
	</div>
</div>
	</div><!-- /.ew-extended-search -->
</div><!-- /.ew-search-panel -->
</form>
<?php } ?>
<?php } ?>
<?php $transrecords_list->showPageHeader(); ?>
<?php
$transrecords_list->showMessage();
?>
<?php if ($transrecords_list->TotalRecords > 0 || $transrecords->CurrentAction) { ?>
<div class="card ew-card ew-grid<?php if ($transrecords_list->isAddOrEdit()) { ?> ew-grid-add-edit<?php } ?> transrecords">
<form name="ftransrecordslist" id="ftransrecordslist" class="form-inline ew-form ew-list-form" action="<?php echo CurrentPageName() ?>" method="post">
<?php if ($Page->CheckToken) { ?>
<input type="hidden" name="<?php echo Config("TOKEN_NAME") ?>" value="<?php echo $Page->Token ?>">
<?php } ?>
<input type="hidden" name="t" value="transrecords">
<div id="gmp_transrecords" class="<?php echo ResponsiveTableClass() ?>card-body ew-grid-middle-panel">
<?php if ($transrecords_list->TotalRecords > 0 || $transrecords_list->isGridEdit()) { ?>
<table id="tbl_transrecordslist" class="table ew-table"><!-- .ew-table -->
<thead>
	<tr class="ew-table-header">
<?php

// Header row
$transrecords->RowType = ROWTYPE_HEADER;

// Render list options
$transrecords_list->renderListOptions();

// Render list options (header, left)
$transrecords_list->ListOptions->render("header", "left");
?>
<?php if ($transrecords_list->recid->Visible) { // recid ?>
	<?php if ($transrecords_list->SortUrl($transrecords_list->recid) == "") { ?>
		<th data-name="recid" class="<?php echo $transrecords_list->recid->headerCellClass() ?>"><div id="elh_transrecords_recid" class="transrecords_recid"><div class="ew-table-header-caption"><?php echo $transrecords_list->recid->caption() ?></div></div></th>
	<?php } else { ?>
		<th data-name="recid" class="<?php echo $transrecords_list->recid->headerCellClass() ?>"><div class="ew-pointer" onclick="ew.sort(event, '<?php echo $transrecords_list->SortUrl($transrecords_list->recid) ?>', 1);"><div id="elh_transrecords_recid" class="transrecords_recid">
			<div class="ew-table-header-btn"><span class="ew-table-header-caption"><?php echo $transrecords_list->recid->caption() ?></span><span class="ew-table-header-sort"><?php if ($transrecords_list->recid->getSort() == "ASC") { ?><i class="fas fa-sort-up"></i><?php } elseif ($transrecords_list->recid->getSort() == "DESC") { ?><i class="fas fa-sort-down"></i><?php } ?></span></div>
		</div></div></th>
	<?php } ?>
<?php } ?>
<?php if ($transrecords_list->brokerid->Visible) { // brokerid ?>
	<?php if ($transrecords_list->SortUrl($transrecords_list->brokerid) == "") { ?>
		<th data-name="brokerid" class="<?php echo $transrecords_list->brokerid->headerCellClass() ?>"><div id="elh_transrecords_brokerid" class="transrecords_brokerid"><div class="ew-table-header-caption"><?php echo $transrecords_list->brokerid->caption() ?></div></div></th>
	<?php } else { ?>
		<th data-name="brokerid" class="<?php echo $transrecords_list->brokerid->headerCellClass() ?>"><div class="ew-pointer" onclick="ew.sort(event, '<?php echo $transrecords_list->SortUrl($transrecords_list->brokerid) ?>', 1);"><div id="elh_transrecords_brokerid" class="transrecords_brokerid">
			<div class="ew-table-header-btn"><span class="ew-table-header-caption"><?php echo $transrecords_list->brokerid->caption() ?></span><span class="ew-table-header-sort"><?php if ($transrecords_list->brokerid->getSort() == "ASC") { ?><i class="fas fa-sort-up"></i><?php } elseif ($transrecords_list->brokerid->getSort() == "DESC") { ?><i class="fas fa-sort-down"></i><?php } ?></span></div>
		</div></div></th>
	<?php } ?>
<?php } ?>
<?php if ($transrecords_list->customeracctno->Visible) { // customeracctno ?>
	<?php if ($transrecords_list->SortUrl($transrecords_list->customeracctno) == "") { ?>
		<th data-name="customeracctno" class="<?php echo $transrecords_list->customeracctno->headerCellClass() ?>"><div id="elh_transrecords_customeracctno" class="transrecords_customeracctno"><div class="ew-table-header-caption"><?php echo $transrecords_list->customeracctno->caption() ?></div></div></th>
	<?php } else { ?>
		<th data-name="customeracctno" class="<?php echo $transrecords_list->customeracctno->headerCellClass() ?>"><div class="ew-pointer" onclick="ew.sort(event, '<?php echo $transrecords_list->SortUrl($transrecords_list->customeracctno) ?>', 1);"><div id="elh_transrecords_customeracctno" class="transrecords_customeracctno">
			<div class="ew-table-header-btn"><span class="ew-table-header-caption"><?php echo $transrecords_list->customeracctno->caption() ?><?php echo $Language->phrase("SrchLegend") ?></span><span class="ew-table-header-sort"><?php if ($transrecords_list->customeracctno->getSort() == "ASC") { ?><i class="fas fa-sort-up"></i><?php } elseif ($transrecords_list->customeracctno->getSort() == "DESC") { ?><i class="fas fa-sort-down"></i><?php } ?></span></div>
		</div></div></th>
	<?php } ?>
<?php } ?>
<?php if ($transrecords_list->currcode->Visible) { // currcode ?>
	<?php if ($transrecords_list->SortUrl($transrecords_list->currcode) == "") { ?>
		<th data-name="currcode" class="<?php echo $transrecords_list->currcode->headerCellClass() ?>"><div id="elh_transrecords_currcode" class="transrecords_currcode"><div class="ew-table-header-caption"><?php echo $transrecords_list->currcode->caption() ?></div></div></th>
	<?php } else { ?>
		<th data-name="currcode" class="<?php echo $transrecords_list->currcode->headerCellClass() ?>"><div class="ew-pointer" onclick="ew.sort(event, '<?php echo $transrecords_list->SortUrl($transrecords_list->currcode) ?>', 1);"><div id="elh_transrecords_currcode" class="transrecords_currcode">
			<div class="ew-table-header-btn"><span class="ew-table-header-caption"><?php echo $transrecords_list->currcode->caption() ?><?php echo $Language->phrase("SrchLegend") ?></span><span class="ew-table-header-sort"><?php if ($transrecords_list->currcode->getSort() == "ASC") { ?><i class="fas fa-sort-up"></i><?php } elseif ($transrecords_list->currcode->getSort() == "DESC") { ?><i class="fas fa-sort-down"></i><?php } ?></span></div>
		</div></div></th>
	<?php } ?>
<?php } ?>
<?php if ($transrecords_list->amount->Visible) { // amount ?>
	<?php if ($transrecords_list->SortUrl($transrecords_list->amount) == "") { ?>
		<th data-name="amount" class="<?php echo $transrecords_list->amount->headerCellClass() ?>"><div id="elh_transrecords_amount" class="transrecords_amount"><div class="ew-table-header-caption"><?php echo $transrecords_list->amount->caption() ?></div></div></th>
	<?php } else { ?>
		<th data-name="amount" class="<?php echo $transrecords_list->amount->headerCellClass() ?>"><div class="ew-pointer" onclick="ew.sort(event, '<?php echo $transrecords_list->SortUrl($transrecords_list->amount) ?>', 1);"><div id="elh_transrecords_amount" class="transrecords_amount">
			<div class="ew-table-header-btn"><span class="ew-table-header-caption"><?php echo $transrecords_list->amount->caption() ?></span><span class="ew-table-header-sort"><?php if ($transrecords_list->amount->getSort() == "ASC") { ?><i class="fas fa-sort-up"></i><?php } elseif ($transrecords_list->amount->getSort() == "DESC") { ?><i class="fas fa-sort-down"></i><?php } ?></span></div>
		</div></div></th>
	<?php } ?>
<?php } ?>
<?php if ($transrecords_list->balance->Visible) { // balance ?>
	<?php if ($transrecords_list->SortUrl($transrecords_list->balance) == "") { ?>
		<th data-name="balance" class="<?php echo $transrecords_list->balance->headerCellClass() ?>"><div id="elh_transrecords_balance" class="transrecords_balance"><div class="ew-table-header-caption"><?php echo $transrecords_list->balance->caption() ?></div></div></th>
	<?php } else { ?>
		<th data-name="balance" class="<?php echo $transrecords_list->balance->headerCellClass() ?>"><div class="ew-pointer" onclick="ew.sort(event, '<?php echo $transrecords_list->SortUrl($transrecords_list->balance) ?>', 1);"><div id="elh_transrecords_balance" class="transrecords_balance">
			<div class="ew-table-header-btn"><span class="ew-table-header-caption"><?php echo $transrecords_list->balance->caption() ?></span><span class="ew-table-header-sort"><?php if ($transrecords_list->balance->getSort() == "ASC") { ?><i class="fas fa-sort-up"></i><?php } elseif ($transrecords_list->balance->getSort() == "DESC") { ?><i class="fas fa-sort-down"></i><?php } ?></span></div>
		</div></div></th>
	<?php } ?>
<?php } ?>
<?php if ($transrecords_list->success->Visible) { // success ?>
	<?php if ($transrecords_list->SortUrl($transrecords_list->success) == "") { ?>
		<th data-name="success" class="<?php echo $transrecords_list->success->headerCellClass() ?>"><div id="elh_transrecords_success" class="transrecords_success"><div class="ew-table-header-caption"><?php echo $transrecords_list->success->caption() ?></div></div></th>
	<?php } else { ?>
		<th data-name="success" class="<?php echo $transrecords_list->success->headerCellClass() ?>"><div class="ew-pointer" onclick="ew.sort(event, '<?php echo $transrecords_list->SortUrl($transrecords_list->success) ?>', 1);"><div id="elh_transrecords_success" class="transrecords_success">
			<div class="ew-table-header-btn"><span class="ew-table-header-caption"><?php echo $transrecords_list->success->caption() ?></span><span class="ew-table-header-sort"><?php if ($transrecords_list->success->getSort() == "ASC") { ?><i class="fas fa-sort-up"></i><?php } elseif ($transrecords_list->success->getSort() == "DESC") { ?><i class="fas fa-sort-down"></i><?php } ?></span></div>
		</div></div></th>
	<?php } ?>
<?php } ?>
<?php if ($transrecords_list->transdate->Visible) { // transdate ?>
	<?php if ($transrecords_list->SortUrl($transrecords_list->transdate) == "") { ?>
		<th data-name="transdate" class="<?php echo $transrecords_list->transdate->headerCellClass() ?>"><div id="elh_transrecords_transdate" class="transrecords_transdate"><div class="ew-table-header-caption"><?php echo $transrecords_list->transdate->caption() ?></div></div></th>
	<?php } else { ?>
		<th data-name="transdate" class="<?php echo $transrecords_list->transdate->headerCellClass() ?>"><div class="ew-pointer" onclick="ew.sort(event, '<?php echo $transrecords_list->SortUrl($transrecords_list->transdate) ?>', 1);"><div id="elh_transrecords_transdate" class="transrecords_transdate">
			<div class="ew-table-header-btn"><span class="ew-table-header-caption"><?php echo $transrecords_list->transdate->caption() ?></span><span class="ew-table-header-sort"><?php if ($transrecords_list->transdate->getSort() == "ASC") { ?><i class="fas fa-sort-up"></i><?php } elseif ($transrecords_list->transdate->getSort() == "DESC") { ?><i class="fas fa-sort-down"></i><?php } ?></span></div>
		</div></div></th>
	<?php } ?>
<?php } ?>
<?php if ($transrecords_list->_userid->Visible) { // userid ?>
	<?php if ($transrecords_list->SortUrl($transrecords_list->_userid) == "") { ?>
		<th data-name="_userid" class="<?php echo $transrecords_list->_userid->headerCellClass() ?>"><div id="elh_transrecords__userid" class="transrecords__userid"><div class="ew-table-header-caption"><?php echo $transrecords_list->_userid->caption() ?></div></div></th>
	<?php } else { ?>
		<th data-name="_userid" class="<?php echo $transrecords_list->_userid->headerCellClass() ?>"><div class="ew-pointer" onclick="ew.sort(event, '<?php echo $transrecords_list->SortUrl($transrecords_list->_userid) ?>', 1);"><div id="elh_transrecords__userid" class="transrecords__userid">
			<div class="ew-table-header-btn"><span class="ew-table-header-caption"><?php echo $transrecords_list->_userid->caption() ?></span><span class="ew-table-header-sort"><?php if ($transrecords_list->_userid->getSort() == "ASC") { ?><i class="fas fa-sort-up"></i><?php } elseif ($transrecords_list->_userid->getSort() == "DESC") { ?><i class="fas fa-sort-down"></i><?php } ?></span></div>
		</div></div></th>
	<?php } ?>
<?php } ?>
<?php if ($transrecords_list->transtype->Visible) { // transtype ?>
	<?php if ($transrecords_list->SortUrl($transrecords_list->transtype) == "") { ?>
		<th data-name="transtype" class="<?php echo $transrecords_list->transtype->headerCellClass() ?>"><div id="elh_transrecords_transtype" class="transrecords_transtype"><div class="ew-table-header-caption"><?php echo $transrecords_list->transtype->caption() ?></div></div></th>
	<?php } else { ?>
		<th data-name="transtype" class="<?php echo $transrecords_list->transtype->headerCellClass() ?>"><div class="ew-pointer" onclick="ew.sort(event, '<?php echo $transrecords_list->SortUrl($transrecords_list->transtype) ?>', 1);"><div id="elh_transrecords_transtype" class="transrecords_transtype">
			<div class="ew-table-header-btn"><span class="ew-table-header-caption"><?php echo $transrecords_list->transtype->caption() ?></span><span class="ew-table-header-sort"><?php if ($transrecords_list->transtype->getSort() == "ASC") { ?><i class="fas fa-sort-up"></i><?php } elseif ($transrecords_list->transtype->getSort() == "DESC") { ?><i class="fas fa-sort-down"></i><?php } ?></span></div>
		</div></div></th>
	<?php } ?>
<?php } ?>
<?php if ($transrecords_list->paymentclass1->Visible) { // paymentclass1 ?>
	<?php if ($transrecords_list->SortUrl($transrecords_list->paymentclass1) == "") { ?>
		<th data-name="paymentclass1" class="<?php echo $transrecords_list->paymentclass1->headerCellClass() ?>"><div id="elh_transrecords_paymentclass1" class="transrecords_paymentclass1"><div class="ew-table-header-caption"><?php echo $transrecords_list->paymentclass1->caption() ?></div></div></th>
	<?php } else { ?>
		<th data-name="paymentclass1" class="<?php echo $transrecords_list->paymentclass1->headerCellClass() ?>"><div class="ew-pointer" onclick="ew.sort(event, '<?php echo $transrecords_list->SortUrl($transrecords_list->paymentclass1) ?>', 1);"><div id="elh_transrecords_paymentclass1" class="transrecords_paymentclass1">
			<div class="ew-table-header-btn"><span class="ew-table-header-caption"><?php echo $transrecords_list->paymentclass1->caption() ?><?php echo $Language->phrase("SrchLegend") ?></span><span class="ew-table-header-sort"><?php if ($transrecords_list->paymentclass1->getSort() == "ASC") { ?><i class="fas fa-sort-up"></i><?php } elseif ($transrecords_list->paymentclass1->getSort() == "DESC") { ?><i class="fas fa-sort-down"></i><?php } ?></span></div>
		</div></div></th>
	<?php } ?>
<?php } ?>
<?php

// Render list options (header, right)
$transrecords_list->ListOptions->render("header", "right");
?>
	</tr>
</thead>
<tbody>
<?php
if ($transrecords_list->ExportAll && $transrecords_list->isExport()) {
	$transrecords_list->StopRecord = $transrecords_list->TotalRecords;
} else {

	// Set the last record to display
	if ($transrecords_list->TotalRecords > $transrecords_list->StartRecord + $transrecords_list->DisplayRecords - 1)
		$transrecords_list->StopRecord = $transrecords_list->StartRecord + $transrecords_list->DisplayRecords - 1;
	else
		$transrecords_list->StopRecord = $transrecords_list->TotalRecords;
}
$transrecords_list->RecordCount = $transrecords_list->StartRecord - 1;
if ($transrecords_list->Recordset && !$transrecords_list->Recordset->EOF) {
	$transrecords_list->Recordset->moveFirst();
	$selectLimit = $transrecords_list->UseSelectLimit;
	if (!$selectLimit && $transrecords_list->StartRecord > 1)
		$transrecords_list->Recordset->move($transrecords_list->StartRecord - 1);
} elseif (!$transrecords->AllowAddDeleteRow && $transrecords_list->StopRecord == 0) {
	$transrecords_list->StopRecord = $transrecords->GridAddRowCount;
}

// Initialize aggregate
$transrecords->RowType = ROWTYPE_AGGREGATEINIT;
$transrecords->resetAttributes();
$transrecords_list->renderRow();
while ($transrecords_list->RecordCount < $transrecords_list->StopRecord) {
	$transrecords_list->RecordCount++;
	if ($transrecords_list->RecordCount >= $transrecords_list->StartRecord) {
		$transrecords_list->RowCount++;

		// Set up key count
		$transrecords_list->KeyCount = $transrecords_list->RowIndex;

		// Init row class and style
		$transrecords->resetAttributes();
		$transrecords->CssClass = "";
		if ($transrecords_list->isGridAdd()) {
		} else {
			$transrecords_list->loadRowValues($transrecords_list->Recordset); // Load row values
		}
		$transrecords->RowType = ROWTYPE_VIEW; // Render view

		// Set up row id / data-rowindex
		$transrecords->RowAttrs->merge(["data-rowindex" => $transrecords_list->RowCount, "id" => "r" . $transrecords_list->RowCount . "_transrecords", "data-rowtype" => $transrecords->RowType]);

		// Render row
		$transrecords_list->renderRow();

		// Render list options
		$transrecords_list->renderListOptions();
?>
	<tr <?php echo $transrecords->rowAttributes() ?>>
<?php

// Render list options (body, left)
$transrecords_list->ListOptions->render("body", "left", $transrecords_list->RowCount);
?>
	<?php if ($transrecords_list->recid->Visible) { // recid ?>
		<td data-name="recid" <?php echo $transrecords_list->recid->cellAttributes() ?>>
<span id="el<?php echo $transrecords_list->RowCount ?>_transrecords_recid">
<span<?php echo $transrecords_list->recid->viewAttributes() ?>><?php echo $transrecords_list->recid->getViewValue() ?></span>
</span>
</td>
	<?php } ?>
	<?php if ($transrecords_list->brokerid->Visible) { // brokerid ?>
		<td data-name="brokerid" <?php echo $transrecords_list->brokerid->cellAttributes() ?>>
<span id="el<?php echo $transrecords_list->RowCount ?>_transrecords_brokerid">
<span<?php echo $transrecords_list->brokerid->viewAttributes() ?>><?php echo $transrecords_list->brokerid->getViewValue() ?></span>
</span>
</td>
	<?php } ?>
	<?php if ($transrecords_list->customeracctno->Visible) { // customeracctno ?>
		<td data-name="customeracctno" <?php echo $transrecords_list->customeracctno->cellAttributes() ?>>
<span id="el<?php echo $transrecords_list->RowCount ?>_transrecords_customeracctno">
<span<?php echo $transrecords_list->customeracctno->viewAttributes() ?>><?php echo $transrecords_list->customeracctno->getViewValue() ?></span>
</span>
</td>
	<?php } ?>
	<?php if ($transrecords_list->currcode->Visible) { // currcode ?>
		<td data-name="currcode" <?php echo $transrecords_list->currcode->cellAttributes() ?>>
<span id="el<?php echo $transrecords_list->RowCount ?>_transrecords_currcode">
<span<?php echo $transrecords_list->currcode->viewAttributes() ?>><?php echo $transrecords_list->currcode->getViewValue() ?></span>
</span>
</td>
	<?php } ?>
	<?php if ($transrecords_list->amount->Visible) { // amount ?>
		<td data-name="amount" <?php echo $transrecords_list->amount->cellAttributes() ?>>
<span id="el<?php echo $transrecords_list->RowCount ?>_transrecords_amount">
<span<?php echo $transrecords_list->amount->viewAttributes() ?>><?php echo $transrecords_list->amount->getViewValue() ?></span>
</span>
</td>
	<?php } ?>
	<?php if ($transrecords_list->balance->Visible) { // balance ?>
		<td data-name="balance" <?php echo $transrecords_list->balance->cellAttributes() ?>>
<span id="el<?php echo $transrecords_list->RowCount ?>_transrecords_balance">
<span<?php echo $transrecords_list->balance->viewAttributes() ?>><?php echo $transrecords_list->balance->getViewValue() ?></span>
</span>
</td>
	<?php } ?>
	<?php if ($transrecords_list->success->Visible) { // success ?>
		<td data-name="success" <?php echo $transrecords_list->success->cellAttributes() ?>>
<span id="el<?php echo $transrecords_list->RowCount ?>_transrecords_success">
<span<?php echo $transrecords_list->success->viewAttributes() ?>><?php echo $transrecords_list->success->getViewValue() ?></span>
</span>
</td>
	<?php } ?>
	<?php if ($transrecords_list->transdate->Visible) { // transdate ?>
		<td data-name="transdate" <?php echo $transrecords_list->transdate->cellAttributes() ?>>
<span id="el<?php echo $transrecords_list->RowCount ?>_transrecords_transdate">
<span<?php echo $transrecords_list->transdate->viewAttributes() ?>><?php echo $transrecords_list->transdate->getViewValue() ?></span>
</span>
</td>
	<?php } ?>
	<?php if ($transrecords_list->_userid->Visible) { // userid ?>
		<td data-name="_userid" <?php echo $transrecords_list->_userid->cellAttributes() ?>>
<span id="el<?php echo $transrecords_list->RowCount ?>_transrecords__userid">
<span<?php echo $transrecords_list->_userid->viewAttributes() ?>><?php echo $transrecords_list->_userid->getViewValue() ?></span>
</span>
</td>
	<?php } ?>
	<?php if ($transrecords_list->transtype->Visible) { // transtype ?>
		<td data-name="transtype" <?php echo $transrecords_list->transtype->cellAttributes() ?>>
<span id="el<?php echo $transrecords_list->RowCount ?>_transrecords_transtype">
<span<?php echo $transrecords_list->transtype->viewAttributes() ?>><?php echo $transrecords_list->transtype->getViewValue() ?></span>
</span>
</td>
	<?php } ?>
	<?php if ($transrecords_list->paymentclass1->Visible) { // paymentclass1 ?>
		<td data-name="paymentclass1" <?php echo $transrecords_list->paymentclass1->cellAttributes() ?>>
<span id="el<?php echo $transrecords_list->RowCount ?>_transrecords_paymentclass1">
<span<?php echo $transrecords_list->paymentclass1->viewAttributes() ?>><?php echo $transrecords_list->paymentclass1->getViewValue() ?></span>
</span>
</td>
	<?php } ?>
<?php

// Render list options (body, right)
$transrecords_list->ListOptions->render("body", "right", $transrecords_list->RowCount);
?>
	</tr>
<?php
	}
	if (!$transrecords_list->isGridAdd())
		$transrecords_list->Recordset->moveNext();
}
?>
</tbody>
</table><!-- /.ew-table -->
<?php } ?>
</div><!-- /.ew-grid-middle-panel -->
<?php if (!$transrecords->CurrentAction) { ?>
<input type="hidden" name="action" id="action" value="">
<?php } ?>
</form><!-- /.ew-list-form -->
<?php

// Close recordset
if ($transrecords_list->Recordset)
	$transrecords_list->Recordset->Close();
?>
<?php if (!$transrecords_list->isExport()) { ?>
<div class="card-footer ew-grid-lower-panel">
<?php if (!$transrecords_list->isGridAdd()) { ?>
<form name="ew-pager-form" class="form-inline ew-form ew-pager-form" action="<?php echo CurrentPageName() ?>">
<?php echo $transrecords_list->Pager->render() ?>
</form>
<?php } ?>
<div class="ew-list-other-options">
<?php $transrecords_list->OtherOptions->render("body", "bottom") ?>
</div>
<div class="clearfix"></div>
</div>
<?php } ?>
</div><!-- /.ew-grid -->
<?php } ?>
<?php if ($transrecords_list->TotalRecords == 0 && !$transrecords->CurrentAction) { // Show other options ?>
<div class="ew-list-other-options">
<?php $transrecords_list->OtherOptions->render("body") ?>
</div>
<div class="clearfix"></div>
<?php } ?>
<?php
$transrecords_list->showPageFooter();
if (Config("DEBUG"))
	echo GetDebugMessage();
?>
<?php if (!$transrecords_list->isExport()) { ?>
<script>
loadjs.ready("load", function() {

	// Startup script
	// Write your table-specific startup script here
	// console.log("page loaded");

});
</script>
<?php } ?>
<?php include_once "footer.php"; ?>
<?php
$transrecords_list->terminate();
?>