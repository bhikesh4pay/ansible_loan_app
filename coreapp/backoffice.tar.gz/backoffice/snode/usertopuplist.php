<?php
namespace PHPMaker2020\_4payadmin;

// Autoload
include_once "autoload.php";

// Session
if (session_status() !== PHP_SESSION_ACTIVE)
	\Delight\Cookie\Session::start(Config("COOKIE_SAMESITE")); // Init session data

// Output buffering
ob_start();
?>
<?php

// Write header
WriteHeader(FALSE);

// Create page object
$usertopup_list = new usertopup_list();

// Run the page
$usertopup_list->run();

// Setup login status
SetupLoginStatus();
SetClientVar("login", LoginStatus());

// Global Page Rendering event (in userfn*.php)
Page_Rendering();

// Page Rendering event
$usertopup_list->Page_Render();
?>
<?php include_once "header.php"; ?>
<?php if (!$usertopup_list->isExport()) { ?>
<script>
var fusertopuplist, currentPageID;
loadjs.ready("head", function() {

	// Form object
	currentPageID = ew.PAGE_ID = "list";
	fusertopuplist = currentForm = new ew.Form("fusertopuplist", "list");
	fusertopuplist.formKeyCountName = '<?php echo $usertopup_list->FormKeyCountName ?>';
	loadjs.done("fusertopuplist");
});
var fusertopuplistsrch;
loadjs.ready("head", function() {

	// Form object for search
	fusertopuplistsrch = currentSearchForm = new ew.Form("fusertopuplistsrch");

	// Dynamic selection lists
	// Filters

	fusertopuplistsrch.filterList = <?php echo $usertopup_list->getFilterList() ?>;

	// Init search panel as collapsed
	fusertopuplistsrch.initSearchPanel = true;
	loadjs.done("fusertopuplistsrch");
});
</script>
<style type="text/css">
.ew-table-preview-row { /* main table preview row color */
	background-color: #FFFFFF; /* preview row color */
}
.ew-table-preview-row .ew-grid {
	display: table;
}
</style>
<div id="ew-preview" class="d-none"><!-- preview -->
	<div class="ew-nav-tabs"><!-- .ew-nav-tabs -->
		<ul class="nav nav-tabs"></ul>
		<div class="tab-content"><!-- .tab-content -->
			<div class="tab-pane fade active show"></div>
		</div><!-- /.tab-content -->
	</div><!-- /.ew-nav-tabs -->
</div><!-- /preview -->
<script>
loadjs.ready("head", function() {
	ew.PREVIEW_PLACEMENT = ew.CSS_FLIP ? "right" : "left";
	ew.PREVIEW_SINGLE_ROW = false;
	ew.PREVIEW_OVERLAY = false;
	loadjs("js/ewpreview.js", "preview");
});
</script>
<script>
loadjs.ready("head", function() {

	// Client script
	// Write your client script here, no need to add script tags.

});
</script>
<?php } ?>
<?php if (!$usertopup_list->isExport()) { ?>
<div class="btn-toolbar ew-toolbar">
<?php if ($usertopup_list->TotalRecords > 0 && $usertopup_list->ExportOptions->visible()) { ?>
<?php $usertopup_list->ExportOptions->render("body") ?>
<?php } ?>
<?php if ($usertopup_list->ImportOptions->visible()) { ?>
<?php $usertopup_list->ImportOptions->render("body") ?>
<?php } ?>
<?php if ($usertopup_list->SearchOptions->visible()) { ?>
<?php $usertopup_list->SearchOptions->render("body") ?>
<?php } ?>
<?php if ($usertopup_list->FilterOptions->visible()) { ?>
<?php $usertopup_list->FilterOptions->render("body") ?>
<?php } ?>
<div class="clearfix"></div>
</div>
<?php } ?>
<?php
$usertopup_list->renderOtherOptions();
?>
<?php $usertopup_list->showPageHeader(); ?>
<?php
$usertopup_list->showMessage();
?>
<?php if ($usertopup_list->TotalRecords > 0 || $usertopup->CurrentAction) { ?>
<div class="card ew-card ew-grid<?php if ($usertopup_list->isAddOrEdit()) { ?> ew-grid-add-edit<?php } ?> usertopup">
<form name="fusertopuplist" id="fusertopuplist" class="form-inline ew-form ew-list-form" action="<?php echo CurrentPageName() ?>" method="post">
<?php if ($Page->CheckToken) { ?>
<input type="hidden" name="<?php echo Config("TOKEN_NAME") ?>" value="<?php echo $Page->Token ?>">
<?php } ?>
<input type="hidden" name="t" value="usertopup">
<div id="gmp_usertopup" class="<?php echo ResponsiveTableClass() ?>card-body ew-grid-middle-panel">
<?php if ($usertopup_list->TotalRecords > 0 || $usertopup_list->isGridEdit()) { ?>
<table id="tbl_usertopuplist" class="table ew-table"><!-- .ew-table -->
<thead>
	<tr class="ew-table-header">
<?php

// Header row
$usertopup->RowType = ROWTYPE_HEADER;

// Render list options
$usertopup_list->renderListOptions();

// Render list options (header, left)
$usertopup_list->ListOptions->render("header", "left");
?>
<?php if ($usertopup_list->topupid->Visible) { // topupid ?>
	<?php if ($usertopup_list->SortUrl($usertopup_list->topupid) == "") { ?>
		<th data-name="topupid" class="<?php echo $usertopup_list->topupid->headerCellClass() ?>"><div id="elh_usertopup_topupid" class="usertopup_topupid"><div class="ew-table-header-caption"><?php echo $usertopup_list->topupid->caption() ?></div></div></th>
	<?php } else { ?>
		<th data-name="topupid" class="<?php echo $usertopup_list->topupid->headerCellClass() ?>"><div class="ew-pointer" onclick="ew.sort(event, '<?php echo $usertopup_list->SortUrl($usertopup_list->topupid) ?>', 1);"><div id="elh_usertopup_topupid" class="usertopup_topupid">
			<div class="ew-table-header-btn"><span class="ew-table-header-caption"><?php echo $usertopup_list->topupid->caption() ?></span><span class="ew-table-header-sort"><?php if ($usertopup_list->topupid->getSort() == "ASC") { ?><i class="fas fa-sort-up"></i><?php } elseif ($usertopup_list->topupid->getSort() == "DESC") { ?><i class="fas fa-sort-down"></i><?php } ?></span></div>
		</div></div></th>
	<?php } ?>
<?php } ?>
<?php if ($usertopup_list->status->Visible) { // status ?>
	<?php if ($usertopup_list->SortUrl($usertopup_list->status) == "") { ?>
		<th data-name="status" class="<?php echo $usertopup_list->status->headerCellClass() ?>"><div id="elh_usertopup_status" class="usertopup_status"><div class="ew-table-header-caption"><?php echo $usertopup_list->status->caption() ?></div></div></th>
	<?php } else { ?>
		<th data-name="status" class="<?php echo $usertopup_list->status->headerCellClass() ?>"><div class="ew-pointer" onclick="ew.sort(event, '<?php echo $usertopup_list->SortUrl($usertopup_list->status) ?>', 1);"><div id="elh_usertopup_status" class="usertopup_status">
			<div class="ew-table-header-btn"><span class="ew-table-header-caption"><?php echo $usertopup_list->status->caption() ?></span><span class="ew-table-header-sort"><?php if ($usertopup_list->status->getSort() == "ASC") { ?><i class="fas fa-sort-up"></i><?php } elseif ($usertopup_list->status->getSort() == "DESC") { ?><i class="fas fa-sort-down"></i><?php } ?></span></div>
		</div></div></th>
	<?php } ?>
<?php } ?>
<?php if ($usertopup_list->piid->Visible) { // piid ?>
	<?php if ($usertopup_list->SortUrl($usertopup_list->piid) == "") { ?>
		<th data-name="piid" class="<?php echo $usertopup_list->piid->headerCellClass() ?>"><div id="elh_usertopup_piid" class="usertopup_piid"><div class="ew-table-header-caption"><?php echo $usertopup_list->piid->caption() ?></div></div></th>
	<?php } else { ?>
		<th data-name="piid" class="<?php echo $usertopup_list->piid->headerCellClass() ?>"><div class="ew-pointer" onclick="ew.sort(event, '<?php echo $usertopup_list->SortUrl($usertopup_list->piid) ?>', 1);"><div id="elh_usertopup_piid" class="usertopup_piid">
			<div class="ew-table-header-btn"><span class="ew-table-header-caption"><?php echo $usertopup_list->piid->caption() ?></span><span class="ew-table-header-sort"><?php if ($usertopup_list->piid->getSort() == "ASC") { ?><i class="fas fa-sort-up"></i><?php } elseif ($usertopup_list->piid->getSort() == "DESC") { ?><i class="fas fa-sort-down"></i><?php } ?></span></div>
		</div></div></th>
	<?php } ?>
<?php } ?>
<?php if ($usertopup_list->requesttime->Visible) { // requesttime ?>
	<?php if ($usertopup_list->SortUrl($usertopup_list->requesttime) == "") { ?>
		<th data-name="requesttime" class="<?php echo $usertopup_list->requesttime->headerCellClass() ?>"><div id="elh_usertopup_requesttime" class="usertopup_requesttime"><div class="ew-table-header-caption"><?php echo $usertopup_list->requesttime->caption() ?></div></div></th>
	<?php } else { ?>
		<th data-name="requesttime" class="<?php echo $usertopup_list->requesttime->headerCellClass() ?>"><div class="ew-pointer" onclick="ew.sort(event, '<?php echo $usertopup_list->SortUrl($usertopup_list->requesttime) ?>', 1);"><div id="elh_usertopup_requesttime" class="usertopup_requesttime">
			<div class="ew-table-header-btn"><span class="ew-table-header-caption"><?php echo $usertopup_list->requesttime->caption() ?></span><span class="ew-table-header-sort"><?php if ($usertopup_list->requesttime->getSort() == "ASC") { ?><i class="fas fa-sort-up"></i><?php } elseif ($usertopup_list->requesttime->getSort() == "DESC") { ?><i class="fas fa-sort-down"></i><?php } ?></span></div>
		</div></div></th>
	<?php } ?>
<?php } ?>
<?php if ($usertopup_list->paidtime->Visible) { // paidtime ?>
	<?php if ($usertopup_list->SortUrl($usertopup_list->paidtime) == "") { ?>
		<th data-name="paidtime" class="<?php echo $usertopup_list->paidtime->headerCellClass() ?>"><div id="elh_usertopup_paidtime" class="usertopup_paidtime"><div class="ew-table-header-caption"><?php echo $usertopup_list->paidtime->caption() ?></div></div></th>
	<?php } else { ?>
		<th data-name="paidtime" class="<?php echo $usertopup_list->paidtime->headerCellClass() ?>"><div class="ew-pointer" onclick="ew.sort(event, '<?php echo $usertopup_list->SortUrl($usertopup_list->paidtime) ?>', 1);"><div id="elh_usertopup_paidtime" class="usertopup_paidtime">
			<div class="ew-table-header-btn"><span class="ew-table-header-caption"><?php echo $usertopup_list->paidtime->caption() ?></span><span class="ew-table-header-sort"><?php if ($usertopup_list->paidtime->getSort() == "ASC") { ?><i class="fas fa-sort-up"></i><?php } elseif ($usertopup_list->paidtime->getSort() == "DESC") { ?><i class="fas fa-sort-down"></i><?php } ?></span></div>
		</div></div></th>
	<?php } ?>
<?php } ?>
<?php if ($usertopup_list->fulfillmenttime->Visible) { // fulfillmenttime ?>
	<?php if ($usertopup_list->SortUrl($usertopup_list->fulfillmenttime) == "") { ?>
		<th data-name="fulfillmenttime" class="<?php echo $usertopup_list->fulfillmenttime->headerCellClass() ?>"><div id="elh_usertopup_fulfillmenttime" class="usertopup_fulfillmenttime"><div class="ew-table-header-caption"><?php echo $usertopup_list->fulfillmenttime->caption() ?></div></div></th>
	<?php } else { ?>
		<th data-name="fulfillmenttime" class="<?php echo $usertopup_list->fulfillmenttime->headerCellClass() ?>"><div class="ew-pointer" onclick="ew.sort(event, '<?php echo $usertopup_list->SortUrl($usertopup_list->fulfillmenttime) ?>', 1);"><div id="elh_usertopup_fulfillmenttime" class="usertopup_fulfillmenttime">
			<div class="ew-table-header-btn"><span class="ew-table-header-caption"><?php echo $usertopup_list->fulfillmenttime->caption() ?></span><span class="ew-table-header-sort"><?php if ($usertopup_list->fulfillmenttime->getSort() == "ASC") { ?><i class="fas fa-sort-up"></i><?php } elseif ($usertopup_list->fulfillmenttime->getSort() == "DESC") { ?><i class="fas fa-sort-down"></i><?php } ?></span></div>
		</div></div></th>
	<?php } ?>
<?php } ?>
<?php if ($usertopup_list->_userid->Visible) { // userid ?>
	<?php if ($usertopup_list->SortUrl($usertopup_list->_userid) == "") { ?>
		<th data-name="_userid" class="<?php echo $usertopup_list->_userid->headerCellClass() ?>"><div id="elh_usertopup__userid" class="usertopup__userid"><div class="ew-table-header-caption"><?php echo $usertopup_list->_userid->caption() ?></div></div></th>
	<?php } else { ?>
		<th data-name="_userid" class="<?php echo $usertopup_list->_userid->headerCellClass() ?>"><div class="ew-pointer" onclick="ew.sort(event, '<?php echo $usertopup_list->SortUrl($usertopup_list->_userid) ?>', 1);"><div id="elh_usertopup__userid" class="usertopup__userid">
			<div class="ew-table-header-btn"><span class="ew-table-header-caption"><?php echo $usertopup_list->_userid->caption() ?></span><span class="ew-table-header-sort"><?php if ($usertopup_list->_userid->getSort() == "ASC") { ?><i class="fas fa-sort-up"></i><?php } elseif ($usertopup_list->_userid->getSort() == "DESC") { ?><i class="fas fa-sort-down"></i><?php } ?></span></div>
		</div></div></th>
	<?php } ?>
<?php } ?>
<?php

// Render list options (header, right)
$usertopup_list->ListOptions->render("header", "right");
?>
	</tr>
</thead>
<tbody>
<?php
if ($usertopup_list->ExportAll && $usertopup_list->isExport()) {
	$usertopup_list->StopRecord = $usertopup_list->TotalRecords;
} else {

	// Set the last record to display
	if ($usertopup_list->TotalRecords > $usertopup_list->StartRecord + $usertopup_list->DisplayRecords - 1)
		$usertopup_list->StopRecord = $usertopup_list->StartRecord + $usertopup_list->DisplayRecords - 1;
	else
		$usertopup_list->StopRecord = $usertopup_list->TotalRecords;
}
$usertopup_list->RecordCount = $usertopup_list->StartRecord - 1;
if ($usertopup_list->Recordset && !$usertopup_list->Recordset->EOF) {
	$usertopup_list->Recordset->moveFirst();
	$selectLimit = $usertopup_list->UseSelectLimit;
	if (!$selectLimit && $usertopup_list->StartRecord > 1)
		$usertopup_list->Recordset->move($usertopup_list->StartRecord - 1);
} elseif (!$usertopup->AllowAddDeleteRow && $usertopup_list->StopRecord == 0) {
	$usertopup_list->StopRecord = $usertopup->GridAddRowCount;
}

// Initialize aggregate
$usertopup->RowType = ROWTYPE_AGGREGATEINIT;
$usertopup->resetAttributes();
$usertopup_list->renderRow();
while ($usertopup_list->RecordCount < $usertopup_list->StopRecord) {
	$usertopup_list->RecordCount++;
	if ($usertopup_list->RecordCount >= $usertopup_list->StartRecord) {
		$usertopup_list->RowCount++;

		// Set up key count
		$usertopup_list->KeyCount = $usertopup_list->RowIndex;

		// Init row class and style
		$usertopup->resetAttributes();
		$usertopup->CssClass = "";
		if ($usertopup_list->isGridAdd()) {
		} else {
			$usertopup_list->loadRowValues($usertopup_list->Recordset); // Load row values
		}
		$usertopup->RowType = ROWTYPE_VIEW; // Render view

		// Set up row id / data-rowindex
		$usertopup->RowAttrs->merge(["data-rowindex" => $usertopup_list->RowCount, "id" => "r" . $usertopup_list->RowCount . "_usertopup", "data-rowtype" => $usertopup->RowType]);

		// Render row
		$usertopup_list->renderRow();

		// Render list options
		$usertopup_list->renderListOptions();
?>
	<tr <?php echo $usertopup->rowAttributes() ?>>
<?php

// Render list options (body, left)
$usertopup_list->ListOptions->render("body", "left", $usertopup_list->RowCount);
?>
	<?php if ($usertopup_list->topupid->Visible) { // topupid ?>
		<td data-name="topupid" <?php echo $usertopup_list->topupid->cellAttributes() ?>>
<span id="el<?php echo $usertopup_list->RowCount ?>_usertopup_topupid">
<span<?php echo $usertopup_list->topupid->viewAttributes() ?>><?php echo $usertopup_list->topupid->getViewValue() ?></span>
</span>
</td>
	<?php } ?>
	<?php if ($usertopup_list->status->Visible) { // status ?>
		<td data-name="status" <?php echo $usertopup_list->status->cellAttributes() ?>>
<span id="el<?php echo $usertopup_list->RowCount ?>_usertopup_status">
<span<?php echo $usertopup_list->status->viewAttributes() ?>><?php echo $usertopup_list->status->getViewValue() ?></span>
</span>
</td>
	<?php } ?>
	<?php if ($usertopup_list->piid->Visible) { // piid ?>
		<td data-name="piid" <?php echo $usertopup_list->piid->cellAttributes() ?>>
<span id="el<?php echo $usertopup_list->RowCount ?>_usertopup_piid">
<span<?php echo $usertopup_list->piid->viewAttributes() ?>><?php echo $usertopup_list->piid->getViewValue() ?></span>
</span>
</td>
	<?php } ?>
	<?php if ($usertopup_list->requesttime->Visible) { // requesttime ?>
		<td data-name="requesttime" <?php echo $usertopup_list->requesttime->cellAttributes() ?>>
<span id="el<?php echo $usertopup_list->RowCount ?>_usertopup_requesttime">
<span<?php echo $usertopup_list->requesttime->viewAttributes() ?>><?php echo $usertopup_list->requesttime->getViewValue() ?></span>
</span>
</td>
	<?php } ?>
	<?php if ($usertopup_list->paidtime->Visible) { // paidtime ?>
		<td data-name="paidtime" <?php echo $usertopup_list->paidtime->cellAttributes() ?>>
<span id="el<?php echo $usertopup_list->RowCount ?>_usertopup_paidtime">
<span<?php echo $usertopup_list->paidtime->viewAttributes() ?>><?php echo $usertopup_list->paidtime->getViewValue() ?></span>
</span>
</td>
	<?php } ?>
	<?php if ($usertopup_list->fulfillmenttime->Visible) { // fulfillmenttime ?>
		<td data-name="fulfillmenttime" <?php echo $usertopup_list->fulfillmenttime->cellAttributes() ?>>
<span id="el<?php echo $usertopup_list->RowCount ?>_usertopup_fulfillmenttime">
<span<?php echo $usertopup_list->fulfillmenttime->viewAttributes() ?>><?php echo $usertopup_list->fulfillmenttime->getViewValue() ?></span>
</span>
</td>
	<?php } ?>
	<?php if ($usertopup_list->_userid->Visible) { // userid ?>
		<td data-name="_userid" <?php echo $usertopup_list->_userid->cellAttributes() ?>>
<span id="el<?php echo $usertopup_list->RowCount ?>_usertopup__userid">
<span<?php echo $usertopup_list->_userid->viewAttributes() ?>><?php echo $usertopup_list->_userid->getViewValue() ?></span>
</span>
</td>
	<?php } ?>
<?php

// Render list options (body, right)
$usertopup_list->ListOptions->render("body", "right", $usertopup_list->RowCount);
?>
	</tr>
<?php
	}
	if (!$usertopup_list->isGridAdd())
		$usertopup_list->Recordset->moveNext();
}
?>
</tbody>
</table><!-- /.ew-table -->
<?php } ?>
</div><!-- /.ew-grid-middle-panel -->
<?php if (!$usertopup->CurrentAction) { ?>
<input type="hidden" name="action" id="action" value="">
<?php } ?>
</form><!-- /.ew-list-form -->
<?php

// Close recordset
if ($usertopup_list->Recordset)
	$usertopup_list->Recordset->Close();
?>
<?php if (!$usertopup_list->isExport()) { ?>
<div class="card-footer ew-grid-lower-panel">
<?php if (!$usertopup_list->isGridAdd()) { ?>
<form name="ew-pager-form" class="form-inline ew-form ew-pager-form" action="<?php echo CurrentPageName() ?>">
<?php echo $usertopup_list->Pager->render() ?>
</form>
<?php } ?>
<div class="ew-list-other-options">
<?php $usertopup_list->OtherOptions->render("body", "bottom") ?>
</div>
<div class="clearfix"></div>
</div>
<?php } ?>
</div><!-- /.ew-grid -->
<?php } ?>
<?php if ($usertopup_list->TotalRecords == 0 && !$usertopup->CurrentAction) { // Show other options ?>
<div class="ew-list-other-options">
<?php $usertopup_list->OtherOptions->render("body") ?>
</div>
<div class="clearfix"></div>
<?php } ?>
<?php
$usertopup_list->showPageFooter();
if (Config("DEBUG"))
	echo GetDebugMessage();
?>
<?php if (!$usertopup_list->isExport()) { ?>
<script>
loadjs.ready("load", function() {

	// Startup script
	// Write your table-specific startup script here
	// console.log("page loaded");

});
</script>
<?php } ?>
<?php include_once "footer.php"; ?>
<?php
$usertopup_list->terminate();
?>