<?php
namespace PHPMaker2020\_4payadmin;

// Autoload
include_once "autoload.php";

// Session
if (session_status() !== PHP_SESSION_ACTIVE)
	\Delight\Cookie\Session::start(Config("COOKIE_SAMESITE")); // Init session data

// Output buffering
ob_start();
?>
<?php

// Write header
WriteHeader(FALSE);

// Create page object
$merchant_search = new merchant_search();

// Run the page
$merchant_search->run();

// Setup login status
SetupLoginStatus();
SetClientVar("login", LoginStatus());

// Global Page Rendering event (in userfn*.php)
Page_Rendering();

// Page Rendering event
$merchant_search->Page_Render();
?>
<?php include_once "header.php"; ?>
<script>
var fmerchantsearch, currentPageID;
loadjs.ready("head", function() {

	// Form object for search
	<?php if ($merchant_search->IsModal) { ?>
	fmerchantsearch = currentAdvancedSearchForm = new ew.Form("fmerchantsearch", "search");
	<?php } else { ?>
	fmerchantsearch = currentForm = new ew.Form("fmerchantsearch", "search");
	<?php } ?>
	currentPageID = ew.PAGE_ID = "search";

	// Validate function for search
	fmerchantsearch.validate = function(fobj) {
		if (!this.validateRequired)
			return true; // Ignore validation
		fobj = fobj || this._form;
		var infix = "";
		elm = this.getElements("x" + infix + "__userid");
		if (elm && !ew.checkInteger(elm.value))
			return this.onError(elm, "<?php echo JsEncode($merchant_search->_userid->errorMessage()) ?>");
		elm = this.getElements("x" + infix + "_ratetableid");
		if (elm && !ew.checkInteger(elm.value))
			return this.onError(elm, "<?php echo JsEncode($merchant_search->ratetableid->errorMessage()) ?>");
		elm = this.getElements("x" + infix + "_taxamount");
		if (elm && !ew.checkNumber(elm.value))
			return this.onError(elm, "<?php echo JsEncode($merchant_search->taxamount->errorMessage()) ?>");
		elm = this.getElements("x" + infix + "_returndays");
		if (elm && !ew.checkInteger(elm.value))
			return this.onError(elm, "<?php echo JsEncode($merchant_search->returndays->errorMessage()) ?>");
		elm = this.getElements("x" + infix + "_memberextrafieldsid");
		if (elm && !ew.checkInteger(elm.value))
			return this.onError(elm, "<?php echo JsEncode($merchant_search->memberextrafieldsid->errorMessage()) ?>");
		elm = this.getElements("x" + infix + "_lastupdatedate");
		if (elm && !ew.checkDateDef(elm.value))
			return this.onError(elm, "<?php echo JsEncode($merchant_search->lastupdatedate->errorMessage()) ?>");
		elm = this.getElements("x" + infix + "_withholdingtaxaccount");
		if (elm && !ew.checkInteger(elm.value))
			return this.onError(elm, "<?php echo JsEncode($merchant_search->withholdingtaxaccount->errorMessage()) ?>");
		elm = this.getElements("x" + infix + "_profilevalidationdate");
		if (elm && !ew.checkDateDef(elm.value))
			return this.onError(elm, "<?php echo JsEncode($merchant_search->profilevalidationdate->errorMessage()) ?>");

		// Call Form_CustomValidate event
		if (!this.Form_CustomValidate(fobj))
			return false;
		return true;
	}

	// Form_CustomValidate
	fmerchantsearch.Form_CustomValidate = function(fobj) { // DO NOT CHANGE THIS LINE!

		// Your custom validation code here, return false if invalid.
		return true;
	}

	// Use JavaScript validation or not
	fmerchantsearch.validateRequired = <?php echo Config("CLIENT_VALIDATE") ? "true" : "false" ?>;

	// Dynamic selection lists
	fmerchantsearch.lists["x_changed"] = <?php echo $merchant_search->changed->Lookup->toClientList($merchant_search) ?>;
	fmerchantsearch.lists["x_changed"].options = <?php echo JsonEncode($merchant_search->changed->lookupOptions()) ?>;
	fmerchantsearch.lists["x_active"] = <?php echo $merchant_search->active->Lookup->toClientList($merchant_search) ?>;
	fmerchantsearch.lists["x_active"].options = <?php echo JsonEncode($merchant_search->active->lookupOptions()) ?>;
	fmerchantsearch.lists["x_tipallowed"] = <?php echo $merchant_search->tipallowed->Lookup->toClientList($merchant_search) ?>;
	fmerchantsearch.lists["x_tipallowed"].options = <?php echo JsonEncode($merchant_search->tipallowed->lookupOptions()) ?>;
	fmerchantsearch.lists["x_merchanttoaddtip"] = <?php echo $merchant_search->merchanttoaddtip->Lookup->toClientList($merchant_search) ?>;
	fmerchantsearch.lists["x_merchanttoaddtip"].options = <?php echo JsonEncode($merchant_search->merchanttoaddtip->lookupOptions()) ?>;
	fmerchantsearch.lists["x_ratetabletype"] = <?php echo $merchant_search->ratetabletype->Lookup->toClientList($merchant_search) ?>;
	fmerchantsearch.lists["x_ratetabletype"].options = <?php echo JsonEncode($merchant_search->ratetabletype->lookupOptions()) ?>;
	fmerchantsearch.lists["x_variabletax"] = <?php echo $merchant_search->variabletax->Lookup->toClientList($merchant_search) ?>;
	fmerchantsearch.lists["x_variabletax"].options = <?php echo JsonEncode($merchant_search->variabletax->lookupOptions()) ?>;
	fmerchantsearch.lists["x_remmitancetype"] = <?php echo $merchant_search->remmitancetype->Lookup->toClientList($merchant_search) ?>;
	fmerchantsearch.lists["x_remmitancetype"].options = <?php echo JsonEncode($merchant_search->remmitancetype->options(FALSE, TRUE)) ?>;
	fmerchantsearch.lists["x_businesscountry"] = <?php echo $merchant_search->businesscountry->Lookup->toClientList($merchant_search) ?>;
	fmerchantsearch.lists["x_businesscountry"].options = <?php echo JsonEncode($merchant_search->businesscountry->lookupOptions()) ?>;
	fmerchantsearch.lists["x_businessstate"] = <?php echo $merchant_search->businessstate->Lookup->toClientList($merchant_search) ?>;
	fmerchantsearch.lists["x_businessstate"].options = <?php echo JsonEncode($merchant_search->businessstate->lookupOptions()) ?>;
	fmerchantsearch.lists["x_profilevalidated"] = <?php echo $merchant_search->profilevalidated->Lookup->toClientList($merchant_search) ?>;
	fmerchantsearch.lists["x_profilevalidated"].options = <?php echo JsonEncode($merchant_search->profilevalidated->lookupOptions()) ?>;
	fmerchantsearch.lists["x_industry"] = <?php echo $merchant_search->industry->Lookup->toClientList($merchant_search) ?>;
	fmerchantsearch.lists["x_industry"].options = <?php echo JsonEncode($merchant_search->industry->lookupOptions()) ?>;
	fmerchantsearch.lists["x_legalstructure"] = <?php echo $merchant_search->legalstructure->Lookup->toClientList($merchant_search) ?>;
	fmerchantsearch.lists["x_legalstructure"].options = <?php echo JsonEncode($merchant_search->legalstructure->lookupOptions()) ?>;
	loadjs.done("fmerchantsearch");
});
</script>
<script>
loadjs.ready("head", function() {

	// Client script
	// Write your client script here, no need to add script tags.

});
</script>
<?php $merchant_search->showPageHeader(); ?>
<?php
$merchant_search->showMessage();
?>
<form name="fmerchantsearch" id="fmerchantsearch" class="<?php echo $merchant_search->FormClassName ?>" action="<?php echo CurrentPageName() ?>" method="post">
<?php if ($Page->CheckToken) { ?>
<input type="hidden" name="<?php echo Config("TOKEN_NAME") ?>" value="<?php echo $Page->Token ?>">
<?php } ?>
<input type="hidden" name="t" value="merchant">
<input type="hidden" name="action" id="action" value="search">
<input type="hidden" name="modal" value="<?php echo (int)$merchant_search->IsModal ?>">
<div class="ew-multi-page"><!-- multi-page -->
<div class="ew-nav-tabs" id="merchant_search"><!-- multi-page tabs -->
	<ul class="<?php echo $merchant_search->MultiPages->navStyle() ?>">
		<li class="nav-item"><a class="nav-link<?php echo $merchant_search->MultiPages->pageStyle(1) ?>" href="#tab_merchant1" data-toggle="tab"><?php echo $merchant->pageCaption(1) ?></a></li>
		<li class="nav-item"><a class="nav-link<?php echo $merchant_search->MultiPages->pageStyle(2) ?>" href="#tab_merchant2" data-toggle="tab"><?php echo $merchant->pageCaption(2) ?></a></li>
	</ul>
	<div class="tab-content"><!-- multi-page tabs .tab-content -->
		<div class="tab-pane<?php echo $merchant_search->MultiPages->pageStyle(1) ?>" id="tab_merchant1"><!-- multi-page .tab-pane -->
<div class="ew-search-div"><!-- page* -->
<?php if ($merchant_search->_userid->Visible) { // userid ?>
	<div id="r__userid" class="form-group row">
		<label for="x__userid" class="<?php echo $merchant_search->LeftColumnClass ?>"><span id="elh_merchant__userid"><?php echo $merchant_search->_userid->caption() ?></span>
		<span class="ew-search-operator">
<?php echo $Language->phrase("=") ?>
<input type="hidden" name="z__userid" id="z__userid" value="=">
</span>
		</label>
		<div class="<?php echo $merchant_search->RightColumnClass ?>"><div <?php echo $merchant_search->_userid->cellAttributes() ?>>
			<span id="el_merchant__userid" class="ew-search-field">
<input type="text" data-table="merchant" data-field="x__userid" data-page="1" name="x__userid" id="x__userid" size="30" placeholder="<?php echo HtmlEncode($merchant_search->_userid->getPlaceHolder()) ?>" value="<?php echo $merchant_search->_userid->EditValue ?>"<?php echo $merchant_search->_userid->editAttributes() ?>>
</span>
		</div></div>
	</div>
<?php } ?>
<?php if ($merchant_search->businessname->Visible) { // businessname ?>
	<div id="r_businessname" class="form-group row">
		<label for="x_businessname" class="<?php echo $merchant_search->LeftColumnClass ?>"><span id="elh_merchant_businessname"><?php echo $merchant_search->businessname->caption() ?></span>
		<span class="ew-search-operator">
<?php echo $Language->phrase("LIKE") ?>
<input type="hidden" name="z_businessname" id="z_businessname" value="LIKE">
</span>
		</label>
		<div class="<?php echo $merchant_search->RightColumnClass ?>"><div <?php echo $merchant_search->businessname->cellAttributes() ?>>
			<span id="el_merchant_businessname" class="ew-search-field">
<input type="text" data-table="merchant" data-field="x_businessname" data-page="1" name="x_businessname" id="x_businessname" size="30" maxlength="60" placeholder="<?php echo HtmlEncode($merchant_search->businessname->getPlaceHolder()) ?>" value="<?php echo $merchant_search->businessname->EditValue ?>"<?php echo $merchant_search->businessname->editAttributes() ?>>
</span>
		</div></div>
	</div>
<?php } ?>
<?php if ($merchant_search->officialname->Visible) { // officialname ?>
	<div id="r_officialname" class="form-group row">
		<label for="x_officialname" class="<?php echo $merchant_search->LeftColumnClass ?>"><span id="elh_merchant_officialname"><?php echo $merchant_search->officialname->caption() ?></span>
		<span class="ew-search-operator">
<?php echo $Language->phrase("LIKE") ?>
<input type="hidden" name="z_officialname" id="z_officialname" value="LIKE">
</span>
		</label>
		<div class="<?php echo $merchant_search->RightColumnClass ?>"><div <?php echo $merchant_search->officialname->cellAttributes() ?>>
			<span id="el_merchant_officialname" class="ew-search-field">
<input type="text" data-table="merchant" data-field="x_officialname" data-page="1" name="x_officialname" id="x_officialname" size="30" maxlength="60" placeholder="<?php echo HtmlEncode($merchant_search->officialname->getPlaceHolder()) ?>" value="<?php echo $merchant_search->officialname->EditValue ?>"<?php echo $merchant_search->officialname->editAttributes() ?>>
</span>
		</div></div>
	</div>
<?php } ?>
<?php if ($merchant_search->active->Visible) { // active ?>
	<div id="r_active" class="form-group row">
		<label class="<?php echo $merchant_search->LeftColumnClass ?>"><span id="elh_merchant_active"><?php echo $merchant_search->active->caption() ?></span>
		<span class="ew-search-operator">
<?php echo $Language->phrase("=") ?>
<input type="hidden" name="z_active" id="z_active" value="=">
</span>
		</label>
		<div class="<?php echo $merchant_search->RightColumnClass ?>"><div <?php echo $merchant_search->active->cellAttributes() ?>>
			<span id="el_merchant_active" class="ew-search-field">
<div id="tp_x_active" class="ew-template"><input type="radio" class="custom-control-input" data-table="merchant" data-field="x_active" data-page="1" data-value-separator="<?php echo $merchant_search->active->displayValueSeparatorAttribute() ?>" name="x_active" id="x_active" value="{value}"<?php echo $merchant_search->active->editAttributes() ?>></div>
<div id="dsl_x_active" data-repeatcolumn="5" class="ew-item-list d-none"><div>
<?php echo $merchant_search->active->radioButtonListHtml(FALSE, "x_active", 1) ?>
</div></div>
<?php echo $merchant_search->active->Lookup->getParamTag($merchant_search, "p_x_active") ?>
</span>
		</div></div>
	</div>
<?php } ?>
<?php if ($merchant_search->ratetableid->Visible) { // ratetableid ?>
	<div id="r_ratetableid" class="form-group row">
		<label for="x_ratetableid" class="<?php echo $merchant_search->LeftColumnClass ?>"><span id="elh_merchant_ratetableid"><?php echo $merchant_search->ratetableid->caption() ?></span>
		<span class="ew-search-operator">
<?php echo $Language->phrase("=") ?>
<input type="hidden" name="z_ratetableid" id="z_ratetableid" value="=">
</span>
		</label>
		<div class="<?php echo $merchant_search->RightColumnClass ?>"><div <?php echo $merchant_search->ratetableid->cellAttributes() ?>>
			<span id="el_merchant_ratetableid" class="ew-search-field">
<input type="text" data-table="merchant" data-field="x_ratetableid" data-page="1" name="x_ratetableid" id="x_ratetableid" size="30" placeholder="<?php echo HtmlEncode($merchant_search->ratetableid->getPlaceHolder()) ?>" value="<?php echo $merchant_search->ratetableid->EditValue ?>"<?php echo $merchant_search->ratetableid->editAttributes() ?>>
</span>
		</div></div>
	</div>
<?php } ?>
<?php if ($merchant_search->ratetabletype->Visible) { // ratetabletype ?>
	<div id="r_ratetabletype" class="form-group row">
		<label for="x_ratetabletype" class="<?php echo $merchant_search->LeftColumnClass ?>"><span id="elh_merchant_ratetabletype"><?php echo $merchant_search->ratetabletype->caption() ?></span>
		<span class="ew-search-operator">
<?php echo $Language->phrase("=") ?>
<input type="hidden" name="z_ratetabletype" id="z_ratetabletype" value="=">
</span>
		</label>
		<div class="<?php echo $merchant_search->RightColumnClass ?>"><div <?php echo $merchant_search->ratetabletype->cellAttributes() ?>>
			<span id="el_merchant_ratetabletype" class="ew-search-field">
<div class="btn-group ew-dropdown-list" role="group">
	<div class="btn-group" role="group">
		<button type="button" class="btn form-control dropdown-toggle ew-dropdown-toggle" aria-haspopup="true" aria-expanded="false"<?php if ($merchant_search->ratetabletype->ReadOnly) { ?> readonly<?php } else { ?>data-toggle="dropdown"<?php } ?>><?php echo $merchant_search->ratetabletype->AdvancedSearch->ViewValue ?></button>
		<div id="dsl_x_ratetabletype" data-repeatcolumn="1" class="dropdown-menu">
			<div class="ew-items" style="overflow-x: hidden;">
<?php echo $merchant_search->ratetabletype->radioButtonListHtml(TRUE, "x_ratetabletype", 1) ?>
			</div><!-- /.ew-items -->
		</div><!-- /.dropdown-menu -->
		<div id="tp_x_ratetabletype" class="ew-template"><input type="radio" class="custom-control-input" data-table="merchant" data-field="x_ratetabletype" data-page="1" data-value-separator="<?php echo $merchant_search->ratetabletype->displayValueSeparatorAttribute() ?>" name="x_ratetabletype" id="x_ratetabletype" value="{value}"<?php echo $merchant_search->ratetabletype->editAttributes() ?>></div>
	</div><!-- /.btn-group -->
	<?php if (!$merchant_search->ratetabletype->ReadOnly) { ?>
	<button type="button" class="btn btn-default ew-dropdown-clear" disabled>
		<i class="fas fa-times ew-icon"></i>
	</button>
	<?php } ?>
</div><!-- /.ew-dropdown-list -->
<?php echo $merchant_search->ratetabletype->Lookup->getParamTag($merchant_search, "p_x_ratetabletype") ?>
</span>
		</div></div>
	</div>
<?php } ?>
<?php if ($merchant_search->officialdocnumber->Visible) { // officialdocnumber ?>
	<div id="r_officialdocnumber" class="form-group row">
		<label for="x_officialdocnumber" class="<?php echo $merchant_search->LeftColumnClass ?>"><span id="elh_merchant_officialdocnumber"><?php echo $merchant_search->officialdocnumber->caption() ?></span>
		<span class="ew-search-operator">
<?php echo $Language->phrase("LIKE") ?>
<input type="hidden" name="z_officialdocnumber" id="z_officialdocnumber" value="LIKE">
</span>
		</label>
		<div class="<?php echo $merchant_search->RightColumnClass ?>"><div <?php echo $merchant_search->officialdocnumber->cellAttributes() ?>>
			<span id="el_merchant_officialdocnumber" class="ew-search-field">
<input type="text" data-table="merchant" data-field="x_officialdocnumber" data-page="1" name="x_officialdocnumber" id="x_officialdocnumber" size="30" maxlength="20" placeholder="<?php echo HtmlEncode($merchant_search->officialdocnumber->getPlaceHolder()) ?>" value="<?php echo $merchant_search->officialdocnumber->EditValue ?>"<?php echo $merchant_search->officialdocnumber->editAttributes() ?>>
</span>
		</div></div>
	</div>
<?php } ?>
<?php if ($merchant_search->officialdocname->Visible) { // officialdocname ?>
	<div id="r_officialdocname" class="form-group row">
		<label for="x_officialdocname" class="<?php echo $merchant_search->LeftColumnClass ?>"><span id="elh_merchant_officialdocname"><?php echo $merchant_search->officialdocname->caption() ?></span>
		<span class="ew-search-operator">
<?php echo $Language->phrase("LIKE") ?>
<input type="hidden" name="z_officialdocname" id="z_officialdocname" value="LIKE">
</span>
		</label>
		<div class="<?php echo $merchant_search->RightColumnClass ?>"><div <?php echo $merchant_search->officialdocname->cellAttributes() ?>>
			<span id="el_merchant_officialdocname" class="ew-search-field">
<input type="text" data-table="merchant" data-field="x_officialdocname" data-page="1" name="x_officialdocname" id="x_officialdocname" size="30" maxlength="15" placeholder="<?php echo HtmlEncode($merchant_search->officialdocname->getPlaceHolder()) ?>" value="<?php echo $merchant_search->officialdocname->EditValue ?>"<?php echo $merchant_search->officialdocname->editAttributes() ?>>
</span>
		</div></div>
	</div>
<?php } ?>
<?php if ($merchant_search->businessphoneno->Visible) { // businessphoneno ?>
	<div id="r_businessphoneno" class="form-group row">
		<label for="x_businessphoneno" class="<?php echo $merchant_search->LeftColumnClass ?>"><span id="elh_merchant_businessphoneno"><?php echo $merchant_search->businessphoneno->caption() ?></span>
		<span class="ew-search-operator">
<?php echo $Language->phrase("LIKE") ?>
<input type="hidden" name="z_businessphoneno" id="z_businessphoneno" value="LIKE">
</span>
		</label>
		<div class="<?php echo $merchant_search->RightColumnClass ?>"><div <?php echo $merchant_search->businessphoneno->cellAttributes() ?>>
			<span id="el_merchant_businessphoneno" class="ew-search-field">
<input type="text" data-table="merchant" data-field="x_businessphoneno" data-page="1" name="x_businessphoneno" id="x_businessphoneno" size="30" maxlength="15" placeholder="<?php echo HtmlEncode($merchant_search->businessphoneno->getPlaceHolder()) ?>" value="<?php echo $merchant_search->businessphoneno->EditValue ?>"<?php echo $merchant_search->businessphoneno->editAttributes() ?>>
</span>
		</div></div>
	</div>
<?php } ?>
<?php if ($merchant_search->businessaddress1->Visible) { // businessaddress1 ?>
	<div id="r_businessaddress1" class="form-group row">
		<label for="x_businessaddress1" class="<?php echo $merchant_search->LeftColumnClass ?>"><span id="elh_merchant_businessaddress1"><?php echo $merchant_search->businessaddress1->caption() ?></span>
		<span class="ew-search-operator">
<?php echo $Language->phrase("LIKE") ?>
<input type="hidden" name="z_businessaddress1" id="z_businessaddress1" value="LIKE">
</span>
		</label>
		<div class="<?php echo $merchant_search->RightColumnClass ?>"><div <?php echo $merchant_search->businessaddress1->cellAttributes() ?>>
			<span id="el_merchant_businessaddress1" class="ew-search-field">
<input type="text" data-table="merchant" data-field="x_businessaddress1" data-page="1" name="x_businessaddress1" id="x_businessaddress1" size="30" maxlength="60" placeholder="<?php echo HtmlEncode($merchant_search->businessaddress1->getPlaceHolder()) ?>" value="<?php echo $merchant_search->businessaddress1->EditValue ?>"<?php echo $merchant_search->businessaddress1->editAttributes() ?>>
</span>
		</div></div>
	</div>
<?php } ?>
<?php if ($merchant_search->businessaddress2->Visible) { // businessaddress2 ?>
	<div id="r_businessaddress2" class="form-group row">
		<label for="x_businessaddress2" class="<?php echo $merchant_search->LeftColumnClass ?>"><span id="elh_merchant_businessaddress2"><?php echo $merchant_search->businessaddress2->caption() ?></span>
		<span class="ew-search-operator">
<?php echo $Language->phrase("LIKE") ?>
<input type="hidden" name="z_businessaddress2" id="z_businessaddress2" value="LIKE">
</span>
		</label>
		<div class="<?php echo $merchant_search->RightColumnClass ?>"><div <?php echo $merchant_search->businessaddress2->cellAttributes() ?>>
			<span id="el_merchant_businessaddress2" class="ew-search-field">
<input type="text" data-table="merchant" data-field="x_businessaddress2" data-page="1" name="x_businessaddress2" id="x_businessaddress2" size="30" maxlength="60" placeholder="<?php echo HtmlEncode($merchant_search->businessaddress2->getPlaceHolder()) ?>" value="<?php echo $merchant_search->businessaddress2->EditValue ?>"<?php echo $merchant_search->businessaddress2->editAttributes() ?>>
</span>
		</div></div>
	</div>
<?php } ?>
<?php if ($merchant_search->businesscity->Visible) { // businesscity ?>
	<div id="r_businesscity" class="form-group row">
		<label for="x_businesscity" class="<?php echo $merchant_search->LeftColumnClass ?>"><span id="elh_merchant_businesscity"><?php echo $merchant_search->businesscity->caption() ?></span>
		<span class="ew-search-operator">
<?php echo $Language->phrase("LIKE") ?>
<input type="hidden" name="z_businesscity" id="z_businesscity" value="LIKE">
</span>
		</label>
		<div class="<?php echo $merchant_search->RightColumnClass ?>"><div <?php echo $merchant_search->businesscity->cellAttributes() ?>>
			<span id="el_merchant_businesscity" class="ew-search-field">
<input type="text" data-table="merchant" data-field="x_businesscity" data-page="1" name="x_businesscity" id="x_businesscity" size="30" maxlength="60" placeholder="<?php echo HtmlEncode($merchant_search->businesscity->getPlaceHolder()) ?>" value="<?php echo $merchant_search->businesscity->EditValue ?>"<?php echo $merchant_search->businesscity->editAttributes() ?>>
</span>
		</div></div>
	</div>
<?php } ?>
<?php if ($merchant_search->businesscountry->Visible) { // businesscountry ?>
	<div id="r_businesscountry" class="form-group row">
		<label for="x_businesscountry" class="<?php echo $merchant_search->LeftColumnClass ?>"><span id="elh_merchant_businesscountry"><?php echo $merchant_search->businesscountry->caption() ?></span>
		<span class="ew-search-operator">
<?php echo $Language->phrase("LIKE") ?>
<input type="hidden" name="z_businesscountry" id="z_businesscountry" value="LIKE">
</span>
		</label>
		<div class="<?php echo $merchant_search->RightColumnClass ?>"><div <?php echo $merchant_search->businesscountry->cellAttributes() ?>>
			<span id="el_merchant_businesscountry" class="ew-search-field">
<?php $merchant_search->businesscountry->EditAttrs->prepend("onclick", "ew.updateOptions.call(this);"); ?>
<div class="btn-group ew-dropdown-list" role="group">
	<div class="btn-group" role="group">
		<button type="button" class="btn form-control dropdown-toggle ew-dropdown-toggle" aria-haspopup="true" aria-expanded="false"<?php if ($merchant_search->businesscountry->ReadOnly) { ?> readonly<?php } else { ?>data-toggle="dropdown"<?php } ?>><?php echo $merchant_search->businesscountry->AdvancedSearch->ViewValue ?></button>
		<div id="dsl_x_businesscountry" data-repeatcolumn="1" class="dropdown-menu">
			<div class="ew-items" style="overflow-x: hidden; min-width: 200px; max-height: 300px; overflow-y: auto;">
<?php echo $merchant_search->businesscountry->radioButtonListHtml(TRUE, "x_businesscountry", 1) ?>
			</div><!-- /.ew-items -->
		</div><!-- /.dropdown-menu -->
		<div id="tp_x_businesscountry" class="ew-template"><input type="radio" class="custom-control-input" data-table="merchant" data-field="x_businesscountry" data-page="1" data-value-separator="<?php echo $merchant_search->businesscountry->displayValueSeparatorAttribute() ?>" name="x_businesscountry" id="x_businesscountry" value="{value}"<?php echo $merchant_search->businesscountry->editAttributes() ?>></div>
	</div><!-- /.btn-group -->
	<?php if (!$merchant_search->businesscountry->ReadOnly) { ?>
	<button type="button" class="btn btn-default ew-dropdown-clear" disabled>
		<i class="fas fa-times ew-icon"></i>
	</button>
	<?php } ?>
</div><!-- /.ew-dropdown-list -->
<?php echo $merchant_search->businesscountry->Lookup->getParamTag($merchant_search, "p_x_businesscountry") ?>
</span>
		</div></div>
	</div>
<?php } ?>
<?php if ($merchant_search->businessstate->Visible) { // businessstate ?>
	<div id="r_businessstate" class="form-group row">
		<label for="x_businessstate" class="<?php echo $merchant_search->LeftColumnClass ?>"><span id="elh_merchant_businessstate"><?php echo $merchant_search->businessstate->caption() ?></span>
		<span class="ew-search-operator">
<?php echo $Language->phrase("LIKE") ?>
<input type="hidden" name="z_businessstate" id="z_businessstate" value="LIKE">
</span>
		</label>
		<div class="<?php echo $merchant_search->RightColumnClass ?>"><div <?php echo $merchant_search->businessstate->cellAttributes() ?>>
			<span id="el_merchant_businessstate" class="ew-search-field">
<div class="btn-group ew-dropdown-list" role="group">
	<div class="btn-group" role="group">
		<button type="button" class="btn form-control dropdown-toggle ew-dropdown-toggle" aria-haspopup="true" aria-expanded="false"<?php if ($merchant_search->businessstate->ReadOnly) { ?> readonly<?php } else { ?>data-toggle="dropdown"<?php } ?>><?php echo $merchant_search->businessstate->AdvancedSearch->ViewValue ?></button>
		<div id="dsl_x_businessstate" data-repeatcolumn="1" class="dropdown-menu">
			<div class="ew-items" style="overflow-x: hidden; min-width: 200px; max-height: 300px; overflow-y: auto;">
<?php echo $merchant_search->businessstate->radioButtonListHtml(TRUE, "x_businessstate", 1) ?>
			</div><!-- /.ew-items -->
		</div><!-- /.dropdown-menu -->
		<div id="tp_x_businessstate" class="ew-template"><input type="radio" class="custom-control-input" data-table="merchant" data-field="x_businessstate" data-page="1" data-value-separator="<?php echo $merchant_search->businessstate->displayValueSeparatorAttribute() ?>" name="x_businessstate" id="x_businessstate" value="{value}"<?php echo $merchant_search->businessstate->editAttributes() ?>></div>
	</div><!-- /.btn-group -->
	<?php if (!$merchant_search->businessstate->ReadOnly) { ?>
	<button type="button" class="btn btn-default ew-dropdown-clear" disabled>
		<i class="fas fa-times ew-icon"></i>
	</button>
	<?php } ?>
</div><!-- /.ew-dropdown-list -->
<?php echo $merchant_search->businessstate->Lookup->getParamTag($merchant_search, "p_x_businessstate") ?>
</span>
		</div></div>
	</div>
<?php } ?>
<?php if ($merchant_search->businesszipcode->Visible) { // businesszipcode ?>
	<div id="r_businesszipcode" class="form-group row">
		<label for="x_businesszipcode" class="<?php echo $merchant_search->LeftColumnClass ?>"><span id="elh_merchant_businesszipcode"><?php echo $merchant_search->businesszipcode->caption() ?></span>
		<span class="ew-search-operator">
<?php echo $Language->phrase("LIKE") ?>
<input type="hidden" name="z_businesszipcode" id="z_businesszipcode" value="LIKE">
</span>
		</label>
		<div class="<?php echo $merchant_search->RightColumnClass ?>"><div <?php echo $merchant_search->businesszipcode->cellAttributes() ?>>
			<span id="el_merchant_businesszipcode" class="ew-search-field">
<input type="text" data-table="merchant" data-field="x_businesszipcode" data-page="1" name="x_businesszipcode" id="x_businesszipcode" size="30" maxlength="10" placeholder="<?php echo HtmlEncode($merchant_search->businesszipcode->getPlaceHolder()) ?>" value="<?php echo $merchant_search->businesszipcode->EditValue ?>"<?php echo $merchant_search->businesszipcode->editAttributes() ?>>
</span>
		</div></div>
	</div>
<?php } ?>
<?php if ($merchant_search->bankname->Visible) { // bankname ?>
	<div id="r_bankname" class="form-group row">
		<label for="x_bankname" class="<?php echo $merchant_search->LeftColumnClass ?>"><span id="elh_merchant_bankname"><?php echo $merchant_search->bankname->caption() ?></span>
		<span class="ew-search-operator">
<?php echo $Language->phrase("LIKE") ?>
<input type="hidden" name="z_bankname" id="z_bankname" value="LIKE">
</span>
		</label>
		<div class="<?php echo $merchant_search->RightColumnClass ?>"><div <?php echo $merchant_search->bankname->cellAttributes() ?>>
			<span id="el_merchant_bankname" class="ew-search-field">
<input type="text" data-table="merchant" data-field="x_bankname" data-page="1" name="x_bankname" id="x_bankname" size="30" maxlength="20" placeholder="<?php echo HtmlEncode($merchant_search->bankname->getPlaceHolder()) ?>" value="<?php echo $merchant_search->bankname->EditValue ?>"<?php echo $merchant_search->bankname->editAttributes() ?>>
</span>
		</div></div>
	</div>
<?php } ?>
<?php if ($merchant_search->bankbranchnumber->Visible) { // bankbranchnumber ?>
	<div id="r_bankbranchnumber" class="form-group row">
		<label for="x_bankbranchnumber" class="<?php echo $merchant_search->LeftColumnClass ?>"><span id="elh_merchant_bankbranchnumber"><?php echo $merchant_search->bankbranchnumber->caption() ?></span>
		<span class="ew-search-operator">
<?php echo $Language->phrase("LIKE") ?>
<input type="hidden" name="z_bankbranchnumber" id="z_bankbranchnumber" value="LIKE">
</span>
		</label>
		<div class="<?php echo $merchant_search->RightColumnClass ?>"><div <?php echo $merchant_search->bankbranchnumber->cellAttributes() ?>>
			<span id="el_merchant_bankbranchnumber" class="ew-search-field">
<input type="text" data-table="merchant" data-field="x_bankbranchnumber" data-page="1" name="x_bankbranchnumber" id="x_bankbranchnumber" size="30" maxlength="10" placeholder="<?php echo HtmlEncode($merchant_search->bankbranchnumber->getPlaceHolder()) ?>" value="<?php echo $merchant_search->bankbranchnumber->EditValue ?>"<?php echo $merchant_search->bankbranchnumber->editAttributes() ?>>
</span>
		</div></div>
	</div>
<?php } ?>
<?php if ($merchant_search->bankaccountnumber->Visible) { // bankaccountnumber ?>
	<div id="r_bankaccountnumber" class="form-group row">
		<label for="x_bankaccountnumber" class="<?php echo $merchant_search->LeftColumnClass ?>"><span id="elh_merchant_bankaccountnumber"><?php echo $merchant_search->bankaccountnumber->caption() ?></span>
		<span class="ew-search-operator">
<?php echo $Language->phrase("LIKE") ?>
<input type="hidden" name="z_bankaccountnumber" id="z_bankaccountnumber" value="LIKE">
</span>
		</label>
		<div class="<?php echo $merchant_search->RightColumnClass ?>"><div <?php echo $merchant_search->bankaccountnumber->cellAttributes() ?>>
			<span id="el_merchant_bankaccountnumber" class="ew-search-field">
<input type="text" data-table="merchant" data-field="x_bankaccountnumber" data-page="1" name="x_bankaccountnumber" id="x_bankaccountnumber" size="30" maxlength="10" placeholder="<?php echo HtmlEncode($merchant_search->bankaccountnumber->getPlaceHolder()) ?>" value="<?php echo $merchant_search->bankaccountnumber->EditValue ?>"<?php echo $merchant_search->bankaccountnumber->editAttributes() ?>>
</span>
		</div></div>
	</div>
<?php } ?>
<?php if ($merchant_search->other1->Visible) { // other1 ?>
	<div id="r_other1" class="form-group row">
		<label for="x_other1" class="<?php echo $merchant_search->LeftColumnClass ?>"><span id="elh_merchant_other1"><?php echo $merchant_search->other1->caption() ?></span>
		<span class="ew-search-operator">
<?php echo $Language->phrase("LIKE") ?>
<input type="hidden" name="z_other1" id="z_other1" value="LIKE">
</span>
		</label>
		<div class="<?php echo $merchant_search->RightColumnClass ?>"><div <?php echo $merchant_search->other1->cellAttributes() ?>>
			<span id="el_merchant_other1" class="ew-search-field">
<input type="text" data-table="merchant" data-field="x_other1" data-page="1" name="x_other1" id="x_other1" size="30" maxlength="20" placeholder="<?php echo HtmlEncode($merchant_search->other1->getPlaceHolder()) ?>" value="<?php echo $merchant_search->other1->EditValue ?>"<?php echo $merchant_search->other1->editAttributes() ?>>
</span>
		</div></div>
	</div>
<?php } ?>
<?php if ($merchant_search->other2->Visible) { // other2 ?>
	<div id="r_other2" class="form-group row">
		<label for="x_other2" class="<?php echo $merchant_search->LeftColumnClass ?>"><span id="elh_merchant_other2"><?php echo $merchant_search->other2->caption() ?></span>
		<span class="ew-search-operator">
<?php echo $Language->phrase("LIKE") ?>
<input type="hidden" name="z_other2" id="z_other2" value="LIKE">
</span>
		</label>
		<div class="<?php echo $merchant_search->RightColumnClass ?>"><div <?php echo $merchant_search->other2->cellAttributes() ?>>
			<span id="el_merchant_other2" class="ew-search-field">
<input type="text" data-table="merchant" data-field="x_other2" data-page="1" name="x_other2" id="x_other2" size="30" maxlength="20" placeholder="<?php echo HtmlEncode($merchant_search->other2->getPlaceHolder()) ?>" value="<?php echo $merchant_search->other2->EditValue ?>"<?php echo $merchant_search->other2->editAttributes() ?>>
</span>
		</div></div>
	</div>
<?php } ?>
<?php if ($merchant_search->other3->Visible) { // other3 ?>
	<div id="r_other3" class="form-group row">
		<label for="x_other3" class="<?php echo $merchant_search->LeftColumnClass ?>"><span id="elh_merchant_other3"><?php echo $merchant_search->other3->caption() ?></span>
		<span class="ew-search-operator">
<?php echo $Language->phrase("LIKE") ?>
<input type="hidden" name="z_other3" id="z_other3" value="LIKE">
</span>
		</label>
		<div class="<?php echo $merchant_search->RightColumnClass ?>"><div <?php echo $merchant_search->other3->cellAttributes() ?>>
			<span id="el_merchant_other3" class="ew-search-field">
<input type="text" data-table="merchant" data-field="x_other3" data-page="1" name="x_other3" id="x_other3" size="30" maxlength="20" placeholder="<?php echo HtmlEncode($merchant_search->other3->getPlaceHolder()) ?>" value="<?php echo $merchant_search->other3->EditValue ?>"<?php echo $merchant_search->other3->editAttributes() ?>>
</span>
		</div></div>
	</div>
<?php } ?>
<?php if ($merchant_search->externalid->Visible) { // externalid ?>
	<div id="r_externalid" class="form-group row">
		<label for="x_externalid" class="<?php echo $merchant_search->LeftColumnClass ?>"><span id="elh_merchant_externalid"><?php echo $merchant_search->externalid->caption() ?></span>
		<span class="ew-search-operator">
<?php echo $Language->phrase("LIKE") ?>
<input type="hidden" name="z_externalid" id="z_externalid" value="LIKE">
</span>
		</label>
		<div class="<?php echo $merchant_search->RightColumnClass ?>"><div <?php echo $merchant_search->externalid->cellAttributes() ?>>
			<span id="el_merchant_externalid" class="ew-search-field">
<input type="text" data-table="merchant" data-field="x_externalid" data-page="1" name="x_externalid" id="x_externalid" size="30" maxlength="60" placeholder="<?php echo HtmlEncode($merchant_search->externalid->getPlaceHolder()) ?>" value="<?php echo $merchant_search->externalid->EditValue ?>"<?php echo $merchant_search->externalid->editAttributes() ?>>
</span>
		</div></div>
	</div>
<?php } ?>
<?php if ($merchant_search->couponpin->Visible) { // couponpin ?>
	<div id="r_couponpin" class="form-group row">
		<label for="x_couponpin" class="<?php echo $merchant_search->LeftColumnClass ?>"><span id="elh_merchant_couponpin"><?php echo $merchant_search->couponpin->caption() ?></span>
		<span class="ew-search-operator">
<?php echo $Language->phrase("LIKE") ?>
<input type="hidden" name="z_couponpin" id="z_couponpin" value="LIKE">
</span>
		</label>
		<div class="<?php echo $merchant_search->RightColumnClass ?>"><div <?php echo $merchant_search->couponpin->cellAttributes() ?>>
			<span id="el_merchant_couponpin" class="ew-search-field">
<input type="text" data-table="merchant" data-field="x_couponpin" data-page="1" name="x_couponpin" id="x_couponpin" size="30" maxlength="3" placeholder="<?php echo HtmlEncode($merchant_search->couponpin->getPlaceHolder()) ?>" value="<?php echo $merchant_search->couponpin->EditValue ?>"<?php echo $merchant_search->couponpin->editAttributes() ?>>
</span>
		</div></div>
	</div>
<?php } ?>
<?php if ($merchant_search->swiftcode->Visible) { // swiftcode ?>
	<div id="r_swiftcode" class="form-group row">
		<label for="x_swiftcode" class="<?php echo $merchant_search->LeftColumnClass ?>"><span id="elh_merchant_swiftcode"><?php echo $merchant_search->swiftcode->caption() ?></span>
		<span class="ew-search-operator">
<?php echo $Language->phrase("LIKE") ?>
<input type="hidden" name="z_swiftcode" id="z_swiftcode" value="LIKE">
</span>
		</label>
		<div class="<?php echo $merchant_search->RightColumnClass ?>"><div <?php echo $merchant_search->swiftcode->cellAttributes() ?>>
			<span id="el_merchant_swiftcode" class="ew-search-field">
<input type="text" data-table="merchant" data-field="x_swiftcode" data-page="1" name="x_swiftcode" id="x_swiftcode" size="30" maxlength="20" placeholder="<?php echo HtmlEncode($merchant_search->swiftcode->getPlaceHolder()) ?>" value="<?php echo $merchant_search->swiftcode->EditValue ?>"<?php echo $merchant_search->swiftcode->editAttributes() ?>>
</span>
		</div></div>
	</div>
<?php } ?>
<?php if ($merchant_search->profilevalidated->Visible) { // profilevalidated ?>
	<div id="r_profilevalidated" class="form-group row">
		<label class="<?php echo $merchant_search->LeftColumnClass ?>"><span id="elh_merchant_profilevalidated"><?php echo $merchant_search->profilevalidated->caption() ?></span>
		<span class="ew-search-operator">
<?php echo $Language->phrase("=") ?>
<input type="hidden" name="z_profilevalidated" id="z_profilevalidated" value="=">
</span>
		</label>
		<div class="<?php echo $merchant_search->RightColumnClass ?>"><div <?php echo $merchant_search->profilevalidated->cellAttributes() ?>>
			<span id="el_merchant_profilevalidated" class="ew-search-field">
<div id="tp_x_profilevalidated" class="ew-template"><input type="radio" class="custom-control-input" data-table="merchant" data-field="x_profilevalidated" data-page="1" data-value-separator="<?php echo $merchant_search->profilevalidated->displayValueSeparatorAttribute() ?>" name="x_profilevalidated" id="x_profilevalidated" value="{value}"<?php echo $merchant_search->profilevalidated->editAttributes() ?>></div>
<div id="dsl_x_profilevalidated" data-repeatcolumn="5" class="ew-item-list d-none"><div>
<?php echo $merchant_search->profilevalidated->radioButtonListHtml(FALSE, "x_profilevalidated", 1) ?>
</div></div>
<?php echo $merchant_search->profilevalidated->Lookup->getParamTag($merchant_search, "p_x_profilevalidated") ?>
</span>
		</div></div>
	</div>
<?php } ?>
<?php if ($merchant_search->profilevalidationdate->Visible) { // profilevalidationdate ?>
	<div id="r_profilevalidationdate" class="form-group row">
		<label for="x_profilevalidationdate" class="<?php echo $merchant_search->LeftColumnClass ?>"><span id="elh_merchant_profilevalidationdate"><?php echo $merchant_search->profilevalidationdate->caption() ?></span>
		<span class="ew-search-operator">
<?php echo $Language->phrase("=") ?>
<input type="hidden" name="z_profilevalidationdate" id="z_profilevalidationdate" value="=">
</span>
		</label>
		<div class="<?php echo $merchant_search->RightColumnClass ?>"><div <?php echo $merchant_search->profilevalidationdate->cellAttributes() ?>>
			<span id="el_merchant_profilevalidationdate" class="ew-search-field">
<input type="text" data-table="merchant" data-field="x_profilevalidationdate" data-page="1" name="x_profilevalidationdate" id="x_profilevalidationdate" maxlength="10" placeholder="<?php echo HtmlEncode($merchant_search->profilevalidationdate->getPlaceHolder()) ?>" value="<?php echo $merchant_search->profilevalidationdate->EditValue ?>"<?php echo $merchant_search->profilevalidationdate->editAttributes() ?>>
<?php if (!$merchant_search->profilevalidationdate->ReadOnly && !$merchant_search->profilevalidationdate->Disabled && !isset($merchant_search->profilevalidationdate->EditAttrs["readonly"]) && !isset($merchant_search->profilevalidationdate->EditAttrs["disabled"])) { ?>
<script>
loadjs.ready(["fmerchantsearch", "datetimepicker"], function() {
	ew.createDateTimePicker("fmerchantsearch", "x_profilevalidationdate", {"ignoreReadonly":true,"useCurrent":false,"format":0});
});
</script>
<?php } ?>
</span>
		</div></div>
	</div>
<?php } ?>
<?php if ($merchant_search->industry->Visible) { // industry ?>
	<div id="r_industry" class="form-group row">
		<label for="x_industry" class="<?php echo $merchant_search->LeftColumnClass ?>"><span id="elh_merchant_industry"><?php echo $merchant_search->industry->caption() ?></span>
		<span class="ew-search-operator">
<?php echo $Language->phrase("LIKE") ?>
<input type="hidden" name="z_industry" id="z_industry" value="LIKE">
</span>
		</label>
		<div class="<?php echo $merchant_search->RightColumnClass ?>"><div <?php echo $merchant_search->industry->cellAttributes() ?>>
			<span id="el_merchant_industry" class="ew-search-field">
<div class="input-group">
	<select class="custom-select ew-custom-select" data-table="merchant" data-field="x_industry" data-page="1" data-value-separator="<?php echo $merchant_search->industry->displayValueSeparatorAttribute() ?>" id="x_industry" name="x_industry"<?php echo $merchant_search->industry->editAttributes() ?>>
			<?php echo $merchant_search->industry->selectOptionListHtml("x_industry") ?>
		</select>
</div>
<?php echo $merchant_search->industry->Lookup->getParamTag($merchant_search, "p_x_industry") ?>
</span>
		</div></div>
	</div>
<?php } ?>
<?php if ($merchant_search->legalstructure->Visible) { // legalstructure ?>
	<div id="r_legalstructure" class="form-group row">
		<label for="x_legalstructure" class="<?php echo $merchant_search->LeftColumnClass ?>"><span id="elh_merchant_legalstructure"><?php echo $merchant_search->legalstructure->caption() ?></span>
		<span class="ew-search-operator">
<?php echo $Language->phrase("LIKE") ?>
<input type="hidden" name="z_legalstructure" id="z_legalstructure" value="LIKE">
</span>
		</label>
		<div class="<?php echo $merchant_search->RightColumnClass ?>"><div <?php echo $merchant_search->legalstructure->cellAttributes() ?>>
			<span id="el_merchant_legalstructure" class="ew-search-field">
<div class="input-group">
	<select class="custom-select ew-custom-select" data-table="merchant" data-field="x_legalstructure" data-page="1" data-value-separator="<?php echo $merchant_search->legalstructure->displayValueSeparatorAttribute() ?>" id="x_legalstructure" name="x_legalstructure"<?php echo $merchant_search->legalstructure->editAttributes() ?>>
			<?php echo $merchant_search->legalstructure->selectOptionListHtml("x_legalstructure") ?>
		</select>
</div>
<?php echo $merchant_search->legalstructure->Lookup->getParamTag($merchant_search, "p_x_legalstructure") ?>
</span>
		</div></div>
	</div>
<?php } ?>
<?php if ($merchant_search->extendedfields->Visible) { // extendedfields ?>
	<div id="r_extendedfields" class="form-group row">
		<label for="x_extendedfields" class="<?php echo $merchant_search->LeftColumnClass ?>"><span id="elh_merchant_extendedfields"><?php echo $merchant_search->extendedfields->caption() ?></span>
		<span class="ew-search-operator">
<?php echo $Language->phrase("LIKE") ?>
<input type="hidden" name="z_extendedfields" id="z_extendedfields" value="LIKE">
</span>
		</label>
		<div class="<?php echo $merchant_search->RightColumnClass ?>"><div <?php echo $merchant_search->extendedfields->cellAttributes() ?>>
			<span id="el_merchant_extendedfields" class="ew-search-field">
<input type="text" data-table="merchant" data-field="x_extendedfields" data-page="1" name="x_extendedfields" id="x_extendedfields" size="35" placeholder="<?php echo HtmlEncode($merchant_search->extendedfields->getPlaceHolder()) ?>" value="<?php echo $merchant_search->extendedfields->EditValue ?>"<?php echo $merchant_search->extendedfields->editAttributes() ?>>
</span>
		</div></div>
	</div>
<?php } ?>
</div><!-- /page* -->
		</div><!-- /multi-page .tab-pane -->
		<div class="tab-pane<?php echo $merchant_search->MultiPages->pageStyle(2) ?>" id="tab_merchant2"><!-- multi-page .tab-pane -->
<div class="ew-search-div"><!-- page* -->
<?php if ($merchant_search->changed->Visible) { // changed ?>
	<div id="r_changed" class="form-group row">
		<label class="<?php echo $merchant_search->LeftColumnClass ?>"><span id="elh_merchant_changed"><?php echo $merchant_search->changed->caption() ?></span>
		<span class="ew-search-operator">
<?php echo $Language->phrase("=") ?>
<input type="hidden" name="z_changed" id="z_changed" value="=">
</span>
		</label>
		<div class="<?php echo $merchant_search->RightColumnClass ?>"><div <?php echo $merchant_search->changed->cellAttributes() ?>>
			<span id="el_merchant_changed" class="ew-search-field">
<div id="tp_x_changed" class="ew-template"><input type="radio" class="custom-control-input" data-table="merchant" data-field="x_changed" data-page="2" data-value-separator="<?php echo $merchant_search->changed->displayValueSeparatorAttribute() ?>" name="x_changed" id="x_changed" value="{value}"<?php echo $merchant_search->changed->editAttributes() ?>></div>
<div id="dsl_x_changed" data-repeatcolumn="5" class="ew-item-list d-none"><div>
<?php echo $merchant_search->changed->radioButtonListHtml(FALSE, "x_changed", 2) ?>
</div></div>
<?php echo $merchant_search->changed->Lookup->getParamTag($merchant_search, "p_x_changed") ?>
</span>
		</div></div>
	</div>
<?php } ?>
<?php if ($merchant_search->tipallowed->Visible) { // tipallowed ?>
	<div id="r_tipallowed" class="form-group row">
		<label class="<?php echo $merchant_search->LeftColumnClass ?>"><span id="elh_merchant_tipallowed"><?php echo $merchant_search->tipallowed->caption() ?></span>
		<span class="ew-search-operator">
<?php echo $Language->phrase("=") ?>
<input type="hidden" name="z_tipallowed" id="z_tipallowed" value="=">
</span>
		</label>
		<div class="<?php echo $merchant_search->RightColumnClass ?>"><div <?php echo $merchant_search->tipallowed->cellAttributes() ?>>
			<span id="el_merchant_tipallowed" class="ew-search-field">
<div id="tp_x_tipallowed" class="ew-template"><input type="radio" class="custom-control-input" data-table="merchant" data-field="x_tipallowed" data-page="2" data-value-separator="<?php echo $merchant_search->tipallowed->displayValueSeparatorAttribute() ?>" name="x_tipallowed" id="x_tipallowed" value="{value}"<?php echo $merchant_search->tipallowed->editAttributes() ?>></div>
<div id="dsl_x_tipallowed" data-repeatcolumn="5" class="ew-item-list d-none"><div>
<?php echo $merchant_search->tipallowed->radioButtonListHtml(FALSE, "x_tipallowed", 2) ?>
</div></div>
<?php echo $merchant_search->tipallowed->Lookup->getParamTag($merchant_search, "p_x_tipallowed") ?>
</span>
		</div></div>
	</div>
<?php } ?>
<?php if ($merchant_search->merchanttoaddtip->Visible) { // merchanttoaddtip ?>
	<div id="r_merchanttoaddtip" class="form-group row">
		<label class="<?php echo $merchant_search->LeftColumnClass ?>"><span id="elh_merchant_merchanttoaddtip"><?php echo $merchant_search->merchanttoaddtip->caption() ?></span>
		<span class="ew-search-operator">
<?php echo $Language->phrase("=") ?>
<input type="hidden" name="z_merchanttoaddtip" id="z_merchanttoaddtip" value="=">
</span>
		</label>
		<div class="<?php echo $merchant_search->RightColumnClass ?>"><div <?php echo $merchant_search->merchanttoaddtip->cellAttributes() ?>>
			<span id="el_merchant_merchanttoaddtip" class="ew-search-field">
<div id="tp_x_merchanttoaddtip" class="ew-template"><input type="radio" class="custom-control-input" data-table="merchant" data-field="x_merchanttoaddtip" data-page="2" data-value-separator="<?php echo $merchant_search->merchanttoaddtip->displayValueSeparatorAttribute() ?>" name="x_merchanttoaddtip" id="x_merchanttoaddtip" value="{value}"<?php echo $merchant_search->merchanttoaddtip->editAttributes() ?>></div>
<div id="dsl_x_merchanttoaddtip" data-repeatcolumn="5" class="ew-item-list d-none"><div>
<?php echo $merchant_search->merchanttoaddtip->radioButtonListHtml(FALSE, "x_merchanttoaddtip", 2) ?>
</div></div>
<?php echo $merchant_search->merchanttoaddtip->Lookup->getParamTag($merchant_search, "p_x_merchanttoaddtip") ?>
</span>
		</div></div>
	</div>
<?php } ?>
<?php if ($merchant_search->pis->Visible) { // pis ?>
	<div id="r_pis" class="form-group row">
		<label for="x_pis" class="<?php echo $merchant_search->LeftColumnClass ?>"><span id="elh_merchant_pis"><?php echo $merchant_search->pis->caption() ?></span>
		<span class="ew-search-operator">
<?php echo $Language->phrase("LIKE") ?>
<input type="hidden" name="z_pis" id="z_pis" value="LIKE">
</span>
		</label>
		<div class="<?php echo $merchant_search->RightColumnClass ?>"><div <?php echo $merchant_search->pis->cellAttributes() ?>>
			<span id="el_merchant_pis" class="ew-search-field">
<input type="text" data-table="merchant" data-field="x_pis" data-page="2" name="x_pis" id="x_pis" size="30" maxlength="100" placeholder="<?php echo HtmlEncode($merchant_search->pis->getPlaceHolder()) ?>" value="<?php echo $merchant_search->pis->EditValue ?>"<?php echo $merchant_search->pis->editAttributes() ?>>
</span>
		</div></div>
	</div>
<?php } ?>
<?php if ($merchant_search->softposid->Visible) { // softposid ?>
	<div id="r_softposid" class="form-group row">
		<label for="x_softposid" class="<?php echo $merchant_search->LeftColumnClass ?>"><span id="elh_merchant_softposid"><?php echo $merchant_search->softposid->caption() ?></span>
		<span class="ew-search-operator">
<?php echo $Language->phrase("LIKE") ?>
<input type="hidden" name="z_softposid" id="z_softposid" value="LIKE">
</span>
		</label>
		<div class="<?php echo $merchant_search->RightColumnClass ?>"><div <?php echo $merchant_search->softposid->cellAttributes() ?>>
			<span id="el_merchant_softposid" class="ew-search-field">
<input type="text" data-table="merchant" data-field="x_softposid" data-page="2" name="x_softposid" id="x_softposid" size="30" maxlength="25" placeholder="<?php echo HtmlEncode($merchant_search->softposid->getPlaceHolder()) ?>" value="<?php echo $merchant_search->softposid->EditValue ?>"<?php echo $merchant_search->softposid->editAttributes() ?>>
</span>
		</div></div>
	</div>
<?php } ?>
<?php if ($merchant_search->taxamount->Visible) { // taxamount ?>
	<div id="r_taxamount" class="form-group row">
		<label for="x_taxamount" class="<?php echo $merchant_search->LeftColumnClass ?>"><span id="elh_merchant_taxamount"><?php echo $merchant_search->taxamount->caption() ?></span>
		<span class="ew-search-operator">
<?php echo $Language->phrase("=") ?>
<input type="hidden" name="z_taxamount" id="z_taxamount" value="=">
</span>
		</label>
		<div class="<?php echo $merchant_search->RightColumnClass ?>"><div <?php echo $merchant_search->taxamount->cellAttributes() ?>>
			<span id="el_merchant_taxamount" class="ew-search-field">
<input type="text" data-table="merchant" data-field="x_taxamount" data-page="2" name="x_taxamount" id="x_taxamount" size="30" placeholder="<?php echo HtmlEncode($merchant_search->taxamount->getPlaceHolder()) ?>" value="<?php echo $merchant_search->taxamount->EditValue ?>"<?php echo $merchant_search->taxamount->editAttributes() ?>>
</span>
		</div></div>
	</div>
<?php } ?>
<?php if ($merchant_search->variabletax->Visible) { // variabletax ?>
	<div id="r_variabletax" class="form-group row">
		<label class="<?php echo $merchant_search->LeftColumnClass ?>"><span id="elh_merchant_variabletax"><?php echo $merchant_search->variabletax->caption() ?></span>
		<span class="ew-search-operator">
<?php echo $Language->phrase("=") ?>
<input type="hidden" name="z_variabletax" id="z_variabletax" value="=">
</span>
		</label>
		<div class="<?php echo $merchant_search->RightColumnClass ?>"><div <?php echo $merchant_search->variabletax->cellAttributes() ?>>
			<span id="el_merchant_variabletax" class="ew-search-field">
<div id="tp_x_variabletax" class="ew-template"><input type="radio" class="custom-control-input" data-table="merchant" data-field="x_variabletax" data-page="2" data-value-separator="<?php echo $merchant_search->variabletax->displayValueSeparatorAttribute() ?>" name="x_variabletax" id="x_variabletax" value="{value}"<?php echo $merchant_search->variabletax->editAttributes() ?>></div>
<div id="dsl_x_variabletax" data-repeatcolumn="5" class="ew-item-list d-none"><div>
<?php echo $merchant_search->variabletax->radioButtonListHtml(FALSE, "x_variabletax", 2) ?>
</div></div>
<?php echo $merchant_search->variabletax->Lookup->getParamTag($merchant_search, "p_x_variabletax") ?>
</span>
		</div></div>
	</div>
<?php } ?>
<?php if ($merchant_search->logofilename->Visible) { // logofilename ?>
	<div id="r_logofilename" class="form-group row">
		<label for="x_logofilename" class="<?php echo $merchant_search->LeftColumnClass ?>"><span id="elh_merchant_logofilename"><?php echo $merchant_search->logofilename->caption() ?></span>
		<span class="ew-search-operator">
<?php echo $Language->phrase("LIKE") ?>
<input type="hidden" name="z_logofilename" id="z_logofilename" value="LIKE">
</span>
		</label>
		<div class="<?php echo $merchant_search->RightColumnClass ?>"><div <?php echo $merchant_search->logofilename->cellAttributes() ?>>
			<span id="el_merchant_logofilename" class="ew-search-field">
<input type="text" data-table="merchant" data-field="x_logofilename" data-page="2" name="x_logofilename" id="x_logofilename" size="30" maxlength="40" placeholder="<?php echo HtmlEncode($merchant_search->logofilename->getPlaceHolder()) ?>" value="<?php echo $merchant_search->logofilename->EditValue ?>"<?php echo $merchant_search->logofilename->editAttributes() ?>>
</span>
		</div></div>
	</div>
<?php } ?>
<?php if ($merchant_search->returndays->Visible) { // returndays ?>
	<div id="r_returndays" class="form-group row">
		<label for="x_returndays" class="<?php echo $merchant_search->LeftColumnClass ?>"><span id="elh_merchant_returndays"><?php echo $merchant_search->returndays->caption() ?></span>
		<span class="ew-search-operator">
<?php echo $Language->phrase("=") ?>
<input type="hidden" name="z_returndays" id="z_returndays" value="=">
</span>
		</label>
		<div class="<?php echo $merchant_search->RightColumnClass ?>"><div <?php echo $merchant_search->returndays->cellAttributes() ?>>
			<span id="el_merchant_returndays" class="ew-search-field">
<input type="text" data-table="merchant" data-field="x_returndays" data-page="2" name="x_returndays" id="x_returndays" size="30" placeholder="<?php echo HtmlEncode($merchant_search->returndays->getPlaceHolder()) ?>" value="<?php echo $merchant_search->returndays->EditValue ?>"<?php echo $merchant_search->returndays->editAttributes() ?>>
</span>
		</div></div>
	</div>
<?php } ?>
<?php if ($merchant_search->memberextrafieldsid->Visible) { // memberextrafieldsid ?>
	<div id="r_memberextrafieldsid" class="form-group row">
		<label for="x_memberextrafieldsid" class="<?php echo $merchant_search->LeftColumnClass ?>"><span id="elh_merchant_memberextrafieldsid"><?php echo $merchant_search->memberextrafieldsid->caption() ?></span>
		<span class="ew-search-operator">
<?php echo $Language->phrase("=") ?>
<input type="hidden" name="z_memberextrafieldsid" id="z_memberextrafieldsid" value="=">
</span>
		</label>
		<div class="<?php echo $merchant_search->RightColumnClass ?>"><div <?php echo $merchant_search->memberextrafieldsid->cellAttributes() ?>>
			<span id="el_merchant_memberextrafieldsid" class="ew-search-field">
<input type="text" data-table="merchant" data-field="x_memberextrafieldsid" data-page="2" name="x_memberextrafieldsid" id="x_memberextrafieldsid" size="30" placeholder="<?php echo HtmlEncode($merchant_search->memberextrafieldsid->getPlaceHolder()) ?>" value="<?php echo $merchant_search->memberextrafieldsid->EditValue ?>"<?php echo $merchant_search->memberextrafieldsid->editAttributes() ?>>
</span>
		</div></div>
	</div>
<?php } ?>
<?php if ($merchant_search->lastupdatedate->Visible) { // lastupdatedate ?>
	<div id="r_lastupdatedate" class="form-group row">
		<label for="x_lastupdatedate" class="<?php echo $merchant_search->LeftColumnClass ?>"><span id="elh_merchant_lastupdatedate"><?php echo $merchant_search->lastupdatedate->caption() ?></span>
		<span class="ew-search-operator">
<?php echo $Language->phrase("=") ?>
<input type="hidden" name="z_lastupdatedate" id="z_lastupdatedate" value="=">
</span>
		</label>
		<div class="<?php echo $merchant_search->RightColumnClass ?>"><div <?php echo $merchant_search->lastupdatedate->cellAttributes() ?>>
			<span id="el_merchant_lastupdatedate" class="ew-search-field">
<input type="text" data-table="merchant" data-field="x_lastupdatedate" data-page="2" name="x_lastupdatedate" id="x_lastupdatedate" placeholder="<?php echo HtmlEncode($merchant_search->lastupdatedate->getPlaceHolder()) ?>" value="<?php echo $merchant_search->lastupdatedate->EditValue ?>"<?php echo $merchant_search->lastupdatedate->editAttributes() ?>>
</span>
		</div></div>
	</div>
<?php } ?>
<?php if ($merchant_search->remmitancetype->Visible) { // remmitancetype ?>
	<div id="r_remmitancetype" class="form-group row">
		<label for="x_remmitancetype" class="<?php echo $merchant_search->LeftColumnClass ?>"><span id="elh_merchant_remmitancetype"><?php echo $merchant_search->remmitancetype->caption() ?></span>
		<span class="ew-search-operator">
<?php echo $Language->phrase("=") ?>
<input type="hidden" name="z_remmitancetype" id="z_remmitancetype" value="=">
</span>
		</label>
		<div class="<?php echo $merchant_search->RightColumnClass ?>"><div <?php echo $merchant_search->remmitancetype->cellAttributes() ?>>
			<span id="el_merchant_remmitancetype" class="ew-search-field">
<div class="input-group">
	<select class="custom-select ew-custom-select" data-table="merchant" data-field="x_remmitancetype" data-page="2" data-value-separator="<?php echo $merchant_search->remmitancetype->displayValueSeparatorAttribute() ?>" id="x_remmitancetype" name="x_remmitancetype"<?php echo $merchant_search->remmitancetype->editAttributes() ?>>
			<?php echo $merchant_search->remmitancetype->selectOptionListHtml("x_remmitancetype") ?>
		</select>
</div>
</span>
		</div></div>
	</div>
<?php } ?>
<?php if ($merchant_search->withholdingtaxaccount->Visible) { // withholdingtaxaccount ?>
	<div id="r_withholdingtaxaccount" class="form-group row">
		<label for="x_withholdingtaxaccount" class="<?php echo $merchant_search->LeftColumnClass ?>"><span id="elh_merchant_withholdingtaxaccount"><?php echo $merchant_search->withholdingtaxaccount->caption() ?></span>
		<span class="ew-search-operator">
<?php echo $Language->phrase("=") ?>
<input type="hidden" name="z_withholdingtaxaccount" id="z_withholdingtaxaccount" value="=">
</span>
		</label>
		<div class="<?php echo $merchant_search->RightColumnClass ?>"><div <?php echo $merchant_search->withholdingtaxaccount->cellAttributes() ?>>
			<span id="el_merchant_withholdingtaxaccount" class="ew-search-field">
<input type="text" data-table="merchant" data-field="x_withholdingtaxaccount" data-page="2" name="x_withholdingtaxaccount" id="x_withholdingtaxaccount" size="30" placeholder="<?php echo HtmlEncode($merchant_search->withholdingtaxaccount->getPlaceHolder()) ?>" value="<?php echo $merchant_search->withholdingtaxaccount->EditValue ?>"<?php echo $merchant_search->withholdingtaxaccount->editAttributes() ?>>
</span>
		</div></div>
	</div>
<?php } ?>
</div><!-- /page* -->
		</div><!-- /multi-page .tab-pane -->
	</div><!-- /multi-page tabs .tab-content -->
</div><!-- /multi-page tabs -->
</div><!-- /multi-page -->
<?php if (!$merchant_search->IsModal) { ?>
<div class="form-group row"><!-- buttons .form-group -->
	<div class="<?php echo $merchant_search->OffsetColumnClass ?>"><!-- buttons offset -->
<button class="btn btn-primary ew-btn" name="btn-action" id="btn-action" type="submit"><?php echo $Language->phrase("Search") ?></button>
<button class="btn btn-default ew-btn" name="btn-reset" id="btn-reset" type="button" onclick="ew.clearForm(this.form);"><?php echo $Language->phrase("Reset") ?></button>
	</div><!-- /buttons offset -->
</div><!-- /buttons .form-group -->
<?php } ?>
</form>
<?php
$merchant_search->showPageFooter();
if (Config("DEBUG"))
	echo GetDebugMessage();
?>
<script>
loadjs.ready("load", function() {

	// Startup script
	// Write your table-specific startup script here
	// console.log("page loaded");

});
</script>
<?php include_once "footer.php"; ?>
<?php
$merchant_search->terminate();
?>