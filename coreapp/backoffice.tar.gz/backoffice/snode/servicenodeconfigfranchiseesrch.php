<?php
namespace PHPMaker2020\_4payadmin;

// Autoload
include_once "autoload.php";

// Session
if (session_status() !== PHP_SESSION_ACTIVE)
	\Delight\Cookie\Session::start(Config("COOKIE_SAMESITE")); // Init session data

// Output buffering
ob_start();
?>
<?php

// Write header
WriteHeader(FALSE);

// Create page object
$servicenodeconfigfranchisee_search = new servicenodeconfigfranchisee_search();

// Run the page
$servicenodeconfigfranchisee_search->run();

// Setup login status
SetupLoginStatus();
SetClientVar("login", LoginStatus());

// Global Page Rendering event (in userfn*.php)
Page_Rendering();

// Page Rendering event
$servicenodeconfigfranchisee_search->Page_Render();
?>
<?php include_once "header.php"; ?>
<script>
var fservicenodeconfigfranchiseesearch, currentPageID;
loadjs.ready("head", function() {

	// Form object for search
	<?php if ($servicenodeconfigfranchisee_search->IsModal) { ?>
	fservicenodeconfigfranchiseesearch = currentAdvancedSearchForm = new ew.Form("fservicenodeconfigfranchiseesearch", "search");
	<?php } else { ?>
	fservicenodeconfigfranchiseesearch = currentForm = new ew.Form("fservicenodeconfigfranchiseesearch", "search");
	<?php } ?>
	currentPageID = ew.PAGE_ID = "search";

	// Validate function for search
	fservicenodeconfigfranchiseesearch.validate = function(fobj) {
		if (!this.validateRequired)
			return true; // Ignore validation
		fobj = fobj || this._form;
		var infix = "";
		elm = this.getElements("x" + infix + "_configID");
		if (elm && !ew.checkInteger(elm.value))
			return this.onError(elm, "<?php echo JsEncode($servicenodeconfigfranchisee_search->configID->errorMessage()) ?>");
		elm = this.getElements("x" + infix + "_franchiseeid");
		if (elm && !ew.checkInteger(elm.value))
			return this.onError(elm, "<?php echo JsEncode($servicenodeconfigfranchisee_search->franchiseeid->errorMessage()) ?>");

		// Call Form_CustomValidate event
		if (!this.Form_CustomValidate(fobj))
			return false;
		return true;
	}

	// Form_CustomValidate
	fservicenodeconfigfranchiseesearch.Form_CustomValidate = function(fobj) { // DO NOT CHANGE THIS LINE!

		// Your custom validation code here, return false if invalid.
		return true;
	}

	// Use JavaScript validation or not
	fservicenodeconfigfranchiseesearch.validateRequired = <?php echo Config("CLIENT_VALIDATE") ? "true" : "false" ?>;

	// Dynamic selection lists
	loadjs.done("fservicenodeconfigfranchiseesearch");
});
</script>
<script>
loadjs.ready("head", function() {

	// Client script
	// Write your client script here, no need to add script tags.

});
</script>
<?php $servicenodeconfigfranchisee_search->showPageHeader(); ?>
<?php
$servicenodeconfigfranchisee_search->showMessage();
?>
<form name="fservicenodeconfigfranchiseesearch" id="fservicenodeconfigfranchiseesearch" class="<?php echo $servicenodeconfigfranchisee_search->FormClassName ?>" action="<?php echo CurrentPageName() ?>" method="post">
<?php if ($Page->CheckToken) { ?>
<input type="hidden" name="<?php echo Config("TOKEN_NAME") ?>" value="<?php echo $Page->Token ?>">
<?php } ?>
<input type="hidden" name="t" value="servicenodeconfigfranchisee">
<input type="hidden" name="action" id="action" value="search">
<input type="hidden" name="modal" value="<?php echo (int)$servicenodeconfigfranchisee_search->IsModal ?>">
<div class="ew-search-div"><!-- page* -->
<?php if ($servicenodeconfigfranchisee_search->configID->Visible) { // configID ?>
	<div id="r_configID" class="form-group row">
		<label for="x_configID" class="<?php echo $servicenodeconfigfranchisee_search->LeftColumnClass ?>"><span id="elh_servicenodeconfigfranchisee_configID"><?php echo $servicenodeconfigfranchisee_search->configID->caption() ?></span>
		<span class="ew-search-operator">
<?php echo $Language->phrase("=") ?>
<input type="hidden" name="z_configID" id="z_configID" value="=">
</span>
		</label>
		<div class="<?php echo $servicenodeconfigfranchisee_search->RightColumnClass ?>"><div <?php echo $servicenodeconfigfranchisee_search->configID->cellAttributes() ?>>
			<span id="el_servicenodeconfigfranchisee_configID" class="ew-search-field">
<input type="text" data-table="servicenodeconfigfranchisee" data-field="x_configID" name="x_configID" id="x_configID" placeholder="<?php echo HtmlEncode($servicenodeconfigfranchisee_search->configID->getPlaceHolder()) ?>" value="<?php echo $servicenodeconfigfranchisee_search->configID->EditValue ?>"<?php echo $servicenodeconfigfranchisee_search->configID->editAttributes() ?>>
</span>
		</div></div>
	</div>
<?php } ?>
<?php if ($servicenodeconfigfranchisee_search->franchiseeid->Visible) { // franchiseeid ?>
	<div id="r_franchiseeid" class="form-group row">
		<label for="x_franchiseeid" class="<?php echo $servicenodeconfigfranchisee_search->LeftColumnClass ?>"><span id="elh_servicenodeconfigfranchisee_franchiseeid"><?php echo $servicenodeconfigfranchisee_search->franchiseeid->caption() ?></span>
		<span class="ew-search-operator">
<?php echo $Language->phrase("=") ?>
<input type="hidden" name="z_franchiseeid" id="z_franchiseeid" value="=">
</span>
		</label>
		<div class="<?php echo $servicenodeconfigfranchisee_search->RightColumnClass ?>"><div <?php echo $servicenodeconfigfranchisee_search->franchiseeid->cellAttributes() ?>>
			<span id="el_servicenodeconfigfranchisee_franchiseeid" class="ew-search-field">
<input type="text" data-table="servicenodeconfigfranchisee" data-field="x_franchiseeid" name="x_franchiseeid" id="x_franchiseeid" size="30" placeholder="<?php echo HtmlEncode($servicenodeconfigfranchisee_search->franchiseeid->getPlaceHolder()) ?>" value="<?php echo $servicenodeconfigfranchisee_search->franchiseeid->EditValue ?>"<?php echo $servicenodeconfigfranchisee_search->franchiseeid->editAttributes() ?>>
</span>
		</div></div>
	</div>
<?php } ?>
<?php if ($servicenodeconfigfranchisee_search->value1->Visible) { // value1 ?>
	<div id="r_value1" class="form-group row">
		<label for="x_value1" class="<?php echo $servicenodeconfigfranchisee_search->LeftColumnClass ?>"><span id="elh_servicenodeconfigfranchisee_value1"><?php echo $servicenodeconfigfranchisee_search->value1->caption() ?></span>
		<span class="ew-search-operator">
<?php echo $Language->phrase("LIKE") ?>
<input type="hidden" name="z_value1" id="z_value1" value="LIKE">
</span>
		</label>
		<div class="<?php echo $servicenodeconfigfranchisee_search->RightColumnClass ?>"><div <?php echo $servicenodeconfigfranchisee_search->value1->cellAttributes() ?>>
			<span id="el_servicenodeconfigfranchisee_value1" class="ew-search-field">
<input type="text" data-table="servicenodeconfigfranchisee" data-field="x_value1" name="x_value1" id="x_value1" size="30" maxlength="200" placeholder="<?php echo HtmlEncode($servicenodeconfigfranchisee_search->value1->getPlaceHolder()) ?>" value="<?php echo $servicenodeconfigfranchisee_search->value1->EditValue ?>"<?php echo $servicenodeconfigfranchisee_search->value1->editAttributes() ?>>
</span>
		</div></div>
	</div>
<?php } ?>
<?php if ($servicenodeconfigfranchisee_search->value2->Visible) { // value2 ?>
	<div id="r_value2" class="form-group row">
		<label for="x_value2" class="<?php echo $servicenodeconfigfranchisee_search->LeftColumnClass ?>"><span id="elh_servicenodeconfigfranchisee_value2"><?php echo $servicenodeconfigfranchisee_search->value2->caption() ?></span>
		<span class="ew-search-operator">
<?php echo $Language->phrase("LIKE") ?>
<input type="hidden" name="z_value2" id="z_value2" value="LIKE">
</span>
		</label>
		<div class="<?php echo $servicenodeconfigfranchisee_search->RightColumnClass ?>"><div <?php echo $servicenodeconfigfranchisee_search->value2->cellAttributes() ?>>
			<span id="el_servicenodeconfigfranchisee_value2" class="ew-search-field">
<input type="text" data-table="servicenodeconfigfranchisee" data-field="x_value2" name="x_value2" id="x_value2" size="30" maxlength="200" placeholder="<?php echo HtmlEncode($servicenodeconfigfranchisee_search->value2->getPlaceHolder()) ?>" value="<?php echo $servicenodeconfigfranchisee_search->value2->EditValue ?>"<?php echo $servicenodeconfigfranchisee_search->value2->editAttributes() ?>>
</span>
		</div></div>
	</div>
<?php } ?>
<?php if ($servicenodeconfigfranchisee_search->value3->Visible) { // value3 ?>
	<div id="r_value3" class="form-group row">
		<label for="x_value3" class="<?php echo $servicenodeconfigfranchisee_search->LeftColumnClass ?>"><span id="elh_servicenodeconfigfranchisee_value3"><?php echo $servicenodeconfigfranchisee_search->value3->caption() ?></span>
		<span class="ew-search-operator">
<?php echo $Language->phrase("LIKE") ?>
<input type="hidden" name="z_value3" id="z_value3" value="LIKE">
</span>
		</label>
		<div class="<?php echo $servicenodeconfigfranchisee_search->RightColumnClass ?>"><div <?php echo $servicenodeconfigfranchisee_search->value3->cellAttributes() ?>>
			<span id="el_servicenodeconfigfranchisee_value3" class="ew-search-field">
<input type="text" data-table="servicenodeconfigfranchisee" data-field="x_value3" name="x_value3" id="x_value3" size="30" maxlength="200" placeholder="<?php echo HtmlEncode($servicenodeconfigfranchisee_search->value3->getPlaceHolder()) ?>" value="<?php echo $servicenodeconfigfranchisee_search->value3->EditValue ?>"<?php echo $servicenodeconfigfranchisee_search->value3->editAttributes() ?>>
</span>
		</div></div>
	</div>
<?php } ?>
</div><!-- /page* -->
<?php if (!$servicenodeconfigfranchisee_search->IsModal) { ?>
<div class="form-group row"><!-- buttons .form-group -->
	<div class="<?php echo $servicenodeconfigfranchisee_search->OffsetColumnClass ?>"><!-- buttons offset -->
<button class="btn btn-primary ew-btn" name="btn-action" id="btn-action" type="submit"><?php echo $Language->phrase("Search") ?></button>
<button class="btn btn-default ew-btn" name="btn-reset" id="btn-reset" type="button" onclick="ew.clearForm(this.form);"><?php echo $Language->phrase("Reset") ?></button>
	</div><!-- /buttons offset -->
</div><!-- /buttons .form-group -->
<?php } ?>
</form>
<?php
$servicenodeconfigfranchisee_search->showPageFooter();
if (Config("DEBUG"))
	echo GetDebugMessage();
?>
<script>
loadjs.ready("load", function() {

	// Startup script
	// Write your table-specific startup script here
	// console.log("page loaded");

});
</script>
<?php include_once "footer.php"; ?>
<?php
$servicenodeconfigfranchisee_search->terminate();
?>