<?php
namespace PHPMaker2020\_4payadmin;

// Autoload
include_once "autoload.php";

// Session
if (session_status() !== PHP_SESSION_ACTIVE)
	\Delight\Cookie\Session::start(Config("COOKIE_SAMESITE")); // Init session data

// Output buffering
ob_start();
?>
<?php

// Write header
WriteHeader(FALSE);

// Create page object
$invoices_delete = new invoices_delete();

// Run the page
$invoices_delete->run();

// Setup login status
SetupLoginStatus();
SetClientVar("login", LoginStatus());

// Global Page Rendering event (in userfn*.php)
Page_Rendering();

// Page Rendering event
$invoices_delete->Page_Render();
?>
<?php include_once "header.php"; ?>
<script>
var finvoicesdelete, currentPageID;
loadjs.ready("head", function() {

	// Form object
	currentPageID = ew.PAGE_ID = "delete";
	finvoicesdelete = currentForm = new ew.Form("finvoicesdelete", "delete");
	loadjs.done("finvoicesdelete");
});
</script>
<script>
loadjs.ready("head", function() {

	// Client script
	// Write your client script here, no need to add script tags.

});
</script>
<?php $invoices_delete->showPageHeader(); ?>
<?php
$invoices_delete->showMessage();
?>
<form name="finvoicesdelete" id="finvoicesdelete" class="form-inline ew-form ew-delete-form" action="<?php echo CurrentPageName() ?>" method="post">
<?php if ($Page->CheckToken) { ?>
<input type="hidden" name="<?php echo Config("TOKEN_NAME") ?>" value="<?php echo $Page->Token ?>">
<?php } ?>
<input type="hidden" name="t" value="invoices">
<input type="hidden" name="action" id="action" value="delete">
<?php foreach ($invoices_delete->RecKeys as $key) { ?>
<?php $keyvalue = is_array($key) ? implode(Config("COMPOSITE_KEY_SEPARATOR"), $key) : $key; ?>
<input type="hidden" name="key_m[]" value="<?php echo HtmlEncode($keyvalue) ?>">
<?php } ?>
<div class="card ew-card ew-grid">
<div class="<?php echo ResponsiveTableClass() ?>card-body ew-grid-middle-panel">
<table class="table ew-table">
	<thead>
	<tr class="ew-table-header">
<?php if ($invoices_delete->invoiceid->Visible) { // invoiceid ?>
		<th class="<?php echo $invoices_delete->invoiceid->headerCellClass() ?>"><span id="elh_invoices_invoiceid" class="invoices_invoiceid"><?php echo $invoices_delete->invoiceid->caption() ?></span></th>
<?php } ?>
<?php if ($invoices_delete->invoicerefno->Visible) { // invoicerefno ?>
		<th class="<?php echo $invoices_delete->invoicerefno->headerCellClass() ?>"><span id="elh_invoices_invoicerefno" class="invoices_invoicerefno"><?php echo $invoices_delete->invoicerefno->caption() ?></span></th>
<?php } ?>
<?php if ($invoices_delete->invoicedate->Visible) { // invoicedate ?>
		<th class="<?php echo $invoices_delete->invoicedate->headerCellClass() ?>"><span id="elh_invoices_invoicedate" class="invoices_invoicedate"><?php echo $invoices_delete->invoicedate->caption() ?></span></th>
<?php } ?>
<?php if ($invoices_delete->duedate->Visible) { // duedate ?>
		<th class="<?php echo $invoices_delete->duedate->headerCellClass() ?>"><span id="elh_invoices_duedate" class="invoices_duedate"><?php echo $invoices_delete->duedate->caption() ?></span></th>
<?php } ?>
<?php if ($invoices_delete->merchantid->Visible) { // merchantid ?>
		<th class="<?php echo $invoices_delete->merchantid->headerCellClass() ?>"><span id="elh_invoices_merchantid" class="invoices_merchantid"><?php echo $invoices_delete->merchantid->caption() ?></span></th>
<?php } ?>
<?php if ($invoices_delete->currencycode->Visible) { // currencycode ?>
		<th class="<?php echo $invoices_delete->currencycode->headerCellClass() ?>"><span id="elh_invoices_currencycode" class="invoices_currencycode"><?php echo $invoices_delete->currencycode->caption() ?></span></th>
<?php } ?>
<?php if ($invoices_delete->currencycodesettlement->Visible) { // currencycodesettlement ?>
		<th class="<?php echo $invoices_delete->currencycodesettlement->headerCellClass() ?>"><span id="elh_invoices_currencycodesettlement" class="invoices_currencycodesettlement"><?php echo $invoices_delete->currencycodesettlement->caption() ?></span></th>
<?php } ?>
<?php if ($invoices_delete->status->Visible) { // status ?>
		<th class="<?php echo $invoices_delete->status->headerCellClass() ?>"><span id="elh_invoices_status" class="invoices_status"><?php echo $invoices_delete->status->caption() ?></span></th>
<?php } ?>
<?php if ($invoices_delete->customstatus->Visible) { // customstatus ?>
		<th class="<?php echo $invoices_delete->customstatus->headerCellClass() ?>"><span id="elh_invoices_customstatus" class="invoices_customstatus"><?php echo $invoices_delete->customstatus->caption() ?></span></th>
<?php } ?>
<?php if ($invoices_delete->amount->Visible) { // amount ?>
		<th class="<?php echo $invoices_delete->amount->headerCellClass() ?>"><span id="elh_invoices_amount" class="invoices_amount"><?php echo $invoices_delete->amount->caption() ?></span></th>
<?php } ?>
<?php if ($invoices_delete->paid->Visible) { // paid ?>
		<th class="<?php echo $invoices_delete->paid->headerCellClass() ?>"><span id="elh_invoices_paid" class="invoices_paid"><?php echo $invoices_delete->paid->caption() ?></span></th>
<?php } ?>
	</tr>
	</thead>
	<tbody>
<?php
$invoices_delete->RecordCount = 0;
$i = 0;
while (!$invoices_delete->Recordset->EOF) {
	$invoices_delete->RecordCount++;
	$invoices_delete->RowCount++;

	// Set row properties
	$invoices->resetAttributes();
	$invoices->RowType = ROWTYPE_VIEW; // View

	// Get the field contents
	$invoices_delete->loadRowValues($invoices_delete->Recordset);

	// Render row
	$invoices_delete->renderRow();
?>
	<tr <?php echo $invoices->rowAttributes() ?>>
<?php if ($invoices_delete->invoiceid->Visible) { // invoiceid ?>
		<td <?php echo $invoices_delete->invoiceid->cellAttributes() ?>>
<span id="el<?php echo $invoices_delete->RowCount ?>_invoices_invoiceid" class="invoices_invoiceid">
<span<?php echo $invoices_delete->invoiceid->viewAttributes() ?>><?php echo $invoices_delete->invoiceid->getViewValue() ?></span>
</span>
</td>
<?php } ?>
<?php if ($invoices_delete->invoicerefno->Visible) { // invoicerefno ?>
		<td <?php echo $invoices_delete->invoicerefno->cellAttributes() ?>>
<span id="el<?php echo $invoices_delete->RowCount ?>_invoices_invoicerefno" class="invoices_invoicerefno">
<span<?php echo $invoices_delete->invoicerefno->viewAttributes() ?>><?php echo $invoices_delete->invoicerefno->getViewValue() ?></span>
</span>
</td>
<?php } ?>
<?php if ($invoices_delete->invoicedate->Visible) { // invoicedate ?>
		<td <?php echo $invoices_delete->invoicedate->cellAttributes() ?>>
<span id="el<?php echo $invoices_delete->RowCount ?>_invoices_invoicedate" class="invoices_invoicedate">
<span<?php echo $invoices_delete->invoicedate->viewAttributes() ?>><?php echo $invoices_delete->invoicedate->getViewValue() ?></span>
</span>
</td>
<?php } ?>
<?php if ($invoices_delete->duedate->Visible) { // duedate ?>
		<td <?php echo $invoices_delete->duedate->cellAttributes() ?>>
<span id="el<?php echo $invoices_delete->RowCount ?>_invoices_duedate" class="invoices_duedate">
<span<?php echo $invoices_delete->duedate->viewAttributes() ?>><?php echo $invoices_delete->duedate->getViewValue() ?></span>
</span>
</td>
<?php } ?>
<?php if ($invoices_delete->merchantid->Visible) { // merchantid ?>
		<td <?php echo $invoices_delete->merchantid->cellAttributes() ?>>
<span id="el<?php echo $invoices_delete->RowCount ?>_invoices_merchantid" class="invoices_merchantid">
<span<?php echo $invoices_delete->merchantid->viewAttributes() ?>><?php echo $invoices_delete->merchantid->getViewValue() ?></span>
</span>
</td>
<?php } ?>
<?php if ($invoices_delete->currencycode->Visible) { // currencycode ?>
		<td <?php echo $invoices_delete->currencycode->cellAttributes() ?>>
<span id="el<?php echo $invoices_delete->RowCount ?>_invoices_currencycode" class="invoices_currencycode">
<span<?php echo $invoices_delete->currencycode->viewAttributes() ?>><?php echo $invoices_delete->currencycode->getViewValue() ?></span>
</span>
</td>
<?php } ?>
<?php if ($invoices_delete->currencycodesettlement->Visible) { // currencycodesettlement ?>
		<td <?php echo $invoices_delete->currencycodesettlement->cellAttributes() ?>>
<span id="el<?php echo $invoices_delete->RowCount ?>_invoices_currencycodesettlement" class="invoices_currencycodesettlement">
<span<?php echo $invoices_delete->currencycodesettlement->viewAttributes() ?>><?php echo $invoices_delete->currencycodesettlement->getViewValue() ?></span>
</span>
</td>
<?php } ?>
<?php if ($invoices_delete->status->Visible) { // status ?>
		<td <?php echo $invoices_delete->status->cellAttributes() ?>>
<span id="el<?php echo $invoices_delete->RowCount ?>_invoices_status" class="invoices_status">
<span<?php echo $invoices_delete->status->viewAttributes() ?>><?php echo $invoices_delete->status->getViewValue() ?></span>
</span>
</td>
<?php } ?>
<?php if ($invoices_delete->customstatus->Visible) { // customstatus ?>
		<td <?php echo $invoices_delete->customstatus->cellAttributes() ?>>
<span id="el<?php echo $invoices_delete->RowCount ?>_invoices_customstatus" class="invoices_customstatus">
<span<?php echo $invoices_delete->customstatus->viewAttributes() ?>><?php echo $invoices_delete->customstatus->getViewValue() ?></span>
</span>
</td>
<?php } ?>
<?php if ($invoices_delete->amount->Visible) { // amount ?>
		<td <?php echo $invoices_delete->amount->cellAttributes() ?>>
<span id="el<?php echo $invoices_delete->RowCount ?>_invoices_amount" class="invoices_amount">
<span<?php echo $invoices_delete->amount->viewAttributes() ?>><?php echo $invoices_delete->amount->getViewValue() ?></span>
</span>
</td>
<?php } ?>
<?php if ($invoices_delete->paid->Visible) { // paid ?>
		<td <?php echo $invoices_delete->paid->cellAttributes() ?>>
<span id="el<?php echo $invoices_delete->RowCount ?>_invoices_paid" class="invoices_paid">
<span<?php echo $invoices_delete->paid->viewAttributes() ?>><?php echo $invoices_delete->paid->getViewValue() ?></span>
</span>
</td>
<?php } ?>
	</tr>
<?php
	$invoices_delete->Recordset->moveNext();
}
$invoices_delete->Recordset->close();
?>
</tbody>
</table>
</div>
</div>
<div>
<button class="btn btn-primary ew-btn" name="btn-action" id="btn-action" type="submit"><?php echo $Language->phrase("DeleteBtn") ?></button>
<button class="btn btn-default ew-btn" name="btn-cancel" id="btn-cancel" type="button" data-href="<?php echo $invoices_delete->getReturnUrl() ?>"><?php echo $Language->phrase("CancelBtn") ?></button>
</div>
</form>
<?php
$invoices_delete->showPageFooter();
if (Config("DEBUG"))
	echo GetDebugMessage();
?>
<script>
loadjs.ready("load", function() {

	// Startup script
	// Write your table-specific startup script here
	// console.log("page loaded");

});
</script>
<?php include_once "footer.php"; ?>
<?php
$invoices_delete->terminate();
?>