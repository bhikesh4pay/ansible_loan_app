<?php
namespace PHPMaker2020\_4payadmin;

// Autoload
include_once "autoload.php";

// Session
if (session_status() !== PHP_SESSION_ACTIVE)
	\Delight\Cookie\Session::start(Config("COOKIE_SAMESITE")); // Init session data

// Output buffering
ob_start();
?>
<?php

// Write header
WriteHeader(FALSE);

// Create page object
$user_search = new user_search();

// Run the page
$user_search->run();

// Setup login status
SetupLoginStatus();
SetClientVar("login", LoginStatus());

// Global Page Rendering event (in userfn*.php)
Page_Rendering();

// Page Rendering event
$user_search->Page_Render();
?>
<?php include_once "header.php"; ?>
<script>
var fusersearch, currentPageID;
loadjs.ready("head", function() {

	// Form object for search
	<?php if ($user_search->IsModal) { ?>
	fusersearch = currentAdvancedSearchForm = new ew.Form("fusersearch", "search");
	<?php } else { ?>
	fusersearch = currentForm = new ew.Form("fusersearch", "search");
	<?php } ?>
	currentPageID = ew.PAGE_ID = "search";

	// Validate function for search
	fusersearch.validate = function(fobj) {
		if (!this.validateRequired)
			return true; // Ignore validation
		fobj = fobj || this._form;
		var infix = "";
		elm = this.getElements("x" + infix + "_id");
		if (elm && !ew.checkInteger(elm.value))
			return this.onError(elm, "<?php echo JsEncode($user_search->id->errorMessage()) ?>");
		elm = this.getElements("x" + infix + "_franchiseeID");
		if (elm && !ew.checkInteger(elm.value))
			return this.onError(elm, "<?php echo JsEncode($user_search->franchiseeID->errorMessage()) ?>");
		elm = this.getElements("x" + infix + "_dateAdded");
		if (elm && !ew.checkDateDef(elm.value))
			return this.onError(elm, "<?php echo JsEncode($user_search->dateAdded->errorMessage()) ?>");
		elm = this.getElements("x" + infix + "_challengeq1");
		if (elm && !ew.checkInteger(elm.value))
			return this.onError(elm, "<?php echo JsEncode($user_search->challengeq1->errorMessage()) ?>");
		elm = this.getElements("x" + infix + "_challengeq2");
		if (elm && !ew.checkInteger(elm.value))
			return this.onError(elm, "<?php echo JsEncode($user_search->challengeq2->errorMessage()) ?>");
		elm = this.getElements("x" + infix + "_challengeq3");
		if (elm && !ew.checkInteger(elm.value))
			return this.onError(elm, "<?php echo JsEncode($user_search->challengeq3->errorMessage()) ?>");
		elm = this.getElements("x" + infix + "_passwordCounter");
		if (elm && !ew.checkInteger(elm.value))
			return this.onError(elm, "<?php echo JsEncode($user_search->passwordCounter->errorMessage()) ?>");
		elm = this.getElements("x" + infix + "_passwordChangedDate");
		if (elm && !ew.checkDateDef(elm.value))
			return this.onError(elm, "<?php echo JsEncode($user_search->passwordChangedDate->errorMessage()) ?>");
		elm = this.getElements("x" + infix + "_pinCounter");
		if (elm && !ew.checkInteger(elm.value))
			return this.onError(elm, "<?php echo JsEncode($user_search->pinCounter->errorMessage()) ?>");
		elm = this.getElements("x" + infix + "_markedfordeletion");
		if (elm && !ew.checkDateDef(elm.value))
			return this.onError(elm, "<?php echo JsEncode($user_search->markedfordeletion->errorMessage()) ?>");
		elm = this.getElements("x" + infix + "_accountID");
		if (elm && !ew.checkInteger(elm.value))
			return this.onError(elm, "<?php echo JsEncode($user_search->accountID->errorMessage()) ?>");
		elm = this.getElements("x" + infix + "_brokerid");
		if (elm && !ew.checkInteger(elm.value))
			return this.onError(elm, "<?php echo JsEncode($user_search->brokerid->errorMessage()) ?>");
		elm = this.getElements("x" + infix + "_parentuserid");
		if (elm && !ew.checkInteger(elm.value))
			return this.onError(elm, "<?php echo JsEncode($user_search->parentuserid->errorMessage()) ?>");
		elm = this.getElements("x" + infix + "_jumpappid");
		if (elm && !ew.checkInteger(elm.value))
			return this.onError(elm, "<?php echo JsEncode($user_search->jumpappid->errorMessage()) ?>");
		elm = this.getElements("x" + infix + "_dateofbirth");
		if (elm && !ew.checkDateDef(elm.value))
			return this.onError(elm, "<?php echo JsEncode($user_search->dateofbirth->errorMessage()) ?>");
		elm = this.getElements("x" + infix + "_lastupdatedate");
		if (elm && !ew.checkDateDef(elm.value))
			return this.onError(elm, "<?php echo JsEncode($user_search->lastupdatedate->errorMessage()) ?>");
		elm = this.getElements("x" + infix + "_mincashamount");
		if (elm && !ew.checkNumber(elm.value))
			return this.onError(elm, "<?php echo JsEncode($user_search->mincashamount->errorMessage()) ?>");
		elm = this.getElements("x" + infix + "_maxcashamount");
		if (elm && !ew.checkNumber(elm.value))
			return this.onError(elm, "<?php echo JsEncode($user_search->maxcashamount->errorMessage()) ?>");
		elm = this.getElements("x" + infix + "_maxtransferinamount");
		if (elm && !ew.checkNumber(elm.value))
			return this.onError(elm, "<?php echo JsEncode($user_search->maxtransferinamount->errorMessage()) ?>");
		elm = this.getElements("x" + infix + "_maxtransferoutamount");
		if (elm && !ew.checkNumber(elm.value))
			return this.onError(elm, "<?php echo JsEncode($user_search->maxtransferoutamount->errorMessage()) ?>");
		elm = this.getElements("x" + infix + "_legalid");
		if (elm && !ew.checkInteger(elm.value))
			return this.onError(elm, "<?php echo JsEncode($user_search->legalid->errorMessage()) ?>");
		elm = this.getElements("x" + infix + "_lastmsgid");
		if (elm && !ew.checkInteger(elm.value))
			return this.onError(elm, "<?php echo JsEncode($user_search->lastmsgid->errorMessage()) ?>");
		elm = this.getElements("x" + infix + "_otprequiredforphysicalcards");
		if (elm && !ew.checkInteger(elm.value))
			return this.onError(elm, "<?php echo JsEncode($user_search->otprequiredforphysicalcards->errorMessage()) ?>");
		elm = this.getElements("x" + infix + "_otpvaliduntil");
		if (elm && !ew.checkDateDef(elm.value))
			return this.onError(elm, "<?php echo JsEncode($user_search->otpvaliduntil->errorMessage()) ?>");
		elm = this.getElements("x" + infix + "_accountopeningdate");
		if (elm && !ew.checkDateDef(elm.value))
			return this.onError(elm, "<?php echo JsEncode($user_search->accountopeningdate->errorMessage()) ?>");
		elm = this.getElements("x" + infix + "_lastprofilestatuschangedate");
		if (elm && !ew.checkDateDef(elm.value))
			return this.onError(elm, "<?php echo JsEncode($user_search->lastprofilestatuschangedate->errorMessage()) ?>");

		// Call Form_CustomValidate event
		if (!this.Form_CustomValidate(fobj))
			return false;
		return true;
	}

	// Form_CustomValidate
	fusersearch.Form_CustomValidate = function(fobj) { // DO NOT CHANGE THIS LINE!

		// Your custom validation code here, return false if invalid.
		return true;
	}

	// Use JavaScript validation or not
	fusersearch.validateRequired = <?php echo Config("CLIENT_VALIDATE") ? "true" : "false" ?>;

	// Dynamic selection lists
	fusersearch.lists["x_passwordRequireChange"] = <?php echo $user_search->passwordRequireChange->Lookup->toClientList($user_search) ?>;
	fusersearch.lists["x_passwordRequireChange"].options = <?php echo JsonEncode($user_search->passwordRequireChange->lookupOptions()) ?>;
	fusersearch.lists["x_timezoneid"] = <?php echo $user_search->timezoneid->Lookup->toClientList($user_search) ?>;
	fusersearch.lists["x_timezoneid"].options = <?php echo JsonEncode($user_search->timezoneid->lookupOptions()) ?>;
	fusersearch.lists["x_telephoneverified"] = <?php echo $user_search->telephoneverified->Lookup->toClientList($user_search) ?>;
	fusersearch.lists["x_telephoneverified"].options = <?php echo JsonEncode($user_search->telephoneverified->lookupOptions()) ?>;
	fusersearch.lists["x_telephonereceivemessage"] = <?php echo $user_search->telephonereceivemessage->Lookup->toClientList($user_search) ?>;
	fusersearch.lists["x_telephonereceivemessage"].options = <?php echo JsonEncode($user_search->telephonereceivemessage->lookupOptions()) ?>;
	fusersearch.lists["x_countryid"] = <?php echo $user_search->countryid->Lookup->toClientList($user_search) ?>;
	fusersearch.lists["x_countryid"].options = <?php echo JsonEncode($user_search->countryid->lookupOptions()) ?>;
	fusersearch.lists["x_stateid"] = <?php echo $user_search->stateid->Lookup->toClientList($user_search) ?>;
	fusersearch.lists["x_stateid"].options = <?php echo JsonEncode($user_search->stateid->lookupOptions()) ?>;
	fusersearch.lists["x_defaultcurrency"] = <?php echo $user_search->defaultcurrency->Lookup->toClientList($user_search) ?>;
	fusersearch.lists["x_defaultcurrency"].options = <?php echo JsonEncode($user_search->defaultcurrency->lookupOptions()) ?>;
	fusersearch.lists["x_langID"] = <?php echo $user_search->langID->Lookup->toClientList($user_search) ?>;
	fusersearch.lists["x_langID"].options = <?php echo JsonEncode($user_search->langID->lookupOptions()) ?>;
	fusersearch.lists["x_status"] = <?php echo $user_search->status->Lookup->toClientList($user_search) ?>;
	fusersearch.lists["x_status"].options = <?php echo JsonEncode($user_search->status->lookupOptions()) ?>;
	fusersearch.lists["x_userType"] = <?php echo $user_search->userType->Lookup->toClientList($user_search) ?>;
	fusersearch.lists["x_userType"].options = <?php echo JsonEncode($user_search->userType->lookupOptions()) ?>;
	fusersearch.lists["x_usersubtype"] = <?php echo $user_search->usersubtype->Lookup->toClientList($user_search) ?>;
	fusersearch.lists["x_usersubtype"].options = <?php echo JsonEncode($user_search->usersubtype->lookupOptions()) ?>;
	fusersearch.lists["x_corporate"] = <?php echo $user_search->corporate->Lookup->toClientList($user_search) ?>;
	fusersearch.lists["x_corporate"].options = <?php echo JsonEncode($user_search->corporate->lookupOptions()) ?>;
	fusersearch.lists["x_profilestatus"] = <?php echo $user_search->profilestatus->Lookup->toClientList($user_search) ?>;
	fusersearch.lists["x_profilestatus"].options = <?php echo JsonEncode($user_search->profilestatus->lookupOptions()) ?>;
	fusersearch.lists["x_gender"] = <?php echo $user_search->gender->Lookup->toClientList($user_search) ?>;
	fusersearch.lists["x_gender"].options = <?php echo JsonEncode($user_search->gender->lookupOptions()) ?>;
	fusersearch.lists["x_jumprequiredatlogin"] = <?php echo $user_search->jumprequiredatlogin->Lookup->toClientList($user_search) ?>;
	fusersearch.lists["x_jumprequiredatlogin"].options = <?php echo JsonEncode($user_search->jumprequiredatlogin->lookupOptions()) ?>;
	fusersearch.lists["x_ccbypass"] = <?php echo $user_search->ccbypass->Lookup->toClientList($user_search) ?>;
	fusersearch.lists["x_ccbypass"].options = <?php echo JsonEncode($user_search->ccbypass->lookupOptions()) ?>;
	fusersearch.lists["x_userpiview"] = <?php echo $user_search->userpiview->Lookup->toClientList($user_search) ?>;
	fusersearch.lists["x_userpiview"].options = <?php echo JsonEncode($user_search->userpiview->lookupOptions()) ?>;
	fusersearch.lists["x_nationalitycountry"] = <?php echo $user_search->nationalitycountry->Lookup->toClientList($user_search) ?>;
	fusersearch.lists["x_nationalitycountry"].options = <?php echo JsonEncode($user_search->nationalitycountry->lookupOptions()) ?>;
	fusersearch.lists["x_classification"] = <?php echo $user_search->classification->Lookup->toClientList($user_search) ?>;
	fusersearch.lists["x_classification"].options = <?php echo JsonEncode($user_search->classification->lookupOptions()) ?>;
	fusersearch.lists["x_occupation"] = <?php echo $user_search->occupation->Lookup->toClientList($user_search) ?>;
	fusersearch.lists["x_occupation"].options = <?php echo JsonEncode($user_search->occupation->lookupOptions()) ?>;
	fusersearch.autoSuggests["x_occupation"] = <?php echo json_encode(["data" => "ajax=autosuggest"]) ?>;
	fusersearch.lists["x_sourceofincome"] = <?php echo $user_search->sourceofincome->Lookup->toClientList($user_search) ?>;
	fusersearch.lists["x_sourceofincome"].options = <?php echo JsonEncode($user_search->sourceofincome->lookupOptions()) ?>;
	loadjs.done("fusersearch");
});
</script>
<script>
loadjs.ready("head", function() {

	// Client script
	// Write your client script here, no need to add script tags.

});
</script>
<?php $user_search->showPageHeader(); ?>
<?php
$user_search->showMessage();
?>
<form name="fusersearch" id="fusersearch" class="<?php echo $user_search->FormClassName ?>" action="<?php echo CurrentPageName() ?>" method="post">
<?php if ($Page->CheckToken) { ?>
<input type="hidden" name="<?php echo Config("TOKEN_NAME") ?>" value="<?php echo $Page->Token ?>">
<?php } ?>
<input type="hidden" name="t" value="user">
<input type="hidden" name="action" id="action" value="search">
<input type="hidden" name="modal" value="<?php echo (int)$user_search->IsModal ?>">
<div class="ew-multi-page"><!-- multi-page -->
<div class="ew-nav-tabs" id="user_search"><!-- multi-page tabs -->
	<ul class="<?php echo $user_search->MultiPages->navStyle() ?>">
		<li class="nav-item"><a class="nav-link<?php echo $user_search->MultiPages->pageStyle(1) ?>" href="#tab_user1" data-toggle="tab"><?php echo $user->pageCaption(1) ?></a></li>
		<li class="nav-item"><a class="nav-link<?php echo $user_search->MultiPages->pageStyle(2) ?>" href="#tab_user2" data-toggle="tab"><?php echo $user->pageCaption(2) ?></a></li>
		<li class="nav-item"><a class="nav-link<?php echo $user_search->MultiPages->pageStyle(3) ?>" href="#tab_user3" data-toggle="tab"><?php echo $user->pageCaption(3) ?></a></li>
		<li class="nav-item"><a class="nav-link<?php echo $user_search->MultiPages->pageStyle(4) ?>" href="#tab_user4" data-toggle="tab"><?php echo $user->pageCaption(4) ?></a></li>
	</ul>
	<div class="tab-content"><!-- multi-page tabs .tab-content -->
		<div class="tab-pane<?php echo $user_search->MultiPages->pageStyle(1) ?>" id="tab_user1"><!-- multi-page .tab-pane -->
<div class="ew-search-div"><!-- page* -->
<?php if ($user_search->id->Visible) { // id ?>
	<div id="r_id" class="form-group row">
		<label for="x_id" class="<?php echo $user_search->LeftColumnClass ?>"><span id="elh_user_id"><?php echo $user_search->id->caption() ?></span>
		</label>
		<div class="<?php echo $user_search->RightColumnClass ?>"><div <?php echo $user_search->id->cellAttributes() ?>>
		<span class="ew-search-operator">
<select name="z_id" id="z_id" class="custom-select" onchange="ew.searchOperatorChanged(this);">
<option value="="<?php echo $user_search->id->AdvancedSearch->SearchOperator == "=" ? " selected" : "" ?>><?php echo $Language->phrase("EQUAL") ?></option>
<option value="<>"<?php echo $user_search->id->AdvancedSearch->SearchOperator == "<>" ? " selected" : "" ?>><?php echo $Language->phrase("<>") ?></option>
<option value="<"<?php echo $user_search->id->AdvancedSearch->SearchOperator == "<" ? " selected" : "" ?>><?php echo $Language->phrase("<") ?></option>
<option value="<="<?php echo $user_search->id->AdvancedSearch->SearchOperator == "<=" ? " selected" : "" ?>><?php echo $Language->phrase("<=") ?></option>
<option value=">"<?php echo $user_search->id->AdvancedSearch->SearchOperator == ">" ? " selected" : "" ?>><?php echo $Language->phrase(">") ?></option>
<option value=">="<?php echo $user_search->id->AdvancedSearch->SearchOperator == ">=" ? " selected" : "" ?>><?php echo $Language->phrase(">=") ?></option>
<option value="BETWEEN"<?php echo $user_search->id->AdvancedSearch->SearchOperator == "BETWEEN" ? " selected" : "" ?>><?php echo $Language->phrase("BETWEEN") ?></option>
</select>
</span>
			<span id="el_user_id" class="ew-search-field">
<input type="text" data-table="user" data-field="x_id" data-page="1" name="x_id" id="x_id" size="30" placeholder="<?php echo HtmlEncode($user_search->id->getPlaceHolder()) ?>" value="<?php echo $user_search->id->EditValue ?>"<?php echo $user_search->id->editAttributes() ?>>
</span>
			<span class="ew-search-and d-none"><label><?php echo $Language->phrase("AND") ?></label></span>
			<span id="el2_user_id" class="ew-search-field2 d-none">
<input type="text" data-table="user" data-field="x_id" data-page="1" name="y_id" id="y_id" size="30" placeholder="<?php echo HtmlEncode($user_search->id->getPlaceHolder()) ?>" value="<?php echo $user_search->id->EditValue2 ?>"<?php echo $user_search->id->editAttributes() ?>>
</span>
		</div></div>
	</div>
<?php } ?>
<?php if ($user_search->firstName->Visible) { // firstName ?>
	<div id="r_firstName" class="form-group row">
		<label for="x_firstName" class="<?php echo $user_search->LeftColumnClass ?>"><span id="elh_user_firstName"><?php echo $user_search->firstName->caption() ?></span>
		<span class="ew-search-operator">
<?php echo $Language->phrase("LIKE") ?>
<input type="hidden" name="z_firstName" id="z_firstName" value="LIKE">
</span>
		</label>
		<div class="<?php echo $user_search->RightColumnClass ?>"><div <?php echo $user_search->firstName->cellAttributes() ?>>
			<span id="el_user_firstName" class="ew-search-field">
<input type="text" data-table="user" data-field="x_firstName" data-page="1" name="x_firstName" id="x_firstName" size="30" maxlength="60" placeholder="<?php echo HtmlEncode($user_search->firstName->getPlaceHolder()) ?>" value="<?php echo $user_search->firstName->EditValue ?>"<?php echo $user_search->firstName->editAttributes() ?>>
</span>
		</div></div>
	</div>
<?php } ?>
<?php if ($user_search->lastName->Visible) { // lastName ?>
	<div id="r_lastName" class="form-group row">
		<label for="x_lastName" class="<?php echo $user_search->LeftColumnClass ?>"><span id="elh_user_lastName"><?php echo $user_search->lastName->caption() ?></span>
		<span class="ew-search-operator">
<?php echo $Language->phrase("LIKE") ?>
<input type="hidden" name="z_lastName" id="z_lastName" value="LIKE">
</span>
		</label>
		<div class="<?php echo $user_search->RightColumnClass ?>"><div <?php echo $user_search->lastName->cellAttributes() ?>>
			<span id="el_user_lastName" class="ew-search-field">
<input type="text" data-table="user" data-field="x_lastName" data-page="1" name="x_lastName" id="x_lastName" size="30" maxlength="60" placeholder="<?php echo HtmlEncode($user_search->lastName->getPlaceHolder()) ?>" value="<?php echo $user_search->lastName->EditValue ?>"<?php echo $user_search->lastName->editAttributes() ?>>
</span>
		</div></div>
	</div>
<?php } ?>
<?php if ($user_search->otherNames->Visible) { // otherNames ?>
	<div id="r_otherNames" class="form-group row">
		<label for="x_otherNames" class="<?php echo $user_search->LeftColumnClass ?>"><span id="elh_user_otherNames"><?php echo $user_search->otherNames->caption() ?></span>
		<span class="ew-search-operator">
<?php echo $Language->phrase("LIKE") ?>
<input type="hidden" name="z_otherNames" id="z_otherNames" value="LIKE">
</span>
		</label>
		<div class="<?php echo $user_search->RightColumnClass ?>"><div <?php echo $user_search->otherNames->cellAttributes() ?>>
			<span id="el_user_otherNames" class="ew-search-field">
<input type="text" data-table="user" data-field="x_otherNames" data-page="1" name="x_otherNames" id="x_otherNames" size="30" maxlength="60" placeholder="<?php echo HtmlEncode($user_search->otherNames->getPlaceHolder()) ?>" value="<?php echo $user_search->otherNames->EditValue ?>"<?php echo $user_search->otherNames->editAttributes() ?>>
</span>
		</div></div>
	</div>
<?php } ?>
<?php if ($user_search->passwordRequireChange->Visible) { // passwordRequireChange ?>
	<div id="r_passwordRequireChange" class="form-group row">
		<label class="<?php echo $user_search->LeftColumnClass ?>"><span id="elh_user_passwordRequireChange"><?php echo $user_search->passwordRequireChange->caption() ?></span>
		<span class="ew-search-operator">
<?php echo $Language->phrase("=") ?>
<input type="hidden" name="z_passwordRequireChange" id="z_passwordRequireChange" value="=">
</span>
		</label>
		<div class="<?php echo $user_search->RightColumnClass ?>"><div <?php echo $user_search->passwordRequireChange->cellAttributes() ?>>
			<span id="el_user_passwordRequireChange" class="ew-search-field">
<div id="tp_x_passwordRequireChange" class="ew-template"><input type="radio" class="custom-control-input" data-table="user" data-field="x_passwordRequireChange" data-page="1" data-value-separator="<?php echo $user_search->passwordRequireChange->displayValueSeparatorAttribute() ?>" name="x_passwordRequireChange" id="x_passwordRequireChange" value="{value}"<?php echo $user_search->passwordRequireChange->editAttributes() ?>></div>
<div id="dsl_x_passwordRequireChange" data-repeatcolumn="5" class="ew-item-list d-none"><div>
<?php echo $user_search->passwordRequireChange->radioButtonListHtml(FALSE, "x_passwordRequireChange", 1) ?>
</div></div>
<?php echo $user_search->passwordRequireChange->Lookup->getParamTag($user_search, "p_x_passwordRequireChange") ?>
</span>
		</div></div>
	</div>
<?php } ?>
<?php if ($user_search->dateAdded->Visible) { // dateAdded ?>
	<div id="r_dateAdded" class="form-group row">
		<label for="x_dateAdded" class="<?php echo $user_search->LeftColumnClass ?>"><span id="elh_user_dateAdded"><?php echo $user_search->dateAdded->caption() ?></span>
		</label>
		<div class="<?php echo $user_search->RightColumnClass ?>"><div <?php echo $user_search->dateAdded->cellAttributes() ?>>
		<span class="ew-search-operator">
<select name="z_dateAdded" id="z_dateAdded" class="custom-select" onchange="ew.searchOperatorChanged(this);">
<option value="="<?php echo $user_search->dateAdded->AdvancedSearch->SearchOperator == "=" ? " selected" : "" ?>><?php echo $Language->phrase("EQUAL") ?></option>
<option value="<>"<?php echo $user_search->dateAdded->AdvancedSearch->SearchOperator == "<>" ? " selected" : "" ?>><?php echo $Language->phrase("<>") ?></option>
<option value="<"<?php echo $user_search->dateAdded->AdvancedSearch->SearchOperator == "<" ? " selected" : "" ?>><?php echo $Language->phrase("<") ?></option>
<option value="<="<?php echo $user_search->dateAdded->AdvancedSearch->SearchOperator == "<=" ? " selected" : "" ?>><?php echo $Language->phrase("<=") ?></option>
<option value=">"<?php echo $user_search->dateAdded->AdvancedSearch->SearchOperator == ">" ? " selected" : "" ?>><?php echo $Language->phrase(">") ?></option>
<option value=">="<?php echo $user_search->dateAdded->AdvancedSearch->SearchOperator == ">=" ? " selected" : "" ?>><?php echo $Language->phrase(">=") ?></option>
<option value="IS NULL"<?php echo $user_search->dateAdded->AdvancedSearch->SearchOperator == "IS NULL" ? " selected" : "" ?>><?php echo $Language->phrase("IS NULL") ?></option>
<option value="IS NOT NULL"<?php echo $user_search->dateAdded->AdvancedSearch->SearchOperator == "IS NOT NULL" ? " selected" : "" ?>><?php echo $Language->phrase("IS NOT NULL") ?></option>
<option value="BETWEEN"<?php echo $user_search->dateAdded->AdvancedSearch->SearchOperator == "BETWEEN" ? " selected" : "" ?>><?php echo $Language->phrase("BETWEEN") ?></option>
</select>
</span>
			<span id="el_user_dateAdded" class="ew-search-field">
<input type="text" data-table="user" data-field="x_dateAdded" data-page="1" data-format="1" name="x_dateAdded" id="x_dateAdded" placeholder="<?php echo HtmlEncode($user_search->dateAdded->getPlaceHolder()) ?>" value="<?php echo $user_search->dateAdded->EditValue ?>"<?php echo $user_search->dateAdded->editAttributes() ?>>
<?php if (!$user_search->dateAdded->ReadOnly && !$user_search->dateAdded->Disabled && !isset($user_search->dateAdded->EditAttrs["readonly"]) && !isset($user_search->dateAdded->EditAttrs["disabled"])) { ?>
<script>
loadjs.ready(["fusersearch", "datetimepicker"], function() {
	ew.createDateTimePicker("fusersearch", "x_dateAdded", {"ignoreReadonly":true,"useCurrent":false,"format":1});
});
</script>
<?php } ?>
</span>
			<span class="ew-search-and d-none"><label><?php echo $Language->phrase("AND") ?></label></span>
			<span id="el2_user_dateAdded" class="ew-search-field2 d-none">
<input type="text" data-table="user" data-field="x_dateAdded" data-page="1" data-format="1" name="y_dateAdded" id="y_dateAdded" placeholder="<?php echo HtmlEncode($user_search->dateAdded->getPlaceHolder()) ?>" value="<?php echo $user_search->dateAdded->EditValue2 ?>"<?php echo $user_search->dateAdded->editAttributes() ?>>
<?php if (!$user_search->dateAdded->ReadOnly && !$user_search->dateAdded->Disabled && !isset($user_search->dateAdded->EditAttrs["readonly"]) && !isset($user_search->dateAdded->EditAttrs["disabled"])) { ?>
<script>
loadjs.ready(["fusersearch", "datetimepicker"], function() {
	ew.createDateTimePicker("fusersearch", "y_dateAdded", {"ignoreReadonly":true,"useCurrent":false,"format":1});
});
</script>
<?php } ?>
</span>
		</div></div>
	</div>
<?php } ?>
<?php if ($user_search->timezoneid->Visible) { // timezoneid ?>
	<div id="r_timezoneid" class="form-group row">
		<label for="x_timezoneid" class="<?php echo $user_search->LeftColumnClass ?>"><span id="elh_user_timezoneid"><?php echo $user_search->timezoneid->caption() ?></span>
		<span class="ew-search-operator">
<?php echo $Language->phrase("=") ?>
<input type="hidden" name="z_timezoneid" id="z_timezoneid" value="=">
</span>
		</label>
		<div class="<?php echo $user_search->RightColumnClass ?>"><div <?php echo $user_search->timezoneid->cellAttributes() ?>>
			<span id="el_user_timezoneid" class="ew-search-field">
<div class="input-group">
	<select class="custom-select ew-custom-select" data-table="user" data-field="x_timezoneid" data-page="1" data-value-separator="<?php echo $user_search->timezoneid->displayValueSeparatorAttribute() ?>" id="x_timezoneid" name="x_timezoneid"<?php echo $user_search->timezoneid->editAttributes() ?>>
			<?php echo $user_search->timezoneid->selectOptionListHtml("x_timezoneid") ?>
		</select>
</div>
<?php echo $user_search->timezoneid->Lookup->getParamTag($user_search, "p_x_timezoneid") ?>
</span>
		</div></div>
	</div>
<?php } ?>
<?php if ($user_search->contactPhoneNo->Visible) { // contactPhoneNo ?>
	<div id="r_contactPhoneNo" class="form-group row">
		<label for="x_contactPhoneNo" class="<?php echo $user_search->LeftColumnClass ?>"><span id="elh_user_contactPhoneNo"><?php echo $user_search->contactPhoneNo->caption() ?></span>
		<span class="ew-search-operator">
<?php echo $Language->phrase("LIKE") ?>
<input type="hidden" name="z_contactPhoneNo" id="z_contactPhoneNo" value="LIKE">
</span>
		</label>
		<div class="<?php echo $user_search->RightColumnClass ?>"><div <?php echo $user_search->contactPhoneNo->cellAttributes() ?>>
			<span id="el_user_contactPhoneNo" class="ew-search-field">
<input type="text" data-table="user" data-field="x_contactPhoneNo" data-page="1" name="x_contactPhoneNo" id="x_contactPhoneNo" size="30" maxlength="20" placeholder="<?php echo HtmlEncode($user_search->contactPhoneNo->getPlaceHolder()) ?>" value="<?php echo $user_search->contactPhoneNo->EditValue ?>"<?php echo $user_search->contactPhoneNo->editAttributes() ?>>
</span>
		</div></div>
	</div>
<?php } ?>
<?php if ($user_search->telephoneno->Visible) { // telephoneno ?>
	<div id="r_telephoneno" class="form-group row">
		<label for="x_telephoneno" class="<?php echo $user_search->LeftColumnClass ?>"><span id="elh_user_telephoneno"><?php echo $user_search->telephoneno->caption() ?></span>
		<span class="ew-search-operator">
<?php echo $Language->phrase("LIKE") ?>
<input type="hidden" name="z_telephoneno" id="z_telephoneno" value="LIKE">
</span>
		</label>
		<div class="<?php echo $user_search->RightColumnClass ?>"><div <?php echo $user_search->telephoneno->cellAttributes() ?>>
			<span id="el_user_telephoneno" class="ew-search-field">
<input type="text" data-table="user" data-field="x_telephoneno" data-page="1" name="x_telephoneno" id="x_telephoneno" size="30" maxlength="20" placeholder="<?php echo HtmlEncode($user_search->telephoneno->getPlaceHolder()) ?>" value="<?php echo $user_search->telephoneno->EditValue ?>"<?php echo $user_search->telephoneno->editAttributes() ?>>
</span>
		</div></div>
	</div>
<?php } ?>
<?php if ($user_search->telephoneverified->Visible) { // telephoneverified ?>
	<div id="r_telephoneverified" class="form-group row">
		<label class="<?php echo $user_search->LeftColumnClass ?>"><span id="elh_user_telephoneverified"><?php echo $user_search->telephoneverified->caption() ?></span>
		<span class="ew-search-operator">
<?php echo $Language->phrase("=") ?>
<input type="hidden" name="z_telephoneverified" id="z_telephoneverified" value="=">
</span>
		</label>
		<div class="<?php echo $user_search->RightColumnClass ?>"><div <?php echo $user_search->telephoneverified->cellAttributes() ?>>
			<span id="el_user_telephoneverified" class="ew-search-field">
<div id="tp_x_telephoneverified" class="ew-template"><input type="radio" class="custom-control-input" data-table="user" data-field="x_telephoneverified" data-page="1" data-value-separator="<?php echo $user_search->telephoneverified->displayValueSeparatorAttribute() ?>" name="x_telephoneverified" id="x_telephoneverified" value="{value}"<?php echo $user_search->telephoneverified->editAttributes() ?>></div>
<div id="dsl_x_telephoneverified" data-repeatcolumn="5" class="ew-item-list d-none"><div>
<?php echo $user_search->telephoneverified->radioButtonListHtml(FALSE, "x_telephoneverified", 1) ?>
</div></div>
<?php echo $user_search->telephoneverified->Lookup->getParamTag($user_search, "p_x_telephoneverified") ?>
</span>
		</div></div>
	</div>
<?php } ?>
<?php if ($user_search->address1->Visible) { // address1 ?>
	<div id="r_address1" class="form-group row">
		<label for="x_address1" class="<?php echo $user_search->LeftColumnClass ?>"><span id="elh_user_address1"><?php echo $user_search->address1->caption() ?></span>
		<span class="ew-search-operator">
<?php echo $Language->phrase("LIKE") ?>
<input type="hidden" name="z_address1" id="z_address1" value="LIKE">
</span>
		</label>
		<div class="<?php echo $user_search->RightColumnClass ?>"><div <?php echo $user_search->address1->cellAttributes() ?>>
			<span id="el_user_address1" class="ew-search-field">
<input type="text" data-table="user" data-field="x_address1" data-page="1" name="x_address1" id="x_address1" size="30" maxlength="60" placeholder="<?php echo HtmlEncode($user_search->address1->getPlaceHolder()) ?>" value="<?php echo $user_search->address1->EditValue ?>"<?php echo $user_search->address1->editAttributes() ?>>
</span>
		</div></div>
	</div>
<?php } ?>
<?php if ($user_search->address2->Visible) { // address2 ?>
	<div id="r_address2" class="form-group row">
		<label for="x_address2" class="<?php echo $user_search->LeftColumnClass ?>"><span id="elh_user_address2"><?php echo $user_search->address2->caption() ?></span>
		<span class="ew-search-operator">
<?php echo $Language->phrase("LIKE") ?>
<input type="hidden" name="z_address2" id="z_address2" value="LIKE">
</span>
		</label>
		<div class="<?php echo $user_search->RightColumnClass ?>"><div <?php echo $user_search->address2->cellAttributes() ?>>
			<span id="el_user_address2" class="ew-search-field">
<input type="text" data-table="user" data-field="x_address2" data-page="1" name="x_address2" id="x_address2" size="30" maxlength="60" placeholder="<?php echo HtmlEncode($user_search->address2->getPlaceHolder()) ?>" value="<?php echo $user_search->address2->EditValue ?>"<?php echo $user_search->address2->editAttributes() ?>>
</span>
		</div></div>
	</div>
<?php } ?>
<?php if ($user_search->cityname->Visible) { // cityname ?>
	<div id="r_cityname" class="form-group row">
		<label for="x_cityname" class="<?php echo $user_search->LeftColumnClass ?>"><span id="elh_user_cityname"><?php echo $user_search->cityname->caption() ?></span>
		<span class="ew-search-operator">
<?php echo $Language->phrase("LIKE") ?>
<input type="hidden" name="z_cityname" id="z_cityname" value="LIKE">
</span>
		</label>
		<div class="<?php echo $user_search->RightColumnClass ?>"><div <?php echo $user_search->cityname->cellAttributes() ?>>
			<span id="el_user_cityname" class="ew-search-field">
<input type="text" data-table="user" data-field="x_cityname" data-page="1" name="x_cityname" id="x_cityname" size="30" maxlength="60" placeholder="<?php echo HtmlEncode($user_search->cityname->getPlaceHolder()) ?>" value="<?php echo $user_search->cityname->EditValue ?>"<?php echo $user_search->cityname->editAttributes() ?>>
</span>
		</div></div>
	</div>
<?php } ?>
<?php if ($user_search->countryid->Visible) { // countryid ?>
	<div id="r_countryid" class="form-group row">
		<label for="x_countryid" class="<?php echo $user_search->LeftColumnClass ?>"><span id="elh_user_countryid"><?php echo $user_search->countryid->caption() ?></span>
		<span class="ew-search-operator">
<?php echo $Language->phrase("LIKE") ?>
<input type="hidden" name="z_countryid" id="z_countryid" value="LIKE">
</span>
		</label>
		<div class="<?php echo $user_search->RightColumnClass ?>"><div <?php echo $user_search->countryid->cellAttributes() ?>>
			<span id="el_user_countryid" class="ew-search-field">
<?php $user_search->countryid->EditAttrs->prepend("onchange", "ew.updateOptions.call(this);"); ?>
<div class="input-group">
	<select class="custom-select ew-custom-select" data-table="user" data-field="x_countryid" data-page="1" data-value-separator="<?php echo $user_search->countryid->displayValueSeparatorAttribute() ?>" id="x_countryid" name="x_countryid"<?php echo $user_search->countryid->editAttributes() ?>>
			<?php echo $user_search->countryid->selectOptionListHtml("x_countryid") ?>
		</select>
</div>
<?php echo $user_search->countryid->Lookup->getParamTag($user_search, "p_x_countryid") ?>
</span>
		</div></div>
	</div>
<?php } ?>
<?php if ($user_search->stateid->Visible) { // stateid ?>
	<div id="r_stateid" class="form-group row">
		<label for="x_stateid" class="<?php echo $user_search->LeftColumnClass ?>"><span id="elh_user_stateid"><?php echo $user_search->stateid->caption() ?></span>
		<span class="ew-search-operator">
<?php echo $Language->phrase("LIKE") ?>
<input type="hidden" name="z_stateid" id="z_stateid" value="LIKE">
</span>
		</label>
		<div class="<?php echo $user_search->RightColumnClass ?>"><div <?php echo $user_search->stateid->cellAttributes() ?>>
			<span id="el_user_stateid" class="ew-search-field">
<div class="input-group">
	<select class="custom-select ew-custom-select" data-table="user" data-field="x_stateid" data-page="1" data-value-separator="<?php echo $user_search->stateid->displayValueSeparatorAttribute() ?>" id="x_stateid" name="x_stateid"<?php echo $user_search->stateid->editAttributes() ?>>
			<?php echo $user_search->stateid->selectOptionListHtml("x_stateid") ?>
		</select>
</div>
<?php echo $user_search->stateid->Lookup->getParamTag($user_search, "p_x_stateid") ?>
</span>
		</div></div>
	</div>
<?php } ?>
<?php if ($user_search->defaultcurrency->Visible) { // defaultcurrency ?>
	<div id="r_defaultcurrency" class="form-group row">
		<label for="x_defaultcurrency" class="<?php echo $user_search->LeftColumnClass ?>"><span id="elh_user_defaultcurrency"><?php echo $user_search->defaultcurrency->caption() ?></span>
		<span class="ew-search-operator">
<?php echo $Language->phrase("LIKE") ?>
<input type="hidden" name="z_defaultcurrency" id="z_defaultcurrency" value="LIKE">
</span>
		</label>
		<div class="<?php echo $user_search->RightColumnClass ?>"><div <?php echo $user_search->defaultcurrency->cellAttributes() ?>>
			<span id="el_user_defaultcurrency" class="ew-search-field">
<div class="input-group">
	<select class="custom-select ew-custom-select" data-table="user" data-field="x_defaultcurrency" data-page="1" data-value-separator="<?php echo $user_search->defaultcurrency->displayValueSeparatorAttribute() ?>" id="x_defaultcurrency" name="x_defaultcurrency"<?php echo $user_search->defaultcurrency->editAttributes() ?>>
			<?php echo $user_search->defaultcurrency->selectOptionListHtml("x_defaultcurrency") ?>
		</select>
</div>
<?php echo $user_search->defaultcurrency->Lookup->getParamTag($user_search, "p_x_defaultcurrency") ?>
</span>
		</div></div>
	</div>
<?php } ?>
<?php if ($user_search->accountID->Visible) { // accountID ?>
	<div id="r_accountID" class="form-group row">
		<label for="x_accountID" class="<?php echo $user_search->LeftColumnClass ?>"><span id="elh_user_accountID"><?php echo $user_search->accountID->caption() ?></span>
		<span class="ew-search-operator">
<?php echo $Language->phrase("=") ?>
<input type="hidden" name="z_accountID" id="z_accountID" value="=">
</span>
		</label>
		<div class="<?php echo $user_search->RightColumnClass ?>"><div <?php echo $user_search->accountID->cellAttributes() ?>>
			<span id="el_user_accountID" class="ew-search-field">
<input type="text" data-table="user" data-field="x_accountID" data-page="1" name="x_accountID" id="x_accountID" size="30" placeholder="<?php echo HtmlEncode($user_search->accountID->getPlaceHolder()) ?>" value="<?php echo $user_search->accountID->EditValue ?>"<?php echo $user_search->accountID->editAttributes() ?>>
</span>
		</div></div>
	</div>
<?php } ?>
<?php if ($user_search->profilestatus->Visible) { // profilestatus ?>
	<div id="r_profilestatus" class="form-group row">
		<label for="x_profilestatus" class="<?php echo $user_search->LeftColumnClass ?>"><span id="elh_user_profilestatus"><?php echo $user_search->profilestatus->caption() ?></span>
		<span class="ew-search-operator">
<?php echo $Language->phrase("=") ?>
<input type="hidden" name="z_profilestatus" id="z_profilestatus" value="=">
</span>
		</label>
		<div class="<?php echo $user_search->RightColumnClass ?>"><div <?php echo $user_search->profilestatus->cellAttributes() ?>>
			<span id="el_user_profilestatus" class="ew-search-field">
<div class="input-group">
	<select class="custom-select ew-custom-select" data-table="user" data-field="x_profilestatus" data-page="1" data-value-separator="<?php echo $user_search->profilestatus->displayValueSeparatorAttribute() ?>" id="x_profilestatus" name="x_profilestatus"<?php echo $user_search->profilestatus->editAttributes() ?>>
			<?php echo $user_search->profilestatus->selectOptionListHtml("x_profilestatus") ?>
		</select>
</div>
<?php echo $user_search->profilestatus->Lookup->getParamTag($user_search, "p_x_profilestatus") ?>
</span>
		</div></div>
	</div>
<?php } ?>
<?php if ($user_search->dateofbirth->Visible) { // dateofbirth ?>
	<div id="r_dateofbirth" class="form-group row">
		<label for="x_dateofbirth" class="<?php echo $user_search->LeftColumnClass ?>"><span id="elh_user_dateofbirth"><?php echo $user_search->dateofbirth->caption() ?></span>
		<span class="ew-search-operator">
<?php echo $Language->phrase("=") ?>
<input type="hidden" name="z_dateofbirth" id="z_dateofbirth" value="=">
</span>
		</label>
		<div class="<?php echo $user_search->RightColumnClass ?>"><div <?php echo $user_search->dateofbirth->cellAttributes() ?>>
			<span id="el_user_dateofbirth" class="ew-search-field">
<input type="text" data-table="user" data-field="x_dateofbirth" data-page="1" data-format="2" name="x_dateofbirth" id="x_dateofbirth" placeholder="<?php echo HtmlEncode($user_search->dateofbirth->getPlaceHolder()) ?>" value="<?php echo $user_search->dateofbirth->EditValue ?>"<?php echo $user_search->dateofbirth->editAttributes() ?>>
<?php if (!$user_search->dateofbirth->ReadOnly && !$user_search->dateofbirth->Disabled && !isset($user_search->dateofbirth->EditAttrs["readonly"]) && !isset($user_search->dateofbirth->EditAttrs["disabled"])) { ?>
<script>
loadjs.ready(["fusersearch", "datetimepicker"], function() {
	ew.createDateTimePicker("fusersearch", "x_dateofbirth", {"ignoreReadonly":true,"useCurrent":false,"format":2});
});
</script>
<?php } ?>
</span>
		</div></div>
	</div>
<?php } ?>
<?php if ($user_search->gender->Visible) { // gender ?>
	<div id="r_gender" class="form-group row">
		<label for="x_gender" class="<?php echo $user_search->LeftColumnClass ?>"><span id="elh_user_gender"><?php echo $user_search->gender->caption() ?></span>
		<span class="ew-search-operator">
<?php echo $Language->phrase("=") ?>
<input type="hidden" name="z_gender" id="z_gender" value="=">
</span>
		</label>
		<div class="<?php echo $user_search->RightColumnClass ?>"><div <?php echo $user_search->gender->cellAttributes() ?>>
			<span id="el_user_gender" class="ew-search-field">
<div class="input-group">
	<select class="custom-select ew-custom-select" data-table="user" data-field="x_gender" data-page="1" data-value-separator="<?php echo $user_search->gender->displayValueSeparatorAttribute() ?>" id="x_gender" name="x_gender"<?php echo $user_search->gender->editAttributes() ?>>
			<?php echo $user_search->gender->selectOptionListHtml("x_gender") ?>
		</select>
</div>
<?php echo $user_search->gender->Lookup->getParamTag($user_search, "p_x_gender") ?>
</span>
		</div></div>
	</div>
<?php } ?>
<?php if ($user_search->lastupdatedate->Visible) { // lastupdatedate ?>
	<div id="r_lastupdatedate" class="form-group row">
		<label for="x_lastupdatedate" class="<?php echo $user_search->LeftColumnClass ?>"><span id="elh_user_lastupdatedate"><?php echo $user_search->lastupdatedate->caption() ?></span>
		<span class="ew-search-operator">
<?php echo $Language->phrase("=") ?>
<input type="hidden" name="z_lastupdatedate" id="z_lastupdatedate" value="=">
</span>
		</label>
		<div class="<?php echo $user_search->RightColumnClass ?>"><div <?php echo $user_search->lastupdatedate->cellAttributes() ?>>
			<span id="el_user_lastupdatedate" class="ew-search-field">
<input type="text" data-table="user" data-field="x_lastupdatedate" data-page="1" data-format="1" name="x_lastupdatedate" id="x_lastupdatedate" placeholder="<?php echo HtmlEncode($user_search->lastupdatedate->getPlaceHolder()) ?>" value="<?php echo $user_search->lastupdatedate->EditValue ?>"<?php echo $user_search->lastupdatedate->editAttributes() ?>>
<?php if (!$user_search->lastupdatedate->ReadOnly && !$user_search->lastupdatedate->Disabled && !isset($user_search->lastupdatedate->EditAttrs["readonly"]) && !isset($user_search->lastupdatedate->EditAttrs["disabled"])) { ?>
<script>
loadjs.ready(["fusersearch", "datetimepicker"], function() {
	ew.createDateTimePicker("fusersearch", "x_lastupdatedate", {"ignoreReadonly":true,"useCurrent":false,"format":1});
});
</script>
<?php } ?>
</span>
		</div></div>
	</div>
<?php } ?>
<?php if ($user_search->zip->Visible) { // zip ?>
	<div id="r_zip" class="form-group row">
		<label for="x_zip" class="<?php echo $user_search->LeftColumnClass ?>"><span id="elh_user_zip"><?php echo $user_search->zip->caption() ?></span>
		<span class="ew-search-operator">
<?php echo $Language->phrase("LIKE") ?>
<input type="hidden" name="z_zip" id="z_zip" value="LIKE">
</span>
		</label>
		<div class="<?php echo $user_search->RightColumnClass ?>"><div <?php echo $user_search->zip->cellAttributes() ?>>
			<span id="el_user_zip" class="ew-search-field">
<input type="text" data-table="user" data-field="x_zip" data-page="1" name="x_zip" id="x_zip" size="30" maxlength="10" placeholder="<?php echo HtmlEncode($user_search->zip->getPlaceHolder()) ?>" value="<?php echo $user_search->zip->EditValue ?>"<?php echo $user_search->zip->editAttributes() ?>>
</span>
		</div></div>
	</div>
<?php } ?>
<?php if ($user_search->otprequiredforphysicalcards->Visible) { // otprequiredforphysicalcards ?>
	<div id="r_otprequiredforphysicalcards" class="form-group row">
		<label for="x_otprequiredforphysicalcards" class="<?php echo $user_search->LeftColumnClass ?>"><span id="elh_user_otprequiredforphysicalcards"><?php echo $user_search->otprequiredforphysicalcards->caption() ?></span>
		<span class="ew-search-operator">
<?php echo $Language->phrase("=") ?>
<input type="hidden" name="z_otprequiredforphysicalcards" id="z_otprequiredforphysicalcards" value="=">
</span>
		</label>
		<div class="<?php echo $user_search->RightColumnClass ?>"><div <?php echo $user_search->otprequiredforphysicalcards->cellAttributes() ?>>
			<span id="el_user_otprequiredforphysicalcards" class="ew-search-field">
<input type="text" data-table="user" data-field="x_otprequiredforphysicalcards" data-page="1" name="x_otprequiredforphysicalcards" id="x_otprequiredforphysicalcards" size="30" maxlength="1" placeholder="<?php echo HtmlEncode($user_search->otprequiredforphysicalcards->getPlaceHolder()) ?>" value="<?php echo $user_search->otprequiredforphysicalcards->EditValue ?>"<?php echo $user_search->otprequiredforphysicalcards->editAttributes() ?>>
</span>
		</div></div>
	</div>
<?php } ?>
<?php if ($user_search->otpvaliduntil->Visible) { // otpvaliduntil ?>
	<div id="r_otpvaliduntil" class="form-group row">
		<label for="x_otpvaliduntil" class="<?php echo $user_search->LeftColumnClass ?>"><span id="elh_user_otpvaliduntil"><?php echo $user_search->otpvaliduntil->caption() ?></span>
		<span class="ew-search-operator">
<?php echo $Language->phrase("=") ?>
<input type="hidden" name="z_otpvaliduntil" id="z_otpvaliduntil" value="=">
</span>
		</label>
		<div class="<?php echo $user_search->RightColumnClass ?>"><div <?php echo $user_search->otpvaliduntil->cellAttributes() ?>>
			<span id="el_user_otpvaliduntil" class="ew-search-field">
<input type="text" data-table="user" data-field="x_otpvaliduntil" data-page="1" name="x_otpvaliduntil" id="x_otpvaliduntil" maxlength="19" placeholder="<?php echo HtmlEncode($user_search->otpvaliduntil->getPlaceHolder()) ?>" value="<?php echo $user_search->otpvaliduntil->EditValue ?>"<?php echo $user_search->otpvaliduntil->editAttributes() ?>>
<?php if (!$user_search->otpvaliduntil->ReadOnly && !$user_search->otpvaliduntil->Disabled && !isset($user_search->otpvaliduntil->EditAttrs["readonly"]) && !isset($user_search->otpvaliduntil->EditAttrs["disabled"])) { ?>
<script>
loadjs.ready(["fusersearch", "datetimepicker"], function() {
	ew.createDateTimePicker("fusersearch", "x_otpvaliduntil", {"ignoreReadonly":true,"useCurrent":false,"format":0});
});
</script>
<?php } ?>
</span>
		</div></div>
	</div>
<?php } ?>
<?php if ($user_search->nationalitycountry->Visible) { // nationalitycountry ?>
	<div id="r_nationalitycountry" class="form-group row">
		<label for="x_nationalitycountry" class="<?php echo $user_search->LeftColumnClass ?>"><span id="elh_user_nationalitycountry"><?php echo $user_search->nationalitycountry->caption() ?></span>
		<span class="ew-search-operator">
<?php echo $Language->phrase("LIKE") ?>
<input type="hidden" name="z_nationalitycountry" id="z_nationalitycountry" value="LIKE">
</span>
		</label>
		<div class="<?php echo $user_search->RightColumnClass ?>"><div <?php echo $user_search->nationalitycountry->cellAttributes() ?>>
			<span id="el_user_nationalitycountry" class="ew-search-field">
<div class="input-group">
	<select class="custom-select ew-custom-select" data-table="user" data-field="x_nationalitycountry" data-page="1" data-value-separator="<?php echo $user_search->nationalitycountry->displayValueSeparatorAttribute() ?>" id="x_nationalitycountry" name="x_nationalitycountry"<?php echo $user_search->nationalitycountry->editAttributes() ?>>
			<?php echo $user_search->nationalitycountry->selectOptionListHtml("x_nationalitycountry") ?>
		</select>
</div>
<?php echo $user_search->nationalitycountry->Lookup->getParamTag($user_search, "p_x_nationalitycountry") ?>
</span>
		</div></div>
	</div>
<?php } ?>
<?php if ($user_search->classification->Visible) { // classification ?>
	<div id="r_classification" class="form-group row">
		<label for="x_classification" class="<?php echo $user_search->LeftColumnClass ?>"><span id="elh_user_classification"><?php echo $user_search->classification->caption() ?></span>
		<span class="ew-search-operator">
<?php echo $Language->phrase("LIKE") ?>
<input type="hidden" name="z_classification" id="z_classification" value="LIKE">
</span>
		</label>
		<div class="<?php echo $user_search->RightColumnClass ?>"><div <?php echo $user_search->classification->cellAttributes() ?>>
			<span id="el_user_classification" class="ew-search-field">
<div class="input-group">
	<select class="custom-select ew-custom-select" data-table="user" data-field="x_classification" data-page="1" data-value-separator="<?php echo $user_search->classification->displayValueSeparatorAttribute() ?>" id="x_classification" name="x_classification"<?php echo $user_search->classification->editAttributes() ?>>
			<?php echo $user_search->classification->selectOptionListHtml("x_classification") ?>
		</select>
</div>
<?php echo $user_search->classification->Lookup->getParamTag($user_search, "p_x_classification") ?>
</span>
		</div></div>
	</div>
<?php } ?>
<?php if ($user_search->occupation->Visible) { // occupation ?>
	<div id="r_occupation" class="form-group row">
		<label class="<?php echo $user_search->LeftColumnClass ?>"><span id="elh_user_occupation"><?php echo $user_search->occupation->caption() ?></span>
		<span class="ew-search-operator">
<?php echo $Language->phrase("LIKE") ?>
<input type="hidden" name="z_occupation" id="z_occupation" value="LIKE">
</span>
		</label>
		<div class="<?php echo $user_search->RightColumnClass ?>"><div <?php echo $user_search->occupation->cellAttributes() ?>>
			<span id="el_user_occupation" class="ew-search-field">
<?php
$onchange = $user_search->occupation->EditAttrs->prepend("onchange", "");
$onchange = ($onchange) ? ' onchange="' . JsEncode($onchange) . '"' : '';
$user_search->occupation->EditAttrs["onchange"] = "";
?>
<span id="as_x_occupation">
	<input type="text" class="form-control" name="sv_x_occupation" id="sv_x_occupation" value="<?php echo RemoveHtml($user_search->occupation->EditValue) ?>" size="30" maxlength="3" placeholder="<?php echo HtmlEncode($user_search->occupation->getPlaceHolder()) ?>" data-placeholder="<?php echo HtmlEncode($user_search->occupation->getPlaceHolder()) ?>"<?php echo $user_search->occupation->editAttributes() ?>>
</span>
<input type="hidden" data-table="user" data-field="x_occupation" data-page="1" data-value-separator="<?php echo $user_search->occupation->displayValueSeparatorAttribute() ?>" name="x_occupation" id="x_occupation" value="<?php echo HtmlEncode($user_search->occupation->AdvancedSearch->SearchValue) ?>"<?php echo $onchange ?>>
<script>
loadjs.ready(["fusersearch"], function() {
	fusersearch.createAutoSuggest({"id":"x_occupation","forceSelect":false});
});
</script>
<?php echo $user_search->occupation->Lookup->getParamTag($user_search, "p_x_occupation") ?>
</span>
		</div></div>
	</div>
<?php } ?>
<?php if ($user_search->sourceofincome->Visible) { // sourceofincome ?>
	<div id="r_sourceofincome" class="form-group row">
		<label for="x_sourceofincome" class="<?php echo $user_search->LeftColumnClass ?>"><span id="elh_user_sourceofincome"><?php echo $user_search->sourceofincome->caption() ?></span>
		<span class="ew-search-operator">
<?php echo $Language->phrase("LIKE") ?>
<input type="hidden" name="z_sourceofincome" id="z_sourceofincome" value="LIKE">
</span>
		</label>
		<div class="<?php echo $user_search->RightColumnClass ?>"><div <?php echo $user_search->sourceofincome->cellAttributes() ?>>
			<span id="el_user_sourceofincome" class="ew-search-field">
<div class="input-group">
	<select class="custom-select ew-custom-select" data-table="user" data-field="x_sourceofincome" data-page="1" data-value-separator="<?php echo $user_search->sourceofincome->displayValueSeparatorAttribute() ?>" id="x_sourceofincome" name="x_sourceofincome"<?php echo $user_search->sourceofincome->editAttributes() ?>>
			<?php echo $user_search->sourceofincome->selectOptionListHtml("x_sourceofincome") ?>
		</select>
</div>
<?php echo $user_search->sourceofincome->Lookup->getParamTag($user_search, "p_x_sourceofincome") ?>
</span>
		</div></div>
	</div>
<?php } ?>
<?php if ($user_search->accountopeningdate->Visible) { // accountopeningdate ?>
	<div id="r_accountopeningdate" class="form-group row">
		<label for="x_accountopeningdate" class="<?php echo $user_search->LeftColumnClass ?>"><span id="elh_user_accountopeningdate"><?php echo $user_search->accountopeningdate->caption() ?></span>
		<span class="ew-search-operator">
<?php echo $Language->phrase("=") ?>
<input type="hidden" name="z_accountopeningdate" id="z_accountopeningdate" value="=">
</span>
		</label>
		<div class="<?php echo $user_search->RightColumnClass ?>"><div <?php echo $user_search->accountopeningdate->cellAttributes() ?>>
			<span id="el_user_accountopeningdate" class="ew-search-field">
<input type="text" data-table="user" data-field="x_accountopeningdate" data-page="1" name="x_accountopeningdate" id="x_accountopeningdate" maxlength="10" placeholder="<?php echo HtmlEncode($user_search->accountopeningdate->getPlaceHolder()) ?>" value="<?php echo $user_search->accountopeningdate->EditValue ?>"<?php echo $user_search->accountopeningdate->editAttributes() ?>>
<?php if (!$user_search->accountopeningdate->ReadOnly && !$user_search->accountopeningdate->Disabled && !isset($user_search->accountopeningdate->EditAttrs["readonly"]) && !isset($user_search->accountopeningdate->EditAttrs["disabled"])) { ?>
<script>
loadjs.ready(["fusersearch", "datetimepicker"], function() {
	ew.createDateTimePicker("fusersearch", "x_accountopeningdate", {"ignoreReadonly":true,"useCurrent":false,"format":0});
});
</script>
<?php } ?>
</span>
		</div></div>
	</div>
<?php } ?>
<?php if ($user_search->extendedfields->Visible) { // extendedfields ?>
	<div id="r_extendedfields" class="form-group row">
		<label for="x_extendedfields" class="<?php echo $user_search->LeftColumnClass ?>"><span id="elh_user_extendedfields"><?php echo $user_search->extendedfields->caption() ?></span>
		<span class="ew-search-operator">
<?php echo $Language->phrase("LIKE") ?>
<input type="hidden" name="z_extendedfields" id="z_extendedfields" value="LIKE">
</span>
		</label>
		<div class="<?php echo $user_search->RightColumnClass ?>"><div <?php echo $user_search->extendedfields->cellAttributes() ?>>
			<span id="el_user_extendedfields" class="ew-search-field">
<input type="text" data-table="user" data-field="x_extendedfields" data-page="1" name="x_extendedfields" id="x_extendedfields" size="35" placeholder="<?php echo HtmlEncode($user_search->extendedfields->getPlaceHolder()) ?>" value="<?php echo $user_search->extendedfields->EditValue ?>"<?php echo $user_search->extendedfields->editAttributes() ?>>
</span>
		</div></div>
	</div>
<?php } ?>
<?php if ($user_search->lastprofilestatuschangedate->Visible) { // lastprofilestatuschangedate ?>
	<div id="r_lastprofilestatuschangedate" class="form-group row">
		<label for="x_lastprofilestatuschangedate" class="<?php echo $user_search->LeftColumnClass ?>"><span id="elh_user_lastprofilestatuschangedate"><?php echo $user_search->lastprofilestatuschangedate->caption() ?></span>
		<span class="ew-search-operator">
<?php echo $Language->phrase("=") ?>
<input type="hidden" name="z_lastprofilestatuschangedate" id="z_lastprofilestatuschangedate" value="=">
</span>
		</label>
		<div class="<?php echo $user_search->RightColumnClass ?>"><div <?php echo $user_search->lastprofilestatuschangedate->cellAttributes() ?>>
			<span id="el_user_lastprofilestatuschangedate" class="ew-search-field">
<input type="text" data-table="user" data-field="x_lastprofilestatuschangedate" data-page="1" name="x_lastprofilestatuschangedate" id="x_lastprofilestatuschangedate" maxlength="19" placeholder="<?php echo HtmlEncode($user_search->lastprofilestatuschangedate->getPlaceHolder()) ?>" value="<?php echo $user_search->lastprofilestatuschangedate->EditValue ?>"<?php echo $user_search->lastprofilestatuschangedate->editAttributes() ?>>
<?php if (!$user_search->lastprofilestatuschangedate->ReadOnly && !$user_search->lastprofilestatuschangedate->Disabled && !isset($user_search->lastprofilestatuschangedate->EditAttrs["readonly"]) && !isset($user_search->lastprofilestatuschangedate->EditAttrs["disabled"])) { ?>
<script>
loadjs.ready(["fusersearch", "datetimepicker"], function() {
	ew.createDateTimePicker("fusersearch", "x_lastprofilestatuschangedate", {"ignoreReadonly":true,"useCurrent":false,"format":0});
});
</script>
<?php } ?>
</span>
		</div></div>
	</div>
<?php } ?>
</div><!-- /page* -->
		</div><!-- /multi-page .tab-pane -->
		<div class="tab-pane<?php echo $user_search->MultiPages->pageStyle(2) ?>" id="tab_user2"><!-- multi-page .tab-pane -->
<div class="ew-search-div"><!-- page* -->
<?php if ($user_search->challengeq1->Visible) { // challengeq1 ?>
	<div id="r_challengeq1" class="form-group row">
		<label for="x_challengeq1" class="<?php echo $user_search->LeftColumnClass ?>"><span id="elh_user_challengeq1"><?php echo $user_search->challengeq1->caption() ?></span>
		<span class="ew-search-operator">
<?php echo $Language->phrase("=") ?>
<input type="hidden" name="z_challengeq1" id="z_challengeq1" value="=">
</span>
		</label>
		<div class="<?php echo $user_search->RightColumnClass ?>"><div <?php echo $user_search->challengeq1->cellAttributes() ?>>
			<span id="el_user_challengeq1" class="ew-search-field">
<input type="text" data-table="user" data-field="x_challengeq1" data-page="2" name="x_challengeq1" id="x_challengeq1" size="30" placeholder="<?php echo HtmlEncode($user_search->challengeq1->getPlaceHolder()) ?>" value="<?php echo $user_search->challengeq1->EditValue ?>"<?php echo $user_search->challengeq1->editAttributes() ?>>
</span>
		</div></div>
	</div>
<?php } ?>
<?php if ($user_search->challengeq2->Visible) { // challengeq2 ?>
	<div id="r_challengeq2" class="form-group row">
		<label for="x_challengeq2" class="<?php echo $user_search->LeftColumnClass ?>"><span id="elh_user_challengeq2"><?php echo $user_search->challengeq2->caption() ?></span>
		<span class="ew-search-operator">
<?php echo $Language->phrase("=") ?>
<input type="hidden" name="z_challengeq2" id="z_challengeq2" value="=">
</span>
		</label>
		<div class="<?php echo $user_search->RightColumnClass ?>"><div <?php echo $user_search->challengeq2->cellAttributes() ?>>
			<span id="el_user_challengeq2" class="ew-search-field">
<input type="text" data-table="user" data-field="x_challengeq2" data-page="2" name="x_challengeq2" id="x_challengeq2" size="30" placeholder="<?php echo HtmlEncode($user_search->challengeq2->getPlaceHolder()) ?>" value="<?php echo $user_search->challengeq2->EditValue ?>"<?php echo $user_search->challengeq2->editAttributes() ?>>
</span>
		</div></div>
	</div>
<?php } ?>
<?php if ($user_search->challengeq3->Visible) { // challengeq3 ?>
	<div id="r_challengeq3" class="form-group row">
		<label for="x_challengeq3" class="<?php echo $user_search->LeftColumnClass ?>"><span id="elh_user_challengeq3"><?php echo $user_search->challengeq3->caption() ?></span>
		<span class="ew-search-operator">
<?php echo $Language->phrase("=") ?>
<input type="hidden" name="z_challengeq3" id="z_challengeq3" value="=">
</span>
		</label>
		<div class="<?php echo $user_search->RightColumnClass ?>"><div <?php echo $user_search->challengeq3->cellAttributes() ?>>
			<span id="el_user_challengeq3" class="ew-search-field">
<input type="text" data-table="user" data-field="x_challengeq3" data-page="2" name="x_challengeq3" id="x_challengeq3" size="30" placeholder="<?php echo HtmlEncode($user_search->challengeq3->getPlaceHolder()) ?>" value="<?php echo $user_search->challengeq3->EditValue ?>"<?php echo $user_search->challengeq3->editAttributes() ?>>
</span>
		</div></div>
	</div>
<?php } ?>
</div><!-- /page* -->
		</div><!-- /multi-page .tab-pane -->
		<div class="tab-pane<?php echo $user_search->MultiPages->pageStyle(3) ?>" id="tab_user3"><!-- multi-page .tab-pane -->
<div class="ew-search-div"><!-- page* -->
<?php if ($user_search->franchiseeID->Visible) { // franchiseeID ?>
	<div id="r_franchiseeID" class="form-group row">
		<label for="x_franchiseeID" class="<?php echo $user_search->LeftColumnClass ?>"><span id="elh_user_franchiseeID"><?php echo $user_search->franchiseeID->caption() ?></span>
		<span class="ew-search-operator">
<?php echo $Language->phrase("=") ?>
<input type="hidden" name="z_franchiseeID" id="z_franchiseeID" value="=">
</span>
		</label>
		<div class="<?php echo $user_search->RightColumnClass ?>"><div <?php echo $user_search->franchiseeID->cellAttributes() ?>>
			<span id="el_user_franchiseeID" class="ew-search-field">
<input type="text" data-table="user" data-field="x_franchiseeID" data-page="3" name="x_franchiseeID" id="x_franchiseeID" size="30" placeholder="<?php echo HtmlEncode($user_search->franchiseeID->getPlaceHolder()) ?>" value="<?php echo $user_search->franchiseeID->EditValue ?>"<?php echo $user_search->franchiseeID->editAttributes() ?>>
</span>
		</div></div>
	</div>
<?php } ?>
<?php if ($user_search->telephonereceivemessage->Visible) { // telephonereceivemessage ?>
	<div id="r_telephonereceivemessage" class="form-group row">
		<label class="<?php echo $user_search->LeftColumnClass ?>"><span id="elh_user_telephonereceivemessage"><?php echo $user_search->telephonereceivemessage->caption() ?></span>
		<span class="ew-search-operator">
<?php echo $Language->phrase("=") ?>
<input type="hidden" name="z_telephonereceivemessage" id="z_telephonereceivemessage" value="=">
</span>
		</label>
		<div class="<?php echo $user_search->RightColumnClass ?>"><div <?php echo $user_search->telephonereceivemessage->cellAttributes() ?>>
			<span id="el_user_telephonereceivemessage" class="ew-search-field">
<div id="tp_x_telephonereceivemessage" class="ew-template"><input type="radio" class="custom-control-input" data-table="user" data-field="x_telephonereceivemessage" data-page="3" data-value-separator="<?php echo $user_search->telephonereceivemessage->displayValueSeparatorAttribute() ?>" name="x_telephonereceivemessage" id="x_telephonereceivemessage" value="{value}"<?php echo $user_search->telephonereceivemessage->editAttributes() ?>></div>
<div id="dsl_x_telephonereceivemessage" data-repeatcolumn="5" class="ew-item-list d-none"><div>
<?php echo $user_search->telephonereceivemessage->radioButtonListHtml(FALSE, "x_telephonereceivemessage", 3) ?>
</div></div>
<?php echo $user_search->telephonereceivemessage->Lookup->getParamTag($user_search, "p_x_telephonereceivemessage") ?>
</span>
		</div></div>
	</div>
<?php } ?>
<?php if ($user_search->verification1->Visible) { // verification1 ?>
	<div id="r_verification1" class="form-group row">
		<label for="x_verification1" class="<?php echo $user_search->LeftColumnClass ?>"><span id="elh_user_verification1"><?php echo $user_search->verification1->caption() ?></span>
		<span class="ew-search-operator">
<?php echo $Language->phrase("LIKE") ?>
<input type="hidden" name="z_verification1" id="z_verification1" value="LIKE">
</span>
		</label>
		<div class="<?php echo $user_search->RightColumnClass ?>"><div <?php echo $user_search->verification1->cellAttributes() ?>>
			<span id="el_user_verification1" class="ew-search-field">
<input type="text" data-table="user" data-field="x_verification1" data-page="3" name="x_verification1" id="x_verification1" size="30" maxlength="60" placeholder="<?php echo HtmlEncode($user_search->verification1->getPlaceHolder()) ?>" value="<?php echo $user_search->verification1->EditValue ?>"<?php echo $user_search->verification1->editAttributes() ?>>
</span>
		</div></div>
	</div>
<?php } ?>
<?php if ($user_search->verification2->Visible) { // verification2 ?>
	<div id="r_verification2" class="form-group row">
		<label for="x_verification2" class="<?php echo $user_search->LeftColumnClass ?>"><span id="elh_user_verification2"><?php echo $user_search->verification2->caption() ?></span>
		<span class="ew-search-operator">
<?php echo $Language->phrase("LIKE") ?>
<input type="hidden" name="z_verification2" id="z_verification2" value="LIKE">
</span>
		</label>
		<div class="<?php echo $user_search->RightColumnClass ?>"><div <?php echo $user_search->verification2->cellAttributes() ?>>
			<span id="el_user_verification2" class="ew-search-field">
<input type="text" data-table="user" data-field="x_verification2" data-page="3" name="x_verification2" id="x_verification2" size="30" maxlength="60" placeholder="<?php echo HtmlEncode($user_search->verification2->getPlaceHolder()) ?>" value="<?php echo $user_search->verification2->EditValue ?>"<?php echo $user_search->verification2->editAttributes() ?>>
</span>
		</div></div>
	</div>
<?php } ?>
<?php if ($user_search->verification3->Visible) { // verification3 ?>
	<div id="r_verification3" class="form-group row">
		<label for="x_verification3" class="<?php echo $user_search->LeftColumnClass ?>"><span id="elh_user_verification3"><?php echo $user_search->verification3->caption() ?></span>
		</label>
		<div class="<?php echo $user_search->RightColumnClass ?>"><div <?php echo $user_search->verification3->cellAttributes() ?>>
		<span class="ew-search-operator">
<select name="z_verification3" id="z_verification3" class="custom-select" onchange="ew.searchOperatorChanged(this);">
<option value="="<?php echo $user_search->verification3->AdvancedSearch->SearchOperator == "=" ? " selected" : "" ?>><?php echo $Language->phrase("EQUAL") ?></option>
<option value="<>"<?php echo $user_search->verification3->AdvancedSearch->SearchOperator == "<>" ? " selected" : "" ?>><?php echo $Language->phrase("<>") ?></option>
<option value="<"<?php echo $user_search->verification3->AdvancedSearch->SearchOperator == "<" ? " selected" : "" ?>><?php echo $Language->phrase("<") ?></option>
<option value="<="<?php echo $user_search->verification3->AdvancedSearch->SearchOperator == "<=" ? " selected" : "" ?>><?php echo $Language->phrase("<=") ?></option>
<option value=">"<?php echo $user_search->verification3->AdvancedSearch->SearchOperator == ">" ? " selected" : "" ?>><?php echo $Language->phrase(">") ?></option>
<option value=">="<?php echo $user_search->verification3->AdvancedSearch->SearchOperator == ">=" ? " selected" : "" ?>><?php echo $Language->phrase(">=") ?></option>
<option value="LIKE"<?php echo $user_search->verification3->AdvancedSearch->SearchOperator == "LIKE" ? " selected" : "" ?>><?php echo $Language->phrase("LIKE") ?></option>
<option value="NOT LIKE"<?php echo $user_search->verification3->AdvancedSearch->SearchOperator == "NOT LIKE" ? " selected" : "" ?>><?php echo $Language->phrase("NOT LIKE") ?></option>
<option value="STARTS WITH"<?php echo $user_search->verification3->AdvancedSearch->SearchOperator == "STARTS WITH" ? " selected" : "" ?>><?php echo $Language->phrase("STARTS WITH") ?></option>
<option value="ENDS WITH"<?php echo $user_search->verification3->AdvancedSearch->SearchOperator == "ENDS WITH" ? " selected" : "" ?>><?php echo $Language->phrase("ENDS WITH") ?></option>
<option value="IS NULL"<?php echo $user_search->verification3->AdvancedSearch->SearchOperator == "IS NULL" ? " selected" : "" ?>><?php echo $Language->phrase("IS NULL") ?></option>
<option value="IS NOT NULL"<?php echo $user_search->verification3->AdvancedSearch->SearchOperator == "IS NOT NULL" ? " selected" : "" ?>><?php echo $Language->phrase("IS NOT NULL") ?></option>
<option value="BETWEEN"<?php echo $user_search->verification3->AdvancedSearch->SearchOperator == "BETWEEN" ? " selected" : "" ?>><?php echo $Language->phrase("BETWEEN") ?></option>
</select>
</span>
			<span id="el_user_verification3" class="ew-search-field">
<input type="text" data-table="user" data-field="x_verification3" data-page="3" name="x_verification3" id="x_verification3" size="30" maxlength="60" placeholder="<?php echo HtmlEncode($user_search->verification3->getPlaceHolder()) ?>" value="<?php echo $user_search->verification3->EditValue ?>"<?php echo $user_search->verification3->editAttributes() ?>>
</span>
			<span class="ew-search-and d-none"><label><?php echo $Language->phrase("AND") ?></label></span>
			<span id="el2_user_verification3" class="ew-search-field2 d-none">
<input type="text" data-table="user" data-field="x_verification3" data-page="3" name="y_verification3" id="y_verification3" size="30" maxlength="60" placeholder="<?php echo HtmlEncode($user_search->verification3->getPlaceHolder()) ?>" value="<?php echo $user_search->verification3->EditValue2 ?>"<?php echo $user_search->verification3->editAttributes() ?>>
</span>
		</div></div>
	</div>
<?php } ?>
<?php if ($user_search->passwordCounter->Visible) { // passwordCounter ?>
	<div id="r_passwordCounter" class="form-group row">
		<label for="x_passwordCounter" class="<?php echo $user_search->LeftColumnClass ?>"><span id="elh_user_passwordCounter"><?php echo $user_search->passwordCounter->caption() ?></span>
		<span class="ew-search-operator">
<?php echo $Language->phrase("=") ?>
<input type="hidden" name="z_passwordCounter" id="z_passwordCounter" value="=">
</span>
		</label>
		<div class="<?php echo $user_search->RightColumnClass ?>"><div <?php echo $user_search->passwordCounter->cellAttributes() ?>>
			<span id="el_user_passwordCounter" class="ew-search-field">
<input type="text" data-table="user" data-field="x_passwordCounter" data-page="3" name="x_passwordCounter" id="x_passwordCounter" size="30" placeholder="<?php echo HtmlEncode($user_search->passwordCounter->getPlaceHolder()) ?>" value="<?php echo $user_search->passwordCounter->EditValue ?>"<?php echo $user_search->passwordCounter->editAttributes() ?>>
</span>
		</div></div>
	</div>
<?php } ?>
<?php if ($user_search->passwordChangedDate->Visible) { // passwordChangedDate ?>
	<div id="r_passwordChangedDate" class="form-group row">
		<label for="x_passwordChangedDate" class="<?php echo $user_search->LeftColumnClass ?>"><span id="elh_user_passwordChangedDate"><?php echo $user_search->passwordChangedDate->caption() ?></span>
		<span class="ew-search-operator">
<?php echo $Language->phrase("=") ?>
<input type="hidden" name="z_passwordChangedDate" id="z_passwordChangedDate" value="=">
</span>
		</label>
		<div class="<?php echo $user_search->RightColumnClass ?>"><div <?php echo $user_search->passwordChangedDate->cellAttributes() ?>>
			<span id="el_user_passwordChangedDate" class="ew-search-field">
<input type="text" data-table="user" data-field="x_passwordChangedDate" data-page="3" data-format="1" name="x_passwordChangedDate" id="x_passwordChangedDate" placeholder="<?php echo HtmlEncode($user_search->passwordChangedDate->getPlaceHolder()) ?>" value="<?php echo $user_search->passwordChangedDate->EditValue ?>"<?php echo $user_search->passwordChangedDate->editAttributes() ?>>
<?php if (!$user_search->passwordChangedDate->ReadOnly && !$user_search->passwordChangedDate->Disabled && !isset($user_search->passwordChangedDate->EditAttrs["readonly"]) && !isset($user_search->passwordChangedDate->EditAttrs["disabled"])) { ?>
<script>
loadjs.ready(["fusersearch", "datetimepicker"], function() {
	ew.createDateTimePicker("fusersearch", "x_passwordChangedDate", {"ignoreReadonly":true,"useCurrent":false,"format":1});
});
</script>
<?php } ?>
</span>
		</div></div>
	</div>
<?php } ?>
<?php if ($user_search->pinCounter->Visible) { // pinCounter ?>
	<div id="r_pinCounter" class="form-group row">
		<label for="x_pinCounter" class="<?php echo $user_search->LeftColumnClass ?>"><span id="elh_user_pinCounter"><?php echo $user_search->pinCounter->caption() ?></span>
		<span class="ew-search-operator">
<?php echo $Language->phrase("=") ?>
<input type="hidden" name="z_pinCounter" id="z_pinCounter" value="=">
</span>
		</label>
		<div class="<?php echo $user_search->RightColumnClass ?>"><div <?php echo $user_search->pinCounter->cellAttributes() ?>>
			<span id="el_user_pinCounter" class="ew-search-field">
<input type="text" data-table="user" data-field="x_pinCounter" data-page="3" name="x_pinCounter" id="x_pinCounter" size="30" placeholder="<?php echo HtmlEncode($user_search->pinCounter->getPlaceHolder()) ?>" value="<?php echo $user_search->pinCounter->EditValue ?>"<?php echo $user_search->pinCounter->editAttributes() ?>>
</span>
		</div></div>
	</div>
<?php } ?>
<?php if ($user_search->langID->Visible) { // langID ?>
	<div id="r_langID" class="form-group row">
		<label for="x_langID" class="<?php echo $user_search->LeftColumnClass ?>"><span id="elh_user_langID"><?php echo $user_search->langID->caption() ?></span>
		<span class="ew-search-operator">
<?php echo $Language->phrase("LIKE") ?>
<input type="hidden" name="z_langID" id="z_langID" value="LIKE">
</span>
		</label>
		<div class="<?php echo $user_search->RightColumnClass ?>"><div <?php echo $user_search->langID->cellAttributes() ?>>
			<span id="el_user_langID" class="ew-search-field">
<div class="input-group">
	<select class="custom-select ew-custom-select" data-table="user" data-field="x_langID" data-page="3" data-value-separator="<?php echo $user_search->langID->displayValueSeparatorAttribute() ?>" id="x_langID" name="x_langID"<?php echo $user_search->langID->editAttributes() ?>>
			<?php echo $user_search->langID->selectOptionListHtml("x_langID") ?>
		</select>
</div>
<?php echo $user_search->langID->Lookup->getParamTag($user_search, "p_x_langID") ?>
</span>
		</div></div>
	</div>
<?php } ?>
<?php if ($user_search->status->Visible) { // status ?>
	<div id="r_status" class="form-group row">
		<label for="x_status" class="<?php echo $user_search->LeftColumnClass ?>"><span id="elh_user_status"><?php echo $user_search->status->caption() ?></span>
		<span class="ew-search-operator">
<?php echo $Language->phrase("=") ?>
<input type="hidden" name="z_status" id="z_status" value="=">
</span>
		</label>
		<div class="<?php echo $user_search->RightColumnClass ?>"><div <?php echo $user_search->status->cellAttributes() ?>>
			<span id="el_user_status" class="ew-search-field">
<div class="input-group">
	<select class="custom-select ew-custom-select" data-table="user" data-field="x_status" data-page="3" data-value-separator="<?php echo $user_search->status->displayValueSeparatorAttribute() ?>" id="x_status" name="x_status"<?php echo $user_search->status->editAttributes() ?>>
			<?php echo $user_search->status->selectOptionListHtml("x_status") ?>
		</select>
</div>
<?php echo $user_search->status->Lookup->getParamTag($user_search, "p_x_status") ?>
</span>
		</div></div>
	</div>
<?php } ?>
<?php if ($user_search->markedfordeletion->Visible) { // markedfordeletion ?>
	<div id="r_markedfordeletion" class="form-group row">
		<label for="x_markedfordeletion" class="<?php echo $user_search->LeftColumnClass ?>"><span id="elh_user_markedfordeletion"><?php echo $user_search->markedfordeletion->caption() ?></span>
		<span class="ew-search-operator">
<?php echo $Language->phrase("=") ?>
<input type="hidden" name="z_markedfordeletion" id="z_markedfordeletion" value="=">
</span>
		</label>
		<div class="<?php echo $user_search->RightColumnClass ?>"><div <?php echo $user_search->markedfordeletion->cellAttributes() ?>>
			<span id="el_user_markedfordeletion" class="ew-search-field">
<input type="text" data-table="user" data-field="x_markedfordeletion" data-page="3" name="x_markedfordeletion" id="x_markedfordeletion" maxlength="10" placeholder="<?php echo HtmlEncode($user_search->markedfordeletion->getPlaceHolder()) ?>" value="<?php echo $user_search->markedfordeletion->EditValue ?>"<?php echo $user_search->markedfordeletion->editAttributes() ?>>
<?php if (!$user_search->markedfordeletion->ReadOnly && !$user_search->markedfordeletion->Disabled && !isset($user_search->markedfordeletion->EditAttrs["readonly"]) && !isset($user_search->markedfordeletion->EditAttrs["disabled"])) { ?>
<script>
loadjs.ready(["fusersearch", "datetimepicker"], function() {
	ew.createDateTimePicker("fusersearch", "x_markedfordeletion", {"ignoreReadonly":true,"useCurrent":false,"format":0});
});
</script>
<?php } ?>
</span>
		</div></div>
	</div>
<?php } ?>
<?php if ($user_search->userType->Visible) { // userType ?>
	<div id="r_userType" class="form-group row">
		<label for="x_userType" class="<?php echo $user_search->LeftColumnClass ?>"><span id="elh_user_userType"><?php echo $user_search->userType->caption() ?></span>
		<span class="ew-search-operator">
<?php echo $Language->phrase("=") ?>
<input type="hidden" name="z_userType" id="z_userType" value="=">
</span>
		</label>
		<div class="<?php echo $user_search->RightColumnClass ?>"><div <?php echo $user_search->userType->cellAttributes() ?>>
			<span id="el_user_userType" class="ew-search-field">
<?php $user_search->userType->EditAttrs->prepend("onchange", "ew.updateOptions.call(this);"); ?>
<div class="input-group">
	<select class="custom-select ew-custom-select" data-table="user" data-field="x_userType" data-page="3" data-value-separator="<?php echo $user_search->userType->displayValueSeparatorAttribute() ?>" id="x_userType" name="x_userType"<?php echo $user_search->userType->editAttributes() ?>>
			<?php echo $user_search->userType->selectOptionListHtml("x_userType") ?>
		</select>
</div>
<?php echo $user_search->userType->Lookup->getParamTag($user_search, "p_x_userType") ?>
</span>
		</div></div>
	</div>
<?php } ?>
<?php if ($user_search->usersubtype->Visible) { // usersubtype ?>
	<div id="r_usersubtype" class="form-group row">
		<label for="x_usersubtype" class="<?php echo $user_search->LeftColumnClass ?>"><span id="elh_user_usersubtype"><?php echo $user_search->usersubtype->caption() ?></span>
		<span class="ew-search-operator">
<?php echo $Language->phrase("=") ?>
<input type="hidden" name="z_usersubtype" id="z_usersubtype" value="=">
</span>
		</label>
		<div class="<?php echo $user_search->RightColumnClass ?>"><div <?php echo $user_search->usersubtype->cellAttributes() ?>>
			<span id="el_user_usersubtype" class="ew-search-field">
<div class="input-group">
	<select class="custom-select ew-custom-select" data-table="user" data-field="x_usersubtype" data-page="3" data-value-separator="<?php echo $user_search->usersubtype->displayValueSeparatorAttribute() ?>" id="x_usersubtype" name="x_usersubtype"<?php echo $user_search->usersubtype->editAttributes() ?>>
			<?php echo $user_search->usersubtype->selectOptionListHtml("x_usersubtype") ?>
		</select>
</div>
<?php echo $user_search->usersubtype->Lookup->getParamTag($user_search, "p_x_usersubtype") ?>
</span>
		</div></div>
	</div>
<?php } ?>
<?php if ($user_search->brokerid->Visible) { // brokerid ?>
	<div id="r_brokerid" class="form-group row">
		<label for="x_brokerid" class="<?php echo $user_search->LeftColumnClass ?>"><span id="elh_user_brokerid"><?php echo $user_search->brokerid->caption() ?></span>
		<span class="ew-search-operator">
<?php echo $Language->phrase("=") ?>
<input type="hidden" name="z_brokerid" id="z_brokerid" value="=">
</span>
		</label>
		<div class="<?php echo $user_search->RightColumnClass ?>"><div <?php echo $user_search->brokerid->cellAttributes() ?>>
			<span id="el_user_brokerid" class="ew-search-field">
<input type="text" data-table="user" data-field="x_brokerid" data-page="3" name="x_brokerid" id="x_brokerid" size="30" placeholder="<?php echo HtmlEncode($user_search->brokerid->getPlaceHolder()) ?>" value="<?php echo $user_search->brokerid->EditValue ?>"<?php echo $user_search->brokerid->editAttributes() ?>>
</span>
		</div></div>
	</div>
<?php } ?>
<?php if ($user_search->parentuserid->Visible) { // parentuserid ?>
	<div id="r_parentuserid" class="form-group row">
		<label for="x_parentuserid" class="<?php echo $user_search->LeftColumnClass ?>"><span id="elh_user_parentuserid"><?php echo $user_search->parentuserid->caption() ?></span>
		<span class="ew-search-operator">
<?php echo $Language->phrase("=") ?>
<input type="hidden" name="z_parentuserid" id="z_parentuserid" value="=">
</span>
		</label>
		<div class="<?php echo $user_search->RightColumnClass ?>"><div <?php echo $user_search->parentuserid->cellAttributes() ?>>
			<span id="el_user_parentuserid" class="ew-search-field">
<input type="text" data-table="user" data-field="x_parentuserid" data-page="3" name="x_parentuserid" id="x_parentuserid" size="30" placeholder="<?php echo HtmlEncode($user_search->parentuserid->getPlaceHolder()) ?>" value="<?php echo $user_search->parentuserid->EditValue ?>"<?php echo $user_search->parentuserid->editAttributes() ?>>
</span>
		</div></div>
	</div>
<?php } ?>
<?php if ($user_search->corporate->Visible) { // corporate ?>
	<div id="r_corporate" class="form-group row">
		<label class="<?php echo $user_search->LeftColumnClass ?>"><span id="elh_user_corporate"><?php echo $user_search->corporate->caption() ?></span>
		<span class="ew-search-operator">
<?php echo $Language->phrase("=") ?>
<input type="hidden" name="z_corporate" id="z_corporate" value="=">
</span>
		</label>
		<div class="<?php echo $user_search->RightColumnClass ?>"><div <?php echo $user_search->corporate->cellAttributes() ?>>
			<span id="el_user_corporate" class="ew-search-field">
<div id="tp_x_corporate" class="ew-template"><input type="radio" class="custom-control-input" data-table="user" data-field="x_corporate" data-page="3" data-value-separator="<?php echo $user_search->corporate->displayValueSeparatorAttribute() ?>" name="x_corporate" id="x_corporate" value="{value}"<?php echo $user_search->corporate->editAttributes() ?>></div>
<div id="dsl_x_corporate" data-repeatcolumn="5" class="ew-item-list d-none"><div>
<?php echo $user_search->corporate->radioButtonListHtml(FALSE, "x_corporate", 3) ?>
</div></div>
<?php echo $user_search->corporate->Lookup->getParamTag($user_search, "p_x_corporate") ?>
</span>
		</div></div>
	</div>
<?php } ?>
<?php if ($user_search->jumpappid->Visible) { // jumpappid ?>
	<div id="r_jumpappid" class="form-group row">
		<label for="x_jumpappid" class="<?php echo $user_search->LeftColumnClass ?>"><span id="elh_user_jumpappid"><?php echo $user_search->jumpappid->caption() ?></span>
		<span class="ew-search-operator">
<?php echo $Language->phrase("=") ?>
<input type="hidden" name="z_jumpappid" id="z_jumpappid" value="=">
</span>
		</label>
		<div class="<?php echo $user_search->RightColumnClass ?>"><div <?php echo $user_search->jumpappid->cellAttributes() ?>>
			<span id="el_user_jumpappid" class="ew-search-field">
<input type="text" data-table="user" data-field="x_jumpappid" data-page="3" name="x_jumpappid" id="x_jumpappid" size="30" placeholder="<?php echo HtmlEncode($user_search->jumpappid->getPlaceHolder()) ?>" value="<?php echo $user_search->jumpappid->EditValue ?>"<?php echo $user_search->jumpappid->editAttributes() ?>>
</span>
		</div></div>
	</div>
<?php } ?>
<?php if ($user_search->jumprequiredatlogin->Visible) { // jumprequiredatlogin ?>
	<div id="r_jumprequiredatlogin" class="form-group row">
		<label class="<?php echo $user_search->LeftColumnClass ?>"><span id="elh_user_jumprequiredatlogin"><?php echo $user_search->jumprequiredatlogin->caption() ?></span>
		<span class="ew-search-operator">
<?php echo $Language->phrase("=") ?>
<input type="hidden" name="z_jumprequiredatlogin" id="z_jumprequiredatlogin" value="=">
</span>
		</label>
		<div class="<?php echo $user_search->RightColumnClass ?>"><div <?php echo $user_search->jumprequiredatlogin->cellAttributes() ?>>
			<span id="el_user_jumprequiredatlogin" class="ew-search-field">
<div id="tp_x_jumprequiredatlogin" class="ew-template"><input type="radio" class="custom-control-input" data-table="user" data-field="x_jumprequiredatlogin" data-page="3" data-value-separator="<?php echo $user_search->jumprequiredatlogin->displayValueSeparatorAttribute() ?>" name="x_jumprequiredatlogin" id="x_jumprequiredatlogin" value="{value}"<?php echo $user_search->jumprequiredatlogin->editAttributes() ?>></div>
<div id="dsl_x_jumprequiredatlogin" data-repeatcolumn="5" class="ew-item-list d-none"><div>
<?php echo $user_search->jumprequiredatlogin->radioButtonListHtml(FALSE, "x_jumprequiredatlogin", 3) ?>
</div></div>
<?php echo $user_search->jumprequiredatlogin->Lookup->getParamTag($user_search, "p_x_jumprequiredatlogin") ?>
</span>
		</div></div>
	</div>
<?php } ?>
<?php if ($user_search->ccbypass->Visible) { // ccbypass ?>
	<div id="r_ccbypass" class="form-group row">
		<label class="<?php echo $user_search->LeftColumnClass ?>"><span id="elh_user_ccbypass"><?php echo $user_search->ccbypass->caption() ?></span>
		<span class="ew-search-operator">
<?php echo $Language->phrase("=") ?>
<input type="hidden" name="z_ccbypass" id="z_ccbypass" value="=">
</span>
		</label>
		<div class="<?php echo $user_search->RightColumnClass ?>"><div <?php echo $user_search->ccbypass->cellAttributes() ?>>
			<span id="el_user_ccbypass" class="ew-search-field">
<div id="tp_x_ccbypass" class="ew-template"><input type="radio" class="custom-control-input" data-table="user" data-field="x_ccbypass" data-page="3" data-value-separator="<?php echo $user_search->ccbypass->displayValueSeparatorAttribute() ?>" name="x_ccbypass" id="x_ccbypass" value="{value}"<?php echo $user_search->ccbypass->editAttributes() ?>></div>
<div id="dsl_x_ccbypass" data-repeatcolumn="5" class="ew-item-list d-none"><div>
<?php echo $user_search->ccbypass->radioButtonListHtml(FALSE, "x_ccbypass", 3) ?>
</div></div>
<?php echo $user_search->ccbypass->Lookup->getParamTag($user_search, "p_x_ccbypass") ?>
</span>
		</div></div>
	</div>
<?php } ?>
<?php if ($user_search->other1->Visible) { // other1 ?>
	<div id="r_other1" class="form-group row">
		<label for="x_other1" class="<?php echo $user_search->LeftColumnClass ?>"><span id="elh_user_other1"><?php echo $user_search->other1->caption() ?></span>
		<span class="ew-search-operator">
<?php echo $Language->phrase("LIKE") ?>
<input type="hidden" name="z_other1" id="z_other1" value="LIKE">
</span>
		</label>
		<div class="<?php echo $user_search->RightColumnClass ?>"><div <?php echo $user_search->other1->cellAttributes() ?>>
			<span id="el_user_other1" class="ew-search-field">
<input type="text" data-table="user" data-field="x_other1" data-page="3" name="x_other1" id="x_other1" size="30" maxlength="25" placeholder="<?php echo HtmlEncode($user_search->other1->getPlaceHolder()) ?>" value="<?php echo $user_search->other1->EditValue ?>"<?php echo $user_search->other1->editAttributes() ?>>
</span>
		</div></div>
	</div>
<?php } ?>
<?php if ($user_search->other2->Visible) { // other2 ?>
	<div id="r_other2" class="form-group row">
		<label for="x_other2" class="<?php echo $user_search->LeftColumnClass ?>"><span id="elh_user_other2"><?php echo $user_search->other2->caption() ?></span>
		<span class="ew-search-operator">
<?php echo $Language->phrase("LIKE") ?>
<input type="hidden" name="z_other2" id="z_other2" value="LIKE">
</span>
		</label>
		<div class="<?php echo $user_search->RightColumnClass ?>"><div <?php echo $user_search->other2->cellAttributes() ?>>
			<span id="el_user_other2" class="ew-search-field">
<input type="text" data-table="user" data-field="x_other2" data-page="3" name="x_other2" id="x_other2" size="30" maxlength="25" placeholder="<?php echo HtmlEncode($user_search->other2->getPlaceHolder()) ?>" value="<?php echo $user_search->other2->EditValue ?>"<?php echo $user_search->other2->editAttributes() ?>>
</span>
		</div></div>
	</div>
<?php } ?>
<?php if ($user_search->other3->Visible) { // other3 ?>
	<div id="r_other3" class="form-group row">
		<label for="x_other3" class="<?php echo $user_search->LeftColumnClass ?>"><span id="elh_user_other3"><?php echo $user_search->other3->caption() ?></span>
		<span class="ew-search-operator">
<?php echo $Language->phrase("LIKE") ?>
<input type="hidden" name="z_other3" id="z_other3" value="LIKE">
</span>
		</label>
		<div class="<?php echo $user_search->RightColumnClass ?>"><div <?php echo $user_search->other3->cellAttributes() ?>>
			<span id="el_user_other3" class="ew-search-field">
<input type="text" data-table="user" data-field="x_other3" data-page="3" name="x_other3" id="x_other3" size="30" maxlength="25" placeholder="<?php echo HtmlEncode($user_search->other3->getPlaceHolder()) ?>" value="<?php echo $user_search->other3->EditValue ?>"<?php echo $user_search->other3->editAttributes() ?>>
</span>
		</div></div>
	</div>
<?php } ?>
<?php if ($user_search->other4->Visible) { // other4 ?>
	<div id="r_other4" class="form-group row">
		<label for="x_other4" class="<?php echo $user_search->LeftColumnClass ?>"><span id="elh_user_other4"><?php echo $user_search->other4->caption() ?></span>
		<span class="ew-search-operator">
<?php echo $Language->phrase("LIKE") ?>
<input type="hidden" name="z_other4" id="z_other4" value="LIKE">
</span>
		</label>
		<div class="<?php echo $user_search->RightColumnClass ?>"><div <?php echo $user_search->other4->cellAttributes() ?>>
			<span id="el_user_other4" class="ew-search-field">
<input type="text" data-table="user" data-field="x_other4" data-page="3" name="x_other4" id="x_other4" size="30" maxlength="25" placeholder="<?php echo HtmlEncode($user_search->other4->getPlaceHolder()) ?>" value="<?php echo $user_search->other4->EditValue ?>"<?php echo $user_search->other4->editAttributes() ?>>
</span>
		</div></div>
	</div>
<?php } ?>
<?php if ($user_search->other5->Visible) { // other5 ?>
	<div id="r_other5" class="form-group row">
		<label for="x_other5" class="<?php echo $user_search->LeftColumnClass ?>"><span id="elh_user_other5"><?php echo $user_search->other5->caption() ?></span>
		<span class="ew-search-operator">
<?php echo $Language->phrase("LIKE") ?>
<input type="hidden" name="z_other5" id="z_other5" value="LIKE">
</span>
		</label>
		<div class="<?php echo $user_search->RightColumnClass ?>"><div <?php echo $user_search->other5->cellAttributes() ?>>
			<span id="el_user_other5" class="ew-search-field">
<input type="text" data-table="user" data-field="x_other5" data-page="3" name="x_other5" id="x_other5" size="30" maxlength="25" placeholder="<?php echo HtmlEncode($user_search->other5->getPlaceHolder()) ?>" value="<?php echo $user_search->other5->EditValue ?>"<?php echo $user_search->other5->editAttributes() ?>>
</span>
		</div></div>
	</div>
<?php } ?>
<?php if ($user_search->other6->Visible) { // other6 ?>
	<div id="r_other6" class="form-group row">
		<label for="x_other6" class="<?php echo $user_search->LeftColumnClass ?>"><span id="elh_user_other6"><?php echo $user_search->other6->caption() ?></span>
		<span class="ew-search-operator">
<?php echo $Language->phrase("LIKE") ?>
<input type="hidden" name="z_other6" id="z_other6" value="LIKE">
</span>
		</label>
		<div class="<?php echo $user_search->RightColumnClass ?>"><div <?php echo $user_search->other6->cellAttributes() ?>>
			<span id="el_user_other6" class="ew-search-field">
<input type="text" data-table="user" data-field="x_other6" data-page="3" name="x_other6" id="x_other6" size="30" maxlength="25" placeholder="<?php echo HtmlEncode($user_search->other6->getPlaceHolder()) ?>" value="<?php echo $user_search->other6->EditValue ?>"<?php echo $user_search->other6->editAttributes() ?>>
</span>
		</div></div>
	</div>
<?php } ?>
<?php if ($user_search->legalid->Visible) { // legalid ?>
	<div id="r_legalid" class="form-group row">
		<label for="x_legalid" class="<?php echo $user_search->LeftColumnClass ?>"><span id="elh_user_legalid"><?php echo $user_search->legalid->caption() ?></span>
		<span class="ew-search-operator">
<?php echo $Language->phrase("=") ?>
<input type="hidden" name="z_legalid" id="z_legalid" value="=">
</span>
		</label>
		<div class="<?php echo $user_search->RightColumnClass ?>"><div <?php echo $user_search->legalid->cellAttributes() ?>>
			<span id="el_user_legalid" class="ew-search-field">
<input type="text" data-table="user" data-field="x_legalid" data-page="3" name="x_legalid" id="x_legalid" size="30" placeholder="<?php echo HtmlEncode($user_search->legalid->getPlaceHolder()) ?>" value="<?php echo $user_search->legalid->EditValue ?>"<?php echo $user_search->legalid->editAttributes() ?>>
</span>
		</div></div>
	</div>
<?php } ?>
<?php if ($user_search->userpiview->Visible) { // userpiview ?>
	<div id="r_userpiview" class="form-group row">
		<label class="<?php echo $user_search->LeftColumnClass ?>"><span id="elh_user_userpiview"><?php echo $user_search->userpiview->caption() ?></span>
		<span class="ew-search-operator">
<?php echo $Language->phrase("=") ?>
<input type="hidden" name="z_userpiview" id="z_userpiview" value="=">
</span>
		</label>
		<div class="<?php echo $user_search->RightColumnClass ?>"><div <?php echo $user_search->userpiview->cellAttributes() ?>>
			<span id="el_user_userpiview" class="ew-search-field">
<div id="tp_x_userpiview" class="ew-template"><input type="radio" class="custom-control-input" data-table="user" data-field="x_userpiview" data-page="3" data-value-separator="<?php echo $user_search->userpiview->displayValueSeparatorAttribute() ?>" name="x_userpiview" id="x_userpiview" value="{value}"<?php echo $user_search->userpiview->editAttributes() ?>></div>
<div id="dsl_x_userpiview" data-repeatcolumn="5" class="ew-item-list d-none"><div>
<?php echo $user_search->userpiview->radioButtonListHtml(FALSE, "x_userpiview", 3) ?>
</div></div>
<?php echo $user_search->userpiview->Lookup->getParamTag($user_search, "p_x_userpiview") ?>
</span>
		</div></div>
	</div>
<?php } ?>
<?php if ($user_search->lastmsgid->Visible) { // lastmsgid ?>
	<div id="r_lastmsgid" class="form-group row">
		<label for="x_lastmsgid" class="<?php echo $user_search->LeftColumnClass ?>"><span id="elh_user_lastmsgid"><?php echo $user_search->lastmsgid->caption() ?></span>
		<span class="ew-search-operator">
<?php echo $Language->phrase("=") ?>
<input type="hidden" name="z_lastmsgid" id="z_lastmsgid" value="=">
</span>
		</label>
		<div class="<?php echo $user_search->RightColumnClass ?>"><div <?php echo $user_search->lastmsgid->cellAttributes() ?>>
			<span id="el_user_lastmsgid" class="ew-search-field">
<input type="text" data-table="user" data-field="x_lastmsgid" data-page="3" name="x_lastmsgid" id="x_lastmsgid" size="30" placeholder="<?php echo HtmlEncode($user_search->lastmsgid->getPlaceHolder()) ?>" value="<?php echo $user_search->lastmsgid->EditValue ?>"<?php echo $user_search->lastmsgid->editAttributes() ?>>
</span>
		</div></div>
	</div>
<?php } ?>
</div><!-- /page* -->
		</div><!-- /multi-page .tab-pane -->
		<div class="tab-pane<?php echo $user_search->MultiPages->pageStyle(4) ?>" id="tab_user4"><!-- multi-page .tab-pane -->
<div class="ew-search-div"><!-- page* -->
<?php if ($user_search->mincashamount->Visible) { // mincashamount ?>
	<div id="r_mincashamount" class="form-group row">
		<label for="x_mincashamount" class="<?php echo $user_search->LeftColumnClass ?>"><span id="elh_user_mincashamount"><?php echo $user_search->mincashamount->caption() ?></span>
		<span class="ew-search-operator">
<?php echo $Language->phrase("=") ?>
<input type="hidden" name="z_mincashamount" id="z_mincashamount" value="=">
</span>
		</label>
		<div class="<?php echo $user_search->RightColumnClass ?>"><div <?php echo $user_search->mincashamount->cellAttributes() ?>>
			<span id="el_user_mincashamount" class="ew-search-field">
<input type="text" data-table="user" data-field="x_mincashamount" data-page="4" name="x_mincashamount" id="x_mincashamount" size="30" placeholder="<?php echo HtmlEncode($user_search->mincashamount->getPlaceHolder()) ?>" value="<?php echo $user_search->mincashamount->EditValue ?>"<?php echo $user_search->mincashamount->editAttributes() ?>>
</span>
		</div></div>
	</div>
<?php } ?>
<?php if ($user_search->maxcashamount->Visible) { // maxcashamount ?>
	<div id="r_maxcashamount" class="form-group row">
		<label for="x_maxcashamount" class="<?php echo $user_search->LeftColumnClass ?>"><span id="elh_user_maxcashamount"><?php echo $user_search->maxcashamount->caption() ?></span>
		<span class="ew-search-operator">
<?php echo $Language->phrase("=") ?>
<input type="hidden" name="z_maxcashamount" id="z_maxcashamount" value="=">
</span>
		</label>
		<div class="<?php echo $user_search->RightColumnClass ?>"><div <?php echo $user_search->maxcashamount->cellAttributes() ?>>
			<span id="el_user_maxcashamount" class="ew-search-field">
<input type="text" data-table="user" data-field="x_maxcashamount" data-page="4" name="x_maxcashamount" id="x_maxcashamount" size="30" placeholder="<?php echo HtmlEncode($user_search->maxcashamount->getPlaceHolder()) ?>" value="<?php echo $user_search->maxcashamount->EditValue ?>"<?php echo $user_search->maxcashamount->editAttributes() ?>>
</span>
		</div></div>
	</div>
<?php } ?>
<?php if ($user_search->maxtransferinamount->Visible) { // maxtransferinamount ?>
	<div id="r_maxtransferinamount" class="form-group row">
		<label for="x_maxtransferinamount" class="<?php echo $user_search->LeftColumnClass ?>"><span id="elh_user_maxtransferinamount"><?php echo $user_search->maxtransferinamount->caption() ?></span>
		<span class="ew-search-operator">
<?php echo $Language->phrase("=") ?>
<input type="hidden" name="z_maxtransferinamount" id="z_maxtransferinamount" value="=">
</span>
		</label>
		<div class="<?php echo $user_search->RightColumnClass ?>"><div <?php echo $user_search->maxtransferinamount->cellAttributes() ?>>
			<span id="el_user_maxtransferinamount" class="ew-search-field">
<input type="text" data-table="user" data-field="x_maxtransferinamount" data-page="4" name="x_maxtransferinamount" id="x_maxtransferinamount" size="30" placeholder="<?php echo HtmlEncode($user_search->maxtransferinamount->getPlaceHolder()) ?>" value="<?php echo $user_search->maxtransferinamount->EditValue ?>"<?php echo $user_search->maxtransferinamount->editAttributes() ?>>
</span>
		</div></div>
	</div>
<?php } ?>
<?php if ($user_search->maxtransferoutamount->Visible) { // maxtransferoutamount ?>
	<div id="r_maxtransferoutamount" class="form-group row">
		<label for="x_maxtransferoutamount" class="<?php echo $user_search->LeftColumnClass ?>"><span id="elh_user_maxtransferoutamount"><?php echo $user_search->maxtransferoutamount->caption() ?></span>
		<span class="ew-search-operator">
<?php echo $Language->phrase("=") ?>
<input type="hidden" name="z_maxtransferoutamount" id="z_maxtransferoutamount" value="=">
</span>
		</label>
		<div class="<?php echo $user_search->RightColumnClass ?>"><div <?php echo $user_search->maxtransferoutamount->cellAttributes() ?>>
			<span id="el_user_maxtransferoutamount" class="ew-search-field">
<input type="text" data-table="user" data-field="x_maxtransferoutamount" data-page="4" name="x_maxtransferoutamount" id="x_maxtransferoutamount" size="30" placeholder="<?php echo HtmlEncode($user_search->maxtransferoutamount->getPlaceHolder()) ?>" value="<?php echo $user_search->maxtransferoutamount->EditValue ?>"<?php echo $user_search->maxtransferoutamount->editAttributes() ?>>
</span>
		</div></div>
	</div>
<?php } ?>
</div><!-- /page* -->
		</div><!-- /multi-page .tab-pane -->
	</div><!-- /multi-page tabs .tab-content -->
</div><!-- /multi-page tabs -->
</div><!-- /multi-page -->
<?php if (!$user_search->IsModal) { ?>
<div class="form-group row"><!-- buttons .form-group -->
	<div class="<?php echo $user_search->OffsetColumnClass ?>"><!-- buttons offset -->
<button class="btn btn-primary ew-btn" name="btn-action" id="btn-action" type="submit"><?php echo $Language->phrase("Search") ?></button>
<button class="btn btn-default ew-btn" name="btn-reset" id="btn-reset" type="button" onclick="ew.clearForm(this.form);"><?php echo $Language->phrase("Reset") ?></button>
	</div><!-- /buttons offset -->
</div><!-- /buttons .form-group -->
<?php } ?>
</form>
<?php
$user_search->showPageFooter();
if (Config("DEBUG"))
	echo GetDebugMessage();
?>
<script>
loadjs.ready("load", function() {

	// Startup script
	// Write your table-specific startup script here
	// console.log("page loaded");

});
</script>
<?php include_once "footer.php"; ?>
<?php
$user_search->terminate();
?>