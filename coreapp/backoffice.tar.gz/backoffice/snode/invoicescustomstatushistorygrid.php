<?php
namespace PHPMaker2020\_4payadmin;

// Write header
WriteHeader(FALSE);

// Create page object
if (!isset($invoicescustomstatushistory_grid))
	$invoicescustomstatushistory_grid = new invoicescustomstatushistory_grid();

// Run the page
$invoicescustomstatushistory_grid->run();

// Setup login status
SetupLoginStatus();
SetClientVar("login", LoginStatus());

// Global Page Rendering event (in userfn*.php)
Page_Rendering();

// Page Rendering event
$invoicescustomstatushistory_grid->Page_Render();
?>
<?php if (!$invoicescustomstatushistory_grid->isExport()) { ?>
<script>
var finvoicescustomstatushistorygrid, currentPageID;
loadjs.ready("head", function() {

	// Form object
	finvoicescustomstatushistorygrid = new ew.Form("finvoicescustomstatushistorygrid", "grid");
	finvoicescustomstatushistorygrid.formKeyCountName = '<?php echo $invoicescustomstatushistory_grid->FormKeyCountName ?>';

	// Validate form
	finvoicescustomstatushistorygrid.validate = function() {
		if (!this.validateRequired)
			return true; // Ignore validation
		var $ = jQuery, fobj = this.getForm(), $fobj = $(fobj);
		if ($fobj.find("#confirm").val() == "confirm")
			return true;
		var elm, felm, uelm, addcnt = 0;
		var $k = $fobj.find("#" + this.formKeyCountName); // Get key_count
		var rowcnt = ($k[0]) ? parseInt($k.val(), 10) : 1;
		var startcnt = (rowcnt == 0) ? 0 : 1; // Check rowcnt == 0 => Inline-Add
		var gridinsert = ["insert", "gridinsert"].includes($fobj.find("#action").val()) && $k[0];
		for (var i = startcnt; i <= rowcnt; i++) {
			var infix = ($k[0]) ? String(i) : "";
			$fobj.data("rowindex", infix);
			var checkrow = (gridinsert) ? !this.emptyRow(infix) : true;
			if (checkrow) {
				addcnt++;
			<?php if ($invoicescustomstatushistory_grid->changeid->Required) { ?>
				elm = this.getElements("x" + infix + "_changeid");
				if (elm && !ew.isHidden(elm) && !ew.hasValue(elm))
					return this.onError(elm, "<?php echo JsEncode(str_replace("%s", $invoicescustomstatushistory_grid->changeid->caption(), $invoicescustomstatushistory_grid->changeid->RequiredErrorMessage)) ?>");
			<?php } ?>
			<?php if ($invoicescustomstatushistory_grid->invoiceid->Required) { ?>
				elm = this.getElements("x" + infix + "_invoiceid");
				if (elm && !ew.isHidden(elm) && !ew.hasValue(elm))
					return this.onError(elm, "<?php echo JsEncode(str_replace("%s", $invoicescustomstatushistory_grid->invoiceid->caption(), $invoicescustomstatushistory_grid->invoiceid->RequiredErrorMessage)) ?>");
			<?php } ?>
				elm = this.getElements("x" + infix + "_invoiceid");
				if (elm && !ew.checkInteger(elm.value))
					return this.onError(elm, "<?php echo JsEncode($invoicescustomstatushistory_grid->invoiceid->errorMessage()) ?>");
			<?php if ($invoicescustomstatushistory_grid->fromcustomstatus->Required) { ?>
				elm = this.getElements("x" + infix + "_fromcustomstatus");
				if (elm && !ew.isHidden(elm) && !ew.hasValue(elm))
					return this.onError(elm, "<?php echo JsEncode(str_replace("%s", $invoicescustomstatushistory_grid->fromcustomstatus->caption(), $invoicescustomstatushistory_grid->fromcustomstatus->RequiredErrorMessage)) ?>");
			<?php } ?>
			<?php if ($invoicescustomstatushistory_grid->tocustomstatus->Required) { ?>
				elm = this.getElements("x" + infix + "_tocustomstatus");
				if (elm && !ew.isHidden(elm) && !ew.hasValue(elm))
					return this.onError(elm, "<?php echo JsEncode(str_replace("%s", $invoicescustomstatushistory_grid->tocustomstatus->caption(), $invoicescustomstatushistory_grid->tocustomstatus->RequiredErrorMessage)) ?>");
			<?php } ?>
				elm = this.getElements("x" + infix + "_tocustomstatus");
				if (elm && !ew.checkInteger(elm.value))
					return this.onError(elm, "<?php echo JsEncode($invoicescustomstatushistory_grid->tocustomstatus->errorMessage()) ?>");
			<?php if ($invoicescustomstatushistory_grid->changetime->Required) { ?>
				elm = this.getElements("x" + infix + "_changetime");
				if (elm && !ew.isHidden(elm) && !ew.hasValue(elm))
					return this.onError(elm, "<?php echo JsEncode(str_replace("%s", $invoicescustomstatushistory_grid->changetime->caption(), $invoicescustomstatushistory_grid->changetime->RequiredErrorMessage)) ?>");
			<?php } ?>
				elm = this.getElements("x" + infix + "_changetime");
				if (elm && !ew.checkDateDef(elm.value))
					return this.onError(elm, "<?php echo JsEncode($invoicescustomstatushistory_grid->changetime->errorMessage()) ?>");

				// Call Form_CustomValidate event
				if (!this.Form_CustomValidate(fobj))
					return false;
			} // End Grid Add checking
		}
		return true;
	}

	// Check empty row
	finvoicescustomstatushistorygrid.emptyRow = function(infix) {
		var fobj = this._form;
		if (ew.valueChanged(fobj, infix, "invoiceid", false)) return false;
		if (ew.valueChanged(fobj, infix, "fromcustomstatus", false)) return false;
		if (ew.valueChanged(fobj, infix, "tocustomstatus", false)) return false;
		if (ew.valueChanged(fobj, infix, "changetime", false)) return false;
		return true;
	}

	// Form_CustomValidate
	finvoicescustomstatushistorygrid.Form_CustomValidate = function(fobj) { // DO NOT CHANGE THIS LINE!

		// Your custom validation code here, return false if invalid.
		return true;
	}

	// Use JavaScript validation or not
	finvoicescustomstatushistorygrid.validateRequired = <?php echo Config("CLIENT_VALIDATE") ? "true" : "false" ?>;

	// Dynamic selection lists
	finvoicescustomstatushistorygrid.lists["x_fromcustomstatus"] = <?php echo $invoicescustomstatushistory_grid->fromcustomstatus->Lookup->toClientList($invoicescustomstatushistory_grid) ?>;
	finvoicescustomstatushistorygrid.lists["x_fromcustomstatus"].options = <?php echo JsonEncode($invoicescustomstatushistory_grid->fromcustomstatus->lookupOptions()) ?>;
	finvoicescustomstatushistorygrid.lists["x_tocustomstatus"] = <?php echo $invoicescustomstatushistory_grid->tocustomstatus->Lookup->toClientList($invoicescustomstatushistory_grid) ?>;
	finvoicescustomstatushistorygrid.lists["x_tocustomstatus"].options = <?php echo JsonEncode($invoicescustomstatushistory_grid->tocustomstatus->lookupOptions()) ?>;
	finvoicescustomstatushistorygrid.autoSuggests["x_tocustomstatus"] = <?php echo json_encode(["data" => "ajax=autosuggest"]) ?>;
	loadjs.done("finvoicescustomstatushistorygrid");
});
</script>
<?php } ?>
<?php
$invoicescustomstatushistory_grid->renderOtherOptions();
?>
<?php if ($invoicescustomstatushistory_grid->TotalRecords > 0 || $invoicescustomstatushistory->CurrentAction) { ?>
<div class="card ew-card ew-grid<?php if ($invoicescustomstatushistory_grid->isAddOrEdit()) { ?> ew-grid-add-edit<?php } ?> invoicescustomstatushistory">
<div id="finvoicescustomstatushistorygrid" class="ew-form ew-list-form form-inline">
<div id="gmp_invoicescustomstatushistory" class="<?php echo ResponsiveTableClass() ?>card-body ew-grid-middle-panel">
<table id="tbl_invoicescustomstatushistorygrid" class="table ew-table"><!-- .ew-table -->
<thead>
	<tr class="ew-table-header">
<?php

// Header row
$invoicescustomstatushistory->RowType = ROWTYPE_HEADER;

// Render list options
$invoicescustomstatushistory_grid->renderListOptions();

// Render list options (header, left)
$invoicescustomstatushistory_grid->ListOptions->render("header", "left");
?>
<?php if ($invoicescustomstatushistory_grid->changeid->Visible) { // changeid ?>
	<?php if ($invoicescustomstatushistory_grid->SortUrl($invoicescustomstatushistory_grid->changeid) == "") { ?>
		<th data-name="changeid" class="<?php echo $invoicescustomstatushistory_grid->changeid->headerCellClass() ?>"><div id="elh_invoicescustomstatushistory_changeid" class="invoicescustomstatushistory_changeid"><div class="ew-table-header-caption"><?php echo $invoicescustomstatushistory_grid->changeid->caption() ?></div></div></th>
	<?php } else { ?>
		<th data-name="changeid" class="<?php echo $invoicescustomstatushistory_grid->changeid->headerCellClass() ?>"><div><div id="elh_invoicescustomstatushistory_changeid" class="invoicescustomstatushistory_changeid">
			<div class="ew-table-header-btn"><span class="ew-table-header-caption"><?php echo $invoicescustomstatushistory_grid->changeid->caption() ?></span><span class="ew-table-header-sort"><?php if ($invoicescustomstatushistory_grid->changeid->getSort() == "ASC") { ?><i class="fas fa-sort-up"></i><?php } elseif ($invoicescustomstatushistory_grid->changeid->getSort() == "DESC") { ?><i class="fas fa-sort-down"></i><?php } ?></span></div>
		</div></div></th>
	<?php } ?>
<?php } ?>
<?php if ($invoicescustomstatushistory_grid->invoiceid->Visible) { // invoiceid ?>
	<?php if ($invoicescustomstatushistory_grid->SortUrl($invoicescustomstatushistory_grid->invoiceid) == "") { ?>
		<th data-name="invoiceid" class="<?php echo $invoicescustomstatushistory_grid->invoiceid->headerCellClass() ?>"><div id="elh_invoicescustomstatushistory_invoiceid" class="invoicescustomstatushistory_invoiceid"><div class="ew-table-header-caption"><?php echo $invoicescustomstatushistory_grid->invoiceid->caption() ?></div></div></th>
	<?php } else { ?>
		<th data-name="invoiceid" class="<?php echo $invoicescustomstatushistory_grid->invoiceid->headerCellClass() ?>"><div><div id="elh_invoicescustomstatushistory_invoiceid" class="invoicescustomstatushistory_invoiceid">
			<div class="ew-table-header-btn"><span class="ew-table-header-caption"><?php echo $invoicescustomstatushistory_grid->invoiceid->caption() ?></span><span class="ew-table-header-sort"><?php if ($invoicescustomstatushistory_grid->invoiceid->getSort() == "ASC") { ?><i class="fas fa-sort-up"></i><?php } elseif ($invoicescustomstatushistory_grid->invoiceid->getSort() == "DESC") { ?><i class="fas fa-sort-down"></i><?php } ?></span></div>
		</div></div></th>
	<?php } ?>
<?php } ?>
<?php if ($invoicescustomstatushistory_grid->fromcustomstatus->Visible) { // fromcustomstatus ?>
	<?php if ($invoicescustomstatushistory_grid->SortUrl($invoicescustomstatushistory_grid->fromcustomstatus) == "") { ?>
		<th data-name="fromcustomstatus" class="<?php echo $invoicescustomstatushistory_grid->fromcustomstatus->headerCellClass() ?>"><div id="elh_invoicescustomstatushistory_fromcustomstatus" class="invoicescustomstatushistory_fromcustomstatus"><div class="ew-table-header-caption"><?php echo $invoicescustomstatushistory_grid->fromcustomstatus->caption() ?></div></div></th>
	<?php } else { ?>
		<th data-name="fromcustomstatus" class="<?php echo $invoicescustomstatushistory_grid->fromcustomstatus->headerCellClass() ?>"><div><div id="elh_invoicescustomstatushistory_fromcustomstatus" class="invoicescustomstatushistory_fromcustomstatus">
			<div class="ew-table-header-btn"><span class="ew-table-header-caption"><?php echo $invoicescustomstatushistory_grid->fromcustomstatus->caption() ?></span><span class="ew-table-header-sort"><?php if ($invoicescustomstatushistory_grid->fromcustomstatus->getSort() == "ASC") { ?><i class="fas fa-sort-up"></i><?php } elseif ($invoicescustomstatushistory_grid->fromcustomstatus->getSort() == "DESC") { ?><i class="fas fa-sort-down"></i><?php } ?></span></div>
		</div></div></th>
	<?php } ?>
<?php } ?>
<?php if ($invoicescustomstatushistory_grid->tocustomstatus->Visible) { // tocustomstatus ?>
	<?php if ($invoicescustomstatushistory_grid->SortUrl($invoicescustomstatushistory_grid->tocustomstatus) == "") { ?>
		<th data-name="tocustomstatus" class="<?php echo $invoicescustomstatushistory_grid->tocustomstatus->headerCellClass() ?>"><div id="elh_invoicescustomstatushistory_tocustomstatus" class="invoicescustomstatushistory_tocustomstatus"><div class="ew-table-header-caption"><?php echo $invoicescustomstatushistory_grid->tocustomstatus->caption() ?></div></div></th>
	<?php } else { ?>
		<th data-name="tocustomstatus" class="<?php echo $invoicescustomstatushistory_grid->tocustomstatus->headerCellClass() ?>"><div><div id="elh_invoicescustomstatushistory_tocustomstatus" class="invoicescustomstatushistory_tocustomstatus">
			<div class="ew-table-header-btn"><span class="ew-table-header-caption"><?php echo $invoicescustomstatushistory_grid->tocustomstatus->caption() ?></span><span class="ew-table-header-sort"><?php if ($invoicescustomstatushistory_grid->tocustomstatus->getSort() == "ASC") { ?><i class="fas fa-sort-up"></i><?php } elseif ($invoicescustomstatushistory_grid->tocustomstatus->getSort() == "DESC") { ?><i class="fas fa-sort-down"></i><?php } ?></span></div>
		</div></div></th>
	<?php } ?>
<?php } ?>
<?php if ($invoicescustomstatushistory_grid->changetime->Visible) { // changetime ?>
	<?php if ($invoicescustomstatushistory_grid->SortUrl($invoicescustomstatushistory_grid->changetime) == "") { ?>
		<th data-name="changetime" class="<?php echo $invoicescustomstatushistory_grid->changetime->headerCellClass() ?>"><div id="elh_invoicescustomstatushistory_changetime" class="invoicescustomstatushistory_changetime"><div class="ew-table-header-caption"><?php echo $invoicescustomstatushistory_grid->changetime->caption() ?></div></div></th>
	<?php } else { ?>
		<th data-name="changetime" class="<?php echo $invoicescustomstatushistory_grid->changetime->headerCellClass() ?>"><div><div id="elh_invoicescustomstatushistory_changetime" class="invoicescustomstatushistory_changetime">
			<div class="ew-table-header-btn"><span class="ew-table-header-caption"><?php echo $invoicescustomstatushistory_grid->changetime->caption() ?></span><span class="ew-table-header-sort"><?php if ($invoicescustomstatushistory_grid->changetime->getSort() == "ASC") { ?><i class="fas fa-sort-up"></i><?php } elseif ($invoicescustomstatushistory_grid->changetime->getSort() == "DESC") { ?><i class="fas fa-sort-down"></i><?php } ?></span></div>
		</div></div></th>
	<?php } ?>
<?php } ?>
<?php

// Render list options (header, right)
$invoicescustomstatushistory_grid->ListOptions->render("header", "right");
?>
	</tr>
</thead>
<tbody>
<?php
$invoicescustomstatushistory_grid->StartRecord = 1;
$invoicescustomstatushistory_grid->StopRecord = $invoicescustomstatushistory_grid->TotalRecords; // Show all records

// Restore number of post back records
if ($CurrentForm && ($invoicescustomstatushistory->isConfirm() || $invoicescustomstatushistory_grid->EventCancelled)) {
	$CurrentForm->Index = -1;
	if ($CurrentForm->hasValue($invoicescustomstatushistory_grid->FormKeyCountName) && ($invoicescustomstatushistory_grid->isGridAdd() || $invoicescustomstatushistory_grid->isGridEdit() || $invoicescustomstatushistory->isConfirm())) {
		$invoicescustomstatushistory_grid->KeyCount = $CurrentForm->getValue($invoicescustomstatushistory_grid->FormKeyCountName);
		$invoicescustomstatushistory_grid->StopRecord = $invoicescustomstatushistory_grid->StartRecord + $invoicescustomstatushistory_grid->KeyCount - 1;
	}
}
$invoicescustomstatushistory_grid->RecordCount = $invoicescustomstatushistory_grid->StartRecord - 1;
if ($invoicescustomstatushistory_grid->Recordset && !$invoicescustomstatushistory_grid->Recordset->EOF) {
	$invoicescustomstatushistory_grid->Recordset->moveFirst();
	$selectLimit = $invoicescustomstatushistory_grid->UseSelectLimit;
	if (!$selectLimit && $invoicescustomstatushistory_grid->StartRecord > 1)
		$invoicescustomstatushistory_grid->Recordset->move($invoicescustomstatushistory_grid->StartRecord - 1);
} elseif (!$invoicescustomstatushistory->AllowAddDeleteRow && $invoicescustomstatushistory_grid->StopRecord == 0) {
	$invoicescustomstatushistory_grid->StopRecord = $invoicescustomstatushistory->GridAddRowCount;
}

// Initialize aggregate
$invoicescustomstatushistory->RowType = ROWTYPE_AGGREGATEINIT;
$invoicescustomstatushistory->resetAttributes();
$invoicescustomstatushistory_grid->renderRow();
if ($invoicescustomstatushistory_grid->isGridAdd())
	$invoicescustomstatushistory_grid->RowIndex = 0;
if ($invoicescustomstatushistory_grid->isGridEdit())
	$invoicescustomstatushistory_grid->RowIndex = 0;
while ($invoicescustomstatushistory_grid->RecordCount < $invoicescustomstatushistory_grid->StopRecord) {
	$invoicescustomstatushistory_grid->RecordCount++;
	if ($invoicescustomstatushistory_grid->RecordCount >= $invoicescustomstatushistory_grid->StartRecord) {
		$invoicescustomstatushistory_grid->RowCount++;
		if ($invoicescustomstatushistory_grid->isGridAdd() || $invoicescustomstatushistory_grid->isGridEdit() || $invoicescustomstatushistory->isConfirm()) {
			$invoicescustomstatushistory_grid->RowIndex++;
			$CurrentForm->Index = $invoicescustomstatushistory_grid->RowIndex;
			if ($CurrentForm->hasValue($invoicescustomstatushistory_grid->FormActionName) && ($invoicescustomstatushistory->isConfirm() || $invoicescustomstatushistory_grid->EventCancelled))
				$invoicescustomstatushistory_grid->RowAction = strval($CurrentForm->getValue($invoicescustomstatushistory_grid->FormActionName));
			elseif ($invoicescustomstatushistory_grid->isGridAdd())
				$invoicescustomstatushistory_grid->RowAction = "insert";
			else
				$invoicescustomstatushistory_grid->RowAction = "";
		}

		// Set up key count
		$invoicescustomstatushistory_grid->KeyCount = $invoicescustomstatushistory_grid->RowIndex;

		// Init row class and style
		$invoicescustomstatushistory->resetAttributes();
		$invoicescustomstatushistory->CssClass = "";
		if ($invoicescustomstatushistory_grid->isGridAdd()) {
			if ($invoicescustomstatushistory->CurrentMode == "copy") {
				$invoicescustomstatushistory_grid->loadRowValues($invoicescustomstatushistory_grid->Recordset); // Load row values
				$invoicescustomstatushistory_grid->setRecordKey($invoicescustomstatushistory_grid->RowOldKey, $invoicescustomstatushistory_grid->Recordset); // Set old record key
			} else {
				$invoicescustomstatushistory_grid->loadRowValues(); // Load default values
				$invoicescustomstatushistory_grid->RowOldKey = ""; // Clear old key value
			}
		} else {
			$invoicescustomstatushistory_grid->loadRowValues($invoicescustomstatushistory_grid->Recordset); // Load row values
		}
		$invoicescustomstatushistory->RowType = ROWTYPE_VIEW; // Render view
		if ($invoicescustomstatushistory_grid->isGridAdd()) // Grid add
			$invoicescustomstatushistory->RowType = ROWTYPE_ADD; // Render add
		if ($invoicescustomstatushistory_grid->isGridAdd() && $invoicescustomstatushistory->EventCancelled && !$CurrentForm->hasValue("k_blankrow")) // Insert failed
			$invoicescustomstatushistory_grid->restoreCurrentRowFormValues($invoicescustomstatushistory_grid->RowIndex); // Restore form values
		if ($invoicescustomstatushistory_grid->isGridEdit()) { // Grid edit
			if ($invoicescustomstatushistory->EventCancelled)
				$invoicescustomstatushistory_grid->restoreCurrentRowFormValues($invoicescustomstatushistory_grid->RowIndex); // Restore form values
			if ($invoicescustomstatushistory_grid->RowAction == "insert")
				$invoicescustomstatushistory->RowType = ROWTYPE_ADD; // Render add
			else
				$invoicescustomstatushistory->RowType = ROWTYPE_EDIT; // Render edit
		}
		if ($invoicescustomstatushistory_grid->isGridEdit() && ($invoicescustomstatushistory->RowType == ROWTYPE_EDIT || $invoicescustomstatushistory->RowType == ROWTYPE_ADD) && $invoicescustomstatushistory->EventCancelled) // Update failed
			$invoicescustomstatushistory_grid->restoreCurrentRowFormValues($invoicescustomstatushistory_grid->RowIndex); // Restore form values
		if ($invoicescustomstatushistory->RowType == ROWTYPE_EDIT) // Edit row
			$invoicescustomstatushistory_grid->EditRowCount++;
		if ($invoicescustomstatushistory->isConfirm()) // Confirm row
			$invoicescustomstatushistory_grid->restoreCurrentRowFormValues($invoicescustomstatushistory_grid->RowIndex); // Restore form values

		// Set up row id / data-rowindex
		$invoicescustomstatushistory->RowAttrs->merge(["data-rowindex" => $invoicescustomstatushistory_grid->RowCount, "id" => "r" . $invoicescustomstatushistory_grid->RowCount . "_invoicescustomstatushistory", "data-rowtype" => $invoicescustomstatushistory->RowType]);

		// Render row
		$invoicescustomstatushistory_grid->renderRow();

		// Render list options
		$invoicescustomstatushistory_grid->renderListOptions();

		// Skip delete row / empty row for confirm page
		if ($invoicescustomstatushistory_grid->RowAction != "delete" && $invoicescustomstatushistory_grid->RowAction != "insertdelete" && !($invoicescustomstatushistory_grid->RowAction == "insert" && $invoicescustomstatushistory->isConfirm() && $invoicescustomstatushistory_grid->emptyRow())) {
?>
	<tr <?php echo $invoicescustomstatushistory->rowAttributes() ?>>
<?php

// Render list options (body, left)
$invoicescustomstatushistory_grid->ListOptions->render("body", "left", $invoicescustomstatushistory_grid->RowCount);
?>
	<?php if ($invoicescustomstatushistory_grid->changeid->Visible) { // changeid ?>
		<td data-name="changeid" <?php echo $invoicescustomstatushistory_grid->changeid->cellAttributes() ?>>
<?php if ($invoicescustomstatushistory->RowType == ROWTYPE_ADD) { // Add record ?>
<span id="el<?php echo $invoicescustomstatushistory_grid->RowCount ?>_invoicescustomstatushistory_changeid" class="form-group"></span>
<input type="hidden" data-table="invoicescustomstatushistory" data-field="x_changeid" name="o<?php echo $invoicescustomstatushistory_grid->RowIndex ?>_changeid" id="o<?php echo $invoicescustomstatushistory_grid->RowIndex ?>_changeid" value="<?php echo HtmlEncode($invoicescustomstatushistory_grid->changeid->OldValue) ?>">
<?php } ?>
<?php if ($invoicescustomstatushistory->RowType == ROWTYPE_EDIT) { // Edit record ?>
<span id="el<?php echo $invoicescustomstatushistory_grid->RowCount ?>_invoicescustomstatushistory_changeid" class="form-group">
<span<?php echo $invoicescustomstatushistory_grid->changeid->viewAttributes() ?>><input type="text" readonly class="form-control-plaintext" value="<?php echo HtmlEncode(RemoveHtml($invoicescustomstatushistory_grid->changeid->EditValue)) ?>"></span>
</span>
<input type="hidden" data-table="invoicescustomstatushistory" data-field="x_changeid" name="x<?php echo $invoicescustomstatushistory_grid->RowIndex ?>_changeid" id="x<?php echo $invoicescustomstatushistory_grid->RowIndex ?>_changeid" value="<?php echo HtmlEncode($invoicescustomstatushistory_grid->changeid->CurrentValue) ?>">
<?php } ?>
<?php if ($invoicescustomstatushistory->RowType == ROWTYPE_VIEW) { // View record ?>
<span id="el<?php echo $invoicescustomstatushistory_grid->RowCount ?>_invoicescustomstatushistory_changeid">
<span<?php echo $invoicescustomstatushistory_grid->changeid->viewAttributes() ?>><?php echo $invoicescustomstatushistory_grid->changeid->getViewValue() ?></span>
</span>
<?php if (!$invoicescustomstatushistory->isConfirm()) { ?>
<input type="hidden" data-table="invoicescustomstatushistory" data-field="x_changeid" name="x<?php echo $invoicescustomstatushistory_grid->RowIndex ?>_changeid" id="x<?php echo $invoicescustomstatushistory_grid->RowIndex ?>_changeid" value="<?php echo HtmlEncode($invoicescustomstatushistory_grid->changeid->FormValue) ?>">
<input type="hidden" data-table="invoicescustomstatushistory" data-field="x_changeid" name="o<?php echo $invoicescustomstatushistory_grid->RowIndex ?>_changeid" id="o<?php echo $invoicescustomstatushistory_grid->RowIndex ?>_changeid" value="<?php echo HtmlEncode($invoicescustomstatushistory_grid->changeid->OldValue) ?>">
<?php } else { ?>
<input type="hidden" data-table="invoicescustomstatushistory" data-field="x_changeid" name="finvoicescustomstatushistorygrid$x<?php echo $invoicescustomstatushistory_grid->RowIndex ?>_changeid" id="finvoicescustomstatushistorygrid$x<?php echo $invoicescustomstatushistory_grid->RowIndex ?>_changeid" value="<?php echo HtmlEncode($invoicescustomstatushistory_grid->changeid->FormValue) ?>">
<input type="hidden" data-table="invoicescustomstatushistory" data-field="x_changeid" name="finvoicescustomstatushistorygrid$o<?php echo $invoicescustomstatushistory_grid->RowIndex ?>_changeid" id="finvoicescustomstatushistorygrid$o<?php echo $invoicescustomstatushistory_grid->RowIndex ?>_changeid" value="<?php echo HtmlEncode($invoicescustomstatushistory_grid->changeid->OldValue) ?>">
<?php } ?>
<?php } ?>
</td>
	<?php } ?>
	<?php if ($invoicescustomstatushistory_grid->invoiceid->Visible) { // invoiceid ?>
		<td data-name="invoiceid" <?php echo $invoicescustomstatushistory_grid->invoiceid->cellAttributes() ?>>
<?php if ($invoicescustomstatushistory->RowType == ROWTYPE_ADD) { // Add record ?>
<?php if ($invoicescustomstatushistory_grid->invoiceid->getSessionValue() != "") { ?>
<span id="el<?php echo $invoicescustomstatushistory_grid->RowCount ?>_invoicescustomstatushistory_invoiceid" class="form-group">
<span<?php echo $invoicescustomstatushistory_grid->invoiceid->viewAttributes() ?>><input type="text" readonly class="form-control-plaintext" value="<?php echo HtmlEncode(RemoveHtml($invoicescustomstatushistory_grid->invoiceid->ViewValue)) ?>"></span>
</span>
<input type="hidden" id="x<?php echo $invoicescustomstatushistory_grid->RowIndex ?>_invoiceid" name="x<?php echo $invoicescustomstatushistory_grid->RowIndex ?>_invoiceid" value="<?php echo HtmlEncode($invoicescustomstatushistory_grid->invoiceid->CurrentValue) ?>">
<?php } else { ?>
<span id="el<?php echo $invoicescustomstatushistory_grid->RowCount ?>_invoicescustomstatushistory_invoiceid" class="form-group">
<input type="text" data-table="invoicescustomstatushistory" data-field="x_invoiceid" name="x<?php echo $invoicescustomstatushistory_grid->RowIndex ?>_invoiceid" id="x<?php echo $invoicescustomstatushistory_grid->RowIndex ?>_invoiceid" size="30" maxlength="12" placeholder="<?php echo HtmlEncode($invoicescustomstatushistory_grid->invoiceid->getPlaceHolder()) ?>" value="<?php echo $invoicescustomstatushistory_grid->invoiceid->EditValue ?>"<?php echo $invoicescustomstatushistory_grid->invoiceid->editAttributes() ?>>
</span>
<?php } ?>
<input type="hidden" data-table="invoicescustomstatushistory" data-field="x_invoiceid" name="o<?php echo $invoicescustomstatushistory_grid->RowIndex ?>_invoiceid" id="o<?php echo $invoicescustomstatushistory_grid->RowIndex ?>_invoiceid" value="<?php echo HtmlEncode($invoicescustomstatushistory_grid->invoiceid->OldValue) ?>">
<?php } ?>
<?php if ($invoicescustomstatushistory->RowType == ROWTYPE_EDIT) { // Edit record ?>
<?php if ($invoicescustomstatushistory_grid->invoiceid->getSessionValue() != "") { ?>
<span id="el<?php echo $invoicescustomstatushistory_grid->RowCount ?>_invoicescustomstatushistory_invoiceid" class="form-group">
<span<?php echo $invoicescustomstatushistory_grid->invoiceid->viewAttributes() ?>><input type="text" readonly class="form-control-plaintext" value="<?php echo HtmlEncode(RemoveHtml($invoicescustomstatushistory_grid->invoiceid->ViewValue)) ?>"></span>
</span>
<input type="hidden" id="x<?php echo $invoicescustomstatushistory_grid->RowIndex ?>_invoiceid" name="x<?php echo $invoicescustomstatushistory_grid->RowIndex ?>_invoiceid" value="<?php echo HtmlEncode($invoicescustomstatushistory_grid->invoiceid->CurrentValue) ?>">
<?php } else { ?>
<span id="el<?php echo $invoicescustomstatushistory_grid->RowCount ?>_invoicescustomstatushistory_invoiceid" class="form-group">
<input type="text" data-table="invoicescustomstatushistory" data-field="x_invoiceid" name="x<?php echo $invoicescustomstatushistory_grid->RowIndex ?>_invoiceid" id="x<?php echo $invoicescustomstatushistory_grid->RowIndex ?>_invoiceid" size="30" maxlength="12" placeholder="<?php echo HtmlEncode($invoicescustomstatushistory_grid->invoiceid->getPlaceHolder()) ?>" value="<?php echo $invoicescustomstatushistory_grid->invoiceid->EditValue ?>"<?php echo $invoicescustomstatushistory_grid->invoiceid->editAttributes() ?>>
</span>
<?php } ?>
<?php } ?>
<?php if ($invoicescustomstatushistory->RowType == ROWTYPE_VIEW) { // View record ?>
<span id="el<?php echo $invoicescustomstatushistory_grid->RowCount ?>_invoicescustomstatushistory_invoiceid">
<span<?php echo $invoicescustomstatushistory_grid->invoiceid->viewAttributes() ?>><?php echo $invoicescustomstatushistory_grid->invoiceid->getViewValue() ?></span>
</span>
<?php if (!$invoicescustomstatushistory->isConfirm()) { ?>
<input type="hidden" data-table="invoicescustomstatushistory" data-field="x_invoiceid" name="x<?php echo $invoicescustomstatushistory_grid->RowIndex ?>_invoiceid" id="x<?php echo $invoicescustomstatushistory_grid->RowIndex ?>_invoiceid" value="<?php echo HtmlEncode($invoicescustomstatushistory_grid->invoiceid->FormValue) ?>">
<input type="hidden" data-table="invoicescustomstatushistory" data-field="x_invoiceid" name="o<?php echo $invoicescustomstatushistory_grid->RowIndex ?>_invoiceid" id="o<?php echo $invoicescustomstatushistory_grid->RowIndex ?>_invoiceid" value="<?php echo HtmlEncode($invoicescustomstatushistory_grid->invoiceid->OldValue) ?>">
<?php } else { ?>
<input type="hidden" data-table="invoicescustomstatushistory" data-field="x_invoiceid" name="finvoicescustomstatushistorygrid$x<?php echo $invoicescustomstatushistory_grid->RowIndex ?>_invoiceid" id="finvoicescustomstatushistorygrid$x<?php echo $invoicescustomstatushistory_grid->RowIndex ?>_invoiceid" value="<?php echo HtmlEncode($invoicescustomstatushistory_grid->invoiceid->FormValue) ?>">
<input type="hidden" data-table="invoicescustomstatushistory" data-field="x_invoiceid" name="finvoicescustomstatushistorygrid$o<?php echo $invoicescustomstatushistory_grid->RowIndex ?>_invoiceid" id="finvoicescustomstatushistorygrid$o<?php echo $invoicescustomstatushistory_grid->RowIndex ?>_invoiceid" value="<?php echo HtmlEncode($invoicescustomstatushistory_grid->invoiceid->OldValue) ?>">
<?php } ?>
<?php } ?>
</td>
	<?php } ?>
	<?php if ($invoicescustomstatushistory_grid->fromcustomstatus->Visible) { // fromcustomstatus ?>
		<td data-name="fromcustomstatus" <?php echo $invoicescustomstatushistory_grid->fromcustomstatus->cellAttributes() ?>>
<?php if ($invoicescustomstatushistory->RowType == ROWTYPE_ADD) { // Add record ?>
<span id="el<?php echo $invoicescustomstatushistory_grid->RowCount ?>_invoicescustomstatushistory_fromcustomstatus" class="form-group">
<div class="input-group">
	<select class="custom-select ew-custom-select" data-table="invoicescustomstatushistory" data-field="x_fromcustomstatus" data-value-separator="<?php echo $invoicescustomstatushistory_grid->fromcustomstatus->displayValueSeparatorAttribute() ?>" id="x<?php echo $invoicescustomstatushistory_grid->RowIndex ?>_fromcustomstatus" name="x<?php echo $invoicescustomstatushistory_grid->RowIndex ?>_fromcustomstatus"<?php echo $invoicescustomstatushistory_grid->fromcustomstatus->editAttributes() ?>>
			<?php echo $invoicescustomstatushistory_grid->fromcustomstatus->selectOptionListHtml("x{$invoicescustomstatushistory_grid->RowIndex}_fromcustomstatus") ?>
		</select>
</div>
<?php echo $invoicescustomstatushistory_grid->fromcustomstatus->Lookup->getParamTag($invoicescustomstatushistory_grid, "p_x" . $invoicescustomstatushistory_grid->RowIndex . "_fromcustomstatus") ?>
</span>
<input type="hidden" data-table="invoicescustomstatushistory" data-field="x_fromcustomstatus" name="o<?php echo $invoicescustomstatushistory_grid->RowIndex ?>_fromcustomstatus" id="o<?php echo $invoicescustomstatushistory_grid->RowIndex ?>_fromcustomstatus" value="<?php echo HtmlEncode($invoicescustomstatushistory_grid->fromcustomstatus->OldValue) ?>">
<?php } ?>
<?php if ($invoicescustomstatushistory->RowType == ROWTYPE_EDIT) { // Edit record ?>
<span id="el<?php echo $invoicescustomstatushistory_grid->RowCount ?>_invoicescustomstatushistory_fromcustomstatus" class="form-group">
<div class="input-group">
	<select class="custom-select ew-custom-select" data-table="invoicescustomstatushistory" data-field="x_fromcustomstatus" data-value-separator="<?php echo $invoicescustomstatushistory_grid->fromcustomstatus->displayValueSeparatorAttribute() ?>" id="x<?php echo $invoicescustomstatushistory_grid->RowIndex ?>_fromcustomstatus" name="x<?php echo $invoicescustomstatushistory_grid->RowIndex ?>_fromcustomstatus"<?php echo $invoicescustomstatushistory_grid->fromcustomstatus->editAttributes() ?>>
			<?php echo $invoicescustomstatushistory_grid->fromcustomstatus->selectOptionListHtml("x{$invoicescustomstatushistory_grid->RowIndex}_fromcustomstatus") ?>
		</select>
</div>
<?php echo $invoicescustomstatushistory_grid->fromcustomstatus->Lookup->getParamTag($invoicescustomstatushistory_grid, "p_x" . $invoicescustomstatushistory_grid->RowIndex . "_fromcustomstatus") ?>
</span>
<?php } ?>
<?php if ($invoicescustomstatushistory->RowType == ROWTYPE_VIEW) { // View record ?>
<span id="el<?php echo $invoicescustomstatushistory_grid->RowCount ?>_invoicescustomstatushistory_fromcustomstatus">
<span<?php echo $invoicescustomstatushistory_grid->fromcustomstatus->viewAttributes() ?>><?php echo $invoicescustomstatushistory_grid->fromcustomstatus->getViewValue() ?></span>
</span>
<?php if (!$invoicescustomstatushistory->isConfirm()) { ?>
<input type="hidden" data-table="invoicescustomstatushistory" data-field="x_fromcustomstatus" name="x<?php echo $invoicescustomstatushistory_grid->RowIndex ?>_fromcustomstatus" id="x<?php echo $invoicescustomstatushistory_grid->RowIndex ?>_fromcustomstatus" value="<?php echo HtmlEncode($invoicescustomstatushistory_grid->fromcustomstatus->FormValue) ?>">
<input type="hidden" data-table="invoicescustomstatushistory" data-field="x_fromcustomstatus" name="o<?php echo $invoicescustomstatushistory_grid->RowIndex ?>_fromcustomstatus" id="o<?php echo $invoicescustomstatushistory_grid->RowIndex ?>_fromcustomstatus" value="<?php echo HtmlEncode($invoicescustomstatushistory_grid->fromcustomstatus->OldValue) ?>">
<?php } else { ?>
<input type="hidden" data-table="invoicescustomstatushistory" data-field="x_fromcustomstatus" name="finvoicescustomstatushistorygrid$x<?php echo $invoicescustomstatushistory_grid->RowIndex ?>_fromcustomstatus" id="finvoicescustomstatushistorygrid$x<?php echo $invoicescustomstatushistory_grid->RowIndex ?>_fromcustomstatus" value="<?php echo HtmlEncode($invoicescustomstatushistory_grid->fromcustomstatus->FormValue) ?>">
<input type="hidden" data-table="invoicescustomstatushistory" data-field="x_fromcustomstatus" name="finvoicescustomstatushistorygrid$o<?php echo $invoicescustomstatushistory_grid->RowIndex ?>_fromcustomstatus" id="finvoicescustomstatushistorygrid$o<?php echo $invoicescustomstatushistory_grid->RowIndex ?>_fromcustomstatus" value="<?php echo HtmlEncode($invoicescustomstatushistory_grid->fromcustomstatus->OldValue) ?>">
<?php } ?>
<?php } ?>
</td>
	<?php } ?>
	<?php if ($invoicescustomstatushistory_grid->tocustomstatus->Visible) { // tocustomstatus ?>
		<td data-name="tocustomstatus" <?php echo $invoicescustomstatushistory_grid->tocustomstatus->cellAttributes() ?>>
<?php if ($invoicescustomstatushistory->RowType == ROWTYPE_ADD) { // Add record ?>
<span id="el<?php echo $invoicescustomstatushistory_grid->RowCount ?>_invoicescustomstatushistory_tocustomstatus" class="form-group">
<?php
$onchange = $invoicescustomstatushistory_grid->tocustomstatus->EditAttrs->prepend("onchange", "");
$onchange = ($onchange) ? ' onchange="' . JsEncode($onchange) . '"' : '';
$invoicescustomstatushistory_grid->tocustomstatus->EditAttrs["onchange"] = "";
?>
<span id="as_x<?php echo $invoicescustomstatushistory_grid->RowIndex ?>_tocustomstatus">
	<input type="text" class="form-control" name="sv_x<?php echo $invoicescustomstatushistory_grid->RowIndex ?>_tocustomstatus" id="sv_x<?php echo $invoicescustomstatushistory_grid->RowIndex ?>_tocustomstatus" value="<?php echo RemoveHtml($invoicescustomstatushistory_grid->tocustomstatus->EditValue) ?>" size="30" maxlength="2" placeholder="<?php echo HtmlEncode($invoicescustomstatushistory_grid->tocustomstatus->getPlaceHolder()) ?>" data-placeholder="<?php echo HtmlEncode($invoicescustomstatushistory_grid->tocustomstatus->getPlaceHolder()) ?>"<?php echo $invoicescustomstatushistory_grid->tocustomstatus->editAttributes() ?>>
</span>
<input type="hidden" data-table="invoicescustomstatushistory" data-field="x_tocustomstatus" data-value-separator="<?php echo $invoicescustomstatushistory_grid->tocustomstatus->displayValueSeparatorAttribute() ?>" name="x<?php echo $invoicescustomstatushistory_grid->RowIndex ?>_tocustomstatus" id="x<?php echo $invoicescustomstatushistory_grid->RowIndex ?>_tocustomstatus" value="<?php echo HtmlEncode($invoicescustomstatushistory_grid->tocustomstatus->CurrentValue) ?>"<?php echo $onchange ?>>
<script>
loadjs.ready(["finvoicescustomstatushistorygrid"], function() {
	finvoicescustomstatushistorygrid.createAutoSuggest({"id":"x<?php echo $invoicescustomstatushistory_grid->RowIndex ?>_tocustomstatus","forceSelect":false});
});
</script>
<?php echo $invoicescustomstatushistory_grid->tocustomstatus->Lookup->getParamTag($invoicescustomstatushistory_grid, "p_x" . $invoicescustomstatushistory_grid->RowIndex . "_tocustomstatus") ?>
</span>
<input type="hidden" data-table="invoicescustomstatushistory" data-field="x_tocustomstatus" name="o<?php echo $invoicescustomstatushistory_grid->RowIndex ?>_tocustomstatus" id="o<?php echo $invoicescustomstatushistory_grid->RowIndex ?>_tocustomstatus" value="<?php echo HtmlEncode($invoicescustomstatushistory_grid->tocustomstatus->OldValue) ?>">
<?php } ?>
<?php if ($invoicescustomstatushistory->RowType == ROWTYPE_EDIT) { // Edit record ?>
<span id="el<?php echo $invoicescustomstatushistory_grid->RowCount ?>_invoicescustomstatushistory_tocustomstatus" class="form-group">
<?php
$onchange = $invoicescustomstatushistory_grid->tocustomstatus->EditAttrs->prepend("onchange", "");
$onchange = ($onchange) ? ' onchange="' . JsEncode($onchange) . '"' : '';
$invoicescustomstatushistory_grid->tocustomstatus->EditAttrs["onchange"] = "";
?>
<span id="as_x<?php echo $invoicescustomstatushistory_grid->RowIndex ?>_tocustomstatus">
	<input type="text" class="form-control" name="sv_x<?php echo $invoicescustomstatushistory_grid->RowIndex ?>_tocustomstatus" id="sv_x<?php echo $invoicescustomstatushistory_grid->RowIndex ?>_tocustomstatus" value="<?php echo RemoveHtml($invoicescustomstatushistory_grid->tocustomstatus->EditValue) ?>" size="30" maxlength="2" placeholder="<?php echo HtmlEncode($invoicescustomstatushistory_grid->tocustomstatus->getPlaceHolder()) ?>" data-placeholder="<?php echo HtmlEncode($invoicescustomstatushistory_grid->tocustomstatus->getPlaceHolder()) ?>"<?php echo $invoicescustomstatushistory_grid->tocustomstatus->editAttributes() ?>>
</span>
<input type="hidden" data-table="invoicescustomstatushistory" data-field="x_tocustomstatus" data-value-separator="<?php echo $invoicescustomstatushistory_grid->tocustomstatus->displayValueSeparatorAttribute() ?>" name="x<?php echo $invoicescustomstatushistory_grid->RowIndex ?>_tocustomstatus" id="x<?php echo $invoicescustomstatushistory_grid->RowIndex ?>_tocustomstatus" value="<?php echo HtmlEncode($invoicescustomstatushistory_grid->tocustomstatus->CurrentValue) ?>"<?php echo $onchange ?>>
<script>
loadjs.ready(["finvoicescustomstatushistorygrid"], function() {
	finvoicescustomstatushistorygrid.createAutoSuggest({"id":"x<?php echo $invoicescustomstatushistory_grid->RowIndex ?>_tocustomstatus","forceSelect":false});
});
</script>
<?php echo $invoicescustomstatushistory_grid->tocustomstatus->Lookup->getParamTag($invoicescustomstatushistory_grid, "p_x" . $invoicescustomstatushistory_grid->RowIndex . "_tocustomstatus") ?>
</span>
<?php } ?>
<?php if ($invoicescustomstatushistory->RowType == ROWTYPE_VIEW) { // View record ?>
<span id="el<?php echo $invoicescustomstatushistory_grid->RowCount ?>_invoicescustomstatushistory_tocustomstatus">
<span<?php echo $invoicescustomstatushistory_grid->tocustomstatus->viewAttributes() ?>><?php echo $invoicescustomstatushistory_grid->tocustomstatus->getViewValue() ?></span>
</span>
<?php if (!$invoicescustomstatushistory->isConfirm()) { ?>
<input type="hidden" data-table="invoicescustomstatushistory" data-field="x_tocustomstatus" name="x<?php echo $invoicescustomstatushistory_grid->RowIndex ?>_tocustomstatus" id="x<?php echo $invoicescustomstatushistory_grid->RowIndex ?>_tocustomstatus" value="<?php echo HtmlEncode($invoicescustomstatushistory_grid->tocustomstatus->FormValue) ?>">
<input type="hidden" data-table="invoicescustomstatushistory" data-field="x_tocustomstatus" name="o<?php echo $invoicescustomstatushistory_grid->RowIndex ?>_tocustomstatus" id="o<?php echo $invoicescustomstatushistory_grid->RowIndex ?>_tocustomstatus" value="<?php echo HtmlEncode($invoicescustomstatushistory_grid->tocustomstatus->OldValue) ?>">
<?php } else { ?>
<input type="hidden" data-table="invoicescustomstatushistory" data-field="x_tocustomstatus" name="finvoicescustomstatushistorygrid$x<?php echo $invoicescustomstatushistory_grid->RowIndex ?>_tocustomstatus" id="finvoicescustomstatushistorygrid$x<?php echo $invoicescustomstatushistory_grid->RowIndex ?>_tocustomstatus" value="<?php echo HtmlEncode($invoicescustomstatushistory_grid->tocustomstatus->FormValue) ?>">
<input type="hidden" data-table="invoicescustomstatushistory" data-field="x_tocustomstatus" name="finvoicescustomstatushistorygrid$o<?php echo $invoicescustomstatushistory_grid->RowIndex ?>_tocustomstatus" id="finvoicescustomstatushistorygrid$o<?php echo $invoicescustomstatushistory_grid->RowIndex ?>_tocustomstatus" value="<?php echo HtmlEncode($invoicescustomstatushistory_grid->tocustomstatus->OldValue) ?>">
<?php } ?>
<?php } ?>
</td>
	<?php } ?>
	<?php if ($invoicescustomstatushistory_grid->changetime->Visible) { // changetime ?>
		<td data-name="changetime" <?php echo $invoicescustomstatushistory_grid->changetime->cellAttributes() ?>>
<?php if ($invoicescustomstatushistory->RowType == ROWTYPE_ADD) { // Add record ?>
<span id="el<?php echo $invoicescustomstatushistory_grid->RowCount ?>_invoicescustomstatushistory_changetime" class="form-group">
<input type="text" data-table="invoicescustomstatushistory" data-field="x_changetime" name="x<?php echo $invoicescustomstatushistory_grid->RowIndex ?>_changetime" id="x<?php echo $invoicescustomstatushistory_grid->RowIndex ?>_changetime" maxlength="19" placeholder="<?php echo HtmlEncode($invoicescustomstatushistory_grid->changetime->getPlaceHolder()) ?>" value="<?php echo $invoicescustomstatushistory_grid->changetime->EditValue ?>"<?php echo $invoicescustomstatushistory_grid->changetime->editAttributes() ?>>
<?php if (!$invoicescustomstatushistory_grid->changetime->ReadOnly && !$invoicescustomstatushistory_grid->changetime->Disabled && !isset($invoicescustomstatushistory_grid->changetime->EditAttrs["readonly"]) && !isset($invoicescustomstatushistory_grid->changetime->EditAttrs["disabled"])) { ?>
<script>
loadjs.ready(["finvoicescustomstatushistorygrid", "datetimepicker"], function() {
	ew.createDateTimePicker("finvoicescustomstatushistorygrid", "x<?php echo $invoicescustomstatushistory_grid->RowIndex ?>_changetime", {"ignoreReadonly":true,"useCurrent":false,"format":0});
});
</script>
<?php } ?>
</span>
<input type="hidden" data-table="invoicescustomstatushistory" data-field="x_changetime" name="o<?php echo $invoicescustomstatushistory_grid->RowIndex ?>_changetime" id="o<?php echo $invoicescustomstatushistory_grid->RowIndex ?>_changetime" value="<?php echo HtmlEncode($invoicescustomstatushistory_grid->changetime->OldValue) ?>">
<?php } ?>
<?php if ($invoicescustomstatushistory->RowType == ROWTYPE_EDIT) { // Edit record ?>
<span id="el<?php echo $invoicescustomstatushistory_grid->RowCount ?>_invoicescustomstatushistory_changetime" class="form-group">
<input type="text" data-table="invoicescustomstatushistory" data-field="x_changetime" name="x<?php echo $invoicescustomstatushistory_grid->RowIndex ?>_changetime" id="x<?php echo $invoicescustomstatushistory_grid->RowIndex ?>_changetime" maxlength="19" placeholder="<?php echo HtmlEncode($invoicescustomstatushistory_grid->changetime->getPlaceHolder()) ?>" value="<?php echo $invoicescustomstatushistory_grid->changetime->EditValue ?>"<?php echo $invoicescustomstatushistory_grid->changetime->editAttributes() ?>>
<?php if (!$invoicescustomstatushistory_grid->changetime->ReadOnly && !$invoicescustomstatushistory_grid->changetime->Disabled && !isset($invoicescustomstatushistory_grid->changetime->EditAttrs["readonly"]) && !isset($invoicescustomstatushistory_grid->changetime->EditAttrs["disabled"])) { ?>
<script>
loadjs.ready(["finvoicescustomstatushistorygrid", "datetimepicker"], function() {
	ew.createDateTimePicker("finvoicescustomstatushistorygrid", "x<?php echo $invoicescustomstatushistory_grid->RowIndex ?>_changetime", {"ignoreReadonly":true,"useCurrent":false,"format":0});
});
</script>
<?php } ?>
</span>
<?php } ?>
<?php if ($invoicescustomstatushistory->RowType == ROWTYPE_VIEW) { // View record ?>
<span id="el<?php echo $invoicescustomstatushistory_grid->RowCount ?>_invoicescustomstatushistory_changetime">
<span<?php echo $invoicescustomstatushistory_grid->changetime->viewAttributes() ?>><?php echo $invoicescustomstatushistory_grid->changetime->getViewValue() ?></span>
</span>
<?php if (!$invoicescustomstatushistory->isConfirm()) { ?>
<input type="hidden" data-table="invoicescustomstatushistory" data-field="x_changetime" name="x<?php echo $invoicescustomstatushistory_grid->RowIndex ?>_changetime" id="x<?php echo $invoicescustomstatushistory_grid->RowIndex ?>_changetime" value="<?php echo HtmlEncode($invoicescustomstatushistory_grid->changetime->FormValue) ?>">
<input type="hidden" data-table="invoicescustomstatushistory" data-field="x_changetime" name="o<?php echo $invoicescustomstatushistory_grid->RowIndex ?>_changetime" id="o<?php echo $invoicescustomstatushistory_grid->RowIndex ?>_changetime" value="<?php echo HtmlEncode($invoicescustomstatushistory_grid->changetime->OldValue) ?>">
<?php } else { ?>
<input type="hidden" data-table="invoicescustomstatushistory" data-field="x_changetime" name="finvoicescustomstatushistorygrid$x<?php echo $invoicescustomstatushistory_grid->RowIndex ?>_changetime" id="finvoicescustomstatushistorygrid$x<?php echo $invoicescustomstatushistory_grid->RowIndex ?>_changetime" value="<?php echo HtmlEncode($invoicescustomstatushistory_grid->changetime->FormValue) ?>">
<input type="hidden" data-table="invoicescustomstatushistory" data-field="x_changetime" name="finvoicescustomstatushistorygrid$o<?php echo $invoicescustomstatushistory_grid->RowIndex ?>_changetime" id="finvoicescustomstatushistorygrid$o<?php echo $invoicescustomstatushistory_grid->RowIndex ?>_changetime" value="<?php echo HtmlEncode($invoicescustomstatushistory_grid->changetime->OldValue) ?>">
<?php } ?>
<?php } ?>
</td>
	<?php } ?>
<?php

// Render list options (body, right)
$invoicescustomstatushistory_grid->ListOptions->render("body", "right", $invoicescustomstatushistory_grid->RowCount);
?>
	</tr>
<?php if ($invoicescustomstatushistory->RowType == ROWTYPE_ADD || $invoicescustomstatushistory->RowType == ROWTYPE_EDIT) { ?>
<script>
loadjs.ready(["finvoicescustomstatushistorygrid", "load"], function() {
	finvoicescustomstatushistorygrid.updateLists(<?php echo $invoicescustomstatushistory_grid->RowIndex ?>);
});
</script>
<?php } ?>
<?php
	}
	} // End delete row checking
	if (!$invoicescustomstatushistory_grid->isGridAdd() || $invoicescustomstatushistory->CurrentMode == "copy")
		if (!$invoicescustomstatushistory_grid->Recordset->EOF)
			$invoicescustomstatushistory_grid->Recordset->moveNext();
}
?>
<?php
	if ($invoicescustomstatushistory->CurrentMode == "add" || $invoicescustomstatushistory->CurrentMode == "copy" || $invoicescustomstatushistory->CurrentMode == "edit") {
		$invoicescustomstatushistory_grid->RowIndex = '$rowindex$';
		$invoicescustomstatushistory_grid->loadRowValues();

		// Set row properties
		$invoicescustomstatushistory->resetAttributes();
		$invoicescustomstatushistory->RowAttrs->merge(["data-rowindex" => $invoicescustomstatushistory_grid->RowIndex, "id" => "r0_invoicescustomstatushistory", "data-rowtype" => ROWTYPE_ADD]);
		$invoicescustomstatushistory->RowAttrs->appendClass("ew-template");
		$invoicescustomstatushistory->RowType = ROWTYPE_ADD;

		// Render row
		$invoicescustomstatushistory_grid->renderRow();

		// Render list options
		$invoicescustomstatushistory_grid->renderListOptions();
		$invoicescustomstatushistory_grid->StartRowCount = 0;
?>
	<tr <?php echo $invoicescustomstatushistory->rowAttributes() ?>>
<?php

// Render list options (body, left)
$invoicescustomstatushistory_grid->ListOptions->render("body", "left", $invoicescustomstatushistory_grid->RowIndex);
?>
	<?php if ($invoicescustomstatushistory_grid->changeid->Visible) { // changeid ?>
		<td data-name="changeid">
<?php if (!$invoicescustomstatushistory->isConfirm()) { ?>
<span id="el$rowindex$_invoicescustomstatushistory_changeid" class="form-group invoicescustomstatushistory_changeid"></span>
<?php } else { ?>
<span id="el$rowindex$_invoicescustomstatushistory_changeid" class="form-group invoicescustomstatushistory_changeid">
<span<?php echo $invoicescustomstatushistory_grid->changeid->viewAttributes() ?>><input type="text" readonly class="form-control-plaintext" value="<?php echo HtmlEncode(RemoveHtml($invoicescustomstatushistory_grid->changeid->ViewValue)) ?>"></span>
</span>
<input type="hidden" data-table="invoicescustomstatushistory" data-field="x_changeid" name="x<?php echo $invoicescustomstatushistory_grid->RowIndex ?>_changeid" id="x<?php echo $invoicescustomstatushistory_grid->RowIndex ?>_changeid" value="<?php echo HtmlEncode($invoicescustomstatushistory_grid->changeid->FormValue) ?>">
<?php } ?>
<input type="hidden" data-table="invoicescustomstatushistory" data-field="x_changeid" name="o<?php echo $invoicescustomstatushistory_grid->RowIndex ?>_changeid" id="o<?php echo $invoicescustomstatushistory_grid->RowIndex ?>_changeid" value="<?php echo HtmlEncode($invoicescustomstatushistory_grid->changeid->OldValue) ?>">
</td>
	<?php } ?>
	<?php if ($invoicescustomstatushistory_grid->invoiceid->Visible) { // invoiceid ?>
		<td data-name="invoiceid">
<?php if (!$invoicescustomstatushistory->isConfirm()) { ?>
<?php if ($invoicescustomstatushistory_grid->invoiceid->getSessionValue() != "") { ?>
<span id="el$rowindex$_invoicescustomstatushistory_invoiceid" class="form-group invoicescustomstatushistory_invoiceid">
<span<?php echo $invoicescustomstatushistory_grid->invoiceid->viewAttributes() ?>><input type="text" readonly class="form-control-plaintext" value="<?php echo HtmlEncode(RemoveHtml($invoicescustomstatushistory_grid->invoiceid->ViewValue)) ?>"></span>
</span>
<input type="hidden" id="x<?php echo $invoicescustomstatushistory_grid->RowIndex ?>_invoiceid" name="x<?php echo $invoicescustomstatushistory_grid->RowIndex ?>_invoiceid" value="<?php echo HtmlEncode($invoicescustomstatushistory_grid->invoiceid->CurrentValue) ?>">
<?php } else { ?>
<span id="el$rowindex$_invoicescustomstatushistory_invoiceid" class="form-group invoicescustomstatushistory_invoiceid">
<input type="text" data-table="invoicescustomstatushistory" data-field="x_invoiceid" name="x<?php echo $invoicescustomstatushistory_grid->RowIndex ?>_invoiceid" id="x<?php echo $invoicescustomstatushistory_grid->RowIndex ?>_invoiceid" size="30" maxlength="12" placeholder="<?php echo HtmlEncode($invoicescustomstatushistory_grid->invoiceid->getPlaceHolder()) ?>" value="<?php echo $invoicescustomstatushistory_grid->invoiceid->EditValue ?>"<?php echo $invoicescustomstatushistory_grid->invoiceid->editAttributes() ?>>
</span>
<?php } ?>
<?php } else { ?>
<span id="el$rowindex$_invoicescustomstatushistory_invoiceid" class="form-group invoicescustomstatushistory_invoiceid">
<span<?php echo $invoicescustomstatushistory_grid->invoiceid->viewAttributes() ?>><input type="text" readonly class="form-control-plaintext" value="<?php echo HtmlEncode(RemoveHtml($invoicescustomstatushistory_grid->invoiceid->ViewValue)) ?>"></span>
</span>
<input type="hidden" data-table="invoicescustomstatushistory" data-field="x_invoiceid" name="x<?php echo $invoicescustomstatushistory_grid->RowIndex ?>_invoiceid" id="x<?php echo $invoicescustomstatushistory_grid->RowIndex ?>_invoiceid" value="<?php echo HtmlEncode($invoicescustomstatushistory_grid->invoiceid->FormValue) ?>">
<?php } ?>
<input type="hidden" data-table="invoicescustomstatushistory" data-field="x_invoiceid" name="o<?php echo $invoicescustomstatushistory_grid->RowIndex ?>_invoiceid" id="o<?php echo $invoicescustomstatushistory_grid->RowIndex ?>_invoiceid" value="<?php echo HtmlEncode($invoicescustomstatushistory_grid->invoiceid->OldValue) ?>">
</td>
	<?php } ?>
	<?php if ($invoicescustomstatushistory_grid->fromcustomstatus->Visible) { // fromcustomstatus ?>
		<td data-name="fromcustomstatus">
<?php if (!$invoicescustomstatushistory->isConfirm()) { ?>
<span id="el$rowindex$_invoicescustomstatushistory_fromcustomstatus" class="form-group invoicescustomstatushistory_fromcustomstatus">
<div class="input-group">
	<select class="custom-select ew-custom-select" data-table="invoicescustomstatushistory" data-field="x_fromcustomstatus" data-value-separator="<?php echo $invoicescustomstatushistory_grid->fromcustomstatus->displayValueSeparatorAttribute() ?>" id="x<?php echo $invoicescustomstatushistory_grid->RowIndex ?>_fromcustomstatus" name="x<?php echo $invoicescustomstatushistory_grid->RowIndex ?>_fromcustomstatus"<?php echo $invoicescustomstatushistory_grid->fromcustomstatus->editAttributes() ?>>
			<?php echo $invoicescustomstatushistory_grid->fromcustomstatus->selectOptionListHtml("x{$invoicescustomstatushistory_grid->RowIndex}_fromcustomstatus") ?>
		</select>
</div>
<?php echo $invoicescustomstatushistory_grid->fromcustomstatus->Lookup->getParamTag($invoicescustomstatushistory_grid, "p_x" . $invoicescustomstatushistory_grid->RowIndex . "_fromcustomstatus") ?>
</span>
<?php } else { ?>
<span id="el$rowindex$_invoicescustomstatushistory_fromcustomstatus" class="form-group invoicescustomstatushistory_fromcustomstatus">
<span<?php echo $invoicescustomstatushistory_grid->fromcustomstatus->viewAttributes() ?>><input type="text" readonly class="form-control-plaintext" value="<?php echo HtmlEncode(RemoveHtml($invoicescustomstatushistory_grid->fromcustomstatus->ViewValue)) ?>"></span>
</span>
<input type="hidden" data-table="invoicescustomstatushistory" data-field="x_fromcustomstatus" name="x<?php echo $invoicescustomstatushistory_grid->RowIndex ?>_fromcustomstatus" id="x<?php echo $invoicescustomstatushistory_grid->RowIndex ?>_fromcustomstatus" value="<?php echo HtmlEncode($invoicescustomstatushistory_grid->fromcustomstatus->FormValue) ?>">
<?php } ?>
<input type="hidden" data-table="invoicescustomstatushistory" data-field="x_fromcustomstatus" name="o<?php echo $invoicescustomstatushistory_grid->RowIndex ?>_fromcustomstatus" id="o<?php echo $invoicescustomstatushistory_grid->RowIndex ?>_fromcustomstatus" value="<?php echo HtmlEncode($invoicescustomstatushistory_grid->fromcustomstatus->OldValue) ?>">
</td>
	<?php } ?>
	<?php if ($invoicescustomstatushistory_grid->tocustomstatus->Visible) { // tocustomstatus ?>
		<td data-name="tocustomstatus">
<?php if (!$invoicescustomstatushistory->isConfirm()) { ?>
<span id="el$rowindex$_invoicescustomstatushistory_tocustomstatus" class="form-group invoicescustomstatushistory_tocustomstatus">
<?php
$onchange = $invoicescustomstatushistory_grid->tocustomstatus->EditAttrs->prepend("onchange", "");
$onchange = ($onchange) ? ' onchange="' . JsEncode($onchange) . '"' : '';
$invoicescustomstatushistory_grid->tocustomstatus->EditAttrs["onchange"] = "";
?>
<span id="as_x<?php echo $invoicescustomstatushistory_grid->RowIndex ?>_tocustomstatus">
	<input type="text" class="form-control" name="sv_x<?php echo $invoicescustomstatushistory_grid->RowIndex ?>_tocustomstatus" id="sv_x<?php echo $invoicescustomstatushistory_grid->RowIndex ?>_tocustomstatus" value="<?php echo RemoveHtml($invoicescustomstatushistory_grid->tocustomstatus->EditValue) ?>" size="30" maxlength="2" placeholder="<?php echo HtmlEncode($invoicescustomstatushistory_grid->tocustomstatus->getPlaceHolder()) ?>" data-placeholder="<?php echo HtmlEncode($invoicescustomstatushistory_grid->tocustomstatus->getPlaceHolder()) ?>"<?php echo $invoicescustomstatushistory_grid->tocustomstatus->editAttributes() ?>>
</span>
<input type="hidden" data-table="invoicescustomstatushistory" data-field="x_tocustomstatus" data-value-separator="<?php echo $invoicescustomstatushistory_grid->tocustomstatus->displayValueSeparatorAttribute() ?>" name="x<?php echo $invoicescustomstatushistory_grid->RowIndex ?>_tocustomstatus" id="x<?php echo $invoicescustomstatushistory_grid->RowIndex ?>_tocustomstatus" value="<?php echo HtmlEncode($invoicescustomstatushistory_grid->tocustomstatus->CurrentValue) ?>"<?php echo $onchange ?>>
<script>
loadjs.ready(["finvoicescustomstatushistorygrid"], function() {
	finvoicescustomstatushistorygrid.createAutoSuggest({"id":"x<?php echo $invoicescustomstatushistory_grid->RowIndex ?>_tocustomstatus","forceSelect":false});
});
</script>
<?php echo $invoicescustomstatushistory_grid->tocustomstatus->Lookup->getParamTag($invoicescustomstatushistory_grid, "p_x" . $invoicescustomstatushistory_grid->RowIndex . "_tocustomstatus") ?>
</span>
<?php } else { ?>
<span id="el$rowindex$_invoicescustomstatushistory_tocustomstatus" class="form-group invoicescustomstatushistory_tocustomstatus">
<span<?php echo $invoicescustomstatushistory_grid->tocustomstatus->viewAttributes() ?>><input type="text" readonly class="form-control-plaintext" value="<?php echo HtmlEncode(RemoveHtml($invoicescustomstatushistory_grid->tocustomstatus->ViewValue)) ?>"></span>
</span>
<input type="hidden" data-table="invoicescustomstatushistory" data-field="x_tocustomstatus" name="x<?php echo $invoicescustomstatushistory_grid->RowIndex ?>_tocustomstatus" id="x<?php echo $invoicescustomstatushistory_grid->RowIndex ?>_tocustomstatus" value="<?php echo HtmlEncode($invoicescustomstatushistory_grid->tocustomstatus->FormValue) ?>">
<?php } ?>
<input type="hidden" data-table="invoicescustomstatushistory" data-field="x_tocustomstatus" name="o<?php echo $invoicescustomstatushistory_grid->RowIndex ?>_tocustomstatus" id="o<?php echo $invoicescustomstatushistory_grid->RowIndex ?>_tocustomstatus" value="<?php echo HtmlEncode($invoicescustomstatushistory_grid->tocustomstatus->OldValue) ?>">
</td>
	<?php } ?>
	<?php if ($invoicescustomstatushistory_grid->changetime->Visible) { // changetime ?>
		<td data-name="changetime">
<?php if (!$invoicescustomstatushistory->isConfirm()) { ?>
<span id="el$rowindex$_invoicescustomstatushistory_changetime" class="form-group invoicescustomstatushistory_changetime">
<input type="text" data-table="invoicescustomstatushistory" data-field="x_changetime" name="x<?php echo $invoicescustomstatushistory_grid->RowIndex ?>_changetime" id="x<?php echo $invoicescustomstatushistory_grid->RowIndex ?>_changetime" maxlength="19" placeholder="<?php echo HtmlEncode($invoicescustomstatushistory_grid->changetime->getPlaceHolder()) ?>" value="<?php echo $invoicescustomstatushistory_grid->changetime->EditValue ?>"<?php echo $invoicescustomstatushistory_grid->changetime->editAttributes() ?>>
<?php if (!$invoicescustomstatushistory_grid->changetime->ReadOnly && !$invoicescustomstatushistory_grid->changetime->Disabled && !isset($invoicescustomstatushistory_grid->changetime->EditAttrs["readonly"]) && !isset($invoicescustomstatushistory_grid->changetime->EditAttrs["disabled"])) { ?>
<script>
loadjs.ready(["finvoicescustomstatushistorygrid", "datetimepicker"], function() {
	ew.createDateTimePicker("finvoicescustomstatushistorygrid", "x<?php echo $invoicescustomstatushistory_grid->RowIndex ?>_changetime", {"ignoreReadonly":true,"useCurrent":false,"format":0});
});
</script>
<?php } ?>
</span>
<?php } else { ?>
<span id="el$rowindex$_invoicescustomstatushistory_changetime" class="form-group invoicescustomstatushistory_changetime">
<span<?php echo $invoicescustomstatushistory_grid->changetime->viewAttributes() ?>><input type="text" readonly class="form-control-plaintext" value="<?php echo HtmlEncode(RemoveHtml($invoicescustomstatushistory_grid->changetime->ViewValue)) ?>"></span>
</span>
<input type="hidden" data-table="invoicescustomstatushistory" data-field="x_changetime" name="x<?php echo $invoicescustomstatushistory_grid->RowIndex ?>_changetime" id="x<?php echo $invoicescustomstatushistory_grid->RowIndex ?>_changetime" value="<?php echo HtmlEncode($invoicescustomstatushistory_grid->changetime->FormValue) ?>">
<?php } ?>
<input type="hidden" data-table="invoicescustomstatushistory" data-field="x_changetime" name="o<?php echo $invoicescustomstatushistory_grid->RowIndex ?>_changetime" id="o<?php echo $invoicescustomstatushistory_grid->RowIndex ?>_changetime" value="<?php echo HtmlEncode($invoicescustomstatushistory_grid->changetime->OldValue) ?>">
</td>
	<?php } ?>
<?php

// Render list options (body, right)
$invoicescustomstatushistory_grid->ListOptions->render("body", "right", $invoicescustomstatushistory_grid->RowIndex);
?>
<script>
loadjs.ready(["finvoicescustomstatushistorygrid", "load"], function() {
	finvoicescustomstatushistorygrid.updateLists(<?php echo $invoicescustomstatushistory_grid->RowIndex ?>);
});
</script>
	</tr>
<?php
	}
?>
</tbody>
</table><!-- /.ew-table -->
</div><!-- /.ew-grid-middle-panel -->
<?php if ($invoicescustomstatushistory->CurrentMode == "add" || $invoicescustomstatushistory->CurrentMode == "copy") { ?>
<input type="hidden" name="<?php echo $invoicescustomstatushistory_grid->FormKeyCountName ?>" id="<?php echo $invoicescustomstatushistory_grid->FormKeyCountName ?>" value="<?php echo $invoicescustomstatushistory_grid->KeyCount ?>">
<?php echo $invoicescustomstatushistory_grid->MultiSelectKey ?>
<?php } ?>
<?php if ($invoicescustomstatushistory->CurrentMode == "edit") { ?>
<input type="hidden" name="<?php echo $invoicescustomstatushistory_grid->FormKeyCountName ?>" id="<?php echo $invoicescustomstatushistory_grid->FormKeyCountName ?>" value="<?php echo $invoicescustomstatushistory_grid->KeyCount ?>">
<?php echo $invoicescustomstatushistory_grid->MultiSelectKey ?>
<?php } ?>
<?php if ($invoicescustomstatushistory->CurrentMode == "") { ?>
<input type="hidden" name="action" id="action" value="">
<?php } ?>
<input type="hidden" name="detailpage" value="finvoicescustomstatushistorygrid">
</div><!-- /.ew-list-form -->
<?php

// Close recordset
if ($invoicescustomstatushistory_grid->Recordset)
	$invoicescustomstatushistory_grid->Recordset->Close();
?>
<?php if ($invoicescustomstatushistory_grid->ShowOtherOptions) { ?>
<div class="card-footer ew-grid-lower-panel">
<?php $invoicescustomstatushistory_grid->OtherOptions->render("body", "bottom") ?>
</div>
<div class="clearfix"></div>
<?php } ?>
</div><!-- /.ew-grid -->
<?php } ?>
<?php if ($invoicescustomstatushistory_grid->TotalRecords == 0 && !$invoicescustomstatushistory->CurrentAction) { // Show other options ?>
<div class="ew-list-other-options">
<?php $invoicescustomstatushistory_grid->OtherOptions->render("body") ?>
</div>
<div class="clearfix"></div>
<?php } ?>
<?php if (!$invoicescustomstatushistory_grid->isExport()) { ?>
<script>
loadjs.ready("load", function() {

	// Startup script
	// Write your table-specific startup script here
	// console.log("page loaded");

});
</script>
<?php } ?>
<?php
$invoicescustomstatushistory_grid->terminate();
?>