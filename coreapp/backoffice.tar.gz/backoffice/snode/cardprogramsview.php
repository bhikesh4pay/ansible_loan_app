<?php
namespace PHPMaker2020\_4payadmin;

// Autoload
include_once "autoload.php";

// Session
if (session_status() !== PHP_SESSION_ACTIVE)
	\Delight\Cookie\Session::start(Config("COOKIE_SAMESITE")); // Init session data

// Output buffering
ob_start();
?>
<?php

// Write header
WriteHeader(FALSE);

// Create page object
$cardprograms_view = new cardprograms_view();

// Run the page
$cardprograms_view->run();

// Setup login status
SetupLoginStatus();
SetClientVar("login", LoginStatus());

// Global Page Rendering event (in userfn*.php)
Page_Rendering();

// Page Rendering event
$cardprograms_view->Page_Render();
?>
<?php include_once "header.php"; ?>
<?php if (!$cardprograms_view->isExport()) { ?>
<script>
var fcardprogramsview, currentPageID;
loadjs.ready("head", function() {

	// Form object
	currentPageID = ew.PAGE_ID = "view";
	fcardprogramsview = currentForm = new ew.Form("fcardprogramsview", "view");
	loadjs.done("fcardprogramsview");
});
</script>
<script>
loadjs.ready("head", function() {

	// Client script
	// Write your client script here, no need to add script tags.

});
</script>
<?php } ?>
<?php if (!$cardprograms_view->isExport()) { ?>
<div class="btn-toolbar ew-toolbar">
<?php $cardprograms_view->ExportOptions->render("body") ?>
<?php $cardprograms_view->OtherOptions->render("body") ?>
<div class="clearfix"></div>
</div>
<?php } ?>
<?php $cardprograms_view->showPageHeader(); ?>
<?php
$cardprograms_view->showMessage();
?>
<form name="fcardprogramsview" id="fcardprogramsview" class="form-inline ew-form ew-view-form" action="<?php echo CurrentPageName() ?>" method="post">
<?php if ($Page->CheckToken) { ?>
<input type="hidden" name="<?php echo Config("TOKEN_NAME") ?>" value="<?php echo $Page->Token ?>">
<?php } ?>
<input type="hidden" name="t" value="cardprograms">
<input type="hidden" name="modal" value="<?php echo (int)$cardprograms_view->IsModal ?>">
<table class="table table-striped table-sm ew-view-table">
<?php if ($cardprograms_view->programid->Visible) { // programid ?>
	<tr id="r_programid">
		<td class="<?php echo $cardprograms_view->TableLeftColumnClass ?>"><span id="elh_cardprograms_programid"><?php echo $cardprograms_view->programid->caption() ?></span></td>
		<td data-name="programid" <?php echo $cardprograms_view->programid->cellAttributes() ?>>
<span id="el_cardprograms_programid">
<span<?php echo $cardprograms_view->programid->viewAttributes() ?>><?php echo $cardprograms_view->programid->getViewValue() ?></span>
</span>
</td>
	</tr>
<?php } ?>
<?php if ($cardprograms_view->programname->Visible) { // programname ?>
	<tr id="r_programname">
		<td class="<?php echo $cardprograms_view->TableLeftColumnClass ?>"><span id="elh_cardprograms_programname"><?php echo $cardprograms_view->programname->caption() ?></span></td>
		<td data-name="programname" <?php echo $cardprograms_view->programname->cellAttributes() ?>>
<span id="el_cardprograms_programname">
<span<?php echo $cardprograms_view->programname->viewAttributes() ?>><?php echo $cardprograms_view->programname->getViewValue() ?></span>
</span>
</td>
	</tr>
<?php } ?>
<?php if ($cardprograms_view->merchantid->Visible) { // merchantid ?>
	<tr id="r_merchantid">
		<td class="<?php echo $cardprograms_view->TableLeftColumnClass ?>"><span id="elh_cardprograms_merchantid"><?php echo $cardprograms_view->merchantid->caption() ?></span></td>
		<td data-name="merchantid" <?php echo $cardprograms_view->merchantid->cellAttributes() ?>>
<span id="el_cardprograms_merchantid">
<span<?php echo $cardprograms_view->merchantid->viewAttributes() ?>><?php echo $cardprograms_view->merchantid->getViewValue() ?></span>
</span>
</td>
	</tr>
<?php } ?>
<?php if ($cardprograms_view->purchasefeetabletype->Visible) { // purchasefeetabletype ?>
	<tr id="r_purchasefeetabletype">
		<td class="<?php echo $cardprograms_view->TableLeftColumnClass ?>"><span id="elh_cardprograms_purchasefeetabletype"><?php echo $cardprograms_view->purchasefeetabletype->caption() ?></span></td>
		<td data-name="purchasefeetabletype" <?php echo $cardprograms_view->purchasefeetabletype->cellAttributes() ?>>
<span id="el_cardprograms_purchasefeetabletype">
<span<?php echo $cardprograms_view->purchasefeetabletype->viewAttributes() ?>><?php echo $cardprograms_view->purchasefeetabletype->getViewValue() ?></span>
</span>
</td>
	</tr>
<?php } ?>
<?php if ($cardprograms_view->purchasefeetableid->Visible) { // purchasefeetableid ?>
	<tr id="r_purchasefeetableid">
		<td class="<?php echo $cardprograms_view->TableLeftColumnClass ?>"><span id="elh_cardprograms_purchasefeetableid"><?php echo $cardprograms_view->purchasefeetableid->caption() ?></span></td>
		<td data-name="purchasefeetableid" <?php echo $cardprograms_view->purchasefeetableid->cellAttributes() ?>>
<span id="el_cardprograms_purchasefeetableid">
<span<?php echo $cardprograms_view->purchasefeetableid->viewAttributes() ?>><?php echo $cardprograms_view->purchasefeetableid->getViewValue() ?></span>
</span>
</td>
	</tr>
<?php } ?>
<?php if ($cardprograms_view->programfeeaccount->Visible) { // programfeeaccount ?>
	<tr id="r_programfeeaccount">
		<td class="<?php echo $cardprograms_view->TableLeftColumnClass ?>"><span id="elh_cardprograms_programfeeaccount"><?php echo $cardprograms_view->programfeeaccount->caption() ?></span></td>
		<td data-name="programfeeaccount" <?php echo $cardprograms_view->programfeeaccount->cellAttributes() ?>>
<span id="el_cardprograms_programfeeaccount">
<span<?php echo $cardprograms_view->programfeeaccount->viewAttributes() ?>><?php echo $cardprograms_view->programfeeaccount->getViewValue() ?></span>
</span>
</td>
	</tr>
<?php } ?>
<?php if ($cardprograms_view->defaultcurrencycode->Visible) { // defaultcurrencycode ?>
	<tr id="r_defaultcurrencycode">
		<td class="<?php echo $cardprograms_view->TableLeftColumnClass ?>"><span id="elh_cardprograms_defaultcurrencycode"><?php echo $cardprograms_view->defaultcurrencycode->caption() ?></span></td>
		<td data-name="defaultcurrencycode" <?php echo $cardprograms_view->defaultcurrencycode->cellAttributes() ?>>
<span id="el_cardprograms_defaultcurrencycode">
<span<?php echo $cardprograms_view->defaultcurrencycode->viewAttributes() ?>><?php echo $cardprograms_view->defaultcurrencycode->getViewValue() ?></span>
</span>
</td>
	</tr>
<?php } ?>
<?php if ($cardprograms_view->purchasetargetpiid->Visible) { // purchasetargetpiid ?>
	<tr id="r_purchasetargetpiid">
		<td class="<?php echo $cardprograms_view->TableLeftColumnClass ?>"><span id="elh_cardprograms_purchasetargetpiid"><?php echo $cardprograms_view->purchasetargetpiid->caption() ?></span></td>
		<td data-name="purchasetargetpiid" <?php echo $cardprograms_view->purchasetargetpiid->cellAttributes() ?>>
<span id="el_cardprograms_purchasetargetpiid">
<span<?php echo $cardprograms_view->purchasetargetpiid->viewAttributes() ?>><?php echo $cardprograms_view->purchasetargetpiid->getViewValue() ?></span>
</span>
</td>
	</tr>
<?php } ?>
<?php if ($cardprograms_view->status->Visible) { // status ?>
	<tr id="r_status">
		<td class="<?php echo $cardprograms_view->TableLeftColumnClass ?>"><span id="elh_cardprograms_status"><?php echo $cardprograms_view->status->caption() ?></span></td>
		<td data-name="status" <?php echo $cardprograms_view->status->cellAttributes() ?>>
<span id="el_cardprograms_status">
<span<?php echo $cardprograms_view->status->viewAttributes() ?>><?php echo $cardprograms_view->status->getViewValue() ?></span>
</span>
</td>
	</tr>
<?php } ?>
<?php if ($cardprograms_view->programaccountno->Visible) { // programaccountno ?>
	<tr id="r_programaccountno">
		<td class="<?php echo $cardprograms_view->TableLeftColumnClass ?>"><span id="elh_cardprograms_programaccountno"><?php echo $cardprograms_view->programaccountno->caption() ?></span></td>
		<td data-name="programaccountno" <?php echo $cardprograms_view->programaccountno->cellAttributes() ?>>
<span id="el_cardprograms_programaccountno">
<span<?php echo $cardprograms_view->programaccountno->viewAttributes() ?>><?php echo $cardprograms_view->programaccountno->getViewValue() ?></span>
</span>
</td>
	</tr>
<?php } ?>
<?php if ($cardprograms_view->paycontrolaccountno->Visible) { // paycontrolaccountno ?>
	<tr id="r_paycontrolaccountno">
		<td class="<?php echo $cardprograms_view->TableLeftColumnClass ?>"><span id="elh_cardprograms_paycontrolaccountno"><?php echo $cardprograms_view->paycontrolaccountno->caption() ?></span></td>
		<td data-name="paycontrolaccountno" <?php echo $cardprograms_view->paycontrolaccountno->cellAttributes() ?>>
<span id="el_cardprograms_paycontrolaccountno">
<span<?php echo $cardprograms_view->paycontrolaccountno->viewAttributes() ?>><?php echo $cardprograms_view->paycontrolaccountno->getViewValue() ?></span>
</span>
</td>
	</tr>
<?php } ?>
<?php if ($cardprograms_view->claimcodetype->Visible) { // claimcodetype ?>
	<tr id="r_claimcodetype">
		<td class="<?php echo $cardprograms_view->TableLeftColumnClass ?>"><span id="elh_cardprograms_claimcodetype"><?php echo $cardprograms_view->claimcodetype->caption() ?></span></td>
		<td data-name="claimcodetype" <?php echo $cardprograms_view->claimcodetype->cellAttributes() ?>>
<span id="el_cardprograms_claimcodetype">
<span<?php echo $cardprograms_view->claimcodetype->viewAttributes() ?>><?php echo $cardprograms_view->claimcodetype->getViewValue() ?></span>
</span>
</td>
	</tr>
<?php } ?>
<?php if ($cardprograms_view->programpiid->Visible) { // programpiid ?>
	<tr id="r_programpiid">
		<td class="<?php echo $cardprograms_view->TableLeftColumnClass ?>"><span id="elh_cardprograms_programpiid"><?php echo $cardprograms_view->programpiid->caption() ?></span></td>
		<td data-name="programpiid" <?php echo $cardprograms_view->programpiid->cellAttributes() ?>>
<span id="el_cardprograms_programpiid">
<span<?php echo $cardprograms_view->programpiid->viewAttributes() ?>><?php echo $cardprograms_view->programpiid->getViewValue() ?></span>
</span>
</td>
	</tr>
<?php } ?>
<?php if ($cardprograms_view->settlementoption->Visible) { // settlementoption ?>
	<tr id="r_settlementoption">
		<td class="<?php echo $cardprograms_view->TableLeftColumnClass ?>"><span id="elh_cardprograms_settlementoption"><?php echo $cardprograms_view->settlementoption->caption() ?></span></td>
		<td data-name="settlementoption" <?php echo $cardprograms_view->settlementoption->cellAttributes() ?>>
<span id="el_cardprograms_settlementoption">
<span<?php echo $cardprograms_view->settlementoption->viewAttributes() ?>><?php echo $cardprograms_view->settlementoption->getViewValue() ?></span>
</span>
</td>
	</tr>
<?php } ?>
<?php if ($cardprograms_view->settlementdayno->Visible) { // settlementdayno ?>
	<tr id="r_settlementdayno">
		<td class="<?php echo $cardprograms_view->TableLeftColumnClass ?>"><span id="elh_cardprograms_settlementdayno"><?php echo $cardprograms_view->settlementdayno->caption() ?></span></td>
		<td data-name="settlementdayno" <?php echo $cardprograms_view->settlementdayno->cellAttributes() ?>>
<span id="el_cardprograms_settlementdayno">
<span<?php echo $cardprograms_view->settlementdayno->viewAttributes() ?>><?php echo $cardprograms_view->settlementdayno->getViewValue() ?></span>
</span>
</td>
	</tr>
<?php } ?>
<?php if ($cardprograms_view->merchantcanoverridesettlement->Visible) { // merchantcanoverridesettlement ?>
	<tr id="r_merchantcanoverridesettlement">
		<td class="<?php echo $cardprograms_view->TableLeftColumnClass ?>"><span id="elh_cardprograms_merchantcanoverridesettlement"><?php echo $cardprograms_view->merchantcanoverridesettlement->caption() ?></span></td>
		<td data-name="merchantcanoverridesettlement" <?php echo $cardprograms_view->merchantcanoverridesettlement->cellAttributes() ?>>
<span id="el_cardprograms_merchantcanoverridesettlement">
<span<?php echo $cardprograms_view->merchantcanoverridesettlement->viewAttributes() ?>><?php echo $cardprograms_view->merchantcanoverridesettlement->getViewValue() ?></span>
</span>
</td>
	</tr>
<?php } ?>
<?php if ($cardprograms_view->settlementminimumcost->Visible) { // settlementminimumcost ?>
	<tr id="r_settlementminimumcost">
		<td class="<?php echo $cardprograms_view->TableLeftColumnClass ?>"><span id="elh_cardprograms_settlementminimumcost"><?php echo $cardprograms_view->settlementminimumcost->caption() ?></span></td>
		<td data-name="settlementminimumcost" <?php echo $cardprograms_view->settlementminimumcost->cellAttributes() ?>>
<span id="el_cardprograms_settlementminimumcost">
<span<?php echo $cardprograms_view->settlementminimumcost->viewAttributes() ?>><?php echo $cardprograms_view->settlementminimumcost->getViewValue() ?></span>
</span>
</td>
	</tr>
<?php } ?>
<?php if ($cardprograms_view->settlementdefinedcost->Visible) { // settlementdefinedcost ?>
	<tr id="r_settlementdefinedcost">
		<td class="<?php echo $cardprograms_view->TableLeftColumnClass ?>"><span id="elh_cardprograms_settlementdefinedcost"><?php echo $cardprograms_view->settlementdefinedcost->caption() ?></span></td>
		<td data-name="settlementdefinedcost" <?php echo $cardprograms_view->settlementdefinedcost->cellAttributes() ?>>
<span id="el_cardprograms_settlementdefinedcost">
<span<?php echo $cardprograms_view->settlementdefinedcost->viewAttributes() ?>><?php echo $cardprograms_view->settlementdefinedcost->getViewValue() ?></span>
</span>
</td>
	</tr>
<?php } ?>
<?php if ($cardprograms_view->costabsorbedbymerchant->Visible) { // costabsorbedbymerchant ?>
	<tr id="r_costabsorbedbymerchant">
		<td class="<?php echo $cardprograms_view->TableLeftColumnClass ?>"><span id="elh_cardprograms_costabsorbedbymerchant"><?php echo $cardprograms_view->costabsorbedbymerchant->caption() ?></span></td>
		<td data-name="costabsorbedbymerchant" <?php echo $cardprograms_view->costabsorbedbymerchant->cellAttributes() ?>>
<span id="el_cardprograms_costabsorbedbymerchant">
<span<?php echo $cardprograms_view->costabsorbedbymerchant->viewAttributes() ?>><?php echo $cardprograms_view->costabsorbedbymerchant->getViewValue() ?></span>
</span>
</td>
	</tr>
<?php } ?>
<?php if ($cardprograms_view->notificationemailaddresses->Visible) { // notificationemailaddresses ?>
	<tr id="r_notificationemailaddresses">
		<td class="<?php echo $cardprograms_view->TableLeftColumnClass ?>"><span id="elh_cardprograms_notificationemailaddresses"><?php echo $cardprograms_view->notificationemailaddresses->caption() ?></span></td>
		<td data-name="notificationemailaddresses" <?php echo $cardprograms_view->notificationemailaddresses->cellAttributes() ?>>
<span id="el_cardprograms_notificationemailaddresses">
<span<?php echo $cardprograms_view->notificationemailaddresses->viewAttributes() ?>><?php echo $cardprograms_view->notificationemailaddresses->getViewValue() ?></span>
</span>
</td>
	</tr>
<?php } ?>
<?php if ($cardprograms_view->gatewayid->Visible) { // gatewayid ?>
	<tr id="r_gatewayid">
		<td class="<?php echo $cardprograms_view->TableLeftColumnClass ?>"><span id="elh_cardprograms_gatewayid"><?php echo $cardprograms_view->gatewayid->caption() ?></span></td>
		<td data-name="gatewayid" <?php echo $cardprograms_view->gatewayid->cellAttributes() ?>>
<span id="el_cardprograms_gatewayid">
<span<?php echo $cardprograms_view->gatewayid->viewAttributes() ?>><?php echo $cardprograms_view->gatewayid->getViewValue() ?></span>
</span>
</td>
	</tr>
<?php } ?>
<?php if ($cardprograms_view->gatewayprofileid->Visible) { // gatewayprofileid ?>
	<tr id="r_gatewayprofileid">
		<td class="<?php echo $cardprograms_view->TableLeftColumnClass ?>"><span id="elh_cardprograms_gatewayprofileid"><?php echo $cardprograms_view->gatewayprofileid->caption() ?></span></td>
		<td data-name="gatewayprofileid" <?php echo $cardprograms_view->gatewayprofileid->cellAttributes() ?>>
<span id="el_cardprograms_gatewayprofileid">
<span<?php echo $cardprograms_view->gatewayprofileid->viewAttributes() ?>><?php echo $cardprograms_view->gatewayprofileid->getViewValue() ?></span>
</span>
</td>
	</tr>
<?php } ?>
<?php if ($cardprograms_view->newaccountemailtemplate->Visible) { // newaccountemailtemplate ?>
	<tr id="r_newaccountemailtemplate">
		<td class="<?php echo $cardprograms_view->TableLeftColumnClass ?>"><span id="elh_cardprograms_newaccountemailtemplate"><?php echo $cardprograms_view->newaccountemailtemplate->caption() ?></span></td>
		<td data-name="newaccountemailtemplate" <?php echo $cardprograms_view->newaccountemailtemplate->cellAttributes() ?>>
<span id="el_cardprograms_newaccountemailtemplate">
<span<?php echo $cardprograms_view->newaccountemailtemplate->viewAttributes() ?>><?php echo $cardprograms_view->newaccountemailtemplate->getViewValue() ?></span>
</span>
</td>
	</tr>
<?php } ?>
<?php if ($cardprograms_view->newaccountsmstext->Visible) { // newaccountsmstext ?>
	<tr id="r_newaccountsmstext">
		<td class="<?php echo $cardprograms_view->TableLeftColumnClass ?>"><span id="elh_cardprograms_newaccountsmstext"><?php echo $cardprograms_view->newaccountsmstext->caption() ?></span></td>
		<td data-name="newaccountsmstext" <?php echo $cardprograms_view->newaccountsmstext->cellAttributes() ?>>
<span id="el_cardprograms_newaccountsmstext">
<span<?php echo $cardprograms_view->newaccountsmstext->viewAttributes() ?>><?php echo $cardprograms_view->newaccountsmstext->getViewValue() ?></span>
</span>
</td>
	</tr>
<?php } ?>
<?php if ($cardprograms_view->defaultstatusofnewcards->Visible) { // defaultstatusofnewcards ?>
	<tr id="r_defaultstatusofnewcards">
		<td class="<?php echo $cardprograms_view->TableLeftColumnClass ?>"><span id="elh_cardprograms_defaultstatusofnewcards"><?php echo $cardprograms_view->defaultstatusofnewcards->caption() ?></span></td>
		<td data-name="defaultstatusofnewcards" <?php echo $cardprograms_view->defaultstatusofnewcards->cellAttributes() ?>>
<span id="el_cardprograms_defaultstatusofnewcards">
<span<?php echo $cardprograms_view->defaultstatusofnewcards->viewAttributes() ?>><?php echo $cardprograms_view->defaultstatusofnewcards->getViewValue() ?></span>
</span>
</td>
	</tr>
<?php } ?>
<?php if ($cardprograms_view->merchantsettlementtype->Visible) { // merchantsettlementtype ?>
	<tr id="r_merchantsettlementtype">
		<td class="<?php echo $cardprograms_view->TableLeftColumnClass ?>"><span id="elh_cardprograms_merchantsettlementtype"><?php echo $cardprograms_view->merchantsettlementtype->caption() ?></span></td>
		<td data-name="merchantsettlementtype" <?php echo $cardprograms_view->merchantsettlementtype->cellAttributes() ?>>
<span id="el_cardprograms_merchantsettlementtype">
<span<?php echo $cardprograms_view->merchantsettlementtype->viewAttributes() ?>><?php echo $cardprograms_view->merchantsettlementtype->getViewValue() ?></span>
</span>
</td>
	</tr>
<?php } ?>
<?php if ($cardprograms_view->setupminiapp->Visible) { // setupminiapp ?>
	<tr id="r_setupminiapp">
		<td class="<?php echo $cardprograms_view->TableLeftColumnClass ?>"><span id="elh_cardprograms_setupminiapp"><?php echo $cardprograms_view->setupminiapp->caption() ?></span></td>
		<td data-name="setupminiapp" <?php echo $cardprograms_view->setupminiapp->cellAttributes() ?>>
<span id="el_cardprograms_setupminiapp">
<span<?php echo $cardprograms_view->setupminiapp->viewAttributes() ?>><?php echo $cardprograms_view->setupminiapp->getViewValue() ?></span>
</span>
</td>
	</tr>
<?php } ?>
<?php if ($cardprograms_view->sendverificationsms->Visible) { // sendverificationsms ?>
	<tr id="r_sendverificationsms">
		<td class="<?php echo $cardprograms_view->TableLeftColumnClass ?>"><span id="elh_cardprograms_sendverificationsms"><?php echo $cardprograms_view->sendverificationsms->caption() ?></span></td>
		<td data-name="sendverificationsms" <?php echo $cardprograms_view->sendverificationsms->cellAttributes() ?>>
<span id="el_cardprograms_sendverificationsms">
<span<?php echo $cardprograms_view->sendverificationsms->viewAttributes() ?>><?php echo $cardprograms_view->sendverificationsms->getViewValue() ?></span>
</span>
</td>
	</tr>
<?php } ?>
<?php if ($cardprograms_view->profile_status->Visible) { // profile_status ?>
	<tr id="r_profile_status">
		<td class="<?php echo $cardprograms_view->TableLeftColumnClass ?>"><span id="elh_cardprograms_profile_status"><?php echo $cardprograms_view->profile_status->caption() ?></span></td>
		<td data-name="profile_status" <?php echo $cardprograms_view->profile_status->cellAttributes() ?>>
<span id="el_cardprograms_profile_status">
<span<?php echo $cardprograms_view->profile_status->viewAttributes() ?>><?php echo $cardprograms_view->profile_status->getViewValue() ?></span>
</span>
</td>
	</tr>
<?php } ?>
<?php if ($cardprograms_view->other1->Visible) { // other1 ?>
	<tr id="r_other1">
		<td class="<?php echo $cardprograms_view->TableLeftColumnClass ?>"><span id="elh_cardprograms_other1"><?php echo $cardprograms_view->other1->caption() ?></span></td>
		<td data-name="other1" <?php echo $cardprograms_view->other1->cellAttributes() ?>>
<span id="el_cardprograms_other1">
<span<?php echo $cardprograms_view->other1->viewAttributes() ?>><?php echo $cardprograms_view->other1->getViewValue() ?></span>
</span>
</td>
	</tr>
<?php } ?>
<?php if ($cardprograms_view->default_pin->Visible) { // default_pin ?>
	<tr id="r_default_pin">
		<td class="<?php echo $cardprograms_view->TableLeftColumnClass ?>"><span id="elh_cardprograms_default_pin"><?php echo $cardprograms_view->default_pin->caption() ?></span></td>
		<td data-name="default_pin" <?php echo $cardprograms_view->default_pin->cellAttributes() ?>>
<span id="el_cardprograms_default_pin">
<span<?php echo $cardprograms_view->default_pin->viewAttributes() ?>><?php echo $cardprograms_view->default_pin->getViewValue() ?></span>
</span>
</td>
	</tr>
<?php } ?>
<?php if ($cardprograms_view->franchisee_id->Visible) { // franchisee_id ?>
	<tr id="r_franchisee_id">
		<td class="<?php echo $cardprograms_view->TableLeftColumnClass ?>"><span id="elh_cardprograms_franchisee_id"><?php echo $cardprograms_view->franchisee_id->caption() ?></span></td>
		<td data-name="franchisee_id" <?php echo $cardprograms_view->franchisee_id->cellAttributes() ?>>
<span id="el_cardprograms_franchisee_id">
<span<?php echo $cardprograms_view->franchisee_id->viewAttributes() ?>><?php echo $cardprograms_view->franchisee_id->getViewValue() ?></span>
</span>
</td>
	</tr>
<?php } ?>
<?php if ($cardprograms_view->defaultverificationemail->Visible) { // defaultverificationemail ?>
	<tr id="r_defaultverificationemail">
		<td class="<?php echo $cardprograms_view->TableLeftColumnClass ?>"><span id="elh_cardprograms_defaultverificationemail"><?php echo $cardprograms_view->defaultverificationemail->caption() ?></span></td>
		<td data-name="defaultverificationemail" <?php echo $cardprograms_view->defaultverificationemail->cellAttributes() ?>>
<span id="el_cardprograms_defaultverificationemail">
<span<?php echo $cardprograms_view->defaultverificationemail->viewAttributes() ?>><?php echo $cardprograms_view->defaultverificationemail->getViewValue() ?></span>
</span>
</td>
	</tr>
<?php } ?>
<?php if ($cardprograms_view->usertype->Visible) { // usertype ?>
	<tr id="r_usertype">
		<td class="<?php echo $cardprograms_view->TableLeftColumnClass ?>"><span id="elh_cardprograms_usertype"><?php echo $cardprograms_view->usertype->caption() ?></span></td>
		<td data-name="usertype" <?php echo $cardprograms_view->usertype->cellAttributes() ?>>
<span id="el_cardprograms_usertype">
<span<?php echo $cardprograms_view->usertype->viewAttributes() ?>><?php echo $cardprograms_view->usertype->getViewValue() ?></span>
</span>
</td>
	</tr>
<?php } ?>
<?php if ($cardprograms_view->usersubtype->Visible) { // usersubtype ?>
	<tr id="r_usersubtype">
		<td class="<?php echo $cardprograms_view->TableLeftColumnClass ?>"><span id="elh_cardprograms_usersubtype"><?php echo $cardprograms_view->usersubtype->caption() ?></span></td>
		<td data-name="usersubtype" <?php echo $cardprograms_view->usersubtype->cellAttributes() ?>>
<span id="el_cardprograms_usersubtype">
<span<?php echo $cardprograms_view->usersubtype->viewAttributes() ?>><?php echo $cardprograms_view->usersubtype->getViewValue() ?></span>
</span>
</td>
	</tr>
<?php } ?>
<?php if ($cardprograms_view->addfundnotification->Visible) { // addfundnotification ?>
	<tr id="r_addfundnotification">
		<td class="<?php echo $cardprograms_view->TableLeftColumnClass ?>"><span id="elh_cardprograms_addfundnotification"><?php echo $cardprograms_view->addfundnotification->caption() ?></span></td>
		<td data-name="addfundnotification" <?php echo $cardprograms_view->addfundnotification->cellAttributes() ?>>
<span id="el_cardprograms_addfundnotification">
<span<?php echo $cardprograms_view->addfundnotification->viewAttributes() ?>><?php echo $cardprograms_view->addfundnotification->getViewValue() ?></span>
</span>
</td>
	</tr>
<?php } ?>
<?php if ($cardprograms_view->addfundnotificationemailtemplate->Visible) { // addfundnotificationemailtemplate ?>
	<tr id="r_addfundnotificationemailtemplate">
		<td class="<?php echo $cardprograms_view->TableLeftColumnClass ?>"><span id="elh_cardprograms_addfundnotificationemailtemplate"><?php echo $cardprograms_view->addfundnotificationemailtemplate->caption() ?></span></td>
		<td data-name="addfundnotificationemailtemplate" <?php echo $cardprograms_view->addfundnotificationemailtemplate->cellAttributes() ?>>
<span id="el_cardprograms_addfundnotificationemailtemplate">
<span<?php echo $cardprograms_view->addfundnotificationemailtemplate->viewAttributes() ?>><?php echo $cardprograms_view->addfundnotificationemailtemplate->getViewValue() ?></span>
</span>
</td>
	</tr>
<?php } ?>
<?php if ($cardprograms_view->addfundnotificationsmstext->Visible) { // addfundnotificationsmstext ?>
	<tr id="r_addfundnotificationsmstext">
		<td class="<?php echo $cardprograms_view->TableLeftColumnClass ?>"><span id="elh_cardprograms_addfundnotificationsmstext"><?php echo $cardprograms_view->addfundnotificationsmstext->caption() ?></span></td>
		<td data-name="addfundnotificationsmstext" <?php echo $cardprograms_view->addfundnotificationsmstext->cellAttributes() ?>>
<span id="el_cardprograms_addfundnotificationsmstext">
<span<?php echo $cardprograms_view->addfundnotificationsmstext->viewAttributes() ?>><?php echo $cardprograms_view->addfundnotificationsmstext->getViewValue() ?></span>
</span>
</td>
	</tr>
<?php } ?>
<?php if ($cardprograms_view->defaultemailaccountpin->Visible) { // defaultemailaccountpin ?>
	<tr id="r_defaultemailaccountpin">
		<td class="<?php echo $cardprograms_view->TableLeftColumnClass ?>"><span id="elh_cardprograms_defaultemailaccountpin"><?php echo $cardprograms_view->defaultemailaccountpin->caption() ?></span></td>
		<td data-name="defaultemailaccountpin" <?php echo $cardprograms_view->defaultemailaccountpin->cellAttributes() ?>>
<span id="el_cardprograms_defaultemailaccountpin">
<span<?php echo $cardprograms_view->defaultemailaccountpin->viewAttributes() ?>><?php echo $cardprograms_view->defaultemailaccountpin->getViewValue() ?></span>
</span>
</td>
	</tr>
<?php } ?>
<?php if ($cardprograms_view->sensitiveinfodatatype->Visible) { // sensitiveinfodatatype ?>
	<tr id="r_sensitiveinfodatatype">
		<td class="<?php echo $cardprograms_view->TableLeftColumnClass ?>"><span id="elh_cardprograms_sensitiveinfodatatype"><?php echo $cardprograms_view->sensitiveinfodatatype->caption() ?></span></td>
		<td data-name="sensitiveinfodatatype" <?php echo $cardprograms_view->sensitiveinfodatatype->cellAttributes() ?>>
<span id="el_cardprograms_sensitiveinfodatatype">
<span<?php echo $cardprograms_view->sensitiveinfodatatype->viewAttributes() ?>><?php echo $cardprograms_view->sensitiveinfodatatype->getViewValue() ?></span>
</span>
</td>
	</tr>
<?php } ?>
<?php if ($cardprograms_view->duplicateemailallowed->Visible) { // duplicateemailallowed ?>
	<tr id="r_duplicateemailallowed">
		<td class="<?php echo $cardprograms_view->TableLeftColumnClass ?>"><span id="elh_cardprograms_duplicateemailallowed"><?php echo $cardprograms_view->duplicateemailallowed->caption() ?></span></td>
		<td data-name="duplicateemailallowed" <?php echo $cardprograms_view->duplicateemailallowed->cellAttributes() ?>>
<span id="el_cardprograms_duplicateemailallowed">
<span<?php echo $cardprograms_view->duplicateemailallowed->viewAttributes() ?>><?php echo $cardprograms_view->duplicateemailallowed->getViewValue() ?></span>
</span>
</td>
	</tr>
<?php } ?>
<?php if ($cardprograms_view->usernamepostfix->Visible) { // usernamepostfix ?>
	<tr id="r_usernamepostfix">
		<td class="<?php echo $cardprograms_view->TableLeftColumnClass ?>"><span id="elh_cardprograms_usernamepostfix"><?php echo $cardprograms_view->usernamepostfix->caption() ?></span></td>
		<td data-name="usernamepostfix" <?php echo $cardprograms_view->usernamepostfix->cellAttributes() ?>>
<span id="el_cardprograms_usernamepostfix">
<span<?php echo $cardprograms_view->usernamepostfix->viewAttributes() ?>><?php echo $cardprograms_view->usernamepostfix->getViewValue() ?></span>
</span>
</td>
	</tr>
<?php } ?>
<?php if ($cardprograms_view->allowphonecountrycode->Visible) { // allowphonecountrycode ?>
	<tr id="r_allowphonecountrycode">
		<td class="<?php echo $cardprograms_view->TableLeftColumnClass ?>"><span id="elh_cardprograms_allowphonecountrycode"><?php echo $cardprograms_view->allowphonecountrycode->caption() ?></span></td>
		<td data-name="allowphonecountrycode" <?php echo $cardprograms_view->allowphonecountrycode->cellAttributes() ?>>
<span id="el_cardprograms_allowphonecountrycode">
<span<?php echo $cardprograms_view->allowphonecountrycode->viewAttributes() ?>><?php echo $cardprograms_view->allowphonecountrycode->getViewValue() ?></span>
</span>
</td>
	</tr>
<?php } ?>
<?php if ($cardprograms_view->rejectioncontactdetails->Visible) { // rejectioncontactdetails ?>
	<tr id="r_rejectioncontactdetails">
		<td class="<?php echo $cardprograms_view->TableLeftColumnClass ?>"><span id="elh_cardprograms_rejectioncontactdetails"><?php echo $cardprograms_view->rejectioncontactdetails->caption() ?></span></td>
		<td data-name="rejectioncontactdetails" <?php echo $cardprograms_view->rejectioncontactdetails->cellAttributes() ?>>
<span id="el_cardprograms_rejectioncontactdetails">
<span<?php echo $cardprograms_view->rejectioncontactdetails->viewAttributes() ?>><?php echo $cardprograms_view->rejectioncontactdetails->getViewValue() ?></span>
</span>
</td>
	</tr>
<?php } ?>
<?php if ($cardprograms_view->setupaccountminiapp->Visible) { // setupaccountminiapp ?>
	<tr id="r_setupaccountminiapp">
		<td class="<?php echo $cardprograms_view->TableLeftColumnClass ?>"><span id="elh_cardprograms_setupaccountminiapp"><?php echo $cardprograms_view->setupaccountminiapp->caption() ?></span></td>
		<td data-name="setupaccountminiapp" <?php echo $cardprograms_view->setupaccountminiapp->cellAttributes() ?>>
<span id="el_cardprograms_setupaccountminiapp">
<span<?php echo $cardprograms_view->setupaccountminiapp->viewAttributes() ?>><?php echo $cardprograms_view->setupaccountminiapp->getViewValue() ?></span>
</span>
</td>
	</tr>
<?php } ?>
<?php if ($cardprograms_view->paymentrequireswalletpin->Visible) { // paymentrequireswalletpin ?>
	<tr id="r_paymentrequireswalletpin">
		<td class="<?php echo $cardprograms_view->TableLeftColumnClass ?>"><span id="elh_cardprograms_paymentrequireswalletpin"><?php echo $cardprograms_view->paymentrequireswalletpin->caption() ?></span></td>
		<td data-name="paymentrequireswalletpin" <?php echo $cardprograms_view->paymentrequireswalletpin->cellAttributes() ?>>
<span id="el_cardprograms_paymentrequireswalletpin">
<span<?php echo $cardprograms_view->paymentrequireswalletpin->viewAttributes() ?>><?php echo $cardprograms_view->paymentrequireswalletpin->getViewValue() ?></span>
</span>
</td>
	</tr>
<?php } ?>
<?php if ($cardprograms_view->binno->Visible) { // binno ?>
	<tr id="r_binno">
		<td class="<?php echo $cardprograms_view->TableLeftColumnClass ?>"><span id="elh_cardprograms_binno"><?php echo $cardprograms_view->binno->caption() ?></span></td>
		<td data-name="binno" <?php echo $cardprograms_view->binno->cellAttributes() ?>>
<span id="el_cardprograms_binno">
<span<?php echo $cardprograms_view->binno->viewAttributes() ?>><?php echo $cardprograms_view->binno->getViewValue() ?></span>
</span>
</td>
	</tr>
<?php } ?>
<?php if ($cardprograms_view->reportingemail->Visible) { // reportingemail ?>
	<tr id="r_reportingemail">
		<td class="<?php echo $cardprograms_view->TableLeftColumnClass ?>"><span id="elh_cardprograms_reportingemail"><?php echo $cardprograms_view->reportingemail->caption() ?></span></td>
		<td data-name="reportingemail" <?php echo $cardprograms_view->reportingemail->cellAttributes() ?>>
<span id="el_cardprograms_reportingemail">
<span<?php echo $cardprograms_view->reportingemail->viewAttributes() ?>><?php echo $cardprograms_view->reportingemail->getViewValue() ?></span>
</span>
</td>
	</tr>
<?php } ?>
<?php if ($cardprograms_view->suppressprogramvalue->Visible) { // suppressprogramvalue ?>
	<tr id="r_suppressprogramvalue">
		<td class="<?php echo $cardprograms_view->TableLeftColumnClass ?>"><span id="elh_cardprograms_suppressprogramvalue"><?php echo $cardprograms_view->suppressprogramvalue->caption() ?></span></td>
		<td data-name="suppressprogramvalue" <?php echo $cardprograms_view->suppressprogramvalue->cellAttributes() ?>>
<span id="el_cardprograms_suppressprogramvalue">
<span<?php echo $cardprograms_view->suppressprogramvalue->viewAttributes() ?>><?php echo $cardprograms_view->suppressprogramvalue->getViewValue() ?></span>
</span>
</td>
	</tr>
<?php } ?>
<?php if ($cardprograms_view->withdrawalmerchantgp->Visible) { // withdrawalmerchantgp ?>
	<tr id="r_withdrawalmerchantgp">
		<td class="<?php echo $cardprograms_view->TableLeftColumnClass ?>"><span id="elh_cardprograms_withdrawalmerchantgp"><?php echo $cardprograms_view->withdrawalmerchantgp->caption() ?></span></td>
		<td data-name="withdrawalmerchantgp" <?php echo $cardprograms_view->withdrawalmerchantgp->cellAttributes() ?>>
<span id="el_cardprograms_withdrawalmerchantgp">
<span<?php echo $cardprograms_view->withdrawalmerchantgp->viewAttributes() ?>><?php echo $cardprograms_view->withdrawalmerchantgp->getViewValue() ?></span>
</span>
</td>
	</tr>
<?php } ?>
<?php if ($cardprograms_view->removefundnotificationemailtemplate->Visible) { // removefundnotificationemailtemplate ?>
	<tr id="r_removefundnotificationemailtemplate">
		<td class="<?php echo $cardprograms_view->TableLeftColumnClass ?>"><span id="elh_cardprograms_removefundnotificationemailtemplate"><?php echo $cardprograms_view->removefundnotificationemailtemplate->caption() ?></span></td>
		<td data-name="removefundnotificationemailtemplate" <?php echo $cardprograms_view->removefundnotificationemailtemplate->cellAttributes() ?>>
<span id="el_cardprograms_removefundnotificationemailtemplate">
<span<?php echo $cardprograms_view->removefundnotificationemailtemplate->viewAttributes() ?>><?php echo $cardprograms_view->removefundnotificationemailtemplate->getViewValue() ?></span>
</span>
</td>
	</tr>
<?php } ?>
<?php if ($cardprograms_view->removefundnotificationsmstext->Visible) { // removefundnotificationsmstext ?>
	<tr id="r_removefundnotificationsmstext">
		<td class="<?php echo $cardprograms_view->TableLeftColumnClass ?>"><span id="elh_cardprograms_removefundnotificationsmstext"><?php echo $cardprograms_view->removefundnotificationsmstext->caption() ?></span></td>
		<td data-name="removefundnotificationsmstext" <?php echo $cardprograms_view->removefundnotificationsmstext->cellAttributes() ?>>
<span id="el_cardprograms_removefundnotificationsmstext">
<span<?php echo $cardprograms_view->removefundnotificationsmstext->viewAttributes() ?>><?php echo $cardprograms_view->removefundnotificationsmstext->getViewValue() ?></span>
</span>
</td>
	</tr>
<?php } ?>
<?php if ($cardprograms_view->merchanturl->Visible) { // merchanturl ?>
	<tr id="r_merchanturl">
		<td class="<?php echo $cardprograms_view->TableLeftColumnClass ?>"><span id="elh_cardprograms_merchanturl"><?php echo $cardprograms_view->merchanturl->caption() ?></span></td>
		<td data-name="merchanturl" <?php echo $cardprograms_view->merchanturl->cellAttributes() ?>>
<span id="el_cardprograms_merchanturl">
<span<?php echo $cardprograms_view->merchanturl->viewAttributes() ?>><?php echo $cardprograms_view->merchanturl->getViewValue() ?></span>
</span>
</td>
	</tr>
<?php } ?>
<?php if ($cardprograms_view->autoapprovejobads->Visible) { // autoapprovejobads ?>
	<tr id="r_autoapprovejobads">
		<td class="<?php echo $cardprograms_view->TableLeftColumnClass ?>"><span id="elh_cardprograms_autoapprovejobads"><?php echo $cardprograms_view->autoapprovejobads->caption() ?></span></td>
		<td data-name="autoapprovejobads" <?php echo $cardprograms_view->autoapprovejobads->cellAttributes() ?>>
<span id="el_cardprograms_autoapprovejobads">
<span<?php echo $cardprograms_view->autoapprovejobads->viewAttributes() ?>><?php echo $cardprograms_view->autoapprovejobads->getViewValue() ?></span>
</span>
</td>
	</tr>
<?php } ?>
</table>
<?php
	if (in_array("paymentinstrument", explode(",", $cardprograms->getCurrentDetailTable())) && $paymentinstrument->DetailView) {
?>
<?php if ($cardprograms->getCurrentDetailTable() != "") { ?>
<h4 class="ew-detail-caption"><?php echo $Language->tablePhrase("paymentinstrument", "TblCaption") ?></h4>
<?php } ?>
<?php include_once "paymentinstrumentgrid.php" ?>
<?php } ?>
</form>
<?php
$cardprograms_view->showPageFooter();
if (Config("DEBUG"))
	echo GetDebugMessage();
?>
<?php if (!$cardprograms_view->isExport()) { ?>
<script>
loadjs.ready("load", function() {

	// Startup script
	// Write your table-specific startup script here
	// console.log("page loaded");

});
</script>
<?php } ?>
<?php include_once "footer.php"; ?>
<?php
$cardprograms_view->terminate();
?>