<?php
namespace PHPMaker2020\_4payadmin;

// Autoload
include_once "autoload.php";

// Session
if (session_status() !== PHP_SESSION_ACTIVE)
	\Delight\Cookie\Session::start(Config("COOKIE_SAMESITE")); // Init session data

// Output buffering
ob_start();
?>
<?php

// Write header
WriteHeader(FALSE);

// Create page object
$loanusersummarybyday_add = new loanusersummarybyday_add();

// Run the page
$loanusersummarybyday_add->run();

// Setup login status
SetupLoginStatus();
SetClientVar("login", LoginStatus());

// Global Page Rendering event (in userfn*.php)
Page_Rendering();

// Page Rendering event
$loanusersummarybyday_add->Page_Render();
?>
<?php include_once "header.php"; ?>
<script>
var floanusersummarybydayadd, currentPageID;
loadjs.ready("head", function() {

	// Form object
	currentPageID = ew.PAGE_ID = "add";
	floanusersummarybydayadd = currentForm = new ew.Form("floanusersummarybydayadd", "add");

	// Validate form
	floanusersummarybydayadd.validate = function() {
		if (!this.validateRequired)
			return true; // Ignore validation
		var $ = jQuery, fobj = this.getForm(), $fobj = $(fobj);
		if ($fobj.find("#confirm").val() == "confirm")
			return true;
		var elm, felm, uelm, addcnt = 0;
		var $k = $fobj.find("#" + this.formKeyCountName); // Get key_count
		var rowcnt = ($k[0]) ? parseInt($k.val(), 10) : 1;
		var startcnt = (rowcnt == 0) ? 0 : 1; // Check rowcnt == 0 => Inline-Add
		var gridinsert = ["insert", "gridinsert"].includes($fobj.find("#action").val()) && $k[0];
		for (var i = startcnt; i <= rowcnt; i++) {
			var infix = ($k[0]) ? String(i) : "";
			$fobj.data("rowindex", infix);
			<?php if ($loanusersummarybyday_add->_userid->Required) { ?>
				elm = this.getElements("x" + infix + "__userid");
				if (elm && !ew.isHidden(elm) && !ew.hasValue(elm))
					return this.onError(elm, "<?php echo JsEncode(str_replace("%s", $loanusersummarybyday_add->_userid->caption(), $loanusersummarybyday_add->_userid->RequiredErrorMessage)) ?>");
			<?php } ?>
				elm = this.getElements("x" + infix + "__userid");
				if (elm && !ew.checkInteger(elm.value))
					return this.onError(elm, "<?php echo JsEncode($loanusersummarybyday_add->_userid->errorMessage()) ?>");
			<?php if ($loanusersummarybyday_add->currcode->Required) { ?>
				elm = this.getElements("x" + infix + "_currcode");
				if (elm && !ew.isHidden(elm) && !ew.hasValue(elm))
					return this.onError(elm, "<?php echo JsEncode(str_replace("%s", $loanusersummarybyday_add->currcode->caption(), $loanusersummarybyday_add->currcode->RequiredErrorMessage)) ?>");
			<?php } ?>
			<?php if ($loanusersummarybyday_add->loandate->Required) { ?>
				elm = this.getElements("x" + infix + "_loandate");
				if (elm && !ew.isHidden(elm) && !ew.hasValue(elm))
					return this.onError(elm, "<?php echo JsEncode(str_replace("%s", $loanusersummarybyday_add->loandate->caption(), $loanusersummarybyday_add->loandate->RequiredErrorMessage)) ?>");
			<?php } ?>
				elm = this.getElements("x" + infix + "_loandate");
				if (elm && !ew.checkDateDef(elm.value))
					return this.onError(elm, "<?php echo JsEncode($loanusersummarybyday_add->loandate->errorMessage()) ?>");
			<?php if ($loanusersummarybyday_add->amount->Required) { ?>
				elm = this.getElements("x" + infix + "_amount");
				if (elm && !ew.isHidden(elm) && !ew.hasValue(elm))
					return this.onError(elm, "<?php echo JsEncode(str_replace("%s", $loanusersummarybyday_add->amount->caption(), $loanusersummarybyday_add->amount->RequiredErrorMessage)) ?>");
			<?php } ?>
				elm = this.getElements("x" + infix + "_amount");
				if (elm && !ew.checkNumber(elm.value))
					return this.onError(elm, "<?php echo JsEncode($loanusersummarybyday_add->amount->errorMessage()) ?>");

				// Call Form_CustomValidate event
				if (!this.Form_CustomValidate(fobj))
					return false;
		}

		// Process detail forms
		var dfs = $fobj.find("input[name='detailpage']").get();
		for (var i = 0; i < dfs.length; i++) {
			var df = dfs[i], val = df.value;
			if (val && ew.forms[val])
				if (!ew.forms[val].validate())
					return false;
		}
		return true;
	}

	// Form_CustomValidate
	floanusersummarybydayadd.Form_CustomValidate = function(fobj) { // DO NOT CHANGE THIS LINE!

		// Your custom validation code here, return false if invalid.
		return true;
	}

	// Use JavaScript validation or not
	floanusersummarybydayadd.validateRequired = <?php echo Config("CLIENT_VALIDATE") ? "true" : "false" ?>;

	// Dynamic selection lists
	floanusersummarybydayadd.lists["x_currcode"] = <?php echo $loanusersummarybyday_add->currcode->Lookup->toClientList($loanusersummarybyday_add) ?>;
	floanusersummarybydayadd.lists["x_currcode"].options = <?php echo JsonEncode($loanusersummarybyday_add->currcode->lookupOptions()) ?>;
	floanusersummarybydayadd.autoSuggests["x_currcode"] = <?php echo json_encode(["data" => "ajax=autosuggest"]) ?>;
	loadjs.done("floanusersummarybydayadd");
});
</script>
<script>
loadjs.ready("head", function() {

	// Client script
	// Write your client script here, no need to add script tags.

});
</script>
<?php $loanusersummarybyday_add->showPageHeader(); ?>
<?php
$loanusersummarybyday_add->showMessage();
?>
<form name="floanusersummarybydayadd" id="floanusersummarybydayadd" class="<?php echo $loanusersummarybyday_add->FormClassName ?>" action="<?php echo CurrentPageName() ?>" method="post">
<?php if ($Page->CheckToken) { ?>
<input type="hidden" name="<?php echo Config("TOKEN_NAME") ?>" value="<?php echo $Page->Token ?>">
<?php } ?>
<input type="hidden" name="t" value="loanusersummarybyday">
<input type="hidden" name="action" id="action" value="insert">
<input type="hidden" name="modal" value="<?php echo (int)$loanusersummarybyday_add->IsModal ?>">
<?php if ($loanusersummarybyday->getCurrentMasterTable() == "loanlimits") { ?>
<input type="hidden" name="<?php echo Config("TABLE_SHOW_MASTER") ?>" value="loanlimits">
<input type="hidden" name="fk__userid" value="<?php echo HtmlEncode($loanusersummarybyday_add->_userid->getSessionValue()) ?>">
<input type="hidden" name="fk_currcode" value="<?php echo HtmlEncode($loanusersummarybyday_add->currcode->getSessionValue()) ?>">
<?php } ?>
<div class="ew-add-div"><!-- page* -->
<?php if ($loanusersummarybyday_add->_userid->Visible) { // userid ?>
	<div id="r__userid" class="form-group row">
		<label id="elh_loanusersummarybyday__userid" for="x__userid" class="<?php echo $loanusersummarybyday_add->LeftColumnClass ?>"><?php echo $loanusersummarybyday_add->_userid->caption() ?><?php echo $loanusersummarybyday_add->_userid->Required ? $Language->phrase("FieldRequiredIndicator") : "" ?></label>
		<div class="<?php echo $loanusersummarybyday_add->RightColumnClass ?>"><div <?php echo $loanusersummarybyday_add->_userid->cellAttributes() ?>>
<?php if ($loanusersummarybyday_add->_userid->getSessionValue() != "") { ?>
<span id="el_loanusersummarybyday__userid">
<span<?php echo $loanusersummarybyday_add->_userid->viewAttributes() ?>><input type="text" readonly class="form-control-plaintext" value="<?php echo HtmlEncode(RemoveHtml($loanusersummarybyday_add->_userid->ViewValue)) ?>"></span>
</span>
<input type="hidden" id="x__userid" name="x__userid" value="<?php echo HtmlEncode($loanusersummarybyday_add->_userid->CurrentValue) ?>">
<?php } else { ?>
<span id="el_loanusersummarybyday__userid">
<input type="text" data-table="loanusersummarybyday" data-field="x__userid" name="x__userid" id="x__userid" size="30" maxlength="12" placeholder="<?php echo HtmlEncode($loanusersummarybyday_add->_userid->getPlaceHolder()) ?>" value="<?php echo $loanusersummarybyday_add->_userid->EditValue ?>"<?php echo $loanusersummarybyday_add->_userid->editAttributes() ?>>
</span>
<?php } ?>
<?php echo $loanusersummarybyday_add->_userid->CustomMsg ?></div></div>
	</div>
<?php } ?>
<?php if ($loanusersummarybyday_add->currcode->Visible) { // currcode ?>
	<div id="r_currcode" class="form-group row">
		<label id="elh_loanusersummarybyday_currcode" class="<?php echo $loanusersummarybyday_add->LeftColumnClass ?>"><?php echo $loanusersummarybyday_add->currcode->caption() ?><?php echo $loanusersummarybyday_add->currcode->Required ? $Language->phrase("FieldRequiredIndicator") : "" ?></label>
		<div class="<?php echo $loanusersummarybyday_add->RightColumnClass ?>"><div <?php echo $loanusersummarybyday_add->currcode->cellAttributes() ?>>
<?php if ($loanusersummarybyday_add->currcode->getSessionValue() != "") { ?>
<span id="el_loanusersummarybyday_currcode">
<span<?php echo $loanusersummarybyday_add->currcode->viewAttributes() ?>><input type="text" readonly class="form-control-plaintext" value="<?php echo HtmlEncode(RemoveHtml($loanusersummarybyday_add->currcode->ViewValue)) ?>"></span>
</span>
<input type="hidden" id="x_currcode" name="x_currcode" value="<?php echo HtmlEncode($loanusersummarybyday_add->currcode->CurrentValue) ?>">
<?php } else { ?>
<span id="el_loanusersummarybyday_currcode">
<?php
$onchange = $loanusersummarybyday_add->currcode->EditAttrs->prepend("onchange", "");
$onchange = ($onchange) ? ' onchange="' . JsEncode($onchange) . '"' : '';
$loanusersummarybyday_add->currcode->EditAttrs["onchange"] = "";
?>
<span id="as_x_currcode">
	<input type="text" class="form-control" name="sv_x_currcode" id="sv_x_currcode" value="<?php echo RemoveHtml($loanusersummarybyday_add->currcode->EditValue) ?>" size="30" maxlength="3" placeholder="<?php echo HtmlEncode($loanusersummarybyday_add->currcode->getPlaceHolder()) ?>" data-placeholder="<?php echo HtmlEncode($loanusersummarybyday_add->currcode->getPlaceHolder()) ?>"<?php echo $loanusersummarybyday_add->currcode->editAttributes() ?>>
</span>
<input type="hidden" data-table="loanusersummarybyday" data-field="x_currcode" data-value-separator="<?php echo $loanusersummarybyday_add->currcode->displayValueSeparatorAttribute() ?>" name="x_currcode" id="x_currcode" value="<?php echo HtmlEncode($loanusersummarybyday_add->currcode->CurrentValue) ?>"<?php echo $onchange ?>>
<script>
loadjs.ready(["floanusersummarybydayadd"], function() {
	floanusersummarybydayadd.createAutoSuggest({"id":"x_currcode","forceSelect":false});
});
</script>
<?php echo $loanusersummarybyday_add->currcode->Lookup->getParamTag($loanusersummarybyday_add, "p_x_currcode") ?>
</span>
<?php } ?>
<?php echo $loanusersummarybyday_add->currcode->CustomMsg ?></div></div>
	</div>
<?php } ?>
<?php if ($loanusersummarybyday_add->loandate->Visible) { // loandate ?>
	<div id="r_loandate" class="form-group row">
		<label id="elh_loanusersummarybyday_loandate" for="x_loandate" class="<?php echo $loanusersummarybyday_add->LeftColumnClass ?>"><?php echo $loanusersummarybyday_add->loandate->caption() ?><?php echo $loanusersummarybyday_add->loandate->Required ? $Language->phrase("FieldRequiredIndicator") : "" ?></label>
		<div class="<?php echo $loanusersummarybyday_add->RightColumnClass ?>"><div <?php echo $loanusersummarybyday_add->loandate->cellAttributes() ?>>
<span id="el_loanusersummarybyday_loandate">
<input type="text" data-table="loanusersummarybyday" data-field="x_loandate" name="x_loandate" id="x_loandate" maxlength="10" placeholder="<?php echo HtmlEncode($loanusersummarybyday_add->loandate->getPlaceHolder()) ?>" value="<?php echo $loanusersummarybyday_add->loandate->EditValue ?>"<?php echo $loanusersummarybyday_add->loandate->editAttributes() ?>>
<?php if (!$loanusersummarybyday_add->loandate->ReadOnly && !$loanusersummarybyday_add->loandate->Disabled && !isset($loanusersummarybyday_add->loandate->EditAttrs["readonly"]) && !isset($loanusersummarybyday_add->loandate->EditAttrs["disabled"])) { ?>
<script>
loadjs.ready(["floanusersummarybydayadd", "datetimepicker"], function() {
	ew.createDateTimePicker("floanusersummarybydayadd", "x_loandate", {"ignoreReadonly":true,"useCurrent":false,"format":0});
});
</script>
<?php } ?>
</span>
<?php echo $loanusersummarybyday_add->loandate->CustomMsg ?></div></div>
	</div>
<?php } ?>
<?php if ($loanusersummarybyday_add->amount->Visible) { // amount ?>
	<div id="r_amount" class="form-group row">
		<label id="elh_loanusersummarybyday_amount" for="x_amount" class="<?php echo $loanusersummarybyday_add->LeftColumnClass ?>"><?php echo $loanusersummarybyday_add->amount->caption() ?><?php echo $loanusersummarybyday_add->amount->Required ? $Language->phrase("FieldRequiredIndicator") : "" ?></label>
		<div class="<?php echo $loanusersummarybyday_add->RightColumnClass ?>"><div <?php echo $loanusersummarybyday_add->amount->cellAttributes() ?>>
<span id="el_loanusersummarybyday_amount">
<input type="text" data-table="loanusersummarybyday" data-field="x_amount" name="x_amount" id="x_amount" size="30" maxlength="12" placeholder="<?php echo HtmlEncode($loanusersummarybyday_add->amount->getPlaceHolder()) ?>" value="<?php echo $loanusersummarybyday_add->amount->EditValue ?>"<?php echo $loanusersummarybyday_add->amount->editAttributes() ?>>
</span>
<?php echo $loanusersummarybyday_add->amount->CustomMsg ?></div></div>
	</div>
<?php } ?>
</div><!-- /page* -->
<?php if (!$loanusersummarybyday_add->IsModal) { ?>
<div class="form-group row"><!-- buttons .form-group -->
	<div class="<?php echo $loanusersummarybyday_add->OffsetColumnClass ?>"><!-- buttons offset -->
<button class="btn btn-primary ew-btn" name="btn-action" id="btn-action" type="submit"><?php echo $Language->phrase("AddBtn") ?></button>
<button class="btn btn-default ew-btn" name="btn-cancel" id="btn-cancel" type="button" data-href="<?php echo $loanusersummarybyday_add->getReturnUrl() ?>"><?php echo $Language->phrase("CancelBtn") ?></button>
	</div><!-- /buttons offset -->
</div><!-- /buttons .form-group -->
<?php } ?>
</form>
<?php
$loanusersummarybyday_add->showPageFooter();
if (Config("DEBUG"))
	echo GetDebugMessage();
?>
<script>
loadjs.ready("load", function() {

	// Startup script
	// Write your table-specific startup script here
	// console.log("page loaded");

});
</script>
<?php include_once "footer.php"; ?>
<?php
$loanusersummarybyday_add->terminate();
?>