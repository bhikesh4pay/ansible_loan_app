<?php
namespace PHPMaker2020\_4payadmin;

// Autoload
include_once "autoload.php";

// Session
if (session_status() !== PHP_SESSION_ACTIVE)
	\Delight\Cookie\Session::start(Config("COOKIE_SAMESITE")); // Init session data

// Output buffering
ob_start();
?>
<?php

// Write header
WriteHeader(FALSE);

// Create page object
$merchantsubscriptioncatassigned_add = new merchantsubscriptioncatassigned_add();

// Run the page
$merchantsubscriptioncatassigned_add->run();

// Setup login status
SetupLoginStatus();
SetClientVar("login", LoginStatus());

// Global Page Rendering event (in userfn*.php)
Page_Rendering();

// Page Rendering event
$merchantsubscriptioncatassigned_add->Page_Render();
?>
<?php include_once "header.php"; ?>
<script>
var fmerchantsubscriptioncatassignedadd, currentPageID;
loadjs.ready("head", function() {

	// Form object
	currentPageID = ew.PAGE_ID = "add";
	fmerchantsubscriptioncatassignedadd = currentForm = new ew.Form("fmerchantsubscriptioncatassignedadd", "add");

	// Validate form
	fmerchantsubscriptioncatassignedadd.validate = function() {
		if (!this.validateRequired)
			return true; // Ignore validation
		var $ = jQuery, fobj = this.getForm(), $fobj = $(fobj);
		if ($fobj.find("#confirm").val() == "confirm")
			return true;
		var elm, felm, uelm, addcnt = 0;
		var $k = $fobj.find("#" + this.formKeyCountName); // Get key_count
		var rowcnt = ($k[0]) ? parseInt($k.val(), 10) : 1;
		var startcnt = (rowcnt == 0) ? 0 : 1; // Check rowcnt == 0 => Inline-Add
		var gridinsert = ["insert", "gridinsert"].includes($fobj.find("#action").val()) && $k[0];
		for (var i = startcnt; i <= rowcnt; i++) {
			var infix = ($k[0]) ? String(i) : "";
			$fobj.data("rowindex", infix);
			<?php if ($merchantsubscriptioncatassigned_add->subscriptionid->Required) { ?>
				elm = this.getElements("x" + infix + "_subscriptionid");
				if (elm && !ew.isHidden(elm) && !ew.hasValue(elm))
					return this.onError(elm, "<?php echo JsEncode(str_replace("%s", $merchantsubscriptioncatassigned_add->subscriptionid->caption(), $merchantsubscriptioncatassigned_add->subscriptionid->RequiredErrorMessage)) ?>");
			<?php } ?>
				elm = this.getElements("x" + infix + "_subscriptionid");
				if (elm && !ew.checkInteger(elm.value))
					return this.onError(elm, "<?php echo JsEncode($merchantsubscriptioncatassigned_add->subscriptionid->errorMessage()) ?>");
			<?php if ($merchantsubscriptioncatassigned_add->categoryid->Required) { ?>
				elm = this.getElements("x" + infix + "_categoryid");
				if (elm && !ew.isHidden(elm) && !ew.hasValue(elm))
					return this.onError(elm, "<?php echo JsEncode(str_replace("%s", $merchantsubscriptioncatassigned_add->categoryid->caption(), $merchantsubscriptioncatassigned_add->categoryid->RequiredErrorMessage)) ?>");
			<?php } ?>
				elm = this.getElements("x" + infix + "_categoryid");
				if (elm && !ew.checkInteger(elm.value))
					return this.onError(elm, "<?php echo JsEncode($merchantsubscriptioncatassigned_add->categoryid->errorMessage()) ?>");

				// Call Form_CustomValidate event
				if (!this.Form_CustomValidate(fobj))
					return false;
		}

		// Process detail forms
		var dfs = $fobj.find("input[name='detailpage']").get();
		for (var i = 0; i < dfs.length; i++) {
			var df = dfs[i], val = df.value;
			if (val && ew.forms[val])
				if (!ew.forms[val].validate())
					return false;
		}
		return true;
	}

	// Form_CustomValidate
	fmerchantsubscriptioncatassignedadd.Form_CustomValidate = function(fobj) { // DO NOT CHANGE THIS LINE!

		// Your custom validation code here, return false if invalid.
		return true;
	}

	// Use JavaScript validation or not
	fmerchantsubscriptioncatassignedadd.validateRequired = <?php echo Config("CLIENT_VALIDATE") ? "true" : "false" ?>;

	// Dynamic selection lists
	loadjs.done("fmerchantsubscriptioncatassignedadd");
});
</script>
<script>
loadjs.ready("head", function() {

	// Client script
	// Write your client script here, no need to add script tags.

});
</script>
<?php $merchantsubscriptioncatassigned_add->showPageHeader(); ?>
<?php
$merchantsubscriptioncatassigned_add->showMessage();
?>
<form name="fmerchantsubscriptioncatassignedadd" id="fmerchantsubscriptioncatassignedadd" class="<?php echo $merchantsubscriptioncatassigned_add->FormClassName ?>" action="<?php echo CurrentPageName() ?>" method="post">
<?php if ($Page->CheckToken) { ?>
<input type="hidden" name="<?php echo Config("TOKEN_NAME") ?>" value="<?php echo $Page->Token ?>">
<?php } ?>
<input type="hidden" name="t" value="merchantsubscriptioncatassigned">
<input type="hidden" name="action" id="action" value="insert">
<input type="hidden" name="modal" value="<?php echo (int)$merchantsubscriptioncatassigned_add->IsModal ?>">
<div class="ew-add-div"><!-- page* -->
<?php if ($merchantsubscriptioncatassigned_add->subscriptionid->Visible) { // subscriptionid ?>
	<div id="r_subscriptionid" class="form-group row">
		<label id="elh_merchantsubscriptioncatassigned_subscriptionid" for="x_subscriptionid" class="<?php echo $merchantsubscriptioncatassigned_add->LeftColumnClass ?>"><?php echo $merchantsubscriptioncatassigned_add->subscriptionid->caption() ?><?php echo $merchantsubscriptioncatassigned_add->subscriptionid->Required ? $Language->phrase("FieldRequiredIndicator") : "" ?></label>
		<div class="<?php echo $merchantsubscriptioncatassigned_add->RightColumnClass ?>"><div <?php echo $merchantsubscriptioncatassigned_add->subscriptionid->cellAttributes() ?>>
<span id="el_merchantsubscriptioncatassigned_subscriptionid">
<input type="text" data-table="merchantsubscriptioncatassigned" data-field="x_subscriptionid" name="x_subscriptionid" id="x_subscriptionid" size="30" placeholder="<?php echo HtmlEncode($merchantsubscriptioncatassigned_add->subscriptionid->getPlaceHolder()) ?>" value="<?php echo $merchantsubscriptioncatassigned_add->subscriptionid->EditValue ?>"<?php echo $merchantsubscriptioncatassigned_add->subscriptionid->editAttributes() ?>>
</span>
<?php echo $merchantsubscriptioncatassigned_add->subscriptionid->CustomMsg ?></div></div>
	</div>
<?php } ?>
<?php if ($merchantsubscriptioncatassigned_add->categoryid->Visible) { // categoryid ?>
	<div id="r_categoryid" class="form-group row">
		<label id="elh_merchantsubscriptioncatassigned_categoryid" for="x_categoryid" class="<?php echo $merchantsubscriptioncatassigned_add->LeftColumnClass ?>"><?php echo $merchantsubscriptioncatassigned_add->categoryid->caption() ?><?php echo $merchantsubscriptioncatassigned_add->categoryid->Required ? $Language->phrase("FieldRequiredIndicator") : "" ?></label>
		<div class="<?php echo $merchantsubscriptioncatassigned_add->RightColumnClass ?>"><div <?php echo $merchantsubscriptioncatassigned_add->categoryid->cellAttributes() ?>>
<span id="el_merchantsubscriptioncatassigned_categoryid">
<input type="text" data-table="merchantsubscriptioncatassigned" data-field="x_categoryid" name="x_categoryid" id="x_categoryid" size="30" placeholder="<?php echo HtmlEncode($merchantsubscriptioncatassigned_add->categoryid->getPlaceHolder()) ?>" value="<?php echo $merchantsubscriptioncatassigned_add->categoryid->EditValue ?>"<?php echo $merchantsubscriptioncatassigned_add->categoryid->editAttributes() ?>>
</span>
<?php echo $merchantsubscriptioncatassigned_add->categoryid->CustomMsg ?></div></div>
	</div>
<?php } ?>
</div><!-- /page* -->
<?php if (!$merchantsubscriptioncatassigned_add->IsModal) { ?>
<div class="form-group row"><!-- buttons .form-group -->
	<div class="<?php echo $merchantsubscriptioncatassigned_add->OffsetColumnClass ?>"><!-- buttons offset -->
<button class="btn btn-primary ew-btn" name="btn-action" id="btn-action" type="submit"><?php echo $Language->phrase("AddBtn") ?></button>
<button class="btn btn-default ew-btn" name="btn-cancel" id="btn-cancel" type="button" data-href="<?php echo $merchantsubscriptioncatassigned_add->getReturnUrl() ?>"><?php echo $Language->phrase("CancelBtn") ?></button>
	</div><!-- /buttons offset -->
</div><!-- /buttons .form-group -->
<?php } ?>
</form>
<?php
$merchantsubscriptioncatassigned_add->showPageFooter();
if (Config("DEBUG"))
	echo GetDebugMessage();
?>
<script>
loadjs.ready("load", function() {

	// Startup script
	// Write your table-specific startup script here
	// console.log("page loaded");

});
</script>
<?php include_once "footer.php"; ?>
<?php
$merchantsubscriptioncatassigned_add->terminate();
?>