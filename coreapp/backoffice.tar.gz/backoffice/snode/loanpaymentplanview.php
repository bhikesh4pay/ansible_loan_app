<?php
namespace PHPMaker2020\_4payadmin;

// Autoload
include_once "autoload.php";

// Session
if (session_status() !== PHP_SESSION_ACTIVE)
	\Delight\Cookie\Session::start(Config("COOKIE_SAMESITE")); // Init session data

// Output buffering
ob_start();
?>
<?php

// Write header
WriteHeader(FALSE);

// Create page object
$loanpaymentplan_view = new loanpaymentplan_view();

// Run the page
$loanpaymentplan_view->run();

// Setup login status
SetupLoginStatus();
SetClientVar("login", LoginStatus());

// Global Page Rendering event (in userfn*.php)
Page_Rendering();

// Page Rendering event
$loanpaymentplan_view->Page_Render();
?>
<?php include_once "header.php"; ?>
<?php if (!$loanpaymentplan_view->isExport()) { ?>
<script>
var floanpaymentplanview, currentPageID;
loadjs.ready("head", function() {

	// Form object
	currentPageID = ew.PAGE_ID = "view";
	floanpaymentplanview = currentForm = new ew.Form("floanpaymentplanview", "view");
	loadjs.done("floanpaymentplanview");
});
</script>
<script>
loadjs.ready("head", function() {

	// Client script
	// Write your client script here, no need to add script tags.

});
</script>
<?php } ?>
<?php if (!$loanpaymentplan_view->isExport()) { ?>
<div class="btn-toolbar ew-toolbar">
<?php $loanpaymentplan_view->ExportOptions->render("body") ?>
<?php $loanpaymentplan_view->OtherOptions->render("body") ?>
<div class="clearfix"></div>
</div>
<?php } ?>
<?php $loanpaymentplan_view->showPageHeader(); ?>
<?php
$loanpaymentplan_view->showMessage();
?>
<form name="floanpaymentplanview" id="floanpaymentplanview" class="form-inline ew-form ew-view-form" action="<?php echo CurrentPageName() ?>" method="post">
<?php if ($Page->CheckToken) { ?>
<input type="hidden" name="<?php echo Config("TOKEN_NAME") ?>" value="<?php echo $Page->Token ?>">
<?php } ?>
<input type="hidden" name="t" value="loanpaymentplan">
<input type="hidden" name="modal" value="<?php echo (int)$loanpaymentplan_view->IsModal ?>">
<table class="table table-striped table-sm ew-view-table">
<?php if ($loanpaymentplan_view->paymentplanid->Visible) { // paymentplanid ?>
	<tr id="r_paymentplanid">
		<td class="<?php echo $loanpaymentplan_view->TableLeftColumnClass ?>"><span id="elh_loanpaymentplan_paymentplanid"><?php echo $loanpaymentplan_view->paymentplanid->caption() ?></span></td>
		<td data-name="paymentplanid" <?php echo $loanpaymentplan_view->paymentplanid->cellAttributes() ?>>
<span id="el_loanpaymentplan_paymentplanid">
<span<?php echo $loanpaymentplan_view->paymentplanid->viewAttributes() ?>><?php echo $loanpaymentplan_view->paymentplanid->getViewValue() ?></span>
</span>
</td>
	</tr>
<?php } ?>
<?php if ($loanpaymentplan_view->loanid->Visible) { // loanid ?>
	<tr id="r_loanid">
		<td class="<?php echo $loanpaymentplan_view->TableLeftColumnClass ?>"><span id="elh_loanpaymentplan_loanid"><?php echo $loanpaymentplan_view->loanid->caption() ?></span></td>
		<td data-name="loanid" <?php echo $loanpaymentplan_view->loanid->cellAttributes() ?>>
<span id="el_loanpaymentplan_loanid">
<span<?php echo $loanpaymentplan_view->loanid->viewAttributes() ?>><?php echo $loanpaymentplan_view->loanid->getViewValue() ?></span>
</span>
</td>
	</tr>
<?php } ?>
<?php if ($loanpaymentplan_view->termno->Visible) { // termno ?>
	<tr id="r_termno">
		<td class="<?php echo $loanpaymentplan_view->TableLeftColumnClass ?>"><span id="elh_loanpaymentplan_termno"><?php echo $loanpaymentplan_view->termno->caption() ?></span></td>
		<td data-name="termno" <?php echo $loanpaymentplan_view->termno->cellAttributes() ?>>
<span id="el_loanpaymentplan_termno">
<span<?php echo $loanpaymentplan_view->termno->viewAttributes() ?>><?php echo $loanpaymentplan_view->termno->getViewValue() ?></span>
</span>
</td>
	</tr>
<?php } ?>
<?php if ($loanpaymentplan_view->paymentduedate->Visible) { // paymentduedate ?>
	<tr id="r_paymentduedate">
		<td class="<?php echo $loanpaymentplan_view->TableLeftColumnClass ?>"><span id="elh_loanpaymentplan_paymentduedate"><?php echo $loanpaymentplan_view->paymentduedate->caption() ?></span></td>
		<td data-name="paymentduedate" <?php echo $loanpaymentplan_view->paymentduedate->cellAttributes() ?>>
<span id="el_loanpaymentplan_paymentduedate">
<span<?php echo $loanpaymentplan_view->paymentduedate->viewAttributes() ?>><?php echo $loanpaymentplan_view->paymentduedate->getViewValue() ?></span>
</span>
</td>
	</tr>
<?php } ?>
<?php if ($loanpaymentplan_view->outstandingprincipal->Visible) { // outstandingprincipal ?>
	<tr id="r_outstandingprincipal">
		<td class="<?php echo $loanpaymentplan_view->TableLeftColumnClass ?>"><span id="elh_loanpaymentplan_outstandingprincipal"><?php echo $loanpaymentplan_view->outstandingprincipal->caption() ?></span></td>
		<td data-name="outstandingprincipal" <?php echo $loanpaymentplan_view->outstandingprincipal->cellAttributes() ?>>
<span id="el_loanpaymentplan_outstandingprincipal">
<span<?php echo $loanpaymentplan_view->outstandingprincipal->viewAttributes() ?>><?php echo $loanpaymentplan_view->outstandingprincipal->getViewValue() ?></span>
</span>
</td>
	</tr>
<?php } ?>
<?php if ($loanpaymentplan_view->outsandinginterest->Visible) { // outsandinginterest ?>
	<tr id="r_outsandinginterest">
		<td class="<?php echo $loanpaymentplan_view->TableLeftColumnClass ?>"><span id="elh_loanpaymentplan_outsandinginterest"><?php echo $loanpaymentplan_view->outsandinginterest->caption() ?></span></td>
		<td data-name="outsandinginterest" <?php echo $loanpaymentplan_view->outsandinginterest->cellAttributes() ?>>
<span id="el_loanpaymentplan_outsandinginterest">
<span<?php echo $loanpaymentplan_view->outsandinginterest->viewAttributes() ?>><?php echo $loanpaymentplan_view->outsandinginterest->getViewValue() ?></span>
</span>
</td>
	</tr>
<?php } ?>
<?php if ($loanpaymentplan_view->paymentprincipal->Visible) { // paymentprincipal ?>
	<tr id="r_paymentprincipal">
		<td class="<?php echo $loanpaymentplan_view->TableLeftColumnClass ?>"><span id="elh_loanpaymentplan_paymentprincipal"><?php echo $loanpaymentplan_view->paymentprincipal->caption() ?></span></td>
		<td data-name="paymentprincipal" <?php echo $loanpaymentplan_view->paymentprincipal->cellAttributes() ?>>
<span id="el_loanpaymentplan_paymentprincipal">
<span<?php echo $loanpaymentplan_view->paymentprincipal->viewAttributes() ?>><?php echo $loanpaymentplan_view->paymentprincipal->getViewValue() ?></span>
</span>
</td>
	</tr>
<?php } ?>
<?php if ($loanpaymentplan_view->paymentinterest->Visible) { // paymentinterest ?>
	<tr id="r_paymentinterest">
		<td class="<?php echo $loanpaymentplan_view->TableLeftColumnClass ?>"><span id="elh_loanpaymentplan_paymentinterest"><?php echo $loanpaymentplan_view->paymentinterest->caption() ?></span></td>
		<td data-name="paymentinterest" <?php echo $loanpaymentplan_view->paymentinterest->cellAttributes() ?>>
<span id="el_loanpaymentplan_paymentinterest">
<span<?php echo $loanpaymentplan_view->paymentinterest->viewAttributes() ?>><?php echo $loanpaymentplan_view->paymentinterest->getViewValue() ?></span>
</span>
</td>
	</tr>
<?php } ?>
<?php if ($loanpaymentplan_view->paidprincipal->Visible) { // paidprincipal ?>
	<tr id="r_paidprincipal">
		<td class="<?php echo $loanpaymentplan_view->TableLeftColumnClass ?>"><span id="elh_loanpaymentplan_paidprincipal"><?php echo $loanpaymentplan_view->paidprincipal->caption() ?></span></td>
		<td data-name="paidprincipal" <?php echo $loanpaymentplan_view->paidprincipal->cellAttributes() ?>>
<span id="el_loanpaymentplan_paidprincipal">
<span<?php echo $loanpaymentplan_view->paidprincipal->viewAttributes() ?>><?php echo $loanpaymentplan_view->paidprincipal->getViewValue() ?></span>
</span>
</td>
	</tr>
<?php } ?>
<?php if ($loanpaymentplan_view->paidinterest->Visible) { // paidinterest ?>
	<tr id="r_paidinterest">
		<td class="<?php echo $loanpaymentplan_view->TableLeftColumnClass ?>"><span id="elh_loanpaymentplan_paidinterest"><?php echo $loanpaymentplan_view->paidinterest->caption() ?></span></td>
		<td data-name="paidinterest" <?php echo $loanpaymentplan_view->paidinterest->cellAttributes() ?>>
<span id="el_loanpaymentplan_paidinterest">
<span<?php echo $loanpaymentplan_view->paidinterest->viewAttributes() ?>><?php echo $loanpaymentplan_view->paidinterest->getViewValue() ?></span>
</span>
</td>
	</tr>
<?php } ?>
<?php if ($loanpaymentplan_view->status->Visible) { // status ?>
	<tr id="r_status">
		<td class="<?php echo $loanpaymentplan_view->TableLeftColumnClass ?>"><span id="elh_loanpaymentplan_status"><?php echo $loanpaymentplan_view->status->caption() ?></span></td>
		<td data-name="status" <?php echo $loanpaymentplan_view->status->cellAttributes() ?>>
<span id="el_loanpaymentplan_status">
<span<?php echo $loanpaymentplan_view->status->viewAttributes() ?>><?php echo $loanpaymentplan_view->status->getViewValue() ?></span>
</span>
</td>
	</tr>
<?php } ?>
</table>
</form>
<?php
$loanpaymentplan_view->showPageFooter();
if (Config("DEBUG"))
	echo GetDebugMessage();
?>
<?php if (!$loanpaymentplan_view->isExport()) { ?>
<script>
loadjs.ready("load", function() {

	// Startup script
	// Write your table-specific startup script here
	// console.log("page loaded");

});
</script>
<?php } ?>
<?php include_once "footer.php"; ?>
<?php
$loanpaymentplan_view->terminate();
?>