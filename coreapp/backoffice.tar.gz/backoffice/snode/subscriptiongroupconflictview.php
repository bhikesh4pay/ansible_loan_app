<?php
namespace PHPMaker2020\_4payadmin;

// Autoload
include_once "autoload.php";

// Session
if (session_status() !== PHP_SESSION_ACTIVE)
	\Delight\Cookie\Session::start(Config("COOKIE_SAMESITE")); // Init session data

// Output buffering
ob_start();
?>
<?php

// Write header
WriteHeader(FALSE);

// Create page object
$subscriptiongroupconflict_view = new subscriptiongroupconflict_view();

// Run the page
$subscriptiongroupconflict_view->run();

// Setup login status
SetupLoginStatus();
SetClientVar("login", LoginStatus());

// Global Page Rendering event (in userfn*.php)
Page_Rendering();

// Page Rendering event
$subscriptiongroupconflict_view->Page_Render();
?>
<?php include_once "header.php"; ?>
<?php if (!$subscriptiongroupconflict_view->isExport()) { ?>
<script>
var fsubscriptiongroupconflictview, currentPageID;
loadjs.ready("head", function() {

	// Form object
	currentPageID = ew.PAGE_ID = "view";
	fsubscriptiongroupconflictview = currentForm = new ew.Form("fsubscriptiongroupconflictview", "view");
	loadjs.done("fsubscriptiongroupconflictview");
});
</script>
<script>
loadjs.ready("head", function() {

	// Client script
	// Write your client script here, no need to add script tags.

});
</script>
<?php } ?>
<?php if (!$subscriptiongroupconflict_view->isExport()) { ?>
<div class="btn-toolbar ew-toolbar">
<?php $subscriptiongroupconflict_view->ExportOptions->render("body") ?>
<?php $subscriptiongroupconflict_view->OtherOptions->render("body") ?>
<div class="clearfix"></div>
</div>
<?php } ?>
<?php $subscriptiongroupconflict_view->showPageHeader(); ?>
<?php
$subscriptiongroupconflict_view->showMessage();
?>
<form name="fsubscriptiongroupconflictview" id="fsubscriptiongroupconflictview" class="form-inline ew-form ew-view-form" action="<?php echo CurrentPageName() ?>" method="post">
<?php if ($Page->CheckToken) { ?>
<input type="hidden" name="<?php echo Config("TOKEN_NAME") ?>" value="<?php echo $Page->Token ?>">
<?php } ?>
<input type="hidden" name="t" value="subscriptiongroupconflict">
<input type="hidden" name="modal" value="<?php echo (int)$subscriptiongroupconflict_view->IsModal ?>">
<table class="table table-striped table-sm ew-view-table">
<?php if ($subscriptiongroupconflict_view->subscriptionid->Visible) { // subscriptionid ?>
	<tr id="r_subscriptionid">
		<td class="<?php echo $subscriptiongroupconflict_view->TableLeftColumnClass ?>"><span id="elh_subscriptiongroupconflict_subscriptionid"><?php echo $subscriptiongroupconflict_view->subscriptionid->caption() ?></span></td>
		<td data-name="subscriptionid" <?php echo $subscriptiongroupconflict_view->subscriptionid->cellAttributes() ?>>
<span id="el_subscriptiongroupconflict_subscriptionid">
<span<?php echo $subscriptiongroupconflict_view->subscriptionid->viewAttributes() ?>><?php echo $subscriptiongroupconflict_view->subscriptionid->getViewValue() ?></span>
</span>
</td>
	</tr>
<?php } ?>
<?php if ($subscriptiongroupconflict_view->categoryid->Visible) { // categoryid ?>
	<tr id="r_categoryid">
		<td class="<?php echo $subscriptiongroupconflict_view->TableLeftColumnClass ?>"><span id="elh_subscriptiongroupconflict_categoryid"><?php echo $subscriptiongroupconflict_view->categoryid->caption() ?></span></td>
		<td data-name="categoryid" <?php echo $subscriptiongroupconflict_view->categoryid->cellAttributes() ?>>
<span id="el_subscriptiongroupconflict_categoryid">
<span<?php echo $subscriptiongroupconflict_view->categoryid->viewAttributes() ?>><?php echo $subscriptiongroupconflict_view->categoryid->getViewValue() ?></span>
</span>
</td>
	</tr>
<?php } ?>
<?php if ($subscriptiongroupconflict_view->active->Visible) { // active ?>
	<tr id="r_active">
		<td class="<?php echo $subscriptiongroupconflict_view->TableLeftColumnClass ?>"><span id="elh_subscriptiongroupconflict_active"><?php echo $subscriptiongroupconflict_view->active->caption() ?></span></td>
		<td data-name="active" <?php echo $subscriptiongroupconflict_view->active->cellAttributes() ?>>
<span id="el_subscriptiongroupconflict_active">
<span<?php echo $subscriptiongroupconflict_view->active->viewAttributes() ?>><?php echo $subscriptiongroupconflict_view->active->getViewValue() ?></span>
</span>
</td>
	</tr>
<?php } ?>
</table>
</form>
<?php
$subscriptiongroupconflict_view->showPageFooter();
if (Config("DEBUG"))
	echo GetDebugMessage();
?>
<?php if (!$subscriptiongroupconflict_view->isExport()) { ?>
<script>
loadjs.ready("load", function() {

	// Startup script
	// Write your table-specific startup script here
	// console.log("page loaded");

});
</script>
<?php } ?>
<?php include_once "footer.php"; ?>
<?php
$subscriptiongroupconflict_view->terminate();
?>