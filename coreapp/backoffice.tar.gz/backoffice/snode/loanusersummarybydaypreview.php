<?php
namespace PHPMaker2020\_4payadmin;

// Autoload
include_once "autoload.php";

// Session
if (session_status() !== PHP_SESSION_ACTIVE)
	\Delight\Cookie\Session::start(Config("COOKIE_SAMESITE")); // Init session data

// Output buffering
ob_start();
?>
<?php

// Write header
WriteHeader(FALSE, "utf-8");

// Create page object
$loanusersummarybyday_preview = new loanusersummarybyday_preview();

// Run the page
$loanusersummarybyday_preview->run();

// Setup login status
SetupLoginStatus();
SetClientVar("login", LoginStatus());

// Global Page Rendering event (in userfn*.php)
Page_Rendering();

// Page Rendering event
$loanusersummarybyday_preview->Page_Render();
?>
<?php $loanusersummarybyday_preview->showPageHeader(); ?>
<?php if ($loanusersummarybyday_preview->TotalRecords > 0) { ?>
<div class="card ew-grid loanusersummarybyday"><!-- .card -->
<div class="<?php echo ResponsiveTableClass() ?>card-body ew-grid-middle-panel ew-preview-middle-panel"><!-- .table-responsive -->
<table class="table ew-table ew-preview-table"><!-- .table -->
	<thead><!-- Table header -->
		<tr class="ew-table-header">
<?php

// Render list options
$loanusersummarybyday_preview->renderListOptions();

// Render list options (header, left)
$loanusersummarybyday_preview->ListOptions->render("header", "left");
?>
<?php if ($loanusersummarybyday_preview->_userid->Visible) { // userid ?>
	<?php if ($loanusersummarybyday->SortUrl($loanusersummarybyday_preview->_userid) == "") { ?>
		<th class="<?php echo $loanusersummarybyday_preview->_userid->headerCellClass() ?>"><?php echo $loanusersummarybyday_preview->_userid->caption() ?></th>
	<?php } else { ?>
		<th class="<?php echo $loanusersummarybyday_preview->_userid->headerCellClass() ?>"><div class="ew-pointer" data-sort="<?php echo HtmlEncode($loanusersummarybyday_preview->_userid->Name) ?>" data-sort-order="<?php echo $loanusersummarybyday_preview->SortField == $loanusersummarybyday_preview->_userid->Name && $loanusersummarybyday_preview->SortOrder == "ASC" ? "DESC" : "ASC" ?>">
			<div class="ew-table-header-btn"><span class="ew-table-header-caption"><?php echo $loanusersummarybyday_preview->_userid->caption() ?></span><span class="ew-table-header-sort"><?php if ($loanusersummarybyday_preview->SortField == $loanusersummarybyday_preview->_userid->Name) { ?><?php if ($loanusersummarybyday_preview->SortOrder == "ASC") { ?><i class="fas fa-sort-up"></i><?php } elseif ($loanusersummarybyday_preview->SortOrder == "DESC") { ?><i class="fas fa-sort-down"></i><?php } ?><?php } ?></span>
		</div></div></th>
	<?php } ?>
<?php } ?>
<?php if ($loanusersummarybyday_preview->currcode->Visible) { // currcode ?>
	<?php if ($loanusersummarybyday->SortUrl($loanusersummarybyday_preview->currcode) == "") { ?>
		<th class="<?php echo $loanusersummarybyday_preview->currcode->headerCellClass() ?>"><?php echo $loanusersummarybyday_preview->currcode->caption() ?></th>
	<?php } else { ?>
		<th class="<?php echo $loanusersummarybyday_preview->currcode->headerCellClass() ?>"><div class="ew-pointer" data-sort="<?php echo HtmlEncode($loanusersummarybyday_preview->currcode->Name) ?>" data-sort-order="<?php echo $loanusersummarybyday_preview->SortField == $loanusersummarybyday_preview->currcode->Name && $loanusersummarybyday_preview->SortOrder == "ASC" ? "DESC" : "ASC" ?>">
			<div class="ew-table-header-btn"><span class="ew-table-header-caption"><?php echo $loanusersummarybyday_preview->currcode->caption() ?></span><span class="ew-table-header-sort"><?php if ($loanusersummarybyday_preview->SortField == $loanusersummarybyday_preview->currcode->Name) { ?><?php if ($loanusersummarybyday_preview->SortOrder == "ASC") { ?><i class="fas fa-sort-up"></i><?php } elseif ($loanusersummarybyday_preview->SortOrder == "DESC") { ?><i class="fas fa-sort-down"></i><?php } ?><?php } ?></span>
		</div></div></th>
	<?php } ?>
<?php } ?>
<?php if ($loanusersummarybyday_preview->loandate->Visible) { // loandate ?>
	<?php if ($loanusersummarybyday->SortUrl($loanusersummarybyday_preview->loandate) == "") { ?>
		<th class="<?php echo $loanusersummarybyday_preview->loandate->headerCellClass() ?>"><?php echo $loanusersummarybyday_preview->loandate->caption() ?></th>
	<?php } else { ?>
		<th class="<?php echo $loanusersummarybyday_preview->loandate->headerCellClass() ?>"><div class="ew-pointer" data-sort="<?php echo HtmlEncode($loanusersummarybyday_preview->loandate->Name) ?>" data-sort-order="<?php echo $loanusersummarybyday_preview->SortField == $loanusersummarybyday_preview->loandate->Name && $loanusersummarybyday_preview->SortOrder == "ASC" ? "DESC" : "ASC" ?>">
			<div class="ew-table-header-btn"><span class="ew-table-header-caption"><?php echo $loanusersummarybyday_preview->loandate->caption() ?></span><span class="ew-table-header-sort"><?php if ($loanusersummarybyday_preview->SortField == $loanusersummarybyday_preview->loandate->Name) { ?><?php if ($loanusersummarybyday_preview->SortOrder == "ASC") { ?><i class="fas fa-sort-up"></i><?php } elseif ($loanusersummarybyday_preview->SortOrder == "DESC") { ?><i class="fas fa-sort-down"></i><?php } ?><?php } ?></span>
		</div></div></th>
	<?php } ?>
<?php } ?>
<?php if ($loanusersummarybyday_preview->amount->Visible) { // amount ?>
	<?php if ($loanusersummarybyday->SortUrl($loanusersummarybyday_preview->amount) == "") { ?>
		<th class="<?php echo $loanusersummarybyday_preview->amount->headerCellClass() ?>"><?php echo $loanusersummarybyday_preview->amount->caption() ?></th>
	<?php } else { ?>
		<th class="<?php echo $loanusersummarybyday_preview->amount->headerCellClass() ?>"><div class="ew-pointer" data-sort="<?php echo HtmlEncode($loanusersummarybyday_preview->amount->Name) ?>" data-sort-order="<?php echo $loanusersummarybyday_preview->SortField == $loanusersummarybyday_preview->amount->Name && $loanusersummarybyday_preview->SortOrder == "ASC" ? "DESC" : "ASC" ?>">
			<div class="ew-table-header-btn"><span class="ew-table-header-caption"><?php echo $loanusersummarybyday_preview->amount->caption() ?></span><span class="ew-table-header-sort"><?php if ($loanusersummarybyday_preview->SortField == $loanusersummarybyday_preview->amount->Name) { ?><?php if ($loanusersummarybyday_preview->SortOrder == "ASC") { ?><i class="fas fa-sort-up"></i><?php } elseif ($loanusersummarybyday_preview->SortOrder == "DESC") { ?><i class="fas fa-sort-down"></i><?php } ?><?php } ?></span>
		</div></div></th>
	<?php } ?>
<?php } ?>
<?php

// Render list options (header, right)
$loanusersummarybyday_preview->ListOptions->render("header", "right");
?>
		</tr>
	</thead>
	<tbody><!-- Table body -->
<?php
$loanusersummarybyday_preview->RecCount = 0;
$loanusersummarybyday_preview->RowCount = 0;
while ($loanusersummarybyday_preview->Recordset && !$loanusersummarybyday_preview->Recordset->EOF) {

	// Init row class and style
	$loanusersummarybyday_preview->RecCount++;
	$loanusersummarybyday_preview->RowCount++;
	$loanusersummarybyday_preview->CssStyle = "";
	$loanusersummarybyday_preview->loadListRowValues($loanusersummarybyday_preview->Recordset);

	// Render row
	$loanusersummarybyday->RowType = ROWTYPE_PREVIEW; // Preview record
	$loanusersummarybyday_preview->resetAttributes();
	$loanusersummarybyday_preview->renderListRow();

	// Render list options
	$loanusersummarybyday_preview->renderListOptions();
?>
	<tr <?php echo $loanusersummarybyday->rowAttributes() ?>>
<?php

// Render list options (body, left)
$loanusersummarybyday_preview->ListOptions->render("body", "left", $loanusersummarybyday_preview->RowCount);
?>
<?php if ($loanusersummarybyday_preview->_userid->Visible) { // userid ?>
		<!-- userid -->
		<td<?php echo $loanusersummarybyday_preview->_userid->cellAttributes() ?>>
<span<?php echo $loanusersummarybyday_preview->_userid->viewAttributes() ?>><?php echo $loanusersummarybyday_preview->_userid->getViewValue() ?></span>
</td>
<?php } ?>
<?php if ($loanusersummarybyday_preview->currcode->Visible) { // currcode ?>
		<!-- currcode -->
		<td<?php echo $loanusersummarybyday_preview->currcode->cellAttributes() ?>>
<span<?php echo $loanusersummarybyday_preview->currcode->viewAttributes() ?>><?php echo $loanusersummarybyday_preview->currcode->getViewValue() ?></span>
</td>
<?php } ?>
<?php if ($loanusersummarybyday_preview->loandate->Visible) { // loandate ?>
		<!-- loandate -->
		<td<?php echo $loanusersummarybyday_preview->loandate->cellAttributes() ?>>
<span<?php echo $loanusersummarybyday_preview->loandate->viewAttributes() ?>><?php echo $loanusersummarybyday_preview->loandate->getViewValue() ?></span>
</td>
<?php } ?>
<?php if ($loanusersummarybyday_preview->amount->Visible) { // amount ?>
		<!-- amount -->
		<td<?php echo $loanusersummarybyday_preview->amount->cellAttributes() ?>>
<span<?php echo $loanusersummarybyday_preview->amount->viewAttributes() ?>><?php echo $loanusersummarybyday_preview->amount->getViewValue() ?></span>
</td>
<?php } ?>
<?php

// Render list options (body, right)
$loanusersummarybyday_preview->ListOptions->render("body", "right", $loanusersummarybyday_preview->RowCount);
?>
	</tr>
<?php
	$loanusersummarybyday_preview->Recordset->MoveNext();
} // while
?>
	</tbody>
</table><!-- /.table -->
</div><!-- /.table-responsive -->
<div class="card-footer ew-grid-lower-panel ew-preview-lower-panel"><!-- .card-footer -->
<?php echo $loanusersummarybyday_preview->Pager->render() ?>
<?php } else { // No record ?>
<div class="card no-border">
<div class="ew-detail-count"><?php echo $Language->phrase("NoRecord") ?></div>
<?php } ?>
<div class="ew-preview-other-options">
<?php
	foreach ($loanusersummarybyday_preview->OtherOptions as $option)
		$option->render("body");
?>
</div>
<?php if ($loanusersummarybyday_preview->TotalRecords > 0) { ?>
<div class="clearfix"></div>
</div><!-- /.card-footer -->
<?php } ?>
</div><!-- /.card -->
<?php
$loanusersummarybyday_preview->showPageFooter();
if (Config("DEBUG"))
	echo GetDebugMessage();
?>
<?php
if ($loanusersummarybyday_preview->Recordset)
	$loanusersummarybyday_preview->Recordset->Close();

// Output
$content = ob_get_contents();
ob_end_clean();
echo ConvertToUtf8($content);
?>
<?php
$loanusersummarybyday_preview->terminate();
?>