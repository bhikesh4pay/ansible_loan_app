<?php
namespace PHPMaker2020\_4payadmin;

// Autoload
include_once "autoload.php";

// Session
if (session_status() !== PHP_SESSION_ACTIVE)
	\Delight\Cookie\Session::start(Config("COOKIE_SAMESITE")); // Init session data

// Output buffering
ob_start();
?>
<?php

// Write header
WriteHeader(FALSE);

// Create page object
$userdevices_edit = new userdevices_edit();

// Run the page
$userdevices_edit->run();

// Setup login status
SetupLoginStatus();
SetClientVar("login", LoginStatus());

// Global Page Rendering event (in userfn*.php)
Page_Rendering();

// Page Rendering event
$userdevices_edit->Page_Render();
?>
<?php include_once "header.php"; ?>
<script>
var fuserdevicesedit, currentPageID;
loadjs.ready("head", function() {

	// Form object
	currentPageID = ew.PAGE_ID = "edit";
	fuserdevicesedit = currentForm = new ew.Form("fuserdevicesedit", "edit");

	// Validate form
	fuserdevicesedit.validate = function() {
		if (!this.validateRequired)
			return true; // Ignore validation
		var $ = jQuery, fobj = this.getForm(), $fobj = $(fobj);
		if ($fobj.find("#confirm").val() == "confirm")
			return true;
		var elm, felm, uelm, addcnt = 0;
		var $k = $fobj.find("#" + this.formKeyCountName); // Get key_count
		var rowcnt = ($k[0]) ? parseInt($k.val(), 10) : 1;
		var startcnt = (rowcnt == 0) ? 0 : 1; // Check rowcnt == 0 => Inline-Add
		var gridinsert = ["insert", "gridinsert"].includes($fobj.find("#action").val()) && $k[0];
		for (var i = startcnt; i <= rowcnt; i++) {
			var infix = ($k[0]) ? String(i) : "";
			$fobj.data("rowindex", infix);
			<?php if ($userdevices_edit->id->Required) { ?>
				elm = this.getElements("x" + infix + "_id");
				if (elm && !ew.isHidden(elm) && !ew.hasValue(elm))
					return this.onError(elm, "<?php echo JsEncode(str_replace("%s", $userdevices_edit->id->caption(), $userdevices_edit->id->RequiredErrorMessage)) ?>");
			<?php } ?>
			<?php if ($userdevices_edit->deviceid->Required) { ?>
				elm = this.getElements("x" + infix + "_deviceid");
				if (elm && !ew.isHidden(elm) && !ew.hasValue(elm))
					return this.onError(elm, "<?php echo JsEncode(str_replace("%s", $userdevices_edit->deviceid->caption(), $userdevices_edit->deviceid->RequiredErrorMessage)) ?>");
			<?php } ?>
			<?php if ($userdevices_edit->_userid->Required) { ?>
				elm = this.getElements("x" + infix + "__userid");
				if (elm && !ew.isHidden(elm) && !ew.hasValue(elm))
					return this.onError(elm, "<?php echo JsEncode(str_replace("%s", $userdevices_edit->_userid->caption(), $userdevices_edit->_userid->RequiredErrorMessage)) ?>");
			<?php } ?>
				elm = this.getElements("x" + infix + "__userid");
				if (elm && !ew.checkInteger(elm.value))
					return this.onError(elm, "<?php echo JsEncode($userdevices_edit->_userid->errorMessage()) ?>");
			<?php if ($userdevices_edit->devicetoken->Required) { ?>
				elm = this.getElements("x" + infix + "_devicetoken");
				if (elm && !ew.isHidden(elm) && !ew.hasValue(elm))
					return this.onError(elm, "<?php echo JsEncode(str_replace("%s", $userdevices_edit->devicetoken->caption(), $userdevices_edit->devicetoken->RequiredErrorMessage)) ?>");
			<?php } ?>
			<?php if ($userdevices_edit->devicetype->Required) { ?>
				elm = this.getElements("x" + infix + "_devicetype");
				if (elm && !ew.isHidden(elm) && !ew.hasValue(elm))
					return this.onError(elm, "<?php echo JsEncode(str_replace("%s", $userdevices_edit->devicetype->caption(), $userdevices_edit->devicetype->RequiredErrorMessage)) ?>");
			<?php } ?>
			<?php if ($userdevices_edit->franchiseeid->Required) { ?>
				elm = this.getElements("x" + infix + "_franchiseeid");
				if (elm && !ew.isHidden(elm) && !ew.hasValue(elm))
					return this.onError(elm, "<?php echo JsEncode(str_replace("%s", $userdevices_edit->franchiseeid->caption(), $userdevices_edit->franchiseeid->RequiredErrorMessage)) ?>");
			<?php } ?>
				elm = this.getElements("x" + infix + "_franchiseeid");
				if (elm && !ew.checkInteger(elm.value))
					return this.onError(elm, "<?php echo JsEncode($userdevices_edit->franchiseeid->errorMessage()) ?>");
			<?php if ($userdevices_edit->active->Required) { ?>
				elm = this.getElements("x" + infix + "_active");
				if (elm && !ew.isHidden(elm) && !ew.hasValue(elm))
					return this.onError(elm, "<?php echo JsEncode(str_replace("%s", $userdevices_edit->active->caption(), $userdevices_edit->active->RequiredErrorMessage)) ?>");
			<?php } ?>
			<?php if ($userdevices_edit->enrolledtime->Required) { ?>
				elm = this.getElements("x" + infix + "_enrolledtime");
				if (elm && !ew.isHidden(elm) && !ew.hasValue(elm))
					return this.onError(elm, "<?php echo JsEncode(str_replace("%s", $userdevices_edit->enrolledtime->caption(), $userdevices_edit->enrolledtime->RequiredErrorMessage)) ?>");
			<?php } ?>
				elm = this.getElements("x" + infix + "_enrolledtime");
				if (elm && !ew.checkDateDef(elm.value))
					return this.onError(elm, "<?php echo JsEncode($userdevices_edit->enrolledtime->errorMessage()) ?>");
			<?php if ($userdevices_edit->lastlogin->Required) { ?>
				elm = this.getElements("x" + infix + "_lastlogin");
				if (elm && !ew.isHidden(elm) && !ew.hasValue(elm))
					return this.onError(elm, "<?php echo JsEncode(str_replace("%s", $userdevices_edit->lastlogin->caption(), $userdevices_edit->lastlogin->RequiredErrorMessage)) ?>");
			<?php } ?>
				elm = this.getElements("x" + infix + "_lastlogin");
				if (elm && !ew.checkDateDef(elm.value))
					return this.onError(elm, "<?php echo JsEncode($userdevices_edit->lastlogin->errorMessage()) ?>");

				// Call Form_CustomValidate event
				if (!this.Form_CustomValidate(fobj))
					return false;
		}

		// Process detail forms
		var dfs = $fobj.find("input[name='detailpage']").get();
		for (var i = 0; i < dfs.length; i++) {
			var df = dfs[i], val = df.value;
			if (val && ew.forms[val])
				if (!ew.forms[val].validate())
					return false;
		}
		return true;
	}

	// Form_CustomValidate
	fuserdevicesedit.Form_CustomValidate = function(fobj) { // DO NOT CHANGE THIS LINE!

		// Your custom validation code here, return false if invalid.
		return true;
	}

	// Use JavaScript validation or not
	fuserdevicesedit.validateRequired = <?php echo Config("CLIENT_VALIDATE") ? "true" : "false" ?>;

	// Dynamic selection lists
	fuserdevicesedit.lists["x_active"] = <?php echo $userdevices_edit->active->Lookup->toClientList($userdevices_edit) ?>;
	fuserdevicesedit.lists["x_active"].options = <?php echo JsonEncode($userdevices_edit->active->lookupOptions()) ?>;
	loadjs.done("fuserdevicesedit");
});
</script>
<script>
loadjs.ready("head", function() {

	// Client script
	// Write your client script here, no need to add script tags.

});
</script>
<?php $userdevices_edit->showPageHeader(); ?>
<?php
$userdevices_edit->showMessage();
?>
<form name="fuserdevicesedit" id="fuserdevicesedit" class="<?php echo $userdevices_edit->FormClassName ?>" action="<?php echo CurrentPageName() ?>" method="post">
<?php if ($Page->CheckToken) { ?>
<input type="hidden" name="<?php echo Config("TOKEN_NAME") ?>" value="<?php echo $Page->Token ?>">
<?php } ?>
<input type="hidden" name="t" value="userdevices">
<input type="hidden" name="action" id="action" value="update">
<input type="hidden" name="modal" value="<?php echo (int)$userdevices_edit->IsModal ?>">
<?php if ($userdevices->getCurrentMasterTable() == "user") { ?>
<input type="hidden" name="<?php echo Config("TABLE_SHOW_MASTER") ?>" value="user">
<input type="hidden" name="fk_id" value="<?php echo HtmlEncode($userdevices_edit->_userid->getSessionValue()) ?>">
<?php } ?>
<div class="ew-edit-div"><!-- page* -->
<?php if ($userdevices_edit->id->Visible) { // id ?>
	<div id="r_id" class="form-group row">
		<label id="elh_userdevices_id" class="<?php echo $userdevices_edit->LeftColumnClass ?>"><?php echo $userdevices_edit->id->caption() ?><?php echo $userdevices_edit->id->Required ? $Language->phrase("FieldRequiredIndicator") : "" ?></label>
		<div class="<?php echo $userdevices_edit->RightColumnClass ?>"><div <?php echo $userdevices_edit->id->cellAttributes() ?>>
<span id="el_userdevices_id">
<span<?php echo $userdevices_edit->id->viewAttributes() ?>><input type="text" readonly class="form-control-plaintext" value="<?php echo HtmlEncode(RemoveHtml($userdevices_edit->id->EditValue)) ?>"></span>
</span>
<input type="hidden" data-table="userdevices" data-field="x_id" name="x_id" id="x_id" value="<?php echo HtmlEncode($userdevices_edit->id->CurrentValue) ?>">
<?php echo $userdevices_edit->id->CustomMsg ?></div></div>
	</div>
<?php } ?>
<?php if ($userdevices_edit->deviceid->Visible) { // deviceid ?>
	<div id="r_deviceid" class="form-group row">
		<label id="elh_userdevices_deviceid" for="x_deviceid" class="<?php echo $userdevices_edit->LeftColumnClass ?>"><?php echo $userdevices_edit->deviceid->caption() ?><?php echo $userdevices_edit->deviceid->Required ? $Language->phrase("FieldRequiredIndicator") : "" ?></label>
		<div class="<?php echo $userdevices_edit->RightColumnClass ?>"><div <?php echo $userdevices_edit->deviceid->cellAttributes() ?>>
<span id="el_userdevices_deviceid">
<input type="text" data-table="userdevices" data-field="x_deviceid" name="x_deviceid" id="x_deviceid" size="30" maxlength="255" placeholder="<?php echo HtmlEncode($userdevices_edit->deviceid->getPlaceHolder()) ?>" value="<?php echo $userdevices_edit->deviceid->EditValue ?>"<?php echo $userdevices_edit->deviceid->editAttributes() ?>>
</span>
<?php echo $userdevices_edit->deviceid->CustomMsg ?></div></div>
	</div>
<?php } ?>
<?php if ($userdevices_edit->_userid->Visible) { // userid ?>
	<div id="r__userid" class="form-group row">
		<label id="elh_userdevices__userid" for="x__userid" class="<?php echo $userdevices_edit->LeftColumnClass ?>"><?php echo $userdevices_edit->_userid->caption() ?><?php echo $userdevices_edit->_userid->Required ? $Language->phrase("FieldRequiredIndicator") : "" ?></label>
		<div class="<?php echo $userdevices_edit->RightColumnClass ?>"><div <?php echo $userdevices_edit->_userid->cellAttributes() ?>>
<?php if ($userdevices_edit->_userid->getSessionValue() != "") { ?>
<span id="el_userdevices__userid">
<span<?php echo $userdevices_edit->_userid->viewAttributes() ?>><input type="text" readonly class="form-control-plaintext" value="<?php echo HtmlEncode(RemoveHtml($userdevices_edit->_userid->ViewValue)) ?>"></span>
</span>
<input type="hidden" id="x__userid" name="x__userid" value="<?php echo HtmlEncode($userdevices_edit->_userid->CurrentValue) ?>">
<?php } else { ?>
<span id="el_userdevices__userid">
<input type="text" data-table="userdevices" data-field="x__userid" name="x__userid" id="x__userid" size="30" maxlength="12" placeholder="<?php echo HtmlEncode($userdevices_edit->_userid->getPlaceHolder()) ?>" value="<?php echo $userdevices_edit->_userid->EditValue ?>"<?php echo $userdevices_edit->_userid->editAttributes() ?>>
</span>
<?php } ?>
<?php echo $userdevices_edit->_userid->CustomMsg ?></div></div>
	</div>
<?php } ?>
<?php if ($userdevices_edit->devicetoken->Visible) { // devicetoken ?>
	<div id="r_devicetoken" class="form-group row">
		<label id="elh_userdevices_devicetoken" for="x_devicetoken" class="<?php echo $userdevices_edit->LeftColumnClass ?>"><?php echo $userdevices_edit->devicetoken->caption() ?><?php echo $userdevices_edit->devicetoken->Required ? $Language->phrase("FieldRequiredIndicator") : "" ?></label>
		<div class="<?php echo $userdevices_edit->RightColumnClass ?>"><div <?php echo $userdevices_edit->devicetoken->cellAttributes() ?>>
<span id="el_userdevices_devicetoken">
<input type="text" data-table="userdevices" data-field="x_devicetoken" name="x_devicetoken" id="x_devicetoken" size="30" maxlength="255" placeholder="<?php echo HtmlEncode($userdevices_edit->devicetoken->getPlaceHolder()) ?>" value="<?php echo $userdevices_edit->devicetoken->EditValue ?>"<?php echo $userdevices_edit->devicetoken->editAttributes() ?>>
</span>
<?php echo $userdevices_edit->devicetoken->CustomMsg ?></div></div>
	</div>
<?php } ?>
<?php if ($userdevices_edit->devicetype->Visible) { // devicetype ?>
	<div id="r_devicetype" class="form-group row">
		<label id="elh_userdevices_devicetype" for="x_devicetype" class="<?php echo $userdevices_edit->LeftColumnClass ?>"><?php echo $userdevices_edit->devicetype->caption() ?><?php echo $userdevices_edit->devicetype->Required ? $Language->phrase("FieldRequiredIndicator") : "" ?></label>
		<div class="<?php echo $userdevices_edit->RightColumnClass ?>"><div <?php echo $userdevices_edit->devicetype->cellAttributes() ?>>
<span id="el_userdevices_devicetype">
<input type="text" data-table="userdevices" data-field="x_devicetype" name="x_devicetype" id="x_devicetype" size="30" maxlength="50" placeholder="<?php echo HtmlEncode($userdevices_edit->devicetype->getPlaceHolder()) ?>" value="<?php echo $userdevices_edit->devicetype->EditValue ?>"<?php echo $userdevices_edit->devicetype->editAttributes() ?>>
</span>
<?php echo $userdevices_edit->devicetype->CustomMsg ?></div></div>
	</div>
<?php } ?>
<?php if ($userdevices_edit->franchiseeid->Visible) { // franchiseeid ?>
	<div id="r_franchiseeid" class="form-group row">
		<label id="elh_userdevices_franchiseeid" for="x_franchiseeid" class="<?php echo $userdevices_edit->LeftColumnClass ?>"><?php echo $userdevices_edit->franchiseeid->caption() ?><?php echo $userdevices_edit->franchiseeid->Required ? $Language->phrase("FieldRequiredIndicator") : "" ?></label>
		<div class="<?php echo $userdevices_edit->RightColumnClass ?>"><div <?php echo $userdevices_edit->franchiseeid->cellAttributes() ?>>
<span id="el_userdevices_franchiseeid">
<input type="text" data-table="userdevices" data-field="x_franchiseeid" name="x_franchiseeid" id="x_franchiseeid" size="30" maxlength="3" placeholder="<?php echo HtmlEncode($userdevices_edit->franchiseeid->getPlaceHolder()) ?>" value="<?php echo $userdevices_edit->franchiseeid->EditValue ?>"<?php echo $userdevices_edit->franchiseeid->editAttributes() ?>>
</span>
<?php echo $userdevices_edit->franchiseeid->CustomMsg ?></div></div>
	</div>
<?php } ?>
<?php if ($userdevices_edit->active->Visible) { // active ?>
	<div id="r_active" class="form-group row">
		<label id="elh_userdevices_active" class="<?php echo $userdevices_edit->LeftColumnClass ?>"><?php echo $userdevices_edit->active->caption() ?><?php echo $userdevices_edit->active->Required ? $Language->phrase("FieldRequiredIndicator") : "" ?></label>
		<div class="<?php echo $userdevices_edit->RightColumnClass ?>"><div <?php echo $userdevices_edit->active->cellAttributes() ?>>
<span id="el_userdevices_active">
<div id="tp_x_active" class="ew-template"><input type="radio" class="custom-control-input" data-table="userdevices" data-field="x_active" data-value-separator="<?php echo $userdevices_edit->active->displayValueSeparatorAttribute() ?>" name="x_active" id="x_active" value="{value}"<?php echo $userdevices_edit->active->editAttributes() ?>></div>
<div id="dsl_x_active" data-repeatcolumn="5" class="ew-item-list d-none"><div>
<?php echo $userdevices_edit->active->radioButtonListHtml(FALSE, "x_active") ?>
</div></div>
<?php echo $userdevices_edit->active->Lookup->getParamTag($userdevices_edit, "p_x_active") ?>
</span>
<?php echo $userdevices_edit->active->CustomMsg ?></div></div>
	</div>
<?php } ?>
<?php if ($userdevices_edit->enrolledtime->Visible) { // enrolledtime ?>
	<div id="r_enrolledtime" class="form-group row">
		<label id="elh_userdevices_enrolledtime" for="x_enrolledtime" class="<?php echo $userdevices_edit->LeftColumnClass ?>"><?php echo $userdevices_edit->enrolledtime->caption() ?><?php echo $userdevices_edit->enrolledtime->Required ? $Language->phrase("FieldRequiredIndicator") : "" ?></label>
		<div class="<?php echo $userdevices_edit->RightColumnClass ?>"><div <?php echo $userdevices_edit->enrolledtime->cellAttributes() ?>>
<span id="el_userdevices_enrolledtime">
<input type="text" data-table="userdevices" data-field="x_enrolledtime" name="x_enrolledtime" id="x_enrolledtime" maxlength="19" placeholder="<?php echo HtmlEncode($userdevices_edit->enrolledtime->getPlaceHolder()) ?>" value="<?php echo $userdevices_edit->enrolledtime->EditValue ?>"<?php echo $userdevices_edit->enrolledtime->editAttributes() ?>>
<?php if (!$userdevices_edit->enrolledtime->ReadOnly && !$userdevices_edit->enrolledtime->Disabled && !isset($userdevices_edit->enrolledtime->EditAttrs["readonly"]) && !isset($userdevices_edit->enrolledtime->EditAttrs["disabled"])) { ?>
<script>
loadjs.ready(["fuserdevicesedit", "datetimepicker"], function() {
	ew.createDateTimePicker("fuserdevicesedit", "x_enrolledtime", {"ignoreReadonly":true,"useCurrent":false,"format":0});
});
</script>
<?php } ?>
</span>
<?php echo $userdevices_edit->enrolledtime->CustomMsg ?></div></div>
	</div>
<?php } ?>
<?php if ($userdevices_edit->lastlogin->Visible) { // lastlogin ?>
	<div id="r_lastlogin" class="form-group row">
		<label id="elh_userdevices_lastlogin" for="x_lastlogin" class="<?php echo $userdevices_edit->LeftColumnClass ?>"><?php echo $userdevices_edit->lastlogin->caption() ?><?php echo $userdevices_edit->lastlogin->Required ? $Language->phrase("FieldRequiredIndicator") : "" ?></label>
		<div class="<?php echo $userdevices_edit->RightColumnClass ?>"><div <?php echo $userdevices_edit->lastlogin->cellAttributes() ?>>
<span id="el_userdevices_lastlogin">
<input type="text" data-table="userdevices" data-field="x_lastlogin" name="x_lastlogin" id="x_lastlogin" maxlength="19" placeholder="<?php echo HtmlEncode($userdevices_edit->lastlogin->getPlaceHolder()) ?>" value="<?php echo $userdevices_edit->lastlogin->EditValue ?>"<?php echo $userdevices_edit->lastlogin->editAttributes() ?>>
<?php if (!$userdevices_edit->lastlogin->ReadOnly && !$userdevices_edit->lastlogin->Disabled && !isset($userdevices_edit->lastlogin->EditAttrs["readonly"]) && !isset($userdevices_edit->lastlogin->EditAttrs["disabled"])) { ?>
<script>
loadjs.ready(["fuserdevicesedit", "datetimepicker"], function() {
	ew.createDateTimePicker("fuserdevicesedit", "x_lastlogin", {"ignoreReadonly":true,"useCurrent":false,"format":0});
});
</script>
<?php } ?>
</span>
<?php echo $userdevices_edit->lastlogin->CustomMsg ?></div></div>
	</div>
<?php } ?>
</div><!-- /page* -->
<?php
	if (in_array("userpushnotificationhistory", explode(",", $userdevices->getCurrentDetailTable())) && $userpushnotificationhistory->DetailEdit) {
?>
<?php if ($userdevices->getCurrentDetailTable() != "") { ?>
<h4 class="ew-detail-caption"><?php echo $Language->tablePhrase("userpushnotificationhistory", "TblCaption") ?></h4>
<?php } ?>
<?php include_once "userpushnotificationhistorygrid.php" ?>
<?php } ?>
<?php if (!$userdevices_edit->IsModal) { ?>
<div class="form-group row"><!-- buttons .form-group -->
	<div class="<?php echo $userdevices_edit->OffsetColumnClass ?>"><!-- buttons offset -->
<button class="btn btn-primary ew-btn" name="btn-action" id="btn-action" type="submit"><?php echo $Language->phrase("SaveBtn") ?></button>
<button class="btn btn-default ew-btn" name="btn-cancel" id="btn-cancel" type="button" data-href="<?php echo $userdevices_edit->getReturnUrl() ?>"><?php echo $Language->phrase("CancelBtn") ?></button>
	</div><!-- /buttons offset -->
</div><!-- /buttons .form-group -->
<?php } ?>
</form>
<?php
$userdevices_edit->showPageFooter();
if (Config("DEBUG"))
	echo GetDebugMessage();
?>
<script>
loadjs.ready("load", function() {

	// Startup script
	// Write your table-specific startup script here
	// console.log("page loaded");

});
</script>
<?php include_once "footer.php"; ?>
<?php
$userdevices_edit->terminate();
?>