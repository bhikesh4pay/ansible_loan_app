<?php
namespace PHPMaker2020\_4payadmin;

// Autoload
include_once "autoload.php";

// Session
if (session_status() !== PHP_SESSION_ACTIVE)
	\Delight\Cookie\Session::start(Config("COOKIE_SAMESITE")); // Init session data

// Output buffering
ob_start();
?>
<?php

// Write header
WriteHeader(FALSE);

// Create page object
$merchantpolicy_add = new merchantpolicy_add();

// Run the page
$merchantpolicy_add->run();

// Setup login status
SetupLoginStatus();
SetClientVar("login", LoginStatus());

// Global Page Rendering event (in userfn*.php)
Page_Rendering();

// Page Rendering event
$merchantpolicy_add->Page_Render();
?>
<?php include_once "header.php"; ?>
<script>
var fmerchantpolicyadd, currentPageID;
loadjs.ready("head", function() {

	// Form object
	currentPageID = ew.PAGE_ID = "add";
	fmerchantpolicyadd = currentForm = new ew.Form("fmerchantpolicyadd", "add");

	// Validate form
	fmerchantpolicyadd.validate = function() {
		if (!this.validateRequired)
			return true; // Ignore validation
		var $ = jQuery, fobj = this.getForm(), $fobj = $(fobj);
		if ($fobj.find("#confirm").val() == "confirm")
			return true;
		var elm, felm, uelm, addcnt = 0;
		var $k = $fobj.find("#" + this.formKeyCountName); // Get key_count
		var rowcnt = ($k[0]) ? parseInt($k.val(), 10) : 1;
		var startcnt = (rowcnt == 0) ? 0 : 1; // Check rowcnt == 0 => Inline-Add
		var gridinsert = ["insert", "gridinsert"].includes($fobj.find("#action").val()) && $k[0];
		for (var i = startcnt; i <= rowcnt; i++) {
			var infix = ($k[0]) ? String(i) : "";
			$fobj.data("rowindex", infix);
			<?php if ($merchantpolicy_add->merchantid->Required) { ?>
				elm = this.getElements("x" + infix + "_merchantid");
				if (elm && !ew.isHidden(elm) && !ew.hasValue(elm))
					return this.onError(elm, "<?php echo JsEncode(str_replace("%s", $merchantpolicy_add->merchantid->caption(), $merchantpolicy_add->merchantid->RequiredErrorMessage)) ?>");
			<?php } ?>
				elm = this.getElements("x" + infix + "_merchantid");
				if (elm && !ew.checkInteger(elm.value))
					return this.onError(elm, "<?php echo JsEncode($merchantpolicy_add->merchantid->errorMessage()) ?>");
			<?php if ($merchantpolicy_add->label->Required) { ?>
				elm = this.getElements("x" + infix + "_label");
				if (elm && !ew.isHidden(elm) && !ew.hasValue(elm))
					return this.onError(elm, "<?php echo JsEncode(str_replace("%s", $merchantpolicy_add->label->caption(), $merchantpolicy_add->label->RequiredErrorMessage)) ?>");
			<?php } ?>
			<?php if ($merchantpolicy_add->filename->Required) { ?>
				elm = this.getElements("x" + infix + "_filename");
				if (elm && !ew.isHidden(elm) && !ew.hasValue(elm))
					return this.onError(elm, "<?php echo JsEncode(str_replace("%s", $merchantpolicy_add->filename->caption(), $merchantpolicy_add->filename->RequiredErrorMessage)) ?>");
			<?php } ?>
			<?php if ($merchantpolicy_add->active->Required) { ?>
				elm = this.getElements("x" + infix + "_active");
				if (elm && !ew.isHidden(elm) && !ew.hasValue(elm))
					return this.onError(elm, "<?php echo JsEncode(str_replace("%s", $merchantpolicy_add->active->caption(), $merchantpolicy_add->active->RequiredErrorMessage)) ?>");
			<?php } ?>
				elm = this.getElements("x" + infix + "_active");
				if (elm && !ew.checkInteger(elm.value))
					return this.onError(elm, "<?php echo JsEncode($merchantpolicy_add->active->errorMessage()) ?>");
			<?php if ($merchantpolicy_add->lastupdatedate->Required) { ?>
				elm = this.getElements("x" + infix + "_lastupdatedate");
				if (elm && !ew.isHidden(elm) && !ew.hasValue(elm))
					return this.onError(elm, "<?php echo JsEncode(str_replace("%s", $merchantpolicy_add->lastupdatedate->caption(), $merchantpolicy_add->lastupdatedate->RequiredErrorMessage)) ?>");
			<?php } ?>
				elm = this.getElements("x" + infix + "_lastupdatedate");
				if (elm && !ew.checkDateDef(elm.value))
					return this.onError(elm, "<?php echo JsEncode($merchantpolicy_add->lastupdatedate->errorMessage()) ?>");

				// Call Form_CustomValidate event
				if (!this.Form_CustomValidate(fobj))
					return false;
		}

		// Process detail forms
		var dfs = $fobj.find("input[name='detailpage']").get();
		for (var i = 0; i < dfs.length; i++) {
			var df = dfs[i], val = df.value;
			if (val && ew.forms[val])
				if (!ew.forms[val].validate())
					return false;
		}
		return true;
	}

	// Form_CustomValidate
	fmerchantpolicyadd.Form_CustomValidate = function(fobj) { // DO NOT CHANGE THIS LINE!

		// Your custom validation code here, return false if invalid.
		return true;
	}

	// Use JavaScript validation or not
	fmerchantpolicyadd.validateRequired = <?php echo Config("CLIENT_VALIDATE") ? "true" : "false" ?>;

	// Dynamic selection lists
	loadjs.done("fmerchantpolicyadd");
});
</script>
<script>
loadjs.ready("head", function() {

	// Client script
	// Write your client script here, no need to add script tags.

});
</script>
<?php $merchantpolicy_add->showPageHeader(); ?>
<?php
$merchantpolicy_add->showMessage();
?>
<form name="fmerchantpolicyadd" id="fmerchantpolicyadd" class="<?php echo $merchantpolicy_add->FormClassName ?>" action="<?php echo CurrentPageName() ?>" method="post">
<?php if ($Page->CheckToken) { ?>
<input type="hidden" name="<?php echo Config("TOKEN_NAME") ?>" value="<?php echo $Page->Token ?>">
<?php } ?>
<input type="hidden" name="t" value="merchantpolicy">
<input type="hidden" name="action" id="action" value="insert">
<input type="hidden" name="modal" value="<?php echo (int)$merchantpolicy_add->IsModal ?>">
<div class="ew-add-div"><!-- page* -->
<?php if ($merchantpolicy_add->merchantid->Visible) { // merchantid ?>
	<div id="r_merchantid" class="form-group row">
		<label id="elh_merchantpolicy_merchantid" for="x_merchantid" class="<?php echo $merchantpolicy_add->LeftColumnClass ?>"><?php echo $merchantpolicy_add->merchantid->caption() ?><?php echo $merchantpolicy_add->merchantid->Required ? $Language->phrase("FieldRequiredIndicator") : "" ?></label>
		<div class="<?php echo $merchantpolicy_add->RightColumnClass ?>"><div <?php echo $merchantpolicy_add->merchantid->cellAttributes() ?>>
<span id="el_merchantpolicy_merchantid">
<input type="text" data-table="merchantpolicy" data-field="x_merchantid" name="x_merchantid" id="x_merchantid" size="30" placeholder="<?php echo HtmlEncode($merchantpolicy_add->merchantid->getPlaceHolder()) ?>" value="<?php echo $merchantpolicy_add->merchantid->EditValue ?>"<?php echo $merchantpolicy_add->merchantid->editAttributes() ?>>
</span>
<?php echo $merchantpolicy_add->merchantid->CustomMsg ?></div></div>
	</div>
<?php } ?>
<?php if ($merchantpolicy_add->label->Visible) { // label ?>
	<div id="r_label" class="form-group row">
		<label id="elh_merchantpolicy_label" for="x_label" class="<?php echo $merchantpolicy_add->LeftColumnClass ?>"><?php echo $merchantpolicy_add->label->caption() ?><?php echo $merchantpolicy_add->label->Required ? $Language->phrase("FieldRequiredIndicator") : "" ?></label>
		<div class="<?php echo $merchantpolicy_add->RightColumnClass ?>"><div <?php echo $merchantpolicy_add->label->cellAttributes() ?>>
<span id="el_merchantpolicy_label">
<input type="text" data-table="merchantpolicy" data-field="x_label" name="x_label" id="x_label" size="30" maxlength="30" placeholder="<?php echo HtmlEncode($merchantpolicy_add->label->getPlaceHolder()) ?>" value="<?php echo $merchantpolicy_add->label->EditValue ?>"<?php echo $merchantpolicy_add->label->editAttributes() ?>>
</span>
<?php echo $merchantpolicy_add->label->CustomMsg ?></div></div>
	</div>
<?php } ?>
<?php if ($merchantpolicy_add->filename->Visible) { // filename ?>
	<div id="r_filename" class="form-group row">
		<label id="elh_merchantpolicy_filename" for="x_filename" class="<?php echo $merchantpolicy_add->LeftColumnClass ?>"><?php echo $merchantpolicy_add->filename->caption() ?><?php echo $merchantpolicy_add->filename->Required ? $Language->phrase("FieldRequiredIndicator") : "" ?></label>
		<div class="<?php echo $merchantpolicy_add->RightColumnClass ?>"><div <?php echo $merchantpolicy_add->filename->cellAttributes() ?>>
<span id="el_merchantpolicy_filename">
<input type="text" data-table="merchantpolicy" data-field="x_filename" name="x_filename" id="x_filename" size="30" maxlength="50" placeholder="<?php echo HtmlEncode($merchantpolicy_add->filename->getPlaceHolder()) ?>" value="<?php echo $merchantpolicy_add->filename->EditValue ?>"<?php echo $merchantpolicy_add->filename->editAttributes() ?>>
</span>
<?php echo $merchantpolicy_add->filename->CustomMsg ?></div></div>
	</div>
<?php } ?>
<?php if ($merchantpolicy_add->active->Visible) { // active ?>
	<div id="r_active" class="form-group row">
		<label id="elh_merchantpolicy_active" for="x_active" class="<?php echo $merchantpolicy_add->LeftColumnClass ?>"><?php echo $merchantpolicy_add->active->caption() ?><?php echo $merchantpolicy_add->active->Required ? $Language->phrase("FieldRequiredIndicator") : "" ?></label>
		<div class="<?php echo $merchantpolicy_add->RightColumnClass ?>"><div <?php echo $merchantpolicy_add->active->cellAttributes() ?>>
<span id="el_merchantpolicy_active">
<input type="text" data-table="merchantpolicy" data-field="x_active" name="x_active" id="x_active" size="30" placeholder="<?php echo HtmlEncode($merchantpolicy_add->active->getPlaceHolder()) ?>" value="<?php echo $merchantpolicy_add->active->EditValue ?>"<?php echo $merchantpolicy_add->active->editAttributes() ?>>
</span>
<?php echo $merchantpolicy_add->active->CustomMsg ?></div></div>
	</div>
<?php } ?>
<?php if ($merchantpolicy_add->lastupdatedate->Visible) { // lastupdatedate ?>
	<div id="r_lastupdatedate" class="form-group row">
		<label id="elh_merchantpolicy_lastupdatedate" for="x_lastupdatedate" class="<?php echo $merchantpolicy_add->LeftColumnClass ?>"><?php echo $merchantpolicy_add->lastupdatedate->caption() ?><?php echo $merchantpolicy_add->lastupdatedate->Required ? $Language->phrase("FieldRequiredIndicator") : "" ?></label>
		<div class="<?php echo $merchantpolicy_add->RightColumnClass ?>"><div <?php echo $merchantpolicy_add->lastupdatedate->cellAttributes() ?>>
<span id="el_merchantpolicy_lastupdatedate">
<input type="text" data-table="merchantpolicy" data-field="x_lastupdatedate" name="x_lastupdatedate" id="x_lastupdatedate" placeholder="<?php echo HtmlEncode($merchantpolicy_add->lastupdatedate->getPlaceHolder()) ?>" value="<?php echo $merchantpolicy_add->lastupdatedate->EditValue ?>"<?php echo $merchantpolicy_add->lastupdatedate->editAttributes() ?>>
</span>
<?php echo $merchantpolicy_add->lastupdatedate->CustomMsg ?></div></div>
	</div>
<?php } ?>
</div><!-- /page* -->
<?php if (!$merchantpolicy_add->IsModal) { ?>
<div class="form-group row"><!-- buttons .form-group -->
	<div class="<?php echo $merchantpolicy_add->OffsetColumnClass ?>"><!-- buttons offset -->
<button class="btn btn-primary ew-btn" name="btn-action" id="btn-action" type="submit"><?php echo $Language->phrase("AddBtn") ?></button>
<button class="btn btn-default ew-btn" name="btn-cancel" id="btn-cancel" type="button" data-href="<?php echo $merchantpolicy_add->getReturnUrl() ?>"><?php echo $Language->phrase("CancelBtn") ?></button>
	</div><!-- /buttons offset -->
</div><!-- /buttons .form-group -->
<?php } ?>
</form>
<?php
$merchantpolicy_add->showPageFooter();
if (Config("DEBUG"))
	echo GetDebugMessage();
?>
<script>
loadjs.ready("load", function() {

	// Startup script
	// Write your table-specific startup script here
	// console.log("page loaded");

});
</script>
<?php include_once "footer.php"; ?>
<?php
$merchantpolicy_add->terminate();
?>