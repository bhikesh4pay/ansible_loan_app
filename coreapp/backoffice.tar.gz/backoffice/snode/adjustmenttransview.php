<?php
namespace PHPMaker2020\_4payadmin;

// Autoload
include_once "autoload.php";

// Session
if (session_status() !== PHP_SESSION_ACTIVE)
	\Delight\Cookie\Session::start(Config("COOKIE_SAMESITE")); // Init session data

// Output buffering
ob_start();
?>
<?php

// Write header
WriteHeader(FALSE);

// Create page object
$adjustmenttrans_view = new adjustmenttrans_view();

// Run the page
$adjustmenttrans_view->run();

// Setup login status
SetupLoginStatus();
SetClientVar("login", LoginStatus());

// Global Page Rendering event (in userfn*.php)
Page_Rendering();

// Page Rendering event
$adjustmenttrans_view->Page_Render();
?>
<?php include_once "header.php"; ?>
<?php if (!$adjustmenttrans_view->isExport()) { ?>
<script>
var fadjustmenttransview, currentPageID;
loadjs.ready("head", function() {

	// Form object
	currentPageID = ew.PAGE_ID = "view";
	fadjustmenttransview = currentForm = new ew.Form("fadjustmenttransview", "view");
	loadjs.done("fadjustmenttransview");
});
</script>
<script>
loadjs.ready("head", function() {

	// Client script
	// Write your client script here, no need to add script tags.

});
</script>
<?php } ?>
<?php if (!$adjustmenttrans_view->isExport()) { ?>
<div class="btn-toolbar ew-toolbar">
<?php $adjustmenttrans_view->ExportOptions->render("body") ?>
<?php $adjustmenttrans_view->OtherOptions->render("body") ?>
<div class="clearfix"></div>
</div>
<?php } ?>
<?php $adjustmenttrans_view->showPageHeader(); ?>
<?php
$adjustmenttrans_view->showMessage();
?>
<form name="fadjustmenttransview" id="fadjustmenttransview" class="form-inline ew-form ew-view-form" action="<?php echo CurrentPageName() ?>" method="post">
<?php if ($Page->CheckToken) { ?>
<input type="hidden" name="<?php echo Config("TOKEN_NAME") ?>" value="<?php echo $Page->Token ?>">
<?php } ?>
<input type="hidden" name="t" value="adjustmenttrans">
<input type="hidden" name="modal" value="<?php echo (int)$adjustmenttrans_view->IsModal ?>">
<table class="table table-striped table-sm ew-view-table">
<?php if ($adjustmenttrans_view->adjustmentid->Visible) { // adjustmentid ?>
	<tr id="r_adjustmentid">
		<td class="<?php echo $adjustmenttrans_view->TableLeftColumnClass ?>"><span id="elh_adjustmenttrans_adjustmentid"><?php echo $adjustmenttrans_view->adjustmentid->caption() ?></span></td>
		<td data-name="adjustmentid" <?php echo $adjustmenttrans_view->adjustmentid->cellAttributes() ?>>
<span id="el_adjustmenttrans_adjustmentid">
<span<?php echo $adjustmenttrans_view->adjustmentid->viewAttributes() ?>><?php echo $adjustmenttrans_view->adjustmentid->getViewValue() ?></span>
</span>
</td>
	</tr>
<?php } ?>
<?php if ($adjustmenttrans_view->transdatetime->Visible) { // transdatetime ?>
	<tr id="r_transdatetime">
		<td class="<?php echo $adjustmenttrans_view->TableLeftColumnClass ?>"><span id="elh_adjustmenttrans_transdatetime"><?php echo $adjustmenttrans_view->transdatetime->caption() ?></span></td>
		<td data-name="transdatetime" <?php echo $adjustmenttrans_view->transdatetime->cellAttributes() ?>>
<span id="el_adjustmenttrans_transdatetime">
<span<?php echo $adjustmenttrans_view->transdatetime->viewAttributes() ?>><?php echo $adjustmenttrans_view->transdatetime->getViewValue() ?></span>
</span>
</td>
	</tr>
<?php } ?>
<?php if ($adjustmenttrans_view->_userid->Visible) { // userid ?>
	<tr id="r__userid">
		<td class="<?php echo $adjustmenttrans_view->TableLeftColumnClass ?>"><span id="elh_adjustmenttrans__userid"><?php echo $adjustmenttrans_view->_userid->caption() ?></span></td>
		<td data-name="_userid" <?php echo $adjustmenttrans_view->_userid->cellAttributes() ?>>
<span id="el_adjustmenttrans__userid">
<span<?php echo $adjustmenttrans_view->_userid->viewAttributes() ?>><?php echo $adjustmenttrans_view->_userid->getViewValue() ?></span>
</span>
</td>
	</tr>
<?php } ?>
<?php if ($adjustmenttrans_view->gltransid->Visible) { // gltransid ?>
	<tr id="r_gltransid">
		<td class="<?php echo $adjustmenttrans_view->TableLeftColumnClass ?>"><span id="elh_adjustmenttrans_gltransid"><?php echo $adjustmenttrans_view->gltransid->caption() ?></span></td>
		<td data-name="gltransid" <?php echo $adjustmenttrans_view->gltransid->cellAttributes() ?>>
<span id="el_adjustmenttrans_gltransid">
<span<?php echo $adjustmenttrans_view->gltransid->viewAttributes() ?>><?php if (!EmptyString($adjustmenttrans_view->gltransid->getViewValue()) && $adjustmenttrans_view->gltransid->linkAttributes() != "") { ?>
<a<?php echo $adjustmenttrans_view->gltransid->linkAttributes() ?>><?php echo $adjustmenttrans_view->gltransid->getViewValue() ?></a>
<?php } else { ?>
<?php echo $adjustmenttrans_view->gltransid->getViewValue() ?>
<?php } ?></span>
</span>
</td>
	</tr>
<?php } ?>
</table>
</form>
<?php
$adjustmenttrans_view->showPageFooter();
if (Config("DEBUG"))
	echo GetDebugMessage();
?>
<?php if (!$adjustmenttrans_view->isExport()) { ?>
<script>
loadjs.ready("load", function() {

	// Startup script
	// Write your table-specific startup script here
	// console.log("page loaded");

});
</script>
<?php } ?>
<?php include_once "footer.php"; ?>
<?php
$adjustmenttrans_view->terminate();
?>