<?php
namespace PHPMaker2020\_4payadmin;

// Autoload
include_once "autoload.php";

// Session
if (session_status() !== PHP_SESSION_ACTIVE)
	\Delight\Cookie\Session::start(Config("COOKIE_SAMESITE")); // Init session data

// Output buffering
ob_start();
?>
<?php

// Write header
WriteHeader(FALSE);

// Create page object
$userownedapps_edit = new userownedapps_edit();

// Run the page
$userownedapps_edit->run();

// Setup login status
SetupLoginStatus();
SetClientVar("login", LoginStatus());

// Global Page Rendering event (in userfn*.php)
Page_Rendering();

// Page Rendering event
$userownedapps_edit->Page_Render();
?>
<?php include_once "header.php"; ?>
<script>
var fuserownedappsedit, currentPageID;
loadjs.ready("head", function() {

	// Form object
	currentPageID = ew.PAGE_ID = "edit";
	fuserownedappsedit = currentForm = new ew.Form("fuserownedappsedit", "edit");

	// Validate form
	fuserownedappsedit.validate = function() {
		if (!this.validateRequired)
			return true; // Ignore validation
		var $ = jQuery, fobj = this.getForm(), $fobj = $(fobj);
		if ($fobj.find("#confirm").val() == "confirm")
			return true;
		var elm, felm, uelm, addcnt = 0;
		var $k = $fobj.find("#" + this.formKeyCountName); // Get key_count
		var rowcnt = ($k[0]) ? parseInt($k.val(), 10) : 1;
		var startcnt = (rowcnt == 0) ? 0 : 1; // Check rowcnt == 0 => Inline-Add
		var gridinsert = ["insert", "gridinsert"].includes($fobj.find("#action").val()) && $k[0];
		for (var i = startcnt; i <= rowcnt; i++) {
			var infix = ($k[0]) ? String(i) : "";
			$fobj.data("rowindex", infix);
			<?php if ($userownedapps_edit->_userid->Required) { ?>
				elm = this.getElements("x" + infix + "__userid");
				if (elm && !ew.isHidden(elm) && !ew.hasValue(elm))
					return this.onError(elm, "<?php echo JsEncode(str_replace("%s", $userownedapps_edit->_userid->caption(), $userownedapps_edit->_userid->RequiredErrorMessage)) ?>");
			<?php } ?>
				elm = this.getElements("x" + infix + "__userid");
				if (elm && !ew.checkInteger(elm.value))
					return this.onError(elm, "<?php echo JsEncode($userownedapps_edit->_userid->errorMessage()) ?>");
			<?php if ($userownedapps_edit->appid->Required) { ?>
				elm = this.getElements("x" + infix + "_appid");
				if (elm && !ew.isHidden(elm) && !ew.hasValue(elm))
					return this.onError(elm, "<?php echo JsEncode(str_replace("%s", $userownedapps_edit->appid->caption(), $userownedapps_edit->appid->RequiredErrorMessage)) ?>");
			<?php } ?>
				elm = this.getElements("x" + infix + "_appid");
				if (elm && !ew.checkInteger(elm.value))
					return this.onError(elm, "<?php echo JsEncode($userownedapps_edit->appid->errorMessage()) ?>");

				// Call Form_CustomValidate event
				if (!this.Form_CustomValidate(fobj))
					return false;
		}

		// Process detail forms
		var dfs = $fobj.find("input[name='detailpage']").get();
		for (var i = 0; i < dfs.length; i++) {
			var df = dfs[i], val = df.value;
			if (val && ew.forms[val])
				if (!ew.forms[val].validate())
					return false;
		}
		return true;
	}

	// Form_CustomValidate
	fuserownedappsedit.Form_CustomValidate = function(fobj) { // DO NOT CHANGE THIS LINE!

		// Your custom validation code here, return false if invalid.
		return true;
	}

	// Use JavaScript validation or not
	fuserownedappsedit.validateRequired = <?php echo Config("CLIENT_VALIDATE") ? "true" : "false" ?>;

	// Dynamic selection lists
	fuserownedappsedit.lists["x_appid"] = <?php echo $userownedapps_edit->appid->Lookup->toClientList($userownedapps_edit) ?>;
	fuserownedappsedit.lists["x_appid"].options = <?php echo JsonEncode($userownedapps_edit->appid->lookupOptions()) ?>;
	fuserownedappsedit.autoSuggests["x_appid"] = <?php echo json_encode(["data" => "ajax=autosuggest"]) ?>;
	loadjs.done("fuserownedappsedit");
});
</script>
<script>
loadjs.ready("head", function() {

	// Client script
	// Write your client script here, no need to add script tags.

});
</script>
<?php $userownedapps_edit->showPageHeader(); ?>
<?php
$userownedapps_edit->showMessage();
?>
<form name="fuserownedappsedit" id="fuserownedappsedit" class="<?php echo $userownedapps_edit->FormClassName ?>" action="<?php echo CurrentPageName() ?>" method="post">
<?php if ($Page->CheckToken) { ?>
<input type="hidden" name="<?php echo Config("TOKEN_NAME") ?>" value="<?php echo $Page->Token ?>">
<?php } ?>
<input type="hidden" name="t" value="userownedapps">
<input type="hidden" name="action" id="action" value="update">
<input type="hidden" name="modal" value="<?php echo (int)$userownedapps_edit->IsModal ?>">
<div class="ew-edit-div"><!-- page* -->
<?php if ($userownedapps_edit->_userid->Visible) { // userid ?>
	<div id="r__userid" class="form-group row">
		<label id="elh_userownedapps__userid" for="x__userid" class="<?php echo $userownedapps_edit->LeftColumnClass ?>"><?php echo $userownedapps_edit->_userid->caption() ?><?php echo $userownedapps_edit->_userid->Required ? $Language->phrase("FieldRequiredIndicator") : "" ?></label>
		<div class="<?php echo $userownedapps_edit->RightColumnClass ?>"><div <?php echo $userownedapps_edit->_userid->cellAttributes() ?>>
<input type="text" data-table="userownedapps" data-field="x__userid" name="x__userid" id="x__userid" size="30" placeholder="<?php echo HtmlEncode($userownedapps_edit->_userid->getPlaceHolder()) ?>" value="<?php echo $userownedapps_edit->_userid->EditValue ?>"<?php echo $userownedapps_edit->_userid->editAttributes() ?>>
<input type="hidden" data-table="userownedapps" data-field="x__userid" name="o__userid" id="o__userid" value="<?php echo HtmlEncode($userownedapps_edit->_userid->OldValue != null ? $userownedapps_edit->_userid->OldValue : $userownedapps_edit->_userid->CurrentValue) ?>">
<?php echo $userownedapps_edit->_userid->CustomMsg ?></div></div>
	</div>
<?php } ?>
<?php if ($userownedapps_edit->appid->Visible) { // appid ?>
	<div id="r_appid" class="form-group row">
		<label id="elh_userownedapps_appid" class="<?php echo $userownedapps_edit->LeftColumnClass ?>"><?php echo $userownedapps_edit->appid->caption() ?><?php echo $userownedapps_edit->appid->Required ? $Language->phrase("FieldRequiredIndicator") : "" ?></label>
		<div class="<?php echo $userownedapps_edit->RightColumnClass ?>"><div <?php echo $userownedapps_edit->appid->cellAttributes() ?>>
<?php
$onchange = $userownedapps_edit->appid->EditAttrs->prepend("onchange", "");
$onchange = ($onchange) ? ' onchange="' . JsEncode($onchange) . '"' : '';
$userownedapps_edit->appid->EditAttrs["onchange"] = "";
?>
<span id="as_x_appid">
	<input type="text" class="form-control" name="sv_x_appid" id="sv_x_appid" value="<?php echo RemoveHtml($userownedapps_edit->appid->EditValue) ?>" size="30" placeholder="<?php echo HtmlEncode($userownedapps_edit->appid->getPlaceHolder()) ?>" data-placeholder="<?php echo HtmlEncode($userownedapps_edit->appid->getPlaceHolder()) ?>"<?php echo $userownedapps_edit->appid->editAttributes() ?>>
</span>
<input type="hidden" data-table="userownedapps" data-field="x_appid" data-value-separator="<?php echo $userownedapps_edit->appid->displayValueSeparatorAttribute() ?>" name="x_appid" id="x_appid" value="<?php echo HtmlEncode($userownedapps_edit->appid->CurrentValue) ?>"<?php echo $onchange ?>>
<script>
loadjs.ready(["fuserownedappsedit"], function() {
	fuserownedappsedit.createAutoSuggest({"id":"x_appid","forceSelect":false});
});
</script>
<?php echo $userownedapps_edit->appid->Lookup->getParamTag($userownedapps_edit, "p_x_appid") ?>
<input type="hidden" data-table="userownedapps" data-field="x_appid" name="o_appid" id="o_appid" value="<?php echo HtmlEncode($userownedapps_edit->appid->OldValue != null ? $userownedapps_edit->appid->OldValue : $userownedapps_edit->appid->CurrentValue) ?>">
<?php echo $userownedapps_edit->appid->CustomMsg ?></div></div>
	</div>
<?php } ?>
</div><!-- /page* -->
<?php if (!$userownedapps_edit->IsModal) { ?>
<div class="form-group row"><!-- buttons .form-group -->
	<div class="<?php echo $userownedapps_edit->OffsetColumnClass ?>"><!-- buttons offset -->
<button class="btn btn-primary ew-btn" name="btn-action" id="btn-action" type="submit"><?php echo $Language->phrase("SaveBtn") ?></button>
<button class="btn btn-default ew-btn" name="btn-cancel" id="btn-cancel" type="button" data-href="<?php echo $userownedapps_edit->getReturnUrl() ?>"><?php echo $Language->phrase("CancelBtn") ?></button>
	</div><!-- /buttons offset -->
</div><!-- /buttons .form-group -->
<?php } ?>
</form>
<?php
$userownedapps_edit->showPageFooter();
if (Config("DEBUG"))
	echo GetDebugMessage();
?>
<script>
loadjs.ready("load", function() {

	// Startup script
	// Write your table-specific startup script here
	// console.log("page loaded");

});
</script>
<?php include_once "footer.php"; ?>
<?php
$userownedapps_edit->terminate();
?>