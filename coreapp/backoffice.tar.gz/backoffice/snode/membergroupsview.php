<?php
namespace PHPMaker2020\_4payadmin;

// Autoload
include_once "autoload.php";

// Session
if (session_status() !== PHP_SESSION_ACTIVE)
	\Delight\Cookie\Session::start(Config("COOKIE_SAMESITE")); // Init session data

// Output buffering
ob_start();
?>
<?php

// Write header
WriteHeader(FALSE);

// Create page object
$membergroups_view = new membergroups_view();

// Run the page
$membergroups_view->run();

// Setup login status
SetupLoginStatus();
SetClientVar("login", LoginStatus());

// Global Page Rendering event (in userfn*.php)
Page_Rendering();

// Page Rendering event
$membergroups_view->Page_Render();
?>
<?php include_once "header.php"; ?>
<?php if (!$membergroups_view->isExport()) { ?>
<script>
var fmembergroupsview, currentPageID;
loadjs.ready("head", function() {

	// Form object
	currentPageID = ew.PAGE_ID = "view";
	fmembergroupsview = currentForm = new ew.Form("fmembergroupsview", "view");
	loadjs.done("fmembergroupsview");
});
</script>
<script>
loadjs.ready("head", function() {

	// Client script
	// Write your client script here, no need to add script tags.

});
</script>
<?php } ?>
<?php if (!$membergroups_view->isExport()) { ?>
<div class="btn-toolbar ew-toolbar">
<?php $membergroups_view->ExportOptions->render("body") ?>
<?php $membergroups_view->OtherOptions->render("body") ?>
<div class="clearfix"></div>
</div>
<?php } ?>
<?php $membergroups_view->showPageHeader(); ?>
<?php
$membergroups_view->showMessage();
?>
<form name="fmembergroupsview" id="fmembergroupsview" class="form-inline ew-form ew-view-form" action="<?php echo CurrentPageName() ?>" method="post">
<?php if ($Page->CheckToken) { ?>
<input type="hidden" name="<?php echo Config("TOKEN_NAME") ?>" value="<?php echo $Page->Token ?>">
<?php } ?>
<input type="hidden" name="t" value="membergroups">
<input type="hidden" name="modal" value="<?php echo (int)$membergroups_view->IsModal ?>">
<table class="table table-striped table-sm ew-view-table">
<?php if ($membergroups_view->groupid->Visible) { // groupid ?>
	<tr id="r_groupid">
		<td class="<?php echo $membergroups_view->TableLeftColumnClass ?>"><span id="elh_membergroups_groupid"><?php echo $membergroups_view->groupid->caption() ?></span></td>
		<td data-name="groupid" <?php echo $membergroups_view->groupid->cellAttributes() ?>>
<span id="el_membergroups_groupid">
<span<?php echo $membergroups_view->groupid->viewAttributes() ?>><?php echo $membergroups_view->groupid->getViewValue() ?></span>
</span>
</td>
	</tr>
<?php } ?>
<?php if ($membergroups_view->merchantid->Visible) { // merchantid ?>
	<tr id="r_merchantid">
		<td class="<?php echo $membergroups_view->TableLeftColumnClass ?>"><span id="elh_membergroups_merchantid"><?php echo $membergroups_view->merchantid->caption() ?></span></td>
		<td data-name="merchantid" <?php echo $membergroups_view->merchantid->cellAttributes() ?>>
<span id="el_membergroups_merchantid">
<span<?php echo $membergroups_view->merchantid->viewAttributes() ?>><?php echo $membergroups_view->merchantid->getViewValue() ?></span>
</span>
</td>
	</tr>
<?php } ?>
<?php if ($membergroups_view->label->Visible) { // label ?>
	<tr id="r_label">
		<td class="<?php echo $membergroups_view->TableLeftColumnClass ?>"><span id="elh_membergroups_label"><?php echo $membergroups_view->label->caption() ?></span></td>
		<td data-name="label" <?php echo $membergroups_view->label->cellAttributes() ?>>
<span id="el_membergroups_label">
<span<?php echo $membergroups_view->label->viewAttributes() ?>><?php echo $membergroups_view->label->getViewValue() ?></span>
</span>
</td>
	</tr>
<?php } ?>
<?php if ($membergroups_view->active->Visible) { // active ?>
	<tr id="r_active">
		<td class="<?php echo $membergroups_view->TableLeftColumnClass ?>"><span id="elh_membergroups_active"><?php echo $membergroups_view->active->caption() ?></span></td>
		<td data-name="active" <?php echo $membergroups_view->active->cellAttributes() ?>>
<span id="el_membergroups_active">
<span<?php echo $membergroups_view->active->viewAttributes() ?>><?php echo $membergroups_view->active->getViewValue() ?></span>
</span>
</td>
	</tr>
<?php } ?>
<?php if ($membergroups_view->lastupdatedate->Visible) { // lastupdatedate ?>
	<tr id="r_lastupdatedate">
		<td class="<?php echo $membergroups_view->TableLeftColumnClass ?>"><span id="elh_membergroups_lastupdatedate"><?php echo $membergroups_view->lastupdatedate->caption() ?></span></td>
		<td data-name="lastupdatedate" <?php echo $membergroups_view->lastupdatedate->cellAttributes() ?>>
<span id="el_membergroups_lastupdatedate">
<span<?php echo $membergroups_view->lastupdatedate->viewAttributes() ?>><?php echo $membergroups_view->lastupdatedate->getViewValue() ?></span>
</span>
</td>
	</tr>
<?php } ?>
</table>
</form>
<?php
$membergroups_view->showPageFooter();
if (Config("DEBUG"))
	echo GetDebugMessage();
?>
<?php if (!$membergroups_view->isExport()) { ?>
<script>
loadjs.ready("load", function() {

	// Startup script
	// Write your table-specific startup script here
	// console.log("page loaded");

});
</script>
<?php } ?>
<?php include_once "footer.php"; ?>
<?php
$membergroups_view->terminate();
?>