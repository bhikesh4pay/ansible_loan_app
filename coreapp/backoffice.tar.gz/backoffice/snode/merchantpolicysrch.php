<?php
namespace PHPMaker2020\_4payadmin;

// Autoload
include_once "autoload.php";

// Session
if (session_status() !== PHP_SESSION_ACTIVE)
	\Delight\Cookie\Session::start(Config("COOKIE_SAMESITE")); // Init session data

// Output buffering
ob_start();
?>
<?php

// Write header
WriteHeader(FALSE);

// Create page object
$merchantpolicy_search = new merchantpolicy_search();

// Run the page
$merchantpolicy_search->run();

// Setup login status
SetupLoginStatus();
SetClientVar("login", LoginStatus());

// Global Page Rendering event (in userfn*.php)
Page_Rendering();

// Page Rendering event
$merchantpolicy_search->Page_Render();
?>
<?php include_once "header.php"; ?>
<script>
var fmerchantpolicysearch, currentPageID;
loadjs.ready("head", function() {

	// Form object for search
	<?php if ($merchantpolicy_search->IsModal) { ?>
	fmerchantpolicysearch = currentAdvancedSearchForm = new ew.Form("fmerchantpolicysearch", "search");
	<?php } else { ?>
	fmerchantpolicysearch = currentForm = new ew.Form("fmerchantpolicysearch", "search");
	<?php } ?>
	currentPageID = ew.PAGE_ID = "search";

	// Validate function for search
	fmerchantpolicysearch.validate = function(fobj) {
		if (!this.validateRequired)
			return true; // Ignore validation
		fobj = fobj || this._form;
		var infix = "";
		elm = this.getElements("x" + infix + "_policyid");
		if (elm && !ew.checkInteger(elm.value))
			return this.onError(elm, "<?php echo JsEncode($merchantpolicy_search->policyid->errorMessage()) ?>");
		elm = this.getElements("x" + infix + "_merchantid");
		if (elm && !ew.checkInteger(elm.value))
			return this.onError(elm, "<?php echo JsEncode($merchantpolicy_search->merchantid->errorMessage()) ?>");
		elm = this.getElements("x" + infix + "_active");
		if (elm && !ew.checkInteger(elm.value))
			return this.onError(elm, "<?php echo JsEncode($merchantpolicy_search->active->errorMessage()) ?>");
		elm = this.getElements("x" + infix + "_lastupdatedate");
		if (elm && !ew.checkDateDef(elm.value))
			return this.onError(elm, "<?php echo JsEncode($merchantpolicy_search->lastupdatedate->errorMessage()) ?>");

		// Call Form_CustomValidate event
		if (!this.Form_CustomValidate(fobj))
			return false;
		return true;
	}

	// Form_CustomValidate
	fmerchantpolicysearch.Form_CustomValidate = function(fobj) { // DO NOT CHANGE THIS LINE!

		// Your custom validation code here, return false if invalid.
		return true;
	}

	// Use JavaScript validation or not
	fmerchantpolicysearch.validateRequired = <?php echo Config("CLIENT_VALIDATE") ? "true" : "false" ?>;

	// Dynamic selection lists
	loadjs.done("fmerchantpolicysearch");
});
</script>
<script>
loadjs.ready("head", function() {

	// Client script
	// Write your client script here, no need to add script tags.

});
</script>
<?php $merchantpolicy_search->showPageHeader(); ?>
<?php
$merchantpolicy_search->showMessage();
?>
<form name="fmerchantpolicysearch" id="fmerchantpolicysearch" class="<?php echo $merchantpolicy_search->FormClassName ?>" action="<?php echo CurrentPageName() ?>" method="post">
<?php if ($Page->CheckToken) { ?>
<input type="hidden" name="<?php echo Config("TOKEN_NAME") ?>" value="<?php echo $Page->Token ?>">
<?php } ?>
<input type="hidden" name="t" value="merchantpolicy">
<input type="hidden" name="action" id="action" value="search">
<input type="hidden" name="modal" value="<?php echo (int)$merchantpolicy_search->IsModal ?>">
<div class="ew-search-div"><!-- page* -->
<?php if ($merchantpolicy_search->policyid->Visible) { // policyid ?>
	<div id="r_policyid" class="form-group row">
		<label for="x_policyid" class="<?php echo $merchantpolicy_search->LeftColumnClass ?>"><span id="elh_merchantpolicy_policyid"><?php echo $merchantpolicy_search->policyid->caption() ?></span>
		<span class="ew-search-operator">
<?php echo $Language->phrase("=") ?>
<input type="hidden" name="z_policyid" id="z_policyid" value="=">
</span>
		</label>
		<div class="<?php echo $merchantpolicy_search->RightColumnClass ?>"><div <?php echo $merchantpolicy_search->policyid->cellAttributes() ?>>
			<span id="el_merchantpolicy_policyid" class="ew-search-field">
<input type="text" data-table="merchantpolicy" data-field="x_policyid" name="x_policyid" id="x_policyid" placeholder="<?php echo HtmlEncode($merchantpolicy_search->policyid->getPlaceHolder()) ?>" value="<?php echo $merchantpolicy_search->policyid->EditValue ?>"<?php echo $merchantpolicy_search->policyid->editAttributes() ?>>
</span>
		</div></div>
	</div>
<?php } ?>
<?php if ($merchantpolicy_search->merchantid->Visible) { // merchantid ?>
	<div id="r_merchantid" class="form-group row">
		<label for="x_merchantid" class="<?php echo $merchantpolicy_search->LeftColumnClass ?>"><span id="elh_merchantpolicy_merchantid"><?php echo $merchantpolicy_search->merchantid->caption() ?></span>
		<span class="ew-search-operator">
<?php echo $Language->phrase("=") ?>
<input type="hidden" name="z_merchantid" id="z_merchantid" value="=">
</span>
		</label>
		<div class="<?php echo $merchantpolicy_search->RightColumnClass ?>"><div <?php echo $merchantpolicy_search->merchantid->cellAttributes() ?>>
			<span id="el_merchantpolicy_merchantid" class="ew-search-field">
<input type="text" data-table="merchantpolicy" data-field="x_merchantid" name="x_merchantid" id="x_merchantid" size="30" placeholder="<?php echo HtmlEncode($merchantpolicy_search->merchantid->getPlaceHolder()) ?>" value="<?php echo $merchantpolicy_search->merchantid->EditValue ?>"<?php echo $merchantpolicy_search->merchantid->editAttributes() ?>>
</span>
		</div></div>
	</div>
<?php } ?>
<?php if ($merchantpolicy_search->label->Visible) { // label ?>
	<div id="r_label" class="form-group row">
		<label for="x_label" class="<?php echo $merchantpolicy_search->LeftColumnClass ?>"><span id="elh_merchantpolicy_label"><?php echo $merchantpolicy_search->label->caption() ?></span>
		<span class="ew-search-operator">
<?php echo $Language->phrase("LIKE") ?>
<input type="hidden" name="z_label" id="z_label" value="LIKE">
</span>
		</label>
		<div class="<?php echo $merchantpolicy_search->RightColumnClass ?>"><div <?php echo $merchantpolicy_search->label->cellAttributes() ?>>
			<span id="el_merchantpolicy_label" class="ew-search-field">
<input type="text" data-table="merchantpolicy" data-field="x_label" name="x_label" id="x_label" size="30" maxlength="30" placeholder="<?php echo HtmlEncode($merchantpolicy_search->label->getPlaceHolder()) ?>" value="<?php echo $merchantpolicy_search->label->EditValue ?>"<?php echo $merchantpolicy_search->label->editAttributes() ?>>
</span>
		</div></div>
	</div>
<?php } ?>
<?php if ($merchantpolicy_search->filename->Visible) { // filename ?>
	<div id="r_filename" class="form-group row">
		<label for="x_filename" class="<?php echo $merchantpolicy_search->LeftColumnClass ?>"><span id="elh_merchantpolicy_filename"><?php echo $merchantpolicy_search->filename->caption() ?></span>
		<span class="ew-search-operator">
<?php echo $Language->phrase("LIKE") ?>
<input type="hidden" name="z_filename" id="z_filename" value="LIKE">
</span>
		</label>
		<div class="<?php echo $merchantpolicy_search->RightColumnClass ?>"><div <?php echo $merchantpolicy_search->filename->cellAttributes() ?>>
			<span id="el_merchantpolicy_filename" class="ew-search-field">
<input type="text" data-table="merchantpolicy" data-field="x_filename" name="x_filename" id="x_filename" size="30" maxlength="50" placeholder="<?php echo HtmlEncode($merchantpolicy_search->filename->getPlaceHolder()) ?>" value="<?php echo $merchantpolicy_search->filename->EditValue ?>"<?php echo $merchantpolicy_search->filename->editAttributes() ?>>
</span>
		</div></div>
	</div>
<?php } ?>
<?php if ($merchantpolicy_search->active->Visible) { // active ?>
	<div id="r_active" class="form-group row">
		<label for="x_active" class="<?php echo $merchantpolicy_search->LeftColumnClass ?>"><span id="elh_merchantpolicy_active"><?php echo $merchantpolicy_search->active->caption() ?></span>
		<span class="ew-search-operator">
<?php echo $Language->phrase("=") ?>
<input type="hidden" name="z_active" id="z_active" value="=">
</span>
		</label>
		<div class="<?php echo $merchantpolicy_search->RightColumnClass ?>"><div <?php echo $merchantpolicy_search->active->cellAttributes() ?>>
			<span id="el_merchantpolicy_active" class="ew-search-field">
<input type="text" data-table="merchantpolicy" data-field="x_active" name="x_active" id="x_active" size="30" placeholder="<?php echo HtmlEncode($merchantpolicy_search->active->getPlaceHolder()) ?>" value="<?php echo $merchantpolicy_search->active->EditValue ?>"<?php echo $merchantpolicy_search->active->editAttributes() ?>>
</span>
		</div></div>
	</div>
<?php } ?>
<?php if ($merchantpolicy_search->lastupdatedate->Visible) { // lastupdatedate ?>
	<div id="r_lastupdatedate" class="form-group row">
		<label for="x_lastupdatedate" class="<?php echo $merchantpolicy_search->LeftColumnClass ?>"><span id="elh_merchantpolicy_lastupdatedate"><?php echo $merchantpolicy_search->lastupdatedate->caption() ?></span>
		<span class="ew-search-operator">
<?php echo $Language->phrase("=") ?>
<input type="hidden" name="z_lastupdatedate" id="z_lastupdatedate" value="=">
</span>
		</label>
		<div class="<?php echo $merchantpolicy_search->RightColumnClass ?>"><div <?php echo $merchantpolicy_search->lastupdatedate->cellAttributes() ?>>
			<span id="el_merchantpolicy_lastupdatedate" class="ew-search-field">
<input type="text" data-table="merchantpolicy" data-field="x_lastupdatedate" name="x_lastupdatedate" id="x_lastupdatedate" placeholder="<?php echo HtmlEncode($merchantpolicy_search->lastupdatedate->getPlaceHolder()) ?>" value="<?php echo $merchantpolicy_search->lastupdatedate->EditValue ?>"<?php echo $merchantpolicy_search->lastupdatedate->editAttributes() ?>>
</span>
		</div></div>
	</div>
<?php } ?>
</div><!-- /page* -->
<?php if (!$merchantpolicy_search->IsModal) { ?>
<div class="form-group row"><!-- buttons .form-group -->
	<div class="<?php echo $merchantpolicy_search->OffsetColumnClass ?>"><!-- buttons offset -->
<button class="btn btn-primary ew-btn" name="btn-action" id="btn-action" type="submit"><?php echo $Language->phrase("Search") ?></button>
<button class="btn btn-default ew-btn" name="btn-reset" id="btn-reset" type="button" onclick="ew.clearForm(this.form);"><?php echo $Language->phrase("Reset") ?></button>
	</div><!-- /buttons offset -->
</div><!-- /buttons .form-group -->
<?php } ?>
</form>
<?php
$merchantpolicy_search->showPageFooter();
if (Config("DEBUG"))
	echo GetDebugMessage();
?>
<script>
loadjs.ready("load", function() {

	// Startup script
	// Write your table-specific startup script here
	// console.log("page loaded");

});
</script>
<?php include_once "footer.php"; ?>
<?php
$merchantpolicy_search->terminate();
?>