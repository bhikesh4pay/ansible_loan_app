<?php
namespace PHPMaker2020\_4payadmin;

// Autoload
include_once "autoload.php";

// Session
if (session_status() !== PHP_SESSION_ACTIVE)
	\Delight\Cookie\Session::start(Config("COOKIE_SAMESITE")); // Init session data

// Output buffering
ob_start();
?>
<?php

// Write header
WriteHeader(FALSE);

// Create page object
$usernotes_delete = new usernotes_delete();

// Run the page
$usernotes_delete->run();

// Setup login status
SetupLoginStatus();
SetClientVar("login", LoginStatus());

// Global Page Rendering event (in userfn*.php)
Page_Rendering();

// Page Rendering event
$usernotes_delete->Page_Render();
?>
<?php include_once "header.php"; ?>
<script>
var fusernotesdelete, currentPageID;
loadjs.ready("head", function() {

	// Form object
	currentPageID = ew.PAGE_ID = "delete";
	fusernotesdelete = currentForm = new ew.Form("fusernotesdelete", "delete");
	loadjs.done("fusernotesdelete");
});
</script>
<script>
loadjs.ready("head", function() {

	// Client script
	// Write your client script here, no need to add script tags.

});
</script>
<?php $usernotes_delete->showPageHeader(); ?>
<?php
$usernotes_delete->showMessage();
?>
<form name="fusernotesdelete" id="fusernotesdelete" class="form-inline ew-form ew-delete-form" action="<?php echo CurrentPageName() ?>" method="post">
<?php if ($Page->CheckToken) { ?>
<input type="hidden" name="<?php echo Config("TOKEN_NAME") ?>" value="<?php echo $Page->Token ?>">
<?php } ?>
<input type="hidden" name="t" value="usernotes">
<input type="hidden" name="action" id="action" value="delete">
<?php foreach ($usernotes_delete->RecKeys as $key) { ?>
<?php $keyvalue = is_array($key) ? implode(Config("COMPOSITE_KEY_SEPARATOR"), $key) : $key; ?>
<input type="hidden" name="key_m[]" value="<?php echo HtmlEncode($keyvalue) ?>">
<?php } ?>
<div class="card ew-card ew-grid">
<div class="<?php echo ResponsiveTableClass() ?>card-body ew-grid-middle-panel">
<table class="table ew-table">
	<thead>
	<tr class="ew-table-header">
<?php if ($usernotes_delete->noteid->Visible) { // noteid ?>
		<th class="<?php echo $usernotes_delete->noteid->headerCellClass() ?>"><span id="elh_usernotes_noteid" class="usernotes_noteid"><?php echo $usernotes_delete->noteid->caption() ?></span></th>
<?php } ?>
<?php if ($usernotes_delete->_userid->Visible) { // userid ?>
		<th class="<?php echo $usernotes_delete->_userid->headerCellClass() ?>"><span id="elh_usernotes__userid" class="usernotes__userid"><?php echo $usernotes_delete->_userid->caption() ?></span></th>
<?php } ?>
<?php if ($usernotes_delete->notedatetime->Visible) { // notedatetime ?>
		<th class="<?php echo $usernotes_delete->notedatetime->headerCellClass() ?>"><span id="elh_usernotes_notedatetime" class="usernotes_notedatetime"><?php echo $usernotes_delete->notedatetime->caption() ?></span></th>
<?php } ?>
<?php if ($usernotes_delete->createdby->Visible) { // createdby ?>
		<th class="<?php echo $usernotes_delete->createdby->headerCellClass() ?>"><span id="elh_usernotes_createdby" class="usernotes_createdby"><?php echo $usernotes_delete->createdby->caption() ?></span></th>
<?php } ?>
<?php if ($usernotes_delete->profilestatus->Visible) { // profilestatus ?>
		<th class="<?php echo $usernotes_delete->profilestatus->headerCellClass() ?>"><span id="elh_usernotes_profilestatus" class="usernotes_profilestatus"><?php echo $usernotes_delete->profilestatus->caption() ?></span></th>
<?php } ?>
	</tr>
	</thead>
	<tbody>
<?php
$usernotes_delete->RecordCount = 0;
$i = 0;
while (!$usernotes_delete->Recordset->EOF) {
	$usernotes_delete->RecordCount++;
	$usernotes_delete->RowCount++;

	// Set row properties
	$usernotes->resetAttributes();
	$usernotes->RowType = ROWTYPE_VIEW; // View

	// Get the field contents
	$usernotes_delete->loadRowValues($usernotes_delete->Recordset);

	// Render row
	$usernotes_delete->renderRow();
?>
	<tr <?php echo $usernotes->rowAttributes() ?>>
<?php if ($usernotes_delete->noteid->Visible) { // noteid ?>
		<td <?php echo $usernotes_delete->noteid->cellAttributes() ?>>
<span id="el<?php echo $usernotes_delete->RowCount ?>_usernotes_noteid" class="usernotes_noteid">
<span<?php echo $usernotes_delete->noteid->viewAttributes() ?>><?php echo $usernotes_delete->noteid->getViewValue() ?></span>
</span>
</td>
<?php } ?>
<?php if ($usernotes_delete->_userid->Visible) { // userid ?>
		<td <?php echo $usernotes_delete->_userid->cellAttributes() ?>>
<span id="el<?php echo $usernotes_delete->RowCount ?>_usernotes__userid" class="usernotes__userid">
<span<?php echo $usernotes_delete->_userid->viewAttributes() ?>><?php echo $usernotes_delete->_userid->getViewValue() ?></span>
</span>
</td>
<?php } ?>
<?php if ($usernotes_delete->notedatetime->Visible) { // notedatetime ?>
		<td <?php echo $usernotes_delete->notedatetime->cellAttributes() ?>>
<span id="el<?php echo $usernotes_delete->RowCount ?>_usernotes_notedatetime" class="usernotes_notedatetime">
<span<?php echo $usernotes_delete->notedatetime->viewAttributes() ?>><?php echo $usernotes_delete->notedatetime->getViewValue() ?></span>
</span>
</td>
<?php } ?>
<?php if ($usernotes_delete->createdby->Visible) { // createdby ?>
		<td <?php echo $usernotes_delete->createdby->cellAttributes() ?>>
<span id="el<?php echo $usernotes_delete->RowCount ?>_usernotes_createdby" class="usernotes_createdby">
<span<?php echo $usernotes_delete->createdby->viewAttributes() ?>><?php echo $usernotes_delete->createdby->getViewValue() ?></span>
</span>
</td>
<?php } ?>
<?php if ($usernotes_delete->profilestatus->Visible) { // profilestatus ?>
		<td <?php echo $usernotes_delete->profilestatus->cellAttributes() ?>>
<span id="el<?php echo $usernotes_delete->RowCount ?>_usernotes_profilestatus" class="usernotes_profilestatus">
<span<?php echo $usernotes_delete->profilestatus->viewAttributes() ?>><?php echo $usernotes_delete->profilestatus->getViewValue() ?></span>
</span>
</td>
<?php } ?>
	</tr>
<?php
	$usernotes_delete->Recordset->moveNext();
}
$usernotes_delete->Recordset->close();
?>
</tbody>
</table>
</div>
</div>
<div>
<button class="btn btn-primary ew-btn" name="btn-action" id="btn-action" type="submit"><?php echo $Language->phrase("DeleteBtn") ?></button>
<button class="btn btn-default ew-btn" name="btn-cancel" id="btn-cancel" type="button" data-href="<?php echo $usernotes_delete->getReturnUrl() ?>"><?php echo $Language->phrase("CancelBtn") ?></button>
</div>
</form>
<?php
$usernotes_delete->showPageFooter();
if (Config("DEBUG"))
	echo GetDebugMessage();
?>
<script>
loadjs.ready("load", function() {

	// Startup script
	// Write your table-specific startup script here
	// console.log("page loaded");

});
</script>
<?php include_once "footer.php"; ?>
<?php
$usernotes_delete->terminate();
?>