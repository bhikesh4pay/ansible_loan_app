<?php
namespace PHPMaker2020\_4payadmin;

// Autoload
include_once "autoload.php";

// Session
if (session_status() !== PHP_SESSION_ACTIVE)
	\Delight\Cookie\Session::start(Config("COOKIE_SAMESITE")); // Init session data

// Output buffering
ob_start();
?>
<?php

// Write header
WriteHeader(FALSE);

// Create page object
$usermembershipplans_edit = new usermembershipplans_edit();

// Run the page
$usermembershipplans_edit->run();

// Setup login status
SetupLoginStatus();
SetClientVar("login", LoginStatus());

// Global Page Rendering event (in userfn*.php)
Page_Rendering();

// Page Rendering event
$usermembershipplans_edit->Page_Render();
?>
<?php include_once "header.php"; ?>
<script>
var fusermembershipplansedit, currentPageID;
loadjs.ready("head", function() {

	// Form object
	currentPageID = ew.PAGE_ID = "edit";
	fusermembershipplansedit = currentForm = new ew.Form("fusermembershipplansedit", "edit");

	// Validate form
	fusermembershipplansedit.validate = function() {
		if (!this.validateRequired)
			return true; // Ignore validation
		var $ = jQuery, fobj = this.getForm(), $fobj = $(fobj);
		if ($fobj.find("#confirm").val() == "confirm")
			return true;
		var elm, felm, uelm, addcnt = 0;
		var $k = $fobj.find("#" + this.formKeyCountName); // Get key_count
		var rowcnt = ($k[0]) ? parseInt($k.val(), 10) : 1;
		var startcnt = (rowcnt == 0) ? 0 : 1; // Check rowcnt == 0 => Inline-Add
		var gridinsert = ["insert", "gridinsert"].includes($fobj.find("#action").val()) && $k[0];
		for (var i = startcnt; i <= rowcnt; i++) {
			var infix = ($k[0]) ? String(i) : "";
			$fobj.data("rowindex", infix);
			<?php if ($usermembershipplans_edit->memberid->Required) { ?>
				elm = this.getElements("x" + infix + "_memberid");
				if (elm && !ew.isHidden(elm) && !ew.hasValue(elm))
					return this.onError(elm, "<?php echo JsEncode(str_replace("%s", $usermembershipplans_edit->memberid->caption(), $usermembershipplans_edit->memberid->RequiredErrorMessage)) ?>");
			<?php } ?>
				elm = this.getElements("x" + infix + "_memberid");
				if (elm && !ew.checkInteger(elm.value))
					return this.onError(elm, "<?php echo JsEncode($usermembershipplans_edit->memberid->errorMessage()) ?>");
			<?php if ($usermembershipplans_edit->merchantid->Required) { ?>
				elm = this.getElements("x" + infix + "_merchantid");
				if (elm && !ew.isHidden(elm) && !ew.hasValue(elm))
					return this.onError(elm, "<?php echo JsEncode(str_replace("%s", $usermembershipplans_edit->merchantid->caption(), $usermembershipplans_edit->merchantid->RequiredErrorMessage)) ?>");
			<?php } ?>
				elm = this.getElements("x" + infix + "_merchantid");
				if (elm && !ew.checkInteger(elm.value))
					return this.onError(elm, "<?php echo JsEncode($usermembershipplans_edit->merchantid->errorMessage()) ?>");
			<?php if ($usermembershipplans_edit->planid->Required) { ?>
				elm = this.getElements("x" + infix + "_planid");
				if (elm && !ew.isHidden(elm) && !ew.hasValue(elm))
					return this.onError(elm, "<?php echo JsEncode(str_replace("%s", $usermembershipplans_edit->planid->caption(), $usermembershipplans_edit->planid->RequiredErrorMessage)) ?>");
			<?php } ?>
				elm = this.getElements("x" + infix + "_planid");
				if (elm && !ew.checkInteger(elm.value))
					return this.onError(elm, "<?php echo JsEncode($usermembershipplans_edit->planid->errorMessage()) ?>");
			<?php if ($usermembershipplans_edit->planstatus->Required) { ?>
				elm = this.getElements("x" + infix + "_planstatus");
				if (elm && !ew.isHidden(elm) && !ew.hasValue(elm))
					return this.onError(elm, "<?php echo JsEncode(str_replace("%s", $usermembershipplans_edit->planstatus->caption(), $usermembershipplans_edit->planstatus->RequiredErrorMessage)) ?>");
			<?php } ?>
				elm = this.getElements("x" + infix + "_planstatus");
				if (elm && !ew.checkInteger(elm.value))
					return this.onError(elm, "<?php echo JsEncode($usermembershipplans_edit->planstatus->errorMessage()) ?>");

				// Call Form_CustomValidate event
				if (!this.Form_CustomValidate(fobj))
					return false;
		}

		// Process detail forms
		var dfs = $fobj.find("input[name='detailpage']").get();
		for (var i = 0; i < dfs.length; i++) {
			var df = dfs[i], val = df.value;
			if (val && ew.forms[val])
				if (!ew.forms[val].validate())
					return false;
		}
		return true;
	}

	// Form_CustomValidate
	fusermembershipplansedit.Form_CustomValidate = function(fobj) { // DO NOT CHANGE THIS LINE!

		// Your custom validation code here, return false if invalid.
		return true;
	}

	// Use JavaScript validation or not
	fusermembershipplansedit.validateRequired = <?php echo Config("CLIENT_VALIDATE") ? "true" : "false" ?>;

	// Dynamic selection lists
	loadjs.done("fusermembershipplansedit");
});
</script>
<script>
loadjs.ready("head", function() {

	// Client script
	// Write your client script here, no need to add script tags.

});
</script>
<?php $usermembershipplans_edit->showPageHeader(); ?>
<?php
$usermembershipplans_edit->showMessage();
?>
<form name="fusermembershipplansedit" id="fusermembershipplansedit" class="<?php echo $usermembershipplans_edit->FormClassName ?>" action="<?php echo CurrentPageName() ?>" method="post">
<?php if ($Page->CheckToken) { ?>
<input type="hidden" name="<?php echo Config("TOKEN_NAME") ?>" value="<?php echo $Page->Token ?>">
<?php } ?>
<input type="hidden" name="t" value="usermembershipplans">
<input type="hidden" name="action" id="action" value="update">
<input type="hidden" name="modal" value="<?php echo (int)$usermembershipplans_edit->IsModal ?>">
<div class="ew-edit-div"><!-- page* -->
<?php if ($usermembershipplans_edit->memberid->Visible) { // memberid ?>
	<div id="r_memberid" class="form-group row">
		<label id="elh_usermembershipplans_memberid" for="x_memberid" class="<?php echo $usermembershipplans_edit->LeftColumnClass ?>"><?php echo $usermembershipplans_edit->memberid->caption() ?><?php echo $usermembershipplans_edit->memberid->Required ? $Language->phrase("FieldRequiredIndicator") : "" ?></label>
		<div class="<?php echo $usermembershipplans_edit->RightColumnClass ?>"><div <?php echo $usermembershipplans_edit->memberid->cellAttributes() ?>>
<input type="text" data-table="usermembershipplans" data-field="x_memberid" name="x_memberid" id="x_memberid" size="30" placeholder="<?php echo HtmlEncode($usermembershipplans_edit->memberid->getPlaceHolder()) ?>" value="<?php echo $usermembershipplans_edit->memberid->EditValue ?>"<?php echo $usermembershipplans_edit->memberid->editAttributes() ?>>
<input type="hidden" data-table="usermembershipplans" data-field="x_memberid" name="o_memberid" id="o_memberid" value="<?php echo HtmlEncode($usermembershipplans_edit->memberid->OldValue != null ? $usermembershipplans_edit->memberid->OldValue : $usermembershipplans_edit->memberid->CurrentValue) ?>">
<?php echo $usermembershipplans_edit->memberid->CustomMsg ?></div></div>
	</div>
<?php } ?>
<?php if ($usermembershipplans_edit->merchantid->Visible) { // merchantid ?>
	<div id="r_merchantid" class="form-group row">
		<label id="elh_usermembershipplans_merchantid" for="x_merchantid" class="<?php echo $usermembershipplans_edit->LeftColumnClass ?>"><?php echo $usermembershipplans_edit->merchantid->caption() ?><?php echo $usermembershipplans_edit->merchantid->Required ? $Language->phrase("FieldRequiredIndicator") : "" ?></label>
		<div class="<?php echo $usermembershipplans_edit->RightColumnClass ?>"><div <?php echo $usermembershipplans_edit->merchantid->cellAttributes() ?>>
<input type="text" data-table="usermembershipplans" data-field="x_merchantid" name="x_merchantid" id="x_merchantid" size="30" placeholder="<?php echo HtmlEncode($usermembershipplans_edit->merchantid->getPlaceHolder()) ?>" value="<?php echo $usermembershipplans_edit->merchantid->EditValue ?>"<?php echo $usermembershipplans_edit->merchantid->editAttributes() ?>>
<input type="hidden" data-table="usermembershipplans" data-field="x_merchantid" name="o_merchantid" id="o_merchantid" value="<?php echo HtmlEncode($usermembershipplans_edit->merchantid->OldValue != null ? $usermembershipplans_edit->merchantid->OldValue : $usermembershipplans_edit->merchantid->CurrentValue) ?>">
<?php echo $usermembershipplans_edit->merchantid->CustomMsg ?></div></div>
	</div>
<?php } ?>
<?php if ($usermembershipplans_edit->planid->Visible) { // planid ?>
	<div id="r_planid" class="form-group row">
		<label id="elh_usermembershipplans_planid" for="x_planid" class="<?php echo $usermembershipplans_edit->LeftColumnClass ?>"><?php echo $usermembershipplans_edit->planid->caption() ?><?php echo $usermembershipplans_edit->planid->Required ? $Language->phrase("FieldRequiredIndicator") : "" ?></label>
		<div class="<?php echo $usermembershipplans_edit->RightColumnClass ?>"><div <?php echo $usermembershipplans_edit->planid->cellAttributes() ?>>
<input type="text" data-table="usermembershipplans" data-field="x_planid" name="x_planid" id="x_planid" size="30" placeholder="<?php echo HtmlEncode($usermembershipplans_edit->planid->getPlaceHolder()) ?>" value="<?php echo $usermembershipplans_edit->planid->EditValue ?>"<?php echo $usermembershipplans_edit->planid->editAttributes() ?>>
<input type="hidden" data-table="usermembershipplans" data-field="x_planid" name="o_planid" id="o_planid" value="<?php echo HtmlEncode($usermembershipplans_edit->planid->OldValue != null ? $usermembershipplans_edit->planid->OldValue : $usermembershipplans_edit->planid->CurrentValue) ?>">
<?php echo $usermembershipplans_edit->planid->CustomMsg ?></div></div>
	</div>
<?php } ?>
<?php if ($usermembershipplans_edit->planstatus->Visible) { // planstatus ?>
	<div id="r_planstatus" class="form-group row">
		<label id="elh_usermembershipplans_planstatus" for="x_planstatus" class="<?php echo $usermembershipplans_edit->LeftColumnClass ?>"><?php echo $usermembershipplans_edit->planstatus->caption() ?><?php echo $usermembershipplans_edit->planstatus->Required ? $Language->phrase("FieldRequiredIndicator") : "" ?></label>
		<div class="<?php echo $usermembershipplans_edit->RightColumnClass ?>"><div <?php echo $usermembershipplans_edit->planstatus->cellAttributes() ?>>
<span id="el_usermembershipplans_planstatus">
<input type="text" data-table="usermembershipplans" data-field="x_planstatus" name="x_planstatus" id="x_planstatus" size="30" placeholder="<?php echo HtmlEncode($usermembershipplans_edit->planstatus->getPlaceHolder()) ?>" value="<?php echo $usermembershipplans_edit->planstatus->EditValue ?>"<?php echo $usermembershipplans_edit->planstatus->editAttributes() ?>>
</span>
<?php echo $usermembershipplans_edit->planstatus->CustomMsg ?></div></div>
	</div>
<?php } ?>
</div><!-- /page* -->
<?php if (!$usermembershipplans_edit->IsModal) { ?>
<div class="form-group row"><!-- buttons .form-group -->
	<div class="<?php echo $usermembershipplans_edit->OffsetColumnClass ?>"><!-- buttons offset -->
<button class="btn btn-primary ew-btn" name="btn-action" id="btn-action" type="submit"><?php echo $Language->phrase("SaveBtn") ?></button>
<button class="btn btn-default ew-btn" name="btn-cancel" id="btn-cancel" type="button" data-href="<?php echo $usermembershipplans_edit->getReturnUrl() ?>"><?php echo $Language->phrase("CancelBtn") ?></button>
	</div><!-- /buttons offset -->
</div><!-- /buttons .form-group -->
<?php } ?>
</form>
<?php
$usermembershipplans_edit->showPageFooter();
if (Config("DEBUG"))
	echo GetDebugMessage();
?>
<script>
loadjs.ready("load", function() {

	// Startup script
	// Write your table-specific startup script here
	// console.log("page loaded");

});
</script>
<?php include_once "footer.php"; ?>
<?php
$usermembershipplans_edit->terminate();
?>