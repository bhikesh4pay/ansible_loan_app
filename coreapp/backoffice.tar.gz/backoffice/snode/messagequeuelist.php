<?php
namespace PHPMaker2020\_4payadmin;

// Autoload
include_once "autoload.php";

// Session
if (session_status() !== PHP_SESSION_ACTIVE)
	\Delight\Cookie\Session::start(Config("COOKIE_SAMESITE")); // Init session data

// Output buffering
ob_start();
?>
<?php

// Write header
WriteHeader(FALSE);

// Create page object
$messagequeue_list = new messagequeue_list();

// Run the page
$messagequeue_list->run();

// Setup login status
SetupLoginStatus();
SetClientVar("login", LoginStatus());

// Global Page Rendering event (in userfn*.php)
Page_Rendering();

// Page Rendering event
$messagequeue_list->Page_Render();
?>
<?php include_once "header.php"; ?>
<?php if (!$messagequeue_list->isExport()) { ?>
<script>
var fmessagequeuelist, currentPageID;
loadjs.ready("head", function() {

	// Form object
	currentPageID = ew.PAGE_ID = "list";
	fmessagequeuelist = currentForm = new ew.Form("fmessagequeuelist", "list");
	fmessagequeuelist.formKeyCountName = '<?php echo $messagequeue_list->FormKeyCountName ?>';
	loadjs.done("fmessagequeuelist");
});
var fmessagequeuelistsrch;
loadjs.ready("head", function() {

	// Form object for search
	fmessagequeuelistsrch = currentSearchForm = new ew.Form("fmessagequeuelistsrch");

	// Dynamic selection lists
	// Filters

	fmessagequeuelistsrch.filterList = <?php echo $messagequeue_list->getFilterList() ?>;

	// Init search panel as collapsed
	fmessagequeuelistsrch.initSearchPanel = true;
	loadjs.done("fmessagequeuelistsrch");
});
</script>
<style type="text/css">
.ew-table-preview-row { /* main table preview row color */
	background-color: #FFFFFF; /* preview row color */
}
.ew-table-preview-row .ew-grid {
	display: table;
}
</style>
<div id="ew-preview" class="d-none"><!-- preview -->
	<div class="ew-nav-tabs"><!-- .ew-nav-tabs -->
		<ul class="nav nav-tabs"></ul>
		<div class="tab-content"><!-- .tab-content -->
			<div class="tab-pane fade active show"></div>
		</div><!-- /.tab-content -->
	</div><!-- /.ew-nav-tabs -->
</div><!-- /preview -->
<script>
loadjs.ready("head", function() {
	ew.PREVIEW_PLACEMENT = ew.CSS_FLIP ? "right" : "left";
	ew.PREVIEW_SINGLE_ROW = false;
	ew.PREVIEW_OVERLAY = false;
	loadjs("js/ewpreview.js", "preview");
});
</script>
<script>
loadjs.ready("head", function() {

	// Client script
	// Write your client script here, no need to add script tags.

});
</script>
<?php } ?>
<?php if (!$messagequeue_list->isExport()) { ?>
<div class="btn-toolbar ew-toolbar">
<?php if ($messagequeue_list->TotalRecords > 0 && $messagequeue_list->ExportOptions->visible()) { ?>
<?php $messagequeue_list->ExportOptions->render("body") ?>
<?php } ?>
<?php if ($messagequeue_list->ImportOptions->visible()) { ?>
<?php $messagequeue_list->ImportOptions->render("body") ?>
<?php } ?>
<?php if ($messagequeue_list->SearchOptions->visible()) { ?>
<?php $messagequeue_list->SearchOptions->render("body") ?>
<?php } ?>
<?php if ($messagequeue_list->FilterOptions->visible()) { ?>
<?php $messagequeue_list->FilterOptions->render("body") ?>
<?php } ?>
<div class="clearfix"></div>
</div>
<?php } ?>
<?php
$messagequeue_list->renderOtherOptions();
?>
<?php if ($Security->CanSearch()) { ?>
<?php if (!$messagequeue_list->isExport() && !$messagequeue->CurrentAction) { ?>
<form name="fmessagequeuelistsrch" id="fmessagequeuelistsrch" class="form-inline ew-form ew-ext-search-form" action="<?php echo CurrentPageName() ?>">
<div id="fmessagequeuelistsrch-search-panel" class="<?php echo $messagequeue_list->SearchPanelClass ?>">
<input type="hidden" name="cmd" value="search">
<input type="hidden" name="t" value="messagequeue">
	<div class="ew-extended-search">
<div id="xsr_<?php echo $messagequeue_list->SearchRowCount + 1 ?>" class="ew-row d-sm-flex">
	<div class="ew-quick-search input-group">
		<input type="text" name="<?php echo Config("TABLE_BASIC_SEARCH") ?>" id="<?php echo Config("TABLE_BASIC_SEARCH") ?>" class="form-control" value="<?php echo HtmlEncode($messagequeue_list->BasicSearch->getKeyword()) ?>" placeholder="<?php echo HtmlEncode($Language->phrase("Search")) ?>">
		<input type="hidden" name="<?php echo Config("TABLE_BASIC_SEARCH_TYPE") ?>" id="<?php echo Config("TABLE_BASIC_SEARCH_TYPE") ?>" value="<?php echo HtmlEncode($messagequeue_list->BasicSearch->getType()) ?>">
		<div class="input-group-append">
			<button class="btn btn-primary" name="btn-submit" id="btn-submit" type="submit"><?php echo $Language->phrase("SearchBtn") ?></button>
			<button type="button" data-toggle="dropdown" class="btn btn-primary dropdown-toggle dropdown-toggle-split" aria-haspopup="true" aria-expanded="false"><span id="searchtype"><?php echo $messagequeue_list->BasicSearch->getTypeNameShort() ?></span></button>
			<div class="dropdown-menu dropdown-menu-right">
				<a class="dropdown-item<?php if ($messagequeue_list->BasicSearch->getType() == "") { ?> active<?php } ?>" href="#" onclick="return ew.setSearchType(this);"><?php echo $Language->phrase("QuickSearchAuto") ?></a>
				<a class="dropdown-item<?php if ($messagequeue_list->BasicSearch->getType() == "=") { ?> active<?php } ?>" href="#" onclick="return ew.setSearchType(this, '=');"><?php echo $Language->phrase("QuickSearchExact") ?></a>
				<a class="dropdown-item<?php if ($messagequeue_list->BasicSearch->getType() == "AND") { ?> active<?php } ?>" href="#" onclick="return ew.setSearchType(this, 'AND');"><?php echo $Language->phrase("QuickSearchAll") ?></a>
				<a class="dropdown-item<?php if ($messagequeue_list->BasicSearch->getType() == "OR") { ?> active<?php } ?>" href="#" onclick="return ew.setSearchType(this, 'OR');"><?php echo $Language->phrase("QuickSearchAny") ?></a>
			</div>
		</div>
	</div>
</div>
	</div><!-- /.ew-extended-search -->
</div><!-- /.ew-search-panel -->
</form>
<?php } ?>
<?php } ?>
<?php $messagequeue_list->showPageHeader(); ?>
<?php
$messagequeue_list->showMessage();
?>
<?php if ($messagequeue_list->TotalRecords > 0 || $messagequeue->CurrentAction) { ?>
<div class="card ew-card ew-grid<?php if ($messagequeue_list->isAddOrEdit()) { ?> ew-grid-add-edit<?php } ?> messagequeue">
<form name="fmessagequeuelist" id="fmessagequeuelist" class="form-inline ew-form ew-list-form" action="<?php echo CurrentPageName() ?>" method="post">
<?php if ($Page->CheckToken) { ?>
<input type="hidden" name="<?php echo Config("TOKEN_NAME") ?>" value="<?php echo $Page->Token ?>">
<?php } ?>
<input type="hidden" name="t" value="messagequeue">
<div id="gmp_messagequeue" class="<?php echo ResponsiveTableClass() ?>card-body ew-grid-middle-panel">
<?php if ($messagequeue_list->TotalRecords > 0 || $messagequeue_list->isGridEdit()) { ?>
<table id="tbl_messagequeuelist" class="table ew-table"><!-- .ew-table -->
<thead>
	<tr class="ew-table-header">
<?php

// Header row
$messagequeue->RowType = ROWTYPE_HEADER;

// Render list options
$messagequeue_list->renderListOptions();

// Render list options (header, left)
$messagequeue_list->ListOptions->render("header", "left");
?>
<?php if ($messagequeue_list->queueid->Visible) { // queueid ?>
	<?php if ($messagequeue_list->SortUrl($messagequeue_list->queueid) == "") { ?>
		<th data-name="queueid" class="<?php echo $messagequeue_list->queueid->headerCellClass() ?>"><div id="elh_messagequeue_queueid" class="messagequeue_queueid"><div class="ew-table-header-caption"><?php echo $messagequeue_list->queueid->caption() ?></div></div></th>
	<?php } else { ?>
		<th data-name="queueid" class="<?php echo $messagequeue_list->queueid->headerCellClass() ?>"><div class="ew-pointer" onclick="ew.sort(event, '<?php echo $messagequeue_list->SortUrl($messagequeue_list->queueid) ?>', 1);"><div id="elh_messagequeue_queueid" class="messagequeue_queueid">
			<div class="ew-table-header-btn"><span class="ew-table-header-caption"><?php echo $messagequeue_list->queueid->caption() ?></span><span class="ew-table-header-sort"><?php if ($messagequeue_list->queueid->getSort() == "ASC") { ?><i class="fas fa-sort-up"></i><?php } elseif ($messagequeue_list->queueid->getSort() == "DESC") { ?><i class="fas fa-sort-down"></i><?php } ?></span></div>
		</div></div></th>
	<?php } ?>
<?php } ?>
<?php if ($messagequeue_list->merchantid->Visible) { // merchantid ?>
	<?php if ($messagequeue_list->SortUrl($messagequeue_list->merchantid) == "") { ?>
		<th data-name="merchantid" class="<?php echo $messagequeue_list->merchantid->headerCellClass() ?>"><div id="elh_messagequeue_merchantid" class="messagequeue_merchantid"><div class="ew-table-header-caption"><?php echo $messagequeue_list->merchantid->caption() ?></div></div></th>
	<?php } else { ?>
		<th data-name="merchantid" class="<?php echo $messagequeue_list->merchantid->headerCellClass() ?>"><div class="ew-pointer" onclick="ew.sort(event, '<?php echo $messagequeue_list->SortUrl($messagequeue_list->merchantid) ?>', 1);"><div id="elh_messagequeue_merchantid" class="messagequeue_merchantid">
			<div class="ew-table-header-btn"><span class="ew-table-header-caption"><?php echo $messagequeue_list->merchantid->caption() ?></span><span class="ew-table-header-sort"><?php if ($messagequeue_list->merchantid->getSort() == "ASC") { ?><i class="fas fa-sort-up"></i><?php } elseif ($messagequeue_list->merchantid->getSort() == "DESC") { ?><i class="fas fa-sort-down"></i><?php } ?></span></div>
		</div></div></th>
	<?php } ?>
<?php } ?>
<?php if ($messagequeue_list->completeddate->Visible) { // completeddate ?>
	<?php if ($messagequeue_list->SortUrl($messagequeue_list->completeddate) == "") { ?>
		<th data-name="completeddate" class="<?php echo $messagequeue_list->completeddate->headerCellClass() ?>"><div id="elh_messagequeue_completeddate" class="messagequeue_completeddate"><div class="ew-table-header-caption"><?php echo $messagequeue_list->completeddate->caption() ?></div></div></th>
	<?php } else { ?>
		<th data-name="completeddate" class="<?php echo $messagequeue_list->completeddate->headerCellClass() ?>"><div class="ew-pointer" onclick="ew.sort(event, '<?php echo $messagequeue_list->SortUrl($messagequeue_list->completeddate) ?>', 1);"><div id="elh_messagequeue_completeddate" class="messagequeue_completeddate">
			<div class="ew-table-header-btn"><span class="ew-table-header-caption"><?php echo $messagequeue_list->completeddate->caption() ?></span><span class="ew-table-header-sort"><?php if ($messagequeue_list->completeddate->getSort() == "ASC") { ?><i class="fas fa-sort-up"></i><?php } elseif ($messagequeue_list->completeddate->getSort() == "DESC") { ?><i class="fas fa-sort-down"></i><?php } ?></span></div>
		</div></div></th>
	<?php } ?>
<?php } ?>
<?php if ($messagequeue_list->status->Visible) { // status ?>
	<?php if ($messagequeue_list->SortUrl($messagequeue_list->status) == "") { ?>
		<th data-name="status" class="<?php echo $messagequeue_list->status->headerCellClass() ?>"><div id="elh_messagequeue_status" class="messagequeue_status"><div class="ew-table-header-caption"><?php echo $messagequeue_list->status->caption() ?></div></div></th>
	<?php } else { ?>
		<th data-name="status" class="<?php echo $messagequeue_list->status->headerCellClass() ?>"><div class="ew-pointer" onclick="ew.sort(event, '<?php echo $messagequeue_list->SortUrl($messagequeue_list->status) ?>', 1);"><div id="elh_messagequeue_status" class="messagequeue_status">
			<div class="ew-table-header-btn"><span class="ew-table-header-caption"><?php echo $messagequeue_list->status->caption() ?></span><span class="ew-table-header-sort"><?php if ($messagequeue_list->status->getSort() == "ASC") { ?><i class="fas fa-sort-up"></i><?php } elseif ($messagequeue_list->status->getSort() == "DESC") { ?><i class="fas fa-sort-down"></i><?php } ?></span></div>
		</div></div></th>
	<?php } ?>
<?php } ?>
<?php if ($messagequeue_list->message->Visible) { // message ?>
	<?php if ($messagequeue_list->SortUrl($messagequeue_list->message) == "") { ?>
		<th data-name="message" class="<?php echo $messagequeue_list->message->headerCellClass() ?>"><div id="elh_messagequeue_message" class="messagequeue_message"><div class="ew-table-header-caption"><?php echo $messagequeue_list->message->caption() ?></div></div></th>
	<?php } else { ?>
		<th data-name="message" class="<?php echo $messagequeue_list->message->headerCellClass() ?>"><div class="ew-pointer" onclick="ew.sort(event, '<?php echo $messagequeue_list->SortUrl($messagequeue_list->message) ?>', 1);"><div id="elh_messagequeue_message" class="messagequeue_message">
			<div class="ew-table-header-btn"><span class="ew-table-header-caption"><?php echo $messagequeue_list->message->caption() ?><?php echo $Language->phrase("SrchLegend") ?></span><span class="ew-table-header-sort"><?php if ($messagequeue_list->message->getSort() == "ASC") { ?><i class="fas fa-sort-up"></i><?php } elseif ($messagequeue_list->message->getSort() == "DESC") { ?><i class="fas fa-sort-down"></i><?php } ?></span></div>
		</div></div></th>
	<?php } ?>
<?php } ?>
<?php

// Render list options (header, right)
$messagequeue_list->ListOptions->render("header", "right");
?>
	</tr>
</thead>
<tbody>
<?php
if ($messagequeue_list->ExportAll && $messagequeue_list->isExport()) {
	$messagequeue_list->StopRecord = $messagequeue_list->TotalRecords;
} else {

	// Set the last record to display
	if ($messagequeue_list->TotalRecords > $messagequeue_list->StartRecord + $messagequeue_list->DisplayRecords - 1)
		$messagequeue_list->StopRecord = $messagequeue_list->StartRecord + $messagequeue_list->DisplayRecords - 1;
	else
		$messagequeue_list->StopRecord = $messagequeue_list->TotalRecords;
}
$messagequeue_list->RecordCount = $messagequeue_list->StartRecord - 1;
if ($messagequeue_list->Recordset && !$messagequeue_list->Recordset->EOF) {
	$messagequeue_list->Recordset->moveFirst();
	$selectLimit = $messagequeue_list->UseSelectLimit;
	if (!$selectLimit && $messagequeue_list->StartRecord > 1)
		$messagequeue_list->Recordset->move($messagequeue_list->StartRecord - 1);
} elseif (!$messagequeue->AllowAddDeleteRow && $messagequeue_list->StopRecord == 0) {
	$messagequeue_list->StopRecord = $messagequeue->GridAddRowCount;
}

// Initialize aggregate
$messagequeue->RowType = ROWTYPE_AGGREGATEINIT;
$messagequeue->resetAttributes();
$messagequeue_list->renderRow();
while ($messagequeue_list->RecordCount < $messagequeue_list->StopRecord) {
	$messagequeue_list->RecordCount++;
	if ($messagequeue_list->RecordCount >= $messagequeue_list->StartRecord) {
		$messagequeue_list->RowCount++;

		// Set up key count
		$messagequeue_list->KeyCount = $messagequeue_list->RowIndex;

		// Init row class and style
		$messagequeue->resetAttributes();
		$messagequeue->CssClass = "";
		if ($messagequeue_list->isGridAdd()) {
		} else {
			$messagequeue_list->loadRowValues($messagequeue_list->Recordset); // Load row values
		}
		$messagequeue->RowType = ROWTYPE_VIEW; // Render view

		// Set up row id / data-rowindex
		$messagequeue->RowAttrs->merge(["data-rowindex" => $messagequeue_list->RowCount, "id" => "r" . $messagequeue_list->RowCount . "_messagequeue", "data-rowtype" => $messagequeue->RowType]);

		// Render row
		$messagequeue_list->renderRow();

		// Render list options
		$messagequeue_list->renderListOptions();
?>
	<tr <?php echo $messagequeue->rowAttributes() ?>>
<?php

// Render list options (body, left)
$messagequeue_list->ListOptions->render("body", "left", $messagequeue_list->RowCount);
?>
	<?php if ($messagequeue_list->queueid->Visible) { // queueid ?>
		<td data-name="queueid" <?php echo $messagequeue_list->queueid->cellAttributes() ?>>
<span id="el<?php echo $messagequeue_list->RowCount ?>_messagequeue_queueid">
<span<?php echo $messagequeue_list->queueid->viewAttributes() ?>><?php echo $messagequeue_list->queueid->getViewValue() ?></span>
</span>
</td>
	<?php } ?>
	<?php if ($messagequeue_list->merchantid->Visible) { // merchantid ?>
		<td data-name="merchantid" <?php echo $messagequeue_list->merchantid->cellAttributes() ?>>
<span id="el<?php echo $messagequeue_list->RowCount ?>_messagequeue_merchantid">
<span<?php echo $messagequeue_list->merchantid->viewAttributes() ?>><?php echo $messagequeue_list->merchantid->getViewValue() ?></span>
</span>
</td>
	<?php } ?>
	<?php if ($messagequeue_list->completeddate->Visible) { // completeddate ?>
		<td data-name="completeddate" <?php echo $messagequeue_list->completeddate->cellAttributes() ?>>
<span id="el<?php echo $messagequeue_list->RowCount ?>_messagequeue_completeddate">
<span<?php echo $messagequeue_list->completeddate->viewAttributes() ?>><?php echo $messagequeue_list->completeddate->getViewValue() ?></span>
</span>
</td>
	<?php } ?>
	<?php if ($messagequeue_list->status->Visible) { // status ?>
		<td data-name="status" <?php echo $messagequeue_list->status->cellAttributes() ?>>
<span id="el<?php echo $messagequeue_list->RowCount ?>_messagequeue_status">
<span<?php echo $messagequeue_list->status->viewAttributes() ?>><?php echo $messagequeue_list->status->getViewValue() ?></span>
</span>
</td>
	<?php } ?>
	<?php if ($messagequeue_list->message->Visible) { // message ?>
		<td data-name="message" <?php echo $messagequeue_list->message->cellAttributes() ?>>
<span id="el<?php echo $messagequeue_list->RowCount ?>_messagequeue_message">
<span<?php echo $messagequeue_list->message->viewAttributes() ?>><?php echo $messagequeue_list->message->getViewValue() ?></span>
</span>
</td>
	<?php } ?>
<?php

// Render list options (body, right)
$messagequeue_list->ListOptions->render("body", "right", $messagequeue_list->RowCount);
?>
	</tr>
<?php
	}
	if (!$messagequeue_list->isGridAdd())
		$messagequeue_list->Recordset->moveNext();
}
?>
</tbody>
</table><!-- /.ew-table -->
<?php } ?>
</div><!-- /.ew-grid-middle-panel -->
<?php if (!$messagequeue->CurrentAction) { ?>
<input type="hidden" name="action" id="action" value="">
<?php } ?>
</form><!-- /.ew-list-form -->
<?php

// Close recordset
if ($messagequeue_list->Recordset)
	$messagequeue_list->Recordset->Close();
?>
<?php if (!$messagequeue_list->isExport()) { ?>
<div class="card-footer ew-grid-lower-panel">
<?php if (!$messagequeue_list->isGridAdd()) { ?>
<form name="ew-pager-form" class="form-inline ew-form ew-pager-form" action="<?php echo CurrentPageName() ?>">
<?php echo $messagequeue_list->Pager->render() ?>
</form>
<?php } ?>
<div class="ew-list-other-options">
<?php $messagequeue_list->OtherOptions->render("body", "bottom") ?>
</div>
<div class="clearfix"></div>
</div>
<?php } ?>
</div><!-- /.ew-grid -->
<?php } ?>
<?php if ($messagequeue_list->TotalRecords == 0 && !$messagequeue->CurrentAction) { // Show other options ?>
<div class="ew-list-other-options">
<?php $messagequeue_list->OtherOptions->render("body") ?>
</div>
<div class="clearfix"></div>
<?php } ?>
<?php
$messagequeue_list->showPageFooter();
if (Config("DEBUG"))
	echo GetDebugMessage();
?>
<?php if (!$messagequeue_list->isExport()) { ?>
<script>
loadjs.ready("load", function() {

	// Startup script
	// Write your table-specific startup script here
	// console.log("page loaded");

});
</script>
<?php } ?>
<?php include_once "footer.php"; ?>
<?php
$messagequeue_list->terminate();
?>