<?php
namespace PHPMaker2020\_4payadmin;

// Autoload
include_once "autoload.php";

// Session
if (session_status() !== PHP_SESSION_ACTIVE)
	\Delight\Cookie\Session::start(Config("COOKIE_SAMESITE")); // Init session data

// Output buffering
ob_start();
?>
<?php

// Write header
WriteHeader(FALSE);

// Create page object
$uitemptransaction_delete = new uitemptransaction_delete();

// Run the page
$uitemptransaction_delete->run();

// Setup login status
SetupLoginStatus();
SetClientVar("login", LoginStatus());

// Global Page Rendering event (in userfn*.php)
Page_Rendering();

// Page Rendering event
$uitemptransaction_delete->Page_Render();
?>
<?php include_once "header.php"; ?>
<script>
var fuitemptransactiondelete, currentPageID;
loadjs.ready("head", function() {

	// Form object
	currentPageID = ew.PAGE_ID = "delete";
	fuitemptransactiondelete = currentForm = new ew.Form("fuitemptransactiondelete", "delete");
	loadjs.done("fuitemptransactiondelete");
});
</script>
<script>
loadjs.ready("head", function() {

	// Client script
	// Write your client script here, no need to add script tags.

});
</script>
<?php $uitemptransaction_delete->showPageHeader(); ?>
<?php
$uitemptransaction_delete->showMessage();
?>
<form name="fuitemptransactiondelete" id="fuitemptransactiondelete" class="form-inline ew-form ew-delete-form" action="<?php echo CurrentPageName() ?>" method="post">
<?php if ($Page->CheckToken) { ?>
<input type="hidden" name="<?php echo Config("TOKEN_NAME") ?>" value="<?php echo $Page->Token ?>">
<?php } ?>
<input type="hidden" name="t" value="uitemptransaction">
<input type="hidden" name="action" id="action" value="delete">
<?php foreach ($uitemptransaction_delete->RecKeys as $key) { ?>
<?php $keyvalue = is_array($key) ? implode(Config("COMPOSITE_KEY_SEPARATOR"), $key) : $key; ?>
<input type="hidden" name="key_m[]" value="<?php echo HtmlEncode($keyvalue) ?>">
<?php } ?>
<div class="card ew-card ew-grid">
<div class="<?php echo ResponsiveTableClass() ?>card-body ew-grid-middle-panel">
<table class="table ew-table">
	<thead>
	<tr class="ew-table-header">
<?php if ($uitemptransaction_delete->recid->Visible) { // recid ?>
		<th class="<?php echo $uitemptransaction_delete->recid->headerCellClass() ?>"><span id="elh_uitemptransaction_recid" class="uitemptransaction_recid"><?php echo $uitemptransaction_delete->recid->caption() ?></span></th>
<?php } ?>
<?php if ($uitemptransaction_delete->_userid->Visible) { // userid ?>
		<th class="<?php echo $uitemptransaction_delete->_userid->headerCellClass() ?>"><span id="elh_uitemptransaction__userid" class="uitemptransaction__userid"><?php echo $uitemptransaction_delete->_userid->caption() ?></span></th>
<?php } ?>
<?php if ($uitemptransaction_delete->refdata->Visible) { // refdata ?>
		<th class="<?php echo $uitemptransaction_delete->refdata->headerCellClass() ?>"><span id="elh_uitemptransaction_refdata" class="uitemptransaction_refdata"><?php echo $uitemptransaction_delete->refdata->caption() ?></span></th>
<?php } ?>
<?php if ($uitemptransaction_delete->creationtime->Visible) { // creationtime ?>
		<th class="<?php echo $uitemptransaction_delete->creationtime->headerCellClass() ?>"><span id="elh_uitemptransaction_creationtime" class="uitemptransaction_creationtime"><?php echo $uitemptransaction_delete->creationtime->caption() ?></span></th>
<?php } ?>
<?php if ($uitemptransaction_delete->expirytime->Visible) { // expirytime ?>
		<th class="<?php echo $uitemptransaction_delete->expirytime->headerCellClass() ?>"><span id="elh_uitemptransaction_expirytime" class="uitemptransaction_expirytime"><?php echo $uitemptransaction_delete->expirytime->caption() ?></span></th>
<?php } ?>
	</tr>
	</thead>
	<tbody>
<?php
$uitemptransaction_delete->RecordCount = 0;
$i = 0;
while (!$uitemptransaction_delete->Recordset->EOF) {
	$uitemptransaction_delete->RecordCount++;
	$uitemptransaction_delete->RowCount++;

	// Set row properties
	$uitemptransaction->resetAttributes();
	$uitemptransaction->RowType = ROWTYPE_VIEW; // View

	// Get the field contents
	$uitemptransaction_delete->loadRowValues($uitemptransaction_delete->Recordset);

	// Render row
	$uitemptransaction_delete->renderRow();
?>
	<tr <?php echo $uitemptransaction->rowAttributes() ?>>
<?php if ($uitemptransaction_delete->recid->Visible) { // recid ?>
		<td <?php echo $uitemptransaction_delete->recid->cellAttributes() ?>>
<span id="el<?php echo $uitemptransaction_delete->RowCount ?>_uitemptransaction_recid" class="uitemptransaction_recid">
<span<?php echo $uitemptransaction_delete->recid->viewAttributes() ?>><?php echo $uitemptransaction_delete->recid->getViewValue() ?></span>
</span>
</td>
<?php } ?>
<?php if ($uitemptransaction_delete->_userid->Visible) { // userid ?>
		<td <?php echo $uitemptransaction_delete->_userid->cellAttributes() ?>>
<span id="el<?php echo $uitemptransaction_delete->RowCount ?>_uitemptransaction__userid" class="uitemptransaction__userid">
<span<?php echo $uitemptransaction_delete->_userid->viewAttributes() ?>><?php echo $uitemptransaction_delete->_userid->getViewValue() ?></span>
</span>
</td>
<?php } ?>
<?php if ($uitemptransaction_delete->refdata->Visible) { // refdata ?>
		<td <?php echo $uitemptransaction_delete->refdata->cellAttributes() ?>>
<span id="el<?php echo $uitemptransaction_delete->RowCount ?>_uitemptransaction_refdata" class="uitemptransaction_refdata">
<span<?php echo $uitemptransaction_delete->refdata->viewAttributes() ?>><?php echo $uitemptransaction_delete->refdata->getViewValue() ?></span>
</span>
</td>
<?php } ?>
<?php if ($uitemptransaction_delete->creationtime->Visible) { // creationtime ?>
		<td <?php echo $uitemptransaction_delete->creationtime->cellAttributes() ?>>
<span id="el<?php echo $uitemptransaction_delete->RowCount ?>_uitemptransaction_creationtime" class="uitemptransaction_creationtime">
<span<?php echo $uitemptransaction_delete->creationtime->viewAttributes() ?>><?php echo $uitemptransaction_delete->creationtime->getViewValue() ?></span>
</span>
</td>
<?php } ?>
<?php if ($uitemptransaction_delete->expirytime->Visible) { // expirytime ?>
		<td <?php echo $uitemptransaction_delete->expirytime->cellAttributes() ?>>
<span id="el<?php echo $uitemptransaction_delete->RowCount ?>_uitemptransaction_expirytime" class="uitemptransaction_expirytime">
<span<?php echo $uitemptransaction_delete->expirytime->viewAttributes() ?>><?php echo $uitemptransaction_delete->expirytime->getViewValue() ?></span>
</span>
</td>
<?php } ?>
	</tr>
<?php
	$uitemptransaction_delete->Recordset->moveNext();
}
$uitemptransaction_delete->Recordset->close();
?>
</tbody>
</table>
</div>
</div>
<div>
<button class="btn btn-primary ew-btn" name="btn-action" id="btn-action" type="submit"><?php echo $Language->phrase("DeleteBtn") ?></button>
<button class="btn btn-default ew-btn" name="btn-cancel" id="btn-cancel" type="button" data-href="<?php echo $uitemptransaction_delete->getReturnUrl() ?>"><?php echo $Language->phrase("CancelBtn") ?></button>
</div>
</form>
<?php
$uitemptransaction_delete->showPageFooter();
if (Config("DEBUG"))
	echo GetDebugMessage();
?>
<script>
loadjs.ready("load", function() {

	// Startup script
	// Write your table-specific startup script here
	// console.log("page loaded");

});
</script>
<?php include_once "footer.php"; ?>
<?php
$uitemptransaction_delete->terminate();
?>