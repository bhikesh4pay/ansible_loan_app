<?php
namespace PHPMaker2020\_4payadmin;

// Autoload
include_once "autoload.php";

// Session
if (session_status() !== PHP_SESSION_ACTIVE)
	\Delight\Cookie\Session::start(Config("COOKIE_SAMESITE")); // Init session data

// Output buffering
ob_start();
?>
<?php

// Write header
WriteHeader(FALSE);

// Create page object
$merchant_copy1_view = new merchant_copy1_view();

// Run the page
$merchant_copy1_view->run();

// Setup login status
SetupLoginStatus();
SetClientVar("login", LoginStatus());

// Global Page Rendering event (in userfn*.php)
Page_Rendering();

// Page Rendering event
$merchant_copy1_view->Page_Render();
?>
<?php include_once "header.php"; ?>
<?php if (!$merchant_copy1_view->isExport()) { ?>
<script>
var fmerchant_copy1view, currentPageID;
loadjs.ready("head", function() {

	// Form object
	currentPageID = ew.PAGE_ID = "view";
	fmerchant_copy1view = currentForm = new ew.Form("fmerchant_copy1view", "view");
	loadjs.done("fmerchant_copy1view");
});
</script>
<script>
loadjs.ready("head", function() {

	// Client script
	// Write your client script here, no need to add script tags.

});
</script>
<?php } ?>
<?php if (!$merchant_copy1_view->isExport()) { ?>
<div class="btn-toolbar ew-toolbar">
<?php $merchant_copy1_view->ExportOptions->render("body") ?>
<?php $merchant_copy1_view->OtherOptions->render("body") ?>
<div class="clearfix"></div>
</div>
<?php } ?>
<?php $merchant_copy1_view->showPageHeader(); ?>
<?php
$merchant_copy1_view->showMessage();
?>
<form name="fmerchant_copy1view" id="fmerchant_copy1view" class="form-inline ew-form ew-view-form" action="<?php echo CurrentPageName() ?>" method="post">
<?php if ($Page->CheckToken) { ?>
<input type="hidden" name="<?php echo Config("TOKEN_NAME") ?>" value="<?php echo $Page->Token ?>">
<?php } ?>
<input type="hidden" name="t" value="merchant_copy1">
<input type="hidden" name="modal" value="<?php echo (int)$merchant_copy1_view->IsModal ?>">
<table class="table table-striped table-sm ew-view-table">
<?php if ($merchant_copy1_view->_userid->Visible) { // userid ?>
	<tr id="r__userid">
		<td class="<?php echo $merchant_copy1_view->TableLeftColumnClass ?>"><span id="elh_merchant_copy1__userid"><?php echo $merchant_copy1_view->_userid->caption() ?></span></td>
		<td data-name="_userid" <?php echo $merchant_copy1_view->_userid->cellAttributes() ?>>
<span id="el_merchant_copy1__userid">
<span<?php echo $merchant_copy1_view->_userid->viewAttributes() ?>><?php echo $merchant_copy1_view->_userid->getViewValue() ?></span>
</span>
</td>
	</tr>
<?php } ?>
<?php if ($merchant_copy1_view->changed->Visible) { // changed ?>
	<tr id="r_changed">
		<td class="<?php echo $merchant_copy1_view->TableLeftColumnClass ?>"><span id="elh_merchant_copy1_changed"><?php echo $merchant_copy1_view->changed->caption() ?></span></td>
		<td data-name="changed" <?php echo $merchant_copy1_view->changed->cellAttributes() ?>>
<span id="el_merchant_copy1_changed">
<span<?php echo $merchant_copy1_view->changed->viewAttributes() ?>><?php echo $merchant_copy1_view->changed->getViewValue() ?></span>
</span>
</td>
	</tr>
<?php } ?>
<?php if ($merchant_copy1_view->active->Visible) { // active ?>
	<tr id="r_active">
		<td class="<?php echo $merchant_copy1_view->TableLeftColumnClass ?>"><span id="elh_merchant_copy1_active"><?php echo $merchant_copy1_view->active->caption() ?></span></td>
		<td data-name="active" <?php echo $merchant_copy1_view->active->cellAttributes() ?>>
<span id="el_merchant_copy1_active">
<span<?php echo $merchant_copy1_view->active->viewAttributes() ?>><?php echo $merchant_copy1_view->active->getViewValue() ?></span>
</span>
</td>
	</tr>
<?php } ?>
<?php if ($merchant_copy1_view->tipallowed->Visible) { // tipallowed ?>
	<tr id="r_tipallowed">
		<td class="<?php echo $merchant_copy1_view->TableLeftColumnClass ?>"><span id="elh_merchant_copy1_tipallowed"><?php echo $merchant_copy1_view->tipallowed->caption() ?></span></td>
		<td data-name="tipallowed" <?php echo $merchant_copy1_view->tipallowed->cellAttributes() ?>>
<span id="el_merchant_copy1_tipallowed">
<span<?php echo $merchant_copy1_view->tipallowed->viewAttributes() ?>><?php echo $merchant_copy1_view->tipallowed->getViewValue() ?></span>
</span>
</td>
	</tr>
<?php } ?>
<?php if ($merchant_copy1_view->merchanttoaddtip->Visible) { // merchanttoaddtip ?>
	<tr id="r_merchanttoaddtip">
		<td class="<?php echo $merchant_copy1_view->TableLeftColumnClass ?>"><span id="elh_merchant_copy1_merchanttoaddtip"><?php echo $merchant_copy1_view->merchanttoaddtip->caption() ?></span></td>
		<td data-name="merchanttoaddtip" <?php echo $merchant_copy1_view->merchanttoaddtip->cellAttributes() ?>>
<span id="el_merchant_copy1_merchanttoaddtip">
<span<?php echo $merchant_copy1_view->merchanttoaddtip->viewAttributes() ?>><?php echo $merchant_copy1_view->merchanttoaddtip->getViewValue() ?></span>
</span>
</td>
	</tr>
<?php } ?>
<?php if ($merchant_copy1_view->pis->Visible) { // pis ?>
	<tr id="r_pis">
		<td class="<?php echo $merchant_copy1_view->TableLeftColumnClass ?>"><span id="elh_merchant_copy1_pis"><?php echo $merchant_copy1_view->pis->caption() ?></span></td>
		<td data-name="pis" <?php echo $merchant_copy1_view->pis->cellAttributes() ?>>
<span id="el_merchant_copy1_pis">
<span<?php echo $merchant_copy1_view->pis->viewAttributes() ?>><?php echo $merchant_copy1_view->pis->getViewValue() ?></span>
</span>
</td>
	</tr>
<?php } ?>
<?php if ($merchant_copy1_view->ratetabletype->Visible) { // ratetabletype ?>
	<tr id="r_ratetabletype">
		<td class="<?php echo $merchant_copy1_view->TableLeftColumnClass ?>"><span id="elh_merchant_copy1_ratetabletype"><?php echo $merchant_copy1_view->ratetabletype->caption() ?></span></td>
		<td data-name="ratetabletype" <?php echo $merchant_copy1_view->ratetabletype->cellAttributes() ?>>
<span id="el_merchant_copy1_ratetabletype">
<span<?php echo $merchant_copy1_view->ratetabletype->viewAttributes() ?>><?php echo $merchant_copy1_view->ratetabletype->getViewValue() ?></span>
</span>
</td>
	</tr>
<?php } ?>
<?php if ($merchant_copy1_view->ratetableid->Visible) { // ratetableid ?>
	<tr id="r_ratetableid">
		<td class="<?php echo $merchant_copy1_view->TableLeftColumnClass ?>"><span id="elh_merchant_copy1_ratetableid"><?php echo $merchant_copy1_view->ratetableid->caption() ?></span></td>
		<td data-name="ratetableid" <?php echo $merchant_copy1_view->ratetableid->cellAttributes() ?>>
<span id="el_merchant_copy1_ratetableid">
<span<?php echo $merchant_copy1_view->ratetableid->viewAttributes() ?>><?php echo $merchant_copy1_view->ratetableid->getViewValue() ?></span>
</span>
</td>
	</tr>
<?php } ?>
<?php if ($merchant_copy1_view->officialdocnumber->Visible) { // officialdocnumber ?>
	<tr id="r_officialdocnumber">
		<td class="<?php echo $merchant_copy1_view->TableLeftColumnClass ?>"><span id="elh_merchant_copy1_officialdocnumber"><?php echo $merchant_copy1_view->officialdocnumber->caption() ?></span></td>
		<td data-name="officialdocnumber" <?php echo $merchant_copy1_view->officialdocnumber->cellAttributes() ?>>
<span id="el_merchant_copy1_officialdocnumber">
<span<?php echo $merchant_copy1_view->officialdocnumber->viewAttributes() ?>><?php echo $merchant_copy1_view->officialdocnumber->getViewValue() ?></span>
</span>
</td>
	</tr>
<?php } ?>
<?php if ($merchant_copy1_view->officialdocname->Visible) { // officialdocname ?>
	<tr id="r_officialdocname">
		<td class="<?php echo $merchant_copy1_view->TableLeftColumnClass ?>"><span id="elh_merchant_copy1_officialdocname"><?php echo $merchant_copy1_view->officialdocname->caption() ?></span></td>
		<td data-name="officialdocname" <?php echo $merchant_copy1_view->officialdocname->cellAttributes() ?>>
<span id="el_merchant_copy1_officialdocname">
<span<?php echo $merchant_copy1_view->officialdocname->viewAttributes() ?>><?php echo $merchant_copy1_view->officialdocname->getViewValue() ?></span>
</span>
</td>
	</tr>
<?php } ?>
<?php if ($merchant_copy1_view->businessname->Visible) { // businessname ?>
	<tr id="r_businessname">
		<td class="<?php echo $merchant_copy1_view->TableLeftColumnClass ?>"><span id="elh_merchant_copy1_businessname"><?php echo $merchant_copy1_view->businessname->caption() ?></span></td>
		<td data-name="businessname" <?php echo $merchant_copy1_view->businessname->cellAttributes() ?>>
<span id="el_merchant_copy1_businessname">
<span<?php echo $merchant_copy1_view->businessname->viewAttributes() ?>><?php echo $merchant_copy1_view->businessname->getViewValue() ?></span>
</span>
</td>
	</tr>
<?php } ?>
<?php if ($merchant_copy1_view->softposid->Visible) { // softposid ?>
	<tr id="r_softposid">
		<td class="<?php echo $merchant_copy1_view->TableLeftColumnClass ?>"><span id="elh_merchant_copy1_softposid"><?php echo $merchant_copy1_view->softposid->caption() ?></span></td>
		<td data-name="softposid" <?php echo $merchant_copy1_view->softposid->cellAttributes() ?>>
<span id="el_merchant_copy1_softposid">
<span<?php echo $merchant_copy1_view->softposid->viewAttributes() ?>><?php echo $merchant_copy1_view->softposid->getViewValue() ?></span>
</span>
</td>
	</tr>
<?php } ?>
<?php if ($merchant_copy1_view->taxamount->Visible) { // taxamount ?>
	<tr id="r_taxamount">
		<td class="<?php echo $merchant_copy1_view->TableLeftColumnClass ?>"><span id="elh_merchant_copy1_taxamount"><?php echo $merchant_copy1_view->taxamount->caption() ?></span></td>
		<td data-name="taxamount" <?php echo $merchant_copy1_view->taxamount->cellAttributes() ?>>
<span id="el_merchant_copy1_taxamount">
<span<?php echo $merchant_copy1_view->taxamount->viewAttributes() ?>><?php echo $merchant_copy1_view->taxamount->getViewValue() ?></span>
</span>
</td>
	</tr>
<?php } ?>
<?php if ($merchant_copy1_view->variabletax->Visible) { // variabletax ?>
	<tr id="r_variabletax">
		<td class="<?php echo $merchant_copy1_view->TableLeftColumnClass ?>"><span id="elh_merchant_copy1_variabletax"><?php echo $merchant_copy1_view->variabletax->caption() ?></span></td>
		<td data-name="variabletax" <?php echo $merchant_copy1_view->variabletax->cellAttributes() ?>>
<span id="el_merchant_copy1_variabletax">
<span<?php echo $merchant_copy1_view->variabletax->viewAttributes() ?>><?php echo $merchant_copy1_view->variabletax->getViewValue() ?></span>
</span>
</td>
	</tr>
<?php } ?>
<?php if ($merchant_copy1_view->logofilename->Visible) { // logofilename ?>
	<tr id="r_logofilename">
		<td class="<?php echo $merchant_copy1_view->TableLeftColumnClass ?>"><span id="elh_merchant_copy1_logofilename"><?php echo $merchant_copy1_view->logofilename->caption() ?></span></td>
		<td data-name="logofilename" <?php echo $merchant_copy1_view->logofilename->cellAttributes() ?>>
<span id="el_merchant_copy1_logofilename">
<span<?php echo $merchant_copy1_view->logofilename->viewAttributes() ?>><?php echo $merchant_copy1_view->logofilename->getViewValue() ?></span>
</span>
</td>
	</tr>
<?php } ?>
<?php if ($merchant_copy1_view->returndays->Visible) { // returndays ?>
	<tr id="r_returndays">
		<td class="<?php echo $merchant_copy1_view->TableLeftColumnClass ?>"><span id="elh_merchant_copy1_returndays"><?php echo $merchant_copy1_view->returndays->caption() ?></span></td>
		<td data-name="returndays" <?php echo $merchant_copy1_view->returndays->cellAttributes() ?>>
<span id="el_merchant_copy1_returndays">
<span<?php echo $merchant_copy1_view->returndays->viewAttributes() ?>><?php echo $merchant_copy1_view->returndays->getViewValue() ?></span>
</span>
</td>
	</tr>
<?php } ?>
<?php if ($merchant_copy1_view->memberextrafieldsid->Visible) { // memberextrafieldsid ?>
	<tr id="r_memberextrafieldsid">
		<td class="<?php echo $merchant_copy1_view->TableLeftColumnClass ?>"><span id="elh_merchant_copy1_memberextrafieldsid"><?php echo $merchant_copy1_view->memberextrafieldsid->caption() ?></span></td>
		<td data-name="memberextrafieldsid" <?php echo $merchant_copy1_view->memberextrafieldsid->cellAttributes() ?>>
<span id="el_merchant_copy1_memberextrafieldsid">
<span<?php echo $merchant_copy1_view->memberextrafieldsid->viewAttributes() ?>><?php echo $merchant_copy1_view->memberextrafieldsid->getViewValue() ?></span>
</span>
</td>
	</tr>
<?php } ?>
<?php if ($merchant_copy1_view->lastupdatedate->Visible) { // lastupdatedate ?>
	<tr id="r_lastupdatedate">
		<td class="<?php echo $merchant_copy1_view->TableLeftColumnClass ?>"><span id="elh_merchant_copy1_lastupdatedate"><?php echo $merchant_copy1_view->lastupdatedate->caption() ?></span></td>
		<td data-name="lastupdatedate" <?php echo $merchant_copy1_view->lastupdatedate->cellAttributes() ?>>
<span id="el_merchant_copy1_lastupdatedate">
<span<?php echo $merchant_copy1_view->lastupdatedate->viewAttributes() ?>><?php echo $merchant_copy1_view->lastupdatedate->getViewValue() ?></span>
</span>
</td>
	</tr>
<?php } ?>
<?php if ($merchant_copy1_view->remmitancetype->Visible) { // remmitancetype ?>
	<tr id="r_remmitancetype">
		<td class="<?php echo $merchant_copy1_view->TableLeftColumnClass ?>"><span id="elh_merchant_copy1_remmitancetype"><?php echo $merchant_copy1_view->remmitancetype->caption() ?></span></td>
		<td data-name="remmitancetype" <?php echo $merchant_copy1_view->remmitancetype->cellAttributes() ?>>
<span id="el_merchant_copy1_remmitancetype">
<span<?php echo $merchant_copy1_view->remmitancetype->viewAttributes() ?>><?php echo $merchant_copy1_view->remmitancetype->getViewValue() ?></span>
</span>
</td>
	</tr>
<?php } ?>
<?php if ($merchant_copy1_view->withholdingtaxaccount->Visible) { // withholdingtaxaccount ?>
	<tr id="r_withholdingtaxaccount">
		<td class="<?php echo $merchant_copy1_view->TableLeftColumnClass ?>"><span id="elh_merchant_copy1_withholdingtaxaccount"><?php echo $merchant_copy1_view->withholdingtaxaccount->caption() ?></span></td>
		<td data-name="withholdingtaxaccount" <?php echo $merchant_copy1_view->withholdingtaxaccount->cellAttributes() ?>>
<span id="el_merchant_copy1_withholdingtaxaccount">
<span<?php echo $merchant_copy1_view->withholdingtaxaccount->viewAttributes() ?>><?php echo $merchant_copy1_view->withholdingtaxaccount->getViewValue() ?></span>
</span>
</td>
	</tr>
<?php } ?>
<?php if ($merchant_copy1_view->businessphoneno->Visible) { // businessphoneno ?>
	<tr id="r_businessphoneno">
		<td class="<?php echo $merchant_copy1_view->TableLeftColumnClass ?>"><span id="elh_merchant_copy1_businessphoneno"><?php echo $merchant_copy1_view->businessphoneno->caption() ?></span></td>
		<td data-name="businessphoneno" <?php echo $merchant_copy1_view->businessphoneno->cellAttributes() ?>>
<span id="el_merchant_copy1_businessphoneno">
<span<?php echo $merchant_copy1_view->businessphoneno->viewAttributes() ?>><?php echo $merchant_copy1_view->businessphoneno->getViewValue() ?></span>
</span>
</td>
	</tr>
<?php } ?>
<?php if ($merchant_copy1_view->businessaddress1->Visible) { // businessaddress1 ?>
	<tr id="r_businessaddress1">
		<td class="<?php echo $merchant_copy1_view->TableLeftColumnClass ?>"><span id="elh_merchant_copy1_businessaddress1"><?php echo $merchant_copy1_view->businessaddress1->caption() ?></span></td>
		<td data-name="businessaddress1" <?php echo $merchant_copy1_view->businessaddress1->cellAttributes() ?>>
<span id="el_merchant_copy1_businessaddress1">
<span<?php echo $merchant_copy1_view->businessaddress1->viewAttributes() ?>><?php echo $merchant_copy1_view->businessaddress1->getViewValue() ?></span>
</span>
</td>
	</tr>
<?php } ?>
<?php if ($merchant_copy1_view->businessaddress2->Visible) { // businessaddress2 ?>
	<tr id="r_businessaddress2">
		<td class="<?php echo $merchant_copy1_view->TableLeftColumnClass ?>"><span id="elh_merchant_copy1_businessaddress2"><?php echo $merchant_copy1_view->businessaddress2->caption() ?></span></td>
		<td data-name="businessaddress2" <?php echo $merchant_copy1_view->businessaddress2->cellAttributes() ?>>
<span id="el_merchant_copy1_businessaddress2">
<span<?php echo $merchant_copy1_view->businessaddress2->viewAttributes() ?>><?php echo $merchant_copy1_view->businessaddress2->getViewValue() ?></span>
</span>
</td>
	</tr>
<?php } ?>
<?php if ($merchant_copy1_view->businesscity->Visible) { // businesscity ?>
	<tr id="r_businesscity">
		<td class="<?php echo $merchant_copy1_view->TableLeftColumnClass ?>"><span id="elh_merchant_copy1_businesscity"><?php echo $merchant_copy1_view->businesscity->caption() ?></span></td>
		<td data-name="businesscity" <?php echo $merchant_copy1_view->businesscity->cellAttributes() ?>>
<span id="el_merchant_copy1_businesscity">
<span<?php echo $merchant_copy1_view->businesscity->viewAttributes() ?>><?php echo $merchant_copy1_view->businesscity->getViewValue() ?></span>
</span>
</td>
	</tr>
<?php } ?>
<?php if ($merchant_copy1_view->businessstate->Visible) { // businessstate ?>
	<tr id="r_businessstate">
		<td class="<?php echo $merchant_copy1_view->TableLeftColumnClass ?>"><span id="elh_merchant_copy1_businessstate"><?php echo $merchant_copy1_view->businessstate->caption() ?></span></td>
		<td data-name="businessstate" <?php echo $merchant_copy1_view->businessstate->cellAttributes() ?>>
<span id="el_merchant_copy1_businessstate">
<span<?php echo $merchant_copy1_view->businessstate->viewAttributes() ?>><?php echo $merchant_copy1_view->businessstate->getViewValue() ?></span>
</span>
</td>
	</tr>
<?php } ?>
<?php if ($merchant_copy1_view->businesscountry->Visible) { // businesscountry ?>
	<tr id="r_businesscountry">
		<td class="<?php echo $merchant_copy1_view->TableLeftColumnClass ?>"><span id="elh_merchant_copy1_businesscountry"><?php echo $merchant_copy1_view->businesscountry->caption() ?></span></td>
		<td data-name="businesscountry" <?php echo $merchant_copy1_view->businesscountry->cellAttributes() ?>>
<span id="el_merchant_copy1_businesscountry">
<span<?php echo $merchant_copy1_view->businesscountry->viewAttributes() ?>><?php echo $merchant_copy1_view->businesscountry->getViewValue() ?></span>
</span>
</td>
	</tr>
<?php } ?>
<?php if ($merchant_copy1_view->businesszipcode->Visible) { // businesszipcode ?>
	<tr id="r_businesszipcode">
		<td class="<?php echo $merchant_copy1_view->TableLeftColumnClass ?>"><span id="elh_merchant_copy1_businesszipcode"><?php echo $merchant_copy1_view->businesszipcode->caption() ?></span></td>
		<td data-name="businesszipcode" <?php echo $merchant_copy1_view->businesszipcode->cellAttributes() ?>>
<span id="el_merchant_copy1_businesszipcode">
<span<?php echo $merchant_copy1_view->businesszipcode->viewAttributes() ?>><?php echo $merchant_copy1_view->businesszipcode->getViewValue() ?></span>
</span>
</td>
	</tr>
<?php } ?>
<?php if ($merchant_copy1_view->bankname->Visible) { // bankname ?>
	<tr id="r_bankname">
		<td class="<?php echo $merchant_copy1_view->TableLeftColumnClass ?>"><span id="elh_merchant_copy1_bankname"><?php echo $merchant_copy1_view->bankname->caption() ?></span></td>
		<td data-name="bankname" <?php echo $merchant_copy1_view->bankname->cellAttributes() ?>>
<span id="el_merchant_copy1_bankname">
<span<?php echo $merchant_copy1_view->bankname->viewAttributes() ?>><?php echo $merchant_copy1_view->bankname->getViewValue() ?></span>
</span>
</td>
	</tr>
<?php } ?>
<?php if ($merchant_copy1_view->bankbranchnumber->Visible) { // bankbranchnumber ?>
	<tr id="r_bankbranchnumber">
		<td class="<?php echo $merchant_copy1_view->TableLeftColumnClass ?>"><span id="elh_merchant_copy1_bankbranchnumber"><?php echo $merchant_copy1_view->bankbranchnumber->caption() ?></span></td>
		<td data-name="bankbranchnumber" <?php echo $merchant_copy1_view->bankbranchnumber->cellAttributes() ?>>
<span id="el_merchant_copy1_bankbranchnumber">
<span<?php echo $merchant_copy1_view->bankbranchnumber->viewAttributes() ?>><?php echo $merchant_copy1_view->bankbranchnumber->getViewValue() ?></span>
</span>
</td>
	</tr>
<?php } ?>
<?php if ($merchant_copy1_view->bankaccountnumber->Visible) { // bankaccountnumber ?>
	<tr id="r_bankaccountnumber">
		<td class="<?php echo $merchant_copy1_view->TableLeftColumnClass ?>"><span id="elh_merchant_copy1_bankaccountnumber"><?php echo $merchant_copy1_view->bankaccountnumber->caption() ?></span></td>
		<td data-name="bankaccountnumber" <?php echo $merchant_copy1_view->bankaccountnumber->cellAttributes() ?>>
<span id="el_merchant_copy1_bankaccountnumber">
<span<?php echo $merchant_copy1_view->bankaccountnumber->viewAttributes() ?>><?php echo $merchant_copy1_view->bankaccountnumber->getViewValue() ?></span>
</span>
</td>
	</tr>
<?php } ?>
<?php if ($merchant_copy1_view->other1->Visible) { // other1 ?>
	<tr id="r_other1">
		<td class="<?php echo $merchant_copy1_view->TableLeftColumnClass ?>"><span id="elh_merchant_copy1_other1"><?php echo $merchant_copy1_view->other1->caption() ?></span></td>
		<td data-name="other1" <?php echo $merchant_copy1_view->other1->cellAttributes() ?>>
<span id="el_merchant_copy1_other1">
<span<?php echo $merchant_copy1_view->other1->viewAttributes() ?>><?php echo $merchant_copy1_view->other1->getViewValue() ?></span>
</span>
</td>
	</tr>
<?php } ?>
<?php if ($merchant_copy1_view->other2->Visible) { // other2 ?>
	<tr id="r_other2">
		<td class="<?php echo $merchant_copy1_view->TableLeftColumnClass ?>"><span id="elh_merchant_copy1_other2"><?php echo $merchant_copy1_view->other2->caption() ?></span></td>
		<td data-name="other2" <?php echo $merchant_copy1_view->other2->cellAttributes() ?>>
<span id="el_merchant_copy1_other2">
<span<?php echo $merchant_copy1_view->other2->viewAttributes() ?>><?php echo $merchant_copy1_view->other2->getViewValue() ?></span>
</span>
</td>
	</tr>
<?php } ?>
<?php if ($merchant_copy1_view->other3->Visible) { // other3 ?>
	<tr id="r_other3">
		<td class="<?php echo $merchant_copy1_view->TableLeftColumnClass ?>"><span id="elh_merchant_copy1_other3"><?php echo $merchant_copy1_view->other3->caption() ?></span></td>
		<td data-name="other3" <?php echo $merchant_copy1_view->other3->cellAttributes() ?>>
<span id="el_merchant_copy1_other3">
<span<?php echo $merchant_copy1_view->other3->viewAttributes() ?>><?php echo $merchant_copy1_view->other3->getViewValue() ?></span>
</span>
</td>
	</tr>
<?php } ?>
<?php if ($merchant_copy1_view->externalid->Visible) { // externalid ?>
	<tr id="r_externalid">
		<td class="<?php echo $merchant_copy1_view->TableLeftColumnClass ?>"><span id="elh_merchant_copy1_externalid"><?php echo $merchant_copy1_view->externalid->caption() ?></span></td>
		<td data-name="externalid" <?php echo $merchant_copy1_view->externalid->cellAttributes() ?>>
<span id="el_merchant_copy1_externalid">
<span<?php echo $merchant_copy1_view->externalid->viewAttributes() ?>><?php echo $merchant_copy1_view->externalid->getViewValue() ?></span>
</span>
</td>
	</tr>
<?php } ?>
<?php if ($merchant_copy1_view->couponpin->Visible) { // couponpin ?>
	<tr id="r_couponpin">
		<td class="<?php echo $merchant_copy1_view->TableLeftColumnClass ?>"><span id="elh_merchant_copy1_couponpin"><?php echo $merchant_copy1_view->couponpin->caption() ?></span></td>
		<td data-name="couponpin" <?php echo $merchant_copy1_view->couponpin->cellAttributes() ?>>
<span id="el_merchant_copy1_couponpin">
<span<?php echo $merchant_copy1_view->couponpin->viewAttributes() ?>><?php echo $merchant_copy1_view->couponpin->getViewValue() ?></span>
</span>
</td>
	</tr>
<?php } ?>
<?php if ($merchant_copy1_view->officialname->Visible) { // officialname ?>
	<tr id="r_officialname">
		<td class="<?php echo $merchant_copy1_view->TableLeftColumnClass ?>"><span id="elh_merchant_copy1_officialname"><?php echo $merchant_copy1_view->officialname->caption() ?></span></td>
		<td data-name="officialname" <?php echo $merchant_copy1_view->officialname->cellAttributes() ?>>
<span id="el_merchant_copy1_officialname">
<span<?php echo $merchant_copy1_view->officialname->viewAttributes() ?>><?php echo $merchant_copy1_view->officialname->getViewValue() ?></span>
</span>
</td>
	</tr>
<?php } ?>
<?php if ($merchant_copy1_view->swiftcode->Visible) { // swiftcode ?>
	<tr id="r_swiftcode">
		<td class="<?php echo $merchant_copy1_view->TableLeftColumnClass ?>"><span id="elh_merchant_copy1_swiftcode"><?php echo $merchant_copy1_view->swiftcode->caption() ?></span></td>
		<td data-name="swiftcode" <?php echo $merchant_copy1_view->swiftcode->cellAttributes() ?>>
<span id="el_merchant_copy1_swiftcode">
<span<?php echo $merchant_copy1_view->swiftcode->viewAttributes() ?>><?php echo $merchant_copy1_view->swiftcode->getViewValue() ?></span>
</span>
</td>
	</tr>
<?php } ?>
<?php if ($merchant_copy1_view->profilevalidated->Visible) { // profilevalidated ?>
	<tr id="r_profilevalidated">
		<td class="<?php echo $merchant_copy1_view->TableLeftColumnClass ?>"><span id="elh_merchant_copy1_profilevalidated"><?php echo $merchant_copy1_view->profilevalidated->caption() ?></span></td>
		<td data-name="profilevalidated" <?php echo $merchant_copy1_view->profilevalidated->cellAttributes() ?>>
<span id="el_merchant_copy1_profilevalidated">
<span<?php echo $merchant_copy1_view->profilevalidated->viewAttributes() ?>><?php echo $merchant_copy1_view->profilevalidated->getViewValue() ?></span>
</span>
</td>
	</tr>
<?php } ?>
<?php if ($merchant_copy1_view->profilevalidationdate->Visible) { // profilevalidationdate ?>
	<tr id="r_profilevalidationdate">
		<td class="<?php echo $merchant_copy1_view->TableLeftColumnClass ?>"><span id="elh_merchant_copy1_profilevalidationdate"><?php echo $merchant_copy1_view->profilevalidationdate->caption() ?></span></td>
		<td data-name="profilevalidationdate" <?php echo $merchant_copy1_view->profilevalidationdate->cellAttributes() ?>>
<span id="el_merchant_copy1_profilevalidationdate">
<span<?php echo $merchant_copy1_view->profilevalidationdate->viewAttributes() ?>><?php echo $merchant_copy1_view->profilevalidationdate->getViewValue() ?></span>
</span>
</td>
	</tr>
<?php } ?>
<?php if ($merchant_copy1_view->industry->Visible) { // industry ?>
	<tr id="r_industry">
		<td class="<?php echo $merchant_copy1_view->TableLeftColumnClass ?>"><span id="elh_merchant_copy1_industry"><?php echo $merchant_copy1_view->industry->caption() ?></span></td>
		<td data-name="industry" <?php echo $merchant_copy1_view->industry->cellAttributes() ?>>
<span id="el_merchant_copy1_industry">
<span<?php echo $merchant_copy1_view->industry->viewAttributes() ?>><?php echo $merchant_copy1_view->industry->getViewValue() ?></span>
</span>
</td>
	</tr>
<?php } ?>
<?php if ($merchant_copy1_view->legalstructure->Visible) { // legalstructure ?>
	<tr id="r_legalstructure">
		<td class="<?php echo $merchant_copy1_view->TableLeftColumnClass ?>"><span id="elh_merchant_copy1_legalstructure"><?php echo $merchant_copy1_view->legalstructure->caption() ?></span></td>
		<td data-name="legalstructure" <?php echo $merchant_copy1_view->legalstructure->cellAttributes() ?>>
<span id="el_merchant_copy1_legalstructure">
<span<?php echo $merchant_copy1_view->legalstructure->viewAttributes() ?>><?php echo $merchant_copy1_view->legalstructure->getViewValue() ?></span>
</span>
</td>
	</tr>
<?php } ?>
<?php if ($merchant_copy1_view->extendedfields->Visible) { // extendedfields ?>
	<tr id="r_extendedfields">
		<td class="<?php echo $merchant_copy1_view->TableLeftColumnClass ?>"><span id="elh_merchant_copy1_extendedfields"><?php echo $merchant_copy1_view->extendedfields->caption() ?></span></td>
		<td data-name="extendedfields" <?php echo $merchant_copy1_view->extendedfields->cellAttributes() ?>>
<span id="el_merchant_copy1_extendedfields">
<span<?php echo $merchant_copy1_view->extendedfields->viewAttributes() ?>><?php echo $merchant_copy1_view->extendedfields->getViewValue() ?></span>
</span>
</td>
	</tr>
<?php } ?>
</table>
</form>
<?php
$merchant_copy1_view->showPageFooter();
if (Config("DEBUG"))
	echo GetDebugMessage();
?>
<?php if (!$merchant_copy1_view->isExport()) { ?>
<script>
loadjs.ready("load", function() {

	// Startup script
	// Write your table-specific startup script here
	// console.log("page loaded");

});
</script>
<?php } ?>
<?php include_once "footer.php"; ?>
<?php
$merchant_copy1_view->terminate();
?>