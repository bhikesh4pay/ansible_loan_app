<?php
namespace PHPMaker2020\_4payadmin;

// Autoload
include_once "autoload.php";

// Session
if (session_status() !== PHP_SESSION_ACTIVE)
	\Delight\Cookie\Session::start(Config("COOKIE_SAMESITE")); // Init session data

// Output buffering
ob_start();
?>
<?php

// Write header
WriteHeader(FALSE, "utf-8");

// Create page object
$usercommission_preview = new usercommission_preview();

// Run the page
$usercommission_preview->run();

// Setup login status
SetupLoginStatus();
SetClientVar("login", LoginStatus());

// Global Page Rendering event (in userfn*.php)
Page_Rendering();

// Page Rendering event
$usercommission_preview->Page_Render();
?>
<?php $usercommission_preview->showPageHeader(); ?>
<?php if ($usercommission_preview->TotalRecords > 0) { ?>
<div class="card ew-grid usercommission"><!-- .card -->
<div class="<?php echo ResponsiveTableClass() ?>card-body ew-grid-middle-panel ew-preview-middle-panel"><!-- .table-responsive -->
<table class="table ew-table ew-preview-table"><!-- .table -->
	<thead><!-- Table header -->
		<tr class="ew-table-header">
<?php

// Render list options
$usercommission_preview->renderListOptions();

// Render list options (header, left)
$usercommission_preview->ListOptions->render("header", "left");
?>
<?php if ($usercommission_preview->recid->Visible) { // recid ?>
	<?php if ($usercommission->SortUrl($usercommission_preview->recid) == "") { ?>
		<th class="<?php echo $usercommission_preview->recid->headerCellClass() ?>"><?php echo $usercommission_preview->recid->caption() ?></th>
	<?php } else { ?>
		<th class="<?php echo $usercommission_preview->recid->headerCellClass() ?>"><div class="ew-pointer" data-sort="<?php echo HtmlEncode($usercommission_preview->recid->Name) ?>" data-sort-order="<?php echo $usercommission_preview->SortField == $usercommission_preview->recid->Name && $usercommission_preview->SortOrder == "ASC" ? "DESC" : "ASC" ?>">
			<div class="ew-table-header-btn"><span class="ew-table-header-caption"><?php echo $usercommission_preview->recid->caption() ?></span><span class="ew-table-header-sort"><?php if ($usercommission_preview->SortField == $usercommission_preview->recid->Name) { ?><?php if ($usercommission_preview->SortOrder == "ASC") { ?><i class="fas fa-sort-up"></i><?php } elseif ($usercommission_preview->SortOrder == "DESC") { ?><i class="fas fa-sort-down"></i><?php } ?><?php } ?></span>
		</div></div></th>
	<?php } ?>
<?php } ?>
<?php if ($usercommission_preview->_userid->Visible) { // userid ?>
	<?php if ($usercommission->SortUrl($usercommission_preview->_userid) == "") { ?>
		<th class="<?php echo $usercommission_preview->_userid->headerCellClass() ?>"><?php echo $usercommission_preview->_userid->caption() ?></th>
	<?php } else { ?>
		<th class="<?php echo $usercommission_preview->_userid->headerCellClass() ?>"><div class="ew-pointer" data-sort="<?php echo HtmlEncode($usercommission_preview->_userid->Name) ?>" data-sort-order="<?php echo $usercommission_preview->SortField == $usercommission_preview->_userid->Name && $usercommission_preview->SortOrder == "ASC" ? "DESC" : "ASC" ?>">
			<div class="ew-table-header-btn"><span class="ew-table-header-caption"><?php echo $usercommission_preview->_userid->caption() ?></span><span class="ew-table-header-sort"><?php if ($usercommission_preview->SortField == $usercommission_preview->_userid->Name) { ?><?php if ($usercommission_preview->SortOrder == "ASC") { ?><i class="fas fa-sort-up"></i><?php } elseif ($usercommission_preview->SortOrder == "DESC") { ?><i class="fas fa-sort-down"></i><?php } ?><?php } ?></span>
		</div></div></th>
	<?php } ?>
<?php } ?>
<?php if ($usercommission_preview->userpi->Visible) { // userpi ?>
	<?php if ($usercommission->SortUrl($usercommission_preview->userpi) == "") { ?>
		<th class="<?php echo $usercommission_preview->userpi->headerCellClass() ?>"><?php echo $usercommission_preview->userpi->caption() ?></th>
	<?php } else { ?>
		<th class="<?php echo $usercommission_preview->userpi->headerCellClass() ?>"><div class="ew-pointer" data-sort="<?php echo HtmlEncode($usercommission_preview->userpi->Name) ?>" data-sort-order="<?php echo $usercommission_preview->SortField == $usercommission_preview->userpi->Name && $usercommission_preview->SortOrder == "ASC" ? "DESC" : "ASC" ?>">
			<div class="ew-table-header-btn"><span class="ew-table-header-caption"><?php echo $usercommission_preview->userpi->caption() ?></span><span class="ew-table-header-sort"><?php if ($usercommission_preview->SortField == $usercommission_preview->userpi->Name) { ?><?php if ($usercommission_preview->SortOrder == "ASC") { ?><i class="fas fa-sort-up"></i><?php } elseif ($usercommission_preview->SortOrder == "DESC") { ?><i class="fas fa-sort-down"></i><?php } ?><?php } ?></span>
		</div></div></th>
	<?php } ?>
<?php } ?>
<?php if ($usercommission_preview->category->Visible) { // category ?>
	<?php if ($usercommission->SortUrl($usercommission_preview->category) == "") { ?>
		<th class="<?php echo $usercommission_preview->category->headerCellClass() ?>"><?php echo $usercommission_preview->category->caption() ?></th>
	<?php } else { ?>
		<th class="<?php echo $usercommission_preview->category->headerCellClass() ?>"><div class="ew-pointer" data-sort="<?php echo HtmlEncode($usercommission_preview->category->Name) ?>" data-sort-order="<?php echo $usercommission_preview->SortField == $usercommission_preview->category->Name && $usercommission_preview->SortOrder == "ASC" ? "DESC" : "ASC" ?>">
			<div class="ew-table-header-btn"><span class="ew-table-header-caption"><?php echo $usercommission_preview->category->caption() ?></span><span class="ew-table-header-sort"><?php if ($usercommission_preview->SortField == $usercommission_preview->category->Name) { ?><?php if ($usercommission_preview->SortOrder == "ASC") { ?><i class="fas fa-sort-up"></i><?php } elseif ($usercommission_preview->SortOrder == "DESC") { ?><i class="fas fa-sort-down"></i><?php } ?><?php } ?></span>
		</div></div></th>
	<?php } ?>
<?php } ?>
<?php if ($usercommission_preview->transactiondate->Visible) { // transactiondate ?>
	<?php if ($usercommission->SortUrl($usercommission_preview->transactiondate) == "") { ?>
		<th class="<?php echo $usercommission_preview->transactiondate->headerCellClass() ?>"><?php echo $usercommission_preview->transactiondate->caption() ?></th>
	<?php } else { ?>
		<th class="<?php echo $usercommission_preview->transactiondate->headerCellClass() ?>"><div class="ew-pointer" data-sort="<?php echo HtmlEncode($usercommission_preview->transactiondate->Name) ?>" data-sort-order="<?php echo $usercommission_preview->SortField == $usercommission_preview->transactiondate->Name && $usercommission_preview->SortOrder == "ASC" ? "DESC" : "ASC" ?>">
			<div class="ew-table-header-btn"><span class="ew-table-header-caption"><?php echo $usercommission_preview->transactiondate->caption() ?></span><span class="ew-table-header-sort"><?php if ($usercommission_preview->SortField == $usercommission_preview->transactiondate->Name) { ?><?php if ($usercommission_preview->SortOrder == "ASC") { ?><i class="fas fa-sort-up"></i><?php } elseif ($usercommission_preview->SortOrder == "DESC") { ?><i class="fas fa-sort-down"></i><?php } ?><?php } ?></span>
		</div></div></th>
	<?php } ?>
<?php } ?>
<?php if ($usercommission_preview->commissionamount->Visible) { // commissionamount ?>
	<?php if ($usercommission->SortUrl($usercommission_preview->commissionamount) == "") { ?>
		<th class="<?php echo $usercommission_preview->commissionamount->headerCellClass() ?>"><?php echo $usercommission_preview->commissionamount->caption() ?></th>
	<?php } else { ?>
		<th class="<?php echo $usercommission_preview->commissionamount->headerCellClass() ?>"><div class="ew-pointer" data-sort="<?php echo HtmlEncode($usercommission_preview->commissionamount->Name) ?>" data-sort-order="<?php echo $usercommission_preview->SortField == $usercommission_preview->commissionamount->Name && $usercommission_preview->SortOrder == "ASC" ? "DESC" : "ASC" ?>">
			<div class="ew-table-header-btn"><span class="ew-table-header-caption"><?php echo $usercommission_preview->commissionamount->caption() ?></span><span class="ew-table-header-sort"><?php if ($usercommission_preview->SortField == $usercommission_preview->commissionamount->Name) { ?><?php if ($usercommission_preview->SortOrder == "ASC") { ?><i class="fas fa-sort-up"></i><?php } elseif ($usercommission_preview->SortOrder == "DESC") { ?><i class="fas fa-sort-down"></i><?php } ?><?php } ?></span>
		</div></div></th>
	<?php } ?>
<?php } ?>
<?php if ($usercommission_preview->payoutdate->Visible) { // payoutdate ?>
	<?php if ($usercommission->SortUrl($usercommission_preview->payoutdate) == "") { ?>
		<th class="<?php echo $usercommission_preview->payoutdate->headerCellClass() ?>"><?php echo $usercommission_preview->payoutdate->caption() ?></th>
	<?php } else { ?>
		<th class="<?php echo $usercommission_preview->payoutdate->headerCellClass() ?>"><div class="ew-pointer" data-sort="<?php echo HtmlEncode($usercommission_preview->payoutdate->Name) ?>" data-sort-order="<?php echo $usercommission_preview->SortField == $usercommission_preview->payoutdate->Name && $usercommission_preview->SortOrder == "ASC" ? "DESC" : "ASC" ?>">
			<div class="ew-table-header-btn"><span class="ew-table-header-caption"><?php echo $usercommission_preview->payoutdate->caption() ?></span><span class="ew-table-header-sort"><?php if ($usercommission_preview->SortField == $usercommission_preview->payoutdate->Name) { ?><?php if ($usercommission_preview->SortOrder == "ASC") { ?><i class="fas fa-sort-up"></i><?php } elseif ($usercommission_preview->SortOrder == "DESC") { ?><i class="fas fa-sort-down"></i><?php } ?><?php } ?></span>
		</div></div></th>
	<?php } ?>
<?php } ?>
<?php if ($usercommission_preview->desc->Visible) { // desc ?>
	<?php if ($usercommission->SortUrl($usercommission_preview->desc) == "") { ?>
		<th class="<?php echo $usercommission_preview->desc->headerCellClass() ?>"><?php echo $usercommission_preview->desc->caption() ?></th>
	<?php } else { ?>
		<th class="<?php echo $usercommission_preview->desc->headerCellClass() ?>"><div class="ew-pointer" data-sort="<?php echo HtmlEncode($usercommission_preview->desc->Name) ?>" data-sort-order="<?php echo $usercommission_preview->SortField == $usercommission_preview->desc->Name && $usercommission_preview->SortOrder == "ASC" ? "DESC" : "ASC" ?>">
			<div class="ew-table-header-btn"><span class="ew-table-header-caption"><?php echo $usercommission_preview->desc->caption() ?></span><span class="ew-table-header-sort"><?php if ($usercommission_preview->SortField == $usercommission_preview->desc->Name) { ?><?php if ($usercommission_preview->SortOrder == "ASC") { ?><i class="fas fa-sort-up"></i><?php } elseif ($usercommission_preview->SortOrder == "DESC") { ?><i class="fas fa-sort-down"></i><?php } ?><?php } ?></span>
		</div></div></th>
	<?php } ?>
<?php } ?>
<?php if ($usercommission_preview->paid->Visible) { // paid ?>
	<?php if ($usercommission->SortUrl($usercommission_preview->paid) == "") { ?>
		<th class="<?php echo $usercommission_preview->paid->headerCellClass() ?>"><?php echo $usercommission_preview->paid->caption() ?></th>
	<?php } else { ?>
		<th class="<?php echo $usercommission_preview->paid->headerCellClass() ?>"><div class="ew-pointer" data-sort="<?php echo HtmlEncode($usercommission_preview->paid->Name) ?>" data-sort-order="<?php echo $usercommission_preview->SortField == $usercommission_preview->paid->Name && $usercommission_preview->SortOrder == "ASC" ? "DESC" : "ASC" ?>">
			<div class="ew-table-header-btn"><span class="ew-table-header-caption"><?php echo $usercommission_preview->paid->caption() ?></span><span class="ew-table-header-sort"><?php if ($usercommission_preview->SortField == $usercommission_preview->paid->Name) { ?><?php if ($usercommission_preview->SortOrder == "ASC") { ?><i class="fas fa-sort-up"></i><?php } elseif ($usercommission_preview->SortOrder == "DESC") { ?><i class="fas fa-sort-down"></i><?php } ?><?php } ?></span>
		</div></div></th>
	<?php } ?>
<?php } ?>
<?php

// Render list options (header, right)
$usercommission_preview->ListOptions->render("header", "right");
?>
		</tr>
	</thead>
	<tbody><!-- Table body -->
<?php
$usercommission_preview->RecCount = 0;
$usercommission_preview->RowCount = 0;
while ($usercommission_preview->Recordset && !$usercommission_preview->Recordset->EOF) {

	// Init row class and style
	$usercommission_preview->RecCount++;
	$usercommission_preview->RowCount++;
	$usercommission_preview->CssStyle = "";
	$usercommission_preview->loadListRowValues($usercommission_preview->Recordset);

	// Render row
	$usercommission->RowType = ROWTYPE_PREVIEW; // Preview record
	$usercommission_preview->resetAttributes();
	$usercommission_preview->renderListRow();

	// Render list options
	$usercommission_preview->renderListOptions();
?>
	<tr <?php echo $usercommission->rowAttributes() ?>>
<?php

// Render list options (body, left)
$usercommission_preview->ListOptions->render("body", "left", $usercommission_preview->RowCount);
?>
<?php if ($usercommission_preview->recid->Visible) { // recid ?>
		<!-- recid -->
		<td<?php echo $usercommission_preview->recid->cellAttributes() ?>>
<span<?php echo $usercommission_preview->recid->viewAttributes() ?>><?php echo $usercommission_preview->recid->getViewValue() ?></span>
</td>
<?php } ?>
<?php if ($usercommission_preview->_userid->Visible) { // userid ?>
		<!-- userid -->
		<td<?php echo $usercommission_preview->_userid->cellAttributes() ?>>
<span<?php echo $usercommission_preview->_userid->viewAttributes() ?>><?php echo $usercommission_preview->_userid->getViewValue() ?></span>
</td>
<?php } ?>
<?php if ($usercommission_preview->userpi->Visible) { // userpi ?>
		<!-- userpi -->
		<td<?php echo $usercommission_preview->userpi->cellAttributes() ?>>
<span<?php echo $usercommission_preview->userpi->viewAttributes() ?>><?php echo $usercommission_preview->userpi->getViewValue() ?></span>
</td>
<?php } ?>
<?php if ($usercommission_preview->category->Visible) { // category ?>
		<!-- category -->
		<td<?php echo $usercommission_preview->category->cellAttributes() ?>>
<span<?php echo $usercommission_preview->category->viewAttributes() ?>><?php echo $usercommission_preview->category->getViewValue() ?></span>
</td>
<?php } ?>
<?php if ($usercommission_preview->transactiondate->Visible) { // transactiondate ?>
		<!-- transactiondate -->
		<td<?php echo $usercommission_preview->transactiondate->cellAttributes() ?>>
<span<?php echo $usercommission_preview->transactiondate->viewAttributes() ?>><?php echo $usercommission_preview->transactiondate->getViewValue() ?></span>
</td>
<?php } ?>
<?php if ($usercommission_preview->commissionamount->Visible) { // commissionamount ?>
		<!-- commissionamount -->
		<td<?php echo $usercommission_preview->commissionamount->cellAttributes() ?>>
<span<?php echo $usercommission_preview->commissionamount->viewAttributes() ?>><?php echo $usercommission_preview->commissionamount->getViewValue() ?></span>
</td>
<?php } ?>
<?php if ($usercommission_preview->payoutdate->Visible) { // payoutdate ?>
		<!-- payoutdate -->
		<td<?php echo $usercommission_preview->payoutdate->cellAttributes() ?>>
<span<?php echo $usercommission_preview->payoutdate->viewAttributes() ?>><?php echo $usercommission_preview->payoutdate->getViewValue() ?></span>
</td>
<?php } ?>
<?php if ($usercommission_preview->desc->Visible) { // desc ?>
		<!-- desc -->
		<td<?php echo $usercommission_preview->desc->cellAttributes() ?>>
<span<?php echo $usercommission_preview->desc->viewAttributes() ?>><?php echo $usercommission_preview->desc->getViewValue() ?></span>
</td>
<?php } ?>
<?php if ($usercommission_preview->paid->Visible) { // paid ?>
		<!-- paid -->
		<td<?php echo $usercommission_preview->paid->cellAttributes() ?>>
<span<?php echo $usercommission_preview->paid->viewAttributes() ?>><?php echo $usercommission_preview->paid->getViewValue() ?></span>
</td>
<?php } ?>
<?php

// Render list options (body, right)
$usercommission_preview->ListOptions->render("body", "right", $usercommission_preview->RowCount);
?>
	</tr>
<?php
	$usercommission_preview->Recordset->MoveNext();
} // while
?>
	</tbody>
</table><!-- /.table -->
</div><!-- /.table-responsive -->
<div class="card-footer ew-grid-lower-panel ew-preview-lower-panel"><!-- .card-footer -->
<?php echo $usercommission_preview->Pager->render() ?>
<?php } else { // No record ?>
<div class="card no-border">
<div class="ew-detail-count"><?php echo $Language->phrase("NoRecord") ?></div>
<?php } ?>
<div class="ew-preview-other-options">
<?php
	foreach ($usercommission_preview->OtherOptions as $option)
		$option->render("body");
?>
</div>
<?php if ($usercommission_preview->TotalRecords > 0) { ?>
<div class="clearfix"></div>
</div><!-- /.card-footer -->
<?php } ?>
</div><!-- /.card -->
<?php
$usercommission_preview->showPageFooter();
if (Config("DEBUG"))
	echo GetDebugMessage();
?>
<?php
if ($usercommission_preview->Recordset)
	$usercommission_preview->Recordset->Close();

// Output
$content = ob_get_contents();
ob_end_clean();
echo ConvertToUtf8($content);
?>
<?php
$usercommission_preview->terminate();
?>