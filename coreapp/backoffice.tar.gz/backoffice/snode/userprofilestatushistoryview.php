<?php
namespace PHPMaker2020\_4payadmin;

// Autoload
include_once "autoload.php";

// Session
if (session_status() !== PHP_SESSION_ACTIVE)
	\Delight\Cookie\Session::start(Config("COOKIE_SAMESITE")); // Init session data

// Output buffering
ob_start();
?>
<?php

// Write header
WriteHeader(FALSE);

// Create page object
$userprofilestatushistory_view = new userprofilestatushistory_view();

// Run the page
$userprofilestatushistory_view->run();

// Setup login status
SetupLoginStatus();
SetClientVar("login", LoginStatus());

// Global Page Rendering event (in userfn*.php)
Page_Rendering();

// Page Rendering event
$userprofilestatushistory_view->Page_Render();
?>
<?php include_once "header.php"; ?>
<?php if (!$userprofilestatushistory_view->isExport()) { ?>
<script>
var fuserprofilestatushistoryview, currentPageID;
loadjs.ready("head", function() {

	// Form object
	currentPageID = ew.PAGE_ID = "view";
	fuserprofilestatushistoryview = currentForm = new ew.Form("fuserprofilestatushistoryview", "view");
	loadjs.done("fuserprofilestatushistoryview");
});
</script>
<script>
loadjs.ready("head", function() {

	// Client script
	// Write your client script here, no need to add script tags.

});
</script>
<?php } ?>
<?php if (!$userprofilestatushistory_view->isExport()) { ?>
<div class="btn-toolbar ew-toolbar">
<?php $userprofilestatushistory_view->ExportOptions->render("body") ?>
<?php $userprofilestatushistory_view->OtherOptions->render("body") ?>
<div class="clearfix"></div>
</div>
<?php } ?>
<?php $userprofilestatushistory_view->showPageHeader(); ?>
<?php
$userprofilestatushistory_view->showMessage();
?>
<form name="fuserprofilestatushistoryview" id="fuserprofilestatushistoryview" class="form-inline ew-form ew-view-form" action="<?php echo CurrentPageName() ?>" method="post">
<?php if ($Page->CheckToken) { ?>
<input type="hidden" name="<?php echo Config("TOKEN_NAME") ?>" value="<?php echo $Page->Token ?>">
<?php } ?>
<input type="hidden" name="t" value="userprofilestatushistory">
<input type="hidden" name="modal" value="<?php echo (int)$userprofilestatushistory_view->IsModal ?>">
<table class="table table-striped table-sm ew-view-table">
<?php if ($userprofilestatushistory_view->changeid->Visible) { // changeid ?>
	<tr id="r_changeid">
		<td class="<?php echo $userprofilestatushistory_view->TableLeftColumnClass ?>"><span id="elh_userprofilestatushistory_changeid"><?php echo $userprofilestatushistory_view->changeid->caption() ?></span></td>
		<td data-name="changeid" <?php echo $userprofilestatushistory_view->changeid->cellAttributes() ?>>
<span id="el_userprofilestatushistory_changeid">
<span<?php echo $userprofilestatushistory_view->changeid->viewAttributes() ?>><?php echo $userprofilestatushistory_view->changeid->getViewValue() ?></span>
</span>
</td>
	</tr>
<?php } ?>
<?php if ($userprofilestatushistory_view->_userid->Visible) { // userid ?>
	<tr id="r__userid">
		<td class="<?php echo $userprofilestatushistory_view->TableLeftColumnClass ?>"><span id="elh_userprofilestatushistory__userid"><?php echo $userprofilestatushistory_view->_userid->caption() ?></span></td>
		<td data-name="_userid" <?php echo $userprofilestatushistory_view->_userid->cellAttributes() ?>>
<span id="el_userprofilestatushistory__userid">
<span<?php echo $userprofilestatushistory_view->_userid->viewAttributes() ?>><?php echo $userprofilestatushistory_view->_userid->getViewValue() ?></span>
</span>
</td>
	</tr>
<?php } ?>
<?php if ($userprofilestatushistory_view->oldstatus->Visible) { // oldstatus ?>
	<tr id="r_oldstatus">
		<td class="<?php echo $userprofilestatushistory_view->TableLeftColumnClass ?>"><span id="elh_userprofilestatushistory_oldstatus"><?php echo $userprofilestatushistory_view->oldstatus->caption() ?></span></td>
		<td data-name="oldstatus" <?php echo $userprofilestatushistory_view->oldstatus->cellAttributes() ?>>
<span id="el_userprofilestatushistory_oldstatus">
<span<?php echo $userprofilestatushistory_view->oldstatus->viewAttributes() ?>><?php echo $userprofilestatushistory_view->oldstatus->getViewValue() ?></span>
</span>
</td>
	</tr>
<?php } ?>
<?php if ($userprofilestatushistory_view->newstatus->Visible) { // newstatus ?>
	<tr id="r_newstatus">
		<td class="<?php echo $userprofilestatushistory_view->TableLeftColumnClass ?>"><span id="elh_userprofilestatushistory_newstatus"><?php echo $userprofilestatushistory_view->newstatus->caption() ?></span></td>
		<td data-name="newstatus" <?php echo $userprofilestatushistory_view->newstatus->cellAttributes() ?>>
<span id="el_userprofilestatushistory_newstatus">
<span<?php echo $userprofilestatushistory_view->newstatus->viewAttributes() ?>><?php echo $userprofilestatushistory_view->newstatus->getViewValue() ?></span>
</span>
</td>
	</tr>
<?php } ?>
<?php if ($userprofilestatushistory_view->changetime->Visible) { // changetime ?>
	<tr id="r_changetime">
		<td class="<?php echo $userprofilestatushistory_view->TableLeftColumnClass ?>"><span id="elh_userprofilestatushistory_changetime"><?php echo $userprofilestatushistory_view->changetime->caption() ?></span></td>
		<td data-name="changetime" <?php echo $userprofilestatushistory_view->changetime->cellAttributes() ?>>
<span id="el_userprofilestatushistory_changetime">
<span<?php echo $userprofilestatushistory_view->changetime->viewAttributes() ?>><?php echo $userprofilestatushistory_view->changetime->getViewValue() ?></span>
</span>
</td>
	</tr>
<?php } ?>
</table>
</form>
<?php
$userprofilestatushistory_view->showPageFooter();
if (Config("DEBUG"))
	echo GetDebugMessage();
?>
<?php if (!$userprofilestatushistory_view->isExport()) { ?>
<script>
loadjs.ready("load", function() {

	// Startup script
	// Write your table-specific startup script here
	// console.log("page loaded");

});
</script>
<?php } ?>
<?php include_once "footer.php"; ?>
<?php
$userprofilestatushistory_view->terminate();
?>