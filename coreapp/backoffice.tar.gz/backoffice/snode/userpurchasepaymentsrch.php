<?php
namespace PHPMaker2020\_4payadmin;

// Autoload
include_once "autoload.php";

// Session
if (session_status() !== PHP_SESSION_ACTIVE)
	\Delight\Cookie\Session::start(Config("COOKIE_SAMESITE")); // Init session data

// Output buffering
ob_start();
?>
<?php

// Write header
WriteHeader(FALSE);

// Create page object
$userpurchasepayment_search = new userpurchasepayment_search();

// Run the page
$userpurchasepayment_search->run();

// Setup login status
SetupLoginStatus();
SetClientVar("login", LoginStatus());

// Global Page Rendering event (in userfn*.php)
Page_Rendering();

// Page Rendering event
$userpurchasepayment_search->Page_Render();
?>
<?php include_once "header.php"; ?>
<script>
var fuserpurchasepaymentsearch, currentPageID;
loadjs.ready("head", function() {

	// Form object for search
	<?php if ($userpurchasepayment_search->IsModal) { ?>
	fuserpurchasepaymentsearch = currentAdvancedSearchForm = new ew.Form("fuserpurchasepaymentsearch", "search");
	<?php } else { ?>
	fuserpurchasepaymentsearch = currentForm = new ew.Form("fuserpurchasepaymentsearch", "search");
	<?php } ?>
	currentPageID = ew.PAGE_ID = "search";

	// Validate function for search
	fuserpurchasepaymentsearch.validate = function(fobj) {
		if (!this.validateRequired)
			return true; // Ignore validation
		fobj = fobj || this._form;
		var infix = "";
		elm = this.getElements("x" + infix + "_paymentid");
		if (elm && !ew.checkInteger(elm.value))
			return this.onError(elm, "<?php echo JsEncode($userpurchasepayment_search->paymentid->errorMessage()) ?>");
		elm = this.getElements("x" + infix + "_purchaseid");
		if (elm && !ew.checkInteger(elm.value))
			return this.onError(elm, "<?php echo JsEncode($userpurchasepayment_search->purchaseid->errorMessage()) ?>");
		elm = this.getElements("x" + infix + "_userpiid");
		if (elm && !ew.checkInteger(elm.value))
			return this.onError(elm, "<?php echo JsEncode($userpurchasepayment_search->userpiid->errorMessage()) ?>");
		elm = this.getElements("x" + infix + "_userpi");
		if (elm && !ew.checkInteger(elm.value))
			return this.onError(elm, "<?php echo JsEncode($userpurchasepayment_search->userpi->errorMessage()) ?>");
		elm = this.getElements("x" + infix + "_merchantfees");
		if (elm && !ew.checkNumber(elm.value))
			return this.onError(elm, "<?php echo JsEncode($userpurchasepayment_search->merchantfees->errorMessage()) ?>");
		elm = this.getElements("x" + infix + "_consumerfees");
		if (elm && !ew.checkNumber(elm.value))
			return this.onError(elm, "<?php echo JsEncode($userpurchasepayment_search->consumerfees->errorMessage()) ?>");
		elm = this.getElements("x" + infix + "_paymentdatetime");
		if (elm && !ew.checkDateDef(elm.value))
			return this.onError(elm, "<?php echo JsEncode($userpurchasepayment_search->paymentdatetime->errorMessage()) ?>");
		elm = this.getElements("x" + infix + "_feesystemshare");
		if (elm && !ew.checkNumber(elm.value))
			return this.onError(elm, "<?php echo JsEncode($userpurchasepayment_search->feesystemshare->errorMessage()) ?>");
		elm = this.getElements("x" + infix + "_feeexternalshare");
		if (elm && !ew.checkNumber(elm.value))
			return this.onError(elm, "<?php echo JsEncode($userpurchasepayment_search->feeexternalshare->errorMessage()) ?>");
		elm = this.getElements("x" + infix + "_feefranchiseeshare");
		if (elm && !ew.checkNumber(elm.value))
			return this.onError(elm, "<?php echo JsEncode($userpurchasepayment_search->feefranchiseeshare->errorMessage()) ?>");
		elm = this.getElements("x" + infix + "_feeresellershare");
		if (elm && !ew.checkNumber(elm.value))
			return this.onError(elm, "<?php echo JsEncode($userpurchasepayment_search->feeresellershare->errorMessage()) ?>");

		// Call Form_CustomValidate event
		if (!this.Form_CustomValidate(fobj))
			return false;
		return true;
	}

	// Form_CustomValidate
	fuserpurchasepaymentsearch.Form_CustomValidate = function(fobj) { // DO NOT CHANGE THIS LINE!

		// Your custom validation code here, return false if invalid.
		return true;
	}

	// Use JavaScript validation or not
	fuserpurchasepaymentsearch.validateRequired = <?php echo Config("CLIENT_VALIDATE") ? "true" : "false" ?>;

	// Dynamic selection lists
	fuserpurchasepaymentsearch.lists["x_paidsuccessfully"] = <?php echo $userpurchasepayment_search->paidsuccessfully->Lookup->toClientList($userpurchasepayment_search) ?>;
	fuserpurchasepaymentsearch.lists["x_paidsuccessfully"].options = <?php echo JsonEncode($userpurchasepayment_search->paidsuccessfully->options(FALSE, TRUE)) ?>;
	fuserpurchasepaymentsearch.lists["x_refunded"] = <?php echo $userpurchasepayment_search->refunded->Lookup->toClientList($userpurchasepayment_search) ?>;
	fuserpurchasepaymentsearch.lists["x_refunded"].options = <?php echo JsonEncode($userpurchasepayment_search->refunded->lookupOptions()) ?>;
	fuserpurchasepaymentsearch.lists["x_refundrequested"] = <?php echo $userpurchasepayment_search->refundrequested->Lookup->toClientList($userpurchasepayment_search) ?>;
	fuserpurchasepaymentsearch.lists["x_refundrequested"].options = <?php echo JsonEncode($userpurchasepayment_search->refundrequested->lookupOptions()) ?>;
	loadjs.done("fuserpurchasepaymentsearch");
});
</script>
<script>
loadjs.ready("head", function() {

	// Client script
	// Write your client script here, no need to add script tags.

});
</script>
<?php $userpurchasepayment_search->showPageHeader(); ?>
<?php
$userpurchasepayment_search->showMessage();
?>
<form name="fuserpurchasepaymentsearch" id="fuserpurchasepaymentsearch" class="<?php echo $userpurchasepayment_search->FormClassName ?>" action="<?php echo CurrentPageName() ?>" method="post">
<?php if ($Page->CheckToken) { ?>
<input type="hidden" name="<?php echo Config("TOKEN_NAME") ?>" value="<?php echo $Page->Token ?>">
<?php } ?>
<input type="hidden" name="t" value="userpurchasepayment">
<input type="hidden" name="action" id="action" value="search">
<input type="hidden" name="modal" value="<?php echo (int)$userpurchasepayment_search->IsModal ?>">
<div class="ew-multi-page"><!-- multi-page -->
<div class="ew-nav-tabs" id="userpurchasepayment_search"><!-- multi-page tabs -->
	<ul class="<?php echo $userpurchasepayment_search->MultiPages->navStyle() ?>">
		<li class="nav-item"><a class="nav-link<?php echo $userpurchasepayment_search->MultiPages->pageStyle(1) ?>" href="#tab_userpurchasepayment1" data-toggle="tab"><?php echo $userpurchasepayment->pageCaption(1) ?></a></li>
		<li class="nav-item"><a class="nav-link<?php echo $userpurchasepayment_search->MultiPages->pageStyle(2) ?>" href="#tab_userpurchasepayment2" data-toggle="tab"><?php echo $userpurchasepayment->pageCaption(2) ?></a></li>
	</ul>
	<div class="tab-content"><!-- multi-page tabs .tab-content -->
		<div class="tab-pane<?php echo $userpurchasepayment_search->MultiPages->pageStyle(1) ?>" id="tab_userpurchasepayment1"><!-- multi-page .tab-pane -->
<div class="ew-search-div"><!-- page* -->
<?php if ($userpurchasepayment_search->paymentid->Visible) { // paymentid ?>
	<div id="r_paymentid" class="form-group row">
		<label for="x_paymentid" class="<?php echo $userpurchasepayment_search->LeftColumnClass ?>"><span id="elh_userpurchasepayment_paymentid"><?php echo $userpurchasepayment_search->paymentid->caption() ?></span>
		<span class="ew-search-operator">
<?php echo $Language->phrase("=") ?>
<input type="hidden" name="z_paymentid" id="z_paymentid" value="=">
</span>
		</label>
		<div class="<?php echo $userpurchasepayment_search->RightColumnClass ?>"><div <?php echo $userpurchasepayment_search->paymentid->cellAttributes() ?>>
			<span id="el_userpurchasepayment_paymentid" class="ew-search-field">
<input type="text" data-table="userpurchasepayment" data-field="x_paymentid" data-page="1" name="x_paymentid" id="x_paymentid" placeholder="<?php echo HtmlEncode($userpurchasepayment_search->paymentid->getPlaceHolder()) ?>" value="<?php echo $userpurchasepayment_search->paymentid->EditValue ?>"<?php echo $userpurchasepayment_search->paymentid->editAttributes() ?>>
</span>
		</div></div>
	</div>
<?php } ?>
<?php if ($userpurchasepayment_search->purchaseid->Visible) { // purchaseid ?>
	<div id="r_purchaseid" class="form-group row">
		<label for="x_purchaseid" class="<?php echo $userpurchasepayment_search->LeftColumnClass ?>"><span id="elh_userpurchasepayment_purchaseid"><?php echo $userpurchasepayment_search->purchaseid->caption() ?></span>
		<span class="ew-search-operator">
<?php echo $Language->phrase("=") ?>
<input type="hidden" name="z_purchaseid" id="z_purchaseid" value="=">
</span>
		</label>
		<div class="<?php echo $userpurchasepayment_search->RightColumnClass ?>"><div <?php echo $userpurchasepayment_search->purchaseid->cellAttributes() ?>>
			<span id="el_userpurchasepayment_purchaseid" class="ew-search-field">
<input type="text" data-table="userpurchasepayment" data-field="x_purchaseid" data-page="1" name="x_purchaseid" id="x_purchaseid" size="30" placeholder="<?php echo HtmlEncode($userpurchasepayment_search->purchaseid->getPlaceHolder()) ?>" value="<?php echo $userpurchasepayment_search->purchaseid->EditValue ?>"<?php echo $userpurchasepayment_search->purchaseid->editAttributes() ?>>
</span>
		</div></div>
	</div>
<?php } ?>
<?php if ($userpurchasepayment_search->userpiid->Visible) { // userpiid ?>
	<div id="r_userpiid" class="form-group row">
		<label for="x_userpiid" class="<?php echo $userpurchasepayment_search->LeftColumnClass ?>"><span id="elh_userpurchasepayment_userpiid"><?php echo $userpurchasepayment_search->userpiid->caption() ?></span>
		<span class="ew-search-operator">
<?php echo $Language->phrase("=") ?>
<input type="hidden" name="z_userpiid" id="z_userpiid" value="=">
</span>
		</label>
		<div class="<?php echo $userpurchasepayment_search->RightColumnClass ?>"><div <?php echo $userpurchasepayment_search->userpiid->cellAttributes() ?>>
			<span id="el_userpurchasepayment_userpiid" class="ew-search-field">
<input type="text" data-table="userpurchasepayment" data-field="x_userpiid" data-page="1" name="x_userpiid" id="x_userpiid" size="30" maxlength="7" placeholder="<?php echo HtmlEncode($userpurchasepayment_search->userpiid->getPlaceHolder()) ?>" value="<?php echo $userpurchasepayment_search->userpiid->EditValue ?>"<?php echo $userpurchasepayment_search->userpiid->editAttributes() ?>>
</span>
		</div></div>
	</div>
<?php } ?>
<?php if ($userpurchasepayment_search->userpi->Visible) { // userpi ?>
	<div id="r_userpi" class="form-group row">
		<label for="x_userpi" class="<?php echo $userpurchasepayment_search->LeftColumnClass ?>"><span id="elh_userpurchasepayment_userpi"><?php echo $userpurchasepayment_search->userpi->caption() ?></span>
		<span class="ew-search-operator">
<?php echo $Language->phrase("=") ?>
<input type="hidden" name="z_userpi" id="z_userpi" value="=">
</span>
		</label>
		<div class="<?php echo $userpurchasepayment_search->RightColumnClass ?>"><div <?php echo $userpurchasepayment_search->userpi->cellAttributes() ?>>
			<span id="el_userpurchasepayment_userpi" class="ew-search-field">
<input type="text" data-table="userpurchasepayment" data-field="x_userpi" data-page="1" name="x_userpi" id="x_userpi" size="30" placeholder="<?php echo HtmlEncode($userpurchasepayment_search->userpi->getPlaceHolder()) ?>" value="<?php echo $userpurchasepayment_search->userpi->EditValue ?>"<?php echo $userpurchasepayment_search->userpi->editAttributes() ?>>
</span>
		</div></div>
	</div>
<?php } ?>
<?php if ($userpurchasepayment_search->otherconfirmref->Visible) { // otherconfirmref ?>
	<div id="r_otherconfirmref" class="form-group row">
		<label for="x_otherconfirmref" class="<?php echo $userpurchasepayment_search->LeftColumnClass ?>"><span id="elh_userpurchasepayment_otherconfirmref"><?php echo $userpurchasepayment_search->otherconfirmref->caption() ?></span>
		<span class="ew-search-operator">
<?php echo $Language->phrase("LIKE") ?>
<input type="hidden" name="z_otherconfirmref" id="z_otherconfirmref" value="LIKE">
</span>
		</label>
		<div class="<?php echo $userpurchasepayment_search->RightColumnClass ?>"><div <?php echo $userpurchasepayment_search->otherconfirmref->cellAttributes() ?>>
			<span id="el_userpurchasepayment_otherconfirmref" class="ew-search-field">
<input type="text" data-table="userpurchasepayment" data-field="x_otherconfirmref" data-page="1" name="x_otherconfirmref" id="x_otherconfirmref" size="35" placeholder="<?php echo HtmlEncode($userpurchasepayment_search->otherconfirmref->getPlaceHolder()) ?>" value="<?php echo $userpurchasepayment_search->otherconfirmref->EditValue ?>"<?php echo $userpurchasepayment_search->otherconfirmref->editAttributes() ?>>
</span>
		</div></div>
	</div>
<?php } ?>
<?php if ($userpurchasepayment_search->merchantfees->Visible) { // merchantfees ?>
	<div id="r_merchantfees" class="form-group row">
		<label for="x_merchantfees" class="<?php echo $userpurchasepayment_search->LeftColumnClass ?>"><span id="elh_userpurchasepayment_merchantfees"><?php echo $userpurchasepayment_search->merchantfees->caption() ?></span>
		<span class="ew-search-operator">
<?php echo $Language->phrase("=") ?>
<input type="hidden" name="z_merchantfees" id="z_merchantfees" value="=">
</span>
		</label>
		<div class="<?php echo $userpurchasepayment_search->RightColumnClass ?>"><div <?php echo $userpurchasepayment_search->merchantfees->cellAttributes() ?>>
			<span id="el_userpurchasepayment_merchantfees" class="ew-search-field">
<input type="text" data-table="userpurchasepayment" data-field="x_merchantfees" data-page="1" name="x_merchantfees" id="x_merchantfees" size="30" placeholder="<?php echo HtmlEncode($userpurchasepayment_search->merchantfees->getPlaceHolder()) ?>" value="<?php echo $userpurchasepayment_search->merchantfees->EditValue ?>"<?php echo $userpurchasepayment_search->merchantfees->editAttributes() ?>>
</span>
		</div></div>
	</div>
<?php } ?>
<?php if ($userpurchasepayment_search->consumerfees->Visible) { // consumerfees ?>
	<div id="r_consumerfees" class="form-group row">
		<label for="x_consumerfees" class="<?php echo $userpurchasepayment_search->LeftColumnClass ?>"><span id="elh_userpurchasepayment_consumerfees"><?php echo $userpurchasepayment_search->consumerfees->caption() ?></span>
		<span class="ew-search-operator">
<?php echo $Language->phrase("=") ?>
<input type="hidden" name="z_consumerfees" id="z_consumerfees" value="=">
</span>
		</label>
		<div class="<?php echo $userpurchasepayment_search->RightColumnClass ?>"><div <?php echo $userpurchasepayment_search->consumerfees->cellAttributes() ?>>
			<span id="el_userpurchasepayment_consumerfees" class="ew-search-field">
<input type="text" data-table="userpurchasepayment" data-field="x_consumerfees" data-page="1" name="x_consumerfees" id="x_consumerfees" size="30" placeholder="<?php echo HtmlEncode($userpurchasepayment_search->consumerfees->getPlaceHolder()) ?>" value="<?php echo $userpurchasepayment_search->consumerfees->EditValue ?>"<?php echo $userpurchasepayment_search->consumerfees->editAttributes() ?>>
</span>
		</div></div>
	</div>
<?php } ?>
<?php if ($userpurchasepayment_search->currencycode->Visible) { // currencycode ?>
	<div id="r_currencycode" class="form-group row">
		<label for="x_currencycode" class="<?php echo $userpurchasepayment_search->LeftColumnClass ?>"><span id="elh_userpurchasepayment_currencycode"><?php echo $userpurchasepayment_search->currencycode->caption() ?></span>
		<span class="ew-search-operator">
<?php echo $Language->phrase("LIKE") ?>
<input type="hidden" name="z_currencycode" id="z_currencycode" value="LIKE">
</span>
		</label>
		<div class="<?php echo $userpurchasepayment_search->RightColumnClass ?>"><div <?php echo $userpurchasepayment_search->currencycode->cellAttributes() ?>>
			<span id="el_userpurchasepayment_currencycode" class="ew-search-field">
<input type="text" data-table="userpurchasepayment" data-field="x_currencycode" data-page="1" name="x_currencycode" id="x_currencycode" size="30" maxlength="3" placeholder="<?php echo HtmlEncode($userpurchasepayment_search->currencycode->getPlaceHolder()) ?>" value="<?php echo $userpurchasepayment_search->currencycode->EditValue ?>"<?php echo $userpurchasepayment_search->currencycode->editAttributes() ?>>
</span>
		</div></div>
	</div>
<?php } ?>
<?php if ($userpurchasepayment_search->paidsuccessfully->Visible) { // paidsuccessfully ?>
	<div id="r_paidsuccessfully" class="form-group row">
		<label for="x_paidsuccessfully" class="<?php echo $userpurchasepayment_search->LeftColumnClass ?>"><span id="elh_userpurchasepayment_paidsuccessfully"><?php echo $userpurchasepayment_search->paidsuccessfully->caption() ?></span>
		<span class="ew-search-operator">
<?php echo $Language->phrase("=") ?>
<input type="hidden" name="z_paidsuccessfully" id="z_paidsuccessfully" value="=">
</span>
		</label>
		<div class="<?php echo $userpurchasepayment_search->RightColumnClass ?>"><div <?php echo $userpurchasepayment_search->paidsuccessfully->cellAttributes() ?>>
			<span id="el_userpurchasepayment_paidsuccessfully" class="ew-search-field">
<div class="input-group">
	<select class="custom-select ew-custom-select" data-table="userpurchasepayment" data-field="x_paidsuccessfully" data-page="1" data-value-separator="<?php echo $userpurchasepayment_search->paidsuccessfully->displayValueSeparatorAttribute() ?>" id="x_paidsuccessfully" name="x_paidsuccessfully"<?php echo $userpurchasepayment_search->paidsuccessfully->editAttributes() ?>>
			<?php echo $userpurchasepayment_search->paidsuccessfully->selectOptionListHtml("x_paidsuccessfully") ?>
		</select>
</div>
</span>
		</div></div>
	</div>
<?php } ?>
<?php if ($userpurchasepayment_search->refunded->Visible) { // refunded ?>
	<div id="r_refunded" class="form-group row">
		<label class="<?php echo $userpurchasepayment_search->LeftColumnClass ?>"><span id="elh_userpurchasepayment_refunded"><?php echo $userpurchasepayment_search->refunded->caption() ?></span>
		<span class="ew-search-operator">
<?php echo $Language->phrase("=") ?>
<input type="hidden" name="z_refunded" id="z_refunded" value="=">
</span>
		</label>
		<div class="<?php echo $userpurchasepayment_search->RightColumnClass ?>"><div <?php echo $userpurchasepayment_search->refunded->cellAttributes() ?>>
			<span id="el_userpurchasepayment_refunded" class="ew-search-field">
<div id="tp_x_refunded" class="ew-template"><input type="radio" class="custom-control-input" data-table="userpurchasepayment" data-field="x_refunded" data-page="1" data-value-separator="<?php echo $userpurchasepayment_search->refunded->displayValueSeparatorAttribute() ?>" name="x_refunded" id="x_refunded" value="{value}"<?php echo $userpurchasepayment_search->refunded->editAttributes() ?>></div>
<div id="dsl_x_refunded" data-repeatcolumn="5" class="ew-item-list d-none"><div>
<?php echo $userpurchasepayment_search->refunded->radioButtonListHtml(FALSE, "x_refunded", 1) ?>
</div></div>
<?php echo $userpurchasepayment_search->refunded->Lookup->getParamTag($userpurchasepayment_search, "p_x_refunded") ?>
</span>
		</div></div>
	</div>
<?php } ?>
<?php if ($userpurchasepayment_search->refundrequested->Visible) { // refundrequested ?>
	<div id="r_refundrequested" class="form-group row">
		<label class="<?php echo $userpurchasepayment_search->LeftColumnClass ?>"><span id="elh_userpurchasepayment_refundrequested"><?php echo $userpurchasepayment_search->refundrequested->caption() ?></span>
		<span class="ew-search-operator">
<?php echo $Language->phrase("=") ?>
<input type="hidden" name="z_refundrequested" id="z_refundrequested" value="=">
</span>
		</label>
		<div class="<?php echo $userpurchasepayment_search->RightColumnClass ?>"><div <?php echo $userpurchasepayment_search->refundrequested->cellAttributes() ?>>
			<span id="el_userpurchasepayment_refundrequested" class="ew-search-field">
<div id="tp_x_refundrequested" class="ew-template"><input type="radio" class="custom-control-input" data-table="userpurchasepayment" data-field="x_refundrequested" data-page="1" data-value-separator="<?php echo $userpurchasepayment_search->refundrequested->displayValueSeparatorAttribute() ?>" name="x_refundrequested" id="x_refundrequested" value="{value}"<?php echo $userpurchasepayment_search->refundrequested->editAttributes() ?>></div>
<div id="dsl_x_refundrequested" data-repeatcolumn="5" class="ew-item-list d-none"><div>
<?php echo $userpurchasepayment_search->refundrequested->radioButtonListHtml(FALSE, "x_refundrequested", 1) ?>
</div></div>
<?php echo $userpurchasepayment_search->refundrequested->Lookup->getParamTag($userpurchasepayment_search, "p_x_refundrequested") ?>
</span>
		</div></div>
	</div>
<?php } ?>
<?php if ($userpurchasepayment_search->refundrequesttxid->Visible) { // refundrequesttxid ?>
	<div id="r_refundrequesttxid" class="form-group row">
		<label for="x_refundrequesttxid" class="<?php echo $userpurchasepayment_search->LeftColumnClass ?>"><span id="elh_userpurchasepayment_refundrequesttxid"><?php echo $userpurchasepayment_search->refundrequesttxid->caption() ?></span>
		<span class="ew-search-operator">
<?php echo $Language->phrase("LIKE") ?>
<input type="hidden" name="z_refundrequesttxid" id="z_refundrequesttxid" value="LIKE">
</span>
		</label>
		<div class="<?php echo $userpurchasepayment_search->RightColumnClass ?>"><div <?php echo $userpurchasepayment_search->refundrequesttxid->cellAttributes() ?>>
			<span id="el_userpurchasepayment_refundrequesttxid" class="ew-search-field">
<input type="text" data-table="userpurchasepayment" data-field="x_refundrequesttxid" data-page="1" name="x_refundrequesttxid" id="x_refundrequesttxid" size="30" maxlength="9" placeholder="<?php echo HtmlEncode($userpurchasepayment_search->refundrequesttxid->getPlaceHolder()) ?>" value="<?php echo $userpurchasepayment_search->refundrequesttxid->EditValue ?>"<?php echo $userpurchasepayment_search->refundrequesttxid->editAttributes() ?>>
</span>
		</div></div>
	</div>
<?php } ?>
<?php if ($userpurchasepayment_search->paymentdatetime->Visible) { // paymentdatetime ?>
	<div id="r_paymentdatetime" class="form-group row">
		<label for="x_paymentdatetime" class="<?php echo $userpurchasepayment_search->LeftColumnClass ?>"><span id="elh_userpurchasepayment_paymentdatetime"><?php echo $userpurchasepayment_search->paymentdatetime->caption() ?></span>
		<span class="ew-search-operator">
<?php echo $Language->phrase("=") ?>
<input type="hidden" name="z_paymentdatetime" id="z_paymentdatetime" value="=">
</span>
		</label>
		<div class="<?php echo $userpurchasepayment_search->RightColumnClass ?>"><div <?php echo $userpurchasepayment_search->paymentdatetime->cellAttributes() ?>>
			<span id="el_userpurchasepayment_paymentdatetime" class="ew-search-field">
<input type="text" data-table="userpurchasepayment" data-field="x_paymentdatetime" data-page="1" name="x_paymentdatetime" id="x_paymentdatetime" placeholder="<?php echo HtmlEncode($userpurchasepayment_search->paymentdatetime->getPlaceHolder()) ?>" value="<?php echo $userpurchasepayment_search->paymentdatetime->EditValue ?>"<?php echo $userpurchasepayment_search->paymentdatetime->editAttributes() ?>>
</span>
		</div></div>
	</div>
<?php } ?>
<?php if ($userpurchasepayment_search->feesystemshare->Visible) { // feesystemshare ?>
	<div id="r_feesystemshare" class="form-group row">
		<label for="x_feesystemshare" class="<?php echo $userpurchasepayment_search->LeftColumnClass ?>"><span id="elh_userpurchasepayment_feesystemshare"><?php echo $userpurchasepayment_search->feesystemshare->caption() ?></span>
		<span class="ew-search-operator">
<?php echo $Language->phrase("=") ?>
<input type="hidden" name="z_feesystemshare" id="z_feesystemshare" value="=">
</span>
		</label>
		<div class="<?php echo $userpurchasepayment_search->RightColumnClass ?>"><div <?php echo $userpurchasepayment_search->feesystemshare->cellAttributes() ?>>
			<span id="el_userpurchasepayment_feesystemshare" class="ew-search-field">
<input type="text" data-table="userpurchasepayment" data-field="x_feesystemshare" data-page="1" name="x_feesystemshare" id="x_feesystemshare" size="30" placeholder="<?php echo HtmlEncode($userpurchasepayment_search->feesystemshare->getPlaceHolder()) ?>" value="<?php echo $userpurchasepayment_search->feesystemshare->EditValue ?>"<?php echo $userpurchasepayment_search->feesystemshare->editAttributes() ?>>
</span>
		</div></div>
	</div>
<?php } ?>
<?php if ($userpurchasepayment_search->feeexternalshare->Visible) { // feeexternalshare ?>
	<div id="r_feeexternalshare" class="form-group row">
		<label for="x_feeexternalshare" class="<?php echo $userpurchasepayment_search->LeftColumnClass ?>"><span id="elh_userpurchasepayment_feeexternalshare"><?php echo $userpurchasepayment_search->feeexternalshare->caption() ?></span>
		<span class="ew-search-operator">
<?php echo $Language->phrase("=") ?>
<input type="hidden" name="z_feeexternalshare" id="z_feeexternalshare" value="=">
</span>
		</label>
		<div class="<?php echo $userpurchasepayment_search->RightColumnClass ?>"><div <?php echo $userpurchasepayment_search->feeexternalshare->cellAttributes() ?>>
			<span id="el_userpurchasepayment_feeexternalshare" class="ew-search-field">
<input type="text" data-table="userpurchasepayment" data-field="x_feeexternalshare" data-page="1" name="x_feeexternalshare" id="x_feeexternalshare" size="30" placeholder="<?php echo HtmlEncode($userpurchasepayment_search->feeexternalshare->getPlaceHolder()) ?>" value="<?php echo $userpurchasepayment_search->feeexternalshare->EditValue ?>"<?php echo $userpurchasepayment_search->feeexternalshare->editAttributes() ?>>
</span>
		</div></div>
	</div>
<?php } ?>
<?php if ($userpurchasepayment_search->feefranchiseeshare->Visible) { // feefranchiseeshare ?>
	<div id="r_feefranchiseeshare" class="form-group row">
		<label for="x_feefranchiseeshare" class="<?php echo $userpurchasepayment_search->LeftColumnClass ?>"><span id="elh_userpurchasepayment_feefranchiseeshare"><?php echo $userpurchasepayment_search->feefranchiseeshare->caption() ?></span>
		<span class="ew-search-operator">
<?php echo $Language->phrase("=") ?>
<input type="hidden" name="z_feefranchiseeshare" id="z_feefranchiseeshare" value="=">
</span>
		</label>
		<div class="<?php echo $userpurchasepayment_search->RightColumnClass ?>"><div <?php echo $userpurchasepayment_search->feefranchiseeshare->cellAttributes() ?>>
			<span id="el_userpurchasepayment_feefranchiseeshare" class="ew-search-field">
<input type="text" data-table="userpurchasepayment" data-field="x_feefranchiseeshare" data-page="1" name="x_feefranchiseeshare" id="x_feefranchiseeshare" size="30" placeholder="<?php echo HtmlEncode($userpurchasepayment_search->feefranchiseeshare->getPlaceHolder()) ?>" value="<?php echo $userpurchasepayment_search->feefranchiseeshare->EditValue ?>"<?php echo $userpurchasepayment_search->feefranchiseeshare->editAttributes() ?>>
</span>
		</div></div>
	</div>
<?php } ?>
<?php if ($userpurchasepayment_search->feeresellershare->Visible) { // feeresellershare ?>
	<div id="r_feeresellershare" class="form-group row">
		<label for="x_feeresellershare" class="<?php echo $userpurchasepayment_search->LeftColumnClass ?>"><span id="elh_userpurchasepayment_feeresellershare"><?php echo $userpurchasepayment_search->feeresellershare->caption() ?></span>
		<span class="ew-search-operator">
<?php echo $Language->phrase("=") ?>
<input type="hidden" name="z_feeresellershare" id="z_feeresellershare" value="=">
</span>
		</label>
		<div class="<?php echo $userpurchasepayment_search->RightColumnClass ?>"><div <?php echo $userpurchasepayment_search->feeresellershare->cellAttributes() ?>>
			<span id="el_userpurchasepayment_feeresellershare" class="ew-search-field">
<input type="text" data-table="userpurchasepayment" data-field="x_feeresellershare" data-page="1" name="x_feeresellershare" id="x_feeresellershare" size="30" placeholder="<?php echo HtmlEncode($userpurchasepayment_search->feeresellershare->getPlaceHolder()) ?>" value="<?php echo $userpurchasepayment_search->feeresellershare->EditValue ?>"<?php echo $userpurchasepayment_search->feeresellershare->editAttributes() ?>>
</span>
		</div></div>
	</div>
<?php } ?>
</div><!-- /page* -->
		</div><!-- /multi-page .tab-pane -->
		<div class="tab-pane<?php echo $userpurchasepayment_search->MultiPages->pageStyle(2) ?>" id="tab_userpurchasepayment2"><!-- multi-page .tab-pane -->
<div class="ew-search-div"><!-- page* -->
<?php if ($userpurchasepayment_search->processoroutput->Visible) { // processoroutput ?>
	<div id="r_processoroutput" class="form-group row">
		<label for="x_processoroutput" class="<?php echo $userpurchasepayment_search->LeftColumnClass ?>"><span id="elh_userpurchasepayment_processoroutput"><?php echo $userpurchasepayment_search->processoroutput->caption() ?></span>
		<span class="ew-search-operator">
<?php echo $Language->phrase("LIKE") ?>
<input type="hidden" name="z_processoroutput" id="z_processoroutput" value="LIKE">
</span>
		</label>
		<div class="<?php echo $userpurchasepayment_search->RightColumnClass ?>"><div <?php echo $userpurchasepayment_search->processoroutput->cellAttributes() ?>>
			<span id="el_userpurchasepayment_processoroutput" class="ew-search-field">
<input type="text" data-table="userpurchasepayment" data-field="x_processoroutput" data-page="2" name="x_processoroutput" id="x_processoroutput" size="35" placeholder="<?php echo HtmlEncode($userpurchasepayment_search->processoroutput->getPlaceHolder()) ?>" value="<?php echo $userpurchasepayment_search->processoroutput->EditValue ?>"<?php echo $userpurchasepayment_search->processoroutput->editAttributes() ?>>
</span>
		</div></div>
	</div>
<?php } ?>
<?php if ($userpurchasepayment_search->processoroutput2->Visible) { // processoroutput2 ?>
	<div id="r_processoroutput2" class="form-group row">
		<label class="<?php echo $userpurchasepayment_search->LeftColumnClass ?>"><span id="elh_userpurchasepayment_processoroutput2"><?php echo $userpurchasepayment_search->processoroutput2->caption() ?></span>
		<span class="ew-search-operator">
<?php echo $Language->phrase("LIKE") ?>
<input type="hidden" name="z_processoroutput2" id="z_processoroutput2" value="LIKE">
</span>
		</label>
		<div class="<?php echo $userpurchasepayment_search->RightColumnClass ?>"><div <?php echo $userpurchasepayment_search->processoroutput2->cellAttributes() ?>>
			<span id="el_userpurchasepayment_processoroutput2" class="ew-search-field">
<input type="text" data-table="userpurchasepayment" data-field="x_processoroutput2" data-page="2" name="x_processoroutput2" id="x_processoroutput2" size="35" placeholder="<?php echo HtmlEncode($userpurchasepayment_search->processoroutput2->getPlaceHolder()) ?>" value="<?php echo $userpurchasepayment_search->processoroutput2->EditValue ?>"<?php echo $userpurchasepayment_search->processoroutput2->editAttributes() ?>>
</span>
		</div></div>
	</div>
<?php } ?>
<?php if ($userpurchasepayment_search->processoroutput3->Visible) { // processoroutput3 ?>
	<div id="r_processoroutput3" class="form-group row">
		<label for="x_processoroutput3" class="<?php echo $userpurchasepayment_search->LeftColumnClass ?>"><span id="elh_userpurchasepayment_processoroutput3"><?php echo $userpurchasepayment_search->processoroutput3->caption() ?></span>
		<span class="ew-search-operator">
<?php echo $Language->phrase("LIKE") ?>
<input type="hidden" name="z_processoroutput3" id="z_processoroutput3" value="LIKE">
</span>
		</label>
		<div class="<?php echo $userpurchasepayment_search->RightColumnClass ?>"><div <?php echo $userpurchasepayment_search->processoroutput3->cellAttributes() ?>>
			<span id="el_userpurchasepayment_processoroutput3" class="ew-search-field">
<input type="text" data-table="userpurchasepayment" data-field="x_processoroutput3" data-page="2" name="x_processoroutput3" id="x_processoroutput3" size="35" placeholder="<?php echo HtmlEncode($userpurchasepayment_search->processoroutput3->getPlaceHolder()) ?>" value="<?php echo $userpurchasepayment_search->processoroutput3->EditValue ?>"<?php echo $userpurchasepayment_search->processoroutput3->editAttributes() ?>>
</span>
		</div></div>
	</div>
<?php } ?>
</div><!-- /page* -->
		</div><!-- /multi-page .tab-pane -->
	</div><!-- /multi-page tabs .tab-content -->
</div><!-- /multi-page tabs -->
</div><!-- /multi-page -->
<?php if (!$userpurchasepayment_search->IsModal) { ?>
<div class="form-group row"><!-- buttons .form-group -->
	<div class="<?php echo $userpurchasepayment_search->OffsetColumnClass ?>"><!-- buttons offset -->
<button class="btn btn-primary ew-btn" name="btn-action" id="btn-action" type="submit"><?php echo $Language->phrase("Search") ?></button>
<button class="btn btn-default ew-btn" name="btn-reset" id="btn-reset" type="button" onclick="ew.clearForm(this.form);"><?php echo $Language->phrase("Reset") ?></button>
	</div><!-- /buttons offset -->
</div><!-- /buttons .form-group -->
<?php } ?>
</form>
<?php
$userpurchasepayment_search->showPageFooter();
if (Config("DEBUG"))
	echo GetDebugMessage();
?>
<script>
loadjs.ready("load", function() {

	// Startup script
	// Write your table-specific startup script here
	// console.log("page loaded");

});
</script>
<?php include_once "footer.php"; ?>
<?php
$userpurchasepayment_search->terminate();
?>