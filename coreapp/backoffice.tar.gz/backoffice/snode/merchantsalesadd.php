<?php
namespace PHPMaker2020\_4payadmin;

// Autoload
include_once "autoload.php";

// Session
if (session_status() !== PHP_SESSION_ACTIVE)
	\Delight\Cookie\Session::start(Config("COOKIE_SAMESITE")); // Init session data

// Output buffering
ob_start();
?>
<?php

// Write header
WriteHeader(FALSE);

// Create page object
$merchantsales_add = new merchantsales_add();

// Run the page
$merchantsales_add->run();

// Setup login status
SetupLoginStatus();
SetClientVar("login", LoginStatus());

// Global Page Rendering event (in userfn*.php)
Page_Rendering();

// Page Rendering event
$merchantsales_add->Page_Render();
?>
<?php include_once "header.php"; ?>
<script>
var fmerchantsalesadd, currentPageID;
loadjs.ready("head", function() {

	// Form object
	currentPageID = ew.PAGE_ID = "add";
	fmerchantsalesadd = currentForm = new ew.Form("fmerchantsalesadd", "add");

	// Validate form
	fmerchantsalesadd.validate = function() {
		if (!this.validateRequired)
			return true; // Ignore validation
		var $ = jQuery, fobj = this.getForm(), $fobj = $(fobj);
		if ($fobj.find("#confirm").val() == "confirm")
			return true;
		var elm, felm, uelm, addcnt = 0;
		var $k = $fobj.find("#" + this.formKeyCountName); // Get key_count
		var rowcnt = ($k[0]) ? parseInt($k.val(), 10) : 1;
		var startcnt = (rowcnt == 0) ? 0 : 1; // Check rowcnt == 0 => Inline-Add
		var gridinsert = ["insert", "gridinsert"].includes($fobj.find("#action").val()) && $k[0];
		for (var i = startcnt; i <= rowcnt; i++) {
			var infix = ($k[0]) ? String(i) : "";
			$fobj.data("rowindex", infix);
			<?php if ($merchantsales_add->txid->Required) { ?>
				elm = this.getElements("x" + infix + "_txid");
				if (elm && !ew.isHidden(elm) && !ew.hasValue(elm))
					return this.onError(elm, "<?php echo JsEncode(str_replace("%s", $merchantsales_add->txid->caption(), $merchantsales_add->txid->RequiredErrorMessage)) ?>");
			<?php } ?>
			<?php if ($merchantsales_add->merchantID->Required) { ?>
				elm = this.getElements("x" + infix + "_merchantID");
				if (elm && !ew.isHidden(elm) && !ew.hasValue(elm))
					return this.onError(elm, "<?php echo JsEncode(str_replace("%s", $merchantsales_add->merchantID->caption(), $merchantsales_add->merchantID->RequiredErrorMessage)) ?>");
			<?php } ?>
			<?php if ($merchantsales_add->_userID->Required) { ?>
				elm = this.getElements("x" + infix + "__userID");
				if (elm && !ew.isHidden(elm) && !ew.hasValue(elm))
					return this.onError(elm, "<?php echo JsEncode(str_replace("%s", $merchantsales_add->_userID->caption(), $merchantsales_add->_userID->RequiredErrorMessage)) ?>");
			<?php } ?>
				elm = this.getElements("x" + infix + "__userID");
				if (elm && !ew.checkInteger(elm.value))
					return this.onError(elm, "<?php echo JsEncode($merchantsales_add->_userID->errorMessage()) ?>");
			<?php if ($merchantsales_add->transferTime->Required) { ?>
				elm = this.getElements("x" + infix + "_transferTime");
				if (elm && !ew.isHidden(elm) && !ew.hasValue(elm))
					return this.onError(elm, "<?php echo JsEncode(str_replace("%s", $merchantsales_add->transferTime->caption(), $merchantsales_add->transferTime->RequiredErrorMessage)) ?>");
			<?php } ?>
				elm = this.getElements("x" + infix + "_transferTime");
				if (elm && !ew.checkUSDate(elm.value))
					return this.onError(elm, "<?php echo JsEncode($merchantsales_add->transferTime->errorMessage()) ?>");
			<?php if ($merchantsales_add->currID->Required) { ?>
				elm = this.getElements("x" + infix + "_currID");
				if (elm && !ew.isHidden(elm) && !ew.hasValue(elm))
					return this.onError(elm, "<?php echo JsEncode(str_replace("%s", $merchantsales_add->currID->caption(), $merchantsales_add->currID->RequiredErrorMessage)) ?>");
			<?php } ?>
			<?php if ($merchantsales_add->purchaseAmount->Required) { ?>
				elm = this.getElements("x" + infix + "_purchaseAmount");
				if (elm && !ew.isHidden(elm) && !ew.hasValue(elm))
					return this.onError(elm, "<?php echo JsEncode(str_replace("%s", $merchantsales_add->purchaseAmount->caption(), $merchantsales_add->purchaseAmount->RequiredErrorMessage)) ?>");
			<?php } ?>
				elm = this.getElements("x" + infix + "_purchaseAmount");
				if (elm && !ew.checkNumber(elm.value))
					return this.onError(elm, "<?php echo JsEncode($merchantsales_add->purchaseAmount->errorMessage()) ?>");
			<?php if ($merchantsales_add->merchantSurcharge->Required) { ?>
				elm = this.getElements("x" + infix + "_merchantSurcharge");
				if (elm && !ew.isHidden(elm) && !ew.hasValue(elm))
					return this.onError(elm, "<?php echo JsEncode(str_replace("%s", $merchantsales_add->merchantSurcharge->caption(), $merchantsales_add->merchantSurcharge->RequiredErrorMessage)) ?>");
			<?php } ?>
				elm = this.getElements("x" + infix + "_merchantSurcharge");
				if (elm && !ew.checkNumber(elm.value))
					return this.onError(elm, "<?php echo JsEncode($merchantsales_add->merchantSurcharge->errorMessage()) ?>");
			<?php if ($merchantsales_add->taxAmount->Required) { ?>
				elm = this.getElements("x" + infix + "_taxAmount");
				if (elm && !ew.isHidden(elm) && !ew.hasValue(elm))
					return this.onError(elm, "<?php echo JsEncode(str_replace("%s", $merchantsales_add->taxAmount->caption(), $merchantsales_add->taxAmount->RequiredErrorMessage)) ?>");
			<?php } ?>
				elm = this.getElements("x" + infix + "_taxAmount");
				if (elm && !ew.checkNumber(elm.value))
					return this.onError(elm, "<?php echo JsEncode($merchantsales_add->taxAmount->errorMessage()) ?>");
			<?php if ($merchantsales_add->tipAmount->Required) { ?>
				elm = this.getElements("x" + infix + "_tipAmount");
				if (elm && !ew.isHidden(elm) && !ew.hasValue(elm))
					return this.onError(elm, "<?php echo JsEncode(str_replace("%s", $merchantsales_add->tipAmount->caption(), $merchantsales_add->tipAmount->RequiredErrorMessage)) ?>");
			<?php } ?>
				elm = this.getElements("x" + infix + "_tipAmount");
				if (elm && !ew.checkNumber(elm.value))
					return this.onError(elm, "<?php echo JsEncode($merchantsales_add->tipAmount->errorMessage()) ?>");
			<?php if ($merchantsales_add->serviceFeeToCustomer->Required) { ?>
				elm = this.getElements("x" + infix + "_serviceFeeToCustomer");
				if (elm && !ew.isHidden(elm) && !ew.hasValue(elm))
					return this.onError(elm, "<?php echo JsEncode(str_replace("%s", $merchantsales_add->serviceFeeToCustomer->caption(), $merchantsales_add->serviceFeeToCustomer->RequiredErrorMessage)) ?>");
			<?php } ?>
				elm = this.getElements("x" + infix + "_serviceFeeToCustomer");
				if (elm && !ew.checkNumber(elm.value))
					return this.onError(elm, "<?php echo JsEncode($merchantsales_add->serviceFeeToCustomer->errorMessage()) ?>");
			<?php if ($merchantsales_add->TotalAmountForCustomer->Required) { ?>
				elm = this.getElements("x" + infix + "_TotalAmountForCustomer");
				if (elm && !ew.isHidden(elm) && !ew.hasValue(elm))
					return this.onError(elm, "<?php echo JsEncode(str_replace("%s", $merchantsales_add->TotalAmountForCustomer->caption(), $merchantsales_add->TotalAmountForCustomer->RequiredErrorMessage)) ?>");
			<?php } ?>
				elm = this.getElements("x" + infix + "_TotalAmountForCustomer");
				if (elm && !ew.checkNumber(elm.value))
					return this.onError(elm, "<?php echo JsEncode($merchantsales_add->TotalAmountForCustomer->errorMessage()) ?>");
			<?php if ($merchantsales_add->serviceFeeToMerchant->Required) { ?>
				elm = this.getElements("x" + infix + "_serviceFeeToMerchant");
				if (elm && !ew.isHidden(elm) && !ew.hasValue(elm))
					return this.onError(elm, "<?php echo JsEncode(str_replace("%s", $merchantsales_add->serviceFeeToMerchant->caption(), $merchantsales_add->serviceFeeToMerchant->RequiredErrorMessage)) ?>");
			<?php } ?>
				elm = this.getElements("x" + infix + "_serviceFeeToMerchant");
				if (elm && !ew.checkNumber(elm.value))
					return this.onError(elm, "<?php echo JsEncode($merchantsales_add->serviceFeeToMerchant->errorMessage()) ?>");
			<?php if ($merchantsales_add->status->Required) { ?>
				elm = this.getElements("x" + infix + "_status");
				if (elm && !ew.isHidden(elm) && !ew.hasValue(elm))
					return this.onError(elm, "<?php echo JsEncode(str_replace("%s", $merchantsales_add->status->caption(), $merchantsales_add->status->RequiredErrorMessage)) ?>");
			<?php } ?>
			<?php if ($merchantsales_add->shoppingCartID->Required) { ?>
				elm = this.getElements("x" + infix + "_shoppingCartID");
				if (elm && !ew.isHidden(elm) && !ew.hasValue(elm))
					return this.onError(elm, "<?php echo JsEncode(str_replace("%s", $merchantsales_add->shoppingCartID->caption(), $merchantsales_add->shoppingCartID->RequiredErrorMessage)) ?>");
			<?php } ?>
			<?php if ($merchantsales_add->merchantRefID->Required) { ?>
				elm = this.getElements("x" + infix + "_merchantRefID");
				if (elm && !ew.isHidden(elm) && !ew.hasValue(elm))
					return this.onError(elm, "<?php echo JsEncode(str_replace("%s", $merchantsales_add->merchantRefID->caption(), $merchantsales_add->merchantRefID->RequiredErrorMessage)) ?>");
			<?php } ?>
			<?php if ($merchantsales_add->feeid->Required) { ?>
				elm = this.getElements("x" + infix + "_feeid");
				if (elm && !ew.isHidden(elm) && !ew.hasValue(elm))
					return this.onError(elm, "<?php echo JsEncode(str_replace("%s", $merchantsales_add->feeid->caption(), $merchantsales_add->feeid->RequiredErrorMessage)) ?>");
			<?php } ?>
				elm = this.getElements("x" + infix + "_feeid");
				if (elm && !ew.checkInteger(elm.value))
					return this.onError(elm, "<?php echo JsEncode($merchantsales_add->feeid->errorMessage()) ?>");
			<?php if ($merchantsales_add->ratetabletype->Required) { ?>
				elm = this.getElements("x" + infix + "_ratetabletype");
				if (elm && !ew.isHidden(elm) && !ew.hasValue(elm))
					return this.onError(elm, "<?php echo JsEncode(str_replace("%s", $merchantsales_add->ratetabletype->caption(), $merchantsales_add->ratetabletype->RequiredErrorMessage)) ?>");
			<?php } ?>
				elm = this.getElements("x" + infix + "_ratetabletype");
				if (elm && !ew.checkInteger(elm.value))
					return this.onError(elm, "<?php echo JsEncode($merchantsales_add->ratetabletype->errorMessage()) ?>");
			<?php if ($merchantsales_add->pis->Required) { ?>
				elm = this.getElements("x" + infix + "_pis");
				if (elm && !ew.isHidden(elm) && !ew.hasValue(elm))
					return this.onError(elm, "<?php echo JsEncode(str_replace("%s", $merchantsales_add->pis->caption(), $merchantsales_add->pis->RequiredErrorMessage)) ?>");
			<?php } ?>
			<?php if ($merchantsales_add->feesystemshare->Required) { ?>
				elm = this.getElements("x" + infix + "_feesystemshare");
				if (elm && !ew.isHidden(elm) && !ew.hasValue(elm))
					return this.onError(elm, "<?php echo JsEncode(str_replace("%s", $merchantsales_add->feesystemshare->caption(), $merchantsales_add->feesystemshare->RequiredErrorMessage)) ?>");
			<?php } ?>
				elm = this.getElements("x" + infix + "_feesystemshare");
				if (elm && !ew.checkNumber(elm.value))
					return this.onError(elm, "<?php echo JsEncode($merchantsales_add->feesystemshare->errorMessage()) ?>");
			<?php if ($merchantsales_add->feeexternalshare->Required) { ?>
				elm = this.getElements("x" + infix + "_feeexternalshare");
				if (elm && !ew.isHidden(elm) && !ew.hasValue(elm))
					return this.onError(elm, "<?php echo JsEncode(str_replace("%s", $merchantsales_add->feeexternalshare->caption(), $merchantsales_add->feeexternalshare->RequiredErrorMessage)) ?>");
			<?php } ?>
				elm = this.getElements("x" + infix + "_feeexternalshare");
				if (elm && !ew.checkNumber(elm.value))
					return this.onError(elm, "<?php echo JsEncode($merchantsales_add->feeexternalshare->errorMessage()) ?>");
			<?php if ($merchantsales_add->feefranchiseeshare->Required) { ?>
				elm = this.getElements("x" + infix + "_feefranchiseeshare");
				if (elm && !ew.isHidden(elm) && !ew.hasValue(elm))
					return this.onError(elm, "<?php echo JsEncode(str_replace("%s", $merchantsales_add->feefranchiseeshare->caption(), $merchantsales_add->feefranchiseeshare->RequiredErrorMessage)) ?>");
			<?php } ?>
				elm = this.getElements("x" + infix + "_feefranchiseeshare");
				if (elm && !ew.checkNumber(elm.value))
					return this.onError(elm, "<?php echo JsEncode($merchantsales_add->feefranchiseeshare->errorMessage()) ?>");
			<?php if ($merchantsales_add->feeresellershare->Required) { ?>
				elm = this.getElements("x" + infix + "_feeresellershare");
				if (elm && !ew.isHidden(elm) && !ew.hasValue(elm))
					return this.onError(elm, "<?php echo JsEncode(str_replace("%s", $merchantsales_add->feeresellershare->caption(), $merchantsales_add->feeresellershare->RequiredErrorMessage)) ?>");
			<?php } ?>
				elm = this.getElements("x" + infix + "_feeresellershare");
				if (elm && !ew.checkNumber(elm.value))
					return this.onError(elm, "<?php echo JsEncode($merchantsales_add->feeresellershare->errorMessage()) ?>");
			<?php if ($merchantsales_add->lastupdatetime->Required) { ?>
				elm = this.getElements("x" + infix + "_lastupdatetime");
				if (elm && !ew.isHidden(elm) && !ew.hasValue(elm))
					return this.onError(elm, "<?php echo JsEncode(str_replace("%s", $merchantsales_add->lastupdatetime->caption(), $merchantsales_add->lastupdatetime->RequiredErrorMessage)) ?>");
			<?php } ?>
				elm = this.getElements("x" + infix + "_lastupdatetime");
				if (elm && !ew.checkUSDate(elm.value))
					return this.onError(elm, "<?php echo JsEncode($merchantsales_add->lastupdatetime->errorMessage()) ?>");
			<?php if ($merchantsales_add->expirationTimeInMinutes->Required) { ?>
				elm = this.getElements("x" + infix + "_expirationTimeInMinutes");
				if (elm && !ew.isHidden(elm) && !ew.hasValue(elm))
					return this.onError(elm, "<?php echo JsEncode(str_replace("%s", $merchantsales_add->expirationTimeInMinutes->caption(), $merchantsales_add->expirationTimeInMinutes->RequiredErrorMessage)) ?>");
			<?php } ?>
				elm = this.getElements("x" + infix + "_expirationTimeInMinutes");
				if (elm && !ew.checkInteger(elm.value))
					return this.onError(elm, "<?php echo JsEncode($merchantsales_add->expirationTimeInMinutes->errorMessage()) ?>");
			<?php if ($merchantsales_add->expirationTime->Required) { ?>
				elm = this.getElements("x" + infix + "_expirationTime");
				if (elm && !ew.isHidden(elm) && !ew.hasValue(elm))
					return this.onError(elm, "<?php echo JsEncode(str_replace("%s", $merchantsales_add->expirationTime->caption(), $merchantsales_add->expirationTime->RequiredErrorMessage)) ?>");
			<?php } ?>
				elm = this.getElements("x" + infix + "_expirationTime");
				if (elm && !ew.checkDateDef(elm.value))
					return this.onError(elm, "<?php echo JsEncode($merchantsales_add->expirationTime->errorMessage()) ?>");
			<?php if ($merchantsales_add->customeruserid->Required) { ?>
				elm = this.getElements("x" + infix + "_customeruserid");
				if (elm && !ew.isHidden(elm) && !ew.hasValue(elm))
					return this.onError(elm, "<?php echo JsEncode(str_replace("%s", $merchantsales_add->customeruserid->caption(), $merchantsales_add->customeruserid->RequiredErrorMessage)) ?>");
			<?php } ?>
				elm = this.getElements("x" + infix + "_customeruserid");
				if (elm && !ew.checkInteger(elm.value))
					return this.onError(elm, "<?php echo JsEncode($merchantsales_add->customeruserid->errorMessage()) ?>");
			<?php if ($merchantsales_add->serviceFeeToCustomerbk1amt->Required) { ?>
				elm = this.getElements("x" + infix + "_serviceFeeToCustomerbk1amt");
				if (elm && !ew.isHidden(elm) && !ew.hasValue(elm))
					return this.onError(elm, "<?php echo JsEncode(str_replace("%s", $merchantsales_add->serviceFeeToCustomerbk1amt->caption(), $merchantsales_add->serviceFeeToCustomerbk1amt->RequiredErrorMessage)) ?>");
			<?php } ?>
				elm = this.getElements("x" + infix + "_serviceFeeToCustomerbk1amt");
				if (elm && !ew.checkNumber(elm.value))
					return this.onError(elm, "<?php echo JsEncode($merchantsales_add->serviceFeeToCustomerbk1amt->errorMessage()) ?>");
			<?php if ($merchantsales_add->serviceFeeToCustomerbk1type->Required) { ?>
				elm = this.getElements("x" + infix + "_serviceFeeToCustomerbk1type");
				if (elm && !ew.isHidden(elm) && !ew.hasValue(elm))
					return this.onError(elm, "<?php echo JsEncode(str_replace("%s", $merchantsales_add->serviceFeeToCustomerbk1type->caption(), $merchantsales_add->serviceFeeToCustomerbk1type->RequiredErrorMessage)) ?>");
			<?php } ?>
			<?php if ($merchantsales_add->serviceFeeToCustomerbk2amt->Required) { ?>
				elm = this.getElements("x" + infix + "_serviceFeeToCustomerbk2amt");
				if (elm && !ew.isHidden(elm) && !ew.hasValue(elm))
					return this.onError(elm, "<?php echo JsEncode(str_replace("%s", $merchantsales_add->serviceFeeToCustomerbk2amt->caption(), $merchantsales_add->serviceFeeToCustomerbk2amt->RequiredErrorMessage)) ?>");
			<?php } ?>
				elm = this.getElements("x" + infix + "_serviceFeeToCustomerbk2amt");
				if (elm && !ew.checkNumber(elm.value))
					return this.onError(elm, "<?php echo JsEncode($merchantsales_add->serviceFeeToCustomerbk2amt->errorMessage()) ?>");
			<?php if ($merchantsales_add->serviceFeeToCustomerbk2type->Required) { ?>
				elm = this.getElements("x" + infix + "_serviceFeeToCustomerbk2type");
				if (elm && !ew.isHidden(elm) && !ew.hasValue(elm))
					return this.onError(elm, "<?php echo JsEncode(str_replace("%s", $merchantsales_add->serviceFeeToCustomerbk2type->caption(), $merchantsales_add->serviceFeeToCustomerbk2type->RequiredErrorMessage)) ?>");
			<?php } ?>
			<?php if ($merchantsales_add->serviceFeeToCustomerbk3amt->Required) { ?>
				elm = this.getElements("x" + infix + "_serviceFeeToCustomerbk3amt");
				if (elm && !ew.isHidden(elm) && !ew.hasValue(elm))
					return this.onError(elm, "<?php echo JsEncode(str_replace("%s", $merchantsales_add->serviceFeeToCustomerbk3amt->caption(), $merchantsales_add->serviceFeeToCustomerbk3amt->RequiredErrorMessage)) ?>");
			<?php } ?>
				elm = this.getElements("x" + infix + "_serviceFeeToCustomerbk3amt");
				if (elm && !ew.checkNumber(elm.value))
					return this.onError(elm, "<?php echo JsEncode($merchantsales_add->serviceFeeToCustomerbk3amt->errorMessage()) ?>");
			<?php if ($merchantsales_add->serviceFeeToCustomerbk3type->Required) { ?>
				elm = this.getElements("x" + infix + "_serviceFeeToCustomerbk3type");
				if (elm && !ew.isHidden(elm) && !ew.hasValue(elm))
					return this.onError(elm, "<?php echo JsEncode(str_replace("%s", $merchantsales_add->serviceFeeToCustomerbk3type->caption(), $merchantsales_add->serviceFeeToCustomerbk3type->RequiredErrorMessage)) ?>");
			<?php } ?>
			<?php if ($merchantsales_add->taxAmountbk1amt->Required) { ?>
				elm = this.getElements("x" + infix + "_taxAmountbk1amt");
				if (elm && !ew.isHidden(elm) && !ew.hasValue(elm))
					return this.onError(elm, "<?php echo JsEncode(str_replace("%s", $merchantsales_add->taxAmountbk1amt->caption(), $merchantsales_add->taxAmountbk1amt->RequiredErrorMessage)) ?>");
			<?php } ?>
				elm = this.getElements("x" + infix + "_taxAmountbk1amt");
				if (elm && !ew.checkNumber(elm.value))
					return this.onError(elm, "<?php echo JsEncode($merchantsales_add->taxAmountbk1amt->errorMessage()) ?>");
			<?php if ($merchantsales_add->taxAmountbk1type->Required) { ?>
				elm = this.getElements("x" + infix + "_taxAmountbk1type");
				if (elm && !ew.isHidden(elm) && !ew.hasValue(elm))
					return this.onError(elm, "<?php echo JsEncode(str_replace("%s", $merchantsales_add->taxAmountbk1type->caption(), $merchantsales_add->taxAmountbk1type->RequiredErrorMessage)) ?>");
			<?php } ?>
			<?php if ($merchantsales_add->taxAmountbk2amt->Required) { ?>
				elm = this.getElements("x" + infix + "_taxAmountbk2amt");
				if (elm && !ew.isHidden(elm) && !ew.hasValue(elm))
					return this.onError(elm, "<?php echo JsEncode(str_replace("%s", $merchantsales_add->taxAmountbk2amt->caption(), $merchantsales_add->taxAmountbk2amt->RequiredErrorMessage)) ?>");
			<?php } ?>
				elm = this.getElements("x" + infix + "_taxAmountbk2amt");
				if (elm && !ew.checkNumber(elm.value))
					return this.onError(elm, "<?php echo JsEncode($merchantsales_add->taxAmountbk2amt->errorMessage()) ?>");
			<?php if ($merchantsales_add->taxAmountbk2type->Required) { ?>
				elm = this.getElements("x" + infix + "_taxAmountbk2type");
				if (elm && !ew.isHidden(elm) && !ew.hasValue(elm))
					return this.onError(elm, "<?php echo JsEncode(str_replace("%s", $merchantsales_add->taxAmountbk2type->caption(), $merchantsales_add->taxAmountbk2type->RequiredErrorMessage)) ?>");
			<?php } ?>
			<?php if ($merchantsales_add->taxAmountbk3amt->Required) { ?>
				elm = this.getElements("x" + infix + "_taxAmountbk3amt");
				if (elm && !ew.isHidden(elm) && !ew.hasValue(elm))
					return this.onError(elm, "<?php echo JsEncode(str_replace("%s", $merchantsales_add->taxAmountbk3amt->caption(), $merchantsales_add->taxAmountbk3amt->RequiredErrorMessage)) ?>");
			<?php } ?>
				elm = this.getElements("x" + infix + "_taxAmountbk3amt");
				if (elm && !ew.checkNumber(elm.value))
					return this.onError(elm, "<?php echo JsEncode($merchantsales_add->taxAmountbk3amt->errorMessage()) ?>");
			<?php if ($merchantsales_add->taxAmountbk3type->Required) { ?>
				elm = this.getElements("x" + infix + "_taxAmountbk3type");
				if (elm && !ew.isHidden(elm) && !ew.hasValue(elm))
					return this.onError(elm, "<?php echo JsEncode(str_replace("%s", $merchantsales_add->taxAmountbk3type->caption(), $merchantsales_add->taxAmountbk3type->RequiredErrorMessage)) ?>");
			<?php } ?>
			<?php if ($merchantsales_add->originalpurchaseamount->Required) { ?>
				elm = this.getElements("x" + infix + "_originalpurchaseamount");
				if (elm && !ew.isHidden(elm) && !ew.hasValue(elm))
					return this.onError(elm, "<?php echo JsEncode(str_replace("%s", $merchantsales_add->originalpurchaseamount->caption(), $merchantsales_add->originalpurchaseamount->RequiredErrorMessage)) ?>");
			<?php } ?>
				elm = this.getElements("x" + infix + "_originalpurchaseamount");
				if (elm && !ew.checkNumber(elm.value))
					return this.onError(elm, "<?php echo JsEncode($merchantsales_add->originalpurchaseamount->errorMessage()) ?>");
			<?php if ($merchantsales_add->discountamount->Required) { ?>
				elm = this.getElements("x" + infix + "_discountamount");
				if (elm && !ew.isHidden(elm) && !ew.hasValue(elm))
					return this.onError(elm, "<?php echo JsEncode(str_replace("%s", $merchantsales_add->discountamount->caption(), $merchantsales_add->discountamount->RequiredErrorMessage)) ?>");
			<?php } ?>
				elm = this.getElements("x" + infix + "_discountamount");
				if (elm && !ew.checkNumber(elm.value))
					return this.onError(elm, "<?php echo JsEncode($merchantsales_add->discountamount->errorMessage()) ?>");
			<?php if ($merchantsales_add->discountpercentage->Required) { ?>
				elm = this.getElements("x" + infix + "_discountpercentage");
				if (elm && !ew.isHidden(elm) && !ew.hasValue(elm))
					return this.onError(elm, "<?php echo JsEncode(str_replace("%s", $merchantsales_add->discountpercentage->caption(), $merchantsales_add->discountpercentage->RequiredErrorMessage)) ?>");
			<?php } ?>
				elm = this.getElements("x" + infix + "_discountpercentage");
				if (elm && !ew.checkInteger(elm.value))
					return this.onError(elm, "<?php echo JsEncode($merchantsales_add->discountpercentage->errorMessage()) ?>");
			<?php if ($merchantsales_add->customerpurchaseid->Required) { ?>
				elm = this.getElements("x" + infix + "_customerpurchaseid");
				if (elm && !ew.isHidden(elm) && !ew.hasValue(elm))
					return this.onError(elm, "<?php echo JsEncode(str_replace("%s", $merchantsales_add->customerpurchaseid->caption(), $merchantsales_add->customerpurchaseid->RequiredErrorMessage)) ?>");
			<?php } ?>
				elm = this.getElements("x" + infix + "_customerpurchaseid");
				if (elm && !ew.checkInteger(elm.value))
					return this.onError(elm, "<?php echo JsEncode($merchantsales_add->customerpurchaseid->errorMessage()) ?>");
			<?php if ($merchantsales_add->userpiid->Required) { ?>
				elm = this.getElements("x" + infix + "_userpiid");
				if (elm && !ew.isHidden(elm) && !ew.hasValue(elm))
					return this.onError(elm, "<?php echo JsEncode(str_replace("%s", $merchantsales_add->userpiid->caption(), $merchantsales_add->userpiid->RequiredErrorMessage)) ?>");
			<?php } ?>
				elm = this.getElements("x" + infix + "_userpiid");
				if (elm && !ew.checkInteger(elm.value))
					return this.onError(elm, "<?php echo JsEncode($merchantsales_add->userpiid->errorMessage()) ?>");
			<?php if ($merchantsales_add->originalMerchantSurcharge->Required) { ?>
				elm = this.getElements("x" + infix + "_originalMerchantSurcharge");
				if (elm && !ew.isHidden(elm) && !ew.hasValue(elm))
					return this.onError(elm, "<?php echo JsEncode(str_replace("%s", $merchantsales_add->originalMerchantSurcharge->caption(), $merchantsales_add->originalMerchantSurcharge->RequiredErrorMessage)) ?>");
			<?php } ?>
				elm = this.getElements("x" + infix + "_originalMerchantSurcharge");
				if (elm && !ew.checkNumber(elm.value))
					return this.onError(elm, "<?php echo JsEncode($merchantsales_add->originalMerchantSurcharge->errorMessage()) ?>");
			<?php if ($merchantsales_add->originalTaxAmount->Required) { ?>
				elm = this.getElements("x" + infix + "_originalTaxAmount");
				if (elm && !ew.isHidden(elm) && !ew.hasValue(elm))
					return this.onError(elm, "<?php echo JsEncode(str_replace("%s", $merchantsales_add->originalTaxAmount->caption(), $merchantsales_add->originalTaxAmount->RequiredErrorMessage)) ?>");
			<?php } ?>
				elm = this.getElements("x" + infix + "_originalTaxAmount");
				if (elm && !ew.checkNumber(elm.value))
					return this.onError(elm, "<?php echo JsEncode($merchantsales_add->originalTaxAmount->errorMessage()) ?>");
			<?php if ($merchantsales_add->originalServiceFeeToCustomer->Required) { ?>
				elm = this.getElements("x" + infix + "_originalServiceFeeToCustomer");
				if (elm && !ew.isHidden(elm) && !ew.hasValue(elm))
					return this.onError(elm, "<?php echo JsEncode(str_replace("%s", $merchantsales_add->originalServiceFeeToCustomer->caption(), $merchantsales_add->originalServiceFeeToCustomer->RequiredErrorMessage)) ?>");
			<?php } ?>
				elm = this.getElements("x" + infix + "_originalServiceFeeToCustomer");
				if (elm && !ew.checkNumber(elm.value))
					return this.onError(elm, "<?php echo JsEncode($merchantsales_add->originalServiceFeeToCustomer->errorMessage()) ?>");
			<?php if ($merchantsales_add->originalTotalAmountForCustomer->Required) { ?>
				elm = this.getElements("x" + infix + "_originalTotalAmountForCustomer");
				if (elm && !ew.isHidden(elm) && !ew.hasValue(elm))
					return this.onError(elm, "<?php echo JsEncode(str_replace("%s", $merchantsales_add->originalTotalAmountForCustomer->caption(), $merchantsales_add->originalTotalAmountForCustomer->RequiredErrorMessage)) ?>");
			<?php } ?>
				elm = this.getElements("x" + infix + "_originalTotalAmountForCustomer");
				if (elm && !ew.checkNumber(elm.value))
					return this.onError(elm, "<?php echo JsEncode($merchantsales_add->originalTotalAmountForCustomer->errorMessage()) ?>");
			<?php if ($merchantsales_add->originalServiceFeeToMerchant->Required) { ?>
				elm = this.getElements("x" + infix + "_originalServiceFeeToMerchant");
				if (elm && !ew.isHidden(elm) && !ew.hasValue(elm))
					return this.onError(elm, "<?php echo JsEncode(str_replace("%s", $merchantsales_add->originalServiceFeeToMerchant->caption(), $merchantsales_add->originalServiceFeeToMerchant->RequiredErrorMessage)) ?>");
			<?php } ?>
				elm = this.getElements("x" + infix + "_originalServiceFeeToMerchant");
				if (elm && !ew.checkNumber(elm.value))
					return this.onError(elm, "<?php echo JsEncode($merchantsales_add->originalServiceFeeToMerchant->errorMessage()) ?>");
			<?php if ($merchantsales_add->originalTipAmount->Required) { ?>
				elm = this.getElements("x" + infix + "_originalTipAmount");
				if (elm && !ew.isHidden(elm) && !ew.hasValue(elm))
					return this.onError(elm, "<?php echo JsEncode(str_replace("%s", $merchantsales_add->originalTipAmount->caption(), $merchantsales_add->originalTipAmount->RequiredErrorMessage)) ?>");
			<?php } ?>
				elm = this.getElements("x" + infix + "_originalTipAmount");
				if (elm && !ew.checkNumber(elm.value))
					return this.onError(elm, "<?php echo JsEncode($merchantsales_add->originalTipAmount->errorMessage()) ?>");

				// Call Form_CustomValidate event
				if (!this.Form_CustomValidate(fobj))
					return false;
		}

		// Process detail forms
		var dfs = $fobj.find("input[name='detailpage']").get();
		for (var i = 0; i < dfs.length; i++) {
			var df = dfs[i], val = df.value;
			if (val && ew.forms[val])
				if (!ew.forms[val].validate())
					return false;
		}
		return true;
	}

	// Form_CustomValidate
	fmerchantsalesadd.Form_CustomValidate = function(fobj) { // DO NOT CHANGE THIS LINE!

		// Your custom validation code here, return false if invalid.
		return true;
	}

	// Use JavaScript validation or not
	fmerchantsalesadd.validateRequired = <?php echo Config("CLIENT_VALIDATE") ? "true" : "false" ?>;

	// Dynamic selection lists
	fmerchantsalesadd.lists["x_merchantID"] = <?php echo $merchantsales_add->merchantID->Lookup->toClientList($merchantsales_add) ?>;
	fmerchantsalesadd.lists["x_merchantID"].options = <?php echo JsonEncode($merchantsales_add->merchantID->lookupOptions()) ?>;
	fmerchantsalesadd.lists["x_status"] = <?php echo $merchantsales_add->status->Lookup->toClientList($merchantsales_add) ?>;
	fmerchantsalesadd.lists["x_status"].options = <?php echo JsonEncode($merchantsales_add->status->options(FALSE, TRUE)) ?>;
	loadjs.done("fmerchantsalesadd");
});
</script>
<script>
loadjs.ready("head", function() {

	// Client script
	// Write your client script here, no need to add script tags.

});
</script>
<?php $merchantsales_add->showPageHeader(); ?>
<?php
$merchantsales_add->showMessage();
?>
<form name="fmerchantsalesadd" id="fmerchantsalesadd" class="<?php echo $merchantsales_add->FormClassName ?>" action="<?php echo CurrentPageName() ?>" method="post">
<?php if ($Page->CheckToken) { ?>
<input type="hidden" name="<?php echo Config("TOKEN_NAME") ?>" value="<?php echo $Page->Token ?>">
<?php } ?>
<input type="hidden" name="t" value="merchantsales">
<input type="hidden" name="action" id="action" value="insert">
<input type="hidden" name="modal" value="<?php echo (int)$merchantsales_add->IsModal ?>">
<?php if ($merchantsales->getCurrentMasterTable() == "merchant") { ?>
<input type="hidden" name="<?php echo Config("TABLE_SHOW_MASTER") ?>" value="merchant">
<input type="hidden" name="fk__userid" value="<?php echo HtmlEncode($merchantsales_add->merchantID->getSessionValue()) ?>">
<?php } ?>
<div class="ew-add-div"><!-- page* -->
<?php if ($merchantsales_add->txid->Visible) { // txid ?>
	<div id="r_txid" class="form-group row">
		<label id="elh_merchantsales_txid" for="x_txid" class="<?php echo $merchantsales_add->LeftColumnClass ?>"><?php echo $merchantsales_add->txid->caption() ?><?php echo $merchantsales_add->txid->Required ? $Language->phrase("FieldRequiredIndicator") : "" ?></label>
		<div class="<?php echo $merchantsales_add->RightColumnClass ?>"><div <?php echo $merchantsales_add->txid->cellAttributes() ?>>
<span id="el_merchantsales_txid">
<input type="text" data-table="merchantsales" data-field="x_txid" name="x_txid" id="x_txid" size="30" maxlength="10" placeholder="<?php echo HtmlEncode($merchantsales_add->txid->getPlaceHolder()) ?>" value="<?php echo $merchantsales_add->txid->EditValue ?>"<?php echo $merchantsales_add->txid->editAttributes() ?>>
</span>
<?php echo $merchantsales_add->txid->CustomMsg ?></div></div>
	</div>
<?php } ?>
<?php if ($merchantsales_add->merchantID->Visible) { // merchantID ?>
	<div id="r_merchantID" class="form-group row">
		<label id="elh_merchantsales_merchantID" for="x_merchantID" class="<?php echo $merchantsales_add->LeftColumnClass ?>"><?php echo $merchantsales_add->merchantID->caption() ?><?php echo $merchantsales_add->merchantID->Required ? $Language->phrase("FieldRequiredIndicator") : "" ?></label>
		<div class="<?php echo $merchantsales_add->RightColumnClass ?>"><div <?php echo $merchantsales_add->merchantID->cellAttributes() ?>>
<?php if ($merchantsales_add->merchantID->getSessionValue() != "") { ?>
<span id="el_merchantsales_merchantID">
<span<?php echo $merchantsales_add->merchantID->viewAttributes() ?>><input type="text" readonly class="form-control-plaintext" value="<?php echo HtmlEncode(RemoveHtml($merchantsales_add->merchantID->ViewValue)) ?>"></span>
</span>
<input type="hidden" id="x_merchantID" name="x_merchantID" value="<?php echo HtmlEncode($merchantsales_add->merchantID->CurrentValue) ?>">
<?php } else { ?>
<span id="el_merchantsales_merchantID">
<div class="input-group">
	<select class="custom-select ew-custom-select" data-table="merchantsales" data-field="x_merchantID" data-value-separator="<?php echo $merchantsales_add->merchantID->displayValueSeparatorAttribute() ?>" id="x_merchantID" name="x_merchantID"<?php echo $merchantsales_add->merchantID->editAttributes() ?>>
			<?php echo $merchantsales_add->merchantID->selectOptionListHtml("x_merchantID") ?>
		</select>
</div>
<?php echo $merchantsales_add->merchantID->Lookup->getParamTag($merchantsales_add, "p_x_merchantID") ?>
</span>
<?php } ?>
<?php echo $merchantsales_add->merchantID->CustomMsg ?></div></div>
	</div>
<?php } ?>
<?php if ($merchantsales_add->_userID->Visible) { // userID ?>
	<div id="r__userID" class="form-group row">
		<label id="elh_merchantsales__userID" for="x__userID" class="<?php echo $merchantsales_add->LeftColumnClass ?>"><?php echo $merchantsales_add->_userID->caption() ?><?php echo $merchantsales_add->_userID->Required ? $Language->phrase("FieldRequiredIndicator") : "" ?></label>
		<div class="<?php echo $merchantsales_add->RightColumnClass ?>"><div <?php echo $merchantsales_add->_userID->cellAttributes() ?>>
<span id="el_merchantsales__userID">
<input type="text" data-table="merchantsales" data-field="x__userID" name="x__userID" id="x__userID" size="30" placeholder="<?php echo HtmlEncode($merchantsales_add->_userID->getPlaceHolder()) ?>" value="<?php echo $merchantsales_add->_userID->EditValue ?>"<?php echo $merchantsales_add->_userID->editAttributes() ?>>
</span>
<?php echo $merchantsales_add->_userID->CustomMsg ?></div></div>
	</div>
<?php } ?>
<?php if ($merchantsales_add->transferTime->Visible) { // transferTime ?>
	<div id="r_transferTime" class="form-group row">
		<label id="elh_merchantsales_transferTime" for="x_transferTime" class="<?php echo $merchantsales_add->LeftColumnClass ?>"><?php echo $merchantsales_add->transferTime->caption() ?><?php echo $merchantsales_add->transferTime->Required ? $Language->phrase("FieldRequiredIndicator") : "" ?></label>
		<div class="<?php echo $merchantsales_add->RightColumnClass ?>"><div <?php echo $merchantsales_add->transferTime->cellAttributes() ?>>
<span id="el_merchantsales_transferTime">
<input type="text" data-table="merchantsales" data-field="x_transferTime" data-format="10" name="x_transferTime" id="x_transferTime" placeholder="<?php echo HtmlEncode($merchantsales_add->transferTime->getPlaceHolder()) ?>" value="<?php echo $merchantsales_add->transferTime->EditValue ?>"<?php echo $merchantsales_add->transferTime->editAttributes() ?>>
<?php if (!$merchantsales_add->transferTime->ReadOnly && !$merchantsales_add->transferTime->Disabled && !isset($merchantsales_add->transferTime->EditAttrs["readonly"]) && !isset($merchantsales_add->transferTime->EditAttrs["disabled"])) { ?>
<script>
loadjs.ready(["fmerchantsalesadd", "datetimepicker"], function() {
	ew.createDateTimePicker("fmerchantsalesadd", "x_transferTime", {"ignoreReadonly":true,"useCurrent":false,"format":10});
});
</script>
<?php } ?>
</span>
<?php echo $merchantsales_add->transferTime->CustomMsg ?></div></div>
	</div>
<?php } ?>
<?php if ($merchantsales_add->currID->Visible) { // currID ?>
	<div id="r_currID" class="form-group row">
		<label id="elh_merchantsales_currID" for="x_currID" class="<?php echo $merchantsales_add->LeftColumnClass ?>"><?php echo $merchantsales_add->currID->caption() ?><?php echo $merchantsales_add->currID->Required ? $Language->phrase("FieldRequiredIndicator") : "" ?></label>
		<div class="<?php echo $merchantsales_add->RightColumnClass ?>"><div <?php echo $merchantsales_add->currID->cellAttributes() ?>>
<span id="el_merchantsales_currID">
<input type="text" data-table="merchantsales" data-field="x_currID" name="x_currID" id="x_currID" size="30" maxlength="3" placeholder="<?php echo HtmlEncode($merchantsales_add->currID->getPlaceHolder()) ?>" value="<?php echo $merchantsales_add->currID->EditValue ?>"<?php echo $merchantsales_add->currID->editAttributes() ?>>
</span>
<?php echo $merchantsales_add->currID->CustomMsg ?></div></div>
	</div>
<?php } ?>
<?php if ($merchantsales_add->purchaseAmount->Visible) { // purchaseAmount ?>
	<div id="r_purchaseAmount" class="form-group row">
		<label id="elh_merchantsales_purchaseAmount" for="x_purchaseAmount" class="<?php echo $merchantsales_add->LeftColumnClass ?>"><?php echo $merchantsales_add->purchaseAmount->caption() ?><?php echo $merchantsales_add->purchaseAmount->Required ? $Language->phrase("FieldRequiredIndicator") : "" ?></label>
		<div class="<?php echo $merchantsales_add->RightColumnClass ?>"><div <?php echo $merchantsales_add->purchaseAmount->cellAttributes() ?>>
<span id="el_merchantsales_purchaseAmount">
<input type="text" data-table="merchantsales" data-field="x_purchaseAmount" name="x_purchaseAmount" id="x_purchaseAmount" size="30" placeholder="<?php echo HtmlEncode($merchantsales_add->purchaseAmount->getPlaceHolder()) ?>" value="<?php echo $merchantsales_add->purchaseAmount->EditValue ?>"<?php echo $merchantsales_add->purchaseAmount->editAttributes() ?>>
</span>
<?php echo $merchantsales_add->purchaseAmount->CustomMsg ?></div></div>
	</div>
<?php } ?>
<?php if ($merchantsales_add->merchantSurcharge->Visible) { // merchantSurcharge ?>
	<div id="r_merchantSurcharge" class="form-group row">
		<label id="elh_merchantsales_merchantSurcharge" for="x_merchantSurcharge" class="<?php echo $merchantsales_add->LeftColumnClass ?>"><?php echo $merchantsales_add->merchantSurcharge->caption() ?><?php echo $merchantsales_add->merchantSurcharge->Required ? $Language->phrase("FieldRequiredIndicator") : "" ?></label>
		<div class="<?php echo $merchantsales_add->RightColumnClass ?>"><div <?php echo $merchantsales_add->merchantSurcharge->cellAttributes() ?>>
<span id="el_merchantsales_merchantSurcharge">
<input type="text" data-table="merchantsales" data-field="x_merchantSurcharge" name="x_merchantSurcharge" id="x_merchantSurcharge" size="30" placeholder="<?php echo HtmlEncode($merchantsales_add->merchantSurcharge->getPlaceHolder()) ?>" value="<?php echo $merchantsales_add->merchantSurcharge->EditValue ?>"<?php echo $merchantsales_add->merchantSurcharge->editAttributes() ?>>
</span>
<?php echo $merchantsales_add->merchantSurcharge->CustomMsg ?></div></div>
	</div>
<?php } ?>
<?php if ($merchantsales_add->taxAmount->Visible) { // taxAmount ?>
	<div id="r_taxAmount" class="form-group row">
		<label id="elh_merchantsales_taxAmount" for="x_taxAmount" class="<?php echo $merchantsales_add->LeftColumnClass ?>"><?php echo $merchantsales_add->taxAmount->caption() ?><?php echo $merchantsales_add->taxAmount->Required ? $Language->phrase("FieldRequiredIndicator") : "" ?></label>
		<div class="<?php echo $merchantsales_add->RightColumnClass ?>"><div <?php echo $merchantsales_add->taxAmount->cellAttributes() ?>>
<span id="el_merchantsales_taxAmount">
<input type="text" data-table="merchantsales" data-field="x_taxAmount" name="x_taxAmount" id="x_taxAmount" size="30" placeholder="<?php echo HtmlEncode($merchantsales_add->taxAmount->getPlaceHolder()) ?>" value="<?php echo $merchantsales_add->taxAmount->EditValue ?>"<?php echo $merchantsales_add->taxAmount->editAttributes() ?>>
</span>
<?php echo $merchantsales_add->taxAmount->CustomMsg ?></div></div>
	</div>
<?php } ?>
<?php if ($merchantsales_add->tipAmount->Visible) { // tipAmount ?>
	<div id="r_tipAmount" class="form-group row">
		<label id="elh_merchantsales_tipAmount" for="x_tipAmount" class="<?php echo $merchantsales_add->LeftColumnClass ?>"><?php echo $merchantsales_add->tipAmount->caption() ?><?php echo $merchantsales_add->tipAmount->Required ? $Language->phrase("FieldRequiredIndicator") : "" ?></label>
		<div class="<?php echo $merchantsales_add->RightColumnClass ?>"><div <?php echo $merchantsales_add->tipAmount->cellAttributes() ?>>
<span id="el_merchantsales_tipAmount">
<input type="text" data-table="merchantsales" data-field="x_tipAmount" name="x_tipAmount" id="x_tipAmount" size="30" placeholder="<?php echo HtmlEncode($merchantsales_add->tipAmount->getPlaceHolder()) ?>" value="<?php echo $merchantsales_add->tipAmount->EditValue ?>"<?php echo $merchantsales_add->tipAmount->editAttributes() ?>>
</span>
<?php echo $merchantsales_add->tipAmount->CustomMsg ?></div></div>
	</div>
<?php } ?>
<?php if ($merchantsales_add->serviceFeeToCustomer->Visible) { // serviceFeeToCustomer ?>
	<div id="r_serviceFeeToCustomer" class="form-group row">
		<label id="elh_merchantsales_serviceFeeToCustomer" for="x_serviceFeeToCustomer" class="<?php echo $merchantsales_add->LeftColumnClass ?>"><?php echo $merchantsales_add->serviceFeeToCustomer->caption() ?><?php echo $merchantsales_add->serviceFeeToCustomer->Required ? $Language->phrase("FieldRequiredIndicator") : "" ?></label>
		<div class="<?php echo $merchantsales_add->RightColumnClass ?>"><div <?php echo $merchantsales_add->serviceFeeToCustomer->cellAttributes() ?>>
<span id="el_merchantsales_serviceFeeToCustomer">
<input type="text" data-table="merchantsales" data-field="x_serviceFeeToCustomer" name="x_serviceFeeToCustomer" id="x_serviceFeeToCustomer" size="30" placeholder="<?php echo HtmlEncode($merchantsales_add->serviceFeeToCustomer->getPlaceHolder()) ?>" value="<?php echo $merchantsales_add->serviceFeeToCustomer->EditValue ?>"<?php echo $merchantsales_add->serviceFeeToCustomer->editAttributes() ?>>
</span>
<?php echo $merchantsales_add->serviceFeeToCustomer->CustomMsg ?></div></div>
	</div>
<?php } ?>
<?php if ($merchantsales_add->TotalAmountForCustomer->Visible) { // TotalAmountForCustomer ?>
	<div id="r_TotalAmountForCustomer" class="form-group row">
		<label id="elh_merchantsales_TotalAmountForCustomer" for="x_TotalAmountForCustomer" class="<?php echo $merchantsales_add->LeftColumnClass ?>"><?php echo $merchantsales_add->TotalAmountForCustomer->caption() ?><?php echo $merchantsales_add->TotalAmountForCustomer->Required ? $Language->phrase("FieldRequiredIndicator") : "" ?></label>
		<div class="<?php echo $merchantsales_add->RightColumnClass ?>"><div <?php echo $merchantsales_add->TotalAmountForCustomer->cellAttributes() ?>>
<span id="el_merchantsales_TotalAmountForCustomer">
<input type="text" data-table="merchantsales" data-field="x_TotalAmountForCustomer" name="x_TotalAmountForCustomer" id="x_TotalAmountForCustomer" size="30" placeholder="<?php echo HtmlEncode($merchantsales_add->TotalAmountForCustomer->getPlaceHolder()) ?>" value="<?php echo $merchantsales_add->TotalAmountForCustomer->EditValue ?>"<?php echo $merchantsales_add->TotalAmountForCustomer->editAttributes() ?>>
</span>
<?php echo $merchantsales_add->TotalAmountForCustomer->CustomMsg ?></div></div>
	</div>
<?php } ?>
<?php if ($merchantsales_add->serviceFeeToMerchant->Visible) { // serviceFeeToMerchant ?>
	<div id="r_serviceFeeToMerchant" class="form-group row">
		<label id="elh_merchantsales_serviceFeeToMerchant" for="x_serviceFeeToMerchant" class="<?php echo $merchantsales_add->LeftColumnClass ?>"><?php echo $merchantsales_add->serviceFeeToMerchant->caption() ?><?php echo $merchantsales_add->serviceFeeToMerchant->Required ? $Language->phrase("FieldRequiredIndicator") : "" ?></label>
		<div class="<?php echo $merchantsales_add->RightColumnClass ?>"><div <?php echo $merchantsales_add->serviceFeeToMerchant->cellAttributes() ?>>
<span id="el_merchantsales_serviceFeeToMerchant">
<input type="text" data-table="merchantsales" data-field="x_serviceFeeToMerchant" name="x_serviceFeeToMerchant" id="x_serviceFeeToMerchant" size="30" placeholder="<?php echo HtmlEncode($merchantsales_add->serviceFeeToMerchant->getPlaceHolder()) ?>" value="<?php echo $merchantsales_add->serviceFeeToMerchant->EditValue ?>"<?php echo $merchantsales_add->serviceFeeToMerchant->editAttributes() ?>>
</span>
<?php echo $merchantsales_add->serviceFeeToMerchant->CustomMsg ?></div></div>
	</div>
<?php } ?>
<?php if ($merchantsales_add->status->Visible) { // status ?>
	<div id="r_status" class="form-group row">
		<label id="elh_merchantsales_status" for="x_status" class="<?php echo $merchantsales_add->LeftColumnClass ?>"><?php echo $merchantsales_add->status->caption() ?><?php echo $merchantsales_add->status->Required ? $Language->phrase("FieldRequiredIndicator") : "" ?></label>
		<div class="<?php echo $merchantsales_add->RightColumnClass ?>"><div <?php echo $merchantsales_add->status->cellAttributes() ?>>
<span id="el_merchantsales_status">
<div class="input-group">
	<select class="custom-select ew-custom-select" data-table="merchantsales" data-field="x_status" data-value-separator="<?php echo $merchantsales_add->status->displayValueSeparatorAttribute() ?>" id="x_status" name="x_status"<?php echo $merchantsales_add->status->editAttributes() ?>>
			<?php echo $merchantsales_add->status->selectOptionListHtml("x_status") ?>
		</select>
</div>
</span>
<?php echo $merchantsales_add->status->CustomMsg ?></div></div>
	</div>
<?php } ?>
<?php if ($merchantsales_add->shoppingCartID->Visible) { // shoppingCartID ?>
	<div id="r_shoppingCartID" class="form-group row">
		<label id="elh_merchantsales_shoppingCartID" for="x_shoppingCartID" class="<?php echo $merchantsales_add->LeftColumnClass ?>"><?php echo $merchantsales_add->shoppingCartID->caption() ?><?php echo $merchantsales_add->shoppingCartID->Required ? $Language->phrase("FieldRequiredIndicator") : "" ?></label>
		<div class="<?php echo $merchantsales_add->RightColumnClass ?>"><div <?php echo $merchantsales_add->shoppingCartID->cellAttributes() ?>>
<span id="el_merchantsales_shoppingCartID">
<input type="text" data-table="merchantsales" data-field="x_shoppingCartID" name="x_shoppingCartID" id="x_shoppingCartID" size="30" maxlength="20" placeholder="<?php echo HtmlEncode($merchantsales_add->shoppingCartID->getPlaceHolder()) ?>" value="<?php echo $merchantsales_add->shoppingCartID->EditValue ?>"<?php echo $merchantsales_add->shoppingCartID->editAttributes() ?>>
</span>
<?php echo $merchantsales_add->shoppingCartID->CustomMsg ?></div></div>
	</div>
<?php } ?>
<?php if ($merchantsales_add->merchantRefID->Visible) { // merchantRefID ?>
	<div id="r_merchantRefID" class="form-group row">
		<label id="elh_merchantsales_merchantRefID" for="x_merchantRefID" class="<?php echo $merchantsales_add->LeftColumnClass ?>"><?php echo $merchantsales_add->merchantRefID->caption() ?><?php echo $merchantsales_add->merchantRefID->Required ? $Language->phrase("FieldRequiredIndicator") : "" ?></label>
		<div class="<?php echo $merchantsales_add->RightColumnClass ?>"><div <?php echo $merchantsales_add->merchantRefID->cellAttributes() ?>>
<span id="el_merchantsales_merchantRefID">
<input type="text" data-table="merchantsales" data-field="x_merchantRefID" name="x_merchantRefID" id="x_merchantRefID" size="30" maxlength="20" placeholder="<?php echo HtmlEncode($merchantsales_add->merchantRefID->getPlaceHolder()) ?>" value="<?php echo $merchantsales_add->merchantRefID->EditValue ?>"<?php echo $merchantsales_add->merchantRefID->editAttributes() ?>>
</span>
<?php echo $merchantsales_add->merchantRefID->CustomMsg ?></div></div>
	</div>
<?php } ?>
<?php if ($merchantsales_add->feeid->Visible) { // feeid ?>
	<div id="r_feeid" class="form-group row">
		<label id="elh_merchantsales_feeid" for="x_feeid" class="<?php echo $merchantsales_add->LeftColumnClass ?>"><?php echo $merchantsales_add->feeid->caption() ?><?php echo $merchantsales_add->feeid->Required ? $Language->phrase("FieldRequiredIndicator") : "" ?></label>
		<div class="<?php echo $merchantsales_add->RightColumnClass ?>"><div <?php echo $merchantsales_add->feeid->cellAttributes() ?>>
<span id="el_merchantsales_feeid">
<input type="text" data-table="merchantsales" data-field="x_feeid" name="x_feeid" id="x_feeid" size="30" placeholder="<?php echo HtmlEncode($merchantsales_add->feeid->getPlaceHolder()) ?>" value="<?php echo $merchantsales_add->feeid->EditValue ?>"<?php echo $merchantsales_add->feeid->editAttributes() ?>>
</span>
<?php echo $merchantsales_add->feeid->CustomMsg ?></div></div>
	</div>
<?php } ?>
<?php if ($merchantsales_add->ratetabletype->Visible) { // ratetabletype ?>
	<div id="r_ratetabletype" class="form-group row">
		<label id="elh_merchantsales_ratetabletype" for="x_ratetabletype" class="<?php echo $merchantsales_add->LeftColumnClass ?>"><?php echo $merchantsales_add->ratetabletype->caption() ?><?php echo $merchantsales_add->ratetabletype->Required ? $Language->phrase("FieldRequiredIndicator") : "" ?></label>
		<div class="<?php echo $merchantsales_add->RightColumnClass ?>"><div <?php echo $merchantsales_add->ratetabletype->cellAttributes() ?>>
<span id="el_merchantsales_ratetabletype">
<input type="text" data-table="merchantsales" data-field="x_ratetabletype" name="x_ratetabletype" id="x_ratetabletype" size="30" placeholder="<?php echo HtmlEncode($merchantsales_add->ratetabletype->getPlaceHolder()) ?>" value="<?php echo $merchantsales_add->ratetabletype->EditValue ?>"<?php echo $merchantsales_add->ratetabletype->editAttributes() ?>>
</span>
<?php echo $merchantsales_add->ratetabletype->CustomMsg ?></div></div>
	</div>
<?php } ?>
<?php if ($merchantsales_add->pis->Visible) { // pis ?>
	<div id="r_pis" class="form-group row">
		<label id="elh_merchantsales_pis" for="x_pis" class="<?php echo $merchantsales_add->LeftColumnClass ?>"><?php echo $merchantsales_add->pis->caption() ?><?php echo $merchantsales_add->pis->Required ? $Language->phrase("FieldRequiredIndicator") : "" ?></label>
		<div class="<?php echo $merchantsales_add->RightColumnClass ?>"><div <?php echo $merchantsales_add->pis->cellAttributes() ?>>
<span id="el_merchantsales_pis">
<textarea data-table="merchantsales" data-field="x_pis" name="x_pis" id="x_pis" cols="35" rows="4" placeholder="<?php echo HtmlEncode($merchantsales_add->pis->getPlaceHolder()) ?>"<?php echo $merchantsales_add->pis->editAttributes() ?>><?php echo $merchantsales_add->pis->EditValue ?></textarea>
</span>
<?php echo $merchantsales_add->pis->CustomMsg ?></div></div>
	</div>
<?php } ?>
<?php if ($merchantsales_add->feesystemshare->Visible) { // feesystemshare ?>
	<div id="r_feesystemshare" class="form-group row">
		<label id="elh_merchantsales_feesystemshare" for="x_feesystemshare" class="<?php echo $merchantsales_add->LeftColumnClass ?>"><?php echo $merchantsales_add->feesystemshare->caption() ?><?php echo $merchantsales_add->feesystemshare->Required ? $Language->phrase("FieldRequiredIndicator") : "" ?></label>
		<div class="<?php echo $merchantsales_add->RightColumnClass ?>"><div <?php echo $merchantsales_add->feesystemshare->cellAttributes() ?>>
<span id="el_merchantsales_feesystemshare">
<input type="text" data-table="merchantsales" data-field="x_feesystemshare" name="x_feesystemshare" id="x_feesystemshare" size="30" placeholder="<?php echo HtmlEncode($merchantsales_add->feesystemshare->getPlaceHolder()) ?>" value="<?php echo $merchantsales_add->feesystemshare->EditValue ?>"<?php echo $merchantsales_add->feesystemshare->editAttributes() ?>>
</span>
<?php echo $merchantsales_add->feesystemshare->CustomMsg ?></div></div>
	</div>
<?php } ?>
<?php if ($merchantsales_add->feeexternalshare->Visible) { // feeexternalshare ?>
	<div id="r_feeexternalshare" class="form-group row">
		<label id="elh_merchantsales_feeexternalshare" for="x_feeexternalshare" class="<?php echo $merchantsales_add->LeftColumnClass ?>"><?php echo $merchantsales_add->feeexternalshare->caption() ?><?php echo $merchantsales_add->feeexternalshare->Required ? $Language->phrase("FieldRequiredIndicator") : "" ?></label>
		<div class="<?php echo $merchantsales_add->RightColumnClass ?>"><div <?php echo $merchantsales_add->feeexternalshare->cellAttributes() ?>>
<span id="el_merchantsales_feeexternalshare">
<input type="text" data-table="merchantsales" data-field="x_feeexternalshare" name="x_feeexternalshare" id="x_feeexternalshare" size="30" placeholder="<?php echo HtmlEncode($merchantsales_add->feeexternalshare->getPlaceHolder()) ?>" value="<?php echo $merchantsales_add->feeexternalshare->EditValue ?>"<?php echo $merchantsales_add->feeexternalshare->editAttributes() ?>>
</span>
<?php echo $merchantsales_add->feeexternalshare->CustomMsg ?></div></div>
	</div>
<?php } ?>
<?php if ($merchantsales_add->feefranchiseeshare->Visible) { // feefranchiseeshare ?>
	<div id="r_feefranchiseeshare" class="form-group row">
		<label id="elh_merchantsales_feefranchiseeshare" for="x_feefranchiseeshare" class="<?php echo $merchantsales_add->LeftColumnClass ?>"><?php echo $merchantsales_add->feefranchiseeshare->caption() ?><?php echo $merchantsales_add->feefranchiseeshare->Required ? $Language->phrase("FieldRequiredIndicator") : "" ?></label>
		<div class="<?php echo $merchantsales_add->RightColumnClass ?>"><div <?php echo $merchantsales_add->feefranchiseeshare->cellAttributes() ?>>
<span id="el_merchantsales_feefranchiseeshare">
<input type="text" data-table="merchantsales" data-field="x_feefranchiseeshare" name="x_feefranchiseeshare" id="x_feefranchiseeshare" size="30" placeholder="<?php echo HtmlEncode($merchantsales_add->feefranchiseeshare->getPlaceHolder()) ?>" value="<?php echo $merchantsales_add->feefranchiseeshare->EditValue ?>"<?php echo $merchantsales_add->feefranchiseeshare->editAttributes() ?>>
</span>
<?php echo $merchantsales_add->feefranchiseeshare->CustomMsg ?></div></div>
	</div>
<?php } ?>
<?php if ($merchantsales_add->feeresellershare->Visible) { // feeresellershare ?>
	<div id="r_feeresellershare" class="form-group row">
		<label id="elh_merchantsales_feeresellershare" for="x_feeresellershare" class="<?php echo $merchantsales_add->LeftColumnClass ?>"><?php echo $merchantsales_add->feeresellershare->caption() ?><?php echo $merchantsales_add->feeresellershare->Required ? $Language->phrase("FieldRequiredIndicator") : "" ?></label>
		<div class="<?php echo $merchantsales_add->RightColumnClass ?>"><div <?php echo $merchantsales_add->feeresellershare->cellAttributes() ?>>
<span id="el_merchantsales_feeresellershare">
<input type="text" data-table="merchantsales" data-field="x_feeresellershare" name="x_feeresellershare" id="x_feeresellershare" size="30" placeholder="<?php echo HtmlEncode($merchantsales_add->feeresellershare->getPlaceHolder()) ?>" value="<?php echo $merchantsales_add->feeresellershare->EditValue ?>"<?php echo $merchantsales_add->feeresellershare->editAttributes() ?>>
</span>
<?php echo $merchantsales_add->feeresellershare->CustomMsg ?></div></div>
	</div>
<?php } ?>
<?php if ($merchantsales_add->lastupdatetime->Visible) { // lastupdatetime ?>
	<div id="r_lastupdatetime" class="form-group row">
		<label id="elh_merchantsales_lastupdatetime" for="x_lastupdatetime" class="<?php echo $merchantsales_add->LeftColumnClass ?>"><?php echo $merchantsales_add->lastupdatetime->caption() ?><?php echo $merchantsales_add->lastupdatetime->Required ? $Language->phrase("FieldRequiredIndicator") : "" ?></label>
		<div class="<?php echo $merchantsales_add->RightColumnClass ?>"><div <?php echo $merchantsales_add->lastupdatetime->cellAttributes() ?>>
<span id="el_merchantsales_lastupdatetime">
<input type="text" data-table="merchantsales" data-field="x_lastupdatetime" data-format="10" name="x_lastupdatetime" id="x_lastupdatetime" placeholder="<?php echo HtmlEncode($merchantsales_add->lastupdatetime->getPlaceHolder()) ?>" value="<?php echo $merchantsales_add->lastupdatetime->EditValue ?>"<?php echo $merchantsales_add->lastupdatetime->editAttributes() ?>>
</span>
<?php echo $merchantsales_add->lastupdatetime->CustomMsg ?></div></div>
	</div>
<?php } ?>
<?php if ($merchantsales_add->expirationTimeInMinutes->Visible) { // expirationTimeInMinutes ?>
	<div id="r_expirationTimeInMinutes" class="form-group row">
		<label id="elh_merchantsales_expirationTimeInMinutes" for="x_expirationTimeInMinutes" class="<?php echo $merchantsales_add->LeftColumnClass ?>"><?php echo $merchantsales_add->expirationTimeInMinutes->caption() ?><?php echo $merchantsales_add->expirationTimeInMinutes->Required ? $Language->phrase("FieldRequiredIndicator") : "" ?></label>
		<div class="<?php echo $merchantsales_add->RightColumnClass ?>"><div <?php echo $merchantsales_add->expirationTimeInMinutes->cellAttributes() ?>>
<span id="el_merchantsales_expirationTimeInMinutes">
<input type="text" data-table="merchantsales" data-field="x_expirationTimeInMinutes" name="x_expirationTimeInMinutes" id="x_expirationTimeInMinutes" size="30" placeholder="<?php echo HtmlEncode($merchantsales_add->expirationTimeInMinutes->getPlaceHolder()) ?>" value="<?php echo $merchantsales_add->expirationTimeInMinutes->EditValue ?>"<?php echo $merchantsales_add->expirationTimeInMinutes->editAttributes() ?>>
</span>
<?php echo $merchantsales_add->expirationTimeInMinutes->CustomMsg ?></div></div>
	</div>
<?php } ?>
<?php if ($merchantsales_add->expirationTime->Visible) { // expirationTime ?>
	<div id="r_expirationTime" class="form-group row">
		<label id="elh_merchantsales_expirationTime" for="x_expirationTime" class="<?php echo $merchantsales_add->LeftColumnClass ?>"><?php echo $merchantsales_add->expirationTime->caption() ?><?php echo $merchantsales_add->expirationTime->Required ? $Language->phrase("FieldRequiredIndicator") : "" ?></label>
		<div class="<?php echo $merchantsales_add->RightColumnClass ?>"><div <?php echo $merchantsales_add->expirationTime->cellAttributes() ?>>
<span id="el_merchantsales_expirationTime">
<input type="text" data-table="merchantsales" data-field="x_expirationTime" name="x_expirationTime" id="x_expirationTime" placeholder="<?php echo HtmlEncode($merchantsales_add->expirationTime->getPlaceHolder()) ?>" value="<?php echo $merchantsales_add->expirationTime->EditValue ?>"<?php echo $merchantsales_add->expirationTime->editAttributes() ?>>
</span>
<?php echo $merchantsales_add->expirationTime->CustomMsg ?></div></div>
	</div>
<?php } ?>
<?php if ($merchantsales_add->customeruserid->Visible) { // customeruserid ?>
	<div id="r_customeruserid" class="form-group row">
		<label id="elh_merchantsales_customeruserid" for="x_customeruserid" class="<?php echo $merchantsales_add->LeftColumnClass ?>"><?php echo $merchantsales_add->customeruserid->caption() ?><?php echo $merchantsales_add->customeruserid->Required ? $Language->phrase("FieldRequiredIndicator") : "" ?></label>
		<div class="<?php echo $merchantsales_add->RightColumnClass ?>"><div <?php echo $merchantsales_add->customeruserid->cellAttributes() ?>>
<span id="el_merchantsales_customeruserid">
<input type="text" data-table="merchantsales" data-field="x_customeruserid" name="x_customeruserid" id="x_customeruserid" size="30" placeholder="<?php echo HtmlEncode($merchantsales_add->customeruserid->getPlaceHolder()) ?>" value="<?php echo $merchantsales_add->customeruserid->EditValue ?>"<?php echo $merchantsales_add->customeruserid->editAttributes() ?>>
</span>
<?php echo $merchantsales_add->customeruserid->CustomMsg ?></div></div>
	</div>
<?php } ?>
<?php if ($merchantsales_add->serviceFeeToCustomerbk1amt->Visible) { // serviceFeeToCustomerbk1amt ?>
	<div id="r_serviceFeeToCustomerbk1amt" class="form-group row">
		<label id="elh_merchantsales_serviceFeeToCustomerbk1amt" for="x_serviceFeeToCustomerbk1amt" class="<?php echo $merchantsales_add->LeftColumnClass ?>"><?php echo $merchantsales_add->serviceFeeToCustomerbk1amt->caption() ?><?php echo $merchantsales_add->serviceFeeToCustomerbk1amt->Required ? $Language->phrase("FieldRequiredIndicator") : "" ?></label>
		<div class="<?php echo $merchantsales_add->RightColumnClass ?>"><div <?php echo $merchantsales_add->serviceFeeToCustomerbk1amt->cellAttributes() ?>>
<span id="el_merchantsales_serviceFeeToCustomerbk1amt">
<input type="text" data-table="merchantsales" data-field="x_serviceFeeToCustomerbk1amt" name="x_serviceFeeToCustomerbk1amt" id="x_serviceFeeToCustomerbk1amt" size="30" maxlength="22" placeholder="<?php echo HtmlEncode($merchantsales_add->serviceFeeToCustomerbk1amt->getPlaceHolder()) ?>" value="<?php echo $merchantsales_add->serviceFeeToCustomerbk1amt->EditValue ?>"<?php echo $merchantsales_add->serviceFeeToCustomerbk1amt->editAttributes() ?>>
</span>
<?php echo $merchantsales_add->serviceFeeToCustomerbk1amt->CustomMsg ?></div></div>
	</div>
<?php } ?>
<?php if ($merchantsales_add->serviceFeeToCustomerbk1type->Visible) { // serviceFeeToCustomerbk1type ?>
	<div id="r_serviceFeeToCustomerbk1type" class="form-group row">
		<label id="elh_merchantsales_serviceFeeToCustomerbk1type" for="x_serviceFeeToCustomerbk1type" class="<?php echo $merchantsales_add->LeftColumnClass ?>"><?php echo $merchantsales_add->serviceFeeToCustomerbk1type->caption() ?><?php echo $merchantsales_add->serviceFeeToCustomerbk1type->Required ? $Language->phrase("FieldRequiredIndicator") : "" ?></label>
		<div class="<?php echo $merchantsales_add->RightColumnClass ?>"><div <?php echo $merchantsales_add->serviceFeeToCustomerbk1type->cellAttributes() ?>>
<span id="el_merchantsales_serviceFeeToCustomerbk1type">
<input type="text" data-table="merchantsales" data-field="x_serviceFeeToCustomerbk1type" name="x_serviceFeeToCustomerbk1type" id="x_serviceFeeToCustomerbk1type" size="30" maxlength="15" placeholder="<?php echo HtmlEncode($merchantsales_add->serviceFeeToCustomerbk1type->getPlaceHolder()) ?>" value="<?php echo $merchantsales_add->serviceFeeToCustomerbk1type->EditValue ?>"<?php echo $merchantsales_add->serviceFeeToCustomerbk1type->editAttributes() ?>>
</span>
<?php echo $merchantsales_add->serviceFeeToCustomerbk1type->CustomMsg ?></div></div>
	</div>
<?php } ?>
<?php if ($merchantsales_add->serviceFeeToCustomerbk2amt->Visible) { // serviceFeeToCustomerbk2amt ?>
	<div id="r_serviceFeeToCustomerbk2amt" class="form-group row">
		<label id="elh_merchantsales_serviceFeeToCustomerbk2amt" for="x_serviceFeeToCustomerbk2amt" class="<?php echo $merchantsales_add->LeftColumnClass ?>"><?php echo $merchantsales_add->serviceFeeToCustomerbk2amt->caption() ?><?php echo $merchantsales_add->serviceFeeToCustomerbk2amt->Required ? $Language->phrase("FieldRequiredIndicator") : "" ?></label>
		<div class="<?php echo $merchantsales_add->RightColumnClass ?>"><div <?php echo $merchantsales_add->serviceFeeToCustomerbk2amt->cellAttributes() ?>>
<span id="el_merchantsales_serviceFeeToCustomerbk2amt">
<input type="text" data-table="merchantsales" data-field="x_serviceFeeToCustomerbk2amt" name="x_serviceFeeToCustomerbk2amt" id="x_serviceFeeToCustomerbk2amt" size="30" maxlength="22" placeholder="<?php echo HtmlEncode($merchantsales_add->serviceFeeToCustomerbk2amt->getPlaceHolder()) ?>" value="<?php echo $merchantsales_add->serviceFeeToCustomerbk2amt->EditValue ?>"<?php echo $merchantsales_add->serviceFeeToCustomerbk2amt->editAttributes() ?>>
</span>
<?php echo $merchantsales_add->serviceFeeToCustomerbk2amt->CustomMsg ?></div></div>
	</div>
<?php } ?>
<?php if ($merchantsales_add->serviceFeeToCustomerbk2type->Visible) { // serviceFeeToCustomerbk2type ?>
	<div id="r_serviceFeeToCustomerbk2type" class="form-group row">
		<label id="elh_merchantsales_serviceFeeToCustomerbk2type" for="x_serviceFeeToCustomerbk2type" class="<?php echo $merchantsales_add->LeftColumnClass ?>"><?php echo $merchantsales_add->serviceFeeToCustomerbk2type->caption() ?><?php echo $merchantsales_add->serviceFeeToCustomerbk2type->Required ? $Language->phrase("FieldRequiredIndicator") : "" ?></label>
		<div class="<?php echo $merchantsales_add->RightColumnClass ?>"><div <?php echo $merchantsales_add->serviceFeeToCustomerbk2type->cellAttributes() ?>>
<span id="el_merchantsales_serviceFeeToCustomerbk2type">
<input type="text" data-table="merchantsales" data-field="x_serviceFeeToCustomerbk2type" name="x_serviceFeeToCustomerbk2type" id="x_serviceFeeToCustomerbk2type" size="30" maxlength="15" placeholder="<?php echo HtmlEncode($merchantsales_add->serviceFeeToCustomerbk2type->getPlaceHolder()) ?>" value="<?php echo $merchantsales_add->serviceFeeToCustomerbk2type->EditValue ?>"<?php echo $merchantsales_add->serviceFeeToCustomerbk2type->editAttributes() ?>>
</span>
<?php echo $merchantsales_add->serviceFeeToCustomerbk2type->CustomMsg ?></div></div>
	</div>
<?php } ?>
<?php if ($merchantsales_add->serviceFeeToCustomerbk3amt->Visible) { // serviceFeeToCustomerbk3amt ?>
	<div id="r_serviceFeeToCustomerbk3amt" class="form-group row">
		<label id="elh_merchantsales_serviceFeeToCustomerbk3amt" for="x_serviceFeeToCustomerbk3amt" class="<?php echo $merchantsales_add->LeftColumnClass ?>"><?php echo $merchantsales_add->serviceFeeToCustomerbk3amt->caption() ?><?php echo $merchantsales_add->serviceFeeToCustomerbk3amt->Required ? $Language->phrase("FieldRequiredIndicator") : "" ?></label>
		<div class="<?php echo $merchantsales_add->RightColumnClass ?>"><div <?php echo $merchantsales_add->serviceFeeToCustomerbk3amt->cellAttributes() ?>>
<span id="el_merchantsales_serviceFeeToCustomerbk3amt">
<input type="text" data-table="merchantsales" data-field="x_serviceFeeToCustomerbk3amt" name="x_serviceFeeToCustomerbk3amt" id="x_serviceFeeToCustomerbk3amt" size="30" maxlength="22" placeholder="<?php echo HtmlEncode($merchantsales_add->serviceFeeToCustomerbk3amt->getPlaceHolder()) ?>" value="<?php echo $merchantsales_add->serviceFeeToCustomerbk3amt->EditValue ?>"<?php echo $merchantsales_add->serviceFeeToCustomerbk3amt->editAttributes() ?>>
</span>
<?php echo $merchantsales_add->serviceFeeToCustomerbk3amt->CustomMsg ?></div></div>
	</div>
<?php } ?>
<?php if ($merchantsales_add->serviceFeeToCustomerbk3type->Visible) { // serviceFeeToCustomerbk3type ?>
	<div id="r_serviceFeeToCustomerbk3type" class="form-group row">
		<label id="elh_merchantsales_serviceFeeToCustomerbk3type" for="x_serviceFeeToCustomerbk3type" class="<?php echo $merchantsales_add->LeftColumnClass ?>"><?php echo $merchantsales_add->serviceFeeToCustomerbk3type->caption() ?><?php echo $merchantsales_add->serviceFeeToCustomerbk3type->Required ? $Language->phrase("FieldRequiredIndicator") : "" ?></label>
		<div class="<?php echo $merchantsales_add->RightColumnClass ?>"><div <?php echo $merchantsales_add->serviceFeeToCustomerbk3type->cellAttributes() ?>>
<span id="el_merchantsales_serviceFeeToCustomerbk3type">
<input type="text" data-table="merchantsales" data-field="x_serviceFeeToCustomerbk3type" name="x_serviceFeeToCustomerbk3type" id="x_serviceFeeToCustomerbk3type" size="30" maxlength="15" placeholder="<?php echo HtmlEncode($merchantsales_add->serviceFeeToCustomerbk3type->getPlaceHolder()) ?>" value="<?php echo $merchantsales_add->serviceFeeToCustomerbk3type->EditValue ?>"<?php echo $merchantsales_add->serviceFeeToCustomerbk3type->editAttributes() ?>>
</span>
<?php echo $merchantsales_add->serviceFeeToCustomerbk3type->CustomMsg ?></div></div>
	</div>
<?php } ?>
<?php if ($merchantsales_add->taxAmountbk1amt->Visible) { // taxAmountbk1amt ?>
	<div id="r_taxAmountbk1amt" class="form-group row">
		<label id="elh_merchantsales_taxAmountbk1amt" for="x_taxAmountbk1amt" class="<?php echo $merchantsales_add->LeftColumnClass ?>"><?php echo $merchantsales_add->taxAmountbk1amt->caption() ?><?php echo $merchantsales_add->taxAmountbk1amt->Required ? $Language->phrase("FieldRequiredIndicator") : "" ?></label>
		<div class="<?php echo $merchantsales_add->RightColumnClass ?>"><div <?php echo $merchantsales_add->taxAmountbk1amt->cellAttributes() ?>>
<span id="el_merchantsales_taxAmountbk1amt">
<input type="text" data-table="merchantsales" data-field="x_taxAmountbk1amt" name="x_taxAmountbk1amt" id="x_taxAmountbk1amt" size="30" maxlength="22" placeholder="<?php echo HtmlEncode($merchantsales_add->taxAmountbk1amt->getPlaceHolder()) ?>" value="<?php echo $merchantsales_add->taxAmountbk1amt->EditValue ?>"<?php echo $merchantsales_add->taxAmountbk1amt->editAttributes() ?>>
</span>
<?php echo $merchantsales_add->taxAmountbk1amt->CustomMsg ?></div></div>
	</div>
<?php } ?>
<?php if ($merchantsales_add->taxAmountbk1type->Visible) { // taxAmountbk1type ?>
	<div id="r_taxAmountbk1type" class="form-group row">
		<label id="elh_merchantsales_taxAmountbk1type" for="x_taxAmountbk1type" class="<?php echo $merchantsales_add->LeftColumnClass ?>"><?php echo $merchantsales_add->taxAmountbk1type->caption() ?><?php echo $merchantsales_add->taxAmountbk1type->Required ? $Language->phrase("FieldRequiredIndicator") : "" ?></label>
		<div class="<?php echo $merchantsales_add->RightColumnClass ?>"><div <?php echo $merchantsales_add->taxAmountbk1type->cellAttributes() ?>>
<span id="el_merchantsales_taxAmountbk1type">
<input type="text" data-table="merchantsales" data-field="x_taxAmountbk1type" name="x_taxAmountbk1type" id="x_taxAmountbk1type" size="30" maxlength="15" placeholder="<?php echo HtmlEncode($merchantsales_add->taxAmountbk1type->getPlaceHolder()) ?>" value="<?php echo $merchantsales_add->taxAmountbk1type->EditValue ?>"<?php echo $merchantsales_add->taxAmountbk1type->editAttributes() ?>>
</span>
<?php echo $merchantsales_add->taxAmountbk1type->CustomMsg ?></div></div>
	</div>
<?php } ?>
<?php if ($merchantsales_add->taxAmountbk2amt->Visible) { // taxAmountbk2amt ?>
	<div id="r_taxAmountbk2amt" class="form-group row">
		<label id="elh_merchantsales_taxAmountbk2amt" for="x_taxAmountbk2amt" class="<?php echo $merchantsales_add->LeftColumnClass ?>"><?php echo $merchantsales_add->taxAmountbk2amt->caption() ?><?php echo $merchantsales_add->taxAmountbk2amt->Required ? $Language->phrase("FieldRequiredIndicator") : "" ?></label>
		<div class="<?php echo $merchantsales_add->RightColumnClass ?>"><div <?php echo $merchantsales_add->taxAmountbk2amt->cellAttributes() ?>>
<span id="el_merchantsales_taxAmountbk2amt">
<input type="text" data-table="merchantsales" data-field="x_taxAmountbk2amt" name="x_taxAmountbk2amt" id="x_taxAmountbk2amt" size="30" maxlength="22" placeholder="<?php echo HtmlEncode($merchantsales_add->taxAmountbk2amt->getPlaceHolder()) ?>" value="<?php echo $merchantsales_add->taxAmountbk2amt->EditValue ?>"<?php echo $merchantsales_add->taxAmountbk2amt->editAttributes() ?>>
</span>
<?php echo $merchantsales_add->taxAmountbk2amt->CustomMsg ?></div></div>
	</div>
<?php } ?>
<?php if ($merchantsales_add->taxAmountbk2type->Visible) { // taxAmountbk2type ?>
	<div id="r_taxAmountbk2type" class="form-group row">
		<label id="elh_merchantsales_taxAmountbk2type" for="x_taxAmountbk2type" class="<?php echo $merchantsales_add->LeftColumnClass ?>"><?php echo $merchantsales_add->taxAmountbk2type->caption() ?><?php echo $merchantsales_add->taxAmountbk2type->Required ? $Language->phrase("FieldRequiredIndicator") : "" ?></label>
		<div class="<?php echo $merchantsales_add->RightColumnClass ?>"><div <?php echo $merchantsales_add->taxAmountbk2type->cellAttributes() ?>>
<span id="el_merchantsales_taxAmountbk2type">
<input type="text" data-table="merchantsales" data-field="x_taxAmountbk2type" name="x_taxAmountbk2type" id="x_taxAmountbk2type" size="30" maxlength="15" placeholder="<?php echo HtmlEncode($merchantsales_add->taxAmountbk2type->getPlaceHolder()) ?>" value="<?php echo $merchantsales_add->taxAmountbk2type->EditValue ?>"<?php echo $merchantsales_add->taxAmountbk2type->editAttributes() ?>>
</span>
<?php echo $merchantsales_add->taxAmountbk2type->CustomMsg ?></div></div>
	</div>
<?php } ?>
<?php if ($merchantsales_add->taxAmountbk3amt->Visible) { // taxAmountbk3amt ?>
	<div id="r_taxAmountbk3amt" class="form-group row">
		<label id="elh_merchantsales_taxAmountbk3amt" for="x_taxAmountbk3amt" class="<?php echo $merchantsales_add->LeftColumnClass ?>"><?php echo $merchantsales_add->taxAmountbk3amt->caption() ?><?php echo $merchantsales_add->taxAmountbk3amt->Required ? $Language->phrase("FieldRequiredIndicator") : "" ?></label>
		<div class="<?php echo $merchantsales_add->RightColumnClass ?>"><div <?php echo $merchantsales_add->taxAmountbk3amt->cellAttributes() ?>>
<span id="el_merchantsales_taxAmountbk3amt">
<input type="text" data-table="merchantsales" data-field="x_taxAmountbk3amt" name="x_taxAmountbk3amt" id="x_taxAmountbk3amt" size="30" maxlength="22" placeholder="<?php echo HtmlEncode($merchantsales_add->taxAmountbk3amt->getPlaceHolder()) ?>" value="<?php echo $merchantsales_add->taxAmountbk3amt->EditValue ?>"<?php echo $merchantsales_add->taxAmountbk3amt->editAttributes() ?>>
</span>
<?php echo $merchantsales_add->taxAmountbk3amt->CustomMsg ?></div></div>
	</div>
<?php } ?>
<?php if ($merchantsales_add->taxAmountbk3type->Visible) { // taxAmountbk3type ?>
	<div id="r_taxAmountbk3type" class="form-group row">
		<label id="elh_merchantsales_taxAmountbk3type" for="x_taxAmountbk3type" class="<?php echo $merchantsales_add->LeftColumnClass ?>"><?php echo $merchantsales_add->taxAmountbk3type->caption() ?><?php echo $merchantsales_add->taxAmountbk3type->Required ? $Language->phrase("FieldRequiredIndicator") : "" ?></label>
		<div class="<?php echo $merchantsales_add->RightColumnClass ?>"><div <?php echo $merchantsales_add->taxAmountbk3type->cellAttributes() ?>>
<span id="el_merchantsales_taxAmountbk3type">
<input type="text" data-table="merchantsales" data-field="x_taxAmountbk3type" name="x_taxAmountbk3type" id="x_taxAmountbk3type" size="30" maxlength="15" placeholder="<?php echo HtmlEncode($merchantsales_add->taxAmountbk3type->getPlaceHolder()) ?>" value="<?php echo $merchantsales_add->taxAmountbk3type->EditValue ?>"<?php echo $merchantsales_add->taxAmountbk3type->editAttributes() ?>>
</span>
<?php echo $merchantsales_add->taxAmountbk3type->CustomMsg ?></div></div>
	</div>
<?php } ?>
<?php if ($merchantsales_add->originalpurchaseamount->Visible) { // originalpurchaseamount ?>
	<div id="r_originalpurchaseamount" class="form-group row">
		<label id="elh_merchantsales_originalpurchaseamount" for="x_originalpurchaseamount" class="<?php echo $merchantsales_add->LeftColumnClass ?>"><?php echo $merchantsales_add->originalpurchaseamount->caption() ?><?php echo $merchantsales_add->originalpurchaseamount->Required ? $Language->phrase("FieldRequiredIndicator") : "" ?></label>
		<div class="<?php echo $merchantsales_add->RightColumnClass ?>"><div <?php echo $merchantsales_add->originalpurchaseamount->cellAttributes() ?>>
<span id="el_merchantsales_originalpurchaseamount">
<input type="text" data-table="merchantsales" data-field="x_originalpurchaseamount" name="x_originalpurchaseamount" id="x_originalpurchaseamount" size="30" maxlength="22" placeholder="<?php echo HtmlEncode($merchantsales_add->originalpurchaseamount->getPlaceHolder()) ?>" value="<?php echo $merchantsales_add->originalpurchaseamount->EditValue ?>"<?php echo $merchantsales_add->originalpurchaseamount->editAttributes() ?>>
</span>
<?php echo $merchantsales_add->originalpurchaseamount->CustomMsg ?></div></div>
	</div>
<?php } ?>
<?php if ($merchantsales_add->discountamount->Visible) { // discountamount ?>
	<div id="r_discountamount" class="form-group row">
		<label id="elh_merchantsales_discountamount" for="x_discountamount" class="<?php echo $merchantsales_add->LeftColumnClass ?>"><?php echo $merchantsales_add->discountamount->caption() ?><?php echo $merchantsales_add->discountamount->Required ? $Language->phrase("FieldRequiredIndicator") : "" ?></label>
		<div class="<?php echo $merchantsales_add->RightColumnClass ?>"><div <?php echo $merchantsales_add->discountamount->cellAttributes() ?>>
<span id="el_merchantsales_discountamount">
<input type="text" data-table="merchantsales" data-field="x_discountamount" name="x_discountamount" id="x_discountamount" size="30" maxlength="22" placeholder="<?php echo HtmlEncode($merchantsales_add->discountamount->getPlaceHolder()) ?>" value="<?php echo $merchantsales_add->discountamount->EditValue ?>"<?php echo $merchantsales_add->discountamount->editAttributes() ?>>
</span>
<?php echo $merchantsales_add->discountamount->CustomMsg ?></div></div>
	</div>
<?php } ?>
<?php if ($merchantsales_add->discountpercentage->Visible) { // discountpercentage ?>
	<div id="r_discountpercentage" class="form-group row">
		<label id="elh_merchantsales_discountpercentage" for="x_discountpercentage" class="<?php echo $merchantsales_add->LeftColumnClass ?>"><?php echo $merchantsales_add->discountpercentage->caption() ?><?php echo $merchantsales_add->discountpercentage->Required ? $Language->phrase("FieldRequiredIndicator") : "" ?></label>
		<div class="<?php echo $merchantsales_add->RightColumnClass ?>"><div <?php echo $merchantsales_add->discountpercentage->cellAttributes() ?>>
<span id="el_merchantsales_discountpercentage">
<input type="text" data-table="merchantsales" data-field="x_discountpercentage" name="x_discountpercentage" id="x_discountpercentage" size="30" maxlength="1" placeholder="<?php echo HtmlEncode($merchantsales_add->discountpercentage->getPlaceHolder()) ?>" value="<?php echo $merchantsales_add->discountpercentage->EditValue ?>"<?php echo $merchantsales_add->discountpercentage->editAttributes() ?>>
</span>
<?php echo $merchantsales_add->discountpercentage->CustomMsg ?></div></div>
	</div>
<?php } ?>
<?php if ($merchantsales_add->customerpurchaseid->Visible) { // customerpurchaseid ?>
	<div id="r_customerpurchaseid" class="form-group row">
		<label id="elh_merchantsales_customerpurchaseid" for="x_customerpurchaseid" class="<?php echo $merchantsales_add->LeftColumnClass ?>"><?php echo $merchantsales_add->customerpurchaseid->caption() ?><?php echo $merchantsales_add->customerpurchaseid->Required ? $Language->phrase("FieldRequiredIndicator") : "" ?></label>
		<div class="<?php echo $merchantsales_add->RightColumnClass ?>"><div <?php echo $merchantsales_add->customerpurchaseid->cellAttributes() ?>>
<span id="el_merchantsales_customerpurchaseid">
<input type="text" data-table="merchantsales" data-field="x_customerpurchaseid" name="x_customerpurchaseid" id="x_customerpurchaseid" size="30" maxlength="15" placeholder="<?php echo HtmlEncode($merchantsales_add->customerpurchaseid->getPlaceHolder()) ?>" value="<?php echo $merchantsales_add->customerpurchaseid->EditValue ?>"<?php echo $merchantsales_add->customerpurchaseid->editAttributes() ?>>
</span>
<?php echo $merchantsales_add->customerpurchaseid->CustomMsg ?></div></div>
	</div>
<?php } ?>
<?php if ($merchantsales_add->userpiid->Visible) { // userpiid ?>
	<div id="r_userpiid" class="form-group row">
		<label id="elh_merchantsales_userpiid" for="x_userpiid" class="<?php echo $merchantsales_add->LeftColumnClass ?>"><?php echo $merchantsales_add->userpiid->caption() ?><?php echo $merchantsales_add->userpiid->Required ? $Language->phrase("FieldRequiredIndicator") : "" ?></label>
		<div class="<?php echo $merchantsales_add->RightColumnClass ?>"><div <?php echo $merchantsales_add->userpiid->cellAttributes() ?>>
<span id="el_merchantsales_userpiid">
<input type="text" data-table="merchantsales" data-field="x_userpiid" name="x_userpiid" id="x_userpiid" size="30" maxlength="5" placeholder="<?php echo HtmlEncode($merchantsales_add->userpiid->getPlaceHolder()) ?>" value="<?php echo $merchantsales_add->userpiid->EditValue ?>"<?php echo $merchantsales_add->userpiid->editAttributes() ?>>
</span>
<?php echo $merchantsales_add->userpiid->CustomMsg ?></div></div>
	</div>
<?php } ?>
<?php if ($merchantsales_add->originalMerchantSurcharge->Visible) { // originalMerchantSurcharge ?>
	<div id="r_originalMerchantSurcharge" class="form-group row">
		<label id="elh_merchantsales_originalMerchantSurcharge" for="x_originalMerchantSurcharge" class="<?php echo $merchantsales_add->LeftColumnClass ?>"><?php echo $merchantsales_add->originalMerchantSurcharge->caption() ?><?php echo $merchantsales_add->originalMerchantSurcharge->Required ? $Language->phrase("FieldRequiredIndicator") : "" ?></label>
		<div class="<?php echo $merchantsales_add->RightColumnClass ?>"><div <?php echo $merchantsales_add->originalMerchantSurcharge->cellAttributes() ?>>
<span id="el_merchantsales_originalMerchantSurcharge">
<input type="text" data-table="merchantsales" data-field="x_originalMerchantSurcharge" name="x_originalMerchantSurcharge" id="x_originalMerchantSurcharge" size="30" maxlength="20" placeholder="<?php echo HtmlEncode($merchantsales_add->originalMerchantSurcharge->getPlaceHolder()) ?>" value="<?php echo $merchantsales_add->originalMerchantSurcharge->EditValue ?>"<?php echo $merchantsales_add->originalMerchantSurcharge->editAttributes() ?>>
</span>
<?php echo $merchantsales_add->originalMerchantSurcharge->CustomMsg ?></div></div>
	</div>
<?php } ?>
<?php if ($merchantsales_add->originalTaxAmount->Visible) { // originalTaxAmount ?>
	<div id="r_originalTaxAmount" class="form-group row">
		<label id="elh_merchantsales_originalTaxAmount" for="x_originalTaxAmount" class="<?php echo $merchantsales_add->LeftColumnClass ?>"><?php echo $merchantsales_add->originalTaxAmount->caption() ?><?php echo $merchantsales_add->originalTaxAmount->Required ? $Language->phrase("FieldRequiredIndicator") : "" ?></label>
		<div class="<?php echo $merchantsales_add->RightColumnClass ?>"><div <?php echo $merchantsales_add->originalTaxAmount->cellAttributes() ?>>
<span id="el_merchantsales_originalTaxAmount">
<input type="text" data-table="merchantsales" data-field="x_originalTaxAmount" name="x_originalTaxAmount" id="x_originalTaxAmount" size="30" maxlength="20" placeholder="<?php echo HtmlEncode($merchantsales_add->originalTaxAmount->getPlaceHolder()) ?>" value="<?php echo $merchantsales_add->originalTaxAmount->EditValue ?>"<?php echo $merchantsales_add->originalTaxAmount->editAttributes() ?>>
</span>
<?php echo $merchantsales_add->originalTaxAmount->CustomMsg ?></div></div>
	</div>
<?php } ?>
<?php if ($merchantsales_add->originalServiceFeeToCustomer->Visible) { // originalServiceFeeToCustomer ?>
	<div id="r_originalServiceFeeToCustomer" class="form-group row">
		<label id="elh_merchantsales_originalServiceFeeToCustomer" for="x_originalServiceFeeToCustomer" class="<?php echo $merchantsales_add->LeftColumnClass ?>"><?php echo $merchantsales_add->originalServiceFeeToCustomer->caption() ?><?php echo $merchantsales_add->originalServiceFeeToCustomer->Required ? $Language->phrase("FieldRequiredIndicator") : "" ?></label>
		<div class="<?php echo $merchantsales_add->RightColumnClass ?>"><div <?php echo $merchantsales_add->originalServiceFeeToCustomer->cellAttributes() ?>>
<span id="el_merchantsales_originalServiceFeeToCustomer">
<input type="text" data-table="merchantsales" data-field="x_originalServiceFeeToCustomer" name="x_originalServiceFeeToCustomer" id="x_originalServiceFeeToCustomer" size="30" maxlength="20" placeholder="<?php echo HtmlEncode($merchantsales_add->originalServiceFeeToCustomer->getPlaceHolder()) ?>" value="<?php echo $merchantsales_add->originalServiceFeeToCustomer->EditValue ?>"<?php echo $merchantsales_add->originalServiceFeeToCustomer->editAttributes() ?>>
</span>
<?php echo $merchantsales_add->originalServiceFeeToCustomer->CustomMsg ?></div></div>
	</div>
<?php } ?>
<?php if ($merchantsales_add->originalTotalAmountForCustomer->Visible) { // originalTotalAmountForCustomer ?>
	<div id="r_originalTotalAmountForCustomer" class="form-group row">
		<label id="elh_merchantsales_originalTotalAmountForCustomer" for="x_originalTotalAmountForCustomer" class="<?php echo $merchantsales_add->LeftColumnClass ?>"><?php echo $merchantsales_add->originalTotalAmountForCustomer->caption() ?><?php echo $merchantsales_add->originalTotalAmountForCustomer->Required ? $Language->phrase("FieldRequiredIndicator") : "" ?></label>
		<div class="<?php echo $merchantsales_add->RightColumnClass ?>"><div <?php echo $merchantsales_add->originalTotalAmountForCustomer->cellAttributes() ?>>
<span id="el_merchantsales_originalTotalAmountForCustomer">
<input type="text" data-table="merchantsales" data-field="x_originalTotalAmountForCustomer" name="x_originalTotalAmountForCustomer" id="x_originalTotalAmountForCustomer" size="30" maxlength="20" placeholder="<?php echo HtmlEncode($merchantsales_add->originalTotalAmountForCustomer->getPlaceHolder()) ?>" value="<?php echo $merchantsales_add->originalTotalAmountForCustomer->EditValue ?>"<?php echo $merchantsales_add->originalTotalAmountForCustomer->editAttributes() ?>>
</span>
<?php echo $merchantsales_add->originalTotalAmountForCustomer->CustomMsg ?></div></div>
	</div>
<?php } ?>
<?php if ($merchantsales_add->originalServiceFeeToMerchant->Visible) { // originalServiceFeeToMerchant ?>
	<div id="r_originalServiceFeeToMerchant" class="form-group row">
		<label id="elh_merchantsales_originalServiceFeeToMerchant" for="x_originalServiceFeeToMerchant" class="<?php echo $merchantsales_add->LeftColumnClass ?>"><?php echo $merchantsales_add->originalServiceFeeToMerchant->caption() ?><?php echo $merchantsales_add->originalServiceFeeToMerchant->Required ? $Language->phrase("FieldRequiredIndicator") : "" ?></label>
		<div class="<?php echo $merchantsales_add->RightColumnClass ?>"><div <?php echo $merchantsales_add->originalServiceFeeToMerchant->cellAttributes() ?>>
<span id="el_merchantsales_originalServiceFeeToMerchant">
<input type="text" data-table="merchantsales" data-field="x_originalServiceFeeToMerchant" name="x_originalServiceFeeToMerchant" id="x_originalServiceFeeToMerchant" size="30" maxlength="20" placeholder="<?php echo HtmlEncode($merchantsales_add->originalServiceFeeToMerchant->getPlaceHolder()) ?>" value="<?php echo $merchantsales_add->originalServiceFeeToMerchant->EditValue ?>"<?php echo $merchantsales_add->originalServiceFeeToMerchant->editAttributes() ?>>
</span>
<?php echo $merchantsales_add->originalServiceFeeToMerchant->CustomMsg ?></div></div>
	</div>
<?php } ?>
<?php if ($merchantsales_add->originalTipAmount->Visible) { // originalTipAmount ?>
	<div id="r_originalTipAmount" class="form-group row">
		<label id="elh_merchantsales_originalTipAmount" for="x_originalTipAmount" class="<?php echo $merchantsales_add->LeftColumnClass ?>"><?php echo $merchantsales_add->originalTipAmount->caption() ?><?php echo $merchantsales_add->originalTipAmount->Required ? $Language->phrase("FieldRequiredIndicator") : "" ?></label>
		<div class="<?php echo $merchantsales_add->RightColumnClass ?>"><div <?php echo $merchantsales_add->originalTipAmount->cellAttributes() ?>>
<span id="el_merchantsales_originalTipAmount">
<input type="text" data-table="merchantsales" data-field="x_originalTipAmount" name="x_originalTipAmount" id="x_originalTipAmount" size="30" maxlength="20" placeholder="<?php echo HtmlEncode($merchantsales_add->originalTipAmount->getPlaceHolder()) ?>" value="<?php echo $merchantsales_add->originalTipAmount->EditValue ?>"<?php echo $merchantsales_add->originalTipAmount->editAttributes() ?>>
</span>
<?php echo $merchantsales_add->originalTipAmount->CustomMsg ?></div></div>
	</div>
<?php } ?>
</div><!-- /page* -->
<?php if (!$merchantsales_add->IsModal) { ?>
<div class="form-group row"><!-- buttons .form-group -->
	<div class="<?php echo $merchantsales_add->OffsetColumnClass ?>"><!-- buttons offset -->
<button class="btn btn-primary ew-btn" name="btn-action" id="btn-action" type="submit"><?php echo $Language->phrase("AddBtn") ?></button>
<button class="btn btn-default ew-btn" name="btn-cancel" id="btn-cancel" type="button" data-href="<?php echo $merchantsales_add->getReturnUrl() ?>"><?php echo $Language->phrase("CancelBtn") ?></button>
	</div><!-- /buttons offset -->
</div><!-- /buttons .form-group -->
<?php } ?>
</form>
<?php
$merchantsales_add->showPageFooter();
if (Config("DEBUG"))
	echo GetDebugMessage();
?>
<script>
loadjs.ready("load", function() {

	// Startup script
	// Write your table-specific startup script here
	// console.log("page loaded");

});
</script>
<?php include_once "footer.php"; ?>
<?php
$merchantsales_add->terminate();
?>