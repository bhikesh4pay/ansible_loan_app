<?php
namespace PHPMaker2020\_4payadmin;

// Autoload
include_once "autoload.php";

// Session
if (session_status() !== PHP_SESSION_ACTIVE)
	\Delight\Cookie\Session::start(Config("COOKIE_SAMESITE")); // Init session data

// Output buffering
ob_start();
?>
<?php

// Write header
WriteHeader(FALSE);

// Create page object
$loanunconfirmed_add = new loanunconfirmed_add();

// Run the page
$loanunconfirmed_add->run();

// Setup login status
SetupLoginStatus();
SetClientVar("login", LoginStatus());

// Global Page Rendering event (in userfn*.php)
Page_Rendering();

// Page Rendering event
$loanunconfirmed_add->Page_Render();
?>
<?php include_once "header.php"; ?>
<script>
var floanunconfirmedadd, currentPageID;
loadjs.ready("head", function() {

	// Form object
	currentPageID = ew.PAGE_ID = "add";
	floanunconfirmedadd = currentForm = new ew.Form("floanunconfirmedadd", "add");

	// Validate form
	floanunconfirmedadd.validate = function() {
		if (!this.validateRequired)
			return true; // Ignore validation
		var $ = jQuery, fobj = this.getForm(), $fobj = $(fobj);
		if ($fobj.find("#confirm").val() == "confirm")
			return true;
		var elm, felm, uelm, addcnt = 0;
		var $k = $fobj.find("#" + this.formKeyCountName); // Get key_count
		var rowcnt = ($k[0]) ? parseInt($k.val(), 10) : 1;
		var startcnt = (rowcnt == 0) ? 0 : 1; // Check rowcnt == 0 => Inline-Add
		var gridinsert = ["insert", "gridinsert"].includes($fobj.find("#action").val()) && $k[0];
		for (var i = startcnt; i <= rowcnt; i++) {
			var infix = ($k[0]) ? String(i) : "";
			$fobj.data("rowindex", infix);
			<?php if ($loanunconfirmed_add->loanid->Required) { ?>
				elm = this.getElements("x" + infix + "_loanid");
				if (elm && !ew.isHidden(elm) && !ew.hasValue(elm))
					return this.onError(elm, "<?php echo JsEncode(str_replace("%s", $loanunconfirmed_add->loanid->caption(), $loanunconfirmed_add->loanid->RequiredErrorMessage)) ?>");
			<?php } ?>
				elm = this.getElements("x" + infix + "_loanid");
				if (elm && !ew.checkInteger(elm.value))
					return this.onError(elm, "<?php echo JsEncode($loanunconfirmed_add->loanid->errorMessage()) ?>");
			<?php if ($loanunconfirmed_add->loggedtime->Required) { ?>
				elm = this.getElements("x" + infix + "_loggedtime");
				if (elm && !ew.isHidden(elm) && !ew.hasValue(elm))
					return this.onError(elm, "<?php echo JsEncode(str_replace("%s", $loanunconfirmed_add->loggedtime->caption(), $loanunconfirmed_add->loggedtime->RequiredErrorMessage)) ?>");
			<?php } ?>
				elm = this.getElements("x" + infix + "_loggedtime");
				if (elm && !ew.checkDateDef(elm.value))
					return this.onError(elm, "<?php echo JsEncode($loanunconfirmed_add->loggedtime->errorMessage()) ?>");
			<?php if ($loanunconfirmed_add->trycount->Required) { ?>
				elm = this.getElements("x" + infix + "_trycount");
				if (elm && !ew.isHidden(elm) && !ew.hasValue(elm))
					return this.onError(elm, "<?php echo JsEncode(str_replace("%s", $loanunconfirmed_add->trycount->caption(), $loanunconfirmed_add->trycount->RequiredErrorMessage)) ?>");
			<?php } ?>
				elm = this.getElements("x" + infix + "_trycount");
				if (elm && !ew.checkInteger(elm.value))
					return this.onError(elm, "<?php echo JsEncode($loanunconfirmed_add->trycount->errorMessage()) ?>");
			<?php if ($loanunconfirmed_add->lasttrytime->Required) { ?>
				elm = this.getElements("x" + infix + "_lasttrytime");
				if (elm && !ew.isHidden(elm) && !ew.hasValue(elm))
					return this.onError(elm, "<?php echo JsEncode(str_replace("%s", $loanunconfirmed_add->lasttrytime->caption(), $loanunconfirmed_add->lasttrytime->RequiredErrorMessage)) ?>");
			<?php } ?>
				elm = this.getElements("x" + infix + "_lasttrytime");
				if (elm && !ew.checkDateDef(elm.value))
					return this.onError(elm, "<?php echo JsEncode($loanunconfirmed_add->lasttrytime->errorMessage()) ?>");

				// Call Form_CustomValidate event
				if (!this.Form_CustomValidate(fobj))
					return false;
		}

		// Process detail forms
		var dfs = $fobj.find("input[name='detailpage']").get();
		for (var i = 0; i < dfs.length; i++) {
			var df = dfs[i], val = df.value;
			if (val && ew.forms[val])
				if (!ew.forms[val].validate())
					return false;
		}
		return true;
	}

	// Form_CustomValidate
	floanunconfirmedadd.Form_CustomValidate = function(fobj) { // DO NOT CHANGE THIS LINE!

		// Your custom validation code here, return false if invalid.
		return true;
	}

	// Use JavaScript validation or not
	floanunconfirmedadd.validateRequired = <?php echo Config("CLIENT_VALIDATE") ? "true" : "false" ?>;

	// Dynamic selection lists
	loadjs.done("floanunconfirmedadd");
});
</script>
<script>
loadjs.ready("head", function() {

	// Client script
	// Write your client script here, no need to add script tags.

});
</script>
<?php $loanunconfirmed_add->showPageHeader(); ?>
<?php
$loanunconfirmed_add->showMessage();
?>
<form name="floanunconfirmedadd" id="floanunconfirmedadd" class="<?php echo $loanunconfirmed_add->FormClassName ?>" action="<?php echo CurrentPageName() ?>" method="post">
<?php if ($Page->CheckToken) { ?>
<input type="hidden" name="<?php echo Config("TOKEN_NAME") ?>" value="<?php echo $Page->Token ?>">
<?php } ?>
<input type="hidden" name="t" value="loanunconfirmed">
<input type="hidden" name="action" id="action" value="insert">
<input type="hidden" name="modal" value="<?php echo (int)$loanunconfirmed_add->IsModal ?>">
<div class="ew-add-div"><!-- page* -->
<?php if ($loanunconfirmed_add->loanid->Visible) { // loanid ?>
	<div id="r_loanid" class="form-group row">
		<label id="elh_loanunconfirmed_loanid" for="x_loanid" class="<?php echo $loanunconfirmed_add->LeftColumnClass ?>"><?php echo $loanunconfirmed_add->loanid->caption() ?><?php echo $loanunconfirmed_add->loanid->Required ? $Language->phrase("FieldRequiredIndicator") : "" ?></label>
		<div class="<?php echo $loanunconfirmed_add->RightColumnClass ?>"><div <?php echo $loanunconfirmed_add->loanid->cellAttributes() ?>>
<span id="el_loanunconfirmed_loanid">
<input type="text" data-table="loanunconfirmed" data-field="x_loanid" name="x_loanid" id="x_loanid" size="30" maxlength="12" placeholder="<?php echo HtmlEncode($loanunconfirmed_add->loanid->getPlaceHolder()) ?>" value="<?php echo $loanunconfirmed_add->loanid->EditValue ?>"<?php echo $loanunconfirmed_add->loanid->editAttributes() ?>>
</span>
<?php echo $loanunconfirmed_add->loanid->CustomMsg ?></div></div>
	</div>
<?php } ?>
<?php if ($loanunconfirmed_add->loggedtime->Visible) { // loggedtime ?>
	<div id="r_loggedtime" class="form-group row">
		<label id="elh_loanunconfirmed_loggedtime" for="x_loggedtime" class="<?php echo $loanunconfirmed_add->LeftColumnClass ?>"><?php echo $loanunconfirmed_add->loggedtime->caption() ?><?php echo $loanunconfirmed_add->loggedtime->Required ? $Language->phrase("FieldRequiredIndicator") : "" ?></label>
		<div class="<?php echo $loanunconfirmed_add->RightColumnClass ?>"><div <?php echo $loanunconfirmed_add->loggedtime->cellAttributes() ?>>
<span id="el_loanunconfirmed_loggedtime">
<input type="text" data-table="loanunconfirmed" data-field="x_loggedtime" name="x_loggedtime" id="x_loggedtime" maxlength="19" placeholder="<?php echo HtmlEncode($loanunconfirmed_add->loggedtime->getPlaceHolder()) ?>" value="<?php echo $loanunconfirmed_add->loggedtime->EditValue ?>"<?php echo $loanunconfirmed_add->loggedtime->editAttributes() ?>>
<?php if (!$loanunconfirmed_add->loggedtime->ReadOnly && !$loanunconfirmed_add->loggedtime->Disabled && !isset($loanunconfirmed_add->loggedtime->EditAttrs["readonly"]) && !isset($loanunconfirmed_add->loggedtime->EditAttrs["disabled"])) { ?>
<script>
loadjs.ready(["floanunconfirmedadd", "datetimepicker"], function() {
	ew.createDateTimePicker("floanunconfirmedadd", "x_loggedtime", {"ignoreReadonly":true,"useCurrent":false,"format":0});
});
</script>
<?php } ?>
</span>
<?php echo $loanunconfirmed_add->loggedtime->CustomMsg ?></div></div>
	</div>
<?php } ?>
<?php if ($loanunconfirmed_add->trycount->Visible) { // trycount ?>
	<div id="r_trycount" class="form-group row">
		<label id="elh_loanunconfirmed_trycount" for="x_trycount" class="<?php echo $loanunconfirmed_add->LeftColumnClass ?>"><?php echo $loanunconfirmed_add->trycount->caption() ?><?php echo $loanunconfirmed_add->trycount->Required ? $Language->phrase("FieldRequiredIndicator") : "" ?></label>
		<div class="<?php echo $loanunconfirmed_add->RightColumnClass ?>"><div <?php echo $loanunconfirmed_add->trycount->cellAttributes() ?>>
<span id="el_loanunconfirmed_trycount">
<input type="text" data-table="loanunconfirmed" data-field="x_trycount" name="x_trycount" id="x_trycount" size="30" maxlength="1" placeholder="<?php echo HtmlEncode($loanunconfirmed_add->trycount->getPlaceHolder()) ?>" value="<?php echo $loanunconfirmed_add->trycount->EditValue ?>"<?php echo $loanunconfirmed_add->trycount->editAttributes() ?>>
</span>
<?php echo $loanunconfirmed_add->trycount->CustomMsg ?></div></div>
	</div>
<?php } ?>
<?php if ($loanunconfirmed_add->lasttrytime->Visible) { // lasttrytime ?>
	<div id="r_lasttrytime" class="form-group row">
		<label id="elh_loanunconfirmed_lasttrytime" for="x_lasttrytime" class="<?php echo $loanunconfirmed_add->LeftColumnClass ?>"><?php echo $loanunconfirmed_add->lasttrytime->caption() ?><?php echo $loanunconfirmed_add->lasttrytime->Required ? $Language->phrase("FieldRequiredIndicator") : "" ?></label>
		<div class="<?php echo $loanunconfirmed_add->RightColumnClass ?>"><div <?php echo $loanunconfirmed_add->lasttrytime->cellAttributes() ?>>
<span id="el_loanunconfirmed_lasttrytime">
<input type="text" data-table="loanunconfirmed" data-field="x_lasttrytime" name="x_lasttrytime" id="x_lasttrytime" maxlength="19" placeholder="<?php echo HtmlEncode($loanunconfirmed_add->lasttrytime->getPlaceHolder()) ?>" value="<?php echo $loanunconfirmed_add->lasttrytime->EditValue ?>"<?php echo $loanunconfirmed_add->lasttrytime->editAttributes() ?>>
<?php if (!$loanunconfirmed_add->lasttrytime->ReadOnly && !$loanunconfirmed_add->lasttrytime->Disabled && !isset($loanunconfirmed_add->lasttrytime->EditAttrs["readonly"]) && !isset($loanunconfirmed_add->lasttrytime->EditAttrs["disabled"])) { ?>
<script>
loadjs.ready(["floanunconfirmedadd", "datetimepicker"], function() {
	ew.createDateTimePicker("floanunconfirmedadd", "x_lasttrytime", {"ignoreReadonly":true,"useCurrent":false,"format":0});
});
</script>
<?php } ?>
</span>
<?php echo $loanunconfirmed_add->lasttrytime->CustomMsg ?></div></div>
	</div>
<?php } ?>
</div><!-- /page* -->
<?php if (!$loanunconfirmed_add->IsModal) { ?>
<div class="form-group row"><!-- buttons .form-group -->
	<div class="<?php echo $loanunconfirmed_add->OffsetColumnClass ?>"><!-- buttons offset -->
<button class="btn btn-primary ew-btn" name="btn-action" id="btn-action" type="submit"><?php echo $Language->phrase("AddBtn") ?></button>
<button class="btn btn-default ew-btn" name="btn-cancel" id="btn-cancel" type="button" data-href="<?php echo $loanunconfirmed_add->getReturnUrl() ?>"><?php echo $Language->phrase("CancelBtn") ?></button>
	</div><!-- /buttons offset -->
</div><!-- /buttons .form-group -->
<?php } ?>
</form>
<?php
$loanunconfirmed_add->showPageFooter();
if (Config("DEBUG"))
	echo GetDebugMessage();
?>
<script>
loadjs.ready("load", function() {

	// Startup script
	// Write your table-specific startup script here
	// console.log("page loaded");

});
</script>
<?php include_once "footer.php"; ?>
<?php
$loanunconfirmed_add->terminate();
?>