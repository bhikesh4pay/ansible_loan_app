<?php
namespace PHPMaker2020\_4payadmin;

// Autoload
include_once "autoload.php";

// Session
if (session_status() !== PHP_SESSION_ACTIVE)
	\Delight\Cookie\Session::start(Config("COOKIE_SAMESITE")); // Init session data

// Output buffering
ob_start();
?>
<?php

// Write header
WriteHeader(FALSE);

// Create page object
$billacclookup_delete = new billacclookup_delete();

// Run the page
$billacclookup_delete->run();

// Setup login status
SetupLoginStatus();
SetClientVar("login", LoginStatus());

// Global Page Rendering event (in userfn*.php)
Page_Rendering();

// Page Rendering event
$billacclookup_delete->Page_Render();
?>
<?php include_once "header.php"; ?>
<script>
var fbillacclookupdelete, currentPageID;
loadjs.ready("head", function() {

	// Form object
	currentPageID = ew.PAGE_ID = "delete";
	fbillacclookupdelete = currentForm = new ew.Form("fbillacclookupdelete", "delete");
	loadjs.done("fbillacclookupdelete");
});
</script>
<script>
loadjs.ready("head", function() {

	// Client script
	// Write your client script here, no need to add script tags.

});
</script>
<?php $billacclookup_delete->showPageHeader(); ?>
<?php
$billacclookup_delete->showMessage();
?>
<form name="fbillacclookupdelete" id="fbillacclookupdelete" class="form-inline ew-form ew-delete-form" action="<?php echo CurrentPageName() ?>" method="post">
<?php if ($Page->CheckToken) { ?>
<input type="hidden" name="<?php echo Config("TOKEN_NAME") ?>" value="<?php echo $Page->Token ?>">
<?php } ?>
<input type="hidden" name="t" value="billacclookup">
<input type="hidden" name="action" id="action" value="delete">
<?php foreach ($billacclookup_delete->RecKeys as $key) { ?>
<?php $keyvalue = is_array($key) ? implode(Config("COMPOSITE_KEY_SEPARATOR"), $key) : $key; ?>
<input type="hidden" name="key_m[]" value="<?php echo HtmlEncode($keyvalue) ?>">
<?php } ?>
<div class="card ew-card ew-grid">
<div class="<?php echo ResponsiveTableClass() ?>card-body ew-grid-middle-panel">
<table class="table ew-table">
	<thead>
	<tr class="ew-table-header">
<?php if ($billacclookup_delete->recid->Visible) { // recid ?>
		<th class="<?php echo $billacclookup_delete->recid->headerCellClass() ?>"><span id="elh_billacclookup_recid" class="billacclookup_recid"><?php echo $billacclookup_delete->recid->caption() ?></span></th>
<?php } ?>
<?php if ($billacclookup_delete->logtime->Visible) { // logtime ?>
		<th class="<?php echo $billacclookup_delete->logtime->headerCellClass() ?>"><span id="elh_billacclookup_logtime" class="billacclookup_logtime"><?php echo $billacclookup_delete->logtime->caption() ?></span></th>
<?php } ?>
<?php if ($billacclookup_delete->_userid->Visible) { // userid ?>
		<th class="<?php echo $billacclookup_delete->_userid->headerCellClass() ?>"><span id="elh_billacclookup__userid" class="billacclookup__userid"><?php echo $billacclookup_delete->_userid->caption() ?></span></th>
<?php } ?>
<?php if ($billacclookup_delete->serviceid->Visible) { // serviceid ?>
		<th class="<?php echo $billacclookup_delete->serviceid->headerCellClass() ?>"><span id="elh_billacclookup_serviceid" class="billacclookup_serviceid"><?php echo $billacclookup_delete->serviceid->caption() ?></span></th>
<?php } ?>
<?php if ($billacclookup_delete->billaccountno->Visible) { // billaccountno ?>
		<th class="<?php echo $billacclookup_delete->billaccountno->headerCellClass() ?>"><span id="elh_billacclookup_billaccountno" class="billacclookup_billaccountno"><?php echo $billacclookup_delete->billaccountno->caption() ?></span></th>
<?php } ?>
	</tr>
	</thead>
	<tbody>
<?php
$billacclookup_delete->RecordCount = 0;
$i = 0;
while (!$billacclookup_delete->Recordset->EOF) {
	$billacclookup_delete->RecordCount++;
	$billacclookup_delete->RowCount++;

	// Set row properties
	$billacclookup->resetAttributes();
	$billacclookup->RowType = ROWTYPE_VIEW; // View

	// Get the field contents
	$billacclookup_delete->loadRowValues($billacclookup_delete->Recordset);

	// Render row
	$billacclookup_delete->renderRow();
?>
	<tr <?php echo $billacclookup->rowAttributes() ?>>
<?php if ($billacclookup_delete->recid->Visible) { // recid ?>
		<td <?php echo $billacclookup_delete->recid->cellAttributes() ?>>
<span id="el<?php echo $billacclookup_delete->RowCount ?>_billacclookup_recid" class="billacclookup_recid">
<span<?php echo $billacclookup_delete->recid->viewAttributes() ?>><?php echo $billacclookup_delete->recid->getViewValue() ?></span>
</span>
</td>
<?php } ?>
<?php if ($billacclookup_delete->logtime->Visible) { // logtime ?>
		<td <?php echo $billacclookup_delete->logtime->cellAttributes() ?>>
<span id="el<?php echo $billacclookup_delete->RowCount ?>_billacclookup_logtime" class="billacclookup_logtime">
<span<?php echo $billacclookup_delete->logtime->viewAttributes() ?>><?php echo $billacclookup_delete->logtime->getViewValue() ?></span>
</span>
</td>
<?php } ?>
<?php if ($billacclookup_delete->_userid->Visible) { // userid ?>
		<td <?php echo $billacclookup_delete->_userid->cellAttributes() ?>>
<span id="el<?php echo $billacclookup_delete->RowCount ?>_billacclookup__userid" class="billacclookup__userid">
<span<?php echo $billacclookup_delete->_userid->viewAttributes() ?>><?php echo $billacclookup_delete->_userid->getViewValue() ?></span>
</span>
</td>
<?php } ?>
<?php if ($billacclookup_delete->serviceid->Visible) { // serviceid ?>
		<td <?php echo $billacclookup_delete->serviceid->cellAttributes() ?>>
<span id="el<?php echo $billacclookup_delete->RowCount ?>_billacclookup_serviceid" class="billacclookup_serviceid">
<span<?php echo $billacclookup_delete->serviceid->viewAttributes() ?>><?php echo $billacclookup_delete->serviceid->getViewValue() ?></span>
</span>
</td>
<?php } ?>
<?php if ($billacclookup_delete->billaccountno->Visible) { // billaccountno ?>
		<td <?php echo $billacclookup_delete->billaccountno->cellAttributes() ?>>
<span id="el<?php echo $billacclookup_delete->RowCount ?>_billacclookup_billaccountno" class="billacclookup_billaccountno">
<span<?php echo $billacclookup_delete->billaccountno->viewAttributes() ?>><?php echo $billacclookup_delete->billaccountno->getViewValue() ?></span>
</span>
</td>
<?php } ?>
	</tr>
<?php
	$billacclookup_delete->Recordset->moveNext();
}
$billacclookup_delete->Recordset->close();
?>
</tbody>
</table>
</div>
</div>
<div>
<button class="btn btn-primary ew-btn" name="btn-action" id="btn-action" type="submit"><?php echo $Language->phrase("DeleteBtn") ?></button>
<button class="btn btn-default ew-btn" name="btn-cancel" id="btn-cancel" type="button" data-href="<?php echo $billacclookup_delete->getReturnUrl() ?>"><?php echo $Language->phrase("CancelBtn") ?></button>
</div>
</form>
<?php
$billacclookup_delete->showPageFooter();
if (Config("DEBUG"))
	echo GetDebugMessage();
?>
<script>
loadjs.ready("load", function() {

	// Startup script
	// Write your table-specific startup script here
	// console.log("page loaded");

});
</script>
<?php include_once "footer.php"; ?>
<?php
$billacclookup_delete->terminate();
?>