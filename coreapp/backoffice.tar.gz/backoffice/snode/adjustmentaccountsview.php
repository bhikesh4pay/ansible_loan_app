<?php
namespace PHPMaker2020\_4payadmin;

// Autoload
include_once "autoload.php";

// Session
if (session_status() !== PHP_SESSION_ACTIVE)
	\Delight\Cookie\Session::start(Config("COOKIE_SAMESITE")); // Init session data

// Output buffering
ob_start();
?>
<?php

// Write header
WriteHeader(FALSE);

// Create page object
$adjustmentaccounts_view = new adjustmentaccounts_view();

// Run the page
$adjustmentaccounts_view->run();

// Setup login status
SetupLoginStatus();
SetClientVar("login", LoginStatus());

// Global Page Rendering event (in userfn*.php)
Page_Rendering();

// Page Rendering event
$adjustmentaccounts_view->Page_Render();
?>
<?php include_once "header.php"; ?>
<?php if (!$adjustmentaccounts_view->isExport()) { ?>
<script>
var fadjustmentaccountsview, currentPageID;
loadjs.ready("head", function() {

	// Form object
	currentPageID = ew.PAGE_ID = "view";
	fadjustmentaccountsview = currentForm = new ew.Form("fadjustmentaccountsview", "view");
	loadjs.done("fadjustmentaccountsview");
});
</script>
<script>
loadjs.ready("head", function() {

	// Client script
	// Write your client script here, no need to add script tags.

});
</script>
<?php } ?>
<?php if (!$adjustmentaccounts_view->isExport()) { ?>
<div class="btn-toolbar ew-toolbar">
<?php $adjustmentaccounts_view->ExportOptions->render("body") ?>
<?php $adjustmentaccounts_view->OtherOptions->render("body") ?>
<div class="clearfix"></div>
</div>
<?php } ?>
<?php $adjustmentaccounts_view->showPageHeader(); ?>
<?php
$adjustmentaccounts_view->showMessage();
?>
<form name="fadjustmentaccountsview" id="fadjustmentaccountsview" class="form-inline ew-form ew-view-form" action="<?php echo CurrentPageName() ?>" method="post">
<?php if ($Page->CheckToken) { ?>
<input type="hidden" name="<?php echo Config("TOKEN_NAME") ?>" value="<?php echo $Page->Token ?>">
<?php } ?>
<input type="hidden" name="t" value="adjustmentaccounts">
<input type="hidden" name="modal" value="<?php echo (int)$adjustmentaccounts_view->IsModal ?>">
<table class="table table-striped table-sm ew-view-table">
<?php if ($adjustmentaccounts_view->acctid->Visible) { // acctid ?>
	<tr id="r_acctid">
		<td class="<?php echo $adjustmentaccounts_view->TableLeftColumnClass ?>"><span id="elh_adjustmentaccounts_acctid"><?php echo $adjustmentaccounts_view->acctid->caption() ?></span></td>
		<td data-name="acctid" <?php echo $adjustmentaccounts_view->acctid->cellAttributes() ?>>
<span id="el_adjustmentaccounts_acctid">
<span<?php echo $adjustmentaccounts_view->acctid->viewAttributes() ?>><?php echo $adjustmentaccounts_view->acctid->getViewValue() ?></span>
</span>
</td>
	</tr>
<?php } ?>
<?php if ($adjustmentaccounts_view->description->Visible) { // description ?>
	<tr id="r_description">
		<td class="<?php echo $adjustmentaccounts_view->TableLeftColumnClass ?>"><span id="elh_adjustmentaccounts_description"><?php echo $adjustmentaccounts_view->description->caption() ?></span></td>
		<td data-name="description" <?php echo $adjustmentaccounts_view->description->cellAttributes() ?>>
<span id="el_adjustmentaccounts_description">
<span<?php echo $adjustmentaccounts_view->description->viewAttributes() ?>><?php echo $adjustmentaccounts_view->description->getViewValue() ?></span>
</span>
</td>
	</tr>
<?php } ?>
<?php if ($adjustmentaccounts_view->active->Visible) { // active ?>
	<tr id="r_active">
		<td class="<?php echo $adjustmentaccounts_view->TableLeftColumnClass ?>"><span id="elh_adjustmentaccounts_active"><?php echo $adjustmentaccounts_view->active->caption() ?></span></td>
		<td data-name="active" <?php echo $adjustmentaccounts_view->active->cellAttributes() ?>>
<span id="el_adjustmentaccounts_active">
<span<?php echo $adjustmentaccounts_view->active->viewAttributes() ?>><?php echo $adjustmentaccounts_view->active->getViewValue() ?></span>
</span>
</td>
	</tr>
<?php } ?>
<?php if ($adjustmentaccounts_view->_userid->Visible) { // userid ?>
	<tr id="r__userid">
		<td class="<?php echo $adjustmentaccounts_view->TableLeftColumnClass ?>"><span id="elh_adjustmentaccounts__userid"><?php echo $adjustmentaccounts_view->_userid->caption() ?></span></td>
		<td data-name="_userid" <?php echo $adjustmentaccounts_view->_userid->cellAttributes() ?>>
<span id="el_adjustmentaccounts__userid">
<span<?php echo $adjustmentaccounts_view->_userid->viewAttributes() ?>><?php echo $adjustmentaccounts_view->_userid->getViewValue() ?></span>
</span>
</td>
	</tr>
<?php } ?>
</table>
</form>
<?php
$adjustmentaccounts_view->showPageFooter();
if (Config("DEBUG"))
	echo GetDebugMessage();
?>
<?php if (!$adjustmentaccounts_view->isExport()) { ?>
<script>
loadjs.ready("load", function() {

	// Startup script
	// Write your table-specific startup script here
	// console.log("page loaded");

});
</script>
<?php } ?>
<?php include_once "footer.php"; ?>
<?php
$adjustmentaccounts_view->terminate();
?>