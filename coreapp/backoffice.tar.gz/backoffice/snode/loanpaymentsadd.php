<?php
namespace PHPMaker2020\_4payadmin;

// Autoload
include_once "autoload.php";

// Session
if (session_status() !== PHP_SESSION_ACTIVE)
	\Delight\Cookie\Session::start(Config("COOKIE_SAMESITE")); // Init session data

// Output buffering
ob_start();
?>
<?php

// Write header
WriteHeader(FALSE);

// Create page object
$loanpayments_add = new loanpayments_add();

// Run the page
$loanpayments_add->run();

// Setup login status
SetupLoginStatus();
SetClientVar("login", LoginStatus());

// Global Page Rendering event (in userfn*.php)
Page_Rendering();

// Page Rendering event
$loanpayments_add->Page_Render();
?>
<?php include_once "header.php"; ?>
<script>
var floanpaymentsadd, currentPageID;
loadjs.ready("head", function() {

	// Form object
	currentPageID = ew.PAGE_ID = "add";
	floanpaymentsadd = currentForm = new ew.Form("floanpaymentsadd", "add");

	// Validate form
	floanpaymentsadd.validate = function() {
		if (!this.validateRequired)
			return true; // Ignore validation
		var $ = jQuery, fobj = this.getForm(), $fobj = $(fobj);
		if ($fobj.find("#confirm").val() == "confirm")
			return true;
		var elm, felm, uelm, addcnt = 0;
		var $k = $fobj.find("#" + this.formKeyCountName); // Get key_count
		var rowcnt = ($k[0]) ? parseInt($k.val(), 10) : 1;
		var startcnt = (rowcnt == 0) ? 0 : 1; // Check rowcnt == 0 => Inline-Add
		var gridinsert = ["insert", "gridinsert"].includes($fobj.find("#action").val()) && $k[0];
		for (var i = startcnt; i <= rowcnt; i++) {
			var infix = ($k[0]) ? String(i) : "";
			$fobj.data("rowindex", infix);
			<?php if ($loanpayments_add->paymentdate->Required) { ?>
				elm = this.getElements("x" + infix + "_paymentdate");
				if (elm && !ew.isHidden(elm) && !ew.hasValue(elm))
					return this.onError(elm, "<?php echo JsEncode(str_replace("%s", $loanpayments_add->paymentdate->caption(), $loanpayments_add->paymentdate->RequiredErrorMessage)) ?>");
			<?php } ?>
				elm = this.getElements("x" + infix + "_paymentdate");
				if (elm && !ew.checkDateDef(elm.value))
					return this.onError(elm, "<?php echo JsEncode($loanpayments_add->paymentdate->errorMessage()) ?>");
			<?php if ($loanpayments_add->_userid->Required) { ?>
				elm = this.getElements("x" + infix + "__userid");
				if (elm && !ew.isHidden(elm) && !ew.hasValue(elm))
					return this.onError(elm, "<?php echo JsEncode(str_replace("%s", $loanpayments_add->_userid->caption(), $loanpayments_add->_userid->RequiredErrorMessage)) ?>");
			<?php } ?>
				elm = this.getElements("x" + infix + "__userid");
				if (elm && !ew.checkInteger(elm.value))
					return this.onError(elm, "<?php echo JsEncode($loanpayments_add->_userid->errorMessage()) ?>");
			<?php if ($loanpayments_add->currcode->Required) { ?>
				elm = this.getElements("x" + infix + "_currcode");
				if (elm && !ew.isHidden(elm) && !ew.hasValue(elm))
					return this.onError(elm, "<?php echo JsEncode(str_replace("%s", $loanpayments_add->currcode->caption(), $loanpayments_add->currcode->RequiredErrorMessage)) ?>");
			<?php } ?>
			<?php if ($loanpayments_add->paymentamount->Required) { ?>
				elm = this.getElements("x" + infix + "_paymentamount");
				if (elm && !ew.isHidden(elm) && !ew.hasValue(elm))
					return this.onError(elm, "<?php echo JsEncode(str_replace("%s", $loanpayments_add->paymentamount->caption(), $loanpayments_add->paymentamount->RequiredErrorMessage)) ?>");
			<?php } ?>
				elm = this.getElements("x" + infix + "_paymentamount");
				if (elm && !ew.checkNumber(elm.value))
					return this.onError(elm, "<?php echo JsEncode($loanpayments_add->paymentamount->errorMessage()) ?>");
			<?php if ($loanpayments_add->amountapplied->Required) { ?>
				elm = this.getElements("x" + infix + "_amountapplied");
				if (elm && !ew.isHidden(elm) && !ew.hasValue(elm))
					return this.onError(elm, "<?php echo JsEncode(str_replace("%s", $loanpayments_add->amountapplied->caption(), $loanpayments_add->amountapplied->RequiredErrorMessage)) ?>");
			<?php } ?>
				elm = this.getElements("x" + infix + "_amountapplied");
				if (elm && !ew.checkNumber(elm.value))
					return this.onError(elm, "<?php echo JsEncode($loanpayments_add->amountapplied->errorMessage()) ?>");
			<?php if ($loanpayments_add->residualamount->Required) { ?>
				elm = this.getElements("x" + infix + "_residualamount");
				if (elm && !ew.isHidden(elm) && !ew.hasValue(elm))
					return this.onError(elm, "<?php echo JsEncode(str_replace("%s", $loanpayments_add->residualamount->caption(), $loanpayments_add->residualamount->RequiredErrorMessage)) ?>");
			<?php } ?>
				elm = this.getElements("x" + infix + "_residualamount");
				if (elm && !ew.checkNumber(elm.value))
					return this.onError(elm, "<?php echo JsEncode($loanpayments_add->residualamount->errorMessage()) ?>");
			<?php if ($loanpayments_add->externalrefno->Required) { ?>
				elm = this.getElements("x" + infix + "_externalrefno");
				if (elm && !ew.isHidden(elm) && !ew.hasValue(elm))
					return this.onError(elm, "<?php echo JsEncode(str_replace("%s", $loanpayments_add->externalrefno->caption(), $loanpayments_add->externalrefno->RequiredErrorMessage)) ?>");
			<?php } ?>
			<?php if ($loanpayments_add->principleamountapplied->Required) { ?>
				elm = this.getElements("x" + infix + "_principleamountapplied");
				if (elm && !ew.isHidden(elm) && !ew.hasValue(elm))
					return this.onError(elm, "<?php echo JsEncode(str_replace("%s", $loanpayments_add->principleamountapplied->caption(), $loanpayments_add->principleamountapplied->RequiredErrorMessage)) ?>");
			<?php } ?>
				elm = this.getElements("x" + infix + "_principleamountapplied");
				if (elm && !ew.checkNumber(elm.value))
					return this.onError(elm, "<?php echo JsEncode($loanpayments_add->principleamountapplied->errorMessage()) ?>");
			<?php if ($loanpayments_add->feesamountapplied->Required) { ?>
				elm = this.getElements("x" + infix + "_feesamountapplied");
				if (elm && !ew.isHidden(elm) && !ew.hasValue(elm))
					return this.onError(elm, "<?php echo JsEncode(str_replace("%s", $loanpayments_add->feesamountapplied->caption(), $loanpayments_add->feesamountapplied->RequiredErrorMessage)) ?>");
			<?php } ?>
				elm = this.getElements("x" + infix + "_feesamountapplied");
				if (elm && !ew.checkNumber(elm.value))
					return this.onError(elm, "<?php echo JsEncode($loanpayments_add->feesamountapplied->errorMessage()) ?>");
			<?php if ($loanpayments_add->latefeesamountapplied->Required) { ?>
				elm = this.getElements("x" + infix + "_latefeesamountapplied");
				if (elm && !ew.isHidden(elm) && !ew.hasValue(elm))
					return this.onError(elm, "<?php echo JsEncode(str_replace("%s", $loanpayments_add->latefeesamountapplied->caption(), $loanpayments_add->latefeesamountapplied->RequiredErrorMessage)) ?>");
			<?php } ?>
				elm = this.getElements("x" + infix + "_latefeesamountapplied");
				if (elm && !ew.checkNumber(elm.value))
					return this.onError(elm, "<?php echo JsEncode($loanpayments_add->latefeesamountapplied->errorMessage()) ?>");
			<?php if ($loanpayments_add->loanid->Required) { ?>
				elm = this.getElements("x" + infix + "_loanid");
				if (elm && !ew.isHidden(elm) && !ew.hasValue(elm))
					return this.onError(elm, "<?php echo JsEncode(str_replace("%s", $loanpayments_add->loanid->caption(), $loanpayments_add->loanid->RequiredErrorMessage)) ?>");
			<?php } ?>
				elm = this.getElements("x" + infix + "_loanid");
				if (elm && !ew.checkInteger(elm.value))
					return this.onError(elm, "<?php echo JsEncode($loanpayments_add->loanid->errorMessage()) ?>");
			<?php if ($loanpayments_add->latefeesonly->Required) { ?>
				elm = this.getElements("x" + infix + "_latefeesonly");
				if (elm && !ew.isHidden(elm) && !ew.hasValue(elm))
					return this.onError(elm, "<?php echo JsEncode(str_replace("%s", $loanpayments_add->latefeesonly->caption(), $loanpayments_add->latefeesonly->RequiredErrorMessage)) ?>");
			<?php } ?>
			<?php if ($loanpayments_add->lockflag->Required) { ?>
				elm = this.getElements("x" + infix + "_lockflag");
				if (elm && !ew.isHidden(elm) && !ew.hasValue(elm))
					return this.onError(elm, "<?php echo JsEncode(str_replace("%s", $loanpayments_add->lockflag->caption(), $loanpayments_add->lockflag->RequiredErrorMessage)) ?>");
			<?php } ?>
			<?php if ($loanpayments_add->lastreconciledate->Required) { ?>
				elm = this.getElements("x" + infix + "_lastreconciledate");
				if (elm && !ew.isHidden(elm) && !ew.hasValue(elm))
					return this.onError(elm, "<?php echo JsEncode(str_replace("%s", $loanpayments_add->lastreconciledate->caption(), $loanpayments_add->lastreconciledate->RequiredErrorMessage)) ?>");
			<?php } ?>
				elm = this.getElements("x" + infix + "_lastreconciledate");
				if (elm && !ew.checkDateDef(elm.value))
					return this.onError(elm, "<?php echo JsEncode($loanpayments_add->lastreconciledate->errorMessage()) ?>");

				// Call Form_CustomValidate event
				if (!this.Form_CustomValidate(fobj))
					return false;
		}

		// Process detail forms
		var dfs = $fobj.find("input[name='detailpage']").get();
		for (var i = 0; i < dfs.length; i++) {
			var df = dfs[i], val = df.value;
			if (val && ew.forms[val])
				if (!ew.forms[val].validate())
					return false;
		}
		return true;
	}

	// Form_CustomValidate
	floanpaymentsadd.Form_CustomValidate = function(fobj) { // DO NOT CHANGE THIS LINE!

		// Your custom validation code here, return false if invalid.
		return true;
	}

	// Use JavaScript validation or not
	floanpaymentsadd.validateRequired = <?php echo Config("CLIENT_VALIDATE") ? "true" : "false" ?>;

	// Dynamic selection lists
	floanpaymentsadd.lists["x_currcode"] = <?php echo $loanpayments_add->currcode->Lookup->toClientList($loanpayments_add) ?>;
	floanpaymentsadd.lists["x_currcode"].options = <?php echo JsonEncode($loanpayments_add->currcode->lookupOptions()) ?>;
	floanpaymentsadd.lists["x_latefeesonly"] = <?php echo $loanpayments_add->latefeesonly->Lookup->toClientList($loanpayments_add) ?>;
	floanpaymentsadd.lists["x_latefeesonly"].options = <?php echo JsonEncode($loanpayments_add->latefeesonly->options(FALSE, TRUE)) ?>;
	floanpaymentsadd.lists["x_lockflag"] = <?php echo $loanpayments_add->lockflag->Lookup->toClientList($loanpayments_add) ?>;
	floanpaymentsadd.lists["x_lockflag"].options = <?php echo JsonEncode($loanpayments_add->lockflag->options(FALSE, TRUE)) ?>;
	loadjs.done("floanpaymentsadd");
});
</script>
<script>
loadjs.ready("head", function() {

	// Client script
	// Write your client script here, no need to add script tags.

});
</script>
<?php $loanpayments_add->showPageHeader(); ?>
<?php
$loanpayments_add->showMessage();
?>
<form name="floanpaymentsadd" id="floanpaymentsadd" class="<?php echo $loanpayments_add->FormClassName ?>" action="<?php echo CurrentPageName() ?>" method="post">
<?php if ($Page->CheckToken) { ?>
<input type="hidden" name="<?php echo Config("TOKEN_NAME") ?>" value="<?php echo $Page->Token ?>">
<?php } ?>
<input type="hidden" name="t" value="loanpayments">
<input type="hidden" name="action" id="action" value="insert">
<input type="hidden" name="modal" value="<?php echo (int)$loanpayments_add->IsModal ?>">
<?php if ($loanpayments->getCurrentMasterTable() == "loanlimits") { ?>
<input type="hidden" name="<?php echo Config("TABLE_SHOW_MASTER") ?>" value="loanlimits">
<input type="hidden" name="fk__userid" value="<?php echo HtmlEncode($loanpayments_add->_userid->getSessionValue()) ?>">
<?php } ?>
<?php if ($loanpayments->getCurrentMasterTable() == "loanissued") { ?>
<input type="hidden" name="<?php echo Config("TABLE_SHOW_MASTER") ?>" value="loanissued">
<input type="hidden" name="fk_loanid" value="<?php echo HtmlEncode($loanpayments_add->loanid->getSessionValue()) ?>">
<input type="hidden" name="fk_currcode" value="<?php echo HtmlEncode($loanpayments_add->currcode->getSessionValue()) ?>">
<?php } ?>
<div class="ew-add-div"><!-- page* -->
<?php if ($loanpayments_add->paymentdate->Visible) { // paymentdate ?>
	<div id="r_paymentdate" class="form-group row">
		<label id="elh_loanpayments_paymentdate" for="x_paymentdate" class="<?php echo $loanpayments_add->LeftColumnClass ?>"><?php echo $loanpayments_add->paymentdate->caption() ?><?php echo $loanpayments_add->paymentdate->Required ? $Language->phrase("FieldRequiredIndicator") : "" ?></label>
		<div class="<?php echo $loanpayments_add->RightColumnClass ?>"><div <?php echo $loanpayments_add->paymentdate->cellAttributes() ?>>
<span id="el_loanpayments_paymentdate">
<input type="text" data-table="loanpayments" data-field="x_paymentdate" data-format="1" name="x_paymentdate" id="x_paymentdate" placeholder="<?php echo HtmlEncode($loanpayments_add->paymentdate->getPlaceHolder()) ?>" value="<?php echo $loanpayments_add->paymentdate->EditValue ?>"<?php echo $loanpayments_add->paymentdate->editAttributes() ?>>
<?php if (!$loanpayments_add->paymentdate->ReadOnly && !$loanpayments_add->paymentdate->Disabled && !isset($loanpayments_add->paymentdate->EditAttrs["readonly"]) && !isset($loanpayments_add->paymentdate->EditAttrs["disabled"])) { ?>
<script>
loadjs.ready(["floanpaymentsadd", "datetimepicker"], function() {
	ew.createDateTimePicker("floanpaymentsadd", "x_paymentdate", {"ignoreReadonly":true,"useCurrent":false,"format":1});
});
</script>
<?php } ?>
</span>
<?php echo $loanpayments_add->paymentdate->CustomMsg ?></div></div>
	</div>
<?php } ?>
<?php if ($loanpayments_add->_userid->Visible) { // userid ?>
	<div id="r__userid" class="form-group row">
		<label id="elh_loanpayments__userid" for="x__userid" class="<?php echo $loanpayments_add->LeftColumnClass ?>"><?php echo $loanpayments_add->_userid->caption() ?><?php echo $loanpayments_add->_userid->Required ? $Language->phrase("FieldRequiredIndicator") : "" ?></label>
		<div class="<?php echo $loanpayments_add->RightColumnClass ?>"><div <?php echo $loanpayments_add->_userid->cellAttributes() ?>>
<?php if ($loanpayments_add->_userid->getSessionValue() != "") { ?>
<span id="el_loanpayments__userid">
<span<?php echo $loanpayments_add->_userid->viewAttributes() ?>><?php if (!EmptyString($loanpayments_add->_userid->ViewValue) && $loanpayments_add->_userid->linkAttributes() != "") { ?>
<a<?php echo $loanpayments_add->_userid->linkAttributes() ?>><input type="text" readonly class="form-control-plaintext" value="<?php echo HtmlEncode(RemoveHtml($loanpayments_add->_userid->ViewValue)) ?>"></a>
<?php } else { ?>
<input type="text" readonly class="form-control-plaintext" value="<?php echo HtmlEncode(RemoveHtml($loanpayments_add->_userid->ViewValue)) ?>">
<?php } ?></span>
</span>
<input type="hidden" id="x__userid" name="x__userid" value="<?php echo HtmlEncode($loanpayments_add->_userid->CurrentValue) ?>">
<?php } else { ?>
<span id="el_loanpayments__userid">
<input type="text" data-table="loanpayments" data-field="x__userid" name="x__userid" id="x__userid" size="30" placeholder="<?php echo HtmlEncode($loanpayments_add->_userid->getPlaceHolder()) ?>" value="<?php echo $loanpayments_add->_userid->EditValue ?>"<?php echo $loanpayments_add->_userid->editAttributes() ?>>
</span>
<?php } ?>
<?php echo $loanpayments_add->_userid->CustomMsg ?></div></div>
	</div>
<?php } ?>
<?php if ($loanpayments_add->currcode->Visible) { // currcode ?>
	<div id="r_currcode" class="form-group row">
		<label id="elh_loanpayments_currcode" for="x_currcode" class="<?php echo $loanpayments_add->LeftColumnClass ?>"><?php echo $loanpayments_add->currcode->caption() ?><?php echo $loanpayments_add->currcode->Required ? $Language->phrase("FieldRequiredIndicator") : "" ?></label>
		<div class="<?php echo $loanpayments_add->RightColumnClass ?>"><div <?php echo $loanpayments_add->currcode->cellAttributes() ?>>
<?php if ($loanpayments_add->currcode->getSessionValue() != "") { ?>
<span id="el_loanpayments_currcode">
<span<?php echo $loanpayments_add->currcode->viewAttributes() ?>><input type="text" readonly class="form-control-plaintext" value="<?php echo HtmlEncode(RemoveHtml($loanpayments_add->currcode->ViewValue)) ?>"></span>
</span>
<input type="hidden" id="x_currcode" name="x_currcode" value="<?php echo HtmlEncode($loanpayments_add->currcode->CurrentValue) ?>">
<?php } else { ?>
<span id="el_loanpayments_currcode">
<div class="input-group">
	<select class="custom-select ew-custom-select" data-table="loanpayments" data-field="x_currcode" data-value-separator="<?php echo $loanpayments_add->currcode->displayValueSeparatorAttribute() ?>" id="x_currcode" name="x_currcode"<?php echo $loanpayments_add->currcode->editAttributes() ?>>
			<?php echo $loanpayments_add->currcode->selectOptionListHtml("x_currcode") ?>
		</select>
</div>
<?php echo $loanpayments_add->currcode->Lookup->getParamTag($loanpayments_add, "p_x_currcode") ?>
</span>
<?php } ?>
<?php echo $loanpayments_add->currcode->CustomMsg ?></div></div>
	</div>
<?php } ?>
<?php if ($loanpayments_add->paymentamount->Visible) { // paymentamount ?>
	<div id="r_paymentamount" class="form-group row">
		<label id="elh_loanpayments_paymentamount" for="x_paymentamount" class="<?php echo $loanpayments_add->LeftColumnClass ?>"><?php echo $loanpayments_add->paymentamount->caption() ?><?php echo $loanpayments_add->paymentamount->Required ? $Language->phrase("FieldRequiredIndicator") : "" ?></label>
		<div class="<?php echo $loanpayments_add->RightColumnClass ?>"><div <?php echo $loanpayments_add->paymentamount->cellAttributes() ?>>
<span id="el_loanpayments_paymentamount">
<input type="text" data-table="loanpayments" data-field="x_paymentamount" name="x_paymentamount" id="x_paymentamount" size="30" placeholder="<?php echo HtmlEncode($loanpayments_add->paymentamount->getPlaceHolder()) ?>" value="<?php echo $loanpayments_add->paymentamount->EditValue ?>"<?php echo $loanpayments_add->paymentamount->editAttributes() ?>>
</span>
<?php echo $loanpayments_add->paymentamount->CustomMsg ?></div></div>
	</div>
<?php } ?>
<?php if ($loanpayments_add->amountapplied->Visible) { // amountapplied ?>
	<div id="r_amountapplied" class="form-group row">
		<label id="elh_loanpayments_amountapplied" for="x_amountapplied" class="<?php echo $loanpayments_add->LeftColumnClass ?>"><?php echo $loanpayments_add->amountapplied->caption() ?><?php echo $loanpayments_add->amountapplied->Required ? $Language->phrase("FieldRequiredIndicator") : "" ?></label>
		<div class="<?php echo $loanpayments_add->RightColumnClass ?>"><div <?php echo $loanpayments_add->amountapplied->cellAttributes() ?>>
<span id="el_loanpayments_amountapplied">
<input type="text" data-table="loanpayments" data-field="x_amountapplied" name="x_amountapplied" id="x_amountapplied" size="30" placeholder="<?php echo HtmlEncode($loanpayments_add->amountapplied->getPlaceHolder()) ?>" value="<?php echo $loanpayments_add->amountapplied->EditValue ?>"<?php echo $loanpayments_add->amountapplied->editAttributes() ?>>
</span>
<?php echo $loanpayments_add->amountapplied->CustomMsg ?></div></div>
	</div>
<?php } ?>
<?php if ($loanpayments_add->residualamount->Visible) { // residualamount ?>
	<div id="r_residualamount" class="form-group row">
		<label id="elh_loanpayments_residualamount" for="x_residualamount" class="<?php echo $loanpayments_add->LeftColumnClass ?>"><?php echo $loanpayments_add->residualamount->caption() ?><?php echo $loanpayments_add->residualamount->Required ? $Language->phrase("FieldRequiredIndicator") : "" ?></label>
		<div class="<?php echo $loanpayments_add->RightColumnClass ?>"><div <?php echo $loanpayments_add->residualamount->cellAttributes() ?>>
<span id="el_loanpayments_residualamount">
<input type="text" data-table="loanpayments" data-field="x_residualamount" name="x_residualamount" id="x_residualamount" size="30" placeholder="<?php echo HtmlEncode($loanpayments_add->residualamount->getPlaceHolder()) ?>" value="<?php echo $loanpayments_add->residualamount->EditValue ?>"<?php echo $loanpayments_add->residualamount->editAttributes() ?>>
</span>
<?php echo $loanpayments_add->residualamount->CustomMsg ?></div></div>
	</div>
<?php } ?>
<?php if ($loanpayments_add->externalrefno->Visible) { // externalrefno ?>
	<div id="r_externalrefno" class="form-group row">
		<label id="elh_loanpayments_externalrefno" for="x_externalrefno" class="<?php echo $loanpayments_add->LeftColumnClass ?>"><?php echo $loanpayments_add->externalrefno->caption() ?><?php echo $loanpayments_add->externalrefno->Required ? $Language->phrase("FieldRequiredIndicator") : "" ?></label>
		<div class="<?php echo $loanpayments_add->RightColumnClass ?>"><div <?php echo $loanpayments_add->externalrefno->cellAttributes() ?>>
<span id="el_loanpayments_externalrefno">
<input type="text" data-table="loanpayments" data-field="x_externalrefno" name="x_externalrefno" id="x_externalrefno" size="30" maxlength="50" placeholder="<?php echo HtmlEncode($loanpayments_add->externalrefno->getPlaceHolder()) ?>" value="<?php echo $loanpayments_add->externalrefno->EditValue ?>"<?php echo $loanpayments_add->externalrefno->editAttributes() ?>>
</span>
<?php echo $loanpayments_add->externalrefno->CustomMsg ?></div></div>
	</div>
<?php } ?>
<?php if ($loanpayments_add->principleamountapplied->Visible) { // principleamountapplied ?>
	<div id="r_principleamountapplied" class="form-group row">
		<label id="elh_loanpayments_principleamountapplied" for="x_principleamountapplied" class="<?php echo $loanpayments_add->LeftColumnClass ?>"><?php echo $loanpayments_add->principleamountapplied->caption() ?><?php echo $loanpayments_add->principleamountapplied->Required ? $Language->phrase("FieldRequiredIndicator") : "" ?></label>
		<div class="<?php echo $loanpayments_add->RightColumnClass ?>"><div <?php echo $loanpayments_add->principleamountapplied->cellAttributes() ?>>
<span id="el_loanpayments_principleamountapplied">
<input type="text" data-table="loanpayments" data-field="x_principleamountapplied" name="x_principleamountapplied" id="x_principleamountapplied" size="30" maxlength="15" placeholder="<?php echo HtmlEncode($loanpayments_add->principleamountapplied->getPlaceHolder()) ?>" value="<?php echo $loanpayments_add->principleamountapplied->EditValue ?>"<?php echo $loanpayments_add->principleamountapplied->editAttributes() ?>>
</span>
<?php echo $loanpayments_add->principleamountapplied->CustomMsg ?></div></div>
	</div>
<?php } ?>
<?php if ($loanpayments_add->feesamountapplied->Visible) { // feesamountapplied ?>
	<div id="r_feesamountapplied" class="form-group row">
		<label id="elh_loanpayments_feesamountapplied" for="x_feesamountapplied" class="<?php echo $loanpayments_add->LeftColumnClass ?>"><?php echo $loanpayments_add->feesamountapplied->caption() ?><?php echo $loanpayments_add->feesamountapplied->Required ? $Language->phrase("FieldRequiredIndicator") : "" ?></label>
		<div class="<?php echo $loanpayments_add->RightColumnClass ?>"><div <?php echo $loanpayments_add->feesamountapplied->cellAttributes() ?>>
<span id="el_loanpayments_feesamountapplied">
<input type="text" data-table="loanpayments" data-field="x_feesamountapplied" name="x_feesamountapplied" id="x_feesamountapplied" size="30" maxlength="15" placeholder="<?php echo HtmlEncode($loanpayments_add->feesamountapplied->getPlaceHolder()) ?>" value="<?php echo $loanpayments_add->feesamountapplied->EditValue ?>"<?php echo $loanpayments_add->feesamountapplied->editAttributes() ?>>
</span>
<?php echo $loanpayments_add->feesamountapplied->CustomMsg ?></div></div>
	</div>
<?php } ?>
<?php if ($loanpayments_add->latefeesamountapplied->Visible) { // latefeesamountapplied ?>
	<div id="r_latefeesamountapplied" class="form-group row">
		<label id="elh_loanpayments_latefeesamountapplied" for="x_latefeesamountapplied" class="<?php echo $loanpayments_add->LeftColumnClass ?>"><?php echo $loanpayments_add->latefeesamountapplied->caption() ?><?php echo $loanpayments_add->latefeesamountapplied->Required ? $Language->phrase("FieldRequiredIndicator") : "" ?></label>
		<div class="<?php echo $loanpayments_add->RightColumnClass ?>"><div <?php echo $loanpayments_add->latefeesamountapplied->cellAttributes() ?>>
<span id="el_loanpayments_latefeesamountapplied">
<input type="text" data-table="loanpayments" data-field="x_latefeesamountapplied" name="x_latefeesamountapplied" id="x_latefeesamountapplied" size="30" maxlength="15" placeholder="<?php echo HtmlEncode($loanpayments_add->latefeesamountapplied->getPlaceHolder()) ?>" value="<?php echo $loanpayments_add->latefeesamountapplied->EditValue ?>"<?php echo $loanpayments_add->latefeesamountapplied->editAttributes() ?>>
</span>
<?php echo $loanpayments_add->latefeesamountapplied->CustomMsg ?></div></div>
	</div>
<?php } ?>
<?php if ($loanpayments_add->loanid->Visible) { // loanid ?>
	<div id="r_loanid" class="form-group row">
		<label id="elh_loanpayments_loanid" for="x_loanid" class="<?php echo $loanpayments_add->LeftColumnClass ?>"><?php echo $loanpayments_add->loanid->caption() ?><?php echo $loanpayments_add->loanid->Required ? $Language->phrase("FieldRequiredIndicator") : "" ?></label>
		<div class="<?php echo $loanpayments_add->RightColumnClass ?>"><div <?php echo $loanpayments_add->loanid->cellAttributes() ?>>
<?php if ($loanpayments_add->loanid->getSessionValue() != "") { ?>
<span id="el_loanpayments_loanid">
<span<?php echo $loanpayments_add->loanid->viewAttributes() ?>><input type="text" readonly class="form-control-plaintext" value="<?php echo HtmlEncode(RemoveHtml($loanpayments_add->loanid->ViewValue)) ?>"></span>
</span>
<input type="hidden" id="x_loanid" name="x_loanid" value="<?php echo HtmlEncode($loanpayments_add->loanid->CurrentValue) ?>">
<?php } else { ?>
<span id="el_loanpayments_loanid">
<input type="text" data-table="loanpayments" data-field="x_loanid" name="x_loanid" id="x_loanid" size="30" maxlength="12" placeholder="<?php echo HtmlEncode($loanpayments_add->loanid->getPlaceHolder()) ?>" value="<?php echo $loanpayments_add->loanid->EditValue ?>"<?php echo $loanpayments_add->loanid->editAttributes() ?>>
</span>
<?php } ?>
<?php echo $loanpayments_add->loanid->CustomMsg ?></div></div>
	</div>
<?php } ?>
<?php if ($loanpayments_add->latefeesonly->Visible) { // latefeesonly ?>
	<div id="r_latefeesonly" class="form-group row">
		<label id="elh_loanpayments_latefeesonly" for="x_latefeesonly" class="<?php echo $loanpayments_add->LeftColumnClass ?>"><?php echo $loanpayments_add->latefeesonly->caption() ?><?php echo $loanpayments_add->latefeesonly->Required ? $Language->phrase("FieldRequiredIndicator") : "" ?></label>
		<div class="<?php echo $loanpayments_add->RightColumnClass ?>"><div <?php echo $loanpayments_add->latefeesonly->cellAttributes() ?>>
<span id="el_loanpayments_latefeesonly">
<div class="input-group">
	<select class="custom-select ew-custom-select" data-table="loanpayments" data-field="x_latefeesonly" data-value-separator="<?php echo $loanpayments_add->latefeesonly->displayValueSeparatorAttribute() ?>" id="x_latefeesonly" name="x_latefeesonly"<?php echo $loanpayments_add->latefeesonly->editAttributes() ?>>
			<?php echo $loanpayments_add->latefeesonly->selectOptionListHtml("x_latefeesonly") ?>
		</select>
</div>
</span>
<?php echo $loanpayments_add->latefeesonly->CustomMsg ?></div></div>
	</div>
<?php } ?>
<?php if ($loanpayments_add->lockflag->Visible) { // lockflag ?>
	<div id="r_lockflag" class="form-group row">
		<label id="elh_loanpayments_lockflag" class="<?php echo $loanpayments_add->LeftColumnClass ?>"><?php echo $loanpayments_add->lockflag->caption() ?><?php echo $loanpayments_add->lockflag->Required ? $Language->phrase("FieldRequiredIndicator") : "" ?></label>
		<div class="<?php echo $loanpayments_add->RightColumnClass ?>"><div <?php echo $loanpayments_add->lockflag->cellAttributes() ?>>
<span id="el_loanpayments_lockflag">
<div id="tp_x_lockflag" class="ew-template"><input type="radio" class="custom-control-input" data-table="loanpayments" data-field="x_lockflag" data-value-separator="<?php echo $loanpayments_add->lockflag->displayValueSeparatorAttribute() ?>" name="x_lockflag" id="x_lockflag" value="{value}"<?php echo $loanpayments_add->lockflag->editAttributes() ?>></div>
<div id="dsl_x_lockflag" data-repeatcolumn="5" class="ew-item-list d-none"><div>
<?php echo $loanpayments_add->lockflag->radioButtonListHtml(FALSE, "x_lockflag") ?>
</div></div>
</span>
<?php echo $loanpayments_add->lockflag->CustomMsg ?></div></div>
	</div>
<?php } ?>
<?php if ($loanpayments_add->lastreconciledate->Visible) { // lastreconciledate ?>
	<div id="r_lastreconciledate" class="form-group row">
		<label id="elh_loanpayments_lastreconciledate" for="x_lastreconciledate" class="<?php echo $loanpayments_add->LeftColumnClass ?>"><?php echo $loanpayments_add->lastreconciledate->caption() ?><?php echo $loanpayments_add->lastreconciledate->Required ? $Language->phrase("FieldRequiredIndicator") : "" ?></label>
		<div class="<?php echo $loanpayments_add->RightColumnClass ?>"><div <?php echo $loanpayments_add->lastreconciledate->cellAttributes() ?>>
<span id="el_loanpayments_lastreconciledate">
<input type="text" data-table="loanpayments" data-field="x_lastreconciledate" name="x_lastreconciledate" id="x_lastreconciledate" maxlength="19" placeholder="<?php echo HtmlEncode($loanpayments_add->lastreconciledate->getPlaceHolder()) ?>" value="<?php echo $loanpayments_add->lastreconciledate->EditValue ?>"<?php echo $loanpayments_add->lastreconciledate->editAttributes() ?>>
<?php if (!$loanpayments_add->lastreconciledate->ReadOnly && !$loanpayments_add->lastreconciledate->Disabled && !isset($loanpayments_add->lastreconciledate->EditAttrs["readonly"]) && !isset($loanpayments_add->lastreconciledate->EditAttrs["disabled"])) { ?>
<script>
loadjs.ready(["floanpaymentsadd", "datetimepicker"], function() {
	ew.createDateTimePicker("floanpaymentsadd", "x_lastreconciledate", {"ignoreReadonly":true,"useCurrent":false,"format":0});
});
</script>
<?php } ?>
</span>
<?php echo $loanpayments_add->lastreconciledate->CustomMsg ?></div></div>
	</div>
<?php } ?>
</div><!-- /page* -->
<?php
	if (in_array("loanapplied", explode(",", $loanpayments->getCurrentDetailTable())) && $loanapplied->DetailAdd) {
?>
<?php if ($loanpayments->getCurrentDetailTable() != "") { ?>
<h4 class="ew-detail-caption"><?php echo $Language->tablePhrase("loanapplied", "TblCaption") ?></h4>
<?php } ?>
<?php include_once "loanappliedgrid.php" ?>
<?php } ?>
<?php
	if (in_array("loanlatefeesapplied", explode(",", $loanpayments->getCurrentDetailTable())) && $loanlatefeesapplied->DetailAdd) {
?>
<?php if ($loanpayments->getCurrentDetailTable() != "") { ?>
<h4 class="ew-detail-caption"><?php echo $Language->tablePhrase("loanlatefeesapplied", "TblCaption") ?></h4>
<?php } ?>
<?php include_once "loanlatefeesappliedgrid.php" ?>
<?php } ?>
<?php
	if (in_array("loanpaymentcancelrequests", explode(",", $loanpayments->getCurrentDetailTable())) && $loanpaymentcancelrequests->DetailAdd) {
?>
<?php if ($loanpayments->getCurrentDetailTable() != "") { ?>
<h4 class="ew-detail-caption"><?php echo $Language->tablePhrase("loanpaymentcancelrequests", "TblCaption") ?></h4>
<?php } ?>
<?php include_once "loanpaymentcancelrequestsgrid.php" ?>
<?php } ?>
<?php
	if (in_array("loanappliedcancelled", explode(",", $loanpayments->getCurrentDetailTable())) && $loanappliedcancelled->DetailAdd) {
?>
<?php if ($loanpayments->getCurrentDetailTable() != "") { ?>
<h4 class="ew-detail-caption"><?php echo $Language->tablePhrase("loanappliedcancelled", "TblCaption") ?></h4>
<?php } ?>
<?php include_once "loanappliedcancelledgrid.php" ?>
<?php } ?>
<?php
	if (in_array("loanlatefeesappliedcancelled", explode(",", $loanpayments->getCurrentDetailTable())) && $loanlatefeesappliedcancelled->DetailAdd) {
?>
<?php if ($loanpayments->getCurrentDetailTable() != "") { ?>
<h4 class="ew-detail-caption"><?php echo $Language->tablePhrase("loanlatefeesappliedcancelled", "TblCaption") ?></h4>
<?php } ?>
<?php include_once "loanlatefeesappliedcancelledgrid.php" ?>
<?php } ?>
<?php if (!$loanpayments_add->IsModal) { ?>
<div class="form-group row"><!-- buttons .form-group -->
	<div class="<?php echo $loanpayments_add->OffsetColumnClass ?>"><!-- buttons offset -->
<button class="btn btn-primary ew-btn" name="btn-action" id="btn-action" type="submit"><?php echo $Language->phrase("AddBtn") ?></button>
<button class="btn btn-default ew-btn" name="btn-cancel" id="btn-cancel" type="button" data-href="<?php echo $loanpayments_add->getReturnUrl() ?>"><?php echo $Language->phrase("CancelBtn") ?></button>
	</div><!-- /buttons offset -->
</div><!-- /buttons .form-group -->
<?php } ?>
</form>
<?php
$loanpayments_add->showPageFooter();
if (Config("DEBUG"))
	echo GetDebugMessage();
?>
<script>
loadjs.ready("load", function() {

	// Startup script
	// Write your table-specific startup script here
	// console.log("page loaded");

});
</script>
<?php include_once "footer.php"; ?>
<?php
$loanpayments_add->terminate();
?>