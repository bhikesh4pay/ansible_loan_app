<?php
namespace PHPMaker2020\_4payadmin;

// Autoload
include_once "autoload.php";

// Session
if (session_status() !== PHP_SESSION_ACTIVE)
	\Delight\Cookie\Session::start(Config("COOKIE_SAMESITE")); // Init session data

// Output buffering
ob_start();
?>
<?php

// Write header
WriteHeader(FALSE);

// Create page object
$userexternaltypes_list = new userexternaltypes_list();

// Run the page
$userexternaltypes_list->run();

// Setup login status
SetupLoginStatus();
SetClientVar("login", LoginStatus());

// Global Page Rendering event (in userfn*.php)
Page_Rendering();

// Page Rendering event
$userexternaltypes_list->Page_Render();
?>
<?php include_once "header.php"; ?>
<?php if (!$userexternaltypes_list->isExport()) { ?>
<script>
var fuserexternaltypeslist, currentPageID;
loadjs.ready("head", function() {

	// Form object
	currentPageID = ew.PAGE_ID = "list";
	fuserexternaltypeslist = currentForm = new ew.Form("fuserexternaltypeslist", "list");
	fuserexternaltypeslist.formKeyCountName = '<?php echo $userexternaltypes_list->FormKeyCountName ?>';
	loadjs.done("fuserexternaltypeslist");
});
var fuserexternaltypeslistsrch;
loadjs.ready("head", function() {

	// Form object for search
	fuserexternaltypeslistsrch = currentSearchForm = new ew.Form("fuserexternaltypeslistsrch");

	// Dynamic selection lists
	// Filters

	fuserexternaltypeslistsrch.filterList = <?php echo $userexternaltypes_list->getFilterList() ?>;

	// Init search panel as collapsed
	fuserexternaltypeslistsrch.initSearchPanel = true;
	loadjs.done("fuserexternaltypeslistsrch");
});
</script>
<style type="text/css">
.ew-table-preview-row { /* main table preview row color */
	background-color: #FFFFFF; /* preview row color */
}
.ew-table-preview-row .ew-grid {
	display: table;
}
</style>
<div id="ew-preview" class="d-none"><!-- preview -->
	<div class="ew-nav-tabs"><!-- .ew-nav-tabs -->
		<ul class="nav nav-tabs"></ul>
		<div class="tab-content"><!-- .tab-content -->
			<div class="tab-pane fade active show"></div>
		</div><!-- /.tab-content -->
	</div><!-- /.ew-nav-tabs -->
</div><!-- /preview -->
<script>
loadjs.ready("head", function() {
	ew.PREVIEW_PLACEMENT = ew.CSS_FLIP ? "right" : "left";
	ew.PREVIEW_SINGLE_ROW = false;
	ew.PREVIEW_OVERLAY = false;
	loadjs("js/ewpreview.js", "preview");
});
</script>
<script>
loadjs.ready("head", function() {

	// Client script
	// Write your client script here, no need to add script tags.

});
</script>
<?php } ?>
<?php if (!$userexternaltypes_list->isExport()) { ?>
<div class="btn-toolbar ew-toolbar">
<?php if ($userexternaltypes_list->TotalRecords > 0 && $userexternaltypes_list->ExportOptions->visible()) { ?>
<?php $userexternaltypes_list->ExportOptions->render("body") ?>
<?php } ?>
<?php if ($userexternaltypes_list->ImportOptions->visible()) { ?>
<?php $userexternaltypes_list->ImportOptions->render("body") ?>
<?php } ?>
<?php if ($userexternaltypes_list->SearchOptions->visible()) { ?>
<?php $userexternaltypes_list->SearchOptions->render("body") ?>
<?php } ?>
<?php if ($userexternaltypes_list->FilterOptions->visible()) { ?>
<?php $userexternaltypes_list->FilterOptions->render("body") ?>
<?php } ?>
<div class="clearfix"></div>
</div>
<?php } ?>
<?php
$userexternaltypes_list->renderOtherOptions();
?>
<?php if ($Security->CanSearch()) { ?>
<?php if (!$userexternaltypes_list->isExport() && !$userexternaltypes->CurrentAction) { ?>
<form name="fuserexternaltypeslistsrch" id="fuserexternaltypeslistsrch" class="form-inline ew-form ew-ext-search-form" action="<?php echo CurrentPageName() ?>">
<div id="fuserexternaltypeslistsrch-search-panel" class="<?php echo $userexternaltypes_list->SearchPanelClass ?>">
<input type="hidden" name="cmd" value="search">
<input type="hidden" name="t" value="userexternaltypes">
	<div class="ew-extended-search">
<div id="xsr_<?php echo $userexternaltypes_list->SearchRowCount + 1 ?>" class="ew-row d-sm-flex">
	<div class="ew-quick-search input-group">
		<input type="text" name="<?php echo Config("TABLE_BASIC_SEARCH") ?>" id="<?php echo Config("TABLE_BASIC_SEARCH") ?>" class="form-control" value="<?php echo HtmlEncode($userexternaltypes_list->BasicSearch->getKeyword()) ?>" placeholder="<?php echo HtmlEncode($Language->phrase("Search")) ?>">
		<input type="hidden" name="<?php echo Config("TABLE_BASIC_SEARCH_TYPE") ?>" id="<?php echo Config("TABLE_BASIC_SEARCH_TYPE") ?>" value="<?php echo HtmlEncode($userexternaltypes_list->BasicSearch->getType()) ?>">
		<div class="input-group-append">
			<button class="btn btn-primary" name="btn-submit" id="btn-submit" type="submit"><?php echo $Language->phrase("SearchBtn") ?></button>
			<button type="button" data-toggle="dropdown" class="btn btn-primary dropdown-toggle dropdown-toggle-split" aria-haspopup="true" aria-expanded="false"><span id="searchtype"><?php echo $userexternaltypes_list->BasicSearch->getTypeNameShort() ?></span></button>
			<div class="dropdown-menu dropdown-menu-right">
				<a class="dropdown-item<?php if ($userexternaltypes_list->BasicSearch->getType() == "") { ?> active<?php } ?>" href="#" onclick="return ew.setSearchType(this);"><?php echo $Language->phrase("QuickSearchAuto") ?></a>
				<a class="dropdown-item<?php if ($userexternaltypes_list->BasicSearch->getType() == "=") { ?> active<?php } ?>" href="#" onclick="return ew.setSearchType(this, '=');"><?php echo $Language->phrase("QuickSearchExact") ?></a>
				<a class="dropdown-item<?php if ($userexternaltypes_list->BasicSearch->getType() == "AND") { ?> active<?php } ?>" href="#" onclick="return ew.setSearchType(this, 'AND');"><?php echo $Language->phrase("QuickSearchAll") ?></a>
				<a class="dropdown-item<?php if ($userexternaltypes_list->BasicSearch->getType() == "OR") { ?> active<?php } ?>" href="#" onclick="return ew.setSearchType(this, 'OR');"><?php echo $Language->phrase("QuickSearchAny") ?></a>
			</div>
		</div>
	</div>
</div>
	</div><!-- /.ew-extended-search -->
</div><!-- /.ew-search-panel -->
</form>
<?php } ?>
<?php } ?>
<?php $userexternaltypes_list->showPageHeader(); ?>
<?php
$userexternaltypes_list->showMessage();
?>
<?php if ($userexternaltypes_list->TotalRecords > 0 || $userexternaltypes->CurrentAction) { ?>
<div class="card ew-card ew-grid<?php if ($userexternaltypes_list->isAddOrEdit()) { ?> ew-grid-add-edit<?php } ?> userexternaltypes">
<form name="fuserexternaltypeslist" id="fuserexternaltypeslist" class="form-inline ew-form ew-list-form" action="<?php echo CurrentPageName() ?>" method="post">
<?php if ($Page->CheckToken) { ?>
<input type="hidden" name="<?php echo Config("TOKEN_NAME") ?>" value="<?php echo $Page->Token ?>">
<?php } ?>
<input type="hidden" name="t" value="userexternaltypes">
<div id="gmp_userexternaltypes" class="<?php echo ResponsiveTableClass() ?>card-body ew-grid-middle-panel">
<?php if ($userexternaltypes_list->TotalRecords > 0 || $userexternaltypes_list->isGridEdit()) { ?>
<table id="tbl_userexternaltypeslist" class="table ew-table"><!-- .ew-table -->
<thead>
	<tr class="ew-table-header">
<?php

// Header row
$userexternaltypes->RowType = ROWTYPE_HEADER;

// Render list options
$userexternaltypes_list->renderListOptions();

// Render list options (header, left)
$userexternaltypes_list->ListOptions->render("header", "left");
?>
<?php if ($userexternaltypes_list->_userid->Visible) { // userid ?>
	<?php if ($userexternaltypes_list->SortUrl($userexternaltypes_list->_userid) == "") { ?>
		<th data-name="_userid" class="<?php echo $userexternaltypes_list->_userid->headerCellClass() ?>"><div id="elh_userexternaltypes__userid" class="userexternaltypes__userid"><div class="ew-table-header-caption"><?php echo $userexternaltypes_list->_userid->caption() ?></div></div></th>
	<?php } else { ?>
		<th data-name="_userid" class="<?php echo $userexternaltypes_list->_userid->headerCellClass() ?>"><div class="ew-pointer" onclick="ew.sort(event, '<?php echo $userexternaltypes_list->SortUrl($userexternaltypes_list->_userid) ?>', 1);"><div id="elh_userexternaltypes__userid" class="userexternaltypes__userid">
			<div class="ew-table-header-btn"><span class="ew-table-header-caption"><?php echo $userexternaltypes_list->_userid->caption() ?></span><span class="ew-table-header-sort"><?php if ($userexternaltypes_list->_userid->getSort() == "ASC") { ?><i class="fas fa-sort-up"></i><?php } elseif ($userexternaltypes_list->_userid->getSort() == "DESC") { ?><i class="fas fa-sort-down"></i><?php } ?></span></div>
		</div></div></th>
	<?php } ?>
<?php } ?>
<?php if ($userexternaltypes_list->usertype->Visible) { // usertype ?>
	<?php if ($userexternaltypes_list->SortUrl($userexternaltypes_list->usertype) == "") { ?>
		<th data-name="usertype" class="<?php echo $userexternaltypes_list->usertype->headerCellClass() ?>"><div id="elh_userexternaltypes_usertype" class="userexternaltypes_usertype"><div class="ew-table-header-caption"><?php echo $userexternaltypes_list->usertype->caption() ?></div></div></th>
	<?php } else { ?>
		<th data-name="usertype" class="<?php echo $userexternaltypes_list->usertype->headerCellClass() ?>"><div class="ew-pointer" onclick="ew.sort(event, '<?php echo $userexternaltypes_list->SortUrl($userexternaltypes_list->usertype) ?>', 1);"><div id="elh_userexternaltypes_usertype" class="userexternaltypes_usertype">
			<div class="ew-table-header-btn"><span class="ew-table-header-caption"><?php echo $userexternaltypes_list->usertype->caption() ?><?php echo $Language->phrase("SrchLegend") ?></span><span class="ew-table-header-sort"><?php if ($userexternaltypes_list->usertype->getSort() == "ASC") { ?><i class="fas fa-sort-up"></i><?php } elseif ($userexternaltypes_list->usertype->getSort() == "DESC") { ?><i class="fas fa-sort-down"></i><?php } ?></span></div>
		</div></div></th>
	<?php } ?>
<?php } ?>
<?php

// Render list options (header, right)
$userexternaltypes_list->ListOptions->render("header", "right");
?>
	</tr>
</thead>
<tbody>
<?php
if ($userexternaltypes_list->ExportAll && $userexternaltypes_list->isExport()) {
	$userexternaltypes_list->StopRecord = $userexternaltypes_list->TotalRecords;
} else {

	// Set the last record to display
	if ($userexternaltypes_list->TotalRecords > $userexternaltypes_list->StartRecord + $userexternaltypes_list->DisplayRecords - 1)
		$userexternaltypes_list->StopRecord = $userexternaltypes_list->StartRecord + $userexternaltypes_list->DisplayRecords - 1;
	else
		$userexternaltypes_list->StopRecord = $userexternaltypes_list->TotalRecords;
}
$userexternaltypes_list->RecordCount = $userexternaltypes_list->StartRecord - 1;
if ($userexternaltypes_list->Recordset && !$userexternaltypes_list->Recordset->EOF) {
	$userexternaltypes_list->Recordset->moveFirst();
	$selectLimit = $userexternaltypes_list->UseSelectLimit;
	if (!$selectLimit && $userexternaltypes_list->StartRecord > 1)
		$userexternaltypes_list->Recordset->move($userexternaltypes_list->StartRecord - 1);
} elseif (!$userexternaltypes->AllowAddDeleteRow && $userexternaltypes_list->StopRecord == 0) {
	$userexternaltypes_list->StopRecord = $userexternaltypes->GridAddRowCount;
}

// Initialize aggregate
$userexternaltypes->RowType = ROWTYPE_AGGREGATEINIT;
$userexternaltypes->resetAttributes();
$userexternaltypes_list->renderRow();
while ($userexternaltypes_list->RecordCount < $userexternaltypes_list->StopRecord) {
	$userexternaltypes_list->RecordCount++;
	if ($userexternaltypes_list->RecordCount >= $userexternaltypes_list->StartRecord) {
		$userexternaltypes_list->RowCount++;

		// Set up key count
		$userexternaltypes_list->KeyCount = $userexternaltypes_list->RowIndex;

		// Init row class and style
		$userexternaltypes->resetAttributes();
		$userexternaltypes->CssClass = "";
		if ($userexternaltypes_list->isGridAdd()) {
		} else {
			$userexternaltypes_list->loadRowValues($userexternaltypes_list->Recordset); // Load row values
		}
		$userexternaltypes->RowType = ROWTYPE_VIEW; // Render view

		// Set up row id / data-rowindex
		$userexternaltypes->RowAttrs->merge(["data-rowindex" => $userexternaltypes_list->RowCount, "id" => "r" . $userexternaltypes_list->RowCount . "_userexternaltypes", "data-rowtype" => $userexternaltypes->RowType]);

		// Render row
		$userexternaltypes_list->renderRow();

		// Render list options
		$userexternaltypes_list->renderListOptions();
?>
	<tr <?php echo $userexternaltypes->rowAttributes() ?>>
<?php

// Render list options (body, left)
$userexternaltypes_list->ListOptions->render("body", "left", $userexternaltypes_list->RowCount);
?>
	<?php if ($userexternaltypes_list->_userid->Visible) { // userid ?>
		<td data-name="_userid" <?php echo $userexternaltypes_list->_userid->cellAttributes() ?>>
<span id="el<?php echo $userexternaltypes_list->RowCount ?>_userexternaltypes__userid">
<span<?php echo $userexternaltypes_list->_userid->viewAttributes() ?>><?php echo $userexternaltypes_list->_userid->getViewValue() ?></span>
</span>
</td>
	<?php } ?>
	<?php if ($userexternaltypes_list->usertype->Visible) { // usertype ?>
		<td data-name="usertype" <?php echo $userexternaltypes_list->usertype->cellAttributes() ?>>
<span id="el<?php echo $userexternaltypes_list->RowCount ?>_userexternaltypes_usertype">
<span<?php echo $userexternaltypes_list->usertype->viewAttributes() ?>><?php echo $userexternaltypes_list->usertype->getViewValue() ?></span>
</span>
</td>
	<?php } ?>
<?php

// Render list options (body, right)
$userexternaltypes_list->ListOptions->render("body", "right", $userexternaltypes_list->RowCount);
?>
	</tr>
<?php
	}
	if (!$userexternaltypes_list->isGridAdd())
		$userexternaltypes_list->Recordset->moveNext();
}
?>
</tbody>
</table><!-- /.ew-table -->
<?php } ?>
</div><!-- /.ew-grid-middle-panel -->
<?php if (!$userexternaltypes->CurrentAction) { ?>
<input type="hidden" name="action" id="action" value="">
<?php } ?>
</form><!-- /.ew-list-form -->
<?php

// Close recordset
if ($userexternaltypes_list->Recordset)
	$userexternaltypes_list->Recordset->Close();
?>
<?php if (!$userexternaltypes_list->isExport()) { ?>
<div class="card-footer ew-grid-lower-panel">
<?php if (!$userexternaltypes_list->isGridAdd()) { ?>
<form name="ew-pager-form" class="form-inline ew-form ew-pager-form" action="<?php echo CurrentPageName() ?>">
<?php echo $userexternaltypes_list->Pager->render() ?>
</form>
<?php } ?>
<div class="ew-list-other-options">
<?php $userexternaltypes_list->OtherOptions->render("body", "bottom") ?>
</div>
<div class="clearfix"></div>
</div>
<?php } ?>
</div><!-- /.ew-grid -->
<?php } ?>
<?php if ($userexternaltypes_list->TotalRecords == 0 && !$userexternaltypes->CurrentAction) { // Show other options ?>
<div class="ew-list-other-options">
<?php $userexternaltypes_list->OtherOptions->render("body") ?>
</div>
<div class="clearfix"></div>
<?php } ?>
<?php
$userexternaltypes_list->showPageFooter();
if (Config("DEBUG"))
	echo GetDebugMessage();
?>
<?php if (!$userexternaltypes_list->isExport()) { ?>
<script>
loadjs.ready("load", function() {

	// Startup script
	// Write your table-specific startup script here
	// console.log("page loaded");

});
</script>
<?php } ?>
<?php include_once "footer.php"; ?>
<?php
$userexternaltypes_list->terminate();
?>