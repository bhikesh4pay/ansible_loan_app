<?php
namespace PHPMaker2020\_4payadmin;

// Autoload
include_once "autoload.php";

// Session
if (session_status() !== PHP_SESSION_ACTIVE)
	\Delight\Cookie\Session::start(Config("COOKIE_SAMESITE")); // Init session data

// Output buffering
ob_start();
?>
<?php

// Write header
WriteHeader(FALSE);

// Create page object
$programmerchantfunds_search = new programmerchantfunds_search();

// Run the page
$programmerchantfunds_search->run();

// Setup login status
SetupLoginStatus();
SetClientVar("login", LoginStatus());

// Global Page Rendering event (in userfn*.php)
Page_Rendering();

// Page Rendering event
$programmerchantfunds_search->Page_Render();
?>
<?php include_once "header.php"; ?>
<script>
var fprogrammerchantfundssearch, currentPageID;
loadjs.ready("head", function() {

	// Form object for search
	<?php if ($programmerchantfunds_search->IsModal) { ?>
	fprogrammerchantfundssearch = currentAdvancedSearchForm = new ew.Form("fprogrammerchantfundssearch", "search");
	<?php } else { ?>
	fprogrammerchantfundssearch = currentForm = new ew.Form("fprogrammerchantfundssearch", "search");
	<?php } ?>
	currentPageID = ew.PAGE_ID = "search";

	// Validate function for search
	fprogrammerchantfundssearch.validate = function(fobj) {
		if (!this.validateRequired)
			return true; // Ignore validation
		fobj = fobj || this._form;
		var infix = "";
		elm = this.getElements("x" + infix + "_requestid");
		if (elm && !ew.checkInteger(elm.value))
			return this.onError(elm, "<?php echo JsEncode($programmerchantfunds_search->requestid->errorMessage()) ?>");
		elm = this.getElements("x" + infix + "__userid");
		if (elm && !ew.checkInteger(elm.value))
			return this.onError(elm, "<?php echo JsEncode($programmerchantfunds_search->_userid->errorMessage()) ?>");
		elm = this.getElements("x" + infix + "_userpi");
		if (elm && !ew.checkInteger(elm.value))
			return this.onError(elm, "<?php echo JsEncode($programmerchantfunds_search->userpi->errorMessage()) ?>");
		elm = this.getElements("x" + infix + "_programid");
		if (elm && !ew.checkInteger(elm.value))
			return this.onError(elm, "<?php echo JsEncode($programmerchantfunds_search->programid->errorMessage()) ?>");
		elm = this.getElements("x" + infix + "_amount");
		if (elm && !ew.checkNumber(elm.value))
			return this.onError(elm, "<?php echo JsEncode($programmerchantfunds_search->amount->errorMessage()) ?>");
		elm = this.getElements("x" + infix + "__action");
		if (elm && !ew.checkInteger(elm.value))
			return this.onError(elm, "<?php echo JsEncode($programmerchantfunds_search->_action->errorMessage()) ?>");
		elm = this.getElements("x" + infix + "_status");
		if (elm && !ew.checkInteger(elm.value))
			return this.onError(elm, "<?php echo JsEncode($programmerchantfunds_search->status->errorMessage()) ?>");
		elm = this.getElements("x" + infix + "_submittiondate");
		if (elm && !ew.checkDateDef(elm.value))
			return this.onError(elm, "<?php echo JsEncode($programmerchantfunds_search->submittiondate->errorMessage()) ?>");
		elm = this.getElements("x" + infix + "_completiondate");
		if (elm && !ew.checkDateDef(elm.value))
			return this.onError(elm, "<?php echo JsEncode($programmerchantfunds_search->completiondate->errorMessage()) ?>");
		elm = this.getElements("x" + infix + "_eftid");
		if (elm && !ew.checkInteger(elm.value))
			return this.onError(elm, "<?php echo JsEncode($programmerchantfunds_search->eftid->errorMessage()) ?>");
		elm = this.getElements("x" + infix + "_gltransid");
		if (elm && !ew.checkInteger(elm.value))
			return this.onError(elm, "<?php echo JsEncode($programmerchantfunds_search->gltransid->errorMessage()) ?>");
		elm = this.getElements("x" + infix + "_feeamount");
		if (elm && !ew.checkNumber(elm.value))
			return this.onError(elm, "<?php echo JsEncode($programmerchantfunds_search->feeamount->errorMessage()) ?>");

		// Call Form_CustomValidate event
		if (!this.Form_CustomValidate(fobj))
			return false;
		return true;
	}

	// Form_CustomValidate
	fprogrammerchantfundssearch.Form_CustomValidate = function(fobj) { // DO NOT CHANGE THIS LINE!

		// Your custom validation code here, return false if invalid.
		return true;
	}

	// Use JavaScript validation or not
	fprogrammerchantfundssearch.validateRequired = <?php echo Config("CLIENT_VALIDATE") ? "true" : "false" ?>;

	// Dynamic selection lists
	loadjs.done("fprogrammerchantfundssearch");
});
</script>
<script>
loadjs.ready("head", function() {

	// Client script
	// Write your client script here, no need to add script tags.

});
</script>
<?php $programmerchantfunds_search->showPageHeader(); ?>
<?php
$programmerchantfunds_search->showMessage();
?>
<form name="fprogrammerchantfundssearch" id="fprogrammerchantfundssearch" class="<?php echo $programmerchantfunds_search->FormClassName ?>" action="<?php echo CurrentPageName() ?>" method="post">
<?php if ($Page->CheckToken) { ?>
<input type="hidden" name="<?php echo Config("TOKEN_NAME") ?>" value="<?php echo $Page->Token ?>">
<?php } ?>
<input type="hidden" name="t" value="programmerchantfunds">
<input type="hidden" name="action" id="action" value="search">
<input type="hidden" name="modal" value="<?php echo (int)$programmerchantfunds_search->IsModal ?>">
<div class="ew-search-div"><!-- page* -->
<?php if ($programmerchantfunds_search->requestid->Visible) { // requestid ?>
	<div id="r_requestid" class="form-group row">
		<label for="x_requestid" class="<?php echo $programmerchantfunds_search->LeftColumnClass ?>"><span id="elh_programmerchantfunds_requestid"><?php echo $programmerchantfunds_search->requestid->caption() ?></span>
		<span class="ew-search-operator">
<?php echo $Language->phrase("=") ?>
<input type="hidden" name="z_requestid" id="z_requestid" value="=">
</span>
		</label>
		<div class="<?php echo $programmerchantfunds_search->RightColumnClass ?>"><div <?php echo $programmerchantfunds_search->requestid->cellAttributes() ?>>
			<span id="el_programmerchantfunds_requestid" class="ew-search-field">
<input type="text" data-table="programmerchantfunds" data-field="x_requestid" name="x_requestid" id="x_requestid" maxlength="12" placeholder="<?php echo HtmlEncode($programmerchantfunds_search->requestid->getPlaceHolder()) ?>" value="<?php echo $programmerchantfunds_search->requestid->EditValue ?>"<?php echo $programmerchantfunds_search->requestid->editAttributes() ?>>
</span>
		</div></div>
	</div>
<?php } ?>
<?php if ($programmerchantfunds_search->_userid->Visible) { // userid ?>
	<div id="r__userid" class="form-group row">
		<label for="x__userid" class="<?php echo $programmerchantfunds_search->LeftColumnClass ?>"><span id="elh_programmerchantfunds__userid"><?php echo $programmerchantfunds_search->_userid->caption() ?></span>
		<span class="ew-search-operator">
<?php echo $Language->phrase("=") ?>
<input type="hidden" name="z__userid" id="z__userid" value="=">
</span>
		</label>
		<div class="<?php echo $programmerchantfunds_search->RightColumnClass ?>"><div <?php echo $programmerchantfunds_search->_userid->cellAttributes() ?>>
			<span id="el_programmerchantfunds__userid" class="ew-search-field">
<input type="text" data-table="programmerchantfunds" data-field="x__userid" name="x__userid" id="x__userid" size="30" maxlength="12" placeholder="<?php echo HtmlEncode($programmerchantfunds_search->_userid->getPlaceHolder()) ?>" value="<?php echo $programmerchantfunds_search->_userid->EditValue ?>"<?php echo $programmerchantfunds_search->_userid->editAttributes() ?>>
</span>
		</div></div>
	</div>
<?php } ?>
<?php if ($programmerchantfunds_search->userpi->Visible) { // userpi ?>
	<div id="r_userpi" class="form-group row">
		<label for="x_userpi" class="<?php echo $programmerchantfunds_search->LeftColumnClass ?>"><span id="elh_programmerchantfunds_userpi"><?php echo $programmerchantfunds_search->userpi->caption() ?></span>
		<span class="ew-search-operator">
<?php echo $Language->phrase("=") ?>
<input type="hidden" name="z_userpi" id="z_userpi" value="=">
</span>
		</label>
		<div class="<?php echo $programmerchantfunds_search->RightColumnClass ?>"><div <?php echo $programmerchantfunds_search->userpi->cellAttributes() ?>>
			<span id="el_programmerchantfunds_userpi" class="ew-search-field">
<input type="text" data-table="programmerchantfunds" data-field="x_userpi" name="x_userpi" id="x_userpi" size="30" maxlength="12" placeholder="<?php echo HtmlEncode($programmerchantfunds_search->userpi->getPlaceHolder()) ?>" value="<?php echo $programmerchantfunds_search->userpi->EditValue ?>"<?php echo $programmerchantfunds_search->userpi->editAttributes() ?>>
</span>
		</div></div>
	</div>
<?php } ?>
<?php if ($programmerchantfunds_search->programid->Visible) { // programid ?>
	<div id="r_programid" class="form-group row">
		<label for="x_programid" class="<?php echo $programmerchantfunds_search->LeftColumnClass ?>"><span id="elh_programmerchantfunds_programid"><?php echo $programmerchantfunds_search->programid->caption() ?></span>
		<span class="ew-search-operator">
<?php echo $Language->phrase("=") ?>
<input type="hidden" name="z_programid" id="z_programid" value="=">
</span>
		</label>
		<div class="<?php echo $programmerchantfunds_search->RightColumnClass ?>"><div <?php echo $programmerchantfunds_search->programid->cellAttributes() ?>>
			<span id="el_programmerchantfunds_programid" class="ew-search-field">
<input type="text" data-table="programmerchantfunds" data-field="x_programid" name="x_programid" id="x_programid" size="30" maxlength="6" placeholder="<?php echo HtmlEncode($programmerchantfunds_search->programid->getPlaceHolder()) ?>" value="<?php echo $programmerchantfunds_search->programid->EditValue ?>"<?php echo $programmerchantfunds_search->programid->editAttributes() ?>>
</span>
		</div></div>
	</div>
<?php } ?>
<?php if ($programmerchantfunds_search->currcode->Visible) { // currcode ?>
	<div id="r_currcode" class="form-group row">
		<label for="x_currcode" class="<?php echo $programmerchantfunds_search->LeftColumnClass ?>"><span id="elh_programmerchantfunds_currcode"><?php echo $programmerchantfunds_search->currcode->caption() ?></span>
		<span class="ew-search-operator">
<?php echo $Language->phrase("LIKE") ?>
<input type="hidden" name="z_currcode" id="z_currcode" value="LIKE">
</span>
		</label>
		<div class="<?php echo $programmerchantfunds_search->RightColumnClass ?>"><div <?php echo $programmerchantfunds_search->currcode->cellAttributes() ?>>
			<span id="el_programmerchantfunds_currcode" class="ew-search-field">
<input type="text" data-table="programmerchantfunds" data-field="x_currcode" name="x_currcode" id="x_currcode" size="30" maxlength="3" placeholder="<?php echo HtmlEncode($programmerchantfunds_search->currcode->getPlaceHolder()) ?>" value="<?php echo $programmerchantfunds_search->currcode->EditValue ?>"<?php echo $programmerchantfunds_search->currcode->editAttributes() ?>>
</span>
		</div></div>
	</div>
<?php } ?>
<?php if ($programmerchantfunds_search->amount->Visible) { // amount ?>
	<div id="r_amount" class="form-group row">
		<label for="x_amount" class="<?php echo $programmerchantfunds_search->LeftColumnClass ?>"><span id="elh_programmerchantfunds_amount"><?php echo $programmerchantfunds_search->amount->caption() ?></span>
		<span class="ew-search-operator">
<?php echo $Language->phrase("=") ?>
<input type="hidden" name="z_amount" id="z_amount" value="=">
</span>
		</label>
		<div class="<?php echo $programmerchantfunds_search->RightColumnClass ?>"><div <?php echo $programmerchantfunds_search->amount->cellAttributes() ?>>
			<span id="el_programmerchantfunds_amount" class="ew-search-field">
<input type="text" data-table="programmerchantfunds" data-field="x_amount" name="x_amount" id="x_amount" size="30" maxlength="12" placeholder="<?php echo HtmlEncode($programmerchantfunds_search->amount->getPlaceHolder()) ?>" value="<?php echo $programmerchantfunds_search->amount->EditValue ?>"<?php echo $programmerchantfunds_search->amount->editAttributes() ?>>
</span>
		</div></div>
	</div>
<?php } ?>
<?php if ($programmerchantfunds_search->_action->Visible) { // action ?>
	<div id="r__action" class="form-group row">
		<label for="x__action" class="<?php echo $programmerchantfunds_search->LeftColumnClass ?>"><span id="elh_programmerchantfunds__action"><?php echo $programmerchantfunds_search->_action->caption() ?></span>
		<span class="ew-search-operator">
<?php echo $Language->phrase("=") ?>
<input type="hidden" name="z__action" id="z__action" value="=">
</span>
		</label>
		<div class="<?php echo $programmerchantfunds_search->RightColumnClass ?>"><div <?php echo $programmerchantfunds_search->_action->cellAttributes() ?>>
			<span id="el_programmerchantfunds__action" class="ew-search-field">
<input type="text" data-table="programmerchantfunds" data-field="x__action" name="x__action" id="x__action" size="30" maxlength="1" placeholder="<?php echo HtmlEncode($programmerchantfunds_search->_action->getPlaceHolder()) ?>" value="<?php echo $programmerchantfunds_search->_action->EditValue ?>"<?php echo $programmerchantfunds_search->_action->editAttributes() ?>>
</span>
		</div></div>
	</div>
<?php } ?>
<?php if ($programmerchantfunds_search->status->Visible) { // status ?>
	<div id="r_status" class="form-group row">
		<label for="x_status" class="<?php echo $programmerchantfunds_search->LeftColumnClass ?>"><span id="elh_programmerchantfunds_status"><?php echo $programmerchantfunds_search->status->caption() ?></span>
		<span class="ew-search-operator">
<?php echo $Language->phrase("=") ?>
<input type="hidden" name="z_status" id="z_status" value="=">
</span>
		</label>
		<div class="<?php echo $programmerchantfunds_search->RightColumnClass ?>"><div <?php echo $programmerchantfunds_search->status->cellAttributes() ?>>
			<span id="el_programmerchantfunds_status" class="ew-search-field">
<input type="text" data-table="programmerchantfunds" data-field="x_status" name="x_status" id="x_status" size="30" maxlength="1" placeholder="<?php echo HtmlEncode($programmerchantfunds_search->status->getPlaceHolder()) ?>" value="<?php echo $programmerchantfunds_search->status->EditValue ?>"<?php echo $programmerchantfunds_search->status->editAttributes() ?>>
</span>
		</div></div>
	</div>
<?php } ?>
<?php if ($programmerchantfunds_search->submittiondate->Visible) { // submittiondate ?>
	<div id="r_submittiondate" class="form-group row">
		<label for="x_submittiondate" class="<?php echo $programmerchantfunds_search->LeftColumnClass ?>"><span id="elh_programmerchantfunds_submittiondate"><?php echo $programmerchantfunds_search->submittiondate->caption() ?></span>
		<span class="ew-search-operator">
<?php echo $Language->phrase("=") ?>
<input type="hidden" name="z_submittiondate" id="z_submittiondate" value="=">
</span>
		</label>
		<div class="<?php echo $programmerchantfunds_search->RightColumnClass ?>"><div <?php echo $programmerchantfunds_search->submittiondate->cellAttributes() ?>>
			<span id="el_programmerchantfunds_submittiondate" class="ew-search-field">
<input type="text" data-table="programmerchantfunds" data-field="x_submittiondate" name="x_submittiondate" id="x_submittiondate" maxlength="19" placeholder="<?php echo HtmlEncode($programmerchantfunds_search->submittiondate->getPlaceHolder()) ?>" value="<?php echo $programmerchantfunds_search->submittiondate->EditValue ?>"<?php echo $programmerchantfunds_search->submittiondate->editAttributes() ?>>
<?php if (!$programmerchantfunds_search->submittiondate->ReadOnly && !$programmerchantfunds_search->submittiondate->Disabled && !isset($programmerchantfunds_search->submittiondate->EditAttrs["readonly"]) && !isset($programmerchantfunds_search->submittiondate->EditAttrs["disabled"])) { ?>
<script>
loadjs.ready(["fprogrammerchantfundssearch", "datetimepicker"], function() {
	ew.createDateTimePicker("fprogrammerchantfundssearch", "x_submittiondate", {"ignoreReadonly":true,"useCurrent":false,"format":0});
});
</script>
<?php } ?>
</span>
		</div></div>
	</div>
<?php } ?>
<?php if ($programmerchantfunds_search->completiondate->Visible) { // completiondate ?>
	<div id="r_completiondate" class="form-group row">
		<label for="x_completiondate" class="<?php echo $programmerchantfunds_search->LeftColumnClass ?>"><span id="elh_programmerchantfunds_completiondate"><?php echo $programmerchantfunds_search->completiondate->caption() ?></span>
		<span class="ew-search-operator">
<?php echo $Language->phrase("=") ?>
<input type="hidden" name="z_completiondate" id="z_completiondate" value="=">
</span>
		</label>
		<div class="<?php echo $programmerchantfunds_search->RightColumnClass ?>"><div <?php echo $programmerchantfunds_search->completiondate->cellAttributes() ?>>
			<span id="el_programmerchantfunds_completiondate" class="ew-search-field">
<input type="text" data-table="programmerchantfunds" data-field="x_completiondate" name="x_completiondate" id="x_completiondate" maxlength="19" placeholder="<?php echo HtmlEncode($programmerchantfunds_search->completiondate->getPlaceHolder()) ?>" value="<?php echo $programmerchantfunds_search->completiondate->EditValue ?>"<?php echo $programmerchantfunds_search->completiondate->editAttributes() ?>>
<?php if (!$programmerchantfunds_search->completiondate->ReadOnly && !$programmerchantfunds_search->completiondate->Disabled && !isset($programmerchantfunds_search->completiondate->EditAttrs["readonly"]) && !isset($programmerchantfunds_search->completiondate->EditAttrs["disabled"])) { ?>
<script>
loadjs.ready(["fprogrammerchantfundssearch", "datetimepicker"], function() {
	ew.createDateTimePicker("fprogrammerchantfundssearch", "x_completiondate", {"ignoreReadonly":true,"useCurrent":false,"format":0});
});
</script>
<?php } ?>
</span>
		</div></div>
	</div>
<?php } ?>
<?php if ($programmerchantfunds_search->eftid->Visible) { // eftid ?>
	<div id="r_eftid" class="form-group row">
		<label for="x_eftid" class="<?php echo $programmerchantfunds_search->LeftColumnClass ?>"><span id="elh_programmerchantfunds_eftid"><?php echo $programmerchantfunds_search->eftid->caption() ?></span>
		<span class="ew-search-operator">
<?php echo $Language->phrase("=") ?>
<input type="hidden" name="z_eftid" id="z_eftid" value="=">
</span>
		</label>
		<div class="<?php echo $programmerchantfunds_search->RightColumnClass ?>"><div <?php echo $programmerchantfunds_search->eftid->cellAttributes() ?>>
			<span id="el_programmerchantfunds_eftid" class="ew-search-field">
<input type="text" data-table="programmerchantfunds" data-field="x_eftid" name="x_eftid" id="x_eftid" size="30" maxlength="8" placeholder="<?php echo HtmlEncode($programmerchantfunds_search->eftid->getPlaceHolder()) ?>" value="<?php echo $programmerchantfunds_search->eftid->EditValue ?>"<?php echo $programmerchantfunds_search->eftid->editAttributes() ?>>
</span>
		</div></div>
	</div>
<?php } ?>
<?php if ($programmerchantfunds_search->gltransid->Visible) { // gltransid ?>
	<div id="r_gltransid" class="form-group row">
		<label for="x_gltransid" class="<?php echo $programmerchantfunds_search->LeftColumnClass ?>"><span id="elh_programmerchantfunds_gltransid"><?php echo $programmerchantfunds_search->gltransid->caption() ?></span>
		<span class="ew-search-operator">
<?php echo $Language->phrase("=") ?>
<input type="hidden" name="z_gltransid" id="z_gltransid" value="=">
</span>
		</label>
		<div class="<?php echo $programmerchantfunds_search->RightColumnClass ?>"><div <?php echo $programmerchantfunds_search->gltransid->cellAttributes() ?>>
			<span id="el_programmerchantfunds_gltransid" class="ew-search-field">
<input type="text" data-table="programmerchantfunds" data-field="x_gltransid" name="x_gltransid" id="x_gltransid" size="30" maxlength="12" placeholder="<?php echo HtmlEncode($programmerchantfunds_search->gltransid->getPlaceHolder()) ?>" value="<?php echo $programmerchantfunds_search->gltransid->EditValue ?>"<?php echo $programmerchantfunds_search->gltransid->editAttributes() ?>>
</span>
		</div></div>
	</div>
<?php } ?>
<?php if ($programmerchantfunds_search->feeamount->Visible) { // feeamount ?>
	<div id="r_feeamount" class="form-group row">
		<label for="x_feeamount" class="<?php echo $programmerchantfunds_search->LeftColumnClass ?>"><span id="elh_programmerchantfunds_feeamount"><?php echo $programmerchantfunds_search->feeamount->caption() ?></span>
		<span class="ew-search-operator">
<?php echo $Language->phrase("=") ?>
<input type="hidden" name="z_feeamount" id="z_feeamount" value="=">
</span>
		</label>
		<div class="<?php echo $programmerchantfunds_search->RightColumnClass ?>"><div <?php echo $programmerchantfunds_search->feeamount->cellAttributes() ?>>
			<span id="el_programmerchantfunds_feeamount" class="ew-search-field">
<input type="text" data-table="programmerchantfunds" data-field="x_feeamount" name="x_feeamount" id="x_feeamount" size="30" maxlength="12" placeholder="<?php echo HtmlEncode($programmerchantfunds_search->feeamount->getPlaceHolder()) ?>" value="<?php echo $programmerchantfunds_search->feeamount->EditValue ?>"<?php echo $programmerchantfunds_search->feeamount->editAttributes() ?>>
</span>
		</div></div>
	</div>
<?php } ?>
</div><!-- /page* -->
<?php if (!$programmerchantfunds_search->IsModal) { ?>
<div class="form-group row"><!-- buttons .form-group -->
	<div class="<?php echo $programmerchantfunds_search->OffsetColumnClass ?>"><!-- buttons offset -->
<button class="btn btn-primary ew-btn" name="btn-action" id="btn-action" type="submit"><?php echo $Language->phrase("Search") ?></button>
<button class="btn btn-default ew-btn" name="btn-reset" id="btn-reset" type="button" onclick="ew.clearForm(this.form);"><?php echo $Language->phrase("Reset") ?></button>
	</div><!-- /buttons offset -->
</div><!-- /buttons .form-group -->
<?php } ?>
</form>
<?php
$programmerchantfunds_search->showPageFooter();
if (Config("DEBUG"))
	echo GetDebugMessage();
?>
<script>
loadjs.ready("load", function() {

	// Startup script
	// Write your table-specific startup script here
	// console.log("page loaded");

});
</script>
<?php include_once "footer.php"; ?>
<?php
$programmerchantfunds_search->terminate();
?>