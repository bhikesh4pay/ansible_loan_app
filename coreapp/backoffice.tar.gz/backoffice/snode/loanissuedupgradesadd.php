<?php
namespace PHPMaker2020\_4payadmin;

// Autoload
include_once "autoload.php";

// Session
if (session_status() !== PHP_SESSION_ACTIVE)
	\Delight\Cookie\Session::start(Config("COOKIE_SAMESITE")); // Init session data

// Output buffering
ob_start();
?>
<?php

// Write header
WriteHeader(FALSE);

// Create page object
$loanissuedupgrades_add = new loanissuedupgrades_add();

// Run the page
$loanissuedupgrades_add->run();

// Setup login status
SetupLoginStatus();
SetClientVar("login", LoginStatus());

// Global Page Rendering event (in userfn*.php)
Page_Rendering();

// Page Rendering event
$loanissuedupgrades_add->Page_Render();
?>
<?php include_once "header.php"; ?>
<script>
var floanissuedupgradesadd, currentPageID;
loadjs.ready("head", function() {

	// Form object
	currentPageID = ew.PAGE_ID = "add";
	floanissuedupgradesadd = currentForm = new ew.Form("floanissuedupgradesadd", "add");

	// Validate form
	floanissuedupgradesadd.validate = function() {
		if (!this.validateRequired)
			return true; // Ignore validation
		var $ = jQuery, fobj = this.getForm(), $fobj = $(fobj);
		if ($fobj.find("#confirm").val() == "confirm")
			return true;
		var elm, felm, uelm, addcnt = 0;
		var $k = $fobj.find("#" + this.formKeyCountName); // Get key_count
		var rowcnt = ($k[0]) ? parseInt($k.val(), 10) : 1;
		var startcnt = (rowcnt == 0) ? 0 : 1; // Check rowcnt == 0 => Inline-Add
		var gridinsert = ["insert", "gridinsert"].includes($fobj.find("#action").val()) && $k[0];
		for (var i = startcnt; i <= rowcnt; i++) {
			var infix = ($k[0]) ? String(i) : "";
			$fobj.data("rowindex", infix);
			<?php if ($loanissuedupgrades_add->loanid->Required) { ?>
				elm = this.getElements("x" + infix + "_loanid");
				if (elm && !ew.isHidden(elm) && !ew.hasValue(elm))
					return this.onError(elm, "<?php echo JsEncode(str_replace("%s", $loanissuedupgrades_add->loanid->caption(), $loanissuedupgrades_add->loanid->RequiredErrorMessage)) ?>");
			<?php } ?>
				elm = this.getElements("x" + infix + "_loanid");
				if (elm && !ew.checkInteger(elm.value))
					return this.onError(elm, "<?php echo JsEncode($loanissuedupgrades_add->loanid->errorMessage()) ?>");
			<?php if ($loanissuedupgrades_add->fromloantype->Required) { ?>
				elm = this.getElements("x" + infix + "_fromloantype");
				if (elm && !ew.isHidden(elm) && !ew.hasValue(elm))
					return this.onError(elm, "<?php echo JsEncode(str_replace("%s", $loanissuedupgrades_add->fromloantype->caption(), $loanissuedupgrades_add->fromloantype->RequiredErrorMessage)) ?>");
			<?php } ?>
			<?php if ($loanissuedupgrades_add->toloantype->Required) { ?>
				elm = this.getElements("x" + infix + "_toloantype");
				if (elm && !ew.isHidden(elm) && !ew.hasValue(elm))
					return this.onError(elm, "<?php echo JsEncode(str_replace("%s", $loanissuedupgrades_add->toloantype->caption(), $loanissuedupgrades_add->toloantype->RequiredErrorMessage)) ?>");
			<?php } ?>
			<?php if ($loanissuedupgrades_add->upgradedate->Required) { ?>
				elm = this.getElements("x" + infix + "_upgradedate");
				if (elm && !ew.isHidden(elm) && !ew.hasValue(elm))
					return this.onError(elm, "<?php echo JsEncode(str_replace("%s", $loanissuedupgrades_add->upgradedate->caption(), $loanissuedupgrades_add->upgradedate->RequiredErrorMessage)) ?>");
			<?php } ?>
				elm = this.getElements("x" + infix + "_upgradedate");
				if (elm && !ew.checkDateDef(elm.value))
					return this.onError(elm, "<?php echo JsEncode($loanissuedupgrades_add->upgradedate->errorMessage()) ?>");
			<?php if ($loanissuedupgrades_add->fromduedate->Required) { ?>
				elm = this.getElements("x" + infix + "_fromduedate");
				if (elm && !ew.isHidden(elm) && !ew.hasValue(elm))
					return this.onError(elm, "<?php echo JsEncode(str_replace("%s", $loanissuedupgrades_add->fromduedate->caption(), $loanissuedupgrades_add->fromduedate->RequiredErrorMessage)) ?>");
			<?php } ?>
				elm = this.getElements("x" + infix + "_fromduedate");
				if (elm && !ew.checkDateDef(elm.value))
					return this.onError(elm, "<?php echo JsEncode($loanissuedupgrades_add->fromduedate->errorMessage()) ?>");
			<?php if ($loanissuedupgrades_add->toduedate->Required) { ?>
				elm = this.getElements("x" + infix + "_toduedate");
				if (elm && !ew.isHidden(elm) && !ew.hasValue(elm))
					return this.onError(elm, "<?php echo JsEncode(str_replace("%s", $loanissuedupgrades_add->toduedate->caption(), $loanissuedupgrades_add->toduedate->RequiredErrorMessage)) ?>");
			<?php } ?>
				elm = this.getElements("x" + infix + "_toduedate");
				if (elm && !ew.checkDateDef(elm.value))
					return this.onError(elm, "<?php echo JsEncode($loanissuedupgrades_add->toduedate->errorMessage()) ?>");

				// Call Form_CustomValidate event
				if (!this.Form_CustomValidate(fobj))
					return false;
		}

		// Process detail forms
		var dfs = $fobj.find("input[name='detailpage']").get();
		for (var i = 0; i < dfs.length; i++) {
			var df = dfs[i], val = df.value;
			if (val && ew.forms[val])
				if (!ew.forms[val].validate())
					return false;
		}
		return true;
	}

	// Form_CustomValidate
	floanissuedupgradesadd.Form_CustomValidate = function(fobj) { // DO NOT CHANGE THIS LINE!

		// Your custom validation code here, return false if invalid.
		return true;
	}

	// Use JavaScript validation or not
	floanissuedupgradesadd.validateRequired = <?php echo Config("CLIENT_VALIDATE") ? "true" : "false" ?>;

	// Dynamic selection lists
	floanissuedupgradesadd.lists["x_fromloantype"] = <?php echo $loanissuedupgrades_add->fromloantype->Lookup->toClientList($loanissuedupgrades_add) ?>;
	floanissuedupgradesadd.lists["x_fromloantype"].options = <?php echo JsonEncode($loanissuedupgrades_add->fromloantype->lookupOptions()) ?>;
	floanissuedupgradesadd.lists["x_toloantype"] = <?php echo $loanissuedupgrades_add->toloantype->Lookup->toClientList($loanissuedupgrades_add) ?>;
	floanissuedupgradesadd.lists["x_toloantype"].options = <?php echo JsonEncode($loanissuedupgrades_add->toloantype->lookupOptions()) ?>;
	loadjs.done("floanissuedupgradesadd");
});
</script>
<script>
loadjs.ready("head", function() {

	// Client script
	// Write your client script here, no need to add script tags.

});
</script>
<?php $loanissuedupgrades_add->showPageHeader(); ?>
<?php
$loanissuedupgrades_add->showMessage();
?>
<form name="floanissuedupgradesadd" id="floanissuedupgradesadd" class="<?php echo $loanissuedupgrades_add->FormClassName ?>" action="<?php echo CurrentPageName() ?>" method="post">
<?php if ($Page->CheckToken) { ?>
<input type="hidden" name="<?php echo Config("TOKEN_NAME") ?>" value="<?php echo $Page->Token ?>">
<?php } ?>
<input type="hidden" name="t" value="loanissuedupgrades">
<input type="hidden" name="action" id="action" value="insert">
<input type="hidden" name="modal" value="<?php echo (int)$loanissuedupgrades_add->IsModal ?>">
<?php if ($loanissuedupgrades->getCurrentMasterTable() == "loanissued") { ?>
<input type="hidden" name="<?php echo Config("TABLE_SHOW_MASTER") ?>" value="loanissued">
<input type="hidden" name="fk_loanid" value="<?php echo HtmlEncode($loanissuedupgrades_add->loanid->getSessionValue()) ?>">
<?php } ?>
<div class="ew-add-div"><!-- page* -->
<?php if ($loanissuedupgrades_add->loanid->Visible) { // loanid ?>
	<div id="r_loanid" class="form-group row">
		<label id="elh_loanissuedupgrades_loanid" for="x_loanid" class="<?php echo $loanissuedupgrades_add->LeftColumnClass ?>"><?php echo $loanissuedupgrades_add->loanid->caption() ?><?php echo $loanissuedupgrades_add->loanid->Required ? $Language->phrase("FieldRequiredIndicator") : "" ?></label>
		<div class="<?php echo $loanissuedupgrades_add->RightColumnClass ?>"><div <?php echo $loanissuedupgrades_add->loanid->cellAttributes() ?>>
<?php if ($loanissuedupgrades_add->loanid->getSessionValue() != "") { ?>
<span id="el_loanissuedupgrades_loanid">
<span<?php echo $loanissuedupgrades_add->loanid->viewAttributes() ?>><input type="text" readonly class="form-control-plaintext" value="<?php echo HtmlEncode(RemoveHtml($loanissuedupgrades_add->loanid->ViewValue)) ?>"></span>
</span>
<input type="hidden" id="x_loanid" name="x_loanid" value="<?php echo HtmlEncode($loanissuedupgrades_add->loanid->CurrentValue) ?>">
<?php } else { ?>
<span id="el_loanissuedupgrades_loanid">
<input type="text" data-table="loanissuedupgrades" data-field="x_loanid" name="x_loanid" id="x_loanid" size="30" maxlength="12" placeholder="<?php echo HtmlEncode($loanissuedupgrades_add->loanid->getPlaceHolder()) ?>" value="<?php echo $loanissuedupgrades_add->loanid->EditValue ?>"<?php echo $loanissuedupgrades_add->loanid->editAttributes() ?>>
</span>
<?php } ?>
<?php echo $loanissuedupgrades_add->loanid->CustomMsg ?></div></div>
	</div>
<?php } ?>
<?php if ($loanissuedupgrades_add->fromloantype->Visible) { // fromloantype ?>
	<div id="r_fromloantype" class="form-group row">
		<label id="elh_loanissuedupgrades_fromloantype" for="x_fromloantype" class="<?php echo $loanissuedupgrades_add->LeftColumnClass ?>"><?php echo $loanissuedupgrades_add->fromloantype->caption() ?><?php echo $loanissuedupgrades_add->fromloantype->Required ? $Language->phrase("FieldRequiredIndicator") : "" ?></label>
		<div class="<?php echo $loanissuedupgrades_add->RightColumnClass ?>"><div <?php echo $loanissuedupgrades_add->fromloantype->cellAttributes() ?>>
<span id="el_loanissuedupgrades_fromloantype">
<div class="btn-group ew-dropdown-list" role="group">
	<div class="btn-group" role="group">
		<button type="button" class="btn form-control dropdown-toggle ew-dropdown-toggle" aria-haspopup="true" aria-expanded="false"<?php if ($loanissuedupgrades_add->fromloantype->ReadOnly) { ?> readonly<?php } else { ?>data-toggle="dropdown"<?php } ?>><?php echo $loanissuedupgrades_add->fromloantype->ViewValue ?></button>
		<div id="dsl_x_fromloantype" data-repeatcolumn="1" class="dropdown-menu">
			<div class="ew-items" style="overflow-x: hidden; min-width: 300px; max-height: 200px; overflow-y: auto;">
<?php echo $loanissuedupgrades_add->fromloantype->radioButtonListHtml(TRUE, "x_fromloantype") ?>
			</div><!-- /.ew-items -->
		</div><!-- /.dropdown-menu -->
		<div id="tp_x_fromloantype" class="ew-template"><input type="radio" class="custom-control-input" data-table="loanissuedupgrades" data-field="x_fromloantype" data-value-separator="<?php echo $loanissuedupgrades_add->fromloantype->displayValueSeparatorAttribute() ?>" name="x_fromloantype" id="x_fromloantype" value="{value}"<?php echo $loanissuedupgrades_add->fromloantype->editAttributes() ?>></div>
	</div><!-- /.btn-group -->
	<?php if (!$loanissuedupgrades_add->fromloantype->ReadOnly) { ?>
	<button type="button" class="btn btn-default ew-dropdown-clear" disabled>
		<i class="fas fa-times ew-icon"></i>
	</button>
	<?php } ?>
</div><!-- /.ew-dropdown-list -->
<?php echo $loanissuedupgrades_add->fromloantype->Lookup->getParamTag($loanissuedupgrades_add, "p_x_fromloantype") ?>
</span>
<?php echo $loanissuedupgrades_add->fromloantype->CustomMsg ?></div></div>
	</div>
<?php } ?>
<?php if ($loanissuedupgrades_add->toloantype->Visible) { // toloantype ?>
	<div id="r_toloantype" class="form-group row">
		<label id="elh_loanissuedupgrades_toloantype" for="x_toloantype" class="<?php echo $loanissuedupgrades_add->LeftColumnClass ?>"><?php echo $loanissuedupgrades_add->toloantype->caption() ?><?php echo $loanissuedupgrades_add->toloantype->Required ? $Language->phrase("FieldRequiredIndicator") : "" ?></label>
		<div class="<?php echo $loanissuedupgrades_add->RightColumnClass ?>"><div <?php echo $loanissuedupgrades_add->toloantype->cellAttributes() ?>>
<span id="el_loanissuedupgrades_toloantype">
<div class="btn-group ew-dropdown-list" role="group">
	<div class="btn-group" role="group">
		<button type="button" class="btn form-control dropdown-toggle ew-dropdown-toggle" aria-haspopup="true" aria-expanded="false"<?php if ($loanissuedupgrades_add->toloantype->ReadOnly) { ?> readonly<?php } else { ?>data-toggle="dropdown"<?php } ?>><?php echo $loanissuedupgrades_add->toloantype->ViewValue ?></button>
		<div id="dsl_x_toloantype" data-repeatcolumn="1" class="dropdown-menu">
			<div class="ew-items" style="overflow-x: hidden; min-width: 300px; max-height: 196px; overflow-y: auto;">
<?php echo $loanissuedupgrades_add->toloantype->radioButtonListHtml(TRUE, "x_toloantype") ?>
			</div><!-- /.ew-items -->
		</div><!-- /.dropdown-menu -->
		<div id="tp_x_toloantype" class="ew-template"><input type="radio" class="custom-control-input" data-table="loanissuedupgrades" data-field="x_toloantype" data-value-separator="<?php echo $loanissuedupgrades_add->toloantype->displayValueSeparatorAttribute() ?>" name="x_toloantype" id="x_toloantype" value="{value}"<?php echo $loanissuedupgrades_add->toloantype->editAttributes() ?>></div>
	</div><!-- /.btn-group -->
	<?php if (!$loanissuedupgrades_add->toloantype->ReadOnly) { ?>
	<button type="button" class="btn btn-default ew-dropdown-clear" disabled>
		<i class="fas fa-times ew-icon"></i>
	</button>
	<?php } ?>
</div><!-- /.ew-dropdown-list -->
<?php echo $loanissuedupgrades_add->toloantype->Lookup->getParamTag($loanissuedupgrades_add, "p_x_toloantype") ?>
</span>
<?php echo $loanissuedupgrades_add->toloantype->CustomMsg ?></div></div>
	</div>
<?php } ?>
<?php if ($loanissuedupgrades_add->upgradedate->Visible) { // upgradedate ?>
	<div id="r_upgradedate" class="form-group row">
		<label id="elh_loanissuedupgrades_upgradedate" for="x_upgradedate" class="<?php echo $loanissuedupgrades_add->LeftColumnClass ?>"><?php echo $loanissuedupgrades_add->upgradedate->caption() ?><?php echo $loanissuedupgrades_add->upgradedate->Required ? $Language->phrase("FieldRequiredIndicator") : "" ?></label>
		<div class="<?php echo $loanissuedupgrades_add->RightColumnClass ?>"><div <?php echo $loanissuedupgrades_add->upgradedate->cellAttributes() ?>>
<span id="el_loanissuedupgrades_upgradedate">
<input type="text" data-table="loanissuedupgrades" data-field="x_upgradedate" name="x_upgradedate" id="x_upgradedate" maxlength="19" placeholder="<?php echo HtmlEncode($loanissuedupgrades_add->upgradedate->getPlaceHolder()) ?>" value="<?php echo $loanissuedupgrades_add->upgradedate->EditValue ?>"<?php echo $loanissuedupgrades_add->upgradedate->editAttributes() ?>>
<?php if (!$loanissuedupgrades_add->upgradedate->ReadOnly && !$loanissuedupgrades_add->upgradedate->Disabled && !isset($loanissuedupgrades_add->upgradedate->EditAttrs["readonly"]) && !isset($loanissuedupgrades_add->upgradedate->EditAttrs["disabled"])) { ?>
<script>
loadjs.ready(["floanissuedupgradesadd", "datetimepicker"], function() {
	ew.createDateTimePicker("floanissuedupgradesadd", "x_upgradedate", {"ignoreReadonly":true,"useCurrent":false,"format":0});
});
</script>
<?php } ?>
</span>
<?php echo $loanissuedupgrades_add->upgradedate->CustomMsg ?></div></div>
	</div>
<?php } ?>
<?php if ($loanissuedupgrades_add->fromduedate->Visible) { // fromduedate ?>
	<div id="r_fromduedate" class="form-group row">
		<label id="elh_loanissuedupgrades_fromduedate" for="x_fromduedate" class="<?php echo $loanissuedupgrades_add->LeftColumnClass ?>"><?php echo $loanissuedupgrades_add->fromduedate->caption() ?><?php echo $loanissuedupgrades_add->fromduedate->Required ? $Language->phrase("FieldRequiredIndicator") : "" ?></label>
		<div class="<?php echo $loanissuedupgrades_add->RightColumnClass ?>"><div <?php echo $loanissuedupgrades_add->fromduedate->cellAttributes() ?>>
<span id="el_loanissuedupgrades_fromduedate">
<input type="text" data-table="loanissuedupgrades" data-field="x_fromduedate" name="x_fromduedate" id="x_fromduedate" maxlength="10" placeholder="<?php echo HtmlEncode($loanissuedupgrades_add->fromduedate->getPlaceHolder()) ?>" value="<?php echo $loanissuedupgrades_add->fromduedate->EditValue ?>"<?php echo $loanissuedupgrades_add->fromduedate->editAttributes() ?>>
<?php if (!$loanissuedupgrades_add->fromduedate->ReadOnly && !$loanissuedupgrades_add->fromduedate->Disabled && !isset($loanissuedupgrades_add->fromduedate->EditAttrs["readonly"]) && !isset($loanissuedupgrades_add->fromduedate->EditAttrs["disabled"])) { ?>
<script>
loadjs.ready(["floanissuedupgradesadd", "datetimepicker"], function() {
	ew.createDateTimePicker("floanissuedupgradesadd", "x_fromduedate", {"ignoreReadonly":true,"useCurrent":false,"format":0});
});
</script>
<?php } ?>
</span>
<?php echo $loanissuedupgrades_add->fromduedate->CustomMsg ?></div></div>
	</div>
<?php } ?>
<?php if ($loanissuedupgrades_add->toduedate->Visible) { // toduedate ?>
	<div id="r_toduedate" class="form-group row">
		<label id="elh_loanissuedupgrades_toduedate" for="x_toduedate" class="<?php echo $loanissuedupgrades_add->LeftColumnClass ?>"><?php echo $loanissuedupgrades_add->toduedate->caption() ?><?php echo $loanissuedupgrades_add->toduedate->Required ? $Language->phrase("FieldRequiredIndicator") : "" ?></label>
		<div class="<?php echo $loanissuedupgrades_add->RightColumnClass ?>"><div <?php echo $loanissuedupgrades_add->toduedate->cellAttributes() ?>>
<span id="el_loanissuedupgrades_toduedate">
<input type="text" data-table="loanissuedupgrades" data-field="x_toduedate" name="x_toduedate" id="x_toduedate" maxlength="10" placeholder="<?php echo HtmlEncode($loanissuedupgrades_add->toduedate->getPlaceHolder()) ?>" value="<?php echo $loanissuedupgrades_add->toduedate->EditValue ?>"<?php echo $loanissuedupgrades_add->toduedate->editAttributes() ?>>
<?php if (!$loanissuedupgrades_add->toduedate->ReadOnly && !$loanissuedupgrades_add->toduedate->Disabled && !isset($loanissuedupgrades_add->toduedate->EditAttrs["readonly"]) && !isset($loanissuedupgrades_add->toduedate->EditAttrs["disabled"])) { ?>
<script>
loadjs.ready(["floanissuedupgradesadd", "datetimepicker"], function() {
	ew.createDateTimePicker("floanissuedupgradesadd", "x_toduedate", {"ignoreReadonly":true,"useCurrent":false,"format":0});
});
</script>
<?php } ?>
</span>
<?php echo $loanissuedupgrades_add->toduedate->CustomMsg ?></div></div>
	</div>
<?php } ?>
</div><!-- /page* -->
<?php if (!$loanissuedupgrades_add->IsModal) { ?>
<div class="form-group row"><!-- buttons .form-group -->
	<div class="<?php echo $loanissuedupgrades_add->OffsetColumnClass ?>"><!-- buttons offset -->
<button class="btn btn-primary ew-btn" name="btn-action" id="btn-action" type="submit"><?php echo $Language->phrase("AddBtn") ?></button>
<button class="btn btn-default ew-btn" name="btn-cancel" id="btn-cancel" type="button" data-href="<?php echo $loanissuedupgrades_add->getReturnUrl() ?>"><?php echo $Language->phrase("CancelBtn") ?></button>
	</div><!-- /buttons offset -->
</div><!-- /buttons .form-group -->
<?php } ?>
</form>
<?php
$loanissuedupgrades_add->showPageFooter();
if (Config("DEBUG"))
	echo GetDebugMessage();
?>
<script>
loadjs.ready("load", function() {

	// Startup script
	// Write your table-specific startup script here
	// console.log("page loaded");

});
</script>
<?php include_once "footer.php"; ?>
<?php
$loanissuedupgrades_add->terminate();
?>