<?php
namespace PHPMaker2020\_4payadmin;

// Autoload
include_once "autoload.php";

// Session
if (session_status() !== PHP_SESSION_ACTIVE)
	\Delight\Cookie\Session::start(Config("COOKIE_SAMESITE")); // Init session data

// Output buffering
ob_start();
?>
<?php

// Write header
WriteHeader(FALSE);

// Create page object
$userbillingaccounts_edit = new userbillingaccounts_edit();

// Run the page
$userbillingaccounts_edit->run();

// Setup login status
SetupLoginStatus();
SetClientVar("login", LoginStatus());

// Global Page Rendering event (in userfn*.php)
Page_Rendering();

// Page Rendering event
$userbillingaccounts_edit->Page_Render();
?>
<?php include_once "header.php"; ?>
<script>
var fuserbillingaccountsedit, currentPageID;
loadjs.ready("head", function() {

	// Form object
	currentPageID = ew.PAGE_ID = "edit";
	fuserbillingaccountsedit = currentForm = new ew.Form("fuserbillingaccountsedit", "edit");

	// Validate form
	fuserbillingaccountsedit.validate = function() {
		if (!this.validateRequired)
			return true; // Ignore validation
		var $ = jQuery, fobj = this.getForm(), $fobj = $(fobj);
		if ($fobj.find("#confirm").val() == "confirm")
			return true;
		var elm, felm, uelm, addcnt = 0;
		var $k = $fobj.find("#" + this.formKeyCountName); // Get key_count
		var rowcnt = ($k[0]) ? parseInt($k.val(), 10) : 1;
		var startcnt = (rowcnt == 0) ? 0 : 1; // Check rowcnt == 0 => Inline-Add
		var gridinsert = ["insert", "gridinsert"].includes($fobj.find("#action").val()) && $k[0];
		for (var i = startcnt; i <= rowcnt; i++) {
			var infix = ($k[0]) ? String(i) : "";
			$fobj.data("rowindex", infix);
			<?php if ($userbillingaccounts_edit->_userid->Required) { ?>
				elm = this.getElements("x" + infix + "__userid");
				if (elm && !ew.isHidden(elm) && !ew.hasValue(elm))
					return this.onError(elm, "<?php echo JsEncode(str_replace("%s", $userbillingaccounts_edit->_userid->caption(), $userbillingaccounts_edit->_userid->RequiredErrorMessage)) ?>");
			<?php } ?>
				elm = this.getElements("x" + infix + "__userid");
				if (elm && !ew.checkInteger(elm.value))
					return this.onError(elm, "<?php echo JsEncode($userbillingaccounts_edit->_userid->errorMessage()) ?>");
			<?php if ($userbillingaccounts_edit->billingserviceid->Required) { ?>
				elm = this.getElements("x" + infix + "_billingserviceid");
				if (elm && !ew.isHidden(elm) && !ew.hasValue(elm))
					return this.onError(elm, "<?php echo JsEncode(str_replace("%s", $userbillingaccounts_edit->billingserviceid->caption(), $userbillingaccounts_edit->billingserviceid->RequiredErrorMessage)) ?>");
			<?php } ?>
				elm = this.getElements("x" + infix + "_billingserviceid");
				if (elm && !ew.checkInteger(elm.value))
					return this.onError(elm, "<?php echo JsEncode($userbillingaccounts_edit->billingserviceid->errorMessage()) ?>");
			<?php if ($userbillingaccounts_edit->accountno->Required) { ?>
				elm = this.getElements("x" + infix + "_accountno");
				if (elm && !ew.isHidden(elm) && !ew.hasValue(elm))
					return this.onError(elm, "<?php echo JsEncode(str_replace("%s", $userbillingaccounts_edit->accountno->caption(), $userbillingaccounts_edit->accountno->RequiredErrorMessage)) ?>");
			<?php } ?>
			<?php if ($userbillingaccounts_edit->active->Required) { ?>
				elm = this.getElements("x" + infix + "_active");
				if (elm && !ew.isHidden(elm) && !ew.hasValue(elm))
					return this.onError(elm, "<?php echo JsEncode(str_replace("%s", $userbillingaccounts_edit->active->caption(), $userbillingaccounts_edit->active->RequiredErrorMessage)) ?>");
			<?php } ?>
				elm = this.getElements("x" + infix + "_active");
				if (elm && !ew.checkInteger(elm.value))
					return this.onError(elm, "<?php echo JsEncode($userbillingaccounts_edit->active->errorMessage()) ?>");
			<?php if ($userbillingaccounts_edit->lastchangedate->Required) { ?>
				elm = this.getElements("x" + infix + "_lastchangedate");
				if (elm && !ew.isHidden(elm) && !ew.hasValue(elm))
					return this.onError(elm, "<?php echo JsEncode(str_replace("%s", $userbillingaccounts_edit->lastchangedate->caption(), $userbillingaccounts_edit->lastchangedate->RequiredErrorMessage)) ?>");
			<?php } ?>
				elm = this.getElements("x" + infix + "_lastchangedate");
				if (elm && !ew.checkDateDef(elm.value))
					return this.onError(elm, "<?php echo JsEncode($userbillingaccounts_edit->lastchangedate->errorMessage()) ?>");
			<?php if ($userbillingaccounts_edit->userpi->Required) { ?>
				elm = this.getElements("x" + infix + "_userpi");
				if (elm && !ew.isHidden(elm) && !ew.hasValue(elm))
					return this.onError(elm, "<?php echo JsEncode(str_replace("%s", $userbillingaccounts_edit->userpi->caption(), $userbillingaccounts_edit->userpi->RequiredErrorMessage)) ?>");
			<?php } ?>
				elm = this.getElements("x" + infix + "_userpi");
				if (elm && !ew.checkInteger(elm.value))
					return this.onError(elm, "<?php echo JsEncode($userbillingaccounts_edit->userpi->errorMessage()) ?>");
			<?php if ($userbillingaccounts_edit->maxamount->Required) { ?>
				elm = this.getElements("x" + infix + "_maxamount");
				if (elm && !ew.isHidden(elm) && !ew.hasValue(elm))
					return this.onError(elm, "<?php echo JsEncode(str_replace("%s", $userbillingaccounts_edit->maxamount->caption(), $userbillingaccounts_edit->maxamount->RequiredErrorMessage)) ?>");
			<?php } ?>
				elm = this.getElements("x" + infix + "_maxamount");
				if (elm && !ew.checkNumber(elm.value))
					return this.onError(elm, "<?php echo JsEncode($userbillingaccounts_edit->maxamount->errorMessage()) ?>");
			<?php if ($userbillingaccounts_edit->authorizeautomaticpayment->Required) { ?>
				elm = this.getElements("x" + infix + "_authorizeautomaticpayment");
				if (elm && !ew.isHidden(elm) && !ew.hasValue(elm))
					return this.onError(elm, "<?php echo JsEncode(str_replace("%s", $userbillingaccounts_edit->authorizeautomaticpayment->caption(), $userbillingaccounts_edit->authorizeautomaticpayment->RequiredErrorMessage)) ?>");
			<?php } ?>
				elm = this.getElements("x" + infix + "_authorizeautomaticpayment");
				if (elm && !ew.checkInteger(elm.value))
					return this.onError(elm, "<?php echo JsEncode($userbillingaccounts_edit->authorizeautomaticpayment->errorMessage()) ?>");
			<?php if ($userbillingaccounts_edit->otherdetails->Required) { ?>
				elm = this.getElements("x" + infix + "_otherdetails");
				if (elm && !ew.isHidden(elm) && !ew.hasValue(elm))
					return this.onError(elm, "<?php echo JsEncode(str_replace("%s", $userbillingaccounts_edit->otherdetails->caption(), $userbillingaccounts_edit->otherdetails->RequiredErrorMessage)) ?>");
			<?php } ?>

				// Call Form_CustomValidate event
				if (!this.Form_CustomValidate(fobj))
					return false;
		}

		// Process detail forms
		var dfs = $fobj.find("input[name='detailpage']").get();
		for (var i = 0; i < dfs.length; i++) {
			var df = dfs[i], val = df.value;
			if (val && ew.forms[val])
				if (!ew.forms[val].validate())
					return false;
		}
		return true;
	}

	// Form_CustomValidate
	fuserbillingaccountsedit.Form_CustomValidate = function(fobj) { // DO NOT CHANGE THIS LINE!

		// Your custom validation code here, return false if invalid.
		return true;
	}

	// Use JavaScript validation or not
	fuserbillingaccountsedit.validateRequired = <?php echo Config("CLIENT_VALIDATE") ? "true" : "false" ?>;

	// Dynamic selection lists
	loadjs.done("fuserbillingaccountsedit");
});
</script>
<script>
loadjs.ready("head", function() {

	// Client script
	// Write your client script here, no need to add script tags.

});
</script>
<?php $userbillingaccounts_edit->showPageHeader(); ?>
<?php
$userbillingaccounts_edit->showMessage();
?>
<form name="fuserbillingaccountsedit" id="fuserbillingaccountsedit" class="<?php echo $userbillingaccounts_edit->FormClassName ?>" action="<?php echo CurrentPageName() ?>" method="post">
<?php if ($Page->CheckToken) { ?>
<input type="hidden" name="<?php echo Config("TOKEN_NAME") ?>" value="<?php echo $Page->Token ?>">
<?php } ?>
<input type="hidden" name="t" value="userbillingaccounts">
<input type="hidden" name="action" id="action" value="update">
<input type="hidden" name="modal" value="<?php echo (int)$userbillingaccounts_edit->IsModal ?>">
<div class="ew-edit-div"><!-- page* -->
<?php if ($userbillingaccounts_edit->_userid->Visible) { // userid ?>
	<div id="r__userid" class="form-group row">
		<label id="elh_userbillingaccounts__userid" for="x__userid" class="<?php echo $userbillingaccounts_edit->LeftColumnClass ?>"><?php echo $userbillingaccounts_edit->_userid->caption() ?><?php echo $userbillingaccounts_edit->_userid->Required ? $Language->phrase("FieldRequiredIndicator") : "" ?></label>
		<div class="<?php echo $userbillingaccounts_edit->RightColumnClass ?>"><div <?php echo $userbillingaccounts_edit->_userid->cellAttributes() ?>>
<input type="text" data-table="userbillingaccounts" data-field="x__userid" name="x__userid" id="x__userid" size="30" placeholder="<?php echo HtmlEncode($userbillingaccounts_edit->_userid->getPlaceHolder()) ?>" value="<?php echo $userbillingaccounts_edit->_userid->EditValue ?>"<?php echo $userbillingaccounts_edit->_userid->editAttributes() ?>>
<input type="hidden" data-table="userbillingaccounts" data-field="x__userid" name="o__userid" id="o__userid" value="<?php echo HtmlEncode($userbillingaccounts_edit->_userid->OldValue != null ? $userbillingaccounts_edit->_userid->OldValue : $userbillingaccounts_edit->_userid->CurrentValue) ?>">
<?php echo $userbillingaccounts_edit->_userid->CustomMsg ?></div></div>
	</div>
<?php } ?>
<?php if ($userbillingaccounts_edit->billingserviceid->Visible) { // billingserviceid ?>
	<div id="r_billingserviceid" class="form-group row">
		<label id="elh_userbillingaccounts_billingserviceid" for="x_billingserviceid" class="<?php echo $userbillingaccounts_edit->LeftColumnClass ?>"><?php echo $userbillingaccounts_edit->billingserviceid->caption() ?><?php echo $userbillingaccounts_edit->billingserviceid->Required ? $Language->phrase("FieldRequiredIndicator") : "" ?></label>
		<div class="<?php echo $userbillingaccounts_edit->RightColumnClass ?>"><div <?php echo $userbillingaccounts_edit->billingserviceid->cellAttributes() ?>>
<input type="text" data-table="userbillingaccounts" data-field="x_billingserviceid" name="x_billingserviceid" id="x_billingserviceid" size="30" placeholder="<?php echo HtmlEncode($userbillingaccounts_edit->billingserviceid->getPlaceHolder()) ?>" value="<?php echo $userbillingaccounts_edit->billingserviceid->EditValue ?>"<?php echo $userbillingaccounts_edit->billingserviceid->editAttributes() ?>>
<input type="hidden" data-table="userbillingaccounts" data-field="x_billingserviceid" name="o_billingserviceid" id="o_billingserviceid" value="<?php echo HtmlEncode($userbillingaccounts_edit->billingserviceid->OldValue != null ? $userbillingaccounts_edit->billingserviceid->OldValue : $userbillingaccounts_edit->billingserviceid->CurrentValue) ?>">
<?php echo $userbillingaccounts_edit->billingserviceid->CustomMsg ?></div></div>
	</div>
<?php } ?>
<?php if ($userbillingaccounts_edit->accountno->Visible) { // accountno ?>
	<div id="r_accountno" class="form-group row">
		<label id="elh_userbillingaccounts_accountno" for="x_accountno" class="<?php echo $userbillingaccounts_edit->LeftColumnClass ?>"><?php echo $userbillingaccounts_edit->accountno->caption() ?><?php echo $userbillingaccounts_edit->accountno->Required ? $Language->phrase("FieldRequiredIndicator") : "" ?></label>
		<div class="<?php echo $userbillingaccounts_edit->RightColumnClass ?>"><div <?php echo $userbillingaccounts_edit->accountno->cellAttributes() ?>>
<input type="text" data-table="userbillingaccounts" data-field="x_accountno" name="x_accountno" id="x_accountno" size="30" maxlength="30" placeholder="<?php echo HtmlEncode($userbillingaccounts_edit->accountno->getPlaceHolder()) ?>" value="<?php echo $userbillingaccounts_edit->accountno->EditValue ?>"<?php echo $userbillingaccounts_edit->accountno->editAttributes() ?>>
<input type="hidden" data-table="userbillingaccounts" data-field="x_accountno" name="o_accountno" id="o_accountno" value="<?php echo HtmlEncode($userbillingaccounts_edit->accountno->OldValue != null ? $userbillingaccounts_edit->accountno->OldValue : $userbillingaccounts_edit->accountno->CurrentValue) ?>">
<?php echo $userbillingaccounts_edit->accountno->CustomMsg ?></div></div>
	</div>
<?php } ?>
<?php if ($userbillingaccounts_edit->active->Visible) { // active ?>
	<div id="r_active" class="form-group row">
		<label id="elh_userbillingaccounts_active" for="x_active" class="<?php echo $userbillingaccounts_edit->LeftColumnClass ?>"><?php echo $userbillingaccounts_edit->active->caption() ?><?php echo $userbillingaccounts_edit->active->Required ? $Language->phrase("FieldRequiredIndicator") : "" ?></label>
		<div class="<?php echo $userbillingaccounts_edit->RightColumnClass ?>"><div <?php echo $userbillingaccounts_edit->active->cellAttributes() ?>>
<span id="el_userbillingaccounts_active">
<input type="text" data-table="userbillingaccounts" data-field="x_active" name="x_active" id="x_active" size="30" placeholder="<?php echo HtmlEncode($userbillingaccounts_edit->active->getPlaceHolder()) ?>" value="<?php echo $userbillingaccounts_edit->active->EditValue ?>"<?php echo $userbillingaccounts_edit->active->editAttributes() ?>>
</span>
<?php echo $userbillingaccounts_edit->active->CustomMsg ?></div></div>
	</div>
<?php } ?>
<?php if ($userbillingaccounts_edit->lastchangedate->Visible) { // lastchangedate ?>
	<div id="r_lastchangedate" class="form-group row">
		<label id="elh_userbillingaccounts_lastchangedate" for="x_lastchangedate" class="<?php echo $userbillingaccounts_edit->LeftColumnClass ?>"><?php echo $userbillingaccounts_edit->lastchangedate->caption() ?><?php echo $userbillingaccounts_edit->lastchangedate->Required ? $Language->phrase("FieldRequiredIndicator") : "" ?></label>
		<div class="<?php echo $userbillingaccounts_edit->RightColumnClass ?>"><div <?php echo $userbillingaccounts_edit->lastchangedate->cellAttributes() ?>>
<span id="el_userbillingaccounts_lastchangedate">
<input type="text" data-table="userbillingaccounts" data-field="x_lastchangedate" name="x_lastchangedate" id="x_lastchangedate" placeholder="<?php echo HtmlEncode($userbillingaccounts_edit->lastchangedate->getPlaceHolder()) ?>" value="<?php echo $userbillingaccounts_edit->lastchangedate->EditValue ?>"<?php echo $userbillingaccounts_edit->lastchangedate->editAttributes() ?>>
</span>
<?php echo $userbillingaccounts_edit->lastchangedate->CustomMsg ?></div></div>
	</div>
<?php } ?>
<?php if ($userbillingaccounts_edit->userpi->Visible) { // userpi ?>
	<div id="r_userpi" class="form-group row">
		<label id="elh_userbillingaccounts_userpi" for="x_userpi" class="<?php echo $userbillingaccounts_edit->LeftColumnClass ?>"><?php echo $userbillingaccounts_edit->userpi->caption() ?><?php echo $userbillingaccounts_edit->userpi->Required ? $Language->phrase("FieldRequiredIndicator") : "" ?></label>
		<div class="<?php echo $userbillingaccounts_edit->RightColumnClass ?>"><div <?php echo $userbillingaccounts_edit->userpi->cellAttributes() ?>>
<span id="el_userbillingaccounts_userpi">
<input type="text" data-table="userbillingaccounts" data-field="x_userpi" name="x_userpi" id="x_userpi" size="30" placeholder="<?php echo HtmlEncode($userbillingaccounts_edit->userpi->getPlaceHolder()) ?>" value="<?php echo $userbillingaccounts_edit->userpi->EditValue ?>"<?php echo $userbillingaccounts_edit->userpi->editAttributes() ?>>
</span>
<?php echo $userbillingaccounts_edit->userpi->CustomMsg ?></div></div>
	</div>
<?php } ?>
<?php if ($userbillingaccounts_edit->maxamount->Visible) { // maxamount ?>
	<div id="r_maxamount" class="form-group row">
		<label id="elh_userbillingaccounts_maxamount" for="x_maxamount" class="<?php echo $userbillingaccounts_edit->LeftColumnClass ?>"><?php echo $userbillingaccounts_edit->maxamount->caption() ?><?php echo $userbillingaccounts_edit->maxamount->Required ? $Language->phrase("FieldRequiredIndicator") : "" ?></label>
		<div class="<?php echo $userbillingaccounts_edit->RightColumnClass ?>"><div <?php echo $userbillingaccounts_edit->maxamount->cellAttributes() ?>>
<span id="el_userbillingaccounts_maxamount">
<input type="text" data-table="userbillingaccounts" data-field="x_maxamount" name="x_maxamount" id="x_maxamount" size="30" placeholder="<?php echo HtmlEncode($userbillingaccounts_edit->maxamount->getPlaceHolder()) ?>" value="<?php echo $userbillingaccounts_edit->maxamount->EditValue ?>"<?php echo $userbillingaccounts_edit->maxamount->editAttributes() ?>>
</span>
<?php echo $userbillingaccounts_edit->maxamount->CustomMsg ?></div></div>
	</div>
<?php } ?>
<?php if ($userbillingaccounts_edit->authorizeautomaticpayment->Visible) { // authorizeautomaticpayment ?>
	<div id="r_authorizeautomaticpayment" class="form-group row">
		<label id="elh_userbillingaccounts_authorizeautomaticpayment" for="x_authorizeautomaticpayment" class="<?php echo $userbillingaccounts_edit->LeftColumnClass ?>"><?php echo $userbillingaccounts_edit->authorizeautomaticpayment->caption() ?><?php echo $userbillingaccounts_edit->authorizeautomaticpayment->Required ? $Language->phrase("FieldRequiredIndicator") : "" ?></label>
		<div class="<?php echo $userbillingaccounts_edit->RightColumnClass ?>"><div <?php echo $userbillingaccounts_edit->authorizeautomaticpayment->cellAttributes() ?>>
<span id="el_userbillingaccounts_authorizeautomaticpayment">
<input type="text" data-table="userbillingaccounts" data-field="x_authorizeautomaticpayment" name="x_authorizeautomaticpayment" id="x_authorizeautomaticpayment" size="30" placeholder="<?php echo HtmlEncode($userbillingaccounts_edit->authorizeautomaticpayment->getPlaceHolder()) ?>" value="<?php echo $userbillingaccounts_edit->authorizeautomaticpayment->EditValue ?>"<?php echo $userbillingaccounts_edit->authorizeautomaticpayment->editAttributes() ?>>
</span>
<?php echo $userbillingaccounts_edit->authorizeautomaticpayment->CustomMsg ?></div></div>
	</div>
<?php } ?>
<?php if ($userbillingaccounts_edit->otherdetails->Visible) { // otherdetails ?>
	<div id="r_otherdetails" class="form-group row">
		<label id="elh_userbillingaccounts_otherdetails" for="x_otherdetails" class="<?php echo $userbillingaccounts_edit->LeftColumnClass ?>"><?php echo $userbillingaccounts_edit->otherdetails->caption() ?><?php echo $userbillingaccounts_edit->otherdetails->Required ? $Language->phrase("FieldRequiredIndicator") : "" ?></label>
		<div class="<?php echo $userbillingaccounts_edit->RightColumnClass ?>"><div <?php echo $userbillingaccounts_edit->otherdetails->cellAttributes() ?>>
<span id="el_userbillingaccounts_otherdetails">
<input type="text" data-table="userbillingaccounts" data-field="x_otherdetails" name="x_otherdetails" id="x_otherdetails" size="30" maxlength="100" placeholder="<?php echo HtmlEncode($userbillingaccounts_edit->otherdetails->getPlaceHolder()) ?>" value="<?php echo $userbillingaccounts_edit->otherdetails->EditValue ?>"<?php echo $userbillingaccounts_edit->otherdetails->editAttributes() ?>>
</span>
<?php echo $userbillingaccounts_edit->otherdetails->CustomMsg ?></div></div>
	</div>
<?php } ?>
</div><!-- /page* -->
<?php if (!$userbillingaccounts_edit->IsModal) { ?>
<div class="form-group row"><!-- buttons .form-group -->
	<div class="<?php echo $userbillingaccounts_edit->OffsetColumnClass ?>"><!-- buttons offset -->
<button class="btn btn-primary ew-btn" name="btn-action" id="btn-action" type="submit"><?php echo $Language->phrase("SaveBtn") ?></button>
<button class="btn btn-default ew-btn" name="btn-cancel" id="btn-cancel" type="button" data-href="<?php echo $userbillingaccounts_edit->getReturnUrl() ?>"><?php echo $Language->phrase("CancelBtn") ?></button>
	</div><!-- /buttons offset -->
</div><!-- /buttons .form-group -->
<?php } ?>
</form>
<?php
$userbillingaccounts_edit->showPageFooter();
if (Config("DEBUG"))
	echo GetDebugMessage();
?>
<script>
loadjs.ready("load", function() {

	// Startup script
	// Write your table-specific startup script here
	// console.log("page loaded");

});
</script>
<?php include_once "footer.php"; ?>
<?php
$userbillingaccounts_edit->terminate();
?>