<?php
namespace PHPMaker2020\_4payadmin;

// Autoload
include_once "autoload.php";

// Session
if (session_status() !== PHP_SESSION_ACTIVE)
	\Delight\Cookie\Session::start(Config("COOKIE_SAMESITE")); // Init session data

// Output buffering
ob_start();
?>
<?php

// Write header
WriteHeader(FALSE, "utf-8");

// Create page object
$merchantsales_preview = new merchantsales_preview();

// Run the page
$merchantsales_preview->run();

// Setup login status
SetupLoginStatus();
SetClientVar("login", LoginStatus());

// Global Page Rendering event (in userfn*.php)
Page_Rendering();

// Page Rendering event
$merchantsales_preview->Page_Render();
?>
<?php $merchantsales_preview->showPageHeader(); ?>
<?php if ($merchantsales_preview->TotalRecords > 0) { ?>
<div class="card ew-grid merchantsales"><!-- .card -->
<div class="<?php echo ResponsiveTableClass() ?>card-body ew-grid-middle-panel ew-preview-middle-panel"><!-- .table-responsive -->
<table class="table ew-table ew-preview-table"><!-- .table -->
	<thead><!-- Table header -->
		<tr class="ew-table-header">
<?php

// Render list options
$merchantsales_preview->renderListOptions();

// Render list options (header, left)
$merchantsales_preview->ListOptions->render("header", "left");
?>
<?php if ($merchantsales_preview->transferID->Visible) { // transferID ?>
	<?php if ($merchantsales->SortUrl($merchantsales_preview->transferID) == "") { ?>
		<th class="<?php echo $merchantsales_preview->transferID->headerCellClass() ?>"><?php echo $merchantsales_preview->transferID->caption() ?></th>
	<?php } else { ?>
		<th class="<?php echo $merchantsales_preview->transferID->headerCellClass() ?>"><div class="ew-pointer" data-sort="<?php echo HtmlEncode($merchantsales_preview->transferID->Name) ?>" data-sort-order="<?php echo $merchantsales_preview->SortField == $merchantsales_preview->transferID->Name && $merchantsales_preview->SortOrder == "ASC" ? "DESC" : "ASC" ?>">
			<div class="ew-table-header-btn"><span class="ew-table-header-caption"><?php echo $merchantsales_preview->transferID->caption() ?></span><span class="ew-table-header-sort"><?php if ($merchantsales_preview->SortField == $merchantsales_preview->transferID->Name) { ?><?php if ($merchantsales_preview->SortOrder == "ASC") { ?><i class="fas fa-sort-up"></i><?php } elseif ($merchantsales_preview->SortOrder == "DESC") { ?><i class="fas fa-sort-down"></i><?php } ?><?php } ?></span>
		</div></div></th>
	<?php } ?>
<?php } ?>
<?php if ($merchantsales_preview->txid->Visible) { // txid ?>
	<?php if ($merchantsales->SortUrl($merchantsales_preview->txid) == "") { ?>
		<th class="<?php echo $merchantsales_preview->txid->headerCellClass() ?>"><?php echo $merchantsales_preview->txid->caption() ?></th>
	<?php } else { ?>
		<th class="<?php echo $merchantsales_preview->txid->headerCellClass() ?>"><div class="ew-pointer" data-sort="<?php echo HtmlEncode($merchantsales_preview->txid->Name) ?>" data-sort-order="<?php echo $merchantsales_preview->SortField == $merchantsales_preview->txid->Name && $merchantsales_preview->SortOrder == "ASC" ? "DESC" : "ASC" ?>">
			<div class="ew-table-header-btn"><span class="ew-table-header-caption"><?php echo $merchantsales_preview->txid->caption() ?></span><span class="ew-table-header-sort"><?php if ($merchantsales_preview->SortField == $merchantsales_preview->txid->Name) { ?><?php if ($merchantsales_preview->SortOrder == "ASC") { ?><i class="fas fa-sort-up"></i><?php } elseif ($merchantsales_preview->SortOrder == "DESC") { ?><i class="fas fa-sort-down"></i><?php } ?><?php } ?></span>
		</div></div></th>
	<?php } ?>
<?php } ?>
<?php if ($merchantsales_preview->merchantID->Visible) { // merchantID ?>
	<?php if ($merchantsales->SortUrl($merchantsales_preview->merchantID) == "") { ?>
		<th class="<?php echo $merchantsales_preview->merchantID->headerCellClass() ?>"><?php echo $merchantsales_preview->merchantID->caption() ?></th>
	<?php } else { ?>
		<th class="<?php echo $merchantsales_preview->merchantID->headerCellClass() ?>"><div class="ew-pointer" data-sort="<?php echo HtmlEncode($merchantsales_preview->merchantID->Name) ?>" data-sort-order="<?php echo $merchantsales_preview->SortField == $merchantsales_preview->merchantID->Name && $merchantsales_preview->SortOrder == "ASC" ? "DESC" : "ASC" ?>">
			<div class="ew-table-header-btn"><span class="ew-table-header-caption"><?php echo $merchantsales_preview->merchantID->caption() ?></span><span class="ew-table-header-sort"><?php if ($merchantsales_preview->SortField == $merchantsales_preview->merchantID->Name) { ?><?php if ($merchantsales_preview->SortOrder == "ASC") { ?><i class="fas fa-sort-up"></i><?php } elseif ($merchantsales_preview->SortOrder == "DESC") { ?><i class="fas fa-sort-down"></i><?php } ?><?php } ?></span>
		</div></div></th>
	<?php } ?>
<?php } ?>
<?php if ($merchantsales_preview->_userID->Visible) { // userID ?>
	<?php if ($merchantsales->SortUrl($merchantsales_preview->_userID) == "") { ?>
		<th class="<?php echo $merchantsales_preview->_userID->headerCellClass() ?>"><?php echo $merchantsales_preview->_userID->caption() ?></th>
	<?php } else { ?>
		<th class="<?php echo $merchantsales_preview->_userID->headerCellClass() ?>"><div class="ew-pointer" data-sort="<?php echo HtmlEncode($merchantsales_preview->_userID->Name) ?>" data-sort-order="<?php echo $merchantsales_preview->SortField == $merchantsales_preview->_userID->Name && $merchantsales_preview->SortOrder == "ASC" ? "DESC" : "ASC" ?>">
			<div class="ew-table-header-btn"><span class="ew-table-header-caption"><?php echo $merchantsales_preview->_userID->caption() ?></span><span class="ew-table-header-sort"><?php if ($merchantsales_preview->SortField == $merchantsales_preview->_userID->Name) { ?><?php if ($merchantsales_preview->SortOrder == "ASC") { ?><i class="fas fa-sort-up"></i><?php } elseif ($merchantsales_preview->SortOrder == "DESC") { ?><i class="fas fa-sort-down"></i><?php } ?><?php } ?></span>
		</div></div></th>
	<?php } ?>
<?php } ?>
<?php if ($merchantsales_preview->transferTime->Visible) { // transferTime ?>
	<?php if ($merchantsales->SortUrl($merchantsales_preview->transferTime) == "") { ?>
		<th class="<?php echo $merchantsales_preview->transferTime->headerCellClass() ?>"><?php echo $merchantsales_preview->transferTime->caption() ?></th>
	<?php } else { ?>
		<th class="<?php echo $merchantsales_preview->transferTime->headerCellClass() ?>"><div class="ew-pointer" data-sort="<?php echo HtmlEncode($merchantsales_preview->transferTime->Name) ?>" data-sort-order="<?php echo $merchantsales_preview->SortField == $merchantsales_preview->transferTime->Name && $merchantsales_preview->SortOrder == "ASC" ? "DESC" : "ASC" ?>">
			<div class="ew-table-header-btn"><span class="ew-table-header-caption"><?php echo $merchantsales_preview->transferTime->caption() ?></span><span class="ew-table-header-sort"><?php if ($merchantsales_preview->SortField == $merchantsales_preview->transferTime->Name) { ?><?php if ($merchantsales_preview->SortOrder == "ASC") { ?><i class="fas fa-sort-up"></i><?php } elseif ($merchantsales_preview->SortOrder == "DESC") { ?><i class="fas fa-sort-down"></i><?php } ?><?php } ?></span>
		</div></div></th>
	<?php } ?>
<?php } ?>
<?php if ($merchantsales_preview->currID->Visible) { // currID ?>
	<?php if ($merchantsales->SortUrl($merchantsales_preview->currID) == "") { ?>
		<th class="<?php echo $merchantsales_preview->currID->headerCellClass() ?>"><?php echo $merchantsales_preview->currID->caption() ?></th>
	<?php } else { ?>
		<th class="<?php echo $merchantsales_preview->currID->headerCellClass() ?>"><div class="ew-pointer" data-sort="<?php echo HtmlEncode($merchantsales_preview->currID->Name) ?>" data-sort-order="<?php echo $merchantsales_preview->SortField == $merchantsales_preview->currID->Name && $merchantsales_preview->SortOrder == "ASC" ? "DESC" : "ASC" ?>">
			<div class="ew-table-header-btn"><span class="ew-table-header-caption"><?php echo $merchantsales_preview->currID->caption() ?></span><span class="ew-table-header-sort"><?php if ($merchantsales_preview->SortField == $merchantsales_preview->currID->Name) { ?><?php if ($merchantsales_preview->SortOrder == "ASC") { ?><i class="fas fa-sort-up"></i><?php } elseif ($merchantsales_preview->SortOrder == "DESC") { ?><i class="fas fa-sort-down"></i><?php } ?><?php } ?></span>
		</div></div></th>
	<?php } ?>
<?php } ?>
<?php if ($merchantsales_preview->purchaseAmount->Visible) { // purchaseAmount ?>
	<?php if ($merchantsales->SortUrl($merchantsales_preview->purchaseAmount) == "") { ?>
		<th class="<?php echo $merchantsales_preview->purchaseAmount->headerCellClass() ?>"><?php echo $merchantsales_preview->purchaseAmount->caption() ?></th>
	<?php } else { ?>
		<th class="<?php echo $merchantsales_preview->purchaseAmount->headerCellClass() ?>"><div class="ew-pointer" data-sort="<?php echo HtmlEncode($merchantsales_preview->purchaseAmount->Name) ?>" data-sort-order="<?php echo $merchantsales_preview->SortField == $merchantsales_preview->purchaseAmount->Name && $merchantsales_preview->SortOrder == "ASC" ? "DESC" : "ASC" ?>">
			<div class="ew-table-header-btn"><span class="ew-table-header-caption"><?php echo $merchantsales_preview->purchaseAmount->caption() ?></span><span class="ew-table-header-sort"><?php if ($merchantsales_preview->SortField == $merchantsales_preview->purchaseAmount->Name) { ?><?php if ($merchantsales_preview->SortOrder == "ASC") { ?><i class="fas fa-sort-up"></i><?php } elseif ($merchantsales_preview->SortOrder == "DESC") { ?><i class="fas fa-sort-down"></i><?php } ?><?php } ?></span>
		</div></div></th>
	<?php } ?>
<?php } ?>
<?php if ($merchantsales_preview->serviceFeeToMerchant->Visible) { // serviceFeeToMerchant ?>
	<?php if ($merchantsales->SortUrl($merchantsales_preview->serviceFeeToMerchant) == "") { ?>
		<th class="<?php echo $merchantsales_preview->serviceFeeToMerchant->headerCellClass() ?>"><?php echo $merchantsales_preview->serviceFeeToMerchant->caption() ?></th>
	<?php } else { ?>
		<th class="<?php echo $merchantsales_preview->serviceFeeToMerchant->headerCellClass() ?>"><div class="ew-pointer" data-sort="<?php echo HtmlEncode($merchantsales_preview->serviceFeeToMerchant->Name) ?>" data-sort-order="<?php echo $merchantsales_preview->SortField == $merchantsales_preview->serviceFeeToMerchant->Name && $merchantsales_preview->SortOrder == "ASC" ? "DESC" : "ASC" ?>">
			<div class="ew-table-header-btn"><span class="ew-table-header-caption"><?php echo $merchantsales_preview->serviceFeeToMerchant->caption() ?></span><span class="ew-table-header-sort"><?php if ($merchantsales_preview->SortField == $merchantsales_preview->serviceFeeToMerchant->Name) { ?><?php if ($merchantsales_preview->SortOrder == "ASC") { ?><i class="fas fa-sort-up"></i><?php } elseif ($merchantsales_preview->SortOrder == "DESC") { ?><i class="fas fa-sort-down"></i><?php } ?><?php } ?></span>
		</div></div></th>
	<?php } ?>
<?php } ?>
<?php if ($merchantsales_preview->status->Visible) { // status ?>
	<?php if ($merchantsales->SortUrl($merchantsales_preview->status) == "") { ?>
		<th class="<?php echo $merchantsales_preview->status->headerCellClass() ?>"><?php echo $merchantsales_preview->status->caption() ?></th>
	<?php } else { ?>
		<th class="<?php echo $merchantsales_preview->status->headerCellClass() ?>"><div class="ew-pointer" data-sort="<?php echo HtmlEncode($merchantsales_preview->status->Name) ?>" data-sort-order="<?php echo $merchantsales_preview->SortField == $merchantsales_preview->status->Name && $merchantsales_preview->SortOrder == "ASC" ? "DESC" : "ASC" ?>">
			<div class="ew-table-header-btn"><span class="ew-table-header-caption"><?php echo $merchantsales_preview->status->caption() ?></span><span class="ew-table-header-sort"><?php if ($merchantsales_preview->SortField == $merchantsales_preview->status->Name) { ?><?php if ($merchantsales_preview->SortOrder == "ASC") { ?><i class="fas fa-sort-up"></i><?php } elseif ($merchantsales_preview->SortOrder == "DESC") { ?><i class="fas fa-sort-down"></i><?php } ?><?php } ?></span>
		</div></div></th>
	<?php } ?>
<?php } ?>
<?php

// Render list options (header, right)
$merchantsales_preview->ListOptions->render("header", "right");
?>
		</tr>
	</thead>
	<tbody><!-- Table body -->
<?php
$merchantsales_preview->RecCount = 0;
$merchantsales_preview->RowCount = 0;
while ($merchantsales_preview->Recordset && !$merchantsales_preview->Recordset->EOF) {

	// Init row class and style
	$merchantsales_preview->RecCount++;
	$merchantsales_preview->RowCount++;
	$merchantsales_preview->CssStyle = "";
	$merchantsales_preview->loadListRowValues($merchantsales_preview->Recordset);
	$merchantsales_preview->aggregateListRowValues(); // Aggregate row values

	// Render row
	$merchantsales->RowType = ROWTYPE_PREVIEW; // Preview record
	$merchantsales_preview->resetAttributes();
	$merchantsales_preview->renderListRow();

	// Render list options
	$merchantsales_preview->renderListOptions();
?>
	<tr <?php echo $merchantsales->rowAttributes() ?>>
<?php

// Render list options (body, left)
$merchantsales_preview->ListOptions->render("body", "left", $merchantsales_preview->RowCount);
?>
<?php if ($merchantsales_preview->transferID->Visible) { // transferID ?>
		<!-- transferID -->
		<td<?php echo $merchantsales_preview->transferID->cellAttributes() ?>>
<span<?php echo $merchantsales_preview->transferID->viewAttributes() ?>><?php echo $merchantsales_preview->transferID->getViewValue() ?></span>
</td>
<?php } ?>
<?php if ($merchantsales_preview->txid->Visible) { // txid ?>
		<!-- txid -->
		<td<?php echo $merchantsales_preview->txid->cellAttributes() ?>>
<span<?php echo $merchantsales_preview->txid->viewAttributes() ?>><?php echo $merchantsales_preview->txid->getViewValue() ?></span>
</td>
<?php } ?>
<?php if ($merchantsales_preview->merchantID->Visible) { // merchantID ?>
		<!-- merchantID -->
		<td<?php echo $merchantsales_preview->merchantID->cellAttributes() ?>>
<span<?php echo $merchantsales_preview->merchantID->viewAttributes() ?>><?php echo $merchantsales_preview->merchantID->getViewValue() ?></span>
</td>
<?php } ?>
<?php if ($merchantsales_preview->_userID->Visible) { // userID ?>
		<!-- userID -->
		<td<?php echo $merchantsales_preview->_userID->cellAttributes() ?>>
<span<?php echo $merchantsales_preview->_userID->viewAttributes() ?>><?php echo $merchantsales_preview->_userID->getViewValue() ?></span>
</td>
<?php } ?>
<?php if ($merchantsales_preview->transferTime->Visible) { // transferTime ?>
		<!-- transferTime -->
		<td<?php echo $merchantsales_preview->transferTime->cellAttributes() ?>>
<span<?php echo $merchantsales_preview->transferTime->viewAttributes() ?>><?php echo $merchantsales_preview->transferTime->getViewValue() ?></span>
</td>
<?php } ?>
<?php if ($merchantsales_preview->currID->Visible) { // currID ?>
		<!-- currID -->
		<td<?php echo $merchantsales_preview->currID->cellAttributes() ?>>
<span<?php echo $merchantsales_preview->currID->viewAttributes() ?>><?php echo $merchantsales_preview->currID->getViewValue() ?></span>
</td>
<?php } ?>
<?php if ($merchantsales_preview->purchaseAmount->Visible) { // purchaseAmount ?>
		<!-- purchaseAmount -->
		<td<?php echo $merchantsales_preview->purchaseAmount->cellAttributes() ?>>
<span<?php echo $merchantsales_preview->purchaseAmount->viewAttributes() ?>><?php echo $merchantsales_preview->purchaseAmount->getViewValue() ?></span>
</td>
<?php } ?>
<?php if ($merchantsales_preview->serviceFeeToMerchant->Visible) { // serviceFeeToMerchant ?>
		<!-- serviceFeeToMerchant -->
		<td<?php echo $merchantsales_preview->serviceFeeToMerchant->cellAttributes() ?>>
<span<?php echo $merchantsales_preview->serviceFeeToMerchant->viewAttributes() ?>><?php echo $merchantsales_preview->serviceFeeToMerchant->getViewValue() ?></span>
</td>
<?php } ?>
<?php if ($merchantsales_preview->status->Visible) { // status ?>
		<!-- status -->
		<td<?php echo $merchantsales_preview->status->cellAttributes() ?>>
<span<?php echo $merchantsales_preview->status->viewAttributes() ?>><?php echo $merchantsales_preview->status->getViewValue() ?></span>
</td>
<?php } ?>
<?php

// Render list options (body, right)
$merchantsales_preview->ListOptions->render("body", "right", $merchantsales_preview->RowCount);
?>
	</tr>
<?php
	$merchantsales_preview->Recordset->MoveNext();
} // while
?>
	</tbody>
<?php

	// Render aggregate row
	$merchantsales->RowType = ROWTYPE_AGGREGATE; // Aggregate
	$merchantsales_preview->aggregateListRow(); // Prepare aggregate row

	// Render list options
	$merchantsales_preview->renderListOptions();
?>
	<tfoot><!-- Table footer -->
	<tr class="ew-table-footer">
<?php

// Render list options (footer, left)
$merchantsales_preview->ListOptions->render("footer", "left");
?>
<?php if ($merchantsales_preview->transferID->Visible) { // transferID ?>
		<!-- transferID -->
		<td class="<?php echo $merchantsales_preview->transferID->footerCellClass() ?>">
		&nbsp;
		</td>
<?php } ?>
<?php if ($merchantsales_preview->txid->Visible) { // txid ?>
		<!-- txid -->
		<td class="<?php echo $merchantsales_preview->txid->footerCellClass() ?>">
		&nbsp;
		</td>
<?php } ?>
<?php if ($merchantsales_preview->merchantID->Visible) { // merchantID ?>
		<!-- merchantID -->
		<td class="<?php echo $merchantsales_preview->merchantID->footerCellClass() ?>">
		&nbsp;
		</td>
<?php } ?>
<?php if ($merchantsales_preview->_userID->Visible) { // userID ?>
		<!-- userID -->
		<td class="<?php echo $merchantsales_preview->_userID->footerCellClass() ?>">
		&nbsp;
		</td>
<?php } ?>
<?php if ($merchantsales_preview->transferTime->Visible) { // transferTime ?>
		<!-- transferTime -->
		<td class="<?php echo $merchantsales_preview->transferTime->footerCellClass() ?>">
		&nbsp;
		</td>
<?php } ?>
<?php if ($merchantsales_preview->currID->Visible) { // currID ?>
		<!-- currID -->
		<td class="<?php echo $merchantsales_preview->currID->footerCellClass() ?>">
		&nbsp;
		</td>
<?php } ?>
<?php if ($merchantsales_preview->purchaseAmount->Visible) { // purchaseAmount ?>
		<!-- purchaseAmount -->
		<td class="<?php echo $merchantsales_preview->purchaseAmount->footerCellClass() ?>">
		<span class="ew-aggregate"><?php echo $Language->phrase("TOTAL") ?></span><span class="ew-aggregate-value">
		<?php echo $merchantsales_preview->purchaseAmount->ViewValue ?></span>
		</td>
<?php } ?>
<?php if ($merchantsales_preview->serviceFeeToMerchant->Visible) { // serviceFeeToMerchant ?>
		<!-- serviceFeeToMerchant -->
		<td class="<?php echo $merchantsales_preview->serviceFeeToMerchant->footerCellClass() ?>">
		<span class="ew-aggregate"><?php echo $Language->phrase("TOTAL") ?></span><span class="ew-aggregate-value">
		<?php echo $merchantsales_preview->serviceFeeToMerchant->ViewValue ?></span>
		</td>
<?php } ?>
<?php if ($merchantsales_preview->status->Visible) { // status ?>
		<!-- status -->
		<td class="<?php echo $merchantsales_preview->status->footerCellClass() ?>">
		&nbsp;
		</td>
<?php } ?>
<?php

// Render list options (footer, right)
$merchantsales_preview->ListOptions->render("footer", "right");
?>
	</tr>
	</tfoot>
</table><!-- /.table -->
</div><!-- /.table-responsive -->
<div class="card-footer ew-grid-lower-panel ew-preview-lower-panel"><!-- .card-footer -->
<?php echo $merchantsales_preview->Pager->render() ?>
<?php } else { // No record ?>
<div class="card no-border">
<div class="ew-detail-count"><?php echo $Language->phrase("NoRecord") ?></div>
<?php } ?>
<div class="ew-preview-other-options">
<?php
	foreach ($merchantsales_preview->OtherOptions as $option)
		$option->render("body");
?>
</div>
<?php if ($merchantsales_preview->TotalRecords > 0) { ?>
<div class="clearfix"></div>
</div><!-- /.card-footer -->
<?php } ?>
</div><!-- /.card -->
<?php
$merchantsales_preview->showPageFooter();
if (Config("DEBUG"))
	echo GetDebugMessage();
?>
<?php
if ($merchantsales_preview->Recordset)
	$merchantsales_preview->Recordset->Close();

// Output
$content = ob_get_contents();
ob_end_clean();
echo ConvertToUtf8($content);
?>
<?php
$merchantsales_preview->terminate();
?>