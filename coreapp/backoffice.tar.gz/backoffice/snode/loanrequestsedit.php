<?php
namespace PHPMaker2020\_4payadmin;

// Autoload
include_once "autoload.php";

// Session
if (session_status() !== PHP_SESSION_ACTIVE)
	\Delight\Cookie\Session::start(Config("COOKIE_SAMESITE")); // Init session data

// Output buffering
ob_start();
?>
<?php

// Write header
WriteHeader(FALSE);

// Create page object
$loanrequests_edit = new loanrequests_edit();

// Run the page
$loanrequests_edit->run();

// Setup login status
SetupLoginStatus();
SetClientVar("login", LoginStatus());

// Global Page Rendering event (in userfn*.php)
Page_Rendering();

// Page Rendering event
$loanrequests_edit->Page_Render();
?>
<?php include_once "header.php"; ?>
<script>
var floanrequestsedit, currentPageID;
loadjs.ready("head", function() {

	// Form object
	currentPageID = ew.PAGE_ID = "edit";
	floanrequestsedit = currentForm = new ew.Form("floanrequestsedit", "edit");

	// Validate form
	floanrequestsedit.validate = function() {
		if (!this.validateRequired)
			return true; // Ignore validation
		var $ = jQuery, fobj = this.getForm(), $fobj = $(fobj);
		if ($fobj.find("#confirm").val() == "confirm")
			return true;
		var elm, felm, uelm, addcnt = 0;
		var $k = $fobj.find("#" + this.formKeyCountName); // Get key_count
		var rowcnt = ($k[0]) ? parseInt($k.val(), 10) : 1;
		var startcnt = (rowcnt == 0) ? 0 : 1; // Check rowcnt == 0 => Inline-Add
		var gridinsert = ["insert", "gridinsert"].includes($fobj.find("#action").val()) && $k[0];
		for (var i = startcnt; i <= rowcnt; i++) {
			var infix = ($k[0]) ? String(i) : "";
			$fobj.data("rowindex", infix);
			<?php if ($loanrequests_edit->requestid->Required) { ?>
				elm = this.getElements("x" + infix + "_requestid");
				if (elm && !ew.isHidden(elm) && !ew.hasValue(elm))
					return this.onError(elm, "<?php echo JsEncode(str_replace("%s", $loanrequests_edit->requestid->caption(), $loanrequests_edit->requestid->RequiredErrorMessage)) ?>");
			<?php } ?>
			<?php if ($loanrequests_edit->requestdate->Required) { ?>
				elm = this.getElements("x" + infix + "_requestdate");
				if (elm && !ew.isHidden(elm) && !ew.hasValue(elm))
					return this.onError(elm, "<?php echo JsEncode(str_replace("%s", $loanrequests_edit->requestdate->caption(), $loanrequests_edit->requestdate->RequiredErrorMessage)) ?>");
			<?php } ?>
				elm = this.getElements("x" + infix + "_requestdate");
				if (elm && !ew.checkDateDef(elm.value))
					return this.onError(elm, "<?php echo JsEncode($loanrequests_edit->requestdate->errorMessage()) ?>");
			<?php if ($loanrequests_edit->_userid->Required) { ?>
				elm = this.getElements("x" + infix + "__userid");
				if (elm && !ew.isHidden(elm) && !ew.hasValue(elm))
					return this.onError(elm, "<?php echo JsEncode(str_replace("%s", $loanrequests_edit->_userid->caption(), $loanrequests_edit->_userid->RequiredErrorMessage)) ?>");
			<?php } ?>
				elm = this.getElements("x" + infix + "__userid");
				if (elm && !ew.checkInteger(elm.value))
					return this.onError(elm, "<?php echo JsEncode($loanrequests_edit->_userid->errorMessage()) ?>");
			<?php if ($loanrequests_edit->currcode->Required) { ?>
				elm = this.getElements("x" + infix + "_currcode");
				if (elm && !ew.isHidden(elm) && !ew.hasValue(elm))
					return this.onError(elm, "<?php echo JsEncode(str_replace("%s", $loanrequests_edit->currcode->caption(), $loanrequests_edit->currcode->RequiredErrorMessage)) ?>");
			<?php } ?>
			<?php if ($loanrequests_edit->requestamount->Required) { ?>
				elm = this.getElements("x" + infix + "_requestamount");
				if (elm && !ew.isHidden(elm) && !ew.hasValue(elm))
					return this.onError(elm, "<?php echo JsEncode(str_replace("%s", $loanrequests_edit->requestamount->caption(), $loanrequests_edit->requestamount->RequiredErrorMessage)) ?>");
			<?php } ?>
				elm = this.getElements("x" + infix + "_requestamount");
				if (elm && !ew.checkNumber(elm.value))
					return this.onError(elm, "<?php echo JsEncode($loanrequests_edit->requestamount->errorMessage()) ?>");
			<?php if ($loanrequests_edit->requestoruserid->Required) { ?>
				elm = this.getElements("x" + infix + "_requestoruserid");
				if (elm && !ew.isHidden(elm) && !ew.hasValue(elm))
					return this.onError(elm, "<?php echo JsEncode(str_replace("%s", $loanrequests_edit->requestoruserid->caption(), $loanrequests_edit->requestoruserid->RequiredErrorMessage)) ?>");
			<?php } ?>
				elm = this.getElements("x" + infix + "_requestoruserid");
				if (elm && !ew.checkInteger(elm.value))
					return this.onError(elm, "<?php echo JsEncode($loanrequests_edit->requestoruserid->errorMessage()) ?>");
			<?php if ($loanrequests_edit->externalrefno->Required) { ?>
				elm = this.getElements("x" + infix + "_externalrefno");
				if (elm && !ew.isHidden(elm) && !ew.hasValue(elm))
					return this.onError(elm, "<?php echo JsEncode(str_replace("%s", $loanrequests_edit->externalrefno->caption(), $loanrequests_edit->externalrefno->RequiredErrorMessage)) ?>");
			<?php } ?>
			<?php if ($loanrequests_edit->currentlimit->Required) { ?>
				elm = this.getElements("x" + infix + "_currentlimit");
				if (elm && !ew.isHidden(elm) && !ew.hasValue(elm))
					return this.onError(elm, "<?php echo JsEncode(str_replace("%s", $loanrequests_edit->currentlimit->caption(), $loanrequests_edit->currentlimit->RequiredErrorMessage)) ?>");
			<?php } ?>
				elm = this.getElements("x" + infix + "_currentlimit");
				if (elm && !ew.checkNumber(elm.value))
					return this.onError(elm, "<?php echo JsEncode($loanrequests_edit->currentlimit->errorMessage()) ?>");
			<?php if ($loanrequests_edit->currentoutstandingloan->Required) { ?>
				elm = this.getElements("x" + infix + "_currentoutstandingloan");
				if (elm && !ew.isHidden(elm) && !ew.hasValue(elm))
					return this.onError(elm, "<?php echo JsEncode(str_replace("%s", $loanrequests_edit->currentoutstandingloan->caption(), $loanrequests_edit->currentoutstandingloan->RequiredErrorMessage)) ?>");
			<?php } ?>
				elm = this.getElements("x" + infix + "_currentoutstandingloan");
				if (elm && !ew.checkNumber(elm.value))
					return this.onError(elm, "<?php echo JsEncode($loanrequests_edit->currentoutstandingloan->errorMessage()) ?>");
			<?php if ($loanrequests_edit->issued->Required) { ?>
				elm = this.getElements("x" + infix + "_issued");
				if (elm && !ew.isHidden(elm) && !ew.hasValue(elm))
					return this.onError(elm, "<?php echo JsEncode(str_replace("%s", $loanrequests_edit->issued->caption(), $loanrequests_edit->issued->RequiredErrorMessage)) ?>");
			<?php } ?>
			<?php if ($loanrequests_edit->loanid->Required) { ?>
				elm = this.getElements("x" + infix + "_loanid");
				if (elm && !ew.isHidden(elm) && !ew.hasValue(elm))
					return this.onError(elm, "<?php echo JsEncode(str_replace("%s", $loanrequests_edit->loanid->caption(), $loanrequests_edit->loanid->RequiredErrorMessage)) ?>");
			<?php } ?>
				elm = this.getElements("x" + infix + "_loanid");
				if (elm && !ew.checkInteger(elm.value))
					return this.onError(elm, "<?php echo JsEncode($loanrequests_edit->loanid->errorMessage()) ?>");
			<?php if ($loanrequests_edit->comments->Required) { ?>
				elm = this.getElements("x" + infix + "_comments");
				if (elm && !ew.isHidden(elm) && !ew.hasValue(elm))
					return this.onError(elm, "<?php echo JsEncode(str_replace("%s", $loanrequests_edit->comments->caption(), $loanrequests_edit->comments->RequiredErrorMessage)) ?>");
			<?php } ?>
			<?php if ($loanrequests_edit->loantype->Required) { ?>
				elm = this.getElements("x" + infix + "_loantype");
				if (elm && !ew.isHidden(elm) && !ew.hasValue(elm))
					return this.onError(elm, "<?php echo JsEncode(str_replace("%s", $loanrequests_edit->loantype->caption(), $loanrequests_edit->loantype->RequiredErrorMessage)) ?>");
			<?php } ?>
			<?php if ($loanrequests_edit->amountforfeecalculation->Required) { ?>
				elm = this.getElements("x" + infix + "_amountforfeecalculation");
				if (elm && !ew.isHidden(elm) && !ew.hasValue(elm))
					return this.onError(elm, "<?php echo JsEncode(str_replace("%s", $loanrequests_edit->amountforfeecalculation->caption(), $loanrequests_edit->amountforfeecalculation->RequiredErrorMessage)) ?>");
			<?php } ?>
				elm = this.getElements("x" + infix + "_amountforfeecalculation");
				if (elm && !ew.checkNumber(elm.value))
					return this.onError(elm, "<?php echo JsEncode($loanrequests_edit->amountforfeecalculation->errorMessage()) ?>");
			<?php if ($loanrequests_edit->approveddate->Required) { ?>
				elm = this.getElements("x" + infix + "_approveddate");
				if (elm && !ew.isHidden(elm) && !ew.hasValue(elm))
					return this.onError(elm, "<?php echo JsEncode(str_replace("%s", $loanrequests_edit->approveddate->caption(), $loanrequests_edit->approveddate->RequiredErrorMessage)) ?>");
			<?php } ?>
				elm = this.getElements("x" + infix + "_approveddate");
				if (elm && !ew.checkDateDef(elm.value))
					return this.onError(elm, "<?php echo JsEncode($loanrequests_edit->approveddate->errorMessage()) ?>");
			<?php if ($loanrequests_edit->approvedby->Required) { ?>
				elm = this.getElements("x" + infix + "_approvedby");
				if (elm && !ew.isHidden(elm) && !ew.hasValue(elm))
					return this.onError(elm, "<?php echo JsEncode(str_replace("%s", $loanrequests_edit->approvedby->caption(), $loanrequests_edit->approvedby->RequiredErrorMessage)) ?>");
			<?php } ?>
				elm = this.getElements("x" + infix + "_approvedby");
				if (elm && !ew.checkInteger(elm.value))
					return this.onError(elm, "<?php echo JsEncode($loanrequests_edit->approvedby->errorMessage()) ?>");
			<?php if ($loanrequests_edit->overriddeninterestamount->Required) { ?>
				elm = this.getElements("x" + infix + "_overriddeninterestamount");
				if (elm && !ew.isHidden(elm) && !ew.hasValue(elm))
					return this.onError(elm, "<?php echo JsEncode(str_replace("%s", $loanrequests_edit->overriddeninterestamount->caption(), $loanrequests_edit->overriddeninterestamount->RequiredErrorMessage)) ?>");
			<?php } ?>
				elm = this.getElements("x" + infix + "_overriddeninterestamount");
				if (elm && !ew.checkNumber(elm.value))
					return this.onError(elm, "<?php echo JsEncode($loanrequests_edit->overriddeninterestamount->errorMessage()) ?>");
			<?php if ($loanrequests_edit->overrideinterest->Required) { ?>
				elm = this.getElements("x" + infix + "_overrideinterest");
				if (elm && !ew.isHidden(elm) && !ew.hasValue(elm))
					return this.onError(elm, "<?php echo JsEncode(str_replace("%s", $loanrequests_edit->overrideinterest->caption(), $loanrequests_edit->overrideinterest->RequiredErrorMessage)) ?>");
			<?php } ?>
			<?php if ($loanrequests_edit->otherdetails->Required) { ?>
				elm = this.getElements("x" + infix + "_otherdetails");
				if (elm && !ew.isHidden(elm) && !ew.hasValue(elm))
					return this.onError(elm, "<?php echo JsEncode(str_replace("%s", $loanrequests_edit->otherdetails->caption(), $loanrequests_edit->otherdetails->RequiredErrorMessage)) ?>");
			<?php } ?>
			<?php if ($loanrequests_edit->termtype->Required) { ?>
				elm = this.getElements("x" + infix + "_termtype");
				if (elm && !ew.isHidden(elm) && !ew.hasValue(elm))
					return this.onError(elm, "<?php echo JsEncode(str_replace("%s", $loanrequests_edit->termtype->caption(), $loanrequests_edit->termtype->RequiredErrorMessage)) ?>");
			<?php } ?>

				// Call Form_CustomValidate event
				if (!this.Form_CustomValidate(fobj))
					return false;
		}

		// Process detail forms
		var dfs = $fobj.find("input[name='detailpage']").get();
		for (var i = 0; i < dfs.length; i++) {
			var df = dfs[i], val = df.value;
			if (val && ew.forms[val])
				if (!ew.forms[val].validate())
					return false;
		}
		return true;
	}

	// Form_CustomValidate
	floanrequestsedit.Form_CustomValidate = function(fobj) { // DO NOT CHANGE THIS LINE!

		// Your custom validation code here, return false if invalid.
		return true;
	}

	// Use JavaScript validation or not
	floanrequestsedit.validateRequired = <?php echo Config("CLIENT_VALIDATE") ? "true" : "false" ?>;

	// Dynamic selection lists
	floanrequestsedit.lists["x_currcode"] = <?php echo $loanrequests_edit->currcode->Lookup->toClientList($loanrequests_edit) ?>;
	floanrequestsedit.lists["x_currcode"].options = <?php echo JsonEncode($loanrequests_edit->currcode->lookupOptions()) ?>;
	floanrequestsedit.lists["x_issued"] = <?php echo $loanrequests_edit->issued->Lookup->toClientList($loanrequests_edit) ?>;
	floanrequestsedit.lists["x_issued"].options = <?php echo JsonEncode($loanrequests_edit->issued->options(FALSE, TRUE)) ?>;
	floanrequestsedit.lists["x_loantype"] = <?php echo $loanrequests_edit->loantype->Lookup->toClientList($loanrequests_edit) ?>;
	floanrequestsedit.lists["x_loantype"].options = <?php echo JsonEncode($loanrequests_edit->loantype->lookupOptions()) ?>;
	floanrequestsedit.lists["x_overrideinterest"] = <?php echo $loanrequests_edit->overrideinterest->Lookup->toClientList($loanrequests_edit) ?>;
	floanrequestsedit.lists["x_overrideinterest"].options = <?php echo JsonEncode($loanrequests_edit->overrideinterest->lookupOptions()) ?>;
	floanrequestsedit.lists["x_termtype"] = <?php echo $loanrequests_edit->termtype->Lookup->toClientList($loanrequests_edit) ?>;
	floanrequestsedit.lists["x_termtype"].options = <?php echo JsonEncode($loanrequests_edit->termtype->options(FALSE, TRUE)) ?>;
	loadjs.done("floanrequestsedit");
});
</script>
<script>
loadjs.ready("head", function() {

	// Client script
	// Write your client script here, no need to add script tags.

});
</script>
<?php $loanrequests_edit->showPageHeader(); ?>
<?php
$loanrequests_edit->showMessage();
?>
<form name="floanrequestsedit" id="floanrequestsedit" class="<?php echo $loanrequests_edit->FormClassName ?>" action="<?php echo CurrentPageName() ?>" method="post">
<?php if ($Page->CheckToken) { ?>
<input type="hidden" name="<?php echo Config("TOKEN_NAME") ?>" value="<?php echo $Page->Token ?>">
<?php } ?>
<input type="hidden" name="t" value="loanrequests">
<input type="hidden" name="action" id="action" value="update">
<input type="hidden" name="modal" value="<?php echo (int)$loanrequests_edit->IsModal ?>">
<?php if ($loanrequests->getCurrentMasterTable() == "loanlimits") { ?>
<input type="hidden" name="<?php echo Config("TABLE_SHOW_MASTER") ?>" value="loanlimits">
<input type="hidden" name="fk__userid" value="<?php echo HtmlEncode($loanrequests_edit->_userid->getSessionValue()) ?>">
<input type="hidden" name="fk_currcode" value="<?php echo HtmlEncode($loanrequests_edit->currcode->getSessionValue()) ?>">
<?php } ?>
<div class="ew-edit-div"><!-- page* -->
<?php if ($loanrequests_edit->requestid->Visible) { // requestid ?>
	<div id="r_requestid" class="form-group row">
		<label id="elh_loanrequests_requestid" class="<?php echo $loanrequests_edit->LeftColumnClass ?>"><?php echo $loanrequests_edit->requestid->caption() ?><?php echo $loanrequests_edit->requestid->Required ? $Language->phrase("FieldRequiredIndicator") : "" ?></label>
		<div class="<?php echo $loanrequests_edit->RightColumnClass ?>"><div <?php echo $loanrequests_edit->requestid->cellAttributes() ?>>
<span id="el_loanrequests_requestid">
<span<?php echo $loanrequests_edit->requestid->viewAttributes() ?>><input type="text" readonly class="form-control-plaintext" value="<?php echo HtmlEncode(RemoveHtml($loanrequests_edit->requestid->EditValue)) ?>"></span>
</span>
<input type="hidden" data-table="loanrequests" data-field="x_requestid" name="x_requestid" id="x_requestid" value="<?php echo HtmlEncode($loanrequests_edit->requestid->CurrentValue) ?>">
<?php echo $loanrequests_edit->requestid->CustomMsg ?></div></div>
	</div>
<?php } ?>
<?php if ($loanrequests_edit->requestdate->Visible) { // requestdate ?>
	<div id="r_requestdate" class="form-group row">
		<label id="elh_loanrequests_requestdate" for="x_requestdate" class="<?php echo $loanrequests_edit->LeftColumnClass ?>"><?php echo $loanrequests_edit->requestdate->caption() ?><?php echo $loanrequests_edit->requestdate->Required ? $Language->phrase("FieldRequiredIndicator") : "" ?></label>
		<div class="<?php echo $loanrequests_edit->RightColumnClass ?>"><div <?php echo $loanrequests_edit->requestdate->cellAttributes() ?>>
<span id="el_loanrequests_requestdate">
<input type="text" data-table="loanrequests" data-field="x_requestdate" data-format="1" name="x_requestdate" id="x_requestdate" placeholder="<?php echo HtmlEncode($loanrequests_edit->requestdate->getPlaceHolder()) ?>" value="<?php echo $loanrequests_edit->requestdate->EditValue ?>"<?php echo $loanrequests_edit->requestdate->editAttributes() ?>>
<?php if (!$loanrequests_edit->requestdate->ReadOnly && !$loanrequests_edit->requestdate->Disabled && !isset($loanrequests_edit->requestdate->EditAttrs["readonly"]) && !isset($loanrequests_edit->requestdate->EditAttrs["disabled"])) { ?>
<script>
loadjs.ready(["floanrequestsedit", "datetimepicker"], function() {
	ew.createDateTimePicker("floanrequestsedit", "x_requestdate", {"ignoreReadonly":true,"useCurrent":false,"format":1});
});
</script>
<?php } ?>
</span>
<?php echo $loanrequests_edit->requestdate->CustomMsg ?></div></div>
	</div>
<?php } ?>
<?php if ($loanrequests_edit->_userid->Visible) { // userid ?>
	<div id="r__userid" class="form-group row">
		<label id="elh_loanrequests__userid" for="x__userid" class="<?php echo $loanrequests_edit->LeftColumnClass ?>"><?php echo $loanrequests_edit->_userid->caption() ?><?php echo $loanrequests_edit->_userid->Required ? $Language->phrase("FieldRequiredIndicator") : "" ?></label>
		<div class="<?php echo $loanrequests_edit->RightColumnClass ?>"><div <?php echo $loanrequests_edit->_userid->cellAttributes() ?>>
<?php if ($loanrequests_edit->_userid->getSessionValue() != "") { ?>
<span id="el_loanrequests__userid">
<span<?php echo $loanrequests_edit->_userid->viewAttributes() ?>><?php if (!EmptyString($loanrequests_edit->_userid->ViewValue) && $loanrequests_edit->_userid->linkAttributes() != "") { ?>
<a<?php echo $loanrequests_edit->_userid->linkAttributes() ?>><input type="text" readonly class="form-control-plaintext" value="<?php echo HtmlEncode(RemoveHtml($loanrequests_edit->_userid->ViewValue)) ?>"></a>
<?php } else { ?>
<input type="text" readonly class="form-control-plaintext" value="<?php echo HtmlEncode(RemoveHtml($loanrequests_edit->_userid->ViewValue)) ?>">
<?php } ?></span>
</span>
<input type="hidden" id="x__userid" name="x__userid" value="<?php echo HtmlEncode($loanrequests_edit->_userid->CurrentValue) ?>">
<?php } else { ?>
<span id="el_loanrequests__userid">
<input type="text" data-table="loanrequests" data-field="x__userid" name="x__userid" id="x__userid" size="30" placeholder="<?php echo HtmlEncode($loanrequests_edit->_userid->getPlaceHolder()) ?>" value="<?php echo $loanrequests_edit->_userid->EditValue ?>"<?php echo $loanrequests_edit->_userid->editAttributes() ?>>
</span>
<?php } ?>
<?php echo $loanrequests_edit->_userid->CustomMsg ?></div></div>
	</div>
<?php } ?>
<?php if ($loanrequests_edit->currcode->Visible) { // currcode ?>
	<div id="r_currcode" class="form-group row">
		<label id="elh_loanrequests_currcode" for="x_currcode" class="<?php echo $loanrequests_edit->LeftColumnClass ?>"><?php echo $loanrequests_edit->currcode->caption() ?><?php echo $loanrequests_edit->currcode->Required ? $Language->phrase("FieldRequiredIndicator") : "" ?></label>
		<div class="<?php echo $loanrequests_edit->RightColumnClass ?>"><div <?php echo $loanrequests_edit->currcode->cellAttributes() ?>>
<?php if ($loanrequests_edit->currcode->getSessionValue() != "") { ?>
<span id="el_loanrequests_currcode">
<span<?php echo $loanrequests_edit->currcode->viewAttributes() ?>><input type="text" readonly class="form-control-plaintext" value="<?php echo HtmlEncode(RemoveHtml($loanrequests_edit->currcode->ViewValue)) ?>"></span>
</span>
<input type="hidden" id="x_currcode" name="x_currcode" value="<?php echo HtmlEncode($loanrequests_edit->currcode->CurrentValue) ?>">
<?php } else { ?>
<span id="el_loanrequests_currcode">
<div class="input-group">
	<select class="custom-select ew-custom-select" data-table="loanrequests" data-field="x_currcode" data-value-separator="<?php echo $loanrequests_edit->currcode->displayValueSeparatorAttribute() ?>" id="x_currcode" name="x_currcode"<?php echo $loanrequests_edit->currcode->editAttributes() ?>>
			<?php echo $loanrequests_edit->currcode->selectOptionListHtml("x_currcode") ?>
		</select>
</div>
<?php echo $loanrequests_edit->currcode->Lookup->getParamTag($loanrequests_edit, "p_x_currcode") ?>
</span>
<?php } ?>
<?php echo $loanrequests_edit->currcode->CustomMsg ?></div></div>
	</div>
<?php } ?>
<?php if ($loanrequests_edit->requestamount->Visible) { // requestamount ?>
	<div id="r_requestamount" class="form-group row">
		<label id="elh_loanrequests_requestamount" for="x_requestamount" class="<?php echo $loanrequests_edit->LeftColumnClass ?>"><?php echo $loanrequests_edit->requestamount->caption() ?><?php echo $loanrequests_edit->requestamount->Required ? $Language->phrase("FieldRequiredIndicator") : "" ?></label>
		<div class="<?php echo $loanrequests_edit->RightColumnClass ?>"><div <?php echo $loanrequests_edit->requestamount->cellAttributes() ?>>
<span id="el_loanrequests_requestamount">
<input type="text" data-table="loanrequests" data-field="x_requestamount" name="x_requestamount" id="x_requestamount" size="30" placeholder="<?php echo HtmlEncode($loanrequests_edit->requestamount->getPlaceHolder()) ?>" value="<?php echo $loanrequests_edit->requestamount->EditValue ?>"<?php echo $loanrequests_edit->requestamount->editAttributes() ?>>
</span>
<?php echo $loanrequests_edit->requestamount->CustomMsg ?></div></div>
	</div>
<?php } ?>
<?php if ($loanrequests_edit->requestoruserid->Visible) { // requestoruserid ?>
	<div id="r_requestoruserid" class="form-group row">
		<label id="elh_loanrequests_requestoruserid" for="x_requestoruserid" class="<?php echo $loanrequests_edit->LeftColumnClass ?>"><?php echo $loanrequests_edit->requestoruserid->caption() ?><?php echo $loanrequests_edit->requestoruserid->Required ? $Language->phrase("FieldRequiredIndicator") : "" ?></label>
		<div class="<?php echo $loanrequests_edit->RightColumnClass ?>"><div <?php echo $loanrequests_edit->requestoruserid->cellAttributes() ?>>
<span id="el_loanrequests_requestoruserid">
<input type="text" data-table="loanrequests" data-field="x_requestoruserid" name="x_requestoruserid" id="x_requestoruserid" size="30" placeholder="<?php echo HtmlEncode($loanrequests_edit->requestoruserid->getPlaceHolder()) ?>" value="<?php echo $loanrequests_edit->requestoruserid->EditValue ?>"<?php echo $loanrequests_edit->requestoruserid->editAttributes() ?>>
</span>
<?php echo $loanrequests_edit->requestoruserid->CustomMsg ?></div></div>
	</div>
<?php } ?>
<?php if ($loanrequests_edit->externalrefno->Visible) { // externalrefno ?>
	<div id="r_externalrefno" class="form-group row">
		<label id="elh_loanrequests_externalrefno" for="x_externalrefno" class="<?php echo $loanrequests_edit->LeftColumnClass ?>"><?php echo $loanrequests_edit->externalrefno->caption() ?><?php echo $loanrequests_edit->externalrefno->Required ? $Language->phrase("FieldRequiredIndicator") : "" ?></label>
		<div class="<?php echo $loanrequests_edit->RightColumnClass ?>"><div <?php echo $loanrequests_edit->externalrefno->cellAttributes() ?>>
<span id="el_loanrequests_externalrefno">
<input type="text" data-table="loanrequests" data-field="x_externalrefno" name="x_externalrefno" id="x_externalrefno" size="30" maxlength="40" placeholder="<?php echo HtmlEncode($loanrequests_edit->externalrefno->getPlaceHolder()) ?>" value="<?php echo $loanrequests_edit->externalrefno->EditValue ?>"<?php echo $loanrequests_edit->externalrefno->editAttributes() ?>>
</span>
<?php echo $loanrequests_edit->externalrefno->CustomMsg ?></div></div>
	</div>
<?php } ?>
<?php if ($loanrequests_edit->currentlimit->Visible) { // currentlimit ?>
	<div id="r_currentlimit" class="form-group row">
		<label id="elh_loanrequests_currentlimit" for="x_currentlimit" class="<?php echo $loanrequests_edit->LeftColumnClass ?>"><?php echo $loanrequests_edit->currentlimit->caption() ?><?php echo $loanrequests_edit->currentlimit->Required ? $Language->phrase("FieldRequiredIndicator") : "" ?></label>
		<div class="<?php echo $loanrequests_edit->RightColumnClass ?>"><div <?php echo $loanrequests_edit->currentlimit->cellAttributes() ?>>
<span id="el_loanrequests_currentlimit">
<input type="text" data-table="loanrequests" data-field="x_currentlimit" name="x_currentlimit" id="x_currentlimit" size="30" placeholder="<?php echo HtmlEncode($loanrequests_edit->currentlimit->getPlaceHolder()) ?>" value="<?php echo $loanrequests_edit->currentlimit->EditValue ?>"<?php echo $loanrequests_edit->currentlimit->editAttributes() ?>>
</span>
<?php echo $loanrequests_edit->currentlimit->CustomMsg ?></div></div>
	</div>
<?php } ?>
<?php if ($loanrequests_edit->currentoutstandingloan->Visible) { // currentoutstandingloan ?>
	<div id="r_currentoutstandingloan" class="form-group row">
		<label id="elh_loanrequests_currentoutstandingloan" for="x_currentoutstandingloan" class="<?php echo $loanrequests_edit->LeftColumnClass ?>"><?php echo $loanrequests_edit->currentoutstandingloan->caption() ?><?php echo $loanrequests_edit->currentoutstandingloan->Required ? $Language->phrase("FieldRequiredIndicator") : "" ?></label>
		<div class="<?php echo $loanrequests_edit->RightColumnClass ?>"><div <?php echo $loanrequests_edit->currentoutstandingloan->cellAttributes() ?>>
<span id="el_loanrequests_currentoutstandingloan">
<input type="text" data-table="loanrequests" data-field="x_currentoutstandingloan" name="x_currentoutstandingloan" id="x_currentoutstandingloan" size="30" placeholder="<?php echo HtmlEncode($loanrequests_edit->currentoutstandingloan->getPlaceHolder()) ?>" value="<?php echo $loanrequests_edit->currentoutstandingloan->EditValue ?>"<?php echo $loanrequests_edit->currentoutstandingloan->editAttributes() ?>>
</span>
<?php echo $loanrequests_edit->currentoutstandingloan->CustomMsg ?></div></div>
	</div>
<?php } ?>
<?php if ($loanrequests_edit->issued->Visible) { // issued ?>
	<div id="r_issued" class="form-group row">
		<label id="elh_loanrequests_issued" for="x_issued" class="<?php echo $loanrequests_edit->LeftColumnClass ?>"><?php echo $loanrequests_edit->issued->caption() ?><?php echo $loanrequests_edit->issued->Required ? $Language->phrase("FieldRequiredIndicator") : "" ?></label>
		<div class="<?php echo $loanrequests_edit->RightColumnClass ?>"><div <?php echo $loanrequests_edit->issued->cellAttributes() ?>>
<span id="el_loanrequests_issued">
<div class="input-group">
	<select class="custom-select ew-custom-select" data-table="loanrequests" data-field="x_issued" data-value-separator="<?php echo $loanrequests_edit->issued->displayValueSeparatorAttribute() ?>" id="x_issued" name="x_issued"<?php echo $loanrequests_edit->issued->editAttributes() ?>>
			<?php echo $loanrequests_edit->issued->selectOptionListHtml("x_issued") ?>
		</select>
</div>
</span>
<?php echo $loanrequests_edit->issued->CustomMsg ?></div></div>
	</div>
<?php } ?>
<?php if ($loanrequests_edit->loanid->Visible) { // loanid ?>
	<div id="r_loanid" class="form-group row">
		<label id="elh_loanrequests_loanid" for="x_loanid" class="<?php echo $loanrequests_edit->LeftColumnClass ?>"><?php echo $loanrequests_edit->loanid->caption() ?><?php echo $loanrequests_edit->loanid->Required ? $Language->phrase("FieldRequiredIndicator") : "" ?></label>
		<div class="<?php echo $loanrequests_edit->RightColumnClass ?>"><div <?php echo $loanrequests_edit->loanid->cellAttributes() ?>>
<span id="el_loanrequests_loanid">
<input type="text" data-table="loanrequests" data-field="x_loanid" name="x_loanid" id="x_loanid" size="30" placeholder="<?php echo HtmlEncode($loanrequests_edit->loanid->getPlaceHolder()) ?>" value="<?php echo $loanrequests_edit->loanid->EditValue ?>"<?php echo $loanrequests_edit->loanid->editAttributes() ?>>
</span>
<?php echo $loanrequests_edit->loanid->CustomMsg ?></div></div>
	</div>
<?php } ?>
<?php if ($loanrequests_edit->comments->Visible) { // comments ?>
	<div id="r_comments" class="form-group row">
		<label id="elh_loanrequests_comments" for="x_comments" class="<?php echo $loanrequests_edit->LeftColumnClass ?>"><?php echo $loanrequests_edit->comments->caption() ?><?php echo $loanrequests_edit->comments->Required ? $Language->phrase("FieldRequiredIndicator") : "" ?></label>
		<div class="<?php echo $loanrequests_edit->RightColumnClass ?>"><div <?php echo $loanrequests_edit->comments->cellAttributes() ?>>
<span id="el_loanrequests_comments">
<input type="text" data-table="loanrequests" data-field="x_comments" name="x_comments" id="x_comments" size="30" maxlength="50" placeholder="<?php echo HtmlEncode($loanrequests_edit->comments->getPlaceHolder()) ?>" value="<?php echo $loanrequests_edit->comments->EditValue ?>"<?php echo $loanrequests_edit->comments->editAttributes() ?>>
</span>
<?php echo $loanrequests_edit->comments->CustomMsg ?></div></div>
	</div>
<?php } ?>
<?php if ($loanrequests_edit->loantype->Visible) { // loantype ?>
	<div id="r_loantype" class="form-group row">
		<label id="elh_loanrequests_loantype" for="x_loantype" class="<?php echo $loanrequests_edit->LeftColumnClass ?>"><?php echo $loanrequests_edit->loantype->caption() ?><?php echo $loanrequests_edit->loantype->Required ? $Language->phrase("FieldRequiredIndicator") : "" ?></label>
		<div class="<?php echo $loanrequests_edit->RightColumnClass ?>"><div <?php echo $loanrequests_edit->loantype->cellAttributes() ?>>
<span id="el_loanrequests_loantype">
<div class="input-group">
	<select class="custom-select ew-custom-select" data-table="loanrequests" data-field="x_loantype" data-value-separator="<?php echo $loanrequests_edit->loantype->displayValueSeparatorAttribute() ?>" id="x_loantype" name="x_loantype"<?php echo $loanrequests_edit->loantype->editAttributes() ?>>
			<?php echo $loanrequests_edit->loantype->selectOptionListHtml("x_loantype") ?>
		</select>
</div>
<?php echo $loanrequests_edit->loantype->Lookup->getParamTag($loanrequests_edit, "p_x_loantype") ?>
</span>
<?php echo $loanrequests_edit->loantype->CustomMsg ?></div></div>
	</div>
<?php } ?>
<?php if ($loanrequests_edit->amountforfeecalculation->Visible) { // amountforfeecalculation ?>
	<div id="r_amountforfeecalculation" class="form-group row">
		<label id="elh_loanrequests_amountforfeecalculation" for="x_amountforfeecalculation" class="<?php echo $loanrequests_edit->LeftColumnClass ?>"><?php echo $loanrequests_edit->amountforfeecalculation->caption() ?><?php echo $loanrequests_edit->amountforfeecalculation->Required ? $Language->phrase("FieldRequiredIndicator") : "" ?></label>
		<div class="<?php echo $loanrequests_edit->RightColumnClass ?>"><div <?php echo $loanrequests_edit->amountforfeecalculation->cellAttributes() ?>>
<span id="el_loanrequests_amountforfeecalculation">
<input type="text" data-table="loanrequests" data-field="x_amountforfeecalculation" name="x_amountforfeecalculation" id="x_amountforfeecalculation" size="30" maxlength="15" placeholder="<?php echo HtmlEncode($loanrequests_edit->amountforfeecalculation->getPlaceHolder()) ?>" value="<?php echo $loanrequests_edit->amountforfeecalculation->EditValue ?>"<?php echo $loanrequests_edit->amountforfeecalculation->editAttributes() ?>>
</span>
<?php echo $loanrequests_edit->amountforfeecalculation->CustomMsg ?></div></div>
	</div>
<?php } ?>
<?php if ($loanrequests_edit->approveddate->Visible) { // approveddate ?>
	<div id="r_approveddate" class="form-group row">
		<label id="elh_loanrequests_approveddate" for="x_approveddate" class="<?php echo $loanrequests_edit->LeftColumnClass ?>"><?php echo $loanrequests_edit->approveddate->caption() ?><?php echo $loanrequests_edit->approveddate->Required ? $Language->phrase("FieldRequiredIndicator") : "" ?></label>
		<div class="<?php echo $loanrequests_edit->RightColumnClass ?>"><div <?php echo $loanrequests_edit->approveddate->cellAttributes() ?>>
<span id="el_loanrequests_approveddate">
<input type="text" data-table="loanrequests" data-field="x_approveddate" name="x_approveddate" id="x_approveddate" maxlength="19" placeholder="<?php echo HtmlEncode($loanrequests_edit->approveddate->getPlaceHolder()) ?>" value="<?php echo $loanrequests_edit->approveddate->EditValue ?>"<?php echo $loanrequests_edit->approveddate->editAttributes() ?>>
<?php if (!$loanrequests_edit->approveddate->ReadOnly && !$loanrequests_edit->approveddate->Disabled && !isset($loanrequests_edit->approveddate->EditAttrs["readonly"]) && !isset($loanrequests_edit->approveddate->EditAttrs["disabled"])) { ?>
<script>
loadjs.ready(["floanrequestsedit", "datetimepicker"], function() {
	ew.createDateTimePicker("floanrequestsedit", "x_approveddate", {"ignoreReadonly":true,"useCurrent":false,"format":0});
});
</script>
<?php } ?>
</span>
<?php echo $loanrequests_edit->approveddate->CustomMsg ?></div></div>
	</div>
<?php } ?>
<?php if ($loanrequests_edit->approvedby->Visible) { // approvedby ?>
	<div id="r_approvedby" class="form-group row">
		<label id="elh_loanrequests_approvedby" for="x_approvedby" class="<?php echo $loanrequests_edit->LeftColumnClass ?>"><?php echo $loanrequests_edit->approvedby->caption() ?><?php echo $loanrequests_edit->approvedby->Required ? $Language->phrase("FieldRequiredIndicator") : "" ?></label>
		<div class="<?php echo $loanrequests_edit->RightColumnClass ?>"><div <?php echo $loanrequests_edit->approvedby->cellAttributes() ?>>
<span id="el_loanrequests_approvedby">
<input type="text" data-table="loanrequests" data-field="x_approvedby" name="x_approvedby" id="x_approvedby" size="30" maxlength="12" placeholder="<?php echo HtmlEncode($loanrequests_edit->approvedby->getPlaceHolder()) ?>" value="<?php echo $loanrequests_edit->approvedby->EditValue ?>"<?php echo $loanrequests_edit->approvedby->editAttributes() ?>>
</span>
<?php echo $loanrequests_edit->approvedby->CustomMsg ?></div></div>
	</div>
<?php } ?>
<?php if ($loanrequests_edit->overriddeninterestamount->Visible) { // overriddeninterestamount ?>
	<div id="r_overriddeninterestamount" class="form-group row">
		<label id="elh_loanrequests_overriddeninterestamount" for="x_overriddeninterestamount" class="<?php echo $loanrequests_edit->LeftColumnClass ?>"><?php echo $loanrequests_edit->overriddeninterestamount->caption() ?><?php echo $loanrequests_edit->overriddeninterestamount->Required ? $Language->phrase("FieldRequiredIndicator") : "" ?></label>
		<div class="<?php echo $loanrequests_edit->RightColumnClass ?>"><div <?php echo $loanrequests_edit->overriddeninterestamount->cellAttributes() ?>>
<span id="el_loanrequests_overriddeninterestamount">
<input type="text" data-table="loanrequests" data-field="x_overriddeninterestamount" name="x_overriddeninterestamount" id="x_overriddeninterestamount" size="30" maxlength="12" placeholder="<?php echo HtmlEncode($loanrequests_edit->overriddeninterestamount->getPlaceHolder()) ?>" value="<?php echo $loanrequests_edit->overriddeninterestamount->EditValue ?>"<?php echo $loanrequests_edit->overriddeninterestamount->editAttributes() ?>>
</span>
<?php echo $loanrequests_edit->overriddeninterestamount->CustomMsg ?></div></div>
	</div>
<?php } ?>
<?php if ($loanrequests_edit->overrideinterest->Visible) { // overrideinterest ?>
	<div id="r_overrideinterest" class="form-group row">
		<label id="elh_loanrequests_overrideinterest" for="x_overrideinterest" class="<?php echo $loanrequests_edit->LeftColumnClass ?>"><?php echo $loanrequests_edit->overrideinterest->caption() ?><?php echo $loanrequests_edit->overrideinterest->Required ? $Language->phrase("FieldRequiredIndicator") : "" ?></label>
		<div class="<?php echo $loanrequests_edit->RightColumnClass ?>"><div <?php echo $loanrequests_edit->overrideinterest->cellAttributes() ?>>
<span id="el_loanrequests_overrideinterest">
<div class="input-group">
	<select class="custom-select ew-custom-select" data-table="loanrequests" data-field="x_overrideinterest" data-value-separator="<?php echo $loanrequests_edit->overrideinterest->displayValueSeparatorAttribute() ?>" id="x_overrideinterest" name="x_overrideinterest"<?php echo $loanrequests_edit->overrideinterest->editAttributes() ?>>
			<?php echo $loanrequests_edit->overrideinterest->selectOptionListHtml("x_overrideinterest") ?>
		</select>
</div>
<?php echo $loanrequests_edit->overrideinterest->Lookup->getParamTag($loanrequests_edit, "p_x_overrideinterest") ?>
</span>
<?php echo $loanrequests_edit->overrideinterest->CustomMsg ?></div></div>
	</div>
<?php } ?>
<?php if ($loanrequests_edit->otherdetails->Visible) { // otherdetails ?>
	<div id="r_otherdetails" class="form-group row">
		<label id="elh_loanrequests_otherdetails" for="x_otherdetails" class="<?php echo $loanrequests_edit->LeftColumnClass ?>"><?php echo $loanrequests_edit->otherdetails->caption() ?><?php echo $loanrequests_edit->otherdetails->Required ? $Language->phrase("FieldRequiredIndicator") : "" ?></label>
		<div class="<?php echo $loanrequests_edit->RightColumnClass ?>"><div <?php echo $loanrequests_edit->otherdetails->cellAttributes() ?>>
<span id="el_loanrequests_otherdetails">
<input type="text" data-table="loanrequests" data-field="x_otherdetails" name="x_otherdetails" id="x_otherdetails" size="30" maxlength="50" placeholder="<?php echo HtmlEncode($loanrequests_edit->otherdetails->getPlaceHolder()) ?>" value="<?php echo $loanrequests_edit->otherdetails->EditValue ?>"<?php echo $loanrequests_edit->otherdetails->editAttributes() ?>>
</span>
<?php echo $loanrequests_edit->otherdetails->CustomMsg ?></div></div>
	</div>
<?php } ?>
<?php if ($loanrequests_edit->termtype->Visible) { // termtype ?>
	<div id="r_termtype" class="form-group row">
		<label id="elh_loanrequests_termtype" class="<?php echo $loanrequests_edit->LeftColumnClass ?>"><?php echo $loanrequests_edit->termtype->caption() ?><?php echo $loanrequests_edit->termtype->Required ? $Language->phrase("FieldRequiredIndicator") : "" ?></label>
		<div class="<?php echo $loanrequests_edit->RightColumnClass ?>"><div <?php echo $loanrequests_edit->termtype->cellAttributes() ?>>
<span id="el_loanrequests_termtype">
<div id="tp_x_termtype" class="ew-template"><input type="radio" class="custom-control-input" data-table="loanrequests" data-field="x_termtype" data-value-separator="<?php echo $loanrequests_edit->termtype->displayValueSeparatorAttribute() ?>" name="x_termtype" id="x_termtype" value="{value}"<?php echo $loanrequests_edit->termtype->editAttributes() ?>></div>
<div id="dsl_x_termtype" data-repeatcolumn="5" class="ew-item-list d-none"><div>
<?php echo $loanrequests_edit->termtype->radioButtonListHtml(FALSE, "x_termtype") ?>
</div></div>
</span>
<?php echo $loanrequests_edit->termtype->CustomMsg ?></div></div>
	</div>
<?php } ?>
</div><!-- /page* -->
<?php
	if (in_array("loanissued", explode(",", $loanrequests->getCurrentDetailTable())) && $loanissued->DetailEdit) {
?>
<?php if ($loanrequests->getCurrentDetailTable() != "") { ?>
<h4 class="ew-detail-caption"><?php echo $Language->tablePhrase("loanissued", "TblCaption") ?></h4>
<?php } ?>
<?php include_once "loanissuedgrid.php" ?>
<?php } ?>
<?php if (!$loanrequests_edit->IsModal) { ?>
<div class="form-group row"><!-- buttons .form-group -->
	<div class="<?php echo $loanrequests_edit->OffsetColumnClass ?>"><!-- buttons offset -->
<button class="btn btn-primary ew-btn" name="btn-action" id="btn-action" type="submit"><?php echo $Language->phrase("SaveBtn") ?></button>
<button class="btn btn-default ew-btn" name="btn-cancel" id="btn-cancel" type="button" data-href="<?php echo $loanrequests_edit->getReturnUrl() ?>"><?php echo $Language->phrase("CancelBtn") ?></button>
	</div><!-- /buttons offset -->
</div><!-- /buttons .form-group -->
<?php } ?>
</form>
<?php
$loanrequests_edit->showPageFooter();
if (Config("DEBUG"))
	echo GetDebugMessage();
?>
<script>
loadjs.ready("load", function() {

	// Startup script
	// Write your table-specific startup script here
	// console.log("page loaded");

});
</script>
<?php include_once "footer.php"; ?>
<?php
$loanrequests_edit->terminate();
?>