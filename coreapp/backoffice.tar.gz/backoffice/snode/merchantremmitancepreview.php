<?php
namespace PHPMaker2020\_4payadmin;

// Autoload
include_once "autoload.php";

// Session
if (session_status() !== PHP_SESSION_ACTIVE)
	\Delight\Cookie\Session::start(Config("COOKIE_SAMESITE")); // Init session data

// Output buffering
ob_start();
?>
<?php

// Write header
WriteHeader(FALSE, "utf-8");

// Create page object
$merchantremmitance_preview = new merchantremmitance_preview();

// Run the page
$merchantremmitance_preview->run();

// Setup login status
SetupLoginStatus();
SetClientVar("login", LoginStatus());

// Global Page Rendering event (in userfn*.php)
Page_Rendering();

// Page Rendering event
$merchantremmitance_preview->Page_Render();
?>
<?php $merchantremmitance_preview->showPageHeader(); ?>
<?php if ($merchantremmitance_preview->TotalRecords > 0) { ?>
<div class="card ew-grid merchantremmitance"><!-- .card -->
<div class="<?php echo ResponsiveTableClass() ?>card-body ew-grid-middle-panel ew-preview-middle-panel"><!-- .table-responsive -->
<table class="table ew-table ew-preview-table"><!-- .table -->
	<thead><!-- Table header -->
		<tr class="ew-table-header">
<?php

// Render list options
$merchantremmitance_preview->renderListOptions();

// Render list options (header, left)
$merchantremmitance_preview->ListOptions->render("header", "left");
?>
<?php if ($merchantremmitance_preview->remmitandid->Visible) { // remmitandid ?>
	<?php if ($merchantremmitance->SortUrl($merchantremmitance_preview->remmitandid) == "") { ?>
		<th class="<?php echo $merchantremmitance_preview->remmitandid->headerCellClass() ?>"><?php echo $merchantremmitance_preview->remmitandid->caption() ?></th>
	<?php } else { ?>
		<th class="<?php echo $merchantremmitance_preview->remmitandid->headerCellClass() ?>"><div class="ew-pointer" data-sort="<?php echo HtmlEncode($merchantremmitance_preview->remmitandid->Name) ?>" data-sort-order="<?php echo $merchantremmitance_preview->SortField == $merchantremmitance_preview->remmitandid->Name && $merchantremmitance_preview->SortOrder == "ASC" ? "DESC" : "ASC" ?>">
			<div class="ew-table-header-btn"><span class="ew-table-header-caption"><?php echo $merchantremmitance_preview->remmitandid->caption() ?></span><span class="ew-table-header-sort"><?php if ($merchantremmitance_preview->SortField == $merchantremmitance_preview->remmitandid->Name) { ?><?php if ($merchantremmitance_preview->SortOrder == "ASC") { ?><i class="fas fa-sort-up"></i><?php } elseif ($merchantremmitance_preview->SortOrder == "DESC") { ?><i class="fas fa-sort-down"></i><?php } ?><?php } ?></span>
		</div></div></th>
	<?php } ?>
<?php } ?>
<?php if ($merchantremmitance_preview->_userid->Visible) { // userid ?>
	<?php if ($merchantremmitance->SortUrl($merchantremmitance_preview->_userid) == "") { ?>
		<th class="<?php echo $merchantremmitance_preview->_userid->headerCellClass() ?>"><?php echo $merchantremmitance_preview->_userid->caption() ?></th>
	<?php } else { ?>
		<th class="<?php echo $merchantremmitance_preview->_userid->headerCellClass() ?>"><div class="ew-pointer" data-sort="<?php echo HtmlEncode($merchantremmitance_preview->_userid->Name) ?>" data-sort-order="<?php echo $merchantremmitance_preview->SortField == $merchantremmitance_preview->_userid->Name && $merchantremmitance_preview->SortOrder == "ASC" ? "DESC" : "ASC" ?>">
			<div class="ew-table-header-btn"><span class="ew-table-header-caption"><?php echo $merchantremmitance_preview->_userid->caption() ?></span><span class="ew-table-header-sort"><?php if ($merchantremmitance_preview->SortField == $merchantremmitance_preview->_userid->Name) { ?><?php if ($merchantremmitance_preview->SortOrder == "ASC") { ?><i class="fas fa-sort-up"></i><?php } elseif ($merchantremmitance_preview->SortOrder == "DESC") { ?><i class="fas fa-sort-down"></i><?php } ?><?php } ?></span>
		</div></div></th>
	<?php } ?>
<?php } ?>
<?php if ($merchantremmitance_preview->transferdatetime->Visible) { // transferdatetime ?>
	<?php if ($merchantremmitance->SortUrl($merchantremmitance_preview->transferdatetime) == "") { ?>
		<th class="<?php echo $merchantremmitance_preview->transferdatetime->headerCellClass() ?>"><?php echo $merchantremmitance_preview->transferdatetime->caption() ?></th>
	<?php } else { ?>
		<th class="<?php echo $merchantremmitance_preview->transferdatetime->headerCellClass() ?>"><div class="ew-pointer" data-sort="<?php echo HtmlEncode($merchantremmitance_preview->transferdatetime->Name) ?>" data-sort-order="<?php echo $merchantremmitance_preview->SortField == $merchantremmitance_preview->transferdatetime->Name && $merchantremmitance_preview->SortOrder == "ASC" ? "DESC" : "ASC" ?>">
			<div class="ew-table-header-btn"><span class="ew-table-header-caption"><?php echo $merchantremmitance_preview->transferdatetime->caption() ?></span><span class="ew-table-header-sort"><?php if ($merchantremmitance_preview->SortField == $merchantremmitance_preview->transferdatetime->Name) { ?><?php if ($merchantremmitance_preview->SortOrder == "ASC") { ?><i class="fas fa-sort-up"></i><?php } elseif ($merchantremmitance_preview->SortOrder == "DESC") { ?><i class="fas fa-sort-down"></i><?php } ?><?php } ?></span>
		</div></div></th>
	<?php } ?>
<?php } ?>
<?php if ($merchantremmitance_preview->currency->Visible) { // currency ?>
	<?php if ($merchantremmitance->SortUrl($merchantremmitance_preview->currency) == "") { ?>
		<th class="<?php echo $merchantremmitance_preview->currency->headerCellClass() ?>"><?php echo $merchantremmitance_preview->currency->caption() ?></th>
	<?php } else { ?>
		<th class="<?php echo $merchantremmitance_preview->currency->headerCellClass() ?>"><div class="ew-pointer" data-sort="<?php echo HtmlEncode($merchantremmitance_preview->currency->Name) ?>" data-sort-order="<?php echo $merchantremmitance_preview->SortField == $merchantremmitance_preview->currency->Name && $merchantremmitance_preview->SortOrder == "ASC" ? "DESC" : "ASC" ?>">
			<div class="ew-table-header-btn"><span class="ew-table-header-caption"><?php echo $merchantremmitance_preview->currency->caption() ?></span><span class="ew-table-header-sort"><?php if ($merchantremmitance_preview->SortField == $merchantremmitance_preview->currency->Name) { ?><?php if ($merchantremmitance_preview->SortOrder == "ASC") { ?><i class="fas fa-sort-up"></i><?php } elseif ($merchantremmitance_preview->SortOrder == "DESC") { ?><i class="fas fa-sort-down"></i><?php } ?><?php } ?></span>
		</div></div></th>
	<?php } ?>
<?php } ?>
<?php if ($merchantremmitance_preview->amount->Visible) { // amount ?>
	<?php if ($merchantremmitance->SortUrl($merchantremmitance_preview->amount) == "") { ?>
		<th class="<?php echo $merchantremmitance_preview->amount->headerCellClass() ?>"><?php echo $merchantremmitance_preview->amount->caption() ?></th>
	<?php } else { ?>
		<th class="<?php echo $merchantremmitance_preview->amount->headerCellClass() ?>"><div class="ew-pointer" data-sort="<?php echo HtmlEncode($merchantremmitance_preview->amount->Name) ?>" data-sort-order="<?php echo $merchantremmitance_preview->SortField == $merchantremmitance_preview->amount->Name && $merchantremmitance_preview->SortOrder == "ASC" ? "DESC" : "ASC" ?>">
			<div class="ew-table-header-btn"><span class="ew-table-header-caption"><?php echo $merchantremmitance_preview->amount->caption() ?></span><span class="ew-table-header-sort"><?php if ($merchantremmitance_preview->SortField == $merchantremmitance_preview->amount->Name) { ?><?php if ($merchantremmitance_preview->SortOrder == "ASC") { ?><i class="fas fa-sort-up"></i><?php } elseif ($merchantremmitance_preview->SortOrder == "DESC") { ?><i class="fas fa-sort-down"></i><?php } ?><?php } ?></span>
		</div></div></th>
	<?php } ?>
<?php } ?>
<?php if ($merchantremmitance_preview->completed->Visible) { // completed ?>
	<?php if ($merchantremmitance->SortUrl($merchantremmitance_preview->completed) == "") { ?>
		<th class="<?php echo $merchantremmitance_preview->completed->headerCellClass() ?>"><?php echo $merchantremmitance_preview->completed->caption() ?></th>
	<?php } else { ?>
		<th class="<?php echo $merchantremmitance_preview->completed->headerCellClass() ?>"><div class="ew-pointer" data-sort="<?php echo HtmlEncode($merchantremmitance_preview->completed->Name) ?>" data-sort-order="<?php echo $merchantremmitance_preview->SortField == $merchantremmitance_preview->completed->Name && $merchantremmitance_preview->SortOrder == "ASC" ? "DESC" : "ASC" ?>">
			<div class="ew-table-header-btn"><span class="ew-table-header-caption"><?php echo $merchantremmitance_preview->completed->caption() ?></span><span class="ew-table-header-sort"><?php if ($merchantremmitance_preview->SortField == $merchantremmitance_preview->completed->Name) { ?><?php if ($merchantremmitance_preview->SortOrder == "ASC") { ?><i class="fas fa-sort-up"></i><?php } elseif ($merchantremmitance_preview->SortOrder == "DESC") { ?><i class="fas fa-sort-down"></i><?php } ?><?php } ?></span>
		</div></div></th>
	<?php } ?>
<?php } ?>
<?php if ($merchantremmitance_preview->refno->Visible) { // refno ?>
	<?php if ($merchantremmitance->SortUrl($merchantremmitance_preview->refno) == "") { ?>
		<th class="<?php echo $merchantremmitance_preview->refno->headerCellClass() ?>"><?php echo $merchantremmitance_preview->refno->caption() ?></th>
	<?php } else { ?>
		<th class="<?php echo $merchantremmitance_preview->refno->headerCellClass() ?>"><div class="ew-pointer" data-sort="<?php echo HtmlEncode($merchantremmitance_preview->refno->Name) ?>" data-sort-order="<?php echo $merchantremmitance_preview->SortField == $merchantremmitance_preview->refno->Name && $merchantremmitance_preview->SortOrder == "ASC" ? "DESC" : "ASC" ?>">
			<div class="ew-table-header-btn"><span class="ew-table-header-caption"><?php echo $merchantremmitance_preview->refno->caption() ?></span><span class="ew-table-header-sort"><?php if ($merchantremmitance_preview->SortField == $merchantremmitance_preview->refno->Name) { ?><?php if ($merchantremmitance_preview->SortOrder == "ASC") { ?><i class="fas fa-sort-up"></i><?php } elseif ($merchantremmitance_preview->SortOrder == "DESC") { ?><i class="fas fa-sort-down"></i><?php } ?><?php } ?></span>
		</div></div></th>
	<?php } ?>
<?php } ?>
<?php if ($merchantremmitance_preview->refdate->Visible) { // refdate ?>
	<?php if ($merchantremmitance->SortUrl($merchantremmitance_preview->refdate) == "") { ?>
		<th class="<?php echo $merchantremmitance_preview->refdate->headerCellClass() ?>"><?php echo $merchantremmitance_preview->refdate->caption() ?></th>
	<?php } else { ?>
		<th class="<?php echo $merchantremmitance_preview->refdate->headerCellClass() ?>"><div class="ew-pointer" data-sort="<?php echo HtmlEncode($merchantremmitance_preview->refdate->Name) ?>" data-sort-order="<?php echo $merchantremmitance_preview->SortField == $merchantremmitance_preview->refdate->Name && $merchantremmitance_preview->SortOrder == "ASC" ? "DESC" : "ASC" ?>">
			<div class="ew-table-header-btn"><span class="ew-table-header-caption"><?php echo $merchantremmitance_preview->refdate->caption() ?></span><span class="ew-table-header-sort"><?php if ($merchantremmitance_preview->SortField == $merchantremmitance_preview->refdate->Name) { ?><?php if ($merchantremmitance_preview->SortOrder == "ASC") { ?><i class="fas fa-sort-up"></i><?php } elseif ($merchantremmitance_preview->SortOrder == "DESC") { ?><i class="fas fa-sort-down"></i><?php } ?><?php } ?></span>
		</div></div></th>
	<?php } ?>
<?php } ?>
<?php if ($merchantremmitance_preview->userrequested->Visible) { // userrequested ?>
	<?php if ($merchantremmitance->SortUrl($merchantremmitance_preview->userrequested) == "") { ?>
		<th class="<?php echo $merchantremmitance_preview->userrequested->headerCellClass() ?>"><?php echo $merchantremmitance_preview->userrequested->caption() ?></th>
	<?php } else { ?>
		<th class="<?php echo $merchantremmitance_preview->userrequested->headerCellClass() ?>"><div class="ew-pointer" data-sort="<?php echo HtmlEncode($merchantremmitance_preview->userrequested->Name) ?>" data-sort-order="<?php echo $merchantremmitance_preview->SortField == $merchantremmitance_preview->userrequested->Name && $merchantremmitance_preview->SortOrder == "ASC" ? "DESC" : "ASC" ?>">
			<div class="ew-table-header-btn"><span class="ew-table-header-caption"><?php echo $merchantremmitance_preview->userrequested->caption() ?></span><span class="ew-table-header-sort"><?php if ($merchantremmitance_preview->SortField == $merchantremmitance_preview->userrequested->Name) { ?><?php if ($merchantremmitance_preview->SortOrder == "ASC") { ?><i class="fas fa-sort-up"></i><?php } elseif ($merchantremmitance_preview->SortOrder == "DESC") { ?><i class="fas fa-sort-down"></i><?php } ?><?php } ?></span>
		</div></div></th>
	<?php } ?>
<?php } ?>
<?php

// Render list options (header, right)
$merchantremmitance_preview->ListOptions->render("header", "right");
?>
		</tr>
	</thead>
	<tbody><!-- Table body -->
<?php
$merchantremmitance_preview->RecCount = 0;
$merchantremmitance_preview->RowCount = 0;
while ($merchantremmitance_preview->Recordset && !$merchantremmitance_preview->Recordset->EOF) {

	// Init row class and style
	$merchantremmitance_preview->RecCount++;
	$merchantremmitance_preview->RowCount++;
	$merchantremmitance_preview->CssStyle = "";
	$merchantremmitance_preview->loadListRowValues($merchantremmitance_preview->Recordset);

	// Render row
	$merchantremmitance->RowType = ROWTYPE_PREVIEW; // Preview record
	$merchantremmitance_preview->resetAttributes();
	$merchantremmitance_preview->renderListRow();

	// Render list options
	$merchantremmitance_preview->renderListOptions();
?>
	<tr <?php echo $merchantremmitance->rowAttributes() ?>>
<?php

// Render list options (body, left)
$merchantremmitance_preview->ListOptions->render("body", "left", $merchantremmitance_preview->RowCount);
?>
<?php if ($merchantremmitance_preview->remmitandid->Visible) { // remmitandid ?>
		<!-- remmitandid -->
		<td<?php echo $merchantremmitance_preview->remmitandid->cellAttributes() ?>>
<span<?php echo $merchantremmitance_preview->remmitandid->viewAttributes() ?>><?php echo $merchantremmitance_preview->remmitandid->getViewValue() ?></span>
</td>
<?php } ?>
<?php if ($merchantremmitance_preview->_userid->Visible) { // userid ?>
		<!-- userid -->
		<td<?php echo $merchantremmitance_preview->_userid->cellAttributes() ?>>
<span<?php echo $merchantremmitance_preview->_userid->viewAttributes() ?>><?php if (!EmptyString($merchantremmitance_preview->_userid->getViewValue()) && $merchantremmitance_preview->_userid->linkAttributes() != "") { ?>
<a<?php echo $merchantremmitance_preview->_userid->linkAttributes() ?>><?php echo $merchantremmitance_preview->_userid->getViewValue() ?></a>
<?php } else { ?>
<?php echo $merchantremmitance_preview->_userid->getViewValue() ?>
<?php } ?></span>
</td>
<?php } ?>
<?php if ($merchantremmitance_preview->transferdatetime->Visible) { // transferdatetime ?>
		<!-- transferdatetime -->
		<td<?php echo $merchantremmitance_preview->transferdatetime->cellAttributes() ?>>
<span<?php echo $merchantremmitance_preview->transferdatetime->viewAttributes() ?>><?php echo $merchantremmitance_preview->transferdatetime->getViewValue() ?></span>
</td>
<?php } ?>
<?php if ($merchantremmitance_preview->currency->Visible) { // currency ?>
		<!-- currency -->
		<td<?php echo $merchantremmitance_preview->currency->cellAttributes() ?>>
<span<?php echo $merchantremmitance_preview->currency->viewAttributes() ?>><?php echo $merchantremmitance_preview->currency->getViewValue() ?></span>
</td>
<?php } ?>
<?php if ($merchantremmitance_preview->amount->Visible) { // amount ?>
		<!-- amount -->
		<td<?php echo $merchantremmitance_preview->amount->cellAttributes() ?>>
<span<?php echo $merchantremmitance_preview->amount->viewAttributes() ?>><?php echo $merchantremmitance_preview->amount->getViewValue() ?></span>
</td>
<?php } ?>
<?php if ($merchantremmitance_preview->completed->Visible) { // completed ?>
		<!-- completed -->
		<td<?php echo $merchantremmitance_preview->completed->cellAttributes() ?>>
<span<?php echo $merchantremmitance_preview->completed->viewAttributes() ?>><?php echo $merchantremmitance_preview->completed->getViewValue() ?></span>
</td>
<?php } ?>
<?php if ($merchantremmitance_preview->refno->Visible) { // refno ?>
		<!-- refno -->
		<td<?php echo $merchantremmitance_preview->refno->cellAttributes() ?>>
<span<?php echo $merchantremmitance_preview->refno->viewAttributes() ?>><?php echo $merchantremmitance_preview->refno->getViewValue() ?></span>
</td>
<?php } ?>
<?php if ($merchantremmitance_preview->refdate->Visible) { // refdate ?>
		<!-- refdate -->
		<td<?php echo $merchantremmitance_preview->refdate->cellAttributes() ?>>
<span<?php echo $merchantremmitance_preview->refdate->viewAttributes() ?>><?php echo $merchantremmitance_preview->refdate->getViewValue() ?></span>
</td>
<?php } ?>
<?php if ($merchantremmitance_preview->userrequested->Visible) { // userrequested ?>
		<!-- userrequested -->
		<td<?php echo $merchantremmitance_preview->userrequested->cellAttributes() ?>>
<span<?php echo $merchantremmitance_preview->userrequested->viewAttributes() ?>><?php echo $merchantremmitance_preview->userrequested->getViewValue() ?></span>
</td>
<?php } ?>
<?php

// Render list options (body, right)
$merchantremmitance_preview->ListOptions->render("body", "right", $merchantremmitance_preview->RowCount);
?>
	</tr>
<?php
	$merchantremmitance_preview->Recordset->MoveNext();
} // while
?>
	</tbody>
</table><!-- /.table -->
</div><!-- /.table-responsive -->
<div class="card-footer ew-grid-lower-panel ew-preview-lower-panel"><!-- .card-footer -->
<?php echo $merchantremmitance_preview->Pager->render() ?>
<?php } else { // No record ?>
<div class="card no-border">
<div class="ew-detail-count"><?php echo $Language->phrase("NoRecord") ?></div>
<?php } ?>
<div class="ew-preview-other-options">
<?php
	foreach ($merchantremmitance_preview->OtherOptions as $option)
		$option->render("body");
?>
</div>
<?php if ($merchantremmitance_preview->TotalRecords > 0) { ?>
<div class="clearfix"></div>
</div><!-- /.card-footer -->
<?php } ?>
</div><!-- /.card -->
<?php
$merchantremmitance_preview->showPageFooter();
if (Config("DEBUG"))
	echo GetDebugMessage();
?>
<?php
if ($merchantremmitance_preview->Recordset)
	$merchantremmitance_preview->Recordset->Close();

// Output
$content = ob_get_contents();
ob_end_clean();
echo ConvertToUtf8($content);
?>
<?php
$merchantremmitance_preview->terminate();
?>