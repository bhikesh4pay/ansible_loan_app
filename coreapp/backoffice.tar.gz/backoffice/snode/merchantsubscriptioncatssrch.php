<?php
namespace PHPMaker2020\_4payadmin;

// Autoload
include_once "autoload.php";

// Session
if (session_status() !== PHP_SESSION_ACTIVE)
	\Delight\Cookie\Session::start(Config("COOKIE_SAMESITE")); // Init session data

// Output buffering
ob_start();
?>
<?php

// Write header
WriteHeader(FALSE);

// Create page object
$merchantsubscriptioncats_search = new merchantsubscriptioncats_search();

// Run the page
$merchantsubscriptioncats_search->run();

// Setup login status
SetupLoginStatus();
SetClientVar("login", LoginStatus());

// Global Page Rendering event (in userfn*.php)
Page_Rendering();

// Page Rendering event
$merchantsubscriptioncats_search->Page_Render();
?>
<?php include_once "header.php"; ?>
<script>
var fmerchantsubscriptioncatssearch, currentPageID;
loadjs.ready("head", function() {

	// Form object for search
	<?php if ($merchantsubscriptioncats_search->IsModal) { ?>
	fmerchantsubscriptioncatssearch = currentAdvancedSearchForm = new ew.Form("fmerchantsubscriptioncatssearch", "search");
	<?php } else { ?>
	fmerchantsubscriptioncatssearch = currentForm = new ew.Form("fmerchantsubscriptioncatssearch", "search");
	<?php } ?>
	currentPageID = ew.PAGE_ID = "search";

	// Validate function for search
	fmerchantsubscriptioncatssearch.validate = function(fobj) {
		if (!this.validateRequired)
			return true; // Ignore validation
		fobj = fobj || this._form;
		var infix = "";
		elm = this.getElements("x" + infix + "_categoryid");
		if (elm && !ew.checkInteger(elm.value))
			return this.onError(elm, "<?php echo JsEncode($merchantsubscriptioncats_search->categoryid->errorMessage()) ?>");
		elm = this.getElements("x" + infix + "_merchantid");
		if (elm && !ew.checkInteger(elm.value))
			return this.onError(elm, "<?php echo JsEncode($merchantsubscriptioncats_search->merchantid->errorMessage()) ?>");
		elm = this.getElements("x" + infix + "_active");
		if (elm && !ew.checkInteger(elm.value))
			return this.onError(elm, "<?php echo JsEncode($merchantsubscriptioncats_search->active->errorMessage()) ?>");
		elm = this.getElements("x" + infix + "_lastupdatedate");
		if (elm && !ew.checkDateDef(elm.value))
			return this.onError(elm, "<?php echo JsEncode($merchantsubscriptioncats_search->lastupdatedate->errorMessage()) ?>");

		// Call Form_CustomValidate event
		if (!this.Form_CustomValidate(fobj))
			return false;
		return true;
	}

	// Form_CustomValidate
	fmerchantsubscriptioncatssearch.Form_CustomValidate = function(fobj) { // DO NOT CHANGE THIS LINE!

		// Your custom validation code here, return false if invalid.
		return true;
	}

	// Use JavaScript validation or not
	fmerchantsubscriptioncatssearch.validateRequired = <?php echo Config("CLIENT_VALIDATE") ? "true" : "false" ?>;

	// Dynamic selection lists
	loadjs.done("fmerchantsubscriptioncatssearch");
});
</script>
<script>
loadjs.ready("head", function() {

	// Client script
	// Write your client script here, no need to add script tags.

});
</script>
<?php $merchantsubscriptioncats_search->showPageHeader(); ?>
<?php
$merchantsubscriptioncats_search->showMessage();
?>
<form name="fmerchantsubscriptioncatssearch" id="fmerchantsubscriptioncatssearch" class="<?php echo $merchantsubscriptioncats_search->FormClassName ?>" action="<?php echo CurrentPageName() ?>" method="post">
<?php if ($Page->CheckToken) { ?>
<input type="hidden" name="<?php echo Config("TOKEN_NAME") ?>" value="<?php echo $Page->Token ?>">
<?php } ?>
<input type="hidden" name="t" value="merchantsubscriptioncats">
<input type="hidden" name="action" id="action" value="search">
<input type="hidden" name="modal" value="<?php echo (int)$merchantsubscriptioncats_search->IsModal ?>">
<div class="ew-search-div"><!-- page* -->
<?php if ($merchantsubscriptioncats_search->categoryid->Visible) { // categoryid ?>
	<div id="r_categoryid" class="form-group row">
		<label for="x_categoryid" class="<?php echo $merchantsubscriptioncats_search->LeftColumnClass ?>"><span id="elh_merchantsubscriptioncats_categoryid"><?php echo $merchantsubscriptioncats_search->categoryid->caption() ?></span>
		<span class="ew-search-operator">
<?php echo $Language->phrase("=") ?>
<input type="hidden" name="z_categoryid" id="z_categoryid" value="=">
</span>
		</label>
		<div class="<?php echo $merchantsubscriptioncats_search->RightColumnClass ?>"><div <?php echo $merchantsubscriptioncats_search->categoryid->cellAttributes() ?>>
			<span id="el_merchantsubscriptioncats_categoryid" class="ew-search-field">
<input type="text" data-table="merchantsubscriptioncats" data-field="x_categoryid" name="x_categoryid" id="x_categoryid" placeholder="<?php echo HtmlEncode($merchantsubscriptioncats_search->categoryid->getPlaceHolder()) ?>" value="<?php echo $merchantsubscriptioncats_search->categoryid->EditValue ?>"<?php echo $merchantsubscriptioncats_search->categoryid->editAttributes() ?>>
</span>
		</div></div>
	</div>
<?php } ?>
<?php if ($merchantsubscriptioncats_search->merchantid->Visible) { // merchantid ?>
	<div id="r_merchantid" class="form-group row">
		<label for="x_merchantid" class="<?php echo $merchantsubscriptioncats_search->LeftColumnClass ?>"><span id="elh_merchantsubscriptioncats_merchantid"><?php echo $merchantsubscriptioncats_search->merchantid->caption() ?></span>
		<span class="ew-search-operator">
<?php echo $Language->phrase("=") ?>
<input type="hidden" name="z_merchantid" id="z_merchantid" value="=">
</span>
		</label>
		<div class="<?php echo $merchantsubscriptioncats_search->RightColumnClass ?>"><div <?php echo $merchantsubscriptioncats_search->merchantid->cellAttributes() ?>>
			<span id="el_merchantsubscriptioncats_merchantid" class="ew-search-field">
<input type="text" data-table="merchantsubscriptioncats" data-field="x_merchantid" name="x_merchantid" id="x_merchantid" size="30" placeholder="<?php echo HtmlEncode($merchantsubscriptioncats_search->merchantid->getPlaceHolder()) ?>" value="<?php echo $merchantsubscriptioncats_search->merchantid->EditValue ?>"<?php echo $merchantsubscriptioncats_search->merchantid->editAttributes() ?>>
</span>
		</div></div>
	</div>
<?php } ?>
<?php if ($merchantsubscriptioncats_search->label->Visible) { // label ?>
	<div id="r_label" class="form-group row">
		<label for="x_label" class="<?php echo $merchantsubscriptioncats_search->LeftColumnClass ?>"><span id="elh_merchantsubscriptioncats_label"><?php echo $merchantsubscriptioncats_search->label->caption() ?></span>
		<span class="ew-search-operator">
<?php echo $Language->phrase("LIKE") ?>
<input type="hidden" name="z_label" id="z_label" value="LIKE">
</span>
		</label>
		<div class="<?php echo $merchantsubscriptioncats_search->RightColumnClass ?>"><div <?php echo $merchantsubscriptioncats_search->label->cellAttributes() ?>>
			<span id="el_merchantsubscriptioncats_label" class="ew-search-field">
<input type="text" data-table="merchantsubscriptioncats" data-field="x_label" name="x_label" id="x_label" size="30" maxlength="30" placeholder="<?php echo HtmlEncode($merchantsubscriptioncats_search->label->getPlaceHolder()) ?>" value="<?php echo $merchantsubscriptioncats_search->label->EditValue ?>"<?php echo $merchantsubscriptioncats_search->label->editAttributes() ?>>
</span>
		</div></div>
	</div>
<?php } ?>
<?php if ($merchantsubscriptioncats_search->active->Visible) { // active ?>
	<div id="r_active" class="form-group row">
		<label for="x_active" class="<?php echo $merchantsubscriptioncats_search->LeftColumnClass ?>"><span id="elh_merchantsubscriptioncats_active"><?php echo $merchantsubscriptioncats_search->active->caption() ?></span>
		<span class="ew-search-operator">
<?php echo $Language->phrase("=") ?>
<input type="hidden" name="z_active" id="z_active" value="=">
</span>
		</label>
		<div class="<?php echo $merchantsubscriptioncats_search->RightColumnClass ?>"><div <?php echo $merchantsubscriptioncats_search->active->cellAttributes() ?>>
			<span id="el_merchantsubscriptioncats_active" class="ew-search-field">
<input type="text" data-table="merchantsubscriptioncats" data-field="x_active" name="x_active" id="x_active" size="30" placeholder="<?php echo HtmlEncode($merchantsubscriptioncats_search->active->getPlaceHolder()) ?>" value="<?php echo $merchantsubscriptioncats_search->active->EditValue ?>"<?php echo $merchantsubscriptioncats_search->active->editAttributes() ?>>
</span>
		</div></div>
	</div>
<?php } ?>
<?php if ($merchantsubscriptioncats_search->lastupdatedate->Visible) { // lastupdatedate ?>
	<div id="r_lastupdatedate" class="form-group row">
		<label for="x_lastupdatedate" class="<?php echo $merchantsubscriptioncats_search->LeftColumnClass ?>"><span id="elh_merchantsubscriptioncats_lastupdatedate"><?php echo $merchantsubscriptioncats_search->lastupdatedate->caption() ?></span>
		<span class="ew-search-operator">
<?php echo $Language->phrase("=") ?>
<input type="hidden" name="z_lastupdatedate" id="z_lastupdatedate" value="=">
</span>
		</label>
		<div class="<?php echo $merchantsubscriptioncats_search->RightColumnClass ?>"><div <?php echo $merchantsubscriptioncats_search->lastupdatedate->cellAttributes() ?>>
			<span id="el_merchantsubscriptioncats_lastupdatedate" class="ew-search-field">
<input type="text" data-table="merchantsubscriptioncats" data-field="x_lastupdatedate" name="x_lastupdatedate" id="x_lastupdatedate" placeholder="<?php echo HtmlEncode($merchantsubscriptioncats_search->lastupdatedate->getPlaceHolder()) ?>" value="<?php echo $merchantsubscriptioncats_search->lastupdatedate->EditValue ?>"<?php echo $merchantsubscriptioncats_search->lastupdatedate->editAttributes() ?>>
</span>
		</div></div>
	</div>
<?php } ?>
</div><!-- /page* -->
<?php if (!$merchantsubscriptioncats_search->IsModal) { ?>
<div class="form-group row"><!-- buttons .form-group -->
	<div class="<?php echo $merchantsubscriptioncats_search->OffsetColumnClass ?>"><!-- buttons offset -->
<button class="btn btn-primary ew-btn" name="btn-action" id="btn-action" type="submit"><?php echo $Language->phrase("Search") ?></button>
<button class="btn btn-default ew-btn" name="btn-reset" id="btn-reset" type="button" onclick="ew.clearForm(this.form);"><?php echo $Language->phrase("Reset") ?></button>
	</div><!-- /buttons offset -->
</div><!-- /buttons .form-group -->
<?php } ?>
</form>
<?php
$merchantsubscriptioncats_search->showPageFooter();
if (Config("DEBUG"))
	echo GetDebugMessage();
?>
<script>
loadjs.ready("load", function() {

	// Startup script
	// Write your table-specific startup script here
	// console.log("page loaded");

});
</script>
<?php include_once "footer.php"; ?>
<?php
$merchantsubscriptioncats_search->terminate();
?>