<?php
namespace PHPMaker2020\_4payadmin;

// Autoload
include_once "autoload.php";

// Session
if (session_status() !== PHP_SESSION_ACTIVE)
	\Delight\Cookie\Session::start(Config("COOKIE_SAMESITE")); // Init session data

// Output buffering
ob_start();
?>
<?php

// Write header
WriteHeader(FALSE, "utf-8");

// Create page object
$loantierhistory_preview = new loantierhistory_preview();

// Run the page
$loantierhistory_preview->run();

// Setup login status
SetupLoginStatus();
SetClientVar("login", LoginStatus());

// Global Page Rendering event (in userfn*.php)
Page_Rendering();

// Page Rendering event
$loantierhistory_preview->Page_Render();
?>
<?php $loantierhistory_preview->showPageHeader(); ?>
<?php if ($loantierhistory_preview->TotalRecords > 0) { ?>
<div class="card ew-grid loantierhistory"><!-- .card -->
<div class="<?php echo ResponsiveTableClass() ?>card-body ew-grid-middle-panel ew-preview-middle-panel"><!-- .table-responsive -->
<table class="table ew-table ew-preview-table"><!-- .table -->
	<thead><!-- Table header -->
		<tr class="ew-table-header">
<?php

// Render list options
$loantierhistory_preview->renderListOptions();

// Render list options (header, left)
$loantierhistory_preview->ListOptions->render("header", "left");
?>
<?php if ($loantierhistory_preview->changeid->Visible) { // changeid ?>
	<?php if ($loantierhistory->SortUrl($loantierhistory_preview->changeid) == "") { ?>
		<th class="<?php echo $loantierhistory_preview->changeid->headerCellClass() ?>"><?php echo $loantierhistory_preview->changeid->caption() ?></th>
	<?php } else { ?>
		<th class="<?php echo $loantierhistory_preview->changeid->headerCellClass() ?>"><div class="ew-pointer" data-sort="<?php echo HtmlEncode($loantierhistory_preview->changeid->Name) ?>" data-sort-order="<?php echo $loantierhistory_preview->SortField == $loantierhistory_preview->changeid->Name && $loantierhistory_preview->SortOrder == "ASC" ? "DESC" : "ASC" ?>">
			<div class="ew-table-header-btn"><span class="ew-table-header-caption"><?php echo $loantierhistory_preview->changeid->caption() ?></span><span class="ew-table-header-sort"><?php if ($loantierhistory_preview->SortField == $loantierhistory_preview->changeid->Name) { ?><?php if ($loantierhistory_preview->SortOrder == "ASC") { ?><i class="fas fa-sort-up"></i><?php } elseif ($loantierhistory_preview->SortOrder == "DESC") { ?><i class="fas fa-sort-down"></i><?php } ?><?php } ?></span>
		</div></div></th>
	<?php } ?>
<?php } ?>
<?php if ($loantierhistory_preview->_userid->Visible) { // userid ?>
	<?php if ($loantierhistory->SortUrl($loantierhistory_preview->_userid) == "") { ?>
		<th class="<?php echo $loantierhistory_preview->_userid->headerCellClass() ?>"><?php echo $loantierhistory_preview->_userid->caption() ?></th>
	<?php } else { ?>
		<th class="<?php echo $loantierhistory_preview->_userid->headerCellClass() ?>"><div class="ew-pointer" data-sort="<?php echo HtmlEncode($loantierhistory_preview->_userid->Name) ?>" data-sort-order="<?php echo $loantierhistory_preview->SortField == $loantierhistory_preview->_userid->Name && $loantierhistory_preview->SortOrder == "ASC" ? "DESC" : "ASC" ?>">
			<div class="ew-table-header-btn"><span class="ew-table-header-caption"><?php echo $loantierhistory_preview->_userid->caption() ?></span><span class="ew-table-header-sort"><?php if ($loantierhistory_preview->SortField == $loantierhistory_preview->_userid->Name) { ?><?php if ($loantierhistory_preview->SortOrder == "ASC") { ?><i class="fas fa-sort-up"></i><?php } elseif ($loantierhistory_preview->SortOrder == "DESC") { ?><i class="fas fa-sort-down"></i><?php } ?><?php } ?></span>
		</div></div></th>
	<?php } ?>
<?php } ?>
<?php if ($loantierhistory_preview->curr->Visible) { // curr ?>
	<?php if ($loantierhistory->SortUrl($loantierhistory_preview->curr) == "") { ?>
		<th class="<?php echo $loantierhistory_preview->curr->headerCellClass() ?>"><?php echo $loantierhistory_preview->curr->caption() ?></th>
	<?php } else { ?>
		<th class="<?php echo $loantierhistory_preview->curr->headerCellClass() ?>"><div class="ew-pointer" data-sort="<?php echo HtmlEncode($loantierhistory_preview->curr->Name) ?>" data-sort-order="<?php echo $loantierhistory_preview->SortField == $loantierhistory_preview->curr->Name && $loantierhistory_preview->SortOrder == "ASC" ? "DESC" : "ASC" ?>">
			<div class="ew-table-header-btn"><span class="ew-table-header-caption"><?php echo $loantierhistory_preview->curr->caption() ?></span><span class="ew-table-header-sort"><?php if ($loantierhistory_preview->SortField == $loantierhistory_preview->curr->Name) { ?><?php if ($loantierhistory_preview->SortOrder == "ASC") { ?><i class="fas fa-sort-up"></i><?php } elseif ($loantierhistory_preview->SortOrder == "DESC") { ?><i class="fas fa-sort-down"></i><?php } ?><?php } ?></span>
		</div></div></th>
	<?php } ?>
<?php } ?>
<?php if ($loantierhistory_preview->fromtier->Visible) { // fromtier ?>
	<?php if ($loantierhistory->SortUrl($loantierhistory_preview->fromtier) == "") { ?>
		<th class="<?php echo $loantierhistory_preview->fromtier->headerCellClass() ?>"><?php echo $loantierhistory_preview->fromtier->caption() ?></th>
	<?php } else { ?>
		<th class="<?php echo $loantierhistory_preview->fromtier->headerCellClass() ?>"><div class="ew-pointer" data-sort="<?php echo HtmlEncode($loantierhistory_preview->fromtier->Name) ?>" data-sort-order="<?php echo $loantierhistory_preview->SortField == $loantierhistory_preview->fromtier->Name && $loantierhistory_preview->SortOrder == "ASC" ? "DESC" : "ASC" ?>">
			<div class="ew-table-header-btn"><span class="ew-table-header-caption"><?php echo $loantierhistory_preview->fromtier->caption() ?></span><span class="ew-table-header-sort"><?php if ($loantierhistory_preview->SortField == $loantierhistory_preview->fromtier->Name) { ?><?php if ($loantierhistory_preview->SortOrder == "ASC") { ?><i class="fas fa-sort-up"></i><?php } elseif ($loantierhistory_preview->SortOrder == "DESC") { ?><i class="fas fa-sort-down"></i><?php } ?><?php } ?></span>
		</div></div></th>
	<?php } ?>
<?php } ?>
<?php if ($loantierhistory_preview->totier->Visible) { // totier ?>
	<?php if ($loantierhistory->SortUrl($loantierhistory_preview->totier) == "") { ?>
		<th class="<?php echo $loantierhistory_preview->totier->headerCellClass() ?>"><?php echo $loantierhistory_preview->totier->caption() ?></th>
	<?php } else { ?>
		<th class="<?php echo $loantierhistory_preview->totier->headerCellClass() ?>"><div class="ew-pointer" data-sort="<?php echo HtmlEncode($loantierhistory_preview->totier->Name) ?>" data-sort-order="<?php echo $loantierhistory_preview->SortField == $loantierhistory_preview->totier->Name && $loantierhistory_preview->SortOrder == "ASC" ? "DESC" : "ASC" ?>">
			<div class="ew-table-header-btn"><span class="ew-table-header-caption"><?php echo $loantierhistory_preview->totier->caption() ?></span><span class="ew-table-header-sort"><?php if ($loantierhistory_preview->SortField == $loantierhistory_preview->totier->Name) { ?><?php if ($loantierhistory_preview->SortOrder == "ASC") { ?><i class="fas fa-sort-up"></i><?php } elseif ($loantierhistory_preview->SortOrder == "DESC") { ?><i class="fas fa-sort-down"></i><?php } ?><?php } ?></span>
		</div></div></th>
	<?php } ?>
<?php } ?>
<?php if ($loantierhistory_preview->changedate->Visible) { // changedate ?>
	<?php if ($loantierhistory->SortUrl($loantierhistory_preview->changedate) == "") { ?>
		<th class="<?php echo $loantierhistory_preview->changedate->headerCellClass() ?>"><?php echo $loantierhistory_preview->changedate->caption() ?></th>
	<?php } else { ?>
		<th class="<?php echo $loantierhistory_preview->changedate->headerCellClass() ?>"><div class="ew-pointer" data-sort="<?php echo HtmlEncode($loantierhistory_preview->changedate->Name) ?>" data-sort-order="<?php echo $loantierhistory_preview->SortField == $loantierhistory_preview->changedate->Name && $loantierhistory_preview->SortOrder == "ASC" ? "DESC" : "ASC" ?>">
			<div class="ew-table-header-btn"><span class="ew-table-header-caption"><?php echo $loantierhistory_preview->changedate->caption() ?></span><span class="ew-table-header-sort"><?php if ($loantierhistory_preview->SortField == $loantierhistory_preview->changedate->Name) { ?><?php if ($loantierhistory_preview->SortOrder == "ASC") { ?><i class="fas fa-sort-up"></i><?php } elseif ($loantierhistory_preview->SortOrder == "DESC") { ?><i class="fas fa-sort-down"></i><?php } ?><?php } ?></span>
		</div></div></th>
	<?php } ?>
<?php } ?>
<?php

// Render list options (header, right)
$loantierhistory_preview->ListOptions->render("header", "right");
?>
		</tr>
	</thead>
	<tbody><!-- Table body -->
<?php
$loantierhistory_preview->RecCount = 0;
$loantierhistory_preview->RowCount = 0;
while ($loantierhistory_preview->Recordset && !$loantierhistory_preview->Recordset->EOF) {

	// Init row class and style
	$loantierhistory_preview->RecCount++;
	$loantierhistory_preview->RowCount++;
	$loantierhistory_preview->CssStyle = "";
	$loantierhistory_preview->loadListRowValues($loantierhistory_preview->Recordset);

	// Render row
	$loantierhistory->RowType = ROWTYPE_PREVIEW; // Preview record
	$loantierhistory_preview->resetAttributes();
	$loantierhistory_preview->renderListRow();

	// Render list options
	$loantierhistory_preview->renderListOptions();
?>
	<tr <?php echo $loantierhistory->rowAttributes() ?>>
<?php

// Render list options (body, left)
$loantierhistory_preview->ListOptions->render("body", "left", $loantierhistory_preview->RowCount);
?>
<?php if ($loantierhistory_preview->changeid->Visible) { // changeid ?>
		<!-- changeid -->
		<td<?php echo $loantierhistory_preview->changeid->cellAttributes() ?>>
<span<?php echo $loantierhistory_preview->changeid->viewAttributes() ?>><?php echo $loantierhistory_preview->changeid->getViewValue() ?></span>
</td>
<?php } ?>
<?php if ($loantierhistory_preview->_userid->Visible) { // userid ?>
		<!-- userid -->
		<td<?php echo $loantierhistory_preview->_userid->cellAttributes() ?>>
<span<?php echo $loantierhistory_preview->_userid->viewAttributes() ?>><?php if (!EmptyString($loantierhistory_preview->_userid->getViewValue()) && $loantierhistory_preview->_userid->linkAttributes() != "") { ?>
<a<?php echo $loantierhistory_preview->_userid->linkAttributes() ?>><?php echo $loantierhistory_preview->_userid->getViewValue() ?></a>
<?php } else { ?>
<?php echo $loantierhistory_preview->_userid->getViewValue() ?>
<?php } ?></span>
</td>
<?php } ?>
<?php if ($loantierhistory_preview->curr->Visible) { // curr ?>
		<!-- curr -->
		<td<?php echo $loantierhistory_preview->curr->cellAttributes() ?>>
<span<?php echo $loantierhistory_preview->curr->viewAttributes() ?>><?php echo $loantierhistory_preview->curr->getViewValue() ?></span>
</td>
<?php } ?>
<?php if ($loantierhistory_preview->fromtier->Visible) { // fromtier ?>
		<!-- fromtier -->
		<td<?php echo $loantierhistory_preview->fromtier->cellAttributes() ?>>
<span<?php echo $loantierhistory_preview->fromtier->viewAttributes() ?>><?php echo $loantierhistory_preview->fromtier->getViewValue() ?></span>
</td>
<?php } ?>
<?php if ($loantierhistory_preview->totier->Visible) { // totier ?>
		<!-- totier -->
		<td<?php echo $loantierhistory_preview->totier->cellAttributes() ?>>
<span<?php echo $loantierhistory_preview->totier->viewAttributes() ?>><?php echo $loantierhistory_preview->totier->getViewValue() ?></span>
</td>
<?php } ?>
<?php if ($loantierhistory_preview->changedate->Visible) { // changedate ?>
		<!-- changedate -->
		<td<?php echo $loantierhistory_preview->changedate->cellAttributes() ?>>
<span<?php echo $loantierhistory_preview->changedate->viewAttributes() ?>><?php echo $loantierhistory_preview->changedate->getViewValue() ?></span>
</td>
<?php } ?>
<?php

// Render list options (body, right)
$loantierhistory_preview->ListOptions->render("body", "right", $loantierhistory_preview->RowCount);
?>
	</tr>
<?php
	$loantierhistory_preview->Recordset->MoveNext();
} // while
?>
	</tbody>
</table><!-- /.table -->
</div><!-- /.table-responsive -->
<div class="card-footer ew-grid-lower-panel ew-preview-lower-panel"><!-- .card-footer -->
<?php echo $loantierhistory_preview->Pager->render() ?>
<?php } else { // No record ?>
<div class="card no-border">
<div class="ew-detail-count"><?php echo $Language->phrase("NoRecord") ?></div>
<?php } ?>
<div class="ew-preview-other-options">
<?php
	foreach ($loantierhistory_preview->OtherOptions as $option)
		$option->render("body");
?>
</div>
<?php if ($loantierhistory_preview->TotalRecords > 0) { ?>
<div class="clearfix"></div>
</div><!-- /.card-footer -->
<?php } ?>
</div><!-- /.card -->
<?php
$loantierhistory_preview->showPageFooter();
if (Config("DEBUG"))
	echo GetDebugMessage();
?>
<?php
if ($loantierhistory_preview->Recordset)
	$loantierhistory_preview->Recordset->Close();

// Output
$content = ob_get_contents();
ob_end_clean();
echo ConvertToUtf8($content);
?>
<?php
$loantierhistory_preview->terminate();
?>