<?php
namespace PHPMaker2020\_4payadmin;

// Autoload
include_once "autoload.php";

// Session
if (session_status() !== PHP_SESSION_ACTIVE)
	\Delight\Cookie\Session::start(Config("COOKIE_SAMESITE")); // Init session data

// Output buffering
ob_start();
?>
<?php

// Write header
WriteHeader(FALSE);

// Create page object
$subscriptions_view = new subscriptions_view();

// Run the page
$subscriptions_view->run();

// Setup login status
SetupLoginStatus();
SetClientVar("login", LoginStatus());

// Global Page Rendering event (in userfn*.php)
Page_Rendering();

// Page Rendering event
$subscriptions_view->Page_Render();
?>
<?php include_once "header.php"; ?>
<?php if (!$subscriptions_view->isExport()) { ?>
<script>
var fsubscriptionsview, currentPageID;
loadjs.ready("head", function() {

	// Form object
	currentPageID = ew.PAGE_ID = "view";
	fsubscriptionsview = currentForm = new ew.Form("fsubscriptionsview", "view");
	loadjs.done("fsubscriptionsview");
});
</script>
<script>
loadjs.ready("head", function() {

	// Client script
	// Write your client script here, no need to add script tags.

});
</script>
<?php } ?>
<?php if (!$subscriptions_view->isExport()) { ?>
<div class="btn-toolbar ew-toolbar">
<?php $subscriptions_view->ExportOptions->render("body") ?>
<?php $subscriptions_view->OtherOptions->render("body") ?>
<div class="clearfix"></div>
</div>
<?php } ?>
<?php $subscriptions_view->showPageHeader(); ?>
<?php
$subscriptions_view->showMessage();
?>
<form name="fsubscriptionsview" id="fsubscriptionsview" class="form-inline ew-form ew-view-form" action="<?php echo CurrentPageName() ?>" method="post">
<?php if ($Page->CheckToken) { ?>
<input type="hidden" name="<?php echo Config("TOKEN_NAME") ?>" value="<?php echo $Page->Token ?>">
<?php } ?>
<input type="hidden" name="t" value="subscriptions">
<input type="hidden" name="modal" value="<?php echo (int)$subscriptions_view->IsModal ?>">
<table class="table table-striped table-sm ew-view-table">
<?php if ($subscriptions_view->subscriptionid->Visible) { // subscriptionid ?>
	<tr id="r_subscriptionid">
		<td class="<?php echo $subscriptions_view->TableLeftColumnClass ?>"><span id="elh_subscriptions_subscriptionid"><?php echo $subscriptions_view->subscriptionid->caption() ?></span></td>
		<td data-name="subscriptionid" <?php echo $subscriptions_view->subscriptionid->cellAttributes() ?>>
<span id="el_subscriptions_subscriptionid">
<span<?php echo $subscriptions_view->subscriptionid->viewAttributes() ?>><?php echo $subscriptions_view->subscriptionid->getViewValue() ?></span>
</span>
</td>
	</tr>
<?php } ?>
<?php if ($subscriptions_view->merchantid->Visible) { // merchantid ?>
	<tr id="r_merchantid">
		<td class="<?php echo $subscriptions_view->TableLeftColumnClass ?>"><span id="elh_subscriptions_merchantid"><?php echo $subscriptions_view->merchantid->caption() ?></span></td>
		<td data-name="merchantid" <?php echo $subscriptions_view->merchantid->cellAttributes() ?>>
<span id="el_subscriptions_merchantid">
<span<?php echo $subscriptions_view->merchantid->viewAttributes() ?>><?php echo $subscriptions_view->merchantid->getViewValue() ?></span>
</span>
</td>
	</tr>
<?php } ?>
<?php if ($subscriptions_view->title->Visible) { // title ?>
	<tr id="r_title">
		<td class="<?php echo $subscriptions_view->TableLeftColumnClass ?>"><span id="elh_subscriptions_title"><?php echo $subscriptions_view->title->caption() ?></span></td>
		<td data-name="title" <?php echo $subscriptions_view->title->cellAttributes() ?>>
<span id="el_subscriptions_title">
<span<?php echo $subscriptions_view->title->viewAttributes() ?>><?php echo $subscriptions_view->title->getViewValue() ?></span>
</span>
</td>
	</tr>
<?php } ?>
<?php if ($subscriptions_view->description->Visible) { // description ?>
	<tr id="r_description">
		<td class="<?php echo $subscriptions_view->TableLeftColumnClass ?>"><span id="elh_subscriptions_description"><?php echo $subscriptions_view->description->caption() ?></span></td>
		<td data-name="description" <?php echo $subscriptions_view->description->cellAttributes() ?>>
<span id="el_subscriptions_description">
<span<?php echo $subscriptions_view->description->viewAttributes() ?>><?php echo $subscriptions_view->description->getViewValue() ?></span>
</span>
</td>
	</tr>
<?php } ?>
<?php if ($subscriptions_view->notes->Visible) { // notes ?>
	<tr id="r_notes">
		<td class="<?php echo $subscriptions_view->TableLeftColumnClass ?>"><span id="elh_subscriptions_notes"><?php echo $subscriptions_view->notes->caption() ?></span></td>
		<td data-name="notes" <?php echo $subscriptions_view->notes->cellAttributes() ?>>
<span id="el_subscriptions_notes">
<span<?php echo $subscriptions_view->notes->viewAttributes() ?>><?php echo $subscriptions_view->notes->getViewValue() ?></span>
</span>
</td>
	</tr>
<?php } ?>
<?php if ($subscriptions_view->currency->Visible) { // currency ?>
	<tr id="r_currency">
		<td class="<?php echo $subscriptions_view->TableLeftColumnClass ?>"><span id="elh_subscriptions_currency"><?php echo $subscriptions_view->currency->caption() ?></span></td>
		<td data-name="currency" <?php echo $subscriptions_view->currency->cellAttributes() ?>>
<span id="el_subscriptions_currency">
<span<?php echo $subscriptions_view->currency->viewAttributes() ?>><?php echo $subscriptions_view->currency->getViewValue() ?></span>
</span>
</td>
	</tr>
<?php } ?>
<?php if ($subscriptions_view->active->Visible) { // active ?>
	<tr id="r_active">
		<td class="<?php echo $subscriptions_view->TableLeftColumnClass ?>"><span id="elh_subscriptions_active"><?php echo $subscriptions_view->active->caption() ?></span></td>
		<td data-name="active" <?php echo $subscriptions_view->active->cellAttributes() ?>>
<span id="el_subscriptions_active">
<span<?php echo $subscriptions_view->active->viewAttributes() ?>><?php echo $subscriptions_view->active->getViewValue() ?></span>
</span>
</td>
	</tr>
<?php } ?>
<?php if ($subscriptions_view->picture->Visible) { // picture ?>
	<tr id="r_picture">
		<td class="<?php echo $subscriptions_view->TableLeftColumnClass ?>"><span id="elh_subscriptions_picture"><?php echo $subscriptions_view->picture->caption() ?></span></td>
		<td data-name="picture" <?php echo $subscriptions_view->picture->cellAttributes() ?>>
<span id="el_subscriptions_picture">
<span<?php echo $subscriptions_view->picture->viewAttributes() ?>><?php echo $subscriptions_view->picture->getViewValue() ?></span>
</span>
</td>
	</tr>
<?php } ?>
<?php if ($subscriptions_view->policyid->Visible) { // policyid ?>
	<tr id="r_policyid">
		<td class="<?php echo $subscriptions_view->TableLeftColumnClass ?>"><span id="elh_subscriptions_policyid"><?php echo $subscriptions_view->policyid->caption() ?></span></td>
		<td data-name="policyid" <?php echo $subscriptions_view->policyid->cellAttributes() ?>>
<span id="el_subscriptions_policyid">
<span<?php echo $subscriptions_view->policyid->viewAttributes() ?>><?php echo $subscriptions_view->policyid->getViewValue() ?></span>
</span>
</td>
	</tr>
<?php } ?>
<?php if ($subscriptions_view->extrafieldid->Visible) { // extrafieldid ?>
	<tr id="r_extrafieldid">
		<td class="<?php echo $subscriptions_view->TableLeftColumnClass ?>"><span id="elh_subscriptions_extrafieldid"><?php echo $subscriptions_view->extrafieldid->caption() ?></span></td>
		<td data-name="extrafieldid" <?php echo $subscriptions_view->extrafieldid->cellAttributes() ?>>
<span id="el_subscriptions_extrafieldid">
<span<?php echo $subscriptions_view->extrafieldid->viewAttributes() ?>><?php echo $subscriptions_view->extrafieldid->getViewValue() ?></span>
</span>
</td>
	</tr>
<?php } ?>
<?php if ($subscriptions_view->lastupdatedate->Visible) { // lastupdatedate ?>
	<tr id="r_lastupdatedate">
		<td class="<?php echo $subscriptions_view->TableLeftColumnClass ?>"><span id="elh_subscriptions_lastupdatedate"><?php echo $subscriptions_view->lastupdatedate->caption() ?></span></td>
		<td data-name="lastupdatedate" <?php echo $subscriptions_view->lastupdatedate->cellAttributes() ?>>
<span id="el_subscriptions_lastupdatedate">
<span<?php echo $subscriptions_view->lastupdatedate->viewAttributes() ?>><?php echo $subscriptions_view->lastupdatedate->getViewValue() ?></span>
</span>
</td>
	</tr>
<?php } ?>
</table>
</form>
<?php
$subscriptions_view->showPageFooter();
if (Config("DEBUG"))
	echo GetDebugMessage();
?>
<?php if (!$subscriptions_view->isExport()) { ?>
<script>
loadjs.ready("load", function() {

	// Startup script
	// Write your table-specific startup script here
	// console.log("page loaded");

});
</script>
<?php } ?>
<?php include_once "footer.php"; ?>
<?php
$subscriptions_view->terminate();
?>