<?php
namespace PHPMaker2020\_4payadmin;

// Autoload
include_once "autoload.php";

// Session
if (session_status() !== PHP_SESSION_ACTIVE)
	\Delight\Cookie\Session::start(Config("COOKIE_SAMESITE")); // Init session data

// Output buffering
ob_start();
?>
<?php

// Write header
WriteHeader(FALSE);

// Create page object
$loanpayments_list = new loanpayments_list();

// Run the page
$loanpayments_list->run();

// Setup login status
SetupLoginStatus();
SetClientVar("login", LoginStatus());

// Global Page Rendering event (in userfn*.php)
Page_Rendering();

// Page Rendering event
$loanpayments_list->Page_Render();
?>
<?php include_once "header.php"; ?>
<?php if (!$loanpayments_list->isExport()) { ?>
<script>
var floanpaymentslist, currentPageID;
loadjs.ready("head", function() {

	// Form object
	currentPageID = ew.PAGE_ID = "list";
	floanpaymentslist = currentForm = new ew.Form("floanpaymentslist", "list");
	floanpaymentslist.formKeyCountName = '<?php echo $loanpayments_list->FormKeyCountName ?>';
	loadjs.done("floanpaymentslist");
});
var floanpaymentslistsrch;
loadjs.ready("head", function() {

	// Form object for search
	floanpaymentslistsrch = currentSearchForm = new ew.Form("floanpaymentslistsrch");

	// Dynamic selection lists
	// Filters

	floanpaymentslistsrch.filterList = <?php echo $loanpayments_list->getFilterList() ?>;
	loadjs.done("floanpaymentslistsrch");
});
</script>
<style type="text/css">
.ew-table-preview-row { /* main table preview row color */
	background-color: #FFFFFF; /* preview row color */
}
.ew-table-preview-row .ew-grid {
	display: table;
}
</style>
<div id="ew-preview" class="d-none"><!-- preview -->
	<div class="ew-nav-tabs"><!-- .ew-nav-tabs -->
		<ul class="nav nav-tabs"></ul>
		<div class="tab-content"><!-- .tab-content -->
			<div class="tab-pane fade active show"></div>
		</div><!-- /.tab-content -->
	</div><!-- /.ew-nav-tabs -->
</div><!-- /preview -->
<script>
loadjs.ready("head", function() {
	ew.PREVIEW_PLACEMENT = ew.CSS_FLIP ? "right" : "left";
	ew.PREVIEW_SINGLE_ROW = false;
	ew.PREVIEW_OVERLAY = false;
	loadjs("js/ewpreview.js", "preview");
});
</script>
<script>
loadjs.ready("head", function() {

	// Client script
	// Write your client script here, no need to add script tags.

});
</script>
<?php } ?>
<?php if (!$loanpayments_list->isExport()) { ?>
<div class="btn-toolbar ew-toolbar">
<?php if ($loanpayments_list->TotalRecords > 0 && $loanpayments_list->ExportOptions->visible()) { ?>
<?php $loanpayments_list->ExportOptions->render("body") ?>
<?php } ?>
<?php if ($loanpayments_list->ImportOptions->visible()) { ?>
<?php $loanpayments_list->ImportOptions->render("body") ?>
<?php } ?>
<?php if ($loanpayments_list->SearchOptions->visible()) { ?>
<?php $loanpayments_list->SearchOptions->render("body") ?>
<?php } ?>
<?php if ($loanpayments_list->FilterOptions->visible()) { ?>
<?php $loanpayments_list->FilterOptions->render("body") ?>
<?php } ?>
<div class="clearfix"></div>
</div>
<?php } ?>
<?php if (!$loanpayments_list->isExport() || Config("EXPORT_MASTER_RECORD") && $loanpayments_list->isExport("print")) { ?>
<?php
if ($loanpayments_list->DbMasterFilter != "" && $loanpayments->getCurrentMasterTable() == "loanlimits") {
	if ($loanpayments_list->MasterRecordExists) {
		include_once "loanlimitsmaster.php";
	}
}
?>
<?php
if ($loanpayments_list->DbMasterFilter != "" && $loanpayments->getCurrentMasterTable() == "loanissued") {
	if ($loanpayments_list->MasterRecordExists) {
		include_once "loanissuedmaster.php";
	}
}
?>
<?php } ?>
<?php
$loanpayments_list->renderOtherOptions();
?>
<?php $loanpayments_list->showPageHeader(); ?>
<?php
$loanpayments_list->showMessage();
?>
<?php if ($loanpayments_list->TotalRecords > 0 || $loanpayments->CurrentAction) { ?>
<div class="card ew-card ew-grid<?php if ($loanpayments_list->isAddOrEdit()) { ?> ew-grid-add-edit<?php } ?> loanpayments">
<form name="floanpaymentslist" id="floanpaymentslist" class="form-inline ew-form ew-list-form" action="<?php echo CurrentPageName() ?>" method="post">
<?php if ($Page->CheckToken) { ?>
<input type="hidden" name="<?php echo Config("TOKEN_NAME") ?>" value="<?php echo $Page->Token ?>">
<?php } ?>
<input type="hidden" name="t" value="loanpayments">
<?php if ($loanpayments->getCurrentMasterTable() == "loanlimits" && $loanpayments->CurrentAction) { ?>
<input type="hidden" name="<?php echo Config("TABLE_SHOW_MASTER") ?>" value="loanlimits">
<input type="hidden" name="fk__userid" value="<?php echo HtmlEncode($loanpayments_list->_userid->getSessionValue()) ?>">
<?php } ?>
<?php if ($loanpayments->getCurrentMasterTable() == "loanissued" && $loanpayments->CurrentAction) { ?>
<input type="hidden" name="<?php echo Config("TABLE_SHOW_MASTER") ?>" value="loanissued">
<input type="hidden" name="fk_loanid" value="<?php echo HtmlEncode($loanpayments_list->loanid->getSessionValue()) ?>">
<input type="hidden" name="fk_currcode" value="<?php echo HtmlEncode($loanpayments_list->currcode->getSessionValue()) ?>">
<?php } ?>
<div id="gmp_loanpayments" class="<?php echo ResponsiveTableClass() ?>card-body ew-grid-middle-panel">
<?php if ($loanpayments_list->TotalRecords > 0 || $loanpayments_list->isGridEdit()) { ?>
<table id="tbl_loanpaymentslist" class="table ew-table"><!-- .ew-table -->
<thead>
	<tr class="ew-table-header">
<?php

// Header row
$loanpayments->RowType = ROWTYPE_HEADER;

// Render list options
$loanpayments_list->renderListOptions();

// Render list options (header, left)
$loanpayments_list->ListOptions->render("header", "left");
?>
<?php if ($loanpayments_list->paymentid->Visible) { // paymentid ?>
	<?php if ($loanpayments_list->SortUrl($loanpayments_list->paymentid) == "") { ?>
		<th data-name="paymentid" class="<?php echo $loanpayments_list->paymentid->headerCellClass() ?>"><div id="elh_loanpayments_paymentid" class="loanpayments_paymentid"><div class="ew-table-header-caption"><?php echo $loanpayments_list->paymentid->caption() ?></div></div></th>
	<?php } else { ?>
		<th data-name="paymentid" class="<?php echo $loanpayments_list->paymentid->headerCellClass() ?>"><div class="ew-pointer" onclick="ew.sort(event, '<?php echo $loanpayments_list->SortUrl($loanpayments_list->paymentid) ?>', 1);"><div id="elh_loanpayments_paymentid" class="loanpayments_paymentid">
			<div class="ew-table-header-btn"><span class="ew-table-header-caption"><?php echo $loanpayments_list->paymentid->caption() ?></span><span class="ew-table-header-sort"><?php if ($loanpayments_list->paymentid->getSort() == "ASC") { ?><i class="fas fa-sort-up"></i><?php } elseif ($loanpayments_list->paymentid->getSort() == "DESC") { ?><i class="fas fa-sort-down"></i><?php } ?></span></div>
		</div></div></th>
	<?php } ?>
<?php } ?>
<?php if ($loanpayments_list->paymentdate->Visible) { // paymentdate ?>
	<?php if ($loanpayments_list->SortUrl($loanpayments_list->paymentdate) == "") { ?>
		<th data-name="paymentdate" class="<?php echo $loanpayments_list->paymentdate->headerCellClass() ?>"><div id="elh_loanpayments_paymentdate" class="loanpayments_paymentdate"><div class="ew-table-header-caption"><?php echo $loanpayments_list->paymentdate->caption() ?></div></div></th>
	<?php } else { ?>
		<th data-name="paymentdate" class="<?php echo $loanpayments_list->paymentdate->headerCellClass() ?>"><div class="ew-pointer" onclick="ew.sort(event, '<?php echo $loanpayments_list->SortUrl($loanpayments_list->paymentdate) ?>', 1);"><div id="elh_loanpayments_paymentdate" class="loanpayments_paymentdate">
			<div class="ew-table-header-btn"><span class="ew-table-header-caption"><?php echo $loanpayments_list->paymentdate->caption() ?></span><span class="ew-table-header-sort"><?php if ($loanpayments_list->paymentdate->getSort() == "ASC") { ?><i class="fas fa-sort-up"></i><?php } elseif ($loanpayments_list->paymentdate->getSort() == "DESC") { ?><i class="fas fa-sort-down"></i><?php } ?></span></div>
		</div></div></th>
	<?php } ?>
<?php } ?>
<?php if ($loanpayments_list->_userid->Visible) { // userid ?>
	<?php if ($loanpayments_list->SortUrl($loanpayments_list->_userid) == "") { ?>
		<th data-name="_userid" class="<?php echo $loanpayments_list->_userid->headerCellClass() ?>"><div id="elh_loanpayments__userid" class="loanpayments__userid"><div class="ew-table-header-caption"><?php echo $loanpayments_list->_userid->caption() ?></div></div></th>
	<?php } else { ?>
		<th data-name="_userid" class="<?php echo $loanpayments_list->_userid->headerCellClass() ?>"><div class="ew-pointer" onclick="ew.sort(event, '<?php echo $loanpayments_list->SortUrl($loanpayments_list->_userid) ?>', 1);"><div id="elh_loanpayments__userid" class="loanpayments__userid">
			<div class="ew-table-header-btn"><span class="ew-table-header-caption"><?php echo $loanpayments_list->_userid->caption() ?></span><span class="ew-table-header-sort"><?php if ($loanpayments_list->_userid->getSort() == "ASC") { ?><i class="fas fa-sort-up"></i><?php } elseif ($loanpayments_list->_userid->getSort() == "DESC") { ?><i class="fas fa-sort-down"></i><?php } ?></span></div>
		</div></div></th>
	<?php } ?>
<?php } ?>
<?php if ($loanpayments_list->currcode->Visible) { // currcode ?>
	<?php if ($loanpayments_list->SortUrl($loanpayments_list->currcode) == "") { ?>
		<th data-name="currcode" class="<?php echo $loanpayments_list->currcode->headerCellClass() ?>"><div id="elh_loanpayments_currcode" class="loanpayments_currcode"><div class="ew-table-header-caption"><?php echo $loanpayments_list->currcode->caption() ?></div></div></th>
	<?php } else { ?>
		<th data-name="currcode" class="<?php echo $loanpayments_list->currcode->headerCellClass() ?>"><div class="ew-pointer" onclick="ew.sort(event, '<?php echo $loanpayments_list->SortUrl($loanpayments_list->currcode) ?>', 1);"><div id="elh_loanpayments_currcode" class="loanpayments_currcode">
			<div class="ew-table-header-btn"><span class="ew-table-header-caption"><?php echo $loanpayments_list->currcode->caption() ?></span><span class="ew-table-header-sort"><?php if ($loanpayments_list->currcode->getSort() == "ASC") { ?><i class="fas fa-sort-up"></i><?php } elseif ($loanpayments_list->currcode->getSort() == "DESC") { ?><i class="fas fa-sort-down"></i><?php } ?></span></div>
		</div></div></th>
	<?php } ?>
<?php } ?>
<?php if ($loanpayments_list->paymentamount->Visible) { // paymentamount ?>
	<?php if ($loanpayments_list->SortUrl($loanpayments_list->paymentamount) == "") { ?>
		<th data-name="paymentamount" class="<?php echo $loanpayments_list->paymentamount->headerCellClass() ?>"><div id="elh_loanpayments_paymentamount" class="loanpayments_paymentamount"><div class="ew-table-header-caption"><?php echo $loanpayments_list->paymentamount->caption() ?></div></div></th>
	<?php } else { ?>
		<th data-name="paymentamount" class="<?php echo $loanpayments_list->paymentamount->headerCellClass() ?>"><div class="ew-pointer" onclick="ew.sort(event, '<?php echo $loanpayments_list->SortUrl($loanpayments_list->paymentamount) ?>', 1);"><div id="elh_loanpayments_paymentamount" class="loanpayments_paymentamount">
			<div class="ew-table-header-btn"><span class="ew-table-header-caption"><?php echo $loanpayments_list->paymentamount->caption() ?></span><span class="ew-table-header-sort"><?php if ($loanpayments_list->paymentamount->getSort() == "ASC") { ?><i class="fas fa-sort-up"></i><?php } elseif ($loanpayments_list->paymentamount->getSort() == "DESC") { ?><i class="fas fa-sort-down"></i><?php } ?></span></div>
		</div></div></th>
	<?php } ?>
<?php } ?>
<?php if ($loanpayments_list->amountapplied->Visible) { // amountapplied ?>
	<?php if ($loanpayments_list->SortUrl($loanpayments_list->amountapplied) == "") { ?>
		<th data-name="amountapplied" class="<?php echo $loanpayments_list->amountapplied->headerCellClass() ?>"><div id="elh_loanpayments_amountapplied" class="loanpayments_amountapplied"><div class="ew-table-header-caption"><?php echo $loanpayments_list->amountapplied->caption() ?></div></div></th>
	<?php } else { ?>
		<th data-name="amountapplied" class="<?php echo $loanpayments_list->amountapplied->headerCellClass() ?>"><div class="ew-pointer" onclick="ew.sort(event, '<?php echo $loanpayments_list->SortUrl($loanpayments_list->amountapplied) ?>', 1);"><div id="elh_loanpayments_amountapplied" class="loanpayments_amountapplied">
			<div class="ew-table-header-btn"><span class="ew-table-header-caption"><?php echo $loanpayments_list->amountapplied->caption() ?></span><span class="ew-table-header-sort"><?php if ($loanpayments_list->amountapplied->getSort() == "ASC") { ?><i class="fas fa-sort-up"></i><?php } elseif ($loanpayments_list->amountapplied->getSort() == "DESC") { ?><i class="fas fa-sort-down"></i><?php } ?></span></div>
		</div></div></th>
	<?php } ?>
<?php } ?>
<?php if ($loanpayments_list->residualamount->Visible) { // residualamount ?>
	<?php if ($loanpayments_list->SortUrl($loanpayments_list->residualamount) == "") { ?>
		<th data-name="residualamount" class="<?php echo $loanpayments_list->residualamount->headerCellClass() ?>"><div id="elh_loanpayments_residualamount" class="loanpayments_residualamount"><div class="ew-table-header-caption"><?php echo $loanpayments_list->residualamount->caption() ?></div></div></th>
	<?php } else { ?>
		<th data-name="residualamount" class="<?php echo $loanpayments_list->residualamount->headerCellClass() ?>"><div class="ew-pointer" onclick="ew.sort(event, '<?php echo $loanpayments_list->SortUrl($loanpayments_list->residualamount) ?>', 1);"><div id="elh_loanpayments_residualamount" class="loanpayments_residualamount">
			<div class="ew-table-header-btn"><span class="ew-table-header-caption"><?php echo $loanpayments_list->residualamount->caption() ?></span><span class="ew-table-header-sort"><?php if ($loanpayments_list->residualamount->getSort() == "ASC") { ?><i class="fas fa-sort-up"></i><?php } elseif ($loanpayments_list->residualamount->getSort() == "DESC") { ?><i class="fas fa-sort-down"></i><?php } ?></span></div>
		</div></div></th>
	<?php } ?>
<?php } ?>
<?php if ($loanpayments_list->externalrefno->Visible) { // externalrefno ?>
	<?php if ($loanpayments_list->SortUrl($loanpayments_list->externalrefno) == "") { ?>
		<th data-name="externalrefno" class="<?php echo $loanpayments_list->externalrefno->headerCellClass() ?>"><div id="elh_loanpayments_externalrefno" class="loanpayments_externalrefno"><div class="ew-table-header-caption"><?php echo $loanpayments_list->externalrefno->caption() ?></div></div></th>
	<?php } else { ?>
		<th data-name="externalrefno" class="<?php echo $loanpayments_list->externalrefno->headerCellClass() ?>"><div class="ew-pointer" onclick="ew.sort(event, '<?php echo $loanpayments_list->SortUrl($loanpayments_list->externalrefno) ?>', 1);"><div id="elh_loanpayments_externalrefno" class="loanpayments_externalrefno">
			<div class="ew-table-header-btn"><span class="ew-table-header-caption"><?php echo $loanpayments_list->externalrefno->caption() ?></span><span class="ew-table-header-sort"><?php if ($loanpayments_list->externalrefno->getSort() == "ASC") { ?><i class="fas fa-sort-up"></i><?php } elseif ($loanpayments_list->externalrefno->getSort() == "DESC") { ?><i class="fas fa-sort-down"></i><?php } ?></span></div>
		</div></div></th>
	<?php } ?>
<?php } ?>
<?php if ($loanpayments_list->lockflag->Visible) { // lockflag ?>
	<?php if ($loanpayments_list->SortUrl($loanpayments_list->lockflag) == "") { ?>
		<th data-name="lockflag" class="<?php echo $loanpayments_list->lockflag->headerCellClass() ?>"><div id="elh_loanpayments_lockflag" class="loanpayments_lockflag"><div class="ew-table-header-caption"><?php echo $loanpayments_list->lockflag->caption() ?></div></div></th>
	<?php } else { ?>
		<th data-name="lockflag" class="<?php echo $loanpayments_list->lockflag->headerCellClass() ?>"><div class="ew-pointer" onclick="ew.sort(event, '<?php echo $loanpayments_list->SortUrl($loanpayments_list->lockflag) ?>', 1);"><div id="elh_loanpayments_lockflag" class="loanpayments_lockflag">
			<div class="ew-table-header-btn"><span class="ew-table-header-caption"><?php echo $loanpayments_list->lockflag->caption() ?></span><span class="ew-table-header-sort"><?php if ($loanpayments_list->lockflag->getSort() == "ASC") { ?><i class="fas fa-sort-up"></i><?php } elseif ($loanpayments_list->lockflag->getSort() == "DESC") { ?><i class="fas fa-sort-down"></i><?php } ?></span></div>
		</div></div></th>
	<?php } ?>
<?php } ?>
<?php if ($loanpayments_list->lastreconciledate->Visible) { // lastreconciledate ?>
	<?php if ($loanpayments_list->SortUrl($loanpayments_list->lastreconciledate) == "") { ?>
		<th data-name="lastreconciledate" class="<?php echo $loanpayments_list->lastreconciledate->headerCellClass() ?>"><div id="elh_loanpayments_lastreconciledate" class="loanpayments_lastreconciledate"><div class="ew-table-header-caption"><?php echo $loanpayments_list->lastreconciledate->caption() ?></div></div></th>
	<?php } else { ?>
		<th data-name="lastreconciledate" class="<?php echo $loanpayments_list->lastreconciledate->headerCellClass() ?>"><div class="ew-pointer" onclick="ew.sort(event, '<?php echo $loanpayments_list->SortUrl($loanpayments_list->lastreconciledate) ?>', 1);"><div id="elh_loanpayments_lastreconciledate" class="loanpayments_lastreconciledate">
			<div class="ew-table-header-btn"><span class="ew-table-header-caption"><?php echo $loanpayments_list->lastreconciledate->caption() ?></span><span class="ew-table-header-sort"><?php if ($loanpayments_list->lastreconciledate->getSort() == "ASC") { ?><i class="fas fa-sort-up"></i><?php } elseif ($loanpayments_list->lastreconciledate->getSort() == "DESC") { ?><i class="fas fa-sort-down"></i><?php } ?></span></div>
		</div></div></th>
	<?php } ?>
<?php } ?>
<?php

// Render list options (header, right)
$loanpayments_list->ListOptions->render("header", "right");
?>
	</tr>
</thead>
<tbody>
<?php
if ($loanpayments_list->ExportAll && $loanpayments_list->isExport()) {
	$loanpayments_list->StopRecord = $loanpayments_list->TotalRecords;
} else {

	// Set the last record to display
	if ($loanpayments_list->TotalRecords > $loanpayments_list->StartRecord + $loanpayments_list->DisplayRecords - 1)
		$loanpayments_list->StopRecord = $loanpayments_list->StartRecord + $loanpayments_list->DisplayRecords - 1;
	else
		$loanpayments_list->StopRecord = $loanpayments_list->TotalRecords;
}
$loanpayments_list->RecordCount = $loanpayments_list->StartRecord - 1;
if ($loanpayments_list->Recordset && !$loanpayments_list->Recordset->EOF) {
	$loanpayments_list->Recordset->moveFirst();
	$selectLimit = $loanpayments_list->UseSelectLimit;
	if (!$selectLimit && $loanpayments_list->StartRecord > 1)
		$loanpayments_list->Recordset->move($loanpayments_list->StartRecord - 1);
} elseif (!$loanpayments->AllowAddDeleteRow && $loanpayments_list->StopRecord == 0) {
	$loanpayments_list->StopRecord = $loanpayments->GridAddRowCount;
}

// Initialize aggregate
$loanpayments->RowType = ROWTYPE_AGGREGATEINIT;
$loanpayments->resetAttributes();
$loanpayments_list->renderRow();
while ($loanpayments_list->RecordCount < $loanpayments_list->StopRecord) {
	$loanpayments_list->RecordCount++;
	if ($loanpayments_list->RecordCount >= $loanpayments_list->StartRecord) {
		$loanpayments_list->RowCount++;

		// Set up key count
		$loanpayments_list->KeyCount = $loanpayments_list->RowIndex;

		// Init row class and style
		$loanpayments->resetAttributes();
		$loanpayments->CssClass = "";
		if ($loanpayments_list->isGridAdd()) {
		} else {
			$loanpayments_list->loadRowValues($loanpayments_list->Recordset); // Load row values
		}
		$loanpayments->RowType = ROWTYPE_VIEW; // Render view

		// Set up row id / data-rowindex
		$loanpayments->RowAttrs->merge(["data-rowindex" => $loanpayments_list->RowCount, "id" => "r" . $loanpayments_list->RowCount . "_loanpayments", "data-rowtype" => $loanpayments->RowType]);

		// Render row
		$loanpayments_list->renderRow();

		// Render list options
		$loanpayments_list->renderListOptions();
?>
	<tr <?php echo $loanpayments->rowAttributes() ?>>
<?php

// Render list options (body, left)
$loanpayments_list->ListOptions->render("body", "left", $loanpayments_list->RowCount);
?>
	<?php if ($loanpayments_list->paymentid->Visible) { // paymentid ?>
		<td data-name="paymentid" <?php echo $loanpayments_list->paymentid->cellAttributes() ?>>
<span id="el<?php echo $loanpayments_list->RowCount ?>_loanpayments_paymentid">
<span<?php echo $loanpayments_list->paymentid->viewAttributes() ?>><?php echo $loanpayments_list->paymentid->getViewValue() ?></span>
</span>
</td>
	<?php } ?>
	<?php if ($loanpayments_list->paymentdate->Visible) { // paymentdate ?>
		<td data-name="paymentdate" <?php echo $loanpayments_list->paymentdate->cellAttributes() ?>>
<span id="el<?php echo $loanpayments_list->RowCount ?>_loanpayments_paymentdate">
<span<?php echo $loanpayments_list->paymentdate->viewAttributes() ?>><?php echo $loanpayments_list->paymentdate->getViewValue() ?></span>
</span>
</td>
	<?php } ?>
	<?php if ($loanpayments_list->_userid->Visible) { // userid ?>
		<td data-name="_userid" <?php echo $loanpayments_list->_userid->cellAttributes() ?>>
<span id="el<?php echo $loanpayments_list->RowCount ?>_loanpayments__userid">
<span<?php echo $loanpayments_list->_userid->viewAttributes() ?>><?php if (!EmptyString($loanpayments_list->_userid->getViewValue()) && $loanpayments_list->_userid->linkAttributes() != "") { ?>
<a<?php echo $loanpayments_list->_userid->linkAttributes() ?>><?php echo $loanpayments_list->_userid->getViewValue() ?></a>
<?php } else { ?>
<?php echo $loanpayments_list->_userid->getViewValue() ?>
<?php } ?></span>
</span>
</td>
	<?php } ?>
	<?php if ($loanpayments_list->currcode->Visible) { // currcode ?>
		<td data-name="currcode" <?php echo $loanpayments_list->currcode->cellAttributes() ?>>
<span id="el<?php echo $loanpayments_list->RowCount ?>_loanpayments_currcode">
<span<?php echo $loanpayments_list->currcode->viewAttributes() ?>><?php echo $loanpayments_list->currcode->getViewValue() ?></span>
</span>
</td>
	<?php } ?>
	<?php if ($loanpayments_list->paymentamount->Visible) { // paymentamount ?>
		<td data-name="paymentamount" <?php echo $loanpayments_list->paymentamount->cellAttributes() ?>>
<span id="el<?php echo $loanpayments_list->RowCount ?>_loanpayments_paymentamount">
<span<?php echo $loanpayments_list->paymentamount->viewAttributes() ?>><?php echo $loanpayments_list->paymentamount->getViewValue() ?></span>
</span>
</td>
	<?php } ?>
	<?php if ($loanpayments_list->amountapplied->Visible) { // amountapplied ?>
		<td data-name="amountapplied" <?php echo $loanpayments_list->amountapplied->cellAttributes() ?>>
<span id="el<?php echo $loanpayments_list->RowCount ?>_loanpayments_amountapplied">
<span<?php echo $loanpayments_list->amountapplied->viewAttributes() ?>><?php echo $loanpayments_list->amountapplied->getViewValue() ?></span>
</span>
</td>
	<?php } ?>
	<?php if ($loanpayments_list->residualamount->Visible) { // residualamount ?>
		<td data-name="residualamount" <?php echo $loanpayments_list->residualamount->cellAttributes() ?>>
<span id="el<?php echo $loanpayments_list->RowCount ?>_loanpayments_residualamount">
<span<?php echo $loanpayments_list->residualamount->viewAttributes() ?>><?php echo $loanpayments_list->residualamount->getViewValue() ?></span>
</span>
</td>
	<?php } ?>
	<?php if ($loanpayments_list->externalrefno->Visible) { // externalrefno ?>
		<td data-name="externalrefno" <?php echo $loanpayments_list->externalrefno->cellAttributes() ?>>
<span id="el<?php echo $loanpayments_list->RowCount ?>_loanpayments_externalrefno">
<span<?php echo $loanpayments_list->externalrefno->viewAttributes() ?>><?php echo $loanpayments_list->externalrefno->getViewValue() ?></span>
</span>
</td>
	<?php } ?>
	<?php if ($loanpayments_list->lockflag->Visible) { // lockflag ?>
		<td data-name="lockflag" <?php echo $loanpayments_list->lockflag->cellAttributes() ?>>
<span id="el<?php echo $loanpayments_list->RowCount ?>_loanpayments_lockflag">
<span<?php echo $loanpayments_list->lockflag->viewAttributes() ?>><?php echo $loanpayments_list->lockflag->getViewValue() ?></span>
</span>
</td>
	<?php } ?>
	<?php if ($loanpayments_list->lastreconciledate->Visible) { // lastreconciledate ?>
		<td data-name="lastreconciledate" <?php echo $loanpayments_list->lastreconciledate->cellAttributes() ?>>
<span id="el<?php echo $loanpayments_list->RowCount ?>_loanpayments_lastreconciledate">
<span<?php echo $loanpayments_list->lastreconciledate->viewAttributes() ?>><?php echo $loanpayments_list->lastreconciledate->getViewValue() ?></span>
</span>
</td>
	<?php } ?>
<?php

// Render list options (body, right)
$loanpayments_list->ListOptions->render("body", "right", $loanpayments_list->RowCount);
?>
	</tr>
<?php
	}
	if (!$loanpayments_list->isGridAdd())
		$loanpayments_list->Recordset->moveNext();
}
?>
</tbody>
</table><!-- /.ew-table -->
<?php } ?>
</div><!-- /.ew-grid-middle-panel -->
<?php if (!$loanpayments->CurrentAction) { ?>
<input type="hidden" name="action" id="action" value="">
<?php } ?>
</form><!-- /.ew-list-form -->
<?php

// Close recordset
if ($loanpayments_list->Recordset)
	$loanpayments_list->Recordset->Close();
?>
<?php if (!$loanpayments_list->isExport()) { ?>
<div class="card-footer ew-grid-lower-panel">
<?php if (!$loanpayments_list->isGridAdd()) { ?>
<form name="ew-pager-form" class="form-inline ew-form ew-pager-form" action="<?php echo CurrentPageName() ?>">
<?php echo $loanpayments_list->Pager->render() ?>
</form>
<?php } ?>
<div class="ew-list-other-options">
<?php $loanpayments_list->OtherOptions->render("body", "bottom") ?>
</div>
<div class="clearfix"></div>
</div>
<?php } ?>
</div><!-- /.ew-grid -->
<?php } ?>
<?php if ($loanpayments_list->TotalRecords == 0 && !$loanpayments->CurrentAction) { // Show other options ?>
<div class="ew-list-other-options">
<?php $loanpayments_list->OtherOptions->render("body") ?>
</div>
<div class="clearfix"></div>
<?php } ?>
<?php
$loanpayments_list->showPageFooter();
if (Config("DEBUG"))
	echo GetDebugMessage();
?>
<?php if (!$loanpayments_list->isExport()) { ?>
<script>
loadjs.ready("load", function() {

	// Startup script
	// Write your table-specific startup script here
	// console.log("page loaded");

});
</script>
<?php } ?>
<?php include_once "footer.php"; ?>
<?php
$loanpayments_list->terminate();
?>