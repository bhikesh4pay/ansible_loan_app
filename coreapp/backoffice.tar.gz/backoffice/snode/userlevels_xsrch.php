<?php
namespace PHPMaker2020\_4payadmin;

// Autoload
include_once "autoload.php";

// Session
if (session_status() !== PHP_SESSION_ACTIVE)
	\Delight\Cookie\Session::start(Config("COOKIE_SAMESITE")); // Init session data

// Output buffering
ob_start();
?>
<?php

// Write header
WriteHeader(FALSE);

// Create page object
$userlevels_x_search = new userlevels_x_search();

// Run the page
$userlevels_x_search->run();

// Setup login status
SetupLoginStatus();
SetClientVar("login", LoginStatus());

// Global Page Rendering event (in userfn*.php)
Page_Rendering();

// Page Rendering event
$userlevels_x_search->Page_Render();
?>
<?php include_once "header.php"; ?>
<script>
var fuserlevels_xsearch, currentPageID;
loadjs.ready("head", function() {

	// Form object for search
	<?php if ($userlevels_x_search->IsModal) { ?>
	fuserlevels_xsearch = currentAdvancedSearchForm = new ew.Form("fuserlevels_xsearch", "search");
	<?php } else { ?>
	fuserlevels_xsearch = currentForm = new ew.Form("fuserlevels_xsearch", "search");
	<?php } ?>
	currentPageID = ew.PAGE_ID = "search";

	// Validate function for search
	fuserlevels_xsearch.validate = function(fobj) {
		if (!this.validateRequired)
			return true; // Ignore validation
		fobj = fobj || this._form;
		var infix = "";
		elm = this.getElements("x" + infix + "_userlevelid");
		if (elm && !ew.checkInteger(elm.value))
			return this.onError(elm, "<?php echo JsEncode($userlevels_x_search->userlevelid->errorMessage()) ?>");

		// Call Form_CustomValidate event
		if (!this.Form_CustomValidate(fobj))
			return false;
		return true;
	}

	// Form_CustomValidate
	fuserlevels_xsearch.Form_CustomValidate = function(fobj) { // DO NOT CHANGE THIS LINE!

		// Your custom validation code here, return false if invalid.
		return true;
	}

	// Use JavaScript validation or not
	fuserlevels_xsearch.validateRequired = <?php echo Config("CLIENT_VALIDATE") ? "true" : "false" ?>;

	// Dynamic selection lists
	loadjs.done("fuserlevels_xsearch");
});
</script>
<script>
loadjs.ready("head", function() {

	// Client script
	// Write your client script here, no need to add script tags.

});
</script>
<?php $userlevels_x_search->showPageHeader(); ?>
<?php
$userlevels_x_search->showMessage();
?>
<form name="fuserlevels_xsearch" id="fuserlevels_xsearch" class="<?php echo $userlevels_x_search->FormClassName ?>" action="<?php echo CurrentPageName() ?>" method="post">
<?php if ($Page->CheckToken) { ?>
<input type="hidden" name="<?php echo Config("TOKEN_NAME") ?>" value="<?php echo $Page->Token ?>">
<?php } ?>
<input type="hidden" name="t" value="userlevels_x">
<input type="hidden" name="action" id="action" value="search">
<input type="hidden" name="modal" value="<?php echo (int)$userlevels_x_search->IsModal ?>">
<div class="ew-search-div"><!-- page* -->
<?php if ($userlevels_x_search->userlevelid->Visible) { // userlevelid ?>
	<div id="r_userlevelid" class="form-group row">
		<label for="x_userlevelid" class="<?php echo $userlevels_x_search->LeftColumnClass ?>"><span id="elh_userlevels_x_userlevelid"><?php echo $userlevels_x_search->userlevelid->caption() ?></span>
		<span class="ew-search-operator">
<?php echo $Language->phrase("=") ?>
<input type="hidden" name="z_userlevelid" id="z_userlevelid" value="=">
</span>
		</label>
		<div class="<?php echo $userlevels_x_search->RightColumnClass ?>"><div <?php echo $userlevels_x_search->userlevelid->cellAttributes() ?>>
			<span id="el_userlevels_x_userlevelid" class="ew-search-field">
<input type="text" data-table="userlevels_x" data-field="x_userlevelid" name="x_userlevelid" id="x_userlevelid" size="30" maxlength="11" placeholder="<?php echo HtmlEncode($userlevels_x_search->userlevelid->getPlaceHolder()) ?>" value="<?php echo $userlevels_x_search->userlevelid->EditValue ?>"<?php echo $userlevels_x_search->userlevelid->editAttributes() ?>>
</span>
		</div></div>
	</div>
<?php } ?>
<?php if ($userlevels_x_search->userlevelname->Visible) { // userlevelname ?>
	<div id="r_userlevelname" class="form-group row">
		<label for="x_userlevelname" class="<?php echo $userlevels_x_search->LeftColumnClass ?>"><span id="elh_userlevels_x_userlevelname"><?php echo $userlevels_x_search->userlevelname->caption() ?></span>
		<span class="ew-search-operator">
<?php echo $Language->phrase("LIKE") ?>
<input type="hidden" name="z_userlevelname" id="z_userlevelname" value="LIKE">
</span>
		</label>
		<div class="<?php echo $userlevels_x_search->RightColumnClass ?>"><div <?php echo $userlevels_x_search->userlevelname->cellAttributes() ?>>
			<span id="el_userlevels_x_userlevelname" class="ew-search-field">
<input type="text" data-table="userlevels_x" data-field="x_userlevelname" name="x_userlevelname" id="x_userlevelname" size="30" maxlength="255" placeholder="<?php echo HtmlEncode($userlevels_x_search->userlevelname->getPlaceHolder()) ?>" value="<?php echo $userlevels_x_search->userlevelname->EditValue ?>"<?php echo $userlevels_x_search->userlevelname->editAttributes() ?>>
</span>
		</div></div>
	</div>
<?php } ?>
</div><!-- /page* -->
<?php if (!$userlevels_x_search->IsModal) { ?>
<div class="form-group row"><!-- buttons .form-group -->
	<div class="<?php echo $userlevels_x_search->OffsetColumnClass ?>"><!-- buttons offset -->
<button class="btn btn-primary ew-btn" name="btn-action" id="btn-action" type="submit"><?php echo $Language->phrase("Search") ?></button>
<button class="btn btn-default ew-btn" name="btn-reset" id="btn-reset" type="button" onclick="ew.clearForm(this.form);"><?php echo $Language->phrase("Reset") ?></button>
	</div><!-- /buttons offset -->
</div><!-- /buttons .form-group -->
<?php } ?>
</form>
<?php
$userlevels_x_search->showPageFooter();
if (Config("DEBUG"))
	echo GetDebugMessage();
?>
<script>
loadjs.ready("load", function() {

	// Startup script
	// Write your table-specific startup script here
	// console.log("page loaded");

});
</script>
<?php include_once "footer.php"; ?>
<?php
$userlevels_x_search->terminate();
?>