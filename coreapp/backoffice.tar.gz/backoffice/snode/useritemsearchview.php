<?php
namespace PHPMaker2020\_4payadmin;

// Autoload
include_once "autoload.php";

// Session
if (session_status() !== PHP_SESSION_ACTIVE)
	\Delight\Cookie\Session::start(Config("COOKIE_SAMESITE")); // Init session data

// Output buffering
ob_start();
?>
<?php

// Write header
WriteHeader(FALSE);

// Create page object
$useritemsearch_view = new useritemsearch_view();

// Run the page
$useritemsearch_view->run();

// Setup login status
SetupLoginStatus();
SetClientVar("login", LoginStatus());

// Global Page Rendering event (in userfn*.php)
Page_Rendering();

// Page Rendering event
$useritemsearch_view->Page_Render();
?>
<?php include_once "header.php"; ?>
<?php if (!$useritemsearch_view->isExport()) { ?>
<script>
var fuseritemsearchview, currentPageID;
loadjs.ready("head", function() {

	// Form object
	currentPageID = ew.PAGE_ID = "view";
	fuseritemsearchview = currentForm = new ew.Form("fuseritemsearchview", "view");
	loadjs.done("fuseritemsearchview");
});
</script>
<script>
loadjs.ready("head", function() {

	// Client script
	// Write your client script here, no need to add script tags.

});
</script>
<?php } ?>
<?php if (!$useritemsearch_view->isExport()) { ?>
<div class="btn-toolbar ew-toolbar">
<?php $useritemsearch_view->ExportOptions->render("body") ?>
<?php $useritemsearch_view->OtherOptions->render("body") ?>
<div class="clearfix"></div>
</div>
<?php } ?>
<?php $useritemsearch_view->showPageHeader(); ?>
<?php
$useritemsearch_view->showMessage();
?>
<form name="fuseritemsearchview" id="fuseritemsearchview" class="form-inline ew-form ew-view-form" action="<?php echo CurrentPageName() ?>" method="post">
<?php if ($Page->CheckToken) { ?>
<input type="hidden" name="<?php echo Config("TOKEN_NAME") ?>" value="<?php echo $Page->Token ?>">
<?php } ?>
<input type="hidden" name="t" value="useritemsearch">
<input type="hidden" name="modal" value="<?php echo (int)$useritemsearch_view->IsModal ?>">
<table class="table table-striped table-sm ew-view-table">
<?php if ($useritemsearch_view->requestid->Visible) { // requestid ?>
	<tr id="r_requestid">
		<td class="<?php echo $useritemsearch_view->TableLeftColumnClass ?>"><span id="elh_useritemsearch_requestid"><?php echo $useritemsearch_view->requestid->caption() ?></span></td>
		<td data-name="requestid" <?php echo $useritemsearch_view->requestid->cellAttributes() ?>>
<span id="el_useritemsearch_requestid">
<span<?php echo $useritemsearch_view->requestid->viewAttributes() ?>><?php echo $useritemsearch_view->requestid->getViewValue() ?></span>
</span>
</td>
	</tr>
<?php } ?>
<?php if ($useritemsearch_view->requestorid->Visible) { // requestorid ?>
	<tr id="r_requestorid">
		<td class="<?php echo $useritemsearch_view->TableLeftColumnClass ?>"><span id="elh_useritemsearch_requestorid"><?php echo $useritemsearch_view->requestorid->caption() ?></span></td>
		<td data-name="requestorid" <?php echo $useritemsearch_view->requestorid->cellAttributes() ?>>
<span id="el_useritemsearch_requestorid">
<span<?php echo $useritemsearch_view->requestorid->viewAttributes() ?>><?php echo $useritemsearch_view->requestorid->getViewValue() ?></span>
</span>
</td>
	</tr>
<?php } ?>
<?php if ($useritemsearch_view->requestdate->Visible) { // requestdate ?>
	<tr id="r_requestdate">
		<td class="<?php echo $useritemsearch_view->TableLeftColumnClass ?>"><span id="elh_useritemsearch_requestdate"><?php echo $useritemsearch_view->requestdate->caption() ?></span></td>
		<td data-name="requestdate" <?php echo $useritemsearch_view->requestdate->cellAttributes() ?>>
<span id="el_useritemsearch_requestdate">
<span<?php echo $useritemsearch_view->requestdate->viewAttributes() ?>><?php echo $useritemsearch_view->requestdate->getViewValue() ?></span>
</span>
</td>
	</tr>
<?php } ?>
<?php if ($useritemsearch_view->results->Visible) { // results ?>
	<tr id="r_results">
		<td class="<?php echo $useritemsearch_view->TableLeftColumnClass ?>"><span id="elh_useritemsearch_results"><?php echo $useritemsearch_view->results->caption() ?></span></td>
		<td data-name="results" <?php echo $useritemsearch_view->results->cellAttributes() ?>>
<span id="el_useritemsearch_results">
<span<?php echo $useritemsearch_view->results->viewAttributes() ?>><?php echo $useritemsearch_view->results->getViewValue() ?></span>
</span>
</td>
	</tr>
<?php } ?>
</table>
</form>
<?php
$useritemsearch_view->showPageFooter();
if (Config("DEBUG"))
	echo GetDebugMessage();
?>
<?php if (!$useritemsearch_view->isExport()) { ?>
<script>
loadjs.ready("load", function() {

	// Startup script
	// Write your table-specific startup script here
	// console.log("page loaded");

});
</script>
<?php } ?>
<?php include_once "footer.php"; ?>
<?php
$useritemsearch_view->terminate();
?>