<?php
namespace PHPMaker2020\_4payadmin;

// Autoload
include_once "autoload.php";

// Session
if (session_status() !== PHP_SESSION_ACTIVE)
	\Delight\Cookie\Session::start(Config("COOKIE_SAMESITE")); // Init session data

// Output buffering
ob_start();
?>
<?php

// Write header
WriteHeader(FALSE);

// Create page object
$merchantremmitance_edit = new merchantremmitance_edit();

// Run the page
$merchantremmitance_edit->run();

// Setup login status
SetupLoginStatus();
SetClientVar("login", LoginStatus());

// Global Page Rendering event (in userfn*.php)
Page_Rendering();

// Page Rendering event
$merchantremmitance_edit->Page_Render();
?>
<?php include_once "header.php"; ?>
<script>
var fmerchantremmitanceedit, currentPageID;
loadjs.ready("head", function() {

	// Form object
	currentPageID = ew.PAGE_ID = "edit";
	fmerchantremmitanceedit = currentForm = new ew.Form("fmerchantremmitanceedit", "edit");

	// Validate form
	fmerchantremmitanceedit.validate = function() {
		if (!this.validateRequired)
			return true; // Ignore validation
		var $ = jQuery, fobj = this.getForm(), $fobj = $(fobj);
		if ($fobj.find("#confirm").val() == "confirm")
			return true;
		var elm, felm, uelm, addcnt = 0;
		var $k = $fobj.find("#" + this.formKeyCountName); // Get key_count
		var rowcnt = ($k[0]) ? parseInt($k.val(), 10) : 1;
		var startcnt = (rowcnt == 0) ? 0 : 1; // Check rowcnt == 0 => Inline-Add
		var gridinsert = ["insert", "gridinsert"].includes($fobj.find("#action").val()) && $k[0];
		for (var i = startcnt; i <= rowcnt; i++) {
			var infix = ($k[0]) ? String(i) : "";
			$fobj.data("rowindex", infix);
			<?php if ($merchantremmitance_edit->remmitandid->Required) { ?>
				elm = this.getElements("x" + infix + "_remmitandid");
				if (elm && !ew.isHidden(elm) && !ew.hasValue(elm))
					return this.onError(elm, "<?php echo JsEncode(str_replace("%s", $merchantremmitance_edit->remmitandid->caption(), $merchantremmitance_edit->remmitandid->RequiredErrorMessage)) ?>");
			<?php } ?>
			<?php if ($merchantremmitance_edit->_userid->Required) { ?>
				elm = this.getElements("x" + infix + "__userid");
				if (elm && !ew.isHidden(elm) && !ew.hasValue(elm))
					return this.onError(elm, "<?php echo JsEncode(str_replace("%s", $merchantremmitance_edit->_userid->caption(), $merchantremmitance_edit->_userid->RequiredErrorMessage)) ?>");
			<?php } ?>
				elm = this.getElements("x" + infix + "__userid");
				if (elm && !ew.checkInteger(elm.value))
					return this.onError(elm, "<?php echo JsEncode($merchantremmitance_edit->_userid->errorMessage()) ?>");
			<?php if ($merchantremmitance_edit->transferdatetime->Required) { ?>
				elm = this.getElements("x" + infix + "_transferdatetime");
				if (elm && !ew.isHidden(elm) && !ew.hasValue(elm))
					return this.onError(elm, "<?php echo JsEncode(str_replace("%s", $merchantremmitance_edit->transferdatetime->caption(), $merchantremmitance_edit->transferdatetime->RequiredErrorMessage)) ?>");
			<?php } ?>
				elm = this.getElements("x" + infix + "_transferdatetime");
				if (elm && !ew.checkDateDef(elm.value))
					return this.onError(elm, "<?php echo JsEncode($merchantremmitance_edit->transferdatetime->errorMessage()) ?>");
			<?php if ($merchantremmitance_edit->currency->Required) { ?>
				elm = this.getElements("x" + infix + "_currency");
				if (elm && !ew.isHidden(elm) && !ew.hasValue(elm))
					return this.onError(elm, "<?php echo JsEncode(str_replace("%s", $merchantremmitance_edit->currency->caption(), $merchantremmitance_edit->currency->RequiredErrorMessage)) ?>");
			<?php } ?>
			<?php if ($merchantremmitance_edit->amount->Required) { ?>
				elm = this.getElements("x" + infix + "_amount");
				if (elm && !ew.isHidden(elm) && !ew.hasValue(elm))
					return this.onError(elm, "<?php echo JsEncode(str_replace("%s", $merchantremmitance_edit->amount->caption(), $merchantremmitance_edit->amount->RequiredErrorMessage)) ?>");
			<?php } ?>
				elm = this.getElements("x" + infix + "_amount");
				if (elm && !ew.checkNumber(elm.value))
					return this.onError(elm, "<?php echo JsEncode($merchantremmitance_edit->amount->errorMessage()) ?>");
			<?php if ($merchantremmitance_edit->completed->Required) { ?>
				elm = this.getElements("x" + infix + "_completed");
				if (elm && !ew.isHidden(elm) && !ew.hasValue(elm))
					return this.onError(elm, "<?php echo JsEncode(str_replace("%s", $merchantremmitance_edit->completed->caption(), $merchantremmitance_edit->completed->RequiredErrorMessage)) ?>");
			<?php } ?>
			<?php if ($merchantremmitance_edit->refno->Required) { ?>
				elm = this.getElements("x" + infix + "_refno");
				if (elm && !ew.isHidden(elm) && !ew.hasValue(elm))
					return this.onError(elm, "<?php echo JsEncode(str_replace("%s", $merchantremmitance_edit->refno->caption(), $merchantremmitance_edit->refno->RequiredErrorMessage)) ?>");
			<?php } ?>
			<?php if ($merchantremmitance_edit->refdate->Required) { ?>
				elm = this.getElements("x" + infix + "_refdate");
				if (elm && !ew.isHidden(elm) && !ew.hasValue(elm))
					return this.onError(elm, "<?php echo JsEncode(str_replace("%s", $merchantremmitance_edit->refdate->caption(), $merchantremmitance_edit->refdate->RequiredErrorMessage)) ?>");
			<?php } ?>
				elm = this.getElements("x" + infix + "_refdate");
				if (elm && !ew.checkDateDef(elm.value))
					return this.onError(elm, "<?php echo JsEncode($merchantremmitance_edit->refdate->errorMessage()) ?>");
			<?php if ($merchantremmitance_edit->userrequested->Required) { ?>
				elm = this.getElements("x" + infix + "_userrequested");
				if (elm && !ew.isHidden(elm) && !ew.hasValue(elm))
					return this.onError(elm, "<?php echo JsEncode(str_replace("%s", $merchantremmitance_edit->userrequested->caption(), $merchantremmitance_edit->userrequested->RequiredErrorMessage)) ?>");
			<?php } ?>
				elm = this.getElements("x" + infix + "_userrequested");
				if (elm && !ew.checkInteger(elm.value))
					return this.onError(elm, "<?php echo JsEncode($merchantremmitance_edit->userrequested->errorMessage()) ?>");

				// Call Form_CustomValidate event
				if (!this.Form_CustomValidate(fobj))
					return false;
		}

		// Process detail forms
		var dfs = $fobj.find("input[name='detailpage']").get();
		for (var i = 0; i < dfs.length; i++) {
			var df = dfs[i], val = df.value;
			if (val && ew.forms[val])
				if (!ew.forms[val].validate())
					return false;
		}
		return true;
	}

	// Form_CustomValidate
	fmerchantremmitanceedit.Form_CustomValidate = function(fobj) { // DO NOT CHANGE THIS LINE!

		// Your custom validation code here, return false if invalid.
		return true;
	}

	// Use JavaScript validation or not
	fmerchantremmitanceedit.validateRequired = <?php echo Config("CLIENT_VALIDATE") ? "true" : "false" ?>;

	// Dynamic selection lists
	fmerchantremmitanceedit.lists["x__userid"] = <?php echo $merchantremmitance_edit->_userid->Lookup->toClientList($merchantremmitance_edit) ?>;
	fmerchantremmitanceedit.lists["x__userid"].options = <?php echo JsonEncode($merchantremmitance_edit->_userid->lookupOptions()) ?>;
	fmerchantremmitanceedit.autoSuggests["x__userid"] = <?php echo json_encode(["data" => "ajax=autosuggest"]) ?>;
	fmerchantremmitanceedit.lists["x_completed"] = <?php echo $merchantremmitance_edit->completed->Lookup->toClientList($merchantremmitance_edit) ?>;
	fmerchantremmitanceedit.lists["x_completed"].options = <?php echo JsonEncode($merchantremmitance_edit->completed->lookupOptions()) ?>;
	loadjs.done("fmerchantremmitanceedit");
});
</script>
<script>
loadjs.ready("head", function() {

	// Client script
	// Write your client script here, no need to add script tags.

});
</script>
<?php $merchantremmitance_edit->showPageHeader(); ?>
<?php
$merchantremmitance_edit->showMessage();
?>
<form name="fmerchantremmitanceedit" id="fmerchantremmitanceedit" class="<?php echo $merchantremmitance_edit->FormClassName ?>" action="<?php echo CurrentPageName() ?>" method="post">
<?php if ($Page->CheckToken) { ?>
<input type="hidden" name="<?php echo Config("TOKEN_NAME") ?>" value="<?php echo $Page->Token ?>">
<?php } ?>
<input type="hidden" name="t" value="merchantremmitance">
<input type="hidden" name="action" id="action" value="update">
<input type="hidden" name="modal" value="<?php echo (int)$merchantremmitance_edit->IsModal ?>">
<?php if ($merchantremmitance->getCurrentMasterTable() == "merchant") { ?>
<input type="hidden" name="<?php echo Config("TABLE_SHOW_MASTER") ?>" value="merchant">
<input type="hidden" name="fk__userid" value="<?php echo HtmlEncode($merchantremmitance_edit->_userid->getSessionValue()) ?>">
<?php } ?>
<div class="ew-edit-div"><!-- page* -->
<?php if ($merchantremmitance_edit->remmitandid->Visible) { // remmitandid ?>
	<div id="r_remmitandid" class="form-group row">
		<label id="elh_merchantremmitance_remmitandid" class="<?php echo $merchantremmitance_edit->LeftColumnClass ?>"><?php echo $merchantremmitance_edit->remmitandid->caption() ?><?php echo $merchantremmitance_edit->remmitandid->Required ? $Language->phrase("FieldRequiredIndicator") : "" ?></label>
		<div class="<?php echo $merchantremmitance_edit->RightColumnClass ?>"><div <?php echo $merchantremmitance_edit->remmitandid->cellAttributes() ?>>
<span id="el_merchantremmitance_remmitandid">
<span<?php echo $merchantremmitance_edit->remmitandid->viewAttributes() ?>><input type="text" readonly class="form-control-plaintext" value="<?php echo HtmlEncode(RemoveHtml($merchantremmitance_edit->remmitandid->EditValue)) ?>"></span>
</span>
<input type="hidden" data-table="merchantremmitance" data-field="x_remmitandid" name="x_remmitandid" id="x_remmitandid" value="<?php echo HtmlEncode($merchantremmitance_edit->remmitandid->CurrentValue) ?>">
<?php echo $merchantremmitance_edit->remmitandid->CustomMsg ?></div></div>
	</div>
<?php } ?>
<?php if ($merchantremmitance_edit->_userid->Visible) { // userid ?>
	<div id="r__userid" class="form-group row">
		<label id="elh_merchantremmitance__userid" class="<?php echo $merchantremmitance_edit->LeftColumnClass ?>"><?php echo $merchantremmitance_edit->_userid->caption() ?><?php echo $merchantremmitance_edit->_userid->Required ? $Language->phrase("FieldRequiredIndicator") : "" ?></label>
		<div class="<?php echo $merchantremmitance_edit->RightColumnClass ?>"><div <?php echo $merchantremmitance_edit->_userid->cellAttributes() ?>>
<?php if ($merchantremmitance_edit->_userid->getSessionValue() != "") { ?>
<span id="el_merchantremmitance__userid">
<span<?php echo $merchantremmitance_edit->_userid->viewAttributes() ?>><?php if (!EmptyString($merchantremmitance_edit->_userid->ViewValue) && $merchantremmitance_edit->_userid->linkAttributes() != "") { ?>
<a<?php echo $merchantremmitance_edit->_userid->linkAttributes() ?>><input type="text" readonly class="form-control-plaintext" value="<?php echo HtmlEncode(RemoveHtml($merchantremmitance_edit->_userid->ViewValue)) ?>"></a>
<?php } else { ?>
<input type="text" readonly class="form-control-plaintext" value="<?php echo HtmlEncode(RemoveHtml($merchantremmitance_edit->_userid->ViewValue)) ?>">
<?php } ?></span>
</span>
<input type="hidden" id="x__userid" name="x__userid" value="<?php echo HtmlEncode($merchantremmitance_edit->_userid->CurrentValue) ?>">
<?php } else { ?>
<span id="el_merchantremmitance__userid">
<?php
$onchange = $merchantremmitance_edit->_userid->EditAttrs->prepend("onchange", "");
$onchange = ($onchange) ? ' onchange="' . JsEncode($onchange) . '"' : '';
$merchantremmitance_edit->_userid->EditAttrs["onchange"] = "";
?>
<span id="as_x__userid">
	<input type="text" class="form-control" name="sv_x__userid" id="sv_x__userid" value="<?php echo RemoveHtml($merchantremmitance_edit->_userid->EditValue) ?>" size="30" placeholder="<?php echo HtmlEncode($merchantremmitance_edit->_userid->getPlaceHolder()) ?>" data-placeholder="<?php echo HtmlEncode($merchantremmitance_edit->_userid->getPlaceHolder()) ?>"<?php echo $merchantremmitance_edit->_userid->editAttributes() ?>>
</span>
<input type="hidden" data-table="merchantremmitance" data-field="x__userid" data-value-separator="<?php echo $merchantremmitance_edit->_userid->displayValueSeparatorAttribute() ?>" name="x__userid" id="x__userid" value="<?php echo HtmlEncode($merchantremmitance_edit->_userid->CurrentValue) ?>"<?php echo $onchange ?>>
<script>
loadjs.ready(["fmerchantremmitanceedit"], function() {
	fmerchantremmitanceedit.createAutoSuggest({"id":"x__userid","forceSelect":false});
});
</script>
<?php echo $merchantremmitance_edit->_userid->Lookup->getParamTag($merchantremmitance_edit, "p_x__userid") ?>
</span>
<?php } ?>
<?php echo $merchantremmitance_edit->_userid->CustomMsg ?></div></div>
	</div>
<?php } ?>
<?php if ($merchantremmitance_edit->transferdatetime->Visible) { // transferdatetime ?>
	<div id="r_transferdatetime" class="form-group row">
		<label id="elh_merchantremmitance_transferdatetime" for="x_transferdatetime" class="<?php echo $merchantremmitance_edit->LeftColumnClass ?>"><?php echo $merchantremmitance_edit->transferdatetime->caption() ?><?php echo $merchantremmitance_edit->transferdatetime->Required ? $Language->phrase("FieldRequiredIndicator") : "" ?></label>
		<div class="<?php echo $merchantremmitance_edit->RightColumnClass ?>"><div <?php echo $merchantremmitance_edit->transferdatetime->cellAttributes() ?>>
<span id="el_merchantremmitance_transferdatetime">
<input type="text" data-table="merchantremmitance" data-field="x_transferdatetime" data-format="2" name="x_transferdatetime" id="x_transferdatetime" placeholder="<?php echo HtmlEncode($merchantremmitance_edit->transferdatetime->getPlaceHolder()) ?>" value="<?php echo $merchantremmitance_edit->transferdatetime->EditValue ?>"<?php echo $merchantremmitance_edit->transferdatetime->editAttributes() ?>>
<?php if (!$merchantremmitance_edit->transferdatetime->ReadOnly && !$merchantremmitance_edit->transferdatetime->Disabled && !isset($merchantremmitance_edit->transferdatetime->EditAttrs["readonly"]) && !isset($merchantremmitance_edit->transferdatetime->EditAttrs["disabled"])) { ?>
<script>
loadjs.ready(["fmerchantremmitanceedit", "datetimepicker"], function() {
	ew.createDateTimePicker("fmerchantremmitanceedit", "x_transferdatetime", {"ignoreReadonly":true,"useCurrent":false,"format":2});
});
</script>
<?php } ?>
</span>
<?php echo $merchantremmitance_edit->transferdatetime->CustomMsg ?></div></div>
	</div>
<?php } ?>
<?php if ($merchantremmitance_edit->currency->Visible) { // currency ?>
	<div id="r_currency" class="form-group row">
		<label id="elh_merchantremmitance_currency" for="x_currency" class="<?php echo $merchantremmitance_edit->LeftColumnClass ?>"><?php echo $merchantremmitance_edit->currency->caption() ?><?php echo $merchantremmitance_edit->currency->Required ? $Language->phrase("FieldRequiredIndicator") : "" ?></label>
		<div class="<?php echo $merchantremmitance_edit->RightColumnClass ?>"><div <?php echo $merchantremmitance_edit->currency->cellAttributes() ?>>
<span id="el_merchantremmitance_currency">
<input type="text" data-table="merchantremmitance" data-field="x_currency" name="x_currency" id="x_currency" size="30" maxlength="3" placeholder="<?php echo HtmlEncode($merchantremmitance_edit->currency->getPlaceHolder()) ?>" value="<?php echo $merchantremmitance_edit->currency->EditValue ?>"<?php echo $merchantremmitance_edit->currency->editAttributes() ?>>
</span>
<?php echo $merchantremmitance_edit->currency->CustomMsg ?></div></div>
	</div>
<?php } ?>
<?php if ($merchantremmitance_edit->amount->Visible) { // amount ?>
	<div id="r_amount" class="form-group row">
		<label id="elh_merchantremmitance_amount" for="x_amount" class="<?php echo $merchantremmitance_edit->LeftColumnClass ?>"><?php echo $merchantremmitance_edit->amount->caption() ?><?php echo $merchantremmitance_edit->amount->Required ? $Language->phrase("FieldRequiredIndicator") : "" ?></label>
		<div class="<?php echo $merchantremmitance_edit->RightColumnClass ?>"><div <?php echo $merchantremmitance_edit->amount->cellAttributes() ?>>
<span id="el_merchantremmitance_amount">
<input type="text" data-table="merchantremmitance" data-field="x_amount" name="x_amount" id="x_amount" size="30" placeholder="<?php echo HtmlEncode($merchantremmitance_edit->amount->getPlaceHolder()) ?>" value="<?php echo $merchantremmitance_edit->amount->EditValue ?>"<?php echo $merchantremmitance_edit->amount->editAttributes() ?>>
</span>
<?php echo $merchantremmitance_edit->amount->CustomMsg ?></div></div>
	</div>
<?php } ?>
<?php if ($merchantremmitance_edit->completed->Visible) { // completed ?>
	<div id="r_completed" class="form-group row">
		<label id="elh_merchantremmitance_completed" for="x_completed" class="<?php echo $merchantremmitance_edit->LeftColumnClass ?>"><?php echo $merchantremmitance_edit->completed->caption() ?><?php echo $merchantremmitance_edit->completed->Required ? $Language->phrase("FieldRequiredIndicator") : "" ?></label>
		<div class="<?php echo $merchantremmitance_edit->RightColumnClass ?>"><div <?php echo $merchantremmitance_edit->completed->cellAttributes() ?>>
<span id="el_merchantremmitance_completed">
<div class="input-group">
	<select class="custom-select ew-custom-select" data-table="merchantremmitance" data-field="x_completed" data-value-separator="<?php echo $merchantremmitance_edit->completed->displayValueSeparatorAttribute() ?>" id="x_completed" name="x_completed"<?php echo $merchantremmitance_edit->completed->editAttributes() ?>>
			<?php echo $merchantremmitance_edit->completed->selectOptionListHtml("x_completed") ?>
		</select>
</div>
<?php echo $merchantremmitance_edit->completed->Lookup->getParamTag($merchantremmitance_edit, "p_x_completed") ?>
</span>
<?php echo $merchantremmitance_edit->completed->CustomMsg ?></div></div>
	</div>
<?php } ?>
<?php if ($merchantremmitance_edit->refno->Visible) { // refno ?>
	<div id="r_refno" class="form-group row">
		<label id="elh_merchantremmitance_refno" for="x_refno" class="<?php echo $merchantremmitance_edit->LeftColumnClass ?>"><?php echo $merchantremmitance_edit->refno->caption() ?><?php echo $merchantremmitance_edit->refno->Required ? $Language->phrase("FieldRequiredIndicator") : "" ?></label>
		<div class="<?php echo $merchantremmitance_edit->RightColumnClass ?>"><div <?php echo $merchantremmitance_edit->refno->cellAttributes() ?>>
<span id="el_merchantremmitance_refno">
<input type="text" data-table="merchantremmitance" data-field="x_refno" name="x_refno" id="x_refno" size="30" maxlength="30" placeholder="<?php echo HtmlEncode($merchantremmitance_edit->refno->getPlaceHolder()) ?>" value="<?php echo $merchantremmitance_edit->refno->EditValue ?>"<?php echo $merchantremmitance_edit->refno->editAttributes() ?>>
</span>
<?php echo $merchantremmitance_edit->refno->CustomMsg ?></div></div>
	</div>
<?php } ?>
<?php if ($merchantremmitance_edit->refdate->Visible) { // refdate ?>
	<div id="r_refdate" class="form-group row">
		<label id="elh_merchantremmitance_refdate" for="x_refdate" class="<?php echo $merchantremmitance_edit->LeftColumnClass ?>"><?php echo $merchantremmitance_edit->refdate->caption() ?><?php echo $merchantremmitance_edit->refdate->Required ? $Language->phrase("FieldRequiredIndicator") : "" ?></label>
		<div class="<?php echo $merchantremmitance_edit->RightColumnClass ?>"><div <?php echo $merchantremmitance_edit->refdate->cellAttributes() ?>>
<span id="el_merchantremmitance_refdate">
<input type="text" data-table="merchantremmitance" data-field="x_refdate" name="x_refdate" id="x_refdate" placeholder="<?php echo HtmlEncode($merchantremmitance_edit->refdate->getPlaceHolder()) ?>" value="<?php echo $merchantremmitance_edit->refdate->EditValue ?>"<?php echo $merchantremmitance_edit->refdate->editAttributes() ?>>
</span>
<?php echo $merchantremmitance_edit->refdate->CustomMsg ?></div></div>
	</div>
<?php } ?>
<?php if ($merchantremmitance_edit->userrequested->Visible) { // userrequested ?>
	<div id="r_userrequested" class="form-group row">
		<label id="elh_merchantremmitance_userrequested" for="x_userrequested" class="<?php echo $merchantremmitance_edit->LeftColumnClass ?>"><?php echo $merchantremmitance_edit->userrequested->caption() ?><?php echo $merchantremmitance_edit->userrequested->Required ? $Language->phrase("FieldRequiredIndicator") : "" ?></label>
		<div class="<?php echo $merchantremmitance_edit->RightColumnClass ?>"><div <?php echo $merchantremmitance_edit->userrequested->cellAttributes() ?>>
<span id="el_merchantremmitance_userrequested">
<input type="text" data-table="merchantremmitance" data-field="x_userrequested" name="x_userrequested" id="x_userrequested" size="30" placeholder="<?php echo HtmlEncode($merchantremmitance_edit->userrequested->getPlaceHolder()) ?>" value="<?php echo $merchantremmitance_edit->userrequested->EditValue ?>"<?php echo $merchantremmitance_edit->userrequested->editAttributes() ?>>
</span>
<?php echo $merchantremmitance_edit->userrequested->CustomMsg ?></div></div>
	</div>
<?php } ?>
</div><!-- /page* -->
<?php if (!$merchantremmitance_edit->IsModal) { ?>
<div class="form-group row"><!-- buttons .form-group -->
	<div class="<?php echo $merchantremmitance_edit->OffsetColumnClass ?>"><!-- buttons offset -->
<button class="btn btn-primary ew-btn" name="btn-action" id="btn-action" type="submit"><?php echo $Language->phrase("SaveBtn") ?></button>
<button class="btn btn-default ew-btn" name="btn-cancel" id="btn-cancel" type="button" data-href="<?php echo $merchantremmitance_edit->getReturnUrl() ?>"><?php echo $Language->phrase("CancelBtn") ?></button>
	</div><!-- /buttons offset -->
</div><!-- /buttons .form-group -->
<?php } ?>
</form>
<?php
$merchantremmitance_edit->showPageFooter();
if (Config("DEBUG"))
	echo GetDebugMessage();
?>
<script>
loadjs.ready("load", function() {

	// Startup script
	// Write your table-specific startup script here
	// console.log("page loaded");

});
</script>
<?php include_once "footer.php"; ?>
<?php
$merchantremmitance_edit->terminate();
?>