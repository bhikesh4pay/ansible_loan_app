<?php
namespace PHPMaker2020\_4payadmin;

// Autoload
include_once "autoload.php";

// Session
if (session_status() !== PHP_SESSION_ACTIVE)
	\Delight\Cookie\Session::start(Config("COOKIE_SAMESITE")); // Init session data

// Output buffering
ob_start();
?>
<?php

// Write header
WriteHeader(FALSE, "utf-8");

// Create page object
$servicenodeconfigfranchisee_preview = new servicenodeconfigfranchisee_preview();

// Run the page
$servicenodeconfigfranchisee_preview->run();

// Setup login status
SetupLoginStatus();
SetClientVar("login", LoginStatus());

// Global Page Rendering event (in userfn*.php)
Page_Rendering();

// Page Rendering event
$servicenodeconfigfranchisee_preview->Page_Render();
?>
<?php $servicenodeconfigfranchisee_preview->showPageHeader(); ?>
<?php if ($servicenodeconfigfranchisee_preview->TotalRecords > 0) { ?>
<div class="card ew-grid servicenodeconfigfranchisee"><!-- .card -->
<div class="<?php echo ResponsiveTableClass() ?>card-body ew-grid-middle-panel ew-preview-middle-panel"><!-- .table-responsive -->
<table class="table ew-table ew-preview-table"><!-- .table -->
	<thead><!-- Table header -->
		<tr class="ew-table-header">
<?php

// Render list options
$servicenodeconfigfranchisee_preview->renderListOptions();

// Render list options (header, left)
$servicenodeconfigfranchisee_preview->ListOptions->render("header", "left");
?>
<?php if ($servicenodeconfigfranchisee_preview->configID->Visible) { // configID ?>
	<?php if ($servicenodeconfigfranchisee->SortUrl($servicenodeconfigfranchisee_preview->configID) == "") { ?>
		<th class="<?php echo $servicenodeconfigfranchisee_preview->configID->headerCellClass() ?>"><?php echo $servicenodeconfigfranchisee_preview->configID->caption() ?></th>
	<?php } else { ?>
		<th class="<?php echo $servicenodeconfigfranchisee_preview->configID->headerCellClass() ?>"><div class="ew-pointer" data-sort="<?php echo HtmlEncode($servicenodeconfigfranchisee_preview->configID->Name) ?>" data-sort-order="<?php echo $servicenodeconfigfranchisee_preview->SortField == $servicenodeconfigfranchisee_preview->configID->Name && $servicenodeconfigfranchisee_preview->SortOrder == "ASC" ? "DESC" : "ASC" ?>">
			<div class="ew-table-header-btn"><span class="ew-table-header-caption"><?php echo $servicenodeconfigfranchisee_preview->configID->caption() ?></span><span class="ew-table-header-sort"><?php if ($servicenodeconfigfranchisee_preview->SortField == $servicenodeconfigfranchisee_preview->configID->Name) { ?><?php if ($servicenodeconfigfranchisee_preview->SortOrder == "ASC") { ?><i class="fas fa-sort-up"></i><?php } elseif ($servicenodeconfigfranchisee_preview->SortOrder == "DESC") { ?><i class="fas fa-sort-down"></i><?php } ?><?php } ?></span>
		</div></div></th>
	<?php } ?>
<?php } ?>
<?php if ($servicenodeconfigfranchisee_preview->franchiseeid->Visible) { // franchiseeid ?>
	<?php if ($servicenodeconfigfranchisee->SortUrl($servicenodeconfigfranchisee_preview->franchiseeid) == "") { ?>
		<th class="<?php echo $servicenodeconfigfranchisee_preview->franchiseeid->headerCellClass() ?>"><?php echo $servicenodeconfigfranchisee_preview->franchiseeid->caption() ?></th>
	<?php } else { ?>
		<th class="<?php echo $servicenodeconfigfranchisee_preview->franchiseeid->headerCellClass() ?>"><div class="ew-pointer" data-sort="<?php echo HtmlEncode($servicenodeconfigfranchisee_preview->franchiseeid->Name) ?>" data-sort-order="<?php echo $servicenodeconfigfranchisee_preview->SortField == $servicenodeconfigfranchisee_preview->franchiseeid->Name && $servicenodeconfigfranchisee_preview->SortOrder == "ASC" ? "DESC" : "ASC" ?>">
			<div class="ew-table-header-btn"><span class="ew-table-header-caption"><?php echo $servicenodeconfigfranchisee_preview->franchiseeid->caption() ?></span><span class="ew-table-header-sort"><?php if ($servicenodeconfigfranchisee_preview->SortField == $servicenodeconfigfranchisee_preview->franchiseeid->Name) { ?><?php if ($servicenodeconfigfranchisee_preview->SortOrder == "ASC") { ?><i class="fas fa-sort-up"></i><?php } elseif ($servicenodeconfigfranchisee_preview->SortOrder == "DESC") { ?><i class="fas fa-sort-down"></i><?php } ?><?php } ?></span>
		</div></div></th>
	<?php } ?>
<?php } ?>
<?php if ($servicenodeconfigfranchisee_preview->value1->Visible) { // value1 ?>
	<?php if ($servicenodeconfigfranchisee->SortUrl($servicenodeconfigfranchisee_preview->value1) == "") { ?>
		<th class="<?php echo $servicenodeconfigfranchisee_preview->value1->headerCellClass() ?>"><?php echo $servicenodeconfigfranchisee_preview->value1->caption() ?></th>
	<?php } else { ?>
		<th class="<?php echo $servicenodeconfigfranchisee_preview->value1->headerCellClass() ?>"><div class="ew-pointer" data-sort="<?php echo HtmlEncode($servicenodeconfigfranchisee_preview->value1->Name) ?>" data-sort-order="<?php echo $servicenodeconfigfranchisee_preview->SortField == $servicenodeconfigfranchisee_preview->value1->Name && $servicenodeconfigfranchisee_preview->SortOrder == "ASC" ? "DESC" : "ASC" ?>">
			<div class="ew-table-header-btn"><span class="ew-table-header-caption"><?php echo $servicenodeconfigfranchisee_preview->value1->caption() ?></span><span class="ew-table-header-sort"><?php if ($servicenodeconfigfranchisee_preview->SortField == $servicenodeconfigfranchisee_preview->value1->Name) { ?><?php if ($servicenodeconfigfranchisee_preview->SortOrder == "ASC") { ?><i class="fas fa-sort-up"></i><?php } elseif ($servicenodeconfigfranchisee_preview->SortOrder == "DESC") { ?><i class="fas fa-sort-down"></i><?php } ?><?php } ?></span>
		</div></div></th>
	<?php } ?>
<?php } ?>
<?php if ($servicenodeconfigfranchisee_preview->value2->Visible) { // value2 ?>
	<?php if ($servicenodeconfigfranchisee->SortUrl($servicenodeconfigfranchisee_preview->value2) == "") { ?>
		<th class="<?php echo $servicenodeconfigfranchisee_preview->value2->headerCellClass() ?>"><?php echo $servicenodeconfigfranchisee_preview->value2->caption() ?></th>
	<?php } else { ?>
		<th class="<?php echo $servicenodeconfigfranchisee_preview->value2->headerCellClass() ?>"><div class="ew-pointer" data-sort="<?php echo HtmlEncode($servicenodeconfigfranchisee_preview->value2->Name) ?>" data-sort-order="<?php echo $servicenodeconfigfranchisee_preview->SortField == $servicenodeconfigfranchisee_preview->value2->Name && $servicenodeconfigfranchisee_preview->SortOrder == "ASC" ? "DESC" : "ASC" ?>">
			<div class="ew-table-header-btn"><span class="ew-table-header-caption"><?php echo $servicenodeconfigfranchisee_preview->value2->caption() ?></span><span class="ew-table-header-sort"><?php if ($servicenodeconfigfranchisee_preview->SortField == $servicenodeconfigfranchisee_preview->value2->Name) { ?><?php if ($servicenodeconfigfranchisee_preview->SortOrder == "ASC") { ?><i class="fas fa-sort-up"></i><?php } elseif ($servicenodeconfigfranchisee_preview->SortOrder == "DESC") { ?><i class="fas fa-sort-down"></i><?php } ?><?php } ?></span>
		</div></div></th>
	<?php } ?>
<?php } ?>
<?php if ($servicenodeconfigfranchisee_preview->value3->Visible) { // value3 ?>
	<?php if ($servicenodeconfigfranchisee->SortUrl($servicenodeconfigfranchisee_preview->value3) == "") { ?>
		<th class="<?php echo $servicenodeconfigfranchisee_preview->value3->headerCellClass() ?>"><?php echo $servicenodeconfigfranchisee_preview->value3->caption() ?></th>
	<?php } else { ?>
		<th class="<?php echo $servicenodeconfigfranchisee_preview->value3->headerCellClass() ?>"><div class="ew-pointer" data-sort="<?php echo HtmlEncode($servicenodeconfigfranchisee_preview->value3->Name) ?>" data-sort-order="<?php echo $servicenodeconfigfranchisee_preview->SortField == $servicenodeconfigfranchisee_preview->value3->Name && $servicenodeconfigfranchisee_preview->SortOrder == "ASC" ? "DESC" : "ASC" ?>">
			<div class="ew-table-header-btn"><span class="ew-table-header-caption"><?php echo $servicenodeconfigfranchisee_preview->value3->caption() ?></span><span class="ew-table-header-sort"><?php if ($servicenodeconfigfranchisee_preview->SortField == $servicenodeconfigfranchisee_preview->value3->Name) { ?><?php if ($servicenodeconfigfranchisee_preview->SortOrder == "ASC") { ?><i class="fas fa-sort-up"></i><?php } elseif ($servicenodeconfigfranchisee_preview->SortOrder == "DESC") { ?><i class="fas fa-sort-down"></i><?php } ?><?php } ?></span>
		</div></div></th>
	<?php } ?>
<?php } ?>
<?php

// Render list options (header, right)
$servicenodeconfigfranchisee_preview->ListOptions->render("header", "right");
?>
		</tr>
	</thead>
	<tbody><!-- Table body -->
<?php
$servicenodeconfigfranchisee_preview->RecCount = 0;
$servicenodeconfigfranchisee_preview->RowCount = 0;
while ($servicenodeconfigfranchisee_preview->Recordset && !$servicenodeconfigfranchisee_preview->Recordset->EOF) {

	// Init row class and style
	$servicenodeconfigfranchisee_preview->RecCount++;
	$servicenodeconfigfranchisee_preview->RowCount++;
	$servicenodeconfigfranchisee_preview->CssStyle = "";
	$servicenodeconfigfranchisee_preview->loadListRowValues($servicenodeconfigfranchisee_preview->Recordset);

	// Render row
	$servicenodeconfigfranchisee->RowType = ROWTYPE_PREVIEW; // Preview record
	$servicenodeconfigfranchisee_preview->resetAttributes();
	$servicenodeconfigfranchisee_preview->renderListRow();

	// Render list options
	$servicenodeconfigfranchisee_preview->renderListOptions();
?>
	<tr <?php echo $servicenodeconfigfranchisee->rowAttributes() ?>>
<?php

// Render list options (body, left)
$servicenodeconfigfranchisee_preview->ListOptions->render("body", "left", $servicenodeconfigfranchisee_preview->RowCount);
?>
<?php if ($servicenodeconfigfranchisee_preview->configID->Visible) { // configID ?>
		<!-- configID -->
		<td<?php echo $servicenodeconfigfranchisee_preview->configID->cellAttributes() ?>>
<span<?php echo $servicenodeconfigfranchisee_preview->configID->viewAttributes() ?>><?php echo $servicenodeconfigfranchisee_preview->configID->getViewValue() ?></span>
</td>
<?php } ?>
<?php if ($servicenodeconfigfranchisee_preview->franchiseeid->Visible) { // franchiseeid ?>
		<!-- franchiseeid -->
		<td<?php echo $servicenodeconfigfranchisee_preview->franchiseeid->cellAttributes() ?>>
<span<?php echo $servicenodeconfigfranchisee_preview->franchiseeid->viewAttributes() ?>><?php echo $servicenodeconfigfranchisee_preview->franchiseeid->getViewValue() ?></span>
</td>
<?php } ?>
<?php if ($servicenodeconfigfranchisee_preview->value1->Visible) { // value1 ?>
		<!-- value1 -->
		<td<?php echo $servicenodeconfigfranchisee_preview->value1->cellAttributes() ?>>
<span<?php echo $servicenodeconfigfranchisee_preview->value1->viewAttributes() ?>><?php echo $servicenodeconfigfranchisee_preview->value1->getViewValue() ?></span>
</td>
<?php } ?>
<?php if ($servicenodeconfigfranchisee_preview->value2->Visible) { // value2 ?>
		<!-- value2 -->
		<td<?php echo $servicenodeconfigfranchisee_preview->value2->cellAttributes() ?>>
<span<?php echo $servicenodeconfigfranchisee_preview->value2->viewAttributes() ?>><?php echo $servicenodeconfigfranchisee_preview->value2->getViewValue() ?></span>
</td>
<?php } ?>
<?php if ($servicenodeconfigfranchisee_preview->value3->Visible) { // value3 ?>
		<!-- value3 -->
		<td<?php echo $servicenodeconfigfranchisee_preview->value3->cellAttributes() ?>>
<span<?php echo $servicenodeconfigfranchisee_preview->value3->viewAttributes() ?>><?php echo $servicenodeconfigfranchisee_preview->value3->getViewValue() ?></span>
</td>
<?php } ?>
<?php

// Render list options (body, right)
$servicenodeconfigfranchisee_preview->ListOptions->render("body", "right", $servicenodeconfigfranchisee_preview->RowCount);
?>
	</tr>
<?php
	$servicenodeconfigfranchisee_preview->Recordset->MoveNext();
} // while
?>
	</tbody>
</table><!-- /.table -->
</div><!-- /.table-responsive -->
<div class="card-footer ew-grid-lower-panel ew-preview-lower-panel"><!-- .card-footer -->
<?php echo $servicenodeconfigfranchisee_preview->Pager->render() ?>
<?php } else { // No record ?>
<div class="card no-border">
<div class="ew-detail-count"><?php echo $Language->phrase("NoRecord") ?></div>
<?php } ?>
<div class="ew-preview-other-options">
<?php
	foreach ($servicenodeconfigfranchisee_preview->OtherOptions as $option)
		$option->render("body");
?>
</div>
<?php if ($servicenodeconfigfranchisee_preview->TotalRecords > 0) { ?>
<div class="clearfix"></div>
</div><!-- /.card-footer -->
<?php } ?>
</div><!-- /.card -->
<?php
$servicenodeconfigfranchisee_preview->showPageFooter();
if (Config("DEBUG"))
	echo GetDebugMessage();
?>
<?php
if ($servicenodeconfigfranchisee_preview->Recordset)
	$servicenodeconfigfranchisee_preview->Recordset->Close();

// Output
$content = ob_get_contents();
ob_end_clean();
echo ConvertToUtf8($content);
?>
<?php
$servicenodeconfigfranchisee_preview->terminate();
?>