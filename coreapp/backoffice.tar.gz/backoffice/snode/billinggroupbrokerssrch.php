<?php
namespace PHPMaker2020\_4payadmin;

// Autoload
include_once "autoload.php";

// Session
if (session_status() !== PHP_SESSION_ACTIVE)
	\Delight\Cookie\Session::start(Config("COOKIE_SAMESITE")); // Init session data

// Output buffering
ob_start();
?>
<?php

// Write header
WriteHeader(FALSE);

// Create page object
$billinggroupbrokers_search = new billinggroupbrokers_search();

// Run the page
$billinggroupbrokers_search->run();

// Setup login status
SetupLoginStatus();
SetClientVar("login", LoginStatus());

// Global Page Rendering event (in userfn*.php)
Page_Rendering();

// Page Rendering event
$billinggroupbrokers_search->Page_Render();
?>
<?php include_once "header.php"; ?>
<script>
var fbillinggroupbrokerssearch, currentPageID;
loadjs.ready("head", function() {

	// Form object for search
	<?php if ($billinggroupbrokers_search->IsModal) { ?>
	fbillinggroupbrokerssearch = currentAdvancedSearchForm = new ew.Form("fbillinggroupbrokerssearch", "search");
	<?php } else { ?>
	fbillinggroupbrokerssearch = currentForm = new ew.Form("fbillinggroupbrokerssearch", "search");
	<?php } ?>
	currentPageID = ew.PAGE_ID = "search";

	// Validate function for search
	fbillinggroupbrokerssearch.validate = function(fobj) {
		if (!this.validateRequired)
			return true; // Ignore validation
		fobj = fobj || this._form;
		var infix = "";
		elm = this.getElements("x" + infix + "_brokeruserid");
		if (elm && !ew.checkInteger(elm.value))
			return this.onError(elm, "<?php echo JsEncode($billinggroupbrokers_search->brokeruserid->errorMessage()) ?>");
		elm = this.getElements("x" + infix + "_lastupdatedate");
		if (elm && !ew.checkDateDef(elm.value))
			return this.onError(elm, "<?php echo JsEncode($billinggroupbrokers_search->lastupdatedate->errorMessage()) ?>");

		// Call Form_CustomValidate event
		if (!this.Form_CustomValidate(fobj))
			return false;
		return true;
	}

	// Form_CustomValidate
	fbillinggroupbrokerssearch.Form_CustomValidate = function(fobj) { // DO NOT CHANGE THIS LINE!

		// Your custom validation code here, return false if invalid.
		return true;
	}

	// Use JavaScript validation or not
	fbillinggroupbrokerssearch.validateRequired = <?php echo Config("CLIENT_VALIDATE") ? "true" : "false" ?>;

	// Dynamic selection lists
	fbillinggroupbrokerssearch.lists["x_groupid"] = <?php echo $billinggroupbrokers_search->groupid->Lookup->toClientList($billinggroupbrokers_search) ?>;
	fbillinggroupbrokerssearch.lists["x_groupid"].options = <?php echo JsonEncode($billinggroupbrokers_search->groupid->lookupOptions()) ?>;
	fbillinggroupbrokerssearch.lists["x_active"] = <?php echo $billinggroupbrokers_search->active->Lookup->toClientList($billinggroupbrokers_search) ?>;
	fbillinggroupbrokerssearch.lists["x_active"].options = <?php echo JsonEncode($billinggroupbrokers_search->active->lookupOptions()) ?>;
	loadjs.done("fbillinggroupbrokerssearch");
});
</script>
<script>
loadjs.ready("head", function() {

	// Client script
	// Write your client script here, no need to add script tags.

});
</script>
<?php $billinggroupbrokers_search->showPageHeader(); ?>
<?php
$billinggroupbrokers_search->showMessage();
?>
<form name="fbillinggroupbrokerssearch" id="fbillinggroupbrokerssearch" class="<?php echo $billinggroupbrokers_search->FormClassName ?>" action="<?php echo CurrentPageName() ?>" method="post">
<?php if ($Page->CheckToken) { ?>
<input type="hidden" name="<?php echo Config("TOKEN_NAME") ?>" value="<?php echo $Page->Token ?>">
<?php } ?>
<input type="hidden" name="t" value="billinggroupbrokers">
<input type="hidden" name="action" id="action" value="search">
<input type="hidden" name="modal" value="<?php echo (int)$billinggroupbrokers_search->IsModal ?>">
<div class="ew-search-div"><!-- page* -->
<?php if ($billinggroupbrokers_search->groupid->Visible) { // groupid ?>
	<div id="r_groupid" class="form-group row">
		<label for="x_groupid" class="<?php echo $billinggroupbrokers_search->LeftColumnClass ?>"><span id="elh_billinggroupbrokers_groupid"><?php echo $billinggroupbrokers_search->groupid->caption() ?></span>
		<span class="ew-search-operator">
<?php echo $Language->phrase("=") ?>
<input type="hidden" name="z_groupid" id="z_groupid" value="=">
</span>
		</label>
		<div class="<?php echo $billinggroupbrokers_search->RightColumnClass ?>"><div <?php echo $billinggroupbrokers_search->groupid->cellAttributes() ?>>
			<span id="el_billinggroupbrokers_groupid" class="ew-search-field">
<div class="input-group">
	<select class="custom-select ew-custom-select" data-table="billinggroupbrokers" data-field="x_groupid" data-value-separator="<?php echo $billinggroupbrokers_search->groupid->displayValueSeparatorAttribute() ?>" id="x_groupid" name="x_groupid"<?php echo $billinggroupbrokers_search->groupid->editAttributes() ?>>
			<?php echo $billinggroupbrokers_search->groupid->selectOptionListHtml("x_groupid") ?>
		</select>
</div>
<?php echo $billinggroupbrokers_search->groupid->Lookup->getParamTag($billinggroupbrokers_search, "p_x_groupid") ?>
</span>
		</div></div>
	</div>
<?php } ?>
<?php if ($billinggroupbrokers_search->brokeruserid->Visible) { // brokeruserid ?>
	<div id="r_brokeruserid" class="form-group row">
		<label for="x_brokeruserid" class="<?php echo $billinggroupbrokers_search->LeftColumnClass ?>"><span id="elh_billinggroupbrokers_brokeruserid"><?php echo $billinggroupbrokers_search->brokeruserid->caption() ?></span>
		<span class="ew-search-operator">
<?php echo $Language->phrase("=") ?>
<input type="hidden" name="z_brokeruserid" id="z_brokeruserid" value="=">
</span>
		</label>
		<div class="<?php echo $billinggroupbrokers_search->RightColumnClass ?>"><div <?php echo $billinggroupbrokers_search->brokeruserid->cellAttributes() ?>>
			<span id="el_billinggroupbrokers_brokeruserid" class="ew-search-field">
<input type="text" data-table="billinggroupbrokers" data-field="x_brokeruserid" name="x_brokeruserid" id="x_brokeruserid" size="30" placeholder="<?php echo HtmlEncode($billinggroupbrokers_search->brokeruserid->getPlaceHolder()) ?>" value="<?php echo $billinggroupbrokers_search->brokeruserid->EditValue ?>"<?php echo $billinggroupbrokers_search->brokeruserid->editAttributes() ?>>
</span>
		</div></div>
	</div>
<?php } ?>
<?php if ($billinggroupbrokers_search->active->Visible) { // active ?>
	<div id="r_active" class="form-group row">
		<label class="<?php echo $billinggroupbrokers_search->LeftColumnClass ?>"><span id="elh_billinggroupbrokers_active"><?php echo $billinggroupbrokers_search->active->caption() ?></span>
		<span class="ew-search-operator">
<?php echo $Language->phrase("=") ?>
<input type="hidden" name="z_active" id="z_active" value="=">
</span>
		</label>
		<div class="<?php echo $billinggroupbrokers_search->RightColumnClass ?>"><div <?php echo $billinggroupbrokers_search->active->cellAttributes() ?>>
			<span id="el_billinggroupbrokers_active" class="ew-search-field">
<div id="tp_x_active" class="ew-template"><input type="radio" class="custom-control-input" data-table="billinggroupbrokers" data-field="x_active" data-value-separator="<?php echo $billinggroupbrokers_search->active->displayValueSeparatorAttribute() ?>" name="x_active" id="x_active" value="{value}"<?php echo $billinggroupbrokers_search->active->editAttributes() ?>></div>
<div id="dsl_x_active" data-repeatcolumn="5" class="ew-item-list d-none"><div>
<?php echo $billinggroupbrokers_search->active->radioButtonListHtml(FALSE, "x_active") ?>
</div></div>
<?php echo $billinggroupbrokers_search->active->Lookup->getParamTag($billinggroupbrokers_search, "p_x_active") ?>
</span>
		</div></div>
	</div>
<?php } ?>
<?php if ($billinggroupbrokers_search->lastupdatedate->Visible) { // lastupdatedate ?>
	<div id="r_lastupdatedate" class="form-group row">
		<label for="x_lastupdatedate" class="<?php echo $billinggroupbrokers_search->LeftColumnClass ?>"><span id="elh_billinggroupbrokers_lastupdatedate"><?php echo $billinggroupbrokers_search->lastupdatedate->caption() ?></span>
		<span class="ew-search-operator">
<?php echo $Language->phrase("=") ?>
<input type="hidden" name="z_lastupdatedate" id="z_lastupdatedate" value="=">
</span>
		</label>
		<div class="<?php echo $billinggroupbrokers_search->RightColumnClass ?>"><div <?php echo $billinggroupbrokers_search->lastupdatedate->cellAttributes() ?>>
			<span id="el_billinggroupbrokers_lastupdatedate" class="ew-search-field">
<input type="text" data-table="billinggroupbrokers" data-field="x_lastupdatedate" data-format="1" name="x_lastupdatedate" id="x_lastupdatedate" placeholder="<?php echo HtmlEncode($billinggroupbrokers_search->lastupdatedate->getPlaceHolder()) ?>" value="<?php echo $billinggroupbrokers_search->lastupdatedate->EditValue ?>"<?php echo $billinggroupbrokers_search->lastupdatedate->editAttributes() ?>>
</span>
		</div></div>
	</div>
<?php } ?>
</div><!-- /page* -->
<?php if (!$billinggroupbrokers_search->IsModal) { ?>
<div class="form-group row"><!-- buttons .form-group -->
	<div class="<?php echo $billinggroupbrokers_search->OffsetColumnClass ?>"><!-- buttons offset -->
<button class="btn btn-primary ew-btn" name="btn-action" id="btn-action" type="submit"><?php echo $Language->phrase("Search") ?></button>
<button class="btn btn-default ew-btn" name="btn-reset" id="btn-reset" type="button" onclick="ew.clearForm(this.form);"><?php echo $Language->phrase("Reset") ?></button>
	</div><!-- /buttons offset -->
</div><!-- /buttons .form-group -->
<?php } ?>
</form>
<?php
$billinggroupbrokers_search->showPageFooter();
if (Config("DEBUG"))
	echo GetDebugMessage();
?>
<script>
loadjs.ready("load", function() {

	// Startup script
	// Write your table-specific startup script here
	// console.log("page loaded");

});
</script>
<?php include_once "footer.php"; ?>
<?php
$billinggroupbrokers_search->terminate();
?>