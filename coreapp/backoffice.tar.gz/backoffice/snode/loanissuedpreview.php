<?php
namespace PHPMaker2020\_4payadmin;

// Autoload
include_once "autoload.php";

// Session
if (session_status() !== PHP_SESSION_ACTIVE)
	\Delight\Cookie\Session::start(Config("COOKIE_SAMESITE")); // Init session data

// Output buffering
ob_start();
?>
<?php

// Write header
WriteHeader(FALSE, "utf-8");

// Create page object
$loanissued_preview = new loanissued_preview();

// Run the page
$loanissued_preview->run();

// Setup login status
SetupLoginStatus();
SetClientVar("login", LoginStatus());

// Global Page Rendering event (in userfn*.php)
Page_Rendering();

// Page Rendering event
$loanissued_preview->Page_Render();
?>
<?php $loanissued_preview->showPageHeader(); ?>
<?php if ($loanissued_preview->TotalRecords > 0) { ?>
<div class="card ew-grid loanissued"><!-- .card -->
<div class="<?php echo ResponsiveTableClass() ?>card-body ew-grid-middle-panel ew-preview-middle-panel"><!-- .table-responsive -->
<table class="table ew-table ew-preview-table"><!-- .table -->
	<thead><!-- Table header -->
		<tr class="ew-table-header">
<?php

// Render list options
$loanissued_preview->renderListOptions();

// Render list options (header, left)
$loanissued_preview->ListOptions->render("header", "left");
?>
<?php if ($loanissued_preview->loanid->Visible) { // loanid ?>
	<?php if ($loanissued->SortUrl($loanissued_preview->loanid) == "") { ?>
		<th class="<?php echo $loanissued_preview->loanid->headerCellClass() ?>"><?php echo $loanissued_preview->loanid->caption() ?></th>
	<?php } else { ?>
		<th class="<?php echo $loanissued_preview->loanid->headerCellClass() ?>"><div class="ew-pointer" data-sort="<?php echo HtmlEncode($loanissued_preview->loanid->Name) ?>" data-sort-order="<?php echo $loanissued_preview->SortField == $loanissued_preview->loanid->Name && $loanissued_preview->SortOrder == "ASC" ? "DESC" : "ASC" ?>">
			<div class="ew-table-header-btn"><span class="ew-table-header-caption"><?php echo $loanissued_preview->loanid->caption() ?></span><span class="ew-table-header-sort"><?php if ($loanissued_preview->SortField == $loanissued_preview->loanid->Name) { ?><?php if ($loanissued_preview->SortOrder == "ASC") { ?><i class="fas fa-sort-up"></i><?php } elseif ($loanissued_preview->SortOrder == "DESC") { ?><i class="fas fa-sort-down"></i><?php } ?><?php } ?></span>
		</div></div></th>
	<?php } ?>
<?php } ?>
<?php if ($loanissued_preview->_userid->Visible) { // userid ?>
	<?php if ($loanissued->SortUrl($loanissued_preview->_userid) == "") { ?>
		<th class="<?php echo $loanissued_preview->_userid->headerCellClass() ?>"><?php echo $loanissued_preview->_userid->caption() ?></th>
	<?php } else { ?>
		<th class="<?php echo $loanissued_preview->_userid->headerCellClass() ?>"><div class="ew-pointer" data-sort="<?php echo HtmlEncode($loanissued_preview->_userid->Name) ?>" data-sort-order="<?php echo $loanissued_preview->SortField == $loanissued_preview->_userid->Name && $loanissued_preview->SortOrder == "ASC" ? "DESC" : "ASC" ?>">
			<div class="ew-table-header-btn"><span class="ew-table-header-caption"><?php echo $loanissued_preview->_userid->caption() ?></span><span class="ew-table-header-sort"><?php if ($loanissued_preview->SortField == $loanissued_preview->_userid->Name) { ?><?php if ($loanissued_preview->SortOrder == "ASC") { ?><i class="fas fa-sort-up"></i><?php } elseif ($loanissued_preview->SortOrder == "DESC") { ?><i class="fas fa-sort-down"></i><?php } ?><?php } ?></span>
		</div></div></th>
	<?php } ?>
<?php } ?>
<?php if ($loanissued_preview->issueddate->Visible) { // issueddate ?>
	<?php if ($loanissued->SortUrl($loanissued_preview->issueddate) == "") { ?>
		<th class="<?php echo $loanissued_preview->issueddate->headerCellClass() ?>"><?php echo $loanissued_preview->issueddate->caption() ?></th>
	<?php } else { ?>
		<th class="<?php echo $loanissued_preview->issueddate->headerCellClass() ?>"><div class="ew-pointer" data-sort="<?php echo HtmlEncode($loanissued_preview->issueddate->Name) ?>" data-sort-order="<?php echo $loanissued_preview->SortField == $loanissued_preview->issueddate->Name && $loanissued_preview->SortOrder == "ASC" ? "DESC" : "ASC" ?>">
			<div class="ew-table-header-btn"><span class="ew-table-header-caption"><?php echo $loanissued_preview->issueddate->caption() ?></span><span class="ew-table-header-sort"><?php if ($loanissued_preview->SortField == $loanissued_preview->issueddate->Name) { ?><?php if ($loanissued_preview->SortOrder == "ASC") { ?><i class="fas fa-sort-up"></i><?php } elseif ($loanissued_preview->SortOrder == "DESC") { ?><i class="fas fa-sort-down"></i><?php } ?><?php } ?></span>
		</div></div></th>
	<?php } ?>
<?php } ?>
<?php if ($loanissued_preview->currcode->Visible) { // currcode ?>
	<?php if ($loanissued->SortUrl($loanissued_preview->currcode) == "") { ?>
		<th class="<?php echo $loanissued_preview->currcode->headerCellClass() ?>"><?php echo $loanissued_preview->currcode->caption() ?></th>
	<?php } else { ?>
		<th class="<?php echo $loanissued_preview->currcode->headerCellClass() ?>"><div class="ew-pointer" data-sort="<?php echo HtmlEncode($loanissued_preview->currcode->Name) ?>" data-sort-order="<?php echo $loanissued_preview->SortField == $loanissued_preview->currcode->Name && $loanissued_preview->SortOrder == "ASC" ? "DESC" : "ASC" ?>">
			<div class="ew-table-header-btn"><span class="ew-table-header-caption"><?php echo $loanissued_preview->currcode->caption() ?></span><span class="ew-table-header-sort"><?php if ($loanissued_preview->SortField == $loanissued_preview->currcode->Name) { ?><?php if ($loanissued_preview->SortOrder == "ASC") { ?><i class="fas fa-sort-up"></i><?php } elseif ($loanissued_preview->SortOrder == "DESC") { ?><i class="fas fa-sort-down"></i><?php } ?><?php } ?></span>
		</div></div></th>
	<?php } ?>
<?php } ?>
<?php if ($loanissued_preview->fullypaidind->Visible) { // fullypaidind ?>
	<?php if ($loanissued->SortUrl($loanissued_preview->fullypaidind) == "") { ?>
		<th class="<?php echo $loanissued_preview->fullypaidind->headerCellClass() ?>"><?php echo $loanissued_preview->fullypaidind->caption() ?></th>
	<?php } else { ?>
		<th class="<?php echo $loanissued_preview->fullypaidind->headerCellClass() ?>"><div class="ew-pointer" data-sort="<?php echo HtmlEncode($loanissued_preview->fullypaidind->Name) ?>" data-sort-order="<?php echo $loanissued_preview->SortField == $loanissued_preview->fullypaidind->Name && $loanissued_preview->SortOrder == "ASC" ? "DESC" : "ASC" ?>">
			<div class="ew-table-header-btn"><span class="ew-table-header-caption"><?php echo $loanissued_preview->fullypaidind->caption() ?></span><span class="ew-table-header-sort"><?php if ($loanissued_preview->SortField == $loanissued_preview->fullypaidind->Name) { ?><?php if ($loanissued_preview->SortOrder == "ASC") { ?><i class="fas fa-sort-up"></i><?php } elseif ($loanissued_preview->SortOrder == "DESC") { ?><i class="fas fa-sort-down"></i><?php } ?><?php } ?></span>
		</div></div></th>
	<?php } ?>
<?php } ?>
<?php if ($loanissued_preview->loanconfirmed->Visible) { // loanconfirmed ?>
	<?php if ($loanissued->SortUrl($loanissued_preview->loanconfirmed) == "") { ?>
		<th class="<?php echo $loanissued_preview->loanconfirmed->headerCellClass() ?>"><?php echo $loanissued_preview->loanconfirmed->caption() ?></th>
	<?php } else { ?>
		<th class="<?php echo $loanissued_preview->loanconfirmed->headerCellClass() ?>"><div class="ew-pointer" data-sort="<?php echo HtmlEncode($loanissued_preview->loanconfirmed->Name) ?>" data-sort-order="<?php echo $loanissued_preview->SortField == $loanissued_preview->loanconfirmed->Name && $loanissued_preview->SortOrder == "ASC" ? "DESC" : "ASC" ?>">
			<div class="ew-table-header-btn"><span class="ew-table-header-caption"><?php echo $loanissued_preview->loanconfirmed->caption() ?></span><span class="ew-table-header-sort"><?php if ($loanissued_preview->SortField == $loanissued_preview->loanconfirmed->Name) { ?><?php if ($loanissued_preview->SortOrder == "ASC") { ?><i class="fas fa-sort-up"></i><?php } elseif ($loanissued_preview->SortOrder == "DESC") { ?><i class="fas fa-sort-down"></i><?php } ?><?php } ?></span>
		</div></div></th>
	<?php } ?>
<?php } ?>
<?php if ($loanissued_preview->termtype->Visible) { // termtype ?>
	<?php if ($loanissued->SortUrl($loanissued_preview->termtype) == "") { ?>
		<th class="<?php echo $loanissued_preview->termtype->headerCellClass() ?>"><?php echo $loanissued_preview->termtype->caption() ?></th>
	<?php } else { ?>
		<th class="<?php echo $loanissued_preview->termtype->headerCellClass() ?>"><div class="ew-pointer" data-sort="<?php echo HtmlEncode($loanissued_preview->termtype->Name) ?>" data-sort-order="<?php echo $loanissued_preview->SortField == $loanissued_preview->termtype->Name && $loanissued_preview->SortOrder == "ASC" ? "DESC" : "ASC" ?>">
			<div class="ew-table-header-btn"><span class="ew-table-header-caption"><?php echo $loanissued_preview->termtype->caption() ?></span><span class="ew-table-header-sort"><?php if ($loanissued_preview->SortField == $loanissued_preview->termtype->Name) { ?><?php if ($loanissued_preview->SortOrder == "ASC") { ?><i class="fas fa-sort-up"></i><?php } elseif ($loanissued_preview->SortOrder == "DESC") { ?><i class="fas fa-sort-down"></i><?php } ?><?php } ?></span>
		</div></div></th>
	<?php } ?>
<?php } ?>
<?php

// Render list options (header, right)
$loanissued_preview->ListOptions->render("header", "right");
?>
		</tr>
	</thead>
	<tbody><!-- Table body -->
<?php
$loanissued_preview->RecCount = 0;
$loanissued_preview->RowCount = 0;
while ($loanissued_preview->Recordset && !$loanissued_preview->Recordset->EOF) {

	// Init row class and style
	$loanissued_preview->RecCount++;
	$loanissued_preview->RowCount++;
	$loanissued_preview->CssStyle = "";
	$loanissued_preview->loadListRowValues($loanissued_preview->Recordset);

	// Render row
	$loanissued->RowType = ROWTYPE_PREVIEW; // Preview record
	$loanissued_preview->resetAttributes();
	$loanissued_preview->renderListRow();

	// Render list options
	$loanissued_preview->renderListOptions();
?>
	<tr <?php echo $loanissued->rowAttributes() ?>>
<?php

// Render list options (body, left)
$loanissued_preview->ListOptions->render("body", "left", $loanissued_preview->RowCount);
?>
<?php if ($loanissued_preview->loanid->Visible) { // loanid ?>
		<!-- loanid -->
		<td<?php echo $loanissued_preview->loanid->cellAttributes() ?>>
<span<?php echo $loanissued_preview->loanid->viewAttributes() ?>><?php echo $loanissued_preview->loanid->getViewValue() ?></span>
</td>
<?php } ?>
<?php if ($loanissued_preview->_userid->Visible) { // userid ?>
		<!-- userid -->
		<td<?php echo $loanissued_preview->_userid->cellAttributes() ?>>
<span<?php echo $loanissued_preview->_userid->viewAttributes() ?>><?php if (!EmptyString($loanissued_preview->_userid->getViewValue()) && $loanissued_preview->_userid->linkAttributes() != "") { ?>
<a<?php echo $loanissued_preview->_userid->linkAttributes() ?>><?php echo $loanissued_preview->_userid->getViewValue() ?></a>
<?php } else { ?>
<?php echo $loanissued_preview->_userid->getViewValue() ?>
<?php } ?></span>
</td>
<?php } ?>
<?php if ($loanissued_preview->issueddate->Visible) { // issueddate ?>
		<!-- issueddate -->
		<td<?php echo $loanissued_preview->issueddate->cellAttributes() ?>>
<span<?php echo $loanissued_preview->issueddate->viewAttributes() ?>><?php echo $loanissued_preview->issueddate->getViewValue() ?></span>
</td>
<?php } ?>
<?php if ($loanissued_preview->currcode->Visible) { // currcode ?>
		<!-- currcode -->
		<td<?php echo $loanissued_preview->currcode->cellAttributes() ?>>
<span<?php echo $loanissued_preview->currcode->viewAttributes() ?>><?php echo $loanissued_preview->currcode->getViewValue() ?></span>
</td>
<?php } ?>
<?php if ($loanissued_preview->fullypaidind->Visible) { // fullypaidind ?>
		<!-- fullypaidind -->
		<td<?php echo $loanissued_preview->fullypaidind->cellAttributes() ?>>
<span<?php echo $loanissued_preview->fullypaidind->viewAttributes() ?>><?php echo $loanissued_preview->fullypaidind->getViewValue() ?></span>
</td>
<?php } ?>
<?php if ($loanissued_preview->loanconfirmed->Visible) { // loanconfirmed ?>
		<!-- loanconfirmed -->
		<td<?php echo $loanissued_preview->loanconfirmed->cellAttributes() ?>>
<span<?php echo $loanissued_preview->loanconfirmed->viewAttributes() ?>><?php echo $loanissued_preview->loanconfirmed->getViewValue() ?></span>
</td>
<?php } ?>
<?php if ($loanissued_preview->termtype->Visible) { // termtype ?>
		<!-- termtype -->
		<td<?php echo $loanissued_preview->termtype->cellAttributes() ?>>
<span<?php echo $loanissued_preview->termtype->viewAttributes() ?>><?php echo $loanissued_preview->termtype->getViewValue() ?></span>
</td>
<?php } ?>
<?php

// Render list options (body, right)
$loanissued_preview->ListOptions->render("body", "right", $loanissued_preview->RowCount);
?>
	</tr>
<?php
	$loanissued_preview->Recordset->MoveNext();
} // while
?>
	</tbody>
</table><!-- /.table -->
</div><!-- /.table-responsive -->
<div class="card-footer ew-grid-lower-panel ew-preview-lower-panel"><!-- .card-footer -->
<?php echo $loanissued_preview->Pager->render() ?>
<?php } else { // No record ?>
<div class="card no-border">
<div class="ew-detail-count"><?php echo $Language->phrase("NoRecord") ?></div>
<?php } ?>
<div class="ew-preview-other-options">
<?php
	foreach ($loanissued_preview->OtherOptions as $option)
		$option->render("body");
?>
</div>
<?php if ($loanissued_preview->TotalRecords > 0) { ?>
<div class="clearfix"></div>
</div><!-- /.card-footer -->
<?php } ?>
</div><!-- /.card -->
<?php
$loanissued_preview->showPageFooter();
if (Config("DEBUG"))
	echo GetDebugMessage();
?>
<?php
if ($loanissued_preview->Recordset)
	$loanissued_preview->Recordset->Close();

// Output
$content = ob_get_contents();
ob_end_clean();
echo ConvertToUtf8($content);
?>
<?php
$loanissued_preview->terminate();
?>