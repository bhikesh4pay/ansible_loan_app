<?php
namespace PHPMaker2020\_4payadmin;

// Autoload
include_once "autoload.php";

// Session
if (session_status() !== PHP_SESSION_ACTIVE)
	\Delight\Cookie\Session::start(Config("COOKIE_SAMESITE")); // Init session data

// Output buffering
ob_start();
?>
<?php

// Write header
WriteHeader(FALSE, "utf-8");

// Create page object
$userchildren_preview = new userchildren_preview();

// Run the page
$userchildren_preview->run();

// Setup login status
SetupLoginStatus();
SetClientVar("login", LoginStatus());

// Global Page Rendering event (in userfn*.php)
Page_Rendering();

// Page Rendering event
$userchildren_preview->Page_Render();
?>
<?php $userchildren_preview->showPageHeader(); ?>
<?php if ($userchildren_preview->TotalRecords > 0) { ?>
<div class="card ew-grid userchildren"><!-- .card -->
<div class="<?php echo ResponsiveTableClass() ?>card-body ew-grid-middle-panel ew-preview-middle-panel"><!-- .table-responsive -->
<table class="table ew-table ew-preview-table"><!-- .table -->
	<thead><!-- Table header -->
		<tr class="ew-table-header">
<?php

// Render list options
$userchildren_preview->renderListOptions();

// Render list options (header, left)
$userchildren_preview->ListOptions->render("header", "left");
?>
<?php if ($userchildren_preview->parentUserID->Visible) { // parentUserID ?>
	<?php if ($userchildren->SortUrl($userchildren_preview->parentUserID) == "") { ?>
		<th class="<?php echo $userchildren_preview->parentUserID->headerCellClass() ?>"><?php echo $userchildren_preview->parentUserID->caption() ?></th>
	<?php } else { ?>
		<th class="<?php echo $userchildren_preview->parentUserID->headerCellClass() ?>"><div class="ew-pointer" data-sort="<?php echo HtmlEncode($userchildren_preview->parentUserID->Name) ?>" data-sort-order="<?php echo $userchildren_preview->SortField == $userchildren_preview->parentUserID->Name && $userchildren_preview->SortOrder == "ASC" ? "DESC" : "ASC" ?>">
			<div class="ew-table-header-btn"><span class="ew-table-header-caption"><?php echo $userchildren_preview->parentUserID->caption() ?></span><span class="ew-table-header-sort"><?php if ($userchildren_preview->SortField == $userchildren_preview->parentUserID->Name) { ?><?php if ($userchildren_preview->SortOrder == "ASC") { ?><i class="fas fa-sort-up"></i><?php } elseif ($userchildren_preview->SortOrder == "DESC") { ?><i class="fas fa-sort-down"></i><?php } ?><?php } ?></span>
		</div></div></th>
	<?php } ?>
<?php } ?>
<?php if ($userchildren_preview->childUserID->Visible) { // childUserID ?>
	<?php if ($userchildren->SortUrl($userchildren_preview->childUserID) == "") { ?>
		<th class="<?php echo $userchildren_preview->childUserID->headerCellClass() ?>"><?php echo $userchildren_preview->childUserID->caption() ?></th>
	<?php } else { ?>
		<th class="<?php echo $userchildren_preview->childUserID->headerCellClass() ?>"><div class="ew-pointer" data-sort="<?php echo HtmlEncode($userchildren_preview->childUserID->Name) ?>" data-sort-order="<?php echo $userchildren_preview->SortField == $userchildren_preview->childUserID->Name && $userchildren_preview->SortOrder == "ASC" ? "DESC" : "ASC" ?>">
			<div class="ew-table-header-btn"><span class="ew-table-header-caption"><?php echo $userchildren_preview->childUserID->caption() ?></span><span class="ew-table-header-sort"><?php if ($userchildren_preview->SortField == $userchildren_preview->childUserID->Name) { ?><?php if ($userchildren_preview->SortOrder == "ASC") { ?><i class="fas fa-sort-up"></i><?php } elseif ($userchildren_preview->SortOrder == "DESC") { ?><i class="fas fa-sort-down"></i><?php } ?><?php } ?></span>
		</div></div></th>
	<?php } ?>
<?php } ?>
<?php if ($userchildren_preview->associationTime->Visible) { // associationTime ?>
	<?php if ($userchildren->SortUrl($userchildren_preview->associationTime) == "") { ?>
		<th class="<?php echo $userchildren_preview->associationTime->headerCellClass() ?>"><?php echo $userchildren_preview->associationTime->caption() ?></th>
	<?php } else { ?>
		<th class="<?php echo $userchildren_preview->associationTime->headerCellClass() ?>"><div class="ew-pointer" data-sort="<?php echo HtmlEncode($userchildren_preview->associationTime->Name) ?>" data-sort-order="<?php echo $userchildren_preview->SortField == $userchildren_preview->associationTime->Name && $userchildren_preview->SortOrder == "ASC" ? "DESC" : "ASC" ?>">
			<div class="ew-table-header-btn"><span class="ew-table-header-caption"><?php echo $userchildren_preview->associationTime->caption() ?></span><span class="ew-table-header-sort"><?php if ($userchildren_preview->SortField == $userchildren_preview->associationTime->Name) { ?><?php if ($userchildren_preview->SortOrder == "ASC") { ?><i class="fas fa-sort-up"></i><?php } elseif ($userchildren_preview->SortOrder == "DESC") { ?><i class="fas fa-sort-down"></i><?php } ?><?php } ?></span>
		</div></div></th>
	<?php } ?>
<?php } ?>
<?php

// Render list options (header, right)
$userchildren_preview->ListOptions->render("header", "right");
?>
		</tr>
	</thead>
	<tbody><!-- Table body -->
<?php
$userchildren_preview->RecCount = 0;
$userchildren_preview->RowCount = 0;
while ($userchildren_preview->Recordset && !$userchildren_preview->Recordset->EOF) {

	// Init row class and style
	$userchildren_preview->RecCount++;
	$userchildren_preview->RowCount++;
	$userchildren_preview->CssStyle = "";
	$userchildren_preview->loadListRowValues($userchildren_preview->Recordset);

	// Render row
	$userchildren->RowType = ROWTYPE_PREVIEW; // Preview record
	$userchildren_preview->resetAttributes();
	$userchildren_preview->renderListRow();

	// Render list options
	$userchildren_preview->renderListOptions();
?>
	<tr <?php echo $userchildren->rowAttributes() ?>>
<?php

// Render list options (body, left)
$userchildren_preview->ListOptions->render("body", "left", $userchildren_preview->RowCount);
?>
<?php if ($userchildren_preview->parentUserID->Visible) { // parentUserID ?>
		<!-- parentUserID -->
		<td<?php echo $userchildren_preview->parentUserID->cellAttributes() ?>>
<span<?php echo $userchildren_preview->parentUserID->viewAttributes() ?>><?php echo $userchildren_preview->parentUserID->getViewValue() ?></span>
</td>
<?php } ?>
<?php if ($userchildren_preview->childUserID->Visible) { // childUserID ?>
		<!-- childUserID -->
		<td<?php echo $userchildren_preview->childUserID->cellAttributes() ?>>
<span<?php echo $userchildren_preview->childUserID->viewAttributes() ?>><?php echo $userchildren_preview->childUserID->getViewValue() ?></span>
</td>
<?php } ?>
<?php if ($userchildren_preview->associationTime->Visible) { // associationTime ?>
		<!-- associationTime -->
		<td<?php echo $userchildren_preview->associationTime->cellAttributes() ?>>
<span<?php echo $userchildren_preview->associationTime->viewAttributes() ?>><?php echo $userchildren_preview->associationTime->getViewValue() ?></span>
</td>
<?php } ?>
<?php

// Render list options (body, right)
$userchildren_preview->ListOptions->render("body", "right", $userchildren_preview->RowCount);
?>
	</tr>
<?php
	$userchildren_preview->Recordset->MoveNext();
} // while
?>
	</tbody>
</table><!-- /.table -->
</div><!-- /.table-responsive -->
<div class="card-footer ew-grid-lower-panel ew-preview-lower-panel"><!-- .card-footer -->
<?php echo $userchildren_preview->Pager->render() ?>
<?php } else { // No record ?>
<div class="card no-border">
<div class="ew-detail-count"><?php echo $Language->phrase("NoRecord") ?></div>
<?php } ?>
<div class="ew-preview-other-options">
<?php
	foreach ($userchildren_preview->OtherOptions as $option)
		$option->render("body");
?>
</div>
<?php if ($userchildren_preview->TotalRecords > 0) { ?>
<div class="clearfix"></div>
</div><!-- /.card-footer -->
<?php } ?>
</div><!-- /.card -->
<?php
$userchildren_preview->showPageFooter();
if (Config("DEBUG"))
	echo GetDebugMessage();
?>
<?php
if ($userchildren_preview->Recordset)
	$userchildren_preview->Recordset->Close();

// Output
$content = ob_get_contents();
ob_end_clean();
echo ConvertToUtf8($content);
?>
<?php
$userchildren_preview->terminate();
?>