<?php
namespace PHPMaker2020\_4payadmin;

// Write header
WriteHeader(FALSE);

// Create page object
if (!isset($mailbox_grid))
	$mailbox_grid = new mailbox_grid();

// Run the page
$mailbox_grid->run();

// Setup login status
SetupLoginStatus();
SetClientVar("login", LoginStatus());

// Global Page Rendering event (in userfn*.php)
Page_Rendering();

// Page Rendering event
$mailbox_grid->Page_Render();
?>
<?php if (!$mailbox_grid->isExport()) { ?>
<script>
var fmailboxgrid, currentPageID;
loadjs.ready("head", function() {

	// Form object
	fmailboxgrid = new ew.Form("fmailboxgrid", "grid");
	fmailboxgrid.formKeyCountName = '<?php echo $mailbox_grid->FormKeyCountName ?>';

	// Validate form
	fmailboxgrid.validate = function() {
		if (!this.validateRequired)
			return true; // Ignore validation
		var $ = jQuery, fobj = this.getForm(), $fobj = $(fobj);
		if ($fobj.find("#confirm").val() == "confirm")
			return true;
		var elm, felm, uelm, addcnt = 0;
		var $k = $fobj.find("#" + this.formKeyCountName); // Get key_count
		var rowcnt = ($k[0]) ? parseInt($k.val(), 10) : 1;
		var startcnt = (rowcnt == 0) ? 0 : 1; // Check rowcnt == 0 => Inline-Add
		var gridinsert = ["insert", "gridinsert"].includes($fobj.find("#action").val()) && $k[0];
		for (var i = startcnt; i <= rowcnt; i++) {
			var infix = ($k[0]) ? String(i) : "";
			$fobj.data("rowindex", infix);
			var checkrow = (gridinsert) ? !this.emptyRow(infix) : true;
			if (checkrow) {
				addcnt++;
			<?php if ($mailbox_grid->msgid->Required) { ?>
				elm = this.getElements("x" + infix + "_msgid");
				if (elm && !ew.isHidden(elm) && !ew.hasValue(elm))
					return this.onError(elm, "<?php echo JsEncode(str_replace("%s", $mailbox_grid->msgid->caption(), $mailbox_grid->msgid->RequiredErrorMessage)) ?>");
			<?php } ?>
			<?php if ($mailbox_grid->_userid->Required) { ?>
				elm = this.getElements("x" + infix + "__userid");
				if (elm && !ew.isHidden(elm) && !ew.hasValue(elm))
					return this.onError(elm, "<?php echo JsEncode(str_replace("%s", $mailbox_grid->_userid->caption(), $mailbox_grid->_userid->RequiredErrorMessage)) ?>");
			<?php } ?>
				elm = this.getElements("x" + infix + "__userid");
				if (elm && !ew.checkInteger(elm.value))
					return this.onError(elm, "<?php echo JsEncode($mailbox_grid->_userid->errorMessage()) ?>");
			<?php if ($mailbox_grid->msgtype->Required) { ?>
				elm = this.getElements("x" + infix + "_msgtype");
				if (elm && !ew.isHidden(elm) && !ew.hasValue(elm))
					return this.onError(elm, "<?php echo JsEncode(str_replace("%s", $mailbox_grid->msgtype->caption(), $mailbox_grid->msgtype->RequiredErrorMessage)) ?>");
			<?php } ?>
			<?php if ($mailbox_grid->msgcontent->Required) { ?>
				elm = this.getElements("x" + infix + "_msgcontent");
				if (elm && !ew.isHidden(elm) && !ew.hasValue(elm))
					return this.onError(elm, "<?php echo JsEncode(str_replace("%s", $mailbox_grid->msgcontent->caption(), $mailbox_grid->msgcontent->RequiredErrorMessage)) ?>");
			<?php } ?>
			<?php if ($mailbox_grid->msgread->Required) { ?>
				elm = this.getElements("x" + infix + "_msgread");
				if (elm && !ew.isHidden(elm) && !ew.hasValue(elm))
					return this.onError(elm, "<?php echo JsEncode(str_replace("%s", $mailbox_grid->msgread->caption(), $mailbox_grid->msgread->RequiredErrorMessage)) ?>");
			<?php } ?>
			<?php if ($mailbox_grid->msgtime->Required) { ?>
				elm = this.getElements("x" + infix + "_msgtime");
				if (elm && !ew.isHidden(elm) && !ew.hasValue(elm))
					return this.onError(elm, "<?php echo JsEncode(str_replace("%s", $mailbox_grid->msgtime->caption(), $mailbox_grid->msgtime->RequiredErrorMessage)) ?>");
			<?php } ?>
				elm = this.getElements("x" + infix + "_msgtime");
				if (elm && !ew.checkDateDef(elm.value))
					return this.onError(elm, "<?php echo JsEncode($mailbox_grid->msgtime->errorMessage()) ?>");
			<?php if ($mailbox_grid->datavalue->Required) { ?>
				elm = this.getElements("x" + infix + "_datavalue");
				if (elm && !ew.isHidden(elm) && !ew.hasValue(elm))
					return this.onError(elm, "<?php echo JsEncode(str_replace("%s", $mailbox_grid->datavalue->caption(), $mailbox_grid->datavalue->RequiredErrorMessage)) ?>");
			<?php } ?>
			<?php if ($mailbox_grid->version->Required) { ?>
				elm = this.getElements("x" + infix + "_version");
				if (elm && !ew.isHidden(elm) && !ew.hasValue(elm))
					return this.onError(elm, "<?php echo JsEncode(str_replace("%s", $mailbox_grid->version->caption(), $mailbox_grid->version->RequiredErrorMessage)) ?>");
			<?php } ?>
				elm = this.getElements("x" + infix + "_version");
				if (elm && !ew.checkInteger(elm.value))
					return this.onError(elm, "<?php echo JsEncode($mailbox_grid->version->errorMessage()) ?>");
			<?php if ($mailbox_grid->delimeter->Required) { ?>
				elm = this.getElements("x" + infix + "_delimeter");
				if (elm && !ew.isHidden(elm) && !ew.hasValue(elm))
					return this.onError(elm, "<?php echo JsEncode(str_replace("%s", $mailbox_grid->delimeter->caption(), $mailbox_grid->delimeter->RequiredErrorMessage)) ?>");
			<?php } ?>

				// Call Form_CustomValidate event
				if (!this.Form_CustomValidate(fobj))
					return false;
			} // End Grid Add checking
		}
		return true;
	}

	// Check empty row
	fmailboxgrid.emptyRow = function(infix) {
		var fobj = this._form;
		if (ew.valueChanged(fobj, infix, "_userid", false)) return false;
		if (ew.valueChanged(fobj, infix, "msgtype", false)) return false;
		if (ew.valueChanged(fobj, infix, "msgcontent", false)) return false;
		if (ew.valueChanged(fobj, infix, "msgread", false)) return false;
		if (ew.valueChanged(fobj, infix, "msgtime", false)) return false;
		if (ew.valueChanged(fobj, infix, "datavalue", false)) return false;
		if (ew.valueChanged(fobj, infix, "version", false)) return false;
		if (ew.valueChanged(fobj, infix, "delimeter", false)) return false;
		return true;
	}

	// Form_CustomValidate
	fmailboxgrid.Form_CustomValidate = function(fobj) { // DO NOT CHANGE THIS LINE!

		// Your custom validation code here, return false if invalid.
		return true;
	}

	// Use JavaScript validation or not
	fmailboxgrid.validateRequired = <?php echo Config("CLIENT_VALIDATE") ? "true" : "false" ?>;

	// Dynamic selection lists
	fmailboxgrid.lists["x_msgtype"] = <?php echo $mailbox_grid->msgtype->Lookup->toClientList($mailbox_grid) ?>;
	fmailboxgrid.lists["x_msgtype"].options = <?php echo JsonEncode($mailbox_grid->msgtype->lookupOptions()) ?>;
	fmailboxgrid.lists["x_msgread"] = <?php echo $mailbox_grid->msgread->Lookup->toClientList($mailbox_grid) ?>;
	fmailboxgrid.lists["x_msgread"].options = <?php echo JsonEncode($mailbox_grid->msgread->lookupOptions()) ?>;
	loadjs.done("fmailboxgrid");
});
</script>
<?php } ?>
<?php
$mailbox_grid->renderOtherOptions();
?>
<?php if ($mailbox_grid->TotalRecords > 0 || $mailbox->CurrentAction) { ?>
<div class="card ew-card ew-grid<?php if ($mailbox_grid->isAddOrEdit()) { ?> ew-grid-add-edit<?php } ?> mailbox">
<div id="fmailboxgrid" class="ew-form ew-list-form form-inline">
<div id="gmp_mailbox" class="<?php echo ResponsiveTableClass() ?>card-body ew-grid-middle-panel">
<table id="tbl_mailboxgrid" class="table ew-table"><!-- .ew-table -->
<thead>
	<tr class="ew-table-header">
<?php

// Header row
$mailbox->RowType = ROWTYPE_HEADER;

// Render list options
$mailbox_grid->renderListOptions();

// Render list options (header, left)
$mailbox_grid->ListOptions->render("header", "left");
?>
<?php if ($mailbox_grid->msgid->Visible) { // msgid ?>
	<?php if ($mailbox_grid->SortUrl($mailbox_grid->msgid) == "") { ?>
		<th data-name="msgid" class="<?php echo $mailbox_grid->msgid->headerCellClass() ?>"><div id="elh_mailbox_msgid" class="mailbox_msgid"><div class="ew-table-header-caption"><?php echo $mailbox_grid->msgid->caption() ?></div></div></th>
	<?php } else { ?>
		<th data-name="msgid" class="<?php echo $mailbox_grid->msgid->headerCellClass() ?>"><div><div id="elh_mailbox_msgid" class="mailbox_msgid">
			<div class="ew-table-header-btn"><span class="ew-table-header-caption"><?php echo $mailbox_grid->msgid->caption() ?></span><span class="ew-table-header-sort"><?php if ($mailbox_grid->msgid->getSort() == "ASC") { ?><i class="fas fa-sort-up"></i><?php } elseif ($mailbox_grid->msgid->getSort() == "DESC") { ?><i class="fas fa-sort-down"></i><?php } ?></span></div>
		</div></div></th>
	<?php } ?>
<?php } ?>
<?php if ($mailbox_grid->_userid->Visible) { // userid ?>
	<?php if ($mailbox_grid->SortUrl($mailbox_grid->_userid) == "") { ?>
		<th data-name="_userid" class="<?php echo $mailbox_grid->_userid->headerCellClass() ?>"><div id="elh_mailbox__userid" class="mailbox__userid"><div class="ew-table-header-caption"><?php echo $mailbox_grid->_userid->caption() ?></div></div></th>
	<?php } else { ?>
		<th data-name="_userid" class="<?php echo $mailbox_grid->_userid->headerCellClass() ?>"><div><div id="elh_mailbox__userid" class="mailbox__userid">
			<div class="ew-table-header-btn"><span class="ew-table-header-caption"><?php echo $mailbox_grid->_userid->caption() ?></span><span class="ew-table-header-sort"><?php if ($mailbox_grid->_userid->getSort() == "ASC") { ?><i class="fas fa-sort-up"></i><?php } elseif ($mailbox_grid->_userid->getSort() == "DESC") { ?><i class="fas fa-sort-down"></i><?php } ?></span></div>
		</div></div></th>
	<?php } ?>
<?php } ?>
<?php if ($mailbox_grid->msgtype->Visible) { // msgtype ?>
	<?php if ($mailbox_grid->SortUrl($mailbox_grid->msgtype) == "") { ?>
		<th data-name="msgtype" class="<?php echo $mailbox_grid->msgtype->headerCellClass() ?>"><div id="elh_mailbox_msgtype" class="mailbox_msgtype"><div class="ew-table-header-caption"><?php echo $mailbox_grid->msgtype->caption() ?></div></div></th>
	<?php } else { ?>
		<th data-name="msgtype" class="<?php echo $mailbox_grid->msgtype->headerCellClass() ?>"><div><div id="elh_mailbox_msgtype" class="mailbox_msgtype">
			<div class="ew-table-header-btn"><span class="ew-table-header-caption"><?php echo $mailbox_grid->msgtype->caption() ?></span><span class="ew-table-header-sort"><?php if ($mailbox_grid->msgtype->getSort() == "ASC") { ?><i class="fas fa-sort-up"></i><?php } elseif ($mailbox_grid->msgtype->getSort() == "DESC") { ?><i class="fas fa-sort-down"></i><?php } ?></span></div>
		</div></div></th>
	<?php } ?>
<?php } ?>
<?php if ($mailbox_grid->msgcontent->Visible) { // msgcontent ?>
	<?php if ($mailbox_grid->SortUrl($mailbox_grid->msgcontent) == "") { ?>
		<th data-name="msgcontent" class="<?php echo $mailbox_grid->msgcontent->headerCellClass() ?>"><div id="elh_mailbox_msgcontent" class="mailbox_msgcontent"><div class="ew-table-header-caption"><?php echo $mailbox_grid->msgcontent->caption() ?></div></div></th>
	<?php } else { ?>
		<th data-name="msgcontent" class="<?php echo $mailbox_grid->msgcontent->headerCellClass() ?>"><div><div id="elh_mailbox_msgcontent" class="mailbox_msgcontent">
			<div class="ew-table-header-btn"><span class="ew-table-header-caption"><?php echo $mailbox_grid->msgcontent->caption() ?></span><span class="ew-table-header-sort"><?php if ($mailbox_grid->msgcontent->getSort() == "ASC") { ?><i class="fas fa-sort-up"></i><?php } elseif ($mailbox_grid->msgcontent->getSort() == "DESC") { ?><i class="fas fa-sort-down"></i><?php } ?></span></div>
		</div></div></th>
	<?php } ?>
<?php } ?>
<?php if ($mailbox_grid->msgread->Visible) { // msgread ?>
	<?php if ($mailbox_grid->SortUrl($mailbox_grid->msgread) == "") { ?>
		<th data-name="msgread" class="<?php echo $mailbox_grid->msgread->headerCellClass() ?>"><div id="elh_mailbox_msgread" class="mailbox_msgread"><div class="ew-table-header-caption"><?php echo $mailbox_grid->msgread->caption() ?></div></div></th>
	<?php } else { ?>
		<th data-name="msgread" class="<?php echo $mailbox_grid->msgread->headerCellClass() ?>"><div><div id="elh_mailbox_msgread" class="mailbox_msgread">
			<div class="ew-table-header-btn"><span class="ew-table-header-caption"><?php echo $mailbox_grid->msgread->caption() ?></span><span class="ew-table-header-sort"><?php if ($mailbox_grid->msgread->getSort() == "ASC") { ?><i class="fas fa-sort-up"></i><?php } elseif ($mailbox_grid->msgread->getSort() == "DESC") { ?><i class="fas fa-sort-down"></i><?php } ?></span></div>
		</div></div></th>
	<?php } ?>
<?php } ?>
<?php if ($mailbox_grid->msgtime->Visible) { // msgtime ?>
	<?php if ($mailbox_grid->SortUrl($mailbox_grid->msgtime) == "") { ?>
		<th data-name="msgtime" class="<?php echo $mailbox_grid->msgtime->headerCellClass() ?>"><div id="elh_mailbox_msgtime" class="mailbox_msgtime"><div class="ew-table-header-caption"><?php echo $mailbox_grid->msgtime->caption() ?></div></div></th>
	<?php } else { ?>
		<th data-name="msgtime" class="<?php echo $mailbox_grid->msgtime->headerCellClass() ?>"><div><div id="elh_mailbox_msgtime" class="mailbox_msgtime">
			<div class="ew-table-header-btn"><span class="ew-table-header-caption"><?php echo $mailbox_grid->msgtime->caption() ?></span><span class="ew-table-header-sort"><?php if ($mailbox_grid->msgtime->getSort() == "ASC") { ?><i class="fas fa-sort-up"></i><?php } elseif ($mailbox_grid->msgtime->getSort() == "DESC") { ?><i class="fas fa-sort-down"></i><?php } ?></span></div>
		</div></div></th>
	<?php } ?>
<?php } ?>
<?php if ($mailbox_grid->datavalue->Visible) { // datavalue ?>
	<?php if ($mailbox_grid->SortUrl($mailbox_grid->datavalue) == "") { ?>
		<th data-name="datavalue" class="<?php echo $mailbox_grid->datavalue->headerCellClass() ?>"><div id="elh_mailbox_datavalue" class="mailbox_datavalue"><div class="ew-table-header-caption"><?php echo $mailbox_grid->datavalue->caption() ?></div></div></th>
	<?php } else { ?>
		<th data-name="datavalue" class="<?php echo $mailbox_grid->datavalue->headerCellClass() ?>"><div><div id="elh_mailbox_datavalue" class="mailbox_datavalue">
			<div class="ew-table-header-btn"><span class="ew-table-header-caption"><?php echo $mailbox_grid->datavalue->caption() ?></span><span class="ew-table-header-sort"><?php if ($mailbox_grid->datavalue->getSort() == "ASC") { ?><i class="fas fa-sort-up"></i><?php } elseif ($mailbox_grid->datavalue->getSort() == "DESC") { ?><i class="fas fa-sort-down"></i><?php } ?></span></div>
		</div></div></th>
	<?php } ?>
<?php } ?>
<?php if ($mailbox_grid->version->Visible) { // version ?>
	<?php if ($mailbox_grid->SortUrl($mailbox_grid->version) == "") { ?>
		<th data-name="version" class="<?php echo $mailbox_grid->version->headerCellClass() ?>"><div id="elh_mailbox_version" class="mailbox_version"><div class="ew-table-header-caption"><?php echo $mailbox_grid->version->caption() ?></div></div></th>
	<?php } else { ?>
		<th data-name="version" class="<?php echo $mailbox_grid->version->headerCellClass() ?>"><div><div id="elh_mailbox_version" class="mailbox_version">
			<div class="ew-table-header-btn"><span class="ew-table-header-caption"><?php echo $mailbox_grid->version->caption() ?></span><span class="ew-table-header-sort"><?php if ($mailbox_grid->version->getSort() == "ASC") { ?><i class="fas fa-sort-up"></i><?php } elseif ($mailbox_grid->version->getSort() == "DESC") { ?><i class="fas fa-sort-down"></i><?php } ?></span></div>
		</div></div></th>
	<?php } ?>
<?php } ?>
<?php if ($mailbox_grid->delimeter->Visible) { // delimeter ?>
	<?php if ($mailbox_grid->SortUrl($mailbox_grid->delimeter) == "") { ?>
		<th data-name="delimeter" class="<?php echo $mailbox_grid->delimeter->headerCellClass() ?>"><div id="elh_mailbox_delimeter" class="mailbox_delimeter"><div class="ew-table-header-caption"><?php echo $mailbox_grid->delimeter->caption() ?></div></div></th>
	<?php } else { ?>
		<th data-name="delimeter" class="<?php echo $mailbox_grid->delimeter->headerCellClass() ?>"><div><div id="elh_mailbox_delimeter" class="mailbox_delimeter">
			<div class="ew-table-header-btn"><span class="ew-table-header-caption"><?php echo $mailbox_grid->delimeter->caption() ?></span><span class="ew-table-header-sort"><?php if ($mailbox_grid->delimeter->getSort() == "ASC") { ?><i class="fas fa-sort-up"></i><?php } elseif ($mailbox_grid->delimeter->getSort() == "DESC") { ?><i class="fas fa-sort-down"></i><?php } ?></span></div>
		</div></div></th>
	<?php } ?>
<?php } ?>
<?php

// Render list options (header, right)
$mailbox_grid->ListOptions->render("header", "right");
?>
	</tr>
</thead>
<tbody>
<?php
$mailbox_grid->StartRecord = 1;
$mailbox_grid->StopRecord = $mailbox_grid->TotalRecords; // Show all records

// Restore number of post back records
if ($CurrentForm && ($mailbox->isConfirm() || $mailbox_grid->EventCancelled)) {
	$CurrentForm->Index = -1;
	if ($CurrentForm->hasValue($mailbox_grid->FormKeyCountName) && ($mailbox_grid->isGridAdd() || $mailbox_grid->isGridEdit() || $mailbox->isConfirm())) {
		$mailbox_grid->KeyCount = $CurrentForm->getValue($mailbox_grid->FormKeyCountName);
		$mailbox_grid->StopRecord = $mailbox_grid->StartRecord + $mailbox_grid->KeyCount - 1;
	}
}
$mailbox_grid->RecordCount = $mailbox_grid->StartRecord - 1;
if ($mailbox_grid->Recordset && !$mailbox_grid->Recordset->EOF) {
	$mailbox_grid->Recordset->moveFirst();
	$selectLimit = $mailbox_grid->UseSelectLimit;
	if (!$selectLimit && $mailbox_grid->StartRecord > 1)
		$mailbox_grid->Recordset->move($mailbox_grid->StartRecord - 1);
} elseif (!$mailbox->AllowAddDeleteRow && $mailbox_grid->StopRecord == 0) {
	$mailbox_grid->StopRecord = $mailbox->GridAddRowCount;
}

// Initialize aggregate
$mailbox->RowType = ROWTYPE_AGGREGATEINIT;
$mailbox->resetAttributes();
$mailbox_grid->renderRow();
if ($mailbox_grid->isGridAdd())
	$mailbox_grid->RowIndex = 0;
if ($mailbox_grid->isGridEdit())
	$mailbox_grid->RowIndex = 0;
while ($mailbox_grid->RecordCount < $mailbox_grid->StopRecord) {
	$mailbox_grid->RecordCount++;
	if ($mailbox_grid->RecordCount >= $mailbox_grid->StartRecord) {
		$mailbox_grid->RowCount++;
		if ($mailbox_grid->isGridAdd() || $mailbox_grid->isGridEdit() || $mailbox->isConfirm()) {
			$mailbox_grid->RowIndex++;
			$CurrentForm->Index = $mailbox_grid->RowIndex;
			if ($CurrentForm->hasValue($mailbox_grid->FormActionName) && ($mailbox->isConfirm() || $mailbox_grid->EventCancelled))
				$mailbox_grid->RowAction = strval($CurrentForm->getValue($mailbox_grid->FormActionName));
			elseif ($mailbox_grid->isGridAdd())
				$mailbox_grid->RowAction = "insert";
			else
				$mailbox_grid->RowAction = "";
		}

		// Set up key count
		$mailbox_grid->KeyCount = $mailbox_grid->RowIndex;

		// Init row class and style
		$mailbox->resetAttributes();
		$mailbox->CssClass = "";
		if ($mailbox_grid->isGridAdd()) {
			if ($mailbox->CurrentMode == "copy") {
				$mailbox_grid->loadRowValues($mailbox_grid->Recordset); // Load row values
				$mailbox_grid->setRecordKey($mailbox_grid->RowOldKey, $mailbox_grid->Recordset); // Set old record key
			} else {
				$mailbox_grid->loadRowValues(); // Load default values
				$mailbox_grid->RowOldKey = ""; // Clear old key value
			}
		} else {
			$mailbox_grid->loadRowValues($mailbox_grid->Recordset); // Load row values
		}
		$mailbox->RowType = ROWTYPE_VIEW; // Render view
		if ($mailbox_grid->isGridAdd()) // Grid add
			$mailbox->RowType = ROWTYPE_ADD; // Render add
		if ($mailbox_grid->isGridAdd() && $mailbox->EventCancelled && !$CurrentForm->hasValue("k_blankrow")) // Insert failed
			$mailbox_grid->restoreCurrentRowFormValues($mailbox_grid->RowIndex); // Restore form values
		if ($mailbox_grid->isGridEdit()) { // Grid edit
			if ($mailbox->EventCancelled)
				$mailbox_grid->restoreCurrentRowFormValues($mailbox_grid->RowIndex); // Restore form values
			if ($mailbox_grid->RowAction == "insert")
				$mailbox->RowType = ROWTYPE_ADD; // Render add
			else
				$mailbox->RowType = ROWTYPE_EDIT; // Render edit
		}
		if ($mailbox_grid->isGridEdit() && ($mailbox->RowType == ROWTYPE_EDIT || $mailbox->RowType == ROWTYPE_ADD) && $mailbox->EventCancelled) // Update failed
			$mailbox_grid->restoreCurrentRowFormValues($mailbox_grid->RowIndex); // Restore form values
		if ($mailbox->RowType == ROWTYPE_EDIT) // Edit row
			$mailbox_grid->EditRowCount++;
		if ($mailbox->isConfirm()) // Confirm row
			$mailbox_grid->restoreCurrentRowFormValues($mailbox_grid->RowIndex); // Restore form values

		// Set up row id / data-rowindex
		$mailbox->RowAttrs->merge(["data-rowindex" => $mailbox_grid->RowCount, "id" => "r" . $mailbox_grid->RowCount . "_mailbox", "data-rowtype" => $mailbox->RowType]);

		// Render row
		$mailbox_grid->renderRow();

		// Render list options
		$mailbox_grid->renderListOptions();

		// Skip delete row / empty row for confirm page
		if ($mailbox_grid->RowAction != "delete" && $mailbox_grid->RowAction != "insertdelete" && !($mailbox_grid->RowAction == "insert" && $mailbox->isConfirm() && $mailbox_grid->emptyRow())) {
?>
	<tr <?php echo $mailbox->rowAttributes() ?>>
<?php

// Render list options (body, left)
$mailbox_grid->ListOptions->render("body", "left", $mailbox_grid->RowCount);
?>
	<?php if ($mailbox_grid->msgid->Visible) { // msgid ?>
		<td data-name="msgid" <?php echo $mailbox_grid->msgid->cellAttributes() ?>>
<?php if ($mailbox->RowType == ROWTYPE_ADD) { // Add record ?>
<span id="el<?php echo $mailbox_grid->RowCount ?>_mailbox_msgid" class="form-group"></span>
<input type="hidden" data-table="mailbox" data-field="x_msgid" name="o<?php echo $mailbox_grid->RowIndex ?>_msgid" id="o<?php echo $mailbox_grid->RowIndex ?>_msgid" value="<?php echo HtmlEncode($mailbox_grid->msgid->OldValue) ?>">
<?php } ?>
<?php if ($mailbox->RowType == ROWTYPE_EDIT) { // Edit record ?>
<span id="el<?php echo $mailbox_grid->RowCount ?>_mailbox_msgid" class="form-group">
<span<?php echo $mailbox_grid->msgid->viewAttributes() ?>><input type="text" readonly class="form-control-plaintext" value="<?php echo HtmlEncode(RemoveHtml($mailbox_grid->msgid->EditValue)) ?>"></span>
</span>
<input type="hidden" data-table="mailbox" data-field="x_msgid" name="x<?php echo $mailbox_grid->RowIndex ?>_msgid" id="x<?php echo $mailbox_grid->RowIndex ?>_msgid" value="<?php echo HtmlEncode($mailbox_grid->msgid->CurrentValue) ?>">
<?php } ?>
<?php if ($mailbox->RowType == ROWTYPE_VIEW) { // View record ?>
<span id="el<?php echo $mailbox_grid->RowCount ?>_mailbox_msgid">
<span<?php echo $mailbox_grid->msgid->viewAttributes() ?>><?php echo $mailbox_grid->msgid->getViewValue() ?></span>
</span>
<?php if (!$mailbox->isConfirm()) { ?>
<input type="hidden" data-table="mailbox" data-field="x_msgid" name="x<?php echo $mailbox_grid->RowIndex ?>_msgid" id="x<?php echo $mailbox_grid->RowIndex ?>_msgid" value="<?php echo HtmlEncode($mailbox_grid->msgid->FormValue) ?>">
<input type="hidden" data-table="mailbox" data-field="x_msgid" name="o<?php echo $mailbox_grid->RowIndex ?>_msgid" id="o<?php echo $mailbox_grid->RowIndex ?>_msgid" value="<?php echo HtmlEncode($mailbox_grid->msgid->OldValue) ?>">
<?php } else { ?>
<input type="hidden" data-table="mailbox" data-field="x_msgid" name="fmailboxgrid$x<?php echo $mailbox_grid->RowIndex ?>_msgid" id="fmailboxgrid$x<?php echo $mailbox_grid->RowIndex ?>_msgid" value="<?php echo HtmlEncode($mailbox_grid->msgid->FormValue) ?>">
<input type="hidden" data-table="mailbox" data-field="x_msgid" name="fmailboxgrid$o<?php echo $mailbox_grid->RowIndex ?>_msgid" id="fmailboxgrid$o<?php echo $mailbox_grid->RowIndex ?>_msgid" value="<?php echo HtmlEncode($mailbox_grid->msgid->OldValue) ?>">
<?php } ?>
<?php } ?>
</td>
	<?php } ?>
	<?php if ($mailbox_grid->_userid->Visible) { // userid ?>
		<td data-name="_userid" <?php echo $mailbox_grid->_userid->cellAttributes() ?>>
<?php if ($mailbox->RowType == ROWTYPE_ADD) { // Add record ?>
<?php if ($mailbox_grid->_userid->getSessionValue() != "") { ?>
<span id="el<?php echo $mailbox_grid->RowCount ?>_mailbox__userid" class="form-group">
<span<?php echo $mailbox_grid->_userid->viewAttributes() ?>><?php if (!EmptyString($mailbox_grid->_userid->ViewValue) && $mailbox_grid->_userid->linkAttributes() != "") { ?>
<a<?php echo $mailbox_grid->_userid->linkAttributes() ?>><input type="text" readonly class="form-control-plaintext" value="<?php echo HtmlEncode(RemoveHtml($mailbox_grid->_userid->ViewValue)) ?>"></a>
<?php } else { ?>
<input type="text" readonly class="form-control-plaintext" value="<?php echo HtmlEncode(RemoveHtml($mailbox_grid->_userid->ViewValue)) ?>">
<?php } ?></span>
</span>
<input type="hidden" id="x<?php echo $mailbox_grid->RowIndex ?>__userid" name="x<?php echo $mailbox_grid->RowIndex ?>__userid" value="<?php echo HtmlEncode($mailbox_grid->_userid->CurrentValue) ?>">
<?php } else { ?>
<span id="el<?php echo $mailbox_grid->RowCount ?>_mailbox__userid" class="form-group">
<input type="text" data-table="mailbox" data-field="x__userid" name="x<?php echo $mailbox_grid->RowIndex ?>__userid" id="x<?php echo $mailbox_grid->RowIndex ?>__userid" size="30" placeholder="<?php echo HtmlEncode($mailbox_grid->_userid->getPlaceHolder()) ?>" value="<?php echo $mailbox_grid->_userid->EditValue ?>"<?php echo $mailbox_grid->_userid->editAttributes() ?>>
</span>
<?php } ?>
<input type="hidden" data-table="mailbox" data-field="x__userid" name="o<?php echo $mailbox_grid->RowIndex ?>__userid" id="o<?php echo $mailbox_grid->RowIndex ?>__userid" value="<?php echo HtmlEncode($mailbox_grid->_userid->OldValue) ?>">
<?php } ?>
<?php if ($mailbox->RowType == ROWTYPE_EDIT) { // Edit record ?>
<?php if ($mailbox_grid->_userid->getSessionValue() != "") { ?>
<span id="el<?php echo $mailbox_grid->RowCount ?>_mailbox__userid" class="form-group">
<span<?php echo $mailbox_grid->_userid->viewAttributes() ?>><?php if (!EmptyString($mailbox_grid->_userid->ViewValue) && $mailbox_grid->_userid->linkAttributes() != "") { ?>
<a<?php echo $mailbox_grid->_userid->linkAttributes() ?>><input type="text" readonly class="form-control-plaintext" value="<?php echo HtmlEncode(RemoveHtml($mailbox_grid->_userid->ViewValue)) ?>"></a>
<?php } else { ?>
<input type="text" readonly class="form-control-plaintext" value="<?php echo HtmlEncode(RemoveHtml($mailbox_grid->_userid->ViewValue)) ?>">
<?php } ?></span>
</span>
<input type="hidden" id="x<?php echo $mailbox_grid->RowIndex ?>__userid" name="x<?php echo $mailbox_grid->RowIndex ?>__userid" value="<?php echo HtmlEncode($mailbox_grid->_userid->CurrentValue) ?>">
<?php } else { ?>
<span id="el<?php echo $mailbox_grid->RowCount ?>_mailbox__userid" class="form-group">
<input type="text" data-table="mailbox" data-field="x__userid" name="x<?php echo $mailbox_grid->RowIndex ?>__userid" id="x<?php echo $mailbox_grid->RowIndex ?>__userid" size="30" placeholder="<?php echo HtmlEncode($mailbox_grid->_userid->getPlaceHolder()) ?>" value="<?php echo $mailbox_grid->_userid->EditValue ?>"<?php echo $mailbox_grid->_userid->editAttributes() ?>>
</span>
<?php } ?>
<?php } ?>
<?php if ($mailbox->RowType == ROWTYPE_VIEW) { // View record ?>
<span id="el<?php echo $mailbox_grid->RowCount ?>_mailbox__userid">
<span<?php echo $mailbox_grid->_userid->viewAttributes() ?>><?php if (!EmptyString($mailbox_grid->_userid->getViewValue()) && $mailbox_grid->_userid->linkAttributes() != "") { ?>
<a<?php echo $mailbox_grid->_userid->linkAttributes() ?>><?php echo $mailbox_grid->_userid->getViewValue() ?></a>
<?php } else { ?>
<?php echo $mailbox_grid->_userid->getViewValue() ?>
<?php } ?></span>
</span>
<?php if (!$mailbox->isConfirm()) { ?>
<input type="hidden" data-table="mailbox" data-field="x__userid" name="x<?php echo $mailbox_grid->RowIndex ?>__userid" id="x<?php echo $mailbox_grid->RowIndex ?>__userid" value="<?php echo HtmlEncode($mailbox_grid->_userid->FormValue) ?>">
<input type="hidden" data-table="mailbox" data-field="x__userid" name="o<?php echo $mailbox_grid->RowIndex ?>__userid" id="o<?php echo $mailbox_grid->RowIndex ?>__userid" value="<?php echo HtmlEncode($mailbox_grid->_userid->OldValue) ?>">
<?php } else { ?>
<input type="hidden" data-table="mailbox" data-field="x__userid" name="fmailboxgrid$x<?php echo $mailbox_grid->RowIndex ?>__userid" id="fmailboxgrid$x<?php echo $mailbox_grid->RowIndex ?>__userid" value="<?php echo HtmlEncode($mailbox_grid->_userid->FormValue) ?>">
<input type="hidden" data-table="mailbox" data-field="x__userid" name="fmailboxgrid$o<?php echo $mailbox_grid->RowIndex ?>__userid" id="fmailboxgrid$o<?php echo $mailbox_grid->RowIndex ?>__userid" value="<?php echo HtmlEncode($mailbox_grid->_userid->OldValue) ?>">
<?php } ?>
<?php } ?>
</td>
	<?php } ?>
	<?php if ($mailbox_grid->msgtype->Visible) { // msgtype ?>
		<td data-name="msgtype" <?php echo $mailbox_grid->msgtype->cellAttributes() ?>>
<?php if ($mailbox->RowType == ROWTYPE_ADD) { // Add record ?>
<span id="el<?php echo $mailbox_grid->RowCount ?>_mailbox_msgtype" class="form-group">
<div class="input-group">
	<select class="custom-select ew-custom-select" data-table="mailbox" data-field="x_msgtype" data-value-separator="<?php echo $mailbox_grid->msgtype->displayValueSeparatorAttribute() ?>" id="x<?php echo $mailbox_grid->RowIndex ?>_msgtype" name="x<?php echo $mailbox_grid->RowIndex ?>_msgtype"<?php echo $mailbox_grid->msgtype->editAttributes() ?>>
			<?php echo $mailbox_grid->msgtype->selectOptionListHtml("x{$mailbox_grid->RowIndex}_msgtype") ?>
		</select>
</div>
<?php echo $mailbox_grid->msgtype->Lookup->getParamTag($mailbox_grid, "p_x" . $mailbox_grid->RowIndex . "_msgtype") ?>
</span>
<input type="hidden" data-table="mailbox" data-field="x_msgtype" name="o<?php echo $mailbox_grid->RowIndex ?>_msgtype" id="o<?php echo $mailbox_grid->RowIndex ?>_msgtype" value="<?php echo HtmlEncode($mailbox_grid->msgtype->OldValue) ?>">
<?php } ?>
<?php if ($mailbox->RowType == ROWTYPE_EDIT) { // Edit record ?>
<span id="el<?php echo $mailbox_grid->RowCount ?>_mailbox_msgtype" class="form-group">
<div class="input-group">
	<select class="custom-select ew-custom-select" data-table="mailbox" data-field="x_msgtype" data-value-separator="<?php echo $mailbox_grid->msgtype->displayValueSeparatorAttribute() ?>" id="x<?php echo $mailbox_grid->RowIndex ?>_msgtype" name="x<?php echo $mailbox_grid->RowIndex ?>_msgtype"<?php echo $mailbox_grid->msgtype->editAttributes() ?>>
			<?php echo $mailbox_grid->msgtype->selectOptionListHtml("x{$mailbox_grid->RowIndex}_msgtype") ?>
		</select>
</div>
<?php echo $mailbox_grid->msgtype->Lookup->getParamTag($mailbox_grid, "p_x" . $mailbox_grid->RowIndex . "_msgtype") ?>
</span>
<?php } ?>
<?php if ($mailbox->RowType == ROWTYPE_VIEW) { // View record ?>
<span id="el<?php echo $mailbox_grid->RowCount ?>_mailbox_msgtype">
<span<?php echo $mailbox_grid->msgtype->viewAttributes() ?>><?php echo $mailbox_grid->msgtype->getViewValue() ?></span>
</span>
<?php if (!$mailbox->isConfirm()) { ?>
<input type="hidden" data-table="mailbox" data-field="x_msgtype" name="x<?php echo $mailbox_grid->RowIndex ?>_msgtype" id="x<?php echo $mailbox_grid->RowIndex ?>_msgtype" value="<?php echo HtmlEncode($mailbox_grid->msgtype->FormValue) ?>">
<input type="hidden" data-table="mailbox" data-field="x_msgtype" name="o<?php echo $mailbox_grid->RowIndex ?>_msgtype" id="o<?php echo $mailbox_grid->RowIndex ?>_msgtype" value="<?php echo HtmlEncode($mailbox_grid->msgtype->OldValue) ?>">
<?php } else { ?>
<input type="hidden" data-table="mailbox" data-field="x_msgtype" name="fmailboxgrid$x<?php echo $mailbox_grid->RowIndex ?>_msgtype" id="fmailboxgrid$x<?php echo $mailbox_grid->RowIndex ?>_msgtype" value="<?php echo HtmlEncode($mailbox_grid->msgtype->FormValue) ?>">
<input type="hidden" data-table="mailbox" data-field="x_msgtype" name="fmailboxgrid$o<?php echo $mailbox_grid->RowIndex ?>_msgtype" id="fmailboxgrid$o<?php echo $mailbox_grid->RowIndex ?>_msgtype" value="<?php echo HtmlEncode($mailbox_grid->msgtype->OldValue) ?>">
<?php } ?>
<?php } ?>
</td>
	<?php } ?>
	<?php if ($mailbox_grid->msgcontent->Visible) { // msgcontent ?>
		<td data-name="msgcontent" <?php echo $mailbox_grid->msgcontent->cellAttributes() ?>>
<?php if ($mailbox->RowType == ROWTYPE_ADD) { // Add record ?>
<span id="el<?php echo $mailbox_grid->RowCount ?>_mailbox_msgcontent" class="form-group">
<input type="text" data-table="mailbox" data-field="x_msgcontent" name="x<?php echo $mailbox_grid->RowIndex ?>_msgcontent" id="x<?php echo $mailbox_grid->RowIndex ?>_msgcontent" size="30" maxlength="200" placeholder="<?php echo HtmlEncode($mailbox_grid->msgcontent->getPlaceHolder()) ?>" value="<?php echo $mailbox_grid->msgcontent->EditValue ?>"<?php echo $mailbox_grid->msgcontent->editAttributes() ?>>
</span>
<input type="hidden" data-table="mailbox" data-field="x_msgcontent" name="o<?php echo $mailbox_grid->RowIndex ?>_msgcontent" id="o<?php echo $mailbox_grid->RowIndex ?>_msgcontent" value="<?php echo HtmlEncode($mailbox_grid->msgcontent->OldValue) ?>">
<?php } ?>
<?php if ($mailbox->RowType == ROWTYPE_EDIT) { // Edit record ?>
<span id="el<?php echo $mailbox_grid->RowCount ?>_mailbox_msgcontent" class="form-group">
<input type="text" data-table="mailbox" data-field="x_msgcontent" name="x<?php echo $mailbox_grid->RowIndex ?>_msgcontent" id="x<?php echo $mailbox_grid->RowIndex ?>_msgcontent" size="30" maxlength="200" placeholder="<?php echo HtmlEncode($mailbox_grid->msgcontent->getPlaceHolder()) ?>" value="<?php echo $mailbox_grid->msgcontent->EditValue ?>"<?php echo $mailbox_grid->msgcontent->editAttributes() ?>>
</span>
<?php } ?>
<?php if ($mailbox->RowType == ROWTYPE_VIEW) { // View record ?>
<span id="el<?php echo $mailbox_grid->RowCount ?>_mailbox_msgcontent">
<span<?php echo $mailbox_grid->msgcontent->viewAttributes() ?>><?php echo $mailbox_grid->msgcontent->getViewValue() ?></span>
</span>
<?php if (!$mailbox->isConfirm()) { ?>
<input type="hidden" data-table="mailbox" data-field="x_msgcontent" name="x<?php echo $mailbox_grid->RowIndex ?>_msgcontent" id="x<?php echo $mailbox_grid->RowIndex ?>_msgcontent" value="<?php echo HtmlEncode($mailbox_grid->msgcontent->FormValue) ?>">
<input type="hidden" data-table="mailbox" data-field="x_msgcontent" name="o<?php echo $mailbox_grid->RowIndex ?>_msgcontent" id="o<?php echo $mailbox_grid->RowIndex ?>_msgcontent" value="<?php echo HtmlEncode($mailbox_grid->msgcontent->OldValue) ?>">
<?php } else { ?>
<input type="hidden" data-table="mailbox" data-field="x_msgcontent" name="fmailboxgrid$x<?php echo $mailbox_grid->RowIndex ?>_msgcontent" id="fmailboxgrid$x<?php echo $mailbox_grid->RowIndex ?>_msgcontent" value="<?php echo HtmlEncode($mailbox_grid->msgcontent->FormValue) ?>">
<input type="hidden" data-table="mailbox" data-field="x_msgcontent" name="fmailboxgrid$o<?php echo $mailbox_grid->RowIndex ?>_msgcontent" id="fmailboxgrid$o<?php echo $mailbox_grid->RowIndex ?>_msgcontent" value="<?php echo HtmlEncode($mailbox_grid->msgcontent->OldValue) ?>">
<?php } ?>
<?php } ?>
</td>
	<?php } ?>
	<?php if ($mailbox_grid->msgread->Visible) { // msgread ?>
		<td data-name="msgread" <?php echo $mailbox_grid->msgread->cellAttributes() ?>>
<?php if ($mailbox->RowType == ROWTYPE_ADD) { // Add record ?>
<span id="el<?php echo $mailbox_grid->RowCount ?>_mailbox_msgread" class="form-group">
<div id="tp_x<?php echo $mailbox_grid->RowIndex ?>_msgread" class="ew-template"><input type="radio" class="custom-control-input" data-table="mailbox" data-field="x_msgread" data-value-separator="<?php echo $mailbox_grid->msgread->displayValueSeparatorAttribute() ?>" name="x<?php echo $mailbox_grid->RowIndex ?>_msgread" id="x<?php echo $mailbox_grid->RowIndex ?>_msgread" value="{value}"<?php echo $mailbox_grid->msgread->editAttributes() ?>></div>
<div id="dsl_x<?php echo $mailbox_grid->RowIndex ?>_msgread" data-repeatcolumn="5" class="ew-item-list d-none"><div>
<?php echo $mailbox_grid->msgread->radioButtonListHtml(FALSE, "x{$mailbox_grid->RowIndex}_msgread") ?>
</div></div>
<?php echo $mailbox_grid->msgread->Lookup->getParamTag($mailbox_grid, "p_x" . $mailbox_grid->RowIndex . "_msgread") ?>
</span>
<input type="hidden" data-table="mailbox" data-field="x_msgread" name="o<?php echo $mailbox_grid->RowIndex ?>_msgread" id="o<?php echo $mailbox_grid->RowIndex ?>_msgread" value="<?php echo HtmlEncode($mailbox_grid->msgread->OldValue) ?>">
<?php } ?>
<?php if ($mailbox->RowType == ROWTYPE_EDIT) { // Edit record ?>
<span id="el<?php echo $mailbox_grid->RowCount ?>_mailbox_msgread" class="form-group">
<div id="tp_x<?php echo $mailbox_grid->RowIndex ?>_msgread" class="ew-template"><input type="radio" class="custom-control-input" data-table="mailbox" data-field="x_msgread" data-value-separator="<?php echo $mailbox_grid->msgread->displayValueSeparatorAttribute() ?>" name="x<?php echo $mailbox_grid->RowIndex ?>_msgread" id="x<?php echo $mailbox_grid->RowIndex ?>_msgread" value="{value}"<?php echo $mailbox_grid->msgread->editAttributes() ?>></div>
<div id="dsl_x<?php echo $mailbox_grid->RowIndex ?>_msgread" data-repeatcolumn="5" class="ew-item-list d-none"><div>
<?php echo $mailbox_grid->msgread->radioButtonListHtml(FALSE, "x{$mailbox_grid->RowIndex}_msgread") ?>
</div></div>
<?php echo $mailbox_grid->msgread->Lookup->getParamTag($mailbox_grid, "p_x" . $mailbox_grid->RowIndex . "_msgread") ?>
</span>
<?php } ?>
<?php if ($mailbox->RowType == ROWTYPE_VIEW) { // View record ?>
<span id="el<?php echo $mailbox_grid->RowCount ?>_mailbox_msgread">
<span<?php echo $mailbox_grid->msgread->viewAttributes() ?>><?php echo $mailbox_grid->msgread->getViewValue() ?></span>
</span>
<?php if (!$mailbox->isConfirm()) { ?>
<input type="hidden" data-table="mailbox" data-field="x_msgread" name="x<?php echo $mailbox_grid->RowIndex ?>_msgread" id="x<?php echo $mailbox_grid->RowIndex ?>_msgread" value="<?php echo HtmlEncode($mailbox_grid->msgread->FormValue) ?>">
<input type="hidden" data-table="mailbox" data-field="x_msgread" name="o<?php echo $mailbox_grid->RowIndex ?>_msgread" id="o<?php echo $mailbox_grid->RowIndex ?>_msgread" value="<?php echo HtmlEncode($mailbox_grid->msgread->OldValue) ?>">
<?php } else { ?>
<input type="hidden" data-table="mailbox" data-field="x_msgread" name="fmailboxgrid$x<?php echo $mailbox_grid->RowIndex ?>_msgread" id="fmailboxgrid$x<?php echo $mailbox_grid->RowIndex ?>_msgread" value="<?php echo HtmlEncode($mailbox_grid->msgread->FormValue) ?>">
<input type="hidden" data-table="mailbox" data-field="x_msgread" name="fmailboxgrid$o<?php echo $mailbox_grid->RowIndex ?>_msgread" id="fmailboxgrid$o<?php echo $mailbox_grid->RowIndex ?>_msgread" value="<?php echo HtmlEncode($mailbox_grid->msgread->OldValue) ?>">
<?php } ?>
<?php } ?>
</td>
	<?php } ?>
	<?php if ($mailbox_grid->msgtime->Visible) { // msgtime ?>
		<td data-name="msgtime" <?php echo $mailbox_grid->msgtime->cellAttributes() ?>>
<?php if ($mailbox->RowType == ROWTYPE_ADD) { // Add record ?>
<span id="el<?php echo $mailbox_grid->RowCount ?>_mailbox_msgtime" class="form-group">
<input type="text" data-table="mailbox" data-field="x_msgtime" data-format="1" name="x<?php echo $mailbox_grid->RowIndex ?>_msgtime" id="x<?php echo $mailbox_grid->RowIndex ?>_msgtime" placeholder="<?php echo HtmlEncode($mailbox_grid->msgtime->getPlaceHolder()) ?>" value="<?php echo $mailbox_grid->msgtime->EditValue ?>"<?php echo $mailbox_grid->msgtime->editAttributes() ?>>
</span>
<input type="hidden" data-table="mailbox" data-field="x_msgtime" name="o<?php echo $mailbox_grid->RowIndex ?>_msgtime" id="o<?php echo $mailbox_grid->RowIndex ?>_msgtime" value="<?php echo HtmlEncode($mailbox_grid->msgtime->OldValue) ?>">
<?php } ?>
<?php if ($mailbox->RowType == ROWTYPE_EDIT) { // Edit record ?>
<span id="el<?php echo $mailbox_grid->RowCount ?>_mailbox_msgtime" class="form-group">
<input type="text" data-table="mailbox" data-field="x_msgtime" data-format="1" name="x<?php echo $mailbox_grid->RowIndex ?>_msgtime" id="x<?php echo $mailbox_grid->RowIndex ?>_msgtime" placeholder="<?php echo HtmlEncode($mailbox_grid->msgtime->getPlaceHolder()) ?>" value="<?php echo $mailbox_grid->msgtime->EditValue ?>"<?php echo $mailbox_grid->msgtime->editAttributes() ?>>
</span>
<?php } ?>
<?php if ($mailbox->RowType == ROWTYPE_VIEW) { // View record ?>
<span id="el<?php echo $mailbox_grid->RowCount ?>_mailbox_msgtime">
<span<?php echo $mailbox_grid->msgtime->viewAttributes() ?>><?php echo $mailbox_grid->msgtime->getViewValue() ?></span>
</span>
<?php if (!$mailbox->isConfirm()) { ?>
<input type="hidden" data-table="mailbox" data-field="x_msgtime" name="x<?php echo $mailbox_grid->RowIndex ?>_msgtime" id="x<?php echo $mailbox_grid->RowIndex ?>_msgtime" value="<?php echo HtmlEncode($mailbox_grid->msgtime->FormValue) ?>">
<input type="hidden" data-table="mailbox" data-field="x_msgtime" name="o<?php echo $mailbox_grid->RowIndex ?>_msgtime" id="o<?php echo $mailbox_grid->RowIndex ?>_msgtime" value="<?php echo HtmlEncode($mailbox_grid->msgtime->OldValue) ?>">
<?php } else { ?>
<input type="hidden" data-table="mailbox" data-field="x_msgtime" name="fmailboxgrid$x<?php echo $mailbox_grid->RowIndex ?>_msgtime" id="fmailboxgrid$x<?php echo $mailbox_grid->RowIndex ?>_msgtime" value="<?php echo HtmlEncode($mailbox_grid->msgtime->FormValue) ?>">
<input type="hidden" data-table="mailbox" data-field="x_msgtime" name="fmailboxgrid$o<?php echo $mailbox_grid->RowIndex ?>_msgtime" id="fmailboxgrid$o<?php echo $mailbox_grid->RowIndex ?>_msgtime" value="<?php echo HtmlEncode($mailbox_grid->msgtime->OldValue) ?>">
<?php } ?>
<?php } ?>
</td>
	<?php } ?>
	<?php if ($mailbox_grid->datavalue->Visible) { // datavalue ?>
		<td data-name="datavalue" <?php echo $mailbox_grid->datavalue->cellAttributes() ?>>
<?php if ($mailbox->RowType == ROWTYPE_ADD) { // Add record ?>
<span id="el<?php echo $mailbox_grid->RowCount ?>_mailbox_datavalue" class="form-group">
<input type="text" data-table="mailbox" data-field="x_datavalue" name="x<?php echo $mailbox_grid->RowIndex ?>_datavalue" id="x<?php echo $mailbox_grid->RowIndex ?>_datavalue" size="30" maxlength="50" placeholder="<?php echo HtmlEncode($mailbox_grid->datavalue->getPlaceHolder()) ?>" value="<?php echo $mailbox_grid->datavalue->EditValue ?>"<?php echo $mailbox_grid->datavalue->editAttributes() ?>>
</span>
<input type="hidden" data-table="mailbox" data-field="x_datavalue" name="o<?php echo $mailbox_grid->RowIndex ?>_datavalue" id="o<?php echo $mailbox_grid->RowIndex ?>_datavalue" value="<?php echo HtmlEncode($mailbox_grid->datavalue->OldValue) ?>">
<?php } ?>
<?php if ($mailbox->RowType == ROWTYPE_EDIT) { // Edit record ?>
<span id="el<?php echo $mailbox_grid->RowCount ?>_mailbox_datavalue" class="form-group">
<input type="text" data-table="mailbox" data-field="x_datavalue" name="x<?php echo $mailbox_grid->RowIndex ?>_datavalue" id="x<?php echo $mailbox_grid->RowIndex ?>_datavalue" size="30" maxlength="50" placeholder="<?php echo HtmlEncode($mailbox_grid->datavalue->getPlaceHolder()) ?>" value="<?php echo $mailbox_grid->datavalue->EditValue ?>"<?php echo $mailbox_grid->datavalue->editAttributes() ?>>
</span>
<?php } ?>
<?php if ($mailbox->RowType == ROWTYPE_VIEW) { // View record ?>
<span id="el<?php echo $mailbox_grid->RowCount ?>_mailbox_datavalue">
<span<?php echo $mailbox_grid->datavalue->viewAttributes() ?>><?php echo $mailbox_grid->datavalue->getViewValue() ?></span>
</span>
<?php if (!$mailbox->isConfirm()) { ?>
<input type="hidden" data-table="mailbox" data-field="x_datavalue" name="x<?php echo $mailbox_grid->RowIndex ?>_datavalue" id="x<?php echo $mailbox_grid->RowIndex ?>_datavalue" value="<?php echo HtmlEncode($mailbox_grid->datavalue->FormValue) ?>">
<input type="hidden" data-table="mailbox" data-field="x_datavalue" name="o<?php echo $mailbox_grid->RowIndex ?>_datavalue" id="o<?php echo $mailbox_grid->RowIndex ?>_datavalue" value="<?php echo HtmlEncode($mailbox_grid->datavalue->OldValue) ?>">
<?php } else { ?>
<input type="hidden" data-table="mailbox" data-field="x_datavalue" name="fmailboxgrid$x<?php echo $mailbox_grid->RowIndex ?>_datavalue" id="fmailboxgrid$x<?php echo $mailbox_grid->RowIndex ?>_datavalue" value="<?php echo HtmlEncode($mailbox_grid->datavalue->FormValue) ?>">
<input type="hidden" data-table="mailbox" data-field="x_datavalue" name="fmailboxgrid$o<?php echo $mailbox_grid->RowIndex ?>_datavalue" id="fmailboxgrid$o<?php echo $mailbox_grid->RowIndex ?>_datavalue" value="<?php echo HtmlEncode($mailbox_grid->datavalue->OldValue) ?>">
<?php } ?>
<?php } ?>
</td>
	<?php } ?>
	<?php if ($mailbox_grid->version->Visible) { // version ?>
		<td data-name="version" <?php echo $mailbox_grid->version->cellAttributes() ?>>
<?php if ($mailbox->RowType == ROWTYPE_ADD) { // Add record ?>
<span id="el<?php echo $mailbox_grid->RowCount ?>_mailbox_version" class="form-group">
<input type="text" data-table="mailbox" data-field="x_version" name="x<?php echo $mailbox_grid->RowIndex ?>_version" id="x<?php echo $mailbox_grid->RowIndex ?>_version" size="30" maxlength="1" placeholder="<?php echo HtmlEncode($mailbox_grid->version->getPlaceHolder()) ?>" value="<?php echo $mailbox_grid->version->EditValue ?>"<?php echo $mailbox_grid->version->editAttributes() ?>>
</span>
<input type="hidden" data-table="mailbox" data-field="x_version" name="o<?php echo $mailbox_grid->RowIndex ?>_version" id="o<?php echo $mailbox_grid->RowIndex ?>_version" value="<?php echo HtmlEncode($mailbox_grid->version->OldValue) ?>">
<?php } ?>
<?php if ($mailbox->RowType == ROWTYPE_EDIT) { // Edit record ?>
<span id="el<?php echo $mailbox_grid->RowCount ?>_mailbox_version" class="form-group">
<input type="text" data-table="mailbox" data-field="x_version" name="x<?php echo $mailbox_grid->RowIndex ?>_version" id="x<?php echo $mailbox_grid->RowIndex ?>_version" size="30" maxlength="1" placeholder="<?php echo HtmlEncode($mailbox_grid->version->getPlaceHolder()) ?>" value="<?php echo $mailbox_grid->version->EditValue ?>"<?php echo $mailbox_grid->version->editAttributes() ?>>
</span>
<?php } ?>
<?php if ($mailbox->RowType == ROWTYPE_VIEW) { // View record ?>
<span id="el<?php echo $mailbox_grid->RowCount ?>_mailbox_version">
<span<?php echo $mailbox_grid->version->viewAttributes() ?>><?php echo $mailbox_grid->version->getViewValue() ?></span>
</span>
<?php if (!$mailbox->isConfirm()) { ?>
<input type="hidden" data-table="mailbox" data-field="x_version" name="x<?php echo $mailbox_grid->RowIndex ?>_version" id="x<?php echo $mailbox_grid->RowIndex ?>_version" value="<?php echo HtmlEncode($mailbox_grid->version->FormValue) ?>">
<input type="hidden" data-table="mailbox" data-field="x_version" name="o<?php echo $mailbox_grid->RowIndex ?>_version" id="o<?php echo $mailbox_grid->RowIndex ?>_version" value="<?php echo HtmlEncode($mailbox_grid->version->OldValue) ?>">
<?php } else { ?>
<input type="hidden" data-table="mailbox" data-field="x_version" name="fmailboxgrid$x<?php echo $mailbox_grid->RowIndex ?>_version" id="fmailboxgrid$x<?php echo $mailbox_grid->RowIndex ?>_version" value="<?php echo HtmlEncode($mailbox_grid->version->FormValue) ?>">
<input type="hidden" data-table="mailbox" data-field="x_version" name="fmailboxgrid$o<?php echo $mailbox_grid->RowIndex ?>_version" id="fmailboxgrid$o<?php echo $mailbox_grid->RowIndex ?>_version" value="<?php echo HtmlEncode($mailbox_grid->version->OldValue) ?>">
<?php } ?>
<?php } ?>
</td>
	<?php } ?>
	<?php if ($mailbox_grid->delimeter->Visible) { // delimeter ?>
		<td data-name="delimeter" <?php echo $mailbox_grid->delimeter->cellAttributes() ?>>
<?php if ($mailbox->RowType == ROWTYPE_ADD) { // Add record ?>
<span id="el<?php echo $mailbox_grid->RowCount ?>_mailbox_delimeter" class="form-group">
<input type="text" data-table="mailbox" data-field="x_delimeter" name="x<?php echo $mailbox_grid->RowIndex ?>_delimeter" id="x<?php echo $mailbox_grid->RowIndex ?>_delimeter" size="30" maxlength="3" placeholder="<?php echo HtmlEncode($mailbox_grid->delimeter->getPlaceHolder()) ?>" value="<?php echo $mailbox_grid->delimeter->EditValue ?>"<?php echo $mailbox_grid->delimeter->editAttributes() ?>>
</span>
<input type="hidden" data-table="mailbox" data-field="x_delimeter" name="o<?php echo $mailbox_grid->RowIndex ?>_delimeter" id="o<?php echo $mailbox_grid->RowIndex ?>_delimeter" value="<?php echo HtmlEncode($mailbox_grid->delimeter->OldValue) ?>">
<?php } ?>
<?php if ($mailbox->RowType == ROWTYPE_EDIT) { // Edit record ?>
<span id="el<?php echo $mailbox_grid->RowCount ?>_mailbox_delimeter" class="form-group">
<input type="text" data-table="mailbox" data-field="x_delimeter" name="x<?php echo $mailbox_grid->RowIndex ?>_delimeter" id="x<?php echo $mailbox_grid->RowIndex ?>_delimeter" size="30" maxlength="3" placeholder="<?php echo HtmlEncode($mailbox_grid->delimeter->getPlaceHolder()) ?>" value="<?php echo $mailbox_grid->delimeter->EditValue ?>"<?php echo $mailbox_grid->delimeter->editAttributes() ?>>
</span>
<?php } ?>
<?php if ($mailbox->RowType == ROWTYPE_VIEW) { // View record ?>
<span id="el<?php echo $mailbox_grid->RowCount ?>_mailbox_delimeter">
<span<?php echo $mailbox_grid->delimeter->viewAttributes() ?>><?php echo $mailbox_grid->delimeter->getViewValue() ?></span>
</span>
<?php if (!$mailbox->isConfirm()) { ?>
<input type="hidden" data-table="mailbox" data-field="x_delimeter" name="x<?php echo $mailbox_grid->RowIndex ?>_delimeter" id="x<?php echo $mailbox_grid->RowIndex ?>_delimeter" value="<?php echo HtmlEncode($mailbox_grid->delimeter->FormValue) ?>">
<input type="hidden" data-table="mailbox" data-field="x_delimeter" name="o<?php echo $mailbox_grid->RowIndex ?>_delimeter" id="o<?php echo $mailbox_grid->RowIndex ?>_delimeter" value="<?php echo HtmlEncode($mailbox_grid->delimeter->OldValue) ?>">
<?php } else { ?>
<input type="hidden" data-table="mailbox" data-field="x_delimeter" name="fmailboxgrid$x<?php echo $mailbox_grid->RowIndex ?>_delimeter" id="fmailboxgrid$x<?php echo $mailbox_grid->RowIndex ?>_delimeter" value="<?php echo HtmlEncode($mailbox_grid->delimeter->FormValue) ?>">
<input type="hidden" data-table="mailbox" data-field="x_delimeter" name="fmailboxgrid$o<?php echo $mailbox_grid->RowIndex ?>_delimeter" id="fmailboxgrid$o<?php echo $mailbox_grid->RowIndex ?>_delimeter" value="<?php echo HtmlEncode($mailbox_grid->delimeter->OldValue) ?>">
<?php } ?>
<?php } ?>
</td>
	<?php } ?>
<?php

// Render list options (body, right)
$mailbox_grid->ListOptions->render("body", "right", $mailbox_grid->RowCount);
?>
	</tr>
<?php if ($mailbox->RowType == ROWTYPE_ADD || $mailbox->RowType == ROWTYPE_EDIT) { ?>
<script>
loadjs.ready(["fmailboxgrid", "load"], function() {
	fmailboxgrid.updateLists(<?php echo $mailbox_grid->RowIndex ?>);
});
</script>
<?php } ?>
<?php
	}
	} // End delete row checking
	if (!$mailbox_grid->isGridAdd() || $mailbox->CurrentMode == "copy")
		if (!$mailbox_grid->Recordset->EOF)
			$mailbox_grid->Recordset->moveNext();
}
?>
<?php
	if ($mailbox->CurrentMode == "add" || $mailbox->CurrentMode == "copy" || $mailbox->CurrentMode == "edit") {
		$mailbox_grid->RowIndex = '$rowindex$';
		$mailbox_grid->loadRowValues();

		// Set row properties
		$mailbox->resetAttributes();
		$mailbox->RowAttrs->merge(["data-rowindex" => $mailbox_grid->RowIndex, "id" => "r0_mailbox", "data-rowtype" => ROWTYPE_ADD]);
		$mailbox->RowAttrs->appendClass("ew-template");
		$mailbox->RowType = ROWTYPE_ADD;

		// Render row
		$mailbox_grid->renderRow();

		// Render list options
		$mailbox_grid->renderListOptions();
		$mailbox_grid->StartRowCount = 0;
?>
	<tr <?php echo $mailbox->rowAttributes() ?>>
<?php

// Render list options (body, left)
$mailbox_grid->ListOptions->render("body", "left", $mailbox_grid->RowIndex);
?>
	<?php if ($mailbox_grid->msgid->Visible) { // msgid ?>
		<td data-name="msgid">
<?php if (!$mailbox->isConfirm()) { ?>
<span id="el$rowindex$_mailbox_msgid" class="form-group mailbox_msgid"></span>
<?php } else { ?>
<span id="el$rowindex$_mailbox_msgid" class="form-group mailbox_msgid">
<span<?php echo $mailbox_grid->msgid->viewAttributes() ?>><input type="text" readonly class="form-control-plaintext" value="<?php echo HtmlEncode(RemoveHtml($mailbox_grid->msgid->ViewValue)) ?>"></span>
</span>
<input type="hidden" data-table="mailbox" data-field="x_msgid" name="x<?php echo $mailbox_grid->RowIndex ?>_msgid" id="x<?php echo $mailbox_grid->RowIndex ?>_msgid" value="<?php echo HtmlEncode($mailbox_grid->msgid->FormValue) ?>">
<?php } ?>
<input type="hidden" data-table="mailbox" data-field="x_msgid" name="o<?php echo $mailbox_grid->RowIndex ?>_msgid" id="o<?php echo $mailbox_grid->RowIndex ?>_msgid" value="<?php echo HtmlEncode($mailbox_grid->msgid->OldValue) ?>">
</td>
	<?php } ?>
	<?php if ($mailbox_grid->_userid->Visible) { // userid ?>
		<td data-name="_userid">
<?php if (!$mailbox->isConfirm()) { ?>
<?php if ($mailbox_grid->_userid->getSessionValue() != "") { ?>
<span id="el$rowindex$_mailbox__userid" class="form-group mailbox__userid">
<span<?php echo $mailbox_grid->_userid->viewAttributes() ?>><?php if (!EmptyString($mailbox_grid->_userid->ViewValue) && $mailbox_grid->_userid->linkAttributes() != "") { ?>
<a<?php echo $mailbox_grid->_userid->linkAttributes() ?>><input type="text" readonly class="form-control-plaintext" value="<?php echo HtmlEncode(RemoveHtml($mailbox_grid->_userid->ViewValue)) ?>"></a>
<?php } else { ?>
<input type="text" readonly class="form-control-plaintext" value="<?php echo HtmlEncode(RemoveHtml($mailbox_grid->_userid->ViewValue)) ?>">
<?php } ?></span>
</span>
<input type="hidden" id="x<?php echo $mailbox_grid->RowIndex ?>__userid" name="x<?php echo $mailbox_grid->RowIndex ?>__userid" value="<?php echo HtmlEncode($mailbox_grid->_userid->CurrentValue) ?>">
<?php } else { ?>
<span id="el$rowindex$_mailbox__userid" class="form-group mailbox__userid">
<input type="text" data-table="mailbox" data-field="x__userid" name="x<?php echo $mailbox_grid->RowIndex ?>__userid" id="x<?php echo $mailbox_grid->RowIndex ?>__userid" size="30" placeholder="<?php echo HtmlEncode($mailbox_grid->_userid->getPlaceHolder()) ?>" value="<?php echo $mailbox_grid->_userid->EditValue ?>"<?php echo $mailbox_grid->_userid->editAttributes() ?>>
</span>
<?php } ?>
<?php } else { ?>
<span id="el$rowindex$_mailbox__userid" class="form-group mailbox__userid">
<span<?php echo $mailbox_grid->_userid->viewAttributes() ?>><?php if (!EmptyString($mailbox_grid->_userid->ViewValue) && $mailbox_grid->_userid->linkAttributes() != "") { ?>
<a<?php echo $mailbox_grid->_userid->linkAttributes() ?>><input type="text" readonly class="form-control-plaintext" value="<?php echo HtmlEncode(RemoveHtml($mailbox_grid->_userid->ViewValue)) ?>"></a>
<?php } else { ?>
<input type="text" readonly class="form-control-plaintext" value="<?php echo HtmlEncode(RemoveHtml($mailbox_grid->_userid->ViewValue)) ?>">
<?php } ?></span>
</span>
<input type="hidden" data-table="mailbox" data-field="x__userid" name="x<?php echo $mailbox_grid->RowIndex ?>__userid" id="x<?php echo $mailbox_grid->RowIndex ?>__userid" value="<?php echo HtmlEncode($mailbox_grid->_userid->FormValue) ?>">
<?php } ?>
<input type="hidden" data-table="mailbox" data-field="x__userid" name="o<?php echo $mailbox_grid->RowIndex ?>__userid" id="o<?php echo $mailbox_grid->RowIndex ?>__userid" value="<?php echo HtmlEncode($mailbox_grid->_userid->OldValue) ?>">
</td>
	<?php } ?>
	<?php if ($mailbox_grid->msgtype->Visible) { // msgtype ?>
		<td data-name="msgtype">
<?php if (!$mailbox->isConfirm()) { ?>
<span id="el$rowindex$_mailbox_msgtype" class="form-group mailbox_msgtype">
<div class="input-group">
	<select class="custom-select ew-custom-select" data-table="mailbox" data-field="x_msgtype" data-value-separator="<?php echo $mailbox_grid->msgtype->displayValueSeparatorAttribute() ?>" id="x<?php echo $mailbox_grid->RowIndex ?>_msgtype" name="x<?php echo $mailbox_grid->RowIndex ?>_msgtype"<?php echo $mailbox_grid->msgtype->editAttributes() ?>>
			<?php echo $mailbox_grid->msgtype->selectOptionListHtml("x{$mailbox_grid->RowIndex}_msgtype") ?>
		</select>
</div>
<?php echo $mailbox_grid->msgtype->Lookup->getParamTag($mailbox_grid, "p_x" . $mailbox_grid->RowIndex . "_msgtype") ?>
</span>
<?php } else { ?>
<span id="el$rowindex$_mailbox_msgtype" class="form-group mailbox_msgtype">
<span<?php echo $mailbox_grid->msgtype->viewAttributes() ?>><input type="text" readonly class="form-control-plaintext" value="<?php echo HtmlEncode(RemoveHtml($mailbox_grid->msgtype->ViewValue)) ?>"></span>
</span>
<input type="hidden" data-table="mailbox" data-field="x_msgtype" name="x<?php echo $mailbox_grid->RowIndex ?>_msgtype" id="x<?php echo $mailbox_grid->RowIndex ?>_msgtype" value="<?php echo HtmlEncode($mailbox_grid->msgtype->FormValue) ?>">
<?php } ?>
<input type="hidden" data-table="mailbox" data-field="x_msgtype" name="o<?php echo $mailbox_grid->RowIndex ?>_msgtype" id="o<?php echo $mailbox_grid->RowIndex ?>_msgtype" value="<?php echo HtmlEncode($mailbox_grid->msgtype->OldValue) ?>">
</td>
	<?php } ?>
	<?php if ($mailbox_grid->msgcontent->Visible) { // msgcontent ?>
		<td data-name="msgcontent">
<?php if (!$mailbox->isConfirm()) { ?>
<span id="el$rowindex$_mailbox_msgcontent" class="form-group mailbox_msgcontent">
<input type="text" data-table="mailbox" data-field="x_msgcontent" name="x<?php echo $mailbox_grid->RowIndex ?>_msgcontent" id="x<?php echo $mailbox_grid->RowIndex ?>_msgcontent" size="30" maxlength="200" placeholder="<?php echo HtmlEncode($mailbox_grid->msgcontent->getPlaceHolder()) ?>" value="<?php echo $mailbox_grid->msgcontent->EditValue ?>"<?php echo $mailbox_grid->msgcontent->editAttributes() ?>>
</span>
<?php } else { ?>
<span id="el$rowindex$_mailbox_msgcontent" class="form-group mailbox_msgcontent">
<span<?php echo $mailbox_grid->msgcontent->viewAttributes() ?>><input type="text" readonly class="form-control-plaintext" value="<?php echo HtmlEncode(RemoveHtml($mailbox_grid->msgcontent->ViewValue)) ?>"></span>
</span>
<input type="hidden" data-table="mailbox" data-field="x_msgcontent" name="x<?php echo $mailbox_grid->RowIndex ?>_msgcontent" id="x<?php echo $mailbox_grid->RowIndex ?>_msgcontent" value="<?php echo HtmlEncode($mailbox_grid->msgcontent->FormValue) ?>">
<?php } ?>
<input type="hidden" data-table="mailbox" data-field="x_msgcontent" name="o<?php echo $mailbox_grid->RowIndex ?>_msgcontent" id="o<?php echo $mailbox_grid->RowIndex ?>_msgcontent" value="<?php echo HtmlEncode($mailbox_grid->msgcontent->OldValue) ?>">
</td>
	<?php } ?>
	<?php if ($mailbox_grid->msgread->Visible) { // msgread ?>
		<td data-name="msgread">
<?php if (!$mailbox->isConfirm()) { ?>
<span id="el$rowindex$_mailbox_msgread" class="form-group mailbox_msgread">
<div id="tp_x<?php echo $mailbox_grid->RowIndex ?>_msgread" class="ew-template"><input type="radio" class="custom-control-input" data-table="mailbox" data-field="x_msgread" data-value-separator="<?php echo $mailbox_grid->msgread->displayValueSeparatorAttribute() ?>" name="x<?php echo $mailbox_grid->RowIndex ?>_msgread" id="x<?php echo $mailbox_grid->RowIndex ?>_msgread" value="{value}"<?php echo $mailbox_grid->msgread->editAttributes() ?>></div>
<div id="dsl_x<?php echo $mailbox_grid->RowIndex ?>_msgread" data-repeatcolumn="5" class="ew-item-list d-none"><div>
<?php echo $mailbox_grid->msgread->radioButtonListHtml(FALSE, "x{$mailbox_grid->RowIndex}_msgread") ?>
</div></div>
<?php echo $mailbox_grid->msgread->Lookup->getParamTag($mailbox_grid, "p_x" . $mailbox_grid->RowIndex . "_msgread") ?>
</span>
<?php } else { ?>
<span id="el$rowindex$_mailbox_msgread" class="form-group mailbox_msgread">
<span<?php echo $mailbox_grid->msgread->viewAttributes() ?>><input type="text" readonly class="form-control-plaintext" value="<?php echo HtmlEncode(RemoveHtml($mailbox_grid->msgread->ViewValue)) ?>"></span>
</span>
<input type="hidden" data-table="mailbox" data-field="x_msgread" name="x<?php echo $mailbox_grid->RowIndex ?>_msgread" id="x<?php echo $mailbox_grid->RowIndex ?>_msgread" value="<?php echo HtmlEncode($mailbox_grid->msgread->FormValue) ?>">
<?php } ?>
<input type="hidden" data-table="mailbox" data-field="x_msgread" name="o<?php echo $mailbox_grid->RowIndex ?>_msgread" id="o<?php echo $mailbox_grid->RowIndex ?>_msgread" value="<?php echo HtmlEncode($mailbox_grid->msgread->OldValue) ?>">
</td>
	<?php } ?>
	<?php if ($mailbox_grid->msgtime->Visible) { // msgtime ?>
		<td data-name="msgtime">
<?php if (!$mailbox->isConfirm()) { ?>
<span id="el$rowindex$_mailbox_msgtime" class="form-group mailbox_msgtime">
<input type="text" data-table="mailbox" data-field="x_msgtime" data-format="1" name="x<?php echo $mailbox_grid->RowIndex ?>_msgtime" id="x<?php echo $mailbox_grid->RowIndex ?>_msgtime" placeholder="<?php echo HtmlEncode($mailbox_grid->msgtime->getPlaceHolder()) ?>" value="<?php echo $mailbox_grid->msgtime->EditValue ?>"<?php echo $mailbox_grid->msgtime->editAttributes() ?>>
</span>
<?php } else { ?>
<span id="el$rowindex$_mailbox_msgtime" class="form-group mailbox_msgtime">
<span<?php echo $mailbox_grid->msgtime->viewAttributes() ?>><input type="text" readonly class="form-control-plaintext" value="<?php echo HtmlEncode(RemoveHtml($mailbox_grid->msgtime->ViewValue)) ?>"></span>
</span>
<input type="hidden" data-table="mailbox" data-field="x_msgtime" name="x<?php echo $mailbox_grid->RowIndex ?>_msgtime" id="x<?php echo $mailbox_grid->RowIndex ?>_msgtime" value="<?php echo HtmlEncode($mailbox_grid->msgtime->FormValue) ?>">
<?php } ?>
<input type="hidden" data-table="mailbox" data-field="x_msgtime" name="o<?php echo $mailbox_grid->RowIndex ?>_msgtime" id="o<?php echo $mailbox_grid->RowIndex ?>_msgtime" value="<?php echo HtmlEncode($mailbox_grid->msgtime->OldValue) ?>">
</td>
	<?php } ?>
	<?php if ($mailbox_grid->datavalue->Visible) { // datavalue ?>
		<td data-name="datavalue">
<?php if (!$mailbox->isConfirm()) { ?>
<span id="el$rowindex$_mailbox_datavalue" class="form-group mailbox_datavalue">
<input type="text" data-table="mailbox" data-field="x_datavalue" name="x<?php echo $mailbox_grid->RowIndex ?>_datavalue" id="x<?php echo $mailbox_grid->RowIndex ?>_datavalue" size="30" maxlength="50" placeholder="<?php echo HtmlEncode($mailbox_grid->datavalue->getPlaceHolder()) ?>" value="<?php echo $mailbox_grid->datavalue->EditValue ?>"<?php echo $mailbox_grid->datavalue->editAttributes() ?>>
</span>
<?php } else { ?>
<span id="el$rowindex$_mailbox_datavalue" class="form-group mailbox_datavalue">
<span<?php echo $mailbox_grid->datavalue->viewAttributes() ?>><input type="text" readonly class="form-control-plaintext" value="<?php echo HtmlEncode(RemoveHtml($mailbox_grid->datavalue->ViewValue)) ?>"></span>
</span>
<input type="hidden" data-table="mailbox" data-field="x_datavalue" name="x<?php echo $mailbox_grid->RowIndex ?>_datavalue" id="x<?php echo $mailbox_grid->RowIndex ?>_datavalue" value="<?php echo HtmlEncode($mailbox_grid->datavalue->FormValue) ?>">
<?php } ?>
<input type="hidden" data-table="mailbox" data-field="x_datavalue" name="o<?php echo $mailbox_grid->RowIndex ?>_datavalue" id="o<?php echo $mailbox_grid->RowIndex ?>_datavalue" value="<?php echo HtmlEncode($mailbox_grid->datavalue->OldValue) ?>">
</td>
	<?php } ?>
	<?php if ($mailbox_grid->version->Visible) { // version ?>
		<td data-name="version">
<?php if (!$mailbox->isConfirm()) { ?>
<span id="el$rowindex$_mailbox_version" class="form-group mailbox_version">
<input type="text" data-table="mailbox" data-field="x_version" name="x<?php echo $mailbox_grid->RowIndex ?>_version" id="x<?php echo $mailbox_grid->RowIndex ?>_version" size="30" maxlength="1" placeholder="<?php echo HtmlEncode($mailbox_grid->version->getPlaceHolder()) ?>" value="<?php echo $mailbox_grid->version->EditValue ?>"<?php echo $mailbox_grid->version->editAttributes() ?>>
</span>
<?php } else { ?>
<span id="el$rowindex$_mailbox_version" class="form-group mailbox_version">
<span<?php echo $mailbox_grid->version->viewAttributes() ?>><input type="text" readonly class="form-control-plaintext" value="<?php echo HtmlEncode(RemoveHtml($mailbox_grid->version->ViewValue)) ?>"></span>
</span>
<input type="hidden" data-table="mailbox" data-field="x_version" name="x<?php echo $mailbox_grid->RowIndex ?>_version" id="x<?php echo $mailbox_grid->RowIndex ?>_version" value="<?php echo HtmlEncode($mailbox_grid->version->FormValue) ?>">
<?php } ?>
<input type="hidden" data-table="mailbox" data-field="x_version" name="o<?php echo $mailbox_grid->RowIndex ?>_version" id="o<?php echo $mailbox_grid->RowIndex ?>_version" value="<?php echo HtmlEncode($mailbox_grid->version->OldValue) ?>">
</td>
	<?php } ?>
	<?php if ($mailbox_grid->delimeter->Visible) { // delimeter ?>
		<td data-name="delimeter">
<?php if (!$mailbox->isConfirm()) { ?>
<span id="el$rowindex$_mailbox_delimeter" class="form-group mailbox_delimeter">
<input type="text" data-table="mailbox" data-field="x_delimeter" name="x<?php echo $mailbox_grid->RowIndex ?>_delimeter" id="x<?php echo $mailbox_grid->RowIndex ?>_delimeter" size="30" maxlength="3" placeholder="<?php echo HtmlEncode($mailbox_grid->delimeter->getPlaceHolder()) ?>" value="<?php echo $mailbox_grid->delimeter->EditValue ?>"<?php echo $mailbox_grid->delimeter->editAttributes() ?>>
</span>
<?php } else { ?>
<span id="el$rowindex$_mailbox_delimeter" class="form-group mailbox_delimeter">
<span<?php echo $mailbox_grid->delimeter->viewAttributes() ?>><input type="text" readonly class="form-control-plaintext" value="<?php echo HtmlEncode(RemoveHtml($mailbox_grid->delimeter->ViewValue)) ?>"></span>
</span>
<input type="hidden" data-table="mailbox" data-field="x_delimeter" name="x<?php echo $mailbox_grid->RowIndex ?>_delimeter" id="x<?php echo $mailbox_grid->RowIndex ?>_delimeter" value="<?php echo HtmlEncode($mailbox_grid->delimeter->FormValue) ?>">
<?php } ?>
<input type="hidden" data-table="mailbox" data-field="x_delimeter" name="o<?php echo $mailbox_grid->RowIndex ?>_delimeter" id="o<?php echo $mailbox_grid->RowIndex ?>_delimeter" value="<?php echo HtmlEncode($mailbox_grid->delimeter->OldValue) ?>">
</td>
	<?php } ?>
<?php

// Render list options (body, right)
$mailbox_grid->ListOptions->render("body", "right", $mailbox_grid->RowIndex);
?>
<script>
loadjs.ready(["fmailboxgrid", "load"], function() {
	fmailboxgrid.updateLists(<?php echo $mailbox_grid->RowIndex ?>);
});
</script>
	</tr>
<?php
	}
?>
</tbody>
</table><!-- /.ew-table -->
</div><!-- /.ew-grid-middle-panel -->
<?php if ($mailbox->CurrentMode == "add" || $mailbox->CurrentMode == "copy") { ?>
<input type="hidden" name="<?php echo $mailbox_grid->FormKeyCountName ?>" id="<?php echo $mailbox_grid->FormKeyCountName ?>" value="<?php echo $mailbox_grid->KeyCount ?>">
<?php echo $mailbox_grid->MultiSelectKey ?>
<?php } ?>
<?php if ($mailbox->CurrentMode == "edit") { ?>
<input type="hidden" name="<?php echo $mailbox_grid->FormKeyCountName ?>" id="<?php echo $mailbox_grid->FormKeyCountName ?>" value="<?php echo $mailbox_grid->KeyCount ?>">
<?php echo $mailbox_grid->MultiSelectKey ?>
<?php } ?>
<?php if ($mailbox->CurrentMode == "") { ?>
<input type="hidden" name="action" id="action" value="">
<?php } ?>
<input type="hidden" name="detailpage" value="fmailboxgrid">
</div><!-- /.ew-list-form -->
<?php

// Close recordset
if ($mailbox_grid->Recordset)
	$mailbox_grid->Recordset->Close();
?>
<?php if ($mailbox_grid->ShowOtherOptions) { ?>
<div class="card-footer ew-grid-lower-panel">
<?php $mailbox_grid->OtherOptions->render("body", "bottom") ?>
</div>
<div class="clearfix"></div>
<?php } ?>
</div><!-- /.ew-grid -->
<?php } ?>
<?php if ($mailbox_grid->TotalRecords == 0 && !$mailbox->CurrentAction) { // Show other options ?>
<div class="ew-list-other-options">
<?php $mailbox_grid->OtherOptions->render("body") ?>
</div>
<div class="clearfix"></div>
<?php } ?>
<?php if (!$mailbox_grid->isExport()) { ?>
<script>
loadjs.ready("load", function() {

	// Startup script
	// Write your table-specific startup script here
	// console.log("page loaded");

});
</script>
<?php } ?>
<?php
$mailbox_grid->terminate();
?>