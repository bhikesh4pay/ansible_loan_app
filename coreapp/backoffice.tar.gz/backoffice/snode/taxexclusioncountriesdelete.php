<?php
namespace PHPMaker2020\_4payadmin;

// Autoload
include_once "autoload.php";

// Session
if (session_status() !== PHP_SESSION_ACTIVE)
	\Delight\Cookie\Session::start(Config("COOKIE_SAMESITE")); // Init session data

// Output buffering
ob_start();
?>
<?php

// Write header
WriteHeader(FALSE);

// Create page object
$taxexclusioncountries_delete = new taxexclusioncountries_delete();

// Run the page
$taxexclusioncountries_delete->run();

// Setup login status
SetupLoginStatus();
SetClientVar("login", LoginStatus());

// Global Page Rendering event (in userfn*.php)
Page_Rendering();

// Page Rendering event
$taxexclusioncountries_delete->Page_Render();
?>
<?php include_once "header.php"; ?>
<script>
var ftaxexclusioncountriesdelete, currentPageID;
loadjs.ready("head", function() {

	// Form object
	currentPageID = ew.PAGE_ID = "delete";
	ftaxexclusioncountriesdelete = currentForm = new ew.Form("ftaxexclusioncountriesdelete", "delete");
	loadjs.done("ftaxexclusioncountriesdelete");
});
</script>
<script>
loadjs.ready("head", function() {

	// Client script
	// Write your client script here, no need to add script tags.

});
</script>
<?php $taxexclusioncountries_delete->showPageHeader(); ?>
<?php
$taxexclusioncountries_delete->showMessage();
?>
<form name="ftaxexclusioncountriesdelete" id="ftaxexclusioncountriesdelete" class="form-inline ew-form ew-delete-form" action="<?php echo CurrentPageName() ?>" method="post">
<?php if ($Page->CheckToken) { ?>
<input type="hidden" name="<?php echo Config("TOKEN_NAME") ?>" value="<?php echo $Page->Token ?>">
<?php } ?>
<input type="hidden" name="t" value="taxexclusioncountries">
<input type="hidden" name="action" id="action" value="delete">
<?php foreach ($taxexclusioncountries_delete->RecKeys as $key) { ?>
<?php $keyvalue = is_array($key) ? implode(Config("COMPOSITE_KEY_SEPARATOR"), $key) : $key; ?>
<input type="hidden" name="key_m[]" value="<?php echo HtmlEncode($keyvalue) ?>">
<?php } ?>
<div class="card ew-card ew-grid">
<div class="<?php echo ResponsiveTableClass() ?>card-body ew-grid-middle-panel">
<table class="table ew-table">
	<thead>
	<tr class="ew-table-header">
<?php if ($taxexclusioncountries_delete->taxcodeid->Visible) { // taxcodeid ?>
		<th class="<?php echo $taxexclusioncountries_delete->taxcodeid->headerCellClass() ?>"><span id="elh_taxexclusioncountries_taxcodeid" class="taxexclusioncountries_taxcodeid"><?php echo $taxexclusioncountries_delete->taxcodeid->caption() ?></span></th>
<?php } ?>
<?php if ($taxexclusioncountries_delete->countryid->Visible) { // countryid ?>
		<th class="<?php echo $taxexclusioncountries_delete->countryid->headerCellClass() ?>"><span id="elh_taxexclusioncountries_countryid" class="taxexclusioncountries_countryid"><?php echo $taxexclusioncountries_delete->countryid->caption() ?></span></th>
<?php } ?>
	</tr>
	</thead>
	<tbody>
<?php
$taxexclusioncountries_delete->RecordCount = 0;
$i = 0;
while (!$taxexclusioncountries_delete->Recordset->EOF) {
	$taxexclusioncountries_delete->RecordCount++;
	$taxexclusioncountries_delete->RowCount++;

	// Set row properties
	$taxexclusioncountries->resetAttributes();
	$taxexclusioncountries->RowType = ROWTYPE_VIEW; // View

	// Get the field contents
	$taxexclusioncountries_delete->loadRowValues($taxexclusioncountries_delete->Recordset);

	// Render row
	$taxexclusioncountries_delete->renderRow();
?>
	<tr <?php echo $taxexclusioncountries->rowAttributes() ?>>
<?php if ($taxexclusioncountries_delete->taxcodeid->Visible) { // taxcodeid ?>
		<td <?php echo $taxexclusioncountries_delete->taxcodeid->cellAttributes() ?>>
<span id="el<?php echo $taxexclusioncountries_delete->RowCount ?>_taxexclusioncountries_taxcodeid" class="taxexclusioncountries_taxcodeid">
<span<?php echo $taxexclusioncountries_delete->taxcodeid->viewAttributes() ?>><?php echo $taxexclusioncountries_delete->taxcodeid->getViewValue() ?></span>
</span>
</td>
<?php } ?>
<?php if ($taxexclusioncountries_delete->countryid->Visible) { // countryid ?>
		<td <?php echo $taxexclusioncountries_delete->countryid->cellAttributes() ?>>
<span id="el<?php echo $taxexclusioncountries_delete->RowCount ?>_taxexclusioncountries_countryid" class="taxexclusioncountries_countryid">
<span<?php echo $taxexclusioncountries_delete->countryid->viewAttributes() ?>><?php echo $taxexclusioncountries_delete->countryid->getViewValue() ?></span>
</span>
</td>
<?php } ?>
	</tr>
<?php
	$taxexclusioncountries_delete->Recordset->moveNext();
}
$taxexclusioncountries_delete->Recordset->close();
?>
</tbody>
</table>
</div>
</div>
<div>
<button class="btn btn-primary ew-btn" name="btn-action" id="btn-action" type="submit"><?php echo $Language->phrase("DeleteBtn") ?></button>
<button class="btn btn-default ew-btn" name="btn-cancel" id="btn-cancel" type="button" data-href="<?php echo $taxexclusioncountries_delete->getReturnUrl() ?>"><?php echo $Language->phrase("CancelBtn") ?></button>
</div>
</form>
<?php
$taxexclusioncountries_delete->showPageFooter();
if (Config("DEBUG"))
	echo GetDebugMessage();
?>
<script>
loadjs.ready("load", function() {

	// Startup script
	// Write your table-specific startup script here
	// console.log("page loaded");

});
</script>
<?php include_once "footer.php"; ?>
<?php
$taxexclusioncountries_delete->terminate();
?>