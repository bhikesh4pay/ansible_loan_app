<?php
namespace PHPMaker2020\_4payadmin;

// Write header
WriteHeader(FALSE);

// Create page object
if (!isset($loanappliedcancelled_grid))
	$loanappliedcancelled_grid = new loanappliedcancelled_grid();

// Run the page
$loanappliedcancelled_grid->run();

// Setup login status
SetupLoginStatus();
SetClientVar("login", LoginStatus());

// Global Page Rendering event (in userfn*.php)
Page_Rendering();

// Page Rendering event
$loanappliedcancelled_grid->Page_Render();
?>
<?php if (!$loanappliedcancelled_grid->isExport()) { ?>
<script>
var floanappliedcancelledgrid, currentPageID;
loadjs.ready("head", function() {

	// Form object
	floanappliedcancelledgrid = new ew.Form("floanappliedcancelledgrid", "grid");
	floanappliedcancelledgrid.formKeyCountName = '<?php echo $loanappliedcancelled_grid->FormKeyCountName ?>';

	// Validate form
	floanappliedcancelledgrid.validate = function() {
		if (!this.validateRequired)
			return true; // Ignore validation
		var $ = jQuery, fobj = this.getForm(), $fobj = $(fobj);
		if ($fobj.find("#confirm").val() == "confirm")
			return true;
		var elm, felm, uelm, addcnt = 0;
		var $k = $fobj.find("#" + this.formKeyCountName); // Get key_count
		var rowcnt = ($k[0]) ? parseInt($k.val(), 10) : 1;
		var startcnt = (rowcnt == 0) ? 0 : 1; // Check rowcnt == 0 => Inline-Add
		var gridinsert = ["insert", "gridinsert"].includes($fobj.find("#action").val()) && $k[0];
		for (var i = startcnt; i <= rowcnt; i++) {
			var infix = ($k[0]) ? String(i) : "";
			$fobj.data("rowindex", infix);
			var checkrow = (gridinsert) ? !this.emptyRow(infix) : true;
			if (checkrow) {
				addcnt++;
			<?php if ($loanappliedcancelled_grid->applyid->Required) { ?>
				elm = this.getElements("x" + infix + "_applyid");
				if (elm && !ew.isHidden(elm) && !ew.hasValue(elm))
					return this.onError(elm, "<?php echo JsEncode(str_replace("%s", $loanappliedcancelled_grid->applyid->caption(), $loanappliedcancelled_grid->applyid->RequiredErrorMessage)) ?>");
			<?php } ?>
				elm = this.getElements("x" + infix + "_applyid");
				if (elm && !ew.checkInteger(elm.value))
					return this.onError(elm, "<?php echo JsEncode($loanappliedcancelled_grid->applyid->errorMessage()) ?>");
			<?php if ($loanappliedcancelled_grid->loanid->Required) { ?>
				elm = this.getElements("x" + infix + "_loanid");
				if (elm && !ew.isHidden(elm) && !ew.hasValue(elm))
					return this.onError(elm, "<?php echo JsEncode(str_replace("%s", $loanappliedcancelled_grid->loanid->caption(), $loanappliedcancelled_grid->loanid->RequiredErrorMessage)) ?>");
			<?php } ?>
				elm = this.getElements("x" + infix + "_loanid");
				if (elm && !ew.checkInteger(elm.value))
					return this.onError(elm, "<?php echo JsEncode($loanappliedcancelled_grid->loanid->errorMessage()) ?>");
			<?php if ($loanappliedcancelled_grid->paymentid->Required) { ?>
				elm = this.getElements("x" + infix + "_paymentid");
				if (elm && !ew.isHidden(elm) && !ew.hasValue(elm))
					return this.onError(elm, "<?php echo JsEncode(str_replace("%s", $loanappliedcancelled_grid->paymentid->caption(), $loanappliedcancelled_grid->paymentid->RequiredErrorMessage)) ?>");
			<?php } ?>
				elm = this.getElements("x" + infix + "_paymentid");
				if (elm && !ew.checkInteger(elm.value))
					return this.onError(elm, "<?php echo JsEncode($loanappliedcancelled_grid->paymentid->errorMessage()) ?>");
			<?php if ($loanappliedcancelled_grid->amountapplied->Required) { ?>
				elm = this.getElements("x" + infix + "_amountapplied");
				if (elm && !ew.isHidden(elm) && !ew.hasValue(elm))
					return this.onError(elm, "<?php echo JsEncode(str_replace("%s", $loanappliedcancelled_grid->amountapplied->caption(), $loanappliedcancelled_grid->amountapplied->RequiredErrorMessage)) ?>");
			<?php } ?>
				elm = this.getElements("x" + infix + "_amountapplied");
				if (elm && !ew.checkNumber(elm.value))
					return this.onError(elm, "<?php echo JsEncode($loanappliedcancelled_grid->amountapplied->errorMessage()) ?>");
			<?php if ($loanappliedcancelled_grid->feesapplied->Required) { ?>
				elm = this.getElements("x" + infix + "_feesapplied");
				if (elm && !ew.isHidden(elm) && !ew.hasValue(elm))
					return this.onError(elm, "<?php echo JsEncode(str_replace("%s", $loanappliedcancelled_grid->feesapplied->caption(), $loanappliedcancelled_grid->feesapplied->RequiredErrorMessage)) ?>");
			<?php } ?>
				elm = this.getElements("x" + infix + "_feesapplied");
				if (elm && !ew.checkNumber(elm.value))
					return this.onError(elm, "<?php echo JsEncode($loanappliedcancelled_grid->feesapplied->errorMessage()) ?>");
			<?php if ($loanappliedcancelled_grid->totalamountapplied->Required) { ?>
				elm = this.getElements("x" + infix + "_totalamountapplied");
				if (elm && !ew.isHidden(elm) && !ew.hasValue(elm))
					return this.onError(elm, "<?php echo JsEncode(str_replace("%s", $loanappliedcancelled_grid->totalamountapplied->caption(), $loanappliedcancelled_grid->totalamountapplied->RequiredErrorMessage)) ?>");
			<?php } ?>
				elm = this.getElements("x" + infix + "_totalamountapplied");
				if (elm && !ew.checkNumber(elm.value))
					return this.onError(elm, "<?php echo JsEncode($loanappliedcancelled_grid->totalamountapplied->errorMessage()) ?>");
			<?php if ($loanappliedcancelled_grid->taxamountbreakdown->Required) { ?>
				elm = this.getElements("x" + infix + "_taxamountbreakdown");
				if (elm && !ew.isHidden(elm) && !ew.hasValue(elm))
					return this.onError(elm, "<?php echo JsEncode(str_replace("%s", $loanappliedcancelled_grid->taxamountbreakdown->caption(), $loanappliedcancelled_grid->taxamountbreakdown->RequiredErrorMessage)) ?>");
			<?php } ?>
				elm = this.getElements("x" + infix + "_taxamountbreakdown");
				if (elm && !ew.checkNumber(elm.value))
					return this.onError(elm, "<?php echo JsEncode($loanappliedcancelled_grid->taxamountbreakdown->errorMessage()) ?>");
			<?php if ($loanappliedcancelled_grid->feesystembreakdown->Required) { ?>
				elm = this.getElements("x" + infix + "_feesystembreakdown");
				if (elm && !ew.isHidden(elm) && !ew.hasValue(elm))
					return this.onError(elm, "<?php echo JsEncode(str_replace("%s", $loanappliedcancelled_grid->feesystembreakdown->caption(), $loanappliedcancelled_grid->feesystembreakdown->RequiredErrorMessage)) ?>");
			<?php } ?>
				elm = this.getElements("x" + infix + "_feesystembreakdown");
				if (elm && !ew.checkNumber(elm.value))
					return this.onError(elm, "<?php echo JsEncode($loanappliedcancelled_grid->feesystembreakdown->errorMessage()) ?>");
			<?php if ($loanappliedcancelled_grid->feeexternalbreakdown->Required) { ?>
				elm = this.getElements("x" + infix + "_feeexternalbreakdown");
				if (elm && !ew.isHidden(elm) && !ew.hasValue(elm))
					return this.onError(elm, "<?php echo JsEncode(str_replace("%s", $loanappliedcancelled_grid->feeexternalbreakdown->caption(), $loanappliedcancelled_grid->feeexternalbreakdown->RequiredErrorMessage)) ?>");
			<?php } ?>
				elm = this.getElements("x" + infix + "_feeexternalbreakdown");
				if (elm && !ew.checkNumber(elm.value))
					return this.onError(elm, "<?php echo JsEncode($loanappliedcancelled_grid->feeexternalbreakdown->errorMessage()) ?>");
			<?php if ($loanappliedcancelled_grid->feefranchiseebreakdown->Required) { ?>
				elm = this.getElements("x" + infix + "_feefranchiseebreakdown");
				if (elm && !ew.isHidden(elm) && !ew.hasValue(elm))
					return this.onError(elm, "<?php echo JsEncode(str_replace("%s", $loanappliedcancelled_grid->feefranchiseebreakdown->caption(), $loanappliedcancelled_grid->feefranchiseebreakdown->RequiredErrorMessage)) ?>");
			<?php } ?>
				elm = this.getElements("x" + infix + "_feefranchiseebreakdown");
				if (elm && !ew.checkNumber(elm.value))
					return this.onError(elm, "<?php echo JsEncode($loanappliedcancelled_grid->feefranchiseebreakdown->errorMessage()) ?>");
			<?php if ($loanappliedcancelled_grid->feeresellerbreakdown->Required) { ?>
				elm = this.getElements("x" + infix + "_feeresellerbreakdown");
				if (elm && !ew.isHidden(elm) && !ew.hasValue(elm))
					return this.onError(elm, "<?php echo JsEncode(str_replace("%s", $loanappliedcancelled_grid->feeresellerbreakdown->caption(), $loanappliedcancelled_grid->feeresellerbreakdown->RequiredErrorMessage)) ?>");
			<?php } ?>
				elm = this.getElements("x" + infix + "_feeresellerbreakdown");
				if (elm && !ew.checkNumber(elm.value))
					return this.onError(elm, "<?php echo JsEncode($loanappliedcancelled_grid->feeresellerbreakdown->errorMessage()) ?>");
			<?php if ($loanappliedcancelled_grid->cancellationtime->Required) { ?>
				elm = this.getElements("x" + infix + "_cancellationtime");
				if (elm && !ew.isHidden(elm) && !ew.hasValue(elm))
					return this.onError(elm, "<?php echo JsEncode(str_replace("%s", $loanappliedcancelled_grid->cancellationtime->caption(), $loanappliedcancelled_grid->cancellationtime->RequiredErrorMessage)) ?>");
			<?php } ?>
				elm = this.getElements("x" + infix + "_cancellationtime");
				if (elm && !ew.checkDateDef(elm.value))
					return this.onError(elm, "<?php echo JsEncode($loanappliedcancelled_grid->cancellationtime->errorMessage()) ?>");
			<?php if ($loanappliedcancelled_grid->cancellationrefno->Required) { ?>
				elm = this.getElements("x" + infix + "_cancellationrefno");
				if (elm && !ew.isHidden(elm) && !ew.hasValue(elm))
					return this.onError(elm, "<?php echo JsEncode(str_replace("%s", $loanappliedcancelled_grid->cancellationrefno->caption(), $loanappliedcancelled_grid->cancellationrefno->RequiredErrorMessage)) ?>");
			<?php } ?>

				// Call Form_CustomValidate event
				if (!this.Form_CustomValidate(fobj))
					return false;
			} // End Grid Add checking
		}
		return true;
	}

	// Check empty row
	floanappliedcancelledgrid.emptyRow = function(infix) {
		var fobj = this._form;
		if (ew.valueChanged(fobj, infix, "applyid", false)) return false;
		if (ew.valueChanged(fobj, infix, "loanid", false)) return false;
		if (ew.valueChanged(fobj, infix, "paymentid", false)) return false;
		if (ew.valueChanged(fobj, infix, "amountapplied", false)) return false;
		if (ew.valueChanged(fobj, infix, "feesapplied", false)) return false;
		if (ew.valueChanged(fobj, infix, "totalamountapplied", false)) return false;
		if (ew.valueChanged(fobj, infix, "taxamountbreakdown", false)) return false;
		if (ew.valueChanged(fobj, infix, "feesystembreakdown", false)) return false;
		if (ew.valueChanged(fobj, infix, "feeexternalbreakdown", false)) return false;
		if (ew.valueChanged(fobj, infix, "feefranchiseebreakdown", false)) return false;
		if (ew.valueChanged(fobj, infix, "feeresellerbreakdown", false)) return false;
		if (ew.valueChanged(fobj, infix, "cancellationtime", false)) return false;
		if (ew.valueChanged(fobj, infix, "cancellationrefno", false)) return false;
		return true;
	}

	// Form_CustomValidate
	floanappliedcancelledgrid.Form_CustomValidate = function(fobj) { // DO NOT CHANGE THIS LINE!

		// Your custom validation code here, return false if invalid.
		return true;
	}

	// Use JavaScript validation or not
	floanappliedcancelledgrid.validateRequired = <?php echo Config("CLIENT_VALIDATE") ? "true" : "false" ?>;

	// Dynamic selection lists
	loadjs.done("floanappliedcancelledgrid");
});
</script>
<?php } ?>
<?php
$loanappliedcancelled_grid->renderOtherOptions();
?>
<?php if ($loanappliedcancelled_grid->TotalRecords > 0 || $loanappliedcancelled->CurrentAction) { ?>
<div class="card ew-card ew-grid<?php if ($loanappliedcancelled_grid->isAddOrEdit()) { ?> ew-grid-add-edit<?php } ?> loanappliedcancelled">
<div id="floanappliedcancelledgrid" class="ew-form ew-list-form form-inline">
<div id="gmp_loanappliedcancelled" class="<?php echo ResponsiveTableClass() ?>card-body ew-grid-middle-panel">
<table id="tbl_loanappliedcancelledgrid" class="table ew-table"><!-- .ew-table -->
<thead>
	<tr class="ew-table-header">
<?php

// Header row
$loanappliedcancelled->RowType = ROWTYPE_HEADER;

// Render list options
$loanappliedcancelled_grid->renderListOptions();

// Render list options (header, left)
$loanappliedcancelled_grid->ListOptions->render("header", "left");
?>
<?php if ($loanappliedcancelled_grid->applyid->Visible) { // applyid ?>
	<?php if ($loanappliedcancelled_grid->SortUrl($loanappliedcancelled_grid->applyid) == "") { ?>
		<th data-name="applyid" class="<?php echo $loanappliedcancelled_grid->applyid->headerCellClass() ?>"><div id="elh_loanappliedcancelled_applyid" class="loanappliedcancelled_applyid"><div class="ew-table-header-caption"><?php echo $loanappliedcancelled_grid->applyid->caption() ?></div></div></th>
	<?php } else { ?>
		<th data-name="applyid" class="<?php echo $loanappliedcancelled_grid->applyid->headerCellClass() ?>"><div><div id="elh_loanappliedcancelled_applyid" class="loanappliedcancelled_applyid">
			<div class="ew-table-header-btn"><span class="ew-table-header-caption"><?php echo $loanappliedcancelled_grid->applyid->caption() ?></span><span class="ew-table-header-sort"><?php if ($loanappliedcancelled_grid->applyid->getSort() == "ASC") { ?><i class="fas fa-sort-up"></i><?php } elseif ($loanappliedcancelled_grid->applyid->getSort() == "DESC") { ?><i class="fas fa-sort-down"></i><?php } ?></span></div>
		</div></div></th>
	<?php } ?>
<?php } ?>
<?php if ($loanappliedcancelled_grid->loanid->Visible) { // loanid ?>
	<?php if ($loanappliedcancelled_grid->SortUrl($loanappliedcancelled_grid->loanid) == "") { ?>
		<th data-name="loanid" class="<?php echo $loanappliedcancelled_grid->loanid->headerCellClass() ?>"><div id="elh_loanappliedcancelled_loanid" class="loanappliedcancelled_loanid"><div class="ew-table-header-caption"><?php echo $loanappliedcancelled_grid->loanid->caption() ?></div></div></th>
	<?php } else { ?>
		<th data-name="loanid" class="<?php echo $loanappliedcancelled_grid->loanid->headerCellClass() ?>"><div><div id="elh_loanappliedcancelled_loanid" class="loanappliedcancelled_loanid">
			<div class="ew-table-header-btn"><span class="ew-table-header-caption"><?php echo $loanappliedcancelled_grid->loanid->caption() ?></span><span class="ew-table-header-sort"><?php if ($loanappliedcancelled_grid->loanid->getSort() == "ASC") { ?><i class="fas fa-sort-up"></i><?php } elseif ($loanappliedcancelled_grid->loanid->getSort() == "DESC") { ?><i class="fas fa-sort-down"></i><?php } ?></span></div>
		</div></div></th>
	<?php } ?>
<?php } ?>
<?php if ($loanappliedcancelled_grid->paymentid->Visible) { // paymentid ?>
	<?php if ($loanappliedcancelled_grid->SortUrl($loanappliedcancelled_grid->paymentid) == "") { ?>
		<th data-name="paymentid" class="<?php echo $loanappliedcancelled_grid->paymentid->headerCellClass() ?>"><div id="elh_loanappliedcancelled_paymentid" class="loanappliedcancelled_paymentid"><div class="ew-table-header-caption"><?php echo $loanappliedcancelled_grid->paymentid->caption() ?></div></div></th>
	<?php } else { ?>
		<th data-name="paymentid" class="<?php echo $loanappliedcancelled_grid->paymentid->headerCellClass() ?>"><div><div id="elh_loanappliedcancelled_paymentid" class="loanappliedcancelled_paymentid">
			<div class="ew-table-header-btn"><span class="ew-table-header-caption"><?php echo $loanappliedcancelled_grid->paymentid->caption() ?></span><span class="ew-table-header-sort"><?php if ($loanappliedcancelled_grid->paymentid->getSort() == "ASC") { ?><i class="fas fa-sort-up"></i><?php } elseif ($loanappliedcancelled_grid->paymentid->getSort() == "DESC") { ?><i class="fas fa-sort-down"></i><?php } ?></span></div>
		</div></div></th>
	<?php } ?>
<?php } ?>
<?php if ($loanappliedcancelled_grid->amountapplied->Visible) { // amountapplied ?>
	<?php if ($loanappliedcancelled_grid->SortUrl($loanappliedcancelled_grid->amountapplied) == "") { ?>
		<th data-name="amountapplied" class="<?php echo $loanappliedcancelled_grid->amountapplied->headerCellClass() ?>"><div id="elh_loanappliedcancelled_amountapplied" class="loanappliedcancelled_amountapplied"><div class="ew-table-header-caption"><?php echo $loanappliedcancelled_grid->amountapplied->caption() ?></div></div></th>
	<?php } else { ?>
		<th data-name="amountapplied" class="<?php echo $loanappliedcancelled_grid->amountapplied->headerCellClass() ?>"><div><div id="elh_loanappliedcancelled_amountapplied" class="loanappliedcancelled_amountapplied">
			<div class="ew-table-header-btn"><span class="ew-table-header-caption"><?php echo $loanappliedcancelled_grid->amountapplied->caption() ?></span><span class="ew-table-header-sort"><?php if ($loanappliedcancelled_grid->amountapplied->getSort() == "ASC") { ?><i class="fas fa-sort-up"></i><?php } elseif ($loanappliedcancelled_grid->amountapplied->getSort() == "DESC") { ?><i class="fas fa-sort-down"></i><?php } ?></span></div>
		</div></div></th>
	<?php } ?>
<?php } ?>
<?php if ($loanappliedcancelled_grid->feesapplied->Visible) { // feesapplied ?>
	<?php if ($loanappliedcancelled_grid->SortUrl($loanappliedcancelled_grid->feesapplied) == "") { ?>
		<th data-name="feesapplied" class="<?php echo $loanappliedcancelled_grid->feesapplied->headerCellClass() ?>"><div id="elh_loanappliedcancelled_feesapplied" class="loanappliedcancelled_feesapplied"><div class="ew-table-header-caption"><?php echo $loanappliedcancelled_grid->feesapplied->caption() ?></div></div></th>
	<?php } else { ?>
		<th data-name="feesapplied" class="<?php echo $loanappliedcancelled_grid->feesapplied->headerCellClass() ?>"><div><div id="elh_loanappliedcancelled_feesapplied" class="loanappliedcancelled_feesapplied">
			<div class="ew-table-header-btn"><span class="ew-table-header-caption"><?php echo $loanappliedcancelled_grid->feesapplied->caption() ?></span><span class="ew-table-header-sort"><?php if ($loanappliedcancelled_grid->feesapplied->getSort() == "ASC") { ?><i class="fas fa-sort-up"></i><?php } elseif ($loanappliedcancelled_grid->feesapplied->getSort() == "DESC") { ?><i class="fas fa-sort-down"></i><?php } ?></span></div>
		</div></div></th>
	<?php } ?>
<?php } ?>
<?php if ($loanappliedcancelled_grid->totalamountapplied->Visible) { // totalamountapplied ?>
	<?php if ($loanappliedcancelled_grid->SortUrl($loanappliedcancelled_grid->totalamountapplied) == "") { ?>
		<th data-name="totalamountapplied" class="<?php echo $loanappliedcancelled_grid->totalamountapplied->headerCellClass() ?>"><div id="elh_loanappliedcancelled_totalamountapplied" class="loanappliedcancelled_totalamountapplied"><div class="ew-table-header-caption"><?php echo $loanappliedcancelled_grid->totalamountapplied->caption() ?></div></div></th>
	<?php } else { ?>
		<th data-name="totalamountapplied" class="<?php echo $loanappliedcancelled_grid->totalamountapplied->headerCellClass() ?>"><div><div id="elh_loanappliedcancelled_totalamountapplied" class="loanappliedcancelled_totalamountapplied">
			<div class="ew-table-header-btn"><span class="ew-table-header-caption"><?php echo $loanappliedcancelled_grid->totalamountapplied->caption() ?></span><span class="ew-table-header-sort"><?php if ($loanappliedcancelled_grid->totalamountapplied->getSort() == "ASC") { ?><i class="fas fa-sort-up"></i><?php } elseif ($loanappliedcancelled_grid->totalamountapplied->getSort() == "DESC") { ?><i class="fas fa-sort-down"></i><?php } ?></span></div>
		</div></div></th>
	<?php } ?>
<?php } ?>
<?php if ($loanappliedcancelled_grid->taxamountbreakdown->Visible) { // taxamountbreakdown ?>
	<?php if ($loanappliedcancelled_grid->SortUrl($loanappliedcancelled_grid->taxamountbreakdown) == "") { ?>
		<th data-name="taxamountbreakdown" class="<?php echo $loanappliedcancelled_grid->taxamountbreakdown->headerCellClass() ?>"><div id="elh_loanappliedcancelled_taxamountbreakdown" class="loanappliedcancelled_taxamountbreakdown"><div class="ew-table-header-caption"><?php echo $loanappliedcancelled_grid->taxamountbreakdown->caption() ?></div></div></th>
	<?php } else { ?>
		<th data-name="taxamountbreakdown" class="<?php echo $loanappliedcancelled_grid->taxamountbreakdown->headerCellClass() ?>"><div><div id="elh_loanappliedcancelled_taxamountbreakdown" class="loanappliedcancelled_taxamountbreakdown">
			<div class="ew-table-header-btn"><span class="ew-table-header-caption"><?php echo $loanappliedcancelled_grid->taxamountbreakdown->caption() ?></span><span class="ew-table-header-sort"><?php if ($loanappliedcancelled_grid->taxamountbreakdown->getSort() == "ASC") { ?><i class="fas fa-sort-up"></i><?php } elseif ($loanappliedcancelled_grid->taxamountbreakdown->getSort() == "DESC") { ?><i class="fas fa-sort-down"></i><?php } ?></span></div>
		</div></div></th>
	<?php } ?>
<?php } ?>
<?php if ($loanappliedcancelled_grid->feesystembreakdown->Visible) { // feesystembreakdown ?>
	<?php if ($loanappliedcancelled_grid->SortUrl($loanappliedcancelled_grid->feesystembreakdown) == "") { ?>
		<th data-name="feesystembreakdown" class="<?php echo $loanappliedcancelled_grid->feesystembreakdown->headerCellClass() ?>"><div id="elh_loanappliedcancelled_feesystembreakdown" class="loanappliedcancelled_feesystembreakdown"><div class="ew-table-header-caption"><?php echo $loanappliedcancelled_grid->feesystembreakdown->caption() ?></div></div></th>
	<?php } else { ?>
		<th data-name="feesystembreakdown" class="<?php echo $loanappliedcancelled_grid->feesystembreakdown->headerCellClass() ?>"><div><div id="elh_loanappliedcancelled_feesystembreakdown" class="loanappliedcancelled_feesystembreakdown">
			<div class="ew-table-header-btn"><span class="ew-table-header-caption"><?php echo $loanappliedcancelled_grid->feesystembreakdown->caption() ?></span><span class="ew-table-header-sort"><?php if ($loanappliedcancelled_grid->feesystembreakdown->getSort() == "ASC") { ?><i class="fas fa-sort-up"></i><?php } elseif ($loanappliedcancelled_grid->feesystembreakdown->getSort() == "DESC") { ?><i class="fas fa-sort-down"></i><?php } ?></span></div>
		</div></div></th>
	<?php } ?>
<?php } ?>
<?php if ($loanappliedcancelled_grid->feeexternalbreakdown->Visible) { // feeexternalbreakdown ?>
	<?php if ($loanappliedcancelled_grid->SortUrl($loanappliedcancelled_grid->feeexternalbreakdown) == "") { ?>
		<th data-name="feeexternalbreakdown" class="<?php echo $loanappliedcancelled_grid->feeexternalbreakdown->headerCellClass() ?>"><div id="elh_loanappliedcancelled_feeexternalbreakdown" class="loanappliedcancelled_feeexternalbreakdown"><div class="ew-table-header-caption"><?php echo $loanappliedcancelled_grid->feeexternalbreakdown->caption() ?></div></div></th>
	<?php } else { ?>
		<th data-name="feeexternalbreakdown" class="<?php echo $loanappliedcancelled_grid->feeexternalbreakdown->headerCellClass() ?>"><div><div id="elh_loanappliedcancelled_feeexternalbreakdown" class="loanappliedcancelled_feeexternalbreakdown">
			<div class="ew-table-header-btn"><span class="ew-table-header-caption"><?php echo $loanappliedcancelled_grid->feeexternalbreakdown->caption() ?></span><span class="ew-table-header-sort"><?php if ($loanappliedcancelled_grid->feeexternalbreakdown->getSort() == "ASC") { ?><i class="fas fa-sort-up"></i><?php } elseif ($loanappliedcancelled_grid->feeexternalbreakdown->getSort() == "DESC") { ?><i class="fas fa-sort-down"></i><?php } ?></span></div>
		</div></div></th>
	<?php } ?>
<?php } ?>
<?php if ($loanappliedcancelled_grid->feefranchiseebreakdown->Visible) { // feefranchiseebreakdown ?>
	<?php if ($loanappliedcancelled_grid->SortUrl($loanappliedcancelled_grid->feefranchiseebreakdown) == "") { ?>
		<th data-name="feefranchiseebreakdown" class="<?php echo $loanappliedcancelled_grid->feefranchiseebreakdown->headerCellClass() ?>"><div id="elh_loanappliedcancelled_feefranchiseebreakdown" class="loanappliedcancelled_feefranchiseebreakdown"><div class="ew-table-header-caption"><?php echo $loanappliedcancelled_grid->feefranchiseebreakdown->caption() ?></div></div></th>
	<?php } else { ?>
		<th data-name="feefranchiseebreakdown" class="<?php echo $loanappliedcancelled_grid->feefranchiseebreakdown->headerCellClass() ?>"><div><div id="elh_loanappliedcancelled_feefranchiseebreakdown" class="loanappliedcancelled_feefranchiseebreakdown">
			<div class="ew-table-header-btn"><span class="ew-table-header-caption"><?php echo $loanappliedcancelled_grid->feefranchiseebreakdown->caption() ?></span><span class="ew-table-header-sort"><?php if ($loanappliedcancelled_grid->feefranchiseebreakdown->getSort() == "ASC") { ?><i class="fas fa-sort-up"></i><?php } elseif ($loanappliedcancelled_grid->feefranchiseebreakdown->getSort() == "DESC") { ?><i class="fas fa-sort-down"></i><?php } ?></span></div>
		</div></div></th>
	<?php } ?>
<?php } ?>
<?php if ($loanappliedcancelled_grid->feeresellerbreakdown->Visible) { // feeresellerbreakdown ?>
	<?php if ($loanappliedcancelled_grid->SortUrl($loanappliedcancelled_grid->feeresellerbreakdown) == "") { ?>
		<th data-name="feeresellerbreakdown" class="<?php echo $loanappliedcancelled_grid->feeresellerbreakdown->headerCellClass() ?>"><div id="elh_loanappliedcancelled_feeresellerbreakdown" class="loanappliedcancelled_feeresellerbreakdown"><div class="ew-table-header-caption"><?php echo $loanappliedcancelled_grid->feeresellerbreakdown->caption() ?></div></div></th>
	<?php } else { ?>
		<th data-name="feeresellerbreakdown" class="<?php echo $loanappliedcancelled_grid->feeresellerbreakdown->headerCellClass() ?>"><div><div id="elh_loanappliedcancelled_feeresellerbreakdown" class="loanappliedcancelled_feeresellerbreakdown">
			<div class="ew-table-header-btn"><span class="ew-table-header-caption"><?php echo $loanappliedcancelled_grid->feeresellerbreakdown->caption() ?></span><span class="ew-table-header-sort"><?php if ($loanappliedcancelled_grid->feeresellerbreakdown->getSort() == "ASC") { ?><i class="fas fa-sort-up"></i><?php } elseif ($loanappliedcancelled_grid->feeresellerbreakdown->getSort() == "DESC") { ?><i class="fas fa-sort-down"></i><?php } ?></span></div>
		</div></div></th>
	<?php } ?>
<?php } ?>
<?php if ($loanappliedcancelled_grid->cancellationtime->Visible) { // cancellationtime ?>
	<?php if ($loanappliedcancelled_grid->SortUrl($loanappliedcancelled_grid->cancellationtime) == "") { ?>
		<th data-name="cancellationtime" class="<?php echo $loanappliedcancelled_grid->cancellationtime->headerCellClass() ?>"><div id="elh_loanappliedcancelled_cancellationtime" class="loanappliedcancelled_cancellationtime"><div class="ew-table-header-caption"><?php echo $loanappliedcancelled_grid->cancellationtime->caption() ?></div></div></th>
	<?php } else { ?>
		<th data-name="cancellationtime" class="<?php echo $loanappliedcancelled_grid->cancellationtime->headerCellClass() ?>"><div><div id="elh_loanappliedcancelled_cancellationtime" class="loanappliedcancelled_cancellationtime">
			<div class="ew-table-header-btn"><span class="ew-table-header-caption"><?php echo $loanappliedcancelled_grid->cancellationtime->caption() ?></span><span class="ew-table-header-sort"><?php if ($loanappliedcancelled_grid->cancellationtime->getSort() == "ASC") { ?><i class="fas fa-sort-up"></i><?php } elseif ($loanappliedcancelled_grid->cancellationtime->getSort() == "DESC") { ?><i class="fas fa-sort-down"></i><?php } ?></span></div>
		</div></div></th>
	<?php } ?>
<?php } ?>
<?php if ($loanappliedcancelled_grid->cancellationrefno->Visible) { // cancellationrefno ?>
	<?php if ($loanappliedcancelled_grid->SortUrl($loanappliedcancelled_grid->cancellationrefno) == "") { ?>
		<th data-name="cancellationrefno" class="<?php echo $loanappliedcancelled_grid->cancellationrefno->headerCellClass() ?>"><div id="elh_loanappliedcancelled_cancellationrefno" class="loanappliedcancelled_cancellationrefno"><div class="ew-table-header-caption"><?php echo $loanappliedcancelled_grid->cancellationrefno->caption() ?></div></div></th>
	<?php } else { ?>
		<th data-name="cancellationrefno" class="<?php echo $loanappliedcancelled_grid->cancellationrefno->headerCellClass() ?>"><div><div id="elh_loanappliedcancelled_cancellationrefno" class="loanappliedcancelled_cancellationrefno">
			<div class="ew-table-header-btn"><span class="ew-table-header-caption"><?php echo $loanappliedcancelled_grid->cancellationrefno->caption() ?></span><span class="ew-table-header-sort"><?php if ($loanappliedcancelled_grid->cancellationrefno->getSort() == "ASC") { ?><i class="fas fa-sort-up"></i><?php } elseif ($loanappliedcancelled_grid->cancellationrefno->getSort() == "DESC") { ?><i class="fas fa-sort-down"></i><?php } ?></span></div>
		</div></div></th>
	<?php } ?>
<?php } ?>
<?php

// Render list options (header, right)
$loanappliedcancelled_grid->ListOptions->render("header", "right");
?>
	</tr>
</thead>
<tbody>
<?php
$loanappliedcancelled_grid->StartRecord = 1;
$loanappliedcancelled_grid->StopRecord = $loanappliedcancelled_grid->TotalRecords; // Show all records

// Restore number of post back records
if ($CurrentForm && ($loanappliedcancelled->isConfirm() || $loanappliedcancelled_grid->EventCancelled)) {
	$CurrentForm->Index = -1;
	if ($CurrentForm->hasValue($loanappliedcancelled_grid->FormKeyCountName) && ($loanappliedcancelled_grid->isGridAdd() || $loanappliedcancelled_grid->isGridEdit() || $loanappliedcancelled->isConfirm())) {
		$loanappliedcancelled_grid->KeyCount = $CurrentForm->getValue($loanappliedcancelled_grid->FormKeyCountName);
		$loanappliedcancelled_grid->StopRecord = $loanappliedcancelled_grid->StartRecord + $loanappliedcancelled_grid->KeyCount - 1;
	}
}
$loanappliedcancelled_grid->RecordCount = $loanappliedcancelled_grid->StartRecord - 1;
if ($loanappliedcancelled_grid->Recordset && !$loanappliedcancelled_grid->Recordset->EOF) {
	$loanappliedcancelled_grid->Recordset->moveFirst();
	$selectLimit = $loanappliedcancelled_grid->UseSelectLimit;
	if (!$selectLimit && $loanappliedcancelled_grid->StartRecord > 1)
		$loanappliedcancelled_grid->Recordset->move($loanappliedcancelled_grid->StartRecord - 1);
} elseif (!$loanappliedcancelled->AllowAddDeleteRow && $loanappliedcancelled_grid->StopRecord == 0) {
	$loanappliedcancelled_grid->StopRecord = $loanappliedcancelled->GridAddRowCount;
}

// Initialize aggregate
$loanappliedcancelled->RowType = ROWTYPE_AGGREGATEINIT;
$loanappliedcancelled->resetAttributes();
$loanappliedcancelled_grid->renderRow();
if ($loanappliedcancelled_grid->isGridAdd())
	$loanappliedcancelled_grid->RowIndex = 0;
if ($loanappliedcancelled_grid->isGridEdit())
	$loanappliedcancelled_grid->RowIndex = 0;
while ($loanappliedcancelled_grid->RecordCount < $loanappliedcancelled_grid->StopRecord) {
	$loanappliedcancelled_grid->RecordCount++;
	if ($loanappliedcancelled_grid->RecordCount >= $loanappliedcancelled_grid->StartRecord) {
		$loanappliedcancelled_grid->RowCount++;
		if ($loanappliedcancelled_grid->isGridAdd() || $loanappliedcancelled_grid->isGridEdit() || $loanappliedcancelled->isConfirm()) {
			$loanappliedcancelled_grid->RowIndex++;
			$CurrentForm->Index = $loanappliedcancelled_grid->RowIndex;
			if ($CurrentForm->hasValue($loanappliedcancelled_grid->FormActionName) && ($loanappliedcancelled->isConfirm() || $loanappliedcancelled_grid->EventCancelled))
				$loanappliedcancelled_grid->RowAction = strval($CurrentForm->getValue($loanappliedcancelled_grid->FormActionName));
			elseif ($loanappliedcancelled_grid->isGridAdd())
				$loanappliedcancelled_grid->RowAction = "insert";
			else
				$loanappliedcancelled_grid->RowAction = "";
		}

		// Set up key count
		$loanappliedcancelled_grid->KeyCount = $loanappliedcancelled_grid->RowIndex;

		// Init row class and style
		$loanappliedcancelled->resetAttributes();
		$loanappliedcancelled->CssClass = "";
		if ($loanappliedcancelled_grid->isGridAdd()) {
			if ($loanappliedcancelled->CurrentMode == "copy") {
				$loanappliedcancelled_grid->loadRowValues($loanappliedcancelled_grid->Recordset); // Load row values
				$loanappliedcancelled_grid->setRecordKey($loanappliedcancelled_grid->RowOldKey, $loanappliedcancelled_grid->Recordset); // Set old record key
			} else {
				$loanappliedcancelled_grid->loadRowValues(); // Load default values
				$loanappliedcancelled_grid->RowOldKey = ""; // Clear old key value
			}
		} else {
			$loanappliedcancelled_grid->loadRowValues($loanappliedcancelled_grid->Recordset); // Load row values
		}
		$loanappliedcancelled->RowType = ROWTYPE_VIEW; // Render view
		if ($loanappliedcancelled_grid->isGridAdd()) // Grid add
			$loanappliedcancelled->RowType = ROWTYPE_ADD; // Render add
		if ($loanappliedcancelled_grid->isGridAdd() && $loanappliedcancelled->EventCancelled && !$CurrentForm->hasValue("k_blankrow")) // Insert failed
			$loanappliedcancelled_grid->restoreCurrentRowFormValues($loanappliedcancelled_grid->RowIndex); // Restore form values
		if ($loanappliedcancelled_grid->isGridEdit()) { // Grid edit
			if ($loanappliedcancelled->EventCancelled)
				$loanappliedcancelled_grid->restoreCurrentRowFormValues($loanappliedcancelled_grid->RowIndex); // Restore form values
			if ($loanappliedcancelled_grid->RowAction == "insert")
				$loanappliedcancelled->RowType = ROWTYPE_ADD; // Render add
			else
				$loanappliedcancelled->RowType = ROWTYPE_EDIT; // Render edit
		}
		if ($loanappliedcancelled_grid->isGridEdit() && ($loanappliedcancelled->RowType == ROWTYPE_EDIT || $loanappliedcancelled->RowType == ROWTYPE_ADD) && $loanappliedcancelled->EventCancelled) // Update failed
			$loanappliedcancelled_grid->restoreCurrentRowFormValues($loanappliedcancelled_grid->RowIndex); // Restore form values
		if ($loanappliedcancelled->RowType == ROWTYPE_EDIT) // Edit row
			$loanappliedcancelled_grid->EditRowCount++;
		if ($loanappliedcancelled->isConfirm()) // Confirm row
			$loanappliedcancelled_grid->restoreCurrentRowFormValues($loanappliedcancelled_grid->RowIndex); // Restore form values

		// Set up row id / data-rowindex
		$loanappliedcancelled->RowAttrs->merge(["data-rowindex" => $loanappliedcancelled_grid->RowCount, "id" => "r" . $loanappliedcancelled_grid->RowCount . "_loanappliedcancelled", "data-rowtype" => $loanappliedcancelled->RowType]);

		// Render row
		$loanappliedcancelled_grid->renderRow();

		// Render list options
		$loanappliedcancelled_grid->renderListOptions();

		// Skip delete row / empty row for confirm page
		if ($loanappliedcancelled_grid->RowAction != "delete" && $loanappliedcancelled_grid->RowAction != "insertdelete" && !($loanappliedcancelled_grid->RowAction == "insert" && $loanappliedcancelled->isConfirm() && $loanappliedcancelled_grid->emptyRow())) {
?>
	<tr <?php echo $loanappliedcancelled->rowAttributes() ?>>
<?php

// Render list options (body, left)
$loanappliedcancelled_grid->ListOptions->render("body", "left", $loanappliedcancelled_grid->RowCount);
?>
	<?php if ($loanappliedcancelled_grid->applyid->Visible) { // applyid ?>
		<td data-name="applyid" <?php echo $loanappliedcancelled_grid->applyid->cellAttributes() ?>>
<?php if ($loanappliedcancelled->RowType == ROWTYPE_ADD) { // Add record ?>
<span id="el<?php echo $loanappliedcancelled_grid->RowCount ?>_loanappliedcancelled_applyid" class="form-group">
<input type="text" data-table="loanappliedcancelled" data-field="x_applyid" name="x<?php echo $loanappliedcancelled_grid->RowIndex ?>_applyid" id="x<?php echo $loanappliedcancelled_grid->RowIndex ?>_applyid" size="30" maxlength="15" placeholder="<?php echo HtmlEncode($loanappliedcancelled_grid->applyid->getPlaceHolder()) ?>" value="<?php echo $loanappliedcancelled_grid->applyid->EditValue ?>"<?php echo $loanappliedcancelled_grid->applyid->editAttributes() ?>>
</span>
<input type="hidden" data-table="loanappliedcancelled" data-field="x_applyid" name="o<?php echo $loanappliedcancelled_grid->RowIndex ?>_applyid" id="o<?php echo $loanappliedcancelled_grid->RowIndex ?>_applyid" value="<?php echo HtmlEncode($loanappliedcancelled_grid->applyid->OldValue) ?>">
<?php } ?>
<?php if ($loanappliedcancelled->RowType == ROWTYPE_EDIT) { // Edit record ?>
<input type="text" data-table="loanappliedcancelled" data-field="x_applyid" name="x<?php echo $loanappliedcancelled_grid->RowIndex ?>_applyid" id="x<?php echo $loanappliedcancelled_grid->RowIndex ?>_applyid" size="30" maxlength="15" placeholder="<?php echo HtmlEncode($loanappliedcancelled_grid->applyid->getPlaceHolder()) ?>" value="<?php echo $loanappliedcancelled_grid->applyid->EditValue ?>"<?php echo $loanappliedcancelled_grid->applyid->editAttributes() ?>>
<input type="hidden" data-table="loanappliedcancelled" data-field="x_applyid" name="o<?php echo $loanappliedcancelled_grid->RowIndex ?>_applyid" id="o<?php echo $loanappliedcancelled_grid->RowIndex ?>_applyid" value="<?php echo HtmlEncode($loanappliedcancelled_grid->applyid->OldValue != null ? $loanappliedcancelled_grid->applyid->OldValue : $loanappliedcancelled_grid->applyid->CurrentValue) ?>">
<?php } ?>
<?php if ($loanappliedcancelled->RowType == ROWTYPE_VIEW) { // View record ?>
<span id="el<?php echo $loanappliedcancelled_grid->RowCount ?>_loanappliedcancelled_applyid">
<span<?php echo $loanappliedcancelled_grid->applyid->viewAttributes() ?>><?php echo $loanappliedcancelled_grid->applyid->getViewValue() ?></span>
</span>
<?php if (!$loanappliedcancelled->isConfirm()) { ?>
<input type="hidden" data-table="loanappliedcancelled" data-field="x_applyid" name="x<?php echo $loanappliedcancelled_grid->RowIndex ?>_applyid" id="x<?php echo $loanappliedcancelled_grid->RowIndex ?>_applyid" value="<?php echo HtmlEncode($loanappliedcancelled_grid->applyid->FormValue) ?>">
<input type="hidden" data-table="loanappliedcancelled" data-field="x_applyid" name="o<?php echo $loanappliedcancelled_grid->RowIndex ?>_applyid" id="o<?php echo $loanappliedcancelled_grid->RowIndex ?>_applyid" value="<?php echo HtmlEncode($loanappliedcancelled_grid->applyid->OldValue) ?>">
<?php } else { ?>
<input type="hidden" data-table="loanappliedcancelled" data-field="x_applyid" name="floanappliedcancelledgrid$x<?php echo $loanappliedcancelled_grid->RowIndex ?>_applyid" id="floanappliedcancelledgrid$x<?php echo $loanappliedcancelled_grid->RowIndex ?>_applyid" value="<?php echo HtmlEncode($loanappliedcancelled_grid->applyid->FormValue) ?>">
<input type="hidden" data-table="loanappliedcancelled" data-field="x_applyid" name="floanappliedcancelledgrid$o<?php echo $loanappliedcancelled_grid->RowIndex ?>_applyid" id="floanappliedcancelledgrid$o<?php echo $loanappliedcancelled_grid->RowIndex ?>_applyid" value="<?php echo HtmlEncode($loanappliedcancelled_grid->applyid->OldValue) ?>">
<?php } ?>
<?php } ?>
</td>
	<?php } ?>
	<?php if ($loanappliedcancelled_grid->loanid->Visible) { // loanid ?>
		<td data-name="loanid" <?php echo $loanappliedcancelled_grid->loanid->cellAttributes() ?>>
<?php if ($loanappliedcancelled->RowType == ROWTYPE_ADD) { // Add record ?>
<span id="el<?php echo $loanappliedcancelled_grid->RowCount ?>_loanappliedcancelled_loanid" class="form-group">
<input type="text" data-table="loanappliedcancelled" data-field="x_loanid" name="x<?php echo $loanappliedcancelled_grid->RowIndex ?>_loanid" id="x<?php echo $loanappliedcancelled_grid->RowIndex ?>_loanid" size="30" maxlength="15" placeholder="<?php echo HtmlEncode($loanappliedcancelled_grid->loanid->getPlaceHolder()) ?>" value="<?php echo $loanappliedcancelled_grid->loanid->EditValue ?>"<?php echo $loanappliedcancelled_grid->loanid->editAttributes() ?>>
</span>
<input type="hidden" data-table="loanappliedcancelled" data-field="x_loanid" name="o<?php echo $loanappliedcancelled_grid->RowIndex ?>_loanid" id="o<?php echo $loanappliedcancelled_grid->RowIndex ?>_loanid" value="<?php echo HtmlEncode($loanappliedcancelled_grid->loanid->OldValue) ?>">
<?php } ?>
<?php if ($loanappliedcancelled->RowType == ROWTYPE_EDIT) { // Edit record ?>
<span id="el<?php echo $loanappliedcancelled_grid->RowCount ?>_loanappliedcancelled_loanid" class="form-group">
<input type="text" data-table="loanappliedcancelled" data-field="x_loanid" name="x<?php echo $loanappliedcancelled_grid->RowIndex ?>_loanid" id="x<?php echo $loanappliedcancelled_grid->RowIndex ?>_loanid" size="30" maxlength="15" placeholder="<?php echo HtmlEncode($loanappliedcancelled_grid->loanid->getPlaceHolder()) ?>" value="<?php echo $loanappliedcancelled_grid->loanid->EditValue ?>"<?php echo $loanappliedcancelled_grid->loanid->editAttributes() ?>>
</span>
<?php } ?>
<?php if ($loanappliedcancelled->RowType == ROWTYPE_VIEW) { // View record ?>
<span id="el<?php echo $loanappliedcancelled_grid->RowCount ?>_loanappliedcancelled_loanid">
<span<?php echo $loanappliedcancelled_grid->loanid->viewAttributes() ?>><?php if (!EmptyString($loanappliedcancelled_grid->loanid->getViewValue()) && $loanappliedcancelled_grid->loanid->linkAttributes() != "") { ?>
<a<?php echo $loanappliedcancelled_grid->loanid->linkAttributes() ?>><?php echo $loanappliedcancelled_grid->loanid->getViewValue() ?></a>
<?php } else { ?>
<?php echo $loanappliedcancelled_grid->loanid->getViewValue() ?>
<?php } ?></span>
</span>
<?php if (!$loanappliedcancelled->isConfirm()) { ?>
<input type="hidden" data-table="loanappliedcancelled" data-field="x_loanid" name="x<?php echo $loanappliedcancelled_grid->RowIndex ?>_loanid" id="x<?php echo $loanappliedcancelled_grid->RowIndex ?>_loanid" value="<?php echo HtmlEncode($loanappliedcancelled_grid->loanid->FormValue) ?>">
<input type="hidden" data-table="loanappliedcancelled" data-field="x_loanid" name="o<?php echo $loanappliedcancelled_grid->RowIndex ?>_loanid" id="o<?php echo $loanappliedcancelled_grid->RowIndex ?>_loanid" value="<?php echo HtmlEncode($loanappliedcancelled_grid->loanid->OldValue) ?>">
<?php } else { ?>
<input type="hidden" data-table="loanappliedcancelled" data-field="x_loanid" name="floanappliedcancelledgrid$x<?php echo $loanappliedcancelled_grid->RowIndex ?>_loanid" id="floanappliedcancelledgrid$x<?php echo $loanappliedcancelled_grid->RowIndex ?>_loanid" value="<?php echo HtmlEncode($loanappliedcancelled_grid->loanid->FormValue) ?>">
<input type="hidden" data-table="loanappliedcancelled" data-field="x_loanid" name="floanappliedcancelledgrid$o<?php echo $loanappliedcancelled_grid->RowIndex ?>_loanid" id="floanappliedcancelledgrid$o<?php echo $loanappliedcancelled_grid->RowIndex ?>_loanid" value="<?php echo HtmlEncode($loanappliedcancelled_grid->loanid->OldValue) ?>">
<?php } ?>
<?php } ?>
</td>
	<?php } ?>
	<?php if ($loanappliedcancelled_grid->paymentid->Visible) { // paymentid ?>
		<td data-name="paymentid" <?php echo $loanappliedcancelled_grid->paymentid->cellAttributes() ?>>
<?php if ($loanappliedcancelled->RowType == ROWTYPE_ADD) { // Add record ?>
<?php if ($loanappliedcancelled_grid->paymentid->getSessionValue() != "") { ?>
<span id="el<?php echo $loanappliedcancelled_grid->RowCount ?>_loanappliedcancelled_paymentid" class="form-group">
<span<?php echo $loanappliedcancelled_grid->paymentid->viewAttributes() ?>><?php if (!EmptyString($loanappliedcancelled_grid->paymentid->ViewValue) && $loanappliedcancelled_grid->paymentid->linkAttributes() != "") { ?>
<a<?php echo $loanappliedcancelled_grid->paymentid->linkAttributes() ?>><input type="text" readonly class="form-control-plaintext" value="<?php echo HtmlEncode(RemoveHtml($loanappliedcancelled_grid->paymentid->ViewValue)) ?>"></a>
<?php } else { ?>
<input type="text" readonly class="form-control-plaintext" value="<?php echo HtmlEncode(RemoveHtml($loanappliedcancelled_grid->paymentid->ViewValue)) ?>">
<?php } ?></span>
</span>
<input type="hidden" id="x<?php echo $loanappliedcancelled_grid->RowIndex ?>_paymentid" name="x<?php echo $loanappliedcancelled_grid->RowIndex ?>_paymentid" value="<?php echo HtmlEncode($loanappliedcancelled_grid->paymentid->CurrentValue) ?>">
<?php } else { ?>
<span id="el<?php echo $loanappliedcancelled_grid->RowCount ?>_loanappliedcancelled_paymentid" class="form-group">
<input type="text" data-table="loanappliedcancelled" data-field="x_paymentid" name="x<?php echo $loanappliedcancelled_grid->RowIndex ?>_paymentid" id="x<?php echo $loanappliedcancelled_grid->RowIndex ?>_paymentid" size="30" maxlength="15" placeholder="<?php echo HtmlEncode($loanappliedcancelled_grid->paymentid->getPlaceHolder()) ?>" value="<?php echo $loanappliedcancelled_grid->paymentid->EditValue ?>"<?php echo $loanappliedcancelled_grid->paymentid->editAttributes() ?>>
</span>
<?php } ?>
<input type="hidden" data-table="loanappliedcancelled" data-field="x_paymentid" name="o<?php echo $loanappliedcancelled_grid->RowIndex ?>_paymentid" id="o<?php echo $loanappliedcancelled_grid->RowIndex ?>_paymentid" value="<?php echo HtmlEncode($loanappliedcancelled_grid->paymentid->OldValue) ?>">
<?php } ?>
<?php if ($loanappliedcancelled->RowType == ROWTYPE_EDIT) { // Edit record ?>
<?php if ($loanappliedcancelled_grid->paymentid->getSessionValue() != "") { ?>
<span id="el<?php echo $loanappliedcancelled_grid->RowCount ?>_loanappliedcancelled_paymentid" class="form-group">
<span<?php echo $loanappliedcancelled_grid->paymentid->viewAttributes() ?>><?php if (!EmptyString($loanappliedcancelled_grid->paymentid->ViewValue) && $loanappliedcancelled_grid->paymentid->linkAttributes() != "") { ?>
<a<?php echo $loanappliedcancelled_grid->paymentid->linkAttributes() ?>><input type="text" readonly class="form-control-plaintext" value="<?php echo HtmlEncode(RemoveHtml($loanappliedcancelled_grid->paymentid->ViewValue)) ?>"></a>
<?php } else { ?>
<input type="text" readonly class="form-control-plaintext" value="<?php echo HtmlEncode(RemoveHtml($loanappliedcancelled_grid->paymentid->ViewValue)) ?>">
<?php } ?></span>
</span>
<input type="hidden" id="x<?php echo $loanappliedcancelled_grid->RowIndex ?>_paymentid" name="x<?php echo $loanappliedcancelled_grid->RowIndex ?>_paymentid" value="<?php echo HtmlEncode($loanappliedcancelled_grid->paymentid->CurrentValue) ?>">
<?php } else { ?>
<span id="el<?php echo $loanappliedcancelled_grid->RowCount ?>_loanappliedcancelled_paymentid" class="form-group">
<input type="text" data-table="loanappliedcancelled" data-field="x_paymentid" name="x<?php echo $loanappliedcancelled_grid->RowIndex ?>_paymentid" id="x<?php echo $loanappliedcancelled_grid->RowIndex ?>_paymentid" size="30" maxlength="15" placeholder="<?php echo HtmlEncode($loanappliedcancelled_grid->paymentid->getPlaceHolder()) ?>" value="<?php echo $loanappliedcancelled_grid->paymentid->EditValue ?>"<?php echo $loanappliedcancelled_grid->paymentid->editAttributes() ?>>
</span>
<?php } ?>
<?php } ?>
<?php if ($loanappliedcancelled->RowType == ROWTYPE_VIEW) { // View record ?>
<span id="el<?php echo $loanappliedcancelled_grid->RowCount ?>_loanappliedcancelled_paymentid">
<span<?php echo $loanappliedcancelled_grid->paymentid->viewAttributes() ?>><?php if (!EmptyString($loanappliedcancelled_grid->paymentid->getViewValue()) && $loanappliedcancelled_grid->paymentid->linkAttributes() != "") { ?>
<a<?php echo $loanappliedcancelled_grid->paymentid->linkAttributes() ?>><?php echo $loanappliedcancelled_grid->paymentid->getViewValue() ?></a>
<?php } else { ?>
<?php echo $loanappliedcancelled_grid->paymentid->getViewValue() ?>
<?php } ?></span>
</span>
<?php if (!$loanappliedcancelled->isConfirm()) { ?>
<input type="hidden" data-table="loanappliedcancelled" data-field="x_paymentid" name="x<?php echo $loanappliedcancelled_grid->RowIndex ?>_paymentid" id="x<?php echo $loanappliedcancelled_grid->RowIndex ?>_paymentid" value="<?php echo HtmlEncode($loanappliedcancelled_grid->paymentid->FormValue) ?>">
<input type="hidden" data-table="loanappliedcancelled" data-field="x_paymentid" name="o<?php echo $loanappliedcancelled_grid->RowIndex ?>_paymentid" id="o<?php echo $loanappliedcancelled_grid->RowIndex ?>_paymentid" value="<?php echo HtmlEncode($loanappliedcancelled_grid->paymentid->OldValue) ?>">
<?php } else { ?>
<input type="hidden" data-table="loanappliedcancelled" data-field="x_paymentid" name="floanappliedcancelledgrid$x<?php echo $loanappliedcancelled_grid->RowIndex ?>_paymentid" id="floanappliedcancelledgrid$x<?php echo $loanappliedcancelled_grid->RowIndex ?>_paymentid" value="<?php echo HtmlEncode($loanappliedcancelled_grid->paymentid->FormValue) ?>">
<input type="hidden" data-table="loanappliedcancelled" data-field="x_paymentid" name="floanappliedcancelledgrid$o<?php echo $loanappliedcancelled_grid->RowIndex ?>_paymentid" id="floanappliedcancelledgrid$o<?php echo $loanappliedcancelled_grid->RowIndex ?>_paymentid" value="<?php echo HtmlEncode($loanappliedcancelled_grid->paymentid->OldValue) ?>">
<?php } ?>
<?php } ?>
</td>
	<?php } ?>
	<?php if ($loanappliedcancelled_grid->amountapplied->Visible) { // amountapplied ?>
		<td data-name="amountapplied" <?php echo $loanappliedcancelled_grid->amountapplied->cellAttributes() ?>>
<?php if ($loanappliedcancelled->RowType == ROWTYPE_ADD) { // Add record ?>
<span id="el<?php echo $loanappliedcancelled_grid->RowCount ?>_loanappliedcancelled_amountapplied" class="form-group">
<input type="text" data-table="loanappliedcancelled" data-field="x_amountapplied" name="x<?php echo $loanappliedcancelled_grid->RowIndex ?>_amountapplied" id="x<?php echo $loanappliedcancelled_grid->RowIndex ?>_amountapplied" size="30" maxlength="15" placeholder="<?php echo HtmlEncode($loanappliedcancelled_grid->amountapplied->getPlaceHolder()) ?>" value="<?php echo $loanappliedcancelled_grid->amountapplied->EditValue ?>"<?php echo $loanappliedcancelled_grid->amountapplied->editAttributes() ?>>
</span>
<input type="hidden" data-table="loanappliedcancelled" data-field="x_amountapplied" name="o<?php echo $loanappliedcancelled_grid->RowIndex ?>_amountapplied" id="o<?php echo $loanappliedcancelled_grid->RowIndex ?>_amountapplied" value="<?php echo HtmlEncode($loanappliedcancelled_grid->amountapplied->OldValue) ?>">
<?php } ?>
<?php if ($loanappliedcancelled->RowType == ROWTYPE_EDIT) { // Edit record ?>
<span id="el<?php echo $loanappliedcancelled_grid->RowCount ?>_loanappliedcancelled_amountapplied" class="form-group">
<input type="text" data-table="loanappliedcancelled" data-field="x_amountapplied" name="x<?php echo $loanappliedcancelled_grid->RowIndex ?>_amountapplied" id="x<?php echo $loanappliedcancelled_grid->RowIndex ?>_amountapplied" size="30" maxlength="15" placeholder="<?php echo HtmlEncode($loanappliedcancelled_grid->amountapplied->getPlaceHolder()) ?>" value="<?php echo $loanappliedcancelled_grid->amountapplied->EditValue ?>"<?php echo $loanappliedcancelled_grid->amountapplied->editAttributes() ?>>
</span>
<?php } ?>
<?php if ($loanappliedcancelled->RowType == ROWTYPE_VIEW) { // View record ?>
<span id="el<?php echo $loanappliedcancelled_grid->RowCount ?>_loanappliedcancelled_amountapplied">
<span<?php echo $loanappliedcancelled_grid->amountapplied->viewAttributes() ?>><?php echo $loanappliedcancelled_grid->amountapplied->getViewValue() ?></span>
</span>
<?php if (!$loanappliedcancelled->isConfirm()) { ?>
<input type="hidden" data-table="loanappliedcancelled" data-field="x_amountapplied" name="x<?php echo $loanappliedcancelled_grid->RowIndex ?>_amountapplied" id="x<?php echo $loanappliedcancelled_grid->RowIndex ?>_amountapplied" value="<?php echo HtmlEncode($loanappliedcancelled_grid->amountapplied->FormValue) ?>">
<input type="hidden" data-table="loanappliedcancelled" data-field="x_amountapplied" name="o<?php echo $loanappliedcancelled_grid->RowIndex ?>_amountapplied" id="o<?php echo $loanappliedcancelled_grid->RowIndex ?>_amountapplied" value="<?php echo HtmlEncode($loanappliedcancelled_grid->amountapplied->OldValue) ?>">
<?php } else { ?>
<input type="hidden" data-table="loanappliedcancelled" data-field="x_amountapplied" name="floanappliedcancelledgrid$x<?php echo $loanappliedcancelled_grid->RowIndex ?>_amountapplied" id="floanappliedcancelledgrid$x<?php echo $loanappliedcancelled_grid->RowIndex ?>_amountapplied" value="<?php echo HtmlEncode($loanappliedcancelled_grid->amountapplied->FormValue) ?>">
<input type="hidden" data-table="loanappliedcancelled" data-field="x_amountapplied" name="floanappliedcancelledgrid$o<?php echo $loanappliedcancelled_grid->RowIndex ?>_amountapplied" id="floanappliedcancelledgrid$o<?php echo $loanappliedcancelled_grid->RowIndex ?>_amountapplied" value="<?php echo HtmlEncode($loanappliedcancelled_grid->amountapplied->OldValue) ?>">
<?php } ?>
<?php } ?>
</td>
	<?php } ?>
	<?php if ($loanappliedcancelled_grid->feesapplied->Visible) { // feesapplied ?>
		<td data-name="feesapplied" <?php echo $loanappliedcancelled_grid->feesapplied->cellAttributes() ?>>
<?php if ($loanappliedcancelled->RowType == ROWTYPE_ADD) { // Add record ?>
<span id="el<?php echo $loanappliedcancelled_grid->RowCount ?>_loanappliedcancelled_feesapplied" class="form-group">
<input type="text" data-table="loanappliedcancelled" data-field="x_feesapplied" name="x<?php echo $loanappliedcancelled_grid->RowIndex ?>_feesapplied" id="x<?php echo $loanappliedcancelled_grid->RowIndex ?>_feesapplied" size="30" maxlength="15" placeholder="<?php echo HtmlEncode($loanappliedcancelled_grid->feesapplied->getPlaceHolder()) ?>" value="<?php echo $loanappliedcancelled_grid->feesapplied->EditValue ?>"<?php echo $loanappliedcancelled_grid->feesapplied->editAttributes() ?>>
</span>
<input type="hidden" data-table="loanappliedcancelled" data-field="x_feesapplied" name="o<?php echo $loanappliedcancelled_grid->RowIndex ?>_feesapplied" id="o<?php echo $loanappliedcancelled_grid->RowIndex ?>_feesapplied" value="<?php echo HtmlEncode($loanappliedcancelled_grid->feesapplied->OldValue) ?>">
<?php } ?>
<?php if ($loanappliedcancelled->RowType == ROWTYPE_EDIT) { // Edit record ?>
<span id="el<?php echo $loanappliedcancelled_grid->RowCount ?>_loanappliedcancelled_feesapplied" class="form-group">
<input type="text" data-table="loanappliedcancelled" data-field="x_feesapplied" name="x<?php echo $loanappliedcancelled_grid->RowIndex ?>_feesapplied" id="x<?php echo $loanappliedcancelled_grid->RowIndex ?>_feesapplied" size="30" maxlength="15" placeholder="<?php echo HtmlEncode($loanappliedcancelled_grid->feesapplied->getPlaceHolder()) ?>" value="<?php echo $loanappliedcancelled_grid->feesapplied->EditValue ?>"<?php echo $loanappliedcancelled_grid->feesapplied->editAttributes() ?>>
</span>
<?php } ?>
<?php if ($loanappliedcancelled->RowType == ROWTYPE_VIEW) { // View record ?>
<span id="el<?php echo $loanappliedcancelled_grid->RowCount ?>_loanappliedcancelled_feesapplied">
<span<?php echo $loanappliedcancelled_grid->feesapplied->viewAttributes() ?>><?php echo $loanappliedcancelled_grid->feesapplied->getViewValue() ?></span>
</span>
<?php if (!$loanappliedcancelled->isConfirm()) { ?>
<input type="hidden" data-table="loanappliedcancelled" data-field="x_feesapplied" name="x<?php echo $loanappliedcancelled_grid->RowIndex ?>_feesapplied" id="x<?php echo $loanappliedcancelled_grid->RowIndex ?>_feesapplied" value="<?php echo HtmlEncode($loanappliedcancelled_grid->feesapplied->FormValue) ?>">
<input type="hidden" data-table="loanappliedcancelled" data-field="x_feesapplied" name="o<?php echo $loanappliedcancelled_grid->RowIndex ?>_feesapplied" id="o<?php echo $loanappliedcancelled_grid->RowIndex ?>_feesapplied" value="<?php echo HtmlEncode($loanappliedcancelled_grid->feesapplied->OldValue) ?>">
<?php } else { ?>
<input type="hidden" data-table="loanappliedcancelled" data-field="x_feesapplied" name="floanappliedcancelledgrid$x<?php echo $loanappliedcancelled_grid->RowIndex ?>_feesapplied" id="floanappliedcancelledgrid$x<?php echo $loanappliedcancelled_grid->RowIndex ?>_feesapplied" value="<?php echo HtmlEncode($loanappliedcancelled_grid->feesapplied->FormValue) ?>">
<input type="hidden" data-table="loanappliedcancelled" data-field="x_feesapplied" name="floanappliedcancelledgrid$o<?php echo $loanappliedcancelled_grid->RowIndex ?>_feesapplied" id="floanappliedcancelledgrid$o<?php echo $loanappliedcancelled_grid->RowIndex ?>_feesapplied" value="<?php echo HtmlEncode($loanappliedcancelled_grid->feesapplied->OldValue) ?>">
<?php } ?>
<?php } ?>
</td>
	<?php } ?>
	<?php if ($loanappliedcancelled_grid->totalamountapplied->Visible) { // totalamountapplied ?>
		<td data-name="totalamountapplied" <?php echo $loanappliedcancelled_grid->totalamountapplied->cellAttributes() ?>>
<?php if ($loanappliedcancelled->RowType == ROWTYPE_ADD) { // Add record ?>
<span id="el<?php echo $loanappliedcancelled_grid->RowCount ?>_loanappliedcancelled_totalamountapplied" class="form-group">
<input type="text" data-table="loanappliedcancelled" data-field="x_totalamountapplied" name="x<?php echo $loanappliedcancelled_grid->RowIndex ?>_totalamountapplied" id="x<?php echo $loanappliedcancelled_grid->RowIndex ?>_totalamountapplied" size="30" maxlength="15" placeholder="<?php echo HtmlEncode($loanappliedcancelled_grid->totalamountapplied->getPlaceHolder()) ?>" value="<?php echo $loanappliedcancelled_grid->totalamountapplied->EditValue ?>"<?php echo $loanappliedcancelled_grid->totalamountapplied->editAttributes() ?>>
</span>
<input type="hidden" data-table="loanappliedcancelled" data-field="x_totalamountapplied" name="o<?php echo $loanappliedcancelled_grid->RowIndex ?>_totalamountapplied" id="o<?php echo $loanappliedcancelled_grid->RowIndex ?>_totalamountapplied" value="<?php echo HtmlEncode($loanappliedcancelled_grid->totalamountapplied->OldValue) ?>">
<?php } ?>
<?php if ($loanappliedcancelled->RowType == ROWTYPE_EDIT) { // Edit record ?>
<span id="el<?php echo $loanappliedcancelled_grid->RowCount ?>_loanappliedcancelled_totalamountapplied" class="form-group">
<input type="text" data-table="loanappliedcancelled" data-field="x_totalamountapplied" name="x<?php echo $loanappliedcancelled_grid->RowIndex ?>_totalamountapplied" id="x<?php echo $loanappliedcancelled_grid->RowIndex ?>_totalamountapplied" size="30" maxlength="15" placeholder="<?php echo HtmlEncode($loanappliedcancelled_grid->totalamountapplied->getPlaceHolder()) ?>" value="<?php echo $loanappliedcancelled_grid->totalamountapplied->EditValue ?>"<?php echo $loanappliedcancelled_grid->totalamountapplied->editAttributes() ?>>
</span>
<?php } ?>
<?php if ($loanappliedcancelled->RowType == ROWTYPE_VIEW) { // View record ?>
<span id="el<?php echo $loanappliedcancelled_grid->RowCount ?>_loanappliedcancelled_totalamountapplied">
<span<?php echo $loanappliedcancelled_grid->totalamountapplied->viewAttributes() ?>><?php echo $loanappliedcancelled_grid->totalamountapplied->getViewValue() ?></span>
</span>
<?php if (!$loanappliedcancelled->isConfirm()) { ?>
<input type="hidden" data-table="loanappliedcancelled" data-field="x_totalamountapplied" name="x<?php echo $loanappliedcancelled_grid->RowIndex ?>_totalamountapplied" id="x<?php echo $loanappliedcancelled_grid->RowIndex ?>_totalamountapplied" value="<?php echo HtmlEncode($loanappliedcancelled_grid->totalamountapplied->FormValue) ?>">
<input type="hidden" data-table="loanappliedcancelled" data-field="x_totalamountapplied" name="o<?php echo $loanappliedcancelled_grid->RowIndex ?>_totalamountapplied" id="o<?php echo $loanappliedcancelled_grid->RowIndex ?>_totalamountapplied" value="<?php echo HtmlEncode($loanappliedcancelled_grid->totalamountapplied->OldValue) ?>">
<?php } else { ?>
<input type="hidden" data-table="loanappliedcancelled" data-field="x_totalamountapplied" name="floanappliedcancelledgrid$x<?php echo $loanappliedcancelled_grid->RowIndex ?>_totalamountapplied" id="floanappliedcancelledgrid$x<?php echo $loanappliedcancelled_grid->RowIndex ?>_totalamountapplied" value="<?php echo HtmlEncode($loanappliedcancelled_grid->totalamountapplied->FormValue) ?>">
<input type="hidden" data-table="loanappliedcancelled" data-field="x_totalamountapplied" name="floanappliedcancelledgrid$o<?php echo $loanappliedcancelled_grid->RowIndex ?>_totalamountapplied" id="floanappliedcancelledgrid$o<?php echo $loanappliedcancelled_grid->RowIndex ?>_totalamountapplied" value="<?php echo HtmlEncode($loanappliedcancelled_grid->totalamountapplied->OldValue) ?>">
<?php } ?>
<?php } ?>
</td>
	<?php } ?>
	<?php if ($loanappliedcancelled_grid->taxamountbreakdown->Visible) { // taxamountbreakdown ?>
		<td data-name="taxamountbreakdown" <?php echo $loanappliedcancelled_grid->taxamountbreakdown->cellAttributes() ?>>
<?php if ($loanappliedcancelled->RowType == ROWTYPE_ADD) { // Add record ?>
<span id="el<?php echo $loanappliedcancelled_grid->RowCount ?>_loanappliedcancelled_taxamountbreakdown" class="form-group">
<input type="text" data-table="loanappliedcancelled" data-field="x_taxamountbreakdown" name="x<?php echo $loanappliedcancelled_grid->RowIndex ?>_taxamountbreakdown" id="x<?php echo $loanappliedcancelled_grid->RowIndex ?>_taxamountbreakdown" size="30" maxlength="15" placeholder="<?php echo HtmlEncode($loanappliedcancelled_grid->taxamountbreakdown->getPlaceHolder()) ?>" value="<?php echo $loanappliedcancelled_grid->taxamountbreakdown->EditValue ?>"<?php echo $loanappliedcancelled_grid->taxamountbreakdown->editAttributes() ?>>
</span>
<input type="hidden" data-table="loanappliedcancelled" data-field="x_taxamountbreakdown" name="o<?php echo $loanappliedcancelled_grid->RowIndex ?>_taxamountbreakdown" id="o<?php echo $loanappliedcancelled_grid->RowIndex ?>_taxamountbreakdown" value="<?php echo HtmlEncode($loanappliedcancelled_grid->taxamountbreakdown->OldValue) ?>">
<?php } ?>
<?php if ($loanappliedcancelled->RowType == ROWTYPE_EDIT) { // Edit record ?>
<span id="el<?php echo $loanappliedcancelled_grid->RowCount ?>_loanappliedcancelled_taxamountbreakdown" class="form-group">
<input type="text" data-table="loanappliedcancelled" data-field="x_taxamountbreakdown" name="x<?php echo $loanappliedcancelled_grid->RowIndex ?>_taxamountbreakdown" id="x<?php echo $loanappliedcancelled_grid->RowIndex ?>_taxamountbreakdown" size="30" maxlength="15" placeholder="<?php echo HtmlEncode($loanappliedcancelled_grid->taxamountbreakdown->getPlaceHolder()) ?>" value="<?php echo $loanappliedcancelled_grid->taxamountbreakdown->EditValue ?>"<?php echo $loanappliedcancelled_grid->taxamountbreakdown->editAttributes() ?>>
</span>
<?php } ?>
<?php if ($loanappliedcancelled->RowType == ROWTYPE_VIEW) { // View record ?>
<span id="el<?php echo $loanappliedcancelled_grid->RowCount ?>_loanappliedcancelled_taxamountbreakdown">
<span<?php echo $loanappliedcancelled_grid->taxamountbreakdown->viewAttributes() ?>><?php echo $loanappliedcancelled_grid->taxamountbreakdown->getViewValue() ?></span>
</span>
<?php if (!$loanappliedcancelled->isConfirm()) { ?>
<input type="hidden" data-table="loanappliedcancelled" data-field="x_taxamountbreakdown" name="x<?php echo $loanappliedcancelled_grid->RowIndex ?>_taxamountbreakdown" id="x<?php echo $loanappliedcancelled_grid->RowIndex ?>_taxamountbreakdown" value="<?php echo HtmlEncode($loanappliedcancelled_grid->taxamountbreakdown->FormValue) ?>">
<input type="hidden" data-table="loanappliedcancelled" data-field="x_taxamountbreakdown" name="o<?php echo $loanappliedcancelled_grid->RowIndex ?>_taxamountbreakdown" id="o<?php echo $loanappliedcancelled_grid->RowIndex ?>_taxamountbreakdown" value="<?php echo HtmlEncode($loanappliedcancelled_grid->taxamountbreakdown->OldValue) ?>">
<?php } else { ?>
<input type="hidden" data-table="loanappliedcancelled" data-field="x_taxamountbreakdown" name="floanappliedcancelledgrid$x<?php echo $loanappliedcancelled_grid->RowIndex ?>_taxamountbreakdown" id="floanappliedcancelledgrid$x<?php echo $loanappliedcancelled_grid->RowIndex ?>_taxamountbreakdown" value="<?php echo HtmlEncode($loanappliedcancelled_grid->taxamountbreakdown->FormValue) ?>">
<input type="hidden" data-table="loanappliedcancelled" data-field="x_taxamountbreakdown" name="floanappliedcancelledgrid$o<?php echo $loanappliedcancelled_grid->RowIndex ?>_taxamountbreakdown" id="floanappliedcancelledgrid$o<?php echo $loanappliedcancelled_grid->RowIndex ?>_taxamountbreakdown" value="<?php echo HtmlEncode($loanappliedcancelled_grid->taxamountbreakdown->OldValue) ?>">
<?php } ?>
<?php } ?>
</td>
	<?php } ?>
	<?php if ($loanappliedcancelled_grid->feesystembreakdown->Visible) { // feesystembreakdown ?>
		<td data-name="feesystembreakdown" <?php echo $loanappliedcancelled_grid->feesystembreakdown->cellAttributes() ?>>
<?php if ($loanappliedcancelled->RowType == ROWTYPE_ADD) { // Add record ?>
<span id="el<?php echo $loanappliedcancelled_grid->RowCount ?>_loanappliedcancelled_feesystembreakdown" class="form-group">
<input type="text" data-table="loanappliedcancelled" data-field="x_feesystembreakdown" name="x<?php echo $loanappliedcancelled_grid->RowIndex ?>_feesystembreakdown" id="x<?php echo $loanappliedcancelled_grid->RowIndex ?>_feesystembreakdown" size="30" maxlength="12" placeholder="<?php echo HtmlEncode($loanappliedcancelled_grid->feesystembreakdown->getPlaceHolder()) ?>" value="<?php echo $loanappliedcancelled_grid->feesystembreakdown->EditValue ?>"<?php echo $loanappliedcancelled_grid->feesystembreakdown->editAttributes() ?>>
</span>
<input type="hidden" data-table="loanappliedcancelled" data-field="x_feesystembreakdown" name="o<?php echo $loanappliedcancelled_grid->RowIndex ?>_feesystembreakdown" id="o<?php echo $loanappliedcancelled_grid->RowIndex ?>_feesystembreakdown" value="<?php echo HtmlEncode($loanappliedcancelled_grid->feesystembreakdown->OldValue) ?>">
<?php } ?>
<?php if ($loanappliedcancelled->RowType == ROWTYPE_EDIT) { // Edit record ?>
<span id="el<?php echo $loanappliedcancelled_grid->RowCount ?>_loanappliedcancelled_feesystembreakdown" class="form-group">
<input type="text" data-table="loanappliedcancelled" data-field="x_feesystembreakdown" name="x<?php echo $loanappliedcancelled_grid->RowIndex ?>_feesystembreakdown" id="x<?php echo $loanappliedcancelled_grid->RowIndex ?>_feesystembreakdown" size="30" maxlength="12" placeholder="<?php echo HtmlEncode($loanappliedcancelled_grid->feesystembreakdown->getPlaceHolder()) ?>" value="<?php echo $loanappliedcancelled_grid->feesystembreakdown->EditValue ?>"<?php echo $loanappliedcancelled_grid->feesystembreakdown->editAttributes() ?>>
</span>
<?php } ?>
<?php if ($loanappliedcancelled->RowType == ROWTYPE_VIEW) { // View record ?>
<span id="el<?php echo $loanappliedcancelled_grid->RowCount ?>_loanappliedcancelled_feesystembreakdown">
<span<?php echo $loanappliedcancelled_grid->feesystembreakdown->viewAttributes() ?>><?php echo $loanappliedcancelled_grid->feesystembreakdown->getViewValue() ?></span>
</span>
<?php if (!$loanappliedcancelled->isConfirm()) { ?>
<input type="hidden" data-table="loanappliedcancelled" data-field="x_feesystembreakdown" name="x<?php echo $loanappliedcancelled_grid->RowIndex ?>_feesystembreakdown" id="x<?php echo $loanappliedcancelled_grid->RowIndex ?>_feesystembreakdown" value="<?php echo HtmlEncode($loanappliedcancelled_grid->feesystembreakdown->FormValue) ?>">
<input type="hidden" data-table="loanappliedcancelled" data-field="x_feesystembreakdown" name="o<?php echo $loanappliedcancelled_grid->RowIndex ?>_feesystembreakdown" id="o<?php echo $loanappliedcancelled_grid->RowIndex ?>_feesystembreakdown" value="<?php echo HtmlEncode($loanappliedcancelled_grid->feesystembreakdown->OldValue) ?>">
<?php } else { ?>
<input type="hidden" data-table="loanappliedcancelled" data-field="x_feesystembreakdown" name="floanappliedcancelledgrid$x<?php echo $loanappliedcancelled_grid->RowIndex ?>_feesystembreakdown" id="floanappliedcancelledgrid$x<?php echo $loanappliedcancelled_grid->RowIndex ?>_feesystembreakdown" value="<?php echo HtmlEncode($loanappliedcancelled_grid->feesystembreakdown->FormValue) ?>">
<input type="hidden" data-table="loanappliedcancelled" data-field="x_feesystembreakdown" name="floanappliedcancelledgrid$o<?php echo $loanappliedcancelled_grid->RowIndex ?>_feesystembreakdown" id="floanappliedcancelledgrid$o<?php echo $loanappliedcancelled_grid->RowIndex ?>_feesystembreakdown" value="<?php echo HtmlEncode($loanappliedcancelled_grid->feesystembreakdown->OldValue) ?>">
<?php } ?>
<?php } ?>
</td>
	<?php } ?>
	<?php if ($loanappliedcancelled_grid->feeexternalbreakdown->Visible) { // feeexternalbreakdown ?>
		<td data-name="feeexternalbreakdown" <?php echo $loanappliedcancelled_grid->feeexternalbreakdown->cellAttributes() ?>>
<?php if ($loanappliedcancelled->RowType == ROWTYPE_ADD) { // Add record ?>
<span id="el<?php echo $loanappliedcancelled_grid->RowCount ?>_loanappliedcancelled_feeexternalbreakdown" class="form-group">
<input type="text" data-table="loanappliedcancelled" data-field="x_feeexternalbreakdown" name="x<?php echo $loanappliedcancelled_grid->RowIndex ?>_feeexternalbreakdown" id="x<?php echo $loanappliedcancelled_grid->RowIndex ?>_feeexternalbreakdown" size="30" maxlength="12" placeholder="<?php echo HtmlEncode($loanappliedcancelled_grid->feeexternalbreakdown->getPlaceHolder()) ?>" value="<?php echo $loanappliedcancelled_grid->feeexternalbreakdown->EditValue ?>"<?php echo $loanappliedcancelled_grid->feeexternalbreakdown->editAttributes() ?>>
</span>
<input type="hidden" data-table="loanappliedcancelled" data-field="x_feeexternalbreakdown" name="o<?php echo $loanappliedcancelled_grid->RowIndex ?>_feeexternalbreakdown" id="o<?php echo $loanappliedcancelled_grid->RowIndex ?>_feeexternalbreakdown" value="<?php echo HtmlEncode($loanappliedcancelled_grid->feeexternalbreakdown->OldValue) ?>">
<?php } ?>
<?php if ($loanappliedcancelled->RowType == ROWTYPE_EDIT) { // Edit record ?>
<span id="el<?php echo $loanappliedcancelled_grid->RowCount ?>_loanappliedcancelled_feeexternalbreakdown" class="form-group">
<input type="text" data-table="loanappliedcancelled" data-field="x_feeexternalbreakdown" name="x<?php echo $loanappliedcancelled_grid->RowIndex ?>_feeexternalbreakdown" id="x<?php echo $loanappliedcancelled_grid->RowIndex ?>_feeexternalbreakdown" size="30" maxlength="12" placeholder="<?php echo HtmlEncode($loanappliedcancelled_grid->feeexternalbreakdown->getPlaceHolder()) ?>" value="<?php echo $loanappliedcancelled_grid->feeexternalbreakdown->EditValue ?>"<?php echo $loanappliedcancelled_grid->feeexternalbreakdown->editAttributes() ?>>
</span>
<?php } ?>
<?php if ($loanappliedcancelled->RowType == ROWTYPE_VIEW) { // View record ?>
<span id="el<?php echo $loanappliedcancelled_grid->RowCount ?>_loanappliedcancelled_feeexternalbreakdown">
<span<?php echo $loanappliedcancelled_grid->feeexternalbreakdown->viewAttributes() ?>><?php echo $loanappliedcancelled_grid->feeexternalbreakdown->getViewValue() ?></span>
</span>
<?php if (!$loanappliedcancelled->isConfirm()) { ?>
<input type="hidden" data-table="loanappliedcancelled" data-field="x_feeexternalbreakdown" name="x<?php echo $loanappliedcancelled_grid->RowIndex ?>_feeexternalbreakdown" id="x<?php echo $loanappliedcancelled_grid->RowIndex ?>_feeexternalbreakdown" value="<?php echo HtmlEncode($loanappliedcancelled_grid->feeexternalbreakdown->FormValue) ?>">
<input type="hidden" data-table="loanappliedcancelled" data-field="x_feeexternalbreakdown" name="o<?php echo $loanappliedcancelled_grid->RowIndex ?>_feeexternalbreakdown" id="o<?php echo $loanappliedcancelled_grid->RowIndex ?>_feeexternalbreakdown" value="<?php echo HtmlEncode($loanappliedcancelled_grid->feeexternalbreakdown->OldValue) ?>">
<?php } else { ?>
<input type="hidden" data-table="loanappliedcancelled" data-field="x_feeexternalbreakdown" name="floanappliedcancelledgrid$x<?php echo $loanappliedcancelled_grid->RowIndex ?>_feeexternalbreakdown" id="floanappliedcancelledgrid$x<?php echo $loanappliedcancelled_grid->RowIndex ?>_feeexternalbreakdown" value="<?php echo HtmlEncode($loanappliedcancelled_grid->feeexternalbreakdown->FormValue) ?>">
<input type="hidden" data-table="loanappliedcancelled" data-field="x_feeexternalbreakdown" name="floanappliedcancelledgrid$o<?php echo $loanappliedcancelled_grid->RowIndex ?>_feeexternalbreakdown" id="floanappliedcancelledgrid$o<?php echo $loanappliedcancelled_grid->RowIndex ?>_feeexternalbreakdown" value="<?php echo HtmlEncode($loanappliedcancelled_grid->feeexternalbreakdown->OldValue) ?>">
<?php } ?>
<?php } ?>
</td>
	<?php } ?>
	<?php if ($loanappliedcancelled_grid->feefranchiseebreakdown->Visible) { // feefranchiseebreakdown ?>
		<td data-name="feefranchiseebreakdown" <?php echo $loanappliedcancelled_grid->feefranchiseebreakdown->cellAttributes() ?>>
<?php if ($loanappliedcancelled->RowType == ROWTYPE_ADD) { // Add record ?>
<span id="el<?php echo $loanappliedcancelled_grid->RowCount ?>_loanappliedcancelled_feefranchiseebreakdown" class="form-group">
<input type="text" data-table="loanappliedcancelled" data-field="x_feefranchiseebreakdown" name="x<?php echo $loanappliedcancelled_grid->RowIndex ?>_feefranchiseebreakdown" id="x<?php echo $loanappliedcancelled_grid->RowIndex ?>_feefranchiseebreakdown" size="30" maxlength="12" placeholder="<?php echo HtmlEncode($loanappliedcancelled_grid->feefranchiseebreakdown->getPlaceHolder()) ?>" value="<?php echo $loanappliedcancelled_grid->feefranchiseebreakdown->EditValue ?>"<?php echo $loanappliedcancelled_grid->feefranchiseebreakdown->editAttributes() ?>>
</span>
<input type="hidden" data-table="loanappliedcancelled" data-field="x_feefranchiseebreakdown" name="o<?php echo $loanappliedcancelled_grid->RowIndex ?>_feefranchiseebreakdown" id="o<?php echo $loanappliedcancelled_grid->RowIndex ?>_feefranchiseebreakdown" value="<?php echo HtmlEncode($loanappliedcancelled_grid->feefranchiseebreakdown->OldValue) ?>">
<?php } ?>
<?php if ($loanappliedcancelled->RowType == ROWTYPE_EDIT) { // Edit record ?>
<span id="el<?php echo $loanappliedcancelled_grid->RowCount ?>_loanappliedcancelled_feefranchiseebreakdown" class="form-group">
<input type="text" data-table="loanappliedcancelled" data-field="x_feefranchiseebreakdown" name="x<?php echo $loanappliedcancelled_grid->RowIndex ?>_feefranchiseebreakdown" id="x<?php echo $loanappliedcancelled_grid->RowIndex ?>_feefranchiseebreakdown" size="30" maxlength="12" placeholder="<?php echo HtmlEncode($loanappliedcancelled_grid->feefranchiseebreakdown->getPlaceHolder()) ?>" value="<?php echo $loanappliedcancelled_grid->feefranchiseebreakdown->EditValue ?>"<?php echo $loanappliedcancelled_grid->feefranchiseebreakdown->editAttributes() ?>>
</span>
<?php } ?>
<?php if ($loanappliedcancelled->RowType == ROWTYPE_VIEW) { // View record ?>
<span id="el<?php echo $loanappliedcancelled_grid->RowCount ?>_loanappliedcancelled_feefranchiseebreakdown">
<span<?php echo $loanappliedcancelled_grid->feefranchiseebreakdown->viewAttributes() ?>><?php echo $loanappliedcancelled_grid->feefranchiseebreakdown->getViewValue() ?></span>
</span>
<?php if (!$loanappliedcancelled->isConfirm()) { ?>
<input type="hidden" data-table="loanappliedcancelled" data-field="x_feefranchiseebreakdown" name="x<?php echo $loanappliedcancelled_grid->RowIndex ?>_feefranchiseebreakdown" id="x<?php echo $loanappliedcancelled_grid->RowIndex ?>_feefranchiseebreakdown" value="<?php echo HtmlEncode($loanappliedcancelled_grid->feefranchiseebreakdown->FormValue) ?>">
<input type="hidden" data-table="loanappliedcancelled" data-field="x_feefranchiseebreakdown" name="o<?php echo $loanappliedcancelled_grid->RowIndex ?>_feefranchiseebreakdown" id="o<?php echo $loanappliedcancelled_grid->RowIndex ?>_feefranchiseebreakdown" value="<?php echo HtmlEncode($loanappliedcancelled_grid->feefranchiseebreakdown->OldValue) ?>">
<?php } else { ?>
<input type="hidden" data-table="loanappliedcancelled" data-field="x_feefranchiseebreakdown" name="floanappliedcancelledgrid$x<?php echo $loanappliedcancelled_grid->RowIndex ?>_feefranchiseebreakdown" id="floanappliedcancelledgrid$x<?php echo $loanappliedcancelled_grid->RowIndex ?>_feefranchiseebreakdown" value="<?php echo HtmlEncode($loanappliedcancelled_grid->feefranchiseebreakdown->FormValue) ?>">
<input type="hidden" data-table="loanappliedcancelled" data-field="x_feefranchiseebreakdown" name="floanappliedcancelledgrid$o<?php echo $loanappliedcancelled_grid->RowIndex ?>_feefranchiseebreakdown" id="floanappliedcancelledgrid$o<?php echo $loanappliedcancelled_grid->RowIndex ?>_feefranchiseebreakdown" value="<?php echo HtmlEncode($loanappliedcancelled_grid->feefranchiseebreakdown->OldValue) ?>">
<?php } ?>
<?php } ?>
</td>
	<?php } ?>
	<?php if ($loanappliedcancelled_grid->feeresellerbreakdown->Visible) { // feeresellerbreakdown ?>
		<td data-name="feeresellerbreakdown" <?php echo $loanappliedcancelled_grid->feeresellerbreakdown->cellAttributes() ?>>
<?php if ($loanappliedcancelled->RowType == ROWTYPE_ADD) { // Add record ?>
<span id="el<?php echo $loanappliedcancelled_grid->RowCount ?>_loanappliedcancelled_feeresellerbreakdown" class="form-group">
<input type="text" data-table="loanappliedcancelled" data-field="x_feeresellerbreakdown" name="x<?php echo $loanappliedcancelled_grid->RowIndex ?>_feeresellerbreakdown" id="x<?php echo $loanappliedcancelled_grid->RowIndex ?>_feeresellerbreakdown" size="30" maxlength="12" placeholder="<?php echo HtmlEncode($loanappliedcancelled_grid->feeresellerbreakdown->getPlaceHolder()) ?>" value="<?php echo $loanappliedcancelled_grid->feeresellerbreakdown->EditValue ?>"<?php echo $loanappliedcancelled_grid->feeresellerbreakdown->editAttributes() ?>>
</span>
<input type="hidden" data-table="loanappliedcancelled" data-field="x_feeresellerbreakdown" name="o<?php echo $loanappliedcancelled_grid->RowIndex ?>_feeresellerbreakdown" id="o<?php echo $loanappliedcancelled_grid->RowIndex ?>_feeresellerbreakdown" value="<?php echo HtmlEncode($loanappliedcancelled_grid->feeresellerbreakdown->OldValue) ?>">
<?php } ?>
<?php if ($loanappliedcancelled->RowType == ROWTYPE_EDIT) { // Edit record ?>
<span id="el<?php echo $loanappliedcancelled_grid->RowCount ?>_loanappliedcancelled_feeresellerbreakdown" class="form-group">
<input type="text" data-table="loanappliedcancelled" data-field="x_feeresellerbreakdown" name="x<?php echo $loanappliedcancelled_grid->RowIndex ?>_feeresellerbreakdown" id="x<?php echo $loanappliedcancelled_grid->RowIndex ?>_feeresellerbreakdown" size="30" maxlength="12" placeholder="<?php echo HtmlEncode($loanappliedcancelled_grid->feeresellerbreakdown->getPlaceHolder()) ?>" value="<?php echo $loanappliedcancelled_grid->feeresellerbreakdown->EditValue ?>"<?php echo $loanappliedcancelled_grid->feeresellerbreakdown->editAttributes() ?>>
</span>
<?php } ?>
<?php if ($loanappliedcancelled->RowType == ROWTYPE_VIEW) { // View record ?>
<span id="el<?php echo $loanappliedcancelled_grid->RowCount ?>_loanappliedcancelled_feeresellerbreakdown">
<span<?php echo $loanappliedcancelled_grid->feeresellerbreakdown->viewAttributes() ?>><?php echo $loanappliedcancelled_grid->feeresellerbreakdown->getViewValue() ?></span>
</span>
<?php if (!$loanappliedcancelled->isConfirm()) { ?>
<input type="hidden" data-table="loanappliedcancelled" data-field="x_feeresellerbreakdown" name="x<?php echo $loanappliedcancelled_grid->RowIndex ?>_feeresellerbreakdown" id="x<?php echo $loanappliedcancelled_grid->RowIndex ?>_feeresellerbreakdown" value="<?php echo HtmlEncode($loanappliedcancelled_grid->feeresellerbreakdown->FormValue) ?>">
<input type="hidden" data-table="loanappliedcancelled" data-field="x_feeresellerbreakdown" name="o<?php echo $loanappliedcancelled_grid->RowIndex ?>_feeresellerbreakdown" id="o<?php echo $loanappliedcancelled_grid->RowIndex ?>_feeresellerbreakdown" value="<?php echo HtmlEncode($loanappliedcancelled_grid->feeresellerbreakdown->OldValue) ?>">
<?php } else { ?>
<input type="hidden" data-table="loanappliedcancelled" data-field="x_feeresellerbreakdown" name="floanappliedcancelledgrid$x<?php echo $loanappliedcancelled_grid->RowIndex ?>_feeresellerbreakdown" id="floanappliedcancelledgrid$x<?php echo $loanappliedcancelled_grid->RowIndex ?>_feeresellerbreakdown" value="<?php echo HtmlEncode($loanappliedcancelled_grid->feeresellerbreakdown->FormValue) ?>">
<input type="hidden" data-table="loanappliedcancelled" data-field="x_feeresellerbreakdown" name="floanappliedcancelledgrid$o<?php echo $loanappliedcancelled_grid->RowIndex ?>_feeresellerbreakdown" id="floanappliedcancelledgrid$o<?php echo $loanappliedcancelled_grid->RowIndex ?>_feeresellerbreakdown" value="<?php echo HtmlEncode($loanappliedcancelled_grid->feeresellerbreakdown->OldValue) ?>">
<?php } ?>
<?php } ?>
</td>
	<?php } ?>
	<?php if ($loanappliedcancelled_grid->cancellationtime->Visible) { // cancellationtime ?>
		<td data-name="cancellationtime" <?php echo $loanappliedcancelled_grid->cancellationtime->cellAttributes() ?>>
<?php if ($loanappliedcancelled->RowType == ROWTYPE_ADD) { // Add record ?>
<span id="el<?php echo $loanappliedcancelled_grid->RowCount ?>_loanappliedcancelled_cancellationtime" class="form-group">
<input type="text" data-table="loanappliedcancelled" data-field="x_cancellationtime" name="x<?php echo $loanappliedcancelled_grid->RowIndex ?>_cancellationtime" id="x<?php echo $loanappliedcancelled_grid->RowIndex ?>_cancellationtime" maxlength="19" placeholder="<?php echo HtmlEncode($loanappliedcancelled_grid->cancellationtime->getPlaceHolder()) ?>" value="<?php echo $loanappliedcancelled_grid->cancellationtime->EditValue ?>"<?php echo $loanappliedcancelled_grid->cancellationtime->editAttributes() ?>>
<?php if (!$loanappliedcancelled_grid->cancellationtime->ReadOnly && !$loanappliedcancelled_grid->cancellationtime->Disabled && !isset($loanappliedcancelled_grid->cancellationtime->EditAttrs["readonly"]) && !isset($loanappliedcancelled_grid->cancellationtime->EditAttrs["disabled"])) { ?>
<script>
loadjs.ready(["floanappliedcancelledgrid", "datetimepicker"], function() {
	ew.createDateTimePicker("floanappliedcancelledgrid", "x<?php echo $loanappliedcancelled_grid->RowIndex ?>_cancellationtime", {"ignoreReadonly":true,"useCurrent":false,"format":0});
});
</script>
<?php } ?>
</span>
<input type="hidden" data-table="loanappliedcancelled" data-field="x_cancellationtime" name="o<?php echo $loanappliedcancelled_grid->RowIndex ?>_cancellationtime" id="o<?php echo $loanappliedcancelled_grid->RowIndex ?>_cancellationtime" value="<?php echo HtmlEncode($loanappliedcancelled_grid->cancellationtime->OldValue) ?>">
<?php } ?>
<?php if ($loanappliedcancelled->RowType == ROWTYPE_EDIT) { // Edit record ?>
<span id="el<?php echo $loanappliedcancelled_grid->RowCount ?>_loanappliedcancelled_cancellationtime" class="form-group">
<input type="text" data-table="loanappliedcancelled" data-field="x_cancellationtime" name="x<?php echo $loanappliedcancelled_grid->RowIndex ?>_cancellationtime" id="x<?php echo $loanappliedcancelled_grid->RowIndex ?>_cancellationtime" maxlength="19" placeholder="<?php echo HtmlEncode($loanappliedcancelled_grid->cancellationtime->getPlaceHolder()) ?>" value="<?php echo $loanappliedcancelled_grid->cancellationtime->EditValue ?>"<?php echo $loanappliedcancelled_grid->cancellationtime->editAttributes() ?>>
<?php if (!$loanappliedcancelled_grid->cancellationtime->ReadOnly && !$loanappliedcancelled_grid->cancellationtime->Disabled && !isset($loanappliedcancelled_grid->cancellationtime->EditAttrs["readonly"]) && !isset($loanappliedcancelled_grid->cancellationtime->EditAttrs["disabled"])) { ?>
<script>
loadjs.ready(["floanappliedcancelledgrid", "datetimepicker"], function() {
	ew.createDateTimePicker("floanappliedcancelledgrid", "x<?php echo $loanappliedcancelled_grid->RowIndex ?>_cancellationtime", {"ignoreReadonly":true,"useCurrent":false,"format":0});
});
</script>
<?php } ?>
</span>
<?php } ?>
<?php if ($loanappliedcancelled->RowType == ROWTYPE_VIEW) { // View record ?>
<span id="el<?php echo $loanappliedcancelled_grid->RowCount ?>_loanappliedcancelled_cancellationtime">
<span<?php echo $loanappliedcancelled_grid->cancellationtime->viewAttributes() ?>><?php echo $loanappliedcancelled_grid->cancellationtime->getViewValue() ?></span>
</span>
<?php if (!$loanappliedcancelled->isConfirm()) { ?>
<input type="hidden" data-table="loanappliedcancelled" data-field="x_cancellationtime" name="x<?php echo $loanappliedcancelled_grid->RowIndex ?>_cancellationtime" id="x<?php echo $loanappliedcancelled_grid->RowIndex ?>_cancellationtime" value="<?php echo HtmlEncode($loanappliedcancelled_grid->cancellationtime->FormValue) ?>">
<input type="hidden" data-table="loanappliedcancelled" data-field="x_cancellationtime" name="o<?php echo $loanappliedcancelled_grid->RowIndex ?>_cancellationtime" id="o<?php echo $loanappliedcancelled_grid->RowIndex ?>_cancellationtime" value="<?php echo HtmlEncode($loanappliedcancelled_grid->cancellationtime->OldValue) ?>">
<?php } else { ?>
<input type="hidden" data-table="loanappliedcancelled" data-field="x_cancellationtime" name="floanappliedcancelledgrid$x<?php echo $loanappliedcancelled_grid->RowIndex ?>_cancellationtime" id="floanappliedcancelledgrid$x<?php echo $loanappliedcancelled_grid->RowIndex ?>_cancellationtime" value="<?php echo HtmlEncode($loanappliedcancelled_grid->cancellationtime->FormValue) ?>">
<input type="hidden" data-table="loanappliedcancelled" data-field="x_cancellationtime" name="floanappliedcancelledgrid$o<?php echo $loanappliedcancelled_grid->RowIndex ?>_cancellationtime" id="floanappliedcancelledgrid$o<?php echo $loanappliedcancelled_grid->RowIndex ?>_cancellationtime" value="<?php echo HtmlEncode($loanappliedcancelled_grid->cancellationtime->OldValue) ?>">
<?php } ?>
<?php } ?>
</td>
	<?php } ?>
	<?php if ($loanappliedcancelled_grid->cancellationrefno->Visible) { // cancellationrefno ?>
		<td data-name="cancellationrefno" <?php echo $loanappliedcancelled_grid->cancellationrefno->cellAttributes() ?>>
<?php if ($loanappliedcancelled->RowType == ROWTYPE_ADD) { // Add record ?>
<span id="el<?php echo $loanappliedcancelled_grid->RowCount ?>_loanappliedcancelled_cancellationrefno" class="form-group">
<input type="text" data-table="loanappliedcancelled" data-field="x_cancellationrefno" name="x<?php echo $loanappliedcancelled_grid->RowIndex ?>_cancellationrefno" id="x<?php echo $loanappliedcancelled_grid->RowIndex ?>_cancellationrefno" size="30" maxlength="100" placeholder="<?php echo HtmlEncode($loanappliedcancelled_grid->cancellationrefno->getPlaceHolder()) ?>" value="<?php echo $loanappliedcancelled_grid->cancellationrefno->EditValue ?>"<?php echo $loanappliedcancelled_grid->cancellationrefno->editAttributes() ?>>
</span>
<input type="hidden" data-table="loanappliedcancelled" data-field="x_cancellationrefno" name="o<?php echo $loanappliedcancelled_grid->RowIndex ?>_cancellationrefno" id="o<?php echo $loanappliedcancelled_grid->RowIndex ?>_cancellationrefno" value="<?php echo HtmlEncode($loanappliedcancelled_grid->cancellationrefno->OldValue) ?>">
<?php } ?>
<?php if ($loanappliedcancelled->RowType == ROWTYPE_EDIT) { // Edit record ?>
<span id="el<?php echo $loanappliedcancelled_grid->RowCount ?>_loanappliedcancelled_cancellationrefno" class="form-group">
<input type="text" data-table="loanappliedcancelled" data-field="x_cancellationrefno" name="x<?php echo $loanappliedcancelled_grid->RowIndex ?>_cancellationrefno" id="x<?php echo $loanappliedcancelled_grid->RowIndex ?>_cancellationrefno" size="30" maxlength="100" placeholder="<?php echo HtmlEncode($loanappliedcancelled_grid->cancellationrefno->getPlaceHolder()) ?>" value="<?php echo $loanappliedcancelled_grid->cancellationrefno->EditValue ?>"<?php echo $loanappliedcancelled_grid->cancellationrefno->editAttributes() ?>>
</span>
<?php } ?>
<?php if ($loanappliedcancelled->RowType == ROWTYPE_VIEW) { // View record ?>
<span id="el<?php echo $loanappliedcancelled_grid->RowCount ?>_loanappliedcancelled_cancellationrefno">
<span<?php echo $loanappliedcancelled_grid->cancellationrefno->viewAttributes() ?>><?php echo $loanappliedcancelled_grid->cancellationrefno->getViewValue() ?></span>
</span>
<?php if (!$loanappliedcancelled->isConfirm()) { ?>
<input type="hidden" data-table="loanappliedcancelled" data-field="x_cancellationrefno" name="x<?php echo $loanappliedcancelled_grid->RowIndex ?>_cancellationrefno" id="x<?php echo $loanappliedcancelled_grid->RowIndex ?>_cancellationrefno" value="<?php echo HtmlEncode($loanappliedcancelled_grid->cancellationrefno->FormValue) ?>">
<input type="hidden" data-table="loanappliedcancelled" data-field="x_cancellationrefno" name="o<?php echo $loanappliedcancelled_grid->RowIndex ?>_cancellationrefno" id="o<?php echo $loanappliedcancelled_grid->RowIndex ?>_cancellationrefno" value="<?php echo HtmlEncode($loanappliedcancelled_grid->cancellationrefno->OldValue) ?>">
<?php } else { ?>
<input type="hidden" data-table="loanappliedcancelled" data-field="x_cancellationrefno" name="floanappliedcancelledgrid$x<?php echo $loanappliedcancelled_grid->RowIndex ?>_cancellationrefno" id="floanappliedcancelledgrid$x<?php echo $loanappliedcancelled_grid->RowIndex ?>_cancellationrefno" value="<?php echo HtmlEncode($loanappliedcancelled_grid->cancellationrefno->FormValue) ?>">
<input type="hidden" data-table="loanappliedcancelled" data-field="x_cancellationrefno" name="floanappliedcancelledgrid$o<?php echo $loanappliedcancelled_grid->RowIndex ?>_cancellationrefno" id="floanappliedcancelledgrid$o<?php echo $loanappliedcancelled_grid->RowIndex ?>_cancellationrefno" value="<?php echo HtmlEncode($loanappliedcancelled_grid->cancellationrefno->OldValue) ?>">
<?php } ?>
<?php } ?>
</td>
	<?php } ?>
<?php

// Render list options (body, right)
$loanappliedcancelled_grid->ListOptions->render("body", "right", $loanappliedcancelled_grid->RowCount);
?>
	</tr>
<?php if ($loanappliedcancelled->RowType == ROWTYPE_ADD || $loanappliedcancelled->RowType == ROWTYPE_EDIT) { ?>
<script>
loadjs.ready(["floanappliedcancelledgrid", "load"], function() {
	floanappliedcancelledgrid.updateLists(<?php echo $loanappliedcancelled_grid->RowIndex ?>);
});
</script>
<?php } ?>
<?php
	}
	} // End delete row checking
	if (!$loanappliedcancelled_grid->isGridAdd() || $loanappliedcancelled->CurrentMode == "copy")
		if (!$loanappliedcancelled_grid->Recordset->EOF)
			$loanappliedcancelled_grid->Recordset->moveNext();
}
?>
<?php
	if ($loanappliedcancelled->CurrentMode == "add" || $loanappliedcancelled->CurrentMode == "copy" || $loanappliedcancelled->CurrentMode == "edit") {
		$loanappliedcancelled_grid->RowIndex = '$rowindex$';
		$loanappliedcancelled_grid->loadRowValues();

		// Set row properties
		$loanappliedcancelled->resetAttributes();
		$loanappliedcancelled->RowAttrs->merge(["data-rowindex" => $loanappliedcancelled_grid->RowIndex, "id" => "r0_loanappliedcancelled", "data-rowtype" => ROWTYPE_ADD]);
		$loanappliedcancelled->RowAttrs->appendClass("ew-template");
		$loanappliedcancelled->RowType = ROWTYPE_ADD;

		// Render row
		$loanappliedcancelled_grid->renderRow();

		// Render list options
		$loanappliedcancelled_grid->renderListOptions();
		$loanappliedcancelled_grid->StartRowCount = 0;
?>
	<tr <?php echo $loanappliedcancelled->rowAttributes() ?>>
<?php

// Render list options (body, left)
$loanappliedcancelled_grid->ListOptions->render("body", "left", $loanappliedcancelled_grid->RowIndex);
?>
	<?php if ($loanappliedcancelled_grid->applyid->Visible) { // applyid ?>
		<td data-name="applyid">
<?php if (!$loanappliedcancelled->isConfirm()) { ?>
<span id="el$rowindex$_loanappliedcancelled_applyid" class="form-group loanappliedcancelled_applyid">
<input type="text" data-table="loanappliedcancelled" data-field="x_applyid" name="x<?php echo $loanappliedcancelled_grid->RowIndex ?>_applyid" id="x<?php echo $loanappliedcancelled_grid->RowIndex ?>_applyid" size="30" maxlength="15" placeholder="<?php echo HtmlEncode($loanappliedcancelled_grid->applyid->getPlaceHolder()) ?>" value="<?php echo $loanappliedcancelled_grid->applyid->EditValue ?>"<?php echo $loanappliedcancelled_grid->applyid->editAttributes() ?>>
</span>
<?php } else { ?>
<span id="el$rowindex$_loanappliedcancelled_applyid" class="form-group loanappliedcancelled_applyid">
<span<?php echo $loanappliedcancelled_grid->applyid->viewAttributes() ?>><input type="text" readonly class="form-control-plaintext" value="<?php echo HtmlEncode(RemoveHtml($loanappliedcancelled_grid->applyid->ViewValue)) ?>"></span>
</span>
<input type="hidden" data-table="loanappliedcancelled" data-field="x_applyid" name="x<?php echo $loanappliedcancelled_grid->RowIndex ?>_applyid" id="x<?php echo $loanappliedcancelled_grid->RowIndex ?>_applyid" value="<?php echo HtmlEncode($loanappliedcancelled_grid->applyid->FormValue) ?>">
<?php } ?>
<input type="hidden" data-table="loanappliedcancelled" data-field="x_applyid" name="o<?php echo $loanappliedcancelled_grid->RowIndex ?>_applyid" id="o<?php echo $loanappliedcancelled_grid->RowIndex ?>_applyid" value="<?php echo HtmlEncode($loanappliedcancelled_grid->applyid->OldValue) ?>">
</td>
	<?php } ?>
	<?php if ($loanappliedcancelled_grid->loanid->Visible) { // loanid ?>
		<td data-name="loanid">
<?php if (!$loanappliedcancelled->isConfirm()) { ?>
<span id="el$rowindex$_loanappliedcancelled_loanid" class="form-group loanappliedcancelled_loanid">
<input type="text" data-table="loanappliedcancelled" data-field="x_loanid" name="x<?php echo $loanappliedcancelled_grid->RowIndex ?>_loanid" id="x<?php echo $loanappliedcancelled_grid->RowIndex ?>_loanid" size="30" maxlength="15" placeholder="<?php echo HtmlEncode($loanappliedcancelled_grid->loanid->getPlaceHolder()) ?>" value="<?php echo $loanappliedcancelled_grid->loanid->EditValue ?>"<?php echo $loanappliedcancelled_grid->loanid->editAttributes() ?>>
</span>
<?php } else { ?>
<span id="el$rowindex$_loanappliedcancelled_loanid" class="form-group loanappliedcancelled_loanid">
<span<?php echo $loanappliedcancelled_grid->loanid->viewAttributes() ?>><?php if (!EmptyString($loanappliedcancelled_grid->loanid->ViewValue) && $loanappliedcancelled_grid->loanid->linkAttributes() != "") { ?>
<a<?php echo $loanappliedcancelled_grid->loanid->linkAttributes() ?>><input type="text" readonly class="form-control-plaintext" value="<?php echo HtmlEncode(RemoveHtml($loanappliedcancelled_grid->loanid->ViewValue)) ?>"></a>
<?php } else { ?>
<input type="text" readonly class="form-control-plaintext" value="<?php echo HtmlEncode(RemoveHtml($loanappliedcancelled_grid->loanid->ViewValue)) ?>">
<?php } ?></span>
</span>
<input type="hidden" data-table="loanappliedcancelled" data-field="x_loanid" name="x<?php echo $loanappliedcancelled_grid->RowIndex ?>_loanid" id="x<?php echo $loanappliedcancelled_grid->RowIndex ?>_loanid" value="<?php echo HtmlEncode($loanappliedcancelled_grid->loanid->FormValue) ?>">
<?php } ?>
<input type="hidden" data-table="loanappliedcancelled" data-field="x_loanid" name="o<?php echo $loanappliedcancelled_grid->RowIndex ?>_loanid" id="o<?php echo $loanappliedcancelled_grid->RowIndex ?>_loanid" value="<?php echo HtmlEncode($loanappliedcancelled_grid->loanid->OldValue) ?>">
</td>
	<?php } ?>
	<?php if ($loanappliedcancelled_grid->paymentid->Visible) { // paymentid ?>
		<td data-name="paymentid">
<?php if (!$loanappliedcancelled->isConfirm()) { ?>
<?php if ($loanappliedcancelled_grid->paymentid->getSessionValue() != "") { ?>
<span id="el$rowindex$_loanappliedcancelled_paymentid" class="form-group loanappliedcancelled_paymentid">
<span<?php echo $loanappliedcancelled_grid->paymentid->viewAttributes() ?>><?php if (!EmptyString($loanappliedcancelled_grid->paymentid->ViewValue) && $loanappliedcancelled_grid->paymentid->linkAttributes() != "") { ?>
<a<?php echo $loanappliedcancelled_grid->paymentid->linkAttributes() ?>><input type="text" readonly class="form-control-plaintext" value="<?php echo HtmlEncode(RemoveHtml($loanappliedcancelled_grid->paymentid->ViewValue)) ?>"></a>
<?php } else { ?>
<input type="text" readonly class="form-control-plaintext" value="<?php echo HtmlEncode(RemoveHtml($loanappliedcancelled_grid->paymentid->ViewValue)) ?>">
<?php } ?></span>
</span>
<input type="hidden" id="x<?php echo $loanappliedcancelled_grid->RowIndex ?>_paymentid" name="x<?php echo $loanappliedcancelled_grid->RowIndex ?>_paymentid" value="<?php echo HtmlEncode($loanappliedcancelled_grid->paymentid->CurrentValue) ?>">
<?php } else { ?>
<span id="el$rowindex$_loanappliedcancelled_paymentid" class="form-group loanappliedcancelled_paymentid">
<input type="text" data-table="loanappliedcancelled" data-field="x_paymentid" name="x<?php echo $loanappliedcancelled_grid->RowIndex ?>_paymentid" id="x<?php echo $loanappliedcancelled_grid->RowIndex ?>_paymentid" size="30" maxlength="15" placeholder="<?php echo HtmlEncode($loanappliedcancelled_grid->paymentid->getPlaceHolder()) ?>" value="<?php echo $loanappliedcancelled_grid->paymentid->EditValue ?>"<?php echo $loanappliedcancelled_grid->paymentid->editAttributes() ?>>
</span>
<?php } ?>
<?php } else { ?>
<span id="el$rowindex$_loanappliedcancelled_paymentid" class="form-group loanappliedcancelled_paymentid">
<span<?php echo $loanappliedcancelled_grid->paymentid->viewAttributes() ?>><?php if (!EmptyString($loanappliedcancelled_grid->paymentid->ViewValue) && $loanappliedcancelled_grid->paymentid->linkAttributes() != "") { ?>
<a<?php echo $loanappliedcancelled_grid->paymentid->linkAttributes() ?>><input type="text" readonly class="form-control-plaintext" value="<?php echo HtmlEncode(RemoveHtml($loanappliedcancelled_grid->paymentid->ViewValue)) ?>"></a>
<?php } else { ?>
<input type="text" readonly class="form-control-plaintext" value="<?php echo HtmlEncode(RemoveHtml($loanappliedcancelled_grid->paymentid->ViewValue)) ?>">
<?php } ?></span>
</span>
<input type="hidden" data-table="loanappliedcancelled" data-field="x_paymentid" name="x<?php echo $loanappliedcancelled_grid->RowIndex ?>_paymentid" id="x<?php echo $loanappliedcancelled_grid->RowIndex ?>_paymentid" value="<?php echo HtmlEncode($loanappliedcancelled_grid->paymentid->FormValue) ?>">
<?php } ?>
<input type="hidden" data-table="loanappliedcancelled" data-field="x_paymentid" name="o<?php echo $loanappliedcancelled_grid->RowIndex ?>_paymentid" id="o<?php echo $loanappliedcancelled_grid->RowIndex ?>_paymentid" value="<?php echo HtmlEncode($loanappliedcancelled_grid->paymentid->OldValue) ?>">
</td>
	<?php } ?>
	<?php if ($loanappliedcancelled_grid->amountapplied->Visible) { // amountapplied ?>
		<td data-name="amountapplied">
<?php if (!$loanappliedcancelled->isConfirm()) { ?>
<span id="el$rowindex$_loanappliedcancelled_amountapplied" class="form-group loanappliedcancelled_amountapplied">
<input type="text" data-table="loanappliedcancelled" data-field="x_amountapplied" name="x<?php echo $loanappliedcancelled_grid->RowIndex ?>_amountapplied" id="x<?php echo $loanappliedcancelled_grid->RowIndex ?>_amountapplied" size="30" maxlength="15" placeholder="<?php echo HtmlEncode($loanappliedcancelled_grid->amountapplied->getPlaceHolder()) ?>" value="<?php echo $loanappliedcancelled_grid->amountapplied->EditValue ?>"<?php echo $loanappliedcancelled_grid->amountapplied->editAttributes() ?>>
</span>
<?php } else { ?>
<span id="el$rowindex$_loanappliedcancelled_amountapplied" class="form-group loanappliedcancelled_amountapplied">
<span<?php echo $loanappliedcancelled_grid->amountapplied->viewAttributes() ?>><input type="text" readonly class="form-control-plaintext" value="<?php echo HtmlEncode(RemoveHtml($loanappliedcancelled_grid->amountapplied->ViewValue)) ?>"></span>
</span>
<input type="hidden" data-table="loanappliedcancelled" data-field="x_amountapplied" name="x<?php echo $loanappliedcancelled_grid->RowIndex ?>_amountapplied" id="x<?php echo $loanappliedcancelled_grid->RowIndex ?>_amountapplied" value="<?php echo HtmlEncode($loanappliedcancelled_grid->amountapplied->FormValue) ?>">
<?php } ?>
<input type="hidden" data-table="loanappliedcancelled" data-field="x_amountapplied" name="o<?php echo $loanappliedcancelled_grid->RowIndex ?>_amountapplied" id="o<?php echo $loanappliedcancelled_grid->RowIndex ?>_amountapplied" value="<?php echo HtmlEncode($loanappliedcancelled_grid->amountapplied->OldValue) ?>">
</td>
	<?php } ?>
	<?php if ($loanappliedcancelled_grid->feesapplied->Visible) { // feesapplied ?>
		<td data-name="feesapplied">
<?php if (!$loanappliedcancelled->isConfirm()) { ?>
<span id="el$rowindex$_loanappliedcancelled_feesapplied" class="form-group loanappliedcancelled_feesapplied">
<input type="text" data-table="loanappliedcancelled" data-field="x_feesapplied" name="x<?php echo $loanappliedcancelled_grid->RowIndex ?>_feesapplied" id="x<?php echo $loanappliedcancelled_grid->RowIndex ?>_feesapplied" size="30" maxlength="15" placeholder="<?php echo HtmlEncode($loanappliedcancelled_grid->feesapplied->getPlaceHolder()) ?>" value="<?php echo $loanappliedcancelled_grid->feesapplied->EditValue ?>"<?php echo $loanappliedcancelled_grid->feesapplied->editAttributes() ?>>
</span>
<?php } else { ?>
<span id="el$rowindex$_loanappliedcancelled_feesapplied" class="form-group loanappliedcancelled_feesapplied">
<span<?php echo $loanappliedcancelled_grid->feesapplied->viewAttributes() ?>><input type="text" readonly class="form-control-plaintext" value="<?php echo HtmlEncode(RemoveHtml($loanappliedcancelled_grid->feesapplied->ViewValue)) ?>"></span>
</span>
<input type="hidden" data-table="loanappliedcancelled" data-field="x_feesapplied" name="x<?php echo $loanappliedcancelled_grid->RowIndex ?>_feesapplied" id="x<?php echo $loanappliedcancelled_grid->RowIndex ?>_feesapplied" value="<?php echo HtmlEncode($loanappliedcancelled_grid->feesapplied->FormValue) ?>">
<?php } ?>
<input type="hidden" data-table="loanappliedcancelled" data-field="x_feesapplied" name="o<?php echo $loanappliedcancelled_grid->RowIndex ?>_feesapplied" id="o<?php echo $loanappliedcancelled_grid->RowIndex ?>_feesapplied" value="<?php echo HtmlEncode($loanappliedcancelled_grid->feesapplied->OldValue) ?>">
</td>
	<?php } ?>
	<?php if ($loanappliedcancelled_grid->totalamountapplied->Visible) { // totalamountapplied ?>
		<td data-name="totalamountapplied">
<?php if (!$loanappliedcancelled->isConfirm()) { ?>
<span id="el$rowindex$_loanappliedcancelled_totalamountapplied" class="form-group loanappliedcancelled_totalamountapplied">
<input type="text" data-table="loanappliedcancelled" data-field="x_totalamountapplied" name="x<?php echo $loanappliedcancelled_grid->RowIndex ?>_totalamountapplied" id="x<?php echo $loanappliedcancelled_grid->RowIndex ?>_totalamountapplied" size="30" maxlength="15" placeholder="<?php echo HtmlEncode($loanappliedcancelled_grid->totalamountapplied->getPlaceHolder()) ?>" value="<?php echo $loanappliedcancelled_grid->totalamountapplied->EditValue ?>"<?php echo $loanappliedcancelled_grid->totalamountapplied->editAttributes() ?>>
</span>
<?php } else { ?>
<span id="el$rowindex$_loanappliedcancelled_totalamountapplied" class="form-group loanappliedcancelled_totalamountapplied">
<span<?php echo $loanappliedcancelled_grid->totalamountapplied->viewAttributes() ?>><input type="text" readonly class="form-control-plaintext" value="<?php echo HtmlEncode(RemoveHtml($loanappliedcancelled_grid->totalamountapplied->ViewValue)) ?>"></span>
</span>
<input type="hidden" data-table="loanappliedcancelled" data-field="x_totalamountapplied" name="x<?php echo $loanappliedcancelled_grid->RowIndex ?>_totalamountapplied" id="x<?php echo $loanappliedcancelled_grid->RowIndex ?>_totalamountapplied" value="<?php echo HtmlEncode($loanappliedcancelled_grid->totalamountapplied->FormValue) ?>">
<?php } ?>
<input type="hidden" data-table="loanappliedcancelled" data-field="x_totalamountapplied" name="o<?php echo $loanappliedcancelled_grid->RowIndex ?>_totalamountapplied" id="o<?php echo $loanappliedcancelled_grid->RowIndex ?>_totalamountapplied" value="<?php echo HtmlEncode($loanappliedcancelled_grid->totalamountapplied->OldValue) ?>">
</td>
	<?php } ?>
	<?php if ($loanappliedcancelled_grid->taxamountbreakdown->Visible) { // taxamountbreakdown ?>
		<td data-name="taxamountbreakdown">
<?php if (!$loanappliedcancelled->isConfirm()) { ?>
<span id="el$rowindex$_loanappliedcancelled_taxamountbreakdown" class="form-group loanappliedcancelled_taxamountbreakdown">
<input type="text" data-table="loanappliedcancelled" data-field="x_taxamountbreakdown" name="x<?php echo $loanappliedcancelled_grid->RowIndex ?>_taxamountbreakdown" id="x<?php echo $loanappliedcancelled_grid->RowIndex ?>_taxamountbreakdown" size="30" maxlength="15" placeholder="<?php echo HtmlEncode($loanappliedcancelled_grid->taxamountbreakdown->getPlaceHolder()) ?>" value="<?php echo $loanappliedcancelled_grid->taxamountbreakdown->EditValue ?>"<?php echo $loanappliedcancelled_grid->taxamountbreakdown->editAttributes() ?>>
</span>
<?php } else { ?>
<span id="el$rowindex$_loanappliedcancelled_taxamountbreakdown" class="form-group loanappliedcancelled_taxamountbreakdown">
<span<?php echo $loanappliedcancelled_grid->taxamountbreakdown->viewAttributes() ?>><input type="text" readonly class="form-control-plaintext" value="<?php echo HtmlEncode(RemoveHtml($loanappliedcancelled_grid->taxamountbreakdown->ViewValue)) ?>"></span>
</span>
<input type="hidden" data-table="loanappliedcancelled" data-field="x_taxamountbreakdown" name="x<?php echo $loanappliedcancelled_grid->RowIndex ?>_taxamountbreakdown" id="x<?php echo $loanappliedcancelled_grid->RowIndex ?>_taxamountbreakdown" value="<?php echo HtmlEncode($loanappliedcancelled_grid->taxamountbreakdown->FormValue) ?>">
<?php } ?>
<input type="hidden" data-table="loanappliedcancelled" data-field="x_taxamountbreakdown" name="o<?php echo $loanappliedcancelled_grid->RowIndex ?>_taxamountbreakdown" id="o<?php echo $loanappliedcancelled_grid->RowIndex ?>_taxamountbreakdown" value="<?php echo HtmlEncode($loanappliedcancelled_grid->taxamountbreakdown->OldValue) ?>">
</td>
	<?php } ?>
	<?php if ($loanappliedcancelled_grid->feesystembreakdown->Visible) { // feesystembreakdown ?>
		<td data-name="feesystembreakdown">
<?php if (!$loanappliedcancelled->isConfirm()) { ?>
<span id="el$rowindex$_loanappliedcancelled_feesystembreakdown" class="form-group loanappliedcancelled_feesystembreakdown">
<input type="text" data-table="loanappliedcancelled" data-field="x_feesystembreakdown" name="x<?php echo $loanappliedcancelled_grid->RowIndex ?>_feesystembreakdown" id="x<?php echo $loanappliedcancelled_grid->RowIndex ?>_feesystembreakdown" size="30" maxlength="12" placeholder="<?php echo HtmlEncode($loanappliedcancelled_grid->feesystembreakdown->getPlaceHolder()) ?>" value="<?php echo $loanappliedcancelled_grid->feesystembreakdown->EditValue ?>"<?php echo $loanappliedcancelled_grid->feesystembreakdown->editAttributes() ?>>
</span>
<?php } else { ?>
<span id="el$rowindex$_loanappliedcancelled_feesystembreakdown" class="form-group loanappliedcancelled_feesystembreakdown">
<span<?php echo $loanappliedcancelled_grid->feesystembreakdown->viewAttributes() ?>><input type="text" readonly class="form-control-plaintext" value="<?php echo HtmlEncode(RemoveHtml($loanappliedcancelled_grid->feesystembreakdown->ViewValue)) ?>"></span>
</span>
<input type="hidden" data-table="loanappliedcancelled" data-field="x_feesystembreakdown" name="x<?php echo $loanappliedcancelled_grid->RowIndex ?>_feesystembreakdown" id="x<?php echo $loanappliedcancelled_grid->RowIndex ?>_feesystembreakdown" value="<?php echo HtmlEncode($loanappliedcancelled_grid->feesystembreakdown->FormValue) ?>">
<?php } ?>
<input type="hidden" data-table="loanappliedcancelled" data-field="x_feesystembreakdown" name="o<?php echo $loanappliedcancelled_grid->RowIndex ?>_feesystembreakdown" id="o<?php echo $loanappliedcancelled_grid->RowIndex ?>_feesystembreakdown" value="<?php echo HtmlEncode($loanappliedcancelled_grid->feesystembreakdown->OldValue) ?>">
</td>
	<?php } ?>
	<?php if ($loanappliedcancelled_grid->feeexternalbreakdown->Visible) { // feeexternalbreakdown ?>
		<td data-name="feeexternalbreakdown">
<?php if (!$loanappliedcancelled->isConfirm()) { ?>
<span id="el$rowindex$_loanappliedcancelled_feeexternalbreakdown" class="form-group loanappliedcancelled_feeexternalbreakdown">
<input type="text" data-table="loanappliedcancelled" data-field="x_feeexternalbreakdown" name="x<?php echo $loanappliedcancelled_grid->RowIndex ?>_feeexternalbreakdown" id="x<?php echo $loanappliedcancelled_grid->RowIndex ?>_feeexternalbreakdown" size="30" maxlength="12" placeholder="<?php echo HtmlEncode($loanappliedcancelled_grid->feeexternalbreakdown->getPlaceHolder()) ?>" value="<?php echo $loanappliedcancelled_grid->feeexternalbreakdown->EditValue ?>"<?php echo $loanappliedcancelled_grid->feeexternalbreakdown->editAttributes() ?>>
</span>
<?php } else { ?>
<span id="el$rowindex$_loanappliedcancelled_feeexternalbreakdown" class="form-group loanappliedcancelled_feeexternalbreakdown">
<span<?php echo $loanappliedcancelled_grid->feeexternalbreakdown->viewAttributes() ?>><input type="text" readonly class="form-control-plaintext" value="<?php echo HtmlEncode(RemoveHtml($loanappliedcancelled_grid->feeexternalbreakdown->ViewValue)) ?>"></span>
</span>
<input type="hidden" data-table="loanappliedcancelled" data-field="x_feeexternalbreakdown" name="x<?php echo $loanappliedcancelled_grid->RowIndex ?>_feeexternalbreakdown" id="x<?php echo $loanappliedcancelled_grid->RowIndex ?>_feeexternalbreakdown" value="<?php echo HtmlEncode($loanappliedcancelled_grid->feeexternalbreakdown->FormValue) ?>">
<?php } ?>
<input type="hidden" data-table="loanappliedcancelled" data-field="x_feeexternalbreakdown" name="o<?php echo $loanappliedcancelled_grid->RowIndex ?>_feeexternalbreakdown" id="o<?php echo $loanappliedcancelled_grid->RowIndex ?>_feeexternalbreakdown" value="<?php echo HtmlEncode($loanappliedcancelled_grid->feeexternalbreakdown->OldValue) ?>">
</td>
	<?php } ?>
	<?php if ($loanappliedcancelled_grid->feefranchiseebreakdown->Visible) { // feefranchiseebreakdown ?>
		<td data-name="feefranchiseebreakdown">
<?php if (!$loanappliedcancelled->isConfirm()) { ?>
<span id="el$rowindex$_loanappliedcancelled_feefranchiseebreakdown" class="form-group loanappliedcancelled_feefranchiseebreakdown">
<input type="text" data-table="loanappliedcancelled" data-field="x_feefranchiseebreakdown" name="x<?php echo $loanappliedcancelled_grid->RowIndex ?>_feefranchiseebreakdown" id="x<?php echo $loanappliedcancelled_grid->RowIndex ?>_feefranchiseebreakdown" size="30" maxlength="12" placeholder="<?php echo HtmlEncode($loanappliedcancelled_grid->feefranchiseebreakdown->getPlaceHolder()) ?>" value="<?php echo $loanappliedcancelled_grid->feefranchiseebreakdown->EditValue ?>"<?php echo $loanappliedcancelled_grid->feefranchiseebreakdown->editAttributes() ?>>
</span>
<?php } else { ?>
<span id="el$rowindex$_loanappliedcancelled_feefranchiseebreakdown" class="form-group loanappliedcancelled_feefranchiseebreakdown">
<span<?php echo $loanappliedcancelled_grid->feefranchiseebreakdown->viewAttributes() ?>><input type="text" readonly class="form-control-plaintext" value="<?php echo HtmlEncode(RemoveHtml($loanappliedcancelled_grid->feefranchiseebreakdown->ViewValue)) ?>"></span>
</span>
<input type="hidden" data-table="loanappliedcancelled" data-field="x_feefranchiseebreakdown" name="x<?php echo $loanappliedcancelled_grid->RowIndex ?>_feefranchiseebreakdown" id="x<?php echo $loanappliedcancelled_grid->RowIndex ?>_feefranchiseebreakdown" value="<?php echo HtmlEncode($loanappliedcancelled_grid->feefranchiseebreakdown->FormValue) ?>">
<?php } ?>
<input type="hidden" data-table="loanappliedcancelled" data-field="x_feefranchiseebreakdown" name="o<?php echo $loanappliedcancelled_grid->RowIndex ?>_feefranchiseebreakdown" id="o<?php echo $loanappliedcancelled_grid->RowIndex ?>_feefranchiseebreakdown" value="<?php echo HtmlEncode($loanappliedcancelled_grid->feefranchiseebreakdown->OldValue) ?>">
</td>
	<?php } ?>
	<?php if ($loanappliedcancelled_grid->feeresellerbreakdown->Visible) { // feeresellerbreakdown ?>
		<td data-name="feeresellerbreakdown">
<?php if (!$loanappliedcancelled->isConfirm()) { ?>
<span id="el$rowindex$_loanappliedcancelled_feeresellerbreakdown" class="form-group loanappliedcancelled_feeresellerbreakdown">
<input type="text" data-table="loanappliedcancelled" data-field="x_feeresellerbreakdown" name="x<?php echo $loanappliedcancelled_grid->RowIndex ?>_feeresellerbreakdown" id="x<?php echo $loanappliedcancelled_grid->RowIndex ?>_feeresellerbreakdown" size="30" maxlength="12" placeholder="<?php echo HtmlEncode($loanappliedcancelled_grid->feeresellerbreakdown->getPlaceHolder()) ?>" value="<?php echo $loanappliedcancelled_grid->feeresellerbreakdown->EditValue ?>"<?php echo $loanappliedcancelled_grid->feeresellerbreakdown->editAttributes() ?>>
</span>
<?php } else { ?>
<span id="el$rowindex$_loanappliedcancelled_feeresellerbreakdown" class="form-group loanappliedcancelled_feeresellerbreakdown">
<span<?php echo $loanappliedcancelled_grid->feeresellerbreakdown->viewAttributes() ?>><input type="text" readonly class="form-control-plaintext" value="<?php echo HtmlEncode(RemoveHtml($loanappliedcancelled_grid->feeresellerbreakdown->ViewValue)) ?>"></span>
</span>
<input type="hidden" data-table="loanappliedcancelled" data-field="x_feeresellerbreakdown" name="x<?php echo $loanappliedcancelled_grid->RowIndex ?>_feeresellerbreakdown" id="x<?php echo $loanappliedcancelled_grid->RowIndex ?>_feeresellerbreakdown" value="<?php echo HtmlEncode($loanappliedcancelled_grid->feeresellerbreakdown->FormValue) ?>">
<?php } ?>
<input type="hidden" data-table="loanappliedcancelled" data-field="x_feeresellerbreakdown" name="o<?php echo $loanappliedcancelled_grid->RowIndex ?>_feeresellerbreakdown" id="o<?php echo $loanappliedcancelled_grid->RowIndex ?>_feeresellerbreakdown" value="<?php echo HtmlEncode($loanappliedcancelled_grid->feeresellerbreakdown->OldValue) ?>">
</td>
	<?php } ?>
	<?php if ($loanappliedcancelled_grid->cancellationtime->Visible) { // cancellationtime ?>
		<td data-name="cancellationtime">
<?php if (!$loanappliedcancelled->isConfirm()) { ?>
<span id="el$rowindex$_loanappliedcancelled_cancellationtime" class="form-group loanappliedcancelled_cancellationtime">
<input type="text" data-table="loanappliedcancelled" data-field="x_cancellationtime" name="x<?php echo $loanappliedcancelled_grid->RowIndex ?>_cancellationtime" id="x<?php echo $loanappliedcancelled_grid->RowIndex ?>_cancellationtime" maxlength="19" placeholder="<?php echo HtmlEncode($loanappliedcancelled_grid->cancellationtime->getPlaceHolder()) ?>" value="<?php echo $loanappliedcancelled_grid->cancellationtime->EditValue ?>"<?php echo $loanappliedcancelled_grid->cancellationtime->editAttributes() ?>>
<?php if (!$loanappliedcancelled_grid->cancellationtime->ReadOnly && !$loanappliedcancelled_grid->cancellationtime->Disabled && !isset($loanappliedcancelled_grid->cancellationtime->EditAttrs["readonly"]) && !isset($loanappliedcancelled_grid->cancellationtime->EditAttrs["disabled"])) { ?>
<script>
loadjs.ready(["floanappliedcancelledgrid", "datetimepicker"], function() {
	ew.createDateTimePicker("floanappliedcancelledgrid", "x<?php echo $loanappliedcancelled_grid->RowIndex ?>_cancellationtime", {"ignoreReadonly":true,"useCurrent":false,"format":0});
});
</script>
<?php } ?>
</span>
<?php } else { ?>
<span id="el$rowindex$_loanappliedcancelled_cancellationtime" class="form-group loanappliedcancelled_cancellationtime">
<span<?php echo $loanappliedcancelled_grid->cancellationtime->viewAttributes() ?>><input type="text" readonly class="form-control-plaintext" value="<?php echo HtmlEncode(RemoveHtml($loanappliedcancelled_grid->cancellationtime->ViewValue)) ?>"></span>
</span>
<input type="hidden" data-table="loanappliedcancelled" data-field="x_cancellationtime" name="x<?php echo $loanappliedcancelled_grid->RowIndex ?>_cancellationtime" id="x<?php echo $loanappliedcancelled_grid->RowIndex ?>_cancellationtime" value="<?php echo HtmlEncode($loanappliedcancelled_grid->cancellationtime->FormValue) ?>">
<?php } ?>
<input type="hidden" data-table="loanappliedcancelled" data-field="x_cancellationtime" name="o<?php echo $loanappliedcancelled_grid->RowIndex ?>_cancellationtime" id="o<?php echo $loanappliedcancelled_grid->RowIndex ?>_cancellationtime" value="<?php echo HtmlEncode($loanappliedcancelled_grid->cancellationtime->OldValue) ?>">
</td>
	<?php } ?>
	<?php if ($loanappliedcancelled_grid->cancellationrefno->Visible) { // cancellationrefno ?>
		<td data-name="cancellationrefno">
<?php if (!$loanappliedcancelled->isConfirm()) { ?>
<span id="el$rowindex$_loanappliedcancelled_cancellationrefno" class="form-group loanappliedcancelled_cancellationrefno">
<input type="text" data-table="loanappliedcancelled" data-field="x_cancellationrefno" name="x<?php echo $loanappliedcancelled_grid->RowIndex ?>_cancellationrefno" id="x<?php echo $loanappliedcancelled_grid->RowIndex ?>_cancellationrefno" size="30" maxlength="100" placeholder="<?php echo HtmlEncode($loanappliedcancelled_grid->cancellationrefno->getPlaceHolder()) ?>" value="<?php echo $loanappliedcancelled_grid->cancellationrefno->EditValue ?>"<?php echo $loanappliedcancelled_grid->cancellationrefno->editAttributes() ?>>
</span>
<?php } else { ?>
<span id="el$rowindex$_loanappliedcancelled_cancellationrefno" class="form-group loanappliedcancelled_cancellationrefno">
<span<?php echo $loanappliedcancelled_grid->cancellationrefno->viewAttributes() ?>><input type="text" readonly class="form-control-plaintext" value="<?php echo HtmlEncode(RemoveHtml($loanappliedcancelled_grid->cancellationrefno->ViewValue)) ?>"></span>
</span>
<input type="hidden" data-table="loanappliedcancelled" data-field="x_cancellationrefno" name="x<?php echo $loanappliedcancelled_grid->RowIndex ?>_cancellationrefno" id="x<?php echo $loanappliedcancelled_grid->RowIndex ?>_cancellationrefno" value="<?php echo HtmlEncode($loanappliedcancelled_grid->cancellationrefno->FormValue) ?>">
<?php } ?>
<input type="hidden" data-table="loanappliedcancelled" data-field="x_cancellationrefno" name="o<?php echo $loanappliedcancelled_grid->RowIndex ?>_cancellationrefno" id="o<?php echo $loanappliedcancelled_grid->RowIndex ?>_cancellationrefno" value="<?php echo HtmlEncode($loanappliedcancelled_grid->cancellationrefno->OldValue) ?>">
</td>
	<?php } ?>
<?php

// Render list options (body, right)
$loanappliedcancelled_grid->ListOptions->render("body", "right", $loanappliedcancelled_grid->RowIndex);
?>
<script>
loadjs.ready(["floanappliedcancelledgrid", "load"], function() {
	floanappliedcancelledgrid.updateLists(<?php echo $loanappliedcancelled_grid->RowIndex ?>);
});
</script>
	</tr>
<?php
	}
?>
</tbody>
</table><!-- /.ew-table -->
</div><!-- /.ew-grid-middle-panel -->
<?php if ($loanappliedcancelled->CurrentMode == "add" || $loanappliedcancelled->CurrentMode == "copy") { ?>
<input type="hidden" name="<?php echo $loanappliedcancelled_grid->FormKeyCountName ?>" id="<?php echo $loanappliedcancelled_grid->FormKeyCountName ?>" value="<?php echo $loanappliedcancelled_grid->KeyCount ?>">
<?php echo $loanappliedcancelled_grid->MultiSelectKey ?>
<?php } ?>
<?php if ($loanappliedcancelled->CurrentMode == "edit") { ?>
<input type="hidden" name="<?php echo $loanappliedcancelled_grid->FormKeyCountName ?>" id="<?php echo $loanappliedcancelled_grid->FormKeyCountName ?>" value="<?php echo $loanappliedcancelled_grid->KeyCount ?>">
<?php echo $loanappliedcancelled_grid->MultiSelectKey ?>
<?php } ?>
<?php if ($loanappliedcancelled->CurrentMode == "") { ?>
<input type="hidden" name="action" id="action" value="">
<?php } ?>
<input type="hidden" name="detailpage" value="floanappliedcancelledgrid">
</div><!-- /.ew-list-form -->
<?php

// Close recordset
if ($loanappliedcancelled_grid->Recordset)
	$loanappliedcancelled_grid->Recordset->Close();
?>
<?php if ($loanappliedcancelled_grid->ShowOtherOptions) { ?>
<div class="card-footer ew-grid-lower-panel">
<?php $loanappliedcancelled_grid->OtherOptions->render("body", "bottom") ?>
</div>
<div class="clearfix"></div>
<?php } ?>
</div><!-- /.ew-grid -->
<?php } ?>
<?php if ($loanappliedcancelled_grid->TotalRecords == 0 && !$loanappliedcancelled->CurrentAction) { // Show other options ?>
<div class="ew-list-other-options">
<?php $loanappliedcancelled_grid->OtherOptions->render("body") ?>
</div>
<div class="clearfix"></div>
<?php } ?>
<?php if (!$loanappliedcancelled_grid->isExport()) { ?>
<script>
loadjs.ready("load", function() {

	// Startup script
	// Write your table-specific startup script here
	// console.log("page loaded");

});
</script>
<?php } ?>
<?php
$loanappliedcancelled_grid->terminate();
?>