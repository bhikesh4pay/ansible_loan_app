<?php
namespace PHPMaker2020\_4payadmin;
?>
<?php if ($acct->Visible) { ?>
<div class="ew-master-div">
<table id="tbl_acctmaster" class="table ew-view-table ew-master-table ew-vertical">
	<tbody>
<?php if ($acct->acctID->Visible) { // acctID ?>
		<tr id="r_acctID">
			<td class="<?php echo $acct->TableLeftColumnClass ?>"><?php echo $acct->acctID->caption() ?></td>
			<td <?php echo $acct->acctID->cellAttributes() ?>>
<span id="el_acct_acctID">
<span<?php echo $acct->acctID->viewAttributes() ?>><?php echo $acct->acctID->getViewValue() ?></span>
</span>
</td>
		</tr>
<?php } ?>
<?php if ($acct->name->Visible) { // name ?>
		<tr id="r_name">
			<td class="<?php echo $acct->TableLeftColumnClass ?>"><?php echo $acct->name->caption() ?></td>
			<td <?php echo $acct->name->cellAttributes() ?>>
<span id="el_acct_name">
<span<?php echo $acct->name->viewAttributes() ?>><?php echo $acct->name->getViewValue() ?></span>
</span>
</td>
		</tr>
<?php } ?>
<?php if ($acct->type->Visible) { // type ?>
		<tr id="r_type">
			<td class="<?php echo $acct->TableLeftColumnClass ?>"><?php echo $acct->type->caption() ?></td>
			<td <?php echo $acct->type->cellAttributes() ?>>
<span id="el_acct_type">
<span<?php echo $acct->type->viewAttributes() ?>><?php echo $acct->type->getViewValue() ?></span>
</span>
</td>
		</tr>
<?php } ?>
<?php if ($acct->subtype->Visible) { // subtype ?>
		<tr id="r_subtype">
			<td class="<?php echo $acct->TableLeftColumnClass ?>"><?php echo $acct->subtype->caption() ?></td>
			<td <?php echo $acct->subtype->cellAttributes() ?>>
<span id="el_acct_subtype">
<span<?php echo $acct->subtype->viewAttributes() ?>><?php echo $acct->subtype->getViewValue() ?></span>
</span>
</td>
		</tr>
<?php } ?>
<?php if ($acct->classID->Visible) { // classID ?>
		<tr id="r_classID">
			<td class="<?php echo $acct->TableLeftColumnClass ?>"><?php echo $acct->classID->caption() ?></td>
			<td <?php echo $acct->classID->cellAttributes() ?>>
<span id="el_acct_classID">
<span<?php echo $acct->classID->viewAttributes() ?>><?php echo $acct->classID->getViewValue() ?></span>
</span>
</td>
		</tr>
<?php } ?>
<?php if ($acct->externalnumber->Visible) { // externalnumber ?>
		<tr id="r_externalnumber">
			<td class="<?php echo $acct->TableLeftColumnClass ?>"><?php echo $acct->externalnumber->caption() ?></td>
			<td <?php echo $acct->externalnumber->cellAttributes() ?>>
<span id="el_acct_externalnumber">
<span<?php echo $acct->externalnumber->viewAttributes() ?>><?php echo $acct->externalnumber->getViewValue() ?></span>
</span>
</td>
		</tr>
<?php } ?>
	</tbody>
</table>
</div>
<?php } ?>