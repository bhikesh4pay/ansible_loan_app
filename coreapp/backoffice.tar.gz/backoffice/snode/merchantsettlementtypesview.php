<?php
namespace PHPMaker2020\_4payadmin;

// Autoload
include_once "autoload.php";

// Session
if (session_status() !== PHP_SESSION_ACTIVE)
	\Delight\Cookie\Session::start(Config("COOKIE_SAMESITE")); // Init session data

// Output buffering
ob_start();
?>
<?php

// Write header
WriteHeader(FALSE);

// Create page object
$merchantsettlementtypes_view = new merchantsettlementtypes_view();

// Run the page
$merchantsettlementtypes_view->run();

// Setup login status
SetupLoginStatus();
SetClientVar("login", LoginStatus());

// Global Page Rendering event (in userfn*.php)
Page_Rendering();

// Page Rendering event
$merchantsettlementtypes_view->Page_Render();
?>
<?php include_once "header.php"; ?>
<?php if (!$merchantsettlementtypes_view->isExport()) { ?>
<script>
var fmerchantsettlementtypesview, currentPageID;
loadjs.ready("head", function() {

	// Form object
	currentPageID = ew.PAGE_ID = "view";
	fmerchantsettlementtypesview = currentForm = new ew.Form("fmerchantsettlementtypesview", "view");
	loadjs.done("fmerchantsettlementtypesview");
});
</script>
<script>
loadjs.ready("head", function() {

	// Client script
	// Write your client script here, no need to add script tags.

});
</script>
<?php } ?>
<?php if (!$merchantsettlementtypes_view->isExport()) { ?>
<div class="btn-toolbar ew-toolbar">
<?php $merchantsettlementtypes_view->ExportOptions->render("body") ?>
<?php $merchantsettlementtypes_view->OtherOptions->render("body") ?>
<div class="clearfix"></div>
</div>
<?php } ?>
<?php $merchantsettlementtypes_view->showPageHeader(); ?>
<?php
$merchantsettlementtypes_view->showMessage();
?>
<form name="fmerchantsettlementtypesview" id="fmerchantsettlementtypesview" class="form-inline ew-form ew-view-form" action="<?php echo CurrentPageName() ?>" method="post">
<?php if ($Page->CheckToken) { ?>
<input type="hidden" name="<?php echo Config("TOKEN_NAME") ?>" value="<?php echo $Page->Token ?>">
<?php } ?>
<input type="hidden" name="t" value="merchantsettlementtypes">
<input type="hidden" name="modal" value="<?php echo (int)$merchantsettlementtypes_view->IsModal ?>">
<table class="table table-striped table-sm ew-view-table">
<?php if ($merchantsettlementtypes_view->typeid->Visible) { // typeid ?>
	<tr id="r_typeid">
		<td class="<?php echo $merchantsettlementtypes_view->TableLeftColumnClass ?>"><span id="elh_merchantsettlementtypes_typeid"><?php echo $merchantsettlementtypes_view->typeid->caption() ?></span></td>
		<td data-name="typeid" <?php echo $merchantsettlementtypes_view->typeid->cellAttributes() ?>>
<span id="el_merchantsettlementtypes_typeid">
<span<?php echo $merchantsettlementtypes_view->typeid->viewAttributes() ?>><?php echo $merchantsettlementtypes_view->typeid->getViewValue() ?></span>
</span>
</td>
	</tr>
<?php } ?>
<?php if ($merchantsettlementtypes_view->description->Visible) { // description ?>
	<tr id="r_description">
		<td class="<?php echo $merchantsettlementtypes_view->TableLeftColumnClass ?>"><span id="elh_merchantsettlementtypes_description"><?php echo $merchantsettlementtypes_view->description->caption() ?></span></td>
		<td data-name="description" <?php echo $merchantsettlementtypes_view->description->cellAttributes() ?>>
<span id="el_merchantsettlementtypes_description">
<span<?php echo $merchantsettlementtypes_view->description->viewAttributes() ?>><?php echo $merchantsettlementtypes_view->description->getViewValue() ?></span>
</span>
</td>
	</tr>
<?php } ?>
<?php if ($merchantsettlementtypes_view->classname->Visible) { // classname ?>
	<tr id="r_classname">
		<td class="<?php echo $merchantsettlementtypes_view->TableLeftColumnClass ?>"><span id="elh_merchantsettlementtypes_classname"><?php echo $merchantsettlementtypes_view->classname->caption() ?></span></td>
		<td data-name="classname" <?php echo $merchantsettlementtypes_view->classname->cellAttributes() ?>>
<span id="el_merchantsettlementtypes_classname">
<span<?php echo $merchantsettlementtypes_view->classname->viewAttributes() ?>><?php echo $merchantsettlementtypes_view->classname->getViewValue() ?></span>
</span>
</td>
	</tr>
<?php } ?>
</table>
</form>
<?php
$merchantsettlementtypes_view->showPageFooter();
if (Config("DEBUG"))
	echo GetDebugMessage();
?>
<?php if (!$merchantsettlementtypes_view->isExport()) { ?>
<script>
loadjs.ready("load", function() {

	// Startup script
	// Write your table-specific startup script here
	// console.log("page loaded");

});
</script>
<?php } ?>
<?php include_once "footer.php"; ?>
<?php
$merchantsettlementtypes_view->terminate();
?>