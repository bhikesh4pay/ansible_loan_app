<?php
namespace PHPMaker2020\_4payadmin;

// Autoload
include_once "autoload.php";

// Session
if (session_status() !== PHP_SESSION_ACTIVE)
	\Delight\Cookie\Session::start(Config("COOKIE_SAMESITE")); // Init session data

// Output buffering
ob_start();
?>
<?php

// Write header
WriteHeader(FALSE);

// Create page object
$purchasefeecustom_edit = new purchasefeecustom_edit();

// Run the page
$purchasefeecustom_edit->run();

// Setup login status
SetupLoginStatus();
SetClientVar("login", LoginStatus());

// Global Page Rendering event (in userfn*.php)
Page_Rendering();

// Page Rendering event
$purchasefeecustom_edit->Page_Render();
?>
<?php include_once "header.php"; ?>
<script>
var fpurchasefeecustomedit, currentPageID;
loadjs.ready("head", function() {

	// Form object
	currentPageID = ew.PAGE_ID = "edit";
	fpurchasefeecustomedit = currentForm = new ew.Form("fpurchasefeecustomedit", "edit");

	// Validate form
	fpurchasefeecustomedit.validate = function() {
		if (!this.validateRequired)
			return true; // Ignore validation
		var $ = jQuery, fobj = this.getForm(), $fobj = $(fobj);
		if ($fobj.find("#confirm").val() == "confirm")
			return true;
		var elm, felm, uelm, addcnt = 0;
		var $k = $fobj.find("#" + this.formKeyCountName); // Get key_count
		var rowcnt = ($k[0]) ? parseInt($k.val(), 10) : 1;
		var startcnt = (rowcnt == 0) ? 0 : 1; // Check rowcnt == 0 => Inline-Add
		var gridinsert = ["insert", "gridinsert"].includes($fobj.find("#action").val()) && $k[0];
		for (var i = startcnt; i <= rowcnt; i++) {
			var infix = ($k[0]) ? String(i) : "";
			$fobj.data("rowindex", infix);
			<?php if ($purchasefeecustom_edit->feeid->Required) { ?>
				elm = this.getElements("x" + infix + "_feeid");
				if (elm && !ew.isHidden(elm) && !ew.hasValue(elm))
					return this.onError(elm, "<?php echo JsEncode(str_replace("%s", $purchasefeecustom_edit->feeid->caption(), $purchasefeecustom_edit->feeid->RequiredErrorMessage)) ?>");
			<?php } ?>
			<?php if ($purchasefeecustom_edit->tableid->Required) { ?>
				elm = this.getElements("x" + infix + "_tableid");
				if (elm && !ew.isHidden(elm) && !ew.hasValue(elm))
					return this.onError(elm, "<?php echo JsEncode(str_replace("%s", $purchasefeecustom_edit->tableid->caption(), $purchasefeecustom_edit->tableid->RequiredErrorMessage)) ?>");
			<?php } ?>
				elm = this.getElements("x" + infix + "_tableid");
				if (elm && !ew.checkInteger(elm.value))
					return this.onError(elm, "<?php echo JsEncode($purchasefeecustom_edit->tableid->errorMessage()) ?>");
			<?php if ($purchasefeecustom_edit->active->Required) { ?>
				elm = this.getElements("x" + infix + "_active");
				if (elm && !ew.isHidden(elm) && !ew.hasValue(elm))
					return this.onError(elm, "<?php echo JsEncode(str_replace("%s", $purchasefeecustom_edit->active->caption(), $purchasefeecustom_edit->active->RequiredErrorMessage)) ?>");
			<?php } ?>
			<?php if ($purchasefeecustom_edit->currencycode->Required) { ?>
				elm = this.getElements("x" + infix + "_currencycode");
				if (elm && !ew.isHidden(elm) && !ew.hasValue(elm))
					return this.onError(elm, "<?php echo JsEncode(str_replace("%s", $purchasefeecustom_edit->currencycode->caption(), $purchasefeecustom_edit->currencycode->RequiredErrorMessage)) ?>");
			<?php } ?>
			<?php if ($purchasefeecustom_edit->startvalue->Required) { ?>
				elm = this.getElements("x" + infix + "_startvalue");
				if (elm && !ew.isHidden(elm) && !ew.hasValue(elm))
					return this.onError(elm, "<?php echo JsEncode(str_replace("%s", $purchasefeecustom_edit->startvalue->caption(), $purchasefeecustom_edit->startvalue->RequiredErrorMessage)) ?>");
			<?php } ?>
				elm = this.getElements("x" + infix + "_startvalue");
				if (elm && !ew.checkNumber(elm.value))
					return this.onError(elm, "<?php echo JsEncode($purchasefeecustom_edit->startvalue->errorMessage()) ?>");
			<?php if ($purchasefeecustom_edit->endvalue->Required) { ?>
				elm = this.getElements("x" + infix + "_endvalue");
				if (elm && !ew.isHidden(elm) && !ew.hasValue(elm))
					return this.onError(elm, "<?php echo JsEncode(str_replace("%s", $purchasefeecustom_edit->endvalue->caption(), $purchasefeecustom_edit->endvalue->RequiredErrorMessage)) ?>");
			<?php } ?>
				elm = this.getElements("x" + infix + "_endvalue");
				if (elm && !ew.checkNumber(elm.value))
					return this.onError(elm, "<?php echo JsEncode($purchasefeecustom_edit->endvalue->errorMessage()) ?>");
			<?php if ($purchasefeecustom_edit->franchiseeid->Required) { ?>
				elm = this.getElements("x" + infix + "_franchiseeid");
				if (elm && !ew.isHidden(elm) && !ew.hasValue(elm))
					return this.onError(elm, "<?php echo JsEncode(str_replace("%s", $purchasefeecustom_edit->franchiseeid->caption(), $purchasefeecustom_edit->franchiseeid->RequiredErrorMessage)) ?>");
			<?php } ?>
			<?php if ($purchasefeecustom_edit->piid->Required) { ?>
				elm = this.getElements("x" + infix + "_piid");
				if (elm && !ew.isHidden(elm) && !ew.hasValue(elm))
					return this.onError(elm, "<?php echo JsEncode(str_replace("%s", $purchasefeecustom_edit->piid->caption(), $purchasefeecustom_edit->piid->RequiredErrorMessage)) ?>");
			<?php } ?>
			<?php if ($purchasefeecustom_edit->countryid->Required) { ?>
				elm = this.getElements("x" + infix + "_countryid");
				if (elm && !ew.isHidden(elm) && !ew.hasValue(elm))
					return this.onError(elm, "<?php echo JsEncode(str_replace("%s", $purchasefeecustom_edit->countryid->caption(), $purchasefeecustom_edit->countryid->RequiredErrorMessage)) ?>");
			<?php } ?>
			<?php if ($purchasefeecustom_edit->percentfeemerchantsystem->Required) { ?>
				elm = this.getElements("x" + infix + "_percentfeemerchantsystem");
				if (elm && !ew.isHidden(elm) && !ew.hasValue(elm))
					return this.onError(elm, "<?php echo JsEncode(str_replace("%s", $purchasefeecustom_edit->percentfeemerchantsystem->caption(), $purchasefeecustom_edit->percentfeemerchantsystem->RequiredErrorMessage)) ?>");
			<?php } ?>
				elm = this.getElements("x" + infix + "_percentfeemerchantsystem");
				if (elm && !ew.checkNumber(elm.value))
					return this.onError(elm, "<?php echo JsEncode($purchasefeecustom_edit->percentfeemerchantsystem->errorMessage()) ?>");
			<?php if ($purchasefeecustom_edit->percentfeemerchantexternal->Required) { ?>
				elm = this.getElements("x" + infix + "_percentfeemerchantexternal");
				if (elm && !ew.isHidden(elm) && !ew.hasValue(elm))
					return this.onError(elm, "<?php echo JsEncode(str_replace("%s", $purchasefeecustom_edit->percentfeemerchantexternal->caption(), $purchasefeecustom_edit->percentfeemerchantexternal->RequiredErrorMessage)) ?>");
			<?php } ?>
				elm = this.getElements("x" + infix + "_percentfeemerchantexternal");
				if (elm && !ew.checkNumber(elm.value))
					return this.onError(elm, "<?php echo JsEncode($purchasefeecustom_edit->percentfeemerchantexternal->errorMessage()) ?>");
			<?php if ($purchasefeecustom_edit->percentfeemerchantfranchisee->Required) { ?>
				elm = this.getElements("x" + infix + "_percentfeemerchantfranchisee");
				if (elm && !ew.isHidden(elm) && !ew.hasValue(elm))
					return this.onError(elm, "<?php echo JsEncode(str_replace("%s", $purchasefeecustom_edit->percentfeemerchantfranchisee->caption(), $purchasefeecustom_edit->percentfeemerchantfranchisee->RequiredErrorMessage)) ?>");
			<?php } ?>
				elm = this.getElements("x" + infix + "_percentfeemerchantfranchisee");
				if (elm && !ew.checkNumber(elm.value))
					return this.onError(elm, "<?php echo JsEncode($purchasefeecustom_edit->percentfeemerchantfranchisee->errorMessage()) ?>");
			<?php if ($purchasefeecustom_edit->percentfeemerchantreseller->Required) { ?>
				elm = this.getElements("x" + infix + "_percentfeemerchantreseller");
				if (elm && !ew.isHidden(elm) && !ew.hasValue(elm))
					return this.onError(elm, "<?php echo JsEncode(str_replace("%s", $purchasefeecustom_edit->percentfeemerchantreseller->caption(), $purchasefeecustom_edit->percentfeemerchantreseller->RequiredErrorMessage)) ?>");
			<?php } ?>
				elm = this.getElements("x" + infix + "_percentfeemerchantreseller");
				if (elm && !ew.checkNumber(elm.value))
					return this.onError(elm, "<?php echo JsEncode($purchasefeecustom_edit->percentfeemerchantreseller->errorMessage()) ?>");
			<?php if ($purchasefeecustom_edit->fixedfeemerchantsystem->Required) { ?>
				elm = this.getElements("x" + infix + "_fixedfeemerchantsystem");
				if (elm && !ew.isHidden(elm) && !ew.hasValue(elm))
					return this.onError(elm, "<?php echo JsEncode(str_replace("%s", $purchasefeecustom_edit->fixedfeemerchantsystem->caption(), $purchasefeecustom_edit->fixedfeemerchantsystem->RequiredErrorMessage)) ?>");
			<?php } ?>
				elm = this.getElements("x" + infix + "_fixedfeemerchantsystem");
				if (elm && !ew.checkNumber(elm.value))
					return this.onError(elm, "<?php echo JsEncode($purchasefeecustom_edit->fixedfeemerchantsystem->errorMessage()) ?>");
			<?php if ($purchasefeecustom_edit->fixedfeemerchantexternal->Required) { ?>
				elm = this.getElements("x" + infix + "_fixedfeemerchantexternal");
				if (elm && !ew.isHidden(elm) && !ew.hasValue(elm))
					return this.onError(elm, "<?php echo JsEncode(str_replace("%s", $purchasefeecustom_edit->fixedfeemerchantexternal->caption(), $purchasefeecustom_edit->fixedfeemerchantexternal->RequiredErrorMessage)) ?>");
			<?php } ?>
				elm = this.getElements("x" + infix + "_fixedfeemerchantexternal");
				if (elm && !ew.checkNumber(elm.value))
					return this.onError(elm, "<?php echo JsEncode($purchasefeecustom_edit->fixedfeemerchantexternal->errorMessage()) ?>");
			<?php if ($purchasefeecustom_edit->fixedfeemerchantfranchisee->Required) { ?>
				elm = this.getElements("x" + infix + "_fixedfeemerchantfranchisee");
				if (elm && !ew.isHidden(elm) && !ew.hasValue(elm))
					return this.onError(elm, "<?php echo JsEncode(str_replace("%s", $purchasefeecustom_edit->fixedfeemerchantfranchisee->caption(), $purchasefeecustom_edit->fixedfeemerchantfranchisee->RequiredErrorMessage)) ?>");
			<?php } ?>
				elm = this.getElements("x" + infix + "_fixedfeemerchantfranchisee");
				if (elm && !ew.checkNumber(elm.value))
					return this.onError(elm, "<?php echo JsEncode($purchasefeecustom_edit->fixedfeemerchantfranchisee->errorMessage()) ?>");
			<?php if ($purchasefeecustom_edit->fixedfeemerchantreseller->Required) { ?>
				elm = this.getElements("x" + infix + "_fixedfeemerchantreseller");
				if (elm && !ew.isHidden(elm) && !ew.hasValue(elm))
					return this.onError(elm, "<?php echo JsEncode(str_replace("%s", $purchasefeecustom_edit->fixedfeemerchantreseller->caption(), $purchasefeecustom_edit->fixedfeemerchantreseller->RequiredErrorMessage)) ?>");
			<?php } ?>
				elm = this.getElements("x" + infix + "_fixedfeemerchantreseller");
				if (elm && !ew.checkNumber(elm.value))
					return this.onError(elm, "<?php echo JsEncode($purchasefeecustom_edit->fixedfeemerchantreseller->errorMessage()) ?>");
			<?php if ($purchasefeecustom_edit->percentfeeconsumersystem->Required) { ?>
				elm = this.getElements("x" + infix + "_percentfeeconsumersystem");
				if (elm && !ew.isHidden(elm) && !ew.hasValue(elm))
					return this.onError(elm, "<?php echo JsEncode(str_replace("%s", $purchasefeecustom_edit->percentfeeconsumersystem->caption(), $purchasefeecustom_edit->percentfeeconsumersystem->RequiredErrorMessage)) ?>");
			<?php } ?>
				elm = this.getElements("x" + infix + "_percentfeeconsumersystem");
				if (elm && !ew.checkNumber(elm.value))
					return this.onError(elm, "<?php echo JsEncode($purchasefeecustom_edit->percentfeeconsumersystem->errorMessage()) ?>");
			<?php if ($purchasefeecustom_edit->percentfeeconsumerexternal->Required) { ?>
				elm = this.getElements("x" + infix + "_percentfeeconsumerexternal");
				if (elm && !ew.isHidden(elm) && !ew.hasValue(elm))
					return this.onError(elm, "<?php echo JsEncode(str_replace("%s", $purchasefeecustom_edit->percentfeeconsumerexternal->caption(), $purchasefeecustom_edit->percentfeeconsumerexternal->RequiredErrorMessage)) ?>");
			<?php } ?>
				elm = this.getElements("x" + infix + "_percentfeeconsumerexternal");
				if (elm && !ew.checkNumber(elm.value))
					return this.onError(elm, "<?php echo JsEncode($purchasefeecustom_edit->percentfeeconsumerexternal->errorMessage()) ?>");
			<?php if ($purchasefeecustom_edit->percentfeeconsumerfranchisee->Required) { ?>
				elm = this.getElements("x" + infix + "_percentfeeconsumerfranchisee");
				if (elm && !ew.isHidden(elm) && !ew.hasValue(elm))
					return this.onError(elm, "<?php echo JsEncode(str_replace("%s", $purchasefeecustom_edit->percentfeeconsumerfranchisee->caption(), $purchasefeecustom_edit->percentfeeconsumerfranchisee->RequiredErrorMessage)) ?>");
			<?php } ?>
				elm = this.getElements("x" + infix + "_percentfeeconsumerfranchisee");
				if (elm && !ew.checkNumber(elm.value))
					return this.onError(elm, "<?php echo JsEncode($purchasefeecustom_edit->percentfeeconsumerfranchisee->errorMessage()) ?>");
			<?php if ($purchasefeecustom_edit->percentfeeconsumerreseller->Required) { ?>
				elm = this.getElements("x" + infix + "_percentfeeconsumerreseller");
				if (elm && !ew.isHidden(elm) && !ew.hasValue(elm))
					return this.onError(elm, "<?php echo JsEncode(str_replace("%s", $purchasefeecustom_edit->percentfeeconsumerreseller->caption(), $purchasefeecustom_edit->percentfeeconsumerreseller->RequiredErrorMessage)) ?>");
			<?php } ?>
				elm = this.getElements("x" + infix + "_percentfeeconsumerreseller");
				if (elm && !ew.checkNumber(elm.value))
					return this.onError(elm, "<?php echo JsEncode($purchasefeecustom_edit->percentfeeconsumerreseller->errorMessage()) ?>");
			<?php if ($purchasefeecustom_edit->fixedfeeconsumersystem->Required) { ?>
				elm = this.getElements("x" + infix + "_fixedfeeconsumersystem");
				if (elm && !ew.isHidden(elm) && !ew.hasValue(elm))
					return this.onError(elm, "<?php echo JsEncode(str_replace("%s", $purchasefeecustom_edit->fixedfeeconsumersystem->caption(), $purchasefeecustom_edit->fixedfeeconsumersystem->RequiredErrorMessage)) ?>");
			<?php } ?>
				elm = this.getElements("x" + infix + "_fixedfeeconsumersystem");
				if (elm && !ew.checkNumber(elm.value))
					return this.onError(elm, "<?php echo JsEncode($purchasefeecustom_edit->fixedfeeconsumersystem->errorMessage()) ?>");
			<?php if ($purchasefeecustom_edit->fixedfeeconsumerexternal->Required) { ?>
				elm = this.getElements("x" + infix + "_fixedfeeconsumerexternal");
				if (elm && !ew.isHidden(elm) && !ew.hasValue(elm))
					return this.onError(elm, "<?php echo JsEncode(str_replace("%s", $purchasefeecustom_edit->fixedfeeconsumerexternal->caption(), $purchasefeecustom_edit->fixedfeeconsumerexternal->RequiredErrorMessage)) ?>");
			<?php } ?>
				elm = this.getElements("x" + infix + "_fixedfeeconsumerexternal");
				if (elm && !ew.checkNumber(elm.value))
					return this.onError(elm, "<?php echo JsEncode($purchasefeecustom_edit->fixedfeeconsumerexternal->errorMessage()) ?>");
			<?php if ($purchasefeecustom_edit->fixedfeeconsumerfranchisee->Required) { ?>
				elm = this.getElements("x" + infix + "_fixedfeeconsumerfranchisee");
				if (elm && !ew.isHidden(elm) && !ew.hasValue(elm))
					return this.onError(elm, "<?php echo JsEncode(str_replace("%s", $purchasefeecustom_edit->fixedfeeconsumerfranchisee->caption(), $purchasefeecustom_edit->fixedfeeconsumerfranchisee->RequiredErrorMessage)) ?>");
			<?php } ?>
				elm = this.getElements("x" + infix + "_fixedfeeconsumerfranchisee");
				if (elm && !ew.checkNumber(elm.value))
					return this.onError(elm, "<?php echo JsEncode($purchasefeecustom_edit->fixedfeeconsumerfranchisee->errorMessage()) ?>");
			<?php if ($purchasefeecustom_edit->fixedfeeconsumerreseller->Required) { ?>
				elm = this.getElements("x" + infix + "_fixedfeeconsumerreseller");
				if (elm && !ew.isHidden(elm) && !ew.hasValue(elm))
					return this.onError(elm, "<?php echo JsEncode(str_replace("%s", $purchasefeecustom_edit->fixedfeeconsumerreseller->caption(), $purchasefeecustom_edit->fixedfeeconsumerreseller->RequiredErrorMessage)) ?>");
			<?php } ?>
				elm = this.getElements("x" + infix + "_fixedfeeconsumerreseller");
				if (elm && !ew.checkNumber(elm.value))
					return this.onError(elm, "<?php echo JsEncode($purchasefeecustom_edit->fixedfeeconsumerreseller->errorMessage()) ?>");
			<?php if ($purchasefeecustom_edit->maxconsumerfees->Required) { ?>
				elm = this.getElements("x" + infix + "_maxconsumerfees");
				if (elm && !ew.isHidden(elm) && !ew.hasValue(elm))
					return this.onError(elm, "<?php echo JsEncode(str_replace("%s", $purchasefeecustom_edit->maxconsumerfees->caption(), $purchasefeecustom_edit->maxconsumerfees->RequiredErrorMessage)) ?>");
			<?php } ?>
				elm = this.getElements("x" + infix + "_maxconsumerfees");
				if (elm && !ew.checkNumber(elm.value))
					return this.onError(elm, "<?php echo JsEncode($purchasefeecustom_edit->maxconsumerfees->errorMessage()) ?>");
			<?php if ($purchasefeecustom_edit->maxmerchantfees->Required) { ?>
				elm = this.getElements("x" + infix + "_maxmerchantfees");
				if (elm && !ew.isHidden(elm) && !ew.hasValue(elm))
					return this.onError(elm, "<?php echo JsEncode(str_replace("%s", $purchasefeecustom_edit->maxmerchantfees->caption(), $purchasefeecustom_edit->maxmerchantfees->RequiredErrorMessage)) ?>");
			<?php } ?>
				elm = this.getElements("x" + infix + "_maxmerchantfees");
				if (elm && !ew.checkNumber(elm.value))
					return this.onError(elm, "<?php echo JsEncode($purchasefeecustom_edit->maxmerchantfees->errorMessage()) ?>");
			<?php if ($purchasefeecustom_edit->usetotalpercentage->Required) { ?>
				elm = this.getElements("x" + infix + "_usetotalpercentage");
				if (elm && !ew.isHidden(elm) && !ew.hasValue(elm))
					return this.onError(elm, "<?php echo JsEncode(str_replace("%s", $purchasefeecustom_edit->usetotalpercentage->caption(), $purchasefeecustom_edit->usetotalpercentage->RequiredErrorMessage)) ?>");
			<?php } ?>
				elm = this.getElements("x" + infix + "_usetotalpercentage");
				if (elm && !ew.checkInteger(elm.value))
					return this.onError(elm, "<?php echo JsEncode($purchasefeecustom_edit->usetotalpercentage->errorMessage()) ?>");

				// Call Form_CustomValidate event
				if (!this.Form_CustomValidate(fobj))
					return false;
		}

		// Process detail forms
		var dfs = $fobj.find("input[name='detailpage']").get();
		for (var i = 0; i < dfs.length; i++) {
			var df = dfs[i], val = df.value;
			if (val && ew.forms[val])
				if (!ew.forms[val].validate())
					return false;
		}
		return true;
	}

	// Form_CustomValidate
	fpurchasefeecustomedit.Form_CustomValidate = function(fobj) { // DO NOT CHANGE THIS LINE!

		// Your custom validation code here, return false if invalid.
		return true;
	}

	// Use JavaScript validation or not
	fpurchasefeecustomedit.validateRequired = <?php echo Config("CLIENT_VALIDATE") ? "true" : "false" ?>;

	// Dynamic selection lists
	fpurchasefeecustomedit.lists["x_active"] = <?php echo $purchasefeecustom_edit->active->Lookup->toClientList($purchasefeecustom_edit) ?>;
	fpurchasefeecustomedit.lists["x_active"].options = <?php echo JsonEncode($purchasefeecustom_edit->active->lookupOptions()) ?>;
	loadjs.done("fpurchasefeecustomedit");
});
</script>
<script>
loadjs.ready("head", function() {

	// Client script
	// Write your client script here, no need to add script tags.

});
</script>
<?php $purchasefeecustom_edit->showPageHeader(); ?>
<?php
$purchasefeecustom_edit->showMessage();
?>
<form name="fpurchasefeecustomedit" id="fpurchasefeecustomedit" class="<?php echo $purchasefeecustom_edit->FormClassName ?>" action="<?php echo CurrentPageName() ?>" method="post">
<?php if ($Page->CheckToken) { ?>
<input type="hidden" name="<?php echo Config("TOKEN_NAME") ?>" value="<?php echo $Page->Token ?>">
<?php } ?>
<input type="hidden" name="t" value="purchasefeecustom">
<input type="hidden" name="action" id="action" value="update">
<input type="hidden" name="modal" value="<?php echo (int)$purchasefeecustom_edit->IsModal ?>">
<?php if ($purchasefeecustom->getCurrentMasterTable() == "purchasefeetablecustom") { ?>
<input type="hidden" name="<?php echo Config("TABLE_SHOW_MASTER") ?>" value="purchasefeetablecustom">
<input type="hidden" name="fk_tableid" value="<?php echo HtmlEncode($purchasefeecustom_edit->tableid->getSessionValue()) ?>">
<?php } ?>
<div class="ew-edit-div"><!-- page* -->
<?php if ($purchasefeecustom_edit->feeid->Visible) { // feeid ?>
	<div id="r_feeid" class="form-group row">
		<label id="elh_purchasefeecustom_feeid" class="<?php echo $purchasefeecustom_edit->LeftColumnClass ?>"><?php echo $purchasefeecustom_edit->feeid->caption() ?><?php echo $purchasefeecustom_edit->feeid->Required ? $Language->phrase("FieldRequiredIndicator") : "" ?></label>
		<div class="<?php echo $purchasefeecustom_edit->RightColumnClass ?>"><div <?php echo $purchasefeecustom_edit->feeid->cellAttributes() ?>>
<span id="el_purchasefeecustom_feeid">
<span<?php echo $purchasefeecustom_edit->feeid->viewAttributes() ?>><input type="text" readonly class="form-control-plaintext" value="<?php echo HtmlEncode(RemoveHtml($purchasefeecustom_edit->feeid->EditValue)) ?>"></span>
</span>
<input type="hidden" data-table="purchasefeecustom" data-field="x_feeid" name="x_feeid" id="x_feeid" value="<?php echo HtmlEncode($purchasefeecustom_edit->feeid->CurrentValue) ?>">
<?php echo $purchasefeecustom_edit->feeid->CustomMsg ?></div></div>
	</div>
<?php } ?>
<?php if ($purchasefeecustom_edit->tableid->Visible) { // tableid ?>
	<div id="r_tableid" class="form-group row">
		<label id="elh_purchasefeecustom_tableid" for="x_tableid" class="<?php echo $purchasefeecustom_edit->LeftColumnClass ?>"><?php echo $purchasefeecustom_edit->tableid->caption() ?><?php echo $purchasefeecustom_edit->tableid->Required ? $Language->phrase("FieldRequiredIndicator") : "" ?></label>
		<div class="<?php echo $purchasefeecustom_edit->RightColumnClass ?>"><div <?php echo $purchasefeecustom_edit->tableid->cellAttributes() ?>>
<?php if ($purchasefeecustom_edit->tableid->getSessionValue() != "") { ?>
<span id="el_purchasefeecustom_tableid">
<span<?php echo $purchasefeecustom_edit->tableid->viewAttributes() ?>><input type="text" readonly class="form-control-plaintext" value="<?php echo HtmlEncode(RemoveHtml($purchasefeecustom_edit->tableid->ViewValue)) ?>"></span>
</span>
<input type="hidden" id="x_tableid" name="x_tableid" value="<?php echo HtmlEncode($purchasefeecustom_edit->tableid->CurrentValue) ?>">
<?php } else { ?>
<span id="el_purchasefeecustom_tableid">
<input type="text" data-table="purchasefeecustom" data-field="x_tableid" name="x_tableid" id="x_tableid" size="30" placeholder="<?php echo HtmlEncode($purchasefeecustom_edit->tableid->getPlaceHolder()) ?>" value="<?php echo $purchasefeecustom_edit->tableid->EditValue ?>"<?php echo $purchasefeecustom_edit->tableid->editAttributes() ?>>
</span>
<?php } ?>
<?php echo $purchasefeecustom_edit->tableid->CustomMsg ?></div></div>
	</div>
<?php } ?>
<?php if ($purchasefeecustom_edit->active->Visible) { // active ?>
	<div id="r_active" class="form-group row">
		<label id="elh_purchasefeecustom_active" for="x_active" class="<?php echo $purchasefeecustom_edit->LeftColumnClass ?>"><?php echo $purchasefeecustom_edit->active->caption() ?><?php echo $purchasefeecustom_edit->active->Required ? $Language->phrase("FieldRequiredIndicator") : "" ?></label>
		<div class="<?php echo $purchasefeecustom_edit->RightColumnClass ?>"><div <?php echo $purchasefeecustom_edit->active->cellAttributes() ?>>
<span id="el_purchasefeecustom_active">
<div class="input-group">
	<select class="custom-select ew-custom-select" data-table="purchasefeecustom" data-field="x_active" data-value-separator="<?php echo $purchasefeecustom_edit->active->displayValueSeparatorAttribute() ?>" id="x_active" name="x_active"<?php echo $purchasefeecustom_edit->active->editAttributes() ?>>
			<?php echo $purchasefeecustom_edit->active->selectOptionListHtml("x_active") ?>
		</select>
</div>
<?php echo $purchasefeecustom_edit->active->Lookup->getParamTag($purchasefeecustom_edit, "p_x_active") ?>
</span>
<?php echo $purchasefeecustom_edit->active->CustomMsg ?></div></div>
	</div>
<?php } ?>
<?php if ($purchasefeecustom_edit->currencycode->Visible) { // currencycode ?>
	<div id="r_currencycode" class="form-group row">
		<label id="elh_purchasefeecustom_currencycode" for="x_currencycode" class="<?php echo $purchasefeecustom_edit->LeftColumnClass ?>"><?php echo $purchasefeecustom_edit->currencycode->caption() ?><?php echo $purchasefeecustom_edit->currencycode->Required ? $Language->phrase("FieldRequiredIndicator") : "" ?></label>
		<div class="<?php echo $purchasefeecustom_edit->RightColumnClass ?>"><div <?php echo $purchasefeecustom_edit->currencycode->cellAttributes() ?>>
<span id="el_purchasefeecustom_currencycode">
<input type="text" data-table="purchasefeecustom" data-field="x_currencycode" name="x_currencycode" id="x_currencycode" size="30" maxlength="3" placeholder="<?php echo HtmlEncode($purchasefeecustom_edit->currencycode->getPlaceHolder()) ?>" value="<?php echo $purchasefeecustom_edit->currencycode->EditValue ?>"<?php echo $purchasefeecustom_edit->currencycode->editAttributes() ?>>
</span>
<?php echo $purchasefeecustom_edit->currencycode->CustomMsg ?></div></div>
	</div>
<?php } ?>
<?php if ($purchasefeecustom_edit->startvalue->Visible) { // startvalue ?>
	<div id="r_startvalue" class="form-group row">
		<label id="elh_purchasefeecustom_startvalue" for="x_startvalue" class="<?php echo $purchasefeecustom_edit->LeftColumnClass ?>"><?php echo $purchasefeecustom_edit->startvalue->caption() ?><?php echo $purchasefeecustom_edit->startvalue->Required ? $Language->phrase("FieldRequiredIndicator") : "" ?></label>
		<div class="<?php echo $purchasefeecustom_edit->RightColumnClass ?>"><div <?php echo $purchasefeecustom_edit->startvalue->cellAttributes() ?>>
<span id="el_purchasefeecustom_startvalue">
<input type="text" data-table="purchasefeecustom" data-field="x_startvalue" name="x_startvalue" id="x_startvalue" size="30" placeholder="<?php echo HtmlEncode($purchasefeecustom_edit->startvalue->getPlaceHolder()) ?>" value="<?php echo $purchasefeecustom_edit->startvalue->EditValue ?>"<?php echo $purchasefeecustom_edit->startvalue->editAttributes() ?>>
</span>
<?php echo $purchasefeecustom_edit->startvalue->CustomMsg ?></div></div>
	</div>
<?php } ?>
<?php if ($purchasefeecustom_edit->endvalue->Visible) { // endvalue ?>
	<div id="r_endvalue" class="form-group row">
		<label id="elh_purchasefeecustom_endvalue" for="x_endvalue" class="<?php echo $purchasefeecustom_edit->LeftColumnClass ?>"><?php echo $purchasefeecustom_edit->endvalue->caption() ?><?php echo $purchasefeecustom_edit->endvalue->Required ? $Language->phrase("FieldRequiredIndicator") : "" ?></label>
		<div class="<?php echo $purchasefeecustom_edit->RightColumnClass ?>"><div <?php echo $purchasefeecustom_edit->endvalue->cellAttributes() ?>>
<span id="el_purchasefeecustom_endvalue">
<input type="text" data-table="purchasefeecustom" data-field="x_endvalue" name="x_endvalue" id="x_endvalue" size="30" placeholder="<?php echo HtmlEncode($purchasefeecustom_edit->endvalue->getPlaceHolder()) ?>" value="<?php echo $purchasefeecustom_edit->endvalue->EditValue ?>"<?php echo $purchasefeecustom_edit->endvalue->editAttributes() ?>>
</span>
<?php echo $purchasefeecustom_edit->endvalue->CustomMsg ?></div></div>
	</div>
<?php } ?>
<?php if ($purchasefeecustom_edit->franchiseeid->Visible) { // franchiseeid ?>
	<div id="r_franchiseeid" class="form-group row">
		<label id="elh_purchasefeecustom_franchiseeid" for="x_franchiseeid" class="<?php echo $purchasefeecustom_edit->LeftColumnClass ?>"><?php echo $purchasefeecustom_edit->franchiseeid->caption() ?><?php echo $purchasefeecustom_edit->franchiseeid->Required ? $Language->phrase("FieldRequiredIndicator") : "" ?></label>
		<div class="<?php echo $purchasefeecustom_edit->RightColumnClass ?>"><div <?php echo $purchasefeecustom_edit->franchiseeid->cellAttributes() ?>>
<span id="el_purchasefeecustom_franchiseeid">
<input type="text" data-table="purchasefeecustom" data-field="x_franchiseeid" name="x_franchiseeid" id="x_franchiseeid" size="30" maxlength="6" placeholder="<?php echo HtmlEncode($purchasefeecustom_edit->franchiseeid->getPlaceHolder()) ?>" value="<?php echo $purchasefeecustom_edit->franchiseeid->EditValue ?>"<?php echo $purchasefeecustom_edit->franchiseeid->editAttributes() ?>>
</span>
<?php echo $purchasefeecustom_edit->franchiseeid->CustomMsg ?></div></div>
	</div>
<?php } ?>
<?php if ($purchasefeecustom_edit->piid->Visible) { // piid ?>
	<div id="r_piid" class="form-group row">
		<label id="elh_purchasefeecustom_piid" for="x_piid" class="<?php echo $purchasefeecustom_edit->LeftColumnClass ?>"><?php echo $purchasefeecustom_edit->piid->caption() ?><?php echo $purchasefeecustom_edit->piid->Required ? $Language->phrase("FieldRequiredIndicator") : "" ?></label>
		<div class="<?php echo $purchasefeecustom_edit->RightColumnClass ?>"><div <?php echo $purchasefeecustom_edit->piid->cellAttributes() ?>>
<span id="el_purchasefeecustom_piid">
<input type="text" data-table="purchasefeecustom" data-field="x_piid" name="x_piid" id="x_piid" size="30" maxlength="5" placeholder="<?php echo HtmlEncode($purchasefeecustom_edit->piid->getPlaceHolder()) ?>" value="<?php echo $purchasefeecustom_edit->piid->EditValue ?>"<?php echo $purchasefeecustom_edit->piid->editAttributes() ?>>
</span>
<?php echo $purchasefeecustom_edit->piid->CustomMsg ?></div></div>
	</div>
<?php } ?>
<?php if ($purchasefeecustom_edit->countryid->Visible) { // countryid ?>
	<div id="r_countryid" class="form-group row">
		<label id="elh_purchasefeecustom_countryid" for="x_countryid" class="<?php echo $purchasefeecustom_edit->LeftColumnClass ?>"><?php echo $purchasefeecustom_edit->countryid->caption() ?><?php echo $purchasefeecustom_edit->countryid->Required ? $Language->phrase("FieldRequiredIndicator") : "" ?></label>
		<div class="<?php echo $purchasefeecustom_edit->RightColumnClass ?>"><div <?php echo $purchasefeecustom_edit->countryid->cellAttributes() ?>>
<span id="el_purchasefeecustom_countryid">
<input type="text" data-table="purchasefeecustom" data-field="x_countryid" name="x_countryid" id="x_countryid" size="30" maxlength="3" placeholder="<?php echo HtmlEncode($purchasefeecustom_edit->countryid->getPlaceHolder()) ?>" value="<?php echo $purchasefeecustom_edit->countryid->EditValue ?>"<?php echo $purchasefeecustom_edit->countryid->editAttributes() ?>>
</span>
<?php echo $purchasefeecustom_edit->countryid->CustomMsg ?></div></div>
	</div>
<?php } ?>
<?php if ($purchasefeecustom_edit->percentfeemerchantsystem->Visible) { // percentfeemerchantsystem ?>
	<div id="r_percentfeemerchantsystem" class="form-group row">
		<label id="elh_purchasefeecustom_percentfeemerchantsystem" for="x_percentfeemerchantsystem" class="<?php echo $purchasefeecustom_edit->LeftColumnClass ?>"><?php echo $purchasefeecustom_edit->percentfeemerchantsystem->caption() ?><?php echo $purchasefeecustom_edit->percentfeemerchantsystem->Required ? $Language->phrase("FieldRequiredIndicator") : "" ?></label>
		<div class="<?php echo $purchasefeecustom_edit->RightColumnClass ?>"><div <?php echo $purchasefeecustom_edit->percentfeemerchantsystem->cellAttributes() ?>>
<span id="el_purchasefeecustom_percentfeemerchantsystem">
<input type="text" data-table="purchasefeecustom" data-field="x_percentfeemerchantsystem" name="x_percentfeemerchantsystem" id="x_percentfeemerchantsystem" size="30" placeholder="<?php echo HtmlEncode($purchasefeecustom_edit->percentfeemerchantsystem->getPlaceHolder()) ?>" value="<?php echo $purchasefeecustom_edit->percentfeemerchantsystem->EditValue ?>"<?php echo $purchasefeecustom_edit->percentfeemerchantsystem->editAttributes() ?>>
</span>
<?php echo $purchasefeecustom_edit->percentfeemerchantsystem->CustomMsg ?></div></div>
	</div>
<?php } ?>
<?php if ($purchasefeecustom_edit->percentfeemerchantexternal->Visible) { // percentfeemerchantexternal ?>
	<div id="r_percentfeemerchantexternal" class="form-group row">
		<label id="elh_purchasefeecustom_percentfeemerchantexternal" for="x_percentfeemerchantexternal" class="<?php echo $purchasefeecustom_edit->LeftColumnClass ?>"><?php echo $purchasefeecustom_edit->percentfeemerchantexternal->caption() ?><?php echo $purchasefeecustom_edit->percentfeemerchantexternal->Required ? $Language->phrase("FieldRequiredIndicator") : "" ?></label>
		<div class="<?php echo $purchasefeecustom_edit->RightColumnClass ?>"><div <?php echo $purchasefeecustom_edit->percentfeemerchantexternal->cellAttributes() ?>>
<span id="el_purchasefeecustom_percentfeemerchantexternal">
<input type="text" data-table="purchasefeecustom" data-field="x_percentfeemerchantexternal" name="x_percentfeemerchantexternal" id="x_percentfeemerchantexternal" size="30" placeholder="<?php echo HtmlEncode($purchasefeecustom_edit->percentfeemerchantexternal->getPlaceHolder()) ?>" value="<?php echo $purchasefeecustom_edit->percentfeemerchantexternal->EditValue ?>"<?php echo $purchasefeecustom_edit->percentfeemerchantexternal->editAttributes() ?>>
</span>
<?php echo $purchasefeecustom_edit->percentfeemerchantexternal->CustomMsg ?></div></div>
	</div>
<?php } ?>
<?php if ($purchasefeecustom_edit->percentfeemerchantfranchisee->Visible) { // percentfeemerchantfranchisee ?>
	<div id="r_percentfeemerchantfranchisee" class="form-group row">
		<label id="elh_purchasefeecustom_percentfeemerchantfranchisee" for="x_percentfeemerchantfranchisee" class="<?php echo $purchasefeecustom_edit->LeftColumnClass ?>"><?php echo $purchasefeecustom_edit->percentfeemerchantfranchisee->caption() ?><?php echo $purchasefeecustom_edit->percentfeemerchantfranchisee->Required ? $Language->phrase("FieldRequiredIndicator") : "" ?></label>
		<div class="<?php echo $purchasefeecustom_edit->RightColumnClass ?>"><div <?php echo $purchasefeecustom_edit->percentfeemerchantfranchisee->cellAttributes() ?>>
<span id="el_purchasefeecustom_percentfeemerchantfranchisee">
<input type="text" data-table="purchasefeecustom" data-field="x_percentfeemerchantfranchisee" name="x_percentfeemerchantfranchisee" id="x_percentfeemerchantfranchisee" size="30" placeholder="<?php echo HtmlEncode($purchasefeecustom_edit->percentfeemerchantfranchisee->getPlaceHolder()) ?>" value="<?php echo $purchasefeecustom_edit->percentfeemerchantfranchisee->EditValue ?>"<?php echo $purchasefeecustom_edit->percentfeemerchantfranchisee->editAttributes() ?>>
</span>
<?php echo $purchasefeecustom_edit->percentfeemerchantfranchisee->CustomMsg ?></div></div>
	</div>
<?php } ?>
<?php if ($purchasefeecustom_edit->percentfeemerchantreseller->Visible) { // percentfeemerchantreseller ?>
	<div id="r_percentfeemerchantreseller" class="form-group row">
		<label id="elh_purchasefeecustom_percentfeemerchantreseller" for="x_percentfeemerchantreseller" class="<?php echo $purchasefeecustom_edit->LeftColumnClass ?>"><?php echo $purchasefeecustom_edit->percentfeemerchantreseller->caption() ?><?php echo $purchasefeecustom_edit->percentfeemerchantreseller->Required ? $Language->phrase("FieldRequiredIndicator") : "" ?></label>
		<div class="<?php echo $purchasefeecustom_edit->RightColumnClass ?>"><div <?php echo $purchasefeecustom_edit->percentfeemerchantreseller->cellAttributes() ?>>
<span id="el_purchasefeecustom_percentfeemerchantreseller">
<input type="text" data-table="purchasefeecustom" data-field="x_percentfeemerchantreseller" name="x_percentfeemerchantreseller" id="x_percentfeemerchantreseller" size="30" placeholder="<?php echo HtmlEncode($purchasefeecustom_edit->percentfeemerchantreseller->getPlaceHolder()) ?>" value="<?php echo $purchasefeecustom_edit->percentfeemerchantreseller->EditValue ?>"<?php echo $purchasefeecustom_edit->percentfeemerchantreseller->editAttributes() ?>>
</span>
<?php echo $purchasefeecustom_edit->percentfeemerchantreseller->CustomMsg ?></div></div>
	</div>
<?php } ?>
<?php if ($purchasefeecustom_edit->fixedfeemerchantsystem->Visible) { // fixedfeemerchantsystem ?>
	<div id="r_fixedfeemerchantsystem" class="form-group row">
		<label id="elh_purchasefeecustom_fixedfeemerchantsystem" for="x_fixedfeemerchantsystem" class="<?php echo $purchasefeecustom_edit->LeftColumnClass ?>"><?php echo $purchasefeecustom_edit->fixedfeemerchantsystem->caption() ?><?php echo $purchasefeecustom_edit->fixedfeemerchantsystem->Required ? $Language->phrase("FieldRequiredIndicator") : "" ?></label>
		<div class="<?php echo $purchasefeecustom_edit->RightColumnClass ?>"><div <?php echo $purchasefeecustom_edit->fixedfeemerchantsystem->cellAttributes() ?>>
<span id="el_purchasefeecustom_fixedfeemerchantsystem">
<input type="text" data-table="purchasefeecustom" data-field="x_fixedfeemerchantsystem" name="x_fixedfeemerchantsystem" id="x_fixedfeemerchantsystem" size="30" placeholder="<?php echo HtmlEncode($purchasefeecustom_edit->fixedfeemerchantsystem->getPlaceHolder()) ?>" value="<?php echo $purchasefeecustom_edit->fixedfeemerchantsystem->EditValue ?>"<?php echo $purchasefeecustom_edit->fixedfeemerchantsystem->editAttributes() ?>>
</span>
<?php echo $purchasefeecustom_edit->fixedfeemerchantsystem->CustomMsg ?></div></div>
	</div>
<?php } ?>
<?php if ($purchasefeecustom_edit->fixedfeemerchantexternal->Visible) { // fixedfeemerchantexternal ?>
	<div id="r_fixedfeemerchantexternal" class="form-group row">
		<label id="elh_purchasefeecustom_fixedfeemerchantexternal" for="x_fixedfeemerchantexternal" class="<?php echo $purchasefeecustom_edit->LeftColumnClass ?>"><?php echo $purchasefeecustom_edit->fixedfeemerchantexternal->caption() ?><?php echo $purchasefeecustom_edit->fixedfeemerchantexternal->Required ? $Language->phrase("FieldRequiredIndicator") : "" ?></label>
		<div class="<?php echo $purchasefeecustom_edit->RightColumnClass ?>"><div <?php echo $purchasefeecustom_edit->fixedfeemerchantexternal->cellAttributes() ?>>
<span id="el_purchasefeecustom_fixedfeemerchantexternal">
<input type="text" data-table="purchasefeecustom" data-field="x_fixedfeemerchantexternal" name="x_fixedfeemerchantexternal" id="x_fixedfeemerchantexternal" size="30" placeholder="<?php echo HtmlEncode($purchasefeecustom_edit->fixedfeemerchantexternal->getPlaceHolder()) ?>" value="<?php echo $purchasefeecustom_edit->fixedfeemerchantexternal->EditValue ?>"<?php echo $purchasefeecustom_edit->fixedfeemerchantexternal->editAttributes() ?>>
</span>
<?php echo $purchasefeecustom_edit->fixedfeemerchantexternal->CustomMsg ?></div></div>
	</div>
<?php } ?>
<?php if ($purchasefeecustom_edit->fixedfeemerchantfranchisee->Visible) { // fixedfeemerchantfranchisee ?>
	<div id="r_fixedfeemerchantfranchisee" class="form-group row">
		<label id="elh_purchasefeecustom_fixedfeemerchantfranchisee" for="x_fixedfeemerchantfranchisee" class="<?php echo $purchasefeecustom_edit->LeftColumnClass ?>"><?php echo $purchasefeecustom_edit->fixedfeemerchantfranchisee->caption() ?><?php echo $purchasefeecustom_edit->fixedfeemerchantfranchisee->Required ? $Language->phrase("FieldRequiredIndicator") : "" ?></label>
		<div class="<?php echo $purchasefeecustom_edit->RightColumnClass ?>"><div <?php echo $purchasefeecustom_edit->fixedfeemerchantfranchisee->cellAttributes() ?>>
<span id="el_purchasefeecustom_fixedfeemerchantfranchisee">
<input type="text" data-table="purchasefeecustom" data-field="x_fixedfeemerchantfranchisee" name="x_fixedfeemerchantfranchisee" id="x_fixedfeemerchantfranchisee" size="30" placeholder="<?php echo HtmlEncode($purchasefeecustom_edit->fixedfeemerchantfranchisee->getPlaceHolder()) ?>" value="<?php echo $purchasefeecustom_edit->fixedfeemerchantfranchisee->EditValue ?>"<?php echo $purchasefeecustom_edit->fixedfeemerchantfranchisee->editAttributes() ?>>
</span>
<?php echo $purchasefeecustom_edit->fixedfeemerchantfranchisee->CustomMsg ?></div></div>
	</div>
<?php } ?>
<?php if ($purchasefeecustom_edit->fixedfeemerchantreseller->Visible) { // fixedfeemerchantreseller ?>
	<div id="r_fixedfeemerchantreseller" class="form-group row">
		<label id="elh_purchasefeecustom_fixedfeemerchantreseller" for="x_fixedfeemerchantreseller" class="<?php echo $purchasefeecustom_edit->LeftColumnClass ?>"><?php echo $purchasefeecustom_edit->fixedfeemerchantreseller->caption() ?><?php echo $purchasefeecustom_edit->fixedfeemerchantreseller->Required ? $Language->phrase("FieldRequiredIndicator") : "" ?></label>
		<div class="<?php echo $purchasefeecustom_edit->RightColumnClass ?>"><div <?php echo $purchasefeecustom_edit->fixedfeemerchantreseller->cellAttributes() ?>>
<span id="el_purchasefeecustom_fixedfeemerchantreseller">
<input type="text" data-table="purchasefeecustom" data-field="x_fixedfeemerchantreseller" name="x_fixedfeemerchantreseller" id="x_fixedfeemerchantreseller" size="30" placeholder="<?php echo HtmlEncode($purchasefeecustom_edit->fixedfeemerchantreseller->getPlaceHolder()) ?>" value="<?php echo $purchasefeecustom_edit->fixedfeemerchantreseller->EditValue ?>"<?php echo $purchasefeecustom_edit->fixedfeemerchantreseller->editAttributes() ?>>
</span>
<?php echo $purchasefeecustom_edit->fixedfeemerchantreseller->CustomMsg ?></div></div>
	</div>
<?php } ?>
<?php if ($purchasefeecustom_edit->percentfeeconsumersystem->Visible) { // percentfeeconsumersystem ?>
	<div id="r_percentfeeconsumersystem" class="form-group row">
		<label id="elh_purchasefeecustom_percentfeeconsumersystem" for="x_percentfeeconsumersystem" class="<?php echo $purchasefeecustom_edit->LeftColumnClass ?>"><?php echo $purchasefeecustom_edit->percentfeeconsumersystem->caption() ?><?php echo $purchasefeecustom_edit->percentfeeconsumersystem->Required ? $Language->phrase("FieldRequiredIndicator") : "" ?></label>
		<div class="<?php echo $purchasefeecustom_edit->RightColumnClass ?>"><div <?php echo $purchasefeecustom_edit->percentfeeconsumersystem->cellAttributes() ?>>
<span id="el_purchasefeecustom_percentfeeconsumersystem">
<input type="text" data-table="purchasefeecustom" data-field="x_percentfeeconsumersystem" name="x_percentfeeconsumersystem" id="x_percentfeeconsumersystem" size="30" placeholder="<?php echo HtmlEncode($purchasefeecustom_edit->percentfeeconsumersystem->getPlaceHolder()) ?>" value="<?php echo $purchasefeecustom_edit->percentfeeconsumersystem->EditValue ?>"<?php echo $purchasefeecustom_edit->percentfeeconsumersystem->editAttributes() ?>>
</span>
<?php echo $purchasefeecustom_edit->percentfeeconsumersystem->CustomMsg ?></div></div>
	</div>
<?php } ?>
<?php if ($purchasefeecustom_edit->percentfeeconsumerexternal->Visible) { // percentfeeconsumerexternal ?>
	<div id="r_percentfeeconsumerexternal" class="form-group row">
		<label id="elh_purchasefeecustom_percentfeeconsumerexternal" for="x_percentfeeconsumerexternal" class="<?php echo $purchasefeecustom_edit->LeftColumnClass ?>"><?php echo $purchasefeecustom_edit->percentfeeconsumerexternal->caption() ?><?php echo $purchasefeecustom_edit->percentfeeconsumerexternal->Required ? $Language->phrase("FieldRequiredIndicator") : "" ?></label>
		<div class="<?php echo $purchasefeecustom_edit->RightColumnClass ?>"><div <?php echo $purchasefeecustom_edit->percentfeeconsumerexternal->cellAttributes() ?>>
<span id="el_purchasefeecustom_percentfeeconsumerexternal">
<input type="text" data-table="purchasefeecustom" data-field="x_percentfeeconsumerexternal" name="x_percentfeeconsumerexternal" id="x_percentfeeconsumerexternal" size="30" placeholder="<?php echo HtmlEncode($purchasefeecustom_edit->percentfeeconsumerexternal->getPlaceHolder()) ?>" value="<?php echo $purchasefeecustom_edit->percentfeeconsumerexternal->EditValue ?>"<?php echo $purchasefeecustom_edit->percentfeeconsumerexternal->editAttributes() ?>>
</span>
<?php echo $purchasefeecustom_edit->percentfeeconsumerexternal->CustomMsg ?></div></div>
	</div>
<?php } ?>
<?php if ($purchasefeecustom_edit->percentfeeconsumerfranchisee->Visible) { // percentfeeconsumerfranchisee ?>
	<div id="r_percentfeeconsumerfranchisee" class="form-group row">
		<label id="elh_purchasefeecustom_percentfeeconsumerfranchisee" for="x_percentfeeconsumerfranchisee" class="<?php echo $purchasefeecustom_edit->LeftColumnClass ?>"><?php echo $purchasefeecustom_edit->percentfeeconsumerfranchisee->caption() ?><?php echo $purchasefeecustom_edit->percentfeeconsumerfranchisee->Required ? $Language->phrase("FieldRequiredIndicator") : "" ?></label>
		<div class="<?php echo $purchasefeecustom_edit->RightColumnClass ?>"><div <?php echo $purchasefeecustom_edit->percentfeeconsumerfranchisee->cellAttributes() ?>>
<span id="el_purchasefeecustom_percentfeeconsumerfranchisee">
<input type="text" data-table="purchasefeecustom" data-field="x_percentfeeconsumerfranchisee" name="x_percentfeeconsumerfranchisee" id="x_percentfeeconsumerfranchisee" size="30" placeholder="<?php echo HtmlEncode($purchasefeecustom_edit->percentfeeconsumerfranchisee->getPlaceHolder()) ?>" value="<?php echo $purchasefeecustom_edit->percentfeeconsumerfranchisee->EditValue ?>"<?php echo $purchasefeecustom_edit->percentfeeconsumerfranchisee->editAttributes() ?>>
</span>
<?php echo $purchasefeecustom_edit->percentfeeconsumerfranchisee->CustomMsg ?></div></div>
	</div>
<?php } ?>
<?php if ($purchasefeecustom_edit->percentfeeconsumerreseller->Visible) { // percentfeeconsumerreseller ?>
	<div id="r_percentfeeconsumerreseller" class="form-group row">
		<label id="elh_purchasefeecustom_percentfeeconsumerreseller" for="x_percentfeeconsumerreseller" class="<?php echo $purchasefeecustom_edit->LeftColumnClass ?>"><?php echo $purchasefeecustom_edit->percentfeeconsumerreseller->caption() ?><?php echo $purchasefeecustom_edit->percentfeeconsumerreseller->Required ? $Language->phrase("FieldRequiredIndicator") : "" ?></label>
		<div class="<?php echo $purchasefeecustom_edit->RightColumnClass ?>"><div <?php echo $purchasefeecustom_edit->percentfeeconsumerreseller->cellAttributes() ?>>
<span id="el_purchasefeecustom_percentfeeconsumerreseller">
<input type="text" data-table="purchasefeecustom" data-field="x_percentfeeconsumerreseller" name="x_percentfeeconsumerreseller" id="x_percentfeeconsumerreseller" size="30" placeholder="<?php echo HtmlEncode($purchasefeecustom_edit->percentfeeconsumerreseller->getPlaceHolder()) ?>" value="<?php echo $purchasefeecustom_edit->percentfeeconsumerreseller->EditValue ?>"<?php echo $purchasefeecustom_edit->percentfeeconsumerreseller->editAttributes() ?>>
</span>
<?php echo $purchasefeecustom_edit->percentfeeconsumerreseller->CustomMsg ?></div></div>
	</div>
<?php } ?>
<?php if ($purchasefeecustom_edit->fixedfeeconsumersystem->Visible) { // fixedfeeconsumersystem ?>
	<div id="r_fixedfeeconsumersystem" class="form-group row">
		<label id="elh_purchasefeecustom_fixedfeeconsumersystem" for="x_fixedfeeconsumersystem" class="<?php echo $purchasefeecustom_edit->LeftColumnClass ?>"><?php echo $purchasefeecustom_edit->fixedfeeconsumersystem->caption() ?><?php echo $purchasefeecustom_edit->fixedfeeconsumersystem->Required ? $Language->phrase("FieldRequiredIndicator") : "" ?></label>
		<div class="<?php echo $purchasefeecustom_edit->RightColumnClass ?>"><div <?php echo $purchasefeecustom_edit->fixedfeeconsumersystem->cellAttributes() ?>>
<span id="el_purchasefeecustom_fixedfeeconsumersystem">
<input type="text" data-table="purchasefeecustom" data-field="x_fixedfeeconsumersystem" name="x_fixedfeeconsumersystem" id="x_fixedfeeconsumersystem" size="30" placeholder="<?php echo HtmlEncode($purchasefeecustom_edit->fixedfeeconsumersystem->getPlaceHolder()) ?>" value="<?php echo $purchasefeecustom_edit->fixedfeeconsumersystem->EditValue ?>"<?php echo $purchasefeecustom_edit->fixedfeeconsumersystem->editAttributes() ?>>
</span>
<?php echo $purchasefeecustom_edit->fixedfeeconsumersystem->CustomMsg ?></div></div>
	</div>
<?php } ?>
<?php if ($purchasefeecustom_edit->fixedfeeconsumerexternal->Visible) { // fixedfeeconsumerexternal ?>
	<div id="r_fixedfeeconsumerexternal" class="form-group row">
		<label id="elh_purchasefeecustom_fixedfeeconsumerexternal" for="x_fixedfeeconsumerexternal" class="<?php echo $purchasefeecustom_edit->LeftColumnClass ?>"><?php echo $purchasefeecustom_edit->fixedfeeconsumerexternal->caption() ?><?php echo $purchasefeecustom_edit->fixedfeeconsumerexternal->Required ? $Language->phrase("FieldRequiredIndicator") : "" ?></label>
		<div class="<?php echo $purchasefeecustom_edit->RightColumnClass ?>"><div <?php echo $purchasefeecustom_edit->fixedfeeconsumerexternal->cellAttributes() ?>>
<span id="el_purchasefeecustom_fixedfeeconsumerexternal">
<input type="text" data-table="purchasefeecustom" data-field="x_fixedfeeconsumerexternal" name="x_fixedfeeconsumerexternal" id="x_fixedfeeconsumerexternal" size="30" placeholder="<?php echo HtmlEncode($purchasefeecustom_edit->fixedfeeconsumerexternal->getPlaceHolder()) ?>" value="<?php echo $purchasefeecustom_edit->fixedfeeconsumerexternal->EditValue ?>"<?php echo $purchasefeecustom_edit->fixedfeeconsumerexternal->editAttributes() ?>>
</span>
<?php echo $purchasefeecustom_edit->fixedfeeconsumerexternal->CustomMsg ?></div></div>
	</div>
<?php } ?>
<?php if ($purchasefeecustom_edit->fixedfeeconsumerfranchisee->Visible) { // fixedfeeconsumerfranchisee ?>
	<div id="r_fixedfeeconsumerfranchisee" class="form-group row">
		<label id="elh_purchasefeecustom_fixedfeeconsumerfranchisee" for="x_fixedfeeconsumerfranchisee" class="<?php echo $purchasefeecustom_edit->LeftColumnClass ?>"><?php echo $purchasefeecustom_edit->fixedfeeconsumerfranchisee->caption() ?><?php echo $purchasefeecustom_edit->fixedfeeconsumerfranchisee->Required ? $Language->phrase("FieldRequiredIndicator") : "" ?></label>
		<div class="<?php echo $purchasefeecustom_edit->RightColumnClass ?>"><div <?php echo $purchasefeecustom_edit->fixedfeeconsumerfranchisee->cellAttributes() ?>>
<span id="el_purchasefeecustom_fixedfeeconsumerfranchisee">
<input type="text" data-table="purchasefeecustom" data-field="x_fixedfeeconsumerfranchisee" name="x_fixedfeeconsumerfranchisee" id="x_fixedfeeconsumerfranchisee" size="30" placeholder="<?php echo HtmlEncode($purchasefeecustom_edit->fixedfeeconsumerfranchisee->getPlaceHolder()) ?>" value="<?php echo $purchasefeecustom_edit->fixedfeeconsumerfranchisee->EditValue ?>"<?php echo $purchasefeecustom_edit->fixedfeeconsumerfranchisee->editAttributes() ?>>
</span>
<?php echo $purchasefeecustom_edit->fixedfeeconsumerfranchisee->CustomMsg ?></div></div>
	</div>
<?php } ?>
<?php if ($purchasefeecustom_edit->fixedfeeconsumerreseller->Visible) { // fixedfeeconsumerreseller ?>
	<div id="r_fixedfeeconsumerreseller" class="form-group row">
		<label id="elh_purchasefeecustom_fixedfeeconsumerreseller" for="x_fixedfeeconsumerreseller" class="<?php echo $purchasefeecustom_edit->LeftColumnClass ?>"><?php echo $purchasefeecustom_edit->fixedfeeconsumerreseller->caption() ?><?php echo $purchasefeecustom_edit->fixedfeeconsumerreseller->Required ? $Language->phrase("FieldRequiredIndicator") : "" ?></label>
		<div class="<?php echo $purchasefeecustom_edit->RightColumnClass ?>"><div <?php echo $purchasefeecustom_edit->fixedfeeconsumerreseller->cellAttributes() ?>>
<span id="el_purchasefeecustom_fixedfeeconsumerreseller">
<input type="text" data-table="purchasefeecustom" data-field="x_fixedfeeconsumerreseller" name="x_fixedfeeconsumerreseller" id="x_fixedfeeconsumerreseller" size="30" placeholder="<?php echo HtmlEncode($purchasefeecustom_edit->fixedfeeconsumerreseller->getPlaceHolder()) ?>" value="<?php echo $purchasefeecustom_edit->fixedfeeconsumerreseller->EditValue ?>"<?php echo $purchasefeecustom_edit->fixedfeeconsumerreseller->editAttributes() ?>>
</span>
<?php echo $purchasefeecustom_edit->fixedfeeconsumerreseller->CustomMsg ?></div></div>
	</div>
<?php } ?>
<?php if ($purchasefeecustom_edit->maxconsumerfees->Visible) { // maxconsumerfees ?>
	<div id="r_maxconsumerfees" class="form-group row">
		<label id="elh_purchasefeecustom_maxconsumerfees" for="x_maxconsumerfees" class="<?php echo $purchasefeecustom_edit->LeftColumnClass ?>"><?php echo $purchasefeecustom_edit->maxconsumerfees->caption() ?><?php echo $purchasefeecustom_edit->maxconsumerfees->Required ? $Language->phrase("FieldRequiredIndicator") : "" ?></label>
		<div class="<?php echo $purchasefeecustom_edit->RightColumnClass ?>"><div <?php echo $purchasefeecustom_edit->maxconsumerfees->cellAttributes() ?>>
<span id="el_purchasefeecustom_maxconsumerfees">
<input type="text" data-table="purchasefeecustom" data-field="x_maxconsumerfees" name="x_maxconsumerfees" id="x_maxconsumerfees" size="30" placeholder="<?php echo HtmlEncode($purchasefeecustom_edit->maxconsumerfees->getPlaceHolder()) ?>" value="<?php echo $purchasefeecustom_edit->maxconsumerfees->EditValue ?>"<?php echo $purchasefeecustom_edit->maxconsumerfees->editAttributes() ?>>
</span>
<?php echo $purchasefeecustom_edit->maxconsumerfees->CustomMsg ?></div></div>
	</div>
<?php } ?>
<?php if ($purchasefeecustom_edit->maxmerchantfees->Visible) { // maxmerchantfees ?>
	<div id="r_maxmerchantfees" class="form-group row">
		<label id="elh_purchasefeecustom_maxmerchantfees" for="x_maxmerchantfees" class="<?php echo $purchasefeecustom_edit->LeftColumnClass ?>"><?php echo $purchasefeecustom_edit->maxmerchantfees->caption() ?><?php echo $purchasefeecustom_edit->maxmerchantfees->Required ? $Language->phrase("FieldRequiredIndicator") : "" ?></label>
		<div class="<?php echo $purchasefeecustom_edit->RightColumnClass ?>"><div <?php echo $purchasefeecustom_edit->maxmerchantfees->cellAttributes() ?>>
<span id="el_purchasefeecustom_maxmerchantfees">
<input type="text" data-table="purchasefeecustom" data-field="x_maxmerchantfees" name="x_maxmerchantfees" id="x_maxmerchantfees" size="30" placeholder="<?php echo HtmlEncode($purchasefeecustom_edit->maxmerchantfees->getPlaceHolder()) ?>" value="<?php echo $purchasefeecustom_edit->maxmerchantfees->EditValue ?>"<?php echo $purchasefeecustom_edit->maxmerchantfees->editAttributes() ?>>
</span>
<?php echo $purchasefeecustom_edit->maxmerchantfees->CustomMsg ?></div></div>
	</div>
<?php } ?>
<?php if ($purchasefeecustom_edit->usetotalpercentage->Visible) { // usetotalpercentage ?>
	<div id="r_usetotalpercentage" class="form-group row">
		<label id="elh_purchasefeecustom_usetotalpercentage" for="x_usetotalpercentage" class="<?php echo $purchasefeecustom_edit->LeftColumnClass ?>"><?php echo $purchasefeecustom_edit->usetotalpercentage->caption() ?><?php echo $purchasefeecustom_edit->usetotalpercentage->Required ? $Language->phrase("FieldRequiredIndicator") : "" ?></label>
		<div class="<?php echo $purchasefeecustom_edit->RightColumnClass ?>"><div <?php echo $purchasefeecustom_edit->usetotalpercentage->cellAttributes() ?>>
<span id="el_purchasefeecustom_usetotalpercentage">
<input type="text" data-table="purchasefeecustom" data-field="x_usetotalpercentage" name="x_usetotalpercentage" id="x_usetotalpercentage" size="30" maxlength="1" placeholder="<?php echo HtmlEncode($purchasefeecustom_edit->usetotalpercentage->getPlaceHolder()) ?>" value="<?php echo $purchasefeecustom_edit->usetotalpercentage->EditValue ?>"<?php echo $purchasefeecustom_edit->usetotalpercentage->editAttributes() ?>>
</span>
<?php echo $purchasefeecustom_edit->usetotalpercentage->CustomMsg ?></div></div>
	</div>
<?php } ?>
</div><!-- /page* -->
<?php if (!$purchasefeecustom_edit->IsModal) { ?>
<div class="form-group row"><!-- buttons .form-group -->
	<div class="<?php echo $purchasefeecustom_edit->OffsetColumnClass ?>"><!-- buttons offset -->
<button class="btn btn-primary ew-btn" name="btn-action" id="btn-action" type="submit"><?php echo $Language->phrase("SaveBtn") ?></button>
<button class="btn btn-default ew-btn" name="btn-cancel" id="btn-cancel" type="button" data-href="<?php echo $purchasefeecustom_edit->getReturnUrl() ?>"><?php echo $Language->phrase("CancelBtn") ?></button>
	</div><!-- /buttons offset -->
</div><!-- /buttons .form-group -->
<?php } ?>
</form>
<?php
$purchasefeecustom_edit->showPageFooter();
if (Config("DEBUG"))
	echo GetDebugMessage();
?>
<script>
loadjs.ready("load", function() {

	// Startup script
	// Write your table-specific startup script here
	// console.log("page loaded");

});
</script>
<?php include_once "footer.php"; ?>
<?php
$purchasefeecustom_edit->terminate();
?>