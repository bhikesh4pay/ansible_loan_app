<?php
namespace PHPMaker2020\_4payadmin;

// Autoload
include_once "autoload.php";

// Session
if (session_status() !== PHP_SESSION_ACTIVE)
	\Delight\Cookie\Session::start(Config("COOKIE_SAMESITE")); // Init session data

// Output buffering
ob_start();
?>
<?php

// Write header
WriteHeader(FALSE);

// Create page object
$loanusersummarybyyear_delete = new loanusersummarybyyear_delete();

// Run the page
$loanusersummarybyyear_delete->run();

// Setup login status
SetupLoginStatus();
SetClientVar("login", LoginStatus());

// Global Page Rendering event (in userfn*.php)
Page_Rendering();

// Page Rendering event
$loanusersummarybyyear_delete->Page_Render();
?>
<?php include_once "header.php"; ?>
<script>
var floanusersummarybyyeardelete, currentPageID;
loadjs.ready("head", function() {

	// Form object
	currentPageID = ew.PAGE_ID = "delete";
	floanusersummarybyyeardelete = currentForm = new ew.Form("floanusersummarybyyeardelete", "delete");
	loadjs.done("floanusersummarybyyeardelete");
});
</script>
<script>
loadjs.ready("head", function() {

	// Client script
	// Write your client script here, no need to add script tags.

});
</script>
<?php $loanusersummarybyyear_delete->showPageHeader(); ?>
<?php
$loanusersummarybyyear_delete->showMessage();
?>
<form name="floanusersummarybyyeardelete" id="floanusersummarybyyeardelete" class="form-inline ew-form ew-delete-form" action="<?php echo CurrentPageName() ?>" method="post">
<?php if ($Page->CheckToken) { ?>
<input type="hidden" name="<?php echo Config("TOKEN_NAME") ?>" value="<?php echo $Page->Token ?>">
<?php } ?>
<input type="hidden" name="t" value="loanusersummarybyyear">
<input type="hidden" name="action" id="action" value="delete">
<?php foreach ($loanusersummarybyyear_delete->RecKeys as $key) { ?>
<?php $keyvalue = is_array($key) ? implode(Config("COMPOSITE_KEY_SEPARATOR"), $key) : $key; ?>
<input type="hidden" name="key_m[]" value="<?php echo HtmlEncode($keyvalue) ?>">
<?php } ?>
<div class="card ew-card ew-grid">
<div class="<?php echo ResponsiveTableClass() ?>card-body ew-grid-middle-panel">
<table class="table ew-table">
	<thead>
	<tr class="ew-table-header">
<?php if ($loanusersummarybyyear_delete->_userid->Visible) { // userid ?>
		<th class="<?php echo $loanusersummarybyyear_delete->_userid->headerCellClass() ?>"><span id="elh_loanusersummarybyyear__userid" class="loanusersummarybyyear__userid"><?php echo $loanusersummarybyyear_delete->_userid->caption() ?></span></th>
<?php } ?>
<?php if ($loanusersummarybyyear_delete->currcode->Visible) { // currcode ?>
		<th class="<?php echo $loanusersummarybyyear_delete->currcode->headerCellClass() ?>"><span id="elh_loanusersummarybyyear_currcode" class="loanusersummarybyyear_currcode"><?php echo $loanusersummarybyyear_delete->currcode->caption() ?></span></th>
<?php } ?>
<?php if ($loanusersummarybyyear_delete->loandate->Visible) { // loandate ?>
		<th class="<?php echo $loanusersummarybyyear_delete->loandate->headerCellClass() ?>"><span id="elh_loanusersummarybyyear_loandate" class="loanusersummarybyyear_loandate"><?php echo $loanusersummarybyyear_delete->loandate->caption() ?></span></th>
<?php } ?>
<?php if ($loanusersummarybyyear_delete->amount->Visible) { // amount ?>
		<th class="<?php echo $loanusersummarybyyear_delete->amount->headerCellClass() ?>"><span id="elh_loanusersummarybyyear_amount" class="loanusersummarybyyear_amount"><?php echo $loanusersummarybyyear_delete->amount->caption() ?></span></th>
<?php } ?>
	</tr>
	</thead>
	<tbody>
<?php
$loanusersummarybyyear_delete->RecordCount = 0;
$i = 0;
while (!$loanusersummarybyyear_delete->Recordset->EOF) {
	$loanusersummarybyyear_delete->RecordCount++;
	$loanusersummarybyyear_delete->RowCount++;

	// Set row properties
	$loanusersummarybyyear->resetAttributes();
	$loanusersummarybyyear->RowType = ROWTYPE_VIEW; // View

	// Get the field contents
	$loanusersummarybyyear_delete->loadRowValues($loanusersummarybyyear_delete->Recordset);

	// Render row
	$loanusersummarybyyear_delete->renderRow();
?>
	<tr <?php echo $loanusersummarybyyear->rowAttributes() ?>>
<?php if ($loanusersummarybyyear_delete->_userid->Visible) { // userid ?>
		<td <?php echo $loanusersummarybyyear_delete->_userid->cellAttributes() ?>>
<span id="el<?php echo $loanusersummarybyyear_delete->RowCount ?>_loanusersummarybyyear__userid" class="loanusersummarybyyear__userid">
<span<?php echo $loanusersummarybyyear_delete->_userid->viewAttributes() ?>><?php echo $loanusersummarybyyear_delete->_userid->getViewValue() ?></span>
</span>
</td>
<?php } ?>
<?php if ($loanusersummarybyyear_delete->currcode->Visible) { // currcode ?>
		<td <?php echo $loanusersummarybyyear_delete->currcode->cellAttributes() ?>>
<span id="el<?php echo $loanusersummarybyyear_delete->RowCount ?>_loanusersummarybyyear_currcode" class="loanusersummarybyyear_currcode">
<span<?php echo $loanusersummarybyyear_delete->currcode->viewAttributes() ?>><?php echo $loanusersummarybyyear_delete->currcode->getViewValue() ?></span>
</span>
</td>
<?php } ?>
<?php if ($loanusersummarybyyear_delete->loandate->Visible) { // loandate ?>
		<td <?php echo $loanusersummarybyyear_delete->loandate->cellAttributes() ?>>
<span id="el<?php echo $loanusersummarybyyear_delete->RowCount ?>_loanusersummarybyyear_loandate" class="loanusersummarybyyear_loandate">
<span<?php echo $loanusersummarybyyear_delete->loandate->viewAttributes() ?>><?php echo $loanusersummarybyyear_delete->loandate->getViewValue() ?></span>
</span>
</td>
<?php } ?>
<?php if ($loanusersummarybyyear_delete->amount->Visible) { // amount ?>
		<td <?php echo $loanusersummarybyyear_delete->amount->cellAttributes() ?>>
<span id="el<?php echo $loanusersummarybyyear_delete->RowCount ?>_loanusersummarybyyear_amount" class="loanusersummarybyyear_amount">
<span<?php echo $loanusersummarybyyear_delete->amount->viewAttributes() ?>><?php echo $loanusersummarybyyear_delete->amount->getViewValue() ?></span>
</span>
</td>
<?php } ?>
	</tr>
<?php
	$loanusersummarybyyear_delete->Recordset->moveNext();
}
$loanusersummarybyyear_delete->Recordset->close();
?>
</tbody>
</table>
</div>
</div>
<div>
<button class="btn btn-primary ew-btn" name="btn-action" id="btn-action" type="submit"><?php echo $Language->phrase("DeleteBtn") ?></button>
<button class="btn btn-default ew-btn" name="btn-cancel" id="btn-cancel" type="button" data-href="<?php echo $loanusersummarybyyear_delete->getReturnUrl() ?>"><?php echo $Language->phrase("CancelBtn") ?></button>
</div>
</form>
<?php
$loanusersummarybyyear_delete->showPageFooter();
if (Config("DEBUG"))
	echo GetDebugMessage();
?>
<script>
loadjs.ready("load", function() {

	// Startup script
	// Write your table-specific startup script here
	// console.log("page loaded");

});
</script>
<?php include_once "footer.php"; ?>
<?php
$loanusersummarybyyear_delete->terminate();
?>