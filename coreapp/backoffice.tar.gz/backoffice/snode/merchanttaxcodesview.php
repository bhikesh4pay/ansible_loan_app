<?php
namespace PHPMaker2020\_4payadmin;

// Autoload
include_once "autoload.php";

// Session
if (session_status() !== PHP_SESSION_ACTIVE)
	\Delight\Cookie\Session::start(Config("COOKIE_SAMESITE")); // Init session data

// Output buffering
ob_start();
?>
<?php

// Write header
WriteHeader(FALSE);

// Create page object
$merchanttaxcodes_view = new merchanttaxcodes_view();

// Run the page
$merchanttaxcodes_view->run();

// Setup login status
SetupLoginStatus();
SetClientVar("login", LoginStatus());

// Global Page Rendering event (in userfn*.php)
Page_Rendering();

// Page Rendering event
$merchanttaxcodes_view->Page_Render();
?>
<?php include_once "header.php"; ?>
<?php if (!$merchanttaxcodes_view->isExport()) { ?>
<script>
var fmerchanttaxcodesview, currentPageID;
loadjs.ready("head", function() {

	// Form object
	currentPageID = ew.PAGE_ID = "view";
	fmerchanttaxcodesview = currentForm = new ew.Form("fmerchanttaxcodesview", "view");
	loadjs.done("fmerchanttaxcodesview");
});
</script>
<script>
loadjs.ready("head", function() {

	// Client script
	// Write your client script here, no need to add script tags.

});
</script>
<?php } ?>
<?php if (!$merchanttaxcodes_view->isExport()) { ?>
<div class="btn-toolbar ew-toolbar">
<?php $merchanttaxcodes_view->ExportOptions->render("body") ?>
<?php $merchanttaxcodes_view->OtherOptions->render("body") ?>
<div class="clearfix"></div>
</div>
<?php } ?>
<?php $merchanttaxcodes_view->showPageHeader(); ?>
<?php
$merchanttaxcodes_view->showMessage();
?>
<form name="fmerchanttaxcodesview" id="fmerchanttaxcodesview" class="form-inline ew-form ew-view-form" action="<?php echo CurrentPageName() ?>" method="post">
<?php if ($Page->CheckToken) { ?>
<input type="hidden" name="<?php echo Config("TOKEN_NAME") ?>" value="<?php echo $Page->Token ?>">
<?php } ?>
<input type="hidden" name="t" value="merchanttaxcodes">
<input type="hidden" name="modal" value="<?php echo (int)$merchanttaxcodes_view->IsModal ?>">
<table class="table table-striped table-sm ew-view-table">
<?php if ($merchanttaxcodes_view->taxcodeid->Visible) { // taxcodeid ?>
	<tr id="r_taxcodeid">
		<td class="<?php echo $merchanttaxcodes_view->TableLeftColumnClass ?>"><span id="elh_merchanttaxcodes_taxcodeid"><?php echo $merchanttaxcodes_view->taxcodeid->caption() ?></span></td>
		<td data-name="taxcodeid" <?php echo $merchanttaxcodes_view->taxcodeid->cellAttributes() ?>>
<span id="el_merchanttaxcodes_taxcodeid">
<span<?php echo $merchanttaxcodes_view->taxcodeid->viewAttributes() ?>><?php echo $merchanttaxcodes_view->taxcodeid->getViewValue() ?></span>
</span>
</td>
	</tr>
<?php } ?>
<?php if ($merchanttaxcodes_view->merchantid->Visible) { // merchantid ?>
	<tr id="r_merchantid">
		<td class="<?php echo $merchanttaxcodes_view->TableLeftColumnClass ?>"><span id="elh_merchanttaxcodes_merchantid"><?php echo $merchanttaxcodes_view->merchantid->caption() ?></span></td>
		<td data-name="merchantid" <?php echo $merchanttaxcodes_view->merchantid->cellAttributes() ?>>
<span id="el_merchanttaxcodes_merchantid">
<span<?php echo $merchanttaxcodes_view->merchantid->viewAttributes() ?>><?php echo $merchanttaxcodes_view->merchantid->getViewValue() ?></span>
</span>
</td>
	</tr>
<?php } ?>
<?php if ($merchanttaxcodes_view->label->Visible) { // label ?>
	<tr id="r_label">
		<td class="<?php echo $merchanttaxcodes_view->TableLeftColumnClass ?>"><span id="elh_merchanttaxcodes_label"><?php echo $merchanttaxcodes_view->label->caption() ?></span></td>
		<td data-name="label" <?php echo $merchanttaxcodes_view->label->cellAttributes() ?>>
<span id="el_merchanttaxcodes_label">
<span<?php echo $merchanttaxcodes_view->label->viewAttributes() ?>><?php echo $merchanttaxcodes_view->label->getViewValue() ?></span>
</span>
</td>
	</tr>
<?php } ?>
<?php if ($merchanttaxcodes_view->active->Visible) { // active ?>
	<tr id="r_active">
		<td class="<?php echo $merchanttaxcodes_view->TableLeftColumnClass ?>"><span id="elh_merchanttaxcodes_active"><?php echo $merchanttaxcodes_view->active->caption() ?></span></td>
		<td data-name="active" <?php echo $merchanttaxcodes_view->active->cellAttributes() ?>>
<span id="el_merchanttaxcodes_active">
<span<?php echo $merchanttaxcodes_view->active->viewAttributes() ?>><?php echo $merchanttaxcodes_view->active->getViewValue() ?></span>
</span>
</td>
	</tr>
<?php } ?>
<?php if ($merchanttaxcodes_view->lastupdatedate->Visible) { // lastupdatedate ?>
	<tr id="r_lastupdatedate">
		<td class="<?php echo $merchanttaxcodes_view->TableLeftColumnClass ?>"><span id="elh_merchanttaxcodes_lastupdatedate"><?php echo $merchanttaxcodes_view->lastupdatedate->caption() ?></span></td>
		<td data-name="lastupdatedate" <?php echo $merchanttaxcodes_view->lastupdatedate->cellAttributes() ?>>
<span id="el_merchanttaxcodes_lastupdatedate">
<span<?php echo $merchanttaxcodes_view->lastupdatedate->viewAttributes() ?>><?php echo $merchanttaxcodes_view->lastupdatedate->getViewValue() ?></span>
</span>
</td>
	</tr>
<?php } ?>
</table>
</form>
<?php
$merchanttaxcodes_view->showPageFooter();
if (Config("DEBUG"))
	echo GetDebugMessage();
?>
<?php if (!$merchanttaxcodes_view->isExport()) { ?>
<script>
loadjs.ready("load", function() {

	// Startup script
	// Write your table-specific startup script here
	// console.log("page loaded");

});
</script>
<?php } ?>
<?php include_once "footer.php"; ?>
<?php
$merchanttaxcodes_view->terminate();
?>