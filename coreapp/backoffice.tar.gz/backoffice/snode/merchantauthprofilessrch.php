<?php
namespace PHPMaker2020\_4payadmin;

// Autoload
include_once "autoload.php";

// Session
if (session_status() !== PHP_SESSION_ACTIVE)
	\Delight\Cookie\Session::start(Config("COOKIE_SAMESITE")); // Init session data

// Output buffering
ob_start();
?>
<?php

// Write header
WriteHeader(FALSE);

// Create page object
$merchantauthprofiles_search = new merchantauthprofiles_search();

// Run the page
$merchantauthprofiles_search->run();

// Setup login status
SetupLoginStatus();
SetClientVar("login", LoginStatus());

// Global Page Rendering event (in userfn*.php)
Page_Rendering();

// Page Rendering event
$merchantauthprofiles_search->Page_Render();
?>
<?php include_once "header.php"; ?>
<script>
var fmerchantauthprofilessearch, currentPageID;
loadjs.ready("head", function() {

	// Form object for search
	<?php if ($merchantauthprofiles_search->IsModal) { ?>
	fmerchantauthprofilessearch = currentAdvancedSearchForm = new ew.Form("fmerchantauthprofilessearch", "search");
	<?php } else { ?>
	fmerchantauthprofilessearch = currentForm = new ew.Form("fmerchantauthprofilessearch", "search");
	<?php } ?>
	currentPageID = ew.PAGE_ID = "search";

	// Validate function for search
	fmerchantauthprofilessearch.validate = function(fobj) {
		if (!this.validateRequired)
			return true; // Ignore validation
		fobj = fobj || this._form;
		var infix = "";
		elm = this.getElements("x" + infix + "_merchantid");
		if (elm && !ew.checkInteger(elm.value))
			return this.onError(elm, "<?php echo JsEncode($merchantauthprofiles_search->merchantid->errorMessage()) ?>");
		elm = this.getElements("x" + infix + "_profileid");
		if (elm && !ew.checkInteger(elm.value))
			return this.onError(elm, "<?php echo JsEncode($merchantauthprofiles_search->profileid->errorMessage()) ?>");
		elm = this.getElements("x" + infix + "_active");
		if (elm && !ew.checkInteger(elm.value))
			return this.onError(elm, "<?php echo JsEncode($merchantauthprofiles_search->active->errorMessage()) ?>");
		elm = this.getElements("x" + infix + "_lastuserdate");
		if (elm && !ew.checkDateDef(elm.value))
			return this.onError(elm, "<?php echo JsEncode($merchantauthprofiles_search->lastuserdate->errorMessage()) ?>");

		// Call Form_CustomValidate event
		if (!this.Form_CustomValidate(fobj))
			return false;
		return true;
	}

	// Form_CustomValidate
	fmerchantauthprofilessearch.Form_CustomValidate = function(fobj) { // DO NOT CHANGE THIS LINE!

		// Your custom validation code here, return false if invalid.
		return true;
	}

	// Use JavaScript validation or not
	fmerchantauthprofilessearch.validateRequired = <?php echo Config("CLIENT_VALIDATE") ? "true" : "false" ?>;

	// Dynamic selection lists
	loadjs.done("fmerchantauthprofilessearch");
});
</script>
<script>
loadjs.ready("head", function() {

	// Client script
	// Write your client script here, no need to add script tags.

});
</script>
<?php $merchantauthprofiles_search->showPageHeader(); ?>
<?php
$merchantauthprofiles_search->showMessage();
?>
<form name="fmerchantauthprofilessearch" id="fmerchantauthprofilessearch" class="<?php echo $merchantauthprofiles_search->FormClassName ?>" action="<?php echo CurrentPageName() ?>" method="post">
<?php if ($Page->CheckToken) { ?>
<input type="hidden" name="<?php echo Config("TOKEN_NAME") ?>" value="<?php echo $Page->Token ?>">
<?php } ?>
<input type="hidden" name="t" value="merchantauthprofiles">
<input type="hidden" name="action" id="action" value="search">
<input type="hidden" name="modal" value="<?php echo (int)$merchantauthprofiles_search->IsModal ?>">
<div class="ew-search-div"><!-- page* -->
<?php if ($merchantauthprofiles_search->merchantid->Visible) { // merchantid ?>
	<div id="r_merchantid" class="form-group row">
		<label for="x_merchantid" class="<?php echo $merchantauthprofiles_search->LeftColumnClass ?>"><span id="elh_merchantauthprofiles_merchantid"><?php echo $merchantauthprofiles_search->merchantid->caption() ?></span>
		<span class="ew-search-operator">
<?php echo $Language->phrase("=") ?>
<input type="hidden" name="z_merchantid" id="z_merchantid" value="=">
</span>
		</label>
		<div class="<?php echo $merchantauthprofiles_search->RightColumnClass ?>"><div <?php echo $merchantauthprofiles_search->merchantid->cellAttributes() ?>>
			<span id="el_merchantauthprofiles_merchantid" class="ew-search-field">
<input type="text" data-table="merchantauthprofiles" data-field="x_merchantid" name="x_merchantid" id="x_merchantid" size="30" placeholder="<?php echo HtmlEncode($merchantauthprofiles_search->merchantid->getPlaceHolder()) ?>" value="<?php echo $merchantauthprofiles_search->merchantid->EditValue ?>"<?php echo $merchantauthprofiles_search->merchantid->editAttributes() ?>>
</span>
		</div></div>
	</div>
<?php } ?>
<?php if ($merchantauthprofiles_search->profileid->Visible) { // profileid ?>
	<div id="r_profileid" class="form-group row">
		<label for="x_profileid" class="<?php echo $merchantauthprofiles_search->LeftColumnClass ?>"><span id="elh_merchantauthprofiles_profileid"><?php echo $merchantauthprofiles_search->profileid->caption() ?></span>
		<span class="ew-search-operator">
<?php echo $Language->phrase("=") ?>
<input type="hidden" name="z_profileid" id="z_profileid" value="=">
</span>
		</label>
		<div class="<?php echo $merchantauthprofiles_search->RightColumnClass ?>"><div <?php echo $merchantauthprofiles_search->profileid->cellAttributes() ?>>
			<span id="el_merchantauthprofiles_profileid" class="ew-search-field">
<input type="text" data-table="merchantauthprofiles" data-field="x_profileid" name="x_profileid" id="x_profileid" placeholder="<?php echo HtmlEncode($merchantauthprofiles_search->profileid->getPlaceHolder()) ?>" value="<?php echo $merchantauthprofiles_search->profileid->EditValue ?>"<?php echo $merchantauthprofiles_search->profileid->editAttributes() ?>>
</span>
		</div></div>
	</div>
<?php } ?>
<?php if ($merchantauthprofiles_search->profilecode->Visible) { // profilecode ?>
	<div id="r_profilecode" class="form-group row">
		<label for="x_profilecode" class="<?php echo $merchantauthprofiles_search->LeftColumnClass ?>"><span id="elh_merchantauthprofiles_profilecode"><?php echo $merchantauthprofiles_search->profilecode->caption() ?></span>
		<span class="ew-search-operator">
<?php echo $Language->phrase("LIKE") ?>
<input type="hidden" name="z_profilecode" id="z_profilecode" value="LIKE">
</span>
		</label>
		<div class="<?php echo $merchantauthprofiles_search->RightColumnClass ?>"><div <?php echo $merchantauthprofiles_search->profilecode->cellAttributes() ?>>
			<span id="el_merchantauthprofiles_profilecode" class="ew-search-field">
<input type="text" data-table="merchantauthprofiles" data-field="x_profilecode" name="x_profilecode" id="x_profilecode" size="30" maxlength="5" placeholder="<?php echo HtmlEncode($merchantauthprofiles_search->profilecode->getPlaceHolder()) ?>" value="<?php echo $merchantauthprofiles_search->profilecode->EditValue ?>"<?php echo $merchantauthprofiles_search->profilecode->editAttributes() ?>>
</span>
		</div></div>
	</div>
<?php } ?>
<?php if ($merchantauthprofiles_search->active->Visible) { // active ?>
	<div id="r_active" class="form-group row">
		<label for="x_active" class="<?php echo $merchantauthprofiles_search->LeftColumnClass ?>"><span id="elh_merchantauthprofiles_active"><?php echo $merchantauthprofiles_search->active->caption() ?></span>
		<span class="ew-search-operator">
<?php echo $Language->phrase("=") ?>
<input type="hidden" name="z_active" id="z_active" value="=">
</span>
		</label>
		<div class="<?php echo $merchantauthprofiles_search->RightColumnClass ?>"><div <?php echo $merchantauthprofiles_search->active->cellAttributes() ?>>
			<span id="el_merchantauthprofiles_active" class="ew-search-field">
<input type="text" data-table="merchantauthprofiles" data-field="x_active" name="x_active" id="x_active" size="30" placeholder="<?php echo HtmlEncode($merchantauthprofiles_search->active->getPlaceHolder()) ?>" value="<?php echo $merchantauthprofiles_search->active->EditValue ?>"<?php echo $merchantauthprofiles_search->active->editAttributes() ?>>
</span>
		</div></div>
	</div>
<?php } ?>
<?php if ($merchantauthprofiles_search->lastuserdate->Visible) { // lastuserdate ?>
	<div id="r_lastuserdate" class="form-group row">
		<label for="x_lastuserdate" class="<?php echo $merchantauthprofiles_search->LeftColumnClass ?>"><span id="elh_merchantauthprofiles_lastuserdate"><?php echo $merchantauthprofiles_search->lastuserdate->caption() ?></span>
		<span class="ew-search-operator">
<?php echo $Language->phrase("=") ?>
<input type="hidden" name="z_lastuserdate" id="z_lastuserdate" value="=">
</span>
		</label>
		<div class="<?php echo $merchantauthprofiles_search->RightColumnClass ?>"><div <?php echo $merchantauthprofiles_search->lastuserdate->cellAttributes() ?>>
			<span id="el_merchantauthprofiles_lastuserdate" class="ew-search-field">
<input type="text" data-table="merchantauthprofiles" data-field="x_lastuserdate" name="x_lastuserdate" id="x_lastuserdate" placeholder="<?php echo HtmlEncode($merchantauthprofiles_search->lastuserdate->getPlaceHolder()) ?>" value="<?php echo $merchantauthprofiles_search->lastuserdate->EditValue ?>"<?php echo $merchantauthprofiles_search->lastuserdate->editAttributes() ?>>
</span>
		</div></div>
	</div>
<?php } ?>
<?php if ($merchantauthprofiles_search->label->Visible) { // label ?>
	<div id="r_label" class="form-group row">
		<label for="x_label" class="<?php echo $merchantauthprofiles_search->LeftColumnClass ?>"><span id="elh_merchantauthprofiles_label"><?php echo $merchantauthprofiles_search->label->caption() ?></span>
		<span class="ew-search-operator">
<?php echo $Language->phrase("LIKE") ?>
<input type="hidden" name="z_label" id="z_label" value="LIKE">
</span>
		</label>
		<div class="<?php echo $merchantauthprofiles_search->RightColumnClass ?>"><div <?php echo $merchantauthprofiles_search->label->cellAttributes() ?>>
			<span id="el_merchantauthprofiles_label" class="ew-search-field">
<input type="text" data-table="merchantauthprofiles" data-field="x_label" name="x_label" id="x_label" size="30" maxlength="50" placeholder="<?php echo HtmlEncode($merchantauthprofiles_search->label->getPlaceHolder()) ?>" value="<?php echo $merchantauthprofiles_search->label->EditValue ?>"<?php echo $merchantauthprofiles_search->label->editAttributes() ?>>
</span>
		</div></div>
	</div>
<?php } ?>
</div><!-- /page* -->
<?php if (!$merchantauthprofiles_search->IsModal) { ?>
<div class="form-group row"><!-- buttons .form-group -->
	<div class="<?php echo $merchantauthprofiles_search->OffsetColumnClass ?>"><!-- buttons offset -->
<button class="btn btn-primary ew-btn" name="btn-action" id="btn-action" type="submit"><?php echo $Language->phrase("Search") ?></button>
<button class="btn btn-default ew-btn" name="btn-reset" id="btn-reset" type="button" onclick="ew.clearForm(this.form);"><?php echo $Language->phrase("Reset") ?></button>
	</div><!-- /buttons offset -->
</div><!-- /buttons .form-group -->
<?php } ?>
</form>
<?php
$merchantauthprofiles_search->showPageFooter();
if (Config("DEBUG"))
	echo GetDebugMessage();
?>
<script>
loadjs.ready("load", function() {

	// Startup script
	// Write your table-specific startup script here
	// console.log("page loaded");

});
</script>
<?php include_once "footer.php"; ?>
<?php
$merchantauthprofiles_search->terminate();
?>