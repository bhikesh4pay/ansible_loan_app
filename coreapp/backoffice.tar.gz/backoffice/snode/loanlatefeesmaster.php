<?php
namespace PHPMaker2020\_4payadmin;
?>
<?php if ($loanlatefees->Visible) { ?>
<div class="ew-master-div">
<table id="tbl_loanlatefeesmaster" class="table ew-view-table ew-master-table ew-vertical">
	<tbody>
<?php if ($loanlatefees->latefeeid->Visible) { // latefeeid ?>
		<tr id="r_latefeeid">
			<td class="<?php echo $loanlatefees->TableLeftColumnClass ?>"><?php echo $loanlatefees->latefeeid->caption() ?></td>
			<td <?php echo $loanlatefees->latefeeid->cellAttributes() ?>>
<span id="el_loanlatefees_latefeeid">
<span<?php echo $loanlatefees->latefeeid->viewAttributes() ?>><?php echo $loanlatefees->latefeeid->getViewValue() ?></span>
</span>
</td>
		</tr>
<?php } ?>
<?php if ($loanlatefees->_userid->Visible) { // userid ?>
		<tr id="r__userid">
			<td class="<?php echo $loanlatefees->TableLeftColumnClass ?>"><?php echo $loanlatefees->_userid->caption() ?></td>
			<td <?php echo $loanlatefees->_userid->cellAttributes() ?>>
<span id="el_loanlatefees__userid">
<span<?php echo $loanlatefees->_userid->viewAttributes() ?>><?php if (!EmptyString($loanlatefees->_userid->getViewValue()) && $loanlatefees->_userid->linkAttributes() != "") { ?>
<a<?php echo $loanlatefees->_userid->linkAttributes() ?>><?php echo $loanlatefees->_userid->getViewValue() ?></a>
<?php } else { ?>
<?php echo $loanlatefees->_userid->getViewValue() ?>
<?php } ?></span>
</span>
</td>
		</tr>
<?php } ?>
<?php if ($loanlatefees->transdate->Visible) { // transdate ?>
		<tr id="r_transdate">
			<td class="<?php echo $loanlatefees->TableLeftColumnClass ?>"><?php echo $loanlatefees->transdate->caption() ?></td>
			<td <?php echo $loanlatefees->transdate->cellAttributes() ?>>
<span id="el_loanlatefees_transdate">
<span<?php echo $loanlatefees->transdate->viewAttributes() ?>><?php echo $loanlatefees->transdate->getViewValue() ?></span>
</span>
</td>
		</tr>
<?php } ?>
<?php if ($loanlatefees->currcode->Visible) { // currcode ?>
		<tr id="r_currcode">
			<td class="<?php echo $loanlatefees->TableLeftColumnClass ?>"><?php echo $loanlatefees->currcode->caption() ?></td>
			<td <?php echo $loanlatefees->currcode->cellAttributes() ?>>
<span id="el_loanlatefees_currcode">
<span<?php echo $loanlatefees->currcode->viewAttributes() ?>><?php echo $loanlatefees->currcode->getViewValue() ?></span>
</span>
</td>
		</tr>
<?php } ?>
<?php if ($loanlatefees->outstandingamount->Visible) { // outstandingamount ?>
		<tr id="r_outstandingamount">
			<td class="<?php echo $loanlatefees->TableLeftColumnClass ?>"><?php echo $loanlatefees->outstandingamount->caption() ?></td>
			<td <?php echo $loanlatefees->outstandingamount->cellAttributes() ?>>
<span id="el_loanlatefees_outstandingamount">
<span<?php echo $loanlatefees->outstandingamount->viewAttributes() ?>><?php echo $loanlatefees->outstandingamount->getViewValue() ?></span>
</span>
</td>
		</tr>
<?php } ?>
<?php if ($loanlatefees->latefee->Visible) { // latefee ?>
		<tr id="r_latefee">
			<td class="<?php echo $loanlatefees->TableLeftColumnClass ?>"><?php echo $loanlatefees->latefee->caption() ?></td>
			<td <?php echo $loanlatefees->latefee->cellAttributes() ?>>
<span id="el_loanlatefees_latefee">
<span<?php echo $loanlatefees->latefee->viewAttributes() ?>><?php echo $loanlatefees->latefee->getViewValue() ?></span>
</span>
</td>
		</tr>
<?php } ?>
<?php if ($loanlatefees->paidamount->Visible) { // paidamount ?>
		<tr id="r_paidamount">
			<td class="<?php echo $loanlatefees->TableLeftColumnClass ?>"><?php echo $loanlatefees->paidamount->caption() ?></td>
			<td <?php echo $loanlatefees->paidamount->cellAttributes() ?>>
<span id="el_loanlatefees_paidamount">
<span<?php echo $loanlatefees->paidamount->viewAttributes() ?>><?php echo $loanlatefees->paidamount->getViewValue() ?></span>
</span>
</td>
		</tr>
<?php } ?>
<?php if ($loanlatefees->fullypaid->Visible) { // fullypaid ?>
		<tr id="r_fullypaid">
			<td class="<?php echo $loanlatefees->TableLeftColumnClass ?>"><?php echo $loanlatefees->fullypaid->caption() ?></td>
			<td <?php echo $loanlatefees->fullypaid->cellAttributes() ?>>
<span id="el_loanlatefees_fullypaid">
<span<?php echo $loanlatefees->fullypaid->viewAttributes() ?>><?php echo $loanlatefees->fullypaid->getViewValue() ?></span>
</span>
</td>
		</tr>
<?php } ?>
	</tbody>
</table>
</div>
<?php } ?>