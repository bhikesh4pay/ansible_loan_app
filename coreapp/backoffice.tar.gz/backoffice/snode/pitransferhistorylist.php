<?php
namespace PHPMaker2020\_4payadmin;

// Autoload
include_once "autoload.php";

// Session
if (session_status() !== PHP_SESSION_ACTIVE)
	\Delight\Cookie\Session::start(Config("COOKIE_SAMESITE")); // Init session data

// Output buffering
ob_start();
?>
<?php

// Write header
WriteHeader(FALSE);

// Create page object
$pitransferhistory_list = new pitransferhistory_list();

// Run the page
$pitransferhistory_list->run();

// Setup login status
SetupLoginStatus();
SetClientVar("login", LoginStatus());

// Global Page Rendering event (in userfn*.php)
Page_Rendering();

// Page Rendering event
$pitransferhistory_list->Page_Render();
?>
<?php include_once "header.php"; ?>
<?php if (!$pitransferhistory_list->isExport()) { ?>
<script>
var fpitransferhistorylist, currentPageID;
loadjs.ready("head", function() {

	// Form object
	currentPageID = ew.PAGE_ID = "list";
	fpitransferhistorylist = currentForm = new ew.Form("fpitransferhistorylist", "list");
	fpitransferhistorylist.formKeyCountName = '<?php echo $pitransferhistory_list->FormKeyCountName ?>';
	loadjs.done("fpitransferhistorylist");
});
var fpitransferhistorylistsrch;
loadjs.ready("head", function() {

	// Form object for search
	fpitransferhistorylistsrch = currentSearchForm = new ew.Form("fpitransferhistorylistsrch");

	// Dynamic selection lists
	// Filters

	fpitransferhistorylistsrch.filterList = <?php echo $pitransferhistory_list->getFilterList() ?>;

	// Init search panel as collapsed
	fpitransferhistorylistsrch.initSearchPanel = true;
	loadjs.done("fpitransferhistorylistsrch");
});
</script>
<style type="text/css">
.ew-table-preview-row { /* main table preview row color */
	background-color: #FFFFFF; /* preview row color */
}
.ew-table-preview-row .ew-grid {
	display: table;
}
</style>
<div id="ew-preview" class="d-none"><!-- preview -->
	<div class="ew-nav-tabs"><!-- .ew-nav-tabs -->
		<ul class="nav nav-tabs"></ul>
		<div class="tab-content"><!-- .tab-content -->
			<div class="tab-pane fade active show"></div>
		</div><!-- /.tab-content -->
	</div><!-- /.ew-nav-tabs -->
</div><!-- /preview -->
<script>
loadjs.ready("head", function() {
	ew.PREVIEW_PLACEMENT = ew.CSS_FLIP ? "right" : "left";
	ew.PREVIEW_SINGLE_ROW = false;
	ew.PREVIEW_OVERLAY = false;
	loadjs("js/ewpreview.js", "preview");
});
</script>
<script>
loadjs.ready("head", function() {

	// Client script
	// Write your client script here, no need to add script tags.

});
</script>
<?php } ?>
<?php if (!$pitransferhistory_list->isExport()) { ?>
<div class="btn-toolbar ew-toolbar">
<?php if ($pitransferhistory_list->TotalRecords > 0 && $pitransferhistory_list->ExportOptions->visible()) { ?>
<?php $pitransferhistory_list->ExportOptions->render("body") ?>
<?php } ?>
<?php if ($pitransferhistory_list->ImportOptions->visible()) { ?>
<?php $pitransferhistory_list->ImportOptions->render("body") ?>
<?php } ?>
<?php if ($pitransferhistory_list->SearchOptions->visible()) { ?>
<?php $pitransferhistory_list->SearchOptions->render("body") ?>
<?php } ?>
<?php if ($pitransferhistory_list->FilterOptions->visible()) { ?>
<?php $pitransferhistory_list->FilterOptions->render("body") ?>
<?php } ?>
<div class="clearfix"></div>
</div>
<?php } ?>
<?php
$pitransferhistory_list->renderOtherOptions();
?>
<?php if ($Security->CanSearch()) { ?>
<?php if (!$pitransferhistory_list->isExport() && !$pitransferhistory->CurrentAction) { ?>
<form name="fpitransferhistorylistsrch" id="fpitransferhistorylistsrch" class="form-inline ew-form ew-ext-search-form" action="<?php echo CurrentPageName() ?>">
<div id="fpitransferhistorylistsrch-search-panel" class="<?php echo $pitransferhistory_list->SearchPanelClass ?>">
<input type="hidden" name="cmd" value="search">
<input type="hidden" name="t" value="pitransferhistory">
	<div class="ew-extended-search">
<div id="xsr_<?php echo $pitransferhistory_list->SearchRowCount + 1 ?>" class="ew-row d-sm-flex">
	<div class="ew-quick-search input-group">
		<input type="text" name="<?php echo Config("TABLE_BASIC_SEARCH") ?>" id="<?php echo Config("TABLE_BASIC_SEARCH") ?>" class="form-control" value="<?php echo HtmlEncode($pitransferhistory_list->BasicSearch->getKeyword()) ?>" placeholder="<?php echo HtmlEncode($Language->phrase("Search")) ?>">
		<input type="hidden" name="<?php echo Config("TABLE_BASIC_SEARCH_TYPE") ?>" id="<?php echo Config("TABLE_BASIC_SEARCH_TYPE") ?>" value="<?php echo HtmlEncode($pitransferhistory_list->BasicSearch->getType()) ?>">
		<div class="input-group-append">
			<button class="btn btn-primary" name="btn-submit" id="btn-submit" type="submit"><?php echo $Language->phrase("SearchBtn") ?></button>
			<button type="button" data-toggle="dropdown" class="btn btn-primary dropdown-toggle dropdown-toggle-split" aria-haspopup="true" aria-expanded="false"><span id="searchtype"><?php echo $pitransferhistory_list->BasicSearch->getTypeNameShort() ?></span></button>
			<div class="dropdown-menu dropdown-menu-right">
				<a class="dropdown-item<?php if ($pitransferhistory_list->BasicSearch->getType() == "") { ?> active<?php } ?>" href="#" onclick="return ew.setSearchType(this);"><?php echo $Language->phrase("QuickSearchAuto") ?></a>
				<a class="dropdown-item<?php if ($pitransferhistory_list->BasicSearch->getType() == "=") { ?> active<?php } ?>" href="#" onclick="return ew.setSearchType(this, '=');"><?php echo $Language->phrase("QuickSearchExact") ?></a>
				<a class="dropdown-item<?php if ($pitransferhistory_list->BasicSearch->getType() == "AND") { ?> active<?php } ?>" href="#" onclick="return ew.setSearchType(this, 'AND');"><?php echo $Language->phrase("QuickSearchAll") ?></a>
				<a class="dropdown-item<?php if ($pitransferhistory_list->BasicSearch->getType() == "OR") { ?> active<?php } ?>" href="#" onclick="return ew.setSearchType(this, 'OR');"><?php echo $Language->phrase("QuickSearchAny") ?></a>
			</div>
		</div>
	</div>
</div>
	</div><!-- /.ew-extended-search -->
</div><!-- /.ew-search-panel -->
</form>
<?php } ?>
<?php } ?>
<?php $pitransferhistory_list->showPageHeader(); ?>
<?php
$pitransferhistory_list->showMessage();
?>
<?php if ($pitransferhistory_list->TotalRecords > 0 || $pitransferhistory->CurrentAction) { ?>
<div class="card ew-card ew-grid<?php if ($pitransferhistory_list->isAddOrEdit()) { ?> ew-grid-add-edit<?php } ?> pitransferhistory">
<form name="fpitransferhistorylist" id="fpitransferhistorylist" class="form-inline ew-form ew-list-form" action="<?php echo CurrentPageName() ?>" method="post">
<?php if ($Page->CheckToken) { ?>
<input type="hidden" name="<?php echo Config("TOKEN_NAME") ?>" value="<?php echo $Page->Token ?>">
<?php } ?>
<input type="hidden" name="t" value="pitransferhistory">
<div id="gmp_pitransferhistory" class="<?php echo ResponsiveTableClass() ?>card-body ew-grid-middle-panel">
<?php if ($pitransferhistory_list->TotalRecords > 0 || $pitransferhistory_list->isGridEdit()) { ?>
<table id="tbl_pitransferhistorylist" class="table ew-table"><!-- .ew-table -->
<thead>
	<tr class="ew-table-header">
<?php

// Header row
$pitransferhistory->RowType = ROWTYPE_HEADER;

// Render list options
$pitransferhistory_list->renderListOptions();

// Render list options (header, left)
$pitransferhistory_list->ListOptions->render("header", "left");
?>
<?php if ($pitransferhistory_list->transferID->Visible) { // transferID ?>
	<?php if ($pitransferhistory_list->SortUrl($pitransferhistory_list->transferID) == "") { ?>
		<th data-name="transferID" class="<?php echo $pitransferhistory_list->transferID->headerCellClass() ?>"><div id="elh_pitransferhistory_transferID" class="pitransferhistory_transferID"><div class="ew-table-header-caption"><?php echo $pitransferhistory_list->transferID->caption() ?></div></div></th>
	<?php } else { ?>
		<th data-name="transferID" class="<?php echo $pitransferhistory_list->transferID->headerCellClass() ?>"><div class="ew-pointer" onclick="ew.sort(event, '<?php echo $pitransferhistory_list->SortUrl($pitransferhistory_list->transferID) ?>', 1);"><div id="elh_pitransferhistory_transferID" class="pitransferhistory_transferID">
			<div class="ew-table-header-btn"><span class="ew-table-header-caption"><?php echo $pitransferhistory_list->transferID->caption() ?></span><span class="ew-table-header-sort"><?php if ($pitransferhistory_list->transferID->getSort() == "ASC") { ?><i class="fas fa-sort-up"></i><?php } elseif ($pitransferhistory_list->transferID->getSort() == "DESC") { ?><i class="fas fa-sort-down"></i><?php } ?></span></div>
		</div></div></th>
	<?php } ?>
<?php } ?>
<?php if ($pitransferhistory_list->txid->Visible) { // txid ?>
	<?php if ($pitransferhistory_list->SortUrl($pitransferhistory_list->txid) == "") { ?>
		<th data-name="txid" class="<?php echo $pitransferhistory_list->txid->headerCellClass() ?>"><div id="elh_pitransferhistory_txid" class="pitransferhistory_txid"><div class="ew-table-header-caption"><?php echo $pitransferhistory_list->txid->caption() ?></div></div></th>
	<?php } else { ?>
		<th data-name="txid" class="<?php echo $pitransferhistory_list->txid->headerCellClass() ?>"><div class="ew-pointer" onclick="ew.sort(event, '<?php echo $pitransferhistory_list->SortUrl($pitransferhistory_list->txid) ?>', 1);"><div id="elh_pitransferhistory_txid" class="pitransferhistory_txid">
			<div class="ew-table-header-btn"><span class="ew-table-header-caption"><?php echo $pitransferhistory_list->txid->caption() ?><?php echo $Language->phrase("SrchLegend") ?></span><span class="ew-table-header-sort"><?php if ($pitransferhistory_list->txid->getSort() == "ASC") { ?><i class="fas fa-sort-up"></i><?php } elseif ($pitransferhistory_list->txid->getSort() == "DESC") { ?><i class="fas fa-sort-down"></i><?php } ?></span></div>
		</div></div></th>
	<?php } ?>
<?php } ?>
<?php if ($pitransferhistory_list->sourceUserID->Visible) { // sourceUserID ?>
	<?php if ($pitransferhistory_list->SortUrl($pitransferhistory_list->sourceUserID) == "") { ?>
		<th data-name="sourceUserID" class="<?php echo $pitransferhistory_list->sourceUserID->headerCellClass() ?>"><div id="elh_pitransferhistory_sourceUserID" class="pitransferhistory_sourceUserID"><div class="ew-table-header-caption"><?php echo $pitransferhistory_list->sourceUserID->caption() ?></div></div></th>
	<?php } else { ?>
		<th data-name="sourceUserID" class="<?php echo $pitransferhistory_list->sourceUserID->headerCellClass() ?>"><div class="ew-pointer" onclick="ew.sort(event, '<?php echo $pitransferhistory_list->SortUrl($pitransferhistory_list->sourceUserID) ?>', 1);"><div id="elh_pitransferhistory_sourceUserID" class="pitransferhistory_sourceUserID">
			<div class="ew-table-header-btn"><span class="ew-table-header-caption"><?php echo $pitransferhistory_list->sourceUserID->caption() ?></span><span class="ew-table-header-sort"><?php if ($pitransferhistory_list->sourceUserID->getSort() == "ASC") { ?><i class="fas fa-sort-up"></i><?php } elseif ($pitransferhistory_list->sourceUserID->getSort() == "DESC") { ?><i class="fas fa-sort-down"></i><?php } ?></span></div>
		</div></div></th>
	<?php } ?>
<?php } ?>
<?php if ($pitransferhistory_list->transferTime->Visible) { // transferTime ?>
	<?php if ($pitransferhistory_list->SortUrl($pitransferhistory_list->transferTime) == "") { ?>
		<th data-name="transferTime" class="<?php echo $pitransferhistory_list->transferTime->headerCellClass() ?>"><div id="elh_pitransferhistory_transferTime" class="pitransferhistory_transferTime"><div class="ew-table-header-caption"><?php echo $pitransferhistory_list->transferTime->caption() ?></div></div></th>
	<?php } else { ?>
		<th data-name="transferTime" class="<?php echo $pitransferhistory_list->transferTime->headerCellClass() ?>"><div class="ew-pointer" onclick="ew.sort(event, '<?php echo $pitransferhistory_list->SortUrl($pitransferhistory_list->transferTime) ?>', 1);"><div id="elh_pitransferhistory_transferTime" class="pitransferhistory_transferTime">
			<div class="ew-table-header-btn"><span class="ew-table-header-caption"><?php echo $pitransferhistory_list->transferTime->caption() ?></span><span class="ew-table-header-sort"><?php if ($pitransferhistory_list->transferTime->getSort() == "ASC") { ?><i class="fas fa-sort-up"></i><?php } elseif ($pitransferhistory_list->transferTime->getSort() == "DESC") { ?><i class="fas fa-sort-down"></i><?php } ?></span></div>
		</div></div></th>
	<?php } ?>
<?php } ?>
<?php if ($pitransferhistory_list->comments->Visible) { // comments ?>
	<?php if ($pitransferhistory_list->SortUrl($pitransferhistory_list->comments) == "") { ?>
		<th data-name="comments" class="<?php echo $pitransferhistory_list->comments->headerCellClass() ?>"><div id="elh_pitransferhistory_comments" class="pitransferhistory_comments"><div class="ew-table-header-caption"><?php echo $pitransferhistory_list->comments->caption() ?></div></div></th>
	<?php } else { ?>
		<th data-name="comments" class="<?php echo $pitransferhistory_list->comments->headerCellClass() ?>"><div class="ew-pointer" onclick="ew.sort(event, '<?php echo $pitransferhistory_list->SortUrl($pitransferhistory_list->comments) ?>', 1);"><div id="elh_pitransferhistory_comments" class="pitransferhistory_comments">
			<div class="ew-table-header-btn"><span class="ew-table-header-caption"><?php echo $pitransferhistory_list->comments->caption() ?><?php echo $Language->phrase("SrchLegend") ?></span><span class="ew-table-header-sort"><?php if ($pitransferhistory_list->comments->getSort() == "ASC") { ?><i class="fas fa-sort-up"></i><?php } elseif ($pitransferhistory_list->comments->getSort() == "DESC") { ?><i class="fas fa-sort-down"></i><?php } ?></span></div>
		</div></div></th>
	<?php } ?>
<?php } ?>
<?php if ($pitransferhistory_list->type->Visible) { // type ?>
	<?php if ($pitransferhistory_list->SortUrl($pitransferhistory_list->type) == "") { ?>
		<th data-name="type" class="<?php echo $pitransferhistory_list->type->headerCellClass() ?>"><div id="elh_pitransferhistory_type" class="pitransferhistory_type"><div class="ew-table-header-caption"><?php echo $pitransferhistory_list->type->caption() ?></div></div></th>
	<?php } else { ?>
		<th data-name="type" class="<?php echo $pitransferhistory_list->type->headerCellClass() ?>"><div class="ew-pointer" onclick="ew.sort(event, '<?php echo $pitransferhistory_list->SortUrl($pitransferhistory_list->type) ?>', 1);"><div id="elh_pitransferhistory_type" class="pitransferhistory_type">
			<div class="ew-table-header-btn"><span class="ew-table-header-caption"><?php echo $pitransferhistory_list->type->caption() ?></span><span class="ew-table-header-sort"><?php if ($pitransferhistory_list->type->getSort() == "ASC") { ?><i class="fas fa-sort-up"></i><?php } elseif ($pitransferhistory_list->type->getSort() == "DESC") { ?><i class="fas fa-sort-down"></i><?php } ?></span></div>
		</div></div></th>
	<?php } ?>
<?php } ?>
<?php if ($pitransferhistory_list->lastUpdateDateTime->Visible) { // lastUpdateDateTime ?>
	<?php if ($pitransferhistory_list->SortUrl($pitransferhistory_list->lastUpdateDateTime) == "") { ?>
		<th data-name="lastUpdateDateTime" class="<?php echo $pitransferhistory_list->lastUpdateDateTime->headerCellClass() ?>"><div id="elh_pitransferhistory_lastUpdateDateTime" class="pitransferhistory_lastUpdateDateTime"><div class="ew-table-header-caption"><?php echo $pitransferhistory_list->lastUpdateDateTime->caption() ?></div></div></th>
	<?php } else { ?>
		<th data-name="lastUpdateDateTime" class="<?php echo $pitransferhistory_list->lastUpdateDateTime->headerCellClass() ?>"><div class="ew-pointer" onclick="ew.sort(event, '<?php echo $pitransferhistory_list->SortUrl($pitransferhistory_list->lastUpdateDateTime) ?>', 1);"><div id="elh_pitransferhistory_lastUpdateDateTime" class="pitransferhistory_lastUpdateDateTime">
			<div class="ew-table-header-btn"><span class="ew-table-header-caption"><?php echo $pitransferhistory_list->lastUpdateDateTime->caption() ?></span><span class="ew-table-header-sort"><?php if ($pitransferhistory_list->lastUpdateDateTime->getSort() == "ASC") { ?><i class="fas fa-sort-up"></i><?php } elseif ($pitransferhistory_list->lastUpdateDateTime->getSort() == "DESC") { ?><i class="fas fa-sort-down"></i><?php } ?></span></div>
		</div></div></th>
	<?php } ?>
<?php } ?>
<?php if ($pitransferhistory_list->confirmCode->Visible) { // confirmCode ?>
	<?php if ($pitransferhistory_list->SortUrl($pitransferhistory_list->confirmCode) == "") { ?>
		<th data-name="confirmCode" class="<?php echo $pitransferhistory_list->confirmCode->headerCellClass() ?>"><div id="elh_pitransferhistory_confirmCode" class="pitransferhistory_confirmCode"><div class="ew-table-header-caption"><?php echo $pitransferhistory_list->confirmCode->caption() ?></div></div></th>
	<?php } else { ?>
		<th data-name="confirmCode" class="<?php echo $pitransferhistory_list->confirmCode->headerCellClass() ?>"><div class="ew-pointer" onclick="ew.sort(event, '<?php echo $pitransferhistory_list->SortUrl($pitransferhistory_list->confirmCode) ?>', 1);"><div id="elh_pitransferhistory_confirmCode" class="pitransferhistory_confirmCode">
			<div class="ew-table-header-btn"><span class="ew-table-header-caption"><?php echo $pitransferhistory_list->confirmCode->caption() ?><?php echo $Language->phrase("SrchLegend") ?></span><span class="ew-table-header-sort"><?php if ($pitransferhistory_list->confirmCode->getSort() == "ASC") { ?><i class="fas fa-sort-up"></i><?php } elseif ($pitransferhistory_list->confirmCode->getSort() == "DESC") { ?><i class="fas fa-sort-down"></i><?php } ?></span></div>
		</div></div></th>
	<?php } ?>
<?php } ?>
<?php if ($pitransferhistory_list->status->Visible) { // status ?>
	<?php if ($pitransferhistory_list->SortUrl($pitransferhistory_list->status) == "") { ?>
		<th data-name="status" class="<?php echo $pitransferhistory_list->status->headerCellClass() ?>"><div id="elh_pitransferhistory_status" class="pitransferhistory_status"><div class="ew-table-header-caption"><?php echo $pitransferhistory_list->status->caption() ?></div></div></th>
	<?php } else { ?>
		<th data-name="status" class="<?php echo $pitransferhistory_list->status->headerCellClass() ?>"><div class="ew-pointer" onclick="ew.sort(event, '<?php echo $pitransferhistory_list->SortUrl($pitransferhistory_list->status) ?>', 1);"><div id="elh_pitransferhistory_status" class="pitransferhistory_status">
			<div class="ew-table-header-btn"><span class="ew-table-header-caption"><?php echo $pitransferhistory_list->status->caption() ?></span><span class="ew-table-header-sort"><?php if ($pitransferhistory_list->status->getSort() == "ASC") { ?><i class="fas fa-sort-up"></i><?php } elseif ($pitransferhistory_list->status->getSort() == "DESC") { ?><i class="fas fa-sort-down"></i><?php } ?></span></div>
		</div></div></th>
	<?php } ?>
<?php } ?>
<?php if ($pitransferhistory_list->tries->Visible) { // tries ?>
	<?php if ($pitransferhistory_list->SortUrl($pitransferhistory_list->tries) == "") { ?>
		<th data-name="tries" class="<?php echo $pitransferhistory_list->tries->headerCellClass() ?>"><div id="elh_pitransferhistory_tries" class="pitransferhistory_tries"><div class="ew-table-header-caption"><?php echo $pitransferhistory_list->tries->caption() ?></div></div></th>
	<?php } else { ?>
		<th data-name="tries" class="<?php echo $pitransferhistory_list->tries->headerCellClass() ?>"><div class="ew-pointer" onclick="ew.sort(event, '<?php echo $pitransferhistory_list->SortUrl($pitransferhistory_list->tries) ?>', 1);"><div id="elh_pitransferhistory_tries" class="pitransferhistory_tries">
			<div class="ew-table-header-btn"><span class="ew-table-header-caption"><?php echo $pitransferhistory_list->tries->caption() ?></span><span class="ew-table-header-sort"><?php if ($pitransferhistory_list->tries->getSort() == "ASC") { ?><i class="fas fa-sort-up"></i><?php } elseif ($pitransferhistory_list->tries->getSort() == "DESC") { ?><i class="fas fa-sort-down"></i><?php } ?></span></div>
		</div></div></th>
	<?php } ?>
<?php } ?>
<?php if ($pitransferhistory_list->locked->Visible) { // locked ?>
	<?php if ($pitransferhistory_list->SortUrl($pitransferhistory_list->locked) == "") { ?>
		<th data-name="locked" class="<?php echo $pitransferhistory_list->locked->headerCellClass() ?>"><div id="elh_pitransferhistory_locked" class="pitransferhistory_locked"><div class="ew-table-header-caption"><?php echo $pitransferhistory_list->locked->caption() ?></div></div></th>
	<?php } else { ?>
		<th data-name="locked" class="<?php echo $pitransferhistory_list->locked->headerCellClass() ?>"><div class="ew-pointer" onclick="ew.sort(event, '<?php echo $pitransferhistory_list->SortUrl($pitransferhistory_list->locked) ?>', 1);"><div id="elh_pitransferhistory_locked" class="pitransferhistory_locked">
			<div class="ew-table-header-btn"><span class="ew-table-header-caption"><?php echo $pitransferhistory_list->locked->caption() ?></span><span class="ew-table-header-sort"><?php if ($pitransferhistory_list->locked->getSort() == "ASC") { ?><i class="fas fa-sort-up"></i><?php } elseif ($pitransferhistory_list->locked->getSort() == "DESC") { ?><i class="fas fa-sort-down"></i><?php } ?></span></div>
		</div></div></th>
	<?php } ?>
<?php } ?>
<?php if ($pitransferhistory_list->internal->Visible) { // internal ?>
	<?php if ($pitransferhistory_list->SortUrl($pitransferhistory_list->internal) == "") { ?>
		<th data-name="internal" class="<?php echo $pitransferhistory_list->internal->headerCellClass() ?>"><div id="elh_pitransferhistory_internal" class="pitransferhistory_internal"><div class="ew-table-header-caption"><?php echo $pitransferhistory_list->internal->caption() ?></div></div></th>
	<?php } else { ?>
		<th data-name="internal" class="<?php echo $pitransferhistory_list->internal->headerCellClass() ?>"><div class="ew-pointer" onclick="ew.sort(event, '<?php echo $pitransferhistory_list->SortUrl($pitransferhistory_list->internal) ?>', 1);"><div id="elh_pitransferhistory_internal" class="pitransferhistory_internal">
			<div class="ew-table-header-btn"><span class="ew-table-header-caption"><?php echo $pitransferhistory_list->internal->caption() ?></span><span class="ew-table-header-sort"><?php if ($pitransferhistory_list->internal->getSort() == "ASC") { ?><i class="fas fa-sort-up"></i><?php } elseif ($pitransferhistory_list->internal->getSort() == "DESC") { ?><i class="fas fa-sort-down"></i><?php } ?></span></div>
		</div></div></th>
	<?php } ?>
<?php } ?>
<?php if ($pitransferhistory_list->senderpi->Visible) { // senderpi ?>
	<?php if ($pitransferhistory_list->SortUrl($pitransferhistory_list->senderpi) == "") { ?>
		<th data-name="senderpi" class="<?php echo $pitransferhistory_list->senderpi->headerCellClass() ?>"><div id="elh_pitransferhistory_senderpi" class="pitransferhistory_senderpi"><div class="ew-table-header-caption"><?php echo $pitransferhistory_list->senderpi->caption() ?></div></div></th>
	<?php } else { ?>
		<th data-name="senderpi" class="<?php echo $pitransferhistory_list->senderpi->headerCellClass() ?>"><div class="ew-pointer" onclick="ew.sort(event, '<?php echo $pitransferhistory_list->SortUrl($pitransferhistory_list->senderpi) ?>', 1);"><div id="elh_pitransferhistory_senderpi" class="pitransferhistory_senderpi">
			<div class="ew-table-header-btn"><span class="ew-table-header-caption"><?php echo $pitransferhistory_list->senderpi->caption() ?></span><span class="ew-table-header-sort"><?php if ($pitransferhistory_list->senderpi->getSort() == "ASC") { ?><i class="fas fa-sort-up"></i><?php } elseif ($pitransferhistory_list->senderpi->getSort() == "DESC") { ?><i class="fas fa-sort-down"></i><?php } ?></span></div>
		</div></div></th>
	<?php } ?>
<?php } ?>
<?php if ($pitransferhistory_list->senderpiid->Visible) { // senderpiid ?>
	<?php if ($pitransferhistory_list->SortUrl($pitransferhistory_list->senderpiid) == "") { ?>
		<th data-name="senderpiid" class="<?php echo $pitransferhistory_list->senderpiid->headerCellClass() ?>"><div id="elh_pitransferhistory_senderpiid" class="pitransferhistory_senderpiid"><div class="ew-table-header-caption"><?php echo $pitransferhistory_list->senderpiid->caption() ?></div></div></th>
	<?php } else { ?>
		<th data-name="senderpiid" class="<?php echo $pitransferhistory_list->senderpiid->headerCellClass() ?>"><div class="ew-pointer" onclick="ew.sort(event, '<?php echo $pitransferhistory_list->SortUrl($pitransferhistory_list->senderpiid) ?>', 1);"><div id="elh_pitransferhistory_senderpiid" class="pitransferhistory_senderpiid">
			<div class="ew-table-header-btn"><span class="ew-table-header-caption"><?php echo $pitransferhistory_list->senderpiid->caption() ?></span><span class="ew-table-header-sort"><?php if ($pitransferhistory_list->senderpiid->getSort() == "ASC") { ?><i class="fas fa-sort-up"></i><?php } elseif ($pitransferhistory_list->senderpiid->getSort() == "DESC") { ?><i class="fas fa-sort-down"></i><?php } ?></span></div>
		</div></div></th>
	<?php } ?>
<?php } ?>
<?php if ($pitransferhistory_list->recipientid->Visible) { // recipientid ?>
	<?php if ($pitransferhistory_list->SortUrl($pitransferhistory_list->recipientid) == "") { ?>
		<th data-name="recipientid" class="<?php echo $pitransferhistory_list->recipientid->headerCellClass() ?>"><div id="elh_pitransferhistory_recipientid" class="pitransferhistory_recipientid"><div class="ew-table-header-caption"><?php echo $pitransferhistory_list->recipientid->caption() ?></div></div></th>
	<?php } else { ?>
		<th data-name="recipientid" class="<?php echo $pitransferhistory_list->recipientid->headerCellClass() ?>"><div class="ew-pointer" onclick="ew.sort(event, '<?php echo $pitransferhistory_list->SortUrl($pitransferhistory_list->recipientid) ?>', 1);"><div id="elh_pitransferhistory_recipientid" class="pitransferhistory_recipientid">
			<div class="ew-table-header-btn"><span class="ew-table-header-caption"><?php echo $pitransferhistory_list->recipientid->caption() ?><?php echo $Language->phrase("SrchLegend") ?></span><span class="ew-table-header-sort"><?php if ($pitransferhistory_list->recipientid->getSort() == "ASC") { ?><i class="fas fa-sort-up"></i><?php } elseif ($pitransferhistory_list->recipientid->getSort() == "DESC") { ?><i class="fas fa-sort-down"></i><?php } ?></span></div>
		</div></div></th>
	<?php } ?>
<?php } ?>
<?php if ($pitransferhistory_list->presentationcode->Visible) { // presentationcode ?>
	<?php if ($pitransferhistory_list->SortUrl($pitransferhistory_list->presentationcode) == "") { ?>
		<th data-name="presentationcode" class="<?php echo $pitransferhistory_list->presentationcode->headerCellClass() ?>"><div id="elh_pitransferhistory_presentationcode" class="pitransferhistory_presentationcode"><div class="ew-table-header-caption"><?php echo $pitransferhistory_list->presentationcode->caption() ?></div></div></th>
	<?php } else { ?>
		<th data-name="presentationcode" class="<?php echo $pitransferhistory_list->presentationcode->headerCellClass() ?>"><div class="ew-pointer" onclick="ew.sort(event, '<?php echo $pitransferhistory_list->SortUrl($pitransferhistory_list->presentationcode) ?>', 1);"><div id="elh_pitransferhistory_presentationcode" class="pitransferhistory_presentationcode">
			<div class="ew-table-header-btn"><span class="ew-table-header-caption"><?php echo $pitransferhistory_list->presentationcode->caption() ?></span><span class="ew-table-header-sort"><?php if ($pitransferhistory_list->presentationcode->getSort() == "ASC") { ?><i class="fas fa-sort-up"></i><?php } elseif ($pitransferhistory_list->presentationcode->getSort() == "DESC") { ?><i class="fas fa-sort-down"></i><?php } ?></span></div>
		</div></div></th>
	<?php } ?>
<?php } ?>
<?php if ($pitransferhistory_list->recipientname->Visible) { // recipientname ?>
	<?php if ($pitransferhistory_list->SortUrl($pitransferhistory_list->recipientname) == "") { ?>
		<th data-name="recipientname" class="<?php echo $pitransferhistory_list->recipientname->headerCellClass() ?>"><div id="elh_pitransferhistory_recipientname" class="pitransferhistory_recipientname"><div class="ew-table-header-caption"><?php echo $pitransferhistory_list->recipientname->caption() ?></div></div></th>
	<?php } else { ?>
		<th data-name="recipientname" class="<?php echo $pitransferhistory_list->recipientname->headerCellClass() ?>"><div class="ew-pointer" onclick="ew.sort(event, '<?php echo $pitransferhistory_list->SortUrl($pitransferhistory_list->recipientname) ?>', 1);"><div id="elh_pitransferhistory_recipientname" class="pitransferhistory_recipientname">
			<div class="ew-table-header-btn"><span class="ew-table-header-caption"><?php echo $pitransferhistory_list->recipientname->caption() ?><?php echo $Language->phrase("SrchLegend") ?></span><span class="ew-table-header-sort"><?php if ($pitransferhistory_list->recipientname->getSort() == "ASC") { ?><i class="fas fa-sort-up"></i><?php } elseif ($pitransferhistory_list->recipientname->getSort() == "DESC") { ?><i class="fas fa-sort-down"></i><?php } ?></span></div>
		</div></div></th>
	<?php } ?>
<?php } ?>
<?php

// Render list options (header, right)
$pitransferhistory_list->ListOptions->render("header", "right");
?>
	</tr>
</thead>
<tbody>
<?php
if ($pitransferhistory_list->ExportAll && $pitransferhistory_list->isExport()) {
	$pitransferhistory_list->StopRecord = $pitransferhistory_list->TotalRecords;
} else {

	// Set the last record to display
	if ($pitransferhistory_list->TotalRecords > $pitransferhistory_list->StartRecord + $pitransferhistory_list->DisplayRecords - 1)
		$pitransferhistory_list->StopRecord = $pitransferhistory_list->StartRecord + $pitransferhistory_list->DisplayRecords - 1;
	else
		$pitransferhistory_list->StopRecord = $pitransferhistory_list->TotalRecords;
}
$pitransferhistory_list->RecordCount = $pitransferhistory_list->StartRecord - 1;
if ($pitransferhistory_list->Recordset && !$pitransferhistory_list->Recordset->EOF) {
	$pitransferhistory_list->Recordset->moveFirst();
	$selectLimit = $pitransferhistory_list->UseSelectLimit;
	if (!$selectLimit && $pitransferhistory_list->StartRecord > 1)
		$pitransferhistory_list->Recordset->move($pitransferhistory_list->StartRecord - 1);
} elseif (!$pitransferhistory->AllowAddDeleteRow && $pitransferhistory_list->StopRecord == 0) {
	$pitransferhistory_list->StopRecord = $pitransferhistory->GridAddRowCount;
}

// Initialize aggregate
$pitransferhistory->RowType = ROWTYPE_AGGREGATEINIT;
$pitransferhistory->resetAttributes();
$pitransferhistory_list->renderRow();
while ($pitransferhistory_list->RecordCount < $pitransferhistory_list->StopRecord) {
	$pitransferhistory_list->RecordCount++;
	if ($pitransferhistory_list->RecordCount >= $pitransferhistory_list->StartRecord) {
		$pitransferhistory_list->RowCount++;

		// Set up key count
		$pitransferhistory_list->KeyCount = $pitransferhistory_list->RowIndex;

		// Init row class and style
		$pitransferhistory->resetAttributes();
		$pitransferhistory->CssClass = "";
		if ($pitransferhistory_list->isGridAdd()) {
		} else {
			$pitransferhistory_list->loadRowValues($pitransferhistory_list->Recordset); // Load row values
		}
		$pitransferhistory->RowType = ROWTYPE_VIEW; // Render view

		// Set up row id / data-rowindex
		$pitransferhistory->RowAttrs->merge(["data-rowindex" => $pitransferhistory_list->RowCount, "id" => "r" . $pitransferhistory_list->RowCount . "_pitransferhistory", "data-rowtype" => $pitransferhistory->RowType]);

		// Render row
		$pitransferhistory_list->renderRow();

		// Render list options
		$pitransferhistory_list->renderListOptions();
?>
	<tr <?php echo $pitransferhistory->rowAttributes() ?>>
<?php

// Render list options (body, left)
$pitransferhistory_list->ListOptions->render("body", "left", $pitransferhistory_list->RowCount);
?>
	<?php if ($pitransferhistory_list->transferID->Visible) { // transferID ?>
		<td data-name="transferID" <?php echo $pitransferhistory_list->transferID->cellAttributes() ?>>
<span id="el<?php echo $pitransferhistory_list->RowCount ?>_pitransferhistory_transferID">
<span<?php echo $pitransferhistory_list->transferID->viewAttributes() ?>><?php echo $pitransferhistory_list->transferID->getViewValue() ?></span>
</span>
</td>
	<?php } ?>
	<?php if ($pitransferhistory_list->txid->Visible) { // txid ?>
		<td data-name="txid" <?php echo $pitransferhistory_list->txid->cellAttributes() ?>>
<span id="el<?php echo $pitransferhistory_list->RowCount ?>_pitransferhistory_txid">
<span<?php echo $pitransferhistory_list->txid->viewAttributes() ?>><?php echo $pitransferhistory_list->txid->getViewValue() ?></span>
</span>
</td>
	<?php } ?>
	<?php if ($pitransferhistory_list->sourceUserID->Visible) { // sourceUserID ?>
		<td data-name="sourceUserID" <?php echo $pitransferhistory_list->sourceUserID->cellAttributes() ?>>
<span id="el<?php echo $pitransferhistory_list->RowCount ?>_pitransferhistory_sourceUserID">
<span<?php echo $pitransferhistory_list->sourceUserID->viewAttributes() ?>><?php echo $pitransferhistory_list->sourceUserID->getViewValue() ?></span>
</span>
</td>
	<?php } ?>
	<?php if ($pitransferhistory_list->transferTime->Visible) { // transferTime ?>
		<td data-name="transferTime" <?php echo $pitransferhistory_list->transferTime->cellAttributes() ?>>
<span id="el<?php echo $pitransferhistory_list->RowCount ?>_pitransferhistory_transferTime">
<span<?php echo $pitransferhistory_list->transferTime->viewAttributes() ?>><?php echo $pitransferhistory_list->transferTime->getViewValue() ?></span>
</span>
</td>
	<?php } ?>
	<?php if ($pitransferhistory_list->comments->Visible) { // comments ?>
		<td data-name="comments" <?php echo $pitransferhistory_list->comments->cellAttributes() ?>>
<span id="el<?php echo $pitransferhistory_list->RowCount ?>_pitransferhistory_comments">
<span<?php echo $pitransferhistory_list->comments->viewAttributes() ?>><?php echo $pitransferhistory_list->comments->getViewValue() ?></span>
</span>
</td>
	<?php } ?>
	<?php if ($pitransferhistory_list->type->Visible) { // type ?>
		<td data-name="type" <?php echo $pitransferhistory_list->type->cellAttributes() ?>>
<span id="el<?php echo $pitransferhistory_list->RowCount ?>_pitransferhistory_type">
<span<?php echo $pitransferhistory_list->type->viewAttributes() ?>><?php echo $pitransferhistory_list->type->getViewValue() ?></span>
</span>
</td>
	<?php } ?>
	<?php if ($pitransferhistory_list->lastUpdateDateTime->Visible) { // lastUpdateDateTime ?>
		<td data-name="lastUpdateDateTime" <?php echo $pitransferhistory_list->lastUpdateDateTime->cellAttributes() ?>>
<span id="el<?php echo $pitransferhistory_list->RowCount ?>_pitransferhistory_lastUpdateDateTime">
<span<?php echo $pitransferhistory_list->lastUpdateDateTime->viewAttributes() ?>><?php echo $pitransferhistory_list->lastUpdateDateTime->getViewValue() ?></span>
</span>
</td>
	<?php } ?>
	<?php if ($pitransferhistory_list->confirmCode->Visible) { // confirmCode ?>
		<td data-name="confirmCode" <?php echo $pitransferhistory_list->confirmCode->cellAttributes() ?>>
<span id="el<?php echo $pitransferhistory_list->RowCount ?>_pitransferhistory_confirmCode">
<span<?php echo $pitransferhistory_list->confirmCode->viewAttributes() ?>><?php echo $pitransferhistory_list->confirmCode->getViewValue() ?></span>
</span>
</td>
	<?php } ?>
	<?php if ($pitransferhistory_list->status->Visible) { // status ?>
		<td data-name="status" <?php echo $pitransferhistory_list->status->cellAttributes() ?>>
<span id="el<?php echo $pitransferhistory_list->RowCount ?>_pitransferhistory_status">
<span<?php echo $pitransferhistory_list->status->viewAttributes() ?>><?php echo $pitransferhistory_list->status->getViewValue() ?></span>
</span>
</td>
	<?php } ?>
	<?php if ($pitransferhistory_list->tries->Visible) { // tries ?>
		<td data-name="tries" <?php echo $pitransferhistory_list->tries->cellAttributes() ?>>
<span id="el<?php echo $pitransferhistory_list->RowCount ?>_pitransferhistory_tries">
<span<?php echo $pitransferhistory_list->tries->viewAttributes() ?>><?php echo $pitransferhistory_list->tries->getViewValue() ?></span>
</span>
</td>
	<?php } ?>
	<?php if ($pitransferhistory_list->locked->Visible) { // locked ?>
		<td data-name="locked" <?php echo $pitransferhistory_list->locked->cellAttributes() ?>>
<span id="el<?php echo $pitransferhistory_list->RowCount ?>_pitransferhistory_locked">
<span<?php echo $pitransferhistory_list->locked->viewAttributes() ?>><?php echo $pitransferhistory_list->locked->getViewValue() ?></span>
</span>
</td>
	<?php } ?>
	<?php if ($pitransferhistory_list->internal->Visible) { // internal ?>
		<td data-name="internal" <?php echo $pitransferhistory_list->internal->cellAttributes() ?>>
<span id="el<?php echo $pitransferhistory_list->RowCount ?>_pitransferhistory_internal">
<span<?php echo $pitransferhistory_list->internal->viewAttributes() ?>><?php echo $pitransferhistory_list->internal->getViewValue() ?></span>
</span>
</td>
	<?php } ?>
	<?php if ($pitransferhistory_list->senderpi->Visible) { // senderpi ?>
		<td data-name="senderpi" <?php echo $pitransferhistory_list->senderpi->cellAttributes() ?>>
<span id="el<?php echo $pitransferhistory_list->RowCount ?>_pitransferhistory_senderpi">
<span<?php echo $pitransferhistory_list->senderpi->viewAttributes() ?>><?php echo $pitransferhistory_list->senderpi->getViewValue() ?></span>
</span>
</td>
	<?php } ?>
	<?php if ($pitransferhistory_list->senderpiid->Visible) { // senderpiid ?>
		<td data-name="senderpiid" <?php echo $pitransferhistory_list->senderpiid->cellAttributes() ?>>
<span id="el<?php echo $pitransferhistory_list->RowCount ?>_pitransferhistory_senderpiid">
<span<?php echo $pitransferhistory_list->senderpiid->viewAttributes() ?>><?php echo $pitransferhistory_list->senderpiid->getViewValue() ?></span>
</span>
</td>
	<?php } ?>
	<?php if ($pitransferhistory_list->recipientid->Visible) { // recipientid ?>
		<td data-name="recipientid" <?php echo $pitransferhistory_list->recipientid->cellAttributes() ?>>
<span id="el<?php echo $pitransferhistory_list->RowCount ?>_pitransferhistory_recipientid">
<span<?php echo $pitransferhistory_list->recipientid->viewAttributes() ?>><?php echo $pitransferhistory_list->recipientid->getViewValue() ?></span>
</span>
</td>
	<?php } ?>
	<?php if ($pitransferhistory_list->presentationcode->Visible) { // presentationcode ?>
		<td data-name="presentationcode" <?php echo $pitransferhistory_list->presentationcode->cellAttributes() ?>>
<span id="el<?php echo $pitransferhistory_list->RowCount ?>_pitransferhistory_presentationcode">
<span<?php echo $pitransferhistory_list->presentationcode->viewAttributes() ?>><?php echo $pitransferhistory_list->presentationcode->getViewValue() ?></span>
</span>
</td>
	<?php } ?>
	<?php if ($pitransferhistory_list->recipientname->Visible) { // recipientname ?>
		<td data-name="recipientname" <?php echo $pitransferhistory_list->recipientname->cellAttributes() ?>>
<span id="el<?php echo $pitransferhistory_list->RowCount ?>_pitransferhistory_recipientname">
<span<?php echo $pitransferhistory_list->recipientname->viewAttributes() ?>><?php echo $pitransferhistory_list->recipientname->getViewValue() ?></span>
</span>
</td>
	<?php } ?>
<?php

// Render list options (body, right)
$pitransferhistory_list->ListOptions->render("body", "right", $pitransferhistory_list->RowCount);
?>
	</tr>
<?php
	}
	if (!$pitransferhistory_list->isGridAdd())
		$pitransferhistory_list->Recordset->moveNext();
}
?>
</tbody>
</table><!-- /.ew-table -->
<?php } ?>
</div><!-- /.ew-grid-middle-panel -->
<?php if (!$pitransferhistory->CurrentAction) { ?>
<input type="hidden" name="action" id="action" value="">
<?php } ?>
</form><!-- /.ew-list-form -->
<?php

// Close recordset
if ($pitransferhistory_list->Recordset)
	$pitransferhistory_list->Recordset->Close();
?>
<?php if (!$pitransferhistory_list->isExport()) { ?>
<div class="card-footer ew-grid-lower-panel">
<?php if (!$pitransferhistory_list->isGridAdd()) { ?>
<form name="ew-pager-form" class="form-inline ew-form ew-pager-form" action="<?php echo CurrentPageName() ?>">
<?php echo $pitransferhistory_list->Pager->render() ?>
</form>
<?php } ?>
<div class="ew-list-other-options">
<?php $pitransferhistory_list->OtherOptions->render("body", "bottom") ?>
</div>
<div class="clearfix"></div>
</div>
<?php } ?>
</div><!-- /.ew-grid -->
<?php } ?>
<?php if ($pitransferhistory_list->TotalRecords == 0 && !$pitransferhistory->CurrentAction) { // Show other options ?>
<div class="ew-list-other-options">
<?php $pitransferhistory_list->OtherOptions->render("body") ?>
</div>
<div class="clearfix"></div>
<?php } ?>
<?php
$pitransferhistory_list->showPageFooter();
if (Config("DEBUG"))
	echo GetDebugMessage();
?>
<?php if (!$pitransferhistory_list->isExport()) { ?>
<script>
loadjs.ready("load", function() {

	// Startup script
	// Write your table-specific startup script here
	// console.log("page loaded");

});
</script>
<?php } ?>
<?php include_once "footer.php"; ?>
<?php
$pitransferhistory_list->terminate();
?>