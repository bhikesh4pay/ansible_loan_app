<?php
namespace PHPMaker2020\_4payadmin;

// Autoload
include_once "autoload.php";

// Session
if (session_status() !== PHP_SESSION_ACTIVE)
	\Delight\Cookie\Session::start(Config("COOKIE_SAMESITE")); // Init session data

// Output buffering
ob_start();
?>
<?php

// Write header
WriteHeader(FALSE);

// Create page object
$vtranshistorybyuser_list = new vtranshistorybyuser_list();

// Run the page
$vtranshistorybyuser_list->run();

// Setup login status
SetupLoginStatus();
SetClientVar("login", LoginStatus());

// Global Page Rendering event (in userfn*.php)
Page_Rendering();

// Page Rendering event
$vtranshistorybyuser_list->Page_Render();
?>
<?php include_once "header.php"; ?>
<?php if (!$vtranshistorybyuser_list->isExport()) { ?>
<script>
var fvtranshistorybyuserlist, currentPageID;
loadjs.ready("head", function() {

	// Form object
	currentPageID = ew.PAGE_ID = "list";
	fvtranshistorybyuserlist = currentForm = new ew.Form("fvtranshistorybyuserlist", "list");
	fvtranshistorybyuserlist.formKeyCountName = '<?php echo $vtranshistorybyuser_list->FormKeyCountName ?>';
	loadjs.done("fvtranshistorybyuserlist");
});
var fvtranshistorybyuserlistsrch;
loadjs.ready("head", function() {

	// Form object for search
	fvtranshistorybyuserlistsrch = currentSearchForm = new ew.Form("fvtranshistorybyuserlistsrch");

	// Dynamic selection lists
	// Filters

	fvtranshistorybyuserlistsrch.filterList = <?php echo $vtranshistorybyuser_list->getFilterList() ?>;
	loadjs.done("fvtranshistorybyuserlistsrch");
});
</script>
<style type="text/css">
.ew-table-preview-row { /* main table preview row color */
	background-color: #FFFFFF; /* preview row color */
}
.ew-table-preview-row .ew-grid {
	display: table;
}
</style>
<div id="ew-preview" class="d-none"><!-- preview -->
	<div class="ew-nav-tabs"><!-- .ew-nav-tabs -->
		<ul class="nav nav-tabs"></ul>
		<div class="tab-content"><!-- .tab-content -->
			<div class="tab-pane fade active show"></div>
		</div><!-- /.tab-content -->
	</div><!-- /.ew-nav-tabs -->
</div><!-- /preview -->
<script>
loadjs.ready("head", function() {
	ew.PREVIEW_PLACEMENT = ew.CSS_FLIP ? "right" : "left";
	ew.PREVIEW_SINGLE_ROW = false;
	ew.PREVIEW_OVERLAY = false;
	loadjs("js/ewpreview.js", "preview");
});
</script>
<script>
loadjs.ready("head", function() {

	// Client script
	// Write your client script here, no need to add script tags.

});
</script>
<?php } ?>
<?php if (!$vtranshistorybyuser_list->isExport()) { ?>
<div class="btn-toolbar ew-toolbar">
<?php if ($vtranshistorybyuser_list->TotalRecords > 0 && $vtranshistorybyuser_list->ExportOptions->visible()) { ?>
<?php $vtranshistorybyuser_list->ExportOptions->render("body") ?>
<?php } ?>
<?php if ($vtranshistorybyuser_list->ImportOptions->visible()) { ?>
<?php $vtranshistorybyuser_list->ImportOptions->render("body") ?>
<?php } ?>
<?php if ($vtranshistorybyuser_list->SearchOptions->visible()) { ?>
<?php $vtranshistorybyuser_list->SearchOptions->render("body") ?>
<?php } ?>
<?php if ($vtranshistorybyuser_list->FilterOptions->visible()) { ?>
<?php $vtranshistorybyuser_list->FilterOptions->render("body") ?>
<?php } ?>
<div class="clearfix"></div>
</div>
<?php } ?>
<?php if (!$vtranshistorybyuser_list->isExport() || Config("EXPORT_MASTER_RECORD") && $vtranshistorybyuser_list->isExport("print")) { ?>
<?php
if ($vtranshistorybyuser_list->DbMasterFilter != "" && $vtranshistorybyuser->getCurrentMasterTable() == "user") {
	if ($vtranshistorybyuser_list->MasterRecordExists) {
		include_once "usermaster.php";
	}
}
?>
<?php } ?>
<?php
$vtranshistorybyuser_list->renderOtherOptions();
?>
<?php if ($Security->CanSearch()) { ?>
<?php if (!$vtranshistorybyuser_list->isExport() && !$vtranshistorybyuser->CurrentAction) { ?>
<form name="fvtranshistorybyuserlistsrch" id="fvtranshistorybyuserlistsrch" class="form-inline ew-form ew-ext-search-form" action="<?php echo CurrentPageName() ?>">
<div id="fvtranshistorybyuserlistsrch-search-panel" class="<?php echo $vtranshistorybyuser_list->SearchPanelClass ?>">
<input type="hidden" name="cmd" value="search">
<input type="hidden" name="t" value="vtranshistorybyuser">
	<div class="ew-extended-search">
<div id="xsr_<?php echo $vtranshistorybyuser_list->SearchRowCount + 1 ?>" class="ew-row d-sm-flex">
	<div class="ew-quick-search input-group">
		<input type="text" name="<?php echo Config("TABLE_BASIC_SEARCH") ?>" id="<?php echo Config("TABLE_BASIC_SEARCH") ?>" class="form-control" value="<?php echo HtmlEncode($vtranshistorybyuser_list->BasicSearch->getKeyword()) ?>" placeholder="<?php echo HtmlEncode($Language->phrase("Search")) ?>">
		<input type="hidden" name="<?php echo Config("TABLE_BASIC_SEARCH_TYPE") ?>" id="<?php echo Config("TABLE_BASIC_SEARCH_TYPE") ?>" value="<?php echo HtmlEncode($vtranshistorybyuser_list->BasicSearch->getType()) ?>">
		<div class="input-group-append">
			<button class="btn btn-primary" name="btn-submit" id="btn-submit" type="submit"><?php echo $Language->phrase("SearchBtn") ?></button>
			<button type="button" data-toggle="dropdown" class="btn btn-primary dropdown-toggle dropdown-toggle-split" aria-haspopup="true" aria-expanded="false"><span id="searchtype"><?php echo $vtranshistorybyuser_list->BasicSearch->getTypeNameShort() ?></span></button>
			<div class="dropdown-menu dropdown-menu-right">
				<a class="dropdown-item<?php if ($vtranshistorybyuser_list->BasicSearch->getType() == "") { ?> active<?php } ?>" href="#" onclick="return ew.setSearchType(this);"><?php echo $Language->phrase("QuickSearchAuto") ?></a>
				<a class="dropdown-item<?php if ($vtranshistorybyuser_list->BasicSearch->getType() == "=") { ?> active<?php } ?>" href="#" onclick="return ew.setSearchType(this, '=');"><?php echo $Language->phrase("QuickSearchExact") ?></a>
				<a class="dropdown-item<?php if ($vtranshistorybyuser_list->BasicSearch->getType() == "AND") { ?> active<?php } ?>" href="#" onclick="return ew.setSearchType(this, 'AND');"><?php echo $Language->phrase("QuickSearchAll") ?></a>
				<a class="dropdown-item<?php if ($vtranshistorybyuser_list->BasicSearch->getType() == "OR") { ?> active<?php } ?>" href="#" onclick="return ew.setSearchType(this, 'OR');"><?php echo $Language->phrase("QuickSearchAny") ?></a>
			</div>
		</div>
	</div>
</div>
	</div><!-- /.ew-extended-search -->
</div><!-- /.ew-search-panel -->
</form>
<?php } ?>
<?php } ?>
<?php $vtranshistorybyuser_list->showPageHeader(); ?>
<?php
$vtranshistorybyuser_list->showMessage();
?>
<?php if ($vtranshistorybyuser_list->TotalRecords > 0 || $vtranshistorybyuser->CurrentAction) { ?>
<div class="card ew-card ew-grid<?php if ($vtranshistorybyuser_list->isAddOrEdit()) { ?> ew-grid-add-edit<?php } ?> vtranshistorybyuser">
<form name="fvtranshistorybyuserlist" id="fvtranshistorybyuserlist" class="form-inline ew-form ew-list-form" action="<?php echo CurrentPageName() ?>" method="post">
<?php if ($Page->CheckToken) { ?>
<input type="hidden" name="<?php echo Config("TOKEN_NAME") ?>" value="<?php echo $Page->Token ?>">
<?php } ?>
<input type="hidden" name="t" value="vtranshistorybyuser">
<?php if ($vtranshistorybyuser->getCurrentMasterTable() == "user" && $vtranshistorybyuser->CurrentAction) { ?>
<input type="hidden" name="<?php echo Config("TABLE_SHOW_MASTER") ?>" value="user">
<input type="hidden" name="fk_id" value="<?php echo HtmlEncode($vtranshistorybyuser_list->filterusrid->getSessionValue()) ?>">
<?php } ?>
<div id="gmp_vtranshistorybyuser" class="<?php echo ResponsiveTableClass() ?>card-body ew-grid-middle-panel">
<?php if ($vtranshistorybyuser_list->TotalRecords > 0 || $vtranshistorybyuser_list->isGridEdit()) { ?>
<table id="tbl_vtranshistorybyuserlist" class="table ew-table"><!-- .ew-table -->
<thead>
	<tr class="ew-table-header">
<?php

// Header row
$vtranshistorybyuser->RowType = ROWTYPE_HEADER;

// Render list options
$vtranshistorybyuser_list->renderListOptions();

// Render list options (header, left)
$vtranshistorybyuser_list->ListOptions->render("header", "left");
?>
<?php if ($vtranshistorybyuser_list->acctID->Visible) { // acctID ?>
	<?php if ($vtranshistorybyuser_list->SortUrl($vtranshistorybyuser_list->acctID) == "") { ?>
		<th data-name="acctID" class="<?php echo $vtranshistorybyuser_list->acctID->headerCellClass() ?>"><div id="elh_vtranshistorybyuser_acctID" class="vtranshistorybyuser_acctID"><div class="ew-table-header-caption"><?php echo $vtranshistorybyuser_list->acctID->caption() ?></div></div></th>
	<?php } else { ?>
		<th data-name="acctID" class="<?php echo $vtranshistorybyuser_list->acctID->headerCellClass() ?>"><div class="ew-pointer" onclick="ew.sort(event, '<?php echo $vtranshistorybyuser_list->SortUrl($vtranshistorybyuser_list->acctID) ?>', 1);"><div id="elh_vtranshistorybyuser_acctID" class="vtranshistorybyuser_acctID">
			<div class="ew-table-header-btn"><span class="ew-table-header-caption"><?php echo $vtranshistorybyuser_list->acctID->caption() ?></span><span class="ew-table-header-sort"><?php if ($vtranshistorybyuser_list->acctID->getSort() == "ASC") { ?><i class="fas fa-sort-up"></i><?php } elseif ($vtranshistorybyuser_list->acctID->getSort() == "DESC") { ?><i class="fas fa-sort-down"></i><?php } ?></span></div>
		</div></div></th>
	<?php } ?>
<?php } ?>
<?php if ($vtranshistorybyuser_list->currID->Visible) { // currID ?>
	<?php if ($vtranshistorybyuser_list->SortUrl($vtranshistorybyuser_list->currID) == "") { ?>
		<th data-name="currID" class="<?php echo $vtranshistorybyuser_list->currID->headerCellClass() ?>"><div id="elh_vtranshistorybyuser_currID" class="vtranshistorybyuser_currID"><div class="ew-table-header-caption"><?php echo $vtranshistorybyuser_list->currID->caption() ?></div></div></th>
	<?php } else { ?>
		<th data-name="currID" class="<?php echo $vtranshistorybyuser_list->currID->headerCellClass() ?>"><div class="ew-pointer" onclick="ew.sort(event, '<?php echo $vtranshistorybyuser_list->SortUrl($vtranshistorybyuser_list->currID) ?>', 1);"><div id="elh_vtranshistorybyuser_currID" class="vtranshistorybyuser_currID">
			<div class="ew-table-header-btn"><span class="ew-table-header-caption"><?php echo $vtranshistorybyuser_list->currID->caption() ?><?php echo $Language->phrase("SrchLegend") ?></span><span class="ew-table-header-sort"><?php if ($vtranshistorybyuser_list->currID->getSort() == "ASC") { ?><i class="fas fa-sort-up"></i><?php } elseif ($vtranshistorybyuser_list->currID->getSort() == "DESC") { ?><i class="fas fa-sort-down"></i><?php } ?></span></div>
		</div></div></th>
	<?php } ?>
<?php } ?>
<?php if ($vtranshistorybyuser_list->amount->Visible) { // amount ?>
	<?php if ($vtranshistorybyuser_list->SortUrl($vtranshistorybyuser_list->amount) == "") { ?>
		<th data-name="amount" class="<?php echo $vtranshistorybyuser_list->amount->headerCellClass() ?>"><div id="elh_vtranshistorybyuser_amount" class="vtranshistorybyuser_amount"><div class="ew-table-header-caption"><?php echo $vtranshistorybyuser_list->amount->caption() ?></div></div></th>
	<?php } else { ?>
		<th data-name="amount" class="<?php echo $vtranshistorybyuser_list->amount->headerCellClass() ?>"><div class="ew-pointer" onclick="ew.sort(event, '<?php echo $vtranshistorybyuser_list->SortUrl($vtranshistorybyuser_list->amount) ?>', 1);"><div id="elh_vtranshistorybyuser_amount" class="vtranshistorybyuser_amount">
			<div class="ew-table-header-btn"><span class="ew-table-header-caption"><?php echo $vtranshistorybyuser_list->amount->caption() ?></span><span class="ew-table-header-sort"><?php if ($vtranshistorybyuser_list->amount->getSort() == "ASC") { ?><i class="fas fa-sort-up"></i><?php } elseif ($vtranshistorybyuser_list->amount->getSort() == "DESC") { ?><i class="fas fa-sort-down"></i><?php } ?></span></div>
		</div></div></th>
	<?php } ?>
<?php } ?>
<?php if ($vtranshistorybyuser_list->transTime->Visible) { // transTime ?>
	<?php if ($vtranshistorybyuser_list->SortUrl($vtranshistorybyuser_list->transTime) == "") { ?>
		<th data-name="transTime" class="<?php echo $vtranshistorybyuser_list->transTime->headerCellClass() ?>"><div id="elh_vtranshistorybyuser_transTime" class="vtranshistorybyuser_transTime"><div class="ew-table-header-caption"><?php echo $vtranshistorybyuser_list->transTime->caption() ?></div></div></th>
	<?php } else { ?>
		<th data-name="transTime" class="<?php echo $vtranshistorybyuser_list->transTime->headerCellClass() ?>"><div class="ew-pointer" onclick="ew.sort(event, '<?php echo $vtranshistorybyuser_list->SortUrl($vtranshistorybyuser_list->transTime) ?>', 1);"><div id="elh_vtranshistorybyuser_transTime" class="vtranshistorybyuser_transTime">
			<div class="ew-table-header-btn"><span class="ew-table-header-caption"><?php echo $vtranshistorybyuser_list->transTime->caption() ?></span><span class="ew-table-header-sort"><?php if ($vtranshistorybyuser_list->transTime->getSort() == "ASC") { ?><i class="fas fa-sort-up"></i><?php } elseif ($vtranshistorybyuser_list->transTime->getSort() == "DESC") { ?><i class="fas fa-sort-down"></i><?php } ?></span></div>
		</div></div></th>
	<?php } ?>
<?php } ?>
<?php if ($vtranshistorybyuser_list->transtypelabel->Visible) { // transtypelabel ?>
	<?php if ($vtranshistorybyuser_list->SortUrl($vtranshistorybyuser_list->transtypelabel) == "") { ?>
		<th data-name="transtypelabel" class="<?php echo $vtranshistorybyuser_list->transtypelabel->headerCellClass() ?>"><div id="elh_vtranshistorybyuser_transtypelabel" class="vtranshistorybyuser_transtypelabel"><div class="ew-table-header-caption"><?php echo $vtranshistorybyuser_list->transtypelabel->caption() ?></div></div></th>
	<?php } else { ?>
		<th data-name="transtypelabel" class="<?php echo $vtranshistorybyuser_list->transtypelabel->headerCellClass() ?>"><div class="ew-pointer" onclick="ew.sort(event, '<?php echo $vtranshistorybyuser_list->SortUrl($vtranshistorybyuser_list->transtypelabel) ?>', 1);"><div id="elh_vtranshistorybyuser_transtypelabel" class="vtranshistorybyuser_transtypelabel">
			<div class="ew-table-header-btn"><span class="ew-table-header-caption"><?php echo $vtranshistorybyuser_list->transtypelabel->caption() ?><?php echo $Language->phrase("SrchLegend") ?></span><span class="ew-table-header-sort"><?php if ($vtranshistorybyuser_list->transtypelabel->getSort() == "ASC") { ?><i class="fas fa-sort-up"></i><?php } elseif ($vtranshistorybyuser_list->transtypelabel->getSort() == "DESC") { ?><i class="fas fa-sort-down"></i><?php } ?></span></div>
		</div></div></th>
	<?php } ?>
<?php } ?>
<?php if ($vtranshistorybyuser_list->sourceUserID->Visible) { // sourceUserID ?>
	<?php if ($vtranshistorybyuser_list->SortUrl($vtranshistorybyuser_list->sourceUserID) == "") { ?>
		<th data-name="sourceUserID" class="<?php echo $vtranshistorybyuser_list->sourceUserID->headerCellClass() ?>"><div id="elh_vtranshistorybyuser_sourceUserID" class="vtranshistorybyuser_sourceUserID"><div class="ew-table-header-caption"><?php echo $vtranshistorybyuser_list->sourceUserID->caption() ?></div></div></th>
	<?php } else { ?>
		<th data-name="sourceUserID" class="<?php echo $vtranshistorybyuser_list->sourceUserID->headerCellClass() ?>"><div class="ew-pointer" onclick="ew.sort(event, '<?php echo $vtranshistorybyuser_list->SortUrl($vtranshistorybyuser_list->sourceUserID) ?>', 1);"><div id="elh_vtranshistorybyuser_sourceUserID" class="vtranshistorybyuser_sourceUserID">
			<div class="ew-table-header-btn"><span class="ew-table-header-caption"><?php echo $vtranshistorybyuser_list->sourceUserID->caption() ?></span><span class="ew-table-header-sort"><?php if ($vtranshistorybyuser_list->sourceUserID->getSort() == "ASC") { ?><i class="fas fa-sort-up"></i><?php } elseif ($vtranshistorybyuser_list->sourceUserID->getSort() == "DESC") { ?><i class="fas fa-sort-down"></i><?php } ?></span></div>
		</div></div></th>
	<?php } ?>
<?php } ?>
<?php if ($vtranshistorybyuser_list->destinationUserID->Visible) { // destinationUserID ?>
	<?php if ($vtranshistorybyuser_list->SortUrl($vtranshistorybyuser_list->destinationUserID) == "") { ?>
		<th data-name="destinationUserID" class="<?php echo $vtranshistorybyuser_list->destinationUserID->headerCellClass() ?>"><div id="elh_vtranshistorybyuser_destinationUserID" class="vtranshistorybyuser_destinationUserID"><div class="ew-table-header-caption"><?php echo $vtranshistorybyuser_list->destinationUserID->caption() ?></div></div></th>
	<?php } else { ?>
		<th data-name="destinationUserID" class="<?php echo $vtranshistorybyuser_list->destinationUserID->headerCellClass() ?>"><div class="ew-pointer" onclick="ew.sort(event, '<?php echo $vtranshistorybyuser_list->SortUrl($vtranshistorybyuser_list->destinationUserID) ?>', 1);"><div id="elh_vtranshistorybyuser_destinationUserID" class="vtranshistorybyuser_destinationUserID">
			<div class="ew-table-header-btn"><span class="ew-table-header-caption"><?php echo $vtranshistorybyuser_list->destinationUserID->caption() ?></span><span class="ew-table-header-sort"><?php if ($vtranshistorybyuser_list->destinationUserID->getSort() == "ASC") { ?><i class="fas fa-sort-up"></i><?php } elseif ($vtranshistorybyuser_list->destinationUserID->getSort() == "DESC") { ?><i class="fas fa-sort-down"></i><?php } ?></span></div>
		</div></div></th>
	<?php } ?>
<?php } ?>
<?php if ($vtranshistorybyuser_list->referenceTXID->Visible) { // referenceTXID ?>
	<?php if ($vtranshistorybyuser_list->SortUrl($vtranshistorybyuser_list->referenceTXID) == "") { ?>
		<th data-name="referenceTXID" class="<?php echo $vtranshistorybyuser_list->referenceTXID->headerCellClass() ?>"><div id="elh_vtranshistorybyuser_referenceTXID" class="vtranshistorybyuser_referenceTXID"><div class="ew-table-header-caption"><?php echo $vtranshistorybyuser_list->referenceTXID->caption() ?></div></div></th>
	<?php } else { ?>
		<th data-name="referenceTXID" class="<?php echo $vtranshistorybyuser_list->referenceTXID->headerCellClass() ?>"><div class="ew-pointer" onclick="ew.sort(event, '<?php echo $vtranshistorybyuser_list->SortUrl($vtranshistorybyuser_list->referenceTXID) ?>', 1);"><div id="elh_vtranshistorybyuser_referenceTXID" class="vtranshistorybyuser_referenceTXID">
			<div class="ew-table-header-btn"><span class="ew-table-header-caption"><?php echo $vtranshistorybyuser_list->referenceTXID->caption() ?><?php echo $Language->phrase("SrchLegend") ?></span><span class="ew-table-header-sort"><?php if ($vtranshistorybyuser_list->referenceTXID->getSort() == "ASC") { ?><i class="fas fa-sort-up"></i><?php } elseif ($vtranshistorybyuser_list->referenceTXID->getSort() == "DESC") { ?><i class="fas fa-sort-down"></i><?php } ?></span></div>
		</div></div></th>
	<?php } ?>
<?php } ?>
<?php if ($vtranshistorybyuser_list->transID->Visible) { // transID ?>
	<?php if ($vtranshistorybyuser_list->SortUrl($vtranshistorybyuser_list->transID) == "") { ?>
		<th data-name="transID" class="<?php echo $vtranshistorybyuser_list->transID->headerCellClass() ?>"><div id="elh_vtranshistorybyuser_transID" class="vtranshistorybyuser_transID"><div class="ew-table-header-caption"><?php echo $vtranshistorybyuser_list->transID->caption() ?></div></div></th>
	<?php } else { ?>
		<th data-name="transID" class="<?php echo $vtranshistorybyuser_list->transID->headerCellClass() ?>"><div class="ew-pointer" onclick="ew.sort(event, '<?php echo $vtranshistorybyuser_list->SortUrl($vtranshistorybyuser_list->transID) ?>', 1);"><div id="elh_vtranshistorybyuser_transID" class="vtranshistorybyuser_transID">
			<div class="ew-table-header-btn"><span class="ew-table-header-caption"><?php echo $vtranshistorybyuser_list->transID->caption() ?></span><span class="ew-table-header-sort"><?php if ($vtranshistorybyuser_list->transID->getSort() == "ASC") { ?><i class="fas fa-sort-up"></i><?php } elseif ($vtranshistorybyuser_list->transID->getSort() == "DESC") { ?><i class="fas fa-sort-down"></i><?php } ?></span></div>
		</div></div></th>
	<?php } ?>
<?php } ?>
<?php if ($vtranshistorybyuser_list->msg->Visible) { // msg ?>
	<?php if ($vtranshistorybyuser_list->SortUrl($vtranshistorybyuser_list->msg) == "") { ?>
		<th data-name="msg" class="<?php echo $vtranshistorybyuser_list->msg->headerCellClass() ?>"><div id="elh_vtranshistorybyuser_msg" class="vtranshistorybyuser_msg"><div class="ew-table-header-caption"><?php echo $vtranshistorybyuser_list->msg->caption() ?></div></div></th>
	<?php } else { ?>
		<th data-name="msg" class="<?php echo $vtranshistorybyuser_list->msg->headerCellClass() ?>"><div class="ew-pointer" onclick="ew.sort(event, '<?php echo $vtranshistorybyuser_list->SortUrl($vtranshistorybyuser_list->msg) ?>', 1);"><div id="elh_vtranshistorybyuser_msg" class="vtranshistorybyuser_msg">
			<div class="ew-table-header-btn"><span class="ew-table-header-caption"><?php echo $vtranshistorybyuser_list->msg->caption() ?><?php echo $Language->phrase("SrchLegend") ?></span><span class="ew-table-header-sort"><?php if ($vtranshistorybyuser_list->msg->getSort() == "ASC") { ?><i class="fas fa-sort-up"></i><?php } elseif ($vtranshistorybyuser_list->msg->getSort() == "DESC") { ?><i class="fas fa-sort-down"></i><?php } ?></span></div>
		</div></div></th>
	<?php } ?>
<?php } ?>
<?php

// Render list options (header, right)
$vtranshistorybyuser_list->ListOptions->render("header", "right");
?>
	</tr>
</thead>
<tbody>
<?php
if ($vtranshistorybyuser_list->ExportAll && $vtranshistorybyuser_list->isExport()) {
	$vtranshistorybyuser_list->StopRecord = $vtranshistorybyuser_list->TotalRecords;
} else {

	// Set the last record to display
	if ($vtranshistorybyuser_list->TotalRecords > $vtranshistorybyuser_list->StartRecord + $vtranshistorybyuser_list->DisplayRecords - 1)
		$vtranshistorybyuser_list->StopRecord = $vtranshistorybyuser_list->StartRecord + $vtranshistorybyuser_list->DisplayRecords - 1;
	else
		$vtranshistorybyuser_list->StopRecord = $vtranshistorybyuser_list->TotalRecords;
}
$vtranshistorybyuser_list->RecordCount = $vtranshistorybyuser_list->StartRecord - 1;
if ($vtranshistorybyuser_list->Recordset && !$vtranshistorybyuser_list->Recordset->EOF) {
	$vtranshistorybyuser_list->Recordset->moveFirst();
	$selectLimit = $vtranshistorybyuser_list->UseSelectLimit;
	if (!$selectLimit && $vtranshistorybyuser_list->StartRecord > 1)
		$vtranshistorybyuser_list->Recordset->move($vtranshistorybyuser_list->StartRecord - 1);
} elseif (!$vtranshistorybyuser->AllowAddDeleteRow && $vtranshistorybyuser_list->StopRecord == 0) {
	$vtranshistorybyuser_list->StopRecord = $vtranshistorybyuser->GridAddRowCount;
}

// Initialize aggregate
$vtranshistorybyuser->RowType = ROWTYPE_AGGREGATEINIT;
$vtranshistorybyuser->resetAttributes();
$vtranshistorybyuser_list->renderRow();
while ($vtranshistorybyuser_list->RecordCount < $vtranshistorybyuser_list->StopRecord) {
	$vtranshistorybyuser_list->RecordCount++;
	if ($vtranshistorybyuser_list->RecordCount >= $vtranshistorybyuser_list->StartRecord) {
		$vtranshistorybyuser_list->RowCount++;

		// Set up key count
		$vtranshistorybyuser_list->KeyCount = $vtranshistorybyuser_list->RowIndex;

		// Init row class and style
		$vtranshistorybyuser->resetAttributes();
		$vtranshistorybyuser->CssClass = "";
		if ($vtranshistorybyuser_list->isGridAdd()) {
		} else {
			$vtranshistorybyuser_list->loadRowValues($vtranshistorybyuser_list->Recordset); // Load row values
		}
		$vtranshistorybyuser->RowType = ROWTYPE_VIEW; // Render view

		// Set up row id / data-rowindex
		$vtranshistorybyuser->RowAttrs->merge(["data-rowindex" => $vtranshistorybyuser_list->RowCount, "id" => "r" . $vtranshistorybyuser_list->RowCount . "_vtranshistorybyuser", "data-rowtype" => $vtranshistorybyuser->RowType]);

		// Render row
		$vtranshistorybyuser_list->renderRow();

		// Render list options
		$vtranshistorybyuser_list->renderListOptions();
?>
	<tr <?php echo $vtranshistorybyuser->rowAttributes() ?>>
<?php

// Render list options (body, left)
$vtranshistorybyuser_list->ListOptions->render("body", "left", $vtranshistorybyuser_list->RowCount);
?>
	<?php if ($vtranshistorybyuser_list->acctID->Visible) { // acctID ?>
		<td data-name="acctID" <?php echo $vtranshistorybyuser_list->acctID->cellAttributes() ?>>
<span id="el<?php echo $vtranshistorybyuser_list->RowCount ?>_vtranshistorybyuser_acctID">
<span<?php echo $vtranshistorybyuser_list->acctID->viewAttributes() ?>><?php echo $vtranshistorybyuser_list->acctID->getViewValue() ?></span>
</span>
</td>
	<?php } ?>
	<?php if ($vtranshistorybyuser_list->currID->Visible) { // currID ?>
		<td data-name="currID" <?php echo $vtranshistorybyuser_list->currID->cellAttributes() ?>>
<span id="el<?php echo $vtranshistorybyuser_list->RowCount ?>_vtranshistorybyuser_currID">
<span<?php echo $vtranshistorybyuser_list->currID->viewAttributes() ?>><?php echo $vtranshistorybyuser_list->currID->getViewValue() ?></span>
</span>
</td>
	<?php } ?>
	<?php if ($vtranshistorybyuser_list->amount->Visible) { // amount ?>
		<td data-name="amount" <?php echo $vtranshistorybyuser_list->amount->cellAttributes() ?>>
<span id="el<?php echo $vtranshistorybyuser_list->RowCount ?>_vtranshistorybyuser_amount">
<span<?php echo $vtranshistorybyuser_list->amount->viewAttributes() ?>><?php echo $vtranshistorybyuser_list->amount->getViewValue() ?></span>
</span>
</td>
	<?php } ?>
	<?php if ($vtranshistorybyuser_list->transTime->Visible) { // transTime ?>
		<td data-name="transTime" <?php echo $vtranshistorybyuser_list->transTime->cellAttributes() ?>>
<span id="el<?php echo $vtranshistorybyuser_list->RowCount ?>_vtranshistorybyuser_transTime">
<span<?php echo $vtranshistorybyuser_list->transTime->viewAttributes() ?>><?php echo $vtranshistorybyuser_list->transTime->getViewValue() ?></span>
</span>
</td>
	<?php } ?>
	<?php if ($vtranshistorybyuser_list->transtypelabel->Visible) { // transtypelabel ?>
		<td data-name="transtypelabel" <?php echo $vtranshistorybyuser_list->transtypelabel->cellAttributes() ?>>
<span id="el<?php echo $vtranshistorybyuser_list->RowCount ?>_vtranshistorybyuser_transtypelabel">
<span<?php echo $vtranshistorybyuser_list->transtypelabel->viewAttributes() ?>><?php echo $vtranshistorybyuser_list->transtypelabel->getViewValue() ?></span>
</span>
</td>
	<?php } ?>
	<?php if ($vtranshistorybyuser_list->sourceUserID->Visible) { // sourceUserID ?>
		<td data-name="sourceUserID" <?php echo $vtranshistorybyuser_list->sourceUserID->cellAttributes() ?>>
<span id="el<?php echo $vtranshistorybyuser_list->RowCount ?>_vtranshistorybyuser_sourceUserID">
<span<?php echo $vtranshistorybyuser_list->sourceUserID->viewAttributes() ?>><?php echo $vtranshistorybyuser_list->sourceUserID->getViewValue() ?></span>
</span>
</td>
	<?php } ?>
	<?php if ($vtranshistorybyuser_list->destinationUserID->Visible) { // destinationUserID ?>
		<td data-name="destinationUserID" <?php echo $vtranshistorybyuser_list->destinationUserID->cellAttributes() ?>>
<span id="el<?php echo $vtranshistorybyuser_list->RowCount ?>_vtranshistorybyuser_destinationUserID">
<span<?php echo $vtranshistorybyuser_list->destinationUserID->viewAttributes() ?>><?php echo $vtranshistorybyuser_list->destinationUserID->getViewValue() ?></span>
</span>
</td>
	<?php } ?>
	<?php if ($vtranshistorybyuser_list->referenceTXID->Visible) { // referenceTXID ?>
		<td data-name="referenceTXID" <?php echo $vtranshistorybyuser_list->referenceTXID->cellAttributes() ?>>
<span id="el<?php echo $vtranshistorybyuser_list->RowCount ?>_vtranshistorybyuser_referenceTXID">
<span<?php echo $vtranshistorybyuser_list->referenceTXID->viewAttributes() ?>><?php echo $vtranshistorybyuser_list->referenceTXID->getViewValue() ?></span>
</span>
</td>
	<?php } ?>
	<?php if ($vtranshistorybyuser_list->transID->Visible) { // transID ?>
		<td data-name="transID" <?php echo $vtranshistorybyuser_list->transID->cellAttributes() ?>>
<span id="el<?php echo $vtranshistorybyuser_list->RowCount ?>_vtranshistorybyuser_transID">
<span<?php echo $vtranshistorybyuser_list->transID->viewAttributes() ?>><?php echo $vtranshistorybyuser_list->transID->getViewValue() ?></span>
</span>
</td>
	<?php } ?>
	<?php if ($vtranshistorybyuser_list->msg->Visible) { // msg ?>
		<td data-name="msg" <?php echo $vtranshistorybyuser_list->msg->cellAttributes() ?>>
<span id="el<?php echo $vtranshistorybyuser_list->RowCount ?>_vtranshistorybyuser_msg">
<span<?php echo $vtranshistorybyuser_list->msg->viewAttributes() ?>><?php echo $vtranshistorybyuser_list->msg->getViewValue() ?></span>
</span>
</td>
	<?php } ?>
<?php

// Render list options (body, right)
$vtranshistorybyuser_list->ListOptions->render("body", "right", $vtranshistorybyuser_list->RowCount);
?>
	</tr>
<?php
	}
	if (!$vtranshistorybyuser_list->isGridAdd())
		$vtranshistorybyuser_list->Recordset->moveNext();
}
?>
</tbody>
</table><!-- /.ew-table -->
<?php } ?>
</div><!-- /.ew-grid-middle-panel -->
<?php if (!$vtranshistorybyuser->CurrentAction) { ?>
<input type="hidden" name="action" id="action" value="">
<?php } ?>
</form><!-- /.ew-list-form -->
<?php

// Close recordset
if ($vtranshistorybyuser_list->Recordset)
	$vtranshistorybyuser_list->Recordset->Close();
?>
<?php if (!$vtranshistorybyuser_list->isExport()) { ?>
<div class="card-footer ew-grid-lower-panel">
<?php if (!$vtranshistorybyuser_list->isGridAdd()) { ?>
<form name="ew-pager-form" class="form-inline ew-form ew-pager-form" action="<?php echo CurrentPageName() ?>">
<?php echo $vtranshistorybyuser_list->Pager->render() ?>
</form>
<?php } ?>
<div class="ew-list-other-options">
<?php $vtranshistorybyuser_list->OtherOptions->render("body", "bottom") ?>
</div>
<div class="clearfix"></div>
</div>
<?php } ?>
</div><!-- /.ew-grid -->
<?php } ?>
<?php if ($vtranshistorybyuser_list->TotalRecords == 0 && !$vtranshistorybyuser->CurrentAction) { // Show other options ?>
<div class="ew-list-other-options">
<?php $vtranshistorybyuser_list->OtherOptions->render("body") ?>
</div>
<div class="clearfix"></div>
<?php } ?>
<?php
$vtranshistorybyuser_list->showPageFooter();
if (Config("DEBUG"))
	echo GetDebugMessage();
?>
<?php if (!$vtranshistorybyuser_list->isExport()) { ?>
<script>
loadjs.ready("load", function() {

	// Startup script
	// Write your table-specific startup script here
	// console.log("page loaded");

});
</script>
<?php } ?>
<?php include_once "footer.php"; ?>
<?php
$vtranshistorybyuser_list->terminate();
?>