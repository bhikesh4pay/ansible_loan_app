<?php
namespace PHPMaker2020\_4payadmin;

// Autoload
include_once "autoload.php";

// Session
if (session_status() !== PHP_SESSION_ACTIVE)
	\Delight\Cookie\Session::start(Config("COOKIE_SAMESITE")); // Init session data

// Output buffering
ob_start();
?>
<?php

// Write header
WriteHeader(FALSE);

// Create page object
$billinghistory_edit = new billinghistory_edit();

// Run the page
$billinghistory_edit->run();

// Setup login status
SetupLoginStatus();
SetClientVar("login", LoginStatus());

// Global Page Rendering event (in userfn*.php)
Page_Rendering();

// Page Rendering event
$billinghistory_edit->Page_Render();
?>
<?php include_once "header.php"; ?>
<script>
var fbillinghistoryedit, currentPageID;
loadjs.ready("head", function() {

	// Form object
	currentPageID = ew.PAGE_ID = "edit";
	fbillinghistoryedit = currentForm = new ew.Form("fbillinghistoryedit", "edit");

	// Validate form
	fbillinghistoryedit.validate = function() {
		if (!this.validateRequired)
			return true; // Ignore validation
		var $ = jQuery, fobj = this.getForm(), $fobj = $(fobj);
		if ($fobj.find("#confirm").val() == "confirm")
			return true;
		var elm, felm, uelm, addcnt = 0;
		var $k = $fobj.find("#" + this.formKeyCountName); // Get key_count
		var rowcnt = ($k[0]) ? parseInt($k.val(), 10) : 1;
		var startcnt = (rowcnt == 0) ? 0 : 1; // Check rowcnt == 0 => Inline-Add
		var gridinsert = ["insert", "gridinsert"].includes($fobj.find("#action").val()) && $k[0];
		for (var i = startcnt; i <= rowcnt; i++) {
			var infix = ($k[0]) ? String(i) : "";
			$fobj.data("rowindex", infix);
			<?php if ($billinghistory_edit->recid->Required) { ?>
				elm = this.getElements("x" + infix + "_recid");
				if (elm && !ew.isHidden(elm) && !ew.hasValue(elm))
					return this.onError(elm, "<?php echo JsEncode(str_replace("%s", $billinghistory_edit->recid->caption(), $billinghistory_edit->recid->RequiredErrorMessage)) ?>");
			<?php } ?>
			<?php if ($billinghistory_edit->serviceid->Required) { ?>
				elm = this.getElements("x" + infix + "_serviceid");
				if (elm && !ew.isHidden(elm) && !ew.hasValue(elm))
					return this.onError(elm, "<?php echo JsEncode(str_replace("%s", $billinghistory_edit->serviceid->caption(), $billinghistory_edit->serviceid->RequiredErrorMessage)) ?>");
			<?php } ?>
				elm = this.getElements("x" + infix + "_serviceid");
				if (elm && !ew.checkInteger(elm.value))
					return this.onError(elm, "<?php echo JsEncode($billinghistory_edit->serviceid->errorMessage()) ?>");
			<?php if ($billinghistory_edit->brokerid->Required) { ?>
				elm = this.getElements("x" + infix + "_brokerid");
				if (elm && !ew.isHidden(elm) && !ew.hasValue(elm))
					return this.onError(elm, "<?php echo JsEncode(str_replace("%s", $billinghistory_edit->brokerid->caption(), $billinghistory_edit->brokerid->RequiredErrorMessage)) ?>");
			<?php } ?>
				elm = this.getElements("x" + infix + "_brokerid");
				if (elm && !ew.checkInteger(elm.value))
					return this.onError(elm, "<?php echo JsEncode($billinghistory_edit->brokerid->errorMessage()) ?>");
			<?php if ($billinghistory_edit->customeracctno->Required) { ?>
				elm = this.getElements("x" + infix + "_customeracctno");
				if (elm && !ew.isHidden(elm) && !ew.hasValue(elm))
					return this.onError(elm, "<?php echo JsEncode(str_replace("%s", $billinghistory_edit->customeracctno->caption(), $billinghistory_edit->customeracctno->RequiredErrorMessage)) ?>");
			<?php } ?>
			<?php if ($billinghistory_edit->currcode->Required) { ?>
				elm = this.getElements("x" + infix + "_currcode");
				if (elm && !ew.isHidden(elm) && !ew.hasValue(elm))
					return this.onError(elm, "<?php echo JsEncode(str_replace("%s", $billinghistory_edit->currcode->caption(), $billinghistory_edit->currcode->RequiredErrorMessage)) ?>");
			<?php } ?>
			<?php if ($billinghistory_edit->balance->Required) { ?>
				elm = this.getElements("x" + infix + "_balance");
				if (elm && !ew.isHidden(elm) && !ew.hasValue(elm))
					return this.onError(elm, "<?php echo JsEncode(str_replace("%s", $billinghistory_edit->balance->caption(), $billinghistory_edit->balance->RequiredErrorMessage)) ?>");
			<?php } ?>
				elm = this.getElements("x" + infix + "_balance");
				if (elm && !ew.checkNumber(elm.value))
					return this.onError(elm, "<?php echo JsEncode($billinghistory_edit->balance->errorMessage()) ?>");
			<?php if ($billinghistory_edit->confcode->Required) { ?>
				elm = this.getElements("x" + infix + "_confcode");
				if (elm && !ew.isHidden(elm) && !ew.hasValue(elm))
					return this.onError(elm, "<?php echo JsEncode(str_replace("%s", $billinghistory_edit->confcode->caption(), $billinghistory_edit->confcode->RequiredErrorMessage)) ?>");
			<?php } ?>
			<?php if ($billinghistory_edit->success->Required) { ?>
				elm = this.getElements("x" + infix + "_success");
				if (elm && !ew.isHidden(elm) && !ew.hasValue(elm))
					return this.onError(elm, "<?php echo JsEncode(str_replace("%s", $billinghistory_edit->success->caption(), $billinghistory_edit->success->RequiredErrorMessage)) ?>");
			<?php } ?>
				elm = this.getElements("x" + infix + "_success");
				if (elm && !ew.checkInteger(elm.value))
					return this.onError(elm, "<?php echo JsEncode($billinghistory_edit->success->errorMessage()) ?>");
			<?php if ($billinghistory_edit->transdate->Required) { ?>
				elm = this.getElements("x" + infix + "_transdate");
				if (elm && !ew.isHidden(elm) && !ew.hasValue(elm))
					return this.onError(elm, "<?php echo JsEncode(str_replace("%s", $billinghistory_edit->transdate->caption(), $billinghistory_edit->transdate->RequiredErrorMessage)) ?>");
			<?php } ?>
				elm = this.getElements("x" + infix + "_transdate");
				if (elm && !ew.checkDateDef(elm.value))
					return this.onError(elm, "<?php echo JsEncode($billinghistory_edit->transdate->errorMessage()) ?>");
			<?php if ($billinghistory_edit->_userid->Required) { ?>
				elm = this.getElements("x" + infix + "__userid");
				if (elm && !ew.isHidden(elm) && !ew.hasValue(elm))
					return this.onError(elm, "<?php echo JsEncode(str_replace("%s", $billinghistory_edit->_userid->caption(), $billinghistory_edit->_userid->RequiredErrorMessage)) ?>");
			<?php } ?>
				elm = this.getElements("x" + infix + "__userid");
				if (elm && !ew.checkInteger(elm.value))
					return this.onError(elm, "<?php echo JsEncode($billinghistory_edit->_userid->errorMessage()) ?>");
			<?php if ($billinghistory_edit->billerresponse->Required) { ?>
				elm = this.getElements("x" + infix + "_billerresponse");
				if (elm && !ew.isHidden(elm) && !ew.hasValue(elm))
					return this.onError(elm, "<?php echo JsEncode(str_replace("%s", $billinghistory_edit->billerresponse->caption(), $billinghistory_edit->billerresponse->RequiredErrorMessage)) ?>");
			<?php } ?>
			<?php if ($billinghistory_edit->paymenttype->Required) { ?>
				elm = this.getElements("x" + infix + "_paymenttype");
				if (elm && !ew.isHidden(elm) && !ew.hasValue(elm))
					return this.onError(elm, "<?php echo JsEncode(str_replace("%s", $billinghistory_edit->paymenttype->caption(), $billinghistory_edit->paymenttype->RequiredErrorMessage)) ?>");
			<?php } ?>
			<?php if ($billinghistory_edit->customername->Required) { ?>
				elm = this.getElements("x" + infix + "_customername");
				if (elm && !ew.isHidden(elm) && !ew.hasValue(elm))
					return this.onError(elm, "<?php echo JsEncode(str_replace("%s", $billinghistory_edit->customername->caption(), $billinghistory_edit->customername->RequiredErrorMessage)) ?>");
			<?php } ?>
			<?php if ($billinghistory_edit->parentuserid->Required) { ?>
				elm = this.getElements("x" + infix + "_parentuserid");
				if (elm && !ew.isHidden(elm) && !ew.hasValue(elm))
					return this.onError(elm, "<?php echo JsEncode(str_replace("%s", $billinghistory_edit->parentuserid->caption(), $billinghistory_edit->parentuserid->RequiredErrorMessage)) ?>");
			<?php } ?>
			<?php if ($billinghistory_edit->refno->Required) { ?>
				elm = this.getElements("x" + infix + "_refno");
				if (elm && !ew.isHidden(elm) && !ew.hasValue(elm))
					return this.onError(elm, "<?php echo JsEncode(str_replace("%s", $billinghistory_edit->refno->caption(), $billinghistory_edit->refno->RequiredErrorMessage)) ?>");
			<?php } ?>
			<?php if ($billinghistory_edit->feeid->Required) { ?>
				elm = this.getElements("x" + infix + "_feeid");
				if (elm && !ew.isHidden(elm) && !ew.hasValue(elm))
					return this.onError(elm, "<?php echo JsEncode(str_replace("%s", $billinghistory_edit->feeid->caption(), $billinghistory_edit->feeid->RequiredErrorMessage)) ?>");
			<?php } ?>
				elm = this.getElements("x" + infix + "_feeid");
				if (elm && !ew.checkInteger(elm.value))
					return this.onError(elm, "<?php echo JsEncode($billinghistory_edit->feeid->errorMessage()) ?>");
			<?php if ($billinghistory_edit->_tabletype->Required) { ?>
				elm = this.getElements("x" + infix + "__tabletype");
				if (elm && !ew.isHidden(elm) && !ew.hasValue(elm))
					return this.onError(elm, "<?php echo JsEncode(str_replace("%s", $billinghistory_edit->_tabletype->caption(), $billinghistory_edit->_tabletype->RequiredErrorMessage)) ?>");
			<?php } ?>
				elm = this.getElements("x" + infix + "__tabletype");
				if (elm && !ew.checkInteger(elm.value))
					return this.onError(elm, "<?php echo JsEncode($billinghistory_edit->_tabletype->errorMessage()) ?>");
			<?php if ($billinghistory_edit->feemerchanttotal->Required) { ?>
				elm = this.getElements("x" + infix + "_feemerchanttotal");
				if (elm && !ew.isHidden(elm) && !ew.hasValue(elm))
					return this.onError(elm, "<?php echo JsEncode(str_replace("%s", $billinghistory_edit->feemerchanttotal->caption(), $billinghistory_edit->feemerchanttotal->RequiredErrorMessage)) ?>");
			<?php } ?>
				elm = this.getElements("x" + infix + "_feemerchanttotal");
				if (elm && !ew.checkNumber(elm.value))
					return this.onError(elm, "<?php echo JsEncode($billinghistory_edit->feemerchanttotal->errorMessage()) ?>");
			<?php if ($billinghistory_edit->feeconsumertotal->Required) { ?>
				elm = this.getElements("x" + infix + "_feeconsumertotal");
				if (elm && !ew.isHidden(elm) && !ew.hasValue(elm))
					return this.onError(elm, "<?php echo JsEncode(str_replace("%s", $billinghistory_edit->feeconsumertotal->caption(), $billinghistory_edit->feeconsumertotal->RequiredErrorMessage)) ?>");
			<?php } ?>
				elm = this.getElements("x" + infix + "_feeconsumertotal");
				if (elm && !ew.checkNumber(elm.value))
					return this.onError(elm, "<?php echo JsEncode($billinghistory_edit->feeconsumertotal->errorMessage()) ?>");
			<?php if ($billinghistory_edit->feesystemtotal->Required) { ?>
				elm = this.getElements("x" + infix + "_feesystemtotal");
				if (elm && !ew.isHidden(elm) && !ew.hasValue(elm))
					return this.onError(elm, "<?php echo JsEncode(str_replace("%s", $billinghistory_edit->feesystemtotal->caption(), $billinghistory_edit->feesystemtotal->RequiredErrorMessage)) ?>");
			<?php } ?>
				elm = this.getElements("x" + infix + "_feesystemtotal");
				if (elm && !ew.checkNumber(elm.value))
					return this.onError(elm, "<?php echo JsEncode($billinghistory_edit->feesystemtotal->errorMessage()) ?>");
			<?php if ($billinghistory_edit->feeexternaltotal->Required) { ?>
				elm = this.getElements("x" + infix + "_feeexternaltotal");
				if (elm && !ew.isHidden(elm) && !ew.hasValue(elm))
					return this.onError(elm, "<?php echo JsEncode(str_replace("%s", $billinghistory_edit->feeexternaltotal->caption(), $billinghistory_edit->feeexternaltotal->RequiredErrorMessage)) ?>");
			<?php } ?>
				elm = this.getElements("x" + infix + "_feeexternaltotal");
				if (elm && !ew.checkNumber(elm.value))
					return this.onError(elm, "<?php echo JsEncode($billinghistory_edit->feeexternaltotal->errorMessage()) ?>");
			<?php if ($billinghistory_edit->feefranchiseetotal->Required) { ?>
				elm = this.getElements("x" + infix + "_feefranchiseetotal");
				if (elm && !ew.isHidden(elm) && !ew.hasValue(elm))
					return this.onError(elm, "<?php echo JsEncode(str_replace("%s", $billinghistory_edit->feefranchiseetotal->caption(), $billinghistory_edit->feefranchiseetotal->RequiredErrorMessage)) ?>");
			<?php } ?>
				elm = this.getElements("x" + infix + "_feefranchiseetotal");
				if (elm && !ew.checkNumber(elm.value))
					return this.onError(elm, "<?php echo JsEncode($billinghistory_edit->feefranchiseetotal->errorMessage()) ?>");
			<?php if ($billinghistory_edit->feeresellertotal->Required) { ?>
				elm = this.getElements("x" + infix + "_feeresellertotal");
				if (elm && !ew.isHidden(elm) && !ew.hasValue(elm))
					return this.onError(elm, "<?php echo JsEncode(str_replace("%s", $billinghistory_edit->feeresellertotal->caption(), $billinghistory_edit->feeresellertotal->RequiredErrorMessage)) ?>");
			<?php } ?>
				elm = this.getElements("x" + infix + "_feeresellertotal");
				if (elm && !ew.checkNumber(elm.value))
					return this.onError(elm, "<?php echo JsEncode($billinghistory_edit->feeresellertotal->errorMessage()) ?>");
			<?php if ($billinghistory_edit->branchname->Required) { ?>
				elm = this.getElements("x" + infix + "_branchname");
				if (elm && !ew.isHidden(elm) && !ew.hasValue(elm))
					return this.onError(elm, "<?php echo JsEncode(str_replace("%s", $billinghistory_edit->branchname->caption(), $billinghistory_edit->branchname->RequiredErrorMessage)) ?>");
			<?php } ?>
			<?php if ($billinghistory_edit->clerkname->Required) { ?>
				elm = this.getElements("x" + infix + "_clerkname");
				if (elm && !ew.isHidden(elm) && !ew.hasValue(elm))
					return this.onError(elm, "<?php echo JsEncode(str_replace("%s", $billinghistory_edit->clerkname->caption(), $billinghistory_edit->clerkname->RequiredErrorMessage)) ?>");
			<?php } ?>
			<?php if ($billinghistory_edit->taxamount->Required) { ?>
				elm = this.getElements("x" + infix + "_taxamount");
				if (elm && !ew.isHidden(elm) && !ew.hasValue(elm))
					return this.onError(elm, "<?php echo JsEncode(str_replace("%s", $billinghistory_edit->taxamount->caption(), $billinghistory_edit->taxamount->RequiredErrorMessage)) ?>");
			<?php } ?>
				elm = this.getElements("x" + infix + "_taxamount");
				if (elm && !ew.checkNumber(elm.value))
					return this.onError(elm, "<?php echo JsEncode($billinghistory_edit->taxamount->errorMessage()) ?>");
			<?php if ($billinghistory_edit->totalamount->Required) { ?>
				elm = this.getElements("x" + infix + "_totalamount");
				if (elm && !ew.isHidden(elm) && !ew.hasValue(elm))
					return this.onError(elm, "<?php echo JsEncode(str_replace("%s", $billinghistory_edit->totalamount->caption(), $billinghistory_edit->totalamount->RequiredErrorMessage)) ?>");
			<?php } ?>
				elm = this.getElements("x" + infix + "_totalamount");
				if (elm && !ew.checkNumber(elm.value))
					return this.onError(elm, "<?php echo JsEncode($billinghistory_edit->totalamount->errorMessage()) ?>");
			<?php if ($billinghistory_edit->taxperc->Required) { ?>
				elm = this.getElements("x" + infix + "_taxperc");
				if (elm && !ew.isHidden(elm) && !ew.hasValue(elm))
					return this.onError(elm, "<?php echo JsEncode(str_replace("%s", $billinghistory_edit->taxperc->caption(), $billinghistory_edit->taxperc->RequiredErrorMessage)) ?>");
			<?php } ?>
				elm = this.getElements("x" + infix + "_taxperc");
				if (elm && !ew.checkNumber(elm.value))
					return this.onError(elm, "<?php echo JsEncode($billinghistory_edit->taxperc->errorMessage()) ?>");
			<?php if ($billinghistory_edit->otherdetails->Required) { ?>
				elm = this.getElements("x" + infix + "_otherdetails");
				if (elm && !ew.isHidden(elm) && !ew.hasValue(elm))
					return this.onError(elm, "<?php echo JsEncode(str_replace("%s", $billinghistory_edit->otherdetails->caption(), $billinghistory_edit->otherdetails->RequiredErrorMessage)) ?>");
			<?php } ?>
			<?php if ($billinghistory_edit->transgroupid->Required) { ?>
				elm = this.getElements("x" + infix + "_transgroupid");
				if (elm && !ew.isHidden(elm) && !ew.hasValue(elm))
					return this.onError(elm, "<?php echo JsEncode(str_replace("%s", $billinghistory_edit->transgroupid->caption(), $billinghistory_edit->transgroupid->RequiredErrorMessage)) ?>");
			<?php } ?>
				elm = this.getElements("x" + infix + "_transgroupid");
				if (elm && !ew.checkInteger(elm.value))
					return this.onError(elm, "<?php echo JsEncode($billinghistory_edit->transgroupid->errorMessage()) ?>");
			<?php if ($billinghistory_edit->department->Required) { ?>
				elm = this.getElements("x" + infix + "_department");
				if (elm && !ew.isHidden(elm) && !ew.hasValue(elm))
					return this.onError(elm, "<?php echo JsEncode(str_replace("%s", $billinghistory_edit->department->caption(), $billinghistory_edit->department->RequiredErrorMessage)) ?>");
			<?php } ?>
			<?php if ($billinghistory_edit->billingresponse2->Required) { ?>
				elm = this.getElements("x" + infix + "_billingresponse2");
				if (elm && !ew.isHidden(elm) && !ew.hasValue(elm))
					return this.onError(elm, "<?php echo JsEncode(str_replace("%s", $billinghistory_edit->billingresponse2->caption(), $billinghistory_edit->billingresponse2->RequiredErrorMessage)) ?>");
			<?php } ?>
			<?php if ($billinghistory_edit->purchaseid->Required) { ?>
				elm = this.getElements("x" + infix + "_purchaseid");
				if (elm && !ew.isHidden(elm) && !ew.hasValue(elm))
					return this.onError(elm, "<?php echo JsEncode(str_replace("%s", $billinghistory_edit->purchaseid->caption(), $billinghistory_edit->purchaseid->RequiredErrorMessage)) ?>");
			<?php } ?>
				elm = this.getElements("x" + infix + "_purchaseid");
				if (elm && !ew.checkInteger(elm.value))
					return this.onError(elm, "<?php echo JsEncode($billinghistory_edit->purchaseid->errorMessage()) ?>");
			<?php if ($billinghistory_edit->paymentid->Required) { ?>
				elm = this.getElements("x" + infix + "_paymentid");
				if (elm && !ew.isHidden(elm) && !ew.hasValue(elm))
					return this.onError(elm, "<?php echo JsEncode(str_replace("%s", $billinghistory_edit->paymentid->caption(), $billinghistory_edit->paymentid->RequiredErrorMessage)) ?>");
			<?php } ?>
				elm = this.getElements("x" + infix + "_paymentid");
				if (elm && !ew.checkInteger(elm.value))
					return this.onError(elm, "<?php echo JsEncode($billinghistory_edit->paymentid->errorMessage()) ?>");

				// Call Form_CustomValidate event
				if (!this.Form_CustomValidate(fobj))
					return false;
		}

		// Process detail forms
		var dfs = $fobj.find("input[name='detailpage']").get();
		for (var i = 0; i < dfs.length; i++) {
			var df = dfs[i], val = df.value;
			if (val && ew.forms[val])
				if (!ew.forms[val].validate())
					return false;
		}
		return true;
	}

	// Form_CustomValidate
	fbillinghistoryedit.Form_CustomValidate = function(fobj) { // DO NOT CHANGE THIS LINE!

		// Your custom validation code here, return false if invalid.
		return true;
	}

	// Use JavaScript validation or not
	fbillinghistoryedit.validateRequired = <?php echo Config("CLIENT_VALIDATE") ? "true" : "false" ?>;

	// Dynamic selection lists
	fbillinghistoryedit.lists["x_serviceid"] = <?php echo $billinghistory_edit->serviceid->Lookup->toClientList($billinghistory_edit) ?>;
	fbillinghistoryedit.lists["x_serviceid"].options = <?php echo JsonEncode($billinghistory_edit->serviceid->lookupOptions()) ?>;
	fbillinghistoryedit.autoSuggests["x_serviceid"] = <?php echo json_encode(["data" => "ajax=autosuggest"]) ?>;
	fbillinghistoryedit.lists["x_success"] = <?php echo $billinghistory_edit->success->Lookup->toClientList($billinghistory_edit) ?>;
	fbillinghistoryedit.lists["x_success"].options = <?php echo JsonEncode($billinghistory_edit->success->lookupOptions()) ?>;
	fbillinghistoryedit.autoSuggests["x_success"] = <?php echo json_encode(["data" => "ajax=autosuggest"]) ?>;
	fbillinghistoryedit.lists["x_paymenttype"] = <?php echo $billinghistory_edit->paymenttype->Lookup->toClientList($billinghistory_edit) ?>;
	fbillinghistoryedit.lists["x_paymenttype"].options = <?php echo JsonEncode($billinghistory_edit->paymenttype->options(FALSE, TRUE)) ?>;
	fbillinghistoryedit.lists["x_department"] = <?php echo $billinghistory_edit->department->Lookup->toClientList($billinghistory_edit) ?>;
	fbillinghistoryedit.lists["x_department"].options = <?php echo JsonEncode($billinghistory_edit->department->lookupOptions()) ?>;
	loadjs.done("fbillinghistoryedit");
});
</script>
<script>
loadjs.ready("head", function() {

	// Client script
	// Write your client script here, no need to add script tags.

});
</script>
<?php $billinghistory_edit->showPageHeader(); ?>
<?php
$billinghistory_edit->showMessage();
?>
<form name="fbillinghistoryedit" id="fbillinghistoryedit" class="<?php echo $billinghistory_edit->FormClassName ?>" action="<?php echo CurrentPageName() ?>" method="post">
<?php if ($Page->CheckToken) { ?>
<input type="hidden" name="<?php echo Config("TOKEN_NAME") ?>" value="<?php echo $Page->Token ?>">
<?php } ?>
<input type="hidden" name="t" value="billinghistory">
<input type="hidden" name="action" id="action" value="update">
<input type="hidden" name="modal" value="<?php echo (int)$billinghistory_edit->IsModal ?>">
<div class="ew-edit-div"><!-- page* -->
<?php if ($billinghistory_edit->recid->Visible) { // recid ?>
	<div id="r_recid" class="form-group row">
		<label id="elh_billinghistory_recid" class="<?php echo $billinghistory_edit->LeftColumnClass ?>"><?php echo $billinghistory_edit->recid->caption() ?><?php echo $billinghistory_edit->recid->Required ? $Language->phrase("FieldRequiredIndicator") : "" ?></label>
		<div class="<?php echo $billinghistory_edit->RightColumnClass ?>"><div <?php echo $billinghistory_edit->recid->cellAttributes() ?>>
<span id="el_billinghistory_recid">
<span<?php echo $billinghistory_edit->recid->viewAttributes() ?>><input type="text" readonly class="form-control-plaintext" value="<?php echo HtmlEncode(RemoveHtml($billinghistory_edit->recid->EditValue)) ?>"></span>
</span>
<input type="hidden" data-table="billinghistory" data-field="x_recid" name="x_recid" id="x_recid" value="<?php echo HtmlEncode($billinghistory_edit->recid->CurrentValue) ?>">
<?php echo $billinghistory_edit->recid->CustomMsg ?></div></div>
	</div>
<?php } ?>
<?php if ($billinghistory_edit->serviceid->Visible) { // serviceid ?>
	<div id="r_serviceid" class="form-group row">
		<label id="elh_billinghistory_serviceid" class="<?php echo $billinghistory_edit->LeftColumnClass ?>"><?php echo $billinghistory_edit->serviceid->caption() ?><?php echo $billinghistory_edit->serviceid->Required ? $Language->phrase("FieldRequiredIndicator") : "" ?></label>
		<div class="<?php echo $billinghistory_edit->RightColumnClass ?>"><div <?php echo $billinghistory_edit->serviceid->cellAttributes() ?>>
<span id="el_billinghistory_serviceid">
<?php
$onchange = $billinghistory_edit->serviceid->EditAttrs->prepend("onchange", "");
$onchange = ($onchange) ? ' onchange="' . JsEncode($onchange) . '"' : '';
$billinghistory_edit->serviceid->EditAttrs["onchange"] = "";
?>
<span id="as_x_serviceid">
	<input type="text" class="form-control" name="sv_x_serviceid" id="sv_x_serviceid" value="<?php echo RemoveHtml($billinghistory_edit->serviceid->EditValue) ?>" size="30" placeholder="<?php echo HtmlEncode($billinghistory_edit->serviceid->getPlaceHolder()) ?>" data-placeholder="<?php echo HtmlEncode($billinghistory_edit->serviceid->getPlaceHolder()) ?>"<?php echo $billinghistory_edit->serviceid->editAttributes() ?>>
</span>
<input type="hidden" data-table="billinghistory" data-field="x_serviceid" data-value-separator="<?php echo $billinghistory_edit->serviceid->displayValueSeparatorAttribute() ?>" name="x_serviceid" id="x_serviceid" value="<?php echo HtmlEncode($billinghistory_edit->serviceid->CurrentValue) ?>"<?php echo $onchange ?>>
<script>
loadjs.ready(["fbillinghistoryedit"], function() {
	fbillinghistoryedit.createAutoSuggest({"id":"x_serviceid","forceSelect":false});
});
</script>
<?php echo $billinghistory_edit->serviceid->Lookup->getParamTag($billinghistory_edit, "p_x_serviceid") ?>
</span>
<?php echo $billinghistory_edit->serviceid->CustomMsg ?></div></div>
	</div>
<?php } ?>
<?php if ($billinghistory_edit->brokerid->Visible) { // brokerid ?>
	<div id="r_brokerid" class="form-group row">
		<label id="elh_billinghistory_brokerid" for="x_brokerid" class="<?php echo $billinghistory_edit->LeftColumnClass ?>"><?php echo $billinghistory_edit->brokerid->caption() ?><?php echo $billinghistory_edit->brokerid->Required ? $Language->phrase("FieldRequiredIndicator") : "" ?></label>
		<div class="<?php echo $billinghistory_edit->RightColumnClass ?>"><div <?php echo $billinghistory_edit->brokerid->cellAttributes() ?>>
<span id="el_billinghistory_brokerid">
<input type="text" data-table="billinghistory" data-field="x_brokerid" name="x_brokerid" id="x_brokerid" size="30" placeholder="<?php echo HtmlEncode($billinghistory_edit->brokerid->getPlaceHolder()) ?>" value="<?php echo $billinghistory_edit->brokerid->EditValue ?>"<?php echo $billinghistory_edit->brokerid->editAttributes() ?>>
</span>
<?php echo $billinghistory_edit->brokerid->CustomMsg ?></div></div>
	</div>
<?php } ?>
<?php if ($billinghistory_edit->customeracctno->Visible) { // customeracctno ?>
	<div id="r_customeracctno" class="form-group row">
		<label id="elh_billinghistory_customeracctno" for="x_customeracctno" class="<?php echo $billinghistory_edit->LeftColumnClass ?>"><?php echo $billinghistory_edit->customeracctno->caption() ?><?php echo $billinghistory_edit->customeracctno->Required ? $Language->phrase("FieldRequiredIndicator") : "" ?></label>
		<div class="<?php echo $billinghistory_edit->RightColumnClass ?>"><div <?php echo $billinghistory_edit->customeracctno->cellAttributes() ?>>
<span id="el_billinghistory_customeracctno">
<input type="text" data-table="billinghistory" data-field="x_customeracctno" name="x_customeracctno" id="x_customeracctno" size="30" maxlength="20" placeholder="<?php echo HtmlEncode($billinghistory_edit->customeracctno->getPlaceHolder()) ?>" value="<?php echo $billinghistory_edit->customeracctno->EditValue ?>"<?php echo $billinghistory_edit->customeracctno->editAttributes() ?>>
</span>
<?php echo $billinghistory_edit->customeracctno->CustomMsg ?></div></div>
	</div>
<?php } ?>
<?php if ($billinghistory_edit->currcode->Visible) { // currcode ?>
	<div id="r_currcode" class="form-group row">
		<label id="elh_billinghistory_currcode" for="x_currcode" class="<?php echo $billinghistory_edit->LeftColumnClass ?>"><?php echo $billinghistory_edit->currcode->caption() ?><?php echo $billinghistory_edit->currcode->Required ? $Language->phrase("FieldRequiredIndicator") : "" ?></label>
		<div class="<?php echo $billinghistory_edit->RightColumnClass ?>"><div <?php echo $billinghistory_edit->currcode->cellAttributes() ?>>
<span id="el_billinghistory_currcode">
<input type="text" data-table="billinghistory" data-field="x_currcode" name="x_currcode" id="x_currcode" size="30" maxlength="3" placeholder="<?php echo HtmlEncode($billinghistory_edit->currcode->getPlaceHolder()) ?>" value="<?php echo $billinghistory_edit->currcode->EditValue ?>"<?php echo $billinghistory_edit->currcode->editAttributes() ?>>
</span>
<?php echo $billinghistory_edit->currcode->CustomMsg ?></div></div>
	</div>
<?php } ?>
<?php if ($billinghistory_edit->balance->Visible) { // balance ?>
	<div id="r_balance" class="form-group row">
		<label id="elh_billinghistory_balance" for="x_balance" class="<?php echo $billinghistory_edit->LeftColumnClass ?>"><?php echo $billinghistory_edit->balance->caption() ?><?php echo $billinghistory_edit->balance->Required ? $Language->phrase("FieldRequiredIndicator") : "" ?></label>
		<div class="<?php echo $billinghistory_edit->RightColumnClass ?>"><div <?php echo $billinghistory_edit->balance->cellAttributes() ?>>
<span id="el_billinghistory_balance">
<input type="text" data-table="billinghistory" data-field="x_balance" name="x_balance" id="x_balance" size="30" placeholder="<?php echo HtmlEncode($billinghistory_edit->balance->getPlaceHolder()) ?>" value="<?php echo $billinghistory_edit->balance->EditValue ?>"<?php echo $billinghistory_edit->balance->editAttributes() ?>>
</span>
<?php echo $billinghistory_edit->balance->CustomMsg ?></div></div>
	</div>
<?php } ?>
<?php if ($billinghistory_edit->confcode->Visible) { // confcode ?>
	<div id="r_confcode" class="form-group row">
		<label id="elh_billinghistory_confcode" for="x_confcode" class="<?php echo $billinghistory_edit->LeftColumnClass ?>"><?php echo $billinghistory_edit->confcode->caption() ?><?php echo $billinghistory_edit->confcode->Required ? $Language->phrase("FieldRequiredIndicator") : "" ?></label>
		<div class="<?php echo $billinghistory_edit->RightColumnClass ?>"><div <?php echo $billinghistory_edit->confcode->cellAttributes() ?>>
<span id="el_billinghistory_confcode">
<input type="text" data-table="billinghistory" data-field="x_confcode" name="x_confcode" id="x_confcode" size="30" maxlength="20" placeholder="<?php echo HtmlEncode($billinghistory_edit->confcode->getPlaceHolder()) ?>" value="<?php echo $billinghistory_edit->confcode->EditValue ?>"<?php echo $billinghistory_edit->confcode->editAttributes() ?>>
</span>
<?php echo $billinghistory_edit->confcode->CustomMsg ?></div></div>
	</div>
<?php } ?>
<?php if ($billinghistory_edit->success->Visible) { // success ?>
	<div id="r_success" class="form-group row">
		<label id="elh_billinghistory_success" class="<?php echo $billinghistory_edit->LeftColumnClass ?>"><?php echo $billinghistory_edit->success->caption() ?><?php echo $billinghistory_edit->success->Required ? $Language->phrase("FieldRequiredIndicator") : "" ?></label>
		<div class="<?php echo $billinghistory_edit->RightColumnClass ?>"><div <?php echo $billinghistory_edit->success->cellAttributes() ?>>
<span id="el_billinghistory_success">
<?php
$onchange = $billinghistory_edit->success->EditAttrs->prepend("onchange", "");
$onchange = ($onchange) ? ' onchange="' . JsEncode($onchange) . '"' : '';
$billinghistory_edit->success->EditAttrs["onchange"] = "";
?>
<span id="as_x_success">
	<input type="text" class="form-control" name="sv_x_success" id="sv_x_success" value="<?php echo RemoveHtml($billinghistory_edit->success->EditValue) ?>" size="30" placeholder="<?php echo HtmlEncode($billinghistory_edit->success->getPlaceHolder()) ?>" data-placeholder="<?php echo HtmlEncode($billinghistory_edit->success->getPlaceHolder()) ?>"<?php echo $billinghistory_edit->success->editAttributes() ?>>
</span>
<input type="hidden" data-table="billinghistory" data-field="x_success" data-value-separator="<?php echo $billinghistory_edit->success->displayValueSeparatorAttribute() ?>" name="x_success" id="x_success" value="<?php echo HtmlEncode($billinghistory_edit->success->CurrentValue) ?>"<?php echo $onchange ?>>
<script>
loadjs.ready(["fbillinghistoryedit"], function() {
	fbillinghistoryedit.createAutoSuggest({"id":"x_success","forceSelect":false});
});
</script>
<?php echo $billinghistory_edit->success->Lookup->getParamTag($billinghistory_edit, "p_x_success") ?>
</span>
<?php echo $billinghistory_edit->success->CustomMsg ?></div></div>
	</div>
<?php } ?>
<?php if ($billinghistory_edit->transdate->Visible) { // transdate ?>
	<div id="r_transdate" class="form-group row">
		<label id="elh_billinghistory_transdate" for="x_transdate" class="<?php echo $billinghistory_edit->LeftColumnClass ?>"><?php echo $billinghistory_edit->transdate->caption() ?><?php echo $billinghistory_edit->transdate->Required ? $Language->phrase("FieldRequiredIndicator") : "" ?></label>
		<div class="<?php echo $billinghistory_edit->RightColumnClass ?>"><div <?php echo $billinghistory_edit->transdate->cellAttributes() ?>>
<span id="el_billinghistory_transdate">
<input type="text" data-table="billinghistory" data-field="x_transdate" data-format="2" name="x_transdate" id="x_transdate" placeholder="<?php echo HtmlEncode($billinghistory_edit->transdate->getPlaceHolder()) ?>" value="<?php echo $billinghistory_edit->transdate->EditValue ?>"<?php echo $billinghistory_edit->transdate->editAttributes() ?>>
</span>
<?php echo $billinghistory_edit->transdate->CustomMsg ?></div></div>
	</div>
<?php } ?>
<?php if ($billinghistory_edit->_userid->Visible) { // userid ?>
	<div id="r__userid" class="form-group row">
		<label id="elh_billinghistory__userid" for="x__userid" class="<?php echo $billinghistory_edit->LeftColumnClass ?>"><?php echo $billinghistory_edit->_userid->caption() ?><?php echo $billinghistory_edit->_userid->Required ? $Language->phrase("FieldRequiredIndicator") : "" ?></label>
		<div class="<?php echo $billinghistory_edit->RightColumnClass ?>"><div <?php echo $billinghistory_edit->_userid->cellAttributes() ?>>
<span id="el_billinghistory__userid">
<input type="text" data-table="billinghistory" data-field="x__userid" name="x__userid" id="x__userid" size="30" placeholder="<?php echo HtmlEncode($billinghistory_edit->_userid->getPlaceHolder()) ?>" value="<?php echo $billinghistory_edit->_userid->EditValue ?>"<?php echo $billinghistory_edit->_userid->editAttributes() ?>>
</span>
<?php echo $billinghistory_edit->_userid->CustomMsg ?></div></div>
	</div>
<?php } ?>
<?php if ($billinghistory_edit->billerresponse->Visible) { // billerresponse ?>
	<div id="r_billerresponse" class="form-group row">
		<label id="elh_billinghistory_billerresponse" for="x_billerresponse" class="<?php echo $billinghistory_edit->LeftColumnClass ?>"><?php echo $billinghistory_edit->billerresponse->caption() ?><?php echo $billinghistory_edit->billerresponse->Required ? $Language->phrase("FieldRequiredIndicator") : "" ?></label>
		<div class="<?php echo $billinghistory_edit->RightColumnClass ?>"><div <?php echo $billinghistory_edit->billerresponse->cellAttributes() ?>>
<span id="el_billinghistory_billerresponse">
<input type="text" data-table="billinghistory" data-field="x_billerresponse" name="x_billerresponse" id="x_billerresponse" size="30" maxlength="100" placeholder="<?php echo HtmlEncode($billinghistory_edit->billerresponse->getPlaceHolder()) ?>" value="<?php echo $billinghistory_edit->billerresponse->EditValue ?>"<?php echo $billinghistory_edit->billerresponse->editAttributes() ?>>
</span>
<?php echo $billinghistory_edit->billerresponse->CustomMsg ?></div></div>
	</div>
<?php } ?>
<?php if ($billinghistory_edit->paymenttype->Visible) { // paymenttype ?>
	<div id="r_paymenttype" class="form-group row">
		<label id="elh_billinghistory_paymenttype" for="x_paymenttype" class="<?php echo $billinghistory_edit->LeftColumnClass ?>"><?php echo $billinghistory_edit->paymenttype->caption() ?><?php echo $billinghistory_edit->paymenttype->Required ? $Language->phrase("FieldRequiredIndicator") : "" ?></label>
		<div class="<?php echo $billinghistory_edit->RightColumnClass ?>"><div <?php echo $billinghistory_edit->paymenttype->cellAttributes() ?>>
<span id="el_billinghistory_paymenttype">
<div class="input-group">
	<select class="custom-select ew-custom-select" data-table="billinghistory" data-field="x_paymenttype" data-value-separator="<?php echo $billinghistory_edit->paymenttype->displayValueSeparatorAttribute() ?>" id="x_paymenttype" name="x_paymenttype"<?php echo $billinghistory_edit->paymenttype->editAttributes() ?>>
			<?php echo $billinghistory_edit->paymenttype->selectOptionListHtml("x_paymenttype") ?>
		</select>
</div>
</span>
<?php echo $billinghistory_edit->paymenttype->CustomMsg ?></div></div>
	</div>
<?php } ?>
<?php if ($billinghistory_edit->customername->Visible) { // customername ?>
	<div id="r_customername" class="form-group row">
		<label id="elh_billinghistory_customername" for="x_customername" class="<?php echo $billinghistory_edit->LeftColumnClass ?>"><?php echo $billinghistory_edit->customername->caption() ?><?php echo $billinghistory_edit->customername->Required ? $Language->phrase("FieldRequiredIndicator") : "" ?></label>
		<div class="<?php echo $billinghistory_edit->RightColumnClass ?>"><div <?php echo $billinghistory_edit->customername->cellAttributes() ?>>
<span id="el_billinghistory_customername">
<input type="text" data-table="billinghistory" data-field="x_customername" name="x_customername" id="x_customername" size="30" maxlength="60" placeholder="<?php echo HtmlEncode($billinghistory_edit->customername->getPlaceHolder()) ?>" value="<?php echo $billinghistory_edit->customername->EditValue ?>"<?php echo $billinghistory_edit->customername->editAttributes() ?>>
</span>
<?php echo $billinghistory_edit->customername->CustomMsg ?></div></div>
	</div>
<?php } ?>
<?php if ($billinghistory_edit->parentuserid->Visible) { // parentuserid ?>
	<div id="r_parentuserid" class="form-group row">
		<label id="elh_billinghistory_parentuserid" for="x_parentuserid" class="<?php echo $billinghistory_edit->LeftColumnClass ?>"><?php echo $billinghistory_edit->parentuserid->caption() ?><?php echo $billinghistory_edit->parentuserid->Required ? $Language->phrase("FieldRequiredIndicator") : "" ?></label>
		<div class="<?php echo $billinghistory_edit->RightColumnClass ?>"><div <?php echo $billinghistory_edit->parentuserid->cellAttributes() ?>>
<span id="el_billinghistory_parentuserid">
<span<?php echo $billinghistory_edit->parentuserid->viewAttributes() ?>><input type="text" readonly class="form-control-plaintext" value="<?php echo HtmlEncode(RemoveHtml($billinghistory_edit->parentuserid->EditValue)) ?>"></span>
</span>
<input type="hidden" data-table="billinghistory" data-field="x_parentuserid" name="x_parentuserid" id="x_parentuserid" value="<?php echo HtmlEncode($billinghistory_edit->parentuserid->CurrentValue) ?>">
<?php echo $billinghistory_edit->parentuserid->CustomMsg ?></div></div>
	</div>
<?php } ?>
<?php if ($billinghistory_edit->refno->Visible) { // refno ?>
	<div id="r_refno" class="form-group row">
		<label id="elh_billinghistory_refno" for="x_refno" class="<?php echo $billinghistory_edit->LeftColumnClass ?>"><?php echo $billinghistory_edit->refno->caption() ?><?php echo $billinghistory_edit->refno->Required ? $Language->phrase("FieldRequiredIndicator") : "" ?></label>
		<div class="<?php echo $billinghistory_edit->RightColumnClass ?>"><div <?php echo $billinghistory_edit->refno->cellAttributes() ?>>
<span id="el_billinghistory_refno">
<input type="text" data-table="billinghistory" data-field="x_refno" name="x_refno" id="x_refno" size="30" maxlength="20" placeholder="<?php echo HtmlEncode($billinghistory_edit->refno->getPlaceHolder()) ?>" value="<?php echo $billinghistory_edit->refno->EditValue ?>"<?php echo $billinghistory_edit->refno->editAttributes() ?>>
</span>
<?php echo $billinghistory_edit->refno->CustomMsg ?></div></div>
	</div>
<?php } ?>
<?php if ($billinghistory_edit->feeid->Visible) { // feeid ?>
	<div id="r_feeid" class="form-group row">
		<label id="elh_billinghistory_feeid" for="x_feeid" class="<?php echo $billinghistory_edit->LeftColumnClass ?>"><?php echo $billinghistory_edit->feeid->caption() ?><?php echo $billinghistory_edit->feeid->Required ? $Language->phrase("FieldRequiredIndicator") : "" ?></label>
		<div class="<?php echo $billinghistory_edit->RightColumnClass ?>"><div <?php echo $billinghistory_edit->feeid->cellAttributes() ?>>
<span id="el_billinghistory_feeid">
<input type="text" data-table="billinghistory" data-field="x_feeid" name="x_feeid" id="x_feeid" size="30" placeholder="<?php echo HtmlEncode($billinghistory_edit->feeid->getPlaceHolder()) ?>" value="<?php echo $billinghistory_edit->feeid->EditValue ?>"<?php echo $billinghistory_edit->feeid->editAttributes() ?>>
</span>
<?php echo $billinghistory_edit->feeid->CustomMsg ?></div></div>
	</div>
<?php } ?>
<?php if ($billinghistory_edit->_tabletype->Visible) { // tabletype ?>
	<div id="r__tabletype" class="form-group row">
		<label id="elh_billinghistory__tabletype" for="x__tabletype" class="<?php echo $billinghistory_edit->LeftColumnClass ?>"><?php echo $billinghistory_edit->_tabletype->caption() ?><?php echo $billinghistory_edit->_tabletype->Required ? $Language->phrase("FieldRequiredIndicator") : "" ?></label>
		<div class="<?php echo $billinghistory_edit->RightColumnClass ?>"><div <?php echo $billinghistory_edit->_tabletype->cellAttributes() ?>>
<span id="el_billinghistory__tabletype">
<input type="text" data-table="billinghistory" data-field="x__tabletype" name="x__tabletype" id="x__tabletype" size="30" placeholder="<?php echo HtmlEncode($billinghistory_edit->_tabletype->getPlaceHolder()) ?>" value="<?php echo $billinghistory_edit->_tabletype->EditValue ?>"<?php echo $billinghistory_edit->_tabletype->editAttributes() ?>>
</span>
<?php echo $billinghistory_edit->_tabletype->CustomMsg ?></div></div>
	</div>
<?php } ?>
<?php if ($billinghistory_edit->feemerchanttotal->Visible) { // feemerchanttotal ?>
	<div id="r_feemerchanttotal" class="form-group row">
		<label id="elh_billinghistory_feemerchanttotal" for="x_feemerchanttotal" class="<?php echo $billinghistory_edit->LeftColumnClass ?>"><?php echo $billinghistory_edit->feemerchanttotal->caption() ?><?php echo $billinghistory_edit->feemerchanttotal->Required ? $Language->phrase("FieldRequiredIndicator") : "" ?></label>
		<div class="<?php echo $billinghistory_edit->RightColumnClass ?>"><div <?php echo $billinghistory_edit->feemerchanttotal->cellAttributes() ?>>
<span id="el_billinghistory_feemerchanttotal">
<input type="text" data-table="billinghistory" data-field="x_feemerchanttotal" name="x_feemerchanttotal" id="x_feemerchanttotal" size="30" placeholder="<?php echo HtmlEncode($billinghistory_edit->feemerchanttotal->getPlaceHolder()) ?>" value="<?php echo $billinghistory_edit->feemerchanttotal->EditValue ?>"<?php echo $billinghistory_edit->feemerchanttotal->editAttributes() ?>>
</span>
<?php echo $billinghistory_edit->feemerchanttotal->CustomMsg ?></div></div>
	</div>
<?php } ?>
<?php if ($billinghistory_edit->feeconsumertotal->Visible) { // feeconsumertotal ?>
	<div id="r_feeconsumertotal" class="form-group row">
		<label id="elh_billinghistory_feeconsumertotal" for="x_feeconsumertotal" class="<?php echo $billinghistory_edit->LeftColumnClass ?>"><?php echo $billinghistory_edit->feeconsumertotal->caption() ?><?php echo $billinghistory_edit->feeconsumertotal->Required ? $Language->phrase("FieldRequiredIndicator") : "" ?></label>
		<div class="<?php echo $billinghistory_edit->RightColumnClass ?>"><div <?php echo $billinghistory_edit->feeconsumertotal->cellAttributes() ?>>
<span id="el_billinghistory_feeconsumertotal">
<input type="text" data-table="billinghistory" data-field="x_feeconsumertotal" name="x_feeconsumertotal" id="x_feeconsumertotal" size="30" placeholder="<?php echo HtmlEncode($billinghistory_edit->feeconsumertotal->getPlaceHolder()) ?>" value="<?php echo $billinghistory_edit->feeconsumertotal->EditValue ?>"<?php echo $billinghistory_edit->feeconsumertotal->editAttributes() ?>>
</span>
<?php echo $billinghistory_edit->feeconsumertotal->CustomMsg ?></div></div>
	</div>
<?php } ?>
<?php if ($billinghistory_edit->feesystemtotal->Visible) { // feesystemtotal ?>
	<div id="r_feesystemtotal" class="form-group row">
		<label id="elh_billinghistory_feesystemtotal" for="x_feesystemtotal" class="<?php echo $billinghistory_edit->LeftColumnClass ?>"><?php echo $billinghistory_edit->feesystemtotal->caption() ?><?php echo $billinghistory_edit->feesystemtotal->Required ? $Language->phrase("FieldRequiredIndicator") : "" ?></label>
		<div class="<?php echo $billinghistory_edit->RightColumnClass ?>"><div <?php echo $billinghistory_edit->feesystemtotal->cellAttributes() ?>>
<span id="el_billinghistory_feesystemtotal">
<input type="text" data-table="billinghistory" data-field="x_feesystemtotal" name="x_feesystemtotal" id="x_feesystemtotal" size="30" placeholder="<?php echo HtmlEncode($billinghistory_edit->feesystemtotal->getPlaceHolder()) ?>" value="<?php echo $billinghistory_edit->feesystemtotal->EditValue ?>"<?php echo $billinghistory_edit->feesystemtotal->editAttributes() ?>>
</span>
<?php echo $billinghistory_edit->feesystemtotal->CustomMsg ?></div></div>
	</div>
<?php } ?>
<?php if ($billinghistory_edit->feeexternaltotal->Visible) { // feeexternaltotal ?>
	<div id="r_feeexternaltotal" class="form-group row">
		<label id="elh_billinghistory_feeexternaltotal" for="x_feeexternaltotal" class="<?php echo $billinghistory_edit->LeftColumnClass ?>"><?php echo $billinghistory_edit->feeexternaltotal->caption() ?><?php echo $billinghistory_edit->feeexternaltotal->Required ? $Language->phrase("FieldRequiredIndicator") : "" ?></label>
		<div class="<?php echo $billinghistory_edit->RightColumnClass ?>"><div <?php echo $billinghistory_edit->feeexternaltotal->cellAttributes() ?>>
<span id="el_billinghistory_feeexternaltotal">
<input type="text" data-table="billinghistory" data-field="x_feeexternaltotal" name="x_feeexternaltotal" id="x_feeexternaltotal" size="30" placeholder="<?php echo HtmlEncode($billinghistory_edit->feeexternaltotal->getPlaceHolder()) ?>" value="<?php echo $billinghistory_edit->feeexternaltotal->EditValue ?>"<?php echo $billinghistory_edit->feeexternaltotal->editAttributes() ?>>
</span>
<?php echo $billinghistory_edit->feeexternaltotal->CustomMsg ?></div></div>
	</div>
<?php } ?>
<?php if ($billinghistory_edit->feefranchiseetotal->Visible) { // feefranchiseetotal ?>
	<div id="r_feefranchiseetotal" class="form-group row">
		<label id="elh_billinghistory_feefranchiseetotal" for="x_feefranchiseetotal" class="<?php echo $billinghistory_edit->LeftColumnClass ?>"><?php echo $billinghistory_edit->feefranchiseetotal->caption() ?><?php echo $billinghistory_edit->feefranchiseetotal->Required ? $Language->phrase("FieldRequiredIndicator") : "" ?></label>
		<div class="<?php echo $billinghistory_edit->RightColumnClass ?>"><div <?php echo $billinghistory_edit->feefranchiseetotal->cellAttributes() ?>>
<span id="el_billinghistory_feefranchiseetotal">
<input type="text" data-table="billinghistory" data-field="x_feefranchiseetotal" name="x_feefranchiseetotal" id="x_feefranchiseetotal" size="30" placeholder="<?php echo HtmlEncode($billinghistory_edit->feefranchiseetotal->getPlaceHolder()) ?>" value="<?php echo $billinghistory_edit->feefranchiseetotal->EditValue ?>"<?php echo $billinghistory_edit->feefranchiseetotal->editAttributes() ?>>
</span>
<?php echo $billinghistory_edit->feefranchiseetotal->CustomMsg ?></div></div>
	</div>
<?php } ?>
<?php if ($billinghistory_edit->feeresellertotal->Visible) { // feeresellertotal ?>
	<div id="r_feeresellertotal" class="form-group row">
		<label id="elh_billinghistory_feeresellertotal" for="x_feeresellertotal" class="<?php echo $billinghistory_edit->LeftColumnClass ?>"><?php echo $billinghistory_edit->feeresellertotal->caption() ?><?php echo $billinghistory_edit->feeresellertotal->Required ? $Language->phrase("FieldRequiredIndicator") : "" ?></label>
		<div class="<?php echo $billinghistory_edit->RightColumnClass ?>"><div <?php echo $billinghistory_edit->feeresellertotal->cellAttributes() ?>>
<span id="el_billinghistory_feeresellertotal">
<input type="text" data-table="billinghistory" data-field="x_feeresellertotal" name="x_feeresellertotal" id="x_feeresellertotal" size="30" placeholder="<?php echo HtmlEncode($billinghistory_edit->feeresellertotal->getPlaceHolder()) ?>" value="<?php echo $billinghistory_edit->feeresellertotal->EditValue ?>"<?php echo $billinghistory_edit->feeresellertotal->editAttributes() ?>>
</span>
<?php echo $billinghistory_edit->feeresellertotal->CustomMsg ?></div></div>
	</div>
<?php } ?>
<?php if ($billinghistory_edit->branchname->Visible) { // branchname ?>
	<div id="r_branchname" class="form-group row">
		<label id="elh_billinghistory_branchname" for="x_branchname" class="<?php echo $billinghistory_edit->LeftColumnClass ?>"><?php echo $billinghistory_edit->branchname->caption() ?><?php echo $billinghistory_edit->branchname->Required ? $Language->phrase("FieldRequiredIndicator") : "" ?></label>
		<div class="<?php echo $billinghistory_edit->RightColumnClass ?>"><div <?php echo $billinghistory_edit->branchname->cellAttributes() ?>>
<span id="el_billinghistory_branchname">
<input type="text" data-table="billinghistory" data-field="x_branchname" name="x_branchname" id="x_branchname" size="30" maxlength="50" placeholder="<?php echo HtmlEncode($billinghistory_edit->branchname->getPlaceHolder()) ?>" value="<?php echo $billinghistory_edit->branchname->EditValue ?>"<?php echo $billinghistory_edit->branchname->editAttributes() ?>>
</span>
<?php echo $billinghistory_edit->branchname->CustomMsg ?></div></div>
	</div>
<?php } ?>
<?php if ($billinghistory_edit->clerkname->Visible) { // clerkname ?>
	<div id="r_clerkname" class="form-group row">
		<label id="elh_billinghistory_clerkname" for="x_clerkname" class="<?php echo $billinghistory_edit->LeftColumnClass ?>"><?php echo $billinghistory_edit->clerkname->caption() ?><?php echo $billinghistory_edit->clerkname->Required ? $Language->phrase("FieldRequiredIndicator") : "" ?></label>
		<div class="<?php echo $billinghistory_edit->RightColumnClass ?>"><div <?php echo $billinghistory_edit->clerkname->cellAttributes() ?>>
<span id="el_billinghistory_clerkname">
<input type="text" data-table="billinghistory" data-field="x_clerkname" name="x_clerkname" id="x_clerkname" size="30" maxlength="50" placeholder="<?php echo HtmlEncode($billinghistory_edit->clerkname->getPlaceHolder()) ?>" value="<?php echo $billinghistory_edit->clerkname->EditValue ?>"<?php echo $billinghistory_edit->clerkname->editAttributes() ?>>
</span>
<?php echo $billinghistory_edit->clerkname->CustomMsg ?></div></div>
	</div>
<?php } ?>
<?php if ($billinghistory_edit->taxamount->Visible) { // taxamount ?>
	<div id="r_taxamount" class="form-group row">
		<label id="elh_billinghistory_taxamount" for="x_taxamount" class="<?php echo $billinghistory_edit->LeftColumnClass ?>"><?php echo $billinghistory_edit->taxamount->caption() ?><?php echo $billinghistory_edit->taxamount->Required ? $Language->phrase("FieldRequiredIndicator") : "" ?></label>
		<div class="<?php echo $billinghistory_edit->RightColumnClass ?>"><div <?php echo $billinghistory_edit->taxamount->cellAttributes() ?>>
<span id="el_billinghistory_taxamount">
<input type="text" data-table="billinghistory" data-field="x_taxamount" name="x_taxamount" id="x_taxamount" size="30" maxlength="12" placeholder="<?php echo HtmlEncode($billinghistory_edit->taxamount->getPlaceHolder()) ?>" value="<?php echo $billinghistory_edit->taxamount->EditValue ?>"<?php echo $billinghistory_edit->taxamount->editAttributes() ?>>
</span>
<?php echo $billinghistory_edit->taxamount->CustomMsg ?></div></div>
	</div>
<?php } ?>
<?php if ($billinghistory_edit->totalamount->Visible) { // totalamount ?>
	<div id="r_totalamount" class="form-group row">
		<label id="elh_billinghistory_totalamount" for="x_totalamount" class="<?php echo $billinghistory_edit->LeftColumnClass ?>"><?php echo $billinghistory_edit->totalamount->caption() ?><?php echo $billinghistory_edit->totalamount->Required ? $Language->phrase("FieldRequiredIndicator") : "" ?></label>
		<div class="<?php echo $billinghistory_edit->RightColumnClass ?>"><div <?php echo $billinghistory_edit->totalamount->cellAttributes() ?>>
<span id="el_billinghistory_totalamount">
<input type="text" data-table="billinghistory" data-field="x_totalamount" name="x_totalamount" id="x_totalamount" size="30" maxlength="12" placeholder="<?php echo HtmlEncode($billinghistory_edit->totalamount->getPlaceHolder()) ?>" value="<?php echo $billinghistory_edit->totalamount->EditValue ?>"<?php echo $billinghistory_edit->totalamount->editAttributes() ?>>
</span>
<?php echo $billinghistory_edit->totalamount->CustomMsg ?></div></div>
	</div>
<?php } ?>
<?php if ($billinghistory_edit->taxperc->Visible) { // taxperc ?>
	<div id="r_taxperc" class="form-group row">
		<label id="elh_billinghistory_taxperc" for="x_taxperc" class="<?php echo $billinghistory_edit->LeftColumnClass ?>"><?php echo $billinghistory_edit->taxperc->caption() ?><?php echo $billinghistory_edit->taxperc->Required ? $Language->phrase("FieldRequiredIndicator") : "" ?></label>
		<div class="<?php echo $billinghistory_edit->RightColumnClass ?>"><div <?php echo $billinghistory_edit->taxperc->cellAttributes() ?>>
<span id="el_billinghistory_taxperc">
<input type="text" data-table="billinghistory" data-field="x_taxperc" name="x_taxperc" id="x_taxperc" size="30" maxlength="6" placeholder="<?php echo HtmlEncode($billinghistory_edit->taxperc->getPlaceHolder()) ?>" value="<?php echo $billinghistory_edit->taxperc->EditValue ?>"<?php echo $billinghistory_edit->taxperc->editAttributes() ?>>
</span>
<?php echo $billinghistory_edit->taxperc->CustomMsg ?></div></div>
	</div>
<?php } ?>
<?php if ($billinghistory_edit->otherdetails->Visible) { // otherdetails ?>
	<div id="r_otherdetails" class="form-group row">
		<label id="elh_billinghistory_otherdetails" for="x_otherdetails" class="<?php echo $billinghistory_edit->LeftColumnClass ?>"><?php echo $billinghistory_edit->otherdetails->caption() ?><?php echo $billinghistory_edit->otherdetails->Required ? $Language->phrase("FieldRequiredIndicator") : "" ?></label>
		<div class="<?php echo $billinghistory_edit->RightColumnClass ?>"><div <?php echo $billinghistory_edit->otherdetails->cellAttributes() ?>>
<span id="el_billinghistory_otherdetails">
<input type="text" data-table="billinghistory" data-field="x_otherdetails" name="x_otherdetails" id="x_otherdetails" size="30" maxlength="100" placeholder="<?php echo HtmlEncode($billinghistory_edit->otherdetails->getPlaceHolder()) ?>" value="<?php echo $billinghistory_edit->otherdetails->EditValue ?>"<?php echo $billinghistory_edit->otherdetails->editAttributes() ?>>
</span>
<?php echo $billinghistory_edit->otherdetails->CustomMsg ?></div></div>
	</div>
<?php } ?>
<?php if ($billinghistory_edit->transgroupid->Visible) { // transgroupid ?>
	<div id="r_transgroupid" class="form-group row">
		<label id="elh_billinghistory_transgroupid" for="x_transgroupid" class="<?php echo $billinghistory_edit->LeftColumnClass ?>"><?php echo $billinghistory_edit->transgroupid->caption() ?><?php echo $billinghistory_edit->transgroupid->Required ? $Language->phrase("FieldRequiredIndicator") : "" ?></label>
		<div class="<?php echo $billinghistory_edit->RightColumnClass ?>"><div <?php echo $billinghistory_edit->transgroupid->cellAttributes() ?>>
<span id="el_billinghistory_transgroupid">
<input type="text" data-table="billinghistory" data-field="x_transgroupid" name="x_transgroupid" id="x_transgroupid" size="30" maxlength="12" placeholder="<?php echo HtmlEncode($billinghistory_edit->transgroupid->getPlaceHolder()) ?>" value="<?php echo $billinghistory_edit->transgroupid->EditValue ?>"<?php echo $billinghistory_edit->transgroupid->editAttributes() ?>>
</span>
<?php echo $billinghistory_edit->transgroupid->CustomMsg ?></div></div>
	</div>
<?php } ?>
<?php if ($billinghistory_edit->department->Visible) { // department ?>
	<div id="r_department" class="form-group row">
		<label id="elh_billinghistory_department" for="x_department" class="<?php echo $billinghistory_edit->LeftColumnClass ?>"><?php echo $billinghistory_edit->department->caption() ?><?php echo $billinghistory_edit->department->Required ? $Language->phrase("FieldRequiredIndicator") : "" ?></label>
		<div class="<?php echo $billinghistory_edit->RightColumnClass ?>"><div <?php echo $billinghistory_edit->department->cellAttributes() ?>>
<span id="el_billinghistory_department">
<div class="input-group">
	<select class="custom-select ew-custom-select" data-table="billinghistory" data-field="x_department" data-value-separator="<?php echo $billinghistory_edit->department->displayValueSeparatorAttribute() ?>" id="x_department" name="x_department"<?php echo $billinghistory_edit->department->editAttributes() ?>>
			<?php echo $billinghistory_edit->department->selectOptionListHtml("x_department") ?>
		</select>
</div>
<?php echo $billinghistory_edit->department->Lookup->getParamTag($billinghistory_edit, "p_x_department") ?>
</span>
<?php echo $billinghistory_edit->department->CustomMsg ?></div></div>
	</div>
<?php } ?>
<?php if ($billinghistory_edit->billingresponse2->Visible) { // billingresponse2 ?>
	<div id="r_billingresponse2" class="form-group row">
		<label id="elh_billinghistory_billingresponse2" for="x_billingresponse2" class="<?php echo $billinghistory_edit->LeftColumnClass ?>"><?php echo $billinghistory_edit->billingresponse2->caption() ?><?php echo $billinghistory_edit->billingresponse2->Required ? $Language->phrase("FieldRequiredIndicator") : "" ?></label>
		<div class="<?php echo $billinghistory_edit->RightColumnClass ?>"><div <?php echo $billinghistory_edit->billingresponse2->cellAttributes() ?>>
<span id="el_billinghistory_billingresponse2">
<textarea data-table="billinghistory" data-field="x_billingresponse2" name="x_billingresponse2" id="x_billingresponse2" cols="35" rows="4" placeholder="<?php echo HtmlEncode($billinghistory_edit->billingresponse2->getPlaceHolder()) ?>"<?php echo $billinghistory_edit->billingresponse2->editAttributes() ?>><?php echo $billinghistory_edit->billingresponse2->EditValue ?></textarea>
</span>
<?php echo $billinghistory_edit->billingresponse2->CustomMsg ?></div></div>
	</div>
<?php } ?>
<?php if ($billinghistory_edit->purchaseid->Visible) { // purchaseid ?>
	<div id="r_purchaseid" class="form-group row">
		<label id="elh_billinghistory_purchaseid" for="x_purchaseid" class="<?php echo $billinghistory_edit->LeftColumnClass ?>"><?php echo $billinghistory_edit->purchaseid->caption() ?><?php echo $billinghistory_edit->purchaseid->Required ? $Language->phrase("FieldRequiredIndicator") : "" ?></label>
		<div class="<?php echo $billinghistory_edit->RightColumnClass ?>"><div <?php echo $billinghistory_edit->purchaseid->cellAttributes() ?>>
<span id="el_billinghistory_purchaseid">
<input type="text" data-table="billinghistory" data-field="x_purchaseid" name="x_purchaseid" id="x_purchaseid" size="30" maxlength="12" placeholder="<?php echo HtmlEncode($billinghistory_edit->purchaseid->getPlaceHolder()) ?>" value="<?php echo $billinghistory_edit->purchaseid->EditValue ?>"<?php echo $billinghistory_edit->purchaseid->editAttributes() ?>>
</span>
<?php echo $billinghistory_edit->purchaseid->CustomMsg ?></div></div>
	</div>
<?php } ?>
<?php if ($billinghistory_edit->paymentid->Visible) { // paymentid ?>
	<div id="r_paymentid" class="form-group row">
		<label id="elh_billinghistory_paymentid" for="x_paymentid" class="<?php echo $billinghistory_edit->LeftColumnClass ?>"><?php echo $billinghistory_edit->paymentid->caption() ?><?php echo $billinghistory_edit->paymentid->Required ? $Language->phrase("FieldRequiredIndicator") : "" ?></label>
		<div class="<?php echo $billinghistory_edit->RightColumnClass ?>"><div <?php echo $billinghistory_edit->paymentid->cellAttributes() ?>>
<span id="el_billinghistory_paymentid">
<input type="text" data-table="billinghistory" data-field="x_paymentid" name="x_paymentid" id="x_paymentid" size="30" maxlength="12" placeholder="<?php echo HtmlEncode($billinghistory_edit->paymentid->getPlaceHolder()) ?>" value="<?php echo $billinghistory_edit->paymentid->EditValue ?>"<?php echo $billinghistory_edit->paymentid->editAttributes() ?>>
</span>
<?php echo $billinghistory_edit->paymentid->CustomMsg ?></div></div>
	</div>
<?php } ?>
</div><!-- /page* -->
<?php if (!$billinghistory_edit->IsModal) { ?>
<div class="form-group row"><!-- buttons .form-group -->
	<div class="<?php echo $billinghistory_edit->OffsetColumnClass ?>"><!-- buttons offset -->
<button class="btn btn-primary ew-btn" name="btn-action" id="btn-action" type="submit"><?php echo $Language->phrase("SaveBtn") ?></button>
<button class="btn btn-default ew-btn" name="btn-cancel" id="btn-cancel" type="button" data-href="<?php echo $billinghistory_edit->getReturnUrl() ?>"><?php echo $Language->phrase("CancelBtn") ?></button>
	</div><!-- /buttons offset -->
</div><!-- /buttons .form-group -->
<?php } ?>
</form>
<?php
$billinghistory_edit->showPageFooter();
if (Config("DEBUG"))
	echo GetDebugMessage();
?>
<script>
loadjs.ready("load", function() {

	// Startup script
	// Write your table-specific startup script here
	// console.log("page loaded");

});
</script>
<?php include_once "footer.php"; ?>
<?php
$billinghistory_edit->terminate();
?>