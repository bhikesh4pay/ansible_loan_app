<?php
namespace PHPMaker2020\_4payadmin;

// Autoload
include_once "autoload.php";

// Session
if (session_status() !== PHP_SESSION_ACTIVE)
	\Delight\Cookie\Session::start(Config("COOKIE_SAMESITE")); // Init session data

// Output buffering
ob_start();
?>
<?php

// Write header
WriteHeader(FALSE);

// Create page object
$merchantpayments_list = new merchantpayments_list();

// Run the page
$merchantpayments_list->run();

// Setup login status
SetupLoginStatus();
SetClientVar("login", LoginStatus());

// Global Page Rendering event (in userfn*.php)
Page_Rendering();

// Page Rendering event
$merchantpayments_list->Page_Render();
?>
<?php include_once "header.php"; ?>
<?php if (!$merchantpayments_list->isExport()) { ?>
<script>
var fmerchantpaymentslist, currentPageID;
loadjs.ready("head", function() {

	// Form object
	currentPageID = ew.PAGE_ID = "list";
	fmerchantpaymentslist = currentForm = new ew.Form("fmerchantpaymentslist", "list");
	fmerchantpaymentslist.formKeyCountName = '<?php echo $merchantpayments_list->FormKeyCountName ?>';
	loadjs.done("fmerchantpaymentslist");
});
var fmerchantpaymentslistsrch;
loadjs.ready("head", function() {

	// Form object for search
	fmerchantpaymentslistsrch = currentSearchForm = new ew.Form("fmerchantpaymentslistsrch");

	// Dynamic selection lists
	// Filters

	fmerchantpaymentslistsrch.filterList = <?php echo $merchantpayments_list->getFilterList() ?>;

	// Init search panel as collapsed
	fmerchantpaymentslistsrch.initSearchPanel = true;
	loadjs.done("fmerchantpaymentslistsrch");
});
</script>
<style type="text/css">
.ew-table-preview-row { /* main table preview row color */
	background-color: #FFFFFF; /* preview row color */
}
.ew-table-preview-row .ew-grid {
	display: table;
}
</style>
<div id="ew-preview" class="d-none"><!-- preview -->
	<div class="ew-nav-tabs"><!-- .ew-nav-tabs -->
		<ul class="nav nav-tabs"></ul>
		<div class="tab-content"><!-- .tab-content -->
			<div class="tab-pane fade active show"></div>
		</div><!-- /.tab-content -->
	</div><!-- /.ew-nav-tabs -->
</div><!-- /preview -->
<script>
loadjs.ready("head", function() {
	ew.PREVIEW_PLACEMENT = ew.CSS_FLIP ? "right" : "left";
	ew.PREVIEW_SINGLE_ROW = false;
	ew.PREVIEW_OVERLAY = false;
	loadjs("js/ewpreview.js", "preview");
});
</script>
<script>
loadjs.ready("head", function() {

	// Client script
	// Write your client script here, no need to add script tags.

});
</script>
<?php } ?>
<?php if (!$merchantpayments_list->isExport()) { ?>
<div class="btn-toolbar ew-toolbar">
<?php if ($merchantpayments_list->TotalRecords > 0 && $merchantpayments_list->ExportOptions->visible()) { ?>
<?php $merchantpayments_list->ExportOptions->render("body") ?>
<?php } ?>
<?php if ($merchantpayments_list->ImportOptions->visible()) { ?>
<?php $merchantpayments_list->ImportOptions->render("body") ?>
<?php } ?>
<?php if ($merchantpayments_list->SearchOptions->visible()) { ?>
<?php $merchantpayments_list->SearchOptions->render("body") ?>
<?php } ?>
<?php if ($merchantpayments_list->FilterOptions->visible()) { ?>
<?php $merchantpayments_list->FilterOptions->render("body") ?>
<?php } ?>
<div class="clearfix"></div>
</div>
<?php } ?>
<?php
$merchantpayments_list->renderOtherOptions();
?>
<?php if ($Security->CanSearch()) { ?>
<?php if (!$merchantpayments_list->isExport() && !$merchantpayments->CurrentAction) { ?>
<form name="fmerchantpaymentslistsrch" id="fmerchantpaymentslistsrch" class="form-inline ew-form ew-ext-search-form" action="<?php echo CurrentPageName() ?>">
<div id="fmerchantpaymentslistsrch-search-panel" class="<?php echo $merchantpayments_list->SearchPanelClass ?>">
<input type="hidden" name="cmd" value="search">
<input type="hidden" name="t" value="merchantpayments">
	<div class="ew-extended-search">
<div id="xsr_<?php echo $merchantpayments_list->SearchRowCount + 1 ?>" class="ew-row d-sm-flex">
	<div class="ew-quick-search input-group">
		<input type="text" name="<?php echo Config("TABLE_BASIC_SEARCH") ?>" id="<?php echo Config("TABLE_BASIC_SEARCH") ?>" class="form-control" value="<?php echo HtmlEncode($merchantpayments_list->BasicSearch->getKeyword()) ?>" placeholder="<?php echo HtmlEncode($Language->phrase("Search")) ?>">
		<input type="hidden" name="<?php echo Config("TABLE_BASIC_SEARCH_TYPE") ?>" id="<?php echo Config("TABLE_BASIC_SEARCH_TYPE") ?>" value="<?php echo HtmlEncode($merchantpayments_list->BasicSearch->getType()) ?>">
		<div class="input-group-append">
			<button class="btn btn-primary" name="btn-submit" id="btn-submit" type="submit"><?php echo $Language->phrase("SearchBtn") ?></button>
			<button type="button" data-toggle="dropdown" class="btn btn-primary dropdown-toggle dropdown-toggle-split" aria-haspopup="true" aria-expanded="false"><span id="searchtype"><?php echo $merchantpayments_list->BasicSearch->getTypeNameShort() ?></span></button>
			<div class="dropdown-menu dropdown-menu-right">
				<a class="dropdown-item<?php if ($merchantpayments_list->BasicSearch->getType() == "") { ?> active<?php } ?>" href="#" onclick="return ew.setSearchType(this);"><?php echo $Language->phrase("QuickSearchAuto") ?></a>
				<a class="dropdown-item<?php if ($merchantpayments_list->BasicSearch->getType() == "=") { ?> active<?php } ?>" href="#" onclick="return ew.setSearchType(this, '=');"><?php echo $Language->phrase("QuickSearchExact") ?></a>
				<a class="dropdown-item<?php if ($merchantpayments_list->BasicSearch->getType() == "AND") { ?> active<?php } ?>" href="#" onclick="return ew.setSearchType(this, 'AND');"><?php echo $Language->phrase("QuickSearchAll") ?></a>
				<a class="dropdown-item<?php if ($merchantpayments_list->BasicSearch->getType() == "OR") { ?> active<?php } ?>" href="#" onclick="return ew.setSearchType(this, 'OR');"><?php echo $Language->phrase("QuickSearchAny") ?></a>
			</div>
		</div>
	</div>
</div>
	</div><!-- /.ew-extended-search -->
</div><!-- /.ew-search-panel -->
</form>
<?php } ?>
<?php } ?>
<?php $merchantpayments_list->showPageHeader(); ?>
<?php
$merchantpayments_list->showMessage();
?>
<?php if ($merchantpayments_list->TotalRecords > 0 || $merchantpayments->CurrentAction) { ?>
<div class="card ew-card ew-grid<?php if ($merchantpayments_list->isAddOrEdit()) { ?> ew-grid-add-edit<?php } ?> merchantpayments">
<form name="fmerchantpaymentslist" id="fmerchantpaymentslist" class="form-inline ew-form ew-list-form" action="<?php echo CurrentPageName() ?>" method="post">
<?php if ($Page->CheckToken) { ?>
<input type="hidden" name="<?php echo Config("TOKEN_NAME") ?>" value="<?php echo $Page->Token ?>">
<?php } ?>
<input type="hidden" name="t" value="merchantpayments">
<div id="gmp_merchantpayments" class="<?php echo ResponsiveTableClass() ?>card-body ew-grid-middle-panel">
<?php if ($merchantpayments_list->TotalRecords > 0 || $merchantpayments_list->isGridEdit()) { ?>
<table id="tbl_merchantpaymentslist" class="table ew-table"><!-- .ew-table -->
<thead>
	<tr class="ew-table-header">
<?php

// Header row
$merchantpayments->RowType = ROWTYPE_HEADER;

// Render list options
$merchantpayments_list->renderListOptions();

// Render list options (header, left)
$merchantpayments_list->ListOptions->render("header", "left");
?>
<?php if ($merchantpayments_list->paymentid->Visible) { // paymentid ?>
	<?php if ($merchantpayments_list->SortUrl($merchantpayments_list->paymentid) == "") { ?>
		<th data-name="paymentid" class="<?php echo $merchantpayments_list->paymentid->headerCellClass() ?>"><div id="elh_merchantpayments_paymentid" class="merchantpayments_paymentid"><div class="ew-table-header-caption"><?php echo $merchantpayments_list->paymentid->caption() ?></div></div></th>
	<?php } else { ?>
		<th data-name="paymentid" class="<?php echo $merchantpayments_list->paymentid->headerCellClass() ?>"><div class="ew-pointer" onclick="ew.sort(event, '<?php echo $merchantpayments_list->SortUrl($merchantpayments_list->paymentid) ?>', 1);"><div id="elh_merchantpayments_paymentid" class="merchantpayments_paymentid">
			<div class="ew-table-header-btn"><span class="ew-table-header-caption"><?php echo $merchantpayments_list->paymentid->caption() ?></span><span class="ew-table-header-sort"><?php if ($merchantpayments_list->paymentid->getSort() == "ASC") { ?><i class="fas fa-sort-up"></i><?php } elseif ($merchantpayments_list->paymentid->getSort() == "DESC") { ?><i class="fas fa-sort-down"></i><?php } ?></span></div>
		</div></div></th>
	<?php } ?>
<?php } ?>
<?php if ($merchantpayments_list->merchantid->Visible) { // merchantid ?>
	<?php if ($merchantpayments_list->SortUrl($merchantpayments_list->merchantid) == "") { ?>
		<th data-name="merchantid" class="<?php echo $merchantpayments_list->merchantid->headerCellClass() ?>"><div id="elh_merchantpayments_merchantid" class="merchantpayments_merchantid"><div class="ew-table-header-caption"><?php echo $merchantpayments_list->merchantid->caption() ?></div></div></th>
	<?php } else { ?>
		<th data-name="merchantid" class="<?php echo $merchantpayments_list->merchantid->headerCellClass() ?>"><div class="ew-pointer" onclick="ew.sort(event, '<?php echo $merchantpayments_list->SortUrl($merchantpayments_list->merchantid) ?>', 1);"><div id="elh_merchantpayments_merchantid" class="merchantpayments_merchantid">
			<div class="ew-table-header-btn"><span class="ew-table-header-caption"><?php echo $merchantpayments_list->merchantid->caption() ?></span><span class="ew-table-header-sort"><?php if ($merchantpayments_list->merchantid->getSort() == "ASC") { ?><i class="fas fa-sort-up"></i><?php } elseif ($merchantpayments_list->merchantid->getSort() == "DESC") { ?><i class="fas fa-sort-down"></i><?php } ?></span></div>
		</div></div></th>
	<?php } ?>
<?php } ?>
<?php if ($merchantpayments_list->paymentmethod->Visible) { // paymentmethod ?>
	<?php if ($merchantpayments_list->SortUrl($merchantpayments_list->paymentmethod) == "") { ?>
		<th data-name="paymentmethod" class="<?php echo $merchantpayments_list->paymentmethod->headerCellClass() ?>"><div id="elh_merchantpayments_paymentmethod" class="merchantpayments_paymentmethod"><div class="ew-table-header-caption"><?php echo $merchantpayments_list->paymentmethod->caption() ?></div></div></th>
	<?php } else { ?>
		<th data-name="paymentmethod" class="<?php echo $merchantpayments_list->paymentmethod->headerCellClass() ?>"><div class="ew-pointer" onclick="ew.sort(event, '<?php echo $merchantpayments_list->SortUrl($merchantpayments_list->paymentmethod) ?>', 1);"><div id="elh_merchantpayments_paymentmethod" class="merchantpayments_paymentmethod">
			<div class="ew-table-header-btn"><span class="ew-table-header-caption"><?php echo $merchantpayments_list->paymentmethod->caption() ?></span><span class="ew-table-header-sort"><?php if ($merchantpayments_list->paymentmethod->getSort() == "ASC") { ?><i class="fas fa-sort-up"></i><?php } elseif ($merchantpayments_list->paymentmethod->getSort() == "DESC") { ?><i class="fas fa-sort-down"></i><?php } ?></span></div>
		</div></div></th>
	<?php } ?>
<?php } ?>
<?php if ($merchantpayments_list->currencycode->Visible) { // currencycode ?>
	<?php if ($merchantpayments_list->SortUrl($merchantpayments_list->currencycode) == "") { ?>
		<th data-name="currencycode" class="<?php echo $merchantpayments_list->currencycode->headerCellClass() ?>"><div id="elh_merchantpayments_currencycode" class="merchantpayments_currencycode"><div class="ew-table-header-caption"><?php echo $merchantpayments_list->currencycode->caption() ?></div></div></th>
	<?php } else { ?>
		<th data-name="currencycode" class="<?php echo $merchantpayments_list->currencycode->headerCellClass() ?>"><div class="ew-pointer" onclick="ew.sort(event, '<?php echo $merchantpayments_list->SortUrl($merchantpayments_list->currencycode) ?>', 1);"><div id="elh_merchantpayments_currencycode" class="merchantpayments_currencycode">
			<div class="ew-table-header-btn"><span class="ew-table-header-caption"><?php echo $merchantpayments_list->currencycode->caption() ?><?php echo $Language->phrase("SrchLegend") ?></span><span class="ew-table-header-sort"><?php if ($merchantpayments_list->currencycode->getSort() == "ASC") { ?><i class="fas fa-sort-up"></i><?php } elseif ($merchantpayments_list->currencycode->getSort() == "DESC") { ?><i class="fas fa-sort-down"></i><?php } ?></span></div>
		</div></div></th>
	<?php } ?>
<?php } ?>
<?php if ($merchantpayments_list->amount->Visible) { // amount ?>
	<?php if ($merchantpayments_list->SortUrl($merchantpayments_list->amount) == "") { ?>
		<th data-name="amount" class="<?php echo $merchantpayments_list->amount->headerCellClass() ?>"><div id="elh_merchantpayments_amount" class="merchantpayments_amount"><div class="ew-table-header-caption"><?php echo $merchantpayments_list->amount->caption() ?></div></div></th>
	<?php } else { ?>
		<th data-name="amount" class="<?php echo $merchantpayments_list->amount->headerCellClass() ?>"><div class="ew-pointer" onclick="ew.sort(event, '<?php echo $merchantpayments_list->SortUrl($merchantpayments_list->amount) ?>', 1);"><div id="elh_merchantpayments_amount" class="merchantpayments_amount">
			<div class="ew-table-header-btn"><span class="ew-table-header-caption"><?php echo $merchantpayments_list->amount->caption() ?></span><span class="ew-table-header-sort"><?php if ($merchantpayments_list->amount->getSort() == "ASC") { ?><i class="fas fa-sort-up"></i><?php } elseif ($merchantpayments_list->amount->getSort() == "DESC") { ?><i class="fas fa-sort-down"></i><?php } ?></span></div>
		</div></div></th>
	<?php } ?>
<?php } ?>
<?php if ($merchantpayments_list->_4paypaymentid->Visible) { // 4paypaymentid ?>
	<?php if ($merchantpayments_list->SortUrl($merchantpayments_list->_4paypaymentid) == "") { ?>
		<th data-name="_4paypaymentid" class="<?php echo $merchantpayments_list->_4paypaymentid->headerCellClass() ?>"><div id="elh_merchantpayments__4paypaymentid" class="merchantpayments__4paypaymentid"><div class="ew-table-header-caption"><?php echo $merchantpayments_list->_4paypaymentid->caption() ?></div></div></th>
	<?php } else { ?>
		<th data-name="_4paypaymentid" class="<?php echo $merchantpayments_list->_4paypaymentid->headerCellClass() ?>"><div class="ew-pointer" onclick="ew.sort(event, '<?php echo $merchantpayments_list->SortUrl($merchantpayments_list->_4paypaymentid) ?>', 1);"><div id="elh_merchantpayments__4paypaymentid" class="merchantpayments__4paypaymentid">
			<div class="ew-table-header-btn"><span class="ew-table-header-caption"><?php echo $merchantpayments_list->_4paypaymentid->caption() ?></span><span class="ew-table-header-sort"><?php if ($merchantpayments_list->_4paypaymentid->getSort() == "ASC") { ?><i class="fas fa-sort-up"></i><?php } elseif ($merchantpayments_list->_4paypaymentid->getSort() == "DESC") { ?><i class="fas fa-sort-down"></i><?php } ?></span></div>
		</div></div></th>
	<?php } ?>
<?php } ?>
<?php if ($merchantpayments_list->notes->Visible) { // notes ?>
	<?php if ($merchantpayments_list->SortUrl($merchantpayments_list->notes) == "") { ?>
		<th data-name="notes" class="<?php echo $merchantpayments_list->notes->headerCellClass() ?>"><div id="elh_merchantpayments_notes" class="merchantpayments_notes"><div class="ew-table-header-caption"><?php echo $merchantpayments_list->notes->caption() ?></div></div></th>
	<?php } else { ?>
		<th data-name="notes" class="<?php echo $merchantpayments_list->notes->headerCellClass() ?>"><div class="ew-pointer" onclick="ew.sort(event, '<?php echo $merchantpayments_list->SortUrl($merchantpayments_list->notes) ?>', 1);"><div id="elh_merchantpayments_notes" class="merchantpayments_notes">
			<div class="ew-table-header-btn"><span class="ew-table-header-caption"><?php echo $merchantpayments_list->notes->caption() ?><?php echo $Language->phrase("SrchLegend") ?></span><span class="ew-table-header-sort"><?php if ($merchantpayments_list->notes->getSort() == "ASC") { ?><i class="fas fa-sort-up"></i><?php } elseif ($merchantpayments_list->notes->getSort() == "DESC") { ?><i class="fas fa-sort-down"></i><?php } ?></span></div>
		</div></div></th>
	<?php } ?>
<?php } ?>
<?php if ($merchantpayments_list->invoiceid->Visible) { // invoiceid ?>
	<?php if ($merchantpayments_list->SortUrl($merchantpayments_list->invoiceid) == "") { ?>
		<th data-name="invoiceid" class="<?php echo $merchantpayments_list->invoiceid->headerCellClass() ?>"><div id="elh_merchantpayments_invoiceid" class="merchantpayments_invoiceid"><div class="ew-table-header-caption"><?php echo $merchantpayments_list->invoiceid->caption() ?></div></div></th>
	<?php } else { ?>
		<th data-name="invoiceid" class="<?php echo $merchantpayments_list->invoiceid->headerCellClass() ?>"><div class="ew-pointer" onclick="ew.sort(event, '<?php echo $merchantpayments_list->SortUrl($merchantpayments_list->invoiceid) ?>', 1);"><div id="elh_merchantpayments_invoiceid" class="merchantpayments_invoiceid">
			<div class="ew-table-header-btn"><span class="ew-table-header-caption"><?php echo $merchantpayments_list->invoiceid->caption() ?></span><span class="ew-table-header-sort"><?php if ($merchantpayments_list->invoiceid->getSort() == "ASC") { ?><i class="fas fa-sort-up"></i><?php } elseif ($merchantpayments_list->invoiceid->getSort() == "DESC") { ?><i class="fas fa-sort-down"></i><?php } ?></span></div>
		</div></div></th>
	<?php } ?>
<?php } ?>
<?php if ($merchantpayments_list->lastupdatedate->Visible) { // lastupdatedate ?>
	<?php if ($merchantpayments_list->SortUrl($merchantpayments_list->lastupdatedate) == "") { ?>
		<th data-name="lastupdatedate" class="<?php echo $merchantpayments_list->lastupdatedate->headerCellClass() ?>"><div id="elh_merchantpayments_lastupdatedate" class="merchantpayments_lastupdatedate"><div class="ew-table-header-caption"><?php echo $merchantpayments_list->lastupdatedate->caption() ?></div></div></th>
	<?php } else { ?>
		<th data-name="lastupdatedate" class="<?php echo $merchantpayments_list->lastupdatedate->headerCellClass() ?>"><div class="ew-pointer" onclick="ew.sort(event, '<?php echo $merchantpayments_list->SortUrl($merchantpayments_list->lastupdatedate) ?>', 1);"><div id="elh_merchantpayments_lastupdatedate" class="merchantpayments_lastupdatedate">
			<div class="ew-table-header-btn"><span class="ew-table-header-caption"><?php echo $merchantpayments_list->lastupdatedate->caption() ?></span><span class="ew-table-header-sort"><?php if ($merchantpayments_list->lastupdatedate->getSort() == "ASC") { ?><i class="fas fa-sort-up"></i><?php } elseif ($merchantpayments_list->lastupdatedate->getSort() == "DESC") { ?><i class="fas fa-sort-down"></i><?php } ?></span></div>
		</div></div></th>
	<?php } ?>
<?php } ?>
<?php if ($merchantpayments_list->paymentdate->Visible) { // paymentdate ?>
	<?php if ($merchantpayments_list->SortUrl($merchantpayments_list->paymentdate) == "") { ?>
		<th data-name="paymentdate" class="<?php echo $merchantpayments_list->paymentdate->headerCellClass() ?>"><div id="elh_merchantpayments_paymentdate" class="merchantpayments_paymentdate"><div class="ew-table-header-caption"><?php echo $merchantpayments_list->paymentdate->caption() ?></div></div></th>
	<?php } else { ?>
		<th data-name="paymentdate" class="<?php echo $merchantpayments_list->paymentdate->headerCellClass() ?>"><div class="ew-pointer" onclick="ew.sort(event, '<?php echo $merchantpayments_list->SortUrl($merchantpayments_list->paymentdate) ?>', 1);"><div id="elh_merchantpayments_paymentdate" class="merchantpayments_paymentdate">
			<div class="ew-table-header-btn"><span class="ew-table-header-caption"><?php echo $merchantpayments_list->paymentdate->caption() ?></span><span class="ew-table-header-sort"><?php if ($merchantpayments_list->paymentdate->getSort() == "ASC") { ?><i class="fas fa-sort-up"></i><?php } elseif ($merchantpayments_list->paymentdate->getSort() == "DESC") { ?><i class="fas fa-sort-down"></i><?php } ?></span></div>
		</div></div></th>
	<?php } ?>
<?php } ?>
<?php

// Render list options (header, right)
$merchantpayments_list->ListOptions->render("header", "right");
?>
	</tr>
</thead>
<tbody>
<?php
if ($merchantpayments_list->ExportAll && $merchantpayments_list->isExport()) {
	$merchantpayments_list->StopRecord = $merchantpayments_list->TotalRecords;
} else {

	// Set the last record to display
	if ($merchantpayments_list->TotalRecords > $merchantpayments_list->StartRecord + $merchantpayments_list->DisplayRecords - 1)
		$merchantpayments_list->StopRecord = $merchantpayments_list->StartRecord + $merchantpayments_list->DisplayRecords - 1;
	else
		$merchantpayments_list->StopRecord = $merchantpayments_list->TotalRecords;
}
$merchantpayments_list->RecordCount = $merchantpayments_list->StartRecord - 1;
if ($merchantpayments_list->Recordset && !$merchantpayments_list->Recordset->EOF) {
	$merchantpayments_list->Recordset->moveFirst();
	$selectLimit = $merchantpayments_list->UseSelectLimit;
	if (!$selectLimit && $merchantpayments_list->StartRecord > 1)
		$merchantpayments_list->Recordset->move($merchantpayments_list->StartRecord - 1);
} elseif (!$merchantpayments->AllowAddDeleteRow && $merchantpayments_list->StopRecord == 0) {
	$merchantpayments_list->StopRecord = $merchantpayments->GridAddRowCount;
}

// Initialize aggregate
$merchantpayments->RowType = ROWTYPE_AGGREGATEINIT;
$merchantpayments->resetAttributes();
$merchantpayments_list->renderRow();
while ($merchantpayments_list->RecordCount < $merchantpayments_list->StopRecord) {
	$merchantpayments_list->RecordCount++;
	if ($merchantpayments_list->RecordCount >= $merchantpayments_list->StartRecord) {
		$merchantpayments_list->RowCount++;

		// Set up key count
		$merchantpayments_list->KeyCount = $merchantpayments_list->RowIndex;

		// Init row class and style
		$merchantpayments->resetAttributes();
		$merchantpayments->CssClass = "";
		if ($merchantpayments_list->isGridAdd()) {
		} else {
			$merchantpayments_list->loadRowValues($merchantpayments_list->Recordset); // Load row values
		}
		$merchantpayments->RowType = ROWTYPE_VIEW; // Render view

		// Set up row id / data-rowindex
		$merchantpayments->RowAttrs->merge(["data-rowindex" => $merchantpayments_list->RowCount, "id" => "r" . $merchantpayments_list->RowCount . "_merchantpayments", "data-rowtype" => $merchantpayments->RowType]);

		// Render row
		$merchantpayments_list->renderRow();

		// Render list options
		$merchantpayments_list->renderListOptions();
?>
	<tr <?php echo $merchantpayments->rowAttributes() ?>>
<?php

// Render list options (body, left)
$merchantpayments_list->ListOptions->render("body", "left", $merchantpayments_list->RowCount);
?>
	<?php if ($merchantpayments_list->paymentid->Visible) { // paymentid ?>
		<td data-name="paymentid" <?php echo $merchantpayments_list->paymentid->cellAttributes() ?>>
<span id="el<?php echo $merchantpayments_list->RowCount ?>_merchantpayments_paymentid">
<span<?php echo $merchantpayments_list->paymentid->viewAttributes() ?>><?php echo $merchantpayments_list->paymentid->getViewValue() ?></span>
</span>
</td>
	<?php } ?>
	<?php if ($merchantpayments_list->merchantid->Visible) { // merchantid ?>
		<td data-name="merchantid" <?php echo $merchantpayments_list->merchantid->cellAttributes() ?>>
<span id="el<?php echo $merchantpayments_list->RowCount ?>_merchantpayments_merchantid">
<span<?php echo $merchantpayments_list->merchantid->viewAttributes() ?>><?php echo $merchantpayments_list->merchantid->getViewValue() ?></span>
</span>
</td>
	<?php } ?>
	<?php if ($merchantpayments_list->paymentmethod->Visible) { // paymentmethod ?>
		<td data-name="paymentmethod" <?php echo $merchantpayments_list->paymentmethod->cellAttributes() ?>>
<span id="el<?php echo $merchantpayments_list->RowCount ?>_merchantpayments_paymentmethod">
<span<?php echo $merchantpayments_list->paymentmethod->viewAttributes() ?>><?php echo $merchantpayments_list->paymentmethod->getViewValue() ?></span>
</span>
</td>
	<?php } ?>
	<?php if ($merchantpayments_list->currencycode->Visible) { // currencycode ?>
		<td data-name="currencycode" <?php echo $merchantpayments_list->currencycode->cellAttributes() ?>>
<span id="el<?php echo $merchantpayments_list->RowCount ?>_merchantpayments_currencycode">
<span<?php echo $merchantpayments_list->currencycode->viewAttributes() ?>><?php echo $merchantpayments_list->currencycode->getViewValue() ?></span>
</span>
</td>
	<?php } ?>
	<?php if ($merchantpayments_list->amount->Visible) { // amount ?>
		<td data-name="amount" <?php echo $merchantpayments_list->amount->cellAttributes() ?>>
<span id="el<?php echo $merchantpayments_list->RowCount ?>_merchantpayments_amount">
<span<?php echo $merchantpayments_list->amount->viewAttributes() ?>><?php echo $merchantpayments_list->amount->getViewValue() ?></span>
</span>
</td>
	<?php } ?>
	<?php if ($merchantpayments_list->_4paypaymentid->Visible) { // 4paypaymentid ?>
		<td data-name="_4paypaymentid" <?php echo $merchantpayments_list->_4paypaymentid->cellAttributes() ?>>
<span id="el<?php echo $merchantpayments_list->RowCount ?>_merchantpayments__4paypaymentid">
<span<?php echo $merchantpayments_list->_4paypaymentid->viewAttributes() ?>><?php echo $merchantpayments_list->_4paypaymentid->getViewValue() ?></span>
</span>
</td>
	<?php } ?>
	<?php if ($merchantpayments_list->notes->Visible) { // notes ?>
		<td data-name="notes" <?php echo $merchantpayments_list->notes->cellAttributes() ?>>
<span id="el<?php echo $merchantpayments_list->RowCount ?>_merchantpayments_notes">
<span<?php echo $merchantpayments_list->notes->viewAttributes() ?>><?php echo $merchantpayments_list->notes->getViewValue() ?></span>
</span>
</td>
	<?php } ?>
	<?php if ($merchantpayments_list->invoiceid->Visible) { // invoiceid ?>
		<td data-name="invoiceid" <?php echo $merchantpayments_list->invoiceid->cellAttributes() ?>>
<span id="el<?php echo $merchantpayments_list->RowCount ?>_merchantpayments_invoiceid">
<span<?php echo $merchantpayments_list->invoiceid->viewAttributes() ?>><?php echo $merchantpayments_list->invoiceid->getViewValue() ?></span>
</span>
</td>
	<?php } ?>
	<?php if ($merchantpayments_list->lastupdatedate->Visible) { // lastupdatedate ?>
		<td data-name="lastupdatedate" <?php echo $merchantpayments_list->lastupdatedate->cellAttributes() ?>>
<span id="el<?php echo $merchantpayments_list->RowCount ?>_merchantpayments_lastupdatedate">
<span<?php echo $merchantpayments_list->lastupdatedate->viewAttributes() ?>><?php echo $merchantpayments_list->lastupdatedate->getViewValue() ?></span>
</span>
</td>
	<?php } ?>
	<?php if ($merchantpayments_list->paymentdate->Visible) { // paymentdate ?>
		<td data-name="paymentdate" <?php echo $merchantpayments_list->paymentdate->cellAttributes() ?>>
<span id="el<?php echo $merchantpayments_list->RowCount ?>_merchantpayments_paymentdate">
<span<?php echo $merchantpayments_list->paymentdate->viewAttributes() ?>><?php echo $merchantpayments_list->paymentdate->getViewValue() ?></span>
</span>
</td>
	<?php } ?>
<?php

// Render list options (body, right)
$merchantpayments_list->ListOptions->render("body", "right", $merchantpayments_list->RowCount);
?>
	</tr>
<?php
	}
	if (!$merchantpayments_list->isGridAdd())
		$merchantpayments_list->Recordset->moveNext();
}
?>
</tbody>
</table><!-- /.ew-table -->
<?php } ?>
</div><!-- /.ew-grid-middle-panel -->
<?php if (!$merchantpayments->CurrentAction) { ?>
<input type="hidden" name="action" id="action" value="">
<?php } ?>
</form><!-- /.ew-list-form -->
<?php

// Close recordset
if ($merchantpayments_list->Recordset)
	$merchantpayments_list->Recordset->Close();
?>
<?php if (!$merchantpayments_list->isExport()) { ?>
<div class="card-footer ew-grid-lower-panel">
<?php if (!$merchantpayments_list->isGridAdd()) { ?>
<form name="ew-pager-form" class="form-inline ew-form ew-pager-form" action="<?php echo CurrentPageName() ?>">
<?php echo $merchantpayments_list->Pager->render() ?>
</form>
<?php } ?>
<div class="ew-list-other-options">
<?php $merchantpayments_list->OtherOptions->render("body", "bottom") ?>
</div>
<div class="clearfix"></div>
</div>
<?php } ?>
</div><!-- /.ew-grid -->
<?php } ?>
<?php if ($merchantpayments_list->TotalRecords == 0 && !$merchantpayments->CurrentAction) { // Show other options ?>
<div class="ew-list-other-options">
<?php $merchantpayments_list->OtherOptions->render("body") ?>
</div>
<div class="clearfix"></div>
<?php } ?>
<?php
$merchantpayments_list->showPageFooter();
if (Config("DEBUG"))
	echo GetDebugMessage();
?>
<?php if (!$merchantpayments_list->isExport()) { ?>
<script>
loadjs.ready("load", function() {

	// Startup script
	// Write your table-specific startup script here
	// console.log("page loaded");

});
</script>
<?php } ?>
<?php include_once "footer.php"; ?>
<?php
$merchantpayments_list->terminate();
?>