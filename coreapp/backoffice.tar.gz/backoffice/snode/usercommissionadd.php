<?php
namespace PHPMaker2020\_4payadmin;

// Autoload
include_once "autoload.php";

// Session
if (session_status() !== PHP_SESSION_ACTIVE)
	\Delight\Cookie\Session::start(Config("COOKIE_SAMESITE")); // Init session data

// Output buffering
ob_start();
?>
<?php

// Write header
WriteHeader(FALSE);

// Create page object
$usercommission_add = new usercommission_add();

// Run the page
$usercommission_add->run();

// Setup login status
SetupLoginStatus();
SetClientVar("login", LoginStatus());

// Global Page Rendering event (in userfn*.php)
Page_Rendering();

// Page Rendering event
$usercommission_add->Page_Render();
?>
<?php include_once "header.php"; ?>
<script>
var fusercommissionadd, currentPageID;
loadjs.ready("head", function() {

	// Form object
	currentPageID = ew.PAGE_ID = "add";
	fusercommissionadd = currentForm = new ew.Form("fusercommissionadd", "add");

	// Validate form
	fusercommissionadd.validate = function() {
		if (!this.validateRequired)
			return true; // Ignore validation
		var $ = jQuery, fobj = this.getForm(), $fobj = $(fobj);
		if ($fobj.find("#confirm").val() == "confirm")
			return true;
		var elm, felm, uelm, addcnt = 0;
		var $k = $fobj.find("#" + this.formKeyCountName); // Get key_count
		var rowcnt = ($k[0]) ? parseInt($k.val(), 10) : 1;
		var startcnt = (rowcnt == 0) ? 0 : 1; // Check rowcnt == 0 => Inline-Add
		var gridinsert = ["insert", "gridinsert"].includes($fobj.find("#action").val()) && $k[0];
		for (var i = startcnt; i <= rowcnt; i++) {
			var infix = ($k[0]) ? String(i) : "";
			$fobj.data("rowindex", infix);
			<?php if ($usercommission_add->_userid->Required) { ?>
				elm = this.getElements("x" + infix + "__userid");
				if (elm && !ew.isHidden(elm) && !ew.hasValue(elm))
					return this.onError(elm, "<?php echo JsEncode(str_replace("%s", $usercommission_add->_userid->caption(), $usercommission_add->_userid->RequiredErrorMessage)) ?>");
			<?php } ?>
				elm = this.getElements("x" + infix + "__userid");
				if (elm && !ew.checkInteger(elm.value))
					return this.onError(elm, "<?php echo JsEncode($usercommission_add->_userid->errorMessage()) ?>");
			<?php if ($usercommission_add->userpi->Required) { ?>
				elm = this.getElements("x" + infix + "_userpi");
				if (elm && !ew.isHidden(elm) && !ew.hasValue(elm))
					return this.onError(elm, "<?php echo JsEncode(str_replace("%s", $usercommission_add->userpi->caption(), $usercommission_add->userpi->RequiredErrorMessage)) ?>");
			<?php } ?>
				elm = this.getElements("x" + infix + "_userpi");
				if (elm && !ew.checkInteger(elm.value))
					return this.onError(elm, "<?php echo JsEncode($usercommission_add->userpi->errorMessage()) ?>");
			<?php if ($usercommission_add->category->Required) { ?>
				elm = this.getElements("x" + infix + "_category");
				if (elm && !ew.isHidden(elm) && !ew.hasValue(elm))
					return this.onError(elm, "<?php echo JsEncode(str_replace("%s", $usercommission_add->category->caption(), $usercommission_add->category->RequiredErrorMessage)) ?>");
			<?php } ?>
				elm = this.getElements("x" + infix + "_category");
				if (elm && !ew.checkInteger(elm.value))
					return this.onError(elm, "<?php echo JsEncode($usercommission_add->category->errorMessage()) ?>");
			<?php if ($usercommission_add->transactiondate->Required) { ?>
				elm = this.getElements("x" + infix + "_transactiondate");
				if (elm && !ew.isHidden(elm) && !ew.hasValue(elm))
					return this.onError(elm, "<?php echo JsEncode(str_replace("%s", $usercommission_add->transactiondate->caption(), $usercommission_add->transactiondate->RequiredErrorMessage)) ?>");
			<?php } ?>
				elm = this.getElements("x" + infix + "_transactiondate");
				if (elm && !ew.checkDateDef(elm.value))
					return this.onError(elm, "<?php echo JsEncode($usercommission_add->transactiondate->errorMessage()) ?>");
			<?php if ($usercommission_add->commissionamount->Required) { ?>
				elm = this.getElements("x" + infix + "_commissionamount");
				if (elm && !ew.isHidden(elm) && !ew.hasValue(elm))
					return this.onError(elm, "<?php echo JsEncode(str_replace("%s", $usercommission_add->commissionamount->caption(), $usercommission_add->commissionamount->RequiredErrorMessage)) ?>");
			<?php } ?>
				elm = this.getElements("x" + infix + "_commissionamount");
				if (elm && !ew.checkNumber(elm.value))
					return this.onError(elm, "<?php echo JsEncode($usercommission_add->commissionamount->errorMessage()) ?>");
			<?php if ($usercommission_add->payoutdate->Required) { ?>
				elm = this.getElements("x" + infix + "_payoutdate");
				if (elm && !ew.isHidden(elm) && !ew.hasValue(elm))
					return this.onError(elm, "<?php echo JsEncode(str_replace("%s", $usercommission_add->payoutdate->caption(), $usercommission_add->payoutdate->RequiredErrorMessage)) ?>");
			<?php } ?>
				elm = this.getElements("x" + infix + "_payoutdate");
				if (elm && !ew.checkDateDef(elm.value))
					return this.onError(elm, "<?php echo JsEncode($usercommission_add->payoutdate->errorMessage()) ?>");
			<?php if ($usercommission_add->desc->Required) { ?>
				elm = this.getElements("x" + infix + "_desc");
				if (elm && !ew.isHidden(elm) && !ew.hasValue(elm))
					return this.onError(elm, "<?php echo JsEncode(str_replace("%s", $usercommission_add->desc->caption(), $usercommission_add->desc->RequiredErrorMessage)) ?>");
			<?php } ?>
			<?php if ($usercommission_add->paid->Required) { ?>
				elm = this.getElements("x" + infix + "_paid");
				if (elm && !ew.isHidden(elm) && !ew.hasValue(elm))
					return this.onError(elm, "<?php echo JsEncode(str_replace("%s", $usercommission_add->paid->caption(), $usercommission_add->paid->RequiredErrorMessage)) ?>");
			<?php } ?>
				elm = this.getElements("x" + infix + "_paid");
				if (elm && !ew.checkInteger(elm.value))
					return this.onError(elm, "<?php echo JsEncode($usercommission_add->paid->errorMessage()) ?>");

				// Call Form_CustomValidate event
				if (!this.Form_CustomValidate(fobj))
					return false;
		}

		// Process detail forms
		var dfs = $fobj.find("input[name='detailpage']").get();
		for (var i = 0; i < dfs.length; i++) {
			var df = dfs[i], val = df.value;
			if (val && ew.forms[val])
				if (!ew.forms[val].validate())
					return false;
		}
		return true;
	}

	// Form_CustomValidate
	fusercommissionadd.Form_CustomValidate = function(fobj) { // DO NOT CHANGE THIS LINE!

		// Your custom validation code here, return false if invalid.
		return true;
	}

	// Use JavaScript validation or not
	fusercommissionadd.validateRequired = <?php echo Config("CLIENT_VALIDATE") ? "true" : "false" ?>;

	// Dynamic selection lists
	fusercommissionadd.lists["x__userid"] = <?php echo $usercommission_add->_userid->Lookup->toClientList($usercommission_add) ?>;
	fusercommissionadd.lists["x__userid"].options = <?php echo JsonEncode($usercommission_add->_userid->lookupOptions()) ?>;
	fusercommissionadd.autoSuggests["x__userid"] = <?php echo json_encode(["data" => "ajax=autosuggest"]) ?>;
	loadjs.done("fusercommissionadd");
});
</script>
<script>
loadjs.ready("head", function() {

	// Client script
	// Write your client script here, no need to add script tags.

});
</script>
<?php $usercommission_add->showPageHeader(); ?>
<?php
$usercommission_add->showMessage();
?>
<form name="fusercommissionadd" id="fusercommissionadd" class="<?php echo $usercommission_add->FormClassName ?>" action="<?php echo CurrentPageName() ?>" method="post">
<?php if ($Page->CheckToken) { ?>
<input type="hidden" name="<?php echo Config("TOKEN_NAME") ?>" value="<?php echo $Page->Token ?>">
<?php } ?>
<input type="hidden" name="t" value="usercommission">
<input type="hidden" name="action" id="action" value="insert">
<input type="hidden" name="modal" value="<?php echo (int)$usercommission_add->IsModal ?>">
<?php if ($usercommission->getCurrentMasterTable() == "user") { ?>
<input type="hidden" name="<?php echo Config("TABLE_SHOW_MASTER") ?>" value="user">
<input type="hidden" name="fk_id" value="<?php echo HtmlEncode($usercommission_add->_userid->getSessionValue()) ?>">
<?php } ?>
<div class="ew-add-div"><!-- page* -->
<?php if ($usercommission_add->_userid->Visible) { // userid ?>
	<div id="r__userid" class="form-group row">
		<label id="elh_usercommission__userid" class="<?php echo $usercommission_add->LeftColumnClass ?>"><?php echo $usercommission_add->_userid->caption() ?><?php echo $usercommission_add->_userid->Required ? $Language->phrase("FieldRequiredIndicator") : "" ?></label>
		<div class="<?php echo $usercommission_add->RightColumnClass ?>"><div <?php echo $usercommission_add->_userid->cellAttributes() ?>>
<?php if ($usercommission_add->_userid->getSessionValue() != "") { ?>
<span id="el_usercommission__userid">
<span<?php echo $usercommission_add->_userid->viewAttributes() ?>><input type="text" readonly class="form-control-plaintext" value="<?php echo HtmlEncode(RemoveHtml($usercommission_add->_userid->ViewValue)) ?>"></span>
</span>
<input type="hidden" id="x__userid" name="x__userid" value="<?php echo HtmlEncode($usercommission_add->_userid->CurrentValue) ?>">
<?php } else { ?>
<span id="el_usercommission__userid">
<?php
$onchange = $usercommission_add->_userid->EditAttrs->prepend("onchange", "");
$onchange = ($onchange) ? ' onchange="' . JsEncode($onchange) . '"' : '';
$usercommission_add->_userid->EditAttrs["onchange"] = "";
?>
<span id="as_x__userid">
	<input type="text" class="form-control" name="sv_x__userid" id="sv_x__userid" value="<?php echo RemoveHtml($usercommission_add->_userid->EditValue) ?>" size="30" maxlength="12" placeholder="<?php echo HtmlEncode($usercommission_add->_userid->getPlaceHolder()) ?>" data-placeholder="<?php echo HtmlEncode($usercommission_add->_userid->getPlaceHolder()) ?>"<?php echo $usercommission_add->_userid->editAttributes() ?>>
</span>
<input type="hidden" data-table="usercommission" data-field="x__userid" data-value-separator="<?php echo $usercommission_add->_userid->displayValueSeparatorAttribute() ?>" name="x__userid" id="x__userid" value="<?php echo HtmlEncode($usercommission_add->_userid->CurrentValue) ?>"<?php echo $onchange ?>>
<script>
loadjs.ready(["fusercommissionadd"], function() {
	fusercommissionadd.createAutoSuggest({"id":"x__userid","forceSelect":false});
});
</script>
<?php echo $usercommission_add->_userid->Lookup->getParamTag($usercommission_add, "p_x__userid") ?>
</span>
<?php } ?>
<?php echo $usercommission_add->_userid->CustomMsg ?></div></div>
	</div>
<?php } ?>
<?php if ($usercommission_add->userpi->Visible) { // userpi ?>
	<div id="r_userpi" class="form-group row">
		<label id="elh_usercommission_userpi" for="x_userpi" class="<?php echo $usercommission_add->LeftColumnClass ?>"><?php echo $usercommission_add->userpi->caption() ?><?php echo $usercommission_add->userpi->Required ? $Language->phrase("FieldRequiredIndicator") : "" ?></label>
		<div class="<?php echo $usercommission_add->RightColumnClass ?>"><div <?php echo $usercommission_add->userpi->cellAttributes() ?>>
<span id="el_usercommission_userpi">
<input type="text" data-table="usercommission" data-field="x_userpi" name="x_userpi" id="x_userpi" size="30" maxlength="12" placeholder="<?php echo HtmlEncode($usercommission_add->userpi->getPlaceHolder()) ?>" value="<?php echo $usercommission_add->userpi->EditValue ?>"<?php echo $usercommission_add->userpi->editAttributes() ?>>
</span>
<?php echo $usercommission_add->userpi->CustomMsg ?></div></div>
	</div>
<?php } ?>
<?php if ($usercommission_add->category->Visible) { // category ?>
	<div id="r_category" class="form-group row">
		<label id="elh_usercommission_category" for="x_category" class="<?php echo $usercommission_add->LeftColumnClass ?>"><?php echo $usercommission_add->category->caption() ?><?php echo $usercommission_add->category->Required ? $Language->phrase("FieldRequiredIndicator") : "" ?></label>
		<div class="<?php echo $usercommission_add->RightColumnClass ?>"><div <?php echo $usercommission_add->category->cellAttributes() ?>>
<span id="el_usercommission_category">
<input type="text" data-table="usercommission" data-field="x_category" name="x_category" id="x_category" size="30" maxlength="2" placeholder="<?php echo HtmlEncode($usercommission_add->category->getPlaceHolder()) ?>" value="<?php echo $usercommission_add->category->EditValue ?>"<?php echo $usercommission_add->category->editAttributes() ?>>
</span>
<?php echo $usercommission_add->category->CustomMsg ?></div></div>
	</div>
<?php } ?>
<?php if ($usercommission_add->transactiondate->Visible) { // transactiondate ?>
	<div id="r_transactiondate" class="form-group row">
		<label id="elh_usercommission_transactiondate" for="x_transactiondate" class="<?php echo $usercommission_add->LeftColumnClass ?>"><?php echo $usercommission_add->transactiondate->caption() ?><?php echo $usercommission_add->transactiondate->Required ? $Language->phrase("FieldRequiredIndicator") : "" ?></label>
		<div class="<?php echo $usercommission_add->RightColumnClass ?>"><div <?php echo $usercommission_add->transactiondate->cellAttributes() ?>>
<span id="el_usercommission_transactiondate">
<input type="text" data-table="usercommission" data-field="x_transactiondate" name="x_transactiondate" id="x_transactiondate" maxlength="19" placeholder="<?php echo HtmlEncode($usercommission_add->transactiondate->getPlaceHolder()) ?>" value="<?php echo $usercommission_add->transactiondate->EditValue ?>"<?php echo $usercommission_add->transactiondate->editAttributes() ?>>
<?php if (!$usercommission_add->transactiondate->ReadOnly && !$usercommission_add->transactiondate->Disabled && !isset($usercommission_add->transactiondate->EditAttrs["readonly"]) && !isset($usercommission_add->transactiondate->EditAttrs["disabled"])) { ?>
<script>
loadjs.ready(["fusercommissionadd", "datetimepicker"], function() {
	ew.createDateTimePicker("fusercommissionadd", "x_transactiondate", {"ignoreReadonly":true,"useCurrent":false,"format":0});
});
</script>
<?php } ?>
</span>
<?php echo $usercommission_add->transactiondate->CustomMsg ?></div></div>
	</div>
<?php } ?>
<?php if ($usercommission_add->commissionamount->Visible) { // commissionamount ?>
	<div id="r_commissionamount" class="form-group row">
		<label id="elh_usercommission_commissionamount" for="x_commissionamount" class="<?php echo $usercommission_add->LeftColumnClass ?>"><?php echo $usercommission_add->commissionamount->caption() ?><?php echo $usercommission_add->commissionamount->Required ? $Language->phrase("FieldRequiredIndicator") : "" ?></label>
		<div class="<?php echo $usercommission_add->RightColumnClass ?>"><div <?php echo $usercommission_add->commissionamount->cellAttributes() ?>>
<span id="el_usercommission_commissionamount">
<input type="text" data-table="usercommission" data-field="x_commissionamount" name="x_commissionamount" id="x_commissionamount" size="30" maxlength="12" placeholder="<?php echo HtmlEncode($usercommission_add->commissionamount->getPlaceHolder()) ?>" value="<?php echo $usercommission_add->commissionamount->EditValue ?>"<?php echo $usercommission_add->commissionamount->editAttributes() ?>>
</span>
<?php echo $usercommission_add->commissionamount->CustomMsg ?></div></div>
	</div>
<?php } ?>
<?php if ($usercommission_add->payoutdate->Visible) { // payoutdate ?>
	<div id="r_payoutdate" class="form-group row">
		<label id="elh_usercommission_payoutdate" for="x_payoutdate" class="<?php echo $usercommission_add->LeftColumnClass ?>"><?php echo $usercommission_add->payoutdate->caption() ?><?php echo $usercommission_add->payoutdate->Required ? $Language->phrase("FieldRequiredIndicator") : "" ?></label>
		<div class="<?php echo $usercommission_add->RightColumnClass ?>"><div <?php echo $usercommission_add->payoutdate->cellAttributes() ?>>
<span id="el_usercommission_payoutdate">
<input type="text" data-table="usercommission" data-field="x_payoutdate" name="x_payoutdate" id="x_payoutdate" maxlength="10" placeholder="<?php echo HtmlEncode($usercommission_add->payoutdate->getPlaceHolder()) ?>" value="<?php echo $usercommission_add->payoutdate->EditValue ?>"<?php echo $usercommission_add->payoutdate->editAttributes() ?>>
<?php if (!$usercommission_add->payoutdate->ReadOnly && !$usercommission_add->payoutdate->Disabled && !isset($usercommission_add->payoutdate->EditAttrs["readonly"]) && !isset($usercommission_add->payoutdate->EditAttrs["disabled"])) { ?>
<script>
loadjs.ready(["fusercommissionadd", "datetimepicker"], function() {
	ew.createDateTimePicker("fusercommissionadd", "x_payoutdate", {"ignoreReadonly":true,"useCurrent":false,"format":0});
});
</script>
<?php } ?>
</span>
<?php echo $usercommission_add->payoutdate->CustomMsg ?></div></div>
	</div>
<?php } ?>
<?php if ($usercommission_add->desc->Visible) { // desc ?>
	<div id="r_desc" class="form-group row">
		<label id="elh_usercommission_desc" for="x_desc" class="<?php echo $usercommission_add->LeftColumnClass ?>"><?php echo $usercommission_add->desc->caption() ?><?php echo $usercommission_add->desc->Required ? $Language->phrase("FieldRequiredIndicator") : "" ?></label>
		<div class="<?php echo $usercommission_add->RightColumnClass ?>"><div <?php echo $usercommission_add->desc->cellAttributes() ?>>
<span id="el_usercommission_desc">
<input type="text" data-table="usercommission" data-field="x_desc" name="x_desc" id="x_desc" size="30" maxlength="60" placeholder="<?php echo HtmlEncode($usercommission_add->desc->getPlaceHolder()) ?>" value="<?php echo $usercommission_add->desc->EditValue ?>"<?php echo $usercommission_add->desc->editAttributes() ?>>
</span>
<?php echo $usercommission_add->desc->CustomMsg ?></div></div>
	</div>
<?php } ?>
<?php if ($usercommission_add->paid->Visible) { // paid ?>
	<div id="r_paid" class="form-group row">
		<label id="elh_usercommission_paid" for="x_paid" class="<?php echo $usercommission_add->LeftColumnClass ?>"><?php echo $usercommission_add->paid->caption() ?><?php echo $usercommission_add->paid->Required ? $Language->phrase("FieldRequiredIndicator") : "" ?></label>
		<div class="<?php echo $usercommission_add->RightColumnClass ?>"><div <?php echo $usercommission_add->paid->cellAttributes() ?>>
<span id="el_usercommission_paid">
<input type="text" data-table="usercommission" data-field="x_paid" name="x_paid" id="x_paid" size="30" maxlength="1" placeholder="<?php echo HtmlEncode($usercommission_add->paid->getPlaceHolder()) ?>" value="<?php echo $usercommission_add->paid->EditValue ?>"<?php echo $usercommission_add->paid->editAttributes() ?>>
</span>
<?php echo $usercommission_add->paid->CustomMsg ?></div></div>
	</div>
<?php } ?>
</div><!-- /page* -->
<?php if (!$usercommission_add->IsModal) { ?>
<div class="form-group row"><!-- buttons .form-group -->
	<div class="<?php echo $usercommission_add->OffsetColumnClass ?>"><!-- buttons offset -->
<button class="btn btn-primary ew-btn" name="btn-action" id="btn-action" type="submit"><?php echo $Language->phrase("AddBtn") ?></button>
<button class="btn btn-default ew-btn" name="btn-cancel" id="btn-cancel" type="button" data-href="<?php echo $usercommission_add->getReturnUrl() ?>"><?php echo $Language->phrase("CancelBtn") ?></button>
	</div><!-- /buttons offset -->
</div><!-- /buttons .form-group -->
<?php } ?>
</form>
<?php
$usercommission_add->showPageFooter();
if (Config("DEBUG"))
	echo GetDebugMessage();
?>
<script>
loadjs.ready("load", function() {

	// Startup script
	// Write your table-specific startup script here
	// console.log("page loaded");

});
</script>
<?php include_once "footer.php"; ?>
<?php
$usercommission_add->terminate();
?>