<?php
namespace PHPMaker2020\_4payadmin;

// Autoload
include_once "autoload.php";

// Session
if (session_status() !== PHP_SESSION_ACTIVE)
	\Delight\Cookie\Session::start(Config("COOKIE_SAMESITE")); // Init session data

// Output buffering
ob_start();
?>
<?php

// Write header
WriteHeader(FALSE);

// Create page object
$vloanissued_list = new vloanissued_list();

// Run the page
$vloanissued_list->run();

// Setup login status
SetupLoginStatus();
SetClientVar("login", LoginStatus());

// Global Page Rendering event (in userfn*.php)
Page_Rendering();

// Page Rendering event
$vloanissued_list->Page_Render();
?>
<?php include_once "header.php"; ?>
<?php if (!$vloanissued_list->isExport()) { ?>
<script>
var fvloanissuedlist, currentPageID;
loadjs.ready("head", function() {

	// Form object
	currentPageID = ew.PAGE_ID = "list";
	fvloanissuedlist = currentForm = new ew.Form("fvloanissuedlist", "list");
	fvloanissuedlist.formKeyCountName = '<?php echo $vloanissued_list->FormKeyCountName ?>';
	loadjs.done("fvloanissuedlist");
});
var fvloanissuedlistsrch;
loadjs.ready("head", function() {

	// Form object for search
	fvloanissuedlistsrch = currentSearchForm = new ew.Form("fvloanissuedlistsrch");

	// Dynamic selection lists
	// Filters

	fvloanissuedlistsrch.filterList = <?php echo $vloanissued_list->getFilterList() ?>;

	// Init search panel as collapsed
	fvloanissuedlistsrch.initSearchPanel = true;
	loadjs.done("fvloanissuedlistsrch");
});
</script>
<style type="text/css">
.ew-table-preview-row { /* main table preview row color */
	background-color: #FFFFFF; /* preview row color */
}
.ew-table-preview-row .ew-grid {
	display: table;
}
</style>
<div id="ew-preview" class="d-none"><!-- preview -->
	<div class="ew-nav-tabs"><!-- .ew-nav-tabs -->
		<ul class="nav nav-tabs"></ul>
		<div class="tab-content"><!-- .tab-content -->
			<div class="tab-pane fade active show"></div>
		</div><!-- /.tab-content -->
	</div><!-- /.ew-nav-tabs -->
</div><!-- /preview -->
<script>
loadjs.ready("head", function() {
	ew.PREVIEW_PLACEMENT = ew.CSS_FLIP ? "right" : "left";
	ew.PREVIEW_SINGLE_ROW = false;
	ew.PREVIEW_OVERLAY = false;
	loadjs("js/ewpreview.js", "preview");
});
</script>
<script>
loadjs.ready("head", function() {

	// Client script
	// Write your client script here, no need to add script tags.

});
</script>
<?php } ?>
<?php if (!$vloanissued_list->isExport()) { ?>
<div class="btn-toolbar ew-toolbar">
<?php if ($vloanissued_list->TotalRecords > 0 && $vloanissued_list->ExportOptions->visible()) { ?>
<?php $vloanissued_list->ExportOptions->render("body") ?>
<?php } ?>
<?php if ($vloanissued_list->ImportOptions->visible()) { ?>
<?php $vloanissued_list->ImportOptions->render("body") ?>
<?php } ?>
<?php if ($vloanissued_list->SearchOptions->visible()) { ?>
<?php $vloanissued_list->SearchOptions->render("body") ?>
<?php } ?>
<?php if ($vloanissued_list->FilterOptions->visible()) { ?>
<?php $vloanissued_list->FilterOptions->render("body") ?>
<?php } ?>
<div class="clearfix"></div>
</div>
<?php } ?>
<?php
$vloanissued_list->renderOtherOptions();
?>
<?php if ($Security->CanSearch()) { ?>
<?php if (!$vloanissued_list->isExport() && !$vloanissued->CurrentAction) { ?>
<form name="fvloanissuedlistsrch" id="fvloanissuedlistsrch" class="form-inline ew-form ew-ext-search-form" action="<?php echo CurrentPageName() ?>">
<div id="fvloanissuedlistsrch-search-panel" class="<?php echo $vloanissued_list->SearchPanelClass ?>">
<input type="hidden" name="cmd" value="search">
<input type="hidden" name="t" value="vloanissued">
	<div class="ew-extended-search">
<div id="xsr_<?php echo $vloanissued_list->SearchRowCount + 1 ?>" class="ew-row d-sm-flex">
	<div class="ew-quick-search input-group">
		<input type="text" name="<?php echo Config("TABLE_BASIC_SEARCH") ?>" id="<?php echo Config("TABLE_BASIC_SEARCH") ?>" class="form-control" value="<?php echo HtmlEncode($vloanissued_list->BasicSearch->getKeyword()) ?>" placeholder="<?php echo HtmlEncode($Language->phrase("Search")) ?>">
		<input type="hidden" name="<?php echo Config("TABLE_BASIC_SEARCH_TYPE") ?>" id="<?php echo Config("TABLE_BASIC_SEARCH_TYPE") ?>" value="<?php echo HtmlEncode($vloanissued_list->BasicSearch->getType()) ?>">
		<div class="input-group-append">
			<button class="btn btn-primary" name="btn-submit" id="btn-submit" type="submit"><?php echo $Language->phrase("SearchBtn") ?></button>
			<button type="button" data-toggle="dropdown" class="btn btn-primary dropdown-toggle dropdown-toggle-split" aria-haspopup="true" aria-expanded="false"><span id="searchtype"><?php echo $vloanissued_list->BasicSearch->getTypeNameShort() ?></span></button>
			<div class="dropdown-menu dropdown-menu-right">
				<a class="dropdown-item<?php if ($vloanissued_list->BasicSearch->getType() == "") { ?> active<?php } ?>" href="#" onclick="return ew.setSearchType(this);"><?php echo $Language->phrase("QuickSearchAuto") ?></a>
				<a class="dropdown-item<?php if ($vloanissued_list->BasicSearch->getType() == "=") { ?> active<?php } ?>" href="#" onclick="return ew.setSearchType(this, '=');"><?php echo $Language->phrase("QuickSearchExact") ?></a>
				<a class="dropdown-item<?php if ($vloanissued_list->BasicSearch->getType() == "AND") { ?> active<?php } ?>" href="#" onclick="return ew.setSearchType(this, 'AND');"><?php echo $Language->phrase("QuickSearchAll") ?></a>
				<a class="dropdown-item<?php if ($vloanissued_list->BasicSearch->getType() == "OR") { ?> active<?php } ?>" href="#" onclick="return ew.setSearchType(this, 'OR');"><?php echo $Language->phrase("QuickSearchAny") ?></a>
			</div>
		</div>
	</div>
</div>
	</div><!-- /.ew-extended-search -->
</div><!-- /.ew-search-panel -->
</form>
<?php } ?>
<?php } ?>
<?php $vloanissued_list->showPageHeader(); ?>
<?php
$vloanissued_list->showMessage();
?>
<?php if ($vloanissued_list->TotalRecords > 0 || $vloanissued->CurrentAction) { ?>
<div class="card ew-card ew-grid<?php if ($vloanissued_list->isAddOrEdit()) { ?> ew-grid-add-edit<?php } ?> vloanissued">
<form name="fvloanissuedlist" id="fvloanissuedlist" class="form-inline ew-form ew-list-form" action="<?php echo CurrentPageName() ?>" method="post">
<?php if ($Page->CheckToken) { ?>
<input type="hidden" name="<?php echo Config("TOKEN_NAME") ?>" value="<?php echo $Page->Token ?>">
<?php } ?>
<input type="hidden" name="t" value="vloanissued">
<div id="gmp_vloanissued" class="<?php echo ResponsiveTableClass() ?>card-body ew-grid-middle-panel">
<?php if ($vloanissued_list->TotalRecords > 0 || $vloanissued_list->isGridEdit()) { ?>
<table id="tbl_vloanissuedlist" class="table ew-table"><!-- .ew-table -->
<thead>
	<tr class="ew-table-header">
<?php

// Header row
$vloanissued->RowType = ROWTYPE_HEADER;

// Render list options
$vloanissued_list->renderListOptions();

// Render list options (header, left)
$vloanissued_list->ListOptions->render("header", "left");
?>
<?php if ($vloanissued_list->loanid->Visible) { // loanid ?>
	<?php if ($vloanissued_list->SortUrl($vloanissued_list->loanid) == "") { ?>
		<th data-name="loanid" class="<?php echo $vloanissued_list->loanid->headerCellClass() ?>"><div id="elh_vloanissued_loanid" class="vloanissued_loanid"><div class="ew-table-header-caption"><?php echo $vloanissued_list->loanid->caption() ?></div></div></th>
	<?php } else { ?>
		<th data-name="loanid" class="<?php echo $vloanissued_list->loanid->headerCellClass() ?>"><div class="ew-pointer" onclick="ew.sort(event, '<?php echo $vloanissued_list->SortUrl($vloanissued_list->loanid) ?>', 1);"><div id="elh_vloanissued_loanid" class="vloanissued_loanid">
			<div class="ew-table-header-btn"><span class="ew-table-header-caption"><?php echo $vloanissued_list->loanid->caption() ?></span><span class="ew-table-header-sort"><?php if ($vloanissued_list->loanid->getSort() == "ASC") { ?><i class="fas fa-sort-up"></i><?php } elseif ($vloanissued_list->loanid->getSort() == "DESC") { ?><i class="fas fa-sort-down"></i><?php } ?></span></div>
		</div></div></th>
	<?php } ?>
<?php } ?>
<?php if ($vloanissued_list->_userid->Visible) { // userid ?>
	<?php if ($vloanissued_list->SortUrl($vloanissued_list->_userid) == "") { ?>
		<th data-name="_userid" class="<?php echo $vloanissued_list->_userid->headerCellClass() ?>"><div id="elh_vloanissued__userid" class="vloanissued__userid"><div class="ew-table-header-caption"><?php echo $vloanissued_list->_userid->caption() ?></div></div></th>
	<?php } else { ?>
		<th data-name="_userid" class="<?php echo $vloanissued_list->_userid->headerCellClass() ?>"><div class="ew-pointer" onclick="ew.sort(event, '<?php echo $vloanissued_list->SortUrl($vloanissued_list->_userid) ?>', 1);"><div id="elh_vloanissued__userid" class="vloanissued__userid">
			<div class="ew-table-header-btn"><span class="ew-table-header-caption"><?php echo $vloanissued_list->_userid->caption() ?></span><span class="ew-table-header-sort"><?php if ($vloanissued_list->_userid->getSort() == "ASC") { ?><i class="fas fa-sort-up"></i><?php } elseif ($vloanissued_list->_userid->getSort() == "DESC") { ?><i class="fas fa-sort-down"></i><?php } ?></span></div>
		</div></div></th>
	<?php } ?>
<?php } ?>
<?php if ($vloanissued_list->emailAccount->Visible) { // emailAccount ?>
	<?php if ($vloanissued_list->SortUrl($vloanissued_list->emailAccount) == "") { ?>
		<th data-name="emailAccount" class="<?php echo $vloanissued_list->emailAccount->headerCellClass() ?>"><div id="elh_vloanissued_emailAccount" class="vloanissued_emailAccount"><div class="ew-table-header-caption"><?php echo $vloanissued_list->emailAccount->caption() ?></div></div></th>
	<?php } else { ?>
		<th data-name="emailAccount" class="<?php echo $vloanissued_list->emailAccount->headerCellClass() ?>"><div class="ew-pointer" onclick="ew.sort(event, '<?php echo $vloanissued_list->SortUrl($vloanissued_list->emailAccount) ?>', 1);"><div id="elh_vloanissued_emailAccount" class="vloanissued_emailAccount">
			<div class="ew-table-header-btn"><span class="ew-table-header-caption"><?php echo $vloanissued_list->emailAccount->caption() ?><?php echo $Language->phrase("SrchLegend") ?></span><span class="ew-table-header-sort"><?php if ($vloanissued_list->emailAccount->getSort() == "ASC") { ?><i class="fas fa-sort-up"></i><?php } elseif ($vloanissued_list->emailAccount->getSort() == "DESC") { ?><i class="fas fa-sort-down"></i><?php } ?></span></div>
		</div></div></th>
	<?php } ?>
<?php } ?>
<?php if ($vloanissued_list->issueddate->Visible) { // issueddate ?>
	<?php if ($vloanissued_list->SortUrl($vloanissued_list->issueddate) == "") { ?>
		<th data-name="issueddate" class="<?php echo $vloanissued_list->issueddate->headerCellClass() ?>"><div id="elh_vloanissued_issueddate" class="vloanissued_issueddate"><div class="ew-table-header-caption"><?php echo $vloanissued_list->issueddate->caption() ?></div></div></th>
	<?php } else { ?>
		<th data-name="issueddate" class="<?php echo $vloanissued_list->issueddate->headerCellClass() ?>"><div class="ew-pointer" onclick="ew.sort(event, '<?php echo $vloanissued_list->SortUrl($vloanissued_list->issueddate) ?>', 1);"><div id="elh_vloanissued_issueddate" class="vloanissued_issueddate">
			<div class="ew-table-header-btn"><span class="ew-table-header-caption"><?php echo $vloanissued_list->issueddate->caption() ?></span><span class="ew-table-header-sort"><?php if ($vloanissued_list->issueddate->getSort() == "ASC") { ?><i class="fas fa-sort-up"></i><?php } elseif ($vloanissued_list->issueddate->getSort() == "DESC") { ?><i class="fas fa-sort-down"></i><?php } ?></span></div>
		</div></div></th>
	<?php } ?>
<?php } ?>
<?php if ($vloanissued_list->currcode->Visible) { // currcode ?>
	<?php if ($vloanissued_list->SortUrl($vloanissued_list->currcode) == "") { ?>
		<th data-name="currcode" class="<?php echo $vloanissued_list->currcode->headerCellClass() ?>"><div id="elh_vloanissued_currcode" class="vloanissued_currcode"><div class="ew-table-header-caption"><?php echo $vloanissued_list->currcode->caption() ?></div></div></th>
	<?php } else { ?>
		<th data-name="currcode" class="<?php echo $vloanissued_list->currcode->headerCellClass() ?>"><div class="ew-pointer" onclick="ew.sort(event, '<?php echo $vloanissued_list->SortUrl($vloanissued_list->currcode) ?>', 1);"><div id="elh_vloanissued_currcode" class="vloanissued_currcode">
			<div class="ew-table-header-btn"><span class="ew-table-header-caption"><?php echo $vloanissued_list->currcode->caption() ?><?php echo $Language->phrase("SrchLegend") ?></span><span class="ew-table-header-sort"><?php if ($vloanissued_list->currcode->getSort() == "ASC") { ?><i class="fas fa-sort-up"></i><?php } elseif ($vloanissued_list->currcode->getSort() == "DESC") { ?><i class="fas fa-sort-down"></i><?php } ?></span></div>
		</div></div></th>
	<?php } ?>
<?php } ?>
<?php if ($vloanissued_list->issuedamount->Visible) { // issuedamount ?>
	<?php if ($vloanissued_list->SortUrl($vloanissued_list->issuedamount) == "") { ?>
		<th data-name="issuedamount" class="<?php echo $vloanissued_list->issuedamount->headerCellClass() ?>"><div id="elh_vloanissued_issuedamount" class="vloanissued_issuedamount"><div class="ew-table-header-caption"><?php echo $vloanissued_list->issuedamount->caption() ?></div></div></th>
	<?php } else { ?>
		<th data-name="issuedamount" class="<?php echo $vloanissued_list->issuedamount->headerCellClass() ?>"><div class="ew-pointer" onclick="ew.sort(event, '<?php echo $vloanissued_list->SortUrl($vloanissued_list->issuedamount) ?>', 1);"><div id="elh_vloanissued_issuedamount" class="vloanissued_issuedamount">
			<div class="ew-table-header-btn"><span class="ew-table-header-caption"><?php echo $vloanissued_list->issuedamount->caption() ?></span><span class="ew-table-header-sort"><?php if ($vloanissued_list->issuedamount->getSort() == "ASC") { ?><i class="fas fa-sort-up"></i><?php } elseif ($vloanissued_list->issuedamount->getSort() == "DESC") { ?><i class="fas fa-sort-down"></i><?php } ?></span></div>
		</div></div></th>
	<?php } ?>
<?php } ?>
<?php if ($vloanissued_list->externalrefno->Visible) { // externalrefno ?>
	<?php if ($vloanissued_list->SortUrl($vloanissued_list->externalrefno) == "") { ?>
		<th data-name="externalrefno" class="<?php echo $vloanissued_list->externalrefno->headerCellClass() ?>"><div id="elh_vloanissued_externalrefno" class="vloanissued_externalrefno"><div class="ew-table-header-caption"><?php echo $vloanissued_list->externalrefno->caption() ?></div></div></th>
	<?php } else { ?>
		<th data-name="externalrefno" class="<?php echo $vloanissued_list->externalrefno->headerCellClass() ?>"><div class="ew-pointer" onclick="ew.sort(event, '<?php echo $vloanissued_list->SortUrl($vloanissued_list->externalrefno) ?>', 1);"><div id="elh_vloanissued_externalrefno" class="vloanissued_externalrefno">
			<div class="ew-table-header-btn"><span class="ew-table-header-caption"><?php echo $vloanissued_list->externalrefno->caption() ?><?php echo $Language->phrase("SrchLegend") ?></span><span class="ew-table-header-sort"><?php if ($vloanissued_list->externalrefno->getSort() == "ASC") { ?><i class="fas fa-sort-up"></i><?php } elseif ($vloanissued_list->externalrefno->getSort() == "DESC") { ?><i class="fas fa-sort-down"></i><?php } ?></span></div>
		</div></div></th>
	<?php } ?>
<?php } ?>
<?php if ($vloanissued_list->fullypaidind->Visible) { // fullypaidind ?>
	<?php if ($vloanissued_list->SortUrl($vloanissued_list->fullypaidind) == "") { ?>
		<th data-name="fullypaidind" class="<?php echo $vloanissued_list->fullypaidind->headerCellClass() ?>"><div id="elh_vloanissued_fullypaidind" class="vloanissued_fullypaidind"><div class="ew-table-header-caption"><?php echo $vloanissued_list->fullypaidind->caption() ?></div></div></th>
	<?php } else { ?>
		<th data-name="fullypaidind" class="<?php echo $vloanissued_list->fullypaidind->headerCellClass() ?>"><div class="ew-pointer" onclick="ew.sort(event, '<?php echo $vloanissued_list->SortUrl($vloanissued_list->fullypaidind) ?>', 1);"><div id="elh_vloanissued_fullypaidind" class="vloanissued_fullypaidind">
			<div class="ew-table-header-btn"><span class="ew-table-header-caption"><?php echo $vloanissued_list->fullypaidind->caption() ?></span><span class="ew-table-header-sort"><?php if ($vloanissued_list->fullypaidind->getSort() == "ASC") { ?><i class="fas fa-sort-up"></i><?php } elseif ($vloanissued_list->fullypaidind->getSort() == "DESC") { ?><i class="fas fa-sort-down"></i><?php } ?></span></div>
		</div></div></th>
	<?php } ?>
<?php } ?>
<?php if ($vloanissued_list->feeperc->Visible) { // feeperc ?>
	<?php if ($vloanissued_list->SortUrl($vloanissued_list->feeperc) == "") { ?>
		<th data-name="feeperc" class="<?php echo $vloanissued_list->feeperc->headerCellClass() ?>"><div id="elh_vloanissued_feeperc" class="vloanissued_feeperc"><div class="ew-table-header-caption"><?php echo $vloanissued_list->feeperc->caption() ?></div></div></th>
	<?php } else { ?>
		<th data-name="feeperc" class="<?php echo $vloanissued_list->feeperc->headerCellClass() ?>"><div class="ew-pointer" onclick="ew.sort(event, '<?php echo $vloanissued_list->SortUrl($vloanissued_list->feeperc) ?>', 1);"><div id="elh_vloanissued_feeperc" class="vloanissued_feeperc">
			<div class="ew-table-header-btn"><span class="ew-table-header-caption"><?php echo $vloanissued_list->feeperc->caption() ?></span><span class="ew-table-header-sort"><?php if ($vloanissued_list->feeperc->getSort() == "ASC") { ?><i class="fas fa-sort-up"></i><?php } elseif ($vloanissued_list->feeperc->getSort() == "DESC") { ?><i class="fas fa-sort-down"></i><?php } ?></span></div>
		</div></div></th>
	<?php } ?>
<?php } ?>
<?php if ($vloanissued_list->feefixed->Visible) { // feefixed ?>
	<?php if ($vloanissued_list->SortUrl($vloanissued_list->feefixed) == "") { ?>
		<th data-name="feefixed" class="<?php echo $vloanissued_list->feefixed->headerCellClass() ?>"><div id="elh_vloanissued_feefixed" class="vloanissued_feefixed"><div class="ew-table-header-caption"><?php echo $vloanissued_list->feefixed->caption() ?></div></div></th>
	<?php } else { ?>
		<th data-name="feefixed" class="<?php echo $vloanissued_list->feefixed->headerCellClass() ?>"><div class="ew-pointer" onclick="ew.sort(event, '<?php echo $vloanissued_list->SortUrl($vloanissued_list->feefixed) ?>', 1);"><div id="elh_vloanissued_feefixed" class="vloanissued_feefixed">
			<div class="ew-table-header-btn"><span class="ew-table-header-caption"><?php echo $vloanissued_list->feefixed->caption() ?></span><span class="ew-table-header-sort"><?php if ($vloanissued_list->feefixed->getSort() == "ASC") { ?><i class="fas fa-sort-up"></i><?php } elseif ($vloanissued_list->feefixed->getSort() == "DESC") { ?><i class="fas fa-sort-down"></i><?php } ?></span></div>
		</div></div></th>
	<?php } ?>
<?php } ?>
<?php if ($vloanissued_list->feeamount->Visible) { // feeamount ?>
	<?php if ($vloanissued_list->SortUrl($vloanissued_list->feeamount) == "") { ?>
		<th data-name="feeamount" class="<?php echo $vloanissued_list->feeamount->headerCellClass() ?>"><div id="elh_vloanissued_feeamount" class="vloanissued_feeamount"><div class="ew-table-header-caption"><?php echo $vloanissued_list->feeamount->caption() ?></div></div></th>
	<?php } else { ?>
		<th data-name="feeamount" class="<?php echo $vloanissued_list->feeamount->headerCellClass() ?>"><div class="ew-pointer" onclick="ew.sort(event, '<?php echo $vloanissued_list->SortUrl($vloanissued_list->feeamount) ?>', 1);"><div id="elh_vloanissued_feeamount" class="vloanissued_feeamount">
			<div class="ew-table-header-btn"><span class="ew-table-header-caption"><?php echo $vloanissued_list->feeamount->caption() ?></span><span class="ew-table-header-sort"><?php if ($vloanissued_list->feeamount->getSort() == "ASC") { ?><i class="fas fa-sort-up"></i><?php } elseif ($vloanissued_list->feeamount->getSort() == "DESC") { ?><i class="fas fa-sort-down"></i><?php } ?></span></div>
		</div></div></th>
	<?php } ?>
<?php } ?>
<?php if ($vloanissued_list->taxperc->Visible) { // taxperc ?>
	<?php if ($vloanissued_list->SortUrl($vloanissued_list->taxperc) == "") { ?>
		<th data-name="taxperc" class="<?php echo $vloanissued_list->taxperc->headerCellClass() ?>"><div id="elh_vloanissued_taxperc" class="vloanissued_taxperc"><div class="ew-table-header-caption"><?php echo $vloanissued_list->taxperc->caption() ?></div></div></th>
	<?php } else { ?>
		<th data-name="taxperc" class="<?php echo $vloanissued_list->taxperc->headerCellClass() ?>"><div class="ew-pointer" onclick="ew.sort(event, '<?php echo $vloanissued_list->SortUrl($vloanissued_list->taxperc) ?>', 1);"><div id="elh_vloanissued_taxperc" class="vloanissued_taxperc">
			<div class="ew-table-header-btn"><span class="ew-table-header-caption"><?php echo $vloanissued_list->taxperc->caption() ?></span><span class="ew-table-header-sort"><?php if ($vloanissued_list->taxperc->getSort() == "ASC") { ?><i class="fas fa-sort-up"></i><?php } elseif ($vloanissued_list->taxperc->getSort() == "DESC") { ?><i class="fas fa-sort-down"></i><?php } ?></span></div>
		</div></div></th>
	<?php } ?>
<?php } ?>
<?php if ($vloanissued_list->taxamount->Visible) { // taxamount ?>
	<?php if ($vloanissued_list->SortUrl($vloanissued_list->taxamount) == "") { ?>
		<th data-name="taxamount" class="<?php echo $vloanissued_list->taxamount->headerCellClass() ?>"><div id="elh_vloanissued_taxamount" class="vloanissued_taxamount"><div class="ew-table-header-caption"><?php echo $vloanissued_list->taxamount->caption() ?></div></div></th>
	<?php } else { ?>
		<th data-name="taxamount" class="<?php echo $vloanissued_list->taxamount->headerCellClass() ?>"><div class="ew-pointer" onclick="ew.sort(event, '<?php echo $vloanissued_list->SortUrl($vloanissued_list->taxamount) ?>', 1);"><div id="elh_vloanissued_taxamount" class="vloanissued_taxamount">
			<div class="ew-table-header-btn"><span class="ew-table-header-caption"><?php echo $vloanissued_list->taxamount->caption() ?></span><span class="ew-table-header-sort"><?php if ($vloanissued_list->taxamount->getSort() == "ASC") { ?><i class="fas fa-sort-up"></i><?php } elseif ($vloanissued_list->taxamount->getSort() == "DESC") { ?><i class="fas fa-sort-down"></i><?php } ?></span></div>
		</div></div></th>
	<?php } ?>
<?php } ?>
<?php if ($vloanissued_list->totalfees->Visible) { // totalfees ?>
	<?php if ($vloanissued_list->SortUrl($vloanissued_list->totalfees) == "") { ?>
		<th data-name="totalfees" class="<?php echo $vloanissued_list->totalfees->headerCellClass() ?>"><div id="elh_vloanissued_totalfees" class="vloanissued_totalfees"><div class="ew-table-header-caption"><?php echo $vloanissued_list->totalfees->caption() ?></div></div></th>
	<?php } else { ?>
		<th data-name="totalfees" class="<?php echo $vloanissued_list->totalfees->headerCellClass() ?>"><div class="ew-pointer" onclick="ew.sort(event, '<?php echo $vloanissued_list->SortUrl($vloanissued_list->totalfees) ?>', 1);"><div id="elh_vloanissued_totalfees" class="vloanissued_totalfees">
			<div class="ew-table-header-btn"><span class="ew-table-header-caption"><?php echo $vloanissued_list->totalfees->caption() ?></span><span class="ew-table-header-sort"><?php if ($vloanissued_list->totalfees->getSort() == "ASC") { ?><i class="fas fa-sort-up"></i><?php } elseif ($vloanissued_list->totalfees->getSort() == "DESC") { ?><i class="fas fa-sort-down"></i><?php } ?></span></div>
		</div></div></th>
	<?php } ?>
<?php } ?>
<?php if ($vloanissued_list->totalamount->Visible) { // totalamount ?>
	<?php if ($vloanissued_list->SortUrl($vloanissued_list->totalamount) == "") { ?>
		<th data-name="totalamount" class="<?php echo $vloanissued_list->totalamount->headerCellClass() ?>"><div id="elh_vloanissued_totalamount" class="vloanissued_totalamount"><div class="ew-table-header-caption"><?php echo $vloanissued_list->totalamount->caption() ?></div></div></th>
	<?php } else { ?>
		<th data-name="totalamount" class="<?php echo $vloanissued_list->totalamount->headerCellClass() ?>"><div class="ew-pointer" onclick="ew.sort(event, '<?php echo $vloanissued_list->SortUrl($vloanissued_list->totalamount) ?>', 1);"><div id="elh_vloanissued_totalamount" class="vloanissued_totalamount">
			<div class="ew-table-header-btn"><span class="ew-table-header-caption"><?php echo $vloanissued_list->totalamount->caption() ?></span><span class="ew-table-header-sort"><?php if ($vloanissued_list->totalamount->getSort() == "ASC") { ?><i class="fas fa-sort-up"></i><?php } elseif ($vloanissued_list->totalamount->getSort() == "DESC") { ?><i class="fas fa-sort-down"></i><?php } ?></span></div>
		</div></div></th>
	<?php } ?>
<?php } ?>
<?php if ($vloanissued_list->paymenttargetdate->Visible) { // paymenttargetdate ?>
	<?php if ($vloanissued_list->SortUrl($vloanissued_list->paymenttargetdate) == "") { ?>
		<th data-name="paymenttargetdate" class="<?php echo $vloanissued_list->paymenttargetdate->headerCellClass() ?>"><div id="elh_vloanissued_paymenttargetdate" class="vloanissued_paymenttargetdate"><div class="ew-table-header-caption"><?php echo $vloanissued_list->paymenttargetdate->caption() ?></div></div></th>
	<?php } else { ?>
		<th data-name="paymenttargetdate" class="<?php echo $vloanissued_list->paymenttargetdate->headerCellClass() ?>"><div class="ew-pointer" onclick="ew.sort(event, '<?php echo $vloanissued_list->SortUrl($vloanissued_list->paymenttargetdate) ?>', 1);"><div id="elh_vloanissued_paymenttargetdate" class="vloanissued_paymenttargetdate">
			<div class="ew-table-header-btn"><span class="ew-table-header-caption"><?php echo $vloanissued_list->paymenttargetdate->caption() ?></span><span class="ew-table-header-sort"><?php if ($vloanissued_list->paymenttargetdate->getSort() == "ASC") { ?><i class="fas fa-sort-up"></i><?php } elseif ($vloanissued_list->paymenttargetdate->getSort() == "DESC") { ?><i class="fas fa-sort-down"></i><?php } ?></span></div>
		</div></div></th>
	<?php } ?>
<?php } ?>
<?php if ($vloanissued_list->approveruserid->Visible) { // approveruserid ?>
	<?php if ($vloanissued_list->SortUrl($vloanissued_list->approveruserid) == "") { ?>
		<th data-name="approveruserid" class="<?php echo $vloanissued_list->approveruserid->headerCellClass() ?>"><div id="elh_vloanissued_approveruserid" class="vloanissued_approveruserid"><div class="ew-table-header-caption"><?php echo $vloanissued_list->approveruserid->caption() ?></div></div></th>
	<?php } else { ?>
		<th data-name="approveruserid" class="<?php echo $vloanissued_list->approveruserid->headerCellClass() ?>"><div class="ew-pointer" onclick="ew.sort(event, '<?php echo $vloanissued_list->SortUrl($vloanissued_list->approveruserid) ?>', 1);"><div id="elh_vloanissued_approveruserid" class="vloanissued_approveruserid">
			<div class="ew-table-header-btn"><span class="ew-table-header-caption"><?php echo $vloanissued_list->approveruserid->caption() ?></span><span class="ew-table-header-sort"><?php if ($vloanissued_list->approveruserid->getSort() == "ASC") { ?><i class="fas fa-sort-up"></i><?php } elseif ($vloanissued_list->approveruserid->getSort() == "DESC") { ?><i class="fas fa-sort-down"></i><?php } ?></span></div>
		</div></div></th>
	<?php } ?>
<?php } ?>
<?php if ($vloanissued_list->docid->Visible) { // docid ?>
	<?php if ($vloanissued_list->SortUrl($vloanissued_list->docid) == "") { ?>
		<th data-name="docid" class="<?php echo $vloanissued_list->docid->headerCellClass() ?>"><div id="elh_vloanissued_docid" class="vloanissued_docid"><div class="ew-table-header-caption"><?php echo $vloanissued_list->docid->caption() ?></div></div></th>
	<?php } else { ?>
		<th data-name="docid" class="<?php echo $vloanissued_list->docid->headerCellClass() ?>"><div class="ew-pointer" onclick="ew.sort(event, '<?php echo $vloanissued_list->SortUrl($vloanissued_list->docid) ?>', 1);"><div id="elh_vloanissued_docid" class="vloanissued_docid">
			<div class="ew-table-header-btn"><span class="ew-table-header-caption"><?php echo $vloanissued_list->docid->caption() ?><?php echo $Language->phrase("SrchLegend") ?></span><span class="ew-table-header-sort"><?php if ($vloanissued_list->docid->getSort() == "ASC") { ?><i class="fas fa-sort-up"></i><?php } elseif ($vloanissued_list->docid->getSort() == "DESC") { ?><i class="fas fa-sort-down"></i><?php } ?></span></div>
		</div></div></th>
	<?php } ?>
<?php } ?>
<?php if ($vloanissued_list->feesystemtotal->Visible) { // feesystemtotal ?>
	<?php if ($vloanissued_list->SortUrl($vloanissued_list->feesystemtotal) == "") { ?>
		<th data-name="feesystemtotal" class="<?php echo $vloanissued_list->feesystemtotal->headerCellClass() ?>"><div id="elh_vloanissued_feesystemtotal" class="vloanissued_feesystemtotal"><div class="ew-table-header-caption"><?php echo $vloanissued_list->feesystemtotal->caption() ?></div></div></th>
	<?php } else { ?>
		<th data-name="feesystemtotal" class="<?php echo $vloanissued_list->feesystemtotal->headerCellClass() ?>"><div class="ew-pointer" onclick="ew.sort(event, '<?php echo $vloanissued_list->SortUrl($vloanissued_list->feesystemtotal) ?>', 1);"><div id="elh_vloanissued_feesystemtotal" class="vloanissued_feesystemtotal">
			<div class="ew-table-header-btn"><span class="ew-table-header-caption"><?php echo $vloanissued_list->feesystemtotal->caption() ?></span><span class="ew-table-header-sort"><?php if ($vloanissued_list->feesystemtotal->getSort() == "ASC") { ?><i class="fas fa-sort-up"></i><?php } elseif ($vloanissued_list->feesystemtotal->getSort() == "DESC") { ?><i class="fas fa-sort-down"></i><?php } ?></span></div>
		</div></div></th>
	<?php } ?>
<?php } ?>
<?php if ($vloanissued_list->feeexternaltotal->Visible) { // feeexternaltotal ?>
	<?php if ($vloanissued_list->SortUrl($vloanissued_list->feeexternaltotal) == "") { ?>
		<th data-name="feeexternaltotal" class="<?php echo $vloanissued_list->feeexternaltotal->headerCellClass() ?>"><div id="elh_vloanissued_feeexternaltotal" class="vloanissued_feeexternaltotal"><div class="ew-table-header-caption"><?php echo $vloanissued_list->feeexternaltotal->caption() ?></div></div></th>
	<?php } else { ?>
		<th data-name="feeexternaltotal" class="<?php echo $vloanissued_list->feeexternaltotal->headerCellClass() ?>"><div class="ew-pointer" onclick="ew.sort(event, '<?php echo $vloanissued_list->SortUrl($vloanissued_list->feeexternaltotal) ?>', 1);"><div id="elh_vloanissued_feeexternaltotal" class="vloanissued_feeexternaltotal">
			<div class="ew-table-header-btn"><span class="ew-table-header-caption"><?php echo $vloanissued_list->feeexternaltotal->caption() ?></span><span class="ew-table-header-sort"><?php if ($vloanissued_list->feeexternaltotal->getSort() == "ASC") { ?><i class="fas fa-sort-up"></i><?php } elseif ($vloanissued_list->feeexternaltotal->getSort() == "DESC") { ?><i class="fas fa-sort-down"></i><?php } ?></span></div>
		</div></div></th>
	<?php } ?>
<?php } ?>
<?php if ($vloanissued_list->feefranchiseetotal->Visible) { // feefranchiseetotal ?>
	<?php if ($vloanissued_list->SortUrl($vloanissued_list->feefranchiseetotal) == "") { ?>
		<th data-name="feefranchiseetotal" class="<?php echo $vloanissued_list->feefranchiseetotal->headerCellClass() ?>"><div id="elh_vloanissued_feefranchiseetotal" class="vloanissued_feefranchiseetotal"><div class="ew-table-header-caption"><?php echo $vloanissued_list->feefranchiseetotal->caption() ?></div></div></th>
	<?php } else { ?>
		<th data-name="feefranchiseetotal" class="<?php echo $vloanissued_list->feefranchiseetotal->headerCellClass() ?>"><div class="ew-pointer" onclick="ew.sort(event, '<?php echo $vloanissued_list->SortUrl($vloanissued_list->feefranchiseetotal) ?>', 1);"><div id="elh_vloanissued_feefranchiseetotal" class="vloanissued_feefranchiseetotal">
			<div class="ew-table-header-btn"><span class="ew-table-header-caption"><?php echo $vloanissued_list->feefranchiseetotal->caption() ?></span><span class="ew-table-header-sort"><?php if ($vloanissued_list->feefranchiseetotal->getSort() == "ASC") { ?><i class="fas fa-sort-up"></i><?php } elseif ($vloanissued_list->feefranchiseetotal->getSort() == "DESC") { ?><i class="fas fa-sort-down"></i><?php } ?></span></div>
		</div></div></th>
	<?php } ?>
<?php } ?>
<?php if ($vloanissued_list->feeresellertotal->Visible) { // feeresellertotal ?>
	<?php if ($vloanissued_list->SortUrl($vloanissued_list->feeresellertotal) == "") { ?>
		<th data-name="feeresellertotal" class="<?php echo $vloanissued_list->feeresellertotal->headerCellClass() ?>"><div id="elh_vloanissued_feeresellertotal" class="vloanissued_feeresellertotal"><div class="ew-table-header-caption"><?php echo $vloanissued_list->feeresellertotal->caption() ?></div></div></th>
	<?php } else { ?>
		<th data-name="feeresellertotal" class="<?php echo $vloanissued_list->feeresellertotal->headerCellClass() ?>"><div class="ew-pointer" onclick="ew.sort(event, '<?php echo $vloanissued_list->SortUrl($vloanissued_list->feeresellertotal) ?>', 1);"><div id="elh_vloanissued_feeresellertotal" class="vloanissued_feeresellertotal">
			<div class="ew-table-header-btn"><span class="ew-table-header-caption"><?php echo $vloanissued_list->feeresellertotal->caption() ?></span><span class="ew-table-header-sort"><?php if ($vloanissued_list->feeresellertotal->getSort() == "ASC") { ?><i class="fas fa-sort-up"></i><?php } elseif ($vloanissued_list->feeresellertotal->getSort() == "DESC") { ?><i class="fas fa-sort-down"></i><?php } ?></span></div>
		</div></div></th>
	<?php } ?>
<?php } ?>
<?php if ($vloanissued_list->purchasefeeid->Visible) { // purchasefeeid ?>
	<?php if ($vloanissued_list->SortUrl($vloanissued_list->purchasefeeid) == "") { ?>
		<th data-name="purchasefeeid" class="<?php echo $vloanissued_list->purchasefeeid->headerCellClass() ?>"><div id="elh_vloanissued_purchasefeeid" class="vloanissued_purchasefeeid"><div class="ew-table-header-caption"><?php echo $vloanissued_list->purchasefeeid->caption() ?></div></div></th>
	<?php } else { ?>
		<th data-name="purchasefeeid" class="<?php echo $vloanissued_list->purchasefeeid->headerCellClass() ?>"><div class="ew-pointer" onclick="ew.sort(event, '<?php echo $vloanissued_list->SortUrl($vloanissued_list->purchasefeeid) ?>', 1);"><div id="elh_vloanissued_purchasefeeid" class="vloanissued_purchasefeeid">
			<div class="ew-table-header-btn"><span class="ew-table-header-caption"><?php echo $vloanissued_list->purchasefeeid->caption() ?></span><span class="ew-table-header-sort"><?php if ($vloanissued_list->purchasefeeid->getSort() == "ASC") { ?><i class="fas fa-sort-up"></i><?php } elseif ($vloanissued_list->purchasefeeid->getSort() == "DESC") { ?><i class="fas fa-sort-down"></i><?php } ?></span></div>
		</div></div></th>
	<?php } ?>
<?php } ?>
<?php if ($vloanissued_list->cancellationrefid->Visible) { // cancellationrefid ?>
	<?php if ($vloanissued_list->SortUrl($vloanissued_list->cancellationrefid) == "") { ?>
		<th data-name="cancellationrefid" class="<?php echo $vloanissued_list->cancellationrefid->headerCellClass() ?>"><div id="elh_vloanissued_cancellationrefid" class="vloanissued_cancellationrefid"><div class="ew-table-header-caption"><?php echo $vloanissued_list->cancellationrefid->caption() ?></div></div></th>
	<?php } else { ?>
		<th data-name="cancellationrefid" class="<?php echo $vloanissued_list->cancellationrefid->headerCellClass() ?>"><div class="ew-pointer" onclick="ew.sort(event, '<?php echo $vloanissued_list->SortUrl($vloanissued_list->cancellationrefid) ?>', 1);"><div id="elh_vloanissued_cancellationrefid" class="vloanissued_cancellationrefid">
			<div class="ew-table-header-btn"><span class="ew-table-header-caption"><?php echo $vloanissued_list->cancellationrefid->caption() ?><?php echo $Language->phrase("SrchLegend") ?></span><span class="ew-table-header-sort"><?php if ($vloanissued_list->cancellationrefid->getSort() == "ASC") { ?><i class="fas fa-sort-up"></i><?php } elseif ($vloanissued_list->cancellationrefid->getSort() == "DESC") { ?><i class="fas fa-sort-down"></i><?php } ?></span></div>
		</div></div></th>
	<?php } ?>
<?php } ?>
<?php if ($vloanissued_list->cancellationdatetime->Visible) { // cancellationdatetime ?>
	<?php if ($vloanissued_list->SortUrl($vloanissued_list->cancellationdatetime) == "") { ?>
		<th data-name="cancellationdatetime" class="<?php echo $vloanissued_list->cancellationdatetime->headerCellClass() ?>"><div id="elh_vloanissued_cancellationdatetime" class="vloanissued_cancellationdatetime"><div class="ew-table-header-caption"><?php echo $vloanissued_list->cancellationdatetime->caption() ?></div></div></th>
	<?php } else { ?>
		<th data-name="cancellationdatetime" class="<?php echo $vloanissued_list->cancellationdatetime->headerCellClass() ?>"><div class="ew-pointer" onclick="ew.sort(event, '<?php echo $vloanissued_list->SortUrl($vloanissued_list->cancellationdatetime) ?>', 1);"><div id="elh_vloanissued_cancellationdatetime" class="vloanissued_cancellationdatetime">
			<div class="ew-table-header-btn"><span class="ew-table-header-caption"><?php echo $vloanissued_list->cancellationdatetime->caption() ?></span><span class="ew-table-header-sort"><?php if ($vloanissued_list->cancellationdatetime->getSort() == "ASC") { ?><i class="fas fa-sort-up"></i><?php } elseif ($vloanissued_list->cancellationdatetime->getSort() == "DESC") { ?><i class="fas fa-sort-down"></i><?php } ?></span></div>
		</div></div></th>
	<?php } ?>
<?php } ?>
<?php if ($vloanissued_list->cancellationreason->Visible) { // cancellationreason ?>
	<?php if ($vloanissued_list->SortUrl($vloanissued_list->cancellationreason) == "") { ?>
		<th data-name="cancellationreason" class="<?php echo $vloanissued_list->cancellationreason->headerCellClass() ?>"><div id="elh_vloanissued_cancellationreason" class="vloanissued_cancellationreason"><div class="ew-table-header-caption"><?php echo $vloanissued_list->cancellationreason->caption() ?></div></div></th>
	<?php } else { ?>
		<th data-name="cancellationreason" class="<?php echo $vloanissued_list->cancellationreason->headerCellClass() ?>"><div class="ew-pointer" onclick="ew.sort(event, '<?php echo $vloanissued_list->SortUrl($vloanissued_list->cancellationreason) ?>', 1);"><div id="elh_vloanissued_cancellationreason" class="vloanissued_cancellationreason">
			<div class="ew-table-header-btn"><span class="ew-table-header-caption"><?php echo $vloanissued_list->cancellationreason->caption() ?><?php echo $Language->phrase("SrchLegend") ?></span><span class="ew-table-header-sort"><?php if ($vloanissued_list->cancellationreason->getSort() == "ASC") { ?><i class="fas fa-sort-up"></i><?php } elseif ($vloanissued_list->cancellationreason->getSort() == "DESC") { ?><i class="fas fa-sort-down"></i><?php } ?></span></div>
		</div></div></th>
	<?php } ?>
<?php } ?>
<?php if ($vloanissued_list->bankcode->Visible) { // bankcode ?>
	<?php if ($vloanissued_list->SortUrl($vloanissued_list->bankcode) == "") { ?>
		<th data-name="bankcode" class="<?php echo $vloanissued_list->bankcode->headerCellClass() ?>"><div id="elh_vloanissued_bankcode" class="vloanissued_bankcode"><div class="ew-table-header-caption"><?php echo $vloanissued_list->bankcode->caption() ?></div></div></th>
	<?php } else { ?>
		<th data-name="bankcode" class="<?php echo $vloanissued_list->bankcode->headerCellClass() ?>"><div class="ew-pointer" onclick="ew.sort(event, '<?php echo $vloanissued_list->SortUrl($vloanissued_list->bankcode) ?>', 1);"><div id="elh_vloanissued_bankcode" class="vloanissued_bankcode">
			<div class="ew-table-header-btn"><span class="ew-table-header-caption"><?php echo $vloanissued_list->bankcode->caption() ?><?php echo $Language->phrase("SrchLegend") ?></span><span class="ew-table-header-sort"><?php if ($vloanissued_list->bankcode->getSort() == "ASC") { ?><i class="fas fa-sort-up"></i><?php } elseif ($vloanissued_list->bankcode->getSort() == "DESC") { ?><i class="fas fa-sort-down"></i><?php } ?></span></div>
		</div></div></th>
	<?php } ?>
<?php } ?>
<?php

// Render list options (header, right)
$vloanissued_list->ListOptions->render("header", "right");
?>
	</tr>
</thead>
<tbody>
<?php
if ($vloanissued_list->ExportAll && $vloanissued_list->isExport()) {
	$vloanissued_list->StopRecord = $vloanissued_list->TotalRecords;
} else {

	// Set the last record to display
	if ($vloanissued_list->TotalRecords > $vloanissued_list->StartRecord + $vloanissued_list->DisplayRecords - 1)
		$vloanissued_list->StopRecord = $vloanissued_list->StartRecord + $vloanissued_list->DisplayRecords - 1;
	else
		$vloanissued_list->StopRecord = $vloanissued_list->TotalRecords;
}
$vloanissued_list->RecordCount = $vloanissued_list->StartRecord - 1;
if ($vloanissued_list->Recordset && !$vloanissued_list->Recordset->EOF) {
	$vloanissued_list->Recordset->moveFirst();
	$selectLimit = $vloanissued_list->UseSelectLimit;
	if (!$selectLimit && $vloanissued_list->StartRecord > 1)
		$vloanissued_list->Recordset->move($vloanissued_list->StartRecord - 1);
} elseif (!$vloanissued->AllowAddDeleteRow && $vloanissued_list->StopRecord == 0) {
	$vloanissued_list->StopRecord = $vloanissued->GridAddRowCount;
}

// Initialize aggregate
$vloanissued->RowType = ROWTYPE_AGGREGATEINIT;
$vloanissued->resetAttributes();
$vloanissued_list->renderRow();
while ($vloanissued_list->RecordCount < $vloanissued_list->StopRecord) {
	$vloanissued_list->RecordCount++;
	if ($vloanissued_list->RecordCount >= $vloanissued_list->StartRecord) {
		$vloanissued_list->RowCount++;

		// Set up key count
		$vloanissued_list->KeyCount = $vloanissued_list->RowIndex;

		// Init row class and style
		$vloanissued->resetAttributes();
		$vloanissued->CssClass = "";
		if ($vloanissued_list->isGridAdd()) {
		} else {
			$vloanissued_list->loadRowValues($vloanissued_list->Recordset); // Load row values
		}
		$vloanissued->RowType = ROWTYPE_VIEW; // Render view

		// Set up row id / data-rowindex
		$vloanissued->RowAttrs->merge(["data-rowindex" => $vloanissued_list->RowCount, "id" => "r" . $vloanissued_list->RowCount . "_vloanissued", "data-rowtype" => $vloanissued->RowType]);

		// Render row
		$vloanissued_list->renderRow();

		// Render list options
		$vloanissued_list->renderListOptions();
?>
	<tr <?php echo $vloanissued->rowAttributes() ?>>
<?php

// Render list options (body, left)
$vloanissued_list->ListOptions->render("body", "left", $vloanissued_list->RowCount);
?>
	<?php if ($vloanissued_list->loanid->Visible) { // loanid ?>
		<td data-name="loanid" <?php echo $vloanissued_list->loanid->cellAttributes() ?>>
<span id="el<?php echo $vloanissued_list->RowCount ?>_vloanissued_loanid">
<span<?php echo $vloanissued_list->loanid->viewAttributes() ?>><?php echo $vloanissued_list->loanid->getViewValue() ?></span>
</span>
</td>
	<?php } ?>
	<?php if ($vloanissued_list->_userid->Visible) { // userid ?>
		<td data-name="_userid" <?php echo $vloanissued_list->_userid->cellAttributes() ?>>
<span id="el<?php echo $vloanissued_list->RowCount ?>_vloanissued__userid">
<span<?php echo $vloanissued_list->_userid->viewAttributes() ?>><?php echo $vloanissued_list->_userid->getViewValue() ?></span>
</span>
</td>
	<?php } ?>
	<?php if ($vloanissued_list->emailAccount->Visible) { // emailAccount ?>
		<td data-name="emailAccount" <?php echo $vloanissued_list->emailAccount->cellAttributes() ?>>
<span id="el<?php echo $vloanissued_list->RowCount ?>_vloanissued_emailAccount">
<span<?php echo $vloanissued_list->emailAccount->viewAttributes() ?>><?php echo $vloanissued_list->emailAccount->getViewValue() ?></span>
</span>
</td>
	<?php } ?>
	<?php if ($vloanissued_list->issueddate->Visible) { // issueddate ?>
		<td data-name="issueddate" <?php echo $vloanissued_list->issueddate->cellAttributes() ?>>
<span id="el<?php echo $vloanissued_list->RowCount ?>_vloanissued_issueddate">
<span<?php echo $vloanissued_list->issueddate->viewAttributes() ?>><?php echo $vloanissued_list->issueddate->getViewValue() ?></span>
</span>
</td>
	<?php } ?>
	<?php if ($vloanissued_list->currcode->Visible) { // currcode ?>
		<td data-name="currcode" <?php echo $vloanissued_list->currcode->cellAttributes() ?>>
<span id="el<?php echo $vloanissued_list->RowCount ?>_vloanissued_currcode">
<span<?php echo $vloanissued_list->currcode->viewAttributes() ?>><?php echo $vloanissued_list->currcode->getViewValue() ?></span>
</span>
</td>
	<?php } ?>
	<?php if ($vloanissued_list->issuedamount->Visible) { // issuedamount ?>
		<td data-name="issuedamount" <?php echo $vloanissued_list->issuedamount->cellAttributes() ?>>
<span id="el<?php echo $vloanissued_list->RowCount ?>_vloanissued_issuedamount">
<span<?php echo $vloanissued_list->issuedamount->viewAttributes() ?>><?php echo $vloanissued_list->issuedamount->getViewValue() ?></span>
</span>
</td>
	<?php } ?>
	<?php if ($vloanissued_list->externalrefno->Visible) { // externalrefno ?>
		<td data-name="externalrefno" <?php echo $vloanissued_list->externalrefno->cellAttributes() ?>>
<span id="el<?php echo $vloanissued_list->RowCount ?>_vloanissued_externalrefno">
<span<?php echo $vloanissued_list->externalrefno->viewAttributes() ?>><?php echo $vloanissued_list->externalrefno->getViewValue() ?></span>
</span>
</td>
	<?php } ?>
	<?php if ($vloanissued_list->fullypaidind->Visible) { // fullypaidind ?>
		<td data-name="fullypaidind" <?php echo $vloanissued_list->fullypaidind->cellAttributes() ?>>
<span id="el<?php echo $vloanissued_list->RowCount ?>_vloanissued_fullypaidind">
<span<?php echo $vloanissued_list->fullypaidind->viewAttributes() ?>><?php echo $vloanissued_list->fullypaidind->getViewValue() ?></span>
</span>
</td>
	<?php } ?>
	<?php if ($vloanissued_list->feeperc->Visible) { // feeperc ?>
		<td data-name="feeperc" <?php echo $vloanissued_list->feeperc->cellAttributes() ?>>
<span id="el<?php echo $vloanissued_list->RowCount ?>_vloanissued_feeperc">
<span<?php echo $vloanissued_list->feeperc->viewAttributes() ?>><?php echo $vloanissued_list->feeperc->getViewValue() ?></span>
</span>
</td>
	<?php } ?>
	<?php if ($vloanissued_list->feefixed->Visible) { // feefixed ?>
		<td data-name="feefixed" <?php echo $vloanissued_list->feefixed->cellAttributes() ?>>
<span id="el<?php echo $vloanissued_list->RowCount ?>_vloanissued_feefixed">
<span<?php echo $vloanissued_list->feefixed->viewAttributes() ?>><?php echo $vloanissued_list->feefixed->getViewValue() ?></span>
</span>
</td>
	<?php } ?>
	<?php if ($vloanissued_list->feeamount->Visible) { // feeamount ?>
		<td data-name="feeamount" <?php echo $vloanissued_list->feeamount->cellAttributes() ?>>
<span id="el<?php echo $vloanissued_list->RowCount ?>_vloanissued_feeamount">
<span<?php echo $vloanissued_list->feeamount->viewAttributes() ?>><?php echo $vloanissued_list->feeamount->getViewValue() ?></span>
</span>
</td>
	<?php } ?>
	<?php if ($vloanissued_list->taxperc->Visible) { // taxperc ?>
		<td data-name="taxperc" <?php echo $vloanissued_list->taxperc->cellAttributes() ?>>
<span id="el<?php echo $vloanissued_list->RowCount ?>_vloanissued_taxperc">
<span<?php echo $vloanissued_list->taxperc->viewAttributes() ?>><?php echo $vloanissued_list->taxperc->getViewValue() ?></span>
</span>
</td>
	<?php } ?>
	<?php if ($vloanissued_list->taxamount->Visible) { // taxamount ?>
		<td data-name="taxamount" <?php echo $vloanissued_list->taxamount->cellAttributes() ?>>
<span id="el<?php echo $vloanissued_list->RowCount ?>_vloanissued_taxamount">
<span<?php echo $vloanissued_list->taxamount->viewAttributes() ?>><?php echo $vloanissued_list->taxamount->getViewValue() ?></span>
</span>
</td>
	<?php } ?>
	<?php if ($vloanissued_list->totalfees->Visible) { // totalfees ?>
		<td data-name="totalfees" <?php echo $vloanissued_list->totalfees->cellAttributes() ?>>
<span id="el<?php echo $vloanissued_list->RowCount ?>_vloanissued_totalfees">
<span<?php echo $vloanissued_list->totalfees->viewAttributes() ?>><?php echo $vloanissued_list->totalfees->getViewValue() ?></span>
</span>
</td>
	<?php } ?>
	<?php if ($vloanissued_list->totalamount->Visible) { // totalamount ?>
		<td data-name="totalamount" <?php echo $vloanissued_list->totalamount->cellAttributes() ?>>
<span id="el<?php echo $vloanissued_list->RowCount ?>_vloanissued_totalamount">
<span<?php echo $vloanissued_list->totalamount->viewAttributes() ?>><?php echo $vloanissued_list->totalamount->getViewValue() ?></span>
</span>
</td>
	<?php } ?>
	<?php if ($vloanissued_list->paymenttargetdate->Visible) { // paymenttargetdate ?>
		<td data-name="paymenttargetdate" <?php echo $vloanissued_list->paymenttargetdate->cellAttributes() ?>>
<span id="el<?php echo $vloanissued_list->RowCount ?>_vloanissued_paymenttargetdate">
<span<?php echo $vloanissued_list->paymenttargetdate->viewAttributes() ?>><?php echo $vloanissued_list->paymenttargetdate->getViewValue() ?></span>
</span>
</td>
	<?php } ?>
	<?php if ($vloanissued_list->approveruserid->Visible) { // approveruserid ?>
		<td data-name="approveruserid" <?php echo $vloanissued_list->approveruserid->cellAttributes() ?>>
<span id="el<?php echo $vloanissued_list->RowCount ?>_vloanissued_approveruserid">
<span<?php echo $vloanissued_list->approveruserid->viewAttributes() ?>><?php echo $vloanissued_list->approveruserid->getViewValue() ?></span>
</span>
</td>
	<?php } ?>
	<?php if ($vloanissued_list->docid->Visible) { // docid ?>
		<td data-name="docid" <?php echo $vloanissued_list->docid->cellAttributes() ?>>
<span id="el<?php echo $vloanissued_list->RowCount ?>_vloanissued_docid">
<span<?php echo $vloanissued_list->docid->viewAttributes() ?>><?php echo $vloanissued_list->docid->getViewValue() ?></span>
</span>
</td>
	<?php } ?>
	<?php if ($vloanissued_list->feesystemtotal->Visible) { // feesystemtotal ?>
		<td data-name="feesystemtotal" <?php echo $vloanissued_list->feesystemtotal->cellAttributes() ?>>
<span id="el<?php echo $vloanissued_list->RowCount ?>_vloanissued_feesystemtotal">
<span<?php echo $vloanissued_list->feesystemtotal->viewAttributes() ?>><?php echo $vloanissued_list->feesystemtotal->getViewValue() ?></span>
</span>
</td>
	<?php } ?>
	<?php if ($vloanissued_list->feeexternaltotal->Visible) { // feeexternaltotal ?>
		<td data-name="feeexternaltotal" <?php echo $vloanissued_list->feeexternaltotal->cellAttributes() ?>>
<span id="el<?php echo $vloanissued_list->RowCount ?>_vloanissued_feeexternaltotal">
<span<?php echo $vloanissued_list->feeexternaltotal->viewAttributes() ?>><?php echo $vloanissued_list->feeexternaltotal->getViewValue() ?></span>
</span>
</td>
	<?php } ?>
	<?php if ($vloanissued_list->feefranchiseetotal->Visible) { // feefranchiseetotal ?>
		<td data-name="feefranchiseetotal" <?php echo $vloanissued_list->feefranchiseetotal->cellAttributes() ?>>
<span id="el<?php echo $vloanissued_list->RowCount ?>_vloanissued_feefranchiseetotal">
<span<?php echo $vloanissued_list->feefranchiseetotal->viewAttributes() ?>><?php echo $vloanissued_list->feefranchiseetotal->getViewValue() ?></span>
</span>
</td>
	<?php } ?>
	<?php if ($vloanissued_list->feeresellertotal->Visible) { // feeresellertotal ?>
		<td data-name="feeresellertotal" <?php echo $vloanissued_list->feeresellertotal->cellAttributes() ?>>
<span id="el<?php echo $vloanissued_list->RowCount ?>_vloanissued_feeresellertotal">
<span<?php echo $vloanissued_list->feeresellertotal->viewAttributes() ?>><?php echo $vloanissued_list->feeresellertotal->getViewValue() ?></span>
</span>
</td>
	<?php } ?>
	<?php if ($vloanissued_list->purchasefeeid->Visible) { // purchasefeeid ?>
		<td data-name="purchasefeeid" <?php echo $vloanissued_list->purchasefeeid->cellAttributes() ?>>
<span id="el<?php echo $vloanissued_list->RowCount ?>_vloanissued_purchasefeeid">
<span<?php echo $vloanissued_list->purchasefeeid->viewAttributes() ?>><?php echo $vloanissued_list->purchasefeeid->getViewValue() ?></span>
</span>
</td>
	<?php } ?>
	<?php if ($vloanissued_list->cancellationrefid->Visible) { // cancellationrefid ?>
		<td data-name="cancellationrefid" <?php echo $vloanissued_list->cancellationrefid->cellAttributes() ?>>
<span id="el<?php echo $vloanissued_list->RowCount ?>_vloanissued_cancellationrefid">
<span<?php echo $vloanissued_list->cancellationrefid->viewAttributes() ?>><?php echo $vloanissued_list->cancellationrefid->getViewValue() ?></span>
</span>
</td>
	<?php } ?>
	<?php if ($vloanissued_list->cancellationdatetime->Visible) { // cancellationdatetime ?>
		<td data-name="cancellationdatetime" <?php echo $vloanissued_list->cancellationdatetime->cellAttributes() ?>>
<span id="el<?php echo $vloanissued_list->RowCount ?>_vloanissued_cancellationdatetime">
<span<?php echo $vloanissued_list->cancellationdatetime->viewAttributes() ?>><?php echo $vloanissued_list->cancellationdatetime->getViewValue() ?></span>
</span>
</td>
	<?php } ?>
	<?php if ($vloanissued_list->cancellationreason->Visible) { // cancellationreason ?>
		<td data-name="cancellationreason" <?php echo $vloanissued_list->cancellationreason->cellAttributes() ?>>
<span id="el<?php echo $vloanissued_list->RowCount ?>_vloanissued_cancellationreason">
<span<?php echo $vloanissued_list->cancellationreason->viewAttributes() ?>><?php echo $vloanissued_list->cancellationreason->getViewValue() ?></span>
</span>
</td>
	<?php } ?>
	<?php if ($vloanissued_list->bankcode->Visible) { // bankcode ?>
		<td data-name="bankcode" <?php echo $vloanissued_list->bankcode->cellAttributes() ?>>
<span id="el<?php echo $vloanissued_list->RowCount ?>_vloanissued_bankcode">
<span<?php echo $vloanissued_list->bankcode->viewAttributes() ?>><?php echo $vloanissued_list->bankcode->getViewValue() ?></span>
</span>
</td>
	<?php } ?>
<?php

// Render list options (body, right)
$vloanissued_list->ListOptions->render("body", "right", $vloanissued_list->RowCount);
?>
	</tr>
<?php
	}
	if (!$vloanissued_list->isGridAdd())
		$vloanissued_list->Recordset->moveNext();
}
?>
</tbody>
</table><!-- /.ew-table -->
<?php } ?>
</div><!-- /.ew-grid-middle-panel -->
<?php if (!$vloanissued->CurrentAction) { ?>
<input type="hidden" name="action" id="action" value="">
<?php } ?>
</form><!-- /.ew-list-form -->
<?php

// Close recordset
if ($vloanissued_list->Recordset)
	$vloanissued_list->Recordset->Close();
?>
<?php if (!$vloanissued_list->isExport()) { ?>
<div class="card-footer ew-grid-lower-panel">
<?php if (!$vloanissued_list->isGridAdd()) { ?>
<form name="ew-pager-form" class="form-inline ew-form ew-pager-form" action="<?php echo CurrentPageName() ?>">
<?php echo $vloanissued_list->Pager->render() ?>
</form>
<?php } ?>
<div class="ew-list-other-options">
<?php $vloanissued_list->OtherOptions->render("body", "bottom") ?>
</div>
<div class="clearfix"></div>
</div>
<?php } ?>
</div><!-- /.ew-grid -->
<?php } ?>
<?php if ($vloanissued_list->TotalRecords == 0 && !$vloanissued->CurrentAction) { // Show other options ?>
<div class="ew-list-other-options">
<?php $vloanissued_list->OtherOptions->render("body") ?>
</div>
<div class="clearfix"></div>
<?php } ?>
<?php
$vloanissued_list->showPageFooter();
if (Config("DEBUG"))
	echo GetDebugMessage();
?>
<?php if (!$vloanissued_list->isExport()) { ?>
<script>
loadjs.ready("load", function() {

	// Startup script
	// Write your table-specific startup script here
	// console.log("page loaded");

});
</script>
<?php } ?>
<?php include_once "footer.php"; ?>
<?php
$vloanissued_list->terminate();
?>