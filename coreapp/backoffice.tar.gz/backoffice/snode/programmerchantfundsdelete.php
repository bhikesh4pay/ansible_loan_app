<?php
namespace PHPMaker2020\_4payadmin;

// Autoload
include_once "autoload.php";

// Session
if (session_status() !== PHP_SESSION_ACTIVE)
	\Delight\Cookie\Session::start(Config("COOKIE_SAMESITE")); // Init session data

// Output buffering
ob_start();
?>
<?php

// Write header
WriteHeader(FALSE);

// Create page object
$programmerchantfunds_delete = new programmerchantfunds_delete();

// Run the page
$programmerchantfunds_delete->run();

// Setup login status
SetupLoginStatus();
SetClientVar("login", LoginStatus());

// Global Page Rendering event (in userfn*.php)
Page_Rendering();

// Page Rendering event
$programmerchantfunds_delete->Page_Render();
?>
<?php include_once "header.php"; ?>
<script>
var fprogrammerchantfundsdelete, currentPageID;
loadjs.ready("head", function() {

	// Form object
	currentPageID = ew.PAGE_ID = "delete";
	fprogrammerchantfundsdelete = currentForm = new ew.Form("fprogrammerchantfundsdelete", "delete");
	loadjs.done("fprogrammerchantfundsdelete");
});
</script>
<script>
loadjs.ready("head", function() {

	// Client script
	// Write your client script here, no need to add script tags.

});
</script>
<?php $programmerchantfunds_delete->showPageHeader(); ?>
<?php
$programmerchantfunds_delete->showMessage();
?>
<form name="fprogrammerchantfundsdelete" id="fprogrammerchantfundsdelete" class="form-inline ew-form ew-delete-form" action="<?php echo CurrentPageName() ?>" method="post">
<?php if ($Page->CheckToken) { ?>
<input type="hidden" name="<?php echo Config("TOKEN_NAME") ?>" value="<?php echo $Page->Token ?>">
<?php } ?>
<input type="hidden" name="t" value="programmerchantfunds">
<input type="hidden" name="action" id="action" value="delete">
<?php foreach ($programmerchantfunds_delete->RecKeys as $key) { ?>
<?php $keyvalue = is_array($key) ? implode(Config("COMPOSITE_KEY_SEPARATOR"), $key) : $key; ?>
<input type="hidden" name="key_m[]" value="<?php echo HtmlEncode($keyvalue) ?>">
<?php } ?>
<div class="card ew-card ew-grid">
<div class="<?php echo ResponsiveTableClass() ?>card-body ew-grid-middle-panel">
<table class="table ew-table">
	<thead>
	<tr class="ew-table-header">
<?php if ($programmerchantfunds_delete->requestid->Visible) { // requestid ?>
		<th class="<?php echo $programmerchantfunds_delete->requestid->headerCellClass() ?>"><span id="elh_programmerchantfunds_requestid" class="programmerchantfunds_requestid"><?php echo $programmerchantfunds_delete->requestid->caption() ?></span></th>
<?php } ?>
<?php if ($programmerchantfunds_delete->_userid->Visible) { // userid ?>
		<th class="<?php echo $programmerchantfunds_delete->_userid->headerCellClass() ?>"><span id="elh_programmerchantfunds__userid" class="programmerchantfunds__userid"><?php echo $programmerchantfunds_delete->_userid->caption() ?></span></th>
<?php } ?>
<?php if ($programmerchantfunds_delete->userpi->Visible) { // userpi ?>
		<th class="<?php echo $programmerchantfunds_delete->userpi->headerCellClass() ?>"><span id="elh_programmerchantfunds_userpi" class="programmerchantfunds_userpi"><?php echo $programmerchantfunds_delete->userpi->caption() ?></span></th>
<?php } ?>
<?php if ($programmerchantfunds_delete->programid->Visible) { // programid ?>
		<th class="<?php echo $programmerchantfunds_delete->programid->headerCellClass() ?>"><span id="elh_programmerchantfunds_programid" class="programmerchantfunds_programid"><?php echo $programmerchantfunds_delete->programid->caption() ?></span></th>
<?php } ?>
<?php if ($programmerchantfunds_delete->currcode->Visible) { // currcode ?>
		<th class="<?php echo $programmerchantfunds_delete->currcode->headerCellClass() ?>"><span id="elh_programmerchantfunds_currcode" class="programmerchantfunds_currcode"><?php echo $programmerchantfunds_delete->currcode->caption() ?></span></th>
<?php } ?>
<?php if ($programmerchantfunds_delete->amount->Visible) { // amount ?>
		<th class="<?php echo $programmerchantfunds_delete->amount->headerCellClass() ?>"><span id="elh_programmerchantfunds_amount" class="programmerchantfunds_amount"><?php echo $programmerchantfunds_delete->amount->caption() ?></span></th>
<?php } ?>
<?php if ($programmerchantfunds_delete->_action->Visible) { // action ?>
		<th class="<?php echo $programmerchantfunds_delete->_action->headerCellClass() ?>"><span id="elh_programmerchantfunds__action" class="programmerchantfunds__action"><?php echo $programmerchantfunds_delete->_action->caption() ?></span></th>
<?php } ?>
<?php if ($programmerchantfunds_delete->status->Visible) { // status ?>
		<th class="<?php echo $programmerchantfunds_delete->status->headerCellClass() ?>"><span id="elh_programmerchantfunds_status" class="programmerchantfunds_status"><?php echo $programmerchantfunds_delete->status->caption() ?></span></th>
<?php } ?>
<?php if ($programmerchantfunds_delete->submittiondate->Visible) { // submittiondate ?>
		<th class="<?php echo $programmerchantfunds_delete->submittiondate->headerCellClass() ?>"><span id="elh_programmerchantfunds_submittiondate" class="programmerchantfunds_submittiondate"><?php echo $programmerchantfunds_delete->submittiondate->caption() ?></span></th>
<?php } ?>
<?php if ($programmerchantfunds_delete->completiondate->Visible) { // completiondate ?>
		<th class="<?php echo $programmerchantfunds_delete->completiondate->headerCellClass() ?>"><span id="elh_programmerchantfunds_completiondate" class="programmerchantfunds_completiondate"><?php echo $programmerchantfunds_delete->completiondate->caption() ?></span></th>
<?php } ?>
<?php if ($programmerchantfunds_delete->eftid->Visible) { // eftid ?>
		<th class="<?php echo $programmerchantfunds_delete->eftid->headerCellClass() ?>"><span id="elh_programmerchantfunds_eftid" class="programmerchantfunds_eftid"><?php echo $programmerchantfunds_delete->eftid->caption() ?></span></th>
<?php } ?>
<?php if ($programmerchantfunds_delete->gltransid->Visible) { // gltransid ?>
		<th class="<?php echo $programmerchantfunds_delete->gltransid->headerCellClass() ?>"><span id="elh_programmerchantfunds_gltransid" class="programmerchantfunds_gltransid"><?php echo $programmerchantfunds_delete->gltransid->caption() ?></span></th>
<?php } ?>
<?php if ($programmerchantfunds_delete->feeamount->Visible) { // feeamount ?>
		<th class="<?php echo $programmerchantfunds_delete->feeamount->headerCellClass() ?>"><span id="elh_programmerchantfunds_feeamount" class="programmerchantfunds_feeamount"><?php echo $programmerchantfunds_delete->feeamount->caption() ?></span></th>
<?php } ?>
	</tr>
	</thead>
	<tbody>
<?php
$programmerchantfunds_delete->RecordCount = 0;
$i = 0;
while (!$programmerchantfunds_delete->Recordset->EOF) {
	$programmerchantfunds_delete->RecordCount++;
	$programmerchantfunds_delete->RowCount++;

	// Set row properties
	$programmerchantfunds->resetAttributes();
	$programmerchantfunds->RowType = ROWTYPE_VIEW; // View

	// Get the field contents
	$programmerchantfunds_delete->loadRowValues($programmerchantfunds_delete->Recordset);

	// Render row
	$programmerchantfunds_delete->renderRow();
?>
	<tr <?php echo $programmerchantfunds->rowAttributes() ?>>
<?php if ($programmerchantfunds_delete->requestid->Visible) { // requestid ?>
		<td <?php echo $programmerchantfunds_delete->requestid->cellAttributes() ?>>
<span id="el<?php echo $programmerchantfunds_delete->RowCount ?>_programmerchantfunds_requestid" class="programmerchantfunds_requestid">
<span<?php echo $programmerchantfunds_delete->requestid->viewAttributes() ?>><?php echo $programmerchantfunds_delete->requestid->getViewValue() ?></span>
</span>
</td>
<?php } ?>
<?php if ($programmerchantfunds_delete->_userid->Visible) { // userid ?>
		<td <?php echo $programmerchantfunds_delete->_userid->cellAttributes() ?>>
<span id="el<?php echo $programmerchantfunds_delete->RowCount ?>_programmerchantfunds__userid" class="programmerchantfunds__userid">
<span<?php echo $programmerchantfunds_delete->_userid->viewAttributes() ?>><?php echo $programmerchantfunds_delete->_userid->getViewValue() ?></span>
</span>
</td>
<?php } ?>
<?php if ($programmerchantfunds_delete->userpi->Visible) { // userpi ?>
		<td <?php echo $programmerchantfunds_delete->userpi->cellAttributes() ?>>
<span id="el<?php echo $programmerchantfunds_delete->RowCount ?>_programmerchantfunds_userpi" class="programmerchantfunds_userpi">
<span<?php echo $programmerchantfunds_delete->userpi->viewAttributes() ?>><?php echo $programmerchantfunds_delete->userpi->getViewValue() ?></span>
</span>
</td>
<?php } ?>
<?php if ($programmerchantfunds_delete->programid->Visible) { // programid ?>
		<td <?php echo $programmerchantfunds_delete->programid->cellAttributes() ?>>
<span id="el<?php echo $programmerchantfunds_delete->RowCount ?>_programmerchantfunds_programid" class="programmerchantfunds_programid">
<span<?php echo $programmerchantfunds_delete->programid->viewAttributes() ?>><?php echo $programmerchantfunds_delete->programid->getViewValue() ?></span>
</span>
</td>
<?php } ?>
<?php if ($programmerchantfunds_delete->currcode->Visible) { // currcode ?>
		<td <?php echo $programmerchantfunds_delete->currcode->cellAttributes() ?>>
<span id="el<?php echo $programmerchantfunds_delete->RowCount ?>_programmerchantfunds_currcode" class="programmerchantfunds_currcode">
<span<?php echo $programmerchantfunds_delete->currcode->viewAttributes() ?>><?php echo $programmerchantfunds_delete->currcode->getViewValue() ?></span>
</span>
</td>
<?php } ?>
<?php if ($programmerchantfunds_delete->amount->Visible) { // amount ?>
		<td <?php echo $programmerchantfunds_delete->amount->cellAttributes() ?>>
<span id="el<?php echo $programmerchantfunds_delete->RowCount ?>_programmerchantfunds_amount" class="programmerchantfunds_amount">
<span<?php echo $programmerchantfunds_delete->amount->viewAttributes() ?>><?php echo $programmerchantfunds_delete->amount->getViewValue() ?></span>
</span>
</td>
<?php } ?>
<?php if ($programmerchantfunds_delete->_action->Visible) { // action ?>
		<td <?php echo $programmerchantfunds_delete->_action->cellAttributes() ?>>
<span id="el<?php echo $programmerchantfunds_delete->RowCount ?>_programmerchantfunds__action" class="programmerchantfunds__action">
<span<?php echo $programmerchantfunds_delete->_action->viewAttributes() ?>><?php echo $programmerchantfunds_delete->_action->getViewValue() ?></span>
</span>
</td>
<?php } ?>
<?php if ($programmerchantfunds_delete->status->Visible) { // status ?>
		<td <?php echo $programmerchantfunds_delete->status->cellAttributes() ?>>
<span id="el<?php echo $programmerchantfunds_delete->RowCount ?>_programmerchantfunds_status" class="programmerchantfunds_status">
<span<?php echo $programmerchantfunds_delete->status->viewAttributes() ?>><?php echo $programmerchantfunds_delete->status->getViewValue() ?></span>
</span>
</td>
<?php } ?>
<?php if ($programmerchantfunds_delete->submittiondate->Visible) { // submittiondate ?>
		<td <?php echo $programmerchantfunds_delete->submittiondate->cellAttributes() ?>>
<span id="el<?php echo $programmerchantfunds_delete->RowCount ?>_programmerchantfunds_submittiondate" class="programmerchantfunds_submittiondate">
<span<?php echo $programmerchantfunds_delete->submittiondate->viewAttributes() ?>><?php echo $programmerchantfunds_delete->submittiondate->getViewValue() ?></span>
</span>
</td>
<?php } ?>
<?php if ($programmerchantfunds_delete->completiondate->Visible) { // completiondate ?>
		<td <?php echo $programmerchantfunds_delete->completiondate->cellAttributes() ?>>
<span id="el<?php echo $programmerchantfunds_delete->RowCount ?>_programmerchantfunds_completiondate" class="programmerchantfunds_completiondate">
<span<?php echo $programmerchantfunds_delete->completiondate->viewAttributes() ?>><?php echo $programmerchantfunds_delete->completiondate->getViewValue() ?></span>
</span>
</td>
<?php } ?>
<?php if ($programmerchantfunds_delete->eftid->Visible) { // eftid ?>
		<td <?php echo $programmerchantfunds_delete->eftid->cellAttributes() ?>>
<span id="el<?php echo $programmerchantfunds_delete->RowCount ?>_programmerchantfunds_eftid" class="programmerchantfunds_eftid">
<span<?php echo $programmerchantfunds_delete->eftid->viewAttributes() ?>><?php echo $programmerchantfunds_delete->eftid->getViewValue() ?></span>
</span>
</td>
<?php } ?>
<?php if ($programmerchantfunds_delete->gltransid->Visible) { // gltransid ?>
		<td <?php echo $programmerchantfunds_delete->gltransid->cellAttributes() ?>>
<span id="el<?php echo $programmerchantfunds_delete->RowCount ?>_programmerchantfunds_gltransid" class="programmerchantfunds_gltransid">
<span<?php echo $programmerchantfunds_delete->gltransid->viewAttributes() ?>><?php echo $programmerchantfunds_delete->gltransid->getViewValue() ?></span>
</span>
</td>
<?php } ?>
<?php if ($programmerchantfunds_delete->feeamount->Visible) { // feeamount ?>
		<td <?php echo $programmerchantfunds_delete->feeamount->cellAttributes() ?>>
<span id="el<?php echo $programmerchantfunds_delete->RowCount ?>_programmerchantfunds_feeamount" class="programmerchantfunds_feeamount">
<span<?php echo $programmerchantfunds_delete->feeamount->viewAttributes() ?>><?php echo $programmerchantfunds_delete->feeamount->getViewValue() ?></span>
</span>
</td>
<?php } ?>
	</tr>
<?php
	$programmerchantfunds_delete->Recordset->moveNext();
}
$programmerchantfunds_delete->Recordset->close();
?>
</tbody>
</table>
</div>
</div>
<div>
<button class="btn btn-primary ew-btn" name="btn-action" id="btn-action" type="submit"><?php echo $Language->phrase("DeleteBtn") ?></button>
<button class="btn btn-default ew-btn" name="btn-cancel" id="btn-cancel" type="button" data-href="<?php echo $programmerchantfunds_delete->getReturnUrl() ?>"><?php echo $Language->phrase("CancelBtn") ?></button>
</div>
</form>
<?php
$programmerchantfunds_delete->showPageFooter();
if (Config("DEBUG"))
	echo GetDebugMessage();
?>
<script>
loadjs.ready("load", function() {

	// Startup script
	// Write your table-specific startup script here
	// console.log("page loaded");

});
</script>
<?php include_once "footer.php"; ?>
<?php
$programmerchantfunds_delete->terminate();
?>