<?php
namespace PHPMaker2020\_4payadmin;

// Autoload
include_once "autoload.php";

// Session
if (session_status() !== PHP_SESSION_ACTIVE)
	\Delight\Cookie\Session::start(Config("COOKIE_SAMESITE")); // Init session data

// Output buffering
ob_start();
?>
<?php

// Write header
WriteHeader(FALSE);

// Create page object
$E_Cash_Balances_Users_summary = new E_Cash_Balances_Users_summary();

// Run the page
$E_Cash_Balances_Users_summary->run();

// Setup login status
SetupLoginStatus();
SetClientVar("login", LoginStatus());

// Global Page Rendering event (in userfn*.php)
Page_Rendering();

// Page Rendering event
$E_Cash_Balances_Users_summary->Page_Render();
?>
<?php if (!$DashboardReport) { ?>
<?php include_once "header.php"; ?>
<?php } ?>
<?php if (!$E_Cash_Balances_Users_summary->isExport() && !$E_Cash_Balances_Users_summary->DrillDown && !$DashboardReport) { ?>
<script>
var fsummary, currentPageID;
loadjs.ready("head", function() {

	// Form object for search
	fsummary = currentForm = new ew.Form("fsummary", "summary");
	currentPageID = ew.PAGE_ID = "summary";

	// Validate function for search
	fsummary.validate = function(fobj) {
		if (!this.validateRequired)
			return true; // Ignore validation
		fobj = fobj || this._form;
		var infix = "";

		// Call Form_CustomValidate event
		if (!this.Form_CustomValidate(fobj))
			return false;
		return true;
	}

	// Form_CustomValidate
	fsummary.Form_CustomValidate = function(fobj) { // DO NOT CHANGE THIS LINE!

		// Your custom validation code here, return false if invalid.
		return true;
	}

	// Use JavaScript validation or not
	fsummary.validateRequired = <?php echo Config("CLIENT_VALIDATE") ? "true" : "false" ?>;

	// Dynamic selection lists
	fsummary.lists["x_rolename"] = <?php echo $E_Cash_Balances_Users_summary->rolename->Lookup->toClientList($E_Cash_Balances_Users_summary) ?>;
	fsummary.lists["x_rolename"].options = <?php echo JsonEncode($E_Cash_Balances_Users_summary->rolename->lookupOptions()) ?>;
	fsummary.lists["x_currCode"] = <?php echo $E_Cash_Balances_Users_summary->currCode->Lookup->toClientList($E_Cash_Balances_Users_summary) ?>;
	fsummary.lists["x_currCode"].options = <?php echo JsonEncode($E_Cash_Balances_Users_summary->currCode->lookupOptions()) ?>;
	fsummary.lists["x_userType"] = <?php echo $E_Cash_Balances_Users_summary->userType->Lookup->toClientList($E_Cash_Balances_Users_summary) ?>;
	fsummary.lists["x_userType"].options = <?php echo JsonEncode($E_Cash_Balances_Users_summary->userType->lookupOptions()) ?>;
	fsummary.lists["x_usersubtype"] = <?php echo $E_Cash_Balances_Users_summary->usersubtype->Lookup->toClientList($E_Cash_Balances_Users_summary) ?>;
	fsummary.lists["x_usersubtype"].options = <?php echo JsonEncode($E_Cash_Balances_Users_summary->usersubtype->lookupOptions()) ?>;

	// Filters
	fsummary.filterList = <?php echo $E_Cash_Balances_Users_summary->getFilterList() ?>;
	loadjs.done("fsummary");
});
</script>
<script>
loadjs.ready("head", function() {

	// Client script
	// Write your client script here, no need to add script tags.

});
</script>
<?php } ?>
<a id="top"></a>
<?php if ((!$E_Cash_Balances_Users_summary->isExport() || $E_Cash_Balances_Users_summary->isExport("print")) && !$DashboardReport) { ?>
<!-- Content Container -->
<div id="ew-report" class="ew-report container-fluid">
<?php } ?>
<?php if ($E_Cash_Balances_Users_summary->ShowCurrentFilter) { ?>
<?php $E_Cash_Balances_Users_summary->showFilterList() ?>
<?php } ?>
<div class="btn-toolbar ew-toolbar">
<?php
if (!$E_Cash_Balances_Users_summary->DrillDownInPanel) {
	$E_Cash_Balances_Users_summary->ExportOptions->render("body");
	$E_Cash_Balances_Users_summary->SearchOptions->render("body");
	$E_Cash_Balances_Users_summary->FilterOptions->render("body");
}
?>
</div>
<?php $E_Cash_Balances_Users_summary->showPageHeader(); ?>
<?php
$E_Cash_Balances_Users_summary->showMessage();
?>
<?php if ((!$E_Cash_Balances_Users_summary->isExport() || $E_Cash_Balances_Users_summary->isExport("print")) && !$DashboardReport) { ?>
<div class="row">
<?php } ?>
<?php if ((!$E_Cash_Balances_Users_summary->isExport() || $E_Cash_Balances_Users_summary->isExport("print")) && !$DashboardReport) { ?>
<!-- Center Container -->
<div id="ew-center" class="<?php echo $E_Cash_Balances_Users_summary->CenterContentClass ?>">
<?php } ?>
<!-- Summary report (begin) -->
<div id="report_summary">
<?php if (!$E_Cash_Balances_Users_summary->isExport() && !$E_Cash_Balances_Users_summary->DrillDown && !$DashboardReport) { ?>
<?php if ($Security->CanSearch()) { ?>
<?php if (!$E_Cash_Balances_Users_summary->isExport() && !$E_Cash_Balances_Users->CurrentAction) { ?>
<form name="fsummary" id="fsummary" class="form-inline ew-form ew-ext-search-form" action="<?php echo CurrentPageName() ?>">
<div id="fsummary-search-panel" class="<?php echo $E_Cash_Balances_Users_summary->SearchPanelClass ?>">
<input type="hidden" name="cmd" value="search">
<input type="hidden" name="t" value="E_Cash_Balances_Users">
	<div class="ew-extended-search">
<?php

// Render search row
$E_Cash_Balances_Users->RowType = ROWTYPE_SEARCH;
$E_Cash_Balances_Users->resetAttributes();
$E_Cash_Balances_Users_summary->renderRow();
?>
<?php if ($E_Cash_Balances_Users_summary->rolename->Visible) { // rolename ?>
	<?php
		$E_Cash_Balances_Users_summary->SearchColumnCount++;
		if (($E_Cash_Balances_Users_summary->SearchColumnCount - 1) % $E_Cash_Balances_Users_summary->SearchFieldsPerRow == 0) {
			$E_Cash_Balances_Users_summary->SearchRowCount++;
	?>
<div id="xsr_<?php echo $E_Cash_Balances_Users_summary->SearchRowCount ?>" class="ew-row d-sm-flex">
	<?php
		}
	 ?>
	<div id="xsc_rolename" class="ew-cell form-group">
		<label for="x_rolename" class="ew-search-caption ew-label"><?php echo $E_Cash_Balances_Users_summary->rolename->caption() ?></label>
		<span id="el_E_Cash_Balances_Users_rolename" class="ew-search-field">
<div class="btn-group ew-dropdown-list" role="group">
	<div class="btn-group" role="group">
		<button type="button" class="btn form-control dropdown-toggle ew-dropdown-toggle" aria-haspopup="true" aria-expanded="false"<?php if ($E_Cash_Balances_Users_summary->rolename->ReadOnly) { ?> readonly<?php } else { ?>data-toggle="dropdown"<?php } ?>><?php echo $E_Cash_Balances_Users_summary->rolename->AdvancedSearch->ViewValue ?></button>
		<div id="dsl_x_rolename" data-repeatcolumn="1" class="dropdown-menu">
			<div class="ew-items" style="overflow-x: hidden; min-width: 300px; max-height: 200px; overflow-y: auto;">
<?php echo $E_Cash_Balances_Users_summary->rolename->radioButtonListHtml(TRUE, "x_rolename") ?>
			</div><!-- /.ew-items -->
		</div><!-- /.dropdown-menu -->
		<div id="tp_x_rolename" class="ew-template"><input type="radio" class="custom-control-input" data-table="E_Cash_Balances_Users" data-field="x_rolename" data-value-separator="<?php echo $E_Cash_Balances_Users_summary->rolename->displayValueSeparatorAttribute() ?>" name="x_rolename" id="x_rolename" value="{value}"<?php echo $E_Cash_Balances_Users_summary->rolename->editAttributes() ?>></div>
	</div><!-- /.btn-group -->
	<?php if (!$E_Cash_Balances_Users_summary->rolename->ReadOnly) { ?>
	<button type="button" class="btn btn-default ew-dropdown-clear" disabled>
		<i class="fas fa-times ew-icon"></i>
	</button>
	<?php } ?>
</div><!-- /.ew-dropdown-list -->
<?php echo $E_Cash_Balances_Users_summary->rolename->Lookup->getParamTag($E_Cash_Balances_Users_summary, "p_x_rolename") ?>
</span>
	</div>
	<?php if ($E_Cash_Balances_Users_summary->SearchColumnCount % $E_Cash_Balances_Users_summary->SearchFieldsPerRow == 0) { ?>
</div>
	<?php } ?>
<?php } ?>
<?php if ($E_Cash_Balances_Users_summary->currCode->Visible) { // currCode ?>
	<?php
		$E_Cash_Balances_Users_summary->SearchColumnCount++;
		if (($E_Cash_Balances_Users_summary->SearchColumnCount - 1) % $E_Cash_Balances_Users_summary->SearchFieldsPerRow == 0) {
			$E_Cash_Balances_Users_summary->SearchRowCount++;
	?>
<div id="xsr_<?php echo $E_Cash_Balances_Users_summary->SearchRowCount ?>" class="ew-row d-sm-flex">
	<?php
		}
	 ?>
	<div id="xsc_currCode" class="ew-cell form-group">
		<label for="x_currCode" class="ew-search-caption ew-label"><?php echo $E_Cash_Balances_Users_summary->currCode->caption() ?></label>
		<span id="el_E_Cash_Balances_Users_currCode" class="ew-search-field">
<div class="btn-group ew-dropdown-list" role="group">
	<div class="btn-group" role="group">
		<button type="button" class="btn form-control dropdown-toggle ew-dropdown-toggle" aria-haspopup="true" aria-expanded="false"<?php if ($E_Cash_Balances_Users_summary->currCode->ReadOnly) { ?> readonly<?php } else { ?>data-toggle="dropdown"<?php } ?>><?php echo $E_Cash_Balances_Users_summary->currCode->AdvancedSearch->ViewValue ?></button>
		<div id="dsl_x_currCode" data-repeatcolumn="1" class="dropdown-menu">
			<div class="ew-items" style="overflow-x: hidden; min-width: 300px; max-height: 200px; overflow-y: auto;">
<?php echo $E_Cash_Balances_Users_summary->currCode->radioButtonListHtml(TRUE, "x_currCode") ?>
			</div><!-- /.ew-items -->
		</div><!-- /.dropdown-menu -->
		<div id="tp_x_currCode" class="ew-template"><input type="radio" class="custom-control-input" data-table="E_Cash_Balances_Users" data-field="x_currCode" data-value-separator="<?php echo $E_Cash_Balances_Users_summary->currCode->displayValueSeparatorAttribute() ?>" name="x_currCode" id="x_currCode" value="{value}"<?php echo $E_Cash_Balances_Users_summary->currCode->editAttributes() ?>></div>
	</div><!-- /.btn-group -->
	<?php if (!$E_Cash_Balances_Users_summary->currCode->ReadOnly) { ?>
	<button type="button" class="btn btn-default ew-dropdown-clear" disabled>
		<i class="fas fa-times ew-icon"></i>
	</button>
	<?php } ?>
</div><!-- /.ew-dropdown-list -->
<?php echo $E_Cash_Balances_Users_summary->currCode->Lookup->getParamTag($E_Cash_Balances_Users_summary, "p_x_currCode") ?>
</span>
	</div>
	<?php if ($E_Cash_Balances_Users_summary->SearchColumnCount % $E_Cash_Balances_Users_summary->SearchFieldsPerRow == 0) { ?>
</div>
	<?php } ?>
<?php } ?>
<?php if ($E_Cash_Balances_Users_summary->userType->Visible) { // userType ?>
	<?php
		$E_Cash_Balances_Users_summary->SearchColumnCount++;
		if (($E_Cash_Balances_Users_summary->SearchColumnCount - 1) % $E_Cash_Balances_Users_summary->SearchFieldsPerRow == 0) {
			$E_Cash_Balances_Users_summary->SearchRowCount++;
	?>
<div id="xsr_<?php echo $E_Cash_Balances_Users_summary->SearchRowCount ?>" class="ew-row d-sm-flex">
	<?php
		}
	 ?>
	<div id="xsc_userType" class="ew-cell form-group">
		<label for="x_userType" class="ew-search-caption ew-label"><?php echo $E_Cash_Balances_Users_summary->userType->caption() ?></label>
		<span id="el_E_Cash_Balances_Users_userType" class="ew-search-field">
<div class="btn-group ew-dropdown-list" role="group">
	<div class="btn-group" role="group">
		<button type="button" class="btn form-control dropdown-toggle ew-dropdown-toggle" aria-haspopup="true" aria-expanded="false"<?php if ($E_Cash_Balances_Users_summary->userType->ReadOnly) { ?> readonly<?php } else { ?>data-toggle="dropdown"<?php } ?>><?php echo $E_Cash_Balances_Users_summary->userType->AdvancedSearch->ViewValue ?></button>
		<div id="dsl_x_userType" data-repeatcolumn="1" class="dropdown-menu">
			<div class="ew-items" style="overflow-x: hidden; min-width: 300px; max-height: 200px; overflow-y: auto;">
<?php echo $E_Cash_Balances_Users_summary->userType->radioButtonListHtml(TRUE, "x_userType") ?>
			</div><!-- /.ew-items -->
		</div><!-- /.dropdown-menu -->
		<div id="tp_x_userType" class="ew-template"><input type="radio" class="custom-control-input" data-table="E_Cash_Balances_Users" data-field="x_userType" data-value-separator="<?php echo $E_Cash_Balances_Users_summary->userType->displayValueSeparatorAttribute() ?>" name="x_userType" id="x_userType" value="{value}"<?php echo $E_Cash_Balances_Users_summary->userType->editAttributes() ?>></div>
	</div><!-- /.btn-group -->
	<?php if (!$E_Cash_Balances_Users_summary->userType->ReadOnly) { ?>
	<button type="button" class="btn btn-default ew-dropdown-clear" disabled>
		<i class="fas fa-times ew-icon"></i>
	</button>
	<?php } ?>
</div><!-- /.ew-dropdown-list -->
<?php echo $E_Cash_Balances_Users_summary->userType->Lookup->getParamTag($E_Cash_Balances_Users_summary, "p_x_userType") ?>
</span>
	</div>
	<?php if ($E_Cash_Balances_Users_summary->SearchColumnCount % $E_Cash_Balances_Users_summary->SearchFieldsPerRow == 0) { ?>
</div>
	<?php } ?>
<?php } ?>
<?php if ($E_Cash_Balances_Users_summary->usersubtype->Visible) { // usersubtype ?>
	<?php
		$E_Cash_Balances_Users_summary->SearchColumnCount++;
		if (($E_Cash_Balances_Users_summary->SearchColumnCount - 1) % $E_Cash_Balances_Users_summary->SearchFieldsPerRow == 0) {
			$E_Cash_Balances_Users_summary->SearchRowCount++;
	?>
<div id="xsr_<?php echo $E_Cash_Balances_Users_summary->SearchRowCount ?>" class="ew-row d-sm-flex">
	<?php
		}
	 ?>
	<div id="xsc_usersubtype" class="ew-cell form-group">
		<label for="x_usersubtype" class="ew-search-caption ew-label"><?php echo $E_Cash_Balances_Users_summary->usersubtype->caption() ?></label>
		<span id="el_E_Cash_Balances_Users_usersubtype" class="ew-search-field">
<div class="btn-group ew-dropdown-list" role="group">
	<div class="btn-group" role="group">
		<button type="button" class="btn form-control dropdown-toggle ew-dropdown-toggle" aria-haspopup="true" aria-expanded="false"<?php if ($E_Cash_Balances_Users_summary->usersubtype->ReadOnly) { ?> readonly<?php } else { ?>data-toggle="dropdown"<?php } ?>><?php echo $E_Cash_Balances_Users_summary->usersubtype->AdvancedSearch->ViewValue ?></button>
		<div id="dsl_x_usersubtype" data-repeatcolumn="1" class="dropdown-menu">
			<div class="ew-items" style="overflow-x: hidden; min-width: 300px; max-height: 200px; overflow-y: auto;">
<?php echo $E_Cash_Balances_Users_summary->usersubtype->radioButtonListHtml(TRUE, "x_usersubtype") ?>
			</div><!-- /.ew-items -->
		</div><!-- /.dropdown-menu -->
		<div id="tp_x_usersubtype" class="ew-template"><input type="radio" class="custom-control-input" data-table="E_Cash_Balances_Users" data-field="x_usersubtype" data-value-separator="<?php echo $E_Cash_Balances_Users_summary->usersubtype->displayValueSeparatorAttribute() ?>" name="x_usersubtype" id="x_usersubtype" value="{value}"<?php echo $E_Cash_Balances_Users_summary->usersubtype->editAttributes() ?>></div>
	</div><!-- /.btn-group -->
	<?php if (!$E_Cash_Balances_Users_summary->usersubtype->ReadOnly) { ?>
	<button type="button" class="btn btn-default ew-dropdown-clear" disabled>
		<i class="fas fa-times ew-icon"></i>
	</button>
	<?php } ?>
</div><!-- /.ew-dropdown-list -->
<?php echo $E_Cash_Balances_Users_summary->usersubtype->Lookup->getParamTag($E_Cash_Balances_Users_summary, "p_x_usersubtype") ?>
</span>
	</div>
	<?php if ($E_Cash_Balances_Users_summary->SearchColumnCount % $E_Cash_Balances_Users_summary->SearchFieldsPerRow == 0) { ?>
</div>
	<?php } ?>
<?php } ?>
	<?php if ($E_Cash_Balances_Users_summary->SearchColumnCount % $E_Cash_Balances_Users_summary->SearchFieldsPerRow > 0) { ?>
</div>
	<?php } ?>
<div id="xsr_<?php echo $E_Cash_Balances_Users_summary->SearchRowCount + 1 ?>" class="ew-row d-sm-flex">
	<button class="btn btn-primary" name="btn-submit" id="btn-submit" type="submit"><?php echo $Language->phrase("SearchBtn") ?></button>
</div>
	</div><!-- /.ew-extended-search -->
</div><!-- /.ew-search-panel -->
</form>
<?php } ?>
<?php } ?>
<?php } ?>
<?php
while ($E_Cash_Balances_Users_summary->GroupCount <= count($E_Cash_Balances_Users_summary->GroupRecords) && $E_Cash_Balances_Users_summary->GroupCount <= $E_Cash_Balances_Users_summary->DisplayGroups) {
?>
<?php

	// Show header
	if ($E_Cash_Balances_Users_summary->ShowHeader) {
?>
<?php if ($E_Cash_Balances_Users_summary->GroupCount > 1) { ?>
</tbody>
</table>
</div>
<!-- /.ew-grid-middle-panel -->
<!-- Report grid (end) -->
<?php if (!$E_Cash_Balances_Users_summary->isExport() && !($E_Cash_Balances_Users_summary->DrillDown && $E_Cash_Balances_Users_summary->TotalGroups > 0)) { ?>
<!-- Bottom pager -->
<div class="card-footer ew-grid-lower-panel">
<form name="ew-pager-form" class="form-inline ew-form ew-pager-form" action="<?php echo CurrentPageName() ?>">
<?php echo $E_Cash_Balances_Users_summary->Pager->render() ?>
</form>
<div class="clearfix"></div>
</div>
<?php } ?>
</div>
<!-- /.ew-grid -->
<?php echo $E_Cash_Balances_Users_summary->PageBreakContent ?>
<?php } ?>
<div class="<?php if (!$E_Cash_Balances_Users_summary->isExport("word") && !$E_Cash_Balances_Users_summary->isExport("excel")) { ?>card ew-card <?php } ?>ew-grid"<?php echo $E_Cash_Balances_Users_summary->ReportTableStyle ?>>
<!-- Report grid (begin) -->
<div id="gmp_E_Cash_Balances_Users" class="<?php echo ResponsiveTableClass() ?>card-body ew-grid-middle-panel">
<table class="<?php echo $E_Cash_Balances_Users_summary->ReportTableClass ?>">
<thead>
	<!-- Table header -->
	<tr class="ew-table-header">
<?php if ($E_Cash_Balances_Users_summary->currCode->Visible) { ?>
	<?php if ($E_Cash_Balances_Users_summary->currCode->ShowGroupHeaderAsRow) { ?>
	<th data-name="currCode">&nbsp;</th>
	<?php } else { ?>
		<?php if ($E_Cash_Balances_Users_summary->sortUrl($E_Cash_Balances_Users_summary->currCode) == "") { ?>
	<th data-name="currCode" class="<?php echo $E_Cash_Balances_Users_summary->currCode->headerCellClass() ?>"><div class="E_Cash_Balances_Users_currCode"><div class="ew-table-header-caption"><?php echo $E_Cash_Balances_Users_summary->currCode->caption() ?></div></div></th>
		<?php } else { ?>
	<th data-name="currCode" class="<?php echo $E_Cash_Balances_Users_summary->currCode->headerCellClass() ?>"><div class="ew-pointer" onclick="ew.sort(event, '<?php echo $E_Cash_Balances_Users_summary->sortUrl($E_Cash_Balances_Users_summary->currCode) ?>', 1);"><div class="E_Cash_Balances_Users_currCode">
		<div class="ew-table-header-btn"><span class="ew-table-header-caption"><?php echo $E_Cash_Balances_Users_summary->currCode->caption() ?></span><span class="ew-table-header-sort"><?php if ($E_Cash_Balances_Users_summary->currCode->getSort() == "ASC") { ?><i class="fas fa-sort-up"></i><?php } elseif ($E_Cash_Balances_Users_summary->currCode->getSort() == "DESC") { ?><i class="fas fa-sort-down"></i><?php } ?></span></div>
	</div></div></th>
		<?php } ?>
	<?php } ?>
<?php } ?>
<?php if ($E_Cash_Balances_Users_summary->firstName->Visible) { ?>
	<?php if ($E_Cash_Balances_Users_summary->sortUrl($E_Cash_Balances_Users_summary->firstName) == "") { ?>
	<th data-name="firstName" class="<?php echo $E_Cash_Balances_Users_summary->firstName->headerCellClass() ?>"><div class="E_Cash_Balances_Users_firstName"><div class="ew-table-header-caption"><?php echo $E_Cash_Balances_Users_summary->firstName->caption() ?></div></div></th>
	<?php } else { ?>
	<th data-name="firstName" class="<?php echo $E_Cash_Balances_Users_summary->firstName->headerCellClass() ?>"><div class="ew-pointer" onclick="ew.sort(event, '<?php echo $E_Cash_Balances_Users_summary->sortUrl($E_Cash_Balances_Users_summary->firstName) ?>', 1);"><div class="E_Cash_Balances_Users_firstName">
		<div class="ew-table-header-btn"><span class="ew-table-header-caption"><?php echo $E_Cash_Balances_Users_summary->firstName->caption() ?></span><span class="ew-table-header-sort"><?php if ($E_Cash_Balances_Users_summary->firstName->getSort() == "ASC") { ?><i class="fas fa-sort-up"></i><?php } elseif ($E_Cash_Balances_Users_summary->firstName->getSort() == "DESC") { ?><i class="fas fa-sort-down"></i><?php } ?></span></div>
	</div></div></th>
	<?php } ?>
<?php } ?>
<?php if ($E_Cash_Balances_Users_summary->lastName->Visible) { ?>
	<?php if ($E_Cash_Balances_Users_summary->sortUrl($E_Cash_Balances_Users_summary->lastName) == "") { ?>
	<th data-name="lastName" class="<?php echo $E_Cash_Balances_Users_summary->lastName->headerCellClass() ?>"><div class="E_Cash_Balances_Users_lastName"><div class="ew-table-header-caption"><?php echo $E_Cash_Balances_Users_summary->lastName->caption() ?></div></div></th>
	<?php } else { ?>
	<th data-name="lastName" class="<?php echo $E_Cash_Balances_Users_summary->lastName->headerCellClass() ?>"><div class="ew-pointer" onclick="ew.sort(event, '<?php echo $E_Cash_Balances_Users_summary->sortUrl($E_Cash_Balances_Users_summary->lastName) ?>', 1);"><div class="E_Cash_Balances_Users_lastName">
		<div class="ew-table-header-btn"><span class="ew-table-header-caption"><?php echo $E_Cash_Balances_Users_summary->lastName->caption() ?></span><span class="ew-table-header-sort"><?php if ($E_Cash_Balances_Users_summary->lastName->getSort() == "ASC") { ?><i class="fas fa-sort-up"></i><?php } elseif ($E_Cash_Balances_Users_summary->lastName->getSort() == "DESC") { ?><i class="fas fa-sort-down"></i><?php } ?></span></div>
	</div></div></th>
	<?php } ?>
<?php } ?>
<?php if ($E_Cash_Balances_Users_summary->_userid->Visible) { ?>
	<?php if ($E_Cash_Balances_Users_summary->sortUrl($E_Cash_Balances_Users_summary->_userid) == "") { ?>
	<th data-name="_userid" class="<?php echo $E_Cash_Balances_Users_summary->_userid->headerCellClass() ?>"><div class="E_Cash_Balances_Users__userid"><div class="ew-table-header-caption"><?php echo $E_Cash_Balances_Users_summary->_userid->caption() ?></div></div></th>
	<?php } else { ?>
	<th data-name="_userid" class="<?php echo $E_Cash_Balances_Users_summary->_userid->headerCellClass() ?>"><div class="ew-pointer" onclick="ew.sort(event, '<?php echo $E_Cash_Balances_Users_summary->sortUrl($E_Cash_Balances_Users_summary->_userid) ?>', 1);"><div class="E_Cash_Balances_Users__userid">
		<div class="ew-table-header-btn"><span class="ew-table-header-caption"><?php echo $E_Cash_Balances_Users_summary->_userid->caption() ?></span><span class="ew-table-header-sort"><?php if ($E_Cash_Balances_Users_summary->_userid->getSort() == "ASC") { ?><i class="fas fa-sort-up"></i><?php } elseif ($E_Cash_Balances_Users_summary->_userid->getSort() == "DESC") { ?><i class="fas fa-sort-down"></i><?php } ?></span></div>
	</div></div></th>
	<?php } ?>
<?php } ?>
<?php if ($E_Cash_Balances_Users_summary->rolename->Visible) { ?>
	<?php if ($E_Cash_Balances_Users_summary->sortUrl($E_Cash_Balances_Users_summary->rolename) == "") { ?>
	<th data-name="rolename" class="<?php echo $E_Cash_Balances_Users_summary->rolename->headerCellClass() ?>"><div class="E_Cash_Balances_Users_rolename"><div class="ew-table-header-caption"><?php echo $E_Cash_Balances_Users_summary->rolename->caption() ?></div></div></th>
	<?php } else { ?>
	<th data-name="rolename" class="<?php echo $E_Cash_Balances_Users_summary->rolename->headerCellClass() ?>"><div class="ew-pointer" onclick="ew.sort(event, '<?php echo $E_Cash_Balances_Users_summary->sortUrl($E_Cash_Balances_Users_summary->rolename) ?>', 1);"><div class="E_Cash_Balances_Users_rolename">
		<div class="ew-table-header-btn"><span class="ew-table-header-caption"><?php echo $E_Cash_Balances_Users_summary->rolename->caption() ?></span><span class="ew-table-header-sort"><?php if ($E_Cash_Balances_Users_summary->rolename->getSort() == "ASC") { ?><i class="fas fa-sort-up"></i><?php } elseif ($E_Cash_Balances_Users_summary->rolename->getSort() == "DESC") { ?><i class="fas fa-sort-down"></i><?php } ?></span></div>
	</div></div></th>
	<?php } ?>
<?php } ?>
<?php if ($E_Cash_Balances_Users_summary->userType->Visible) { ?>
	<?php if ($E_Cash_Balances_Users_summary->sortUrl($E_Cash_Balances_Users_summary->userType) == "") { ?>
	<th data-name="userType" class="<?php echo $E_Cash_Balances_Users_summary->userType->headerCellClass() ?>"><div class="E_Cash_Balances_Users_userType"><div class="ew-table-header-caption"><?php echo $E_Cash_Balances_Users_summary->userType->caption() ?></div></div></th>
	<?php } else { ?>
	<th data-name="userType" class="<?php echo $E_Cash_Balances_Users_summary->userType->headerCellClass() ?>"><div class="ew-pointer" onclick="ew.sort(event, '<?php echo $E_Cash_Balances_Users_summary->sortUrl($E_Cash_Balances_Users_summary->userType) ?>', 1);"><div class="E_Cash_Balances_Users_userType">
		<div class="ew-table-header-btn"><span class="ew-table-header-caption"><?php echo $E_Cash_Balances_Users_summary->userType->caption() ?></span><span class="ew-table-header-sort"><?php if ($E_Cash_Balances_Users_summary->userType->getSort() == "ASC") { ?><i class="fas fa-sort-up"></i><?php } elseif ($E_Cash_Balances_Users_summary->userType->getSort() == "DESC") { ?><i class="fas fa-sort-down"></i><?php } ?></span></div>
	</div></div></th>
	<?php } ?>
<?php } ?>
<?php if ($E_Cash_Balances_Users_summary->usersubtype->Visible) { ?>
	<?php if ($E_Cash_Balances_Users_summary->sortUrl($E_Cash_Balances_Users_summary->usersubtype) == "") { ?>
	<th data-name="usersubtype" class="<?php echo $E_Cash_Balances_Users_summary->usersubtype->headerCellClass() ?>"><div class="E_Cash_Balances_Users_usersubtype"><div class="ew-table-header-caption"><?php echo $E_Cash_Balances_Users_summary->usersubtype->caption() ?></div></div></th>
	<?php } else { ?>
	<th data-name="usersubtype" class="<?php echo $E_Cash_Balances_Users_summary->usersubtype->headerCellClass() ?>"><div class="ew-pointer" onclick="ew.sort(event, '<?php echo $E_Cash_Balances_Users_summary->sortUrl($E_Cash_Balances_Users_summary->usersubtype) ?>', 1);"><div class="E_Cash_Balances_Users_usersubtype">
		<div class="ew-table-header-btn"><span class="ew-table-header-caption"><?php echo $E_Cash_Balances_Users_summary->usersubtype->caption() ?></span><span class="ew-table-header-sort"><?php if ($E_Cash_Balances_Users_summary->usersubtype->getSort() == "ASC") { ?><i class="fas fa-sort-up"></i><?php } elseif ($E_Cash_Balances_Users_summary->usersubtype->getSort() == "DESC") { ?><i class="fas fa-sort-down"></i><?php } ?></span></div>
	</div></div></th>
	<?php } ?>
<?php } ?>
<?php if ($E_Cash_Balances_Users_summary->availablebalance->Visible) { ?>
	<?php if ($E_Cash_Balances_Users_summary->sortUrl($E_Cash_Balances_Users_summary->availablebalance) == "") { ?>
	<th data-name="availablebalance" class="<?php echo $E_Cash_Balances_Users_summary->availablebalance->headerCellClass() ?>"><div class="E_Cash_Balances_Users_availablebalance"><div class="ew-table-header-caption"><?php echo $E_Cash_Balances_Users_summary->availablebalance->caption() ?></div></div></th>
	<?php } else { ?>
	<th data-name="availablebalance" class="<?php echo $E_Cash_Balances_Users_summary->availablebalance->headerCellClass() ?>"><div class="ew-pointer" onclick="ew.sort(event, '<?php echo $E_Cash_Balances_Users_summary->sortUrl($E_Cash_Balances_Users_summary->availablebalance) ?>', 1);"><div class="E_Cash_Balances_Users_availablebalance">
		<div class="ew-table-header-btn"><span class="ew-table-header-caption"><?php echo $E_Cash_Balances_Users_summary->availablebalance->caption() ?></span><span class="ew-table-header-sort"><?php if ($E_Cash_Balances_Users_summary->availablebalance->getSort() == "ASC") { ?><i class="fas fa-sort-up"></i><?php } elseif ($E_Cash_Balances_Users_summary->availablebalance->getSort() == "DESC") { ?><i class="fas fa-sort-down"></i><?php } ?></span></div>
	</div></div></th>
	<?php } ?>
<?php } ?>
<?php if ($E_Cash_Balances_Users_summary->unavailablebalance->Visible) { ?>
	<?php if ($E_Cash_Balances_Users_summary->sortUrl($E_Cash_Balances_Users_summary->unavailablebalance) == "") { ?>
	<th data-name="unavailablebalance" class="<?php echo $E_Cash_Balances_Users_summary->unavailablebalance->headerCellClass() ?>"><div class="E_Cash_Balances_Users_unavailablebalance"><div class="ew-table-header-caption"><?php echo $E_Cash_Balances_Users_summary->unavailablebalance->caption() ?></div></div></th>
	<?php } else { ?>
	<th data-name="unavailablebalance" class="<?php echo $E_Cash_Balances_Users_summary->unavailablebalance->headerCellClass() ?>"><div class="ew-pointer" onclick="ew.sort(event, '<?php echo $E_Cash_Balances_Users_summary->sortUrl($E_Cash_Balances_Users_summary->unavailablebalance) ?>', 1);"><div class="E_Cash_Balances_Users_unavailablebalance">
		<div class="ew-table-header-btn"><span class="ew-table-header-caption"><?php echo $E_Cash_Balances_Users_summary->unavailablebalance->caption() ?></span><span class="ew-table-header-sort"><?php if ($E_Cash_Balances_Users_summary->unavailablebalance->getSort() == "ASC") { ?><i class="fas fa-sort-up"></i><?php } elseif ($E_Cash_Balances_Users_summary->unavailablebalance->getSort() == "DESC") { ?><i class="fas fa-sort-down"></i><?php } ?></span></div>
	</div></div></th>
	<?php } ?>
<?php } ?>
<?php if ($E_Cash_Balances_Users_summary->accountID->Visible) { ?>
	<?php if ($E_Cash_Balances_Users_summary->sortUrl($E_Cash_Balances_Users_summary->accountID) == "") { ?>
	<th data-name="accountID" class="<?php echo $E_Cash_Balances_Users_summary->accountID->headerCellClass() ?>"><div class="E_Cash_Balances_Users_accountID"><div class="ew-table-header-caption"><?php echo $E_Cash_Balances_Users_summary->accountID->caption() ?></div></div></th>
	<?php } else { ?>
	<th data-name="accountID" class="<?php echo $E_Cash_Balances_Users_summary->accountID->headerCellClass() ?>"><div class="ew-pointer" onclick="ew.sort(event, '<?php echo $E_Cash_Balances_Users_summary->sortUrl($E_Cash_Balances_Users_summary->accountID) ?>', 1);"><div class="E_Cash_Balances_Users_accountID">
		<div class="ew-table-header-btn"><span class="ew-table-header-caption"><?php echo $E_Cash_Balances_Users_summary->accountID->caption() ?></span><span class="ew-table-header-sort"><?php if ($E_Cash_Balances_Users_summary->accountID->getSort() == "ASC") { ?><i class="fas fa-sort-up"></i><?php } elseif ($E_Cash_Balances_Users_summary->accountID->getSort() == "DESC") { ?><i class="fas fa-sort-down"></i><?php } ?></span></div>
	</div></div></th>
	<?php } ?>
<?php } ?>
	</tr>
</thead>
<tbody>
<?php
		if ($E_Cash_Balances_Users_summary->TotalGroups == 0)
			break; // Show header only
		$E_Cash_Balances_Users_summary->ShowHeader = FALSE;
	} // End show header
?>
<?php

	// Build detail SQL
	$where = DetailFilterSql($E_Cash_Balances_Users_summary->currCode, $E_Cash_Balances_Users_summary->getSqlFirstGroupField(), $E_Cash_Balances_Users_summary->currCode->groupValue(), $E_Cash_Balances_Users_summary->Dbid);
	if ($E_Cash_Balances_Users_summary->PageFirstGroupFilter != "") $E_Cash_Balances_Users_summary->PageFirstGroupFilter .= " OR ";
	$E_Cash_Balances_Users_summary->PageFirstGroupFilter .= $where;
	if ($E_Cash_Balances_Users_summary->Filter != "")
		$where = "($E_Cash_Balances_Users_summary->Filter) AND ($where)";
	$sql = BuildReportSql($E_Cash_Balances_Users_summary->getSqlSelect(), $E_Cash_Balances_Users_summary->getSqlWhere(), $E_Cash_Balances_Users_summary->getSqlGroupBy(), $E_Cash_Balances_Users_summary->getSqlHaving(), $E_Cash_Balances_Users_summary->getSqlOrderBy(), $where, $E_Cash_Balances_Users_summary->Sort);
	$rs = $E_Cash_Balances_Users_summary->getRecordset($sql);
	$E_Cash_Balances_Users_summary->DetailRecords = $rs ? $rs->getRows() : [];
	$E_Cash_Balances_Users_summary->DetailRecordCount = count($E_Cash_Balances_Users_summary->DetailRecords);
	$E_Cash_Balances_Users_summary->setGroupCount($E_Cash_Balances_Users_summary->DetailRecordCount, $E_Cash_Balances_Users_summary->GroupCount);

	// Load detail records
	$E_Cash_Balances_Users_summary->currCode->Records = &$E_Cash_Balances_Users_summary->DetailRecords;
	$E_Cash_Balances_Users_summary->currCode->LevelBreak = TRUE; // Set field level break
		$E_Cash_Balances_Users_summary->GroupCounter[1] = $E_Cash_Balances_Users_summary->GroupCount;
		$E_Cash_Balances_Users_summary->currCode->getCnt($E_Cash_Balances_Users_summary->currCode->Records); // Get record count
		$E_Cash_Balances_Users_summary->setGroupCount($E_Cash_Balances_Users_summary->currCode->Count, $E_Cash_Balances_Users_summary->GroupCounter[1]);
?>
<?php if ($E_Cash_Balances_Users_summary->currCode->Visible && $E_Cash_Balances_Users_summary->currCode->ShowGroupHeaderAsRow) { ?>
<?php

		// Render header row
		$E_Cash_Balances_Users_summary->resetAttributes();
		$E_Cash_Balances_Users_summary->RowType = ROWTYPE_TOTAL;
		$E_Cash_Balances_Users_summary->RowTotalType = ROWTOTAL_GROUP;
		$E_Cash_Balances_Users_summary->RowTotalSubType = ROWTOTAL_HEADER;
		$E_Cash_Balances_Users_summary->RowGroupLevel = 1;
		$E_Cash_Balances_Users_summary->renderRow();
?>
	<tr<?php echo $E_Cash_Balances_Users_summary->rowAttributes(); ?>>
<?php if ($E_Cash_Balances_Users_summary->currCode->Visible) { ?>
		<td data-field="currCode"<?php echo $E_Cash_Balances_Users_summary->currCode->cellAttributes(); ?>><span class="ew-group-toggle icon-collapse"></span></td>
<?php } ?>
		<td data-field="currCode" colspan="<?php echo ($Page->GroupColumnCount + $Page->DetailColumnCount - 1) ?>"<?php echo $E_Cash_Balances_Users_summary->currCode->cellAttributes() ?>>
<?php if ($E_Cash_Balances_Users_summary->sortUrl($E_Cash_Balances_Users_summary->currCode) == "") { ?>
		<span class="ew-summary-caption E_Cash_Balances_Users_currCode"><span class="ew-table-header-caption"><?php echo $E_Cash_Balances_Users_summary->currCode->caption() ?></span></span>
<?php } else { ?>
		<span class="ew-table-header-btn ew-pointer ew-summary-caption E_Cash_Balances_Users_currCode" onclick="ew.sort(event, '<?php echo $E_Cash_Balances_Users_summary->sortUrl($E_Cash_Balances_Users_summary->currCode) ?>', 1);">
			<span class="ew-table-header-caption"><?php echo $E_Cash_Balances_Users_summary->currCode->caption() ?></span>
			<span class="ew-table-header-sort"><?php if ($E_Cash_Balances_Users_summary->currCode->getSort() == "ASC") { ?><i class="fas fa-sort-up"></i><?php } elseif ($E_Cash_Balances_Users_summary->currCode->getSort() == "DESC") { ?><i class="fas fa-sort-down"></i><?php } ?></span>
		</span>
<?php } ?>
		<?php echo $Language->phrase("SummaryColon") ?><span<?php echo $E_Cash_Balances_Users_summary->currCode->viewAttributes() ?>><?php echo $E_Cash_Balances_Users_summary->currCode->GroupViewValue ?></span>
		<span class="ew-summary-count">(<span class="ew-aggregate-caption"><?php echo $Language->phrase("RptCnt") ?></span><?php echo $Language->phrase("AggregateEqual") ?><span class="ew-aggregate-value"><?php echo FormatNumber($E_Cash_Balances_Users_summary->currCode->Count, 0); ?></span>)</span>
		</td>
	</tr>
<?php } ?>
<?php
	$E_Cash_Balances_Users_summary->RecordCount = 0; // Reset record count
	foreach ($E_Cash_Balances_Users_summary->currCode->Records as $record) {
		$E_Cash_Balances_Users_summary->RecordCount++;
		$E_Cash_Balances_Users_summary->RecordIndex++;
		$E_Cash_Balances_Users_summary->loadRowValues($record);
?>
<?php

		// Render detail row
		$E_Cash_Balances_Users_summary->resetAttributes();
		$E_Cash_Balances_Users_summary->RowType = ROWTYPE_DETAIL;
		$E_Cash_Balances_Users_summary->renderRow();
?>
	<tr<?php echo $E_Cash_Balances_Users_summary->rowAttributes(); ?>>
<?php if ($E_Cash_Balances_Users_summary->currCode->Visible) { ?>
	<?php if ($E_Cash_Balances_Users_summary->currCode->ShowGroupHeaderAsRow) { ?>
		<td data-field="currCode"<?php echo $E_Cash_Balances_Users_summary->currCode->cellAttributes(); ?>>&nbsp;</td>
	<?php } else { ?>
		<td data-field="currCode"<?php echo $E_Cash_Balances_Users_summary->currCode->cellAttributes(); ?>><span<?php echo $E_Cash_Balances_Users_summary->currCode->viewAttributes() ?>><?php echo $E_Cash_Balances_Users_summary->currCode->GroupViewValue ?></span></td>
	<?php } ?>
<?php } ?>
<?php if ($E_Cash_Balances_Users_summary->firstName->Visible) { ?>
		<td data-field="firstName"<?php echo $E_Cash_Balances_Users_summary->firstName->cellAttributes() ?>>
<span<?php echo $E_Cash_Balances_Users_summary->firstName->viewAttributes() ?>><?php echo $E_Cash_Balances_Users_summary->firstName->getViewValue() ?></span>
</td>
<?php } ?>
<?php if ($E_Cash_Balances_Users_summary->lastName->Visible) { ?>
		<td data-field="lastName"<?php echo $E_Cash_Balances_Users_summary->lastName->cellAttributes() ?>>
<span<?php echo $E_Cash_Balances_Users_summary->lastName->viewAttributes() ?>><?php echo $E_Cash_Balances_Users_summary->lastName->getViewValue() ?></span>
</td>
<?php } ?>
<?php if ($E_Cash_Balances_Users_summary->_userid->Visible) { ?>
		<td data-field="_userid"<?php echo $E_Cash_Balances_Users_summary->_userid->cellAttributes() ?>>
<span<?php echo $E_Cash_Balances_Users_summary->_userid->viewAttributes() ?>><?php echo $E_Cash_Balances_Users_summary->_userid->getViewValue() ?></span>
</td>
<?php } ?>
<?php if ($E_Cash_Balances_Users_summary->rolename->Visible) { ?>
		<td data-field="rolename"<?php echo $E_Cash_Balances_Users_summary->rolename->cellAttributes() ?>>
<span<?php echo $E_Cash_Balances_Users_summary->rolename->viewAttributes() ?>><?php echo $E_Cash_Balances_Users_summary->rolename->getViewValue() ?></span>
</td>
<?php } ?>
<?php if ($E_Cash_Balances_Users_summary->userType->Visible) { ?>
		<td data-field="userType"<?php echo $E_Cash_Balances_Users_summary->userType->cellAttributes() ?>>
<span<?php echo $E_Cash_Balances_Users_summary->userType->viewAttributes() ?>><?php echo $E_Cash_Balances_Users_summary->userType->getViewValue() ?></span>
</td>
<?php } ?>
<?php if ($E_Cash_Balances_Users_summary->usersubtype->Visible) { ?>
		<td data-field="usersubtype"<?php echo $E_Cash_Balances_Users_summary->usersubtype->cellAttributes() ?>>
<span<?php echo $E_Cash_Balances_Users_summary->usersubtype->viewAttributes() ?>><?php echo $E_Cash_Balances_Users_summary->usersubtype->getViewValue() ?></span>
</td>
<?php } ?>
<?php if ($E_Cash_Balances_Users_summary->availablebalance->Visible) { ?>
		<td data-field="availablebalance"<?php echo $E_Cash_Balances_Users_summary->availablebalance->cellAttributes() ?>>
<span<?php echo $E_Cash_Balances_Users_summary->availablebalance->viewAttributes() ?>><?php echo $E_Cash_Balances_Users_summary->availablebalance->getViewValue() ?></span>
</td>
<?php } ?>
<?php if ($E_Cash_Balances_Users_summary->unavailablebalance->Visible) { ?>
		<td data-field="unavailablebalance"<?php echo $E_Cash_Balances_Users_summary->unavailablebalance->cellAttributes() ?>>
<span<?php echo $E_Cash_Balances_Users_summary->unavailablebalance->viewAttributes() ?>><?php echo $E_Cash_Balances_Users_summary->unavailablebalance->getViewValue() ?></span>
</td>
<?php } ?>
<?php if ($E_Cash_Balances_Users_summary->accountID->Visible) { ?>
		<td data-field="accountID"<?php echo $E_Cash_Balances_Users_summary->accountID->cellAttributes() ?>>
<span<?php echo $E_Cash_Balances_Users_summary->accountID->viewAttributes() ?>><?php echo $E_Cash_Balances_Users_summary->accountID->getViewValue() ?></span>
</td>
<?php } ?>
	</tr>
<?php
	}
?>
<?php

	// Next group
	$E_Cash_Balances_Users_summary->loadGroupRowValues();

	// Show header if page break
	if ($E_Cash_Balances_Users_summary->isExport())
		$E_Cash_Balances_Users_summary->ShowHeader = ($E_Cash_Balances_Users_summary->ExportPageBreakCount == 0) ? FALSE : ($E_Cash_Balances_Users_summary->GroupCount % $E_Cash_Balances_Users_summary->ExportPageBreakCount == 0);

	// Page_Breaking server event
	if ($E_Cash_Balances_Users_summary->ShowHeader)
		$E_Cash_Balances_Users_summary->Page_Breaking($E_Cash_Balances_Users_summary->ShowHeader, $E_Cash_Balances_Users_summary->PageBreakContent);
	$E_Cash_Balances_Users_summary->GroupCount++;
} // End while
?>
<?php if ($E_Cash_Balances_Users_summary->TotalGroups > 0) { ?>
</tbody>
<tfoot>
<?php
	$E_Cash_Balances_Users_summary->resetAttributes();
	$E_Cash_Balances_Users_summary->RowType = ROWTYPE_TOTAL;
	$E_Cash_Balances_Users_summary->RowTotalType = ROWTOTAL_GRAND;
	$E_Cash_Balances_Users_summary->RowTotalSubType = ROWTOTAL_FOOTER;
	$E_Cash_Balances_Users_summary->RowAttrs["class"] = "ew-rpt-grand-summary";
	$E_Cash_Balances_Users_summary->renderRow();
?>
<?php if ($E_Cash_Balances_Users_summary->currCode->ShowCompactSummaryFooter) { ?>
	<tr<?php echo $E_Cash_Balances_Users_summary->rowAttributes() ?>><td colspan="<?php echo ($E_Cash_Balances_Users_summary->GroupColumnCount + $E_Cash_Balances_Users_summary->DetailColumnCount) ?>"><?php echo $Language->phrase("RptGrandSummary") ?> <span class="ew-summary-count">(<span class="ew-aggregate-caption"><?php echo $Language->phrase("RptCnt") ?></span><?php echo $Language->phrase("AggregateEqual") ?><span class="ew-aggregate-value"><?php echo FormatNumber($E_Cash_Balances_Users_summary->TotalCount, 0); ?></span>)</span></td></tr>
	<tr<?php echo $E_Cash_Balances_Users_summary->rowAttributes() ?>>
<?php if ($E_Cash_Balances_Users_summary->GroupColumnCount > 0) { ?>
		<td colspan="<?php echo $E_Cash_Balances_Users_summary->GroupColumnCount ?>" class="ew-rpt-grp-aggregate">&nbsp;</td>
<?php } ?>
<?php if ($E_Cash_Balances_Users_summary->firstName->Visible) { ?>
		<td data-field="firstName"<?php echo $E_Cash_Balances_Users_summary->firstName->cellAttributes() ?>></td>
<?php } ?>
<?php if ($E_Cash_Balances_Users_summary->lastName->Visible) { ?>
		<td data-field="lastName"<?php echo $E_Cash_Balances_Users_summary->lastName->cellAttributes() ?>></td>
<?php } ?>
<?php if ($E_Cash_Balances_Users_summary->_userid->Visible) { ?>
		<td data-field="_userid"<?php echo $E_Cash_Balances_Users_summary->_userid->cellAttributes() ?>></td>
<?php } ?>
<?php if ($E_Cash_Balances_Users_summary->rolename->Visible) { ?>
		<td data-field="rolename"<?php echo $E_Cash_Balances_Users_summary->rolename->cellAttributes() ?>></td>
<?php } ?>
<?php if ($E_Cash_Balances_Users_summary->userType->Visible) { ?>
		<td data-field="userType"<?php echo $E_Cash_Balances_Users_summary->userType->cellAttributes() ?>></td>
<?php } ?>
<?php if ($E_Cash_Balances_Users_summary->usersubtype->Visible) { ?>
		<td data-field="usersubtype"<?php echo $E_Cash_Balances_Users_summary->usersubtype->cellAttributes() ?>></td>
<?php } ?>
<?php if ($E_Cash_Balances_Users_summary->availablebalance->Visible) { ?>
		<td data-field="availablebalance"<?php echo $E_Cash_Balances_Users_summary->availablebalance->cellAttributes() ?>><span class="ew-aggregate-caption"><?php echo $Language->phrase("RptSum") ?></span><?php echo $Language->phrase("AggregateEqual") ?><span class="ew-aggregate-value"><span<?php echo $E_Cash_Balances_Users_summary->availablebalance->viewAttributes() ?>><?php echo $E_Cash_Balances_Users_summary->availablebalance->SumViewValue ?></span></span></td>
<?php } ?>
<?php if ($E_Cash_Balances_Users_summary->unavailablebalance->Visible) { ?>
		<td data-field="unavailablebalance"<?php echo $E_Cash_Balances_Users_summary->unavailablebalance->cellAttributes() ?>><span class="ew-aggregate-caption"><?php echo $Language->phrase("RptSum") ?></span><?php echo $Language->phrase("AggregateEqual") ?><span class="ew-aggregate-value"><span<?php echo $E_Cash_Balances_Users_summary->unavailablebalance->viewAttributes() ?>><?php echo $E_Cash_Balances_Users_summary->unavailablebalance->SumViewValue ?></span></span></td>
<?php } ?>
<?php if ($E_Cash_Balances_Users_summary->accountID->Visible) { ?>
		<td data-field="accountID"<?php echo $E_Cash_Balances_Users_summary->accountID->cellAttributes() ?>></td>
<?php } ?>
	</tr>
<?php } else { ?>
	<tr<?php echo $E_Cash_Balances_Users_summary->rowAttributes() ?>><td colspan="<?php echo ($E_Cash_Balances_Users_summary->GroupColumnCount + $E_Cash_Balances_Users_summary->DetailColumnCount) ?>"><?php echo $Language->phrase("RptGrandSummary") ?> <span class="ew-summary-count">(<?php echo FormatNumber($E_Cash_Balances_Users_summary->TotalCount, 0); ?><?php echo $Language->phrase("RptDtlRec") ?>)</span></td></tr>
	<tr<?php echo $E_Cash_Balances_Users_summary->rowAttributes() ?>>
<?php if ($E_Cash_Balances_Users_summary->GroupColumnCount > 0) { ?>
		<td colspan="<?php echo $E_Cash_Balances_Users_summary->GroupColumnCount ?>" class="ew-rpt-grp-aggregate"><?php echo $Language->phrase("RptSum") ?></td>
<?php } ?>
<?php if ($E_Cash_Balances_Users_summary->firstName->Visible) { ?>
		<td data-field="firstName"<?php echo $E_Cash_Balances_Users_summary->firstName->cellAttributes() ?>>&nbsp;</td>
<?php } ?>
<?php if ($E_Cash_Balances_Users_summary->lastName->Visible) { ?>
		<td data-field="lastName"<?php echo $E_Cash_Balances_Users_summary->lastName->cellAttributes() ?>>&nbsp;</td>
<?php } ?>
<?php if ($E_Cash_Balances_Users_summary->_userid->Visible) { ?>
		<td data-field="_userid"<?php echo $E_Cash_Balances_Users_summary->_userid->cellAttributes() ?>>&nbsp;</td>
<?php } ?>
<?php if ($E_Cash_Balances_Users_summary->rolename->Visible) { ?>
		<td data-field="rolename"<?php echo $E_Cash_Balances_Users_summary->rolename->cellAttributes() ?>>&nbsp;</td>
<?php } ?>
<?php if ($E_Cash_Balances_Users_summary->userType->Visible) { ?>
		<td data-field="userType"<?php echo $E_Cash_Balances_Users_summary->userType->cellAttributes() ?>>&nbsp;</td>
<?php } ?>
<?php if ($E_Cash_Balances_Users_summary->usersubtype->Visible) { ?>
		<td data-field="usersubtype"<?php echo $E_Cash_Balances_Users_summary->usersubtype->cellAttributes() ?>>&nbsp;</td>
<?php } ?>
<?php if ($E_Cash_Balances_Users_summary->availablebalance->Visible) { ?>
		<td data-field="availablebalance"<?php echo $E_Cash_Balances_Users_summary->availablebalance->cellAttributes() ?>>
<span<?php echo $E_Cash_Balances_Users_summary->availablebalance->viewAttributes() ?>><?php echo $E_Cash_Balances_Users_summary->availablebalance->SumViewValue ?></span>
</td>
<?php } ?>
<?php if ($E_Cash_Balances_Users_summary->unavailablebalance->Visible) { ?>
		<td data-field="unavailablebalance"<?php echo $E_Cash_Balances_Users_summary->unavailablebalance->cellAttributes() ?>>
<span<?php echo $E_Cash_Balances_Users_summary->unavailablebalance->viewAttributes() ?>><?php echo $E_Cash_Balances_Users_summary->unavailablebalance->SumViewValue ?></span>
</td>
<?php } ?>
<?php if ($E_Cash_Balances_Users_summary->accountID->Visible) { ?>
		<td data-field="accountID"<?php echo $E_Cash_Balances_Users_summary->accountID->cellAttributes() ?>>&nbsp;</td>
<?php } ?>
	</tr>
<?php } ?>
</tfoot>
</table>
</div>
<!-- /.ew-grid-middle-panel -->
<!-- Report grid (end) -->
<?php if (!$E_Cash_Balances_Users_summary->isExport() && !($E_Cash_Balances_Users_summary->DrillDown && $E_Cash_Balances_Users_summary->TotalGroups > 0)) { ?>
<!-- Bottom pager -->
<div class="card-footer ew-grid-lower-panel">
<form name="ew-pager-form" class="form-inline ew-form ew-pager-form" action="<?php echo CurrentPageName() ?>">
<?php echo $E_Cash_Balances_Users_summary->Pager->render() ?>
</form>
<div class="clearfix"></div>
</div>
<?php } ?>
</div>
<!-- /.ew-grid -->
<?php } ?>
</div>
<!-- /#report-summary -->
<!-- Summary report (end) -->
<?php if ((!$E_Cash_Balances_Users_summary->isExport() || $E_Cash_Balances_Users_summary->isExport("print")) && !$DashboardReport) { ?>
</div>
<!-- /#ew-center -->
<?php } ?>
<?php if ((!$E_Cash_Balances_Users_summary->isExport() || $E_Cash_Balances_Users_summary->isExport("print")) && !$DashboardReport) { ?>
</div>
<!-- /.row -->
<?php } ?>
<?php if ((!$E_Cash_Balances_Users_summary->isExport() || $E_Cash_Balances_Users_summary->isExport("print")) && !$DashboardReport) { ?>
</div>
<!-- /.ew-report -->
<?php } ?>
<?php
$E_Cash_Balances_Users_summary->showPageFooter();
if (Config("DEBUG"))
	echo GetDebugMessage();
?>
<?php if (!$E_Cash_Balances_Users_summary->isExport() && !$E_Cash_Balances_Users_summary->DrillDown && !$DashboardReport) { ?>
<script>
loadjs.ready("load", function() {

	// Startup script
	// Write your table-specific startup script here
	// console.log("page loaded");

});
</script>
<?php } ?>
<?php if (!$DashboardReport) { ?>
<?php include_once "footer.php"; ?>
<?php } ?>
<?php
$E_Cash_Balances_Users_summary->terminate();
?>