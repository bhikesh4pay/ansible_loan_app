<?php
namespace PHPMaker2020\_4payadmin;

// Autoload
include_once "autoload.php";

// Session
if (session_status() !== PHP_SESSION_ACTIVE)
	\Delight\Cookie\Session::start(Config("COOKIE_SAMESITE")); // Init session data

// Output buffering
ob_start();
?>
<?php

// Write header
WriteHeader(FALSE);

// Create page object
$merchantsubscriptioncatassigned_list = new merchantsubscriptioncatassigned_list();

// Run the page
$merchantsubscriptioncatassigned_list->run();

// Setup login status
SetupLoginStatus();
SetClientVar("login", LoginStatus());

// Global Page Rendering event (in userfn*.php)
Page_Rendering();

// Page Rendering event
$merchantsubscriptioncatassigned_list->Page_Render();
?>
<?php include_once "header.php"; ?>
<?php if (!$merchantsubscriptioncatassigned_list->isExport()) { ?>
<script>
var fmerchantsubscriptioncatassignedlist, currentPageID;
loadjs.ready("head", function() {

	// Form object
	currentPageID = ew.PAGE_ID = "list";
	fmerchantsubscriptioncatassignedlist = currentForm = new ew.Form("fmerchantsubscriptioncatassignedlist", "list");
	fmerchantsubscriptioncatassignedlist.formKeyCountName = '<?php echo $merchantsubscriptioncatassigned_list->FormKeyCountName ?>';
	loadjs.done("fmerchantsubscriptioncatassignedlist");
});
var fmerchantsubscriptioncatassignedlistsrch;
loadjs.ready("head", function() {

	// Form object for search
	fmerchantsubscriptioncatassignedlistsrch = currentSearchForm = new ew.Form("fmerchantsubscriptioncatassignedlistsrch");

	// Dynamic selection lists
	// Filters

	fmerchantsubscriptioncatassignedlistsrch.filterList = <?php echo $merchantsubscriptioncatassigned_list->getFilterList() ?>;

	// Init search panel as collapsed
	fmerchantsubscriptioncatassignedlistsrch.initSearchPanel = true;
	loadjs.done("fmerchantsubscriptioncatassignedlistsrch");
});
</script>
<style type="text/css">
.ew-table-preview-row { /* main table preview row color */
	background-color: #FFFFFF; /* preview row color */
}
.ew-table-preview-row .ew-grid {
	display: table;
}
</style>
<div id="ew-preview" class="d-none"><!-- preview -->
	<div class="ew-nav-tabs"><!-- .ew-nav-tabs -->
		<ul class="nav nav-tabs"></ul>
		<div class="tab-content"><!-- .tab-content -->
			<div class="tab-pane fade active show"></div>
		</div><!-- /.tab-content -->
	</div><!-- /.ew-nav-tabs -->
</div><!-- /preview -->
<script>
loadjs.ready("head", function() {
	ew.PREVIEW_PLACEMENT = ew.CSS_FLIP ? "right" : "left";
	ew.PREVIEW_SINGLE_ROW = false;
	ew.PREVIEW_OVERLAY = false;
	loadjs("js/ewpreview.js", "preview");
});
</script>
<script>
loadjs.ready("head", function() {

	// Client script
	// Write your client script here, no need to add script tags.

});
</script>
<?php } ?>
<?php if (!$merchantsubscriptioncatassigned_list->isExport()) { ?>
<div class="btn-toolbar ew-toolbar">
<?php if ($merchantsubscriptioncatassigned_list->TotalRecords > 0 && $merchantsubscriptioncatassigned_list->ExportOptions->visible()) { ?>
<?php $merchantsubscriptioncatassigned_list->ExportOptions->render("body") ?>
<?php } ?>
<?php if ($merchantsubscriptioncatassigned_list->ImportOptions->visible()) { ?>
<?php $merchantsubscriptioncatassigned_list->ImportOptions->render("body") ?>
<?php } ?>
<?php if ($merchantsubscriptioncatassigned_list->SearchOptions->visible()) { ?>
<?php $merchantsubscriptioncatassigned_list->SearchOptions->render("body") ?>
<?php } ?>
<?php if ($merchantsubscriptioncatassigned_list->FilterOptions->visible()) { ?>
<?php $merchantsubscriptioncatassigned_list->FilterOptions->render("body") ?>
<?php } ?>
<div class="clearfix"></div>
</div>
<?php } ?>
<?php
$merchantsubscriptioncatassigned_list->renderOtherOptions();
?>
<?php $merchantsubscriptioncatassigned_list->showPageHeader(); ?>
<?php
$merchantsubscriptioncatassigned_list->showMessage();
?>
<?php if ($merchantsubscriptioncatassigned_list->TotalRecords > 0 || $merchantsubscriptioncatassigned->CurrentAction) { ?>
<div class="card ew-card ew-grid<?php if ($merchantsubscriptioncatassigned_list->isAddOrEdit()) { ?> ew-grid-add-edit<?php } ?> merchantsubscriptioncatassigned">
<form name="fmerchantsubscriptioncatassignedlist" id="fmerchantsubscriptioncatassignedlist" class="form-inline ew-form ew-list-form" action="<?php echo CurrentPageName() ?>" method="post">
<?php if ($Page->CheckToken) { ?>
<input type="hidden" name="<?php echo Config("TOKEN_NAME") ?>" value="<?php echo $Page->Token ?>">
<?php } ?>
<input type="hidden" name="t" value="merchantsubscriptioncatassigned">
<div id="gmp_merchantsubscriptioncatassigned" class="<?php echo ResponsiveTableClass() ?>card-body ew-grid-middle-panel">
<?php if ($merchantsubscriptioncatassigned_list->TotalRecords > 0 || $merchantsubscriptioncatassigned_list->isGridEdit()) { ?>
<table id="tbl_merchantsubscriptioncatassignedlist" class="table ew-table"><!-- .ew-table -->
<thead>
	<tr class="ew-table-header">
<?php

// Header row
$merchantsubscriptioncatassigned->RowType = ROWTYPE_HEADER;

// Render list options
$merchantsubscriptioncatassigned_list->renderListOptions();

// Render list options (header, left)
$merchantsubscriptioncatassigned_list->ListOptions->render("header", "left");
?>
<?php if ($merchantsubscriptioncatassigned_list->subscriptionid->Visible) { // subscriptionid ?>
	<?php if ($merchantsubscriptioncatassigned_list->SortUrl($merchantsubscriptioncatassigned_list->subscriptionid) == "") { ?>
		<th data-name="subscriptionid" class="<?php echo $merchantsubscriptioncatassigned_list->subscriptionid->headerCellClass() ?>"><div id="elh_merchantsubscriptioncatassigned_subscriptionid" class="merchantsubscriptioncatassigned_subscriptionid"><div class="ew-table-header-caption"><?php echo $merchantsubscriptioncatassigned_list->subscriptionid->caption() ?></div></div></th>
	<?php } else { ?>
		<th data-name="subscriptionid" class="<?php echo $merchantsubscriptioncatassigned_list->subscriptionid->headerCellClass() ?>"><div class="ew-pointer" onclick="ew.sort(event, '<?php echo $merchantsubscriptioncatassigned_list->SortUrl($merchantsubscriptioncatassigned_list->subscriptionid) ?>', 1);"><div id="elh_merchantsubscriptioncatassigned_subscriptionid" class="merchantsubscriptioncatassigned_subscriptionid">
			<div class="ew-table-header-btn"><span class="ew-table-header-caption"><?php echo $merchantsubscriptioncatassigned_list->subscriptionid->caption() ?></span><span class="ew-table-header-sort"><?php if ($merchantsubscriptioncatassigned_list->subscriptionid->getSort() == "ASC") { ?><i class="fas fa-sort-up"></i><?php } elseif ($merchantsubscriptioncatassigned_list->subscriptionid->getSort() == "DESC") { ?><i class="fas fa-sort-down"></i><?php } ?></span></div>
		</div></div></th>
	<?php } ?>
<?php } ?>
<?php if ($merchantsubscriptioncatassigned_list->categoryid->Visible) { // categoryid ?>
	<?php if ($merchantsubscriptioncatassigned_list->SortUrl($merchantsubscriptioncatassigned_list->categoryid) == "") { ?>
		<th data-name="categoryid" class="<?php echo $merchantsubscriptioncatassigned_list->categoryid->headerCellClass() ?>"><div id="elh_merchantsubscriptioncatassigned_categoryid" class="merchantsubscriptioncatassigned_categoryid"><div class="ew-table-header-caption"><?php echo $merchantsubscriptioncatassigned_list->categoryid->caption() ?></div></div></th>
	<?php } else { ?>
		<th data-name="categoryid" class="<?php echo $merchantsubscriptioncatassigned_list->categoryid->headerCellClass() ?>"><div class="ew-pointer" onclick="ew.sort(event, '<?php echo $merchantsubscriptioncatassigned_list->SortUrl($merchantsubscriptioncatassigned_list->categoryid) ?>', 1);"><div id="elh_merchantsubscriptioncatassigned_categoryid" class="merchantsubscriptioncatassigned_categoryid">
			<div class="ew-table-header-btn"><span class="ew-table-header-caption"><?php echo $merchantsubscriptioncatassigned_list->categoryid->caption() ?></span><span class="ew-table-header-sort"><?php if ($merchantsubscriptioncatassigned_list->categoryid->getSort() == "ASC") { ?><i class="fas fa-sort-up"></i><?php } elseif ($merchantsubscriptioncatassigned_list->categoryid->getSort() == "DESC") { ?><i class="fas fa-sort-down"></i><?php } ?></span></div>
		</div></div></th>
	<?php } ?>
<?php } ?>
<?php

// Render list options (header, right)
$merchantsubscriptioncatassigned_list->ListOptions->render("header", "right");
?>
	</tr>
</thead>
<tbody>
<?php
if ($merchantsubscriptioncatassigned_list->ExportAll && $merchantsubscriptioncatassigned_list->isExport()) {
	$merchantsubscriptioncatassigned_list->StopRecord = $merchantsubscriptioncatassigned_list->TotalRecords;
} else {

	// Set the last record to display
	if ($merchantsubscriptioncatassigned_list->TotalRecords > $merchantsubscriptioncatassigned_list->StartRecord + $merchantsubscriptioncatassigned_list->DisplayRecords - 1)
		$merchantsubscriptioncatassigned_list->StopRecord = $merchantsubscriptioncatassigned_list->StartRecord + $merchantsubscriptioncatassigned_list->DisplayRecords - 1;
	else
		$merchantsubscriptioncatassigned_list->StopRecord = $merchantsubscriptioncatassigned_list->TotalRecords;
}
$merchantsubscriptioncatassigned_list->RecordCount = $merchantsubscriptioncatassigned_list->StartRecord - 1;
if ($merchantsubscriptioncatassigned_list->Recordset && !$merchantsubscriptioncatassigned_list->Recordset->EOF) {
	$merchantsubscriptioncatassigned_list->Recordset->moveFirst();
	$selectLimit = $merchantsubscriptioncatassigned_list->UseSelectLimit;
	if (!$selectLimit && $merchantsubscriptioncatassigned_list->StartRecord > 1)
		$merchantsubscriptioncatassigned_list->Recordset->move($merchantsubscriptioncatassigned_list->StartRecord - 1);
} elseif (!$merchantsubscriptioncatassigned->AllowAddDeleteRow && $merchantsubscriptioncatassigned_list->StopRecord == 0) {
	$merchantsubscriptioncatassigned_list->StopRecord = $merchantsubscriptioncatassigned->GridAddRowCount;
}

// Initialize aggregate
$merchantsubscriptioncatassigned->RowType = ROWTYPE_AGGREGATEINIT;
$merchantsubscriptioncatassigned->resetAttributes();
$merchantsubscriptioncatassigned_list->renderRow();
while ($merchantsubscriptioncatassigned_list->RecordCount < $merchantsubscriptioncatassigned_list->StopRecord) {
	$merchantsubscriptioncatassigned_list->RecordCount++;
	if ($merchantsubscriptioncatassigned_list->RecordCount >= $merchantsubscriptioncatassigned_list->StartRecord) {
		$merchantsubscriptioncatassigned_list->RowCount++;

		// Set up key count
		$merchantsubscriptioncatassigned_list->KeyCount = $merchantsubscriptioncatassigned_list->RowIndex;

		// Init row class and style
		$merchantsubscriptioncatassigned->resetAttributes();
		$merchantsubscriptioncatassigned->CssClass = "";
		if ($merchantsubscriptioncatassigned_list->isGridAdd()) {
		} else {
			$merchantsubscriptioncatassigned_list->loadRowValues($merchantsubscriptioncatassigned_list->Recordset); // Load row values
		}
		$merchantsubscriptioncatassigned->RowType = ROWTYPE_VIEW; // Render view

		// Set up row id / data-rowindex
		$merchantsubscriptioncatassigned->RowAttrs->merge(["data-rowindex" => $merchantsubscriptioncatassigned_list->RowCount, "id" => "r" . $merchantsubscriptioncatassigned_list->RowCount . "_merchantsubscriptioncatassigned", "data-rowtype" => $merchantsubscriptioncatassigned->RowType]);

		// Render row
		$merchantsubscriptioncatassigned_list->renderRow();

		// Render list options
		$merchantsubscriptioncatassigned_list->renderListOptions();
?>
	<tr <?php echo $merchantsubscriptioncatassigned->rowAttributes() ?>>
<?php

// Render list options (body, left)
$merchantsubscriptioncatassigned_list->ListOptions->render("body", "left", $merchantsubscriptioncatassigned_list->RowCount);
?>
	<?php if ($merchantsubscriptioncatassigned_list->subscriptionid->Visible) { // subscriptionid ?>
		<td data-name="subscriptionid" <?php echo $merchantsubscriptioncatassigned_list->subscriptionid->cellAttributes() ?>>
<span id="el<?php echo $merchantsubscriptioncatassigned_list->RowCount ?>_merchantsubscriptioncatassigned_subscriptionid">
<span<?php echo $merchantsubscriptioncatassigned_list->subscriptionid->viewAttributes() ?>><?php echo $merchantsubscriptioncatassigned_list->subscriptionid->getViewValue() ?></span>
</span>
</td>
	<?php } ?>
	<?php if ($merchantsubscriptioncatassigned_list->categoryid->Visible) { // categoryid ?>
		<td data-name="categoryid" <?php echo $merchantsubscriptioncatassigned_list->categoryid->cellAttributes() ?>>
<span id="el<?php echo $merchantsubscriptioncatassigned_list->RowCount ?>_merchantsubscriptioncatassigned_categoryid">
<span<?php echo $merchantsubscriptioncatassigned_list->categoryid->viewAttributes() ?>><?php echo $merchantsubscriptioncatassigned_list->categoryid->getViewValue() ?></span>
</span>
</td>
	<?php } ?>
<?php

// Render list options (body, right)
$merchantsubscriptioncatassigned_list->ListOptions->render("body", "right", $merchantsubscriptioncatassigned_list->RowCount);
?>
	</tr>
<?php
	}
	if (!$merchantsubscriptioncatassigned_list->isGridAdd())
		$merchantsubscriptioncatassigned_list->Recordset->moveNext();
}
?>
</tbody>
</table><!-- /.ew-table -->
<?php } ?>
</div><!-- /.ew-grid-middle-panel -->
<?php if (!$merchantsubscriptioncatassigned->CurrentAction) { ?>
<input type="hidden" name="action" id="action" value="">
<?php } ?>
</form><!-- /.ew-list-form -->
<?php

// Close recordset
if ($merchantsubscriptioncatassigned_list->Recordset)
	$merchantsubscriptioncatassigned_list->Recordset->Close();
?>
<?php if (!$merchantsubscriptioncatassigned_list->isExport()) { ?>
<div class="card-footer ew-grid-lower-panel">
<?php if (!$merchantsubscriptioncatassigned_list->isGridAdd()) { ?>
<form name="ew-pager-form" class="form-inline ew-form ew-pager-form" action="<?php echo CurrentPageName() ?>">
<?php echo $merchantsubscriptioncatassigned_list->Pager->render() ?>
</form>
<?php } ?>
<div class="ew-list-other-options">
<?php $merchantsubscriptioncatassigned_list->OtherOptions->render("body", "bottom") ?>
</div>
<div class="clearfix"></div>
</div>
<?php } ?>
</div><!-- /.ew-grid -->
<?php } ?>
<?php if ($merchantsubscriptioncatassigned_list->TotalRecords == 0 && !$merchantsubscriptioncatassigned->CurrentAction) { // Show other options ?>
<div class="ew-list-other-options">
<?php $merchantsubscriptioncatassigned_list->OtherOptions->render("body") ?>
</div>
<div class="clearfix"></div>
<?php } ?>
<?php
$merchantsubscriptioncatassigned_list->showPageFooter();
if (Config("DEBUG"))
	echo GetDebugMessage();
?>
<?php if (!$merchantsubscriptioncatassigned_list->isExport()) { ?>
<script>
loadjs.ready("load", function() {

	// Startup script
	// Write your table-specific startup script here
	// console.log("page loaded");

});
</script>
<?php } ?>
<?php include_once "footer.php"; ?>
<?php
$merchantsubscriptioncatassigned_list->terminate();
?>