<?php
namespace PHPMaker2020\_4payadmin;

// Autoload
include_once "autoload.php";

// Session
if (session_status() !== PHP_SESSION_ACTIVE)
	\Delight\Cookie\Session::start(Config("COOKIE_SAMESITE")); // Init session data

// Output buffering
ob_start();
?>
<?php

// Write header
WriteHeader(FALSE);

// Create page object
$Voucher2FWithdrawal_Summary_summary = new Voucher2FWithdrawal_Summary_summary();

// Run the page
$Voucher2FWithdrawal_Summary_summary->run();

// Setup login status
SetupLoginStatus();
SetClientVar("login", LoginStatus());

// Global Page Rendering event (in userfn*.php)
Page_Rendering();

// Page Rendering event
$Voucher2FWithdrawal_Summary_summary->Page_Render();
?>
<?php if (!$DashboardReport) { ?>
<?php include_once "header.php"; ?>
<?php } ?>
<?php if (!$Voucher2FWithdrawal_Summary_summary->isExport() && !$Voucher2FWithdrawal_Summary_summary->DrillDown && !$DashboardReport) { ?>
<script>
var fsummary, currentPageID;
loadjs.ready("head", function() {

	// Form object for search
	fsummary = currentForm = new ew.Form("fsummary", "summary");
	currentPageID = ew.PAGE_ID = "summary";

	// Validate function for search
	fsummary.validate = function(fobj) {
		if (!this.validateRequired)
			return true; // Ignore validation
		fobj = fobj || this._form;
		var infix = "";
		elm = this.getElements("x" + infix + "_amountSender");
		if (elm && !ew.checkNumber(elm.value))
			return this.onError(elm, "<?php echo JsEncode($Voucher2FWithdrawal_Summary_summary->amountSender->errorMessage()) ?>");

		// Call Form_CustomValidate event
		if (!this.Form_CustomValidate(fobj))
			return false;
		return true;
	}

	// Form_CustomValidate
	fsummary.Form_CustomValidate = function(fobj) { // DO NOT CHANGE THIS LINE!

		// Your custom validation code here, return false if invalid.
		return true;
	}

	// Use JavaScript validation or not
	fsummary.validateRequired = <?php echo Config("CLIENT_VALIDATE") ? "true" : "false" ?>;

	// Dynamic selection lists
	fsummary.lists["x_transferTime"] = <?php echo $Voucher2FWithdrawal_Summary_summary->transferTime->Lookup->toClientList($Voucher2FWithdrawal_Summary_summary) ?>;
	fsummary.lists["x_transferTime"].options = <?php echo JsonEncode($Voucher2FWithdrawal_Summary_summary->transferTime->lookupOptions()) ?>;
	fsummary.lists["x_currID"] = <?php echo $Voucher2FWithdrawal_Summary_summary->currID->Lookup->toClientList($Voucher2FWithdrawal_Summary_summary) ?>;
	fsummary.lists["x_currID"].options = <?php echo JsonEncode($Voucher2FWithdrawal_Summary_summary->currID->lookupOptions()) ?>;
	fsummary.lists["x_type"] = <?php echo $Voucher2FWithdrawal_Summary_summary->type->Lookup->toClientList($Voucher2FWithdrawal_Summary_summary) ?>;
	fsummary.lists["x_type"].options = <?php echo JsonEncode($Voucher2FWithdrawal_Summary_summary->type->lookupOptions()) ?>;
	fsummary.lists["x_status"] = <?php echo $Voucher2FWithdrawal_Summary_summary->status->Lookup->toClientList($Voucher2FWithdrawal_Summary_summary) ?>;
	fsummary.lists["x_status"].options = <?php echo JsonEncode($Voucher2FWithdrawal_Summary_summary->status->lookupOptions()) ?>;

	// Filters
	fsummary.filterList = <?php echo $Voucher2FWithdrawal_Summary_summary->getFilterList() ?>;
	loadjs.done("fsummary");
});
</script>
<script>
loadjs.ready("head", function() {

	// Client script
	// Write your client script here, no need to add script tags.

});
</script>
<?php } ?>
<a id="top"></a>
<?php if ((!$Voucher2FWithdrawal_Summary_summary->isExport() || $Voucher2FWithdrawal_Summary_summary->isExport("print")) && !$DashboardReport) { ?>
<!-- Content Container -->
<div id="ew-report" class="ew-report container-fluid">
<?php } ?>
<?php if ($Voucher2FWithdrawal_Summary_summary->ShowCurrentFilter) { ?>
<?php $Voucher2FWithdrawal_Summary_summary->showFilterList() ?>
<?php } ?>
<div class="btn-toolbar ew-toolbar">
<?php
if (!$Voucher2FWithdrawal_Summary_summary->DrillDownInPanel) {
	$Voucher2FWithdrawal_Summary_summary->ExportOptions->render("body");
	$Voucher2FWithdrawal_Summary_summary->SearchOptions->render("body");
	$Voucher2FWithdrawal_Summary_summary->FilterOptions->render("body");
}
?>
</div>
<?php $Voucher2FWithdrawal_Summary_summary->showPageHeader(); ?>
<?php
$Voucher2FWithdrawal_Summary_summary->showMessage();
?>
<?php if ((!$Voucher2FWithdrawal_Summary_summary->isExport() || $Voucher2FWithdrawal_Summary_summary->isExport("print")) && !$DashboardReport) { ?>
<div class="row">
<?php } ?>
<?php if ((!$Voucher2FWithdrawal_Summary_summary->isExport() || $Voucher2FWithdrawal_Summary_summary->isExport("print")) && !$DashboardReport) { ?>
<!-- Center Container -->
<div id="ew-center" class="<?php echo $Voucher2FWithdrawal_Summary_summary->CenterContentClass ?>">
<?php } ?>
<!-- Summary report (begin) -->
<div id="report_summary">
<?php if (!$Voucher2FWithdrawal_Summary_summary->isExport() && !$Voucher2FWithdrawal_Summary_summary->DrillDown && !$DashboardReport) { ?>
<?php if ($Security->CanSearch()) { ?>
<?php if (!$Voucher2FWithdrawal_Summary_summary->isExport() && !$Voucher2FWithdrawal_Summary->CurrentAction) { ?>
<form name="fsummary" id="fsummary" class="form-inline ew-form ew-ext-search-form" action="<?php echo CurrentPageName() ?>">
<div id="fsummary-search-panel" class="<?php echo $Voucher2FWithdrawal_Summary_summary->SearchPanelClass ?>">
<input type="hidden" name="cmd" value="search">
<input type="hidden" name="t" value="Voucher2FWithdrawal_Summary">
	<div class="ew-extended-search">
<?php

// Render search row
$Voucher2FWithdrawal_Summary->RowType = ROWTYPE_SEARCH;
$Voucher2FWithdrawal_Summary->resetAttributes();
$Voucher2FWithdrawal_Summary_summary->renderRow();
?>
<?php if ($Voucher2FWithdrawal_Summary_summary->transferTime->Visible) { // transferTime ?>
	<?php
		$Voucher2FWithdrawal_Summary_summary->SearchColumnCount++;
		if (($Voucher2FWithdrawal_Summary_summary->SearchColumnCount - 1) % $Voucher2FWithdrawal_Summary_summary->SearchFieldsPerRow == 0) {
			$Voucher2FWithdrawal_Summary_summary->SearchRowCount++;
	?>
<div id="xsr_<?php echo $Voucher2FWithdrawal_Summary_summary->SearchRowCount ?>" class="ew-row d-sm-flex">
	<?php
		}
	 ?>
	<div id="xsc_transferTime" class="ew-cell form-group">
		<label for="x_transferTime" class="ew-search-caption ew-label"><?php echo $Voucher2FWithdrawal_Summary_summary->transferTime->caption() ?></label>
		<span id="el_Voucher2FWithdrawal_Summary_transferTime" class="ew-search-field">
<div class="input-group">
	<select class="custom-select ew-custom-select" data-table="Voucher2FWithdrawal_Summary" data-field="x_transferTime" data-value-separator="<?php echo $Voucher2FWithdrawal_Summary_summary->transferTime->displayValueSeparatorAttribute() ?>" id="x_transferTime" name="x_transferTime"<?php echo $Voucher2FWithdrawal_Summary_summary->transferTime->editAttributes() ?>>
			<?php echo $Voucher2FWithdrawal_Summary_summary->transferTime->selectOptionListHtml("x_transferTime") ?>
		</select>
</div>
<?php echo $Voucher2FWithdrawal_Summary_summary->transferTime->Lookup->getParamTag($Voucher2FWithdrawal_Summary_summary, "p_x_transferTime") ?>
</span>
		<span class="ew-search-and"><label><?php echo $Language->phrase("AND") ?></label></span>
		<span id="el2_Voucher2FWithdrawal_Summary_transferTime" class="ew-search-field2">
<div class="input-group">
	<select class="custom-select ew-custom-select" data-table="Voucher2FWithdrawal_Summary" data-field="x_transferTime" data-value-separator="<?php echo $Voucher2FWithdrawal_Summary_summary->transferTime->displayValueSeparatorAttribute() ?>" id="y_transferTime" name="y_transferTime"<?php echo $Voucher2FWithdrawal_Summary_summary->transferTime->editAttributes() ?>>
			<?php echo $Voucher2FWithdrawal_Summary_summary->transferTime->selectOptionListHtml("y_transferTime") ?>
		</select>
</div>
<?php echo $Voucher2FWithdrawal_Summary_summary->transferTime->Lookup->getParamTag($Voucher2FWithdrawal_Summary_summary, "p_x_transferTime") ?>
</span>
	</div>
	<?php if ($Voucher2FWithdrawal_Summary_summary->SearchColumnCount % $Voucher2FWithdrawal_Summary_summary->SearchFieldsPerRow == 0) { ?>
</div>
	<?php } ?>
<?php } ?>
<?php if ($Voucher2FWithdrawal_Summary_summary->currID->Visible) { // currID ?>
	<?php
		$Voucher2FWithdrawal_Summary_summary->SearchColumnCount++;
		if (($Voucher2FWithdrawal_Summary_summary->SearchColumnCount - 1) % $Voucher2FWithdrawal_Summary_summary->SearchFieldsPerRow == 0) {
			$Voucher2FWithdrawal_Summary_summary->SearchRowCount++;
	?>
<div id="xsr_<?php echo $Voucher2FWithdrawal_Summary_summary->SearchRowCount ?>" class="ew-row d-sm-flex">
	<?php
		}
	 ?>
	<div id="xsc_currID" class="ew-cell form-group">
		<label for="x_currID" class="ew-search-caption ew-label"><?php echo $Voucher2FWithdrawal_Summary_summary->currID->caption() ?></label>
		<span id="el_Voucher2FWithdrawal_Summary_currID" class="ew-search-field">
<div class="btn-group ew-dropdown-list" role="group">
	<div class="btn-group" role="group">
		<button type="button" class="btn form-control dropdown-toggle ew-dropdown-toggle" aria-haspopup="true" aria-expanded="false"<?php if ($Voucher2FWithdrawal_Summary_summary->currID->ReadOnly) { ?> readonly<?php } else { ?>data-toggle="dropdown"<?php } ?>><?php echo $Voucher2FWithdrawal_Summary_summary->currID->AdvancedSearch->ViewValue ?></button>
		<div id="dsl_x_currID" data-repeatcolumn="1" class="dropdown-menu">
			<div class="ew-items" style="overflow-x: hidden;">
<?php echo $Voucher2FWithdrawal_Summary_summary->currID->radioButtonListHtml(TRUE, "x_currID") ?>
			</div><!-- /.ew-items -->
		</div><!-- /.dropdown-menu -->
		<div id="tp_x_currID" class="ew-template"><input type="radio" class="custom-control-input" data-table="Voucher2FWithdrawal_Summary" data-field="x_currID" data-value-separator="<?php echo $Voucher2FWithdrawal_Summary_summary->currID->displayValueSeparatorAttribute() ?>" name="x_currID" id="x_currID" value="{value}"<?php echo $Voucher2FWithdrawal_Summary_summary->currID->editAttributes() ?>></div>
	</div><!-- /.btn-group -->
	<?php if (!$Voucher2FWithdrawal_Summary_summary->currID->ReadOnly) { ?>
	<button type="button" class="btn btn-default ew-dropdown-clear" disabled>
		<i class="fas fa-times ew-icon"></i>
	</button>
	<?php } ?>
</div><!-- /.ew-dropdown-list -->
<?php echo $Voucher2FWithdrawal_Summary_summary->currID->Lookup->getParamTag($Voucher2FWithdrawal_Summary_summary, "p_x_currID") ?>
</span>
	</div>
	<?php if ($Voucher2FWithdrawal_Summary_summary->SearchColumnCount % $Voucher2FWithdrawal_Summary_summary->SearchFieldsPerRow == 0) { ?>
</div>
	<?php } ?>
<?php } ?>
<?php if ($Voucher2FWithdrawal_Summary_summary->amountSender->Visible) { // amountSender ?>
	<?php
		$Voucher2FWithdrawal_Summary_summary->SearchColumnCount++;
		if (($Voucher2FWithdrawal_Summary_summary->SearchColumnCount - 1) % $Voucher2FWithdrawal_Summary_summary->SearchFieldsPerRow == 0) {
			$Voucher2FWithdrawal_Summary_summary->SearchRowCount++;
	?>
<div id="xsr_<?php echo $Voucher2FWithdrawal_Summary_summary->SearchRowCount ?>" class="ew-row d-sm-flex">
	<?php
		}
	 ?>
	<div id="xsc_amountSender" class="ew-cell form-group">
		<label for="x_amountSender" class="ew-search-caption ew-label"><?php echo $Voucher2FWithdrawal_Summary_summary->amountSender->caption() ?></label>
		<span class="ew-search-operator">
<?php echo $Language->phrase("BETWEEN") ?>
<input type="hidden" name="z_amountSender" id="z_amountSender" value="BETWEEN">
</span>
		<span id="el_Voucher2FWithdrawal_Summary_amountSender" class="ew-search-field">
<input type="text" data-table="Voucher2FWithdrawal_Summary" data-field="x_amountSender" name="x_amountSender" id="x_amountSender" size="30" placeholder="<?php echo HtmlEncode($Voucher2FWithdrawal_Summary_summary->amountSender->getPlaceHolder()) ?>" value="<?php echo $Voucher2FWithdrawal_Summary_summary->amountSender->EditValue ?>"<?php echo $Voucher2FWithdrawal_Summary_summary->amountSender->editAttributes() ?>>
</span>
		<span class="ew-search-and"><label><?php echo $Language->phrase("AND") ?></label></span>
		<span id="el2_Voucher2FWithdrawal_Summary_amountSender" class="ew-search-field2">
<input type="text" data-table="Voucher2FWithdrawal_Summary" data-field="x_amountSender" name="y_amountSender" id="y_amountSender" size="30" placeholder="<?php echo HtmlEncode($Voucher2FWithdrawal_Summary_summary->amountSender->getPlaceHolder()) ?>" value="<?php echo $Voucher2FWithdrawal_Summary_summary->amountSender->EditValue2 ?>"<?php echo $Voucher2FWithdrawal_Summary_summary->amountSender->editAttributes() ?>>
</span>
	</div>
	<?php if ($Voucher2FWithdrawal_Summary_summary->SearchColumnCount % $Voucher2FWithdrawal_Summary_summary->SearchFieldsPerRow == 0) { ?>
</div>
	<?php } ?>
<?php } ?>
<?php if ($Voucher2FWithdrawal_Summary_summary->type->Visible) { // type ?>
	<?php
		$Voucher2FWithdrawal_Summary_summary->SearchColumnCount++;
		if (($Voucher2FWithdrawal_Summary_summary->SearchColumnCount - 1) % $Voucher2FWithdrawal_Summary_summary->SearchFieldsPerRow == 0) {
			$Voucher2FWithdrawal_Summary_summary->SearchRowCount++;
	?>
<div id="xsr_<?php echo $Voucher2FWithdrawal_Summary_summary->SearchRowCount ?>" class="ew-row d-sm-flex">
	<?php
		}
	 ?>
	<div id="xsc_type" class="ew-cell form-group">
		<label for="x_type" class="ew-search-caption ew-label"><?php echo $Voucher2FWithdrawal_Summary_summary->type->caption() ?></label>
		<span id="el_Voucher2FWithdrawal_Summary_type" class="ew-search-field">
<div class="btn-group ew-dropdown-list" role="group">
	<div class="btn-group" role="group">
		<button type="button" class="btn form-control dropdown-toggle ew-dropdown-toggle" aria-haspopup="true" aria-expanded="false"<?php if ($Voucher2FWithdrawal_Summary_summary->type->ReadOnly) { ?> readonly<?php } else { ?>data-toggle="dropdown"<?php } ?>><?php echo $Voucher2FWithdrawal_Summary_summary->type->AdvancedSearch->ViewValue ?></button>
		<div id="dsl_x_type" data-repeatcolumn="1" class="dropdown-menu">
			<div class="ew-items" style="overflow-x: hidden;">
<?php echo $Voucher2FWithdrawal_Summary_summary->type->radioButtonListHtml(TRUE, "x_type") ?>
			</div><!-- /.ew-items -->
		</div><!-- /.dropdown-menu -->
		<div id="tp_x_type" class="ew-template"><input type="radio" class="custom-control-input" data-table="Voucher2FWithdrawal_Summary" data-field="x_type" data-value-separator="<?php echo $Voucher2FWithdrawal_Summary_summary->type->displayValueSeparatorAttribute() ?>" name="x_type" id="x_type" value="{value}"<?php echo $Voucher2FWithdrawal_Summary_summary->type->editAttributes() ?>></div>
	</div><!-- /.btn-group -->
	<?php if (!$Voucher2FWithdrawal_Summary_summary->type->ReadOnly) { ?>
	<button type="button" class="btn btn-default ew-dropdown-clear" disabled>
		<i class="fas fa-times ew-icon"></i>
	</button>
	<?php } ?>
</div><!-- /.ew-dropdown-list -->
<?php echo $Voucher2FWithdrawal_Summary_summary->type->Lookup->getParamTag($Voucher2FWithdrawal_Summary_summary, "p_x_type") ?>
</span>
	</div>
	<?php if ($Voucher2FWithdrawal_Summary_summary->SearchColumnCount % $Voucher2FWithdrawal_Summary_summary->SearchFieldsPerRow == 0) { ?>
</div>
	<?php } ?>
<?php } ?>
<?php if ($Voucher2FWithdrawal_Summary_summary->status->Visible) { // status ?>
	<?php
		$Voucher2FWithdrawal_Summary_summary->SearchColumnCount++;
		if (($Voucher2FWithdrawal_Summary_summary->SearchColumnCount - 1) % $Voucher2FWithdrawal_Summary_summary->SearchFieldsPerRow == 0) {
			$Voucher2FWithdrawal_Summary_summary->SearchRowCount++;
	?>
<div id="xsr_<?php echo $Voucher2FWithdrawal_Summary_summary->SearchRowCount ?>" class="ew-row d-sm-flex">
	<?php
		}
	 ?>
	<div id="xsc_status" class="ew-cell form-group">
		<label for="x_status" class="ew-search-caption ew-label"><?php echo $Voucher2FWithdrawal_Summary_summary->status->caption() ?></label>
		<span id="el_Voucher2FWithdrawal_Summary_status" class="ew-search-field">
<div class="btn-group ew-dropdown-list" role="group">
	<div class="btn-group" role="group">
		<button type="button" class="btn form-control dropdown-toggle ew-dropdown-toggle" aria-haspopup="true" aria-expanded="false"<?php if ($Voucher2FWithdrawal_Summary_summary->status->ReadOnly) { ?> readonly<?php } else { ?>data-toggle="dropdown"<?php } ?>><?php echo $Voucher2FWithdrawal_Summary_summary->status->AdvancedSearch->ViewValue ?></button>
		<div id="dsl_x_status" data-repeatcolumn="1" class="dropdown-menu">
			<div class="ew-items" style="overflow-x: hidden;">
<?php echo $Voucher2FWithdrawal_Summary_summary->status->radioButtonListHtml(TRUE, "x_status") ?>
			</div><!-- /.ew-items -->
		</div><!-- /.dropdown-menu -->
		<div id="tp_x_status" class="ew-template"><input type="radio" class="custom-control-input" data-table="Voucher2FWithdrawal_Summary" data-field="x_status" data-value-separator="<?php echo $Voucher2FWithdrawal_Summary_summary->status->displayValueSeparatorAttribute() ?>" name="x_status" id="x_status" value="{value}"<?php echo $Voucher2FWithdrawal_Summary_summary->status->editAttributes() ?>></div>
	</div><!-- /.btn-group -->
	<?php if (!$Voucher2FWithdrawal_Summary_summary->status->ReadOnly) { ?>
	<button type="button" class="btn btn-default ew-dropdown-clear" disabled>
		<i class="fas fa-times ew-icon"></i>
	</button>
	<?php } ?>
</div><!-- /.ew-dropdown-list -->
<?php echo $Voucher2FWithdrawal_Summary_summary->status->Lookup->getParamTag($Voucher2FWithdrawal_Summary_summary, "p_x_status") ?>
</span>
	</div>
	<?php if ($Voucher2FWithdrawal_Summary_summary->SearchColumnCount % $Voucher2FWithdrawal_Summary_summary->SearchFieldsPerRow == 0) { ?>
</div>
	<?php } ?>
<?php } ?>
	<?php if ($Voucher2FWithdrawal_Summary_summary->SearchColumnCount % $Voucher2FWithdrawal_Summary_summary->SearchFieldsPerRow > 0) { ?>
</div>
	<?php } ?>
<div id="xsr_<?php echo $Voucher2FWithdrawal_Summary_summary->SearchRowCount + 1 ?>" class="ew-row d-sm-flex">
	<button class="btn btn-primary" name="btn-submit" id="btn-submit" type="submit"><?php echo $Language->phrase("SearchBtn") ?></button>
</div>
	</div><!-- /.ew-extended-search -->
</div><!-- /.ew-search-panel -->
</form>
<?php } ?>
<?php } ?>
<?php } ?>
<?php
while ($Voucher2FWithdrawal_Summary_summary->GroupCount <= count($Voucher2FWithdrawal_Summary_summary->GroupRecords) && $Voucher2FWithdrawal_Summary_summary->GroupCount <= $Voucher2FWithdrawal_Summary_summary->DisplayGroups) {
?>
<?php

	// Show header
	if ($Voucher2FWithdrawal_Summary_summary->ShowHeader) {
?>
<?php if ($Voucher2FWithdrawal_Summary_summary->GroupCount > 1) { ?>
</tbody>
</table>
</div>
<!-- /.ew-grid-middle-panel -->
<!-- Report grid (end) -->
<?php if (!$Voucher2FWithdrawal_Summary_summary->isExport() && !($Voucher2FWithdrawal_Summary_summary->DrillDown && $Voucher2FWithdrawal_Summary_summary->TotalGroups > 0)) { ?>
<!-- Bottom pager -->
<div class="card-footer ew-grid-lower-panel">
<form name="ew-pager-form" class="form-inline ew-form ew-pager-form" action="<?php echo CurrentPageName() ?>">
<?php echo $Voucher2FWithdrawal_Summary_summary->Pager->render() ?>
</form>
<div class="clearfix"></div>
</div>
<?php } ?>
</div>
<!-- /.ew-grid -->
<?php echo $Voucher2FWithdrawal_Summary_summary->PageBreakContent ?>
<?php } ?>
<div class="<?php if (!$Voucher2FWithdrawal_Summary_summary->isExport("word") && !$Voucher2FWithdrawal_Summary_summary->isExport("excel")) { ?>card ew-card <?php } ?>ew-grid"<?php echo $Voucher2FWithdrawal_Summary_summary->ReportTableStyle ?>>
<!-- Report grid (begin) -->
<div id="gmp_Voucher2FWithdrawal_Summary" class="<?php echo ResponsiveTableClass() ?>card-body ew-grid-middle-panel">
<table class="<?php echo $Voucher2FWithdrawal_Summary_summary->ReportTableClass ?>">
<thead>
	<!-- Table header -->
	<tr class="ew-table-header">
<?php if ($Voucher2FWithdrawal_Summary_summary->transferTime->Visible) { ?>
	<?php if ($Voucher2FWithdrawal_Summary_summary->transferTime->ShowGroupHeaderAsRow) { ?>
	<th data-name="transferTime">&nbsp;</th>
	<?php } else { ?>
		<?php if ($Voucher2FWithdrawal_Summary_summary->sortUrl($Voucher2FWithdrawal_Summary_summary->transferTime) == "") { ?>
	<th data-name="transferTime" class="<?php echo $Voucher2FWithdrawal_Summary_summary->transferTime->headerCellClass() ?>"><div class="Voucher2FWithdrawal_Summary_transferTime"><div class="ew-table-header-caption"><?php echo $Voucher2FWithdrawal_Summary_summary->transferTime->caption() ?></div></div></th>
		<?php } else { ?>
	<th data-name="transferTime" class="<?php echo $Voucher2FWithdrawal_Summary_summary->transferTime->headerCellClass() ?>"><div class="ew-pointer" onclick="ew.sort(event, '<?php echo $Voucher2FWithdrawal_Summary_summary->sortUrl($Voucher2FWithdrawal_Summary_summary->transferTime) ?>', 1);"><div class="Voucher2FWithdrawal_Summary_transferTime">
		<div class="ew-table-header-btn"><span class="ew-table-header-caption"><?php echo $Voucher2FWithdrawal_Summary_summary->transferTime->caption() ?></span><span class="ew-table-header-sort"><?php if ($Voucher2FWithdrawal_Summary_summary->transferTime->getSort() == "ASC") { ?><i class="fas fa-sort-up"></i><?php } elseif ($Voucher2FWithdrawal_Summary_summary->transferTime->getSort() == "DESC") { ?><i class="fas fa-sort-down"></i><?php } ?></span></div>
	</div></div></th>
		<?php } ?>
	<?php } ?>
<?php } ?>
<?php if ($Voucher2FWithdrawal_Summary_summary->currID->Visible) { ?>
	<?php if ($Voucher2FWithdrawal_Summary_summary->currID->ShowGroupHeaderAsRow) { ?>
	<th data-name="currID">&nbsp;</th>
	<?php } else { ?>
		<?php if ($Voucher2FWithdrawal_Summary_summary->sortUrl($Voucher2FWithdrawal_Summary_summary->currID) == "") { ?>
	<th data-name="currID" class="<?php echo $Voucher2FWithdrawal_Summary_summary->currID->headerCellClass() ?>"><div class="Voucher2FWithdrawal_Summary_currID"><div class="ew-table-header-caption"><?php echo $Voucher2FWithdrawal_Summary_summary->currID->caption() ?></div></div></th>
		<?php } else { ?>
	<th data-name="currID" class="<?php echo $Voucher2FWithdrawal_Summary_summary->currID->headerCellClass() ?>"><div class="ew-pointer" onclick="ew.sort(event, '<?php echo $Voucher2FWithdrawal_Summary_summary->sortUrl($Voucher2FWithdrawal_Summary_summary->currID) ?>', 1);"><div class="Voucher2FWithdrawal_Summary_currID">
		<div class="ew-table-header-btn"><span class="ew-table-header-caption"><?php echo $Voucher2FWithdrawal_Summary_summary->currID->caption() ?></span><span class="ew-table-header-sort"><?php if ($Voucher2FWithdrawal_Summary_summary->currID->getSort() == "ASC") { ?><i class="fas fa-sort-up"></i><?php } elseif ($Voucher2FWithdrawal_Summary_summary->currID->getSort() == "DESC") { ?><i class="fas fa-sort-down"></i><?php } ?></span></div>
	</div></div></th>
		<?php } ?>
	<?php } ?>
<?php } ?>
<?php if ($Voucher2FWithdrawal_Summary_summary->type->Visible) { ?>
	<?php if ($Voucher2FWithdrawal_Summary_summary->type->ShowGroupHeaderAsRow) { ?>
	<th data-name="type">&nbsp;</th>
	<?php } else { ?>
		<?php if ($Voucher2FWithdrawal_Summary_summary->sortUrl($Voucher2FWithdrawal_Summary_summary->type) == "") { ?>
	<th data-name="type" class="<?php echo $Voucher2FWithdrawal_Summary_summary->type->headerCellClass() ?>"><div class="Voucher2FWithdrawal_Summary_type"><div class="ew-table-header-caption"><?php echo $Voucher2FWithdrawal_Summary_summary->type->caption() ?></div></div></th>
		<?php } else { ?>
	<th data-name="type" class="<?php echo $Voucher2FWithdrawal_Summary_summary->type->headerCellClass() ?>"><div class="ew-pointer" onclick="ew.sort(event, '<?php echo $Voucher2FWithdrawal_Summary_summary->sortUrl($Voucher2FWithdrawal_Summary_summary->type) ?>', 1);"><div class="Voucher2FWithdrawal_Summary_type">
		<div class="ew-table-header-btn"><span class="ew-table-header-caption"><?php echo $Voucher2FWithdrawal_Summary_summary->type->caption() ?></span><span class="ew-table-header-sort"><?php if ($Voucher2FWithdrawal_Summary_summary->type->getSort() == "ASC") { ?><i class="fas fa-sort-up"></i><?php } elseif ($Voucher2FWithdrawal_Summary_summary->type->getSort() == "DESC") { ?><i class="fas fa-sort-down"></i><?php } ?></span></div>
	</div></div></th>
		<?php } ?>
	<?php } ?>
<?php } ?>
<?php if ($Voucher2FWithdrawal_Summary_summary->status->Visible) { ?>
	<?php if ($Voucher2FWithdrawal_Summary_summary->status->ShowGroupHeaderAsRow) { ?>
	<th data-name="status">&nbsp;</th>
	<?php } else { ?>
		<?php if ($Voucher2FWithdrawal_Summary_summary->sortUrl($Voucher2FWithdrawal_Summary_summary->status) == "") { ?>
	<th data-name="status" class="<?php echo $Voucher2FWithdrawal_Summary_summary->status->headerCellClass() ?>"><div class="Voucher2FWithdrawal_Summary_status"><div class="ew-table-header-caption"><?php echo $Voucher2FWithdrawal_Summary_summary->status->caption() ?></div></div></th>
		<?php } else { ?>
	<th data-name="status" class="<?php echo $Voucher2FWithdrawal_Summary_summary->status->headerCellClass() ?>"><div class="ew-pointer" onclick="ew.sort(event, '<?php echo $Voucher2FWithdrawal_Summary_summary->sortUrl($Voucher2FWithdrawal_Summary_summary->status) ?>', 1);"><div class="Voucher2FWithdrawal_Summary_status">
		<div class="ew-table-header-btn"><span class="ew-table-header-caption"><?php echo $Voucher2FWithdrawal_Summary_summary->status->caption() ?></span><span class="ew-table-header-sort"><?php if ($Voucher2FWithdrawal_Summary_summary->status->getSort() == "ASC") { ?><i class="fas fa-sort-up"></i><?php } elseif ($Voucher2FWithdrawal_Summary_summary->status->getSort() == "DESC") { ?><i class="fas fa-sort-down"></i><?php } ?></span></div>
	</div></div></th>
		<?php } ?>
	<?php } ?>
<?php } ?>
<?php if ($Voucher2FWithdrawal_Summary_summary->sourceUserID->Visible) { ?>
	<?php if ($Voucher2FWithdrawal_Summary_summary->sortUrl($Voucher2FWithdrawal_Summary_summary->sourceUserID) == "") { ?>
	<th data-name="sourceUserID" class="<?php echo $Voucher2FWithdrawal_Summary_summary->sourceUserID->headerCellClass() ?>"><div class="Voucher2FWithdrawal_Summary_sourceUserID"><div class="ew-table-header-caption"><?php echo $Voucher2FWithdrawal_Summary_summary->sourceUserID->caption() ?></div></div></th>
	<?php } else { ?>
	<th data-name="sourceUserID" class="<?php echo $Voucher2FWithdrawal_Summary_summary->sourceUserID->headerCellClass() ?>"><div class="ew-pointer" onclick="ew.sort(event, '<?php echo $Voucher2FWithdrawal_Summary_summary->sortUrl($Voucher2FWithdrawal_Summary_summary->sourceUserID) ?>', 1);"><div class="Voucher2FWithdrawal_Summary_sourceUserID">
		<div class="ew-table-header-btn"><span class="ew-table-header-caption"><?php echo $Voucher2FWithdrawal_Summary_summary->sourceUserID->caption() ?></span><span class="ew-table-header-sort"><?php if ($Voucher2FWithdrawal_Summary_summary->sourceUserID->getSort() == "ASC") { ?><i class="fas fa-sort-up"></i><?php } elseif ($Voucher2FWithdrawal_Summary_summary->sourceUserID->getSort() == "DESC") { ?><i class="fas fa-sort-down"></i><?php } ?></span></div>
	</div></div></th>
	<?php } ?>
<?php } ?>
<?php if ($Voucher2FWithdrawal_Summary_summary->amountSender->Visible) { ?>
	<?php if ($Voucher2FWithdrawal_Summary_summary->sortUrl($Voucher2FWithdrawal_Summary_summary->amountSender) == "") { ?>
	<th data-name="amountSender" class="<?php echo $Voucher2FWithdrawal_Summary_summary->amountSender->headerCellClass() ?>"><div class="Voucher2FWithdrawal_Summary_amountSender"><div class="ew-table-header-caption"><?php echo $Voucher2FWithdrawal_Summary_summary->amountSender->caption() ?></div></div></th>
	<?php } else { ?>
	<th data-name="amountSender" class="<?php echo $Voucher2FWithdrawal_Summary_summary->amountSender->headerCellClass() ?>"><div class="ew-pointer" onclick="ew.sort(event, '<?php echo $Voucher2FWithdrawal_Summary_summary->sortUrl($Voucher2FWithdrawal_Summary_summary->amountSender) ?>', 1);"><div class="Voucher2FWithdrawal_Summary_amountSender">
		<div class="ew-table-header-btn"><span class="ew-table-header-caption"><?php echo $Voucher2FWithdrawal_Summary_summary->amountSender->caption() ?></span><span class="ew-table-header-sort"><?php if ($Voucher2FWithdrawal_Summary_summary->amountSender->getSort() == "ASC") { ?><i class="fas fa-sort-up"></i><?php } elseif ($Voucher2FWithdrawal_Summary_summary->amountSender->getSort() == "DESC") { ?><i class="fas fa-sort-down"></i><?php } ?></span></div>
	</div></div></th>
	<?php } ?>
<?php } ?>
<?php if ($Voucher2FWithdrawal_Summary_summary->serviceFee->Visible) { ?>
	<?php if ($Voucher2FWithdrawal_Summary_summary->sortUrl($Voucher2FWithdrawal_Summary_summary->serviceFee) == "") { ?>
	<th data-name="serviceFee" class="<?php echo $Voucher2FWithdrawal_Summary_summary->serviceFee->headerCellClass() ?>"><div class="Voucher2FWithdrawal_Summary_serviceFee"><div class="ew-table-header-caption"><?php echo $Voucher2FWithdrawal_Summary_summary->serviceFee->caption() ?></div></div></th>
	<?php } else { ?>
	<th data-name="serviceFee" class="<?php echo $Voucher2FWithdrawal_Summary_summary->serviceFee->headerCellClass() ?>"><div class="ew-pointer" onclick="ew.sort(event, '<?php echo $Voucher2FWithdrawal_Summary_summary->sortUrl($Voucher2FWithdrawal_Summary_summary->serviceFee) ?>', 1);"><div class="Voucher2FWithdrawal_Summary_serviceFee">
		<div class="ew-table-header-btn"><span class="ew-table-header-caption"><?php echo $Voucher2FWithdrawal_Summary_summary->serviceFee->caption() ?></span><span class="ew-table-header-sort"><?php if ($Voucher2FWithdrawal_Summary_summary->serviceFee->getSort() == "ASC") { ?><i class="fas fa-sort-up"></i><?php } elseif ($Voucher2FWithdrawal_Summary_summary->serviceFee->getSort() == "DESC") { ?><i class="fas fa-sort-down"></i><?php } ?></span></div>
	</div></div></th>
	<?php } ?>
<?php } ?>
<?php if ($Voucher2FWithdrawal_Summary_summary->feetax->Visible) { ?>
	<?php if ($Voucher2FWithdrawal_Summary_summary->sortUrl($Voucher2FWithdrawal_Summary_summary->feetax) == "") { ?>
	<th data-name="feetax" class="<?php echo $Voucher2FWithdrawal_Summary_summary->feetax->headerCellClass() ?>"><div class="Voucher2FWithdrawal_Summary_feetax"><div class="ew-table-header-caption"><?php echo $Voucher2FWithdrawal_Summary_summary->feetax->caption() ?></div></div></th>
	<?php } else { ?>
	<th data-name="feetax" class="<?php echo $Voucher2FWithdrawal_Summary_summary->feetax->headerCellClass() ?>"><div class="ew-pointer" onclick="ew.sort(event, '<?php echo $Voucher2FWithdrawal_Summary_summary->sortUrl($Voucher2FWithdrawal_Summary_summary->feetax) ?>', 1);"><div class="Voucher2FWithdrawal_Summary_feetax">
		<div class="ew-table-header-btn"><span class="ew-table-header-caption"><?php echo $Voucher2FWithdrawal_Summary_summary->feetax->caption() ?></span><span class="ew-table-header-sort"><?php if ($Voucher2FWithdrawal_Summary_summary->feetax->getSort() == "ASC") { ?><i class="fas fa-sort-up"></i><?php } elseif ($Voucher2FWithdrawal_Summary_summary->feetax->getSort() == "DESC") { ?><i class="fas fa-sort-down"></i><?php } ?></span></div>
	</div></div></th>
	<?php } ?>
<?php } ?>
<?php if ($Voucher2FWithdrawal_Summary_summary->feetaxtotal->Visible) { ?>
	<?php if ($Voucher2FWithdrawal_Summary_summary->sortUrl($Voucher2FWithdrawal_Summary_summary->feetaxtotal) == "") { ?>
	<th data-name="feetaxtotal" class="<?php echo $Voucher2FWithdrawal_Summary_summary->feetaxtotal->headerCellClass() ?>"><div class="Voucher2FWithdrawal_Summary_feetaxtotal"><div class="ew-table-header-caption"><?php echo $Voucher2FWithdrawal_Summary_summary->feetaxtotal->caption() ?></div></div></th>
	<?php } else { ?>
	<th data-name="feetaxtotal" class="<?php echo $Voucher2FWithdrawal_Summary_summary->feetaxtotal->headerCellClass() ?>"><div class="ew-pointer" onclick="ew.sort(event, '<?php echo $Voucher2FWithdrawal_Summary_summary->sortUrl($Voucher2FWithdrawal_Summary_summary->feetaxtotal) ?>', 1);"><div class="Voucher2FWithdrawal_Summary_feetaxtotal">
		<div class="ew-table-header-btn"><span class="ew-table-header-caption"><?php echo $Voucher2FWithdrawal_Summary_summary->feetaxtotal->caption() ?></span><span class="ew-table-header-sort"><?php if ($Voucher2FWithdrawal_Summary_summary->feetaxtotal->getSort() == "ASC") { ?><i class="fas fa-sort-up"></i><?php } elseif ($Voucher2FWithdrawal_Summary_summary->feetaxtotal->getSort() == "DESC") { ?><i class="fas fa-sort-down"></i><?php } ?></span></div>
	</div></div></th>
	<?php } ?>
<?php } ?>
<?php if ($Voucher2FWithdrawal_Summary_summary->recipientname->Visible) { ?>
	<?php if ($Voucher2FWithdrawal_Summary_summary->sortUrl($Voucher2FWithdrawal_Summary_summary->recipientname) == "") { ?>
	<th data-name="recipientname" class="<?php echo $Voucher2FWithdrawal_Summary_summary->recipientname->headerCellClass() ?>"><div class="Voucher2FWithdrawal_Summary_recipientname"><div class="ew-table-header-caption"><?php echo $Voucher2FWithdrawal_Summary_summary->recipientname->caption() ?></div></div></th>
	<?php } else { ?>
	<th data-name="recipientname" class="<?php echo $Voucher2FWithdrawal_Summary_summary->recipientname->headerCellClass() ?>"><div class="ew-pointer" onclick="ew.sort(event, '<?php echo $Voucher2FWithdrawal_Summary_summary->sortUrl($Voucher2FWithdrawal_Summary_summary->recipientname) ?>', 1);"><div class="Voucher2FWithdrawal_Summary_recipientname">
		<div class="ew-table-header-btn"><span class="ew-table-header-caption"><?php echo $Voucher2FWithdrawal_Summary_summary->recipientname->caption() ?></span><span class="ew-table-header-sort"><?php if ($Voucher2FWithdrawal_Summary_summary->recipientname->getSort() == "ASC") { ?><i class="fas fa-sort-up"></i><?php } elseif ($Voucher2FWithdrawal_Summary_summary->recipientname->getSort() == "DESC") { ?><i class="fas fa-sort-down"></i><?php } ?></span></div>
	</div></div></th>
	<?php } ?>
<?php } ?>
<?php if ($Voucher2FWithdrawal_Summary_summary->recipientemail->Visible) { ?>
	<?php if ($Voucher2FWithdrawal_Summary_summary->sortUrl($Voucher2FWithdrawal_Summary_summary->recipientemail) == "") { ?>
	<th data-name="recipientemail" class="<?php echo $Voucher2FWithdrawal_Summary_summary->recipientemail->headerCellClass() ?>"><div class="Voucher2FWithdrawal_Summary_recipientemail"><div class="ew-table-header-caption"><?php echo $Voucher2FWithdrawal_Summary_summary->recipientemail->caption() ?></div></div></th>
	<?php } else { ?>
	<th data-name="recipientemail" class="<?php echo $Voucher2FWithdrawal_Summary_summary->recipientemail->headerCellClass() ?>"><div class="ew-pointer" onclick="ew.sort(event, '<?php echo $Voucher2FWithdrawal_Summary_summary->sortUrl($Voucher2FWithdrawal_Summary_summary->recipientemail) ?>', 1);"><div class="Voucher2FWithdrawal_Summary_recipientemail">
		<div class="ew-table-header-btn"><span class="ew-table-header-caption"><?php echo $Voucher2FWithdrawal_Summary_summary->recipientemail->caption() ?></span><span class="ew-table-header-sort"><?php if ($Voucher2FWithdrawal_Summary_summary->recipientemail->getSort() == "ASC") { ?><i class="fas fa-sort-up"></i><?php } elseif ($Voucher2FWithdrawal_Summary_summary->recipientemail->getSort() == "DESC") { ?><i class="fas fa-sort-down"></i><?php } ?></span></div>
	</div></div></th>
	<?php } ?>
<?php } ?>
<?php if ($Voucher2FWithdrawal_Summary_summary->presentationcode->Visible) { ?>
	<?php if ($Voucher2FWithdrawal_Summary_summary->sortUrl($Voucher2FWithdrawal_Summary_summary->presentationcode) == "") { ?>
	<th data-name="presentationcode" class="<?php echo $Voucher2FWithdrawal_Summary_summary->presentationcode->headerCellClass() ?>"><div class="Voucher2FWithdrawal_Summary_presentationcode"><div class="ew-table-header-caption"><?php echo $Voucher2FWithdrawal_Summary_summary->presentationcode->caption() ?></div></div></th>
	<?php } else { ?>
	<th data-name="presentationcode" class="<?php echo $Voucher2FWithdrawal_Summary_summary->presentationcode->headerCellClass() ?>"><div class="ew-pointer" onclick="ew.sort(event, '<?php echo $Voucher2FWithdrawal_Summary_summary->sortUrl($Voucher2FWithdrawal_Summary_summary->presentationcode) ?>', 1);"><div class="Voucher2FWithdrawal_Summary_presentationcode">
		<div class="ew-table-header-btn"><span class="ew-table-header-caption"><?php echo $Voucher2FWithdrawal_Summary_summary->presentationcode->caption() ?></span><span class="ew-table-header-sort"><?php if ($Voucher2FWithdrawal_Summary_summary->presentationcode->getSort() == "ASC") { ?><i class="fas fa-sort-up"></i><?php } elseif ($Voucher2FWithdrawal_Summary_summary->presentationcode->getSort() == "DESC") { ?><i class="fas fa-sort-down"></i><?php } ?></span></div>
	</div></div></th>
	<?php } ?>
<?php } ?>
<?php if ($Voucher2FWithdrawal_Summary_summary->secondaryemail->Visible) { ?>
	<?php if ($Voucher2FWithdrawal_Summary_summary->sortUrl($Voucher2FWithdrawal_Summary_summary->secondaryemail) == "") { ?>
	<th data-name="secondaryemail" class="<?php echo $Voucher2FWithdrawal_Summary_summary->secondaryemail->headerCellClass() ?>"><div class="Voucher2FWithdrawal_Summary_secondaryemail"><div class="ew-table-header-caption"><?php echo $Voucher2FWithdrawal_Summary_summary->secondaryemail->caption() ?></div></div></th>
	<?php } else { ?>
	<th data-name="secondaryemail" class="<?php echo $Voucher2FWithdrawal_Summary_summary->secondaryemail->headerCellClass() ?>"><div class="ew-pointer" onclick="ew.sort(event, '<?php echo $Voucher2FWithdrawal_Summary_summary->sortUrl($Voucher2FWithdrawal_Summary_summary->secondaryemail) ?>', 1);"><div class="Voucher2FWithdrawal_Summary_secondaryemail">
		<div class="ew-table-header-btn"><span class="ew-table-header-caption"><?php echo $Voucher2FWithdrawal_Summary_summary->secondaryemail->caption() ?></span><span class="ew-table-header-sort"><?php if ($Voucher2FWithdrawal_Summary_summary->secondaryemail->getSort() == "ASC") { ?><i class="fas fa-sort-up"></i><?php } elseif ($Voucher2FWithdrawal_Summary_summary->secondaryemail->getSort() == "DESC") { ?><i class="fas fa-sort-down"></i><?php } ?></span></div>
	</div></div></th>
	<?php } ?>
<?php } ?>
<?php if ($Voucher2FWithdrawal_Summary_summary->secondarytoken->Visible) { ?>
	<?php if ($Voucher2FWithdrawal_Summary_summary->sortUrl($Voucher2FWithdrawal_Summary_summary->secondarytoken) == "") { ?>
	<th data-name="secondarytoken" class="<?php echo $Voucher2FWithdrawal_Summary_summary->secondarytoken->headerCellClass() ?>"><div class="Voucher2FWithdrawal_Summary_secondarytoken"><div class="ew-table-header-caption"><?php echo $Voucher2FWithdrawal_Summary_summary->secondarytoken->caption() ?></div></div></th>
	<?php } else { ?>
	<th data-name="secondarytoken" class="<?php echo $Voucher2FWithdrawal_Summary_summary->secondarytoken->headerCellClass() ?>"><div class="ew-pointer" onclick="ew.sort(event, '<?php echo $Voucher2FWithdrawal_Summary_summary->sortUrl($Voucher2FWithdrawal_Summary_summary->secondarytoken) ?>', 1);"><div class="Voucher2FWithdrawal_Summary_secondarytoken">
		<div class="ew-table-header-btn"><span class="ew-table-header-caption"><?php echo $Voucher2FWithdrawal_Summary_summary->secondarytoken->caption() ?></span><span class="ew-table-header-sort"><?php if ($Voucher2FWithdrawal_Summary_summary->secondarytoken->getSort() == "ASC") { ?><i class="fas fa-sort-up"></i><?php } elseif ($Voucher2FWithdrawal_Summary_summary->secondarytoken->getSort() == "DESC") { ?><i class="fas fa-sort-down"></i><?php } ?></span></div>
	</div></div></th>
	<?php } ?>
<?php } ?>
<?php if ($Voucher2FWithdrawal_Summary_summary->secondaryname->Visible) { ?>
	<?php if ($Voucher2FWithdrawal_Summary_summary->sortUrl($Voucher2FWithdrawal_Summary_summary->secondaryname) == "") { ?>
	<th data-name="secondaryname" class="<?php echo $Voucher2FWithdrawal_Summary_summary->secondaryname->headerCellClass() ?>"><div class="Voucher2FWithdrawal_Summary_secondaryname"><div class="ew-table-header-caption"><?php echo $Voucher2FWithdrawal_Summary_summary->secondaryname->caption() ?></div></div></th>
	<?php } else { ?>
	<th data-name="secondaryname" class="<?php echo $Voucher2FWithdrawal_Summary_summary->secondaryname->headerCellClass() ?>"><div class="ew-pointer" onclick="ew.sort(event, '<?php echo $Voucher2FWithdrawal_Summary_summary->sortUrl($Voucher2FWithdrawal_Summary_summary->secondaryname) ?>', 1);"><div class="Voucher2FWithdrawal_Summary_secondaryname">
		<div class="ew-table-header-btn"><span class="ew-table-header-caption"><?php echo $Voucher2FWithdrawal_Summary_summary->secondaryname->caption() ?></span><span class="ew-table-header-sort"><?php if ($Voucher2FWithdrawal_Summary_summary->secondaryname->getSort() == "ASC") { ?><i class="fas fa-sort-up"></i><?php } elseif ($Voucher2FWithdrawal_Summary_summary->secondaryname->getSort() == "DESC") { ?><i class="fas fa-sort-down"></i><?php } ?></span></div>
	</div></div></th>
	<?php } ?>
<?php } ?>
<?php if ($Voucher2FWithdrawal_Summary_summary->sendercustomeruserid->Visible) { ?>
	<?php if ($Voucher2FWithdrawal_Summary_summary->sortUrl($Voucher2FWithdrawal_Summary_summary->sendercustomeruserid) == "") { ?>
	<th data-name="sendercustomeruserid" class="<?php echo $Voucher2FWithdrawal_Summary_summary->sendercustomeruserid->headerCellClass() ?>"><div class="Voucher2FWithdrawal_Summary_sendercustomeruserid"><div class="ew-table-header-caption"><?php echo $Voucher2FWithdrawal_Summary_summary->sendercustomeruserid->caption() ?></div></div></th>
	<?php } else { ?>
	<th data-name="sendercustomeruserid" class="<?php echo $Voucher2FWithdrawal_Summary_summary->sendercustomeruserid->headerCellClass() ?>"><div class="ew-pointer" onclick="ew.sort(event, '<?php echo $Voucher2FWithdrawal_Summary_summary->sortUrl($Voucher2FWithdrawal_Summary_summary->sendercustomeruserid) ?>', 1);"><div class="Voucher2FWithdrawal_Summary_sendercustomeruserid">
		<div class="ew-table-header-btn"><span class="ew-table-header-caption"><?php echo $Voucher2FWithdrawal_Summary_summary->sendercustomeruserid->caption() ?></span><span class="ew-table-header-sort"><?php if ($Voucher2FWithdrawal_Summary_summary->sendercustomeruserid->getSort() == "ASC") { ?><i class="fas fa-sort-up"></i><?php } elseif ($Voucher2FWithdrawal_Summary_summary->sendercustomeruserid->getSort() == "DESC") { ?><i class="fas fa-sort-down"></i><?php } ?></span></div>
	</div></div></th>
	<?php } ?>
<?php } ?>
<?php if ($Voucher2FWithdrawal_Summary_summary->systemshare->Visible) { ?>
	<?php if ($Voucher2FWithdrawal_Summary_summary->sortUrl($Voucher2FWithdrawal_Summary_summary->systemshare) == "") { ?>
	<th data-name="systemshare" class="<?php echo $Voucher2FWithdrawal_Summary_summary->systemshare->headerCellClass() ?>"><div class="Voucher2FWithdrawal_Summary_systemshare"><div class="ew-table-header-caption"><?php echo $Voucher2FWithdrawal_Summary_summary->systemshare->caption() ?></div></div></th>
	<?php } else { ?>
	<th data-name="systemshare" class="<?php echo $Voucher2FWithdrawal_Summary_summary->systemshare->headerCellClass() ?>"><div class="ew-pointer" onclick="ew.sort(event, '<?php echo $Voucher2FWithdrawal_Summary_summary->sortUrl($Voucher2FWithdrawal_Summary_summary->systemshare) ?>', 1);"><div class="Voucher2FWithdrawal_Summary_systemshare">
		<div class="ew-table-header-btn"><span class="ew-table-header-caption"><?php echo $Voucher2FWithdrawal_Summary_summary->systemshare->caption() ?></span><span class="ew-table-header-sort"><?php if ($Voucher2FWithdrawal_Summary_summary->systemshare->getSort() == "ASC") { ?><i class="fas fa-sort-up"></i><?php } elseif ($Voucher2FWithdrawal_Summary_summary->systemshare->getSort() == "DESC") { ?><i class="fas fa-sort-down"></i><?php } ?></span></div>
	</div></div></th>
	<?php } ?>
<?php } ?>
<?php if ($Voucher2FWithdrawal_Summary_summary->franchiseeshare->Visible) { ?>
	<?php if ($Voucher2FWithdrawal_Summary_summary->sortUrl($Voucher2FWithdrawal_Summary_summary->franchiseeshare) == "") { ?>
	<th data-name="franchiseeshare" class="<?php echo $Voucher2FWithdrawal_Summary_summary->franchiseeshare->headerCellClass() ?>"><div class="Voucher2FWithdrawal_Summary_franchiseeshare"><div class="ew-table-header-caption"><?php echo $Voucher2FWithdrawal_Summary_summary->franchiseeshare->caption() ?></div></div></th>
	<?php } else { ?>
	<th data-name="franchiseeshare" class="<?php echo $Voucher2FWithdrawal_Summary_summary->franchiseeshare->headerCellClass() ?>"><div class="ew-pointer" onclick="ew.sort(event, '<?php echo $Voucher2FWithdrawal_Summary_summary->sortUrl($Voucher2FWithdrawal_Summary_summary->franchiseeshare) ?>', 1);"><div class="Voucher2FWithdrawal_Summary_franchiseeshare">
		<div class="ew-table-header-btn"><span class="ew-table-header-caption"><?php echo $Voucher2FWithdrawal_Summary_summary->franchiseeshare->caption() ?></span><span class="ew-table-header-sort"><?php if ($Voucher2FWithdrawal_Summary_summary->franchiseeshare->getSort() == "ASC") { ?><i class="fas fa-sort-up"></i><?php } elseif ($Voucher2FWithdrawal_Summary_summary->franchiseeshare->getSort() == "DESC") { ?><i class="fas fa-sort-down"></i><?php } ?></span></div>
	</div></div></th>
	<?php } ?>
<?php } ?>
<?php if ($Voucher2FWithdrawal_Summary_summary->managershare->Visible) { ?>
	<?php if ($Voucher2FWithdrawal_Summary_summary->sortUrl($Voucher2FWithdrawal_Summary_summary->managershare) == "") { ?>
	<th data-name="managershare" class="<?php echo $Voucher2FWithdrawal_Summary_summary->managershare->headerCellClass() ?>"><div class="Voucher2FWithdrawal_Summary_managershare"><div class="ew-table-header-caption"><?php echo $Voucher2FWithdrawal_Summary_summary->managershare->caption() ?></div></div></th>
	<?php } else { ?>
	<th data-name="managershare" class="<?php echo $Voucher2FWithdrawal_Summary_summary->managershare->headerCellClass() ?>"><div class="ew-pointer" onclick="ew.sort(event, '<?php echo $Voucher2FWithdrawal_Summary_summary->sortUrl($Voucher2FWithdrawal_Summary_summary->managershare) ?>', 1);"><div class="Voucher2FWithdrawal_Summary_managershare">
		<div class="ew-table-header-btn"><span class="ew-table-header-caption"><?php echo $Voucher2FWithdrawal_Summary_summary->managershare->caption() ?></span><span class="ew-table-header-sort"><?php if ($Voucher2FWithdrawal_Summary_summary->managershare->getSort() == "ASC") { ?><i class="fas fa-sort-up"></i><?php } elseif ($Voucher2FWithdrawal_Summary_summary->managershare->getSort() == "DESC") { ?><i class="fas fa-sort-down"></i><?php } ?></span></div>
	</div></div></th>
	<?php } ?>
<?php } ?>
<?php if ($Voucher2FWithdrawal_Summary_summary->brokershare->Visible) { ?>
	<?php if ($Voucher2FWithdrawal_Summary_summary->sortUrl($Voucher2FWithdrawal_Summary_summary->brokershare) == "") { ?>
	<th data-name="brokershare" class="<?php echo $Voucher2FWithdrawal_Summary_summary->brokershare->headerCellClass() ?>"><div class="Voucher2FWithdrawal_Summary_brokershare"><div class="ew-table-header-caption"><?php echo $Voucher2FWithdrawal_Summary_summary->brokershare->caption() ?></div></div></th>
	<?php } else { ?>
	<th data-name="brokershare" class="<?php echo $Voucher2FWithdrawal_Summary_summary->brokershare->headerCellClass() ?>"><div class="ew-pointer" onclick="ew.sort(event, '<?php echo $Voucher2FWithdrawal_Summary_summary->sortUrl($Voucher2FWithdrawal_Summary_summary->brokershare) ?>', 1);"><div class="Voucher2FWithdrawal_Summary_brokershare">
		<div class="ew-table-header-btn"><span class="ew-table-header-caption"><?php echo $Voucher2FWithdrawal_Summary_summary->brokershare->caption() ?></span><span class="ew-table-header-sort"><?php if ($Voucher2FWithdrawal_Summary_summary->brokershare->getSort() == "ASC") { ?><i class="fas fa-sort-up"></i><?php } elseif ($Voucher2FWithdrawal_Summary_summary->brokershare->getSort() == "DESC") { ?><i class="fas fa-sort-down"></i><?php } ?></span></div>
	</div></div></th>
	<?php } ?>
<?php } ?>
	</tr>
</thead>
<tbody>
<?php
		if ($Voucher2FWithdrawal_Summary_summary->TotalGroups == 0)
			break; // Show header only
		$Voucher2FWithdrawal_Summary_summary->ShowHeader = FALSE;
	} // End show header
?>
<?php

	// Build detail SQL
	$where = DetailFilterSql($Voucher2FWithdrawal_Summary_summary->transferTime, $Voucher2FWithdrawal_Summary_summary->getSqlFirstGroupField(), $Voucher2FWithdrawal_Summary_summary->transferTime->groupValue(), $Voucher2FWithdrawal_Summary_summary->Dbid);
	if ($Voucher2FWithdrawal_Summary_summary->PageFirstGroupFilter != "") $Voucher2FWithdrawal_Summary_summary->PageFirstGroupFilter .= " OR ";
	$Voucher2FWithdrawal_Summary_summary->PageFirstGroupFilter .= $where;
	if ($Voucher2FWithdrawal_Summary_summary->Filter != "")
		$where = "($Voucher2FWithdrawal_Summary_summary->Filter) AND ($where)";
	$sql = BuildReportSql($Voucher2FWithdrawal_Summary_summary->getSqlSelect(), $Voucher2FWithdrawal_Summary_summary->getSqlWhere(), $Voucher2FWithdrawal_Summary_summary->getSqlGroupBy(), $Voucher2FWithdrawal_Summary_summary->getSqlHaving(), $Voucher2FWithdrawal_Summary_summary->getSqlOrderBy(), $where, $Voucher2FWithdrawal_Summary_summary->Sort);
	$rs = $Voucher2FWithdrawal_Summary_summary->getRecordset($sql);
	$Voucher2FWithdrawal_Summary_summary->DetailRecords = $rs ? $rs->getRows() : [];
	$Voucher2FWithdrawal_Summary_summary->DetailRecordCount = count($Voucher2FWithdrawal_Summary_summary->DetailRecords);

	// Load detail records
	$Voucher2FWithdrawal_Summary_summary->transferTime->Records = &$Voucher2FWithdrawal_Summary_summary->DetailRecords;
	$Voucher2FWithdrawal_Summary_summary->transferTime->LevelBreak = TRUE; // Set field level break
		$Voucher2FWithdrawal_Summary_summary->GroupCounter[1] = $Voucher2FWithdrawal_Summary_summary->GroupCount;
		$Voucher2FWithdrawal_Summary_summary->transferTime->getCnt($Voucher2FWithdrawal_Summary_summary->transferTime->Records); // Get record count
?>
<?php if ($Voucher2FWithdrawal_Summary_summary->transferTime->Visible && $Voucher2FWithdrawal_Summary_summary->transferTime->ShowGroupHeaderAsRow) { ?>
<?php

		// Render header row
		$Voucher2FWithdrawal_Summary_summary->resetAttributes();
		$Voucher2FWithdrawal_Summary_summary->RowType = ROWTYPE_TOTAL;
		$Voucher2FWithdrawal_Summary_summary->RowTotalType = ROWTOTAL_GROUP;
		$Voucher2FWithdrawal_Summary_summary->RowTotalSubType = ROWTOTAL_HEADER;
		$Voucher2FWithdrawal_Summary_summary->RowGroupLevel = 1;
		$Voucher2FWithdrawal_Summary_summary->renderRow();
?>
	<tr<?php echo $Voucher2FWithdrawal_Summary_summary->rowAttributes(); ?>>
<?php if ($Voucher2FWithdrawal_Summary_summary->transferTime->Visible) { ?>
		<td data-field="transferTime"<?php echo $Voucher2FWithdrawal_Summary_summary->transferTime->cellAttributes(); ?>><span class="ew-group-toggle icon-collapse"></span></td>
<?php } ?>
		<td data-field="transferTime" colspan="<?php echo ($Page->GroupColumnCount + $Page->DetailColumnCount - 1) ?>"<?php echo $Voucher2FWithdrawal_Summary_summary->transferTime->cellAttributes() ?>>
<?php if ($Voucher2FWithdrawal_Summary_summary->sortUrl($Voucher2FWithdrawal_Summary_summary->transferTime) == "") { ?>
		<span class="ew-summary-caption Voucher2FWithdrawal_Summary_transferTime"><span class="ew-table-header-caption"><?php echo $Voucher2FWithdrawal_Summary_summary->transferTime->caption() ?></span></span>
<?php } else { ?>
		<span class="ew-table-header-btn ew-pointer ew-summary-caption Voucher2FWithdrawal_Summary_transferTime" onclick="ew.sort(event, '<?php echo $Voucher2FWithdrawal_Summary_summary->sortUrl($Voucher2FWithdrawal_Summary_summary->transferTime) ?>', 1);">
			<span class="ew-table-header-caption"><?php echo $Voucher2FWithdrawal_Summary_summary->transferTime->caption() ?></span>
			<span class="ew-table-header-sort"><?php if ($Voucher2FWithdrawal_Summary_summary->transferTime->getSort() == "ASC") { ?><i class="fas fa-sort-up"></i><?php } elseif ($Voucher2FWithdrawal_Summary_summary->transferTime->getSort() == "DESC") { ?><i class="fas fa-sort-down"></i><?php } ?></span>
		</span>
<?php } ?>
		<?php echo $Language->phrase("SummaryColon") ?><span<?php echo $Voucher2FWithdrawal_Summary_summary->transferTime->viewAttributes() ?>><?php echo $Voucher2FWithdrawal_Summary_summary->transferTime->GroupViewValue ?></span>
		<span class="ew-summary-count">(<span class="ew-aggregate-caption"><?php echo $Language->phrase("RptCnt") ?></span><?php echo $Language->phrase("AggregateEqual") ?><span class="ew-aggregate-value"><?php echo FormatNumber($Voucher2FWithdrawal_Summary_summary->transferTime->Count, 0); ?></span>)</span>
		</td>
	</tr>
<?php } ?>
<?php
	$Voucher2FWithdrawal_Summary_summary->currID->getDistinctValues($Voucher2FWithdrawal_Summary_summary->transferTime->Records);
	$Voucher2FWithdrawal_Summary_summary->setGroupCount(count($Voucher2FWithdrawal_Summary_summary->currID->DistinctValues), $Voucher2FWithdrawal_Summary_summary->GroupCounter[1]);
	$Voucher2FWithdrawal_Summary_summary->GroupCounter[2] = 0; // Init group count index
	foreach ($Voucher2FWithdrawal_Summary_summary->currID->DistinctValues as $currID) { // Load records for this distinct value
		$Voucher2FWithdrawal_Summary_summary->currID->setGroupValue($currID); // Set group value
		$Voucher2FWithdrawal_Summary_summary->currID->getDistinctRecords($Voucher2FWithdrawal_Summary_summary->transferTime->Records, $Voucher2FWithdrawal_Summary_summary->currID->groupValue());
		$Voucher2FWithdrawal_Summary_summary->currID->LevelBreak = TRUE; // Set field level break
		$Voucher2FWithdrawal_Summary_summary->GroupCounter[2]++;
		$Voucher2FWithdrawal_Summary_summary->currID->getCnt($Voucher2FWithdrawal_Summary_summary->currID->Records); // Get record count
?>
<?php if ($Voucher2FWithdrawal_Summary_summary->currID->Visible && $Voucher2FWithdrawal_Summary_summary->currID->ShowGroupHeaderAsRow) { ?>
<?php

		// Render header row
		$Voucher2FWithdrawal_Summary_summary->currID->setDbValue($currID); // Set current value for currID
		$Voucher2FWithdrawal_Summary_summary->resetAttributes();
		$Voucher2FWithdrawal_Summary_summary->RowType = ROWTYPE_TOTAL;
		$Voucher2FWithdrawal_Summary_summary->RowTotalType = ROWTOTAL_GROUP;
		$Voucher2FWithdrawal_Summary_summary->RowTotalSubType = ROWTOTAL_HEADER;
		$Voucher2FWithdrawal_Summary_summary->RowGroupLevel = 2;
		$Voucher2FWithdrawal_Summary_summary->renderRow();
?>
	<tr<?php echo $Voucher2FWithdrawal_Summary_summary->rowAttributes(); ?>>
<?php if ($Voucher2FWithdrawal_Summary_summary->transferTime->Visible) { ?>
		<td data-field="transferTime"<?php echo $Voucher2FWithdrawal_Summary_summary->transferTime->cellAttributes(); ?>></td>
<?php } ?>
<?php if ($Voucher2FWithdrawal_Summary_summary->currID->Visible) { ?>
		<td data-field="currID"<?php echo $Voucher2FWithdrawal_Summary_summary->currID->cellAttributes(); ?>><span class="ew-group-toggle icon-collapse"></span></td>
<?php } ?>
		<td data-field="currID" colspan="<?php echo ($Page->GroupColumnCount + $Page->DetailColumnCount - 2) ?>"<?php echo $Voucher2FWithdrawal_Summary_summary->currID->cellAttributes() ?>>
<?php if ($Voucher2FWithdrawal_Summary_summary->sortUrl($Voucher2FWithdrawal_Summary_summary->currID) == "") { ?>
		<span class="ew-summary-caption Voucher2FWithdrawal_Summary_currID"><span class="ew-table-header-caption"><?php echo $Voucher2FWithdrawal_Summary_summary->currID->caption() ?></span></span>
<?php } else { ?>
		<span class="ew-table-header-btn ew-pointer ew-summary-caption Voucher2FWithdrawal_Summary_currID" onclick="ew.sort(event, '<?php echo $Voucher2FWithdrawal_Summary_summary->sortUrl($Voucher2FWithdrawal_Summary_summary->currID) ?>', 1);">
			<span class="ew-table-header-caption"><?php echo $Voucher2FWithdrawal_Summary_summary->currID->caption() ?></span>
			<span class="ew-table-header-sort"><?php if ($Voucher2FWithdrawal_Summary_summary->currID->getSort() == "ASC") { ?><i class="fas fa-sort-up"></i><?php } elseif ($Voucher2FWithdrawal_Summary_summary->currID->getSort() == "DESC") { ?><i class="fas fa-sort-down"></i><?php } ?></span>
		</span>
<?php } ?>
		<?php echo $Language->phrase("SummaryColon") ?><span<?php echo $Voucher2FWithdrawal_Summary_summary->currID->viewAttributes() ?>><?php echo $Voucher2FWithdrawal_Summary_summary->currID->GroupViewValue ?></span>
		<span class="ew-summary-count">(<span class="ew-aggregate-caption"><?php echo $Language->phrase("RptCnt") ?></span><?php echo $Language->phrase("AggregateEqual") ?><span class="ew-aggregate-value"><?php echo FormatNumber($Voucher2FWithdrawal_Summary_summary->currID->Count, 0); ?></span>)</span>
		</td>
	</tr>
<?php } ?>
<?php
	$Voucher2FWithdrawal_Summary_summary->type->getDistinctValues($Voucher2FWithdrawal_Summary_summary->currID->Records);
	$Voucher2FWithdrawal_Summary_summary->setGroupCount(count($Voucher2FWithdrawal_Summary_summary->type->DistinctValues), $Voucher2FWithdrawal_Summary_summary->GroupCounter[1], $Voucher2FWithdrawal_Summary_summary->GroupCounter[2]);
	$Voucher2FWithdrawal_Summary_summary->GroupCounter[3] = 0; // Init group count index
	foreach ($Voucher2FWithdrawal_Summary_summary->type->DistinctValues as $type) { // Load records for this distinct value
		$Voucher2FWithdrawal_Summary_summary->type->setGroupValue($type); // Set group value
		$Voucher2FWithdrawal_Summary_summary->type->getDistinctRecords($Voucher2FWithdrawal_Summary_summary->currID->Records, $Voucher2FWithdrawal_Summary_summary->type->groupValue());
		$Voucher2FWithdrawal_Summary_summary->type->LevelBreak = TRUE; // Set field level break
		$Voucher2FWithdrawal_Summary_summary->GroupCounter[3]++;
		$Voucher2FWithdrawal_Summary_summary->type->getCnt($Voucher2FWithdrawal_Summary_summary->type->Records); // Get record count
?>
<?php if ($Voucher2FWithdrawal_Summary_summary->type->Visible && $Voucher2FWithdrawal_Summary_summary->type->ShowGroupHeaderAsRow) { ?>
<?php

		// Render header row
		$Voucher2FWithdrawal_Summary_summary->type->setDbValue($type); // Set current value for type
		$Voucher2FWithdrawal_Summary_summary->resetAttributes();
		$Voucher2FWithdrawal_Summary_summary->RowType = ROWTYPE_TOTAL;
		$Voucher2FWithdrawal_Summary_summary->RowTotalType = ROWTOTAL_GROUP;
		$Voucher2FWithdrawal_Summary_summary->RowTotalSubType = ROWTOTAL_HEADER;
		$Voucher2FWithdrawal_Summary_summary->RowGroupLevel = 3;
		$Voucher2FWithdrawal_Summary_summary->renderRow();
?>
	<tr<?php echo $Voucher2FWithdrawal_Summary_summary->rowAttributes(); ?>>
<?php if ($Voucher2FWithdrawal_Summary_summary->transferTime->Visible) { ?>
		<td data-field="transferTime"<?php echo $Voucher2FWithdrawal_Summary_summary->transferTime->cellAttributes(); ?>></td>
<?php } ?>
<?php if ($Voucher2FWithdrawal_Summary_summary->currID->Visible) { ?>
		<td data-field="currID"<?php echo $Voucher2FWithdrawal_Summary_summary->currID->cellAttributes(); ?>></td>
<?php } ?>
<?php if ($Voucher2FWithdrawal_Summary_summary->type->Visible) { ?>
		<td data-field="type"<?php echo $Voucher2FWithdrawal_Summary_summary->type->cellAttributes(); ?>><span class="ew-group-toggle icon-collapse"></span></td>
<?php } ?>
		<td data-field="type" colspan="<?php echo ($Page->GroupColumnCount + $Page->DetailColumnCount - 3) ?>"<?php echo $Voucher2FWithdrawal_Summary_summary->type->cellAttributes() ?>>
<?php if ($Voucher2FWithdrawal_Summary_summary->sortUrl($Voucher2FWithdrawal_Summary_summary->type) == "") { ?>
		<span class="ew-summary-caption Voucher2FWithdrawal_Summary_type"><span class="ew-table-header-caption"><?php echo $Voucher2FWithdrawal_Summary_summary->type->caption() ?></span></span>
<?php } else { ?>
		<span class="ew-table-header-btn ew-pointer ew-summary-caption Voucher2FWithdrawal_Summary_type" onclick="ew.sort(event, '<?php echo $Voucher2FWithdrawal_Summary_summary->sortUrl($Voucher2FWithdrawal_Summary_summary->type) ?>', 1);">
			<span class="ew-table-header-caption"><?php echo $Voucher2FWithdrawal_Summary_summary->type->caption() ?></span>
			<span class="ew-table-header-sort"><?php if ($Voucher2FWithdrawal_Summary_summary->type->getSort() == "ASC") { ?><i class="fas fa-sort-up"></i><?php } elseif ($Voucher2FWithdrawal_Summary_summary->type->getSort() == "DESC") { ?><i class="fas fa-sort-down"></i><?php } ?></span>
		</span>
<?php } ?>
		<?php echo $Language->phrase("SummaryColon") ?><span<?php echo $Voucher2FWithdrawal_Summary_summary->type->viewAttributes() ?>><?php echo $Voucher2FWithdrawal_Summary_summary->type->GroupViewValue ?></span>
		<span class="ew-summary-count">(<span class="ew-aggregate-caption"><?php echo $Language->phrase("RptCnt") ?></span><?php echo $Language->phrase("AggregateEqual") ?><span class="ew-aggregate-value"><?php echo FormatNumber($Voucher2FWithdrawal_Summary_summary->type->Count, 0); ?></span>)</span>
		</td>
	</tr>
<?php } ?>
<?php
	$Voucher2FWithdrawal_Summary_summary->status->getDistinctValues($Voucher2FWithdrawal_Summary_summary->type->Records);
	$Voucher2FWithdrawal_Summary_summary->setGroupCount(count($Voucher2FWithdrawal_Summary_summary->status->DistinctValues), $Voucher2FWithdrawal_Summary_summary->GroupCounter[1], $Voucher2FWithdrawal_Summary_summary->GroupCounter[2], $Voucher2FWithdrawal_Summary_summary->GroupCounter[3]);
	$Voucher2FWithdrawal_Summary_summary->GroupCounter[4] = 0; // Init group count index
	foreach ($Voucher2FWithdrawal_Summary_summary->status->DistinctValues as $status) { // Load records for this distinct value
		$Voucher2FWithdrawal_Summary_summary->status->setGroupValue($status); // Set group value
		$Voucher2FWithdrawal_Summary_summary->status->getDistinctRecords($Voucher2FWithdrawal_Summary_summary->type->Records, $Voucher2FWithdrawal_Summary_summary->status->groupValue());
		$Voucher2FWithdrawal_Summary_summary->status->LevelBreak = TRUE; // Set field level break
		$Voucher2FWithdrawal_Summary_summary->GroupCounter[4]++;
		$Voucher2FWithdrawal_Summary_summary->status->getCnt($Voucher2FWithdrawal_Summary_summary->status->Records); // Get record count
		$Voucher2FWithdrawal_Summary_summary->setGroupCount($Voucher2FWithdrawal_Summary_summary->status->Count, $Voucher2FWithdrawal_Summary_summary->GroupCounter[1], $Voucher2FWithdrawal_Summary_summary->GroupCounter[2], $Voucher2FWithdrawal_Summary_summary->GroupCounter[3], $Voucher2FWithdrawal_Summary_summary->GroupCounter[4]);
?>
<?php if ($Voucher2FWithdrawal_Summary_summary->status->Visible && $Voucher2FWithdrawal_Summary_summary->status->ShowGroupHeaderAsRow) { ?>
<?php

		// Render header row
		$Voucher2FWithdrawal_Summary_summary->status->setDbValue($status); // Set current value for status
		$Voucher2FWithdrawal_Summary_summary->resetAttributes();
		$Voucher2FWithdrawal_Summary_summary->RowType = ROWTYPE_TOTAL;
		$Voucher2FWithdrawal_Summary_summary->RowTotalType = ROWTOTAL_GROUP;
		$Voucher2FWithdrawal_Summary_summary->RowTotalSubType = ROWTOTAL_HEADER;
		$Voucher2FWithdrawal_Summary_summary->RowGroupLevel = 4;
		$Voucher2FWithdrawal_Summary_summary->renderRow();
?>
	<tr<?php echo $Voucher2FWithdrawal_Summary_summary->rowAttributes(); ?>>
<?php if ($Voucher2FWithdrawal_Summary_summary->transferTime->Visible) { ?>
		<td data-field="transferTime"<?php echo $Voucher2FWithdrawal_Summary_summary->transferTime->cellAttributes(); ?>></td>
<?php } ?>
<?php if ($Voucher2FWithdrawal_Summary_summary->currID->Visible) { ?>
		<td data-field="currID"<?php echo $Voucher2FWithdrawal_Summary_summary->currID->cellAttributes(); ?>></td>
<?php } ?>
<?php if ($Voucher2FWithdrawal_Summary_summary->type->Visible) { ?>
		<td data-field="type"<?php echo $Voucher2FWithdrawal_Summary_summary->type->cellAttributes(); ?>></td>
<?php } ?>
<?php if ($Voucher2FWithdrawal_Summary_summary->status->Visible) { ?>
		<td data-field="status"<?php echo $Voucher2FWithdrawal_Summary_summary->status->cellAttributes(); ?>><span class="ew-group-toggle icon-collapse"></span></td>
<?php } ?>
		<td data-field="status" colspan="<?php echo ($Page->GroupColumnCount + $Page->DetailColumnCount - 4) ?>"<?php echo $Voucher2FWithdrawal_Summary_summary->status->cellAttributes() ?>>
<?php if ($Voucher2FWithdrawal_Summary_summary->sortUrl($Voucher2FWithdrawal_Summary_summary->status) == "") { ?>
		<span class="ew-summary-caption Voucher2FWithdrawal_Summary_status"><span class="ew-table-header-caption"><?php echo $Voucher2FWithdrawal_Summary_summary->status->caption() ?></span></span>
<?php } else { ?>
		<span class="ew-table-header-btn ew-pointer ew-summary-caption Voucher2FWithdrawal_Summary_status" onclick="ew.sort(event, '<?php echo $Voucher2FWithdrawal_Summary_summary->sortUrl($Voucher2FWithdrawal_Summary_summary->status) ?>', 1);">
			<span class="ew-table-header-caption"><?php echo $Voucher2FWithdrawal_Summary_summary->status->caption() ?></span>
			<span class="ew-table-header-sort"><?php if ($Voucher2FWithdrawal_Summary_summary->status->getSort() == "ASC") { ?><i class="fas fa-sort-up"></i><?php } elseif ($Voucher2FWithdrawal_Summary_summary->status->getSort() == "DESC") { ?><i class="fas fa-sort-down"></i><?php } ?></span>
		</span>
<?php } ?>
		<?php echo $Language->phrase("SummaryColon") ?><span<?php echo $Voucher2FWithdrawal_Summary_summary->status->viewAttributes() ?>><?php echo $Voucher2FWithdrawal_Summary_summary->status->GroupViewValue ?></span>
		<span class="ew-summary-count">(<span class="ew-aggregate-caption"><?php echo $Language->phrase("RptCnt") ?></span><?php echo $Language->phrase("AggregateEqual") ?><span class="ew-aggregate-value"><?php echo FormatNumber($Voucher2FWithdrawal_Summary_summary->status->Count, 0); ?></span>)</span>
		</td>
	</tr>
<?php } ?>
<?php
	$Voucher2FWithdrawal_Summary_summary->RecordCount = 0; // Reset record count
	foreach ($Voucher2FWithdrawal_Summary_summary->status->Records as $record) {
		$Voucher2FWithdrawal_Summary_summary->RecordCount++;
		$Voucher2FWithdrawal_Summary_summary->RecordIndex++;
		$Voucher2FWithdrawal_Summary_summary->loadRowValues($record);
?>
<?php

		// Render detail row
		$Voucher2FWithdrawal_Summary_summary->resetAttributes();
		$Voucher2FWithdrawal_Summary_summary->RowType = ROWTYPE_DETAIL;
		$Voucher2FWithdrawal_Summary_summary->renderRow();
?>
	<tr<?php echo $Voucher2FWithdrawal_Summary_summary->rowAttributes(); ?>>
<?php if ($Voucher2FWithdrawal_Summary_summary->transferTime->Visible) { ?>
	<?php if ($Voucher2FWithdrawal_Summary_summary->transferTime->ShowGroupHeaderAsRow) { ?>
		<td data-field="transferTime"<?php echo $Voucher2FWithdrawal_Summary_summary->transferTime->cellAttributes(); ?>>&nbsp;</td>
	<?php } else { ?>
		<td data-field="transferTime"<?php echo $Voucher2FWithdrawal_Summary_summary->transferTime->cellAttributes(); ?>><span<?php echo $Voucher2FWithdrawal_Summary_summary->transferTime->viewAttributes() ?>><?php echo $Voucher2FWithdrawal_Summary_summary->transferTime->GroupViewValue ?></span></td>
	<?php } ?>
<?php } ?>
<?php if ($Voucher2FWithdrawal_Summary_summary->currID->Visible) { ?>
	<?php if ($Voucher2FWithdrawal_Summary_summary->currID->ShowGroupHeaderAsRow) { ?>
		<td data-field="currID"<?php echo $Voucher2FWithdrawal_Summary_summary->currID->cellAttributes(); ?>>&nbsp;</td>
	<?php } else { ?>
		<td data-field="currID"<?php echo $Voucher2FWithdrawal_Summary_summary->currID->cellAttributes(); ?>><span<?php echo $Voucher2FWithdrawal_Summary_summary->currID->viewAttributes() ?>><?php echo $Voucher2FWithdrawal_Summary_summary->currID->GroupViewValue ?></span></td>
	<?php } ?>
<?php } ?>
<?php if ($Voucher2FWithdrawal_Summary_summary->type->Visible) { ?>
	<?php if ($Voucher2FWithdrawal_Summary_summary->type->ShowGroupHeaderAsRow) { ?>
		<td data-field="type"<?php echo $Voucher2FWithdrawal_Summary_summary->type->cellAttributes(); ?>>&nbsp;</td>
	<?php } else { ?>
		<td data-field="type"<?php echo $Voucher2FWithdrawal_Summary_summary->type->cellAttributes(); ?>><span<?php echo $Voucher2FWithdrawal_Summary_summary->type->viewAttributes() ?>><?php echo $Voucher2FWithdrawal_Summary_summary->type->GroupViewValue ?></span></td>
	<?php } ?>
<?php } ?>
<?php if ($Voucher2FWithdrawal_Summary_summary->status->Visible) { ?>
	<?php if ($Voucher2FWithdrawal_Summary_summary->status->ShowGroupHeaderAsRow) { ?>
		<td data-field="status"<?php echo $Voucher2FWithdrawal_Summary_summary->status->cellAttributes(); ?>>&nbsp;</td>
	<?php } else { ?>
		<td data-field="status"<?php echo $Voucher2FWithdrawal_Summary_summary->status->cellAttributes(); ?>><span<?php echo $Voucher2FWithdrawal_Summary_summary->status->viewAttributes() ?>><?php echo $Voucher2FWithdrawal_Summary_summary->status->GroupViewValue ?></span></td>
	<?php } ?>
<?php } ?>
<?php if ($Voucher2FWithdrawal_Summary_summary->sourceUserID->Visible) { ?>
		<td data-field="sourceUserID"<?php echo $Voucher2FWithdrawal_Summary_summary->sourceUserID->cellAttributes() ?>>
<span<?php echo $Voucher2FWithdrawal_Summary_summary->sourceUserID->viewAttributes() ?>><?php echo $Voucher2FWithdrawal_Summary_summary->sourceUserID->getViewValue() ?></span>
</td>
<?php } ?>
<?php if ($Voucher2FWithdrawal_Summary_summary->amountSender->Visible) { ?>
		<td data-field="amountSender"<?php echo $Voucher2FWithdrawal_Summary_summary->amountSender->cellAttributes() ?>>
<span<?php echo $Voucher2FWithdrawal_Summary_summary->amountSender->viewAttributes() ?>><?php echo $Voucher2FWithdrawal_Summary_summary->amountSender->getViewValue() ?></span>
</td>
<?php } ?>
<?php if ($Voucher2FWithdrawal_Summary_summary->serviceFee->Visible) { ?>
		<td data-field="serviceFee"<?php echo $Voucher2FWithdrawal_Summary_summary->serviceFee->cellAttributes() ?>>
<span<?php echo $Voucher2FWithdrawal_Summary_summary->serviceFee->viewAttributes() ?>><?php echo $Voucher2FWithdrawal_Summary_summary->serviceFee->getViewValue() ?></span>
</td>
<?php } ?>
<?php if ($Voucher2FWithdrawal_Summary_summary->feetax->Visible) { ?>
		<td data-field="feetax"<?php echo $Voucher2FWithdrawal_Summary_summary->feetax->cellAttributes() ?>>
<span<?php echo $Voucher2FWithdrawal_Summary_summary->feetax->viewAttributes() ?>><?php echo $Voucher2FWithdrawal_Summary_summary->feetax->getViewValue() ?></span>
</td>
<?php } ?>
<?php if ($Voucher2FWithdrawal_Summary_summary->feetaxtotal->Visible) { ?>
		<td data-field="feetaxtotal"<?php echo $Voucher2FWithdrawal_Summary_summary->feetaxtotal->cellAttributes() ?>>
<span<?php echo $Voucher2FWithdrawal_Summary_summary->feetaxtotal->viewAttributes() ?>><?php echo $Voucher2FWithdrawal_Summary_summary->feetaxtotal->getViewValue() ?></span>
</td>
<?php } ?>
<?php if ($Voucher2FWithdrawal_Summary_summary->recipientname->Visible) { ?>
		<td data-field="recipientname"<?php echo $Voucher2FWithdrawal_Summary_summary->recipientname->cellAttributes() ?>>
<span<?php echo $Voucher2FWithdrawal_Summary_summary->recipientname->viewAttributes() ?>><?php echo $Voucher2FWithdrawal_Summary_summary->recipientname->getViewValue() ?></span>
</td>
<?php } ?>
<?php if ($Voucher2FWithdrawal_Summary_summary->recipientemail->Visible) { ?>
		<td data-field="recipientemail"<?php echo $Voucher2FWithdrawal_Summary_summary->recipientemail->cellAttributes() ?>>
<span<?php echo $Voucher2FWithdrawal_Summary_summary->recipientemail->viewAttributes() ?>><?php echo $Voucher2FWithdrawal_Summary_summary->recipientemail->getViewValue() ?></span>
</td>
<?php } ?>
<?php if ($Voucher2FWithdrawal_Summary_summary->presentationcode->Visible) { ?>
		<td data-field="presentationcode"<?php echo $Voucher2FWithdrawal_Summary_summary->presentationcode->cellAttributes() ?>>
<span<?php echo $Voucher2FWithdrawal_Summary_summary->presentationcode->viewAttributes() ?>><?php echo $Voucher2FWithdrawal_Summary_summary->presentationcode->getViewValue() ?></span>
</td>
<?php } ?>
<?php if ($Voucher2FWithdrawal_Summary_summary->secondaryemail->Visible) { ?>
		<td data-field="secondaryemail"<?php echo $Voucher2FWithdrawal_Summary_summary->secondaryemail->cellAttributes() ?>>
<span<?php echo $Voucher2FWithdrawal_Summary_summary->secondaryemail->viewAttributes() ?>><?php echo $Voucher2FWithdrawal_Summary_summary->secondaryemail->getViewValue() ?></span>
</td>
<?php } ?>
<?php if ($Voucher2FWithdrawal_Summary_summary->secondarytoken->Visible) { ?>
		<td data-field="secondarytoken"<?php echo $Voucher2FWithdrawal_Summary_summary->secondarytoken->cellAttributes() ?>>
<span<?php echo $Voucher2FWithdrawal_Summary_summary->secondarytoken->viewAttributes() ?>><?php echo $Voucher2FWithdrawal_Summary_summary->secondarytoken->getViewValue() ?></span>
</td>
<?php } ?>
<?php if ($Voucher2FWithdrawal_Summary_summary->secondaryname->Visible) { ?>
		<td data-field="secondaryname"<?php echo $Voucher2FWithdrawal_Summary_summary->secondaryname->cellAttributes() ?>>
<span<?php echo $Voucher2FWithdrawal_Summary_summary->secondaryname->viewAttributes() ?>><?php echo $Voucher2FWithdrawal_Summary_summary->secondaryname->getViewValue() ?></span>
</td>
<?php } ?>
<?php if ($Voucher2FWithdrawal_Summary_summary->sendercustomeruserid->Visible) { ?>
		<td data-field="sendercustomeruserid"<?php echo $Voucher2FWithdrawal_Summary_summary->sendercustomeruserid->cellAttributes() ?>>
<span<?php echo $Voucher2FWithdrawal_Summary_summary->sendercustomeruserid->viewAttributes() ?>><?php echo $Voucher2FWithdrawal_Summary_summary->sendercustomeruserid->getViewValue() ?></span>
</td>
<?php } ?>
<?php if ($Voucher2FWithdrawal_Summary_summary->systemshare->Visible) { ?>
		<td data-field="systemshare"<?php echo $Voucher2FWithdrawal_Summary_summary->systemshare->cellAttributes() ?>>
<span<?php echo $Voucher2FWithdrawal_Summary_summary->systemshare->viewAttributes() ?>><?php echo $Voucher2FWithdrawal_Summary_summary->systemshare->getViewValue() ?></span>
</td>
<?php } ?>
<?php if ($Voucher2FWithdrawal_Summary_summary->franchiseeshare->Visible) { ?>
		<td data-field="franchiseeshare"<?php echo $Voucher2FWithdrawal_Summary_summary->franchiseeshare->cellAttributes() ?>>
<span<?php echo $Voucher2FWithdrawal_Summary_summary->franchiseeshare->viewAttributes() ?>><?php echo $Voucher2FWithdrawal_Summary_summary->franchiseeshare->getViewValue() ?></span>
</td>
<?php } ?>
<?php if ($Voucher2FWithdrawal_Summary_summary->managershare->Visible) { ?>
		<td data-field="managershare"<?php echo $Voucher2FWithdrawal_Summary_summary->managershare->cellAttributes() ?>>
<span<?php echo $Voucher2FWithdrawal_Summary_summary->managershare->viewAttributes() ?>><?php echo $Voucher2FWithdrawal_Summary_summary->managershare->getViewValue() ?></span>
</td>
<?php } ?>
<?php if ($Voucher2FWithdrawal_Summary_summary->brokershare->Visible) { ?>
		<td data-field="brokershare"<?php echo $Voucher2FWithdrawal_Summary_summary->brokershare->cellAttributes() ?>>
<span<?php echo $Voucher2FWithdrawal_Summary_summary->brokershare->viewAttributes() ?>><?php echo $Voucher2FWithdrawal_Summary_summary->brokershare->getViewValue() ?></span>
</td>
<?php } ?>
	</tr>
<?php
	}
	} // End group level 3
	} // End group level 2
	} // End group level 1
?>
<?php

	// Next group
	$Voucher2FWithdrawal_Summary_summary->loadGroupRowValues();

	// Show header if page break
	if ($Voucher2FWithdrawal_Summary_summary->isExport())
		$Voucher2FWithdrawal_Summary_summary->ShowHeader = ($Voucher2FWithdrawal_Summary_summary->ExportPageBreakCount == 0) ? FALSE : ($Voucher2FWithdrawal_Summary_summary->GroupCount % $Voucher2FWithdrawal_Summary_summary->ExportPageBreakCount == 0);

	// Page_Breaking server event
	if ($Voucher2FWithdrawal_Summary_summary->ShowHeader)
		$Voucher2FWithdrawal_Summary_summary->Page_Breaking($Voucher2FWithdrawal_Summary_summary->ShowHeader, $Voucher2FWithdrawal_Summary_summary->PageBreakContent);
	$Voucher2FWithdrawal_Summary_summary->GroupCount++;
} // End while
?>
<?php if ($Voucher2FWithdrawal_Summary_summary->TotalGroups > 0) { ?>
</tbody>
<tfoot>
<?php
	$Voucher2FWithdrawal_Summary_summary->resetAttributes();
	$Voucher2FWithdrawal_Summary_summary->RowType = ROWTYPE_TOTAL;
	$Voucher2FWithdrawal_Summary_summary->RowTotalType = ROWTOTAL_GRAND;
	$Voucher2FWithdrawal_Summary_summary->RowTotalSubType = ROWTOTAL_FOOTER;
	$Voucher2FWithdrawal_Summary_summary->RowAttrs["class"] = "ew-rpt-grand-summary";
	$Voucher2FWithdrawal_Summary_summary->renderRow();
?>
<?php if ($Voucher2FWithdrawal_Summary_summary->transferTime->ShowCompactSummaryFooter) { ?>
	<tr<?php echo $Voucher2FWithdrawal_Summary_summary->rowAttributes() ?>><td colspan="<?php echo ($Voucher2FWithdrawal_Summary_summary->GroupColumnCount + $Voucher2FWithdrawal_Summary_summary->DetailColumnCount) ?>"><?php echo $Language->phrase("RptGrandSummary") ?> <span class="ew-summary-count">(<span class="ew-aggregate-caption"><?php echo $Language->phrase("RptCnt") ?></span><?php echo $Language->phrase("AggregateEqual") ?><span class="ew-aggregate-value"><?php echo FormatNumber($Voucher2FWithdrawal_Summary_summary->TotalCount, 0); ?></span>)</span></td></tr>
	<tr<?php echo $Voucher2FWithdrawal_Summary_summary->rowAttributes() ?>>
<?php if ($Voucher2FWithdrawal_Summary_summary->GroupColumnCount > 0) { ?>
		<td colspan="<?php echo $Voucher2FWithdrawal_Summary_summary->GroupColumnCount ?>" class="ew-rpt-grp-aggregate">&nbsp;</td>
<?php } ?>
<?php if ($Voucher2FWithdrawal_Summary_summary->sourceUserID->Visible) { ?>
		<td data-field="sourceUserID"<?php echo $Voucher2FWithdrawal_Summary_summary->sourceUserID->cellAttributes() ?>><span class="ew-aggregate-caption"><?php echo $Language->phrase("RptSum") ?></span><?php echo $Language->phrase("AggregateEqual") ?><span class="ew-aggregate-value"><span<?php echo $Voucher2FWithdrawal_Summary_summary->sourceUserID->viewAttributes() ?>><?php echo $Voucher2FWithdrawal_Summary_summary->sourceUserID->SumViewValue ?></span></span></td>
<?php } ?>
<?php if ($Voucher2FWithdrawal_Summary_summary->amountSender->Visible) { ?>
		<td data-field="amountSender"<?php echo $Voucher2FWithdrawal_Summary_summary->amountSender->cellAttributes() ?>><span class="ew-aggregate-caption"><?php echo $Language->phrase("RptSum") ?></span><?php echo $Language->phrase("AggregateEqual") ?><span class="ew-aggregate-value"><span<?php echo $Voucher2FWithdrawal_Summary_summary->amountSender->viewAttributes() ?>><?php echo $Voucher2FWithdrawal_Summary_summary->amountSender->SumViewValue ?></span></span></td>
<?php } ?>
<?php if ($Voucher2FWithdrawal_Summary_summary->serviceFee->Visible) { ?>
		<td data-field="serviceFee"<?php echo $Voucher2FWithdrawal_Summary_summary->serviceFee->cellAttributes() ?>><span class="ew-aggregate-caption"><?php echo $Language->phrase("RptSum") ?></span><?php echo $Language->phrase("AggregateEqual") ?><span class="ew-aggregate-value"><span<?php echo $Voucher2FWithdrawal_Summary_summary->serviceFee->viewAttributes() ?>><?php echo $Voucher2FWithdrawal_Summary_summary->serviceFee->SumViewValue ?></span></span></td>
<?php } ?>
<?php if ($Voucher2FWithdrawal_Summary_summary->feetax->Visible) { ?>
		<td data-field="feetax"<?php echo $Voucher2FWithdrawal_Summary_summary->feetax->cellAttributes() ?>></td>
<?php } ?>
<?php if ($Voucher2FWithdrawal_Summary_summary->feetaxtotal->Visible) { ?>
		<td data-field="feetaxtotal"<?php echo $Voucher2FWithdrawal_Summary_summary->feetaxtotal->cellAttributes() ?>><span class="ew-aggregate-caption"><?php echo $Language->phrase("RptSum") ?></span><?php echo $Language->phrase("AggregateEqual") ?><span class="ew-aggregate-value"><span<?php echo $Voucher2FWithdrawal_Summary_summary->feetaxtotal->viewAttributes() ?>><?php echo $Voucher2FWithdrawal_Summary_summary->feetaxtotal->SumViewValue ?></span></span></td>
<?php } ?>
<?php if ($Voucher2FWithdrawal_Summary_summary->recipientname->Visible) { ?>
		<td data-field="recipientname"<?php echo $Voucher2FWithdrawal_Summary_summary->recipientname->cellAttributes() ?>></td>
<?php } ?>
<?php if ($Voucher2FWithdrawal_Summary_summary->recipientemail->Visible) { ?>
		<td data-field="recipientemail"<?php echo $Voucher2FWithdrawal_Summary_summary->recipientemail->cellAttributes() ?>></td>
<?php } ?>
<?php if ($Voucher2FWithdrawal_Summary_summary->presentationcode->Visible) { ?>
		<td data-field="presentationcode"<?php echo $Voucher2FWithdrawal_Summary_summary->presentationcode->cellAttributes() ?>></td>
<?php } ?>
<?php if ($Voucher2FWithdrawal_Summary_summary->secondaryemail->Visible) { ?>
		<td data-field="secondaryemail"<?php echo $Voucher2FWithdrawal_Summary_summary->secondaryemail->cellAttributes() ?>></td>
<?php } ?>
<?php if ($Voucher2FWithdrawal_Summary_summary->secondarytoken->Visible) { ?>
		<td data-field="secondarytoken"<?php echo $Voucher2FWithdrawal_Summary_summary->secondarytoken->cellAttributes() ?>></td>
<?php } ?>
<?php if ($Voucher2FWithdrawal_Summary_summary->secondaryname->Visible) { ?>
		<td data-field="secondaryname"<?php echo $Voucher2FWithdrawal_Summary_summary->secondaryname->cellAttributes() ?>></td>
<?php } ?>
<?php if ($Voucher2FWithdrawal_Summary_summary->sendercustomeruserid->Visible) { ?>
		<td data-field="sendercustomeruserid"<?php echo $Voucher2FWithdrawal_Summary_summary->sendercustomeruserid->cellAttributes() ?>></td>
<?php } ?>
<?php if ($Voucher2FWithdrawal_Summary_summary->systemshare->Visible) { ?>
		<td data-field="systemshare"<?php echo $Voucher2FWithdrawal_Summary_summary->systemshare->cellAttributes() ?>></td>
<?php } ?>
<?php if ($Voucher2FWithdrawal_Summary_summary->franchiseeshare->Visible) { ?>
		<td data-field="franchiseeshare"<?php echo $Voucher2FWithdrawal_Summary_summary->franchiseeshare->cellAttributes() ?>></td>
<?php } ?>
<?php if ($Voucher2FWithdrawal_Summary_summary->managershare->Visible) { ?>
		<td data-field="managershare"<?php echo $Voucher2FWithdrawal_Summary_summary->managershare->cellAttributes() ?>></td>
<?php } ?>
<?php if ($Voucher2FWithdrawal_Summary_summary->brokershare->Visible) { ?>
		<td data-field="brokershare"<?php echo $Voucher2FWithdrawal_Summary_summary->brokershare->cellAttributes() ?>></td>
<?php } ?>
	</tr>
<?php } else { ?>
	<tr<?php echo $Voucher2FWithdrawal_Summary_summary->rowAttributes() ?>><td colspan="<?php echo ($Voucher2FWithdrawal_Summary_summary->GroupColumnCount + $Voucher2FWithdrawal_Summary_summary->DetailColumnCount) ?>"><?php echo $Language->phrase("RptGrandSummary") ?> <span class="ew-summary-count">(<?php echo FormatNumber($Voucher2FWithdrawal_Summary_summary->TotalCount, 0); ?><?php echo $Language->phrase("RptDtlRec") ?>)</span></td></tr>
	<tr<?php echo $Voucher2FWithdrawal_Summary_summary->rowAttributes() ?>>
<?php if ($Voucher2FWithdrawal_Summary_summary->GroupColumnCount > 0) { ?>
		<td colspan="<?php echo $Voucher2FWithdrawal_Summary_summary->GroupColumnCount ?>" class="ew-rpt-grp-aggregate"><?php echo $Language->phrase("RptSum") ?></td>
<?php } ?>
<?php if ($Voucher2FWithdrawal_Summary_summary->sourceUserID->Visible) { ?>
		<td data-field="sourceUserID"<?php echo $Voucher2FWithdrawal_Summary_summary->sourceUserID->cellAttributes() ?>>
<span<?php echo $Voucher2FWithdrawal_Summary_summary->sourceUserID->viewAttributes() ?>><?php echo $Voucher2FWithdrawal_Summary_summary->sourceUserID->SumViewValue ?></span>
</td>
<?php } ?>
<?php if ($Voucher2FWithdrawal_Summary_summary->amountSender->Visible) { ?>
		<td data-field="amountSender"<?php echo $Voucher2FWithdrawal_Summary_summary->amountSender->cellAttributes() ?>>
<span<?php echo $Voucher2FWithdrawal_Summary_summary->amountSender->viewAttributes() ?>><?php echo $Voucher2FWithdrawal_Summary_summary->amountSender->SumViewValue ?></span>
</td>
<?php } ?>
<?php if ($Voucher2FWithdrawal_Summary_summary->serviceFee->Visible) { ?>
		<td data-field="serviceFee"<?php echo $Voucher2FWithdrawal_Summary_summary->serviceFee->cellAttributes() ?>>
<span<?php echo $Voucher2FWithdrawal_Summary_summary->serviceFee->viewAttributes() ?>><?php echo $Voucher2FWithdrawal_Summary_summary->serviceFee->SumViewValue ?></span>
</td>
<?php } ?>
<?php if ($Voucher2FWithdrawal_Summary_summary->feetax->Visible) { ?>
		<td data-field="feetax"<?php echo $Voucher2FWithdrawal_Summary_summary->feetax->cellAttributes() ?>>&nbsp;</td>
<?php } ?>
<?php if ($Voucher2FWithdrawal_Summary_summary->feetaxtotal->Visible) { ?>
		<td data-field="feetaxtotal"<?php echo $Voucher2FWithdrawal_Summary_summary->feetaxtotal->cellAttributes() ?>>
<span<?php echo $Voucher2FWithdrawal_Summary_summary->feetaxtotal->viewAttributes() ?>><?php echo $Voucher2FWithdrawal_Summary_summary->feetaxtotal->SumViewValue ?></span>
</td>
<?php } ?>
<?php if ($Voucher2FWithdrawal_Summary_summary->recipientname->Visible) { ?>
		<td data-field="recipientname"<?php echo $Voucher2FWithdrawal_Summary_summary->recipientname->cellAttributes() ?>>&nbsp;</td>
<?php } ?>
<?php if ($Voucher2FWithdrawal_Summary_summary->recipientemail->Visible) { ?>
		<td data-field="recipientemail"<?php echo $Voucher2FWithdrawal_Summary_summary->recipientemail->cellAttributes() ?>>&nbsp;</td>
<?php } ?>
<?php if ($Voucher2FWithdrawal_Summary_summary->presentationcode->Visible) { ?>
		<td data-field="presentationcode"<?php echo $Voucher2FWithdrawal_Summary_summary->presentationcode->cellAttributes() ?>>&nbsp;</td>
<?php } ?>
<?php if ($Voucher2FWithdrawal_Summary_summary->secondaryemail->Visible) { ?>
		<td data-field="secondaryemail"<?php echo $Voucher2FWithdrawal_Summary_summary->secondaryemail->cellAttributes() ?>>&nbsp;</td>
<?php } ?>
<?php if ($Voucher2FWithdrawal_Summary_summary->secondarytoken->Visible) { ?>
		<td data-field="secondarytoken"<?php echo $Voucher2FWithdrawal_Summary_summary->secondarytoken->cellAttributes() ?>>&nbsp;</td>
<?php } ?>
<?php if ($Voucher2FWithdrawal_Summary_summary->secondaryname->Visible) { ?>
		<td data-field="secondaryname"<?php echo $Voucher2FWithdrawal_Summary_summary->secondaryname->cellAttributes() ?>>&nbsp;</td>
<?php } ?>
<?php if ($Voucher2FWithdrawal_Summary_summary->sendercustomeruserid->Visible) { ?>
		<td data-field="sendercustomeruserid"<?php echo $Voucher2FWithdrawal_Summary_summary->sendercustomeruserid->cellAttributes() ?>>&nbsp;</td>
<?php } ?>
<?php if ($Voucher2FWithdrawal_Summary_summary->systemshare->Visible) { ?>
		<td data-field="systemshare"<?php echo $Voucher2FWithdrawal_Summary_summary->systemshare->cellAttributes() ?>>&nbsp;</td>
<?php } ?>
<?php if ($Voucher2FWithdrawal_Summary_summary->franchiseeshare->Visible) { ?>
		<td data-field="franchiseeshare"<?php echo $Voucher2FWithdrawal_Summary_summary->franchiseeshare->cellAttributes() ?>>&nbsp;</td>
<?php } ?>
<?php if ($Voucher2FWithdrawal_Summary_summary->managershare->Visible) { ?>
		<td data-field="managershare"<?php echo $Voucher2FWithdrawal_Summary_summary->managershare->cellAttributes() ?>>&nbsp;</td>
<?php } ?>
<?php if ($Voucher2FWithdrawal_Summary_summary->brokershare->Visible) { ?>
		<td data-field="brokershare"<?php echo $Voucher2FWithdrawal_Summary_summary->brokershare->cellAttributes() ?>>&nbsp;</td>
<?php } ?>
	</tr>
<?php } ?>
</tfoot>
</table>
</div>
<!-- /.ew-grid-middle-panel -->
<!-- Report grid (end) -->
<?php if (!$Voucher2FWithdrawal_Summary_summary->isExport() && !($Voucher2FWithdrawal_Summary_summary->DrillDown && $Voucher2FWithdrawal_Summary_summary->TotalGroups > 0)) { ?>
<!-- Bottom pager -->
<div class="card-footer ew-grid-lower-panel">
<form name="ew-pager-form" class="form-inline ew-form ew-pager-form" action="<?php echo CurrentPageName() ?>">
<?php echo $Voucher2FWithdrawal_Summary_summary->Pager->render() ?>
</form>
<div class="clearfix"></div>
</div>
<?php } ?>
</div>
<!-- /.ew-grid -->
<?php } ?>
</div>
<!-- /#report-summary -->
<!-- Summary report (end) -->
<?php if ((!$Voucher2FWithdrawal_Summary_summary->isExport() || $Voucher2FWithdrawal_Summary_summary->isExport("print")) && !$DashboardReport) { ?>
</div>
<!-- /#ew-center -->
<?php } ?>
<?php if ((!$Voucher2FWithdrawal_Summary_summary->isExport() || $Voucher2FWithdrawal_Summary_summary->isExport("print")) && !$DashboardReport) { ?>
</div>
<!-- /.row -->
<?php } ?>
<?php if ((!$Voucher2FWithdrawal_Summary_summary->isExport() || $Voucher2FWithdrawal_Summary_summary->isExport("print")) && !$DashboardReport) { ?>
</div>
<!-- /.ew-report -->
<?php } ?>
<?php
$Voucher2FWithdrawal_Summary_summary->showPageFooter();
if (Config("DEBUG"))
	echo GetDebugMessage();
?>
<?php if (!$Voucher2FWithdrawal_Summary_summary->isExport() && !$Voucher2FWithdrawal_Summary_summary->DrillDown && !$DashboardReport) { ?>
<script>
loadjs.ready("load", function() {

	// Startup script
	// Write your table-specific startup script here
	// console.log("page loaded");

});
</script>
<?php } ?>
<?php if (!$DashboardReport) { ?>
<?php include_once "footer.php"; ?>
<?php } ?>
<?php
$Voucher2FWithdrawal_Summary_summary->terminate();
?>