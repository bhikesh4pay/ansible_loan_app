<?php
namespace PHPMaker2020\_4payadmin;

// Autoload
include_once "autoload.php";

// Session
if (session_status() !== PHP_SESSION_ACTIVE)
	\Delight\Cookie\Session::start(Config("COOKIE_SAMESITE")); // Init session data

// Output buffering
ob_start();
?>
<?php

// Write header
WriteHeader(FALSE);

// Create page object
$merchantpolicy_delete = new merchantpolicy_delete();

// Run the page
$merchantpolicy_delete->run();

// Setup login status
SetupLoginStatus();
SetClientVar("login", LoginStatus());

// Global Page Rendering event (in userfn*.php)
Page_Rendering();

// Page Rendering event
$merchantpolicy_delete->Page_Render();
?>
<?php include_once "header.php"; ?>
<script>
var fmerchantpolicydelete, currentPageID;
loadjs.ready("head", function() {

	// Form object
	currentPageID = ew.PAGE_ID = "delete";
	fmerchantpolicydelete = currentForm = new ew.Form("fmerchantpolicydelete", "delete");
	loadjs.done("fmerchantpolicydelete");
});
</script>
<script>
loadjs.ready("head", function() {

	// Client script
	// Write your client script here, no need to add script tags.

});
</script>
<?php $merchantpolicy_delete->showPageHeader(); ?>
<?php
$merchantpolicy_delete->showMessage();
?>
<form name="fmerchantpolicydelete" id="fmerchantpolicydelete" class="form-inline ew-form ew-delete-form" action="<?php echo CurrentPageName() ?>" method="post">
<?php if ($Page->CheckToken) { ?>
<input type="hidden" name="<?php echo Config("TOKEN_NAME") ?>" value="<?php echo $Page->Token ?>">
<?php } ?>
<input type="hidden" name="t" value="merchantpolicy">
<input type="hidden" name="action" id="action" value="delete">
<?php foreach ($merchantpolicy_delete->RecKeys as $key) { ?>
<?php $keyvalue = is_array($key) ? implode(Config("COMPOSITE_KEY_SEPARATOR"), $key) : $key; ?>
<input type="hidden" name="key_m[]" value="<?php echo HtmlEncode($keyvalue) ?>">
<?php } ?>
<div class="card ew-card ew-grid">
<div class="<?php echo ResponsiveTableClass() ?>card-body ew-grid-middle-panel">
<table class="table ew-table">
	<thead>
	<tr class="ew-table-header">
<?php if ($merchantpolicy_delete->policyid->Visible) { // policyid ?>
		<th class="<?php echo $merchantpolicy_delete->policyid->headerCellClass() ?>"><span id="elh_merchantpolicy_policyid" class="merchantpolicy_policyid"><?php echo $merchantpolicy_delete->policyid->caption() ?></span></th>
<?php } ?>
<?php if ($merchantpolicy_delete->merchantid->Visible) { // merchantid ?>
		<th class="<?php echo $merchantpolicy_delete->merchantid->headerCellClass() ?>"><span id="elh_merchantpolicy_merchantid" class="merchantpolicy_merchantid"><?php echo $merchantpolicy_delete->merchantid->caption() ?></span></th>
<?php } ?>
<?php if ($merchantpolicy_delete->label->Visible) { // label ?>
		<th class="<?php echo $merchantpolicy_delete->label->headerCellClass() ?>"><span id="elh_merchantpolicy_label" class="merchantpolicy_label"><?php echo $merchantpolicy_delete->label->caption() ?></span></th>
<?php } ?>
<?php if ($merchantpolicy_delete->filename->Visible) { // filename ?>
		<th class="<?php echo $merchantpolicy_delete->filename->headerCellClass() ?>"><span id="elh_merchantpolicy_filename" class="merchantpolicy_filename"><?php echo $merchantpolicy_delete->filename->caption() ?></span></th>
<?php } ?>
<?php if ($merchantpolicy_delete->active->Visible) { // active ?>
		<th class="<?php echo $merchantpolicy_delete->active->headerCellClass() ?>"><span id="elh_merchantpolicy_active" class="merchantpolicy_active"><?php echo $merchantpolicy_delete->active->caption() ?></span></th>
<?php } ?>
<?php if ($merchantpolicy_delete->lastupdatedate->Visible) { // lastupdatedate ?>
		<th class="<?php echo $merchantpolicy_delete->lastupdatedate->headerCellClass() ?>"><span id="elh_merchantpolicy_lastupdatedate" class="merchantpolicy_lastupdatedate"><?php echo $merchantpolicy_delete->lastupdatedate->caption() ?></span></th>
<?php } ?>
	</tr>
	</thead>
	<tbody>
<?php
$merchantpolicy_delete->RecordCount = 0;
$i = 0;
while (!$merchantpolicy_delete->Recordset->EOF) {
	$merchantpolicy_delete->RecordCount++;
	$merchantpolicy_delete->RowCount++;

	// Set row properties
	$merchantpolicy->resetAttributes();
	$merchantpolicy->RowType = ROWTYPE_VIEW; // View

	// Get the field contents
	$merchantpolicy_delete->loadRowValues($merchantpolicy_delete->Recordset);

	// Render row
	$merchantpolicy_delete->renderRow();
?>
	<tr <?php echo $merchantpolicy->rowAttributes() ?>>
<?php if ($merchantpolicy_delete->policyid->Visible) { // policyid ?>
		<td <?php echo $merchantpolicy_delete->policyid->cellAttributes() ?>>
<span id="el<?php echo $merchantpolicy_delete->RowCount ?>_merchantpolicy_policyid" class="merchantpolicy_policyid">
<span<?php echo $merchantpolicy_delete->policyid->viewAttributes() ?>><?php echo $merchantpolicy_delete->policyid->getViewValue() ?></span>
</span>
</td>
<?php } ?>
<?php if ($merchantpolicy_delete->merchantid->Visible) { // merchantid ?>
		<td <?php echo $merchantpolicy_delete->merchantid->cellAttributes() ?>>
<span id="el<?php echo $merchantpolicy_delete->RowCount ?>_merchantpolicy_merchantid" class="merchantpolicy_merchantid">
<span<?php echo $merchantpolicy_delete->merchantid->viewAttributes() ?>><?php echo $merchantpolicy_delete->merchantid->getViewValue() ?></span>
</span>
</td>
<?php } ?>
<?php if ($merchantpolicy_delete->label->Visible) { // label ?>
		<td <?php echo $merchantpolicy_delete->label->cellAttributes() ?>>
<span id="el<?php echo $merchantpolicy_delete->RowCount ?>_merchantpolicy_label" class="merchantpolicy_label">
<span<?php echo $merchantpolicy_delete->label->viewAttributes() ?>><?php echo $merchantpolicy_delete->label->getViewValue() ?></span>
</span>
</td>
<?php } ?>
<?php if ($merchantpolicy_delete->filename->Visible) { // filename ?>
		<td <?php echo $merchantpolicy_delete->filename->cellAttributes() ?>>
<span id="el<?php echo $merchantpolicy_delete->RowCount ?>_merchantpolicy_filename" class="merchantpolicy_filename">
<span<?php echo $merchantpolicy_delete->filename->viewAttributes() ?>><?php echo $merchantpolicy_delete->filename->getViewValue() ?></span>
</span>
</td>
<?php } ?>
<?php if ($merchantpolicy_delete->active->Visible) { // active ?>
		<td <?php echo $merchantpolicy_delete->active->cellAttributes() ?>>
<span id="el<?php echo $merchantpolicy_delete->RowCount ?>_merchantpolicy_active" class="merchantpolicy_active">
<span<?php echo $merchantpolicy_delete->active->viewAttributes() ?>><?php echo $merchantpolicy_delete->active->getViewValue() ?></span>
</span>
</td>
<?php } ?>
<?php if ($merchantpolicy_delete->lastupdatedate->Visible) { // lastupdatedate ?>
		<td <?php echo $merchantpolicy_delete->lastupdatedate->cellAttributes() ?>>
<span id="el<?php echo $merchantpolicy_delete->RowCount ?>_merchantpolicy_lastupdatedate" class="merchantpolicy_lastupdatedate">
<span<?php echo $merchantpolicy_delete->lastupdatedate->viewAttributes() ?>><?php echo $merchantpolicy_delete->lastupdatedate->getViewValue() ?></span>
</span>
</td>
<?php } ?>
	</tr>
<?php
	$merchantpolicy_delete->Recordset->moveNext();
}
$merchantpolicy_delete->Recordset->close();
?>
</tbody>
</table>
</div>
</div>
<div>
<button class="btn btn-primary ew-btn" name="btn-action" id="btn-action" type="submit"><?php echo $Language->phrase("DeleteBtn") ?></button>
<button class="btn btn-default ew-btn" name="btn-cancel" id="btn-cancel" type="button" data-href="<?php echo $merchantpolicy_delete->getReturnUrl() ?>"><?php echo $Language->phrase("CancelBtn") ?></button>
</div>
</form>
<?php
$merchantpolicy_delete->showPageFooter();
if (Config("DEBUG"))
	echo GetDebugMessage();
?>
<script>
loadjs.ready("load", function() {

	// Startup script
	// Write your table-specific startup script here
	// console.log("page loaded");

});
</script>
<?php include_once "footer.php"; ?>
<?php
$merchantpolicy_delete->terminate();
?>