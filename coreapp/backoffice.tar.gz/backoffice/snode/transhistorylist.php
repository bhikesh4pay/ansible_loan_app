<?php
namespace PHPMaker2020\_4payadmin;

// Autoload
include_once "autoload.php";

// Session
if (session_status() !== PHP_SESSION_ACTIVE)
	\Delight\Cookie\Session::start(Config("COOKIE_SAMESITE")); // Init session data

// Output buffering
ob_start();
?>
<?php

// Write header
WriteHeader(FALSE);

// Create page object
$transhistory_list = new transhistory_list();

// Run the page
$transhistory_list->run();

// Setup login status
SetupLoginStatus();
SetClientVar("login", LoginStatus());

// Global Page Rendering event (in userfn*.php)
Page_Rendering();

// Page Rendering event
$transhistory_list->Page_Render();
?>
<?php include_once "header.php"; ?>
<?php if (!$transhistory_list->isExport()) { ?>
<script>
var ftranshistorylist, currentPageID;
loadjs.ready("head", function() {

	// Form object
	currentPageID = ew.PAGE_ID = "list";
	ftranshistorylist = currentForm = new ew.Form("ftranshistorylist", "list");
	ftranshistorylist.formKeyCountName = '<?php echo $transhistory_list->FormKeyCountName ?>';
	loadjs.done("ftranshistorylist");
});
var ftranshistorylistsrch;
loadjs.ready("head", function() {

	// Form object for search
	ftranshistorylistsrch = currentSearchForm = new ew.Form("ftranshistorylistsrch");

	// Dynamic selection lists
	// Filters

	ftranshistorylistsrch.filterList = <?php echo $transhistory_list->getFilterList() ?>;

	// Init search panel as collapsed
	ftranshistorylistsrch.initSearchPanel = true;
	loadjs.done("ftranshistorylistsrch");
});
</script>
<style type="text/css">
.ew-table-preview-row { /* main table preview row color */
	background-color: #FFFFFF; /* preview row color */
}
.ew-table-preview-row .ew-grid {
	display: table;
}
</style>
<div id="ew-preview" class="d-none"><!-- preview -->
	<div class="ew-nav-tabs"><!-- .ew-nav-tabs -->
		<ul class="nav nav-tabs"></ul>
		<div class="tab-content"><!-- .tab-content -->
			<div class="tab-pane fade active show"></div>
		</div><!-- /.tab-content -->
	</div><!-- /.ew-nav-tabs -->
</div><!-- /preview -->
<script>
loadjs.ready("head", function() {
	ew.PREVIEW_PLACEMENT = ew.CSS_FLIP ? "right" : "left";
	ew.PREVIEW_SINGLE_ROW = false;
	ew.PREVIEW_OVERLAY = false;
	loadjs("js/ewpreview.js", "preview");
});
</script>
<script>
loadjs.ready("head", function() {

	// Client script
	// Write your client script here, no need to add script tags.

});
</script>
<?php } ?>
<?php if (!$transhistory_list->isExport()) { ?>
<div class="btn-toolbar ew-toolbar">
<?php if ($transhistory_list->TotalRecords > 0 && $transhistory_list->ExportOptions->visible()) { ?>
<?php $transhistory_list->ExportOptions->render("body") ?>
<?php } ?>
<?php if ($transhistory_list->ImportOptions->visible()) { ?>
<?php $transhistory_list->ImportOptions->render("body") ?>
<?php } ?>
<?php if ($transhistory_list->SearchOptions->visible()) { ?>
<?php $transhistory_list->SearchOptions->render("body") ?>
<?php } ?>
<?php if ($transhistory_list->FilterOptions->visible()) { ?>
<?php $transhistory_list->FilterOptions->render("body") ?>
<?php } ?>
<div class="clearfix"></div>
</div>
<?php } ?>
<?php if (!$transhistory_list->isExport() || Config("EXPORT_MASTER_RECORD") && $transhistory_list->isExport("print")) { ?>
<?php
if ($transhistory_list->DbMasterFilter != "" && $transhistory->getCurrentMasterTable() == "transgroup") {
	if ($transhistory_list->MasterRecordExists) {
		include_once "transgroupmaster.php";
	}
}
?>
<?php } ?>
<?php
$transhistory_list->renderOtherOptions();
?>
<?php if ($Security->CanSearch()) { ?>
<?php if (!$transhistory_list->isExport() && !$transhistory->CurrentAction) { ?>
<form name="ftranshistorylistsrch" id="ftranshistorylistsrch" class="form-inline ew-form ew-ext-search-form" action="<?php echo CurrentPageName() ?>">
<div id="ftranshistorylistsrch-search-panel" class="<?php echo $transhistory_list->SearchPanelClass ?>">
<input type="hidden" name="cmd" value="search">
<input type="hidden" name="t" value="transhistory">
	<div class="ew-extended-search">
<div id="xsr_<?php echo $transhistory_list->SearchRowCount + 1 ?>" class="ew-row d-sm-flex">
	<div class="ew-quick-search input-group">
		<input type="text" name="<?php echo Config("TABLE_BASIC_SEARCH") ?>" id="<?php echo Config("TABLE_BASIC_SEARCH") ?>" class="form-control" value="<?php echo HtmlEncode($transhistory_list->BasicSearch->getKeyword()) ?>" placeholder="<?php echo HtmlEncode($Language->phrase("Search")) ?>">
		<input type="hidden" name="<?php echo Config("TABLE_BASIC_SEARCH_TYPE") ?>" id="<?php echo Config("TABLE_BASIC_SEARCH_TYPE") ?>" value="<?php echo HtmlEncode($transhistory_list->BasicSearch->getType()) ?>">
		<div class="input-group-append">
			<button class="btn btn-primary" name="btn-submit" id="btn-submit" type="submit"><?php echo $Language->phrase("SearchBtn") ?></button>
			<button type="button" data-toggle="dropdown" class="btn btn-primary dropdown-toggle dropdown-toggle-split" aria-haspopup="true" aria-expanded="false"><span id="searchtype"><?php echo $transhistory_list->BasicSearch->getTypeNameShort() ?></span></button>
			<div class="dropdown-menu dropdown-menu-right">
				<a class="dropdown-item<?php if ($transhistory_list->BasicSearch->getType() == "") { ?> active<?php } ?>" href="#" onclick="return ew.setSearchType(this);"><?php echo $Language->phrase("QuickSearchAuto") ?></a>
				<a class="dropdown-item<?php if ($transhistory_list->BasicSearch->getType() == "=") { ?> active<?php } ?>" href="#" onclick="return ew.setSearchType(this, '=');"><?php echo $Language->phrase("QuickSearchExact") ?></a>
				<a class="dropdown-item<?php if ($transhistory_list->BasicSearch->getType() == "AND") { ?> active<?php } ?>" href="#" onclick="return ew.setSearchType(this, 'AND');"><?php echo $Language->phrase("QuickSearchAll") ?></a>
				<a class="dropdown-item<?php if ($transhistory_list->BasicSearch->getType() == "OR") { ?> active<?php } ?>" href="#" onclick="return ew.setSearchType(this, 'OR');"><?php echo $Language->phrase("QuickSearchAny") ?></a>
			</div>
		</div>
	</div>
</div>
	</div><!-- /.ew-extended-search -->
</div><!-- /.ew-search-panel -->
</form>
<?php } ?>
<?php } ?>
<?php $transhistory_list->showPageHeader(); ?>
<?php
$transhistory_list->showMessage();
?>
<?php if ($transhistory_list->TotalRecords > 0 || $transhistory->CurrentAction) { ?>
<div class="card ew-card ew-grid<?php if ($transhistory_list->isAddOrEdit()) { ?> ew-grid-add-edit<?php } ?> transhistory">
<form name="ftranshistorylist" id="ftranshistorylist" class="form-inline ew-form ew-list-form" action="<?php echo CurrentPageName() ?>" method="post">
<?php if ($Page->CheckToken) { ?>
<input type="hidden" name="<?php echo Config("TOKEN_NAME") ?>" value="<?php echo $Page->Token ?>">
<?php } ?>
<input type="hidden" name="t" value="transhistory">
<?php if ($transhistory->getCurrentMasterTable() == "transgroup" && $transhistory->CurrentAction) { ?>
<input type="hidden" name="<?php echo Config("TABLE_SHOW_MASTER") ?>" value="transgroup">
<input type="hidden" name="fk_groupID" value="<?php echo HtmlEncode($transhistory_list->groupID->getSessionValue()) ?>">
<?php } ?>
<div id="gmp_transhistory" class="<?php echo ResponsiveTableClass() ?>card-body ew-grid-middle-panel">
<?php if ($transhistory_list->TotalRecords > 0 || $transhistory_list->isGridEdit()) { ?>
<table id="tbl_transhistorylist" class="table ew-table"><!-- .ew-table -->
<thead>
	<tr class="ew-table-header">
<?php

// Header row
$transhistory->RowType = ROWTYPE_HEADER;

// Render list options
$transhistory_list->renderListOptions();

// Render list options (header, left)
$transhistory_list->ListOptions->render("header", "left");
?>
<?php if ($transhistory_list->transID->Visible) { // transID ?>
	<?php if ($transhistory_list->SortUrl($transhistory_list->transID) == "") { ?>
		<th data-name="transID" class="<?php echo $transhistory_list->transID->headerCellClass() ?>"><div id="elh_transhistory_transID" class="transhistory_transID"><div class="ew-table-header-caption"><?php echo $transhistory_list->transID->caption() ?></div></div></th>
	<?php } else { ?>
		<th data-name="transID" class="<?php echo $transhistory_list->transID->headerCellClass() ?>"><div class="ew-pointer" onclick="ew.sort(event, '<?php echo $transhistory_list->SortUrl($transhistory_list->transID) ?>', 1);"><div id="elh_transhistory_transID" class="transhistory_transID">
			<div class="ew-table-header-btn"><span class="ew-table-header-caption"><?php echo $transhistory_list->transID->caption() ?></span><span class="ew-table-header-sort"><?php if ($transhistory_list->transID->getSort() == "ASC") { ?><i class="fas fa-sort-up"></i><?php } elseif ($transhistory_list->transID->getSort() == "DESC") { ?><i class="fas fa-sort-down"></i><?php } ?></span></div>
		</div></div></th>
	<?php } ?>
<?php } ?>
<?php if ($transhistory_list->groupID->Visible) { // groupID ?>
	<?php if ($transhistory_list->SortUrl($transhistory_list->groupID) == "") { ?>
		<th data-name="groupID" class="<?php echo $transhistory_list->groupID->headerCellClass() ?>"><div id="elh_transhistory_groupID" class="transhistory_groupID"><div class="ew-table-header-caption"><?php echo $transhistory_list->groupID->caption() ?></div></div></th>
	<?php } else { ?>
		<th data-name="groupID" class="<?php echo $transhistory_list->groupID->headerCellClass() ?>"><div class="ew-pointer" onclick="ew.sort(event, '<?php echo $transhistory_list->SortUrl($transhistory_list->groupID) ?>', 1);"><div id="elh_transhistory_groupID" class="transhistory_groupID">
			<div class="ew-table-header-btn"><span class="ew-table-header-caption"><?php echo $transhistory_list->groupID->caption() ?></span><span class="ew-table-header-sort"><?php if ($transhistory_list->groupID->getSort() == "ASC") { ?><i class="fas fa-sort-up"></i><?php } elseif ($transhistory_list->groupID->getSort() == "DESC") { ?><i class="fas fa-sort-down"></i><?php } ?></span></div>
		</div></div></th>
	<?php } ?>
<?php } ?>
<?php if ($transhistory_list->acctID->Visible) { // acctID ?>
	<?php if ($transhistory_list->SortUrl($transhistory_list->acctID) == "") { ?>
		<th data-name="acctID" class="<?php echo $transhistory_list->acctID->headerCellClass() ?>"><div id="elh_transhistory_acctID" class="transhistory_acctID"><div class="ew-table-header-caption"><?php echo $transhistory_list->acctID->caption() ?></div></div></th>
	<?php } else { ?>
		<th data-name="acctID" class="<?php echo $transhistory_list->acctID->headerCellClass() ?>"><div class="ew-pointer" onclick="ew.sort(event, '<?php echo $transhistory_list->SortUrl($transhistory_list->acctID) ?>', 1);"><div id="elh_transhistory_acctID" class="transhistory_acctID">
			<div class="ew-table-header-btn"><span class="ew-table-header-caption"><?php echo $transhistory_list->acctID->caption() ?></span><span class="ew-table-header-sort"><?php if ($transhistory_list->acctID->getSort() == "ASC") { ?><i class="fas fa-sort-up"></i><?php } elseif ($transhistory_list->acctID->getSort() == "DESC") { ?><i class="fas fa-sort-down"></i><?php } ?></span></div>
		</div></div></th>
	<?php } ?>
<?php } ?>
<?php if ($transhistory_list->currID->Visible) { // currID ?>
	<?php if ($transhistory_list->SortUrl($transhistory_list->currID) == "") { ?>
		<th data-name="currID" class="<?php echo $transhistory_list->currID->headerCellClass() ?>"><div id="elh_transhistory_currID" class="transhistory_currID"><div class="ew-table-header-caption"><?php echo $transhistory_list->currID->caption() ?></div></div></th>
	<?php } else { ?>
		<th data-name="currID" class="<?php echo $transhistory_list->currID->headerCellClass() ?>"><div class="ew-pointer" onclick="ew.sort(event, '<?php echo $transhistory_list->SortUrl($transhistory_list->currID) ?>', 1);"><div id="elh_transhistory_currID" class="transhistory_currID">
			<div class="ew-table-header-btn"><span class="ew-table-header-caption"><?php echo $transhistory_list->currID->caption() ?><?php echo $Language->phrase("SrchLegend") ?></span><span class="ew-table-header-sort"><?php if ($transhistory_list->currID->getSort() == "ASC") { ?><i class="fas fa-sort-up"></i><?php } elseif ($transhistory_list->currID->getSort() == "DESC") { ?><i class="fas fa-sort-down"></i><?php } ?></span></div>
		</div></div></th>
	<?php } ?>
<?php } ?>
<?php if ($transhistory_list->amount->Visible) { // amount ?>
	<?php if ($transhistory_list->SortUrl($transhistory_list->amount) == "") { ?>
		<th data-name="amount" class="<?php echo $transhistory_list->amount->headerCellClass() ?>"><div id="elh_transhistory_amount" class="transhistory_amount"><div class="ew-table-header-caption"><?php echo $transhistory_list->amount->caption() ?></div></div></th>
	<?php } else { ?>
		<th data-name="amount" class="<?php echo $transhistory_list->amount->headerCellClass() ?>"><div class="ew-pointer" onclick="ew.sort(event, '<?php echo $transhistory_list->SortUrl($transhistory_list->amount) ?>', 1);"><div id="elh_transhistory_amount" class="transhistory_amount">
			<div class="ew-table-header-btn"><span class="ew-table-header-caption"><?php echo $transhistory_list->amount->caption() ?></span><span class="ew-table-header-sort"><?php if ($transhistory_list->amount->getSort() == "ASC") { ?><i class="fas fa-sort-up"></i><?php } elseif ($transhistory_list->amount->getSort() == "DESC") { ?><i class="fas fa-sort-down"></i><?php } ?></span></div>
		</div></div></th>
	<?php } ?>
<?php } ?>
<?php if ($transhistory_list->transType->Visible) { // transType ?>
	<?php if ($transhistory_list->SortUrl($transhistory_list->transType) == "") { ?>
		<th data-name="transType" class="<?php echo $transhistory_list->transType->headerCellClass() ?>"><div id="elh_transhistory_transType" class="transhistory_transType"><div class="ew-table-header-caption"><?php echo $transhistory_list->transType->caption() ?></div></div></th>
	<?php } else { ?>
		<th data-name="transType" class="<?php echo $transhistory_list->transType->headerCellClass() ?>"><div class="ew-pointer" onclick="ew.sort(event, '<?php echo $transhistory_list->SortUrl($transhistory_list->transType) ?>', 1);"><div id="elh_transhistory_transType" class="transhistory_transType">
			<div class="ew-table-header-btn"><span class="ew-table-header-caption"><?php echo $transhistory_list->transType->caption() ?></span><span class="ew-table-header-sort"><?php if ($transhistory_list->transType->getSort() == "ASC") { ?><i class="fas fa-sort-up"></i><?php } elseif ($transhistory_list->transType->getSort() == "DESC") { ?><i class="fas fa-sort-down"></i><?php } ?></span></div>
		</div></div></th>
	<?php } ?>
<?php } ?>
<?php if ($transhistory_list->msg->Visible) { // msg ?>
	<?php if ($transhistory_list->SortUrl($transhistory_list->msg) == "") { ?>
		<th data-name="msg" class="<?php echo $transhistory_list->msg->headerCellClass() ?>"><div id="elh_transhistory_msg" class="transhistory_msg"><div class="ew-table-header-caption"><?php echo $transhistory_list->msg->caption() ?></div></div></th>
	<?php } else { ?>
		<th data-name="msg" class="<?php echo $transhistory_list->msg->headerCellClass() ?>"><div class="ew-pointer" onclick="ew.sort(event, '<?php echo $transhistory_list->SortUrl($transhistory_list->msg) ?>', 1);"><div id="elh_transhistory_msg" class="transhistory_msg">
			<div class="ew-table-header-btn"><span class="ew-table-header-caption"><?php echo $transhistory_list->msg->caption() ?><?php echo $Language->phrase("SrchLegend") ?></span><span class="ew-table-header-sort"><?php if ($transhistory_list->msg->getSort() == "ASC") { ?><i class="fas fa-sort-up"></i><?php } elseif ($transhistory_list->msg->getSort() == "DESC") { ?><i class="fas fa-sort-down"></i><?php } ?></span></div>
		</div></div></th>
	<?php } ?>
<?php } ?>
<?php if ($transhistory_list->balance->Visible) { // balance ?>
	<?php if ($transhistory_list->SortUrl($transhistory_list->balance) == "") { ?>
		<th data-name="balance" class="<?php echo $transhistory_list->balance->headerCellClass() ?>"><div id="elh_transhistory_balance" class="transhistory_balance"><div class="ew-table-header-caption"><?php echo $transhistory_list->balance->caption() ?></div></div></th>
	<?php } else { ?>
		<th data-name="balance" class="<?php echo $transhistory_list->balance->headerCellClass() ?>"><div class="ew-pointer" onclick="ew.sort(event, '<?php echo $transhistory_list->SortUrl($transhistory_list->balance) ?>', 1);"><div id="elh_transhistory_balance" class="transhistory_balance">
			<div class="ew-table-header-btn"><span class="ew-table-header-caption"><?php echo $transhistory_list->balance->caption() ?></span><span class="ew-table-header-sort"><?php if ($transhistory_list->balance->getSort() == "ASC") { ?><i class="fas fa-sort-up"></i><?php } elseif ($transhistory_list->balance->getSort() == "DESC") { ?><i class="fas fa-sort-down"></i><?php } ?></span></div>
		</div></div></th>
	<?php } ?>
<?php } ?>
<?php

// Render list options (header, right)
$transhistory_list->ListOptions->render("header", "right");
?>
	</tr>
</thead>
<tbody>
<?php
if ($transhistory_list->ExportAll && $transhistory_list->isExport()) {
	$transhistory_list->StopRecord = $transhistory_list->TotalRecords;
} else {

	// Set the last record to display
	if ($transhistory_list->TotalRecords > $transhistory_list->StartRecord + $transhistory_list->DisplayRecords - 1)
		$transhistory_list->StopRecord = $transhistory_list->StartRecord + $transhistory_list->DisplayRecords - 1;
	else
		$transhistory_list->StopRecord = $transhistory_list->TotalRecords;
}
$transhistory_list->RecordCount = $transhistory_list->StartRecord - 1;
if ($transhistory_list->Recordset && !$transhistory_list->Recordset->EOF) {
	$transhistory_list->Recordset->moveFirst();
	$selectLimit = $transhistory_list->UseSelectLimit;
	if (!$selectLimit && $transhistory_list->StartRecord > 1)
		$transhistory_list->Recordset->move($transhistory_list->StartRecord - 1);
} elseif (!$transhistory->AllowAddDeleteRow && $transhistory_list->StopRecord == 0) {
	$transhistory_list->StopRecord = $transhistory->GridAddRowCount;
}

// Initialize aggregate
$transhistory->RowType = ROWTYPE_AGGREGATEINIT;
$transhistory->resetAttributes();
$transhistory_list->renderRow();
while ($transhistory_list->RecordCount < $transhistory_list->StopRecord) {
	$transhistory_list->RecordCount++;
	if ($transhistory_list->RecordCount >= $transhistory_list->StartRecord) {
		$transhistory_list->RowCount++;

		// Set up key count
		$transhistory_list->KeyCount = $transhistory_list->RowIndex;

		// Init row class and style
		$transhistory->resetAttributes();
		$transhistory->CssClass = "";
		if ($transhistory_list->isGridAdd()) {
		} else {
			$transhistory_list->loadRowValues($transhistory_list->Recordset); // Load row values
		}
		$transhistory->RowType = ROWTYPE_VIEW; // Render view

		// Set up row id / data-rowindex
		$transhistory->RowAttrs->merge(["data-rowindex" => $transhistory_list->RowCount, "id" => "r" . $transhistory_list->RowCount . "_transhistory", "data-rowtype" => $transhistory->RowType]);

		// Render row
		$transhistory_list->renderRow();

		// Render list options
		$transhistory_list->renderListOptions();
?>
	<tr <?php echo $transhistory->rowAttributes() ?>>
<?php

// Render list options (body, left)
$transhistory_list->ListOptions->render("body", "left", $transhistory_list->RowCount);
?>
	<?php if ($transhistory_list->transID->Visible) { // transID ?>
		<td data-name="transID" <?php echo $transhistory_list->transID->cellAttributes() ?>>
<span id="el<?php echo $transhistory_list->RowCount ?>_transhistory_transID">
<span<?php echo $transhistory_list->transID->viewAttributes() ?>><?php echo $transhistory_list->transID->getViewValue() ?></span>
</span>
</td>
	<?php } ?>
	<?php if ($transhistory_list->groupID->Visible) { // groupID ?>
		<td data-name="groupID" <?php echo $transhistory_list->groupID->cellAttributes() ?>>
<span id="el<?php echo $transhistory_list->RowCount ?>_transhistory_groupID">
<span<?php echo $transhistory_list->groupID->viewAttributes() ?>><?php echo $transhistory_list->groupID->getViewValue() ?></span>
</span>
</td>
	<?php } ?>
	<?php if ($transhistory_list->acctID->Visible) { // acctID ?>
		<td data-name="acctID" <?php echo $transhistory_list->acctID->cellAttributes() ?>>
<span id="el<?php echo $transhistory_list->RowCount ?>_transhistory_acctID">
<span<?php echo $transhistory_list->acctID->viewAttributes() ?>><?php echo $transhistory_list->acctID->getViewValue() ?></span>
</span>
</td>
	<?php } ?>
	<?php if ($transhistory_list->currID->Visible) { // currID ?>
		<td data-name="currID" <?php echo $transhistory_list->currID->cellAttributes() ?>>
<span id="el<?php echo $transhistory_list->RowCount ?>_transhistory_currID">
<span<?php echo $transhistory_list->currID->viewAttributes() ?>><?php echo $transhistory_list->currID->getViewValue() ?></span>
</span>
</td>
	<?php } ?>
	<?php if ($transhistory_list->amount->Visible) { // amount ?>
		<td data-name="amount" <?php echo $transhistory_list->amount->cellAttributes() ?>>
<span id="el<?php echo $transhistory_list->RowCount ?>_transhistory_amount">
<span<?php echo $transhistory_list->amount->viewAttributes() ?>><?php echo $transhistory_list->amount->getViewValue() ?></span>
</span>
</td>
	<?php } ?>
	<?php if ($transhistory_list->transType->Visible) { // transType ?>
		<td data-name="transType" <?php echo $transhistory_list->transType->cellAttributes() ?>>
<span id="el<?php echo $transhistory_list->RowCount ?>_transhistory_transType">
<span<?php echo $transhistory_list->transType->viewAttributes() ?>><?php echo $transhistory_list->transType->getViewValue() ?></span>
</span>
</td>
	<?php } ?>
	<?php if ($transhistory_list->msg->Visible) { // msg ?>
		<td data-name="msg" <?php echo $transhistory_list->msg->cellAttributes() ?>>
<span id="el<?php echo $transhistory_list->RowCount ?>_transhistory_msg">
<span<?php echo $transhistory_list->msg->viewAttributes() ?>><?php echo $transhistory_list->msg->getViewValue() ?></span>
</span>
</td>
	<?php } ?>
	<?php if ($transhistory_list->balance->Visible) { // balance ?>
		<td data-name="balance" <?php echo $transhistory_list->balance->cellAttributes() ?>>
<span id="el<?php echo $transhistory_list->RowCount ?>_transhistory_balance">
<span<?php echo $transhistory_list->balance->viewAttributes() ?>><?php echo $transhistory_list->balance->getViewValue() ?></span>
</span>
</td>
	<?php } ?>
<?php

// Render list options (body, right)
$transhistory_list->ListOptions->render("body", "right", $transhistory_list->RowCount);
?>
	</tr>
<?php
	}
	if (!$transhistory_list->isGridAdd())
		$transhistory_list->Recordset->moveNext();
}
?>
</tbody>
</table><!-- /.ew-table -->
<?php } ?>
</div><!-- /.ew-grid-middle-panel -->
<?php if (!$transhistory->CurrentAction) { ?>
<input type="hidden" name="action" id="action" value="">
<?php } ?>
</form><!-- /.ew-list-form -->
<?php

// Close recordset
if ($transhistory_list->Recordset)
	$transhistory_list->Recordset->Close();
?>
<?php if (!$transhistory_list->isExport()) { ?>
<div class="card-footer ew-grid-lower-panel">
<?php if (!$transhistory_list->isGridAdd()) { ?>
<form name="ew-pager-form" class="form-inline ew-form ew-pager-form" action="<?php echo CurrentPageName() ?>">
<?php echo $transhistory_list->Pager->render() ?>
</form>
<?php } ?>
<div class="ew-list-other-options">
<?php $transhistory_list->OtherOptions->render("body", "bottom") ?>
</div>
<div class="clearfix"></div>
</div>
<?php } ?>
</div><!-- /.ew-grid -->
<?php } ?>
<?php if ($transhistory_list->TotalRecords == 0 && !$transhistory->CurrentAction) { // Show other options ?>
<div class="ew-list-other-options">
<?php $transhistory_list->OtherOptions->render("body") ?>
</div>
<div class="clearfix"></div>
<?php } ?>
<?php
$transhistory_list->showPageFooter();
if (Config("DEBUG"))
	echo GetDebugMessage();
?>
<?php if (!$transhistory_list->isExport()) { ?>
<script>
loadjs.ready("load", function() {

	// Startup script
	// Write your table-specific startup script here
	// console.log("page loaded");

});
</script>
<?php } ?>
<?php include_once "footer.php"; ?>
<?php
$transhistory_list->terminate();
?>