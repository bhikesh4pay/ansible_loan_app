<?php
namespace PHPMaker2020\_4payadmin;

// Autoload
include_once "autoload.php";

// Session
if (session_status() !== PHP_SESSION_ACTIVE)
	\Delight\Cookie\Session::start(Config("COOKIE_SAMESITE")); // Init session data

// Output buffering
ob_start();
?>
<?php

// Write header
WriteHeader(FALSE);

// Create page object
$usersentiment_list = new usersentiment_list();

// Run the page
$usersentiment_list->run();

// Setup login status
SetupLoginStatus();
SetClientVar("login", LoginStatus());

// Global Page Rendering event (in userfn*.php)
Page_Rendering();

// Page Rendering event
$usersentiment_list->Page_Render();
?>
<?php include_once "header.php"; ?>
<?php if (!$usersentiment_list->isExport()) { ?>
<script>
var fusersentimentlist, currentPageID;
loadjs.ready("head", function() {

	// Form object
	currentPageID = ew.PAGE_ID = "list";
	fusersentimentlist = currentForm = new ew.Form("fusersentimentlist", "list");
	fusersentimentlist.formKeyCountName = '<?php echo $usersentiment_list->FormKeyCountName ?>';
	loadjs.done("fusersentimentlist");
});
</script>
<style type="text/css">
.ew-table-preview-row { /* main table preview row color */
	background-color: #FFFFFF; /* preview row color */
}
.ew-table-preview-row .ew-grid {
	display: table;
}
</style>
<div id="ew-preview" class="d-none"><!-- preview -->
	<div class="ew-nav-tabs"><!-- .ew-nav-tabs -->
		<ul class="nav nav-tabs"></ul>
		<div class="tab-content"><!-- .tab-content -->
			<div class="tab-pane fade active show"></div>
		</div><!-- /.tab-content -->
	</div><!-- /.ew-nav-tabs -->
</div><!-- /preview -->
<script>
loadjs.ready("head", function() {
	ew.PREVIEW_PLACEMENT = ew.CSS_FLIP ? "right" : "left";
	ew.PREVIEW_SINGLE_ROW = false;
	ew.PREVIEW_OVERLAY = false;
	loadjs("js/ewpreview.js", "preview");
});
</script>
<script>
loadjs.ready("head", function() {

	// Client script
	// Write your client script here, no need to add script tags.

});
</script>
<?php } ?>
<?php if (!$usersentiment_list->isExport()) { ?>
<div class="btn-toolbar ew-toolbar">
<?php if ($usersentiment_list->TotalRecords > 0 && $usersentiment_list->ExportOptions->visible()) { ?>
<?php $usersentiment_list->ExportOptions->render("body") ?>
<?php } ?>
<?php if ($usersentiment_list->ImportOptions->visible()) { ?>
<?php $usersentiment_list->ImportOptions->render("body") ?>
<?php } ?>
<div class="clearfix"></div>
</div>
<?php } ?>
<?php
$usersentiment_list->renderOtherOptions();
?>
<?php $usersentiment_list->showPageHeader(); ?>
<?php
$usersentiment_list->showMessage();
?>
<?php if ($usersentiment_list->TotalRecords > 0 || $usersentiment->CurrentAction) { ?>
<div class="card ew-card ew-grid<?php if ($usersentiment_list->isAddOrEdit()) { ?> ew-grid-add-edit<?php } ?> usersentiment">
<form name="fusersentimentlist" id="fusersentimentlist" class="form-inline ew-form ew-list-form" action="<?php echo CurrentPageName() ?>" method="post">
<?php if ($Page->CheckToken) { ?>
<input type="hidden" name="<?php echo Config("TOKEN_NAME") ?>" value="<?php echo $Page->Token ?>">
<?php } ?>
<input type="hidden" name="t" value="usersentiment">
<div id="gmp_usersentiment" class="<?php echo ResponsiveTableClass() ?>card-body ew-grid-middle-panel">
<?php if ($usersentiment_list->TotalRecords > 0 || $usersentiment_list->isGridEdit()) { ?>
<table id="tbl_usersentimentlist" class="table ew-table"><!-- .ew-table -->
<thead>
	<tr class="ew-table-header">
<?php

// Header row
$usersentiment->RowType = ROWTYPE_HEADER;

// Render list options
$usersentiment_list->renderListOptions();

// Render list options (header, left)
$usersentiment_list->ListOptions->render("header", "left");
?>
<?php if ($usersentiment_list->recid->Visible) { // recid ?>
	<?php if ($usersentiment_list->SortUrl($usersentiment_list->recid) == "") { ?>
		<th data-name="recid" class="<?php echo $usersentiment_list->recid->headerCellClass() ?>"><div id="elh_usersentiment_recid" class="usersentiment_recid"><div class="ew-table-header-caption"><?php echo $usersentiment_list->recid->caption() ?></div></div></th>
	<?php } else { ?>
		<th data-name="recid" class="<?php echo $usersentiment_list->recid->headerCellClass() ?>"><div class="ew-pointer" onclick="ew.sort(event, '<?php echo $usersentiment_list->SortUrl($usersentiment_list->recid) ?>', 1);"><div id="elh_usersentiment_recid" class="usersentiment_recid">
			<div class="ew-table-header-btn"><span class="ew-table-header-caption"><?php echo $usersentiment_list->recid->caption() ?></span><span class="ew-table-header-sort"><?php if ($usersentiment_list->recid->getSort() == "ASC") { ?><i class="fas fa-sort-up"></i><?php } elseif ($usersentiment_list->recid->getSort() == "DESC") { ?><i class="fas fa-sort-down"></i><?php } ?></span></div>
		</div></div></th>
	<?php } ?>
<?php } ?>
<?php if ($usersentiment_list->_userid->Visible) { // userid ?>
	<?php if ($usersentiment_list->SortUrl($usersentiment_list->_userid) == "") { ?>
		<th data-name="_userid" class="<?php echo $usersentiment_list->_userid->headerCellClass() ?>"><div id="elh_usersentiment__userid" class="usersentiment__userid"><div class="ew-table-header-caption"><?php echo $usersentiment_list->_userid->caption() ?></div></div></th>
	<?php } else { ?>
		<th data-name="_userid" class="<?php echo $usersentiment_list->_userid->headerCellClass() ?>"><div class="ew-pointer" onclick="ew.sort(event, '<?php echo $usersentiment_list->SortUrl($usersentiment_list->_userid) ?>', 1);"><div id="elh_usersentiment__userid" class="usersentiment__userid">
			<div class="ew-table-header-btn"><span class="ew-table-header-caption"><?php echo $usersentiment_list->_userid->caption() ?></span><span class="ew-table-header-sort"><?php if ($usersentiment_list->_userid->getSort() == "ASC") { ?><i class="fas fa-sort-up"></i><?php } elseif ($usersentiment_list->_userid->getSort() == "DESC") { ?><i class="fas fa-sort-down"></i><?php } ?></span></div>
		</div></div></th>
	<?php } ?>
<?php } ?>
<?php if ($usersentiment_list->sentimenttype->Visible) { // sentimenttype ?>
	<?php if ($usersentiment_list->SortUrl($usersentiment_list->sentimenttype) == "") { ?>
		<th data-name="sentimenttype" class="<?php echo $usersentiment_list->sentimenttype->headerCellClass() ?>"><div id="elh_usersentiment_sentimenttype" class="usersentiment_sentimenttype"><div class="ew-table-header-caption"><?php echo $usersentiment_list->sentimenttype->caption() ?></div></div></th>
	<?php } else { ?>
		<th data-name="sentimenttype" class="<?php echo $usersentiment_list->sentimenttype->headerCellClass() ?>"><div class="ew-pointer" onclick="ew.sort(event, '<?php echo $usersentiment_list->SortUrl($usersentiment_list->sentimenttype) ?>', 1);"><div id="elh_usersentiment_sentimenttype" class="usersentiment_sentimenttype">
			<div class="ew-table-header-btn"><span class="ew-table-header-caption"><?php echo $usersentiment_list->sentimenttype->caption() ?></span><span class="ew-table-header-sort"><?php if ($usersentiment_list->sentimenttype->getSort() == "ASC") { ?><i class="fas fa-sort-up"></i><?php } elseif ($usersentiment_list->sentimenttype->getSort() == "DESC") { ?><i class="fas fa-sort-down"></i><?php } ?></span></div>
		</div></div></th>
	<?php } ?>
<?php } ?>
<?php if ($usersentiment_list->creationtime->Visible) { // creationtime ?>
	<?php if ($usersentiment_list->SortUrl($usersentiment_list->creationtime) == "") { ?>
		<th data-name="creationtime" class="<?php echo $usersentiment_list->creationtime->headerCellClass() ?>"><div id="elh_usersentiment_creationtime" class="usersentiment_creationtime"><div class="ew-table-header-caption"><?php echo $usersentiment_list->creationtime->caption() ?></div></div></th>
	<?php } else { ?>
		<th data-name="creationtime" class="<?php echo $usersentiment_list->creationtime->headerCellClass() ?>"><div class="ew-pointer" onclick="ew.sort(event, '<?php echo $usersentiment_list->SortUrl($usersentiment_list->creationtime) ?>', 1);"><div id="elh_usersentiment_creationtime" class="usersentiment_creationtime">
			<div class="ew-table-header-btn"><span class="ew-table-header-caption"><?php echo $usersentiment_list->creationtime->caption() ?></span><span class="ew-table-header-sort"><?php if ($usersentiment_list->creationtime->getSort() == "ASC") { ?><i class="fas fa-sort-up"></i><?php } elseif ($usersentiment_list->creationtime->getSort() == "DESC") { ?><i class="fas fa-sort-down"></i><?php } ?></span></div>
		</div></div></th>
	<?php } ?>
<?php } ?>
<?php if ($usersentiment_list->surveyquestionid->Visible) { // surveyquestionid ?>
	<?php if ($usersentiment_list->SortUrl($usersentiment_list->surveyquestionid) == "") { ?>
		<th data-name="surveyquestionid" class="<?php echo $usersentiment_list->surveyquestionid->headerCellClass() ?>"><div id="elh_usersentiment_surveyquestionid" class="usersentiment_surveyquestionid"><div class="ew-table-header-caption"><?php echo $usersentiment_list->surveyquestionid->caption() ?></div></div></th>
	<?php } else { ?>
		<th data-name="surveyquestionid" class="<?php echo $usersentiment_list->surveyquestionid->headerCellClass() ?>"><div class="ew-pointer" onclick="ew.sort(event, '<?php echo $usersentiment_list->SortUrl($usersentiment_list->surveyquestionid) ?>', 1);"><div id="elh_usersentiment_surveyquestionid" class="usersentiment_surveyquestionid">
			<div class="ew-table-header-btn"><span class="ew-table-header-caption"><?php echo $usersentiment_list->surveyquestionid->caption() ?></span><span class="ew-table-header-sort"><?php if ($usersentiment_list->surveyquestionid->getSort() == "ASC") { ?><i class="fas fa-sort-up"></i><?php } elseif ($usersentiment_list->surveyquestionid->getSort() == "DESC") { ?><i class="fas fa-sort-down"></i><?php } ?></span></div>
		</div></div></th>
	<?php } ?>
<?php } ?>
<?php

// Render list options (header, right)
$usersentiment_list->ListOptions->render("header", "right");
?>
	</tr>
</thead>
<tbody>
<?php
if ($usersentiment_list->ExportAll && $usersentiment_list->isExport()) {
	$usersentiment_list->StopRecord = $usersentiment_list->TotalRecords;
} else {

	// Set the last record to display
	if ($usersentiment_list->TotalRecords > $usersentiment_list->StartRecord + $usersentiment_list->DisplayRecords - 1)
		$usersentiment_list->StopRecord = $usersentiment_list->StartRecord + $usersentiment_list->DisplayRecords - 1;
	else
		$usersentiment_list->StopRecord = $usersentiment_list->TotalRecords;
}
$usersentiment_list->RecordCount = $usersentiment_list->StartRecord - 1;
if ($usersentiment_list->Recordset && !$usersentiment_list->Recordset->EOF) {
	$usersentiment_list->Recordset->moveFirst();
	$selectLimit = $usersentiment_list->UseSelectLimit;
	if (!$selectLimit && $usersentiment_list->StartRecord > 1)
		$usersentiment_list->Recordset->move($usersentiment_list->StartRecord - 1);
} elseif (!$usersentiment->AllowAddDeleteRow && $usersentiment_list->StopRecord == 0) {
	$usersentiment_list->StopRecord = $usersentiment->GridAddRowCount;
}

// Initialize aggregate
$usersentiment->RowType = ROWTYPE_AGGREGATEINIT;
$usersentiment->resetAttributes();
$usersentiment_list->renderRow();
while ($usersentiment_list->RecordCount < $usersentiment_list->StopRecord) {
	$usersentiment_list->RecordCount++;
	if ($usersentiment_list->RecordCount >= $usersentiment_list->StartRecord) {
		$usersentiment_list->RowCount++;

		// Set up key count
		$usersentiment_list->KeyCount = $usersentiment_list->RowIndex;

		// Init row class and style
		$usersentiment->resetAttributes();
		$usersentiment->CssClass = "";
		if ($usersentiment_list->isGridAdd()) {
		} else {
			$usersentiment_list->loadRowValues($usersentiment_list->Recordset); // Load row values
		}
		$usersentiment->RowType = ROWTYPE_VIEW; // Render view

		// Set up row id / data-rowindex
		$usersentiment->RowAttrs->merge(["data-rowindex" => $usersentiment_list->RowCount, "id" => "r" . $usersentiment_list->RowCount . "_usersentiment", "data-rowtype" => $usersentiment->RowType]);

		// Render row
		$usersentiment_list->renderRow();

		// Render list options
		$usersentiment_list->renderListOptions();
?>
	<tr <?php echo $usersentiment->rowAttributes() ?>>
<?php

// Render list options (body, left)
$usersentiment_list->ListOptions->render("body", "left", $usersentiment_list->RowCount);
?>
	<?php if ($usersentiment_list->recid->Visible) { // recid ?>
		<td data-name="recid" <?php echo $usersentiment_list->recid->cellAttributes() ?>>
<span id="el<?php echo $usersentiment_list->RowCount ?>_usersentiment_recid">
<span<?php echo $usersentiment_list->recid->viewAttributes() ?>><?php echo $usersentiment_list->recid->getViewValue() ?></span>
</span>
</td>
	<?php } ?>
	<?php if ($usersentiment_list->_userid->Visible) { // userid ?>
		<td data-name="_userid" <?php echo $usersentiment_list->_userid->cellAttributes() ?>>
<span id="el<?php echo $usersentiment_list->RowCount ?>_usersentiment__userid">
<span<?php echo $usersentiment_list->_userid->viewAttributes() ?>><?php echo $usersentiment_list->_userid->getViewValue() ?></span>
</span>
</td>
	<?php } ?>
	<?php if ($usersentiment_list->sentimenttype->Visible) { // sentimenttype ?>
		<td data-name="sentimenttype" <?php echo $usersentiment_list->sentimenttype->cellAttributes() ?>>
<span id="el<?php echo $usersentiment_list->RowCount ?>_usersentiment_sentimenttype">
<span<?php echo $usersentiment_list->sentimenttype->viewAttributes() ?>><?php echo $usersentiment_list->sentimenttype->getViewValue() ?></span>
</span>
</td>
	<?php } ?>
	<?php if ($usersentiment_list->creationtime->Visible) { // creationtime ?>
		<td data-name="creationtime" <?php echo $usersentiment_list->creationtime->cellAttributes() ?>>
<span id="el<?php echo $usersentiment_list->RowCount ?>_usersentiment_creationtime">
<span<?php echo $usersentiment_list->creationtime->viewAttributes() ?>><?php echo $usersentiment_list->creationtime->getViewValue() ?></span>
</span>
</td>
	<?php } ?>
	<?php if ($usersentiment_list->surveyquestionid->Visible) { // surveyquestionid ?>
		<td data-name="surveyquestionid" <?php echo $usersentiment_list->surveyquestionid->cellAttributes() ?>>
<span id="el<?php echo $usersentiment_list->RowCount ?>_usersentiment_surveyquestionid">
<span<?php echo $usersentiment_list->surveyquestionid->viewAttributes() ?>><?php echo $usersentiment_list->surveyquestionid->getViewValue() ?></span>
</span>
</td>
	<?php } ?>
<?php

// Render list options (body, right)
$usersentiment_list->ListOptions->render("body", "right", $usersentiment_list->RowCount);
?>
	</tr>
<?php
	}
	if (!$usersentiment_list->isGridAdd())
		$usersentiment_list->Recordset->moveNext();
}
?>
</tbody>
</table><!-- /.ew-table -->
<?php } ?>
</div><!-- /.ew-grid-middle-panel -->
<?php if (!$usersentiment->CurrentAction) { ?>
<input type="hidden" name="action" id="action" value="">
<?php } ?>
</form><!-- /.ew-list-form -->
<?php

// Close recordset
if ($usersentiment_list->Recordset)
	$usersentiment_list->Recordset->Close();
?>
<?php if (!$usersentiment_list->isExport()) { ?>
<div class="card-footer ew-grid-lower-panel">
<?php if (!$usersentiment_list->isGridAdd()) { ?>
<form name="ew-pager-form" class="form-inline ew-form ew-pager-form" action="<?php echo CurrentPageName() ?>">
<?php echo $usersentiment_list->Pager->render() ?>
</form>
<?php } ?>
<div class="ew-list-other-options">
<?php $usersentiment_list->OtherOptions->render("body", "bottom") ?>
</div>
<div class="clearfix"></div>
</div>
<?php } ?>
</div><!-- /.ew-grid -->
<?php } ?>
<?php if ($usersentiment_list->TotalRecords == 0 && !$usersentiment->CurrentAction) { // Show other options ?>
<div class="ew-list-other-options">
<?php $usersentiment_list->OtherOptions->render("body") ?>
</div>
<div class="clearfix"></div>
<?php } ?>
<?php
$usersentiment_list->showPageFooter();
if (Config("DEBUG"))
	echo GetDebugMessage();
?>
<?php if (!$usersentiment_list->isExport()) { ?>
<script>
loadjs.ready("load", function() {

	// Startup script
	// Write your table-specific startup script here
	// console.log("page loaded");

});
</script>
<?php } ?>
<?php include_once "footer.php"; ?>
<?php
$usersentiment_list->terminate();
?>