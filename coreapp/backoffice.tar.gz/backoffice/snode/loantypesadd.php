<?php
namespace PHPMaker2020\_4payadmin;

// Autoload
include_once "autoload.php";

// Session
if (session_status() !== PHP_SESSION_ACTIVE)
	\Delight\Cookie\Session::start(Config("COOKIE_SAMESITE")); // Init session data

// Output buffering
ob_start();
?>
<?php

// Write header
WriteHeader(FALSE);

// Create page object
$loantypes_add = new loantypes_add();

// Run the page
$loantypes_add->run();

// Setup login status
SetupLoginStatus();
SetClientVar("login", LoginStatus());

// Global Page Rendering event (in userfn*.php)
Page_Rendering();

// Page Rendering event
$loantypes_add->Page_Render();
?>
<?php include_once "header.php"; ?>
<script>
var floantypesadd, currentPageID;
loadjs.ready("head", function() {

	// Form object
	currentPageID = ew.PAGE_ID = "add";
	floantypesadd = currentForm = new ew.Form("floantypesadd", "add");

	// Validate form
	floantypesadd.validate = function() {
		if (!this.validateRequired)
			return true; // Ignore validation
		var $ = jQuery, fobj = this.getForm(), $fobj = $(fobj);
		if ($fobj.find("#confirm").val() == "confirm")
			return true;
		var elm, felm, uelm, addcnt = 0;
		var $k = $fobj.find("#" + this.formKeyCountName); // Get key_count
		var rowcnt = ($k[0]) ? parseInt($k.val(), 10) : 1;
		var startcnt = (rowcnt == 0) ? 0 : 1; // Check rowcnt == 0 => Inline-Add
		var gridinsert = ["insert", "gridinsert"].includes($fobj.find("#action").val()) && $k[0];
		for (var i = startcnt; i <= rowcnt; i++) {
			var infix = ($k[0]) ? String(i) : "";
			$fobj.data("rowindex", infix);
			<?php if ($loantypes_add->loantype->Required) { ?>
				elm = this.getElements("x" + infix + "_loantype");
				if (elm && !ew.isHidden(elm) && !ew.hasValue(elm))
					return this.onError(elm, "<?php echo JsEncode(str_replace("%s", $loantypes_add->loantype->caption(), $loantypes_add->loantype->RequiredErrorMessage)) ?>");
			<?php } ?>
				elm = this.getElements("x" + infix + "_loantype");
				if (elm && !ew.checkInteger(elm.value))
					return this.onError(elm, "<?php echo JsEncode($loantypes_add->loantype->errorMessage()) ?>");
			<?php if ($loantypes_add->loandesc->Required) { ?>
				elm = this.getElements("x" + infix + "_loandesc");
				if (elm && !ew.isHidden(elm) && !ew.hasValue(elm))
					return this.onError(elm, "<?php echo JsEncode(str_replace("%s", $loantypes_add->loandesc->caption(), $loantypes_add->loandesc->RequiredErrorMessage)) ?>");
			<?php } ?>
			<?php if ($loantypes_add->feeperc->Required) { ?>
				elm = this.getElements("x" + infix + "_feeperc");
				if (elm && !ew.isHidden(elm) && !ew.hasValue(elm))
					return this.onError(elm, "<?php echo JsEncode(str_replace("%s", $loantypes_add->feeperc->caption(), $loantypes_add->feeperc->RequiredErrorMessage)) ?>");
			<?php } ?>
				elm = this.getElements("x" + infix + "_feeperc");
				if (elm && !ew.checkNumber(elm.value))
					return this.onError(elm, "<?php echo JsEncode($loantypes_add->feeperc->errorMessage()) ?>");
			<?php if ($loantypes_add->feefixed->Required) { ?>
				elm = this.getElements("x" + infix + "_feefixed");
				if (elm && !ew.isHidden(elm) && !ew.hasValue(elm))
					return this.onError(elm, "<?php echo JsEncode(str_replace("%s", $loantypes_add->feefixed->caption(), $loantypes_add->feefixed->RequiredErrorMessage)) ?>");
			<?php } ?>
				elm = this.getElements("x" + infix + "_feefixed");
				if (elm && !ew.checkNumber(elm.value))
					return this.onError(elm, "<?php echo JsEncode($loantypes_add->feefixed->errorMessage()) ?>");
			<?php if ($loantypes_add->feetax->Required) { ?>
				elm = this.getElements("x" + infix + "_feetax");
				if (elm && !ew.isHidden(elm) && !ew.hasValue(elm))
					return this.onError(elm, "<?php echo JsEncode(str_replace("%s", $loantypes_add->feetax->caption(), $loantypes_add->feetax->RequiredErrorMessage)) ?>");
			<?php } ?>
				elm = this.getElements("x" + infix + "_feetax");
				if (elm && !ew.checkNumber(elm.value))
					return this.onError(elm, "<?php echo JsEncode($loantypes_add->feetax->errorMessage()) ?>");
			<?php if ($loantypes_add->purchasetableid->Required) { ?>
				elm = this.getElements("x" + infix + "_purchasetableid");
				if (elm && !ew.isHidden(elm) && !ew.hasValue(elm))
					return this.onError(elm, "<?php echo JsEncode(str_replace("%s", $loantypes_add->purchasetableid->caption(), $loantypes_add->purchasetableid->RequiredErrorMessage)) ?>");
			<?php } ?>
				elm = this.getElements("x" + infix + "_purchasetableid");
				if (elm && !ew.checkInteger(elm.value))
					return this.onError(elm, "<?php echo JsEncode($loantypes_add->purchasetableid->errorMessage()) ?>");
			<?php if ($loantypes_add->numberofdays->Required) { ?>
				elm = this.getElements("x" + infix + "_numberofdays");
				if (elm && !ew.isHidden(elm) && !ew.hasValue(elm))
					return this.onError(elm, "<?php echo JsEncode(str_replace("%s", $loantypes_add->numberofdays->caption(), $loantypes_add->numberofdays->RequiredErrorMessage)) ?>");
			<?php } ?>
				elm = this.getElements("x" + infix + "_numberofdays");
				if (elm && !ew.checkInteger(elm.value))
					return this.onError(elm, "<?php echo JsEncode($loantypes_add->numberofdays->errorMessage()) ?>");
			<?php if ($loantypes_add->nextloantype->Required) { ?>
				elm = this.getElements("x" + infix + "_nextloantype");
				if (elm && !ew.isHidden(elm) && !ew.hasValue(elm))
					return this.onError(elm, "<?php echo JsEncode(str_replace("%s", $loantypes_add->nextloantype->caption(), $loantypes_add->nextloantype->RequiredErrorMessage)) ?>");
			<?php } ?>
				elm = this.getElements("x" + infix + "_nextloantype");
				if (elm && !ew.checkInteger(elm.value))
					return this.onError(elm, "<?php echo JsEncode($loantypes_add->nextloantype->errorMessage()) ?>");
			<?php if ($loantypes_add->latefeetableid->Required) { ?>
				elm = this.getElements("x" + infix + "_latefeetableid");
				if (elm && !ew.isHidden(elm) && !ew.hasValue(elm))
					return this.onError(elm, "<?php echo JsEncode(str_replace("%s", $loantypes_add->latefeetableid->caption(), $loantypes_add->latefeetableid->RequiredErrorMessage)) ?>");
			<?php } ?>
				elm = this.getElements("x" + infix + "_latefeetableid");
				if (elm && !ew.checkInteger(elm.value))
					return this.onError(elm, "<?php echo JsEncode($loantypes_add->latefeetableid->errorMessage()) ?>");
			<?php if ($loantypes_add->stopcalculatingafterdays->Required) { ?>
				elm = this.getElements("x" + infix + "_stopcalculatingafterdays");
				if (elm && !ew.isHidden(elm) && !ew.hasValue(elm))
					return this.onError(elm, "<?php echo JsEncode(str_replace("%s", $loantypes_add->stopcalculatingafterdays->caption(), $loantypes_add->stopcalculatingafterdays->RequiredErrorMessage)) ?>");
			<?php } ?>
				elm = this.getElements("x" + infix + "_stopcalculatingafterdays");
				if (elm && !ew.checkInteger(elm.value))
					return this.onError(elm, "<?php echo JsEncode($loantypes_add->stopcalculatingafterdays->errorMessage()) ?>");
			<?php if ($loantypes_add->graceperioddays->Required) { ?>
				elm = this.getElements("x" + infix + "_graceperioddays");
				if (elm && !ew.isHidden(elm) && !ew.hasValue(elm))
					return this.onError(elm, "<?php echo JsEncode(str_replace("%s", $loantypes_add->graceperioddays->caption(), $loantypes_add->graceperioddays->RequiredErrorMessage)) ?>");
			<?php } ?>
				elm = this.getElements("x" + infix + "_graceperioddays");
				if (elm && !ew.checkInteger(elm.value))
					return this.onError(elm, "<?php echo JsEncode($loantypes_add->graceperioddays->errorMessage()) ?>");
			<?php if ($loantypes_add->feecalculationmode->Required) { ?>
				elm = this.getElements("x" + infix + "_feecalculationmode");
				if (elm && !ew.isHidden(elm) && !ew.hasValue(elm))
					return this.onError(elm, "<?php echo JsEncode(str_replace("%s", $loantypes_add->feecalculationmode->caption(), $loantypes_add->feecalculationmode->RequiredErrorMessage)) ?>");
			<?php } ?>
				elm = this.getElements("x" + infix + "_feecalculationmode");
				if (elm && !ew.checkInteger(elm.value))
					return this.onError(elm, "<?php echo JsEncode($loantypes_add->feecalculationmode->errorMessage()) ?>");
			<?php if ($loantypes_add->latefeewarninglangid->Required) { ?>
				elm = this.getElements("x" + infix + "_latefeewarninglangid");
				if (elm && !ew.isHidden(elm) && !ew.hasValue(elm))
					return this.onError(elm, "<?php echo JsEncode(str_replace("%s", $loantypes_add->latefeewarninglangid->caption(), $loantypes_add->latefeewarninglangid->RequiredErrorMessage)) ?>");
			<?php } ?>
				elm = this.getElements("x" + infix + "_latefeewarninglangid");
				if (elm && !ew.checkInteger(elm.value))
					return this.onError(elm, "<?php echo JsEncode($loantypes_add->latefeewarninglangid->errorMessage()) ?>");
			<?php if ($loantypes_add->latefeelangid->Required) { ?>
				elm = this.getElements("x" + infix + "_latefeelangid");
				if (elm && !ew.isHidden(elm) && !ew.hasValue(elm))
					return this.onError(elm, "<?php echo JsEncode(str_replace("%s", $loantypes_add->latefeelangid->caption(), $loantypes_add->latefeelangid->RequiredErrorMessage)) ?>");
			<?php } ?>
				elm = this.getElements("x" + infix + "_latefeelangid");
				if (elm && !ew.checkInteger(elm.value))
					return this.onError(elm, "<?php echo JsEncode($loantypes_add->latefeelangid->errorMessage()) ?>");
			<?php if ($loantypes_add->flaggedlangid->Required) { ?>
				elm = this.getElements("x" + infix + "_flaggedlangid");
				if (elm && !ew.isHidden(elm) && !ew.hasValue(elm))
					return this.onError(elm, "<?php echo JsEncode(str_replace("%s", $loantypes_add->flaggedlangid->caption(), $loantypes_add->flaggedlangid->RequiredErrorMessage)) ?>");
			<?php } ?>
				elm = this.getElements("x" + infix + "_flaggedlangid");
				if (elm && !ew.checkInteger(elm.value))
					return this.onError(elm, "<?php echo JsEncode($loantypes_add->flaggedlangid->errorMessage()) ?>");
			<?php if ($loantypes_add->unblocklangid->Required) { ?>
				elm = this.getElements("x" + infix + "_unblocklangid");
				if (elm && !ew.isHidden(elm) && !ew.hasValue(elm))
					return this.onError(elm, "<?php echo JsEncode(str_replace("%s", $loantypes_add->unblocklangid->caption(), $loantypes_add->unblocklangid->RequiredErrorMessage)) ?>");
			<?php } ?>
				elm = this.getElements("x" + infix + "_unblocklangid");
				if (elm && !ew.checkInteger(elm.value))
					return this.onError(elm, "<?php echo JsEncode($loantypes_add->unblocklangid->errorMessage()) ?>");
			<?php if ($loantypes_add->blockedlangid->Required) { ?>
				elm = this.getElements("x" + infix + "_blockedlangid");
				if (elm && !ew.isHidden(elm) && !ew.hasValue(elm))
					return this.onError(elm, "<?php echo JsEncode(str_replace("%s", $loantypes_add->blockedlangid->caption(), $loantypes_add->blockedlangid->RequiredErrorMessage)) ?>");
			<?php } ?>
				elm = this.getElements("x" + infix + "_blockedlangid");
				if (elm && !ew.checkInteger(elm.value))
					return this.onError(elm, "<?php echo JsEncode($loantypes_add->blockedlangid->errorMessage()) ?>");
			<?php if ($loantypes_add->nexttierwarninglangid->Required) { ?>
				elm = this.getElements("x" + infix + "_nexttierwarninglangid");
				if (elm && !ew.isHidden(elm) && !ew.hasValue(elm))
					return this.onError(elm, "<?php echo JsEncode(str_replace("%s", $loantypes_add->nexttierwarninglangid->caption(), $loantypes_add->nexttierwarninglangid->RequiredErrorMessage)) ?>");
			<?php } ?>
				elm = this.getElements("x" + infix + "_nexttierwarninglangid");
				if (elm && !ew.checkInteger(elm.value))
					return this.onError(elm, "<?php echo JsEncode($loantypes_add->nexttierwarninglangid->errorMessage()) ?>");
			<?php if ($loantypes_add->nexttiernotificationlangid->Required) { ?>
				elm = this.getElements("x" + infix + "_nexttiernotificationlangid");
				if (elm && !ew.isHidden(elm) && !ew.hasValue(elm))
					return this.onError(elm, "<?php echo JsEncode(str_replace("%s", $loantypes_add->nexttiernotificationlangid->caption(), $loantypes_add->nexttiernotificationlangid->RequiredErrorMessage)) ?>");
			<?php } ?>
				elm = this.getElements("x" + infix + "_nexttiernotificationlangid");
				if (elm && !ew.checkInteger(elm.value))
					return this.onError(elm, "<?php echo JsEncode($loantypes_add->nexttiernotificationlangid->errorMessage()) ?>");
			<?php if ($loantypes_add->ignoreholidays->Required) { ?>
				elm = this.getElements("x" + infix + "_ignoreholidays");
				if (elm && !ew.isHidden(elm) && !ew.hasValue(elm))
					return this.onError(elm, "<?php echo JsEncode(str_replace("%s", $loantypes_add->ignoreholidays->caption(), $loantypes_add->ignoreholidays->RequiredErrorMessage)) ?>");
			<?php } ?>
				elm = this.getElements("x" + infix + "_ignoreholidays");
				if (elm && !ew.checkInteger(elm.value))
					return this.onError(elm, "<?php echo JsEncode($loantypes_add->ignoreholidays->errorMessage()) ?>");
			<?php if ($loantypes_add->flagging->Required) { ?>
				elm = this.getElements("x" + infix + "_flagging");
				if (elm && !ew.isHidden(elm) && !ew.hasValue(elm))
					return this.onError(elm, "<?php echo JsEncode(str_replace("%s", $loantypes_add->flagging->caption(), $loantypes_add->flagging->RequiredErrorMessage)) ?>");
			<?php } ?>
				elm = this.getElements("x" + infix + "_flagging");
				if (elm && !ew.checkInteger(elm.value))
					return this.onError(elm, "<?php echo JsEncode($loantypes_add->flagging->errorMessage()) ?>");
			<?php if ($loantypes_add->flaggingdays->Required) { ?>
				elm = this.getElements("x" + infix + "_flaggingdays");
				if (elm && !ew.isHidden(elm) && !ew.hasValue(elm))
					return this.onError(elm, "<?php echo JsEncode(str_replace("%s", $loantypes_add->flaggingdays->caption(), $loantypes_add->flaggingdays->RequiredErrorMessage)) ?>");
			<?php } ?>
				elm = this.getElements("x" + infix + "_flaggingdays");
				if (elm && !ew.checkInteger(elm.value))
					return this.onError(elm, "<?php echo JsEncode($loantypes_add->flaggingdays->errorMessage()) ?>");
			<?php if ($loantypes_add->flaggingwaringdays->Required) { ?>
				elm = this.getElements("x" + infix + "_flaggingwaringdays");
				if (elm && !ew.isHidden(elm) && !ew.hasValue(elm))
					return this.onError(elm, "<?php echo JsEncode(str_replace("%s", $loantypes_add->flaggingwaringdays->caption(), $loantypes_add->flaggingwaringdays->RequiredErrorMessage)) ?>");
			<?php } ?>
				elm = this.getElements("x" + infix + "_flaggingwaringdays");
				if (elm && !ew.checkInteger(elm.value))
					return this.onError(elm, "<?php echo JsEncode($loantypes_add->flaggingwaringdays->errorMessage()) ?>");
			<?php if ($loantypes_add->flagwarninglangid->Required) { ?>
				elm = this.getElements("x" + infix + "_flagwarninglangid");
				if (elm && !ew.isHidden(elm) && !ew.hasValue(elm))
					return this.onError(elm, "<?php echo JsEncode(str_replace("%s", $loantypes_add->flagwarninglangid->caption(), $loantypes_add->flagwarninglangid->RequiredErrorMessage)) ?>");
			<?php } ?>
				elm = this.getElements("x" + infix + "_flagwarninglangid");
				if (elm && !ew.checkInteger(elm.value))
					return this.onError(elm, "<?php echo JsEncode($loantypes_add->flagwarninglangid->errorMessage()) ?>");
			<?php if ($loantypes_add->noofduedays->Required) { ?>
				elm = this.getElements("x" + infix + "_noofduedays");
				if (elm && !ew.isHidden(elm) && !ew.hasValue(elm))
					return this.onError(elm, "<?php echo JsEncode(str_replace("%s", $loantypes_add->noofduedays->caption(), $loantypes_add->noofduedays->RequiredErrorMessage)) ?>");
			<?php } ?>
				elm = this.getElements("x" + infix + "_noofduedays");
				if (elm && !ew.checkInteger(elm.value))
					return this.onError(elm, "<?php echo JsEncode($loantypes_add->noofduedays->errorMessage()) ?>");
			<?php if ($loantypes_add->optin->Required) { ?>
				elm = this.getElements("x" + infix + "_optin");
				if (elm && !ew.isHidden(elm) && !ew.hasValue(elm))
					return this.onError(elm, "<?php echo JsEncode(str_replace("%s", $loantypes_add->optin->caption(), $loantypes_add->optin->RequiredErrorMessage)) ?>");
			<?php } ?>
				elm = this.getElements("x" + infix + "_optin");
				if (elm && !ew.checkInteger(elm.value))
					return this.onError(elm, "<?php echo JsEncode($loantypes_add->optin->errorMessage()) ?>");
			<?php if ($loantypes_add->optout->Required) { ?>
				elm = this.getElements("x" + infix + "_optout");
				if (elm && !ew.isHidden(elm) && !ew.hasValue(elm))
					return this.onError(elm, "<?php echo JsEncode(str_replace("%s", $loantypes_add->optout->caption(), $loantypes_add->optout->RequiredErrorMessage)) ?>");
			<?php } ?>
				elm = this.getElements("x" + infix + "_optout");
				if (elm && !ew.checkInteger(elm.value))
					return this.onError(elm, "<?php echo JsEncode($loantypes_add->optout->errorMessage()) ?>");
			<?php if ($loantypes_add->noteligiblelangid->Required) { ?>
				elm = this.getElements("x" + infix + "_noteligiblelangid");
				if (elm && !ew.isHidden(elm) && !ew.hasValue(elm))
					return this.onError(elm, "<?php echo JsEncode(str_replace("%s", $loantypes_add->noteligiblelangid->caption(), $loantypes_add->noteligiblelangid->RequiredErrorMessage)) ?>");
			<?php } ?>
				elm = this.getElements("x" + infix + "_noteligiblelangid");
				if (elm && !ew.checkInteger(elm.value))
					return this.onError(elm, "<?php echo JsEncode($loantypes_add->noteligiblelangid->errorMessage()) ?>");
			<?php if ($loantypes_add->loanrequestwarninglangid->Required) { ?>
				elm = this.getElements("x" + infix + "_loanrequestwarninglangid");
				if (elm && !ew.isHidden(elm) && !ew.hasValue(elm))
					return this.onError(elm, "<?php echo JsEncode(str_replace("%s", $loantypes_add->loanrequestwarninglangid->caption(), $loantypes_add->loanrequestwarninglangid->RequiredErrorMessage)) ?>");
			<?php } ?>
				elm = this.getElements("x" + infix + "_loanrequestwarninglangid");
				if (elm && !ew.checkInteger(elm.value))
					return this.onError(elm, "<?php echo JsEncode($loantypes_add->loanrequestwarninglangid->errorMessage()) ?>");
			<?php if ($loantypes_add->optinlangid->Required) { ?>
				elm = this.getElements("x" + infix + "_optinlangid");
				if (elm && !ew.isHidden(elm) && !ew.hasValue(elm))
					return this.onError(elm, "<?php echo JsEncode(str_replace("%s", $loantypes_add->optinlangid->caption(), $loantypes_add->optinlangid->RequiredErrorMessage)) ?>");
			<?php } ?>
				elm = this.getElements("x" + infix + "_optinlangid");
				if (elm && !ew.checkInteger(elm.value))
					return this.onError(elm, "<?php echo JsEncode($loantypes_add->optinlangid->errorMessage()) ?>");
			<?php if ($loantypes_add->optoutlangid->Required) { ?>
				elm = this.getElements("x" + infix + "_optoutlangid");
				if (elm && !ew.isHidden(elm) && !ew.hasValue(elm))
					return this.onError(elm, "<?php echo JsEncode(str_replace("%s", $loantypes_add->optoutlangid->caption(), $loantypes_add->optoutlangid->RequiredErrorMessage)) ?>");
			<?php } ?>
				elm = this.getElements("x" + infix + "_optoutlangid");
				if (elm && !ew.checkInteger(elm.value))
					return this.onError(elm, "<?php echo JsEncode($loantypes_add->optoutlangid->errorMessage()) ?>");
			<?php if ($loantypes_add->loanlimitlangid->Required) { ?>
				elm = this.getElements("x" + infix + "_loanlimitlangid");
				if (elm && !ew.isHidden(elm) && !ew.hasValue(elm))
					return this.onError(elm, "<?php echo JsEncode(str_replace("%s", $loantypes_add->loanlimitlangid->caption(), $loantypes_add->loanlimitlangid->RequiredErrorMessage)) ?>");
			<?php } ?>
				elm = this.getElements("x" + infix + "_loanlimitlangid");
				if (elm && !ew.checkInteger(elm.value))
					return this.onError(elm, "<?php echo JsEncode($loantypes_add->loanlimitlangid->errorMessage()) ?>");
			<?php if ($loantypes_add->includefeesineligibilitycheck->Required) { ?>
				elm = this.getElements("x" + infix + "_includefeesineligibilitycheck");
				if (elm && !ew.isHidden(elm) && !ew.hasValue(elm))
					return this.onError(elm, "<?php echo JsEncode(str_replace("%s", $loantypes_add->includefeesineligibilitycheck->caption(), $loantypes_add->includefeesineligibilitycheck->RequiredErrorMessage)) ?>");
			<?php } ?>
				elm = this.getElements("x" + infix + "_includefeesineligibilitycheck");
				if (elm && !ew.checkInteger(elm.value))
					return this.onError(elm, "<?php echo JsEncode($loantypes_add->includefeesineligibilitycheck->errorMessage()) ?>");
			<?php if ($loantypes_add->disbursementtype->Required) { ?>
				elm = this.getElements("x" + infix + "_disbursementtype");
				if (elm && !ew.isHidden(elm) && !ew.hasValue(elm))
					return this.onError(elm, "<?php echo JsEncode(str_replace("%s", $loantypes_add->disbursementtype->caption(), $loantypes_add->disbursementtype->RequiredErrorMessage)) ?>");
			<?php } ?>
				elm = this.getElements("x" + infix + "_disbursementtype");
				if (elm && !ew.checkInteger(elm.value))
					return this.onError(elm, "<?php echo JsEncode($loantypes_add->disbursementtype->errorMessage()) ?>");
			<?php if ($loantypes_add->timegranularity->Required) { ?>
				elm = this.getElements("x" + infix + "_timegranularity");
				if (elm && !ew.isHidden(elm) && !ew.hasValue(elm))
					return this.onError(elm, "<?php echo JsEncode(str_replace("%s", $loantypes_add->timegranularity->caption(), $loantypes_add->timegranularity->RequiredErrorMessage)) ?>");
			<?php } ?>
				elm = this.getElements("x" + infix + "_timegranularity");
				if (elm && !ew.checkInteger(elm.value))
					return this.onError(elm, "<?php echo JsEncode($loantypes_add->timegranularity->errorMessage()) ?>");
			<?php if ($loantypes_add->loanrequestconfirmationlangid->Required) { ?>
				elm = this.getElements("x" + infix + "_loanrequestconfirmationlangid");
				if (elm && !ew.isHidden(elm) && !ew.hasValue(elm))
					return this.onError(elm, "<?php echo JsEncode(str_replace("%s", $loantypes_add->loanrequestconfirmationlangid->caption(), $loantypes_add->loanrequestconfirmationlangid->RequiredErrorMessage)) ?>");
			<?php } ?>
				elm = this.getElements("x" + infix + "_loanrequestconfirmationlangid");
				if (elm && !ew.checkInteger(elm.value))
					return this.onError(elm, "<?php echo JsEncode($loantypes_add->loanrequestconfirmationlangid->errorMessage()) ?>");
			<?php if ($loantypes_add->loanpaymentconfirmationlangid->Required) { ?>
				elm = this.getElements("x" + infix + "_loanpaymentconfirmationlangid");
				if (elm && !ew.isHidden(elm) && !ew.hasValue(elm))
					return this.onError(elm, "<?php echo JsEncode(str_replace("%s", $loantypes_add->loanpaymentconfirmationlangid->caption(), $loantypes_add->loanpaymentconfirmationlangid->RequiredErrorMessage)) ?>");
			<?php } ?>
				elm = this.getElements("x" + infix + "_loanpaymentconfirmationlangid");
				if (elm && !ew.checkInteger(elm.value))
					return this.onError(elm, "<?php echo JsEncode($loantypes_add->loanpaymentconfirmationlangid->errorMessage()) ?>");
			<?php if ($loantypes_add->restrictive->Required) { ?>
				elm = this.getElements("x" + infix + "_restrictive");
				if (elm && !ew.isHidden(elm) && !ew.hasValue(elm))
					return this.onError(elm, "<?php echo JsEncode(str_replace("%s", $loantypes_add->restrictive->caption(), $loantypes_add->restrictive->RequiredErrorMessage)) ?>");
			<?php } ?>
				elm = this.getElements("x" + infix + "_restrictive");
				if (elm && !ew.checkInteger(elm.value))
					return this.onError(elm, "<?php echo JsEncode($loantypes_add->restrictive->errorMessage()) ?>");
			<?php if ($loantypes_add->ignorenextbusinessday->Required) { ?>
				elm = this.getElements("x" + infix + "_ignorenextbusinessday");
				if (elm && !ew.isHidden(elm) && !ew.hasValue(elm))
					return this.onError(elm, "<?php echo JsEncode(str_replace("%s", $loantypes_add->ignorenextbusinessday->caption(), $loantypes_add->ignorenextbusinessday->RequiredErrorMessage)) ?>");
			<?php } ?>
				elm = this.getElements("x" + infix + "_ignorenextbusinessday");
				if (elm && !ew.checkInteger(elm.value))
					return this.onError(elm, "<?php echo JsEncode($loantypes_add->ignorenextbusinessday->errorMessage()) ?>");
			<?php if ($loantypes_add->maxactiveloans->Required) { ?>
				elm = this.getElements("x" + infix + "_maxactiveloans");
				if (elm && !ew.isHidden(elm) && !ew.hasValue(elm))
					return this.onError(elm, "<?php echo JsEncode(str_replace("%s", $loantypes_add->maxactiveloans->caption(), $loantypes_add->maxactiveloans->RequiredErrorMessage)) ?>");
			<?php } ?>
				elm = this.getElements("x" + infix + "_maxactiveloans");
				if (elm && !ew.checkInteger(elm.value))
					return this.onError(elm, "<?php echo JsEncode($loantypes_add->maxactiveloans->errorMessage()) ?>");
			<?php if ($loantypes_add->terminterestallocationtype->Required) { ?>
				elm = this.getElements("x" + infix + "_terminterestallocationtype");
				if (elm && !ew.isHidden(elm) && !ew.hasValue(elm))
					return this.onError(elm, "<?php echo JsEncode(str_replace("%s", $loantypes_add->terminterestallocationtype->caption(), $loantypes_add->terminterestallocationtype->RequiredErrorMessage)) ?>");
			<?php } ?>
				elm = this.getElements("x" + infix + "_terminterestallocationtype");
				if (elm && !ew.checkInteger(elm.value))
					return this.onError(elm, "<?php echo JsEncode($loantypes_add->terminterestallocationtype->errorMessage()) ?>");

				// Call Form_CustomValidate event
				if (!this.Form_CustomValidate(fobj))
					return false;
		}

		// Process detail forms
		var dfs = $fobj.find("input[name='detailpage']").get();
		for (var i = 0; i < dfs.length; i++) {
			var df = dfs[i], val = df.value;
			if (val && ew.forms[val])
				if (!ew.forms[val].validate())
					return false;
		}
		return true;
	}

	// Form_CustomValidate
	floantypesadd.Form_CustomValidate = function(fobj) { // DO NOT CHANGE THIS LINE!

		// Your custom validation code here, return false if invalid.
		return true;
	}

	// Use JavaScript validation or not
	floantypesadd.validateRequired = <?php echo Config("CLIENT_VALIDATE") ? "true" : "false" ?>;

	// Dynamic selection lists
	loadjs.done("floantypesadd");
});
</script>
<script>
loadjs.ready("head", function() {

	// Client script
	// Write your client script here, no need to add script tags.

});
</script>
<?php $loantypes_add->showPageHeader(); ?>
<?php
$loantypes_add->showMessage();
?>
<form name="floantypesadd" id="floantypesadd" class="<?php echo $loantypes_add->FormClassName ?>" action="<?php echo CurrentPageName() ?>" method="post">
<?php if ($Page->CheckToken) { ?>
<input type="hidden" name="<?php echo Config("TOKEN_NAME") ?>" value="<?php echo $Page->Token ?>">
<?php } ?>
<input type="hidden" name="t" value="loantypes">
<input type="hidden" name="action" id="action" value="insert">
<input type="hidden" name="modal" value="<?php echo (int)$loantypes_add->IsModal ?>">
<div class="ew-add-div"><!-- page* -->
<?php if ($loantypes_add->loantype->Visible) { // loantype ?>
	<div id="r_loantype" class="form-group row">
		<label id="elh_loantypes_loantype" for="x_loantype" class="<?php echo $loantypes_add->LeftColumnClass ?>"><?php echo $loantypes_add->loantype->caption() ?><?php echo $loantypes_add->loantype->Required ? $Language->phrase("FieldRequiredIndicator") : "" ?></label>
		<div class="<?php echo $loantypes_add->RightColumnClass ?>"><div <?php echo $loantypes_add->loantype->cellAttributes() ?>>
<span id="el_loantypes_loantype">
<input type="text" data-table="loantypes" data-field="x_loantype" name="x_loantype" id="x_loantype" size="30" maxlength="3" placeholder="<?php echo HtmlEncode($loantypes_add->loantype->getPlaceHolder()) ?>" value="<?php echo $loantypes_add->loantype->EditValue ?>"<?php echo $loantypes_add->loantype->editAttributes() ?>>
</span>
<?php echo $loantypes_add->loantype->CustomMsg ?></div></div>
	</div>
<?php } ?>
<?php if ($loantypes_add->loandesc->Visible) { // loandesc ?>
	<div id="r_loandesc" class="form-group row">
		<label id="elh_loantypes_loandesc" for="x_loandesc" class="<?php echo $loantypes_add->LeftColumnClass ?>"><?php echo $loantypes_add->loandesc->caption() ?><?php echo $loantypes_add->loandesc->Required ? $Language->phrase("FieldRequiredIndicator") : "" ?></label>
		<div class="<?php echo $loantypes_add->RightColumnClass ?>"><div <?php echo $loantypes_add->loandesc->cellAttributes() ?>>
<span id="el_loantypes_loandesc">
<input type="text" data-table="loantypes" data-field="x_loandesc" name="x_loandesc" id="x_loandesc" size="30" maxlength="60" placeholder="<?php echo HtmlEncode($loantypes_add->loandesc->getPlaceHolder()) ?>" value="<?php echo $loantypes_add->loandesc->EditValue ?>"<?php echo $loantypes_add->loandesc->editAttributes() ?>>
</span>
<?php echo $loantypes_add->loandesc->CustomMsg ?></div></div>
	</div>
<?php } ?>
<?php if ($loantypes_add->feeperc->Visible) { // feeperc ?>
	<div id="r_feeperc" class="form-group row">
		<label id="elh_loantypes_feeperc" for="x_feeperc" class="<?php echo $loantypes_add->LeftColumnClass ?>"><?php echo $loantypes_add->feeperc->caption() ?><?php echo $loantypes_add->feeperc->Required ? $Language->phrase("FieldRequiredIndicator") : "" ?></label>
		<div class="<?php echo $loantypes_add->RightColumnClass ?>"><div <?php echo $loantypes_add->feeperc->cellAttributes() ?>>
<span id="el_loantypes_feeperc">
<input type="text" data-table="loantypes" data-field="x_feeperc" name="x_feeperc" id="x_feeperc" size="30" maxlength="5" placeholder="<?php echo HtmlEncode($loantypes_add->feeperc->getPlaceHolder()) ?>" value="<?php echo $loantypes_add->feeperc->EditValue ?>"<?php echo $loantypes_add->feeperc->editAttributes() ?>>
</span>
<?php echo $loantypes_add->feeperc->CustomMsg ?></div></div>
	</div>
<?php } ?>
<?php if ($loantypes_add->feefixed->Visible) { // feefixed ?>
	<div id="r_feefixed" class="form-group row">
		<label id="elh_loantypes_feefixed" for="x_feefixed" class="<?php echo $loantypes_add->LeftColumnClass ?>"><?php echo $loantypes_add->feefixed->caption() ?><?php echo $loantypes_add->feefixed->Required ? $Language->phrase("FieldRequiredIndicator") : "" ?></label>
		<div class="<?php echo $loantypes_add->RightColumnClass ?>"><div <?php echo $loantypes_add->feefixed->cellAttributes() ?>>
<span id="el_loantypes_feefixed">
<input type="text" data-table="loantypes" data-field="x_feefixed" name="x_feefixed" id="x_feefixed" size="30" maxlength="10" placeholder="<?php echo HtmlEncode($loantypes_add->feefixed->getPlaceHolder()) ?>" value="<?php echo $loantypes_add->feefixed->EditValue ?>"<?php echo $loantypes_add->feefixed->editAttributes() ?>>
</span>
<?php echo $loantypes_add->feefixed->CustomMsg ?></div></div>
	</div>
<?php } ?>
<?php if ($loantypes_add->feetax->Visible) { // feetax ?>
	<div id="r_feetax" class="form-group row">
		<label id="elh_loantypes_feetax" for="x_feetax" class="<?php echo $loantypes_add->LeftColumnClass ?>"><?php echo $loantypes_add->feetax->caption() ?><?php echo $loantypes_add->feetax->Required ? $Language->phrase("FieldRequiredIndicator") : "" ?></label>
		<div class="<?php echo $loantypes_add->RightColumnClass ?>"><div <?php echo $loantypes_add->feetax->cellAttributes() ?>>
<span id="el_loantypes_feetax">
<input type="text" data-table="loantypes" data-field="x_feetax" name="x_feetax" id="x_feetax" size="30" maxlength="10" placeholder="<?php echo HtmlEncode($loantypes_add->feetax->getPlaceHolder()) ?>" value="<?php echo $loantypes_add->feetax->EditValue ?>"<?php echo $loantypes_add->feetax->editAttributes() ?>>
</span>
<?php echo $loantypes_add->feetax->CustomMsg ?></div></div>
	</div>
<?php } ?>
<?php if ($loantypes_add->purchasetableid->Visible) { // purchasetableid ?>
	<div id="r_purchasetableid" class="form-group row">
		<label id="elh_loantypes_purchasetableid" for="x_purchasetableid" class="<?php echo $loantypes_add->LeftColumnClass ?>"><?php echo $loantypes_add->purchasetableid->caption() ?><?php echo $loantypes_add->purchasetableid->Required ? $Language->phrase("FieldRequiredIndicator") : "" ?></label>
		<div class="<?php echo $loantypes_add->RightColumnClass ?>"><div <?php echo $loantypes_add->purchasetableid->cellAttributes() ?>>
<span id="el_loantypes_purchasetableid">
<input type="text" data-table="loantypes" data-field="x_purchasetableid" name="x_purchasetableid" id="x_purchasetableid" size="30" maxlength="10" placeholder="<?php echo HtmlEncode($loantypes_add->purchasetableid->getPlaceHolder()) ?>" value="<?php echo $loantypes_add->purchasetableid->EditValue ?>"<?php echo $loantypes_add->purchasetableid->editAttributes() ?>>
</span>
<?php echo $loantypes_add->purchasetableid->CustomMsg ?></div></div>
	</div>
<?php } ?>
<?php if ($loantypes_add->numberofdays->Visible) { // numberofdays ?>
	<div id="r_numberofdays" class="form-group row">
		<label id="elh_loantypes_numberofdays" for="x_numberofdays" class="<?php echo $loantypes_add->LeftColumnClass ?>"><?php echo $loantypes_add->numberofdays->caption() ?><?php echo $loantypes_add->numberofdays->Required ? $Language->phrase("FieldRequiredIndicator") : "" ?></label>
		<div class="<?php echo $loantypes_add->RightColumnClass ?>"><div <?php echo $loantypes_add->numberofdays->cellAttributes() ?>>
<span id="el_loantypes_numberofdays">
<input type="text" data-table="loantypes" data-field="x_numberofdays" name="x_numberofdays" id="x_numberofdays" size="30" maxlength="3" placeholder="<?php echo HtmlEncode($loantypes_add->numberofdays->getPlaceHolder()) ?>" value="<?php echo $loantypes_add->numberofdays->EditValue ?>"<?php echo $loantypes_add->numberofdays->editAttributes() ?>>
</span>
<?php echo $loantypes_add->numberofdays->CustomMsg ?></div></div>
	</div>
<?php } ?>
<?php if ($loantypes_add->nextloantype->Visible) { // nextloantype ?>
	<div id="r_nextloantype" class="form-group row">
		<label id="elh_loantypes_nextloantype" for="x_nextloantype" class="<?php echo $loantypes_add->LeftColumnClass ?>"><?php echo $loantypes_add->nextloantype->caption() ?><?php echo $loantypes_add->nextloantype->Required ? $Language->phrase("FieldRequiredIndicator") : "" ?></label>
		<div class="<?php echo $loantypes_add->RightColumnClass ?>"><div <?php echo $loantypes_add->nextloantype->cellAttributes() ?>>
<span id="el_loantypes_nextloantype">
<input type="text" data-table="loantypes" data-field="x_nextloantype" name="x_nextloantype" id="x_nextloantype" size="30" maxlength="3" placeholder="<?php echo HtmlEncode($loantypes_add->nextloantype->getPlaceHolder()) ?>" value="<?php echo $loantypes_add->nextloantype->EditValue ?>"<?php echo $loantypes_add->nextloantype->editAttributes() ?>>
</span>
<?php echo $loantypes_add->nextloantype->CustomMsg ?></div></div>
	</div>
<?php } ?>
<?php if ($loantypes_add->latefeetableid->Visible) { // latefeetableid ?>
	<div id="r_latefeetableid" class="form-group row">
		<label id="elh_loantypes_latefeetableid" for="x_latefeetableid" class="<?php echo $loantypes_add->LeftColumnClass ?>"><?php echo $loantypes_add->latefeetableid->caption() ?><?php echo $loantypes_add->latefeetableid->Required ? $Language->phrase("FieldRequiredIndicator") : "" ?></label>
		<div class="<?php echo $loantypes_add->RightColumnClass ?>"><div <?php echo $loantypes_add->latefeetableid->cellAttributes() ?>>
<span id="el_loantypes_latefeetableid">
<input type="text" data-table="loantypes" data-field="x_latefeetableid" name="x_latefeetableid" id="x_latefeetableid" size="30" maxlength="10" placeholder="<?php echo HtmlEncode($loantypes_add->latefeetableid->getPlaceHolder()) ?>" value="<?php echo $loantypes_add->latefeetableid->EditValue ?>"<?php echo $loantypes_add->latefeetableid->editAttributes() ?>>
</span>
<?php echo $loantypes_add->latefeetableid->CustomMsg ?></div></div>
	</div>
<?php } ?>
<?php if ($loantypes_add->stopcalculatingafterdays->Visible) { // stopcalculatingafterdays ?>
	<div id="r_stopcalculatingafterdays" class="form-group row">
		<label id="elh_loantypes_stopcalculatingafterdays" for="x_stopcalculatingafterdays" class="<?php echo $loantypes_add->LeftColumnClass ?>"><?php echo $loantypes_add->stopcalculatingafterdays->caption() ?><?php echo $loantypes_add->stopcalculatingafterdays->Required ? $Language->phrase("FieldRequiredIndicator") : "" ?></label>
		<div class="<?php echo $loantypes_add->RightColumnClass ?>"><div <?php echo $loantypes_add->stopcalculatingafterdays->cellAttributes() ?>>
<span id="el_loantypes_stopcalculatingafterdays">
<input type="text" data-table="loantypes" data-field="x_stopcalculatingafterdays" name="x_stopcalculatingafterdays" id="x_stopcalculatingafterdays" size="30" maxlength="5" placeholder="<?php echo HtmlEncode($loantypes_add->stopcalculatingafterdays->getPlaceHolder()) ?>" value="<?php echo $loantypes_add->stopcalculatingafterdays->EditValue ?>"<?php echo $loantypes_add->stopcalculatingafterdays->editAttributes() ?>>
</span>
<?php echo $loantypes_add->stopcalculatingafterdays->CustomMsg ?></div></div>
	</div>
<?php } ?>
<?php if ($loantypes_add->graceperioddays->Visible) { // graceperioddays ?>
	<div id="r_graceperioddays" class="form-group row">
		<label id="elh_loantypes_graceperioddays" for="x_graceperioddays" class="<?php echo $loantypes_add->LeftColumnClass ?>"><?php echo $loantypes_add->graceperioddays->caption() ?><?php echo $loantypes_add->graceperioddays->Required ? $Language->phrase("FieldRequiredIndicator") : "" ?></label>
		<div class="<?php echo $loantypes_add->RightColumnClass ?>"><div <?php echo $loantypes_add->graceperioddays->cellAttributes() ?>>
<span id="el_loantypes_graceperioddays">
<input type="text" data-table="loantypes" data-field="x_graceperioddays" name="x_graceperioddays" id="x_graceperioddays" size="30" maxlength="3" placeholder="<?php echo HtmlEncode($loantypes_add->graceperioddays->getPlaceHolder()) ?>" value="<?php echo $loantypes_add->graceperioddays->EditValue ?>"<?php echo $loantypes_add->graceperioddays->editAttributes() ?>>
</span>
<?php echo $loantypes_add->graceperioddays->CustomMsg ?></div></div>
	</div>
<?php } ?>
<?php if ($loantypes_add->feecalculationmode->Visible) { // feecalculationmode ?>
	<div id="r_feecalculationmode" class="form-group row">
		<label id="elh_loantypes_feecalculationmode" for="x_feecalculationmode" class="<?php echo $loantypes_add->LeftColumnClass ?>"><?php echo $loantypes_add->feecalculationmode->caption() ?><?php echo $loantypes_add->feecalculationmode->Required ? $Language->phrase("FieldRequiredIndicator") : "" ?></label>
		<div class="<?php echo $loantypes_add->RightColumnClass ?>"><div <?php echo $loantypes_add->feecalculationmode->cellAttributes() ?>>
<span id="el_loantypes_feecalculationmode">
<input type="text" data-table="loantypes" data-field="x_feecalculationmode" name="x_feecalculationmode" id="x_feecalculationmode" size="30" maxlength="1" placeholder="<?php echo HtmlEncode($loantypes_add->feecalculationmode->getPlaceHolder()) ?>" value="<?php echo $loantypes_add->feecalculationmode->EditValue ?>"<?php echo $loantypes_add->feecalculationmode->editAttributes() ?>>
</span>
<?php echo $loantypes_add->feecalculationmode->CustomMsg ?></div></div>
	</div>
<?php } ?>
<?php if ($loantypes_add->latefeewarninglangid->Visible) { // latefeewarninglangid ?>
	<div id="r_latefeewarninglangid" class="form-group row">
		<label id="elh_loantypes_latefeewarninglangid" for="x_latefeewarninglangid" class="<?php echo $loantypes_add->LeftColumnClass ?>"><?php echo $loantypes_add->latefeewarninglangid->caption() ?><?php echo $loantypes_add->latefeewarninglangid->Required ? $Language->phrase("FieldRequiredIndicator") : "" ?></label>
		<div class="<?php echo $loantypes_add->RightColumnClass ?>"><div <?php echo $loantypes_add->latefeewarninglangid->cellAttributes() ?>>
<span id="el_loantypes_latefeewarninglangid">
<input type="text" data-table="loantypes" data-field="x_latefeewarninglangid" name="x_latefeewarninglangid" id="x_latefeewarninglangid" size="30" maxlength="12" placeholder="<?php echo HtmlEncode($loantypes_add->latefeewarninglangid->getPlaceHolder()) ?>" value="<?php echo $loantypes_add->latefeewarninglangid->EditValue ?>"<?php echo $loantypes_add->latefeewarninglangid->editAttributes() ?>>
</span>
<?php echo $loantypes_add->latefeewarninglangid->CustomMsg ?></div></div>
	</div>
<?php } ?>
<?php if ($loantypes_add->latefeelangid->Visible) { // latefeelangid ?>
	<div id="r_latefeelangid" class="form-group row">
		<label id="elh_loantypes_latefeelangid" for="x_latefeelangid" class="<?php echo $loantypes_add->LeftColumnClass ?>"><?php echo $loantypes_add->latefeelangid->caption() ?><?php echo $loantypes_add->latefeelangid->Required ? $Language->phrase("FieldRequiredIndicator") : "" ?></label>
		<div class="<?php echo $loantypes_add->RightColumnClass ?>"><div <?php echo $loantypes_add->latefeelangid->cellAttributes() ?>>
<span id="el_loantypes_latefeelangid">
<input type="text" data-table="loantypes" data-field="x_latefeelangid" name="x_latefeelangid" id="x_latefeelangid" size="30" maxlength="12" placeholder="<?php echo HtmlEncode($loantypes_add->latefeelangid->getPlaceHolder()) ?>" value="<?php echo $loantypes_add->latefeelangid->EditValue ?>"<?php echo $loantypes_add->latefeelangid->editAttributes() ?>>
</span>
<?php echo $loantypes_add->latefeelangid->CustomMsg ?></div></div>
	</div>
<?php } ?>
<?php if ($loantypes_add->flaggedlangid->Visible) { // flaggedlangid ?>
	<div id="r_flaggedlangid" class="form-group row">
		<label id="elh_loantypes_flaggedlangid" for="x_flaggedlangid" class="<?php echo $loantypes_add->LeftColumnClass ?>"><?php echo $loantypes_add->flaggedlangid->caption() ?><?php echo $loantypes_add->flaggedlangid->Required ? $Language->phrase("FieldRequiredIndicator") : "" ?></label>
		<div class="<?php echo $loantypes_add->RightColumnClass ?>"><div <?php echo $loantypes_add->flaggedlangid->cellAttributes() ?>>
<span id="el_loantypes_flaggedlangid">
<input type="text" data-table="loantypes" data-field="x_flaggedlangid" name="x_flaggedlangid" id="x_flaggedlangid" size="30" maxlength="12" placeholder="<?php echo HtmlEncode($loantypes_add->flaggedlangid->getPlaceHolder()) ?>" value="<?php echo $loantypes_add->flaggedlangid->EditValue ?>"<?php echo $loantypes_add->flaggedlangid->editAttributes() ?>>
</span>
<?php echo $loantypes_add->flaggedlangid->CustomMsg ?></div></div>
	</div>
<?php } ?>
<?php if ($loantypes_add->unblocklangid->Visible) { // unblocklangid ?>
	<div id="r_unblocklangid" class="form-group row">
		<label id="elh_loantypes_unblocklangid" for="x_unblocklangid" class="<?php echo $loantypes_add->LeftColumnClass ?>"><?php echo $loantypes_add->unblocklangid->caption() ?><?php echo $loantypes_add->unblocklangid->Required ? $Language->phrase("FieldRequiredIndicator") : "" ?></label>
		<div class="<?php echo $loantypes_add->RightColumnClass ?>"><div <?php echo $loantypes_add->unblocklangid->cellAttributes() ?>>
<span id="el_loantypes_unblocklangid">
<input type="text" data-table="loantypes" data-field="x_unblocklangid" name="x_unblocklangid" id="x_unblocklangid" size="30" maxlength="12" placeholder="<?php echo HtmlEncode($loantypes_add->unblocklangid->getPlaceHolder()) ?>" value="<?php echo $loantypes_add->unblocklangid->EditValue ?>"<?php echo $loantypes_add->unblocklangid->editAttributes() ?>>
</span>
<?php echo $loantypes_add->unblocklangid->CustomMsg ?></div></div>
	</div>
<?php } ?>
<?php if ($loantypes_add->blockedlangid->Visible) { // blockedlangid ?>
	<div id="r_blockedlangid" class="form-group row">
		<label id="elh_loantypes_blockedlangid" for="x_blockedlangid" class="<?php echo $loantypes_add->LeftColumnClass ?>"><?php echo $loantypes_add->blockedlangid->caption() ?><?php echo $loantypes_add->blockedlangid->Required ? $Language->phrase("FieldRequiredIndicator") : "" ?></label>
		<div class="<?php echo $loantypes_add->RightColumnClass ?>"><div <?php echo $loantypes_add->blockedlangid->cellAttributes() ?>>
<span id="el_loantypes_blockedlangid">
<input type="text" data-table="loantypes" data-field="x_blockedlangid" name="x_blockedlangid" id="x_blockedlangid" size="30" maxlength="12" placeholder="<?php echo HtmlEncode($loantypes_add->blockedlangid->getPlaceHolder()) ?>" value="<?php echo $loantypes_add->blockedlangid->EditValue ?>"<?php echo $loantypes_add->blockedlangid->editAttributes() ?>>
</span>
<?php echo $loantypes_add->blockedlangid->CustomMsg ?></div></div>
	</div>
<?php } ?>
<?php if ($loantypes_add->nexttierwarninglangid->Visible) { // nexttierwarninglangid ?>
	<div id="r_nexttierwarninglangid" class="form-group row">
		<label id="elh_loantypes_nexttierwarninglangid" for="x_nexttierwarninglangid" class="<?php echo $loantypes_add->LeftColumnClass ?>"><?php echo $loantypes_add->nexttierwarninglangid->caption() ?><?php echo $loantypes_add->nexttierwarninglangid->Required ? $Language->phrase("FieldRequiredIndicator") : "" ?></label>
		<div class="<?php echo $loantypes_add->RightColumnClass ?>"><div <?php echo $loantypes_add->nexttierwarninglangid->cellAttributes() ?>>
<span id="el_loantypes_nexttierwarninglangid">
<input type="text" data-table="loantypes" data-field="x_nexttierwarninglangid" name="x_nexttierwarninglangid" id="x_nexttierwarninglangid" size="30" maxlength="12" placeholder="<?php echo HtmlEncode($loantypes_add->nexttierwarninglangid->getPlaceHolder()) ?>" value="<?php echo $loantypes_add->nexttierwarninglangid->EditValue ?>"<?php echo $loantypes_add->nexttierwarninglangid->editAttributes() ?>>
</span>
<?php echo $loantypes_add->nexttierwarninglangid->CustomMsg ?></div></div>
	</div>
<?php } ?>
<?php if ($loantypes_add->nexttiernotificationlangid->Visible) { // nexttiernotificationlangid ?>
	<div id="r_nexttiernotificationlangid" class="form-group row">
		<label id="elh_loantypes_nexttiernotificationlangid" for="x_nexttiernotificationlangid" class="<?php echo $loantypes_add->LeftColumnClass ?>"><?php echo $loantypes_add->nexttiernotificationlangid->caption() ?><?php echo $loantypes_add->nexttiernotificationlangid->Required ? $Language->phrase("FieldRequiredIndicator") : "" ?></label>
		<div class="<?php echo $loantypes_add->RightColumnClass ?>"><div <?php echo $loantypes_add->nexttiernotificationlangid->cellAttributes() ?>>
<span id="el_loantypes_nexttiernotificationlangid">
<input type="text" data-table="loantypes" data-field="x_nexttiernotificationlangid" name="x_nexttiernotificationlangid" id="x_nexttiernotificationlangid" size="30" maxlength="12" placeholder="<?php echo HtmlEncode($loantypes_add->nexttiernotificationlangid->getPlaceHolder()) ?>" value="<?php echo $loantypes_add->nexttiernotificationlangid->EditValue ?>"<?php echo $loantypes_add->nexttiernotificationlangid->editAttributes() ?>>
</span>
<?php echo $loantypes_add->nexttiernotificationlangid->CustomMsg ?></div></div>
	</div>
<?php } ?>
<?php if ($loantypes_add->ignoreholidays->Visible) { // ignoreholidays ?>
	<div id="r_ignoreholidays" class="form-group row">
		<label id="elh_loantypes_ignoreholidays" for="x_ignoreholidays" class="<?php echo $loantypes_add->LeftColumnClass ?>"><?php echo $loantypes_add->ignoreholidays->caption() ?><?php echo $loantypes_add->ignoreholidays->Required ? $Language->phrase("FieldRequiredIndicator") : "" ?></label>
		<div class="<?php echo $loantypes_add->RightColumnClass ?>"><div <?php echo $loantypes_add->ignoreholidays->cellAttributes() ?>>
<span id="el_loantypes_ignoreholidays">
<input type="text" data-table="loantypes" data-field="x_ignoreholidays" name="x_ignoreholidays" id="x_ignoreholidays" size="30" maxlength="1" placeholder="<?php echo HtmlEncode($loantypes_add->ignoreholidays->getPlaceHolder()) ?>" value="<?php echo $loantypes_add->ignoreholidays->EditValue ?>"<?php echo $loantypes_add->ignoreholidays->editAttributes() ?>>
</span>
<?php echo $loantypes_add->ignoreholidays->CustomMsg ?></div></div>
	</div>
<?php } ?>
<?php if ($loantypes_add->flagging->Visible) { // flagging ?>
	<div id="r_flagging" class="form-group row">
		<label id="elh_loantypes_flagging" for="x_flagging" class="<?php echo $loantypes_add->LeftColumnClass ?>"><?php echo $loantypes_add->flagging->caption() ?><?php echo $loantypes_add->flagging->Required ? $Language->phrase("FieldRequiredIndicator") : "" ?></label>
		<div class="<?php echo $loantypes_add->RightColumnClass ?>"><div <?php echo $loantypes_add->flagging->cellAttributes() ?>>
<span id="el_loantypes_flagging">
<input type="text" data-table="loantypes" data-field="x_flagging" name="x_flagging" id="x_flagging" size="30" maxlength="1" placeholder="<?php echo HtmlEncode($loantypes_add->flagging->getPlaceHolder()) ?>" value="<?php echo $loantypes_add->flagging->EditValue ?>"<?php echo $loantypes_add->flagging->editAttributes() ?>>
</span>
<?php echo $loantypes_add->flagging->CustomMsg ?></div></div>
	</div>
<?php } ?>
<?php if ($loantypes_add->flaggingdays->Visible) { // flaggingdays ?>
	<div id="r_flaggingdays" class="form-group row">
		<label id="elh_loantypes_flaggingdays" for="x_flaggingdays" class="<?php echo $loantypes_add->LeftColumnClass ?>"><?php echo $loantypes_add->flaggingdays->caption() ?><?php echo $loantypes_add->flaggingdays->Required ? $Language->phrase("FieldRequiredIndicator") : "" ?></label>
		<div class="<?php echo $loantypes_add->RightColumnClass ?>"><div <?php echo $loantypes_add->flaggingdays->cellAttributes() ?>>
<span id="el_loantypes_flaggingdays">
<input type="text" data-table="loantypes" data-field="x_flaggingdays" name="x_flaggingdays" id="x_flaggingdays" size="30" maxlength="5" placeholder="<?php echo HtmlEncode($loantypes_add->flaggingdays->getPlaceHolder()) ?>" value="<?php echo $loantypes_add->flaggingdays->EditValue ?>"<?php echo $loantypes_add->flaggingdays->editAttributes() ?>>
</span>
<?php echo $loantypes_add->flaggingdays->CustomMsg ?></div></div>
	</div>
<?php } ?>
<?php if ($loantypes_add->flaggingwaringdays->Visible) { // flaggingwaringdays ?>
	<div id="r_flaggingwaringdays" class="form-group row">
		<label id="elh_loantypes_flaggingwaringdays" for="x_flaggingwaringdays" class="<?php echo $loantypes_add->LeftColumnClass ?>"><?php echo $loantypes_add->flaggingwaringdays->caption() ?><?php echo $loantypes_add->flaggingwaringdays->Required ? $Language->phrase("FieldRequiredIndicator") : "" ?></label>
		<div class="<?php echo $loantypes_add->RightColumnClass ?>"><div <?php echo $loantypes_add->flaggingwaringdays->cellAttributes() ?>>
<span id="el_loantypes_flaggingwaringdays">
<input type="text" data-table="loantypes" data-field="x_flaggingwaringdays" name="x_flaggingwaringdays" id="x_flaggingwaringdays" size="30" maxlength="5" placeholder="<?php echo HtmlEncode($loantypes_add->flaggingwaringdays->getPlaceHolder()) ?>" value="<?php echo $loantypes_add->flaggingwaringdays->EditValue ?>"<?php echo $loantypes_add->flaggingwaringdays->editAttributes() ?>>
</span>
<?php echo $loantypes_add->flaggingwaringdays->CustomMsg ?></div></div>
	</div>
<?php } ?>
<?php if ($loantypes_add->flagwarninglangid->Visible) { // flagwarninglangid ?>
	<div id="r_flagwarninglangid" class="form-group row">
		<label id="elh_loantypes_flagwarninglangid" for="x_flagwarninglangid" class="<?php echo $loantypes_add->LeftColumnClass ?>"><?php echo $loantypes_add->flagwarninglangid->caption() ?><?php echo $loantypes_add->flagwarninglangid->Required ? $Language->phrase("FieldRequiredIndicator") : "" ?></label>
		<div class="<?php echo $loantypes_add->RightColumnClass ?>"><div <?php echo $loantypes_add->flagwarninglangid->cellAttributes() ?>>
<span id="el_loantypes_flagwarninglangid">
<input type="text" data-table="loantypes" data-field="x_flagwarninglangid" name="x_flagwarninglangid" id="x_flagwarninglangid" size="30" maxlength="12" placeholder="<?php echo HtmlEncode($loantypes_add->flagwarninglangid->getPlaceHolder()) ?>" value="<?php echo $loantypes_add->flagwarninglangid->EditValue ?>"<?php echo $loantypes_add->flagwarninglangid->editAttributes() ?>>
</span>
<?php echo $loantypes_add->flagwarninglangid->CustomMsg ?></div></div>
	</div>
<?php } ?>
<?php if ($loantypes_add->noofduedays->Visible) { // noofduedays ?>
	<div id="r_noofduedays" class="form-group row">
		<label id="elh_loantypes_noofduedays" for="x_noofduedays" class="<?php echo $loantypes_add->LeftColumnClass ?>"><?php echo $loantypes_add->noofduedays->caption() ?><?php echo $loantypes_add->noofduedays->Required ? $Language->phrase("FieldRequiredIndicator") : "" ?></label>
		<div class="<?php echo $loantypes_add->RightColumnClass ?>"><div <?php echo $loantypes_add->noofduedays->cellAttributes() ?>>
<span id="el_loantypes_noofduedays">
<input type="text" data-table="loantypes" data-field="x_noofduedays" name="x_noofduedays" id="x_noofduedays" size="30" maxlength="3" placeholder="<?php echo HtmlEncode($loantypes_add->noofduedays->getPlaceHolder()) ?>" value="<?php echo $loantypes_add->noofduedays->EditValue ?>"<?php echo $loantypes_add->noofduedays->editAttributes() ?>>
</span>
<?php echo $loantypes_add->noofduedays->CustomMsg ?></div></div>
	</div>
<?php } ?>
<?php if ($loantypes_add->optin->Visible) { // optin ?>
	<div id="r_optin" class="form-group row">
		<label id="elh_loantypes_optin" for="x_optin" class="<?php echo $loantypes_add->LeftColumnClass ?>"><?php echo $loantypes_add->optin->caption() ?><?php echo $loantypes_add->optin->Required ? $Language->phrase("FieldRequiredIndicator") : "" ?></label>
		<div class="<?php echo $loantypes_add->RightColumnClass ?>"><div <?php echo $loantypes_add->optin->cellAttributes() ?>>
<span id="el_loantypes_optin">
<input type="text" data-table="loantypes" data-field="x_optin" name="x_optin" id="x_optin" size="30" maxlength="12" placeholder="<?php echo HtmlEncode($loantypes_add->optin->getPlaceHolder()) ?>" value="<?php echo $loantypes_add->optin->EditValue ?>"<?php echo $loantypes_add->optin->editAttributes() ?>>
</span>
<?php echo $loantypes_add->optin->CustomMsg ?></div></div>
	</div>
<?php } ?>
<?php if ($loantypes_add->optout->Visible) { // optout ?>
	<div id="r_optout" class="form-group row">
		<label id="elh_loantypes_optout" for="x_optout" class="<?php echo $loantypes_add->LeftColumnClass ?>"><?php echo $loantypes_add->optout->caption() ?><?php echo $loantypes_add->optout->Required ? $Language->phrase("FieldRequiredIndicator") : "" ?></label>
		<div class="<?php echo $loantypes_add->RightColumnClass ?>"><div <?php echo $loantypes_add->optout->cellAttributes() ?>>
<span id="el_loantypes_optout">
<input type="text" data-table="loantypes" data-field="x_optout" name="x_optout" id="x_optout" size="30" maxlength="12" placeholder="<?php echo HtmlEncode($loantypes_add->optout->getPlaceHolder()) ?>" value="<?php echo $loantypes_add->optout->EditValue ?>"<?php echo $loantypes_add->optout->editAttributes() ?>>
</span>
<?php echo $loantypes_add->optout->CustomMsg ?></div></div>
	</div>
<?php } ?>
<?php if ($loantypes_add->noteligiblelangid->Visible) { // noteligiblelangid ?>
	<div id="r_noteligiblelangid" class="form-group row">
		<label id="elh_loantypes_noteligiblelangid" for="x_noteligiblelangid" class="<?php echo $loantypes_add->LeftColumnClass ?>"><?php echo $loantypes_add->noteligiblelangid->caption() ?><?php echo $loantypes_add->noteligiblelangid->Required ? $Language->phrase("FieldRequiredIndicator") : "" ?></label>
		<div class="<?php echo $loantypes_add->RightColumnClass ?>"><div <?php echo $loantypes_add->noteligiblelangid->cellAttributes() ?>>
<span id="el_loantypes_noteligiblelangid">
<input type="text" data-table="loantypes" data-field="x_noteligiblelangid" name="x_noteligiblelangid" id="x_noteligiblelangid" size="30" maxlength="12" placeholder="<?php echo HtmlEncode($loantypes_add->noteligiblelangid->getPlaceHolder()) ?>" value="<?php echo $loantypes_add->noteligiblelangid->EditValue ?>"<?php echo $loantypes_add->noteligiblelangid->editAttributes() ?>>
</span>
<?php echo $loantypes_add->noteligiblelangid->CustomMsg ?></div></div>
	</div>
<?php } ?>
<?php if ($loantypes_add->loanrequestwarninglangid->Visible) { // loanrequestwarninglangid ?>
	<div id="r_loanrequestwarninglangid" class="form-group row">
		<label id="elh_loantypes_loanrequestwarninglangid" for="x_loanrequestwarninglangid" class="<?php echo $loantypes_add->LeftColumnClass ?>"><?php echo $loantypes_add->loanrequestwarninglangid->caption() ?><?php echo $loantypes_add->loanrequestwarninglangid->Required ? $Language->phrase("FieldRequiredIndicator") : "" ?></label>
		<div class="<?php echo $loantypes_add->RightColumnClass ?>"><div <?php echo $loantypes_add->loanrequestwarninglangid->cellAttributes() ?>>
<span id="el_loantypes_loanrequestwarninglangid">
<input type="text" data-table="loantypes" data-field="x_loanrequestwarninglangid" name="x_loanrequestwarninglangid" id="x_loanrequestwarninglangid" size="30" maxlength="12" placeholder="<?php echo HtmlEncode($loantypes_add->loanrequestwarninglangid->getPlaceHolder()) ?>" value="<?php echo $loantypes_add->loanrequestwarninglangid->EditValue ?>"<?php echo $loantypes_add->loanrequestwarninglangid->editAttributes() ?>>
</span>
<?php echo $loantypes_add->loanrequestwarninglangid->CustomMsg ?></div></div>
	</div>
<?php } ?>
<?php if ($loantypes_add->optinlangid->Visible) { // optinlangid ?>
	<div id="r_optinlangid" class="form-group row">
		<label id="elh_loantypes_optinlangid" for="x_optinlangid" class="<?php echo $loantypes_add->LeftColumnClass ?>"><?php echo $loantypes_add->optinlangid->caption() ?><?php echo $loantypes_add->optinlangid->Required ? $Language->phrase("FieldRequiredIndicator") : "" ?></label>
		<div class="<?php echo $loantypes_add->RightColumnClass ?>"><div <?php echo $loantypes_add->optinlangid->cellAttributes() ?>>
<span id="el_loantypes_optinlangid">
<input type="text" data-table="loantypes" data-field="x_optinlangid" name="x_optinlangid" id="x_optinlangid" size="30" maxlength="12" placeholder="<?php echo HtmlEncode($loantypes_add->optinlangid->getPlaceHolder()) ?>" value="<?php echo $loantypes_add->optinlangid->EditValue ?>"<?php echo $loantypes_add->optinlangid->editAttributes() ?>>
</span>
<?php echo $loantypes_add->optinlangid->CustomMsg ?></div></div>
	</div>
<?php } ?>
<?php if ($loantypes_add->optoutlangid->Visible) { // optoutlangid ?>
	<div id="r_optoutlangid" class="form-group row">
		<label id="elh_loantypes_optoutlangid" for="x_optoutlangid" class="<?php echo $loantypes_add->LeftColumnClass ?>"><?php echo $loantypes_add->optoutlangid->caption() ?><?php echo $loantypes_add->optoutlangid->Required ? $Language->phrase("FieldRequiredIndicator") : "" ?></label>
		<div class="<?php echo $loantypes_add->RightColumnClass ?>"><div <?php echo $loantypes_add->optoutlangid->cellAttributes() ?>>
<span id="el_loantypes_optoutlangid">
<input type="text" data-table="loantypes" data-field="x_optoutlangid" name="x_optoutlangid" id="x_optoutlangid" size="30" maxlength="12" placeholder="<?php echo HtmlEncode($loantypes_add->optoutlangid->getPlaceHolder()) ?>" value="<?php echo $loantypes_add->optoutlangid->EditValue ?>"<?php echo $loantypes_add->optoutlangid->editAttributes() ?>>
</span>
<?php echo $loantypes_add->optoutlangid->CustomMsg ?></div></div>
	</div>
<?php } ?>
<?php if ($loantypes_add->loanlimitlangid->Visible) { // loanlimitlangid ?>
	<div id="r_loanlimitlangid" class="form-group row">
		<label id="elh_loantypes_loanlimitlangid" for="x_loanlimitlangid" class="<?php echo $loantypes_add->LeftColumnClass ?>"><?php echo $loantypes_add->loanlimitlangid->caption() ?><?php echo $loantypes_add->loanlimitlangid->Required ? $Language->phrase("FieldRequiredIndicator") : "" ?></label>
		<div class="<?php echo $loantypes_add->RightColumnClass ?>"><div <?php echo $loantypes_add->loanlimitlangid->cellAttributes() ?>>
<span id="el_loantypes_loanlimitlangid">
<input type="text" data-table="loantypes" data-field="x_loanlimitlangid" name="x_loanlimitlangid" id="x_loanlimitlangid" size="30" maxlength="12" placeholder="<?php echo HtmlEncode($loantypes_add->loanlimitlangid->getPlaceHolder()) ?>" value="<?php echo $loantypes_add->loanlimitlangid->EditValue ?>"<?php echo $loantypes_add->loanlimitlangid->editAttributes() ?>>
</span>
<?php echo $loantypes_add->loanlimitlangid->CustomMsg ?></div></div>
	</div>
<?php } ?>
<?php if ($loantypes_add->includefeesineligibilitycheck->Visible) { // includefeesineligibilitycheck ?>
	<div id="r_includefeesineligibilitycheck" class="form-group row">
		<label id="elh_loantypes_includefeesineligibilitycheck" for="x_includefeesineligibilitycheck" class="<?php echo $loantypes_add->LeftColumnClass ?>"><?php echo $loantypes_add->includefeesineligibilitycheck->caption() ?><?php echo $loantypes_add->includefeesineligibilitycheck->Required ? $Language->phrase("FieldRequiredIndicator") : "" ?></label>
		<div class="<?php echo $loantypes_add->RightColumnClass ?>"><div <?php echo $loantypes_add->includefeesineligibilitycheck->cellAttributes() ?>>
<span id="el_loantypes_includefeesineligibilitycheck">
<input type="text" data-table="loantypes" data-field="x_includefeesineligibilitycheck" name="x_includefeesineligibilitycheck" id="x_includefeesineligibilitycheck" size="30" maxlength="1" placeholder="<?php echo HtmlEncode($loantypes_add->includefeesineligibilitycheck->getPlaceHolder()) ?>" value="<?php echo $loantypes_add->includefeesineligibilitycheck->EditValue ?>"<?php echo $loantypes_add->includefeesineligibilitycheck->editAttributes() ?>>
</span>
<?php echo $loantypes_add->includefeesineligibilitycheck->CustomMsg ?></div></div>
	</div>
<?php } ?>
<?php if ($loantypes_add->disbursementtype->Visible) { // disbursementtype ?>
	<div id="r_disbursementtype" class="form-group row">
		<label id="elh_loantypes_disbursementtype" for="x_disbursementtype" class="<?php echo $loantypes_add->LeftColumnClass ?>"><?php echo $loantypes_add->disbursementtype->caption() ?><?php echo $loantypes_add->disbursementtype->Required ? $Language->phrase("FieldRequiredIndicator") : "" ?></label>
		<div class="<?php echo $loantypes_add->RightColumnClass ?>"><div <?php echo $loantypes_add->disbursementtype->cellAttributes() ?>>
<span id="el_loantypes_disbursementtype">
<input type="text" data-table="loantypes" data-field="x_disbursementtype" name="x_disbursementtype" id="x_disbursementtype" size="30" maxlength="1" placeholder="<?php echo HtmlEncode($loantypes_add->disbursementtype->getPlaceHolder()) ?>" value="<?php echo $loantypes_add->disbursementtype->EditValue ?>"<?php echo $loantypes_add->disbursementtype->editAttributes() ?>>
</span>
<?php echo $loantypes_add->disbursementtype->CustomMsg ?></div></div>
	</div>
<?php } ?>
<?php if ($loantypes_add->timegranularity->Visible) { // timegranularity ?>
	<div id="r_timegranularity" class="form-group row">
		<label id="elh_loantypes_timegranularity" for="x_timegranularity" class="<?php echo $loantypes_add->LeftColumnClass ?>"><?php echo $loantypes_add->timegranularity->caption() ?><?php echo $loantypes_add->timegranularity->Required ? $Language->phrase("FieldRequiredIndicator") : "" ?></label>
		<div class="<?php echo $loantypes_add->RightColumnClass ?>"><div <?php echo $loantypes_add->timegranularity->cellAttributes() ?>>
<span id="el_loantypes_timegranularity">
<input type="text" data-table="loantypes" data-field="x_timegranularity" name="x_timegranularity" id="x_timegranularity" size="30" maxlength="1" placeholder="<?php echo HtmlEncode($loantypes_add->timegranularity->getPlaceHolder()) ?>" value="<?php echo $loantypes_add->timegranularity->EditValue ?>"<?php echo $loantypes_add->timegranularity->editAttributes() ?>>
</span>
<?php echo $loantypes_add->timegranularity->CustomMsg ?></div></div>
	</div>
<?php } ?>
<?php if ($loantypes_add->loanrequestconfirmationlangid->Visible) { // loanrequestconfirmationlangid ?>
	<div id="r_loanrequestconfirmationlangid" class="form-group row">
		<label id="elh_loantypes_loanrequestconfirmationlangid" for="x_loanrequestconfirmationlangid" class="<?php echo $loantypes_add->LeftColumnClass ?>"><?php echo $loantypes_add->loanrequestconfirmationlangid->caption() ?><?php echo $loantypes_add->loanrequestconfirmationlangid->Required ? $Language->phrase("FieldRequiredIndicator") : "" ?></label>
		<div class="<?php echo $loantypes_add->RightColumnClass ?>"><div <?php echo $loantypes_add->loanrequestconfirmationlangid->cellAttributes() ?>>
<span id="el_loantypes_loanrequestconfirmationlangid">
<input type="text" data-table="loantypes" data-field="x_loanrequestconfirmationlangid" name="x_loanrequestconfirmationlangid" id="x_loanrequestconfirmationlangid" size="30" maxlength="12" placeholder="<?php echo HtmlEncode($loantypes_add->loanrequestconfirmationlangid->getPlaceHolder()) ?>" value="<?php echo $loantypes_add->loanrequestconfirmationlangid->EditValue ?>"<?php echo $loantypes_add->loanrequestconfirmationlangid->editAttributes() ?>>
</span>
<?php echo $loantypes_add->loanrequestconfirmationlangid->CustomMsg ?></div></div>
	</div>
<?php } ?>
<?php if ($loantypes_add->loanpaymentconfirmationlangid->Visible) { // loanpaymentconfirmationlangid ?>
	<div id="r_loanpaymentconfirmationlangid" class="form-group row">
		<label id="elh_loantypes_loanpaymentconfirmationlangid" for="x_loanpaymentconfirmationlangid" class="<?php echo $loantypes_add->LeftColumnClass ?>"><?php echo $loantypes_add->loanpaymentconfirmationlangid->caption() ?><?php echo $loantypes_add->loanpaymentconfirmationlangid->Required ? $Language->phrase("FieldRequiredIndicator") : "" ?></label>
		<div class="<?php echo $loantypes_add->RightColumnClass ?>"><div <?php echo $loantypes_add->loanpaymentconfirmationlangid->cellAttributes() ?>>
<span id="el_loantypes_loanpaymentconfirmationlangid">
<input type="text" data-table="loantypes" data-field="x_loanpaymentconfirmationlangid" name="x_loanpaymentconfirmationlangid" id="x_loanpaymentconfirmationlangid" size="30" maxlength="12" placeholder="<?php echo HtmlEncode($loantypes_add->loanpaymentconfirmationlangid->getPlaceHolder()) ?>" value="<?php echo $loantypes_add->loanpaymentconfirmationlangid->EditValue ?>"<?php echo $loantypes_add->loanpaymentconfirmationlangid->editAttributes() ?>>
</span>
<?php echo $loantypes_add->loanpaymentconfirmationlangid->CustomMsg ?></div></div>
	</div>
<?php } ?>
<?php if ($loantypes_add->restrictive->Visible) { // restrictive ?>
	<div id="r_restrictive" class="form-group row">
		<label id="elh_loantypes_restrictive" for="x_restrictive" class="<?php echo $loantypes_add->LeftColumnClass ?>"><?php echo $loantypes_add->restrictive->caption() ?><?php echo $loantypes_add->restrictive->Required ? $Language->phrase("FieldRequiredIndicator") : "" ?></label>
		<div class="<?php echo $loantypes_add->RightColumnClass ?>"><div <?php echo $loantypes_add->restrictive->cellAttributes() ?>>
<span id="el_loantypes_restrictive">
<input type="text" data-table="loantypes" data-field="x_restrictive" name="x_restrictive" id="x_restrictive" size="30" maxlength="1" placeholder="<?php echo HtmlEncode($loantypes_add->restrictive->getPlaceHolder()) ?>" value="<?php echo $loantypes_add->restrictive->EditValue ?>"<?php echo $loantypes_add->restrictive->editAttributes() ?>>
</span>
<?php echo $loantypes_add->restrictive->CustomMsg ?></div></div>
	</div>
<?php } ?>
<?php if ($loantypes_add->ignorenextbusinessday->Visible) { // ignorenextbusinessday ?>
	<div id="r_ignorenextbusinessday" class="form-group row">
		<label id="elh_loantypes_ignorenextbusinessday" for="x_ignorenextbusinessday" class="<?php echo $loantypes_add->LeftColumnClass ?>"><?php echo $loantypes_add->ignorenextbusinessday->caption() ?><?php echo $loantypes_add->ignorenextbusinessday->Required ? $Language->phrase("FieldRequiredIndicator") : "" ?></label>
		<div class="<?php echo $loantypes_add->RightColumnClass ?>"><div <?php echo $loantypes_add->ignorenextbusinessday->cellAttributes() ?>>
<span id="el_loantypes_ignorenextbusinessday">
<input type="text" data-table="loantypes" data-field="x_ignorenextbusinessday" name="x_ignorenextbusinessday" id="x_ignorenextbusinessday" size="30" maxlength="1" placeholder="<?php echo HtmlEncode($loantypes_add->ignorenextbusinessday->getPlaceHolder()) ?>" value="<?php echo $loantypes_add->ignorenextbusinessday->EditValue ?>"<?php echo $loantypes_add->ignorenextbusinessday->editAttributes() ?>>
</span>
<?php echo $loantypes_add->ignorenextbusinessday->CustomMsg ?></div></div>
	</div>
<?php } ?>
<?php if ($loantypes_add->maxactiveloans->Visible) { // maxactiveloans ?>
	<div id="r_maxactiveloans" class="form-group row">
		<label id="elh_loantypes_maxactiveloans" for="x_maxactiveloans" class="<?php echo $loantypes_add->LeftColumnClass ?>"><?php echo $loantypes_add->maxactiveloans->caption() ?><?php echo $loantypes_add->maxactiveloans->Required ? $Language->phrase("FieldRequiredIndicator") : "" ?></label>
		<div class="<?php echo $loantypes_add->RightColumnClass ?>"><div <?php echo $loantypes_add->maxactiveloans->cellAttributes() ?>>
<span id="el_loantypes_maxactiveloans">
<input type="text" data-table="loantypes" data-field="x_maxactiveloans" name="x_maxactiveloans" id="x_maxactiveloans" size="30" maxlength="5" placeholder="<?php echo HtmlEncode($loantypes_add->maxactiveloans->getPlaceHolder()) ?>" value="<?php echo $loantypes_add->maxactiveloans->EditValue ?>"<?php echo $loantypes_add->maxactiveloans->editAttributes() ?>>
</span>
<?php echo $loantypes_add->maxactiveloans->CustomMsg ?></div></div>
	</div>
<?php } ?>
<?php if ($loantypes_add->terminterestallocationtype->Visible) { // terminterestallocationtype ?>
	<div id="r_terminterestallocationtype" class="form-group row">
		<label id="elh_loantypes_terminterestallocationtype" for="x_terminterestallocationtype" class="<?php echo $loantypes_add->LeftColumnClass ?>"><?php echo $loantypes_add->terminterestallocationtype->caption() ?><?php echo $loantypes_add->terminterestallocationtype->Required ? $Language->phrase("FieldRequiredIndicator") : "" ?></label>
		<div class="<?php echo $loantypes_add->RightColumnClass ?>"><div <?php echo $loantypes_add->terminterestallocationtype->cellAttributes() ?>>
<span id="el_loantypes_terminterestallocationtype">
<input type="text" data-table="loantypes" data-field="x_terminterestallocationtype" name="x_terminterestallocationtype" id="x_terminterestallocationtype" size="30" maxlength="1" placeholder="<?php echo HtmlEncode($loantypes_add->terminterestallocationtype->getPlaceHolder()) ?>" value="<?php echo $loantypes_add->terminterestallocationtype->EditValue ?>"<?php echo $loantypes_add->terminterestallocationtype->editAttributes() ?>>
</span>
<?php echo $loantypes_add->terminterestallocationtype->CustomMsg ?></div></div>
	</div>
<?php } ?>
</div><!-- /page* -->
<?php if (!$loantypes_add->IsModal) { ?>
<div class="form-group row"><!-- buttons .form-group -->
	<div class="<?php echo $loantypes_add->OffsetColumnClass ?>"><!-- buttons offset -->
<button class="btn btn-primary ew-btn" name="btn-action" id="btn-action" type="submit"><?php echo $Language->phrase("AddBtn") ?></button>
<button class="btn btn-default ew-btn" name="btn-cancel" id="btn-cancel" type="button" data-href="<?php echo $loantypes_add->getReturnUrl() ?>"><?php echo $Language->phrase("CancelBtn") ?></button>
	</div><!-- /buttons offset -->
</div><!-- /buttons .form-group -->
<?php } ?>
</form>
<?php
$loantypes_add->showPageFooter();
if (Config("DEBUG"))
	echo GetDebugMessage();
?>
<script>
loadjs.ready("load", function() {

	// Startup script
	// Write your table-specific startup script here
	// console.log("page loaded");

});
</script>
<?php include_once "footer.php"; ?>
<?php
$loantypes_add->terminate();
?>