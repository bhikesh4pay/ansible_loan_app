<?php
namespace PHPMaker2020\_4payadmin;

// Autoload
include_once "autoload.php";

// Session
if (session_status() !== PHP_SESSION_ACTIVE)
	\Delight\Cookie\Session::start(Config("COOKIE_SAMESITE")); // Init session data

// Output buffering
ob_start();
?>
<?php

// Write header
WriteHeader(FALSE);

// Create page object
$user_add = new user_add();

// Run the page
$user_add->run();

// Setup login status
SetupLoginStatus();
SetClientVar("login", LoginStatus());

// Global Page Rendering event (in userfn*.php)
Page_Rendering();

// Page Rendering event
$user_add->Page_Render();
?>
<?php include_once "header.php"; ?>
<script>
var fuseradd, currentPageID;
loadjs.ready("head", function() {

	// Form object
	currentPageID = ew.PAGE_ID = "add";
	fuseradd = currentForm = new ew.Form("fuseradd", "add");

	// Validate form
	fuseradd.validate = function() {
		if (!this.validateRequired)
			return true; // Ignore validation
		var $ = jQuery, fobj = this.getForm(), $fobj = $(fobj);
		if ($fobj.find("#confirm").val() == "confirm")
			return true;
		var elm, felm, uelm, addcnt = 0;
		var $k = $fobj.find("#" + this.formKeyCountName); // Get key_count
		var rowcnt = ($k[0]) ? parseInt($k.val(), 10) : 1;
		var startcnt = (rowcnt == 0) ? 0 : 1; // Check rowcnt == 0 => Inline-Add
		var gridinsert = ["insert", "gridinsert"].includes($fobj.find("#action").val()) && $k[0];
		for (var i = startcnt; i <= rowcnt; i++) {
			var infix = ($k[0]) ? String(i) : "";
			$fobj.data("rowindex", infix);
			<?php if ($user_add->id->Required) { ?>
				elm = this.getElements("x" + infix + "_id");
				if (elm && !ew.isHidden(elm) && !ew.hasValue(elm))
					return this.onError(elm, "<?php echo JsEncode(str_replace("%s", $user_add->id->caption(), $user_add->id->RequiredErrorMessage)) ?>");
			<?php } ?>
				elm = this.getElements("x" + infix + "_id");
				if (elm && !ew.checkInteger(elm.value))
					return this.onError(elm, "<?php echo JsEncode($user_add->id->errorMessage()) ?>");
			<?php if ($user_add->firstName->Required) { ?>
				elm = this.getElements("x" + infix + "_firstName");
				if (elm && !ew.isHidden(elm) && !ew.hasValue(elm))
					return this.onError(elm, "<?php echo JsEncode(str_replace("%s", $user_add->firstName->caption(), $user_add->firstName->RequiredErrorMessage)) ?>");
			<?php } ?>
			<?php if ($user_add->lastName->Required) { ?>
				elm = this.getElements("x" + infix + "_lastName");
				if (elm && !ew.isHidden(elm) && !ew.hasValue(elm))
					return this.onError(elm, "<?php echo JsEncode(str_replace("%s", $user_add->lastName->caption(), $user_add->lastName->RequiredErrorMessage)) ?>");
			<?php } ?>
			<?php if ($user_add->otherNames->Required) { ?>
				elm = this.getElements("x" + infix + "_otherNames");
				if (elm && !ew.isHidden(elm) && !ew.hasValue(elm))
					return this.onError(elm, "<?php echo JsEncode(str_replace("%s", $user_add->otherNames->caption(), $user_add->otherNames->RequiredErrorMessage)) ?>");
			<?php } ?>
			<?php if ($user_add->passwordRequireChange->Required) { ?>
				elm = this.getElements("x" + infix + "_passwordRequireChange");
				if (elm && !ew.isHidden(elm) && !ew.hasValue(elm))
					return this.onError(elm, "<?php echo JsEncode(str_replace("%s", $user_add->passwordRequireChange->caption(), $user_add->passwordRequireChange->RequiredErrorMessage)) ?>");
			<?php } ?>
			<?php if ($user_add->franchiseeID->Required) { ?>
				elm = this.getElements("x" + infix + "_franchiseeID");
				if (elm && !ew.isHidden(elm) && !ew.hasValue(elm))
					return this.onError(elm, "<?php echo JsEncode(str_replace("%s", $user_add->franchiseeID->caption(), $user_add->franchiseeID->RequiredErrorMessage)) ?>");
			<?php } ?>
				elm = this.getElements("x" + infix + "_franchiseeID");
				if (elm && !ew.checkInteger(elm.value))
					return this.onError(elm, "<?php echo JsEncode($user_add->franchiseeID->errorMessage()) ?>");
			<?php if ($user_add->dateAdded->Required) { ?>
				elm = this.getElements("x" + infix + "_dateAdded");
				if (elm && !ew.isHidden(elm) && !ew.hasValue(elm))
					return this.onError(elm, "<?php echo JsEncode(str_replace("%s", $user_add->dateAdded->caption(), $user_add->dateAdded->RequiredErrorMessage)) ?>");
			<?php } ?>
				elm = this.getElements("x" + infix + "_dateAdded");
				if (elm && !ew.checkDateDef(elm.value))
					return this.onError(elm, "<?php echo JsEncode($user_add->dateAdded->errorMessage()) ?>");
			<?php if ($user_add->timezoneid->Required) { ?>
				elm = this.getElements("x" + infix + "_timezoneid");
				if (elm && !ew.isHidden(elm) && !ew.hasValue(elm))
					return this.onError(elm, "<?php echo JsEncode(str_replace("%s", $user_add->timezoneid->caption(), $user_add->timezoneid->RequiredErrorMessage)) ?>");
			<?php } ?>
			<?php if ($user_add->contactPhoneNo->Required) { ?>
				elm = this.getElements("x" + infix + "_contactPhoneNo");
				if (elm && !ew.isHidden(elm) && !ew.hasValue(elm))
					return this.onError(elm, "<?php echo JsEncode(str_replace("%s", $user_add->contactPhoneNo->caption(), $user_add->contactPhoneNo->RequiredErrorMessage)) ?>");
			<?php } ?>
			<?php if ($user_add->telephoneno->Required) { ?>
				elm = this.getElements("x" + infix + "_telephoneno");
				if (elm && !ew.isHidden(elm) && !ew.hasValue(elm))
					return this.onError(elm, "<?php echo JsEncode(str_replace("%s", $user_add->telephoneno->caption(), $user_add->telephoneno->RequiredErrorMessage)) ?>");
			<?php } ?>
			<?php if ($user_add->telephoneverified->Required) { ?>
				elm = this.getElements("x" + infix + "_telephoneverified");
				if (elm && !ew.isHidden(elm) && !ew.hasValue(elm))
					return this.onError(elm, "<?php echo JsEncode(str_replace("%s", $user_add->telephoneverified->caption(), $user_add->telephoneverified->RequiredErrorMessage)) ?>");
			<?php } ?>
			<?php if ($user_add->telephonereceivemessage->Required) { ?>
				elm = this.getElements("x" + infix + "_telephonereceivemessage");
				if (elm && !ew.isHidden(elm) && !ew.hasValue(elm))
					return this.onError(elm, "<?php echo JsEncode(str_replace("%s", $user_add->telephonereceivemessage->caption(), $user_add->telephonereceivemessage->RequiredErrorMessage)) ?>");
			<?php } ?>
			<?php if ($user_add->verification1->Required) { ?>
				elm = this.getElements("x" + infix + "_verification1");
				if (elm && !ew.isHidden(elm) && !ew.hasValue(elm))
					return this.onError(elm, "<?php echo JsEncode(str_replace("%s", $user_add->verification1->caption(), $user_add->verification1->RequiredErrorMessage)) ?>");
			<?php } ?>
			<?php if ($user_add->verification2->Required) { ?>
				elm = this.getElements("x" + infix + "_verification2");
				if (elm && !ew.isHidden(elm) && !ew.hasValue(elm))
					return this.onError(elm, "<?php echo JsEncode(str_replace("%s", $user_add->verification2->caption(), $user_add->verification2->RequiredErrorMessage)) ?>");
			<?php } ?>
			<?php if ($user_add->verification3->Required) { ?>
				elm = this.getElements("x" + infix + "_verification3");
				if (elm && !ew.isHidden(elm) && !ew.hasValue(elm))
					return this.onError(elm, "<?php echo JsEncode(str_replace("%s", $user_add->verification3->caption(), $user_add->verification3->RequiredErrorMessage)) ?>");
			<?php } ?>
			<?php if ($user_add->address1->Required) { ?>
				elm = this.getElements("x" + infix + "_address1");
				if (elm && !ew.isHidden(elm) && !ew.hasValue(elm))
					return this.onError(elm, "<?php echo JsEncode(str_replace("%s", $user_add->address1->caption(), $user_add->address1->RequiredErrorMessage)) ?>");
			<?php } ?>
			<?php if ($user_add->address2->Required) { ?>
				elm = this.getElements("x" + infix + "_address2");
				if (elm && !ew.isHidden(elm) && !ew.hasValue(elm))
					return this.onError(elm, "<?php echo JsEncode(str_replace("%s", $user_add->address2->caption(), $user_add->address2->RequiredErrorMessage)) ?>");
			<?php } ?>
			<?php if ($user_add->cityname->Required) { ?>
				elm = this.getElements("x" + infix + "_cityname");
				if (elm && !ew.isHidden(elm) && !ew.hasValue(elm))
					return this.onError(elm, "<?php echo JsEncode(str_replace("%s", $user_add->cityname->caption(), $user_add->cityname->RequiredErrorMessage)) ?>");
			<?php } ?>
			<?php if ($user_add->countryid->Required) { ?>
				elm = this.getElements("x" + infix + "_countryid");
				if (elm && !ew.isHidden(elm) && !ew.hasValue(elm))
					return this.onError(elm, "<?php echo JsEncode(str_replace("%s", $user_add->countryid->caption(), $user_add->countryid->RequiredErrorMessage)) ?>");
			<?php } ?>
			<?php if ($user_add->stateid->Required) { ?>
				elm = this.getElements("x" + infix + "_stateid");
				if (elm && !ew.isHidden(elm) && !ew.hasValue(elm))
					return this.onError(elm, "<?php echo JsEncode(str_replace("%s", $user_add->stateid->caption(), $user_add->stateid->RequiredErrorMessage)) ?>");
			<?php } ?>
			<?php if ($user_add->defaultcurrency->Required) { ?>
				elm = this.getElements("x" + infix + "_defaultcurrency");
				if (elm && !ew.isHidden(elm) && !ew.hasValue(elm))
					return this.onError(elm, "<?php echo JsEncode(str_replace("%s", $user_add->defaultcurrency->caption(), $user_add->defaultcurrency->RequiredErrorMessage)) ?>");
			<?php } ?>
			<?php if ($user_add->challengeq1->Required) { ?>
				elm = this.getElements("x" + infix + "_challengeq1");
				if (elm && !ew.isHidden(elm) && !ew.hasValue(elm))
					return this.onError(elm, "<?php echo JsEncode(str_replace("%s", $user_add->challengeq1->caption(), $user_add->challengeq1->RequiredErrorMessage)) ?>");
			<?php } ?>
				elm = this.getElements("x" + infix + "_challengeq1");
				if (elm && !ew.checkInteger(elm.value))
					return this.onError(elm, "<?php echo JsEncode($user_add->challengeq1->errorMessage()) ?>");
			<?php if ($user_add->challengea1->Required) { ?>
				elm = this.getElements("x" + infix + "_challengea1");
				if (elm && !ew.isHidden(elm) && !ew.hasValue(elm))
					return this.onError(elm, "<?php echo JsEncode(str_replace("%s", $user_add->challengea1->caption(), $user_add->challengea1->RequiredErrorMessage)) ?>");
			<?php } ?>
			<?php if ($user_add->challengeq2->Required) { ?>
				elm = this.getElements("x" + infix + "_challengeq2");
				if (elm && !ew.isHidden(elm) && !ew.hasValue(elm))
					return this.onError(elm, "<?php echo JsEncode(str_replace("%s", $user_add->challengeq2->caption(), $user_add->challengeq2->RequiredErrorMessage)) ?>");
			<?php } ?>
				elm = this.getElements("x" + infix + "_challengeq2");
				if (elm && !ew.checkInteger(elm.value))
					return this.onError(elm, "<?php echo JsEncode($user_add->challengeq2->errorMessage()) ?>");
			<?php if ($user_add->challengea2->Required) { ?>
				elm = this.getElements("x" + infix + "_challengea2");
				if (elm && !ew.isHidden(elm) && !ew.hasValue(elm))
					return this.onError(elm, "<?php echo JsEncode(str_replace("%s", $user_add->challengea2->caption(), $user_add->challengea2->RequiredErrorMessage)) ?>");
			<?php } ?>
			<?php if ($user_add->challengeq3->Required) { ?>
				elm = this.getElements("x" + infix + "_challengeq3");
				if (elm && !ew.isHidden(elm) && !ew.hasValue(elm))
					return this.onError(elm, "<?php echo JsEncode(str_replace("%s", $user_add->challengeq3->caption(), $user_add->challengeq3->RequiredErrorMessage)) ?>");
			<?php } ?>
				elm = this.getElements("x" + infix + "_challengeq3");
				if (elm && !ew.checkInteger(elm.value))
					return this.onError(elm, "<?php echo JsEncode($user_add->challengeq3->errorMessage()) ?>");
			<?php if ($user_add->challengea3->Required) { ?>
				elm = this.getElements("x" + infix + "_challengea3");
				if (elm && !ew.isHidden(elm) && !ew.hasValue(elm))
					return this.onError(elm, "<?php echo JsEncode(str_replace("%s", $user_add->challengea3->caption(), $user_add->challengea3->RequiredErrorMessage)) ?>");
			<?php } ?>
			<?php if ($user_add->passwordCounter->Required) { ?>
				elm = this.getElements("x" + infix + "_passwordCounter");
				if (elm && !ew.isHidden(elm) && !ew.hasValue(elm))
					return this.onError(elm, "<?php echo JsEncode(str_replace("%s", $user_add->passwordCounter->caption(), $user_add->passwordCounter->RequiredErrorMessage)) ?>");
			<?php } ?>
				elm = this.getElements("x" + infix + "_passwordCounter");
				if (elm && !ew.checkInteger(elm.value))
					return this.onError(elm, "<?php echo JsEncode($user_add->passwordCounter->errorMessage()) ?>");
			<?php if ($user_add->passwordChangedDate->Required) { ?>
				elm = this.getElements("x" + infix + "_passwordChangedDate");
				if (elm && !ew.isHidden(elm) && !ew.hasValue(elm))
					return this.onError(elm, "<?php echo JsEncode(str_replace("%s", $user_add->passwordChangedDate->caption(), $user_add->passwordChangedDate->RequiredErrorMessage)) ?>");
			<?php } ?>
				elm = this.getElements("x" + infix + "_passwordChangedDate");
				if (elm && !ew.checkDateDef(elm.value))
					return this.onError(elm, "<?php echo JsEncode($user_add->passwordChangedDate->errorMessage()) ?>");
			<?php if ($user_add->pinCounter->Required) { ?>
				elm = this.getElements("x" + infix + "_pinCounter");
				if (elm && !ew.isHidden(elm) && !ew.hasValue(elm))
					return this.onError(elm, "<?php echo JsEncode(str_replace("%s", $user_add->pinCounter->caption(), $user_add->pinCounter->RequiredErrorMessage)) ?>");
			<?php } ?>
				elm = this.getElements("x" + infix + "_pinCounter");
				if (elm && !ew.checkInteger(elm.value))
					return this.onError(elm, "<?php echo JsEncode($user_add->pinCounter->errorMessage()) ?>");
			<?php if ($user_add->langID->Required) { ?>
				elm = this.getElements("x" + infix + "_langID");
				if (elm && !ew.isHidden(elm) && !ew.hasValue(elm))
					return this.onError(elm, "<?php echo JsEncode(str_replace("%s", $user_add->langID->caption(), $user_add->langID->RequiredErrorMessage)) ?>");
			<?php } ?>
			<?php if ($user_add->photo->Required) { ?>
				felm = this.getElements("x" + infix + "_photo");
				elm = this.getElements("fn_x" + infix + "_photo");
				if (felm && elm && !ew.hasValue(elm))
					return this.onError(felm, "<?php echo JsEncode(str_replace("%s", $user_add->photo->caption(), $user_add->photo->RequiredErrorMessage)) ?>");
			<?php } ?>
			<?php if ($user_add->status->Required) { ?>
				elm = this.getElements("x" + infix + "_status");
				if (elm && !ew.isHidden(elm) && !ew.hasValue(elm))
					return this.onError(elm, "<?php echo JsEncode(str_replace("%s", $user_add->status->caption(), $user_add->status->RequiredErrorMessage)) ?>");
			<?php } ?>
			<?php if ($user_add->markedfordeletion->Required) { ?>
				elm = this.getElements("x" + infix + "_markedfordeletion");
				if (elm && !ew.isHidden(elm) && !ew.hasValue(elm))
					return this.onError(elm, "<?php echo JsEncode(str_replace("%s", $user_add->markedfordeletion->caption(), $user_add->markedfordeletion->RequiredErrorMessage)) ?>");
			<?php } ?>
				elm = this.getElements("x" + infix + "_markedfordeletion");
				if (elm && !ew.checkDateDef(elm.value))
					return this.onError(elm, "<?php echo JsEncode($user_add->markedfordeletion->errorMessage()) ?>");
			<?php if ($user_add->userType->Required) { ?>
				elm = this.getElements("x" + infix + "_userType");
				if (elm && !ew.isHidden(elm) && !ew.hasValue(elm))
					return this.onError(elm, "<?php echo JsEncode(str_replace("%s", $user_add->userType->caption(), $user_add->userType->RequiredErrorMessage)) ?>");
			<?php } ?>
			<?php if ($user_add->usersubtype->Required) { ?>
				elm = this.getElements("x" + infix + "_usersubtype");
				if (elm && !ew.isHidden(elm) && !ew.hasValue(elm))
					return this.onError(elm, "<?php echo JsEncode(str_replace("%s", $user_add->usersubtype->caption(), $user_add->usersubtype->RequiredErrorMessage)) ?>");
			<?php } ?>
			<?php if ($user_add->accountID->Required) { ?>
				elm = this.getElements("x" + infix + "_accountID");
				if (elm && !ew.isHidden(elm) && !ew.hasValue(elm))
					return this.onError(elm, "<?php echo JsEncode(str_replace("%s", $user_add->accountID->caption(), $user_add->accountID->RequiredErrorMessage)) ?>");
			<?php } ?>
				elm = this.getElements("x" + infix + "_accountID");
				if (elm && !ew.checkInteger(elm.value))
					return this.onError(elm, "<?php echo JsEncode($user_add->accountID->errorMessage()) ?>");
			<?php if ($user_add->brokerid->Required) { ?>
				elm = this.getElements("x" + infix + "_brokerid");
				if (elm && !ew.isHidden(elm) && !ew.hasValue(elm))
					return this.onError(elm, "<?php echo JsEncode(str_replace("%s", $user_add->brokerid->caption(), $user_add->brokerid->RequiredErrorMessage)) ?>");
			<?php } ?>
				elm = this.getElements("x" + infix + "_brokerid");
				if (elm && !ew.checkInteger(elm.value))
					return this.onError(elm, "<?php echo JsEncode($user_add->brokerid->errorMessage()) ?>");
			<?php if ($user_add->parentuserid->Required) { ?>
				elm = this.getElements("x" + infix + "_parentuserid");
				if (elm && !ew.isHidden(elm) && !ew.hasValue(elm))
					return this.onError(elm, "<?php echo JsEncode(str_replace("%s", $user_add->parentuserid->caption(), $user_add->parentuserid->RequiredErrorMessage)) ?>");
			<?php } ?>
				elm = this.getElements("x" + infix + "_parentuserid");
				if (elm && !ew.checkInteger(elm.value))
					return this.onError(elm, "<?php echo JsEncode($user_add->parentuserid->errorMessage()) ?>");
			<?php if ($user_add->corporate->Required) { ?>
				elm = this.getElements("x" + infix + "_corporate");
				if (elm && !ew.isHidden(elm) && !ew.hasValue(elm))
					return this.onError(elm, "<?php echo JsEncode(str_replace("%s", $user_add->corporate->caption(), $user_add->corporate->RequiredErrorMessage)) ?>");
			<?php } ?>
			<?php if ($user_add->profilestatus->Required) { ?>
				elm = this.getElements("x" + infix + "_profilestatus");
				if (elm && !ew.isHidden(elm) && !ew.hasValue(elm))
					return this.onError(elm, "<?php echo JsEncode(str_replace("%s", $user_add->profilestatus->caption(), $user_add->profilestatus->RequiredErrorMessage)) ?>");
			<?php } ?>
			<?php if ($user_add->jumpappid->Required) { ?>
				elm = this.getElements("x" + infix + "_jumpappid");
				if (elm && !ew.isHidden(elm) && !ew.hasValue(elm))
					return this.onError(elm, "<?php echo JsEncode(str_replace("%s", $user_add->jumpappid->caption(), $user_add->jumpappid->RequiredErrorMessage)) ?>");
			<?php } ?>
				elm = this.getElements("x" + infix + "_jumpappid");
				if (elm && !ew.checkInteger(elm.value))
					return this.onError(elm, "<?php echo JsEncode($user_add->jumpappid->errorMessage()) ?>");
			<?php if ($user_add->dateofbirth->Required) { ?>
				elm = this.getElements("x" + infix + "_dateofbirth");
				if (elm && !ew.isHidden(elm) && !ew.hasValue(elm))
					return this.onError(elm, "<?php echo JsEncode(str_replace("%s", $user_add->dateofbirth->caption(), $user_add->dateofbirth->RequiredErrorMessage)) ?>");
			<?php } ?>
				elm = this.getElements("x" + infix + "_dateofbirth");
				if (elm && !ew.checkDateDef(elm.value))
					return this.onError(elm, "<?php echo JsEncode($user_add->dateofbirth->errorMessage()) ?>");
			<?php if ($user_add->gender->Required) { ?>
				elm = this.getElements("x" + infix + "_gender");
				if (elm && !ew.isHidden(elm) && !ew.hasValue(elm))
					return this.onError(elm, "<?php echo JsEncode(str_replace("%s", $user_add->gender->caption(), $user_add->gender->RequiredErrorMessage)) ?>");
			<?php } ?>
			<?php if ($user_add->jumprequiredatlogin->Required) { ?>
				elm = this.getElements("x" + infix + "_jumprequiredatlogin");
				if (elm && !ew.isHidden(elm) && !ew.hasValue(elm))
					return this.onError(elm, "<?php echo JsEncode(str_replace("%s", $user_add->jumprequiredatlogin->caption(), $user_add->jumprequiredatlogin->RequiredErrorMessage)) ?>");
			<?php } ?>
			<?php if ($user_add->ccbypass->Required) { ?>
				elm = this.getElements("x" + infix + "_ccbypass");
				if (elm && !ew.isHidden(elm) && !ew.hasValue(elm))
					return this.onError(elm, "<?php echo JsEncode(str_replace("%s", $user_add->ccbypass->caption(), $user_add->ccbypass->RequiredErrorMessage)) ?>");
			<?php } ?>
			<?php if ($user_add->zip->Required) { ?>
				elm = this.getElements("x" + infix + "_zip");
				if (elm && !ew.isHidden(elm) && !ew.hasValue(elm))
					return this.onError(elm, "<?php echo JsEncode(str_replace("%s", $user_add->zip->caption(), $user_add->zip->RequiredErrorMessage)) ?>");
			<?php } ?>
			<?php if ($user_add->other1->Required) { ?>
				elm = this.getElements("x" + infix + "_other1");
				if (elm && !ew.isHidden(elm) && !ew.hasValue(elm))
					return this.onError(elm, "<?php echo JsEncode(str_replace("%s", $user_add->other1->caption(), $user_add->other1->RequiredErrorMessage)) ?>");
			<?php } ?>
			<?php if ($user_add->other2->Required) { ?>
				elm = this.getElements("x" + infix + "_other2");
				if (elm && !ew.isHidden(elm) && !ew.hasValue(elm))
					return this.onError(elm, "<?php echo JsEncode(str_replace("%s", $user_add->other2->caption(), $user_add->other2->RequiredErrorMessage)) ?>");
			<?php } ?>
			<?php if ($user_add->other3->Required) { ?>
				elm = this.getElements("x" + infix + "_other3");
				if (elm && !ew.isHidden(elm) && !ew.hasValue(elm))
					return this.onError(elm, "<?php echo JsEncode(str_replace("%s", $user_add->other3->caption(), $user_add->other3->RequiredErrorMessage)) ?>");
			<?php } ?>
			<?php if ($user_add->other4->Required) { ?>
				elm = this.getElements("x" + infix + "_other4");
				if (elm && !ew.isHidden(elm) && !ew.hasValue(elm))
					return this.onError(elm, "<?php echo JsEncode(str_replace("%s", $user_add->other4->caption(), $user_add->other4->RequiredErrorMessage)) ?>");
			<?php } ?>
			<?php if ($user_add->other5->Required) { ?>
				elm = this.getElements("x" + infix + "_other5");
				if (elm && !ew.isHidden(elm) && !ew.hasValue(elm))
					return this.onError(elm, "<?php echo JsEncode(str_replace("%s", $user_add->other5->caption(), $user_add->other5->RequiredErrorMessage)) ?>");
			<?php } ?>
			<?php if ($user_add->other6->Required) { ?>
				elm = this.getElements("x" + infix + "_other6");
				if (elm && !ew.isHidden(elm) && !ew.hasValue(elm))
					return this.onError(elm, "<?php echo JsEncode(str_replace("%s", $user_add->other6->caption(), $user_add->other6->RequiredErrorMessage)) ?>");
			<?php } ?>
			<?php if ($user_add->mincashamount->Required) { ?>
				elm = this.getElements("x" + infix + "_mincashamount");
				if (elm && !ew.isHidden(elm) && !ew.hasValue(elm))
					return this.onError(elm, "<?php echo JsEncode(str_replace("%s", $user_add->mincashamount->caption(), $user_add->mincashamount->RequiredErrorMessage)) ?>");
			<?php } ?>
				elm = this.getElements("x" + infix + "_mincashamount");
				if (elm && !ew.checkNumber(elm.value))
					return this.onError(elm, "<?php echo JsEncode($user_add->mincashamount->errorMessage()) ?>");
			<?php if ($user_add->maxcashamount->Required) { ?>
				elm = this.getElements("x" + infix + "_maxcashamount");
				if (elm && !ew.isHidden(elm) && !ew.hasValue(elm))
					return this.onError(elm, "<?php echo JsEncode(str_replace("%s", $user_add->maxcashamount->caption(), $user_add->maxcashamount->RequiredErrorMessage)) ?>");
			<?php } ?>
				elm = this.getElements("x" + infix + "_maxcashamount");
				if (elm && !ew.checkNumber(elm.value))
					return this.onError(elm, "<?php echo JsEncode($user_add->maxcashamount->errorMessage()) ?>");
			<?php if ($user_add->maxtransferinamount->Required) { ?>
				elm = this.getElements("x" + infix + "_maxtransferinamount");
				if (elm && !ew.isHidden(elm) && !ew.hasValue(elm))
					return this.onError(elm, "<?php echo JsEncode(str_replace("%s", $user_add->maxtransferinamount->caption(), $user_add->maxtransferinamount->RequiredErrorMessage)) ?>");
			<?php } ?>
				elm = this.getElements("x" + infix + "_maxtransferinamount");
				if (elm && !ew.checkNumber(elm.value))
					return this.onError(elm, "<?php echo JsEncode($user_add->maxtransferinamount->errorMessage()) ?>");
			<?php if ($user_add->maxtransferoutamount->Required) { ?>
				elm = this.getElements("x" + infix + "_maxtransferoutamount");
				if (elm && !ew.isHidden(elm) && !ew.hasValue(elm))
					return this.onError(elm, "<?php echo JsEncode(str_replace("%s", $user_add->maxtransferoutamount->caption(), $user_add->maxtransferoutamount->RequiredErrorMessage)) ?>");
			<?php } ?>
				elm = this.getElements("x" + infix + "_maxtransferoutamount");
				if (elm && !ew.checkNumber(elm.value))
					return this.onError(elm, "<?php echo JsEncode($user_add->maxtransferoutamount->errorMessage()) ?>");
			<?php if ($user_add->legalid->Required) { ?>
				elm = this.getElements("x" + infix + "_legalid");
				if (elm && !ew.isHidden(elm) && !ew.hasValue(elm))
					return this.onError(elm, "<?php echo JsEncode(str_replace("%s", $user_add->legalid->caption(), $user_add->legalid->RequiredErrorMessage)) ?>");
			<?php } ?>
				elm = this.getElements("x" + infix + "_legalid");
				if (elm && !ew.checkInteger(elm.value))
					return this.onError(elm, "<?php echo JsEncode($user_add->legalid->errorMessage()) ?>");
			<?php if ($user_add->userpiview->Required) { ?>
				elm = this.getElements("x" + infix + "_userpiview");
				if (elm && !ew.isHidden(elm) && !ew.hasValue(elm))
					return this.onError(elm, "<?php echo JsEncode(str_replace("%s", $user_add->userpiview->caption(), $user_add->userpiview->RequiredErrorMessage)) ?>");
			<?php } ?>
			<?php if ($user_add->lastmsgid->Required) { ?>
				elm = this.getElements("x" + infix + "_lastmsgid");
				if (elm && !ew.isHidden(elm) && !ew.hasValue(elm))
					return this.onError(elm, "<?php echo JsEncode(str_replace("%s", $user_add->lastmsgid->caption(), $user_add->lastmsgid->RequiredErrorMessage)) ?>");
			<?php } ?>
				elm = this.getElements("x" + infix + "_lastmsgid");
				if (elm && !ew.checkInteger(elm.value))
					return this.onError(elm, "<?php echo JsEncode($user_add->lastmsgid->errorMessage()) ?>");
			<?php if ($user_add->otprequiredforphysicalcards->Required) { ?>
				elm = this.getElements("x" + infix + "_otprequiredforphysicalcards");
				if (elm && !ew.isHidden(elm) && !ew.hasValue(elm))
					return this.onError(elm, "<?php echo JsEncode(str_replace("%s", $user_add->otprequiredforphysicalcards->caption(), $user_add->otprequiredforphysicalcards->RequiredErrorMessage)) ?>");
			<?php } ?>
				elm = this.getElements("x" + infix + "_otprequiredforphysicalcards");
				if (elm && !ew.checkInteger(elm.value))
					return this.onError(elm, "<?php echo JsEncode($user_add->otprequiredforphysicalcards->errorMessage()) ?>");
			<?php if ($user_add->otpvaliduntil->Required) { ?>
				elm = this.getElements("x" + infix + "_otpvaliduntil");
				if (elm && !ew.isHidden(elm) && !ew.hasValue(elm))
					return this.onError(elm, "<?php echo JsEncode(str_replace("%s", $user_add->otpvaliduntil->caption(), $user_add->otpvaliduntil->RequiredErrorMessage)) ?>");
			<?php } ?>
				elm = this.getElements("x" + infix + "_otpvaliduntil");
				if (elm && !ew.checkDateDef(elm.value))
					return this.onError(elm, "<?php echo JsEncode($user_add->otpvaliduntil->errorMessage()) ?>");
			<?php if ($user_add->nationalitycountry->Required) { ?>
				elm = this.getElements("x" + infix + "_nationalitycountry");
				if (elm && !ew.isHidden(elm) && !ew.hasValue(elm))
					return this.onError(elm, "<?php echo JsEncode(str_replace("%s", $user_add->nationalitycountry->caption(), $user_add->nationalitycountry->RequiredErrorMessage)) ?>");
			<?php } ?>
			<?php if ($user_add->classification->Required) { ?>
				elm = this.getElements("x" + infix + "_classification");
				if (elm && !ew.isHidden(elm) && !ew.hasValue(elm))
					return this.onError(elm, "<?php echo JsEncode(str_replace("%s", $user_add->classification->caption(), $user_add->classification->RequiredErrorMessage)) ?>");
			<?php } ?>
			<?php if ($user_add->occupation->Required) { ?>
				elm = this.getElements("x" + infix + "_occupation");
				if (elm && !ew.isHidden(elm) && !ew.hasValue(elm))
					return this.onError(elm, "<?php echo JsEncode(str_replace("%s", $user_add->occupation->caption(), $user_add->occupation->RequiredErrorMessage)) ?>");
			<?php } ?>
			<?php if ($user_add->sourceofincome->Required) { ?>
				elm = this.getElements("x" + infix + "_sourceofincome");
				if (elm && !ew.isHidden(elm) && !ew.hasValue(elm))
					return this.onError(elm, "<?php echo JsEncode(str_replace("%s", $user_add->sourceofincome->caption(), $user_add->sourceofincome->RequiredErrorMessage)) ?>");
			<?php } ?>
			<?php if ($user_add->accountopeningdate->Required) { ?>
				elm = this.getElements("x" + infix + "_accountopeningdate");
				if (elm && !ew.isHidden(elm) && !ew.hasValue(elm))
					return this.onError(elm, "<?php echo JsEncode(str_replace("%s", $user_add->accountopeningdate->caption(), $user_add->accountopeningdate->RequiredErrorMessage)) ?>");
			<?php } ?>
				elm = this.getElements("x" + infix + "_accountopeningdate");
				if (elm && !ew.checkDateDef(elm.value))
					return this.onError(elm, "<?php echo JsEncode($user_add->accountopeningdate->errorMessage()) ?>");
			<?php if ($user_add->extendedfields->Required) { ?>
				elm = this.getElements("x" + infix + "_extendedfields");
				if (elm && !ew.isHidden(elm) && !ew.hasValue(elm))
					return this.onError(elm, "<?php echo JsEncode(str_replace("%s", $user_add->extendedfields->caption(), $user_add->extendedfields->RequiredErrorMessage)) ?>");
			<?php } ?>
			<?php if ($user_add->lastprofilestatuschangedate->Required) { ?>
				elm = this.getElements("x" + infix + "_lastprofilestatuschangedate");
				if (elm && !ew.isHidden(elm) && !ew.hasValue(elm))
					return this.onError(elm, "<?php echo JsEncode(str_replace("%s", $user_add->lastprofilestatuschangedate->caption(), $user_add->lastprofilestatuschangedate->RequiredErrorMessage)) ?>");
			<?php } ?>
				elm = this.getElements("x" + infix + "_lastprofilestatuschangedate");
				if (elm && !ew.checkDateDef(elm.value))
					return this.onError(elm, "<?php echo JsEncode($user_add->lastprofilestatuschangedate->errorMessage()) ?>");

				// Call Form_CustomValidate event
				if (!this.Form_CustomValidate(fobj))
					return false;
		}

		// Process detail forms
		var dfs = $fobj.find("input[name='detailpage']").get();
		for (var i = 0; i < dfs.length; i++) {
			var df = dfs[i], val = df.value;
			if (val && ew.forms[val])
				if (!ew.forms[val].validate())
					return false;
		}
		return true;
	}

	// Form_CustomValidate
	fuseradd.Form_CustomValidate = function(fobj) { // DO NOT CHANGE THIS LINE!

		// Your custom validation code here, return false if invalid.
		return true;
	}

	// Use JavaScript validation or not
	fuseradd.validateRequired = <?php echo Config("CLIENT_VALIDATE") ? "true" : "false" ?>;

	// Multi-Page
	fuseradd.multiPage = new ew.MultiPage("fuseradd");

	// Dynamic selection lists
	fuseradd.lists["x_passwordRequireChange"] = <?php echo $user_add->passwordRequireChange->Lookup->toClientList($user_add) ?>;
	fuseradd.lists["x_passwordRequireChange"].options = <?php echo JsonEncode($user_add->passwordRequireChange->lookupOptions()) ?>;
	fuseradd.lists["x_timezoneid"] = <?php echo $user_add->timezoneid->Lookup->toClientList($user_add) ?>;
	fuseradd.lists["x_timezoneid"].options = <?php echo JsonEncode($user_add->timezoneid->lookupOptions()) ?>;
	fuseradd.lists["x_telephoneverified"] = <?php echo $user_add->telephoneverified->Lookup->toClientList($user_add) ?>;
	fuseradd.lists["x_telephoneverified"].options = <?php echo JsonEncode($user_add->telephoneverified->lookupOptions()) ?>;
	fuseradd.lists["x_telephonereceivemessage"] = <?php echo $user_add->telephonereceivemessage->Lookup->toClientList($user_add) ?>;
	fuseradd.lists["x_telephonereceivemessage"].options = <?php echo JsonEncode($user_add->telephonereceivemessage->lookupOptions()) ?>;
	fuseradd.lists["x_countryid"] = <?php echo $user_add->countryid->Lookup->toClientList($user_add) ?>;
	fuseradd.lists["x_countryid"].options = <?php echo JsonEncode($user_add->countryid->lookupOptions()) ?>;
	fuseradd.lists["x_stateid"] = <?php echo $user_add->stateid->Lookup->toClientList($user_add) ?>;
	fuseradd.lists["x_stateid"].options = <?php echo JsonEncode($user_add->stateid->lookupOptions()) ?>;
	fuseradd.lists["x_defaultcurrency"] = <?php echo $user_add->defaultcurrency->Lookup->toClientList($user_add) ?>;
	fuseradd.lists["x_defaultcurrency"].options = <?php echo JsonEncode($user_add->defaultcurrency->lookupOptions()) ?>;
	fuseradd.lists["x_langID"] = <?php echo $user_add->langID->Lookup->toClientList($user_add) ?>;
	fuseradd.lists["x_langID"].options = <?php echo JsonEncode($user_add->langID->lookupOptions()) ?>;
	fuseradd.lists["x_status"] = <?php echo $user_add->status->Lookup->toClientList($user_add) ?>;
	fuseradd.lists["x_status"].options = <?php echo JsonEncode($user_add->status->lookupOptions()) ?>;
	fuseradd.lists["x_userType"] = <?php echo $user_add->userType->Lookup->toClientList($user_add) ?>;
	fuseradd.lists["x_userType"].options = <?php echo JsonEncode($user_add->userType->lookupOptions()) ?>;
	fuseradd.lists["x_usersubtype"] = <?php echo $user_add->usersubtype->Lookup->toClientList($user_add) ?>;
	fuseradd.lists["x_usersubtype"].options = <?php echo JsonEncode($user_add->usersubtype->lookupOptions()) ?>;
	fuseradd.lists["x_corporate"] = <?php echo $user_add->corporate->Lookup->toClientList($user_add) ?>;
	fuseradd.lists["x_corporate"].options = <?php echo JsonEncode($user_add->corporate->lookupOptions()) ?>;
	fuseradd.lists["x_profilestatus"] = <?php echo $user_add->profilestatus->Lookup->toClientList($user_add) ?>;
	fuseradd.lists["x_profilestatus"].options = <?php echo JsonEncode($user_add->profilestatus->lookupOptions()) ?>;
	fuseradd.lists["x_gender"] = <?php echo $user_add->gender->Lookup->toClientList($user_add) ?>;
	fuseradd.lists["x_gender"].options = <?php echo JsonEncode($user_add->gender->lookupOptions()) ?>;
	fuseradd.lists["x_jumprequiredatlogin"] = <?php echo $user_add->jumprequiredatlogin->Lookup->toClientList($user_add) ?>;
	fuseradd.lists["x_jumprequiredatlogin"].options = <?php echo JsonEncode($user_add->jumprequiredatlogin->lookupOptions()) ?>;
	fuseradd.lists["x_ccbypass"] = <?php echo $user_add->ccbypass->Lookup->toClientList($user_add) ?>;
	fuseradd.lists["x_ccbypass"].options = <?php echo JsonEncode($user_add->ccbypass->lookupOptions()) ?>;
	fuseradd.lists["x_userpiview"] = <?php echo $user_add->userpiview->Lookup->toClientList($user_add) ?>;
	fuseradd.lists["x_userpiview"].options = <?php echo JsonEncode($user_add->userpiview->lookupOptions()) ?>;
	fuseradd.lists["x_nationalitycountry"] = <?php echo $user_add->nationalitycountry->Lookup->toClientList($user_add) ?>;
	fuseradd.lists["x_nationalitycountry"].options = <?php echo JsonEncode($user_add->nationalitycountry->lookupOptions()) ?>;
	fuseradd.lists["x_classification"] = <?php echo $user_add->classification->Lookup->toClientList($user_add) ?>;
	fuseradd.lists["x_classification"].options = <?php echo JsonEncode($user_add->classification->lookupOptions()) ?>;
	fuseradd.lists["x_occupation"] = <?php echo $user_add->occupation->Lookup->toClientList($user_add) ?>;
	fuseradd.lists["x_occupation"].options = <?php echo JsonEncode($user_add->occupation->lookupOptions()) ?>;
	fuseradd.autoSuggests["x_occupation"] = <?php echo json_encode(["data" => "ajax=autosuggest"]) ?>;
	fuseradd.lists["x_sourceofincome"] = <?php echo $user_add->sourceofincome->Lookup->toClientList($user_add) ?>;
	fuseradd.lists["x_sourceofincome"].options = <?php echo JsonEncode($user_add->sourceofincome->lookupOptions()) ?>;
	loadjs.done("fuseradd");
});
</script>
<script>
loadjs.ready("head", function() {

	// Client script
	// Write your client script here, no need to add script tags.

});
</script>
<?php $user_add->showPageHeader(); ?>
<?php
$user_add->showMessage();
?>
<form name="fuseradd" id="fuseradd" class="<?php echo $user_add->FormClassName ?>" action="<?php echo CurrentPageName() ?>" method="post">
<?php if ($Page->CheckToken) { ?>
<input type="hidden" name="<?php echo Config("TOKEN_NAME") ?>" value="<?php echo $Page->Token ?>">
<?php } ?>
<input type="hidden" name="t" value="user">
<input type="hidden" name="action" id="action" value="insert">
<input type="hidden" name="modal" value="<?php echo (int)$user_add->IsModal ?>">
<div class="ew-multi-page"><!-- multi-page -->
<div class="ew-nav-tabs" id="user_add"><!-- multi-page tabs -->
	<ul class="<?php echo $user_add->MultiPages->navStyle() ?>">
		<li class="nav-item"><a class="nav-link<?php echo $user_add->MultiPages->pageStyle(1) ?>" href="#tab_user1" data-toggle="tab"><?php echo $user->pageCaption(1) ?></a></li>
		<li class="nav-item"><a class="nav-link<?php echo $user_add->MultiPages->pageStyle(2) ?>" href="#tab_user2" data-toggle="tab"><?php echo $user->pageCaption(2) ?></a></li>
		<li class="nav-item"><a class="nav-link<?php echo $user_add->MultiPages->pageStyle(3) ?>" href="#tab_user3" data-toggle="tab"><?php echo $user->pageCaption(3) ?></a></li>
		<li class="nav-item"><a class="nav-link<?php echo $user_add->MultiPages->pageStyle(4) ?>" href="#tab_user4" data-toggle="tab"><?php echo $user->pageCaption(4) ?></a></li>
	</ul>
	<div class="tab-content"><!-- multi-page tabs .tab-content -->
		<div class="tab-pane<?php echo $user_add->MultiPages->pageStyle(1) ?>" id="tab_user1"><!-- multi-page .tab-pane -->
<div class="ew-add-div"><!-- page* -->
<?php if ($user_add->id->Visible) { // id ?>
	<div id="r_id" class="form-group row">
		<label id="elh_user_id" for="x_id" class="<?php echo $user_add->LeftColumnClass ?>"><?php echo $user_add->id->caption() ?><?php echo $user_add->id->Required ? $Language->phrase("FieldRequiredIndicator") : "" ?></label>
		<div class="<?php echo $user_add->RightColumnClass ?>"><div <?php echo $user_add->id->cellAttributes() ?>>
<span id="el_user_id">
<input type="text" data-table="user" data-field="x_id" data-page="1" name="x_id" id="x_id" size="30" placeholder="<?php echo HtmlEncode($user_add->id->getPlaceHolder()) ?>" value="<?php echo $user_add->id->EditValue ?>"<?php echo $user_add->id->editAttributes() ?>>
</span>
<?php echo $user_add->id->CustomMsg ?></div></div>
	</div>
<?php } ?>
<?php if ($user_add->firstName->Visible) { // firstName ?>
	<div id="r_firstName" class="form-group row">
		<label id="elh_user_firstName" for="x_firstName" class="<?php echo $user_add->LeftColumnClass ?>"><?php echo $user_add->firstName->caption() ?><?php echo $user_add->firstName->Required ? $Language->phrase("FieldRequiredIndicator") : "" ?></label>
		<div class="<?php echo $user_add->RightColumnClass ?>"><div <?php echo $user_add->firstName->cellAttributes() ?>>
<span id="el_user_firstName">
<input type="text" data-table="user" data-field="x_firstName" data-page="1" name="x_firstName" id="x_firstName" size="30" maxlength="60" placeholder="<?php echo HtmlEncode($user_add->firstName->getPlaceHolder()) ?>" value="<?php echo $user_add->firstName->EditValue ?>"<?php echo $user_add->firstName->editAttributes() ?>>
</span>
<?php echo $user_add->firstName->CustomMsg ?></div></div>
	</div>
<?php } ?>
<?php if ($user_add->lastName->Visible) { // lastName ?>
	<div id="r_lastName" class="form-group row">
		<label id="elh_user_lastName" for="x_lastName" class="<?php echo $user_add->LeftColumnClass ?>"><?php echo $user_add->lastName->caption() ?><?php echo $user_add->lastName->Required ? $Language->phrase("FieldRequiredIndicator") : "" ?></label>
		<div class="<?php echo $user_add->RightColumnClass ?>"><div <?php echo $user_add->lastName->cellAttributes() ?>>
<span id="el_user_lastName">
<input type="text" data-table="user" data-field="x_lastName" data-page="1" name="x_lastName" id="x_lastName" size="30" maxlength="60" placeholder="<?php echo HtmlEncode($user_add->lastName->getPlaceHolder()) ?>" value="<?php echo $user_add->lastName->EditValue ?>"<?php echo $user_add->lastName->editAttributes() ?>>
</span>
<?php echo $user_add->lastName->CustomMsg ?></div></div>
	</div>
<?php } ?>
<?php if ($user_add->otherNames->Visible) { // otherNames ?>
	<div id="r_otherNames" class="form-group row">
		<label id="elh_user_otherNames" for="x_otherNames" class="<?php echo $user_add->LeftColumnClass ?>"><?php echo $user_add->otherNames->caption() ?><?php echo $user_add->otherNames->Required ? $Language->phrase("FieldRequiredIndicator") : "" ?></label>
		<div class="<?php echo $user_add->RightColumnClass ?>"><div <?php echo $user_add->otherNames->cellAttributes() ?>>
<span id="el_user_otherNames">
<input type="text" data-table="user" data-field="x_otherNames" data-page="1" name="x_otherNames" id="x_otherNames" size="30" maxlength="60" placeholder="<?php echo HtmlEncode($user_add->otherNames->getPlaceHolder()) ?>" value="<?php echo $user_add->otherNames->EditValue ?>"<?php echo $user_add->otherNames->editAttributes() ?>>
</span>
<?php echo $user_add->otherNames->CustomMsg ?></div></div>
	</div>
<?php } ?>
<?php if ($user_add->passwordRequireChange->Visible) { // passwordRequireChange ?>
	<div id="r_passwordRequireChange" class="form-group row">
		<label id="elh_user_passwordRequireChange" class="<?php echo $user_add->LeftColumnClass ?>"><?php echo $user_add->passwordRequireChange->caption() ?><?php echo $user_add->passwordRequireChange->Required ? $Language->phrase("FieldRequiredIndicator") : "" ?></label>
		<div class="<?php echo $user_add->RightColumnClass ?>"><div <?php echo $user_add->passwordRequireChange->cellAttributes() ?>>
<span id="el_user_passwordRequireChange">
<div id="tp_x_passwordRequireChange" class="ew-template"><input type="radio" class="custom-control-input" data-table="user" data-field="x_passwordRequireChange" data-page="1" data-value-separator="<?php echo $user_add->passwordRequireChange->displayValueSeparatorAttribute() ?>" name="x_passwordRequireChange" id="x_passwordRequireChange" value="{value}"<?php echo $user_add->passwordRequireChange->editAttributes() ?>></div>
<div id="dsl_x_passwordRequireChange" data-repeatcolumn="5" class="ew-item-list d-none"><div>
<?php echo $user_add->passwordRequireChange->radioButtonListHtml(FALSE, "x_passwordRequireChange", 1) ?>
</div></div>
<?php echo $user_add->passwordRequireChange->Lookup->getParamTag($user_add, "p_x_passwordRequireChange") ?>
</span>
<?php echo $user_add->passwordRequireChange->CustomMsg ?></div></div>
	</div>
<?php } ?>
<?php if ($user_add->dateAdded->Visible) { // dateAdded ?>
	<div id="r_dateAdded" class="form-group row">
		<label id="elh_user_dateAdded" for="x_dateAdded" class="<?php echo $user_add->LeftColumnClass ?>"><?php echo $user_add->dateAdded->caption() ?><?php echo $user_add->dateAdded->Required ? $Language->phrase("FieldRequiredIndicator") : "" ?></label>
		<div class="<?php echo $user_add->RightColumnClass ?>"><div <?php echo $user_add->dateAdded->cellAttributes() ?>>
<span id="el_user_dateAdded">
<input type="text" data-table="user" data-field="x_dateAdded" data-page="1" data-format="1" name="x_dateAdded" id="x_dateAdded" placeholder="<?php echo HtmlEncode($user_add->dateAdded->getPlaceHolder()) ?>" value="<?php echo $user_add->dateAdded->EditValue ?>"<?php echo $user_add->dateAdded->editAttributes() ?>>
<?php if (!$user_add->dateAdded->ReadOnly && !$user_add->dateAdded->Disabled && !isset($user_add->dateAdded->EditAttrs["readonly"]) && !isset($user_add->dateAdded->EditAttrs["disabled"])) { ?>
<script>
loadjs.ready(["fuseradd", "datetimepicker"], function() {
	ew.createDateTimePicker("fuseradd", "x_dateAdded", {"ignoreReadonly":true,"useCurrent":false,"format":1});
});
</script>
<?php } ?>
</span>
<?php echo $user_add->dateAdded->CustomMsg ?></div></div>
	</div>
<?php } ?>
<?php if ($user_add->timezoneid->Visible) { // timezoneid ?>
	<div id="r_timezoneid" class="form-group row">
		<label id="elh_user_timezoneid" for="x_timezoneid" class="<?php echo $user_add->LeftColumnClass ?>"><?php echo $user_add->timezoneid->caption() ?><?php echo $user_add->timezoneid->Required ? $Language->phrase("FieldRequiredIndicator") : "" ?></label>
		<div class="<?php echo $user_add->RightColumnClass ?>"><div <?php echo $user_add->timezoneid->cellAttributes() ?>>
<span id="el_user_timezoneid">
<div class="input-group">
	<select class="custom-select ew-custom-select" data-table="user" data-field="x_timezoneid" data-page="1" data-value-separator="<?php echo $user_add->timezoneid->displayValueSeparatorAttribute() ?>" id="x_timezoneid" name="x_timezoneid"<?php echo $user_add->timezoneid->editAttributes() ?>>
			<?php echo $user_add->timezoneid->selectOptionListHtml("x_timezoneid") ?>
		</select>
</div>
<?php echo $user_add->timezoneid->Lookup->getParamTag($user_add, "p_x_timezoneid") ?>
</span>
<?php echo $user_add->timezoneid->CustomMsg ?></div></div>
	</div>
<?php } ?>
<?php if ($user_add->contactPhoneNo->Visible) { // contactPhoneNo ?>
	<div id="r_contactPhoneNo" class="form-group row">
		<label id="elh_user_contactPhoneNo" for="x_contactPhoneNo" class="<?php echo $user_add->LeftColumnClass ?>"><?php echo $user_add->contactPhoneNo->caption() ?><?php echo $user_add->contactPhoneNo->Required ? $Language->phrase("FieldRequiredIndicator") : "" ?></label>
		<div class="<?php echo $user_add->RightColumnClass ?>"><div <?php echo $user_add->contactPhoneNo->cellAttributes() ?>>
<span id="el_user_contactPhoneNo">
<input type="text" data-table="user" data-field="x_contactPhoneNo" data-page="1" name="x_contactPhoneNo" id="x_contactPhoneNo" size="30" maxlength="20" placeholder="<?php echo HtmlEncode($user_add->contactPhoneNo->getPlaceHolder()) ?>" value="<?php echo $user_add->contactPhoneNo->EditValue ?>"<?php echo $user_add->contactPhoneNo->editAttributes() ?>>
</span>
<?php echo $user_add->contactPhoneNo->CustomMsg ?></div></div>
	</div>
<?php } ?>
<?php if ($user_add->telephoneno->Visible) { // telephoneno ?>
	<div id="r_telephoneno" class="form-group row">
		<label id="elh_user_telephoneno" for="x_telephoneno" class="<?php echo $user_add->LeftColumnClass ?>"><?php echo $user_add->telephoneno->caption() ?><?php echo $user_add->telephoneno->Required ? $Language->phrase("FieldRequiredIndicator") : "" ?></label>
		<div class="<?php echo $user_add->RightColumnClass ?>"><div <?php echo $user_add->telephoneno->cellAttributes() ?>>
<span id="el_user_telephoneno">
<input type="text" data-table="user" data-field="x_telephoneno" data-page="1" name="x_telephoneno" id="x_telephoneno" size="30" maxlength="20" placeholder="<?php echo HtmlEncode($user_add->telephoneno->getPlaceHolder()) ?>" value="<?php echo $user_add->telephoneno->EditValue ?>"<?php echo $user_add->telephoneno->editAttributes() ?>>
</span>
<?php echo $user_add->telephoneno->CustomMsg ?></div></div>
	</div>
<?php } ?>
<?php if ($user_add->telephoneverified->Visible) { // telephoneverified ?>
	<div id="r_telephoneverified" class="form-group row">
		<label id="elh_user_telephoneverified" class="<?php echo $user_add->LeftColumnClass ?>"><?php echo $user_add->telephoneverified->caption() ?><?php echo $user_add->telephoneverified->Required ? $Language->phrase("FieldRequiredIndicator") : "" ?></label>
		<div class="<?php echo $user_add->RightColumnClass ?>"><div <?php echo $user_add->telephoneverified->cellAttributes() ?>>
<span id="el_user_telephoneverified">
<div id="tp_x_telephoneverified" class="ew-template"><input type="radio" class="custom-control-input" data-table="user" data-field="x_telephoneverified" data-page="1" data-value-separator="<?php echo $user_add->telephoneverified->displayValueSeparatorAttribute() ?>" name="x_telephoneverified" id="x_telephoneverified" value="{value}"<?php echo $user_add->telephoneverified->editAttributes() ?>></div>
<div id="dsl_x_telephoneverified" data-repeatcolumn="5" class="ew-item-list d-none"><div>
<?php echo $user_add->telephoneverified->radioButtonListHtml(FALSE, "x_telephoneverified", 1) ?>
</div></div>
<?php echo $user_add->telephoneverified->Lookup->getParamTag($user_add, "p_x_telephoneverified") ?>
</span>
<?php echo $user_add->telephoneverified->CustomMsg ?></div></div>
	</div>
<?php } ?>
<?php if ($user_add->address1->Visible) { // address1 ?>
	<div id="r_address1" class="form-group row">
		<label id="elh_user_address1" for="x_address1" class="<?php echo $user_add->LeftColumnClass ?>"><?php echo $user_add->address1->caption() ?><?php echo $user_add->address1->Required ? $Language->phrase("FieldRequiredIndicator") : "" ?></label>
		<div class="<?php echo $user_add->RightColumnClass ?>"><div <?php echo $user_add->address1->cellAttributes() ?>>
<span id="el_user_address1">
<input type="text" data-table="user" data-field="x_address1" data-page="1" name="x_address1" id="x_address1" size="30" maxlength="60" placeholder="<?php echo HtmlEncode($user_add->address1->getPlaceHolder()) ?>" value="<?php echo $user_add->address1->EditValue ?>"<?php echo $user_add->address1->editAttributes() ?>>
</span>
<?php echo $user_add->address1->CustomMsg ?></div></div>
	</div>
<?php } ?>
<?php if ($user_add->address2->Visible) { // address2 ?>
	<div id="r_address2" class="form-group row">
		<label id="elh_user_address2" for="x_address2" class="<?php echo $user_add->LeftColumnClass ?>"><?php echo $user_add->address2->caption() ?><?php echo $user_add->address2->Required ? $Language->phrase("FieldRequiredIndicator") : "" ?></label>
		<div class="<?php echo $user_add->RightColumnClass ?>"><div <?php echo $user_add->address2->cellAttributes() ?>>
<span id="el_user_address2">
<input type="text" data-table="user" data-field="x_address2" data-page="1" name="x_address2" id="x_address2" size="30" maxlength="60" placeholder="<?php echo HtmlEncode($user_add->address2->getPlaceHolder()) ?>" value="<?php echo $user_add->address2->EditValue ?>"<?php echo $user_add->address2->editAttributes() ?>>
</span>
<?php echo $user_add->address2->CustomMsg ?></div></div>
	</div>
<?php } ?>
<?php if ($user_add->cityname->Visible) { // cityname ?>
	<div id="r_cityname" class="form-group row">
		<label id="elh_user_cityname" for="x_cityname" class="<?php echo $user_add->LeftColumnClass ?>"><?php echo $user_add->cityname->caption() ?><?php echo $user_add->cityname->Required ? $Language->phrase("FieldRequiredIndicator") : "" ?></label>
		<div class="<?php echo $user_add->RightColumnClass ?>"><div <?php echo $user_add->cityname->cellAttributes() ?>>
<span id="el_user_cityname">
<input type="text" data-table="user" data-field="x_cityname" data-page="1" name="x_cityname" id="x_cityname" size="30" maxlength="60" placeholder="<?php echo HtmlEncode($user_add->cityname->getPlaceHolder()) ?>" value="<?php echo $user_add->cityname->EditValue ?>"<?php echo $user_add->cityname->editAttributes() ?>>
</span>
<?php echo $user_add->cityname->CustomMsg ?></div></div>
	</div>
<?php } ?>
<?php if ($user_add->countryid->Visible) { // countryid ?>
	<div id="r_countryid" class="form-group row">
		<label id="elh_user_countryid" for="x_countryid" class="<?php echo $user_add->LeftColumnClass ?>"><?php echo $user_add->countryid->caption() ?><?php echo $user_add->countryid->Required ? $Language->phrase("FieldRequiredIndicator") : "" ?></label>
		<div class="<?php echo $user_add->RightColumnClass ?>"><div <?php echo $user_add->countryid->cellAttributes() ?>>
<span id="el_user_countryid">
<?php $user_add->countryid->EditAttrs->prepend("onchange", "ew.updateOptions.call(this);"); ?>
<div class="input-group">
	<select class="custom-select ew-custom-select" data-table="user" data-field="x_countryid" data-page="1" data-value-separator="<?php echo $user_add->countryid->displayValueSeparatorAttribute() ?>" id="x_countryid" name="x_countryid"<?php echo $user_add->countryid->editAttributes() ?>>
			<?php echo $user_add->countryid->selectOptionListHtml("x_countryid") ?>
		</select>
</div>
<?php echo $user_add->countryid->Lookup->getParamTag($user_add, "p_x_countryid") ?>
</span>
<?php echo $user_add->countryid->CustomMsg ?></div></div>
	</div>
<?php } ?>
<?php if ($user_add->stateid->Visible) { // stateid ?>
	<div id="r_stateid" class="form-group row">
		<label id="elh_user_stateid" for="x_stateid" class="<?php echo $user_add->LeftColumnClass ?>"><?php echo $user_add->stateid->caption() ?><?php echo $user_add->stateid->Required ? $Language->phrase("FieldRequiredIndicator") : "" ?></label>
		<div class="<?php echo $user_add->RightColumnClass ?>"><div <?php echo $user_add->stateid->cellAttributes() ?>>
<span id="el_user_stateid">
<div class="input-group">
	<select class="custom-select ew-custom-select" data-table="user" data-field="x_stateid" data-page="1" data-value-separator="<?php echo $user_add->stateid->displayValueSeparatorAttribute() ?>" id="x_stateid" name="x_stateid"<?php echo $user_add->stateid->editAttributes() ?>>
			<?php echo $user_add->stateid->selectOptionListHtml("x_stateid") ?>
		</select>
</div>
<?php echo $user_add->stateid->Lookup->getParamTag($user_add, "p_x_stateid") ?>
</span>
<?php echo $user_add->stateid->CustomMsg ?></div></div>
	</div>
<?php } ?>
<?php if ($user_add->defaultcurrency->Visible) { // defaultcurrency ?>
	<div id="r_defaultcurrency" class="form-group row">
		<label id="elh_user_defaultcurrency" for="x_defaultcurrency" class="<?php echo $user_add->LeftColumnClass ?>"><?php echo $user_add->defaultcurrency->caption() ?><?php echo $user_add->defaultcurrency->Required ? $Language->phrase("FieldRequiredIndicator") : "" ?></label>
		<div class="<?php echo $user_add->RightColumnClass ?>"><div <?php echo $user_add->defaultcurrency->cellAttributes() ?>>
<span id="el_user_defaultcurrency">
<div class="input-group">
	<select class="custom-select ew-custom-select" data-table="user" data-field="x_defaultcurrency" data-page="1" data-value-separator="<?php echo $user_add->defaultcurrency->displayValueSeparatorAttribute() ?>" id="x_defaultcurrency" name="x_defaultcurrency"<?php echo $user_add->defaultcurrency->editAttributes() ?>>
			<?php echo $user_add->defaultcurrency->selectOptionListHtml("x_defaultcurrency") ?>
		</select>
</div>
<?php echo $user_add->defaultcurrency->Lookup->getParamTag($user_add, "p_x_defaultcurrency") ?>
</span>
<?php echo $user_add->defaultcurrency->CustomMsg ?></div></div>
	</div>
<?php } ?>
<?php if ($user_add->accountID->Visible) { // accountID ?>
	<div id="r_accountID" class="form-group row">
		<label id="elh_user_accountID" for="x_accountID" class="<?php echo $user_add->LeftColumnClass ?>"><?php echo $user_add->accountID->caption() ?><?php echo $user_add->accountID->Required ? $Language->phrase("FieldRequiredIndicator") : "" ?></label>
		<div class="<?php echo $user_add->RightColumnClass ?>"><div <?php echo $user_add->accountID->cellAttributes() ?>>
<span id="el_user_accountID">
<input type="text" data-table="user" data-field="x_accountID" data-page="1" name="x_accountID" id="x_accountID" size="30" placeholder="<?php echo HtmlEncode($user_add->accountID->getPlaceHolder()) ?>" value="<?php echo $user_add->accountID->EditValue ?>"<?php echo $user_add->accountID->editAttributes() ?>>
</span>
<?php echo $user_add->accountID->CustomMsg ?></div></div>
	</div>
<?php } ?>
<?php if ($user_add->profilestatus->Visible) { // profilestatus ?>
	<div id="r_profilestatus" class="form-group row">
		<label id="elh_user_profilestatus" for="x_profilestatus" class="<?php echo $user_add->LeftColumnClass ?>"><?php echo $user_add->profilestatus->caption() ?><?php echo $user_add->profilestatus->Required ? $Language->phrase("FieldRequiredIndicator") : "" ?></label>
		<div class="<?php echo $user_add->RightColumnClass ?>"><div <?php echo $user_add->profilestatus->cellAttributes() ?>>
<span id="el_user_profilestatus">
<div class="input-group">
	<select class="custom-select ew-custom-select" data-table="user" data-field="x_profilestatus" data-page="1" data-value-separator="<?php echo $user_add->profilestatus->displayValueSeparatorAttribute() ?>" id="x_profilestatus" name="x_profilestatus"<?php echo $user_add->profilestatus->editAttributes() ?>>
			<?php echo $user_add->profilestatus->selectOptionListHtml("x_profilestatus") ?>
		</select>
</div>
<?php echo $user_add->profilestatus->Lookup->getParamTag($user_add, "p_x_profilestatus") ?>
</span>
<?php echo $user_add->profilestatus->CustomMsg ?></div></div>
	</div>
<?php } ?>
<?php if ($user_add->dateofbirth->Visible) { // dateofbirth ?>
	<div id="r_dateofbirth" class="form-group row">
		<label id="elh_user_dateofbirth" for="x_dateofbirth" class="<?php echo $user_add->LeftColumnClass ?>"><?php echo $user_add->dateofbirth->caption() ?><?php echo $user_add->dateofbirth->Required ? $Language->phrase("FieldRequiredIndicator") : "" ?></label>
		<div class="<?php echo $user_add->RightColumnClass ?>"><div <?php echo $user_add->dateofbirth->cellAttributes() ?>>
<span id="el_user_dateofbirth">
<input type="text" data-table="user" data-field="x_dateofbirth" data-page="1" data-format="2" name="x_dateofbirth" id="x_dateofbirth" placeholder="<?php echo HtmlEncode($user_add->dateofbirth->getPlaceHolder()) ?>" value="<?php echo $user_add->dateofbirth->EditValue ?>"<?php echo $user_add->dateofbirth->editAttributes() ?>>
<?php if (!$user_add->dateofbirth->ReadOnly && !$user_add->dateofbirth->Disabled && !isset($user_add->dateofbirth->EditAttrs["readonly"]) && !isset($user_add->dateofbirth->EditAttrs["disabled"])) { ?>
<script>
loadjs.ready(["fuseradd", "datetimepicker"], function() {
	ew.createDateTimePicker("fuseradd", "x_dateofbirth", {"ignoreReadonly":true,"useCurrent":false,"format":2});
});
</script>
<?php } ?>
</span>
<?php echo $user_add->dateofbirth->CustomMsg ?></div></div>
	</div>
<?php } ?>
<?php if ($user_add->gender->Visible) { // gender ?>
	<div id="r_gender" class="form-group row">
		<label id="elh_user_gender" for="x_gender" class="<?php echo $user_add->LeftColumnClass ?>"><?php echo $user_add->gender->caption() ?><?php echo $user_add->gender->Required ? $Language->phrase("FieldRequiredIndicator") : "" ?></label>
		<div class="<?php echo $user_add->RightColumnClass ?>"><div <?php echo $user_add->gender->cellAttributes() ?>>
<span id="el_user_gender">
<div class="input-group">
	<select class="custom-select ew-custom-select" data-table="user" data-field="x_gender" data-page="1" data-value-separator="<?php echo $user_add->gender->displayValueSeparatorAttribute() ?>" id="x_gender" name="x_gender"<?php echo $user_add->gender->editAttributes() ?>>
			<?php echo $user_add->gender->selectOptionListHtml("x_gender") ?>
		</select>
</div>
<?php echo $user_add->gender->Lookup->getParamTag($user_add, "p_x_gender") ?>
</span>
<?php echo $user_add->gender->CustomMsg ?></div></div>
	</div>
<?php } ?>
<?php if ($user_add->zip->Visible) { // zip ?>
	<div id="r_zip" class="form-group row">
		<label id="elh_user_zip" for="x_zip" class="<?php echo $user_add->LeftColumnClass ?>"><?php echo $user_add->zip->caption() ?><?php echo $user_add->zip->Required ? $Language->phrase("FieldRequiredIndicator") : "" ?></label>
		<div class="<?php echo $user_add->RightColumnClass ?>"><div <?php echo $user_add->zip->cellAttributes() ?>>
<span id="el_user_zip">
<input type="text" data-table="user" data-field="x_zip" data-page="1" name="x_zip" id="x_zip" size="30" maxlength="10" placeholder="<?php echo HtmlEncode($user_add->zip->getPlaceHolder()) ?>" value="<?php echo $user_add->zip->EditValue ?>"<?php echo $user_add->zip->editAttributes() ?>>
</span>
<?php echo $user_add->zip->CustomMsg ?></div></div>
	</div>
<?php } ?>
<?php if ($user_add->otprequiredforphysicalcards->Visible) { // otprequiredforphysicalcards ?>
	<div id="r_otprequiredforphysicalcards" class="form-group row">
		<label id="elh_user_otprequiredforphysicalcards" for="x_otprequiredforphysicalcards" class="<?php echo $user_add->LeftColumnClass ?>"><?php echo $user_add->otprequiredforphysicalcards->caption() ?><?php echo $user_add->otprequiredforphysicalcards->Required ? $Language->phrase("FieldRequiredIndicator") : "" ?></label>
		<div class="<?php echo $user_add->RightColumnClass ?>"><div <?php echo $user_add->otprequiredforphysicalcards->cellAttributes() ?>>
<span id="el_user_otprequiredforphysicalcards">
<input type="text" data-table="user" data-field="x_otprequiredforphysicalcards" data-page="1" name="x_otprequiredforphysicalcards" id="x_otprequiredforphysicalcards" size="30" maxlength="1" placeholder="<?php echo HtmlEncode($user_add->otprequiredforphysicalcards->getPlaceHolder()) ?>" value="<?php echo $user_add->otprequiredforphysicalcards->EditValue ?>"<?php echo $user_add->otprequiredforphysicalcards->editAttributes() ?>>
</span>
<?php echo $user_add->otprequiredforphysicalcards->CustomMsg ?></div></div>
	</div>
<?php } ?>
<?php if ($user_add->otpvaliduntil->Visible) { // otpvaliduntil ?>
	<div id="r_otpvaliduntil" class="form-group row">
		<label id="elh_user_otpvaliduntil" for="x_otpvaliduntil" class="<?php echo $user_add->LeftColumnClass ?>"><?php echo $user_add->otpvaliduntil->caption() ?><?php echo $user_add->otpvaliduntil->Required ? $Language->phrase("FieldRequiredIndicator") : "" ?></label>
		<div class="<?php echo $user_add->RightColumnClass ?>"><div <?php echo $user_add->otpvaliduntil->cellAttributes() ?>>
<span id="el_user_otpvaliduntil">
<input type="text" data-table="user" data-field="x_otpvaliduntil" data-page="1" name="x_otpvaliduntil" id="x_otpvaliduntil" maxlength="19" placeholder="<?php echo HtmlEncode($user_add->otpvaliduntil->getPlaceHolder()) ?>" value="<?php echo $user_add->otpvaliduntil->EditValue ?>"<?php echo $user_add->otpvaliduntil->editAttributes() ?>>
<?php if (!$user_add->otpvaliduntil->ReadOnly && !$user_add->otpvaliduntil->Disabled && !isset($user_add->otpvaliduntil->EditAttrs["readonly"]) && !isset($user_add->otpvaliduntil->EditAttrs["disabled"])) { ?>
<script>
loadjs.ready(["fuseradd", "datetimepicker"], function() {
	ew.createDateTimePicker("fuseradd", "x_otpvaliduntil", {"ignoreReadonly":true,"useCurrent":false,"format":0});
});
</script>
<?php } ?>
</span>
<?php echo $user_add->otpvaliduntil->CustomMsg ?></div></div>
	</div>
<?php } ?>
<?php if ($user_add->nationalitycountry->Visible) { // nationalitycountry ?>
	<div id="r_nationalitycountry" class="form-group row">
		<label id="elh_user_nationalitycountry" for="x_nationalitycountry" class="<?php echo $user_add->LeftColumnClass ?>"><?php echo $user_add->nationalitycountry->caption() ?><?php echo $user_add->nationalitycountry->Required ? $Language->phrase("FieldRequiredIndicator") : "" ?></label>
		<div class="<?php echo $user_add->RightColumnClass ?>"><div <?php echo $user_add->nationalitycountry->cellAttributes() ?>>
<span id="el_user_nationalitycountry">
<div class="input-group">
	<select class="custom-select ew-custom-select" data-table="user" data-field="x_nationalitycountry" data-page="1" data-value-separator="<?php echo $user_add->nationalitycountry->displayValueSeparatorAttribute() ?>" id="x_nationalitycountry" name="x_nationalitycountry"<?php echo $user_add->nationalitycountry->editAttributes() ?>>
			<?php echo $user_add->nationalitycountry->selectOptionListHtml("x_nationalitycountry") ?>
		</select>
</div>
<?php echo $user_add->nationalitycountry->Lookup->getParamTag($user_add, "p_x_nationalitycountry") ?>
</span>
<?php echo $user_add->nationalitycountry->CustomMsg ?></div></div>
	</div>
<?php } ?>
<?php if ($user_add->classification->Visible) { // classification ?>
	<div id="r_classification" class="form-group row">
		<label id="elh_user_classification" for="x_classification" class="<?php echo $user_add->LeftColumnClass ?>"><?php echo $user_add->classification->caption() ?><?php echo $user_add->classification->Required ? $Language->phrase("FieldRequiredIndicator") : "" ?></label>
		<div class="<?php echo $user_add->RightColumnClass ?>"><div <?php echo $user_add->classification->cellAttributes() ?>>
<span id="el_user_classification">
<div class="input-group">
	<select class="custom-select ew-custom-select" data-table="user" data-field="x_classification" data-page="1" data-value-separator="<?php echo $user_add->classification->displayValueSeparatorAttribute() ?>" id="x_classification" name="x_classification"<?php echo $user_add->classification->editAttributes() ?>>
			<?php echo $user_add->classification->selectOptionListHtml("x_classification") ?>
		</select>
</div>
<?php echo $user_add->classification->Lookup->getParamTag($user_add, "p_x_classification") ?>
</span>
<?php echo $user_add->classification->CustomMsg ?></div></div>
	</div>
<?php } ?>
<?php if ($user_add->occupation->Visible) { // occupation ?>
	<div id="r_occupation" class="form-group row">
		<label id="elh_user_occupation" class="<?php echo $user_add->LeftColumnClass ?>"><?php echo $user_add->occupation->caption() ?><?php echo $user_add->occupation->Required ? $Language->phrase("FieldRequiredIndicator") : "" ?></label>
		<div class="<?php echo $user_add->RightColumnClass ?>"><div <?php echo $user_add->occupation->cellAttributes() ?>>
<span id="el_user_occupation">
<?php
$onchange = $user_add->occupation->EditAttrs->prepend("onchange", "");
$onchange = ($onchange) ? ' onchange="' . JsEncode($onchange) . '"' : '';
$user_add->occupation->EditAttrs["onchange"] = "";
?>
<span id="as_x_occupation">
	<input type="text" class="form-control" name="sv_x_occupation" id="sv_x_occupation" value="<?php echo RemoveHtml($user_add->occupation->EditValue) ?>" size="30" maxlength="3" placeholder="<?php echo HtmlEncode($user_add->occupation->getPlaceHolder()) ?>" data-placeholder="<?php echo HtmlEncode($user_add->occupation->getPlaceHolder()) ?>"<?php echo $user_add->occupation->editAttributes() ?>>
</span>
<input type="hidden" data-table="user" data-field="x_occupation" data-page="1" data-value-separator="<?php echo $user_add->occupation->displayValueSeparatorAttribute() ?>" name="x_occupation" id="x_occupation" value="<?php echo HtmlEncode($user_add->occupation->CurrentValue) ?>"<?php echo $onchange ?>>
<script>
loadjs.ready(["fuseradd"], function() {
	fuseradd.createAutoSuggest({"id":"x_occupation","forceSelect":false});
});
</script>
<?php echo $user_add->occupation->Lookup->getParamTag($user_add, "p_x_occupation") ?>
</span>
<?php echo $user_add->occupation->CustomMsg ?></div></div>
	</div>
<?php } ?>
<?php if ($user_add->sourceofincome->Visible) { // sourceofincome ?>
	<div id="r_sourceofincome" class="form-group row">
		<label id="elh_user_sourceofincome" for="x_sourceofincome" class="<?php echo $user_add->LeftColumnClass ?>"><?php echo $user_add->sourceofincome->caption() ?><?php echo $user_add->sourceofincome->Required ? $Language->phrase("FieldRequiredIndicator") : "" ?></label>
		<div class="<?php echo $user_add->RightColumnClass ?>"><div <?php echo $user_add->sourceofincome->cellAttributes() ?>>
<span id="el_user_sourceofincome">
<div class="input-group">
	<select class="custom-select ew-custom-select" data-table="user" data-field="x_sourceofincome" data-page="1" data-value-separator="<?php echo $user_add->sourceofincome->displayValueSeparatorAttribute() ?>" id="x_sourceofincome" name="x_sourceofincome"<?php echo $user_add->sourceofincome->editAttributes() ?>>
			<?php echo $user_add->sourceofincome->selectOptionListHtml("x_sourceofincome") ?>
		</select>
</div>
<?php echo $user_add->sourceofincome->Lookup->getParamTag($user_add, "p_x_sourceofincome") ?>
</span>
<?php echo $user_add->sourceofincome->CustomMsg ?></div></div>
	</div>
<?php } ?>
<?php if ($user_add->accountopeningdate->Visible) { // accountopeningdate ?>
	<div id="r_accountopeningdate" class="form-group row">
		<label id="elh_user_accountopeningdate" for="x_accountopeningdate" class="<?php echo $user_add->LeftColumnClass ?>"><?php echo $user_add->accountopeningdate->caption() ?><?php echo $user_add->accountopeningdate->Required ? $Language->phrase("FieldRequiredIndicator") : "" ?></label>
		<div class="<?php echo $user_add->RightColumnClass ?>"><div <?php echo $user_add->accountopeningdate->cellAttributes() ?>>
<span id="el_user_accountopeningdate">
<input type="text" data-table="user" data-field="x_accountopeningdate" data-page="1" name="x_accountopeningdate" id="x_accountopeningdate" maxlength="10" placeholder="<?php echo HtmlEncode($user_add->accountopeningdate->getPlaceHolder()) ?>" value="<?php echo $user_add->accountopeningdate->EditValue ?>"<?php echo $user_add->accountopeningdate->editAttributes() ?>>
<?php if (!$user_add->accountopeningdate->ReadOnly && !$user_add->accountopeningdate->Disabled && !isset($user_add->accountopeningdate->EditAttrs["readonly"]) && !isset($user_add->accountopeningdate->EditAttrs["disabled"])) { ?>
<script>
loadjs.ready(["fuseradd", "datetimepicker"], function() {
	ew.createDateTimePicker("fuseradd", "x_accountopeningdate", {"ignoreReadonly":true,"useCurrent":false,"format":0});
});
</script>
<?php } ?>
</span>
<?php echo $user_add->accountopeningdate->CustomMsg ?></div></div>
	</div>
<?php } ?>
<?php if ($user_add->extendedfields->Visible) { // extendedfields ?>
	<div id="r_extendedfields" class="form-group row">
		<label id="elh_user_extendedfields" for="x_extendedfields" class="<?php echo $user_add->LeftColumnClass ?>"><?php echo $user_add->extendedfields->caption() ?><?php echo $user_add->extendedfields->Required ? $Language->phrase("FieldRequiredIndicator") : "" ?></label>
		<div class="<?php echo $user_add->RightColumnClass ?>"><div <?php echo $user_add->extendedfields->cellAttributes() ?>>
<span id="el_user_extendedfields">
<textarea data-table="user" data-field="x_extendedfields" data-page="1" name="x_extendedfields" id="x_extendedfields" cols="35" rows="4" placeholder="<?php echo HtmlEncode($user_add->extendedfields->getPlaceHolder()) ?>"<?php echo $user_add->extendedfields->editAttributes() ?>><?php echo $user_add->extendedfields->EditValue ?></textarea>
</span>
<?php echo $user_add->extendedfields->CustomMsg ?></div></div>
	</div>
<?php } ?>
<?php if ($user_add->lastprofilestatuschangedate->Visible) { // lastprofilestatuschangedate ?>
	<div id="r_lastprofilestatuschangedate" class="form-group row">
		<label id="elh_user_lastprofilestatuschangedate" for="x_lastprofilestatuschangedate" class="<?php echo $user_add->LeftColumnClass ?>"><?php echo $user_add->lastprofilestatuschangedate->caption() ?><?php echo $user_add->lastprofilestatuschangedate->Required ? $Language->phrase("FieldRequiredIndicator") : "" ?></label>
		<div class="<?php echo $user_add->RightColumnClass ?>"><div <?php echo $user_add->lastprofilestatuschangedate->cellAttributes() ?>>
<span id="el_user_lastprofilestatuschangedate">
<input type="text" data-table="user" data-field="x_lastprofilestatuschangedate" data-page="1" name="x_lastprofilestatuschangedate" id="x_lastprofilestatuschangedate" maxlength="19" placeholder="<?php echo HtmlEncode($user_add->lastprofilestatuschangedate->getPlaceHolder()) ?>" value="<?php echo $user_add->lastprofilestatuschangedate->EditValue ?>"<?php echo $user_add->lastprofilestatuschangedate->editAttributes() ?>>
<?php if (!$user_add->lastprofilestatuschangedate->ReadOnly && !$user_add->lastprofilestatuschangedate->Disabled && !isset($user_add->lastprofilestatuschangedate->EditAttrs["readonly"]) && !isset($user_add->lastprofilestatuschangedate->EditAttrs["disabled"])) { ?>
<script>
loadjs.ready(["fuseradd", "datetimepicker"], function() {
	ew.createDateTimePicker("fuseradd", "x_lastprofilestatuschangedate", {"ignoreReadonly":true,"useCurrent":false,"format":0});
});
</script>
<?php } ?>
</span>
<?php echo $user_add->lastprofilestatuschangedate->CustomMsg ?></div></div>
	</div>
<?php } ?>
</div><!-- /page* -->
		</div><!-- /multi-page .tab-pane -->
		<div class="tab-pane<?php echo $user_add->MultiPages->pageStyle(2) ?>" id="tab_user2"><!-- multi-page .tab-pane -->
<div class="ew-add-div"><!-- page* -->
<?php if ($user_add->challengeq1->Visible) { // challengeq1 ?>
	<div id="r_challengeq1" class="form-group row">
		<label id="elh_user_challengeq1" for="x_challengeq1" class="<?php echo $user_add->LeftColumnClass ?>"><?php echo $user_add->challengeq1->caption() ?><?php echo $user_add->challengeq1->Required ? $Language->phrase("FieldRequiredIndicator") : "" ?></label>
		<div class="<?php echo $user_add->RightColumnClass ?>"><div <?php echo $user_add->challengeq1->cellAttributes() ?>>
<span id="el_user_challengeq1">
<input type="text" data-table="user" data-field="x_challengeq1" data-page="2" name="x_challengeq1" id="x_challengeq1" size="30" placeholder="<?php echo HtmlEncode($user_add->challengeq1->getPlaceHolder()) ?>" value="<?php echo $user_add->challengeq1->EditValue ?>"<?php echo $user_add->challengeq1->editAttributes() ?>>
</span>
<?php echo $user_add->challengeq1->CustomMsg ?></div></div>
	</div>
<?php } ?>
<?php if ($user_add->challengea1->Visible) { // challengea1 ?>
	<div id="r_challengea1" class="form-group row">
		<label id="elh_user_challengea1" for="x_challengea1" class="<?php echo $user_add->LeftColumnClass ?>"><?php echo $user_add->challengea1->caption() ?><?php echo $user_add->challengea1->Required ? $Language->phrase("FieldRequiredIndicator") : "" ?></label>
		<div class="<?php echo $user_add->RightColumnClass ?>"><div <?php echo $user_add->challengea1->cellAttributes() ?>>
<span id="el_user_challengea1">
<input type="text" data-table="user" data-field="x_challengea1" data-page="2" name="x_challengea1" id="x_challengea1" size="30" maxlength="100" placeholder="<?php echo HtmlEncode($user_add->challengea1->getPlaceHolder()) ?>" value="<?php echo $user_add->challengea1->EditValue ?>"<?php echo $user_add->challengea1->editAttributes() ?>>
</span>
<?php echo $user_add->challengea1->CustomMsg ?></div></div>
	</div>
<?php } ?>
<?php if ($user_add->challengeq2->Visible) { // challengeq2 ?>
	<div id="r_challengeq2" class="form-group row">
		<label id="elh_user_challengeq2" for="x_challengeq2" class="<?php echo $user_add->LeftColumnClass ?>"><?php echo $user_add->challengeq2->caption() ?><?php echo $user_add->challengeq2->Required ? $Language->phrase("FieldRequiredIndicator") : "" ?></label>
		<div class="<?php echo $user_add->RightColumnClass ?>"><div <?php echo $user_add->challengeq2->cellAttributes() ?>>
<span id="el_user_challengeq2">
<input type="text" data-table="user" data-field="x_challengeq2" data-page="2" name="x_challengeq2" id="x_challengeq2" size="30" placeholder="<?php echo HtmlEncode($user_add->challengeq2->getPlaceHolder()) ?>" value="<?php echo $user_add->challengeq2->EditValue ?>"<?php echo $user_add->challengeq2->editAttributes() ?>>
</span>
<?php echo $user_add->challengeq2->CustomMsg ?></div></div>
	</div>
<?php } ?>
<?php if ($user_add->challengea2->Visible) { // challengea2 ?>
	<div id="r_challengea2" class="form-group row">
		<label id="elh_user_challengea2" for="x_challengea2" class="<?php echo $user_add->LeftColumnClass ?>"><?php echo $user_add->challengea2->caption() ?><?php echo $user_add->challengea2->Required ? $Language->phrase("FieldRequiredIndicator") : "" ?></label>
		<div class="<?php echo $user_add->RightColumnClass ?>"><div <?php echo $user_add->challengea2->cellAttributes() ?>>
<span id="el_user_challengea2">
<input type="text" data-table="user" data-field="x_challengea2" data-page="2" name="x_challengea2" id="x_challengea2" size="30" maxlength="100" placeholder="<?php echo HtmlEncode($user_add->challengea2->getPlaceHolder()) ?>" value="<?php echo $user_add->challengea2->EditValue ?>"<?php echo $user_add->challengea2->editAttributes() ?>>
</span>
<?php echo $user_add->challengea2->CustomMsg ?></div></div>
	</div>
<?php } ?>
<?php if ($user_add->challengeq3->Visible) { // challengeq3 ?>
	<div id="r_challengeq3" class="form-group row">
		<label id="elh_user_challengeq3" for="x_challengeq3" class="<?php echo $user_add->LeftColumnClass ?>"><?php echo $user_add->challengeq3->caption() ?><?php echo $user_add->challengeq3->Required ? $Language->phrase("FieldRequiredIndicator") : "" ?></label>
		<div class="<?php echo $user_add->RightColumnClass ?>"><div <?php echo $user_add->challengeq3->cellAttributes() ?>>
<span id="el_user_challengeq3">
<input type="text" data-table="user" data-field="x_challengeq3" data-page="2" name="x_challengeq3" id="x_challengeq3" size="30" placeholder="<?php echo HtmlEncode($user_add->challengeq3->getPlaceHolder()) ?>" value="<?php echo $user_add->challengeq3->EditValue ?>"<?php echo $user_add->challengeq3->editAttributes() ?>>
</span>
<?php echo $user_add->challengeq3->CustomMsg ?></div></div>
	</div>
<?php } ?>
<?php if ($user_add->challengea3->Visible) { // challengea3 ?>
	<div id="r_challengea3" class="form-group row">
		<label id="elh_user_challengea3" for="x_challengea3" class="<?php echo $user_add->LeftColumnClass ?>"><?php echo $user_add->challengea3->caption() ?><?php echo $user_add->challengea3->Required ? $Language->phrase("FieldRequiredIndicator") : "" ?></label>
		<div class="<?php echo $user_add->RightColumnClass ?>"><div <?php echo $user_add->challengea3->cellAttributes() ?>>
<span id="el_user_challengea3">
<input type="text" data-table="user" data-field="x_challengea3" data-page="2" name="x_challengea3" id="x_challengea3" size="30" maxlength="100" placeholder="<?php echo HtmlEncode($user_add->challengea3->getPlaceHolder()) ?>" value="<?php echo $user_add->challengea3->EditValue ?>"<?php echo $user_add->challengea3->editAttributes() ?>>
</span>
<?php echo $user_add->challengea3->CustomMsg ?></div></div>
	</div>
<?php } ?>
</div><!-- /page* -->
		</div><!-- /multi-page .tab-pane -->
		<div class="tab-pane<?php echo $user_add->MultiPages->pageStyle(3) ?>" id="tab_user3"><!-- multi-page .tab-pane -->
<div class="ew-add-div"><!-- page* -->
<?php if ($user_add->franchiseeID->Visible) { // franchiseeID ?>
	<div id="r_franchiseeID" class="form-group row">
		<label id="elh_user_franchiseeID" for="x_franchiseeID" class="<?php echo $user_add->LeftColumnClass ?>"><?php echo $user_add->franchiseeID->caption() ?><?php echo $user_add->franchiseeID->Required ? $Language->phrase("FieldRequiredIndicator") : "" ?></label>
		<div class="<?php echo $user_add->RightColumnClass ?>"><div <?php echo $user_add->franchiseeID->cellAttributes() ?>>
<span id="el_user_franchiseeID">
<input type="text" data-table="user" data-field="x_franchiseeID" data-page="3" name="x_franchiseeID" id="x_franchiseeID" size="30" placeholder="<?php echo HtmlEncode($user_add->franchiseeID->getPlaceHolder()) ?>" value="<?php echo $user_add->franchiseeID->EditValue ?>"<?php echo $user_add->franchiseeID->editAttributes() ?>>
</span>
<?php echo $user_add->franchiseeID->CustomMsg ?></div></div>
	</div>
<?php } ?>
<?php if ($user_add->telephonereceivemessage->Visible) { // telephonereceivemessage ?>
	<div id="r_telephonereceivemessage" class="form-group row">
		<label id="elh_user_telephonereceivemessage" class="<?php echo $user_add->LeftColumnClass ?>"><?php echo $user_add->telephonereceivemessage->caption() ?><?php echo $user_add->telephonereceivemessage->Required ? $Language->phrase("FieldRequiredIndicator") : "" ?></label>
		<div class="<?php echo $user_add->RightColumnClass ?>"><div <?php echo $user_add->telephonereceivemessage->cellAttributes() ?>>
<span id="el_user_telephonereceivemessage">
<div id="tp_x_telephonereceivemessage" class="ew-template"><input type="radio" class="custom-control-input" data-table="user" data-field="x_telephonereceivemessage" data-page="3" data-value-separator="<?php echo $user_add->telephonereceivemessage->displayValueSeparatorAttribute() ?>" name="x_telephonereceivemessage" id="x_telephonereceivemessage" value="{value}"<?php echo $user_add->telephonereceivemessage->editAttributes() ?>></div>
<div id="dsl_x_telephonereceivemessage" data-repeatcolumn="5" class="ew-item-list d-none"><div>
<?php echo $user_add->telephonereceivemessage->radioButtonListHtml(FALSE, "x_telephonereceivemessage", 3) ?>
</div></div>
<?php echo $user_add->telephonereceivemessage->Lookup->getParamTag($user_add, "p_x_telephonereceivemessage") ?>
</span>
<?php echo $user_add->telephonereceivemessage->CustomMsg ?></div></div>
	</div>
<?php } ?>
<?php if ($user_add->verification1->Visible) { // verification1 ?>
	<div id="r_verification1" class="form-group row">
		<label id="elh_user_verification1" for="x_verification1" class="<?php echo $user_add->LeftColumnClass ?>"><?php echo $user_add->verification1->caption() ?><?php echo $user_add->verification1->Required ? $Language->phrase("FieldRequiredIndicator") : "" ?></label>
		<div class="<?php echo $user_add->RightColumnClass ?>"><div <?php echo $user_add->verification1->cellAttributes() ?>>
<span id="el_user_verification1">
<input type="text" data-table="user" data-field="x_verification1" data-page="3" name="x_verification1" id="x_verification1" size="30" maxlength="60" placeholder="<?php echo HtmlEncode($user_add->verification1->getPlaceHolder()) ?>" value="<?php echo $user_add->verification1->EditValue ?>"<?php echo $user_add->verification1->editAttributes() ?>>
</span>
<?php echo $user_add->verification1->CustomMsg ?></div></div>
	</div>
<?php } ?>
<?php if ($user_add->verification2->Visible) { // verification2 ?>
	<div id="r_verification2" class="form-group row">
		<label id="elh_user_verification2" for="x_verification2" class="<?php echo $user_add->LeftColumnClass ?>"><?php echo $user_add->verification2->caption() ?><?php echo $user_add->verification2->Required ? $Language->phrase("FieldRequiredIndicator") : "" ?></label>
		<div class="<?php echo $user_add->RightColumnClass ?>"><div <?php echo $user_add->verification2->cellAttributes() ?>>
<span id="el_user_verification2">
<input type="text" data-table="user" data-field="x_verification2" data-page="3" name="x_verification2" id="x_verification2" size="30" maxlength="60" placeholder="<?php echo HtmlEncode($user_add->verification2->getPlaceHolder()) ?>" value="<?php echo $user_add->verification2->EditValue ?>"<?php echo $user_add->verification2->editAttributes() ?>>
</span>
<?php echo $user_add->verification2->CustomMsg ?></div></div>
	</div>
<?php } ?>
<?php if ($user_add->verification3->Visible) { // verification3 ?>
	<div id="r_verification3" class="form-group row">
		<label id="elh_user_verification3" for="x_verification3" class="<?php echo $user_add->LeftColumnClass ?>"><?php echo $user_add->verification3->caption() ?><?php echo $user_add->verification3->Required ? $Language->phrase("FieldRequiredIndicator") : "" ?></label>
		<div class="<?php echo $user_add->RightColumnClass ?>"><div <?php echo $user_add->verification3->cellAttributes() ?>>
<span id="el_user_verification3">
<input type="text" data-table="user" data-field="x_verification3" data-page="3" name="x_verification3" id="x_verification3" size="30" maxlength="60" placeholder="<?php echo HtmlEncode($user_add->verification3->getPlaceHolder()) ?>" value="<?php echo $user_add->verification3->EditValue ?>"<?php echo $user_add->verification3->editAttributes() ?>>
</span>
<?php echo $user_add->verification3->CustomMsg ?></div></div>
	</div>
<?php } ?>
<?php if ($user_add->passwordCounter->Visible) { // passwordCounter ?>
	<div id="r_passwordCounter" class="form-group row">
		<label id="elh_user_passwordCounter" for="x_passwordCounter" class="<?php echo $user_add->LeftColumnClass ?>"><?php echo $user_add->passwordCounter->caption() ?><?php echo $user_add->passwordCounter->Required ? $Language->phrase("FieldRequiredIndicator") : "" ?></label>
		<div class="<?php echo $user_add->RightColumnClass ?>"><div <?php echo $user_add->passwordCounter->cellAttributes() ?>>
<span id="el_user_passwordCounter">
<input type="text" data-table="user" data-field="x_passwordCounter" data-page="3" name="x_passwordCounter" id="x_passwordCounter" size="30" placeholder="<?php echo HtmlEncode($user_add->passwordCounter->getPlaceHolder()) ?>" value="<?php echo $user_add->passwordCounter->EditValue ?>"<?php echo $user_add->passwordCounter->editAttributes() ?>>
</span>
<?php echo $user_add->passwordCounter->CustomMsg ?></div></div>
	</div>
<?php } ?>
<?php if ($user_add->passwordChangedDate->Visible) { // passwordChangedDate ?>
	<div id="r_passwordChangedDate" class="form-group row">
		<label id="elh_user_passwordChangedDate" for="x_passwordChangedDate" class="<?php echo $user_add->LeftColumnClass ?>"><?php echo $user_add->passwordChangedDate->caption() ?><?php echo $user_add->passwordChangedDate->Required ? $Language->phrase("FieldRequiredIndicator") : "" ?></label>
		<div class="<?php echo $user_add->RightColumnClass ?>"><div <?php echo $user_add->passwordChangedDate->cellAttributes() ?>>
<span id="el_user_passwordChangedDate">
<input type="text" data-table="user" data-field="x_passwordChangedDate" data-page="3" data-format="1" name="x_passwordChangedDate" id="x_passwordChangedDate" placeholder="<?php echo HtmlEncode($user_add->passwordChangedDate->getPlaceHolder()) ?>" value="<?php echo $user_add->passwordChangedDate->EditValue ?>"<?php echo $user_add->passwordChangedDate->editAttributes() ?>>
<?php if (!$user_add->passwordChangedDate->ReadOnly && !$user_add->passwordChangedDate->Disabled && !isset($user_add->passwordChangedDate->EditAttrs["readonly"]) && !isset($user_add->passwordChangedDate->EditAttrs["disabled"])) { ?>
<script>
loadjs.ready(["fuseradd", "datetimepicker"], function() {
	ew.createDateTimePicker("fuseradd", "x_passwordChangedDate", {"ignoreReadonly":true,"useCurrent":false,"format":1});
});
</script>
<?php } ?>
</span>
<?php echo $user_add->passwordChangedDate->CustomMsg ?></div></div>
	</div>
<?php } ?>
<?php if ($user_add->pinCounter->Visible) { // pinCounter ?>
	<div id="r_pinCounter" class="form-group row">
		<label id="elh_user_pinCounter" for="x_pinCounter" class="<?php echo $user_add->LeftColumnClass ?>"><?php echo $user_add->pinCounter->caption() ?><?php echo $user_add->pinCounter->Required ? $Language->phrase("FieldRequiredIndicator") : "" ?></label>
		<div class="<?php echo $user_add->RightColumnClass ?>"><div <?php echo $user_add->pinCounter->cellAttributes() ?>>
<span id="el_user_pinCounter">
<input type="text" data-table="user" data-field="x_pinCounter" data-page="3" name="x_pinCounter" id="x_pinCounter" size="30" placeholder="<?php echo HtmlEncode($user_add->pinCounter->getPlaceHolder()) ?>" value="<?php echo $user_add->pinCounter->EditValue ?>"<?php echo $user_add->pinCounter->editAttributes() ?>>
</span>
<?php echo $user_add->pinCounter->CustomMsg ?></div></div>
	</div>
<?php } ?>
<?php if ($user_add->langID->Visible) { // langID ?>
	<div id="r_langID" class="form-group row">
		<label id="elh_user_langID" for="x_langID" class="<?php echo $user_add->LeftColumnClass ?>"><?php echo $user_add->langID->caption() ?><?php echo $user_add->langID->Required ? $Language->phrase("FieldRequiredIndicator") : "" ?></label>
		<div class="<?php echo $user_add->RightColumnClass ?>"><div <?php echo $user_add->langID->cellAttributes() ?>>
<span id="el_user_langID">
<div class="input-group">
	<select class="custom-select ew-custom-select" data-table="user" data-field="x_langID" data-page="3" data-value-separator="<?php echo $user_add->langID->displayValueSeparatorAttribute() ?>" id="x_langID" name="x_langID"<?php echo $user_add->langID->editAttributes() ?>>
			<?php echo $user_add->langID->selectOptionListHtml("x_langID") ?>
		</select>
</div>
<?php echo $user_add->langID->Lookup->getParamTag($user_add, "p_x_langID") ?>
</span>
<?php echo $user_add->langID->CustomMsg ?></div></div>
	</div>
<?php } ?>
<?php if ($user_add->photo->Visible) { // photo ?>
	<div id="r_photo" class="form-group row">
		<label id="elh_user_photo" class="<?php echo $user_add->LeftColumnClass ?>"><?php echo $user_add->photo->caption() ?><?php echo $user_add->photo->Required ? $Language->phrase("FieldRequiredIndicator") : "" ?></label>
		<div class="<?php echo $user_add->RightColumnClass ?>"><div <?php echo $user_add->photo->cellAttributes() ?>>
<span id="el_user_photo">
<div id="fd_x_photo">
<div class="input-group">
	<div class="custom-file">
		<input type="file" class="custom-file-input" title="<?php echo $user_add->photo->title() ?>" data-table="user" data-field="x_photo" data-page="3" name="x_photo" id="x_photo" lang="<?php echo CurrentLanguageID() ?>"<?php echo $user_add->photo->editAttributes() ?><?php if ($user_add->photo->ReadOnly || $user_add->photo->Disabled) echo " disabled"; ?>>
		<label class="custom-file-label ew-file-label" for="x_photo"><?php echo $Language->phrase("ChooseFile") ?></label>
	</div>
</div>
<input type="hidden" name="fn_x_photo" id= "fn_x_photo" value="<?php echo $user_add->photo->Upload->FileName ?>">
<input type="hidden" name="fa_x_photo" id= "fa_x_photo" value="0">
<input type="hidden" name="fs_x_photo" id= "fs_x_photo" value="30">
<input type="hidden" name="fx_x_photo" id= "fx_x_photo" value="<?php echo $user_add->photo->UploadAllowedFileExt ?>">
<input type="hidden" name="fm_x_photo" id= "fm_x_photo" value="<?php echo $user_add->photo->UploadMaxFileSize ?>">
</div>
<table id="ft_x_photo" class="table table-sm float-left ew-upload-table"><tbody class="files"></tbody></table>
</span>
<?php echo $user_add->photo->CustomMsg ?></div></div>
	</div>
<?php } ?>
<?php if ($user_add->status->Visible) { // status ?>
	<div id="r_status" class="form-group row">
		<label id="elh_user_status" for="x_status" class="<?php echo $user_add->LeftColumnClass ?>"><?php echo $user_add->status->caption() ?><?php echo $user_add->status->Required ? $Language->phrase("FieldRequiredIndicator") : "" ?></label>
		<div class="<?php echo $user_add->RightColumnClass ?>"><div <?php echo $user_add->status->cellAttributes() ?>>
<span id="el_user_status">
<div class="input-group">
	<select class="custom-select ew-custom-select" data-table="user" data-field="x_status" data-page="3" data-value-separator="<?php echo $user_add->status->displayValueSeparatorAttribute() ?>" id="x_status" name="x_status"<?php echo $user_add->status->editAttributes() ?>>
			<?php echo $user_add->status->selectOptionListHtml("x_status") ?>
		</select>
</div>
<?php echo $user_add->status->Lookup->getParamTag($user_add, "p_x_status") ?>
</span>
<?php echo $user_add->status->CustomMsg ?></div></div>
	</div>
<?php } ?>
<?php if ($user_add->markedfordeletion->Visible) { // markedfordeletion ?>
	<div id="r_markedfordeletion" class="form-group row">
		<label id="elh_user_markedfordeletion" for="x_markedfordeletion" class="<?php echo $user_add->LeftColumnClass ?>"><?php echo $user_add->markedfordeletion->caption() ?><?php echo $user_add->markedfordeletion->Required ? $Language->phrase("FieldRequiredIndicator") : "" ?></label>
		<div class="<?php echo $user_add->RightColumnClass ?>"><div <?php echo $user_add->markedfordeletion->cellAttributes() ?>>
<span id="el_user_markedfordeletion">
<input type="text" data-table="user" data-field="x_markedfordeletion" data-page="3" name="x_markedfordeletion" id="x_markedfordeletion" maxlength="10" placeholder="<?php echo HtmlEncode($user_add->markedfordeletion->getPlaceHolder()) ?>" value="<?php echo $user_add->markedfordeletion->EditValue ?>"<?php echo $user_add->markedfordeletion->editAttributes() ?>>
<?php if (!$user_add->markedfordeletion->ReadOnly && !$user_add->markedfordeletion->Disabled && !isset($user_add->markedfordeletion->EditAttrs["readonly"]) && !isset($user_add->markedfordeletion->EditAttrs["disabled"])) { ?>
<script>
loadjs.ready(["fuseradd", "datetimepicker"], function() {
	ew.createDateTimePicker("fuseradd", "x_markedfordeletion", {"ignoreReadonly":true,"useCurrent":false,"format":0});
});
</script>
<?php } ?>
</span>
<?php echo $user_add->markedfordeletion->CustomMsg ?></div></div>
	</div>
<?php } ?>
<?php if ($user_add->userType->Visible) { // userType ?>
	<div id="r_userType" class="form-group row">
		<label id="elh_user_userType" for="x_userType" class="<?php echo $user_add->LeftColumnClass ?>"><?php echo $user_add->userType->caption() ?><?php echo $user_add->userType->Required ? $Language->phrase("FieldRequiredIndicator") : "" ?></label>
		<div class="<?php echo $user_add->RightColumnClass ?>"><div <?php echo $user_add->userType->cellAttributes() ?>>
<span id="el_user_userType">
<?php $user_add->userType->EditAttrs->prepend("onchange", "ew.updateOptions.call(this);"); ?>
<div class="input-group">
	<select class="custom-select ew-custom-select" data-table="user" data-field="x_userType" data-page="3" data-value-separator="<?php echo $user_add->userType->displayValueSeparatorAttribute() ?>" id="x_userType" name="x_userType"<?php echo $user_add->userType->editAttributes() ?>>
			<?php echo $user_add->userType->selectOptionListHtml("x_userType") ?>
		</select>
</div>
<?php echo $user_add->userType->Lookup->getParamTag($user_add, "p_x_userType") ?>
</span>
<?php echo $user_add->userType->CustomMsg ?></div></div>
	</div>
<?php } ?>
<?php if ($user_add->usersubtype->Visible) { // usersubtype ?>
	<div id="r_usersubtype" class="form-group row">
		<label id="elh_user_usersubtype" for="x_usersubtype" class="<?php echo $user_add->LeftColumnClass ?>"><?php echo $user_add->usersubtype->caption() ?><?php echo $user_add->usersubtype->Required ? $Language->phrase("FieldRequiredIndicator") : "" ?></label>
		<div class="<?php echo $user_add->RightColumnClass ?>"><div <?php echo $user_add->usersubtype->cellAttributes() ?>>
<span id="el_user_usersubtype">
<div class="input-group">
	<select class="custom-select ew-custom-select" data-table="user" data-field="x_usersubtype" data-page="3" data-value-separator="<?php echo $user_add->usersubtype->displayValueSeparatorAttribute() ?>" id="x_usersubtype" name="x_usersubtype"<?php echo $user_add->usersubtype->editAttributes() ?>>
			<?php echo $user_add->usersubtype->selectOptionListHtml("x_usersubtype") ?>
		</select>
</div>
<?php echo $user_add->usersubtype->Lookup->getParamTag($user_add, "p_x_usersubtype") ?>
</span>
<?php echo $user_add->usersubtype->CustomMsg ?></div></div>
	</div>
<?php } ?>
<?php if ($user_add->brokerid->Visible) { // brokerid ?>
	<div id="r_brokerid" class="form-group row">
		<label id="elh_user_brokerid" for="x_brokerid" class="<?php echo $user_add->LeftColumnClass ?>"><?php echo $user_add->brokerid->caption() ?><?php echo $user_add->brokerid->Required ? $Language->phrase("FieldRequiredIndicator") : "" ?></label>
		<div class="<?php echo $user_add->RightColumnClass ?>"><div <?php echo $user_add->brokerid->cellAttributes() ?>>
<span id="el_user_brokerid">
<input type="text" data-table="user" data-field="x_brokerid" data-page="3" name="x_brokerid" id="x_brokerid" size="30" placeholder="<?php echo HtmlEncode($user_add->brokerid->getPlaceHolder()) ?>" value="<?php echo $user_add->brokerid->EditValue ?>"<?php echo $user_add->brokerid->editAttributes() ?>>
</span>
<?php echo $user_add->brokerid->CustomMsg ?></div></div>
	</div>
<?php } ?>
<?php if ($user_add->parentuserid->Visible) { // parentuserid ?>
	<div id="r_parentuserid" class="form-group row">
		<label id="elh_user_parentuserid" for="x_parentuserid" class="<?php echo $user_add->LeftColumnClass ?>"><?php echo $user_add->parentuserid->caption() ?><?php echo $user_add->parentuserid->Required ? $Language->phrase("FieldRequiredIndicator") : "" ?></label>
		<div class="<?php echo $user_add->RightColumnClass ?>"><div <?php echo $user_add->parentuserid->cellAttributes() ?>>
<span id="el_user_parentuserid">
<input type="text" data-table="user" data-field="x_parentuserid" data-page="3" name="x_parentuserid" id="x_parentuserid" size="30" placeholder="<?php echo HtmlEncode($user_add->parentuserid->getPlaceHolder()) ?>" value="<?php echo $user_add->parentuserid->EditValue ?>"<?php echo $user_add->parentuserid->editAttributes() ?>>
</span>
<?php echo $user_add->parentuserid->CustomMsg ?></div></div>
	</div>
<?php } ?>
<?php if ($user_add->corporate->Visible) { // corporate ?>
	<div id="r_corporate" class="form-group row">
		<label id="elh_user_corporate" class="<?php echo $user_add->LeftColumnClass ?>"><?php echo $user_add->corporate->caption() ?><?php echo $user_add->corporate->Required ? $Language->phrase("FieldRequiredIndicator") : "" ?></label>
		<div class="<?php echo $user_add->RightColumnClass ?>"><div <?php echo $user_add->corporate->cellAttributes() ?>>
<span id="el_user_corporate">
<div id="tp_x_corporate" class="ew-template"><input type="radio" class="custom-control-input" data-table="user" data-field="x_corporate" data-page="3" data-value-separator="<?php echo $user_add->corporate->displayValueSeparatorAttribute() ?>" name="x_corporate" id="x_corporate" value="{value}"<?php echo $user_add->corporate->editAttributes() ?>></div>
<div id="dsl_x_corporate" data-repeatcolumn="5" class="ew-item-list d-none"><div>
<?php echo $user_add->corporate->radioButtonListHtml(FALSE, "x_corporate", 3) ?>
</div></div>
<?php echo $user_add->corporate->Lookup->getParamTag($user_add, "p_x_corporate") ?>
</span>
<?php echo $user_add->corporate->CustomMsg ?></div></div>
	</div>
<?php } ?>
<?php if ($user_add->jumpappid->Visible) { // jumpappid ?>
	<div id="r_jumpappid" class="form-group row">
		<label id="elh_user_jumpappid" for="x_jumpappid" class="<?php echo $user_add->LeftColumnClass ?>"><?php echo $user_add->jumpappid->caption() ?><?php echo $user_add->jumpappid->Required ? $Language->phrase("FieldRequiredIndicator") : "" ?></label>
		<div class="<?php echo $user_add->RightColumnClass ?>"><div <?php echo $user_add->jumpappid->cellAttributes() ?>>
<span id="el_user_jumpappid">
<input type="text" data-table="user" data-field="x_jumpappid" data-page="3" name="x_jumpappid" id="x_jumpappid" size="30" placeholder="<?php echo HtmlEncode($user_add->jumpappid->getPlaceHolder()) ?>" value="<?php echo $user_add->jumpappid->EditValue ?>"<?php echo $user_add->jumpappid->editAttributes() ?>>
</span>
<?php echo $user_add->jumpappid->CustomMsg ?></div></div>
	</div>
<?php } ?>
<?php if ($user_add->jumprequiredatlogin->Visible) { // jumprequiredatlogin ?>
	<div id="r_jumprequiredatlogin" class="form-group row">
		<label id="elh_user_jumprequiredatlogin" class="<?php echo $user_add->LeftColumnClass ?>"><?php echo $user_add->jumprequiredatlogin->caption() ?><?php echo $user_add->jumprequiredatlogin->Required ? $Language->phrase("FieldRequiredIndicator") : "" ?></label>
		<div class="<?php echo $user_add->RightColumnClass ?>"><div <?php echo $user_add->jumprequiredatlogin->cellAttributes() ?>>
<span id="el_user_jumprequiredatlogin">
<div id="tp_x_jumprequiredatlogin" class="ew-template"><input type="radio" class="custom-control-input" data-table="user" data-field="x_jumprequiredatlogin" data-page="3" data-value-separator="<?php echo $user_add->jumprequiredatlogin->displayValueSeparatorAttribute() ?>" name="x_jumprequiredatlogin" id="x_jumprequiredatlogin" value="{value}"<?php echo $user_add->jumprequiredatlogin->editAttributes() ?>></div>
<div id="dsl_x_jumprequiredatlogin" data-repeatcolumn="5" class="ew-item-list d-none"><div>
<?php echo $user_add->jumprequiredatlogin->radioButtonListHtml(FALSE, "x_jumprequiredatlogin", 3) ?>
</div></div>
<?php echo $user_add->jumprequiredatlogin->Lookup->getParamTag($user_add, "p_x_jumprequiredatlogin") ?>
</span>
<?php echo $user_add->jumprequiredatlogin->CustomMsg ?></div></div>
	</div>
<?php } ?>
<?php if ($user_add->ccbypass->Visible) { // ccbypass ?>
	<div id="r_ccbypass" class="form-group row">
		<label id="elh_user_ccbypass" class="<?php echo $user_add->LeftColumnClass ?>"><?php echo $user_add->ccbypass->caption() ?><?php echo $user_add->ccbypass->Required ? $Language->phrase("FieldRequiredIndicator") : "" ?></label>
		<div class="<?php echo $user_add->RightColumnClass ?>"><div <?php echo $user_add->ccbypass->cellAttributes() ?>>
<span id="el_user_ccbypass">
<div id="tp_x_ccbypass" class="ew-template"><input type="radio" class="custom-control-input" data-table="user" data-field="x_ccbypass" data-page="3" data-value-separator="<?php echo $user_add->ccbypass->displayValueSeparatorAttribute() ?>" name="x_ccbypass" id="x_ccbypass" value="{value}"<?php echo $user_add->ccbypass->editAttributes() ?>></div>
<div id="dsl_x_ccbypass" data-repeatcolumn="5" class="ew-item-list d-none"><div>
<?php echo $user_add->ccbypass->radioButtonListHtml(FALSE, "x_ccbypass", 3) ?>
</div></div>
<?php echo $user_add->ccbypass->Lookup->getParamTag($user_add, "p_x_ccbypass") ?>
</span>
<?php echo $user_add->ccbypass->CustomMsg ?></div></div>
	</div>
<?php } ?>
<?php if ($user_add->other1->Visible) { // other1 ?>
	<div id="r_other1" class="form-group row">
		<label id="elh_user_other1" for="x_other1" class="<?php echo $user_add->LeftColumnClass ?>"><?php echo $user_add->other1->caption() ?><?php echo $user_add->other1->Required ? $Language->phrase("FieldRequiredIndicator") : "" ?></label>
		<div class="<?php echo $user_add->RightColumnClass ?>"><div <?php echo $user_add->other1->cellAttributes() ?>>
<span id="el_user_other1">
<input type="text" data-table="user" data-field="x_other1" data-page="3" name="x_other1" id="x_other1" size="30" maxlength="25" placeholder="<?php echo HtmlEncode($user_add->other1->getPlaceHolder()) ?>" value="<?php echo $user_add->other1->EditValue ?>"<?php echo $user_add->other1->editAttributes() ?>>
</span>
<?php echo $user_add->other1->CustomMsg ?></div></div>
	</div>
<?php } ?>
<?php if ($user_add->other2->Visible) { // other2 ?>
	<div id="r_other2" class="form-group row">
		<label id="elh_user_other2" for="x_other2" class="<?php echo $user_add->LeftColumnClass ?>"><?php echo $user_add->other2->caption() ?><?php echo $user_add->other2->Required ? $Language->phrase("FieldRequiredIndicator") : "" ?></label>
		<div class="<?php echo $user_add->RightColumnClass ?>"><div <?php echo $user_add->other2->cellAttributes() ?>>
<span id="el_user_other2">
<input type="text" data-table="user" data-field="x_other2" data-page="3" name="x_other2" id="x_other2" size="30" maxlength="25" placeholder="<?php echo HtmlEncode($user_add->other2->getPlaceHolder()) ?>" value="<?php echo $user_add->other2->EditValue ?>"<?php echo $user_add->other2->editAttributes() ?>>
</span>
<?php echo $user_add->other2->CustomMsg ?></div></div>
	</div>
<?php } ?>
<?php if ($user_add->other3->Visible) { // other3 ?>
	<div id="r_other3" class="form-group row">
		<label id="elh_user_other3" for="x_other3" class="<?php echo $user_add->LeftColumnClass ?>"><?php echo $user_add->other3->caption() ?><?php echo $user_add->other3->Required ? $Language->phrase("FieldRequiredIndicator") : "" ?></label>
		<div class="<?php echo $user_add->RightColumnClass ?>"><div <?php echo $user_add->other3->cellAttributes() ?>>
<span id="el_user_other3">
<input type="text" data-table="user" data-field="x_other3" data-page="3" name="x_other3" id="x_other3" size="30" maxlength="25" placeholder="<?php echo HtmlEncode($user_add->other3->getPlaceHolder()) ?>" value="<?php echo $user_add->other3->EditValue ?>"<?php echo $user_add->other3->editAttributes() ?>>
</span>
<?php echo $user_add->other3->CustomMsg ?></div></div>
	</div>
<?php } ?>
<?php if ($user_add->other4->Visible) { // other4 ?>
	<div id="r_other4" class="form-group row">
		<label id="elh_user_other4" for="x_other4" class="<?php echo $user_add->LeftColumnClass ?>"><?php echo $user_add->other4->caption() ?><?php echo $user_add->other4->Required ? $Language->phrase("FieldRequiredIndicator") : "" ?></label>
		<div class="<?php echo $user_add->RightColumnClass ?>"><div <?php echo $user_add->other4->cellAttributes() ?>>
<span id="el_user_other4">
<input type="text" data-table="user" data-field="x_other4" data-page="3" name="x_other4" id="x_other4" size="30" maxlength="25" placeholder="<?php echo HtmlEncode($user_add->other4->getPlaceHolder()) ?>" value="<?php echo $user_add->other4->EditValue ?>"<?php echo $user_add->other4->editAttributes() ?>>
</span>
<?php echo $user_add->other4->CustomMsg ?></div></div>
	</div>
<?php } ?>
<?php if ($user_add->other5->Visible) { // other5 ?>
	<div id="r_other5" class="form-group row">
		<label id="elh_user_other5" for="x_other5" class="<?php echo $user_add->LeftColumnClass ?>"><?php echo $user_add->other5->caption() ?><?php echo $user_add->other5->Required ? $Language->phrase("FieldRequiredIndicator") : "" ?></label>
		<div class="<?php echo $user_add->RightColumnClass ?>"><div <?php echo $user_add->other5->cellAttributes() ?>>
<span id="el_user_other5">
<input type="text" data-table="user" data-field="x_other5" data-page="3" name="x_other5" id="x_other5" size="30" maxlength="25" placeholder="<?php echo HtmlEncode($user_add->other5->getPlaceHolder()) ?>" value="<?php echo $user_add->other5->EditValue ?>"<?php echo $user_add->other5->editAttributes() ?>>
</span>
<?php echo $user_add->other5->CustomMsg ?></div></div>
	</div>
<?php } ?>
<?php if ($user_add->other6->Visible) { // other6 ?>
	<div id="r_other6" class="form-group row">
		<label id="elh_user_other6" for="x_other6" class="<?php echo $user_add->LeftColumnClass ?>"><?php echo $user_add->other6->caption() ?><?php echo $user_add->other6->Required ? $Language->phrase("FieldRequiredIndicator") : "" ?></label>
		<div class="<?php echo $user_add->RightColumnClass ?>"><div <?php echo $user_add->other6->cellAttributes() ?>>
<span id="el_user_other6">
<input type="text" data-table="user" data-field="x_other6" data-page="3" name="x_other6" id="x_other6" size="30" maxlength="25" placeholder="<?php echo HtmlEncode($user_add->other6->getPlaceHolder()) ?>" value="<?php echo $user_add->other6->EditValue ?>"<?php echo $user_add->other6->editAttributes() ?>>
</span>
<?php echo $user_add->other6->CustomMsg ?></div></div>
	</div>
<?php } ?>
<?php if ($user_add->legalid->Visible) { // legalid ?>
	<div id="r_legalid" class="form-group row">
		<label id="elh_user_legalid" for="x_legalid" class="<?php echo $user_add->LeftColumnClass ?>"><?php echo $user_add->legalid->caption() ?><?php echo $user_add->legalid->Required ? $Language->phrase("FieldRequiredIndicator") : "" ?></label>
		<div class="<?php echo $user_add->RightColumnClass ?>"><div <?php echo $user_add->legalid->cellAttributes() ?>>
<span id="el_user_legalid">
<input type="text" data-table="user" data-field="x_legalid" data-page="3" name="x_legalid" id="x_legalid" size="30" placeholder="<?php echo HtmlEncode($user_add->legalid->getPlaceHolder()) ?>" value="<?php echo $user_add->legalid->EditValue ?>"<?php echo $user_add->legalid->editAttributes() ?>>
</span>
<?php echo $user_add->legalid->CustomMsg ?></div></div>
	</div>
<?php } ?>
<?php if ($user_add->userpiview->Visible) { // userpiview ?>
	<div id="r_userpiview" class="form-group row">
		<label id="elh_user_userpiview" class="<?php echo $user_add->LeftColumnClass ?>"><?php echo $user_add->userpiview->caption() ?><?php echo $user_add->userpiview->Required ? $Language->phrase("FieldRequiredIndicator") : "" ?></label>
		<div class="<?php echo $user_add->RightColumnClass ?>"><div <?php echo $user_add->userpiview->cellAttributes() ?>>
<span id="el_user_userpiview">
<div id="tp_x_userpiview" class="ew-template"><input type="radio" class="custom-control-input" data-table="user" data-field="x_userpiview" data-page="3" data-value-separator="<?php echo $user_add->userpiview->displayValueSeparatorAttribute() ?>" name="x_userpiview" id="x_userpiview" value="{value}"<?php echo $user_add->userpiview->editAttributes() ?>></div>
<div id="dsl_x_userpiview" data-repeatcolumn="5" class="ew-item-list d-none"><div>
<?php echo $user_add->userpiview->radioButtonListHtml(FALSE, "x_userpiview", 3) ?>
</div></div>
<?php echo $user_add->userpiview->Lookup->getParamTag($user_add, "p_x_userpiview") ?>
</span>
<?php echo $user_add->userpiview->CustomMsg ?></div></div>
	</div>
<?php } ?>
<?php if ($user_add->lastmsgid->Visible) { // lastmsgid ?>
	<div id="r_lastmsgid" class="form-group row">
		<label id="elh_user_lastmsgid" for="x_lastmsgid" class="<?php echo $user_add->LeftColumnClass ?>"><?php echo $user_add->lastmsgid->caption() ?><?php echo $user_add->lastmsgid->Required ? $Language->phrase("FieldRequiredIndicator") : "" ?></label>
		<div class="<?php echo $user_add->RightColumnClass ?>"><div <?php echo $user_add->lastmsgid->cellAttributes() ?>>
<span id="el_user_lastmsgid">
<input type="text" data-table="user" data-field="x_lastmsgid" data-page="3" name="x_lastmsgid" id="x_lastmsgid" size="30" placeholder="<?php echo HtmlEncode($user_add->lastmsgid->getPlaceHolder()) ?>" value="<?php echo $user_add->lastmsgid->EditValue ?>"<?php echo $user_add->lastmsgid->editAttributes() ?>>
</span>
<?php echo $user_add->lastmsgid->CustomMsg ?></div></div>
	</div>
<?php } ?>
</div><!-- /page* -->
		</div><!-- /multi-page .tab-pane -->
		<div class="tab-pane<?php echo $user_add->MultiPages->pageStyle(4) ?>" id="tab_user4"><!-- multi-page .tab-pane -->
<div class="ew-add-div"><!-- page* -->
<?php if ($user_add->mincashamount->Visible) { // mincashamount ?>
	<div id="r_mincashamount" class="form-group row">
		<label id="elh_user_mincashamount" for="x_mincashamount" class="<?php echo $user_add->LeftColumnClass ?>"><?php echo $user_add->mincashamount->caption() ?><?php echo $user_add->mincashamount->Required ? $Language->phrase("FieldRequiredIndicator") : "" ?></label>
		<div class="<?php echo $user_add->RightColumnClass ?>"><div <?php echo $user_add->mincashamount->cellAttributes() ?>>
<span id="el_user_mincashamount">
<input type="text" data-table="user" data-field="x_mincashamount" data-page="4" name="x_mincashamount" id="x_mincashamount" size="30" placeholder="<?php echo HtmlEncode($user_add->mincashamount->getPlaceHolder()) ?>" value="<?php echo $user_add->mincashamount->EditValue ?>"<?php echo $user_add->mincashamount->editAttributes() ?>>
</span>
<?php echo $user_add->mincashamount->CustomMsg ?></div></div>
	</div>
<?php } ?>
<?php if ($user_add->maxcashamount->Visible) { // maxcashamount ?>
	<div id="r_maxcashamount" class="form-group row">
		<label id="elh_user_maxcashamount" for="x_maxcashamount" class="<?php echo $user_add->LeftColumnClass ?>"><?php echo $user_add->maxcashamount->caption() ?><?php echo $user_add->maxcashamount->Required ? $Language->phrase("FieldRequiredIndicator") : "" ?></label>
		<div class="<?php echo $user_add->RightColumnClass ?>"><div <?php echo $user_add->maxcashamount->cellAttributes() ?>>
<span id="el_user_maxcashamount">
<input type="text" data-table="user" data-field="x_maxcashamount" data-page="4" name="x_maxcashamount" id="x_maxcashamount" size="30" placeholder="<?php echo HtmlEncode($user_add->maxcashamount->getPlaceHolder()) ?>" value="<?php echo $user_add->maxcashamount->EditValue ?>"<?php echo $user_add->maxcashamount->editAttributes() ?>>
</span>
<?php echo $user_add->maxcashamount->CustomMsg ?></div></div>
	</div>
<?php } ?>
<?php if ($user_add->maxtransferinamount->Visible) { // maxtransferinamount ?>
	<div id="r_maxtransferinamount" class="form-group row">
		<label id="elh_user_maxtransferinamount" for="x_maxtransferinamount" class="<?php echo $user_add->LeftColumnClass ?>"><?php echo $user_add->maxtransferinamount->caption() ?><?php echo $user_add->maxtransferinamount->Required ? $Language->phrase("FieldRequiredIndicator") : "" ?></label>
		<div class="<?php echo $user_add->RightColumnClass ?>"><div <?php echo $user_add->maxtransferinamount->cellAttributes() ?>>
<span id="el_user_maxtransferinamount">
<input type="text" data-table="user" data-field="x_maxtransferinamount" data-page="4" name="x_maxtransferinamount" id="x_maxtransferinamount" size="30" placeholder="<?php echo HtmlEncode($user_add->maxtransferinamount->getPlaceHolder()) ?>" value="<?php echo $user_add->maxtransferinamount->EditValue ?>"<?php echo $user_add->maxtransferinamount->editAttributes() ?>>
</span>
<?php echo $user_add->maxtransferinamount->CustomMsg ?></div></div>
	</div>
<?php } ?>
<?php if ($user_add->maxtransferoutamount->Visible) { // maxtransferoutamount ?>
	<div id="r_maxtransferoutamount" class="form-group row">
		<label id="elh_user_maxtransferoutamount" for="x_maxtransferoutamount" class="<?php echo $user_add->LeftColumnClass ?>"><?php echo $user_add->maxtransferoutamount->caption() ?><?php echo $user_add->maxtransferoutamount->Required ? $Language->phrase("FieldRequiredIndicator") : "" ?></label>
		<div class="<?php echo $user_add->RightColumnClass ?>"><div <?php echo $user_add->maxtransferoutamount->cellAttributes() ?>>
<span id="el_user_maxtransferoutamount">
<input type="text" data-table="user" data-field="x_maxtransferoutamount" data-page="4" name="x_maxtransferoutamount" id="x_maxtransferoutamount" size="30" placeholder="<?php echo HtmlEncode($user_add->maxtransferoutamount->getPlaceHolder()) ?>" value="<?php echo $user_add->maxtransferoutamount->EditValue ?>"<?php echo $user_add->maxtransferoutamount->editAttributes() ?>>
</span>
<?php echo $user_add->maxtransferoutamount->CustomMsg ?></div></div>
	</div>
<?php } ?>
</div><!-- /page* -->
		</div><!-- /multi-page .tab-pane -->
	</div><!-- /multi-page tabs .tab-content -->
</div><!-- /multi-page tabs -->
</div><!-- /multi-page -->
<?php if ($user->getCurrentDetailTable() != "") { ?>
<?php
	$user_add->DetailPages->ValidKeys = explode(",", $user->getCurrentDetailTable());
	$firstActiveDetailTable = $user_add->DetailPages->activePageIndex();
?>
<div class="ew-detail-pages"><!-- detail-pages -->
<div class="ew-nav-tabs" id="user_add_details"><!-- tabs -->
	<ul class="<?php echo $user_add->DetailPages->navStyle() ?>"><!-- .nav -->
<?php
	if (in_array("userpasswordhistory", explode(",", $user->getCurrentDetailTable())) && $userpasswordhistory->DetailAdd) {
		if ($firstActiveDetailTable == "" || $firstActiveDetailTable == "userpasswordhistory") {
			$firstActiveDetailTable = "userpasswordhistory";
		}
?>
		<li class="nav-item"><a class="nav-link <?php echo $user_add->DetailPages->pageStyle("userpasswordhistory") ?>" href="#tab_userpasswordhistory" data-toggle="tab"><?php echo $Language->tablePhrase("userpasswordhistory", "TblCaption") ?></a></li>
<?php
	}
?>
<?php
	if (in_array("userpinhistory", explode(",", $user->getCurrentDetailTable())) && $userpinhistory->DetailAdd) {
		if ($firstActiveDetailTable == "" || $firstActiveDetailTable == "userpinhistory") {
			$firstActiveDetailTable = "userpinhistory";
		}
?>
		<li class="nav-item"><a class="nav-link <?php echo $user_add->DetailPages->pageStyle("userpinhistory") ?>" href="#tab_userpinhistory" data-toggle="tab"><?php echo $Language->tablePhrase("userpinhistory", "TblCaption") ?></a></li>
<?php
	}
?>
<?php
	if (in_array("userchildren", explode(",", $user->getCurrentDetailTable())) && $userchildren->DetailAdd) {
		if ($firstActiveDetailTable == "" || $firstActiveDetailTable == "userchildren") {
			$firstActiveDetailTable = "userchildren";
		}
?>
		<li class="nav-item"><a class="nav-link <?php echo $user_add->DetailPages->pageStyle("userchildren") ?>" href="#tab_userchildren" data-toggle="tab"><?php echo $Language->tablePhrase("userchildren", "TblCaption") ?></a></li>
<?php
	}
?>
<?php
	if (in_array("usercontactlist", explode(",", $user->getCurrentDetailTable())) && $usercontactlist->DetailAdd) {
		if ($firstActiveDetailTable == "" || $firstActiveDetailTable == "usercontactlist") {
			$firstActiveDetailTable = "usercontactlist";
		}
?>
		<li class="nav-item"><a class="nav-link <?php echo $user_add->DetailPages->pageStyle("usercontactlist") ?>" href="#tab_usercontactlist" data-toggle="tab"><?php echo $Language->tablePhrase("usercontactlist", "TblCaption") ?></a></li>
<?php
	}
?>
<?php
	if (in_array("securityuserrole", explode(",", $user->getCurrentDetailTable())) && $securityuserrole->DetailAdd) {
		if ($firstActiveDetailTable == "" || $firstActiveDetailTable == "securityuserrole") {
			$firstActiveDetailTable = "securityuserrole";
		}
?>
		<li class="nav-item"><a class="nav-link <?php echo $user_add->DetailPages->pageStyle("securityuserrole") ?>" href="#tab_securityuserrole" data-toggle="tab"><?php echo $Language->tablePhrase("securityuserrole", "TblCaption") ?></a></li>
<?php
	}
?>
<?php
	if (in_array("mailbox", explode(",", $user->getCurrentDetailTable())) && $mailbox->DetailAdd) {
		if ($firstActiveDetailTable == "" || $firstActiveDetailTable == "mailbox") {
			$firstActiveDetailTable = "mailbox";
		}
?>
		<li class="nav-item"><a class="nav-link <?php echo $user_add->DetailPages->pageStyle("mailbox") ?>" href="#tab_mailbox" data-toggle="tab"><?php echo $Language->tablePhrase("mailbox", "TblCaption") ?></a></li>
<?php
	}
?>
<?php
	if (in_array("balanceinquiryhistory", explode(",", $user->getCurrentDetailTable())) && $balanceinquiryhistory->DetailAdd) {
		if ($firstActiveDetailTable == "" || $firstActiveDetailTable == "balanceinquiryhistory") {
			$firstActiveDetailTable = "balanceinquiryhistory";
		}
?>
		<li class="nav-item"><a class="nav-link <?php echo $user_add->DetailPages->pageStyle("balanceinquiryhistory") ?>" href="#tab_balanceinquiryhistory" data-toggle="tab"><?php echo $Language->tablePhrase("balanceinquiryhistory", "TblCaption") ?></a></li>
<?php
	}
?>
<?php
	if (in_array("usersession", explode(",", $user->getCurrentDetailTable())) && $usersession->DetailAdd) {
		if ($firstActiveDetailTable == "" || $firstActiveDetailTable == "usersession") {
			$firstActiveDetailTable = "usersession";
		}
?>
		<li class="nav-item"><a class="nav-link <?php echo $user_add->DetailPages->pageStyle("usersession") ?>" href="#tab_usersession" data-toggle="tab"><?php echo $Language->tablePhrase("usersession", "TblCaption") ?></a></li>
<?php
	}
?>
<?php
	if (in_array("vtranshistorybyuser", explode(",", $user->getCurrentDetailTable())) && $vtranshistorybyuser->DetailAdd) {
		if ($firstActiveDetailTable == "" || $firstActiveDetailTable == "vtranshistorybyuser") {
			$firstActiveDetailTable = "vtranshistorybyuser";
		}
?>
		<li class="nav-item"><a class="nav-link <?php echo $user_add->DetailPages->pageStyle("vtranshistorybyuser") ?>" href="#tab_vtranshistorybyuser" data-toggle="tab"><?php echo $Language->tablePhrase("vtranshistorybyuser", "TblCaption") ?></a></li>
<?php
	}
?>
<?php
	if (in_array("vtranssummary", explode(",", $user->getCurrentDetailTable())) && $vtranssummary->DetailAdd) {
		if ($firstActiveDetailTable == "" || $firstActiveDetailTable == "vtranssummary") {
			$firstActiveDetailTable = "vtranssummary";
		}
?>
		<li class="nav-item"><a class="nav-link <?php echo $user_add->DetailPages->pageStyle("vtranssummary") ?>" href="#tab_vtranssummary" data-toggle="tab"><?php echo $Language->tablePhrase("vtranssummary", "TblCaption") ?></a></li>
<?php
	}
?>
<?php
	if (in_array("useremailaccount", explode(",", $user->getCurrentDetailTable())) && $useremailaccount->DetailAdd) {
		if ($firstActiveDetailTable == "" || $firstActiveDetailTable == "useremailaccount") {
			$firstActiveDetailTable = "useremailaccount";
		}
?>
		<li class="nav-item"><a class="nav-link <?php echo $user_add->DetailPages->pageStyle("useremailaccount") ?>" href="#tab_useremailaccount" data-toggle="tab"><?php echo $Language->tablePhrase("useremailaccount", "TblCaption") ?></a></li>
<?php
	}
?>
<?php
	if (in_array("userpi", explode(",", $user->getCurrentDetailTable())) && $userpi->DetailAdd) {
		if ($firstActiveDetailTable == "" || $firstActiveDetailTable == "userpi") {
			$firstActiveDetailTable = "userpi";
		}
?>
		<li class="nav-item"><a class="nav-link <?php echo $user_add->DetailPages->pageStyle("userpi") ?>" href="#tab_userpi" data-toggle="tab"><?php echo $Language->tablePhrase("userpi", "TblCaption") ?></a></li>
<?php
	}
?>
<?php
	if (in_array("userpurchase", explode(",", $user->getCurrentDetailTable())) && $userpurchase->DetailAdd) {
		if ($firstActiveDetailTable == "" || $firstActiveDetailTable == "userpurchase") {
			$firstActiveDetailTable = "userpurchase";
		}
?>
		<li class="nav-item"><a class="nav-link <?php echo $user_add->DetailPages->pageStyle("userpurchase") ?>" href="#tab_userpurchase" data-toggle="tab"><?php echo $Language->tablePhrase("userpurchase", "TblCaption") ?></a></li>
<?php
	}
?>
<?php
	if (in_array("loanlimits", explode(",", $user->getCurrentDetailTable())) && $loanlimits->DetailAdd) {
		if ($firstActiveDetailTable == "" || $firstActiveDetailTable == "loanlimits") {
			$firstActiveDetailTable = "loanlimits";
		}
?>
		<li class="nav-item"><a class="nav-link <?php echo $user_add->DetailPages->pageStyle("loanlimits") ?>" href="#tab_loanlimits" data-toggle="tab"><?php echo $Language->tablePhrase("loanlimits", "TblCaption") ?></a></li>
<?php
	}
?>
<?php
	if (in_array("userkycdocs", explode(",", $user->getCurrentDetailTable())) && $userkycdocs->DetailAdd) {
		if ($firstActiveDetailTable == "" || $firstActiveDetailTable == "userkycdocs") {
			$firstActiveDetailTable = "userkycdocs";
		}
?>
		<li class="nav-item"><a class="nav-link <?php echo $user_add->DetailPages->pageStyle("userkycdocs") ?>" href="#tab_userkycdocs" data-toggle="tab"><?php echo $Language->tablePhrase("userkycdocs", "TblCaption") ?></a></li>
<?php
	}
?>
<?php
	if (in_array("acctbalance", explode(",", $user->getCurrentDetailTable())) && $acctbalance->DetailAdd) {
		if ($firstActiveDetailTable == "" || $firstActiveDetailTable == "acctbalance") {
			$firstActiveDetailTable = "acctbalance";
		}
?>
		<li class="nav-item"><a class="nav-link <?php echo $user_add->DetailPages->pageStyle("acctbalance") ?>" href="#tab_acctbalance" data-toggle="tab"><?php echo $Language->tablePhrase("acctbalance", "TblCaption") ?></a></li>
<?php
	}
?>
<?php
	if (in_array("userdevices", explode(",", $user->getCurrentDetailTable())) && $userdevices->DetailAdd) {
		if ($firstActiveDetailTable == "" || $firstActiveDetailTable == "userdevices") {
			$firstActiveDetailTable = "userdevices";
		}
?>
		<li class="nav-item"><a class="nav-link <?php echo $user_add->DetailPages->pageStyle("userdevices") ?>" href="#tab_userdevices" data-toggle="tab"><?php echo $Language->tablePhrase("userdevices", "TblCaption") ?></a></li>
<?php
	}
?>
<?php
	if (in_array("usercommission", explode(",", $user->getCurrentDetailTable())) && $usercommission->DetailAdd) {
		if ($firstActiveDetailTable == "" || $firstActiveDetailTable == "usercommission") {
			$firstActiveDetailTable = "usercommission";
		}
?>
		<li class="nav-item"><a class="nav-link <?php echo $user_add->DetailPages->pageStyle("usercommission") ?>" href="#tab_usercommission" data-toggle="tab"><?php echo $Language->tablePhrase("usercommission", "TblCaption") ?></a></li>
<?php
	}
?>
	</ul><!-- /.nav -->
	<div class="tab-content"><!-- .tab-content -->
<?php
	if (in_array("userpasswordhistory", explode(",", $user->getCurrentDetailTable())) && $userpasswordhistory->DetailAdd) {
		if ($firstActiveDetailTable == "" || $firstActiveDetailTable == "userpasswordhistory")
			$firstActiveDetailTable = "userpasswordhistory";
?>
		<div class="tab-pane <?php echo $user_add->DetailPages->pageStyle("userpasswordhistory") ?>" id="tab_userpasswordhistory"><!-- page* -->
<?php include_once "userpasswordhistorygrid.php" ?>
		</div><!-- /page* -->
<?php } ?>
<?php
	if (in_array("userpinhistory", explode(",", $user->getCurrentDetailTable())) && $userpinhistory->DetailAdd) {
		if ($firstActiveDetailTable == "" || $firstActiveDetailTable == "userpinhistory")
			$firstActiveDetailTable = "userpinhistory";
?>
		<div class="tab-pane <?php echo $user_add->DetailPages->pageStyle("userpinhistory") ?>" id="tab_userpinhistory"><!-- page* -->
<?php include_once "userpinhistorygrid.php" ?>
		</div><!-- /page* -->
<?php } ?>
<?php
	if (in_array("userchildren", explode(",", $user->getCurrentDetailTable())) && $userchildren->DetailAdd) {
		if ($firstActiveDetailTable == "" || $firstActiveDetailTable == "userchildren")
			$firstActiveDetailTable = "userchildren";
?>
		<div class="tab-pane <?php echo $user_add->DetailPages->pageStyle("userchildren") ?>" id="tab_userchildren"><!-- page* -->
<?php include_once "userchildrengrid.php" ?>
		</div><!-- /page* -->
<?php } ?>
<?php
	if (in_array("usercontactlist", explode(",", $user->getCurrentDetailTable())) && $usercontactlist->DetailAdd) {
		if ($firstActiveDetailTable == "" || $firstActiveDetailTable == "usercontactlist")
			$firstActiveDetailTable = "usercontactlist";
?>
		<div class="tab-pane <?php echo $user_add->DetailPages->pageStyle("usercontactlist") ?>" id="tab_usercontactlist"><!-- page* -->
<?php include_once "usercontactlistgrid.php" ?>
		</div><!-- /page* -->
<?php } ?>
<?php
	if (in_array("securityuserrole", explode(",", $user->getCurrentDetailTable())) && $securityuserrole->DetailAdd) {
		if ($firstActiveDetailTable == "" || $firstActiveDetailTable == "securityuserrole")
			$firstActiveDetailTable = "securityuserrole";
?>
		<div class="tab-pane <?php echo $user_add->DetailPages->pageStyle("securityuserrole") ?>" id="tab_securityuserrole"><!-- page* -->
<?php include_once "securityuserrolegrid.php" ?>
		</div><!-- /page* -->
<?php } ?>
<?php
	if (in_array("mailbox", explode(",", $user->getCurrentDetailTable())) && $mailbox->DetailAdd) {
		if ($firstActiveDetailTable == "" || $firstActiveDetailTable == "mailbox")
			$firstActiveDetailTable = "mailbox";
?>
		<div class="tab-pane <?php echo $user_add->DetailPages->pageStyle("mailbox") ?>" id="tab_mailbox"><!-- page* -->
<?php include_once "mailboxgrid.php" ?>
		</div><!-- /page* -->
<?php } ?>
<?php
	if (in_array("balanceinquiryhistory", explode(",", $user->getCurrentDetailTable())) && $balanceinquiryhistory->DetailAdd) {
		if ($firstActiveDetailTable == "" || $firstActiveDetailTable == "balanceinquiryhistory")
			$firstActiveDetailTable = "balanceinquiryhistory";
?>
		<div class="tab-pane <?php echo $user_add->DetailPages->pageStyle("balanceinquiryhistory") ?>" id="tab_balanceinquiryhistory"><!-- page* -->
<?php include_once "balanceinquiryhistorygrid.php" ?>
		</div><!-- /page* -->
<?php } ?>
<?php
	if (in_array("usersession", explode(",", $user->getCurrentDetailTable())) && $usersession->DetailAdd) {
		if ($firstActiveDetailTable == "" || $firstActiveDetailTable == "usersession")
			$firstActiveDetailTable = "usersession";
?>
		<div class="tab-pane <?php echo $user_add->DetailPages->pageStyle("usersession") ?>" id="tab_usersession"><!-- page* -->
<?php include_once "usersessiongrid.php" ?>
		</div><!-- /page* -->
<?php } ?>
<?php
	if (in_array("vtranshistorybyuser", explode(",", $user->getCurrentDetailTable())) && $vtranshistorybyuser->DetailAdd) {
		if ($firstActiveDetailTable == "" || $firstActiveDetailTable == "vtranshistorybyuser")
			$firstActiveDetailTable = "vtranshistorybyuser";
?>
		<div class="tab-pane <?php echo $user_add->DetailPages->pageStyle("vtranshistorybyuser") ?>" id="tab_vtranshistorybyuser"><!-- page* -->
<?php include_once "vtranshistorybyusergrid.php" ?>
		</div><!-- /page* -->
<?php } ?>
<?php
	if (in_array("vtranssummary", explode(",", $user->getCurrentDetailTable())) && $vtranssummary->DetailAdd) {
		if ($firstActiveDetailTable == "" || $firstActiveDetailTable == "vtranssummary")
			$firstActiveDetailTable = "vtranssummary";
?>
		<div class="tab-pane <?php echo $user_add->DetailPages->pageStyle("vtranssummary") ?>" id="tab_vtranssummary"><!-- page* -->
<?php include_once "vtranssummarygrid.php" ?>
		</div><!-- /page* -->
<?php } ?>
<?php
	if (in_array("useremailaccount", explode(",", $user->getCurrentDetailTable())) && $useremailaccount->DetailAdd) {
		if ($firstActiveDetailTable == "" || $firstActiveDetailTable == "useremailaccount")
			$firstActiveDetailTable = "useremailaccount";
?>
		<div class="tab-pane <?php echo $user_add->DetailPages->pageStyle("useremailaccount") ?>" id="tab_useremailaccount"><!-- page* -->
<?php include_once "useremailaccountgrid.php" ?>
		</div><!-- /page* -->
<?php } ?>
<?php
	if (in_array("userpi", explode(",", $user->getCurrentDetailTable())) && $userpi->DetailAdd) {
		if ($firstActiveDetailTable == "" || $firstActiveDetailTable == "userpi")
			$firstActiveDetailTable = "userpi";
?>
		<div class="tab-pane <?php echo $user_add->DetailPages->pageStyle("userpi") ?>" id="tab_userpi"><!-- page* -->
<?php include_once "userpigrid.php" ?>
		</div><!-- /page* -->
<?php } ?>
<?php
	if (in_array("userpurchase", explode(",", $user->getCurrentDetailTable())) && $userpurchase->DetailAdd) {
		if ($firstActiveDetailTable == "" || $firstActiveDetailTable == "userpurchase")
			$firstActiveDetailTable = "userpurchase";
?>
		<div class="tab-pane <?php echo $user_add->DetailPages->pageStyle("userpurchase") ?>" id="tab_userpurchase"><!-- page* -->
<?php include_once "userpurchasegrid.php" ?>
		</div><!-- /page* -->
<?php } ?>
<?php
	if (in_array("loanlimits", explode(",", $user->getCurrentDetailTable())) && $loanlimits->DetailAdd) {
		if ($firstActiveDetailTable == "" || $firstActiveDetailTable == "loanlimits")
			$firstActiveDetailTable = "loanlimits";
?>
		<div class="tab-pane <?php echo $user_add->DetailPages->pageStyle("loanlimits") ?>" id="tab_loanlimits"><!-- page* -->
<?php include_once "loanlimitsgrid.php" ?>
		</div><!-- /page* -->
<?php } ?>
<?php
	if (in_array("userkycdocs", explode(",", $user->getCurrentDetailTable())) && $userkycdocs->DetailAdd) {
		if ($firstActiveDetailTable == "" || $firstActiveDetailTable == "userkycdocs")
			$firstActiveDetailTable = "userkycdocs";
?>
		<div class="tab-pane <?php echo $user_add->DetailPages->pageStyle("userkycdocs") ?>" id="tab_userkycdocs"><!-- page* -->
<?php include_once "userkycdocsgrid.php" ?>
		</div><!-- /page* -->
<?php } ?>
<?php
	if (in_array("acctbalance", explode(",", $user->getCurrentDetailTable())) && $acctbalance->DetailAdd) {
		if ($firstActiveDetailTable == "" || $firstActiveDetailTable == "acctbalance")
			$firstActiveDetailTable = "acctbalance";
?>
		<div class="tab-pane <?php echo $user_add->DetailPages->pageStyle("acctbalance") ?>" id="tab_acctbalance"><!-- page* -->
<?php include_once "acctbalancegrid.php" ?>
		</div><!-- /page* -->
<?php } ?>
<?php
	if (in_array("userdevices", explode(",", $user->getCurrentDetailTable())) && $userdevices->DetailAdd) {
		if ($firstActiveDetailTable == "" || $firstActiveDetailTable == "userdevices")
			$firstActiveDetailTable = "userdevices";
?>
		<div class="tab-pane <?php echo $user_add->DetailPages->pageStyle("userdevices") ?>" id="tab_userdevices"><!-- page* -->
<?php include_once "userdevicesgrid.php" ?>
		</div><!-- /page* -->
<?php } ?>
<?php
	if (in_array("usercommission", explode(",", $user->getCurrentDetailTable())) && $usercommission->DetailAdd) {
		if ($firstActiveDetailTable == "" || $firstActiveDetailTable == "usercommission")
			$firstActiveDetailTable = "usercommission";
?>
		<div class="tab-pane <?php echo $user_add->DetailPages->pageStyle("usercommission") ?>" id="tab_usercommission"><!-- page* -->
<?php include_once "usercommissiongrid.php" ?>
		</div><!-- /page* -->
<?php } ?>
	</div><!-- /.tab-content -->
</div><!-- /tabs -->
</div><!-- /detail-pages -->
<?php } ?>
<?php if (!$user_add->IsModal) { ?>
<div class="form-group row"><!-- buttons .form-group -->
	<div class="<?php echo $user_add->OffsetColumnClass ?>"><!-- buttons offset -->
<button class="btn btn-primary ew-btn" name="btn-action" id="btn-action" type="submit"><?php echo $Language->phrase("AddBtn") ?></button>
<button class="btn btn-default ew-btn" name="btn-cancel" id="btn-cancel" type="button" data-href="<?php echo $user_add->getReturnUrl() ?>"><?php echo $Language->phrase("CancelBtn") ?></button>
	</div><!-- /buttons offset -->
</div><!-- /buttons .form-group -->
<?php } ?>
</form>
<?php
$user_add->showPageFooter();
if (Config("DEBUG"))
	echo GetDebugMessage();
?>
<script>
loadjs.ready("load", function() {

	// Startup script
	// Write your table-specific startup script here
	// console.log("page loaded");

});
</script>
<?php include_once "footer.php"; ?>
<?php
$user_add->terminate();
?>