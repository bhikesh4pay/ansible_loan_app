<?php
namespace PHPMaker2020\_4payadmin;

// Autoload
include_once "autoload.php";

// Session
if (session_status() !== PHP_SESSION_ACTIVE)
	\Delight\Cookie\Session::start(Config("COOKIE_SAMESITE")); // Init session data

// Output buffering
ob_start();
?>
<?php

// Write header
WriteHeader(FALSE, "utf-8");

// Create page object
$loanrequests_preview = new loanrequests_preview();

// Run the page
$loanrequests_preview->run();

// Setup login status
SetupLoginStatus();
SetClientVar("login", LoginStatus());

// Global Page Rendering event (in userfn*.php)
Page_Rendering();

// Page Rendering event
$loanrequests_preview->Page_Render();
?>
<?php $loanrequests_preview->showPageHeader(); ?>
<?php if ($loanrequests_preview->TotalRecords > 0) { ?>
<div class="card ew-grid loanrequests"><!-- .card -->
<div class="<?php echo ResponsiveTableClass() ?>card-body ew-grid-middle-panel ew-preview-middle-panel"><!-- .table-responsive -->
<table class="table ew-table ew-preview-table"><!-- .table -->
	<thead><!-- Table header -->
		<tr class="ew-table-header">
<?php

// Render list options
$loanrequests_preview->renderListOptions();

// Render list options (header, left)
$loanrequests_preview->ListOptions->render("header", "left");
?>
<?php if ($loanrequests_preview->requestid->Visible) { // requestid ?>
	<?php if ($loanrequests->SortUrl($loanrequests_preview->requestid) == "") { ?>
		<th class="<?php echo $loanrequests_preview->requestid->headerCellClass() ?>"><?php echo $loanrequests_preview->requestid->caption() ?></th>
	<?php } else { ?>
		<th class="<?php echo $loanrequests_preview->requestid->headerCellClass() ?>"><div class="ew-pointer" data-sort="<?php echo HtmlEncode($loanrequests_preview->requestid->Name) ?>" data-sort-order="<?php echo $loanrequests_preview->SortField == $loanrequests_preview->requestid->Name && $loanrequests_preview->SortOrder == "ASC" ? "DESC" : "ASC" ?>">
			<div class="ew-table-header-btn"><span class="ew-table-header-caption"><?php echo $loanrequests_preview->requestid->caption() ?></span><span class="ew-table-header-sort"><?php if ($loanrequests_preview->SortField == $loanrequests_preview->requestid->Name) { ?><?php if ($loanrequests_preview->SortOrder == "ASC") { ?><i class="fas fa-sort-up"></i><?php } elseif ($loanrequests_preview->SortOrder == "DESC") { ?><i class="fas fa-sort-down"></i><?php } ?><?php } ?></span>
		</div></div></th>
	<?php } ?>
<?php } ?>
<?php if ($loanrequests_preview->requestdate->Visible) { // requestdate ?>
	<?php if ($loanrequests->SortUrl($loanrequests_preview->requestdate) == "") { ?>
		<th class="<?php echo $loanrequests_preview->requestdate->headerCellClass() ?>"><?php echo $loanrequests_preview->requestdate->caption() ?></th>
	<?php } else { ?>
		<th class="<?php echo $loanrequests_preview->requestdate->headerCellClass() ?>"><div class="ew-pointer" data-sort="<?php echo HtmlEncode($loanrequests_preview->requestdate->Name) ?>" data-sort-order="<?php echo $loanrequests_preview->SortField == $loanrequests_preview->requestdate->Name && $loanrequests_preview->SortOrder == "ASC" ? "DESC" : "ASC" ?>">
			<div class="ew-table-header-btn"><span class="ew-table-header-caption"><?php echo $loanrequests_preview->requestdate->caption() ?></span><span class="ew-table-header-sort"><?php if ($loanrequests_preview->SortField == $loanrequests_preview->requestdate->Name) { ?><?php if ($loanrequests_preview->SortOrder == "ASC") { ?><i class="fas fa-sort-up"></i><?php } elseif ($loanrequests_preview->SortOrder == "DESC") { ?><i class="fas fa-sort-down"></i><?php } ?><?php } ?></span>
		</div></div></th>
	<?php } ?>
<?php } ?>
<?php if ($loanrequests_preview->_userid->Visible) { // userid ?>
	<?php if ($loanrequests->SortUrl($loanrequests_preview->_userid) == "") { ?>
		<th class="<?php echo $loanrequests_preview->_userid->headerCellClass() ?>"><?php echo $loanrequests_preview->_userid->caption() ?></th>
	<?php } else { ?>
		<th class="<?php echo $loanrequests_preview->_userid->headerCellClass() ?>"><div class="ew-pointer" data-sort="<?php echo HtmlEncode($loanrequests_preview->_userid->Name) ?>" data-sort-order="<?php echo $loanrequests_preview->SortField == $loanrequests_preview->_userid->Name && $loanrequests_preview->SortOrder == "ASC" ? "DESC" : "ASC" ?>">
			<div class="ew-table-header-btn"><span class="ew-table-header-caption"><?php echo $loanrequests_preview->_userid->caption() ?></span><span class="ew-table-header-sort"><?php if ($loanrequests_preview->SortField == $loanrequests_preview->_userid->Name) { ?><?php if ($loanrequests_preview->SortOrder == "ASC") { ?><i class="fas fa-sort-up"></i><?php } elseif ($loanrequests_preview->SortOrder == "DESC") { ?><i class="fas fa-sort-down"></i><?php } ?><?php } ?></span>
		</div></div></th>
	<?php } ?>
<?php } ?>
<?php if ($loanrequests_preview->currcode->Visible) { // currcode ?>
	<?php if ($loanrequests->SortUrl($loanrequests_preview->currcode) == "") { ?>
		<th class="<?php echo $loanrequests_preview->currcode->headerCellClass() ?>"><?php echo $loanrequests_preview->currcode->caption() ?></th>
	<?php } else { ?>
		<th class="<?php echo $loanrequests_preview->currcode->headerCellClass() ?>"><div class="ew-pointer" data-sort="<?php echo HtmlEncode($loanrequests_preview->currcode->Name) ?>" data-sort-order="<?php echo $loanrequests_preview->SortField == $loanrequests_preview->currcode->Name && $loanrequests_preview->SortOrder == "ASC" ? "DESC" : "ASC" ?>">
			<div class="ew-table-header-btn"><span class="ew-table-header-caption"><?php echo $loanrequests_preview->currcode->caption() ?></span><span class="ew-table-header-sort"><?php if ($loanrequests_preview->SortField == $loanrequests_preview->currcode->Name) { ?><?php if ($loanrequests_preview->SortOrder == "ASC") { ?><i class="fas fa-sort-up"></i><?php } elseif ($loanrequests_preview->SortOrder == "DESC") { ?><i class="fas fa-sort-down"></i><?php } ?><?php } ?></span>
		</div></div></th>
	<?php } ?>
<?php } ?>
<?php if ($loanrequests_preview->requestamount->Visible) { // requestamount ?>
	<?php if ($loanrequests->SortUrl($loanrequests_preview->requestamount) == "") { ?>
		<th class="<?php echo $loanrequests_preview->requestamount->headerCellClass() ?>"><?php echo $loanrequests_preview->requestamount->caption() ?></th>
	<?php } else { ?>
		<th class="<?php echo $loanrequests_preview->requestamount->headerCellClass() ?>"><div class="ew-pointer" data-sort="<?php echo HtmlEncode($loanrequests_preview->requestamount->Name) ?>" data-sort-order="<?php echo $loanrequests_preview->SortField == $loanrequests_preview->requestamount->Name && $loanrequests_preview->SortOrder == "ASC" ? "DESC" : "ASC" ?>">
			<div class="ew-table-header-btn"><span class="ew-table-header-caption"><?php echo $loanrequests_preview->requestamount->caption() ?></span><span class="ew-table-header-sort"><?php if ($loanrequests_preview->SortField == $loanrequests_preview->requestamount->Name) { ?><?php if ($loanrequests_preview->SortOrder == "ASC") { ?><i class="fas fa-sort-up"></i><?php } elseif ($loanrequests_preview->SortOrder == "DESC") { ?><i class="fas fa-sort-down"></i><?php } ?><?php } ?></span>
		</div></div></th>
	<?php } ?>
<?php } ?>
<?php if ($loanrequests_preview->requestoruserid->Visible) { // requestoruserid ?>
	<?php if ($loanrequests->SortUrl($loanrequests_preview->requestoruserid) == "") { ?>
		<th class="<?php echo $loanrequests_preview->requestoruserid->headerCellClass() ?>"><?php echo $loanrequests_preview->requestoruserid->caption() ?></th>
	<?php } else { ?>
		<th class="<?php echo $loanrequests_preview->requestoruserid->headerCellClass() ?>"><div class="ew-pointer" data-sort="<?php echo HtmlEncode($loanrequests_preview->requestoruserid->Name) ?>" data-sort-order="<?php echo $loanrequests_preview->SortField == $loanrequests_preview->requestoruserid->Name && $loanrequests_preview->SortOrder == "ASC" ? "DESC" : "ASC" ?>">
			<div class="ew-table-header-btn"><span class="ew-table-header-caption"><?php echo $loanrequests_preview->requestoruserid->caption() ?></span><span class="ew-table-header-sort"><?php if ($loanrequests_preview->SortField == $loanrequests_preview->requestoruserid->Name) { ?><?php if ($loanrequests_preview->SortOrder == "ASC") { ?><i class="fas fa-sort-up"></i><?php } elseif ($loanrequests_preview->SortOrder == "DESC") { ?><i class="fas fa-sort-down"></i><?php } ?><?php } ?></span>
		</div></div></th>
	<?php } ?>
<?php } ?>
<?php if ($loanrequests_preview->externalrefno->Visible) { // externalrefno ?>
	<?php if ($loanrequests->SortUrl($loanrequests_preview->externalrefno) == "") { ?>
		<th class="<?php echo $loanrequests_preview->externalrefno->headerCellClass() ?>"><?php echo $loanrequests_preview->externalrefno->caption() ?></th>
	<?php } else { ?>
		<th class="<?php echo $loanrequests_preview->externalrefno->headerCellClass() ?>"><div class="ew-pointer" data-sort="<?php echo HtmlEncode($loanrequests_preview->externalrefno->Name) ?>" data-sort-order="<?php echo $loanrequests_preview->SortField == $loanrequests_preview->externalrefno->Name && $loanrequests_preview->SortOrder == "ASC" ? "DESC" : "ASC" ?>">
			<div class="ew-table-header-btn"><span class="ew-table-header-caption"><?php echo $loanrequests_preview->externalrefno->caption() ?></span><span class="ew-table-header-sort"><?php if ($loanrequests_preview->SortField == $loanrequests_preview->externalrefno->Name) { ?><?php if ($loanrequests_preview->SortOrder == "ASC") { ?><i class="fas fa-sort-up"></i><?php } elseif ($loanrequests_preview->SortOrder == "DESC") { ?><i class="fas fa-sort-down"></i><?php } ?><?php } ?></span>
		</div></div></th>
	<?php } ?>
<?php } ?>
<?php if ($loanrequests_preview->issued->Visible) { // issued ?>
	<?php if ($loanrequests->SortUrl($loanrequests_preview->issued) == "") { ?>
		<th class="<?php echo $loanrequests_preview->issued->headerCellClass() ?>"><?php echo $loanrequests_preview->issued->caption() ?></th>
	<?php } else { ?>
		<th class="<?php echo $loanrequests_preview->issued->headerCellClass() ?>"><div class="ew-pointer" data-sort="<?php echo HtmlEncode($loanrequests_preview->issued->Name) ?>" data-sort-order="<?php echo $loanrequests_preview->SortField == $loanrequests_preview->issued->Name && $loanrequests_preview->SortOrder == "ASC" ? "DESC" : "ASC" ?>">
			<div class="ew-table-header-btn"><span class="ew-table-header-caption"><?php echo $loanrequests_preview->issued->caption() ?></span><span class="ew-table-header-sort"><?php if ($loanrequests_preview->SortField == $loanrequests_preview->issued->Name) { ?><?php if ($loanrequests_preview->SortOrder == "ASC") { ?><i class="fas fa-sort-up"></i><?php } elseif ($loanrequests_preview->SortOrder == "DESC") { ?><i class="fas fa-sort-down"></i><?php } ?><?php } ?></span>
		</div></div></th>
	<?php } ?>
<?php } ?>
<?php if ($loanrequests_preview->termtype->Visible) { // termtype ?>
	<?php if ($loanrequests->SortUrl($loanrequests_preview->termtype) == "") { ?>
		<th class="<?php echo $loanrequests_preview->termtype->headerCellClass() ?>"><?php echo $loanrequests_preview->termtype->caption() ?></th>
	<?php } else { ?>
		<th class="<?php echo $loanrequests_preview->termtype->headerCellClass() ?>"><div class="ew-pointer" data-sort="<?php echo HtmlEncode($loanrequests_preview->termtype->Name) ?>" data-sort-order="<?php echo $loanrequests_preview->SortField == $loanrequests_preview->termtype->Name && $loanrequests_preview->SortOrder == "ASC" ? "DESC" : "ASC" ?>">
			<div class="ew-table-header-btn"><span class="ew-table-header-caption"><?php echo $loanrequests_preview->termtype->caption() ?></span><span class="ew-table-header-sort"><?php if ($loanrequests_preview->SortField == $loanrequests_preview->termtype->Name) { ?><?php if ($loanrequests_preview->SortOrder == "ASC") { ?><i class="fas fa-sort-up"></i><?php } elseif ($loanrequests_preview->SortOrder == "DESC") { ?><i class="fas fa-sort-down"></i><?php } ?><?php } ?></span>
		</div></div></th>
	<?php } ?>
<?php } ?>
<?php

// Render list options (header, right)
$loanrequests_preview->ListOptions->render("header", "right");
?>
		</tr>
	</thead>
	<tbody><!-- Table body -->
<?php
$loanrequests_preview->RecCount = 0;
$loanrequests_preview->RowCount = 0;
while ($loanrequests_preview->Recordset && !$loanrequests_preview->Recordset->EOF) {

	// Init row class and style
	$loanrequests_preview->RecCount++;
	$loanrequests_preview->RowCount++;
	$loanrequests_preview->CssStyle = "";
	$loanrequests_preview->loadListRowValues($loanrequests_preview->Recordset);

	// Render row
	$loanrequests->RowType = ROWTYPE_PREVIEW; // Preview record
	$loanrequests_preview->resetAttributes();
	$loanrequests_preview->renderListRow();

	// Render list options
	$loanrequests_preview->renderListOptions();
?>
	<tr <?php echo $loanrequests->rowAttributes() ?>>
<?php

// Render list options (body, left)
$loanrequests_preview->ListOptions->render("body", "left", $loanrequests_preview->RowCount);
?>
<?php if ($loanrequests_preview->requestid->Visible) { // requestid ?>
		<!-- requestid -->
		<td<?php echo $loanrequests_preview->requestid->cellAttributes() ?>>
<span<?php echo $loanrequests_preview->requestid->viewAttributes() ?>><?php echo $loanrequests_preview->requestid->getViewValue() ?></span>
</td>
<?php } ?>
<?php if ($loanrequests_preview->requestdate->Visible) { // requestdate ?>
		<!-- requestdate -->
		<td<?php echo $loanrequests_preview->requestdate->cellAttributes() ?>>
<span<?php echo $loanrequests_preview->requestdate->viewAttributes() ?>><?php echo $loanrequests_preview->requestdate->getViewValue() ?></span>
</td>
<?php } ?>
<?php if ($loanrequests_preview->_userid->Visible) { // userid ?>
		<!-- userid -->
		<td<?php echo $loanrequests_preview->_userid->cellAttributes() ?>>
<span<?php echo $loanrequests_preview->_userid->viewAttributes() ?>><?php if (!EmptyString($loanrequests_preview->_userid->getViewValue()) && $loanrequests_preview->_userid->linkAttributes() != "") { ?>
<a<?php echo $loanrequests_preview->_userid->linkAttributes() ?>><?php echo $loanrequests_preview->_userid->getViewValue() ?></a>
<?php } else { ?>
<?php echo $loanrequests_preview->_userid->getViewValue() ?>
<?php } ?></span>
</td>
<?php } ?>
<?php if ($loanrequests_preview->currcode->Visible) { // currcode ?>
		<!-- currcode -->
		<td<?php echo $loanrequests_preview->currcode->cellAttributes() ?>>
<span<?php echo $loanrequests_preview->currcode->viewAttributes() ?>><?php echo $loanrequests_preview->currcode->getViewValue() ?></span>
</td>
<?php } ?>
<?php if ($loanrequests_preview->requestamount->Visible) { // requestamount ?>
		<!-- requestamount -->
		<td<?php echo $loanrequests_preview->requestamount->cellAttributes() ?>>
<span<?php echo $loanrequests_preview->requestamount->viewAttributes() ?>><?php echo $loanrequests_preview->requestamount->getViewValue() ?></span>
</td>
<?php } ?>
<?php if ($loanrequests_preview->requestoruserid->Visible) { // requestoruserid ?>
		<!-- requestoruserid -->
		<td<?php echo $loanrequests_preview->requestoruserid->cellAttributes() ?>>
<span<?php echo $loanrequests_preview->requestoruserid->viewAttributes() ?>><?php echo $loanrequests_preview->requestoruserid->getViewValue() ?></span>
</td>
<?php } ?>
<?php if ($loanrequests_preview->externalrefno->Visible) { // externalrefno ?>
		<!-- externalrefno -->
		<td<?php echo $loanrequests_preview->externalrefno->cellAttributes() ?>>
<span<?php echo $loanrequests_preview->externalrefno->viewAttributes() ?>><?php echo $loanrequests_preview->externalrefno->getViewValue() ?></span>
</td>
<?php } ?>
<?php if ($loanrequests_preview->issued->Visible) { // issued ?>
		<!-- issued -->
		<td<?php echo $loanrequests_preview->issued->cellAttributes() ?>>
<span<?php echo $loanrequests_preview->issued->viewAttributes() ?>><?php echo $loanrequests_preview->issued->getViewValue() ?></span>
</td>
<?php } ?>
<?php if ($loanrequests_preview->termtype->Visible) { // termtype ?>
		<!-- termtype -->
		<td<?php echo $loanrequests_preview->termtype->cellAttributes() ?>>
<span<?php echo $loanrequests_preview->termtype->viewAttributes() ?>><?php echo $loanrequests_preview->termtype->getViewValue() ?></span>
</td>
<?php } ?>
<?php

// Render list options (body, right)
$loanrequests_preview->ListOptions->render("body", "right", $loanrequests_preview->RowCount);
?>
	</tr>
<?php
	$loanrequests_preview->Recordset->MoveNext();
} // while
?>
	</tbody>
</table><!-- /.table -->
</div><!-- /.table-responsive -->
<div class="card-footer ew-grid-lower-panel ew-preview-lower-panel"><!-- .card-footer -->
<?php echo $loanrequests_preview->Pager->render() ?>
<?php } else { // No record ?>
<div class="card no-border">
<div class="ew-detail-count"><?php echo $Language->phrase("NoRecord") ?></div>
<?php } ?>
<div class="ew-preview-other-options">
<?php
	foreach ($loanrequests_preview->OtherOptions as $option)
		$option->render("body");
?>
</div>
<?php if ($loanrequests_preview->TotalRecords > 0) { ?>
<div class="clearfix"></div>
</div><!-- /.card-footer -->
<?php } ?>
</div><!-- /.card -->
<?php
$loanrequests_preview->showPageFooter();
if (Config("DEBUG"))
	echo GetDebugMessage();
?>
<?php
if ($loanrequests_preview->Recordset)
	$loanrequests_preview->Recordset->Close();

// Output
$content = ob_get_contents();
ob_end_clean();
echo ConvertToUtf8($content);
?>
<?php
$loanrequests_preview->terminate();
?>