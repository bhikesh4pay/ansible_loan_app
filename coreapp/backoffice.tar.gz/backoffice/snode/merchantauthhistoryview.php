<?php
namespace PHPMaker2020\_4payadmin;

// Autoload
include_once "autoload.php";

// Session
if (session_status() !== PHP_SESSION_ACTIVE)
	\Delight\Cookie\Session::start(Config("COOKIE_SAMESITE")); // Init session data

// Output buffering
ob_start();
?>
<?php

// Write header
WriteHeader(FALSE);

// Create page object
$merchantauthhistory_view = new merchantauthhistory_view();

// Run the page
$merchantauthhistory_view->run();

// Setup login status
SetupLoginStatus();
SetClientVar("login", LoginStatus());

// Global Page Rendering event (in userfn*.php)
Page_Rendering();

// Page Rendering event
$merchantauthhistory_view->Page_Render();
?>
<?php include_once "header.php"; ?>
<?php if (!$merchantauthhistory_view->isExport()) { ?>
<script>
var fmerchantauthhistoryview, currentPageID;
loadjs.ready("head", function() {

	// Form object
	currentPageID = ew.PAGE_ID = "view";
	fmerchantauthhistoryview = currentForm = new ew.Form("fmerchantauthhistoryview", "view");
	loadjs.done("fmerchantauthhistoryview");
});
</script>
<script>
loadjs.ready("head", function() {

	// Client script
	// Write your client script here, no need to add script tags.

});
</script>
<?php } ?>
<?php if (!$merchantauthhistory_view->isExport()) { ?>
<div class="btn-toolbar ew-toolbar">
<?php $merchantauthhistory_view->ExportOptions->render("body") ?>
<?php $merchantauthhistory_view->OtherOptions->render("body") ?>
<div class="clearfix"></div>
</div>
<?php } ?>
<?php $merchantauthhistory_view->showPageHeader(); ?>
<?php
$merchantauthhistory_view->showMessage();
?>
<form name="fmerchantauthhistoryview" id="fmerchantauthhistoryview" class="form-inline ew-form ew-view-form" action="<?php echo CurrentPageName() ?>" method="post">
<?php if ($Page->CheckToken) { ?>
<input type="hidden" name="<?php echo Config("TOKEN_NAME") ?>" value="<?php echo $Page->Token ?>">
<?php } ?>
<input type="hidden" name="t" value="merchantauthhistory">
<input type="hidden" name="modal" value="<?php echo (int)$merchantauthhistory_view->IsModal ?>">
<table class="table table-striped table-sm ew-view-table">
<?php if ($merchantauthhistory_view->historyid->Visible) { // historyid ?>
	<tr id="r_historyid">
		<td class="<?php echo $merchantauthhistory_view->TableLeftColumnClass ?>"><span id="elh_merchantauthhistory_historyid"><?php echo $merchantauthhistory_view->historyid->caption() ?></span></td>
		<td data-name="historyid" <?php echo $merchantauthhistory_view->historyid->cellAttributes() ?>>
<span id="el_merchantauthhistory_historyid">
<span<?php echo $merchantauthhistory_view->historyid->viewAttributes() ?>><?php echo $merchantauthhistory_view->historyid->getViewValue() ?></span>
</span>
</td>
	</tr>
<?php } ?>
<?php if ($merchantauthhistory_view->profileid->Visible) { // profileid ?>
	<tr id="r_profileid">
		<td class="<?php echo $merchantauthhistory_view->TableLeftColumnClass ?>"><span id="elh_merchantauthhistory_profileid"><?php echo $merchantauthhistory_view->profileid->caption() ?></span></td>
		<td data-name="profileid" <?php echo $merchantauthhistory_view->profileid->cellAttributes() ?>>
<span id="el_merchantauthhistory_profileid">
<span<?php echo $merchantauthhistory_view->profileid->viewAttributes() ?>><?php echo $merchantauthhistory_view->profileid->getViewValue() ?></span>
</span>
</td>
	</tr>
<?php } ?>
<?php if ($merchantauthhistory_view->_userid->Visible) { // userid ?>
	<tr id="r__userid">
		<td class="<?php echo $merchantauthhistory_view->TableLeftColumnClass ?>"><span id="elh_merchantauthhistory__userid"><?php echo $merchantauthhistory_view->_userid->caption() ?></span></td>
		<td data-name="_userid" <?php echo $merchantauthhistory_view->_userid->cellAttributes() ?>>
<span id="el_merchantauthhistory__userid">
<span<?php echo $merchantauthhistory_view->_userid->viewAttributes() ?>><?php echo $merchantauthhistory_view->_userid->getViewValue() ?></span>
</span>
</td>
	</tr>
<?php } ?>
<?php if ($merchantauthhistory_view->accessdatetime->Visible) { // accessdatetime ?>
	<tr id="r_accessdatetime">
		<td class="<?php echo $merchantauthhistory_view->TableLeftColumnClass ?>"><span id="elh_merchantauthhistory_accessdatetime"><?php echo $merchantauthhistory_view->accessdatetime->caption() ?></span></td>
		<td data-name="accessdatetime" <?php echo $merchantauthhistory_view->accessdatetime->cellAttributes() ?>>
<span id="el_merchantauthhistory_accessdatetime">
<span<?php echo $merchantauthhistory_view->accessdatetime->viewAttributes() ?>><?php echo $merchantauthhistory_view->accessdatetime->getViewValue() ?></span>
</span>
</td>
	</tr>
<?php } ?>
</table>
</form>
<?php
$merchantauthhistory_view->showPageFooter();
if (Config("DEBUG"))
	echo GetDebugMessage();
?>
<?php if (!$merchantauthhistory_view->isExport()) { ?>
<script>
loadjs.ready("load", function() {

	// Startup script
	// Write your table-specific startup script here
	// console.log("page loaded");

});
</script>
<?php } ?>
<?php include_once "footer.php"; ?>
<?php
$merchantauthhistory_view->terminate();
?>