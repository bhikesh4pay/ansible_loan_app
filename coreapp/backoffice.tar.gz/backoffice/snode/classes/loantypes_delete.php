<?php
namespace PHPMaker2020\_4payadmin;

/**
 * Page class
 */
class loantypes_delete extends loantypes
{

	// Page ID
	public $PageID = "delete";

	// Project ID
	public $ProjectID = "{153C2D2E-60EE-4944-8753-3935EB38E8D6}";

	// Table name
	public $TableName = 'loantypes';

	// Page object name
	public $PageObjName = "loantypes_delete";

	// Page headings
	public $Heading = "";
	public $Subheading = "";
	public $PageHeader;
	public $PageFooter;

	// Token
	public $Token = "";
	public $TokenTimeout = 0;
	public $CheckToken;

	// Page heading
	public function pageHeading()
	{
		global $Language;
		if ($this->Heading != "")
			return $this->Heading;
		if (method_exists($this, "tableCaption"))
			return $this->tableCaption();
		return "";
	}

	// Page subheading
	public function pageSubheading()
	{
		global $Language;
		if ($this->Subheading != "")
			return $this->Subheading;
		if ($this->TableName)
			return $Language->phrase($this->PageID);
		return "";
	}

	// Page name
	public function pageName()
	{
		return CurrentPageName();
	}

	// Page URL
	public function pageUrl()
	{
		$url = CurrentPageName() . "?";
		if ($this->UseTokenInUrl)
			$url .= "t=" . $this->TableVar . "&"; // Add page token
		return $url;
	}

	// Messages
	private $_message = "";
	private $_failureMessage = "";
	private $_successMessage = "";
	private $_warningMessage = "";

	// Get message
	public function getMessage()
	{
		return isset($_SESSION[SESSION_MESSAGE]) ? $_SESSION[SESSION_MESSAGE] : $this->_message;
	}

	// Set message
	public function setMessage($v)
	{
		AddMessage($this->_message, $v);
		$_SESSION[SESSION_MESSAGE] = $this->_message;
	}

	// Get failure message
	public function getFailureMessage()
	{
		return isset($_SESSION[SESSION_FAILURE_MESSAGE]) ? $_SESSION[SESSION_FAILURE_MESSAGE] : $this->_failureMessage;
	}

	// Set failure message
	public function setFailureMessage($v)
	{
		AddMessage($this->_failureMessage, $v);
		$_SESSION[SESSION_FAILURE_MESSAGE] = $this->_failureMessage;
	}

	// Get success message
	public function getSuccessMessage()
	{
		return isset($_SESSION[SESSION_SUCCESS_MESSAGE]) ? $_SESSION[SESSION_SUCCESS_MESSAGE] : $this->_successMessage;
	}

	// Set success message
	public function setSuccessMessage($v)
	{
		AddMessage($this->_successMessage, $v);
		$_SESSION[SESSION_SUCCESS_MESSAGE] = $this->_successMessage;
	}

	// Get warning message
	public function getWarningMessage()
	{
		return isset($_SESSION[SESSION_WARNING_MESSAGE]) ? $_SESSION[SESSION_WARNING_MESSAGE] : $this->_warningMessage;
	}

	// Set warning message
	public function setWarningMessage($v)
	{
		AddMessage($this->_warningMessage, $v);
		$_SESSION[SESSION_WARNING_MESSAGE] = $this->_warningMessage;
	}

	// Clear message
	public function clearMessage()
	{
		$this->_message = "";
		$_SESSION[SESSION_MESSAGE] = "";
	}

	// Clear failure message
	public function clearFailureMessage()
	{
		$this->_failureMessage = "";
		$_SESSION[SESSION_FAILURE_MESSAGE] = "";
	}

	// Clear success message
	public function clearSuccessMessage()
	{
		$this->_successMessage = "";
		$_SESSION[SESSION_SUCCESS_MESSAGE] = "";
	}

	// Clear warning message
	public function clearWarningMessage()
	{
		$this->_warningMessage = "";
		$_SESSION[SESSION_WARNING_MESSAGE] = "";
	}

	// Clear messages
	public function clearMessages()
	{
		$this->clearMessage();
		$this->clearFailureMessage();
		$this->clearSuccessMessage();
		$this->clearWarningMessage();
	}

	// Show message
	public function showMessage()
	{
		$hidden = FALSE;
		$html = "";

		// Message
		$message = $this->getMessage();
		if (method_exists($this, "Message_Showing"))
			$this->Message_Showing($message, "");
		if ($message != "") { // Message in Session, display
			if (!$hidden)
				$message = '<button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button>' . $message;
			$html .= '<div class="alert alert-info alert-dismissible ew-info"><i class="icon fas fa-info"></i>' . $message . '</div>';
			$_SESSION[SESSION_MESSAGE] = ""; // Clear message in Session
		}

		// Warning message
		$warningMessage = $this->getWarningMessage();
		if (method_exists($this, "Message_Showing"))
			$this->Message_Showing($warningMessage, "warning");
		if ($warningMessage != "") { // Message in Session, display
			if (!$hidden)
				$warningMessage = '<button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button>' . $warningMessage;
			$html .= '<div class="alert alert-warning alert-dismissible ew-warning"><i class="icon fas fa-exclamation"></i>' . $warningMessage . '</div>';
			$_SESSION[SESSION_WARNING_MESSAGE] = ""; // Clear message in Session
		}

		// Success message
		$successMessage = $this->getSuccessMessage();
		if (method_exists($this, "Message_Showing"))
			$this->Message_Showing($successMessage, "success");
		if ($successMessage != "") { // Message in Session, display
			if (!$hidden)
				$successMessage = '<button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button>' . $successMessage;
			$html .= '<div class="alert alert-success alert-dismissible ew-success"><i class="icon fas fa-check"></i>' . $successMessage . '</div>';
			$_SESSION[SESSION_SUCCESS_MESSAGE] = ""; // Clear message in Session
		}

		// Failure message
		$errorMessage = $this->getFailureMessage();
		if (method_exists($this, "Message_Showing"))
			$this->Message_Showing($errorMessage, "failure");
		if ($errorMessage != "") { // Message in Session, display
			if (!$hidden)
				$errorMessage = '<button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button>' . $errorMessage;
			$html .= '<div class="alert alert-danger alert-dismissible ew-error"><i class="icon fas fa-ban"></i>' . $errorMessage . '</div>';
			$_SESSION[SESSION_FAILURE_MESSAGE] = ""; // Clear message in Session
		}
		echo '<div class="ew-message-dialog' . (($hidden) ? ' d-none' : "") . '">' . $html . '</div>';
	}

	// Get message as array
	public function getMessages()
	{
		$ar = [];

		// Message
		$message = $this->getMessage();

		//if (method_exists($this, "Message_Showing"))
		//	$this->Message_Showing($message, "");

		if ($message != "") { // Message in Session, display
			$ar["message"] = $message;
			$_SESSION[SESSION_MESSAGE] = ""; // Clear message in Session
		}

		// Warning message
		$warningMessage = $this->getWarningMessage();

		//if (method_exists($this, "Message_Showing"))
		//	$this->Message_Showing($warningMessage, "warning");

		if ($warningMessage != "") { // Message in Session, display
			$ar["warningMessage"] = $warningMessage;
			$_SESSION[SESSION_WARNING_MESSAGE] = ""; // Clear message in Session
		}

		// Success message
		$successMessage = $this->getSuccessMessage();

		//if (method_exists($this, "Message_Showing"))
		//	$this->Message_Showing($successMessage, "success");

		if ($successMessage != "") { // Message in Session, display
			$ar["successMessage"] = $successMessage;
			$_SESSION[SESSION_SUCCESS_MESSAGE] = ""; // Clear message in Session
		}

		// Failure message
		$failureMessage = $this->getFailureMessage();

		//if (method_exists($this, "Message_Showing"))
		//	$this->Message_Showing($failureMessage, "failure");

		if ($failureMessage != "") { // Message in Session, display
			$ar["failureMessage"] = $failureMessage;
			$_SESSION[SESSION_FAILURE_MESSAGE] = ""; // Clear message in Session
		}
		return $ar;
	}

	// Show Page Header
	public function showPageHeader()
	{
		$header = $this->PageHeader;
		$this->Page_DataRendering($header);
		if ($header != "") { // Header exists, display
			echo '<p id="ew-page-header">' . $header . '</p>';
		}
	}

	// Show Page Footer
	public function showPageFooter()
	{
		$footer = $this->PageFooter;
		$this->Page_DataRendered($footer);
		if ($footer != "") { // Footer exists, display
			echo '<p id="ew-page-footer">' . $footer . '</p>';
		}
	}

	// Validate page request
	protected function isPageRequest()
	{
		global $CurrentForm;
		if ($this->UseTokenInUrl) {
			if ($CurrentForm)
				return ($this->TableVar == $CurrentForm->getValue("t"));
			if (Get("t") !== NULL)
				return ($this->TableVar == Get("t"));
		}
		return TRUE;
	}

	// Valid Post
	protected function validPost()
	{
		if (!$this->CheckToken || !IsPost() || IsApi())
			return TRUE;
		if (Post(Config("TOKEN_NAME")) === NULL)
			return FALSE;
		$fn = Config("CHECK_TOKEN_FUNC");
		if (is_callable($fn))
			return $fn(Post(Config("TOKEN_NAME")), $this->TokenTimeout);
		return FALSE;
	}

	// Create Token
	public function createToken()
	{
		global $CurrentToken;
		$fn = Config("CREATE_TOKEN_FUNC"); // Always create token, required by API file/lookup request
		if ($this->Token == "" && is_callable($fn)) // Create token
			$this->Token = $fn();
		$CurrentToken = $this->Token; // Save to global variable
	}

	// Constructor
	public function __construct()
	{
		global $Language, $DashboardReport;
		global $UserTable;

		// Check token
		$this->CheckToken = Config("CHECK_TOKEN");

		// Initialize
		$GLOBALS["Page"] = &$this;
		$this->TokenTimeout = SessionTimeoutTime();

		// Language object
		if (!isset($Language))
			$Language = new Language();

		// Parent constuctor
		parent::__construct();

		// Table object (loantypes)
		if (!isset($GLOBALS["loantypes"]) || get_class($GLOBALS["loantypes"]) == PROJECT_NAMESPACE . "loantypes") {
			$GLOBALS["loantypes"] = &$this;
			$GLOBALS["Table"] = &$GLOBALS["loantypes"];
		}

		// Table object (admin)
		if (!isset($GLOBALS['admin']))
			$GLOBALS['admin'] = new admin();

		// Page ID (for backward compatibility only)
		if (!defined(PROJECT_NAMESPACE . "PAGE_ID"))
			define(PROJECT_NAMESPACE . "PAGE_ID", 'delete');

		// Table name (for backward compatibility only)
		if (!defined(PROJECT_NAMESPACE . "TABLE_NAME"))
			define(PROJECT_NAMESPACE . "TABLE_NAME", 'loantypes');

		// Start timer
		if (!isset($GLOBALS["DebugTimer"]))
			$GLOBALS["DebugTimer"] = new Timer();

		// Debug message
		LoadDebugMessage();

		// Open connection
		if (!isset($GLOBALS["Conn"]))
			$GLOBALS["Conn"] = $this->getConnection();

		// User table object (admin)
		$UserTable = $UserTable ?: new admin();
	}

	// Terminate page
	public function terminate($url = "")
	{
		global $ExportFileName, $TempImages, $DashboardReport;

		// Page Unload event
		$this->Page_Unload();

		// Global Page Unloaded event (in userfn*.php)
		Page_Unloaded();

		// Export
		global $loantypes;
		if ($this->CustomExport && $this->CustomExport == $this->Export && array_key_exists($this->CustomExport, Config("EXPORT_CLASSES"))) {
				$content = ob_get_contents();
			if ($ExportFileName == "")
				$ExportFileName = $this->TableVar;
			$class = PROJECT_NAMESPACE . Config("EXPORT_CLASSES." . $this->CustomExport);
			if (class_exists($class)) {
				$doc = new $class($loantypes);
				$doc->Text = @$content;
				if ($this->isExport("email"))
					echo $this->exportEmail($doc->Text);
				else
					$doc->export();
				DeleteTempImages(); // Delete temp images
				exit();
			}
		}
		if (!IsApi())
			$this->Page_Redirecting($url);

		// Close connection
		CloseConnections();

		// Return for API
		if (IsApi()) {
			$res = $url === TRUE;
			if (!$res) // Show error
				WriteJson(array_merge(["success" => FALSE], $this->getMessages()));
			return;
		}

		// Go to URL if specified
		if ($url != "") {
			if (!Config("DEBUG") && ob_get_length())
				ob_end_clean();
			SaveDebugMessage();
			AddHeader("Location", $url);
		}
		exit();
	}

	// Get records from recordset
	protected function getRecordsFromRecordset($rs, $current = FALSE)
	{
		$rows = [];
		if (is_object($rs)) { // Recordset
			while ($rs && !$rs->EOF) {
				$this->loadRowValues($rs); // Set up DbValue/CurrentValue
				$row = $this->getRecordFromArray($rs->fields);
				if ($current)
					return $row;
				else
					$rows[] = $row;
				$rs->moveNext();
			}
		} elseif (is_array($rs)) {
			foreach ($rs as $ar) {
				$row = $this->getRecordFromArray($ar);
				if ($current)
					return $row;
				else
					$rows[] = $row;
			}
		}
		return $rows;
	}

	// Get record from array
	protected function getRecordFromArray($ar)
	{
		$row = [];
		if (is_array($ar)) {
			foreach ($ar as $fldname => $val) {
				if (array_key_exists($fldname, $this->fields) && ($this->fields[$fldname]->Visible || $this->fields[$fldname]->IsPrimaryKey)) { // Primary key or Visible
					$fld = &$this->fields[$fldname];
					if ($fld->HtmlTag == "FILE") { // Upload field
						if (EmptyValue($val)) {
							$row[$fldname] = NULL;
						} else {
							if ($fld->DataType == DATATYPE_BLOB) {
								$url = FullUrl(GetApiUrl(Config("API_FILE_ACTION"),
									Config("API_OBJECT_NAME") . "=" . $fld->TableVar . "&" .
									Config("API_FIELD_NAME") . "=" . $fld->Param . "&" .
									Config("API_KEY_NAME") . "=" . rawurlencode($this->getRecordKeyValue($ar)))); //*** need to add this? API may not be in the same folder
								$row[$fldname] = ["type" => ContentType($val), "url" => $url, "name" => $fld->Param . ContentExtension($val)];
							} elseif (!$fld->UploadMultiple || !ContainsString($val, Config("MULTIPLE_UPLOAD_SEPARATOR"))) { // Single file
								$url = FullUrl(GetApiUrl(Config("API_FILE_ACTION"),
									Config("API_OBJECT_NAME") . "=" . $fld->TableVar . "&" .
									"fn=" . Encrypt($fld->physicalUploadPath() . $val)));
								$row[$fldname] = ["type" => MimeContentType($val), "url" => $url, "name" => $val];
							} else { // Multiple files
								$files = explode(Config("MULTIPLE_UPLOAD_SEPARATOR"), $val);
								$ar = [];
								foreach ($files as $file) {
									$url = FullUrl(GetApiUrl(Config("API_FILE_ACTION"),
										Config("API_OBJECT_NAME") . "=" . $fld->TableVar . "&" .
										"fn=" . Encrypt($fld->physicalUploadPath() . $file)));
									if (!EmptyValue($file))
										$ar[] = ["type" => MimeContentType($file), "url" => $url, "name" => $file];
								}
								$row[$fldname] = $ar;
							}
						}
					} else {
						$row[$fldname] = $val;
					}
				}
			}
		}
		return $row;
	}

	// Get record key value from array
	protected function getRecordKeyValue($ar)
	{
		$key = "";
		if (is_array($ar)) {
			$key .= @$ar['loantype'];
		}
		return $key;
	}

	/**
	 * Hide fields for add/edit
	 *
	 * @return void
	 */
	protected function hideFieldsForAddEdit()
	{
	}

	// Set up API security
	public function setupApiSecurity()
	{
		global $Security;

		// Setup security for API request
		if ($Security->isLoggedIn()) $Security->TablePermission_Loading();
		$Security->loadCurrentUserLevel(Config("PROJECT_ID") . $this->TableName);
		if ($Security->isLoggedIn()) $Security->TablePermission_Loaded();
	}
	public $DbMasterFilter = "";
	public $DbDetailFilter = "";
	public $StartRecord;
	public $TotalRecords = 0;
	public $RecordCount;
	public $RecKeys = [];
	public $StartRowCount = 1;
	public $RowCount = 0;

	//
	// Page run
	//

	public function run()
	{
		global $ExportType, $CustomExportType, $ExportFileName, $UserProfile, $Language, $Security, $CurrentForm;

		// User profile
		$UserProfile = new UserProfile();

		// Security
		if (ValidApiRequest()) { // API request
			$this->setupApiSecurity(); // Set up API Security
			if (!$Security->canDelete()) {
				SetStatus(401); // Unauthorized
				return;
			}
		} else {
			$Security = new AdvancedSecurity();
			if (IsPasswordExpired())
				$this->terminate(GetUrl("changepwd.php"));
			if (!$Security->isLoggedIn())
				$Security->autoLogin();
			if ($Security->isLoggedIn())
				$Security->TablePermission_Loading();
			$Security->loadCurrentUserLevel($this->ProjectID . $this->TableName);
			if ($Security->isLoggedIn())
				$Security->TablePermission_Loaded();
			if (!$Security->canDelete()) {
				$Security->saveLastUrl();
				$this->setFailureMessage(DeniedMessage()); // Set no permission
				if ($Security->canList())
					$this->terminate(GetUrl("loantypeslist.php"));
				else
					$this->terminate(GetUrl("login.php"));
				return;
			}
		}
		$this->CurrentAction = Param("action"); // Set up current action
		$this->loantype->setVisibility();
		$this->loandesc->setVisibility();
		$this->feeperc->setVisibility();
		$this->feefixed->setVisibility();
		$this->feetax->setVisibility();
		$this->purchasetableid->setVisibility();
		$this->numberofdays->setVisibility();
		$this->nextloantype->setVisibility();
		$this->latefeetableid->setVisibility();
		$this->stopcalculatingafterdays->setVisibility();
		$this->graceperioddays->setVisibility();
		$this->feecalculationmode->setVisibility();
		$this->latefeewarninglangid->setVisibility();
		$this->latefeelangid->setVisibility();
		$this->flaggedlangid->setVisibility();
		$this->unblocklangid->setVisibility();
		$this->blockedlangid->setVisibility();
		$this->nexttierwarninglangid->setVisibility();
		$this->nexttiernotificationlangid->setVisibility();
		$this->ignoreholidays->setVisibility();
		$this->flagging->setVisibility();
		$this->flaggingdays->setVisibility();
		$this->flaggingwaringdays->setVisibility();
		$this->flagwarninglangid->setVisibility();
		$this->noofduedays->setVisibility();
		$this->optin->setVisibility();
		$this->optout->setVisibility();
		$this->noteligiblelangid->setVisibility();
		$this->loanrequestwarninglangid->setVisibility();
		$this->optinlangid->setVisibility();
		$this->optoutlangid->setVisibility();
		$this->loanlimitlangid->setVisibility();
		$this->includefeesineligibilitycheck->setVisibility();
		$this->disbursementtype->setVisibility();
		$this->timegranularity->setVisibility();
		$this->loanrequestconfirmationlangid->setVisibility();
		$this->loanpaymentconfirmationlangid->setVisibility();
		$this->restrictive->setVisibility();
		$this->ignorenextbusinessday->setVisibility();
		$this->maxactiveloans->setVisibility();
		$this->terminterestallocationtype->setVisibility();
		$this->hideFieldsForAddEdit();

		// Do not use lookup cache
		$this->setUseLookupCache(FALSE);

		// Global Page Loading event (in userfn*.php)
		Page_Loading();

		// Page Load event
		$this->Page_Load();

		// Check token
		if (!$this->validPost()) {
			Write($Language->phrase("InvalidPostRequest"));
			$this->terminate();
		}

		// Create Token
		$this->createToken();

		// Set up lookup cache
		// Check permission

		if (!$Security->canDelete()) {
			$this->setFailureMessage(DeniedMessage()); // No permission
			$this->terminate("loantypeslist.php");
			return;
		}

		// Set up Breadcrumb
		$this->setupBreadcrumb();

		// Load key parameters
		$this->RecKeys = $this->getRecordKeys(); // Load record keys
		$filter = $this->getFilterFromRecordKeys();
		if ($filter == "") {
			$this->terminate("loantypeslist.php"); // Prevent SQL injection, return to list
			return;
		}

		// Set up filter (WHERE Clause)
		$this->CurrentFilter = $filter;

		// Get action
		if (IsApi()) {
			$this->CurrentAction = "delete"; // Delete record directly
		} elseif (Post("action") !== NULL) {
			$this->CurrentAction = Post("action");
		} elseif (Get("action") == "1") {
			$this->CurrentAction = "delete"; // Delete record directly
		} else {
			$this->CurrentAction = "show"; // Display record
		}
		if ($this->isDelete()) {
			$this->SendEmail = TRUE; // Send email on delete success
			if ($this->deleteRows()) { // Delete rows
				if ($this->getSuccessMessage() == "")
					$this->setSuccessMessage($Language->phrase("DeleteSuccess")); // Set up success message
				if (IsApi()) {
					$this->terminate(TRUE);
					return;
				} else {
					$this->terminate($this->getReturnUrl()); // Return to caller
				}
			} else { // Delete failed
				if (IsApi()) {
					$this->terminate();
					return;
				}
				$this->CurrentAction = "show"; // Display record
			}
		}
		if ($this->isShow()) { // Load records for display
			if ($this->Recordset = $this->loadRecordset())
				$this->TotalRecords = $this->Recordset->RecordCount(); // Get record count
			if ($this->TotalRecords <= 0) { // No record found, exit
				if ($this->Recordset)
					$this->Recordset->close();
				$this->terminate("loantypeslist.php"); // Return to list
			}
		}
	}

	// Load recordset
	public function loadRecordset($offset = -1, $rowcnt = -1)
	{

		// Load List page SQL
		$sql = $this->getListSql();
		$conn = $this->getConnection();

		// Load recordset
		$dbtype = GetConnectionType($this->Dbid);
		if ($this->UseSelectLimit) {
			$conn->raiseErrorFn = Config("ERROR_FUNC");
			if ($dbtype == "MSSQL") {
				$rs = $conn->selectLimit($sql, $rowcnt, $offset, ["_hasOrderBy" => trim($this->getOrderBy()) || trim($this->getSessionOrderBy())]);
			} else {
				$rs = $conn->selectLimit($sql, $rowcnt, $offset);
			}
			$conn->raiseErrorFn = "";
		} else {
			$rs = LoadRecordset($sql, $conn);
		}

		// Call Recordset Selected event
		$this->Recordset_Selected($rs);
		return $rs;
	}

	// Load row based on key values
	public function loadRow()
	{
		global $Security, $Language;
		$filter = $this->getRecordFilter();

		// Call Row Selecting event
		$this->Row_Selecting($filter);

		// Load SQL based on filter
		$this->CurrentFilter = $filter;
		$sql = $this->getCurrentSql();
		$conn = $this->getConnection();
		$res = FALSE;
		$rs = LoadRecordset($sql, $conn);
		if ($rs && !$rs->EOF) {
			$res = TRUE;
			$this->loadRowValues($rs); // Load row values
			$rs->close();
		}
		return $res;
	}

	// Load row values from recordset
	public function loadRowValues($rs = NULL)
	{
		if ($rs && !$rs->EOF)
			$row = $rs->fields;
		else
			$row = $this->newRow();

		// Call Row Selected event
		$this->Row_Selected($row);
		if (!$rs || $rs->EOF)
			return;
		$this->loantype->setDbValue($row['loantype']);
		$this->loandesc->setDbValue($row['loandesc']);
		$this->feeperc->setDbValue($row['feeperc']);
		$this->feefixed->setDbValue($row['feefixed']);
		$this->feetax->setDbValue($row['feetax']);
		$this->purchasetableid->setDbValue($row['purchasetableid']);
		$this->numberofdays->setDbValue($row['numberofdays']);
		$this->nextloantype->setDbValue($row['nextloantype']);
		$this->latefeetableid->setDbValue($row['latefeetableid']);
		$this->stopcalculatingafterdays->setDbValue($row['stopcalculatingafterdays']);
		$this->graceperioddays->setDbValue($row['graceperioddays']);
		$this->feecalculationmode->setDbValue($row['feecalculationmode']);
		$this->latefeewarninglangid->setDbValue($row['latefeewarninglangid']);
		$this->latefeelangid->setDbValue($row['latefeelangid']);
		$this->flaggedlangid->setDbValue($row['flaggedlangid']);
		$this->unblocklangid->setDbValue($row['unblocklangid']);
		$this->blockedlangid->setDbValue($row['blockedlangid']);
		$this->nexttierwarninglangid->setDbValue($row['nexttierwarninglangid']);
		$this->nexttiernotificationlangid->setDbValue($row['nexttiernotificationlangid']);
		$this->ignoreholidays->setDbValue($row['ignoreholidays']);
		$this->flagging->setDbValue($row['flagging']);
		$this->flaggingdays->setDbValue($row['flaggingdays']);
		$this->flaggingwaringdays->setDbValue($row['flaggingwaringdays']);
		$this->flagwarninglangid->setDbValue($row['flagwarninglangid']);
		$this->noofduedays->setDbValue($row['noofduedays']);
		$this->optin->setDbValue($row['optin']);
		$this->optout->setDbValue($row['optout']);
		$this->noteligiblelangid->setDbValue($row['noteligiblelangid']);
		$this->loanrequestwarninglangid->setDbValue($row['loanrequestwarninglangid']);
		$this->optinlangid->setDbValue($row['optinlangid']);
		$this->optoutlangid->setDbValue($row['optoutlangid']);
		$this->loanlimitlangid->setDbValue($row['loanlimitlangid']);
		$this->includefeesineligibilitycheck->setDbValue($row['includefeesineligibilitycheck']);
		$this->disbursementtype->setDbValue($row['disbursementtype']);
		$this->timegranularity->setDbValue($row['timegranularity']);
		$this->loanrequestconfirmationlangid->setDbValue($row['loanrequestconfirmationlangid']);
		$this->loanpaymentconfirmationlangid->setDbValue($row['loanpaymentconfirmationlangid']);
		$this->restrictive->setDbValue($row['restrictive']);
		$this->ignorenextbusinessday->setDbValue($row['ignorenextbusinessday']);
		$this->maxactiveloans->setDbValue($row['maxactiveloans']);
		$this->terminterestallocationtype->setDbValue($row['terminterestallocationtype']);
	}

	// Return a row with default values
	protected function newRow()
	{
		$row = [];
		$row['loantype'] = NULL;
		$row['loandesc'] = NULL;
		$row['feeperc'] = NULL;
		$row['feefixed'] = NULL;
		$row['feetax'] = NULL;
		$row['purchasetableid'] = NULL;
		$row['numberofdays'] = NULL;
		$row['nextloantype'] = NULL;
		$row['latefeetableid'] = NULL;
		$row['stopcalculatingafterdays'] = NULL;
		$row['graceperioddays'] = NULL;
		$row['feecalculationmode'] = NULL;
		$row['latefeewarninglangid'] = NULL;
		$row['latefeelangid'] = NULL;
		$row['flaggedlangid'] = NULL;
		$row['unblocklangid'] = NULL;
		$row['blockedlangid'] = NULL;
		$row['nexttierwarninglangid'] = NULL;
		$row['nexttiernotificationlangid'] = NULL;
		$row['ignoreholidays'] = NULL;
		$row['flagging'] = NULL;
		$row['flaggingdays'] = NULL;
		$row['flaggingwaringdays'] = NULL;
		$row['flagwarninglangid'] = NULL;
		$row['noofduedays'] = NULL;
		$row['optin'] = NULL;
		$row['optout'] = NULL;
		$row['noteligiblelangid'] = NULL;
		$row['loanrequestwarninglangid'] = NULL;
		$row['optinlangid'] = NULL;
		$row['optoutlangid'] = NULL;
		$row['loanlimitlangid'] = NULL;
		$row['includefeesineligibilitycheck'] = NULL;
		$row['disbursementtype'] = NULL;
		$row['timegranularity'] = NULL;
		$row['loanrequestconfirmationlangid'] = NULL;
		$row['loanpaymentconfirmationlangid'] = NULL;
		$row['restrictive'] = NULL;
		$row['ignorenextbusinessday'] = NULL;
		$row['maxactiveloans'] = NULL;
		$row['terminterestallocationtype'] = NULL;
		return $row;
	}

	// Render row values based on field settings
	public function renderRow()
	{
		global $Security, $Language, $CurrentLanguage;

		// Initialize URLs
		// Convert decimal values if posted back

		if ($this->feeperc->FormValue == $this->feeperc->CurrentValue && is_numeric(ConvertToFloatString($this->feeperc->CurrentValue)))
			$this->feeperc->CurrentValue = ConvertToFloatString($this->feeperc->CurrentValue);

		// Convert decimal values if posted back
		if ($this->feefixed->FormValue == $this->feefixed->CurrentValue && is_numeric(ConvertToFloatString($this->feefixed->CurrentValue)))
			$this->feefixed->CurrentValue = ConvertToFloatString($this->feefixed->CurrentValue);

		// Convert decimal values if posted back
		if ($this->feetax->FormValue == $this->feetax->CurrentValue && is_numeric(ConvertToFloatString($this->feetax->CurrentValue)))
			$this->feetax->CurrentValue = ConvertToFloatString($this->feetax->CurrentValue);

		// Call Row_Rendering event
		$this->Row_Rendering();

		// Common render codes for all row types
		// loantype
		// loandesc
		// feeperc
		// feefixed
		// feetax
		// purchasetableid
		// numberofdays
		// nextloantype
		// latefeetableid
		// stopcalculatingafterdays
		// graceperioddays
		// feecalculationmode
		// latefeewarninglangid
		// latefeelangid
		// flaggedlangid
		// unblocklangid
		// blockedlangid
		// nexttierwarninglangid
		// nexttiernotificationlangid
		// ignoreholidays
		// flagging
		// flaggingdays
		// flaggingwaringdays
		// flagwarninglangid
		// noofduedays
		// optin
		// optout
		// noteligiblelangid
		// loanrequestwarninglangid
		// optinlangid
		// optoutlangid
		// loanlimitlangid
		// includefeesineligibilitycheck
		// disbursementtype
		// timegranularity
		// loanrequestconfirmationlangid
		// loanpaymentconfirmationlangid
		// restrictive
		// ignorenextbusinessday
		// maxactiveloans
		// terminterestallocationtype

		if ($this->RowType == ROWTYPE_VIEW) { // View row

			// loantype
			$this->loantype->ViewValue = $this->loantype->CurrentValue;
			$this->loantype->ViewValue = FormatNumber($this->loantype->ViewValue, 0, -2, -2, -2);
			$this->loantype->ViewCustomAttributes = "";

			// loandesc
			$this->loandesc->ViewValue = $this->loandesc->CurrentValue;
			$this->loandesc->ViewCustomAttributes = "";

			// feeperc
			$this->feeperc->ViewValue = $this->feeperc->CurrentValue;
			$this->feeperc->ViewValue = FormatNumber($this->feeperc->ViewValue, 2, -2, -2, -2);
			$this->feeperc->ViewCustomAttributes = "";

			// feefixed
			$this->feefixed->ViewValue = $this->feefixed->CurrentValue;
			$this->feefixed->ViewValue = FormatNumber($this->feefixed->ViewValue, 2, -2, -2, -2);
			$this->feefixed->ViewCustomAttributes = "";

			// feetax
			$this->feetax->ViewValue = $this->feetax->CurrentValue;
			$this->feetax->ViewValue = FormatNumber($this->feetax->ViewValue, 2, -2, -2, -2);
			$this->feetax->ViewCustomAttributes = "";

			// purchasetableid
			$this->purchasetableid->ViewValue = $this->purchasetableid->CurrentValue;
			$this->purchasetableid->ViewValue = FormatNumber($this->purchasetableid->ViewValue, 0, -2, -2, -2);
			$this->purchasetableid->ViewCustomAttributes = "";

			// numberofdays
			$this->numberofdays->ViewValue = $this->numberofdays->CurrentValue;
			$this->numberofdays->ViewValue = FormatNumber($this->numberofdays->ViewValue, 0, -2, -2, -2);
			$this->numberofdays->ViewCustomAttributes = "";

			// nextloantype
			$this->nextloantype->ViewValue = $this->nextloantype->CurrentValue;
			$this->nextloantype->ViewValue = FormatNumber($this->nextloantype->ViewValue, 0, -2, -2, -2);
			$this->nextloantype->ViewCustomAttributes = "";

			// latefeetableid
			$this->latefeetableid->ViewValue = $this->latefeetableid->CurrentValue;
			$this->latefeetableid->ViewValue = FormatNumber($this->latefeetableid->ViewValue, 0, -2, -2, -2);
			$this->latefeetableid->ViewCustomAttributes = "";

			// stopcalculatingafterdays
			$this->stopcalculatingafterdays->ViewValue = $this->stopcalculatingafterdays->CurrentValue;
			$this->stopcalculatingafterdays->ViewValue = FormatNumber($this->stopcalculatingafterdays->ViewValue, 0, -2, -2, -2);
			$this->stopcalculatingafterdays->ViewCustomAttributes = "";

			// graceperioddays
			$this->graceperioddays->ViewValue = $this->graceperioddays->CurrentValue;
			$this->graceperioddays->ViewValue = FormatNumber($this->graceperioddays->ViewValue, 0, -2, -2, -2);
			$this->graceperioddays->ViewCustomAttributes = "";

			// feecalculationmode
			$this->feecalculationmode->ViewValue = $this->feecalculationmode->CurrentValue;
			$this->feecalculationmode->ViewValue = FormatNumber($this->feecalculationmode->ViewValue, 0, -2, -2, -2);
			$this->feecalculationmode->ViewCustomAttributes = "";

			// latefeewarninglangid
			$this->latefeewarninglangid->ViewValue = $this->latefeewarninglangid->CurrentValue;
			$this->latefeewarninglangid->ViewValue = FormatNumber($this->latefeewarninglangid->ViewValue, 0, -2, -2, -2);
			$this->latefeewarninglangid->ViewCustomAttributes = "";

			// latefeelangid
			$this->latefeelangid->ViewValue = $this->latefeelangid->CurrentValue;
			$this->latefeelangid->ViewValue = FormatNumber($this->latefeelangid->ViewValue, 0, -2, -2, -2);
			$this->latefeelangid->ViewCustomAttributes = "";

			// flaggedlangid
			$this->flaggedlangid->ViewValue = $this->flaggedlangid->CurrentValue;
			$this->flaggedlangid->ViewValue = FormatNumber($this->flaggedlangid->ViewValue, 0, -2, -2, -2);
			$this->flaggedlangid->ViewCustomAttributes = "";

			// unblocklangid
			$this->unblocklangid->ViewValue = $this->unblocklangid->CurrentValue;
			$this->unblocklangid->ViewValue = FormatNumber($this->unblocklangid->ViewValue, 0, -2, -2, -2);
			$this->unblocklangid->ViewCustomAttributes = "";

			// blockedlangid
			$this->blockedlangid->ViewValue = $this->blockedlangid->CurrentValue;
			$this->blockedlangid->ViewValue = FormatNumber($this->blockedlangid->ViewValue, 0, -2, -2, -2);
			$this->blockedlangid->ViewCustomAttributes = "";

			// nexttierwarninglangid
			$this->nexttierwarninglangid->ViewValue = $this->nexttierwarninglangid->CurrentValue;
			$this->nexttierwarninglangid->ViewValue = FormatNumber($this->nexttierwarninglangid->ViewValue, 0, -2, -2, -2);
			$this->nexttierwarninglangid->ViewCustomAttributes = "";

			// nexttiernotificationlangid
			$this->nexttiernotificationlangid->ViewValue = $this->nexttiernotificationlangid->CurrentValue;
			$this->nexttiernotificationlangid->ViewValue = FormatNumber($this->nexttiernotificationlangid->ViewValue, 0, -2, -2, -2);
			$this->nexttiernotificationlangid->ViewCustomAttributes = "";

			// ignoreholidays
			$this->ignoreholidays->ViewValue = $this->ignoreholidays->CurrentValue;
			$this->ignoreholidays->ViewValue = FormatNumber($this->ignoreholidays->ViewValue, 0, -2, -2, -2);
			$this->ignoreholidays->ViewCustomAttributes = "";

			// flagging
			$this->flagging->ViewValue = $this->flagging->CurrentValue;
			$this->flagging->ViewValue = FormatNumber($this->flagging->ViewValue, 0, -2, -2, -2);
			$this->flagging->ViewCustomAttributes = "";

			// flaggingdays
			$this->flaggingdays->ViewValue = $this->flaggingdays->CurrentValue;
			$this->flaggingdays->ViewValue = FormatNumber($this->flaggingdays->ViewValue, 0, -2, -2, -2);
			$this->flaggingdays->ViewCustomAttributes = "";

			// flaggingwaringdays
			$this->flaggingwaringdays->ViewValue = $this->flaggingwaringdays->CurrentValue;
			$this->flaggingwaringdays->ViewValue = FormatNumber($this->flaggingwaringdays->ViewValue, 0, -2, -2, -2);
			$this->flaggingwaringdays->ViewCustomAttributes = "";

			// flagwarninglangid
			$this->flagwarninglangid->ViewValue = $this->flagwarninglangid->CurrentValue;
			$this->flagwarninglangid->ViewValue = FormatNumber($this->flagwarninglangid->ViewValue, 0, -2, -2, -2);
			$this->flagwarninglangid->ViewCustomAttributes = "";

			// noofduedays
			$this->noofduedays->ViewValue = $this->noofduedays->CurrentValue;
			$this->noofduedays->ViewValue = FormatNumber($this->noofduedays->ViewValue, 0, -2, -2, -2);
			$this->noofduedays->ViewCustomAttributes = "";

			// optin
			$this->optin->ViewValue = $this->optin->CurrentValue;
			$this->optin->ViewValue = FormatNumber($this->optin->ViewValue, 0, -2, -2, -2);
			$this->optin->ViewCustomAttributes = "";

			// optout
			$this->optout->ViewValue = $this->optout->CurrentValue;
			$this->optout->ViewValue = FormatNumber($this->optout->ViewValue, 0, -2, -2, -2);
			$this->optout->ViewCustomAttributes = "";

			// noteligiblelangid
			$this->noteligiblelangid->ViewValue = $this->noteligiblelangid->CurrentValue;
			$this->noteligiblelangid->ViewValue = FormatNumber($this->noteligiblelangid->ViewValue, 0, -2, -2, -2);
			$this->noteligiblelangid->ViewCustomAttributes = "";

			// loanrequestwarninglangid
			$this->loanrequestwarninglangid->ViewValue = $this->loanrequestwarninglangid->CurrentValue;
			$this->loanrequestwarninglangid->ViewValue = FormatNumber($this->loanrequestwarninglangid->ViewValue, 0, -2, -2, -2);
			$this->loanrequestwarninglangid->ViewCustomAttributes = "";

			// optinlangid
			$this->optinlangid->ViewValue = $this->optinlangid->CurrentValue;
			$this->optinlangid->ViewValue = FormatNumber($this->optinlangid->ViewValue, 0, -2, -2, -2);
			$this->optinlangid->ViewCustomAttributes = "";

			// optoutlangid
			$this->optoutlangid->ViewValue = $this->optoutlangid->CurrentValue;
			$this->optoutlangid->ViewValue = FormatNumber($this->optoutlangid->ViewValue, 0, -2, -2, -2);
			$this->optoutlangid->ViewCustomAttributes = "";

			// loanlimitlangid
			$this->loanlimitlangid->ViewValue = $this->loanlimitlangid->CurrentValue;
			$this->loanlimitlangid->ViewValue = FormatNumber($this->loanlimitlangid->ViewValue, 0, -2, -2, -2);
			$this->loanlimitlangid->ViewCustomAttributes = "";

			// includefeesineligibilitycheck
			$this->includefeesineligibilitycheck->ViewValue = $this->includefeesineligibilitycheck->CurrentValue;
			$this->includefeesineligibilitycheck->ViewValue = FormatNumber($this->includefeesineligibilitycheck->ViewValue, 0, -2, -2, -2);
			$this->includefeesineligibilitycheck->ViewCustomAttributes = "";

			// disbursementtype
			$this->disbursementtype->ViewValue = $this->disbursementtype->CurrentValue;
			$this->disbursementtype->ViewValue = FormatNumber($this->disbursementtype->ViewValue, 0, -2, -2, -2);
			$this->disbursementtype->ViewCustomAttributes = "";

			// timegranularity
			$this->timegranularity->ViewValue = $this->timegranularity->CurrentValue;
			$this->timegranularity->ViewValue = FormatNumber($this->timegranularity->ViewValue, 0, -2, -2, -2);
			$this->timegranularity->ViewCustomAttributes = "";

			// loanrequestconfirmationlangid
			$this->loanrequestconfirmationlangid->ViewValue = $this->loanrequestconfirmationlangid->CurrentValue;
			$this->loanrequestconfirmationlangid->ViewValue = FormatNumber($this->loanrequestconfirmationlangid->ViewValue, 0, -2, -2, -2);
			$this->loanrequestconfirmationlangid->ViewCustomAttributes = "";

			// loanpaymentconfirmationlangid
			$this->loanpaymentconfirmationlangid->ViewValue = $this->loanpaymentconfirmationlangid->CurrentValue;
			$this->loanpaymentconfirmationlangid->ViewValue = FormatNumber($this->loanpaymentconfirmationlangid->ViewValue, 0, -2, -2, -2);
			$this->loanpaymentconfirmationlangid->ViewCustomAttributes = "";

			// restrictive
			$this->restrictive->ViewValue = $this->restrictive->CurrentValue;
			$this->restrictive->ViewValue = FormatNumber($this->restrictive->ViewValue, 0, -2, -2, -2);
			$this->restrictive->ViewCustomAttributes = "";

			// ignorenextbusinessday
			$this->ignorenextbusinessday->ViewValue = $this->ignorenextbusinessday->CurrentValue;
			$this->ignorenextbusinessday->ViewValue = FormatNumber($this->ignorenextbusinessday->ViewValue, 0, -2, -2, -2);
			$this->ignorenextbusinessday->ViewCustomAttributes = "";

			// maxactiveloans
			$this->maxactiveloans->ViewValue = $this->maxactiveloans->CurrentValue;
			$this->maxactiveloans->ViewValue = FormatNumber($this->maxactiveloans->ViewValue, 0, -2, -2, -2);
			$this->maxactiveloans->ViewCustomAttributes = "";

			// terminterestallocationtype
			$this->terminterestallocationtype->ViewValue = $this->terminterestallocationtype->CurrentValue;
			$this->terminterestallocationtype->ViewValue = FormatNumber($this->terminterestallocationtype->ViewValue, 0, -2, -2, -2);
			$this->terminterestallocationtype->ViewCustomAttributes = "";

			// loantype
			$this->loantype->LinkCustomAttributes = "";
			$this->loantype->HrefValue = "";
			$this->loantype->TooltipValue = "";

			// loandesc
			$this->loandesc->LinkCustomAttributes = "";
			$this->loandesc->HrefValue = "";
			$this->loandesc->TooltipValue = "";

			// feeperc
			$this->feeperc->LinkCustomAttributes = "";
			$this->feeperc->HrefValue = "";
			$this->feeperc->TooltipValue = "";

			// feefixed
			$this->feefixed->LinkCustomAttributes = "";
			$this->feefixed->HrefValue = "";
			$this->feefixed->TooltipValue = "";

			// feetax
			$this->feetax->LinkCustomAttributes = "";
			$this->feetax->HrefValue = "";
			$this->feetax->TooltipValue = "";

			// purchasetableid
			$this->purchasetableid->LinkCustomAttributes = "";
			$this->purchasetableid->HrefValue = "";
			$this->purchasetableid->TooltipValue = "";

			// numberofdays
			$this->numberofdays->LinkCustomAttributes = "";
			$this->numberofdays->HrefValue = "";
			$this->numberofdays->TooltipValue = "";

			// nextloantype
			$this->nextloantype->LinkCustomAttributes = "";
			$this->nextloantype->HrefValue = "";
			$this->nextloantype->TooltipValue = "";

			// latefeetableid
			$this->latefeetableid->LinkCustomAttributes = "";
			$this->latefeetableid->HrefValue = "";
			$this->latefeetableid->TooltipValue = "";

			// stopcalculatingafterdays
			$this->stopcalculatingafterdays->LinkCustomAttributes = "";
			$this->stopcalculatingafterdays->HrefValue = "";
			$this->stopcalculatingafterdays->TooltipValue = "";

			// graceperioddays
			$this->graceperioddays->LinkCustomAttributes = "";
			$this->graceperioddays->HrefValue = "";
			$this->graceperioddays->TooltipValue = "";

			// feecalculationmode
			$this->feecalculationmode->LinkCustomAttributes = "";
			$this->feecalculationmode->HrefValue = "";
			$this->feecalculationmode->TooltipValue = "";

			// latefeewarninglangid
			$this->latefeewarninglangid->LinkCustomAttributes = "";
			$this->latefeewarninglangid->HrefValue = "";
			$this->latefeewarninglangid->TooltipValue = "";

			// latefeelangid
			$this->latefeelangid->LinkCustomAttributes = "";
			$this->latefeelangid->HrefValue = "";
			$this->latefeelangid->TooltipValue = "";

			// flaggedlangid
			$this->flaggedlangid->LinkCustomAttributes = "";
			$this->flaggedlangid->HrefValue = "";
			$this->flaggedlangid->TooltipValue = "";

			// unblocklangid
			$this->unblocklangid->LinkCustomAttributes = "";
			$this->unblocklangid->HrefValue = "";
			$this->unblocklangid->TooltipValue = "";

			// blockedlangid
			$this->blockedlangid->LinkCustomAttributes = "";
			$this->blockedlangid->HrefValue = "";
			$this->blockedlangid->TooltipValue = "";

			// nexttierwarninglangid
			$this->nexttierwarninglangid->LinkCustomAttributes = "";
			$this->nexttierwarninglangid->HrefValue = "";
			$this->nexttierwarninglangid->TooltipValue = "";

			// nexttiernotificationlangid
			$this->nexttiernotificationlangid->LinkCustomAttributes = "";
			$this->nexttiernotificationlangid->HrefValue = "";
			$this->nexttiernotificationlangid->TooltipValue = "";

			// ignoreholidays
			$this->ignoreholidays->LinkCustomAttributes = "";
			$this->ignoreholidays->HrefValue = "";
			$this->ignoreholidays->TooltipValue = "";

			// flagging
			$this->flagging->LinkCustomAttributes = "";
			$this->flagging->HrefValue = "";
			$this->flagging->TooltipValue = "";

			// flaggingdays
			$this->flaggingdays->LinkCustomAttributes = "";
			$this->flaggingdays->HrefValue = "";
			$this->flaggingdays->TooltipValue = "";

			// flaggingwaringdays
			$this->flaggingwaringdays->LinkCustomAttributes = "";
			$this->flaggingwaringdays->HrefValue = "";
			$this->flaggingwaringdays->TooltipValue = "";

			// flagwarninglangid
			$this->flagwarninglangid->LinkCustomAttributes = "";
			$this->flagwarninglangid->HrefValue = "";
			$this->flagwarninglangid->TooltipValue = "";

			// noofduedays
			$this->noofduedays->LinkCustomAttributes = "";
			$this->noofduedays->HrefValue = "";
			$this->noofduedays->TooltipValue = "";

			// optin
			$this->optin->LinkCustomAttributes = "";
			$this->optin->HrefValue = "";
			$this->optin->TooltipValue = "";

			// optout
			$this->optout->LinkCustomAttributes = "";
			$this->optout->HrefValue = "";
			$this->optout->TooltipValue = "";

			// noteligiblelangid
			$this->noteligiblelangid->LinkCustomAttributes = "";
			$this->noteligiblelangid->HrefValue = "";
			$this->noteligiblelangid->TooltipValue = "";

			// loanrequestwarninglangid
			$this->loanrequestwarninglangid->LinkCustomAttributes = "";
			$this->loanrequestwarninglangid->HrefValue = "";
			$this->loanrequestwarninglangid->TooltipValue = "";

			// optinlangid
			$this->optinlangid->LinkCustomAttributes = "";
			$this->optinlangid->HrefValue = "";
			$this->optinlangid->TooltipValue = "";

			// optoutlangid
			$this->optoutlangid->LinkCustomAttributes = "";
			$this->optoutlangid->HrefValue = "";
			$this->optoutlangid->TooltipValue = "";

			// loanlimitlangid
			$this->loanlimitlangid->LinkCustomAttributes = "";
			$this->loanlimitlangid->HrefValue = "";
			$this->loanlimitlangid->TooltipValue = "";

			// includefeesineligibilitycheck
			$this->includefeesineligibilitycheck->LinkCustomAttributes = "";
			$this->includefeesineligibilitycheck->HrefValue = "";
			$this->includefeesineligibilitycheck->TooltipValue = "";

			// disbursementtype
			$this->disbursementtype->LinkCustomAttributes = "";
			$this->disbursementtype->HrefValue = "";
			$this->disbursementtype->TooltipValue = "";

			// timegranularity
			$this->timegranularity->LinkCustomAttributes = "";
			$this->timegranularity->HrefValue = "";
			$this->timegranularity->TooltipValue = "";

			// loanrequestconfirmationlangid
			$this->loanrequestconfirmationlangid->LinkCustomAttributes = "";
			$this->loanrequestconfirmationlangid->HrefValue = "";
			$this->loanrequestconfirmationlangid->TooltipValue = "";

			// loanpaymentconfirmationlangid
			$this->loanpaymentconfirmationlangid->LinkCustomAttributes = "";
			$this->loanpaymentconfirmationlangid->HrefValue = "";
			$this->loanpaymentconfirmationlangid->TooltipValue = "";

			// restrictive
			$this->restrictive->LinkCustomAttributes = "";
			$this->restrictive->HrefValue = "";
			$this->restrictive->TooltipValue = "";

			// ignorenextbusinessday
			$this->ignorenextbusinessday->LinkCustomAttributes = "";
			$this->ignorenextbusinessday->HrefValue = "";
			$this->ignorenextbusinessday->TooltipValue = "";

			// maxactiveloans
			$this->maxactiveloans->LinkCustomAttributes = "";
			$this->maxactiveloans->HrefValue = "";
			$this->maxactiveloans->TooltipValue = "";

			// terminterestallocationtype
			$this->terminterestallocationtype->LinkCustomAttributes = "";
			$this->terminterestallocationtype->HrefValue = "";
			$this->terminterestallocationtype->TooltipValue = "";
		}

		// Call Row Rendered event
		if ($this->RowType != ROWTYPE_AGGREGATEINIT)
			$this->Row_Rendered();
	}

	// Delete records based on current filter
	protected function deleteRows()
	{
		global $Language, $Security;
		if (!$Security->canDelete()) {
			$this->setFailureMessage($Language->phrase("NoDeletePermission")); // No delete permission
			return FALSE;
		}
		$deleteRows = TRUE;
		$sql = $this->getCurrentSql();
		$conn = $this->getConnection();
		$conn->raiseErrorFn = Config("ERROR_FUNC");
		$rs = $conn->execute($sql);
		$conn->raiseErrorFn = "";
		if ($rs === FALSE) {
			return FALSE;
		} elseif ($rs->EOF) {
			$this->setFailureMessage($Language->phrase("NoRecord")); // No record found
			$rs->close();
			return FALSE;
		}
		$rows = ($rs) ? $rs->getRows() : [];
		$conn->beginTrans();

		// Clone old rows
		$rsold = $rows;
		if ($rs)
			$rs->close();

		// Call row deleting event
		if ($deleteRows) {
			foreach ($rsold as $row) {
				$deleteRows = $this->Row_Deleting($row);
				if (!$deleteRows)
					break;
			}
		}
		if ($deleteRows) {
			$key = "";
			foreach ($rsold as $row) {
				$thisKey = "";
				if ($thisKey != "")
					$thisKey .= Config("COMPOSITE_KEY_SEPARATOR");
				$thisKey .= $row['loantype'];
				if (Config("DELETE_UPLOADED_FILES")) // Delete old files
					$this->deleteUploadedFiles($row);
				$conn->raiseErrorFn = Config("ERROR_FUNC");
				$deleteRows = $this->delete($row); // Delete
				$conn->raiseErrorFn = "";
				if ($deleteRows === FALSE)
					break;
				if ($key != "")
					$key .= ", ";
				$key .= $thisKey;
			}
		}
		if (!$deleteRows) {

			// Set up error message
			if ($this->getSuccessMessage() != "" || $this->getFailureMessage() != "") {

				// Use the message, do nothing
			} elseif ($this->CancelMessage != "") {
				$this->setFailureMessage($this->CancelMessage);
				$this->CancelMessage = "";
			} else {
				$this->setFailureMessage($Language->phrase("DeleteCancelled"));
			}
		}
		if ($deleteRows) {
			$conn->commitTrans(); // Commit the changes
		} else {
			$conn->rollbackTrans(); // Rollback changes
		}

		// Call Row Deleted event
		if ($deleteRows) {
			foreach ($rsold as $row) {
				$this->Row_Deleted($row);
			}
		}

		// Write JSON for API request (Support single row only)
		if (IsApi() && $deleteRows) {
			$row = $this->getRecordsFromRecordset($rsold, TRUE);
			WriteJson(["success" => TRUE, $this->TableVar => $row]);
		}
		return $deleteRows;
	}

	// Set up Breadcrumb
	protected function setupBreadcrumb()
	{
		global $Breadcrumb, $Language;
		$Breadcrumb = new Breadcrumb();
		$url = substr(CurrentUrl(), strrpos(CurrentUrl(), "/")+1);
		$Breadcrumb->add("list", $this->TableVar, $this->addMasterUrl("loantypeslist.php"), "", $this->TableVar, TRUE);
		$pageId = "delete";
		$Breadcrumb->add("delete", $pageId, $url);
	}

	// Setup lookup options
	public function setupLookupOptions($fld)
	{
		if ($fld->Lookup !== NULL && $fld->Lookup->Options === NULL) {

			// Get default connection and filter
			$conn = $this->getConnection();
			$lookupFilter = "";

			// No need to check any more
			$fld->Lookup->Options = [];

			// Set up lookup SQL and connection
			switch ($fld->FieldVar) {
				default:
					$lookupFilter = "";
					break;
			}

			// Always call to Lookup->getSql so that user can setup Lookup->Options in Lookup_Selecting server event
			$sql = $fld->Lookup->getSql(FALSE, "", $lookupFilter, $this);

			// Set up lookup cache
			if ($fld->UseLookupCache && $sql != "" && count($fld->Lookup->Options) == 0) {
				$totalCnt = $this->getRecordCount($sql, $conn);
				if ($totalCnt > $fld->LookupCacheCount) // Total count > cache count, do not cache
					return;
				$rs = $conn->execute($sql);
				$ar = [];
				while ($rs && !$rs->EOF) {
					$row = &$rs->fields;

					// Format the field values
					switch ($fld->FieldVar) {
					}
					$ar[strval($row[0])] = $row;
					$rs->moveNext();
				}
				if ($rs)
					$rs->close();
				$fld->Lookup->Options = $ar;
			}
		}
	}

	// Page Load event
	function Page_Load() {

		//echo "Page Load";
	}

	// Page Unload event
	function Page_Unload() {

		//echo "Page Unload";
	}

	// Page Redirecting event
	function Page_Redirecting(&$url) {

		// Example:
		//$url = "your URL";

	}

	// Message Showing event
	// $type = ''|'success'|'failure'|'warning'
	function Message_Showing(&$msg, $type) {
		if ($type == 'success') {

			//$msg = "your success message";
		} elseif ($type == 'failure') {

			//$msg = "your failure message";
		} elseif ($type == 'warning') {

			//$msg = "your warning message";
		} else {

			//$msg = "your message";
		}
	}

	// Page Render event
	function Page_Render() {

		//echo "Page Render";
	}

	// Page Data Rendering event
	function Page_DataRendering(&$header) {

		// Example:
		//$header = "your header";

	}

	// Page Data Rendered event
	function Page_DataRendered(&$footer) {

		// Example:
		//$footer = "your footer";

	}
} // End class
?>