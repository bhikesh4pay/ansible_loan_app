<?php
namespace PHPMaker2020\_4payadmin;

/**
 * Page class
 */
class extrafieldstemplate_list extends extrafieldstemplate
{

	// Page ID
	public $PageID = "list";

	// Project ID
	public $ProjectID = "{153C2D2E-60EE-4944-8753-3935EB38E8D6}";

	// Table name
	public $TableName = 'extrafieldstemplate';

	// Page object name
	public $PageObjName = "extrafieldstemplate_list";

	// Grid form hidden field names
	public $FormName = "fextrafieldstemplatelist";
	public $FormActionName = "k_action";
	public $FormKeyName = "k_key";
	public $FormOldKeyName = "k_oldkey";
	public $FormBlankRowName = "k_blankrow";
	public $FormKeyCountName = "key_count";

	// Page URLs
	public $AddUrl;
	public $EditUrl;
	public $CopyUrl;
	public $DeleteUrl;
	public $ViewUrl;
	public $ListUrl;

	// Export URLs
	public $ExportPrintUrl;
	public $ExportHtmlUrl;
	public $ExportExcelUrl;
	public $ExportWordUrl;
	public $ExportXmlUrl;
	public $ExportCsvUrl;
	public $ExportPdfUrl;

	// Custom export
	public $ExportExcelCustom = FALSE;
	public $ExportWordCustom = FALSE;
	public $ExportPdfCustom = FALSE;
	public $ExportEmailCustom = FALSE;

	// Update URLs
	public $InlineAddUrl;
	public $InlineCopyUrl;
	public $InlineEditUrl;
	public $GridAddUrl;
	public $GridEditUrl;
	public $MultiDeleteUrl;
	public $MultiUpdateUrl;

	// Audit Trail
	public $AuditTrailOnAdd = TRUE;
	public $AuditTrailOnEdit = TRUE;
	public $AuditTrailOnDelete = TRUE;
	public $AuditTrailOnView = FALSE;
	public $AuditTrailOnViewData = FALSE;
	public $AuditTrailOnSearch = FALSE;

	// Page headings
	public $Heading = "";
	public $Subheading = "";
	public $PageHeader;
	public $PageFooter;

	// Token
	public $Token = "";
	public $TokenTimeout = 0;
	public $CheckToken;

	// Page heading
	public function pageHeading()
	{
		global $Language;
		if ($this->Heading != "")
			return $this->Heading;
		if (method_exists($this, "tableCaption"))
			return $this->tableCaption();
		return "";
	}

	// Page subheading
	public function pageSubheading()
	{
		global $Language;
		if ($this->Subheading != "")
			return $this->Subheading;
		if ($this->TableName)
			return $Language->phrase($this->PageID);
		return "";
	}

	// Page name
	public function pageName()
	{
		return CurrentPageName();
	}

	// Page URL
	public function pageUrl()
	{
		$url = CurrentPageName() . "?";
		if ($this->UseTokenInUrl)
			$url .= "t=" . $this->TableVar . "&"; // Add page token
		return $url;
	}

	// Messages
	private $_message = "";
	private $_failureMessage = "";
	private $_successMessage = "";
	private $_warningMessage = "";

	// Get message
	public function getMessage()
	{
		return isset($_SESSION[SESSION_MESSAGE]) ? $_SESSION[SESSION_MESSAGE] : $this->_message;
	}

	// Set message
	public function setMessage($v)
	{
		AddMessage($this->_message, $v);
		$_SESSION[SESSION_MESSAGE] = $this->_message;
	}

	// Get failure message
	public function getFailureMessage()
	{
		return isset($_SESSION[SESSION_FAILURE_MESSAGE]) ? $_SESSION[SESSION_FAILURE_MESSAGE] : $this->_failureMessage;
	}

	// Set failure message
	public function setFailureMessage($v)
	{
		AddMessage($this->_failureMessage, $v);
		$_SESSION[SESSION_FAILURE_MESSAGE] = $this->_failureMessage;
	}

	// Get success message
	public function getSuccessMessage()
	{
		return isset($_SESSION[SESSION_SUCCESS_MESSAGE]) ? $_SESSION[SESSION_SUCCESS_MESSAGE] : $this->_successMessage;
	}

	// Set success message
	public function setSuccessMessage($v)
	{
		AddMessage($this->_successMessage, $v);
		$_SESSION[SESSION_SUCCESS_MESSAGE] = $this->_successMessage;
	}

	// Get warning message
	public function getWarningMessage()
	{
		return isset($_SESSION[SESSION_WARNING_MESSAGE]) ? $_SESSION[SESSION_WARNING_MESSAGE] : $this->_warningMessage;
	}

	// Set warning message
	public function setWarningMessage($v)
	{
		AddMessage($this->_warningMessage, $v);
		$_SESSION[SESSION_WARNING_MESSAGE] = $this->_warningMessage;
	}

	// Clear message
	public function clearMessage()
	{
		$this->_message = "";
		$_SESSION[SESSION_MESSAGE] = "";
	}

	// Clear failure message
	public function clearFailureMessage()
	{
		$this->_failureMessage = "";
		$_SESSION[SESSION_FAILURE_MESSAGE] = "";
	}

	// Clear success message
	public function clearSuccessMessage()
	{
		$this->_successMessage = "";
		$_SESSION[SESSION_SUCCESS_MESSAGE] = "";
	}

	// Clear warning message
	public function clearWarningMessage()
	{
		$this->_warningMessage = "";
		$_SESSION[SESSION_WARNING_MESSAGE] = "";
	}

	// Clear messages
	public function clearMessages()
	{
		$this->clearMessage();
		$this->clearFailureMessage();
		$this->clearSuccessMessage();
		$this->clearWarningMessage();
	}

	// Show message
	public function showMessage()
	{
		$hidden = FALSE;
		$html = "";

		// Message
		$message = $this->getMessage();
		if (method_exists($this, "Message_Showing"))
			$this->Message_Showing($message, "");
		if ($message != "") { // Message in Session, display
			if (!$hidden)
				$message = '<button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button>' . $message;
			$html .= '<div class="alert alert-info alert-dismissible ew-info"><i class="icon fas fa-info"></i>' . $message . '</div>';
			$_SESSION[SESSION_MESSAGE] = ""; // Clear message in Session
		}

		// Warning message
		$warningMessage = $this->getWarningMessage();
		if (method_exists($this, "Message_Showing"))
			$this->Message_Showing($warningMessage, "warning");
		if ($warningMessage != "") { // Message in Session, display
			if (!$hidden)
				$warningMessage = '<button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button>' . $warningMessage;
			$html .= '<div class="alert alert-warning alert-dismissible ew-warning"><i class="icon fas fa-exclamation"></i>' . $warningMessage . '</div>';
			$_SESSION[SESSION_WARNING_MESSAGE] = ""; // Clear message in Session
		}

		// Success message
		$successMessage = $this->getSuccessMessage();
		if (method_exists($this, "Message_Showing"))
			$this->Message_Showing($successMessage, "success");
		if ($successMessage != "") { // Message in Session, display
			if (!$hidden)
				$successMessage = '<button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button>' . $successMessage;
			$html .= '<div class="alert alert-success alert-dismissible ew-success"><i class="icon fas fa-check"></i>' . $successMessage . '</div>';
			$_SESSION[SESSION_SUCCESS_MESSAGE] = ""; // Clear message in Session
		}

		// Failure message
		$errorMessage = $this->getFailureMessage();
		if (method_exists($this, "Message_Showing"))
			$this->Message_Showing($errorMessage, "failure");
		if ($errorMessage != "") { // Message in Session, display
			if (!$hidden)
				$errorMessage = '<button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button>' . $errorMessage;
			$html .= '<div class="alert alert-danger alert-dismissible ew-error"><i class="icon fas fa-ban"></i>' . $errorMessage . '</div>';
			$_SESSION[SESSION_FAILURE_MESSAGE] = ""; // Clear message in Session
		}
		echo '<div class="ew-message-dialog' . (($hidden) ? ' d-none' : "") . '">' . $html . '</div>';
	}

	// Get message as array
	public function getMessages()
	{
		$ar = [];

		// Message
		$message = $this->getMessage();

		//if (method_exists($this, "Message_Showing"))
		//	$this->Message_Showing($message, "");

		if ($message != "") { // Message in Session, display
			$ar["message"] = $message;
			$_SESSION[SESSION_MESSAGE] = ""; // Clear message in Session
		}

		// Warning message
		$warningMessage = $this->getWarningMessage();

		//if (method_exists($this, "Message_Showing"))
		//	$this->Message_Showing($warningMessage, "warning");

		if ($warningMessage != "") { // Message in Session, display
			$ar["warningMessage"] = $warningMessage;
			$_SESSION[SESSION_WARNING_MESSAGE] = ""; // Clear message in Session
		}

		// Success message
		$successMessage = $this->getSuccessMessage();

		//if (method_exists($this, "Message_Showing"))
		//	$this->Message_Showing($successMessage, "success");

		if ($successMessage != "") { // Message in Session, display
			$ar["successMessage"] = $successMessage;
			$_SESSION[SESSION_SUCCESS_MESSAGE] = ""; // Clear message in Session
		}

		// Failure message
		$failureMessage = $this->getFailureMessage();

		//if (method_exists($this, "Message_Showing"))
		//	$this->Message_Showing($failureMessage, "failure");

		if ($failureMessage != "") { // Message in Session, display
			$ar["failureMessage"] = $failureMessage;
			$_SESSION[SESSION_FAILURE_MESSAGE] = ""; // Clear message in Session
		}
		return $ar;
	}

	// Show Page Header
	public function showPageHeader()
	{
		$header = $this->PageHeader;
		$this->Page_DataRendering($header);
		if ($header != "") { // Header exists, display
			echo '<p id="ew-page-header">' . $header . '</p>';
		}
	}

	// Show Page Footer
	public function showPageFooter()
	{
		$footer = $this->PageFooter;
		$this->Page_DataRendered($footer);
		if ($footer != "") { // Footer exists, display
			echo '<p id="ew-page-footer">' . $footer . '</p>';
		}
	}

	// Validate page request
	protected function isPageRequest()
	{
		global $CurrentForm;
		if ($this->UseTokenInUrl) {
			if ($CurrentForm)
				return ($this->TableVar == $CurrentForm->getValue("t"));
			if (Get("t") !== NULL)
				return ($this->TableVar == Get("t"));
		}
		return TRUE;
	}

	// Valid Post
	protected function validPost()
	{
		if (!$this->CheckToken || !IsPost() || IsApi())
			return TRUE;
		if (Post(Config("TOKEN_NAME")) === NULL)
			return FALSE;
		$fn = Config("CHECK_TOKEN_FUNC");
		if (is_callable($fn))
			return $fn(Post(Config("TOKEN_NAME")), $this->TokenTimeout);
		return FALSE;
	}

	// Create Token
	public function createToken()
	{
		global $CurrentToken;
		$fn = Config("CREATE_TOKEN_FUNC"); // Always create token, required by API file/lookup request
		if ($this->Token == "" && is_callable($fn)) // Create token
			$this->Token = $fn();
		$CurrentToken = $this->Token; // Save to global variable
	}

	// Constructor
	public function __construct()
	{
		global $Language, $DashboardReport;
		global $UserTable;

		// Check token
		$this->CheckToken = Config("CHECK_TOKEN");

		// Initialize
		$GLOBALS["Page"] = &$this;
		$this->TokenTimeout = SessionTimeoutTime();

		// Language object
		if (!isset($Language))
			$Language = new Language();

		// Parent constuctor
		parent::__construct();

		// Table object (extrafieldstemplate)
		if (!isset($GLOBALS["extrafieldstemplate"]) || get_class($GLOBALS["extrafieldstemplate"]) == PROJECT_NAMESPACE . "extrafieldstemplate") {
			$GLOBALS["extrafieldstemplate"] = &$this;
			$GLOBALS["Table"] = &$GLOBALS["extrafieldstemplate"];
		}

		// Initialize URLs
		$this->ExportPrintUrl = $this->pageUrl() . "export=print";
		$this->ExportExcelUrl = $this->pageUrl() . "export=excel";
		$this->ExportWordUrl = $this->pageUrl() . "export=word";
		$this->ExportPdfUrl = $this->pageUrl() . "export=pdf";
		$this->ExportHtmlUrl = $this->pageUrl() . "export=html";
		$this->ExportXmlUrl = $this->pageUrl() . "export=xml";
		$this->ExportCsvUrl = $this->pageUrl() . "export=csv";
		$this->AddUrl = "extrafieldstemplateadd.php";
		$this->InlineAddUrl = $this->pageUrl() . "action=add";
		$this->GridAddUrl = $this->pageUrl() . "action=gridadd";
		$this->GridEditUrl = $this->pageUrl() . "action=gridedit";
		$this->MultiDeleteUrl = "extrafieldstemplatedelete.php";
		$this->MultiUpdateUrl = "extrafieldstemplateupdate.php";

		// Table object (admin)
		if (!isset($GLOBALS['admin']))
			$GLOBALS['admin'] = new admin();

		// Page ID (for backward compatibility only)
		if (!defined(PROJECT_NAMESPACE . "PAGE_ID"))
			define(PROJECT_NAMESPACE . "PAGE_ID", 'list');

		// Table name (for backward compatibility only)
		if (!defined(PROJECT_NAMESPACE . "TABLE_NAME"))
			define(PROJECT_NAMESPACE . "TABLE_NAME", 'extrafieldstemplate');

		// Start timer
		if (!isset($GLOBALS["DebugTimer"]))
			$GLOBALS["DebugTimer"] = new Timer();

		// Debug message
		LoadDebugMessage();

		// Open connection
		if (!isset($GLOBALS["Conn"]))
			$GLOBALS["Conn"] = $this->getConnection();

		// User table object (admin)
		$UserTable = $UserTable ?: new admin();

		// List options
		$this->ListOptions = new ListOptions();
		$this->ListOptions->TableVar = $this->TableVar;

		// Export options
		$this->ExportOptions = new ListOptions("div");
		$this->ExportOptions->TagClassName = "ew-export-option";

		// Import options
		$this->ImportOptions = new ListOptions("div");
		$this->ImportOptions->TagClassName = "ew-import-option";

		// Other options
		if (!$this->OtherOptions)
			$this->OtherOptions = new ListOptionsArray();
		$this->OtherOptions["addedit"] = new ListOptions("div");
		$this->OtherOptions["addedit"]->TagClassName = "ew-add-edit-option";
		$this->OtherOptions["detail"] = new ListOptions("div");
		$this->OtherOptions["detail"]->TagClassName = "ew-detail-option";
		$this->OtherOptions["action"] = new ListOptions("div");
		$this->OtherOptions["action"]->TagClassName = "ew-action-option";

		// Filter options
		$this->FilterOptions = new ListOptions("div");
		$this->FilterOptions->TagClassName = "ew-filter-option fextrafieldstemplatelistsrch";

		// List actions
		$this->ListActions = new ListActions();
	}

	// Terminate page
	public function terminate($url = "")
	{
		global $ExportFileName, $TempImages, $DashboardReport;

		// Page Unload event
		$this->Page_Unload();

		// Global Page Unloaded event (in userfn*.php)
		Page_Unloaded();

		// Export
		global $extrafieldstemplate;
		if ($this->CustomExport && $this->CustomExport == $this->Export && array_key_exists($this->CustomExport, Config("EXPORT_CLASSES"))) {
				$content = ob_get_contents();
			if ($ExportFileName == "")
				$ExportFileName = $this->TableVar;
			$class = PROJECT_NAMESPACE . Config("EXPORT_CLASSES." . $this->CustomExport);
			if (class_exists($class)) {
				$doc = new $class($extrafieldstemplate);
				$doc->Text = @$content;
				if ($this->isExport("email"))
					echo $this->exportEmail($doc->Text);
				else
					$doc->export();
				DeleteTempImages(); // Delete temp images
				exit();
			}
		}
		if (!IsApi())
			$this->Page_Redirecting($url);

		// Close connection
		CloseConnections();

		// Return for API
		if (IsApi()) {
			$res = $url === TRUE;
			if (!$res) // Show error
				WriteJson(array_merge(["success" => FALSE], $this->getMessages()));
			return;
		}

		// Go to URL if specified
		if ($url != "") {
			if (!Config("DEBUG") && ob_get_length())
				ob_end_clean();
			SaveDebugMessage();
			AddHeader("Location", $url);
		}
		exit();
	}

	// Get records from recordset
	protected function getRecordsFromRecordset($rs, $current = FALSE)
	{
		$rows = [];
		if (is_object($rs)) { // Recordset
			while ($rs && !$rs->EOF) {
				$this->loadRowValues($rs); // Set up DbValue/CurrentValue
				$row = $this->getRecordFromArray($rs->fields);
				if ($current)
					return $row;
				else
					$rows[] = $row;
				$rs->moveNext();
			}
		} elseif (is_array($rs)) {
			foreach ($rs as $ar) {
				$row = $this->getRecordFromArray($ar);
				if ($current)
					return $row;
				else
					$rows[] = $row;
			}
		}
		return $rows;
	}

	// Get record from array
	protected function getRecordFromArray($ar)
	{
		$row = [];
		if (is_array($ar)) {
			foreach ($ar as $fldname => $val) {
				if (array_key_exists($fldname, $this->fields) && ($this->fields[$fldname]->Visible || $this->fields[$fldname]->IsPrimaryKey)) { // Primary key or Visible
					$fld = &$this->fields[$fldname];
					if ($fld->HtmlTag == "FILE") { // Upload field
						if (EmptyValue($val)) {
							$row[$fldname] = NULL;
						} else {
							if ($fld->DataType == DATATYPE_BLOB) {
								$url = FullUrl(GetApiUrl(Config("API_FILE_ACTION"),
									Config("API_OBJECT_NAME") . "=" . $fld->TableVar . "&" .
									Config("API_FIELD_NAME") . "=" . $fld->Param . "&" .
									Config("API_KEY_NAME") . "=" . rawurlencode($this->getRecordKeyValue($ar)))); //*** need to add this? API may not be in the same folder
								$row[$fldname] = ["type" => ContentType($val), "url" => $url, "name" => $fld->Param . ContentExtension($val)];
							} elseif (!$fld->UploadMultiple || !ContainsString($val, Config("MULTIPLE_UPLOAD_SEPARATOR"))) { // Single file
								$url = FullUrl(GetApiUrl(Config("API_FILE_ACTION"),
									Config("API_OBJECT_NAME") . "=" . $fld->TableVar . "&" .
									"fn=" . Encrypt($fld->physicalUploadPath() . $val)));
								$row[$fldname] = ["type" => MimeContentType($val), "url" => $url, "name" => $val];
							} else { // Multiple files
								$files = explode(Config("MULTIPLE_UPLOAD_SEPARATOR"), $val);
								$ar = [];
								foreach ($files as $file) {
									$url = FullUrl(GetApiUrl(Config("API_FILE_ACTION"),
										Config("API_OBJECT_NAME") . "=" . $fld->TableVar . "&" .
										"fn=" . Encrypt($fld->physicalUploadPath() . $file)));
									if (!EmptyValue($file))
										$ar[] = ["type" => MimeContentType($file), "url" => $url, "name" => $file];
								}
								$row[$fldname] = $ar;
							}
						}
					} else {
						if ($fld->DataType == DATATYPE_MEMO && $fld->MemoMaxLength > 0)
							$val = TruncateMemo($val, $fld->MemoMaxLength, $fld->TruncateMemoRemoveHtml);
						$row[$fldname] = $val;
					}
				}
			}
		}
		return $row;
	}

	// Get record key value from array
	protected function getRecordKeyValue($ar)
	{
		$key = "";
		if (is_array($ar)) {
			$key .= @$ar['extrafieldsid'];
		}
		return $key;
	}

	/**
	 * Hide fields for add/edit
	 *
	 * @return void
	 */
	protected function hideFieldsForAddEdit()
	{
		if ($this->isAdd() || $this->isCopy() || $this->isGridAdd())
			$this->extrafieldsid->Visible = FALSE;
	}

	// Lookup data
	public function lookup()
	{
		global $Language, $Security;
		if (!isset($Language))
			$Language = new Language(Config("LANGUAGE_FOLDER"), Post("language", ""));

		// Set up API request
		if (!ValidApiRequest())
			return FALSE;
		$this->setupApiSecurity();

		// Get lookup object
		$fieldName = Post("field");
		if (!array_key_exists($fieldName, $this->fields))
			return FALSE;
		$lookupField = $this->fields[$fieldName];
		$lookup = $lookupField->Lookup;
		if ($lookup === NULL)
			return FALSE;
		$tbl = $lookup->getTable();
		if (!$Security->allowLookup(Config("PROJECT_ID") . $tbl->TableName)) // Lookup permission
			return FALSE;

		// Get lookup parameters
		$lookupType = Post("ajax", "unknown");
		$pageSize = -1;
		$offset = -1;
		$searchValue = "";
		if (SameText($lookupType, "modal")) {
			$searchValue = Post("sv", "");
			$pageSize = Post("recperpage", 10);
			$offset = Post("start", 0);
		} elseif (SameText($lookupType, "autosuggest")) {
			$searchValue = Param("q", "");
			$pageSize = Param("n", -1);
			$pageSize = is_numeric($pageSize) ? (int)$pageSize : -1;
			if ($pageSize <= 0)
				$pageSize = Config("AUTO_SUGGEST_MAX_ENTRIES");
			$start = Param("start", -1);
			$start = is_numeric($start) ? (int)$start : -1;
			$page = Param("page", -1);
			$page = is_numeric($page) ? (int)$page : -1;
			$offset = $start >= 0 ? $start : ($page > 0 && $pageSize > 0 ? ($page - 1) * $pageSize : 0);
		}
		$userSelect = Decrypt(Post("s", ""));
		$userFilter = Decrypt(Post("f", ""));
		$userOrderBy = Decrypt(Post("o", ""));
		$keys = Post("keys");
		$lookup->LookupType = $lookupType; // Lookup type
		if ($keys !== NULL) { // Selected records from modal
			if (is_array($keys))
				$keys = implode(Config("MULTIPLE_OPTION_SEPARATOR"), $keys);
			$lookup->FilterFields = []; // Skip parent fields if any
			$lookup->FilterValues[] = $keys; // Lookup values
			$pageSize = -1; // Show all records
		} else { // Lookup values
			$lookup->FilterValues[] = Post("v0", Post("lookupValue", ""));
		}
		$cnt = is_array($lookup->FilterFields) ? count($lookup->FilterFields) : 0;
		for ($i = 1; $i <= $cnt; $i++)
			$lookup->FilterValues[] = Post("v" . $i, "");
		$lookup->SearchValue = $searchValue;
		$lookup->PageSize = $pageSize;
		$lookup->Offset = $offset;
		if ($userSelect != "")
			$lookup->UserSelect = $userSelect;
		if ($userFilter != "")
			$lookup->UserFilter = $userFilter;
		if ($userOrderBy != "")
			$lookup->UserOrderBy = $userOrderBy;
		$lookup->toJson($this); // Use settings from current page
	}

	// Set up API security
	public function setupApiSecurity()
	{
		global $Security;

		// Setup security for API request
		if ($Security->isLoggedIn()) $Security->TablePermission_Loading();
		$Security->loadCurrentUserLevel(Config("PROJECT_ID") . $this->TableName);
		if ($Security->isLoggedIn()) $Security->TablePermission_Loaded();
	}

	// Class variables
	public $ListOptions; // List options
	public $ExportOptions; // Export options
	public $SearchOptions; // Search options
	public $OtherOptions; // Other options
	public $FilterOptions; // Filter options
	public $ImportOptions; // Import options
	public $ListActions; // List actions
	public $SelectedCount = 0;
	public $SelectedIndex = 0;
	public $DisplayRecords = 10;
	public $StartRecord;
	public $StopRecord;
	public $TotalRecords = 0;
	public $RecordRange = 10;
	public $PageSizes = ""; // Page sizes (comma separated)
	public $DefaultSearchWhere = ""; // Default search WHERE clause
	public $SearchWhere = ""; // Search WHERE clause
	public $SearchPanelClass = "ew-search-panel collapse"; // Search Panel class
	public $SearchRowCount = 0; // For extended search
	public $SearchColumnCount = 0; // For extended search
	public $SearchFieldsPerRow = 1; // For extended search
	public $RecordCount = 0; // Record count
	public $EditRowCount;
	public $StartRowCount = 1;
	public $RowCount = 0;
	public $Attrs = []; // Row attributes and cell attributes
	public $RowIndex = 0; // Row index
	public $KeyCount = 0; // Key count
	public $RowAction = ""; // Row action
	public $RowOldKey = ""; // Row old key (for copy)
	public $MultiColumnClass = "col-sm";
	public $MultiColumnEditClass = "w-100";
	public $DbMasterFilter = ""; // Master filter
	public $DbDetailFilter = ""; // Detail filter
	public $MasterRecordExists;
	public $MultiSelectKey;
	public $Command;
	public $RestoreSearch = FALSE;
	public $DetailPages;
	public $OldRecordset;

	//
	// Page run
	//

	public function run()
	{
		global $ExportType, $CustomExportType, $ExportFileName, $UserProfile, $Language, $Security, $CurrentForm,
			$FormError, $SearchError;

		// User profile
		$UserProfile = new UserProfile();

		// Security
		if (ValidApiRequest()) { // API request
			$this->setupApiSecurity(); // Set up API Security
			if (!$Security->canList()) {
				SetStatus(401); // Unauthorized
				return;
			}
		} else {
			$Security = new AdvancedSecurity();
			if (IsPasswordExpired())
				$this->terminate(GetUrl("changepwd.php"));
			if (!$Security->isLoggedIn())
				$Security->autoLogin();
			if ($Security->isLoggedIn())
				$Security->TablePermission_Loading();
			$Security->loadCurrentUserLevel($this->ProjectID . $this->TableName);
			if ($Security->isLoggedIn())
				$Security->TablePermission_Loaded();
			if (!$Security->canList()) {
				$Security->saveLastUrl();
				$this->setFailureMessage(DeniedMessage()); // Set no permission
				$this->terminate(GetUrl("index.php"));
				return;
			}
		}

		// Get export parameters
		$custom = "";
		if (Param("export") !== NULL) {
			$this->Export = Param("export");
			$custom = Param("custom", "");
		} elseif (IsPost()) {
			if (Post("exporttype") !== NULL)
				$this->Export = Post("exporttype");
			$custom = Post("custom", "");
		} elseif (Get("cmd") == "json") {
			$this->Export = Get("cmd");
		} else {
			$this->setExportReturnUrl(CurrentUrl());
		}
		$ExportFileName = $this->TableVar; // Get export file, used in header

		// Get custom export parameters
		if ($this->isExport() && $custom != "") {
			$this->CustomExport = $this->Export;
			$this->Export = "print";
		}
		$CustomExportType = $this->CustomExport;
		$ExportType = $this->Export; // Get export parameter, used in header

		// Update Export URLs
		if (Config("USE_PHPEXCEL"))
			$this->ExportExcelCustom = FALSE;
		if ($this->ExportExcelCustom)
			$this->ExportExcelUrl .= "&amp;custom=1";
		if (Config("USE_PHPWORD"))
			$this->ExportWordCustom = FALSE;
		if ($this->ExportWordCustom)
			$this->ExportWordUrl .= "&amp;custom=1";
		if ($this->ExportPdfCustom)
			$this->ExportPdfUrl .= "&amp;custom=1";
		$this->CurrentAction = Param("action"); // Set up current action

		// Get grid add count
		$gridaddcnt = Get(Config("TABLE_GRID_ADD_ROW_COUNT"), "");
		if (is_numeric($gridaddcnt) && $gridaddcnt > 0)
			$this->GridAddRowCount = $gridaddcnt;

		// Set up list options
		$this->setupListOptions();

		// Setup export options
		$this->setupExportOptions();
		$this->extrafieldsid->setVisibility();
		$this->merchantid->setVisibility();
		$this->name->setVisibility();
		$this->field1label->setVisibility();
		$this->field1type->setVisibility();
		$this->field1mandatory->setVisibility();
		$this->field1display->setVisibility();
		$this->field1displaysequence->setVisibility();
		$this->field1domain->setVisibility();
		$this->field2label->setVisibility();
		$this->field2type->setVisibility();
		$this->field2mandatory->setVisibility();
		$this->field2display->setVisibility();
		$this->field2displaysequence->setVisibility();
		$this->field2domain->setVisibility();
		$this->field3label->setVisibility();
		$this->field3type->setVisibility();
		$this->field3mandatory->setVisibility();
		$this->field3display->setVisibility();
		$this->field3displaysequence->setVisibility();
		$this->field3domain->setVisibility();
		$this->field4label->setVisibility();
		$this->field4type->setVisibility();
		$this->field4mandatory->setVisibility();
		$this->field4display->setVisibility();
		$this->field4displaysequence->setVisibility();
		$this->field4domain->setVisibility();
		$this->field5label->setVisibility();
		$this->field5type->setVisibility();
		$this->field5mandatory->setVisibility();
		$this->field5display->setVisibility();
		$this->field5displaysequence->setVisibility();
		$this->field5domain->setVisibility();
		$this->field6label->setVisibility();
		$this->field6type->setVisibility();
		$this->field6mandatory->setVisibility();
		$this->field6display->setVisibility();
		$this->field6displaysequence->setVisibility();
		$this->field6domain->setVisibility();
		$this->field7label->setVisibility();
		$this->field7type->setVisibility();
		$this->field7mandatory->setVisibility();
		$this->field7display->setVisibility();
		$this->field7displaysequence->setVisibility();
		$this->field7domain->setVisibility();
		$this->field8label->setVisibility();
		$this->field8type->setVisibility();
		$this->field8mandatory->setVisibility();
		$this->field8display->setVisibility();
		$this->field8displaysequence->setVisibility();
		$this->field8domain->setVisibility();
		$this->field9label->setVisibility();
		$this->field9type->setVisibility();
		$this->field9mandatory->setVisibility();
		$this->field9display->setVisibility();
		$this->field9displaysequence->setVisibility();
		$this->field9domain->setVisibility();
		$this->field10label->setVisibility();
		$this->field10type->setVisibility();
		$this->field10mandatory->setVisibility();
		$this->field10display->setVisibility();
		$this->field10displaysequence->setVisibility();
		$this->field10domain->setVisibility();
		$this->lastupdatedate->setVisibility();
		$this->hideFieldsForAddEdit();

		// Global Page Loading event (in userfn*.php)
		Page_Loading();

		// Page Load event
		$this->Page_Load();

		// Check token
		if (!$this->validPost()) {
			Write($Language->phrase("InvalidPostRequest"));
			$this->terminate();
		}

		// Create Token
		$this->createToken();

		// Setup other options
		$this->setupOtherOptions();

		// Set up custom action (compatible with old version)
		foreach ($this->CustomActions as $name => $action)
			$this->ListActions->add($name, $action);

		// Show checkbox column if multiple action
		foreach ($this->ListActions->Items as $listaction) {
			if ($listaction->Select == ACTION_MULTIPLE && $listaction->Allow) {
				$this->ListOptions["checkbox"]->Visible = TRUE;
				break;
			}
		}

		// Set up lookup cache
		// Search filters

		$srchAdvanced = ""; // Advanced search filter
		$srchBasic = ""; // Basic search filter
		$filter = "";

		// Get command
		$this->Command = strtolower(Get("cmd"));
		if ($this->isPageRequest()) { // Validate request

			// Process list action first
			if ($this->processListAction()) // Ajax request
				$this->terminate();

			// Set up records per page
			$this->setupDisplayRecords();

			// Handle reset command
			$this->resetCmd();

			// Set up Breadcrumb
			if (!$this->isExport())
				$this->setupBreadcrumb();

			// Hide list options
			if ($this->isExport()) {
				$this->ListOptions->hideAllOptions(["sequence"]);
				$this->ListOptions->UseDropDownButton = FALSE; // Disable drop down button
				$this->ListOptions->UseButtonGroup = FALSE; // Disable button group
			} elseif ($this->isGridAdd() || $this->isGridEdit()) {
				$this->ListOptions->hideAllOptions();
				$this->ListOptions->UseDropDownButton = FALSE; // Disable drop down button
				$this->ListOptions->UseButtonGroup = FALSE; // Disable button group
			}

			// Hide options
			if ($this->isExport() || $this->CurrentAction) {
				$this->ExportOptions->hideAllOptions();
				$this->FilterOptions->hideAllOptions();
				$this->ImportOptions->hideAllOptions();
			}

			// Hide other options
			if ($this->isExport())
				$this->OtherOptions->hideAllOptions();

			// Get default search criteria
			AddFilter($this->DefaultSearchWhere, $this->basicSearchWhere(TRUE));
			AddFilter($this->DefaultSearchWhere, $this->advancedSearchWhere(TRUE));

			// Get basic search values
			$this->loadBasicSearchValues();

			// Get and validate search values for advanced search
			$this->loadSearchValues(); // Get search values

			// Process filter list
			if ($this->processFilterList())
				$this->terminate();
			if (!$this->validateSearch())
				$this->setFailureMessage($SearchError);

			// Restore search parms from Session if not searching / reset / export
			if (($this->isExport() || $this->Command != "search" && $this->Command != "reset" && $this->Command != "resetall") && $this->Command != "json" && $this->checkSearchParms())
				$this->restoreSearchParms();

			// Call Recordset SearchValidated event
			$this->Recordset_SearchValidated();

			// Set up sorting order
			$this->setupSortOrder();

			// Get basic search criteria
			if ($SearchError == "")
				$srchBasic = $this->basicSearchWhere();

			// Get search criteria for advanced search
			if ($SearchError == "")
				$srchAdvanced = $this->advancedSearchWhere();
		}

		// Restore display records
		if ($this->Command != "json" && $this->getRecordsPerPage() != "") {
			$this->DisplayRecords = $this->getRecordsPerPage(); // Restore from Session
		} else {
			$this->DisplayRecords = 10; // Load default
			$this->setRecordsPerPage($this->DisplayRecords); // Save default to Session
		}

		// Load Sorting Order
		if ($this->Command != "json")
			$this->loadSortOrder();

		// Load search default if no existing search criteria
		if (!$this->checkSearchParms()) {

			// Load basic search from default
			$this->BasicSearch->loadDefault();
			if ($this->BasicSearch->Keyword != "")
				$srchBasic = $this->basicSearchWhere();

			// Load advanced search from default
			if ($this->loadAdvancedSearchDefault()) {
				$srchAdvanced = $this->advancedSearchWhere();
			}
		}

		// Restore search settings from Session
		if ($SearchError == "")
			$this->loadAdvancedSearch();

		// Build search criteria
		AddFilter($this->SearchWhere, $srchAdvanced);
		AddFilter($this->SearchWhere, $srchBasic);

		// Call Recordset_Searching event
		$this->Recordset_Searching($this->SearchWhere);

		// Save search criteria
		if ($this->Command == "search" && !$this->RestoreSearch) {
			$this->setSearchWhere($this->SearchWhere); // Save to Session
			$this->StartRecord = 1; // Reset start record counter
			$this->setStartRecordNumber($this->StartRecord);
		} elseif ($this->Command != "json") {
			$this->SearchWhere = $this->getSearchWhere();
		}

		// Build filter
		$filter = "";
		if (!$Security->canList())
			$filter = "(0=1)"; // Filter all records
		AddFilter($filter, $this->DbDetailFilter);
		AddFilter($filter, $this->SearchWhere);

		// Set up filter
		if ($this->Command == "json") {
			$this->UseSessionForListSql = FALSE; // Do not use session for ListSQL
			$this->CurrentFilter = $filter;
		} else {
			$this->setSessionWhere($filter);
			$this->CurrentFilter = "";
		}

		// Export data only
		if (!$this->CustomExport && in_array($this->Export, array_keys(Config("EXPORT_CLASSES")))) {
			$this->exportData();
			$this->terminate();
		}
		if ($this->isGridAdd()) {
			$this->CurrentFilter = "0=1";
			$this->StartRecord = 1;
			$this->DisplayRecords = $this->GridAddRowCount;
			$this->TotalRecords = $this->DisplayRecords;
			$this->StopRecord = $this->DisplayRecords;
		} else {
			$selectLimit = $this->UseSelectLimit;
			if ($selectLimit) {
				$this->TotalRecords = $this->listRecordCount();
			} else {
				if ($this->Recordset = $this->loadRecordset())
					$this->TotalRecords = $this->Recordset->RecordCount();
			}
			$this->StartRecord = 1;
			if ($this->DisplayRecords <= 0 || ($this->isExport() && $this->ExportAll)) // Display all records
				$this->DisplayRecords = $this->TotalRecords;
			if (!($this->isExport() && $this->ExportAll)) // Set up start record position
				$this->setupStartRecord();
			if ($selectLimit)
				$this->Recordset = $this->loadRecordset($this->StartRecord - 1, $this->DisplayRecords);

			// Set no record found message
			if (!$this->CurrentAction && $this->TotalRecords == 0) {
				if (!$Security->canList())
					$this->setWarningMessage(DeniedMessage());
				if ($this->SearchWhere == "0=101")
					$this->setWarningMessage($Language->phrase("EnterSearchCriteria"));
				else
					$this->setWarningMessage($Language->phrase("NoRecord"));
			}

			// Audit trail on search
			if ($this->AuditTrailOnSearch && $this->Command == "search" && !$this->RestoreSearch) {
				$searchParm = ServerVar("QUERY_STRING");
				$searchSql = $this->getSessionWhere();
				$this->writeAuditTrailOnSearch($searchParm, $searchSql);
			}
		}

		// Search options
		$this->setupSearchOptions();

		// Set up search panel class
		if ($this->SearchWhere != "")
			AppendClass($this->SearchPanelClass, "show");

		// Normal return
		if (IsApi()) {
			$rows = $this->getRecordsFromRecordset($this->Recordset);
			$this->Recordset->close();
			WriteJson(["success" => TRUE, $this->TableVar => $rows, "totalRecordCount" => $this->TotalRecords]);
			$this->terminate(TRUE);
		}

		// Set up pager
		$this->Pager = new PrevNextPager($this->StartRecord, $this->getRecordsPerPage(), $this->TotalRecords, $this->PageSizes, $this->RecordRange, $this->AutoHidePager, $this->AutoHidePageSizeSelector);
	}

	// Set up number of records displayed per page
	protected function setupDisplayRecords()
	{
		$wrk = Get(Config("TABLE_REC_PER_PAGE"), "");
		if ($wrk != "") {
			if (is_numeric($wrk)) {
				$this->DisplayRecords = (int)$wrk;
			} else {
				if (SameText($wrk, "all")) { // Display all records
					$this->DisplayRecords = -1;
				} else {
					$this->DisplayRecords = 10; // Non-numeric, load default
				}
			}
			$this->setRecordsPerPage($this->DisplayRecords); // Save to Session

			// Reset start position
			$this->StartRecord = 1;
			$this->setStartRecordNumber($this->StartRecord);
		}
	}

	// Build filter for all keys
	protected function buildKeyFilter()
	{
		global $CurrentForm;
		$wrkFilter = "";

		// Update row index and get row key
		$rowindex = 1;
		$CurrentForm->Index = $rowindex;
		$thisKey = strval($CurrentForm->getValue($this->FormKeyName));
		while ($thisKey != "") {
			if ($this->setupKeyValues($thisKey)) {
				$filter = $this->getRecordFilter();
				if ($wrkFilter != "")
					$wrkFilter .= " OR ";
				$wrkFilter .= $filter;
			} else {
				$wrkFilter = "0=1";
				break;
			}

			// Update row index and get row key
			$rowindex++; // Next row
			$CurrentForm->Index = $rowindex;
			$thisKey = strval($CurrentForm->getValue($this->FormKeyName));
		}
		return $wrkFilter;
	}

	// Set up key values
	protected function setupKeyValues($key)
	{
		$arKeyFlds = explode(Config("COMPOSITE_KEY_SEPARATOR"), $key);
		if (count($arKeyFlds) >= 1) {
			$this->extrafieldsid->setOldValue($arKeyFlds[0]);
			if (!is_numeric($this->extrafieldsid->OldValue))
				return FALSE;
		}
		return TRUE;
	}

	// Get list of filters
	public function getFilterList()
	{
		global $UserProfile;

		// Initialize
		$filterList = "";
		$savedFilterList = "";

		// Load server side filters
		if (Config("SEARCH_FILTER_OPTION") == "Server" && isset($UserProfile))
			$savedFilterList = $UserProfile->getSearchFilters(CurrentUserName(), "fextrafieldstemplatelistsrch");
		$filterList = Concat($filterList, $this->extrafieldsid->AdvancedSearch->toJson(), ","); // Field extrafieldsid
		$filterList = Concat($filterList, $this->merchantid->AdvancedSearch->toJson(), ","); // Field merchantid
		$filterList = Concat($filterList, $this->name->AdvancedSearch->toJson(), ","); // Field name
		$filterList = Concat($filterList, $this->field1label->AdvancedSearch->toJson(), ","); // Field field1label
		$filterList = Concat($filterList, $this->field1type->AdvancedSearch->toJson(), ","); // Field field1type
		$filterList = Concat($filterList, $this->field1mandatory->AdvancedSearch->toJson(), ","); // Field field1mandatory
		$filterList = Concat($filterList, $this->field1display->AdvancedSearch->toJson(), ","); // Field field1display
		$filterList = Concat($filterList, $this->field1displaysequence->AdvancedSearch->toJson(), ","); // Field field1displaysequence
		$filterList = Concat($filterList, $this->field1domain->AdvancedSearch->toJson(), ","); // Field field1domain
		$filterList = Concat($filterList, $this->field2label->AdvancedSearch->toJson(), ","); // Field field2label
		$filterList = Concat($filterList, $this->field2type->AdvancedSearch->toJson(), ","); // Field field2type
		$filterList = Concat($filterList, $this->field2mandatory->AdvancedSearch->toJson(), ","); // Field field2mandatory
		$filterList = Concat($filterList, $this->field2display->AdvancedSearch->toJson(), ","); // Field field2display
		$filterList = Concat($filterList, $this->field2displaysequence->AdvancedSearch->toJson(), ","); // Field field2displaysequence
		$filterList = Concat($filterList, $this->field2domain->AdvancedSearch->toJson(), ","); // Field field2domain
		$filterList = Concat($filterList, $this->field3label->AdvancedSearch->toJson(), ","); // Field field3label
		$filterList = Concat($filterList, $this->field3type->AdvancedSearch->toJson(), ","); // Field field3type
		$filterList = Concat($filterList, $this->field3mandatory->AdvancedSearch->toJson(), ","); // Field field3mandatory
		$filterList = Concat($filterList, $this->field3display->AdvancedSearch->toJson(), ","); // Field field3display
		$filterList = Concat($filterList, $this->field3displaysequence->AdvancedSearch->toJson(), ","); // Field field3displaysequence
		$filterList = Concat($filterList, $this->field3domain->AdvancedSearch->toJson(), ","); // Field field3domain
		$filterList = Concat($filterList, $this->field4label->AdvancedSearch->toJson(), ","); // Field field4label
		$filterList = Concat($filterList, $this->field4type->AdvancedSearch->toJson(), ","); // Field field4type
		$filterList = Concat($filterList, $this->field4mandatory->AdvancedSearch->toJson(), ","); // Field field4mandatory
		$filterList = Concat($filterList, $this->field4display->AdvancedSearch->toJson(), ","); // Field field4display
		$filterList = Concat($filterList, $this->field4displaysequence->AdvancedSearch->toJson(), ","); // Field field4displaysequence
		$filterList = Concat($filterList, $this->field4domain->AdvancedSearch->toJson(), ","); // Field field4domain
		$filterList = Concat($filterList, $this->field5label->AdvancedSearch->toJson(), ","); // Field field5label
		$filterList = Concat($filterList, $this->field5type->AdvancedSearch->toJson(), ","); // Field field5type
		$filterList = Concat($filterList, $this->field5mandatory->AdvancedSearch->toJson(), ","); // Field field5mandatory
		$filterList = Concat($filterList, $this->field5display->AdvancedSearch->toJson(), ","); // Field field5display
		$filterList = Concat($filterList, $this->field5displaysequence->AdvancedSearch->toJson(), ","); // Field field5displaysequence
		$filterList = Concat($filterList, $this->field5domain->AdvancedSearch->toJson(), ","); // Field field5domain
		$filterList = Concat($filterList, $this->field6label->AdvancedSearch->toJson(), ","); // Field field6label
		$filterList = Concat($filterList, $this->field6type->AdvancedSearch->toJson(), ","); // Field field6type
		$filterList = Concat($filterList, $this->field6mandatory->AdvancedSearch->toJson(), ","); // Field field6mandatory
		$filterList = Concat($filterList, $this->field6display->AdvancedSearch->toJson(), ","); // Field field6display
		$filterList = Concat($filterList, $this->field6displaysequence->AdvancedSearch->toJson(), ","); // Field field6displaysequence
		$filterList = Concat($filterList, $this->field6domain->AdvancedSearch->toJson(), ","); // Field field6domain
		$filterList = Concat($filterList, $this->field7label->AdvancedSearch->toJson(), ","); // Field field7label
		$filterList = Concat($filterList, $this->field7type->AdvancedSearch->toJson(), ","); // Field field7type
		$filterList = Concat($filterList, $this->field7mandatory->AdvancedSearch->toJson(), ","); // Field field7mandatory
		$filterList = Concat($filterList, $this->field7display->AdvancedSearch->toJson(), ","); // Field field7display
		$filterList = Concat($filterList, $this->field7displaysequence->AdvancedSearch->toJson(), ","); // Field field7displaysequence
		$filterList = Concat($filterList, $this->field7domain->AdvancedSearch->toJson(), ","); // Field field7domain
		$filterList = Concat($filterList, $this->field8label->AdvancedSearch->toJson(), ","); // Field field8label
		$filterList = Concat($filterList, $this->field8type->AdvancedSearch->toJson(), ","); // Field field8type
		$filterList = Concat($filterList, $this->field8mandatory->AdvancedSearch->toJson(), ","); // Field field8mandatory
		$filterList = Concat($filterList, $this->field8display->AdvancedSearch->toJson(), ","); // Field field8display
		$filterList = Concat($filterList, $this->field8displaysequence->AdvancedSearch->toJson(), ","); // Field field8displaysequence
		$filterList = Concat($filterList, $this->field8domain->AdvancedSearch->toJson(), ","); // Field field8domain
		$filterList = Concat($filterList, $this->field9label->AdvancedSearch->toJson(), ","); // Field field9label
		$filterList = Concat($filterList, $this->field9type->AdvancedSearch->toJson(), ","); // Field field9type
		$filterList = Concat($filterList, $this->field9mandatory->AdvancedSearch->toJson(), ","); // Field field9mandatory
		$filterList = Concat($filterList, $this->field9display->AdvancedSearch->toJson(), ","); // Field field9display
		$filterList = Concat($filterList, $this->field9displaysequence->AdvancedSearch->toJson(), ","); // Field field9displaysequence
		$filterList = Concat($filterList, $this->field9domain->AdvancedSearch->toJson(), ","); // Field field9domain
		$filterList = Concat($filterList, $this->field10label->AdvancedSearch->toJson(), ","); // Field field10label
		$filterList = Concat($filterList, $this->field10type->AdvancedSearch->toJson(), ","); // Field field10type
		$filterList = Concat($filterList, $this->field10mandatory->AdvancedSearch->toJson(), ","); // Field field10mandatory
		$filterList = Concat($filterList, $this->field10display->AdvancedSearch->toJson(), ","); // Field field10display
		$filterList = Concat($filterList, $this->field10displaysequence->AdvancedSearch->toJson(), ","); // Field field10displaysequence
		$filterList = Concat($filterList, $this->field10domain->AdvancedSearch->toJson(), ","); // Field field10domain
		$filterList = Concat($filterList, $this->lastupdatedate->AdvancedSearch->toJson(), ","); // Field lastupdatedate
		if ($this->BasicSearch->Keyword != "") {
			$wrk = "\"" . Config("TABLE_BASIC_SEARCH") . "\":\"" . JsEncode($this->BasicSearch->Keyword) . "\",\"" . Config("TABLE_BASIC_SEARCH_TYPE") . "\":\"" . JsEncode($this->BasicSearch->Type) . "\"";
			$filterList = Concat($filterList, $wrk, ",");
		}

		// Return filter list in JSON
		if ($filterList != "")
			$filterList = "\"data\":{" . $filterList . "}";
		if ($savedFilterList != "")
			$filterList = Concat($filterList, "\"filters\":" . $savedFilterList, ",");
		return ($filterList != "") ? "{" . $filterList . "}" : "null";
	}

	// Process filter list
	protected function processFilterList()
	{
		global $UserProfile;
		if (Post("ajax") == "savefilters") { // Save filter request (Ajax)
			$filters = Post("filters");
			$UserProfile->setSearchFilters(CurrentUserName(), "fextrafieldstemplatelistsrch", $filters);
			WriteJson([["success" => TRUE]]); // Success
			return TRUE;
		} elseif (Post("cmd") == "resetfilter") {
			$this->restoreFilterList();
		}
		return FALSE;
	}

	// Restore list of filters
	protected function restoreFilterList()
	{

		// Return if not reset filter
		if (Post("cmd") !== "resetfilter")
			return FALSE;
		$filter = json_decode(Post("filter"), TRUE);
		$this->Command = "search";

		// Field extrafieldsid
		$this->extrafieldsid->AdvancedSearch->SearchValue = @$filter["x_extrafieldsid"];
		$this->extrafieldsid->AdvancedSearch->SearchOperator = @$filter["z_extrafieldsid"];
		$this->extrafieldsid->AdvancedSearch->SearchCondition = @$filter["v_extrafieldsid"];
		$this->extrafieldsid->AdvancedSearch->SearchValue2 = @$filter["y_extrafieldsid"];
		$this->extrafieldsid->AdvancedSearch->SearchOperator2 = @$filter["w_extrafieldsid"];
		$this->extrafieldsid->AdvancedSearch->save();

		// Field merchantid
		$this->merchantid->AdvancedSearch->SearchValue = @$filter["x_merchantid"];
		$this->merchantid->AdvancedSearch->SearchOperator = @$filter["z_merchantid"];
		$this->merchantid->AdvancedSearch->SearchCondition = @$filter["v_merchantid"];
		$this->merchantid->AdvancedSearch->SearchValue2 = @$filter["y_merchantid"];
		$this->merchantid->AdvancedSearch->SearchOperator2 = @$filter["w_merchantid"];
		$this->merchantid->AdvancedSearch->save();

		// Field name
		$this->name->AdvancedSearch->SearchValue = @$filter["x_name"];
		$this->name->AdvancedSearch->SearchOperator = @$filter["z_name"];
		$this->name->AdvancedSearch->SearchCondition = @$filter["v_name"];
		$this->name->AdvancedSearch->SearchValue2 = @$filter["y_name"];
		$this->name->AdvancedSearch->SearchOperator2 = @$filter["w_name"];
		$this->name->AdvancedSearch->save();

		// Field field1label
		$this->field1label->AdvancedSearch->SearchValue = @$filter["x_field1label"];
		$this->field1label->AdvancedSearch->SearchOperator = @$filter["z_field1label"];
		$this->field1label->AdvancedSearch->SearchCondition = @$filter["v_field1label"];
		$this->field1label->AdvancedSearch->SearchValue2 = @$filter["y_field1label"];
		$this->field1label->AdvancedSearch->SearchOperator2 = @$filter["w_field1label"];
		$this->field1label->AdvancedSearch->save();

		// Field field1type
		$this->field1type->AdvancedSearch->SearchValue = @$filter["x_field1type"];
		$this->field1type->AdvancedSearch->SearchOperator = @$filter["z_field1type"];
		$this->field1type->AdvancedSearch->SearchCondition = @$filter["v_field1type"];
		$this->field1type->AdvancedSearch->SearchValue2 = @$filter["y_field1type"];
		$this->field1type->AdvancedSearch->SearchOperator2 = @$filter["w_field1type"];
		$this->field1type->AdvancedSearch->save();

		// Field field1mandatory
		$this->field1mandatory->AdvancedSearch->SearchValue = @$filter["x_field1mandatory"];
		$this->field1mandatory->AdvancedSearch->SearchOperator = @$filter["z_field1mandatory"];
		$this->field1mandatory->AdvancedSearch->SearchCondition = @$filter["v_field1mandatory"];
		$this->field1mandatory->AdvancedSearch->SearchValue2 = @$filter["y_field1mandatory"];
		$this->field1mandatory->AdvancedSearch->SearchOperator2 = @$filter["w_field1mandatory"];
		$this->field1mandatory->AdvancedSearch->save();

		// Field field1display
		$this->field1display->AdvancedSearch->SearchValue = @$filter["x_field1display"];
		$this->field1display->AdvancedSearch->SearchOperator = @$filter["z_field1display"];
		$this->field1display->AdvancedSearch->SearchCondition = @$filter["v_field1display"];
		$this->field1display->AdvancedSearch->SearchValue2 = @$filter["y_field1display"];
		$this->field1display->AdvancedSearch->SearchOperator2 = @$filter["w_field1display"];
		$this->field1display->AdvancedSearch->save();

		// Field field1displaysequence
		$this->field1displaysequence->AdvancedSearch->SearchValue = @$filter["x_field1displaysequence"];
		$this->field1displaysequence->AdvancedSearch->SearchOperator = @$filter["z_field1displaysequence"];
		$this->field1displaysequence->AdvancedSearch->SearchCondition = @$filter["v_field1displaysequence"];
		$this->field1displaysequence->AdvancedSearch->SearchValue2 = @$filter["y_field1displaysequence"];
		$this->field1displaysequence->AdvancedSearch->SearchOperator2 = @$filter["w_field1displaysequence"];
		$this->field1displaysequence->AdvancedSearch->save();

		// Field field1domain
		$this->field1domain->AdvancedSearch->SearchValue = @$filter["x_field1domain"];
		$this->field1domain->AdvancedSearch->SearchOperator = @$filter["z_field1domain"];
		$this->field1domain->AdvancedSearch->SearchCondition = @$filter["v_field1domain"];
		$this->field1domain->AdvancedSearch->SearchValue2 = @$filter["y_field1domain"];
		$this->field1domain->AdvancedSearch->SearchOperator2 = @$filter["w_field1domain"];
		$this->field1domain->AdvancedSearch->save();

		// Field field2label
		$this->field2label->AdvancedSearch->SearchValue = @$filter["x_field2label"];
		$this->field2label->AdvancedSearch->SearchOperator = @$filter["z_field2label"];
		$this->field2label->AdvancedSearch->SearchCondition = @$filter["v_field2label"];
		$this->field2label->AdvancedSearch->SearchValue2 = @$filter["y_field2label"];
		$this->field2label->AdvancedSearch->SearchOperator2 = @$filter["w_field2label"];
		$this->field2label->AdvancedSearch->save();

		// Field field2type
		$this->field2type->AdvancedSearch->SearchValue = @$filter["x_field2type"];
		$this->field2type->AdvancedSearch->SearchOperator = @$filter["z_field2type"];
		$this->field2type->AdvancedSearch->SearchCondition = @$filter["v_field2type"];
		$this->field2type->AdvancedSearch->SearchValue2 = @$filter["y_field2type"];
		$this->field2type->AdvancedSearch->SearchOperator2 = @$filter["w_field2type"];
		$this->field2type->AdvancedSearch->save();

		// Field field2mandatory
		$this->field2mandatory->AdvancedSearch->SearchValue = @$filter["x_field2mandatory"];
		$this->field2mandatory->AdvancedSearch->SearchOperator = @$filter["z_field2mandatory"];
		$this->field2mandatory->AdvancedSearch->SearchCondition = @$filter["v_field2mandatory"];
		$this->field2mandatory->AdvancedSearch->SearchValue2 = @$filter["y_field2mandatory"];
		$this->field2mandatory->AdvancedSearch->SearchOperator2 = @$filter["w_field2mandatory"];
		$this->field2mandatory->AdvancedSearch->save();

		// Field field2display
		$this->field2display->AdvancedSearch->SearchValue = @$filter["x_field2display"];
		$this->field2display->AdvancedSearch->SearchOperator = @$filter["z_field2display"];
		$this->field2display->AdvancedSearch->SearchCondition = @$filter["v_field2display"];
		$this->field2display->AdvancedSearch->SearchValue2 = @$filter["y_field2display"];
		$this->field2display->AdvancedSearch->SearchOperator2 = @$filter["w_field2display"];
		$this->field2display->AdvancedSearch->save();

		// Field field2displaysequence
		$this->field2displaysequence->AdvancedSearch->SearchValue = @$filter["x_field2displaysequence"];
		$this->field2displaysequence->AdvancedSearch->SearchOperator = @$filter["z_field2displaysequence"];
		$this->field2displaysequence->AdvancedSearch->SearchCondition = @$filter["v_field2displaysequence"];
		$this->field2displaysequence->AdvancedSearch->SearchValue2 = @$filter["y_field2displaysequence"];
		$this->field2displaysequence->AdvancedSearch->SearchOperator2 = @$filter["w_field2displaysequence"];
		$this->field2displaysequence->AdvancedSearch->save();

		// Field field2domain
		$this->field2domain->AdvancedSearch->SearchValue = @$filter["x_field2domain"];
		$this->field2domain->AdvancedSearch->SearchOperator = @$filter["z_field2domain"];
		$this->field2domain->AdvancedSearch->SearchCondition = @$filter["v_field2domain"];
		$this->field2domain->AdvancedSearch->SearchValue2 = @$filter["y_field2domain"];
		$this->field2domain->AdvancedSearch->SearchOperator2 = @$filter["w_field2domain"];
		$this->field2domain->AdvancedSearch->save();

		// Field field3label
		$this->field3label->AdvancedSearch->SearchValue = @$filter["x_field3label"];
		$this->field3label->AdvancedSearch->SearchOperator = @$filter["z_field3label"];
		$this->field3label->AdvancedSearch->SearchCondition = @$filter["v_field3label"];
		$this->field3label->AdvancedSearch->SearchValue2 = @$filter["y_field3label"];
		$this->field3label->AdvancedSearch->SearchOperator2 = @$filter["w_field3label"];
		$this->field3label->AdvancedSearch->save();

		// Field field3type
		$this->field3type->AdvancedSearch->SearchValue = @$filter["x_field3type"];
		$this->field3type->AdvancedSearch->SearchOperator = @$filter["z_field3type"];
		$this->field3type->AdvancedSearch->SearchCondition = @$filter["v_field3type"];
		$this->field3type->AdvancedSearch->SearchValue2 = @$filter["y_field3type"];
		$this->field3type->AdvancedSearch->SearchOperator2 = @$filter["w_field3type"];
		$this->field3type->AdvancedSearch->save();

		// Field field3mandatory
		$this->field3mandatory->AdvancedSearch->SearchValue = @$filter["x_field3mandatory"];
		$this->field3mandatory->AdvancedSearch->SearchOperator = @$filter["z_field3mandatory"];
		$this->field3mandatory->AdvancedSearch->SearchCondition = @$filter["v_field3mandatory"];
		$this->field3mandatory->AdvancedSearch->SearchValue2 = @$filter["y_field3mandatory"];
		$this->field3mandatory->AdvancedSearch->SearchOperator2 = @$filter["w_field3mandatory"];
		$this->field3mandatory->AdvancedSearch->save();

		// Field field3display
		$this->field3display->AdvancedSearch->SearchValue = @$filter["x_field3display"];
		$this->field3display->AdvancedSearch->SearchOperator = @$filter["z_field3display"];
		$this->field3display->AdvancedSearch->SearchCondition = @$filter["v_field3display"];
		$this->field3display->AdvancedSearch->SearchValue2 = @$filter["y_field3display"];
		$this->field3display->AdvancedSearch->SearchOperator2 = @$filter["w_field3display"];
		$this->field3display->AdvancedSearch->save();

		// Field field3displaysequence
		$this->field3displaysequence->AdvancedSearch->SearchValue = @$filter["x_field3displaysequence"];
		$this->field3displaysequence->AdvancedSearch->SearchOperator = @$filter["z_field3displaysequence"];
		$this->field3displaysequence->AdvancedSearch->SearchCondition = @$filter["v_field3displaysequence"];
		$this->field3displaysequence->AdvancedSearch->SearchValue2 = @$filter["y_field3displaysequence"];
		$this->field3displaysequence->AdvancedSearch->SearchOperator2 = @$filter["w_field3displaysequence"];
		$this->field3displaysequence->AdvancedSearch->save();

		// Field field3domain
		$this->field3domain->AdvancedSearch->SearchValue = @$filter["x_field3domain"];
		$this->field3domain->AdvancedSearch->SearchOperator = @$filter["z_field3domain"];
		$this->field3domain->AdvancedSearch->SearchCondition = @$filter["v_field3domain"];
		$this->field3domain->AdvancedSearch->SearchValue2 = @$filter["y_field3domain"];
		$this->field3domain->AdvancedSearch->SearchOperator2 = @$filter["w_field3domain"];
		$this->field3domain->AdvancedSearch->save();

		// Field field4label
		$this->field4label->AdvancedSearch->SearchValue = @$filter["x_field4label"];
		$this->field4label->AdvancedSearch->SearchOperator = @$filter["z_field4label"];
		$this->field4label->AdvancedSearch->SearchCondition = @$filter["v_field4label"];
		$this->field4label->AdvancedSearch->SearchValue2 = @$filter["y_field4label"];
		$this->field4label->AdvancedSearch->SearchOperator2 = @$filter["w_field4label"];
		$this->field4label->AdvancedSearch->save();

		// Field field4type
		$this->field4type->AdvancedSearch->SearchValue = @$filter["x_field4type"];
		$this->field4type->AdvancedSearch->SearchOperator = @$filter["z_field4type"];
		$this->field4type->AdvancedSearch->SearchCondition = @$filter["v_field4type"];
		$this->field4type->AdvancedSearch->SearchValue2 = @$filter["y_field4type"];
		$this->field4type->AdvancedSearch->SearchOperator2 = @$filter["w_field4type"];
		$this->field4type->AdvancedSearch->save();

		// Field field4mandatory
		$this->field4mandatory->AdvancedSearch->SearchValue = @$filter["x_field4mandatory"];
		$this->field4mandatory->AdvancedSearch->SearchOperator = @$filter["z_field4mandatory"];
		$this->field4mandatory->AdvancedSearch->SearchCondition = @$filter["v_field4mandatory"];
		$this->field4mandatory->AdvancedSearch->SearchValue2 = @$filter["y_field4mandatory"];
		$this->field4mandatory->AdvancedSearch->SearchOperator2 = @$filter["w_field4mandatory"];
		$this->field4mandatory->AdvancedSearch->save();

		// Field field4display
		$this->field4display->AdvancedSearch->SearchValue = @$filter["x_field4display"];
		$this->field4display->AdvancedSearch->SearchOperator = @$filter["z_field4display"];
		$this->field4display->AdvancedSearch->SearchCondition = @$filter["v_field4display"];
		$this->field4display->AdvancedSearch->SearchValue2 = @$filter["y_field4display"];
		$this->field4display->AdvancedSearch->SearchOperator2 = @$filter["w_field4display"];
		$this->field4display->AdvancedSearch->save();

		// Field field4displaysequence
		$this->field4displaysequence->AdvancedSearch->SearchValue = @$filter["x_field4displaysequence"];
		$this->field4displaysequence->AdvancedSearch->SearchOperator = @$filter["z_field4displaysequence"];
		$this->field4displaysequence->AdvancedSearch->SearchCondition = @$filter["v_field4displaysequence"];
		$this->field4displaysequence->AdvancedSearch->SearchValue2 = @$filter["y_field4displaysequence"];
		$this->field4displaysequence->AdvancedSearch->SearchOperator2 = @$filter["w_field4displaysequence"];
		$this->field4displaysequence->AdvancedSearch->save();

		// Field field4domain
		$this->field4domain->AdvancedSearch->SearchValue = @$filter["x_field4domain"];
		$this->field4domain->AdvancedSearch->SearchOperator = @$filter["z_field4domain"];
		$this->field4domain->AdvancedSearch->SearchCondition = @$filter["v_field4domain"];
		$this->field4domain->AdvancedSearch->SearchValue2 = @$filter["y_field4domain"];
		$this->field4domain->AdvancedSearch->SearchOperator2 = @$filter["w_field4domain"];
		$this->field4domain->AdvancedSearch->save();

		// Field field5label
		$this->field5label->AdvancedSearch->SearchValue = @$filter["x_field5label"];
		$this->field5label->AdvancedSearch->SearchOperator = @$filter["z_field5label"];
		$this->field5label->AdvancedSearch->SearchCondition = @$filter["v_field5label"];
		$this->field5label->AdvancedSearch->SearchValue2 = @$filter["y_field5label"];
		$this->field5label->AdvancedSearch->SearchOperator2 = @$filter["w_field5label"];
		$this->field5label->AdvancedSearch->save();

		// Field field5type
		$this->field5type->AdvancedSearch->SearchValue = @$filter["x_field5type"];
		$this->field5type->AdvancedSearch->SearchOperator = @$filter["z_field5type"];
		$this->field5type->AdvancedSearch->SearchCondition = @$filter["v_field5type"];
		$this->field5type->AdvancedSearch->SearchValue2 = @$filter["y_field5type"];
		$this->field5type->AdvancedSearch->SearchOperator2 = @$filter["w_field5type"];
		$this->field5type->AdvancedSearch->save();

		// Field field5mandatory
		$this->field5mandatory->AdvancedSearch->SearchValue = @$filter["x_field5mandatory"];
		$this->field5mandatory->AdvancedSearch->SearchOperator = @$filter["z_field5mandatory"];
		$this->field5mandatory->AdvancedSearch->SearchCondition = @$filter["v_field5mandatory"];
		$this->field5mandatory->AdvancedSearch->SearchValue2 = @$filter["y_field5mandatory"];
		$this->field5mandatory->AdvancedSearch->SearchOperator2 = @$filter["w_field5mandatory"];
		$this->field5mandatory->AdvancedSearch->save();

		// Field field5display
		$this->field5display->AdvancedSearch->SearchValue = @$filter["x_field5display"];
		$this->field5display->AdvancedSearch->SearchOperator = @$filter["z_field5display"];
		$this->field5display->AdvancedSearch->SearchCondition = @$filter["v_field5display"];
		$this->field5display->AdvancedSearch->SearchValue2 = @$filter["y_field5display"];
		$this->field5display->AdvancedSearch->SearchOperator2 = @$filter["w_field5display"];
		$this->field5display->AdvancedSearch->save();

		// Field field5displaysequence
		$this->field5displaysequence->AdvancedSearch->SearchValue = @$filter["x_field5displaysequence"];
		$this->field5displaysequence->AdvancedSearch->SearchOperator = @$filter["z_field5displaysequence"];
		$this->field5displaysequence->AdvancedSearch->SearchCondition = @$filter["v_field5displaysequence"];
		$this->field5displaysequence->AdvancedSearch->SearchValue2 = @$filter["y_field5displaysequence"];
		$this->field5displaysequence->AdvancedSearch->SearchOperator2 = @$filter["w_field5displaysequence"];
		$this->field5displaysequence->AdvancedSearch->save();

		// Field field5domain
		$this->field5domain->AdvancedSearch->SearchValue = @$filter["x_field5domain"];
		$this->field5domain->AdvancedSearch->SearchOperator = @$filter["z_field5domain"];
		$this->field5domain->AdvancedSearch->SearchCondition = @$filter["v_field5domain"];
		$this->field5domain->AdvancedSearch->SearchValue2 = @$filter["y_field5domain"];
		$this->field5domain->AdvancedSearch->SearchOperator2 = @$filter["w_field5domain"];
		$this->field5domain->AdvancedSearch->save();

		// Field field6label
		$this->field6label->AdvancedSearch->SearchValue = @$filter["x_field6label"];
		$this->field6label->AdvancedSearch->SearchOperator = @$filter["z_field6label"];
		$this->field6label->AdvancedSearch->SearchCondition = @$filter["v_field6label"];
		$this->field6label->AdvancedSearch->SearchValue2 = @$filter["y_field6label"];
		$this->field6label->AdvancedSearch->SearchOperator2 = @$filter["w_field6label"];
		$this->field6label->AdvancedSearch->save();

		// Field field6type
		$this->field6type->AdvancedSearch->SearchValue = @$filter["x_field6type"];
		$this->field6type->AdvancedSearch->SearchOperator = @$filter["z_field6type"];
		$this->field6type->AdvancedSearch->SearchCondition = @$filter["v_field6type"];
		$this->field6type->AdvancedSearch->SearchValue2 = @$filter["y_field6type"];
		$this->field6type->AdvancedSearch->SearchOperator2 = @$filter["w_field6type"];
		$this->field6type->AdvancedSearch->save();

		// Field field6mandatory
		$this->field6mandatory->AdvancedSearch->SearchValue = @$filter["x_field6mandatory"];
		$this->field6mandatory->AdvancedSearch->SearchOperator = @$filter["z_field6mandatory"];
		$this->field6mandatory->AdvancedSearch->SearchCondition = @$filter["v_field6mandatory"];
		$this->field6mandatory->AdvancedSearch->SearchValue2 = @$filter["y_field6mandatory"];
		$this->field6mandatory->AdvancedSearch->SearchOperator2 = @$filter["w_field6mandatory"];
		$this->field6mandatory->AdvancedSearch->save();

		// Field field6display
		$this->field6display->AdvancedSearch->SearchValue = @$filter["x_field6display"];
		$this->field6display->AdvancedSearch->SearchOperator = @$filter["z_field6display"];
		$this->field6display->AdvancedSearch->SearchCondition = @$filter["v_field6display"];
		$this->field6display->AdvancedSearch->SearchValue2 = @$filter["y_field6display"];
		$this->field6display->AdvancedSearch->SearchOperator2 = @$filter["w_field6display"];
		$this->field6display->AdvancedSearch->save();

		// Field field6displaysequence
		$this->field6displaysequence->AdvancedSearch->SearchValue = @$filter["x_field6displaysequence"];
		$this->field6displaysequence->AdvancedSearch->SearchOperator = @$filter["z_field6displaysequence"];
		$this->field6displaysequence->AdvancedSearch->SearchCondition = @$filter["v_field6displaysequence"];
		$this->field6displaysequence->AdvancedSearch->SearchValue2 = @$filter["y_field6displaysequence"];
		$this->field6displaysequence->AdvancedSearch->SearchOperator2 = @$filter["w_field6displaysequence"];
		$this->field6displaysequence->AdvancedSearch->save();

		// Field field6domain
		$this->field6domain->AdvancedSearch->SearchValue = @$filter["x_field6domain"];
		$this->field6domain->AdvancedSearch->SearchOperator = @$filter["z_field6domain"];
		$this->field6domain->AdvancedSearch->SearchCondition = @$filter["v_field6domain"];
		$this->field6domain->AdvancedSearch->SearchValue2 = @$filter["y_field6domain"];
		$this->field6domain->AdvancedSearch->SearchOperator2 = @$filter["w_field6domain"];
		$this->field6domain->AdvancedSearch->save();

		// Field field7label
		$this->field7label->AdvancedSearch->SearchValue = @$filter["x_field7label"];
		$this->field7label->AdvancedSearch->SearchOperator = @$filter["z_field7label"];
		$this->field7label->AdvancedSearch->SearchCondition = @$filter["v_field7label"];
		$this->field7label->AdvancedSearch->SearchValue2 = @$filter["y_field7label"];
		$this->field7label->AdvancedSearch->SearchOperator2 = @$filter["w_field7label"];
		$this->field7label->AdvancedSearch->save();

		// Field field7type
		$this->field7type->AdvancedSearch->SearchValue = @$filter["x_field7type"];
		$this->field7type->AdvancedSearch->SearchOperator = @$filter["z_field7type"];
		$this->field7type->AdvancedSearch->SearchCondition = @$filter["v_field7type"];
		$this->field7type->AdvancedSearch->SearchValue2 = @$filter["y_field7type"];
		$this->field7type->AdvancedSearch->SearchOperator2 = @$filter["w_field7type"];
		$this->field7type->AdvancedSearch->save();

		// Field field7mandatory
		$this->field7mandatory->AdvancedSearch->SearchValue = @$filter["x_field7mandatory"];
		$this->field7mandatory->AdvancedSearch->SearchOperator = @$filter["z_field7mandatory"];
		$this->field7mandatory->AdvancedSearch->SearchCondition = @$filter["v_field7mandatory"];
		$this->field7mandatory->AdvancedSearch->SearchValue2 = @$filter["y_field7mandatory"];
		$this->field7mandatory->AdvancedSearch->SearchOperator2 = @$filter["w_field7mandatory"];
		$this->field7mandatory->AdvancedSearch->save();

		// Field field7display
		$this->field7display->AdvancedSearch->SearchValue = @$filter["x_field7display"];
		$this->field7display->AdvancedSearch->SearchOperator = @$filter["z_field7display"];
		$this->field7display->AdvancedSearch->SearchCondition = @$filter["v_field7display"];
		$this->field7display->AdvancedSearch->SearchValue2 = @$filter["y_field7display"];
		$this->field7display->AdvancedSearch->SearchOperator2 = @$filter["w_field7display"];
		$this->field7display->AdvancedSearch->save();

		// Field field7displaysequence
		$this->field7displaysequence->AdvancedSearch->SearchValue = @$filter["x_field7displaysequence"];
		$this->field7displaysequence->AdvancedSearch->SearchOperator = @$filter["z_field7displaysequence"];
		$this->field7displaysequence->AdvancedSearch->SearchCondition = @$filter["v_field7displaysequence"];
		$this->field7displaysequence->AdvancedSearch->SearchValue2 = @$filter["y_field7displaysequence"];
		$this->field7displaysequence->AdvancedSearch->SearchOperator2 = @$filter["w_field7displaysequence"];
		$this->field7displaysequence->AdvancedSearch->save();

		// Field field7domain
		$this->field7domain->AdvancedSearch->SearchValue = @$filter["x_field7domain"];
		$this->field7domain->AdvancedSearch->SearchOperator = @$filter["z_field7domain"];
		$this->field7domain->AdvancedSearch->SearchCondition = @$filter["v_field7domain"];
		$this->field7domain->AdvancedSearch->SearchValue2 = @$filter["y_field7domain"];
		$this->field7domain->AdvancedSearch->SearchOperator2 = @$filter["w_field7domain"];
		$this->field7domain->AdvancedSearch->save();

		// Field field8label
		$this->field8label->AdvancedSearch->SearchValue = @$filter["x_field8label"];
		$this->field8label->AdvancedSearch->SearchOperator = @$filter["z_field8label"];
		$this->field8label->AdvancedSearch->SearchCondition = @$filter["v_field8label"];
		$this->field8label->AdvancedSearch->SearchValue2 = @$filter["y_field8label"];
		$this->field8label->AdvancedSearch->SearchOperator2 = @$filter["w_field8label"];
		$this->field8label->AdvancedSearch->save();

		// Field field8type
		$this->field8type->AdvancedSearch->SearchValue = @$filter["x_field8type"];
		$this->field8type->AdvancedSearch->SearchOperator = @$filter["z_field8type"];
		$this->field8type->AdvancedSearch->SearchCondition = @$filter["v_field8type"];
		$this->field8type->AdvancedSearch->SearchValue2 = @$filter["y_field8type"];
		$this->field8type->AdvancedSearch->SearchOperator2 = @$filter["w_field8type"];
		$this->field8type->AdvancedSearch->save();

		// Field field8mandatory
		$this->field8mandatory->AdvancedSearch->SearchValue = @$filter["x_field8mandatory"];
		$this->field8mandatory->AdvancedSearch->SearchOperator = @$filter["z_field8mandatory"];
		$this->field8mandatory->AdvancedSearch->SearchCondition = @$filter["v_field8mandatory"];
		$this->field8mandatory->AdvancedSearch->SearchValue2 = @$filter["y_field8mandatory"];
		$this->field8mandatory->AdvancedSearch->SearchOperator2 = @$filter["w_field8mandatory"];
		$this->field8mandatory->AdvancedSearch->save();

		// Field field8display
		$this->field8display->AdvancedSearch->SearchValue = @$filter["x_field8display"];
		$this->field8display->AdvancedSearch->SearchOperator = @$filter["z_field8display"];
		$this->field8display->AdvancedSearch->SearchCondition = @$filter["v_field8display"];
		$this->field8display->AdvancedSearch->SearchValue2 = @$filter["y_field8display"];
		$this->field8display->AdvancedSearch->SearchOperator2 = @$filter["w_field8display"];
		$this->field8display->AdvancedSearch->save();

		// Field field8displaysequence
		$this->field8displaysequence->AdvancedSearch->SearchValue = @$filter["x_field8displaysequence"];
		$this->field8displaysequence->AdvancedSearch->SearchOperator = @$filter["z_field8displaysequence"];
		$this->field8displaysequence->AdvancedSearch->SearchCondition = @$filter["v_field8displaysequence"];
		$this->field8displaysequence->AdvancedSearch->SearchValue2 = @$filter["y_field8displaysequence"];
		$this->field8displaysequence->AdvancedSearch->SearchOperator2 = @$filter["w_field8displaysequence"];
		$this->field8displaysequence->AdvancedSearch->save();

		// Field field8domain
		$this->field8domain->AdvancedSearch->SearchValue = @$filter["x_field8domain"];
		$this->field8domain->AdvancedSearch->SearchOperator = @$filter["z_field8domain"];
		$this->field8domain->AdvancedSearch->SearchCondition = @$filter["v_field8domain"];
		$this->field8domain->AdvancedSearch->SearchValue2 = @$filter["y_field8domain"];
		$this->field8domain->AdvancedSearch->SearchOperator2 = @$filter["w_field8domain"];
		$this->field8domain->AdvancedSearch->save();

		// Field field9label
		$this->field9label->AdvancedSearch->SearchValue = @$filter["x_field9label"];
		$this->field9label->AdvancedSearch->SearchOperator = @$filter["z_field9label"];
		$this->field9label->AdvancedSearch->SearchCondition = @$filter["v_field9label"];
		$this->field9label->AdvancedSearch->SearchValue2 = @$filter["y_field9label"];
		$this->field9label->AdvancedSearch->SearchOperator2 = @$filter["w_field9label"];
		$this->field9label->AdvancedSearch->save();

		// Field field9type
		$this->field9type->AdvancedSearch->SearchValue = @$filter["x_field9type"];
		$this->field9type->AdvancedSearch->SearchOperator = @$filter["z_field9type"];
		$this->field9type->AdvancedSearch->SearchCondition = @$filter["v_field9type"];
		$this->field9type->AdvancedSearch->SearchValue2 = @$filter["y_field9type"];
		$this->field9type->AdvancedSearch->SearchOperator2 = @$filter["w_field9type"];
		$this->field9type->AdvancedSearch->save();

		// Field field9mandatory
		$this->field9mandatory->AdvancedSearch->SearchValue = @$filter["x_field9mandatory"];
		$this->field9mandatory->AdvancedSearch->SearchOperator = @$filter["z_field9mandatory"];
		$this->field9mandatory->AdvancedSearch->SearchCondition = @$filter["v_field9mandatory"];
		$this->field9mandatory->AdvancedSearch->SearchValue2 = @$filter["y_field9mandatory"];
		$this->field9mandatory->AdvancedSearch->SearchOperator2 = @$filter["w_field9mandatory"];
		$this->field9mandatory->AdvancedSearch->save();

		// Field field9display
		$this->field9display->AdvancedSearch->SearchValue = @$filter["x_field9display"];
		$this->field9display->AdvancedSearch->SearchOperator = @$filter["z_field9display"];
		$this->field9display->AdvancedSearch->SearchCondition = @$filter["v_field9display"];
		$this->field9display->AdvancedSearch->SearchValue2 = @$filter["y_field9display"];
		$this->field9display->AdvancedSearch->SearchOperator2 = @$filter["w_field9display"];
		$this->field9display->AdvancedSearch->save();

		// Field field9displaysequence
		$this->field9displaysequence->AdvancedSearch->SearchValue = @$filter["x_field9displaysequence"];
		$this->field9displaysequence->AdvancedSearch->SearchOperator = @$filter["z_field9displaysequence"];
		$this->field9displaysequence->AdvancedSearch->SearchCondition = @$filter["v_field9displaysequence"];
		$this->field9displaysequence->AdvancedSearch->SearchValue2 = @$filter["y_field9displaysequence"];
		$this->field9displaysequence->AdvancedSearch->SearchOperator2 = @$filter["w_field9displaysequence"];
		$this->field9displaysequence->AdvancedSearch->save();

		// Field field9domain
		$this->field9domain->AdvancedSearch->SearchValue = @$filter["x_field9domain"];
		$this->field9domain->AdvancedSearch->SearchOperator = @$filter["z_field9domain"];
		$this->field9domain->AdvancedSearch->SearchCondition = @$filter["v_field9domain"];
		$this->field9domain->AdvancedSearch->SearchValue2 = @$filter["y_field9domain"];
		$this->field9domain->AdvancedSearch->SearchOperator2 = @$filter["w_field9domain"];
		$this->field9domain->AdvancedSearch->save();

		// Field field10label
		$this->field10label->AdvancedSearch->SearchValue = @$filter["x_field10label"];
		$this->field10label->AdvancedSearch->SearchOperator = @$filter["z_field10label"];
		$this->field10label->AdvancedSearch->SearchCondition = @$filter["v_field10label"];
		$this->field10label->AdvancedSearch->SearchValue2 = @$filter["y_field10label"];
		$this->field10label->AdvancedSearch->SearchOperator2 = @$filter["w_field10label"];
		$this->field10label->AdvancedSearch->save();

		// Field field10type
		$this->field10type->AdvancedSearch->SearchValue = @$filter["x_field10type"];
		$this->field10type->AdvancedSearch->SearchOperator = @$filter["z_field10type"];
		$this->field10type->AdvancedSearch->SearchCondition = @$filter["v_field10type"];
		$this->field10type->AdvancedSearch->SearchValue2 = @$filter["y_field10type"];
		$this->field10type->AdvancedSearch->SearchOperator2 = @$filter["w_field10type"];
		$this->field10type->AdvancedSearch->save();

		// Field field10mandatory
		$this->field10mandatory->AdvancedSearch->SearchValue = @$filter["x_field10mandatory"];
		$this->field10mandatory->AdvancedSearch->SearchOperator = @$filter["z_field10mandatory"];
		$this->field10mandatory->AdvancedSearch->SearchCondition = @$filter["v_field10mandatory"];
		$this->field10mandatory->AdvancedSearch->SearchValue2 = @$filter["y_field10mandatory"];
		$this->field10mandatory->AdvancedSearch->SearchOperator2 = @$filter["w_field10mandatory"];
		$this->field10mandatory->AdvancedSearch->save();

		// Field field10display
		$this->field10display->AdvancedSearch->SearchValue = @$filter["x_field10display"];
		$this->field10display->AdvancedSearch->SearchOperator = @$filter["z_field10display"];
		$this->field10display->AdvancedSearch->SearchCondition = @$filter["v_field10display"];
		$this->field10display->AdvancedSearch->SearchValue2 = @$filter["y_field10display"];
		$this->field10display->AdvancedSearch->SearchOperator2 = @$filter["w_field10display"];
		$this->field10display->AdvancedSearch->save();

		// Field field10displaysequence
		$this->field10displaysequence->AdvancedSearch->SearchValue = @$filter["x_field10displaysequence"];
		$this->field10displaysequence->AdvancedSearch->SearchOperator = @$filter["z_field10displaysequence"];
		$this->field10displaysequence->AdvancedSearch->SearchCondition = @$filter["v_field10displaysequence"];
		$this->field10displaysequence->AdvancedSearch->SearchValue2 = @$filter["y_field10displaysequence"];
		$this->field10displaysequence->AdvancedSearch->SearchOperator2 = @$filter["w_field10displaysequence"];
		$this->field10displaysequence->AdvancedSearch->save();

		// Field field10domain
		$this->field10domain->AdvancedSearch->SearchValue = @$filter["x_field10domain"];
		$this->field10domain->AdvancedSearch->SearchOperator = @$filter["z_field10domain"];
		$this->field10domain->AdvancedSearch->SearchCondition = @$filter["v_field10domain"];
		$this->field10domain->AdvancedSearch->SearchValue2 = @$filter["y_field10domain"];
		$this->field10domain->AdvancedSearch->SearchOperator2 = @$filter["w_field10domain"];
		$this->field10domain->AdvancedSearch->save();

		// Field lastupdatedate
		$this->lastupdatedate->AdvancedSearch->SearchValue = @$filter["x_lastupdatedate"];
		$this->lastupdatedate->AdvancedSearch->SearchOperator = @$filter["z_lastupdatedate"];
		$this->lastupdatedate->AdvancedSearch->SearchCondition = @$filter["v_lastupdatedate"];
		$this->lastupdatedate->AdvancedSearch->SearchValue2 = @$filter["y_lastupdatedate"];
		$this->lastupdatedate->AdvancedSearch->SearchOperator2 = @$filter["w_lastupdatedate"];
		$this->lastupdatedate->AdvancedSearch->save();
		$this->BasicSearch->setKeyword(@$filter[Config("TABLE_BASIC_SEARCH")]);
		$this->BasicSearch->setType(@$filter[Config("TABLE_BASIC_SEARCH_TYPE")]);
	}

	// Advanced search WHERE clause based on QueryString
	protected function advancedSearchWhere($default = FALSE)
	{
		global $Security;
		$where = "";
		if (!$Security->canSearch())
			return "";
		$this->buildSearchSql($where, $this->extrafieldsid, $default, FALSE); // extrafieldsid
		$this->buildSearchSql($where, $this->merchantid, $default, FALSE); // merchantid
		$this->buildSearchSql($where, $this->name, $default, FALSE); // name
		$this->buildSearchSql($where, $this->field1label, $default, FALSE); // field1label
		$this->buildSearchSql($where, $this->field1type, $default, FALSE); // field1type
		$this->buildSearchSql($where, $this->field1mandatory, $default, FALSE); // field1mandatory
		$this->buildSearchSql($where, $this->field1display, $default, FALSE); // field1display
		$this->buildSearchSql($where, $this->field1displaysequence, $default, FALSE); // field1displaysequence
		$this->buildSearchSql($where, $this->field1domain, $default, FALSE); // field1domain
		$this->buildSearchSql($where, $this->field2label, $default, FALSE); // field2label
		$this->buildSearchSql($where, $this->field2type, $default, FALSE); // field2type
		$this->buildSearchSql($where, $this->field2mandatory, $default, FALSE); // field2mandatory
		$this->buildSearchSql($where, $this->field2display, $default, FALSE); // field2display
		$this->buildSearchSql($where, $this->field2displaysequence, $default, FALSE); // field2displaysequence
		$this->buildSearchSql($where, $this->field2domain, $default, FALSE); // field2domain
		$this->buildSearchSql($where, $this->field3label, $default, FALSE); // field3label
		$this->buildSearchSql($where, $this->field3type, $default, FALSE); // field3type
		$this->buildSearchSql($where, $this->field3mandatory, $default, FALSE); // field3mandatory
		$this->buildSearchSql($where, $this->field3display, $default, FALSE); // field3display
		$this->buildSearchSql($where, $this->field3displaysequence, $default, FALSE); // field3displaysequence
		$this->buildSearchSql($where, $this->field3domain, $default, FALSE); // field3domain
		$this->buildSearchSql($where, $this->field4label, $default, FALSE); // field4label
		$this->buildSearchSql($where, $this->field4type, $default, FALSE); // field4type
		$this->buildSearchSql($where, $this->field4mandatory, $default, FALSE); // field4mandatory
		$this->buildSearchSql($where, $this->field4display, $default, FALSE); // field4display
		$this->buildSearchSql($where, $this->field4displaysequence, $default, FALSE); // field4displaysequence
		$this->buildSearchSql($where, $this->field4domain, $default, FALSE); // field4domain
		$this->buildSearchSql($where, $this->field5label, $default, FALSE); // field5label
		$this->buildSearchSql($where, $this->field5type, $default, FALSE); // field5type
		$this->buildSearchSql($where, $this->field5mandatory, $default, FALSE); // field5mandatory
		$this->buildSearchSql($where, $this->field5display, $default, FALSE); // field5display
		$this->buildSearchSql($where, $this->field5displaysequence, $default, FALSE); // field5displaysequence
		$this->buildSearchSql($where, $this->field5domain, $default, FALSE); // field5domain
		$this->buildSearchSql($where, $this->field6label, $default, FALSE); // field6label
		$this->buildSearchSql($where, $this->field6type, $default, FALSE); // field6type
		$this->buildSearchSql($where, $this->field6mandatory, $default, FALSE); // field6mandatory
		$this->buildSearchSql($where, $this->field6display, $default, FALSE); // field6display
		$this->buildSearchSql($where, $this->field6displaysequence, $default, FALSE); // field6displaysequence
		$this->buildSearchSql($where, $this->field6domain, $default, FALSE); // field6domain
		$this->buildSearchSql($where, $this->field7label, $default, FALSE); // field7label
		$this->buildSearchSql($where, $this->field7type, $default, FALSE); // field7type
		$this->buildSearchSql($where, $this->field7mandatory, $default, FALSE); // field7mandatory
		$this->buildSearchSql($where, $this->field7display, $default, FALSE); // field7display
		$this->buildSearchSql($where, $this->field7displaysequence, $default, FALSE); // field7displaysequence
		$this->buildSearchSql($where, $this->field7domain, $default, FALSE); // field7domain
		$this->buildSearchSql($where, $this->field8label, $default, FALSE); // field8label
		$this->buildSearchSql($where, $this->field8type, $default, FALSE); // field8type
		$this->buildSearchSql($where, $this->field8mandatory, $default, FALSE); // field8mandatory
		$this->buildSearchSql($where, $this->field8display, $default, FALSE); // field8display
		$this->buildSearchSql($where, $this->field8displaysequence, $default, FALSE); // field8displaysequence
		$this->buildSearchSql($where, $this->field8domain, $default, FALSE); // field8domain
		$this->buildSearchSql($where, $this->field9label, $default, FALSE); // field9label
		$this->buildSearchSql($where, $this->field9type, $default, FALSE); // field9type
		$this->buildSearchSql($where, $this->field9mandatory, $default, FALSE); // field9mandatory
		$this->buildSearchSql($where, $this->field9display, $default, FALSE); // field9display
		$this->buildSearchSql($where, $this->field9displaysequence, $default, FALSE); // field9displaysequence
		$this->buildSearchSql($where, $this->field9domain, $default, FALSE); // field9domain
		$this->buildSearchSql($where, $this->field10label, $default, FALSE); // field10label
		$this->buildSearchSql($where, $this->field10type, $default, FALSE); // field10type
		$this->buildSearchSql($where, $this->field10mandatory, $default, FALSE); // field10mandatory
		$this->buildSearchSql($where, $this->field10display, $default, FALSE); // field10display
		$this->buildSearchSql($where, $this->field10displaysequence, $default, FALSE); // field10displaysequence
		$this->buildSearchSql($where, $this->field10domain, $default, FALSE); // field10domain
		$this->buildSearchSql($where, $this->lastupdatedate, $default, FALSE); // lastupdatedate

		// Set up search parm
		if (!$default && $where != "" && in_array($this->Command, ["", "reset", "resetall"])) {
			$this->Command = "search";
		}
		if (!$default && $this->Command == "search") {
			$this->extrafieldsid->AdvancedSearch->save(); // extrafieldsid
			$this->merchantid->AdvancedSearch->save(); // merchantid
			$this->name->AdvancedSearch->save(); // name
			$this->field1label->AdvancedSearch->save(); // field1label
			$this->field1type->AdvancedSearch->save(); // field1type
			$this->field1mandatory->AdvancedSearch->save(); // field1mandatory
			$this->field1display->AdvancedSearch->save(); // field1display
			$this->field1displaysequence->AdvancedSearch->save(); // field1displaysequence
			$this->field1domain->AdvancedSearch->save(); // field1domain
			$this->field2label->AdvancedSearch->save(); // field2label
			$this->field2type->AdvancedSearch->save(); // field2type
			$this->field2mandatory->AdvancedSearch->save(); // field2mandatory
			$this->field2display->AdvancedSearch->save(); // field2display
			$this->field2displaysequence->AdvancedSearch->save(); // field2displaysequence
			$this->field2domain->AdvancedSearch->save(); // field2domain
			$this->field3label->AdvancedSearch->save(); // field3label
			$this->field3type->AdvancedSearch->save(); // field3type
			$this->field3mandatory->AdvancedSearch->save(); // field3mandatory
			$this->field3display->AdvancedSearch->save(); // field3display
			$this->field3displaysequence->AdvancedSearch->save(); // field3displaysequence
			$this->field3domain->AdvancedSearch->save(); // field3domain
			$this->field4label->AdvancedSearch->save(); // field4label
			$this->field4type->AdvancedSearch->save(); // field4type
			$this->field4mandatory->AdvancedSearch->save(); // field4mandatory
			$this->field4display->AdvancedSearch->save(); // field4display
			$this->field4displaysequence->AdvancedSearch->save(); // field4displaysequence
			$this->field4domain->AdvancedSearch->save(); // field4domain
			$this->field5label->AdvancedSearch->save(); // field5label
			$this->field5type->AdvancedSearch->save(); // field5type
			$this->field5mandatory->AdvancedSearch->save(); // field5mandatory
			$this->field5display->AdvancedSearch->save(); // field5display
			$this->field5displaysequence->AdvancedSearch->save(); // field5displaysequence
			$this->field5domain->AdvancedSearch->save(); // field5domain
			$this->field6label->AdvancedSearch->save(); // field6label
			$this->field6type->AdvancedSearch->save(); // field6type
			$this->field6mandatory->AdvancedSearch->save(); // field6mandatory
			$this->field6display->AdvancedSearch->save(); // field6display
			$this->field6displaysequence->AdvancedSearch->save(); // field6displaysequence
			$this->field6domain->AdvancedSearch->save(); // field6domain
			$this->field7label->AdvancedSearch->save(); // field7label
			$this->field7type->AdvancedSearch->save(); // field7type
			$this->field7mandatory->AdvancedSearch->save(); // field7mandatory
			$this->field7display->AdvancedSearch->save(); // field7display
			$this->field7displaysequence->AdvancedSearch->save(); // field7displaysequence
			$this->field7domain->AdvancedSearch->save(); // field7domain
			$this->field8label->AdvancedSearch->save(); // field8label
			$this->field8type->AdvancedSearch->save(); // field8type
			$this->field8mandatory->AdvancedSearch->save(); // field8mandatory
			$this->field8display->AdvancedSearch->save(); // field8display
			$this->field8displaysequence->AdvancedSearch->save(); // field8displaysequence
			$this->field8domain->AdvancedSearch->save(); // field8domain
			$this->field9label->AdvancedSearch->save(); // field9label
			$this->field9type->AdvancedSearch->save(); // field9type
			$this->field9mandatory->AdvancedSearch->save(); // field9mandatory
			$this->field9display->AdvancedSearch->save(); // field9display
			$this->field9displaysequence->AdvancedSearch->save(); // field9displaysequence
			$this->field9domain->AdvancedSearch->save(); // field9domain
			$this->field10label->AdvancedSearch->save(); // field10label
			$this->field10type->AdvancedSearch->save(); // field10type
			$this->field10mandatory->AdvancedSearch->save(); // field10mandatory
			$this->field10display->AdvancedSearch->save(); // field10display
			$this->field10displaysequence->AdvancedSearch->save(); // field10displaysequence
			$this->field10domain->AdvancedSearch->save(); // field10domain
			$this->lastupdatedate->AdvancedSearch->save(); // lastupdatedate
		}
		return $where;
	}

	// Build search SQL
	protected function buildSearchSql(&$where, &$fld, $default, $multiValue)
	{
		$fldParm = $fld->Param;
		$fldVal = ($default) ? $fld->AdvancedSearch->SearchValueDefault : $fld->AdvancedSearch->SearchValue;
		$fldOpr = ($default) ? $fld->AdvancedSearch->SearchOperatorDefault : $fld->AdvancedSearch->SearchOperator;
		$fldCond = ($default) ? $fld->AdvancedSearch->SearchConditionDefault : $fld->AdvancedSearch->SearchCondition;
		$fldVal2 = ($default) ? $fld->AdvancedSearch->SearchValue2Default : $fld->AdvancedSearch->SearchValue2;
		$fldOpr2 = ($default) ? $fld->AdvancedSearch->SearchOperator2Default : $fld->AdvancedSearch->SearchOperator2;
		$wrk = "";
		if (is_array($fldVal))
			$fldVal = implode(Config("MULTIPLE_OPTION_SEPARATOR"), $fldVal);
		if (is_array($fldVal2))
			$fldVal2 = implode(Config("MULTIPLE_OPTION_SEPARATOR"), $fldVal2);
		$fldOpr = strtoupper(trim($fldOpr));
		if ($fldOpr == "")
			$fldOpr = "=";
		$fldOpr2 = strtoupper(trim($fldOpr2));
		if ($fldOpr2 == "")
			$fldOpr2 = "=";
		if (Config("SEARCH_MULTI_VALUE_OPTION") == 1 || !IsMultiSearchOperator($fldOpr))
			$multiValue = FALSE;
		if ($multiValue) {
			$wrk1 = ($fldVal != "") ? GetMultiSearchSql($fld, $fldOpr, $fldVal, $this->Dbid) : ""; // Field value 1
			$wrk2 = ($fldVal2 != "") ? GetMultiSearchSql($fld, $fldOpr2, $fldVal2, $this->Dbid) : ""; // Field value 2
			$wrk = $wrk1; // Build final SQL
			if ($wrk2 != "")
				$wrk = ($wrk != "") ? "($wrk) $fldCond ($wrk2)" : $wrk2;
		} else {
			$fldVal = $this->convertSearchValue($fld, $fldVal);
			$fldVal2 = $this->convertSearchValue($fld, $fldVal2);
			$wrk = GetSearchSql($fld, $fldVal, $fldOpr, $fldCond, $fldVal2, $fldOpr2, $this->Dbid);
		}
		AddFilter($where, $wrk);
	}

	// Convert search value
	protected function convertSearchValue(&$fld, $fldVal)
	{
		if ($fldVal == Config("NULL_VALUE") || $fldVal == Config("NOT_NULL_VALUE"))
			return $fldVal;
		$value = $fldVal;
		if ($fld->isBoolean()) {
			if ($fldVal != "")
				$value = (SameText($fldVal, "1") || SameText($fldVal, "y") || SameText($fldVal, "t")) ? $fld->TrueValue : $fld->FalseValue;
		} elseif ($fld->DataType == DATATYPE_DATE || $fld->DataType == DATATYPE_TIME) {
			if ($fldVal != "")
				$value = UnFormatDateTime($fldVal, $fld->DateTimeFormat);
		}
		return $value;
	}

	// Return basic search SQL
	protected function basicSearchSql($arKeywords, $type)
	{
		$where = "";
		$this->buildBasicSearchSql($where, $this->name, $arKeywords, $type);
		$this->buildBasicSearchSql($where, $this->field1label, $arKeywords, $type);
		$this->buildBasicSearchSql($where, $this->field2label, $arKeywords, $type);
		$this->buildBasicSearchSql($where, $this->field3label, $arKeywords, $type);
		$this->buildBasicSearchSql($where, $this->field4label, $arKeywords, $type);
		$this->buildBasicSearchSql($where, $this->field5label, $arKeywords, $type);
		$this->buildBasicSearchSql($where, $this->field6label, $arKeywords, $type);
		$this->buildBasicSearchSql($where, $this->field7label, $arKeywords, $type);
		$this->buildBasicSearchSql($where, $this->field8label, $arKeywords, $type);
		$this->buildBasicSearchSql($where, $this->field9label, $arKeywords, $type);
		$this->buildBasicSearchSql($where, $this->field10label, $arKeywords, $type);
		return $where;
	}

	// Build basic search SQL
	protected function buildBasicSearchSql(&$where, &$fld, $arKeywords, $type)
	{
		$defCond = ($type == "OR") ? "OR" : "AND";
		$arSql = []; // Array for SQL parts
		$arCond = []; // Array for search conditions
		$cnt = count($arKeywords);
		$j = 0; // Number of SQL parts
		for ($i = 0; $i < $cnt; $i++) {
			$keyword = $arKeywords[$i];
			$keyword = trim($keyword);
			if (Config("BASIC_SEARCH_IGNORE_PATTERN") != "") {
				$keyword = preg_replace(Config("BASIC_SEARCH_IGNORE_PATTERN"), "\\", $keyword);
				$ar = explode("\\", $keyword);
			} else {
				$ar = [$keyword];
			}
			foreach ($ar as $keyword) {
				if ($keyword != "") {
					$wrk = "";
					if ($keyword == "OR" && $type == "") {
						if ($j > 0)
							$arCond[$j - 1] = "OR";
					} elseif ($keyword == Config("NULL_VALUE")) {
						$wrk = $fld->Expression . " IS NULL";
					} elseif ($keyword == Config("NOT_NULL_VALUE")) {
						$wrk = $fld->Expression . " IS NOT NULL";
					} elseif ($fld->IsVirtual) {
						$wrk = $fld->VirtualExpression . Like(QuotedValue("%" . $keyword . "%", DATATYPE_STRING, $this->Dbid), $this->Dbid);
					} elseif ($fld->DataType != DATATYPE_NUMBER || is_numeric($keyword)) {
						$wrk = $fld->BasicSearchExpression . Like(QuotedValue("%" . $keyword . "%", DATATYPE_STRING, $this->Dbid), $this->Dbid);
					}
					if ($wrk != "") {
						$arSql[$j] = $wrk;
						$arCond[$j] = $defCond;
						$j += 1;
					}
				}
			}
		}
		$cnt = count($arSql);
		$quoted = FALSE;
		$sql = "";
		if ($cnt > 0) {
			for ($i = 0; $i < $cnt - 1; $i++) {
				if ($arCond[$i] == "OR") {
					if (!$quoted)
						$sql .= "(";
					$quoted = TRUE;
				}
				$sql .= $arSql[$i];
				if ($quoted && $arCond[$i] != "OR") {
					$sql .= ")";
					$quoted = FALSE;
				}
				$sql .= " " . $arCond[$i] . " ";
			}
			$sql .= $arSql[$cnt - 1];
			if ($quoted)
				$sql .= ")";
		}
		if ($sql != "") {
			if ($where != "")
				$where .= " OR ";
			$where .= "(" . $sql . ")";
		}
	}

	// Return basic search WHERE clause based on search keyword and type
	protected function basicSearchWhere($default = FALSE)
	{
		global $Security;
		$searchStr = "";
		if (!$Security->canSearch())
			return "";
		$searchKeyword = ($default) ? $this->BasicSearch->KeywordDefault : $this->BasicSearch->Keyword;
		$searchType = ($default) ? $this->BasicSearch->TypeDefault : $this->BasicSearch->Type;

		// Get search SQL
		if ($searchKeyword != "") {
			$ar = $this->BasicSearch->keywordList($default);

			// Search keyword in any fields
			if (($searchType == "OR" || $searchType == "AND") && $this->BasicSearch->BasicSearchAnyFields) {
				foreach ($ar as $keyword) {
					if ($keyword != "") {
						if ($searchStr != "")
							$searchStr .= " " . $searchType . " ";
						$searchStr .= "(" . $this->basicSearchSql([$keyword], $searchType) . ")";
					}
				}
			} else {
				$searchStr = $this->basicSearchSql($ar, $searchType);
			}
			if (!$default && in_array($this->Command, ["", "reset", "resetall"]))
				$this->Command = "search";
		}
		if (!$default && $this->Command == "search") {
			$this->BasicSearch->setKeyword($searchKeyword);
			$this->BasicSearch->setType($searchType);
		}
		return $searchStr;
	}

	// Check if search parm exists
	protected function checkSearchParms()
	{

		// Check basic search
		if ($this->BasicSearch->issetSession())
			return TRUE;
		if ($this->extrafieldsid->AdvancedSearch->issetSession())
			return TRUE;
		if ($this->merchantid->AdvancedSearch->issetSession())
			return TRUE;
		if ($this->name->AdvancedSearch->issetSession())
			return TRUE;
		if ($this->field1label->AdvancedSearch->issetSession())
			return TRUE;
		if ($this->field1type->AdvancedSearch->issetSession())
			return TRUE;
		if ($this->field1mandatory->AdvancedSearch->issetSession())
			return TRUE;
		if ($this->field1display->AdvancedSearch->issetSession())
			return TRUE;
		if ($this->field1displaysequence->AdvancedSearch->issetSession())
			return TRUE;
		if ($this->field1domain->AdvancedSearch->issetSession())
			return TRUE;
		if ($this->field2label->AdvancedSearch->issetSession())
			return TRUE;
		if ($this->field2type->AdvancedSearch->issetSession())
			return TRUE;
		if ($this->field2mandatory->AdvancedSearch->issetSession())
			return TRUE;
		if ($this->field2display->AdvancedSearch->issetSession())
			return TRUE;
		if ($this->field2displaysequence->AdvancedSearch->issetSession())
			return TRUE;
		if ($this->field2domain->AdvancedSearch->issetSession())
			return TRUE;
		if ($this->field3label->AdvancedSearch->issetSession())
			return TRUE;
		if ($this->field3type->AdvancedSearch->issetSession())
			return TRUE;
		if ($this->field3mandatory->AdvancedSearch->issetSession())
			return TRUE;
		if ($this->field3display->AdvancedSearch->issetSession())
			return TRUE;
		if ($this->field3displaysequence->AdvancedSearch->issetSession())
			return TRUE;
		if ($this->field3domain->AdvancedSearch->issetSession())
			return TRUE;
		if ($this->field4label->AdvancedSearch->issetSession())
			return TRUE;
		if ($this->field4type->AdvancedSearch->issetSession())
			return TRUE;
		if ($this->field4mandatory->AdvancedSearch->issetSession())
			return TRUE;
		if ($this->field4display->AdvancedSearch->issetSession())
			return TRUE;
		if ($this->field4displaysequence->AdvancedSearch->issetSession())
			return TRUE;
		if ($this->field4domain->AdvancedSearch->issetSession())
			return TRUE;
		if ($this->field5label->AdvancedSearch->issetSession())
			return TRUE;
		if ($this->field5type->AdvancedSearch->issetSession())
			return TRUE;
		if ($this->field5mandatory->AdvancedSearch->issetSession())
			return TRUE;
		if ($this->field5display->AdvancedSearch->issetSession())
			return TRUE;
		if ($this->field5displaysequence->AdvancedSearch->issetSession())
			return TRUE;
		if ($this->field5domain->AdvancedSearch->issetSession())
			return TRUE;
		if ($this->field6label->AdvancedSearch->issetSession())
			return TRUE;
		if ($this->field6type->AdvancedSearch->issetSession())
			return TRUE;
		if ($this->field6mandatory->AdvancedSearch->issetSession())
			return TRUE;
		if ($this->field6display->AdvancedSearch->issetSession())
			return TRUE;
		if ($this->field6displaysequence->AdvancedSearch->issetSession())
			return TRUE;
		if ($this->field6domain->AdvancedSearch->issetSession())
			return TRUE;
		if ($this->field7label->AdvancedSearch->issetSession())
			return TRUE;
		if ($this->field7type->AdvancedSearch->issetSession())
			return TRUE;
		if ($this->field7mandatory->AdvancedSearch->issetSession())
			return TRUE;
		if ($this->field7display->AdvancedSearch->issetSession())
			return TRUE;
		if ($this->field7displaysequence->AdvancedSearch->issetSession())
			return TRUE;
		if ($this->field7domain->AdvancedSearch->issetSession())
			return TRUE;
		if ($this->field8label->AdvancedSearch->issetSession())
			return TRUE;
		if ($this->field8type->AdvancedSearch->issetSession())
			return TRUE;
		if ($this->field8mandatory->AdvancedSearch->issetSession())
			return TRUE;
		if ($this->field8display->AdvancedSearch->issetSession())
			return TRUE;
		if ($this->field8displaysequence->AdvancedSearch->issetSession())
			return TRUE;
		if ($this->field8domain->AdvancedSearch->issetSession())
			return TRUE;
		if ($this->field9label->AdvancedSearch->issetSession())
			return TRUE;
		if ($this->field9type->AdvancedSearch->issetSession())
			return TRUE;
		if ($this->field9mandatory->AdvancedSearch->issetSession())
			return TRUE;
		if ($this->field9display->AdvancedSearch->issetSession())
			return TRUE;
		if ($this->field9displaysequence->AdvancedSearch->issetSession())
			return TRUE;
		if ($this->field9domain->AdvancedSearch->issetSession())
			return TRUE;
		if ($this->field10label->AdvancedSearch->issetSession())
			return TRUE;
		if ($this->field10type->AdvancedSearch->issetSession())
			return TRUE;
		if ($this->field10mandatory->AdvancedSearch->issetSession())
			return TRUE;
		if ($this->field10display->AdvancedSearch->issetSession())
			return TRUE;
		if ($this->field10displaysequence->AdvancedSearch->issetSession())
			return TRUE;
		if ($this->field10domain->AdvancedSearch->issetSession())
			return TRUE;
		if ($this->lastupdatedate->AdvancedSearch->issetSession())
			return TRUE;
		return FALSE;
	}

	// Clear all search parameters
	protected function resetSearchParms()
	{

		// Clear search WHERE clause
		$this->SearchWhere = "";
		$this->setSearchWhere($this->SearchWhere);

		// Clear basic search parameters
		$this->resetBasicSearchParms();

		// Clear advanced search parameters
		$this->resetAdvancedSearchParms();
	}

	// Load advanced search default values
	protected function loadAdvancedSearchDefault()
	{
		return FALSE;
	}

	// Clear all basic search parameters
	protected function resetBasicSearchParms()
	{
		$this->BasicSearch->unsetSession();
	}

	// Clear all advanced search parameters
	protected function resetAdvancedSearchParms()
	{
		$this->extrafieldsid->AdvancedSearch->unsetSession();
		$this->merchantid->AdvancedSearch->unsetSession();
		$this->name->AdvancedSearch->unsetSession();
		$this->field1label->AdvancedSearch->unsetSession();
		$this->field1type->AdvancedSearch->unsetSession();
		$this->field1mandatory->AdvancedSearch->unsetSession();
		$this->field1display->AdvancedSearch->unsetSession();
		$this->field1displaysequence->AdvancedSearch->unsetSession();
		$this->field1domain->AdvancedSearch->unsetSession();
		$this->field2label->AdvancedSearch->unsetSession();
		$this->field2type->AdvancedSearch->unsetSession();
		$this->field2mandatory->AdvancedSearch->unsetSession();
		$this->field2display->AdvancedSearch->unsetSession();
		$this->field2displaysequence->AdvancedSearch->unsetSession();
		$this->field2domain->AdvancedSearch->unsetSession();
		$this->field3label->AdvancedSearch->unsetSession();
		$this->field3type->AdvancedSearch->unsetSession();
		$this->field3mandatory->AdvancedSearch->unsetSession();
		$this->field3display->AdvancedSearch->unsetSession();
		$this->field3displaysequence->AdvancedSearch->unsetSession();
		$this->field3domain->AdvancedSearch->unsetSession();
		$this->field4label->AdvancedSearch->unsetSession();
		$this->field4type->AdvancedSearch->unsetSession();
		$this->field4mandatory->AdvancedSearch->unsetSession();
		$this->field4display->AdvancedSearch->unsetSession();
		$this->field4displaysequence->AdvancedSearch->unsetSession();
		$this->field4domain->AdvancedSearch->unsetSession();
		$this->field5label->AdvancedSearch->unsetSession();
		$this->field5type->AdvancedSearch->unsetSession();
		$this->field5mandatory->AdvancedSearch->unsetSession();
		$this->field5display->AdvancedSearch->unsetSession();
		$this->field5displaysequence->AdvancedSearch->unsetSession();
		$this->field5domain->AdvancedSearch->unsetSession();
		$this->field6label->AdvancedSearch->unsetSession();
		$this->field6type->AdvancedSearch->unsetSession();
		$this->field6mandatory->AdvancedSearch->unsetSession();
		$this->field6display->AdvancedSearch->unsetSession();
		$this->field6displaysequence->AdvancedSearch->unsetSession();
		$this->field6domain->AdvancedSearch->unsetSession();
		$this->field7label->AdvancedSearch->unsetSession();
		$this->field7type->AdvancedSearch->unsetSession();
		$this->field7mandatory->AdvancedSearch->unsetSession();
		$this->field7display->AdvancedSearch->unsetSession();
		$this->field7displaysequence->AdvancedSearch->unsetSession();
		$this->field7domain->AdvancedSearch->unsetSession();
		$this->field8label->AdvancedSearch->unsetSession();
		$this->field8type->AdvancedSearch->unsetSession();
		$this->field8mandatory->AdvancedSearch->unsetSession();
		$this->field8display->AdvancedSearch->unsetSession();
		$this->field8displaysequence->AdvancedSearch->unsetSession();
		$this->field8domain->AdvancedSearch->unsetSession();
		$this->field9label->AdvancedSearch->unsetSession();
		$this->field9type->AdvancedSearch->unsetSession();
		$this->field9mandatory->AdvancedSearch->unsetSession();
		$this->field9display->AdvancedSearch->unsetSession();
		$this->field9displaysequence->AdvancedSearch->unsetSession();
		$this->field9domain->AdvancedSearch->unsetSession();
		$this->field10label->AdvancedSearch->unsetSession();
		$this->field10type->AdvancedSearch->unsetSession();
		$this->field10mandatory->AdvancedSearch->unsetSession();
		$this->field10display->AdvancedSearch->unsetSession();
		$this->field10displaysequence->AdvancedSearch->unsetSession();
		$this->field10domain->AdvancedSearch->unsetSession();
		$this->lastupdatedate->AdvancedSearch->unsetSession();
	}

	// Restore all search parameters
	protected function restoreSearchParms()
	{
		$this->RestoreSearch = TRUE;

		// Restore basic search values
		$this->BasicSearch->load();

		// Restore advanced search values
		$this->extrafieldsid->AdvancedSearch->load();
		$this->merchantid->AdvancedSearch->load();
		$this->name->AdvancedSearch->load();
		$this->field1label->AdvancedSearch->load();
		$this->field1type->AdvancedSearch->load();
		$this->field1mandatory->AdvancedSearch->load();
		$this->field1display->AdvancedSearch->load();
		$this->field1displaysequence->AdvancedSearch->load();
		$this->field1domain->AdvancedSearch->load();
		$this->field2label->AdvancedSearch->load();
		$this->field2type->AdvancedSearch->load();
		$this->field2mandatory->AdvancedSearch->load();
		$this->field2display->AdvancedSearch->load();
		$this->field2displaysequence->AdvancedSearch->load();
		$this->field2domain->AdvancedSearch->load();
		$this->field3label->AdvancedSearch->load();
		$this->field3type->AdvancedSearch->load();
		$this->field3mandatory->AdvancedSearch->load();
		$this->field3display->AdvancedSearch->load();
		$this->field3displaysequence->AdvancedSearch->load();
		$this->field3domain->AdvancedSearch->load();
		$this->field4label->AdvancedSearch->load();
		$this->field4type->AdvancedSearch->load();
		$this->field4mandatory->AdvancedSearch->load();
		$this->field4display->AdvancedSearch->load();
		$this->field4displaysequence->AdvancedSearch->load();
		$this->field4domain->AdvancedSearch->load();
		$this->field5label->AdvancedSearch->load();
		$this->field5type->AdvancedSearch->load();
		$this->field5mandatory->AdvancedSearch->load();
		$this->field5display->AdvancedSearch->load();
		$this->field5displaysequence->AdvancedSearch->load();
		$this->field5domain->AdvancedSearch->load();
		$this->field6label->AdvancedSearch->load();
		$this->field6type->AdvancedSearch->load();
		$this->field6mandatory->AdvancedSearch->load();
		$this->field6display->AdvancedSearch->load();
		$this->field6displaysequence->AdvancedSearch->load();
		$this->field6domain->AdvancedSearch->load();
		$this->field7label->AdvancedSearch->load();
		$this->field7type->AdvancedSearch->load();
		$this->field7mandatory->AdvancedSearch->load();
		$this->field7display->AdvancedSearch->load();
		$this->field7displaysequence->AdvancedSearch->load();
		$this->field7domain->AdvancedSearch->load();
		$this->field8label->AdvancedSearch->load();
		$this->field8type->AdvancedSearch->load();
		$this->field8mandatory->AdvancedSearch->load();
		$this->field8display->AdvancedSearch->load();
		$this->field8displaysequence->AdvancedSearch->load();
		$this->field8domain->AdvancedSearch->load();
		$this->field9label->AdvancedSearch->load();
		$this->field9type->AdvancedSearch->load();
		$this->field9mandatory->AdvancedSearch->load();
		$this->field9display->AdvancedSearch->load();
		$this->field9displaysequence->AdvancedSearch->load();
		$this->field9domain->AdvancedSearch->load();
		$this->field10label->AdvancedSearch->load();
		$this->field10type->AdvancedSearch->load();
		$this->field10mandatory->AdvancedSearch->load();
		$this->field10display->AdvancedSearch->load();
		$this->field10displaysequence->AdvancedSearch->load();
		$this->field10domain->AdvancedSearch->load();
		$this->lastupdatedate->AdvancedSearch->load();
	}

	// Set up sort parameters
	protected function setupSortOrder()
	{

		// Check for "order" parameter
		if (Get("order") !== NULL) {
			$this->CurrentOrder = Get("order");
			$this->CurrentOrderType = Get("ordertype", "");
			$this->updateSort($this->extrafieldsid); // extrafieldsid
			$this->updateSort($this->merchantid); // merchantid
			$this->updateSort($this->name); // name
			$this->updateSort($this->field1label); // field1label
			$this->updateSort($this->field1type); // field1type
			$this->updateSort($this->field1mandatory); // field1mandatory
			$this->updateSort($this->field1display); // field1display
			$this->updateSort($this->field1displaysequence); // field1displaysequence
			$this->updateSort($this->field1domain); // field1domain
			$this->updateSort($this->field2label); // field2label
			$this->updateSort($this->field2type); // field2type
			$this->updateSort($this->field2mandatory); // field2mandatory
			$this->updateSort($this->field2display); // field2display
			$this->updateSort($this->field2displaysequence); // field2displaysequence
			$this->updateSort($this->field2domain); // field2domain
			$this->updateSort($this->field3label); // field3label
			$this->updateSort($this->field3type); // field3type
			$this->updateSort($this->field3mandatory); // field3mandatory
			$this->updateSort($this->field3display); // field3display
			$this->updateSort($this->field3displaysequence); // field3displaysequence
			$this->updateSort($this->field3domain); // field3domain
			$this->updateSort($this->field4label); // field4label
			$this->updateSort($this->field4type); // field4type
			$this->updateSort($this->field4mandatory); // field4mandatory
			$this->updateSort($this->field4display); // field4display
			$this->updateSort($this->field4displaysequence); // field4displaysequence
			$this->updateSort($this->field4domain); // field4domain
			$this->updateSort($this->field5label); // field5label
			$this->updateSort($this->field5type); // field5type
			$this->updateSort($this->field5mandatory); // field5mandatory
			$this->updateSort($this->field5display); // field5display
			$this->updateSort($this->field5displaysequence); // field5displaysequence
			$this->updateSort($this->field5domain); // field5domain
			$this->updateSort($this->field6label); // field6label
			$this->updateSort($this->field6type); // field6type
			$this->updateSort($this->field6mandatory); // field6mandatory
			$this->updateSort($this->field6display); // field6display
			$this->updateSort($this->field6displaysequence); // field6displaysequence
			$this->updateSort($this->field6domain); // field6domain
			$this->updateSort($this->field7label); // field7label
			$this->updateSort($this->field7type); // field7type
			$this->updateSort($this->field7mandatory); // field7mandatory
			$this->updateSort($this->field7display); // field7display
			$this->updateSort($this->field7displaysequence); // field7displaysequence
			$this->updateSort($this->field7domain); // field7domain
			$this->updateSort($this->field8label); // field8label
			$this->updateSort($this->field8type); // field8type
			$this->updateSort($this->field8mandatory); // field8mandatory
			$this->updateSort($this->field8display); // field8display
			$this->updateSort($this->field8displaysequence); // field8displaysequence
			$this->updateSort($this->field8domain); // field8domain
			$this->updateSort($this->field9label); // field9label
			$this->updateSort($this->field9type); // field9type
			$this->updateSort($this->field9mandatory); // field9mandatory
			$this->updateSort($this->field9display); // field9display
			$this->updateSort($this->field9displaysequence); // field9displaysequence
			$this->updateSort($this->field9domain); // field9domain
			$this->updateSort($this->field10label); // field10label
			$this->updateSort($this->field10type); // field10type
			$this->updateSort($this->field10mandatory); // field10mandatory
			$this->updateSort($this->field10display); // field10display
			$this->updateSort($this->field10displaysequence); // field10displaysequence
			$this->updateSort($this->field10domain); // field10domain
			$this->updateSort($this->lastupdatedate); // lastupdatedate
			$this->setStartRecordNumber(1); // Reset start position
		}
	}

	// Load sort order parameters
	protected function loadSortOrder()
	{
		$orderBy = $this->getSessionOrderBy(); // Get ORDER BY from Session
		if ($orderBy == "") {
			if ($this->getSqlOrderBy() != "") {
				$orderBy = $this->getSqlOrderBy();
				$this->setSessionOrderBy($orderBy);
			}
		}
	}

	// Reset command
	// - cmd=reset (Reset search parameters)
	// - cmd=resetall (Reset search and master/detail parameters)
	// - cmd=resetsort (Reset sort parameters)

	protected function resetCmd()
	{

		// Check if reset command
		if (StartsString("reset", $this->Command)) {

			// Reset search criteria
			if ($this->Command == "reset" || $this->Command == "resetall")
				$this->resetSearchParms();

			// Reset sorting order
			if ($this->Command == "resetsort") {
				$orderBy = "";
				$this->setSessionOrderBy($orderBy);
				$this->extrafieldsid->setSort("");
				$this->merchantid->setSort("");
				$this->name->setSort("");
				$this->field1label->setSort("");
				$this->field1type->setSort("");
				$this->field1mandatory->setSort("");
				$this->field1display->setSort("");
				$this->field1displaysequence->setSort("");
				$this->field1domain->setSort("");
				$this->field2label->setSort("");
				$this->field2type->setSort("");
				$this->field2mandatory->setSort("");
				$this->field2display->setSort("");
				$this->field2displaysequence->setSort("");
				$this->field2domain->setSort("");
				$this->field3label->setSort("");
				$this->field3type->setSort("");
				$this->field3mandatory->setSort("");
				$this->field3display->setSort("");
				$this->field3displaysequence->setSort("");
				$this->field3domain->setSort("");
				$this->field4label->setSort("");
				$this->field4type->setSort("");
				$this->field4mandatory->setSort("");
				$this->field4display->setSort("");
				$this->field4displaysequence->setSort("");
				$this->field4domain->setSort("");
				$this->field5label->setSort("");
				$this->field5type->setSort("");
				$this->field5mandatory->setSort("");
				$this->field5display->setSort("");
				$this->field5displaysequence->setSort("");
				$this->field5domain->setSort("");
				$this->field6label->setSort("");
				$this->field6type->setSort("");
				$this->field6mandatory->setSort("");
				$this->field6display->setSort("");
				$this->field6displaysequence->setSort("");
				$this->field6domain->setSort("");
				$this->field7label->setSort("");
				$this->field7type->setSort("");
				$this->field7mandatory->setSort("");
				$this->field7display->setSort("");
				$this->field7displaysequence->setSort("");
				$this->field7domain->setSort("");
				$this->field8label->setSort("");
				$this->field8type->setSort("");
				$this->field8mandatory->setSort("");
				$this->field8display->setSort("");
				$this->field8displaysequence->setSort("");
				$this->field8domain->setSort("");
				$this->field9label->setSort("");
				$this->field9type->setSort("");
				$this->field9mandatory->setSort("");
				$this->field9display->setSort("");
				$this->field9displaysequence->setSort("");
				$this->field9domain->setSort("");
				$this->field10label->setSort("");
				$this->field10type->setSort("");
				$this->field10mandatory->setSort("");
				$this->field10display->setSort("");
				$this->field10displaysequence->setSort("");
				$this->field10domain->setSort("");
				$this->lastupdatedate->setSort("");
			}

			// Reset start position
			$this->StartRecord = 1;
			$this->setStartRecordNumber($this->StartRecord);
		}
	}

	// Set up list options
	protected function setupListOptions()
	{
		global $Security, $Language;

		// Add group option item
		$item = &$this->ListOptions->add($this->ListOptions->GroupOptionName);
		$item->Body = "";
		$item->OnLeft = FALSE;
		$item->Visible = FALSE;

		// "view"
		$item = &$this->ListOptions->add("view");
		$item->CssClass = "text-nowrap";
		$item->Visible = $Security->canView();
		$item->OnLeft = FALSE;

		// "edit"
		$item = &$this->ListOptions->add("edit");
		$item->CssClass = "text-nowrap";
		$item->Visible = $Security->canEdit();
		$item->OnLeft = FALSE;

		// "copy"
		$item = &$this->ListOptions->add("copy");
		$item->CssClass = "text-nowrap";
		$item->Visible = $Security->canAdd();
		$item->OnLeft = FALSE;

		// "delete"
		$item = &$this->ListOptions->add("delete");
		$item->CssClass = "text-nowrap";
		$item->Visible = $Security->canDelete();
		$item->OnLeft = FALSE;

		// List actions
		$item = &$this->ListOptions->add("listactions");
		$item->CssClass = "text-nowrap";
		$item->OnLeft = FALSE;
		$item->Visible = FALSE;
		$item->ShowInButtonGroup = FALSE;
		$item->ShowInDropDown = FALSE;

		// "checkbox"
		$item = &$this->ListOptions->add("checkbox");
		$item->Visible = FALSE;
		$item->OnLeft = FALSE;
		$item->Header = "<div class=\"custom-control custom-checkbox d-inline-block\"><input type=\"checkbox\" name=\"key\" id=\"key\" class=\"custom-control-input\" onclick=\"ew.selectAllKey(this);\"><label class=\"custom-control-label\" for=\"key\"></label></div>";
		$item->ShowInDropDown = FALSE;
		$item->ShowInButtonGroup = FALSE;

		// Drop down button for ListOptions
		$this->ListOptions->UseDropDownButton = FALSE;
		$this->ListOptions->DropDownButtonPhrase = $Language->phrase("ButtonListOptions");
		$this->ListOptions->UseButtonGroup = FALSE;
		if ($this->ListOptions->UseButtonGroup && IsMobile())
			$this->ListOptions->UseDropDownButton = TRUE;

		//$this->ListOptions->ButtonClass = ""; // Class for button group
		// Call ListOptions_Load event

		$this->ListOptions_Load();
		$this->setupListOptionsExt();
		$item = $this->ListOptions[$this->ListOptions->GroupOptionName];
		$item->Visible = $this->ListOptions->groupOptionVisible();
	}

	// Render list options
	public function renderListOptions()
	{
		global $Security, $Language, $CurrentForm;
		$this->ListOptions->loadDefault();

		// Call ListOptions_Rendering event
		$this->ListOptions_Rendering();

		// "view"
		$opt = $this->ListOptions["view"];
		$viewcaption = HtmlTitle($Language->phrase("ViewLink"));
		if ($Security->canView()) {
			$opt->Body = "<a class=\"ew-row-link ew-view\" title=\"" . $viewcaption . "\" data-caption=\"" . $viewcaption . "\" href=\"" . HtmlEncode($this->ViewUrl) . "\">" . $Language->phrase("ViewLink") . "</a>";
		} else {
			$opt->Body = "";
		}

		// "edit"
		$opt = $this->ListOptions["edit"];
		$editcaption = HtmlTitle($Language->phrase("EditLink"));
		if ($Security->canEdit()) {
			$opt->Body = "<a class=\"ew-row-link ew-edit\" title=\"" . HtmlTitle($Language->phrase("EditLink")) . "\" data-caption=\"" . HtmlTitle($Language->phrase("EditLink")) . "\" href=\"" . HtmlEncode($this->EditUrl) . "\">" . $Language->phrase("EditLink") . "</a>";
		} else {
			$opt->Body = "";
		}

		// "copy"
		$opt = $this->ListOptions["copy"];
		$copycaption = HtmlTitle($Language->phrase("CopyLink"));
		if ($Security->canAdd()) {
			$opt->Body = "<a class=\"ew-row-link ew-copy\" title=\"" . $copycaption . "\" data-caption=\"" . $copycaption . "\" href=\"" . HtmlEncode($this->CopyUrl) . "\">" . $Language->phrase("CopyLink") . "</a>";
		} else {
			$opt->Body = "";
		}

		// "delete"
		$opt = $this->ListOptions["delete"];
		if ($Security->canDelete())
			$opt->Body = "<a class=\"ew-row-link ew-delete\"" . "" . " title=\"" . HtmlTitle($Language->phrase("DeleteLink")) . "\" data-caption=\"" . HtmlTitle($Language->phrase("DeleteLink")) . "\" href=\"" . HtmlEncode($this->DeleteUrl) . "\">" . $Language->phrase("DeleteLink") . "</a>";
		else
			$opt->Body = "";

		// Set up list action buttons
		$opt = $this->ListOptions["listactions"];
		if ($opt && !$this->isExport() && !$this->CurrentAction) {
			$body = "";
			$links = [];
			foreach ($this->ListActions->Items as $listaction) {
				if ($listaction->Select == ACTION_SINGLE && $listaction->Allow) {
					$action = $listaction->Action;
					$caption = $listaction->Caption;
					$icon = ($listaction->Icon != "") ? "<i class=\"" . HtmlEncode(str_replace(" ew-icon", "", $listaction->Icon)) . "\" data-caption=\"" . HtmlTitle($caption) . "\"></i> " : "";
					$links[] = "<li><a class=\"dropdown-item ew-action ew-list-action\" data-action=\"" . HtmlEncode($action) . "\" data-caption=\"" . HtmlTitle($caption) . "\" href=\"#\" onclick=\"return ew.submitAction(event,jQuery.extend({key:" . $this->keyToJson(TRUE) . "}," . $listaction->toJson(TRUE) . "));\">" . $icon . $listaction->Caption . "</a></li>";
					if (count($links) == 1) // Single button
						$body = "<a class=\"ew-action ew-list-action\" data-action=\"" . HtmlEncode($action) . "\" title=\"" . HtmlTitle($caption) . "\" data-caption=\"" . HtmlTitle($caption) . "\" href=\"#\" onclick=\"return ew.submitAction(event,jQuery.extend({key:" . $this->keyToJson(TRUE) . "}," . $listaction->toJson(TRUE) . "));\">" . $icon . $listaction->Caption . "</a>";
				}
			}
			if (count($links) > 1) { // More than one buttons, use dropdown
				$body = "<button class=\"dropdown-toggle btn btn-default ew-actions\" title=\"" . HtmlTitle($Language->phrase("ListActionButton")) . "\" data-toggle=\"dropdown\">" . $Language->phrase("ListActionButton") . "</button>";
				$content = "";
				foreach ($links as $link)
					$content .= "<li>" . $link . "</li>";
				$body .= "<ul class=\"dropdown-menu" . ($opt->OnLeft ? "" : " dropdown-menu-right") . "\">". $content . "</ul>";
				$body = "<div class=\"btn-group btn-group-sm\">" . $body . "</div>";
			}
			if (count($links) > 0) {
				$opt->Body = $body;
				$opt->Visible = TRUE;
			}
		}

		// "checkbox"
		$opt = $this->ListOptions["checkbox"];
		$opt->Body = "<div class=\"custom-control custom-checkbox d-inline-block\"><input type=\"checkbox\" id=\"key_m_" . $this->RowCount . "\" name=\"key_m[]\" class=\"custom-control-input ew-multi-select\" value=\"" . HtmlEncode($this->extrafieldsid->CurrentValue) . "\" onclick=\"ew.clickMultiCheckbox(event);\"><label class=\"custom-control-label\" for=\"key_m_" . $this->RowCount . "\"></label></div>";
		$this->renderListOptionsExt();

		// Call ListOptions_Rendered event
		$this->ListOptions_Rendered();
	}

	// Set up other options
	protected function setupOtherOptions()
	{
		global $Language, $Security;
		$options = &$this->OtherOptions;
		$option = $options["addedit"];

		// Add
		$item = &$option->add("add");
		$addcaption = HtmlTitle($Language->phrase("AddLink"));
		$item->Body = "<a class=\"ew-add-edit ew-add\" title=\"" . $addcaption . "\" data-caption=\"" . $addcaption . "\" href=\"" . HtmlEncode($this->AddUrl) . "\">" . $Language->phrase("AddLink") . "</a>";
		$item->Visible = $this->AddUrl != "" && $Security->canAdd();
		$option = $options["action"];

		// Set up options default
		foreach ($options as $option) {
			$option->UseDropDownButton = FALSE;
			$option->UseButtonGroup = TRUE;

			//$option->ButtonClass = ""; // Class for button group
			$item = &$option->add($option->GroupOptionName);
			$item->Body = "";
			$item->Visible = FALSE;
		}
		$options["addedit"]->DropDownButtonPhrase = $Language->phrase("ButtonAddEdit");
		$options["detail"]->DropDownButtonPhrase = $Language->phrase("ButtonDetails");
		$options["action"]->DropDownButtonPhrase = $Language->phrase("ButtonActions");

		// Filter button
		$item = &$this->FilterOptions->add("savecurrentfilter");
		$item->Body = "<a class=\"ew-save-filter\" data-form=\"fextrafieldstemplatelistsrch\" href=\"#\" onclick=\"return false;\">" . $Language->phrase("SaveCurrentFilter") . "</a>";
		$item->Visible = TRUE;
		$item = &$this->FilterOptions->add("deletefilter");
		$item->Body = "<a class=\"ew-delete-filter\" data-form=\"fextrafieldstemplatelistsrch\" href=\"#\" onclick=\"return false;\">" . $Language->phrase("DeleteFilter") . "</a>";
		$item->Visible = TRUE;
		$this->FilterOptions->UseDropDownButton = TRUE;
		$this->FilterOptions->UseButtonGroup = !$this->FilterOptions->UseDropDownButton;
		$this->FilterOptions->DropDownButtonPhrase = $Language->phrase("Filters");

		// Add group option item
		$item = &$this->FilterOptions->add($this->FilterOptions->GroupOptionName);
		$item->Body = "";
		$item->Visible = FALSE;
	}

	// Render other options
	public function renderOtherOptions()
	{
		global $Language, $Security;
		$options = &$this->OtherOptions;
			$option = $options["action"];

			// Set up list action buttons
			foreach ($this->ListActions->Items as $listaction) {
				if ($listaction->Select == ACTION_MULTIPLE) {
					$item = &$option->add("custom_" . $listaction->Action);
					$caption = $listaction->Caption;
					$icon = ($listaction->Icon != "") ? "<i class=\"" . HtmlEncode($listaction->Icon) . "\" data-caption=\"" . HtmlEncode($caption) . "\"></i> " . $caption : $caption;
					$item->Body = "<a class=\"ew-action ew-list-action\" title=\"" . HtmlEncode($caption) . "\" data-caption=\"" . HtmlEncode($caption) . "\" href=\"#\" onclick=\"return ew.submitAction(event,jQuery.extend({f:document.fextrafieldstemplatelist}," . $listaction->toJson(TRUE) . "));\">" . $icon . "</a>";
					$item->Visible = $listaction->Allow;
				}
			}

			// Hide grid edit and other options
			if ($this->TotalRecords <= 0) {
				$option = $options["addedit"];
				$item = $option["gridedit"];
				if ($item)
					$item->Visible = FALSE;
				$option = $options["action"];
				$option->hideAllOptions();
			}
	}

	// Process list action
	protected function processListAction()
	{
		global $Language, $Security;
		$userlist = "";
		$user = "";
		$filter = $this->getFilterFromRecordKeys();
		$userAction = Post("useraction", "");
		if ($filter != "" && $userAction != "") {

			// Check permission first
			$actionCaption = $userAction;
			if (array_key_exists($userAction, $this->ListActions->Items)) {
				$actionCaption = $this->ListActions[$userAction]->Caption;
				if (!$this->ListActions[$userAction]->Allow) {
					$errmsg = str_replace('%s', $actionCaption, $Language->phrase("CustomActionNotAllowed"));
					if (Post("ajax") == $userAction) // Ajax
						echo "<p class=\"text-danger\">" . $errmsg . "</p>";
					else
						$this->setFailureMessage($errmsg);
					return FALSE;
				}
			}
			$this->CurrentFilter = $filter;
			$sql = $this->getCurrentSql();
			$conn = $this->getConnection();
			$conn->raiseErrorFn = Config("ERROR_FUNC");
			$rs = $conn->execute($sql);
			$conn->raiseErrorFn = "";
			$this->CurrentAction = $userAction;

			// Call row action event
			if ($rs && !$rs->EOF) {
				$conn->beginTrans();
				$this->SelectedCount = $rs->RecordCount();
				$this->SelectedIndex = 0;
				while (!$rs->EOF) {
					$this->SelectedIndex++;
					$row = $rs->fields;
					$processed = $this->Row_CustomAction($userAction, $row);
					if (!$processed)
						break;
					$rs->moveNext();
				}
				if ($processed) {
					$conn->commitTrans(); // Commit the changes
					if ($this->getSuccessMessage() == "" && !ob_get_length()) // No output
						$this->setSuccessMessage(str_replace('%s', $actionCaption, $Language->phrase("CustomActionCompleted"))); // Set up success message
				} else {
					$conn->rollbackTrans(); // Rollback changes

					// Set up error message
					if ($this->getSuccessMessage() != "" || $this->getFailureMessage() != "") {

						// Use the message, do nothing
					} elseif ($this->CancelMessage != "") {
						$this->setFailureMessage($this->CancelMessage);
						$this->CancelMessage = "";
					} else {
						$this->setFailureMessage(str_replace('%s', $actionCaption, $Language->phrase("CustomActionFailed")));
					}
				}
			}
			if ($rs)
				$rs->close();
			$this->CurrentAction = ""; // Clear action
			if (Post("ajax") == $userAction) { // Ajax
				if ($this->getSuccessMessage() != "") {
					echo "<p class=\"text-success\">" . $this->getSuccessMessage() . "</p>";
					$this->clearSuccessMessage(); // Clear message
				}
				if ($this->getFailureMessage() != "") {
					echo "<p class=\"text-danger\">" . $this->getFailureMessage() . "</p>";
					$this->clearFailureMessage(); // Clear message
				}
				return TRUE;
			}
		}
		return FALSE; // Not ajax request
	}

// Set up list options (extended codes)
	protected function setupListOptionsExt()
	{

		// Hide detail items for dropdown if necessary
		$this->ListOptions->hideDetailItemsForDropDown();
	}

// Render list options (extended codes)
	protected function renderListOptionsExt()
	{
		global $Security, $Language;
	}

	// Load basic search values
	protected function loadBasicSearchValues()
	{
		$this->BasicSearch->setKeyword(Get(Config("TABLE_BASIC_SEARCH"), ""), FALSE);
		if ($this->BasicSearch->Keyword != "" && $this->Command == "")
			$this->Command = "search";
		$this->BasicSearch->setType(Get(Config("TABLE_BASIC_SEARCH_TYPE"), ""), FALSE);
	}

	// Load search values for validation
	protected function loadSearchValues()
	{

		// Load search values
		$got = FALSE;

		// extrafieldsid
		if (!$this->isAddOrEdit() && $this->extrafieldsid->AdvancedSearch->get()) {
			$got = TRUE;
			if (($this->extrafieldsid->AdvancedSearch->SearchValue != "" || $this->extrafieldsid->AdvancedSearch->SearchValue2 != "") && $this->Command == "")
				$this->Command = "search";
		}

		// merchantid
		if (!$this->isAddOrEdit() && $this->merchantid->AdvancedSearch->get()) {
			$got = TRUE;
			if (($this->merchantid->AdvancedSearch->SearchValue != "" || $this->merchantid->AdvancedSearch->SearchValue2 != "") && $this->Command == "")
				$this->Command = "search";
		}

		// name
		if (!$this->isAddOrEdit() && $this->name->AdvancedSearch->get()) {
			$got = TRUE;
			if (($this->name->AdvancedSearch->SearchValue != "" || $this->name->AdvancedSearch->SearchValue2 != "") && $this->Command == "")
				$this->Command = "search";
		}

		// field1label
		if (!$this->isAddOrEdit() && $this->field1label->AdvancedSearch->get()) {
			$got = TRUE;
			if (($this->field1label->AdvancedSearch->SearchValue != "" || $this->field1label->AdvancedSearch->SearchValue2 != "") && $this->Command == "")
				$this->Command = "search";
		}

		// field1type
		if (!$this->isAddOrEdit() && $this->field1type->AdvancedSearch->get()) {
			$got = TRUE;
			if (($this->field1type->AdvancedSearch->SearchValue != "" || $this->field1type->AdvancedSearch->SearchValue2 != "") && $this->Command == "")
				$this->Command = "search";
		}

		// field1mandatory
		if (!$this->isAddOrEdit() && $this->field1mandatory->AdvancedSearch->get()) {
			$got = TRUE;
			if (($this->field1mandatory->AdvancedSearch->SearchValue != "" || $this->field1mandatory->AdvancedSearch->SearchValue2 != "") && $this->Command == "")
				$this->Command = "search";
		}

		// field1display
		if (!$this->isAddOrEdit() && $this->field1display->AdvancedSearch->get()) {
			$got = TRUE;
			if (($this->field1display->AdvancedSearch->SearchValue != "" || $this->field1display->AdvancedSearch->SearchValue2 != "") && $this->Command == "")
				$this->Command = "search";
		}

		// field1displaysequence
		if (!$this->isAddOrEdit() && $this->field1displaysequence->AdvancedSearch->get()) {
			$got = TRUE;
			if (($this->field1displaysequence->AdvancedSearch->SearchValue != "" || $this->field1displaysequence->AdvancedSearch->SearchValue2 != "") && $this->Command == "")
				$this->Command = "search";
		}

		// field1domain
		if (!$this->isAddOrEdit() && $this->field1domain->AdvancedSearch->get()) {
			$got = TRUE;
			if (($this->field1domain->AdvancedSearch->SearchValue != "" || $this->field1domain->AdvancedSearch->SearchValue2 != "") && $this->Command == "")
				$this->Command = "search";
		}

		// field2label
		if (!$this->isAddOrEdit() && $this->field2label->AdvancedSearch->get()) {
			$got = TRUE;
			if (($this->field2label->AdvancedSearch->SearchValue != "" || $this->field2label->AdvancedSearch->SearchValue2 != "") && $this->Command == "")
				$this->Command = "search";
		}

		// field2type
		if (!$this->isAddOrEdit() && $this->field2type->AdvancedSearch->get()) {
			$got = TRUE;
			if (($this->field2type->AdvancedSearch->SearchValue != "" || $this->field2type->AdvancedSearch->SearchValue2 != "") && $this->Command == "")
				$this->Command = "search";
		}

		// field2mandatory
		if (!$this->isAddOrEdit() && $this->field2mandatory->AdvancedSearch->get()) {
			$got = TRUE;
			if (($this->field2mandatory->AdvancedSearch->SearchValue != "" || $this->field2mandatory->AdvancedSearch->SearchValue2 != "") && $this->Command == "")
				$this->Command = "search";
		}

		// field2display
		if (!$this->isAddOrEdit() && $this->field2display->AdvancedSearch->get()) {
			$got = TRUE;
			if (($this->field2display->AdvancedSearch->SearchValue != "" || $this->field2display->AdvancedSearch->SearchValue2 != "") && $this->Command == "")
				$this->Command = "search";
		}

		// field2displaysequence
		if (!$this->isAddOrEdit() && $this->field2displaysequence->AdvancedSearch->get()) {
			$got = TRUE;
			if (($this->field2displaysequence->AdvancedSearch->SearchValue != "" || $this->field2displaysequence->AdvancedSearch->SearchValue2 != "") && $this->Command == "")
				$this->Command = "search";
		}

		// field2domain
		if (!$this->isAddOrEdit() && $this->field2domain->AdvancedSearch->get()) {
			$got = TRUE;
			if (($this->field2domain->AdvancedSearch->SearchValue != "" || $this->field2domain->AdvancedSearch->SearchValue2 != "") && $this->Command == "")
				$this->Command = "search";
		}

		// field3label
		if (!$this->isAddOrEdit() && $this->field3label->AdvancedSearch->get()) {
			$got = TRUE;
			if (($this->field3label->AdvancedSearch->SearchValue != "" || $this->field3label->AdvancedSearch->SearchValue2 != "") && $this->Command == "")
				$this->Command = "search";
		}

		// field3type
		if (!$this->isAddOrEdit() && $this->field3type->AdvancedSearch->get()) {
			$got = TRUE;
			if (($this->field3type->AdvancedSearch->SearchValue != "" || $this->field3type->AdvancedSearch->SearchValue2 != "") && $this->Command == "")
				$this->Command = "search";
		}

		// field3mandatory
		if (!$this->isAddOrEdit() && $this->field3mandatory->AdvancedSearch->get()) {
			$got = TRUE;
			if (($this->field3mandatory->AdvancedSearch->SearchValue != "" || $this->field3mandatory->AdvancedSearch->SearchValue2 != "") && $this->Command == "")
				$this->Command = "search";
		}

		// field3display
		if (!$this->isAddOrEdit() && $this->field3display->AdvancedSearch->get()) {
			$got = TRUE;
			if (($this->field3display->AdvancedSearch->SearchValue != "" || $this->field3display->AdvancedSearch->SearchValue2 != "") && $this->Command == "")
				$this->Command = "search";
		}

		// field3displaysequence
		if (!$this->isAddOrEdit() && $this->field3displaysequence->AdvancedSearch->get()) {
			$got = TRUE;
			if (($this->field3displaysequence->AdvancedSearch->SearchValue != "" || $this->field3displaysequence->AdvancedSearch->SearchValue2 != "") && $this->Command == "")
				$this->Command = "search";
		}

		// field3domain
		if (!$this->isAddOrEdit() && $this->field3domain->AdvancedSearch->get()) {
			$got = TRUE;
			if (($this->field3domain->AdvancedSearch->SearchValue != "" || $this->field3domain->AdvancedSearch->SearchValue2 != "") && $this->Command == "")
				$this->Command = "search";
		}

		// field4label
		if (!$this->isAddOrEdit() && $this->field4label->AdvancedSearch->get()) {
			$got = TRUE;
			if (($this->field4label->AdvancedSearch->SearchValue != "" || $this->field4label->AdvancedSearch->SearchValue2 != "") && $this->Command == "")
				$this->Command = "search";
		}

		// field4type
		if (!$this->isAddOrEdit() && $this->field4type->AdvancedSearch->get()) {
			$got = TRUE;
			if (($this->field4type->AdvancedSearch->SearchValue != "" || $this->field4type->AdvancedSearch->SearchValue2 != "") && $this->Command == "")
				$this->Command = "search";
		}

		// field4mandatory
		if (!$this->isAddOrEdit() && $this->field4mandatory->AdvancedSearch->get()) {
			$got = TRUE;
			if (($this->field4mandatory->AdvancedSearch->SearchValue != "" || $this->field4mandatory->AdvancedSearch->SearchValue2 != "") && $this->Command == "")
				$this->Command = "search";
		}

		// field4display
		if (!$this->isAddOrEdit() && $this->field4display->AdvancedSearch->get()) {
			$got = TRUE;
			if (($this->field4display->AdvancedSearch->SearchValue != "" || $this->field4display->AdvancedSearch->SearchValue2 != "") && $this->Command == "")
				$this->Command = "search";
		}

		// field4displaysequence
		if (!$this->isAddOrEdit() && $this->field4displaysequence->AdvancedSearch->get()) {
			$got = TRUE;
			if (($this->field4displaysequence->AdvancedSearch->SearchValue != "" || $this->field4displaysequence->AdvancedSearch->SearchValue2 != "") && $this->Command == "")
				$this->Command = "search";
		}

		// field4domain
		if (!$this->isAddOrEdit() && $this->field4domain->AdvancedSearch->get()) {
			$got = TRUE;
			if (($this->field4domain->AdvancedSearch->SearchValue != "" || $this->field4domain->AdvancedSearch->SearchValue2 != "") && $this->Command == "")
				$this->Command = "search";
		}

		// field5label
		if (!$this->isAddOrEdit() && $this->field5label->AdvancedSearch->get()) {
			$got = TRUE;
			if (($this->field5label->AdvancedSearch->SearchValue != "" || $this->field5label->AdvancedSearch->SearchValue2 != "") && $this->Command == "")
				$this->Command = "search";
		}

		// field5type
		if (!$this->isAddOrEdit() && $this->field5type->AdvancedSearch->get()) {
			$got = TRUE;
			if (($this->field5type->AdvancedSearch->SearchValue != "" || $this->field5type->AdvancedSearch->SearchValue2 != "") && $this->Command == "")
				$this->Command = "search";
		}

		// field5mandatory
		if (!$this->isAddOrEdit() && $this->field5mandatory->AdvancedSearch->get()) {
			$got = TRUE;
			if (($this->field5mandatory->AdvancedSearch->SearchValue != "" || $this->field5mandatory->AdvancedSearch->SearchValue2 != "") && $this->Command == "")
				$this->Command = "search";
		}

		// field5display
		if (!$this->isAddOrEdit() && $this->field5display->AdvancedSearch->get()) {
			$got = TRUE;
			if (($this->field5display->AdvancedSearch->SearchValue != "" || $this->field5display->AdvancedSearch->SearchValue2 != "") && $this->Command == "")
				$this->Command = "search";
		}

		// field5displaysequence
		if (!$this->isAddOrEdit() && $this->field5displaysequence->AdvancedSearch->get()) {
			$got = TRUE;
			if (($this->field5displaysequence->AdvancedSearch->SearchValue != "" || $this->field5displaysequence->AdvancedSearch->SearchValue2 != "") && $this->Command == "")
				$this->Command = "search";
		}

		// field5domain
		if (!$this->isAddOrEdit() && $this->field5domain->AdvancedSearch->get()) {
			$got = TRUE;
			if (($this->field5domain->AdvancedSearch->SearchValue != "" || $this->field5domain->AdvancedSearch->SearchValue2 != "") && $this->Command == "")
				$this->Command = "search";
		}

		// field6label
		if (!$this->isAddOrEdit() && $this->field6label->AdvancedSearch->get()) {
			$got = TRUE;
			if (($this->field6label->AdvancedSearch->SearchValue != "" || $this->field6label->AdvancedSearch->SearchValue2 != "") && $this->Command == "")
				$this->Command = "search";
		}

		// field6type
		if (!$this->isAddOrEdit() && $this->field6type->AdvancedSearch->get()) {
			$got = TRUE;
			if (($this->field6type->AdvancedSearch->SearchValue != "" || $this->field6type->AdvancedSearch->SearchValue2 != "") && $this->Command == "")
				$this->Command = "search";
		}

		// field6mandatory
		if (!$this->isAddOrEdit() && $this->field6mandatory->AdvancedSearch->get()) {
			$got = TRUE;
			if (($this->field6mandatory->AdvancedSearch->SearchValue != "" || $this->field6mandatory->AdvancedSearch->SearchValue2 != "") && $this->Command == "")
				$this->Command = "search";
		}

		// field6display
		if (!$this->isAddOrEdit() && $this->field6display->AdvancedSearch->get()) {
			$got = TRUE;
			if (($this->field6display->AdvancedSearch->SearchValue != "" || $this->field6display->AdvancedSearch->SearchValue2 != "") && $this->Command == "")
				$this->Command = "search";
		}

		// field6displaysequence
		if (!$this->isAddOrEdit() && $this->field6displaysequence->AdvancedSearch->get()) {
			$got = TRUE;
			if (($this->field6displaysequence->AdvancedSearch->SearchValue != "" || $this->field6displaysequence->AdvancedSearch->SearchValue2 != "") && $this->Command == "")
				$this->Command = "search";
		}

		// field6domain
		if (!$this->isAddOrEdit() && $this->field6domain->AdvancedSearch->get()) {
			$got = TRUE;
			if (($this->field6domain->AdvancedSearch->SearchValue != "" || $this->field6domain->AdvancedSearch->SearchValue2 != "") && $this->Command == "")
				$this->Command = "search";
		}

		// field7label
		if (!$this->isAddOrEdit() && $this->field7label->AdvancedSearch->get()) {
			$got = TRUE;
			if (($this->field7label->AdvancedSearch->SearchValue != "" || $this->field7label->AdvancedSearch->SearchValue2 != "") && $this->Command == "")
				$this->Command = "search";
		}

		// field7type
		if (!$this->isAddOrEdit() && $this->field7type->AdvancedSearch->get()) {
			$got = TRUE;
			if (($this->field7type->AdvancedSearch->SearchValue != "" || $this->field7type->AdvancedSearch->SearchValue2 != "") && $this->Command == "")
				$this->Command = "search";
		}

		// field7mandatory
		if (!$this->isAddOrEdit() && $this->field7mandatory->AdvancedSearch->get()) {
			$got = TRUE;
			if (($this->field7mandatory->AdvancedSearch->SearchValue != "" || $this->field7mandatory->AdvancedSearch->SearchValue2 != "") && $this->Command == "")
				$this->Command = "search";
		}

		// field7display
		if (!$this->isAddOrEdit() && $this->field7display->AdvancedSearch->get()) {
			$got = TRUE;
			if (($this->field7display->AdvancedSearch->SearchValue != "" || $this->field7display->AdvancedSearch->SearchValue2 != "") && $this->Command == "")
				$this->Command = "search";
		}

		// field7displaysequence
		if (!$this->isAddOrEdit() && $this->field7displaysequence->AdvancedSearch->get()) {
			$got = TRUE;
			if (($this->field7displaysequence->AdvancedSearch->SearchValue != "" || $this->field7displaysequence->AdvancedSearch->SearchValue2 != "") && $this->Command == "")
				$this->Command = "search";
		}

		// field7domain
		if (!$this->isAddOrEdit() && $this->field7domain->AdvancedSearch->get()) {
			$got = TRUE;
			if (($this->field7domain->AdvancedSearch->SearchValue != "" || $this->field7domain->AdvancedSearch->SearchValue2 != "") && $this->Command == "")
				$this->Command = "search";
		}

		// field8label
		if (!$this->isAddOrEdit() && $this->field8label->AdvancedSearch->get()) {
			$got = TRUE;
			if (($this->field8label->AdvancedSearch->SearchValue != "" || $this->field8label->AdvancedSearch->SearchValue2 != "") && $this->Command == "")
				$this->Command = "search";
		}

		// field8type
		if (!$this->isAddOrEdit() && $this->field8type->AdvancedSearch->get()) {
			$got = TRUE;
			if (($this->field8type->AdvancedSearch->SearchValue != "" || $this->field8type->AdvancedSearch->SearchValue2 != "") && $this->Command == "")
				$this->Command = "search";
		}

		// field8mandatory
		if (!$this->isAddOrEdit() && $this->field8mandatory->AdvancedSearch->get()) {
			$got = TRUE;
			if (($this->field8mandatory->AdvancedSearch->SearchValue != "" || $this->field8mandatory->AdvancedSearch->SearchValue2 != "") && $this->Command == "")
				$this->Command = "search";
		}

		// field8display
		if (!$this->isAddOrEdit() && $this->field8display->AdvancedSearch->get()) {
			$got = TRUE;
			if (($this->field8display->AdvancedSearch->SearchValue != "" || $this->field8display->AdvancedSearch->SearchValue2 != "") && $this->Command == "")
				$this->Command = "search";
		}

		// field8displaysequence
		if (!$this->isAddOrEdit() && $this->field8displaysequence->AdvancedSearch->get()) {
			$got = TRUE;
			if (($this->field8displaysequence->AdvancedSearch->SearchValue != "" || $this->field8displaysequence->AdvancedSearch->SearchValue2 != "") && $this->Command == "")
				$this->Command = "search";
		}

		// field8domain
		if (!$this->isAddOrEdit() && $this->field8domain->AdvancedSearch->get()) {
			$got = TRUE;
			if (($this->field8domain->AdvancedSearch->SearchValue != "" || $this->field8domain->AdvancedSearch->SearchValue2 != "") && $this->Command == "")
				$this->Command = "search";
		}

		// field9label
		if (!$this->isAddOrEdit() && $this->field9label->AdvancedSearch->get()) {
			$got = TRUE;
			if (($this->field9label->AdvancedSearch->SearchValue != "" || $this->field9label->AdvancedSearch->SearchValue2 != "") && $this->Command == "")
				$this->Command = "search";
		}

		// field9type
		if (!$this->isAddOrEdit() && $this->field9type->AdvancedSearch->get()) {
			$got = TRUE;
			if (($this->field9type->AdvancedSearch->SearchValue != "" || $this->field9type->AdvancedSearch->SearchValue2 != "") && $this->Command == "")
				$this->Command = "search";
		}

		// field9mandatory
		if (!$this->isAddOrEdit() && $this->field9mandatory->AdvancedSearch->get()) {
			$got = TRUE;
			if (($this->field9mandatory->AdvancedSearch->SearchValue != "" || $this->field9mandatory->AdvancedSearch->SearchValue2 != "") && $this->Command == "")
				$this->Command = "search";
		}

		// field9display
		if (!$this->isAddOrEdit() && $this->field9display->AdvancedSearch->get()) {
			$got = TRUE;
			if (($this->field9display->AdvancedSearch->SearchValue != "" || $this->field9display->AdvancedSearch->SearchValue2 != "") && $this->Command == "")
				$this->Command = "search";
		}

		// field9displaysequence
		if (!$this->isAddOrEdit() && $this->field9displaysequence->AdvancedSearch->get()) {
			$got = TRUE;
			if (($this->field9displaysequence->AdvancedSearch->SearchValue != "" || $this->field9displaysequence->AdvancedSearch->SearchValue2 != "") && $this->Command == "")
				$this->Command = "search";
		}

		// field9domain
		if (!$this->isAddOrEdit() && $this->field9domain->AdvancedSearch->get()) {
			$got = TRUE;
			if (($this->field9domain->AdvancedSearch->SearchValue != "" || $this->field9domain->AdvancedSearch->SearchValue2 != "") && $this->Command == "")
				$this->Command = "search";
		}

		// field10label
		if (!$this->isAddOrEdit() && $this->field10label->AdvancedSearch->get()) {
			$got = TRUE;
			if (($this->field10label->AdvancedSearch->SearchValue != "" || $this->field10label->AdvancedSearch->SearchValue2 != "") && $this->Command == "")
				$this->Command = "search";
		}

		// field10type
		if (!$this->isAddOrEdit() && $this->field10type->AdvancedSearch->get()) {
			$got = TRUE;
			if (($this->field10type->AdvancedSearch->SearchValue != "" || $this->field10type->AdvancedSearch->SearchValue2 != "") && $this->Command == "")
				$this->Command = "search";
		}

		// field10mandatory
		if (!$this->isAddOrEdit() && $this->field10mandatory->AdvancedSearch->get()) {
			$got = TRUE;
			if (($this->field10mandatory->AdvancedSearch->SearchValue != "" || $this->field10mandatory->AdvancedSearch->SearchValue2 != "") && $this->Command == "")
				$this->Command = "search";
		}

		// field10display
		if (!$this->isAddOrEdit() && $this->field10display->AdvancedSearch->get()) {
			$got = TRUE;
			if (($this->field10display->AdvancedSearch->SearchValue != "" || $this->field10display->AdvancedSearch->SearchValue2 != "") && $this->Command == "")
				$this->Command = "search";
		}

		// field10displaysequence
		if (!$this->isAddOrEdit() && $this->field10displaysequence->AdvancedSearch->get()) {
			$got = TRUE;
			if (($this->field10displaysequence->AdvancedSearch->SearchValue != "" || $this->field10displaysequence->AdvancedSearch->SearchValue2 != "") && $this->Command == "")
				$this->Command = "search";
		}

		// field10domain
		if (!$this->isAddOrEdit() && $this->field10domain->AdvancedSearch->get()) {
			$got = TRUE;
			if (($this->field10domain->AdvancedSearch->SearchValue != "" || $this->field10domain->AdvancedSearch->SearchValue2 != "") && $this->Command == "")
				$this->Command = "search";
		}

		// lastupdatedate
		if (!$this->isAddOrEdit() && $this->lastupdatedate->AdvancedSearch->get()) {
			$got = TRUE;
			if (($this->lastupdatedate->AdvancedSearch->SearchValue != "" || $this->lastupdatedate->AdvancedSearch->SearchValue2 != "") && $this->Command == "")
				$this->Command = "search";
		}
		return $got;
	}

	// Load recordset
	public function loadRecordset($offset = -1, $rowcnt = -1)
	{

		// Load List page SQL
		$sql = $this->getListSql();
		$conn = $this->getConnection();

		// Load recordset
		$dbtype = GetConnectionType($this->Dbid);
		if ($this->UseSelectLimit) {
			$conn->raiseErrorFn = Config("ERROR_FUNC");
			if ($dbtype == "MSSQL") {
				$rs = $conn->selectLimit($sql, $rowcnt, $offset, ["_hasOrderBy" => trim($this->getOrderBy()) || trim($this->getSessionOrderBy())]);
			} else {
				$rs = $conn->selectLimit($sql, $rowcnt, $offset);
			}
			$conn->raiseErrorFn = "";
		} else {
			$rs = LoadRecordset($sql, $conn);
		}

		// Call Recordset Selected event
		$this->Recordset_Selected($rs);
		return $rs;
	}

	// Load row based on key values
	public function loadRow()
	{
		global $Security, $Language;
		$filter = $this->getRecordFilter();

		// Call Row Selecting event
		$this->Row_Selecting($filter);

		// Load SQL based on filter
		$this->CurrentFilter = $filter;
		$sql = $this->getCurrentSql();
		$conn = $this->getConnection();
		$res = FALSE;
		$rs = LoadRecordset($sql, $conn);
		if ($rs && !$rs->EOF) {
			$res = TRUE;
			$this->loadRowValues($rs); // Load row values
			$rs->close();
		}
		return $res;
	}

	// Load row values from recordset
	public function loadRowValues($rs = NULL)
	{
		if ($rs && !$rs->EOF)
			$row = $rs->fields;
		else
			$row = $this->newRow();

		// Call Row Selected event
		$this->Row_Selected($row);
		if (!$rs || $rs->EOF)
			return;
		$this->extrafieldsid->setDbValue($row['extrafieldsid']);
		$this->merchantid->setDbValue($row['merchantid']);
		$this->name->setDbValue($row['name']);
		$this->field1label->setDbValue($row['field1label']);
		$this->field1type->setDbValue($row['field1type']);
		$this->field1mandatory->setDbValue($row['field1mandatory']);
		$this->field1display->setDbValue($row['field1display']);
		$this->field1displaysequence->setDbValue($row['field1displaysequence']);
		$this->field1domain->setDbValue($row['field1domain']);
		$this->field2label->setDbValue($row['field2label']);
		$this->field2type->setDbValue($row['field2type']);
		$this->field2mandatory->setDbValue($row['field2mandatory']);
		$this->field2display->setDbValue($row['field2display']);
		$this->field2displaysequence->setDbValue($row['field2displaysequence']);
		$this->field2domain->setDbValue($row['field2domain']);
		$this->field3label->setDbValue($row['field3label']);
		$this->field3type->setDbValue($row['field3type']);
		$this->field3mandatory->setDbValue($row['field3mandatory']);
		$this->field3display->setDbValue($row['field3display']);
		$this->field3displaysequence->setDbValue($row['field3displaysequence']);
		$this->field3domain->setDbValue($row['field3domain']);
		$this->field4label->setDbValue($row['field4label']);
		$this->field4type->setDbValue($row['field4type']);
		$this->field4mandatory->setDbValue($row['field4mandatory']);
		$this->field4display->setDbValue($row['field4display']);
		$this->field4displaysequence->setDbValue($row['field4displaysequence']);
		$this->field4domain->setDbValue($row['field4domain']);
		$this->field5label->setDbValue($row['field5label']);
		$this->field5type->setDbValue($row['field5type']);
		$this->field5mandatory->setDbValue($row['field5mandatory']);
		$this->field5display->setDbValue($row['field5display']);
		$this->field5displaysequence->setDbValue($row['field5displaysequence']);
		$this->field5domain->setDbValue($row['field5domain']);
		$this->field6label->setDbValue($row['field6label']);
		$this->field6type->setDbValue($row['field6type']);
		$this->field6mandatory->setDbValue($row['field6mandatory']);
		$this->field6display->setDbValue($row['field6display']);
		$this->field6displaysequence->setDbValue($row['field6displaysequence']);
		$this->field6domain->setDbValue($row['field6domain']);
		$this->field7label->setDbValue($row['field7label']);
		$this->field7type->setDbValue($row['field7type']);
		$this->field7mandatory->setDbValue($row['field7mandatory']);
		$this->field7display->setDbValue($row['field7display']);
		$this->field7displaysequence->setDbValue($row['field7displaysequence']);
		$this->field7domain->setDbValue($row['field7domain']);
		$this->field8label->setDbValue($row['field8label']);
		$this->field8type->setDbValue($row['field8type']);
		$this->field8mandatory->setDbValue($row['field8mandatory']);
		$this->field8display->setDbValue($row['field8display']);
		$this->field8displaysequence->setDbValue($row['field8displaysequence']);
		$this->field8domain->setDbValue($row['field8domain']);
		$this->field9label->setDbValue($row['field9label']);
		$this->field9type->setDbValue($row['field9type']);
		$this->field9mandatory->setDbValue($row['field9mandatory']);
		$this->field9display->setDbValue($row['field9display']);
		$this->field9displaysequence->setDbValue($row['field9displaysequence']);
		$this->field9domain->setDbValue($row['field9domain']);
		$this->field10label->setDbValue($row['field10label']);
		$this->field10type->setDbValue($row['field10type']);
		$this->field10mandatory->setDbValue($row['field10mandatory']);
		$this->field10display->setDbValue($row['field10display']);
		$this->field10displaysequence->setDbValue($row['field10displaysequence']);
		$this->field10domain->setDbValue($row['field10domain']);
		$this->lastupdatedate->setDbValue($row['lastupdatedate']);
	}

	// Return a row with default values
	protected function newRow()
	{
		$row = [];
		$row['extrafieldsid'] = NULL;
		$row['merchantid'] = NULL;
		$row['name'] = NULL;
		$row['field1label'] = NULL;
		$row['field1type'] = NULL;
		$row['field1mandatory'] = NULL;
		$row['field1display'] = NULL;
		$row['field1displaysequence'] = NULL;
		$row['field1domain'] = NULL;
		$row['field2label'] = NULL;
		$row['field2type'] = NULL;
		$row['field2mandatory'] = NULL;
		$row['field2display'] = NULL;
		$row['field2displaysequence'] = NULL;
		$row['field2domain'] = NULL;
		$row['field3label'] = NULL;
		$row['field3type'] = NULL;
		$row['field3mandatory'] = NULL;
		$row['field3display'] = NULL;
		$row['field3displaysequence'] = NULL;
		$row['field3domain'] = NULL;
		$row['field4label'] = NULL;
		$row['field4type'] = NULL;
		$row['field4mandatory'] = NULL;
		$row['field4display'] = NULL;
		$row['field4displaysequence'] = NULL;
		$row['field4domain'] = NULL;
		$row['field5label'] = NULL;
		$row['field5type'] = NULL;
		$row['field5mandatory'] = NULL;
		$row['field5display'] = NULL;
		$row['field5displaysequence'] = NULL;
		$row['field5domain'] = NULL;
		$row['field6label'] = NULL;
		$row['field6type'] = NULL;
		$row['field6mandatory'] = NULL;
		$row['field6display'] = NULL;
		$row['field6displaysequence'] = NULL;
		$row['field6domain'] = NULL;
		$row['field7label'] = NULL;
		$row['field7type'] = NULL;
		$row['field7mandatory'] = NULL;
		$row['field7display'] = NULL;
		$row['field7displaysequence'] = NULL;
		$row['field7domain'] = NULL;
		$row['field8label'] = NULL;
		$row['field8type'] = NULL;
		$row['field8mandatory'] = NULL;
		$row['field8display'] = NULL;
		$row['field8displaysequence'] = NULL;
		$row['field8domain'] = NULL;
		$row['field9label'] = NULL;
		$row['field9type'] = NULL;
		$row['field9mandatory'] = NULL;
		$row['field9display'] = NULL;
		$row['field9displaysequence'] = NULL;
		$row['field9domain'] = NULL;
		$row['field10label'] = NULL;
		$row['field10type'] = NULL;
		$row['field10mandatory'] = NULL;
		$row['field10display'] = NULL;
		$row['field10displaysequence'] = NULL;
		$row['field10domain'] = NULL;
		$row['lastupdatedate'] = NULL;
		return $row;
	}

	// Load old record
	protected function loadOldRecord()
	{

		// Load key values from Session
		$validKey = TRUE;
		if (strval($this->getKey("extrafieldsid")) != "")
			$this->extrafieldsid->OldValue = $this->getKey("extrafieldsid"); // extrafieldsid
		else
			$validKey = FALSE;

		// Load old record
		$this->OldRecordset = NULL;
		if ($validKey) {
			$this->CurrentFilter = $this->getRecordFilter();
			$sql = $this->getCurrentSql();
			$conn = $this->getConnection();
			$this->OldRecordset = LoadRecordset($sql, $conn);
		}
		$this->loadRowValues($this->OldRecordset); // Load row values
		return $validKey;
	}

	// Render row values based on field settings
	public function renderRow()
	{
		global $Security, $Language, $CurrentLanguage;

		// Initialize URLs
		$this->ViewUrl = $this->getViewUrl();
		$this->EditUrl = $this->getEditUrl();
		$this->InlineEditUrl = $this->getInlineEditUrl();
		$this->CopyUrl = $this->getCopyUrl();
		$this->InlineCopyUrl = $this->getInlineCopyUrl();
		$this->DeleteUrl = $this->getDeleteUrl();

		// Call Row_Rendering event
		$this->Row_Rendering();

		// Common render codes for all row types
		// extrafieldsid
		// merchantid
		// name
		// field1label
		// field1type
		// field1mandatory
		// field1display
		// field1displaysequence
		// field1domain
		// field2label
		// field2type
		// field2mandatory
		// field2display
		// field2displaysequence
		// field2domain
		// field3label
		// field3type
		// field3mandatory
		// field3display
		// field3displaysequence
		// field3domain
		// field4label
		// field4type
		// field4mandatory
		// field4display
		// field4displaysequence
		// field4domain
		// field5label
		// field5type
		// field5mandatory
		// field5display
		// field5displaysequence
		// field5domain
		// field6label
		// field6type
		// field6mandatory
		// field6display
		// field6displaysequence
		// field6domain
		// field7label
		// field7type
		// field7mandatory
		// field7display
		// field7displaysequence
		// field7domain
		// field8label
		// field8type
		// field8mandatory
		// field8display
		// field8displaysequence
		// field8domain
		// field9label
		// field9type
		// field9mandatory
		// field9display
		// field9displaysequence
		// field9domain
		// field10label
		// field10type
		// field10mandatory
		// field10display
		// field10displaysequence
		// field10domain
		// lastupdatedate

		if ($this->RowType == ROWTYPE_VIEW) { // View row

			// extrafieldsid
			$this->extrafieldsid->ViewValue = $this->extrafieldsid->CurrentValue;
			$this->extrafieldsid->ViewCustomAttributes = "";

			// merchantid
			$this->merchantid->ViewValue = $this->merchantid->CurrentValue;
			$this->merchantid->ViewCustomAttributes = "";

			// name
			$this->name->ViewValue = $this->name->CurrentValue;
			$this->name->ViewCustomAttributes = "";

			// field1label
			$this->field1label->ViewValue = $this->field1label->CurrentValue;
			$this->field1label->ViewCustomAttributes = "";

			// field1type
			$this->field1type->ViewValue = $this->field1type->CurrentValue;
			$this->field1type->ViewCustomAttributes = "";

			// field1mandatory
			$this->field1mandatory->ViewValue = $this->field1mandatory->CurrentValue;
			$this->field1mandatory->ViewCustomAttributes = "";

			// field1display
			$this->field1display->ViewValue = $this->field1display->CurrentValue;
			$this->field1display->ViewCustomAttributes = "";

			// field1displaysequence
			$this->field1displaysequence->ViewValue = $this->field1displaysequence->CurrentValue;
			$this->field1displaysequence->ViewCustomAttributes = "";

			// field1domain
			$this->field1domain->ViewValue = $this->field1domain->CurrentValue;
			$this->field1domain->ViewCustomAttributes = "";

			// field2label
			$this->field2label->ViewValue = $this->field2label->CurrentValue;
			$this->field2label->ViewCustomAttributes = "";

			// field2type
			$this->field2type->ViewValue = $this->field2type->CurrentValue;
			$this->field2type->ViewCustomAttributes = "";

			// field2mandatory
			$this->field2mandatory->ViewValue = $this->field2mandatory->CurrentValue;
			$this->field2mandatory->ViewCustomAttributes = "";

			// field2display
			$this->field2display->ViewValue = $this->field2display->CurrentValue;
			$this->field2display->ViewCustomAttributes = "";

			// field2displaysequence
			$this->field2displaysequence->ViewValue = $this->field2displaysequence->CurrentValue;
			$this->field2displaysequence->ViewCustomAttributes = "";

			// field2domain
			$this->field2domain->ViewValue = $this->field2domain->CurrentValue;
			$this->field2domain->ViewCustomAttributes = "";

			// field3label
			$this->field3label->ViewValue = $this->field3label->CurrentValue;
			$this->field3label->ViewCustomAttributes = "";

			// field3type
			$this->field3type->ViewValue = $this->field3type->CurrentValue;
			$this->field3type->ViewCustomAttributes = "";

			// field3mandatory
			$this->field3mandatory->ViewValue = $this->field3mandatory->CurrentValue;
			$this->field3mandatory->ViewCustomAttributes = "";

			// field3display
			$this->field3display->ViewValue = $this->field3display->CurrentValue;
			$this->field3display->ViewCustomAttributes = "";

			// field3displaysequence
			$this->field3displaysequence->ViewValue = $this->field3displaysequence->CurrentValue;
			$this->field3displaysequence->ViewCustomAttributes = "";

			// field3domain
			$this->field3domain->ViewValue = $this->field3domain->CurrentValue;
			$this->field3domain->ViewCustomAttributes = "";

			// field4label
			$this->field4label->ViewValue = $this->field4label->CurrentValue;
			$this->field4label->ViewCustomAttributes = "";

			// field4type
			$this->field4type->ViewValue = $this->field4type->CurrentValue;
			$this->field4type->ViewCustomAttributes = "";

			// field4mandatory
			$this->field4mandatory->ViewValue = $this->field4mandatory->CurrentValue;
			$this->field4mandatory->ViewCustomAttributes = "";

			// field4display
			$this->field4display->ViewValue = $this->field4display->CurrentValue;
			$this->field4display->ViewCustomAttributes = "";

			// field4displaysequence
			$this->field4displaysequence->ViewValue = $this->field4displaysequence->CurrentValue;
			$this->field4displaysequence->ViewCustomAttributes = "";

			// field4domain
			$this->field4domain->ViewValue = $this->field4domain->CurrentValue;
			$this->field4domain->ViewCustomAttributes = "";

			// field5label
			$this->field5label->ViewValue = $this->field5label->CurrentValue;
			$this->field5label->ViewCustomAttributes = "";

			// field5type
			$this->field5type->ViewValue = $this->field5type->CurrentValue;
			$this->field5type->ViewCustomAttributes = "";

			// field5mandatory
			$this->field5mandatory->ViewValue = $this->field5mandatory->CurrentValue;
			$this->field5mandatory->ViewCustomAttributes = "";

			// field5display
			$this->field5display->ViewValue = $this->field5display->CurrentValue;
			$this->field5display->ViewCustomAttributes = "";

			// field5displaysequence
			$this->field5displaysequence->ViewValue = $this->field5displaysequence->CurrentValue;
			$this->field5displaysequence->ViewCustomAttributes = "";

			// field5domain
			$this->field5domain->ViewValue = $this->field5domain->CurrentValue;
			$this->field5domain->ViewCustomAttributes = "";

			// field6label
			$this->field6label->ViewValue = $this->field6label->CurrentValue;
			$this->field6label->ViewCustomAttributes = "";

			// field6type
			$this->field6type->ViewValue = $this->field6type->CurrentValue;
			$this->field6type->ViewCustomAttributes = "";

			// field6mandatory
			$this->field6mandatory->ViewValue = $this->field6mandatory->CurrentValue;
			$this->field6mandatory->ViewCustomAttributes = "";

			// field6display
			$this->field6display->ViewValue = $this->field6display->CurrentValue;
			$this->field6display->ViewCustomAttributes = "";

			// field6displaysequence
			$this->field6displaysequence->ViewValue = $this->field6displaysequence->CurrentValue;
			$this->field6displaysequence->ViewCustomAttributes = "";

			// field6domain
			$this->field6domain->ViewValue = $this->field6domain->CurrentValue;
			$this->field6domain->ViewCustomAttributes = "";

			// field7label
			$this->field7label->ViewValue = $this->field7label->CurrentValue;
			$this->field7label->ViewCustomAttributes = "";

			// field7type
			$this->field7type->ViewValue = $this->field7type->CurrentValue;
			$this->field7type->ViewCustomAttributes = "";

			// field7mandatory
			$this->field7mandatory->ViewValue = $this->field7mandatory->CurrentValue;
			$this->field7mandatory->ViewCustomAttributes = "";

			// field7display
			$this->field7display->ViewValue = $this->field7display->CurrentValue;
			$this->field7display->ViewCustomAttributes = "";

			// field7displaysequence
			$this->field7displaysequence->ViewValue = $this->field7displaysequence->CurrentValue;
			$this->field7displaysequence->ViewCustomAttributes = "";

			// field7domain
			$this->field7domain->ViewValue = $this->field7domain->CurrentValue;
			$this->field7domain->ViewCustomAttributes = "";

			// field8label
			$this->field8label->ViewValue = $this->field8label->CurrentValue;
			$this->field8label->ViewCustomAttributes = "";

			// field8type
			$this->field8type->ViewValue = $this->field8type->CurrentValue;
			$this->field8type->ViewCustomAttributes = "";

			// field8mandatory
			$this->field8mandatory->ViewValue = $this->field8mandatory->CurrentValue;
			$this->field8mandatory->ViewCustomAttributes = "";

			// field8display
			$this->field8display->ViewValue = $this->field8display->CurrentValue;
			$this->field8display->ViewCustomAttributes = "";

			// field8displaysequence
			$this->field8displaysequence->ViewValue = $this->field8displaysequence->CurrentValue;
			$this->field8displaysequence->ViewCustomAttributes = "";

			// field8domain
			$this->field8domain->ViewValue = $this->field8domain->CurrentValue;
			$this->field8domain->ViewCustomAttributes = "";

			// field9label
			$this->field9label->ViewValue = $this->field9label->CurrentValue;
			$this->field9label->ViewCustomAttributes = "";

			// field9type
			$this->field9type->ViewValue = $this->field9type->CurrentValue;
			$this->field9type->ViewCustomAttributes = "";

			// field9mandatory
			$this->field9mandatory->ViewValue = $this->field9mandatory->CurrentValue;
			$this->field9mandatory->ViewCustomAttributes = "";

			// field9display
			$this->field9display->ViewValue = $this->field9display->CurrentValue;
			$this->field9display->ViewCustomAttributes = "";

			// field9displaysequence
			$this->field9displaysequence->ViewValue = $this->field9displaysequence->CurrentValue;
			$this->field9displaysequence->ViewCustomAttributes = "";

			// field9domain
			$this->field9domain->ViewValue = $this->field9domain->CurrentValue;
			$this->field9domain->ViewCustomAttributes = "";

			// field10label
			$this->field10label->ViewValue = $this->field10label->CurrentValue;
			$this->field10label->ViewCustomAttributes = "";

			// field10type
			$this->field10type->ViewValue = $this->field10type->CurrentValue;
			$this->field10type->ViewCustomAttributes = "";

			// field10mandatory
			$this->field10mandatory->ViewValue = $this->field10mandatory->CurrentValue;
			$this->field10mandatory->ViewCustomAttributes = "";

			// field10display
			$this->field10display->ViewValue = $this->field10display->CurrentValue;
			$this->field10display->ViewCustomAttributes = "";

			// field10displaysequence
			$this->field10displaysequence->ViewValue = $this->field10displaysequence->CurrentValue;
			$this->field10displaysequence->ViewCustomAttributes = "";

			// field10domain
			$this->field10domain->ViewValue = $this->field10domain->CurrentValue;
			$this->field10domain->ViewCustomAttributes = "";

			// lastupdatedate
			$this->lastupdatedate->ViewValue = $this->lastupdatedate->CurrentValue;
			$this->lastupdatedate->ViewValue = FormatDateTime($this->lastupdatedate->ViewValue, 0);
			$this->lastupdatedate->ViewCustomAttributes = "";

			// extrafieldsid
			$this->extrafieldsid->LinkCustomAttributes = "";
			$this->extrafieldsid->HrefValue = "";
			$this->extrafieldsid->TooltipValue = "";
			if (!$this->isExport())
				$this->extrafieldsid->ViewValue = $this->highlightValue($this->extrafieldsid);

			// merchantid
			$this->merchantid->LinkCustomAttributes = "";
			$this->merchantid->HrefValue = "";
			$this->merchantid->TooltipValue = "";
			if (!$this->isExport())
				$this->merchantid->ViewValue = $this->highlightValue($this->merchantid);

			// name
			$this->name->LinkCustomAttributes = "";
			$this->name->HrefValue = "";
			$this->name->TooltipValue = "";
			if (!$this->isExport())
				$this->name->ViewValue = $this->highlightValue($this->name);

			// field1label
			$this->field1label->LinkCustomAttributes = "";
			$this->field1label->HrefValue = "";
			$this->field1label->TooltipValue = "";
			if (!$this->isExport())
				$this->field1label->ViewValue = $this->highlightValue($this->field1label);

			// field1type
			$this->field1type->LinkCustomAttributes = "";
			$this->field1type->HrefValue = "";
			$this->field1type->TooltipValue = "";
			if (!$this->isExport())
				$this->field1type->ViewValue = $this->highlightValue($this->field1type);

			// field1mandatory
			$this->field1mandatory->LinkCustomAttributes = "";
			$this->field1mandatory->HrefValue = "";
			$this->field1mandatory->TooltipValue = "";
			if (!$this->isExport())
				$this->field1mandatory->ViewValue = $this->highlightValue($this->field1mandatory);

			// field1display
			$this->field1display->LinkCustomAttributes = "";
			$this->field1display->HrefValue = "";
			$this->field1display->TooltipValue = "";
			if (!$this->isExport())
				$this->field1display->ViewValue = $this->highlightValue($this->field1display);

			// field1displaysequence
			$this->field1displaysequence->LinkCustomAttributes = "";
			$this->field1displaysequence->HrefValue = "";
			$this->field1displaysequence->TooltipValue = "";
			if (!$this->isExport())
				$this->field1displaysequence->ViewValue = $this->highlightValue($this->field1displaysequence);

			// field1domain
			$this->field1domain->LinkCustomAttributes = "";
			$this->field1domain->HrefValue = "";
			$this->field1domain->TooltipValue = "";
			if (!$this->isExport())
				$this->field1domain->ViewValue = $this->highlightValue($this->field1domain);

			// field2label
			$this->field2label->LinkCustomAttributes = "";
			$this->field2label->HrefValue = "";
			$this->field2label->TooltipValue = "";
			if (!$this->isExport())
				$this->field2label->ViewValue = $this->highlightValue($this->field2label);

			// field2type
			$this->field2type->LinkCustomAttributes = "";
			$this->field2type->HrefValue = "";
			$this->field2type->TooltipValue = "";
			if (!$this->isExport())
				$this->field2type->ViewValue = $this->highlightValue($this->field2type);

			// field2mandatory
			$this->field2mandatory->LinkCustomAttributes = "";
			$this->field2mandatory->HrefValue = "";
			$this->field2mandatory->TooltipValue = "";
			if (!$this->isExport())
				$this->field2mandatory->ViewValue = $this->highlightValue($this->field2mandatory);

			// field2display
			$this->field2display->LinkCustomAttributes = "";
			$this->field2display->HrefValue = "";
			$this->field2display->TooltipValue = "";
			if (!$this->isExport())
				$this->field2display->ViewValue = $this->highlightValue($this->field2display);

			// field2displaysequence
			$this->field2displaysequence->LinkCustomAttributes = "";
			$this->field2displaysequence->HrefValue = "";
			$this->field2displaysequence->TooltipValue = "";
			if (!$this->isExport())
				$this->field2displaysequence->ViewValue = $this->highlightValue($this->field2displaysequence);

			// field2domain
			$this->field2domain->LinkCustomAttributes = "";
			$this->field2domain->HrefValue = "";
			$this->field2domain->TooltipValue = "";
			if (!$this->isExport())
				$this->field2domain->ViewValue = $this->highlightValue($this->field2domain);

			// field3label
			$this->field3label->LinkCustomAttributes = "";
			$this->field3label->HrefValue = "";
			$this->field3label->TooltipValue = "";
			if (!$this->isExport())
				$this->field3label->ViewValue = $this->highlightValue($this->field3label);

			// field3type
			$this->field3type->LinkCustomAttributes = "";
			$this->field3type->HrefValue = "";
			$this->field3type->TooltipValue = "";
			if (!$this->isExport())
				$this->field3type->ViewValue = $this->highlightValue($this->field3type);

			// field3mandatory
			$this->field3mandatory->LinkCustomAttributes = "";
			$this->field3mandatory->HrefValue = "";
			$this->field3mandatory->TooltipValue = "";
			if (!$this->isExport())
				$this->field3mandatory->ViewValue = $this->highlightValue($this->field3mandatory);

			// field3display
			$this->field3display->LinkCustomAttributes = "";
			$this->field3display->HrefValue = "";
			$this->field3display->TooltipValue = "";
			if (!$this->isExport())
				$this->field3display->ViewValue = $this->highlightValue($this->field3display);

			// field3displaysequence
			$this->field3displaysequence->LinkCustomAttributes = "";
			$this->field3displaysequence->HrefValue = "";
			$this->field3displaysequence->TooltipValue = "";
			if (!$this->isExport())
				$this->field3displaysequence->ViewValue = $this->highlightValue($this->field3displaysequence);

			// field3domain
			$this->field3domain->LinkCustomAttributes = "";
			$this->field3domain->HrefValue = "";
			$this->field3domain->TooltipValue = "";
			if (!$this->isExport())
				$this->field3domain->ViewValue = $this->highlightValue($this->field3domain);

			// field4label
			$this->field4label->LinkCustomAttributes = "";
			$this->field4label->HrefValue = "";
			$this->field4label->TooltipValue = "";
			if (!$this->isExport())
				$this->field4label->ViewValue = $this->highlightValue($this->field4label);

			// field4type
			$this->field4type->LinkCustomAttributes = "";
			$this->field4type->HrefValue = "";
			$this->field4type->TooltipValue = "";
			if (!$this->isExport())
				$this->field4type->ViewValue = $this->highlightValue($this->field4type);

			// field4mandatory
			$this->field4mandatory->LinkCustomAttributes = "";
			$this->field4mandatory->HrefValue = "";
			$this->field4mandatory->TooltipValue = "";
			if (!$this->isExport())
				$this->field4mandatory->ViewValue = $this->highlightValue($this->field4mandatory);

			// field4display
			$this->field4display->LinkCustomAttributes = "";
			$this->field4display->HrefValue = "";
			$this->field4display->TooltipValue = "";
			if (!$this->isExport())
				$this->field4display->ViewValue = $this->highlightValue($this->field4display);

			// field4displaysequence
			$this->field4displaysequence->LinkCustomAttributes = "";
			$this->field4displaysequence->HrefValue = "";
			$this->field4displaysequence->TooltipValue = "";
			if (!$this->isExport())
				$this->field4displaysequence->ViewValue = $this->highlightValue($this->field4displaysequence);

			// field4domain
			$this->field4domain->LinkCustomAttributes = "";
			$this->field4domain->HrefValue = "";
			$this->field4domain->TooltipValue = "";
			if (!$this->isExport())
				$this->field4domain->ViewValue = $this->highlightValue($this->field4domain);

			// field5label
			$this->field5label->LinkCustomAttributes = "";
			$this->field5label->HrefValue = "";
			$this->field5label->TooltipValue = "";
			if (!$this->isExport())
				$this->field5label->ViewValue = $this->highlightValue($this->field5label);

			// field5type
			$this->field5type->LinkCustomAttributes = "";
			$this->field5type->HrefValue = "";
			$this->field5type->TooltipValue = "";
			if (!$this->isExport())
				$this->field5type->ViewValue = $this->highlightValue($this->field5type);

			// field5mandatory
			$this->field5mandatory->LinkCustomAttributes = "";
			$this->field5mandatory->HrefValue = "";
			$this->field5mandatory->TooltipValue = "";
			if (!$this->isExport())
				$this->field5mandatory->ViewValue = $this->highlightValue($this->field5mandatory);

			// field5display
			$this->field5display->LinkCustomAttributes = "";
			$this->field5display->HrefValue = "";
			$this->field5display->TooltipValue = "";
			if (!$this->isExport())
				$this->field5display->ViewValue = $this->highlightValue($this->field5display);

			// field5displaysequence
			$this->field5displaysequence->LinkCustomAttributes = "";
			$this->field5displaysequence->HrefValue = "";
			$this->field5displaysequence->TooltipValue = "";
			if (!$this->isExport())
				$this->field5displaysequence->ViewValue = $this->highlightValue($this->field5displaysequence);

			// field5domain
			$this->field5domain->LinkCustomAttributes = "";
			$this->field5domain->HrefValue = "";
			$this->field5domain->TooltipValue = "";
			if (!$this->isExport())
				$this->field5domain->ViewValue = $this->highlightValue($this->field5domain);

			// field6label
			$this->field6label->LinkCustomAttributes = "";
			$this->field6label->HrefValue = "";
			$this->field6label->TooltipValue = "";
			if (!$this->isExport())
				$this->field6label->ViewValue = $this->highlightValue($this->field6label);

			// field6type
			$this->field6type->LinkCustomAttributes = "";
			$this->field6type->HrefValue = "";
			$this->field6type->TooltipValue = "";
			if (!$this->isExport())
				$this->field6type->ViewValue = $this->highlightValue($this->field6type);

			// field6mandatory
			$this->field6mandatory->LinkCustomAttributes = "";
			$this->field6mandatory->HrefValue = "";
			$this->field6mandatory->TooltipValue = "";
			if (!$this->isExport())
				$this->field6mandatory->ViewValue = $this->highlightValue($this->field6mandatory);

			// field6display
			$this->field6display->LinkCustomAttributes = "";
			$this->field6display->HrefValue = "";
			$this->field6display->TooltipValue = "";
			if (!$this->isExport())
				$this->field6display->ViewValue = $this->highlightValue($this->field6display);

			// field6displaysequence
			$this->field6displaysequence->LinkCustomAttributes = "";
			$this->field6displaysequence->HrefValue = "";
			$this->field6displaysequence->TooltipValue = "";
			if (!$this->isExport())
				$this->field6displaysequence->ViewValue = $this->highlightValue($this->field6displaysequence);

			// field6domain
			$this->field6domain->LinkCustomAttributes = "";
			$this->field6domain->HrefValue = "";
			$this->field6domain->TooltipValue = "";
			if (!$this->isExport())
				$this->field6domain->ViewValue = $this->highlightValue($this->field6domain);

			// field7label
			$this->field7label->LinkCustomAttributes = "";
			$this->field7label->HrefValue = "";
			$this->field7label->TooltipValue = "";
			if (!$this->isExport())
				$this->field7label->ViewValue = $this->highlightValue($this->field7label);

			// field7type
			$this->field7type->LinkCustomAttributes = "";
			$this->field7type->HrefValue = "";
			$this->field7type->TooltipValue = "";
			if (!$this->isExport())
				$this->field7type->ViewValue = $this->highlightValue($this->field7type);

			// field7mandatory
			$this->field7mandatory->LinkCustomAttributes = "";
			$this->field7mandatory->HrefValue = "";
			$this->field7mandatory->TooltipValue = "";
			if (!$this->isExport())
				$this->field7mandatory->ViewValue = $this->highlightValue($this->field7mandatory);

			// field7display
			$this->field7display->LinkCustomAttributes = "";
			$this->field7display->HrefValue = "";
			$this->field7display->TooltipValue = "";
			if (!$this->isExport())
				$this->field7display->ViewValue = $this->highlightValue($this->field7display);

			// field7displaysequence
			$this->field7displaysequence->LinkCustomAttributes = "";
			$this->field7displaysequence->HrefValue = "";
			$this->field7displaysequence->TooltipValue = "";
			if (!$this->isExport())
				$this->field7displaysequence->ViewValue = $this->highlightValue($this->field7displaysequence);

			// field7domain
			$this->field7domain->LinkCustomAttributes = "";
			$this->field7domain->HrefValue = "";
			$this->field7domain->TooltipValue = "";
			if (!$this->isExport())
				$this->field7domain->ViewValue = $this->highlightValue($this->field7domain);

			// field8label
			$this->field8label->LinkCustomAttributes = "";
			$this->field8label->HrefValue = "";
			$this->field8label->TooltipValue = "";
			if (!$this->isExport())
				$this->field8label->ViewValue = $this->highlightValue($this->field8label);

			// field8type
			$this->field8type->LinkCustomAttributes = "";
			$this->field8type->HrefValue = "";
			$this->field8type->TooltipValue = "";
			if (!$this->isExport())
				$this->field8type->ViewValue = $this->highlightValue($this->field8type);

			// field8mandatory
			$this->field8mandatory->LinkCustomAttributes = "";
			$this->field8mandatory->HrefValue = "";
			$this->field8mandatory->TooltipValue = "";
			if (!$this->isExport())
				$this->field8mandatory->ViewValue = $this->highlightValue($this->field8mandatory);

			// field8display
			$this->field8display->LinkCustomAttributes = "";
			$this->field8display->HrefValue = "";
			$this->field8display->TooltipValue = "";
			if (!$this->isExport())
				$this->field8display->ViewValue = $this->highlightValue($this->field8display);

			// field8displaysequence
			$this->field8displaysequence->LinkCustomAttributes = "";
			$this->field8displaysequence->HrefValue = "";
			$this->field8displaysequence->TooltipValue = "";
			if (!$this->isExport())
				$this->field8displaysequence->ViewValue = $this->highlightValue($this->field8displaysequence);

			// field8domain
			$this->field8domain->LinkCustomAttributes = "";
			$this->field8domain->HrefValue = "";
			$this->field8domain->TooltipValue = "";
			if (!$this->isExport())
				$this->field8domain->ViewValue = $this->highlightValue($this->field8domain);

			// field9label
			$this->field9label->LinkCustomAttributes = "";
			$this->field9label->HrefValue = "";
			$this->field9label->TooltipValue = "";
			if (!$this->isExport())
				$this->field9label->ViewValue = $this->highlightValue($this->field9label);

			// field9type
			$this->field9type->LinkCustomAttributes = "";
			$this->field9type->HrefValue = "";
			$this->field9type->TooltipValue = "";
			if (!$this->isExport())
				$this->field9type->ViewValue = $this->highlightValue($this->field9type);

			// field9mandatory
			$this->field9mandatory->LinkCustomAttributes = "";
			$this->field9mandatory->HrefValue = "";
			$this->field9mandatory->TooltipValue = "";
			if (!$this->isExport())
				$this->field9mandatory->ViewValue = $this->highlightValue($this->field9mandatory);

			// field9display
			$this->field9display->LinkCustomAttributes = "";
			$this->field9display->HrefValue = "";
			$this->field9display->TooltipValue = "";
			if (!$this->isExport())
				$this->field9display->ViewValue = $this->highlightValue($this->field9display);

			// field9displaysequence
			$this->field9displaysequence->LinkCustomAttributes = "";
			$this->field9displaysequence->HrefValue = "";
			$this->field9displaysequence->TooltipValue = "";
			if (!$this->isExport())
				$this->field9displaysequence->ViewValue = $this->highlightValue($this->field9displaysequence);

			// field9domain
			$this->field9domain->LinkCustomAttributes = "";
			$this->field9domain->HrefValue = "";
			$this->field9domain->TooltipValue = "";
			if (!$this->isExport())
				$this->field9domain->ViewValue = $this->highlightValue($this->field9domain);

			// field10label
			$this->field10label->LinkCustomAttributes = "";
			$this->field10label->HrefValue = "";
			$this->field10label->TooltipValue = "";
			if (!$this->isExport())
				$this->field10label->ViewValue = $this->highlightValue($this->field10label);

			// field10type
			$this->field10type->LinkCustomAttributes = "";
			$this->field10type->HrefValue = "";
			$this->field10type->TooltipValue = "";
			if (!$this->isExport())
				$this->field10type->ViewValue = $this->highlightValue($this->field10type);

			// field10mandatory
			$this->field10mandatory->LinkCustomAttributes = "";
			$this->field10mandatory->HrefValue = "";
			$this->field10mandatory->TooltipValue = "";
			if (!$this->isExport())
				$this->field10mandatory->ViewValue = $this->highlightValue($this->field10mandatory);

			// field10display
			$this->field10display->LinkCustomAttributes = "";
			$this->field10display->HrefValue = "";
			$this->field10display->TooltipValue = "";
			if (!$this->isExport())
				$this->field10display->ViewValue = $this->highlightValue($this->field10display);

			// field10displaysequence
			$this->field10displaysequence->LinkCustomAttributes = "";
			$this->field10displaysequence->HrefValue = "";
			$this->field10displaysequence->TooltipValue = "";
			if (!$this->isExport())
				$this->field10displaysequence->ViewValue = $this->highlightValue($this->field10displaysequence);

			// field10domain
			$this->field10domain->LinkCustomAttributes = "";
			$this->field10domain->HrefValue = "";
			$this->field10domain->TooltipValue = "";
			if (!$this->isExport())
				$this->field10domain->ViewValue = $this->highlightValue($this->field10domain);

			// lastupdatedate
			$this->lastupdatedate->LinkCustomAttributes = "";
			$this->lastupdatedate->HrefValue = "";
			$this->lastupdatedate->TooltipValue = "";
		}

		// Call Row Rendered event
		if ($this->RowType != ROWTYPE_AGGREGATEINIT)
			$this->Row_Rendered();
	}

	// Validate search
	protected function validateSearch()
	{
		global $SearchError;

		// Initialize
		$SearchError = "";

		// Check if validation required
		if (!Config("SERVER_VALIDATE"))
			return TRUE;

		// Return validate result
		$validateSearch = ($SearchError == "");

		// Call Form_CustomValidate event
		$formCustomError = "";
		$validateSearch = $validateSearch && $this->Form_CustomValidate($formCustomError);
		if ($formCustomError != "") {
			AddMessage($SearchError, $formCustomError);
		}
		return $validateSearch;
	}

	// Load advanced search
	public function loadAdvancedSearch()
	{
		$this->extrafieldsid->AdvancedSearch->load();
		$this->merchantid->AdvancedSearch->load();
		$this->name->AdvancedSearch->load();
		$this->field1label->AdvancedSearch->load();
		$this->field1type->AdvancedSearch->load();
		$this->field1mandatory->AdvancedSearch->load();
		$this->field1display->AdvancedSearch->load();
		$this->field1displaysequence->AdvancedSearch->load();
		$this->field1domain->AdvancedSearch->load();
		$this->field2label->AdvancedSearch->load();
		$this->field2type->AdvancedSearch->load();
		$this->field2mandatory->AdvancedSearch->load();
		$this->field2display->AdvancedSearch->load();
		$this->field2displaysequence->AdvancedSearch->load();
		$this->field2domain->AdvancedSearch->load();
		$this->field3label->AdvancedSearch->load();
		$this->field3type->AdvancedSearch->load();
		$this->field3mandatory->AdvancedSearch->load();
		$this->field3display->AdvancedSearch->load();
		$this->field3displaysequence->AdvancedSearch->load();
		$this->field3domain->AdvancedSearch->load();
		$this->field4label->AdvancedSearch->load();
		$this->field4type->AdvancedSearch->load();
		$this->field4mandatory->AdvancedSearch->load();
		$this->field4display->AdvancedSearch->load();
		$this->field4displaysequence->AdvancedSearch->load();
		$this->field4domain->AdvancedSearch->load();
		$this->field5label->AdvancedSearch->load();
		$this->field5type->AdvancedSearch->load();
		$this->field5mandatory->AdvancedSearch->load();
		$this->field5display->AdvancedSearch->load();
		$this->field5displaysequence->AdvancedSearch->load();
		$this->field5domain->AdvancedSearch->load();
		$this->field6label->AdvancedSearch->load();
		$this->field6type->AdvancedSearch->load();
		$this->field6mandatory->AdvancedSearch->load();
		$this->field6display->AdvancedSearch->load();
		$this->field6displaysequence->AdvancedSearch->load();
		$this->field6domain->AdvancedSearch->load();
		$this->field7label->AdvancedSearch->load();
		$this->field7type->AdvancedSearch->load();
		$this->field7mandatory->AdvancedSearch->load();
		$this->field7display->AdvancedSearch->load();
		$this->field7displaysequence->AdvancedSearch->load();
		$this->field7domain->AdvancedSearch->load();
		$this->field8label->AdvancedSearch->load();
		$this->field8type->AdvancedSearch->load();
		$this->field8mandatory->AdvancedSearch->load();
		$this->field8display->AdvancedSearch->load();
		$this->field8displaysequence->AdvancedSearch->load();
		$this->field8domain->AdvancedSearch->load();
		$this->field9label->AdvancedSearch->load();
		$this->field9type->AdvancedSearch->load();
		$this->field9mandatory->AdvancedSearch->load();
		$this->field9display->AdvancedSearch->load();
		$this->field9displaysequence->AdvancedSearch->load();
		$this->field9domain->AdvancedSearch->load();
		$this->field10label->AdvancedSearch->load();
		$this->field10type->AdvancedSearch->load();
		$this->field10mandatory->AdvancedSearch->load();
		$this->field10display->AdvancedSearch->load();
		$this->field10displaysequence->AdvancedSearch->load();
		$this->field10domain->AdvancedSearch->load();
		$this->lastupdatedate->AdvancedSearch->load();
	}

	// Get export HTML tag
	protected function getExportTag($type, $custom = FALSE)
	{
		global $Language;
		if (SameText($type, "excel")) {
			if ($custom)
				return "<a href=\"#\" class=\"ew-export-link ew-excel\" title=\"" . HtmlEncode($Language->phrase("ExportToExcelText")) . "\" data-caption=\"" . HtmlEncode($Language->phrase("ExportToExcelText")) . "\" onclick=\"return ew.export(document.fextrafieldstemplatelist, '" . $this->ExportExcelUrl . "', 'excel', true);\">" . $Language->phrase("ExportToExcel") . "</a>";
			else
				return "<a href=\"" . $this->ExportExcelUrl . "\" class=\"ew-export-link ew-excel\" title=\"" . HtmlEncode($Language->phrase("ExportToExcelText")) . "\" data-caption=\"" . HtmlEncode($Language->phrase("ExportToExcelText")) . "\">" . $Language->phrase("ExportToExcel") . "</a>";
		} elseif (SameText($type, "word")) {
			if ($custom)
				return "<a href=\"#\" class=\"ew-export-link ew-word\" title=\"" . HtmlEncode($Language->phrase("ExportToWordText")) . "\" data-caption=\"" . HtmlEncode($Language->phrase("ExportToWordText")) . "\" onclick=\"return ew.export(document.fextrafieldstemplatelist, '" . $this->ExportWordUrl . "', 'word', true);\">" . $Language->phrase("ExportToWord") . "</a>";
			else
				return "<a href=\"" . $this->ExportWordUrl . "\" class=\"ew-export-link ew-word\" title=\"" . HtmlEncode($Language->phrase("ExportToWordText")) . "\" data-caption=\"" . HtmlEncode($Language->phrase("ExportToWordText")) . "\">" . $Language->phrase("ExportToWord") . "</a>";
		} elseif (SameText($type, "pdf")) {
			if ($custom)
				return "<a href=\"#\" class=\"ew-export-link ew-pdf\" title=\"" . HtmlEncode($Language->phrase("ExportToPDFText")) . "\" data-caption=\"" . HtmlEncode($Language->phrase("ExportToPDFText")) . "\" onclick=\"return ew.export(document.fextrafieldstemplatelist, '" . $this->ExportPdfUrl . "', 'pdf', true);\">" . $Language->phrase("ExportToPDF") . "</a>";
			else
				return "<a href=\"" . $this->ExportPdfUrl . "\" class=\"ew-export-link ew-pdf\" title=\"" . HtmlEncode($Language->phrase("ExportToPDFText")) . "\" data-caption=\"" . HtmlEncode($Language->phrase("ExportToPDFText")) . "\">" . $Language->phrase("ExportToPDF") . "</a>";
		} elseif (SameText($type, "html")) {
			return "<a href=\"" . $this->ExportHtmlUrl . "\" class=\"ew-export-link ew-html\" title=\"" . HtmlEncode($Language->phrase("ExportToHtmlText")) . "\" data-caption=\"" . HtmlEncode($Language->phrase("ExportToHtmlText")) . "\">" . $Language->phrase("ExportToHtml") . "</a>";
		} elseif (SameText($type, "xml")) {
			return "<a href=\"" . $this->ExportXmlUrl . "\" class=\"ew-export-link ew-xml\" title=\"" . HtmlEncode($Language->phrase("ExportToXmlText")) . "\" data-caption=\"" . HtmlEncode($Language->phrase("ExportToXmlText")) . "\">" . $Language->phrase("ExportToXml") . "</a>";
		} elseif (SameText($type, "csv")) {
			return "<a href=\"" . $this->ExportCsvUrl . "\" class=\"ew-export-link ew-csv\" title=\"" . HtmlEncode($Language->phrase("ExportToCsvText")) . "\" data-caption=\"" . HtmlEncode($Language->phrase("ExportToCsvText")) . "\">" . $Language->phrase("ExportToCsv") . "</a>";
		} elseif (SameText($type, "email")) {
			$url = $custom ? ",url:'" . $this->pageUrl() . "export=email&amp;custom=1'" : "";
			return '<button id="emf_extrafieldstemplate" class="ew-export-link ew-email" title="' . $Language->phrase("ExportToEmailText") . '" data-caption="' . $Language->phrase("ExportToEmailText") . '" onclick="ew.emailDialogShow({lnk:\'emf_extrafieldstemplate\', hdr:ew.language.phrase(\'ExportToEmailText\'), f:document.fextrafieldstemplatelist, sel:false' . $url . '});">' . $Language->phrase("ExportToEmail") . '</button>';
		} elseif (SameText($type, "print")) {
			return "<a href=\"" . $this->ExportPrintUrl . "\" class=\"ew-export-link ew-print\" title=\"" . HtmlEncode($Language->phrase("PrinterFriendlyText")) . "\" data-caption=\"" . HtmlEncode($Language->phrase("PrinterFriendlyText")) . "\">" . $Language->phrase("PrinterFriendly") . "</a>";
		}
	}

	// Set up export options
	protected function setupExportOptions()
	{
		global $Language;

		// Printer friendly
		$item = &$this->ExportOptions->add("print");
		$item->Body = $this->getExportTag("print");
		$item->Visible = TRUE;

		// Export to Excel
		$item = &$this->ExportOptions->add("excel");
		$item->Body = $this->getExportTag("excel");
		$item->Visible = TRUE;

		// Export to Word
		$item = &$this->ExportOptions->add("word");
		$item->Body = $this->getExportTag("word");
		$item->Visible = TRUE;

		// Export to Html
		$item = &$this->ExportOptions->add("html");
		$item->Body = $this->getExportTag("html");
		$item->Visible = TRUE;

		// Export to Xml
		$item = &$this->ExportOptions->add("xml");
		$item->Body = $this->getExportTag("xml");
		$item->Visible = FALSE;

		// Export to Csv
		$item = &$this->ExportOptions->add("csv");
		$item->Body = $this->getExportTag("csv");
		$item->Visible = TRUE;

		// Export to Pdf
		$item = &$this->ExportOptions->add("pdf");
		$item->Body = $this->getExportTag("pdf");
		$item->Visible = FALSE;

		// Export to Email
		$item = &$this->ExportOptions->add("email");
		$item->Body = $this->getExportTag("email");
		$item->Visible = TRUE;

		// Drop down button for export
		$this->ExportOptions->UseButtonGroup = TRUE;
		$this->ExportOptions->UseDropDownButton = TRUE;
		if ($this->ExportOptions->UseButtonGroup && IsMobile())
			$this->ExportOptions->UseDropDownButton = TRUE;
		$this->ExportOptions->DropDownButtonPhrase = $Language->phrase("ButtonExport");

		// Add group option item
		$item = &$this->ExportOptions->add($this->ExportOptions->GroupOptionName);
		$item->Body = "";
		$item->Visible = FALSE;
	}

	// Set up search options
	protected function setupSearchOptions()
	{
		global $Language;
		$this->SearchOptions = new ListOptions("div");
		$this->SearchOptions->TagClassName = "ew-search-option";

		// Search button
		$item = &$this->SearchOptions->add("searchtoggle");
		$searchToggleClass = ($this->SearchWhere != "") ? " active" : "";
		$item->Body = "<a class=\"btn btn-default ew-search-toggle" . $searchToggleClass . "\" href=\"#\" role=\"button\" title=\"" . $Language->phrase("SearchPanel") . "\" data-caption=\"" . $Language->phrase("SearchPanel") . "\" data-toggle=\"button\" data-form=\"fextrafieldstemplatelistsrch\" aria-pressed=\"" . ($searchToggleClass == " active" ? "true" : "false") . "\">" . $Language->phrase("SearchLink") . "</a>";
		$item->Visible = TRUE;

		// Show all button
		$item = &$this->SearchOptions->add("showall");
		$item->Body = "<a class=\"btn btn-default ew-show-all\" title=\"" . $Language->phrase("ShowAll") . "\" data-caption=\"" . $Language->phrase("ShowAll") . "\" href=\"" . $this->pageUrl() . "cmd=reset\">" . $Language->phrase("ShowAllBtn") . "</a>";
		$item->Visible = ($this->SearchWhere != $this->DefaultSearchWhere && $this->SearchWhere != "0=101");

		// Advanced search button
		$item = &$this->SearchOptions->add("advancedsearch");
		$item->Body = "<a class=\"btn btn-default ew-advanced-search\" title=\"" . $Language->phrase("AdvancedSearch") . "\" data-caption=\"" . $Language->phrase("AdvancedSearch") . "\" href=\"extrafieldstemplatesrch.php\">" . $Language->phrase("AdvancedSearchBtn") . "</a>";
		$item->Visible = TRUE;

		// Search highlight button
		$item = &$this->SearchOptions->add("searchhighlight");
		$item->Body = "<a class=\"btn btn-default ew-highlight active\" href=\"#\" role=\"button\" title=\"" . $Language->phrase("Highlight") . "\" data-caption=\"" . $Language->phrase("Highlight") . "\" data-toggle=\"button\" data-form=\"fextrafieldstemplatelistsrch\" data-name=\"" . $this->highlightName() . "\">" . $Language->phrase("HighlightBtn") . "</a>";
		$item->Visible = ($this->SearchWhere != "" && $this->TotalRecords > 0);

		// Button group for search
		$this->SearchOptions->UseDropDownButton = FALSE;
		$this->SearchOptions->UseButtonGroup = TRUE;
		$this->SearchOptions->DropDownButtonPhrase = $Language->phrase("ButtonSearch");

		// Add group option item
		$item = &$this->SearchOptions->add($this->SearchOptions->GroupOptionName);
		$item->Body = "";
		$item->Visible = FALSE;

		// Hide search options
		if ($this->isExport() || $this->CurrentAction)
			$this->SearchOptions->hideAllOptions();
		global $Security;
		if (!$Security->canSearch()) {
			$this->SearchOptions->hideAllOptions();
			$this->FilterOptions->hideAllOptions();
		}
	}

	/**
	 * Export data in HTML/CSV/Word/Excel/XML/Email/PDF format
	 *
	 * @param boolean $return Return the data rather than output it
	 * @return mixed
	 */
	public function exportData($return = FALSE)
	{
		global $Language;
		$utf8 = SameText(Config("PROJECT_CHARSET"), "utf-8");
		$selectLimit = $this->UseSelectLimit;

		// Load recordset
		if ($selectLimit) {
			$this->TotalRecords = $this->listRecordCount();
		} else {
			if (!$this->Recordset)
				$this->Recordset = $this->loadRecordset();
			$rs = &$this->Recordset;
			if ($rs)
				$this->TotalRecords = $rs->RecordCount();
		}
		$this->StartRecord = 1;

		// Export all
		if ($this->ExportAll) {
			set_time_limit(Config("EXPORT_ALL_TIME_LIMIT"));
			$this->DisplayRecords = $this->TotalRecords;
			$this->StopRecord = $this->TotalRecords;
		} else { // Export one page only
			$this->setupStartRecord(); // Set up start record position

			// Set the last record to display
			if ($this->DisplayRecords <= 0) {
				$this->StopRecord = $this->TotalRecords;
			} else {
				$this->StopRecord = $this->StartRecord + $this->DisplayRecords - 1;
			}
		}
		if ($selectLimit)
			$rs = $this->loadRecordset($this->StartRecord - 1, $this->DisplayRecords <= 0 ? $this->TotalRecords : $this->DisplayRecords);
		$this->ExportDoc = GetExportDocument($this, "h");
		$doc = &$this->ExportDoc;
		if (!$doc)
			$this->setFailureMessage($Language->phrase("ExportClassNotFound")); // Export class not found
		if (!$rs || !$doc) {
			RemoveHeader("Content-Type"); // Remove header
			RemoveHeader("Content-Disposition");
			$this->showMessage();
			return;
		}
		if ($selectLimit) {
			$this->StartRecord = 1;
			$this->StopRecord = $this->DisplayRecords <= 0 ? $this->TotalRecords : $this->DisplayRecords;
		}

		// Call Page Exporting server event
		$this->ExportDoc->ExportCustom = !$this->Page_Exporting();
		$header = $this->PageHeader;
		$this->Page_DataRendering($header);
		$doc->Text .= $header;
		$this->exportDocument($doc, $rs, $this->StartRecord, $this->StopRecord, "");
		$footer = $this->PageFooter;
		$this->Page_DataRendered($footer);
		$doc->Text .= $footer;

		// Close recordset
		$rs->close();

		// Call Page Exported server event
		$this->Page_Exported();

		// Export header and footer
		$doc->exportHeaderAndFooter();

		// Clean output buffer (without destroying output buffer)
		$buffer = ob_get_contents(); // Save the output buffer
		if (!Config("DEBUG") && $buffer)
			ob_clean();

		// Write debug message if enabled
		if (Config("DEBUG") && !$this->isExport("pdf"))
			echo GetDebugMessage();

		// Output data
		if ($this->isExport("email")) {
			if ($return)
				return $doc->Text; // Return email content
			else
				echo $this->exportEmail($doc->Text); // Send email
		} else {
			$doc->export();
			if ($return) {
				RemoveHeader("Content-Type"); // Remove header
				RemoveHeader("Content-Disposition");
				$content = ob_get_contents();
				if ($content)
					ob_clean();
				if ($buffer)
					echo $buffer; // Resume the output buffer
				return $content;
			}
		}
	}

	// Export email
	protected function exportEmail($emailContent)
	{
		global $TempImages, $Language;
		$sender = Post("sender", "");
		$recipient = Post("recipient", "");
		$cc = Post("cc", "");
		$bcc = Post("bcc", "");

		// Subject
		$subject = Post("subject", "");
		$emailSubject = $subject;

		// Message
		$content = Post("message", "");
		$emailMessage = $content;

		// Check sender
		if ($sender == "") {
			return "<p class=\"text-danger\">" . $Language->phrase("EnterSenderEmail") . "</p>";
		}
		if (!CheckEmail($sender)) {
			return "<p class=\"text-danger\">" . $Language->phrase("EnterProperSenderEmail") . "</p>";
		}

		// Check recipient
		if (!CheckEmailList($recipient, Config("MAX_EMAIL_RECIPIENT"))) {
			return "<p class=\"text-danger\">" . $Language->phrase("EnterProperRecipientEmail") . "</p>";
		}

		// Check cc
		if (!CheckEmailList($cc, Config("MAX_EMAIL_RECIPIENT"))) {
			return "<p class=\"text-danger\">" . $Language->phrase("EnterProperCcEmail") . "</p>";
		}

		// Check bcc
		if (!CheckEmailList($bcc, Config("MAX_EMAIL_RECIPIENT"))) {
			return "<p class=\"text-danger\">" . $Language->phrase("EnterProperBccEmail") . "</p>";
		}

		// Check email sent count
		if (!isset($_SESSION[Config("EXPORT_EMAIL_COUNTER")]))
			$_SESSION[Config("EXPORT_EMAIL_COUNTER")] = 0;
		if ((int)$_SESSION[Config("EXPORT_EMAIL_COUNTER")] > Config("MAX_EMAIL_SENT_COUNT")) {
			return "<p class=\"text-danger\">" . $Language->phrase("ExceedMaxEmailExport") . "</p>";
		}

		// Send email
		$email = new Email();
		$email->Sender = $sender; // Sender
		$email->Recipient = $recipient; // Recipient
		$email->Cc = $cc; // Cc
		$email->Bcc = $bcc; // Bcc
		$email->Subject = $emailSubject; // Subject
		$email->Format = "html";
		if ($emailMessage != "")
			$emailMessage = RemoveXss($emailMessage) . "<br><br>";
		foreach ($TempImages as $tmpImage)
			$email->addEmbeddedImage($tmpImage);
		$email->Content = $emailMessage . CleanEmailContent($emailContent); // Content
		$eventArgs = [];
		if ($this->Recordset)
			$eventArgs["rs"] = &$this->Recordset;
		$emailSent = FALSE;
		if ($this->Email_Sending($email, $eventArgs))
			$emailSent = $email->send();

		// Check email sent status
		if ($emailSent) {

			// Update email sent count
			$_SESSION[Config("EXPORT_EMAIL_COUNTER")]++;

			// Sent email success
			return "<p class=\"text-success\">" . $Language->phrase("SendEmailSuccess") . "</p>"; // Set up success message
		} else {

			// Sent email failure
			return "<p class=\"text-danger\">" . $email->SendErrDescription . "</p>";
		}
	}

	// Set up Breadcrumb
	protected function setupBreadcrumb()
	{
		global $Breadcrumb, $Language;
		$Breadcrumb = new Breadcrumb();
		$url = substr(CurrentUrl(), strrpos(CurrentUrl(), "/")+1);
		$url = preg_replace('/\?cmd=reset(all){0,1}$/i', '', $url); // Remove cmd=reset / cmd=resetall
		$Breadcrumb->add("list", $this->TableVar, $url, "", $this->TableVar, TRUE);
	}

	// Setup lookup options
	public function setupLookupOptions($fld)
	{
		if ($fld->Lookup !== NULL && $fld->Lookup->Options === NULL) {

			// Get default connection and filter
			$conn = $this->getConnection();
			$lookupFilter = "";

			// No need to check any more
			$fld->Lookup->Options = [];

			// Set up lookup SQL and connection
			switch ($fld->FieldVar) {
				default:
					$lookupFilter = "";
					break;
			}

			// Always call to Lookup->getSql so that user can setup Lookup->Options in Lookup_Selecting server event
			$sql = $fld->Lookup->getSql(FALSE, "", $lookupFilter, $this);

			// Set up lookup cache
			if ($fld->UseLookupCache && $sql != "" && count($fld->Lookup->Options) == 0) {
				$totalCnt = $this->getRecordCount($sql, $conn);
				if ($totalCnt > $fld->LookupCacheCount) // Total count > cache count, do not cache
					return;
				$rs = $conn->execute($sql);
				$ar = [];
				while ($rs && !$rs->EOF) {
					$row = &$rs->fields;

					// Format the field values
					switch ($fld->FieldVar) {
					}
					$ar[strval($row[0])] = $row;
					$rs->moveNext();
				}
				if ($rs)
					$rs->close();
				$fld->Lookup->Options = $ar;
			}
		}
	}

	// Set up starting record parameters
	public function setupStartRecord()
	{
		if ($this->DisplayRecords == 0)
			return;
		if ($this->isPageRequest()) { // Validate request
			$startRec = Get(Config("TABLE_START_REC"));
			$pageNo = Get(Config("TABLE_PAGE_NO"));
			if ($pageNo !== NULL) { // Check for "pageno" parameter first
				if (is_numeric($pageNo)) {
					$this->StartRecord = ($pageNo - 1) * $this->DisplayRecords + 1;
					if ($this->StartRecord <= 0) {
						$this->StartRecord = 1;
					} elseif ($this->StartRecord >= (int)(($this->TotalRecords - 1)/$this->DisplayRecords) * $this->DisplayRecords + 1) {
						$this->StartRecord = (int)(($this->TotalRecords - 1)/$this->DisplayRecords) * $this->DisplayRecords + 1;
					}
					$this->setStartRecordNumber($this->StartRecord);
				}
			} elseif ($startRec !== NULL) { // Check for "start" parameter
				$this->StartRecord = $startRec;
				$this->setStartRecordNumber($this->StartRecord);
			}
		}
		$this->StartRecord = $this->getStartRecordNumber();

		// Check if correct start record counter
		if (!is_numeric($this->StartRecord) || $this->StartRecord == "") { // Avoid invalid start record counter
			$this->StartRecord = 1; // Reset start record counter
			$this->setStartRecordNumber($this->StartRecord);
		} elseif ($this->StartRecord > $this->TotalRecords) { // Avoid starting record > total records
			$this->StartRecord = (int)(($this->TotalRecords - 1)/$this->DisplayRecords) * $this->DisplayRecords + 1; // Point to last page first record
			$this->setStartRecordNumber($this->StartRecord);
		} elseif (($this->StartRecord - 1) % $this->DisplayRecords != 0) {
			$this->StartRecord = (int)(($this->StartRecord - 1)/$this->DisplayRecords) * $this->DisplayRecords + 1; // Point to page boundary
			$this->setStartRecordNumber($this->StartRecord);
		}
	}

	// Page Load event
	function Page_Load() {

		//echo "Page Load";
	}

	// Page Unload event
	function Page_Unload() {

		//echo "Page Unload";
	}

	// Page Redirecting event
	function Page_Redirecting(&$url) {

		// Example:
		//$url = "your URL";

	}

	// Message Showing event
	// $type = ''|'success'|'failure'|'warning'
	function Message_Showing(&$msg, $type) {
		if ($type == 'success') {

			//$msg = "your success message";
		} elseif ($type == 'failure') {

			//$msg = "your failure message";
		} elseif ($type == 'warning') {

			//$msg = "your warning message";
		} else {

			//$msg = "your message";
		}
	}

	// Page Render event
	function Page_Render() {

		//echo "Page Render";
	}

	// Page Data Rendering event
	function Page_DataRendering(&$header) {

		// Example:
		//$header = "your header";

	}

	// Page Data Rendered event
	function Page_DataRendered(&$footer) {

		// Example:
		//$footer = "your footer";

	}

	// Form Custom Validate event
	function Form_CustomValidate(&$customError) {

		// Return error message in CustomError
		return TRUE;
	}

	// ListOptions Load event
	function ListOptions_Load() {

		// Example:
		//$opt = &$this->ListOptions->Add("new");
		//$opt->Header = "xxx";
		//$opt->OnLeft = TRUE; // Link on left
		//$opt->MoveTo(0); // Move to first column

	}

	// ListOptions Rendering event
	function ListOptions_Rendering() {

		//$GLOBALS["xxx_grid"]->DetailAdd = (...condition...); // Set to TRUE or FALSE conditionally
		//$GLOBALS["xxx_grid"]->DetailEdit = (...condition...); // Set to TRUE or FALSE conditionally
		//$GLOBALS["xxx_grid"]->DetailView = (...condition...); // Set to TRUE or FALSE conditionally

	}

	// ListOptions Rendered event
	function ListOptions_Rendered() {

		// Example:
		//$this->ListOptions["new"]->Body = "xxx";

	}

	// Row Custom Action event
	function Row_CustomAction($action, $row) {

		// Return FALSE to abort
		return TRUE;
	}

	// Page Exporting event
	// $this->ExportDoc = export document object
	function Page_Exporting() {

		//$this->ExportDoc->Text = "my header"; // Export header
		//return FALSE; // Return FALSE to skip default export and use Row_Export event

		return TRUE; // Return TRUE to use default export and skip Row_Export event
	}

	// Row Export event
	// $this->ExportDoc = export document object
	function Row_Export($rs) {

		//$this->ExportDoc->Text .= "my content"; // Build HTML with field value: $rs["MyField"] or $this->MyField->ViewValue
	}

	// Page Exported event
	// $this->ExportDoc = export document object
	function Page_Exported() {

		//$this->ExportDoc->Text .= "my footer"; // Export footer
		//echo $this->ExportDoc->Text;

	}

	// Page Importing event
	function Page_Importing($reader, &$options) {

		//var_dump($reader); // Import data reader
		//var_dump($options); // Show all options for importing
		//return FALSE; // Return FALSE to skip import

		return TRUE;
	}

	// Row Import event
	function Row_Import(&$row, $cnt) {

		//echo $cnt; // Import record count
		//var_dump($row); // Import row
		//return FALSE; // Return FALSE to skip import

		return TRUE;
	}

	// Page Imported event
	function Page_Imported($reader, $results) {

		//var_dump($reader); // Import data reader
		//var_dump($results); // Import results

	}
} // End class
?>