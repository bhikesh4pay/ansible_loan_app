<?php namespace PHPMaker2020\_4payadmin; ?>
<?php

/**
 * Table class for merchantmemberplan
 */
class merchantmemberplan extends DbTable
{
	protected $SqlFrom = "";
	protected $SqlSelect = "";
	protected $SqlSelectList = "";
	protected $SqlWhere = "";
	protected $SqlGroupBy = "";
	protected $SqlHaving = "";
	protected $SqlOrderBy = "";
	public $UseSessionForListSql = TRUE;

	// Column CSS classes
	public $LeftColumnClass = "col-sm-2 col-form-label ew-label";
	public $RightColumnClass = "col-sm-10";
	public $OffsetColumnClass = "col-sm-10 offset-sm-2";
	public $TableLeftColumnClass = "w-col-2";

	// Audit trail
	public $AuditTrailOnAdd = TRUE;
	public $AuditTrailOnEdit = TRUE;
	public $AuditTrailOnDelete = TRUE;
	public $AuditTrailOnView = FALSE;
	public $AuditTrailOnViewData = FALSE;
	public $AuditTrailOnSearch = FALSE;

	// Export
	public $ExportDoc;

	// Fields
	public $subscriptionplanid;
	public $merchantid;
	public $memberid;
	public $planid;
	public $registrationdate;
	public $paymentdate;
	public $effectivedate;
	public $willexpire;
	public $expirydate;
	public $renewalrequired;
	public $planidforrenewal;
	public $planstatus;
	public $planstatusdate;
	public $approvalstatus;
	public $approvaldatetime;
	public $approvalby;
	public $preauthorizedmemberpi;
	public $pendingpayment;
	public $lastinvoiceid;
	public $lastupdatedate;
	public $pendingpaymentid;
	public $notes;
	public $field1;
	public $field2;
	public $field3;
	public $field4;
	public $field5;
	public $field6;
	public $field7;
	public $field8;
	public $field9;
	public $field10;

	// Constructor
	public function __construct()
	{
		global $Language, $CurrentLanguage;
		parent::__construct();

		// Language object
		if (!isset($Language))
			$Language = new Language();
		$this->TableVar = 'merchantmemberplan';
		$this->TableName = 'merchantmemberplan';
		$this->TableType = 'TABLE';

		// Update Table
		$this->UpdateTable = "`merchantmemberplan`";
		$this->Dbid = 'DB';
		$this->ExportAll = TRUE;
		$this->ExportPageBreakCount = 0; // Page break per every n record (PDF only)
		$this->ExportPageOrientation = "portrait"; // Page orientation (PDF only)
		$this->ExportPageSize = "a4"; // Page size (PDF only)
		$this->ExportExcelPageOrientation = \PhpOffice\PhpSpreadsheet\Worksheet\PageSetup::ORIENTATION_DEFAULT; // Page orientation (PhpSpreadsheet only)
		$this->ExportExcelPageSize = \PhpOffice\PhpSpreadsheet\Worksheet\PageSetup::PAPERSIZE_A4; // Page size (PhpSpreadsheet only)
		$this->ExportWordPageOrientation = "portrait"; // Page orientation (PHPWord only)
		$this->ExportWordColumnWidth = NULL; // Cell width (PHPWord only)
		$this->DetailAdd = FALSE; // Allow detail add
		$this->DetailEdit = FALSE; // Allow detail edit
		$this->DetailView = FALSE; // Allow detail view
		$this->ShowMultipleDetails = FALSE; // Show multiple details
		$this->GridAddRowCount = 5;
		$this->AllowAddDeleteRow = TRUE; // Allow add/delete row
		$this->UserIDAllowSecurity = Config("DEFAULT_USER_ID_ALLOW_SECURITY"); // Default User ID allowed permissions
		$this->BasicSearch = new BasicSearch($this->TableVar);

		// subscriptionplanid
		$this->subscriptionplanid = new DbField('merchantmemberplan', 'merchantmemberplan', 'x_subscriptionplanid', 'subscriptionplanid', '`subscriptionplanid`', '`subscriptionplanid`', 3, 12, -1, FALSE, '`subscriptionplanid`', FALSE, FALSE, FALSE, 'FORMATTED TEXT', 'NO');
		$this->subscriptionplanid->IsAutoIncrement = TRUE; // Autoincrement field
		$this->subscriptionplanid->IsPrimaryKey = TRUE; // Primary key field
		$this->subscriptionplanid->Sortable = TRUE; // Allow sort
		$this->subscriptionplanid->DefaultErrorMessage = $Language->phrase("IncorrectInteger");
		$this->fields['subscriptionplanid'] = &$this->subscriptionplanid;

		// merchantid
		$this->merchantid = new DbField('merchantmemberplan', 'merchantmemberplan', 'x_merchantid', 'merchantid', '`merchantid`', '`merchantid`', 3, 12, -1, FALSE, '`merchantid`', FALSE, FALSE, FALSE, 'FORMATTED TEXT', 'TEXT');
		$this->merchantid->Nullable = FALSE; // NOT NULL field
		$this->merchantid->Required = TRUE; // Required field
		$this->merchantid->Sortable = TRUE; // Allow sort
		$this->merchantid->DefaultErrorMessage = $Language->phrase("IncorrectInteger");
		$this->fields['merchantid'] = &$this->merchantid;

		// memberid
		$this->memberid = new DbField('merchantmemberplan', 'merchantmemberplan', 'x_memberid', 'memberid', '`memberid`', '`memberid`', 3, 12, -1, FALSE, '`memberid`', FALSE, FALSE, FALSE, 'FORMATTED TEXT', 'TEXT');
		$this->memberid->Nullable = FALSE; // NOT NULL field
		$this->memberid->Required = TRUE; // Required field
		$this->memberid->Sortable = TRUE; // Allow sort
		$this->memberid->DefaultErrorMessage = $Language->phrase("IncorrectInteger");
		$this->fields['memberid'] = &$this->memberid;

		// planid
		$this->planid = new DbField('merchantmemberplan', 'merchantmemberplan', 'x_planid', 'planid', '`planid`', '`planid`', 3, 12, -1, FALSE, '`planid`', FALSE, FALSE, FALSE, 'FORMATTED TEXT', 'TEXT');
		$this->planid->Nullable = FALSE; // NOT NULL field
		$this->planid->Required = TRUE; // Required field
		$this->planid->Sortable = TRUE; // Allow sort
		$this->planid->DefaultErrorMessage = $Language->phrase("IncorrectInteger");
		$this->fields['planid'] = &$this->planid;

		// registrationdate
		$this->registrationdate = new DbField('merchantmemberplan', 'merchantmemberplan', 'x_registrationdate', 'registrationdate', '`registrationdate`', CastDateFieldForLike("`registrationdate`", 0, "DB"), 133, 10, 0, FALSE, '`registrationdate`', FALSE, FALSE, FALSE, 'FORMATTED TEXT', 'TEXT');
		$this->registrationdate->Nullable = FALSE; // NOT NULL field
		$this->registrationdate->Required = TRUE; // Required field
		$this->registrationdate->Sortable = TRUE; // Allow sort
		$this->registrationdate->DefaultErrorMessage = str_replace("%s", $GLOBALS["DATE_FORMAT"], $Language->phrase("IncorrectDate"));
		$this->fields['registrationdate'] = &$this->registrationdate;

		// paymentdate
		$this->paymentdate = new DbField('merchantmemberplan', 'merchantmemberplan', 'x_paymentdate', 'paymentdate', '`paymentdate`', CastDateFieldForLike("`paymentdate`", 0, "DB"), 133, 10, 0, FALSE, '`paymentdate`', FALSE, FALSE, FALSE, 'FORMATTED TEXT', 'TEXT');
		$this->paymentdate->Sortable = TRUE; // Allow sort
		$this->paymentdate->DefaultErrorMessage = str_replace("%s", $GLOBALS["DATE_FORMAT"], $Language->phrase("IncorrectDate"));
		$this->fields['paymentdate'] = &$this->paymentdate;

		// effectivedate
		$this->effectivedate = new DbField('merchantmemberplan', 'merchantmemberplan', 'x_effectivedate', 'effectivedate', '`effectivedate`', CastDateFieldForLike("`effectivedate`", 0, "DB"), 133, 10, 0, FALSE, '`effectivedate`', FALSE, FALSE, FALSE, 'FORMATTED TEXT', 'TEXT');
		$this->effectivedate->Sortable = TRUE; // Allow sort
		$this->effectivedate->DefaultErrorMessage = str_replace("%s", $GLOBALS["DATE_FORMAT"], $Language->phrase("IncorrectDate"));
		$this->fields['effectivedate'] = &$this->effectivedate;

		// willexpire
		$this->willexpire = new DbField('merchantmemberplan', 'merchantmemberplan', 'x_willexpire', 'willexpire', '`willexpire`', '`willexpire`', 3, 1, -1, FALSE, '`willexpire`', FALSE, FALSE, FALSE, 'FORMATTED TEXT', 'TEXT');
		$this->willexpire->Nullable = FALSE; // NOT NULL field
		$this->willexpire->Required = TRUE; // Required field
		$this->willexpire->Sortable = TRUE; // Allow sort
		$this->willexpire->DefaultErrorMessage = $Language->phrase("IncorrectInteger");
		$this->fields['willexpire'] = &$this->willexpire;

		// expirydate
		$this->expirydate = new DbField('merchantmemberplan', 'merchantmemberplan', 'x_expirydate', 'expirydate', '`expirydate`', CastDateFieldForLike("`expirydate`", 0, "DB"), 133, 10, 0, FALSE, '`expirydate`', FALSE, FALSE, FALSE, 'FORMATTED TEXT', 'TEXT');
		$this->expirydate->Sortable = TRUE; // Allow sort
		$this->expirydate->DefaultErrorMessage = str_replace("%s", $GLOBALS["DATE_FORMAT"], $Language->phrase("IncorrectDate"));
		$this->fields['expirydate'] = &$this->expirydate;

		// renewalrequired
		$this->renewalrequired = new DbField('merchantmemberplan', 'merchantmemberplan', 'x_renewalrequired', 'renewalrequired', '`renewalrequired`', '`renewalrequired`', 3, 1, -1, FALSE, '`renewalrequired`', FALSE, FALSE, FALSE, 'FORMATTED TEXT', 'TEXT');
		$this->renewalrequired->Nullable = FALSE; // NOT NULL field
		$this->renewalrequired->Required = TRUE; // Required field
		$this->renewalrequired->Sortable = TRUE; // Allow sort
		$this->renewalrequired->DefaultErrorMessage = $Language->phrase("IncorrectInteger");
		$this->fields['renewalrequired'] = &$this->renewalrequired;

		// planidforrenewal
		$this->planidforrenewal = new DbField('merchantmemberplan', 'merchantmemberplan', 'x_planidforrenewal', 'planidforrenewal', '`planidforrenewal`', '`planidforrenewal`', 3, 12, -1, FALSE, '`planidforrenewal`', FALSE, FALSE, FALSE, 'FORMATTED TEXT', 'TEXT');
		$this->planidforrenewal->Nullable = FALSE; // NOT NULL field
		$this->planidforrenewal->Required = TRUE; // Required field
		$this->planidforrenewal->Sortable = TRUE; // Allow sort
		$this->planidforrenewal->DefaultErrorMessage = $Language->phrase("IncorrectInteger");
		$this->fields['planidforrenewal'] = &$this->planidforrenewal;

		// planstatus
		$this->planstatus = new DbField('merchantmemberplan', 'merchantmemberplan', 'x_planstatus', 'planstatus', '`planstatus`', '`planstatus`', 3, 1, -1, FALSE, '`planstatus`', FALSE, FALSE, FALSE, 'FORMATTED TEXT', 'TEXT');
		$this->planstatus->Nullable = FALSE; // NOT NULL field
		$this->planstatus->Required = TRUE; // Required field
		$this->planstatus->Sortable = TRUE; // Allow sort
		$this->planstatus->DefaultErrorMessage = $Language->phrase("IncorrectInteger");
		$this->fields['planstatus'] = &$this->planstatus;

		// planstatusdate
		$this->planstatusdate = new DbField('merchantmemberplan', 'merchantmemberplan', 'x_planstatusdate', 'planstatusdate', '`planstatusdate`', CastDateFieldForLike("`planstatusdate`", 0, "DB"), 133, 10, 0, FALSE, '`planstatusdate`', FALSE, FALSE, FALSE, 'FORMATTED TEXT', 'TEXT');
		$this->planstatusdate->Sortable = TRUE; // Allow sort
		$this->planstatusdate->DefaultErrorMessage = str_replace("%s", $GLOBALS["DATE_FORMAT"], $Language->phrase("IncorrectDate"));
		$this->fields['planstatusdate'] = &$this->planstatusdate;

		// approvalstatus
		$this->approvalstatus = new DbField('merchantmemberplan', 'merchantmemberplan', 'x_approvalstatus', 'approvalstatus', '`approvalstatus`', '`approvalstatus`', 3, 1, -1, FALSE, '`approvalstatus`', FALSE, FALSE, FALSE, 'FORMATTED TEXT', 'TEXT');
		$this->approvalstatus->Sortable = TRUE; // Allow sort
		$this->approvalstatus->DefaultErrorMessage = $Language->phrase("IncorrectInteger");
		$this->fields['approvalstatus'] = &$this->approvalstatus;

		// approvaldatetime
		$this->approvaldatetime = new DbField('merchantmemberplan', 'merchantmemberplan', 'x_approvaldatetime', 'approvaldatetime', '`approvaldatetime`', CastDateFieldForLike("`approvaldatetime`", 0, "DB"), 135, 19, 0, FALSE, '`approvaldatetime`', FALSE, FALSE, FALSE, 'FORMATTED TEXT', 'TEXT');
		$this->approvaldatetime->Sortable = TRUE; // Allow sort
		$this->approvaldatetime->DefaultErrorMessage = str_replace("%s", $GLOBALS["DATE_FORMAT"], $Language->phrase("IncorrectDate"));
		$this->fields['approvaldatetime'] = &$this->approvaldatetime;

		// approvalby
		$this->approvalby = new DbField('merchantmemberplan', 'merchantmemberplan', 'x_approvalby', 'approvalby', '`approvalby`', '`approvalby`', 3, 12, -1, FALSE, '`approvalby`', FALSE, FALSE, FALSE, 'FORMATTED TEXT', 'TEXT');
		$this->approvalby->Sortable = TRUE; // Allow sort
		$this->approvalby->DefaultErrorMessage = $Language->phrase("IncorrectInteger");
		$this->fields['approvalby'] = &$this->approvalby;

		// preauthorizedmemberpi
		$this->preauthorizedmemberpi = new DbField('merchantmemberplan', 'merchantmemberplan', 'x_preauthorizedmemberpi', 'preauthorizedmemberpi', '`preauthorizedmemberpi`', '`preauthorizedmemberpi`', 3, 12, -1, FALSE, '`preauthorizedmemberpi`', FALSE, FALSE, FALSE, 'FORMATTED TEXT', 'TEXT');
		$this->preauthorizedmemberpi->Nullable = FALSE; // NOT NULL field
		$this->preauthorizedmemberpi->Required = TRUE; // Required field
		$this->preauthorizedmemberpi->Sortable = TRUE; // Allow sort
		$this->preauthorizedmemberpi->DefaultErrorMessage = $Language->phrase("IncorrectInteger");
		$this->fields['preauthorizedmemberpi'] = &$this->preauthorizedmemberpi;

		// pendingpayment
		$this->pendingpayment = new DbField('merchantmemberplan', 'merchantmemberplan', 'x_pendingpayment', 'pendingpayment', '`pendingpayment`', '`pendingpayment`', 3, 1, -1, FALSE, '`pendingpayment`', FALSE, FALSE, FALSE, 'FORMATTED TEXT', 'TEXT');
		$this->pendingpayment->Nullable = FALSE; // NOT NULL field
		$this->pendingpayment->Required = TRUE; // Required field
		$this->pendingpayment->Sortable = TRUE; // Allow sort
		$this->pendingpayment->DefaultErrorMessage = $Language->phrase("IncorrectInteger");
		$this->fields['pendingpayment'] = &$this->pendingpayment;

		// lastinvoiceid
		$this->lastinvoiceid = new DbField('merchantmemberplan', 'merchantmemberplan', 'x_lastinvoiceid', 'lastinvoiceid', '`lastinvoiceid`', '`lastinvoiceid`', 3, 12, -1, FALSE, '`lastinvoiceid`', FALSE, FALSE, FALSE, 'FORMATTED TEXT', 'TEXT');
		$this->lastinvoiceid->Nullable = FALSE; // NOT NULL field
		$this->lastinvoiceid->Required = TRUE; // Required field
		$this->lastinvoiceid->Sortable = TRUE; // Allow sort
		$this->lastinvoiceid->DefaultErrorMessage = $Language->phrase("IncorrectInteger");
		$this->fields['lastinvoiceid'] = &$this->lastinvoiceid;

		// lastupdatedate
		$this->lastupdatedate = new DbField('merchantmemberplan', 'merchantmemberplan', 'x_lastupdatedate', 'lastupdatedate', '`lastupdatedate`', CastDateFieldForLike("`lastupdatedate`", 0, "DB"), 135, 19, 0, FALSE, '`lastupdatedate`', FALSE, FALSE, FALSE, 'FORMATTED TEXT', 'TEXT');
		$this->lastupdatedate->Sortable = TRUE; // Allow sort
		$this->lastupdatedate->DefaultErrorMessage = str_replace("%s", $GLOBALS["DATE_FORMAT"], $Language->phrase("IncorrectDate"));
		$this->fields['lastupdatedate'] = &$this->lastupdatedate;

		// pendingpaymentid
		$this->pendingpaymentid = new DbField('merchantmemberplan', 'merchantmemberplan', 'x_pendingpaymentid', 'pendingpaymentid', '`pendingpaymentid`', '`pendingpaymentid`', 3, 12, -1, FALSE, '`pendingpaymentid`', FALSE, FALSE, FALSE, 'FORMATTED TEXT', 'TEXT');
		$this->pendingpaymentid->Sortable = TRUE; // Allow sort
		$this->pendingpaymentid->DefaultErrorMessage = $Language->phrase("IncorrectInteger");
		$this->fields['pendingpaymentid'] = &$this->pendingpaymentid;

		// notes
		$this->notes = new DbField('merchantmemberplan', 'merchantmemberplan', 'x_notes', 'notes', '`notes`', '`notes`', 201, 300, -1, FALSE, '`notes`', FALSE, FALSE, FALSE, 'FORMATTED TEXT', 'TEXTAREA');
		$this->notes->Sortable = TRUE; // Allow sort
		$this->fields['notes'] = &$this->notes;

		// field1
		$this->field1 = new DbField('merchantmemberplan', 'merchantmemberplan', 'x_field1', 'field1', '`field1`', '`field1`', 200, 100, -1, FALSE, '`field1`', FALSE, FALSE, FALSE, 'FORMATTED TEXT', 'TEXT');
		$this->field1->Sortable = TRUE; // Allow sort
		$this->fields['field1'] = &$this->field1;

		// field2
		$this->field2 = new DbField('merchantmemberplan', 'merchantmemberplan', 'x_field2', 'field2', '`field2`', '`field2`', 200, 100, -1, FALSE, '`field2`', FALSE, FALSE, FALSE, 'FORMATTED TEXT', 'TEXT');
		$this->field2->Sortable = TRUE; // Allow sort
		$this->fields['field2'] = &$this->field2;

		// field3
		$this->field3 = new DbField('merchantmemberplan', 'merchantmemberplan', 'x_field3', 'field3', '`field3`', '`field3`', 200, 100, -1, FALSE, '`field3`', FALSE, FALSE, FALSE, 'FORMATTED TEXT', 'TEXT');
		$this->field3->Sortable = TRUE; // Allow sort
		$this->fields['field3'] = &$this->field3;

		// field4
		$this->field4 = new DbField('merchantmemberplan', 'merchantmemberplan', 'x_field4', 'field4', '`field4`', '`field4`', 200, 100, -1, FALSE, '`field4`', FALSE, FALSE, FALSE, 'FORMATTED TEXT', 'TEXT');
		$this->field4->Sortable = TRUE; // Allow sort
		$this->fields['field4'] = &$this->field4;

		// field5
		$this->field5 = new DbField('merchantmemberplan', 'merchantmemberplan', 'x_field5', 'field5', '`field5`', '`field5`', 200, 100, -1, FALSE, '`field5`', FALSE, FALSE, FALSE, 'FORMATTED TEXT', 'TEXT');
		$this->field5->Sortable = TRUE; // Allow sort
		$this->fields['field5'] = &$this->field5;

		// field6
		$this->field6 = new DbField('merchantmemberplan', 'merchantmemberplan', 'x_field6', 'field6', '`field6`', '`field6`', 200, 100, -1, FALSE, '`field6`', FALSE, FALSE, FALSE, 'FORMATTED TEXT', 'TEXT');
		$this->field6->Sortable = TRUE; // Allow sort
		$this->fields['field6'] = &$this->field6;

		// field7
		$this->field7 = new DbField('merchantmemberplan', 'merchantmemberplan', 'x_field7', 'field7', '`field7`', '`field7`', 200, 100, -1, FALSE, '`field7`', FALSE, FALSE, FALSE, 'FORMATTED TEXT', 'TEXT');
		$this->field7->Sortable = TRUE; // Allow sort
		$this->fields['field7'] = &$this->field7;

		// field8
		$this->field8 = new DbField('merchantmemberplan', 'merchantmemberplan', 'x_field8', 'field8', '`field8`', '`field8`', 200, 100, -1, FALSE, '`field8`', FALSE, FALSE, FALSE, 'FORMATTED TEXT', 'TEXT');
		$this->field8->Sortable = TRUE; // Allow sort
		$this->fields['field8'] = &$this->field8;

		// field9
		$this->field9 = new DbField('merchantmemberplan', 'merchantmemberplan', 'x_field9', 'field9', '`field9`', '`field9`', 200, 100, -1, FALSE, '`field9`', FALSE, FALSE, FALSE, 'FORMATTED TEXT', 'TEXT');
		$this->field9->Sortable = TRUE; // Allow sort
		$this->fields['field9'] = &$this->field9;

		// field10
		$this->field10 = new DbField('merchantmemberplan', 'merchantmemberplan', 'x_field10', 'field10', '`field10`', '`field10`', 200, 100, -1, FALSE, '`field10`', FALSE, FALSE, FALSE, 'FORMATTED TEXT', 'TEXT');
		$this->field10->Sortable = TRUE; // Allow sort
		$this->fields['field10'] = &$this->field10;
	}

	// Field Visibility
	public function getFieldVisibility($fldParm)
	{
		global $Security;
		return $this->$fldParm->Visible; // Returns original value
	}

	// Set left column class (must be predefined col-*-* classes of Bootstrap grid system)
	function setLeftColumnClass($class)
	{
		if (preg_match('/^col\-(\w+)\-(\d+)$/', $class, $match)) {
			$this->LeftColumnClass = $class . " col-form-label ew-label";
			$this->RightColumnClass = "col-" . $match[1] . "-" . strval(12 - (int)$match[2]);
			$this->OffsetColumnClass = $this->RightColumnClass . " " . str_replace("col-", "offset-", $class);
			$this->TableLeftColumnClass = preg_replace('/^col-\w+-(\d+)$/', "w-col-$1", $class); // Change to w-col-*
		}
	}

	// Single column sort
	public function updateSort(&$fld)
	{
		if ($this->CurrentOrder == $fld->Name) {
			$sortField = $fld->Expression;
			$lastSort = $fld->getSort();
			if ($this->CurrentOrderType == "ASC" || $this->CurrentOrderType == "DESC") {
				$thisSort = $this->CurrentOrderType;
			} else {
				$thisSort = ($lastSort == "ASC") ? "DESC" : "ASC";
			}
			$fld->setSort($thisSort);
			$this->setSessionOrderBy($sortField . " " . $thisSort); // Save to Session
		} else {
			$fld->setSort("");
		}
	}

	// Table level SQL
	public function getSqlFrom() // From
	{
		return ($this->SqlFrom != "") ? $this->SqlFrom : "`merchantmemberplan`";
	}
	public function sqlFrom() // For backward compatibility
	{
		return $this->getSqlFrom();
	}
	public function setSqlFrom($v)
	{
		$this->SqlFrom = $v;
	}
	public function getSqlSelect() // Select
	{
		return ($this->SqlSelect != "") ? $this->SqlSelect : "SELECT * FROM " . $this->getSqlFrom();
	}
	public function sqlSelect() // For backward compatibility
	{
		return $this->getSqlSelect();
	}
	public function setSqlSelect($v)
	{
		$this->SqlSelect = $v;
	}
	public function getSqlWhere() // Where
	{
		$where = ($this->SqlWhere != "") ? $this->SqlWhere : "";
		$this->TableFilter = "";
		AddFilter($where, $this->TableFilter);
		return $where;
	}
	public function sqlWhere() // For backward compatibility
	{
		return $this->getSqlWhere();
	}
	public function setSqlWhere($v)
	{
		$this->SqlWhere = $v;
	}
	public function getSqlGroupBy() // Group By
	{
		return ($this->SqlGroupBy != "") ? $this->SqlGroupBy : "";
	}
	public function sqlGroupBy() // For backward compatibility
	{
		return $this->getSqlGroupBy();
	}
	public function setSqlGroupBy($v)
	{
		$this->SqlGroupBy = $v;
	}
	public function getSqlHaving() // Having
	{
		return ($this->SqlHaving != "") ? $this->SqlHaving : "";
	}
	public function sqlHaving() // For backward compatibility
	{
		return $this->getSqlHaving();
	}
	public function setSqlHaving($v)
	{
		$this->SqlHaving = $v;
	}
	public function getSqlOrderBy() // Order By
	{
		return ($this->SqlOrderBy != "") ? $this->SqlOrderBy : "";
	}
	public function sqlOrderBy() // For backward compatibility
	{
		return $this->getSqlOrderBy();
	}
	public function setSqlOrderBy($v)
	{
		$this->SqlOrderBy = $v;
	}

	// Apply User ID filters
	public function applyUserIDFilters($filter, $id = "")
	{
		return $filter;
	}

	// Check if User ID security allows view all
	public function userIDAllow($id = "")
	{
		$allow = $this->UserIDAllowSecurity;
		switch ($id) {
			case "add":
			case "copy":
			case "gridadd":
			case "register":
			case "addopt":
				return (($allow & 1) == 1);
			case "edit":
			case "gridedit":
			case "update":
			case "changepwd":
			case "forgotpwd":
				return (($allow & 4) == 4);
			case "delete":
				return (($allow & 2) == 2);
			case "view":
				return (($allow & 32) == 32);
			case "search":
				return (($allow & 64) == 64);
			case "lookup":
				return (($allow & 256) == 256);
			default:
				return (($allow & 8) == 8);
		}
	}

	// Get recordset
	public function getRecordset($sql, $rowcnt = -1, $offset = -1)
	{
		$conn = $this->getConnection();
		$conn->raiseErrorFn = Config("ERROR_FUNC");
		$rs = $conn->selectLimit($sql, $rowcnt, $offset);
		$conn->raiseErrorFn = "";
		return $rs;
	}

	// Get record count
	public function getRecordCount($sql, $c = NULL)
	{
		$cnt = -1;
		$rs = NULL;
		$sql = preg_replace('/\/\*BeginOrderBy\*\/[\s\S]+\/\*EndOrderBy\*\//', "", $sql); // Remove ORDER BY clause (MSSQL)
		$pattern = '/^SELECT\s([\s\S]+)\sFROM\s/i';

		// Skip Custom View / SubQuery / SELECT DISTINCT / ORDER BY
		if (($this->TableType == 'TABLE' || $this->TableType == 'VIEW' || $this->TableType == 'LINKTABLE') &&
			preg_match($pattern, $sql) && !preg_match('/\(\s*(SELECT[^)]+)\)/i', $sql) &&
			!preg_match('/^\s*select\s+distinct\s+/i', $sql) && !preg_match('/\s+order\s+by\s+/i', $sql)) {
			$sqlwrk = "SELECT COUNT(*) FROM " . preg_replace($pattern, "", $sql);
		} else {
			$sqlwrk = "SELECT COUNT(*) FROM (" . $sql . ") COUNT_TABLE";
		}
		$conn = $c ?: $this->getConnection();
		if ($rs = $conn->execute($sqlwrk)) {
			if (!$rs->EOF && $rs->FieldCount() > 0) {
				$cnt = $rs->fields[0];
				$rs->close();
			}
			return (int)$cnt;
		}

		// Unable to get count, get record count directly
		if ($rs = $conn->execute($sql)) {
			$cnt = $rs->RecordCount();
			$rs->close();
			return (int)$cnt;
		}
		return $cnt;
	}

	// Get SQL
	public function getSql($where, $orderBy = "")
	{
		return BuildSelectSql($this->getSqlSelect(), $this->getSqlWhere(),
			$this->getSqlGroupBy(), $this->getSqlHaving(), $this->getSqlOrderBy(),
			$where, $orderBy);
	}

	// Table SQL
	public function getCurrentSql()
	{
		$filter = $this->CurrentFilter;
		$filter = $this->applyUserIDFilters($filter);
		$sort = $this->getSessionOrderBy();
		return $this->getSql($filter, $sort);
	}

	// Table SQL with List page filter
	public function getListSql()
	{
		$filter = $this->UseSessionForListSql ? $this->getSessionWhere() : "";
		AddFilter($filter, $this->CurrentFilter);
		$filter = $this->applyUserIDFilters($filter);
		$this->Recordset_Selecting($filter);
		$select = $this->getSqlSelect();
		$sort = $this->UseSessionForListSql ? $this->getSessionOrderBy() : "";
		return BuildSelectSql($select, $this->getSqlWhere(), $this->getSqlGroupBy(),
			$this->getSqlHaving(), $this->getSqlOrderBy(), $filter, $sort);
	}

	// Get ORDER BY clause
	public function getOrderBy()
	{
		$sort = $this->getSessionOrderBy();
		return BuildSelectSql("", "", "", "", $this->getSqlOrderBy(), "", $sort);
	}

	// Get record count based on filter (for detail record count in master table pages)
	public function loadRecordCount($filter)
	{
		$origFilter = $this->CurrentFilter;
		$this->CurrentFilter = $filter;
		$this->Recordset_Selecting($this->CurrentFilter);
		$select = $this->TableType == 'CUSTOMVIEW' ? $this->getSqlSelect() : "SELECT * FROM " . $this->getSqlFrom();
		$groupBy = $this->TableType == 'CUSTOMVIEW' ? $this->getSqlGroupBy() : "";
		$having = $this->TableType == 'CUSTOMVIEW' ? $this->getSqlHaving() : "";
		$sql = BuildSelectSql($select, $this->getSqlWhere(), $groupBy, $having, "", $this->CurrentFilter, "");
		$cnt = $this->getRecordCount($sql);
		$this->CurrentFilter = $origFilter;
		return $cnt;
	}

	// Get record count (for current List page)
	public function listRecordCount()
	{
		$filter = $this->getSessionWhere();
		AddFilter($filter, $this->CurrentFilter);
		$filter = $this->applyUserIDFilters($filter);
		$this->Recordset_Selecting($filter);
		$select = $this->TableType == 'CUSTOMVIEW' ? $this->getSqlSelect() : "SELECT * FROM " . $this->getSqlFrom();
		$groupBy = $this->TableType == 'CUSTOMVIEW' ? $this->getSqlGroupBy() : "";
		$having = $this->TableType == 'CUSTOMVIEW' ? $this->getSqlHaving() : "";
		$sql = BuildSelectSql($select, $this->getSqlWhere(), $groupBy, $having, "", $filter, "");
		$cnt = $this->getRecordCount($sql);
		return $cnt;
	}

	// INSERT statement
	protected function insertSql(&$rs)
	{
		$names = "";
		$values = "";
		foreach ($rs as $name => $value) {
			if (!isset($this->fields[$name]) || $this->fields[$name]->IsCustom)
				continue;
			$names .= $this->fields[$name]->Expression . ",";
			$values .= QuotedValue($value, $this->fields[$name]->DataType, $this->Dbid) . ",";
		}
		$names = preg_replace('/,+$/', "", $names);
		$values = preg_replace('/,+$/', "", $values);
		return "INSERT INTO " . $this->UpdateTable . " (" . $names . ") VALUES (" . $values . ")";
	}

	// Insert
	public function insert(&$rs)
	{
		$conn = $this->getConnection();
		$success = $conn->execute($this->insertSql($rs));
		if ($success) {

			// Get insert id if necessary
			$this->subscriptionplanid->setDbValue($conn->insert_ID());
			$rs['subscriptionplanid'] = $this->subscriptionplanid->DbValue;
			if ($this->AuditTrailOnAdd)
				$this->writeAuditTrailOnAdd($rs);
		}
		return $success;
	}

	// UPDATE statement
	protected function updateSql(&$rs, $where = "", $curfilter = TRUE)
	{
		$sql = "UPDATE " . $this->UpdateTable . " SET ";
		foreach ($rs as $name => $value) {
			if (!isset($this->fields[$name]) || $this->fields[$name]->IsCustom || $this->fields[$name]->IsAutoIncrement)
				continue;
			$sql .= $this->fields[$name]->Expression . "=";
			$sql .= QuotedValue($value, $this->fields[$name]->DataType, $this->Dbid) . ",";
		}
		$sql = preg_replace('/,+$/', "", $sql);
		$filter = ($curfilter) ? $this->CurrentFilter : "";
		if (is_array($where))
			$where = $this->arrayToFilter($where);
		AddFilter($filter, $where);
		if ($filter != "")
			$sql .= " WHERE " . $filter;
		return $sql;
	}

	// Update
	public function update(&$rs, $where = "", $rsold = NULL, $curfilter = TRUE)
	{
		$conn = $this->getConnection();
		$success = $conn->execute($this->updateSql($rs, $where, $curfilter));
		if ($success && $this->AuditTrailOnEdit && $rsold) {
			$rsaudit = $rs;
			$fldname = 'subscriptionplanid';
			if (!array_key_exists($fldname, $rsaudit))
				$rsaudit[$fldname] = $rsold[$fldname];
			$this->writeAuditTrailOnEdit($rsold, $rsaudit);
		}
		return $success;
	}

	// DELETE statement
	protected function deleteSql(&$rs, $where = "", $curfilter = TRUE)
	{
		$sql = "DELETE FROM " . $this->UpdateTable . " WHERE ";
		if (is_array($where))
			$where = $this->arrayToFilter($where);
		if ($rs) {
			if (array_key_exists('subscriptionplanid', $rs))
				AddFilter($where, QuotedName('subscriptionplanid', $this->Dbid) . '=' . QuotedValue($rs['subscriptionplanid'], $this->subscriptionplanid->DataType, $this->Dbid));
		}
		$filter = ($curfilter) ? $this->CurrentFilter : "";
		AddFilter($filter, $where);
		if ($filter != "")
			$sql .= $filter;
		else
			$sql .= "0=1"; // Avoid delete
		return $sql;
	}

	// Delete
	public function delete(&$rs, $where = "", $curfilter = FALSE)
	{
		$success = TRUE;
		$conn = $this->getConnection();
		if ($success)
			$success = $conn->execute($this->deleteSql($rs, $where, $curfilter));
		if ($success && $this->AuditTrailOnDelete)
			$this->writeAuditTrailOnDelete($rs);
		return $success;
	}

	// Load DbValue from recordset or array
	protected function loadDbValues(&$rs)
	{
		if (!$rs || !is_array($rs) && $rs->EOF)
			return;
		$row = is_array($rs) ? $rs : $rs->fields;
		$this->subscriptionplanid->DbValue = $row['subscriptionplanid'];
		$this->merchantid->DbValue = $row['merchantid'];
		$this->memberid->DbValue = $row['memberid'];
		$this->planid->DbValue = $row['planid'];
		$this->registrationdate->DbValue = $row['registrationdate'];
		$this->paymentdate->DbValue = $row['paymentdate'];
		$this->effectivedate->DbValue = $row['effectivedate'];
		$this->willexpire->DbValue = $row['willexpire'];
		$this->expirydate->DbValue = $row['expirydate'];
		$this->renewalrequired->DbValue = $row['renewalrequired'];
		$this->planidforrenewal->DbValue = $row['planidforrenewal'];
		$this->planstatus->DbValue = $row['planstatus'];
		$this->planstatusdate->DbValue = $row['planstatusdate'];
		$this->approvalstatus->DbValue = $row['approvalstatus'];
		$this->approvaldatetime->DbValue = $row['approvaldatetime'];
		$this->approvalby->DbValue = $row['approvalby'];
		$this->preauthorizedmemberpi->DbValue = $row['preauthorizedmemberpi'];
		$this->pendingpayment->DbValue = $row['pendingpayment'];
		$this->lastinvoiceid->DbValue = $row['lastinvoiceid'];
		$this->lastupdatedate->DbValue = $row['lastupdatedate'];
		$this->pendingpaymentid->DbValue = $row['pendingpaymentid'];
		$this->notes->DbValue = $row['notes'];
		$this->field1->DbValue = $row['field1'];
		$this->field2->DbValue = $row['field2'];
		$this->field3->DbValue = $row['field3'];
		$this->field4->DbValue = $row['field4'];
		$this->field5->DbValue = $row['field5'];
		$this->field6->DbValue = $row['field6'];
		$this->field7->DbValue = $row['field7'];
		$this->field8->DbValue = $row['field8'];
		$this->field9->DbValue = $row['field9'];
		$this->field10->DbValue = $row['field10'];
	}

	// Delete uploaded files
	public function deleteUploadedFiles($row)
	{
		$this->loadDbValues($row);
	}

	// Record filter WHERE clause
	protected function sqlKeyFilter()
	{
		return "`subscriptionplanid` = @subscriptionplanid@";
	}

	// Get record filter
	public function getRecordFilter($row = NULL)
	{
		$keyFilter = $this->sqlKeyFilter();
		if (is_array($row))
			$val = array_key_exists('subscriptionplanid', $row) ? $row['subscriptionplanid'] : NULL;
		else
			$val = $this->subscriptionplanid->OldValue !== NULL ? $this->subscriptionplanid->OldValue : $this->subscriptionplanid->CurrentValue;
		if (!is_numeric($val))
			return "0=1"; // Invalid key
		if ($val == NULL)
			return "0=1"; // Invalid key
		else
			$keyFilter = str_replace("@subscriptionplanid@", AdjustSql($val, $this->Dbid), $keyFilter); // Replace key value
		return $keyFilter;
	}

	// Return page URL
	public function getReturnUrl()
	{
		$name = PROJECT_NAME . "_" . $this->TableVar . "_" . Config("TABLE_RETURN_URL");

		// Get referer URL automatically
		if (ServerVar("HTTP_REFERER") != "" && ReferPageName() != CurrentPageName() && ReferPageName() != "login.php") // Referer not same page or login page
			$_SESSION[$name] = ServerVar("HTTP_REFERER"); // Save to Session
		if (@$_SESSION[$name] != "") {
			return $_SESSION[$name];
		} else {
			return "merchantmemberplanlist.php";
		}
	}
	public function setReturnUrl($v)
	{
		$_SESSION[PROJECT_NAME . "_" . $this->TableVar . "_" . Config("TABLE_RETURN_URL")] = $v;
	}

	// Get modal caption
	public function getModalCaption($pageName)
	{
		global $Language;
		if ($pageName == "merchantmemberplanview.php")
			return $Language->phrase("View");
		elseif ($pageName == "merchantmemberplanedit.php")
			return $Language->phrase("Edit");
		elseif ($pageName == "merchantmemberplanadd.php")
			return $Language->phrase("Add");
		else
			return "";
	}

	// List URL
	public function getListUrl()
	{
		return "merchantmemberplanlist.php";
	}

	// View URL
	public function getViewUrl($parm = "")
	{
		if ($parm != "")
			$url = $this->keyUrl("merchantmemberplanview.php", $this->getUrlParm($parm));
		else
			$url = $this->keyUrl("merchantmemberplanview.php", $this->getUrlParm(Config("TABLE_SHOW_DETAIL") . "="));
		return $this->addMasterUrl($url);
	}

	// Add URL
	public function getAddUrl($parm = "")
	{
		if ($parm != "")
			$url = "merchantmemberplanadd.php?" . $this->getUrlParm($parm);
		else
			$url = "merchantmemberplanadd.php";
		return $this->addMasterUrl($url);
	}

	// Edit URL
	public function getEditUrl($parm = "")
	{
		$url = $this->keyUrl("merchantmemberplanedit.php", $this->getUrlParm($parm));
		return $this->addMasterUrl($url);
	}

	// Inline edit URL
	public function getInlineEditUrl()
	{
		$url = $this->keyUrl(CurrentPageName(), $this->getUrlParm("action=edit"));
		return $this->addMasterUrl($url);
	}

	// Copy URL
	public function getCopyUrl($parm = "")
	{
		$url = $this->keyUrl("merchantmemberplanadd.php", $this->getUrlParm($parm));
		return $this->addMasterUrl($url);
	}

	// Inline copy URL
	public function getInlineCopyUrl()
	{
		$url = $this->keyUrl(CurrentPageName(), $this->getUrlParm("action=copy"));
		return $this->addMasterUrl($url);
	}

	// Delete URL
	public function getDeleteUrl()
	{
		return $this->keyUrl("merchantmemberplandelete.php", $this->getUrlParm());
	}

	// Add master url
	public function addMasterUrl($url)
	{
		return $url;
	}
	public function keyToJson($htmlEncode = FALSE)
	{
		$json = "";
		$json .= "subscriptionplanid:" . JsonEncode($this->subscriptionplanid->CurrentValue, "number");
		$json = "{" . $json . "}";
		if ($htmlEncode)
			$json = HtmlEncode($json);
		return $json;
	}

	// Add key value to URL
	public function keyUrl($url, $parm = "")
	{
		$url = $url . "?";
		if ($parm != "")
			$url .= $parm . "&";
		if ($this->subscriptionplanid->CurrentValue != NULL) {
			$url .= "subscriptionplanid=" . urlencode($this->subscriptionplanid->CurrentValue);
		} else {
			return "javascript:ew.alert(ew.language.phrase('InvalidRecord'));";
		}
		return $url;
	}

	// Sort URL
	public function sortUrl(&$fld)
	{
		if ($this->CurrentAction || $this->isExport() ||
			in_array($fld->Type, [128, 204, 205])) { // Unsortable data type
				return "";
		} elseif ($fld->Sortable) {
			$urlParm = $this->getUrlParm("order=" . urlencode($fld->Name) . "&amp;ordertype=" . $fld->reverseSort());
			return $this->addMasterUrl(CurrentPageName() . "?" . $urlParm);
		} else {
			return "";
		}
	}

	// Get record keys from Post/Get/Session
	public function getRecordKeys()
	{
		$arKeys = [];
		$arKey = [];
		if (Param("key_m") !== NULL) {
			$arKeys = Param("key_m");
			$cnt = count($arKeys);
		} else {
			if (Param("subscriptionplanid") !== NULL)
				$arKeys[] = Param("subscriptionplanid");
			elseif (IsApi() && Key(0) !== NULL)
				$arKeys[] = Key(0);
			elseif (IsApi() && Route(2) !== NULL)
				$arKeys[] = Route(2);
			else
				$arKeys = NULL; // Do not setup

			//return $arKeys; // Do not return yet, so the values will also be checked by the following code
		}

		// Check keys
		$ar = [];
		if (is_array($arKeys)) {
			foreach ($arKeys as $key) {
				if (!is_numeric($key))
					continue;
				$ar[] = $key;
			}
		}
		return $ar;
	}

	// Get filter from record keys
	public function getFilterFromRecordKeys($setCurrent = TRUE)
	{
		$arKeys = $this->getRecordKeys();
		$keyFilter = "";
		foreach ($arKeys as $key) {
			if ($keyFilter != "") $keyFilter .= " OR ";
			if ($setCurrent)
				$this->subscriptionplanid->CurrentValue = $key;
			else
				$this->subscriptionplanid->OldValue = $key;
			$keyFilter .= "(" . $this->getRecordFilter() . ")";
		}
		return $keyFilter;
	}

	// Load rows based on filter
	public function &loadRs($filter)
	{

		// Set up filter (WHERE Clause)
		$sql = $this->getSql($filter);
		$conn = $this->getConnection();
		$rs = $conn->execute($sql);
		return $rs;
	}

	// Load row values from recordset
	public function loadListRowValues(&$rs)
	{
		$this->subscriptionplanid->setDbValue($rs->fields('subscriptionplanid'));
		$this->merchantid->setDbValue($rs->fields('merchantid'));
		$this->memberid->setDbValue($rs->fields('memberid'));
		$this->planid->setDbValue($rs->fields('planid'));
		$this->registrationdate->setDbValue($rs->fields('registrationdate'));
		$this->paymentdate->setDbValue($rs->fields('paymentdate'));
		$this->effectivedate->setDbValue($rs->fields('effectivedate'));
		$this->willexpire->setDbValue($rs->fields('willexpire'));
		$this->expirydate->setDbValue($rs->fields('expirydate'));
		$this->renewalrequired->setDbValue($rs->fields('renewalrequired'));
		$this->planidforrenewal->setDbValue($rs->fields('planidforrenewal'));
		$this->planstatus->setDbValue($rs->fields('planstatus'));
		$this->planstatusdate->setDbValue($rs->fields('planstatusdate'));
		$this->approvalstatus->setDbValue($rs->fields('approvalstatus'));
		$this->approvaldatetime->setDbValue($rs->fields('approvaldatetime'));
		$this->approvalby->setDbValue($rs->fields('approvalby'));
		$this->preauthorizedmemberpi->setDbValue($rs->fields('preauthorizedmemberpi'));
		$this->pendingpayment->setDbValue($rs->fields('pendingpayment'));
		$this->lastinvoiceid->setDbValue($rs->fields('lastinvoiceid'));
		$this->lastupdatedate->setDbValue($rs->fields('lastupdatedate'));
		$this->pendingpaymentid->setDbValue($rs->fields('pendingpaymentid'));
		$this->notes->setDbValue($rs->fields('notes'));
		$this->field1->setDbValue($rs->fields('field1'));
		$this->field2->setDbValue($rs->fields('field2'));
		$this->field3->setDbValue($rs->fields('field3'));
		$this->field4->setDbValue($rs->fields('field4'));
		$this->field5->setDbValue($rs->fields('field5'));
		$this->field6->setDbValue($rs->fields('field6'));
		$this->field7->setDbValue($rs->fields('field7'));
		$this->field8->setDbValue($rs->fields('field8'));
		$this->field9->setDbValue($rs->fields('field9'));
		$this->field10->setDbValue($rs->fields('field10'));
	}

	// Render list row values
	public function renderListRow()
	{
		global $Security, $CurrentLanguage, $Language;

		// Call Row Rendering event
		$this->Row_Rendering();

		// Common render codes
		// subscriptionplanid
		// merchantid
		// memberid
		// planid
		// registrationdate
		// paymentdate
		// effectivedate
		// willexpire
		// expirydate
		// renewalrequired
		// planidforrenewal
		// planstatus
		// planstatusdate
		// approvalstatus
		// approvaldatetime
		// approvalby
		// preauthorizedmemberpi
		// pendingpayment
		// lastinvoiceid
		// lastupdatedate
		// pendingpaymentid
		// notes
		// field1
		// field2
		// field3
		// field4
		// field5
		// field6
		// field7
		// field8
		// field9
		// field10
		// subscriptionplanid

		$this->subscriptionplanid->ViewValue = $this->subscriptionplanid->CurrentValue;
		$this->subscriptionplanid->ViewCustomAttributes = "";

		// merchantid
		$this->merchantid->ViewValue = $this->merchantid->CurrentValue;
		$this->merchantid->ViewCustomAttributes = "";

		// memberid
		$this->memberid->ViewValue = $this->memberid->CurrentValue;
		$this->memberid->ViewCustomAttributes = "";

		// planid
		$this->planid->ViewValue = $this->planid->CurrentValue;
		$this->planid->ViewCustomAttributes = "";

		// registrationdate
		$this->registrationdate->ViewValue = $this->registrationdate->CurrentValue;
		$this->registrationdate->ViewValue = FormatDateTime($this->registrationdate->ViewValue, 0);
		$this->registrationdate->ViewCustomAttributes = "";

		// paymentdate
		$this->paymentdate->ViewValue = $this->paymentdate->CurrentValue;
		$this->paymentdate->ViewValue = FormatDateTime($this->paymentdate->ViewValue, 0);
		$this->paymentdate->ViewCustomAttributes = "";

		// effectivedate
		$this->effectivedate->ViewValue = $this->effectivedate->CurrentValue;
		$this->effectivedate->ViewValue = FormatDateTime($this->effectivedate->ViewValue, 0);
		$this->effectivedate->ViewCustomAttributes = "";

		// willexpire
		$this->willexpire->ViewValue = $this->willexpire->CurrentValue;
		$this->willexpire->ViewCustomAttributes = "";

		// expirydate
		$this->expirydate->ViewValue = $this->expirydate->CurrentValue;
		$this->expirydate->ViewValue = FormatDateTime($this->expirydate->ViewValue, 0);
		$this->expirydate->ViewCustomAttributes = "";

		// renewalrequired
		$this->renewalrequired->ViewValue = $this->renewalrequired->CurrentValue;
		$this->renewalrequired->ViewCustomAttributes = "";

		// planidforrenewal
		$this->planidforrenewal->ViewValue = $this->planidforrenewal->CurrentValue;
		$this->planidforrenewal->ViewCustomAttributes = "";

		// planstatus
		$this->planstatus->ViewValue = $this->planstatus->CurrentValue;
		$this->planstatus->ViewCustomAttributes = "";

		// planstatusdate
		$this->planstatusdate->ViewValue = $this->planstatusdate->CurrentValue;
		$this->planstatusdate->ViewValue = FormatDateTime($this->planstatusdate->ViewValue, 0);
		$this->planstatusdate->ViewCustomAttributes = "";

		// approvalstatus
		$this->approvalstatus->ViewValue = $this->approvalstatus->CurrentValue;
		$this->approvalstatus->ViewCustomAttributes = "";

		// approvaldatetime
		$this->approvaldatetime->ViewValue = $this->approvaldatetime->CurrentValue;
		$this->approvaldatetime->ViewValue = FormatDateTime($this->approvaldatetime->ViewValue, 0);
		$this->approvaldatetime->ViewCustomAttributes = "";

		// approvalby
		$this->approvalby->ViewValue = $this->approvalby->CurrentValue;
		$this->approvalby->ViewCustomAttributes = "";

		// preauthorizedmemberpi
		$this->preauthorizedmemberpi->ViewValue = $this->preauthorizedmemberpi->CurrentValue;
		$this->preauthorizedmemberpi->ViewCustomAttributes = "";

		// pendingpayment
		$this->pendingpayment->ViewValue = $this->pendingpayment->CurrentValue;
		$this->pendingpayment->ViewCustomAttributes = "";

		// lastinvoiceid
		$this->lastinvoiceid->ViewValue = $this->lastinvoiceid->CurrentValue;
		$this->lastinvoiceid->ViewCustomAttributes = "";

		// lastupdatedate
		$this->lastupdatedate->ViewValue = $this->lastupdatedate->CurrentValue;
		$this->lastupdatedate->ViewValue = FormatDateTime($this->lastupdatedate->ViewValue, 0);
		$this->lastupdatedate->ViewCustomAttributes = "";

		// pendingpaymentid
		$this->pendingpaymentid->ViewValue = $this->pendingpaymentid->CurrentValue;
		$this->pendingpaymentid->ViewCustomAttributes = "";

		// notes
		$this->notes->ViewValue = $this->notes->CurrentValue;
		$this->notes->ViewCustomAttributes = "";

		// field1
		$this->field1->ViewValue = $this->field1->CurrentValue;
		$this->field1->ViewCustomAttributes = "";

		// field2
		$this->field2->ViewValue = $this->field2->CurrentValue;
		$this->field2->ViewCustomAttributes = "";

		// field3
		$this->field3->ViewValue = $this->field3->CurrentValue;
		$this->field3->ViewCustomAttributes = "";

		// field4
		$this->field4->ViewValue = $this->field4->CurrentValue;
		$this->field4->ViewCustomAttributes = "";

		// field5
		$this->field5->ViewValue = $this->field5->CurrentValue;
		$this->field5->ViewCustomAttributes = "";

		// field6
		$this->field6->ViewValue = $this->field6->CurrentValue;
		$this->field6->ViewCustomAttributes = "";

		// field7
		$this->field7->ViewValue = $this->field7->CurrentValue;
		$this->field7->ViewCustomAttributes = "";

		// field8
		$this->field8->ViewValue = $this->field8->CurrentValue;
		$this->field8->ViewCustomAttributes = "";

		// field9
		$this->field9->ViewValue = $this->field9->CurrentValue;
		$this->field9->ViewCustomAttributes = "";

		// field10
		$this->field10->ViewValue = $this->field10->CurrentValue;
		$this->field10->ViewCustomAttributes = "";

		// subscriptionplanid
		$this->subscriptionplanid->LinkCustomAttributes = "";
		$this->subscriptionplanid->HrefValue = "";
		$this->subscriptionplanid->TooltipValue = "";

		// merchantid
		$this->merchantid->LinkCustomAttributes = "";
		$this->merchantid->HrefValue = "";
		$this->merchantid->TooltipValue = "";

		// memberid
		$this->memberid->LinkCustomAttributes = "";
		$this->memberid->HrefValue = "";
		$this->memberid->TooltipValue = "";

		// planid
		$this->planid->LinkCustomAttributes = "";
		$this->planid->HrefValue = "";
		$this->planid->TooltipValue = "";

		// registrationdate
		$this->registrationdate->LinkCustomAttributes = "";
		$this->registrationdate->HrefValue = "";
		$this->registrationdate->TooltipValue = "";

		// paymentdate
		$this->paymentdate->LinkCustomAttributes = "";
		$this->paymentdate->HrefValue = "";
		$this->paymentdate->TooltipValue = "";

		// effectivedate
		$this->effectivedate->LinkCustomAttributes = "";
		$this->effectivedate->HrefValue = "";
		$this->effectivedate->TooltipValue = "";

		// willexpire
		$this->willexpire->LinkCustomAttributes = "";
		$this->willexpire->HrefValue = "";
		$this->willexpire->TooltipValue = "";

		// expirydate
		$this->expirydate->LinkCustomAttributes = "";
		$this->expirydate->HrefValue = "";
		$this->expirydate->TooltipValue = "";

		// renewalrequired
		$this->renewalrequired->LinkCustomAttributes = "";
		$this->renewalrequired->HrefValue = "";
		$this->renewalrequired->TooltipValue = "";

		// planidforrenewal
		$this->planidforrenewal->LinkCustomAttributes = "";
		$this->planidforrenewal->HrefValue = "";
		$this->planidforrenewal->TooltipValue = "";

		// planstatus
		$this->planstatus->LinkCustomAttributes = "";
		$this->planstatus->HrefValue = "";
		$this->planstatus->TooltipValue = "";

		// planstatusdate
		$this->planstatusdate->LinkCustomAttributes = "";
		$this->planstatusdate->HrefValue = "";
		$this->planstatusdate->TooltipValue = "";

		// approvalstatus
		$this->approvalstatus->LinkCustomAttributes = "";
		$this->approvalstatus->HrefValue = "";
		$this->approvalstatus->TooltipValue = "";

		// approvaldatetime
		$this->approvaldatetime->LinkCustomAttributes = "";
		$this->approvaldatetime->HrefValue = "";
		$this->approvaldatetime->TooltipValue = "";

		// approvalby
		$this->approvalby->LinkCustomAttributes = "";
		$this->approvalby->HrefValue = "";
		$this->approvalby->TooltipValue = "";

		// preauthorizedmemberpi
		$this->preauthorizedmemberpi->LinkCustomAttributes = "";
		$this->preauthorizedmemberpi->HrefValue = "";
		$this->preauthorizedmemberpi->TooltipValue = "";

		// pendingpayment
		$this->pendingpayment->LinkCustomAttributes = "";
		$this->pendingpayment->HrefValue = "";
		$this->pendingpayment->TooltipValue = "";

		// lastinvoiceid
		$this->lastinvoiceid->LinkCustomAttributes = "";
		$this->lastinvoiceid->HrefValue = "";
		$this->lastinvoiceid->TooltipValue = "";

		// lastupdatedate
		$this->lastupdatedate->LinkCustomAttributes = "";
		$this->lastupdatedate->HrefValue = "";
		$this->lastupdatedate->TooltipValue = "";

		// pendingpaymentid
		$this->pendingpaymentid->LinkCustomAttributes = "";
		$this->pendingpaymentid->HrefValue = "";
		$this->pendingpaymentid->TooltipValue = "";

		// notes
		$this->notes->LinkCustomAttributes = "";
		$this->notes->HrefValue = "";
		$this->notes->TooltipValue = "";

		// field1
		$this->field1->LinkCustomAttributes = "";
		$this->field1->HrefValue = "";
		$this->field1->TooltipValue = "";

		// field2
		$this->field2->LinkCustomAttributes = "";
		$this->field2->HrefValue = "";
		$this->field2->TooltipValue = "";

		// field3
		$this->field3->LinkCustomAttributes = "";
		$this->field3->HrefValue = "";
		$this->field3->TooltipValue = "";

		// field4
		$this->field4->LinkCustomAttributes = "";
		$this->field4->HrefValue = "";
		$this->field4->TooltipValue = "";

		// field5
		$this->field5->LinkCustomAttributes = "";
		$this->field5->HrefValue = "";
		$this->field5->TooltipValue = "";

		// field6
		$this->field6->LinkCustomAttributes = "";
		$this->field6->HrefValue = "";
		$this->field6->TooltipValue = "";

		// field7
		$this->field7->LinkCustomAttributes = "";
		$this->field7->HrefValue = "";
		$this->field7->TooltipValue = "";

		// field8
		$this->field8->LinkCustomAttributes = "";
		$this->field8->HrefValue = "";
		$this->field8->TooltipValue = "";

		// field9
		$this->field9->LinkCustomAttributes = "";
		$this->field9->HrefValue = "";
		$this->field9->TooltipValue = "";

		// field10
		$this->field10->LinkCustomAttributes = "";
		$this->field10->HrefValue = "";
		$this->field10->TooltipValue = "";

		// Call Row Rendered event
		$this->Row_Rendered();

		// Save data for Custom Template
		$this->Rows[] = $this->customTemplateFieldValues();
	}

	// Render edit row values
	public function renderEditRow()
	{
		global $Security, $CurrentLanguage, $Language;

		// Call Row Rendering event
		$this->Row_Rendering();

		// subscriptionplanid
		$this->subscriptionplanid->EditAttrs["class"] = "form-control";
		$this->subscriptionplanid->EditCustomAttributes = "";
		$this->subscriptionplanid->EditValue = $this->subscriptionplanid->CurrentValue;
		$this->subscriptionplanid->ViewCustomAttributes = "";

		// merchantid
		$this->merchantid->EditAttrs["class"] = "form-control";
		$this->merchantid->EditCustomAttributes = "";
		$this->merchantid->EditValue = $this->merchantid->CurrentValue;
		$this->merchantid->PlaceHolder = RemoveHtml($this->merchantid->caption());

		// memberid
		$this->memberid->EditAttrs["class"] = "form-control";
		$this->memberid->EditCustomAttributes = "";
		$this->memberid->EditValue = $this->memberid->CurrentValue;
		$this->memberid->PlaceHolder = RemoveHtml($this->memberid->caption());

		// planid
		$this->planid->EditAttrs["class"] = "form-control";
		$this->planid->EditCustomAttributes = "";
		$this->planid->EditValue = $this->planid->CurrentValue;
		$this->planid->PlaceHolder = RemoveHtml($this->planid->caption());

		// registrationdate
		$this->registrationdate->EditAttrs["class"] = "form-control";
		$this->registrationdate->EditCustomAttributes = "";
		$this->registrationdate->EditValue = FormatDateTime($this->registrationdate->CurrentValue, 8);
		$this->registrationdate->PlaceHolder = RemoveHtml($this->registrationdate->caption());

		// paymentdate
		$this->paymentdate->EditAttrs["class"] = "form-control";
		$this->paymentdate->EditCustomAttributes = "";
		$this->paymentdate->EditValue = FormatDateTime($this->paymentdate->CurrentValue, 8);
		$this->paymentdate->PlaceHolder = RemoveHtml($this->paymentdate->caption());

		// effectivedate
		$this->effectivedate->EditAttrs["class"] = "form-control";
		$this->effectivedate->EditCustomAttributes = "";
		$this->effectivedate->EditValue = FormatDateTime($this->effectivedate->CurrentValue, 8);
		$this->effectivedate->PlaceHolder = RemoveHtml($this->effectivedate->caption());

		// willexpire
		$this->willexpire->EditAttrs["class"] = "form-control";
		$this->willexpire->EditCustomAttributes = "";
		$this->willexpire->EditValue = $this->willexpire->CurrentValue;
		$this->willexpire->PlaceHolder = RemoveHtml($this->willexpire->caption());

		// expirydate
		$this->expirydate->EditAttrs["class"] = "form-control";
		$this->expirydate->EditCustomAttributes = "";
		$this->expirydate->EditValue = FormatDateTime($this->expirydate->CurrentValue, 8);
		$this->expirydate->PlaceHolder = RemoveHtml($this->expirydate->caption());

		// renewalrequired
		$this->renewalrequired->EditAttrs["class"] = "form-control";
		$this->renewalrequired->EditCustomAttributes = "";
		$this->renewalrequired->EditValue = $this->renewalrequired->CurrentValue;
		$this->renewalrequired->PlaceHolder = RemoveHtml($this->renewalrequired->caption());

		// planidforrenewal
		$this->planidforrenewal->EditAttrs["class"] = "form-control";
		$this->planidforrenewal->EditCustomAttributes = "";
		$this->planidforrenewal->EditValue = $this->planidforrenewal->CurrentValue;
		$this->planidforrenewal->PlaceHolder = RemoveHtml($this->planidforrenewal->caption());

		// planstatus
		$this->planstatus->EditAttrs["class"] = "form-control";
		$this->planstatus->EditCustomAttributes = "";
		$this->planstatus->EditValue = $this->planstatus->CurrentValue;
		$this->planstatus->PlaceHolder = RemoveHtml($this->planstatus->caption());

		// planstatusdate
		$this->planstatusdate->EditAttrs["class"] = "form-control";
		$this->planstatusdate->EditCustomAttributes = "";
		$this->planstatusdate->EditValue = FormatDateTime($this->planstatusdate->CurrentValue, 8);
		$this->planstatusdate->PlaceHolder = RemoveHtml($this->planstatusdate->caption());

		// approvalstatus
		$this->approvalstatus->EditAttrs["class"] = "form-control";
		$this->approvalstatus->EditCustomAttributes = "";
		$this->approvalstatus->EditValue = $this->approvalstatus->CurrentValue;
		$this->approvalstatus->PlaceHolder = RemoveHtml($this->approvalstatus->caption());

		// approvaldatetime
		$this->approvaldatetime->EditAttrs["class"] = "form-control";
		$this->approvaldatetime->EditCustomAttributes = "";
		$this->approvaldatetime->EditValue = FormatDateTime($this->approvaldatetime->CurrentValue, 8);
		$this->approvaldatetime->PlaceHolder = RemoveHtml($this->approvaldatetime->caption());

		// approvalby
		$this->approvalby->EditAttrs["class"] = "form-control";
		$this->approvalby->EditCustomAttributes = "";
		$this->approvalby->EditValue = $this->approvalby->CurrentValue;
		$this->approvalby->PlaceHolder = RemoveHtml($this->approvalby->caption());

		// preauthorizedmemberpi
		$this->preauthorizedmemberpi->EditAttrs["class"] = "form-control";
		$this->preauthorizedmemberpi->EditCustomAttributes = "";
		$this->preauthorizedmemberpi->EditValue = $this->preauthorizedmemberpi->CurrentValue;
		$this->preauthorizedmemberpi->PlaceHolder = RemoveHtml($this->preauthorizedmemberpi->caption());

		// pendingpayment
		$this->pendingpayment->EditAttrs["class"] = "form-control";
		$this->pendingpayment->EditCustomAttributes = "";
		$this->pendingpayment->EditValue = $this->pendingpayment->CurrentValue;
		$this->pendingpayment->PlaceHolder = RemoveHtml($this->pendingpayment->caption());

		// lastinvoiceid
		$this->lastinvoiceid->EditAttrs["class"] = "form-control";
		$this->lastinvoiceid->EditCustomAttributes = "";
		$this->lastinvoiceid->EditValue = $this->lastinvoiceid->CurrentValue;
		$this->lastinvoiceid->PlaceHolder = RemoveHtml($this->lastinvoiceid->caption());

		// lastupdatedate
		$this->lastupdatedate->EditAttrs["class"] = "form-control";
		$this->lastupdatedate->EditCustomAttributes = "";
		$this->lastupdatedate->EditValue = FormatDateTime($this->lastupdatedate->CurrentValue, 8);
		$this->lastupdatedate->PlaceHolder = RemoveHtml($this->lastupdatedate->caption());

		// pendingpaymentid
		$this->pendingpaymentid->EditAttrs["class"] = "form-control";
		$this->pendingpaymentid->EditCustomAttributes = "";
		$this->pendingpaymentid->EditValue = $this->pendingpaymentid->CurrentValue;
		$this->pendingpaymentid->PlaceHolder = RemoveHtml($this->pendingpaymentid->caption());

		// notes
		$this->notes->EditAttrs["class"] = "form-control";
		$this->notes->EditCustomAttributes = "";
		$this->notes->EditValue = $this->notes->CurrentValue;
		$this->notes->PlaceHolder = RemoveHtml($this->notes->caption());

		// field1
		$this->field1->EditAttrs["class"] = "form-control";
		$this->field1->EditCustomAttributes = "";
		if (!$this->field1->Raw)
			$this->field1->CurrentValue = HtmlDecode($this->field1->CurrentValue);
		$this->field1->EditValue = $this->field1->CurrentValue;
		$this->field1->PlaceHolder = RemoveHtml($this->field1->caption());

		// field2
		$this->field2->EditAttrs["class"] = "form-control";
		$this->field2->EditCustomAttributes = "";
		if (!$this->field2->Raw)
			$this->field2->CurrentValue = HtmlDecode($this->field2->CurrentValue);
		$this->field2->EditValue = $this->field2->CurrentValue;
		$this->field2->PlaceHolder = RemoveHtml($this->field2->caption());

		// field3
		$this->field3->EditAttrs["class"] = "form-control";
		$this->field3->EditCustomAttributes = "";
		if (!$this->field3->Raw)
			$this->field3->CurrentValue = HtmlDecode($this->field3->CurrentValue);
		$this->field3->EditValue = $this->field3->CurrentValue;
		$this->field3->PlaceHolder = RemoveHtml($this->field3->caption());

		// field4
		$this->field4->EditAttrs["class"] = "form-control";
		$this->field4->EditCustomAttributes = "";
		if (!$this->field4->Raw)
			$this->field4->CurrentValue = HtmlDecode($this->field4->CurrentValue);
		$this->field4->EditValue = $this->field4->CurrentValue;
		$this->field4->PlaceHolder = RemoveHtml($this->field4->caption());

		// field5
		$this->field5->EditAttrs["class"] = "form-control";
		$this->field5->EditCustomAttributes = "";
		if (!$this->field5->Raw)
			$this->field5->CurrentValue = HtmlDecode($this->field5->CurrentValue);
		$this->field5->EditValue = $this->field5->CurrentValue;
		$this->field5->PlaceHolder = RemoveHtml($this->field5->caption());

		// field6
		$this->field6->EditAttrs["class"] = "form-control";
		$this->field6->EditCustomAttributes = "";
		if (!$this->field6->Raw)
			$this->field6->CurrentValue = HtmlDecode($this->field6->CurrentValue);
		$this->field6->EditValue = $this->field6->CurrentValue;
		$this->field6->PlaceHolder = RemoveHtml($this->field6->caption());

		// field7
		$this->field7->EditAttrs["class"] = "form-control";
		$this->field7->EditCustomAttributes = "";
		if (!$this->field7->Raw)
			$this->field7->CurrentValue = HtmlDecode($this->field7->CurrentValue);
		$this->field7->EditValue = $this->field7->CurrentValue;
		$this->field7->PlaceHolder = RemoveHtml($this->field7->caption());

		// field8
		$this->field8->EditAttrs["class"] = "form-control";
		$this->field8->EditCustomAttributes = "";
		if (!$this->field8->Raw)
			$this->field8->CurrentValue = HtmlDecode($this->field8->CurrentValue);
		$this->field8->EditValue = $this->field8->CurrentValue;
		$this->field8->PlaceHolder = RemoveHtml($this->field8->caption());

		// field9
		$this->field9->EditAttrs["class"] = "form-control";
		$this->field9->EditCustomAttributes = "";
		if (!$this->field9->Raw)
			$this->field9->CurrentValue = HtmlDecode($this->field9->CurrentValue);
		$this->field9->EditValue = $this->field9->CurrentValue;
		$this->field9->PlaceHolder = RemoveHtml($this->field9->caption());

		// field10
		$this->field10->EditAttrs["class"] = "form-control";
		$this->field10->EditCustomAttributes = "";
		if (!$this->field10->Raw)
			$this->field10->CurrentValue = HtmlDecode($this->field10->CurrentValue);
		$this->field10->EditValue = $this->field10->CurrentValue;
		$this->field10->PlaceHolder = RemoveHtml($this->field10->caption());

		// Call Row Rendered event
		$this->Row_Rendered();
	}

	// Aggregate list row values
	public function aggregateListRowValues()
	{
	}

	// Aggregate list row (for rendering)
	public function aggregateListRow()
	{

		// Call Row Rendered event
		$this->Row_Rendered();
	}

	// Export data in HTML/CSV/Word/Excel/Email/PDF format
	public function exportDocument($doc, $recordset, $startRec = 1, $stopRec = 1, $exportPageType = "")
	{
		if (!$recordset || !$doc)
			return;
		if (!$doc->ExportCustom) {

			// Write header
			$doc->exportTableHeader();
			if ($doc->Horizontal) { // Horizontal format, write header
				$doc->beginExportRow();
				if ($exportPageType == "view") {
					$doc->exportCaption($this->subscriptionplanid);
					$doc->exportCaption($this->merchantid);
					$doc->exportCaption($this->memberid);
					$doc->exportCaption($this->planid);
					$doc->exportCaption($this->registrationdate);
					$doc->exportCaption($this->paymentdate);
					$doc->exportCaption($this->effectivedate);
					$doc->exportCaption($this->willexpire);
					$doc->exportCaption($this->expirydate);
					$doc->exportCaption($this->renewalrequired);
					$doc->exportCaption($this->planidforrenewal);
					$doc->exportCaption($this->planstatus);
					$doc->exportCaption($this->planstatusdate);
					$doc->exportCaption($this->approvalstatus);
					$doc->exportCaption($this->approvaldatetime);
					$doc->exportCaption($this->approvalby);
					$doc->exportCaption($this->preauthorizedmemberpi);
					$doc->exportCaption($this->pendingpayment);
					$doc->exportCaption($this->lastinvoiceid);
					$doc->exportCaption($this->lastupdatedate);
					$doc->exportCaption($this->pendingpaymentid);
					$doc->exportCaption($this->notes);
					$doc->exportCaption($this->field1);
					$doc->exportCaption($this->field2);
					$doc->exportCaption($this->field3);
					$doc->exportCaption($this->field4);
					$doc->exportCaption($this->field5);
					$doc->exportCaption($this->field6);
					$doc->exportCaption($this->field7);
					$doc->exportCaption($this->field8);
					$doc->exportCaption($this->field9);
					$doc->exportCaption($this->field10);
				} else {
					$doc->exportCaption($this->subscriptionplanid);
					$doc->exportCaption($this->merchantid);
					$doc->exportCaption($this->memberid);
					$doc->exportCaption($this->planid);
					$doc->exportCaption($this->registrationdate);
					$doc->exportCaption($this->paymentdate);
					$doc->exportCaption($this->effectivedate);
					$doc->exportCaption($this->willexpire);
					$doc->exportCaption($this->expirydate);
					$doc->exportCaption($this->renewalrequired);
					$doc->exportCaption($this->planidforrenewal);
					$doc->exportCaption($this->planstatus);
					$doc->exportCaption($this->planstatusdate);
					$doc->exportCaption($this->approvalstatus);
					$doc->exportCaption($this->approvaldatetime);
					$doc->exportCaption($this->approvalby);
					$doc->exportCaption($this->preauthorizedmemberpi);
					$doc->exportCaption($this->pendingpayment);
					$doc->exportCaption($this->lastinvoiceid);
					$doc->exportCaption($this->lastupdatedate);
					$doc->exportCaption($this->pendingpaymentid);
					$doc->exportCaption($this->field1);
					$doc->exportCaption($this->field2);
					$doc->exportCaption($this->field3);
					$doc->exportCaption($this->field4);
					$doc->exportCaption($this->field5);
					$doc->exportCaption($this->field6);
					$doc->exportCaption($this->field7);
					$doc->exportCaption($this->field8);
					$doc->exportCaption($this->field9);
					$doc->exportCaption($this->field10);
				}
				$doc->endExportRow();
			}
		}

		// Move to first record
		$recCnt = $startRec - 1;
		if (!$recordset->EOF) {
			$recordset->moveFirst();
			if ($startRec > 1)
				$recordset->move($startRec - 1);
		}
		while (!$recordset->EOF && $recCnt < $stopRec) {
			$recCnt++;
			if ($recCnt >= $startRec) {
				$rowCnt = $recCnt - $startRec + 1;

				// Page break
				if ($this->ExportPageBreakCount > 0) {
					if ($rowCnt > 1 && ($rowCnt - 1) % $this->ExportPageBreakCount == 0)
						$doc->exportPageBreak();
				}
				$this->loadListRowValues($recordset);

				// Render row
				$this->RowType = ROWTYPE_VIEW; // Render view
				$this->resetAttributes();
				$this->renderListRow();
				if (!$doc->ExportCustom) {
					$doc->beginExportRow($rowCnt); // Allow CSS styles if enabled
					if ($exportPageType == "view") {
						$doc->exportField($this->subscriptionplanid);
						$doc->exportField($this->merchantid);
						$doc->exportField($this->memberid);
						$doc->exportField($this->planid);
						$doc->exportField($this->registrationdate);
						$doc->exportField($this->paymentdate);
						$doc->exportField($this->effectivedate);
						$doc->exportField($this->willexpire);
						$doc->exportField($this->expirydate);
						$doc->exportField($this->renewalrequired);
						$doc->exportField($this->planidforrenewal);
						$doc->exportField($this->planstatus);
						$doc->exportField($this->planstatusdate);
						$doc->exportField($this->approvalstatus);
						$doc->exportField($this->approvaldatetime);
						$doc->exportField($this->approvalby);
						$doc->exportField($this->preauthorizedmemberpi);
						$doc->exportField($this->pendingpayment);
						$doc->exportField($this->lastinvoiceid);
						$doc->exportField($this->lastupdatedate);
						$doc->exportField($this->pendingpaymentid);
						$doc->exportField($this->notes);
						$doc->exportField($this->field1);
						$doc->exportField($this->field2);
						$doc->exportField($this->field3);
						$doc->exportField($this->field4);
						$doc->exportField($this->field5);
						$doc->exportField($this->field6);
						$doc->exportField($this->field7);
						$doc->exportField($this->field8);
						$doc->exportField($this->field9);
						$doc->exportField($this->field10);
					} else {
						$doc->exportField($this->subscriptionplanid);
						$doc->exportField($this->merchantid);
						$doc->exportField($this->memberid);
						$doc->exportField($this->planid);
						$doc->exportField($this->registrationdate);
						$doc->exportField($this->paymentdate);
						$doc->exportField($this->effectivedate);
						$doc->exportField($this->willexpire);
						$doc->exportField($this->expirydate);
						$doc->exportField($this->renewalrequired);
						$doc->exportField($this->planidforrenewal);
						$doc->exportField($this->planstatus);
						$doc->exportField($this->planstatusdate);
						$doc->exportField($this->approvalstatus);
						$doc->exportField($this->approvaldatetime);
						$doc->exportField($this->approvalby);
						$doc->exportField($this->preauthorizedmemberpi);
						$doc->exportField($this->pendingpayment);
						$doc->exportField($this->lastinvoiceid);
						$doc->exportField($this->lastupdatedate);
						$doc->exportField($this->pendingpaymentid);
						$doc->exportField($this->field1);
						$doc->exportField($this->field2);
						$doc->exportField($this->field3);
						$doc->exportField($this->field4);
						$doc->exportField($this->field5);
						$doc->exportField($this->field6);
						$doc->exportField($this->field7);
						$doc->exportField($this->field8);
						$doc->exportField($this->field9);
						$doc->exportField($this->field10);
					}
					$doc->endExportRow($rowCnt);
				}
			}

			// Call Row Export server event
			if ($doc->ExportCustom)
				$this->Row_Export($recordset->fields);
			$recordset->moveNext();
		}
		if (!$doc->ExportCustom) {
			$doc->exportTableFooter();
		}
	}

	// Get file data
	public function getFileData($fldparm, $key, $resize, $width = 0, $height = 0)
	{

		// No binary fields
		return FALSE;
	}

	// Write Audit Trail start/end for grid update
	public function writeAuditTrailDummy($typ)
	{
		$table = 'merchantmemberplan';
		$usr = CurrentUserName();
		WriteAuditTrail("log", DbCurrentDateTime(), ScriptName(), $usr, $typ, $table, "", "", "", "");
	}

	// Write Audit Trail (add page)
	public function writeAuditTrailOnAdd(&$rs)
	{
		global $Language;
		if (!$this->AuditTrailOnAdd)
			return;
		$table = 'merchantmemberplan';

		// Get key value
		$key = "";
		if ($key != "")
			$key .= Config("COMPOSITE_KEY_SEPARATOR");
		$key .= $rs['subscriptionplanid'];

		// Write Audit Trail
		$dt = DbCurrentDateTime();
		$id = ScriptName();
		$usr = CurrentUserName();
		foreach (array_keys($rs) as $fldname) {
			if (array_key_exists($fldname, $this->fields) && $this->fields[$fldname]->DataType != DATATYPE_BLOB) { // Ignore BLOB fields
				if ($this->fields[$fldname]->HtmlTag == "PASSWORD") {
					$newvalue = $Language->phrase("PasswordMask"); // Password Field
				} elseif ($this->fields[$fldname]->DataType == DATATYPE_MEMO) {
					if (Config("AUDIT_TRAIL_TO_DATABASE"))
						$newvalue = $rs[$fldname];
					else
						$newvalue = "[MEMO]"; // Memo Field
				} elseif ($this->fields[$fldname]->DataType == DATATYPE_XML) {
					$newvalue = "[XML]"; // XML Field
				} else {
					$newvalue = $rs[$fldname];
				}
				WriteAuditTrail("log", $dt, $id, $usr, "A", $table, $fldname, $key, "", $newvalue);
			}
		}
	}

	// Write Audit Trail (edit page)
	public function writeAuditTrailOnEdit(&$rsold, &$rsnew)
	{
		global $Language;
		if (!$this->AuditTrailOnEdit)
			return;
		$table = 'merchantmemberplan';

		// Get key value
		$key = "";
		if ($key != "")
			$key .= Config("COMPOSITE_KEY_SEPARATOR");
		$key .= $rsold['subscriptionplanid'];

		// Write Audit Trail
		$dt = DbCurrentDateTime();
		$id = ScriptName();
		$usr = CurrentUserName();
		foreach (array_keys($rsnew) as $fldname) {
			if (array_key_exists($fldname, $this->fields) && array_key_exists($fldname, $rsold) && $this->fields[$fldname]->DataType != DATATYPE_BLOB) { // Ignore BLOB fields
				if ($this->fields[$fldname]->DataType == DATATYPE_DATE) { // DateTime field
					$modified = (FormatDateTime($rsold[$fldname], 0) != FormatDateTime($rsnew[$fldname], 0));
				} else {
					$modified = !CompareValue($rsold[$fldname], $rsnew[$fldname]);
				}
				if ($modified) {
					if ($this->fields[$fldname]->HtmlTag == "PASSWORD") { // Password Field
						$oldvalue = $Language->phrase("PasswordMask");
						$newvalue = $Language->phrase("PasswordMask");
					} elseif ($this->fields[$fldname]->DataType == DATATYPE_MEMO) { // Memo field
						if (Config("AUDIT_TRAIL_TO_DATABASE")) {
							$oldvalue = $rsold[$fldname];
							$newvalue = $rsnew[$fldname];
						} else {
							$oldvalue = "[MEMO]";
							$newvalue = "[MEMO]";
						}
					} elseif ($this->fields[$fldname]->DataType == DATATYPE_XML) { // XML field
						$oldvalue = "[XML]";
						$newvalue = "[XML]";
					} else {
						$oldvalue = $rsold[$fldname];
						$newvalue = $rsnew[$fldname];
					}
					WriteAuditTrail("log", $dt, $id, $usr, "U", $table, $fldname, $key, $oldvalue, $newvalue);
				}
			}
		}
	}

	// Write Audit Trail (delete page)
	public function writeAuditTrailOnDelete(&$rs)
	{
		global $Language;
		if (!$this->AuditTrailOnDelete)
			return;
		$table = 'merchantmemberplan';

		// Get key value
		$key = "";
		if ($key != "")
			$key .= Config("COMPOSITE_KEY_SEPARATOR");
		$key .= $rs['subscriptionplanid'];

		// Write Audit Trail
		$dt = DbCurrentDateTime();
		$id = ScriptName();
		$curUser = CurrentUserName();
		foreach (array_keys($rs) as $fldname) {
			if (array_key_exists($fldname, $this->fields) && $this->fields[$fldname]->DataType != DATATYPE_BLOB) { // Ignore BLOB fields
				if ($this->fields[$fldname]->HtmlTag == "PASSWORD") {
					$oldvalue = $Language->phrase("PasswordMask"); // Password Field
				} elseif ($this->fields[$fldname]->DataType == DATATYPE_MEMO) {
					if (Config("AUDIT_TRAIL_TO_DATABASE"))
						$oldvalue = $rs[$fldname];
					else
						$oldvalue = "[MEMO]"; // Memo field
				} elseif ($this->fields[$fldname]->DataType == DATATYPE_XML) {
					$oldvalue = "[XML]"; // XML field
				} else {
					$oldvalue = $rs[$fldname];
				}
				WriteAuditTrail("log", $dt, $id, $curUser, "D", $table, $fldname, $key, $oldvalue, "");
			}
		}
	}

	// Table level events
	// Recordset Selecting event
	function Recordset_Selecting(&$filter) {

		// Enter your code here
	}

	// Recordset Selected event
	function Recordset_Selected(&$rs) {

		//echo "Recordset Selected";
	}

	// Recordset Search Validated event
	function Recordset_SearchValidated() {

		// Example:
		//$this->MyField1->AdvancedSearch->SearchValue = "your search criteria"; // Search value

	}

	// Recordset Searching event
	function Recordset_Searching(&$filter) {

		// Enter your code here
	}

	// Row_Selecting event
	function Row_Selecting(&$filter) {

		// Enter your code here
	}

	// Row Selected event
	function Row_Selected(&$rs) {

		//echo "Row Selected";
	}

	// Row Inserting event
	function Row_Inserting($rsold, &$rsnew) {

		// Enter your code here
		// To cancel, set return value to FALSE

		return TRUE;
	}

	// Row Inserted event
	function Row_Inserted($rsold, &$rsnew) {

		//echo "Row Inserted"
	}

	// Row Updating event
	function Row_Updating($rsold, &$rsnew) {

		// Enter your code here
		// To cancel, set return value to FALSE

		return TRUE;
	}

	// Row Updated event
	function Row_Updated($rsold, &$rsnew) {

		//echo "Row Updated";
	}

	// Row Update Conflict event
	function Row_UpdateConflict($rsold, &$rsnew) {

		// Enter your code here
		// To ignore conflict, set return value to FALSE

		return TRUE;
	}

	// Grid Inserting event
	function Grid_Inserting() {

		// Enter your code here
		// To reject grid insert, set return value to FALSE

		return TRUE;
	}

	// Grid Inserted event
	function Grid_Inserted($rsnew) {

		//echo "Grid Inserted";
	}

	// Grid Updating event
	function Grid_Updating($rsold) {

		// Enter your code here
		// To reject grid update, set return value to FALSE

		return TRUE;
	}

	// Grid Updated event
	function Grid_Updated($rsold, $rsnew) {

		//echo "Grid Updated";
	}

	// Row Deleting event
	function Row_Deleting(&$rs) {

		// Enter your code here
		// To cancel, set return value to False

		return TRUE;
	}

	// Row Deleted event
	function Row_Deleted(&$rs) {

		//echo "Row Deleted";
	}

	// Email Sending event
	function Email_Sending($email, &$args) {

		//var_dump($email); var_dump($args); exit();
		return TRUE;
	}

	// Lookup Selecting event
	function Lookup_Selecting($fld, &$filter) {

		//var_dump($fld->Name, $fld->Lookup, $filter); // Uncomment to view the filter
		// Enter your code here

	}

	// Row Rendering event
	function Row_Rendering() {

		// Enter your code here
	}

	// Row Rendered event
	function Row_Rendered() {

		// To view properties of field class, use:
		//var_dump($this-><FieldName>);

	}

	// User ID Filtering event
	function UserID_Filtering(&$filter) {

		// Enter your code here
	}
}
?>