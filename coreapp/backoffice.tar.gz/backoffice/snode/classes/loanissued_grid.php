<?php
namespace PHPMaker2020\_4payadmin;

/**
 * Page class
 */
class loanissued_grid extends loanissued
{

	// Page ID
	public $PageID = "grid";

	// Project ID
	public $ProjectID = "{153C2D2E-60EE-4944-8753-3935EB38E8D6}";

	// Table name
	public $TableName = 'loanissued';

	// Page object name
	public $PageObjName = "loanissued_grid";

	// Grid form hidden field names
	public $FormName = "floanissuedgrid";
	public $FormActionName = "k_action";
	public $FormKeyName = "k_key";
	public $FormOldKeyName = "k_oldkey";
	public $FormBlankRowName = "k_blankrow";
	public $FormKeyCountName = "key_count";

	// Page URLs
	public $AddUrl;
	public $EditUrl;
	public $CopyUrl;
	public $DeleteUrl;
	public $ViewUrl;
	public $ListUrl;

	// Audit Trail
	public $AuditTrailOnAdd = TRUE;
	public $AuditTrailOnEdit = TRUE;
	public $AuditTrailOnDelete = TRUE;
	public $AuditTrailOnView = FALSE;
	public $AuditTrailOnViewData = FALSE;
	public $AuditTrailOnSearch = FALSE;

	// Page headings
	public $Heading = "";
	public $Subheading = "";
	public $PageHeader;
	public $PageFooter;

	// Token
	public $Token = "";
	public $TokenTimeout = 0;
	public $CheckToken;

	// Page heading
	public function pageHeading()
	{
		global $Language;
		if ($this->Heading != "")
			return $this->Heading;
		if (method_exists($this, "tableCaption"))
			return $this->tableCaption();
		return "";
	}

	// Page subheading
	public function pageSubheading()
	{
		global $Language;
		if ($this->Subheading != "")
			return $this->Subheading;
		if ($this->TableName)
			return $Language->phrase($this->PageID);
		return "";
	}

	// Page name
	public function pageName()
	{
		return CurrentPageName();
	}

	// Page URL
	public function pageUrl()
	{
		$url = CurrentPageName() . "?";
		if ($this->UseTokenInUrl)
			$url .= "t=" . $this->TableVar . "&"; // Add page token
		return $url;
	}

	// Messages
	private $_message = "";
	private $_failureMessage = "";
	private $_successMessage = "";
	private $_warningMessage = "";

	// Get message
	public function getMessage()
	{
		return isset($_SESSION[SESSION_MESSAGE]) ? $_SESSION[SESSION_MESSAGE] : $this->_message;
	}

	// Set message
	public function setMessage($v)
	{
		AddMessage($this->_message, $v);
		$_SESSION[SESSION_MESSAGE] = $this->_message;
	}

	// Get failure message
	public function getFailureMessage()
	{
		return isset($_SESSION[SESSION_FAILURE_MESSAGE]) ? $_SESSION[SESSION_FAILURE_MESSAGE] : $this->_failureMessage;
	}

	// Set failure message
	public function setFailureMessage($v)
	{
		AddMessage($this->_failureMessage, $v);
		$_SESSION[SESSION_FAILURE_MESSAGE] = $this->_failureMessage;
	}

	// Get success message
	public function getSuccessMessage()
	{
		return isset($_SESSION[SESSION_SUCCESS_MESSAGE]) ? $_SESSION[SESSION_SUCCESS_MESSAGE] : $this->_successMessage;
	}

	// Set success message
	public function setSuccessMessage($v)
	{
		AddMessage($this->_successMessage, $v);
		$_SESSION[SESSION_SUCCESS_MESSAGE] = $this->_successMessage;
	}

	// Get warning message
	public function getWarningMessage()
	{
		return isset($_SESSION[SESSION_WARNING_MESSAGE]) ? $_SESSION[SESSION_WARNING_MESSAGE] : $this->_warningMessage;
	}

	// Set warning message
	public function setWarningMessage($v)
	{
		AddMessage($this->_warningMessage, $v);
		$_SESSION[SESSION_WARNING_MESSAGE] = $this->_warningMessage;
	}

	// Clear message
	public function clearMessage()
	{
		$this->_message = "";
		$_SESSION[SESSION_MESSAGE] = "";
	}

	// Clear failure message
	public function clearFailureMessage()
	{
		$this->_failureMessage = "";
		$_SESSION[SESSION_FAILURE_MESSAGE] = "";
	}

	// Clear success message
	public function clearSuccessMessage()
	{
		$this->_successMessage = "";
		$_SESSION[SESSION_SUCCESS_MESSAGE] = "";
	}

	// Clear warning message
	public function clearWarningMessage()
	{
		$this->_warningMessage = "";
		$_SESSION[SESSION_WARNING_MESSAGE] = "";
	}

	// Clear messages
	public function clearMessages()
	{
		$this->clearMessage();
		$this->clearFailureMessage();
		$this->clearSuccessMessage();
		$this->clearWarningMessage();
	}

	// Show message
	public function showMessage()
	{
		$hidden = FALSE;
		$html = "";

		// Message
		$message = $this->getMessage();
		if (method_exists($this, "Message_Showing"))
			$this->Message_Showing($message, "");
		if ($message != "") { // Message in Session, display
			if (!$hidden)
				$message = '<button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button>' . $message;
			$html .= '<div class="alert alert-info alert-dismissible ew-info"><i class="icon fas fa-info"></i>' . $message . '</div>';
			$_SESSION[SESSION_MESSAGE] = ""; // Clear message in Session
		}

		// Warning message
		$warningMessage = $this->getWarningMessage();
		if (method_exists($this, "Message_Showing"))
			$this->Message_Showing($warningMessage, "warning");
		if ($warningMessage != "") { // Message in Session, display
			if (!$hidden)
				$warningMessage = '<button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button>' . $warningMessage;
			$html .= '<div class="alert alert-warning alert-dismissible ew-warning"><i class="icon fas fa-exclamation"></i>' . $warningMessage . '</div>';
			$_SESSION[SESSION_WARNING_MESSAGE] = ""; // Clear message in Session
		}

		// Success message
		$successMessage = $this->getSuccessMessage();
		if (method_exists($this, "Message_Showing"))
			$this->Message_Showing($successMessage, "success");
		if ($successMessage != "") { // Message in Session, display
			if (!$hidden)
				$successMessage = '<button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button>' . $successMessage;
			$html .= '<div class="alert alert-success alert-dismissible ew-success"><i class="icon fas fa-check"></i>' . $successMessage . '</div>';
			$_SESSION[SESSION_SUCCESS_MESSAGE] = ""; // Clear message in Session
		}

		// Failure message
		$errorMessage = $this->getFailureMessage();
		if (method_exists($this, "Message_Showing"))
			$this->Message_Showing($errorMessage, "failure");
		if ($errorMessage != "") { // Message in Session, display
			if (!$hidden)
				$errorMessage = '<button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button>' . $errorMessage;
			$html .= '<div class="alert alert-danger alert-dismissible ew-error"><i class="icon fas fa-ban"></i>' . $errorMessage . '</div>';
			$_SESSION[SESSION_FAILURE_MESSAGE] = ""; // Clear message in Session
		}
		echo '<div class="ew-message-dialog' . (($hidden) ? ' d-none' : "") . '">' . $html . '</div>';
	}

	// Get message as array
	public function getMessages()
	{
		$ar = [];

		// Message
		$message = $this->getMessage();

		//if (method_exists($this, "Message_Showing"))
		//	$this->Message_Showing($message, "");

		if ($message != "") { // Message in Session, display
			$ar["message"] = $message;
			$_SESSION[SESSION_MESSAGE] = ""; // Clear message in Session
		}

		// Warning message
		$warningMessage = $this->getWarningMessage();

		//if (method_exists($this, "Message_Showing"))
		//	$this->Message_Showing($warningMessage, "warning");

		if ($warningMessage != "") { // Message in Session, display
			$ar["warningMessage"] = $warningMessage;
			$_SESSION[SESSION_WARNING_MESSAGE] = ""; // Clear message in Session
		}

		// Success message
		$successMessage = $this->getSuccessMessage();

		//if (method_exists($this, "Message_Showing"))
		//	$this->Message_Showing($successMessage, "success");

		if ($successMessage != "") { // Message in Session, display
			$ar["successMessage"] = $successMessage;
			$_SESSION[SESSION_SUCCESS_MESSAGE] = ""; // Clear message in Session
		}

		// Failure message
		$failureMessage = $this->getFailureMessage();

		//if (method_exists($this, "Message_Showing"))
		//	$this->Message_Showing($failureMessage, "failure");

		if ($failureMessage != "") { // Message in Session, display
			$ar["failureMessage"] = $failureMessage;
			$_SESSION[SESSION_FAILURE_MESSAGE] = ""; // Clear message in Session
		}
		return $ar;
	}

	// Show Page Header
	public function showPageHeader()
	{
		$header = $this->PageHeader;
		$this->Page_DataRendering($header);
		if ($header != "") { // Header exists, display
			echo '<p id="ew-page-header">' . $header . '</p>';
		}
	}

	// Show Page Footer
	public function showPageFooter()
	{
		$footer = $this->PageFooter;
		$this->Page_DataRendered($footer);
		if ($footer != "") { // Footer exists, display
			echo '<p id="ew-page-footer">' . $footer . '</p>';
		}
	}

	// Validate page request
	protected function isPageRequest()
	{
		global $CurrentForm;
		if ($this->UseTokenInUrl) {
			if ($CurrentForm)
				return ($this->TableVar == $CurrentForm->getValue("t"));
			if (Get("t") !== NULL)
				return ($this->TableVar == Get("t"));
		}
		return TRUE;
	}

	// Valid Post
	protected function validPost()
	{
		if (!$this->CheckToken || !IsPost() || IsApi())
			return TRUE;
		if (Post(Config("TOKEN_NAME")) === NULL)
			return FALSE;
		$fn = Config("CHECK_TOKEN_FUNC");
		if (is_callable($fn))
			return $fn(Post(Config("TOKEN_NAME")), $this->TokenTimeout);
		return FALSE;
	}

	// Create Token
	public function createToken()
	{
		global $CurrentToken;
		$fn = Config("CREATE_TOKEN_FUNC"); // Always create token, required by API file/lookup request
		if ($this->Token == "" && is_callable($fn)) // Create token
			$this->Token = $fn();
		$CurrentToken = $this->Token; // Save to global variable
	}

	// Constructor
	public function __construct()
	{
		global $Language, $DashboardReport;
		global $UserTable;

		// Check token
		$this->CheckToken = Config("CHECK_TOKEN");

		// Initialize
		$this->FormActionName .= "_" . $this->FormName;
		$this->FormKeyName .= "_" . $this->FormName;
		$this->FormOldKeyName .= "_" . $this->FormName;
		$this->FormBlankRowName .= "_" . $this->FormName;
		$this->FormKeyCountName .= "_" . $this->FormName;
		$GLOBALS["Grid"] = &$this;
		$this->TokenTimeout = SessionTimeoutTime();

		// Language object
		if (!isset($Language))
			$Language = new Language();

		// Parent constuctor
		parent::__construct();

		// Table object (loanissued)
		if (!isset($GLOBALS["loanissued"]) || get_class($GLOBALS["loanissued"]) == PROJECT_NAMESPACE . "loanissued") {
			$GLOBALS["loanissued"] = &$this;

			// $GLOBALS["MasterTable"] = &$GLOBALS["Table"];
			// if (!isset($GLOBALS["Table"]))
			// 	$GLOBALS["Table"] = &$GLOBALS["loanissued"];

		}
		$this->AddUrl = "loanissuedadd.php";

		// Table object (admin)
		if (!isset($GLOBALS['admin']))
			$GLOBALS['admin'] = new admin();

		// Page ID (for backward compatibility only)
		if (!defined(PROJECT_NAMESPACE . "PAGE_ID"))
			define(PROJECT_NAMESPACE . "PAGE_ID", 'grid');

		// Table name (for backward compatibility only)
		if (!defined(PROJECT_NAMESPACE . "TABLE_NAME"))
			define(PROJECT_NAMESPACE . "TABLE_NAME", 'loanissued');

		// Start timer
		if (!isset($GLOBALS["DebugTimer"]))
			$GLOBALS["DebugTimer"] = new Timer();

		// Debug message
		LoadDebugMessage();

		// Open connection
		if (!isset($GLOBALS["Conn"]))
			$GLOBALS["Conn"] = $this->getConnection();

		// User table object (admin)
		$UserTable = $UserTable ?: new admin();

		// List options
		$this->ListOptions = new ListOptions();
		$this->ListOptions->TableVar = $this->TableVar;

		// Other options
		if (!$this->OtherOptions)
			$this->OtherOptions = new ListOptionsArray();
		$this->OtherOptions["addedit"] = new ListOptions("div");
		$this->OtherOptions["addedit"]->TagClassName = "ew-add-edit-option";
	}

	// Terminate page
	public function terminate($url = "")
	{
		global $ExportFileName, $TempImages, $DashboardReport;

		// Export
		global $loanissued;
		if ($this->CustomExport && $this->CustomExport == $this->Export && array_key_exists($this->CustomExport, Config("EXPORT_CLASSES"))) {
				$content = ob_get_contents();
			if ($ExportFileName == "")
				$ExportFileName = $this->TableVar;
			$class = PROJECT_NAMESPACE . Config("EXPORT_CLASSES." . $this->CustomExport);
			if (class_exists($class)) {
				$doc = new $class($loanissued);
				$doc->Text = @$content;
				if ($this->isExport("email"))
					echo $this->exportEmail($doc->Text);
				else
					$doc->export();
				DeleteTempImages(); // Delete temp images
				exit();
			}
		}

//		$GLOBALS["Table"] = &$GLOBALS["MasterTable"];
		unset($GLOBALS["Grid"]);
		if ($url === "")
			return;
		if (!IsApi())
			$this->Page_Redirecting($url);

		// Return for API
		if (IsApi()) {
			$res = $url === TRUE;
			if (!$res) // Show error
				WriteJson(array_merge(["success" => FALSE], $this->getMessages()));
			return;
		}

		// Go to URL if specified
		if ($url != "") {
			if (!Config("DEBUG") && ob_get_length())
				ob_end_clean();
			SaveDebugMessage();
			AddHeader("Location", $url);
		}
		exit();
	}

	// Get records from recordset
	protected function getRecordsFromRecordset($rs, $current = FALSE)
	{
		$rows = [];
		if (is_object($rs)) { // Recordset
			while ($rs && !$rs->EOF) {
				$this->loadRowValues($rs); // Set up DbValue/CurrentValue
				$row = $this->getRecordFromArray($rs->fields);
				if ($current)
					return $row;
				else
					$rows[] = $row;
				$rs->moveNext();
			}
		} elseif (is_array($rs)) {
			foreach ($rs as $ar) {
				$row = $this->getRecordFromArray($ar);
				if ($current)
					return $row;
				else
					$rows[] = $row;
			}
		}
		return $rows;
	}

	// Get record from array
	protected function getRecordFromArray($ar)
	{
		$row = [];
		if (is_array($ar)) {
			foreach ($ar as $fldname => $val) {
				if (array_key_exists($fldname, $this->fields) && ($this->fields[$fldname]->Visible || $this->fields[$fldname]->IsPrimaryKey)) { // Primary key or Visible
					$fld = &$this->fields[$fldname];
					if ($fld->HtmlTag == "FILE") { // Upload field
						if (EmptyValue($val)) {
							$row[$fldname] = NULL;
						} else {
							if ($fld->DataType == DATATYPE_BLOB) {
								$url = FullUrl(GetApiUrl(Config("API_FILE_ACTION"),
									Config("API_OBJECT_NAME") . "=" . $fld->TableVar . "&" .
									Config("API_FIELD_NAME") . "=" . $fld->Param . "&" .
									Config("API_KEY_NAME") . "=" . rawurlencode($this->getRecordKeyValue($ar)))); //*** need to add this? API may not be in the same folder
								$row[$fldname] = ["type" => ContentType($val), "url" => $url, "name" => $fld->Param . ContentExtension($val)];
							} elseif (!$fld->UploadMultiple || !ContainsString($val, Config("MULTIPLE_UPLOAD_SEPARATOR"))) { // Single file
								$url = FullUrl(GetApiUrl(Config("API_FILE_ACTION"),
									Config("API_OBJECT_NAME") . "=" . $fld->TableVar . "&" .
									"fn=" . Encrypt($fld->physicalUploadPath() . $val)));
								$row[$fldname] = ["type" => MimeContentType($val), "url" => $url, "name" => $val];
							} else { // Multiple files
								$files = explode(Config("MULTIPLE_UPLOAD_SEPARATOR"), $val);
								$ar = [];
								foreach ($files as $file) {
									$url = FullUrl(GetApiUrl(Config("API_FILE_ACTION"),
										Config("API_OBJECT_NAME") . "=" . $fld->TableVar . "&" .
										"fn=" . Encrypt($fld->physicalUploadPath() . $file)));
									if (!EmptyValue($file))
										$ar[] = ["type" => MimeContentType($file), "url" => $url, "name" => $file];
								}
								$row[$fldname] = $ar;
							}
						}
					} else {
						$row[$fldname] = $val;
					}
				}
			}
		}
		return $row;
	}

	// Get record key value from array
	protected function getRecordKeyValue($ar)
	{
		$key = "";
		if (is_array($ar)) {
			$key .= @$ar['loanid'];
		}
		return $key;
	}

	/**
	 * Hide fields for add/edit
	 *
	 * @return void
	 */
	protected function hideFieldsForAddEdit()
	{
		if ($this->isAdd() || $this->isCopy() || $this->isGridAdd())
			$this->loanid->Visible = FALSE;
	}

	// Lookup data
	public function lookup()
	{
		global $Language, $Security;
		if (!isset($Language))
			$Language = new Language(Config("LANGUAGE_FOLDER"), Post("language", ""));

		// Set up API request
		if (!ValidApiRequest())
			return FALSE;
		$this->setupApiSecurity();

		// Get lookup object
		$fieldName = Post("field");
		if (!array_key_exists($fieldName, $this->fields))
			return FALSE;
		$lookupField = $this->fields[$fieldName];
		$lookup = $lookupField->Lookup;
		if ($lookup === NULL)
			return FALSE;
		$tbl = $lookup->getTable();
		if (!$Security->allowLookup(Config("PROJECT_ID") . $tbl->TableName)) // Lookup permission
			return FALSE;

		// Get lookup parameters
		$lookupType = Post("ajax", "unknown");
		$pageSize = -1;
		$offset = -1;
		$searchValue = "";
		if (SameText($lookupType, "modal")) {
			$searchValue = Post("sv", "");
			$pageSize = Post("recperpage", 10);
			$offset = Post("start", 0);
		} elseif (SameText($lookupType, "autosuggest")) {
			$searchValue = Param("q", "");
			$pageSize = Param("n", -1);
			$pageSize = is_numeric($pageSize) ? (int)$pageSize : -1;
			if ($pageSize <= 0)
				$pageSize = Config("AUTO_SUGGEST_MAX_ENTRIES");
			$start = Param("start", -1);
			$start = is_numeric($start) ? (int)$start : -1;
			$page = Param("page", -1);
			$page = is_numeric($page) ? (int)$page : -1;
			$offset = $start >= 0 ? $start : ($page > 0 && $pageSize > 0 ? ($page - 1) * $pageSize : 0);
		}
		$userSelect = Decrypt(Post("s", ""));
		$userFilter = Decrypt(Post("f", ""));
		$userOrderBy = Decrypt(Post("o", ""));
		$keys = Post("keys");
		$lookup->LookupType = $lookupType; // Lookup type
		if ($keys !== NULL) { // Selected records from modal
			if (is_array($keys))
				$keys = implode(Config("MULTIPLE_OPTION_SEPARATOR"), $keys);
			$lookup->FilterFields = []; // Skip parent fields if any
			$lookup->FilterValues[] = $keys; // Lookup values
			$pageSize = -1; // Show all records
		} else { // Lookup values
			$lookup->FilterValues[] = Post("v0", Post("lookupValue", ""));
		}
		$cnt = is_array($lookup->FilterFields) ? count($lookup->FilterFields) : 0;
		for ($i = 1; $i <= $cnt; $i++)
			$lookup->FilterValues[] = Post("v" . $i, "");
		$lookup->SearchValue = $searchValue;
		$lookup->PageSize = $pageSize;
		$lookup->Offset = $offset;
		if ($userSelect != "")
			$lookup->UserSelect = $userSelect;
		if ($userFilter != "")
			$lookup->UserFilter = $userFilter;
		if ($userOrderBy != "")
			$lookup->UserOrderBy = $userOrderBy;
		$lookup->toJson($this); // Use settings from current page
	}

	// Set up API security
	public function setupApiSecurity()
	{
		global $Security;

		// Setup security for API request
		if ($Security->isLoggedIn()) $Security->TablePermission_Loading();
		$Security->loadCurrentUserLevel(Config("PROJECT_ID") . $this->TableName);
		if ($Security->isLoggedIn()) $Security->TablePermission_Loaded();
	}

	// Class variables
	public $ListOptions; // List options
	public $ExportOptions; // Export options
	public $SearchOptions; // Search options
	public $OtherOptions; // Other options
	public $FilterOptions; // Filter options
	public $ImportOptions; // Import options
	public $ListActions; // List actions
	public $SelectedCount = 0;
	public $SelectedIndex = 0;
	public $ShowOtherOptions = FALSE;
	public $DisplayRecords = 10;
	public $StartRecord;
	public $StopRecord;
	public $TotalRecords = 0;
	public $RecordRange = 10;
	public $PageSizes = ""; // Page sizes (comma separated)
	public $DefaultSearchWhere = ""; // Default search WHERE clause
	public $SearchWhere = ""; // Search WHERE clause
	public $SearchPanelClass = "ew-search-panel collapse"; // Search Panel class
	public $SearchRowCount = 0; // For extended search
	public $SearchColumnCount = 0; // For extended search
	public $SearchFieldsPerRow = 1; // For extended search
	public $RecordCount = 0; // Record count
	public $EditRowCount;
	public $StartRowCount = 1;
	public $RowCount = 0;
	public $Attrs = []; // Row attributes and cell attributes
	public $RowIndex = 0; // Row index
	public $KeyCount = 0; // Key count
	public $RowAction = ""; // Row action
	public $RowOldKey = ""; // Row old key (for copy)
	public $MultiColumnClass = "col-sm";
	public $MultiColumnEditClass = "w-100";
	public $DbMasterFilter = ""; // Master filter
	public $DbDetailFilter = ""; // Detail filter
	public $MasterRecordExists;
	public $MultiSelectKey;
	public $Command;
	public $RestoreSearch = FALSE;
	public $loanissuedupgrades_Count;
	public $loaneventhistory_Count;
	public $loanlatefees_Count;
	public $loanapplied_Count;
	public $loanpayments_Count;
	public $loanpaymentplan_Count;
	public $DetailPages;
	public $OldRecordset;

	//
	// Page run
	//

	public function run()
	{
		global $ExportType, $CustomExportType, $ExportFileName, $UserProfile, $Language, $Security, $CurrentForm,
			$FormError, $SearchError;

		// User profile
		$UserProfile = new UserProfile();

		// Security
		if (ValidApiRequest()) { // API request
			$this->setupApiSecurity(); // Set up API Security
		} else {
			$Security = new AdvancedSecurity();
			if (IsPasswordExpired())
				$this->terminate(GetUrl("changepwd.php"));
			if (!$Security->isLoggedIn())
				$Security->autoLogin();
			if ($Security->isLoggedIn())
				$Security->TablePermission_Loading();
			$Security->loadCurrentUserLevel($this->ProjectID . $this->TableName);
			if ($Security->isLoggedIn())
				$Security->TablePermission_Loaded();
			if (!$Security->canList()) {
				$Security->saveLastUrl();
				$this->setFailureMessage(DeniedMessage()); // Set no permission
				$this->terminate(GetUrl("index.php"));
				return;
			}
		}

		// Get grid add count
		$gridaddcnt = Get(Config("TABLE_GRID_ADD_ROW_COUNT"), "");
		if (is_numeric($gridaddcnt) && $gridaddcnt > 0)
			$this->GridAddRowCount = $gridaddcnt;

		// Set up list options
		$this->setupListOptions();
		$this->loanid->setVisibility();
		$this->_userid->setVisibility();
		$this->issueddate->setVisibility();
		$this->currcode->setVisibility();
		$this->issuedamount->Visible = FALSE;
		$this->externalrefno->Visible = FALSE;
		$this->fullypaidind->setVisibility();
		$this->bankcode->Visible = FALSE;
		$this->feeperc->Visible = FALSE;
		$this->feeamount->Visible = FALSE;
		$this->taxperc->Visible = FALSE;
		$this->taxamount->Visible = FALSE;
		$this->totalamount->Visible = FALSE;
		$this->paymenttargetdate->Visible = FALSE;
		$this->feefixed->Visible = FALSE;
		$this->totalfees->Visible = FALSE;
		$this->approveruserid->Visible = FALSE;
		$this->docid->Visible = FALSE;
		$this->feesystemtotal->Visible = FALSE;
		$this->feeexternaltotal->Visible = FALSE;
		$this->feefranchiseetotal->Visible = FALSE;
		$this->feeresellertotal->Visible = FALSE;
		$this->purchasefeeid->Visible = FALSE;
		$this->cancellationrefid->Visible = FALSE;
		$this->cancellationdatetime->Visible = FALSE;
		$this->cancellationreason->Visible = FALSE;
		$this->lastupdatedate->Visible = FALSE;
		$this->feeexternaltotaltime->Visible = FALSE;
		$this->totalamountapplied->Visible = FALSE;
		$this->totalfeesapplied->Visible = FALSE;
		$this->totalprincipleandfees->Visible = FALSE;
		$this->taxamountbreakdown->Visible = FALSE;
		$this->feesystembreakdown->Visible = FALSE;
		$this->feeexternalbreakdown->Visible = FALSE;
		$this->feefranchiseebreakdown->Visible = FALSE;
		$this->feeresellerbreakdown->Visible = FALSE;
		$this->outstandingprinciple->Visible = FALSE;
		$this->outstandingfees->Visible = FALSE;
		$this->outstandingprincipleandfees->Visible = FALSE;
		$this->lastupdate->Visible = FALSE;
		$this->externalprovisioningrefno->Visible = FALSE;
		$this->loantype->Visible = FALSE;
		$this->numberofoutstandingdays->Visible = FALSE;
		$this->loandue->Visible = FALSE;
		$this->loanduedate->Visible = FALSE;
		$this->outstandinglatefees->Visible = FALSE;
		$this->disbursementtype->Visible = FALSE;
		$this->disbursementamount->Visible = FALSE;
		$this->loanconfirmed->setVisibility();
		$this->loanconfirmedtime->Visible = FALSE;
		$this->loanupgraded->Visible = FALSE;
		$this->stoplatefee->Visible = FALSE;
		$this->otherdetails1->Visible = FALSE;
		$this->lockflag->Visible = FALSE;
		$this->lastlatefeecalculatedate->Visible = FALSE;
		$this->notificationlockflag->Visible = FALSE;
		$this->lastnotificationdate->Visible = FALSE;
		$this->sendnotificationtextdate->Visible = FALSE;
		$this->termtype->setVisibility();
		$this->hideFieldsForAddEdit();

		// Global Page Loading event (in userfn*.php)
		Page_Loading();

		// Page Load event
		$this->Page_Load();

		// Check token
		if (!$this->validPost()) {
			Write($Language->phrase("InvalidPostRequest"));
			$this->terminate();
		}

		// Create Token
		$this->createToken();

		// Set up master detail parameters
		$this->setupMasterParms();

		// Setup other options
		$this->setupOtherOptions();

		// Set up lookup cache
		$this->setupLookupOptions($this->currcode);
		$this->setupLookupOptions($this->loantype);
		$this->setupLookupOptions($this->loandue);
		$this->setupLookupOptions($this->loanconfirmed);
		$this->setupLookupOptions($this->loanupgraded);
		$this->setupLookupOptions($this->stoplatefee);

		// Search filters
		$srchAdvanced = ""; // Advanced search filter
		$srchBasic = ""; // Basic search filter
		$filter = "";

		// Get command
		$this->Command = strtolower(Get("cmd"));
		if ($this->isPageRequest()) { // Validate request

			// Set up records per page
			$this->setupDisplayRecords();

			// Handle reset command
			$this->resetCmd();

			// Hide list options
			if ($this->isExport()) {
				$this->ListOptions->hideAllOptions(["sequence"]);
				$this->ListOptions->UseDropDownButton = FALSE; // Disable drop down button
				$this->ListOptions->UseButtonGroup = FALSE; // Disable button group
			} elseif ($this->isGridAdd() || $this->isGridEdit()) {
				$this->ListOptions->hideAllOptions();
				$this->ListOptions->UseDropDownButton = FALSE; // Disable drop down button
				$this->ListOptions->UseButtonGroup = FALSE; // Disable button group
			}

			// Show grid delete link for grid add / grid edit
			if ($this->AllowAddDeleteRow) {
				if ($this->isGridAdd() || $this->isGridEdit()) {
					$item = $this->ListOptions["griddelete"];
					if ($item)
						$item->Visible = TRUE;
				}
			}

			// Set up sorting order
			$this->setupSortOrder();
		}

		// Restore display records
		if ($this->Command != "json" && $this->getRecordsPerPage() != "") {
			$this->DisplayRecords = $this->getRecordsPerPage(); // Restore from Session
		} else {
			$this->DisplayRecords = 10; // Load default
			$this->setRecordsPerPage($this->DisplayRecords); // Save default to Session
		}

		// Load Sorting Order
		if ($this->Command != "json")
			$this->loadSortOrder();

		// Build filter
		$filter = "";
		if (!$Security->canList())
			$filter = "(0=1)"; // Filter all records

		// Restore master/detail filter
		$this->DbMasterFilter = $this->getMasterFilter(); // Restore master filter
		$this->DbDetailFilter = $this->getDetailFilter(); // Restore detail filter
		AddFilter($filter, $this->DbDetailFilter);
		AddFilter($filter, $this->SearchWhere);
		if ($filter == "") {
			$filter = "0=101";
			$this->SearchWhere = $filter;
		}

		// Load master record
		if ($this->CurrentMode != "add" && $this->getMasterFilter() != "" && $this->getCurrentMasterTable() == "loanrequests") {
			global $loanrequests;
			$rsmaster = $loanrequests->loadRs($this->DbMasterFilter);
			$this->MasterRecordExists = ($rsmaster && !$rsmaster->EOF);
			if (!$this->MasterRecordExists) {
				$this->setFailureMessage($Language->phrase("NoRecord")); // Set no record found
				$this->terminate("loanrequestslist.php"); // Return to master page
			} else {
				$loanrequests->loadListRowValues($rsmaster);
				$loanrequests->RowType = ROWTYPE_MASTER; // Master row
				$loanrequests->renderListRow();
				$rsmaster->close();
			}
		}

		// Load master record
		if ($this->CurrentMode != "add" && $this->getMasterFilter() != "" && $this->getCurrentMasterTable() == "loancancelrequests") {
			global $loancancelrequests;
			$rsmaster = $loancancelrequests->loadRs($this->DbMasterFilter);
			$this->MasterRecordExists = ($rsmaster && !$rsmaster->EOF);
			if (!$this->MasterRecordExists) {
				$this->setFailureMessage($Language->phrase("NoRecord")); // Set no record found
				$this->terminate("loancancelrequestslist.php"); // Return to master page
			} else {
				$loancancelrequests->loadListRowValues($rsmaster);
				$loancancelrequests->RowType = ROWTYPE_MASTER; // Master row
				$loancancelrequests->renderListRow();
				$rsmaster->close();
			}
		}

		// Load master record
		if ($this->CurrentMode != "add" && $this->getMasterFilter() != "" && $this->getCurrentMasterTable() == "loanlimits") {
			global $loanlimits;
			$rsmaster = $loanlimits->loadRs($this->DbMasterFilter);
			$this->MasterRecordExists = ($rsmaster && !$rsmaster->EOF);
			if (!$this->MasterRecordExists) {
				$this->setFailureMessage($Language->phrase("NoRecord")); // Set no record found
				$this->terminate("loanlimitslist.php"); // Return to master page
			} else {
				$loanlimits->loadListRowValues($rsmaster);
				$loanlimits->RowType = ROWTYPE_MASTER; // Master row
				$loanlimits->renderListRow();
				$rsmaster->close();
			}
		}

		// Set up filter
		if ($this->Command == "json") {
			$this->UseSessionForListSql = FALSE; // Do not use session for ListSQL
			$this->CurrentFilter = $filter;
		} else {
			$this->setSessionWhere($filter);
			$this->CurrentFilter = "";
		}
		if ($this->isGridAdd()) {
			if ($this->CurrentMode == "copy") {
				$selectLimit = $this->UseSelectLimit;
				if ($selectLimit) {
					$this->TotalRecords = $this->listRecordCount();
					$this->Recordset = $this->loadRecordset($this->StartRecord - 1, $this->DisplayRecords);
				} else {
					if ($this->Recordset = $this->loadRecordset())
						$this->TotalRecords = $this->Recordset->RecordCount();
				}
				$this->StartRecord = 1;
				$this->DisplayRecords = $this->TotalRecords;
			} else {
				$this->CurrentFilter = "0=1";
				$this->StartRecord = 1;
				$this->DisplayRecords = $this->GridAddRowCount;
			}
			$this->TotalRecords = $this->DisplayRecords;
			$this->StopRecord = $this->DisplayRecords;
		} else {
			$selectLimit = $this->UseSelectLimit;
			if ($selectLimit) {
				$this->TotalRecords = $this->listRecordCount();
			} else {
				if ($this->Recordset = $this->loadRecordset())
					$this->TotalRecords = $this->Recordset->RecordCount();
			}
			$this->StartRecord = 1;
			$this->DisplayRecords = $this->TotalRecords; // Display all records
			if ($selectLimit)
				$this->Recordset = $this->loadRecordset($this->StartRecord - 1, $this->DisplayRecords);
		}

		// Normal return
		if (IsApi()) {
			$rows = $this->getRecordsFromRecordset($this->Recordset);
			$this->Recordset->close();
			WriteJson(["success" => TRUE, $this->TableVar => $rows, "totalRecordCount" => $this->TotalRecords]);
			$this->terminate(TRUE);
		}

		// Set up pager
		$this->Pager = new PrevNextPager($this->StartRecord, $this->getRecordsPerPage(), $this->TotalRecords, $this->PageSizes, $this->RecordRange, $this->AutoHidePager, $this->AutoHidePageSizeSelector);
	}

	// Set up number of records displayed per page
	protected function setupDisplayRecords()
	{
		$wrk = Get(Config("TABLE_REC_PER_PAGE"), "");
		if ($wrk != "") {
			if (is_numeric($wrk)) {
				$this->DisplayRecords = (int)$wrk;
			} else {
				if (SameText($wrk, "all")) { // Display all records
					$this->DisplayRecords = -1;
				} else {
					$this->DisplayRecords = 10; // Non-numeric, load default
				}
			}
			$this->setRecordsPerPage($this->DisplayRecords); // Save to Session

			// Reset start position
			$this->StartRecord = 1;
			$this->setStartRecordNumber($this->StartRecord);
		}
	}

	// Exit inline mode
	protected function clearInlineMode()
	{
		$this->LastAction = $this->CurrentAction; // Save last action
		$this->CurrentAction = ""; // Clear action
		$_SESSION[SESSION_INLINE_MODE] = ""; // Clear inline mode
	}

	// Switch to Grid Add mode
	protected function gridAddMode()
	{
		$this->CurrentAction = "gridadd";
		$_SESSION[SESSION_INLINE_MODE] = "gridadd";
		$this->hideFieldsForAddEdit();
	}

	// Switch to Grid Edit mode
	protected function gridEditMode()
	{
		$this->CurrentAction = "gridedit";
		$_SESSION[SESSION_INLINE_MODE] = "gridedit";
		$this->hideFieldsForAddEdit();
	}

	// Perform update to grid
	public function gridUpdate()
	{
		global $Language, $CurrentForm, $FormError;
		$gridUpdate = TRUE;

		// Get old recordset
		$this->CurrentFilter = $this->buildKeyFilter();
		if ($this->CurrentFilter == "")
			$this->CurrentFilter = "0=1";
		$sql = $this->getCurrentSql();
		$conn = $this->getConnection();
		if ($rs = $conn->execute($sql)) {
			$rsold = $rs->getRows();
			$rs->close();
		}

		// Call Grid Updating event
		if (!$this->Grid_Updating($rsold)) {
			if ($this->getFailureMessage() == "")
				$this->setFailureMessage($Language->phrase("GridEditCancelled")); // Set grid edit cancelled message
			return FALSE;
		}
		if ($this->AuditTrailOnEdit)
			$this->writeAuditTrailDummy($Language->phrase("BatchUpdateBegin")); // Batch update begin
		$key = "";

		// Update row index and get row key
		$CurrentForm->Index = -1;
		$rowcnt = strval($CurrentForm->getValue($this->FormKeyCountName));
		if ($rowcnt == "" || !is_numeric($rowcnt))
			$rowcnt = 0;

		// Update all rows based on key
		for ($rowindex = 1; $rowindex <= $rowcnt; $rowindex++) {
			$CurrentForm->Index = $rowindex;
			$rowkey = strval($CurrentForm->getValue($this->FormKeyName));
			$rowaction = strval($CurrentForm->getValue($this->FormActionName));

			// Load all values and keys
			if ($rowaction != "insertdelete") { // Skip insert then deleted rows
				$this->loadFormValues(); // Get form values
				if ($rowaction == "" || $rowaction == "edit" || $rowaction == "delete") {
					$gridUpdate = $this->setupKeyValues($rowkey); // Set up key values
				} else {
					$gridUpdate = TRUE;
				}

				// Skip empty row
				if ($rowaction == "insert" && $this->emptyRow()) {

					// No action required
				// Validate form and insert/update/delete record

				} elseif ($gridUpdate) {
					if ($rowaction == "delete") {
						$this->CurrentFilter = $this->getRecordFilter();
						$gridUpdate = $this->deleteRows(); // Delete this row
					} else if (!$this->validateForm()) {
						$gridUpdate = FALSE; // Form error, reset action
						$this->setFailureMessage($FormError);
					} else {
						if ($rowaction == "insert") {
							$gridUpdate = $this->addRow(); // Insert this row
						} else {
							if ($rowkey != "") {
								$this->SendEmail = FALSE; // Do not send email on update success
								$gridUpdate = $this->editRow(); // Update this row
							}
						} // End update
					}
				}
				if ($gridUpdate) {
					if ($key != "")
						$key .= ", ";
					$key .= $rowkey;
				} else {
					break;
				}
			}
		}
		if ($gridUpdate) {

			// Get new recordset
			if ($rs = $conn->execute($sql)) {
				$rsnew = $rs->getRows();
				$rs->close();
			}

			// Call Grid_Updated event
			$this->Grid_Updated($rsold, $rsnew);
			if ($this->AuditTrailOnEdit)
				$this->writeAuditTrailDummy($Language->phrase("BatchUpdateSuccess")); // Batch update success
			$this->clearInlineMode(); // Clear inline edit mode
		} else {
			if ($this->AuditTrailOnEdit)
				$this->writeAuditTrailDummy($Language->phrase("BatchUpdateRollback")); // Batch update rollback
			if ($this->getFailureMessage() == "")
				$this->setFailureMessage($Language->phrase("UpdateFailed")); // Set update failed message
		}
		return $gridUpdate;
	}

	// Build filter for all keys
	protected function buildKeyFilter()
	{
		global $CurrentForm;
		$wrkFilter = "";

		// Update row index and get row key
		$rowindex = 1;
		$CurrentForm->Index = $rowindex;
		$thisKey = strval($CurrentForm->getValue($this->FormKeyName));
		while ($thisKey != "") {
			if ($this->setupKeyValues($thisKey)) {
				$filter = $this->getRecordFilter();
				if ($wrkFilter != "")
					$wrkFilter .= " OR ";
				$wrkFilter .= $filter;
			} else {
				$wrkFilter = "0=1";
				break;
			}

			// Update row index and get row key
			$rowindex++; // Next row
			$CurrentForm->Index = $rowindex;
			$thisKey = strval($CurrentForm->getValue($this->FormKeyName));
		}
		return $wrkFilter;
	}

	// Set up key values
	protected function setupKeyValues($key)
	{
		$arKeyFlds = explode(Config("COMPOSITE_KEY_SEPARATOR"), $key);
		if (count($arKeyFlds) >= 1) {
			$this->loanid->setOldValue($arKeyFlds[0]);
			if (!is_numeric($this->loanid->OldValue))
				return FALSE;
		}
		return TRUE;
	}

	// Perform Grid Add
	public function gridInsert()
	{
		global $Language, $CurrentForm, $FormError;
		$rowindex = 1;
		$gridInsert = FALSE;
		$conn = $this->getConnection();

		// Call Grid Inserting event
		if (!$this->Grid_Inserting()) {
			if ($this->getFailureMessage() == "")
				$this->setFailureMessage($Language->phrase("GridAddCancelled")); // Set grid add cancelled message
			return FALSE;
		}

		// Init key filter
		$wrkfilter = "";
		$addcnt = 0;
		if ($this->AuditTrailOnAdd)
			$this->writeAuditTrailDummy($Language->phrase("BatchInsertBegin")); // Batch insert begin
		$key = "";

		// Get row count
		$CurrentForm->Index = -1;
		$rowcnt = strval($CurrentForm->getValue($this->FormKeyCountName));
		if ($rowcnt == "" || !is_numeric($rowcnt))
			$rowcnt = 0;

		// Insert all rows
		for ($rowindex = 1; $rowindex <= $rowcnt; $rowindex++) {

			// Load current row values
			$CurrentForm->Index = $rowindex;
			$rowaction = strval($CurrentForm->getValue($this->FormActionName));
			if ($rowaction != "" && $rowaction != "insert")
				continue; // Skip
			if ($rowaction == "insert") {
				$this->RowOldKey = strval($CurrentForm->getValue($this->FormOldKeyName));
				$this->loadOldRecord(); // Load old record
			}
			$this->loadFormValues(); // Get form values
			if (!$this->emptyRow()) {
				$addcnt++;
				$this->SendEmail = FALSE; // Do not send email on insert success

				// Validate form
				if (!$this->validateForm()) {
					$gridInsert = FALSE; // Form error, reset action
					$this->setFailureMessage($FormError);
				} else {
					$gridInsert = $this->addRow($this->OldRecordset); // Insert this row
				}
				if ($gridInsert) {
					if ($key != "")
						$key .= Config("COMPOSITE_KEY_SEPARATOR");
					$key .= $this->loanid->CurrentValue;

					// Add filter for this record
					$filter = $this->getRecordFilter();
					if ($wrkfilter != "")
						$wrkfilter .= " OR ";
					$wrkfilter .= $filter;
				} else {
					break;
				}
			}
		}
		if ($addcnt == 0) { // No record inserted
			$this->clearInlineMode(); // Clear grid add mode and return
			return TRUE;
		}
		if ($gridInsert) {

			// Get new recordset
			$this->CurrentFilter = $wrkfilter;
			$sql = $this->getCurrentSql();
			if ($rs = $conn->execute($sql)) {
				$rsnew = $rs->getRows();
				$rs->close();
			}

			// Call Grid_Inserted event
			$this->Grid_Inserted($rsnew);
			if ($this->AuditTrailOnAdd)
				$this->writeAuditTrailDummy($Language->phrase("BatchInsertSuccess")); // Batch insert success
			$this->clearInlineMode(); // Clear grid add mode
		} else {
			if ($this->AuditTrailOnAdd)
				$this->writeAuditTrailDummy($Language->phrase("BatchInsertRollback")); // Batch insert rollback
			if ($this->getFailureMessage() == "")
				$this->setFailureMessage($Language->phrase("InsertFailed")); // Set insert failed message
		}
		return $gridInsert;
	}

	// Check if empty row
	public function emptyRow()
	{
		global $CurrentForm;
		if ($CurrentForm->hasValue("x__userid") && $CurrentForm->hasValue("o__userid") && $this->_userid->CurrentValue != $this->_userid->OldValue)
			return FALSE;
		if ($CurrentForm->hasValue("x_issueddate") && $CurrentForm->hasValue("o_issueddate") && $this->issueddate->CurrentValue != $this->issueddate->OldValue)
			return FALSE;
		if ($CurrentForm->hasValue("x_currcode") && $CurrentForm->hasValue("o_currcode") && $this->currcode->CurrentValue != $this->currcode->OldValue)
			return FALSE;
		if ($CurrentForm->hasValue("x_fullypaidind") && $CurrentForm->hasValue("o_fullypaidind") && $this->fullypaidind->CurrentValue != $this->fullypaidind->OldValue)
			return FALSE;
		if ($CurrentForm->hasValue("x_loanconfirmed") && $CurrentForm->hasValue("o_loanconfirmed") && $this->loanconfirmed->CurrentValue != $this->loanconfirmed->OldValue)
			return FALSE;
		if ($CurrentForm->hasValue("x_termtype") && $CurrentForm->hasValue("o_termtype") && $this->termtype->CurrentValue != $this->termtype->OldValue)
			return FALSE;
		return TRUE;
	}

	// Validate grid form
	public function validateGridForm()
	{
		global $CurrentForm;

		// Get row count
		$CurrentForm->Index = -1;
		$rowcnt = strval($CurrentForm->getValue($this->FormKeyCountName));
		if ($rowcnt == "" || !is_numeric($rowcnt))
			$rowcnt = 0;

		// Validate all records
		for ($rowindex = 1; $rowindex <= $rowcnt; $rowindex++) {

			// Load current row values
			$CurrentForm->Index = $rowindex;
			$rowaction = strval($CurrentForm->getValue($this->FormActionName));
			if ($rowaction != "delete" && $rowaction != "insertdelete") {
				$this->loadFormValues(); // Get form values
				if ($rowaction == "insert" && $this->emptyRow()) {

					// Ignore
				} else if (!$this->validateForm()) {
					return FALSE;
				}
			}
		}
		return TRUE;
	}

	// Get all form values of the grid
	public function getGridFormValues()
	{
		global $CurrentForm;

		// Get row count
		$CurrentForm->Index = -1;
		$rowcnt = strval($CurrentForm->getValue($this->FormKeyCountName));
		if ($rowcnt == "" || !is_numeric($rowcnt))
			$rowcnt = 0;
		$rows = [];

		// Loop through all records
		for ($rowindex = 1; $rowindex <= $rowcnt; $rowindex++) {

			// Load current row values
			$CurrentForm->Index = $rowindex;
			$rowaction = strval($CurrentForm->getValue($this->FormActionName));
			if ($rowaction != "delete" && $rowaction != "insertdelete") {
				$this->loadFormValues(); // Get form values
				if ($rowaction == "insert" && $this->emptyRow()) {

					// Ignore
				} else {
					$rows[] = $this->getFieldValues("FormValue"); // Return row as array
				}
			}
		}
		return $rows; // Return as array of array
	}

	// Restore form values for current row
	public function restoreCurrentRowFormValues($idx)
	{
		global $CurrentForm;

		// Get row based on current index
		$CurrentForm->Index = $idx;
		$this->loadFormValues(); // Load form values
	}

	// Set up sort parameters
	protected function setupSortOrder()
	{

		// Check for "order" parameter
		if (Get("order") !== NULL) {
			$this->CurrentOrder = Get("order");
			$this->CurrentOrderType = Get("ordertype", "");
			$this->setStartRecordNumber(1); // Reset start position
		}
	}

	// Load sort order parameters
	protected function loadSortOrder()
	{
		$orderBy = $this->getSessionOrderBy(); // Get ORDER BY from Session
		if ($orderBy == "") {
			if ($this->getSqlOrderBy() != "") {
				$orderBy = $this->getSqlOrderBy();
				$this->setSessionOrderBy($orderBy);
				$this->issueddate->setSort("DESC");
			}
		}
	}

	// Reset command
	// - cmd=reset (Reset search parameters)
	// - cmd=resetall (Reset search and master/detail parameters)
	// - cmd=resetsort (Reset sort parameters)

	protected function resetCmd()
	{

		// Check if reset command
		if (StartsString("reset", $this->Command)) {

			// Reset master/detail keys
			if ($this->Command == "resetall") {
				$this->setCurrentMasterTable(""); // Clear master table
				$this->DbMasterFilter = "";
				$this->DbDetailFilter = "";
				$this->loanid->setSessionValue("");
				$this->loanid->setSessionValue("");
				$this->_userid->setSessionValue("");
				$this->currcode->setSessionValue("");
			}

			// Reset sorting order
			if ($this->Command == "resetsort") {
				$orderBy = "";
				$this->setSessionOrderBy($orderBy);
			}

			// Reset start position
			$this->StartRecord = 1;
			$this->setStartRecordNumber($this->StartRecord);
		}
	}

	// Set up list options
	protected function setupListOptions()
	{
		global $Security, $Language;

		// "griddelete"
		if ($this->AllowAddDeleteRow) {
			$item = &$this->ListOptions->add("griddelete");
			$item->CssClass = "text-nowrap";
			$item->OnLeft = FALSE;
			$item->Visible = FALSE; // Default hidden
		}

		// Add group option item
		$item = &$this->ListOptions->add($this->ListOptions->GroupOptionName);
		$item->Body = "";
		$item->OnLeft = FALSE;
		$item->Visible = FALSE;

		// "view"
		$item = &$this->ListOptions->add("view");
		$item->CssClass = "text-nowrap";
		$item->Visible = $Security->canView();
		$item->OnLeft = FALSE;

		// "edit"
		$item = &$this->ListOptions->add("edit");
		$item->CssClass = "text-nowrap";
		$item->Visible = $Security->canEdit();
		$item->OnLeft = FALSE;

		// "copy"
		$item = &$this->ListOptions->add("copy");
		$item->CssClass = "text-nowrap";
		$item->Visible = $Security->canAdd();
		$item->OnLeft = FALSE;

		// "delete"
		$item = &$this->ListOptions->add("delete");
		$item->CssClass = "text-nowrap";
		$item->Visible = $Security->canDelete();
		$item->OnLeft = FALSE;

		// Drop down button for ListOptions
		$this->ListOptions->UseDropDownButton = FALSE;
		$this->ListOptions->DropDownButtonPhrase = $Language->phrase("ButtonListOptions");
		$this->ListOptions->UseButtonGroup = FALSE;
		if ($this->ListOptions->UseButtonGroup && IsMobile())
			$this->ListOptions->UseDropDownButton = TRUE;

		//$this->ListOptions->ButtonClass = ""; // Class for button group
		// Call ListOptions_Load event

		$this->ListOptions_Load();
		$item = $this->ListOptions[$this->ListOptions->GroupOptionName];
		$item->Visible = $this->ListOptions->groupOptionVisible();
	}

	// Render list options
	public function renderListOptions()
	{
		global $Security, $Language, $CurrentForm;
		$this->ListOptions->loadDefault();

		// Call ListOptions_Rendering event
		$this->ListOptions_Rendering();

		// Set up row action and key
		if (is_numeric($this->RowIndex) && $this->CurrentMode != "view") {
			$CurrentForm->Index = $this->RowIndex;
			$actionName = str_replace("k_", "k" . $this->RowIndex . "_", $this->FormActionName);
			$oldKeyName = str_replace("k_", "k" . $this->RowIndex . "_", $this->FormOldKeyName);
			$keyName = str_replace("k_", "k" . $this->RowIndex . "_", $this->FormKeyName);
			$blankRowName = str_replace("k_", "k" . $this->RowIndex . "_", $this->FormBlankRowName);
			if ($this->RowAction != "")
				$this->MultiSelectKey .= "<input type=\"hidden\" name=\"" . $actionName . "\" id=\"" . $actionName . "\" value=\"" . $this->RowAction . "\">";
			if ($CurrentForm->hasValue($this->FormOldKeyName))
				$this->RowOldKey = strval($CurrentForm->getValue($this->FormOldKeyName));
			if ($this->RowOldKey != "")
				$this->MultiSelectKey .= "<input type=\"hidden\" name=\"" . $oldKeyName . "\" id=\"" . $oldKeyName . "\" value=\"" . HtmlEncode($this->RowOldKey) . "\">";
			if ($this->RowAction == "delete") {
				$rowkey = $CurrentForm->getValue($this->FormKeyName);
				$this->setupKeyValues($rowkey);

				// Reload hidden key for delete
				$this->MultiSelectKey .= "<input type=\"hidden\" name=\"" . $keyName . "\" id=\"" . $keyName . "\" value=\"" . HtmlEncode($rowkey) . "\">";
			}
			if ($this->RowAction == "insert" && $this->isConfirm() && $this->emptyRow())
				$this->MultiSelectKey .= "<input type=\"hidden\" name=\"" . $blankRowName . "\" id=\"" . $blankRowName . "\" value=\"1\">";
		}

		// "delete"
		if ($this->AllowAddDeleteRow) {
			if ($this->CurrentMode == "add" || $this->CurrentMode == "copy" || $this->CurrentMode == "edit") {
				$options = &$this->ListOptions;
				$options->UseButtonGroup = TRUE; // Use button group for grid delete button
				$opt = $options["griddelete"];
				if (!$Security->canDelete() && is_numeric($this->RowIndex) && ($this->RowAction == "" || $this->RowAction == "edit")) { // Do not allow delete existing record
					$opt->Body = "&nbsp;";
				} else {
					$opt->Body = "<a class=\"ew-grid-link ew-grid-delete\" title=\"" . HtmlTitle($Language->phrase("DeleteLink")) . "\" data-caption=\"" . HtmlTitle($Language->phrase("DeleteLink")) . "\" onclick=\"return ew.deleteGridRow(this, " . $this->RowIndex . ");\">" . $Language->phrase("DeleteLink") . "</a>";
				}
			}
		}
		if ($this->CurrentMode == "view") { // View mode

		// "view"
		$opt = $this->ListOptions["view"];
		$viewcaption = HtmlTitle($Language->phrase("ViewLink"));
		if ($Security->canView()) {
			$opt->Body = "<a class=\"ew-row-link ew-view\" title=\"" . $viewcaption . "\" data-caption=\"" . $viewcaption . "\" href=\"" . HtmlEncode($this->ViewUrl) . "\">" . $Language->phrase("ViewLink") . "</a>";
		} else {
			$opt->Body = "";
		}

		// "edit"
		$opt = $this->ListOptions["edit"];
		$editcaption = HtmlTitle($Language->phrase("EditLink"));
		if ($Security->canEdit()) {
			$opt->Body = "<a class=\"ew-row-link ew-edit\" title=\"" . HtmlTitle($Language->phrase("EditLink")) . "\" data-caption=\"" . HtmlTitle($Language->phrase("EditLink")) . "\" href=\"" . HtmlEncode($this->EditUrl) . "\">" . $Language->phrase("EditLink") . "</a>";
		} else {
			$opt->Body = "";
		}

		// "copy"
		$opt = $this->ListOptions["copy"];
		$copycaption = HtmlTitle($Language->phrase("CopyLink"));
		if ($Security->canAdd()) {
			$opt->Body = "<a class=\"ew-row-link ew-copy\" title=\"" . $copycaption . "\" data-caption=\"" . $copycaption . "\" href=\"" . HtmlEncode($this->CopyUrl) . "\">" . $Language->phrase("CopyLink") . "</a>";
		} else {
			$opt->Body = "";
		}

		// "delete"
		$opt = $this->ListOptions["delete"];
		if ($Security->canDelete())
			$opt->Body = "<a class=\"ew-row-link ew-delete\"" . "" . " title=\"" . HtmlTitle($Language->phrase("DeleteLink")) . "\" data-caption=\"" . HtmlTitle($Language->phrase("DeleteLink")) . "\" href=\"" . HtmlEncode($this->DeleteUrl) . "\">" . $Language->phrase("DeleteLink") . "</a>";
		else
			$opt->Body = "";
		} // End View mode
		if ($this->CurrentMode == "edit" && is_numeric($this->RowIndex) && $this->RowAction != "delete") {
			$this->MultiSelectKey .= "<input type=\"hidden\" name=\"" . $keyName . "\" id=\"" . $keyName . "\" value=\"" . $this->loanid->CurrentValue . "\">";
		}
		$this->renderListOptionsExt();

		// Call ListOptions_Rendered event
		$this->ListOptions_Rendered();
	}

	// Set record key
	public function setRecordKey(&$key, $rs)
	{
		$key = "";
		if ($key != "")
			$key .= Config("COMPOSITE_KEY_SEPARATOR");
		$key .= $rs->fields('loanid');
	}

	// Set up other options
	protected function setupOtherOptions()
	{
		global $Language, $Security;
		$option = $this->OtherOptions["addedit"];
		$option->UseDropDownButton = FALSE;
		$option->DropDownButtonPhrase = $Language->phrase("ButtonAddEdit");
		$option->UseButtonGroup = TRUE;

		//$option->ButtonClass = ""; // Class for button group
		$item = &$option->add($option->GroupOptionName);
		$item->Body = "";
		$item->Visible = FALSE;

		// Add
		if ($this->CurrentMode == "view") { // Check view mode
			$item = &$option->add("add");
			$addcaption = HtmlTitle($Language->phrase("AddLink"));
			$this->AddUrl = $this->getAddUrl();
			$item->Body = "<a class=\"ew-add-edit ew-add\" title=\"" . $addcaption . "\" data-caption=\"" . $addcaption . "\" href=\"" . HtmlEncode($this->AddUrl) . "\">" . $Language->phrase("AddLink") . "</a>";
			$item->Visible = $this->AddUrl != "" && $Security->canAdd();
		}
	}

	// Render other options
	public function renderOtherOptions()
	{
		global $Language, $Security;
		$options = &$this->OtherOptions;
		if (($this->CurrentMode == "add" || $this->CurrentMode == "copy" || $this->CurrentMode == "edit") && !$this->isConfirm()) { // Check add/copy/edit mode
			if ($this->AllowAddDeleteRow) {
				$option = $options["addedit"];
				$option->UseDropDownButton = FALSE;
				$item = &$option->add("addblankrow");
				$item->Body = "<a class=\"ew-add-edit ew-add-blank-row\" title=\"" . HtmlTitle($Language->phrase("AddBlankRow")) . "\" data-caption=\"" . HtmlTitle($Language->phrase("AddBlankRow")) . "\" href=\"#\" onclick=\"return ew.addGridRow(this);\">" . $Language->phrase("AddBlankRow") . "</a>";
				$item->Visible = $Security->canAdd();
				$this->ShowOtherOptions = $item->Visible;
			}
		}
		if ($this->CurrentMode == "view") { // Check view mode
			$option = $options["addedit"];
			$item = $option["add"];
			$this->ShowOtherOptions = $item && $item->Visible;
		}
	}

// Set up list options (extended codes)
	protected function setupListOptionsExt()
	{

		// Hide detail items for dropdown if necessary
		$this->ListOptions->hideDetailItemsForDropDown();
	}

// Render list options (extended codes)
	protected function renderListOptionsExt()
	{
		global $Security, $Language;
		$links = "";
		$btngrps = "";
		$sqlwrk = "`loanid`=" . AdjustSql($this->loanid->CurrentValue, $this->Dbid) . "";

		// Column "detail_loanissuedupgrades"
		if ($this->DetailPages && $this->DetailPages["loanissuedupgrades"] && $this->DetailPages["loanissuedupgrades"]->Visible) {
			$link = "";
			$option = $this->ListOptions["detail_loanissuedupgrades"];
			$url = "loanissuedupgradespreview.php?t=loanissued&f=" . Encrypt($sqlwrk);
			$btngrp = "<div data-table=\"loanissuedupgrades\" data-url=\"" . $url . "\">";
			if ($Security->allowList(CurrentProjectID() . 'loanissued')) {
				$label = $Language->TablePhrase("loanissuedupgrades", "TblCaption");
				$label .= "&nbsp;" . JsEncode(str_replace("%c", $this->loanissuedupgrades_Count, $Language->phrase("DetailCount")));
				$link = "<li class=\"nav-item\"><a href=\"#\" class=\"nav-link\" data-toggle=\"tab\" data-table=\"loanissuedupgrades\" data-url=\"" . $url . "\">" . $label . "</a></li>";
				$links .= $link;
				$detaillnk = JsEncodeAttribute("loanissuedupgradeslist.php?" . Config("TABLE_SHOW_MASTER") . "=loanissued&fk_loanid=" . urlencode(strval($this->loanid->CurrentValue)) . "");
				$btngrp .= "<a href=\"#\" class=\"mr-2\" title=\"" . $Language->TablePhrase("loanissuedupgrades", "TblCaption") . "\" onclick=\"window.location='" . $detaillnk . "';return false;\">" . $Language->phrase("MasterDetailListLink") . "</a>";
			}
			if (!isset($GLOBALS["loanissuedupgrades_grid"]))
				$GLOBALS["loanissuedupgrades_grid"] = new loanissuedupgrades_grid();
			if ($GLOBALS["loanissuedupgrades_grid"]->DetailView && $Security->canView() && $Security->allowView(CurrentProjectID() . 'loanissued')) {
				$caption = $Language->phrase("MasterDetailViewLink");
				$url = $this->getViewUrl(Config("TABLE_SHOW_DETAIL") . "=loanissuedupgrades");
				$btngrp .= "<a href=\"#\" class=\"mr-2\" title=\"" . HtmlTitle($caption) . "\" onclick=\"window.location='" . HtmlEncode($url) . "';return false;\">" . $caption . "</a>";
			}
			if ($GLOBALS["loanissuedupgrades_grid"]->DetailEdit && $Security->canEdit() && $Security->allowEdit(CurrentProjectID() . 'loanissued')) {
				$caption = $Language->phrase("MasterDetailEditLink");
				$url = $this->getEditUrl(Config("TABLE_SHOW_DETAIL") . "=loanissuedupgrades");
				$btngrp .= "<a href=\"#\" class=\"mr-2\" title=\"" . HtmlTitle($caption) . "\" onclick=\"window.location='" . HtmlEncode($url) . "';return false;\">" . $caption . "</a>";
			}
			if ($GLOBALS["loanissuedupgrades_grid"]->DetailAdd && $Security->canAdd() && $Security->allowAdd(CurrentProjectID() . 'loanissued')) {
				$caption = $Language->phrase("MasterDetailCopyLink");
				$url = $this->getCopyUrl(Config("TABLE_SHOW_DETAIL") . "=loanissuedupgrades");
				$btngrp .= "<a href=\"#\" class=\"mr-2\" title=\"" . HtmlTitle($caption) . "\" onclick=\"window.location='" . HtmlEncode($url) . "';return false;\">" . $caption . "</a>";
			}
			$btngrp .= "</div>";
			if ($link != "") {
				$btngrps .= $btngrp;
				$option->Body .= "<div class=\"d-none ew-preview\">" . $link . $btngrp . "</div>";
			}
		}
		$sqlwrk = "`userid`=" . AdjustSql($this->loanid->CurrentValue, $this->Dbid) . "";

		// Column "detail_loaneventhistory"
		if ($this->DetailPages && $this->DetailPages["loaneventhistory"] && $this->DetailPages["loaneventhistory"]->Visible) {
			$link = "";
			$option = $this->ListOptions["detail_loaneventhistory"];
			$url = "loaneventhistorypreview.php?t=loanissued&f=" . Encrypt($sqlwrk);
			$btngrp = "<div data-table=\"loaneventhistory\" data-url=\"" . $url . "\">";
			if ($Security->allowList(CurrentProjectID() . 'loanissued')) {
				$label = $Language->TablePhrase("loaneventhistory", "TblCaption");
				$label .= "&nbsp;" . JsEncode(str_replace("%c", $this->loaneventhistory_Count, $Language->phrase("DetailCount")));
				$link = "<li class=\"nav-item\"><a href=\"#\" class=\"nav-link\" data-toggle=\"tab\" data-table=\"loaneventhistory\" data-url=\"" . $url . "\">" . $label . "</a></li>";
				$links .= $link;
				$detaillnk = JsEncodeAttribute("loaneventhistorylist.php?" . Config("TABLE_SHOW_MASTER") . "=loanissued&fk_loanid=" . urlencode(strval($this->loanid->CurrentValue)) . "");
				$btngrp .= "<a href=\"#\" class=\"mr-2\" title=\"" . $Language->TablePhrase("loaneventhistory", "TblCaption") . "\" onclick=\"window.location='" . $detaillnk . "';return false;\">" . $Language->phrase("MasterDetailListLink") . "</a>";
			}
			if (!isset($GLOBALS["loaneventhistory_grid"]))
				$GLOBALS["loaneventhistory_grid"] = new loaneventhistory_grid();
			if ($GLOBALS["loaneventhistory_grid"]->DetailView && $Security->canView() && $Security->allowView(CurrentProjectID() . 'loanissued')) {
				$caption = $Language->phrase("MasterDetailViewLink");
				$url = $this->getViewUrl(Config("TABLE_SHOW_DETAIL") . "=loaneventhistory");
				$btngrp .= "<a href=\"#\" class=\"mr-2\" title=\"" . HtmlTitle($caption) . "\" onclick=\"window.location='" . HtmlEncode($url) . "';return false;\">" . $caption . "</a>";
			}
			if ($GLOBALS["loaneventhistory_grid"]->DetailEdit && $Security->canEdit() && $Security->allowEdit(CurrentProjectID() . 'loanissued')) {
				$caption = $Language->phrase("MasterDetailEditLink");
				$url = $this->getEditUrl(Config("TABLE_SHOW_DETAIL") . "=loaneventhistory");
				$btngrp .= "<a href=\"#\" class=\"mr-2\" title=\"" . HtmlTitle($caption) . "\" onclick=\"window.location='" . HtmlEncode($url) . "';return false;\">" . $caption . "</a>";
			}
			if ($GLOBALS["loaneventhistory_grid"]->DetailAdd && $Security->canAdd() && $Security->allowAdd(CurrentProjectID() . 'loanissued')) {
				$caption = $Language->phrase("MasterDetailCopyLink");
				$url = $this->getCopyUrl(Config("TABLE_SHOW_DETAIL") . "=loaneventhistory");
				$btngrp .= "<a href=\"#\" class=\"mr-2\" title=\"" . HtmlTitle($caption) . "\" onclick=\"window.location='" . HtmlEncode($url) . "';return false;\">" . $caption . "</a>";
			}
			$btngrp .= "</div>";
			if ($link != "") {
				$btngrps .= $btngrp;
				$option->Body .= "<div class=\"d-none ew-preview\">" . $link . $btngrp . "</div>";
			}
		}
		$sqlwrk = "`loanid`=" . AdjustSql($this->loanid->CurrentValue, $this->Dbid) . "";
		$sqlwrk = $sqlwrk . " AND " . "`currcode`='" . AdjustSql($this->currcode->CurrentValue, $this->Dbid) . "'";
		$sqlwrk = $sqlwrk . " AND " . "`userid`=" . AdjustSql($this->_userid->CurrentValue, $this->Dbid) . "";

		// Column "detail_loanlatefees"
		if ($this->DetailPages && $this->DetailPages["loanlatefees"] && $this->DetailPages["loanlatefees"]->Visible) {
			$link = "";
			$option = $this->ListOptions["detail_loanlatefees"];
			$url = "loanlatefeespreview.php?t=loanissued&f=" . Encrypt($sqlwrk);
			$btngrp = "<div data-table=\"loanlatefees\" data-url=\"" . $url . "\">";
			if ($Security->allowList(CurrentProjectID() . 'loanissued')) {
				$label = $Language->TablePhrase("loanlatefees", "TblCaption");
				$label .= "&nbsp;" . JsEncode(str_replace("%c", $this->loanlatefees_Count, $Language->phrase("DetailCount")));
				$link = "<li class=\"nav-item\"><a href=\"#\" class=\"nav-link\" data-toggle=\"tab\" data-table=\"loanlatefees\" data-url=\"" . $url . "\">" . $label . "</a></li>";
				$links .= $link;
				$detaillnk = JsEncodeAttribute("loanlatefeeslist.php?" . Config("TABLE_SHOW_MASTER") . "=loanissued&fk_loanid=" . urlencode(strval($this->loanid->CurrentValue)) . "&fk_currcode=" . urlencode(strval($this->currcode->CurrentValue)) . "&fk__userid=" . urlencode(strval($this->_userid->CurrentValue)) . "");
				$btngrp .= "<a href=\"#\" class=\"mr-2\" title=\"" . $Language->TablePhrase("loanlatefees", "TblCaption") . "\" onclick=\"window.location='" . $detaillnk . "';return false;\">" . $Language->phrase("MasterDetailListLink") . "</a>";
			}
			if (!isset($GLOBALS["loanlatefees_grid"]))
				$GLOBALS["loanlatefees_grid"] = new loanlatefees_grid();
			if ($GLOBALS["loanlatefees_grid"]->DetailView && $Security->canView() && $Security->allowView(CurrentProjectID() . 'loanissued')) {
				$caption = $Language->phrase("MasterDetailViewLink");
				$url = $this->getViewUrl(Config("TABLE_SHOW_DETAIL") . "=loanlatefees");
				$btngrp .= "<a href=\"#\" class=\"mr-2\" title=\"" . HtmlTitle($caption) . "\" onclick=\"window.location='" . HtmlEncode($url) . "';return false;\">" . $caption . "</a>";
			}
			if ($GLOBALS["loanlatefees_grid"]->DetailEdit && $Security->canEdit() && $Security->allowEdit(CurrentProjectID() . 'loanissued')) {
				$caption = $Language->phrase("MasterDetailEditLink");
				$url = $this->getEditUrl(Config("TABLE_SHOW_DETAIL") . "=loanlatefees");
				$btngrp .= "<a href=\"#\" class=\"mr-2\" title=\"" . HtmlTitle($caption) . "\" onclick=\"window.location='" . HtmlEncode($url) . "';return false;\">" . $caption . "</a>";
			}
			if ($GLOBALS["loanlatefees_grid"]->DetailAdd && $Security->canAdd() && $Security->allowAdd(CurrentProjectID() . 'loanissued')) {
				$caption = $Language->phrase("MasterDetailCopyLink");
				$url = $this->getCopyUrl(Config("TABLE_SHOW_DETAIL") . "=loanlatefees");
				$btngrp .= "<a href=\"#\" class=\"mr-2\" title=\"" . HtmlTitle($caption) . "\" onclick=\"window.location='" . HtmlEncode($url) . "';return false;\">" . $caption . "</a>";
			}
			$btngrp .= "</div>";
			if ($link != "") {
				$btngrps .= $btngrp;
				$option->Body .= "<div class=\"d-none ew-preview\">" . $link . $btngrp . "</div>";
			}
		}
		$sqlwrk = "`loanid`=" . AdjustSql($this->loanid->CurrentValue, $this->Dbid) . "";

		// Column "detail_loanapplied"
		if ($this->DetailPages && $this->DetailPages["loanapplied"] && $this->DetailPages["loanapplied"]->Visible) {
			$link = "";
			$option = $this->ListOptions["detail_loanapplied"];
			$url = "loanappliedpreview.php?t=loanissued&f=" . Encrypt($sqlwrk);
			$btngrp = "<div data-table=\"loanapplied\" data-url=\"" . $url . "\">";
			if ($Security->allowList(CurrentProjectID() . 'loanissued')) {
				$label = $Language->TablePhrase("loanapplied", "TblCaption");
				$label .= "&nbsp;" . JsEncode(str_replace("%c", $this->loanapplied_Count, $Language->phrase("DetailCount")));
				$link = "<li class=\"nav-item\"><a href=\"#\" class=\"nav-link\" data-toggle=\"tab\" data-table=\"loanapplied\" data-url=\"" . $url . "\">" . $label . "</a></li>";
				$links .= $link;
				$detaillnk = JsEncodeAttribute("loanappliedlist.php?" . Config("TABLE_SHOW_MASTER") . "=loanissued&fk_loanid=" . urlencode(strval($this->loanid->CurrentValue)) . "");
				$btngrp .= "<a href=\"#\" class=\"mr-2\" title=\"" . $Language->TablePhrase("loanapplied", "TblCaption") . "\" onclick=\"window.location='" . $detaillnk . "';return false;\">" . $Language->phrase("MasterDetailListLink") . "</a>";
			}
			if (!isset($GLOBALS["loanapplied_grid"]))
				$GLOBALS["loanapplied_grid"] = new loanapplied_grid();
			if ($GLOBALS["loanapplied_grid"]->DetailView && $Security->canView() && $Security->allowView(CurrentProjectID() . 'loanissued')) {
				$caption = $Language->phrase("MasterDetailViewLink");
				$url = $this->getViewUrl(Config("TABLE_SHOW_DETAIL") . "=loanapplied");
				$btngrp .= "<a href=\"#\" class=\"mr-2\" title=\"" . HtmlTitle($caption) . "\" onclick=\"window.location='" . HtmlEncode($url) . "';return false;\">" . $caption . "</a>";
			}
			if ($GLOBALS["loanapplied_grid"]->DetailEdit && $Security->canEdit() && $Security->allowEdit(CurrentProjectID() . 'loanissued')) {
				$caption = $Language->phrase("MasterDetailEditLink");
				$url = $this->getEditUrl(Config("TABLE_SHOW_DETAIL") . "=loanapplied");
				$btngrp .= "<a href=\"#\" class=\"mr-2\" title=\"" . HtmlTitle($caption) . "\" onclick=\"window.location='" . HtmlEncode($url) . "';return false;\">" . $caption . "</a>";
			}
			if ($GLOBALS["loanapplied_grid"]->DetailAdd && $Security->canAdd() && $Security->allowAdd(CurrentProjectID() . 'loanissued')) {
				$caption = $Language->phrase("MasterDetailCopyLink");
				$url = $this->getCopyUrl(Config("TABLE_SHOW_DETAIL") . "=loanapplied");
				$btngrp .= "<a href=\"#\" class=\"mr-2\" title=\"" . HtmlTitle($caption) . "\" onclick=\"window.location='" . HtmlEncode($url) . "';return false;\">" . $caption . "</a>";
			}
			$btngrp .= "</div>";
			if ($link != "") {
				$btngrps .= $btngrp;
				$option->Body .= "<div class=\"d-none ew-preview\">" . $link . $btngrp . "</div>";
			}
		}
		$sqlwrk = "`loanid`=" . AdjustSql($this->loanid->CurrentValue, $this->Dbid) . "";
		$sqlwrk = $sqlwrk . " AND " . "`currcode`='" . AdjustSql($this->currcode->CurrentValue, $this->Dbid) . "'";

		// Column "detail_loanpayments"
		if ($this->DetailPages && $this->DetailPages["loanpayments"] && $this->DetailPages["loanpayments"]->Visible) {
			$link = "";
			$option = $this->ListOptions["detail_loanpayments"];
			$url = "loanpaymentspreview.php?t=loanissued&f=" . Encrypt($sqlwrk);
			$btngrp = "<div data-table=\"loanpayments\" data-url=\"" . $url . "\">";
			if ($Security->allowList(CurrentProjectID() . 'loanissued')) {
				$label = $Language->TablePhrase("loanpayments", "TblCaption");
				$label .= "&nbsp;" . JsEncode(str_replace("%c", $this->loanpayments_Count, $Language->phrase("DetailCount")));
				$link = "<li class=\"nav-item\"><a href=\"#\" class=\"nav-link\" data-toggle=\"tab\" data-table=\"loanpayments\" data-url=\"" . $url . "\">" . $label . "</a></li>";
				$links .= $link;
				$detaillnk = JsEncodeAttribute("loanpaymentslist.php?" . Config("TABLE_SHOW_MASTER") . "=loanissued&fk_loanid=" . urlencode(strval($this->loanid->CurrentValue)) . "&fk_currcode=" . urlencode(strval($this->currcode->CurrentValue)) . "");
				$btngrp .= "<a href=\"#\" class=\"mr-2\" title=\"" . $Language->TablePhrase("loanpayments", "TblCaption") . "\" onclick=\"window.location='" . $detaillnk . "';return false;\">" . $Language->phrase("MasterDetailListLink") . "</a>";
			}
			if (!isset($GLOBALS["loanpayments_grid"]))
				$GLOBALS["loanpayments_grid"] = new loanpayments_grid();
			if ($GLOBALS["loanpayments_grid"]->DetailView && $Security->canView() && $Security->allowView(CurrentProjectID() . 'loanissued')) {
				$caption = $Language->phrase("MasterDetailViewLink");
				$url = $this->getViewUrl(Config("TABLE_SHOW_DETAIL") . "=loanpayments");
				$btngrp .= "<a href=\"#\" class=\"mr-2\" title=\"" . HtmlTitle($caption) . "\" onclick=\"window.location='" . HtmlEncode($url) . "';return false;\">" . $caption . "</a>";
			}
			if ($GLOBALS["loanpayments_grid"]->DetailEdit && $Security->canEdit() && $Security->allowEdit(CurrentProjectID() . 'loanissued')) {
				$caption = $Language->phrase("MasterDetailEditLink");
				$url = $this->getEditUrl(Config("TABLE_SHOW_DETAIL") . "=loanpayments");
				$btngrp .= "<a href=\"#\" class=\"mr-2\" title=\"" . HtmlTitle($caption) . "\" onclick=\"window.location='" . HtmlEncode($url) . "';return false;\">" . $caption . "</a>";
			}
			if ($GLOBALS["loanpayments_grid"]->DetailAdd && $Security->canAdd() && $Security->allowAdd(CurrentProjectID() . 'loanissued')) {
				$caption = $Language->phrase("MasterDetailCopyLink");
				$url = $this->getCopyUrl(Config("TABLE_SHOW_DETAIL") . "=loanpayments");
				$btngrp .= "<a href=\"#\" class=\"mr-2\" title=\"" . HtmlTitle($caption) . "\" onclick=\"window.location='" . HtmlEncode($url) . "';return false;\">" . $caption . "</a>";
			}
			$btngrp .= "</div>";
			if ($link != "") {
				$btngrps .= $btngrp;
				$option->Body .= "<div class=\"d-none ew-preview\">" . $link . $btngrp . "</div>";
			}
		}
		$sqlwrk = "`loanid`=" . AdjustSql($this->loanid->CurrentValue, $this->Dbid) . "";

		// Column "detail_loanpaymentplan"
		if ($this->DetailPages && $this->DetailPages["loanpaymentplan"] && $this->DetailPages["loanpaymentplan"]->Visible) {
			$link = "";
			$option = $this->ListOptions["detail_loanpaymentplan"];
			$url = "loanpaymentplanpreview.php?t=loanissued&f=" . Encrypt($sqlwrk);
			$btngrp = "<div data-table=\"loanpaymentplan\" data-url=\"" . $url . "\">";
			if ($Security->allowList(CurrentProjectID() . 'loanissued')) {
				$label = $Language->TablePhrase("loanpaymentplan", "TblCaption");
				$label .= "&nbsp;" . JsEncode(str_replace("%c", $this->loanpaymentplan_Count, $Language->phrase("DetailCount")));
				$link = "<li class=\"nav-item\"><a href=\"#\" class=\"nav-link\" data-toggle=\"tab\" data-table=\"loanpaymentplan\" data-url=\"" . $url . "\">" . $label . "</a></li>";
				$links .= $link;
				$detaillnk = JsEncodeAttribute("loanpaymentplanlist.php?" . Config("TABLE_SHOW_MASTER") . "=loanissued&fk_loanid=" . urlencode(strval($this->loanid->CurrentValue)) . "");
				$btngrp .= "<a href=\"#\" class=\"mr-2\" title=\"" . $Language->TablePhrase("loanpaymentplan", "TblCaption") . "\" onclick=\"window.location='" . $detaillnk . "';return false;\">" . $Language->phrase("MasterDetailListLink") . "</a>";
			}
			if (!isset($GLOBALS["loanpaymentplan_grid"]))
				$GLOBALS["loanpaymentplan_grid"] = new loanpaymentplan_grid();
			if ($GLOBALS["loanpaymentplan_grid"]->DetailView && $Security->canView() && $Security->allowView(CurrentProjectID() . 'loanissued')) {
				$caption = $Language->phrase("MasterDetailViewLink");
				$url = $this->getViewUrl(Config("TABLE_SHOW_DETAIL") . "=loanpaymentplan");
				$btngrp .= "<a href=\"#\" class=\"mr-2\" title=\"" . HtmlTitle($caption) . "\" onclick=\"window.location='" . HtmlEncode($url) . "';return false;\">" . $caption . "</a>";
			}
			if ($GLOBALS["loanpaymentplan_grid"]->DetailEdit && $Security->canEdit() && $Security->allowEdit(CurrentProjectID() . 'loanissued')) {
				$caption = $Language->phrase("MasterDetailEditLink");
				$url = $this->getEditUrl(Config("TABLE_SHOW_DETAIL") . "=loanpaymentplan");
				$btngrp .= "<a href=\"#\" class=\"mr-2\" title=\"" . HtmlTitle($caption) . "\" onclick=\"window.location='" . HtmlEncode($url) . "';return false;\">" . $caption . "</a>";
			}
			if ($GLOBALS["loanpaymentplan_grid"]->DetailAdd && $Security->canAdd() && $Security->allowAdd(CurrentProjectID() . 'loanissued')) {
				$caption = $Language->phrase("MasterDetailCopyLink");
				$url = $this->getCopyUrl(Config("TABLE_SHOW_DETAIL") . "=loanpaymentplan");
				$btngrp .= "<a href=\"#\" class=\"mr-2\" title=\"" . HtmlTitle($caption) . "\" onclick=\"window.location='" . HtmlEncode($url) . "';return false;\">" . $caption . "</a>";
			}
			$btngrp .= "</div>";
			if ($link != "") {
				$btngrps .= $btngrp;
				$option->Body .= "<div class=\"d-none ew-preview\">" . $link . $btngrp . "</div>";
			}
		}

		// Hide detail items if necessary
		$this->ListOptions->hideDetailItemsForDropDown();

		// Column "preview"
		$option = $this->ListOptions["preview"];
		if (!$option) { // Add preview column
			$option = &$this->ListOptions->add("preview");
			$option->OnLeft = FALSE;
			if ($option->OnLeft) {
				$option->moveTo($this->ListOptions->itemPos("checkbox") + 1);
			} else {
				$option->moveTo($this->ListOptions->itemPos("checkbox"));
			}
			$option->Visible = !($this->isExport() || $this->isGridAdd() || $this->isGridEdit());
			$option->ShowInDropDown = FALSE;
			$option->ShowInButtonGroup = FALSE;
		}
		if ($option) {
			$option->Body = "<i class=\"ew-preview-row-btn ew-icon icon-expand\"></i>";
			$option->Body .= "<div class=\"d-none ew-preview\">" . $links . $btngrps . "</div>";
			if ($option->Visible)
				$option->Visible = $links != "";
		}

		// Column "details" (Multiple details)
		$option = $this->ListOptions["details"];
		if ($option) {
			$option->Body .= "<div class=\"d-none ew-preview\">" . $links . $btngrps . "</div>";
			if ($option->Visible)
				$option->Visible = $links != "";
		}
	}

	// Get upload files
	protected function getUploadFiles()
	{
		global $CurrentForm, $Language;
	}

	// Load default values
	protected function loadDefaultValues()
	{
		$this->loanid->CurrentValue = NULL;
		$this->loanid->OldValue = $this->loanid->CurrentValue;
		$this->_userid->CurrentValue = NULL;
		$this->_userid->OldValue = $this->_userid->CurrentValue;
		$this->issueddate->CurrentValue = NULL;
		$this->issueddate->OldValue = $this->issueddate->CurrentValue;
		$this->currcode->CurrentValue = NULL;
		$this->currcode->OldValue = $this->currcode->CurrentValue;
		$this->issuedamount->CurrentValue = NULL;
		$this->issuedamount->OldValue = $this->issuedamount->CurrentValue;
		$this->externalrefno->CurrentValue = NULL;
		$this->externalrefno->OldValue = $this->externalrefno->CurrentValue;
		$this->fullypaidind->CurrentValue = 0;
		$this->fullypaidind->OldValue = $this->fullypaidind->CurrentValue;
		$this->bankcode->CurrentValue = NULL;
		$this->bankcode->OldValue = $this->bankcode->CurrentValue;
		$this->feeperc->CurrentValue = NULL;
		$this->feeperc->OldValue = $this->feeperc->CurrentValue;
		$this->feeamount->CurrentValue = NULL;
		$this->feeamount->OldValue = $this->feeamount->CurrentValue;
		$this->taxperc->CurrentValue = NULL;
		$this->taxperc->OldValue = $this->taxperc->CurrentValue;
		$this->taxamount->CurrentValue = NULL;
		$this->taxamount->OldValue = $this->taxamount->CurrentValue;
		$this->totalamount->CurrentValue = NULL;
		$this->totalamount->OldValue = $this->totalamount->CurrentValue;
		$this->paymenttargetdate->CurrentValue = NULL;
		$this->paymenttargetdate->OldValue = $this->paymenttargetdate->CurrentValue;
		$this->feefixed->CurrentValue = 0;
		$this->feefixed->OldValue = $this->feefixed->CurrentValue;
		$this->totalfees->CurrentValue = 0;
		$this->totalfees->OldValue = $this->totalfees->CurrentValue;
		$this->approveruserid->CurrentValue = 0;
		$this->approveruserid->OldValue = $this->approveruserid->CurrentValue;
		$this->docid->CurrentValue = NULL;
		$this->docid->OldValue = $this->docid->CurrentValue;
		$this->feesystemtotal->CurrentValue = 0.00;
		$this->feesystemtotal->OldValue = $this->feesystemtotal->CurrentValue;
		$this->feeexternaltotal->CurrentValue = 0.00;
		$this->feeexternaltotal->OldValue = $this->feeexternaltotal->CurrentValue;
		$this->feefranchiseetotal->CurrentValue = 0.00;
		$this->feefranchiseetotal->OldValue = $this->feefranchiseetotal->CurrentValue;
		$this->feeresellertotal->CurrentValue = 0.00;
		$this->feeresellertotal->OldValue = $this->feeresellertotal->CurrentValue;
		$this->purchasefeeid->CurrentValue = 0;
		$this->purchasefeeid->OldValue = $this->purchasefeeid->CurrentValue;
		$this->cancellationrefid->CurrentValue = NULL;
		$this->cancellationrefid->OldValue = $this->cancellationrefid->CurrentValue;
		$this->cancellationdatetime->CurrentValue = NULL;
		$this->cancellationdatetime->OldValue = $this->cancellationdatetime->CurrentValue;
		$this->cancellationreason->CurrentValue = NULL;
		$this->cancellationreason->OldValue = $this->cancellationreason->CurrentValue;
		$this->lastupdatedate->CurrentValue = NULL;
		$this->lastupdatedate->OldValue = $this->lastupdatedate->CurrentValue;
		$this->feeexternaltotaltime->CurrentValue = 0.00;
		$this->feeexternaltotaltime->OldValue = $this->feeexternaltotaltime->CurrentValue;
		$this->totalamountapplied->CurrentValue = 0.00;
		$this->totalamountapplied->OldValue = $this->totalamountapplied->CurrentValue;
		$this->totalfeesapplied->CurrentValue = 0.00;
		$this->totalfeesapplied->OldValue = $this->totalfeesapplied->CurrentValue;
		$this->totalprincipleandfees->CurrentValue = 0.00;
		$this->totalprincipleandfees->OldValue = $this->totalprincipleandfees->CurrentValue;
		$this->taxamountbreakdown->CurrentValue = 0.00;
		$this->taxamountbreakdown->OldValue = $this->taxamountbreakdown->CurrentValue;
		$this->feesystembreakdown->CurrentValue = 0.00;
		$this->feesystembreakdown->OldValue = $this->feesystembreakdown->CurrentValue;
		$this->feeexternalbreakdown->CurrentValue = 0.00;
		$this->feeexternalbreakdown->OldValue = $this->feeexternalbreakdown->CurrentValue;
		$this->feefranchiseebreakdown->CurrentValue = 0.00;
		$this->feefranchiseebreakdown->OldValue = $this->feefranchiseebreakdown->CurrentValue;
		$this->feeresellerbreakdown->CurrentValue = 0.00;
		$this->feeresellerbreakdown->OldValue = $this->feeresellerbreakdown->CurrentValue;
		$this->outstandingprinciple->CurrentValue = 0.00;
		$this->outstandingprinciple->OldValue = $this->outstandingprinciple->CurrentValue;
		$this->outstandingfees->CurrentValue = 0.00;
		$this->outstandingfees->OldValue = $this->outstandingfees->CurrentValue;
		$this->outstandingprincipleandfees->CurrentValue = 0.00;
		$this->outstandingprincipleandfees->OldValue = $this->outstandingprincipleandfees->CurrentValue;
		$this->lastupdate->CurrentValue = NULL;
		$this->lastupdate->OldValue = $this->lastupdate->CurrentValue;
		$this->externalprovisioningrefno->CurrentValue = NULL;
		$this->externalprovisioningrefno->OldValue = $this->externalprovisioningrefno->CurrentValue;
		$this->loantype->CurrentValue = NULL;
		$this->loantype->OldValue = $this->loantype->CurrentValue;
		$this->numberofoutstandingdays->CurrentValue = 0;
		$this->numberofoutstandingdays->OldValue = $this->numberofoutstandingdays->CurrentValue;
		$this->loandue->CurrentValue = 0;
		$this->loandue->OldValue = $this->loandue->CurrentValue;
		$this->loanduedate->CurrentValue = NULL;
		$this->loanduedate->OldValue = $this->loanduedate->CurrentValue;
		$this->outstandinglatefees->CurrentValue = 0.00;
		$this->outstandinglatefees->OldValue = $this->outstandinglatefees->CurrentValue;
		$this->disbursementtype->CurrentValue = 1;
		$this->disbursementtype->OldValue = $this->disbursementtype->CurrentValue;
		$this->disbursementamount->CurrentValue = 0.00;
		$this->disbursementamount->OldValue = $this->disbursementamount->CurrentValue;
		$this->loanconfirmed->CurrentValue = 0;
		$this->loanconfirmed->OldValue = $this->loanconfirmed->CurrentValue;
		$this->loanconfirmedtime->CurrentValue = NULL;
		$this->loanconfirmedtime->OldValue = $this->loanconfirmedtime->CurrentValue;
		$this->loanupgraded->CurrentValue = 0;
		$this->loanupgraded->OldValue = $this->loanupgraded->CurrentValue;
		$this->stoplatefee->CurrentValue = 0;
		$this->stoplatefee->OldValue = $this->stoplatefee->CurrentValue;
		$this->otherdetails1->CurrentValue = NULL;
		$this->otherdetails1->OldValue = $this->otherdetails1->CurrentValue;
		$this->lockflag->CurrentValue = 0;
		$this->lockflag->OldValue = $this->lockflag->CurrentValue;
		$this->lastlatefeecalculatedate->CurrentValue = NULL;
		$this->lastlatefeecalculatedate->OldValue = $this->lastlatefeecalculatedate->CurrentValue;
		$this->notificationlockflag->CurrentValue = 0;
		$this->notificationlockflag->OldValue = $this->notificationlockflag->CurrentValue;
		$this->lastnotificationdate->CurrentValue = NULL;
		$this->lastnotificationdate->OldValue = $this->lastnotificationdate->CurrentValue;
		$this->sendnotificationtextdate->CurrentValue = NULL;
		$this->sendnotificationtextdate->OldValue = $this->sendnotificationtextdate->CurrentValue;
		$this->termtype->CurrentValue = 0;
		$this->termtype->OldValue = $this->termtype->CurrentValue;
	}

	// Load form values
	protected function loadFormValues()
	{

		// Load from form
		global $CurrentForm;
		$CurrentForm->FormName = $this->FormName;

		// Check field name 'loanid' first before field var 'x_loanid'
		$val = $CurrentForm->hasValue("loanid") ? $CurrentForm->getValue("loanid") : $CurrentForm->getValue("x_loanid");
		if (!$this->loanid->IsDetailKey && !$this->isGridAdd() && !$this->isAdd())
			$this->loanid->setFormValue($val);

		// Check field name 'userid' first before field var 'x__userid'
		$val = $CurrentForm->hasValue("userid") ? $CurrentForm->getValue("userid") : $CurrentForm->getValue("x__userid");
		if (!$this->_userid->IsDetailKey) {
			if (IsApi() && $val === NULL)
				$this->_userid->Visible = FALSE; // Disable update for API request
			else
				$this->_userid->setFormValue($val);
		}
		if ($CurrentForm->hasValue("o__userid"))
			$this->_userid->setOldValue($CurrentForm->getValue("o__userid"));

		// Check field name 'issueddate' first before field var 'x_issueddate'
		$val = $CurrentForm->hasValue("issueddate") ? $CurrentForm->getValue("issueddate") : $CurrentForm->getValue("x_issueddate");
		if (!$this->issueddate->IsDetailKey) {
			if (IsApi() && $val === NULL)
				$this->issueddate->Visible = FALSE; // Disable update for API request
			else
				$this->issueddate->setFormValue($val);
			$this->issueddate->CurrentValue = UnFormatDateTime($this->issueddate->CurrentValue, 1);
		}
		if ($CurrentForm->hasValue("o_issueddate"))
			$this->issueddate->setOldValue($CurrentForm->getValue("o_issueddate"));

		// Check field name 'currcode' first before field var 'x_currcode'
		$val = $CurrentForm->hasValue("currcode") ? $CurrentForm->getValue("currcode") : $CurrentForm->getValue("x_currcode");
		if (!$this->currcode->IsDetailKey) {
			if (IsApi() && $val === NULL)
				$this->currcode->Visible = FALSE; // Disable update for API request
			else
				$this->currcode->setFormValue($val);
		}
		if ($CurrentForm->hasValue("o_currcode"))
			$this->currcode->setOldValue($CurrentForm->getValue("o_currcode"));

		// Check field name 'fullypaidind' first before field var 'x_fullypaidind'
		$val = $CurrentForm->hasValue("fullypaidind") ? $CurrentForm->getValue("fullypaidind") : $CurrentForm->getValue("x_fullypaidind");
		if (!$this->fullypaidind->IsDetailKey) {
			if (IsApi() && $val === NULL)
				$this->fullypaidind->Visible = FALSE; // Disable update for API request
			else
				$this->fullypaidind->setFormValue($val);
		}
		if ($CurrentForm->hasValue("o_fullypaidind"))
			$this->fullypaidind->setOldValue($CurrentForm->getValue("o_fullypaidind"));

		// Check field name 'loanconfirmed' first before field var 'x_loanconfirmed'
		$val = $CurrentForm->hasValue("loanconfirmed") ? $CurrentForm->getValue("loanconfirmed") : $CurrentForm->getValue("x_loanconfirmed");
		if (!$this->loanconfirmed->IsDetailKey) {
			if (IsApi() && $val === NULL)
				$this->loanconfirmed->Visible = FALSE; // Disable update for API request
			else
				$this->loanconfirmed->setFormValue($val);
		}
		if ($CurrentForm->hasValue("o_loanconfirmed"))
			$this->loanconfirmed->setOldValue($CurrentForm->getValue("o_loanconfirmed"));

		// Check field name 'termtype' first before field var 'x_termtype'
		$val = $CurrentForm->hasValue("termtype") ? $CurrentForm->getValue("termtype") : $CurrentForm->getValue("x_termtype");
		if (!$this->termtype->IsDetailKey) {
			if (IsApi() && $val === NULL)
				$this->termtype->Visible = FALSE; // Disable update for API request
			else
				$this->termtype->setFormValue($val);
		}
		if ($CurrentForm->hasValue("o_termtype"))
			$this->termtype->setOldValue($CurrentForm->getValue("o_termtype"));
	}

	// Restore form values
	public function restoreFormValues()
	{
		global $CurrentForm;
		if (!$this->isGridAdd() && !$this->isAdd())
			$this->loanid->CurrentValue = $this->loanid->FormValue;
		$this->_userid->CurrentValue = $this->_userid->FormValue;
		$this->issueddate->CurrentValue = $this->issueddate->FormValue;
		$this->issueddate->CurrentValue = UnFormatDateTime($this->issueddate->CurrentValue, 1);
		$this->currcode->CurrentValue = $this->currcode->FormValue;
		$this->fullypaidind->CurrentValue = $this->fullypaidind->FormValue;
		$this->loanconfirmed->CurrentValue = $this->loanconfirmed->FormValue;
		$this->termtype->CurrentValue = $this->termtype->FormValue;
	}

	// Load recordset
	public function loadRecordset($offset = -1, $rowcnt = -1)
	{

		// Load List page SQL
		$sql = $this->getListSql();
		$conn = $this->getConnection();

		// Load recordset
		$dbtype = GetConnectionType($this->Dbid);
		if ($this->UseSelectLimit) {
			$conn->raiseErrorFn = Config("ERROR_FUNC");
			if ($dbtype == "MSSQL") {
				$rs = $conn->selectLimit($sql, $rowcnt, $offset, ["_hasOrderBy" => trim($this->getOrderBy()) || trim($this->getSessionOrderBy())]);
			} else {
				$rs = $conn->selectLimit($sql, $rowcnt, $offset);
			}
			$conn->raiseErrorFn = "";
		} else {
			$rs = LoadRecordset($sql, $conn);
		}

		// Call Recordset Selected event
		$this->Recordset_Selected($rs);
		return $rs;
	}

	// Load row based on key values
	public function loadRow()
	{
		global $Security, $Language;
		$filter = $this->getRecordFilter();

		// Call Row Selecting event
		$this->Row_Selecting($filter);

		// Load SQL based on filter
		$this->CurrentFilter = $filter;
		$sql = $this->getCurrentSql();
		$conn = $this->getConnection();
		$res = FALSE;
		$rs = LoadRecordset($sql, $conn);
		if ($rs && !$rs->EOF) {
			$res = TRUE;
			$this->loadRowValues($rs); // Load row values
			$rs->close();
		}
		return $res;
	}

	// Load row values from recordset
	public function loadRowValues($rs = NULL)
	{
		if ($rs && !$rs->EOF)
			$row = $rs->fields;
		else
			$row = $this->newRow();

		// Call Row Selected event
		$this->Row_Selected($row);
		if (!$rs || $rs->EOF)
			return;
		$this->loanid->setDbValue($row['loanid']);
		$this->_userid->setDbValue($row['userid']);
		$this->issueddate->setDbValue($row['issueddate']);
		$this->currcode->setDbValue($row['currcode']);
		$this->issuedamount->setDbValue($row['issuedamount']);
		$this->externalrefno->setDbValue($row['externalrefno']);
		$this->fullypaidind->setDbValue($row['fullypaidind']);
		$this->bankcode->setDbValue($row['bankcode']);
		$this->feeperc->setDbValue($row['feeperc']);
		$this->feeamount->setDbValue($row['feeamount']);
		$this->taxperc->setDbValue($row['taxperc']);
		$this->taxamount->setDbValue($row['taxamount']);
		$this->totalamount->setDbValue($row['totalamount']);
		$this->paymenttargetdate->setDbValue($row['paymenttargetdate']);
		$this->feefixed->setDbValue($row['feefixed']);
		$this->totalfees->setDbValue($row['totalfees']);
		$this->approveruserid->setDbValue($row['approveruserid']);
		$this->docid->setDbValue($row['docid']);
		$this->feesystemtotal->setDbValue($row['feesystemtotal']);
		$this->feeexternaltotal->setDbValue($row['feeexternaltotal']);
		$this->feefranchiseetotal->setDbValue($row['feefranchiseetotal']);
		$this->feeresellertotal->setDbValue($row['feeresellertotal']);
		$this->purchasefeeid->setDbValue($row['purchasefeeid']);
		$this->cancellationrefid->setDbValue($row['cancellationrefid']);
		$this->cancellationdatetime->setDbValue($row['cancellationdatetime']);
		$this->cancellationreason->setDbValue($row['cancellationreason']);
		$this->lastupdatedate->setDbValue($row['lastupdatedate']);
		$this->feeexternaltotaltime->setDbValue($row['feeexternaltotaltime']);
		$this->totalamountapplied->setDbValue($row['totalamountapplied']);
		$this->totalfeesapplied->setDbValue($row['totalfeesapplied']);
		$this->totalprincipleandfees->setDbValue($row['totalprincipleandfees']);
		$this->taxamountbreakdown->setDbValue($row['taxamountbreakdown']);
		$this->feesystembreakdown->setDbValue($row['feesystembreakdown']);
		$this->feeexternalbreakdown->setDbValue($row['feeexternalbreakdown']);
		$this->feefranchiseebreakdown->setDbValue($row['feefranchiseebreakdown']);
		$this->feeresellerbreakdown->setDbValue($row['feeresellerbreakdown']);
		$this->outstandingprinciple->setDbValue($row['outstandingprinciple']);
		$this->outstandingfees->setDbValue($row['outstandingfees']);
		$this->outstandingprincipleandfees->setDbValue($row['outstandingprincipleandfees']);
		$this->lastupdate->setDbValue($row['lastupdate']);
		$this->externalprovisioningrefno->setDbValue($row['externalprovisioningrefno']);
		$this->loantype->setDbValue($row['loantype']);
		$this->numberofoutstandingdays->setDbValue($row['numberofoutstandingdays']);
		$this->loandue->setDbValue($row['loandue']);
		$this->loanduedate->setDbValue($row['loanduedate']);
		$this->outstandinglatefees->setDbValue($row['outstandinglatefees']);
		$this->disbursementtype->setDbValue($row['disbursementtype']);
		$this->disbursementamount->setDbValue($row['disbursementamount']);
		$this->loanconfirmed->setDbValue($row['loanconfirmed']);
		$this->loanconfirmedtime->setDbValue($row['loanconfirmedtime']);
		$this->loanupgraded->setDbValue($row['loanupgraded']);
		$this->stoplatefee->setDbValue($row['stoplatefee']);
		$this->otherdetails1->setDbValue($row['otherdetails1']);
		$this->lockflag->setDbValue($row['lockflag']);
		$this->lastlatefeecalculatedate->setDbValue($row['lastlatefeecalculatedate']);
		$this->notificationlockflag->setDbValue($row['notificationlockflag']);
		$this->lastnotificationdate->setDbValue($row['lastnotificationdate']);
		$this->sendnotificationtextdate->setDbValue($row['sendnotificationtextdate']);
		$this->termtype->setDbValue($row['termtype']);
	}

	// Return a row with default values
	protected function newRow()
	{
		$this->loadDefaultValues();
		$row = [];
		$row['loanid'] = $this->loanid->CurrentValue;
		$row['userid'] = $this->_userid->CurrentValue;
		$row['issueddate'] = $this->issueddate->CurrentValue;
		$row['currcode'] = $this->currcode->CurrentValue;
		$row['issuedamount'] = $this->issuedamount->CurrentValue;
		$row['externalrefno'] = $this->externalrefno->CurrentValue;
		$row['fullypaidind'] = $this->fullypaidind->CurrentValue;
		$row['bankcode'] = $this->bankcode->CurrentValue;
		$row['feeperc'] = $this->feeperc->CurrentValue;
		$row['feeamount'] = $this->feeamount->CurrentValue;
		$row['taxperc'] = $this->taxperc->CurrentValue;
		$row['taxamount'] = $this->taxamount->CurrentValue;
		$row['totalamount'] = $this->totalamount->CurrentValue;
		$row['paymenttargetdate'] = $this->paymenttargetdate->CurrentValue;
		$row['feefixed'] = $this->feefixed->CurrentValue;
		$row['totalfees'] = $this->totalfees->CurrentValue;
		$row['approveruserid'] = $this->approveruserid->CurrentValue;
		$row['docid'] = $this->docid->CurrentValue;
		$row['feesystemtotal'] = $this->feesystemtotal->CurrentValue;
		$row['feeexternaltotal'] = $this->feeexternaltotal->CurrentValue;
		$row['feefranchiseetotal'] = $this->feefranchiseetotal->CurrentValue;
		$row['feeresellertotal'] = $this->feeresellertotal->CurrentValue;
		$row['purchasefeeid'] = $this->purchasefeeid->CurrentValue;
		$row['cancellationrefid'] = $this->cancellationrefid->CurrentValue;
		$row['cancellationdatetime'] = $this->cancellationdatetime->CurrentValue;
		$row['cancellationreason'] = $this->cancellationreason->CurrentValue;
		$row['lastupdatedate'] = $this->lastupdatedate->CurrentValue;
		$row['feeexternaltotaltime'] = $this->feeexternaltotaltime->CurrentValue;
		$row['totalamountapplied'] = $this->totalamountapplied->CurrentValue;
		$row['totalfeesapplied'] = $this->totalfeesapplied->CurrentValue;
		$row['totalprincipleandfees'] = $this->totalprincipleandfees->CurrentValue;
		$row['taxamountbreakdown'] = $this->taxamountbreakdown->CurrentValue;
		$row['feesystembreakdown'] = $this->feesystembreakdown->CurrentValue;
		$row['feeexternalbreakdown'] = $this->feeexternalbreakdown->CurrentValue;
		$row['feefranchiseebreakdown'] = $this->feefranchiseebreakdown->CurrentValue;
		$row['feeresellerbreakdown'] = $this->feeresellerbreakdown->CurrentValue;
		$row['outstandingprinciple'] = $this->outstandingprinciple->CurrentValue;
		$row['outstandingfees'] = $this->outstandingfees->CurrentValue;
		$row['outstandingprincipleandfees'] = $this->outstandingprincipleandfees->CurrentValue;
		$row['lastupdate'] = $this->lastupdate->CurrentValue;
		$row['externalprovisioningrefno'] = $this->externalprovisioningrefno->CurrentValue;
		$row['loantype'] = $this->loantype->CurrentValue;
		$row['numberofoutstandingdays'] = $this->numberofoutstandingdays->CurrentValue;
		$row['loandue'] = $this->loandue->CurrentValue;
		$row['loanduedate'] = $this->loanduedate->CurrentValue;
		$row['outstandinglatefees'] = $this->outstandinglatefees->CurrentValue;
		$row['disbursementtype'] = $this->disbursementtype->CurrentValue;
		$row['disbursementamount'] = $this->disbursementamount->CurrentValue;
		$row['loanconfirmed'] = $this->loanconfirmed->CurrentValue;
		$row['loanconfirmedtime'] = $this->loanconfirmedtime->CurrentValue;
		$row['loanupgraded'] = $this->loanupgraded->CurrentValue;
		$row['stoplatefee'] = $this->stoplatefee->CurrentValue;
		$row['otherdetails1'] = $this->otherdetails1->CurrentValue;
		$row['lockflag'] = $this->lockflag->CurrentValue;
		$row['lastlatefeecalculatedate'] = $this->lastlatefeecalculatedate->CurrentValue;
		$row['notificationlockflag'] = $this->notificationlockflag->CurrentValue;
		$row['lastnotificationdate'] = $this->lastnotificationdate->CurrentValue;
		$row['sendnotificationtextdate'] = $this->sendnotificationtextdate->CurrentValue;
		$row['termtype'] = $this->termtype->CurrentValue;
		return $row;
	}

	// Load old record
	protected function loadOldRecord()
	{

		// Load key values from Session
		$validKey = TRUE;
		$keys = [$this->RowOldKey];
		$cnt = count($keys);
		if ($cnt >= 1) {
			if (strval($keys[0]) != "")
				$this->loanid->OldValue = strval($keys[0]); // loanid
			else
				$validKey = FALSE;
		} else {
			$validKey = FALSE;
		}

		// Load old record
		$this->OldRecordset = NULL;
		if ($validKey) {
			$this->CurrentFilter = $this->getRecordFilter();
			$sql = $this->getCurrentSql();
			$conn = $this->getConnection();
			$this->OldRecordset = LoadRecordset($sql, $conn);
		}
		$this->loadRowValues($this->OldRecordset); // Load row values
		return $validKey;
	}

	// Render row values based on field settings
	public function renderRow()
	{
		global $Security, $Language, $CurrentLanguage;

		// Initialize URLs
		$this->ViewUrl = $this->getViewUrl();
		$this->EditUrl = $this->getEditUrl();
		$this->CopyUrl = $this->getCopyUrl();
		$this->DeleteUrl = $this->getDeleteUrl();

		// Call Row_Rendering event
		$this->Row_Rendering();

		// Common render codes for all row types
		// loanid
		// userid
		// issueddate
		// currcode
		// issuedamount
		// externalrefno
		// fullypaidind
		// bankcode
		// feeperc
		// feeamount
		// taxperc
		// taxamount
		// totalamount
		// paymenttargetdate
		// feefixed
		// totalfees
		// approveruserid
		// docid
		// feesystemtotal
		// feeexternaltotal
		// feefranchiseetotal
		// feeresellertotal
		// purchasefeeid
		// cancellationrefid
		// cancellationdatetime
		// cancellationreason
		// lastupdatedate
		// feeexternaltotaltime
		// totalamountapplied
		// totalfeesapplied
		// totalprincipleandfees
		// taxamountbreakdown
		// feesystembreakdown
		// feeexternalbreakdown
		// feefranchiseebreakdown
		// feeresellerbreakdown
		// outstandingprinciple
		// outstandingfees
		// outstandingprincipleandfees
		// lastupdate
		// externalprovisioningrefno
		// loantype
		// numberofoutstandingdays
		// loandue
		// loanduedate
		// outstandinglatefees
		// disbursementtype

		$this->disbursementtype->CellCssStyle = "white-space: nowrap;";

		// disbursementamount
		$this->disbursementamount->CellCssStyle = "white-space: nowrap;";

		// loanconfirmed
		// loanconfirmedtime
		// loanupgraded
		// stoplatefee
		// otherdetails1
		// lockflag
		// lastlatefeecalculatedate
		// notificationlockflag
		// lastnotificationdate
		// sendnotificationtextdate
		// termtype

		if ($this->RowType == ROWTYPE_VIEW) { // View row

			// loanid
			$this->loanid->ViewValue = $this->loanid->CurrentValue;
			$this->loanid->ViewCustomAttributes = "";

			// userid
			$this->_userid->ViewValue = $this->_userid->CurrentValue;
			$this->_userid->ViewCustomAttributes = "";

			// issueddate
			$this->issueddate->ViewValue = $this->issueddate->CurrentValue;
			$this->issueddate->ViewValue = FormatDateTime($this->issueddate->ViewValue, 1);
			$this->issueddate->ViewCustomAttributes = "";

			// currcode
			$curVal = strval($this->currcode->CurrentValue);
			if ($curVal != "") {
				$this->currcode->ViewValue = $this->currcode->lookupCacheOption($curVal);
				if ($this->currcode->ViewValue === NULL) { // Lookup from database
					$filterWrk = "`currCode`" . SearchString("=", $curVal, DATATYPE_STRING, "_4payreference");
					$lookupFilter = function() {
						return "`langID`='EN'";
					};
					$lookupFilter = $lookupFilter->bindTo($this);
					$sqlWrk = $this->currcode->Lookup->getSql(FALSE, $filterWrk, $lookupFilter, $this);
					$rswrk = Conn("_4payreference")->execute($sqlWrk);
					if ($rswrk && !$rswrk->EOF) { // Lookup values found
						$arwrk = [];
						$arwrk[1] = $rswrk->fields('df');
						$arwrk[2] = $rswrk->fields('df2');
						$this->currcode->ViewValue = $this->currcode->displayValue($arwrk);
						$rswrk->Close();
					} else {
						$this->currcode->ViewValue = $this->currcode->CurrentValue;
					}
				}
			} else {
				$this->currcode->ViewValue = NULL;
			}
			$this->currcode->ViewCustomAttributes = "";

			// issuedamount
			$this->issuedamount->ViewValue = $this->issuedamount->CurrentValue;
			$this->issuedamount->ViewValue = FormatNumber($this->issuedamount->ViewValue, 2, -2, -2, -2);
			$this->issuedamount->ViewCustomAttributes = "";

			// externalrefno
			$this->externalrefno->ViewValue = $this->externalrefno->CurrentValue;
			$this->externalrefno->ViewCustomAttributes = "";

			// fullypaidind
			if (strval($this->fullypaidind->CurrentValue) != "") {
				$this->fullypaidind->ViewValue = $this->fullypaidind->optionCaption($this->fullypaidind->CurrentValue);
			} else {
				$this->fullypaidind->ViewValue = NULL;
			}
			$this->fullypaidind->ViewCustomAttributes = "";

			// bankcode
			$this->bankcode->ViewValue = $this->bankcode->CurrentValue;
			$this->bankcode->ViewCustomAttributes = "";

			// feeperc
			$this->feeperc->ViewValue = $this->feeperc->CurrentValue;
			$this->feeperc->ViewValue = FormatNumber($this->feeperc->ViewValue, 2, -2, -2, -2);
			$this->feeperc->ViewCustomAttributes = "";

			// feeamount
			$this->feeamount->ViewValue = $this->feeamount->CurrentValue;
			$this->feeamount->ViewValue = FormatNumber($this->feeamount->ViewValue, 2, -2, -2, -2);
			$this->feeamount->ViewCustomAttributes = "";

			// taxperc
			$this->taxperc->ViewValue = $this->taxperc->CurrentValue;
			$this->taxperc->ViewValue = FormatNumber($this->taxperc->ViewValue, 2, -2, -2, -2);
			$this->taxperc->ViewCustomAttributes = "";

			// taxamount
			$this->taxamount->ViewValue = $this->taxamount->CurrentValue;
			$this->taxamount->ViewValue = FormatNumber($this->taxamount->ViewValue, 2, -2, -2, -2);
			$this->taxamount->ViewCustomAttributes = "";

			// totalamount
			$this->totalamount->ViewValue = $this->totalamount->CurrentValue;
			$this->totalamount->ViewValue = FormatNumber($this->totalamount->ViewValue, 2, -2, -2, -2);
			$this->totalamount->ViewCustomAttributes = "";

			// paymenttargetdate
			$this->paymenttargetdate->ViewValue = $this->paymenttargetdate->CurrentValue;
			$this->paymenttargetdate->ViewValue = FormatDateTime($this->paymenttargetdate->ViewValue, 0);
			$this->paymenttargetdate->ViewCustomAttributes = "";

			// feefixed
			$this->feefixed->ViewValue = $this->feefixed->CurrentValue;
			$this->feefixed->ViewValue = FormatNumber($this->feefixed->ViewValue, Config("DEFAULT_DECIMAL_PRECISION"));
			$this->feefixed->ViewCustomAttributes = "";

			// totalfees
			$this->totalfees->ViewValue = $this->totalfees->CurrentValue;
			$this->totalfees->ViewValue = FormatNumber($this->totalfees->ViewValue, Config("DEFAULT_DECIMAL_PRECISION"));
			$this->totalfees->ViewCustomAttributes = "";

			// approveruserid
			$this->approveruserid->ViewValue = $this->approveruserid->CurrentValue;
			$this->approveruserid->ViewCustomAttributes = "";

			// docid
			$this->docid->ViewValue = $this->docid->CurrentValue;
			$this->docid->ViewCustomAttributes = "";

			// feesystemtotal
			$this->feesystemtotal->ViewValue = $this->feesystemtotal->CurrentValue;
			$this->feesystemtotal->ViewValue = FormatNumber($this->feesystemtotal->ViewValue, Config("DEFAULT_DECIMAL_PRECISION"));
			$this->feesystemtotal->ViewCustomAttributes = "";

			// feeexternaltotal
			$this->feeexternaltotal->ViewValue = $this->feeexternaltotal->CurrentValue;
			$this->feeexternaltotal->ViewValue = FormatNumber($this->feeexternaltotal->ViewValue, Config("DEFAULT_DECIMAL_PRECISION"));
			$this->feeexternaltotal->ViewCustomAttributes = "";

			// feefranchiseetotal
			$this->feefranchiseetotal->ViewValue = $this->feefranchiseetotal->CurrentValue;
			$this->feefranchiseetotal->ViewValue = FormatNumber($this->feefranchiseetotal->ViewValue, Config("DEFAULT_DECIMAL_PRECISION"));
			$this->feefranchiseetotal->ViewCustomAttributes = "";

			// feeresellertotal
			$this->feeresellertotal->ViewValue = $this->feeresellertotal->CurrentValue;
			$this->feeresellertotal->ViewValue = FormatNumber($this->feeresellertotal->ViewValue, Config("DEFAULT_DECIMAL_PRECISION"));
			$this->feeresellertotal->ViewCustomAttributes = "";

			// purchasefeeid
			$this->purchasefeeid->ViewValue = $this->purchasefeeid->CurrentValue;
			$this->purchasefeeid->ViewCustomAttributes = "";

			// cancellationrefid
			$this->cancellationrefid->ViewValue = $this->cancellationrefid->CurrentValue;
			$this->cancellationrefid->ViewCustomAttributes = "";

			// cancellationdatetime
			$this->cancellationdatetime->ViewValue = $this->cancellationdatetime->CurrentValue;
			$this->cancellationdatetime->ViewValue = FormatDateTime($this->cancellationdatetime->ViewValue, 0);
			$this->cancellationdatetime->ViewCustomAttributes = "";

			// cancellationreason
			$this->cancellationreason->ViewValue = $this->cancellationreason->CurrentValue;
			$this->cancellationreason->ViewCustomAttributes = "";

			// lastupdatedate
			$this->lastupdatedate->ViewValue = $this->lastupdatedate->CurrentValue;
			$this->lastupdatedate->ViewValue = FormatDateTime($this->lastupdatedate->ViewValue, 0);
			$this->lastupdatedate->ViewCustomAttributes = "";

			// feeexternaltotaltime
			$this->feeexternaltotaltime->ViewValue = $this->feeexternaltotaltime->CurrentValue;
			$this->feeexternaltotaltime->ViewValue = FormatNumber($this->feeexternaltotaltime->ViewValue, 2, -2, -2, -2);
			$this->feeexternaltotaltime->ViewCustomAttributes = "";

			// totalamountapplied
			$this->totalamountapplied->ViewValue = $this->totalamountapplied->CurrentValue;
			$this->totalamountapplied->ViewValue = FormatNumber($this->totalamountapplied->ViewValue, 2, -2, -2, -2);
			$this->totalamountapplied->ViewCustomAttributes = "";

			// totalfeesapplied
			$this->totalfeesapplied->ViewValue = $this->totalfeesapplied->CurrentValue;
			$this->totalfeesapplied->ViewValue = FormatNumber($this->totalfeesapplied->ViewValue, 2, -2, -2, -2);
			$this->totalfeesapplied->ViewCustomAttributes = "";

			// totalprincipleandfees
			$this->totalprincipleandfees->ViewValue = $this->totalprincipleandfees->CurrentValue;
			$this->totalprincipleandfees->ViewValue = FormatNumber($this->totalprincipleandfees->ViewValue, 2, -2, -2, -2);
			$this->totalprincipleandfees->ViewCustomAttributes = "";

			// taxamountbreakdown
			$this->taxamountbreakdown->ViewValue = $this->taxamountbreakdown->CurrentValue;
			$this->taxamountbreakdown->ViewValue = FormatNumber($this->taxamountbreakdown->ViewValue, 2, -2, -2, -2);
			$this->taxamountbreakdown->ViewCustomAttributes = "";

			// feesystembreakdown
			$this->feesystembreakdown->ViewValue = $this->feesystembreakdown->CurrentValue;
			$this->feesystembreakdown->ViewValue = FormatNumber($this->feesystembreakdown->ViewValue, 2, -2, -2, -2);
			$this->feesystembreakdown->ViewCustomAttributes = "";

			// feeexternalbreakdown
			$this->feeexternalbreakdown->ViewValue = $this->feeexternalbreakdown->CurrentValue;
			$this->feeexternalbreakdown->ViewValue = FormatNumber($this->feeexternalbreakdown->ViewValue, 2, -2, -2, -2);
			$this->feeexternalbreakdown->ViewCustomAttributes = "";

			// feefranchiseebreakdown
			$this->feefranchiseebreakdown->ViewValue = $this->feefranchiseebreakdown->CurrentValue;
			$this->feefranchiseebreakdown->ViewValue = FormatNumber($this->feefranchiseebreakdown->ViewValue, 2, -2, -2, -2);
			$this->feefranchiseebreakdown->ViewCustomAttributes = "";

			// feeresellerbreakdown
			$this->feeresellerbreakdown->ViewValue = $this->feeresellerbreakdown->CurrentValue;
			$this->feeresellerbreakdown->ViewValue = FormatNumber($this->feeresellerbreakdown->ViewValue, 2, -2, -2, -2);
			$this->feeresellerbreakdown->ViewCustomAttributes = "";

			// outstandingprinciple
			$this->outstandingprinciple->ViewValue = $this->outstandingprinciple->CurrentValue;
			$this->outstandingprinciple->ViewValue = FormatNumber($this->outstandingprinciple->ViewValue, 2, -2, -2, -2);
			$this->outstandingprinciple->ViewCustomAttributes = "";

			// outstandingfees
			$this->outstandingfees->ViewValue = $this->outstandingfees->CurrentValue;
			$this->outstandingfees->ViewValue = FormatNumber($this->outstandingfees->ViewValue, 2, -2, -2, -2);
			$this->outstandingfees->ViewCustomAttributes = "";

			// outstandingprincipleandfees
			$this->outstandingprincipleandfees->ViewValue = $this->outstandingprincipleandfees->CurrentValue;
			$this->outstandingprincipleandfees->ViewValue = FormatNumber($this->outstandingprincipleandfees->ViewValue, 2, -2, -2, -2);
			$this->outstandingprincipleandfees->ViewCustomAttributes = "";

			// lastupdate
			$this->lastupdate->ViewValue = $this->lastupdate->CurrentValue;
			$this->lastupdate->ViewValue = FormatDateTime($this->lastupdate->ViewValue, 0);
			$this->lastupdate->ViewCustomAttributes = "";

			// externalprovisioningrefno
			$this->externalprovisioningrefno->ViewValue = $this->externalprovisioningrefno->CurrentValue;
			$this->externalprovisioningrefno->ViewCustomAttributes = "";

			// loantype
			$curVal = strval($this->loantype->CurrentValue);
			if ($curVal != "") {
				$this->loantype->ViewValue = $this->loantype->lookupCacheOption($curVal);
				if ($this->loantype->ViewValue === NULL) { // Lookup from database
					$filterWrk = "`loantype`" . SearchString("=", $curVal, DATATYPE_NUMBER, "_4payreference");
					$sqlWrk = $this->loantype->Lookup->getSql(FALSE, $filterWrk, '', $this);
					$rswrk = Conn("_4payreference")->execute($sqlWrk);
					if ($rswrk && !$rswrk->EOF) { // Lookup values found
						$arwrk = [];
						$arwrk[1] = FormatNumber($rswrk->fields('df'), 0, -2, -2, -2);
						$arwrk[2] = $rswrk->fields('df2');
						$this->loantype->ViewValue = $this->loantype->displayValue($arwrk);
						$rswrk->Close();
					} else {
						$this->loantype->ViewValue = $this->loantype->CurrentValue;
					}
				}
			} else {
				$this->loantype->ViewValue = NULL;
			}
			$this->loantype->ViewCustomAttributes = "";

			// numberofoutstandingdays
			$this->numberofoutstandingdays->ViewValue = $this->numberofoutstandingdays->CurrentValue;
			$this->numberofoutstandingdays->ViewValue = FormatNumber($this->numberofoutstandingdays->ViewValue, 0, -2, -2, -2);
			$this->numberofoutstandingdays->ViewCustomAttributes = "";

			// loandue
			$curVal = strval($this->loandue->CurrentValue);
			if ($curVal != "") {
				$this->loandue->ViewValue = $this->loandue->lookupCacheOption($curVal);
				if ($this->loandue->ViewValue === NULL) { // Lookup from database
					$filterWrk = "`id`" . SearchString("=", $curVal, DATATYPE_NUMBER, "");
					$sqlWrk = $this->loandue->Lookup->getSql(FALSE, $filterWrk, '', $this);
					$rswrk = Conn()->execute($sqlWrk);
					if ($rswrk && !$rswrk->EOF) { // Lookup values found
						$arwrk = [];
						$arwrk[1] = $rswrk->fields('df');
						$this->loandue->ViewValue = $this->loandue->displayValue($arwrk);
						$rswrk->Close();
					} else {
						$this->loandue->ViewValue = $this->loandue->CurrentValue;
					}
				}
			} else {
				$this->loandue->ViewValue = NULL;
			}
			$this->loandue->ViewCustomAttributes = "";

			// loanduedate
			$this->loanduedate->ViewValue = $this->loanduedate->CurrentValue;
			$this->loanduedate->ViewValue = FormatDateTime($this->loanduedate->ViewValue, 0);
			$this->loanduedate->ViewCustomAttributes = "";

			// outstandinglatefees
			$this->outstandinglatefees->ViewValue = $this->outstandinglatefees->CurrentValue;
			$this->outstandinglatefees->ViewValue = FormatNumber($this->outstandinglatefees->ViewValue, 2, -2, -2, -2);
			$this->outstandinglatefees->ViewCustomAttributes = "";

			// disbursementtype
			if (strval($this->disbursementtype->CurrentValue) != "") {
				$this->disbursementtype->ViewValue = $this->disbursementtype->optionCaption($this->disbursementtype->CurrentValue);
			} else {
				$this->disbursementtype->ViewValue = NULL;
			}
			$this->disbursementtype->ViewCustomAttributes = "";

			// disbursementamount
			$this->disbursementamount->ViewValue = $this->disbursementamount->CurrentValue;
			$this->disbursementamount->ViewValue = FormatNumber($this->disbursementamount->ViewValue, 2, -2, -2, -2);
			$this->disbursementamount->ViewCustomAttributes = "";

			// loanconfirmed
			$curVal = strval($this->loanconfirmed->CurrentValue);
			if ($curVal != "") {
				$this->loanconfirmed->ViewValue = $this->loanconfirmed->lookupCacheOption($curVal);
				if ($this->loanconfirmed->ViewValue === NULL) { // Lookup from database
					$filterWrk = "`id`" . SearchString("=", $curVal, DATATYPE_NUMBER, "");
					$sqlWrk = $this->loanconfirmed->Lookup->getSql(FALSE, $filterWrk, '', $this);
					$rswrk = Conn()->execute($sqlWrk);
					if ($rswrk && !$rswrk->EOF) { // Lookup values found
						$arwrk = [];
						$arwrk[1] = $rswrk->fields('df');
						$this->loanconfirmed->ViewValue = $this->loanconfirmed->displayValue($arwrk);
						$rswrk->Close();
					} else {
						$this->loanconfirmed->ViewValue = $this->loanconfirmed->CurrentValue;
					}
				}
			} else {
				$this->loanconfirmed->ViewValue = NULL;
			}
			$this->loanconfirmed->ViewCustomAttributes = "";

			// loanconfirmedtime
			$this->loanconfirmedtime->ViewValue = $this->loanconfirmedtime->CurrentValue;
			$this->loanconfirmedtime->ViewValue = FormatDateTime($this->loanconfirmedtime->ViewValue, 0);
			$this->loanconfirmedtime->ViewCustomAttributes = "";

			// loanupgraded
			$curVal = strval($this->loanupgraded->CurrentValue);
			if ($curVal != "") {
				$this->loanupgraded->ViewValue = $this->loanupgraded->lookupCacheOption($curVal);
				if ($this->loanupgraded->ViewValue === NULL) { // Lookup from database
					$filterWrk = "`statusID`" . SearchString("=", $curVal, DATATYPE_NUMBER, "");
					$lookupFilter = function() {
						return "`langID` = 'EN'";
					};
					$lookupFilter = $lookupFilter->bindTo($this);
					$sqlWrk = $this->loanupgraded->Lookup->getSql(FALSE, $filterWrk, $lookupFilter, $this);
					$rswrk = Conn()->execute($sqlWrk);
					if ($rswrk && !$rswrk->EOF) { // Lookup values found
						$arwrk = [];
						$arwrk[1] = $rswrk->fields('df');
						$this->loanupgraded->ViewValue = $this->loanupgraded->displayValue($arwrk);
						$rswrk->Close();
					} else {
						$this->loanupgraded->ViewValue = $this->loanupgraded->CurrentValue;
					}
				}
			} else {
				$this->loanupgraded->ViewValue = NULL;
			}
			$this->loanupgraded->ViewCustomAttributes = "";

			// stoplatefee
			$curVal = strval($this->stoplatefee->CurrentValue);
			if ($curVal != "") {
				$this->stoplatefee->ViewValue = $this->stoplatefee->lookupCacheOption($curVal);
				if ($this->stoplatefee->ViewValue === NULL) { // Lookup from database
					$filterWrk = "`statusID`" . SearchString("=", $curVal, DATATYPE_NUMBER, "");
					$lookupFilter = function() {
						return "`langID` = 'EN'";
					};
					$lookupFilter = $lookupFilter->bindTo($this);
					$sqlWrk = $this->stoplatefee->Lookup->getSql(FALSE, $filterWrk, $lookupFilter, $this);
					$rswrk = Conn()->execute($sqlWrk);
					if ($rswrk && !$rswrk->EOF) { // Lookup values found
						$arwrk = [];
						$arwrk[1] = $rswrk->fields('df');
						$this->stoplatefee->ViewValue = $this->stoplatefee->displayValue($arwrk);
						$rswrk->Close();
					} else {
						$this->stoplatefee->ViewValue = $this->stoplatefee->CurrentValue;
					}
				}
			} else {
				$this->stoplatefee->ViewValue = NULL;
			}
			$this->stoplatefee->ViewCustomAttributes = "";

			// otherdetails1
			$this->otherdetails1->ViewValue = $this->otherdetails1->CurrentValue;
			$this->otherdetails1->ViewCustomAttributes = "";

			// lockflag
			if (strval($this->lockflag->CurrentValue) != "") {
				$this->lockflag->ViewValue = $this->lockflag->optionCaption($this->lockflag->CurrentValue);
			} else {
				$this->lockflag->ViewValue = NULL;
			}
			$this->lockflag->ViewCustomAttributes = "";

			// lastlatefeecalculatedate
			$this->lastlatefeecalculatedate->ViewValue = $this->lastlatefeecalculatedate->CurrentValue;
			$this->lastlatefeecalculatedate->ViewValue = FormatDateTime($this->lastlatefeecalculatedate->ViewValue, 0);
			$this->lastlatefeecalculatedate->ViewCustomAttributes = "";

			// notificationlockflag
			if (strval($this->notificationlockflag->CurrentValue) != "") {
				$this->notificationlockflag->ViewValue = $this->notificationlockflag->optionCaption($this->notificationlockflag->CurrentValue);
			} else {
				$this->notificationlockflag->ViewValue = NULL;
			}
			$this->notificationlockflag->ViewCustomAttributes = "";

			// lastnotificationdate
			$this->lastnotificationdate->ViewValue = $this->lastnotificationdate->CurrentValue;
			$this->lastnotificationdate->ViewValue = FormatDateTime($this->lastnotificationdate->ViewValue, 0);
			$this->lastnotificationdate->ViewCustomAttributes = "";

			// sendnotificationtextdate
			$this->sendnotificationtextdate->ViewValue = $this->sendnotificationtextdate->CurrentValue;
			$this->sendnotificationtextdate->ViewValue = FormatDateTime($this->sendnotificationtextdate->ViewValue, 0);
			$this->sendnotificationtextdate->ViewCustomAttributes = "";

			// termtype
			if (strval($this->termtype->CurrentValue) != "") {
				$this->termtype->ViewValue = $this->termtype->optionCaption($this->termtype->CurrentValue);
			} else {
				$this->termtype->ViewValue = NULL;
			}
			$this->termtype->ViewCustomAttributes = "";

			// loanid
			$this->loanid->LinkCustomAttributes = "";
			$this->loanid->HrefValue = "";
			$this->loanid->TooltipValue = "";
			if (!$this->isExport())
				$this->loanid->ViewValue = $this->highlightValue($this->loanid);

			// userid
			$this->_userid->LinkCustomAttributes = "";
			if (!EmptyValue($this->_userid->CurrentValue)) {
				$this->_userid->HrefValue = "loanlimitslist.php?showmaster=vuser&fk_id=" . $this->_userid->CurrentValue; // Add prefix/suffix
				$this->_userid->LinkAttrs["target"] = ""; // Add target
				if ($this->isExport())
					$this->_userid->HrefValue = FullUrl($this->_userid->HrefValue, "href");
			} else {
				$this->_userid->HrefValue = "";
			}
			$this->_userid->TooltipValue = "";
			if (!$this->isExport())
				$this->_userid->ViewValue = $this->highlightValue($this->_userid);

			// issueddate
			$this->issueddate->LinkCustomAttributes = "";
			$this->issueddate->HrefValue = "";
			$this->issueddate->TooltipValue = "";

			// currcode
			$this->currcode->LinkCustomAttributes = "";
			$this->currcode->HrefValue = "";
			$this->currcode->TooltipValue = "";

			// fullypaidind
			$this->fullypaidind->LinkCustomAttributes = "";
			$this->fullypaidind->HrefValue = "";
			$this->fullypaidind->TooltipValue = "";

			// loanconfirmed
			$this->loanconfirmed->LinkCustomAttributes = "";
			$this->loanconfirmed->HrefValue = "";
			$this->loanconfirmed->TooltipValue = "";

			// termtype
			$this->termtype->LinkCustomAttributes = "";
			$this->termtype->HrefValue = "";
			$this->termtype->TooltipValue = "";
		} elseif ($this->RowType == ROWTYPE_ADD) { // Add row

			// loanid
			// userid

			$this->_userid->EditAttrs["class"] = "form-control";
			$this->_userid->EditCustomAttributes = "";
			if ($this->_userid->getSessionValue() != "") {
				$this->_userid->CurrentValue = $this->_userid->getSessionValue();
				$this->_userid->OldValue = $this->_userid->CurrentValue;
				$this->_userid->ViewValue = $this->_userid->CurrentValue;
				$this->_userid->ViewCustomAttributes = "";
			} else {
				$this->_userid->EditValue = HtmlEncode($this->_userid->CurrentValue);
				$this->_userid->PlaceHolder = RemoveHtml($this->_userid->caption());
			}

			// issueddate
			$this->issueddate->EditAttrs["class"] = "form-control";
			$this->issueddate->EditCustomAttributes = "";
			$this->issueddate->EditValue = HtmlEncode(FormatDateTime($this->issueddate->CurrentValue, 8));
			$this->issueddate->PlaceHolder = RemoveHtml($this->issueddate->caption());

			// currcode
			$this->currcode->EditAttrs["class"] = "form-control";
			$this->currcode->EditCustomAttributes = "";
			if ($this->currcode->getSessionValue() != "") {
				$this->currcode->CurrentValue = $this->currcode->getSessionValue();
				$this->currcode->OldValue = $this->currcode->CurrentValue;
				$curVal = strval($this->currcode->CurrentValue);
				if ($curVal != "") {
					$this->currcode->ViewValue = $this->currcode->lookupCacheOption($curVal);
					if ($this->currcode->ViewValue === NULL) { // Lookup from database
						$filterWrk = "`currCode`" . SearchString("=", $curVal, DATATYPE_STRING, "_4payreference");
						$lookupFilter = function() {
							return "`langID`='EN'";
						};
						$lookupFilter = $lookupFilter->bindTo($this);
						$sqlWrk = $this->currcode->Lookup->getSql(FALSE, $filterWrk, $lookupFilter, $this);
						$rswrk = Conn("_4payreference")->execute($sqlWrk);
						if ($rswrk && !$rswrk->EOF) { // Lookup values found
							$arwrk = [];
							$arwrk[1] = $rswrk->fields('df');
							$arwrk[2] = $rswrk->fields('df2');
							$this->currcode->ViewValue = $this->currcode->displayValue($arwrk);
							$rswrk->Close();
						} else {
							$this->currcode->ViewValue = $this->currcode->CurrentValue;
						}
					}
				} else {
					$this->currcode->ViewValue = NULL;
				}
				$this->currcode->ViewCustomAttributes = "";
			} else {
				$curVal = trim(strval($this->currcode->CurrentValue));
				if ($curVal != "")
					$this->currcode->ViewValue = $this->currcode->lookupCacheOption($curVal);
				else
					$this->currcode->ViewValue = $this->currcode->Lookup !== NULL && is_array($this->currcode->Lookup->Options) ? $curVal : NULL;
				if ($this->currcode->ViewValue !== NULL) { // Load from cache
					$this->currcode->EditValue = array_values($this->currcode->Lookup->Options);
				} else { // Lookup from database
					if ($curVal == "") {
						$filterWrk = "0=1";
					} else {
						$filterWrk = "`currCode`" . SearchString("=", $this->currcode->CurrentValue, DATATYPE_STRING, "_4payreference");
					}
					$lookupFilter = function() {
						return "`langID`='EN'";
					};
					$lookupFilter = $lookupFilter->bindTo($this);
					$sqlWrk = $this->currcode->Lookup->getSql(TRUE, $filterWrk, $lookupFilter, $this);
					$rswrk = Conn("_4payreference")->execute($sqlWrk);
					$arwrk = $rswrk ? $rswrk->getRows() : [];
					if ($rswrk)
						$rswrk->close();
					$this->currcode->EditValue = $arwrk;
				}
			}

			// fullypaidind
			$this->fullypaidind->EditAttrs["class"] = "form-control";
			$this->fullypaidind->EditCustomAttributes = "";
			$this->fullypaidind->EditValue = $this->fullypaidind->options(TRUE);

			// loanconfirmed
			$this->loanconfirmed->EditCustomAttributes = "";
			$curVal = trim(strval($this->loanconfirmed->CurrentValue));
			if ($curVal != "")
				$this->loanconfirmed->ViewValue = $this->loanconfirmed->lookupCacheOption($curVal);
			else
				$this->loanconfirmed->ViewValue = $this->loanconfirmed->Lookup !== NULL && is_array($this->loanconfirmed->Lookup->Options) ? $curVal : NULL;
			if ($this->loanconfirmed->ViewValue !== NULL) { // Load from cache
				$this->loanconfirmed->EditValue = array_values($this->loanconfirmed->Lookup->Options);
			} else { // Lookup from database
				if ($curVal == "") {
					$filterWrk = "0=1";
				} else {
					$filterWrk = "`id`" . SearchString("=", $this->loanconfirmed->CurrentValue, DATATYPE_NUMBER, "");
				}
				$sqlWrk = $this->loanconfirmed->Lookup->getSql(TRUE, $filterWrk, '', $this);
				$rswrk = Conn()->execute($sqlWrk);
				$arwrk = $rswrk ? $rswrk->getRows() : [];
				if ($rswrk)
					$rswrk->close();
				$this->loanconfirmed->EditValue = $arwrk;
			}

			// termtype
			$this->termtype->EditCustomAttributes = "";
			$this->termtype->EditValue = $this->termtype->options(FALSE);

			// Add refer script
			// loanid

			$this->loanid->LinkCustomAttributes = "";
			$this->loanid->HrefValue = "";

			// userid
			$this->_userid->LinkCustomAttributes = "";
			if (!EmptyValue($this->_userid->CurrentValue)) {
				$this->_userid->HrefValue = "loanlimitslist.php?showmaster=vuser&fk_id=" . $this->_userid->CurrentValue; // Add prefix/suffix
				$this->_userid->LinkAttrs["target"] = ""; // Add target
				if ($this->isExport())
					$this->_userid->HrefValue = FullUrl($this->_userid->HrefValue, "href");
			} else {
				$this->_userid->HrefValue = "";
			}

			// issueddate
			$this->issueddate->LinkCustomAttributes = "";
			$this->issueddate->HrefValue = "";

			// currcode
			$this->currcode->LinkCustomAttributes = "";
			$this->currcode->HrefValue = "";

			// fullypaidind
			$this->fullypaidind->LinkCustomAttributes = "";
			$this->fullypaidind->HrefValue = "";

			// loanconfirmed
			$this->loanconfirmed->LinkCustomAttributes = "";
			$this->loanconfirmed->HrefValue = "";

			// termtype
			$this->termtype->LinkCustomAttributes = "";
			$this->termtype->HrefValue = "";
		} elseif ($this->RowType == ROWTYPE_EDIT) { // Edit row

			// loanid
			$this->loanid->EditAttrs["class"] = "form-control";
			$this->loanid->EditCustomAttributes = "";
			$this->loanid->EditValue = $this->loanid->CurrentValue;
			$this->loanid->ViewCustomAttributes = "";

			// userid
			$this->_userid->EditAttrs["class"] = "form-control";
			$this->_userid->EditCustomAttributes = "";
			if ($this->_userid->getSessionValue() != "") {
				$this->_userid->CurrentValue = $this->_userid->getSessionValue();
				$this->_userid->OldValue = $this->_userid->CurrentValue;
				$this->_userid->ViewValue = $this->_userid->CurrentValue;
				$this->_userid->ViewCustomAttributes = "";
			} else {
				$this->_userid->EditValue = HtmlEncode($this->_userid->CurrentValue);
				$this->_userid->PlaceHolder = RemoveHtml($this->_userid->caption());
			}

			// issueddate
			$this->issueddate->EditAttrs["class"] = "form-control";
			$this->issueddate->EditCustomAttributes = "";
			$this->issueddate->EditValue = HtmlEncode(FormatDateTime($this->issueddate->CurrentValue, 8));
			$this->issueddate->PlaceHolder = RemoveHtml($this->issueddate->caption());

			// currcode
			$this->currcode->EditAttrs["class"] = "form-control";
			$this->currcode->EditCustomAttributes = "";
			if ($this->currcode->getSessionValue() != "") {
				$this->currcode->CurrentValue = $this->currcode->getSessionValue();
				$this->currcode->OldValue = $this->currcode->CurrentValue;
				$curVal = strval($this->currcode->CurrentValue);
				if ($curVal != "") {
					$this->currcode->ViewValue = $this->currcode->lookupCacheOption($curVal);
					if ($this->currcode->ViewValue === NULL) { // Lookup from database
						$filterWrk = "`currCode`" . SearchString("=", $curVal, DATATYPE_STRING, "_4payreference");
						$lookupFilter = function() {
							return "`langID`='EN'";
						};
						$lookupFilter = $lookupFilter->bindTo($this);
						$sqlWrk = $this->currcode->Lookup->getSql(FALSE, $filterWrk, $lookupFilter, $this);
						$rswrk = Conn("_4payreference")->execute($sqlWrk);
						if ($rswrk && !$rswrk->EOF) { // Lookup values found
							$arwrk = [];
							$arwrk[1] = $rswrk->fields('df');
							$arwrk[2] = $rswrk->fields('df2');
							$this->currcode->ViewValue = $this->currcode->displayValue($arwrk);
							$rswrk->Close();
						} else {
							$this->currcode->ViewValue = $this->currcode->CurrentValue;
						}
					}
				} else {
					$this->currcode->ViewValue = NULL;
				}
				$this->currcode->ViewCustomAttributes = "";
			} else {
				$curVal = trim(strval($this->currcode->CurrentValue));
				if ($curVal != "")
					$this->currcode->ViewValue = $this->currcode->lookupCacheOption($curVal);
				else
					$this->currcode->ViewValue = $this->currcode->Lookup !== NULL && is_array($this->currcode->Lookup->Options) ? $curVal : NULL;
				if ($this->currcode->ViewValue !== NULL) { // Load from cache
					$this->currcode->EditValue = array_values($this->currcode->Lookup->Options);
				} else { // Lookup from database
					if ($curVal == "") {
						$filterWrk = "0=1";
					} else {
						$filterWrk = "`currCode`" . SearchString("=", $this->currcode->CurrentValue, DATATYPE_STRING, "_4payreference");
					}
					$lookupFilter = function() {
						return "`langID`='EN'";
					};
					$lookupFilter = $lookupFilter->bindTo($this);
					$sqlWrk = $this->currcode->Lookup->getSql(TRUE, $filterWrk, $lookupFilter, $this);
					$rswrk = Conn("_4payreference")->execute($sqlWrk);
					$arwrk = $rswrk ? $rswrk->getRows() : [];
					if ($rswrk)
						$rswrk->close();
					$this->currcode->EditValue = $arwrk;
				}
			}

			// fullypaidind
			$this->fullypaidind->EditAttrs["class"] = "form-control";
			$this->fullypaidind->EditCustomAttributes = "";
			$this->fullypaidind->EditValue = $this->fullypaidind->options(TRUE);

			// loanconfirmed
			$this->loanconfirmed->EditCustomAttributes = "";
			$curVal = trim(strval($this->loanconfirmed->CurrentValue));
			if ($curVal != "")
				$this->loanconfirmed->ViewValue = $this->loanconfirmed->lookupCacheOption($curVal);
			else
				$this->loanconfirmed->ViewValue = $this->loanconfirmed->Lookup !== NULL && is_array($this->loanconfirmed->Lookup->Options) ? $curVal : NULL;
			if ($this->loanconfirmed->ViewValue !== NULL) { // Load from cache
				$this->loanconfirmed->EditValue = array_values($this->loanconfirmed->Lookup->Options);
			} else { // Lookup from database
				if ($curVal == "") {
					$filterWrk = "0=1";
				} else {
					$filterWrk = "`id`" . SearchString("=", $this->loanconfirmed->CurrentValue, DATATYPE_NUMBER, "");
				}
				$sqlWrk = $this->loanconfirmed->Lookup->getSql(TRUE, $filterWrk, '', $this);
				$rswrk = Conn()->execute($sqlWrk);
				$arwrk = $rswrk ? $rswrk->getRows() : [];
				if ($rswrk)
					$rswrk->close();
				$this->loanconfirmed->EditValue = $arwrk;
			}

			// termtype
			$this->termtype->EditCustomAttributes = "";
			$this->termtype->EditValue = $this->termtype->options(FALSE);

			// Edit refer script
			// loanid

			$this->loanid->LinkCustomAttributes = "";
			$this->loanid->HrefValue = "";

			// userid
			$this->_userid->LinkCustomAttributes = "";
			if (!EmptyValue($this->_userid->CurrentValue)) {
				$this->_userid->HrefValue = "loanlimitslist.php?showmaster=vuser&fk_id=" . $this->_userid->CurrentValue; // Add prefix/suffix
				$this->_userid->LinkAttrs["target"] = ""; // Add target
				if ($this->isExport())
					$this->_userid->HrefValue = FullUrl($this->_userid->HrefValue, "href");
			} else {
				$this->_userid->HrefValue = "";
			}

			// issueddate
			$this->issueddate->LinkCustomAttributes = "";
			$this->issueddate->HrefValue = "";

			// currcode
			$this->currcode->LinkCustomAttributes = "";
			$this->currcode->HrefValue = "";

			// fullypaidind
			$this->fullypaidind->LinkCustomAttributes = "";
			$this->fullypaidind->HrefValue = "";

			// loanconfirmed
			$this->loanconfirmed->LinkCustomAttributes = "";
			$this->loanconfirmed->HrefValue = "";

			// termtype
			$this->termtype->LinkCustomAttributes = "";
			$this->termtype->HrefValue = "";
		}
		if ($this->RowType == ROWTYPE_ADD || $this->RowType == ROWTYPE_EDIT || $this->RowType == ROWTYPE_SEARCH) // Add/Edit/Search row
			$this->setupFieldTitles();

		// Call Row Rendered event
		if ($this->RowType != ROWTYPE_AGGREGATEINIT)
			$this->Row_Rendered();
	}

	// Validate form
	protected function validateForm()
	{
		global $Language, $FormError;

		// Check if validation required
		if (!Config("SERVER_VALIDATE"))
			return ($FormError == "");
		if ($this->loanid->Required) {
			if (!$this->loanid->IsDetailKey && $this->loanid->FormValue != NULL && $this->loanid->FormValue == "") {
				AddMessage($FormError, str_replace("%s", $this->loanid->caption(), $this->loanid->RequiredErrorMessage));
			}
		}
		if ($this->_userid->Required) {
			if (!$this->_userid->IsDetailKey && $this->_userid->FormValue != NULL && $this->_userid->FormValue == "") {
				AddMessage($FormError, str_replace("%s", $this->_userid->caption(), $this->_userid->RequiredErrorMessage));
			}
		}
		if (!CheckInteger($this->_userid->FormValue)) {
			AddMessage($FormError, $this->_userid->errorMessage());
		}
		if ($this->issueddate->Required) {
			if (!$this->issueddate->IsDetailKey && $this->issueddate->FormValue != NULL && $this->issueddate->FormValue == "") {
				AddMessage($FormError, str_replace("%s", $this->issueddate->caption(), $this->issueddate->RequiredErrorMessage));
			}
		}
		if (!CheckDate($this->issueddate->FormValue)) {
			AddMessage($FormError, $this->issueddate->errorMessage());
		}
		if ($this->currcode->Required) {
			if (!$this->currcode->IsDetailKey && $this->currcode->FormValue != NULL && $this->currcode->FormValue == "") {
				AddMessage($FormError, str_replace("%s", $this->currcode->caption(), $this->currcode->RequiredErrorMessage));
			}
		}
		if ($this->fullypaidind->Required) {
			if (!$this->fullypaidind->IsDetailKey && $this->fullypaidind->FormValue != NULL && $this->fullypaidind->FormValue == "") {
				AddMessage($FormError, str_replace("%s", $this->fullypaidind->caption(), $this->fullypaidind->RequiredErrorMessage));
			}
		}
		if ($this->loanconfirmed->Required) {
			if ($this->loanconfirmed->FormValue == "") {
				AddMessage($FormError, str_replace("%s", $this->loanconfirmed->caption(), $this->loanconfirmed->RequiredErrorMessage));
			}
		}
		if ($this->termtype->Required) {
			if ($this->termtype->FormValue == "") {
				AddMessage($FormError, str_replace("%s", $this->termtype->caption(), $this->termtype->RequiredErrorMessage));
			}
		}

		// Return validate result
		$validateForm = ($FormError == "");

		// Call Form_CustomValidate event
		$formCustomError = "";
		$validateForm = $validateForm && $this->Form_CustomValidate($formCustomError);
		if ($formCustomError != "") {
			AddMessage($FormError, $formCustomError);
		}
		return $validateForm;
	}

	// Delete records based on current filter
	protected function deleteRows()
	{
		global $Language, $Security;
		if (!$Security->canDelete()) {
			$this->setFailureMessage($Language->phrase("NoDeletePermission")); // No delete permission
			return FALSE;
		}
		$deleteRows = TRUE;
		$sql = $this->getCurrentSql();
		$conn = $this->getConnection();
		$conn->raiseErrorFn = Config("ERROR_FUNC");
		$rs = $conn->execute($sql);
		$conn->raiseErrorFn = "";
		if ($rs === FALSE) {
			return FALSE;
		} elseif ($rs->EOF) {
			$this->setFailureMessage($Language->phrase("NoRecord")); // No record found
			$rs->close();
			return FALSE;
		}
		$rows = ($rs) ? $rs->getRows() : [];
		if ($this->AuditTrailOnDelete)
			$this->writeAuditTrailDummy($Language->phrase("BatchDeleteBegin")); // Batch delete begin

		// Clone old rows
		$rsold = $rows;
		if ($rs)
			$rs->close();

		// Call row deleting event
		if ($deleteRows) {
			foreach ($rsold as $row) {
				$deleteRows = $this->Row_Deleting($row);
				if (!$deleteRows)
					break;
			}
		}
		if ($deleteRows) {
			$key = "";
			foreach ($rsold as $row) {
				$thisKey = "";
				if ($thisKey != "")
					$thisKey .= Config("COMPOSITE_KEY_SEPARATOR");
				$thisKey .= $row['loanid'];
				if (Config("DELETE_UPLOADED_FILES")) // Delete old files
					$this->deleteUploadedFiles($row);
				$conn->raiseErrorFn = Config("ERROR_FUNC");
				$deleteRows = $this->delete($row); // Delete
				$conn->raiseErrorFn = "";
				if ($deleteRows === FALSE)
					break;
				if ($key != "")
					$key .= ", ";
				$key .= $thisKey;
			}
		}
		if (!$deleteRows) {

			// Set up error message
			if ($this->getSuccessMessage() != "" || $this->getFailureMessage() != "") {

				// Use the message, do nothing
			} elseif ($this->CancelMessage != "") {
				$this->setFailureMessage($this->CancelMessage);
				$this->CancelMessage = "";
			} else {
				$this->setFailureMessage($Language->phrase("DeleteCancelled"));
			}
		}

		// Call Row Deleted event
		if ($deleteRows) {
			foreach ($rsold as $row) {
				$this->Row_Deleted($row);
			}
		}

		// Write JSON for API request (Support single row only)
		if (IsApi() && $deleteRows) {
			$row = $this->getRecordsFromRecordset($rsold, TRUE);
			WriteJson(["success" => TRUE, $this->TableVar => $row]);
		}
		return $deleteRows;
	}

	// Update record based on key values
	protected function editRow()
	{
		global $Security, $Language;
		$oldKeyFilter = $this->getRecordFilter();
		$filter = $this->applyUserIDFilters($oldKeyFilter);
		$conn = $this->getConnection();
		$this->CurrentFilter = $filter;
		$sql = $this->getCurrentSql();
		$conn->raiseErrorFn = Config("ERROR_FUNC");
		$rs = $conn->execute($sql);
		$conn->raiseErrorFn = "";
		if ($rs === FALSE)
			return FALSE;
		if ($rs->EOF) {
			$this->setFailureMessage($Language->phrase("NoRecord")); // Set no record message
			$editRow = FALSE; // Update Failed
		} else {

			// Save old values
			$rsold = &$rs->fields;
			$this->loadDbValues($rsold);
			$rsnew = [];

			// userid
			$this->_userid->setDbValueDef($rsnew, $this->_userid->CurrentValue, 0, $this->_userid->ReadOnly);

			// issueddate
			$this->issueddate->setDbValueDef($rsnew, UnFormatDateTime($this->issueddate->CurrentValue, 1), NULL, $this->issueddate->ReadOnly);

			// currcode
			$this->currcode->setDbValueDef($rsnew, $this->currcode->CurrentValue, "", $this->currcode->ReadOnly);

			// fullypaidind
			$this->fullypaidind->setDbValueDef($rsnew, $this->fullypaidind->CurrentValue, 0, $this->fullypaidind->ReadOnly);

			// loanconfirmed
			$this->loanconfirmed->setDbValueDef($rsnew, $this->loanconfirmed->CurrentValue, 0, $this->loanconfirmed->ReadOnly);

			// termtype
			$this->termtype->setDbValueDef($rsnew, $this->termtype->CurrentValue, 0, $this->termtype->ReadOnly);

			// Check referential integrity for master table 'loanrequests'
			$validMasterRecord = TRUE;
			$masterFilter = $this->sqlMasterFilter_loanrequests();
			$keyValue = isset($rsnew['loanid']) ? $rsnew['loanid'] : $rsold['loanid'];
			if (strval($keyValue) != "") {
				$masterFilter = str_replace("@loanid@", AdjustSql($keyValue), $masterFilter);
			} else {
				$validMasterRecord = FALSE;
			}
			if ($validMasterRecord) {
				if (!isset($GLOBALS["loanrequests"]))
					$GLOBALS["loanrequests"] = new loanrequests();
				$rsmaster = $GLOBALS["loanrequests"]->loadRs($masterFilter);
				$validMasterRecord = ($rsmaster && !$rsmaster->EOF);
				$rsmaster->close();
			}
			if (!$validMasterRecord) {
				$relatedRecordMsg = str_replace("%t", "loanrequests", $Language->phrase("RelatedRecordRequired"));
				$this->setFailureMessage($relatedRecordMsg);
				$rs->close();
				return FALSE;
			}

			// Check referential integrity for master table 'loancancelrequests'
			$validMasterRecord = TRUE;
			$masterFilter = $this->sqlMasterFilter_loancancelrequests();
			$keyValue = isset($rsnew['loanid']) ? $rsnew['loanid'] : $rsold['loanid'];
			if (strval($keyValue) != "") {
				$masterFilter = str_replace("@cancelledloanid@", AdjustSql($keyValue), $masterFilter);
			} else {
				$validMasterRecord = FALSE;
			}
			if ($validMasterRecord) {
				if (!isset($GLOBALS["loancancelrequests"]))
					$GLOBALS["loancancelrequests"] = new loancancelrequests();
				$rsmaster = $GLOBALS["loancancelrequests"]->loadRs($masterFilter);
				$validMasterRecord = ($rsmaster && !$rsmaster->EOF);
				$rsmaster->close();
			}
			if (!$validMasterRecord) {
				$relatedRecordMsg = str_replace("%t", "loancancelrequests", $Language->phrase("RelatedRecordRequired"));
				$this->setFailureMessage($relatedRecordMsg);
				$rs->close();
				return FALSE;
			}

			// Check referential integrity for master table 'loanlimits'
			$validMasterRecord = TRUE;
			$masterFilter = $this->sqlMasterFilter_loanlimits();
			$keyValue = isset($rsnew['userid']) ? $rsnew['userid'] : $rsold['userid'];
			if (strval($keyValue) != "") {
				$masterFilter = str_replace("@_userid@", AdjustSql($keyValue), $masterFilter);
			} else {
				$validMasterRecord = FALSE;
			}
			$keyValue = isset($rsnew['currcode']) ? $rsnew['currcode'] : $rsold['currcode'];
			if (strval($keyValue) != "") {
				$masterFilter = str_replace("@currcode@", AdjustSql($keyValue), $masterFilter);
			} else {
				$validMasterRecord = FALSE;
			}
			if ($validMasterRecord) {
				if (!isset($GLOBALS["loanlimits"]))
					$GLOBALS["loanlimits"] = new loanlimits();
				$rsmaster = $GLOBALS["loanlimits"]->loadRs($masterFilter);
				$validMasterRecord = ($rsmaster && !$rsmaster->EOF);
				$rsmaster->close();
			}
			if (!$validMasterRecord) {
				$relatedRecordMsg = str_replace("%t", "loanlimits", $Language->phrase("RelatedRecordRequired"));
				$this->setFailureMessage($relatedRecordMsg);
				$rs->close();
				return FALSE;
			}

			// Call Row Updating event
			$updateRow = $this->Row_Updating($rsold, $rsnew);

			// Check for duplicate key when key changed
			if ($updateRow) {
				$newKeyFilter = $this->getRecordFilter($rsnew);
				if ($newKeyFilter != $oldKeyFilter) {
					$rsChk = $this->loadRs($newKeyFilter);
					if ($rsChk && !$rsChk->EOF) {
						$keyErrMsg = str_replace("%f", $newKeyFilter, $Language->phrase("DupKey"));
						$this->setFailureMessage($keyErrMsg);
						$rsChk->close();
						$updateRow = FALSE;
					}
				}
			}
			if ($updateRow) {
				$conn->raiseErrorFn = Config("ERROR_FUNC");
				if (count($rsnew) > 0)
					$editRow = $this->update($rsnew, "", $rsold);
				else
					$editRow = TRUE; // No field to update
				$conn->raiseErrorFn = "";
				if ($editRow) {
				}
			} else {
				if ($this->getSuccessMessage() != "" || $this->getFailureMessage() != "") {

					// Use the message, do nothing
				} elseif ($this->CancelMessage != "") {
					$this->setFailureMessage($this->CancelMessage);
					$this->CancelMessage = "";
				} else {
					$this->setFailureMessage($Language->phrase("UpdateCancelled"));
				}
				$editRow = FALSE;
			}
		}

		// Call Row_Updated event
		if ($editRow)
			$this->Row_Updated($rsold, $rsnew);
		$rs->close();

		// Clean upload path if any
		if ($editRow) {
		}

		// Write JSON for API request
		if (IsApi() && $editRow) {
			$row = $this->getRecordsFromRecordset([$rsnew], TRUE);
			WriteJson(["success" => TRUE, $this->TableVar => $row]);
		}
		return $editRow;
	}

	// Add record
	protected function addRow($rsold = NULL)
	{
		global $Language, $Security;

		// Set up foreign key field value from Session
			if ($this->getCurrentMasterTable() == "loanrequests") {
				$this->loanid->CurrentValue = $this->loanid->getSessionValue();
			}
			if ($this->getCurrentMasterTable() == "loancancelrequests") {
				$this->loanid->CurrentValue = $this->loanid->getSessionValue();
			}
			if ($this->getCurrentMasterTable() == "loanlimits") {
				$this->_userid->CurrentValue = $this->_userid->getSessionValue();
				$this->currcode->CurrentValue = $this->currcode->getSessionValue();
			}

		// Check referential integrity for master table 'loanissued'
		$validMasterRecord = TRUE;
		$masterFilter = $this->sqlMasterFilter_loanrequests();
		if (strval($this->loanid->CurrentValue) != "") {
			$masterFilter = str_replace("@loanid@", AdjustSql($this->loanid->CurrentValue, "DB"), $masterFilter);
		} else {
			$validMasterRecord = FALSE;
		}
		if ($validMasterRecord) {
			if (!isset($GLOBALS["loanrequests"]))
				$GLOBALS["loanrequests"] = new loanrequests();
			$rsmaster = $GLOBALS["loanrequests"]->loadRs($masterFilter);
			$validMasterRecord = ($rsmaster && !$rsmaster->EOF);
			$rsmaster->close();
		}
		if (!$validMasterRecord) {
			$relatedRecordMsg = str_replace("%t", "loanrequests", $Language->phrase("RelatedRecordRequired"));
			$this->setFailureMessage($relatedRecordMsg);
			return FALSE;
		}

		// Check referential integrity for master table 'loanissued'
		$validMasterRecord = TRUE;
		$masterFilter = $this->sqlMasterFilter_loancancelrequests();
		if (strval($this->loanid->CurrentValue) != "") {
			$masterFilter = str_replace("@cancelledloanid@", AdjustSql($this->loanid->CurrentValue, "DB"), $masterFilter);
		} else {
			$validMasterRecord = FALSE;
		}
		if ($validMasterRecord) {
			if (!isset($GLOBALS["loancancelrequests"]))
				$GLOBALS["loancancelrequests"] = new loancancelrequests();
			$rsmaster = $GLOBALS["loancancelrequests"]->loadRs($masterFilter);
			$validMasterRecord = ($rsmaster && !$rsmaster->EOF);
			$rsmaster->close();
		}
		if (!$validMasterRecord) {
			$relatedRecordMsg = str_replace("%t", "loancancelrequests", $Language->phrase("RelatedRecordRequired"));
			$this->setFailureMessage($relatedRecordMsg);
			return FALSE;
		}

		// Check referential integrity for master table 'loanissued'
		$validMasterRecord = TRUE;
		$masterFilter = $this->sqlMasterFilter_loanlimits();
		if (strval($this->_userid->CurrentValue) != "") {
			$masterFilter = str_replace("@_userid@", AdjustSql($this->_userid->CurrentValue, "DB"), $masterFilter);
		} else {
			$validMasterRecord = FALSE;
		}
		if (strval($this->currcode->CurrentValue) != "") {
			$masterFilter = str_replace("@currcode@", AdjustSql($this->currcode->CurrentValue, "DB"), $masterFilter);
		} else {
			$validMasterRecord = FALSE;
		}
		if ($validMasterRecord) {
			if (!isset($GLOBALS["loanlimits"]))
				$GLOBALS["loanlimits"] = new loanlimits();
			$rsmaster = $GLOBALS["loanlimits"]->loadRs($masterFilter);
			$validMasterRecord = ($rsmaster && !$rsmaster->EOF);
			$rsmaster->close();
		}
		if (!$validMasterRecord) {
			$relatedRecordMsg = str_replace("%t", "loanlimits", $Language->phrase("RelatedRecordRequired"));
			$this->setFailureMessage($relatedRecordMsg);
			return FALSE;
		}
		$conn = $this->getConnection();

		// Load db values from rsold
		$this->loadDbValues($rsold);
		if ($rsold) {
		}
		$rsnew = [];

		// userid
		$this->_userid->setDbValueDef($rsnew, $this->_userid->CurrentValue, 0, FALSE);

		// issueddate
		$this->issueddate->setDbValueDef($rsnew, UnFormatDateTime($this->issueddate->CurrentValue, 1), NULL, FALSE);

		// currcode
		$this->currcode->setDbValueDef($rsnew, $this->currcode->CurrentValue, "", FALSE);

		// fullypaidind
		$this->fullypaidind->setDbValueDef($rsnew, $this->fullypaidind->CurrentValue, 0, strval($this->fullypaidind->CurrentValue) == "");

		// loanconfirmed
		$this->loanconfirmed->setDbValueDef($rsnew, $this->loanconfirmed->CurrentValue, 0, strval($this->loanconfirmed->CurrentValue) == "");

		// termtype
		$this->termtype->setDbValueDef($rsnew, $this->termtype->CurrentValue, 0, strval($this->termtype->CurrentValue) == "");

		// Call Row Inserting event
		$rs = ($rsold) ? $rsold->fields : NULL;
		$insertRow = $this->Row_Inserting($rs, $rsnew);
		if ($insertRow) {
			$conn->raiseErrorFn = Config("ERROR_FUNC");
			$addRow = $this->insert($rsnew);
			$conn->raiseErrorFn = "";
			if ($addRow) {
			}
		} else {
			if ($this->getSuccessMessage() != "" || $this->getFailureMessage() != "") {

				// Use the message, do nothing
			} elseif ($this->CancelMessage != "") {
				$this->setFailureMessage($this->CancelMessage);
				$this->CancelMessage = "";
			} else {
				$this->setFailureMessage($Language->phrase("InsertCancelled"));
			}
			$addRow = FALSE;
		}
		if ($addRow) {

			// Call Row Inserted event
			$rs = ($rsold) ? $rsold->fields : NULL;
			$this->Row_Inserted($rs, $rsnew);
		}

		// Clean upload path if any
		if ($addRow) {
		}

		// Write JSON for API request
		if (IsApi() && $addRow) {
			$row = $this->getRecordsFromRecordset([$rsnew], TRUE);
			WriteJson(["success" => TRUE, $this->TableVar => $row]);
		}
		return $addRow;
	}

	// Set up master/detail based on QueryString
	protected function setupMasterParms()
	{

		// Hide foreign keys
		$masterTblVar = $this->getCurrentMasterTable();
		if ($masterTblVar == "loanrequests") {
			$this->loanid->Visible = FALSE;
			if ($GLOBALS["loanrequests"]->EventCancelled)
				$this->EventCancelled = TRUE;
		}
		if ($masterTblVar == "loancancelrequests") {
			$this->loanid->Visible = FALSE;
			if ($GLOBALS["loancancelrequests"]->EventCancelled)
				$this->EventCancelled = TRUE;
		}
		if ($masterTblVar == "loanlimits") {
			$this->_userid->Visible = FALSE;
			if ($GLOBALS["loanlimits"]->EventCancelled)
				$this->EventCancelled = TRUE;
			$this->currcode->Visible = FALSE;
			if ($GLOBALS["loanlimits"]->EventCancelled)
				$this->EventCancelled = TRUE;
		}
		$this->DbMasterFilter = $this->getMasterFilter(); // Get master filter
		$this->DbDetailFilter = $this->getDetailFilter(); // Get detail filter
	}

	// Setup lookup options
	public function setupLookupOptions($fld)
	{
		if ($fld->Lookup !== NULL && $fld->Lookup->Options === NULL) {

			// Get default connection and filter
			$conn = $this->getConnection();
			$lookupFilter = "";

			// No need to check any more
			$fld->Lookup->Options = [];

			// Set up lookup SQL and connection
			switch ($fld->FieldVar) {
				case "x_currcode":
					$conn = Conn("_4payreference");
					$lookupFilter = function() {
						return "`langID`='EN'";
					};
					$lookupFilter = $lookupFilter->bindTo($this);
					break;
				case "x_fullypaidind":
					$lookupFilter = function() {
						return "`langID` = 'EN'";
					};
					$lookupFilter = $lookupFilter->bindTo($this);
					break;
				case "x_loantype":
					$conn = Conn("_4payreference");
					break;
				case "x_loandue":
					break;
				case "x_disbursementtype":
					$conn = Conn("_4payreference");
					break;
				case "x_loanconfirmed":
					break;
				case "x_loanupgraded":
					$lookupFilter = function() {
						return "`langID` = 'EN'";
					};
					$lookupFilter = $lookupFilter->bindTo($this);
					break;
				case "x_stoplatefee":
					$lookupFilter = function() {
						return "`langID` = 'EN'";
					};
					$lookupFilter = $lookupFilter->bindTo($this);
					break;
				case "x_lockflag":
					break;
				case "x_notificationlockflag":
					break;
				case "x_termtype":
					break;
				default:
					$lookupFilter = "";
					break;
			}

			// Always call to Lookup->getSql so that user can setup Lookup->Options in Lookup_Selecting server event
			$sql = $fld->Lookup->getSql(FALSE, "", $lookupFilter, $this);

			// Set up lookup cache
			if ($fld->UseLookupCache && $sql != "" && count($fld->Lookup->Options) == 0) {
				$totalCnt = $this->getRecordCount($sql, $conn);
				if ($totalCnt > $fld->LookupCacheCount) // Total count > cache count, do not cache
					return;
				$rs = $conn->execute($sql);
				$ar = [];
				while ($rs && !$rs->EOF) {
					$row = &$rs->fields;

					// Format the field values
					switch ($fld->FieldVar) {
						case "x_currcode":
							break;
						case "x_loantype":
							$row[1] = FormatNumber($row[1], 0, -2, -2, -2);
							$row['df'] = $row[1];
							break;
						case "x_loandue":
							break;
						case "x_loanconfirmed":
							break;
						case "x_loanupgraded":
							break;
						case "x_stoplatefee":
							break;
					}
					$ar[strval($row[0])] = $row;
					$rs->moveNext();
				}
				if ($rs)
					$rs->close();
				$fld->Lookup->Options = $ar;
			}
		}
	}

	// Page Load event
	function Page_Load() {

		//echo "Page Load";
	}

	// Page Unload event
	function Page_Unload() {

		//echo "Page Unload";
	}

	// Page Redirecting event
	function Page_Redirecting(&$url) {

		// Example:
		//$url = "your URL";

	}

	// Message Showing event
	// $type = ''|'success'|'failure'|'warning'
	function Message_Showing(&$msg, $type) {
		if ($type == 'success') {

			//$msg = "your success message";
		} elseif ($type == 'failure') {

			//$msg = "your failure message";
		} elseif ($type == 'warning') {

			//$msg = "your warning message";
		} else {

			//$msg = "your message";
		}
	}

	// Page Render event
	function Page_Render() {

		//echo "Page Render";
	}

	// Page Data Rendering event
	function Page_DataRendering(&$header) {

		// Example:
		//$header = "your header";

	}

	// Page Data Rendered event
	function Page_DataRendered(&$footer) {

		// Example:
		//$footer = "your footer";

	}

	// Form Custom Validate event
	function Form_CustomValidate(&$customError) {

		// Return error message in CustomError
		return TRUE;
	}

	// ListOptions Load event
	function ListOptions_Load() {

		// Example:
		//$opt = &$this->ListOptions->Add("new");
		//$opt->Header = "xxx";
		//$opt->OnLeft = TRUE; // Link on left
		//$opt->MoveTo(0); // Move to first column

	}

	// ListOptions Rendering event
	function ListOptions_Rendering() {

		//$GLOBALS["xxx_grid"]->DetailAdd = (...condition...); // Set to TRUE or FALSE conditionally
		//$GLOBALS["xxx_grid"]->DetailEdit = (...condition...); // Set to TRUE or FALSE conditionally
		//$GLOBALS["xxx_grid"]->DetailView = (...condition...); // Set to TRUE or FALSE conditionally

	}

	// ListOptions Rendered event
	function ListOptions_Rendered() {

		// Example:
		//$this->ListOptions["new"]->Body = "xxx";

	}
} // End class
?>