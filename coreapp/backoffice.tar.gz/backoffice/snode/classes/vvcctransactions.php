<?php namespace PHPMaker2020\_4payadmin; ?>
<?php

/**
 * Table class for vvcctransactions
 */
class vvcctransactions extends DbTable
{
	protected $SqlFrom = "";
	protected $SqlSelect = "";
	protected $SqlSelectList = "";
	protected $SqlWhere = "";
	protected $SqlGroupBy = "";
	protected $SqlHaving = "";
	protected $SqlOrderBy = "";
	public $UseSessionForListSql = TRUE;

	// Column CSS classes
	public $LeftColumnClass = "col-sm-2 col-form-label ew-label";
	public $RightColumnClass = "col-sm-10";
	public $OffsetColumnClass = "col-sm-10 offset-sm-2";
	public $TableLeftColumnClass = "w-col-2";

	// Export
	public $ExportDoc;

	// Fields
	public $id;
	public $datecreated;
	public $brokerid;
	public $requestorid;
	public $requestor4payuser;
	public $recipientid;
	public $recipient4payuser;
	public $refno1;
	public $refno2;
	public $saleid;
	public $operatorid;
	public $txid;
	public $merchantID;
	public $_userID;
	public $transferTime;
	public $merchantSurcharge;
	public $currID;
	public $purchaseAmount;
	public $taxAmount;
	public $tipAmount;
	public $serviceFeeToCustomer;
	public $TotalAmountForCustomer;
	public $serviceFeeToMerchant;
	public $status;
	public $shoppingCartID;
	public $merchantRefID;
	public $feeid;
	public $ratetabletype;
	public $pis;
	public $feesystemshare;
	public $feeexternalshare;
	public $feeresellershare;
	public $lastupdatetime;
	public $expirationTimeInMinutes;
	public $expirationTime;
	public $customeruserid;
	public $piname;
	public $branchname;
	public $operatorname;
	public $customerusername;
	public $feefranchiseeshare;
	public $serviceFeeToCustomerbk1amt;
	public $serviceFeeToCustomerbk1type;
	public $serviceFeeToCustomerbk2amt;
	public $serviceFeeToCustomerbk2type;
	public $serviceFeeToCustomerbk3type;
	public $serviceFeeToCustomerbk3amt;
	public $taxAmountbk1amt;
	public $taxAmountbk1type;
	public $taxAmountbk2amt;
	public $taxAmountbk2type;
	public $taxAmountbk3amt;
	public $taxAmountbk3type;

	// Constructor
	public function __construct()
	{
		global $Language, $CurrentLanguage;
		parent::__construct();

		// Language object
		if (!isset($Language))
			$Language = new Language();
		$this->TableVar = 'vvcctransactions';
		$this->TableName = 'vvcctransactions';
		$this->TableType = 'VIEW';

		// Update Table
		$this->UpdateTable = "`vvcctransactions`";
		$this->Dbid = 'DB';
		$this->ExportAll = TRUE;
		$this->ExportPageBreakCount = 0; // Page break per every n record (PDF only)
		$this->ExportPageOrientation = "portrait"; // Page orientation (PDF only)
		$this->ExportPageSize = "a4"; // Page size (PDF only)
		$this->ExportExcelPageOrientation = \PhpOffice\PhpSpreadsheet\Worksheet\PageSetup::ORIENTATION_DEFAULT; // Page orientation (PhpSpreadsheet only)
		$this->ExportExcelPageSize = \PhpOffice\PhpSpreadsheet\Worksheet\PageSetup::PAPERSIZE_A4; // Page size (PhpSpreadsheet only)
		$this->ExportWordPageOrientation = "portrait"; // Page orientation (PHPWord only)
		$this->ExportWordColumnWidth = NULL; // Cell width (PHPWord only)
		$this->DetailAdd = FALSE; // Allow detail add
		$this->DetailEdit = FALSE; // Allow detail edit
		$this->DetailView = FALSE; // Allow detail view
		$this->ShowMultipleDetails = FALSE; // Show multiple details
		$this->GridAddRowCount = 5;
		$this->AllowAddDeleteRow = TRUE; // Allow add/delete row
		$this->UserIDAllowSecurity = Config("DEFAULT_USER_ID_ALLOW_SECURITY"); // Default User ID allowed permissions
		$this->BasicSearch = new BasicSearch($this->TableVar);

		// id
		$this->id = new DbField('vvcctransactions', 'vvcctransactions', 'x_id', 'id', '`id`', '`id`', 3, 12, -1, FALSE, '`id`', FALSE, FALSE, FALSE, 'FORMATTED TEXT', 'NO');
		$this->id->IsAutoIncrement = TRUE; // Autoincrement field
		$this->id->IsPrimaryKey = TRUE; // Primary key field
		$this->id->Sortable = TRUE; // Allow sort
		$this->id->DefaultErrorMessage = $Language->phrase("IncorrectInteger");
		$this->fields['id'] = &$this->id;

		// datecreated
		$this->datecreated = new DbField('vvcctransactions', 'vvcctransactions', 'x_datecreated', 'datecreated', '`datecreated`', CastDateFieldForLike("`datecreated`", 0, "DB"), 135, 19, 0, FALSE, '`datecreated`', FALSE, FALSE, FALSE, 'FORMATTED TEXT', 'TEXT');
		$this->datecreated->Sortable = TRUE; // Allow sort
		$this->datecreated->DefaultErrorMessage = str_replace("%s", $GLOBALS["DATE_FORMAT"], $Language->phrase("IncorrectDate"));
		$this->fields['datecreated'] = &$this->datecreated;

		// brokerid
		$this->brokerid = new DbField('vvcctransactions', 'vvcctransactions', 'x_brokerid', 'brokerid', '`brokerid`', '`brokerid`', 3, 12, -1, FALSE, '`brokerid`', FALSE, FALSE, FALSE, 'FORMATTED TEXT', 'TEXT');
		$this->brokerid->Nullable = FALSE; // NOT NULL field
		$this->brokerid->Required = TRUE; // Required field
		$this->brokerid->Sortable = TRUE; // Allow sort
		$this->brokerid->DefaultErrorMessage = $Language->phrase("IncorrectInteger");
		$this->fields['brokerid'] = &$this->brokerid;

		// requestorid
		$this->requestorid = new DbField('vvcctransactions', 'vvcctransactions', 'x_requestorid', 'requestorid', '`requestorid`', '`requestorid`', 3, 12, -1, FALSE, '`requestorid`', FALSE, FALSE, FALSE, 'FORMATTED TEXT', 'TEXT');
		$this->requestorid->Nullable = FALSE; // NOT NULL field
		$this->requestorid->Required = TRUE; // Required field
		$this->requestorid->Sortable = TRUE; // Allow sort
		$this->requestorid->DefaultErrorMessage = $Language->phrase("IncorrectInteger");
		$this->fields['requestorid'] = &$this->requestorid;

		// requestor4payuser
		$this->requestor4payuser = new DbField('vvcctransactions', 'vvcctransactions', 'x_requestor4payuser', 'requestor4payuser', '`requestor4payuser`', '`requestor4payuser`', 3, 1, -1, FALSE, '`requestor4payuser`', FALSE, FALSE, FALSE, 'FORMATTED TEXT', 'TEXT');
		$this->requestor4payuser->Nullable = FALSE; // NOT NULL field
		$this->requestor4payuser->Required = TRUE; // Required field
		$this->requestor4payuser->Sortable = TRUE; // Allow sort
		$this->requestor4payuser->DefaultErrorMessage = $Language->phrase("IncorrectInteger");
		$this->fields['requestor4payuser'] = &$this->requestor4payuser;

		// recipientid
		$this->recipientid = new DbField('vvcctransactions', 'vvcctransactions', 'x_recipientid', 'recipientid', '`recipientid`', '`recipientid`', 3, 12, -1, FALSE, '`recipientid`', FALSE, FALSE, FALSE, 'FORMATTED TEXT', 'TEXT');
		$this->recipientid->Nullable = FALSE; // NOT NULL field
		$this->recipientid->Required = TRUE; // Required field
		$this->recipientid->Sortable = TRUE; // Allow sort
		$this->recipientid->DefaultErrorMessage = $Language->phrase("IncorrectInteger");
		$this->fields['recipientid'] = &$this->recipientid;

		// recipient4payuser
		$this->recipient4payuser = new DbField('vvcctransactions', 'vvcctransactions', 'x_recipient4payuser', 'recipient4payuser', '`recipient4payuser`', '`recipient4payuser`', 3, 1, -1, FALSE, '`recipient4payuser`', FALSE, FALSE, FALSE, 'FORMATTED TEXT', 'TEXT');
		$this->recipient4payuser->Nullable = FALSE; // NOT NULL field
		$this->recipient4payuser->Required = TRUE; // Required field
		$this->recipient4payuser->Sortable = TRUE; // Allow sort
		$this->recipient4payuser->DefaultErrorMessage = $Language->phrase("IncorrectInteger");
		$this->fields['recipient4payuser'] = &$this->recipient4payuser;

		// refno1
		$this->refno1 = new DbField('vvcctransactions', 'vvcctransactions', 'x_refno1', 'refno1', '`refno1`', '`refno1`', 200, 20, -1, FALSE, '`refno1`', FALSE, FALSE, FALSE, 'FORMATTED TEXT', 'TEXT');
		$this->refno1->Sortable = TRUE; // Allow sort
		$this->fields['refno1'] = &$this->refno1;

		// refno2
		$this->refno2 = new DbField('vvcctransactions', 'vvcctransactions', 'x_refno2', 'refno2', '`refno2`', '`refno2`', 200, 20, -1, FALSE, '`refno2`', FALSE, FALSE, FALSE, 'FORMATTED TEXT', 'TEXT');
		$this->refno2->Sortable = TRUE; // Allow sort
		$this->fields['refno2'] = &$this->refno2;

		// saleid
		$this->saleid = new DbField('vvcctransactions', 'vvcctransactions', 'x_saleid', 'saleid', '`saleid`', '`saleid`', 20, 15, -1, FALSE, '`saleid`', FALSE, FALSE, FALSE, 'FORMATTED TEXT', 'TEXT');
		$this->saleid->Sortable = TRUE; // Allow sort
		$this->saleid->DefaultErrorMessage = $Language->phrase("IncorrectInteger");
		$this->fields['saleid'] = &$this->saleid;

		// operatorid
		$this->operatorid = new DbField('vvcctransactions', 'vvcctransactions', 'x_operatorid', 'operatorid', '`operatorid`', '`operatorid`', 20, 12, -1, FALSE, '`operatorid`', FALSE, FALSE, FALSE, 'FORMATTED TEXT', 'TEXT');
		$this->operatorid->Nullable = FALSE; // NOT NULL field
		$this->operatorid->Sortable = TRUE; // Allow sort
		$this->operatorid->DefaultErrorMessage = $Language->phrase("IncorrectInteger");
		$this->fields['operatorid'] = &$this->operatorid;

		// txid
		$this->txid = new DbField('vvcctransactions', 'vvcctransactions', 'x_txid', 'txid', '`txid`', '`txid`', 200, 10, -1, FALSE, '`txid`', FALSE, FALSE, FALSE, 'FORMATTED TEXT', 'TEXT');
		$this->txid->IsPrimaryKey = TRUE; // Primary key field
		$this->txid->Nullable = FALSE; // NOT NULL field
		$this->txid->Required = TRUE; // Required field
		$this->txid->Sortable = TRUE; // Allow sort
		$this->fields['txid'] = &$this->txid;

		// merchantID
		$this->merchantID = new DbField('vvcctransactions', 'vvcctransactions', 'x_merchantID', 'merchantID', '`merchantID`', '`merchantID`', 3, 12, -1, FALSE, '`merchantID`', FALSE, FALSE, FALSE, 'FORMATTED TEXT', 'TEXT');
		$this->merchantID->Nullable = FALSE; // NOT NULL field
		$this->merchantID->Required = TRUE; // Required field
		$this->merchantID->Sortable = TRUE; // Allow sort
		$this->merchantID->DefaultErrorMessage = $Language->phrase("IncorrectInteger");
		$this->fields['merchantID'] = &$this->merchantID;

		// userID
		$this->_userID = new DbField('vvcctransactions', 'vvcctransactions', 'x__userID', 'userID', '`userID`', '`userID`', 3, 12, -1, FALSE, '`userID`', FALSE, FALSE, FALSE, 'FORMATTED TEXT', 'TEXT');
		$this->_userID->Nullable = FALSE; // NOT NULL field
		$this->_userID->Required = TRUE; // Required field
		$this->_userID->Sortable = TRUE; // Allow sort
		$this->_userID->DefaultErrorMessage = $Language->phrase("IncorrectInteger");
		$this->fields['userID'] = &$this->_userID;

		// transferTime
		$this->transferTime = new DbField('vvcctransactions', 'vvcctransactions', 'x_transferTime', 'transferTime', '`transferTime`', CastDateFieldForLike("`transferTime`", 0, "DB"), 135, 19, 0, FALSE, '`transferTime`', FALSE, FALSE, FALSE, 'FORMATTED TEXT', 'TEXT');
		$this->transferTime->Sortable = TRUE; // Allow sort
		$this->transferTime->DefaultErrorMessage = str_replace("%s", $GLOBALS["DATE_FORMAT"], $Language->phrase("IncorrectDate"));
		$this->fields['transferTime'] = &$this->transferTime;

		// merchantSurcharge
		$this->merchantSurcharge = new DbField('vvcctransactions', 'vvcctransactions', 'x_merchantSurcharge', 'merchantSurcharge', '`merchantSurcharge`', '`merchantSurcharge`', 131, 20, -1, FALSE, '`merchantSurcharge`', FALSE, FALSE, FALSE, 'FORMATTED TEXT', 'TEXT');
		$this->merchantSurcharge->Nullable = FALSE; // NOT NULL field
		$this->merchantSurcharge->Sortable = TRUE; // Allow sort
		$this->merchantSurcharge->DefaultErrorMessage = $Language->phrase("IncorrectFloat");
		$this->fields['merchantSurcharge'] = &$this->merchantSurcharge;

		// currID
		$this->currID = new DbField('vvcctransactions', 'vvcctransactions', 'x_currID', 'currID', '`currID`', '`currID`', 200, 3, -1, FALSE, '`currID`', FALSE, FALSE, FALSE, 'FORMATTED TEXT', 'TEXT');
		$this->currID->Nullable = FALSE; // NOT NULL field
		$this->currID->Required = TRUE; // Required field
		$this->currID->Sortable = TRUE; // Allow sort
		$this->fields['currID'] = &$this->currID;

		// purchaseAmount
		$this->purchaseAmount = new DbField('vvcctransactions', 'vvcctransactions', 'x_purchaseAmount', 'purchaseAmount', '`purchaseAmount`', '`purchaseAmount`', 131, 20, -1, FALSE, '`purchaseAmount`', FALSE, FALSE, FALSE, 'FORMATTED TEXT', 'TEXT');
		$this->purchaseAmount->Nullable = FALSE; // NOT NULL field
		$this->purchaseAmount->Sortable = TRUE; // Allow sort
		$this->purchaseAmount->DefaultErrorMessage = $Language->phrase("IncorrectFloat");
		$this->fields['purchaseAmount'] = &$this->purchaseAmount;

		// taxAmount
		$this->taxAmount = new DbField('vvcctransactions', 'vvcctransactions', 'x_taxAmount', 'taxAmount', '`taxAmount`', '`taxAmount`', 131, 20, -1, FALSE, '`taxAmount`', FALSE, FALSE, FALSE, 'FORMATTED TEXT', 'TEXT');
		$this->taxAmount->Nullable = FALSE; // NOT NULL field
		$this->taxAmount->Sortable = TRUE; // Allow sort
		$this->taxAmount->DefaultErrorMessage = $Language->phrase("IncorrectFloat");
		$this->fields['taxAmount'] = &$this->taxAmount;

		// tipAmount
		$this->tipAmount = new DbField('vvcctransactions', 'vvcctransactions', 'x_tipAmount', 'tipAmount', '`tipAmount`', '`tipAmount`', 131, 20, -1, FALSE, '`tipAmount`', FALSE, FALSE, FALSE, 'FORMATTED TEXT', 'TEXT');
		$this->tipAmount->Nullable = FALSE; // NOT NULL field
		$this->tipAmount->Sortable = TRUE; // Allow sort
		$this->tipAmount->DefaultErrorMessage = $Language->phrase("IncorrectFloat");
		$this->fields['tipAmount'] = &$this->tipAmount;

		// serviceFeeToCustomer
		$this->serviceFeeToCustomer = new DbField('vvcctransactions', 'vvcctransactions', 'x_serviceFeeToCustomer', 'serviceFeeToCustomer', '`serviceFeeToCustomer`', '`serviceFeeToCustomer`', 131, 20, -1, FALSE, '`serviceFeeToCustomer`', FALSE, FALSE, FALSE, 'FORMATTED TEXT', 'TEXT');
		$this->serviceFeeToCustomer->Nullable = FALSE; // NOT NULL field
		$this->serviceFeeToCustomer->Sortable = TRUE; // Allow sort
		$this->serviceFeeToCustomer->DefaultErrorMessage = $Language->phrase("IncorrectFloat");
		$this->fields['serviceFeeToCustomer'] = &$this->serviceFeeToCustomer;

		// TotalAmountForCustomer
		$this->TotalAmountForCustomer = new DbField('vvcctransactions', 'vvcctransactions', 'x_TotalAmountForCustomer', 'TotalAmountForCustomer', '`TotalAmountForCustomer`', '`TotalAmountForCustomer`', 131, 20, -1, FALSE, '`TotalAmountForCustomer`', FALSE, FALSE, FALSE, 'FORMATTED TEXT', 'TEXT');
		$this->TotalAmountForCustomer->Nullable = FALSE; // NOT NULL field
		$this->TotalAmountForCustomer->Sortable = TRUE; // Allow sort
		$this->TotalAmountForCustomer->DefaultErrorMessage = $Language->phrase("IncorrectFloat");
		$this->fields['TotalAmountForCustomer'] = &$this->TotalAmountForCustomer;

		// serviceFeeToMerchant
		$this->serviceFeeToMerchant = new DbField('vvcctransactions', 'vvcctransactions', 'x_serviceFeeToMerchant', 'serviceFeeToMerchant', '`serviceFeeToMerchant`', '`serviceFeeToMerchant`', 131, 20, -1, FALSE, '`serviceFeeToMerchant`', FALSE, FALSE, FALSE, 'FORMATTED TEXT', 'TEXT');
		$this->serviceFeeToMerchant->Nullable = FALSE; // NOT NULL field
		$this->serviceFeeToMerchant->Sortable = TRUE; // Allow sort
		$this->serviceFeeToMerchant->DefaultErrorMessage = $Language->phrase("IncorrectFloat");
		$this->fields['serviceFeeToMerchant'] = &$this->serviceFeeToMerchant;

		// status
		$this->status = new DbField('vvcctransactions', 'vvcctransactions', 'x_status', 'status', '`status`', '`status`', 3, 3, -1, FALSE, '`status`', FALSE, FALSE, FALSE, 'FORMATTED TEXT', 'SELECT');
		$this->status->Nullable = FALSE; // NOT NULL field
		$this->status->Required = TRUE; // Required field
		$this->status->Sortable = TRUE; // Allow sort
		$this->status->UsePleaseSelect = TRUE; // Use PleaseSelect by default
		$this->status->PleaseSelectText = $Language->phrase("PleaseSelect"); // "PleaseSelect" text
		$this->status->Lookup = new Lookup('status', 'vvcctransactions', FALSE, '', ["","","",""], [], [], [], [], [], [], '', '');
		$this->status->OptionCount = 2;
		$this->status->DefaultErrorMessage = $Language->phrase("IncorrectInteger");
		$this->fields['status'] = &$this->status;

		// shoppingCartID
		$this->shoppingCartID = new DbField('vvcctransactions', 'vvcctransactions', 'x_shoppingCartID', 'shoppingCartID', '`shoppingCartID`', '`shoppingCartID`', 200, 20, -1, FALSE, '`shoppingCartID`', FALSE, FALSE, FALSE, 'FORMATTED TEXT', 'TEXT');
		$this->shoppingCartID->Sortable = TRUE; // Allow sort
		$this->fields['shoppingCartID'] = &$this->shoppingCartID;

		// merchantRefID
		$this->merchantRefID = new DbField('vvcctransactions', 'vvcctransactions', 'x_merchantRefID', 'merchantRefID', '`merchantRefID`', '`merchantRefID`', 200, 30, -1, FALSE, '`merchantRefID`', FALSE, FALSE, FALSE, 'FORMATTED TEXT', 'TEXT');
		$this->merchantRefID->Sortable = TRUE; // Allow sort
		$this->fields['merchantRefID'] = &$this->merchantRefID;

		// feeid
		$this->feeid = new DbField('vvcctransactions', 'vvcctransactions', 'x_feeid', 'feeid', '`feeid`', '`feeid`', 3, 10, -1, FALSE, '`feeid`', FALSE, FALSE, FALSE, 'FORMATTED TEXT', 'TEXT');
		$this->feeid->Nullable = FALSE; // NOT NULL field
		$this->feeid->Required = TRUE; // Required field
		$this->feeid->Sortable = TRUE; // Allow sort
		$this->feeid->DefaultErrorMessage = $Language->phrase("IncorrectInteger");
		$this->fields['feeid'] = &$this->feeid;

		// ratetabletype
		$this->ratetabletype = new DbField('vvcctransactions', 'vvcctransactions', 'x_ratetabletype', 'ratetabletype', '`ratetabletype`', '`ratetabletype`', 3, 1, -1, FALSE, '`ratetabletype`', FALSE, FALSE, FALSE, 'FORMATTED TEXT', 'TEXT');
		$this->ratetabletype->Nullable = FALSE; // NOT NULL field
		$this->ratetabletype->Required = TRUE; // Required field
		$this->ratetabletype->Sortable = TRUE; // Allow sort
		$this->ratetabletype->DefaultErrorMessage = $Language->phrase("IncorrectInteger");
		$this->fields['ratetabletype'] = &$this->ratetabletype;

		// pis
		$this->pis = new DbField('vvcctransactions', 'vvcctransactions', 'x_pis', 'pis', '`pis`', '`pis`', 201, 1000, -1, FALSE, '`pis`', FALSE, FALSE, FALSE, 'FORMATTED TEXT', 'TEXTAREA');
		$this->pis->Nullable = FALSE; // NOT NULL field
		$this->pis->Required = TRUE; // Required field
		$this->pis->Sortable = TRUE; // Allow sort
		$this->fields['pis'] = &$this->pis;

		// feesystemshare
		$this->feesystemshare = new DbField('vvcctransactions', 'vvcctransactions', 'x_feesystemshare', 'feesystemshare', '`feesystemshare`', '`feesystemshare`', 131, 20, -1, FALSE, '`feesystemshare`', FALSE, FALSE, FALSE, 'FORMATTED TEXT', 'TEXT');
		$this->feesystemshare->Nullable = FALSE; // NOT NULL field
		$this->feesystemshare->Sortable = TRUE; // Allow sort
		$this->feesystemshare->DefaultErrorMessage = $Language->phrase("IncorrectFloat");
		$this->fields['feesystemshare'] = &$this->feesystemshare;

		// feeexternalshare
		$this->feeexternalshare = new DbField('vvcctransactions', 'vvcctransactions', 'x_feeexternalshare', 'feeexternalshare', '`feeexternalshare`', '`feeexternalshare`', 131, 20, -1, FALSE, '`feeexternalshare`', FALSE, FALSE, FALSE, 'FORMATTED TEXT', 'TEXT');
		$this->feeexternalshare->Nullable = FALSE; // NOT NULL field
		$this->feeexternalshare->Required = TRUE; // Required field
		$this->feeexternalshare->Sortable = TRUE; // Allow sort
		$this->feeexternalshare->DefaultErrorMessage = $Language->phrase("IncorrectFloat");
		$this->fields['feeexternalshare'] = &$this->feeexternalshare;

		// feeresellershare
		$this->feeresellershare = new DbField('vvcctransactions', 'vvcctransactions', 'x_feeresellershare', 'feeresellershare', '`feeresellershare`', '`feeresellershare`', 131, 20, -1, FALSE, '`feeresellershare`', FALSE, FALSE, FALSE, 'FORMATTED TEXT', 'TEXT');
		$this->feeresellershare->Nullable = FALSE; // NOT NULL field
		$this->feeresellershare->Required = TRUE; // Required field
		$this->feeresellershare->Sortable = TRUE; // Allow sort
		$this->feeresellershare->DefaultErrorMessage = $Language->phrase("IncorrectFloat");
		$this->fields['feeresellershare'] = &$this->feeresellershare;

		// lastupdatetime
		$this->lastupdatetime = new DbField('vvcctransactions', 'vvcctransactions', 'x_lastupdatetime', 'lastupdatetime', '`lastupdatetime`', CastDateFieldForLike("`lastupdatetime`", 0, "DB"), 135, 19, 0, FALSE, '`lastupdatetime`', FALSE, FALSE, FALSE, 'FORMATTED TEXT', 'TEXT');
		$this->lastupdatetime->Nullable = FALSE; // NOT NULL field
		$this->lastupdatetime->Required = TRUE; // Required field
		$this->lastupdatetime->Sortable = TRUE; // Allow sort
		$this->lastupdatetime->DefaultErrorMessage = str_replace("%s", $GLOBALS["DATE_FORMAT"], $Language->phrase("IncorrectDate"));
		$this->fields['lastupdatetime'] = &$this->lastupdatetime;

		// expirationTimeInMinutes
		$this->expirationTimeInMinutes = new DbField('vvcctransactions', 'vvcctransactions', 'x_expirationTimeInMinutes', 'expirationTimeInMinutes', '`expirationTimeInMinutes`', '`expirationTimeInMinutes`', 3, 6, -1, FALSE, '`expirationTimeInMinutes`', FALSE, FALSE, FALSE, 'FORMATTED TEXT', 'TEXT');
		$this->expirationTimeInMinutes->Nullable = FALSE; // NOT NULL field
		$this->expirationTimeInMinutes->Required = TRUE; // Required field
		$this->expirationTimeInMinutes->Sortable = TRUE; // Allow sort
		$this->expirationTimeInMinutes->DefaultErrorMessage = $Language->phrase("IncorrectInteger");
		$this->fields['expirationTimeInMinutes'] = &$this->expirationTimeInMinutes;

		// expirationTime
		$this->expirationTime = new DbField('vvcctransactions', 'vvcctransactions', 'x_expirationTime', 'expirationTime', '`expirationTime`', CastDateFieldForLike("`expirationTime`", 0, "DB"), 135, 19, 0, FALSE, '`expirationTime`', FALSE, FALSE, FALSE, 'FORMATTED TEXT', 'TEXT');
		$this->expirationTime->Sortable = TRUE; // Allow sort
		$this->expirationTime->DefaultErrorMessage = str_replace("%s", $GLOBALS["DATE_FORMAT"], $Language->phrase("IncorrectDate"));
		$this->fields['expirationTime'] = &$this->expirationTime;

		// customeruserid
		$this->customeruserid = new DbField('vvcctransactions', 'vvcctransactions', 'x_customeruserid', 'customeruserid', '`customeruserid`', '`customeruserid`', 3, 12, -1, FALSE, '`customeruserid`', FALSE, FALSE, FALSE, 'FORMATTED TEXT', 'TEXT');
		$this->customeruserid->Nullable = FALSE; // NOT NULL field
		$this->customeruserid->Sortable = TRUE; // Allow sort
		$this->customeruserid->DefaultErrorMessage = $Language->phrase("IncorrectInteger");
		$this->fields['customeruserid'] = &$this->customeruserid;

		// piname
		$this->piname = new DbField('vvcctransactions', 'vvcctransactions', 'x_piname', 'piname', '`piname`', '`piname`', 200, 75, -1, FALSE, '`piname`', FALSE, FALSE, FALSE, 'FORMATTED TEXT', 'TEXT');
		$this->piname->Nullable = FALSE; // NOT NULL field
		$this->piname->Required = TRUE; // Required field
		$this->piname->Sortable = TRUE; // Allow sort
		$this->fields['piname'] = &$this->piname;

		// branchname
		$this->branchname = new DbField('vvcctransactions', 'vvcctransactions', 'x_branchname', 'branchname', '`branchname`', '`branchname`', 200, 50, -1, FALSE, '`branchname`', FALSE, FALSE, FALSE, 'FORMATTED TEXT', 'TEXT');
		$this->branchname->Sortable = TRUE; // Allow sort
		$this->fields['branchname'] = &$this->branchname;

		// operatorname
		$this->operatorname = new DbField('vvcctransactions', 'vvcctransactions', 'x_operatorname', 'operatorname', '`operatorname`', '`operatorname`', 200, 50, -1, FALSE, '`operatorname`', FALSE, FALSE, FALSE, 'FORMATTED TEXT', 'TEXT');
		$this->operatorname->Sortable = TRUE; // Allow sort
		$this->fields['operatorname'] = &$this->operatorname;

		// customerusername
		$this->customerusername = new DbField('vvcctransactions', 'vvcctransactions', 'x_customerusername', 'customerusername', '`customerusername`', '`customerusername`', 200, 80, -1, FALSE, '`customerusername`', FALSE, FALSE, FALSE, 'FORMATTED TEXT', 'TEXT');
		$this->customerusername->Sortable = TRUE; // Allow sort
		$this->fields['customerusername'] = &$this->customerusername;

		// feefranchiseeshare
		$this->feefranchiseeshare = new DbField('vvcctransactions', 'vvcctransactions', 'x_feefranchiseeshare', 'feefranchiseeshare', '`feefranchiseeshare`', '`feefranchiseeshare`', 131, 20, -1, FALSE, '`feefranchiseeshare`', FALSE, FALSE, FALSE, 'FORMATTED TEXT', 'TEXT');
		$this->feefranchiseeshare->Nullable = FALSE; // NOT NULL field
		$this->feefranchiseeshare->Required = TRUE; // Required field
		$this->feefranchiseeshare->Sortable = TRUE; // Allow sort
		$this->feefranchiseeshare->DefaultErrorMessage = $Language->phrase("IncorrectFloat");
		$this->fields['feefranchiseeshare'] = &$this->feefranchiseeshare;

		// serviceFeeToCustomerbk1amt
		$this->serviceFeeToCustomerbk1amt = new DbField('vvcctransactions', 'vvcctransactions', 'x_serviceFeeToCustomerbk1amt', 'serviceFeeToCustomerbk1amt', '`serviceFeeToCustomerbk1amt`', '`serviceFeeToCustomerbk1amt`', 131, 20, -1, FALSE, '`serviceFeeToCustomerbk1amt`', FALSE, FALSE, FALSE, 'FORMATTED TEXT', 'TEXT');
		$this->serviceFeeToCustomerbk1amt->Nullable = FALSE; // NOT NULL field
		$this->serviceFeeToCustomerbk1amt->Sortable = TRUE; // Allow sort
		$this->serviceFeeToCustomerbk1amt->DefaultErrorMessage = $Language->phrase("IncorrectFloat");
		$this->fields['serviceFeeToCustomerbk1amt'] = &$this->serviceFeeToCustomerbk1amt;

		// serviceFeeToCustomerbk1type
		$this->serviceFeeToCustomerbk1type = new DbField('vvcctransactions', 'vvcctransactions', 'x_serviceFeeToCustomerbk1type', 'serviceFeeToCustomerbk1type', '`serviceFeeToCustomerbk1type`', '`serviceFeeToCustomerbk1type`', 200, 15, -1, FALSE, '`serviceFeeToCustomerbk1type`', FALSE, FALSE, FALSE, 'FORMATTED TEXT', 'TEXT');
		$this->serviceFeeToCustomerbk1type->Sortable = TRUE; // Allow sort
		$this->fields['serviceFeeToCustomerbk1type'] = &$this->serviceFeeToCustomerbk1type;

		// serviceFeeToCustomerbk2amt
		$this->serviceFeeToCustomerbk2amt = new DbField('vvcctransactions', 'vvcctransactions', 'x_serviceFeeToCustomerbk2amt', 'serviceFeeToCustomerbk2amt', '`serviceFeeToCustomerbk2amt`', '`serviceFeeToCustomerbk2amt`', 131, 20, -1, FALSE, '`serviceFeeToCustomerbk2amt`', FALSE, FALSE, FALSE, 'FORMATTED TEXT', 'TEXT');
		$this->serviceFeeToCustomerbk2amt->Nullable = FALSE; // NOT NULL field
		$this->serviceFeeToCustomerbk2amt->Sortable = TRUE; // Allow sort
		$this->serviceFeeToCustomerbk2amt->DefaultErrorMessage = $Language->phrase("IncorrectFloat");
		$this->fields['serviceFeeToCustomerbk2amt'] = &$this->serviceFeeToCustomerbk2amt;

		// serviceFeeToCustomerbk2type
		$this->serviceFeeToCustomerbk2type = new DbField('vvcctransactions', 'vvcctransactions', 'x_serviceFeeToCustomerbk2type', 'serviceFeeToCustomerbk2type', '`serviceFeeToCustomerbk2type`', '`serviceFeeToCustomerbk2type`', 200, 15, -1, FALSE, '`serviceFeeToCustomerbk2type`', FALSE, FALSE, FALSE, 'FORMATTED TEXT', 'TEXT');
		$this->serviceFeeToCustomerbk2type->Sortable = TRUE; // Allow sort
		$this->fields['serviceFeeToCustomerbk2type'] = &$this->serviceFeeToCustomerbk2type;

		// serviceFeeToCustomerbk3type
		$this->serviceFeeToCustomerbk3type = new DbField('vvcctransactions', 'vvcctransactions', 'x_serviceFeeToCustomerbk3type', 'serviceFeeToCustomerbk3type', '`serviceFeeToCustomerbk3type`', '`serviceFeeToCustomerbk3type`', 200, 15, -1, FALSE, '`serviceFeeToCustomerbk3type`', FALSE, FALSE, FALSE, 'FORMATTED TEXT', 'TEXT');
		$this->serviceFeeToCustomerbk3type->Sortable = TRUE; // Allow sort
		$this->fields['serviceFeeToCustomerbk3type'] = &$this->serviceFeeToCustomerbk3type;

		// serviceFeeToCustomerbk3amt
		$this->serviceFeeToCustomerbk3amt = new DbField('vvcctransactions', 'vvcctransactions', 'x_serviceFeeToCustomerbk3amt', 'serviceFeeToCustomerbk3amt', '`serviceFeeToCustomerbk3amt`', '`serviceFeeToCustomerbk3amt`', 131, 20, -1, FALSE, '`serviceFeeToCustomerbk3amt`', FALSE, FALSE, FALSE, 'FORMATTED TEXT', 'TEXT');
		$this->serviceFeeToCustomerbk3amt->Nullable = FALSE; // NOT NULL field
		$this->serviceFeeToCustomerbk3amt->Sortable = TRUE; // Allow sort
		$this->serviceFeeToCustomerbk3amt->DefaultErrorMessage = $Language->phrase("IncorrectFloat");
		$this->fields['serviceFeeToCustomerbk3amt'] = &$this->serviceFeeToCustomerbk3amt;

		// taxAmountbk1amt
		$this->taxAmountbk1amt = new DbField('vvcctransactions', 'vvcctransactions', 'x_taxAmountbk1amt', 'taxAmountbk1amt', '`taxAmountbk1amt`', '`taxAmountbk1amt`', 131, 20, -1, FALSE, '`taxAmountbk1amt`', FALSE, FALSE, FALSE, 'FORMATTED TEXT', 'TEXT');
		$this->taxAmountbk1amt->Nullable = FALSE; // NOT NULL field
		$this->taxAmountbk1amt->Sortable = TRUE; // Allow sort
		$this->taxAmountbk1amt->DefaultErrorMessage = $Language->phrase("IncorrectFloat");
		$this->fields['taxAmountbk1amt'] = &$this->taxAmountbk1amt;

		// taxAmountbk1type
		$this->taxAmountbk1type = new DbField('vvcctransactions', 'vvcctransactions', 'x_taxAmountbk1type', 'taxAmountbk1type', '`taxAmountbk1type`', '`taxAmountbk1type`', 200, 15, -1, FALSE, '`taxAmountbk1type`', FALSE, FALSE, FALSE, 'FORMATTED TEXT', 'TEXT');
		$this->taxAmountbk1type->Sortable = TRUE; // Allow sort
		$this->fields['taxAmountbk1type'] = &$this->taxAmountbk1type;

		// taxAmountbk2amt
		$this->taxAmountbk2amt = new DbField('vvcctransactions', 'vvcctransactions', 'x_taxAmountbk2amt', 'taxAmountbk2amt', '`taxAmountbk2amt`', '`taxAmountbk2amt`', 131, 20, -1, FALSE, '`taxAmountbk2amt`', FALSE, FALSE, FALSE, 'FORMATTED TEXT', 'TEXT');
		$this->taxAmountbk2amt->Nullable = FALSE; // NOT NULL field
		$this->taxAmountbk2amt->Sortable = TRUE; // Allow sort
		$this->taxAmountbk2amt->DefaultErrorMessage = $Language->phrase("IncorrectFloat");
		$this->fields['taxAmountbk2amt'] = &$this->taxAmountbk2amt;

		// taxAmountbk2type
		$this->taxAmountbk2type = new DbField('vvcctransactions', 'vvcctransactions', 'x_taxAmountbk2type', 'taxAmountbk2type', '`taxAmountbk2type`', '`taxAmountbk2type`', 200, 15, -1, FALSE, '`taxAmountbk2type`', FALSE, FALSE, FALSE, 'FORMATTED TEXT', 'TEXT');
		$this->taxAmountbk2type->Sortable = TRUE; // Allow sort
		$this->fields['taxAmountbk2type'] = &$this->taxAmountbk2type;

		// taxAmountbk3amt
		$this->taxAmountbk3amt = new DbField('vvcctransactions', 'vvcctransactions', 'x_taxAmountbk3amt', 'taxAmountbk3amt', '`taxAmountbk3amt`', '`taxAmountbk3amt`', 131, 20, -1, FALSE, '`taxAmountbk3amt`', FALSE, FALSE, FALSE, 'FORMATTED TEXT', 'TEXT');
		$this->taxAmountbk3amt->Nullable = FALSE; // NOT NULL field
		$this->taxAmountbk3amt->Sortable = TRUE; // Allow sort
		$this->taxAmountbk3amt->DefaultErrorMessage = $Language->phrase("IncorrectFloat");
		$this->fields['taxAmountbk3amt'] = &$this->taxAmountbk3amt;

		// taxAmountbk3type
		$this->taxAmountbk3type = new DbField('vvcctransactions', 'vvcctransactions', 'x_taxAmountbk3type', 'taxAmountbk3type', '`taxAmountbk3type`', '`taxAmountbk3type`', 200, 15, -1, FALSE, '`taxAmountbk3type`', FALSE, FALSE, FALSE, 'FORMATTED TEXT', 'TEXT');
		$this->taxAmountbk3type->Sortable = TRUE; // Allow sort
		$this->fields['taxAmountbk3type'] = &$this->taxAmountbk3type;
	}

	// Field Visibility
	public function getFieldVisibility($fldParm)
	{
		global $Security;
		return $this->$fldParm->Visible; // Returns original value
	}

	// Set left column class (must be predefined col-*-* classes of Bootstrap grid system)
	function setLeftColumnClass($class)
	{
		if (preg_match('/^col\-(\w+)\-(\d+)$/', $class, $match)) {
			$this->LeftColumnClass = $class . " col-form-label ew-label";
			$this->RightColumnClass = "col-" . $match[1] . "-" . strval(12 - (int)$match[2]);
			$this->OffsetColumnClass = $this->RightColumnClass . " " . str_replace("col-", "offset-", $class);
			$this->TableLeftColumnClass = preg_replace('/^col-\w+-(\d+)$/', "w-col-$1", $class); // Change to w-col-*
		}
	}

	// Single column sort
	public function updateSort(&$fld)
	{
		if ($this->CurrentOrder == $fld->Name) {
			$sortField = $fld->Expression;
			$lastSort = $fld->getSort();
			if ($this->CurrentOrderType == "ASC" || $this->CurrentOrderType == "DESC") {
				$thisSort = $this->CurrentOrderType;
			} else {
				$thisSort = ($lastSort == "ASC") ? "DESC" : "ASC";
			}
			$fld->setSort($thisSort);
			$this->setSessionOrderBy($sortField . " " . $thisSort); // Save to Session
		} else {
			$fld->setSort("");
		}
	}

	// Table level SQL
	public function getSqlFrom() // From
	{
		return ($this->SqlFrom != "") ? $this->SqlFrom : "`vvcctransactions`";
	}
	public function sqlFrom() // For backward compatibility
	{
		return $this->getSqlFrom();
	}
	public function setSqlFrom($v)
	{
		$this->SqlFrom = $v;
	}
	public function getSqlSelect() // Select
	{
		return ($this->SqlSelect != "") ? $this->SqlSelect : "SELECT * FROM " . $this->getSqlFrom();
	}
	public function sqlSelect() // For backward compatibility
	{
		return $this->getSqlSelect();
	}
	public function setSqlSelect($v)
	{
		$this->SqlSelect = $v;
	}
	public function getSqlWhere() // Where
	{
		$where = ($this->SqlWhere != "") ? $this->SqlWhere : "";
		$this->TableFilter = "";
		AddFilter($where, $this->TableFilter);
		return $where;
	}
	public function sqlWhere() // For backward compatibility
	{
		return $this->getSqlWhere();
	}
	public function setSqlWhere($v)
	{
		$this->SqlWhere = $v;
	}
	public function getSqlGroupBy() // Group By
	{
		return ($this->SqlGroupBy != "") ? $this->SqlGroupBy : "";
	}
	public function sqlGroupBy() // For backward compatibility
	{
		return $this->getSqlGroupBy();
	}
	public function setSqlGroupBy($v)
	{
		$this->SqlGroupBy = $v;
	}
	public function getSqlHaving() // Having
	{
		return ($this->SqlHaving != "") ? $this->SqlHaving : "";
	}
	public function sqlHaving() // For backward compatibility
	{
		return $this->getSqlHaving();
	}
	public function setSqlHaving($v)
	{
		$this->SqlHaving = $v;
	}
	public function getSqlOrderBy() // Order By
	{
		return ($this->SqlOrderBy != "") ? $this->SqlOrderBy : "";
	}
	public function sqlOrderBy() // For backward compatibility
	{
		return $this->getSqlOrderBy();
	}
	public function setSqlOrderBy($v)
	{
		$this->SqlOrderBy = $v;
	}

	// Apply User ID filters
	public function applyUserIDFilters($filter, $id = "")
	{
		return $filter;
	}

	// Check if User ID security allows view all
	public function userIDAllow($id = "")
	{
		$allow = $this->UserIDAllowSecurity;
		switch ($id) {
			case "add":
			case "copy":
			case "gridadd":
			case "register":
			case "addopt":
				return (($allow & 1) == 1);
			case "edit":
			case "gridedit":
			case "update":
			case "changepwd":
			case "forgotpwd":
				return (($allow & 4) == 4);
			case "delete":
				return (($allow & 2) == 2);
			case "view":
				return (($allow & 32) == 32);
			case "search":
				return (($allow & 64) == 64);
			case "lookup":
				return (($allow & 256) == 256);
			default:
				return (($allow & 8) == 8);
		}
	}

	// Get recordset
	public function getRecordset($sql, $rowcnt = -1, $offset = -1)
	{
		$conn = $this->getConnection();
		$conn->raiseErrorFn = Config("ERROR_FUNC");
		$rs = $conn->selectLimit($sql, $rowcnt, $offset);
		$conn->raiseErrorFn = "";
		return $rs;
	}

	// Get record count
	public function getRecordCount($sql, $c = NULL)
	{
		$cnt = -1;
		$rs = NULL;
		$sql = preg_replace('/\/\*BeginOrderBy\*\/[\s\S]+\/\*EndOrderBy\*\//', "", $sql); // Remove ORDER BY clause (MSSQL)
		$pattern = '/^SELECT\s([\s\S]+)\sFROM\s/i';

		// Skip Custom View / SubQuery / SELECT DISTINCT / ORDER BY
		if (($this->TableType == 'TABLE' || $this->TableType == 'VIEW' || $this->TableType == 'LINKTABLE') &&
			preg_match($pattern, $sql) && !preg_match('/\(\s*(SELECT[^)]+)\)/i', $sql) &&
			!preg_match('/^\s*select\s+distinct\s+/i', $sql) && !preg_match('/\s+order\s+by\s+/i', $sql)) {
			$sqlwrk = "SELECT COUNT(*) FROM " . preg_replace($pattern, "", $sql);
		} else {
			$sqlwrk = "SELECT COUNT(*) FROM (" . $sql . ") COUNT_TABLE";
		}
		$conn = $c ?: $this->getConnection();
		if ($rs = $conn->execute($sqlwrk)) {
			if (!$rs->EOF && $rs->FieldCount() > 0) {
				$cnt = $rs->fields[0];
				$rs->close();
			}
			return (int)$cnt;
		}

		// Unable to get count, get record count directly
		if ($rs = $conn->execute($sql)) {
			$cnt = $rs->RecordCount();
			$rs->close();
			return (int)$cnt;
		}
		return $cnt;
	}

	// Get SQL
	public function getSql($where, $orderBy = "")
	{
		return BuildSelectSql($this->getSqlSelect(), $this->getSqlWhere(),
			$this->getSqlGroupBy(), $this->getSqlHaving(), $this->getSqlOrderBy(),
			$where, $orderBy);
	}

	// Table SQL
	public function getCurrentSql()
	{
		$filter = $this->CurrentFilter;
		$filter = $this->applyUserIDFilters($filter);
		$sort = $this->getSessionOrderBy();
		return $this->getSql($filter, $sort);
	}

	// Table SQL with List page filter
	public function getListSql()
	{
		$filter = $this->UseSessionForListSql ? $this->getSessionWhere() : "";
		AddFilter($filter, $this->CurrentFilter);
		$filter = $this->applyUserIDFilters($filter);
		$this->Recordset_Selecting($filter);
		$select = $this->getSqlSelect();
		$sort = $this->UseSessionForListSql ? $this->getSessionOrderBy() : "";
		return BuildSelectSql($select, $this->getSqlWhere(), $this->getSqlGroupBy(),
			$this->getSqlHaving(), $this->getSqlOrderBy(), $filter, $sort);
	}

	// Get ORDER BY clause
	public function getOrderBy()
	{
		$sort = $this->getSessionOrderBy();
		return BuildSelectSql("", "", "", "", $this->getSqlOrderBy(), "", $sort);
	}

	// Get record count based on filter (for detail record count in master table pages)
	public function loadRecordCount($filter)
	{
		$origFilter = $this->CurrentFilter;
		$this->CurrentFilter = $filter;
		$this->Recordset_Selecting($this->CurrentFilter);
		$select = $this->TableType == 'CUSTOMVIEW' ? $this->getSqlSelect() : "SELECT * FROM " . $this->getSqlFrom();
		$groupBy = $this->TableType == 'CUSTOMVIEW' ? $this->getSqlGroupBy() : "";
		$having = $this->TableType == 'CUSTOMVIEW' ? $this->getSqlHaving() : "";
		$sql = BuildSelectSql($select, $this->getSqlWhere(), $groupBy, $having, "", $this->CurrentFilter, "");
		$cnt = $this->getRecordCount($sql);
		$this->CurrentFilter = $origFilter;
		return $cnt;
	}

	// Get record count (for current List page)
	public function listRecordCount()
	{
		$filter = $this->getSessionWhere();
		AddFilter($filter, $this->CurrentFilter);
		$filter = $this->applyUserIDFilters($filter);
		$this->Recordset_Selecting($filter);
		$select = $this->TableType == 'CUSTOMVIEW' ? $this->getSqlSelect() : "SELECT * FROM " . $this->getSqlFrom();
		$groupBy = $this->TableType == 'CUSTOMVIEW' ? $this->getSqlGroupBy() : "";
		$having = $this->TableType == 'CUSTOMVIEW' ? $this->getSqlHaving() : "";
		$sql = BuildSelectSql($select, $this->getSqlWhere(), $groupBy, $having, "", $filter, "");
		$cnt = $this->getRecordCount($sql);
		return $cnt;
	}

	// INSERT statement
	protected function insertSql(&$rs)
	{
		$names = "";
		$values = "";
		foreach ($rs as $name => $value) {
			if (!isset($this->fields[$name]) || $this->fields[$name]->IsCustom)
				continue;
			$names .= $this->fields[$name]->Expression . ",";
			$values .= QuotedValue($value, $this->fields[$name]->DataType, $this->Dbid) . ",";
		}
		$names = preg_replace('/,+$/', "", $names);
		$values = preg_replace('/,+$/', "", $values);
		return "INSERT INTO " . $this->UpdateTable . " (" . $names . ") VALUES (" . $values . ")";
	}

	// Insert
	public function insert(&$rs)
	{
		$conn = $this->getConnection();
		$success = $conn->execute($this->insertSql($rs));
		if ($success) {

			// Get insert id if necessary
			$this->id->setDbValue($conn->insert_ID());
			$rs['id'] = $this->id->DbValue;
		}
		return $success;
	}

	// UPDATE statement
	protected function updateSql(&$rs, $where = "", $curfilter = TRUE)
	{
		$sql = "UPDATE " . $this->UpdateTable . " SET ";
		foreach ($rs as $name => $value) {
			if (!isset($this->fields[$name]) || $this->fields[$name]->IsCustom || $this->fields[$name]->IsAutoIncrement)
				continue;
			$sql .= $this->fields[$name]->Expression . "=";
			$sql .= QuotedValue($value, $this->fields[$name]->DataType, $this->Dbid) . ",";
		}
		$sql = preg_replace('/,+$/', "", $sql);
		$filter = ($curfilter) ? $this->CurrentFilter : "";
		if (is_array($where))
			$where = $this->arrayToFilter($where);
		AddFilter($filter, $where);
		if ($filter != "")
			$sql .= " WHERE " . $filter;
		return $sql;
	}

	// Update
	public function update(&$rs, $where = "", $rsold = NULL, $curfilter = TRUE)
	{
		$conn = $this->getConnection();
		$success = $conn->execute($this->updateSql($rs, $where, $curfilter));
		return $success;
	}

	// DELETE statement
	protected function deleteSql(&$rs, $where = "", $curfilter = TRUE)
	{
		$sql = "DELETE FROM " . $this->UpdateTable . " WHERE ";
		if (is_array($where))
			$where = $this->arrayToFilter($where);
		if ($rs) {
			if (array_key_exists('id', $rs))
				AddFilter($where, QuotedName('id', $this->Dbid) . '=' . QuotedValue($rs['id'], $this->id->DataType, $this->Dbid));
			if (array_key_exists('txid', $rs))
				AddFilter($where, QuotedName('txid', $this->Dbid) . '=' . QuotedValue($rs['txid'], $this->txid->DataType, $this->Dbid));
		}
		$filter = ($curfilter) ? $this->CurrentFilter : "";
		AddFilter($filter, $where);
		if ($filter != "")
			$sql .= $filter;
		else
			$sql .= "0=1"; // Avoid delete
		return $sql;
	}

	// Delete
	public function delete(&$rs, $where = "", $curfilter = FALSE)
	{
		$success = TRUE;
		$conn = $this->getConnection();
		if ($success)
			$success = $conn->execute($this->deleteSql($rs, $where, $curfilter));
		return $success;
	}

	// Load DbValue from recordset or array
	protected function loadDbValues(&$rs)
	{
		if (!$rs || !is_array($rs) && $rs->EOF)
			return;
		$row = is_array($rs) ? $rs : $rs->fields;
		$this->id->DbValue = $row['id'];
		$this->datecreated->DbValue = $row['datecreated'];
		$this->brokerid->DbValue = $row['brokerid'];
		$this->requestorid->DbValue = $row['requestorid'];
		$this->requestor4payuser->DbValue = $row['requestor4payuser'];
		$this->recipientid->DbValue = $row['recipientid'];
		$this->recipient4payuser->DbValue = $row['recipient4payuser'];
		$this->refno1->DbValue = $row['refno1'];
		$this->refno2->DbValue = $row['refno2'];
		$this->saleid->DbValue = $row['saleid'];
		$this->operatorid->DbValue = $row['operatorid'];
		$this->txid->DbValue = $row['txid'];
		$this->merchantID->DbValue = $row['merchantID'];
		$this->_userID->DbValue = $row['userID'];
		$this->transferTime->DbValue = $row['transferTime'];
		$this->merchantSurcharge->DbValue = $row['merchantSurcharge'];
		$this->currID->DbValue = $row['currID'];
		$this->purchaseAmount->DbValue = $row['purchaseAmount'];
		$this->taxAmount->DbValue = $row['taxAmount'];
		$this->tipAmount->DbValue = $row['tipAmount'];
		$this->serviceFeeToCustomer->DbValue = $row['serviceFeeToCustomer'];
		$this->TotalAmountForCustomer->DbValue = $row['TotalAmountForCustomer'];
		$this->serviceFeeToMerchant->DbValue = $row['serviceFeeToMerchant'];
		$this->status->DbValue = $row['status'];
		$this->shoppingCartID->DbValue = $row['shoppingCartID'];
		$this->merchantRefID->DbValue = $row['merchantRefID'];
		$this->feeid->DbValue = $row['feeid'];
		$this->ratetabletype->DbValue = $row['ratetabletype'];
		$this->pis->DbValue = $row['pis'];
		$this->feesystemshare->DbValue = $row['feesystemshare'];
		$this->feeexternalshare->DbValue = $row['feeexternalshare'];
		$this->feeresellershare->DbValue = $row['feeresellershare'];
		$this->lastupdatetime->DbValue = $row['lastupdatetime'];
		$this->expirationTimeInMinutes->DbValue = $row['expirationTimeInMinutes'];
		$this->expirationTime->DbValue = $row['expirationTime'];
		$this->customeruserid->DbValue = $row['customeruserid'];
		$this->piname->DbValue = $row['piname'];
		$this->branchname->DbValue = $row['branchname'];
		$this->operatorname->DbValue = $row['operatorname'];
		$this->customerusername->DbValue = $row['customerusername'];
		$this->feefranchiseeshare->DbValue = $row['feefranchiseeshare'];
		$this->serviceFeeToCustomerbk1amt->DbValue = $row['serviceFeeToCustomerbk1amt'];
		$this->serviceFeeToCustomerbk1type->DbValue = $row['serviceFeeToCustomerbk1type'];
		$this->serviceFeeToCustomerbk2amt->DbValue = $row['serviceFeeToCustomerbk2amt'];
		$this->serviceFeeToCustomerbk2type->DbValue = $row['serviceFeeToCustomerbk2type'];
		$this->serviceFeeToCustomerbk3type->DbValue = $row['serviceFeeToCustomerbk3type'];
		$this->serviceFeeToCustomerbk3amt->DbValue = $row['serviceFeeToCustomerbk3amt'];
		$this->taxAmountbk1amt->DbValue = $row['taxAmountbk1amt'];
		$this->taxAmountbk1type->DbValue = $row['taxAmountbk1type'];
		$this->taxAmountbk2amt->DbValue = $row['taxAmountbk2amt'];
		$this->taxAmountbk2type->DbValue = $row['taxAmountbk2type'];
		$this->taxAmountbk3amt->DbValue = $row['taxAmountbk3amt'];
		$this->taxAmountbk3type->DbValue = $row['taxAmountbk3type'];
	}

	// Delete uploaded files
	public function deleteUploadedFiles($row)
	{
		$this->loadDbValues($row);
	}

	// Record filter WHERE clause
	protected function sqlKeyFilter()
	{
		return "`id` = @id@ AND `txid` = '@txid@'";
	}

	// Get record filter
	public function getRecordFilter($row = NULL)
	{
		$keyFilter = $this->sqlKeyFilter();
		if (is_array($row))
			$val = array_key_exists('id', $row) ? $row['id'] : NULL;
		else
			$val = $this->id->OldValue !== NULL ? $this->id->OldValue : $this->id->CurrentValue;
		if (!is_numeric($val))
			return "0=1"; // Invalid key
		if ($val == NULL)
			return "0=1"; // Invalid key
		else
			$keyFilter = str_replace("@id@", AdjustSql($val, $this->Dbid), $keyFilter); // Replace key value
		if (is_array($row))
			$val = array_key_exists('txid', $row) ? $row['txid'] : NULL;
		else
			$val = $this->txid->OldValue !== NULL ? $this->txid->OldValue : $this->txid->CurrentValue;
		if ($val == NULL)
			return "0=1"; // Invalid key
		else
			$keyFilter = str_replace("@txid@", AdjustSql($val, $this->Dbid), $keyFilter); // Replace key value
		return $keyFilter;
	}

	// Return page URL
	public function getReturnUrl()
	{
		$name = PROJECT_NAME . "_" . $this->TableVar . "_" . Config("TABLE_RETURN_URL");

		// Get referer URL automatically
		if (ServerVar("HTTP_REFERER") != "" && ReferPageName() != CurrentPageName() && ReferPageName() != "login.php") // Referer not same page or login page
			$_SESSION[$name] = ServerVar("HTTP_REFERER"); // Save to Session
		if (@$_SESSION[$name] != "") {
			return $_SESSION[$name];
		} else {
			return "vvcctransactionslist.php";
		}
	}
	public function setReturnUrl($v)
	{
		$_SESSION[PROJECT_NAME . "_" . $this->TableVar . "_" . Config("TABLE_RETURN_URL")] = $v;
	}

	// Get modal caption
	public function getModalCaption($pageName)
	{
		global $Language;
		if ($pageName == "vvcctransactionsview.php")
			return $Language->phrase("View");
		elseif ($pageName == "vvcctransactionsedit.php")
			return $Language->phrase("Edit");
		elseif ($pageName == "vvcctransactionsadd.php")
			return $Language->phrase("Add");
		else
			return "";
	}

	// List URL
	public function getListUrl()
	{
		return "vvcctransactionslist.php";
	}

	// View URL
	public function getViewUrl($parm = "")
	{
		if ($parm != "")
			$url = $this->keyUrl("vvcctransactionsview.php", $this->getUrlParm($parm));
		else
			$url = $this->keyUrl("vvcctransactionsview.php", $this->getUrlParm(Config("TABLE_SHOW_DETAIL") . "="));
		return $this->addMasterUrl($url);
	}

	// Add URL
	public function getAddUrl($parm = "")
	{
		if ($parm != "")
			$url = "vvcctransactionsadd.php?" . $this->getUrlParm($parm);
		else
			$url = "vvcctransactionsadd.php";
		return $this->addMasterUrl($url);
	}

	// Edit URL
	public function getEditUrl($parm = "")
	{
		$url = $this->keyUrl("vvcctransactionsedit.php", $this->getUrlParm($parm));
		return $this->addMasterUrl($url);
	}

	// Inline edit URL
	public function getInlineEditUrl()
	{
		$url = $this->keyUrl(CurrentPageName(), $this->getUrlParm("action=edit"));
		return $this->addMasterUrl($url);
	}

	// Copy URL
	public function getCopyUrl($parm = "")
	{
		$url = $this->keyUrl("vvcctransactionsadd.php", $this->getUrlParm($parm));
		return $this->addMasterUrl($url);
	}

	// Inline copy URL
	public function getInlineCopyUrl()
	{
		$url = $this->keyUrl(CurrentPageName(), $this->getUrlParm("action=copy"));
		return $this->addMasterUrl($url);
	}

	// Delete URL
	public function getDeleteUrl()
	{
		return $this->keyUrl("vvcctransactionsdelete.php", $this->getUrlParm());
	}

	// Add master url
	public function addMasterUrl($url)
	{
		return $url;
	}
	public function keyToJson($htmlEncode = FALSE)
	{
		$json = "";
		$json .= "id:" . JsonEncode($this->id->CurrentValue, "number");
		$json .= ",txid:" . JsonEncode($this->txid->CurrentValue, "string");
		$json = "{" . $json . "}";
		if ($htmlEncode)
			$json = HtmlEncode($json);
		return $json;
	}

	// Add key value to URL
	public function keyUrl($url, $parm = "")
	{
		$url = $url . "?";
		if ($parm != "")
			$url .= $parm . "&";
		if ($this->id->CurrentValue != NULL) {
			$url .= "id=" . urlencode($this->id->CurrentValue);
		} else {
			return "javascript:ew.alert(ew.language.phrase('InvalidRecord'));";
		}
		if ($this->txid->CurrentValue != NULL) {
			$url .= "&txid=" . urlencode($this->txid->CurrentValue);
		} else {
			return "javascript:ew.alert(ew.language.phrase('InvalidRecord'));";
		}
		return $url;
	}

	// Sort URL
	public function sortUrl(&$fld)
	{
		if ($this->CurrentAction || $this->isExport() ||
			in_array($fld->Type, [128, 204, 205])) { // Unsortable data type
				return "";
		} elseif ($fld->Sortable) {
			$urlParm = $this->getUrlParm("order=" . urlencode($fld->Name) . "&amp;ordertype=" . $fld->reverseSort());
			return $this->addMasterUrl(CurrentPageName() . "?" . $urlParm);
		} else {
			return "";
		}
	}

	// Get record keys from Post/Get/Session
	public function getRecordKeys()
	{
		$arKeys = [];
		$arKey = [];
		if (Param("key_m") !== NULL) {
			$arKeys = Param("key_m");
			$cnt = count($arKeys);
			for ($i = 0; $i < $cnt; $i++)
				$arKeys[$i] = explode(Config("COMPOSITE_KEY_SEPARATOR"), $arKeys[$i]);
		} else {
			if (Param("id") !== NULL)
				$arKey[] = Param("id");
			elseif (IsApi() && Key(0) !== NULL)
				$arKey[] = Key(0);
			elseif (IsApi() && Route(2) !== NULL)
				$arKey[] = Route(2);
			else
				$arKeys = NULL; // Do not setup
			if (Param("txid") !== NULL)
				$arKey[] = Param("txid");
			elseif (IsApi() && Key(1) !== NULL)
				$arKey[] = Key(1);
			elseif (IsApi() && Route(3) !== NULL)
				$arKey[] = Route(3);
			else
				$arKeys = NULL; // Do not setup
			if (is_array($arKeys)) $arKeys[] = $arKey;

			//return $arKeys; // Do not return yet, so the values will also be checked by the following code
		}

		// Check keys
		$ar = [];
		if (is_array($arKeys)) {
			foreach ($arKeys as $key) {
				if (!is_array($key) || count($key) != 2)
					continue; // Just skip so other keys will still work
				if (!is_numeric($key[0])) // id
					continue;
				$ar[] = $key;
			}
		}
		return $ar;
	}

	// Get filter from record keys
	public function getFilterFromRecordKeys($setCurrent = TRUE)
	{
		$arKeys = $this->getRecordKeys();
		$keyFilter = "";
		foreach ($arKeys as $key) {
			if ($keyFilter != "") $keyFilter .= " OR ";
			if ($setCurrent)
				$this->id->CurrentValue = $key[0];
			else
				$this->id->OldValue = $key[0];
			if ($setCurrent)
				$this->txid->CurrentValue = $key[1];
			else
				$this->txid->OldValue = $key[1];
			$keyFilter .= "(" . $this->getRecordFilter() . ")";
		}
		return $keyFilter;
	}

	// Load rows based on filter
	public function &loadRs($filter)
	{

		// Set up filter (WHERE Clause)
		$sql = $this->getSql($filter);
		$conn = $this->getConnection();
		$rs = $conn->execute($sql);
		return $rs;
	}

	// Load row values from recordset
	public function loadListRowValues(&$rs)
	{
		$this->id->setDbValue($rs->fields('id'));
		$this->datecreated->setDbValue($rs->fields('datecreated'));
		$this->brokerid->setDbValue($rs->fields('brokerid'));
		$this->requestorid->setDbValue($rs->fields('requestorid'));
		$this->requestor4payuser->setDbValue($rs->fields('requestor4payuser'));
		$this->recipientid->setDbValue($rs->fields('recipientid'));
		$this->recipient4payuser->setDbValue($rs->fields('recipient4payuser'));
		$this->refno1->setDbValue($rs->fields('refno1'));
		$this->refno2->setDbValue($rs->fields('refno2'));
		$this->saleid->setDbValue($rs->fields('saleid'));
		$this->operatorid->setDbValue($rs->fields('operatorid'));
		$this->txid->setDbValue($rs->fields('txid'));
		$this->merchantID->setDbValue($rs->fields('merchantID'));
		$this->_userID->setDbValue($rs->fields('userID'));
		$this->transferTime->setDbValue($rs->fields('transferTime'));
		$this->merchantSurcharge->setDbValue($rs->fields('merchantSurcharge'));
		$this->currID->setDbValue($rs->fields('currID'));
		$this->purchaseAmount->setDbValue($rs->fields('purchaseAmount'));
		$this->taxAmount->setDbValue($rs->fields('taxAmount'));
		$this->tipAmount->setDbValue($rs->fields('tipAmount'));
		$this->serviceFeeToCustomer->setDbValue($rs->fields('serviceFeeToCustomer'));
		$this->TotalAmountForCustomer->setDbValue($rs->fields('TotalAmountForCustomer'));
		$this->serviceFeeToMerchant->setDbValue($rs->fields('serviceFeeToMerchant'));
		$this->status->setDbValue($rs->fields('status'));
		$this->shoppingCartID->setDbValue($rs->fields('shoppingCartID'));
		$this->merchantRefID->setDbValue($rs->fields('merchantRefID'));
		$this->feeid->setDbValue($rs->fields('feeid'));
		$this->ratetabletype->setDbValue($rs->fields('ratetabletype'));
		$this->pis->setDbValue($rs->fields('pis'));
		$this->feesystemshare->setDbValue($rs->fields('feesystemshare'));
		$this->feeexternalshare->setDbValue($rs->fields('feeexternalshare'));
		$this->feeresellershare->setDbValue($rs->fields('feeresellershare'));
		$this->lastupdatetime->setDbValue($rs->fields('lastupdatetime'));
		$this->expirationTimeInMinutes->setDbValue($rs->fields('expirationTimeInMinutes'));
		$this->expirationTime->setDbValue($rs->fields('expirationTime'));
		$this->customeruserid->setDbValue($rs->fields('customeruserid'));
		$this->piname->setDbValue($rs->fields('piname'));
		$this->branchname->setDbValue($rs->fields('branchname'));
		$this->operatorname->setDbValue($rs->fields('operatorname'));
		$this->customerusername->setDbValue($rs->fields('customerusername'));
		$this->feefranchiseeshare->setDbValue($rs->fields('feefranchiseeshare'));
		$this->serviceFeeToCustomerbk1amt->setDbValue($rs->fields('serviceFeeToCustomerbk1amt'));
		$this->serviceFeeToCustomerbk1type->setDbValue($rs->fields('serviceFeeToCustomerbk1type'));
		$this->serviceFeeToCustomerbk2amt->setDbValue($rs->fields('serviceFeeToCustomerbk2amt'));
		$this->serviceFeeToCustomerbk2type->setDbValue($rs->fields('serviceFeeToCustomerbk2type'));
		$this->serviceFeeToCustomerbk3type->setDbValue($rs->fields('serviceFeeToCustomerbk3type'));
		$this->serviceFeeToCustomerbk3amt->setDbValue($rs->fields('serviceFeeToCustomerbk3amt'));
		$this->taxAmountbk1amt->setDbValue($rs->fields('taxAmountbk1amt'));
		$this->taxAmountbk1type->setDbValue($rs->fields('taxAmountbk1type'));
		$this->taxAmountbk2amt->setDbValue($rs->fields('taxAmountbk2amt'));
		$this->taxAmountbk2type->setDbValue($rs->fields('taxAmountbk2type'));
		$this->taxAmountbk3amt->setDbValue($rs->fields('taxAmountbk3amt'));
		$this->taxAmountbk3type->setDbValue($rs->fields('taxAmountbk3type'));
	}

	// Render list row values
	public function renderListRow()
	{
		global $Security, $CurrentLanguage, $Language;

		// Call Row Rendering event
		$this->Row_Rendering();

		// Common render codes
		// id
		// datecreated
		// brokerid
		// requestorid
		// requestor4payuser
		// recipientid
		// recipient4payuser
		// refno1
		// refno2
		// saleid
		// operatorid
		// txid
		// merchantID
		// userID
		// transferTime
		// merchantSurcharge
		// currID
		// purchaseAmount
		// taxAmount
		// tipAmount
		// serviceFeeToCustomer
		// TotalAmountForCustomer
		// serviceFeeToMerchant
		// status
		// shoppingCartID
		// merchantRefID
		// feeid
		// ratetabletype
		// pis
		// feesystemshare
		// feeexternalshare
		// feeresellershare
		// lastupdatetime
		// expirationTimeInMinutes
		// expirationTime
		// customeruserid
		// piname
		// branchname
		// operatorname
		// customerusername
		// feefranchiseeshare
		// serviceFeeToCustomerbk1amt
		// serviceFeeToCustomerbk1type
		// serviceFeeToCustomerbk2amt
		// serviceFeeToCustomerbk2type
		// serviceFeeToCustomerbk3type
		// serviceFeeToCustomerbk3amt
		// taxAmountbk1amt
		// taxAmountbk1type
		// taxAmountbk2amt
		// taxAmountbk2type
		// taxAmountbk3amt
		// taxAmountbk3type
		// id

		$this->id->ViewValue = $this->id->CurrentValue;
		$this->id->ViewCustomAttributes = "";

		// datecreated
		$this->datecreated->ViewValue = $this->datecreated->CurrentValue;
		$this->datecreated->ViewValue = FormatDateTime($this->datecreated->ViewValue, 0);
		$this->datecreated->ViewCustomAttributes = "";

		// brokerid
		$this->brokerid->ViewValue = $this->brokerid->CurrentValue;
		$this->brokerid->ViewCustomAttributes = "";

		// requestorid
		$this->requestorid->ViewValue = $this->requestorid->CurrentValue;
		$this->requestorid->ViewValue = FormatNumber($this->requestorid->ViewValue, 0, -2, -2, -2);
		$this->requestorid->ViewCustomAttributes = "";

		// requestor4payuser
		$this->requestor4payuser->ViewValue = $this->requestor4payuser->CurrentValue;
		$this->requestor4payuser->ViewValue = FormatNumber($this->requestor4payuser->ViewValue, 0, -2, -2, -2);
		$this->requestor4payuser->ViewCustomAttributes = "";

		// recipientid
		$this->recipientid->ViewValue = $this->recipientid->CurrentValue;
		$this->recipientid->ViewValue = FormatNumber($this->recipientid->ViewValue, 0, -2, -2, -2);
		$this->recipientid->ViewCustomAttributes = "";

		// recipient4payuser
		$this->recipient4payuser->ViewValue = $this->recipient4payuser->CurrentValue;
		$this->recipient4payuser->ViewValue = FormatNumber($this->recipient4payuser->ViewValue, 0, -2, -2, -2);
		$this->recipient4payuser->ViewCustomAttributes = "";

		// refno1
		$this->refno1->ViewValue = $this->refno1->CurrentValue;
		$this->refno1->ViewCustomAttributes = "";

		// refno2
		$this->refno2->ViewValue = $this->refno2->CurrentValue;
		$this->refno2->ViewCustomAttributes = "";

		// saleid
		$this->saleid->ViewValue = $this->saleid->CurrentValue;
		$this->saleid->ViewCustomAttributes = "";

		// operatorid
		$this->operatorid->ViewValue = $this->operatorid->CurrentValue;
		$this->operatorid->ViewValue = FormatNumber($this->operatorid->ViewValue, 0, -2, -2, -2);
		$this->operatorid->ViewCustomAttributes = "";

		// txid
		$this->txid->ViewValue = $this->txid->CurrentValue;
		$this->txid->ViewCustomAttributes = "";

		// merchantID
		$this->merchantID->ViewValue = $this->merchantID->CurrentValue;
		$this->merchantID->ViewCustomAttributes = "";

		// userID
		$this->_userID->ViewValue = $this->_userID->CurrentValue;
		$this->_userID->ViewCustomAttributes = "";

		// transferTime
		$this->transferTime->ViewValue = $this->transferTime->CurrentValue;
		$this->transferTime->ViewValue = FormatDateTime($this->transferTime->ViewValue, 0);
		$this->transferTime->ViewCustomAttributes = "";

		// merchantSurcharge
		$this->merchantSurcharge->ViewValue = $this->merchantSurcharge->CurrentValue;
		$this->merchantSurcharge->ViewValue = FormatNumber($this->merchantSurcharge->ViewValue, 2, -2, -2, -2);
		$this->merchantSurcharge->ViewCustomAttributes = "";

		// currID
		$this->currID->ViewValue = $this->currID->CurrentValue;
		$this->currID->ViewCustomAttributes = "";

		// purchaseAmount
		$this->purchaseAmount->ViewValue = $this->purchaseAmount->CurrentValue;
		$this->purchaseAmount->ViewValue = FormatNumber($this->purchaseAmount->ViewValue, 2, -2, -2, -2);
		$this->purchaseAmount->ViewCustomAttributes = "";

		// taxAmount
		$this->taxAmount->ViewValue = $this->taxAmount->CurrentValue;
		$this->taxAmount->ViewValue = FormatNumber($this->taxAmount->ViewValue, 2, -2, -2, -2);
		$this->taxAmount->ViewCustomAttributes = "";

		// tipAmount
		$this->tipAmount->ViewValue = $this->tipAmount->CurrentValue;
		$this->tipAmount->ViewValue = FormatNumber($this->tipAmount->ViewValue, 2, -2, -2, -2);
		$this->tipAmount->ViewCustomAttributes = "";

		// serviceFeeToCustomer
		$this->serviceFeeToCustomer->ViewValue = $this->serviceFeeToCustomer->CurrentValue;
		$this->serviceFeeToCustomer->ViewValue = FormatNumber($this->serviceFeeToCustomer->ViewValue, 2, -2, -2, -2);
		$this->serviceFeeToCustomer->ViewCustomAttributes = "";

		// TotalAmountForCustomer
		$this->TotalAmountForCustomer->ViewValue = $this->TotalAmountForCustomer->CurrentValue;
		$this->TotalAmountForCustomer->ViewValue = FormatNumber($this->TotalAmountForCustomer->ViewValue, 2, -2, -2, -2);
		$this->TotalAmountForCustomer->CellCssStyle .= "text-align: right;";
		$this->TotalAmountForCustomer->ViewCustomAttributes = "";

		// serviceFeeToMerchant
		$this->serviceFeeToMerchant->ViewValue = $this->serviceFeeToMerchant->CurrentValue;
		$this->serviceFeeToMerchant->ViewValue = FormatNumber($this->serviceFeeToMerchant->ViewValue, 2, -2, -2, -2);
		$this->serviceFeeToMerchant->ViewCustomAttributes = "";

		// status
		if (strval($this->status->CurrentValue) != "") {
			$this->status->ViewValue = $this->status->optionCaption($this->status->CurrentValue);
		} else {
			$this->status->ViewValue = NULL;
		}
		$this->status->ViewCustomAttributes = "";

		// shoppingCartID
		$this->shoppingCartID->ViewValue = $this->shoppingCartID->CurrentValue;
		$this->shoppingCartID->ViewCustomAttributes = "";

		// merchantRefID
		$this->merchantRefID->ViewValue = $this->merchantRefID->CurrentValue;
		$this->merchantRefID->ViewCustomAttributes = "";

		// feeid
		$this->feeid->ViewValue = $this->feeid->CurrentValue;
		$this->feeid->ViewValue = FormatNumber($this->feeid->ViewValue, 0, -2, -2, -2);
		$this->feeid->ViewCustomAttributes = "";

		// ratetabletype
		$this->ratetabletype->ViewValue = $this->ratetabletype->CurrentValue;
		$this->ratetabletype->ViewValue = FormatNumber($this->ratetabletype->ViewValue, 0, -2, -2, -2);
		$this->ratetabletype->ViewCustomAttributes = "";

		// pis
		$this->pis->ViewValue = $this->pis->CurrentValue;
		$this->pis->ViewCustomAttributes = "";

		// feesystemshare
		$this->feesystemshare->ViewValue = $this->feesystemshare->CurrentValue;
		$this->feesystemshare->ViewValue = FormatNumber($this->feesystemshare->ViewValue, 2, -2, -2, -2);
		$this->feesystemshare->ViewCustomAttributes = "";

		// feeexternalshare
		$this->feeexternalshare->ViewValue = $this->feeexternalshare->CurrentValue;
		$this->feeexternalshare->ViewValue = FormatNumber($this->feeexternalshare->ViewValue, 2, -2, -2, -2);
		$this->feeexternalshare->ViewCustomAttributes = "";

		// feeresellershare
		$this->feeresellershare->ViewValue = $this->feeresellershare->CurrentValue;
		$this->feeresellershare->ViewValue = FormatNumber($this->feeresellershare->ViewValue, 2, -2, -2, -2);
		$this->feeresellershare->ViewCustomAttributes = "";

		// lastupdatetime
		$this->lastupdatetime->ViewValue = $this->lastupdatetime->CurrentValue;
		$this->lastupdatetime->ViewValue = FormatDateTime($this->lastupdatetime->ViewValue, 0);
		$this->lastupdatetime->ViewCustomAttributes = "";

		// expirationTimeInMinutes
		$this->expirationTimeInMinutes->ViewValue = $this->expirationTimeInMinutes->CurrentValue;
		$this->expirationTimeInMinutes->ViewValue = FormatNumber($this->expirationTimeInMinutes->ViewValue, 0, -2, -2, -2);
		$this->expirationTimeInMinutes->ViewCustomAttributes = "";

		// expirationTime
		$this->expirationTime->ViewValue = $this->expirationTime->CurrentValue;
		$this->expirationTime->ViewValue = FormatDateTime($this->expirationTime->ViewValue, 0);
		$this->expirationTime->ViewCustomAttributes = "";

		// customeruserid
		$this->customeruserid->ViewValue = $this->customeruserid->CurrentValue;
		$this->customeruserid->ViewValue = FormatNumber($this->customeruserid->ViewValue, 0, -2, -2, -2);
		$this->customeruserid->ViewCustomAttributes = "";

		// piname
		$this->piname->ViewValue = $this->piname->CurrentValue;
		$this->piname->ViewCustomAttributes = "";

		// branchname
		$this->branchname->ViewValue = $this->branchname->CurrentValue;
		$this->branchname->ViewCustomAttributes = "";

		// operatorname
		$this->operatorname->ViewValue = $this->operatorname->CurrentValue;
		$this->operatorname->ViewCustomAttributes = "";

		// customerusername
		$this->customerusername->ViewValue = $this->customerusername->CurrentValue;
		$this->customerusername->ViewCustomAttributes = "";

		// feefranchiseeshare
		$this->feefranchiseeshare->ViewValue = $this->feefranchiseeshare->CurrentValue;
		$this->feefranchiseeshare->ViewValue = FormatNumber($this->feefranchiseeshare->ViewValue, 2, -2, -2, -2);
		$this->feefranchiseeshare->ViewCustomAttributes = "";

		// serviceFeeToCustomerbk1amt
		$this->serviceFeeToCustomerbk1amt->ViewValue = $this->serviceFeeToCustomerbk1amt->CurrentValue;
		$this->serviceFeeToCustomerbk1amt->ViewValue = FormatNumber($this->serviceFeeToCustomerbk1amt->ViewValue, 2, -2, -2, -2);
		$this->serviceFeeToCustomerbk1amt->ViewCustomAttributes = "";

		// serviceFeeToCustomerbk1type
		$this->serviceFeeToCustomerbk1type->ViewValue = $this->serviceFeeToCustomerbk1type->CurrentValue;
		$this->serviceFeeToCustomerbk1type->ViewCustomAttributes = "";

		// serviceFeeToCustomerbk2amt
		$this->serviceFeeToCustomerbk2amt->ViewValue = $this->serviceFeeToCustomerbk2amt->CurrentValue;
		$this->serviceFeeToCustomerbk2amt->ViewValue = FormatNumber($this->serviceFeeToCustomerbk2amt->ViewValue, 2, -2, -2, -2);
		$this->serviceFeeToCustomerbk2amt->ViewCustomAttributes = "";

		// serviceFeeToCustomerbk2type
		$this->serviceFeeToCustomerbk2type->ViewValue = $this->serviceFeeToCustomerbk2type->CurrentValue;
		$this->serviceFeeToCustomerbk2type->ViewCustomAttributes = "";

		// serviceFeeToCustomerbk3type
		$this->serviceFeeToCustomerbk3type->ViewValue = $this->serviceFeeToCustomerbk3type->CurrentValue;
		$this->serviceFeeToCustomerbk3type->ViewCustomAttributes = "";

		// serviceFeeToCustomerbk3amt
		$this->serviceFeeToCustomerbk3amt->ViewValue = $this->serviceFeeToCustomerbk3amt->CurrentValue;
		$this->serviceFeeToCustomerbk3amt->ViewValue = FormatNumber($this->serviceFeeToCustomerbk3amt->ViewValue, 2, -2, -2, -2);
		$this->serviceFeeToCustomerbk3amt->ViewCustomAttributes = "";

		// taxAmountbk1amt
		$this->taxAmountbk1amt->ViewValue = $this->taxAmountbk1amt->CurrentValue;
		$this->taxAmountbk1amt->ViewValue = FormatNumber($this->taxAmountbk1amt->ViewValue, 2, -2, -2, -2);
		$this->taxAmountbk1amt->ViewCustomAttributes = "";

		// taxAmountbk1type
		$this->taxAmountbk1type->ViewValue = $this->taxAmountbk1type->CurrentValue;
		$this->taxAmountbk1type->ViewCustomAttributes = "";

		// taxAmountbk2amt
		$this->taxAmountbk2amt->ViewValue = $this->taxAmountbk2amt->CurrentValue;
		$this->taxAmountbk2amt->ViewValue = FormatNumber($this->taxAmountbk2amt->ViewValue, 2, -2, -2, -2);
		$this->taxAmountbk2amt->ViewCustomAttributes = "";

		// taxAmountbk2type
		$this->taxAmountbk2type->ViewValue = $this->taxAmountbk2type->CurrentValue;
		$this->taxAmountbk2type->ViewCustomAttributes = "";

		// taxAmountbk3amt
		$this->taxAmountbk3amt->ViewValue = $this->taxAmountbk3amt->CurrentValue;
		$this->taxAmountbk3amt->ViewValue = FormatNumber($this->taxAmountbk3amt->ViewValue, 2, -2, -2, -2);
		$this->taxAmountbk3amt->ViewCustomAttributes = "";

		// taxAmountbk3type
		$this->taxAmountbk3type->ViewValue = $this->taxAmountbk3type->CurrentValue;
		$this->taxAmountbk3type->ViewCustomAttributes = "";

		// id
		$this->id->LinkCustomAttributes = "";
		$this->id->HrefValue = "";
		$this->id->TooltipValue = "";

		// datecreated
		$this->datecreated->LinkCustomAttributes = "";
		$this->datecreated->HrefValue = "";
		$this->datecreated->TooltipValue = "";

		// brokerid
		$this->brokerid->LinkCustomAttributes = "";
		$this->brokerid->HrefValue = "";
		$this->brokerid->TooltipValue = "";

		// requestorid
		$this->requestorid->LinkCustomAttributes = "";
		$this->requestorid->HrefValue = "";
		$this->requestorid->TooltipValue = "";

		// requestor4payuser
		$this->requestor4payuser->LinkCustomAttributes = "";
		$this->requestor4payuser->HrefValue = "";
		$this->requestor4payuser->TooltipValue = "";

		// recipientid
		$this->recipientid->LinkCustomAttributes = "";
		$this->recipientid->HrefValue = "";
		$this->recipientid->TooltipValue = "";

		// recipient4payuser
		$this->recipient4payuser->LinkCustomAttributes = "";
		$this->recipient4payuser->HrefValue = "";
		$this->recipient4payuser->TooltipValue = "";

		// refno1
		$this->refno1->LinkCustomAttributes = "";
		$this->refno1->HrefValue = "";
		$this->refno1->TooltipValue = "";

		// refno2
		$this->refno2->LinkCustomAttributes = "";
		$this->refno2->HrefValue = "";
		$this->refno2->TooltipValue = "";

		// saleid
		$this->saleid->LinkCustomAttributes = "";
		$this->saleid->HrefValue = "";
		$this->saleid->TooltipValue = "";

		// operatorid
		$this->operatorid->LinkCustomAttributes = "";
		$this->operatorid->HrefValue = "";
		$this->operatorid->TooltipValue = "";

		// txid
		$this->txid->LinkCustomAttributes = "";
		$this->txid->HrefValue = "";
		$this->txid->TooltipValue = "";

		// merchantID
		$this->merchantID->LinkCustomAttributes = "";
		$this->merchantID->HrefValue = "";
		$this->merchantID->TooltipValue = "";

		// userID
		$this->_userID->LinkCustomAttributes = "";
		$this->_userID->HrefValue = "";
		$this->_userID->TooltipValue = "";

		// transferTime
		$this->transferTime->LinkCustomAttributes = "";
		$this->transferTime->HrefValue = "";
		$this->transferTime->TooltipValue = "";

		// merchantSurcharge
		$this->merchantSurcharge->LinkCustomAttributes = "";
		$this->merchantSurcharge->HrefValue = "";
		$this->merchantSurcharge->TooltipValue = "";

		// currID
		$this->currID->LinkCustomAttributes = "";
		$this->currID->HrefValue = "";
		$this->currID->TooltipValue = "";

		// purchaseAmount
		$this->purchaseAmount->LinkCustomAttributes = "";
		$this->purchaseAmount->HrefValue = "";
		$this->purchaseAmount->TooltipValue = "";

		// taxAmount
		$this->taxAmount->LinkCustomAttributes = "";
		$this->taxAmount->HrefValue = "";
		$this->taxAmount->TooltipValue = "";

		// tipAmount
		$this->tipAmount->LinkCustomAttributes = "";
		$this->tipAmount->HrefValue = "";
		$this->tipAmount->TooltipValue = "";

		// serviceFeeToCustomer
		$this->serviceFeeToCustomer->LinkCustomAttributes = "";
		$this->serviceFeeToCustomer->HrefValue = "";
		$this->serviceFeeToCustomer->TooltipValue = "";

		// TotalAmountForCustomer
		$this->TotalAmountForCustomer->LinkCustomAttributes = "";
		$this->TotalAmountForCustomer->HrefValue = "";
		$this->TotalAmountForCustomer->TooltipValue = "";

		// serviceFeeToMerchant
		$this->serviceFeeToMerchant->LinkCustomAttributes = "";
		$this->serviceFeeToMerchant->HrefValue = "";
		$this->serviceFeeToMerchant->TooltipValue = "";

		// status
		$this->status->LinkCustomAttributes = "";
		$this->status->HrefValue = "";
		$this->status->TooltipValue = "";

		// shoppingCartID
		$this->shoppingCartID->LinkCustomAttributes = "";
		$this->shoppingCartID->HrefValue = "";
		$this->shoppingCartID->TooltipValue = "";

		// merchantRefID
		$this->merchantRefID->LinkCustomAttributes = "";
		$this->merchantRefID->HrefValue = "";
		$this->merchantRefID->TooltipValue = "";

		// feeid
		$this->feeid->LinkCustomAttributes = "";
		$this->feeid->HrefValue = "";
		$this->feeid->TooltipValue = "";

		// ratetabletype
		$this->ratetabletype->LinkCustomAttributes = "";
		$this->ratetabletype->HrefValue = "";
		$this->ratetabletype->TooltipValue = "";

		// pis
		$this->pis->LinkCustomAttributes = "";
		$this->pis->HrefValue = "";
		$this->pis->TooltipValue = "";

		// feesystemshare
		$this->feesystemshare->LinkCustomAttributes = "";
		$this->feesystemshare->HrefValue = "";
		$this->feesystemshare->TooltipValue = "";

		// feeexternalshare
		$this->feeexternalshare->LinkCustomAttributes = "";
		$this->feeexternalshare->HrefValue = "";
		$this->feeexternalshare->TooltipValue = "";

		// feeresellershare
		$this->feeresellershare->LinkCustomAttributes = "";
		$this->feeresellershare->HrefValue = "";
		$this->feeresellershare->TooltipValue = "";

		// lastupdatetime
		$this->lastupdatetime->LinkCustomAttributes = "";
		$this->lastupdatetime->HrefValue = "";
		$this->lastupdatetime->TooltipValue = "";

		// expirationTimeInMinutes
		$this->expirationTimeInMinutes->LinkCustomAttributes = "";
		$this->expirationTimeInMinutes->HrefValue = "";
		$this->expirationTimeInMinutes->TooltipValue = "";

		// expirationTime
		$this->expirationTime->LinkCustomAttributes = "";
		$this->expirationTime->HrefValue = "";
		$this->expirationTime->TooltipValue = "";

		// customeruserid
		$this->customeruserid->LinkCustomAttributes = "";
		$this->customeruserid->HrefValue = "";
		$this->customeruserid->TooltipValue = "";

		// piname
		$this->piname->LinkCustomAttributes = "";
		$this->piname->HrefValue = "";
		$this->piname->TooltipValue = "";

		// branchname
		$this->branchname->LinkCustomAttributes = "";
		$this->branchname->HrefValue = "";
		$this->branchname->TooltipValue = "";

		// operatorname
		$this->operatorname->LinkCustomAttributes = "";
		$this->operatorname->HrefValue = "";
		$this->operatorname->TooltipValue = "";

		// customerusername
		$this->customerusername->LinkCustomAttributes = "";
		$this->customerusername->HrefValue = "";
		$this->customerusername->TooltipValue = "";

		// feefranchiseeshare
		$this->feefranchiseeshare->LinkCustomAttributes = "";
		$this->feefranchiseeshare->HrefValue = "";
		$this->feefranchiseeshare->TooltipValue = "";

		// serviceFeeToCustomerbk1amt
		$this->serviceFeeToCustomerbk1amt->LinkCustomAttributes = "";
		$this->serviceFeeToCustomerbk1amt->HrefValue = "";
		$this->serviceFeeToCustomerbk1amt->TooltipValue = "";

		// serviceFeeToCustomerbk1type
		$this->serviceFeeToCustomerbk1type->LinkCustomAttributes = "";
		$this->serviceFeeToCustomerbk1type->HrefValue = "";
		$this->serviceFeeToCustomerbk1type->TooltipValue = "";

		// serviceFeeToCustomerbk2amt
		$this->serviceFeeToCustomerbk2amt->LinkCustomAttributes = "";
		$this->serviceFeeToCustomerbk2amt->HrefValue = "";
		$this->serviceFeeToCustomerbk2amt->TooltipValue = "";

		// serviceFeeToCustomerbk2type
		$this->serviceFeeToCustomerbk2type->LinkCustomAttributes = "";
		$this->serviceFeeToCustomerbk2type->HrefValue = "";
		$this->serviceFeeToCustomerbk2type->TooltipValue = "";

		// serviceFeeToCustomerbk3type
		$this->serviceFeeToCustomerbk3type->LinkCustomAttributes = "";
		$this->serviceFeeToCustomerbk3type->HrefValue = "";
		$this->serviceFeeToCustomerbk3type->TooltipValue = "";

		// serviceFeeToCustomerbk3amt
		$this->serviceFeeToCustomerbk3amt->LinkCustomAttributes = "";
		$this->serviceFeeToCustomerbk3amt->HrefValue = "";
		$this->serviceFeeToCustomerbk3amt->TooltipValue = "";

		// taxAmountbk1amt
		$this->taxAmountbk1amt->LinkCustomAttributes = "";
		$this->taxAmountbk1amt->HrefValue = "";
		$this->taxAmountbk1amt->TooltipValue = "";

		// taxAmountbk1type
		$this->taxAmountbk1type->LinkCustomAttributes = "";
		$this->taxAmountbk1type->HrefValue = "";
		$this->taxAmountbk1type->TooltipValue = "";

		// taxAmountbk2amt
		$this->taxAmountbk2amt->LinkCustomAttributes = "";
		$this->taxAmountbk2amt->HrefValue = "";
		$this->taxAmountbk2amt->TooltipValue = "";

		// taxAmountbk2type
		$this->taxAmountbk2type->LinkCustomAttributes = "";
		$this->taxAmountbk2type->HrefValue = "";
		$this->taxAmountbk2type->TooltipValue = "";

		// taxAmountbk3amt
		$this->taxAmountbk3amt->LinkCustomAttributes = "";
		$this->taxAmountbk3amt->HrefValue = "";
		$this->taxAmountbk3amt->TooltipValue = "";

		// taxAmountbk3type
		$this->taxAmountbk3type->LinkCustomAttributes = "";
		$this->taxAmountbk3type->HrefValue = "";
		$this->taxAmountbk3type->TooltipValue = "";

		// Call Row Rendered event
		$this->Row_Rendered();

		// Save data for Custom Template
		$this->Rows[] = $this->customTemplateFieldValues();
	}

	// Render edit row values
	public function renderEditRow()
	{
		global $Security, $CurrentLanguage, $Language;

		// Call Row Rendering event
		$this->Row_Rendering();

		// id
		$this->id->EditAttrs["class"] = "form-control";
		$this->id->EditCustomAttributes = "";
		$this->id->EditValue = $this->id->CurrentValue;
		$this->id->ViewCustomAttributes = "";

		// datecreated
		$this->datecreated->EditAttrs["class"] = "form-control";
		$this->datecreated->EditCustomAttributes = "";
		$this->datecreated->EditValue = FormatDateTime($this->datecreated->CurrentValue, 8);
		$this->datecreated->PlaceHolder = RemoveHtml($this->datecreated->caption());

		// brokerid
		$this->brokerid->EditAttrs["class"] = "form-control";
		$this->brokerid->EditCustomAttributes = "";
		$this->brokerid->EditValue = $this->brokerid->CurrentValue;
		$this->brokerid->PlaceHolder = RemoveHtml($this->brokerid->caption());

		// requestorid
		$this->requestorid->EditAttrs["class"] = "form-control";
		$this->requestorid->EditCustomAttributes = "";
		$this->requestorid->EditValue = $this->requestorid->CurrentValue;
		$this->requestorid->PlaceHolder = RemoveHtml($this->requestorid->caption());

		// requestor4payuser
		$this->requestor4payuser->EditAttrs["class"] = "form-control";
		$this->requestor4payuser->EditCustomAttributes = "";
		$this->requestor4payuser->EditValue = $this->requestor4payuser->CurrentValue;
		$this->requestor4payuser->PlaceHolder = RemoveHtml($this->requestor4payuser->caption());

		// recipientid
		$this->recipientid->EditAttrs["class"] = "form-control";
		$this->recipientid->EditCustomAttributes = "";
		$this->recipientid->EditValue = $this->recipientid->CurrentValue;
		$this->recipientid->PlaceHolder = RemoveHtml($this->recipientid->caption());

		// recipient4payuser
		$this->recipient4payuser->EditAttrs["class"] = "form-control";
		$this->recipient4payuser->EditCustomAttributes = "";
		$this->recipient4payuser->EditValue = $this->recipient4payuser->CurrentValue;
		$this->recipient4payuser->PlaceHolder = RemoveHtml($this->recipient4payuser->caption());

		// refno1
		$this->refno1->EditAttrs["class"] = "form-control";
		$this->refno1->EditCustomAttributes = "";
		if (!$this->refno1->Raw)
			$this->refno1->CurrentValue = HtmlDecode($this->refno1->CurrentValue);
		$this->refno1->EditValue = $this->refno1->CurrentValue;
		$this->refno1->PlaceHolder = RemoveHtml($this->refno1->caption());

		// refno2
		$this->refno2->EditAttrs["class"] = "form-control";
		$this->refno2->EditCustomAttributes = "";
		if (!$this->refno2->Raw)
			$this->refno2->CurrentValue = HtmlDecode($this->refno2->CurrentValue);
		$this->refno2->EditValue = $this->refno2->CurrentValue;
		$this->refno2->PlaceHolder = RemoveHtml($this->refno2->caption());

		// saleid
		$this->saleid->EditAttrs["class"] = "form-control";
		$this->saleid->EditCustomAttributes = "";
		$this->saleid->EditValue = $this->saleid->CurrentValue;
		$this->saleid->PlaceHolder = RemoveHtml($this->saleid->caption());

		// operatorid
		$this->operatorid->EditAttrs["class"] = "form-control";
		$this->operatorid->EditCustomAttributes = "";
		$this->operatorid->EditValue = $this->operatorid->CurrentValue;
		$this->operatorid->PlaceHolder = RemoveHtml($this->operatorid->caption());

		// txid
		$this->txid->EditAttrs["class"] = "form-control";
		$this->txid->EditCustomAttributes = "";
		if (!$this->txid->Raw)
			$this->txid->CurrentValue = HtmlDecode($this->txid->CurrentValue);
		$this->txid->EditValue = $this->txid->CurrentValue;
		$this->txid->PlaceHolder = RemoveHtml($this->txid->caption());

		// merchantID
		$this->merchantID->EditAttrs["class"] = "form-control";
		$this->merchantID->EditCustomAttributes = "";
		$this->merchantID->EditValue = $this->merchantID->CurrentValue;
		$this->merchantID->PlaceHolder = RemoveHtml($this->merchantID->caption());

		// userID
		$this->_userID->EditAttrs["class"] = "form-control";
		$this->_userID->EditCustomAttributes = "";
		$this->_userID->EditValue = $this->_userID->CurrentValue;
		$this->_userID->PlaceHolder = RemoveHtml($this->_userID->caption());

		// transferTime
		$this->transferTime->EditAttrs["class"] = "form-control";
		$this->transferTime->EditCustomAttributes = "";
		$this->transferTime->EditValue = FormatDateTime($this->transferTime->CurrentValue, 8);
		$this->transferTime->PlaceHolder = RemoveHtml($this->transferTime->caption());

		// merchantSurcharge
		$this->merchantSurcharge->EditAttrs["class"] = "form-control";
		$this->merchantSurcharge->EditCustomAttributes = "";
		$this->merchantSurcharge->EditValue = $this->merchantSurcharge->CurrentValue;
		$this->merchantSurcharge->PlaceHolder = RemoveHtml($this->merchantSurcharge->caption());
		if (strval($this->merchantSurcharge->EditValue) != "" && is_numeric($this->merchantSurcharge->EditValue))
			$this->merchantSurcharge->EditValue = FormatNumber($this->merchantSurcharge->EditValue, -2, -2, -2, -2);
		

		// currID
		$this->currID->EditAttrs["class"] = "form-control";
		$this->currID->EditCustomAttributes = "";
		if (!$this->currID->Raw)
			$this->currID->CurrentValue = HtmlDecode($this->currID->CurrentValue);
		$this->currID->EditValue = $this->currID->CurrentValue;
		$this->currID->PlaceHolder = RemoveHtml($this->currID->caption());

		// purchaseAmount
		$this->purchaseAmount->EditAttrs["class"] = "form-control";
		$this->purchaseAmount->EditCustomAttributes = "";
		$this->purchaseAmount->EditValue = $this->purchaseAmount->CurrentValue;
		$this->purchaseAmount->PlaceHolder = RemoveHtml($this->purchaseAmount->caption());
		if (strval($this->purchaseAmount->EditValue) != "" && is_numeric($this->purchaseAmount->EditValue))
			$this->purchaseAmount->EditValue = FormatNumber($this->purchaseAmount->EditValue, -2, -2, -2, -2);
		

		// taxAmount
		$this->taxAmount->EditAttrs["class"] = "form-control";
		$this->taxAmount->EditCustomAttributes = "";
		$this->taxAmount->EditValue = $this->taxAmount->CurrentValue;
		$this->taxAmount->PlaceHolder = RemoveHtml($this->taxAmount->caption());
		if (strval($this->taxAmount->EditValue) != "" && is_numeric($this->taxAmount->EditValue))
			$this->taxAmount->EditValue = FormatNumber($this->taxAmount->EditValue, -2, -2, -2, -2);
		

		// tipAmount
		$this->tipAmount->EditAttrs["class"] = "form-control";
		$this->tipAmount->EditCustomAttributes = "";
		$this->tipAmount->EditValue = $this->tipAmount->CurrentValue;
		$this->tipAmount->PlaceHolder = RemoveHtml($this->tipAmount->caption());
		if (strval($this->tipAmount->EditValue) != "" && is_numeric($this->tipAmount->EditValue))
			$this->tipAmount->EditValue = FormatNumber($this->tipAmount->EditValue, -2, -2, -2, -2);
		

		// serviceFeeToCustomer
		$this->serviceFeeToCustomer->EditAttrs["class"] = "form-control";
		$this->serviceFeeToCustomer->EditCustomAttributes = "";
		$this->serviceFeeToCustomer->EditValue = $this->serviceFeeToCustomer->CurrentValue;
		$this->serviceFeeToCustomer->PlaceHolder = RemoveHtml($this->serviceFeeToCustomer->caption());
		if (strval($this->serviceFeeToCustomer->EditValue) != "" && is_numeric($this->serviceFeeToCustomer->EditValue))
			$this->serviceFeeToCustomer->EditValue = FormatNumber($this->serviceFeeToCustomer->EditValue, -2, -2, -2, -2);
		

		// TotalAmountForCustomer
		$this->TotalAmountForCustomer->EditAttrs["class"] = "form-control";
		$this->TotalAmountForCustomer->EditCustomAttributes = "";
		$this->TotalAmountForCustomer->EditValue = $this->TotalAmountForCustomer->CurrentValue;
		$this->TotalAmountForCustomer->PlaceHolder = RemoveHtml($this->TotalAmountForCustomer->caption());
		if (strval($this->TotalAmountForCustomer->EditValue) != "" && is_numeric($this->TotalAmountForCustomer->EditValue))
			$this->TotalAmountForCustomer->EditValue = FormatNumber($this->TotalAmountForCustomer->EditValue, -2, -2, -2, -2);
		

		// serviceFeeToMerchant
		$this->serviceFeeToMerchant->EditAttrs["class"] = "form-control";
		$this->serviceFeeToMerchant->EditCustomAttributes = "";
		$this->serviceFeeToMerchant->EditValue = $this->serviceFeeToMerchant->CurrentValue;
		$this->serviceFeeToMerchant->PlaceHolder = RemoveHtml($this->serviceFeeToMerchant->caption());
		if (strval($this->serviceFeeToMerchant->EditValue) != "" && is_numeric($this->serviceFeeToMerchant->EditValue))
			$this->serviceFeeToMerchant->EditValue = FormatNumber($this->serviceFeeToMerchant->EditValue, -2, -2, -2, -2);
		

		// status
		$this->status->EditCustomAttributes = "";
		$this->status->EditValue = $this->status->options(TRUE);

		// shoppingCartID
		$this->shoppingCartID->EditAttrs["class"] = "form-control";
		$this->shoppingCartID->EditCustomAttributes = "";
		if (!$this->shoppingCartID->Raw)
			$this->shoppingCartID->CurrentValue = HtmlDecode($this->shoppingCartID->CurrentValue);
		$this->shoppingCartID->EditValue = $this->shoppingCartID->CurrentValue;
		$this->shoppingCartID->PlaceHolder = RemoveHtml($this->shoppingCartID->caption());

		// merchantRefID
		$this->merchantRefID->EditAttrs["class"] = "form-control";
		$this->merchantRefID->EditCustomAttributes = "";
		if (!$this->merchantRefID->Raw)
			$this->merchantRefID->CurrentValue = HtmlDecode($this->merchantRefID->CurrentValue);
		$this->merchantRefID->EditValue = $this->merchantRefID->CurrentValue;
		$this->merchantRefID->PlaceHolder = RemoveHtml($this->merchantRefID->caption());

		// feeid
		$this->feeid->EditAttrs["class"] = "form-control";
		$this->feeid->EditCustomAttributes = "";
		$this->feeid->EditValue = $this->feeid->CurrentValue;
		$this->feeid->PlaceHolder = RemoveHtml($this->feeid->caption());

		// ratetabletype
		$this->ratetabletype->EditAttrs["class"] = "form-control";
		$this->ratetabletype->EditCustomAttributes = "";
		$this->ratetabletype->EditValue = $this->ratetabletype->CurrentValue;
		$this->ratetabletype->PlaceHolder = RemoveHtml($this->ratetabletype->caption());

		// pis
		$this->pis->EditAttrs["class"] = "form-control";
		$this->pis->EditCustomAttributes = "";
		$this->pis->EditValue = $this->pis->CurrentValue;
		$this->pis->PlaceHolder = RemoveHtml($this->pis->caption());

		// feesystemshare
		$this->feesystemshare->EditAttrs["class"] = "form-control";
		$this->feesystemshare->EditCustomAttributes = "";
		$this->feesystemshare->EditValue = $this->feesystemshare->CurrentValue;
		$this->feesystemshare->PlaceHolder = RemoveHtml($this->feesystemshare->caption());
		if (strval($this->feesystemshare->EditValue) != "" && is_numeric($this->feesystemshare->EditValue))
			$this->feesystemshare->EditValue = FormatNumber($this->feesystemshare->EditValue, -2, -2, -2, -2);
		

		// feeexternalshare
		$this->feeexternalshare->EditAttrs["class"] = "form-control";
		$this->feeexternalshare->EditCustomAttributes = "";
		$this->feeexternalshare->EditValue = $this->feeexternalshare->CurrentValue;
		$this->feeexternalshare->PlaceHolder = RemoveHtml($this->feeexternalshare->caption());
		if (strval($this->feeexternalshare->EditValue) != "" && is_numeric($this->feeexternalshare->EditValue))
			$this->feeexternalshare->EditValue = FormatNumber($this->feeexternalshare->EditValue, -2, -2, -2, -2);
		

		// feeresellershare
		$this->feeresellershare->EditAttrs["class"] = "form-control";
		$this->feeresellershare->EditCustomAttributes = "";
		$this->feeresellershare->EditValue = $this->feeresellershare->CurrentValue;
		$this->feeresellershare->PlaceHolder = RemoveHtml($this->feeresellershare->caption());
		if (strval($this->feeresellershare->EditValue) != "" && is_numeric($this->feeresellershare->EditValue))
			$this->feeresellershare->EditValue = FormatNumber($this->feeresellershare->EditValue, -2, -2, -2, -2);
		

		// lastupdatetime
		$this->lastupdatetime->EditAttrs["class"] = "form-control";
		$this->lastupdatetime->EditCustomAttributes = "";
		$this->lastupdatetime->EditValue = FormatDateTime($this->lastupdatetime->CurrentValue, 8);
		$this->lastupdatetime->PlaceHolder = RemoveHtml($this->lastupdatetime->caption());

		// expirationTimeInMinutes
		$this->expirationTimeInMinutes->EditAttrs["class"] = "form-control";
		$this->expirationTimeInMinutes->EditCustomAttributes = "";
		$this->expirationTimeInMinutes->EditValue = $this->expirationTimeInMinutes->CurrentValue;
		$this->expirationTimeInMinutes->PlaceHolder = RemoveHtml($this->expirationTimeInMinutes->caption());

		// expirationTime
		$this->expirationTime->EditAttrs["class"] = "form-control";
		$this->expirationTime->EditCustomAttributes = "";
		$this->expirationTime->EditValue = FormatDateTime($this->expirationTime->CurrentValue, 8);
		$this->expirationTime->PlaceHolder = RemoveHtml($this->expirationTime->caption());

		// customeruserid
		$this->customeruserid->EditAttrs["class"] = "form-control";
		$this->customeruserid->EditCustomAttributes = "";
		$this->customeruserid->EditValue = $this->customeruserid->CurrentValue;
		$this->customeruserid->PlaceHolder = RemoveHtml($this->customeruserid->caption());

		// piname
		$this->piname->EditAttrs["class"] = "form-control";
		$this->piname->EditCustomAttributes = "";
		if (!$this->piname->Raw)
			$this->piname->CurrentValue = HtmlDecode($this->piname->CurrentValue);
		$this->piname->EditValue = $this->piname->CurrentValue;
		$this->piname->PlaceHolder = RemoveHtml($this->piname->caption());

		// branchname
		$this->branchname->EditAttrs["class"] = "form-control";
		$this->branchname->EditCustomAttributes = "";
		if (!$this->branchname->Raw)
			$this->branchname->CurrentValue = HtmlDecode($this->branchname->CurrentValue);
		$this->branchname->EditValue = $this->branchname->CurrentValue;
		$this->branchname->PlaceHolder = RemoveHtml($this->branchname->caption());

		// operatorname
		$this->operatorname->EditAttrs["class"] = "form-control";
		$this->operatorname->EditCustomAttributes = "";
		if (!$this->operatorname->Raw)
			$this->operatorname->CurrentValue = HtmlDecode($this->operatorname->CurrentValue);
		$this->operatorname->EditValue = $this->operatorname->CurrentValue;
		$this->operatorname->PlaceHolder = RemoveHtml($this->operatorname->caption());

		// customerusername
		$this->customerusername->EditAttrs["class"] = "form-control";
		$this->customerusername->EditCustomAttributes = "";
		if (!$this->customerusername->Raw)
			$this->customerusername->CurrentValue = HtmlDecode($this->customerusername->CurrentValue);
		$this->customerusername->EditValue = $this->customerusername->CurrentValue;
		$this->customerusername->PlaceHolder = RemoveHtml($this->customerusername->caption());

		// feefranchiseeshare
		$this->feefranchiseeshare->EditAttrs["class"] = "form-control";
		$this->feefranchiseeshare->EditCustomAttributes = "";
		$this->feefranchiseeshare->EditValue = $this->feefranchiseeshare->CurrentValue;
		$this->feefranchiseeshare->PlaceHolder = RemoveHtml($this->feefranchiseeshare->caption());
		if (strval($this->feefranchiseeshare->EditValue) != "" && is_numeric($this->feefranchiseeshare->EditValue))
			$this->feefranchiseeshare->EditValue = FormatNumber($this->feefranchiseeshare->EditValue, -2, -2, -2, -2);
		

		// serviceFeeToCustomerbk1amt
		$this->serviceFeeToCustomerbk1amt->EditAttrs["class"] = "form-control";
		$this->serviceFeeToCustomerbk1amt->EditCustomAttributes = "";
		$this->serviceFeeToCustomerbk1amt->EditValue = $this->serviceFeeToCustomerbk1amt->CurrentValue;
		$this->serviceFeeToCustomerbk1amt->PlaceHolder = RemoveHtml($this->serviceFeeToCustomerbk1amt->caption());
		if (strval($this->serviceFeeToCustomerbk1amt->EditValue) != "" && is_numeric($this->serviceFeeToCustomerbk1amt->EditValue))
			$this->serviceFeeToCustomerbk1amt->EditValue = FormatNumber($this->serviceFeeToCustomerbk1amt->EditValue, -2, -2, -2, -2);
		

		// serviceFeeToCustomerbk1type
		$this->serviceFeeToCustomerbk1type->EditAttrs["class"] = "form-control";
		$this->serviceFeeToCustomerbk1type->EditCustomAttributes = "";
		if (!$this->serviceFeeToCustomerbk1type->Raw)
			$this->serviceFeeToCustomerbk1type->CurrentValue = HtmlDecode($this->serviceFeeToCustomerbk1type->CurrentValue);
		$this->serviceFeeToCustomerbk1type->EditValue = $this->serviceFeeToCustomerbk1type->CurrentValue;
		$this->serviceFeeToCustomerbk1type->PlaceHolder = RemoveHtml($this->serviceFeeToCustomerbk1type->caption());

		// serviceFeeToCustomerbk2amt
		$this->serviceFeeToCustomerbk2amt->EditAttrs["class"] = "form-control";
		$this->serviceFeeToCustomerbk2amt->EditCustomAttributes = "";
		$this->serviceFeeToCustomerbk2amt->EditValue = $this->serviceFeeToCustomerbk2amt->CurrentValue;
		$this->serviceFeeToCustomerbk2amt->PlaceHolder = RemoveHtml($this->serviceFeeToCustomerbk2amt->caption());
		if (strval($this->serviceFeeToCustomerbk2amt->EditValue) != "" && is_numeric($this->serviceFeeToCustomerbk2amt->EditValue))
			$this->serviceFeeToCustomerbk2amt->EditValue = FormatNumber($this->serviceFeeToCustomerbk2amt->EditValue, -2, -2, -2, -2);
		

		// serviceFeeToCustomerbk2type
		$this->serviceFeeToCustomerbk2type->EditAttrs["class"] = "form-control";
		$this->serviceFeeToCustomerbk2type->EditCustomAttributes = "";
		if (!$this->serviceFeeToCustomerbk2type->Raw)
			$this->serviceFeeToCustomerbk2type->CurrentValue = HtmlDecode($this->serviceFeeToCustomerbk2type->CurrentValue);
		$this->serviceFeeToCustomerbk2type->EditValue = $this->serviceFeeToCustomerbk2type->CurrentValue;
		$this->serviceFeeToCustomerbk2type->PlaceHolder = RemoveHtml($this->serviceFeeToCustomerbk2type->caption());

		// serviceFeeToCustomerbk3type
		$this->serviceFeeToCustomerbk3type->EditAttrs["class"] = "form-control";
		$this->serviceFeeToCustomerbk3type->EditCustomAttributes = "";
		if (!$this->serviceFeeToCustomerbk3type->Raw)
			$this->serviceFeeToCustomerbk3type->CurrentValue = HtmlDecode($this->serviceFeeToCustomerbk3type->CurrentValue);
		$this->serviceFeeToCustomerbk3type->EditValue = $this->serviceFeeToCustomerbk3type->CurrentValue;
		$this->serviceFeeToCustomerbk3type->PlaceHolder = RemoveHtml($this->serviceFeeToCustomerbk3type->caption());

		// serviceFeeToCustomerbk3amt
		$this->serviceFeeToCustomerbk3amt->EditAttrs["class"] = "form-control";
		$this->serviceFeeToCustomerbk3amt->EditCustomAttributes = "";
		$this->serviceFeeToCustomerbk3amt->EditValue = $this->serviceFeeToCustomerbk3amt->CurrentValue;
		$this->serviceFeeToCustomerbk3amt->PlaceHolder = RemoveHtml($this->serviceFeeToCustomerbk3amt->caption());
		if (strval($this->serviceFeeToCustomerbk3amt->EditValue) != "" && is_numeric($this->serviceFeeToCustomerbk3amt->EditValue))
			$this->serviceFeeToCustomerbk3amt->EditValue = FormatNumber($this->serviceFeeToCustomerbk3amt->EditValue, -2, -2, -2, -2);
		

		// taxAmountbk1amt
		$this->taxAmountbk1amt->EditAttrs["class"] = "form-control";
		$this->taxAmountbk1amt->EditCustomAttributes = "";
		$this->taxAmountbk1amt->EditValue = $this->taxAmountbk1amt->CurrentValue;
		$this->taxAmountbk1amt->PlaceHolder = RemoveHtml($this->taxAmountbk1amt->caption());
		if (strval($this->taxAmountbk1amt->EditValue) != "" && is_numeric($this->taxAmountbk1amt->EditValue))
			$this->taxAmountbk1amt->EditValue = FormatNumber($this->taxAmountbk1amt->EditValue, -2, -2, -2, -2);
		

		// taxAmountbk1type
		$this->taxAmountbk1type->EditAttrs["class"] = "form-control";
		$this->taxAmountbk1type->EditCustomAttributes = "";
		if (!$this->taxAmountbk1type->Raw)
			$this->taxAmountbk1type->CurrentValue = HtmlDecode($this->taxAmountbk1type->CurrentValue);
		$this->taxAmountbk1type->EditValue = $this->taxAmountbk1type->CurrentValue;
		$this->taxAmountbk1type->PlaceHolder = RemoveHtml($this->taxAmountbk1type->caption());

		// taxAmountbk2amt
		$this->taxAmountbk2amt->EditAttrs["class"] = "form-control";
		$this->taxAmountbk2amt->EditCustomAttributes = "";
		$this->taxAmountbk2amt->EditValue = $this->taxAmountbk2amt->CurrentValue;
		$this->taxAmountbk2amt->PlaceHolder = RemoveHtml($this->taxAmountbk2amt->caption());
		if (strval($this->taxAmountbk2amt->EditValue) != "" && is_numeric($this->taxAmountbk2amt->EditValue))
			$this->taxAmountbk2amt->EditValue = FormatNumber($this->taxAmountbk2amt->EditValue, -2, -2, -2, -2);
		

		// taxAmountbk2type
		$this->taxAmountbk2type->EditAttrs["class"] = "form-control";
		$this->taxAmountbk2type->EditCustomAttributes = "";
		if (!$this->taxAmountbk2type->Raw)
			$this->taxAmountbk2type->CurrentValue = HtmlDecode($this->taxAmountbk2type->CurrentValue);
		$this->taxAmountbk2type->EditValue = $this->taxAmountbk2type->CurrentValue;
		$this->taxAmountbk2type->PlaceHolder = RemoveHtml($this->taxAmountbk2type->caption());

		// taxAmountbk3amt
		$this->taxAmountbk3amt->EditAttrs["class"] = "form-control";
		$this->taxAmountbk3amt->EditCustomAttributes = "";
		$this->taxAmountbk3amt->EditValue = $this->taxAmountbk3amt->CurrentValue;
		$this->taxAmountbk3amt->PlaceHolder = RemoveHtml($this->taxAmountbk3amt->caption());
		if (strval($this->taxAmountbk3amt->EditValue) != "" && is_numeric($this->taxAmountbk3amt->EditValue))
			$this->taxAmountbk3amt->EditValue = FormatNumber($this->taxAmountbk3amt->EditValue, -2, -2, -2, -2);
		

		// taxAmountbk3type
		$this->taxAmountbk3type->EditAttrs["class"] = "form-control";
		$this->taxAmountbk3type->EditCustomAttributes = "";
		if (!$this->taxAmountbk3type->Raw)
			$this->taxAmountbk3type->CurrentValue = HtmlDecode($this->taxAmountbk3type->CurrentValue);
		$this->taxAmountbk3type->EditValue = $this->taxAmountbk3type->CurrentValue;
		$this->taxAmountbk3type->PlaceHolder = RemoveHtml($this->taxAmountbk3type->caption());

		// Call Row Rendered event
		$this->Row_Rendered();
	}

	// Aggregate list row values
	public function aggregateListRowValues()
	{
	}

	// Aggregate list row (for rendering)
	public function aggregateListRow()
	{

		// Call Row Rendered event
		$this->Row_Rendered();
	}

	// Export data in HTML/CSV/Word/Excel/Email/PDF format
	public function exportDocument($doc, $recordset, $startRec = 1, $stopRec = 1, $exportPageType = "")
	{
		if (!$recordset || !$doc)
			return;
		if (!$doc->ExportCustom) {

			// Write header
			$doc->exportTableHeader();
			if ($doc->Horizontal) { // Horizontal format, write header
				$doc->beginExportRow();
				if ($exportPageType == "view") {
					$doc->exportCaption($this->id);
					$doc->exportCaption($this->datecreated);
					$doc->exportCaption($this->brokerid);
					$doc->exportCaption($this->requestorid);
					$doc->exportCaption($this->requestor4payuser);
					$doc->exportCaption($this->recipientid);
					$doc->exportCaption($this->recipient4payuser);
					$doc->exportCaption($this->refno1);
					$doc->exportCaption($this->refno2);
					$doc->exportCaption($this->saleid);
					$doc->exportCaption($this->operatorid);
					$doc->exportCaption($this->txid);
					$doc->exportCaption($this->merchantID);
					$doc->exportCaption($this->_userID);
					$doc->exportCaption($this->transferTime);
					$doc->exportCaption($this->merchantSurcharge);
					$doc->exportCaption($this->currID);
					$doc->exportCaption($this->purchaseAmount);
					$doc->exportCaption($this->taxAmount);
					$doc->exportCaption($this->tipAmount);
					$doc->exportCaption($this->serviceFeeToCustomer);
					$doc->exportCaption($this->TotalAmountForCustomer);
					$doc->exportCaption($this->serviceFeeToMerchant);
					$doc->exportCaption($this->status);
					$doc->exportCaption($this->shoppingCartID);
					$doc->exportCaption($this->merchantRefID);
					$doc->exportCaption($this->feeid);
					$doc->exportCaption($this->ratetabletype);
					$doc->exportCaption($this->pis);
					$doc->exportCaption($this->feesystemshare);
					$doc->exportCaption($this->feeexternalshare);
					$doc->exportCaption($this->feeresellershare);
					$doc->exportCaption($this->lastupdatetime);
					$doc->exportCaption($this->expirationTimeInMinutes);
					$doc->exportCaption($this->expirationTime);
					$doc->exportCaption($this->customeruserid);
					$doc->exportCaption($this->piname);
					$doc->exportCaption($this->branchname);
					$doc->exportCaption($this->operatorname);
					$doc->exportCaption($this->customerusername);
					$doc->exportCaption($this->feefranchiseeshare);
					$doc->exportCaption($this->serviceFeeToCustomerbk1amt);
					$doc->exportCaption($this->serviceFeeToCustomerbk1type);
					$doc->exportCaption($this->serviceFeeToCustomerbk2amt);
					$doc->exportCaption($this->serviceFeeToCustomerbk2type);
					$doc->exportCaption($this->serviceFeeToCustomerbk3type);
					$doc->exportCaption($this->serviceFeeToCustomerbk3amt);
					$doc->exportCaption($this->taxAmountbk1amt);
					$doc->exportCaption($this->taxAmountbk1type);
					$doc->exportCaption($this->taxAmountbk2amt);
					$doc->exportCaption($this->taxAmountbk2type);
					$doc->exportCaption($this->taxAmountbk3amt);
					$doc->exportCaption($this->taxAmountbk3type);
				} else {
					$doc->exportCaption($this->id);
					$doc->exportCaption($this->datecreated);
					$doc->exportCaption($this->brokerid);
					$doc->exportCaption($this->requestorid);
					$doc->exportCaption($this->requestor4payuser);
					$doc->exportCaption($this->recipientid);
					$doc->exportCaption($this->recipient4payuser);
					$doc->exportCaption($this->refno1);
					$doc->exportCaption($this->refno2);
					$doc->exportCaption($this->saleid);
					$doc->exportCaption($this->operatorid);
					$doc->exportCaption($this->txid);
					$doc->exportCaption($this->merchantID);
					$doc->exportCaption($this->_userID);
					$doc->exportCaption($this->transferTime);
					$doc->exportCaption($this->merchantSurcharge);
					$doc->exportCaption($this->currID);
					$doc->exportCaption($this->purchaseAmount);
					$doc->exportCaption($this->taxAmount);
					$doc->exportCaption($this->tipAmount);
					$doc->exportCaption($this->serviceFeeToCustomer);
					$doc->exportCaption($this->TotalAmountForCustomer);
					$doc->exportCaption($this->serviceFeeToMerchant);
					$doc->exportCaption($this->status);
					$doc->exportCaption($this->shoppingCartID);
					$doc->exportCaption($this->merchantRefID);
					$doc->exportCaption($this->feeid);
					$doc->exportCaption($this->ratetabletype);
					$doc->exportCaption($this->feesystemshare);
					$doc->exportCaption($this->feeexternalshare);
					$doc->exportCaption($this->feeresellershare);
					$doc->exportCaption($this->lastupdatetime);
					$doc->exportCaption($this->expirationTimeInMinutes);
					$doc->exportCaption($this->expirationTime);
					$doc->exportCaption($this->customeruserid);
					$doc->exportCaption($this->piname);
					$doc->exportCaption($this->branchname);
					$doc->exportCaption($this->operatorname);
					$doc->exportCaption($this->customerusername);
					$doc->exportCaption($this->feefranchiseeshare);
					$doc->exportCaption($this->serviceFeeToCustomerbk1amt);
					$doc->exportCaption($this->serviceFeeToCustomerbk1type);
					$doc->exportCaption($this->serviceFeeToCustomerbk2amt);
					$doc->exportCaption($this->serviceFeeToCustomerbk2type);
					$doc->exportCaption($this->serviceFeeToCustomerbk3type);
					$doc->exportCaption($this->serviceFeeToCustomerbk3amt);
					$doc->exportCaption($this->taxAmountbk1amt);
					$doc->exportCaption($this->taxAmountbk1type);
					$doc->exportCaption($this->taxAmountbk2amt);
					$doc->exportCaption($this->taxAmountbk2type);
					$doc->exportCaption($this->taxAmountbk3amt);
					$doc->exportCaption($this->taxAmountbk3type);
				}
				$doc->endExportRow();
			}
		}

		// Move to first record
		$recCnt = $startRec - 1;
		if (!$recordset->EOF) {
			$recordset->moveFirst();
			if ($startRec > 1)
				$recordset->move($startRec - 1);
		}
		while (!$recordset->EOF && $recCnt < $stopRec) {
			$recCnt++;
			if ($recCnt >= $startRec) {
				$rowCnt = $recCnt - $startRec + 1;

				// Page break
				if ($this->ExportPageBreakCount > 0) {
					if ($rowCnt > 1 && ($rowCnt - 1) % $this->ExportPageBreakCount == 0)
						$doc->exportPageBreak();
				}
				$this->loadListRowValues($recordset);

				// Render row
				$this->RowType = ROWTYPE_VIEW; // Render view
				$this->resetAttributes();
				$this->renderListRow();
				if (!$doc->ExportCustom) {
					$doc->beginExportRow($rowCnt); // Allow CSS styles if enabled
					if ($exportPageType == "view") {
						$doc->exportField($this->id);
						$doc->exportField($this->datecreated);
						$doc->exportField($this->brokerid);
						$doc->exportField($this->requestorid);
						$doc->exportField($this->requestor4payuser);
						$doc->exportField($this->recipientid);
						$doc->exportField($this->recipient4payuser);
						$doc->exportField($this->refno1);
						$doc->exportField($this->refno2);
						$doc->exportField($this->saleid);
						$doc->exportField($this->operatorid);
						$doc->exportField($this->txid);
						$doc->exportField($this->merchantID);
						$doc->exportField($this->_userID);
						$doc->exportField($this->transferTime);
						$doc->exportField($this->merchantSurcharge);
						$doc->exportField($this->currID);
						$doc->exportField($this->purchaseAmount);
						$doc->exportField($this->taxAmount);
						$doc->exportField($this->tipAmount);
						$doc->exportField($this->serviceFeeToCustomer);
						$doc->exportField($this->TotalAmountForCustomer);
						$doc->exportField($this->serviceFeeToMerchant);
						$doc->exportField($this->status);
						$doc->exportField($this->shoppingCartID);
						$doc->exportField($this->merchantRefID);
						$doc->exportField($this->feeid);
						$doc->exportField($this->ratetabletype);
						$doc->exportField($this->pis);
						$doc->exportField($this->feesystemshare);
						$doc->exportField($this->feeexternalshare);
						$doc->exportField($this->feeresellershare);
						$doc->exportField($this->lastupdatetime);
						$doc->exportField($this->expirationTimeInMinutes);
						$doc->exportField($this->expirationTime);
						$doc->exportField($this->customeruserid);
						$doc->exportField($this->piname);
						$doc->exportField($this->branchname);
						$doc->exportField($this->operatorname);
						$doc->exportField($this->customerusername);
						$doc->exportField($this->feefranchiseeshare);
						$doc->exportField($this->serviceFeeToCustomerbk1amt);
						$doc->exportField($this->serviceFeeToCustomerbk1type);
						$doc->exportField($this->serviceFeeToCustomerbk2amt);
						$doc->exportField($this->serviceFeeToCustomerbk2type);
						$doc->exportField($this->serviceFeeToCustomerbk3type);
						$doc->exportField($this->serviceFeeToCustomerbk3amt);
						$doc->exportField($this->taxAmountbk1amt);
						$doc->exportField($this->taxAmountbk1type);
						$doc->exportField($this->taxAmountbk2amt);
						$doc->exportField($this->taxAmountbk2type);
						$doc->exportField($this->taxAmountbk3amt);
						$doc->exportField($this->taxAmountbk3type);
					} else {
						$doc->exportField($this->id);
						$doc->exportField($this->datecreated);
						$doc->exportField($this->brokerid);
						$doc->exportField($this->requestorid);
						$doc->exportField($this->requestor4payuser);
						$doc->exportField($this->recipientid);
						$doc->exportField($this->recipient4payuser);
						$doc->exportField($this->refno1);
						$doc->exportField($this->refno2);
						$doc->exportField($this->saleid);
						$doc->exportField($this->operatorid);
						$doc->exportField($this->txid);
						$doc->exportField($this->merchantID);
						$doc->exportField($this->_userID);
						$doc->exportField($this->transferTime);
						$doc->exportField($this->merchantSurcharge);
						$doc->exportField($this->currID);
						$doc->exportField($this->purchaseAmount);
						$doc->exportField($this->taxAmount);
						$doc->exportField($this->tipAmount);
						$doc->exportField($this->serviceFeeToCustomer);
						$doc->exportField($this->TotalAmountForCustomer);
						$doc->exportField($this->serviceFeeToMerchant);
						$doc->exportField($this->status);
						$doc->exportField($this->shoppingCartID);
						$doc->exportField($this->merchantRefID);
						$doc->exportField($this->feeid);
						$doc->exportField($this->ratetabletype);
						$doc->exportField($this->feesystemshare);
						$doc->exportField($this->feeexternalshare);
						$doc->exportField($this->feeresellershare);
						$doc->exportField($this->lastupdatetime);
						$doc->exportField($this->expirationTimeInMinutes);
						$doc->exportField($this->expirationTime);
						$doc->exportField($this->customeruserid);
						$doc->exportField($this->piname);
						$doc->exportField($this->branchname);
						$doc->exportField($this->operatorname);
						$doc->exportField($this->customerusername);
						$doc->exportField($this->feefranchiseeshare);
						$doc->exportField($this->serviceFeeToCustomerbk1amt);
						$doc->exportField($this->serviceFeeToCustomerbk1type);
						$doc->exportField($this->serviceFeeToCustomerbk2amt);
						$doc->exportField($this->serviceFeeToCustomerbk2type);
						$doc->exportField($this->serviceFeeToCustomerbk3type);
						$doc->exportField($this->serviceFeeToCustomerbk3amt);
						$doc->exportField($this->taxAmountbk1amt);
						$doc->exportField($this->taxAmountbk1type);
						$doc->exportField($this->taxAmountbk2amt);
						$doc->exportField($this->taxAmountbk2type);
						$doc->exportField($this->taxAmountbk3amt);
						$doc->exportField($this->taxAmountbk3type);
					}
					$doc->endExportRow($rowCnt);
				}
			}

			// Call Row Export server event
			if ($doc->ExportCustom)
				$this->Row_Export($recordset->fields);
			$recordset->moveNext();
		}
		if (!$doc->ExportCustom) {
			$doc->exportTableFooter();
		}
	}

	// Get file data
	public function getFileData($fldparm, $key, $resize, $width = 0, $height = 0)
	{

		// No binary fields
		return FALSE;
	}

	// Table level events
	// Recordset Selecting event
	function Recordset_Selecting(&$filter) {

		// Enter your code here
	}

	// Recordset Selected event
	function Recordset_Selected(&$rs) {

		//echo "Recordset Selected";
	}

	// Recordset Search Validated event
	function Recordset_SearchValidated() {

		// Example:
		//$this->MyField1->AdvancedSearch->SearchValue = "your search criteria"; // Search value

	}

	// Recordset Searching event
	function Recordset_Searching(&$filter) {

		// Enter your code here
	}

	// Row_Selecting event
	function Row_Selecting(&$filter) {

		// Enter your code here
	}

	// Row Selected event
	function Row_Selected(&$rs) {

		//echo "Row Selected";
	}

	// Row Inserting event
	function Row_Inserting($rsold, &$rsnew) {

		// Enter your code here
		// To cancel, set return value to FALSE

		return TRUE;
	}

	// Row Inserted event
	function Row_Inserted($rsold, &$rsnew) {

		//echo "Row Inserted"
	}

	// Row Updating event
	function Row_Updating($rsold, &$rsnew) {

		// Enter your code here
		// To cancel, set return value to FALSE

		return TRUE;
	}

	// Row Updated event
	function Row_Updated($rsold, &$rsnew) {

		//echo "Row Updated";
	}

	// Row Update Conflict event
	function Row_UpdateConflict($rsold, &$rsnew) {

		// Enter your code here
		// To ignore conflict, set return value to FALSE

		return TRUE;
	}

	// Grid Inserting event
	function Grid_Inserting() {

		// Enter your code here
		// To reject grid insert, set return value to FALSE

		return TRUE;
	}

	// Grid Inserted event
	function Grid_Inserted($rsnew) {

		//echo "Grid Inserted";
	}

	// Grid Updating event
	function Grid_Updating($rsold) {

		// Enter your code here
		// To reject grid update, set return value to FALSE

		return TRUE;
	}

	// Grid Updated event
	function Grid_Updated($rsold, $rsnew) {

		//echo "Grid Updated";
	}

	// Row Deleting event
	function Row_Deleting(&$rs) {

		// Enter your code here
		// To cancel, set return value to False

		return TRUE;
	}

	// Row Deleted event
	function Row_Deleted(&$rs) {

		//echo "Row Deleted";
	}

	// Email Sending event
	function Email_Sending($email, &$args) {

		//var_dump($email); var_dump($args); exit();
		return TRUE;
	}

	// Lookup Selecting event
	function Lookup_Selecting($fld, &$filter) {

		//var_dump($fld->Name, $fld->Lookup, $filter); // Uncomment to view the filter
		// Enter your code here

	}

	// Row Rendering event
	function Row_Rendering() {

		// Enter your code here
	}

	// Row Rendered event
	function Row_Rendered() {

		// To view properties of field class, use:
		//var_dump($this-><FieldName>);

	}

	// User ID Filtering event
	function UserID_Filtering(&$filter) {

		// Enter your code here
	}
}
?>