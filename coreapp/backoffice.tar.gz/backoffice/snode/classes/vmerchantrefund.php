<?php namespace PHPMaker2020\_4payadmin; ?>
<?php

/**
 * Table class for vmerchantrefund
 */
class vmerchantrefund extends DbTable
{
	protected $SqlFrom = "";
	protected $SqlSelect = "";
	protected $SqlSelectList = "";
	protected $SqlWhere = "";
	protected $SqlGroupBy = "";
	protected $SqlHaving = "";
	protected $SqlOrderBy = "";
	public $UseSessionForListSql = TRUE;

	// Column CSS classes
	public $LeftColumnClass = "col-sm-2 col-form-label ew-label";
	public $RightColumnClass = "col-sm-10";
	public $OffsetColumnClass = "col-sm-10 offset-sm-2";
	public $TableLeftColumnClass = "w-col-2";

	// Export
	public $ExportDoc;

	// Fields
	public $transferID;
	public $merchantid;
	public $txid;
	public $returnTime;
	public $merchantSurcharge;
	public $currID;
	public $purchaseAmount;
	public $taxAmount;
	public $tipAmount;
	public $serviceFeeToCustomer;
	public $TotalAmountForCustomer;
	public $serviceFeeToMerchant;
	public $merchantRefID;
	public $feesystemshare;
	public $feeexternalshare;
	public $feefranchiseeshare;
	public $feeresellershare;
	public $userpiid;
	public $businessname;
	public $originalpurchaseamount;
	public $transferTime;
	public $merchantuserid;
	public $firstName;
	public $lastName;
	public $customerpurchaseid;

	// Constructor
	public function __construct()
	{
		global $Language, $CurrentLanguage;
		parent::__construct();

		// Language object
		if (!isset($Language))
			$Language = new Language();
		$this->TableVar = 'vmerchantrefund';
		$this->TableName = 'vmerchantrefund';
		$this->TableType = 'VIEW';

		// Update Table
		$this->UpdateTable = "`vmerchantrefund`";
		$this->Dbid = 'DB';
		$this->ExportAll = TRUE;
		$this->ExportPageBreakCount = 0; // Page break per every n record (PDF only)
		$this->ExportPageOrientation = "portrait"; // Page orientation (PDF only)
		$this->ExportPageSize = "a4"; // Page size (PDF only)
		$this->ExportExcelPageOrientation = \PhpOffice\PhpSpreadsheet\Worksheet\PageSetup::ORIENTATION_DEFAULT; // Page orientation (PhpSpreadsheet only)
		$this->ExportExcelPageSize = \PhpOffice\PhpSpreadsheet\Worksheet\PageSetup::PAPERSIZE_A4; // Page size (PhpSpreadsheet only)
		$this->ExportWordPageOrientation = "portrait"; // Page orientation (PHPWord only)
		$this->ExportWordColumnWidth = NULL; // Cell width (PHPWord only)
		$this->DetailAdd = FALSE; // Allow detail add
		$this->DetailEdit = FALSE; // Allow detail edit
		$this->DetailView = FALSE; // Allow detail view
		$this->ShowMultipleDetails = FALSE; // Show multiple details
		$this->GridAddRowCount = 5;
		$this->AllowAddDeleteRow = TRUE; // Allow add/delete row
		$this->UserIDAllowSecurity = Config("DEFAULT_USER_ID_ALLOW_SECURITY"); // Default User ID allowed permissions
		$this->BasicSearch = new BasicSearch($this->TableVar);

		// transferID
		$this->transferID = new DbField('vmerchantrefund', 'vmerchantrefund', 'x_transferID', 'transferID', '`transferID`', '`transferID`', 3, 12, -1, FALSE, '`transferID`', FALSE, FALSE, FALSE, 'FORMATTED TEXT', 'TEXT');
		$this->transferID->IsPrimaryKey = TRUE; // Primary key field
		$this->transferID->Nullable = FALSE; // NOT NULL field
		$this->transferID->Required = TRUE; // Required field
		$this->transferID->Sortable = TRUE; // Allow sort
		$this->transferID->DefaultErrorMessage = $Language->phrase("IncorrectInteger");
		$this->fields['transferID'] = &$this->transferID;

		// merchantid
		$this->merchantid = new DbField('vmerchantrefund', 'vmerchantrefund', 'x_merchantid', 'merchantid', '`merchantid`', '`merchantid`', 20, 12, -1, FALSE, '`merchantid`', FALSE, FALSE, FALSE, 'FORMATTED TEXT', 'TEXT');
		$this->merchantid->Nullable = FALSE; // NOT NULL field
		$this->merchantid->Sortable = TRUE; // Allow sort
		$this->merchantid->DefaultErrorMessage = $Language->phrase("IncorrectInteger");
		$this->fields['merchantid'] = &$this->merchantid;

		// txid
		$this->txid = new DbField('vmerchantrefund', 'vmerchantrefund', 'x_txid', 'txid', '`txid`', '`txid`', 200, 10, -1, FALSE, '`txid`', FALSE, FALSE, FALSE, 'FORMATTED TEXT', 'TEXT');
		$this->txid->IsPrimaryKey = TRUE; // Primary key field
		$this->txid->Nullable = FALSE; // NOT NULL field
		$this->txid->Required = TRUE; // Required field
		$this->txid->Sortable = TRUE; // Allow sort
		$this->fields['txid'] = &$this->txid;

		// returnTime
		$this->returnTime = new DbField('vmerchantrefund', 'vmerchantrefund', 'x_returnTime', 'returnTime', '`returnTime`', CastDateFieldForLike("`returnTime`", 0, "DB"), 135, 19, 0, FALSE, '`returnTime`', FALSE, FALSE, FALSE, 'FORMATTED TEXT', 'TEXT');
		$this->returnTime->IsPrimaryKey = TRUE; // Primary key field
		$this->returnTime->Sortable = TRUE; // Allow sort
		$this->returnTime->DefaultErrorMessage = str_replace("%s", $GLOBALS["DATE_FORMAT"], $Language->phrase("IncorrectDate"));
		$this->fields['returnTime'] = &$this->returnTime;

		// merchantSurcharge
		$this->merchantSurcharge = new DbField('vmerchantrefund', 'vmerchantrefund', 'x_merchantSurcharge', 'merchantSurcharge', '`merchantSurcharge`', '`merchantSurcharge`', 131, 20, -1, FALSE, '`merchantSurcharge`', FALSE, FALSE, FALSE, 'FORMATTED TEXT', 'TEXT');
		$this->merchantSurcharge->Nullable = FALSE; // NOT NULL field
		$this->merchantSurcharge->Sortable = TRUE; // Allow sort
		$this->merchantSurcharge->DefaultErrorMessage = $Language->phrase("IncorrectFloat");
		$this->fields['merchantSurcharge'] = &$this->merchantSurcharge;

		// currID
		$this->currID = new DbField('vmerchantrefund', 'vmerchantrefund', 'x_currID', 'currID', '`currID`', '`currID`', 200, 3, -1, FALSE, '`currID`', FALSE, FALSE, FALSE, 'FORMATTED TEXT', 'TEXT');
		$this->currID->Nullable = FALSE; // NOT NULL field
		$this->currID->Required = TRUE; // Required field
		$this->currID->Sortable = TRUE; // Allow sort
		$this->fields['currID'] = &$this->currID;

		// purchaseAmount
		$this->purchaseAmount = new DbField('vmerchantrefund', 'vmerchantrefund', 'x_purchaseAmount', 'purchaseAmount', '`purchaseAmount`', '`purchaseAmount`', 131, 20, -1, FALSE, '`purchaseAmount`', FALSE, FALSE, FALSE, 'FORMATTED TEXT', 'TEXT');
		$this->purchaseAmount->Nullable = FALSE; // NOT NULL field
		$this->purchaseAmount->Sortable = TRUE; // Allow sort
		$this->purchaseAmount->DefaultErrorMessage = $Language->phrase("IncorrectFloat");
		$this->fields['purchaseAmount'] = &$this->purchaseAmount;

		// taxAmount
		$this->taxAmount = new DbField('vmerchantrefund', 'vmerchantrefund', 'x_taxAmount', 'taxAmount', '`taxAmount`', '`taxAmount`', 131, 20, -1, FALSE, '`taxAmount`', FALSE, FALSE, FALSE, 'FORMATTED TEXT', 'TEXT');
		$this->taxAmount->Nullable = FALSE; // NOT NULL field
		$this->taxAmount->Sortable = TRUE; // Allow sort
		$this->taxAmount->DefaultErrorMessage = $Language->phrase("IncorrectFloat");
		$this->fields['taxAmount'] = &$this->taxAmount;

		// tipAmount
		$this->tipAmount = new DbField('vmerchantrefund', 'vmerchantrefund', 'x_tipAmount', 'tipAmount', '`tipAmount`', '`tipAmount`', 131, 20, -1, FALSE, '`tipAmount`', FALSE, FALSE, FALSE, 'FORMATTED TEXT', 'TEXT');
		$this->tipAmount->Nullable = FALSE; // NOT NULL field
		$this->tipAmount->Sortable = TRUE; // Allow sort
		$this->tipAmount->DefaultErrorMessage = $Language->phrase("IncorrectFloat");
		$this->fields['tipAmount'] = &$this->tipAmount;

		// serviceFeeToCustomer
		$this->serviceFeeToCustomer = new DbField('vmerchantrefund', 'vmerchantrefund', 'x_serviceFeeToCustomer', 'serviceFeeToCustomer', '`serviceFeeToCustomer`', '`serviceFeeToCustomer`', 131, 20, -1, FALSE, '`serviceFeeToCustomer`', FALSE, FALSE, FALSE, 'FORMATTED TEXT', 'TEXT');
		$this->serviceFeeToCustomer->Nullable = FALSE; // NOT NULL field
		$this->serviceFeeToCustomer->Sortable = TRUE; // Allow sort
		$this->serviceFeeToCustomer->DefaultErrorMessage = $Language->phrase("IncorrectFloat");
		$this->fields['serviceFeeToCustomer'] = &$this->serviceFeeToCustomer;

		// TotalAmountForCustomer
		$this->TotalAmountForCustomer = new DbField('vmerchantrefund', 'vmerchantrefund', 'x_TotalAmountForCustomer', 'TotalAmountForCustomer', '`TotalAmountForCustomer`', '`TotalAmountForCustomer`', 131, 20, -1, FALSE, '`TotalAmountForCustomer`', FALSE, FALSE, FALSE, 'FORMATTED TEXT', 'TEXT');
		$this->TotalAmountForCustomer->Nullable = FALSE; // NOT NULL field
		$this->TotalAmountForCustomer->Sortable = TRUE; // Allow sort
		$this->TotalAmountForCustomer->DefaultErrorMessage = $Language->phrase("IncorrectFloat");
		$this->fields['TotalAmountForCustomer'] = &$this->TotalAmountForCustomer;

		// serviceFeeToMerchant
		$this->serviceFeeToMerchant = new DbField('vmerchantrefund', 'vmerchantrefund', 'x_serviceFeeToMerchant', 'serviceFeeToMerchant', '`serviceFeeToMerchant`', '`serviceFeeToMerchant`', 131, 20, -1, FALSE, '`serviceFeeToMerchant`', FALSE, FALSE, FALSE, 'FORMATTED TEXT', 'TEXT');
		$this->serviceFeeToMerchant->Nullable = FALSE; // NOT NULL field
		$this->serviceFeeToMerchant->Sortable = TRUE; // Allow sort
		$this->serviceFeeToMerchant->DefaultErrorMessage = $Language->phrase("IncorrectFloat");
		$this->fields['serviceFeeToMerchant'] = &$this->serviceFeeToMerchant;

		// merchantRefID
		$this->merchantRefID = new DbField('vmerchantrefund', 'vmerchantrefund', 'x_merchantRefID', 'merchantRefID', '`merchantRefID`', '`merchantRefID`', 200, 20, -1, FALSE, '`merchantRefID`', FALSE, FALSE, FALSE, 'FORMATTED TEXT', 'TEXT');
		$this->merchantRefID->Sortable = TRUE; // Allow sort
		$this->fields['merchantRefID'] = &$this->merchantRefID;

		// feesystemshare
		$this->feesystemshare = new DbField('vmerchantrefund', 'vmerchantrefund', 'x_feesystemshare', 'feesystemshare', '`feesystemshare`', '`feesystemshare`', 131, 20, -1, FALSE, '`feesystemshare`', FALSE, FALSE, FALSE, 'FORMATTED TEXT', 'TEXT');
		$this->feesystemshare->Nullable = FALSE; // NOT NULL field
		$this->feesystemshare->Sortable = TRUE; // Allow sort
		$this->feesystemshare->DefaultErrorMessage = $Language->phrase("IncorrectFloat");
		$this->fields['feesystemshare'] = &$this->feesystemshare;

		// feeexternalshare
		$this->feeexternalshare = new DbField('vmerchantrefund', 'vmerchantrefund', 'x_feeexternalshare', 'feeexternalshare', '`feeexternalshare`', '`feeexternalshare`', 131, 20, -1, FALSE, '`feeexternalshare`', FALSE, FALSE, FALSE, 'FORMATTED TEXT', 'TEXT');
		$this->feeexternalshare->Nullable = FALSE; // NOT NULL field
		$this->feeexternalshare->Required = TRUE; // Required field
		$this->feeexternalshare->Sortable = TRUE; // Allow sort
		$this->feeexternalshare->DefaultErrorMessage = $Language->phrase("IncorrectFloat");
		$this->fields['feeexternalshare'] = &$this->feeexternalshare;

		// feefranchiseeshare
		$this->feefranchiseeshare = new DbField('vmerchantrefund', 'vmerchantrefund', 'x_feefranchiseeshare', 'feefranchiseeshare', '`feefranchiseeshare`', '`feefranchiseeshare`', 131, 20, -1, FALSE, '`feefranchiseeshare`', FALSE, FALSE, FALSE, 'FORMATTED TEXT', 'TEXT');
		$this->feefranchiseeshare->Nullable = FALSE; // NOT NULL field
		$this->feefranchiseeshare->Required = TRUE; // Required field
		$this->feefranchiseeshare->Sortable = TRUE; // Allow sort
		$this->feefranchiseeshare->DefaultErrorMessage = $Language->phrase("IncorrectFloat");
		$this->fields['feefranchiseeshare'] = &$this->feefranchiseeshare;

		// feeresellershare
		$this->feeresellershare = new DbField('vmerchantrefund', 'vmerchantrefund', 'x_feeresellershare', 'feeresellershare', '`feeresellershare`', '`feeresellershare`', 131, 20, -1, FALSE, '`feeresellershare`', FALSE, FALSE, FALSE, 'FORMATTED TEXT', 'TEXT');
		$this->feeresellershare->Nullable = FALSE; // NOT NULL field
		$this->feeresellershare->Required = TRUE; // Required field
		$this->feeresellershare->Sortable = TRUE; // Allow sort
		$this->feeresellershare->DefaultErrorMessage = $Language->phrase("IncorrectFloat");
		$this->fields['feeresellershare'] = &$this->feeresellershare;

		// userpiid
		$this->userpiid = new DbField('vmerchantrefund', 'vmerchantrefund', 'x_userpiid', 'userpiid', '`userpiid`', '`userpiid`', 3, 5, -1, FALSE, '`userpiid`', FALSE, FALSE, FALSE, 'FORMATTED TEXT', 'TEXT');
		$this->userpiid->Sortable = TRUE; // Allow sort
		$this->userpiid->DefaultErrorMessage = $Language->phrase("IncorrectInteger");
		$this->fields['userpiid'] = &$this->userpiid;

		// businessname
		$this->businessname = new DbField('vmerchantrefund', 'vmerchantrefund', 'x_businessname', 'businessname', '`businessname`', '`businessname`', 200, 60, -1, FALSE, '`businessname`', FALSE, FALSE, FALSE, 'FORMATTED TEXT', 'TEXT');
		$this->businessname->Nullable = FALSE; // NOT NULL field
		$this->businessname->Required = TRUE; // Required field
		$this->businessname->Sortable = TRUE; // Allow sort
		$this->fields['businessname'] = &$this->businessname;

		// originalpurchaseamount
		$this->originalpurchaseamount = new DbField('vmerchantrefund', 'vmerchantrefund', 'x_originalpurchaseamount', 'originalpurchaseamount', '`originalpurchaseamount`', '`originalpurchaseamount`', 131, 20, -1, FALSE, '`originalpurchaseamount`', FALSE, FALSE, FALSE, 'FORMATTED TEXT', 'TEXT');
		$this->originalpurchaseamount->Nullable = FALSE; // NOT NULL field
		$this->originalpurchaseamount->Sortable = TRUE; // Allow sort
		$this->originalpurchaseamount->DefaultErrorMessage = $Language->phrase("IncorrectFloat");
		$this->fields['originalpurchaseamount'] = &$this->originalpurchaseamount;

		// transferTime
		$this->transferTime = new DbField('vmerchantrefund', 'vmerchantrefund', 'x_transferTime', 'transferTime', '`transferTime`', CastDateFieldForLike("`transferTime`", 0, "DB"), 135, 19, 0, FALSE, '`transferTime`', FALSE, FALSE, FALSE, 'FORMATTED TEXT', 'TEXT');
		$this->transferTime->Sortable = TRUE; // Allow sort
		$this->transferTime->DefaultErrorMessage = str_replace("%s", $GLOBALS["DATE_FORMAT"], $Language->phrase("IncorrectDate"));
		$this->fields['transferTime'] = &$this->transferTime;

		// merchantuserid
		$this->merchantuserid = new DbField('vmerchantrefund', 'vmerchantrefund', 'x_merchantuserid', 'merchantuserid', '`merchantuserid`', '`merchantuserid`', 20, 12, -1, FALSE, '`merchantuserid`', FALSE, FALSE, FALSE, 'FORMATTED TEXT', 'TEXT');
		$this->merchantuserid->Nullable = FALSE; // NOT NULL field
		$this->merchantuserid->Sortable = TRUE; // Allow sort
		$this->merchantuserid->DefaultErrorMessage = $Language->phrase("IncorrectInteger");
		$this->fields['merchantuserid'] = &$this->merchantuserid;

		// firstName
		$this->firstName = new DbField('vmerchantrefund', 'vmerchantrefund', 'x_firstName', 'firstName', '`firstName`', '`firstName`', 200, 60, -1, FALSE, '`firstName`', FALSE, FALSE, FALSE, 'FORMATTED TEXT', 'TEXT');
		$this->firstName->Nullable = FALSE; // NOT NULL field
		$this->firstName->Required = TRUE; // Required field
		$this->firstName->Sortable = TRUE; // Allow sort
		$this->fields['firstName'] = &$this->firstName;

		// lastName
		$this->lastName = new DbField('vmerchantrefund', 'vmerchantrefund', 'x_lastName', 'lastName', '`lastName`', '`lastName`', 200, 60, -1, FALSE, '`lastName`', FALSE, FALSE, FALSE, 'FORMATTED TEXT', 'TEXT');
		$this->lastName->Nullable = FALSE; // NOT NULL field
		$this->lastName->Required = TRUE; // Required field
		$this->lastName->Sortable = TRUE; // Allow sort
		$this->fields['lastName'] = &$this->lastName;

		// customerpurchaseid
		$this->customerpurchaseid = new DbField('vmerchantrefund', 'vmerchantrefund', 'x_customerpurchaseid', 'customerpurchaseid', '`customerpurchaseid`', '`customerpurchaseid`', 20, 15, -1, FALSE, '`customerpurchaseid`', FALSE, FALSE, FALSE, 'FORMATTED TEXT', 'TEXT');
		$this->customerpurchaseid->Nullable = FALSE; // NOT NULL field
		$this->customerpurchaseid->Sortable = TRUE; // Allow sort
		$this->customerpurchaseid->DefaultErrorMessage = $Language->phrase("IncorrectInteger");
		$this->fields['customerpurchaseid'] = &$this->customerpurchaseid;
	}

	// Field Visibility
	public function getFieldVisibility($fldParm)
	{
		global $Security;
		return $this->$fldParm->Visible; // Returns original value
	}

	// Set left column class (must be predefined col-*-* classes of Bootstrap grid system)
	function setLeftColumnClass($class)
	{
		if (preg_match('/^col\-(\w+)\-(\d+)$/', $class, $match)) {
			$this->LeftColumnClass = $class . " col-form-label ew-label";
			$this->RightColumnClass = "col-" . $match[1] . "-" . strval(12 - (int)$match[2]);
			$this->OffsetColumnClass = $this->RightColumnClass . " " . str_replace("col-", "offset-", $class);
			$this->TableLeftColumnClass = preg_replace('/^col-\w+-(\d+)$/', "w-col-$1", $class); // Change to w-col-*
		}
	}

	// Single column sort
	public function updateSort(&$fld)
	{
		if ($this->CurrentOrder == $fld->Name) {
			$sortField = $fld->Expression;
			$lastSort = $fld->getSort();
			if ($this->CurrentOrderType == "ASC" || $this->CurrentOrderType == "DESC") {
				$thisSort = $this->CurrentOrderType;
			} else {
				$thisSort = ($lastSort == "ASC") ? "DESC" : "ASC";
			}
			$fld->setSort($thisSort);
			$this->setSessionOrderBy($sortField . " " . $thisSort); // Save to Session
		} else {
			$fld->setSort("");
		}
	}

	// Table level SQL
	public function getSqlFrom() // From
	{
		return ($this->SqlFrom != "") ? $this->SqlFrom : "`vmerchantrefund`";
	}
	public function sqlFrom() // For backward compatibility
	{
		return $this->getSqlFrom();
	}
	public function setSqlFrom($v)
	{
		$this->SqlFrom = $v;
	}
	public function getSqlSelect() // Select
	{
		return ($this->SqlSelect != "") ? $this->SqlSelect : "SELECT * FROM " . $this->getSqlFrom();
	}
	public function sqlSelect() // For backward compatibility
	{
		return $this->getSqlSelect();
	}
	public function setSqlSelect($v)
	{
		$this->SqlSelect = $v;
	}
	public function getSqlWhere() // Where
	{
		$where = ($this->SqlWhere != "") ? $this->SqlWhere : "";
		$this->TableFilter = "";
		AddFilter($where, $this->TableFilter);
		return $where;
	}
	public function sqlWhere() // For backward compatibility
	{
		return $this->getSqlWhere();
	}
	public function setSqlWhere($v)
	{
		$this->SqlWhere = $v;
	}
	public function getSqlGroupBy() // Group By
	{
		return ($this->SqlGroupBy != "") ? $this->SqlGroupBy : "";
	}
	public function sqlGroupBy() // For backward compatibility
	{
		return $this->getSqlGroupBy();
	}
	public function setSqlGroupBy($v)
	{
		$this->SqlGroupBy = $v;
	}
	public function getSqlHaving() // Having
	{
		return ($this->SqlHaving != "") ? $this->SqlHaving : "";
	}
	public function sqlHaving() // For backward compatibility
	{
		return $this->getSqlHaving();
	}
	public function setSqlHaving($v)
	{
		$this->SqlHaving = $v;
	}
	public function getSqlOrderBy() // Order By
	{
		return ($this->SqlOrderBy != "") ? $this->SqlOrderBy : "";
	}
	public function sqlOrderBy() // For backward compatibility
	{
		return $this->getSqlOrderBy();
	}
	public function setSqlOrderBy($v)
	{
		$this->SqlOrderBy = $v;
	}

	// Apply User ID filters
	public function applyUserIDFilters($filter, $id = "")
	{
		return $filter;
	}

	// Check if User ID security allows view all
	public function userIDAllow($id = "")
	{
		$allow = $this->UserIDAllowSecurity;
		switch ($id) {
			case "add":
			case "copy":
			case "gridadd":
			case "register":
			case "addopt":
				return (($allow & 1) == 1);
			case "edit":
			case "gridedit":
			case "update":
			case "changepwd":
			case "forgotpwd":
				return (($allow & 4) == 4);
			case "delete":
				return (($allow & 2) == 2);
			case "view":
				return (($allow & 32) == 32);
			case "search":
				return (($allow & 64) == 64);
			case "lookup":
				return (($allow & 256) == 256);
			default:
				return (($allow & 8) == 8);
		}
	}

	// Get recordset
	public function getRecordset($sql, $rowcnt = -1, $offset = -1)
	{
		$conn = $this->getConnection();
		$conn->raiseErrorFn = Config("ERROR_FUNC");
		$rs = $conn->selectLimit($sql, $rowcnt, $offset);
		$conn->raiseErrorFn = "";
		return $rs;
	}

	// Get record count
	public function getRecordCount($sql, $c = NULL)
	{
		$cnt = -1;
		$rs = NULL;
		$sql = preg_replace('/\/\*BeginOrderBy\*\/[\s\S]+\/\*EndOrderBy\*\//', "", $sql); // Remove ORDER BY clause (MSSQL)
		$pattern = '/^SELECT\s([\s\S]+)\sFROM\s/i';

		// Skip Custom View / SubQuery / SELECT DISTINCT / ORDER BY
		if (($this->TableType == 'TABLE' || $this->TableType == 'VIEW' || $this->TableType == 'LINKTABLE') &&
			preg_match($pattern, $sql) && !preg_match('/\(\s*(SELECT[^)]+)\)/i', $sql) &&
			!preg_match('/^\s*select\s+distinct\s+/i', $sql) && !preg_match('/\s+order\s+by\s+/i', $sql)) {
			$sqlwrk = "SELECT COUNT(*) FROM " . preg_replace($pattern, "", $sql);
		} else {
			$sqlwrk = "SELECT COUNT(*) FROM (" . $sql . ") COUNT_TABLE";
		}
		$conn = $c ?: $this->getConnection();
		if ($rs = $conn->execute($sqlwrk)) {
			if (!$rs->EOF && $rs->FieldCount() > 0) {
				$cnt = $rs->fields[0];
				$rs->close();
			}
			return (int)$cnt;
		}

		// Unable to get count, get record count directly
		if ($rs = $conn->execute($sql)) {
			$cnt = $rs->RecordCount();
			$rs->close();
			return (int)$cnt;
		}
		return $cnt;
	}

	// Get SQL
	public function getSql($where, $orderBy = "")
	{
		return BuildSelectSql($this->getSqlSelect(), $this->getSqlWhere(),
			$this->getSqlGroupBy(), $this->getSqlHaving(), $this->getSqlOrderBy(),
			$where, $orderBy);
	}

	// Table SQL
	public function getCurrentSql()
	{
		$filter = $this->CurrentFilter;
		$filter = $this->applyUserIDFilters($filter);
		$sort = $this->getSessionOrderBy();
		return $this->getSql($filter, $sort);
	}

	// Table SQL with List page filter
	public function getListSql()
	{
		$filter = $this->UseSessionForListSql ? $this->getSessionWhere() : "";
		AddFilter($filter, $this->CurrentFilter);
		$filter = $this->applyUserIDFilters($filter);
		$this->Recordset_Selecting($filter);
		$select = $this->getSqlSelect();
		$sort = $this->UseSessionForListSql ? $this->getSessionOrderBy() : "";
		return BuildSelectSql($select, $this->getSqlWhere(), $this->getSqlGroupBy(),
			$this->getSqlHaving(), $this->getSqlOrderBy(), $filter, $sort);
	}

	// Get ORDER BY clause
	public function getOrderBy()
	{
		$sort = $this->getSessionOrderBy();
		return BuildSelectSql("", "", "", "", $this->getSqlOrderBy(), "", $sort);
	}

	// Get record count based on filter (for detail record count in master table pages)
	public function loadRecordCount($filter)
	{
		$origFilter = $this->CurrentFilter;
		$this->CurrentFilter = $filter;
		$this->Recordset_Selecting($this->CurrentFilter);
		$select = $this->TableType == 'CUSTOMVIEW' ? $this->getSqlSelect() : "SELECT * FROM " . $this->getSqlFrom();
		$groupBy = $this->TableType == 'CUSTOMVIEW' ? $this->getSqlGroupBy() : "";
		$having = $this->TableType == 'CUSTOMVIEW' ? $this->getSqlHaving() : "";
		$sql = BuildSelectSql($select, $this->getSqlWhere(), $groupBy, $having, "", $this->CurrentFilter, "");
		$cnt = $this->getRecordCount($sql);
		$this->CurrentFilter = $origFilter;
		return $cnt;
	}

	// Get record count (for current List page)
	public function listRecordCount()
	{
		$filter = $this->getSessionWhere();
		AddFilter($filter, $this->CurrentFilter);
		$filter = $this->applyUserIDFilters($filter);
		$this->Recordset_Selecting($filter);
		$select = $this->TableType == 'CUSTOMVIEW' ? $this->getSqlSelect() : "SELECT * FROM " . $this->getSqlFrom();
		$groupBy = $this->TableType == 'CUSTOMVIEW' ? $this->getSqlGroupBy() : "";
		$having = $this->TableType == 'CUSTOMVIEW' ? $this->getSqlHaving() : "";
		$sql = BuildSelectSql($select, $this->getSqlWhere(), $groupBy, $having, "", $filter, "");
		$cnt = $this->getRecordCount($sql);
		return $cnt;
	}

	// INSERT statement
	protected function insertSql(&$rs)
	{
		$names = "";
		$values = "";
		foreach ($rs as $name => $value) {
			if (!isset($this->fields[$name]) || $this->fields[$name]->IsCustom)
				continue;
			$names .= $this->fields[$name]->Expression . ",";
			$values .= QuotedValue($value, $this->fields[$name]->DataType, $this->Dbid) . ",";
		}
		$names = preg_replace('/,+$/', "", $names);
		$values = preg_replace('/,+$/', "", $values);
		return "INSERT INTO " . $this->UpdateTable . " (" . $names . ") VALUES (" . $values . ")";
	}

	// Insert
	public function insert(&$rs)
	{
		$conn = $this->getConnection();
		$success = $conn->execute($this->insertSql($rs));
		if ($success) {
		}
		return $success;
	}

	// UPDATE statement
	protected function updateSql(&$rs, $where = "", $curfilter = TRUE)
	{
		$sql = "UPDATE " . $this->UpdateTable . " SET ";
		foreach ($rs as $name => $value) {
			if (!isset($this->fields[$name]) || $this->fields[$name]->IsCustom || $this->fields[$name]->IsAutoIncrement)
				continue;
			$sql .= $this->fields[$name]->Expression . "=";
			$sql .= QuotedValue($value, $this->fields[$name]->DataType, $this->Dbid) . ",";
		}
		$sql = preg_replace('/,+$/', "", $sql);
		$filter = ($curfilter) ? $this->CurrentFilter : "";
		if (is_array($where))
			$where = $this->arrayToFilter($where);
		AddFilter($filter, $where);
		if ($filter != "")
			$sql .= " WHERE " . $filter;
		return $sql;
	}

	// Update
	public function update(&$rs, $where = "", $rsold = NULL, $curfilter = TRUE)
	{
		$conn = $this->getConnection();
		$success = $conn->execute($this->updateSql($rs, $where, $curfilter));
		return $success;
	}

	// DELETE statement
	protected function deleteSql(&$rs, $where = "", $curfilter = TRUE)
	{
		$sql = "DELETE FROM " . $this->UpdateTable . " WHERE ";
		if (is_array($where))
			$where = $this->arrayToFilter($where);
		if ($rs) {
			if (array_key_exists('transferID', $rs))
				AddFilter($where, QuotedName('transferID', $this->Dbid) . '=' . QuotedValue($rs['transferID'], $this->transferID->DataType, $this->Dbid));
			if (array_key_exists('txid', $rs))
				AddFilter($where, QuotedName('txid', $this->Dbid) . '=' . QuotedValue($rs['txid'], $this->txid->DataType, $this->Dbid));
			if (array_key_exists('returnTime', $rs))
				AddFilter($where, QuotedName('returnTime', $this->Dbid) . '=' . QuotedValue($rs['returnTime'], $this->returnTime->DataType, $this->Dbid));
		}
		$filter = ($curfilter) ? $this->CurrentFilter : "";
		AddFilter($filter, $where);
		if ($filter != "")
			$sql .= $filter;
		else
			$sql .= "0=1"; // Avoid delete
		return $sql;
	}

	// Delete
	public function delete(&$rs, $where = "", $curfilter = FALSE)
	{
		$success = TRUE;
		$conn = $this->getConnection();
		if ($success)
			$success = $conn->execute($this->deleteSql($rs, $where, $curfilter));
		return $success;
	}

	// Load DbValue from recordset or array
	protected function loadDbValues(&$rs)
	{
		if (!$rs || !is_array($rs) && $rs->EOF)
			return;
		$row = is_array($rs) ? $rs : $rs->fields;
		$this->transferID->DbValue = $row['transferID'];
		$this->merchantid->DbValue = $row['merchantid'];
		$this->txid->DbValue = $row['txid'];
		$this->returnTime->DbValue = $row['returnTime'];
		$this->merchantSurcharge->DbValue = $row['merchantSurcharge'];
		$this->currID->DbValue = $row['currID'];
		$this->purchaseAmount->DbValue = $row['purchaseAmount'];
		$this->taxAmount->DbValue = $row['taxAmount'];
		$this->tipAmount->DbValue = $row['tipAmount'];
		$this->serviceFeeToCustomer->DbValue = $row['serviceFeeToCustomer'];
		$this->TotalAmountForCustomer->DbValue = $row['TotalAmountForCustomer'];
		$this->serviceFeeToMerchant->DbValue = $row['serviceFeeToMerchant'];
		$this->merchantRefID->DbValue = $row['merchantRefID'];
		$this->feesystemshare->DbValue = $row['feesystemshare'];
		$this->feeexternalshare->DbValue = $row['feeexternalshare'];
		$this->feefranchiseeshare->DbValue = $row['feefranchiseeshare'];
		$this->feeresellershare->DbValue = $row['feeresellershare'];
		$this->userpiid->DbValue = $row['userpiid'];
		$this->businessname->DbValue = $row['businessname'];
		$this->originalpurchaseamount->DbValue = $row['originalpurchaseamount'];
		$this->transferTime->DbValue = $row['transferTime'];
		$this->merchantuserid->DbValue = $row['merchantuserid'];
		$this->firstName->DbValue = $row['firstName'];
		$this->lastName->DbValue = $row['lastName'];
		$this->customerpurchaseid->DbValue = $row['customerpurchaseid'];
	}

	// Delete uploaded files
	public function deleteUploadedFiles($row)
	{
		$this->loadDbValues($row);
	}

	// Record filter WHERE clause
	protected function sqlKeyFilter()
	{
		return "`transferID` = @transferID@ AND `txid` = '@txid@' AND `returnTime` = '@returnTime@'";
	}

	// Get record filter
	public function getRecordFilter($row = NULL)
	{
		$keyFilter = $this->sqlKeyFilter();
		if (is_array($row))
			$val = array_key_exists('transferID', $row) ? $row['transferID'] : NULL;
		else
			$val = $this->transferID->OldValue !== NULL ? $this->transferID->OldValue : $this->transferID->CurrentValue;
		if (!is_numeric($val))
			return "0=1"; // Invalid key
		if ($val == NULL)
			return "0=1"; // Invalid key
		else
			$keyFilter = str_replace("@transferID@", AdjustSql($val, $this->Dbid), $keyFilter); // Replace key value
		if (is_array($row))
			$val = array_key_exists('txid', $row) ? $row['txid'] : NULL;
		else
			$val = $this->txid->OldValue !== NULL ? $this->txid->OldValue : $this->txid->CurrentValue;
		if ($val == NULL)
			return "0=1"; // Invalid key
		else
			$keyFilter = str_replace("@txid@", AdjustSql($val, $this->Dbid), $keyFilter); // Replace key value
		if (is_array($row))
			$val = array_key_exists('returnTime', $row) ? $row['returnTime'] : NULL;
		else
			$val = $this->returnTime->OldValue !== NULL ? $this->returnTime->OldValue : $this->returnTime->CurrentValue;
		if ($val == NULL)
			return "0=1"; // Invalid key
		else
			$keyFilter = str_replace("@returnTime@", AdjustSql(UnFormatDateTime($val, 0), $this->Dbid), $keyFilter); // Replace key value
		return $keyFilter;
	}

	// Return page URL
	public function getReturnUrl()
	{
		$name = PROJECT_NAME . "_" . $this->TableVar . "_" . Config("TABLE_RETURN_URL");

		// Get referer URL automatically
		if (ServerVar("HTTP_REFERER") != "" && ReferPageName() != CurrentPageName() && ReferPageName() != "login.php") // Referer not same page or login page
			$_SESSION[$name] = ServerVar("HTTP_REFERER"); // Save to Session
		if (@$_SESSION[$name] != "") {
			return $_SESSION[$name];
		} else {
			return "vmerchantrefundlist.php";
		}
	}
	public function setReturnUrl($v)
	{
		$_SESSION[PROJECT_NAME . "_" . $this->TableVar . "_" . Config("TABLE_RETURN_URL")] = $v;
	}

	// Get modal caption
	public function getModalCaption($pageName)
	{
		global $Language;
		if ($pageName == "vmerchantrefundview.php")
			return $Language->phrase("View");
		elseif ($pageName == "vmerchantrefundedit.php")
			return $Language->phrase("Edit");
		elseif ($pageName == "vmerchantrefundadd.php")
			return $Language->phrase("Add");
		else
			return "";
	}

	// List URL
	public function getListUrl()
	{
		return "vmerchantrefundlist.php";
	}

	// View URL
	public function getViewUrl($parm = "")
	{
		if ($parm != "")
			$url = $this->keyUrl("vmerchantrefundview.php", $this->getUrlParm($parm));
		else
			$url = $this->keyUrl("vmerchantrefundview.php", $this->getUrlParm(Config("TABLE_SHOW_DETAIL") . "="));
		return $this->addMasterUrl($url);
	}

	// Add URL
	public function getAddUrl($parm = "")
	{
		if ($parm != "")
			$url = "vmerchantrefundadd.php?" . $this->getUrlParm($parm);
		else
			$url = "vmerchantrefundadd.php";
		return $this->addMasterUrl($url);
	}

	// Edit URL
	public function getEditUrl($parm = "")
	{
		$url = $this->keyUrl("vmerchantrefundedit.php", $this->getUrlParm($parm));
		return $this->addMasterUrl($url);
	}

	// Inline edit URL
	public function getInlineEditUrl()
	{
		$url = $this->keyUrl(CurrentPageName(), $this->getUrlParm("action=edit"));
		return $this->addMasterUrl($url);
	}

	// Copy URL
	public function getCopyUrl($parm = "")
	{
		$url = $this->keyUrl("vmerchantrefundadd.php", $this->getUrlParm($parm));
		return $this->addMasterUrl($url);
	}

	// Inline copy URL
	public function getInlineCopyUrl()
	{
		$url = $this->keyUrl(CurrentPageName(), $this->getUrlParm("action=copy"));
		return $this->addMasterUrl($url);
	}

	// Delete URL
	public function getDeleteUrl()
	{
		return $this->keyUrl("vmerchantrefunddelete.php", $this->getUrlParm());
	}

	// Add master url
	public function addMasterUrl($url)
	{
		return $url;
	}
	public function keyToJson($htmlEncode = FALSE)
	{
		$json = "";
		$json .= "transferID:" . JsonEncode($this->transferID->CurrentValue, "number");
		$json .= ",txid:" . JsonEncode($this->txid->CurrentValue, "string");
		$json .= ",returnTime:" . JsonEncode($this->returnTime->CurrentValue, "string");
		$json = "{" . $json . "}";
		if ($htmlEncode)
			$json = HtmlEncode($json);
		return $json;
	}

	// Add key value to URL
	public function keyUrl($url, $parm = "")
	{
		$url = $url . "?";
		if ($parm != "")
			$url .= $parm . "&";
		if ($this->transferID->CurrentValue != NULL) {
			$url .= "transferID=" . urlencode($this->transferID->CurrentValue);
		} else {
			return "javascript:ew.alert(ew.language.phrase('InvalidRecord'));";
		}
		if ($this->txid->CurrentValue != NULL) {
			$url .= "&txid=" . urlencode($this->txid->CurrentValue);
		} else {
			return "javascript:ew.alert(ew.language.phrase('InvalidRecord'));";
		}
		if ($this->returnTime->CurrentValue != NULL) {
			$url .= "&returnTime=" . urlencode($this->returnTime->CurrentValue);
		} else {
			return "javascript:ew.alert(ew.language.phrase('InvalidRecord'));";
		}
		return $url;
	}

	// Sort URL
	public function sortUrl(&$fld)
	{
		if ($this->CurrentAction || $this->isExport() ||
			in_array($fld->Type, [128, 204, 205])) { // Unsortable data type
				return "";
		} elseif ($fld->Sortable) {
			$urlParm = $this->getUrlParm("order=" . urlencode($fld->Name) . "&amp;ordertype=" . $fld->reverseSort());
			return $this->addMasterUrl(CurrentPageName() . "?" . $urlParm);
		} else {
			return "";
		}
	}

	// Get record keys from Post/Get/Session
	public function getRecordKeys()
	{
		$arKeys = [];
		$arKey = [];
		if (Param("key_m") !== NULL) {
			$arKeys = Param("key_m");
			$cnt = count($arKeys);
			for ($i = 0; $i < $cnt; $i++)
				$arKeys[$i] = explode(Config("COMPOSITE_KEY_SEPARATOR"), $arKeys[$i]);
		} else {
			if (Param("transferID") !== NULL)
				$arKey[] = Param("transferID");
			elseif (IsApi() && Key(0) !== NULL)
				$arKey[] = Key(0);
			elseif (IsApi() && Route(2) !== NULL)
				$arKey[] = Route(2);
			else
				$arKeys = NULL; // Do not setup
			if (Param("txid") !== NULL)
				$arKey[] = Param("txid");
			elseif (IsApi() && Key(1) !== NULL)
				$arKey[] = Key(1);
			elseif (IsApi() && Route(3) !== NULL)
				$arKey[] = Route(3);
			else
				$arKeys = NULL; // Do not setup
			if (Param("returnTime") !== NULL)
				$arKey[] = Param("returnTime");
			elseif (IsApi() && Key(2) !== NULL)
				$arKey[] = Key(2);
			elseif (IsApi() && Route(4) !== NULL)
				$arKey[] = Route(4);
			else
				$arKeys = NULL; // Do not setup
			if (is_array($arKeys)) $arKeys[] = $arKey;

			//return $arKeys; // Do not return yet, so the values will also be checked by the following code
		}

		// Check keys
		$ar = [];
		if (is_array($arKeys)) {
			foreach ($arKeys as $key) {
				if (!is_array($key) || count($key) != 3)
					continue; // Just skip so other keys will still work
				if (!is_numeric($key[0])) // transferID
					continue;
				$ar[] = $key;
			}
		}
		return $ar;
	}

	// Get filter from record keys
	public function getFilterFromRecordKeys($setCurrent = TRUE)
	{
		$arKeys = $this->getRecordKeys();
		$keyFilter = "";
		foreach ($arKeys as $key) {
			if ($keyFilter != "") $keyFilter .= " OR ";
			if ($setCurrent)
				$this->transferID->CurrentValue = $key[0];
			else
				$this->transferID->OldValue = $key[0];
			if ($setCurrent)
				$this->txid->CurrentValue = $key[1];
			else
				$this->txid->OldValue = $key[1];
			if ($setCurrent)
				$this->returnTime->CurrentValue = $key[2];
			else
				$this->returnTime->OldValue = $key[2];
			$keyFilter .= "(" . $this->getRecordFilter() . ")";
		}
		return $keyFilter;
	}

	// Load rows based on filter
	public function &loadRs($filter)
	{

		// Set up filter (WHERE Clause)
		$sql = $this->getSql($filter);
		$conn = $this->getConnection();
		$rs = $conn->execute($sql);
		return $rs;
	}

	// Load row values from recordset
	public function loadListRowValues(&$rs)
	{
		$this->transferID->setDbValue($rs->fields('transferID'));
		$this->merchantid->setDbValue($rs->fields('merchantid'));
		$this->txid->setDbValue($rs->fields('txid'));
		$this->returnTime->setDbValue($rs->fields('returnTime'));
		$this->merchantSurcharge->setDbValue($rs->fields('merchantSurcharge'));
		$this->currID->setDbValue($rs->fields('currID'));
		$this->purchaseAmount->setDbValue($rs->fields('purchaseAmount'));
		$this->taxAmount->setDbValue($rs->fields('taxAmount'));
		$this->tipAmount->setDbValue($rs->fields('tipAmount'));
		$this->serviceFeeToCustomer->setDbValue($rs->fields('serviceFeeToCustomer'));
		$this->TotalAmountForCustomer->setDbValue($rs->fields('TotalAmountForCustomer'));
		$this->serviceFeeToMerchant->setDbValue($rs->fields('serviceFeeToMerchant'));
		$this->merchantRefID->setDbValue($rs->fields('merchantRefID'));
		$this->feesystemshare->setDbValue($rs->fields('feesystemshare'));
		$this->feeexternalshare->setDbValue($rs->fields('feeexternalshare'));
		$this->feefranchiseeshare->setDbValue($rs->fields('feefranchiseeshare'));
		$this->feeresellershare->setDbValue($rs->fields('feeresellershare'));
		$this->userpiid->setDbValue($rs->fields('userpiid'));
		$this->businessname->setDbValue($rs->fields('businessname'));
		$this->originalpurchaseamount->setDbValue($rs->fields('originalpurchaseamount'));
		$this->transferTime->setDbValue($rs->fields('transferTime'));
		$this->merchantuserid->setDbValue($rs->fields('merchantuserid'));
		$this->firstName->setDbValue($rs->fields('firstName'));
		$this->lastName->setDbValue($rs->fields('lastName'));
		$this->customerpurchaseid->setDbValue($rs->fields('customerpurchaseid'));
	}

	// Render list row values
	public function renderListRow()
	{
		global $Security, $CurrentLanguage, $Language;

		// Call Row Rendering event
		$this->Row_Rendering();

		// Common render codes
		// transferID
		// merchantid
		// txid
		// returnTime
		// merchantSurcharge
		// currID
		// purchaseAmount
		// taxAmount
		// tipAmount
		// serviceFeeToCustomer
		// TotalAmountForCustomer
		// serviceFeeToMerchant
		// merchantRefID
		// feesystemshare
		// feeexternalshare
		// feefranchiseeshare
		// feeresellershare
		// userpiid
		// businessname
		// originalpurchaseamount
		// transferTime
		// merchantuserid
		// firstName
		// lastName
		// customerpurchaseid
		// transferID

		$this->transferID->ViewValue = $this->transferID->CurrentValue;
		$this->transferID->ViewCustomAttributes = "";

		// merchantid
		$this->merchantid->ViewValue = $this->merchantid->CurrentValue;
		$this->merchantid->ViewValue = FormatNumber($this->merchantid->ViewValue, 0, -2, -2, -2);
		$this->merchantid->ViewCustomAttributes = "";

		// txid
		$this->txid->ViewValue = $this->txid->CurrentValue;
		$this->txid->ViewCustomAttributes = "";

		// returnTime
		$this->returnTime->ViewValue = $this->returnTime->CurrentValue;
		$this->returnTime->ViewValue = FormatDateTime($this->returnTime->ViewValue, 0);
		$this->returnTime->ViewCustomAttributes = "";

		// merchantSurcharge
		$this->merchantSurcharge->ViewValue = $this->merchantSurcharge->CurrentValue;
		$this->merchantSurcharge->ViewValue = FormatNumber($this->merchantSurcharge->ViewValue, 2, -2, -2, -2);
		$this->merchantSurcharge->ViewCustomAttributes = "";

		// currID
		$this->currID->ViewValue = $this->currID->CurrentValue;
		$this->currID->ViewCustomAttributes = "";

		// purchaseAmount
		$this->purchaseAmount->ViewValue = $this->purchaseAmount->CurrentValue;
		$this->purchaseAmount->ViewValue = FormatNumber($this->purchaseAmount->ViewValue, 2, -2, -2, -2);
		$this->purchaseAmount->ViewCustomAttributes = "";

		// taxAmount
		$this->taxAmount->ViewValue = $this->taxAmount->CurrentValue;
		$this->taxAmount->ViewValue = FormatNumber($this->taxAmount->ViewValue, 2, -2, -2, -2);
		$this->taxAmount->ViewCustomAttributes = "";

		// tipAmount
		$this->tipAmount->ViewValue = $this->tipAmount->CurrentValue;
		$this->tipAmount->ViewValue = FormatNumber($this->tipAmount->ViewValue, 2, -2, -2, -2);
		$this->tipAmount->ViewCustomAttributes = "";

		// serviceFeeToCustomer
		$this->serviceFeeToCustomer->ViewValue = $this->serviceFeeToCustomer->CurrentValue;
		$this->serviceFeeToCustomer->ViewValue = FormatNumber($this->serviceFeeToCustomer->ViewValue, 2, -2, -2, -2);
		$this->serviceFeeToCustomer->ViewCustomAttributes = "";

		// TotalAmountForCustomer
		$this->TotalAmountForCustomer->ViewValue = $this->TotalAmountForCustomer->CurrentValue;
		$this->TotalAmountForCustomer->ViewValue = FormatNumber($this->TotalAmountForCustomer->ViewValue, 2, -2, -2, -2);
		$this->TotalAmountForCustomer->ViewCustomAttributes = "";

		// serviceFeeToMerchant
		$this->serviceFeeToMerchant->ViewValue = $this->serviceFeeToMerchant->CurrentValue;
		$this->serviceFeeToMerchant->ViewValue = FormatNumber($this->serviceFeeToMerchant->ViewValue, 2, -2, -2, -2);
		$this->serviceFeeToMerchant->ViewCustomAttributes = "";

		// merchantRefID
		$this->merchantRefID->ViewValue = $this->merchantRefID->CurrentValue;
		$this->merchantRefID->ViewCustomAttributes = "";

		// feesystemshare
		$this->feesystemshare->ViewValue = $this->feesystemshare->CurrentValue;
		$this->feesystemshare->ViewValue = FormatNumber($this->feesystemshare->ViewValue, 2, -2, -2, -2);
		$this->feesystemshare->ViewCustomAttributes = "";

		// feeexternalshare
		$this->feeexternalshare->ViewValue = $this->feeexternalshare->CurrentValue;
		$this->feeexternalshare->ViewValue = FormatNumber($this->feeexternalshare->ViewValue, 2, -2, -2, -2);
		$this->feeexternalshare->ViewCustomAttributes = "";

		// feefranchiseeshare
		$this->feefranchiseeshare->ViewValue = $this->feefranchiseeshare->CurrentValue;
		$this->feefranchiseeshare->ViewValue = FormatNumber($this->feefranchiseeshare->ViewValue, 2, -2, -2, -2);
		$this->feefranchiseeshare->ViewCustomAttributes = "";

		// feeresellershare
		$this->feeresellershare->ViewValue = $this->feeresellershare->CurrentValue;
		$this->feeresellershare->ViewValue = FormatNumber($this->feeresellershare->ViewValue, 2, -2, -2, -2);
		$this->feeresellershare->ViewCustomAttributes = "";

		// userpiid
		$this->userpiid->ViewValue = $this->userpiid->CurrentValue;
		$this->userpiid->ViewValue = FormatNumber($this->userpiid->ViewValue, 0, -2, -2, -2);
		$this->userpiid->ViewCustomAttributes = "";

		// businessname
		$this->businessname->ViewValue = $this->businessname->CurrentValue;
		$this->businessname->ViewCustomAttributes = "";

		// originalpurchaseamount
		$this->originalpurchaseamount->ViewValue = $this->originalpurchaseamount->CurrentValue;
		$this->originalpurchaseamount->ViewValue = FormatNumber($this->originalpurchaseamount->ViewValue, 2, -2, -2, -2);
		$this->originalpurchaseamount->ViewCustomAttributes = "";

		// transferTime
		$this->transferTime->ViewValue = $this->transferTime->CurrentValue;
		$this->transferTime->ViewValue = FormatDateTime($this->transferTime->ViewValue, 0);
		$this->transferTime->ViewCustomAttributes = "";

		// merchantuserid
		$this->merchantuserid->ViewValue = $this->merchantuserid->CurrentValue;
		$this->merchantuserid->ViewValue = FormatNumber($this->merchantuserid->ViewValue, 0, -2, -2, -2);
		$this->merchantuserid->ViewCustomAttributes = "";

		// firstName
		$this->firstName->ViewValue = $this->firstName->CurrentValue;
		$this->firstName->ViewCustomAttributes = "";

		// lastName
		$this->lastName->ViewValue = $this->lastName->CurrentValue;
		$this->lastName->ViewCustomAttributes = "";

		// customerpurchaseid
		$this->customerpurchaseid->ViewValue = $this->customerpurchaseid->CurrentValue;
		$this->customerpurchaseid->ViewValue = FormatNumber($this->customerpurchaseid->ViewValue, 0, -2, -2, -2);
		$this->customerpurchaseid->ViewCustomAttributes = "";

		// transferID
		$this->transferID->LinkCustomAttributes = "";
		$this->transferID->HrefValue = "";
		$this->transferID->TooltipValue = "";

		// merchantid
		$this->merchantid->LinkCustomAttributes = "";
		$this->merchantid->HrefValue = "";
		$this->merchantid->TooltipValue = "";

		// txid
		$this->txid->LinkCustomAttributes = "";
		$this->txid->HrefValue = "";
		$this->txid->TooltipValue = "";

		// returnTime
		$this->returnTime->LinkCustomAttributes = "";
		$this->returnTime->HrefValue = "";
		$this->returnTime->TooltipValue = "";

		// merchantSurcharge
		$this->merchantSurcharge->LinkCustomAttributes = "";
		$this->merchantSurcharge->HrefValue = "";
		$this->merchantSurcharge->TooltipValue = "";

		// currID
		$this->currID->LinkCustomAttributes = "";
		$this->currID->HrefValue = "";
		$this->currID->TooltipValue = "";

		// purchaseAmount
		$this->purchaseAmount->LinkCustomAttributes = "";
		$this->purchaseAmount->HrefValue = "";
		$this->purchaseAmount->TooltipValue = "";

		// taxAmount
		$this->taxAmount->LinkCustomAttributes = "";
		$this->taxAmount->HrefValue = "";
		$this->taxAmount->TooltipValue = "";

		// tipAmount
		$this->tipAmount->LinkCustomAttributes = "";
		$this->tipAmount->HrefValue = "";
		$this->tipAmount->TooltipValue = "";

		// serviceFeeToCustomer
		$this->serviceFeeToCustomer->LinkCustomAttributes = "";
		$this->serviceFeeToCustomer->HrefValue = "";
		$this->serviceFeeToCustomer->TooltipValue = "";

		// TotalAmountForCustomer
		$this->TotalAmountForCustomer->LinkCustomAttributes = "";
		$this->TotalAmountForCustomer->HrefValue = "";
		$this->TotalAmountForCustomer->TooltipValue = "";

		// serviceFeeToMerchant
		$this->serviceFeeToMerchant->LinkCustomAttributes = "";
		$this->serviceFeeToMerchant->HrefValue = "";
		$this->serviceFeeToMerchant->TooltipValue = "";

		// merchantRefID
		$this->merchantRefID->LinkCustomAttributes = "";
		$this->merchantRefID->HrefValue = "";
		$this->merchantRefID->TooltipValue = "";

		// feesystemshare
		$this->feesystemshare->LinkCustomAttributes = "";
		$this->feesystemshare->HrefValue = "";
		$this->feesystemshare->TooltipValue = "";

		// feeexternalshare
		$this->feeexternalshare->LinkCustomAttributes = "";
		$this->feeexternalshare->HrefValue = "";
		$this->feeexternalshare->TooltipValue = "";

		// feefranchiseeshare
		$this->feefranchiseeshare->LinkCustomAttributes = "";
		$this->feefranchiseeshare->HrefValue = "";
		$this->feefranchiseeshare->TooltipValue = "";

		// feeresellershare
		$this->feeresellershare->LinkCustomAttributes = "";
		$this->feeresellershare->HrefValue = "";
		$this->feeresellershare->TooltipValue = "";

		// userpiid
		$this->userpiid->LinkCustomAttributes = "";
		$this->userpiid->HrefValue = "";
		$this->userpiid->TooltipValue = "";

		// businessname
		$this->businessname->LinkCustomAttributes = "";
		$this->businessname->HrefValue = "";
		$this->businessname->TooltipValue = "";

		// originalpurchaseamount
		$this->originalpurchaseamount->LinkCustomAttributes = "";
		$this->originalpurchaseamount->HrefValue = "";
		$this->originalpurchaseamount->TooltipValue = "";

		// transferTime
		$this->transferTime->LinkCustomAttributes = "";
		$this->transferTime->HrefValue = "";
		$this->transferTime->TooltipValue = "";

		// merchantuserid
		$this->merchantuserid->LinkCustomAttributes = "";
		$this->merchantuserid->HrefValue = "";
		$this->merchantuserid->TooltipValue = "";

		// firstName
		$this->firstName->LinkCustomAttributes = "";
		$this->firstName->HrefValue = "";
		$this->firstName->TooltipValue = "";

		// lastName
		$this->lastName->LinkCustomAttributes = "";
		$this->lastName->HrefValue = "";
		$this->lastName->TooltipValue = "";

		// customerpurchaseid
		$this->customerpurchaseid->LinkCustomAttributes = "";
		$this->customerpurchaseid->HrefValue = "";
		$this->customerpurchaseid->TooltipValue = "";

		// Call Row Rendered event
		$this->Row_Rendered();

		// Save data for Custom Template
		$this->Rows[] = $this->customTemplateFieldValues();
	}

	// Render edit row values
	public function renderEditRow()
	{
		global $Security, $CurrentLanguage, $Language;

		// Call Row Rendering event
		$this->Row_Rendering();

		// transferID
		$this->transferID->EditAttrs["class"] = "form-control";
		$this->transferID->EditCustomAttributes = "";
		$this->transferID->EditValue = $this->transferID->CurrentValue;
		$this->transferID->PlaceHolder = RemoveHtml($this->transferID->caption());

		// merchantid
		$this->merchantid->EditAttrs["class"] = "form-control";
		$this->merchantid->EditCustomAttributes = "";
		$this->merchantid->EditValue = $this->merchantid->CurrentValue;
		$this->merchantid->PlaceHolder = RemoveHtml($this->merchantid->caption());

		// txid
		$this->txid->EditAttrs["class"] = "form-control";
		$this->txid->EditCustomAttributes = "";
		if (!$this->txid->Raw)
			$this->txid->CurrentValue = HtmlDecode($this->txid->CurrentValue);
		$this->txid->EditValue = $this->txid->CurrentValue;
		$this->txid->PlaceHolder = RemoveHtml($this->txid->caption());

		// returnTime
		$this->returnTime->EditAttrs["class"] = "form-control";
		$this->returnTime->EditCustomAttributes = "";
		$this->returnTime->EditValue = FormatDateTime($this->returnTime->CurrentValue, 8);
		$this->returnTime->PlaceHolder = RemoveHtml($this->returnTime->caption());

		// merchantSurcharge
		$this->merchantSurcharge->EditAttrs["class"] = "form-control";
		$this->merchantSurcharge->EditCustomAttributes = "";
		$this->merchantSurcharge->EditValue = $this->merchantSurcharge->CurrentValue;
		$this->merchantSurcharge->PlaceHolder = RemoveHtml($this->merchantSurcharge->caption());
		if (strval($this->merchantSurcharge->EditValue) != "" && is_numeric($this->merchantSurcharge->EditValue))
			$this->merchantSurcharge->EditValue = FormatNumber($this->merchantSurcharge->EditValue, -2, -2, -2, -2);
		

		// currID
		$this->currID->EditAttrs["class"] = "form-control";
		$this->currID->EditCustomAttributes = "";
		if (!$this->currID->Raw)
			$this->currID->CurrentValue = HtmlDecode($this->currID->CurrentValue);
		$this->currID->EditValue = $this->currID->CurrentValue;
		$this->currID->PlaceHolder = RemoveHtml($this->currID->caption());

		// purchaseAmount
		$this->purchaseAmount->EditAttrs["class"] = "form-control";
		$this->purchaseAmount->EditCustomAttributes = "";
		$this->purchaseAmount->EditValue = $this->purchaseAmount->CurrentValue;
		$this->purchaseAmount->PlaceHolder = RemoveHtml($this->purchaseAmount->caption());
		if (strval($this->purchaseAmount->EditValue) != "" && is_numeric($this->purchaseAmount->EditValue))
			$this->purchaseAmount->EditValue = FormatNumber($this->purchaseAmount->EditValue, -2, -2, -2, -2);
		

		// taxAmount
		$this->taxAmount->EditAttrs["class"] = "form-control";
		$this->taxAmount->EditCustomAttributes = "";
		$this->taxAmount->EditValue = $this->taxAmount->CurrentValue;
		$this->taxAmount->PlaceHolder = RemoveHtml($this->taxAmount->caption());
		if (strval($this->taxAmount->EditValue) != "" && is_numeric($this->taxAmount->EditValue))
			$this->taxAmount->EditValue = FormatNumber($this->taxAmount->EditValue, -2, -2, -2, -2);
		

		// tipAmount
		$this->tipAmount->EditAttrs["class"] = "form-control";
		$this->tipAmount->EditCustomAttributes = "";
		$this->tipAmount->EditValue = $this->tipAmount->CurrentValue;
		$this->tipAmount->PlaceHolder = RemoveHtml($this->tipAmount->caption());
		if (strval($this->tipAmount->EditValue) != "" && is_numeric($this->tipAmount->EditValue))
			$this->tipAmount->EditValue = FormatNumber($this->tipAmount->EditValue, -2, -2, -2, -2);
		

		// serviceFeeToCustomer
		$this->serviceFeeToCustomer->EditAttrs["class"] = "form-control";
		$this->serviceFeeToCustomer->EditCustomAttributes = "";
		$this->serviceFeeToCustomer->EditValue = $this->serviceFeeToCustomer->CurrentValue;
		$this->serviceFeeToCustomer->PlaceHolder = RemoveHtml($this->serviceFeeToCustomer->caption());
		if (strval($this->serviceFeeToCustomer->EditValue) != "" && is_numeric($this->serviceFeeToCustomer->EditValue))
			$this->serviceFeeToCustomer->EditValue = FormatNumber($this->serviceFeeToCustomer->EditValue, -2, -2, -2, -2);
		

		// TotalAmountForCustomer
		$this->TotalAmountForCustomer->EditAttrs["class"] = "form-control";
		$this->TotalAmountForCustomer->EditCustomAttributes = "";
		$this->TotalAmountForCustomer->EditValue = $this->TotalAmountForCustomer->CurrentValue;
		$this->TotalAmountForCustomer->PlaceHolder = RemoveHtml($this->TotalAmountForCustomer->caption());
		if (strval($this->TotalAmountForCustomer->EditValue) != "" && is_numeric($this->TotalAmountForCustomer->EditValue))
			$this->TotalAmountForCustomer->EditValue = FormatNumber($this->TotalAmountForCustomer->EditValue, -2, -2, -2, -2);
		

		// serviceFeeToMerchant
		$this->serviceFeeToMerchant->EditAttrs["class"] = "form-control";
		$this->serviceFeeToMerchant->EditCustomAttributes = "";
		$this->serviceFeeToMerchant->EditValue = $this->serviceFeeToMerchant->CurrentValue;
		$this->serviceFeeToMerchant->PlaceHolder = RemoveHtml($this->serviceFeeToMerchant->caption());
		if (strval($this->serviceFeeToMerchant->EditValue) != "" && is_numeric($this->serviceFeeToMerchant->EditValue))
			$this->serviceFeeToMerchant->EditValue = FormatNumber($this->serviceFeeToMerchant->EditValue, -2, -2, -2, -2);
		

		// merchantRefID
		$this->merchantRefID->EditAttrs["class"] = "form-control";
		$this->merchantRefID->EditCustomAttributes = "";
		if (!$this->merchantRefID->Raw)
			$this->merchantRefID->CurrentValue = HtmlDecode($this->merchantRefID->CurrentValue);
		$this->merchantRefID->EditValue = $this->merchantRefID->CurrentValue;
		$this->merchantRefID->PlaceHolder = RemoveHtml($this->merchantRefID->caption());

		// feesystemshare
		$this->feesystemshare->EditAttrs["class"] = "form-control";
		$this->feesystemshare->EditCustomAttributes = "";
		$this->feesystemshare->EditValue = $this->feesystemshare->CurrentValue;
		$this->feesystemshare->PlaceHolder = RemoveHtml($this->feesystemshare->caption());
		if (strval($this->feesystemshare->EditValue) != "" && is_numeric($this->feesystemshare->EditValue))
			$this->feesystemshare->EditValue = FormatNumber($this->feesystemshare->EditValue, -2, -2, -2, -2);
		

		// feeexternalshare
		$this->feeexternalshare->EditAttrs["class"] = "form-control";
		$this->feeexternalshare->EditCustomAttributes = "";
		$this->feeexternalshare->EditValue = $this->feeexternalshare->CurrentValue;
		$this->feeexternalshare->PlaceHolder = RemoveHtml($this->feeexternalshare->caption());
		if (strval($this->feeexternalshare->EditValue) != "" && is_numeric($this->feeexternalshare->EditValue))
			$this->feeexternalshare->EditValue = FormatNumber($this->feeexternalshare->EditValue, -2, -2, -2, -2);
		

		// feefranchiseeshare
		$this->feefranchiseeshare->EditAttrs["class"] = "form-control";
		$this->feefranchiseeshare->EditCustomAttributes = "";
		$this->feefranchiseeshare->EditValue = $this->feefranchiseeshare->CurrentValue;
		$this->feefranchiseeshare->PlaceHolder = RemoveHtml($this->feefranchiseeshare->caption());
		if (strval($this->feefranchiseeshare->EditValue) != "" && is_numeric($this->feefranchiseeshare->EditValue))
			$this->feefranchiseeshare->EditValue = FormatNumber($this->feefranchiseeshare->EditValue, -2, -2, -2, -2);
		

		// feeresellershare
		$this->feeresellershare->EditAttrs["class"] = "form-control";
		$this->feeresellershare->EditCustomAttributes = "";
		$this->feeresellershare->EditValue = $this->feeresellershare->CurrentValue;
		$this->feeresellershare->PlaceHolder = RemoveHtml($this->feeresellershare->caption());
		if (strval($this->feeresellershare->EditValue) != "" && is_numeric($this->feeresellershare->EditValue))
			$this->feeresellershare->EditValue = FormatNumber($this->feeresellershare->EditValue, -2, -2, -2, -2);
		

		// userpiid
		$this->userpiid->EditAttrs["class"] = "form-control";
		$this->userpiid->EditCustomAttributes = "";
		$this->userpiid->EditValue = $this->userpiid->CurrentValue;
		$this->userpiid->PlaceHolder = RemoveHtml($this->userpiid->caption());

		// businessname
		$this->businessname->EditAttrs["class"] = "form-control";
		$this->businessname->EditCustomAttributes = "";
		if (!$this->businessname->Raw)
			$this->businessname->CurrentValue = HtmlDecode($this->businessname->CurrentValue);
		$this->businessname->EditValue = $this->businessname->CurrentValue;
		$this->businessname->PlaceHolder = RemoveHtml($this->businessname->caption());

		// originalpurchaseamount
		$this->originalpurchaseamount->EditAttrs["class"] = "form-control";
		$this->originalpurchaseamount->EditCustomAttributes = "";
		$this->originalpurchaseamount->EditValue = $this->originalpurchaseamount->CurrentValue;
		$this->originalpurchaseamount->PlaceHolder = RemoveHtml($this->originalpurchaseamount->caption());
		if (strval($this->originalpurchaseamount->EditValue) != "" && is_numeric($this->originalpurchaseamount->EditValue))
			$this->originalpurchaseamount->EditValue = FormatNumber($this->originalpurchaseamount->EditValue, -2, -2, -2, -2);
		

		// transferTime
		$this->transferTime->EditAttrs["class"] = "form-control";
		$this->transferTime->EditCustomAttributes = "";
		$this->transferTime->EditValue = FormatDateTime($this->transferTime->CurrentValue, 8);
		$this->transferTime->PlaceHolder = RemoveHtml($this->transferTime->caption());

		// merchantuserid
		$this->merchantuserid->EditAttrs["class"] = "form-control";
		$this->merchantuserid->EditCustomAttributes = "";
		$this->merchantuserid->EditValue = $this->merchantuserid->CurrentValue;
		$this->merchantuserid->PlaceHolder = RemoveHtml($this->merchantuserid->caption());

		// firstName
		$this->firstName->EditAttrs["class"] = "form-control";
		$this->firstName->EditCustomAttributes = "";
		if (!$this->firstName->Raw)
			$this->firstName->CurrentValue = HtmlDecode($this->firstName->CurrentValue);
		$this->firstName->EditValue = $this->firstName->CurrentValue;
		$this->firstName->PlaceHolder = RemoveHtml($this->firstName->caption());

		// lastName
		$this->lastName->EditAttrs["class"] = "form-control";
		$this->lastName->EditCustomAttributes = "";
		if (!$this->lastName->Raw)
			$this->lastName->CurrentValue = HtmlDecode($this->lastName->CurrentValue);
		$this->lastName->EditValue = $this->lastName->CurrentValue;
		$this->lastName->PlaceHolder = RemoveHtml($this->lastName->caption());

		// customerpurchaseid
		$this->customerpurchaseid->EditAttrs["class"] = "form-control";
		$this->customerpurchaseid->EditCustomAttributes = "";
		$this->customerpurchaseid->EditValue = $this->customerpurchaseid->CurrentValue;
		$this->customerpurchaseid->PlaceHolder = RemoveHtml($this->customerpurchaseid->caption());

		// Call Row Rendered event
		$this->Row_Rendered();
	}

	// Aggregate list row values
	public function aggregateListRowValues()
	{
	}

	// Aggregate list row (for rendering)
	public function aggregateListRow()
	{

		// Call Row Rendered event
		$this->Row_Rendered();
	}

	// Export data in HTML/CSV/Word/Excel/Email/PDF format
	public function exportDocument($doc, $recordset, $startRec = 1, $stopRec = 1, $exportPageType = "")
	{
		if (!$recordset || !$doc)
			return;
		if (!$doc->ExportCustom) {

			// Write header
			$doc->exportTableHeader();
			if ($doc->Horizontal) { // Horizontal format, write header
				$doc->beginExportRow();
				if ($exportPageType == "view") {
					$doc->exportCaption($this->transferID);
					$doc->exportCaption($this->merchantid);
					$doc->exportCaption($this->txid);
					$doc->exportCaption($this->returnTime);
					$doc->exportCaption($this->merchantSurcharge);
					$doc->exportCaption($this->currID);
					$doc->exportCaption($this->purchaseAmount);
					$doc->exportCaption($this->taxAmount);
					$doc->exportCaption($this->tipAmount);
					$doc->exportCaption($this->serviceFeeToCustomer);
					$doc->exportCaption($this->TotalAmountForCustomer);
					$doc->exportCaption($this->serviceFeeToMerchant);
					$doc->exportCaption($this->merchantRefID);
					$doc->exportCaption($this->feesystemshare);
					$doc->exportCaption($this->feeexternalshare);
					$doc->exportCaption($this->feefranchiseeshare);
					$doc->exportCaption($this->feeresellershare);
					$doc->exportCaption($this->userpiid);
					$doc->exportCaption($this->businessname);
					$doc->exportCaption($this->originalpurchaseamount);
					$doc->exportCaption($this->transferTime);
					$doc->exportCaption($this->merchantuserid);
					$doc->exportCaption($this->firstName);
					$doc->exportCaption($this->lastName);
					$doc->exportCaption($this->customerpurchaseid);
				} else {
					$doc->exportCaption($this->transferID);
					$doc->exportCaption($this->merchantid);
					$doc->exportCaption($this->txid);
					$doc->exportCaption($this->returnTime);
					$doc->exportCaption($this->merchantSurcharge);
					$doc->exportCaption($this->currID);
					$doc->exportCaption($this->purchaseAmount);
					$doc->exportCaption($this->taxAmount);
					$doc->exportCaption($this->tipAmount);
					$doc->exportCaption($this->serviceFeeToCustomer);
					$doc->exportCaption($this->TotalAmountForCustomer);
					$doc->exportCaption($this->serviceFeeToMerchant);
					$doc->exportCaption($this->merchantRefID);
					$doc->exportCaption($this->feesystemshare);
					$doc->exportCaption($this->feeexternalshare);
					$doc->exportCaption($this->feefranchiseeshare);
					$doc->exportCaption($this->feeresellershare);
					$doc->exportCaption($this->userpiid);
					$doc->exportCaption($this->businessname);
					$doc->exportCaption($this->originalpurchaseamount);
					$doc->exportCaption($this->transferTime);
					$doc->exportCaption($this->merchantuserid);
					$doc->exportCaption($this->firstName);
					$doc->exportCaption($this->lastName);
					$doc->exportCaption($this->customerpurchaseid);
				}
				$doc->endExportRow();
			}
		}

		// Move to first record
		$recCnt = $startRec - 1;
		if (!$recordset->EOF) {
			$recordset->moveFirst();
			if ($startRec > 1)
				$recordset->move($startRec - 1);
		}
		while (!$recordset->EOF && $recCnt < $stopRec) {
			$recCnt++;
			if ($recCnt >= $startRec) {
				$rowCnt = $recCnt - $startRec + 1;

				// Page break
				if ($this->ExportPageBreakCount > 0) {
					if ($rowCnt > 1 && ($rowCnt - 1) % $this->ExportPageBreakCount == 0)
						$doc->exportPageBreak();
				}
				$this->loadListRowValues($recordset);

				// Render row
				$this->RowType = ROWTYPE_VIEW; // Render view
				$this->resetAttributes();
				$this->renderListRow();
				if (!$doc->ExportCustom) {
					$doc->beginExportRow($rowCnt); // Allow CSS styles if enabled
					if ($exportPageType == "view") {
						$doc->exportField($this->transferID);
						$doc->exportField($this->merchantid);
						$doc->exportField($this->txid);
						$doc->exportField($this->returnTime);
						$doc->exportField($this->merchantSurcharge);
						$doc->exportField($this->currID);
						$doc->exportField($this->purchaseAmount);
						$doc->exportField($this->taxAmount);
						$doc->exportField($this->tipAmount);
						$doc->exportField($this->serviceFeeToCustomer);
						$doc->exportField($this->TotalAmountForCustomer);
						$doc->exportField($this->serviceFeeToMerchant);
						$doc->exportField($this->merchantRefID);
						$doc->exportField($this->feesystemshare);
						$doc->exportField($this->feeexternalshare);
						$doc->exportField($this->feefranchiseeshare);
						$doc->exportField($this->feeresellershare);
						$doc->exportField($this->userpiid);
						$doc->exportField($this->businessname);
						$doc->exportField($this->originalpurchaseamount);
						$doc->exportField($this->transferTime);
						$doc->exportField($this->merchantuserid);
						$doc->exportField($this->firstName);
						$doc->exportField($this->lastName);
						$doc->exportField($this->customerpurchaseid);
					} else {
						$doc->exportField($this->transferID);
						$doc->exportField($this->merchantid);
						$doc->exportField($this->txid);
						$doc->exportField($this->returnTime);
						$doc->exportField($this->merchantSurcharge);
						$doc->exportField($this->currID);
						$doc->exportField($this->purchaseAmount);
						$doc->exportField($this->taxAmount);
						$doc->exportField($this->tipAmount);
						$doc->exportField($this->serviceFeeToCustomer);
						$doc->exportField($this->TotalAmountForCustomer);
						$doc->exportField($this->serviceFeeToMerchant);
						$doc->exportField($this->merchantRefID);
						$doc->exportField($this->feesystemshare);
						$doc->exportField($this->feeexternalshare);
						$doc->exportField($this->feefranchiseeshare);
						$doc->exportField($this->feeresellershare);
						$doc->exportField($this->userpiid);
						$doc->exportField($this->businessname);
						$doc->exportField($this->originalpurchaseamount);
						$doc->exportField($this->transferTime);
						$doc->exportField($this->merchantuserid);
						$doc->exportField($this->firstName);
						$doc->exportField($this->lastName);
						$doc->exportField($this->customerpurchaseid);
					}
					$doc->endExportRow($rowCnt);
				}
			}

			// Call Row Export server event
			if ($doc->ExportCustom)
				$this->Row_Export($recordset->fields);
			$recordset->moveNext();
		}
		if (!$doc->ExportCustom) {
			$doc->exportTableFooter();
		}
	}

	// Get file data
	public function getFileData($fldparm, $key, $resize, $width = 0, $height = 0)
	{

		// No binary fields
		return FALSE;
	}

	// Table level events
	// Recordset Selecting event
	function Recordset_Selecting(&$filter) {

		// Enter your code here
	}

	// Recordset Selected event
	function Recordset_Selected(&$rs) {

		//echo "Recordset Selected";
	}

	// Recordset Search Validated event
	function Recordset_SearchValidated() {

		// Example:
		//$this->MyField1->AdvancedSearch->SearchValue = "your search criteria"; // Search value

	}

	// Recordset Searching event
	function Recordset_Searching(&$filter) {

		// Enter your code here
	}

	// Row_Selecting event
	function Row_Selecting(&$filter) {

		// Enter your code here
	}

	// Row Selected event
	function Row_Selected(&$rs) {

		//echo "Row Selected";
	}

	// Row Inserting event
	function Row_Inserting($rsold, &$rsnew) {

		// Enter your code here
		// To cancel, set return value to FALSE

		return TRUE;
	}

	// Row Inserted event
	function Row_Inserted($rsold, &$rsnew) {

		//echo "Row Inserted"
	}

	// Row Updating event
	function Row_Updating($rsold, &$rsnew) {

		// Enter your code here
		// To cancel, set return value to FALSE

		return TRUE;
	}

	// Row Updated event
	function Row_Updated($rsold, &$rsnew) {

		//echo "Row Updated";
	}

	// Row Update Conflict event
	function Row_UpdateConflict($rsold, &$rsnew) {

		// Enter your code here
		// To ignore conflict, set return value to FALSE

		return TRUE;
	}

	// Grid Inserting event
	function Grid_Inserting() {

		// Enter your code here
		// To reject grid insert, set return value to FALSE

		return TRUE;
	}

	// Grid Inserted event
	function Grid_Inserted($rsnew) {

		//echo "Grid Inserted";
	}

	// Grid Updating event
	function Grid_Updating($rsold) {

		// Enter your code here
		// To reject grid update, set return value to FALSE

		return TRUE;
	}

	// Grid Updated event
	function Grid_Updated($rsold, $rsnew) {

		//echo "Grid Updated";
	}

	// Row Deleting event
	function Row_Deleting(&$rs) {

		// Enter your code here
		// To cancel, set return value to False

		return TRUE;
	}

	// Row Deleted event
	function Row_Deleted(&$rs) {

		//echo "Row Deleted";
	}

	// Email Sending event
	function Email_Sending($email, &$args) {

		//var_dump($email); var_dump($args); exit();
		return TRUE;
	}

	// Lookup Selecting event
	function Lookup_Selecting($fld, &$filter) {

		//var_dump($fld->Name, $fld->Lookup, $filter); // Uncomment to view the filter
		// Enter your code here

	}

	// Row Rendering event
	function Row_Rendering() {

		// Enter your code here
	}

	// Row Rendered event
	function Row_Rendered() {

		// To view properties of field class, use:
		//var_dump($this-><FieldName>);

	}

	// User ID Filtering event
	function UserID_Filtering(&$filter) {

		// Enter your code here
	}
}
?>