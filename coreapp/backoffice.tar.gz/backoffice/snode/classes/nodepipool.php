<?php namespace PHPMaker2020\_4payadmin; ?>
<?php

/**
 * Table class for nodepipool
 */
class nodepipool extends DbTable
{
	protected $SqlFrom = "";
	protected $SqlSelect = "";
	protected $SqlSelectList = "";
	protected $SqlWhere = "";
	protected $SqlGroupBy = "";
	protected $SqlHaving = "";
	protected $SqlOrderBy = "";
	public $UseSessionForListSql = TRUE;

	// Column CSS classes
	public $LeftColumnClass = "col-sm-2 col-form-label ew-label";
	public $RightColumnClass = "col-sm-10";
	public $OffsetColumnClass = "col-sm-10 offset-sm-2";
	public $TableLeftColumnClass = "w-col-2";

	// Audit trail
	public $AuditTrailOnAdd = TRUE;
	public $AuditTrailOnEdit = TRUE;
	public $AuditTrailOnDelete = TRUE;
	public $AuditTrailOnView = FALSE;
	public $AuditTrailOnViewData = FALSE;
	public $AuditTrailOnSearch = FALSE;

	// Export
	public $ExportDoc;

	// Fields
	public $transferID;
	public $txid;
	public $sourceUserID;
	public $transferTime;
	public $comments;
	public $type;
	public $lastUpdateDateTime;
	public $confirmCode;
	public $status;
	public $tries;
	public $locked;
	public $internal;
	public $senderpi;
	public $senderpiid;
	public $recipientid;
	public $presentationcode;
	public $recipientname;
	public $sendername;
	public $description;

	// Constructor
	public function __construct()
	{
		global $Language, $CurrentLanguage;
		parent::__construct();

		// Language object
		if (!isset($Language))
			$Language = new Language();
		$this->TableVar = 'nodepipool';
		$this->TableName = 'nodepipool';
		$this->TableType = 'TABLE';

		// Update Table
		$this->UpdateTable = "`nodepipool`";
		$this->Dbid = 'DB';
		$this->ExportAll = TRUE;
		$this->ExportPageBreakCount = 0; // Page break per every n record (PDF only)
		$this->ExportPageOrientation = "portrait"; // Page orientation (PDF only)
		$this->ExportPageSize = "a4"; // Page size (PDF only)
		$this->ExportExcelPageOrientation = \PhpOffice\PhpSpreadsheet\Worksheet\PageSetup::ORIENTATION_DEFAULT; // Page orientation (PhpSpreadsheet only)
		$this->ExportExcelPageSize = \PhpOffice\PhpSpreadsheet\Worksheet\PageSetup::PAPERSIZE_A4; // Page size (PhpSpreadsheet only)
		$this->ExportWordPageOrientation = "portrait"; // Page orientation (PHPWord only)
		$this->ExportWordColumnWidth = NULL; // Cell width (PHPWord only)
		$this->DetailAdd = FALSE; // Allow detail add
		$this->DetailEdit = FALSE; // Allow detail edit
		$this->DetailView = FALSE; // Allow detail view
		$this->ShowMultipleDetails = FALSE; // Show multiple details
		$this->GridAddRowCount = 5;
		$this->AllowAddDeleteRow = TRUE; // Allow add/delete row
		$this->UserIDAllowSecurity = Config("DEFAULT_USER_ID_ALLOW_SECURITY"); // Default User ID allowed permissions
		$this->BasicSearch = new BasicSearch($this->TableVar);

		// transferID
		$this->transferID = new DbField('nodepipool', 'nodepipool', 'x_transferID', 'transferID', '`transferID`', '`transferID`', 3, 12, -1, FALSE, '`transferID`', FALSE, FALSE, FALSE, 'FORMATTED TEXT', 'NO');
		$this->transferID->IsAutoIncrement = TRUE; // Autoincrement field
		$this->transferID->IsPrimaryKey = TRUE; // Primary key field
		$this->transferID->Sortable = TRUE; // Allow sort
		$this->transferID->DefaultErrorMessage = $Language->phrase("IncorrectInteger");
		$this->fields['transferID'] = &$this->transferID;

		// txid
		$this->txid = new DbField('nodepipool', 'nodepipool', 'x_txid', 'txid', '`txid`', '`txid`', 200, 10, -1, FALSE, '`txid`', FALSE, FALSE, FALSE, 'FORMATTED TEXT', 'TEXT');
		$this->txid->Nullable = FALSE; // NOT NULL field
		$this->txid->Required = TRUE; // Required field
		$this->txid->Sortable = TRUE; // Allow sort
		$this->fields['txid'] = &$this->txid;

		// sourceUserID
		$this->sourceUserID = new DbField('nodepipool', 'nodepipool', 'x_sourceUserID', 'sourceUserID', '`sourceUserID`', '`sourceUserID`', 3, 12, -1, FALSE, '`sourceUserID`', FALSE, FALSE, FALSE, 'FORMATTED TEXT', 'TEXT');
		$this->sourceUserID->Nullable = FALSE; // NOT NULL field
		$this->sourceUserID->Required = TRUE; // Required field
		$this->sourceUserID->Sortable = TRUE; // Allow sort
		$this->sourceUserID->DefaultErrorMessage = $Language->phrase("IncorrectInteger");
		$this->fields['sourceUserID'] = &$this->sourceUserID;

		// transferTime
		$this->transferTime = new DbField('nodepipool', 'nodepipool', 'x_transferTime', 'transferTime', '`transferTime`', CastDateFieldForLike("`transferTime`", 0, "DB"), 135, 19, 0, FALSE, '`transferTime`', FALSE, FALSE, FALSE, 'FORMATTED TEXT', 'TEXT');
		$this->transferTime->Sortable = TRUE; // Allow sort
		$this->transferTime->DefaultErrorMessage = str_replace("%s", $GLOBALS["DATE_FORMAT"], $Language->phrase("IncorrectDate"));
		$this->fields['transferTime'] = &$this->transferTime;

		// comments
		$this->comments = new DbField('nodepipool', 'nodepipool', 'x_comments', 'comments', '`comments`', '`comments`', 200, 150, -1, FALSE, '`comments`', FALSE, FALSE, FALSE, 'FORMATTED TEXT', 'TEXT');
		$this->comments->Sortable = TRUE; // Allow sort
		$this->fields['comments'] = &$this->comments;

		// type
		$this->type = new DbField('nodepipool', 'nodepipool', 'x_type', 'type', '`type`', '`type`', 3, 1, -1, FALSE, '`type`', FALSE, FALSE, FALSE, 'FORMATTED TEXT', 'TEXT');
		$this->type->Nullable = FALSE; // NOT NULL field
		$this->type->Sortable = TRUE; // Allow sort
		$this->type->DefaultErrorMessage = $Language->phrase("IncorrectInteger");
		$this->fields['type'] = &$this->type;

		// lastUpdateDateTime
		$this->lastUpdateDateTime = new DbField('nodepipool', 'nodepipool', 'x_lastUpdateDateTime', 'lastUpdateDateTime', '`lastUpdateDateTime`', CastDateFieldForLike("`lastUpdateDateTime`", 0, "DB"), 135, 19, 0, FALSE, '`lastUpdateDateTime`', FALSE, FALSE, FALSE, 'FORMATTED TEXT', 'TEXT');
		$this->lastUpdateDateTime->Sortable = TRUE; // Allow sort
		$this->lastUpdateDateTime->DefaultErrorMessage = str_replace("%s", $GLOBALS["DATE_FORMAT"], $Language->phrase("IncorrectDate"));
		$this->fields['lastUpdateDateTime'] = &$this->lastUpdateDateTime;

		// confirmCode
		$this->confirmCode = new DbField('nodepipool', 'nodepipool', 'x_confirmCode', 'confirmCode', '`confirmCode`', '`confirmCode`', 200, 100, -1, FALSE, '`confirmCode`', FALSE, FALSE, FALSE, 'FORMATTED TEXT', 'TEXT');
		$this->confirmCode->Nullable = FALSE; // NOT NULL field
		$this->confirmCode->Required = TRUE; // Required field
		$this->confirmCode->Sortable = TRUE; // Allow sort
		$this->fields['confirmCode'] = &$this->confirmCode;

		// status
		$this->status = new DbField('nodepipool', 'nodepipool', 'x_status', 'status', '`status`', '`status`', 3, 2, -1, FALSE, '`status`', FALSE, FALSE, FALSE, 'FORMATTED TEXT', 'TEXT');
		$this->status->Nullable = FALSE; // NOT NULL field
		$this->status->Required = TRUE; // Required field
		$this->status->Sortable = TRUE; // Allow sort
		$this->status->DefaultErrorMessage = $Language->phrase("IncorrectInteger");
		$this->fields['status'] = &$this->status;

		// tries
		$this->tries = new DbField('nodepipool', 'nodepipool', 'x_tries', 'tries', '`tries`', '`tries`', 3, 2, -1, FALSE, '`tries`', FALSE, FALSE, FALSE, 'FORMATTED TEXT', 'TEXT');
		$this->tries->Nullable = FALSE; // NOT NULL field
		$this->tries->Sortable = TRUE; // Allow sort
		$this->tries->DefaultErrorMessage = $Language->phrase("IncorrectInteger");
		$this->fields['tries'] = &$this->tries;

		// locked
		$this->locked = new DbField('nodepipool', 'nodepipool', 'x_locked', 'locked', '`locked`', '`locked`', 3, 1, -1, FALSE, '`locked`', FALSE, FALSE, FALSE, 'FORMATTED TEXT', 'TEXT');
		$this->locked->Nullable = FALSE; // NOT NULL field
		$this->locked->Sortable = TRUE; // Allow sort
		$this->locked->DefaultErrorMessage = $Language->phrase("IncorrectInteger");
		$this->fields['locked'] = &$this->locked;

		// internal
		$this->internal = new DbField('nodepipool', 'nodepipool', 'x_internal', 'internal', '`internal`', '`internal`', 3, 1, -1, FALSE, '`internal`', FALSE, FALSE, FALSE, 'FORMATTED TEXT', 'TEXT');
		$this->internal->Sortable = TRUE; // Allow sort
		$this->internal->DefaultErrorMessage = $Language->phrase("IncorrectInteger");
		$this->fields['internal'] = &$this->internal;

		// senderpi
		$this->senderpi = new DbField('nodepipool', 'nodepipool', 'x_senderpi', 'senderpi', '`senderpi`', '`senderpi`', 3, 12, -1, FALSE, '`senderpi`', FALSE, FALSE, FALSE, 'FORMATTED TEXT', 'TEXT');
		$this->senderpi->Nullable = FALSE; // NOT NULL field
		$this->senderpi->Sortable = TRUE; // Allow sort
		$this->senderpi->DefaultErrorMessage = $Language->phrase("IncorrectInteger");
		$this->fields['senderpi'] = &$this->senderpi;

		// senderpiid
		$this->senderpiid = new DbField('nodepipool', 'nodepipool', 'x_senderpiid', 'senderpiid', '`senderpiid`', '`senderpiid`', 3, 5, -1, FALSE, '`senderpiid`', FALSE, FALSE, FALSE, 'FORMATTED TEXT', 'TEXT');
		$this->senderpiid->Nullable = FALSE; // NOT NULL field
		$this->senderpiid->Sortable = TRUE; // Allow sort
		$this->senderpiid->DefaultErrorMessage = $Language->phrase("IncorrectInteger");
		$this->fields['senderpiid'] = &$this->senderpiid;

		// recipientid
		$this->recipientid = new DbField('nodepipool', 'nodepipool', 'x_recipientid', 'recipientid', '`recipientid`', '`recipientid`', 200, 60, -1, FALSE, '`recipientid`', FALSE, FALSE, FALSE, 'FORMATTED TEXT', 'TEXT');
		$this->recipientid->Sortable = TRUE; // Allow sort
		$this->fields['recipientid'] = &$this->recipientid;

		// presentationcode
		$this->presentationcode = new DbField('nodepipool', 'nodepipool', 'x_presentationcode', 'presentationcode', '`presentationcode`', '`presentationcode`', 3, 5, -1, FALSE, '`presentationcode`', FALSE, FALSE, FALSE, 'FORMATTED TEXT', 'TEXT');
		$this->presentationcode->Nullable = FALSE; // NOT NULL field
		$this->presentationcode->Sortable = TRUE; // Allow sort
		$this->presentationcode->DefaultErrorMessage = $Language->phrase("IncorrectInteger");
		$this->fields['presentationcode'] = &$this->presentationcode;

		// recipientname
		$this->recipientname = new DbField('nodepipool', 'nodepipool', 'x_recipientname', 'recipientname', '`recipientname`', '`recipientname`', 200, 100, -1, FALSE, '`recipientname`', FALSE, FALSE, FALSE, 'FORMATTED TEXT', 'TEXT');
		$this->recipientname->Sortable = TRUE; // Allow sort
		$this->fields['recipientname'] = &$this->recipientname;

		// sendername
		$this->sendername = new DbField('nodepipool', 'nodepipool', 'x_sendername', 'sendername', '`sendername`', '`sendername`', 200, 100, -1, FALSE, '`sendername`', FALSE, FALSE, FALSE, 'FORMATTED TEXT', 'TEXT');
		$this->sendername->Sortable = TRUE; // Allow sort
		$this->fields['sendername'] = &$this->sendername;

		// description
		$this->description = new DbField('nodepipool', 'nodepipool', 'x_description', 'description', '`description`', '`description`', 200, 45, -1, FALSE, '`description`', FALSE, FALSE, FALSE, 'FORMATTED TEXT', 'TEXT');
		$this->description->Sortable = TRUE; // Allow sort
		$this->fields['description'] = &$this->description;
	}

	// Field Visibility
	public function getFieldVisibility($fldParm)
	{
		global $Security;
		return $this->$fldParm->Visible; // Returns original value
	}

	// Set left column class (must be predefined col-*-* classes of Bootstrap grid system)
	function setLeftColumnClass($class)
	{
		if (preg_match('/^col\-(\w+)\-(\d+)$/', $class, $match)) {
			$this->LeftColumnClass = $class . " col-form-label ew-label";
			$this->RightColumnClass = "col-" . $match[1] . "-" . strval(12 - (int)$match[2]);
			$this->OffsetColumnClass = $this->RightColumnClass . " " . str_replace("col-", "offset-", $class);
			$this->TableLeftColumnClass = preg_replace('/^col-\w+-(\d+)$/', "w-col-$1", $class); // Change to w-col-*
		}
	}

	// Single column sort
	public function updateSort(&$fld)
	{
		if ($this->CurrentOrder == $fld->Name) {
			$sortField = $fld->Expression;
			$lastSort = $fld->getSort();
			if ($this->CurrentOrderType == "ASC" || $this->CurrentOrderType == "DESC") {
				$thisSort = $this->CurrentOrderType;
			} else {
				$thisSort = ($lastSort == "ASC") ? "DESC" : "ASC";
			}
			$fld->setSort($thisSort);
			$this->setSessionOrderBy($sortField . " " . $thisSort); // Save to Session
		} else {
			$fld->setSort("");
		}
	}

	// Table level SQL
	public function getSqlFrom() // From
	{
		return ($this->SqlFrom != "") ? $this->SqlFrom : "`nodepipool`";
	}
	public function sqlFrom() // For backward compatibility
	{
		return $this->getSqlFrom();
	}
	public function setSqlFrom($v)
	{
		$this->SqlFrom = $v;
	}
	public function getSqlSelect() // Select
	{
		return ($this->SqlSelect != "") ? $this->SqlSelect : "SELECT * FROM " . $this->getSqlFrom();
	}
	public function sqlSelect() // For backward compatibility
	{
		return $this->getSqlSelect();
	}
	public function setSqlSelect($v)
	{
		$this->SqlSelect = $v;
	}
	public function getSqlWhere() // Where
	{
		$where = ($this->SqlWhere != "") ? $this->SqlWhere : "";
		$this->TableFilter = "";
		AddFilter($where, $this->TableFilter);
		return $where;
	}
	public function sqlWhere() // For backward compatibility
	{
		return $this->getSqlWhere();
	}
	public function setSqlWhere($v)
	{
		$this->SqlWhere = $v;
	}
	public function getSqlGroupBy() // Group By
	{
		return ($this->SqlGroupBy != "") ? $this->SqlGroupBy : "";
	}
	public function sqlGroupBy() // For backward compatibility
	{
		return $this->getSqlGroupBy();
	}
	public function setSqlGroupBy($v)
	{
		$this->SqlGroupBy = $v;
	}
	public function getSqlHaving() // Having
	{
		return ($this->SqlHaving != "") ? $this->SqlHaving : "";
	}
	public function sqlHaving() // For backward compatibility
	{
		return $this->getSqlHaving();
	}
	public function setSqlHaving($v)
	{
		$this->SqlHaving = $v;
	}
	public function getSqlOrderBy() // Order By
	{
		return ($this->SqlOrderBy != "") ? $this->SqlOrderBy : "";
	}
	public function sqlOrderBy() // For backward compatibility
	{
		return $this->getSqlOrderBy();
	}
	public function setSqlOrderBy($v)
	{
		$this->SqlOrderBy = $v;
	}

	// Apply User ID filters
	public function applyUserIDFilters($filter, $id = "")
	{
		return $filter;
	}

	// Check if User ID security allows view all
	public function userIDAllow($id = "")
	{
		$allow = $this->UserIDAllowSecurity;
		switch ($id) {
			case "add":
			case "copy":
			case "gridadd":
			case "register":
			case "addopt":
				return (($allow & 1) == 1);
			case "edit":
			case "gridedit":
			case "update":
			case "changepwd":
			case "forgotpwd":
				return (($allow & 4) == 4);
			case "delete":
				return (($allow & 2) == 2);
			case "view":
				return (($allow & 32) == 32);
			case "search":
				return (($allow & 64) == 64);
			case "lookup":
				return (($allow & 256) == 256);
			default:
				return (($allow & 8) == 8);
		}
	}

	// Get recordset
	public function getRecordset($sql, $rowcnt = -1, $offset = -1)
	{
		$conn = $this->getConnection();
		$conn->raiseErrorFn = Config("ERROR_FUNC");
		$rs = $conn->selectLimit($sql, $rowcnt, $offset);
		$conn->raiseErrorFn = "";
		return $rs;
	}

	// Get record count
	public function getRecordCount($sql, $c = NULL)
	{
		$cnt = -1;
		$rs = NULL;
		$sql = preg_replace('/\/\*BeginOrderBy\*\/[\s\S]+\/\*EndOrderBy\*\//', "", $sql); // Remove ORDER BY clause (MSSQL)
		$pattern = '/^SELECT\s([\s\S]+)\sFROM\s/i';

		// Skip Custom View / SubQuery / SELECT DISTINCT / ORDER BY
		if (($this->TableType == 'TABLE' || $this->TableType == 'VIEW' || $this->TableType == 'LINKTABLE') &&
			preg_match($pattern, $sql) && !preg_match('/\(\s*(SELECT[^)]+)\)/i', $sql) &&
			!preg_match('/^\s*select\s+distinct\s+/i', $sql) && !preg_match('/\s+order\s+by\s+/i', $sql)) {
			$sqlwrk = "SELECT COUNT(*) FROM " . preg_replace($pattern, "", $sql);
		} else {
			$sqlwrk = "SELECT COUNT(*) FROM (" . $sql . ") COUNT_TABLE";
		}
		$conn = $c ?: $this->getConnection();
		if ($rs = $conn->execute($sqlwrk)) {
			if (!$rs->EOF && $rs->FieldCount() > 0) {
				$cnt = $rs->fields[0];
				$rs->close();
			}
			return (int)$cnt;
		}

		// Unable to get count, get record count directly
		if ($rs = $conn->execute($sql)) {
			$cnt = $rs->RecordCount();
			$rs->close();
			return (int)$cnt;
		}
		return $cnt;
	}

	// Get SQL
	public function getSql($where, $orderBy = "")
	{
		return BuildSelectSql($this->getSqlSelect(), $this->getSqlWhere(),
			$this->getSqlGroupBy(), $this->getSqlHaving(), $this->getSqlOrderBy(),
			$where, $orderBy);
	}

	// Table SQL
	public function getCurrentSql()
	{
		$filter = $this->CurrentFilter;
		$filter = $this->applyUserIDFilters($filter);
		$sort = $this->getSessionOrderBy();
		return $this->getSql($filter, $sort);
	}

	// Table SQL with List page filter
	public function getListSql()
	{
		$filter = $this->UseSessionForListSql ? $this->getSessionWhere() : "";
		AddFilter($filter, $this->CurrentFilter);
		$filter = $this->applyUserIDFilters($filter);
		$this->Recordset_Selecting($filter);
		$select = $this->getSqlSelect();
		$sort = $this->UseSessionForListSql ? $this->getSessionOrderBy() : "";
		return BuildSelectSql($select, $this->getSqlWhere(), $this->getSqlGroupBy(),
			$this->getSqlHaving(), $this->getSqlOrderBy(), $filter, $sort);
	}

	// Get ORDER BY clause
	public function getOrderBy()
	{
		$sort = $this->getSessionOrderBy();
		return BuildSelectSql("", "", "", "", $this->getSqlOrderBy(), "", $sort);
	}

	// Get record count based on filter (for detail record count in master table pages)
	public function loadRecordCount($filter)
	{
		$origFilter = $this->CurrentFilter;
		$this->CurrentFilter = $filter;
		$this->Recordset_Selecting($this->CurrentFilter);
		$select = $this->TableType == 'CUSTOMVIEW' ? $this->getSqlSelect() : "SELECT * FROM " . $this->getSqlFrom();
		$groupBy = $this->TableType == 'CUSTOMVIEW' ? $this->getSqlGroupBy() : "";
		$having = $this->TableType == 'CUSTOMVIEW' ? $this->getSqlHaving() : "";
		$sql = BuildSelectSql($select, $this->getSqlWhere(), $groupBy, $having, "", $this->CurrentFilter, "");
		$cnt = $this->getRecordCount($sql);
		$this->CurrentFilter = $origFilter;
		return $cnt;
	}

	// Get record count (for current List page)
	public function listRecordCount()
	{
		$filter = $this->getSessionWhere();
		AddFilter($filter, $this->CurrentFilter);
		$filter = $this->applyUserIDFilters($filter);
		$this->Recordset_Selecting($filter);
		$select = $this->TableType == 'CUSTOMVIEW' ? $this->getSqlSelect() : "SELECT * FROM " . $this->getSqlFrom();
		$groupBy = $this->TableType == 'CUSTOMVIEW' ? $this->getSqlGroupBy() : "";
		$having = $this->TableType == 'CUSTOMVIEW' ? $this->getSqlHaving() : "";
		$sql = BuildSelectSql($select, $this->getSqlWhere(), $groupBy, $having, "", $filter, "");
		$cnt = $this->getRecordCount($sql);
		return $cnt;
	}

	// INSERT statement
	protected function insertSql(&$rs)
	{
		$names = "";
		$values = "";
		foreach ($rs as $name => $value) {
			if (!isset($this->fields[$name]) || $this->fields[$name]->IsCustom)
				continue;
			$names .= $this->fields[$name]->Expression . ",";
			$values .= QuotedValue($value, $this->fields[$name]->DataType, $this->Dbid) . ",";
		}
		$names = preg_replace('/,+$/', "", $names);
		$values = preg_replace('/,+$/', "", $values);
		return "INSERT INTO " . $this->UpdateTable . " (" . $names . ") VALUES (" . $values . ")";
	}

	// Insert
	public function insert(&$rs)
	{
		$conn = $this->getConnection();
		$success = $conn->execute($this->insertSql($rs));
		if ($success) {

			// Get insert id if necessary
			$this->transferID->setDbValue($conn->insert_ID());
			$rs['transferID'] = $this->transferID->DbValue;
			if ($this->AuditTrailOnAdd)
				$this->writeAuditTrailOnAdd($rs);
		}
		return $success;
	}

	// UPDATE statement
	protected function updateSql(&$rs, $where = "", $curfilter = TRUE)
	{
		$sql = "UPDATE " . $this->UpdateTable . " SET ";
		foreach ($rs as $name => $value) {
			if (!isset($this->fields[$name]) || $this->fields[$name]->IsCustom || $this->fields[$name]->IsAutoIncrement)
				continue;
			$sql .= $this->fields[$name]->Expression . "=";
			$sql .= QuotedValue($value, $this->fields[$name]->DataType, $this->Dbid) . ",";
		}
		$sql = preg_replace('/,+$/', "", $sql);
		$filter = ($curfilter) ? $this->CurrentFilter : "";
		if (is_array($where))
			$where = $this->arrayToFilter($where);
		AddFilter($filter, $where);
		if ($filter != "")
			$sql .= " WHERE " . $filter;
		return $sql;
	}

	// Update
	public function update(&$rs, $where = "", $rsold = NULL, $curfilter = TRUE)
	{
		$conn = $this->getConnection();
		$success = $conn->execute($this->updateSql($rs, $where, $curfilter));
		if ($success && $this->AuditTrailOnEdit && $rsold) {
			$rsaudit = $rs;
			$fldname = 'transferID';
			if (!array_key_exists($fldname, $rsaudit))
				$rsaudit[$fldname] = $rsold[$fldname];
			$this->writeAuditTrailOnEdit($rsold, $rsaudit);
		}
		return $success;
	}

	// DELETE statement
	protected function deleteSql(&$rs, $where = "", $curfilter = TRUE)
	{
		$sql = "DELETE FROM " . $this->UpdateTable . " WHERE ";
		if (is_array($where))
			$where = $this->arrayToFilter($where);
		if ($rs) {
			if (array_key_exists('transferID', $rs))
				AddFilter($where, QuotedName('transferID', $this->Dbid) . '=' . QuotedValue($rs['transferID'], $this->transferID->DataType, $this->Dbid));
		}
		$filter = ($curfilter) ? $this->CurrentFilter : "";
		AddFilter($filter, $where);
		if ($filter != "")
			$sql .= $filter;
		else
			$sql .= "0=1"; // Avoid delete
		return $sql;
	}

	// Delete
	public function delete(&$rs, $where = "", $curfilter = FALSE)
	{
		$success = TRUE;
		$conn = $this->getConnection();
		if ($success)
			$success = $conn->execute($this->deleteSql($rs, $where, $curfilter));
		if ($success && $this->AuditTrailOnDelete)
			$this->writeAuditTrailOnDelete($rs);
		return $success;
	}

	// Load DbValue from recordset or array
	protected function loadDbValues(&$rs)
	{
		if (!$rs || !is_array($rs) && $rs->EOF)
			return;
		$row = is_array($rs) ? $rs : $rs->fields;
		$this->transferID->DbValue = $row['transferID'];
		$this->txid->DbValue = $row['txid'];
		$this->sourceUserID->DbValue = $row['sourceUserID'];
		$this->transferTime->DbValue = $row['transferTime'];
		$this->comments->DbValue = $row['comments'];
		$this->type->DbValue = $row['type'];
		$this->lastUpdateDateTime->DbValue = $row['lastUpdateDateTime'];
		$this->confirmCode->DbValue = $row['confirmCode'];
		$this->status->DbValue = $row['status'];
		$this->tries->DbValue = $row['tries'];
		$this->locked->DbValue = $row['locked'];
		$this->internal->DbValue = $row['internal'];
		$this->senderpi->DbValue = $row['senderpi'];
		$this->senderpiid->DbValue = $row['senderpiid'];
		$this->recipientid->DbValue = $row['recipientid'];
		$this->presentationcode->DbValue = $row['presentationcode'];
		$this->recipientname->DbValue = $row['recipientname'];
		$this->sendername->DbValue = $row['sendername'];
		$this->description->DbValue = $row['description'];
	}

	// Delete uploaded files
	public function deleteUploadedFiles($row)
	{
		$this->loadDbValues($row);
	}

	// Record filter WHERE clause
	protected function sqlKeyFilter()
	{
		return "`transferID` = @transferID@";
	}

	// Get record filter
	public function getRecordFilter($row = NULL)
	{
		$keyFilter = $this->sqlKeyFilter();
		if (is_array($row))
			$val = array_key_exists('transferID', $row) ? $row['transferID'] : NULL;
		else
			$val = $this->transferID->OldValue !== NULL ? $this->transferID->OldValue : $this->transferID->CurrentValue;
		if (!is_numeric($val))
			return "0=1"; // Invalid key
		if ($val == NULL)
			return "0=1"; // Invalid key
		else
			$keyFilter = str_replace("@transferID@", AdjustSql($val, $this->Dbid), $keyFilter); // Replace key value
		return $keyFilter;
	}

	// Return page URL
	public function getReturnUrl()
	{
		$name = PROJECT_NAME . "_" . $this->TableVar . "_" . Config("TABLE_RETURN_URL");

		// Get referer URL automatically
		if (ServerVar("HTTP_REFERER") != "" && ReferPageName() != CurrentPageName() && ReferPageName() != "login.php") // Referer not same page or login page
			$_SESSION[$name] = ServerVar("HTTP_REFERER"); // Save to Session
		if (@$_SESSION[$name] != "") {
			return $_SESSION[$name];
		} else {
			return "nodepipoollist.php";
		}
	}
	public function setReturnUrl($v)
	{
		$_SESSION[PROJECT_NAME . "_" . $this->TableVar . "_" . Config("TABLE_RETURN_URL")] = $v;
	}

	// Get modal caption
	public function getModalCaption($pageName)
	{
		global $Language;
		if ($pageName == "nodepipoolview.php")
			return $Language->phrase("View");
		elseif ($pageName == "nodepipooledit.php")
			return $Language->phrase("Edit");
		elseif ($pageName == "nodepipooladd.php")
			return $Language->phrase("Add");
		else
			return "";
	}

	// List URL
	public function getListUrl()
	{
		return "nodepipoollist.php";
	}

	// View URL
	public function getViewUrl($parm = "")
	{
		if ($parm != "")
			$url = $this->keyUrl("nodepipoolview.php", $this->getUrlParm($parm));
		else
			$url = $this->keyUrl("nodepipoolview.php", $this->getUrlParm(Config("TABLE_SHOW_DETAIL") . "="));
		return $this->addMasterUrl($url);
	}

	// Add URL
	public function getAddUrl($parm = "")
	{
		if ($parm != "")
			$url = "nodepipooladd.php?" . $this->getUrlParm($parm);
		else
			$url = "nodepipooladd.php";
		return $this->addMasterUrl($url);
	}

	// Edit URL
	public function getEditUrl($parm = "")
	{
		$url = $this->keyUrl("nodepipooledit.php", $this->getUrlParm($parm));
		return $this->addMasterUrl($url);
	}

	// Inline edit URL
	public function getInlineEditUrl()
	{
		$url = $this->keyUrl(CurrentPageName(), $this->getUrlParm("action=edit"));
		return $this->addMasterUrl($url);
	}

	// Copy URL
	public function getCopyUrl($parm = "")
	{
		$url = $this->keyUrl("nodepipooladd.php", $this->getUrlParm($parm));
		return $this->addMasterUrl($url);
	}

	// Inline copy URL
	public function getInlineCopyUrl()
	{
		$url = $this->keyUrl(CurrentPageName(), $this->getUrlParm("action=copy"));
		return $this->addMasterUrl($url);
	}

	// Delete URL
	public function getDeleteUrl()
	{
		return $this->keyUrl("nodepipooldelete.php", $this->getUrlParm());
	}

	// Add master url
	public function addMasterUrl($url)
	{
		return $url;
	}
	public function keyToJson($htmlEncode = FALSE)
	{
		$json = "";
		$json .= "transferID:" . JsonEncode($this->transferID->CurrentValue, "number");
		$json = "{" . $json . "}";
		if ($htmlEncode)
			$json = HtmlEncode($json);
		return $json;
	}

	// Add key value to URL
	public function keyUrl($url, $parm = "")
	{
		$url = $url . "?";
		if ($parm != "")
			$url .= $parm . "&";
		if ($this->transferID->CurrentValue != NULL) {
			$url .= "transferID=" . urlencode($this->transferID->CurrentValue);
		} else {
			return "javascript:ew.alert(ew.language.phrase('InvalidRecord'));";
		}
		return $url;
	}

	// Sort URL
	public function sortUrl(&$fld)
	{
		if ($this->CurrentAction || $this->isExport() ||
			in_array($fld->Type, [128, 204, 205])) { // Unsortable data type
				return "";
		} elseif ($fld->Sortable) {
			$urlParm = $this->getUrlParm("order=" . urlencode($fld->Name) . "&amp;ordertype=" . $fld->reverseSort());
			return $this->addMasterUrl(CurrentPageName() . "?" . $urlParm);
		} else {
			return "";
		}
	}

	// Get record keys from Post/Get/Session
	public function getRecordKeys()
	{
		$arKeys = [];
		$arKey = [];
		if (Param("key_m") !== NULL) {
			$arKeys = Param("key_m");
			$cnt = count($arKeys);
		} else {
			if (Param("transferID") !== NULL)
				$arKeys[] = Param("transferID");
			elseif (IsApi() && Key(0) !== NULL)
				$arKeys[] = Key(0);
			elseif (IsApi() && Route(2) !== NULL)
				$arKeys[] = Route(2);
			else
				$arKeys = NULL; // Do not setup

			//return $arKeys; // Do not return yet, so the values will also be checked by the following code
		}

		// Check keys
		$ar = [];
		if (is_array($arKeys)) {
			foreach ($arKeys as $key) {
				if (!is_numeric($key))
					continue;
				$ar[] = $key;
			}
		}
		return $ar;
	}

	// Get filter from record keys
	public function getFilterFromRecordKeys($setCurrent = TRUE)
	{
		$arKeys = $this->getRecordKeys();
		$keyFilter = "";
		foreach ($arKeys as $key) {
			if ($keyFilter != "") $keyFilter .= " OR ";
			if ($setCurrent)
				$this->transferID->CurrentValue = $key;
			else
				$this->transferID->OldValue = $key;
			$keyFilter .= "(" . $this->getRecordFilter() . ")";
		}
		return $keyFilter;
	}

	// Load rows based on filter
	public function &loadRs($filter)
	{

		// Set up filter (WHERE Clause)
		$sql = $this->getSql($filter);
		$conn = $this->getConnection();
		$rs = $conn->execute($sql);
		return $rs;
	}

	// Load row values from recordset
	public function loadListRowValues(&$rs)
	{
		$this->transferID->setDbValue($rs->fields('transferID'));
		$this->txid->setDbValue($rs->fields('txid'));
		$this->sourceUserID->setDbValue($rs->fields('sourceUserID'));
		$this->transferTime->setDbValue($rs->fields('transferTime'));
		$this->comments->setDbValue($rs->fields('comments'));
		$this->type->setDbValue($rs->fields('type'));
		$this->lastUpdateDateTime->setDbValue($rs->fields('lastUpdateDateTime'));
		$this->confirmCode->setDbValue($rs->fields('confirmCode'));
		$this->status->setDbValue($rs->fields('status'));
		$this->tries->setDbValue($rs->fields('tries'));
		$this->locked->setDbValue($rs->fields('locked'));
		$this->internal->setDbValue($rs->fields('internal'));
		$this->senderpi->setDbValue($rs->fields('senderpi'));
		$this->senderpiid->setDbValue($rs->fields('senderpiid'));
		$this->recipientid->setDbValue($rs->fields('recipientid'));
		$this->presentationcode->setDbValue($rs->fields('presentationcode'));
		$this->recipientname->setDbValue($rs->fields('recipientname'));
		$this->sendername->setDbValue($rs->fields('sendername'));
		$this->description->setDbValue($rs->fields('description'));
	}

	// Render list row values
	public function renderListRow()
	{
		global $Security, $CurrentLanguage, $Language;

		// Call Row Rendering event
		$this->Row_Rendering();

		// Common render codes
		// transferID
		// txid
		// sourceUserID
		// transferTime
		// comments
		// type
		// lastUpdateDateTime
		// confirmCode
		// status
		// tries
		// locked
		// internal
		// senderpi
		// senderpiid
		// recipientid
		// presentationcode
		// recipientname
		// sendername
		// description
		// transferID

		$this->transferID->ViewValue = $this->transferID->CurrentValue;
		$this->transferID->ViewCustomAttributes = "";

		// txid
		$this->txid->ViewValue = $this->txid->CurrentValue;
		$this->txid->ViewCustomAttributes = "";

		// sourceUserID
		$this->sourceUserID->ViewValue = $this->sourceUserID->CurrentValue;
		$this->sourceUserID->ViewValue = FormatNumber($this->sourceUserID->ViewValue, 0, -2, -2, -2);
		$this->sourceUserID->ViewCustomAttributes = "";

		// transferTime
		$this->transferTime->ViewValue = $this->transferTime->CurrentValue;
		$this->transferTime->ViewValue = FormatDateTime($this->transferTime->ViewValue, 0);
		$this->transferTime->ViewCustomAttributes = "";

		// comments
		$this->comments->ViewValue = $this->comments->CurrentValue;
		$this->comments->ViewCustomAttributes = "";

		// type
		$this->type->ViewValue = $this->type->CurrentValue;
		$this->type->ViewValue = FormatNumber($this->type->ViewValue, 0, -2, -2, -2);
		$this->type->ViewCustomAttributes = "";

		// lastUpdateDateTime
		$this->lastUpdateDateTime->ViewValue = $this->lastUpdateDateTime->CurrentValue;
		$this->lastUpdateDateTime->ViewValue = FormatDateTime($this->lastUpdateDateTime->ViewValue, 0);
		$this->lastUpdateDateTime->ViewCustomAttributes = "";

		// confirmCode
		$this->confirmCode->ViewValue = $this->confirmCode->CurrentValue;
		$this->confirmCode->ViewCustomAttributes = "";

		// status
		$this->status->ViewValue = $this->status->CurrentValue;
		$this->status->ViewValue = FormatNumber($this->status->ViewValue, 0, -2, -2, -2);
		$this->status->ViewCustomAttributes = "";

		// tries
		$this->tries->ViewValue = $this->tries->CurrentValue;
		$this->tries->ViewValue = FormatNumber($this->tries->ViewValue, 0, -2, -2, -2);
		$this->tries->ViewCustomAttributes = "";

		// locked
		$this->locked->ViewValue = $this->locked->CurrentValue;
		$this->locked->ViewValue = FormatNumber($this->locked->ViewValue, 0, -2, -2, -2);
		$this->locked->ViewCustomAttributes = "";

		// internal
		$this->internal->ViewValue = $this->internal->CurrentValue;
		$this->internal->ViewValue = FormatNumber($this->internal->ViewValue, 0, -2, -2, -2);
		$this->internal->ViewCustomAttributes = "";

		// senderpi
		$this->senderpi->ViewValue = $this->senderpi->CurrentValue;
		$this->senderpi->ViewValue = FormatNumber($this->senderpi->ViewValue, 0, -2, -2, -2);
		$this->senderpi->ViewCustomAttributes = "";

		// senderpiid
		$this->senderpiid->ViewValue = $this->senderpiid->CurrentValue;
		$this->senderpiid->ViewValue = FormatNumber($this->senderpiid->ViewValue, 0, -2, -2, -2);
		$this->senderpiid->ViewCustomAttributes = "";

		// recipientid
		$this->recipientid->ViewValue = $this->recipientid->CurrentValue;
		$this->recipientid->ViewCustomAttributes = "";

		// presentationcode
		$this->presentationcode->ViewValue = $this->presentationcode->CurrentValue;
		$this->presentationcode->ViewValue = FormatNumber($this->presentationcode->ViewValue, 0, -2, -2, -2);
		$this->presentationcode->ViewCustomAttributes = "";

		// recipientname
		$this->recipientname->ViewValue = $this->recipientname->CurrentValue;
		$this->recipientname->ViewCustomAttributes = "";

		// sendername
		$this->sendername->ViewValue = $this->sendername->CurrentValue;
		$this->sendername->ViewCustomAttributes = "";

		// description
		$this->description->ViewValue = $this->description->CurrentValue;
		$this->description->ViewCustomAttributes = "";

		// transferID
		$this->transferID->LinkCustomAttributes = "";
		$this->transferID->HrefValue = "";
		$this->transferID->TooltipValue = "";

		// txid
		$this->txid->LinkCustomAttributes = "";
		$this->txid->HrefValue = "";
		$this->txid->TooltipValue = "";

		// sourceUserID
		$this->sourceUserID->LinkCustomAttributes = "";
		$this->sourceUserID->HrefValue = "";
		$this->sourceUserID->TooltipValue = "";

		// transferTime
		$this->transferTime->LinkCustomAttributes = "";
		$this->transferTime->HrefValue = "";
		$this->transferTime->TooltipValue = "";

		// comments
		$this->comments->LinkCustomAttributes = "";
		$this->comments->HrefValue = "";
		$this->comments->TooltipValue = "";

		// type
		$this->type->LinkCustomAttributes = "";
		$this->type->HrefValue = "";
		$this->type->TooltipValue = "";

		// lastUpdateDateTime
		$this->lastUpdateDateTime->LinkCustomAttributes = "";
		$this->lastUpdateDateTime->HrefValue = "";
		$this->lastUpdateDateTime->TooltipValue = "";

		// confirmCode
		$this->confirmCode->LinkCustomAttributes = "";
		$this->confirmCode->HrefValue = "";
		$this->confirmCode->TooltipValue = "";

		// status
		$this->status->LinkCustomAttributes = "";
		$this->status->HrefValue = "";
		$this->status->TooltipValue = "";

		// tries
		$this->tries->LinkCustomAttributes = "";
		$this->tries->HrefValue = "";
		$this->tries->TooltipValue = "";

		// locked
		$this->locked->LinkCustomAttributes = "";
		$this->locked->HrefValue = "";
		$this->locked->TooltipValue = "";

		// internal
		$this->internal->LinkCustomAttributes = "";
		$this->internal->HrefValue = "";
		$this->internal->TooltipValue = "";

		// senderpi
		$this->senderpi->LinkCustomAttributes = "";
		$this->senderpi->HrefValue = "";
		$this->senderpi->TooltipValue = "";

		// senderpiid
		$this->senderpiid->LinkCustomAttributes = "";
		$this->senderpiid->HrefValue = "";
		$this->senderpiid->TooltipValue = "";

		// recipientid
		$this->recipientid->LinkCustomAttributes = "";
		$this->recipientid->HrefValue = "";
		$this->recipientid->TooltipValue = "";

		// presentationcode
		$this->presentationcode->LinkCustomAttributes = "";
		$this->presentationcode->HrefValue = "";
		$this->presentationcode->TooltipValue = "";

		// recipientname
		$this->recipientname->LinkCustomAttributes = "";
		$this->recipientname->HrefValue = "";
		$this->recipientname->TooltipValue = "";

		// sendername
		$this->sendername->LinkCustomAttributes = "";
		$this->sendername->HrefValue = "";
		$this->sendername->TooltipValue = "";

		// description
		$this->description->LinkCustomAttributes = "";
		$this->description->HrefValue = "";
		$this->description->TooltipValue = "";

		// Call Row Rendered event
		$this->Row_Rendered();

		// Save data for Custom Template
		$this->Rows[] = $this->customTemplateFieldValues();
	}

	// Render edit row values
	public function renderEditRow()
	{
		global $Security, $CurrentLanguage, $Language;

		// Call Row Rendering event
		$this->Row_Rendering();

		// transferID
		$this->transferID->EditAttrs["class"] = "form-control";
		$this->transferID->EditCustomAttributes = "";
		$this->transferID->EditValue = $this->transferID->CurrentValue;
		$this->transferID->ViewCustomAttributes = "";

		// txid
		$this->txid->EditAttrs["class"] = "form-control";
		$this->txid->EditCustomAttributes = "";
		if (!$this->txid->Raw)
			$this->txid->CurrentValue = HtmlDecode($this->txid->CurrentValue);
		$this->txid->EditValue = $this->txid->CurrentValue;
		$this->txid->PlaceHolder = RemoveHtml($this->txid->caption());

		// sourceUserID
		$this->sourceUserID->EditAttrs["class"] = "form-control";
		$this->sourceUserID->EditCustomAttributes = "";
		$this->sourceUserID->EditValue = $this->sourceUserID->CurrentValue;
		$this->sourceUserID->PlaceHolder = RemoveHtml($this->sourceUserID->caption());

		// transferTime
		$this->transferTime->EditAttrs["class"] = "form-control";
		$this->transferTime->EditCustomAttributes = "";
		$this->transferTime->EditValue = FormatDateTime($this->transferTime->CurrentValue, 8);
		$this->transferTime->PlaceHolder = RemoveHtml($this->transferTime->caption());

		// comments
		$this->comments->EditAttrs["class"] = "form-control";
		$this->comments->EditCustomAttributes = "";
		if (!$this->comments->Raw)
			$this->comments->CurrentValue = HtmlDecode($this->comments->CurrentValue);
		$this->comments->EditValue = $this->comments->CurrentValue;
		$this->comments->PlaceHolder = RemoveHtml($this->comments->caption());

		// type
		$this->type->EditAttrs["class"] = "form-control";
		$this->type->EditCustomAttributes = "";
		$this->type->EditValue = $this->type->CurrentValue;
		$this->type->PlaceHolder = RemoveHtml($this->type->caption());

		// lastUpdateDateTime
		$this->lastUpdateDateTime->EditAttrs["class"] = "form-control";
		$this->lastUpdateDateTime->EditCustomAttributes = "";
		$this->lastUpdateDateTime->EditValue = FormatDateTime($this->lastUpdateDateTime->CurrentValue, 8);
		$this->lastUpdateDateTime->PlaceHolder = RemoveHtml($this->lastUpdateDateTime->caption());

		// confirmCode
		$this->confirmCode->EditAttrs["class"] = "form-control";
		$this->confirmCode->EditCustomAttributes = "";
		if (!$this->confirmCode->Raw)
			$this->confirmCode->CurrentValue = HtmlDecode($this->confirmCode->CurrentValue);
		$this->confirmCode->EditValue = $this->confirmCode->CurrentValue;
		$this->confirmCode->PlaceHolder = RemoveHtml($this->confirmCode->caption());

		// status
		$this->status->EditAttrs["class"] = "form-control";
		$this->status->EditCustomAttributes = "";
		$this->status->EditValue = $this->status->CurrentValue;
		$this->status->PlaceHolder = RemoveHtml($this->status->caption());

		// tries
		$this->tries->EditAttrs["class"] = "form-control";
		$this->tries->EditCustomAttributes = "";
		$this->tries->EditValue = $this->tries->CurrentValue;
		$this->tries->PlaceHolder = RemoveHtml($this->tries->caption());

		// locked
		$this->locked->EditAttrs["class"] = "form-control";
		$this->locked->EditCustomAttributes = "";
		$this->locked->EditValue = $this->locked->CurrentValue;
		$this->locked->PlaceHolder = RemoveHtml($this->locked->caption());

		// internal
		$this->internal->EditAttrs["class"] = "form-control";
		$this->internal->EditCustomAttributes = "";
		$this->internal->EditValue = $this->internal->CurrentValue;
		$this->internal->PlaceHolder = RemoveHtml($this->internal->caption());

		// senderpi
		$this->senderpi->EditAttrs["class"] = "form-control";
		$this->senderpi->EditCustomAttributes = "";
		$this->senderpi->EditValue = $this->senderpi->CurrentValue;
		$this->senderpi->PlaceHolder = RemoveHtml($this->senderpi->caption());

		// senderpiid
		$this->senderpiid->EditAttrs["class"] = "form-control";
		$this->senderpiid->EditCustomAttributes = "";
		$this->senderpiid->EditValue = $this->senderpiid->CurrentValue;
		$this->senderpiid->PlaceHolder = RemoveHtml($this->senderpiid->caption());

		// recipientid
		$this->recipientid->EditAttrs["class"] = "form-control";
		$this->recipientid->EditCustomAttributes = "";
		if (!$this->recipientid->Raw)
			$this->recipientid->CurrentValue = HtmlDecode($this->recipientid->CurrentValue);
		$this->recipientid->EditValue = $this->recipientid->CurrentValue;
		$this->recipientid->PlaceHolder = RemoveHtml($this->recipientid->caption());

		// presentationcode
		$this->presentationcode->EditAttrs["class"] = "form-control";
		$this->presentationcode->EditCustomAttributes = "";
		$this->presentationcode->EditValue = $this->presentationcode->CurrentValue;
		$this->presentationcode->PlaceHolder = RemoveHtml($this->presentationcode->caption());

		// recipientname
		$this->recipientname->EditAttrs["class"] = "form-control";
		$this->recipientname->EditCustomAttributes = "";
		if (!$this->recipientname->Raw)
			$this->recipientname->CurrentValue = HtmlDecode($this->recipientname->CurrentValue);
		$this->recipientname->EditValue = $this->recipientname->CurrentValue;
		$this->recipientname->PlaceHolder = RemoveHtml($this->recipientname->caption());

		// sendername
		$this->sendername->EditAttrs["class"] = "form-control";
		$this->sendername->EditCustomAttributes = "";
		if (!$this->sendername->Raw)
			$this->sendername->CurrentValue = HtmlDecode($this->sendername->CurrentValue);
		$this->sendername->EditValue = $this->sendername->CurrentValue;
		$this->sendername->PlaceHolder = RemoveHtml($this->sendername->caption());

		// description
		$this->description->EditAttrs["class"] = "form-control";
		$this->description->EditCustomAttributes = "";
		if (!$this->description->Raw)
			$this->description->CurrentValue = HtmlDecode($this->description->CurrentValue);
		$this->description->EditValue = $this->description->CurrentValue;
		$this->description->PlaceHolder = RemoveHtml($this->description->caption());

		// Call Row Rendered event
		$this->Row_Rendered();
	}

	// Aggregate list row values
	public function aggregateListRowValues()
	{
	}

	// Aggregate list row (for rendering)
	public function aggregateListRow()
	{

		// Call Row Rendered event
		$this->Row_Rendered();
	}

	// Export data in HTML/CSV/Word/Excel/Email/PDF format
	public function exportDocument($doc, $recordset, $startRec = 1, $stopRec = 1, $exportPageType = "")
	{
		if (!$recordset || !$doc)
			return;
		if (!$doc->ExportCustom) {

			// Write header
			$doc->exportTableHeader();
			if ($doc->Horizontal) { // Horizontal format, write header
				$doc->beginExportRow();
				if ($exportPageType == "view") {
					$doc->exportCaption($this->transferID);
					$doc->exportCaption($this->txid);
					$doc->exportCaption($this->sourceUserID);
					$doc->exportCaption($this->transferTime);
					$doc->exportCaption($this->comments);
					$doc->exportCaption($this->type);
					$doc->exportCaption($this->lastUpdateDateTime);
					$doc->exportCaption($this->confirmCode);
					$doc->exportCaption($this->status);
					$doc->exportCaption($this->tries);
					$doc->exportCaption($this->locked);
					$doc->exportCaption($this->internal);
					$doc->exportCaption($this->senderpi);
					$doc->exportCaption($this->senderpiid);
					$doc->exportCaption($this->recipientid);
					$doc->exportCaption($this->presentationcode);
					$doc->exportCaption($this->recipientname);
					$doc->exportCaption($this->sendername);
					$doc->exportCaption($this->description);
				} else {
					$doc->exportCaption($this->transferID);
					$doc->exportCaption($this->txid);
					$doc->exportCaption($this->sourceUserID);
					$doc->exportCaption($this->transferTime);
					$doc->exportCaption($this->comments);
					$doc->exportCaption($this->type);
					$doc->exportCaption($this->lastUpdateDateTime);
					$doc->exportCaption($this->confirmCode);
					$doc->exportCaption($this->status);
					$doc->exportCaption($this->tries);
					$doc->exportCaption($this->locked);
					$doc->exportCaption($this->internal);
					$doc->exportCaption($this->senderpi);
					$doc->exportCaption($this->senderpiid);
					$doc->exportCaption($this->recipientid);
					$doc->exportCaption($this->presentationcode);
					$doc->exportCaption($this->recipientname);
					$doc->exportCaption($this->sendername);
					$doc->exportCaption($this->description);
				}
				$doc->endExportRow();
			}
		}

		// Move to first record
		$recCnt = $startRec - 1;
		if (!$recordset->EOF) {
			$recordset->moveFirst();
			if ($startRec > 1)
				$recordset->move($startRec - 1);
		}
		while (!$recordset->EOF && $recCnt < $stopRec) {
			$recCnt++;
			if ($recCnt >= $startRec) {
				$rowCnt = $recCnt - $startRec + 1;

				// Page break
				if ($this->ExportPageBreakCount > 0) {
					if ($rowCnt > 1 && ($rowCnt - 1) % $this->ExportPageBreakCount == 0)
						$doc->exportPageBreak();
				}
				$this->loadListRowValues($recordset);

				// Render row
				$this->RowType = ROWTYPE_VIEW; // Render view
				$this->resetAttributes();
				$this->renderListRow();
				if (!$doc->ExportCustom) {
					$doc->beginExportRow($rowCnt); // Allow CSS styles if enabled
					if ($exportPageType == "view") {
						$doc->exportField($this->transferID);
						$doc->exportField($this->txid);
						$doc->exportField($this->sourceUserID);
						$doc->exportField($this->transferTime);
						$doc->exportField($this->comments);
						$doc->exportField($this->type);
						$doc->exportField($this->lastUpdateDateTime);
						$doc->exportField($this->confirmCode);
						$doc->exportField($this->status);
						$doc->exportField($this->tries);
						$doc->exportField($this->locked);
						$doc->exportField($this->internal);
						$doc->exportField($this->senderpi);
						$doc->exportField($this->senderpiid);
						$doc->exportField($this->recipientid);
						$doc->exportField($this->presentationcode);
						$doc->exportField($this->recipientname);
						$doc->exportField($this->sendername);
						$doc->exportField($this->description);
					} else {
						$doc->exportField($this->transferID);
						$doc->exportField($this->txid);
						$doc->exportField($this->sourceUserID);
						$doc->exportField($this->transferTime);
						$doc->exportField($this->comments);
						$doc->exportField($this->type);
						$doc->exportField($this->lastUpdateDateTime);
						$doc->exportField($this->confirmCode);
						$doc->exportField($this->status);
						$doc->exportField($this->tries);
						$doc->exportField($this->locked);
						$doc->exportField($this->internal);
						$doc->exportField($this->senderpi);
						$doc->exportField($this->senderpiid);
						$doc->exportField($this->recipientid);
						$doc->exportField($this->presentationcode);
						$doc->exportField($this->recipientname);
						$doc->exportField($this->sendername);
						$doc->exportField($this->description);
					}
					$doc->endExportRow($rowCnt);
				}
			}

			// Call Row Export server event
			if ($doc->ExportCustom)
				$this->Row_Export($recordset->fields);
			$recordset->moveNext();
		}
		if (!$doc->ExportCustom) {
			$doc->exportTableFooter();
		}
	}

	// Get file data
	public function getFileData($fldparm, $key, $resize, $width = 0, $height = 0)
	{

		// No binary fields
		return FALSE;
	}

	// Write Audit Trail start/end for grid update
	public function writeAuditTrailDummy($typ)
	{
		$table = 'nodepipool';
		$usr = CurrentUserName();
		WriteAuditTrail("log", DbCurrentDateTime(), ScriptName(), $usr, $typ, $table, "", "", "", "");
	}

	// Write Audit Trail (add page)
	public function writeAuditTrailOnAdd(&$rs)
	{
		global $Language;
		if (!$this->AuditTrailOnAdd)
			return;
		$table = 'nodepipool';

		// Get key value
		$key = "";
		if ($key != "")
			$key .= Config("COMPOSITE_KEY_SEPARATOR");
		$key .= $rs['transferID'];

		// Write Audit Trail
		$dt = DbCurrentDateTime();
		$id = ScriptName();
		$usr = CurrentUserName();
		foreach (array_keys($rs) as $fldname) {
			if (array_key_exists($fldname, $this->fields) && $this->fields[$fldname]->DataType != DATATYPE_BLOB) { // Ignore BLOB fields
				if ($this->fields[$fldname]->HtmlTag == "PASSWORD") {
					$newvalue = $Language->phrase("PasswordMask"); // Password Field
				} elseif ($this->fields[$fldname]->DataType == DATATYPE_MEMO) {
					if (Config("AUDIT_TRAIL_TO_DATABASE"))
						$newvalue = $rs[$fldname];
					else
						$newvalue = "[MEMO]"; // Memo Field
				} elseif ($this->fields[$fldname]->DataType == DATATYPE_XML) {
					$newvalue = "[XML]"; // XML Field
				} else {
					$newvalue = $rs[$fldname];
				}
				WriteAuditTrail("log", $dt, $id, $usr, "A", $table, $fldname, $key, "", $newvalue);
			}
		}
	}

	// Write Audit Trail (edit page)
	public function writeAuditTrailOnEdit(&$rsold, &$rsnew)
	{
		global $Language;
		if (!$this->AuditTrailOnEdit)
			return;
		$table = 'nodepipool';

		// Get key value
		$key = "";
		if ($key != "")
			$key .= Config("COMPOSITE_KEY_SEPARATOR");
		$key .= $rsold['transferID'];

		// Write Audit Trail
		$dt = DbCurrentDateTime();
		$id = ScriptName();
		$usr = CurrentUserName();
		foreach (array_keys($rsnew) as $fldname) {
			if (array_key_exists($fldname, $this->fields) && array_key_exists($fldname, $rsold) && $this->fields[$fldname]->DataType != DATATYPE_BLOB) { // Ignore BLOB fields
				if ($this->fields[$fldname]->DataType == DATATYPE_DATE) { // DateTime field
					$modified = (FormatDateTime($rsold[$fldname], 0) != FormatDateTime($rsnew[$fldname], 0));
				} else {
					$modified = !CompareValue($rsold[$fldname], $rsnew[$fldname]);
				}
				if ($modified) {
					if ($this->fields[$fldname]->HtmlTag == "PASSWORD") { // Password Field
						$oldvalue = $Language->phrase("PasswordMask");
						$newvalue = $Language->phrase("PasswordMask");
					} elseif ($this->fields[$fldname]->DataType == DATATYPE_MEMO) { // Memo field
						if (Config("AUDIT_TRAIL_TO_DATABASE")) {
							$oldvalue = $rsold[$fldname];
							$newvalue = $rsnew[$fldname];
						} else {
							$oldvalue = "[MEMO]";
							$newvalue = "[MEMO]";
						}
					} elseif ($this->fields[$fldname]->DataType == DATATYPE_XML) { // XML field
						$oldvalue = "[XML]";
						$newvalue = "[XML]";
					} else {
						$oldvalue = $rsold[$fldname];
						$newvalue = $rsnew[$fldname];
					}
					WriteAuditTrail("log", $dt, $id, $usr, "U", $table, $fldname, $key, $oldvalue, $newvalue);
				}
			}
		}
	}

	// Write Audit Trail (delete page)
	public function writeAuditTrailOnDelete(&$rs)
	{
		global $Language;
		if (!$this->AuditTrailOnDelete)
			return;
		$table = 'nodepipool';

		// Get key value
		$key = "";
		if ($key != "")
			$key .= Config("COMPOSITE_KEY_SEPARATOR");
		$key .= $rs['transferID'];

		// Write Audit Trail
		$dt = DbCurrentDateTime();
		$id = ScriptName();
		$curUser = CurrentUserName();
		foreach (array_keys($rs) as $fldname) {
			if (array_key_exists($fldname, $this->fields) && $this->fields[$fldname]->DataType != DATATYPE_BLOB) { // Ignore BLOB fields
				if ($this->fields[$fldname]->HtmlTag == "PASSWORD") {
					$oldvalue = $Language->phrase("PasswordMask"); // Password Field
				} elseif ($this->fields[$fldname]->DataType == DATATYPE_MEMO) {
					if (Config("AUDIT_TRAIL_TO_DATABASE"))
						$oldvalue = $rs[$fldname];
					else
						$oldvalue = "[MEMO]"; // Memo field
				} elseif ($this->fields[$fldname]->DataType == DATATYPE_XML) {
					$oldvalue = "[XML]"; // XML field
				} else {
					$oldvalue = $rs[$fldname];
				}
				WriteAuditTrail("log", $dt, $id, $curUser, "D", $table, $fldname, $key, $oldvalue, "");
			}
		}
	}

	// Table level events
	// Recordset Selecting event
	function Recordset_Selecting(&$filter) {

		// Enter your code here
	}

	// Recordset Selected event
	function Recordset_Selected(&$rs) {

		//echo "Recordset Selected";
	}

	// Recordset Search Validated event
	function Recordset_SearchValidated() {

		// Example:
		//$this->MyField1->AdvancedSearch->SearchValue = "your search criteria"; // Search value

	}

	// Recordset Searching event
	function Recordset_Searching(&$filter) {

		// Enter your code here
	}

	// Row_Selecting event
	function Row_Selecting(&$filter) {

		// Enter your code here
	}

	// Row Selected event
	function Row_Selected(&$rs) {

		//echo "Row Selected";
	}

	// Row Inserting event
	function Row_Inserting($rsold, &$rsnew) {

		// Enter your code here
		// To cancel, set return value to FALSE

		return TRUE;
	}

	// Row Inserted event
	function Row_Inserted($rsold, &$rsnew) {

		//echo "Row Inserted"
	}

	// Row Updating event
	function Row_Updating($rsold, &$rsnew) {

		// Enter your code here
		// To cancel, set return value to FALSE

		return TRUE;
	}

	// Row Updated event
	function Row_Updated($rsold, &$rsnew) {

		//echo "Row Updated";
	}

	// Row Update Conflict event
	function Row_UpdateConflict($rsold, &$rsnew) {

		// Enter your code here
		// To ignore conflict, set return value to FALSE

		return TRUE;
	}

	// Grid Inserting event
	function Grid_Inserting() {

		// Enter your code here
		// To reject grid insert, set return value to FALSE

		return TRUE;
	}

	// Grid Inserted event
	function Grid_Inserted($rsnew) {

		//echo "Grid Inserted";
	}

	// Grid Updating event
	function Grid_Updating($rsold) {

		// Enter your code here
		// To reject grid update, set return value to FALSE

		return TRUE;
	}

	// Grid Updated event
	function Grid_Updated($rsold, $rsnew) {

		//echo "Grid Updated";
	}

	// Row Deleting event
	function Row_Deleting(&$rs) {

		// Enter your code here
		// To cancel, set return value to False

		return TRUE;
	}

	// Row Deleted event
	function Row_Deleted(&$rs) {

		//echo "Row Deleted";
	}

	// Email Sending event
	function Email_Sending($email, &$args) {

		//var_dump($email); var_dump($args); exit();
		return TRUE;
	}

	// Lookup Selecting event
	function Lookup_Selecting($fld, &$filter) {

		//var_dump($fld->Name, $fld->Lookup, $filter); // Uncomment to view the filter
		// Enter your code here

	}

	// Row Rendering event
	function Row_Rendering() {

		// Enter your code here
	}

	// Row Rendered event
	function Row_Rendered() {

		// To view properties of field class, use:
		//var_dump($this-><FieldName>);

	}

	// User ID Filtering event
	function UserID_Filtering(&$filter) {

		// Enter your code here
	}
}
?>