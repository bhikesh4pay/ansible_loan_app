<?php
namespace PHPMaker2020\_4payadmin;

/**
 * Page class
 */
class cardprograms_delete extends cardprograms
{

	// Page ID
	public $PageID = "delete";

	// Project ID
	public $ProjectID = "{153C2D2E-60EE-4944-8753-3935EB38E8D6}";

	// Table name
	public $TableName = 'cardprograms';

	// Page object name
	public $PageObjName = "cardprograms_delete";

	// Page headings
	public $Heading = "";
	public $Subheading = "";
	public $PageHeader;
	public $PageFooter;

	// Token
	public $Token = "";
	public $TokenTimeout = 0;
	public $CheckToken;

	// Page heading
	public function pageHeading()
	{
		global $Language;
		if ($this->Heading != "")
			return $this->Heading;
		if (method_exists($this, "tableCaption"))
			return $this->tableCaption();
		return "";
	}

	// Page subheading
	public function pageSubheading()
	{
		global $Language;
		if ($this->Subheading != "")
			return $this->Subheading;
		if ($this->TableName)
			return $Language->phrase($this->PageID);
		return "";
	}

	// Page name
	public function pageName()
	{
		return CurrentPageName();
	}

	// Page URL
	public function pageUrl()
	{
		$url = CurrentPageName() . "?";
		if ($this->UseTokenInUrl)
			$url .= "t=" . $this->TableVar . "&"; // Add page token
		return $url;
	}

	// Messages
	private $_message = "";
	private $_failureMessage = "";
	private $_successMessage = "";
	private $_warningMessage = "";

	// Get message
	public function getMessage()
	{
		return isset($_SESSION[SESSION_MESSAGE]) ? $_SESSION[SESSION_MESSAGE] : $this->_message;
	}

	// Set message
	public function setMessage($v)
	{
		AddMessage($this->_message, $v);
		$_SESSION[SESSION_MESSAGE] = $this->_message;
	}

	// Get failure message
	public function getFailureMessage()
	{
		return isset($_SESSION[SESSION_FAILURE_MESSAGE]) ? $_SESSION[SESSION_FAILURE_MESSAGE] : $this->_failureMessage;
	}

	// Set failure message
	public function setFailureMessage($v)
	{
		AddMessage($this->_failureMessage, $v);
		$_SESSION[SESSION_FAILURE_MESSAGE] = $this->_failureMessage;
	}

	// Get success message
	public function getSuccessMessage()
	{
		return isset($_SESSION[SESSION_SUCCESS_MESSAGE]) ? $_SESSION[SESSION_SUCCESS_MESSAGE] : $this->_successMessage;
	}

	// Set success message
	public function setSuccessMessage($v)
	{
		AddMessage($this->_successMessage, $v);
		$_SESSION[SESSION_SUCCESS_MESSAGE] = $this->_successMessage;
	}

	// Get warning message
	public function getWarningMessage()
	{
		return isset($_SESSION[SESSION_WARNING_MESSAGE]) ? $_SESSION[SESSION_WARNING_MESSAGE] : $this->_warningMessage;
	}

	// Set warning message
	public function setWarningMessage($v)
	{
		AddMessage($this->_warningMessage, $v);
		$_SESSION[SESSION_WARNING_MESSAGE] = $this->_warningMessage;
	}

	// Clear message
	public function clearMessage()
	{
		$this->_message = "";
		$_SESSION[SESSION_MESSAGE] = "";
	}

	// Clear failure message
	public function clearFailureMessage()
	{
		$this->_failureMessage = "";
		$_SESSION[SESSION_FAILURE_MESSAGE] = "";
	}

	// Clear success message
	public function clearSuccessMessage()
	{
		$this->_successMessage = "";
		$_SESSION[SESSION_SUCCESS_MESSAGE] = "";
	}

	// Clear warning message
	public function clearWarningMessage()
	{
		$this->_warningMessage = "";
		$_SESSION[SESSION_WARNING_MESSAGE] = "";
	}

	// Clear messages
	public function clearMessages()
	{
		$this->clearMessage();
		$this->clearFailureMessage();
		$this->clearSuccessMessage();
		$this->clearWarningMessage();
	}

	// Show message
	public function showMessage()
	{
		$hidden = FALSE;
		$html = "";

		// Message
		$message = $this->getMessage();
		if (method_exists($this, "Message_Showing"))
			$this->Message_Showing($message, "");
		if ($message != "") { // Message in Session, display
			if (!$hidden)
				$message = '<button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button>' . $message;
			$html .= '<div class="alert alert-info alert-dismissible ew-info"><i class="icon fas fa-info"></i>' . $message . '</div>';
			$_SESSION[SESSION_MESSAGE] = ""; // Clear message in Session
		}

		// Warning message
		$warningMessage = $this->getWarningMessage();
		if (method_exists($this, "Message_Showing"))
			$this->Message_Showing($warningMessage, "warning");
		if ($warningMessage != "") { // Message in Session, display
			if (!$hidden)
				$warningMessage = '<button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button>' . $warningMessage;
			$html .= '<div class="alert alert-warning alert-dismissible ew-warning"><i class="icon fas fa-exclamation"></i>' . $warningMessage . '</div>';
			$_SESSION[SESSION_WARNING_MESSAGE] = ""; // Clear message in Session
		}

		// Success message
		$successMessage = $this->getSuccessMessage();
		if (method_exists($this, "Message_Showing"))
			$this->Message_Showing($successMessage, "success");
		if ($successMessage != "") { // Message in Session, display
			if (!$hidden)
				$successMessage = '<button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button>' . $successMessage;
			$html .= '<div class="alert alert-success alert-dismissible ew-success"><i class="icon fas fa-check"></i>' . $successMessage . '</div>';
			$_SESSION[SESSION_SUCCESS_MESSAGE] = ""; // Clear message in Session
		}

		// Failure message
		$errorMessage = $this->getFailureMessage();
		if (method_exists($this, "Message_Showing"))
			$this->Message_Showing($errorMessage, "failure");
		if ($errorMessage != "") { // Message in Session, display
			if (!$hidden)
				$errorMessage = '<button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button>' . $errorMessage;
			$html .= '<div class="alert alert-danger alert-dismissible ew-error"><i class="icon fas fa-ban"></i>' . $errorMessage . '</div>';
			$_SESSION[SESSION_FAILURE_MESSAGE] = ""; // Clear message in Session
		}
		echo '<div class="ew-message-dialog' . (($hidden) ? ' d-none' : "") . '">' . $html . '</div>';
	}

	// Get message as array
	public function getMessages()
	{
		$ar = [];

		// Message
		$message = $this->getMessage();

		//if (method_exists($this, "Message_Showing"))
		//	$this->Message_Showing($message, "");

		if ($message != "") { // Message in Session, display
			$ar["message"] = $message;
			$_SESSION[SESSION_MESSAGE] = ""; // Clear message in Session
		}

		// Warning message
		$warningMessage = $this->getWarningMessage();

		//if (method_exists($this, "Message_Showing"))
		//	$this->Message_Showing($warningMessage, "warning");

		if ($warningMessage != "") { // Message in Session, display
			$ar["warningMessage"] = $warningMessage;
			$_SESSION[SESSION_WARNING_MESSAGE] = ""; // Clear message in Session
		}

		// Success message
		$successMessage = $this->getSuccessMessage();

		//if (method_exists($this, "Message_Showing"))
		//	$this->Message_Showing($successMessage, "success");

		if ($successMessage != "") { // Message in Session, display
			$ar["successMessage"] = $successMessage;
			$_SESSION[SESSION_SUCCESS_MESSAGE] = ""; // Clear message in Session
		}

		// Failure message
		$failureMessage = $this->getFailureMessage();

		//if (method_exists($this, "Message_Showing"))
		//	$this->Message_Showing($failureMessage, "failure");

		if ($failureMessage != "") { // Message in Session, display
			$ar["failureMessage"] = $failureMessage;
			$_SESSION[SESSION_FAILURE_MESSAGE] = ""; // Clear message in Session
		}
		return $ar;
	}

	// Show Page Header
	public function showPageHeader()
	{
		$header = $this->PageHeader;
		$this->Page_DataRendering($header);
		if ($header != "") { // Header exists, display
			echo '<p id="ew-page-header">' . $header . '</p>';
		}
	}

	// Show Page Footer
	public function showPageFooter()
	{
		$footer = $this->PageFooter;
		$this->Page_DataRendered($footer);
		if ($footer != "") { // Footer exists, display
			echo '<p id="ew-page-footer">' . $footer . '</p>';
		}
	}

	// Validate page request
	protected function isPageRequest()
	{
		global $CurrentForm;
		if ($this->UseTokenInUrl) {
			if ($CurrentForm)
				return ($this->TableVar == $CurrentForm->getValue("t"));
			if (Get("t") !== NULL)
				return ($this->TableVar == Get("t"));
		}
		return TRUE;
	}

	// Valid Post
	protected function validPost()
	{
		if (!$this->CheckToken || !IsPost() || IsApi())
			return TRUE;
		if (Post(Config("TOKEN_NAME")) === NULL)
			return FALSE;
		$fn = Config("CHECK_TOKEN_FUNC");
		if (is_callable($fn))
			return $fn(Post(Config("TOKEN_NAME")), $this->TokenTimeout);
		return FALSE;
	}

	// Create Token
	public function createToken()
	{
		global $CurrentToken;
		$fn = Config("CREATE_TOKEN_FUNC"); // Always create token, required by API file/lookup request
		if ($this->Token == "" && is_callable($fn)) // Create token
			$this->Token = $fn();
		$CurrentToken = $this->Token; // Save to global variable
	}

	// Constructor
	public function __construct()
	{
		global $Language, $DashboardReport;
		global $UserTable;

		// Check token
		$this->CheckToken = Config("CHECK_TOKEN");

		// Initialize
		$GLOBALS["Page"] = &$this;
		$this->TokenTimeout = SessionTimeoutTime();

		// Language object
		if (!isset($Language))
			$Language = new Language();

		// Parent constuctor
		parent::__construct();

		// Table object (cardprograms)
		if (!isset($GLOBALS["cardprograms"]) || get_class($GLOBALS["cardprograms"]) == PROJECT_NAMESPACE . "cardprograms") {
			$GLOBALS["cardprograms"] = &$this;
			$GLOBALS["Table"] = &$GLOBALS["cardprograms"];
		}

		// Table object (admin)
		if (!isset($GLOBALS['admin']))
			$GLOBALS['admin'] = new admin();

		// Page ID (for backward compatibility only)
		if (!defined(PROJECT_NAMESPACE . "PAGE_ID"))
			define(PROJECT_NAMESPACE . "PAGE_ID", 'delete');

		// Table name (for backward compatibility only)
		if (!defined(PROJECT_NAMESPACE . "TABLE_NAME"))
			define(PROJECT_NAMESPACE . "TABLE_NAME", 'cardprograms');

		// Start timer
		if (!isset($GLOBALS["DebugTimer"]))
			$GLOBALS["DebugTimer"] = new Timer();

		// Debug message
		LoadDebugMessage();

		// Open connection
		if (!isset($GLOBALS["Conn"]))
			$GLOBALS["Conn"] = $this->getConnection();

		// User table object (admin)
		$UserTable = $UserTable ?: new admin();
	}

	// Terminate page
	public function terminate($url = "")
	{
		global $ExportFileName, $TempImages, $DashboardReport;

		// Page Unload event
		$this->Page_Unload();

		// Global Page Unloaded event (in userfn*.php)
		Page_Unloaded();

		// Export
		global $cardprograms;
		if ($this->CustomExport && $this->CustomExport == $this->Export && array_key_exists($this->CustomExport, Config("EXPORT_CLASSES"))) {
				$content = ob_get_contents();
			if ($ExportFileName == "")
				$ExportFileName = $this->TableVar;
			$class = PROJECT_NAMESPACE . Config("EXPORT_CLASSES." . $this->CustomExport);
			if (class_exists($class)) {
				$doc = new $class($cardprograms);
				$doc->Text = @$content;
				if ($this->isExport("email"))
					echo $this->exportEmail($doc->Text);
				else
					$doc->export();
				DeleteTempImages(); // Delete temp images
				exit();
			}
		}
		if (!IsApi())
			$this->Page_Redirecting($url);

		// Close connection
		CloseConnections();

		// Return for API
		if (IsApi()) {
			$res = $url === TRUE;
			if (!$res) // Show error
				WriteJson(array_merge(["success" => FALSE], $this->getMessages()));
			return;
		}

		// Go to URL if specified
		if ($url != "") {
			if (!Config("DEBUG") && ob_get_length())
				ob_end_clean();
			SaveDebugMessage();
			AddHeader("Location", $url);
		}
		exit();
	}

	// Get records from recordset
	protected function getRecordsFromRecordset($rs, $current = FALSE)
	{
		$rows = [];
		if (is_object($rs)) { // Recordset
			while ($rs && !$rs->EOF) {
				$this->loadRowValues($rs); // Set up DbValue/CurrentValue
				$row = $this->getRecordFromArray($rs->fields);
				if ($current)
					return $row;
				else
					$rows[] = $row;
				$rs->moveNext();
			}
		} elseif (is_array($rs)) {
			foreach ($rs as $ar) {
				$row = $this->getRecordFromArray($ar);
				if ($current)
					return $row;
				else
					$rows[] = $row;
			}
		}
		return $rows;
	}

	// Get record from array
	protected function getRecordFromArray($ar)
	{
		$row = [];
		if (is_array($ar)) {
			foreach ($ar as $fldname => $val) {
				if (array_key_exists($fldname, $this->fields) && ($this->fields[$fldname]->Visible || $this->fields[$fldname]->IsPrimaryKey)) { // Primary key or Visible
					$fld = &$this->fields[$fldname];
					if ($fld->HtmlTag == "FILE") { // Upload field
						if (EmptyValue($val)) {
							$row[$fldname] = NULL;
						} else {
							if ($fld->DataType == DATATYPE_BLOB) {
								$url = FullUrl(GetApiUrl(Config("API_FILE_ACTION"),
									Config("API_OBJECT_NAME") . "=" . $fld->TableVar . "&" .
									Config("API_FIELD_NAME") . "=" . $fld->Param . "&" .
									Config("API_KEY_NAME") . "=" . rawurlencode($this->getRecordKeyValue($ar)))); //*** need to add this? API may not be in the same folder
								$row[$fldname] = ["type" => ContentType($val), "url" => $url, "name" => $fld->Param . ContentExtension($val)];
							} elseif (!$fld->UploadMultiple || !ContainsString($val, Config("MULTIPLE_UPLOAD_SEPARATOR"))) { // Single file
								$url = FullUrl(GetApiUrl(Config("API_FILE_ACTION"),
									Config("API_OBJECT_NAME") . "=" . $fld->TableVar . "&" .
									"fn=" . Encrypt($fld->physicalUploadPath() . $val)));
								$row[$fldname] = ["type" => MimeContentType($val), "url" => $url, "name" => $val];
							} else { // Multiple files
								$files = explode(Config("MULTIPLE_UPLOAD_SEPARATOR"), $val);
								$ar = [];
								foreach ($files as $file) {
									$url = FullUrl(GetApiUrl(Config("API_FILE_ACTION"),
										Config("API_OBJECT_NAME") . "=" . $fld->TableVar . "&" .
										"fn=" . Encrypt($fld->physicalUploadPath() . $file)));
									if (!EmptyValue($file))
										$ar[] = ["type" => MimeContentType($file), "url" => $url, "name" => $file];
								}
								$row[$fldname] = $ar;
							}
						}
					} else {
						$row[$fldname] = $val;
					}
				}
			}
		}
		return $row;
	}

	// Get record key value from array
	protected function getRecordKeyValue($ar)
	{
		$key = "";
		if (is_array($ar)) {
			$key .= @$ar['programid'];
		}
		return $key;
	}

	/**
	 * Hide fields for add/edit
	 *
	 * @return void
	 */
	protected function hideFieldsForAddEdit()
	{
	}

	// Set up API security
	public function setupApiSecurity()
	{
		global $Security;

		// Setup security for API request
		if ($Security->isLoggedIn()) $Security->TablePermission_Loading();
		$Security->loadCurrentUserLevel(Config("PROJECT_ID") . $this->TableName);
		if ($Security->isLoggedIn()) $Security->TablePermission_Loaded();
	}
	public $DbMasterFilter = "";
	public $DbDetailFilter = "";
	public $StartRecord;
	public $TotalRecords = 0;
	public $RecordCount;
	public $RecKeys = [];
	public $StartRowCount = 1;
	public $RowCount = 0;

	//
	// Page run
	//

	public function run()
	{
		global $ExportType, $CustomExportType, $ExportFileName, $UserProfile, $Language, $Security, $CurrentForm;

		// User profile
		$UserProfile = new UserProfile();

		// Security
		if (ValidApiRequest()) { // API request
			$this->setupApiSecurity(); // Set up API Security
			if (!$Security->canDelete()) {
				SetStatus(401); // Unauthorized
				return;
			}
		} else {
			$Security = new AdvancedSecurity();
			if (IsPasswordExpired())
				$this->terminate(GetUrl("changepwd.php"));
			if (!$Security->isLoggedIn())
				$Security->autoLogin();
			if ($Security->isLoggedIn())
				$Security->TablePermission_Loading();
			$Security->loadCurrentUserLevel($this->ProjectID . $this->TableName);
			if ($Security->isLoggedIn())
				$Security->TablePermission_Loaded();
			if (!$Security->canDelete()) {
				$Security->saveLastUrl();
				$this->setFailureMessage(DeniedMessage()); // Set no permission
				if ($Security->canList())
					$this->terminate(GetUrl("cardprogramslist.php"));
				else
					$this->terminate(GetUrl("login.php"));
				return;
			}
		}
		$this->CurrentAction = Param("action"); // Set up current action
		$this->programid->setVisibility();
		$this->programname->setVisibility();
		$this->merchantid->setVisibility();
		$this->purchasefeetabletype->setVisibility();
		$this->purchasefeetableid->setVisibility();
		$this->programfeeaccount->setVisibility();
		$this->defaultcurrencycode->setVisibility();
		$this->purchasetargetpiid->Visible = FALSE;
		$this->status->Visible = FALSE;
		$this->programaccountno->Visible = FALSE;
		$this->paycontrolaccountno->Visible = FALSE;
		$this->claimcodetype->Visible = FALSE;
		$this->programpiid->Visible = FALSE;
		$this->settlementoption->Visible = FALSE;
		$this->settlementdayno->Visible = FALSE;
		$this->merchantcanoverridesettlement->Visible = FALSE;
		$this->settlementminimumcost->Visible = FALSE;
		$this->settlementdefinedcost->Visible = FALSE;
		$this->costabsorbedbymerchant->Visible = FALSE;
		$this->notificationemailaddresses->Visible = FALSE;
		$this->gatewayid->Visible = FALSE;
		$this->gatewayprofileid->Visible = FALSE;
		$this->newaccountemailtemplate->Visible = FALSE;
		$this->newaccountsmstext->Visible = FALSE;
		$this->defaultstatusofnewcards->Visible = FALSE;
		$this->merchantsettlementtype->Visible = FALSE;
		$this->setupminiapp->Visible = FALSE;
		$this->sendverificationsms->Visible = FALSE;
		$this->profile_status->Visible = FALSE;
		$this->other1->Visible = FALSE;
		$this->default_pin->Visible = FALSE;
		$this->franchisee_id->Visible = FALSE;
		$this->defaultverificationemail->Visible = FALSE;
		$this->usertype->Visible = FALSE;
		$this->usersubtype->Visible = FALSE;
		$this->addfundnotification->Visible = FALSE;
		$this->addfundnotificationemailtemplate->Visible = FALSE;
		$this->addfundnotificationsmstext->Visible = FALSE;
		$this->defaultemailaccountpin->Visible = FALSE;
		$this->sensitiveinfodatatype->Visible = FALSE;
		$this->duplicateemailallowed->Visible = FALSE;
		$this->usernamepostfix->Visible = FALSE;
		$this->allowphonecountrycode->Visible = FALSE;
		$this->rejectioncontactdetails->Visible = FALSE;
		$this->setupaccountminiapp->Visible = FALSE;
		$this->paymentrequireswalletpin->Visible = FALSE;
		$this->binno->Visible = FALSE;
		$this->reportingemail->Visible = FALSE;
		$this->suppressprogramvalue->Visible = FALSE;
		$this->withdrawalmerchantgp->Visible = FALSE;
		$this->removefundnotificationemailtemplate->Visible = FALSE;
		$this->removefundnotificationsmstext->Visible = FALSE;
		$this->merchanturl->Visible = FALSE;
		$this->autoapprovejobads->setVisibility();
		$this->hideFieldsForAddEdit();

		// Do not use lookup cache
		$this->setUseLookupCache(FALSE);

		// Global Page Loading event (in userfn*.php)
		Page_Loading();

		// Page Load event
		$this->Page_Load();

		// Check token
		if (!$this->validPost()) {
			Write($Language->phrase("InvalidPostRequest"));
			$this->terminate();
		}

		// Create Token
		$this->createToken();

		// Set up lookup cache
		$this->setupLookupOptions($this->claimcodetype);
		$this->setupLookupOptions($this->programpiid);
		$this->setupLookupOptions($this->merchantcanoverridesettlement);
		$this->setupLookupOptions($this->costabsorbedbymerchant);
		$this->setupLookupOptions($this->sendverificationsms);
		$this->setupLookupOptions($this->addfundnotification);
		$this->setupLookupOptions($this->duplicateemailallowed);
		$this->setupLookupOptions($this->allowphonecountrycode);
		$this->setupLookupOptions($this->paymentrequireswalletpin);
		$this->setupLookupOptions($this->suppressprogramvalue);
		$this->setupLookupOptions($this->withdrawalmerchantgp);

		// Check permission
		if (!$Security->canDelete()) {
			$this->setFailureMessage(DeniedMessage()); // No permission
			$this->terminate("cardprogramslist.php");
			return;
		}

		// Set up Breadcrumb
		$this->setupBreadcrumb();

		// Load key parameters
		$this->RecKeys = $this->getRecordKeys(); // Load record keys
		$filter = $this->getFilterFromRecordKeys();
		if ($filter == "") {
			$this->terminate("cardprogramslist.php"); // Prevent SQL injection, return to list
			return;
		}

		// Set up filter (WHERE Clause)
		$this->CurrentFilter = $filter;

		// Get action
		if (IsApi()) {
			$this->CurrentAction = "delete"; // Delete record directly
		} elseif (Post("action") !== NULL) {
			$this->CurrentAction = Post("action");
		} elseif (Get("action") == "1") {
			$this->CurrentAction = "delete"; // Delete record directly
		} else {
			$this->CurrentAction = "show"; // Display record
		}
		if ($this->isDelete()) {
			$this->SendEmail = TRUE; // Send email on delete success
			if ($this->deleteRows()) { // Delete rows
				if ($this->getSuccessMessage() == "")
					$this->setSuccessMessage($Language->phrase("DeleteSuccess")); // Set up success message
				if (IsApi()) {
					$this->terminate(TRUE);
					return;
				} else {
					$this->terminate($this->getReturnUrl()); // Return to caller
				}
			} else { // Delete failed
				if (IsApi()) {
					$this->terminate();
					return;
				}
				$this->CurrentAction = "show"; // Display record
			}
		}
		if ($this->isShow()) { // Load records for display
			if ($this->Recordset = $this->loadRecordset())
				$this->TotalRecords = $this->Recordset->RecordCount(); // Get record count
			if ($this->TotalRecords <= 0) { // No record found, exit
				if ($this->Recordset)
					$this->Recordset->close();
				$this->terminate("cardprogramslist.php"); // Return to list
			}
		}
	}

	// Load recordset
	public function loadRecordset($offset = -1, $rowcnt = -1)
	{

		// Load List page SQL
		$sql = $this->getListSql();
		$conn = $this->getConnection();

		// Load recordset
		$dbtype = GetConnectionType($this->Dbid);
		if ($this->UseSelectLimit) {
			$conn->raiseErrorFn = Config("ERROR_FUNC");
			if ($dbtype == "MSSQL") {
				$rs = $conn->selectLimit($sql, $rowcnt, $offset, ["_hasOrderBy" => trim($this->getOrderBy()) || trim($this->getSessionOrderBy())]);
			} else {
				$rs = $conn->selectLimit($sql, $rowcnt, $offset);
			}
			$conn->raiseErrorFn = "";
		} else {
			$rs = LoadRecordset($sql, $conn);
		}

		// Call Recordset Selected event
		$this->Recordset_Selected($rs);
		return $rs;
	}

	// Load row based on key values
	public function loadRow()
	{
		global $Security, $Language;
		$filter = $this->getRecordFilter();

		// Call Row Selecting event
		$this->Row_Selecting($filter);

		// Load SQL based on filter
		$this->CurrentFilter = $filter;
		$sql = $this->getCurrentSql();
		$conn = $this->getConnection();
		$res = FALSE;
		$rs = LoadRecordset($sql, $conn);
		if ($rs && !$rs->EOF) {
			$res = TRUE;
			$this->loadRowValues($rs); // Load row values
			$rs->close();
		}
		return $res;
	}

	// Load row values from recordset
	public function loadRowValues($rs = NULL)
	{
		if ($rs && !$rs->EOF)
			$row = $rs->fields;
		else
			$row = $this->newRow();

		// Call Row Selected event
		$this->Row_Selected($row);
		if (!$rs || $rs->EOF)
			return;
		$this->programid->setDbValue($row['programid']);
		$this->programname->setDbValue($row['programname']);
		$this->merchantid->setDbValue($row['merchantid']);
		$this->purchasefeetabletype->setDbValue($row['purchasefeetabletype']);
		$this->purchasefeetableid->setDbValue($row['purchasefeetableid']);
		$this->programfeeaccount->setDbValue($row['programfeeaccount']);
		$this->defaultcurrencycode->setDbValue($row['defaultcurrencycode']);
		$this->purchasetargetpiid->setDbValue($row['purchasetargetpiid']);
		$this->status->setDbValue($row['status']);
		$this->programaccountno->setDbValue($row['programaccountno']);
		$this->paycontrolaccountno->setDbValue($row['paycontrolaccountno']);
		$this->claimcodetype->setDbValue($row['claimcodetype']);
		$this->programpiid->setDbValue($row['programpiid']);
		$this->settlementoption->setDbValue($row['settlementoption']);
		$this->settlementdayno->setDbValue($row['settlementdayno']);
		$this->merchantcanoverridesettlement->setDbValue($row['merchantcanoverridesettlement']);
		$this->settlementminimumcost->setDbValue($row['settlementminimumcost']);
		$this->settlementdefinedcost->setDbValue($row['settlementdefinedcost']);
		$this->costabsorbedbymerchant->setDbValue($row['costabsorbedbymerchant']);
		$this->notificationemailaddresses->setDbValue($row['notificationemailaddresses']);
		$this->gatewayid->setDbValue($row['gatewayid']);
		$this->gatewayprofileid->setDbValue($row['gatewayprofileid']);
		$this->newaccountemailtemplate->setDbValue($row['newaccountemailtemplate']);
		$this->newaccountsmstext->setDbValue($row['newaccountsmstext']);
		$this->defaultstatusofnewcards->setDbValue($row['defaultstatusofnewcards']);
		$this->merchantsettlementtype->setDbValue($row['merchantsettlementtype']);
		$this->setupminiapp->setDbValue($row['setupminiapp']);
		$this->sendverificationsms->setDbValue($row['sendverificationsms']);
		$this->profile_status->setDbValue($row['profile_status']);
		$this->other1->setDbValue($row['other1']);
		$this->default_pin->setDbValue($row['default_pin']);
		$this->franchisee_id->setDbValue($row['franchisee_id']);
		$this->defaultverificationemail->setDbValue($row['defaultverificationemail']);
		$this->usertype->setDbValue($row['usertype']);
		$this->usersubtype->setDbValue($row['usersubtype']);
		$this->addfundnotification->setDbValue($row['addfundnotification']);
		$this->addfundnotificationemailtemplate->setDbValue($row['addfundnotificationemailtemplate']);
		$this->addfundnotificationsmstext->setDbValue($row['addfundnotificationsmstext']);
		$this->defaultemailaccountpin->setDbValue($row['defaultemailaccountpin']);
		$this->sensitiveinfodatatype->setDbValue($row['sensitiveinfodatatype']);
		$this->duplicateemailallowed->setDbValue($row['duplicateemailallowed']);
		$this->usernamepostfix->setDbValue($row['usernamepostfix']);
		$this->allowphonecountrycode->setDbValue($row['allowphonecountrycode']);
		$this->rejectioncontactdetails->setDbValue($row['rejectioncontactdetails']);
		$this->setupaccountminiapp->setDbValue($row['setupaccountminiapp']);
		$this->paymentrequireswalletpin->setDbValue($row['paymentrequireswalletpin']);
		$this->binno->setDbValue($row['binno']);
		$this->reportingemail->setDbValue($row['reportingemail']);
		$this->suppressprogramvalue->setDbValue($row['suppressprogramvalue']);
		$this->withdrawalmerchantgp->setDbValue($row['withdrawalmerchantgp']);
		$this->removefundnotificationemailtemplate->setDbValue($row['removefundnotificationemailtemplate']);
		$this->removefundnotificationsmstext->setDbValue($row['removefundnotificationsmstext']);
		$this->merchanturl->setDbValue($row['merchanturl']);
		$this->autoapprovejobads->setDbValue($row['autoapprovejobads']);
	}

	// Return a row with default values
	protected function newRow()
	{
		$row = [];
		$row['programid'] = NULL;
		$row['programname'] = NULL;
		$row['merchantid'] = NULL;
		$row['purchasefeetabletype'] = NULL;
		$row['purchasefeetableid'] = NULL;
		$row['programfeeaccount'] = NULL;
		$row['defaultcurrencycode'] = NULL;
		$row['purchasetargetpiid'] = NULL;
		$row['status'] = NULL;
		$row['programaccountno'] = NULL;
		$row['paycontrolaccountno'] = NULL;
		$row['claimcodetype'] = NULL;
		$row['programpiid'] = NULL;
		$row['settlementoption'] = NULL;
		$row['settlementdayno'] = NULL;
		$row['merchantcanoverridesettlement'] = NULL;
		$row['settlementminimumcost'] = NULL;
		$row['settlementdefinedcost'] = NULL;
		$row['costabsorbedbymerchant'] = NULL;
		$row['notificationemailaddresses'] = NULL;
		$row['gatewayid'] = NULL;
		$row['gatewayprofileid'] = NULL;
		$row['newaccountemailtemplate'] = NULL;
		$row['newaccountsmstext'] = NULL;
		$row['defaultstatusofnewcards'] = NULL;
		$row['merchantsettlementtype'] = NULL;
		$row['setupminiapp'] = NULL;
		$row['sendverificationsms'] = NULL;
		$row['profile_status'] = NULL;
		$row['other1'] = NULL;
		$row['default_pin'] = NULL;
		$row['franchisee_id'] = NULL;
		$row['defaultverificationemail'] = NULL;
		$row['usertype'] = NULL;
		$row['usersubtype'] = NULL;
		$row['addfundnotification'] = NULL;
		$row['addfundnotificationemailtemplate'] = NULL;
		$row['addfundnotificationsmstext'] = NULL;
		$row['defaultemailaccountpin'] = NULL;
		$row['sensitiveinfodatatype'] = NULL;
		$row['duplicateemailallowed'] = NULL;
		$row['usernamepostfix'] = NULL;
		$row['allowphonecountrycode'] = NULL;
		$row['rejectioncontactdetails'] = NULL;
		$row['setupaccountminiapp'] = NULL;
		$row['paymentrequireswalletpin'] = NULL;
		$row['binno'] = NULL;
		$row['reportingemail'] = NULL;
		$row['suppressprogramvalue'] = NULL;
		$row['withdrawalmerchantgp'] = NULL;
		$row['removefundnotificationemailtemplate'] = NULL;
		$row['removefundnotificationsmstext'] = NULL;
		$row['merchanturl'] = NULL;
		$row['autoapprovejobads'] = NULL;
		return $row;
	}

	// Render row values based on field settings
	public function renderRow()
	{
		global $Security, $Language, $CurrentLanguage;

		// Initialize URLs
		// Call Row_Rendering event

		$this->Row_Rendering();

		// Common render codes for all row types
		// programid
		// programname
		// merchantid
		// purchasefeetabletype
		// purchasefeetableid
		// programfeeaccount
		// defaultcurrencycode
		// purchasetargetpiid
		// status
		// programaccountno
		// paycontrolaccountno
		// claimcodetype
		// programpiid
		// settlementoption
		// settlementdayno
		// merchantcanoverridesettlement
		// settlementminimumcost
		// settlementdefinedcost
		// costabsorbedbymerchant
		// notificationemailaddresses
		// gatewayid
		// gatewayprofileid
		// newaccountemailtemplate
		// newaccountsmstext
		// defaultstatusofnewcards
		// merchantsettlementtype
		// setupminiapp
		// sendverificationsms
		// profile_status
		// other1
		// default_pin
		// franchisee_id
		// defaultverificationemail
		// usertype
		// usersubtype
		// addfundnotification
		// addfundnotificationemailtemplate
		// addfundnotificationsmstext
		// defaultemailaccountpin
		// sensitiveinfodatatype
		// duplicateemailallowed
		// usernamepostfix
		// allowphonecountrycode
		// rejectioncontactdetails
		// setupaccountminiapp
		// paymentrequireswalletpin
		// binno
		// reportingemail
		// suppressprogramvalue
		// withdrawalmerchantgp
		// removefundnotificationemailtemplate
		// removefundnotificationsmstext
		// merchanturl
		// autoapprovejobads

		if ($this->RowType == ROWTYPE_VIEW) { // View row

			// programid
			$this->programid->ViewValue = $this->programid->CurrentValue;
			$this->programid->ViewValue = FormatNumber($this->programid->ViewValue, 0, -2, -2, -2);
			$this->programid->ViewCustomAttributes = "";

			// programname
			$this->programname->ViewValue = $this->programname->CurrentValue;
			$this->programname->ViewCustomAttributes = "";

			// merchantid
			$this->merchantid->ViewValue = $this->merchantid->CurrentValue;
			$this->merchantid->ViewCustomAttributes = "";

			// purchasefeetabletype
			$this->purchasefeetabletype->ViewValue = $this->purchasefeetabletype->CurrentValue;
			$this->purchasefeetabletype->ViewCustomAttributes = "";

			// purchasefeetableid
			$this->purchasefeetableid->ViewValue = $this->purchasefeetableid->CurrentValue;
			$this->purchasefeetableid->ViewCustomAttributes = "";

			// programfeeaccount
			$this->programfeeaccount->ViewValue = $this->programfeeaccount->CurrentValue;
			$this->programfeeaccount->ViewCustomAttributes = "";

			// defaultcurrencycode
			$this->defaultcurrencycode->ViewValue = $this->defaultcurrencycode->CurrentValue;
			$this->defaultcurrencycode->ViewCustomAttributes = "";

			// purchasetargetpiid
			$this->purchasetargetpiid->ViewValue = $this->purchasetargetpiid->CurrentValue;
			$this->purchasetargetpiid->ViewCustomAttributes = "";

			// status
			if (strval($this->status->CurrentValue) != "") {
				$this->status->ViewValue = $this->status->optionCaption($this->status->CurrentValue);
			} else {
				$this->status->ViewValue = NULL;
			}
			$this->status->ViewCustomAttributes = "";

			// programaccountno
			$this->programaccountno->ViewValue = $this->programaccountno->CurrentValue;
			$this->programaccountno->ViewCustomAttributes = "";

			// paycontrolaccountno
			$this->paycontrolaccountno->ViewValue = $this->paycontrolaccountno->CurrentValue;
			$this->paycontrolaccountno->ViewCustomAttributes = "";

			// claimcodetype
			$curVal = strval($this->claimcodetype->CurrentValue);
			if ($curVal != "") {
				$this->claimcodetype->ViewValue = $this->claimcodetype->lookupCacheOption($curVal);
				if ($this->claimcodetype->ViewValue === NULL) { // Lookup from database
					$filterWrk = "`claimcodetype`" . SearchString("=", $curVal, DATATYPE_NUMBER, "_4payreference");
					$sqlWrk = $this->claimcodetype->Lookup->getSql(FALSE, $filterWrk, '', $this);
					$rswrk = Conn("_4payreference")->execute($sqlWrk);
					if ($rswrk && !$rswrk->EOF) { // Lookup values found
						$arwrk = [];
						$arwrk[1] = $rswrk->fields('df');
						$this->claimcodetype->ViewValue = $this->claimcodetype->displayValue($arwrk);
						$rswrk->Close();
					} else {
						$this->claimcodetype->ViewValue = $this->claimcodetype->CurrentValue;
					}
				}
			} else {
				$this->claimcodetype->ViewValue = NULL;
			}
			$this->claimcodetype->ViewCustomAttributes = "";

			// programpiid
			$curVal = strval($this->programpiid->CurrentValue);
			if ($curVal != "") {
				$this->programpiid->ViewValue = $this->programpiid->lookupCacheOption($curVal);
				if ($this->programpiid->ViewValue === NULL) { // Lookup from database
					$filterWrk = "`id`" . SearchString("=", $curVal, DATATYPE_NUMBER, "_4payreference");
					$sqlWrk = $this->programpiid->Lookup->getSql(FALSE, $filterWrk, '', $this);
					$rswrk = Conn("_4payreference")->execute($sqlWrk);
					if ($rswrk && !$rswrk->EOF) { // Lookup values found
						$arwrk = [];
						$arwrk[1] = $rswrk->fields('df');
						$this->programpiid->ViewValue = $this->programpiid->displayValue($arwrk);
						$rswrk->Close();
					} else {
						$this->programpiid->ViewValue = $this->programpiid->CurrentValue;
					}
				}
			} else {
				$this->programpiid->ViewValue = NULL;
			}
			$this->programpiid->ViewCustomAttributes = "";

			// settlementoption
			if (strval($this->settlementoption->CurrentValue) != "") {
				$this->settlementoption->ViewValue = $this->settlementoption->optionCaption($this->settlementoption->CurrentValue);
			} else {
				$this->settlementoption->ViewValue = NULL;
			}
			$this->settlementoption->ViewCustomAttributes = "";

			// settlementdayno
			$this->settlementdayno->ViewValue = $this->settlementdayno->CurrentValue;
			$this->settlementdayno->ViewCustomAttributes = "";

			// merchantcanoverridesettlement
			$curVal = strval($this->merchantcanoverridesettlement->CurrentValue);
			if ($curVal != "") {
				$this->merchantcanoverridesettlement->ViewValue = $this->merchantcanoverridesettlement->lookupCacheOption($curVal);
				if ($this->merchantcanoverridesettlement->ViewValue === NULL) { // Lookup from database
					$filterWrk = "`id`" . SearchString("=", $curVal, DATATYPE_NUMBER, "");
					$sqlWrk = $this->merchantcanoverridesettlement->Lookup->getSql(FALSE, $filterWrk, '', $this);
					$rswrk = Conn()->execute($sqlWrk);
					if ($rswrk && !$rswrk->EOF) { // Lookup values found
						$arwrk = [];
						$arwrk[1] = $rswrk->fields('df');
						$this->merchantcanoverridesettlement->ViewValue = $this->merchantcanoverridesettlement->displayValue($arwrk);
						$rswrk->Close();
					} else {
						$this->merchantcanoverridesettlement->ViewValue = $this->merchantcanoverridesettlement->CurrentValue;
					}
				}
			} else {
				$this->merchantcanoverridesettlement->ViewValue = NULL;
			}
			$this->merchantcanoverridesettlement->ViewCustomAttributes = "";

			// settlementminimumcost
			$this->settlementminimumcost->ViewValue = $this->settlementminimumcost->CurrentValue;
			$this->settlementminimumcost->ViewValue = FormatNumber($this->settlementminimumcost->ViewValue, Config("DEFAULT_DECIMAL_PRECISION"));
			$this->settlementminimumcost->ViewCustomAttributes = "";

			// settlementdefinedcost
			$this->settlementdefinedcost->ViewValue = $this->settlementdefinedcost->CurrentValue;
			$this->settlementdefinedcost->ViewValue = FormatNumber($this->settlementdefinedcost->ViewValue, Config("DEFAULT_DECIMAL_PRECISION"));
			$this->settlementdefinedcost->ViewCustomAttributes = "";

			// costabsorbedbymerchant
			$curVal = strval($this->costabsorbedbymerchant->CurrentValue);
			if ($curVal != "") {
				$this->costabsorbedbymerchant->ViewValue = $this->costabsorbedbymerchant->lookupCacheOption($curVal);
				if ($this->costabsorbedbymerchant->ViewValue === NULL) { // Lookup from database
					$filterWrk = "`id`" . SearchString("=", $curVal, DATATYPE_NUMBER, "");
					$sqlWrk = $this->costabsorbedbymerchant->Lookup->getSql(FALSE, $filterWrk, '', $this);
					$rswrk = Conn()->execute($sqlWrk);
					if ($rswrk && !$rswrk->EOF) { // Lookup values found
						$arwrk = [];
						$arwrk[1] = $rswrk->fields('df');
						$this->costabsorbedbymerchant->ViewValue = $this->costabsorbedbymerchant->displayValue($arwrk);
						$rswrk->Close();
					} else {
						$this->costabsorbedbymerchant->ViewValue = $this->costabsorbedbymerchant->CurrentValue;
					}
				}
			} else {
				$this->costabsorbedbymerchant->ViewValue = NULL;
			}
			$this->costabsorbedbymerchant->ViewCustomAttributes = "";

			// notificationemailaddresses
			$this->notificationemailaddresses->ViewValue = $this->notificationemailaddresses->CurrentValue;
			$this->notificationemailaddresses->ViewCustomAttributes = "";

			// gatewayid
			$this->gatewayid->ViewValue = $this->gatewayid->CurrentValue;
			$this->gatewayid->ViewCustomAttributes = "";

			// gatewayprofileid
			$this->gatewayprofileid->ViewValue = $this->gatewayprofileid->CurrentValue;
			$this->gatewayprofileid->ViewCustomAttributes = "";

			// newaccountemailtemplate
			$this->newaccountemailtemplate->ViewValue = $this->newaccountemailtemplate->CurrentValue;
			$this->newaccountemailtemplate->ViewCustomAttributes = "";

			// newaccountsmstext
			$this->newaccountsmstext->ViewValue = $this->newaccountsmstext->CurrentValue;
			$this->newaccountsmstext->ViewCustomAttributes = "";

			// defaultstatusofnewcards
			$this->defaultstatusofnewcards->ViewValue = $this->defaultstatusofnewcards->CurrentValue;
			$this->defaultstatusofnewcards->ViewValue = FormatNumber($this->defaultstatusofnewcards->ViewValue, 0, -2, -2, -2);
			$this->defaultstatusofnewcards->ViewCustomAttributes = "";

			// merchantsettlementtype
			$this->merchantsettlementtype->ViewValue = $this->merchantsettlementtype->CurrentValue;
			$this->merchantsettlementtype->ViewValue = FormatNumber($this->merchantsettlementtype->ViewValue, 0, -2, -2, -2);
			$this->merchantsettlementtype->ViewCustomAttributes = "";

			// setupminiapp
			$this->setupminiapp->ViewValue = $this->setupminiapp->CurrentValue;
			$this->setupminiapp->ViewCustomAttributes = "";

			// sendverificationsms
			$curVal = strval($this->sendverificationsms->CurrentValue);
			if ($curVal != "") {
				$this->sendverificationsms->ViewValue = $this->sendverificationsms->lookupCacheOption($curVal);
				if ($this->sendverificationsms->ViewValue === NULL) { // Lookup from database
					$filterWrk = "`id`" . SearchString("=", $curVal, DATATYPE_NUMBER, "");
					$sqlWrk = $this->sendverificationsms->Lookup->getSql(FALSE, $filterWrk, '', $this);
					$rswrk = Conn()->execute($sqlWrk);
					if ($rswrk && !$rswrk->EOF) { // Lookup values found
						$arwrk = [];
						$arwrk[1] = $rswrk->fields('df');
						$this->sendverificationsms->ViewValue = $this->sendverificationsms->displayValue($arwrk);
						$rswrk->Close();
					} else {
						$this->sendverificationsms->ViewValue = $this->sendverificationsms->CurrentValue;
					}
				}
			} else {
				$this->sendverificationsms->ViewValue = NULL;
			}
			$this->sendverificationsms->ViewCustomAttributes = "";

			// profile_status
			$this->profile_status->ViewValue = $this->profile_status->CurrentValue;
			$this->profile_status->ViewValue = FormatNumber($this->profile_status->ViewValue, 0, -2, -2, -2);
			$this->profile_status->ViewCustomAttributes = "";

			// other1
			$this->other1->ViewValue = $this->other1->CurrentValue;
			$this->other1->ViewCustomAttributes = "";

			// default_pin
			$this->default_pin->ViewValue = $this->default_pin->CurrentValue;
			$this->default_pin->ViewCustomAttributes = "";

			// franchisee_id
			$this->franchisee_id->ViewValue = $this->franchisee_id->CurrentValue;
			$this->franchisee_id->ViewValue = FormatNumber($this->franchisee_id->ViewValue, 0, -2, -2, -2);
			$this->franchisee_id->ViewCustomAttributes = "";

			// defaultverificationemail
			$this->defaultverificationemail->ViewValue = $this->defaultverificationemail->CurrentValue;
			$this->defaultverificationemail->ViewValue = FormatNumber($this->defaultverificationemail->ViewValue, 0, -2, -2, -2);
			$this->defaultverificationemail->ViewCustomAttributes = "";

			// usertype
			$this->usertype->ViewValue = $this->usertype->CurrentValue;
			$this->usertype->ViewValue = FormatNumber($this->usertype->ViewValue, 0, -2, -2, -2);
			$this->usertype->ViewCustomAttributes = "";

			// usersubtype
			$this->usersubtype->ViewValue = $this->usersubtype->CurrentValue;
			$this->usersubtype->ViewValue = FormatNumber($this->usersubtype->ViewValue, 0, -2, -2, -2);
			$this->usersubtype->ViewCustomAttributes = "";

			// addfundnotification
			$curVal = strval($this->addfundnotification->CurrentValue);
			if ($curVal != "") {
				$this->addfundnotification->ViewValue = $this->addfundnotification->lookupCacheOption($curVal);
				if ($this->addfundnotification->ViewValue === NULL) { // Lookup from database
					$filterWrk = "`id`" . SearchString("=", $curVal, DATATYPE_NUMBER, "");
					$sqlWrk = $this->addfundnotification->Lookup->getSql(FALSE, $filterWrk, '', $this);
					$rswrk = Conn()->execute($sqlWrk);
					if ($rswrk && !$rswrk->EOF) { // Lookup values found
						$arwrk = [];
						$arwrk[1] = $rswrk->fields('df');
						$this->addfundnotification->ViewValue = $this->addfundnotification->displayValue($arwrk);
						$rswrk->Close();
					} else {
						$this->addfundnotification->ViewValue = $this->addfundnotification->CurrentValue;
					}
				}
			} else {
				$this->addfundnotification->ViewValue = NULL;
			}
			$this->addfundnotification->ViewCustomAttributes = "";

			// addfundnotificationemailtemplate
			$this->addfundnotificationemailtemplate->ViewValue = $this->addfundnotificationemailtemplate->CurrentValue;
			$this->addfundnotificationemailtemplate->ViewCustomAttributes = "";

			// addfundnotificationsmstext
			$this->addfundnotificationsmstext->ViewValue = $this->addfundnotificationsmstext->CurrentValue;
			$this->addfundnotificationsmstext->ViewCustomAttributes = "";

			// defaultemailaccountpin
			$this->defaultemailaccountpin->ViewValue = $this->defaultemailaccountpin->CurrentValue;
			$this->defaultemailaccountpin->ViewCustomAttributes = "";

			// sensitiveinfodatatype
			$this->sensitiveinfodatatype->ViewValue = $this->sensitiveinfodatatype->CurrentValue;
			$this->sensitiveinfodatatype->ViewValue = FormatNumber($this->sensitiveinfodatatype->ViewValue, 0, -2, -2, -2);
			$this->sensitiveinfodatatype->ViewCustomAttributes = "";

			// duplicateemailallowed
			$curVal = strval($this->duplicateemailallowed->CurrentValue);
			if ($curVal != "") {
				$this->duplicateemailallowed->ViewValue = $this->duplicateemailallowed->lookupCacheOption($curVal);
				if ($this->duplicateemailallowed->ViewValue === NULL) { // Lookup from database
					$filterWrk = "`id`" . SearchString("=", $curVal, DATATYPE_NUMBER, "");
					$sqlWrk = $this->duplicateemailallowed->Lookup->getSql(FALSE, $filterWrk, '', $this);
					$rswrk = Conn()->execute($sqlWrk);
					if ($rswrk && !$rswrk->EOF) { // Lookup values found
						$arwrk = [];
						$arwrk[1] = $rswrk->fields('df');
						$this->duplicateemailallowed->ViewValue = $this->duplicateemailallowed->displayValue($arwrk);
						$rswrk->Close();
					} else {
						$this->duplicateemailallowed->ViewValue = $this->duplicateemailallowed->CurrentValue;
					}
				}
			} else {
				$this->duplicateemailallowed->ViewValue = NULL;
			}
			$this->duplicateemailallowed->ViewCustomAttributes = "";

			// usernamepostfix
			$this->usernamepostfix->ViewValue = $this->usernamepostfix->CurrentValue;
			$this->usernamepostfix->ViewCustomAttributes = "";

			// allowphonecountrycode
			$curVal = strval($this->allowphonecountrycode->CurrentValue);
			if ($curVal != "") {
				$this->allowphonecountrycode->ViewValue = $this->allowphonecountrycode->lookupCacheOption($curVal);
				if ($this->allowphonecountrycode->ViewValue === NULL) { // Lookup from database
					$filterWrk = "`id`" . SearchString("=", $curVal, DATATYPE_NUMBER, "");
					$sqlWrk = $this->allowphonecountrycode->Lookup->getSql(FALSE, $filterWrk, '', $this);
					$rswrk = Conn()->execute($sqlWrk);
					if ($rswrk && !$rswrk->EOF) { // Lookup values found
						$arwrk = [];
						$arwrk[1] = $rswrk->fields('df');
						$this->allowphonecountrycode->ViewValue = $this->allowphonecountrycode->displayValue($arwrk);
						$rswrk->Close();
					} else {
						$this->allowphonecountrycode->ViewValue = $this->allowphonecountrycode->CurrentValue;
					}
				}
			} else {
				$this->allowphonecountrycode->ViewValue = NULL;
			}
			$this->allowphonecountrycode->ViewCustomAttributes = "";

			// rejectioncontactdetails
			$this->rejectioncontactdetails->ViewValue = $this->rejectioncontactdetails->CurrentValue;
			$this->rejectioncontactdetails->ViewCustomAttributes = "";

			// setupaccountminiapp
			$this->setupaccountminiapp->ViewValue = $this->setupaccountminiapp->CurrentValue;
			$this->setupaccountminiapp->ViewCustomAttributes = "";

			// paymentrequireswalletpin
			$curVal = strval($this->paymentrequireswalletpin->CurrentValue);
			if ($curVal != "") {
				$this->paymentrequireswalletpin->ViewValue = $this->paymentrequireswalletpin->lookupCacheOption($curVal);
				if ($this->paymentrequireswalletpin->ViewValue === NULL) { // Lookup from database
					$filterWrk = "`id`" . SearchString("=", $curVal, DATATYPE_NUMBER, "");
					$sqlWrk = $this->paymentrequireswalletpin->Lookup->getSql(FALSE, $filterWrk, '', $this);
					$rswrk = Conn()->execute($sqlWrk);
					if ($rswrk && !$rswrk->EOF) { // Lookup values found
						$arwrk = [];
						$arwrk[1] = $rswrk->fields('df');
						$this->paymentrequireswalletpin->ViewValue = $this->paymentrequireswalletpin->displayValue($arwrk);
						$rswrk->Close();
					} else {
						$this->paymentrequireswalletpin->ViewValue = $this->paymentrequireswalletpin->CurrentValue;
					}
				}
			} else {
				$this->paymentrequireswalletpin->ViewValue = NULL;
			}
			$this->paymentrequireswalletpin->ViewCustomAttributes = "";

			// binno
			$this->binno->ViewValue = $this->binno->CurrentValue;
			$this->binno->ViewCustomAttributes = "";

			// reportingemail
			$this->reportingemail->ViewValue = $this->reportingemail->CurrentValue;
			$this->reportingemail->ViewCustomAttributes = "";

			// suppressprogramvalue
			$this->suppressprogramvalue->ViewValue = $this->suppressprogramvalue->CurrentValue;
			$curVal = strval($this->suppressprogramvalue->CurrentValue);
			if ($curVal != "") {
				$this->suppressprogramvalue->ViewValue = $this->suppressprogramvalue->lookupCacheOption($curVal);
				if ($this->suppressprogramvalue->ViewValue === NULL) { // Lookup from database
					$filterWrk = "`statusID`" . SearchString("=", $curVal, DATATYPE_NUMBER, "");
					$lookupFilter = function() {
						return "`langID` = 'EN'";
					};
					$lookupFilter = $lookupFilter->bindTo($this);
					$sqlWrk = $this->suppressprogramvalue->Lookup->getSql(FALSE, $filterWrk, $lookupFilter, $this);
					$rswrk = Conn()->execute($sqlWrk);
					if ($rswrk && !$rswrk->EOF) { // Lookup values found
						$arwrk = [];
						$arwrk[1] = $rswrk->fields('df');
						$this->suppressprogramvalue->ViewValue = $this->suppressprogramvalue->displayValue($arwrk);
						$rswrk->Close();
					} else {
						$this->suppressprogramvalue->ViewValue = $this->suppressprogramvalue->CurrentValue;
					}
				}
			} else {
				$this->suppressprogramvalue->ViewValue = NULL;
			}
			$this->suppressprogramvalue->ViewCustomAttributes = "";

			// withdrawalmerchantgp
			$this->withdrawalmerchantgp->ViewValue = $this->withdrawalmerchantgp->CurrentValue;
			$curVal = strval($this->withdrawalmerchantgp->CurrentValue);
			if ($curVal != "") {
				$this->withdrawalmerchantgp->ViewValue = $this->withdrawalmerchantgp->lookupCacheOption($curVal);
				if ($this->withdrawalmerchantgp->ViewValue === NULL) { // Lookup from database
					$filterWrk = "`id`" . SearchString("=", $curVal, DATATYPE_NUMBER, "");
					$sqlWrk = $this->withdrawalmerchantgp->Lookup->getSql(FALSE, $filterWrk, '', $this);
					$rswrk = Conn()->execute($sqlWrk);
					if ($rswrk && !$rswrk->EOF) { // Lookup values found
						$arwrk = [];
						$arwrk[1] = $rswrk->fields('df');
						$this->withdrawalmerchantgp->ViewValue = $this->withdrawalmerchantgp->displayValue($arwrk);
						$rswrk->Close();
					} else {
						$this->withdrawalmerchantgp->ViewValue = $this->withdrawalmerchantgp->CurrentValue;
					}
				}
			} else {
				$this->withdrawalmerchantgp->ViewValue = NULL;
			}
			$this->withdrawalmerchantgp->ViewCustomAttributes = "";

			// removefundnotificationemailtemplate
			$this->removefundnotificationemailtemplate->ViewValue = $this->removefundnotificationemailtemplate->CurrentValue;
			$this->removefundnotificationemailtemplate->ViewCustomAttributes = "";

			// removefundnotificationsmstext
			$this->removefundnotificationsmstext->ViewValue = $this->removefundnotificationsmstext->CurrentValue;
			$this->removefundnotificationsmstext->ViewCustomAttributes = "";

			// merchanturl
			$this->merchanturl->ViewValue = $this->merchanturl->CurrentValue;
			$this->merchanturl->ViewCustomAttributes = "";

			// autoapprovejobads
			$this->autoapprovejobads->ViewValue = $this->autoapprovejobads->CurrentValue;
			$this->autoapprovejobads->ViewValue = FormatNumber($this->autoapprovejobads->ViewValue, 0, -2, -2, -2);
			$this->autoapprovejobads->ViewCustomAttributes = "";

			// programid
			$this->programid->LinkCustomAttributes = "";
			$this->programid->HrefValue = "";
			$this->programid->TooltipValue = "";

			// programname
			$this->programname->LinkCustomAttributes = "";
			$this->programname->HrefValue = "";
			$this->programname->TooltipValue = "";

			// merchantid
			$this->merchantid->LinkCustomAttributes = "";
			$this->merchantid->HrefValue = "";
			$this->merchantid->TooltipValue = "";

			// purchasefeetabletype
			$this->purchasefeetabletype->LinkCustomAttributes = "";
			$this->purchasefeetabletype->HrefValue = "";
			$this->purchasefeetabletype->TooltipValue = "";

			// purchasefeetableid
			$this->purchasefeetableid->LinkCustomAttributes = "";
			$this->purchasefeetableid->HrefValue = "";
			$this->purchasefeetableid->TooltipValue = "";

			// programfeeaccount
			$this->programfeeaccount->LinkCustomAttributes = "";
			$this->programfeeaccount->HrefValue = "";
			$this->programfeeaccount->TooltipValue = "";

			// defaultcurrencycode
			$this->defaultcurrencycode->LinkCustomAttributes = "";
			$this->defaultcurrencycode->HrefValue = "";
			$this->defaultcurrencycode->TooltipValue = "";

			// autoapprovejobads
			$this->autoapprovejobads->LinkCustomAttributes = "";
			$this->autoapprovejobads->HrefValue = "";
			$this->autoapprovejobads->TooltipValue = "";
		}

		// Call Row Rendered event
		if ($this->RowType != ROWTYPE_AGGREGATEINIT)
			$this->Row_Rendered();
	}

	// Delete records based on current filter
	protected function deleteRows()
	{
		global $Language, $Security;
		if (!$Security->canDelete()) {
			$this->setFailureMessage($Language->phrase("NoDeletePermission")); // No delete permission
			return FALSE;
		}
		$deleteRows = TRUE;
		$sql = $this->getCurrentSql();
		$conn = $this->getConnection();
		$conn->raiseErrorFn = Config("ERROR_FUNC");
		$rs = $conn->execute($sql);
		$conn->raiseErrorFn = "";
		if ($rs === FALSE) {
			return FALSE;
		} elseif ($rs->EOF) {
			$this->setFailureMessage($Language->phrase("NoRecord")); // No record found
			$rs->close();
			return FALSE;
		}
		$rows = ($rs) ? $rs->getRows() : [];
		$conn->beginTrans();

		// Clone old rows
		$rsold = $rows;
		if ($rs)
			$rs->close();

		// Call row deleting event
		if ($deleteRows) {
			foreach ($rsold as $row) {
				$deleteRows = $this->Row_Deleting($row);
				if (!$deleteRows)
					break;
			}
		}
		if ($deleteRows) {
			$key = "";
			foreach ($rsold as $row) {
				$thisKey = "";
				if ($thisKey != "")
					$thisKey .= Config("COMPOSITE_KEY_SEPARATOR");
				$thisKey .= $row['programid'];
				if (Config("DELETE_UPLOADED_FILES")) // Delete old files
					$this->deleteUploadedFiles($row);
				$conn->raiseErrorFn = Config("ERROR_FUNC");
				$deleteRows = $this->delete($row); // Delete
				$conn->raiseErrorFn = "";
				if ($deleteRows === FALSE)
					break;
				if ($key != "")
					$key .= ", ";
				$key .= $thisKey;
			}
		}
		if (!$deleteRows) {

			// Set up error message
			if ($this->getSuccessMessage() != "" || $this->getFailureMessage() != "") {

				// Use the message, do nothing
			} elseif ($this->CancelMessage != "") {
				$this->setFailureMessage($this->CancelMessage);
				$this->CancelMessage = "";
			} else {
				$this->setFailureMessage($Language->phrase("DeleteCancelled"));
			}
		}
		if ($deleteRows) {
			$conn->commitTrans(); // Commit the changes
		} else {
			$conn->rollbackTrans(); // Rollback changes
		}

		// Call Row Deleted event
		if ($deleteRows) {
			foreach ($rsold as $row) {
				$this->Row_Deleted($row);
			}
		}

		// Write JSON for API request (Support single row only)
		if (IsApi() && $deleteRows) {
			$row = $this->getRecordsFromRecordset($rsold, TRUE);
			WriteJson(["success" => TRUE, $this->TableVar => $row]);
		}
		return $deleteRows;
	}

	// Set up Breadcrumb
	protected function setupBreadcrumb()
	{
		global $Breadcrumb, $Language;
		$Breadcrumb = new Breadcrumb();
		$url = substr(CurrentUrl(), strrpos(CurrentUrl(), "/")+1);
		$Breadcrumb->add("list", $this->TableVar, $this->addMasterUrl("cardprogramslist.php"), "", $this->TableVar, TRUE);
		$pageId = "delete";
		$Breadcrumb->add("delete", $pageId, $url);
	}

	// Setup lookup options
	public function setupLookupOptions($fld)
	{
		if ($fld->Lookup !== NULL && $fld->Lookup->Options === NULL) {

			// Get default connection and filter
			$conn = $this->getConnection();
			$lookupFilter = "";

			// No need to check any more
			$fld->Lookup->Options = [];

			// Set up lookup SQL and connection
			switch ($fld->FieldVar) {
				case "x_status":
					break;
				case "x_claimcodetype":
					break;
				case "x_programpiid":
					break;
				case "x_settlementoption":
					break;
				case "x_merchantcanoverridesettlement":
					$conn = Conn("DB");
					break;
				case "x_costabsorbedbymerchant":
					$conn = Conn("DB");
					break;
				case "x_sendverificationsms":
					$conn = Conn("DB");
					break;
				case "x_addfundnotification":
					$conn = Conn("DB");
					break;
				case "x_duplicateemailallowed":
					$conn = Conn("DB");
					break;
				case "x_allowphonecountrycode":
					$conn = Conn("DB");
					break;
				case "x_paymentrequireswalletpin":
					$conn = Conn("DB");
					break;
				case "x_suppressprogramvalue":
					$conn = Conn("DB");
					$lookupFilter = function() {
						return "`langID` = 'EN'";
					};
					$lookupFilter = $lookupFilter->bindTo($this);
					break;
				case "x_withdrawalmerchantgp":
					$conn = Conn("DB");
					break;
				default:
					$lookupFilter = "";
					break;
			}

			// Always call to Lookup->getSql so that user can setup Lookup->Options in Lookup_Selecting server event
			$sql = $fld->Lookup->getSql(FALSE, "", $lookupFilter, $this);

			// Set up lookup cache
			if ($fld->UseLookupCache && $sql != "" && count($fld->Lookup->Options) == 0) {
				$totalCnt = $this->getRecordCount($sql, $conn);
				if ($totalCnt > $fld->LookupCacheCount) // Total count > cache count, do not cache
					return;
				$rs = $conn->execute($sql);
				$ar = [];
				while ($rs && !$rs->EOF) {
					$row = &$rs->fields;

					// Format the field values
					switch ($fld->FieldVar) {
						case "x_claimcodetype":
							break;
						case "x_programpiid":
							break;
						case "x_merchantcanoverridesettlement":
							break;
						case "x_costabsorbedbymerchant":
							break;
						case "x_sendverificationsms":
							break;
						case "x_addfundnotification":
							break;
						case "x_duplicateemailallowed":
							break;
						case "x_allowphonecountrycode":
							break;
						case "x_paymentrequireswalletpin":
							break;
						case "x_suppressprogramvalue":
							break;
						case "x_withdrawalmerchantgp":
							break;
					}
					$ar[strval($row[0])] = $row;
					$rs->moveNext();
				}
				if ($rs)
					$rs->close();
				$fld->Lookup->Options = $ar;
			}
		}
	}

	// Page Load event
	function Page_Load() {

		//echo "Page Load";
	}

	// Page Unload event
	function Page_Unload() {

		//echo "Page Unload";
	}

	// Page Redirecting event
	function Page_Redirecting(&$url) {

		// Example:
		//$url = "your URL";

	}

	// Message Showing event
	// $type = ''|'success'|'failure'|'warning'
	function Message_Showing(&$msg, $type) {
		if ($type == 'success') {

			//$msg = "your success message";
		} elseif ($type == 'failure') {

			//$msg = "your failure message";
		} elseif ($type == 'warning') {

			//$msg = "your warning message";
		} else {

			//$msg = "your message";
		}
	}

	// Page Render event
	function Page_Render() {

		//echo "Page Render";
	}

	// Page Data Rendering event
	function Page_DataRendering(&$header) {

		// Example:
		//$header = "your header";

	}

	// Page Data Rendered event
	function Page_DataRendered(&$footer) {

		// Example:
		//$footer = "your footer";

	}
} // End class
?>