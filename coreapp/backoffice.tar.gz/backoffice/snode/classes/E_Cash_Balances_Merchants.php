<?php namespace PHPMaker2020\_4payadmin; ?>
<?php

/**
 * Table class for E-Cash Balances Merchants
 */
class E_Cash_Balances_Merchants extends ReportTable
{
	protected $SqlFrom = "";
	protected $SqlSelect = "";
	protected $SqlSelectList = "";
	protected $SqlWhere = "";
	protected $SqlGroupBy = "";
	protected $SqlHaving = "";
	protected $SqlOrderBy = "";
	public $UseSessionForListSql = TRUE;

	// Column CSS classes
	public $LeftColumnClass = "col-sm-2 col-form-label ew-label";
	public $RightColumnClass = "col-sm-10";
	public $OffsetColumnClass = "col-sm-10 offset-sm-2";
	public $TableLeftColumnClass = "w-col-2";
	public $ShowGroupHeaderAsRow = FALSE;
	public $ShowCompactSummaryFooter = FALSE;

	// Export
	public $ExportDoc;

	// Fields
	public $_userid;
	public $businessname;
	public $firstName;
	public $lastName;
	public $rolename;
	public $currCode;
	public $availablebalance;
	public $unavailablebalance;

	// Constructor
	public function __construct()
	{
		global $Language, $CurrentLanguage;
		parent::__construct();

		// Language object
		if (!isset($Language))
			$Language = new Language();
		$this->TableVar = 'E_Cash_Balances_Merchants';
		$this->TableName = 'E-Cash Balances Merchants';
		$this->TableType = 'REPORT';

		// Update Table
		$this->UpdateTable = "`vecashbalancesperrolemerchant`";
		$this->ReportSourceTable = 'vecashbalancesperrolemerchant'; // Report source table
		$this->Dbid = 'DB';
		$this->ExportAll = TRUE;
		$this->ExportPageBreakCount = 0; // Page break per every n record (report only)
		$this->ExportPageOrientation = "portrait"; // Page orientation (PDF only)
		$this->ExportPageSize = "a4"; // Page size (PDF only)
		$this->ExportExcelPageOrientation = \PhpOffice\PhpSpreadsheet\Worksheet\PageSetup::ORIENTATION_DEFAULT; // Page orientation (PhpSpreadsheet only)
		$this->ExportExcelPageSize = \PhpOffice\PhpSpreadsheet\Worksheet\PageSetup::PAPERSIZE_A4; // Page size (PhpSpreadsheet only)
		$this->ExportWordPageOrientation = "portrait"; // Page orientation (PHPWord only)
		$this->ExportWordColumnWidth = NULL; // Cell width (PHPWord only)
		$this->UserIDAllowSecurity = Config("DEFAULT_USER_ID_ALLOW_SECURITY"); // Default User ID allowed permissions

		// userid
		$this->_userid = new ReportField('E_Cash_Balances_Merchants', 'E-Cash Balances Merchants', 'x__userid', 'userid', '`userid`', '`userid`', 3, 12, -1, FALSE, '`userid`', FALSE, FALSE, FALSE, 'FORMATTED TEXT', 'TEXT');
		$this->_userid->GroupingFieldId = 4;
		$this->_userid->ShowGroupHeaderAsRow = $this->ShowGroupHeaderAsRow;
		$this->_userid->ShowCompactSummaryFooter = $this->ShowCompactSummaryFooter;
		$this->_userid->GroupByType = "";
		$this->_userid->GroupInterval = "0";
		$this->_userid->GroupSql = "";
		$this->_userid->IsPrimaryKey = TRUE; // Primary key field
		$this->_userid->Nullable = FALSE; // NOT NULL field
		$this->_userid->Required = TRUE; // Required field
		$this->_userid->Sortable = TRUE; // Allow sort
		$this->_userid->DefaultErrorMessage = $Language->phrase("IncorrectInteger");
		$this->_userid->SourceTableVar = 'vecashbalancesperrolemerchant';
		$this->fields['userid'] = &$this->_userid;

		// businessname
		$this->businessname = new ReportField('E_Cash_Balances_Merchants', 'E-Cash Balances Merchants', 'x_businessname', 'businessname', '`businessname`', '`businessname`', 200, 60, -1, FALSE, '`businessname`', FALSE, FALSE, FALSE, 'FORMATTED TEXT', 'TEXT');
		$this->businessname->GroupingFieldId = 1;
		$this->businessname->ShowGroupHeaderAsRow = $this->ShowGroupHeaderAsRow;
		$this->businessname->ShowCompactSummaryFooter = $this->ShowCompactSummaryFooter;
		$this->businessname->GroupByType = "";
		$this->businessname->GroupInterval = "0";
		$this->businessname->GroupSql = "";
		$this->businessname->Nullable = FALSE; // NOT NULL field
		$this->businessname->Required = TRUE; // Required field
		$this->businessname->Sortable = TRUE; // Allow sort
		$this->businessname->SourceTableVar = 'vecashbalancesperrolemerchant';
		$this->fields['businessname'] = &$this->businessname;

		// firstName
		$this->firstName = new ReportField('E_Cash_Balances_Merchants', 'E-Cash Balances Merchants', 'x_firstName', 'firstName', '`firstName`', '`firstName`', 200, 60, -1, FALSE, '`firstName`', FALSE, FALSE, FALSE, 'FORMATTED TEXT', 'TEXT');
		$this->firstName->GroupingFieldId = 2;
		$this->firstName->ShowGroupHeaderAsRow = $this->ShowGroupHeaderAsRow;
		$this->firstName->ShowCompactSummaryFooter = $this->ShowCompactSummaryFooter;
		$this->firstName->GroupByType = "";
		$this->firstName->GroupInterval = "0";
		$this->firstName->GroupSql = "";
		$this->firstName->Nullable = FALSE; // NOT NULL field
		$this->firstName->Required = TRUE; // Required field
		$this->firstName->Sortable = TRUE; // Allow sort
		$this->firstName->SourceTableVar = 'vecashbalancesperrolemerchant';
		$this->fields['firstName'] = &$this->firstName;

		// lastName
		$this->lastName = new ReportField('E_Cash_Balances_Merchants', 'E-Cash Balances Merchants', 'x_lastName', 'lastName', '`lastName`', '`lastName`', 200, 60, -1, FALSE, '`lastName`', FALSE, FALSE, FALSE, 'FORMATTED TEXT', 'TEXT');
		$this->lastName->GroupingFieldId = 3;
		$this->lastName->ShowGroupHeaderAsRow = $this->ShowGroupHeaderAsRow;
		$this->lastName->ShowCompactSummaryFooter = $this->ShowCompactSummaryFooter;
		$this->lastName->GroupByType = "";
		$this->lastName->GroupInterval = "0";
		$this->lastName->GroupSql = "";
		$this->lastName->Nullable = FALSE; // NOT NULL field
		$this->lastName->Required = TRUE; // Required field
		$this->lastName->Sortable = TRUE; // Allow sort
		$this->lastName->SourceTableVar = 'vecashbalancesperrolemerchant';
		$this->fields['lastName'] = &$this->lastName;

		// rolename
		$this->rolename = new ReportField('E_Cash_Balances_Merchants', 'E-Cash Balances Merchants', 'x_rolename', 'rolename', '`rolename`', '`rolename`', 200, 30, -1, FALSE, '`rolename`', FALSE, FALSE, FALSE, 'FORMATTED TEXT', 'SELECT');
		$this->rolename->Nullable = FALSE; // NOT NULL field
		$this->rolename->Required = TRUE; // Required field
		$this->rolename->Sortable = TRUE; // Allow sort
		$this->rolename->UsePleaseSelect = TRUE; // Use PleaseSelect by default
		$this->rolename->PleaseSelectText = $Language->phrase("PleaseSelect"); // "PleaseSelect" text
		$this->rolename->Lookup = new Lookup('rolename', 'vecashbalancesperrolemerchant', TRUE, 'rolename', ["rolename","","",""], [], [], [], [], [], [], '`rolename` ASC', '');
		$this->rolename->AdvancedSearch->SearchValueDefault = INIT_VALUE;
		$this->rolename->SourceTableVar = 'vecashbalancesperrolemerchant';
		$this->fields['rolename'] = &$this->rolename;

		// currCode
		$this->currCode = new ReportField('E_Cash_Balances_Merchants', 'E-Cash Balances Merchants', 'x_currCode', 'currCode', '`currCode`', '`currCode`', 200, 3, -1, FALSE, '`currCode`', FALSE, FALSE, FALSE, 'FORMATTED TEXT', 'SELECT');
		$this->currCode->IsPrimaryKey = TRUE; // Primary key field
		$this->currCode->Nullable = FALSE; // NOT NULL field
		$this->currCode->Required = TRUE; // Required field
		$this->currCode->Sortable = TRUE; // Allow sort
		$this->currCode->UsePleaseSelect = TRUE; // Use PleaseSelect by default
		$this->currCode->PleaseSelectText = $Language->phrase("PleaseSelect"); // "PleaseSelect" text
		$this->currCode->Lookup = new Lookup('currCode', 'vecashbalancesperrolemerchant', TRUE, 'currCode', ["currCode","","",""], [], [], [], [], [], [], '`currCode` ASC', '');
		$this->currCode->AdvancedSearch->SearchValueDefault = INIT_VALUE;
		$this->currCode->SourceTableVar = 'vecashbalancesperrolemerchant';
		$this->fields['currCode'] = &$this->currCode;

		// availablebalance
		$this->availablebalance = new ReportField('E_Cash_Balances_Merchants', 'E-Cash Balances Merchants', 'x_availablebalance', 'availablebalance', '`availablebalance`', '`availablebalance`', 131, 21, -1, FALSE, '`availablebalance`', FALSE, FALSE, FALSE, 'FORMATTED TEXT', 'TEXT');
		$this->availablebalance->Nullable = FALSE; // NOT NULL field
		$this->availablebalance->Sortable = TRUE; // Allow sort
		$this->availablebalance->DefaultErrorMessage = $Language->phrase("IncorrectFloat");
		$this->availablebalance->SourceTableVar = 'vecashbalancesperrolemerchant';
		$this->fields['availablebalance'] = &$this->availablebalance;

		// unavailablebalance
		$this->unavailablebalance = new ReportField('E_Cash_Balances_Merchants', 'E-Cash Balances Merchants', 'x_unavailablebalance', 'unavailablebalance', '`unavailablebalance`', '`unavailablebalance`', 131, 21, -1, FALSE, '`unavailablebalance`', FALSE, FALSE, FALSE, 'FORMATTED TEXT', 'TEXT');
		$this->unavailablebalance->Nullable = FALSE; // NOT NULL field
		$this->unavailablebalance->Sortable = TRUE; // Allow sort
		$this->unavailablebalance->DefaultErrorMessage = $Language->phrase("IncorrectFloat");
		$this->unavailablebalance->SourceTableVar = 'vecashbalancesperrolemerchant';
		$this->fields['unavailablebalance'] = &$this->unavailablebalance;
	}

	// Field Visibility
	public function getFieldVisibility($fldParm)
	{
		global $Security;
		return $this->$fldParm->Visible; // Returns original value
	}

	// Single column sort
	protected function updateSort(&$fld)
	{
		if ($this->CurrentOrder == $fld->Name) {
			$sortField = $fld->Expression;
			$lastSort = $fld->getSort();
			if ($this->CurrentOrderType == "ASC" || $this->CurrentOrderType == "DESC") {
				$thisSort = $this->CurrentOrderType;
			} else {
				$thisSort = ($lastSort == "ASC") ? "DESC" : "ASC";
			}
			$fld->setSort($thisSort);
			if ($fld->GroupingFieldId == 0)
				$this->setDetailOrderBy($sortField . " " . $thisSort); // Save to Session
		} else {
			if ($fld->GroupingFieldId == 0) $fld->setSort("");
		}
	}

	// Get Sort SQL
	protected function sortSql()
	{
		$dtlSortSql = $this->getDetailOrderBy(); // Get ORDER BY for detail fields from session
		$argrps = [];
		foreach ($this->fields as $fld) {
			if ($fld->getSort() != "") {
				$fldsql = $fld->Expression;
				if ($fld->GroupingFieldId > 0) {
					if ($fld->GroupSql != "")
						$argrps[$fld->GroupingFieldId] = str_replace("%s", $fldsql, $fld->GroupSql) . " " . $fld->getSort();
					else
						$argrps[$fld->GroupingFieldId] = $fldsql . " " . $fld->getSort();
				}
			}
		}
		$sortSql = "";
		foreach ($argrps as $grp) {
			if ($sortSql != "") $sortSql .= ", ";
			$sortSql .= $grp;
		}
		if ($dtlSortSql != "") {
			if ($sortSql != "") $sortSql .= ", ";
			$sortSql .= $dtlSortSql;
		}
		return $sortSql;
	}

	// Table Level Group SQL
	private $_sqlFirstGroupField = "";
	private $_sqlSelectGroup = "";
	private $_sqlOrderByGroup = "";

	// First Group Field
	public function getSqlFirstGroupField($alias = FALSE)
	{
		if ($this->_sqlFirstGroupField != "")
			return $this->_sqlFirstGroupField;
		$firstGroupField = &$this->businessname;
		$expr = $firstGroupField->Expression;
		if ($firstGroupField->GroupSql != "") {
			$expr = str_replace("%s", $firstGroupField->Expression, $firstGroupField->GroupSql);
			if ($alias)
				$expr .= " AS " . QuotedName($firstGroupField->getGroupName(), $this->Dbid);
		}
		return $expr;
	}
	public function setSqlFirstGroupField($v)
	{
		$this->_sqlFirstGroupField = $v;
	}

	// Select Group
	public function getSqlSelectGroup()
	{
		return ($this->_sqlSelectGroup != "") ? $this->_sqlSelectGroup : "SELECT DISTINCT " . $this->getSqlFirstGroupField(TRUE) . " FROM " . $this->getSqlFrom();
	}
	public function setSqlSelectGroup($v)
	{
		$this->_sqlSelectGroup = $v;
	}

	// Order By Group
	public function getSqlOrderByGroup()
	{
		if ($this->_sqlOrderByGroup != "")
			return $this->_sqlOrderByGroup;
		return $this->getSqlFirstGroupField() . " ASC";
	}
	public function setSqlOrderByGroup($v)
	{
		$this->_sqlOrderByGroup = $v;
	}

	// Summary properties
	private $_sqlSelectAggregate = "";
	private $_sqlAggregatePrefix = "";
	private $_sqlAggregateSuffix = "";
	private $_sqlSelectCount = "";

	// Select Aggregate
	public function getSqlSelectAggregate()
	{
		return ($this->_sqlSelectAggregate != "") ? $this->_sqlSelectAggregate : "SELECT SUM(`availablebalance`) AS `sum_availablebalance`, SUM(`unavailablebalance`) AS `sum_unavailablebalance` FROM " . $this->getSqlFrom();
	}
	public function setSqlSelectAggregate($v)
	{
		$this->_sqlSelectAggregate = $v;
	}

	// Aggregate Prefix
	public function getSqlAggregatePrefix()
	{
		return ($this->_sqlAggregatePrefix != "") ? $this->_sqlAggregatePrefix : "";
	}
	public function setSqlAggregatePrefix($v)
	{
		$this->_sqlAggregatePrefix = $v;
	}

	// Aggregate Suffix
	public function getSqlAggregateSuffix()
	{
		return ($this->_sqlAggregateSuffix != "") ? $this->_sqlAggregateSuffix : "";
	}
	public function setSqlAggregateSuffix($v)
	{
		$this->_sqlAggregateSuffix = $v;
	}

	// Select Count
	public function getSqlSelectCount()
	{
		return ($this->_sqlSelectCount != "") ? $this->_sqlSelectCount : "SELECT COUNT(*) FROM " . $this->getSqlFrom();
	}
	public function setSqlSelectCount($v)
	{
		$this->_sqlSelectCount = $v;
	}

	// Render for lookup
	public function renderLookup()
	{
		$this->businessname->ViewValue = $this->businessname->CurrentValue;
		$this->firstName->ViewValue = $this->firstName->CurrentValue;
		$this->lastName->ViewValue = $this->lastName->CurrentValue;
		$this->rolename->ViewValue = GetDropDownDisplayValue($this->rolename->CurrentValue, "", 0);
		$this->currCode->ViewValue = GetDropDownDisplayValue($this->currCode->CurrentValue, "", 0);
	}

	// Table level SQL
	public function getSqlFrom() // From
	{
		return ($this->SqlFrom != "") ? $this->SqlFrom : "`vecashbalancesperrolemerchant`";
	}
	public function sqlFrom() // For backward compatibility
	{
		return $this->getSqlFrom();
	}
	public function setSqlFrom($v)
	{
		$this->SqlFrom = $v;
	}
	public function getSqlSelect() // Select
	{
		if ($this->SqlSelect != "")
			return $this->SqlSelect;
		$select = "*";
		$groupField = &$this->businessname;
		if ($groupField->GroupSql != "") {
			$expr = str_replace("%s", $groupField->Expression, $groupField->GroupSql) . " AS " . QuotedName($groupField->getGroupName(), $this->Dbid);
			$select .= ", " . $expr;
		}
		$groupField = &$this->firstName;
		if ($groupField->GroupSql != "") {
			$expr = str_replace("%s", $groupField->Expression, $groupField->GroupSql) . " AS " . QuotedName($groupField->getGroupName(), $this->Dbid);
			$select .= ", " . $expr;
		}
		$groupField = &$this->lastName;
		if ($groupField->GroupSql != "") {
			$expr = str_replace("%s", $groupField->Expression, $groupField->GroupSql) . " AS " . QuotedName($groupField->getGroupName(), $this->Dbid);
			$select .= ", " . $expr;
		}
		$groupField = &$this->_userid;
		if ($groupField->GroupSql != "") {
			$expr = str_replace("%s", $groupField->Expression, $groupField->GroupSql) . " AS " . QuotedName($groupField->getGroupName(), $this->Dbid);
			$select .= ", " . $expr;
		}
		return "SELECT " . $select . " FROM " . $this->getSqlFrom();
	}
	public function sqlSelect() // For backward compatibility
	{
		return $this->getSqlSelect();
	}
	public function setSqlSelect($v)
	{
		$this->SqlSelect = $v;
	}
	public function getSqlWhere() // Where
	{
		$where = ($this->SqlWhere != "") ? $this->SqlWhere : "";
		$this->TableFilter = "";
		AddFilter($where, $this->TableFilter);
		return $where;
	}
	public function sqlWhere() // For backward compatibility
	{
		return $this->getSqlWhere();
	}
	public function setSqlWhere($v)
	{
		$this->SqlWhere = $v;
	}
	public function getSqlGroupBy() // Group By
	{
		return ($this->SqlGroupBy != "") ? $this->SqlGroupBy : "";
	}
	public function sqlGroupBy() // For backward compatibility
	{
		return $this->getSqlGroupBy();
	}
	public function setSqlGroupBy($v)
	{
		$this->SqlGroupBy = $v;
	}
	public function getSqlHaving() // Having
	{
		return ($this->SqlHaving != "") ? $this->SqlHaving : "";
	}
	public function sqlHaving() // For backward compatibility
	{
		return $this->getSqlHaving();
	}
	public function setSqlHaving($v)
	{
		$this->SqlHaving = $v;
	}
	public function getSqlOrderBy() // Order By
	{
		return ($this->SqlOrderBy != "") ? $this->SqlOrderBy : "";
	}
	public function sqlOrderBy() // For backward compatibility
	{
		return $this->getSqlOrderBy();
	}
	public function setSqlOrderBy($v)
	{
		$this->SqlOrderBy = $v;
	}

	// Apply User ID filters
	public function applyUserIDFilters($filter, $id = "")
	{
		return $filter;
	}

	// Check if User ID security allows view all
	public function userIDAllow($id = "")
	{
		$allow = $this->UserIDAllowSecurity;
		switch ($id) {
			case "add":
			case "copy":
			case "gridadd":
			case "register":
			case "addopt":
				return (($allow & 1) == 1);
			case "edit":
			case "gridedit":
			case "update":
			case "changepwd":
			case "forgotpwd":
				return (($allow & 4) == 4);
			case "delete":
				return (($allow & 2) == 2);
			case "view":
				return (($allow & 32) == 32);
			case "search":
				return (($allow & 64) == 64);
			case "lookup":
				return (($allow & 256) == 256);
			default:
				return (($allow & 8) == 8);
		}
	}

	// Get recordset
	public function getRecordset($sql, $rowcnt = -1, $offset = -1)
	{
		$conn = $this->getConnection();
		$conn->raiseErrorFn = Config("ERROR_FUNC");
		$rs = $conn->selectLimit($sql, $rowcnt, $offset);
		$conn->raiseErrorFn = "";
		return $rs;
	}

	// Get record count
	public function getRecordCount($sql, $c = NULL)
	{
		$cnt = -1;
		$rs = NULL;
		$sql = preg_replace('/\/\*BeginOrderBy\*\/[\s\S]+\/\*EndOrderBy\*\//', "", $sql); // Remove ORDER BY clause (MSSQL)
		$pattern = '/^SELECT\s([\s\S]+)\sFROM\s/i';

		// Skip Custom View / SubQuery / SELECT DISTINCT / ORDER BY
		if (($this->TableType == 'TABLE' || $this->TableType == 'VIEW' || $this->TableType == 'LINKTABLE') &&
			preg_match($pattern, $sql) && !preg_match('/\(\s*(SELECT[^)]+)\)/i', $sql) &&
			!preg_match('/^\s*select\s+distinct\s+/i', $sql) && !preg_match('/\s+order\s+by\s+/i', $sql)) {
			$sqlwrk = "SELECT COUNT(*) FROM " . preg_replace($pattern, "", $sql);
		} else {
			$sqlwrk = "SELECT COUNT(*) FROM (" . $sql . ") COUNT_TABLE";
		}
		$conn = $c ?: $this->getConnection();
		if ($rs = $conn->execute($sqlwrk)) {
			if (!$rs->EOF && $rs->FieldCount() > 0) {
				$cnt = $rs->fields[0];
				$rs->close();
			}
			return (int)$cnt;
		}

		// Unable to get count, get record count directly
		if ($rs = $conn->execute($sql)) {
			$cnt = $rs->RecordCount();
			$rs->close();
			return (int)$cnt;
		}
		return $cnt;
	}

	// Record filter WHERE clause
	protected function sqlKeyFilter()
	{
		return "`userid` = @_userid@ AND `currCode` = '@currCode@'";
	}

	// Get record filter
	public function getRecordFilter($row = NULL)
	{
		$keyFilter = $this->sqlKeyFilter();
		if (is_array($row))
			$val = array_key_exists('userid', $row) ? $row['userid'] : NULL;
		else
			$val = $this->_userid->OldValue !== NULL ? $this->_userid->OldValue : $this->_userid->CurrentValue;
		if (!is_numeric($val))
			return "0=1"; // Invalid key
		if ($val == NULL)
			return "0=1"; // Invalid key
		else
			$keyFilter = str_replace("@_userid@", AdjustSql($val, $this->Dbid), $keyFilter); // Replace key value
		if (is_array($row))
			$val = array_key_exists('currCode', $row) ? $row['currCode'] : NULL;
		else
			$val = $this->currCode->OldValue !== NULL ? $this->currCode->OldValue : $this->currCode->CurrentValue;
		if ($val == NULL)
			return "0=1"; // Invalid key
		else
			$keyFilter = str_replace("@currCode@", AdjustSql($val, $this->Dbid), $keyFilter); // Replace key value
		return $keyFilter;
	}

	// Return page URL
	public function getReturnUrl()
	{
		$name = PROJECT_NAME . "_" . $this->TableVar . "_" . Config("TABLE_RETURN_URL");

		// Get referer URL automatically
		if (ServerVar("HTTP_REFERER") != "" && ReferPageName() != CurrentPageName() && ReferPageName() != "login.php") // Referer not same page or login page
			$_SESSION[$name] = ServerVar("HTTP_REFERER"); // Save to Session
		if (@$_SESSION[$name] != "") {
			return $_SESSION[$name];
		} else {
			return "";
		}
	}
	public function setReturnUrl($v)
	{
		$_SESSION[PROJECT_NAME . "_" . $this->TableVar . "_" . Config("TABLE_RETURN_URL")] = $v;
	}

	// Get modal caption
	public function getModalCaption($pageName)
	{
		global $Language;
		if ($pageName == "")
			return $Language->phrase("View");
		elseif ($pageName == "")
			return $Language->phrase("Edit");
		elseif ($pageName == "")
			return $Language->phrase("Add");
		else
			return "";
	}

	// List URL
	public function getListUrl()
	{
		return "";
	}

	// View URL
	public function getViewUrl($parm = "")
	{
		if ($parm != "")
			$url = $this->keyUrl("", $this->getUrlParm($parm));
		else
			$url = $this->keyUrl("", $this->getUrlParm(Config("TABLE_SHOW_DETAIL") . "="));
		return $this->addMasterUrl($url);
	}

	// Add URL
	public function getAddUrl($parm = "")
	{
		if ($parm != "")
			$url = "?" . $this->getUrlParm($parm);
		else
			$url = "";
		return $this->addMasterUrl($url);
	}

	// Edit URL
	public function getEditUrl($parm = "")
	{
		$url = $this->keyUrl("", $this->getUrlParm($parm));
		return $this->addMasterUrl($url);
	}

	// Inline edit URL
	public function getInlineEditUrl()
	{
		$url = $this->keyUrl(CurrentPageName(), $this->getUrlParm("action=edit"));
		return $this->addMasterUrl($url);
	}

	// Copy URL
	public function getCopyUrl($parm = "")
	{
		$url = $this->keyUrl("", $this->getUrlParm($parm));
		return $this->addMasterUrl($url);
	}

	// Inline copy URL
	public function getInlineCopyUrl()
	{
		$url = $this->keyUrl(CurrentPageName(), $this->getUrlParm("action=copy"));
		return $this->addMasterUrl($url);
	}

	// Delete URL
	public function getDeleteUrl()
	{
		return $this->keyUrl("", $this->getUrlParm());
	}

	// Add master url
	public function addMasterUrl($url)
	{
		return $url;
	}
	public function keyToJson($htmlEncode = FALSE)
	{
		$json = "";
		$json .= "_userid:" . JsonEncode($this->_userid->CurrentValue, "number");
		$json .= ",currCode:" . JsonEncode($this->currCode->CurrentValue, "string");
		$json = "{" . $json . "}";
		if ($htmlEncode)
			$json = HtmlEncode($json);
		return $json;
	}

	// Add key value to URL
	public function keyUrl($url, $parm = "")
	{
		$url = $url . "?";
		if ($parm != "")
			$url .= $parm . "&";
		if ($this->_userid->CurrentValue != NULL) {
			$url .= "_userid=" . urlencode($this->_userid->CurrentValue);
		} else {
			return "javascript:ew.alert(ew.language.phrase('InvalidRecord'));";
		}
		if ($this->currCode->CurrentValue != NULL) {
			$url .= "&currCode=" . urlencode($this->currCode->CurrentValue);
		} else {
			return "javascript:ew.alert(ew.language.phrase('InvalidRecord'));";
		}
		return $url;
	}

	// Sort URL
	public function sortUrl(&$fld)
	{
		global $DashboardReport;
		if ($this->CurrentAction || $this->isExport() ||
			$this->DrillDown || $DashboardReport ||
			in_array($fld->Type, [128, 204, 205])) { // Unsortable data type
				return "";
		} elseif ($fld->Sortable) {
			$urlParm = $this->getUrlParm("order=" . urlencode($fld->Name) . "&amp;ordertype=" . $fld->reverseSort());
			return $this->addMasterUrl(CurrentPageName() . "?" . $urlParm);
		} else {
			return "";
		}
	}

	// Get record keys from Post/Get/Session
	public function getRecordKeys()
	{
		$arKeys = [];
		$arKey = [];
		if (Param("key_m") !== NULL) {
			$arKeys = Param("key_m");
			$cnt = count($arKeys);
			for ($i = 0; $i < $cnt; $i++)
				$arKeys[$i] = explode(Config("COMPOSITE_KEY_SEPARATOR"), $arKeys[$i]);
		} else {
			if (Param("_userid") !== NULL)
				$arKey[] = Param("_userid");
			elseif (IsApi() && Key(0) !== NULL)
				$arKey[] = Key(0);
			elseif (IsApi() && Route(2) !== NULL)
				$arKey[] = Route(2);
			else
				$arKeys = NULL; // Do not setup
			if (Param("currCode") !== NULL)
				$arKey[] = Param("currCode");
			elseif (IsApi() && Key(1) !== NULL)
				$arKey[] = Key(1);
			elseif (IsApi() && Route(3) !== NULL)
				$arKey[] = Route(3);
			else
				$arKeys = NULL; // Do not setup
			if (is_array($arKeys)) $arKeys[] = $arKey;

			//return $arKeys; // Do not return yet, so the values will also be checked by the following code
		}

		// Check keys
		$ar = [];
		if (is_array($arKeys)) {
			foreach ($arKeys as $key) {
				if (!is_array($key) || count($key) != 2)
					continue; // Just skip so other keys will still work
				if (!is_numeric($key[0])) // userid
					continue;
				$ar[] = $key;
			}
		}
		return $ar;
	}

	// Get filter from record keys
	public function getFilterFromRecordKeys($setCurrent = TRUE)
	{
		$arKeys = $this->getRecordKeys();
		$keyFilter = "";
		foreach ($arKeys as $key) {
			if ($keyFilter != "") $keyFilter .= " OR ";
			if ($setCurrent)
				$this->_userid->CurrentValue = $key[0];
			else
				$this->_userid->OldValue = $key[0];
			if ($setCurrent)
				$this->currCode->CurrentValue = $key[1];
			else
				$this->currCode->OldValue = $key[1];
			$keyFilter .= "(" . $this->getRecordFilter() . ")";
		}
		return $keyFilter;
	}

	// Load rows based on filter
	public function &loadRs($filter)
	{

		// Set up filter (WHERE Clause)
		$sql = $this->getSql($filter);
		$conn = $this->getConnection();
		$rs = $conn->execute($sql);
		return $rs;
	}

	// Get file data
	public function getFileData($fldparm, $key, $resize, $width = 0, $height = 0)
	{

		// No binary fields
		return FALSE;
	}

	// Email Sending event
	function Email_Sending($email, &$args) {

		//var_dump($email); var_dump($args); exit();
		return TRUE;
	}

	// Lookup Selecting event
	function Lookup_Selecting($fld, &$filter) {

		//var_dump($fld->Name, $fld->Lookup, $filter); // Uncomment to view the filter
		// Enter your code here

	}

	// Row Rendering event
	function Row_Rendering() {

		// Enter your code here
	}

	// Row Rendered event
	function Row_Rendered() {

		// To view properties of field class, use:
		//var_dump($this-><FieldName>);

	}

	// User ID Filtering event
	function UserID_Filtering(&$filter) {

		// Enter your code here
	}
}
?>