<?php
namespace PHPMaker2020\_4payadmin;

/**
 * Page class
 */
class vmerchantsales_list extends vmerchantsales
{

	// Page ID
	public $PageID = "list";

	// Project ID
	public $ProjectID = "{153C2D2E-60EE-4944-8753-3935EB38E8D6}";

	// Table name
	public $TableName = 'vmerchantsales';

	// Page object name
	public $PageObjName = "vmerchantsales_list";

	// Grid form hidden field names
	public $FormName = "fvmerchantsaleslist";
	public $FormActionName = "k_action";
	public $FormKeyName = "k_key";
	public $FormOldKeyName = "k_oldkey";
	public $FormBlankRowName = "k_blankrow";
	public $FormKeyCountName = "key_count";

	// Page URLs
	public $AddUrl;
	public $EditUrl;
	public $CopyUrl;
	public $DeleteUrl;
	public $ViewUrl;
	public $ListUrl;

	// Export URLs
	public $ExportPrintUrl;
	public $ExportHtmlUrl;
	public $ExportExcelUrl;
	public $ExportWordUrl;
	public $ExportXmlUrl;
	public $ExportCsvUrl;
	public $ExportPdfUrl;

	// Custom export
	public $ExportExcelCustom = FALSE;
	public $ExportWordCustom = FALSE;
	public $ExportPdfCustom = FALSE;
	public $ExportEmailCustom = FALSE;

	// Update URLs
	public $InlineAddUrl;
	public $InlineCopyUrl;
	public $InlineEditUrl;
	public $GridAddUrl;
	public $GridEditUrl;
	public $MultiDeleteUrl;
	public $MultiUpdateUrl;

	// Page headings
	public $Heading = "";
	public $Subheading = "";
	public $PageHeader;
	public $PageFooter;

	// Token
	public $Token = "";
	public $TokenTimeout = 0;
	public $CheckToken;

	// Page heading
	public function pageHeading()
	{
		global $Language;
		if ($this->Heading != "")
			return $this->Heading;
		if (method_exists($this, "tableCaption"))
			return $this->tableCaption();
		return "";
	}

	// Page subheading
	public function pageSubheading()
	{
		global $Language;
		if ($this->Subheading != "")
			return $this->Subheading;
		if ($this->TableName)
			return $Language->phrase($this->PageID);
		return "";
	}

	// Page name
	public function pageName()
	{
		return CurrentPageName();
	}

	// Page URL
	public function pageUrl()
	{
		$url = CurrentPageName() . "?";
		if ($this->UseTokenInUrl)
			$url .= "t=" . $this->TableVar . "&"; // Add page token
		return $url;
	}

	// Messages
	private $_message = "";
	private $_failureMessage = "";
	private $_successMessage = "";
	private $_warningMessage = "";

	// Get message
	public function getMessage()
	{
		return isset($_SESSION[SESSION_MESSAGE]) ? $_SESSION[SESSION_MESSAGE] : $this->_message;
	}

	// Set message
	public function setMessage($v)
	{
		AddMessage($this->_message, $v);
		$_SESSION[SESSION_MESSAGE] = $this->_message;
	}

	// Get failure message
	public function getFailureMessage()
	{
		return isset($_SESSION[SESSION_FAILURE_MESSAGE]) ? $_SESSION[SESSION_FAILURE_MESSAGE] : $this->_failureMessage;
	}

	// Set failure message
	public function setFailureMessage($v)
	{
		AddMessage($this->_failureMessage, $v);
		$_SESSION[SESSION_FAILURE_MESSAGE] = $this->_failureMessage;
	}

	// Get success message
	public function getSuccessMessage()
	{
		return isset($_SESSION[SESSION_SUCCESS_MESSAGE]) ? $_SESSION[SESSION_SUCCESS_MESSAGE] : $this->_successMessage;
	}

	// Set success message
	public function setSuccessMessage($v)
	{
		AddMessage($this->_successMessage, $v);
		$_SESSION[SESSION_SUCCESS_MESSAGE] = $this->_successMessage;
	}

	// Get warning message
	public function getWarningMessage()
	{
		return isset($_SESSION[SESSION_WARNING_MESSAGE]) ? $_SESSION[SESSION_WARNING_MESSAGE] : $this->_warningMessage;
	}

	// Set warning message
	public function setWarningMessage($v)
	{
		AddMessage($this->_warningMessage, $v);
		$_SESSION[SESSION_WARNING_MESSAGE] = $this->_warningMessage;
	}

	// Clear message
	public function clearMessage()
	{
		$this->_message = "";
		$_SESSION[SESSION_MESSAGE] = "";
	}

	// Clear failure message
	public function clearFailureMessage()
	{
		$this->_failureMessage = "";
		$_SESSION[SESSION_FAILURE_MESSAGE] = "";
	}

	// Clear success message
	public function clearSuccessMessage()
	{
		$this->_successMessage = "";
		$_SESSION[SESSION_SUCCESS_MESSAGE] = "";
	}

	// Clear warning message
	public function clearWarningMessage()
	{
		$this->_warningMessage = "";
		$_SESSION[SESSION_WARNING_MESSAGE] = "";
	}

	// Clear messages
	public function clearMessages()
	{
		$this->clearMessage();
		$this->clearFailureMessage();
		$this->clearSuccessMessage();
		$this->clearWarningMessage();
	}

	// Show message
	public function showMessage()
	{
		$hidden = FALSE;
		$html = "";

		// Message
		$message = $this->getMessage();
		if (method_exists($this, "Message_Showing"))
			$this->Message_Showing($message, "");
		if ($message != "") { // Message in Session, display
			if (!$hidden)
				$message = '<button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button>' . $message;
			$html .= '<div class="alert alert-info alert-dismissible ew-info"><i class="icon fas fa-info"></i>' . $message . '</div>';
			$_SESSION[SESSION_MESSAGE] = ""; // Clear message in Session
		}

		// Warning message
		$warningMessage = $this->getWarningMessage();
		if (method_exists($this, "Message_Showing"))
			$this->Message_Showing($warningMessage, "warning");
		if ($warningMessage != "") { // Message in Session, display
			if (!$hidden)
				$warningMessage = '<button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button>' . $warningMessage;
			$html .= '<div class="alert alert-warning alert-dismissible ew-warning"><i class="icon fas fa-exclamation"></i>' . $warningMessage . '</div>';
			$_SESSION[SESSION_WARNING_MESSAGE] = ""; // Clear message in Session
		}

		// Success message
		$successMessage = $this->getSuccessMessage();
		if (method_exists($this, "Message_Showing"))
			$this->Message_Showing($successMessage, "success");
		if ($successMessage != "") { // Message in Session, display
			if (!$hidden)
				$successMessage = '<button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button>' . $successMessage;
			$html .= '<div class="alert alert-success alert-dismissible ew-success"><i class="icon fas fa-check"></i>' . $successMessage . '</div>';
			$_SESSION[SESSION_SUCCESS_MESSAGE] = ""; // Clear message in Session
		}

		// Failure message
		$errorMessage = $this->getFailureMessage();
		if (method_exists($this, "Message_Showing"))
			$this->Message_Showing($errorMessage, "failure");
		if ($errorMessage != "") { // Message in Session, display
			if (!$hidden)
				$errorMessage = '<button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button>' . $errorMessage;
			$html .= '<div class="alert alert-danger alert-dismissible ew-error"><i class="icon fas fa-ban"></i>' . $errorMessage . '</div>';
			$_SESSION[SESSION_FAILURE_MESSAGE] = ""; // Clear message in Session
		}
		echo '<div class="ew-message-dialog' . (($hidden) ? ' d-none' : "") . '">' . $html . '</div>';
	}

	// Get message as array
	public function getMessages()
	{
		$ar = [];

		// Message
		$message = $this->getMessage();

		//if (method_exists($this, "Message_Showing"))
		//	$this->Message_Showing($message, "");

		if ($message != "") { // Message in Session, display
			$ar["message"] = $message;
			$_SESSION[SESSION_MESSAGE] = ""; // Clear message in Session
		}

		// Warning message
		$warningMessage = $this->getWarningMessage();

		//if (method_exists($this, "Message_Showing"))
		//	$this->Message_Showing($warningMessage, "warning");

		if ($warningMessage != "") { // Message in Session, display
			$ar["warningMessage"] = $warningMessage;
			$_SESSION[SESSION_WARNING_MESSAGE] = ""; // Clear message in Session
		}

		// Success message
		$successMessage = $this->getSuccessMessage();

		//if (method_exists($this, "Message_Showing"))
		//	$this->Message_Showing($successMessage, "success");

		if ($successMessage != "") { // Message in Session, display
			$ar["successMessage"] = $successMessage;
			$_SESSION[SESSION_SUCCESS_MESSAGE] = ""; // Clear message in Session
		}

		// Failure message
		$failureMessage = $this->getFailureMessage();

		//if (method_exists($this, "Message_Showing"))
		//	$this->Message_Showing($failureMessage, "failure");

		if ($failureMessage != "") { // Message in Session, display
			$ar["failureMessage"] = $failureMessage;
			$_SESSION[SESSION_FAILURE_MESSAGE] = ""; // Clear message in Session
		}
		return $ar;
	}

	// Show Page Header
	public function showPageHeader()
	{
		$header = $this->PageHeader;
		$this->Page_DataRendering($header);
		if ($header != "") { // Header exists, display
			echo '<p id="ew-page-header">' . $header . '</p>';
		}
	}

	// Show Page Footer
	public function showPageFooter()
	{
		$footer = $this->PageFooter;
		$this->Page_DataRendered($footer);
		if ($footer != "") { // Footer exists, display
			echo '<p id="ew-page-footer">' . $footer . '</p>';
		}
	}

	// Validate page request
	protected function isPageRequest()
	{
		global $CurrentForm;
		if ($this->UseTokenInUrl) {
			if ($CurrentForm)
				return ($this->TableVar == $CurrentForm->getValue("t"));
			if (Get("t") !== NULL)
				return ($this->TableVar == Get("t"));
		}
		return TRUE;
	}

	// Valid Post
	protected function validPost()
	{
		if (!$this->CheckToken || !IsPost() || IsApi())
			return TRUE;
		if (Post(Config("TOKEN_NAME")) === NULL)
			return FALSE;
		$fn = Config("CHECK_TOKEN_FUNC");
		if (is_callable($fn))
			return $fn(Post(Config("TOKEN_NAME")), $this->TokenTimeout);
		return FALSE;
	}

	// Create Token
	public function createToken()
	{
		global $CurrentToken;
		$fn = Config("CREATE_TOKEN_FUNC"); // Always create token, required by API file/lookup request
		if ($this->Token == "" && is_callable($fn)) // Create token
			$this->Token = $fn();
		$CurrentToken = $this->Token; // Save to global variable
	}

	// Constructor
	public function __construct()
	{
		global $Language, $DashboardReport;
		global $UserTable;

		// Check token
		$this->CheckToken = Config("CHECK_TOKEN");

		// Initialize
		$GLOBALS["Page"] = &$this;
		$this->TokenTimeout = SessionTimeoutTime();

		// Language object
		if (!isset($Language))
			$Language = new Language();

		// Parent constuctor
		parent::__construct();

		// Table object (vmerchantsales)
		if (!isset($GLOBALS["vmerchantsales"]) || get_class($GLOBALS["vmerchantsales"]) == PROJECT_NAMESPACE . "vmerchantsales") {
			$GLOBALS["vmerchantsales"] = &$this;
			$GLOBALS["Table"] = &$GLOBALS["vmerchantsales"];
		}

		// Initialize URLs
		$this->ExportPrintUrl = $this->pageUrl() . "export=print";
		$this->ExportExcelUrl = $this->pageUrl() . "export=excel";
		$this->ExportWordUrl = $this->pageUrl() . "export=word";
		$this->ExportPdfUrl = $this->pageUrl() . "export=pdf";
		$this->ExportHtmlUrl = $this->pageUrl() . "export=html";
		$this->ExportXmlUrl = $this->pageUrl() . "export=xml";
		$this->ExportCsvUrl = $this->pageUrl() . "export=csv";
		$this->AddUrl = "vmerchantsalesadd.php";
		$this->InlineAddUrl = $this->pageUrl() . "action=add";
		$this->GridAddUrl = $this->pageUrl() . "action=gridadd";
		$this->GridEditUrl = $this->pageUrl() . "action=gridedit";
		$this->MultiDeleteUrl = "vmerchantsalesdelete.php";
		$this->MultiUpdateUrl = "vmerchantsalesupdate.php";

		// Table object (admin)
		if (!isset($GLOBALS['admin']))
			$GLOBALS['admin'] = new admin();

		// Page ID (for backward compatibility only)
		if (!defined(PROJECT_NAMESPACE . "PAGE_ID"))
			define(PROJECT_NAMESPACE . "PAGE_ID", 'list');

		// Table name (for backward compatibility only)
		if (!defined(PROJECT_NAMESPACE . "TABLE_NAME"))
			define(PROJECT_NAMESPACE . "TABLE_NAME", 'vmerchantsales');

		// Start timer
		if (!isset($GLOBALS["DebugTimer"]))
			$GLOBALS["DebugTimer"] = new Timer();

		// Debug message
		LoadDebugMessage();

		// Open connection
		if (!isset($GLOBALS["Conn"]))
			$GLOBALS["Conn"] = $this->getConnection();

		// User table object (admin)
		$UserTable = $UserTable ?: new admin();

		// List options
		$this->ListOptions = new ListOptions();
		$this->ListOptions->TableVar = $this->TableVar;

		// Export options
		$this->ExportOptions = new ListOptions("div");
		$this->ExportOptions->TagClassName = "ew-export-option";

		// Import options
		$this->ImportOptions = new ListOptions("div");
		$this->ImportOptions->TagClassName = "ew-import-option";

		// Other options
		if (!$this->OtherOptions)
			$this->OtherOptions = new ListOptionsArray();
		$this->OtherOptions["addedit"] = new ListOptions("div");
		$this->OtherOptions["addedit"]->TagClassName = "ew-add-edit-option";
		$this->OtherOptions["detail"] = new ListOptions("div");
		$this->OtherOptions["detail"]->TagClassName = "ew-detail-option";
		$this->OtherOptions["action"] = new ListOptions("div");
		$this->OtherOptions["action"]->TagClassName = "ew-action-option";

		// Filter options
		$this->FilterOptions = new ListOptions("div");
		$this->FilterOptions->TagClassName = "ew-filter-option fvmerchantsaleslistsrch";

		// List actions
		$this->ListActions = new ListActions();
	}

	// Terminate page
	public function terminate($url = "")
	{
		global $ExportFileName, $TempImages, $DashboardReport;

		// Page Unload event
		$this->Page_Unload();

		// Global Page Unloaded event (in userfn*.php)
		Page_Unloaded();

		// Export
		global $vmerchantsales;
		if ($this->CustomExport && $this->CustomExport == $this->Export && array_key_exists($this->CustomExport, Config("EXPORT_CLASSES"))) {
				$content = ob_get_contents();
			if ($ExportFileName == "")
				$ExportFileName = $this->TableVar;
			$class = PROJECT_NAMESPACE . Config("EXPORT_CLASSES." . $this->CustomExport);
			if (class_exists($class)) {
				$doc = new $class($vmerchantsales);
				$doc->Text = @$content;
				if ($this->isExport("email"))
					echo $this->exportEmail($doc->Text);
				else
					$doc->export();
				DeleteTempImages(); // Delete temp images
				exit();
			}
		}
		if (!IsApi())
			$this->Page_Redirecting($url);

		// Close connection
		CloseConnections();

		// Return for API
		if (IsApi()) {
			$res = $url === TRUE;
			if (!$res) // Show error
				WriteJson(array_merge(["success" => FALSE], $this->getMessages()));
			return;
		}

		// Go to URL if specified
		if ($url != "") {
			if (!Config("DEBUG") && ob_get_length())
				ob_end_clean();
			SaveDebugMessage();
			AddHeader("Location", $url);
		}
		exit();
	}

	// Get records from recordset
	protected function getRecordsFromRecordset($rs, $current = FALSE)
	{
		$rows = [];
		if (is_object($rs)) { // Recordset
			while ($rs && !$rs->EOF) {
				$this->loadRowValues($rs); // Set up DbValue/CurrentValue
				$row = $this->getRecordFromArray($rs->fields);
				if ($current)
					return $row;
				else
					$rows[] = $row;
				$rs->moveNext();
			}
		} elseif (is_array($rs)) {
			foreach ($rs as $ar) {
				$row = $this->getRecordFromArray($ar);
				if ($current)
					return $row;
				else
					$rows[] = $row;
			}
		}
		return $rows;
	}

	// Get record from array
	protected function getRecordFromArray($ar)
	{
		$row = [];
		if (is_array($ar)) {
			foreach ($ar as $fldname => $val) {
				if (array_key_exists($fldname, $this->fields) && ($this->fields[$fldname]->Visible || $this->fields[$fldname]->IsPrimaryKey)) { // Primary key or Visible
					$fld = &$this->fields[$fldname];
					if ($fld->HtmlTag == "FILE") { // Upload field
						if (EmptyValue($val)) {
							$row[$fldname] = NULL;
						} else {
							if ($fld->DataType == DATATYPE_BLOB) {
								$url = FullUrl(GetApiUrl(Config("API_FILE_ACTION"),
									Config("API_OBJECT_NAME") . "=" . $fld->TableVar . "&" .
									Config("API_FIELD_NAME") . "=" . $fld->Param . "&" .
									Config("API_KEY_NAME") . "=" . rawurlencode($this->getRecordKeyValue($ar)))); //*** need to add this? API may not be in the same folder
								$row[$fldname] = ["type" => ContentType($val), "url" => $url, "name" => $fld->Param . ContentExtension($val)];
							} elseif (!$fld->UploadMultiple || !ContainsString($val, Config("MULTIPLE_UPLOAD_SEPARATOR"))) { // Single file
								$url = FullUrl(GetApiUrl(Config("API_FILE_ACTION"),
									Config("API_OBJECT_NAME") . "=" . $fld->TableVar . "&" .
									"fn=" . Encrypt($fld->physicalUploadPath() . $val)));
								$row[$fldname] = ["type" => MimeContentType($val), "url" => $url, "name" => $val];
							} else { // Multiple files
								$files = explode(Config("MULTIPLE_UPLOAD_SEPARATOR"), $val);
								$ar = [];
								foreach ($files as $file) {
									$url = FullUrl(GetApiUrl(Config("API_FILE_ACTION"),
										Config("API_OBJECT_NAME") . "=" . $fld->TableVar . "&" .
										"fn=" . Encrypt($fld->physicalUploadPath() . $file)));
									if (!EmptyValue($file))
										$ar[] = ["type" => MimeContentType($file), "url" => $url, "name" => $file];
								}
								$row[$fldname] = $ar;
							}
						}
					} else {
						if ($fld->DataType == DATATYPE_MEMO && $fld->MemoMaxLength > 0)
							$val = TruncateMemo($val, $fld->MemoMaxLength, $fld->TruncateMemoRemoveHtml);
						$row[$fldname] = $val;
					}
				}
			}
		}
		return $row;
	}

	// Get record key value from array
	protected function getRecordKeyValue($ar)
	{
		$key = "";
		if (is_array($ar)) {
			$key .= @$ar['transferID'] . Config("COMPOSITE_KEY_SEPARATOR");
			$key .= @$ar['txid'];
		}
		return $key;
	}

	/**
	 * Hide fields for add/edit
	 *
	 * @return void
	 */
	protected function hideFieldsForAddEdit()
	{
		if ($this->isAdd() || $this->isCopy() || $this->isGridAdd())
			$this->transferID->Visible = FALSE;
	}

	// Lookup data
	public function lookup()
	{
		global $Language, $Security;
		if (!isset($Language))
			$Language = new Language(Config("LANGUAGE_FOLDER"), Post("language", ""));

		// Set up API request
		if (!ValidApiRequest())
			return FALSE;
		$this->setupApiSecurity();

		// Get lookup object
		$fieldName = Post("field");
		if (!array_key_exists($fieldName, $this->fields))
			return FALSE;
		$lookupField = $this->fields[$fieldName];
		$lookup = $lookupField->Lookup;
		if ($lookup === NULL)
			return FALSE;
		$tbl = $lookup->getTable();
		if (!$Security->allowLookup(Config("PROJECT_ID") . $tbl->TableName)) // Lookup permission
			return FALSE;

		// Get lookup parameters
		$lookupType = Post("ajax", "unknown");
		$pageSize = -1;
		$offset = -1;
		$searchValue = "";
		if (SameText($lookupType, "modal")) {
			$searchValue = Post("sv", "");
			$pageSize = Post("recperpage", 10);
			$offset = Post("start", 0);
		} elseif (SameText($lookupType, "autosuggest")) {
			$searchValue = Param("q", "");
			$pageSize = Param("n", -1);
			$pageSize = is_numeric($pageSize) ? (int)$pageSize : -1;
			if ($pageSize <= 0)
				$pageSize = Config("AUTO_SUGGEST_MAX_ENTRIES");
			$start = Param("start", -1);
			$start = is_numeric($start) ? (int)$start : -1;
			$page = Param("page", -1);
			$page = is_numeric($page) ? (int)$page : -1;
			$offset = $start >= 0 ? $start : ($page > 0 && $pageSize > 0 ? ($page - 1) * $pageSize : 0);
		}
		$userSelect = Decrypt(Post("s", ""));
		$userFilter = Decrypt(Post("f", ""));
		$userOrderBy = Decrypt(Post("o", ""));
		$keys = Post("keys");
		$lookup->LookupType = $lookupType; // Lookup type
		if ($keys !== NULL) { // Selected records from modal
			if (is_array($keys))
				$keys = implode(Config("MULTIPLE_OPTION_SEPARATOR"), $keys);
			$lookup->FilterFields = []; // Skip parent fields if any
			$lookup->FilterValues[] = $keys; // Lookup values
			$pageSize = -1; // Show all records
		} else { // Lookup values
			$lookup->FilterValues[] = Post("v0", Post("lookupValue", ""));
		}
		$cnt = is_array($lookup->FilterFields) ? count($lookup->FilterFields) : 0;
		for ($i = 1; $i <= $cnt; $i++)
			$lookup->FilterValues[] = Post("v" . $i, "");
		$lookup->SearchValue = $searchValue;
		$lookup->PageSize = $pageSize;
		$lookup->Offset = $offset;
		if ($userSelect != "")
			$lookup->UserSelect = $userSelect;
		if ($userFilter != "")
			$lookup->UserFilter = $userFilter;
		if ($userOrderBy != "")
			$lookup->UserOrderBy = $userOrderBy;
		$lookup->toJson($this); // Use settings from current page
	}

	// Set up API security
	public function setupApiSecurity()
	{
		global $Security;

		// Setup security for API request
		if ($Security->isLoggedIn()) $Security->TablePermission_Loading();
		$Security->loadCurrentUserLevel(Config("PROJECT_ID") . $this->TableName);
		if ($Security->isLoggedIn()) $Security->TablePermission_Loaded();
	}

	// Class variables
	public $ListOptions; // List options
	public $ExportOptions; // Export options
	public $SearchOptions; // Search options
	public $OtherOptions; // Other options
	public $FilterOptions; // Filter options
	public $ImportOptions; // Import options
	public $ListActions; // List actions
	public $SelectedCount = 0;
	public $SelectedIndex = 0;
	public $DisplayRecords = 10;
	public $StartRecord;
	public $StopRecord;
	public $TotalRecords = 0;
	public $RecordRange = 10;
	public $PageSizes = ""; // Page sizes (comma separated)
	public $DefaultSearchWhere = ""; // Default search WHERE clause
	public $SearchWhere = ""; // Search WHERE clause
	public $SearchPanelClass = "ew-search-panel collapse"; // Search Panel class
	public $SearchRowCount = 0; // For extended search
	public $SearchColumnCount = 0; // For extended search
	public $SearchFieldsPerRow = 1; // For extended search
	public $RecordCount = 0; // Record count
	public $EditRowCount;
	public $StartRowCount = 1;
	public $RowCount = 0;
	public $Attrs = []; // Row attributes and cell attributes
	public $RowIndex = 0; // Row index
	public $KeyCount = 0; // Key count
	public $RowAction = ""; // Row action
	public $RowOldKey = ""; // Row old key (for copy)
	public $MultiColumnClass = "col-sm";
	public $MultiColumnEditClass = "w-100";
	public $DbMasterFilter = ""; // Master filter
	public $DbDetailFilter = ""; // Detail filter
	public $MasterRecordExists;
	public $MultiSelectKey;
	public $Command;
	public $RestoreSearch = FALSE;
	public $DetailPages;
	public $OldRecordset;

	//
	// Page run
	//

	public function run()
	{
		global $ExportType, $CustomExportType, $ExportFileName, $UserProfile, $Language, $Security, $CurrentForm,
			$FormError, $SearchError;

		// User profile
		$UserProfile = new UserProfile();

		// Security
		if (ValidApiRequest()) { // API request
			$this->setupApiSecurity(); // Set up API Security
			if (!$Security->canList()) {
				SetStatus(401); // Unauthorized
				return;
			}
		} else {
			$Security = new AdvancedSecurity();
			if (IsPasswordExpired())
				$this->terminate(GetUrl("changepwd.php"));
			if (!$Security->isLoggedIn())
				$Security->autoLogin();
			if ($Security->isLoggedIn())
				$Security->TablePermission_Loading();
			$Security->loadCurrentUserLevel($this->ProjectID . $this->TableName);
			if ($Security->isLoggedIn())
				$Security->TablePermission_Loaded();
			if (!$Security->canList()) {
				$Security->saveLastUrl();
				$this->setFailureMessage(DeniedMessage()); // Set no permission
				$this->terminate(GetUrl("index.php"));
				return;
			}
		}

		// Get export parameters
		$custom = "";
		if (Param("export") !== NULL) {
			$this->Export = Param("export");
			$custom = Param("custom", "");
		} elseif (IsPost()) {
			if (Post("exporttype") !== NULL)
				$this->Export = Post("exporttype");
			$custom = Post("custom", "");
		} elseif (Get("cmd") == "json") {
			$this->Export = Get("cmd");
		} else {
			$this->setExportReturnUrl(CurrentUrl());
		}
		$ExportFileName = $this->TableVar; // Get export file, used in header

		// Get custom export parameters
		if ($this->isExport() && $custom != "") {
			$this->CustomExport = $this->Export;
			$this->Export = "print";
		}
		$CustomExportType = $this->CustomExport;
		$ExportType = $this->Export; // Get export parameter, used in header

		// Update Export URLs
		if (Config("USE_PHPEXCEL"))
			$this->ExportExcelCustom = FALSE;
		if ($this->ExportExcelCustom)
			$this->ExportExcelUrl .= "&amp;custom=1";
		if (Config("USE_PHPWORD"))
			$this->ExportWordCustom = FALSE;
		if ($this->ExportWordCustom)
			$this->ExportWordUrl .= "&amp;custom=1";
		if ($this->ExportPdfCustom)
			$this->ExportPdfUrl .= "&amp;custom=1";
		$this->CurrentAction = Param("action"); // Set up current action

		// Get grid add count
		$gridaddcnt = Get(Config("TABLE_GRID_ADD_ROW_COUNT"), "");
		if (is_numeric($gridaddcnt) && $gridaddcnt > 0)
			$this->GridAddRowCount = $gridaddcnt;

		// Set up list options
		$this->setupListOptions();

		// Setup export options
		$this->setupExportOptions();
		$this->transferID->setVisibility();
		$this->txid->setVisibility();
		$this->merchantID->setVisibility();
		$this->_userID->Visible = FALSE;
		$this->transferTime->setVisibility();
		$this->status->setVisibility();
		$this->currID->setVisibility();
		$this->TotalAmountForCustomer->setVisibility();
		$this->serviceFeeToMerchant->setVisibility();
		$this->TotalAmountForMerchant->setVisibility();
		$this->userpiid->setVisibility();
		$this->shoppingCartID->setVisibility();
		$this->merchantRefID->setVisibility();
		$this->purchaseAmount->Visible = FALSE;
		$this->taxAmount->Visible = FALSE;
		$this->tipAmount->Visible = FALSE;
		$this->discountamount->Visible = FALSE;
		$this->merchantSurcharge->Visible = FALSE;
		$this->serviceFeeToCustomer->Visible = FALSE;
		$this->feeid->Visible = FALSE;
		$this->ratetabletype->Visible = FALSE;
		$this->pis->Visible = FALSE;
		$this->feesystemshare->Visible = FALSE;
		$this->feeexternalshare->Visible = FALSE;
		$this->feefranchiseeshare->Visible = FALSE;
		$this->feeresellershare->Visible = FALSE;
		$this->lastupdatetime->Visible = FALSE;
		$this->officialdocnumber->Visible = FALSE;
		$this->officialdocname->Visible = FALSE;
		$this->businessname->Visible = FALSE;
		$this->logofilename->Visible = FALSE;
		$this->returndays->Visible = FALSE;
		$this->originalpurchaseamount->Visible = FALSE;
		$this->customerpurchaseid->Visible = FALSE;
		$this->clerkFirstName->Visible = FALSE;
		$this->clerkLastName->Visible = FALSE;
		$this->originalMerchantSurcharge->Visible = FALSE;
		$this->originalTaxAmount->Visible = FALSE;
		$this->originalServiceFeeToCustomer->Visible = FALSE;
		$this->originalTotalAmountForCustomer->Visible = FALSE;
		$this->originalServiceFeeToMerchant->Visible = FALSE;
		$this->originalTipAmount->Visible = FALSE;
		$this->userpi->setVisibility();
		$this->hideFieldsForAddEdit();

		// Global Page Loading event (in userfn*.php)
		Page_Loading();

		// Page Load event
		$this->Page_Load();

		// Check token
		if (!$this->validPost()) {
			Write($Language->phrase("InvalidPostRequest"));
			$this->terminate();
		}

		// Create Token
		$this->createToken();

		// Setup other options
		$this->setupOtherOptions();

		// Set up custom action (compatible with old version)
		foreach ($this->CustomActions as $name => $action)
			$this->ListActions->add($name, $action);

		// Show checkbox column if multiple action
		foreach ($this->ListActions->Items as $listaction) {
			if ($listaction->Select == ACTION_MULTIPLE && $listaction->Allow) {
				$this->ListOptions["checkbox"]->Visible = TRUE;
				break;
			}
		}

		// Set up lookup cache
		$this->setupLookupOptions($this->merchantID);
		$this->setupLookupOptions($this->userpiid);

		// Search filters
		$srchAdvanced = ""; // Advanced search filter
		$srchBasic = ""; // Basic search filter
		$filter = "";

		// Get command
		$this->Command = strtolower(Get("cmd"));
		if ($this->isPageRequest()) { // Validate request

			// Process list action first
			if ($this->processListAction()) // Ajax request
				$this->terminate();

			// Set up records per page
			$this->setupDisplayRecords();

			// Handle reset command
			$this->resetCmd();

			// Set up Breadcrumb
			if (!$this->isExport())
				$this->setupBreadcrumb();

			// Hide list options
			if ($this->isExport()) {
				$this->ListOptions->hideAllOptions(["sequence"]);
				$this->ListOptions->UseDropDownButton = FALSE; // Disable drop down button
				$this->ListOptions->UseButtonGroup = FALSE; // Disable button group
			} elseif ($this->isGridAdd() || $this->isGridEdit()) {
				$this->ListOptions->hideAllOptions();
				$this->ListOptions->UseDropDownButton = FALSE; // Disable drop down button
				$this->ListOptions->UseButtonGroup = FALSE; // Disable button group
			}

			// Hide options
			if ($this->isExport() || $this->CurrentAction) {
				$this->ExportOptions->hideAllOptions();
				$this->FilterOptions->hideAllOptions();
				$this->ImportOptions->hideAllOptions();
			}

			// Hide other options
			if ($this->isExport())
				$this->OtherOptions->hideAllOptions();

			// Get default search criteria
			AddFilter($this->DefaultSearchWhere, $this->basicSearchWhere(TRUE));
			AddFilter($this->DefaultSearchWhere, $this->advancedSearchWhere(TRUE));

			// Get basic search values
			$this->loadBasicSearchValues();

			// Get and validate search values for advanced search
			$this->loadSearchValues(); // Get search values

			// Process filter list
			if ($this->processFilterList())
				$this->terminate();
			if (!$this->validateSearch())
				$this->setFailureMessage($SearchError);

			// Restore search parms from Session if not searching / reset / export
			if (($this->isExport() || $this->Command != "search" && $this->Command != "reset" && $this->Command != "resetall") && $this->Command != "json" && $this->checkSearchParms())
				$this->restoreSearchParms();

			// Call Recordset SearchValidated event
			$this->Recordset_SearchValidated();

			// Set up sorting order
			$this->setupSortOrder();

			// Get basic search criteria
			if ($SearchError == "")
				$srchBasic = $this->basicSearchWhere();

			// Get search criteria for advanced search
			if ($SearchError == "")
				$srchAdvanced = $this->advancedSearchWhere();
		}

		// Restore display records
		if ($this->Command != "json" && $this->getRecordsPerPage() != "") {
			$this->DisplayRecords = $this->getRecordsPerPage(); // Restore from Session
		} else {
			$this->DisplayRecords = 10; // Load default
			$this->setRecordsPerPage($this->DisplayRecords); // Save default to Session
		}

		// Load Sorting Order
		if ($this->Command != "json")
			$this->loadSortOrder();

		// Load search default if no existing search criteria
		if (!$this->checkSearchParms()) {

			// Load basic search from default
			$this->BasicSearch->loadDefault();
			if ($this->BasicSearch->Keyword != "")
				$srchBasic = $this->basicSearchWhere();

			// Load advanced search from default
			if ($this->loadAdvancedSearchDefault()) {
				$srchAdvanced = $this->advancedSearchWhere();
			}
		}

		// Restore search settings from Session
		if ($SearchError == "")
			$this->loadAdvancedSearch();

		// Build search criteria
		AddFilter($this->SearchWhere, $srchAdvanced);
		AddFilter($this->SearchWhere, $srchBasic);

		// Call Recordset_Searching event
		$this->Recordset_Searching($this->SearchWhere);

		// Save search criteria
		if ($this->Command == "search" && !$this->RestoreSearch) {
			$this->setSearchWhere($this->SearchWhere); // Save to Session
			$this->StartRecord = 1; // Reset start record counter
			$this->setStartRecordNumber($this->StartRecord);
		} elseif ($this->Command != "json") {
			$this->SearchWhere = $this->getSearchWhere();
		}

		// Build filter
		$filter = "";
		if (!$Security->canList())
			$filter = "(0=1)"; // Filter all records
		AddFilter($filter, $this->DbDetailFilter);
		AddFilter($filter, $this->SearchWhere);

		// Set up filter
		if ($this->Command == "json") {
			$this->UseSessionForListSql = FALSE; // Do not use session for ListSQL
			$this->CurrentFilter = $filter;
		} else {
			$this->setSessionWhere($filter);
			$this->CurrentFilter = "";
		}

		// Export data only
		if (!$this->CustomExport && in_array($this->Export, array_keys(Config("EXPORT_CLASSES")))) {
			$this->exportData();
			$this->terminate();
		}
		if ($this->isGridAdd()) {
			$this->CurrentFilter = "0=1";
			$this->StartRecord = 1;
			$this->DisplayRecords = $this->GridAddRowCount;
			$this->TotalRecords = $this->DisplayRecords;
			$this->StopRecord = $this->DisplayRecords;
		} else {
			$selectLimit = $this->UseSelectLimit;
			if ($selectLimit) {
				$this->TotalRecords = $this->listRecordCount();
			} else {
				if ($this->Recordset = $this->loadRecordset())
					$this->TotalRecords = $this->Recordset->RecordCount();
			}
			$this->StartRecord = 1;
			if ($this->DisplayRecords <= 0 || ($this->isExport() && $this->ExportAll)) // Display all records
				$this->DisplayRecords = $this->TotalRecords;
			if (!($this->isExport() && $this->ExportAll)) // Set up start record position
				$this->setupStartRecord();
			if ($selectLimit)
				$this->Recordset = $this->loadRecordset($this->StartRecord - 1, $this->DisplayRecords);

			// Set no record found message
			if (!$this->CurrentAction && $this->TotalRecords == 0) {
				if (!$Security->canList())
					$this->setWarningMessage(DeniedMessage());
				if ($this->SearchWhere == "0=101")
					$this->setWarningMessage($Language->phrase("EnterSearchCriteria"));
				else
					$this->setWarningMessage($Language->phrase("NoRecord"));
			}
		}

		// Search options
		$this->setupSearchOptions();

		// Set up search panel class
		if ($this->SearchWhere != "")
			AppendClass($this->SearchPanelClass, "show");

		// Normal return
		if (IsApi()) {
			$rows = $this->getRecordsFromRecordset($this->Recordset);
			$this->Recordset->close();
			WriteJson(["success" => TRUE, $this->TableVar => $rows, "totalRecordCount" => $this->TotalRecords]);
			$this->terminate(TRUE);
		}

		// Set up pager
		$this->Pager = new PrevNextPager($this->StartRecord, $this->getRecordsPerPage(), $this->TotalRecords, $this->PageSizes, $this->RecordRange, $this->AutoHidePager, $this->AutoHidePageSizeSelector);
	}

	// Set up number of records displayed per page
	protected function setupDisplayRecords()
	{
		$wrk = Get(Config("TABLE_REC_PER_PAGE"), "");
		if ($wrk != "") {
			if (is_numeric($wrk)) {
				$this->DisplayRecords = (int)$wrk;
			} else {
				if (SameText($wrk, "all")) { // Display all records
					$this->DisplayRecords = -1;
				} else {
					$this->DisplayRecords = 10; // Non-numeric, load default
				}
			}
			$this->setRecordsPerPage($this->DisplayRecords); // Save to Session

			// Reset start position
			$this->StartRecord = 1;
			$this->setStartRecordNumber($this->StartRecord);
		}
	}

	// Build filter for all keys
	protected function buildKeyFilter()
	{
		global $CurrentForm;
		$wrkFilter = "";

		// Update row index and get row key
		$rowindex = 1;
		$CurrentForm->Index = $rowindex;
		$thisKey = strval($CurrentForm->getValue($this->FormKeyName));
		while ($thisKey != "") {
			if ($this->setupKeyValues($thisKey)) {
				$filter = $this->getRecordFilter();
				if ($wrkFilter != "")
					$wrkFilter .= " OR ";
				$wrkFilter .= $filter;
			} else {
				$wrkFilter = "0=1";
				break;
			}

			// Update row index and get row key
			$rowindex++; // Next row
			$CurrentForm->Index = $rowindex;
			$thisKey = strval($CurrentForm->getValue($this->FormKeyName));
		}
		return $wrkFilter;
	}

	// Set up key values
	protected function setupKeyValues($key)
	{
		$arKeyFlds = explode(Config("COMPOSITE_KEY_SEPARATOR"), $key);
		if (count($arKeyFlds) >= 2) {
			$this->transferID->setOldValue($arKeyFlds[0]);
			if (!is_numeric($this->transferID->OldValue))
				return FALSE;
			$this->txid->setOldValue($arKeyFlds[1]);
		}
		return TRUE;
	}

	// Get list of filters
	public function getFilterList()
	{
		global $UserProfile;

		// Initialize
		$filterList = "";
		$savedFilterList = "";

		// Load server side filters
		if (Config("SEARCH_FILTER_OPTION") == "Server" && isset($UserProfile))
			$savedFilterList = $UserProfile->getSearchFilters(CurrentUserName(), "fvmerchantsaleslistsrch");
		$filterList = Concat($filterList, $this->transferID->AdvancedSearch->toJson(), ","); // Field transferID
		$filterList = Concat($filterList, $this->txid->AdvancedSearch->toJson(), ","); // Field txid
		$filterList = Concat($filterList, $this->merchantID->AdvancedSearch->toJson(), ","); // Field merchantID
		$filterList = Concat($filterList, $this->_userID->AdvancedSearch->toJson(), ","); // Field userID
		$filterList = Concat($filterList, $this->transferTime->AdvancedSearch->toJson(), ","); // Field transferTime
		$filterList = Concat($filterList, $this->status->AdvancedSearch->toJson(), ","); // Field status
		$filterList = Concat($filterList, $this->currID->AdvancedSearch->toJson(), ","); // Field currID
		$filterList = Concat($filterList, $this->TotalAmountForCustomer->AdvancedSearch->toJson(), ","); // Field TotalAmountForCustomer
		$filterList = Concat($filterList, $this->serviceFeeToMerchant->AdvancedSearch->toJson(), ","); // Field serviceFeeToMerchant
		$filterList = Concat($filterList, $this->TotalAmountForMerchant->AdvancedSearch->toJson(), ","); // Field TotalAmountForMerchant
		$filterList = Concat($filterList, $this->userpiid->AdvancedSearch->toJson(), ","); // Field userpiid
		$filterList = Concat($filterList, $this->shoppingCartID->AdvancedSearch->toJson(), ","); // Field shoppingCartID
		$filterList = Concat($filterList, $this->merchantRefID->AdvancedSearch->toJson(), ","); // Field merchantRefID
		$filterList = Concat($filterList, $this->purchaseAmount->AdvancedSearch->toJson(), ","); // Field purchaseAmount
		$filterList = Concat($filterList, $this->taxAmount->AdvancedSearch->toJson(), ","); // Field taxAmount
		$filterList = Concat($filterList, $this->tipAmount->AdvancedSearch->toJson(), ","); // Field tipAmount
		$filterList = Concat($filterList, $this->discountamount->AdvancedSearch->toJson(), ","); // Field discountamount
		$filterList = Concat($filterList, $this->merchantSurcharge->AdvancedSearch->toJson(), ","); // Field merchantSurcharge
		$filterList = Concat($filterList, $this->serviceFeeToCustomer->AdvancedSearch->toJson(), ","); // Field serviceFeeToCustomer
		$filterList = Concat($filterList, $this->feeid->AdvancedSearch->toJson(), ","); // Field feeid
		$filterList = Concat($filterList, $this->ratetabletype->AdvancedSearch->toJson(), ","); // Field ratetabletype
		$filterList = Concat($filterList, $this->pis->AdvancedSearch->toJson(), ","); // Field pis
		$filterList = Concat($filterList, $this->feesystemshare->AdvancedSearch->toJson(), ","); // Field feesystemshare
		$filterList = Concat($filterList, $this->feeexternalshare->AdvancedSearch->toJson(), ","); // Field feeexternalshare
		$filterList = Concat($filterList, $this->feefranchiseeshare->AdvancedSearch->toJson(), ","); // Field feefranchiseeshare
		$filterList = Concat($filterList, $this->feeresellershare->AdvancedSearch->toJson(), ","); // Field feeresellershare
		$filterList = Concat($filterList, $this->lastupdatetime->AdvancedSearch->toJson(), ","); // Field lastupdatetime
		$filterList = Concat($filterList, $this->officialdocnumber->AdvancedSearch->toJson(), ","); // Field officialdocnumber
		$filterList = Concat($filterList, $this->officialdocname->AdvancedSearch->toJson(), ","); // Field officialdocname
		$filterList = Concat($filterList, $this->businessname->AdvancedSearch->toJson(), ","); // Field businessname
		$filterList = Concat($filterList, $this->logofilename->AdvancedSearch->toJson(), ","); // Field logofilename
		$filterList = Concat($filterList, $this->returndays->AdvancedSearch->toJson(), ","); // Field returndays
		$filterList = Concat($filterList, $this->originalpurchaseamount->AdvancedSearch->toJson(), ","); // Field originalpurchaseamount
		$filterList = Concat($filterList, $this->customerpurchaseid->AdvancedSearch->toJson(), ","); // Field customerpurchaseid
		$filterList = Concat($filterList, $this->clerkFirstName->AdvancedSearch->toJson(), ","); // Field clerkFirstName
		$filterList = Concat($filterList, $this->clerkLastName->AdvancedSearch->toJson(), ","); // Field clerkLastName
		$filterList = Concat($filterList, $this->originalMerchantSurcharge->AdvancedSearch->toJson(), ","); // Field originalMerchantSurcharge
		$filterList = Concat($filterList, $this->originalTaxAmount->AdvancedSearch->toJson(), ","); // Field originalTaxAmount
		$filterList = Concat($filterList, $this->originalServiceFeeToCustomer->AdvancedSearch->toJson(), ","); // Field originalServiceFeeToCustomer
		$filterList = Concat($filterList, $this->originalTotalAmountForCustomer->AdvancedSearch->toJson(), ","); // Field originalTotalAmountForCustomer
		$filterList = Concat($filterList, $this->originalServiceFeeToMerchant->AdvancedSearch->toJson(), ","); // Field originalServiceFeeToMerchant
		$filterList = Concat($filterList, $this->originalTipAmount->AdvancedSearch->toJson(), ","); // Field originalTipAmount
		$filterList = Concat($filterList, $this->userpi->AdvancedSearch->toJson(), ","); // Field userpi
		if ($this->BasicSearch->Keyword != "") {
			$wrk = "\"" . Config("TABLE_BASIC_SEARCH") . "\":\"" . JsEncode($this->BasicSearch->Keyword) . "\",\"" . Config("TABLE_BASIC_SEARCH_TYPE") . "\":\"" . JsEncode($this->BasicSearch->Type) . "\"";
			$filterList = Concat($filterList, $wrk, ",");
		}

		// Return filter list in JSON
		if ($filterList != "")
			$filterList = "\"data\":{" . $filterList . "}";
		if ($savedFilterList != "")
			$filterList = Concat($filterList, "\"filters\":" . $savedFilterList, ",");
		return ($filterList != "") ? "{" . $filterList . "}" : "null";
	}

	// Process filter list
	protected function processFilterList()
	{
		global $UserProfile;
		if (Post("ajax") == "savefilters") { // Save filter request (Ajax)
			$filters = Post("filters");
			$UserProfile->setSearchFilters(CurrentUserName(), "fvmerchantsaleslistsrch", $filters);
			WriteJson([["success" => TRUE]]); // Success
			return TRUE;
		} elseif (Post("cmd") == "resetfilter") {
			$this->restoreFilterList();
		}
		return FALSE;
	}

	// Restore list of filters
	protected function restoreFilterList()
	{

		// Return if not reset filter
		if (Post("cmd") !== "resetfilter")
			return FALSE;
		$filter = json_decode(Post("filter"), TRUE);
		$this->Command = "search";

		// Field transferID
		$this->transferID->AdvancedSearch->SearchValue = @$filter["x_transferID"];
		$this->transferID->AdvancedSearch->SearchOperator = @$filter["z_transferID"];
		$this->transferID->AdvancedSearch->SearchCondition = @$filter["v_transferID"];
		$this->transferID->AdvancedSearch->SearchValue2 = @$filter["y_transferID"];
		$this->transferID->AdvancedSearch->SearchOperator2 = @$filter["w_transferID"];
		$this->transferID->AdvancedSearch->save();

		// Field txid
		$this->txid->AdvancedSearch->SearchValue = @$filter["x_txid"];
		$this->txid->AdvancedSearch->SearchOperator = @$filter["z_txid"];
		$this->txid->AdvancedSearch->SearchCondition = @$filter["v_txid"];
		$this->txid->AdvancedSearch->SearchValue2 = @$filter["y_txid"];
		$this->txid->AdvancedSearch->SearchOperator2 = @$filter["w_txid"];
		$this->txid->AdvancedSearch->save();

		// Field merchantID
		$this->merchantID->AdvancedSearch->SearchValue = @$filter["x_merchantID"];
		$this->merchantID->AdvancedSearch->SearchOperator = @$filter["z_merchantID"];
		$this->merchantID->AdvancedSearch->SearchCondition = @$filter["v_merchantID"];
		$this->merchantID->AdvancedSearch->SearchValue2 = @$filter["y_merchantID"];
		$this->merchantID->AdvancedSearch->SearchOperator2 = @$filter["w_merchantID"];
		$this->merchantID->AdvancedSearch->save();

		// Field userID
		$this->_userID->AdvancedSearch->SearchValue = @$filter["x__userID"];
		$this->_userID->AdvancedSearch->SearchOperator = @$filter["z__userID"];
		$this->_userID->AdvancedSearch->SearchCondition = @$filter["v__userID"];
		$this->_userID->AdvancedSearch->SearchValue2 = @$filter["y__userID"];
		$this->_userID->AdvancedSearch->SearchOperator2 = @$filter["w__userID"];
		$this->_userID->AdvancedSearch->save();

		// Field transferTime
		$this->transferTime->AdvancedSearch->SearchValue = @$filter["x_transferTime"];
		$this->transferTime->AdvancedSearch->SearchOperator = @$filter["z_transferTime"];
		$this->transferTime->AdvancedSearch->SearchCondition = @$filter["v_transferTime"];
		$this->transferTime->AdvancedSearch->SearchValue2 = @$filter["y_transferTime"];
		$this->transferTime->AdvancedSearch->SearchOperator2 = @$filter["w_transferTime"];
		$this->transferTime->AdvancedSearch->save();

		// Field status
		$this->status->AdvancedSearch->SearchValue = @$filter["x_status"];
		$this->status->AdvancedSearch->SearchOperator = @$filter["z_status"];
		$this->status->AdvancedSearch->SearchCondition = @$filter["v_status"];
		$this->status->AdvancedSearch->SearchValue2 = @$filter["y_status"];
		$this->status->AdvancedSearch->SearchOperator2 = @$filter["w_status"];
		$this->status->AdvancedSearch->save();

		// Field currID
		$this->currID->AdvancedSearch->SearchValue = @$filter["x_currID"];
		$this->currID->AdvancedSearch->SearchOperator = @$filter["z_currID"];
		$this->currID->AdvancedSearch->SearchCondition = @$filter["v_currID"];
		$this->currID->AdvancedSearch->SearchValue2 = @$filter["y_currID"];
		$this->currID->AdvancedSearch->SearchOperator2 = @$filter["w_currID"];
		$this->currID->AdvancedSearch->save();

		// Field TotalAmountForCustomer
		$this->TotalAmountForCustomer->AdvancedSearch->SearchValue = @$filter["x_TotalAmountForCustomer"];
		$this->TotalAmountForCustomer->AdvancedSearch->SearchOperator = @$filter["z_TotalAmountForCustomer"];
		$this->TotalAmountForCustomer->AdvancedSearch->SearchCondition = @$filter["v_TotalAmountForCustomer"];
		$this->TotalAmountForCustomer->AdvancedSearch->SearchValue2 = @$filter["y_TotalAmountForCustomer"];
		$this->TotalAmountForCustomer->AdvancedSearch->SearchOperator2 = @$filter["w_TotalAmountForCustomer"];
		$this->TotalAmountForCustomer->AdvancedSearch->save();

		// Field serviceFeeToMerchant
		$this->serviceFeeToMerchant->AdvancedSearch->SearchValue = @$filter["x_serviceFeeToMerchant"];
		$this->serviceFeeToMerchant->AdvancedSearch->SearchOperator = @$filter["z_serviceFeeToMerchant"];
		$this->serviceFeeToMerchant->AdvancedSearch->SearchCondition = @$filter["v_serviceFeeToMerchant"];
		$this->serviceFeeToMerchant->AdvancedSearch->SearchValue2 = @$filter["y_serviceFeeToMerchant"];
		$this->serviceFeeToMerchant->AdvancedSearch->SearchOperator2 = @$filter["w_serviceFeeToMerchant"];
		$this->serviceFeeToMerchant->AdvancedSearch->save();

		// Field TotalAmountForMerchant
		$this->TotalAmountForMerchant->AdvancedSearch->SearchValue = @$filter["x_TotalAmountForMerchant"];
		$this->TotalAmountForMerchant->AdvancedSearch->SearchOperator = @$filter["z_TotalAmountForMerchant"];
		$this->TotalAmountForMerchant->AdvancedSearch->SearchCondition = @$filter["v_TotalAmountForMerchant"];
		$this->TotalAmountForMerchant->AdvancedSearch->SearchValue2 = @$filter["y_TotalAmountForMerchant"];
		$this->TotalAmountForMerchant->AdvancedSearch->SearchOperator2 = @$filter["w_TotalAmountForMerchant"];
		$this->TotalAmountForMerchant->AdvancedSearch->save();

		// Field userpiid
		$this->userpiid->AdvancedSearch->SearchValue = @$filter["x_userpiid"];
		$this->userpiid->AdvancedSearch->SearchOperator = @$filter["z_userpiid"];
		$this->userpiid->AdvancedSearch->SearchCondition = @$filter["v_userpiid"];
		$this->userpiid->AdvancedSearch->SearchValue2 = @$filter["y_userpiid"];
		$this->userpiid->AdvancedSearch->SearchOperator2 = @$filter["w_userpiid"];
		$this->userpiid->AdvancedSearch->save();

		// Field shoppingCartID
		$this->shoppingCartID->AdvancedSearch->SearchValue = @$filter["x_shoppingCartID"];
		$this->shoppingCartID->AdvancedSearch->SearchOperator = @$filter["z_shoppingCartID"];
		$this->shoppingCartID->AdvancedSearch->SearchCondition = @$filter["v_shoppingCartID"];
		$this->shoppingCartID->AdvancedSearch->SearchValue2 = @$filter["y_shoppingCartID"];
		$this->shoppingCartID->AdvancedSearch->SearchOperator2 = @$filter["w_shoppingCartID"];
		$this->shoppingCartID->AdvancedSearch->save();

		// Field merchantRefID
		$this->merchantRefID->AdvancedSearch->SearchValue = @$filter["x_merchantRefID"];
		$this->merchantRefID->AdvancedSearch->SearchOperator = @$filter["z_merchantRefID"];
		$this->merchantRefID->AdvancedSearch->SearchCondition = @$filter["v_merchantRefID"];
		$this->merchantRefID->AdvancedSearch->SearchValue2 = @$filter["y_merchantRefID"];
		$this->merchantRefID->AdvancedSearch->SearchOperator2 = @$filter["w_merchantRefID"];
		$this->merchantRefID->AdvancedSearch->save();

		// Field purchaseAmount
		$this->purchaseAmount->AdvancedSearch->SearchValue = @$filter["x_purchaseAmount"];
		$this->purchaseAmount->AdvancedSearch->SearchOperator = @$filter["z_purchaseAmount"];
		$this->purchaseAmount->AdvancedSearch->SearchCondition = @$filter["v_purchaseAmount"];
		$this->purchaseAmount->AdvancedSearch->SearchValue2 = @$filter["y_purchaseAmount"];
		$this->purchaseAmount->AdvancedSearch->SearchOperator2 = @$filter["w_purchaseAmount"];
		$this->purchaseAmount->AdvancedSearch->save();

		// Field taxAmount
		$this->taxAmount->AdvancedSearch->SearchValue = @$filter["x_taxAmount"];
		$this->taxAmount->AdvancedSearch->SearchOperator = @$filter["z_taxAmount"];
		$this->taxAmount->AdvancedSearch->SearchCondition = @$filter["v_taxAmount"];
		$this->taxAmount->AdvancedSearch->SearchValue2 = @$filter["y_taxAmount"];
		$this->taxAmount->AdvancedSearch->SearchOperator2 = @$filter["w_taxAmount"];
		$this->taxAmount->AdvancedSearch->save();

		// Field tipAmount
		$this->tipAmount->AdvancedSearch->SearchValue = @$filter["x_tipAmount"];
		$this->tipAmount->AdvancedSearch->SearchOperator = @$filter["z_tipAmount"];
		$this->tipAmount->AdvancedSearch->SearchCondition = @$filter["v_tipAmount"];
		$this->tipAmount->AdvancedSearch->SearchValue2 = @$filter["y_tipAmount"];
		$this->tipAmount->AdvancedSearch->SearchOperator2 = @$filter["w_tipAmount"];
		$this->tipAmount->AdvancedSearch->save();

		// Field discountamount
		$this->discountamount->AdvancedSearch->SearchValue = @$filter["x_discountamount"];
		$this->discountamount->AdvancedSearch->SearchOperator = @$filter["z_discountamount"];
		$this->discountamount->AdvancedSearch->SearchCondition = @$filter["v_discountamount"];
		$this->discountamount->AdvancedSearch->SearchValue2 = @$filter["y_discountamount"];
		$this->discountamount->AdvancedSearch->SearchOperator2 = @$filter["w_discountamount"];
		$this->discountamount->AdvancedSearch->save();

		// Field merchantSurcharge
		$this->merchantSurcharge->AdvancedSearch->SearchValue = @$filter["x_merchantSurcharge"];
		$this->merchantSurcharge->AdvancedSearch->SearchOperator = @$filter["z_merchantSurcharge"];
		$this->merchantSurcharge->AdvancedSearch->SearchCondition = @$filter["v_merchantSurcharge"];
		$this->merchantSurcharge->AdvancedSearch->SearchValue2 = @$filter["y_merchantSurcharge"];
		$this->merchantSurcharge->AdvancedSearch->SearchOperator2 = @$filter["w_merchantSurcharge"];
		$this->merchantSurcharge->AdvancedSearch->save();

		// Field serviceFeeToCustomer
		$this->serviceFeeToCustomer->AdvancedSearch->SearchValue = @$filter["x_serviceFeeToCustomer"];
		$this->serviceFeeToCustomer->AdvancedSearch->SearchOperator = @$filter["z_serviceFeeToCustomer"];
		$this->serviceFeeToCustomer->AdvancedSearch->SearchCondition = @$filter["v_serviceFeeToCustomer"];
		$this->serviceFeeToCustomer->AdvancedSearch->SearchValue2 = @$filter["y_serviceFeeToCustomer"];
		$this->serviceFeeToCustomer->AdvancedSearch->SearchOperator2 = @$filter["w_serviceFeeToCustomer"];
		$this->serviceFeeToCustomer->AdvancedSearch->save();

		// Field feeid
		$this->feeid->AdvancedSearch->SearchValue = @$filter["x_feeid"];
		$this->feeid->AdvancedSearch->SearchOperator = @$filter["z_feeid"];
		$this->feeid->AdvancedSearch->SearchCondition = @$filter["v_feeid"];
		$this->feeid->AdvancedSearch->SearchValue2 = @$filter["y_feeid"];
		$this->feeid->AdvancedSearch->SearchOperator2 = @$filter["w_feeid"];
		$this->feeid->AdvancedSearch->save();

		// Field ratetabletype
		$this->ratetabletype->AdvancedSearch->SearchValue = @$filter["x_ratetabletype"];
		$this->ratetabletype->AdvancedSearch->SearchOperator = @$filter["z_ratetabletype"];
		$this->ratetabletype->AdvancedSearch->SearchCondition = @$filter["v_ratetabletype"];
		$this->ratetabletype->AdvancedSearch->SearchValue2 = @$filter["y_ratetabletype"];
		$this->ratetabletype->AdvancedSearch->SearchOperator2 = @$filter["w_ratetabletype"];
		$this->ratetabletype->AdvancedSearch->save();

		// Field pis
		$this->pis->AdvancedSearch->SearchValue = @$filter["x_pis"];
		$this->pis->AdvancedSearch->SearchOperator = @$filter["z_pis"];
		$this->pis->AdvancedSearch->SearchCondition = @$filter["v_pis"];
		$this->pis->AdvancedSearch->SearchValue2 = @$filter["y_pis"];
		$this->pis->AdvancedSearch->SearchOperator2 = @$filter["w_pis"];
		$this->pis->AdvancedSearch->save();

		// Field feesystemshare
		$this->feesystemshare->AdvancedSearch->SearchValue = @$filter["x_feesystemshare"];
		$this->feesystemshare->AdvancedSearch->SearchOperator = @$filter["z_feesystemshare"];
		$this->feesystemshare->AdvancedSearch->SearchCondition = @$filter["v_feesystemshare"];
		$this->feesystemshare->AdvancedSearch->SearchValue2 = @$filter["y_feesystemshare"];
		$this->feesystemshare->AdvancedSearch->SearchOperator2 = @$filter["w_feesystemshare"];
		$this->feesystemshare->AdvancedSearch->save();

		// Field feeexternalshare
		$this->feeexternalshare->AdvancedSearch->SearchValue = @$filter["x_feeexternalshare"];
		$this->feeexternalshare->AdvancedSearch->SearchOperator = @$filter["z_feeexternalshare"];
		$this->feeexternalshare->AdvancedSearch->SearchCondition = @$filter["v_feeexternalshare"];
		$this->feeexternalshare->AdvancedSearch->SearchValue2 = @$filter["y_feeexternalshare"];
		$this->feeexternalshare->AdvancedSearch->SearchOperator2 = @$filter["w_feeexternalshare"];
		$this->feeexternalshare->AdvancedSearch->save();

		// Field feefranchiseeshare
		$this->feefranchiseeshare->AdvancedSearch->SearchValue = @$filter["x_feefranchiseeshare"];
		$this->feefranchiseeshare->AdvancedSearch->SearchOperator = @$filter["z_feefranchiseeshare"];
		$this->feefranchiseeshare->AdvancedSearch->SearchCondition = @$filter["v_feefranchiseeshare"];
		$this->feefranchiseeshare->AdvancedSearch->SearchValue2 = @$filter["y_feefranchiseeshare"];
		$this->feefranchiseeshare->AdvancedSearch->SearchOperator2 = @$filter["w_feefranchiseeshare"];
		$this->feefranchiseeshare->AdvancedSearch->save();

		// Field feeresellershare
		$this->feeresellershare->AdvancedSearch->SearchValue = @$filter["x_feeresellershare"];
		$this->feeresellershare->AdvancedSearch->SearchOperator = @$filter["z_feeresellershare"];
		$this->feeresellershare->AdvancedSearch->SearchCondition = @$filter["v_feeresellershare"];
		$this->feeresellershare->AdvancedSearch->SearchValue2 = @$filter["y_feeresellershare"];
		$this->feeresellershare->AdvancedSearch->SearchOperator2 = @$filter["w_feeresellershare"];
		$this->feeresellershare->AdvancedSearch->save();

		// Field lastupdatetime
		$this->lastupdatetime->AdvancedSearch->SearchValue = @$filter["x_lastupdatetime"];
		$this->lastupdatetime->AdvancedSearch->SearchOperator = @$filter["z_lastupdatetime"];
		$this->lastupdatetime->AdvancedSearch->SearchCondition = @$filter["v_lastupdatetime"];
		$this->lastupdatetime->AdvancedSearch->SearchValue2 = @$filter["y_lastupdatetime"];
		$this->lastupdatetime->AdvancedSearch->SearchOperator2 = @$filter["w_lastupdatetime"];
		$this->lastupdatetime->AdvancedSearch->save();

		// Field officialdocnumber
		$this->officialdocnumber->AdvancedSearch->SearchValue = @$filter["x_officialdocnumber"];
		$this->officialdocnumber->AdvancedSearch->SearchOperator = @$filter["z_officialdocnumber"];
		$this->officialdocnumber->AdvancedSearch->SearchCondition = @$filter["v_officialdocnumber"];
		$this->officialdocnumber->AdvancedSearch->SearchValue2 = @$filter["y_officialdocnumber"];
		$this->officialdocnumber->AdvancedSearch->SearchOperator2 = @$filter["w_officialdocnumber"];
		$this->officialdocnumber->AdvancedSearch->save();

		// Field officialdocname
		$this->officialdocname->AdvancedSearch->SearchValue = @$filter["x_officialdocname"];
		$this->officialdocname->AdvancedSearch->SearchOperator = @$filter["z_officialdocname"];
		$this->officialdocname->AdvancedSearch->SearchCondition = @$filter["v_officialdocname"];
		$this->officialdocname->AdvancedSearch->SearchValue2 = @$filter["y_officialdocname"];
		$this->officialdocname->AdvancedSearch->SearchOperator2 = @$filter["w_officialdocname"];
		$this->officialdocname->AdvancedSearch->save();

		// Field businessname
		$this->businessname->AdvancedSearch->SearchValue = @$filter["x_businessname"];
		$this->businessname->AdvancedSearch->SearchOperator = @$filter["z_businessname"];
		$this->businessname->AdvancedSearch->SearchCondition = @$filter["v_businessname"];
		$this->businessname->AdvancedSearch->SearchValue2 = @$filter["y_businessname"];
		$this->businessname->AdvancedSearch->SearchOperator2 = @$filter["w_businessname"];
		$this->businessname->AdvancedSearch->save();

		// Field logofilename
		$this->logofilename->AdvancedSearch->SearchValue = @$filter["x_logofilename"];
		$this->logofilename->AdvancedSearch->SearchOperator = @$filter["z_logofilename"];
		$this->logofilename->AdvancedSearch->SearchCondition = @$filter["v_logofilename"];
		$this->logofilename->AdvancedSearch->SearchValue2 = @$filter["y_logofilename"];
		$this->logofilename->AdvancedSearch->SearchOperator2 = @$filter["w_logofilename"];
		$this->logofilename->AdvancedSearch->save();

		// Field returndays
		$this->returndays->AdvancedSearch->SearchValue = @$filter["x_returndays"];
		$this->returndays->AdvancedSearch->SearchOperator = @$filter["z_returndays"];
		$this->returndays->AdvancedSearch->SearchCondition = @$filter["v_returndays"];
		$this->returndays->AdvancedSearch->SearchValue2 = @$filter["y_returndays"];
		$this->returndays->AdvancedSearch->SearchOperator2 = @$filter["w_returndays"];
		$this->returndays->AdvancedSearch->save();

		// Field originalpurchaseamount
		$this->originalpurchaseamount->AdvancedSearch->SearchValue = @$filter["x_originalpurchaseamount"];
		$this->originalpurchaseamount->AdvancedSearch->SearchOperator = @$filter["z_originalpurchaseamount"];
		$this->originalpurchaseamount->AdvancedSearch->SearchCondition = @$filter["v_originalpurchaseamount"];
		$this->originalpurchaseamount->AdvancedSearch->SearchValue2 = @$filter["y_originalpurchaseamount"];
		$this->originalpurchaseamount->AdvancedSearch->SearchOperator2 = @$filter["w_originalpurchaseamount"];
		$this->originalpurchaseamount->AdvancedSearch->save();

		// Field customerpurchaseid
		$this->customerpurchaseid->AdvancedSearch->SearchValue = @$filter["x_customerpurchaseid"];
		$this->customerpurchaseid->AdvancedSearch->SearchOperator = @$filter["z_customerpurchaseid"];
		$this->customerpurchaseid->AdvancedSearch->SearchCondition = @$filter["v_customerpurchaseid"];
		$this->customerpurchaseid->AdvancedSearch->SearchValue2 = @$filter["y_customerpurchaseid"];
		$this->customerpurchaseid->AdvancedSearch->SearchOperator2 = @$filter["w_customerpurchaseid"];
		$this->customerpurchaseid->AdvancedSearch->save();

		// Field clerkFirstName
		$this->clerkFirstName->AdvancedSearch->SearchValue = @$filter["x_clerkFirstName"];
		$this->clerkFirstName->AdvancedSearch->SearchOperator = @$filter["z_clerkFirstName"];
		$this->clerkFirstName->AdvancedSearch->SearchCondition = @$filter["v_clerkFirstName"];
		$this->clerkFirstName->AdvancedSearch->SearchValue2 = @$filter["y_clerkFirstName"];
		$this->clerkFirstName->AdvancedSearch->SearchOperator2 = @$filter["w_clerkFirstName"];
		$this->clerkFirstName->AdvancedSearch->save();

		// Field clerkLastName
		$this->clerkLastName->AdvancedSearch->SearchValue = @$filter["x_clerkLastName"];
		$this->clerkLastName->AdvancedSearch->SearchOperator = @$filter["z_clerkLastName"];
		$this->clerkLastName->AdvancedSearch->SearchCondition = @$filter["v_clerkLastName"];
		$this->clerkLastName->AdvancedSearch->SearchValue2 = @$filter["y_clerkLastName"];
		$this->clerkLastName->AdvancedSearch->SearchOperator2 = @$filter["w_clerkLastName"];
		$this->clerkLastName->AdvancedSearch->save();

		// Field originalMerchantSurcharge
		$this->originalMerchantSurcharge->AdvancedSearch->SearchValue = @$filter["x_originalMerchantSurcharge"];
		$this->originalMerchantSurcharge->AdvancedSearch->SearchOperator = @$filter["z_originalMerchantSurcharge"];
		$this->originalMerchantSurcharge->AdvancedSearch->SearchCondition = @$filter["v_originalMerchantSurcharge"];
		$this->originalMerchantSurcharge->AdvancedSearch->SearchValue2 = @$filter["y_originalMerchantSurcharge"];
		$this->originalMerchantSurcharge->AdvancedSearch->SearchOperator2 = @$filter["w_originalMerchantSurcharge"];
		$this->originalMerchantSurcharge->AdvancedSearch->save();

		// Field originalTaxAmount
		$this->originalTaxAmount->AdvancedSearch->SearchValue = @$filter["x_originalTaxAmount"];
		$this->originalTaxAmount->AdvancedSearch->SearchOperator = @$filter["z_originalTaxAmount"];
		$this->originalTaxAmount->AdvancedSearch->SearchCondition = @$filter["v_originalTaxAmount"];
		$this->originalTaxAmount->AdvancedSearch->SearchValue2 = @$filter["y_originalTaxAmount"];
		$this->originalTaxAmount->AdvancedSearch->SearchOperator2 = @$filter["w_originalTaxAmount"];
		$this->originalTaxAmount->AdvancedSearch->save();

		// Field originalServiceFeeToCustomer
		$this->originalServiceFeeToCustomer->AdvancedSearch->SearchValue = @$filter["x_originalServiceFeeToCustomer"];
		$this->originalServiceFeeToCustomer->AdvancedSearch->SearchOperator = @$filter["z_originalServiceFeeToCustomer"];
		$this->originalServiceFeeToCustomer->AdvancedSearch->SearchCondition = @$filter["v_originalServiceFeeToCustomer"];
		$this->originalServiceFeeToCustomer->AdvancedSearch->SearchValue2 = @$filter["y_originalServiceFeeToCustomer"];
		$this->originalServiceFeeToCustomer->AdvancedSearch->SearchOperator2 = @$filter["w_originalServiceFeeToCustomer"];
		$this->originalServiceFeeToCustomer->AdvancedSearch->save();

		// Field originalTotalAmountForCustomer
		$this->originalTotalAmountForCustomer->AdvancedSearch->SearchValue = @$filter["x_originalTotalAmountForCustomer"];
		$this->originalTotalAmountForCustomer->AdvancedSearch->SearchOperator = @$filter["z_originalTotalAmountForCustomer"];
		$this->originalTotalAmountForCustomer->AdvancedSearch->SearchCondition = @$filter["v_originalTotalAmountForCustomer"];
		$this->originalTotalAmountForCustomer->AdvancedSearch->SearchValue2 = @$filter["y_originalTotalAmountForCustomer"];
		$this->originalTotalAmountForCustomer->AdvancedSearch->SearchOperator2 = @$filter["w_originalTotalAmountForCustomer"];
		$this->originalTotalAmountForCustomer->AdvancedSearch->save();

		// Field originalServiceFeeToMerchant
		$this->originalServiceFeeToMerchant->AdvancedSearch->SearchValue = @$filter["x_originalServiceFeeToMerchant"];
		$this->originalServiceFeeToMerchant->AdvancedSearch->SearchOperator = @$filter["z_originalServiceFeeToMerchant"];
		$this->originalServiceFeeToMerchant->AdvancedSearch->SearchCondition = @$filter["v_originalServiceFeeToMerchant"];
		$this->originalServiceFeeToMerchant->AdvancedSearch->SearchValue2 = @$filter["y_originalServiceFeeToMerchant"];
		$this->originalServiceFeeToMerchant->AdvancedSearch->SearchOperator2 = @$filter["w_originalServiceFeeToMerchant"];
		$this->originalServiceFeeToMerchant->AdvancedSearch->save();

		// Field originalTipAmount
		$this->originalTipAmount->AdvancedSearch->SearchValue = @$filter["x_originalTipAmount"];
		$this->originalTipAmount->AdvancedSearch->SearchOperator = @$filter["z_originalTipAmount"];
		$this->originalTipAmount->AdvancedSearch->SearchCondition = @$filter["v_originalTipAmount"];
		$this->originalTipAmount->AdvancedSearch->SearchValue2 = @$filter["y_originalTipAmount"];
		$this->originalTipAmount->AdvancedSearch->SearchOperator2 = @$filter["w_originalTipAmount"];
		$this->originalTipAmount->AdvancedSearch->save();

		// Field userpi
		$this->userpi->AdvancedSearch->SearchValue = @$filter["x_userpi"];
		$this->userpi->AdvancedSearch->SearchOperator = @$filter["z_userpi"];
		$this->userpi->AdvancedSearch->SearchCondition = @$filter["v_userpi"];
		$this->userpi->AdvancedSearch->SearchValue2 = @$filter["y_userpi"];
		$this->userpi->AdvancedSearch->SearchOperator2 = @$filter["w_userpi"];
		$this->userpi->AdvancedSearch->save();
		$this->BasicSearch->setKeyword(@$filter[Config("TABLE_BASIC_SEARCH")]);
		$this->BasicSearch->setType(@$filter[Config("TABLE_BASIC_SEARCH_TYPE")]);
	}

	// Advanced search WHERE clause based on QueryString
	protected function advancedSearchWhere($default = FALSE)
	{
		global $Security;
		$where = "";
		if (!$Security->canSearch())
			return "";
		$this->buildSearchSql($where, $this->transferID, $default, FALSE); // transferID
		$this->buildSearchSql($where, $this->txid, $default, FALSE); // txid
		$this->buildSearchSql($where, $this->merchantID, $default, FALSE); // merchantID
		$this->buildSearchSql($where, $this->_userID, $default, FALSE); // userID
		$this->buildSearchSql($where, $this->transferTime, $default, FALSE); // transferTime
		$this->buildSearchSql($where, $this->status, $default, FALSE); // status
		$this->buildSearchSql($where, $this->currID, $default, FALSE); // currID
		$this->buildSearchSql($where, $this->TotalAmountForCustomer, $default, FALSE); // TotalAmountForCustomer
		$this->buildSearchSql($where, $this->serviceFeeToMerchant, $default, FALSE); // serviceFeeToMerchant
		$this->buildSearchSql($where, $this->TotalAmountForMerchant, $default, FALSE); // TotalAmountForMerchant
		$this->buildSearchSql($where, $this->userpiid, $default, FALSE); // userpiid
		$this->buildSearchSql($where, $this->shoppingCartID, $default, FALSE); // shoppingCartID
		$this->buildSearchSql($where, $this->merchantRefID, $default, FALSE); // merchantRefID
		$this->buildSearchSql($where, $this->purchaseAmount, $default, FALSE); // purchaseAmount
		$this->buildSearchSql($where, $this->taxAmount, $default, FALSE); // taxAmount
		$this->buildSearchSql($where, $this->tipAmount, $default, FALSE); // tipAmount
		$this->buildSearchSql($where, $this->discountamount, $default, FALSE); // discountamount
		$this->buildSearchSql($where, $this->merchantSurcharge, $default, FALSE); // merchantSurcharge
		$this->buildSearchSql($where, $this->serviceFeeToCustomer, $default, FALSE); // serviceFeeToCustomer
		$this->buildSearchSql($where, $this->feeid, $default, FALSE); // feeid
		$this->buildSearchSql($where, $this->ratetabletype, $default, FALSE); // ratetabletype
		$this->buildSearchSql($where, $this->pis, $default, FALSE); // pis
		$this->buildSearchSql($where, $this->feesystemshare, $default, FALSE); // feesystemshare
		$this->buildSearchSql($where, $this->feeexternalshare, $default, FALSE); // feeexternalshare
		$this->buildSearchSql($where, $this->feefranchiseeshare, $default, FALSE); // feefranchiseeshare
		$this->buildSearchSql($where, $this->feeresellershare, $default, FALSE); // feeresellershare
		$this->buildSearchSql($where, $this->lastupdatetime, $default, FALSE); // lastupdatetime
		$this->buildSearchSql($where, $this->officialdocnumber, $default, FALSE); // officialdocnumber
		$this->buildSearchSql($where, $this->officialdocname, $default, FALSE); // officialdocname
		$this->buildSearchSql($where, $this->businessname, $default, FALSE); // businessname
		$this->buildSearchSql($where, $this->logofilename, $default, FALSE); // logofilename
		$this->buildSearchSql($where, $this->returndays, $default, FALSE); // returndays
		$this->buildSearchSql($where, $this->originalpurchaseamount, $default, FALSE); // originalpurchaseamount
		$this->buildSearchSql($where, $this->customerpurchaseid, $default, FALSE); // customerpurchaseid
		$this->buildSearchSql($where, $this->clerkFirstName, $default, FALSE); // clerkFirstName
		$this->buildSearchSql($where, $this->clerkLastName, $default, FALSE); // clerkLastName
		$this->buildSearchSql($where, $this->originalMerchantSurcharge, $default, FALSE); // originalMerchantSurcharge
		$this->buildSearchSql($where, $this->originalTaxAmount, $default, FALSE); // originalTaxAmount
		$this->buildSearchSql($where, $this->originalServiceFeeToCustomer, $default, FALSE); // originalServiceFeeToCustomer
		$this->buildSearchSql($where, $this->originalTotalAmountForCustomer, $default, FALSE); // originalTotalAmountForCustomer
		$this->buildSearchSql($where, $this->originalServiceFeeToMerchant, $default, FALSE); // originalServiceFeeToMerchant
		$this->buildSearchSql($where, $this->originalTipAmount, $default, FALSE); // originalTipAmount
		$this->buildSearchSql($where, $this->userpi, $default, FALSE); // userpi

		// Set up search parm
		if (!$default && $where != "" && in_array($this->Command, ["", "reset", "resetall"])) {
			$this->Command = "search";
		}
		if (!$default && $this->Command == "search") {
			$this->transferID->AdvancedSearch->save(); // transferID
			$this->txid->AdvancedSearch->save(); // txid
			$this->merchantID->AdvancedSearch->save(); // merchantID
			$this->_userID->AdvancedSearch->save(); // userID
			$this->transferTime->AdvancedSearch->save(); // transferTime
			$this->status->AdvancedSearch->save(); // status
			$this->currID->AdvancedSearch->save(); // currID
			$this->TotalAmountForCustomer->AdvancedSearch->save(); // TotalAmountForCustomer
			$this->serviceFeeToMerchant->AdvancedSearch->save(); // serviceFeeToMerchant
			$this->TotalAmountForMerchant->AdvancedSearch->save(); // TotalAmountForMerchant
			$this->userpiid->AdvancedSearch->save(); // userpiid
			$this->shoppingCartID->AdvancedSearch->save(); // shoppingCartID
			$this->merchantRefID->AdvancedSearch->save(); // merchantRefID
			$this->purchaseAmount->AdvancedSearch->save(); // purchaseAmount
			$this->taxAmount->AdvancedSearch->save(); // taxAmount
			$this->tipAmount->AdvancedSearch->save(); // tipAmount
			$this->discountamount->AdvancedSearch->save(); // discountamount
			$this->merchantSurcharge->AdvancedSearch->save(); // merchantSurcharge
			$this->serviceFeeToCustomer->AdvancedSearch->save(); // serviceFeeToCustomer
			$this->feeid->AdvancedSearch->save(); // feeid
			$this->ratetabletype->AdvancedSearch->save(); // ratetabletype
			$this->pis->AdvancedSearch->save(); // pis
			$this->feesystemshare->AdvancedSearch->save(); // feesystemshare
			$this->feeexternalshare->AdvancedSearch->save(); // feeexternalshare
			$this->feefranchiseeshare->AdvancedSearch->save(); // feefranchiseeshare
			$this->feeresellershare->AdvancedSearch->save(); // feeresellershare
			$this->lastupdatetime->AdvancedSearch->save(); // lastupdatetime
			$this->officialdocnumber->AdvancedSearch->save(); // officialdocnumber
			$this->officialdocname->AdvancedSearch->save(); // officialdocname
			$this->businessname->AdvancedSearch->save(); // businessname
			$this->logofilename->AdvancedSearch->save(); // logofilename
			$this->returndays->AdvancedSearch->save(); // returndays
			$this->originalpurchaseamount->AdvancedSearch->save(); // originalpurchaseamount
			$this->customerpurchaseid->AdvancedSearch->save(); // customerpurchaseid
			$this->clerkFirstName->AdvancedSearch->save(); // clerkFirstName
			$this->clerkLastName->AdvancedSearch->save(); // clerkLastName
			$this->originalMerchantSurcharge->AdvancedSearch->save(); // originalMerchantSurcharge
			$this->originalTaxAmount->AdvancedSearch->save(); // originalTaxAmount
			$this->originalServiceFeeToCustomer->AdvancedSearch->save(); // originalServiceFeeToCustomer
			$this->originalTotalAmountForCustomer->AdvancedSearch->save(); // originalTotalAmountForCustomer
			$this->originalServiceFeeToMerchant->AdvancedSearch->save(); // originalServiceFeeToMerchant
			$this->originalTipAmount->AdvancedSearch->save(); // originalTipAmount
			$this->userpi->AdvancedSearch->save(); // userpi
		}
		return $where;
	}

	// Build search SQL
	protected function buildSearchSql(&$where, &$fld, $default, $multiValue)
	{
		$fldParm = $fld->Param;
		$fldVal = ($default) ? $fld->AdvancedSearch->SearchValueDefault : $fld->AdvancedSearch->SearchValue;
		$fldOpr = ($default) ? $fld->AdvancedSearch->SearchOperatorDefault : $fld->AdvancedSearch->SearchOperator;
		$fldCond = ($default) ? $fld->AdvancedSearch->SearchConditionDefault : $fld->AdvancedSearch->SearchCondition;
		$fldVal2 = ($default) ? $fld->AdvancedSearch->SearchValue2Default : $fld->AdvancedSearch->SearchValue2;
		$fldOpr2 = ($default) ? $fld->AdvancedSearch->SearchOperator2Default : $fld->AdvancedSearch->SearchOperator2;
		$wrk = "";
		if (is_array($fldVal))
			$fldVal = implode(Config("MULTIPLE_OPTION_SEPARATOR"), $fldVal);
		if (is_array($fldVal2))
			$fldVal2 = implode(Config("MULTIPLE_OPTION_SEPARATOR"), $fldVal2);
		$fldOpr = strtoupper(trim($fldOpr));
		if ($fldOpr == "")
			$fldOpr = "=";
		$fldOpr2 = strtoupper(trim($fldOpr2));
		if ($fldOpr2 == "")
			$fldOpr2 = "=";
		if (Config("SEARCH_MULTI_VALUE_OPTION") == 1 || !IsMultiSearchOperator($fldOpr))
			$multiValue = FALSE;
		if ($multiValue) {
			$wrk1 = ($fldVal != "") ? GetMultiSearchSql($fld, $fldOpr, $fldVal, $this->Dbid) : ""; // Field value 1
			$wrk2 = ($fldVal2 != "") ? GetMultiSearchSql($fld, $fldOpr2, $fldVal2, $this->Dbid) : ""; // Field value 2
			$wrk = $wrk1; // Build final SQL
			if ($wrk2 != "")
				$wrk = ($wrk != "") ? "($wrk) $fldCond ($wrk2)" : $wrk2;
		} else {
			$fldVal = $this->convertSearchValue($fld, $fldVal);
			$fldVal2 = $this->convertSearchValue($fld, $fldVal2);
			$wrk = GetSearchSql($fld, $fldVal, $fldOpr, $fldCond, $fldVal2, $fldOpr2, $this->Dbid);
		}
		AddFilter($where, $wrk);
	}

	// Convert search value
	protected function convertSearchValue(&$fld, $fldVal)
	{
		if ($fldVal == Config("NULL_VALUE") || $fldVal == Config("NOT_NULL_VALUE"))
			return $fldVal;
		$value = $fldVal;
		if ($fld->isBoolean()) {
			if ($fldVal != "")
				$value = (SameText($fldVal, "1") || SameText($fldVal, "y") || SameText($fldVal, "t")) ? $fld->TrueValue : $fld->FalseValue;
		} elseif ($fld->DataType == DATATYPE_DATE || $fld->DataType == DATATYPE_TIME) {
			if ($fldVal != "")
				$value = UnFormatDateTime($fldVal, $fld->DateTimeFormat);
		}
		return $value;
	}

	// Return basic search SQL
	protected function basicSearchSql($arKeywords, $type)
	{
		$where = "";
		$this->buildBasicSearchSql($where, $this->txid, $arKeywords, $type);
		$this->buildBasicSearchSql($where, $this->currID, $arKeywords, $type);
		$this->buildBasicSearchSql($where, $this->shoppingCartID, $arKeywords, $type);
		$this->buildBasicSearchSql($where, $this->merchantRefID, $arKeywords, $type);
		$this->buildBasicSearchSql($where, $this->pis, $arKeywords, $type);
		$this->buildBasicSearchSql($where, $this->officialdocnumber, $arKeywords, $type);
		$this->buildBasicSearchSql($where, $this->officialdocname, $arKeywords, $type);
		$this->buildBasicSearchSql($where, $this->businessname, $arKeywords, $type);
		$this->buildBasicSearchSql($where, $this->logofilename, $arKeywords, $type);
		$this->buildBasicSearchSql($where, $this->clerkFirstName, $arKeywords, $type);
		$this->buildBasicSearchSql($where, $this->clerkLastName, $arKeywords, $type);
		return $where;
	}

	// Build basic search SQL
	protected function buildBasicSearchSql(&$where, &$fld, $arKeywords, $type)
	{
		$defCond = ($type == "OR") ? "OR" : "AND";
		$arSql = []; // Array for SQL parts
		$arCond = []; // Array for search conditions
		$cnt = count($arKeywords);
		$j = 0; // Number of SQL parts
		for ($i = 0; $i < $cnt; $i++) {
			$keyword = $arKeywords[$i];
			$keyword = trim($keyword);
			if (Config("BASIC_SEARCH_IGNORE_PATTERN") != "") {
				$keyword = preg_replace(Config("BASIC_SEARCH_IGNORE_PATTERN"), "\\", $keyword);
				$ar = explode("\\", $keyword);
			} else {
				$ar = [$keyword];
			}
			foreach ($ar as $keyword) {
				if ($keyword != "") {
					$wrk = "";
					if ($keyword == "OR" && $type == "") {
						if ($j > 0)
							$arCond[$j - 1] = "OR";
					} elseif ($keyword == Config("NULL_VALUE")) {
						$wrk = $fld->Expression . " IS NULL";
					} elseif ($keyword == Config("NOT_NULL_VALUE")) {
						$wrk = $fld->Expression . " IS NOT NULL";
					} elseif ($fld->IsVirtual) {
						$wrk = $fld->VirtualExpression . Like(QuotedValue("%" . $keyword . "%", DATATYPE_STRING, $this->Dbid), $this->Dbid);
					} elseif ($fld->DataType != DATATYPE_NUMBER || is_numeric($keyword)) {
						$wrk = $fld->BasicSearchExpression . Like(QuotedValue("%" . $keyword . "%", DATATYPE_STRING, $this->Dbid), $this->Dbid);
					}
					if ($wrk != "") {
						$arSql[$j] = $wrk;
						$arCond[$j] = $defCond;
						$j += 1;
					}
				}
			}
		}
		$cnt = count($arSql);
		$quoted = FALSE;
		$sql = "";
		if ($cnt > 0) {
			for ($i = 0; $i < $cnt - 1; $i++) {
				if ($arCond[$i] == "OR") {
					if (!$quoted)
						$sql .= "(";
					$quoted = TRUE;
				}
				$sql .= $arSql[$i];
				if ($quoted && $arCond[$i] != "OR") {
					$sql .= ")";
					$quoted = FALSE;
				}
				$sql .= " " . $arCond[$i] . " ";
			}
			$sql .= $arSql[$cnt - 1];
			if ($quoted)
				$sql .= ")";
		}
		if ($sql != "") {
			if ($where != "")
				$where .= " OR ";
			$where .= "(" . $sql . ")";
		}
	}

	// Return basic search WHERE clause based on search keyword and type
	protected function basicSearchWhere($default = FALSE)
	{
		global $Security;
		$searchStr = "";
		if (!$Security->canSearch())
			return "";
		$searchKeyword = ($default) ? $this->BasicSearch->KeywordDefault : $this->BasicSearch->Keyword;
		$searchType = ($default) ? $this->BasicSearch->TypeDefault : $this->BasicSearch->Type;

		// Get search SQL
		if ($searchKeyword != "") {
			$ar = $this->BasicSearch->keywordList($default);

			// Search keyword in any fields
			if (($searchType == "OR" || $searchType == "AND") && $this->BasicSearch->BasicSearchAnyFields) {
				foreach ($ar as $keyword) {
					if ($keyword != "") {
						if ($searchStr != "")
							$searchStr .= " " . $searchType . " ";
						$searchStr .= "(" . $this->basicSearchSql([$keyword], $searchType) . ")";
					}
				}
			} else {
				$searchStr = $this->basicSearchSql($ar, $searchType);
			}
			if (!$default && in_array($this->Command, ["", "reset", "resetall"]))
				$this->Command = "search";
		}
		if (!$default && $this->Command == "search") {
			$this->BasicSearch->setKeyword($searchKeyword);
			$this->BasicSearch->setType($searchType);
		}
		return $searchStr;
	}

	// Check if search parm exists
	protected function checkSearchParms()
	{

		// Check basic search
		if ($this->BasicSearch->issetSession())
			return TRUE;
		if ($this->transferID->AdvancedSearch->issetSession())
			return TRUE;
		if ($this->txid->AdvancedSearch->issetSession())
			return TRUE;
		if ($this->merchantID->AdvancedSearch->issetSession())
			return TRUE;
		if ($this->_userID->AdvancedSearch->issetSession())
			return TRUE;
		if ($this->transferTime->AdvancedSearch->issetSession())
			return TRUE;
		if ($this->status->AdvancedSearch->issetSession())
			return TRUE;
		if ($this->currID->AdvancedSearch->issetSession())
			return TRUE;
		if ($this->TotalAmountForCustomer->AdvancedSearch->issetSession())
			return TRUE;
		if ($this->serviceFeeToMerchant->AdvancedSearch->issetSession())
			return TRUE;
		if ($this->TotalAmountForMerchant->AdvancedSearch->issetSession())
			return TRUE;
		if ($this->userpiid->AdvancedSearch->issetSession())
			return TRUE;
		if ($this->shoppingCartID->AdvancedSearch->issetSession())
			return TRUE;
		if ($this->merchantRefID->AdvancedSearch->issetSession())
			return TRUE;
		if ($this->purchaseAmount->AdvancedSearch->issetSession())
			return TRUE;
		if ($this->taxAmount->AdvancedSearch->issetSession())
			return TRUE;
		if ($this->tipAmount->AdvancedSearch->issetSession())
			return TRUE;
		if ($this->discountamount->AdvancedSearch->issetSession())
			return TRUE;
		if ($this->merchantSurcharge->AdvancedSearch->issetSession())
			return TRUE;
		if ($this->serviceFeeToCustomer->AdvancedSearch->issetSession())
			return TRUE;
		if ($this->feeid->AdvancedSearch->issetSession())
			return TRUE;
		if ($this->ratetabletype->AdvancedSearch->issetSession())
			return TRUE;
		if ($this->pis->AdvancedSearch->issetSession())
			return TRUE;
		if ($this->feesystemshare->AdvancedSearch->issetSession())
			return TRUE;
		if ($this->feeexternalshare->AdvancedSearch->issetSession())
			return TRUE;
		if ($this->feefranchiseeshare->AdvancedSearch->issetSession())
			return TRUE;
		if ($this->feeresellershare->AdvancedSearch->issetSession())
			return TRUE;
		if ($this->lastupdatetime->AdvancedSearch->issetSession())
			return TRUE;
		if ($this->officialdocnumber->AdvancedSearch->issetSession())
			return TRUE;
		if ($this->officialdocname->AdvancedSearch->issetSession())
			return TRUE;
		if ($this->businessname->AdvancedSearch->issetSession())
			return TRUE;
		if ($this->logofilename->AdvancedSearch->issetSession())
			return TRUE;
		if ($this->returndays->AdvancedSearch->issetSession())
			return TRUE;
		if ($this->originalpurchaseamount->AdvancedSearch->issetSession())
			return TRUE;
		if ($this->customerpurchaseid->AdvancedSearch->issetSession())
			return TRUE;
		if ($this->clerkFirstName->AdvancedSearch->issetSession())
			return TRUE;
		if ($this->clerkLastName->AdvancedSearch->issetSession())
			return TRUE;
		if ($this->originalMerchantSurcharge->AdvancedSearch->issetSession())
			return TRUE;
		if ($this->originalTaxAmount->AdvancedSearch->issetSession())
			return TRUE;
		if ($this->originalServiceFeeToCustomer->AdvancedSearch->issetSession())
			return TRUE;
		if ($this->originalTotalAmountForCustomer->AdvancedSearch->issetSession())
			return TRUE;
		if ($this->originalServiceFeeToMerchant->AdvancedSearch->issetSession())
			return TRUE;
		if ($this->originalTipAmount->AdvancedSearch->issetSession())
			return TRUE;
		if ($this->userpi->AdvancedSearch->issetSession())
			return TRUE;
		return FALSE;
	}

	// Clear all search parameters
	protected function resetSearchParms()
	{

		// Clear search WHERE clause
		$this->SearchWhere = "";
		$this->setSearchWhere($this->SearchWhere);

		// Clear basic search parameters
		$this->resetBasicSearchParms();

		// Clear advanced search parameters
		$this->resetAdvancedSearchParms();
	}

	// Load advanced search default values
	protected function loadAdvancedSearchDefault()
	{
		return FALSE;
	}

	// Clear all basic search parameters
	protected function resetBasicSearchParms()
	{
		$this->BasicSearch->unsetSession();
	}

	// Clear all advanced search parameters
	protected function resetAdvancedSearchParms()
	{
		$this->transferID->AdvancedSearch->unsetSession();
		$this->txid->AdvancedSearch->unsetSession();
		$this->merchantID->AdvancedSearch->unsetSession();
		$this->_userID->AdvancedSearch->unsetSession();
		$this->transferTime->AdvancedSearch->unsetSession();
		$this->status->AdvancedSearch->unsetSession();
		$this->currID->AdvancedSearch->unsetSession();
		$this->TotalAmountForCustomer->AdvancedSearch->unsetSession();
		$this->serviceFeeToMerchant->AdvancedSearch->unsetSession();
		$this->TotalAmountForMerchant->AdvancedSearch->unsetSession();
		$this->userpiid->AdvancedSearch->unsetSession();
		$this->shoppingCartID->AdvancedSearch->unsetSession();
		$this->merchantRefID->AdvancedSearch->unsetSession();
		$this->purchaseAmount->AdvancedSearch->unsetSession();
		$this->taxAmount->AdvancedSearch->unsetSession();
		$this->tipAmount->AdvancedSearch->unsetSession();
		$this->discountamount->AdvancedSearch->unsetSession();
		$this->merchantSurcharge->AdvancedSearch->unsetSession();
		$this->serviceFeeToCustomer->AdvancedSearch->unsetSession();
		$this->feeid->AdvancedSearch->unsetSession();
		$this->ratetabletype->AdvancedSearch->unsetSession();
		$this->pis->AdvancedSearch->unsetSession();
		$this->feesystemshare->AdvancedSearch->unsetSession();
		$this->feeexternalshare->AdvancedSearch->unsetSession();
		$this->feefranchiseeshare->AdvancedSearch->unsetSession();
		$this->feeresellershare->AdvancedSearch->unsetSession();
		$this->lastupdatetime->AdvancedSearch->unsetSession();
		$this->officialdocnumber->AdvancedSearch->unsetSession();
		$this->officialdocname->AdvancedSearch->unsetSession();
		$this->businessname->AdvancedSearch->unsetSession();
		$this->logofilename->AdvancedSearch->unsetSession();
		$this->returndays->AdvancedSearch->unsetSession();
		$this->originalpurchaseamount->AdvancedSearch->unsetSession();
		$this->customerpurchaseid->AdvancedSearch->unsetSession();
		$this->clerkFirstName->AdvancedSearch->unsetSession();
		$this->clerkLastName->AdvancedSearch->unsetSession();
		$this->originalMerchantSurcharge->AdvancedSearch->unsetSession();
		$this->originalTaxAmount->AdvancedSearch->unsetSession();
		$this->originalServiceFeeToCustomer->AdvancedSearch->unsetSession();
		$this->originalTotalAmountForCustomer->AdvancedSearch->unsetSession();
		$this->originalServiceFeeToMerchant->AdvancedSearch->unsetSession();
		$this->originalTipAmount->AdvancedSearch->unsetSession();
		$this->userpi->AdvancedSearch->unsetSession();
	}

	// Restore all search parameters
	protected function restoreSearchParms()
	{
		$this->RestoreSearch = TRUE;

		// Restore basic search values
		$this->BasicSearch->load();

		// Restore advanced search values
		$this->transferID->AdvancedSearch->load();
		$this->txid->AdvancedSearch->load();
		$this->merchantID->AdvancedSearch->load();
		$this->_userID->AdvancedSearch->load();
		$this->transferTime->AdvancedSearch->load();
		$this->status->AdvancedSearch->load();
		$this->currID->AdvancedSearch->load();
		$this->TotalAmountForCustomer->AdvancedSearch->load();
		$this->serviceFeeToMerchant->AdvancedSearch->load();
		$this->TotalAmountForMerchant->AdvancedSearch->load();
		$this->userpiid->AdvancedSearch->load();
		$this->shoppingCartID->AdvancedSearch->load();
		$this->merchantRefID->AdvancedSearch->load();
		$this->purchaseAmount->AdvancedSearch->load();
		$this->taxAmount->AdvancedSearch->load();
		$this->tipAmount->AdvancedSearch->load();
		$this->discountamount->AdvancedSearch->load();
		$this->merchantSurcharge->AdvancedSearch->load();
		$this->serviceFeeToCustomer->AdvancedSearch->load();
		$this->feeid->AdvancedSearch->load();
		$this->ratetabletype->AdvancedSearch->load();
		$this->pis->AdvancedSearch->load();
		$this->feesystemshare->AdvancedSearch->load();
		$this->feeexternalshare->AdvancedSearch->load();
		$this->feefranchiseeshare->AdvancedSearch->load();
		$this->feeresellershare->AdvancedSearch->load();
		$this->lastupdatetime->AdvancedSearch->load();
		$this->officialdocnumber->AdvancedSearch->load();
		$this->officialdocname->AdvancedSearch->load();
		$this->businessname->AdvancedSearch->load();
		$this->logofilename->AdvancedSearch->load();
		$this->returndays->AdvancedSearch->load();
		$this->originalpurchaseamount->AdvancedSearch->load();
		$this->customerpurchaseid->AdvancedSearch->load();
		$this->clerkFirstName->AdvancedSearch->load();
		$this->clerkLastName->AdvancedSearch->load();
		$this->originalMerchantSurcharge->AdvancedSearch->load();
		$this->originalTaxAmount->AdvancedSearch->load();
		$this->originalServiceFeeToCustomer->AdvancedSearch->load();
		$this->originalTotalAmountForCustomer->AdvancedSearch->load();
		$this->originalServiceFeeToMerchant->AdvancedSearch->load();
		$this->originalTipAmount->AdvancedSearch->load();
		$this->userpi->AdvancedSearch->load();
	}

	// Set up sort parameters
	protected function setupSortOrder()
	{

		// Check for "order" parameter
		if (Get("order") !== NULL) {
			$this->CurrentOrder = Get("order");
			$this->CurrentOrderType = Get("ordertype", "");
			$this->updateSort($this->transferID); // transferID
			$this->updateSort($this->txid); // txid
			$this->updateSort($this->merchantID); // merchantID
			$this->updateSort($this->transferTime); // transferTime
			$this->updateSort($this->status); // status
			$this->updateSort($this->currID); // currID
			$this->updateSort($this->TotalAmountForCustomer); // TotalAmountForCustomer
			$this->updateSort($this->serviceFeeToMerchant); // serviceFeeToMerchant
			$this->updateSort($this->TotalAmountForMerchant); // TotalAmountForMerchant
			$this->updateSort($this->userpiid); // userpiid
			$this->updateSort($this->shoppingCartID); // shoppingCartID
			$this->updateSort($this->merchantRefID); // merchantRefID
			$this->updateSort($this->userpi); // userpi
			$this->setStartRecordNumber(1); // Reset start position
		}
	}

	// Load sort order parameters
	protected function loadSortOrder()
	{
		$orderBy = $this->getSessionOrderBy(); // Get ORDER BY from Session
		if ($orderBy == "") {
			if ($this->getSqlOrderBy() != "") {
				$orderBy = $this->getSqlOrderBy();
				$this->setSessionOrderBy($orderBy);
			}
		}
	}

	// Reset command
	// - cmd=reset (Reset search parameters)
	// - cmd=resetall (Reset search and master/detail parameters)
	// - cmd=resetsort (Reset sort parameters)

	protected function resetCmd()
	{

		// Check if reset command
		if (StartsString("reset", $this->Command)) {

			// Reset search criteria
			if ($this->Command == "reset" || $this->Command == "resetall")
				$this->resetSearchParms();

			// Reset sorting order
			if ($this->Command == "resetsort") {
				$orderBy = "";
				$this->setSessionOrderBy($orderBy);
				$this->transferID->setSort("");
				$this->txid->setSort("");
				$this->merchantID->setSort("");
				$this->transferTime->setSort("");
				$this->status->setSort("");
				$this->currID->setSort("");
				$this->TotalAmountForCustomer->setSort("");
				$this->serviceFeeToMerchant->setSort("");
				$this->TotalAmountForMerchant->setSort("");
				$this->userpiid->setSort("");
				$this->shoppingCartID->setSort("");
				$this->merchantRefID->setSort("");
				$this->userpi->setSort("");
			}

			// Reset start position
			$this->StartRecord = 1;
			$this->setStartRecordNumber($this->StartRecord);
		}
	}

	// Set up list options
	protected function setupListOptions()
	{
		global $Security, $Language;

		// Add group option item
		$item = &$this->ListOptions->add($this->ListOptions->GroupOptionName);
		$item->Body = "";
		$item->OnLeft = FALSE;
		$item->Visible = FALSE;

		// "view"
		$item = &$this->ListOptions->add("view");
		$item->CssClass = "text-nowrap";
		$item->Visible = $Security->canView();
		$item->OnLeft = FALSE;

		// List actions
		$item = &$this->ListOptions->add("listactions");
		$item->CssClass = "text-nowrap";
		$item->OnLeft = FALSE;
		$item->Visible = FALSE;
		$item->ShowInButtonGroup = FALSE;
		$item->ShowInDropDown = FALSE;

		// "checkbox"
		$item = &$this->ListOptions->add("checkbox");
		$item->Visible = FALSE;
		$item->OnLeft = FALSE;
		$item->Header = "<div class=\"custom-control custom-checkbox d-inline-block\"><input type=\"checkbox\" name=\"key\" id=\"key\" class=\"custom-control-input\" onclick=\"ew.selectAllKey(this);\"><label class=\"custom-control-label\" for=\"key\"></label></div>";
		$item->ShowInDropDown = FALSE;
		$item->ShowInButtonGroup = FALSE;

		// Drop down button for ListOptions
		$this->ListOptions->UseDropDownButton = FALSE;
		$this->ListOptions->DropDownButtonPhrase = $Language->phrase("ButtonListOptions");
		$this->ListOptions->UseButtonGroup = FALSE;
		if ($this->ListOptions->UseButtonGroup && IsMobile())
			$this->ListOptions->UseDropDownButton = TRUE;

		//$this->ListOptions->ButtonClass = ""; // Class for button group
		// Call ListOptions_Load event

		$this->ListOptions_Load();
		$this->setupListOptionsExt();
		$item = $this->ListOptions[$this->ListOptions->GroupOptionName];
		$item->Visible = $this->ListOptions->groupOptionVisible();
	}

	// Render list options
	public function renderListOptions()
	{
		global $Security, $Language, $CurrentForm;
		$this->ListOptions->loadDefault();

		// Call ListOptions_Rendering event
		$this->ListOptions_Rendering();

		// "view"
		$opt = $this->ListOptions["view"];
		$viewcaption = HtmlTitle($Language->phrase("ViewLink"));
		if ($Security->canView()) {
			$opt->Body = "<a class=\"ew-row-link ew-view\" title=\"" . $viewcaption . "\" data-caption=\"" . $viewcaption . "\" href=\"" . HtmlEncode($this->ViewUrl) . "\">" . $Language->phrase("ViewLink") . "</a>";
		} else {
			$opt->Body = "";
		}

		// Set up list action buttons
		$opt = $this->ListOptions["listactions"];
		if ($opt && !$this->isExport() && !$this->CurrentAction) {
			$body = "";
			$links = [];
			foreach ($this->ListActions->Items as $listaction) {
				if ($listaction->Select == ACTION_SINGLE && $listaction->Allow) {
					$action = $listaction->Action;
					$caption = $listaction->Caption;
					$icon = ($listaction->Icon != "") ? "<i class=\"" . HtmlEncode(str_replace(" ew-icon", "", $listaction->Icon)) . "\" data-caption=\"" . HtmlTitle($caption) . "\"></i> " : "";
					$links[] = "<li><a class=\"dropdown-item ew-action ew-list-action\" data-action=\"" . HtmlEncode($action) . "\" data-caption=\"" . HtmlTitle($caption) . "\" href=\"#\" onclick=\"return ew.submitAction(event,jQuery.extend({key:" . $this->keyToJson(TRUE) . "}," . $listaction->toJson(TRUE) . "));\">" . $icon . $listaction->Caption . "</a></li>";
					if (count($links) == 1) // Single button
						$body = "<a class=\"ew-action ew-list-action\" data-action=\"" . HtmlEncode($action) . "\" title=\"" . HtmlTitle($caption) . "\" data-caption=\"" . HtmlTitle($caption) . "\" href=\"#\" onclick=\"return ew.submitAction(event,jQuery.extend({key:" . $this->keyToJson(TRUE) . "}," . $listaction->toJson(TRUE) . "));\">" . $icon . $listaction->Caption . "</a>";
				}
			}
			if (count($links) > 1) { // More than one buttons, use dropdown
				$body = "<button class=\"dropdown-toggle btn btn-default ew-actions\" title=\"" . HtmlTitle($Language->phrase("ListActionButton")) . "\" data-toggle=\"dropdown\">" . $Language->phrase("ListActionButton") . "</button>";
				$content = "";
				foreach ($links as $link)
					$content .= "<li>" . $link . "</li>";
				$body .= "<ul class=\"dropdown-menu" . ($opt->OnLeft ? "" : " dropdown-menu-right") . "\">". $content . "</ul>";
				$body = "<div class=\"btn-group btn-group-sm\">" . $body . "</div>";
			}
			if (count($links) > 0) {
				$opt->Body = $body;
				$opt->Visible = TRUE;
			}
		}

		// "checkbox"
		$opt = $this->ListOptions["checkbox"];
		$opt->Body = "<div class=\"custom-control custom-checkbox d-inline-block\"><input type=\"checkbox\" id=\"key_m_" . $this->RowCount . "\" name=\"key_m[]\" class=\"custom-control-input ew-multi-select\" value=\"" . HtmlEncode($this->transferID->CurrentValue . Config("COMPOSITE_KEY_SEPARATOR") . $this->txid->CurrentValue) . "\" onclick=\"ew.clickMultiCheckbox(event);\"><label class=\"custom-control-label\" for=\"key_m_" . $this->RowCount . "\"></label></div>";
		$this->renderListOptionsExt();

		// Call ListOptions_Rendered event
		$this->ListOptions_Rendered();
	}

	// Set up other options
	protected function setupOtherOptions()
	{
		global $Language, $Security;
		$options = &$this->OtherOptions;
		$option = $options["action"];

		// Set up options default
		foreach ($options as $option) {
			$option->UseDropDownButton = FALSE;
			$option->UseButtonGroup = TRUE;

			//$option->ButtonClass = ""; // Class for button group
			$item = &$option->add($option->GroupOptionName);
			$item->Body = "";
			$item->Visible = FALSE;
		}
		$options["addedit"]->DropDownButtonPhrase = $Language->phrase("ButtonAddEdit");
		$options["detail"]->DropDownButtonPhrase = $Language->phrase("ButtonDetails");
		$options["action"]->DropDownButtonPhrase = $Language->phrase("ButtonActions");

		// Filter button
		$item = &$this->FilterOptions->add("savecurrentfilter");
		$item->Body = "<a class=\"ew-save-filter\" data-form=\"fvmerchantsaleslistsrch\" href=\"#\" onclick=\"return false;\">" . $Language->phrase("SaveCurrentFilter") . "</a>";
		$item->Visible = TRUE;
		$item = &$this->FilterOptions->add("deletefilter");
		$item->Body = "<a class=\"ew-delete-filter\" data-form=\"fvmerchantsaleslistsrch\" href=\"#\" onclick=\"return false;\">" . $Language->phrase("DeleteFilter") . "</a>";
		$item->Visible = TRUE;
		$this->FilterOptions->UseDropDownButton = TRUE;
		$this->FilterOptions->UseButtonGroup = !$this->FilterOptions->UseDropDownButton;
		$this->FilterOptions->DropDownButtonPhrase = $Language->phrase("Filters");

		// Add group option item
		$item = &$this->FilterOptions->add($this->FilterOptions->GroupOptionName);
		$item->Body = "";
		$item->Visible = FALSE;
	}

	// Render other options
	public function renderOtherOptions()
	{
		global $Language, $Security;
		$options = &$this->OtherOptions;
			$option = $options["action"];

			// Set up list action buttons
			foreach ($this->ListActions->Items as $listaction) {
				if ($listaction->Select == ACTION_MULTIPLE) {
					$item = &$option->add("custom_" . $listaction->Action);
					$caption = $listaction->Caption;
					$icon = ($listaction->Icon != "") ? "<i class=\"" . HtmlEncode($listaction->Icon) . "\" data-caption=\"" . HtmlEncode($caption) . "\"></i> " . $caption : $caption;
					$item->Body = "<a class=\"ew-action ew-list-action\" title=\"" . HtmlEncode($caption) . "\" data-caption=\"" . HtmlEncode($caption) . "\" href=\"#\" onclick=\"return ew.submitAction(event,jQuery.extend({f:document.fvmerchantsaleslist}," . $listaction->toJson(TRUE) . "));\">" . $icon . "</a>";
					$item->Visible = $listaction->Allow;
				}
			}

			// Hide grid edit and other options
			if ($this->TotalRecords <= 0) {
				$option = $options["addedit"];
				$item = $option["gridedit"];
				if ($item)
					$item->Visible = FALSE;
				$option = $options["action"];
				$option->hideAllOptions();
			}
	}

	// Process list action
	protected function processListAction()
	{
		global $Language, $Security;
		$userlist = "";
		$user = "";
		$filter = $this->getFilterFromRecordKeys();
		$userAction = Post("useraction", "");
		if ($filter != "" && $userAction != "") {

			// Check permission first
			$actionCaption = $userAction;
			if (array_key_exists($userAction, $this->ListActions->Items)) {
				$actionCaption = $this->ListActions[$userAction]->Caption;
				if (!$this->ListActions[$userAction]->Allow) {
					$errmsg = str_replace('%s', $actionCaption, $Language->phrase("CustomActionNotAllowed"));
					if (Post("ajax") == $userAction) // Ajax
						echo "<p class=\"text-danger\">" . $errmsg . "</p>";
					else
						$this->setFailureMessage($errmsg);
					return FALSE;
				}
			}
			$this->CurrentFilter = $filter;
			$sql = $this->getCurrentSql();
			$conn = $this->getConnection();
			$conn->raiseErrorFn = Config("ERROR_FUNC");
			$rs = $conn->execute($sql);
			$conn->raiseErrorFn = "";
			$this->CurrentAction = $userAction;

			// Call row action event
			if ($rs && !$rs->EOF) {
				$conn->beginTrans();
				$this->SelectedCount = $rs->RecordCount();
				$this->SelectedIndex = 0;
				while (!$rs->EOF) {
					$this->SelectedIndex++;
					$row = $rs->fields;
					$processed = $this->Row_CustomAction($userAction, $row);
					if (!$processed)
						break;
					$rs->moveNext();
				}
				if ($processed) {
					$conn->commitTrans(); // Commit the changes
					if ($this->getSuccessMessage() == "" && !ob_get_length()) // No output
						$this->setSuccessMessage(str_replace('%s', $actionCaption, $Language->phrase("CustomActionCompleted"))); // Set up success message
				} else {
					$conn->rollbackTrans(); // Rollback changes

					// Set up error message
					if ($this->getSuccessMessage() != "" || $this->getFailureMessage() != "") {

						// Use the message, do nothing
					} elseif ($this->CancelMessage != "") {
						$this->setFailureMessage($this->CancelMessage);
						$this->CancelMessage = "";
					} else {
						$this->setFailureMessage(str_replace('%s', $actionCaption, $Language->phrase("CustomActionFailed")));
					}
				}
			}
			if ($rs)
				$rs->close();
			$this->CurrentAction = ""; // Clear action
			if (Post("ajax") == $userAction) { // Ajax
				if ($this->getSuccessMessage() != "") {
					echo "<p class=\"text-success\">" . $this->getSuccessMessage() . "</p>";
					$this->clearSuccessMessage(); // Clear message
				}
				if ($this->getFailureMessage() != "") {
					echo "<p class=\"text-danger\">" . $this->getFailureMessage() . "</p>";
					$this->clearFailureMessage(); // Clear message
				}
				return TRUE;
			}
		}
		return FALSE; // Not ajax request
	}

// Set up list options (extended codes)
	protected function setupListOptionsExt()
	{

		// Hide detail items for dropdown if necessary
		$this->ListOptions->hideDetailItemsForDropDown();
	}

// Render list options (extended codes)
	protected function renderListOptionsExt()
	{
		global $Security, $Language;
	}

	// Load basic search values
	protected function loadBasicSearchValues()
	{
		$this->BasicSearch->setKeyword(Get(Config("TABLE_BASIC_SEARCH"), ""), FALSE);
		if ($this->BasicSearch->Keyword != "" && $this->Command == "")
			$this->Command = "search";
		$this->BasicSearch->setType(Get(Config("TABLE_BASIC_SEARCH_TYPE"), ""), FALSE);
	}

	// Load search values for validation
	protected function loadSearchValues()
	{

		// Load search values
		$got = FALSE;

		// transferID
		if (!$this->isAddOrEdit() && $this->transferID->AdvancedSearch->get()) {
			$got = TRUE;
			if (($this->transferID->AdvancedSearch->SearchValue != "" || $this->transferID->AdvancedSearch->SearchValue2 != "") && $this->Command == "")
				$this->Command = "search";
		}

		// txid
		if (!$this->isAddOrEdit() && $this->txid->AdvancedSearch->get()) {
			$got = TRUE;
			if (($this->txid->AdvancedSearch->SearchValue != "" || $this->txid->AdvancedSearch->SearchValue2 != "") && $this->Command == "")
				$this->Command = "search";
		}

		// merchantID
		if (!$this->isAddOrEdit() && $this->merchantID->AdvancedSearch->get()) {
			$got = TRUE;
			if (($this->merchantID->AdvancedSearch->SearchValue != "" || $this->merchantID->AdvancedSearch->SearchValue2 != "") && $this->Command == "")
				$this->Command = "search";
		}

		// userID
		if (!$this->isAddOrEdit() && $this->_userID->AdvancedSearch->get()) {
			$got = TRUE;
			if (($this->_userID->AdvancedSearch->SearchValue != "" || $this->_userID->AdvancedSearch->SearchValue2 != "") && $this->Command == "")
				$this->Command = "search";
		}

		// transferTime
		if (!$this->isAddOrEdit() && $this->transferTime->AdvancedSearch->get()) {
			$got = TRUE;
			if (($this->transferTime->AdvancedSearch->SearchValue != "" || $this->transferTime->AdvancedSearch->SearchValue2 != "") && $this->Command == "")
				$this->Command = "search";
		}

		// status
		if (!$this->isAddOrEdit() && $this->status->AdvancedSearch->get()) {
			$got = TRUE;
			if (($this->status->AdvancedSearch->SearchValue != "" || $this->status->AdvancedSearch->SearchValue2 != "") && $this->Command == "")
				$this->Command = "search";
		}

		// currID
		if (!$this->isAddOrEdit() && $this->currID->AdvancedSearch->get()) {
			$got = TRUE;
			if (($this->currID->AdvancedSearch->SearchValue != "" || $this->currID->AdvancedSearch->SearchValue2 != "") && $this->Command == "")
				$this->Command = "search";
		}

		// TotalAmountForCustomer
		if (!$this->isAddOrEdit() && $this->TotalAmountForCustomer->AdvancedSearch->get()) {
			$got = TRUE;
			if (($this->TotalAmountForCustomer->AdvancedSearch->SearchValue != "" || $this->TotalAmountForCustomer->AdvancedSearch->SearchValue2 != "") && $this->Command == "")
				$this->Command = "search";
		}

		// serviceFeeToMerchant
		if (!$this->isAddOrEdit() && $this->serviceFeeToMerchant->AdvancedSearch->get()) {
			$got = TRUE;
			if (($this->serviceFeeToMerchant->AdvancedSearch->SearchValue != "" || $this->serviceFeeToMerchant->AdvancedSearch->SearchValue2 != "") && $this->Command == "")
				$this->Command = "search";
		}

		// TotalAmountForMerchant
		if (!$this->isAddOrEdit() && $this->TotalAmountForMerchant->AdvancedSearch->get()) {
			$got = TRUE;
			if (($this->TotalAmountForMerchant->AdvancedSearch->SearchValue != "" || $this->TotalAmountForMerchant->AdvancedSearch->SearchValue2 != "") && $this->Command == "")
				$this->Command = "search";
		}

		// userpiid
		if (!$this->isAddOrEdit() && $this->userpiid->AdvancedSearch->get()) {
			$got = TRUE;
			if (($this->userpiid->AdvancedSearch->SearchValue != "" || $this->userpiid->AdvancedSearch->SearchValue2 != "") && $this->Command == "")
				$this->Command = "search";
		}

		// shoppingCartID
		if (!$this->isAddOrEdit() && $this->shoppingCartID->AdvancedSearch->get()) {
			$got = TRUE;
			if (($this->shoppingCartID->AdvancedSearch->SearchValue != "" || $this->shoppingCartID->AdvancedSearch->SearchValue2 != "") && $this->Command == "")
				$this->Command = "search";
		}

		// merchantRefID
		if (!$this->isAddOrEdit() && $this->merchantRefID->AdvancedSearch->get()) {
			$got = TRUE;
			if (($this->merchantRefID->AdvancedSearch->SearchValue != "" || $this->merchantRefID->AdvancedSearch->SearchValue2 != "") && $this->Command == "")
				$this->Command = "search";
		}

		// purchaseAmount
		if (!$this->isAddOrEdit() && $this->purchaseAmount->AdvancedSearch->get()) {
			$got = TRUE;
			if (($this->purchaseAmount->AdvancedSearch->SearchValue != "" || $this->purchaseAmount->AdvancedSearch->SearchValue2 != "") && $this->Command == "")
				$this->Command = "search";
		}

		// taxAmount
		if (!$this->isAddOrEdit() && $this->taxAmount->AdvancedSearch->get()) {
			$got = TRUE;
			if (($this->taxAmount->AdvancedSearch->SearchValue != "" || $this->taxAmount->AdvancedSearch->SearchValue2 != "") && $this->Command == "")
				$this->Command = "search";
		}

		// tipAmount
		if (!$this->isAddOrEdit() && $this->tipAmount->AdvancedSearch->get()) {
			$got = TRUE;
			if (($this->tipAmount->AdvancedSearch->SearchValue != "" || $this->tipAmount->AdvancedSearch->SearchValue2 != "") && $this->Command == "")
				$this->Command = "search";
		}

		// discountamount
		if (!$this->isAddOrEdit() && $this->discountamount->AdvancedSearch->get()) {
			$got = TRUE;
			if (($this->discountamount->AdvancedSearch->SearchValue != "" || $this->discountamount->AdvancedSearch->SearchValue2 != "") && $this->Command == "")
				$this->Command = "search";
		}

		// merchantSurcharge
		if (!$this->isAddOrEdit() && $this->merchantSurcharge->AdvancedSearch->get()) {
			$got = TRUE;
			if (($this->merchantSurcharge->AdvancedSearch->SearchValue != "" || $this->merchantSurcharge->AdvancedSearch->SearchValue2 != "") && $this->Command == "")
				$this->Command = "search";
		}

		// serviceFeeToCustomer
		if (!$this->isAddOrEdit() && $this->serviceFeeToCustomer->AdvancedSearch->get()) {
			$got = TRUE;
			if (($this->serviceFeeToCustomer->AdvancedSearch->SearchValue != "" || $this->serviceFeeToCustomer->AdvancedSearch->SearchValue2 != "") && $this->Command == "")
				$this->Command = "search";
		}

		// feeid
		if (!$this->isAddOrEdit() && $this->feeid->AdvancedSearch->get()) {
			$got = TRUE;
			if (($this->feeid->AdvancedSearch->SearchValue != "" || $this->feeid->AdvancedSearch->SearchValue2 != "") && $this->Command == "")
				$this->Command = "search";
		}

		// ratetabletype
		if (!$this->isAddOrEdit() && $this->ratetabletype->AdvancedSearch->get()) {
			$got = TRUE;
			if (($this->ratetabletype->AdvancedSearch->SearchValue != "" || $this->ratetabletype->AdvancedSearch->SearchValue2 != "") && $this->Command == "")
				$this->Command = "search";
		}

		// pis
		if (!$this->isAddOrEdit() && $this->pis->AdvancedSearch->get()) {
			$got = TRUE;
			if (($this->pis->AdvancedSearch->SearchValue != "" || $this->pis->AdvancedSearch->SearchValue2 != "") && $this->Command == "")
				$this->Command = "search";
		}

		// feesystemshare
		if (!$this->isAddOrEdit() && $this->feesystemshare->AdvancedSearch->get()) {
			$got = TRUE;
			if (($this->feesystemshare->AdvancedSearch->SearchValue != "" || $this->feesystemshare->AdvancedSearch->SearchValue2 != "") && $this->Command == "")
				$this->Command = "search";
		}

		// feeexternalshare
		if (!$this->isAddOrEdit() && $this->feeexternalshare->AdvancedSearch->get()) {
			$got = TRUE;
			if (($this->feeexternalshare->AdvancedSearch->SearchValue != "" || $this->feeexternalshare->AdvancedSearch->SearchValue2 != "") && $this->Command == "")
				$this->Command = "search";
		}

		// feefranchiseeshare
		if (!$this->isAddOrEdit() && $this->feefranchiseeshare->AdvancedSearch->get()) {
			$got = TRUE;
			if (($this->feefranchiseeshare->AdvancedSearch->SearchValue != "" || $this->feefranchiseeshare->AdvancedSearch->SearchValue2 != "") && $this->Command == "")
				$this->Command = "search";
		}

		// feeresellershare
		if (!$this->isAddOrEdit() && $this->feeresellershare->AdvancedSearch->get()) {
			$got = TRUE;
			if (($this->feeresellershare->AdvancedSearch->SearchValue != "" || $this->feeresellershare->AdvancedSearch->SearchValue2 != "") && $this->Command == "")
				$this->Command = "search";
		}

		// lastupdatetime
		if (!$this->isAddOrEdit() && $this->lastupdatetime->AdvancedSearch->get()) {
			$got = TRUE;
			if (($this->lastupdatetime->AdvancedSearch->SearchValue != "" || $this->lastupdatetime->AdvancedSearch->SearchValue2 != "") && $this->Command == "")
				$this->Command = "search";
		}

		// officialdocnumber
		if (!$this->isAddOrEdit() && $this->officialdocnumber->AdvancedSearch->get()) {
			$got = TRUE;
			if (($this->officialdocnumber->AdvancedSearch->SearchValue != "" || $this->officialdocnumber->AdvancedSearch->SearchValue2 != "") && $this->Command == "")
				$this->Command = "search";
		}

		// officialdocname
		if (!$this->isAddOrEdit() && $this->officialdocname->AdvancedSearch->get()) {
			$got = TRUE;
			if (($this->officialdocname->AdvancedSearch->SearchValue != "" || $this->officialdocname->AdvancedSearch->SearchValue2 != "") && $this->Command == "")
				$this->Command = "search";
		}

		// businessname
		if (!$this->isAddOrEdit() && $this->businessname->AdvancedSearch->get()) {
			$got = TRUE;
			if (($this->businessname->AdvancedSearch->SearchValue != "" || $this->businessname->AdvancedSearch->SearchValue2 != "") && $this->Command == "")
				$this->Command = "search";
		}

		// logofilename
		if (!$this->isAddOrEdit() && $this->logofilename->AdvancedSearch->get()) {
			$got = TRUE;
			if (($this->logofilename->AdvancedSearch->SearchValue != "" || $this->logofilename->AdvancedSearch->SearchValue2 != "") && $this->Command == "")
				$this->Command = "search";
		}

		// returndays
		if (!$this->isAddOrEdit() && $this->returndays->AdvancedSearch->get()) {
			$got = TRUE;
			if (($this->returndays->AdvancedSearch->SearchValue != "" || $this->returndays->AdvancedSearch->SearchValue2 != "") && $this->Command == "")
				$this->Command = "search";
		}

		// originalpurchaseamount
		if (!$this->isAddOrEdit() && $this->originalpurchaseamount->AdvancedSearch->get()) {
			$got = TRUE;
			if (($this->originalpurchaseamount->AdvancedSearch->SearchValue != "" || $this->originalpurchaseamount->AdvancedSearch->SearchValue2 != "") && $this->Command == "")
				$this->Command = "search";
		}

		// customerpurchaseid
		if (!$this->isAddOrEdit() && $this->customerpurchaseid->AdvancedSearch->get()) {
			$got = TRUE;
			if (($this->customerpurchaseid->AdvancedSearch->SearchValue != "" || $this->customerpurchaseid->AdvancedSearch->SearchValue2 != "") && $this->Command == "")
				$this->Command = "search";
		}

		// clerkFirstName
		if (!$this->isAddOrEdit() && $this->clerkFirstName->AdvancedSearch->get()) {
			$got = TRUE;
			if (($this->clerkFirstName->AdvancedSearch->SearchValue != "" || $this->clerkFirstName->AdvancedSearch->SearchValue2 != "") && $this->Command == "")
				$this->Command = "search";
		}

		// clerkLastName
		if (!$this->isAddOrEdit() && $this->clerkLastName->AdvancedSearch->get()) {
			$got = TRUE;
			if (($this->clerkLastName->AdvancedSearch->SearchValue != "" || $this->clerkLastName->AdvancedSearch->SearchValue2 != "") && $this->Command == "")
				$this->Command = "search";
		}

		// originalMerchantSurcharge
		if (!$this->isAddOrEdit() && $this->originalMerchantSurcharge->AdvancedSearch->get()) {
			$got = TRUE;
			if (($this->originalMerchantSurcharge->AdvancedSearch->SearchValue != "" || $this->originalMerchantSurcharge->AdvancedSearch->SearchValue2 != "") && $this->Command == "")
				$this->Command = "search";
		}

		// originalTaxAmount
		if (!$this->isAddOrEdit() && $this->originalTaxAmount->AdvancedSearch->get()) {
			$got = TRUE;
			if (($this->originalTaxAmount->AdvancedSearch->SearchValue != "" || $this->originalTaxAmount->AdvancedSearch->SearchValue2 != "") && $this->Command == "")
				$this->Command = "search";
		}

		// originalServiceFeeToCustomer
		if (!$this->isAddOrEdit() && $this->originalServiceFeeToCustomer->AdvancedSearch->get()) {
			$got = TRUE;
			if (($this->originalServiceFeeToCustomer->AdvancedSearch->SearchValue != "" || $this->originalServiceFeeToCustomer->AdvancedSearch->SearchValue2 != "") && $this->Command == "")
				$this->Command = "search";
		}

		// originalTotalAmountForCustomer
		if (!$this->isAddOrEdit() && $this->originalTotalAmountForCustomer->AdvancedSearch->get()) {
			$got = TRUE;
			if (($this->originalTotalAmountForCustomer->AdvancedSearch->SearchValue != "" || $this->originalTotalAmountForCustomer->AdvancedSearch->SearchValue2 != "") && $this->Command == "")
				$this->Command = "search";
		}

		// originalServiceFeeToMerchant
		if (!$this->isAddOrEdit() && $this->originalServiceFeeToMerchant->AdvancedSearch->get()) {
			$got = TRUE;
			if (($this->originalServiceFeeToMerchant->AdvancedSearch->SearchValue != "" || $this->originalServiceFeeToMerchant->AdvancedSearch->SearchValue2 != "") && $this->Command == "")
				$this->Command = "search";
		}

		// originalTipAmount
		if (!$this->isAddOrEdit() && $this->originalTipAmount->AdvancedSearch->get()) {
			$got = TRUE;
			if (($this->originalTipAmount->AdvancedSearch->SearchValue != "" || $this->originalTipAmount->AdvancedSearch->SearchValue2 != "") && $this->Command == "")
				$this->Command = "search";
		}

		// userpi
		if (!$this->isAddOrEdit() && $this->userpi->AdvancedSearch->get()) {
			$got = TRUE;
			if (($this->userpi->AdvancedSearch->SearchValue != "" || $this->userpi->AdvancedSearch->SearchValue2 != "") && $this->Command == "")
				$this->Command = "search";
		}
		return $got;
	}

	// Load recordset
	public function loadRecordset($offset = -1, $rowcnt = -1)
	{

		// Load List page SQL
		$sql = $this->getListSql();
		$conn = $this->getConnection();

		// Load recordset
		$dbtype = GetConnectionType($this->Dbid);
		if ($this->UseSelectLimit) {
			$conn->raiseErrorFn = Config("ERROR_FUNC");
			if ($dbtype == "MSSQL") {
				$rs = $conn->selectLimit($sql, $rowcnt, $offset, ["_hasOrderBy" => trim($this->getOrderBy()) || trim($this->getSessionOrderBy())]);
			} else {
				$rs = $conn->selectLimit($sql, $rowcnt, $offset);
			}
			$conn->raiseErrorFn = "";
		} else {
			$rs = LoadRecordset($sql, $conn);
		}

		// Call Recordset Selected event
		$this->Recordset_Selected($rs);
		return $rs;
	}

	// Load row based on key values
	public function loadRow()
	{
		global $Security, $Language;
		$filter = $this->getRecordFilter();

		// Call Row Selecting event
		$this->Row_Selecting($filter);

		// Load SQL based on filter
		$this->CurrentFilter = $filter;
		$sql = $this->getCurrentSql();
		$conn = $this->getConnection();
		$res = FALSE;
		$rs = LoadRecordset($sql, $conn);
		if ($rs && !$rs->EOF) {
			$res = TRUE;
			$this->loadRowValues($rs); // Load row values
			$rs->close();
		}
		return $res;
	}

	// Load row values from recordset
	public function loadRowValues($rs = NULL)
	{
		if ($rs && !$rs->EOF)
			$row = $rs->fields;
		else
			$row = $this->newRow();

		// Call Row Selected event
		$this->Row_Selected($row);
		if (!$rs || $rs->EOF)
			return;
		$this->transferID->setDbValue($row['transferID']);
		$this->txid->setDbValue($row['txid']);
		$this->merchantID->setDbValue($row['merchantID']);
		$this->_userID->setDbValue($row['userID']);
		$this->transferTime->setDbValue($row['transferTime']);
		$this->status->setDbValue($row['status']);
		$this->currID->setDbValue($row['currID']);
		$this->TotalAmountForCustomer->setDbValue($row['TotalAmountForCustomer']);
		$this->serviceFeeToMerchant->setDbValue($row['serviceFeeToMerchant']);
		$this->TotalAmountForMerchant->setDbValue($row['TotalAmountForMerchant']);
		$this->userpiid->setDbValue($row['userpiid']);
		$this->shoppingCartID->setDbValue($row['shoppingCartID']);
		$this->merchantRefID->setDbValue($row['merchantRefID']);
		$this->purchaseAmount->setDbValue($row['purchaseAmount']);
		$this->taxAmount->setDbValue($row['taxAmount']);
		$this->tipAmount->setDbValue($row['tipAmount']);
		$this->discountamount->setDbValue($row['discountamount']);
		$this->merchantSurcharge->setDbValue($row['merchantSurcharge']);
		$this->serviceFeeToCustomer->setDbValue($row['serviceFeeToCustomer']);
		$this->feeid->setDbValue($row['feeid']);
		$this->ratetabletype->setDbValue($row['ratetabletype']);
		$this->pis->setDbValue($row['pis']);
		$this->feesystemshare->setDbValue($row['feesystemshare']);
		$this->feeexternalshare->setDbValue($row['feeexternalshare']);
		$this->feefranchiseeshare->setDbValue($row['feefranchiseeshare']);
		$this->feeresellershare->setDbValue($row['feeresellershare']);
		$this->lastupdatetime->setDbValue($row['lastupdatetime']);
		$this->officialdocnumber->setDbValue($row['officialdocnumber']);
		$this->officialdocname->setDbValue($row['officialdocname']);
		$this->businessname->setDbValue($row['businessname']);
		$this->logofilename->setDbValue($row['logofilename']);
		$this->returndays->setDbValue($row['returndays']);
		$this->originalpurchaseamount->setDbValue($row['originalpurchaseamount']);
		$this->customerpurchaseid->setDbValue($row['customerpurchaseid']);
		$this->clerkFirstName->setDbValue($row['clerkFirstName']);
		$this->clerkLastName->setDbValue($row['clerkLastName']);
		$this->originalMerchantSurcharge->setDbValue($row['originalMerchantSurcharge']);
		$this->originalTaxAmount->setDbValue($row['originalTaxAmount']);
		$this->originalServiceFeeToCustomer->setDbValue($row['originalServiceFeeToCustomer']);
		$this->originalTotalAmountForCustomer->setDbValue($row['originalTotalAmountForCustomer']);
		$this->originalServiceFeeToMerchant->setDbValue($row['originalServiceFeeToMerchant']);
		$this->originalTipAmount->setDbValue($row['originalTipAmount']);
		$this->userpi->setDbValue($row['userpi']);
	}

	// Return a row with default values
	protected function newRow()
	{
		$row = [];
		$row['transferID'] = NULL;
		$row['txid'] = NULL;
		$row['merchantID'] = NULL;
		$row['userID'] = NULL;
		$row['transferTime'] = NULL;
		$row['status'] = NULL;
		$row['currID'] = NULL;
		$row['TotalAmountForCustomer'] = NULL;
		$row['serviceFeeToMerchant'] = NULL;
		$row['TotalAmountForMerchant'] = NULL;
		$row['userpiid'] = NULL;
		$row['shoppingCartID'] = NULL;
		$row['merchantRefID'] = NULL;
		$row['purchaseAmount'] = NULL;
		$row['taxAmount'] = NULL;
		$row['tipAmount'] = NULL;
		$row['discountamount'] = NULL;
		$row['merchantSurcharge'] = NULL;
		$row['serviceFeeToCustomer'] = NULL;
		$row['feeid'] = NULL;
		$row['ratetabletype'] = NULL;
		$row['pis'] = NULL;
		$row['feesystemshare'] = NULL;
		$row['feeexternalshare'] = NULL;
		$row['feefranchiseeshare'] = NULL;
		$row['feeresellershare'] = NULL;
		$row['lastupdatetime'] = NULL;
		$row['officialdocnumber'] = NULL;
		$row['officialdocname'] = NULL;
		$row['businessname'] = NULL;
		$row['logofilename'] = NULL;
		$row['returndays'] = NULL;
		$row['originalpurchaseamount'] = NULL;
		$row['customerpurchaseid'] = NULL;
		$row['clerkFirstName'] = NULL;
		$row['clerkLastName'] = NULL;
		$row['originalMerchantSurcharge'] = NULL;
		$row['originalTaxAmount'] = NULL;
		$row['originalServiceFeeToCustomer'] = NULL;
		$row['originalTotalAmountForCustomer'] = NULL;
		$row['originalServiceFeeToMerchant'] = NULL;
		$row['originalTipAmount'] = NULL;
		$row['userpi'] = NULL;
		return $row;
	}

	// Load old record
	protected function loadOldRecord()
	{

		// Load key values from Session
		$validKey = TRUE;
		if (strval($this->getKey("transferID")) != "")
			$this->transferID->OldValue = $this->getKey("transferID"); // transferID
		else
			$validKey = FALSE;
		if (strval($this->getKey("txid")) != "")
			$this->txid->OldValue = $this->getKey("txid"); // txid
		else
			$validKey = FALSE;

		// Load old record
		$this->OldRecordset = NULL;
		if ($validKey) {
			$this->CurrentFilter = $this->getRecordFilter();
			$sql = $this->getCurrentSql();
			$conn = $this->getConnection();
			$this->OldRecordset = LoadRecordset($sql, $conn);
		}
		$this->loadRowValues($this->OldRecordset); // Load row values
		return $validKey;
	}

	// Render row values based on field settings
	public function renderRow()
	{
		global $Security, $Language, $CurrentLanguage;

		// Initialize URLs
		$this->ViewUrl = $this->getViewUrl();
		$this->EditUrl = $this->getEditUrl();
		$this->InlineEditUrl = $this->getInlineEditUrl();
		$this->CopyUrl = $this->getCopyUrl();
		$this->InlineCopyUrl = $this->getInlineCopyUrl();
		$this->DeleteUrl = $this->getDeleteUrl();

		// Convert decimal values if posted back
		if ($this->TotalAmountForCustomer->FormValue == $this->TotalAmountForCustomer->CurrentValue && is_numeric(ConvertToFloatString($this->TotalAmountForCustomer->CurrentValue)))
			$this->TotalAmountForCustomer->CurrentValue = ConvertToFloatString($this->TotalAmountForCustomer->CurrentValue);

		// Convert decimal values if posted back
		if ($this->serviceFeeToMerchant->FormValue == $this->serviceFeeToMerchant->CurrentValue && is_numeric(ConvertToFloatString($this->serviceFeeToMerchant->CurrentValue)))
			$this->serviceFeeToMerchant->CurrentValue = ConvertToFloatString($this->serviceFeeToMerchant->CurrentValue);

		// Convert decimal values if posted back
		if ($this->TotalAmountForMerchant->FormValue == $this->TotalAmountForMerchant->CurrentValue && is_numeric(ConvertToFloatString($this->TotalAmountForMerchant->CurrentValue)))
			$this->TotalAmountForMerchant->CurrentValue = ConvertToFloatString($this->TotalAmountForMerchant->CurrentValue);

		// Call Row_Rendering event
		$this->Row_Rendering();

		// Common render codes for all row types
		// transferID
		// txid
		// merchantID
		// userID
		// transferTime
		// status
		// currID
		// TotalAmountForCustomer
		// serviceFeeToMerchant
		// TotalAmountForMerchant
		// userpiid
		// shoppingCartID
		// merchantRefID
		// purchaseAmount
		// taxAmount
		// tipAmount
		// discountamount
		// merchantSurcharge
		// serviceFeeToCustomer
		// feeid
		// ratetabletype
		// pis
		// feesystemshare
		// feeexternalshare
		// feefranchiseeshare
		// feeresellershare
		// lastupdatetime
		// officialdocnumber
		// officialdocname
		// businessname
		// logofilename
		// returndays
		// originalpurchaseamount
		// customerpurchaseid
		// clerkFirstName
		// clerkLastName
		// originalMerchantSurcharge
		// originalTaxAmount
		// originalServiceFeeToCustomer
		// originalTotalAmountForCustomer
		// originalServiceFeeToMerchant
		// originalTipAmount
		// userpi
		// Accumulate aggregate value

		if ($this->RowType != ROWTYPE_AGGREGATEINIT && $this->RowType != ROWTYPE_AGGREGATE) {
			if (is_numeric($this->TotalAmountForCustomer->CurrentValue))
				$this->TotalAmountForCustomer->Total += $this->TotalAmountForCustomer->CurrentValue; // Accumulate total
			if (is_numeric($this->serviceFeeToMerchant->CurrentValue))
				$this->serviceFeeToMerchant->Total += $this->serviceFeeToMerchant->CurrentValue; // Accumulate total
			if (is_numeric($this->TotalAmountForMerchant->CurrentValue))
				$this->TotalAmountForMerchant->Total += $this->TotalAmountForMerchant->CurrentValue; // Accumulate total
		}
		if ($this->RowType == ROWTYPE_VIEW) { // View row

			// transferID
			$this->transferID->ViewValue = $this->transferID->CurrentValue;
			$this->transferID->ViewCustomAttributes = "";

			// txid
			$this->txid->ViewValue = $this->txid->CurrentValue;
			$this->txid->ViewCustomAttributes = "";

			// merchantID
			$curVal = strval($this->merchantID->CurrentValue);
			if ($curVal != "") {
				$this->merchantID->ViewValue = $this->merchantID->lookupCacheOption($curVal);
				if ($this->merchantID->ViewValue === NULL) { // Lookup from database
					$filterWrk = "`userid`" . SearchString("=", $curVal, DATATYPE_NUMBER, "");
					$sqlWrk = $this->merchantID->Lookup->getSql(FALSE, $filterWrk, '', $this);
					$rswrk = Conn()->execute($sqlWrk);
					if ($rswrk && !$rswrk->EOF) { // Lookup values found
						$arwrk = [];
						$arwrk[1] = $rswrk->fields('df');
						$this->merchantID->ViewValue = $this->merchantID->displayValue($arwrk);
						$rswrk->Close();
					} else {
						$this->merchantID->ViewValue = $this->merchantID->CurrentValue;
					}
				}
			} else {
				$this->merchantID->ViewValue = NULL;
			}
			$this->merchantID->ViewCustomAttributes = "";

			// userID
			$this->_userID->ViewCustomAttributes = "";

			// transferTime
			$this->transferTime->ViewValue = $this->transferTime->CurrentValue;
			$this->transferTime->ViewValue = FormatDateTime($this->transferTime->ViewValue, 0);
			$this->transferTime->ViewCustomAttributes = "";

			// status
			if (strval($this->status->CurrentValue) != "") {
				$this->status->ViewValue = $this->status->optionCaption($this->status->CurrentValue);
			} else {
				$this->status->ViewValue = NULL;
			}
			$this->status->ViewCustomAttributes = "";

			// currID
			$this->currID->ViewValue = $this->currID->CurrentValue;
			$this->currID->ViewCustomAttributes = "";

			// TotalAmountForCustomer
			$this->TotalAmountForCustomer->ViewValue = $this->TotalAmountForCustomer->CurrentValue;
			$this->TotalAmountForCustomer->ViewValue = FormatCurrency($this->TotalAmountForCustomer->ViewValue, 2, -2, -2, -2);
			$this->TotalAmountForCustomer->CellCssStyle .= "text-align: right;";
			$this->TotalAmountForCustomer->ViewCustomAttributes = "";

			// serviceFeeToMerchant
			$this->serviceFeeToMerchant->ViewValue = $this->serviceFeeToMerchant->CurrentValue;
			$this->serviceFeeToMerchant->ViewValue = FormatCurrency($this->serviceFeeToMerchant->ViewValue, 2, -2, -2, -2);
			$this->serviceFeeToMerchant->CellCssStyle .= "text-align: right;";
			$this->serviceFeeToMerchant->ViewCustomAttributes = "";

			// TotalAmountForMerchant
			$this->TotalAmountForMerchant->ViewValue = $this->TotalAmountForMerchant->CurrentValue;
			$this->TotalAmountForMerchant->ViewValue = FormatCurrency($this->TotalAmountForMerchant->ViewValue, 2, -2, -2, -2);
			$this->TotalAmountForMerchant->CellCssStyle .= "text-align: right;";
			$this->TotalAmountForMerchant->ViewCustomAttributes = "";

			// userpiid
			$curVal = strval($this->userpiid->CurrentValue);
			if ($curVal != "") {
				$this->userpiid->ViewValue = $this->userpiid->lookupCacheOption($curVal);
				if ($this->userpiid->ViewValue === NULL) { // Lookup from database
					$filterWrk = "`id`" . SearchString("=", $curVal, DATATYPE_NUMBER, "_4payreference");
					$sqlWrk = $this->userpiid->Lookup->getSql(FALSE, $filterWrk, '', $this);
					$rswrk = Conn("_4payreference")->execute($sqlWrk);
					if ($rswrk && !$rswrk->EOF) { // Lookup values found
						$arwrk = [];
						$arwrk[1] = $rswrk->fields('df');
						$this->userpiid->ViewValue = $this->userpiid->displayValue($arwrk);
						$rswrk->Close();
					} else {
						$this->userpiid->ViewValue = $this->userpiid->CurrentValue;
					}
				}
			} else {
				$this->userpiid->ViewValue = NULL;
			}
			$this->userpiid->ViewCustomAttributes = "";

			// shoppingCartID
			$this->shoppingCartID->ViewValue = $this->shoppingCartID->CurrentValue;
			$this->shoppingCartID->ViewCustomAttributes = "";

			// merchantRefID
			$this->merchantRefID->ViewValue = $this->merchantRefID->CurrentValue;
			$this->merchantRefID->ViewCustomAttributes = "";

			// purchaseAmount
			$this->purchaseAmount->ViewValue = $this->purchaseAmount->CurrentValue;
			$this->purchaseAmount->ViewValue = FormatNumber($this->purchaseAmount->ViewValue, Config("DEFAULT_DECIMAL_PRECISION"));
			$this->purchaseAmount->ViewCustomAttributes = "";

			// taxAmount
			$this->taxAmount->ViewValue = $this->taxAmount->CurrentValue;
			$this->taxAmount->ViewValue = FormatNumber($this->taxAmount->ViewValue, Config("DEFAULT_DECIMAL_PRECISION"));
			$this->taxAmount->ViewCustomAttributes = "";

			// tipAmount
			$this->tipAmount->ViewValue = $this->tipAmount->CurrentValue;
			$this->tipAmount->ViewValue = FormatNumber($this->tipAmount->ViewValue, Config("DEFAULT_DECIMAL_PRECISION"));
			$this->tipAmount->ViewCustomAttributes = "";

			// discountamount
			$this->discountamount->ViewValue = $this->discountamount->CurrentValue;
			$this->discountamount->ViewValue = FormatNumber($this->discountamount->ViewValue, 2, -2, -2, -2);
			$this->discountamount->ViewCustomAttributes = "";

			// merchantSurcharge
			$this->merchantSurcharge->ViewValue = $this->merchantSurcharge->CurrentValue;
			$this->merchantSurcharge->ViewValue = FormatNumber($this->merchantSurcharge->ViewValue, Config("DEFAULT_DECIMAL_PRECISION"));
			$this->merchantSurcharge->ViewCustomAttributes = "";

			// serviceFeeToCustomer
			$this->serviceFeeToCustomer->ViewValue = $this->serviceFeeToCustomer->CurrentValue;
			$this->serviceFeeToCustomer->ViewValue = FormatNumber($this->serviceFeeToCustomer->ViewValue, Config("DEFAULT_DECIMAL_PRECISION"));
			$this->serviceFeeToCustomer->ViewCustomAttributes = "";

			// feeid
			$this->feeid->ViewValue = $this->feeid->CurrentValue;
			$this->feeid->ViewCustomAttributes = "";

			// ratetabletype
			$this->ratetabletype->ViewValue = $this->ratetabletype->CurrentValue;
			$this->ratetabletype->ViewCustomAttributes = "";

			// feesystemshare
			$this->feesystemshare->ViewValue = $this->feesystemshare->CurrentValue;
			$this->feesystemshare->ViewValue = FormatNumber($this->feesystemshare->ViewValue, Config("DEFAULT_DECIMAL_PRECISION"));
			$this->feesystemshare->ViewCustomAttributes = "";

			// feeexternalshare
			$this->feeexternalshare->ViewValue = $this->feeexternalshare->CurrentValue;
			$this->feeexternalshare->ViewValue = FormatNumber($this->feeexternalshare->ViewValue, Config("DEFAULT_DECIMAL_PRECISION"));
			$this->feeexternalshare->ViewCustomAttributes = "";

			// feefranchiseeshare
			$this->feefranchiseeshare->ViewValue = $this->feefranchiseeshare->CurrentValue;
			$this->feefranchiseeshare->ViewValue = FormatNumber($this->feefranchiseeshare->ViewValue, Config("DEFAULT_DECIMAL_PRECISION"));
			$this->feefranchiseeshare->ViewCustomAttributes = "";

			// feeresellershare
			$this->feeresellershare->ViewValue = $this->feeresellershare->CurrentValue;
			$this->feeresellershare->ViewValue = FormatNumber($this->feeresellershare->ViewValue, Config("DEFAULT_DECIMAL_PRECISION"));
			$this->feeresellershare->ViewCustomAttributes = "";

			// lastupdatetime
			$this->lastupdatetime->ViewValue = $this->lastupdatetime->CurrentValue;
			$this->lastupdatetime->ViewValue = FormatDateTime($this->lastupdatetime->ViewValue, 0);
			$this->lastupdatetime->ViewCustomAttributes = "";

			// officialdocnumber
			$this->officialdocnumber->ViewValue = $this->officialdocnumber->CurrentValue;
			$this->officialdocnumber->ViewCustomAttributes = "";

			// officialdocname
			$this->officialdocname->ViewValue = $this->officialdocname->CurrentValue;
			$this->officialdocname->ViewCustomAttributes = "";

			// businessname
			$this->businessname->ViewValue = $this->businessname->CurrentValue;
			$this->businessname->ViewCustomAttributes = "";

			// logofilename
			$this->logofilename->ViewValue = $this->logofilename->CurrentValue;
			$this->logofilename->ViewCustomAttributes = "";

			// returndays
			$this->returndays->ViewValue = $this->returndays->CurrentValue;
			$this->returndays->ViewCustomAttributes = "";

			// originalpurchaseamount
			$this->originalpurchaseamount->ViewValue = $this->originalpurchaseamount->CurrentValue;
			$this->originalpurchaseamount->ViewValue = FormatNumber($this->originalpurchaseamount->ViewValue, 2, -2, -2, -2);
			$this->originalpurchaseamount->ViewCustomAttributes = "";

			// customerpurchaseid
			$this->customerpurchaseid->ViewValue = $this->customerpurchaseid->CurrentValue;
			$this->customerpurchaseid->ViewValue = FormatNumber($this->customerpurchaseid->ViewValue, 0, -2, -2, -2);
			$this->customerpurchaseid->ViewCustomAttributes = "";

			// clerkFirstName
			$this->clerkFirstName->ViewValue = $this->clerkFirstName->CurrentValue;
			$this->clerkFirstName->ViewCustomAttributes = "";

			// clerkLastName
			$this->clerkLastName->ViewValue = $this->clerkLastName->CurrentValue;
			$this->clerkLastName->ViewCustomAttributes = "";

			// originalMerchantSurcharge
			$this->originalMerchantSurcharge->ViewValue = $this->originalMerchantSurcharge->CurrentValue;
			$this->originalMerchantSurcharge->ViewValue = FormatNumber($this->originalMerchantSurcharge->ViewValue, 2, -2, -2, -2);
			$this->originalMerchantSurcharge->ViewCustomAttributes = "";

			// originalTaxAmount
			$this->originalTaxAmount->ViewValue = $this->originalTaxAmount->CurrentValue;
			$this->originalTaxAmount->ViewValue = FormatNumber($this->originalTaxAmount->ViewValue, 2, -2, -2, -2);
			$this->originalTaxAmount->ViewCustomAttributes = "";

			// originalServiceFeeToCustomer
			$this->originalServiceFeeToCustomer->ViewValue = $this->originalServiceFeeToCustomer->CurrentValue;
			$this->originalServiceFeeToCustomer->ViewValue = FormatNumber($this->originalServiceFeeToCustomer->ViewValue, 2, -2, -2, -2);
			$this->originalServiceFeeToCustomer->ViewCustomAttributes = "";

			// originalTotalAmountForCustomer
			$this->originalTotalAmountForCustomer->ViewValue = $this->originalTotalAmountForCustomer->CurrentValue;
			$this->originalTotalAmountForCustomer->ViewValue = FormatNumber($this->originalTotalAmountForCustomer->ViewValue, 2, -2, -2, -2);
			$this->originalTotalAmountForCustomer->ViewCustomAttributes = "";

			// originalServiceFeeToMerchant
			$this->originalServiceFeeToMerchant->ViewValue = $this->originalServiceFeeToMerchant->CurrentValue;
			$this->originalServiceFeeToMerchant->ViewValue = FormatNumber($this->originalServiceFeeToMerchant->ViewValue, 2, -2, -2, -2);
			$this->originalServiceFeeToMerchant->ViewCustomAttributes = "";

			// originalTipAmount
			$this->originalTipAmount->ViewValue = $this->originalTipAmount->CurrentValue;
			$this->originalTipAmount->ViewValue = FormatNumber($this->originalTipAmount->ViewValue, 2, -2, -2, -2);
			$this->originalTipAmount->ViewCustomAttributes = "";

			// userpi
			$this->userpi->ViewValue = $this->userpi->CurrentValue;
			$this->userpi->ViewValue = FormatNumber($this->userpi->ViewValue, 0, -2, -2, -2);
			$this->userpi->ViewCustomAttributes = "";

			// transferID
			$this->transferID->LinkCustomAttributes = "";
			$this->transferID->HrefValue = "";
			$this->transferID->TooltipValue = "";

			// txid
			$this->txid->LinkCustomAttributes = "";
			$this->txid->HrefValue = "";
			$this->txid->TooltipValue = "";

			// merchantID
			$this->merchantID->LinkCustomAttributes = "";
			$this->merchantID->HrefValue = "";
			$this->merchantID->TooltipValue = "";

			// transferTime
			$this->transferTime->LinkCustomAttributes = "";
			$this->transferTime->HrefValue = "";
			$this->transferTime->TooltipValue = "";

			// status
			$this->status->LinkCustomAttributes = "";
			$this->status->HrefValue = "";
			$this->status->TooltipValue = "";

			// currID
			$this->currID->LinkCustomAttributes = "";
			$this->currID->HrefValue = "";
			$this->currID->TooltipValue = "";

			// TotalAmountForCustomer
			$this->TotalAmountForCustomer->LinkCustomAttributes = "";
			$this->TotalAmountForCustomer->HrefValue = "";
			$this->TotalAmountForCustomer->TooltipValue = "";

			// serviceFeeToMerchant
			$this->serviceFeeToMerchant->LinkCustomAttributes = "";
			$this->serviceFeeToMerchant->HrefValue = "";
			$this->serviceFeeToMerchant->TooltipValue = "";

			// TotalAmountForMerchant
			$this->TotalAmountForMerchant->LinkCustomAttributes = "";
			$this->TotalAmountForMerchant->HrefValue = "";
			$this->TotalAmountForMerchant->TooltipValue = "";

			// userpiid
			$this->userpiid->LinkCustomAttributes = "";
			$this->userpiid->HrefValue = "";
			$this->userpiid->TooltipValue = "";

			// shoppingCartID
			$this->shoppingCartID->LinkCustomAttributes = "";
			$this->shoppingCartID->HrefValue = "";
			$this->shoppingCartID->TooltipValue = "";

			// merchantRefID
			$this->merchantRefID->LinkCustomAttributes = "";
			$this->merchantRefID->HrefValue = "";
			$this->merchantRefID->TooltipValue = "";

			// userpi
			$this->userpi->LinkCustomAttributes = "";
			$this->userpi->HrefValue = "";
			$this->userpi->TooltipValue = "";
		} elseif ($this->RowType == ROWTYPE_SEARCH) { // Search row

			// transferID
			$this->transferID->EditAttrs["class"] = "form-control";
			$this->transferID->EditCustomAttributes = "";
			$this->transferID->EditValue = HtmlEncode($this->transferID->AdvancedSearch->SearchValue);
			$this->transferID->PlaceHolder = RemoveHtml($this->transferID->caption());

			// txid
			$this->txid->EditAttrs["class"] = "form-control";
			$this->txid->EditCustomAttributes = "";
			if (!$this->txid->Raw)
				$this->txid->AdvancedSearch->SearchValue = HtmlDecode($this->txid->AdvancedSearch->SearchValue);
			$this->txid->EditValue = HtmlEncode($this->txid->AdvancedSearch->SearchValue);
			$this->txid->PlaceHolder = RemoveHtml($this->txid->caption());

			// merchantID
			$this->merchantID->EditAttrs["class"] = "form-control";
			$this->merchantID->EditCustomAttributes = "";
			$curVal = trim(strval($this->merchantID->AdvancedSearch->SearchValue));
			if ($curVal != "")
				$this->merchantID->AdvancedSearch->ViewValue = $this->merchantID->lookupCacheOption($curVal);
			else
				$this->merchantID->AdvancedSearch->ViewValue = $this->merchantID->Lookup !== NULL && is_array($this->merchantID->Lookup->Options) ? $curVal : NULL;
			if ($this->merchantID->AdvancedSearch->ViewValue !== NULL) { // Load from cache
				$this->merchantID->EditValue = array_values($this->merchantID->Lookup->Options);
			} else { // Lookup from database
				if ($curVal == "") {
					$filterWrk = "0=1";
				} else {
					$filterWrk = "`userid`" . SearchString("=", $this->merchantID->AdvancedSearch->SearchValue, DATATYPE_NUMBER, "");
				}
				$sqlWrk = $this->merchantID->Lookup->getSql(TRUE, $filterWrk, '', $this);
				$rswrk = Conn()->execute($sqlWrk);
				$arwrk = $rswrk ? $rswrk->getRows() : [];
				if ($rswrk)
					$rswrk->close();
				$this->merchantID->EditValue = $arwrk;
			}

			// transferTime
			$this->transferTime->EditAttrs["class"] = "form-control";
			$this->transferTime->EditCustomAttributes = "";
			$this->transferTime->EditValue = HtmlEncode(FormatDateTime(UnFormatDateTime($this->transferTime->AdvancedSearch->SearchValue, 0), 8));
			$this->transferTime->PlaceHolder = RemoveHtml($this->transferTime->caption());
			$this->transferTime->EditAttrs["class"] = "form-control";
			$this->transferTime->EditCustomAttributes = "";
			$this->transferTime->EditValue2 = HtmlEncode(FormatDateTime(UnFormatDateTime($this->transferTime->AdvancedSearch->SearchValue2, 0), 8));
			$this->transferTime->PlaceHolder = RemoveHtml($this->transferTime->caption());

			// status
			$this->status->EditAttrs["class"] = "form-control";
			$this->status->EditCustomAttributes = "";
			$this->status->EditValue = $this->status->options(TRUE);

			// currID
			$this->currID->EditAttrs["class"] = "form-control";
			$this->currID->EditCustomAttributes = "";
			if (!$this->currID->Raw)
				$this->currID->AdvancedSearch->SearchValue = HtmlDecode($this->currID->AdvancedSearch->SearchValue);
			$this->currID->EditValue = HtmlEncode($this->currID->AdvancedSearch->SearchValue);
			$this->currID->PlaceHolder = RemoveHtml($this->currID->caption());

			// TotalAmountForCustomer
			$this->TotalAmountForCustomer->EditAttrs["class"] = "form-control";
			$this->TotalAmountForCustomer->EditCustomAttributes = "";
			$this->TotalAmountForCustomer->EditValue = HtmlEncode($this->TotalAmountForCustomer->AdvancedSearch->SearchValue);
			$this->TotalAmountForCustomer->PlaceHolder = RemoveHtml($this->TotalAmountForCustomer->caption());
			$this->TotalAmountForCustomer->EditAttrs["class"] = "form-control";
			$this->TotalAmountForCustomer->EditCustomAttributes = "";
			$this->TotalAmountForCustomer->EditValue2 = HtmlEncode($this->TotalAmountForCustomer->AdvancedSearch->SearchValue2);
			$this->TotalAmountForCustomer->PlaceHolder = RemoveHtml($this->TotalAmountForCustomer->caption());

			// serviceFeeToMerchant
			$this->serviceFeeToMerchant->EditAttrs["class"] = "form-control";
			$this->serviceFeeToMerchant->EditCustomAttributes = "";
			$this->serviceFeeToMerchant->EditValue = HtmlEncode($this->serviceFeeToMerchant->AdvancedSearch->SearchValue);
			$this->serviceFeeToMerchant->PlaceHolder = RemoveHtml($this->serviceFeeToMerchant->caption());
			$this->serviceFeeToMerchant->EditAttrs["class"] = "form-control";
			$this->serviceFeeToMerchant->EditCustomAttributes = "";
			$this->serviceFeeToMerchant->EditValue2 = HtmlEncode($this->serviceFeeToMerchant->AdvancedSearch->SearchValue2);
			$this->serviceFeeToMerchant->PlaceHolder = RemoveHtml($this->serviceFeeToMerchant->caption());

			// TotalAmountForMerchant
			$this->TotalAmountForMerchant->EditAttrs["class"] = "form-control";
			$this->TotalAmountForMerchant->EditCustomAttributes = "";
			$this->TotalAmountForMerchant->EditValue = HtmlEncode($this->TotalAmountForMerchant->AdvancedSearch->SearchValue);
			$this->TotalAmountForMerchant->PlaceHolder = RemoveHtml($this->TotalAmountForMerchant->caption());
			$this->TotalAmountForMerchant->EditAttrs["class"] = "form-control";
			$this->TotalAmountForMerchant->EditCustomAttributes = "";
			$this->TotalAmountForMerchant->EditValue2 = HtmlEncode($this->TotalAmountForMerchant->AdvancedSearch->SearchValue2);
			$this->TotalAmountForMerchant->PlaceHolder = RemoveHtml($this->TotalAmountForMerchant->caption());

			// userpiid
			$this->userpiid->EditAttrs["class"] = "form-control";
			$this->userpiid->EditCustomAttributes = "";
			$curVal = trim(strval($this->userpiid->AdvancedSearch->SearchValue));
			if ($curVal != "")
				$this->userpiid->AdvancedSearch->ViewValue = $this->userpiid->lookupCacheOption($curVal);
			else
				$this->userpiid->AdvancedSearch->ViewValue = $this->userpiid->Lookup !== NULL && is_array($this->userpiid->Lookup->Options) ? $curVal : NULL;
			if ($this->userpiid->AdvancedSearch->ViewValue !== NULL) { // Load from cache
				$this->userpiid->EditValue = array_values($this->userpiid->Lookup->Options);
			} else { // Lookup from database
				if ($curVal == "") {
					$filterWrk = "0=1";
				} else {
					$filterWrk = "`id`" . SearchString("=", $this->userpiid->AdvancedSearch->SearchValue, DATATYPE_NUMBER, "_4payreference");
				}
				$sqlWrk = $this->userpiid->Lookup->getSql(TRUE, $filterWrk, '', $this);
				$rswrk = Conn("_4payreference")->execute($sqlWrk);
				$arwrk = $rswrk ? $rswrk->getRows() : [];
				if ($rswrk)
					$rswrk->close();
				$this->userpiid->EditValue = $arwrk;
			}

			// shoppingCartID
			$this->shoppingCartID->EditAttrs["class"] = "form-control";
			$this->shoppingCartID->EditCustomAttributes = "";
			if (!$this->shoppingCartID->Raw)
				$this->shoppingCartID->AdvancedSearch->SearchValue = HtmlDecode($this->shoppingCartID->AdvancedSearch->SearchValue);
			$this->shoppingCartID->EditValue = HtmlEncode($this->shoppingCartID->AdvancedSearch->SearchValue);
			$this->shoppingCartID->PlaceHolder = RemoveHtml($this->shoppingCartID->caption());

			// merchantRefID
			$this->merchantRefID->EditAttrs["class"] = "form-control";
			$this->merchantRefID->EditCustomAttributes = "";
			if (!$this->merchantRefID->Raw)
				$this->merchantRefID->AdvancedSearch->SearchValue = HtmlDecode($this->merchantRefID->AdvancedSearch->SearchValue);
			$this->merchantRefID->EditValue = HtmlEncode($this->merchantRefID->AdvancedSearch->SearchValue);
			$this->merchantRefID->PlaceHolder = RemoveHtml($this->merchantRefID->caption());

			// userpi
			$this->userpi->EditAttrs["class"] = "form-control";
			$this->userpi->EditCustomAttributes = "";
			$this->userpi->EditValue = HtmlEncode($this->userpi->AdvancedSearch->SearchValue);
			$this->userpi->PlaceHolder = RemoveHtml($this->userpi->caption());
		} elseif ($this->RowType == ROWTYPE_AGGREGATEINIT) { // Initialize aggregate row
			$this->TotalAmountForCustomer->Total = 0; // Initialize total
			$this->serviceFeeToMerchant->Total = 0; // Initialize total
			$this->TotalAmountForMerchant->Total = 0; // Initialize total
		} elseif ($this->RowType == ROWTYPE_AGGREGATE) { // Aggregate row
			$this->TotalAmountForCustomer->CurrentValue = $this->TotalAmountForCustomer->Total;
			$this->TotalAmountForCustomer->ViewValue = $this->TotalAmountForCustomer->CurrentValue;
			$this->TotalAmountForCustomer->ViewValue = FormatCurrency($this->TotalAmountForCustomer->ViewValue, 2, -2, -2, -2);
			$this->TotalAmountForCustomer->CellCssStyle .= "text-align: right;";
			$this->TotalAmountForCustomer->ViewCustomAttributes = "";
			$this->TotalAmountForCustomer->HrefValue = ""; // Clear href value
			$this->serviceFeeToMerchant->CurrentValue = $this->serviceFeeToMerchant->Total;
			$this->serviceFeeToMerchant->ViewValue = $this->serviceFeeToMerchant->CurrentValue;
			$this->serviceFeeToMerchant->ViewValue = FormatCurrency($this->serviceFeeToMerchant->ViewValue, 2, -2, -2, -2);
			$this->serviceFeeToMerchant->CellCssStyle .= "text-align: right;";
			$this->serviceFeeToMerchant->ViewCustomAttributes = "";
			$this->serviceFeeToMerchant->HrefValue = ""; // Clear href value
			$this->TotalAmountForMerchant->CurrentValue = $this->TotalAmountForMerchant->Total;
			$this->TotalAmountForMerchant->ViewValue = $this->TotalAmountForMerchant->CurrentValue;
			$this->TotalAmountForMerchant->ViewValue = FormatCurrency($this->TotalAmountForMerchant->ViewValue, 2, -2, -2, -2);
			$this->TotalAmountForMerchant->CellCssStyle .= "text-align: right;";
			$this->TotalAmountForMerchant->ViewCustomAttributes = "";
			$this->TotalAmountForMerchant->HrefValue = ""; // Clear href value
		}
		if ($this->RowType == ROWTYPE_ADD || $this->RowType == ROWTYPE_EDIT || $this->RowType == ROWTYPE_SEARCH) // Add/Edit/Search row
			$this->setupFieldTitles();

		// Call Row Rendered event
		if ($this->RowType != ROWTYPE_AGGREGATEINIT)
			$this->Row_Rendered();
	}

	// Validate search
	protected function validateSearch()
	{
		global $SearchError;

		// Initialize
		$SearchError = "";

		// Check if validation required
		if (!Config("SERVER_VALIDATE"))
			return TRUE;
		if (!CheckDate($this->transferTime->AdvancedSearch->SearchValue)) {
			AddMessage($SearchError, $this->transferTime->errorMessage());
		}
		if (!CheckDate($this->transferTime->AdvancedSearch->SearchValue2)) {
			AddMessage($SearchError, $this->transferTime->errorMessage());
		}
		if (!CheckNumber($this->TotalAmountForCustomer->AdvancedSearch->SearchValue)) {
			AddMessage($SearchError, $this->TotalAmountForCustomer->errorMessage());
		}
		if (!CheckNumber($this->TotalAmountForCustomer->AdvancedSearch->SearchValue2)) {
			AddMessage($SearchError, $this->TotalAmountForCustomer->errorMessage());
		}
		if (!CheckNumber($this->serviceFeeToMerchant->AdvancedSearch->SearchValue)) {
			AddMessage($SearchError, $this->serviceFeeToMerchant->errorMessage());
		}
		if (!CheckNumber($this->serviceFeeToMerchant->AdvancedSearch->SearchValue2)) {
			AddMessage($SearchError, $this->serviceFeeToMerchant->errorMessage());
		}
		if (!CheckNumber($this->TotalAmountForMerchant->AdvancedSearch->SearchValue)) {
			AddMessage($SearchError, $this->TotalAmountForMerchant->errorMessage());
		}
		if (!CheckNumber($this->TotalAmountForMerchant->AdvancedSearch->SearchValue2)) {
			AddMessage($SearchError, $this->TotalAmountForMerchant->errorMessage());
		}

		// Return validate result
		$validateSearch = ($SearchError == "");

		// Call Form_CustomValidate event
		$formCustomError = "";
		$validateSearch = $validateSearch && $this->Form_CustomValidate($formCustomError);
		if ($formCustomError != "") {
			AddMessage($SearchError, $formCustomError);
		}
		return $validateSearch;
	}

	// Load advanced search
	public function loadAdvancedSearch()
	{
		$this->transferID->AdvancedSearch->load();
		$this->txid->AdvancedSearch->load();
		$this->merchantID->AdvancedSearch->load();
		$this->_userID->AdvancedSearch->load();
		$this->transferTime->AdvancedSearch->load();
		$this->status->AdvancedSearch->load();
		$this->currID->AdvancedSearch->load();
		$this->TotalAmountForCustomer->AdvancedSearch->load();
		$this->serviceFeeToMerchant->AdvancedSearch->load();
		$this->TotalAmountForMerchant->AdvancedSearch->load();
		$this->userpiid->AdvancedSearch->load();
		$this->shoppingCartID->AdvancedSearch->load();
		$this->merchantRefID->AdvancedSearch->load();
		$this->purchaseAmount->AdvancedSearch->load();
		$this->taxAmount->AdvancedSearch->load();
		$this->tipAmount->AdvancedSearch->load();
		$this->discountamount->AdvancedSearch->load();
		$this->merchantSurcharge->AdvancedSearch->load();
		$this->serviceFeeToCustomer->AdvancedSearch->load();
		$this->feeid->AdvancedSearch->load();
		$this->ratetabletype->AdvancedSearch->load();
		$this->pis->AdvancedSearch->load();
		$this->feesystemshare->AdvancedSearch->load();
		$this->feeexternalshare->AdvancedSearch->load();
		$this->feefranchiseeshare->AdvancedSearch->load();
		$this->feeresellershare->AdvancedSearch->load();
		$this->lastupdatetime->AdvancedSearch->load();
		$this->officialdocnumber->AdvancedSearch->load();
		$this->officialdocname->AdvancedSearch->load();
		$this->businessname->AdvancedSearch->load();
		$this->logofilename->AdvancedSearch->load();
		$this->returndays->AdvancedSearch->load();
		$this->originalpurchaseamount->AdvancedSearch->load();
		$this->customerpurchaseid->AdvancedSearch->load();
		$this->clerkFirstName->AdvancedSearch->load();
		$this->clerkLastName->AdvancedSearch->load();
		$this->originalMerchantSurcharge->AdvancedSearch->load();
		$this->originalTaxAmount->AdvancedSearch->load();
		$this->originalServiceFeeToCustomer->AdvancedSearch->load();
		$this->originalTotalAmountForCustomer->AdvancedSearch->load();
		$this->originalServiceFeeToMerchant->AdvancedSearch->load();
		$this->originalTipAmount->AdvancedSearch->load();
		$this->userpi->AdvancedSearch->load();
	}

	// Get export HTML tag
	protected function getExportTag($type, $custom = FALSE)
	{
		global $Language;
		if (SameText($type, "excel")) {
			if ($custom)
				return "<a href=\"#\" class=\"ew-export-link ew-excel\" title=\"" . HtmlEncode($Language->phrase("ExportToExcelText")) . "\" data-caption=\"" . HtmlEncode($Language->phrase("ExportToExcelText")) . "\" onclick=\"return ew.export(document.fvmerchantsaleslist, '" . $this->ExportExcelUrl . "', 'excel', true);\">" . $Language->phrase("ExportToExcel") . "</a>";
			else
				return "<a href=\"" . $this->ExportExcelUrl . "\" class=\"ew-export-link ew-excel\" title=\"" . HtmlEncode($Language->phrase("ExportToExcelText")) . "\" data-caption=\"" . HtmlEncode($Language->phrase("ExportToExcelText")) . "\">" . $Language->phrase("ExportToExcel") . "</a>";
		} elseif (SameText($type, "word")) {
			if ($custom)
				return "<a href=\"#\" class=\"ew-export-link ew-word\" title=\"" . HtmlEncode($Language->phrase("ExportToWordText")) . "\" data-caption=\"" . HtmlEncode($Language->phrase("ExportToWordText")) . "\" onclick=\"return ew.export(document.fvmerchantsaleslist, '" . $this->ExportWordUrl . "', 'word', true);\">" . $Language->phrase("ExportToWord") . "</a>";
			else
				return "<a href=\"" . $this->ExportWordUrl . "\" class=\"ew-export-link ew-word\" title=\"" . HtmlEncode($Language->phrase("ExportToWordText")) . "\" data-caption=\"" . HtmlEncode($Language->phrase("ExportToWordText")) . "\">" . $Language->phrase("ExportToWord") . "</a>";
		} elseif (SameText($type, "pdf")) {
			if ($custom)
				return "<a href=\"#\" class=\"ew-export-link ew-pdf\" title=\"" . HtmlEncode($Language->phrase("ExportToPDFText")) . "\" data-caption=\"" . HtmlEncode($Language->phrase("ExportToPDFText")) . "\" onclick=\"return ew.export(document.fvmerchantsaleslist, '" . $this->ExportPdfUrl . "', 'pdf', true);\">" . $Language->phrase("ExportToPDF") . "</a>";
			else
				return "<a href=\"" . $this->ExportPdfUrl . "\" class=\"ew-export-link ew-pdf\" title=\"" . HtmlEncode($Language->phrase("ExportToPDFText")) . "\" data-caption=\"" . HtmlEncode($Language->phrase("ExportToPDFText")) . "\">" . $Language->phrase("ExportToPDF") . "</a>";
		} elseif (SameText($type, "html")) {
			return "<a href=\"" . $this->ExportHtmlUrl . "\" class=\"ew-export-link ew-html\" title=\"" . HtmlEncode($Language->phrase("ExportToHtmlText")) . "\" data-caption=\"" . HtmlEncode($Language->phrase("ExportToHtmlText")) . "\">" . $Language->phrase("ExportToHtml") . "</a>";
		} elseif (SameText($type, "xml")) {
			return "<a href=\"" . $this->ExportXmlUrl . "\" class=\"ew-export-link ew-xml\" title=\"" . HtmlEncode($Language->phrase("ExportToXmlText")) . "\" data-caption=\"" . HtmlEncode($Language->phrase("ExportToXmlText")) . "\">" . $Language->phrase("ExportToXml") . "</a>";
		} elseif (SameText($type, "csv")) {
			return "<a href=\"" . $this->ExportCsvUrl . "\" class=\"ew-export-link ew-csv\" title=\"" . HtmlEncode($Language->phrase("ExportToCsvText")) . "\" data-caption=\"" . HtmlEncode($Language->phrase("ExportToCsvText")) . "\">" . $Language->phrase("ExportToCsv") . "</a>";
		} elseif (SameText($type, "email")) {
			$url = $custom ? ",url:'" . $this->pageUrl() . "export=email&amp;custom=1'" : "";
			return '<button id="emf_vmerchantsales" class="ew-export-link ew-email" title="' . $Language->phrase("ExportToEmailText") . '" data-caption="' . $Language->phrase("ExportToEmailText") . '" onclick="ew.emailDialogShow({lnk:\'emf_vmerchantsales\', hdr:ew.language.phrase(\'ExportToEmailText\'), f:document.fvmerchantsaleslist, sel:false' . $url . '});">' . $Language->phrase("ExportToEmail") . '</button>';
		} elseif (SameText($type, "print")) {
			return "<a href=\"" . $this->ExportPrintUrl . "\" class=\"ew-export-link ew-print\" title=\"" . HtmlEncode($Language->phrase("PrinterFriendlyText")) . "\" data-caption=\"" . HtmlEncode($Language->phrase("PrinterFriendlyText")) . "\">" . $Language->phrase("PrinterFriendly") . "</a>";
		}
	}

	// Set up export options
	protected function setupExportOptions()
	{
		global $Language;

		// Printer friendly
		$item = &$this->ExportOptions->add("print");
		$item->Body = $this->getExportTag("print");
		$item->Visible = TRUE;

		// Export to Excel
		$item = &$this->ExportOptions->add("excel");
		$item->Body = $this->getExportTag("excel");
		$item->Visible = TRUE;

		// Export to Word
		$item = &$this->ExportOptions->add("word");
		$item->Body = $this->getExportTag("word");
		$item->Visible = TRUE;

		// Export to Html
		$item = &$this->ExportOptions->add("html");
		$item->Body = $this->getExportTag("html");
		$item->Visible = TRUE;

		// Export to Xml
		$item = &$this->ExportOptions->add("xml");
		$item->Body = $this->getExportTag("xml");
		$item->Visible = FALSE;

		// Export to Csv
		$item = &$this->ExportOptions->add("csv");
		$item->Body = $this->getExportTag("csv");
		$item->Visible = TRUE;

		// Export to Pdf
		$item = &$this->ExportOptions->add("pdf");
		$item->Body = $this->getExportTag("pdf");
		$item->Visible = FALSE;

		// Export to Email
		$item = &$this->ExportOptions->add("email");
		$item->Body = $this->getExportTag("email");
		$item->Visible = TRUE;

		// Drop down button for export
		$this->ExportOptions->UseButtonGroup = TRUE;
		$this->ExportOptions->UseDropDownButton = TRUE;
		if ($this->ExportOptions->UseButtonGroup && IsMobile())
			$this->ExportOptions->UseDropDownButton = TRUE;
		$this->ExportOptions->DropDownButtonPhrase = $Language->phrase("ButtonExport");

		// Add group option item
		$item = &$this->ExportOptions->add($this->ExportOptions->GroupOptionName);
		$item->Body = "";
		$item->Visible = FALSE;
	}

	// Set up search options
	protected function setupSearchOptions()
	{
		global $Language;
		$this->SearchOptions = new ListOptions("div");
		$this->SearchOptions->TagClassName = "ew-search-option";

		// Search button
		$item = &$this->SearchOptions->add("searchtoggle");
		$searchToggleClass = ($this->SearchWhere != "") ? " active" : "";
		$item->Body = "<a class=\"btn btn-default ew-search-toggle" . $searchToggleClass . "\" href=\"#\" role=\"button\" title=\"" . $Language->phrase("SearchPanel") . "\" data-caption=\"" . $Language->phrase("SearchPanel") . "\" data-toggle=\"button\" data-form=\"fvmerchantsaleslistsrch\" aria-pressed=\"" . ($searchToggleClass == " active" ? "true" : "false") . "\">" . $Language->phrase("SearchLink") . "</a>";
		$item->Visible = TRUE;

		// Show all button
		$item = &$this->SearchOptions->add("showall");
		$item->Body = "<a class=\"btn btn-default ew-show-all\" title=\"" . $Language->phrase("ShowAll") . "\" data-caption=\"" . $Language->phrase("ShowAll") . "\" href=\"" . $this->pageUrl() . "cmd=reset\">" . $Language->phrase("ShowAllBtn") . "</a>";
		$item->Visible = ($this->SearchWhere != $this->DefaultSearchWhere && $this->SearchWhere != "0=101");

		// Advanced search button
		$item = &$this->SearchOptions->add("advancedsearch");
		$item->Body = "<a class=\"btn btn-default ew-advanced-search\" title=\"" . $Language->phrase("AdvancedSearch") . "\" data-caption=\"" . $Language->phrase("AdvancedSearch") . "\" href=\"vmerchantsalessrch.php\">" . $Language->phrase("AdvancedSearchBtn") . "</a>";
		$item->Visible = TRUE;

		// Button group for search
		$this->SearchOptions->UseDropDownButton = FALSE;
		$this->SearchOptions->UseButtonGroup = TRUE;
		$this->SearchOptions->DropDownButtonPhrase = $Language->phrase("ButtonSearch");

		// Add group option item
		$item = &$this->SearchOptions->add($this->SearchOptions->GroupOptionName);
		$item->Body = "";
		$item->Visible = FALSE;

		// Hide search options
		if ($this->isExport() || $this->CurrentAction)
			$this->SearchOptions->hideAllOptions();
		global $Security;
		if (!$Security->canSearch()) {
			$this->SearchOptions->hideAllOptions();
			$this->FilterOptions->hideAllOptions();
		}
	}

	/**
	 * Export data in HTML/CSV/Word/Excel/XML/Email/PDF format
	 *
	 * @param boolean $return Return the data rather than output it
	 * @return mixed
	 */
	public function exportData($return = FALSE)
	{
		global $Language;
		$utf8 = SameText(Config("PROJECT_CHARSET"), "utf-8");
		$selectLimit = $this->UseSelectLimit;

		// Load recordset
		if ($selectLimit) {
			$this->TotalRecords = $this->listRecordCount();
		} else {
			if (!$this->Recordset)
				$this->Recordset = $this->loadRecordset();
			$rs = &$this->Recordset;
			if ($rs)
				$this->TotalRecords = $rs->RecordCount();
		}
		$this->StartRecord = 1;

		// Export all
		if ($this->ExportAll) {
			set_time_limit(Config("EXPORT_ALL_TIME_LIMIT"));
			$this->DisplayRecords = $this->TotalRecords;
			$this->StopRecord = $this->TotalRecords;
		} else { // Export one page only
			$this->setupStartRecord(); // Set up start record position

			// Set the last record to display
			if ($this->DisplayRecords <= 0) {
				$this->StopRecord = $this->TotalRecords;
			} else {
				$this->StopRecord = $this->StartRecord + $this->DisplayRecords - 1;
			}
		}
		if ($selectLimit)
			$rs = $this->loadRecordset($this->StartRecord - 1, $this->DisplayRecords <= 0 ? $this->TotalRecords : $this->DisplayRecords);
		$this->ExportDoc = GetExportDocument($this, "h");
		$doc = &$this->ExportDoc;
		if (!$doc)
			$this->setFailureMessage($Language->phrase("ExportClassNotFound")); // Export class not found
		if (!$rs || !$doc) {
			RemoveHeader("Content-Type"); // Remove header
			RemoveHeader("Content-Disposition");
			$this->showMessage();
			return;
		}
		if ($selectLimit) {
			$this->StartRecord = 1;
			$this->StopRecord = $this->DisplayRecords <= 0 ? $this->TotalRecords : $this->DisplayRecords;
		}

		// Call Page Exporting server event
		$this->ExportDoc->ExportCustom = !$this->Page_Exporting();
		$header = $this->PageHeader;
		$this->Page_DataRendering($header);
		$doc->Text .= $header;
		$this->exportDocument($doc, $rs, $this->StartRecord, $this->StopRecord, "");
		$footer = $this->PageFooter;
		$this->Page_DataRendered($footer);
		$doc->Text .= $footer;

		// Close recordset
		$rs->close();

		// Call Page Exported server event
		$this->Page_Exported();

		// Export header and footer
		$doc->exportHeaderAndFooter();

		// Clean output buffer (without destroying output buffer)
		$buffer = ob_get_contents(); // Save the output buffer
		if (!Config("DEBUG") && $buffer)
			ob_clean();

		// Write debug message if enabled
		if (Config("DEBUG") && !$this->isExport("pdf"))
			echo GetDebugMessage();

		// Output data
		if ($this->isExport("email")) {
			if ($return)
				return $doc->Text; // Return email content
			else
				echo $this->exportEmail($doc->Text); // Send email
		} else {
			$doc->export();
			if ($return) {
				RemoveHeader("Content-Type"); // Remove header
				RemoveHeader("Content-Disposition");
				$content = ob_get_contents();
				if ($content)
					ob_clean();
				if ($buffer)
					echo $buffer; // Resume the output buffer
				return $content;
			}
		}
	}

	// Export email
	protected function exportEmail($emailContent)
	{
		global $TempImages, $Language;
		$sender = Post("sender", "");
		$recipient = Post("recipient", "");
		$cc = Post("cc", "");
		$bcc = Post("bcc", "");

		// Subject
		$subject = Post("subject", "");
		$emailSubject = $subject;

		// Message
		$content = Post("message", "");
		$emailMessage = $content;

		// Check sender
		if ($sender == "") {
			return "<p class=\"text-danger\">" . $Language->phrase("EnterSenderEmail") . "</p>";
		}
		if (!CheckEmail($sender)) {
			return "<p class=\"text-danger\">" . $Language->phrase("EnterProperSenderEmail") . "</p>";
		}

		// Check recipient
		if (!CheckEmailList($recipient, Config("MAX_EMAIL_RECIPIENT"))) {
			return "<p class=\"text-danger\">" . $Language->phrase("EnterProperRecipientEmail") . "</p>";
		}

		// Check cc
		if (!CheckEmailList($cc, Config("MAX_EMAIL_RECIPIENT"))) {
			return "<p class=\"text-danger\">" . $Language->phrase("EnterProperCcEmail") . "</p>";
		}

		// Check bcc
		if (!CheckEmailList($bcc, Config("MAX_EMAIL_RECIPIENT"))) {
			return "<p class=\"text-danger\">" . $Language->phrase("EnterProperBccEmail") . "</p>";
		}

		// Check email sent count
		if (!isset($_SESSION[Config("EXPORT_EMAIL_COUNTER")]))
			$_SESSION[Config("EXPORT_EMAIL_COUNTER")] = 0;
		if ((int)$_SESSION[Config("EXPORT_EMAIL_COUNTER")] > Config("MAX_EMAIL_SENT_COUNT")) {
			return "<p class=\"text-danger\">" . $Language->phrase("ExceedMaxEmailExport") . "</p>";
		}

		// Send email
		$email = new Email();
		$email->Sender = $sender; // Sender
		$email->Recipient = $recipient; // Recipient
		$email->Cc = $cc; // Cc
		$email->Bcc = $bcc; // Bcc
		$email->Subject = $emailSubject; // Subject
		$email->Format = "html";
		if ($emailMessage != "")
			$emailMessage = RemoveXss($emailMessage) . "<br><br>";
		foreach ($TempImages as $tmpImage)
			$email->addEmbeddedImage($tmpImage);
		$email->Content = $emailMessage . CleanEmailContent($emailContent); // Content
		$eventArgs = [];
		if ($this->Recordset)
			$eventArgs["rs"] = &$this->Recordset;
		$emailSent = FALSE;
		if ($this->Email_Sending($email, $eventArgs))
			$emailSent = $email->send();

		// Check email sent status
		if ($emailSent) {

			// Update email sent count
			$_SESSION[Config("EXPORT_EMAIL_COUNTER")]++;

			// Sent email success
			return "<p class=\"text-success\">" . $Language->phrase("SendEmailSuccess") . "</p>"; // Set up success message
		} else {

			// Sent email failure
			return "<p class=\"text-danger\">" . $email->SendErrDescription . "</p>";
		}
	}

	// Set up Breadcrumb
	protected function setupBreadcrumb()
	{
		global $Breadcrumb, $Language;
		$Breadcrumb = new Breadcrumb();
		$url = substr(CurrentUrl(), strrpos(CurrentUrl(), "/")+1);
		$url = preg_replace('/\?cmd=reset(all){0,1}$/i', '', $url); // Remove cmd=reset / cmd=resetall
		$Breadcrumb->add("list", $this->TableVar, $url, "", $this->TableVar, TRUE);
	}

	// Setup lookup options
	public function setupLookupOptions($fld)
	{
		if ($fld->Lookup !== NULL && $fld->Lookup->Options === NULL) {

			// Get default connection and filter
			$conn = $this->getConnection();
			$lookupFilter = "";

			// No need to check any more
			$fld->Lookup->Options = [];

			// Set up lookup SQL and connection
			switch ($fld->FieldVar) {
				case "x_merchantID":
					break;
				case "x_status":
					break;
				case "x_userpiid":
					$conn = Conn("_4payreference");
					break;
				default:
					$lookupFilter = "";
					break;
			}

			// Always call to Lookup->getSql so that user can setup Lookup->Options in Lookup_Selecting server event
			$sql = $fld->Lookup->getSql(FALSE, "", $lookupFilter, $this);

			// Set up lookup cache
			if ($fld->UseLookupCache && $sql != "" && count($fld->Lookup->Options) == 0) {
				$totalCnt = $this->getRecordCount($sql, $conn);
				if ($totalCnt > $fld->LookupCacheCount) // Total count > cache count, do not cache
					return;
				$rs = $conn->execute($sql);
				$ar = [];
				while ($rs && !$rs->EOF) {
					$row = &$rs->fields;

					// Format the field values
					switch ($fld->FieldVar) {
						case "x_merchantID":
							break;
						case "x_userpiid":
							break;
					}
					$ar[strval($row[0])] = $row;
					$rs->moveNext();
				}
				if ($rs)
					$rs->close();
				$fld->Lookup->Options = $ar;
			}
		}
	}

	// Set up starting record parameters
	public function setupStartRecord()
	{
		if ($this->DisplayRecords == 0)
			return;
		if ($this->isPageRequest()) { // Validate request
			$startRec = Get(Config("TABLE_START_REC"));
			$pageNo = Get(Config("TABLE_PAGE_NO"));
			if ($pageNo !== NULL) { // Check for "pageno" parameter first
				if (is_numeric($pageNo)) {
					$this->StartRecord = ($pageNo - 1) * $this->DisplayRecords + 1;
					if ($this->StartRecord <= 0) {
						$this->StartRecord = 1;
					} elseif ($this->StartRecord >= (int)(($this->TotalRecords - 1)/$this->DisplayRecords) * $this->DisplayRecords + 1) {
						$this->StartRecord = (int)(($this->TotalRecords - 1)/$this->DisplayRecords) * $this->DisplayRecords + 1;
					}
					$this->setStartRecordNumber($this->StartRecord);
				}
			} elseif ($startRec !== NULL) { // Check for "start" parameter
				$this->StartRecord = $startRec;
				$this->setStartRecordNumber($this->StartRecord);
			}
		}
		$this->StartRecord = $this->getStartRecordNumber();

		// Check if correct start record counter
		if (!is_numeric($this->StartRecord) || $this->StartRecord == "") { // Avoid invalid start record counter
			$this->StartRecord = 1; // Reset start record counter
			$this->setStartRecordNumber($this->StartRecord);
		} elseif ($this->StartRecord > $this->TotalRecords) { // Avoid starting record > total records
			$this->StartRecord = (int)(($this->TotalRecords - 1)/$this->DisplayRecords) * $this->DisplayRecords + 1; // Point to last page first record
			$this->setStartRecordNumber($this->StartRecord);
		} elseif (($this->StartRecord - 1) % $this->DisplayRecords != 0) {
			$this->StartRecord = (int)(($this->StartRecord - 1)/$this->DisplayRecords) * $this->DisplayRecords + 1; // Point to page boundary
			$this->setStartRecordNumber($this->StartRecord);
		}
	}

	// Page Load event
	function Page_Load() {

		//echo "Page Load";
	}

	// Page Unload event
	function Page_Unload() {

		//echo "Page Unload";
	}

	// Page Redirecting event
	function Page_Redirecting(&$url) {

		// Example:
		//$url = "your URL";

	}

	// Message Showing event
	// $type = ''|'success'|'failure'|'warning'
	function Message_Showing(&$msg, $type) {
		if ($type == 'success') {

			//$msg = "your success message";
		} elseif ($type == 'failure') {

			//$msg = "your failure message";
		} elseif ($type == 'warning') {

			//$msg = "your warning message";
		} else {

			//$msg = "your message";
		}
	}

	// Page Render event
	function Page_Render() {

		//echo "Page Render";
	}

	// Page Data Rendering event
	function Page_DataRendering(&$header) {

		// Example:
		//$header = "your header";

	}

	// Page Data Rendered event
	function Page_DataRendered(&$footer) {

		// Example:
		//$footer = "your footer";

	}

	// Form Custom Validate event
	function Form_CustomValidate(&$customError) {

		// Return error message in CustomError
		return TRUE;
	}

	// ListOptions Load event
	function ListOptions_Load() {

		// Example:
		//$opt = &$this->ListOptions->Add("new");
		//$opt->Header = "xxx";
		//$opt->OnLeft = TRUE; // Link on left
		//$opt->MoveTo(0); // Move to first column

	}

	// ListOptions Rendering event
	function ListOptions_Rendering() {

		//$GLOBALS["xxx_grid"]->DetailAdd = (...condition...); // Set to TRUE or FALSE conditionally
		//$GLOBALS["xxx_grid"]->DetailEdit = (...condition...); // Set to TRUE or FALSE conditionally
		//$GLOBALS["xxx_grid"]->DetailView = (...condition...); // Set to TRUE or FALSE conditionally

	}

	// ListOptions Rendered event
	function ListOptions_Rendered() {

		// Example:
		//$this->ListOptions["new"]->Body = "xxx";

	}

	// Row Custom Action event
	function Row_CustomAction($action, $row) {

		// Return FALSE to abort
		return TRUE;
	}

	// Page Exporting event
	// $this->ExportDoc = export document object
	function Page_Exporting() {

		//$this->ExportDoc->Text = "my header"; // Export header
		//return FALSE; // Return FALSE to skip default export and use Row_Export event

		return TRUE; // Return TRUE to use default export and skip Row_Export event
	}

	// Row Export event
	// $this->ExportDoc = export document object
	function Row_Export($rs) {

		//$this->ExportDoc->Text .= "my content"; // Build HTML with field value: $rs["MyField"] or $this->MyField->ViewValue
	}

	// Page Exported event
	// $this->ExportDoc = export document object
	function Page_Exported() {

		//$this->ExportDoc->Text .= "my footer"; // Export footer
		//echo $this->ExportDoc->Text;

	}

	// Page Importing event
	function Page_Importing($reader, &$options) {

		//var_dump($reader); // Import data reader
		//var_dump($options); // Show all options for importing
		//return FALSE; // Return FALSE to skip import

		return TRUE;
	}

	// Row Import event
	function Row_Import(&$row, $cnt) {

		//echo $cnt; // Import record count
		//var_dump($row); // Import row
		//return FALSE; // Return FALSE to skip import

		return TRUE;
	}

	// Page Imported event
	function Page_Imported($reader, $results) {

		//var_dump($reader); // Import data reader
		//var_dump($results); // Import results

	}
} // End class
?>