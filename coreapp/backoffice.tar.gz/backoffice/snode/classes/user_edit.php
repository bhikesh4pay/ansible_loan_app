<?php
namespace PHPMaker2020\_4payadmin;

/**
 * Page class
 */
class user_edit extends user
{

	// Page ID
	public $PageID = "edit";

	// Project ID
	public $ProjectID = "{153C2D2E-60EE-4944-8753-3935EB38E8D6}";

	// Table name
	public $TableName = 'user';

	// Page object name
	public $PageObjName = "user_edit";

	// Audit Trail
	public $AuditTrailOnAdd = TRUE;
	public $AuditTrailOnEdit = TRUE;
	public $AuditTrailOnDelete = TRUE;
	public $AuditTrailOnView = FALSE;
	public $AuditTrailOnViewData = FALSE;
	public $AuditTrailOnSearch = FALSE;

	// Page headings
	public $Heading = "";
	public $Subheading = "";
	public $PageHeader;
	public $PageFooter;

	// Token
	public $Token = "";
	public $TokenTimeout = 0;
	public $CheckToken;

	// Page heading
	public function pageHeading()
	{
		global $Language;
		if ($this->Heading != "")
			return $this->Heading;
		if (method_exists($this, "tableCaption"))
			return $this->tableCaption();
		return "";
	}

	// Page subheading
	public function pageSubheading()
	{
		global $Language;
		if ($this->Subheading != "")
			return $this->Subheading;
		if ($this->TableName)
			return $Language->phrase($this->PageID);
		return "";
	}

	// Page name
	public function pageName()
	{
		return CurrentPageName();
	}

	// Page URL
	public function pageUrl()
	{
		$url = CurrentPageName() . "?";
		if ($this->UseTokenInUrl)
			$url .= "t=" . $this->TableVar . "&"; // Add page token
		return $url;
	}

	// Messages
	private $_message = "";
	private $_failureMessage = "";
	private $_successMessage = "";
	private $_warningMessage = "";

	// Get message
	public function getMessage()
	{
		return isset($_SESSION[SESSION_MESSAGE]) ? $_SESSION[SESSION_MESSAGE] : $this->_message;
	}

	// Set message
	public function setMessage($v)
	{
		AddMessage($this->_message, $v);
		$_SESSION[SESSION_MESSAGE] = $this->_message;
	}

	// Get failure message
	public function getFailureMessage()
	{
		return isset($_SESSION[SESSION_FAILURE_MESSAGE]) ? $_SESSION[SESSION_FAILURE_MESSAGE] : $this->_failureMessage;
	}

	// Set failure message
	public function setFailureMessage($v)
	{
		AddMessage($this->_failureMessage, $v);
		$_SESSION[SESSION_FAILURE_MESSAGE] = $this->_failureMessage;
	}

	// Get success message
	public function getSuccessMessage()
	{
		return isset($_SESSION[SESSION_SUCCESS_MESSAGE]) ? $_SESSION[SESSION_SUCCESS_MESSAGE] : $this->_successMessage;
	}

	// Set success message
	public function setSuccessMessage($v)
	{
		AddMessage($this->_successMessage, $v);
		$_SESSION[SESSION_SUCCESS_MESSAGE] = $this->_successMessage;
	}

	// Get warning message
	public function getWarningMessage()
	{
		return isset($_SESSION[SESSION_WARNING_MESSAGE]) ? $_SESSION[SESSION_WARNING_MESSAGE] : $this->_warningMessage;
	}

	// Set warning message
	public function setWarningMessage($v)
	{
		AddMessage($this->_warningMessage, $v);
		$_SESSION[SESSION_WARNING_MESSAGE] = $this->_warningMessage;
	}

	// Clear message
	public function clearMessage()
	{
		$this->_message = "";
		$_SESSION[SESSION_MESSAGE] = "";
	}

	// Clear failure message
	public function clearFailureMessage()
	{
		$this->_failureMessage = "";
		$_SESSION[SESSION_FAILURE_MESSAGE] = "";
	}

	// Clear success message
	public function clearSuccessMessage()
	{
		$this->_successMessage = "";
		$_SESSION[SESSION_SUCCESS_MESSAGE] = "";
	}

	// Clear warning message
	public function clearWarningMessage()
	{
		$this->_warningMessage = "";
		$_SESSION[SESSION_WARNING_MESSAGE] = "";
	}

	// Clear messages
	public function clearMessages()
	{
		$this->clearMessage();
		$this->clearFailureMessage();
		$this->clearSuccessMessage();
		$this->clearWarningMessage();
	}

	// Show message
	public function showMessage()
	{
		$hidden = FALSE;
		$html = "";

		// Message
		$message = $this->getMessage();
		if (method_exists($this, "Message_Showing"))
			$this->Message_Showing($message, "");
		if ($message != "") { // Message in Session, display
			if (!$hidden)
				$message = '<button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button>' . $message;
			$html .= '<div class="alert alert-info alert-dismissible ew-info"><i class="icon fas fa-info"></i>' . $message . '</div>';
			$_SESSION[SESSION_MESSAGE] = ""; // Clear message in Session
		}

		// Warning message
		$warningMessage = $this->getWarningMessage();
		if (method_exists($this, "Message_Showing"))
			$this->Message_Showing($warningMessage, "warning");
		if ($warningMessage != "") { // Message in Session, display
			if (!$hidden)
				$warningMessage = '<button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button>' . $warningMessage;
			$html .= '<div class="alert alert-warning alert-dismissible ew-warning"><i class="icon fas fa-exclamation"></i>' . $warningMessage . '</div>';
			$_SESSION[SESSION_WARNING_MESSAGE] = ""; // Clear message in Session
		}

		// Success message
		$successMessage = $this->getSuccessMessage();
		if (method_exists($this, "Message_Showing"))
			$this->Message_Showing($successMessage, "success");
		if ($successMessage != "") { // Message in Session, display
			if (!$hidden)
				$successMessage = '<button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button>' . $successMessage;
			$html .= '<div class="alert alert-success alert-dismissible ew-success"><i class="icon fas fa-check"></i>' . $successMessage . '</div>';
			$_SESSION[SESSION_SUCCESS_MESSAGE] = ""; // Clear message in Session
		}

		// Failure message
		$errorMessage = $this->getFailureMessage();
		if (method_exists($this, "Message_Showing"))
			$this->Message_Showing($errorMessage, "failure");
		if ($errorMessage != "") { // Message in Session, display
			if (!$hidden)
				$errorMessage = '<button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button>' . $errorMessage;
			$html .= '<div class="alert alert-danger alert-dismissible ew-error"><i class="icon fas fa-ban"></i>' . $errorMessage . '</div>';
			$_SESSION[SESSION_FAILURE_MESSAGE] = ""; // Clear message in Session
		}
		echo '<div class="ew-message-dialog' . (($hidden) ? ' d-none' : "") . '">' . $html . '</div>';
	}

	// Get message as array
	public function getMessages()
	{
		$ar = [];

		// Message
		$message = $this->getMessage();

		//if (method_exists($this, "Message_Showing"))
		//	$this->Message_Showing($message, "");

		if ($message != "") { // Message in Session, display
			$ar["message"] = $message;
			$_SESSION[SESSION_MESSAGE] = ""; // Clear message in Session
		}

		// Warning message
		$warningMessage = $this->getWarningMessage();

		//if (method_exists($this, "Message_Showing"))
		//	$this->Message_Showing($warningMessage, "warning");

		if ($warningMessage != "") { // Message in Session, display
			$ar["warningMessage"] = $warningMessage;
			$_SESSION[SESSION_WARNING_MESSAGE] = ""; // Clear message in Session
		}

		// Success message
		$successMessage = $this->getSuccessMessage();

		//if (method_exists($this, "Message_Showing"))
		//	$this->Message_Showing($successMessage, "success");

		if ($successMessage != "") { // Message in Session, display
			$ar["successMessage"] = $successMessage;
			$_SESSION[SESSION_SUCCESS_MESSAGE] = ""; // Clear message in Session
		}

		// Failure message
		$failureMessage = $this->getFailureMessage();

		//if (method_exists($this, "Message_Showing"))
		//	$this->Message_Showing($failureMessage, "failure");

		if ($failureMessage != "") { // Message in Session, display
			$ar["failureMessage"] = $failureMessage;
			$_SESSION[SESSION_FAILURE_MESSAGE] = ""; // Clear message in Session
		}
		return $ar;
	}

	// Show Page Header
	public function showPageHeader()
	{
		$header = $this->PageHeader;
		$this->Page_DataRendering($header);
		if ($header != "") { // Header exists, display
			echo '<p id="ew-page-header">' . $header . '</p>';
		}
	}

	// Show Page Footer
	public function showPageFooter()
	{
		$footer = $this->PageFooter;
		$this->Page_DataRendered($footer);
		if ($footer != "") { // Footer exists, display
			echo '<p id="ew-page-footer">' . $footer . '</p>';
		}
	}

	// Validate page request
	protected function isPageRequest()
	{
		global $CurrentForm;
		if ($this->UseTokenInUrl) {
			if ($CurrentForm)
				return ($this->TableVar == $CurrentForm->getValue("t"));
			if (Get("t") !== NULL)
				return ($this->TableVar == Get("t"));
		}
		return TRUE;
	}

	// Valid Post
	protected function validPost()
	{
		if (!$this->CheckToken || !IsPost() || IsApi())
			return TRUE;
		if (Post(Config("TOKEN_NAME")) === NULL)
			return FALSE;
		$fn = Config("CHECK_TOKEN_FUNC");
		if (is_callable($fn))
			return $fn(Post(Config("TOKEN_NAME")), $this->TokenTimeout);
		return FALSE;
	}

	// Create Token
	public function createToken()
	{
		global $CurrentToken;
		$fn = Config("CREATE_TOKEN_FUNC"); // Always create token, required by API file/lookup request
		if ($this->Token == "" && is_callable($fn)) // Create token
			$this->Token = $fn();
		$CurrentToken = $this->Token; // Save to global variable
	}

	// Constructor
	public function __construct()
	{
		global $Language, $DashboardReport;
		global $UserTable;

		// Check token
		$this->CheckToken = Config("CHECK_TOKEN");

		// Initialize
		$GLOBALS["Page"] = &$this;
		$this->TokenTimeout = SessionTimeoutTime();

		// Language object
		if (!isset($Language))
			$Language = new Language();

		// Parent constuctor
		parent::__construct();

		// Table object (user)
		if (!isset($GLOBALS["user"]) || get_class($GLOBALS["user"]) == PROJECT_NAMESPACE . "user") {
			$GLOBALS["user"] = &$this;
			$GLOBALS["Table"] = &$GLOBALS["user"];
		}

		// Table object (admin)
		if (!isset($GLOBALS['admin']))
			$GLOBALS['admin'] = new admin();

		// Page ID (for backward compatibility only)
		if (!defined(PROJECT_NAMESPACE . "PAGE_ID"))
			define(PROJECT_NAMESPACE . "PAGE_ID", 'edit');

		// Table name (for backward compatibility only)
		if (!defined(PROJECT_NAMESPACE . "TABLE_NAME"))
			define(PROJECT_NAMESPACE . "TABLE_NAME", 'user');

		// Start timer
		if (!isset($GLOBALS["DebugTimer"]))
			$GLOBALS["DebugTimer"] = new Timer();

		// Debug message
		LoadDebugMessage();

		// Open connection
		if (!isset($GLOBALS["Conn"]))
			$GLOBALS["Conn"] = $this->getConnection();

		// User table object (admin)
		$UserTable = $UserTable ?: new admin();
	}

	// Terminate page
	public function terminate($url = "")
	{
		global $ExportFileName, $TempImages, $DashboardReport;

		// Page Unload event
		$this->Page_Unload();

		// Global Page Unloaded event (in userfn*.php)
		Page_Unloaded();

		// Export
		global $user;
		if ($this->CustomExport && $this->CustomExport == $this->Export && array_key_exists($this->CustomExport, Config("EXPORT_CLASSES"))) {
				$content = ob_get_contents();
			if ($ExportFileName == "")
				$ExportFileName = $this->TableVar;
			$class = PROJECT_NAMESPACE . Config("EXPORT_CLASSES." . $this->CustomExport);
			if (class_exists($class)) {
				$doc = new $class($user);
				$doc->Text = @$content;
				if ($this->isExport("email"))
					echo $this->exportEmail($doc->Text);
				else
					$doc->export();
				DeleteTempImages(); // Delete temp images
				exit();
			}
		}
		if (!IsApi())
			$this->Page_Redirecting($url);

		// Close connection
		CloseConnections();

		// Return for API
		if (IsApi()) {
			$res = $url === TRUE;
			if (!$res) // Show error
				WriteJson(array_merge(["success" => FALSE], $this->getMessages()));
			return;
		}

		// Go to URL if specified
		if ($url != "") {
			if (!Config("DEBUG") && ob_get_length())
				ob_end_clean();

			// Handle modal response
			if ($this->IsModal) { // Show as modal
				$row = ["url" => $url, "modal" => "1"];
				$pageName = GetPageName($url);
				if ($pageName != $this->getListUrl()) { // Not List page
					$row["caption"] = $this->getModalCaption($pageName);
					if ($pageName == "userview.php")
						$row["view"] = "1";
				} else { // List page should not be shown as modal => error
					$row["error"] = $this->getFailureMessage();
					$this->clearFailureMessage();
				}
				WriteJson($row);
			} else {
				SaveDebugMessage();
				AddHeader("Location", $url);
			}
		}
		exit();
	}

	// Get records from recordset
	protected function getRecordsFromRecordset($rs, $current = FALSE)
	{
		$rows = [];
		if (is_object($rs)) { // Recordset
			while ($rs && !$rs->EOF) {
				$this->loadRowValues($rs); // Set up DbValue/CurrentValue
				$row = $this->getRecordFromArray($rs->fields);
				if ($current)
					return $row;
				else
					$rows[] = $row;
				$rs->moveNext();
			}
		} elseif (is_array($rs)) {
			foreach ($rs as $ar) {
				$row = $this->getRecordFromArray($ar);
				if ($current)
					return $row;
				else
					$rows[] = $row;
			}
		}
		return $rows;
	}

	// Get record from array
	protected function getRecordFromArray($ar)
	{
		$row = [];
		if (is_array($ar)) {
			foreach ($ar as $fldname => $val) {
				if (array_key_exists($fldname, $this->fields) && ($this->fields[$fldname]->Visible || $this->fields[$fldname]->IsPrimaryKey)) { // Primary key or Visible
					$fld = &$this->fields[$fldname];
					if ($fld->HtmlTag == "FILE") { // Upload field
						if (EmptyValue($val)) {
							$row[$fldname] = NULL;
						} else {
							if ($fld->DataType == DATATYPE_BLOB) {
								$url = FullUrl(GetApiUrl(Config("API_FILE_ACTION"),
									Config("API_OBJECT_NAME") . "=" . $fld->TableVar . "&" .
									Config("API_FIELD_NAME") . "=" . $fld->Param . "&" .
									Config("API_KEY_NAME") . "=" . rawurlencode($this->getRecordKeyValue($ar)))); //*** need to add this? API may not be in the same folder
								$row[$fldname] = ["type" => ContentType($val), "url" => $url, "name" => $fld->Param . ContentExtension($val)];
							} elseif (!$fld->UploadMultiple || !ContainsString($val, Config("MULTIPLE_UPLOAD_SEPARATOR"))) { // Single file
								$url = FullUrl(GetApiUrl(Config("API_FILE_ACTION"),
									Config("API_OBJECT_NAME") . "=" . $fld->TableVar . "&" .
									"fn=" . Encrypt($fld->physicalUploadPath() . $val)));
								$row[$fldname] = ["type" => MimeContentType($val), "url" => $url, "name" => $val];
							} else { // Multiple files
								$files = explode(Config("MULTIPLE_UPLOAD_SEPARATOR"), $val);
								$ar = [];
								foreach ($files as $file) {
									$url = FullUrl(GetApiUrl(Config("API_FILE_ACTION"),
										Config("API_OBJECT_NAME") . "=" . $fld->TableVar . "&" .
										"fn=" . Encrypt($fld->physicalUploadPath() . $file)));
									if (!EmptyValue($file))
										$ar[] = ["type" => MimeContentType($file), "url" => $url, "name" => $file];
								}
								$row[$fldname] = $ar;
							}
						}
					} else {
						$row[$fldname] = $val;
					}
				}
			}
		}
		return $row;
	}

	// Get record key value from array
	protected function getRecordKeyValue($ar)
	{
		$key = "";
		if (is_array($ar)) {
			$key .= @$ar['id'];
		}
		return $key;
	}

	/**
	 * Hide fields for add/edit
	 *
	 * @return void
	 */
	protected function hideFieldsForAddEdit()
	{
	}

	// Lookup data
	public function lookup()
	{
		global $Language, $Security;
		if (!isset($Language))
			$Language = new Language(Config("LANGUAGE_FOLDER"), Post("language", ""));

		// Set up API request
		if (!ValidApiRequest())
			return FALSE;
		$this->setupApiSecurity();

		// Get lookup object
		$fieldName = Post("field");
		if (!array_key_exists($fieldName, $this->fields))
			return FALSE;
		$lookupField = $this->fields[$fieldName];
		$lookup = $lookupField->Lookup;
		if ($lookup === NULL)
			return FALSE;
		$tbl = $lookup->getTable();
		if (!$Security->allowLookup(Config("PROJECT_ID") . $tbl->TableName)) // Lookup permission
			return FALSE;

		// Get lookup parameters
		$lookupType = Post("ajax", "unknown");
		$pageSize = -1;
		$offset = -1;
		$searchValue = "";
		if (SameText($lookupType, "modal")) {
			$searchValue = Post("sv", "");
			$pageSize = Post("recperpage", 10);
			$offset = Post("start", 0);
		} elseif (SameText($lookupType, "autosuggest")) {
			$searchValue = Param("q", "");
			$pageSize = Param("n", -1);
			$pageSize = is_numeric($pageSize) ? (int)$pageSize : -1;
			if ($pageSize <= 0)
				$pageSize = Config("AUTO_SUGGEST_MAX_ENTRIES");
			$start = Param("start", -1);
			$start = is_numeric($start) ? (int)$start : -1;
			$page = Param("page", -1);
			$page = is_numeric($page) ? (int)$page : -1;
			$offset = $start >= 0 ? $start : ($page > 0 && $pageSize > 0 ? ($page - 1) * $pageSize : 0);
		}
		$userSelect = Decrypt(Post("s", ""));
		$userFilter = Decrypt(Post("f", ""));
		$userOrderBy = Decrypt(Post("o", ""));
		$keys = Post("keys");
		$lookup->LookupType = $lookupType; // Lookup type
		if ($keys !== NULL) { // Selected records from modal
			if (is_array($keys))
				$keys = implode(Config("MULTIPLE_OPTION_SEPARATOR"), $keys);
			$lookup->FilterFields = []; // Skip parent fields if any
			$lookup->FilterValues[] = $keys; // Lookup values
			$pageSize = -1; // Show all records
		} else { // Lookup values
			$lookup->FilterValues[] = Post("v0", Post("lookupValue", ""));
		}
		$cnt = is_array($lookup->FilterFields) ? count($lookup->FilterFields) : 0;
		for ($i = 1; $i <= $cnt; $i++)
			$lookup->FilterValues[] = Post("v" . $i, "");
		$lookup->SearchValue = $searchValue;
		$lookup->PageSize = $pageSize;
		$lookup->Offset = $offset;
		if ($userSelect != "")
			$lookup->UserSelect = $userSelect;
		if ($userFilter != "")
			$lookup->UserFilter = $userFilter;
		if ($userOrderBy != "")
			$lookup->UserOrderBy = $userOrderBy;
		$lookup->toJson($this); // Use settings from current page
	}

	// Set up API security
	public function setupApiSecurity()
	{
		global $Security;

		// Setup security for API request
		if ($Security->isLoggedIn()) $Security->TablePermission_Loading();
		$Security->loadCurrentUserLevel(Config("PROJECT_ID") . $this->TableName);
		if ($Security->isLoggedIn()) $Security->TablePermission_Loaded();
	}
	public $FormClassName = "ew-horizontal ew-form ew-edit-form";
	public $IsModal = FALSE;
	public $IsMobileOrModal = FALSE;
	public $DbMasterFilter;
	public $DbDetailFilter;
	public $MultiPages; // Multi pages object
	public $DetailPages; // Detail pages object

	//
	// Page run
	//

	public function run()
	{
		global $ExportType, $CustomExportType, $ExportFileName, $UserProfile, $Language, $Security, $CurrentForm,
			$FormError, $SkipHeaderFooter;

		// Is modal
		$this->IsModal = (Param("modal") == "1");

		// User profile
		$UserProfile = new UserProfile();

		// Security
		if (ValidApiRequest()) { // API request
			$this->setupApiSecurity(); // Set up API Security
			if (!$Security->canEdit()) {
				SetStatus(401); // Unauthorized
				return;
			}
		} else {
			$Security = new AdvancedSecurity();
			if (IsPasswordExpired())
				$this->terminate(GetUrl("changepwd.php"));
			if (!$Security->isLoggedIn())
				$Security->autoLogin();
			if ($Security->isLoggedIn())
				$Security->TablePermission_Loading();
			$Security->loadCurrentUserLevel($this->ProjectID . $this->TableName);
			if ($Security->isLoggedIn())
				$Security->TablePermission_Loaded();
			if (!$Security->canEdit()) {
				$Security->saveLastUrl();
				$this->setFailureMessage(DeniedMessage()); // Set no permission
				if ($Security->canList())
					$this->terminate(GetUrl("userlist.php"));
				else
					$this->terminate(GetUrl("login.php"));
				return;
			}
		}

		// Create form object
		$CurrentForm = new HttpForm();
		$this->CurrentAction = Param("action"); // Set up current action
		$this->id->setVisibility();
		$this->firstName->setVisibility();
		$this->lastName->setVisibility();
		$this->otherNames->setVisibility();
		$this->passwordRequireChange->setVisibility();
		$this->franchiseeID->setVisibility();
		$this->dateAdded->setVisibility();
		$this->timezoneid->setVisibility();
		$this->telephoneverificationcode->Visible = FALSE;
		$this->contactPhoneNo->setVisibility();
		$this->telephoneno->setVisibility();
		$this->telephoneverified->setVisibility();
		$this->telephonereceivemessage->setVisibility();
		$this->verification1->setVisibility();
		$this->verification2->setVisibility();
		$this->verification3->setVisibility();
		$this->address1->setVisibility();
		$this->address2->setVisibility();
		$this->cityname->setVisibility();
		$this->countryid->setVisibility();
		$this->stateid->setVisibility();
		$this->defaultcurrency->setVisibility();
		$this->challengeq1->setVisibility();
		$this->challengea1->setVisibility();
		$this->challengeq2->setVisibility();
		$this->challengea2->setVisibility();
		$this->challengeq3->setVisibility();
		$this->challengea3->setVisibility();
		$this->password->Visible = FALSE;
		$this->passwordCounter->setVisibility();
		$this->passwordChangedDate->setVisibility();
		$this->pin->Visible = FALSE;
		$this->pinCounter->setVisibility();
		$this->langID->setVisibility();
		$this->photo->setVisibility();
		$this->status->setVisibility();
		$this->markedfordeletion->setVisibility();
		$this->userType->setVisibility();
		$this->usersubtype->setVisibility();
		$this->accountID->setVisibility();
		$this->brokerid->setVisibility();
		$this->parentuserid->setVisibility();
		$this->corporate->setVisibility();
		$this->profilestatus->setVisibility();
		$this->jumpappid->setVisibility();
		$this->dateofbirth->setVisibility();
		$this->gender->setVisibility();
		$this->lastupdatedate->setVisibility();
		$this->jumprequiredatlogin->setVisibility();
		$this->ccbypass->setVisibility();
		$this->zip->setVisibility();
		$this->other1->setVisibility();
		$this->other2->setVisibility();
		$this->other3->setVisibility();
		$this->other4->setVisibility();
		$this->other5->setVisibility();
		$this->other6->setVisibility();
		$this->mincashamount->setVisibility();
		$this->maxcashamount->setVisibility();
		$this->maxtransferinamount->setVisibility();
		$this->maxtransferoutamount->setVisibility();
		$this->legalid->setVisibility();
		$this->userpiview->setVisibility();
		$this->lastmsgid->setVisibility();
		$this->otprequiredforphysicalcards->setVisibility();
		$this->otpvalue->Visible = FALSE;
		$this->otpvaliduntil->setVisibility();
		$this->statusshadow->Visible = FALSE;
		$this->nationalitycountry->setVisibility();
		$this->classification->setVisibility();
		$this->occupation->setVisibility();
		$this->sourceofincome->setVisibility();
		$this->accountopeningdate->setVisibility();
		$this->extendedfields->setVisibility();
		$this->lastprofilestatuschangedate->setVisibility();
		$this->hideFieldsForAddEdit();

		// Do not use lookup cache
		$this->setUseLookupCache(FALSE);

		// Set up multi page object
		$this->setupMultiPages();

		// Set up detail page object
		$this->setupDetailPages();

		// Global Page Loading event (in userfn*.php)
		Page_Loading();

		// Page Load event
		$this->Page_Load();

		// Check token
		if (!$this->validPost()) {
			Write($Language->phrase("InvalidPostRequest"));
			$this->terminate();
		}

		// Create Token
		$this->createToken();

		// Set up lookup cache
		$this->setupLookupOptions($this->passwordRequireChange);
		$this->setupLookupOptions($this->timezoneid);
		$this->setupLookupOptions($this->telephoneverified);
		$this->setupLookupOptions($this->telephonereceivemessage);
		$this->setupLookupOptions($this->countryid);
		$this->setupLookupOptions($this->stateid);
		$this->setupLookupOptions($this->defaultcurrency);
		$this->setupLookupOptions($this->langID);
		$this->setupLookupOptions($this->status);
		$this->setupLookupOptions($this->userType);
		$this->setupLookupOptions($this->usersubtype);
		$this->setupLookupOptions($this->corporate);
		$this->setupLookupOptions($this->profilestatus);
		$this->setupLookupOptions($this->gender);
		$this->setupLookupOptions($this->jumprequiredatlogin);
		$this->setupLookupOptions($this->ccbypass);
		$this->setupLookupOptions($this->userpiview);
		$this->setupLookupOptions($this->nationalitycountry);
		$this->setupLookupOptions($this->classification);
		$this->setupLookupOptions($this->occupation);
		$this->setupLookupOptions($this->sourceofincome);

		// Check permission
		if (!$Security->canEdit()) {
			$this->setFailureMessage(DeniedMessage()); // No permission
			$this->terminate("userlist.php");
			return;
		}

		// Check modal
		if ($this->IsModal)
			$SkipHeaderFooter = TRUE;
		$this->IsMobileOrModal = IsMobile() || $this->IsModal;
		$this->FormClassName = "ew-form ew-edit-form ew-horizontal";
		$loaded = FALSE;
		$postBack = FALSE;

		// Set up current action and primary key
		if (IsApi()) {

			// Load key values
			$loaded = TRUE;
			if (Get("id") !== NULL) {
				$this->id->setQueryStringValue(Get("id"));
				$this->id->setOldValue($this->id->QueryStringValue);
			} elseif (Key(0) !== NULL) {
				$this->id->setQueryStringValue(Key(0));
				$this->id->setOldValue($this->id->QueryStringValue);
			} elseif (Post("id") !== NULL) {
				$this->id->setFormValue(Post("id"));
				$this->id->setOldValue($this->id->FormValue);
			} elseif (Route(2) !== NULL) {
				$this->id->setQueryStringValue(Route(2));
				$this->id->setOldValue($this->id->QueryStringValue);
			} else {
				$loaded = FALSE; // Unable to load key
			}

			// Load record
			if ($loaded)
				$loaded = $this->loadRow();
			if (!$loaded) {
				$this->setFailureMessage($Language->phrase("NoRecord")); // Set no record message
				$this->terminate();
				return;
			}
			$this->CurrentAction = "update"; // Update record directly
			$postBack = TRUE;
		} else {
			if (Post("action") !== NULL) {
				$this->CurrentAction = Post("action"); // Get action code
				if (!$this->isShow()) // Not reload record, handle as postback
					$postBack = TRUE;

				// Load key from Form
				if ($CurrentForm->hasValue("x_id")) {
					$this->id->setFormValue($CurrentForm->getValue("x_id"));
				}
			} else {
				$this->CurrentAction = "show"; // Default action is display

				// Load key from QueryString / Route
				$loadByQuery = FALSE;
				if (Get("id") !== NULL) {
					$this->id->setQueryStringValue(Get("id"));
					$loadByQuery = TRUE;
				} elseif (Route(2) !== NULL) {
					$this->id->setQueryStringValue(Route(2));
					$loadByQuery = TRUE;
				} else {
					$this->id->CurrentValue = NULL;
				}
			}

			// Load current record
			$loaded = $this->loadRow();
		}

		// Process form if post back
		if ($postBack) {
			$this->loadFormValues(); // Get form values

			// Set up detail parameters
			$this->setupDetailParms();
		}

		// Validate form if post back
		if ($postBack) {
			if (!$this->validateForm()) {
				$this->setFailureMessage($FormError);
				$this->EventCancelled = TRUE; // Event cancelled
				$this->restoreFormValues();
				if (IsApi()) {
					$this->terminate();
					return;
				} else {
					$this->CurrentAction = ""; // Form error, reset action
				}
			}
		}

		// Perform current action
		switch ($this->CurrentAction) {
			case "show": // Get a record to display
				if (!$loaded) { // Load record based on key
					if ($this->getFailureMessage() == "")
						$this->setFailureMessage($Language->phrase("NoRecord")); // No record found
					$this->terminate("userlist.php"); // No matching record, return to list
				}

				// Set up detail parameters
				$this->setupDetailParms();
				break;
			case "update": // Update
				if ($this->getCurrentDetailTable() != "") // Master/detail edit
					$returnUrl = $this->getViewUrl(Config("TABLE_SHOW_DETAIL") . "=" . $this->getCurrentDetailTable()); // Master/Detail view page
				else
					$returnUrl = $this->getReturnUrl();
				if (GetPageName($returnUrl) == "userlist.php")
					$returnUrl = $this->addMasterUrl($returnUrl); // List page, return to List page with correct master key if necessary
				$this->SendEmail = TRUE; // Send email on update success
				if ($this->editRow()) { // Update record based on key
					if ($this->getSuccessMessage() == "")
						$this->setSuccessMessage($Language->phrase("UpdateSuccess")); // Update success
					if (IsApi()) {
						$this->terminate(TRUE);
						return;
					} else {
						$this->terminate($returnUrl); // Return to caller
					}
				} elseif (IsApi()) { // API request, return
					$this->terminate();
					return;
				} elseif ($this->getFailureMessage() == $Language->phrase("NoRecord")) {
					$this->terminate($returnUrl); // Return to caller
				} else {
					$this->EventCancelled = TRUE; // Event cancelled
					$this->restoreFormValues(); // Restore form values if update failed

					// Set up detail parameters
					$this->setupDetailParms();
				}
		}

		// Set up Breadcrumb
		$this->setupBreadcrumb();

		// Render the record
		$this->RowType = ROWTYPE_EDIT; // Render as Edit
		$this->resetAttributes();
		$this->renderRow();
	}

	// Get upload files
	protected function getUploadFiles()
	{
		global $CurrentForm, $Language;
		$this->photo->Upload->Index = $CurrentForm->Index;
		$this->photo->Upload->uploadFile();
	}

	// Load form values
	protected function loadFormValues()
	{

		// Load from form
		global $CurrentForm;

		// Check field name 'id' first before field var 'x_id'
		$val = $CurrentForm->hasValue("id") ? $CurrentForm->getValue("id") : $CurrentForm->getValue("x_id");
		if (!$this->id->IsDetailKey) {
			if (IsApi() && $val === NULL)
				$this->id->Visible = FALSE; // Disable update for API request
			else
				$this->id->setFormValue($val);
		}
		if ($CurrentForm->hasValue("o_id"))
			$this->id->setOldValue($CurrentForm->getValue("o_id"));

		// Check field name 'firstName' first before field var 'x_firstName'
		$val = $CurrentForm->hasValue("firstName") ? $CurrentForm->getValue("firstName") : $CurrentForm->getValue("x_firstName");
		if (!$this->firstName->IsDetailKey) {
			if (IsApi() && $val === NULL)
				$this->firstName->Visible = FALSE; // Disable update for API request
			else
				$this->firstName->setFormValue($val);
		}

		// Check field name 'lastName' first before field var 'x_lastName'
		$val = $CurrentForm->hasValue("lastName") ? $CurrentForm->getValue("lastName") : $CurrentForm->getValue("x_lastName");
		if (!$this->lastName->IsDetailKey) {
			if (IsApi() && $val === NULL)
				$this->lastName->Visible = FALSE; // Disable update for API request
			else
				$this->lastName->setFormValue($val);
		}

		// Check field name 'otherNames' first before field var 'x_otherNames'
		$val = $CurrentForm->hasValue("otherNames") ? $CurrentForm->getValue("otherNames") : $CurrentForm->getValue("x_otherNames");
		if (!$this->otherNames->IsDetailKey) {
			if (IsApi() && $val === NULL)
				$this->otherNames->Visible = FALSE; // Disable update for API request
			else
				$this->otherNames->setFormValue($val);
		}

		// Check field name 'passwordRequireChange' first before field var 'x_passwordRequireChange'
		$val = $CurrentForm->hasValue("passwordRequireChange") ? $CurrentForm->getValue("passwordRequireChange") : $CurrentForm->getValue("x_passwordRequireChange");
		if (!$this->passwordRequireChange->IsDetailKey) {
			if (IsApi() && $val === NULL)
				$this->passwordRequireChange->Visible = FALSE; // Disable update for API request
			else
				$this->passwordRequireChange->setFormValue($val);
		}

		// Check field name 'franchiseeID' first before field var 'x_franchiseeID'
		$val = $CurrentForm->hasValue("franchiseeID") ? $CurrentForm->getValue("franchiseeID") : $CurrentForm->getValue("x_franchiseeID");
		if (!$this->franchiseeID->IsDetailKey) {
			if (IsApi() && $val === NULL)
				$this->franchiseeID->Visible = FALSE; // Disable update for API request
			else
				$this->franchiseeID->setFormValue($val);
		}

		// Check field name 'dateAdded' first before field var 'x_dateAdded'
		$val = $CurrentForm->hasValue("dateAdded") ? $CurrentForm->getValue("dateAdded") : $CurrentForm->getValue("x_dateAdded");
		if (!$this->dateAdded->IsDetailKey) {
			if (IsApi() && $val === NULL)
				$this->dateAdded->Visible = FALSE; // Disable update for API request
			else
				$this->dateAdded->setFormValue($val);
			$this->dateAdded->CurrentValue = UnFormatDateTime($this->dateAdded->CurrentValue, 1);
		}

		// Check field name 'timezoneid' first before field var 'x_timezoneid'
		$val = $CurrentForm->hasValue("timezoneid") ? $CurrentForm->getValue("timezoneid") : $CurrentForm->getValue("x_timezoneid");
		if (!$this->timezoneid->IsDetailKey) {
			if (IsApi() && $val === NULL)
				$this->timezoneid->Visible = FALSE; // Disable update for API request
			else
				$this->timezoneid->setFormValue($val);
		}

		// Check field name 'contactPhoneNo' first before field var 'x_contactPhoneNo'
		$val = $CurrentForm->hasValue("contactPhoneNo") ? $CurrentForm->getValue("contactPhoneNo") : $CurrentForm->getValue("x_contactPhoneNo");
		if (!$this->contactPhoneNo->IsDetailKey) {
			if (IsApi() && $val === NULL)
				$this->contactPhoneNo->Visible = FALSE; // Disable update for API request
			else
				$this->contactPhoneNo->setFormValue($val);
		}

		// Check field name 'telephoneno' first before field var 'x_telephoneno'
		$val = $CurrentForm->hasValue("telephoneno") ? $CurrentForm->getValue("telephoneno") : $CurrentForm->getValue("x_telephoneno");
		if (!$this->telephoneno->IsDetailKey) {
			if (IsApi() && $val === NULL)
				$this->telephoneno->Visible = FALSE; // Disable update for API request
			else
				$this->telephoneno->setFormValue($val);
		}

		// Check field name 'telephoneverified' first before field var 'x_telephoneverified'
		$val = $CurrentForm->hasValue("telephoneverified") ? $CurrentForm->getValue("telephoneverified") : $CurrentForm->getValue("x_telephoneverified");
		if (!$this->telephoneverified->IsDetailKey) {
			if (IsApi() && $val === NULL)
				$this->telephoneverified->Visible = FALSE; // Disable update for API request
			else
				$this->telephoneverified->setFormValue($val);
		}

		// Check field name 'telephonereceivemessage' first before field var 'x_telephonereceivemessage'
		$val = $CurrentForm->hasValue("telephonereceivemessage") ? $CurrentForm->getValue("telephonereceivemessage") : $CurrentForm->getValue("x_telephonereceivemessage");
		if (!$this->telephonereceivemessage->IsDetailKey) {
			if (IsApi() && $val === NULL)
				$this->telephonereceivemessage->Visible = FALSE; // Disable update for API request
			else
				$this->telephonereceivemessage->setFormValue($val);
		}

		// Check field name 'verification1' first before field var 'x_verification1'
		$val = $CurrentForm->hasValue("verification1") ? $CurrentForm->getValue("verification1") : $CurrentForm->getValue("x_verification1");
		if (!$this->verification1->IsDetailKey) {
			if (IsApi() && $val === NULL)
				$this->verification1->Visible = FALSE; // Disable update for API request
			else
				$this->verification1->setFormValue($val);
		}

		// Check field name 'verification2' first before field var 'x_verification2'
		$val = $CurrentForm->hasValue("verification2") ? $CurrentForm->getValue("verification2") : $CurrentForm->getValue("x_verification2");
		if (!$this->verification2->IsDetailKey) {
			if (IsApi() && $val === NULL)
				$this->verification2->Visible = FALSE; // Disable update for API request
			else
				$this->verification2->setFormValue($val);
		}

		// Check field name 'verification3' first before field var 'x_verification3'
		$val = $CurrentForm->hasValue("verification3") ? $CurrentForm->getValue("verification3") : $CurrentForm->getValue("x_verification3");
		if (!$this->verification3->IsDetailKey) {
			if (IsApi() && $val === NULL)
				$this->verification3->Visible = FALSE; // Disable update for API request
			else
				$this->verification3->setFormValue($val);
		}

		// Check field name 'address1' first before field var 'x_address1'
		$val = $CurrentForm->hasValue("address1") ? $CurrentForm->getValue("address1") : $CurrentForm->getValue("x_address1");
		if (!$this->address1->IsDetailKey) {
			if (IsApi() && $val === NULL)
				$this->address1->Visible = FALSE; // Disable update for API request
			else
				$this->address1->setFormValue($val);
		}

		// Check field name 'address2' first before field var 'x_address2'
		$val = $CurrentForm->hasValue("address2") ? $CurrentForm->getValue("address2") : $CurrentForm->getValue("x_address2");
		if (!$this->address2->IsDetailKey) {
			if (IsApi() && $val === NULL)
				$this->address2->Visible = FALSE; // Disable update for API request
			else
				$this->address2->setFormValue($val);
		}

		// Check field name 'cityname' first before field var 'x_cityname'
		$val = $CurrentForm->hasValue("cityname") ? $CurrentForm->getValue("cityname") : $CurrentForm->getValue("x_cityname");
		if (!$this->cityname->IsDetailKey) {
			if (IsApi() && $val === NULL)
				$this->cityname->Visible = FALSE; // Disable update for API request
			else
				$this->cityname->setFormValue($val);
		}

		// Check field name 'countryid' first before field var 'x_countryid'
		$val = $CurrentForm->hasValue("countryid") ? $CurrentForm->getValue("countryid") : $CurrentForm->getValue("x_countryid");
		if (!$this->countryid->IsDetailKey) {
			if (IsApi() && $val === NULL)
				$this->countryid->Visible = FALSE; // Disable update for API request
			else
				$this->countryid->setFormValue($val);
		}

		// Check field name 'stateid' first before field var 'x_stateid'
		$val = $CurrentForm->hasValue("stateid") ? $CurrentForm->getValue("stateid") : $CurrentForm->getValue("x_stateid");
		if (!$this->stateid->IsDetailKey) {
			if (IsApi() && $val === NULL)
				$this->stateid->Visible = FALSE; // Disable update for API request
			else
				$this->stateid->setFormValue($val);
		}

		// Check field name 'defaultcurrency' first before field var 'x_defaultcurrency'
		$val = $CurrentForm->hasValue("defaultcurrency") ? $CurrentForm->getValue("defaultcurrency") : $CurrentForm->getValue("x_defaultcurrency");
		if (!$this->defaultcurrency->IsDetailKey) {
			if (IsApi() && $val === NULL)
				$this->defaultcurrency->Visible = FALSE; // Disable update for API request
			else
				$this->defaultcurrency->setFormValue($val);
		}

		// Check field name 'challengeq1' first before field var 'x_challengeq1'
		$val = $CurrentForm->hasValue("challengeq1") ? $CurrentForm->getValue("challengeq1") : $CurrentForm->getValue("x_challengeq1");
		if (!$this->challengeq1->IsDetailKey) {
			if (IsApi() && $val === NULL)
				$this->challengeq1->Visible = FALSE; // Disable update for API request
			else
				$this->challengeq1->setFormValue($val);
		}

		// Check field name 'challengea1' first before field var 'x_challengea1'
		$val = $CurrentForm->hasValue("challengea1") ? $CurrentForm->getValue("challengea1") : $CurrentForm->getValue("x_challengea1");
		if (!$this->challengea1->IsDetailKey) {
			if (IsApi() && $val === NULL)
				$this->challengea1->Visible = FALSE; // Disable update for API request
			else
				$this->challengea1->setFormValue($val);
		}

		// Check field name 'challengeq2' first before field var 'x_challengeq2'
		$val = $CurrentForm->hasValue("challengeq2") ? $CurrentForm->getValue("challengeq2") : $CurrentForm->getValue("x_challengeq2");
		if (!$this->challengeq2->IsDetailKey) {
			if (IsApi() && $val === NULL)
				$this->challengeq2->Visible = FALSE; // Disable update for API request
			else
				$this->challengeq2->setFormValue($val);
		}

		// Check field name 'challengea2' first before field var 'x_challengea2'
		$val = $CurrentForm->hasValue("challengea2") ? $CurrentForm->getValue("challengea2") : $CurrentForm->getValue("x_challengea2");
		if (!$this->challengea2->IsDetailKey) {
			if (IsApi() && $val === NULL)
				$this->challengea2->Visible = FALSE; // Disable update for API request
			else
				$this->challengea2->setFormValue($val);
		}

		// Check field name 'challengeq3' first before field var 'x_challengeq3'
		$val = $CurrentForm->hasValue("challengeq3") ? $CurrentForm->getValue("challengeq3") : $CurrentForm->getValue("x_challengeq3");
		if (!$this->challengeq3->IsDetailKey) {
			if (IsApi() && $val === NULL)
				$this->challengeq3->Visible = FALSE; // Disable update for API request
			else
				$this->challengeq3->setFormValue($val);
		}

		// Check field name 'challengea3' first before field var 'x_challengea3'
		$val = $CurrentForm->hasValue("challengea3") ? $CurrentForm->getValue("challengea3") : $CurrentForm->getValue("x_challengea3");
		if (!$this->challengea3->IsDetailKey) {
			if (IsApi() && $val === NULL)
				$this->challengea3->Visible = FALSE; // Disable update for API request
			else
				$this->challengea3->setFormValue($val);
		}

		// Check field name 'passwordCounter' first before field var 'x_passwordCounter'
		$val = $CurrentForm->hasValue("passwordCounter") ? $CurrentForm->getValue("passwordCounter") : $CurrentForm->getValue("x_passwordCounter");
		if (!$this->passwordCounter->IsDetailKey) {
			if (IsApi() && $val === NULL)
				$this->passwordCounter->Visible = FALSE; // Disable update for API request
			else
				$this->passwordCounter->setFormValue($val);
		}

		// Check field name 'passwordChangedDate' first before field var 'x_passwordChangedDate'
		$val = $CurrentForm->hasValue("passwordChangedDate") ? $CurrentForm->getValue("passwordChangedDate") : $CurrentForm->getValue("x_passwordChangedDate");
		if (!$this->passwordChangedDate->IsDetailKey) {
			if (IsApi() && $val === NULL)
				$this->passwordChangedDate->Visible = FALSE; // Disable update for API request
			else
				$this->passwordChangedDate->setFormValue($val);
			$this->passwordChangedDate->CurrentValue = UnFormatDateTime($this->passwordChangedDate->CurrentValue, 1);
		}

		// Check field name 'pinCounter' first before field var 'x_pinCounter'
		$val = $CurrentForm->hasValue("pinCounter") ? $CurrentForm->getValue("pinCounter") : $CurrentForm->getValue("x_pinCounter");
		if (!$this->pinCounter->IsDetailKey) {
			if (IsApi() && $val === NULL)
				$this->pinCounter->Visible = FALSE; // Disable update for API request
			else
				$this->pinCounter->setFormValue($val);
		}

		// Check field name 'langID' first before field var 'x_langID'
		$val = $CurrentForm->hasValue("langID") ? $CurrentForm->getValue("langID") : $CurrentForm->getValue("x_langID");
		if (!$this->langID->IsDetailKey) {
			if (IsApi() && $val === NULL)
				$this->langID->Visible = FALSE; // Disable update for API request
			else
				$this->langID->setFormValue($val);
		}

		// Check field name 'status' first before field var 'x_status'
		$val = $CurrentForm->hasValue("status") ? $CurrentForm->getValue("status") : $CurrentForm->getValue("x_status");
		if (!$this->status->IsDetailKey) {
			if (IsApi() && $val === NULL)
				$this->status->Visible = FALSE; // Disable update for API request
			else
				$this->status->setFormValue($val);
		}

		// Check field name 'markedfordeletion' first before field var 'x_markedfordeletion'
		$val = $CurrentForm->hasValue("markedfordeletion") ? $CurrentForm->getValue("markedfordeletion") : $CurrentForm->getValue("x_markedfordeletion");
		if (!$this->markedfordeletion->IsDetailKey) {
			if (IsApi() && $val === NULL)
				$this->markedfordeletion->Visible = FALSE; // Disable update for API request
			else
				$this->markedfordeletion->setFormValue($val);
			$this->markedfordeletion->CurrentValue = UnFormatDateTime($this->markedfordeletion->CurrentValue, 0);
		}

		// Check field name 'userType' first before field var 'x_userType'
		$val = $CurrentForm->hasValue("userType") ? $CurrentForm->getValue("userType") : $CurrentForm->getValue("x_userType");
		if (!$this->userType->IsDetailKey) {
			if (IsApi() && $val === NULL)
				$this->userType->Visible = FALSE; // Disable update for API request
			else
				$this->userType->setFormValue($val);
		}

		// Check field name 'usersubtype' first before field var 'x_usersubtype'
		$val = $CurrentForm->hasValue("usersubtype") ? $CurrentForm->getValue("usersubtype") : $CurrentForm->getValue("x_usersubtype");
		if (!$this->usersubtype->IsDetailKey) {
			if (IsApi() && $val === NULL)
				$this->usersubtype->Visible = FALSE; // Disable update for API request
			else
				$this->usersubtype->setFormValue($val);
		}

		// Check field name 'accountID' first before field var 'x_accountID'
		$val = $CurrentForm->hasValue("accountID") ? $CurrentForm->getValue("accountID") : $CurrentForm->getValue("x_accountID");
		if (!$this->accountID->IsDetailKey) {
			if (IsApi() && $val === NULL)
				$this->accountID->Visible = FALSE; // Disable update for API request
			else
				$this->accountID->setFormValue($val);
		}

		// Check field name 'brokerid' first before field var 'x_brokerid'
		$val = $CurrentForm->hasValue("brokerid") ? $CurrentForm->getValue("brokerid") : $CurrentForm->getValue("x_brokerid");
		if (!$this->brokerid->IsDetailKey) {
			if (IsApi() && $val === NULL)
				$this->brokerid->Visible = FALSE; // Disable update for API request
			else
				$this->brokerid->setFormValue($val);
		}

		// Check field name 'parentuserid' first before field var 'x_parentuserid'
		$val = $CurrentForm->hasValue("parentuserid") ? $CurrentForm->getValue("parentuserid") : $CurrentForm->getValue("x_parentuserid");
		if (!$this->parentuserid->IsDetailKey) {
			if (IsApi() && $val === NULL)
				$this->parentuserid->Visible = FALSE; // Disable update for API request
			else
				$this->parentuserid->setFormValue($val);
		}

		// Check field name 'corporate' first before field var 'x_corporate'
		$val = $CurrentForm->hasValue("corporate") ? $CurrentForm->getValue("corporate") : $CurrentForm->getValue("x_corporate");
		if (!$this->corporate->IsDetailKey) {
			if (IsApi() && $val === NULL)
				$this->corporate->Visible = FALSE; // Disable update for API request
			else
				$this->corporate->setFormValue($val);
		}

		// Check field name 'profilestatus' first before field var 'x_profilestatus'
		$val = $CurrentForm->hasValue("profilestatus") ? $CurrentForm->getValue("profilestatus") : $CurrentForm->getValue("x_profilestatus");
		if (!$this->profilestatus->IsDetailKey) {
			if (IsApi() && $val === NULL)
				$this->profilestatus->Visible = FALSE; // Disable update for API request
			else
				$this->profilestatus->setFormValue($val);
		}

		// Check field name 'jumpappid' first before field var 'x_jumpappid'
		$val = $CurrentForm->hasValue("jumpappid") ? $CurrentForm->getValue("jumpappid") : $CurrentForm->getValue("x_jumpappid");
		if (!$this->jumpappid->IsDetailKey) {
			if (IsApi() && $val === NULL)
				$this->jumpappid->Visible = FALSE; // Disable update for API request
			else
				$this->jumpappid->setFormValue($val);
		}

		// Check field name 'dateofbirth' first before field var 'x_dateofbirth'
		$val = $CurrentForm->hasValue("dateofbirth") ? $CurrentForm->getValue("dateofbirth") : $CurrentForm->getValue("x_dateofbirth");
		if (!$this->dateofbirth->IsDetailKey) {
			if (IsApi() && $val === NULL)
				$this->dateofbirth->Visible = FALSE; // Disable update for API request
			else
				$this->dateofbirth->setFormValue($val);
			$this->dateofbirth->CurrentValue = UnFormatDateTime($this->dateofbirth->CurrentValue, 2);
		}

		// Check field name 'gender' first before field var 'x_gender'
		$val = $CurrentForm->hasValue("gender") ? $CurrentForm->getValue("gender") : $CurrentForm->getValue("x_gender");
		if (!$this->gender->IsDetailKey) {
			if (IsApi() && $val === NULL)
				$this->gender->Visible = FALSE; // Disable update for API request
			else
				$this->gender->setFormValue($val);
		}

		// Check field name 'lastupdatedate' first before field var 'x_lastupdatedate'
		$val = $CurrentForm->hasValue("lastupdatedate") ? $CurrentForm->getValue("lastupdatedate") : $CurrentForm->getValue("x_lastupdatedate");
		if (!$this->lastupdatedate->IsDetailKey) {
			if (IsApi() && $val === NULL)
				$this->lastupdatedate->Visible = FALSE; // Disable update for API request
			else
				$this->lastupdatedate->setFormValue($val);
			$this->lastupdatedate->CurrentValue = UnFormatDateTime($this->lastupdatedate->CurrentValue, 1);
		}

		// Check field name 'jumprequiredatlogin' first before field var 'x_jumprequiredatlogin'
		$val = $CurrentForm->hasValue("jumprequiredatlogin") ? $CurrentForm->getValue("jumprequiredatlogin") : $CurrentForm->getValue("x_jumprequiredatlogin");
		if (!$this->jumprequiredatlogin->IsDetailKey) {
			if (IsApi() && $val === NULL)
				$this->jumprequiredatlogin->Visible = FALSE; // Disable update for API request
			else
				$this->jumprequiredatlogin->setFormValue($val);
		}

		// Check field name 'ccbypass' first before field var 'x_ccbypass'
		$val = $CurrentForm->hasValue("ccbypass") ? $CurrentForm->getValue("ccbypass") : $CurrentForm->getValue("x_ccbypass");
		if (!$this->ccbypass->IsDetailKey) {
			if (IsApi() && $val === NULL)
				$this->ccbypass->Visible = FALSE; // Disable update for API request
			else
				$this->ccbypass->setFormValue($val);
		}

		// Check field name 'zip' first before field var 'x_zip'
		$val = $CurrentForm->hasValue("zip") ? $CurrentForm->getValue("zip") : $CurrentForm->getValue("x_zip");
		if (!$this->zip->IsDetailKey) {
			if (IsApi() && $val === NULL)
				$this->zip->Visible = FALSE; // Disable update for API request
			else
				$this->zip->setFormValue($val);
		}

		// Check field name 'other1' first before field var 'x_other1'
		$val = $CurrentForm->hasValue("other1") ? $CurrentForm->getValue("other1") : $CurrentForm->getValue("x_other1");
		if (!$this->other1->IsDetailKey) {
			if (IsApi() && $val === NULL)
				$this->other1->Visible = FALSE; // Disable update for API request
			else
				$this->other1->setFormValue($val);
		}

		// Check field name 'other2' first before field var 'x_other2'
		$val = $CurrentForm->hasValue("other2") ? $CurrentForm->getValue("other2") : $CurrentForm->getValue("x_other2");
		if (!$this->other2->IsDetailKey) {
			if (IsApi() && $val === NULL)
				$this->other2->Visible = FALSE; // Disable update for API request
			else
				$this->other2->setFormValue($val);
		}

		// Check field name 'other3' first before field var 'x_other3'
		$val = $CurrentForm->hasValue("other3") ? $CurrentForm->getValue("other3") : $CurrentForm->getValue("x_other3");
		if (!$this->other3->IsDetailKey) {
			if (IsApi() && $val === NULL)
				$this->other3->Visible = FALSE; // Disable update for API request
			else
				$this->other3->setFormValue($val);
		}

		// Check field name 'other4' first before field var 'x_other4'
		$val = $CurrentForm->hasValue("other4") ? $CurrentForm->getValue("other4") : $CurrentForm->getValue("x_other4");
		if (!$this->other4->IsDetailKey) {
			if (IsApi() && $val === NULL)
				$this->other4->Visible = FALSE; // Disable update for API request
			else
				$this->other4->setFormValue($val);
		}

		// Check field name 'other5' first before field var 'x_other5'
		$val = $CurrentForm->hasValue("other5") ? $CurrentForm->getValue("other5") : $CurrentForm->getValue("x_other5");
		if (!$this->other5->IsDetailKey) {
			if (IsApi() && $val === NULL)
				$this->other5->Visible = FALSE; // Disable update for API request
			else
				$this->other5->setFormValue($val);
		}

		// Check field name 'other6' first before field var 'x_other6'
		$val = $CurrentForm->hasValue("other6") ? $CurrentForm->getValue("other6") : $CurrentForm->getValue("x_other6");
		if (!$this->other6->IsDetailKey) {
			if (IsApi() && $val === NULL)
				$this->other6->Visible = FALSE; // Disable update for API request
			else
				$this->other6->setFormValue($val);
		}

		// Check field name 'mincashamount' first before field var 'x_mincashamount'
		$val = $CurrentForm->hasValue("mincashamount") ? $CurrentForm->getValue("mincashamount") : $CurrentForm->getValue("x_mincashamount");
		if (!$this->mincashamount->IsDetailKey) {
			if (IsApi() && $val === NULL)
				$this->mincashamount->Visible = FALSE; // Disable update for API request
			else
				$this->mincashamount->setFormValue($val);
		}

		// Check field name 'maxcashamount' first before field var 'x_maxcashamount'
		$val = $CurrentForm->hasValue("maxcashamount") ? $CurrentForm->getValue("maxcashamount") : $CurrentForm->getValue("x_maxcashamount");
		if (!$this->maxcashamount->IsDetailKey) {
			if (IsApi() && $val === NULL)
				$this->maxcashamount->Visible = FALSE; // Disable update for API request
			else
				$this->maxcashamount->setFormValue($val);
		}

		// Check field name 'maxtransferinamount' first before field var 'x_maxtransferinamount'
		$val = $CurrentForm->hasValue("maxtransferinamount") ? $CurrentForm->getValue("maxtransferinamount") : $CurrentForm->getValue("x_maxtransferinamount");
		if (!$this->maxtransferinamount->IsDetailKey) {
			if (IsApi() && $val === NULL)
				$this->maxtransferinamount->Visible = FALSE; // Disable update for API request
			else
				$this->maxtransferinamount->setFormValue($val);
		}

		// Check field name 'maxtransferoutamount' first before field var 'x_maxtransferoutamount'
		$val = $CurrentForm->hasValue("maxtransferoutamount") ? $CurrentForm->getValue("maxtransferoutamount") : $CurrentForm->getValue("x_maxtransferoutamount");
		if (!$this->maxtransferoutamount->IsDetailKey) {
			if (IsApi() && $val === NULL)
				$this->maxtransferoutamount->Visible = FALSE; // Disable update for API request
			else
				$this->maxtransferoutamount->setFormValue($val);
		}

		// Check field name 'legalid' first before field var 'x_legalid'
		$val = $CurrentForm->hasValue("legalid") ? $CurrentForm->getValue("legalid") : $CurrentForm->getValue("x_legalid");
		if (!$this->legalid->IsDetailKey) {
			if (IsApi() && $val === NULL)
				$this->legalid->Visible = FALSE; // Disable update for API request
			else
				$this->legalid->setFormValue($val);
		}

		// Check field name 'userpiview' first before field var 'x_userpiview'
		$val = $CurrentForm->hasValue("userpiview") ? $CurrentForm->getValue("userpiview") : $CurrentForm->getValue("x_userpiview");
		if (!$this->userpiview->IsDetailKey) {
			if (IsApi() && $val === NULL)
				$this->userpiview->Visible = FALSE; // Disable update for API request
			else
				$this->userpiview->setFormValue($val);
		}

		// Check field name 'lastmsgid' first before field var 'x_lastmsgid'
		$val = $CurrentForm->hasValue("lastmsgid") ? $CurrentForm->getValue("lastmsgid") : $CurrentForm->getValue("x_lastmsgid");
		if (!$this->lastmsgid->IsDetailKey) {
			if (IsApi() && $val === NULL)
				$this->lastmsgid->Visible = FALSE; // Disable update for API request
			else
				$this->lastmsgid->setFormValue($val);
		}

		// Check field name 'otprequiredforphysicalcards' first before field var 'x_otprequiredforphysicalcards'
		$val = $CurrentForm->hasValue("otprequiredforphysicalcards") ? $CurrentForm->getValue("otprequiredforphysicalcards") : $CurrentForm->getValue("x_otprequiredforphysicalcards");
		if (!$this->otprequiredforphysicalcards->IsDetailKey) {
			if (IsApi() && $val === NULL)
				$this->otprequiredforphysicalcards->Visible = FALSE; // Disable update for API request
			else
				$this->otprequiredforphysicalcards->setFormValue($val);
		}

		// Check field name 'otpvaliduntil' first before field var 'x_otpvaliduntil'
		$val = $CurrentForm->hasValue("otpvaliduntil") ? $CurrentForm->getValue("otpvaliduntil") : $CurrentForm->getValue("x_otpvaliduntil");
		if (!$this->otpvaliduntil->IsDetailKey) {
			if (IsApi() && $val === NULL)
				$this->otpvaliduntil->Visible = FALSE; // Disable update for API request
			else
				$this->otpvaliduntil->setFormValue($val);
			$this->otpvaliduntil->CurrentValue = UnFormatDateTime($this->otpvaliduntil->CurrentValue, 0);
		}

		// Check field name 'nationalitycountry' first before field var 'x_nationalitycountry'
		$val = $CurrentForm->hasValue("nationalitycountry") ? $CurrentForm->getValue("nationalitycountry") : $CurrentForm->getValue("x_nationalitycountry");
		if (!$this->nationalitycountry->IsDetailKey) {
			if (IsApi() && $val === NULL)
				$this->nationalitycountry->Visible = FALSE; // Disable update for API request
			else
				$this->nationalitycountry->setFormValue($val);
		}

		// Check field name 'classification' first before field var 'x_classification'
		$val = $CurrentForm->hasValue("classification") ? $CurrentForm->getValue("classification") : $CurrentForm->getValue("x_classification");
		if (!$this->classification->IsDetailKey) {
			if (IsApi() && $val === NULL)
				$this->classification->Visible = FALSE; // Disable update for API request
			else
				$this->classification->setFormValue($val);
		}

		// Check field name 'occupation' first before field var 'x_occupation'
		$val = $CurrentForm->hasValue("occupation") ? $CurrentForm->getValue("occupation") : $CurrentForm->getValue("x_occupation");
		if (!$this->occupation->IsDetailKey) {
			if (IsApi() && $val === NULL)
				$this->occupation->Visible = FALSE; // Disable update for API request
			else
				$this->occupation->setFormValue($val);
		}

		// Check field name 'sourceofincome' first before field var 'x_sourceofincome'
		$val = $CurrentForm->hasValue("sourceofincome") ? $CurrentForm->getValue("sourceofincome") : $CurrentForm->getValue("x_sourceofincome");
		if (!$this->sourceofincome->IsDetailKey) {
			if (IsApi() && $val === NULL)
				$this->sourceofincome->Visible = FALSE; // Disable update for API request
			else
				$this->sourceofincome->setFormValue($val);
		}

		// Check field name 'accountopeningdate' first before field var 'x_accountopeningdate'
		$val = $CurrentForm->hasValue("accountopeningdate") ? $CurrentForm->getValue("accountopeningdate") : $CurrentForm->getValue("x_accountopeningdate");
		if (!$this->accountopeningdate->IsDetailKey) {
			if (IsApi() && $val === NULL)
				$this->accountopeningdate->Visible = FALSE; // Disable update for API request
			else
				$this->accountopeningdate->setFormValue($val);
			$this->accountopeningdate->CurrentValue = UnFormatDateTime($this->accountopeningdate->CurrentValue, 0);
		}

		// Check field name 'extendedfields' first before field var 'x_extendedfields'
		$val = $CurrentForm->hasValue("extendedfields") ? $CurrentForm->getValue("extendedfields") : $CurrentForm->getValue("x_extendedfields");
		if (!$this->extendedfields->IsDetailKey) {
			if (IsApi() && $val === NULL)
				$this->extendedfields->Visible = FALSE; // Disable update for API request
			else
				$this->extendedfields->setFormValue($val);
		}

		// Check field name 'lastprofilestatuschangedate' first before field var 'x_lastprofilestatuschangedate'
		$val = $CurrentForm->hasValue("lastprofilestatuschangedate") ? $CurrentForm->getValue("lastprofilestatuschangedate") : $CurrentForm->getValue("x_lastprofilestatuschangedate");
		if (!$this->lastprofilestatuschangedate->IsDetailKey) {
			if (IsApi() && $val === NULL)
				$this->lastprofilestatuschangedate->Visible = FALSE; // Disable update for API request
			else
				$this->lastprofilestatuschangedate->setFormValue($val);
			$this->lastprofilestatuschangedate->CurrentValue = UnFormatDateTime($this->lastprofilestatuschangedate->CurrentValue, 0);
		}
		$this->getUploadFiles(); // Get upload files
	}

	// Restore form values
	public function restoreFormValues()
	{
		global $CurrentForm;
		$this->id->CurrentValue = $this->id->FormValue;
		$this->firstName->CurrentValue = $this->firstName->FormValue;
		$this->lastName->CurrentValue = $this->lastName->FormValue;
		$this->otherNames->CurrentValue = $this->otherNames->FormValue;
		$this->passwordRequireChange->CurrentValue = $this->passwordRequireChange->FormValue;
		$this->franchiseeID->CurrentValue = $this->franchiseeID->FormValue;
		$this->dateAdded->CurrentValue = $this->dateAdded->FormValue;
		$this->dateAdded->CurrentValue = UnFormatDateTime($this->dateAdded->CurrentValue, 1);
		$this->timezoneid->CurrentValue = $this->timezoneid->FormValue;
		$this->contactPhoneNo->CurrentValue = $this->contactPhoneNo->FormValue;
		$this->telephoneno->CurrentValue = $this->telephoneno->FormValue;
		$this->telephoneverified->CurrentValue = $this->telephoneverified->FormValue;
		$this->telephonereceivemessage->CurrentValue = $this->telephonereceivemessage->FormValue;
		$this->verification1->CurrentValue = $this->verification1->FormValue;
		$this->verification2->CurrentValue = $this->verification2->FormValue;
		$this->verification3->CurrentValue = $this->verification3->FormValue;
		$this->address1->CurrentValue = $this->address1->FormValue;
		$this->address2->CurrentValue = $this->address2->FormValue;
		$this->cityname->CurrentValue = $this->cityname->FormValue;
		$this->countryid->CurrentValue = $this->countryid->FormValue;
		$this->stateid->CurrentValue = $this->stateid->FormValue;
		$this->defaultcurrency->CurrentValue = $this->defaultcurrency->FormValue;
		$this->challengeq1->CurrentValue = $this->challengeq1->FormValue;
		$this->challengea1->CurrentValue = $this->challengea1->FormValue;
		$this->challengeq2->CurrentValue = $this->challengeq2->FormValue;
		$this->challengea2->CurrentValue = $this->challengea2->FormValue;
		$this->challengeq3->CurrentValue = $this->challengeq3->FormValue;
		$this->challengea3->CurrentValue = $this->challengea3->FormValue;
		$this->passwordCounter->CurrentValue = $this->passwordCounter->FormValue;
		$this->passwordChangedDate->CurrentValue = $this->passwordChangedDate->FormValue;
		$this->passwordChangedDate->CurrentValue = UnFormatDateTime($this->passwordChangedDate->CurrentValue, 1);
		$this->pinCounter->CurrentValue = $this->pinCounter->FormValue;
		$this->langID->CurrentValue = $this->langID->FormValue;
		$this->status->CurrentValue = $this->status->FormValue;
		$this->markedfordeletion->CurrentValue = $this->markedfordeletion->FormValue;
		$this->markedfordeletion->CurrentValue = UnFormatDateTime($this->markedfordeletion->CurrentValue, 0);
		$this->userType->CurrentValue = $this->userType->FormValue;
		$this->usersubtype->CurrentValue = $this->usersubtype->FormValue;
		$this->accountID->CurrentValue = $this->accountID->FormValue;
		$this->brokerid->CurrentValue = $this->brokerid->FormValue;
		$this->parentuserid->CurrentValue = $this->parentuserid->FormValue;
		$this->corporate->CurrentValue = $this->corporate->FormValue;
		$this->profilestatus->CurrentValue = $this->profilestatus->FormValue;
		$this->jumpappid->CurrentValue = $this->jumpappid->FormValue;
		$this->dateofbirth->CurrentValue = $this->dateofbirth->FormValue;
		$this->dateofbirth->CurrentValue = UnFormatDateTime($this->dateofbirth->CurrentValue, 2);
		$this->gender->CurrentValue = $this->gender->FormValue;
		$this->lastupdatedate->CurrentValue = $this->lastupdatedate->FormValue;
		$this->lastupdatedate->CurrentValue = UnFormatDateTime($this->lastupdatedate->CurrentValue, 1);
		$this->jumprequiredatlogin->CurrentValue = $this->jumprequiredatlogin->FormValue;
		$this->ccbypass->CurrentValue = $this->ccbypass->FormValue;
		$this->zip->CurrentValue = $this->zip->FormValue;
		$this->other1->CurrentValue = $this->other1->FormValue;
		$this->other2->CurrentValue = $this->other2->FormValue;
		$this->other3->CurrentValue = $this->other3->FormValue;
		$this->other4->CurrentValue = $this->other4->FormValue;
		$this->other5->CurrentValue = $this->other5->FormValue;
		$this->other6->CurrentValue = $this->other6->FormValue;
		$this->mincashamount->CurrentValue = $this->mincashamount->FormValue;
		$this->maxcashamount->CurrentValue = $this->maxcashamount->FormValue;
		$this->maxtransferinamount->CurrentValue = $this->maxtransferinamount->FormValue;
		$this->maxtransferoutamount->CurrentValue = $this->maxtransferoutamount->FormValue;
		$this->legalid->CurrentValue = $this->legalid->FormValue;
		$this->userpiview->CurrentValue = $this->userpiview->FormValue;
		$this->lastmsgid->CurrentValue = $this->lastmsgid->FormValue;
		$this->otprequiredforphysicalcards->CurrentValue = $this->otprequiredforphysicalcards->FormValue;
		$this->otpvaliduntil->CurrentValue = $this->otpvaliduntil->FormValue;
		$this->otpvaliduntil->CurrentValue = UnFormatDateTime($this->otpvaliduntil->CurrentValue, 0);
		$this->nationalitycountry->CurrentValue = $this->nationalitycountry->FormValue;
		$this->classification->CurrentValue = $this->classification->FormValue;
		$this->occupation->CurrentValue = $this->occupation->FormValue;
		$this->sourceofincome->CurrentValue = $this->sourceofincome->FormValue;
		$this->accountopeningdate->CurrentValue = $this->accountopeningdate->FormValue;
		$this->accountopeningdate->CurrentValue = UnFormatDateTime($this->accountopeningdate->CurrentValue, 0);
		$this->extendedfields->CurrentValue = $this->extendedfields->FormValue;
		$this->lastprofilestatuschangedate->CurrentValue = $this->lastprofilestatuschangedate->FormValue;
		$this->lastprofilestatuschangedate->CurrentValue = UnFormatDateTime($this->lastprofilestatuschangedate->CurrentValue, 0);
	}

	// Load row based on key values
	public function loadRow()
	{
		global $Security, $Language;
		$filter = $this->getRecordFilter();

		// Call Row Selecting event
		$this->Row_Selecting($filter);

		// Load SQL based on filter
		$this->CurrentFilter = $filter;
		$sql = $this->getCurrentSql();
		$conn = $this->getConnection();
		$res = FALSE;
		$rs = LoadRecordset($sql, $conn);
		if ($rs && !$rs->EOF) {
			$res = TRUE;
			$this->loadRowValues($rs); // Load row values
			$rs->close();
		}
		return $res;
	}

	// Load row values from recordset
	public function loadRowValues($rs = NULL)
	{
		if ($rs && !$rs->EOF)
			$row = $rs->fields;
		else
			$row = $this->newRow();

		// Call Row Selected event
		$this->Row_Selected($row);
		if (!$rs || $rs->EOF)
			return;
		$this->id->setDbValue($row['id']);
		$this->firstName->setDbValue($row['firstName']);
		$this->lastName->setDbValue($row['lastName']);
		$this->otherNames->setDbValue($row['otherNames']);
		$this->passwordRequireChange->setDbValue($row['passwordRequireChange']);
		$this->franchiseeID->setDbValue($row['franchiseeID']);
		$this->dateAdded->setDbValue($row['dateAdded']);
		$this->timezoneid->setDbValue($row['timezoneid']);
		$this->telephoneverificationcode->setDbValue($row['telephoneverificationcode']);
		$this->contactPhoneNo->setDbValue($row['contactPhoneNo']);
		$this->telephoneno->setDbValue($row['telephoneno']);
		$this->telephoneverified->setDbValue($row['telephoneverified']);
		$this->telephonereceivemessage->setDbValue($row['telephonereceivemessage']);
		$this->verification1->setDbValue($row['verification1']);
		$this->verification2->setDbValue($row['verification2']);
		$this->verification3->setDbValue($row['verification3']);
		$this->address1->setDbValue($row['address1']);
		$this->address2->setDbValue($row['address2']);
		$this->cityname->setDbValue($row['cityname']);
		$this->countryid->setDbValue($row['countryid']);
		$this->stateid->setDbValue($row['stateid']);
		$this->defaultcurrency->setDbValue($row['defaultcurrency']);
		$this->challengeq1->setDbValue($row['challengeq1']);
		$this->challengea1->setDbValue($row['challengea1']);
		$this->challengeq2->setDbValue($row['challengeq2']);
		$this->challengea2->setDbValue($row['challengea2']);
		$this->challengeq3->setDbValue($row['challengeq3']);
		$this->challengea3->setDbValue($row['challengea3']);
		$this->password->setDbValue($row['password']);
		$this->passwordCounter->setDbValue($row['passwordCounter']);
		$this->passwordChangedDate->setDbValue($row['passwordChangedDate']);
		$this->pin->setDbValue($row['pin']);
		$this->pinCounter->setDbValue($row['pinCounter']);
		$this->langID->setDbValue($row['langID']);
		$this->photo->Upload->DbValue = $row['photo'];
		$this->photo->setDbValue($this->photo->Upload->DbValue);
		$this->status->setDbValue($row['status']);
		$this->markedfordeletion->setDbValue($row['markedfordeletion']);
		$this->userType->setDbValue($row['userType']);
		$this->usersubtype->setDbValue($row['usersubtype']);
		$this->accountID->setDbValue($row['accountID']);
		$this->brokerid->setDbValue($row['brokerid']);
		$this->parentuserid->setDbValue($row['parentuserid']);
		$this->corporate->setDbValue($row['corporate']);
		$this->profilestatus->setDbValue($row['profilestatus']);
		$this->jumpappid->setDbValue($row['jumpappid']);
		$this->dateofbirth->setDbValue($row['dateofbirth']);
		$this->gender->setDbValue($row['gender']);
		$this->lastupdatedate->setDbValue($row['lastupdatedate']);
		$this->jumprequiredatlogin->setDbValue($row['jumprequiredatlogin']);
		$this->ccbypass->setDbValue($row['ccbypass']);
		$this->zip->setDbValue($row['zip']);
		$this->other1->setDbValue($row['other1']);
		$this->other2->setDbValue($row['other2']);
		$this->other3->setDbValue($row['other3']);
		$this->other4->setDbValue($row['other4']);
		$this->other5->setDbValue($row['other5']);
		$this->other6->setDbValue($row['other6']);
		$this->mincashamount->setDbValue($row['mincashamount']);
		$this->maxcashamount->setDbValue($row['maxcashamount']);
		$this->maxtransferinamount->setDbValue($row['maxtransferinamount']);
		$this->maxtransferoutamount->setDbValue($row['maxtransferoutamount']);
		$this->legalid->setDbValue($row['legalid']);
		$this->userpiview->setDbValue($row['userpiview']);
		$this->lastmsgid->setDbValue($row['lastmsgid']);
		$this->otprequiredforphysicalcards->setDbValue($row['otprequiredforphysicalcards']);
		$this->otpvalue->setDbValue($row['otpvalue']);
		$this->otpvaliduntil->setDbValue($row['otpvaliduntil']);
		$this->statusshadow->setDbValue($row['statusshadow']);
		$this->nationalitycountry->setDbValue($row['nationalitycountry']);
		$this->classification->setDbValue($row['classification']);
		$this->occupation->setDbValue($row['occupation']);
		$this->sourceofincome->setDbValue($row['sourceofincome']);
		$this->accountopeningdate->setDbValue($row['accountopeningdate']);
		$this->extendedfields->setDbValue($row['extendedfields']);
		$this->lastprofilestatuschangedate->setDbValue($row['lastprofilestatuschangedate']);
	}

	// Return a row with default values
	protected function newRow()
	{
		$row = [];
		$row['id'] = NULL;
		$row['firstName'] = NULL;
		$row['lastName'] = NULL;
		$row['otherNames'] = NULL;
		$row['passwordRequireChange'] = NULL;
		$row['franchiseeID'] = NULL;
		$row['dateAdded'] = NULL;
		$row['timezoneid'] = NULL;
		$row['telephoneverificationcode'] = NULL;
		$row['contactPhoneNo'] = NULL;
		$row['telephoneno'] = NULL;
		$row['telephoneverified'] = NULL;
		$row['telephonereceivemessage'] = NULL;
		$row['verification1'] = NULL;
		$row['verification2'] = NULL;
		$row['verification3'] = NULL;
		$row['address1'] = NULL;
		$row['address2'] = NULL;
		$row['cityname'] = NULL;
		$row['countryid'] = NULL;
		$row['stateid'] = NULL;
		$row['defaultcurrency'] = NULL;
		$row['challengeq1'] = NULL;
		$row['challengea1'] = NULL;
		$row['challengeq2'] = NULL;
		$row['challengea2'] = NULL;
		$row['challengeq3'] = NULL;
		$row['challengea3'] = NULL;
		$row['password'] = NULL;
		$row['passwordCounter'] = NULL;
		$row['passwordChangedDate'] = NULL;
		$row['pin'] = NULL;
		$row['pinCounter'] = NULL;
		$row['langID'] = NULL;
		$row['photo'] = NULL;
		$row['status'] = NULL;
		$row['markedfordeletion'] = NULL;
		$row['userType'] = NULL;
		$row['usersubtype'] = NULL;
		$row['accountID'] = NULL;
		$row['brokerid'] = NULL;
		$row['parentuserid'] = NULL;
		$row['corporate'] = NULL;
		$row['profilestatus'] = NULL;
		$row['jumpappid'] = NULL;
		$row['dateofbirth'] = NULL;
		$row['gender'] = NULL;
		$row['lastupdatedate'] = NULL;
		$row['jumprequiredatlogin'] = NULL;
		$row['ccbypass'] = NULL;
		$row['zip'] = NULL;
		$row['other1'] = NULL;
		$row['other2'] = NULL;
		$row['other3'] = NULL;
		$row['other4'] = NULL;
		$row['other5'] = NULL;
		$row['other6'] = NULL;
		$row['mincashamount'] = NULL;
		$row['maxcashamount'] = NULL;
		$row['maxtransferinamount'] = NULL;
		$row['maxtransferoutamount'] = NULL;
		$row['legalid'] = NULL;
		$row['userpiview'] = NULL;
		$row['lastmsgid'] = NULL;
		$row['otprequiredforphysicalcards'] = NULL;
		$row['otpvalue'] = NULL;
		$row['otpvaliduntil'] = NULL;
		$row['statusshadow'] = NULL;
		$row['nationalitycountry'] = NULL;
		$row['classification'] = NULL;
		$row['occupation'] = NULL;
		$row['sourceofincome'] = NULL;
		$row['accountopeningdate'] = NULL;
		$row['extendedfields'] = NULL;
		$row['lastprofilestatuschangedate'] = NULL;
		return $row;
	}

	// Load old record
	protected function loadOldRecord()
	{

		// Load key values from Session
		$validKey = TRUE;
		if (strval($this->getKey("id")) != "")
			$this->id->OldValue = $this->getKey("id"); // id
		else
			$validKey = FALSE;

		// Load old record
		$this->OldRecordset = NULL;
		if ($validKey) {
			$this->CurrentFilter = $this->getRecordFilter();
			$sql = $this->getCurrentSql();
			$conn = $this->getConnection();
			$this->OldRecordset = LoadRecordset($sql, $conn);
		}
		$this->loadRowValues($this->OldRecordset); // Load row values
		return $validKey;
	}

	// Render row values based on field settings
	public function renderRow()
	{
		global $Security, $Language, $CurrentLanguage;

		// Initialize URLs
		// Convert decimal values if posted back

		if ($this->mincashamount->FormValue == $this->mincashamount->CurrentValue && is_numeric(ConvertToFloatString($this->mincashamount->CurrentValue)))
			$this->mincashamount->CurrentValue = ConvertToFloatString($this->mincashamount->CurrentValue);

		// Convert decimal values if posted back
		if ($this->maxcashamount->FormValue == $this->maxcashamount->CurrentValue && is_numeric(ConvertToFloatString($this->maxcashamount->CurrentValue)))
			$this->maxcashamount->CurrentValue = ConvertToFloatString($this->maxcashamount->CurrentValue);

		// Convert decimal values if posted back
		if ($this->maxtransferinamount->FormValue == $this->maxtransferinamount->CurrentValue && is_numeric(ConvertToFloatString($this->maxtransferinamount->CurrentValue)))
			$this->maxtransferinamount->CurrentValue = ConvertToFloatString($this->maxtransferinamount->CurrentValue);

		// Convert decimal values if posted back
		if ($this->maxtransferoutamount->FormValue == $this->maxtransferoutamount->CurrentValue && is_numeric(ConvertToFloatString($this->maxtransferoutamount->CurrentValue)))
			$this->maxtransferoutamount->CurrentValue = ConvertToFloatString($this->maxtransferoutamount->CurrentValue);

		// Call Row_Rendering event
		$this->Row_Rendering();

		// Common render codes for all row types
		// id
		// firstName
		// lastName
		// otherNames
		// passwordRequireChange
		// franchiseeID
		// dateAdded
		// timezoneid
		// telephoneverificationcode
		// contactPhoneNo
		// telephoneno
		// telephoneverified
		// telephonereceivemessage
		// verification1
		// verification2
		// verification3
		// address1
		// address2
		// cityname
		// countryid
		// stateid
		// defaultcurrency
		// challengeq1
		// challengea1
		// challengeq2
		// challengea2
		// challengeq3
		// challengea3
		// password
		// passwordCounter
		// passwordChangedDate
		// pin
		// pinCounter
		// langID
		// photo
		// status
		// markedfordeletion
		// userType
		// usersubtype
		// accountID
		// brokerid
		// parentuserid
		// corporate
		// profilestatus
		// jumpappid
		// dateofbirth
		// gender
		// lastupdatedate
		// jumprequiredatlogin
		// ccbypass
		// zip
		// other1
		// other2
		// other3
		// other4
		// other5
		// other6
		// mincashamount
		// maxcashamount
		// maxtransferinamount
		// maxtransferoutamount
		// legalid
		// userpiview
		// lastmsgid
		// otprequiredforphysicalcards
		// otpvalue
		// otpvaliduntil
		// statusshadow
		// nationalitycountry
		// classification
		// occupation
		// sourceofincome
		// accountopeningdate
		// extendedfields
		// lastprofilestatuschangedate

		if ($this->RowType == ROWTYPE_VIEW) { // View row

			// id
			$this->id->ViewValue = $this->id->CurrentValue;
			$this->id->ViewCustomAttributes = "";

			// firstName
			$this->firstName->ViewValue = $this->firstName->CurrentValue;
			$this->firstName->ViewCustomAttributes = "";

			// lastName
			$this->lastName->ViewValue = $this->lastName->CurrentValue;
			$this->lastName->ViewCustomAttributes = "";

			// otherNames
			$this->otherNames->ViewValue = $this->otherNames->CurrentValue;
			$this->otherNames->ViewCustomAttributes = "";

			// passwordRequireChange
			$curVal = strval($this->passwordRequireChange->CurrentValue);
			if ($curVal != "") {
				$this->passwordRequireChange->ViewValue = $this->passwordRequireChange->lookupCacheOption($curVal);
				if ($this->passwordRequireChange->ViewValue === NULL) { // Lookup from database
					$filterWrk = "`id`" . SearchString("=", $curVal, DATATYPE_NUMBER, "");
					$sqlWrk = $this->passwordRequireChange->Lookup->getSql(FALSE, $filterWrk, '', $this);
					$rswrk = Conn()->execute($sqlWrk);
					if ($rswrk && !$rswrk->EOF) { // Lookup values found
						$arwrk = [];
						$arwrk[1] = $rswrk->fields('df');
						$this->passwordRequireChange->ViewValue = $this->passwordRequireChange->displayValue($arwrk);
						$rswrk->Close();
					} else {
						$this->passwordRequireChange->ViewValue = $this->passwordRequireChange->CurrentValue;
					}
				}
			} else {
				$this->passwordRequireChange->ViewValue = NULL;
			}
			$this->passwordRequireChange->ViewCustomAttributes = "";

			// franchiseeID
			$this->franchiseeID->ViewValue = $this->franchiseeID->CurrentValue;
			$this->franchiseeID->ViewCustomAttributes = "";

			// dateAdded
			$this->dateAdded->ViewValue = $this->dateAdded->CurrentValue;
			$this->dateAdded->ViewValue = FormatDateTime($this->dateAdded->ViewValue, 1);
			$this->dateAdded->ViewCustomAttributes = "";

			// timezoneid
			$curVal = strval($this->timezoneid->CurrentValue);
			if ($curVal != "") {
				$this->timezoneid->ViewValue = $this->timezoneid->lookupCacheOption($curVal);
				if ($this->timezoneid->ViewValue === NULL) { // Lookup from database
					$filterWrk = "`timeZoneID`" . SearchString("=", $curVal, DATATYPE_NUMBER, "_4payreference");
					$sqlWrk = $this->timezoneid->Lookup->getSql(FALSE, $filterWrk, '', $this);
					$rswrk = Conn("_4payreference")->execute($sqlWrk);
					if ($rswrk && !$rswrk->EOF) { // Lookup values found
						$arwrk = [];
						$arwrk[1] = $rswrk->fields('df');
						$this->timezoneid->ViewValue = $this->timezoneid->displayValue($arwrk);
						$rswrk->Close();
					} else {
						$this->timezoneid->ViewValue = $this->timezoneid->CurrentValue;
					}
				}
			} else {
				$this->timezoneid->ViewValue = NULL;
			}
			$this->timezoneid->ViewCustomAttributes = "";

			// contactPhoneNo
			$this->contactPhoneNo->ViewValue = $this->contactPhoneNo->CurrentValue;
			$this->contactPhoneNo->ViewCustomAttributes = "";

			// telephoneno
			$this->telephoneno->ViewValue = $this->telephoneno->CurrentValue;
			$this->telephoneno->ViewCustomAttributes = "";

			// telephoneverified
			$curVal = strval($this->telephoneverified->CurrentValue);
			if ($curVal != "") {
				$this->telephoneverified->ViewValue = $this->telephoneverified->lookupCacheOption($curVal);
				if ($this->telephoneverified->ViewValue === NULL) { // Lookup from database
					$filterWrk = "`id`" . SearchString("=", $curVal, DATATYPE_NUMBER, "");
					$sqlWrk = $this->telephoneverified->Lookup->getSql(FALSE, $filterWrk, '', $this);
					$rswrk = Conn()->execute($sqlWrk);
					if ($rswrk && !$rswrk->EOF) { // Lookup values found
						$arwrk = [];
						$arwrk[1] = $rswrk->fields('df');
						$this->telephoneverified->ViewValue = $this->telephoneverified->displayValue($arwrk);
						$rswrk->Close();
					} else {
						$this->telephoneverified->ViewValue = $this->telephoneverified->CurrentValue;
					}
				}
			} else {
				$this->telephoneverified->ViewValue = NULL;
			}
			$this->telephoneverified->ViewCustomAttributes = "";

			// telephonereceivemessage
			$curVal = strval($this->telephonereceivemessage->CurrentValue);
			if ($curVal != "") {
				$this->telephonereceivemessage->ViewValue = $this->telephonereceivemessage->lookupCacheOption($curVal);
				if ($this->telephonereceivemessage->ViewValue === NULL) { // Lookup from database
					$filterWrk = "`id`" . SearchString("=", $curVal, DATATYPE_NUMBER, "");
					$sqlWrk = $this->telephonereceivemessage->Lookup->getSql(FALSE, $filterWrk, '', $this);
					$rswrk = Conn()->execute($sqlWrk);
					if ($rswrk && !$rswrk->EOF) { // Lookup values found
						$arwrk = [];
						$arwrk[1] = $rswrk->fields('df');
						$this->telephonereceivemessage->ViewValue = $this->telephonereceivemessage->displayValue($arwrk);
						$rswrk->Close();
					} else {
						$this->telephonereceivemessage->ViewValue = $this->telephonereceivemessage->CurrentValue;
					}
				}
			} else {
				$this->telephonereceivemessage->ViewValue = NULL;
			}
			$this->telephonereceivemessage->ViewCustomAttributes = "";

			// verification1
			$this->verification1->ViewValue = $this->verification1->CurrentValue;
			$this->verification1->ViewCustomAttributes = "";

			// verification2
			$this->verification2->ViewValue = $this->verification2->CurrentValue;
			$this->verification2->ViewCustomAttributes = "";

			// verification3
			$this->verification3->ViewValue = $this->verification3->CurrentValue;
			$this->verification3->ViewCustomAttributes = "";

			// address1
			$this->address1->ViewValue = $this->address1->CurrentValue;
			$this->address1->ViewCustomAttributes = "";

			// address2
			$this->address2->ViewValue = $this->address2->CurrentValue;
			$this->address2->ViewCustomAttributes = "";

			// cityname
			$this->cityname->ViewValue = $this->cityname->CurrentValue;
			$this->cityname->ViewCustomAttributes = "";

			// countryid
			$curVal = strval($this->countryid->CurrentValue);
			if ($curVal != "") {
				$this->countryid->ViewValue = $this->countryid->lookupCacheOption($curVal);
				if ($this->countryid->ViewValue === NULL) { // Lookup from database
					$filterWrk = "`countryID`" . SearchString("=", $curVal, DATATYPE_STRING, "");
					$sqlWrk = $this->countryid->Lookup->getSql(FALSE, $filterWrk, '', $this);
					$rswrk = Conn()->execute($sqlWrk);
					if ($rswrk && !$rswrk->EOF) { // Lookup values found
						$arwrk = [];
						$arwrk[1] = $rswrk->fields('df');
						$this->countryid->ViewValue = $this->countryid->displayValue($arwrk);
						$rswrk->Close();
					} else {
						$this->countryid->ViewValue = $this->countryid->CurrentValue;
					}
				}
			} else {
				$this->countryid->ViewValue = NULL;
			}
			$this->countryid->ViewCustomAttributes = "";

			// stateid
			$curVal = strval($this->stateid->CurrentValue);
			if ($curVal != "") {
				$this->stateid->ViewValue = $this->stateid->lookupCacheOption($curVal);
				if ($this->stateid->ViewValue === NULL) { // Lookup from database
					$filterWrk = "`stateid`" . SearchString("=", $curVal, DATATYPE_STRING, "_4payreference");
					$sqlWrk = $this->stateid->Lookup->getSql(FALSE, $filterWrk, '', $this);
					$rswrk = Conn("_4payreference")->execute($sqlWrk);
					if ($rswrk && !$rswrk->EOF) { // Lookup values found
						$arwrk = [];
						$arwrk[1] = $rswrk->fields('df');
						$arwrk[2] = $rswrk->fields('df2');
						$this->stateid->ViewValue = $this->stateid->displayValue($arwrk);
						$rswrk->Close();
					} else {
						$this->stateid->ViewValue = $this->stateid->CurrentValue;
					}
				}
			} else {
				$this->stateid->ViewValue = NULL;
			}
			$this->stateid->ViewCustomAttributes = "";

			// defaultcurrency
			$curVal = strval($this->defaultcurrency->CurrentValue);
			if ($curVal != "") {
				$this->defaultcurrency->ViewValue = $this->defaultcurrency->lookupCacheOption($curVal);
				if ($this->defaultcurrency->ViewValue === NULL) { // Lookup from database
					$filterWrk = "`currCode`" . SearchString("=", $curVal, DATATYPE_STRING, "_4payreference");
					$sqlWrk = $this->defaultcurrency->Lookup->getSql(FALSE, $filterWrk, '', $this);
					$rswrk = Conn("_4payreference")->execute($sqlWrk);
					if ($rswrk && !$rswrk->EOF) { // Lookup values found
						$arwrk = [];
						$arwrk[1] = $rswrk->fields('df');
						$this->defaultcurrency->ViewValue = $this->defaultcurrency->displayValue($arwrk);
						$rswrk->Close();
					} else {
						$this->defaultcurrency->ViewValue = $this->defaultcurrency->CurrentValue;
					}
				}
			} else {
				$this->defaultcurrency->ViewValue = NULL;
			}
			$this->defaultcurrency->ViewCustomAttributes = "";

			// challengeq1
			$this->challengeq1->ViewValue = $this->challengeq1->CurrentValue;
			$this->challengeq1->ViewCustomAttributes = "";

			// challengea1
			$this->challengea1->ViewValue = $this->challengea1->CurrentValue;
			$this->challengea1->ViewCustomAttributes = "";

			// challengeq2
			$this->challengeq2->ViewValue = $this->challengeq2->CurrentValue;
			$this->challengeq2->ViewCustomAttributes = "";

			// challengea2
			$this->challengea2->ViewValue = $this->challengea2->CurrentValue;
			$this->challengea2->ViewCustomAttributes = "";

			// challengeq3
			$this->challengeq3->ViewValue = $this->challengeq3->CurrentValue;
			$this->challengeq3->ViewCustomAttributes = "";

			// challengea3
			$this->challengea3->ViewValue = $this->challengea3->CurrentValue;
			$this->challengea3->ViewCustomAttributes = "";

			// passwordCounter
			$this->passwordCounter->ViewValue = $this->passwordCounter->CurrentValue;
			$this->passwordCounter->ViewCustomAttributes = "";

			// passwordChangedDate
			$this->passwordChangedDate->ViewValue = $this->passwordChangedDate->CurrentValue;
			$this->passwordChangedDate->ViewValue = FormatDateTime($this->passwordChangedDate->ViewValue, 1);
			$this->passwordChangedDate->ViewCustomAttributes = "";

			// pinCounter
			$this->pinCounter->ViewValue = $this->pinCounter->CurrentValue;
			$this->pinCounter->ViewCustomAttributes = "";

			// langID
			$curVal = strval($this->langID->CurrentValue);
			if ($curVal != "") {
				$this->langID->ViewValue = $this->langID->lookupCacheOption($curVal);
				if ($this->langID->ViewValue === NULL) { // Lookup from database
					$filterWrk = "`langID`" . SearchString("=", $curVal, DATATYPE_STRING, "");
					$lookupFilter = function() {
						return "`inlangid` = 'EN'";
					};
					$lookupFilter = $lookupFilter->bindTo($this);
					$sqlWrk = $this->langID->Lookup->getSql(FALSE, $filterWrk, $lookupFilter, $this);
					$rswrk = Conn()->execute($sqlWrk);
					if ($rswrk && !$rswrk->EOF) { // Lookup values found
						$arwrk = [];
						$arwrk[1] = $rswrk->fields('df');
						$this->langID->ViewValue = $this->langID->displayValue($arwrk);
						$rswrk->Close();
					} else {
						$this->langID->ViewValue = $this->langID->CurrentValue;
					}
				}
			} else {
				$this->langID->ViewValue = NULL;
			}
			$this->langID->ViewCustomAttributes = "";

			// photo
			if (!EmptyValue($this->photo->Upload->DbValue)) {
				$this->photo->ViewValue = $this->photo->Upload->DbValue;
			} else {
				$this->photo->ViewValue = "";
			}
			$this->photo->ViewCustomAttributes = "";

			// status
			$curVal = strval($this->status->CurrentValue);
			if ($curVal != "") {
				$this->status->ViewValue = $this->status->lookupCacheOption($curVal);
				if ($this->status->ViewValue === NULL) { // Lookup from database
					$filterWrk = "`statusID`" . SearchString("=", $curVal, DATATYPE_NUMBER, "");
					$sqlWrk = $this->status->Lookup->getSql(FALSE, $filterWrk, '', $this);
					$rswrk = Conn()->execute($sqlWrk);
					if ($rswrk && !$rswrk->EOF) { // Lookup values found
						$arwrk = [];
						$arwrk[1] = $rswrk->fields('df');
						$this->status->ViewValue = $this->status->displayValue($arwrk);
						$rswrk->Close();
					} else {
						$this->status->ViewValue = $this->status->CurrentValue;
					}
				}
			} else {
				$this->status->ViewValue = NULL;
			}
			$this->status->ViewCustomAttributes = "";

			// markedfordeletion
			$this->markedfordeletion->ViewValue = $this->markedfordeletion->CurrentValue;
			$this->markedfordeletion->ViewValue = FormatDateTime($this->markedfordeletion->ViewValue, 0);
			$this->markedfordeletion->ViewCustomAttributes = "";

			// userType
			$curVal = strval($this->userType->CurrentValue);
			if ($curVal != "") {
				$this->userType->ViewValue = $this->userType->lookupCacheOption($curVal);
				if ($this->userType->ViewValue === NULL) { // Lookup from database
					$filterWrk = "`typeID`" . SearchString("=", $curVal, DATATYPE_NUMBER, "_4payreference");
					$sqlWrk = $this->userType->Lookup->getSql(FALSE, $filterWrk, '', $this);
					$rswrk = Conn("_4payreference")->execute($sqlWrk);
					if ($rswrk && !$rswrk->EOF) { // Lookup values found
						$arwrk = [];
						$arwrk[1] = $rswrk->fields('df');
						$this->userType->ViewValue = $this->userType->displayValue($arwrk);
						$rswrk->Close();
					} else {
						$this->userType->ViewValue = $this->userType->CurrentValue;
					}
				}
			} else {
				$this->userType->ViewValue = NULL;
			}
			$this->userType->ViewCustomAttributes = "";

			// usersubtype
			$curVal = strval($this->usersubtype->CurrentValue);
			if ($curVal != "") {
				$this->usersubtype->ViewValue = $this->usersubtype->lookupCacheOption($curVal);
				if ($this->usersubtype->ViewValue === NULL) { // Lookup from database
					$filterWrk = "`subtypeID`" . SearchString("=", $curVal, DATATYPE_NUMBER, "_4payreference");
					$sqlWrk = $this->usersubtype->Lookup->getSql(FALSE, $filterWrk, '', $this);
					$rswrk = Conn("_4payreference")->execute($sqlWrk);
					if ($rswrk && !$rswrk->EOF) { // Lookup values found
						$arwrk = [];
						$arwrk[1] = $rswrk->fields('df');
						$this->usersubtype->ViewValue = $this->usersubtype->displayValue($arwrk);
						$rswrk->Close();
					} else {
						$this->usersubtype->ViewValue = $this->usersubtype->CurrentValue;
					}
				}
			} else {
				$this->usersubtype->ViewValue = NULL;
			}
			$this->usersubtype->ViewCustomAttributes = "";

			// accountID
			$this->accountID->ViewValue = $this->accountID->CurrentValue;
			$this->accountID->ViewCustomAttributes = "";

			// brokerid
			$this->brokerid->ViewValue = $this->brokerid->CurrentValue;
			$this->brokerid->ViewCustomAttributes = "";

			// parentuserid
			$this->parentuserid->ViewValue = $this->parentuserid->CurrentValue;
			$this->parentuserid->ViewCustomAttributes = "";

			// corporate
			$curVal = strval($this->corporate->CurrentValue);
			if ($curVal != "") {
				$this->corporate->ViewValue = $this->corporate->lookupCacheOption($curVal);
				if ($this->corporate->ViewValue === NULL) { // Lookup from database
					$filterWrk = "`id`" . SearchString("=", $curVal, DATATYPE_NUMBER, "");
					$sqlWrk = $this->corporate->Lookup->getSql(FALSE, $filterWrk, '', $this);
					$rswrk = Conn()->execute($sqlWrk);
					if ($rswrk && !$rswrk->EOF) { // Lookup values found
						$arwrk = [];
						$arwrk[1] = $rswrk->fields('df');
						$this->corporate->ViewValue = $this->corporate->displayValue($arwrk);
						$rswrk->Close();
					} else {
						$this->corporate->ViewValue = $this->corporate->CurrentValue;
					}
				}
			} else {
				$this->corporate->ViewValue = NULL;
			}
			$this->corporate->ViewCustomAttributes = "";

			// profilestatus
			$curVal = strval($this->profilestatus->CurrentValue);
			if ($curVal != "") {
				$this->profilestatus->ViewValue = $this->profilestatus->lookupCacheOption($curVal);
				if ($this->profilestatus->ViewValue === NULL) { // Lookup from database
					$filterWrk = "`statusID`" . SearchString("=", $curVal, DATATYPE_NUMBER, "_4payreference");
					$sqlWrk = $this->profilestatus->Lookup->getSql(FALSE, $filterWrk, '', $this);
					$rswrk = Conn("_4payreference")->execute($sqlWrk);
					if ($rswrk && !$rswrk->EOF) { // Lookup values found
						$arwrk = [];
						$arwrk[1] = $rswrk->fields('df');
						$this->profilestatus->ViewValue = $this->profilestatus->displayValue($arwrk);
						$rswrk->Close();
					} else {
						$this->profilestatus->ViewValue = $this->profilestatus->CurrentValue;
					}
				}
			} else {
				$this->profilestatus->ViewValue = NULL;
			}
			$this->profilestatus->ViewCustomAttributes = "";

			// jumpappid
			$this->jumpappid->ViewValue = $this->jumpappid->CurrentValue;
			$this->jumpappid->ViewCustomAttributes = "";

			// dateofbirth
			$this->dateofbirth->ViewValue = $this->dateofbirth->CurrentValue;
			$this->dateofbirth->ViewValue = FormatDateTime($this->dateofbirth->ViewValue, 2);
			$this->dateofbirth->ViewCustomAttributes = "";

			// gender
			$curVal = strval($this->gender->CurrentValue);
			if ($curVal != "") {
				$this->gender->ViewValue = $this->gender->lookupCacheOption($curVal);
				if ($this->gender->ViewValue === NULL) { // Lookup from database
					$filterWrk = "`id`" . SearchString("=", $curVal, DATATYPE_NUMBER, "_4payreference");
					$sqlWrk = $this->gender->Lookup->getSql(FALSE, $filterWrk, '', $this);
					$rswrk = Conn("_4payreference")->execute($sqlWrk);
					if ($rswrk && !$rswrk->EOF) { // Lookup values found
						$arwrk = [];
						$arwrk[1] = $rswrk->fields('df');
						$this->gender->ViewValue = $this->gender->displayValue($arwrk);
						$rswrk->Close();
					} else {
						$this->gender->ViewValue = $this->gender->CurrentValue;
					}
				}
			} else {
				$this->gender->ViewValue = NULL;
			}
			$this->gender->ViewCustomAttributes = "";

			// lastupdatedate
			$this->lastupdatedate->ViewValue = $this->lastupdatedate->CurrentValue;
			$this->lastupdatedate->ViewValue = FormatDateTime($this->lastupdatedate->ViewValue, 1);
			$this->lastupdatedate->ViewCustomAttributes = "";

			// jumprequiredatlogin
			$curVal = strval($this->jumprequiredatlogin->CurrentValue);
			if ($curVal != "") {
				$this->jumprequiredatlogin->ViewValue = $this->jumprequiredatlogin->lookupCacheOption($curVal);
				if ($this->jumprequiredatlogin->ViewValue === NULL) { // Lookup from database
					$filterWrk = "`id`" . SearchString("=", $curVal, DATATYPE_NUMBER, "");
					$sqlWrk = $this->jumprequiredatlogin->Lookup->getSql(FALSE, $filterWrk, '', $this);
					$rswrk = Conn()->execute($sqlWrk);
					if ($rswrk && !$rswrk->EOF) { // Lookup values found
						$arwrk = [];
						$arwrk[1] = $rswrk->fields('df');
						$this->jumprequiredatlogin->ViewValue = $this->jumprequiredatlogin->displayValue($arwrk);
						$rswrk->Close();
					} else {
						$this->jumprequiredatlogin->ViewValue = $this->jumprequiredatlogin->CurrentValue;
					}
				}
			} else {
				$this->jumprequiredatlogin->ViewValue = NULL;
			}
			$this->jumprequiredatlogin->ViewCustomAttributes = "";

			// ccbypass
			$curVal = strval($this->ccbypass->CurrentValue);
			if ($curVal != "") {
				$this->ccbypass->ViewValue = $this->ccbypass->lookupCacheOption($curVal);
				if ($this->ccbypass->ViewValue === NULL) { // Lookup from database
					$filterWrk = "`id`" . SearchString("=", $curVal, DATATYPE_NUMBER, "");
					$sqlWrk = $this->ccbypass->Lookup->getSql(FALSE, $filterWrk, '', $this);
					$rswrk = Conn()->execute($sqlWrk);
					if ($rswrk && !$rswrk->EOF) { // Lookup values found
						$arwrk = [];
						$arwrk[1] = $rswrk->fields('df');
						$this->ccbypass->ViewValue = $this->ccbypass->displayValue($arwrk);
						$rswrk->Close();
					} else {
						$this->ccbypass->ViewValue = $this->ccbypass->CurrentValue;
					}
				}
			} else {
				$this->ccbypass->ViewValue = NULL;
			}
			$this->ccbypass->ViewCustomAttributes = "";

			// zip
			$this->zip->ViewValue = $this->zip->CurrentValue;
			$this->zip->ViewCustomAttributes = "";

			// other1
			$this->other1->ViewValue = $this->other1->CurrentValue;
			$this->other1->ViewCustomAttributes = "";

			// other2
			$this->other2->ViewValue = $this->other2->CurrentValue;
			$this->other2->ViewCustomAttributes = "";

			// other3
			$this->other3->ViewValue = $this->other3->CurrentValue;
			$this->other3->ViewCustomAttributes = "";

			// other4
			$this->other4->ViewValue = $this->other4->CurrentValue;
			$this->other4->ViewCustomAttributes = "";

			// other5
			$this->other5->ViewValue = $this->other5->CurrentValue;
			$this->other5->ViewCustomAttributes = "";

			// other6
			$this->other6->ViewValue = $this->other6->CurrentValue;
			$this->other6->ViewCustomAttributes = "";

			// mincashamount
			$this->mincashamount->ViewValue = $this->mincashamount->CurrentValue;
			$this->mincashamount->ViewValue = FormatNumber($this->mincashamount->ViewValue, Config("DEFAULT_DECIMAL_PRECISION"));
			$this->mincashamount->ViewCustomAttributes = "";

			// maxcashamount
			$this->maxcashamount->ViewValue = $this->maxcashamount->CurrentValue;
			$this->maxcashamount->ViewValue = FormatNumber($this->maxcashamount->ViewValue, Config("DEFAULT_DECIMAL_PRECISION"));
			$this->maxcashamount->ViewCustomAttributes = "";

			// maxtransferinamount
			$this->maxtransferinamount->ViewValue = $this->maxtransferinamount->CurrentValue;
			$this->maxtransferinamount->ViewValue = FormatNumber($this->maxtransferinamount->ViewValue, Config("DEFAULT_DECIMAL_PRECISION"));
			$this->maxtransferinamount->ViewCustomAttributes = "";

			// maxtransferoutamount
			$this->maxtransferoutamount->ViewValue = $this->maxtransferoutamount->CurrentValue;
			$this->maxtransferoutamount->ViewValue = FormatNumber($this->maxtransferoutamount->ViewValue, Config("DEFAULT_DECIMAL_PRECISION"));
			$this->maxtransferoutamount->ViewCustomAttributes = "";

			// legalid
			$this->legalid->ViewValue = $this->legalid->CurrentValue;
			$this->legalid->ViewCustomAttributes = "";

			// userpiview
			$curVal = strval($this->userpiview->CurrentValue);
			if ($curVal != "") {
				$this->userpiview->ViewValue = $this->userpiview->lookupCacheOption($curVal);
				if ($this->userpiview->ViewValue === NULL) { // Lookup from database
					$filterWrk = "`id`" . SearchString("=", $curVal, DATATYPE_NUMBER, "");
					$sqlWrk = $this->userpiview->Lookup->getSql(FALSE, $filterWrk, '', $this);
					$rswrk = Conn()->execute($sqlWrk);
					if ($rswrk && !$rswrk->EOF) { // Lookup values found
						$arwrk = [];
						$arwrk[1] = $rswrk->fields('df');
						$this->userpiview->ViewValue = $this->userpiview->displayValue($arwrk);
						$rswrk->Close();
					} else {
						$this->userpiview->ViewValue = $this->userpiview->CurrentValue;
					}
				}
			} else {
				$this->userpiview->ViewValue = NULL;
			}
			$this->userpiview->ViewCustomAttributes = "";

			// lastmsgid
			$this->lastmsgid->ViewValue = $this->lastmsgid->CurrentValue;
			$this->lastmsgid->ViewCustomAttributes = "";

			// otprequiredforphysicalcards
			$this->otprequiredforphysicalcards->ViewValue = $this->otprequiredforphysicalcards->CurrentValue;
			$this->otprequiredforphysicalcards->ViewValue = FormatNumber($this->otprequiredforphysicalcards->ViewValue, 0, -2, -2, -2);
			$this->otprequiredforphysicalcards->ViewCustomAttributes = "";

			// otpvaliduntil
			$this->otpvaliduntil->ViewValue = $this->otpvaliduntil->CurrentValue;
			$this->otpvaliduntil->ViewValue = FormatDateTime($this->otpvaliduntil->ViewValue, 0);
			$this->otpvaliduntil->ViewCustomAttributes = "";

			// nationalitycountry
			$curVal = strval($this->nationalitycountry->CurrentValue);
			if ($curVal != "") {
				$this->nationalitycountry->ViewValue = $this->nationalitycountry->lookupCacheOption($curVal);
				if ($this->nationalitycountry->ViewValue === NULL) { // Lookup from database
					$filterWrk = "`countryID`" . SearchString("=", $curVal, DATATYPE_STRING, "_4payreference");
					$sqlWrk = $this->nationalitycountry->Lookup->getSql(FALSE, $filterWrk, '', $this);
					$rswrk = Conn("_4payreference")->execute($sqlWrk);
					if ($rswrk && !$rswrk->EOF) { // Lookup values found
						$arwrk = [];
						$arwrk[1] = $rswrk->fields('df');
						$arwrk[2] = $rswrk->fields('df2');
						$this->nationalitycountry->ViewValue = $this->nationalitycountry->displayValue($arwrk);
						$rswrk->Close();
					} else {
						$this->nationalitycountry->ViewValue = $this->nationalitycountry->CurrentValue;
					}
				}
			} else {
				$this->nationalitycountry->ViewValue = NULL;
			}
			$this->nationalitycountry->ViewCustomAttributes = "";

			// classification
			$curVal = strval($this->classification->CurrentValue);
			if ($curVal != "") {
				$this->classification->ViewValue = $this->classification->lookupCacheOption($curVal);
				if ($this->classification->ViewValue === NULL) { // Lookup from database
					$filterWrk = "`typeID`" . SearchString("=", $curVal, DATATYPE_STRING, "_4payreference");
					$sqlWrk = $this->classification->Lookup->getSql(FALSE, $filterWrk, '', $this);
					$rswrk = Conn("_4payreference")->execute($sqlWrk);
					if ($rswrk && !$rswrk->EOF) { // Lookup values found
						$arwrk = [];
						$arwrk[1] = $rswrk->fields('df');
						$this->classification->ViewValue = $this->classification->displayValue($arwrk);
						$rswrk->Close();
					} else {
						$this->classification->ViewValue = $this->classification->CurrentValue;
					}
				}
			} else {
				$this->classification->ViewValue = NULL;
			}
			$this->classification->ViewCustomAttributes = "";

			// occupation
			$this->occupation->ViewValue = $this->occupation->CurrentValue;
			$curVal = strval($this->occupation->CurrentValue);
			if ($curVal != "") {
				$this->occupation->ViewValue = $this->occupation->lookupCacheOption($curVal);
				if ($this->occupation->ViewValue === NULL) { // Lookup from database
					$filterWrk = "`typeID`" . SearchString("=", $curVal, DATATYPE_STRING, "_4payreference");
					$sqlWrk = $this->occupation->Lookup->getSql(FALSE, $filterWrk, '', $this);
					$rswrk = Conn("_4payreference")->execute($sqlWrk);
					if ($rswrk && !$rswrk->EOF) { // Lookup values found
						$arwrk = [];
						$arwrk[1] = $rswrk->fields('df');
						$this->occupation->ViewValue = $this->occupation->displayValue($arwrk);
						$rswrk->Close();
					} else {
						$this->occupation->ViewValue = $this->occupation->CurrentValue;
					}
				}
			} else {
				$this->occupation->ViewValue = NULL;
			}
			$this->occupation->ViewCustomAttributes = "";

			// sourceofincome
			$curVal = strval($this->sourceofincome->CurrentValue);
			if ($curVal != "") {
				$this->sourceofincome->ViewValue = $this->sourceofincome->lookupCacheOption($curVal);
				if ($this->sourceofincome->ViewValue === NULL) { // Lookup from database
					$filterWrk = "`typeID`" . SearchString("=", $curVal, DATATYPE_STRING, "_4payreference");
					$sqlWrk = $this->sourceofincome->Lookup->getSql(FALSE, $filterWrk, '', $this);
					$rswrk = Conn("_4payreference")->execute($sqlWrk);
					if ($rswrk && !$rswrk->EOF) { // Lookup values found
						$arwrk = [];
						$arwrk[1] = $rswrk->fields('df');
						$this->sourceofincome->ViewValue = $this->sourceofincome->displayValue($arwrk);
						$rswrk->Close();
					} else {
						$this->sourceofincome->ViewValue = $this->sourceofincome->CurrentValue;
					}
				}
			} else {
				$this->sourceofincome->ViewValue = NULL;
			}
			$this->sourceofincome->ViewCustomAttributes = "";

			// accountopeningdate
			$this->accountopeningdate->ViewValue = $this->accountopeningdate->CurrentValue;
			$this->accountopeningdate->ViewValue = FormatDateTime($this->accountopeningdate->ViewValue, 0);
			$this->accountopeningdate->ViewCustomAttributes = "";

			// extendedfields
			$this->extendedfields->ViewValue = $this->extendedfields->CurrentValue;
			$this->extendedfields->ViewCustomAttributes = "";

			// lastprofilestatuschangedate
			$this->lastprofilestatuschangedate->ViewValue = $this->lastprofilestatuschangedate->CurrentValue;
			$this->lastprofilestatuschangedate->ViewValue = FormatDateTime($this->lastprofilestatuschangedate->ViewValue, 0);
			$this->lastprofilestatuschangedate->ViewCustomAttributes = "";

			// id
			$this->id->LinkCustomAttributes = "";
			$this->id->HrefValue = "";
			$this->id->TooltipValue = "";

			// firstName
			$this->firstName->LinkCustomAttributes = "";
			$this->firstName->HrefValue = "";
			$this->firstName->TooltipValue = "";

			// lastName
			$this->lastName->LinkCustomAttributes = "";
			$this->lastName->HrefValue = "";
			$this->lastName->TooltipValue = "";

			// otherNames
			$this->otherNames->LinkCustomAttributes = "";
			$this->otherNames->HrefValue = "";
			$this->otherNames->TooltipValue = "";

			// passwordRequireChange
			$this->passwordRequireChange->LinkCustomAttributes = "";
			$this->passwordRequireChange->HrefValue = "";
			$this->passwordRequireChange->TooltipValue = "";

			// franchiseeID
			$this->franchiseeID->LinkCustomAttributes = "";
			$this->franchiseeID->HrefValue = "";
			$this->franchiseeID->TooltipValue = "";

			// dateAdded
			$this->dateAdded->LinkCustomAttributes = "";
			$this->dateAdded->HrefValue = "";
			$this->dateAdded->TooltipValue = "";

			// timezoneid
			$this->timezoneid->LinkCustomAttributes = "";
			$this->timezoneid->HrefValue = "";
			$this->timezoneid->TooltipValue = "";

			// contactPhoneNo
			$this->contactPhoneNo->LinkCustomAttributes = "";
			$this->contactPhoneNo->HrefValue = "";
			$this->contactPhoneNo->TooltipValue = "";

			// telephoneno
			$this->telephoneno->LinkCustomAttributes = "";
			$this->telephoneno->HrefValue = "";
			$this->telephoneno->TooltipValue = "";

			// telephoneverified
			$this->telephoneverified->LinkCustomAttributes = "";
			$this->telephoneverified->HrefValue = "";
			$this->telephoneverified->TooltipValue = "";

			// telephonereceivemessage
			$this->telephonereceivemessage->LinkCustomAttributes = "";
			$this->telephonereceivemessage->HrefValue = "";
			$this->telephonereceivemessage->TooltipValue = "";

			// verification1
			$this->verification1->LinkCustomAttributes = "";
			$this->verification1->HrefValue = "";
			$this->verification1->TooltipValue = "";

			// verification2
			$this->verification2->LinkCustomAttributes = "";
			$this->verification2->HrefValue = "";
			$this->verification2->TooltipValue = "";

			// verification3
			$this->verification3->LinkCustomAttributes = "";
			$this->verification3->HrefValue = "";
			$this->verification3->TooltipValue = "";

			// address1
			$this->address1->LinkCustomAttributes = "";
			$this->address1->HrefValue = "";
			$this->address1->TooltipValue = "";

			// address2
			$this->address2->LinkCustomAttributes = "";
			$this->address2->HrefValue = "";
			$this->address2->TooltipValue = "";

			// cityname
			$this->cityname->LinkCustomAttributes = "";
			$this->cityname->HrefValue = "";
			$this->cityname->TooltipValue = "";

			// countryid
			$this->countryid->LinkCustomAttributes = "";
			$this->countryid->HrefValue = "";
			$this->countryid->TooltipValue = "";

			// stateid
			$this->stateid->LinkCustomAttributes = "";
			$this->stateid->HrefValue = "";
			$this->stateid->TooltipValue = "";

			// defaultcurrency
			$this->defaultcurrency->LinkCustomAttributes = "";
			$this->defaultcurrency->HrefValue = "";
			$this->defaultcurrency->TooltipValue = "";

			// challengeq1
			$this->challengeq1->LinkCustomAttributes = "";
			$this->challengeq1->HrefValue = "";
			$this->challengeq1->TooltipValue = "";

			// challengea1
			$this->challengea1->LinkCustomAttributes = "";
			$this->challengea1->HrefValue = "";
			$this->challengea1->TooltipValue = "";

			// challengeq2
			$this->challengeq2->LinkCustomAttributes = "";
			$this->challengeq2->HrefValue = "";
			$this->challengeq2->TooltipValue = "";

			// challengea2
			$this->challengea2->LinkCustomAttributes = "";
			$this->challengea2->HrefValue = "";
			$this->challengea2->TooltipValue = "";

			// challengeq3
			$this->challengeq3->LinkCustomAttributes = "";
			$this->challengeq3->HrefValue = "";
			$this->challengeq3->TooltipValue = "";

			// challengea3
			$this->challengea3->LinkCustomAttributes = "";
			$this->challengea3->HrefValue = "";
			$this->challengea3->TooltipValue = "";

			// passwordCounter
			$this->passwordCounter->LinkCustomAttributes = "";
			$this->passwordCounter->HrefValue = "";
			$this->passwordCounter->TooltipValue = "";

			// passwordChangedDate
			$this->passwordChangedDate->LinkCustomAttributes = "";
			$this->passwordChangedDate->HrefValue = "";
			$this->passwordChangedDate->TooltipValue = "";

			// pinCounter
			$this->pinCounter->LinkCustomAttributes = "";
			$this->pinCounter->HrefValue = "";
			$this->pinCounter->TooltipValue = "";

			// langID
			$this->langID->LinkCustomAttributes = "";
			$this->langID->HrefValue = "";
			$this->langID->TooltipValue = "";

			// photo
			$this->photo->LinkCustomAttributes = "";
			if (!EmptyValue($this->photo->Upload->DbValue)) {
				$this->photo->HrefValue = GetFileUploadUrl($this->photo, $this->photo->htmlDecode($this->photo->Upload->DbValue)); // Add prefix/suffix
				$this->photo->LinkAttrs["target"] = ""; // Add target
				if ($this->isExport())
					$this->photo->HrefValue = FullUrl($this->photo->HrefValue, "href");
			} else {
				$this->photo->HrefValue = "";
			}
			$this->photo->ExportHrefValue = $this->photo->UploadPath . $this->photo->Upload->DbValue;
			$this->photo->TooltipValue = "";

			// status
			$this->status->LinkCustomAttributes = "";
			$this->status->HrefValue = "";
			$this->status->TooltipValue = "";

			// markedfordeletion
			$this->markedfordeletion->LinkCustomAttributes = "";
			$this->markedfordeletion->HrefValue = "";
			$this->markedfordeletion->TooltipValue = "";

			// userType
			$this->userType->LinkCustomAttributes = "";
			$this->userType->HrefValue = "";
			$this->userType->TooltipValue = "";

			// usersubtype
			$this->usersubtype->LinkCustomAttributes = "";
			$this->usersubtype->HrefValue = "";
			$this->usersubtype->TooltipValue = "";

			// accountID
			$this->accountID->LinkCustomAttributes = "";
			if (!EmptyValue($this->accountID->CurrentValue)) {
				$this->accountID->HrefValue = "http://localhost/adminportal2020/snode/acctbalancelist.php?showmaster=acct&fk_acctID=" . $this->accountID->CurrentValue; // Add prefix/suffix
				$this->accountID->LinkAttrs["target"] = "_self"; // Add target
				if ($this->isExport())
					$this->accountID->HrefValue = FullUrl($this->accountID->HrefValue, "href");
			} else {
				$this->accountID->HrefValue = "";
			}
			$this->accountID->TooltipValue = "";

			// brokerid
			$this->brokerid->LinkCustomAttributes = "";
			$this->brokerid->HrefValue = "";
			$this->brokerid->TooltipValue = "";

			// parentuserid
			$this->parentuserid->LinkCustomAttributes = "";
			$this->parentuserid->HrefValue = "";
			$this->parentuserid->TooltipValue = "";

			// corporate
			$this->corporate->LinkCustomAttributes = "";
			$this->corporate->HrefValue = "";
			$this->corporate->TooltipValue = "";

			// profilestatus
			$this->profilestatus->LinkCustomAttributes = "";
			$this->profilestatus->HrefValue = "";
			$this->profilestatus->TooltipValue = "";

			// jumpappid
			$this->jumpappid->LinkCustomAttributes = "";
			$this->jumpappid->HrefValue = "";
			$this->jumpappid->TooltipValue = "";

			// dateofbirth
			$this->dateofbirth->LinkCustomAttributes = "";
			$this->dateofbirth->HrefValue = "";
			$this->dateofbirth->TooltipValue = "";

			// gender
			$this->gender->LinkCustomAttributes = "";
			$this->gender->HrefValue = "";
			$this->gender->TooltipValue = "";

			// lastupdatedate
			$this->lastupdatedate->LinkCustomAttributes = "";
			$this->lastupdatedate->HrefValue = "";
			$this->lastupdatedate->TooltipValue = "";

			// jumprequiredatlogin
			$this->jumprequiredatlogin->LinkCustomAttributes = "";
			$this->jumprequiredatlogin->HrefValue = "";
			$this->jumprequiredatlogin->TooltipValue = "";

			// ccbypass
			$this->ccbypass->LinkCustomAttributes = "";
			$this->ccbypass->HrefValue = "";
			$this->ccbypass->TooltipValue = "";

			// zip
			$this->zip->LinkCustomAttributes = "";
			$this->zip->HrefValue = "";
			$this->zip->TooltipValue = "";

			// other1
			$this->other1->LinkCustomAttributes = "";
			$this->other1->HrefValue = "";
			$this->other1->TooltipValue = "";

			// other2
			$this->other2->LinkCustomAttributes = "";
			$this->other2->HrefValue = "";
			$this->other2->TooltipValue = "";

			// other3
			$this->other3->LinkCustomAttributes = "";
			$this->other3->HrefValue = "";
			$this->other3->TooltipValue = "";

			// other4
			$this->other4->LinkCustomAttributes = "";
			$this->other4->HrefValue = "";
			$this->other4->TooltipValue = "";

			// other5
			$this->other5->LinkCustomAttributes = "";
			$this->other5->HrefValue = "";
			$this->other5->TooltipValue = "";

			// other6
			$this->other6->LinkCustomAttributes = "";
			$this->other6->HrefValue = "";
			$this->other6->TooltipValue = "";

			// mincashamount
			$this->mincashamount->LinkCustomAttributes = "";
			$this->mincashamount->HrefValue = "";
			$this->mincashamount->TooltipValue = "";

			// maxcashamount
			$this->maxcashamount->LinkCustomAttributes = "";
			$this->maxcashamount->HrefValue = "";
			$this->maxcashamount->TooltipValue = "";

			// maxtransferinamount
			$this->maxtransferinamount->LinkCustomAttributes = "";
			$this->maxtransferinamount->HrefValue = "";
			$this->maxtransferinamount->TooltipValue = "";

			// maxtransferoutamount
			$this->maxtransferoutamount->LinkCustomAttributes = "";
			$this->maxtransferoutamount->HrefValue = "";
			$this->maxtransferoutamount->TooltipValue = "";

			// legalid
			$this->legalid->LinkCustomAttributes = "";
			$this->legalid->HrefValue = "";
			$this->legalid->TooltipValue = "";

			// userpiview
			$this->userpiview->LinkCustomAttributes = "";
			$this->userpiview->HrefValue = "";
			$this->userpiview->TooltipValue = "";

			// lastmsgid
			$this->lastmsgid->LinkCustomAttributes = "";
			$this->lastmsgid->HrefValue = "";
			$this->lastmsgid->TooltipValue = "";

			// otprequiredforphysicalcards
			$this->otprequiredforphysicalcards->LinkCustomAttributes = "";
			$this->otprequiredforphysicalcards->HrefValue = "";
			$this->otprequiredforphysicalcards->TooltipValue = "";

			// otpvaliduntil
			$this->otpvaliduntil->LinkCustomAttributes = "";
			$this->otpvaliduntil->HrefValue = "";
			$this->otpvaliduntil->TooltipValue = "";

			// nationalitycountry
			$this->nationalitycountry->LinkCustomAttributes = "";
			$this->nationalitycountry->HrefValue = "";
			$this->nationalitycountry->TooltipValue = "";

			// classification
			$this->classification->LinkCustomAttributes = "";
			$this->classification->HrefValue = "";
			$this->classification->TooltipValue = "";

			// occupation
			$this->occupation->LinkCustomAttributes = "";
			$this->occupation->HrefValue = "";
			$this->occupation->TooltipValue = "";

			// sourceofincome
			$this->sourceofincome->LinkCustomAttributes = "";
			$this->sourceofincome->HrefValue = "";
			$this->sourceofincome->TooltipValue = "";

			// accountopeningdate
			$this->accountopeningdate->LinkCustomAttributes = "";
			$this->accountopeningdate->HrefValue = "";
			$this->accountopeningdate->TooltipValue = "";

			// extendedfields
			$this->extendedfields->LinkCustomAttributes = "";
			$this->extendedfields->HrefValue = "";
			$this->extendedfields->TooltipValue = "";

			// lastprofilestatuschangedate
			$this->lastprofilestatuschangedate->LinkCustomAttributes = "";
			$this->lastprofilestatuschangedate->HrefValue = "";
			$this->lastprofilestatuschangedate->TooltipValue = "";
		} elseif ($this->RowType == ROWTYPE_EDIT) { // Edit row

			// id
			$this->id->EditAttrs["class"] = "form-control";
			$this->id->EditCustomAttributes = "";
			$this->id->EditValue = HtmlEncode($this->id->CurrentValue);
			$this->id->PlaceHolder = RemoveHtml($this->id->caption());

			// firstName
			$this->firstName->EditAttrs["class"] = "form-control";
			$this->firstName->EditCustomAttributes = "";
			if (!$this->firstName->Raw)
				$this->firstName->CurrentValue = HtmlDecode($this->firstName->CurrentValue);
			$this->firstName->EditValue = HtmlEncode($this->firstName->CurrentValue);
			$this->firstName->PlaceHolder = RemoveHtml($this->firstName->caption());

			// lastName
			$this->lastName->EditAttrs["class"] = "form-control";
			$this->lastName->EditCustomAttributes = "";
			if (!$this->lastName->Raw)
				$this->lastName->CurrentValue = HtmlDecode($this->lastName->CurrentValue);
			$this->lastName->EditValue = HtmlEncode($this->lastName->CurrentValue);
			$this->lastName->PlaceHolder = RemoveHtml($this->lastName->caption());

			// otherNames
			$this->otherNames->EditAttrs["class"] = "form-control";
			$this->otherNames->EditCustomAttributes = "";
			if (!$this->otherNames->Raw)
				$this->otherNames->CurrentValue = HtmlDecode($this->otherNames->CurrentValue);
			$this->otherNames->EditValue = HtmlEncode($this->otherNames->CurrentValue);
			$this->otherNames->PlaceHolder = RemoveHtml($this->otherNames->caption());

			// passwordRequireChange
			$this->passwordRequireChange->EditCustomAttributes = "";
			$curVal = trim(strval($this->passwordRequireChange->CurrentValue));
			if ($curVal != "")
				$this->passwordRequireChange->ViewValue = $this->passwordRequireChange->lookupCacheOption($curVal);
			else
				$this->passwordRequireChange->ViewValue = $this->passwordRequireChange->Lookup !== NULL && is_array($this->passwordRequireChange->Lookup->Options) ? $curVal : NULL;
			if ($this->passwordRequireChange->ViewValue !== NULL) { // Load from cache
				$this->passwordRequireChange->EditValue = array_values($this->passwordRequireChange->Lookup->Options);
			} else { // Lookup from database
				if ($curVal == "") {
					$filterWrk = "0=1";
				} else {
					$filterWrk = "`id`" . SearchString("=", $this->passwordRequireChange->CurrentValue, DATATYPE_NUMBER, "");
				}
				$sqlWrk = $this->passwordRequireChange->Lookup->getSql(TRUE, $filterWrk, '', $this);
				$rswrk = Conn()->execute($sqlWrk);
				$arwrk = $rswrk ? $rswrk->getRows() : [];
				if ($rswrk)
					$rswrk->close();
				$this->passwordRequireChange->EditValue = $arwrk;
			}

			// franchiseeID
			$this->franchiseeID->EditAttrs["class"] = "form-control";
			$this->franchiseeID->EditCustomAttributes = "";
			$this->franchiseeID->EditValue = HtmlEncode($this->franchiseeID->CurrentValue);
			$this->franchiseeID->PlaceHolder = RemoveHtml($this->franchiseeID->caption());

			// dateAdded
			$this->dateAdded->EditAttrs["class"] = "form-control";
			$this->dateAdded->EditCustomAttributes = "";
			$this->dateAdded->EditValue = HtmlEncode(FormatDateTime($this->dateAdded->CurrentValue, 8));
			$this->dateAdded->PlaceHolder = RemoveHtml($this->dateAdded->caption());

			// timezoneid
			$this->timezoneid->EditAttrs["class"] = "form-control";
			$this->timezoneid->EditCustomAttributes = "";
			$curVal = trim(strval($this->timezoneid->CurrentValue));
			if ($curVal != "")
				$this->timezoneid->ViewValue = $this->timezoneid->lookupCacheOption($curVal);
			else
				$this->timezoneid->ViewValue = $this->timezoneid->Lookup !== NULL && is_array($this->timezoneid->Lookup->Options) ? $curVal : NULL;
			if ($this->timezoneid->ViewValue !== NULL) { // Load from cache
				$this->timezoneid->EditValue = array_values($this->timezoneid->Lookup->Options);
			} else { // Lookup from database
				if ($curVal == "") {
					$filterWrk = "0=1";
				} else {
					$filterWrk = "`timeZoneID`" . SearchString("=", $this->timezoneid->CurrentValue, DATATYPE_NUMBER, "_4payreference");
				}
				$sqlWrk = $this->timezoneid->Lookup->getSql(TRUE, $filterWrk, '', $this);
				$rswrk = Conn("_4payreference")->execute($sqlWrk);
				$arwrk = $rswrk ? $rswrk->getRows() : [];
				if ($rswrk)
					$rswrk->close();
				$this->timezoneid->EditValue = $arwrk;
			}

			// contactPhoneNo
			$this->contactPhoneNo->EditAttrs["class"] = "form-control";
			$this->contactPhoneNo->EditCustomAttributes = "";
			if (!$this->contactPhoneNo->Raw)
				$this->contactPhoneNo->CurrentValue = HtmlDecode($this->contactPhoneNo->CurrentValue);
			$this->contactPhoneNo->EditValue = HtmlEncode($this->contactPhoneNo->CurrentValue);
			$this->contactPhoneNo->PlaceHolder = RemoveHtml($this->contactPhoneNo->caption());

			// telephoneno
			$this->telephoneno->EditAttrs["class"] = "form-control";
			$this->telephoneno->EditCustomAttributes = "";
			if (!$this->telephoneno->Raw)
				$this->telephoneno->CurrentValue = HtmlDecode($this->telephoneno->CurrentValue);
			$this->telephoneno->EditValue = HtmlEncode($this->telephoneno->CurrentValue);
			$this->telephoneno->PlaceHolder = RemoveHtml($this->telephoneno->caption());

			// telephoneverified
			$this->telephoneverified->EditCustomAttributes = "";
			$curVal = trim(strval($this->telephoneverified->CurrentValue));
			if ($curVal != "")
				$this->telephoneverified->ViewValue = $this->telephoneverified->lookupCacheOption($curVal);
			else
				$this->telephoneverified->ViewValue = $this->telephoneverified->Lookup !== NULL && is_array($this->telephoneverified->Lookup->Options) ? $curVal : NULL;
			if ($this->telephoneverified->ViewValue !== NULL) { // Load from cache
				$this->telephoneverified->EditValue = array_values($this->telephoneverified->Lookup->Options);
			} else { // Lookup from database
				if ($curVal == "") {
					$filterWrk = "0=1";
				} else {
					$filterWrk = "`id`" . SearchString("=", $this->telephoneverified->CurrentValue, DATATYPE_NUMBER, "");
				}
				$sqlWrk = $this->telephoneverified->Lookup->getSql(TRUE, $filterWrk, '', $this);
				$rswrk = Conn()->execute($sqlWrk);
				$arwrk = $rswrk ? $rswrk->getRows() : [];
				if ($rswrk)
					$rswrk->close();
				$this->telephoneverified->EditValue = $arwrk;
			}

			// telephonereceivemessage
			$this->telephonereceivemessage->EditCustomAttributes = "";
			$curVal = trim(strval($this->telephonereceivemessage->CurrentValue));
			if ($curVal != "")
				$this->telephonereceivemessage->ViewValue = $this->telephonereceivemessage->lookupCacheOption($curVal);
			else
				$this->telephonereceivemessage->ViewValue = $this->telephonereceivemessage->Lookup !== NULL && is_array($this->telephonereceivemessage->Lookup->Options) ? $curVal : NULL;
			if ($this->telephonereceivemessage->ViewValue !== NULL) { // Load from cache
				$this->telephonereceivemessage->EditValue = array_values($this->telephonereceivemessage->Lookup->Options);
			} else { // Lookup from database
				if ($curVal == "") {
					$filterWrk = "0=1";
				} else {
					$filterWrk = "`id`" . SearchString("=", $this->telephonereceivemessage->CurrentValue, DATATYPE_NUMBER, "");
				}
				$sqlWrk = $this->telephonereceivemessage->Lookup->getSql(TRUE, $filterWrk, '', $this);
				$rswrk = Conn()->execute($sqlWrk);
				$arwrk = $rswrk ? $rswrk->getRows() : [];
				if ($rswrk)
					$rswrk->close();
				$this->telephonereceivemessage->EditValue = $arwrk;
			}

			// verification1
			$this->verification1->EditAttrs["class"] = "form-control";
			$this->verification1->EditCustomAttributes = "";
			if (!$this->verification1->Raw)
				$this->verification1->CurrentValue = HtmlDecode($this->verification1->CurrentValue);
			$this->verification1->EditValue = HtmlEncode($this->verification1->CurrentValue);
			$this->verification1->PlaceHolder = RemoveHtml($this->verification1->caption());

			// verification2
			$this->verification2->EditAttrs["class"] = "form-control";
			$this->verification2->EditCustomAttributes = "";
			if (!$this->verification2->Raw)
				$this->verification2->CurrentValue = HtmlDecode($this->verification2->CurrentValue);
			$this->verification2->EditValue = HtmlEncode($this->verification2->CurrentValue);
			$this->verification2->PlaceHolder = RemoveHtml($this->verification2->caption());

			// verification3
			$this->verification3->EditAttrs["class"] = "form-control";
			$this->verification3->EditCustomAttributes = "";
			if (!$this->verification3->Raw)
				$this->verification3->CurrentValue = HtmlDecode($this->verification3->CurrentValue);
			$this->verification3->EditValue = HtmlEncode($this->verification3->CurrentValue);
			$this->verification3->PlaceHolder = RemoveHtml($this->verification3->caption());

			// address1
			$this->address1->EditAttrs["class"] = "form-control";
			$this->address1->EditCustomAttributes = "";
			if (!$this->address1->Raw)
				$this->address1->CurrentValue = HtmlDecode($this->address1->CurrentValue);
			$this->address1->EditValue = HtmlEncode($this->address1->CurrentValue);
			$this->address1->PlaceHolder = RemoveHtml($this->address1->caption());

			// address2
			$this->address2->EditAttrs["class"] = "form-control";
			$this->address2->EditCustomAttributes = "";
			if (!$this->address2->Raw)
				$this->address2->CurrentValue = HtmlDecode($this->address2->CurrentValue);
			$this->address2->EditValue = HtmlEncode($this->address2->CurrentValue);
			$this->address2->PlaceHolder = RemoveHtml($this->address2->caption());

			// cityname
			$this->cityname->EditAttrs["class"] = "form-control";
			$this->cityname->EditCustomAttributes = "";
			if (!$this->cityname->Raw)
				$this->cityname->CurrentValue = HtmlDecode($this->cityname->CurrentValue);
			$this->cityname->EditValue = HtmlEncode($this->cityname->CurrentValue);
			$this->cityname->PlaceHolder = RemoveHtml($this->cityname->caption());

			// countryid
			$this->countryid->EditAttrs["class"] = "form-control";
			$this->countryid->EditCustomAttributes = "";
			$curVal = trim(strval($this->countryid->CurrentValue));
			if ($curVal != "")
				$this->countryid->ViewValue = $this->countryid->lookupCacheOption($curVal);
			else
				$this->countryid->ViewValue = $this->countryid->Lookup !== NULL && is_array($this->countryid->Lookup->Options) ? $curVal : NULL;
			if ($this->countryid->ViewValue !== NULL) { // Load from cache
				$this->countryid->EditValue = array_values($this->countryid->Lookup->Options);
			} else { // Lookup from database
				if ($curVal == "") {
					$filterWrk = "0=1";
				} else {
					$filterWrk = "`countryID`" . SearchString("=", $this->countryid->CurrentValue, DATATYPE_STRING, "");
				}
				$sqlWrk = $this->countryid->Lookup->getSql(TRUE, $filterWrk, '', $this);
				$rswrk = Conn()->execute($sqlWrk);
				$arwrk = $rswrk ? $rswrk->getRows() : [];
				if ($rswrk)
					$rswrk->close();
				$this->countryid->EditValue = $arwrk;
			}

			// stateid
			$this->stateid->EditAttrs["class"] = "form-control";
			$this->stateid->EditCustomAttributes = "";
			$curVal = trim(strval($this->stateid->CurrentValue));
			if ($curVal != "")
				$this->stateid->ViewValue = $this->stateid->lookupCacheOption($curVal);
			else
				$this->stateid->ViewValue = $this->stateid->Lookup !== NULL && is_array($this->stateid->Lookup->Options) ? $curVal : NULL;
			if ($this->stateid->ViewValue !== NULL) { // Load from cache
				$this->stateid->EditValue = array_values($this->stateid->Lookup->Options);
			} else { // Lookup from database
				if ($curVal == "") {
					$filterWrk = "0=1";
				} else {
					$filterWrk = "`stateid`" . SearchString("=", $this->stateid->CurrentValue, DATATYPE_STRING, "_4payreference");
				}
				$sqlWrk = $this->stateid->Lookup->getSql(TRUE, $filterWrk, '', $this);
				$rswrk = Conn("_4payreference")->execute($sqlWrk);
				$arwrk = $rswrk ? $rswrk->getRows() : [];
				if ($rswrk)
					$rswrk->close();
				$this->stateid->EditValue = $arwrk;
			}

			// defaultcurrency
			$this->defaultcurrency->EditAttrs["class"] = "form-control";
			$this->defaultcurrency->EditCustomAttributes = "";
			$curVal = trim(strval($this->defaultcurrency->CurrentValue));
			if ($curVal != "")
				$this->defaultcurrency->ViewValue = $this->defaultcurrency->lookupCacheOption($curVal);
			else
				$this->defaultcurrency->ViewValue = $this->defaultcurrency->Lookup !== NULL && is_array($this->defaultcurrency->Lookup->Options) ? $curVal : NULL;
			if ($this->defaultcurrency->ViewValue !== NULL) { // Load from cache
				$this->defaultcurrency->EditValue = array_values($this->defaultcurrency->Lookup->Options);
			} else { // Lookup from database
				if ($curVal == "") {
					$filterWrk = "0=1";
				} else {
					$filterWrk = "`currCode`" . SearchString("=", $this->defaultcurrency->CurrentValue, DATATYPE_STRING, "_4payreference");
				}
				$sqlWrk = $this->defaultcurrency->Lookup->getSql(TRUE, $filterWrk, '', $this);
				$rswrk = Conn("_4payreference")->execute($sqlWrk);
				$arwrk = $rswrk ? $rswrk->getRows() : [];
				if ($rswrk)
					$rswrk->close();
				$this->defaultcurrency->EditValue = $arwrk;
			}

			// challengeq1
			$this->challengeq1->EditAttrs["class"] = "form-control";
			$this->challengeq1->EditCustomAttributes = "";
			$this->challengeq1->EditValue = HtmlEncode($this->challengeq1->CurrentValue);
			$this->challengeq1->PlaceHolder = RemoveHtml($this->challengeq1->caption());

			// challengea1
			$this->challengea1->EditAttrs["class"] = "form-control";
			$this->challengea1->EditCustomAttributes = "";
			if (!$this->challengea1->Raw)
				$this->challengea1->CurrentValue = HtmlDecode($this->challengea1->CurrentValue);
			$this->challengea1->EditValue = HtmlEncode($this->challengea1->CurrentValue);
			$this->challengea1->PlaceHolder = RemoveHtml($this->challengea1->caption());

			// challengeq2
			$this->challengeq2->EditAttrs["class"] = "form-control";
			$this->challengeq2->EditCustomAttributes = "";
			$this->challengeq2->EditValue = HtmlEncode($this->challengeq2->CurrentValue);
			$this->challengeq2->PlaceHolder = RemoveHtml($this->challengeq2->caption());

			// challengea2
			$this->challengea2->EditAttrs["class"] = "form-control";
			$this->challengea2->EditCustomAttributes = "";
			if (!$this->challengea2->Raw)
				$this->challengea2->CurrentValue = HtmlDecode($this->challengea2->CurrentValue);
			$this->challengea2->EditValue = HtmlEncode($this->challengea2->CurrentValue);
			$this->challengea2->PlaceHolder = RemoveHtml($this->challengea2->caption());

			// challengeq3
			$this->challengeq3->EditAttrs["class"] = "form-control";
			$this->challengeq3->EditCustomAttributes = "";
			$this->challengeq3->EditValue = HtmlEncode($this->challengeq3->CurrentValue);
			$this->challengeq3->PlaceHolder = RemoveHtml($this->challengeq3->caption());

			// challengea3
			$this->challengea3->EditAttrs["class"] = "form-control";
			$this->challengea3->EditCustomAttributes = "";
			if (!$this->challengea3->Raw)
				$this->challengea3->CurrentValue = HtmlDecode($this->challengea3->CurrentValue);
			$this->challengea3->EditValue = HtmlEncode($this->challengea3->CurrentValue);
			$this->challengea3->PlaceHolder = RemoveHtml($this->challengea3->caption());

			// passwordCounter
			$this->passwordCounter->EditAttrs["class"] = "form-control";
			$this->passwordCounter->EditCustomAttributes = "";
			$this->passwordCounter->EditValue = HtmlEncode($this->passwordCounter->CurrentValue);
			$this->passwordCounter->PlaceHolder = RemoveHtml($this->passwordCounter->caption());

			// passwordChangedDate
			$this->passwordChangedDate->EditAttrs["class"] = "form-control";
			$this->passwordChangedDate->EditCustomAttributes = "";
			$this->passwordChangedDate->EditValue = HtmlEncode(FormatDateTime($this->passwordChangedDate->CurrentValue, 8));
			$this->passwordChangedDate->PlaceHolder = RemoveHtml($this->passwordChangedDate->caption());

			// pinCounter
			$this->pinCounter->EditAttrs["class"] = "form-control";
			$this->pinCounter->EditCustomAttributes = "";
			$this->pinCounter->EditValue = HtmlEncode($this->pinCounter->CurrentValue);
			$this->pinCounter->PlaceHolder = RemoveHtml($this->pinCounter->caption());

			// langID
			$this->langID->EditAttrs["class"] = "form-control";
			$this->langID->EditCustomAttributes = "";
			$curVal = trim(strval($this->langID->CurrentValue));
			if ($curVal != "")
				$this->langID->ViewValue = $this->langID->lookupCacheOption($curVal);
			else
				$this->langID->ViewValue = $this->langID->Lookup !== NULL && is_array($this->langID->Lookup->Options) ? $curVal : NULL;
			if ($this->langID->ViewValue !== NULL) { // Load from cache
				$this->langID->EditValue = array_values($this->langID->Lookup->Options);
			} else { // Lookup from database
				if ($curVal == "") {
					$filterWrk = "0=1";
				} else {
					$filterWrk = "`langID`" . SearchString("=", $this->langID->CurrentValue, DATATYPE_STRING, "");
				}
				$lookupFilter = function() {
					return "`inlangid` = 'EN'";
				};
				$lookupFilter = $lookupFilter->bindTo($this);
				$sqlWrk = $this->langID->Lookup->getSql(TRUE, $filterWrk, $lookupFilter, $this);
				$rswrk = Conn()->execute($sqlWrk);
				$arwrk = $rswrk ? $rswrk->getRows() : [];
				if ($rswrk)
					$rswrk->close();
				$this->langID->EditValue = $arwrk;
			}

			// photo
			$this->photo->EditAttrs["class"] = "form-control";
			$this->photo->EditCustomAttributes = "";
			if (!EmptyValue($this->photo->Upload->DbValue)) {
				$this->photo->EditValue = $this->photo->Upload->DbValue;
			} else {
				$this->photo->EditValue = "";
			}
			if ($this->isShow())
				RenderUploadField($this->photo);

			// status
			$this->status->EditAttrs["class"] = "form-control";
			$this->status->EditCustomAttributes = "";
			$curVal = trim(strval($this->status->CurrentValue));
			if ($curVal != "")
				$this->status->ViewValue = $this->status->lookupCacheOption($curVal);
			else
				$this->status->ViewValue = $this->status->Lookup !== NULL && is_array($this->status->Lookup->Options) ? $curVal : NULL;
			if ($this->status->ViewValue !== NULL) { // Load from cache
				$this->status->EditValue = array_values($this->status->Lookup->Options);
			} else { // Lookup from database
				if ($curVal == "") {
					$filterWrk = "0=1";
				} else {
					$filterWrk = "`statusID`" . SearchString("=", $this->status->CurrentValue, DATATYPE_NUMBER, "");
				}
				$sqlWrk = $this->status->Lookup->getSql(TRUE, $filterWrk, '', $this);
				$rswrk = Conn()->execute($sqlWrk);
				$arwrk = $rswrk ? $rswrk->getRows() : [];
				if ($rswrk)
					$rswrk->close();
				$this->status->EditValue = $arwrk;
			}

			// markedfordeletion
			$this->markedfordeletion->EditAttrs["class"] = "form-control";
			$this->markedfordeletion->EditCustomAttributes = "";
			$this->markedfordeletion->EditValue = HtmlEncode(FormatDateTime($this->markedfordeletion->CurrentValue, 8));
			$this->markedfordeletion->PlaceHolder = RemoveHtml($this->markedfordeletion->caption());

			// userType
			$this->userType->EditAttrs["class"] = "form-control";
			$this->userType->EditCustomAttributes = "";
			$curVal = trim(strval($this->userType->CurrentValue));
			if ($curVal != "")
				$this->userType->ViewValue = $this->userType->lookupCacheOption($curVal);
			else
				$this->userType->ViewValue = $this->userType->Lookup !== NULL && is_array($this->userType->Lookup->Options) ? $curVal : NULL;
			if ($this->userType->ViewValue !== NULL) { // Load from cache
				$this->userType->EditValue = array_values($this->userType->Lookup->Options);
			} else { // Lookup from database
				if ($curVal == "") {
					$filterWrk = "0=1";
				} else {
					$filterWrk = "`typeID`" . SearchString("=", $this->userType->CurrentValue, DATATYPE_NUMBER, "_4payreference");
				}
				$sqlWrk = $this->userType->Lookup->getSql(TRUE, $filterWrk, '', $this);
				$rswrk = Conn("_4payreference")->execute($sqlWrk);
				$arwrk = $rswrk ? $rswrk->getRows() : [];
				if ($rswrk)
					$rswrk->close();
				$this->userType->EditValue = $arwrk;
			}

			// usersubtype
			$this->usersubtype->EditAttrs["class"] = "form-control";
			$this->usersubtype->EditCustomAttributes = "";
			$curVal = trim(strval($this->usersubtype->CurrentValue));
			if ($curVal != "")
				$this->usersubtype->ViewValue = $this->usersubtype->lookupCacheOption($curVal);
			else
				$this->usersubtype->ViewValue = $this->usersubtype->Lookup !== NULL && is_array($this->usersubtype->Lookup->Options) ? $curVal : NULL;
			if ($this->usersubtype->ViewValue !== NULL) { // Load from cache
				$this->usersubtype->EditValue = array_values($this->usersubtype->Lookup->Options);
			} else { // Lookup from database
				if ($curVal == "") {
					$filterWrk = "0=1";
				} else {
					$filterWrk = "`subtypeID`" . SearchString("=", $this->usersubtype->CurrentValue, DATATYPE_NUMBER, "_4payreference");
				}
				$sqlWrk = $this->usersubtype->Lookup->getSql(TRUE, $filterWrk, '', $this);
				$rswrk = Conn("_4payreference")->execute($sqlWrk);
				$arwrk = $rswrk ? $rswrk->getRows() : [];
				if ($rswrk)
					$rswrk->close();
				$this->usersubtype->EditValue = $arwrk;
			}

			// accountID
			$this->accountID->EditAttrs["class"] = "form-control";
			$this->accountID->EditCustomAttributes = "";
			$this->accountID->EditValue = HtmlEncode($this->accountID->CurrentValue);
			$this->accountID->PlaceHolder = RemoveHtml($this->accountID->caption());

			// brokerid
			$this->brokerid->EditAttrs["class"] = "form-control";
			$this->brokerid->EditCustomAttributes = "";
			$this->brokerid->EditValue = HtmlEncode($this->brokerid->CurrentValue);
			$this->brokerid->PlaceHolder = RemoveHtml($this->brokerid->caption());

			// parentuserid
			$this->parentuserid->EditAttrs["class"] = "form-control";
			$this->parentuserid->EditCustomAttributes = "";
			$this->parentuserid->EditValue = HtmlEncode($this->parentuserid->CurrentValue);
			$this->parentuserid->PlaceHolder = RemoveHtml($this->parentuserid->caption());

			// corporate
			$this->corporate->EditCustomAttributes = "";
			$curVal = trim(strval($this->corporate->CurrentValue));
			if ($curVal != "")
				$this->corporate->ViewValue = $this->corporate->lookupCacheOption($curVal);
			else
				$this->corporate->ViewValue = $this->corporate->Lookup !== NULL && is_array($this->corporate->Lookup->Options) ? $curVal : NULL;
			if ($this->corporate->ViewValue !== NULL) { // Load from cache
				$this->corporate->EditValue = array_values($this->corporate->Lookup->Options);
			} else { // Lookup from database
				if ($curVal == "") {
					$filterWrk = "0=1";
				} else {
					$filterWrk = "`id`" . SearchString("=", $this->corporate->CurrentValue, DATATYPE_NUMBER, "");
				}
				$sqlWrk = $this->corporate->Lookup->getSql(TRUE, $filterWrk, '', $this);
				$rswrk = Conn()->execute($sqlWrk);
				$arwrk = $rswrk ? $rswrk->getRows() : [];
				if ($rswrk)
					$rswrk->close();
				$this->corporate->EditValue = $arwrk;
			}

			// profilestatus
			$this->profilestatus->EditAttrs["class"] = "form-control";
			$this->profilestatus->EditCustomAttributes = "";
			$curVal = trim(strval($this->profilestatus->CurrentValue));
			if ($curVal != "")
				$this->profilestatus->ViewValue = $this->profilestatus->lookupCacheOption($curVal);
			else
				$this->profilestatus->ViewValue = $this->profilestatus->Lookup !== NULL && is_array($this->profilestatus->Lookup->Options) ? $curVal : NULL;
			if ($this->profilestatus->ViewValue !== NULL) { // Load from cache
				$this->profilestatus->EditValue = array_values($this->profilestatus->Lookup->Options);
			} else { // Lookup from database
				if ($curVal == "") {
					$filterWrk = "0=1";
				} else {
					$filterWrk = "`statusID`" . SearchString("=", $this->profilestatus->CurrentValue, DATATYPE_NUMBER, "_4payreference");
				}
				$sqlWrk = $this->profilestatus->Lookup->getSql(TRUE, $filterWrk, '', $this);
				$rswrk = Conn("_4payreference")->execute($sqlWrk);
				$arwrk = $rswrk ? $rswrk->getRows() : [];
				if ($rswrk)
					$rswrk->close();
				$this->profilestatus->EditValue = $arwrk;
			}

			// jumpappid
			$this->jumpappid->EditAttrs["class"] = "form-control";
			$this->jumpappid->EditCustomAttributes = "";
			$this->jumpappid->EditValue = HtmlEncode($this->jumpappid->CurrentValue);
			$this->jumpappid->PlaceHolder = RemoveHtml($this->jumpappid->caption());

			// dateofbirth
			$this->dateofbirth->EditAttrs["class"] = "form-control";
			$this->dateofbirth->EditCustomAttributes = "";
			$this->dateofbirth->EditValue = HtmlEncode(FormatDateTime($this->dateofbirth->CurrentValue, 2));
			$this->dateofbirth->PlaceHolder = RemoveHtml($this->dateofbirth->caption());

			// gender
			$this->gender->EditAttrs["class"] = "form-control";
			$this->gender->EditCustomAttributes = "";
			$curVal = trim(strval($this->gender->CurrentValue));
			if ($curVal != "")
				$this->gender->ViewValue = $this->gender->lookupCacheOption($curVal);
			else
				$this->gender->ViewValue = $this->gender->Lookup !== NULL && is_array($this->gender->Lookup->Options) ? $curVal : NULL;
			if ($this->gender->ViewValue !== NULL) { // Load from cache
				$this->gender->EditValue = array_values($this->gender->Lookup->Options);
			} else { // Lookup from database
				if ($curVal == "") {
					$filterWrk = "0=1";
				} else {
					$filterWrk = "`id`" . SearchString("=", $this->gender->CurrentValue, DATATYPE_NUMBER, "_4payreference");
				}
				$sqlWrk = $this->gender->Lookup->getSql(TRUE, $filterWrk, '', $this);
				$rswrk = Conn("_4payreference")->execute($sqlWrk);
				$arwrk = $rswrk ? $rswrk->getRows() : [];
				if ($rswrk)
					$rswrk->close();
				$this->gender->EditValue = $arwrk;
			}

			// lastupdatedate
			$this->lastupdatedate->EditAttrs["class"] = "form-control";
			$this->lastupdatedate->EditCustomAttributes = "";
			$this->lastupdatedate->EditValue = HtmlEncode(FormatDateTime($this->lastupdatedate->CurrentValue, 8));
			$this->lastupdatedate->PlaceHolder = RemoveHtml($this->lastupdatedate->caption());

			// jumprequiredatlogin
			$this->jumprequiredatlogin->EditCustomAttributes = "";
			$curVal = trim(strval($this->jumprequiredatlogin->CurrentValue));
			if ($curVal != "")
				$this->jumprequiredatlogin->ViewValue = $this->jumprequiredatlogin->lookupCacheOption($curVal);
			else
				$this->jumprequiredatlogin->ViewValue = $this->jumprequiredatlogin->Lookup !== NULL && is_array($this->jumprequiredatlogin->Lookup->Options) ? $curVal : NULL;
			if ($this->jumprequiredatlogin->ViewValue !== NULL) { // Load from cache
				$this->jumprequiredatlogin->EditValue = array_values($this->jumprequiredatlogin->Lookup->Options);
			} else { // Lookup from database
				if ($curVal == "") {
					$filterWrk = "0=1";
				} else {
					$filterWrk = "`id`" . SearchString("=", $this->jumprequiredatlogin->CurrentValue, DATATYPE_NUMBER, "");
				}
				$sqlWrk = $this->jumprequiredatlogin->Lookup->getSql(TRUE, $filterWrk, '', $this);
				$rswrk = Conn()->execute($sqlWrk);
				$arwrk = $rswrk ? $rswrk->getRows() : [];
				if ($rswrk)
					$rswrk->close();
				$this->jumprequiredatlogin->EditValue = $arwrk;
			}

			// ccbypass
			$this->ccbypass->EditCustomAttributes = "";
			$curVal = trim(strval($this->ccbypass->CurrentValue));
			if ($curVal != "")
				$this->ccbypass->ViewValue = $this->ccbypass->lookupCacheOption($curVal);
			else
				$this->ccbypass->ViewValue = $this->ccbypass->Lookup !== NULL && is_array($this->ccbypass->Lookup->Options) ? $curVal : NULL;
			if ($this->ccbypass->ViewValue !== NULL) { // Load from cache
				$this->ccbypass->EditValue = array_values($this->ccbypass->Lookup->Options);
			} else { // Lookup from database
				if ($curVal == "") {
					$filterWrk = "0=1";
				} else {
					$filterWrk = "`id`" . SearchString("=", $this->ccbypass->CurrentValue, DATATYPE_NUMBER, "");
				}
				$sqlWrk = $this->ccbypass->Lookup->getSql(TRUE, $filterWrk, '', $this);
				$rswrk = Conn()->execute($sqlWrk);
				$arwrk = $rswrk ? $rswrk->getRows() : [];
				if ($rswrk)
					$rswrk->close();
				$this->ccbypass->EditValue = $arwrk;
			}

			// zip
			$this->zip->EditAttrs["class"] = "form-control";
			$this->zip->EditCustomAttributes = "";
			if (!$this->zip->Raw)
				$this->zip->CurrentValue = HtmlDecode($this->zip->CurrentValue);
			$this->zip->EditValue = HtmlEncode($this->zip->CurrentValue);
			$this->zip->PlaceHolder = RemoveHtml($this->zip->caption());

			// other1
			$this->other1->EditAttrs["class"] = "form-control";
			$this->other1->EditCustomAttributes = "";
			if (!$this->other1->Raw)
				$this->other1->CurrentValue = HtmlDecode($this->other1->CurrentValue);
			$this->other1->EditValue = HtmlEncode($this->other1->CurrentValue);
			$this->other1->PlaceHolder = RemoveHtml($this->other1->caption());

			// other2
			$this->other2->EditAttrs["class"] = "form-control";
			$this->other2->EditCustomAttributes = "";
			if (!$this->other2->Raw)
				$this->other2->CurrentValue = HtmlDecode($this->other2->CurrentValue);
			$this->other2->EditValue = HtmlEncode($this->other2->CurrentValue);
			$this->other2->PlaceHolder = RemoveHtml($this->other2->caption());

			// other3
			$this->other3->EditAttrs["class"] = "form-control";
			$this->other3->EditCustomAttributes = "";
			if (!$this->other3->Raw)
				$this->other3->CurrentValue = HtmlDecode($this->other3->CurrentValue);
			$this->other3->EditValue = HtmlEncode($this->other3->CurrentValue);
			$this->other3->PlaceHolder = RemoveHtml($this->other3->caption());

			// other4
			$this->other4->EditAttrs["class"] = "form-control";
			$this->other4->EditCustomAttributes = "";
			if (!$this->other4->Raw)
				$this->other4->CurrentValue = HtmlDecode($this->other4->CurrentValue);
			$this->other4->EditValue = HtmlEncode($this->other4->CurrentValue);
			$this->other4->PlaceHolder = RemoveHtml($this->other4->caption());

			// other5
			$this->other5->EditAttrs["class"] = "form-control";
			$this->other5->EditCustomAttributes = "";
			if (!$this->other5->Raw)
				$this->other5->CurrentValue = HtmlDecode($this->other5->CurrentValue);
			$this->other5->EditValue = HtmlEncode($this->other5->CurrentValue);
			$this->other5->PlaceHolder = RemoveHtml($this->other5->caption());

			// other6
			$this->other6->EditAttrs["class"] = "form-control";
			$this->other6->EditCustomAttributes = "";
			if (!$this->other6->Raw)
				$this->other6->CurrentValue = HtmlDecode($this->other6->CurrentValue);
			$this->other6->EditValue = HtmlEncode($this->other6->CurrentValue);
			$this->other6->PlaceHolder = RemoveHtml($this->other6->caption());

			// mincashamount
			$this->mincashamount->EditAttrs["class"] = "form-control";
			$this->mincashamount->EditCustomAttributes = "";
			$this->mincashamount->EditValue = HtmlEncode($this->mincashamount->CurrentValue);
			$this->mincashamount->PlaceHolder = RemoveHtml($this->mincashamount->caption());
			if (strval($this->mincashamount->EditValue) != "" && is_numeric($this->mincashamount->EditValue))
				$this->mincashamount->EditValue = FormatNumber($this->mincashamount->EditValue, -2, -1, -2, 0);
			

			// maxcashamount
			$this->maxcashamount->EditAttrs["class"] = "form-control";
			$this->maxcashamount->EditCustomAttributes = "";
			$this->maxcashamount->EditValue = HtmlEncode($this->maxcashamount->CurrentValue);
			$this->maxcashamount->PlaceHolder = RemoveHtml($this->maxcashamount->caption());
			if (strval($this->maxcashamount->EditValue) != "" && is_numeric($this->maxcashamount->EditValue))
				$this->maxcashamount->EditValue = FormatNumber($this->maxcashamount->EditValue, -2, -1, -2, 0);
			

			// maxtransferinamount
			$this->maxtransferinamount->EditAttrs["class"] = "form-control";
			$this->maxtransferinamount->EditCustomAttributes = "";
			$this->maxtransferinamount->EditValue = HtmlEncode($this->maxtransferinamount->CurrentValue);
			$this->maxtransferinamount->PlaceHolder = RemoveHtml($this->maxtransferinamount->caption());
			if (strval($this->maxtransferinamount->EditValue) != "" && is_numeric($this->maxtransferinamount->EditValue))
				$this->maxtransferinamount->EditValue = FormatNumber($this->maxtransferinamount->EditValue, -2, -1, -2, 0);
			

			// maxtransferoutamount
			$this->maxtransferoutamount->EditAttrs["class"] = "form-control";
			$this->maxtransferoutamount->EditCustomAttributes = "";
			$this->maxtransferoutamount->EditValue = HtmlEncode($this->maxtransferoutamount->CurrentValue);
			$this->maxtransferoutamount->PlaceHolder = RemoveHtml($this->maxtransferoutamount->caption());
			if (strval($this->maxtransferoutamount->EditValue) != "" && is_numeric($this->maxtransferoutamount->EditValue))
				$this->maxtransferoutamount->EditValue = FormatNumber($this->maxtransferoutamount->EditValue, -2, -1, -2, 0);
			

			// legalid
			$this->legalid->EditAttrs["class"] = "form-control";
			$this->legalid->EditCustomAttributes = "";
			$this->legalid->EditValue = HtmlEncode($this->legalid->CurrentValue);
			$this->legalid->PlaceHolder = RemoveHtml($this->legalid->caption());

			// userpiview
			$this->userpiview->EditCustomAttributes = "";
			$curVal = trim(strval($this->userpiview->CurrentValue));
			if ($curVal != "")
				$this->userpiview->ViewValue = $this->userpiview->lookupCacheOption($curVal);
			else
				$this->userpiview->ViewValue = $this->userpiview->Lookup !== NULL && is_array($this->userpiview->Lookup->Options) ? $curVal : NULL;
			if ($this->userpiview->ViewValue !== NULL) { // Load from cache
				$this->userpiview->EditValue = array_values($this->userpiview->Lookup->Options);
			} else { // Lookup from database
				if ($curVal == "") {
					$filterWrk = "0=1";
				} else {
					$filterWrk = "`id`" . SearchString("=", $this->userpiview->CurrentValue, DATATYPE_NUMBER, "");
				}
				$sqlWrk = $this->userpiview->Lookup->getSql(TRUE, $filterWrk, '', $this);
				$rswrk = Conn()->execute($sqlWrk);
				$arwrk = $rswrk ? $rswrk->getRows() : [];
				if ($rswrk)
					$rswrk->close();
				$this->userpiview->EditValue = $arwrk;
			}

			// lastmsgid
			$this->lastmsgid->EditAttrs["class"] = "form-control";
			$this->lastmsgid->EditCustomAttributes = "";
			$this->lastmsgid->EditValue = HtmlEncode($this->lastmsgid->CurrentValue);
			$this->lastmsgid->PlaceHolder = RemoveHtml($this->lastmsgid->caption());

			// otprequiredforphysicalcards
			$this->otprequiredforphysicalcards->EditAttrs["class"] = "form-control";
			$this->otprequiredforphysicalcards->EditCustomAttributes = "";
			$this->otprequiredforphysicalcards->EditValue = HtmlEncode($this->otprequiredforphysicalcards->CurrentValue);
			$this->otprequiredforphysicalcards->PlaceHolder = RemoveHtml($this->otprequiredforphysicalcards->caption());

			// otpvaliduntil
			$this->otpvaliduntil->EditAttrs["class"] = "form-control";
			$this->otpvaliduntil->EditCustomAttributes = "";
			$this->otpvaliduntil->EditValue = HtmlEncode(FormatDateTime($this->otpvaliduntil->CurrentValue, 8));
			$this->otpvaliduntil->PlaceHolder = RemoveHtml($this->otpvaliduntil->caption());

			// nationalitycountry
			$this->nationalitycountry->EditAttrs["class"] = "form-control";
			$this->nationalitycountry->EditCustomAttributes = "";
			$curVal = trim(strval($this->nationalitycountry->CurrentValue));
			if ($curVal != "")
				$this->nationalitycountry->ViewValue = $this->nationalitycountry->lookupCacheOption($curVal);
			else
				$this->nationalitycountry->ViewValue = $this->nationalitycountry->Lookup !== NULL && is_array($this->nationalitycountry->Lookup->Options) ? $curVal : NULL;
			if ($this->nationalitycountry->ViewValue !== NULL) { // Load from cache
				$this->nationalitycountry->EditValue = array_values($this->nationalitycountry->Lookup->Options);
			} else { // Lookup from database
				if ($curVal == "") {
					$filterWrk = "0=1";
				} else {
					$filterWrk = "`countryID`" . SearchString("=", $this->nationalitycountry->CurrentValue, DATATYPE_STRING, "_4payreference");
				}
				$sqlWrk = $this->nationalitycountry->Lookup->getSql(TRUE, $filterWrk, '', $this);
				$rswrk = Conn("_4payreference")->execute($sqlWrk);
				$arwrk = $rswrk ? $rswrk->getRows() : [];
				if ($rswrk)
					$rswrk->close();
				$this->nationalitycountry->EditValue = $arwrk;
			}

			// classification
			$this->classification->EditAttrs["class"] = "form-control";
			$this->classification->EditCustomAttributes = "";
			$curVal = trim(strval($this->classification->CurrentValue));
			if ($curVal != "")
				$this->classification->ViewValue = $this->classification->lookupCacheOption($curVal);
			else
				$this->classification->ViewValue = $this->classification->Lookup !== NULL && is_array($this->classification->Lookup->Options) ? $curVal : NULL;
			if ($this->classification->ViewValue !== NULL) { // Load from cache
				$this->classification->EditValue = array_values($this->classification->Lookup->Options);
			} else { // Lookup from database
				if ($curVal == "") {
					$filterWrk = "0=1";
				} else {
					$filterWrk = "`typeID`" . SearchString("=", $this->classification->CurrentValue, DATATYPE_STRING, "_4payreference");
				}
				$sqlWrk = $this->classification->Lookup->getSql(TRUE, $filterWrk, '', $this);
				$rswrk = Conn("_4payreference")->execute($sqlWrk);
				$arwrk = $rswrk ? $rswrk->getRows() : [];
				if ($rswrk)
					$rswrk->close();
				$this->classification->EditValue = $arwrk;
			}

			// occupation
			$this->occupation->EditAttrs["class"] = "form-control";
			$this->occupation->EditCustomAttributes = "";
			if (!$this->occupation->Raw)
				$this->occupation->CurrentValue = HtmlDecode($this->occupation->CurrentValue);
			$this->occupation->EditValue = HtmlEncode($this->occupation->CurrentValue);
			$curVal = strval($this->occupation->CurrentValue);
			if ($curVal != "") {
				$this->occupation->EditValue = $this->occupation->lookupCacheOption($curVal);
				if ($this->occupation->EditValue === NULL) { // Lookup from database
					$filterWrk = "`typeID`" . SearchString("=", $curVal, DATATYPE_STRING, "_4payreference");
					$sqlWrk = $this->occupation->Lookup->getSql(FALSE, $filterWrk, '', $this);
					$rswrk = Conn("_4payreference")->execute($sqlWrk);
					if ($rswrk && !$rswrk->EOF) { // Lookup values found
						$arwrk = [];
						$arwrk[1] = HtmlEncode($rswrk->fields('df'));
						$this->occupation->EditValue = $this->occupation->displayValue($arwrk);
						$rswrk->Close();
					} else {
						$this->occupation->EditValue = HtmlEncode($this->occupation->CurrentValue);
					}
				}
			} else {
				$this->occupation->EditValue = NULL;
			}
			$this->occupation->PlaceHolder = RemoveHtml($this->occupation->caption());

			// sourceofincome
			$this->sourceofincome->EditAttrs["class"] = "form-control";
			$this->sourceofincome->EditCustomAttributes = "";
			$curVal = trim(strval($this->sourceofincome->CurrentValue));
			if ($curVal != "")
				$this->sourceofincome->ViewValue = $this->sourceofincome->lookupCacheOption($curVal);
			else
				$this->sourceofincome->ViewValue = $this->sourceofincome->Lookup !== NULL && is_array($this->sourceofincome->Lookup->Options) ? $curVal : NULL;
			if ($this->sourceofincome->ViewValue !== NULL) { // Load from cache
				$this->sourceofincome->EditValue = array_values($this->sourceofincome->Lookup->Options);
			} else { // Lookup from database
				if ($curVal == "") {
					$filterWrk = "0=1";
				} else {
					$filterWrk = "`typeID`" . SearchString("=", $this->sourceofincome->CurrentValue, DATATYPE_STRING, "_4payreference");
				}
				$sqlWrk = $this->sourceofincome->Lookup->getSql(TRUE, $filterWrk, '', $this);
				$rswrk = Conn("_4payreference")->execute($sqlWrk);
				$arwrk = $rswrk ? $rswrk->getRows() : [];
				if ($rswrk)
					$rswrk->close();
				$this->sourceofincome->EditValue = $arwrk;
			}

			// accountopeningdate
			$this->accountopeningdate->EditAttrs["class"] = "form-control";
			$this->accountopeningdate->EditCustomAttributes = "";
			$this->accountopeningdate->EditValue = HtmlEncode(FormatDateTime($this->accountopeningdate->CurrentValue, 8));
			$this->accountopeningdate->PlaceHolder = RemoveHtml($this->accountopeningdate->caption());

			// extendedfields
			$this->extendedfields->EditAttrs["class"] = "form-control";
			$this->extendedfields->EditCustomAttributes = "";
			$this->extendedfields->EditValue = HtmlEncode($this->extendedfields->CurrentValue);
			$this->extendedfields->PlaceHolder = RemoveHtml($this->extendedfields->caption());

			// lastprofilestatuschangedate
			$this->lastprofilestatuschangedate->EditAttrs["class"] = "form-control";
			$this->lastprofilestatuschangedate->EditCustomAttributes = "";
			$this->lastprofilestatuschangedate->EditValue = HtmlEncode(FormatDateTime($this->lastprofilestatuschangedate->CurrentValue, 8));
			$this->lastprofilestatuschangedate->PlaceHolder = RemoveHtml($this->lastprofilestatuschangedate->caption());

			// Edit refer script
			// id

			$this->id->LinkCustomAttributes = "";
			$this->id->HrefValue = "";

			// firstName
			$this->firstName->LinkCustomAttributes = "";
			$this->firstName->HrefValue = "";

			// lastName
			$this->lastName->LinkCustomAttributes = "";
			$this->lastName->HrefValue = "";

			// otherNames
			$this->otherNames->LinkCustomAttributes = "";
			$this->otherNames->HrefValue = "";

			// passwordRequireChange
			$this->passwordRequireChange->LinkCustomAttributes = "";
			$this->passwordRequireChange->HrefValue = "";

			// franchiseeID
			$this->franchiseeID->LinkCustomAttributes = "";
			$this->franchiseeID->HrefValue = "";

			// dateAdded
			$this->dateAdded->LinkCustomAttributes = "";
			$this->dateAdded->HrefValue = "";

			// timezoneid
			$this->timezoneid->LinkCustomAttributes = "";
			$this->timezoneid->HrefValue = "";

			// contactPhoneNo
			$this->contactPhoneNo->LinkCustomAttributes = "";
			$this->contactPhoneNo->HrefValue = "";

			// telephoneno
			$this->telephoneno->LinkCustomAttributes = "";
			$this->telephoneno->HrefValue = "";

			// telephoneverified
			$this->telephoneverified->LinkCustomAttributes = "";
			$this->telephoneverified->HrefValue = "";

			// telephonereceivemessage
			$this->telephonereceivemessage->LinkCustomAttributes = "";
			$this->telephonereceivemessage->HrefValue = "";

			// verification1
			$this->verification1->LinkCustomAttributes = "";
			$this->verification1->HrefValue = "";

			// verification2
			$this->verification2->LinkCustomAttributes = "";
			$this->verification2->HrefValue = "";

			// verification3
			$this->verification3->LinkCustomAttributes = "";
			$this->verification3->HrefValue = "";

			// address1
			$this->address1->LinkCustomAttributes = "";
			$this->address1->HrefValue = "";

			// address2
			$this->address2->LinkCustomAttributes = "";
			$this->address2->HrefValue = "";

			// cityname
			$this->cityname->LinkCustomAttributes = "";
			$this->cityname->HrefValue = "";

			// countryid
			$this->countryid->LinkCustomAttributes = "";
			$this->countryid->HrefValue = "";

			// stateid
			$this->stateid->LinkCustomAttributes = "";
			$this->stateid->HrefValue = "";

			// defaultcurrency
			$this->defaultcurrency->LinkCustomAttributes = "";
			$this->defaultcurrency->HrefValue = "";

			// challengeq1
			$this->challengeq1->LinkCustomAttributes = "";
			$this->challengeq1->HrefValue = "";

			// challengea1
			$this->challengea1->LinkCustomAttributes = "";
			$this->challengea1->HrefValue = "";

			// challengeq2
			$this->challengeq2->LinkCustomAttributes = "";
			$this->challengeq2->HrefValue = "";

			// challengea2
			$this->challengea2->LinkCustomAttributes = "";
			$this->challengea2->HrefValue = "";

			// challengeq3
			$this->challengeq3->LinkCustomAttributes = "";
			$this->challengeq3->HrefValue = "";

			// challengea3
			$this->challengea3->LinkCustomAttributes = "";
			$this->challengea3->HrefValue = "";

			// passwordCounter
			$this->passwordCounter->LinkCustomAttributes = "";
			$this->passwordCounter->HrefValue = "";

			// passwordChangedDate
			$this->passwordChangedDate->LinkCustomAttributes = "";
			$this->passwordChangedDate->HrefValue = "";

			// pinCounter
			$this->pinCounter->LinkCustomAttributes = "";
			$this->pinCounter->HrefValue = "";

			// langID
			$this->langID->LinkCustomAttributes = "";
			$this->langID->HrefValue = "";

			// photo
			$this->photo->LinkCustomAttributes = "";
			if (!EmptyValue($this->photo->Upload->DbValue)) {
				$this->photo->HrefValue = GetFileUploadUrl($this->photo, $this->photo->htmlDecode($this->photo->Upload->DbValue)); // Add prefix/suffix
				$this->photo->LinkAttrs["target"] = ""; // Add target
				if ($this->isExport())
					$this->photo->HrefValue = FullUrl($this->photo->HrefValue, "href");
			} else {
				$this->photo->HrefValue = "";
			}
			$this->photo->ExportHrefValue = $this->photo->UploadPath . $this->photo->Upload->DbValue;

			// status
			$this->status->LinkCustomAttributes = "";
			$this->status->HrefValue = "";

			// markedfordeletion
			$this->markedfordeletion->LinkCustomAttributes = "";
			$this->markedfordeletion->HrefValue = "";

			// userType
			$this->userType->LinkCustomAttributes = "";
			$this->userType->HrefValue = "";

			// usersubtype
			$this->usersubtype->LinkCustomAttributes = "";
			$this->usersubtype->HrefValue = "";

			// accountID
			$this->accountID->LinkCustomAttributes = "";
			if (!EmptyValue($this->accountID->CurrentValue)) {
				$this->accountID->HrefValue = "http://localhost/adminportal2020/snode/acctbalancelist.php?showmaster=acct&fk_acctID=" . $this->accountID->CurrentValue; // Add prefix/suffix
				$this->accountID->LinkAttrs["target"] = "_self"; // Add target
				if ($this->isExport())
					$this->accountID->HrefValue = FullUrl($this->accountID->HrefValue, "href");
			} else {
				$this->accountID->HrefValue = "";
			}

			// brokerid
			$this->brokerid->LinkCustomAttributes = "";
			$this->brokerid->HrefValue = "";

			// parentuserid
			$this->parentuserid->LinkCustomAttributes = "";
			$this->parentuserid->HrefValue = "";

			// corporate
			$this->corporate->LinkCustomAttributes = "";
			$this->corporate->HrefValue = "";

			// profilestatus
			$this->profilestatus->LinkCustomAttributes = "";
			$this->profilestatus->HrefValue = "";

			// jumpappid
			$this->jumpappid->LinkCustomAttributes = "";
			$this->jumpappid->HrefValue = "";

			// dateofbirth
			$this->dateofbirth->LinkCustomAttributes = "";
			$this->dateofbirth->HrefValue = "";

			// gender
			$this->gender->LinkCustomAttributes = "";
			$this->gender->HrefValue = "";

			// lastupdatedate
			$this->lastupdatedate->LinkCustomAttributes = "";
			$this->lastupdatedate->HrefValue = "";

			// jumprequiredatlogin
			$this->jumprequiredatlogin->LinkCustomAttributes = "";
			$this->jumprequiredatlogin->HrefValue = "";

			// ccbypass
			$this->ccbypass->LinkCustomAttributes = "";
			$this->ccbypass->HrefValue = "";

			// zip
			$this->zip->LinkCustomAttributes = "";
			$this->zip->HrefValue = "";

			// other1
			$this->other1->LinkCustomAttributes = "";
			$this->other1->HrefValue = "";

			// other2
			$this->other2->LinkCustomAttributes = "";
			$this->other2->HrefValue = "";

			// other3
			$this->other3->LinkCustomAttributes = "";
			$this->other3->HrefValue = "";

			// other4
			$this->other4->LinkCustomAttributes = "";
			$this->other4->HrefValue = "";

			// other5
			$this->other5->LinkCustomAttributes = "";
			$this->other5->HrefValue = "";

			// other6
			$this->other6->LinkCustomAttributes = "";
			$this->other6->HrefValue = "";

			// mincashamount
			$this->mincashamount->LinkCustomAttributes = "";
			$this->mincashamount->HrefValue = "";

			// maxcashamount
			$this->maxcashamount->LinkCustomAttributes = "";
			$this->maxcashamount->HrefValue = "";

			// maxtransferinamount
			$this->maxtransferinamount->LinkCustomAttributes = "";
			$this->maxtransferinamount->HrefValue = "";

			// maxtransferoutamount
			$this->maxtransferoutamount->LinkCustomAttributes = "";
			$this->maxtransferoutamount->HrefValue = "";

			// legalid
			$this->legalid->LinkCustomAttributes = "";
			$this->legalid->HrefValue = "";

			// userpiview
			$this->userpiview->LinkCustomAttributes = "";
			$this->userpiview->HrefValue = "";

			// lastmsgid
			$this->lastmsgid->LinkCustomAttributes = "";
			$this->lastmsgid->HrefValue = "";

			// otprequiredforphysicalcards
			$this->otprequiredforphysicalcards->LinkCustomAttributes = "";
			$this->otprequiredforphysicalcards->HrefValue = "";

			// otpvaliduntil
			$this->otpvaliduntil->LinkCustomAttributes = "";
			$this->otpvaliduntil->HrefValue = "";

			// nationalitycountry
			$this->nationalitycountry->LinkCustomAttributes = "";
			$this->nationalitycountry->HrefValue = "";

			// classification
			$this->classification->LinkCustomAttributes = "";
			$this->classification->HrefValue = "";

			// occupation
			$this->occupation->LinkCustomAttributes = "";
			$this->occupation->HrefValue = "";

			// sourceofincome
			$this->sourceofincome->LinkCustomAttributes = "";
			$this->sourceofincome->HrefValue = "";

			// accountopeningdate
			$this->accountopeningdate->LinkCustomAttributes = "";
			$this->accountopeningdate->HrefValue = "";

			// extendedfields
			$this->extendedfields->LinkCustomAttributes = "";
			$this->extendedfields->HrefValue = "";

			// lastprofilestatuschangedate
			$this->lastprofilestatuschangedate->LinkCustomAttributes = "";
			$this->lastprofilestatuschangedate->HrefValue = "";
		}
		if ($this->RowType == ROWTYPE_ADD || $this->RowType == ROWTYPE_EDIT || $this->RowType == ROWTYPE_SEARCH) // Add/Edit/Search row
			$this->setupFieldTitles();

		// Call Row Rendered event
		if ($this->RowType != ROWTYPE_AGGREGATEINIT)
			$this->Row_Rendered();
	}

	// Validate form
	protected function validateForm()
	{
		global $Language, $FormError;

		// Initialize form error message
		$FormError = "";

		// Check if validation required
		if (!Config("SERVER_VALIDATE"))
			return ($FormError == "");
		if ($this->id->Required) {
			if (!$this->id->IsDetailKey && $this->id->FormValue != NULL && $this->id->FormValue == "") {
				AddMessage($FormError, str_replace("%s", $this->id->caption(), $this->id->RequiredErrorMessage));
			}
		}
		if (!CheckInteger($this->id->FormValue)) {
			AddMessage($FormError, $this->id->errorMessage());
		}
		if ($this->firstName->Required) {
			if (!$this->firstName->IsDetailKey && $this->firstName->FormValue != NULL && $this->firstName->FormValue == "") {
				AddMessage($FormError, str_replace("%s", $this->firstName->caption(), $this->firstName->RequiredErrorMessage));
			}
		}
		if ($this->lastName->Required) {
			if (!$this->lastName->IsDetailKey && $this->lastName->FormValue != NULL && $this->lastName->FormValue == "") {
				AddMessage($FormError, str_replace("%s", $this->lastName->caption(), $this->lastName->RequiredErrorMessage));
			}
		}
		if ($this->otherNames->Required) {
			if (!$this->otherNames->IsDetailKey && $this->otherNames->FormValue != NULL && $this->otherNames->FormValue == "") {
				AddMessage($FormError, str_replace("%s", $this->otherNames->caption(), $this->otherNames->RequiredErrorMessage));
			}
		}
		if ($this->passwordRequireChange->Required) {
			if ($this->passwordRequireChange->FormValue == "") {
				AddMessage($FormError, str_replace("%s", $this->passwordRequireChange->caption(), $this->passwordRequireChange->RequiredErrorMessage));
			}
		}
		if ($this->franchiseeID->Required) {
			if (!$this->franchiseeID->IsDetailKey && $this->franchiseeID->FormValue != NULL && $this->franchiseeID->FormValue == "") {
				AddMessage($FormError, str_replace("%s", $this->franchiseeID->caption(), $this->franchiseeID->RequiredErrorMessage));
			}
		}
		if (!CheckInteger($this->franchiseeID->FormValue)) {
			AddMessage($FormError, $this->franchiseeID->errorMessage());
		}
		if ($this->dateAdded->Required) {
			if (!$this->dateAdded->IsDetailKey && $this->dateAdded->FormValue != NULL && $this->dateAdded->FormValue == "") {
				AddMessage($FormError, str_replace("%s", $this->dateAdded->caption(), $this->dateAdded->RequiredErrorMessage));
			}
		}
		if (!CheckDate($this->dateAdded->FormValue)) {
			AddMessage($FormError, $this->dateAdded->errorMessage());
		}
		if ($this->timezoneid->Required) {
			if (!$this->timezoneid->IsDetailKey && $this->timezoneid->FormValue != NULL && $this->timezoneid->FormValue == "") {
				AddMessage($FormError, str_replace("%s", $this->timezoneid->caption(), $this->timezoneid->RequiredErrorMessage));
			}
		}
		if ($this->contactPhoneNo->Required) {
			if (!$this->contactPhoneNo->IsDetailKey && $this->contactPhoneNo->FormValue != NULL && $this->contactPhoneNo->FormValue == "") {
				AddMessage($FormError, str_replace("%s", $this->contactPhoneNo->caption(), $this->contactPhoneNo->RequiredErrorMessage));
			}
		}
		if ($this->telephoneno->Required) {
			if (!$this->telephoneno->IsDetailKey && $this->telephoneno->FormValue != NULL && $this->telephoneno->FormValue == "") {
				AddMessage($FormError, str_replace("%s", $this->telephoneno->caption(), $this->telephoneno->RequiredErrorMessage));
			}
		}
		if ($this->telephoneverified->Required) {
			if ($this->telephoneverified->FormValue == "") {
				AddMessage($FormError, str_replace("%s", $this->telephoneverified->caption(), $this->telephoneverified->RequiredErrorMessage));
			}
		}
		if ($this->telephonereceivemessage->Required) {
			if ($this->telephonereceivemessage->FormValue == "") {
				AddMessage($FormError, str_replace("%s", $this->telephonereceivemessage->caption(), $this->telephonereceivemessage->RequiredErrorMessage));
			}
		}
		if ($this->verification1->Required) {
			if (!$this->verification1->IsDetailKey && $this->verification1->FormValue != NULL && $this->verification1->FormValue == "") {
				AddMessage($FormError, str_replace("%s", $this->verification1->caption(), $this->verification1->RequiredErrorMessage));
			}
		}
		if ($this->verification2->Required) {
			if (!$this->verification2->IsDetailKey && $this->verification2->FormValue != NULL && $this->verification2->FormValue == "") {
				AddMessage($FormError, str_replace("%s", $this->verification2->caption(), $this->verification2->RequiredErrorMessage));
			}
		}
		if ($this->verification3->Required) {
			if (!$this->verification3->IsDetailKey && $this->verification3->FormValue != NULL && $this->verification3->FormValue == "") {
				AddMessage($FormError, str_replace("%s", $this->verification3->caption(), $this->verification3->RequiredErrorMessage));
			}
		}
		if ($this->address1->Required) {
			if (!$this->address1->IsDetailKey && $this->address1->FormValue != NULL && $this->address1->FormValue == "") {
				AddMessage($FormError, str_replace("%s", $this->address1->caption(), $this->address1->RequiredErrorMessage));
			}
		}
		if ($this->address2->Required) {
			if (!$this->address2->IsDetailKey && $this->address2->FormValue != NULL && $this->address2->FormValue == "") {
				AddMessage($FormError, str_replace("%s", $this->address2->caption(), $this->address2->RequiredErrorMessage));
			}
		}
		if ($this->cityname->Required) {
			if (!$this->cityname->IsDetailKey && $this->cityname->FormValue != NULL && $this->cityname->FormValue == "") {
				AddMessage($FormError, str_replace("%s", $this->cityname->caption(), $this->cityname->RequiredErrorMessage));
			}
		}
		if ($this->countryid->Required) {
			if (!$this->countryid->IsDetailKey && $this->countryid->FormValue != NULL && $this->countryid->FormValue == "") {
				AddMessage($FormError, str_replace("%s", $this->countryid->caption(), $this->countryid->RequiredErrorMessage));
			}
		}
		if ($this->stateid->Required) {
			if (!$this->stateid->IsDetailKey && $this->stateid->FormValue != NULL && $this->stateid->FormValue == "") {
				AddMessage($FormError, str_replace("%s", $this->stateid->caption(), $this->stateid->RequiredErrorMessage));
			}
		}
		if ($this->defaultcurrency->Required) {
			if (!$this->defaultcurrency->IsDetailKey && $this->defaultcurrency->FormValue != NULL && $this->defaultcurrency->FormValue == "") {
				AddMessage($FormError, str_replace("%s", $this->defaultcurrency->caption(), $this->defaultcurrency->RequiredErrorMessage));
			}
		}
		if ($this->challengeq1->Required) {
			if (!$this->challengeq1->IsDetailKey && $this->challengeq1->FormValue != NULL && $this->challengeq1->FormValue == "") {
				AddMessage($FormError, str_replace("%s", $this->challengeq1->caption(), $this->challengeq1->RequiredErrorMessage));
			}
		}
		if (!CheckInteger($this->challengeq1->FormValue)) {
			AddMessage($FormError, $this->challengeq1->errorMessage());
		}
		if ($this->challengea1->Required) {
			if (!$this->challengea1->IsDetailKey && $this->challengea1->FormValue != NULL && $this->challengea1->FormValue == "") {
				AddMessage($FormError, str_replace("%s", $this->challengea1->caption(), $this->challengea1->RequiredErrorMessage));
			}
		}
		if ($this->challengeq2->Required) {
			if (!$this->challengeq2->IsDetailKey && $this->challengeq2->FormValue != NULL && $this->challengeq2->FormValue == "") {
				AddMessage($FormError, str_replace("%s", $this->challengeq2->caption(), $this->challengeq2->RequiredErrorMessage));
			}
		}
		if (!CheckInteger($this->challengeq2->FormValue)) {
			AddMessage($FormError, $this->challengeq2->errorMessage());
		}
		if ($this->challengea2->Required) {
			if (!$this->challengea2->IsDetailKey && $this->challengea2->FormValue != NULL && $this->challengea2->FormValue == "") {
				AddMessage($FormError, str_replace("%s", $this->challengea2->caption(), $this->challengea2->RequiredErrorMessage));
			}
		}
		if ($this->challengeq3->Required) {
			if (!$this->challengeq3->IsDetailKey && $this->challengeq3->FormValue != NULL && $this->challengeq3->FormValue == "") {
				AddMessage($FormError, str_replace("%s", $this->challengeq3->caption(), $this->challengeq3->RequiredErrorMessage));
			}
		}
		if (!CheckInteger($this->challengeq3->FormValue)) {
			AddMessage($FormError, $this->challengeq3->errorMessage());
		}
		if ($this->challengea3->Required) {
			if (!$this->challengea3->IsDetailKey && $this->challengea3->FormValue != NULL && $this->challengea3->FormValue == "") {
				AddMessage($FormError, str_replace("%s", $this->challengea3->caption(), $this->challengea3->RequiredErrorMessage));
			}
		}
		if ($this->passwordCounter->Required) {
			if (!$this->passwordCounter->IsDetailKey && $this->passwordCounter->FormValue != NULL && $this->passwordCounter->FormValue == "") {
				AddMessage($FormError, str_replace("%s", $this->passwordCounter->caption(), $this->passwordCounter->RequiredErrorMessage));
			}
		}
		if (!CheckInteger($this->passwordCounter->FormValue)) {
			AddMessage($FormError, $this->passwordCounter->errorMessage());
		}
		if ($this->passwordChangedDate->Required) {
			if (!$this->passwordChangedDate->IsDetailKey && $this->passwordChangedDate->FormValue != NULL && $this->passwordChangedDate->FormValue == "") {
				AddMessage($FormError, str_replace("%s", $this->passwordChangedDate->caption(), $this->passwordChangedDate->RequiredErrorMessage));
			}
		}
		if (!CheckDate($this->passwordChangedDate->FormValue)) {
			AddMessage($FormError, $this->passwordChangedDate->errorMessage());
		}
		if ($this->pinCounter->Required) {
			if (!$this->pinCounter->IsDetailKey && $this->pinCounter->FormValue != NULL && $this->pinCounter->FormValue == "") {
				AddMessage($FormError, str_replace("%s", $this->pinCounter->caption(), $this->pinCounter->RequiredErrorMessage));
			}
		}
		if (!CheckInteger($this->pinCounter->FormValue)) {
			AddMessage($FormError, $this->pinCounter->errorMessage());
		}
		if ($this->langID->Required) {
			if (!$this->langID->IsDetailKey && $this->langID->FormValue != NULL && $this->langID->FormValue == "") {
				AddMessage($FormError, str_replace("%s", $this->langID->caption(), $this->langID->RequiredErrorMessage));
			}
		}
		if ($this->photo->Required) {
			if ($this->photo->Upload->FileName == "" && !$this->photo->Upload->KeepFile) {
				AddMessage($FormError, str_replace("%s", $this->photo->caption(), $this->photo->RequiredErrorMessage));
			}
		}
		if ($this->status->Required) {
			if (!$this->status->IsDetailKey && $this->status->FormValue != NULL && $this->status->FormValue == "") {
				AddMessage($FormError, str_replace("%s", $this->status->caption(), $this->status->RequiredErrorMessage));
			}
		}
		if ($this->markedfordeletion->Required) {
			if (!$this->markedfordeletion->IsDetailKey && $this->markedfordeletion->FormValue != NULL && $this->markedfordeletion->FormValue == "") {
				AddMessage($FormError, str_replace("%s", $this->markedfordeletion->caption(), $this->markedfordeletion->RequiredErrorMessage));
			}
		}
		if (!CheckDate($this->markedfordeletion->FormValue)) {
			AddMessage($FormError, $this->markedfordeletion->errorMessage());
		}
		if ($this->userType->Required) {
			if (!$this->userType->IsDetailKey && $this->userType->FormValue != NULL && $this->userType->FormValue == "") {
				AddMessage($FormError, str_replace("%s", $this->userType->caption(), $this->userType->RequiredErrorMessage));
			}
		}
		if ($this->usersubtype->Required) {
			if (!$this->usersubtype->IsDetailKey && $this->usersubtype->FormValue != NULL && $this->usersubtype->FormValue == "") {
				AddMessage($FormError, str_replace("%s", $this->usersubtype->caption(), $this->usersubtype->RequiredErrorMessage));
			}
		}
		if ($this->accountID->Required) {
			if (!$this->accountID->IsDetailKey && $this->accountID->FormValue != NULL && $this->accountID->FormValue == "") {
				AddMessage($FormError, str_replace("%s", $this->accountID->caption(), $this->accountID->RequiredErrorMessage));
			}
		}
		if (!CheckInteger($this->accountID->FormValue)) {
			AddMessage($FormError, $this->accountID->errorMessage());
		}
		if ($this->brokerid->Required) {
			if (!$this->brokerid->IsDetailKey && $this->brokerid->FormValue != NULL && $this->brokerid->FormValue == "") {
				AddMessage($FormError, str_replace("%s", $this->brokerid->caption(), $this->brokerid->RequiredErrorMessage));
			}
		}
		if (!CheckInteger($this->brokerid->FormValue)) {
			AddMessage($FormError, $this->brokerid->errorMessage());
		}
		if ($this->parentuserid->Required) {
			if (!$this->parentuserid->IsDetailKey && $this->parentuserid->FormValue != NULL && $this->parentuserid->FormValue == "") {
				AddMessage($FormError, str_replace("%s", $this->parentuserid->caption(), $this->parentuserid->RequiredErrorMessage));
			}
		}
		if (!CheckInteger($this->parentuserid->FormValue)) {
			AddMessage($FormError, $this->parentuserid->errorMessage());
		}
		if ($this->corporate->Required) {
			if ($this->corporate->FormValue == "") {
				AddMessage($FormError, str_replace("%s", $this->corporate->caption(), $this->corporate->RequiredErrorMessage));
			}
		}
		if ($this->profilestatus->Required) {
			if (!$this->profilestatus->IsDetailKey && $this->profilestatus->FormValue != NULL && $this->profilestatus->FormValue == "") {
				AddMessage($FormError, str_replace("%s", $this->profilestatus->caption(), $this->profilestatus->RequiredErrorMessage));
			}
		}
		if ($this->jumpappid->Required) {
			if (!$this->jumpappid->IsDetailKey && $this->jumpappid->FormValue != NULL && $this->jumpappid->FormValue == "") {
				AddMessage($FormError, str_replace("%s", $this->jumpappid->caption(), $this->jumpappid->RequiredErrorMessage));
			}
		}
		if (!CheckInteger($this->jumpappid->FormValue)) {
			AddMessage($FormError, $this->jumpappid->errorMessage());
		}
		if ($this->dateofbirth->Required) {
			if (!$this->dateofbirth->IsDetailKey && $this->dateofbirth->FormValue != NULL && $this->dateofbirth->FormValue == "") {
				AddMessage($FormError, str_replace("%s", $this->dateofbirth->caption(), $this->dateofbirth->RequiredErrorMessage));
			}
		}
		if (!CheckDate($this->dateofbirth->FormValue)) {
			AddMessage($FormError, $this->dateofbirth->errorMessage());
		}
		if ($this->gender->Required) {
			if (!$this->gender->IsDetailKey && $this->gender->FormValue != NULL && $this->gender->FormValue == "") {
				AddMessage($FormError, str_replace("%s", $this->gender->caption(), $this->gender->RequiredErrorMessage));
			}
		}
		if ($this->lastupdatedate->Required) {
			if (!$this->lastupdatedate->IsDetailKey && $this->lastupdatedate->FormValue != NULL && $this->lastupdatedate->FormValue == "") {
				AddMessage($FormError, str_replace("%s", $this->lastupdatedate->caption(), $this->lastupdatedate->RequiredErrorMessage));
			}
		}
		if (!CheckDate($this->lastupdatedate->FormValue)) {
			AddMessage($FormError, $this->lastupdatedate->errorMessage());
		}
		if ($this->jumprequiredatlogin->Required) {
			if ($this->jumprequiredatlogin->FormValue == "") {
				AddMessage($FormError, str_replace("%s", $this->jumprequiredatlogin->caption(), $this->jumprequiredatlogin->RequiredErrorMessage));
			}
		}
		if ($this->ccbypass->Required) {
			if ($this->ccbypass->FormValue == "") {
				AddMessage($FormError, str_replace("%s", $this->ccbypass->caption(), $this->ccbypass->RequiredErrorMessage));
			}
		}
		if ($this->zip->Required) {
			if (!$this->zip->IsDetailKey && $this->zip->FormValue != NULL && $this->zip->FormValue == "") {
				AddMessage($FormError, str_replace("%s", $this->zip->caption(), $this->zip->RequiredErrorMessage));
			}
		}
		if ($this->other1->Required) {
			if (!$this->other1->IsDetailKey && $this->other1->FormValue != NULL && $this->other1->FormValue == "") {
				AddMessage($FormError, str_replace("%s", $this->other1->caption(), $this->other1->RequiredErrorMessage));
			}
		}
		if ($this->other2->Required) {
			if (!$this->other2->IsDetailKey && $this->other2->FormValue != NULL && $this->other2->FormValue == "") {
				AddMessage($FormError, str_replace("%s", $this->other2->caption(), $this->other2->RequiredErrorMessage));
			}
		}
		if ($this->other3->Required) {
			if (!$this->other3->IsDetailKey && $this->other3->FormValue != NULL && $this->other3->FormValue == "") {
				AddMessage($FormError, str_replace("%s", $this->other3->caption(), $this->other3->RequiredErrorMessage));
			}
		}
		if ($this->other4->Required) {
			if (!$this->other4->IsDetailKey && $this->other4->FormValue != NULL && $this->other4->FormValue == "") {
				AddMessage($FormError, str_replace("%s", $this->other4->caption(), $this->other4->RequiredErrorMessage));
			}
		}
		if ($this->other5->Required) {
			if (!$this->other5->IsDetailKey && $this->other5->FormValue != NULL && $this->other5->FormValue == "") {
				AddMessage($FormError, str_replace("%s", $this->other5->caption(), $this->other5->RequiredErrorMessage));
			}
		}
		if ($this->other6->Required) {
			if (!$this->other6->IsDetailKey && $this->other6->FormValue != NULL && $this->other6->FormValue == "") {
				AddMessage($FormError, str_replace("%s", $this->other6->caption(), $this->other6->RequiredErrorMessage));
			}
		}
		if ($this->mincashamount->Required) {
			if (!$this->mincashamount->IsDetailKey && $this->mincashamount->FormValue != NULL && $this->mincashamount->FormValue == "") {
				AddMessage($FormError, str_replace("%s", $this->mincashamount->caption(), $this->mincashamount->RequiredErrorMessage));
			}
		}
		if (!CheckNumber($this->mincashamount->FormValue)) {
			AddMessage($FormError, $this->mincashamount->errorMessage());
		}
		if ($this->maxcashamount->Required) {
			if (!$this->maxcashamount->IsDetailKey && $this->maxcashamount->FormValue != NULL && $this->maxcashamount->FormValue == "") {
				AddMessage($FormError, str_replace("%s", $this->maxcashamount->caption(), $this->maxcashamount->RequiredErrorMessage));
			}
		}
		if (!CheckNumber($this->maxcashamount->FormValue)) {
			AddMessage($FormError, $this->maxcashamount->errorMessage());
		}
		if ($this->maxtransferinamount->Required) {
			if (!$this->maxtransferinamount->IsDetailKey && $this->maxtransferinamount->FormValue != NULL && $this->maxtransferinamount->FormValue == "") {
				AddMessage($FormError, str_replace("%s", $this->maxtransferinamount->caption(), $this->maxtransferinamount->RequiredErrorMessage));
			}
		}
		if (!CheckNumber($this->maxtransferinamount->FormValue)) {
			AddMessage($FormError, $this->maxtransferinamount->errorMessage());
		}
		if ($this->maxtransferoutamount->Required) {
			if (!$this->maxtransferoutamount->IsDetailKey && $this->maxtransferoutamount->FormValue != NULL && $this->maxtransferoutamount->FormValue == "") {
				AddMessage($FormError, str_replace("%s", $this->maxtransferoutamount->caption(), $this->maxtransferoutamount->RequiredErrorMessage));
			}
		}
		if (!CheckNumber($this->maxtransferoutamount->FormValue)) {
			AddMessage($FormError, $this->maxtransferoutamount->errorMessage());
		}
		if ($this->legalid->Required) {
			if (!$this->legalid->IsDetailKey && $this->legalid->FormValue != NULL && $this->legalid->FormValue == "") {
				AddMessage($FormError, str_replace("%s", $this->legalid->caption(), $this->legalid->RequiredErrorMessage));
			}
		}
		if (!CheckInteger($this->legalid->FormValue)) {
			AddMessage($FormError, $this->legalid->errorMessage());
		}
		if ($this->userpiview->Required) {
			if ($this->userpiview->FormValue == "") {
				AddMessage($FormError, str_replace("%s", $this->userpiview->caption(), $this->userpiview->RequiredErrorMessage));
			}
		}
		if ($this->lastmsgid->Required) {
			if (!$this->lastmsgid->IsDetailKey && $this->lastmsgid->FormValue != NULL && $this->lastmsgid->FormValue == "") {
				AddMessage($FormError, str_replace("%s", $this->lastmsgid->caption(), $this->lastmsgid->RequiredErrorMessage));
			}
		}
		if (!CheckInteger($this->lastmsgid->FormValue)) {
			AddMessage($FormError, $this->lastmsgid->errorMessage());
		}
		if ($this->otprequiredforphysicalcards->Required) {
			if (!$this->otprequiredforphysicalcards->IsDetailKey && $this->otprequiredforphysicalcards->FormValue != NULL && $this->otprequiredforphysicalcards->FormValue == "") {
				AddMessage($FormError, str_replace("%s", $this->otprequiredforphysicalcards->caption(), $this->otprequiredforphysicalcards->RequiredErrorMessage));
			}
		}
		if (!CheckInteger($this->otprequiredforphysicalcards->FormValue)) {
			AddMessage($FormError, $this->otprequiredforphysicalcards->errorMessage());
		}
		if ($this->otpvaliduntil->Required) {
			if (!$this->otpvaliduntil->IsDetailKey && $this->otpvaliduntil->FormValue != NULL && $this->otpvaliduntil->FormValue == "") {
				AddMessage($FormError, str_replace("%s", $this->otpvaliduntil->caption(), $this->otpvaliduntil->RequiredErrorMessage));
			}
		}
		if (!CheckDate($this->otpvaliduntil->FormValue)) {
			AddMessage($FormError, $this->otpvaliduntil->errorMessage());
		}
		if ($this->nationalitycountry->Required) {
			if (!$this->nationalitycountry->IsDetailKey && $this->nationalitycountry->FormValue != NULL && $this->nationalitycountry->FormValue == "") {
				AddMessage($FormError, str_replace("%s", $this->nationalitycountry->caption(), $this->nationalitycountry->RequiredErrorMessage));
			}
		}
		if ($this->classification->Required) {
			if (!$this->classification->IsDetailKey && $this->classification->FormValue != NULL && $this->classification->FormValue == "") {
				AddMessage($FormError, str_replace("%s", $this->classification->caption(), $this->classification->RequiredErrorMessage));
			}
		}
		if ($this->occupation->Required) {
			if (!$this->occupation->IsDetailKey && $this->occupation->FormValue != NULL && $this->occupation->FormValue == "") {
				AddMessage($FormError, str_replace("%s", $this->occupation->caption(), $this->occupation->RequiredErrorMessage));
			}
		}
		if ($this->sourceofincome->Required) {
			if (!$this->sourceofincome->IsDetailKey && $this->sourceofincome->FormValue != NULL && $this->sourceofincome->FormValue == "") {
				AddMessage($FormError, str_replace("%s", $this->sourceofincome->caption(), $this->sourceofincome->RequiredErrorMessage));
			}
		}
		if ($this->accountopeningdate->Required) {
			if (!$this->accountopeningdate->IsDetailKey && $this->accountopeningdate->FormValue != NULL && $this->accountopeningdate->FormValue == "") {
				AddMessage($FormError, str_replace("%s", $this->accountopeningdate->caption(), $this->accountopeningdate->RequiredErrorMessage));
			}
		}
		if (!CheckDate($this->accountopeningdate->FormValue)) {
			AddMessage($FormError, $this->accountopeningdate->errorMessage());
		}
		if ($this->extendedfields->Required) {
			if (!$this->extendedfields->IsDetailKey && $this->extendedfields->FormValue != NULL && $this->extendedfields->FormValue == "") {
				AddMessage($FormError, str_replace("%s", $this->extendedfields->caption(), $this->extendedfields->RequiredErrorMessage));
			}
		}
		if ($this->lastprofilestatuschangedate->Required) {
			if (!$this->lastprofilestatuschangedate->IsDetailKey && $this->lastprofilestatuschangedate->FormValue != NULL && $this->lastprofilestatuschangedate->FormValue == "") {
				AddMessage($FormError, str_replace("%s", $this->lastprofilestatuschangedate->caption(), $this->lastprofilestatuschangedate->RequiredErrorMessage));
			}
		}
		if (!CheckDate($this->lastprofilestatuschangedate->FormValue)) {
			AddMessage($FormError, $this->lastprofilestatuschangedate->errorMessage());
		}

		// Validate detail grid
		$detailTblVar = explode(",", $this->getCurrentDetailTable());
		if (in_array("userpasswordhistory", $detailTblVar) && $GLOBALS["userpasswordhistory"]->DetailEdit) {
			if (!isset($GLOBALS["userpasswordhistory_grid"]))
				$GLOBALS["userpasswordhistory_grid"] = new userpasswordhistory_grid(); // Get detail page object
			$GLOBALS["userpasswordhistory_grid"]->validateGridForm();
		}
		if (in_array("userpinhistory", $detailTblVar) && $GLOBALS["userpinhistory"]->DetailEdit) {
			if (!isset($GLOBALS["userpinhistory_grid"]))
				$GLOBALS["userpinhistory_grid"] = new userpinhistory_grid(); // Get detail page object
			$GLOBALS["userpinhistory_grid"]->validateGridForm();
		}
		if (in_array("userchildren", $detailTblVar) && $GLOBALS["userchildren"]->DetailEdit) {
			if (!isset($GLOBALS["userchildren_grid"]))
				$GLOBALS["userchildren_grid"] = new userchildren_grid(); // Get detail page object
			$GLOBALS["userchildren_grid"]->validateGridForm();
		}
		if (in_array("usercontactlist", $detailTblVar) && $GLOBALS["usercontactlist"]->DetailEdit) {
			if (!isset($GLOBALS["usercontactlist_grid"]))
				$GLOBALS["usercontactlist_grid"] = new usercontactlist_grid(); // Get detail page object
			$GLOBALS["usercontactlist_grid"]->validateGridForm();
		}
		if (in_array("securityuserrole", $detailTblVar) && $GLOBALS["securityuserrole"]->DetailEdit) {
			if (!isset($GLOBALS["securityuserrole_grid"]))
				$GLOBALS["securityuserrole_grid"] = new securityuserrole_grid(); // Get detail page object
			$GLOBALS["securityuserrole_grid"]->validateGridForm();
		}
		if (in_array("mailbox", $detailTblVar) && $GLOBALS["mailbox"]->DetailEdit) {
			if (!isset($GLOBALS["mailbox_grid"]))
				$GLOBALS["mailbox_grid"] = new mailbox_grid(); // Get detail page object
			$GLOBALS["mailbox_grid"]->validateGridForm();
		}
		if (in_array("balanceinquiryhistory", $detailTblVar) && $GLOBALS["balanceinquiryhistory"]->DetailEdit) {
			if (!isset($GLOBALS["balanceinquiryhistory_grid"]))
				$GLOBALS["balanceinquiryhistory_grid"] = new balanceinquiryhistory_grid(); // Get detail page object
			$GLOBALS["balanceinquiryhistory_grid"]->validateGridForm();
		}
		if (in_array("usersession", $detailTblVar) && $GLOBALS["usersession"]->DetailEdit) {
			if (!isset($GLOBALS["usersession_grid"]))
				$GLOBALS["usersession_grid"] = new usersession_grid(); // Get detail page object
			$GLOBALS["usersession_grid"]->validateGridForm();
		}
		if (in_array("vtranshistorybyuser", $detailTblVar) && $GLOBALS["vtranshistorybyuser"]->DetailEdit) {
			if (!isset($GLOBALS["vtranshistorybyuser_grid"]))
				$GLOBALS["vtranshistorybyuser_grid"] = new vtranshistorybyuser_grid(); // Get detail page object
			$GLOBALS["vtranshistorybyuser_grid"]->validateGridForm();
		}
		if (in_array("vtranssummary", $detailTblVar) && $GLOBALS["vtranssummary"]->DetailEdit) {
			if (!isset($GLOBALS["vtranssummary_grid"]))
				$GLOBALS["vtranssummary_grid"] = new vtranssummary_grid(); // Get detail page object
			$GLOBALS["vtranssummary_grid"]->validateGridForm();
		}
		if (in_array("useremailaccount", $detailTblVar) && $GLOBALS["useremailaccount"]->DetailEdit) {
			if (!isset($GLOBALS["useremailaccount_grid"]))
				$GLOBALS["useremailaccount_grid"] = new useremailaccount_grid(); // Get detail page object
			$GLOBALS["useremailaccount_grid"]->validateGridForm();
		}
		if (in_array("userpi", $detailTblVar) && $GLOBALS["userpi"]->DetailEdit) {
			if (!isset($GLOBALS["userpi_grid"]))
				$GLOBALS["userpi_grid"] = new userpi_grid(); // Get detail page object
			$GLOBALS["userpi_grid"]->validateGridForm();
		}
		if (in_array("userpurchase", $detailTblVar) && $GLOBALS["userpurchase"]->DetailEdit) {
			if (!isset($GLOBALS["userpurchase_grid"]))
				$GLOBALS["userpurchase_grid"] = new userpurchase_grid(); // Get detail page object
			$GLOBALS["userpurchase_grid"]->validateGridForm();
		}
		if (in_array("loanlimits", $detailTblVar) && $GLOBALS["loanlimits"]->DetailEdit) {
			if (!isset($GLOBALS["loanlimits_grid"]))
				$GLOBALS["loanlimits_grid"] = new loanlimits_grid(); // Get detail page object
			$GLOBALS["loanlimits_grid"]->validateGridForm();
		}
		if (in_array("userkycdocs", $detailTblVar) && $GLOBALS["userkycdocs"]->DetailEdit) {
			if (!isset($GLOBALS["userkycdocs_grid"]))
				$GLOBALS["userkycdocs_grid"] = new userkycdocs_grid(); // Get detail page object
			$GLOBALS["userkycdocs_grid"]->validateGridForm();
		}
		if (in_array("acctbalance", $detailTblVar) && $GLOBALS["acctbalance"]->DetailEdit) {
			if (!isset($GLOBALS["acctbalance_grid"]))
				$GLOBALS["acctbalance_grid"] = new acctbalance_grid(); // Get detail page object
			$GLOBALS["acctbalance_grid"]->validateGridForm();
		}
		if (in_array("userdevices", $detailTblVar) && $GLOBALS["userdevices"]->DetailEdit) {
			if (!isset($GLOBALS["userdevices_grid"]))
				$GLOBALS["userdevices_grid"] = new userdevices_grid(); // Get detail page object
			$GLOBALS["userdevices_grid"]->validateGridForm();
		}
		if (in_array("usercommission", $detailTblVar) && $GLOBALS["usercommission"]->DetailEdit) {
			if (!isset($GLOBALS["usercommission_grid"]))
				$GLOBALS["usercommission_grid"] = new usercommission_grid(); // Get detail page object
			$GLOBALS["usercommission_grid"]->validateGridForm();
		}

		// Return validate result
		$validateForm = ($FormError == "");

		// Call Form_CustomValidate event
		$formCustomError = "";
		$validateForm = $validateForm && $this->Form_CustomValidate($formCustomError);
		if ($formCustomError != "") {
			AddMessage($FormError, $formCustomError);
		}
		return $validateForm;
	}

	// Update record based on key values
	protected function editRow()
	{
		global $Security, $Language;
		$oldKeyFilter = $this->getRecordFilter();
		$filter = $this->applyUserIDFilters($oldKeyFilter);
		$conn = $this->getConnection();
		$this->CurrentFilter = $filter;
		$sql = $this->getCurrentSql();
		$conn->raiseErrorFn = Config("ERROR_FUNC");
		$rs = $conn->execute($sql);
		$conn->raiseErrorFn = "";
		if ($rs === FALSE)
			return FALSE;
		if ($rs->EOF) {
			$this->setFailureMessage($Language->phrase("NoRecord")); // Set no record message
			$editRow = FALSE; // Update Failed
		} else {

			// Begin transaction
			if ($this->getCurrentDetailTable() != "")
				$conn->beginTrans();

			// Save old values
			$rsold = &$rs->fields;
			$this->loadDbValues($rsold);
			$rsnew = [];

			// id
			$this->id->setDbValueDef($rsnew, $this->id->CurrentValue, 0, $this->id->ReadOnly);

			// firstName
			$this->firstName->setDbValueDef($rsnew, $this->firstName->CurrentValue, "", $this->firstName->ReadOnly);

			// lastName
			$this->lastName->setDbValueDef($rsnew, $this->lastName->CurrentValue, "", $this->lastName->ReadOnly);

			// otherNames
			$this->otherNames->setDbValueDef($rsnew, $this->otherNames->CurrentValue, NULL, $this->otherNames->ReadOnly);

			// passwordRequireChange
			$this->passwordRequireChange->setDbValueDef($rsnew, $this->passwordRequireChange->CurrentValue, 0, $this->passwordRequireChange->ReadOnly);

			// franchiseeID
			$this->franchiseeID->setDbValueDef($rsnew, $this->franchiseeID->CurrentValue, 0, $this->franchiseeID->ReadOnly);

			// dateAdded
			$this->dateAdded->setDbValueDef($rsnew, UnFormatDateTime($this->dateAdded->CurrentValue, 1), NULL, $this->dateAdded->ReadOnly);

			// timezoneid
			$this->timezoneid->setDbValueDef($rsnew, $this->timezoneid->CurrentValue, 0, $this->timezoneid->ReadOnly);

			// contactPhoneNo
			$this->contactPhoneNo->setDbValueDef($rsnew, $this->contactPhoneNo->CurrentValue, NULL, $this->contactPhoneNo->ReadOnly);

			// telephoneno
			$this->telephoneno->setDbValueDef($rsnew, $this->telephoneno->CurrentValue, NULL, $this->telephoneno->ReadOnly);

			// telephoneverified
			$this->telephoneverified->setDbValueDef($rsnew, $this->telephoneverified->CurrentValue, 0, $this->telephoneverified->ReadOnly);

			// telephonereceivemessage
			$this->telephonereceivemessage->setDbValueDef($rsnew, $this->telephonereceivemessage->CurrentValue, 0, $this->telephonereceivemessage->ReadOnly);

			// verification1
			$this->verification1->setDbValueDef($rsnew, $this->verification1->CurrentValue, NULL, $this->verification1->ReadOnly);

			// verification2
			$this->verification2->setDbValueDef($rsnew, $this->verification2->CurrentValue, NULL, $this->verification2->ReadOnly);

			// verification3
			$this->verification3->setDbValueDef($rsnew, $this->verification3->CurrentValue, NULL, $this->verification3->ReadOnly);

			// address1
			$this->address1->setDbValueDef($rsnew, $this->address1->CurrentValue, NULL, $this->address1->ReadOnly);

			// address2
			$this->address2->setDbValueDef($rsnew, $this->address2->CurrentValue, NULL, $this->address2->ReadOnly);

			// cityname
			$this->cityname->setDbValueDef($rsnew, $this->cityname->CurrentValue, "", $this->cityname->ReadOnly);

			// countryid
			$this->countryid->setDbValueDef($rsnew, $this->countryid->CurrentValue, "", $this->countryid->ReadOnly);

			// stateid
			$this->stateid->setDbValueDef($rsnew, $this->stateid->CurrentValue, NULL, $this->stateid->ReadOnly);

			// defaultcurrency
			$this->defaultcurrency->setDbValueDef($rsnew, $this->defaultcurrency->CurrentValue, NULL, $this->defaultcurrency->ReadOnly);

			// challengeq1
			$this->challengeq1->setDbValueDef($rsnew, $this->challengeq1->CurrentValue, NULL, $this->challengeq1->ReadOnly);

			// challengea1
			$this->challengea1->setDbValueDef($rsnew, $this->challengea1->CurrentValue, NULL, $this->challengea1->ReadOnly);

			// challengeq2
			$this->challengeq2->setDbValueDef($rsnew, $this->challengeq2->CurrentValue, NULL, $this->challengeq2->ReadOnly);

			// challengea2
			$this->challengea2->setDbValueDef($rsnew, $this->challengea2->CurrentValue, NULL, $this->challengea2->ReadOnly);

			// challengeq3
			$this->challengeq3->setDbValueDef($rsnew, $this->challengeq3->CurrentValue, NULL, $this->challengeq3->ReadOnly);

			// challengea3
			$this->challengea3->setDbValueDef($rsnew, $this->challengea3->CurrentValue, NULL, $this->challengea3->ReadOnly);

			// passwordCounter
			$this->passwordCounter->setDbValueDef($rsnew, $this->passwordCounter->CurrentValue, 0, $this->passwordCounter->ReadOnly);

			// passwordChangedDate
			$this->passwordChangedDate->setDbValueDef($rsnew, UnFormatDateTime($this->passwordChangedDate->CurrentValue, 1), CurrentDate(), $this->passwordChangedDate->ReadOnly);

			// pinCounter
			$this->pinCounter->setDbValueDef($rsnew, $this->pinCounter->CurrentValue, 0, $this->pinCounter->ReadOnly);

			// langID
			$this->langID->setDbValueDef($rsnew, $this->langID->CurrentValue, "", $this->langID->ReadOnly);

			// photo
			if ($this->photo->Visible && !$this->photo->ReadOnly && !$this->photo->Upload->KeepFile) {
				$this->photo->Upload->DbValue = $rsold['photo']; // Get original value
				if ($this->photo->Upload->FileName == "") {
					$rsnew['photo'] = NULL;
				} else {
					$rsnew['photo'] = $this->photo->Upload->FileName;
				}
			}

			// status
			$this->status->setDbValueDef($rsnew, $this->status->CurrentValue, 0, $this->status->ReadOnly);

			// markedfordeletion
			$this->markedfordeletion->setDbValueDef($rsnew, UnFormatDateTime($this->markedfordeletion->CurrentValue, 0), NULL, $this->markedfordeletion->ReadOnly);

			// userType
			$this->userType->setDbValueDef($rsnew, $this->userType->CurrentValue, 0, $this->userType->ReadOnly);

			// usersubtype
			$this->usersubtype->setDbValueDef($rsnew, $this->usersubtype->CurrentValue, 0, $this->usersubtype->ReadOnly);

			// accountID
			$this->accountID->setDbValueDef($rsnew, $this->accountID->CurrentValue, 0, $this->accountID->ReadOnly);

			// brokerid
			$this->brokerid->setDbValueDef($rsnew, $this->brokerid->CurrentValue, 0, $this->brokerid->ReadOnly);

			// parentuserid
			$this->parentuserid->setDbValueDef($rsnew, $this->parentuserid->CurrentValue, NULL, $this->parentuserid->ReadOnly);

			// corporate
			$this->corporate->setDbValueDef($rsnew, $this->corporate->CurrentValue, 0, $this->corporate->ReadOnly);

			// profilestatus
			$this->profilestatus->setDbValueDef($rsnew, $this->profilestatus->CurrentValue, 0, $this->profilestatus->ReadOnly);

			// jumpappid
			$this->jumpappid->setDbValueDef($rsnew, $this->jumpappid->CurrentValue, NULL, $this->jumpappid->ReadOnly);

			// dateofbirth
			$this->dateofbirth->setDbValueDef($rsnew, UnFormatDateTime($this->dateofbirth->CurrentValue, 2), NULL, $this->dateofbirth->ReadOnly);

			// gender
			$this->gender->setDbValueDef($rsnew, $this->gender->CurrentValue, 0, $this->gender->ReadOnly);

			// lastupdatedate
			$this->lastupdatedate->setDbValueDef($rsnew, UnFormatDateTime($this->lastupdatedate->CurrentValue, 1), NULL, $this->lastupdatedate->ReadOnly);

			// jumprequiredatlogin
			$this->jumprequiredatlogin->setDbValueDef($rsnew, $this->jumprequiredatlogin->CurrentValue, 0, $this->jumprequiredatlogin->ReadOnly);

			// ccbypass
			$this->ccbypass->setDbValueDef($rsnew, $this->ccbypass->CurrentValue, 0, $this->ccbypass->ReadOnly);

			// zip
			$this->zip->setDbValueDef($rsnew, $this->zip->CurrentValue, NULL, $this->zip->ReadOnly);

			// other1
			$this->other1->setDbValueDef($rsnew, $this->other1->CurrentValue, NULL, $this->other1->ReadOnly);

			// other2
			$this->other2->setDbValueDef($rsnew, $this->other2->CurrentValue, NULL, $this->other2->ReadOnly);

			// other3
			$this->other3->setDbValueDef($rsnew, $this->other3->CurrentValue, NULL, $this->other3->ReadOnly);

			// other4
			$this->other4->setDbValueDef($rsnew, $this->other4->CurrentValue, NULL, $this->other4->ReadOnly);

			// other5
			$this->other5->setDbValueDef($rsnew, $this->other5->CurrentValue, NULL, $this->other5->ReadOnly);

			// other6
			$this->other6->setDbValueDef($rsnew, $this->other6->CurrentValue, NULL, $this->other6->ReadOnly);

			// mincashamount
			$this->mincashamount->setDbValueDef($rsnew, $this->mincashamount->CurrentValue, 0, $this->mincashamount->ReadOnly);

			// maxcashamount
			$this->maxcashamount->setDbValueDef($rsnew, $this->maxcashamount->CurrentValue, 0, $this->maxcashamount->ReadOnly);

			// maxtransferinamount
			$this->maxtransferinamount->setDbValueDef($rsnew, $this->maxtransferinamount->CurrentValue, 0, $this->maxtransferinamount->ReadOnly);

			// maxtransferoutamount
			$this->maxtransferoutamount->setDbValueDef($rsnew, $this->maxtransferoutamount->CurrentValue, 0, $this->maxtransferoutamount->ReadOnly);

			// legalid
			$this->legalid->setDbValueDef($rsnew, $this->legalid->CurrentValue, NULL, $this->legalid->ReadOnly);

			// userpiview
			$this->userpiview->setDbValueDef($rsnew, $this->userpiview->CurrentValue, NULL, $this->userpiview->ReadOnly);

			// lastmsgid
			$this->lastmsgid->setDbValueDef($rsnew, $this->lastmsgid->CurrentValue, 0, $this->lastmsgid->ReadOnly);

			// otprequiredforphysicalcards
			$this->otprequiredforphysicalcards->setDbValueDef($rsnew, $this->otprequiredforphysicalcards->CurrentValue, 0, $this->otprequiredforphysicalcards->ReadOnly);

			// otpvaliduntil
			$this->otpvaliduntil->setDbValueDef($rsnew, UnFormatDateTime($this->otpvaliduntil->CurrentValue, 0), NULL, $this->otpvaliduntil->ReadOnly);

			// nationalitycountry
			$this->nationalitycountry->setDbValueDef($rsnew, $this->nationalitycountry->CurrentValue, NULL, $this->nationalitycountry->ReadOnly);

			// classification
			$this->classification->setDbValueDef($rsnew, $this->classification->CurrentValue, NULL, $this->classification->ReadOnly);

			// occupation
			$this->occupation->setDbValueDef($rsnew, $this->occupation->CurrentValue, NULL, $this->occupation->ReadOnly);

			// sourceofincome
			$this->sourceofincome->setDbValueDef($rsnew, $this->sourceofincome->CurrentValue, NULL, $this->sourceofincome->ReadOnly);

			// accountopeningdate
			$this->accountopeningdate->setDbValueDef($rsnew, UnFormatDateTime($this->accountopeningdate->CurrentValue, 0), NULL, $this->accountopeningdate->ReadOnly);

			// extendedfields
			$this->extendedfields->setDbValueDef($rsnew, $this->extendedfields->CurrentValue, NULL, $this->extendedfields->ReadOnly);

			// lastprofilestatuschangedate
			$this->lastprofilestatuschangedate->setDbValueDef($rsnew, UnFormatDateTime($this->lastprofilestatuschangedate->CurrentValue, 0), NULL, $this->lastprofilestatuschangedate->ReadOnly);
			if ($this->photo->Visible && !$this->photo->Upload->KeepFile) {
				$oldFiles = EmptyValue($this->photo->Upload->DbValue) ? [] : [$this->photo->htmlDecode($this->photo->Upload->DbValue)];
				if (!EmptyValue($this->photo->Upload->FileName)) {
					$newFiles = [$this->photo->Upload->FileName];
					$NewFileCount = count($newFiles);
					for ($i = 0; $i < $NewFileCount; $i++) {
						if ($newFiles[$i] != "") {
							$file = $newFiles[$i];
							$tempPath = UploadTempPath($this->photo, $this->photo->Upload->Index);
							if (file_exists($tempPath . $file)) {
								if (Config("DELETE_UPLOADED_FILES")) {
									$oldFileFound = FALSE;
									$oldFileCount = count($oldFiles);
									for ($j = 0; $j < $oldFileCount; $j++) {
										$oldFile = $oldFiles[$j];
										if ($oldFile == $file) { // Old file found, no need to delete anymore
											array_splice($oldFiles, $j, 1);
											$oldFileFound = TRUE;
											break;
										}
									}
									if ($oldFileFound) // No need to check if file exists further
										continue;
								}
								$file1 = UniqueFilename($this->photo->physicalUploadPath(), $file); // Get new file name
								if ($file1 != $file) { // Rename temp file
									while (file_exists($tempPath . $file1) || file_exists($this->photo->physicalUploadPath() . $file1)) // Make sure no file name clash
										$file1 = UniqueFilename($this->photo->physicalUploadPath(), $file1, TRUE); // Use indexed name
									rename($tempPath . $file, $tempPath . $file1);
									$newFiles[$i] = $file1;
								}
							}
						}
					}
					$this->photo->Upload->DbValue = empty($oldFiles) ? "" : implode(Config("MULTIPLE_UPLOAD_SEPARATOR"), $oldFiles);
					$this->photo->Upload->FileName = implode(Config("MULTIPLE_UPLOAD_SEPARATOR"), $newFiles);
					$this->photo->setDbValueDef($rsnew, $this->photo->Upload->FileName, NULL, $this->photo->ReadOnly);
				}
			}

			// Call Row Updating event
			$updateRow = $this->Row_Updating($rsold, $rsnew);

			// Check for duplicate key when key changed
			if ($updateRow) {
				$newKeyFilter = $this->getRecordFilter($rsnew);
				if ($newKeyFilter != $oldKeyFilter) {
					$rsChk = $this->loadRs($newKeyFilter);
					if ($rsChk && !$rsChk->EOF) {
						$keyErrMsg = str_replace("%f", $newKeyFilter, $Language->phrase("DupKey"));
						$this->setFailureMessage($keyErrMsg);
						$rsChk->close();
						$updateRow = FALSE;
					}
				}
			}
			if ($updateRow) {
				$conn->raiseErrorFn = Config("ERROR_FUNC");
				if (count($rsnew) > 0)
					$editRow = $this->update($rsnew, "", $rsold);
				else
					$editRow = TRUE; // No field to update
				$conn->raiseErrorFn = "";
				if ($editRow) {
					if ($this->photo->Visible && !$this->photo->Upload->KeepFile) {
						$oldFiles = EmptyValue($this->photo->Upload->DbValue) ? [] : [$this->photo->htmlDecode($this->photo->Upload->DbValue)];
						if (!EmptyValue($this->photo->Upload->FileName)) {
							$newFiles = [$this->photo->Upload->FileName];
							$newFiles2 = [$this->photo->htmlDecode($rsnew['photo'])];
							$newFileCount = count($newFiles);
							for ($i = 0; $i < $newFileCount; $i++) {
								if ($newFiles[$i] != "") {
									$file = UploadTempPath($this->photo, $this->photo->Upload->Index) . $newFiles[$i];
									if (file_exists($file)) {
										if (@$newFiles2[$i] != "") // Use correct file name
											$newFiles[$i] = $newFiles2[$i];
										if (!$this->photo->Upload->SaveToFile($newFiles[$i], TRUE, $i)) { // Just replace
											$this->setFailureMessage($Language->phrase("UploadErrMsg7"));
											return FALSE;
										}
									}
								}
							}
						} else {
							$newFiles = [];
						}
						if (Config("DELETE_UPLOADED_FILES")) {
							foreach ($oldFiles as $oldFile) {
								if ($oldFile != "" && !in_array($oldFile, $newFiles))
									@unlink($this->photo->oldPhysicalUploadPath() . $oldFile);
							}
						}
					}
				}

				// Update detail records
				$detailTblVar = explode(",", $this->getCurrentDetailTable());
				if ($editRow) {
					if (in_array("userpasswordhistory", $detailTblVar) && $GLOBALS["userpasswordhistory"]->DetailEdit) {
						if (!isset($GLOBALS["userpasswordhistory_grid"]))
							$GLOBALS["userpasswordhistory_grid"] = new userpasswordhistory_grid(); // Get detail page object
						$Security->loadCurrentUserLevel($this->ProjectID . "userpasswordhistory"); // Load user level of detail table
						$editRow = $GLOBALS["userpasswordhistory_grid"]->gridUpdate();
						$Security->loadCurrentUserLevel($this->ProjectID . $this->TableName); // Restore user level of master table
					}
				}
				if ($editRow) {
					if (in_array("userpinhistory", $detailTblVar) && $GLOBALS["userpinhistory"]->DetailEdit) {
						if (!isset($GLOBALS["userpinhistory_grid"]))
							$GLOBALS["userpinhistory_grid"] = new userpinhistory_grid(); // Get detail page object
						$Security->loadCurrentUserLevel($this->ProjectID . "userpinhistory"); // Load user level of detail table
						$editRow = $GLOBALS["userpinhistory_grid"]->gridUpdate();
						$Security->loadCurrentUserLevel($this->ProjectID . $this->TableName); // Restore user level of master table
					}
				}
				if ($editRow) {
					if (in_array("userchildren", $detailTblVar) && $GLOBALS["userchildren"]->DetailEdit) {
						if (!isset($GLOBALS["userchildren_grid"]))
							$GLOBALS["userchildren_grid"] = new userchildren_grid(); // Get detail page object
						$Security->loadCurrentUserLevel($this->ProjectID . "userchildren"); // Load user level of detail table
						$editRow = $GLOBALS["userchildren_grid"]->gridUpdate();
						$Security->loadCurrentUserLevel($this->ProjectID . $this->TableName); // Restore user level of master table
					}
				}
				if ($editRow) {
					if (in_array("usercontactlist", $detailTblVar) && $GLOBALS["usercontactlist"]->DetailEdit) {
						if (!isset($GLOBALS["usercontactlist_grid"]))
							$GLOBALS["usercontactlist_grid"] = new usercontactlist_grid(); // Get detail page object
						$Security->loadCurrentUserLevel($this->ProjectID . "usercontactlist"); // Load user level of detail table
						$editRow = $GLOBALS["usercontactlist_grid"]->gridUpdate();
						$Security->loadCurrentUserLevel($this->ProjectID . $this->TableName); // Restore user level of master table
					}
				}
				if ($editRow) {
					if (in_array("securityuserrole", $detailTblVar) && $GLOBALS["securityuserrole"]->DetailEdit) {
						if (!isset($GLOBALS["securityuserrole_grid"]))
							$GLOBALS["securityuserrole_grid"] = new securityuserrole_grid(); // Get detail page object
						$Security->loadCurrentUserLevel($this->ProjectID . "securityuserrole"); // Load user level of detail table
						$editRow = $GLOBALS["securityuserrole_grid"]->gridUpdate();
						$Security->loadCurrentUserLevel($this->ProjectID . $this->TableName); // Restore user level of master table
					}
				}
				if ($editRow) {
					if (in_array("mailbox", $detailTblVar) && $GLOBALS["mailbox"]->DetailEdit) {
						if (!isset($GLOBALS["mailbox_grid"]))
							$GLOBALS["mailbox_grid"] = new mailbox_grid(); // Get detail page object
						$Security->loadCurrentUserLevel($this->ProjectID . "mailbox"); // Load user level of detail table
						$editRow = $GLOBALS["mailbox_grid"]->gridUpdate();
						$Security->loadCurrentUserLevel($this->ProjectID . $this->TableName); // Restore user level of master table
					}
				}
				if ($editRow) {
					if (in_array("balanceinquiryhistory", $detailTblVar) && $GLOBALS["balanceinquiryhistory"]->DetailEdit) {
						if (!isset($GLOBALS["balanceinquiryhistory_grid"]))
							$GLOBALS["balanceinquiryhistory_grid"] = new balanceinquiryhistory_grid(); // Get detail page object
						$Security->loadCurrentUserLevel($this->ProjectID . "balanceinquiryhistory"); // Load user level of detail table
						$editRow = $GLOBALS["balanceinquiryhistory_grid"]->gridUpdate();
						$Security->loadCurrentUserLevel($this->ProjectID . $this->TableName); // Restore user level of master table
					}
				}
				if ($editRow) {
					if (in_array("usersession", $detailTblVar) && $GLOBALS["usersession"]->DetailEdit) {
						if (!isset($GLOBALS["usersession_grid"]))
							$GLOBALS["usersession_grid"] = new usersession_grid(); // Get detail page object
						$Security->loadCurrentUserLevel($this->ProjectID . "usersession"); // Load user level of detail table
						$editRow = $GLOBALS["usersession_grid"]->gridUpdate();
						$Security->loadCurrentUserLevel($this->ProjectID . $this->TableName); // Restore user level of master table
					}
				}
				if ($editRow) {
					if (in_array("vtranshistorybyuser", $detailTblVar) && $GLOBALS["vtranshistorybyuser"]->DetailEdit) {
						if (!isset($GLOBALS["vtranshistorybyuser_grid"]))
							$GLOBALS["vtranshistorybyuser_grid"] = new vtranshistorybyuser_grid(); // Get detail page object
						$Security->loadCurrentUserLevel($this->ProjectID . "vtranshistorybyuser"); // Load user level of detail table
						$editRow = $GLOBALS["vtranshistorybyuser_grid"]->gridUpdate();
						$Security->loadCurrentUserLevel($this->ProjectID . $this->TableName); // Restore user level of master table
					}
				}
				if ($editRow) {
					if (in_array("vtranssummary", $detailTblVar) && $GLOBALS["vtranssummary"]->DetailEdit) {
						if (!isset($GLOBALS["vtranssummary_grid"]))
							$GLOBALS["vtranssummary_grid"] = new vtranssummary_grid(); // Get detail page object
						$Security->loadCurrentUserLevel($this->ProjectID . "vtranssummary"); // Load user level of detail table
						$editRow = $GLOBALS["vtranssummary_grid"]->gridUpdate();
						$Security->loadCurrentUserLevel($this->ProjectID . $this->TableName); // Restore user level of master table
					}
				}
				if ($editRow) {
					if (in_array("useremailaccount", $detailTblVar) && $GLOBALS["useremailaccount"]->DetailEdit) {
						if (!isset($GLOBALS["useremailaccount_grid"]))
							$GLOBALS["useremailaccount_grid"] = new useremailaccount_grid(); // Get detail page object
						$Security->loadCurrentUserLevel($this->ProjectID . "useremailaccount"); // Load user level of detail table
						$editRow = $GLOBALS["useremailaccount_grid"]->gridUpdate();
						$Security->loadCurrentUserLevel($this->ProjectID . $this->TableName); // Restore user level of master table
					}
				}
				if ($editRow) {
					if (in_array("userpi", $detailTblVar) && $GLOBALS["userpi"]->DetailEdit) {
						if (!isset($GLOBALS["userpi_grid"]))
							$GLOBALS["userpi_grid"] = new userpi_grid(); // Get detail page object
						$Security->loadCurrentUserLevel($this->ProjectID . "userpi"); // Load user level of detail table
						$editRow = $GLOBALS["userpi_grid"]->gridUpdate();
						$Security->loadCurrentUserLevel($this->ProjectID . $this->TableName); // Restore user level of master table
					}
				}
				if ($editRow) {
					if (in_array("userpurchase", $detailTblVar) && $GLOBALS["userpurchase"]->DetailEdit) {
						if (!isset($GLOBALS["userpurchase_grid"]))
							$GLOBALS["userpurchase_grid"] = new userpurchase_grid(); // Get detail page object
						$Security->loadCurrentUserLevel($this->ProjectID . "userpurchase"); // Load user level of detail table
						$editRow = $GLOBALS["userpurchase_grid"]->gridUpdate();
						$Security->loadCurrentUserLevel($this->ProjectID . $this->TableName); // Restore user level of master table
					}
				}
				if ($editRow) {
					if (in_array("loanlimits", $detailTblVar) && $GLOBALS["loanlimits"]->DetailEdit) {
						if (!isset($GLOBALS["loanlimits_grid"]))
							$GLOBALS["loanlimits_grid"] = new loanlimits_grid(); // Get detail page object
						$Security->loadCurrentUserLevel($this->ProjectID . "loanlimits"); // Load user level of detail table
						$editRow = $GLOBALS["loanlimits_grid"]->gridUpdate();
						$Security->loadCurrentUserLevel($this->ProjectID . $this->TableName); // Restore user level of master table
					}
				}
				if ($editRow) {
					if (in_array("userkycdocs", $detailTblVar) && $GLOBALS["userkycdocs"]->DetailEdit) {
						if (!isset($GLOBALS["userkycdocs_grid"]))
							$GLOBALS["userkycdocs_grid"] = new userkycdocs_grid(); // Get detail page object
						$Security->loadCurrentUserLevel($this->ProjectID . "userkycdocs"); // Load user level of detail table
						$editRow = $GLOBALS["userkycdocs_grid"]->gridUpdate();
						$Security->loadCurrentUserLevel($this->ProjectID . $this->TableName); // Restore user level of master table
					}
				}
				if ($editRow) {
					if (in_array("acctbalance", $detailTblVar) && $GLOBALS["acctbalance"]->DetailEdit) {
						if (!isset($GLOBALS["acctbalance_grid"]))
							$GLOBALS["acctbalance_grid"] = new acctbalance_grid(); // Get detail page object
						$Security->loadCurrentUserLevel($this->ProjectID . "acctbalance"); // Load user level of detail table
						$editRow = $GLOBALS["acctbalance_grid"]->gridUpdate();
						$Security->loadCurrentUserLevel($this->ProjectID . $this->TableName); // Restore user level of master table
					}
				}
				if ($editRow) {
					if (in_array("userdevices", $detailTblVar) && $GLOBALS["userdevices"]->DetailEdit) {
						if (!isset($GLOBALS["userdevices_grid"]))
							$GLOBALS["userdevices_grid"] = new userdevices_grid(); // Get detail page object
						$Security->loadCurrentUserLevel($this->ProjectID . "userdevices"); // Load user level of detail table
						$editRow = $GLOBALS["userdevices_grid"]->gridUpdate();
						$Security->loadCurrentUserLevel($this->ProjectID . $this->TableName); // Restore user level of master table
					}
				}
				if ($editRow) {
					if (in_array("usercommission", $detailTblVar) && $GLOBALS["usercommission"]->DetailEdit) {
						if (!isset($GLOBALS["usercommission_grid"]))
							$GLOBALS["usercommission_grid"] = new usercommission_grid(); // Get detail page object
						$Security->loadCurrentUserLevel($this->ProjectID . "usercommission"); // Load user level of detail table
						$editRow = $GLOBALS["usercommission_grid"]->gridUpdate();
						$Security->loadCurrentUserLevel($this->ProjectID . $this->TableName); // Restore user level of master table
					}
				}

				// Commit/Rollback transaction
				if ($this->getCurrentDetailTable() != "") {
					if ($editRow) {
						$conn->commitTrans(); // Commit transaction
					} else {
						$conn->rollbackTrans(); // Rollback transaction
					}
				}
			} else {
				if ($this->getSuccessMessage() != "" || $this->getFailureMessage() != "") {

					// Use the message, do nothing
				} elseif ($this->CancelMessage != "") {
					$this->setFailureMessage($this->CancelMessage);
					$this->CancelMessage = "";
				} else {
					$this->setFailureMessage($Language->phrase("UpdateCancelled"));
				}
				$editRow = FALSE;
			}
		}

		// Call Row_Updated event
		if ($editRow)
			$this->Row_Updated($rsold, $rsnew);
		if ($editRow) {
			if ($this->SendEmail)
				$this->sendEmailOnEdit($rsold, $rsnew);
		}
		$rs->close();

		// Clean upload path if any
		if ($editRow) {

			// photo
			CleanUploadTempPath($this->photo, $this->photo->Upload->Index);
		}

		// Write JSON for API request
		if (IsApi() && $editRow) {
			$row = $this->getRecordsFromRecordset([$rsnew], TRUE);
			WriteJson(["success" => TRUE, $this->TableVar => $row]);
		}
		return $editRow;
	}

	// Set up detail parms based on QueryString
	protected function setupDetailParms()
	{

		// Get the keys for master table
		$detailTblVar = Get(Config("TABLE_SHOW_DETAIL"));
		if ($detailTblVar !== NULL) {
			$this->setCurrentDetailTable($detailTblVar);
		} else {
			$detailTblVar = $this->getCurrentDetailTable();
		}
		if ($detailTblVar != "") {
			$detailTblVar = explode(",", $detailTblVar);
			if (in_array("userpasswordhistory", $detailTblVar)) {
				if (!isset($GLOBALS["userpasswordhistory_grid"]))
					$GLOBALS["userpasswordhistory_grid"] = new userpasswordhistory_grid();
				if ($GLOBALS["userpasswordhistory_grid"]->DetailEdit) {
					$GLOBALS["userpasswordhistory_grid"]->CurrentMode = "edit";
					$GLOBALS["userpasswordhistory_grid"]->CurrentAction = "gridedit";

					// Save current master table to detail table
					$GLOBALS["userpasswordhistory_grid"]->setCurrentMasterTable($this->TableVar);
					$GLOBALS["userpasswordhistory_grid"]->setStartRecordNumber(1);
					$GLOBALS["userpasswordhistory_grid"]->_userID->IsDetailKey = TRUE;
					$GLOBALS["userpasswordhistory_grid"]->_userID->CurrentValue = $this->id->CurrentValue;
					$GLOBALS["userpasswordhistory_grid"]->_userID->setSessionValue($GLOBALS["userpasswordhistory_grid"]->_userID->CurrentValue);
				}
			}
			if (in_array("userpinhistory", $detailTblVar)) {
				if (!isset($GLOBALS["userpinhistory_grid"]))
					$GLOBALS["userpinhistory_grid"] = new userpinhistory_grid();
				if ($GLOBALS["userpinhistory_grid"]->DetailEdit) {
					$GLOBALS["userpinhistory_grid"]->CurrentMode = "edit";
					$GLOBALS["userpinhistory_grid"]->CurrentAction = "gridedit";

					// Save current master table to detail table
					$GLOBALS["userpinhistory_grid"]->setCurrentMasterTable($this->TableVar);
					$GLOBALS["userpinhistory_grid"]->setStartRecordNumber(1);
					$GLOBALS["userpinhistory_grid"]->_userID->IsDetailKey = TRUE;
					$GLOBALS["userpinhistory_grid"]->_userID->CurrentValue = $this->id->CurrentValue;
					$GLOBALS["userpinhistory_grid"]->_userID->setSessionValue($GLOBALS["userpinhistory_grid"]->_userID->CurrentValue);
				}
			}
			if (in_array("userchildren", $detailTblVar)) {
				if (!isset($GLOBALS["userchildren_grid"]))
					$GLOBALS["userchildren_grid"] = new userchildren_grid();
				if ($GLOBALS["userchildren_grid"]->DetailEdit) {
					$GLOBALS["userchildren_grid"]->CurrentMode = "edit";
					$GLOBALS["userchildren_grid"]->CurrentAction = "gridedit";

					// Save current master table to detail table
					$GLOBALS["userchildren_grid"]->setCurrentMasterTable($this->TableVar);
					$GLOBALS["userchildren_grid"]->setStartRecordNumber(1);
					$GLOBALS["userchildren_grid"]->parentUserID->IsDetailKey = TRUE;
					$GLOBALS["userchildren_grid"]->parentUserID->CurrentValue = $this->id->CurrentValue;
					$GLOBALS["userchildren_grid"]->parentUserID->setSessionValue($GLOBALS["userchildren_grid"]->parentUserID->CurrentValue);
				}
			}
			if (in_array("usercontactlist", $detailTblVar)) {
				if (!isset($GLOBALS["usercontactlist_grid"]))
					$GLOBALS["usercontactlist_grid"] = new usercontactlist_grid();
				if ($GLOBALS["usercontactlist_grid"]->DetailEdit) {
					$GLOBALS["usercontactlist_grid"]->CurrentMode = "edit";
					$GLOBALS["usercontactlist_grid"]->CurrentAction = "gridedit";

					// Save current master table to detail table
					$GLOBALS["usercontactlist_grid"]->setCurrentMasterTable($this->TableVar);
					$GLOBALS["usercontactlist_grid"]->setStartRecordNumber(1);
					$GLOBALS["usercontactlist_grid"]->_userid->IsDetailKey = TRUE;
					$GLOBALS["usercontactlist_grid"]->_userid->CurrentValue = $this->id->CurrentValue;
					$GLOBALS["usercontactlist_grid"]->_userid->setSessionValue($GLOBALS["usercontactlist_grid"]->_userid->CurrentValue);
				}
			}
			if (in_array("securityuserrole", $detailTblVar)) {
				if (!isset($GLOBALS["securityuserrole_grid"]))
					$GLOBALS["securityuserrole_grid"] = new securityuserrole_grid();
				if ($GLOBALS["securityuserrole_grid"]->DetailEdit) {
					$GLOBALS["securityuserrole_grid"]->CurrentMode = "edit";
					$GLOBALS["securityuserrole_grid"]->CurrentAction = "gridedit";

					// Save current master table to detail table
					$GLOBALS["securityuserrole_grid"]->setCurrentMasterTable($this->TableVar);
					$GLOBALS["securityuserrole_grid"]->setStartRecordNumber(1);
					$GLOBALS["securityuserrole_grid"]->_userid->IsDetailKey = TRUE;
					$GLOBALS["securityuserrole_grid"]->_userid->CurrentValue = $this->id->CurrentValue;
					$GLOBALS["securityuserrole_grid"]->_userid->setSessionValue($GLOBALS["securityuserrole_grid"]->_userid->CurrentValue);
				}
			}
			if (in_array("mailbox", $detailTblVar)) {
				if (!isset($GLOBALS["mailbox_grid"]))
					$GLOBALS["mailbox_grid"] = new mailbox_grid();
				if ($GLOBALS["mailbox_grid"]->DetailEdit) {
					$GLOBALS["mailbox_grid"]->CurrentMode = "edit";
					$GLOBALS["mailbox_grid"]->CurrentAction = "gridedit";

					// Save current master table to detail table
					$GLOBALS["mailbox_grid"]->setCurrentMasterTable($this->TableVar);
					$GLOBALS["mailbox_grid"]->setStartRecordNumber(1);
					$GLOBALS["mailbox_grid"]->_userid->IsDetailKey = TRUE;
					$GLOBALS["mailbox_grid"]->_userid->CurrentValue = $this->id->CurrentValue;
					$GLOBALS["mailbox_grid"]->_userid->setSessionValue($GLOBALS["mailbox_grid"]->_userid->CurrentValue);
				}
			}
			if (in_array("balanceinquiryhistory", $detailTblVar)) {
				if (!isset($GLOBALS["balanceinquiryhistory_grid"]))
					$GLOBALS["balanceinquiryhistory_grid"] = new balanceinquiryhistory_grid();
				if ($GLOBALS["balanceinquiryhistory_grid"]->DetailEdit) {
					$GLOBALS["balanceinquiryhistory_grid"]->CurrentMode = "edit";
					$GLOBALS["balanceinquiryhistory_grid"]->CurrentAction = "gridedit";

					// Save current master table to detail table
					$GLOBALS["balanceinquiryhistory_grid"]->setCurrentMasterTable($this->TableVar);
					$GLOBALS["balanceinquiryhistory_grid"]->setStartRecordNumber(1);
					$GLOBALS["balanceinquiryhistory_grid"]->_userid->IsDetailKey = TRUE;
					$GLOBALS["balanceinquiryhistory_grid"]->_userid->CurrentValue = $this->id->CurrentValue;
					$GLOBALS["balanceinquiryhistory_grid"]->_userid->setSessionValue($GLOBALS["balanceinquiryhistory_grid"]->_userid->CurrentValue);
				}
			}
			if (in_array("usersession", $detailTblVar)) {
				if (!isset($GLOBALS["usersession_grid"]))
					$GLOBALS["usersession_grid"] = new usersession_grid();
				if ($GLOBALS["usersession_grid"]->DetailEdit) {
					$GLOBALS["usersession_grid"]->CurrentMode = "edit";
					$GLOBALS["usersession_grid"]->CurrentAction = "gridedit";

					// Save current master table to detail table
					$GLOBALS["usersession_grid"]->setCurrentMasterTable($this->TableVar);
					$GLOBALS["usersession_grid"]->setStartRecordNumber(1);
					$GLOBALS["usersession_grid"]->_userid->IsDetailKey = TRUE;
					$GLOBALS["usersession_grid"]->_userid->CurrentValue = $this->id->CurrentValue;
					$GLOBALS["usersession_grid"]->_userid->setSessionValue($GLOBALS["usersession_grid"]->_userid->CurrentValue);
				}
			}
			if (in_array("vtranshistorybyuser", $detailTblVar)) {
				if (!isset($GLOBALS["vtranshistorybyuser_grid"]))
					$GLOBALS["vtranshistorybyuser_grid"] = new vtranshistorybyuser_grid();
				if ($GLOBALS["vtranshistorybyuser_grid"]->DetailEdit) {
					$GLOBALS["vtranshistorybyuser_grid"]->CurrentMode = "edit";
					$GLOBALS["vtranshistorybyuser_grid"]->CurrentAction = "gridedit";

					// Save current master table to detail table
					$GLOBALS["vtranshistorybyuser_grid"]->setCurrentMasterTable($this->TableVar);
					$GLOBALS["vtranshistorybyuser_grid"]->setStartRecordNumber(1);
					$GLOBALS["vtranshistorybyuser_grid"]->filterusrid->IsDetailKey = TRUE;
					$GLOBALS["vtranshistorybyuser_grid"]->filterusrid->CurrentValue = $this->id->CurrentValue;
					$GLOBALS["vtranshistorybyuser_grid"]->filterusrid->setSessionValue($GLOBALS["vtranshistorybyuser_grid"]->filterusrid->CurrentValue);
				}
			}
			if (in_array("vtranssummary", $detailTblVar)) {
				if (!isset($GLOBALS["vtranssummary_grid"]))
					$GLOBALS["vtranssummary_grid"] = new vtranssummary_grid();
				if ($GLOBALS["vtranssummary_grid"]->DetailEdit) {
					$GLOBALS["vtranssummary_grid"]->CurrentMode = "edit";
					$GLOBALS["vtranssummary_grid"]->CurrentAction = "gridedit";

					// Save current master table to detail table
					$GLOBALS["vtranssummary_grid"]->setCurrentMasterTable($this->TableVar);
					$GLOBALS["vtranssummary_grid"]->setStartRecordNumber(1);
					$GLOBALS["vtranssummary_grid"]->_userid->IsDetailKey = TRUE;
					$GLOBALS["vtranssummary_grid"]->_userid->CurrentValue = $this->id->CurrentValue;
					$GLOBALS["vtranssummary_grid"]->_userid->setSessionValue($GLOBALS["vtranssummary_grid"]->_userid->CurrentValue);
				}
			}
			if (in_array("useremailaccount", $detailTblVar)) {
				if (!isset($GLOBALS["useremailaccount_grid"]))
					$GLOBALS["useremailaccount_grid"] = new useremailaccount_grid();
				if ($GLOBALS["useremailaccount_grid"]->DetailEdit) {
					$GLOBALS["useremailaccount_grid"]->CurrentMode = "edit";
					$GLOBALS["useremailaccount_grid"]->CurrentAction = "gridedit";

					// Save current master table to detail table
					$GLOBALS["useremailaccount_grid"]->setCurrentMasterTable($this->TableVar);
					$GLOBALS["useremailaccount_grid"]->setStartRecordNumber(1);
					$GLOBALS["useremailaccount_grid"]->_userID->IsDetailKey = TRUE;
					$GLOBALS["useremailaccount_grid"]->_userID->CurrentValue = $this->id->CurrentValue;
					$GLOBALS["useremailaccount_grid"]->_userID->setSessionValue($GLOBALS["useremailaccount_grid"]->_userID->CurrentValue);
				}
			}
			if (in_array("userpi", $detailTblVar)) {
				if (!isset($GLOBALS["userpi_grid"]))
					$GLOBALS["userpi_grid"] = new userpi_grid();
				if ($GLOBALS["userpi_grid"]->DetailEdit) {
					$GLOBALS["userpi_grid"]->CurrentMode = "edit";
					$GLOBALS["userpi_grid"]->CurrentAction = "gridedit";

					// Save current master table to detail table
					$GLOBALS["userpi_grid"]->setCurrentMasterTable($this->TableVar);
					$GLOBALS["userpi_grid"]->setStartRecordNumber(1);
					$GLOBALS["userpi_grid"]->_userid->IsDetailKey = TRUE;
					$GLOBALS["userpi_grid"]->_userid->CurrentValue = $this->id->CurrentValue;
					$GLOBALS["userpi_grid"]->_userid->setSessionValue($GLOBALS["userpi_grid"]->_userid->CurrentValue);
				}
			}
			if (in_array("userpurchase", $detailTblVar)) {
				if (!isset($GLOBALS["userpurchase_grid"]))
					$GLOBALS["userpurchase_grid"] = new userpurchase_grid();
				if ($GLOBALS["userpurchase_grid"]->DetailEdit) {
					$GLOBALS["userpurchase_grid"]->CurrentMode = "edit";
					$GLOBALS["userpurchase_grid"]->CurrentAction = "gridedit";

					// Save current master table to detail table
					$GLOBALS["userpurchase_grid"]->setCurrentMasterTable($this->TableVar);
					$GLOBALS["userpurchase_grid"]->setStartRecordNumber(1);
					$GLOBALS["userpurchase_grid"]->_userid->IsDetailKey = TRUE;
					$GLOBALS["userpurchase_grid"]->_userid->CurrentValue = $this->id->CurrentValue;
					$GLOBALS["userpurchase_grid"]->_userid->setSessionValue($GLOBALS["userpurchase_grid"]->_userid->CurrentValue);
				}
			}
			if (in_array("loanlimits", $detailTblVar)) {
				if (!isset($GLOBALS["loanlimits_grid"]))
					$GLOBALS["loanlimits_grid"] = new loanlimits_grid();
				if ($GLOBALS["loanlimits_grid"]->DetailEdit) {
					$GLOBALS["loanlimits_grid"]->CurrentMode = "edit";
					$GLOBALS["loanlimits_grid"]->CurrentAction = "gridedit";

					// Save current master table to detail table
					$GLOBALS["loanlimits_grid"]->setCurrentMasterTable($this->TableVar);
					$GLOBALS["loanlimits_grid"]->setStartRecordNumber(1);
					$GLOBALS["loanlimits_grid"]->_userid->IsDetailKey = TRUE;
					$GLOBALS["loanlimits_grid"]->_userid->CurrentValue = $this->id->CurrentValue;
					$GLOBALS["loanlimits_grid"]->_userid->setSessionValue($GLOBALS["loanlimits_grid"]->_userid->CurrentValue);
				}
			}
			if (in_array("userkycdocs", $detailTblVar)) {
				if (!isset($GLOBALS["userkycdocs_grid"]))
					$GLOBALS["userkycdocs_grid"] = new userkycdocs_grid();
				if ($GLOBALS["userkycdocs_grid"]->DetailEdit) {
					$GLOBALS["userkycdocs_grid"]->CurrentMode = "edit";
					$GLOBALS["userkycdocs_grid"]->CurrentAction = "gridedit";

					// Save current master table to detail table
					$GLOBALS["userkycdocs_grid"]->setCurrentMasterTable($this->TableVar);
					$GLOBALS["userkycdocs_grid"]->setStartRecordNumber(1);
					$GLOBALS["userkycdocs_grid"]->_userid->IsDetailKey = TRUE;
					$GLOBALS["userkycdocs_grid"]->_userid->CurrentValue = $this->id->CurrentValue;
					$GLOBALS["userkycdocs_grid"]->_userid->setSessionValue($GLOBALS["userkycdocs_grid"]->_userid->CurrentValue);
				}
			}
			if (in_array("acctbalance", $detailTblVar)) {
				if (!isset($GLOBALS["acctbalance_grid"]))
					$GLOBALS["acctbalance_grid"] = new acctbalance_grid();
				if ($GLOBALS["acctbalance_grid"]->DetailEdit) {
					$GLOBALS["acctbalance_grid"]->CurrentMode = "edit";
					$GLOBALS["acctbalance_grid"]->CurrentAction = "gridedit";

					// Save current master table to detail table
					$GLOBALS["acctbalance_grid"]->setCurrentMasterTable($this->TableVar);
					$GLOBALS["acctbalance_grid"]->setStartRecordNumber(1);
					$GLOBALS["acctbalance_grid"]->acctID->IsDetailKey = TRUE;
					$GLOBALS["acctbalance_grid"]->acctID->CurrentValue = $this->accountID->CurrentValue;
					$GLOBALS["acctbalance_grid"]->acctID->setSessionValue($GLOBALS["acctbalance_grid"]->acctID->CurrentValue);
				}
			}
			if (in_array("userdevices", $detailTblVar)) {
				if (!isset($GLOBALS["userdevices_grid"]))
					$GLOBALS["userdevices_grid"] = new userdevices_grid();
				if ($GLOBALS["userdevices_grid"]->DetailEdit) {
					$GLOBALS["userdevices_grid"]->CurrentMode = "edit";
					$GLOBALS["userdevices_grid"]->CurrentAction = "gridedit";

					// Save current master table to detail table
					$GLOBALS["userdevices_grid"]->setCurrentMasterTable($this->TableVar);
					$GLOBALS["userdevices_grid"]->setStartRecordNumber(1);
					$GLOBALS["userdevices_grid"]->_userid->IsDetailKey = TRUE;
					$GLOBALS["userdevices_grid"]->_userid->CurrentValue = $this->id->CurrentValue;
					$GLOBALS["userdevices_grid"]->_userid->setSessionValue($GLOBALS["userdevices_grid"]->_userid->CurrentValue);
				}
			}
			if (in_array("usercommission", $detailTblVar)) {
				if (!isset($GLOBALS["usercommission_grid"]))
					$GLOBALS["usercommission_grid"] = new usercommission_grid();
				if ($GLOBALS["usercommission_grid"]->DetailEdit) {
					$GLOBALS["usercommission_grid"]->CurrentMode = "edit";
					$GLOBALS["usercommission_grid"]->CurrentAction = "gridedit";

					// Save current master table to detail table
					$GLOBALS["usercommission_grid"]->setCurrentMasterTable($this->TableVar);
					$GLOBALS["usercommission_grid"]->setStartRecordNumber(1);
					$GLOBALS["usercommission_grid"]->_userid->IsDetailKey = TRUE;
					$GLOBALS["usercommission_grid"]->_userid->CurrentValue = $this->id->CurrentValue;
					$GLOBALS["usercommission_grid"]->_userid->setSessionValue($GLOBALS["usercommission_grid"]->_userid->CurrentValue);
				}
			}
		}
	}

	// Set up Breadcrumb
	protected function setupBreadcrumb()
	{
		global $Breadcrumb, $Language;
		$Breadcrumb = new Breadcrumb();
		$url = substr(CurrentUrl(), strrpos(CurrentUrl(), "/")+1);
		$Breadcrumb->add("list", $this->TableVar, $this->addMasterUrl("userlist.php"), "", $this->TableVar, TRUE);
		$pageId = "edit";
		$Breadcrumb->add("edit", $pageId, $url);
	}

	// Set up multi pages
	protected function setupMultiPages()
	{
		$pages = new SubPages();
		$pages->Style = "tabs";
		$pages->add(0);
		$pages->add(1);
		$pages->add(2);
		$pages->add(3);
		$pages->add(4);
		$this->MultiPages = $pages;
	}

	// Set up detail pages
	protected function setupDetailPages()
	{
		$pages = new SubPages();
		$pages->Style = "tabs";
		$pages->add('userpasswordhistory');
		$pages->add('userpinhistory');
		$pages->add('userchildren');
		$pages->add('usercontactlist');
		$pages->add('securityuserrole');
		$pages->add('mailbox');
		$pages->add('balanceinquiryhistory');
		$pages->add('usersession');
		$pages->add('vtranshistorybyuser');
		$pages->add('vtranssummary');
		$pages->add('useremailaccount');
		$pages->add('userpi');
		$pages->add('userpurchase');
		$pages->add('loanlimits');
		$pages->add('userkycdocs');
		$pages->add('acctbalance');
		$pages->add('userdevices');
		$pages->add('usercommission');
		$this->DetailPages = $pages;
	}

	// Setup lookup options
	public function setupLookupOptions($fld)
	{
		if ($fld->Lookup !== NULL && $fld->Lookup->Options === NULL) {

			// Get default connection and filter
			$conn = $this->getConnection();
			$lookupFilter = "";

			// No need to check any more
			$fld->Lookup->Options = [];

			// Set up lookup SQL and connection
			switch ($fld->FieldVar) {
				case "x_passwordRequireChange":
					break;
				case "x_timezoneid":
					$conn = Conn("_4payreference");
					break;
				case "x_telephoneverified":
					break;
				case "x_telephonereceivemessage":
					break;
				case "x_countryid":
					break;
				case "x_stateid":
					$conn = Conn("_4payreference");
					break;
				case "x_defaultcurrency":
					$conn = Conn("_4payreference");
					break;
				case "x_langID":
					$lookupFilter = function() {
						return "`inlangid` = 'EN'";
					};
					$lookupFilter = $lookupFilter->bindTo($this);
					break;
				case "x_status":
					break;
				case "x_userType":
					$conn = Conn("_4payreference");
					break;
				case "x_usersubtype":
					$conn = Conn("_4payreference");
					break;
				case "x_corporate":
					break;
				case "x_profilestatus":
					$conn = Conn("_4payreference");
					break;
				case "x_gender":
					$conn = Conn("_4payreference");
					break;
				case "x_jumprequiredatlogin":
					break;
				case "x_ccbypass":
					break;
				case "x_userpiview":
					break;
				case "x_nationalitycountry":
					$conn = Conn("_4payreference");
					break;
				case "x_classification":
					$conn = Conn("_4payreference");
					break;
				case "x_occupation":
					$conn = Conn("_4payreference");
					break;
				case "x_sourceofincome":
					$conn = Conn("_4payreference");
					break;
				default:
					$lookupFilter = "";
					break;
			}

			// Always call to Lookup->getSql so that user can setup Lookup->Options in Lookup_Selecting server event
			$sql = $fld->Lookup->getSql(FALSE, "", $lookupFilter, $this);

			// Set up lookup cache
			if ($fld->UseLookupCache && $sql != "" && count($fld->Lookup->Options) == 0) {
				$totalCnt = $this->getRecordCount($sql, $conn);
				if ($totalCnt > $fld->LookupCacheCount) // Total count > cache count, do not cache
					return;
				$rs = $conn->execute($sql);
				$ar = [];
				while ($rs && !$rs->EOF) {
					$row = &$rs->fields;

					// Format the field values
					switch ($fld->FieldVar) {
						case "x_passwordRequireChange":
							break;
						case "x_timezoneid":
							break;
						case "x_telephoneverified":
							break;
						case "x_telephonereceivemessage":
							break;
						case "x_countryid":
							break;
						case "x_stateid":
							break;
						case "x_defaultcurrency":
							break;
						case "x_langID":
							break;
						case "x_status":
							break;
						case "x_userType":
							break;
						case "x_usersubtype":
							break;
						case "x_corporate":
							break;
						case "x_profilestatus":
							break;
						case "x_gender":
							break;
						case "x_jumprequiredatlogin":
							break;
						case "x_ccbypass":
							break;
						case "x_userpiview":
							break;
						case "x_nationalitycountry":
							break;
						case "x_classification":
							break;
						case "x_occupation":
							break;
						case "x_sourceofincome":
							break;
					}
					$ar[strval($row[0])] = $row;
					$rs->moveNext();
				}
				if ($rs)
					$rs->close();
				$fld->Lookup->Options = $ar;
			}
		}
	}

	// Set up starting record parameters
	public function setupStartRecord()
	{
		if ($this->DisplayRecords == 0)
			return;
		if ($this->isPageRequest()) { // Validate request
			$startRec = Get(Config("TABLE_START_REC"));
			$pageNo = Get(Config("TABLE_PAGE_NO"));
			if ($pageNo !== NULL) { // Check for "pageno" parameter first
				if (is_numeric($pageNo)) {
					$this->StartRecord = ($pageNo - 1) * $this->DisplayRecords + 1;
					if ($this->StartRecord <= 0) {
						$this->StartRecord = 1;
					} elseif ($this->StartRecord >= (int)(($this->TotalRecords - 1)/$this->DisplayRecords) * $this->DisplayRecords + 1) {
						$this->StartRecord = (int)(($this->TotalRecords - 1)/$this->DisplayRecords) * $this->DisplayRecords + 1;
					}
					$this->setStartRecordNumber($this->StartRecord);
				}
			} elseif ($startRec !== NULL) { // Check for "start" parameter
				$this->StartRecord = $startRec;
				$this->setStartRecordNumber($this->StartRecord);
			}
		}
		$this->StartRecord = $this->getStartRecordNumber();

		// Check if correct start record counter
		if (!is_numeric($this->StartRecord) || $this->StartRecord == "") { // Avoid invalid start record counter
			$this->StartRecord = 1; // Reset start record counter
			$this->setStartRecordNumber($this->StartRecord);
		} elseif ($this->StartRecord > $this->TotalRecords) { // Avoid starting record > total records
			$this->StartRecord = (int)(($this->TotalRecords - 1)/$this->DisplayRecords) * $this->DisplayRecords + 1; // Point to last page first record
			$this->setStartRecordNumber($this->StartRecord);
		} elseif (($this->StartRecord - 1) % $this->DisplayRecords != 0) {
			$this->StartRecord = (int)(($this->StartRecord - 1)/$this->DisplayRecords) * $this->DisplayRecords + 1; // Point to page boundary
			$this->setStartRecordNumber($this->StartRecord);
		}
	}

	// Page Load event
	function Page_Load() {

		//echo "Page Load";
	}

	// Page Unload event
	function Page_Unload() {

		//echo "Page Unload";
	}

	// Page Redirecting event
	function Page_Redirecting(&$url) {

		// Example:
		//$url = "your URL";

	}

	// Message Showing event
	// $type = ''|'success'|'failure'|'warning'
	function Message_Showing(&$msg, $type) {
		if ($type == 'success') {

			//$msg = "your success message";
		} elseif ($type == 'failure') {

			//$msg = "your failure message";
		} elseif ($type == 'warning') {

			//$msg = "your warning message";
		} else {

			//$msg = "your message";
		}
	}

	// Page Render event
	function Page_Render() {

		//echo "Page Render";
	}

	// Page Data Rendering event
	function Page_DataRendering(&$header) {

		// Example:
		//$header = "your header";

	}

	// Page Data Rendered event
	function Page_DataRendered(&$footer) {

		// Example:
		//$footer = "your footer";

	}

	// Form Custom Validate event
	function Form_CustomValidate(&$customError) {

		// Return error message in CustomError
		return TRUE;
	}
} // End class
?>