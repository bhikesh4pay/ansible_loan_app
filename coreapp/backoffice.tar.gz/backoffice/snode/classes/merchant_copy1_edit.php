<?php
namespace PHPMaker2020\_4payadmin;

/**
 * Page class
 */
class merchant_copy1_edit extends merchant_copy1
{

	// Page ID
	public $PageID = "edit";

	// Project ID
	public $ProjectID = "{153C2D2E-60EE-4944-8753-3935EB38E8D6}";

	// Table name
	public $TableName = 'merchant_copy1';

	// Page object name
	public $PageObjName = "merchant_copy1_edit";

	// Page headings
	public $Heading = "";
	public $Subheading = "";
	public $PageHeader;
	public $PageFooter;

	// Token
	public $Token = "";
	public $TokenTimeout = 0;
	public $CheckToken;

	// Page heading
	public function pageHeading()
	{
		global $Language;
		if ($this->Heading != "")
			return $this->Heading;
		if (method_exists($this, "tableCaption"))
			return $this->tableCaption();
		return "";
	}

	// Page subheading
	public function pageSubheading()
	{
		global $Language;
		if ($this->Subheading != "")
			return $this->Subheading;
		if ($this->TableName)
			return $Language->phrase($this->PageID);
		return "";
	}

	// Page name
	public function pageName()
	{
		return CurrentPageName();
	}

	// Page URL
	public function pageUrl()
	{
		$url = CurrentPageName() . "?";
		if ($this->UseTokenInUrl)
			$url .= "t=" . $this->TableVar . "&"; // Add page token
		return $url;
	}

	// Messages
	private $_message = "";
	private $_failureMessage = "";
	private $_successMessage = "";
	private $_warningMessage = "";

	// Get message
	public function getMessage()
	{
		return isset($_SESSION[SESSION_MESSAGE]) ? $_SESSION[SESSION_MESSAGE] : $this->_message;
	}

	// Set message
	public function setMessage($v)
	{
		AddMessage($this->_message, $v);
		$_SESSION[SESSION_MESSAGE] = $this->_message;
	}

	// Get failure message
	public function getFailureMessage()
	{
		return isset($_SESSION[SESSION_FAILURE_MESSAGE]) ? $_SESSION[SESSION_FAILURE_MESSAGE] : $this->_failureMessage;
	}

	// Set failure message
	public function setFailureMessage($v)
	{
		AddMessage($this->_failureMessage, $v);
		$_SESSION[SESSION_FAILURE_MESSAGE] = $this->_failureMessage;
	}

	// Get success message
	public function getSuccessMessage()
	{
		return isset($_SESSION[SESSION_SUCCESS_MESSAGE]) ? $_SESSION[SESSION_SUCCESS_MESSAGE] : $this->_successMessage;
	}

	// Set success message
	public function setSuccessMessage($v)
	{
		AddMessage($this->_successMessage, $v);
		$_SESSION[SESSION_SUCCESS_MESSAGE] = $this->_successMessage;
	}

	// Get warning message
	public function getWarningMessage()
	{
		return isset($_SESSION[SESSION_WARNING_MESSAGE]) ? $_SESSION[SESSION_WARNING_MESSAGE] : $this->_warningMessage;
	}

	// Set warning message
	public function setWarningMessage($v)
	{
		AddMessage($this->_warningMessage, $v);
		$_SESSION[SESSION_WARNING_MESSAGE] = $this->_warningMessage;
	}

	// Clear message
	public function clearMessage()
	{
		$this->_message = "";
		$_SESSION[SESSION_MESSAGE] = "";
	}

	// Clear failure message
	public function clearFailureMessage()
	{
		$this->_failureMessage = "";
		$_SESSION[SESSION_FAILURE_MESSAGE] = "";
	}

	// Clear success message
	public function clearSuccessMessage()
	{
		$this->_successMessage = "";
		$_SESSION[SESSION_SUCCESS_MESSAGE] = "";
	}

	// Clear warning message
	public function clearWarningMessage()
	{
		$this->_warningMessage = "";
		$_SESSION[SESSION_WARNING_MESSAGE] = "";
	}

	// Clear messages
	public function clearMessages()
	{
		$this->clearMessage();
		$this->clearFailureMessage();
		$this->clearSuccessMessage();
		$this->clearWarningMessage();
	}

	// Show message
	public function showMessage()
	{
		$hidden = FALSE;
		$html = "";

		// Message
		$message = $this->getMessage();
		if (method_exists($this, "Message_Showing"))
			$this->Message_Showing($message, "");
		if ($message != "") { // Message in Session, display
			if (!$hidden)
				$message = '<button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button>' . $message;
			$html .= '<div class="alert alert-info alert-dismissible ew-info"><i class="icon fas fa-info"></i>' . $message . '</div>';
			$_SESSION[SESSION_MESSAGE] = ""; // Clear message in Session
		}

		// Warning message
		$warningMessage = $this->getWarningMessage();
		if (method_exists($this, "Message_Showing"))
			$this->Message_Showing($warningMessage, "warning");
		if ($warningMessage != "") { // Message in Session, display
			if (!$hidden)
				$warningMessage = '<button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button>' . $warningMessage;
			$html .= '<div class="alert alert-warning alert-dismissible ew-warning"><i class="icon fas fa-exclamation"></i>' . $warningMessage . '</div>';
			$_SESSION[SESSION_WARNING_MESSAGE] = ""; // Clear message in Session
		}

		// Success message
		$successMessage = $this->getSuccessMessage();
		if (method_exists($this, "Message_Showing"))
			$this->Message_Showing($successMessage, "success");
		if ($successMessage != "") { // Message in Session, display
			if (!$hidden)
				$successMessage = '<button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button>' . $successMessage;
			$html .= '<div class="alert alert-success alert-dismissible ew-success"><i class="icon fas fa-check"></i>' . $successMessage . '</div>';
			$_SESSION[SESSION_SUCCESS_MESSAGE] = ""; // Clear message in Session
		}

		// Failure message
		$errorMessage = $this->getFailureMessage();
		if (method_exists($this, "Message_Showing"))
			$this->Message_Showing($errorMessage, "failure");
		if ($errorMessage != "") { // Message in Session, display
			if (!$hidden)
				$errorMessage = '<button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button>' . $errorMessage;
			$html .= '<div class="alert alert-danger alert-dismissible ew-error"><i class="icon fas fa-ban"></i>' . $errorMessage . '</div>';
			$_SESSION[SESSION_FAILURE_MESSAGE] = ""; // Clear message in Session
		}
		echo '<div class="ew-message-dialog' . (($hidden) ? ' d-none' : "") . '">' . $html . '</div>';
	}

	// Get message as array
	public function getMessages()
	{
		$ar = [];

		// Message
		$message = $this->getMessage();

		//if (method_exists($this, "Message_Showing"))
		//	$this->Message_Showing($message, "");

		if ($message != "") { // Message in Session, display
			$ar["message"] = $message;
			$_SESSION[SESSION_MESSAGE] = ""; // Clear message in Session
		}

		// Warning message
		$warningMessage = $this->getWarningMessage();

		//if (method_exists($this, "Message_Showing"))
		//	$this->Message_Showing($warningMessage, "warning");

		if ($warningMessage != "") { // Message in Session, display
			$ar["warningMessage"] = $warningMessage;
			$_SESSION[SESSION_WARNING_MESSAGE] = ""; // Clear message in Session
		}

		// Success message
		$successMessage = $this->getSuccessMessage();

		//if (method_exists($this, "Message_Showing"))
		//	$this->Message_Showing($successMessage, "success");

		if ($successMessage != "") { // Message in Session, display
			$ar["successMessage"] = $successMessage;
			$_SESSION[SESSION_SUCCESS_MESSAGE] = ""; // Clear message in Session
		}

		// Failure message
		$failureMessage = $this->getFailureMessage();

		//if (method_exists($this, "Message_Showing"))
		//	$this->Message_Showing($failureMessage, "failure");

		if ($failureMessage != "") { // Message in Session, display
			$ar["failureMessage"] = $failureMessage;
			$_SESSION[SESSION_FAILURE_MESSAGE] = ""; // Clear message in Session
		}
		return $ar;
	}

	// Show Page Header
	public function showPageHeader()
	{
		$header = $this->PageHeader;
		$this->Page_DataRendering($header);
		if ($header != "") { // Header exists, display
			echo '<p id="ew-page-header">' . $header . '</p>';
		}
	}

	// Show Page Footer
	public function showPageFooter()
	{
		$footer = $this->PageFooter;
		$this->Page_DataRendered($footer);
		if ($footer != "") { // Footer exists, display
			echo '<p id="ew-page-footer">' . $footer . '</p>';
		}
	}

	// Validate page request
	protected function isPageRequest()
	{
		global $CurrentForm;
		if ($this->UseTokenInUrl) {
			if ($CurrentForm)
				return ($this->TableVar == $CurrentForm->getValue("t"));
			if (Get("t") !== NULL)
				return ($this->TableVar == Get("t"));
		}
		return TRUE;
	}

	// Valid Post
	protected function validPost()
	{
		if (!$this->CheckToken || !IsPost() || IsApi())
			return TRUE;
		if (Post(Config("TOKEN_NAME")) === NULL)
			return FALSE;
		$fn = Config("CHECK_TOKEN_FUNC");
		if (is_callable($fn))
			return $fn(Post(Config("TOKEN_NAME")), $this->TokenTimeout);
		return FALSE;
	}

	// Create Token
	public function createToken()
	{
		global $CurrentToken;
		$fn = Config("CREATE_TOKEN_FUNC"); // Always create token, required by API file/lookup request
		if ($this->Token == "" && is_callable($fn)) // Create token
			$this->Token = $fn();
		$CurrentToken = $this->Token; // Save to global variable
	}

	// Constructor
	public function __construct()
	{
		global $Language, $DashboardReport;
		global $UserTable;

		// Check token
		$this->CheckToken = Config("CHECK_TOKEN");

		// Initialize
		$GLOBALS["Page"] = &$this;
		$this->TokenTimeout = SessionTimeoutTime();

		// Language object
		if (!isset($Language))
			$Language = new Language();

		// Parent constuctor
		parent::__construct();

		// Table object (merchant_copy1)
		if (!isset($GLOBALS["merchant_copy1"]) || get_class($GLOBALS["merchant_copy1"]) == PROJECT_NAMESPACE . "merchant_copy1") {
			$GLOBALS["merchant_copy1"] = &$this;
			$GLOBALS["Table"] = &$GLOBALS["merchant_copy1"];
		}

		// Table object (admin)
		if (!isset($GLOBALS['admin']))
			$GLOBALS['admin'] = new admin();

		// Page ID (for backward compatibility only)
		if (!defined(PROJECT_NAMESPACE . "PAGE_ID"))
			define(PROJECT_NAMESPACE . "PAGE_ID", 'edit');

		// Table name (for backward compatibility only)
		if (!defined(PROJECT_NAMESPACE . "TABLE_NAME"))
			define(PROJECT_NAMESPACE . "TABLE_NAME", 'merchant_copy1');

		// Start timer
		if (!isset($GLOBALS["DebugTimer"]))
			$GLOBALS["DebugTimer"] = new Timer();

		// Debug message
		LoadDebugMessage();

		// Open connection
		if (!isset($GLOBALS["Conn"]))
			$GLOBALS["Conn"] = $this->getConnection();

		// User table object (admin)
		$UserTable = $UserTable ?: new admin();
	}

	// Terminate page
	public function terminate($url = "")
	{
		global $ExportFileName, $TempImages, $DashboardReport;

		// Page Unload event
		$this->Page_Unload();

		// Global Page Unloaded event (in userfn*.php)
		Page_Unloaded();

		// Export
		global $merchant_copy1;
		if ($this->CustomExport && $this->CustomExport == $this->Export && array_key_exists($this->CustomExport, Config("EXPORT_CLASSES"))) {
				$content = ob_get_contents();
			if ($ExportFileName == "")
				$ExportFileName = $this->TableVar;
			$class = PROJECT_NAMESPACE . Config("EXPORT_CLASSES." . $this->CustomExport);
			if (class_exists($class)) {
				$doc = new $class($merchant_copy1);
				$doc->Text = @$content;
				if ($this->isExport("email"))
					echo $this->exportEmail($doc->Text);
				else
					$doc->export();
				DeleteTempImages(); // Delete temp images
				exit();
			}
		}
		if (!IsApi())
			$this->Page_Redirecting($url);

		// Close connection
		CloseConnections();

		// Return for API
		if (IsApi()) {
			$res = $url === TRUE;
			if (!$res) // Show error
				WriteJson(array_merge(["success" => FALSE], $this->getMessages()));
			return;
		}

		// Go to URL if specified
		if ($url != "") {
			if (!Config("DEBUG") && ob_get_length())
				ob_end_clean();

			// Handle modal response
			if ($this->IsModal) { // Show as modal
				$row = ["url" => $url, "modal" => "1"];
				$pageName = GetPageName($url);
				if ($pageName != $this->getListUrl()) { // Not List page
					$row["caption"] = $this->getModalCaption($pageName);
					if ($pageName == "merchant_copy1view.php")
						$row["view"] = "1";
				} else { // List page should not be shown as modal => error
					$row["error"] = $this->getFailureMessage();
					$this->clearFailureMessage();
				}
				WriteJson($row);
			} else {
				SaveDebugMessage();
				AddHeader("Location", $url);
			}
		}
		exit();
	}

	// Get records from recordset
	protected function getRecordsFromRecordset($rs, $current = FALSE)
	{
		$rows = [];
		if (is_object($rs)) { // Recordset
			while ($rs && !$rs->EOF) {
				$this->loadRowValues($rs); // Set up DbValue/CurrentValue
				$row = $this->getRecordFromArray($rs->fields);
				if ($current)
					return $row;
				else
					$rows[] = $row;
				$rs->moveNext();
			}
		} elseif (is_array($rs)) {
			foreach ($rs as $ar) {
				$row = $this->getRecordFromArray($ar);
				if ($current)
					return $row;
				else
					$rows[] = $row;
			}
		}
		return $rows;
	}

	// Get record from array
	protected function getRecordFromArray($ar)
	{
		$row = [];
		if (is_array($ar)) {
			foreach ($ar as $fldname => $val) {
				if (array_key_exists($fldname, $this->fields) && ($this->fields[$fldname]->Visible || $this->fields[$fldname]->IsPrimaryKey)) { // Primary key or Visible
					$fld = &$this->fields[$fldname];
					if ($fld->HtmlTag == "FILE") { // Upload field
						if (EmptyValue($val)) {
							$row[$fldname] = NULL;
						} else {
							if ($fld->DataType == DATATYPE_BLOB) {
								$url = FullUrl(GetApiUrl(Config("API_FILE_ACTION"),
									Config("API_OBJECT_NAME") . "=" . $fld->TableVar . "&" .
									Config("API_FIELD_NAME") . "=" . $fld->Param . "&" .
									Config("API_KEY_NAME") . "=" . rawurlencode($this->getRecordKeyValue($ar)))); //*** need to add this? API may not be in the same folder
								$row[$fldname] = ["type" => ContentType($val), "url" => $url, "name" => $fld->Param . ContentExtension($val)];
							} elseif (!$fld->UploadMultiple || !ContainsString($val, Config("MULTIPLE_UPLOAD_SEPARATOR"))) { // Single file
								$url = FullUrl(GetApiUrl(Config("API_FILE_ACTION"),
									Config("API_OBJECT_NAME") . "=" . $fld->TableVar . "&" .
									"fn=" . Encrypt($fld->physicalUploadPath() . $val)));
								$row[$fldname] = ["type" => MimeContentType($val), "url" => $url, "name" => $val];
							} else { // Multiple files
								$files = explode(Config("MULTIPLE_UPLOAD_SEPARATOR"), $val);
								$ar = [];
								foreach ($files as $file) {
									$url = FullUrl(GetApiUrl(Config("API_FILE_ACTION"),
										Config("API_OBJECT_NAME") . "=" . $fld->TableVar . "&" .
										"fn=" . Encrypt($fld->physicalUploadPath() . $file)));
									if (!EmptyValue($file))
										$ar[] = ["type" => MimeContentType($file), "url" => $url, "name" => $file];
								}
								$row[$fldname] = $ar;
							}
						}
					} else {
						$row[$fldname] = $val;
					}
				}
			}
		}
		return $row;
	}

	// Get record key value from array
	protected function getRecordKeyValue($ar)
	{
		$key = "";
		if (is_array($ar)) {
			$key .= @$ar['userid'];
		}
		return $key;
	}

	/**
	 * Hide fields for add/edit
	 *
	 * @return void
	 */
	protected function hideFieldsForAddEdit()
	{
	}

	// Lookup data
	public function lookup()
	{
		global $Language, $Security;
		if (!isset($Language))
			$Language = new Language(Config("LANGUAGE_FOLDER"), Post("language", ""));

		// Set up API request
		if (!ValidApiRequest())
			return FALSE;
		$this->setupApiSecurity();

		// Get lookup object
		$fieldName = Post("field");
		if (!array_key_exists($fieldName, $this->fields))
			return FALSE;
		$lookupField = $this->fields[$fieldName];
		$lookup = $lookupField->Lookup;
		if ($lookup === NULL)
			return FALSE;
		$tbl = $lookup->getTable();
		if (!$Security->allowLookup(Config("PROJECT_ID") . $tbl->TableName)) // Lookup permission
			return FALSE;

		// Get lookup parameters
		$lookupType = Post("ajax", "unknown");
		$pageSize = -1;
		$offset = -1;
		$searchValue = "";
		if (SameText($lookupType, "modal")) {
			$searchValue = Post("sv", "");
			$pageSize = Post("recperpage", 10);
			$offset = Post("start", 0);
		} elseif (SameText($lookupType, "autosuggest")) {
			$searchValue = Param("q", "");
			$pageSize = Param("n", -1);
			$pageSize = is_numeric($pageSize) ? (int)$pageSize : -1;
			if ($pageSize <= 0)
				$pageSize = Config("AUTO_SUGGEST_MAX_ENTRIES");
			$start = Param("start", -1);
			$start = is_numeric($start) ? (int)$start : -1;
			$page = Param("page", -1);
			$page = is_numeric($page) ? (int)$page : -1;
			$offset = $start >= 0 ? $start : ($page > 0 && $pageSize > 0 ? ($page - 1) * $pageSize : 0);
		}
		$userSelect = Decrypt(Post("s", ""));
		$userFilter = Decrypt(Post("f", ""));
		$userOrderBy = Decrypt(Post("o", ""));
		$keys = Post("keys");
		$lookup->LookupType = $lookupType; // Lookup type
		if ($keys !== NULL) { // Selected records from modal
			if (is_array($keys))
				$keys = implode(Config("MULTIPLE_OPTION_SEPARATOR"), $keys);
			$lookup->FilterFields = []; // Skip parent fields if any
			$lookup->FilterValues[] = $keys; // Lookup values
			$pageSize = -1; // Show all records
		} else { // Lookup values
			$lookup->FilterValues[] = Post("v0", Post("lookupValue", ""));
		}
		$cnt = is_array($lookup->FilterFields) ? count($lookup->FilterFields) : 0;
		for ($i = 1; $i <= $cnt; $i++)
			$lookup->FilterValues[] = Post("v" . $i, "");
		$lookup->SearchValue = $searchValue;
		$lookup->PageSize = $pageSize;
		$lookup->Offset = $offset;
		if ($userSelect != "")
			$lookup->UserSelect = $userSelect;
		if ($userFilter != "")
			$lookup->UserFilter = $userFilter;
		if ($userOrderBy != "")
			$lookup->UserOrderBy = $userOrderBy;
		$lookup->toJson($this); // Use settings from current page
	}

	// Set up API security
	public function setupApiSecurity()
	{
		global $Security;

		// Setup security for API request
		if ($Security->isLoggedIn()) $Security->TablePermission_Loading();
		$Security->loadCurrentUserLevel(Config("PROJECT_ID") . $this->TableName);
		if ($Security->isLoggedIn()) $Security->TablePermission_Loaded();
	}
	public $FormClassName = "ew-horizontal ew-form ew-edit-form";
	public $IsModal = FALSE;
	public $IsMobileOrModal = FALSE;
	public $DbMasterFilter;
	public $DbDetailFilter;

	//
	// Page run
	//

	public function run()
	{
		global $ExportType, $CustomExportType, $ExportFileName, $UserProfile, $Language, $Security, $CurrentForm,
			$FormError, $SkipHeaderFooter;

		// Is modal
		$this->IsModal = (Param("modal") == "1");

		// User profile
		$UserProfile = new UserProfile();

		// Security
		if (ValidApiRequest()) { // API request
			$this->setupApiSecurity(); // Set up API Security
			if (!$Security->canEdit()) {
				SetStatus(401); // Unauthorized
				return;
			}
		} else {
			$Security = new AdvancedSecurity();
			if (IsPasswordExpired())
				$this->terminate(GetUrl("changepwd.php"));
			if (!$Security->isLoggedIn())
				$Security->autoLogin();
			if ($Security->isLoggedIn())
				$Security->TablePermission_Loading();
			$Security->loadCurrentUserLevel($this->ProjectID . $this->TableName);
			if ($Security->isLoggedIn())
				$Security->TablePermission_Loaded();
			if (!$Security->canEdit()) {
				$Security->saveLastUrl();
				$this->setFailureMessage(DeniedMessage()); // Set no permission
				if ($Security->canList())
					$this->terminate(GetUrl("merchant_copy1list.php"));
				else
					$this->terminate(GetUrl("login.php"));
				return;
			}
		}

		// Create form object
		$CurrentForm = new HttpForm();
		$this->CurrentAction = Param("action"); // Set up current action
		$this->_userid->setVisibility();
		$this->changed->setVisibility();
		$this->active->setVisibility();
		$this->tipallowed->setVisibility();
		$this->merchanttoaddtip->setVisibility();
		$this->pis->setVisibility();
		$this->ratetabletype->setVisibility();
		$this->ratetableid->setVisibility();
		$this->officialdocnumber->setVisibility();
		$this->officialdocname->setVisibility();
		$this->businessname->setVisibility();
		$this->softposid->setVisibility();
		$this->taxamount->setVisibility();
		$this->variabletax->setVisibility();
		$this->logofilename->setVisibility();
		$this->returndays->setVisibility();
		$this->memberextrafieldsid->setVisibility();
		$this->lastupdatedate->setVisibility();
		$this->remmitancetype->setVisibility();
		$this->withholdingtaxaccount->setVisibility();
		$this->businessphoneno->setVisibility();
		$this->businessaddress1->setVisibility();
		$this->businessaddress2->setVisibility();
		$this->businesscity->setVisibility();
		$this->businessstate->setVisibility();
		$this->businesscountry->setVisibility();
		$this->businesszipcode->setVisibility();
		$this->bankname->setVisibility();
		$this->bankbranchnumber->setVisibility();
		$this->bankaccountnumber->setVisibility();
		$this->other1->setVisibility();
		$this->other2->setVisibility();
		$this->other3->setVisibility();
		$this->externalid->setVisibility();
		$this->couponpin->setVisibility();
		$this->officialname->setVisibility();
		$this->swiftcode->setVisibility();
		$this->profilevalidated->setVisibility();
		$this->profilevalidationdate->setVisibility();
		$this->industry->setVisibility();
		$this->legalstructure->setVisibility();
		$this->extendedfields->setVisibility();
		$this->hideFieldsForAddEdit();

		// Do not use lookup cache
		$this->setUseLookupCache(FALSE);

		// Global Page Loading event (in userfn*.php)
		Page_Loading();

		// Page Load event
		$this->Page_Load();

		// Check token
		if (!$this->validPost()) {
			Write($Language->phrase("InvalidPostRequest"));
			$this->terminate();
		}

		// Create Token
		$this->createToken();

		// Set up lookup cache
		// Check permission

		if (!$Security->canEdit()) {
			$this->setFailureMessage(DeniedMessage()); // No permission
			$this->terminate("merchant_copy1list.php");
			return;
		}

		// Check modal
		if ($this->IsModal)
			$SkipHeaderFooter = TRUE;
		$this->IsMobileOrModal = IsMobile() || $this->IsModal;
		$this->FormClassName = "ew-form ew-edit-form ew-horizontal";
		$loaded = FALSE;
		$postBack = FALSE;

		// Set up current action and primary key
		if (IsApi()) {

			// Load key values
			$loaded = TRUE;
			if (Get("_userid") !== NULL) {
				$this->_userid->setQueryStringValue(Get("_userid"));
				$this->_userid->setOldValue($this->_userid->QueryStringValue);
			} elseif (Key(0) !== NULL) {
				$this->_userid->setQueryStringValue(Key(0));
				$this->_userid->setOldValue($this->_userid->QueryStringValue);
			} elseif (Post("_userid") !== NULL) {
				$this->_userid->setFormValue(Post("_userid"));
				$this->_userid->setOldValue($this->_userid->FormValue);
			} elseif (Route(2) !== NULL) {
				$this->_userid->setQueryStringValue(Route(2));
				$this->_userid->setOldValue($this->_userid->QueryStringValue);
			} else {
				$loaded = FALSE; // Unable to load key
			}

			// Load record
			if ($loaded)
				$loaded = $this->loadRow();
			if (!$loaded) {
				$this->setFailureMessage($Language->phrase("NoRecord")); // Set no record message
				$this->terminate();
				return;
			}
			$this->CurrentAction = "update"; // Update record directly
			$postBack = TRUE;
		} else {
			if (Post("action") !== NULL) {
				$this->CurrentAction = Post("action"); // Get action code
				if (!$this->isShow()) // Not reload record, handle as postback
					$postBack = TRUE;

				// Load key from Form
				if ($CurrentForm->hasValue("x__userid")) {
					$this->_userid->setFormValue($CurrentForm->getValue("x__userid"));
				}
			} else {
				$this->CurrentAction = "show"; // Default action is display

				// Load key from QueryString / Route
				$loadByQuery = FALSE;
				if (Get("_userid") !== NULL) {
					$this->_userid->setQueryStringValue(Get("_userid"));
					$loadByQuery = TRUE;
				} elseif (Route(2) !== NULL) {
					$this->_userid->setQueryStringValue(Route(2));
					$loadByQuery = TRUE;
				} else {
					$this->_userid->CurrentValue = NULL;
				}
			}

			// Load current record
			$loaded = $this->loadRow();
		}

		// Process form if post back
		if ($postBack) {
			$this->loadFormValues(); // Get form values
		}

		// Validate form if post back
		if ($postBack) {
			if (!$this->validateForm()) {
				$this->setFailureMessage($FormError);
				$this->EventCancelled = TRUE; // Event cancelled
				$this->restoreFormValues();
				if (IsApi()) {
					$this->terminate();
					return;
				} else {
					$this->CurrentAction = ""; // Form error, reset action
				}
			}
		}

		// Perform current action
		switch ($this->CurrentAction) {
			case "show": // Get a record to display
				if (!$loaded) { // Load record based on key
					if ($this->getFailureMessage() == "")
						$this->setFailureMessage($Language->phrase("NoRecord")); // No record found
					$this->terminate("merchant_copy1list.php"); // No matching record, return to list
				}
				break;
			case "update": // Update
				$returnUrl = $this->getReturnUrl();
				if (GetPageName($returnUrl) == "merchant_copy1list.php")
					$returnUrl = $this->addMasterUrl($returnUrl); // List page, return to List page with correct master key if necessary
				$this->SendEmail = TRUE; // Send email on update success
				if ($this->editRow()) { // Update record based on key
					if ($this->getSuccessMessage() == "")
						$this->setSuccessMessage($Language->phrase("UpdateSuccess")); // Update success
					if (IsApi()) {
						$this->terminate(TRUE);
						return;
					} else {
						$this->terminate($returnUrl); // Return to caller
					}
				} elseif (IsApi()) { // API request, return
					$this->terminate();
					return;
				} elseif ($this->getFailureMessage() == $Language->phrase("NoRecord")) {
					$this->terminate($returnUrl); // Return to caller
				} else {
					$this->EventCancelled = TRUE; // Event cancelled
					$this->restoreFormValues(); // Restore form values if update failed
				}
		}

		// Set up Breadcrumb
		$this->setupBreadcrumb();

		// Render the record
		$this->RowType = ROWTYPE_EDIT; // Render as Edit
		$this->resetAttributes();
		$this->renderRow();
	}

	// Get upload files
	protected function getUploadFiles()
	{
		global $CurrentForm, $Language;
	}

	// Load form values
	protected function loadFormValues()
	{

		// Load from form
		global $CurrentForm;

		// Check field name 'userid' first before field var 'x__userid'
		$val = $CurrentForm->hasValue("userid") ? $CurrentForm->getValue("userid") : $CurrentForm->getValue("x__userid");
		if (!$this->_userid->IsDetailKey) {
			if (IsApi() && $val === NULL)
				$this->_userid->Visible = FALSE; // Disable update for API request
			else
				$this->_userid->setFormValue($val);
		}
		if ($CurrentForm->hasValue("o__userid"))
			$this->_userid->setOldValue($CurrentForm->getValue("o__userid"));

		// Check field name 'changed' first before field var 'x_changed'
		$val = $CurrentForm->hasValue("changed") ? $CurrentForm->getValue("changed") : $CurrentForm->getValue("x_changed");
		if (!$this->changed->IsDetailKey) {
			if (IsApi() && $val === NULL)
				$this->changed->Visible = FALSE; // Disable update for API request
			else
				$this->changed->setFormValue($val);
		}

		// Check field name 'active' first before field var 'x_active'
		$val = $CurrentForm->hasValue("active") ? $CurrentForm->getValue("active") : $CurrentForm->getValue("x_active");
		if (!$this->active->IsDetailKey) {
			if (IsApi() && $val === NULL)
				$this->active->Visible = FALSE; // Disable update for API request
			else
				$this->active->setFormValue($val);
		}

		// Check field name 'tipallowed' first before field var 'x_tipallowed'
		$val = $CurrentForm->hasValue("tipallowed") ? $CurrentForm->getValue("tipallowed") : $CurrentForm->getValue("x_tipallowed");
		if (!$this->tipallowed->IsDetailKey) {
			if (IsApi() && $val === NULL)
				$this->tipallowed->Visible = FALSE; // Disable update for API request
			else
				$this->tipallowed->setFormValue($val);
		}

		// Check field name 'merchanttoaddtip' first before field var 'x_merchanttoaddtip'
		$val = $CurrentForm->hasValue("merchanttoaddtip") ? $CurrentForm->getValue("merchanttoaddtip") : $CurrentForm->getValue("x_merchanttoaddtip");
		if (!$this->merchanttoaddtip->IsDetailKey) {
			if (IsApi() && $val === NULL)
				$this->merchanttoaddtip->Visible = FALSE; // Disable update for API request
			else
				$this->merchanttoaddtip->setFormValue($val);
		}

		// Check field name 'pis' first before field var 'x_pis'
		$val = $CurrentForm->hasValue("pis") ? $CurrentForm->getValue("pis") : $CurrentForm->getValue("x_pis");
		if (!$this->pis->IsDetailKey) {
			if (IsApi() && $val === NULL)
				$this->pis->Visible = FALSE; // Disable update for API request
			else
				$this->pis->setFormValue($val);
		}

		// Check field name 'ratetabletype' first before field var 'x_ratetabletype'
		$val = $CurrentForm->hasValue("ratetabletype") ? $CurrentForm->getValue("ratetabletype") : $CurrentForm->getValue("x_ratetabletype");
		if (!$this->ratetabletype->IsDetailKey) {
			if (IsApi() && $val === NULL)
				$this->ratetabletype->Visible = FALSE; // Disable update for API request
			else
				$this->ratetabletype->setFormValue($val);
		}

		// Check field name 'ratetableid' first before field var 'x_ratetableid'
		$val = $CurrentForm->hasValue("ratetableid") ? $CurrentForm->getValue("ratetableid") : $CurrentForm->getValue("x_ratetableid");
		if (!$this->ratetableid->IsDetailKey) {
			if (IsApi() && $val === NULL)
				$this->ratetableid->Visible = FALSE; // Disable update for API request
			else
				$this->ratetableid->setFormValue($val);
		}

		// Check field name 'officialdocnumber' first before field var 'x_officialdocnumber'
		$val = $CurrentForm->hasValue("officialdocnumber") ? $CurrentForm->getValue("officialdocnumber") : $CurrentForm->getValue("x_officialdocnumber");
		if (!$this->officialdocnumber->IsDetailKey) {
			if (IsApi() && $val === NULL)
				$this->officialdocnumber->Visible = FALSE; // Disable update for API request
			else
				$this->officialdocnumber->setFormValue($val);
		}

		// Check field name 'officialdocname' first before field var 'x_officialdocname'
		$val = $CurrentForm->hasValue("officialdocname") ? $CurrentForm->getValue("officialdocname") : $CurrentForm->getValue("x_officialdocname");
		if (!$this->officialdocname->IsDetailKey) {
			if (IsApi() && $val === NULL)
				$this->officialdocname->Visible = FALSE; // Disable update for API request
			else
				$this->officialdocname->setFormValue($val);
		}

		// Check field name 'businessname' first before field var 'x_businessname'
		$val = $CurrentForm->hasValue("businessname") ? $CurrentForm->getValue("businessname") : $CurrentForm->getValue("x_businessname");
		if (!$this->businessname->IsDetailKey) {
			if (IsApi() && $val === NULL)
				$this->businessname->Visible = FALSE; // Disable update for API request
			else
				$this->businessname->setFormValue($val);
		}

		// Check field name 'softposid' first before field var 'x_softposid'
		$val = $CurrentForm->hasValue("softposid") ? $CurrentForm->getValue("softposid") : $CurrentForm->getValue("x_softposid");
		if (!$this->softposid->IsDetailKey) {
			if (IsApi() && $val === NULL)
				$this->softposid->Visible = FALSE; // Disable update for API request
			else
				$this->softposid->setFormValue($val);
		}

		// Check field name 'taxamount' first before field var 'x_taxamount'
		$val = $CurrentForm->hasValue("taxamount") ? $CurrentForm->getValue("taxamount") : $CurrentForm->getValue("x_taxamount");
		if (!$this->taxamount->IsDetailKey) {
			if (IsApi() && $val === NULL)
				$this->taxamount->Visible = FALSE; // Disable update for API request
			else
				$this->taxamount->setFormValue($val);
		}

		// Check field name 'variabletax' first before field var 'x_variabletax'
		$val = $CurrentForm->hasValue("variabletax") ? $CurrentForm->getValue("variabletax") : $CurrentForm->getValue("x_variabletax");
		if (!$this->variabletax->IsDetailKey) {
			if (IsApi() && $val === NULL)
				$this->variabletax->Visible = FALSE; // Disable update for API request
			else
				$this->variabletax->setFormValue($val);
		}

		// Check field name 'logofilename' first before field var 'x_logofilename'
		$val = $CurrentForm->hasValue("logofilename") ? $CurrentForm->getValue("logofilename") : $CurrentForm->getValue("x_logofilename");
		if (!$this->logofilename->IsDetailKey) {
			if (IsApi() && $val === NULL)
				$this->logofilename->Visible = FALSE; // Disable update for API request
			else
				$this->logofilename->setFormValue($val);
		}

		// Check field name 'returndays' first before field var 'x_returndays'
		$val = $CurrentForm->hasValue("returndays") ? $CurrentForm->getValue("returndays") : $CurrentForm->getValue("x_returndays");
		if (!$this->returndays->IsDetailKey) {
			if (IsApi() && $val === NULL)
				$this->returndays->Visible = FALSE; // Disable update for API request
			else
				$this->returndays->setFormValue($val);
		}

		// Check field name 'memberextrafieldsid' first before field var 'x_memberextrafieldsid'
		$val = $CurrentForm->hasValue("memberextrafieldsid") ? $CurrentForm->getValue("memberextrafieldsid") : $CurrentForm->getValue("x_memberextrafieldsid");
		if (!$this->memberextrafieldsid->IsDetailKey) {
			if (IsApi() && $val === NULL)
				$this->memberextrafieldsid->Visible = FALSE; // Disable update for API request
			else
				$this->memberextrafieldsid->setFormValue($val);
		}

		// Check field name 'lastupdatedate' first before field var 'x_lastupdatedate'
		$val = $CurrentForm->hasValue("lastupdatedate") ? $CurrentForm->getValue("lastupdatedate") : $CurrentForm->getValue("x_lastupdatedate");
		if (!$this->lastupdatedate->IsDetailKey) {
			if (IsApi() && $val === NULL)
				$this->lastupdatedate->Visible = FALSE; // Disable update for API request
			else
				$this->lastupdatedate->setFormValue($val);
			$this->lastupdatedate->CurrentValue = UnFormatDateTime($this->lastupdatedate->CurrentValue, 0);
		}

		// Check field name 'remmitancetype' first before field var 'x_remmitancetype'
		$val = $CurrentForm->hasValue("remmitancetype") ? $CurrentForm->getValue("remmitancetype") : $CurrentForm->getValue("x_remmitancetype");
		if (!$this->remmitancetype->IsDetailKey) {
			if (IsApi() && $val === NULL)
				$this->remmitancetype->Visible = FALSE; // Disable update for API request
			else
				$this->remmitancetype->setFormValue($val);
		}

		// Check field name 'withholdingtaxaccount' first before field var 'x_withholdingtaxaccount'
		$val = $CurrentForm->hasValue("withholdingtaxaccount") ? $CurrentForm->getValue("withholdingtaxaccount") : $CurrentForm->getValue("x_withholdingtaxaccount");
		if (!$this->withholdingtaxaccount->IsDetailKey) {
			if (IsApi() && $val === NULL)
				$this->withholdingtaxaccount->Visible = FALSE; // Disable update for API request
			else
				$this->withholdingtaxaccount->setFormValue($val);
		}

		// Check field name 'businessphoneno' first before field var 'x_businessphoneno'
		$val = $CurrentForm->hasValue("businessphoneno") ? $CurrentForm->getValue("businessphoneno") : $CurrentForm->getValue("x_businessphoneno");
		if (!$this->businessphoneno->IsDetailKey) {
			if (IsApi() && $val === NULL)
				$this->businessphoneno->Visible = FALSE; // Disable update for API request
			else
				$this->businessphoneno->setFormValue($val);
		}

		// Check field name 'businessaddress1' first before field var 'x_businessaddress1'
		$val = $CurrentForm->hasValue("businessaddress1") ? $CurrentForm->getValue("businessaddress1") : $CurrentForm->getValue("x_businessaddress1");
		if (!$this->businessaddress1->IsDetailKey) {
			if (IsApi() && $val === NULL)
				$this->businessaddress1->Visible = FALSE; // Disable update for API request
			else
				$this->businessaddress1->setFormValue($val);
		}

		// Check field name 'businessaddress2' first before field var 'x_businessaddress2'
		$val = $CurrentForm->hasValue("businessaddress2") ? $CurrentForm->getValue("businessaddress2") : $CurrentForm->getValue("x_businessaddress2");
		if (!$this->businessaddress2->IsDetailKey) {
			if (IsApi() && $val === NULL)
				$this->businessaddress2->Visible = FALSE; // Disable update for API request
			else
				$this->businessaddress2->setFormValue($val);
		}

		// Check field name 'businesscity' first before field var 'x_businesscity'
		$val = $CurrentForm->hasValue("businesscity") ? $CurrentForm->getValue("businesscity") : $CurrentForm->getValue("x_businesscity");
		if (!$this->businesscity->IsDetailKey) {
			if (IsApi() && $val === NULL)
				$this->businesscity->Visible = FALSE; // Disable update for API request
			else
				$this->businesscity->setFormValue($val);
		}

		// Check field name 'businessstate' first before field var 'x_businessstate'
		$val = $CurrentForm->hasValue("businessstate") ? $CurrentForm->getValue("businessstate") : $CurrentForm->getValue("x_businessstate");
		if (!$this->businessstate->IsDetailKey) {
			if (IsApi() && $val === NULL)
				$this->businessstate->Visible = FALSE; // Disable update for API request
			else
				$this->businessstate->setFormValue($val);
		}

		// Check field name 'businesscountry' first before field var 'x_businesscountry'
		$val = $CurrentForm->hasValue("businesscountry") ? $CurrentForm->getValue("businesscountry") : $CurrentForm->getValue("x_businesscountry");
		if (!$this->businesscountry->IsDetailKey) {
			if (IsApi() && $val === NULL)
				$this->businesscountry->Visible = FALSE; // Disable update for API request
			else
				$this->businesscountry->setFormValue($val);
		}

		// Check field name 'businesszipcode' first before field var 'x_businesszipcode'
		$val = $CurrentForm->hasValue("businesszipcode") ? $CurrentForm->getValue("businesszipcode") : $CurrentForm->getValue("x_businesszipcode");
		if (!$this->businesszipcode->IsDetailKey) {
			if (IsApi() && $val === NULL)
				$this->businesszipcode->Visible = FALSE; // Disable update for API request
			else
				$this->businesszipcode->setFormValue($val);
		}

		// Check field name 'bankname' first before field var 'x_bankname'
		$val = $CurrentForm->hasValue("bankname") ? $CurrentForm->getValue("bankname") : $CurrentForm->getValue("x_bankname");
		if (!$this->bankname->IsDetailKey) {
			if (IsApi() && $val === NULL)
				$this->bankname->Visible = FALSE; // Disable update for API request
			else
				$this->bankname->setFormValue($val);
		}

		// Check field name 'bankbranchnumber' first before field var 'x_bankbranchnumber'
		$val = $CurrentForm->hasValue("bankbranchnumber") ? $CurrentForm->getValue("bankbranchnumber") : $CurrentForm->getValue("x_bankbranchnumber");
		if (!$this->bankbranchnumber->IsDetailKey) {
			if (IsApi() && $val === NULL)
				$this->bankbranchnumber->Visible = FALSE; // Disable update for API request
			else
				$this->bankbranchnumber->setFormValue($val);
		}

		// Check field name 'bankaccountnumber' first before field var 'x_bankaccountnumber'
		$val = $CurrentForm->hasValue("bankaccountnumber") ? $CurrentForm->getValue("bankaccountnumber") : $CurrentForm->getValue("x_bankaccountnumber");
		if (!$this->bankaccountnumber->IsDetailKey) {
			if (IsApi() && $val === NULL)
				$this->bankaccountnumber->Visible = FALSE; // Disable update for API request
			else
				$this->bankaccountnumber->setFormValue($val);
		}

		// Check field name 'other1' first before field var 'x_other1'
		$val = $CurrentForm->hasValue("other1") ? $CurrentForm->getValue("other1") : $CurrentForm->getValue("x_other1");
		if (!$this->other1->IsDetailKey) {
			if (IsApi() && $val === NULL)
				$this->other1->Visible = FALSE; // Disable update for API request
			else
				$this->other1->setFormValue($val);
		}

		// Check field name 'other2' first before field var 'x_other2'
		$val = $CurrentForm->hasValue("other2") ? $CurrentForm->getValue("other2") : $CurrentForm->getValue("x_other2");
		if (!$this->other2->IsDetailKey) {
			if (IsApi() && $val === NULL)
				$this->other2->Visible = FALSE; // Disable update for API request
			else
				$this->other2->setFormValue($val);
		}

		// Check field name 'other3' first before field var 'x_other3'
		$val = $CurrentForm->hasValue("other3") ? $CurrentForm->getValue("other3") : $CurrentForm->getValue("x_other3");
		if (!$this->other3->IsDetailKey) {
			if (IsApi() && $val === NULL)
				$this->other3->Visible = FALSE; // Disable update for API request
			else
				$this->other3->setFormValue($val);
		}

		// Check field name 'externalid' first before field var 'x_externalid'
		$val = $CurrentForm->hasValue("externalid") ? $CurrentForm->getValue("externalid") : $CurrentForm->getValue("x_externalid");
		if (!$this->externalid->IsDetailKey) {
			if (IsApi() && $val === NULL)
				$this->externalid->Visible = FALSE; // Disable update for API request
			else
				$this->externalid->setFormValue($val);
		}

		// Check field name 'couponpin' first before field var 'x_couponpin'
		$val = $CurrentForm->hasValue("couponpin") ? $CurrentForm->getValue("couponpin") : $CurrentForm->getValue("x_couponpin");
		if (!$this->couponpin->IsDetailKey) {
			if (IsApi() && $val === NULL)
				$this->couponpin->Visible = FALSE; // Disable update for API request
			else
				$this->couponpin->setFormValue($val);
		}

		// Check field name 'officialname' first before field var 'x_officialname'
		$val = $CurrentForm->hasValue("officialname") ? $CurrentForm->getValue("officialname") : $CurrentForm->getValue("x_officialname");
		if (!$this->officialname->IsDetailKey) {
			if (IsApi() && $val === NULL)
				$this->officialname->Visible = FALSE; // Disable update for API request
			else
				$this->officialname->setFormValue($val);
		}

		// Check field name 'swiftcode' first before field var 'x_swiftcode'
		$val = $CurrentForm->hasValue("swiftcode") ? $CurrentForm->getValue("swiftcode") : $CurrentForm->getValue("x_swiftcode");
		if (!$this->swiftcode->IsDetailKey) {
			if (IsApi() && $val === NULL)
				$this->swiftcode->Visible = FALSE; // Disable update for API request
			else
				$this->swiftcode->setFormValue($val);
		}

		// Check field name 'profilevalidated' first before field var 'x_profilevalidated'
		$val = $CurrentForm->hasValue("profilevalidated") ? $CurrentForm->getValue("profilevalidated") : $CurrentForm->getValue("x_profilevalidated");
		if (!$this->profilevalidated->IsDetailKey) {
			if (IsApi() && $val === NULL)
				$this->profilevalidated->Visible = FALSE; // Disable update for API request
			else
				$this->profilevalidated->setFormValue($val);
		}

		// Check field name 'profilevalidationdate' first before field var 'x_profilevalidationdate'
		$val = $CurrentForm->hasValue("profilevalidationdate") ? $CurrentForm->getValue("profilevalidationdate") : $CurrentForm->getValue("x_profilevalidationdate");
		if (!$this->profilevalidationdate->IsDetailKey) {
			if (IsApi() && $val === NULL)
				$this->profilevalidationdate->Visible = FALSE; // Disable update for API request
			else
				$this->profilevalidationdate->setFormValue($val);
			$this->profilevalidationdate->CurrentValue = UnFormatDateTime($this->profilevalidationdate->CurrentValue, 0);
		}

		// Check field name 'industry' first before field var 'x_industry'
		$val = $CurrentForm->hasValue("industry") ? $CurrentForm->getValue("industry") : $CurrentForm->getValue("x_industry");
		if (!$this->industry->IsDetailKey) {
			if (IsApi() && $val === NULL)
				$this->industry->Visible = FALSE; // Disable update for API request
			else
				$this->industry->setFormValue($val);
		}

		// Check field name 'legalstructure' first before field var 'x_legalstructure'
		$val = $CurrentForm->hasValue("legalstructure") ? $CurrentForm->getValue("legalstructure") : $CurrentForm->getValue("x_legalstructure");
		if (!$this->legalstructure->IsDetailKey) {
			if (IsApi() && $val === NULL)
				$this->legalstructure->Visible = FALSE; // Disable update for API request
			else
				$this->legalstructure->setFormValue($val);
		}

		// Check field name 'extendedfields' first before field var 'x_extendedfields'
		$val = $CurrentForm->hasValue("extendedfields") ? $CurrentForm->getValue("extendedfields") : $CurrentForm->getValue("x_extendedfields");
		if (!$this->extendedfields->IsDetailKey) {
			if (IsApi() && $val === NULL)
				$this->extendedfields->Visible = FALSE; // Disable update for API request
			else
				$this->extendedfields->setFormValue($val);
		}
	}

	// Restore form values
	public function restoreFormValues()
	{
		global $CurrentForm;
		$this->_userid->CurrentValue = $this->_userid->FormValue;
		$this->changed->CurrentValue = $this->changed->FormValue;
		$this->active->CurrentValue = $this->active->FormValue;
		$this->tipallowed->CurrentValue = $this->tipallowed->FormValue;
		$this->merchanttoaddtip->CurrentValue = $this->merchanttoaddtip->FormValue;
		$this->pis->CurrentValue = $this->pis->FormValue;
		$this->ratetabletype->CurrentValue = $this->ratetabletype->FormValue;
		$this->ratetableid->CurrentValue = $this->ratetableid->FormValue;
		$this->officialdocnumber->CurrentValue = $this->officialdocnumber->FormValue;
		$this->officialdocname->CurrentValue = $this->officialdocname->FormValue;
		$this->businessname->CurrentValue = $this->businessname->FormValue;
		$this->softposid->CurrentValue = $this->softposid->FormValue;
		$this->taxamount->CurrentValue = $this->taxamount->FormValue;
		$this->variabletax->CurrentValue = $this->variabletax->FormValue;
		$this->logofilename->CurrentValue = $this->logofilename->FormValue;
		$this->returndays->CurrentValue = $this->returndays->FormValue;
		$this->memberextrafieldsid->CurrentValue = $this->memberextrafieldsid->FormValue;
		$this->lastupdatedate->CurrentValue = $this->lastupdatedate->FormValue;
		$this->lastupdatedate->CurrentValue = UnFormatDateTime($this->lastupdatedate->CurrentValue, 0);
		$this->remmitancetype->CurrentValue = $this->remmitancetype->FormValue;
		$this->withholdingtaxaccount->CurrentValue = $this->withholdingtaxaccount->FormValue;
		$this->businessphoneno->CurrentValue = $this->businessphoneno->FormValue;
		$this->businessaddress1->CurrentValue = $this->businessaddress1->FormValue;
		$this->businessaddress2->CurrentValue = $this->businessaddress2->FormValue;
		$this->businesscity->CurrentValue = $this->businesscity->FormValue;
		$this->businessstate->CurrentValue = $this->businessstate->FormValue;
		$this->businesscountry->CurrentValue = $this->businesscountry->FormValue;
		$this->businesszipcode->CurrentValue = $this->businesszipcode->FormValue;
		$this->bankname->CurrentValue = $this->bankname->FormValue;
		$this->bankbranchnumber->CurrentValue = $this->bankbranchnumber->FormValue;
		$this->bankaccountnumber->CurrentValue = $this->bankaccountnumber->FormValue;
		$this->other1->CurrentValue = $this->other1->FormValue;
		$this->other2->CurrentValue = $this->other2->FormValue;
		$this->other3->CurrentValue = $this->other3->FormValue;
		$this->externalid->CurrentValue = $this->externalid->FormValue;
		$this->couponpin->CurrentValue = $this->couponpin->FormValue;
		$this->officialname->CurrentValue = $this->officialname->FormValue;
		$this->swiftcode->CurrentValue = $this->swiftcode->FormValue;
		$this->profilevalidated->CurrentValue = $this->profilevalidated->FormValue;
		$this->profilevalidationdate->CurrentValue = $this->profilevalidationdate->FormValue;
		$this->profilevalidationdate->CurrentValue = UnFormatDateTime($this->profilevalidationdate->CurrentValue, 0);
		$this->industry->CurrentValue = $this->industry->FormValue;
		$this->legalstructure->CurrentValue = $this->legalstructure->FormValue;
		$this->extendedfields->CurrentValue = $this->extendedfields->FormValue;
	}

	// Load row based on key values
	public function loadRow()
	{
		global $Security, $Language;
		$filter = $this->getRecordFilter();

		// Call Row Selecting event
		$this->Row_Selecting($filter);

		// Load SQL based on filter
		$this->CurrentFilter = $filter;
		$sql = $this->getCurrentSql();
		$conn = $this->getConnection();
		$res = FALSE;
		$rs = LoadRecordset($sql, $conn);
		if ($rs && !$rs->EOF) {
			$res = TRUE;
			$this->loadRowValues($rs); // Load row values
			$rs->close();
		}
		return $res;
	}

	// Load row values from recordset
	public function loadRowValues($rs = NULL)
	{
		if ($rs && !$rs->EOF)
			$row = $rs->fields;
		else
			$row = $this->newRow();

		// Call Row Selected event
		$this->Row_Selected($row);
		if (!$rs || $rs->EOF)
			return;
		$this->_userid->setDbValue($row['userid']);
		$this->changed->setDbValue($row['changed']);
		$this->active->setDbValue($row['active']);
		$this->tipallowed->setDbValue($row['tipallowed']);
		$this->merchanttoaddtip->setDbValue($row['merchanttoaddtip']);
		$this->pis->setDbValue($row['pis']);
		$this->ratetabletype->setDbValue($row['ratetabletype']);
		$this->ratetableid->setDbValue($row['ratetableid']);
		$this->officialdocnumber->setDbValue($row['officialdocnumber']);
		$this->officialdocname->setDbValue($row['officialdocname']);
		$this->businessname->setDbValue($row['businessname']);
		$this->softposid->setDbValue($row['softposid']);
		$this->taxamount->setDbValue($row['taxamount']);
		$this->variabletax->setDbValue($row['variabletax']);
		$this->logofilename->setDbValue($row['logofilename']);
		$this->returndays->setDbValue($row['returndays']);
		$this->memberextrafieldsid->setDbValue($row['memberextrafieldsid']);
		$this->lastupdatedate->setDbValue($row['lastupdatedate']);
		$this->remmitancetype->setDbValue($row['remmitancetype']);
		$this->withholdingtaxaccount->setDbValue($row['withholdingtaxaccount']);
		$this->businessphoneno->setDbValue($row['businessphoneno']);
		$this->businessaddress1->setDbValue($row['businessaddress1']);
		$this->businessaddress2->setDbValue($row['businessaddress2']);
		$this->businesscity->setDbValue($row['businesscity']);
		$this->businessstate->setDbValue($row['businessstate']);
		$this->businesscountry->setDbValue($row['businesscountry']);
		$this->businesszipcode->setDbValue($row['businesszipcode']);
		$this->bankname->setDbValue($row['bankname']);
		$this->bankbranchnumber->setDbValue($row['bankbranchnumber']);
		$this->bankaccountnumber->setDbValue($row['bankaccountnumber']);
		$this->other1->setDbValue($row['other1']);
		$this->other2->setDbValue($row['other2']);
		$this->other3->setDbValue($row['other3']);
		$this->externalid->setDbValue($row['externalid']);
		$this->couponpin->setDbValue($row['couponpin']);
		$this->officialname->setDbValue($row['officialname']);
		$this->swiftcode->setDbValue($row['swiftcode']);
		$this->profilevalidated->setDbValue($row['profilevalidated']);
		$this->profilevalidationdate->setDbValue($row['profilevalidationdate']);
		$this->industry->setDbValue($row['industry']);
		$this->legalstructure->setDbValue($row['legalstructure']);
		$this->extendedfields->setDbValue($row['extendedfields']);
	}

	// Return a row with default values
	protected function newRow()
	{
		$row = [];
		$row['userid'] = NULL;
		$row['changed'] = NULL;
		$row['active'] = NULL;
		$row['tipallowed'] = NULL;
		$row['merchanttoaddtip'] = NULL;
		$row['pis'] = NULL;
		$row['ratetabletype'] = NULL;
		$row['ratetableid'] = NULL;
		$row['officialdocnumber'] = NULL;
		$row['officialdocname'] = NULL;
		$row['businessname'] = NULL;
		$row['softposid'] = NULL;
		$row['taxamount'] = NULL;
		$row['variabletax'] = NULL;
		$row['logofilename'] = NULL;
		$row['returndays'] = NULL;
		$row['memberextrafieldsid'] = NULL;
		$row['lastupdatedate'] = NULL;
		$row['remmitancetype'] = NULL;
		$row['withholdingtaxaccount'] = NULL;
		$row['businessphoneno'] = NULL;
		$row['businessaddress1'] = NULL;
		$row['businessaddress2'] = NULL;
		$row['businesscity'] = NULL;
		$row['businessstate'] = NULL;
		$row['businesscountry'] = NULL;
		$row['businesszipcode'] = NULL;
		$row['bankname'] = NULL;
		$row['bankbranchnumber'] = NULL;
		$row['bankaccountnumber'] = NULL;
		$row['other1'] = NULL;
		$row['other2'] = NULL;
		$row['other3'] = NULL;
		$row['externalid'] = NULL;
		$row['couponpin'] = NULL;
		$row['officialname'] = NULL;
		$row['swiftcode'] = NULL;
		$row['profilevalidated'] = NULL;
		$row['profilevalidationdate'] = NULL;
		$row['industry'] = NULL;
		$row['legalstructure'] = NULL;
		$row['extendedfields'] = NULL;
		return $row;
	}

	// Load old record
	protected function loadOldRecord()
	{

		// Load key values from Session
		$validKey = TRUE;
		if (strval($this->getKey("_userid")) != "")
			$this->_userid->OldValue = $this->getKey("_userid"); // userid
		else
			$validKey = FALSE;

		// Load old record
		$this->OldRecordset = NULL;
		if ($validKey) {
			$this->CurrentFilter = $this->getRecordFilter();
			$sql = $this->getCurrentSql();
			$conn = $this->getConnection();
			$this->OldRecordset = LoadRecordset($sql, $conn);
		}
		$this->loadRowValues($this->OldRecordset); // Load row values
		return $validKey;
	}

	// Render row values based on field settings
	public function renderRow()
	{
		global $Security, $Language, $CurrentLanguage;

		// Initialize URLs
		// Convert decimal values if posted back

		if ($this->taxamount->FormValue == $this->taxamount->CurrentValue && is_numeric(ConvertToFloatString($this->taxamount->CurrentValue)))
			$this->taxamount->CurrentValue = ConvertToFloatString($this->taxamount->CurrentValue);

		// Call Row_Rendering event
		$this->Row_Rendering();

		// Common render codes for all row types
		// userid
		// changed
		// active
		// tipallowed
		// merchanttoaddtip
		// pis
		// ratetabletype
		// ratetableid
		// officialdocnumber
		// officialdocname
		// businessname
		// softposid
		// taxamount
		// variabletax
		// logofilename
		// returndays
		// memberextrafieldsid
		// lastupdatedate
		// remmitancetype
		// withholdingtaxaccount
		// businessphoneno
		// businessaddress1
		// businessaddress2
		// businesscity
		// businessstate
		// businesscountry
		// businesszipcode
		// bankname
		// bankbranchnumber
		// bankaccountnumber
		// other1
		// other2
		// other3
		// externalid
		// couponpin
		// officialname
		// swiftcode
		// profilevalidated
		// profilevalidationdate
		// industry
		// legalstructure
		// extendedfields

		if ($this->RowType == ROWTYPE_VIEW) { // View row

			// userid
			$this->_userid->ViewValue = $this->_userid->CurrentValue;
			$this->_userid->ViewValue = FormatNumber($this->_userid->ViewValue, 0, -2, -2, -2);
			$this->_userid->ViewCustomAttributes = "";

			// changed
			$this->changed->ViewValue = $this->changed->CurrentValue;
			$this->changed->ViewValue = FormatNumber($this->changed->ViewValue, 0, -2, -2, -2);
			$this->changed->ViewCustomAttributes = "";

			// active
			$this->active->ViewValue = $this->active->CurrentValue;
			$this->active->ViewValue = FormatNumber($this->active->ViewValue, 0, -2, -2, -2);
			$this->active->ViewCustomAttributes = "";

			// tipallowed
			$this->tipallowed->ViewValue = $this->tipallowed->CurrentValue;
			$this->tipallowed->ViewValue = FormatNumber($this->tipallowed->ViewValue, 0, -2, -2, -2);
			$this->tipallowed->ViewCustomAttributes = "";

			// merchanttoaddtip
			$this->merchanttoaddtip->ViewValue = $this->merchanttoaddtip->CurrentValue;
			$this->merchanttoaddtip->ViewValue = FormatNumber($this->merchanttoaddtip->ViewValue, 0, -2, -2, -2);
			$this->merchanttoaddtip->ViewCustomAttributes = "";

			// pis
			$this->pis->ViewValue = $this->pis->CurrentValue;
			$this->pis->ViewCustomAttributes = "";

			// ratetabletype
			$this->ratetabletype->ViewValue = $this->ratetabletype->CurrentValue;
			$this->ratetabletype->ViewValue = FormatNumber($this->ratetabletype->ViewValue, 0, -2, -2, -2);
			$this->ratetabletype->ViewCustomAttributes = "";

			// ratetableid
			$this->ratetableid->ViewValue = $this->ratetableid->CurrentValue;
			$this->ratetableid->ViewValue = FormatNumber($this->ratetableid->ViewValue, 0, -2, -2, -2);
			$this->ratetableid->ViewCustomAttributes = "";

			// officialdocnumber
			$this->officialdocnumber->ViewValue = $this->officialdocnumber->CurrentValue;
			$this->officialdocnumber->ViewCustomAttributes = "";

			// officialdocname
			$this->officialdocname->ViewValue = $this->officialdocname->CurrentValue;
			$this->officialdocname->ViewCustomAttributes = "";

			// businessname
			$this->businessname->ViewValue = $this->businessname->CurrentValue;
			$this->businessname->ViewCustomAttributes = "";

			// softposid
			$this->softposid->ViewValue = $this->softposid->CurrentValue;
			$this->softposid->ViewCustomAttributes = "";

			// taxamount
			$this->taxamount->ViewValue = $this->taxamount->CurrentValue;
			$this->taxamount->ViewValue = FormatNumber($this->taxamount->ViewValue, 2, -2, -2, -2);
			$this->taxamount->ViewCustomAttributes = "";

			// variabletax
			$this->variabletax->ViewValue = $this->variabletax->CurrentValue;
			$this->variabletax->ViewValue = FormatNumber($this->variabletax->ViewValue, 0, -2, -2, -2);
			$this->variabletax->ViewCustomAttributes = "";

			// logofilename
			$this->logofilename->ViewValue = $this->logofilename->CurrentValue;
			$this->logofilename->ViewCustomAttributes = "";

			// returndays
			$this->returndays->ViewValue = $this->returndays->CurrentValue;
			$this->returndays->ViewValue = FormatNumber($this->returndays->ViewValue, 0, -2, -2, -2);
			$this->returndays->ViewCustomAttributes = "";

			// memberextrafieldsid
			$this->memberextrafieldsid->ViewValue = $this->memberextrafieldsid->CurrentValue;
			$this->memberextrafieldsid->ViewValue = FormatNumber($this->memberextrafieldsid->ViewValue, 0, -2, -2, -2);
			$this->memberextrafieldsid->ViewCustomAttributes = "";

			// lastupdatedate
			$this->lastupdatedate->ViewValue = $this->lastupdatedate->CurrentValue;
			$this->lastupdatedate->ViewValue = FormatDateTime($this->lastupdatedate->ViewValue, 0);
			$this->lastupdatedate->ViewCustomAttributes = "";

			// remmitancetype
			$this->remmitancetype->ViewValue = $this->remmitancetype->CurrentValue;
			$this->remmitancetype->ViewValue = FormatNumber($this->remmitancetype->ViewValue, 0, -2, -2, -2);
			$this->remmitancetype->ViewCustomAttributes = "";

			// withholdingtaxaccount
			$this->withholdingtaxaccount->ViewValue = $this->withholdingtaxaccount->CurrentValue;
			$this->withholdingtaxaccount->ViewValue = FormatNumber($this->withholdingtaxaccount->ViewValue, 0, -2, -2, -2);
			$this->withholdingtaxaccount->ViewCustomAttributes = "";

			// businessphoneno
			$this->businessphoneno->ViewValue = $this->businessphoneno->CurrentValue;
			$this->businessphoneno->ViewCustomAttributes = "";

			// businessaddress1
			$this->businessaddress1->ViewValue = $this->businessaddress1->CurrentValue;
			$this->businessaddress1->ViewCustomAttributes = "";

			// businessaddress2
			$this->businessaddress2->ViewValue = $this->businessaddress2->CurrentValue;
			$this->businessaddress2->ViewCustomAttributes = "";

			// businesscity
			$this->businesscity->ViewValue = $this->businesscity->CurrentValue;
			$this->businesscity->ViewCustomAttributes = "";

			// businessstate
			$this->businessstate->ViewValue = $this->businessstate->CurrentValue;
			$this->businessstate->ViewCustomAttributes = "";

			// businesscountry
			$this->businesscountry->ViewValue = $this->businesscountry->CurrentValue;
			$this->businesscountry->ViewCustomAttributes = "";

			// businesszipcode
			$this->businesszipcode->ViewValue = $this->businesszipcode->CurrentValue;
			$this->businesszipcode->ViewCustomAttributes = "";

			// bankname
			$this->bankname->ViewValue = $this->bankname->CurrentValue;
			$this->bankname->ViewCustomAttributes = "";

			// bankbranchnumber
			$this->bankbranchnumber->ViewValue = $this->bankbranchnumber->CurrentValue;
			$this->bankbranchnumber->ViewCustomAttributes = "";

			// bankaccountnumber
			$this->bankaccountnumber->ViewValue = $this->bankaccountnumber->CurrentValue;
			$this->bankaccountnumber->ViewCustomAttributes = "";

			// other1
			$this->other1->ViewValue = $this->other1->CurrentValue;
			$this->other1->ViewCustomAttributes = "";

			// other2
			$this->other2->ViewValue = $this->other2->CurrentValue;
			$this->other2->ViewCustomAttributes = "";

			// other3
			$this->other3->ViewValue = $this->other3->CurrentValue;
			$this->other3->ViewCustomAttributes = "";

			// externalid
			$this->externalid->ViewValue = $this->externalid->CurrentValue;
			$this->externalid->ViewCustomAttributes = "";

			// couponpin
			$this->couponpin->ViewValue = $this->couponpin->CurrentValue;
			$this->couponpin->ViewCustomAttributes = "";

			// officialname
			$this->officialname->ViewValue = $this->officialname->CurrentValue;
			$this->officialname->ViewCustomAttributes = "";

			// swiftcode
			$this->swiftcode->ViewValue = $this->swiftcode->CurrentValue;
			$this->swiftcode->ViewCustomAttributes = "";

			// profilevalidated
			$this->profilevalidated->ViewValue = $this->profilevalidated->CurrentValue;
			$this->profilevalidated->ViewValue = FormatNumber($this->profilevalidated->ViewValue, 0, -2, -2, -2);
			$this->profilevalidated->ViewCustomAttributes = "";

			// profilevalidationdate
			$this->profilevalidationdate->ViewValue = $this->profilevalidationdate->CurrentValue;
			$this->profilevalidationdate->ViewValue = FormatDateTime($this->profilevalidationdate->ViewValue, 0);
			$this->profilevalidationdate->ViewCustomAttributes = "";

			// industry
			$this->industry->ViewValue = $this->industry->CurrentValue;
			$this->industry->ViewCustomAttributes = "";

			// legalstructure
			$this->legalstructure->ViewValue = $this->legalstructure->CurrentValue;
			$this->legalstructure->ViewCustomAttributes = "";

			// extendedfields
			$this->extendedfields->ViewValue = $this->extendedfields->CurrentValue;
			$this->extendedfields->ViewCustomAttributes = "";

			// userid
			$this->_userid->LinkCustomAttributes = "";
			$this->_userid->HrefValue = "";
			$this->_userid->TooltipValue = "";

			// changed
			$this->changed->LinkCustomAttributes = "";
			$this->changed->HrefValue = "";
			$this->changed->TooltipValue = "";

			// active
			$this->active->LinkCustomAttributes = "";
			$this->active->HrefValue = "";
			$this->active->TooltipValue = "";

			// tipallowed
			$this->tipallowed->LinkCustomAttributes = "";
			$this->tipallowed->HrefValue = "";
			$this->tipallowed->TooltipValue = "";

			// merchanttoaddtip
			$this->merchanttoaddtip->LinkCustomAttributes = "";
			$this->merchanttoaddtip->HrefValue = "";
			$this->merchanttoaddtip->TooltipValue = "";

			// pis
			$this->pis->LinkCustomAttributes = "";
			$this->pis->HrefValue = "";
			$this->pis->TooltipValue = "";

			// ratetabletype
			$this->ratetabletype->LinkCustomAttributes = "";
			$this->ratetabletype->HrefValue = "";
			$this->ratetabletype->TooltipValue = "";

			// ratetableid
			$this->ratetableid->LinkCustomAttributes = "";
			$this->ratetableid->HrefValue = "";
			$this->ratetableid->TooltipValue = "";

			// officialdocnumber
			$this->officialdocnumber->LinkCustomAttributes = "";
			$this->officialdocnumber->HrefValue = "";
			$this->officialdocnumber->TooltipValue = "";

			// officialdocname
			$this->officialdocname->LinkCustomAttributes = "";
			$this->officialdocname->HrefValue = "";
			$this->officialdocname->TooltipValue = "";

			// businessname
			$this->businessname->LinkCustomAttributes = "";
			$this->businessname->HrefValue = "";
			$this->businessname->TooltipValue = "";

			// softposid
			$this->softposid->LinkCustomAttributes = "";
			$this->softposid->HrefValue = "";
			$this->softposid->TooltipValue = "";

			// taxamount
			$this->taxamount->LinkCustomAttributes = "";
			$this->taxamount->HrefValue = "";
			$this->taxamount->TooltipValue = "";

			// variabletax
			$this->variabletax->LinkCustomAttributes = "";
			$this->variabletax->HrefValue = "";
			$this->variabletax->TooltipValue = "";

			// logofilename
			$this->logofilename->LinkCustomAttributes = "";
			$this->logofilename->HrefValue = "";
			$this->logofilename->TooltipValue = "";

			// returndays
			$this->returndays->LinkCustomAttributes = "";
			$this->returndays->HrefValue = "";
			$this->returndays->TooltipValue = "";

			// memberextrafieldsid
			$this->memberextrafieldsid->LinkCustomAttributes = "";
			$this->memberextrafieldsid->HrefValue = "";
			$this->memberextrafieldsid->TooltipValue = "";

			// lastupdatedate
			$this->lastupdatedate->LinkCustomAttributes = "";
			$this->lastupdatedate->HrefValue = "";
			$this->lastupdatedate->TooltipValue = "";

			// remmitancetype
			$this->remmitancetype->LinkCustomAttributes = "";
			$this->remmitancetype->HrefValue = "";
			$this->remmitancetype->TooltipValue = "";

			// withholdingtaxaccount
			$this->withholdingtaxaccount->LinkCustomAttributes = "";
			$this->withholdingtaxaccount->HrefValue = "";
			$this->withholdingtaxaccount->TooltipValue = "";

			// businessphoneno
			$this->businessphoneno->LinkCustomAttributes = "";
			$this->businessphoneno->HrefValue = "";
			$this->businessphoneno->TooltipValue = "";

			// businessaddress1
			$this->businessaddress1->LinkCustomAttributes = "";
			$this->businessaddress1->HrefValue = "";
			$this->businessaddress1->TooltipValue = "";

			// businessaddress2
			$this->businessaddress2->LinkCustomAttributes = "";
			$this->businessaddress2->HrefValue = "";
			$this->businessaddress2->TooltipValue = "";

			// businesscity
			$this->businesscity->LinkCustomAttributes = "";
			$this->businesscity->HrefValue = "";
			$this->businesscity->TooltipValue = "";

			// businessstate
			$this->businessstate->LinkCustomAttributes = "";
			$this->businessstate->HrefValue = "";
			$this->businessstate->TooltipValue = "";

			// businesscountry
			$this->businesscountry->LinkCustomAttributes = "";
			$this->businesscountry->HrefValue = "";
			$this->businesscountry->TooltipValue = "";

			// businesszipcode
			$this->businesszipcode->LinkCustomAttributes = "";
			$this->businesszipcode->HrefValue = "";
			$this->businesszipcode->TooltipValue = "";

			// bankname
			$this->bankname->LinkCustomAttributes = "";
			$this->bankname->HrefValue = "";
			$this->bankname->TooltipValue = "";

			// bankbranchnumber
			$this->bankbranchnumber->LinkCustomAttributes = "";
			$this->bankbranchnumber->HrefValue = "";
			$this->bankbranchnumber->TooltipValue = "";

			// bankaccountnumber
			$this->bankaccountnumber->LinkCustomAttributes = "";
			$this->bankaccountnumber->HrefValue = "";
			$this->bankaccountnumber->TooltipValue = "";

			// other1
			$this->other1->LinkCustomAttributes = "";
			$this->other1->HrefValue = "";
			$this->other1->TooltipValue = "";

			// other2
			$this->other2->LinkCustomAttributes = "";
			$this->other2->HrefValue = "";
			$this->other2->TooltipValue = "";

			// other3
			$this->other3->LinkCustomAttributes = "";
			$this->other3->HrefValue = "";
			$this->other3->TooltipValue = "";

			// externalid
			$this->externalid->LinkCustomAttributes = "";
			$this->externalid->HrefValue = "";
			$this->externalid->TooltipValue = "";

			// couponpin
			$this->couponpin->LinkCustomAttributes = "";
			$this->couponpin->HrefValue = "";
			$this->couponpin->TooltipValue = "";

			// officialname
			$this->officialname->LinkCustomAttributes = "";
			$this->officialname->HrefValue = "";
			$this->officialname->TooltipValue = "";

			// swiftcode
			$this->swiftcode->LinkCustomAttributes = "";
			$this->swiftcode->HrefValue = "";
			$this->swiftcode->TooltipValue = "";

			// profilevalidated
			$this->profilevalidated->LinkCustomAttributes = "";
			$this->profilevalidated->HrefValue = "";
			$this->profilevalidated->TooltipValue = "";

			// profilevalidationdate
			$this->profilevalidationdate->LinkCustomAttributes = "";
			$this->profilevalidationdate->HrefValue = "";
			$this->profilevalidationdate->TooltipValue = "";

			// industry
			$this->industry->LinkCustomAttributes = "";
			$this->industry->HrefValue = "";
			$this->industry->TooltipValue = "";

			// legalstructure
			$this->legalstructure->LinkCustomAttributes = "";
			$this->legalstructure->HrefValue = "";
			$this->legalstructure->TooltipValue = "";

			// extendedfields
			$this->extendedfields->LinkCustomAttributes = "";
			$this->extendedfields->HrefValue = "";
			$this->extendedfields->TooltipValue = "";
		} elseif ($this->RowType == ROWTYPE_EDIT) { // Edit row

			// userid
			$this->_userid->EditAttrs["class"] = "form-control";
			$this->_userid->EditCustomAttributes = "";
			$this->_userid->EditValue = HtmlEncode($this->_userid->CurrentValue);
			$this->_userid->PlaceHolder = RemoveHtml($this->_userid->caption());

			// changed
			$this->changed->EditAttrs["class"] = "form-control";
			$this->changed->EditCustomAttributes = "";
			$this->changed->EditValue = HtmlEncode($this->changed->CurrentValue);
			$this->changed->PlaceHolder = RemoveHtml($this->changed->caption());

			// active
			$this->active->EditAttrs["class"] = "form-control";
			$this->active->EditCustomAttributes = "";
			$this->active->EditValue = HtmlEncode($this->active->CurrentValue);
			$this->active->PlaceHolder = RemoveHtml($this->active->caption());

			// tipallowed
			$this->tipallowed->EditAttrs["class"] = "form-control";
			$this->tipallowed->EditCustomAttributes = "";
			$this->tipallowed->EditValue = HtmlEncode($this->tipallowed->CurrentValue);
			$this->tipallowed->PlaceHolder = RemoveHtml($this->tipallowed->caption());

			// merchanttoaddtip
			$this->merchanttoaddtip->EditAttrs["class"] = "form-control";
			$this->merchanttoaddtip->EditCustomAttributes = "";
			$this->merchanttoaddtip->EditValue = HtmlEncode($this->merchanttoaddtip->CurrentValue);
			$this->merchanttoaddtip->PlaceHolder = RemoveHtml($this->merchanttoaddtip->caption());

			// pis
			$this->pis->EditAttrs["class"] = "form-control";
			$this->pis->EditCustomAttributes = "";
			if (!$this->pis->Raw)
				$this->pis->CurrentValue = HtmlDecode($this->pis->CurrentValue);
			$this->pis->EditValue = HtmlEncode($this->pis->CurrentValue);
			$this->pis->PlaceHolder = RemoveHtml($this->pis->caption());

			// ratetabletype
			$this->ratetabletype->EditAttrs["class"] = "form-control";
			$this->ratetabletype->EditCustomAttributes = "";
			$this->ratetabletype->EditValue = HtmlEncode($this->ratetabletype->CurrentValue);
			$this->ratetabletype->PlaceHolder = RemoveHtml($this->ratetabletype->caption());

			// ratetableid
			$this->ratetableid->EditAttrs["class"] = "form-control";
			$this->ratetableid->EditCustomAttributes = "";
			$this->ratetableid->EditValue = HtmlEncode($this->ratetableid->CurrentValue);
			$this->ratetableid->PlaceHolder = RemoveHtml($this->ratetableid->caption());

			// officialdocnumber
			$this->officialdocnumber->EditAttrs["class"] = "form-control";
			$this->officialdocnumber->EditCustomAttributes = "";
			if (!$this->officialdocnumber->Raw)
				$this->officialdocnumber->CurrentValue = HtmlDecode($this->officialdocnumber->CurrentValue);
			$this->officialdocnumber->EditValue = HtmlEncode($this->officialdocnumber->CurrentValue);
			$this->officialdocnumber->PlaceHolder = RemoveHtml($this->officialdocnumber->caption());

			// officialdocname
			$this->officialdocname->EditAttrs["class"] = "form-control";
			$this->officialdocname->EditCustomAttributes = "";
			if (!$this->officialdocname->Raw)
				$this->officialdocname->CurrentValue = HtmlDecode($this->officialdocname->CurrentValue);
			$this->officialdocname->EditValue = HtmlEncode($this->officialdocname->CurrentValue);
			$this->officialdocname->PlaceHolder = RemoveHtml($this->officialdocname->caption());

			// businessname
			$this->businessname->EditAttrs["class"] = "form-control";
			$this->businessname->EditCustomAttributes = "";
			if (!$this->businessname->Raw)
				$this->businessname->CurrentValue = HtmlDecode($this->businessname->CurrentValue);
			$this->businessname->EditValue = HtmlEncode($this->businessname->CurrentValue);
			$this->businessname->PlaceHolder = RemoveHtml($this->businessname->caption());

			// softposid
			$this->softposid->EditAttrs["class"] = "form-control";
			$this->softposid->EditCustomAttributes = "";
			if (!$this->softposid->Raw)
				$this->softposid->CurrentValue = HtmlDecode($this->softposid->CurrentValue);
			$this->softposid->EditValue = HtmlEncode($this->softposid->CurrentValue);
			$this->softposid->PlaceHolder = RemoveHtml($this->softposid->caption());

			// taxamount
			$this->taxamount->EditAttrs["class"] = "form-control";
			$this->taxamount->EditCustomAttributes = "";
			$this->taxamount->EditValue = HtmlEncode($this->taxamount->CurrentValue);
			$this->taxamount->PlaceHolder = RemoveHtml($this->taxamount->caption());
			if (strval($this->taxamount->EditValue) != "" && is_numeric($this->taxamount->EditValue))
				$this->taxamount->EditValue = FormatNumber($this->taxamount->EditValue, -2, -2, -2, -2);
			

			// variabletax
			$this->variabletax->EditAttrs["class"] = "form-control";
			$this->variabletax->EditCustomAttributes = "";
			$this->variabletax->EditValue = HtmlEncode($this->variabletax->CurrentValue);
			$this->variabletax->PlaceHolder = RemoveHtml($this->variabletax->caption());

			// logofilename
			$this->logofilename->EditAttrs["class"] = "form-control";
			$this->logofilename->EditCustomAttributes = "";
			if (!$this->logofilename->Raw)
				$this->logofilename->CurrentValue = HtmlDecode($this->logofilename->CurrentValue);
			$this->logofilename->EditValue = HtmlEncode($this->logofilename->CurrentValue);
			$this->logofilename->PlaceHolder = RemoveHtml($this->logofilename->caption());

			// returndays
			$this->returndays->EditAttrs["class"] = "form-control";
			$this->returndays->EditCustomAttributes = "";
			$this->returndays->EditValue = HtmlEncode($this->returndays->CurrentValue);
			$this->returndays->PlaceHolder = RemoveHtml($this->returndays->caption());

			// memberextrafieldsid
			$this->memberextrafieldsid->EditAttrs["class"] = "form-control";
			$this->memberextrafieldsid->EditCustomAttributes = "";
			$this->memberextrafieldsid->EditValue = HtmlEncode($this->memberextrafieldsid->CurrentValue);
			$this->memberextrafieldsid->PlaceHolder = RemoveHtml($this->memberextrafieldsid->caption());

			// lastupdatedate
			$this->lastupdatedate->EditAttrs["class"] = "form-control";
			$this->lastupdatedate->EditCustomAttributes = "";
			$this->lastupdatedate->EditValue = HtmlEncode(FormatDateTime($this->lastupdatedate->CurrentValue, 8));
			$this->lastupdatedate->PlaceHolder = RemoveHtml($this->lastupdatedate->caption());

			// remmitancetype
			$this->remmitancetype->EditAttrs["class"] = "form-control";
			$this->remmitancetype->EditCustomAttributes = "";
			$this->remmitancetype->EditValue = HtmlEncode($this->remmitancetype->CurrentValue);
			$this->remmitancetype->PlaceHolder = RemoveHtml($this->remmitancetype->caption());

			// withholdingtaxaccount
			$this->withholdingtaxaccount->EditAttrs["class"] = "form-control";
			$this->withholdingtaxaccount->EditCustomAttributes = "";
			$this->withholdingtaxaccount->EditValue = HtmlEncode($this->withholdingtaxaccount->CurrentValue);
			$this->withholdingtaxaccount->PlaceHolder = RemoveHtml($this->withholdingtaxaccount->caption());

			// businessphoneno
			$this->businessphoneno->EditAttrs["class"] = "form-control";
			$this->businessphoneno->EditCustomAttributes = "";
			if (!$this->businessphoneno->Raw)
				$this->businessphoneno->CurrentValue = HtmlDecode($this->businessphoneno->CurrentValue);
			$this->businessphoneno->EditValue = HtmlEncode($this->businessphoneno->CurrentValue);
			$this->businessphoneno->PlaceHolder = RemoveHtml($this->businessphoneno->caption());

			// businessaddress1
			$this->businessaddress1->EditAttrs["class"] = "form-control";
			$this->businessaddress1->EditCustomAttributes = "";
			if (!$this->businessaddress1->Raw)
				$this->businessaddress1->CurrentValue = HtmlDecode($this->businessaddress1->CurrentValue);
			$this->businessaddress1->EditValue = HtmlEncode($this->businessaddress1->CurrentValue);
			$this->businessaddress1->PlaceHolder = RemoveHtml($this->businessaddress1->caption());

			// businessaddress2
			$this->businessaddress2->EditAttrs["class"] = "form-control";
			$this->businessaddress2->EditCustomAttributes = "";
			if (!$this->businessaddress2->Raw)
				$this->businessaddress2->CurrentValue = HtmlDecode($this->businessaddress2->CurrentValue);
			$this->businessaddress2->EditValue = HtmlEncode($this->businessaddress2->CurrentValue);
			$this->businessaddress2->PlaceHolder = RemoveHtml($this->businessaddress2->caption());

			// businesscity
			$this->businesscity->EditAttrs["class"] = "form-control";
			$this->businesscity->EditCustomAttributes = "";
			if (!$this->businesscity->Raw)
				$this->businesscity->CurrentValue = HtmlDecode($this->businesscity->CurrentValue);
			$this->businesscity->EditValue = HtmlEncode($this->businesscity->CurrentValue);
			$this->businesscity->PlaceHolder = RemoveHtml($this->businesscity->caption());

			// businessstate
			$this->businessstate->EditAttrs["class"] = "form-control";
			$this->businessstate->EditCustomAttributes = "";
			if (!$this->businessstate->Raw)
				$this->businessstate->CurrentValue = HtmlDecode($this->businessstate->CurrentValue);
			$this->businessstate->EditValue = HtmlEncode($this->businessstate->CurrentValue);
			$this->businessstate->PlaceHolder = RemoveHtml($this->businessstate->caption());

			// businesscountry
			$this->businesscountry->EditAttrs["class"] = "form-control";
			$this->businesscountry->EditCustomAttributes = "";
			if (!$this->businesscountry->Raw)
				$this->businesscountry->CurrentValue = HtmlDecode($this->businesscountry->CurrentValue);
			$this->businesscountry->EditValue = HtmlEncode($this->businesscountry->CurrentValue);
			$this->businesscountry->PlaceHolder = RemoveHtml($this->businesscountry->caption());

			// businesszipcode
			$this->businesszipcode->EditAttrs["class"] = "form-control";
			$this->businesszipcode->EditCustomAttributes = "";
			if (!$this->businesszipcode->Raw)
				$this->businesszipcode->CurrentValue = HtmlDecode($this->businesszipcode->CurrentValue);
			$this->businesszipcode->EditValue = HtmlEncode($this->businesszipcode->CurrentValue);
			$this->businesszipcode->PlaceHolder = RemoveHtml($this->businesszipcode->caption());

			// bankname
			$this->bankname->EditAttrs["class"] = "form-control";
			$this->bankname->EditCustomAttributes = "";
			if (!$this->bankname->Raw)
				$this->bankname->CurrentValue = HtmlDecode($this->bankname->CurrentValue);
			$this->bankname->EditValue = HtmlEncode($this->bankname->CurrentValue);
			$this->bankname->PlaceHolder = RemoveHtml($this->bankname->caption());

			// bankbranchnumber
			$this->bankbranchnumber->EditAttrs["class"] = "form-control";
			$this->bankbranchnumber->EditCustomAttributes = "";
			if (!$this->bankbranchnumber->Raw)
				$this->bankbranchnumber->CurrentValue = HtmlDecode($this->bankbranchnumber->CurrentValue);
			$this->bankbranchnumber->EditValue = HtmlEncode($this->bankbranchnumber->CurrentValue);
			$this->bankbranchnumber->PlaceHolder = RemoveHtml($this->bankbranchnumber->caption());

			// bankaccountnumber
			$this->bankaccountnumber->EditAttrs["class"] = "form-control";
			$this->bankaccountnumber->EditCustomAttributes = "";
			if (!$this->bankaccountnumber->Raw)
				$this->bankaccountnumber->CurrentValue = HtmlDecode($this->bankaccountnumber->CurrentValue);
			$this->bankaccountnumber->EditValue = HtmlEncode($this->bankaccountnumber->CurrentValue);
			$this->bankaccountnumber->PlaceHolder = RemoveHtml($this->bankaccountnumber->caption());

			// other1
			$this->other1->EditAttrs["class"] = "form-control";
			$this->other1->EditCustomAttributes = "";
			$this->other1->EditValue = HtmlEncode($this->other1->CurrentValue);
			$this->other1->PlaceHolder = RemoveHtml($this->other1->caption());

			// other2
			$this->other2->EditAttrs["class"] = "form-control";
			$this->other2->EditCustomAttributes = "";
			if (!$this->other2->Raw)
				$this->other2->CurrentValue = HtmlDecode($this->other2->CurrentValue);
			$this->other2->EditValue = HtmlEncode($this->other2->CurrentValue);
			$this->other2->PlaceHolder = RemoveHtml($this->other2->caption());

			// other3
			$this->other3->EditAttrs["class"] = "form-control";
			$this->other3->EditCustomAttributes = "";
			if (!$this->other3->Raw)
				$this->other3->CurrentValue = HtmlDecode($this->other3->CurrentValue);
			$this->other3->EditValue = HtmlEncode($this->other3->CurrentValue);
			$this->other3->PlaceHolder = RemoveHtml($this->other3->caption());

			// externalid
			$this->externalid->EditAttrs["class"] = "form-control";
			$this->externalid->EditCustomAttributes = "";
			if (!$this->externalid->Raw)
				$this->externalid->CurrentValue = HtmlDecode($this->externalid->CurrentValue);
			$this->externalid->EditValue = HtmlEncode($this->externalid->CurrentValue);
			$this->externalid->PlaceHolder = RemoveHtml($this->externalid->caption());

			// couponpin
			$this->couponpin->EditAttrs["class"] = "form-control";
			$this->couponpin->EditCustomAttributes = "";
			if (!$this->couponpin->Raw)
				$this->couponpin->CurrentValue = HtmlDecode($this->couponpin->CurrentValue);
			$this->couponpin->EditValue = HtmlEncode($this->couponpin->CurrentValue);
			$this->couponpin->PlaceHolder = RemoveHtml($this->couponpin->caption());

			// officialname
			$this->officialname->EditAttrs["class"] = "form-control";
			$this->officialname->EditCustomAttributes = "";
			if (!$this->officialname->Raw)
				$this->officialname->CurrentValue = HtmlDecode($this->officialname->CurrentValue);
			$this->officialname->EditValue = HtmlEncode($this->officialname->CurrentValue);
			$this->officialname->PlaceHolder = RemoveHtml($this->officialname->caption());

			// swiftcode
			$this->swiftcode->EditAttrs["class"] = "form-control";
			$this->swiftcode->EditCustomAttributes = "";
			if (!$this->swiftcode->Raw)
				$this->swiftcode->CurrentValue = HtmlDecode($this->swiftcode->CurrentValue);
			$this->swiftcode->EditValue = HtmlEncode($this->swiftcode->CurrentValue);
			$this->swiftcode->PlaceHolder = RemoveHtml($this->swiftcode->caption());

			// profilevalidated
			$this->profilevalidated->EditAttrs["class"] = "form-control";
			$this->profilevalidated->EditCustomAttributes = "";
			$this->profilevalidated->EditValue = HtmlEncode($this->profilevalidated->CurrentValue);
			$this->profilevalidated->PlaceHolder = RemoveHtml($this->profilevalidated->caption());

			// profilevalidationdate
			$this->profilevalidationdate->EditAttrs["class"] = "form-control";
			$this->profilevalidationdate->EditCustomAttributes = "";
			$this->profilevalidationdate->EditValue = HtmlEncode(FormatDateTime($this->profilevalidationdate->CurrentValue, 8));
			$this->profilevalidationdate->PlaceHolder = RemoveHtml($this->profilevalidationdate->caption());

			// industry
			$this->industry->EditAttrs["class"] = "form-control";
			$this->industry->EditCustomAttributes = "";
			if (!$this->industry->Raw)
				$this->industry->CurrentValue = HtmlDecode($this->industry->CurrentValue);
			$this->industry->EditValue = HtmlEncode($this->industry->CurrentValue);
			$this->industry->PlaceHolder = RemoveHtml($this->industry->caption());

			// legalstructure
			$this->legalstructure->EditAttrs["class"] = "form-control";
			$this->legalstructure->EditCustomAttributes = "";
			if (!$this->legalstructure->Raw)
				$this->legalstructure->CurrentValue = HtmlDecode($this->legalstructure->CurrentValue);
			$this->legalstructure->EditValue = HtmlEncode($this->legalstructure->CurrentValue);
			$this->legalstructure->PlaceHolder = RemoveHtml($this->legalstructure->caption());

			// extendedfields
			$this->extendedfields->EditAttrs["class"] = "form-control";
			$this->extendedfields->EditCustomAttributes = "";
			$this->extendedfields->EditValue = HtmlEncode($this->extendedfields->CurrentValue);
			$this->extendedfields->PlaceHolder = RemoveHtml($this->extendedfields->caption());

			// Edit refer script
			// userid

			$this->_userid->LinkCustomAttributes = "";
			$this->_userid->HrefValue = "";

			// changed
			$this->changed->LinkCustomAttributes = "";
			$this->changed->HrefValue = "";

			// active
			$this->active->LinkCustomAttributes = "";
			$this->active->HrefValue = "";

			// tipallowed
			$this->tipallowed->LinkCustomAttributes = "";
			$this->tipallowed->HrefValue = "";

			// merchanttoaddtip
			$this->merchanttoaddtip->LinkCustomAttributes = "";
			$this->merchanttoaddtip->HrefValue = "";

			// pis
			$this->pis->LinkCustomAttributes = "";
			$this->pis->HrefValue = "";

			// ratetabletype
			$this->ratetabletype->LinkCustomAttributes = "";
			$this->ratetabletype->HrefValue = "";

			// ratetableid
			$this->ratetableid->LinkCustomAttributes = "";
			$this->ratetableid->HrefValue = "";

			// officialdocnumber
			$this->officialdocnumber->LinkCustomAttributes = "";
			$this->officialdocnumber->HrefValue = "";

			// officialdocname
			$this->officialdocname->LinkCustomAttributes = "";
			$this->officialdocname->HrefValue = "";

			// businessname
			$this->businessname->LinkCustomAttributes = "";
			$this->businessname->HrefValue = "";

			// softposid
			$this->softposid->LinkCustomAttributes = "";
			$this->softposid->HrefValue = "";

			// taxamount
			$this->taxamount->LinkCustomAttributes = "";
			$this->taxamount->HrefValue = "";

			// variabletax
			$this->variabletax->LinkCustomAttributes = "";
			$this->variabletax->HrefValue = "";

			// logofilename
			$this->logofilename->LinkCustomAttributes = "";
			$this->logofilename->HrefValue = "";

			// returndays
			$this->returndays->LinkCustomAttributes = "";
			$this->returndays->HrefValue = "";

			// memberextrafieldsid
			$this->memberextrafieldsid->LinkCustomAttributes = "";
			$this->memberextrafieldsid->HrefValue = "";

			// lastupdatedate
			$this->lastupdatedate->LinkCustomAttributes = "";
			$this->lastupdatedate->HrefValue = "";

			// remmitancetype
			$this->remmitancetype->LinkCustomAttributes = "";
			$this->remmitancetype->HrefValue = "";

			// withholdingtaxaccount
			$this->withholdingtaxaccount->LinkCustomAttributes = "";
			$this->withholdingtaxaccount->HrefValue = "";

			// businessphoneno
			$this->businessphoneno->LinkCustomAttributes = "";
			$this->businessphoneno->HrefValue = "";

			// businessaddress1
			$this->businessaddress1->LinkCustomAttributes = "";
			$this->businessaddress1->HrefValue = "";

			// businessaddress2
			$this->businessaddress2->LinkCustomAttributes = "";
			$this->businessaddress2->HrefValue = "";

			// businesscity
			$this->businesscity->LinkCustomAttributes = "";
			$this->businesscity->HrefValue = "";

			// businessstate
			$this->businessstate->LinkCustomAttributes = "";
			$this->businessstate->HrefValue = "";

			// businesscountry
			$this->businesscountry->LinkCustomAttributes = "";
			$this->businesscountry->HrefValue = "";

			// businesszipcode
			$this->businesszipcode->LinkCustomAttributes = "";
			$this->businesszipcode->HrefValue = "";

			// bankname
			$this->bankname->LinkCustomAttributes = "";
			$this->bankname->HrefValue = "";

			// bankbranchnumber
			$this->bankbranchnumber->LinkCustomAttributes = "";
			$this->bankbranchnumber->HrefValue = "";

			// bankaccountnumber
			$this->bankaccountnumber->LinkCustomAttributes = "";
			$this->bankaccountnumber->HrefValue = "";

			// other1
			$this->other1->LinkCustomAttributes = "";
			$this->other1->HrefValue = "";

			// other2
			$this->other2->LinkCustomAttributes = "";
			$this->other2->HrefValue = "";

			// other3
			$this->other3->LinkCustomAttributes = "";
			$this->other3->HrefValue = "";

			// externalid
			$this->externalid->LinkCustomAttributes = "";
			$this->externalid->HrefValue = "";

			// couponpin
			$this->couponpin->LinkCustomAttributes = "";
			$this->couponpin->HrefValue = "";

			// officialname
			$this->officialname->LinkCustomAttributes = "";
			$this->officialname->HrefValue = "";

			// swiftcode
			$this->swiftcode->LinkCustomAttributes = "";
			$this->swiftcode->HrefValue = "";

			// profilevalidated
			$this->profilevalidated->LinkCustomAttributes = "";
			$this->profilevalidated->HrefValue = "";

			// profilevalidationdate
			$this->profilevalidationdate->LinkCustomAttributes = "";
			$this->profilevalidationdate->HrefValue = "";

			// industry
			$this->industry->LinkCustomAttributes = "";
			$this->industry->HrefValue = "";

			// legalstructure
			$this->legalstructure->LinkCustomAttributes = "";
			$this->legalstructure->HrefValue = "";

			// extendedfields
			$this->extendedfields->LinkCustomAttributes = "";
			$this->extendedfields->HrefValue = "";
		}
		if ($this->RowType == ROWTYPE_ADD || $this->RowType == ROWTYPE_EDIT || $this->RowType == ROWTYPE_SEARCH) // Add/Edit/Search row
			$this->setupFieldTitles();

		// Call Row Rendered event
		if ($this->RowType != ROWTYPE_AGGREGATEINIT)
			$this->Row_Rendered();
	}

	// Validate form
	protected function validateForm()
	{
		global $Language, $FormError;

		// Initialize form error message
		$FormError = "";

		// Check if validation required
		if (!Config("SERVER_VALIDATE"))
			return ($FormError == "");
		if ($this->_userid->Required) {
			if (!$this->_userid->IsDetailKey && $this->_userid->FormValue != NULL && $this->_userid->FormValue == "") {
				AddMessage($FormError, str_replace("%s", $this->_userid->caption(), $this->_userid->RequiredErrorMessage));
			}
		}
		if (!CheckInteger($this->_userid->FormValue)) {
			AddMessage($FormError, $this->_userid->errorMessage());
		}
		if ($this->changed->Required) {
			if (!$this->changed->IsDetailKey && $this->changed->FormValue != NULL && $this->changed->FormValue == "") {
				AddMessage($FormError, str_replace("%s", $this->changed->caption(), $this->changed->RequiredErrorMessage));
			}
		}
		if (!CheckInteger($this->changed->FormValue)) {
			AddMessage($FormError, $this->changed->errorMessage());
		}
		if ($this->active->Required) {
			if (!$this->active->IsDetailKey && $this->active->FormValue != NULL && $this->active->FormValue == "") {
				AddMessage($FormError, str_replace("%s", $this->active->caption(), $this->active->RequiredErrorMessage));
			}
		}
		if (!CheckInteger($this->active->FormValue)) {
			AddMessage($FormError, $this->active->errorMessage());
		}
		if ($this->tipallowed->Required) {
			if (!$this->tipallowed->IsDetailKey && $this->tipallowed->FormValue != NULL && $this->tipallowed->FormValue == "") {
				AddMessage($FormError, str_replace("%s", $this->tipallowed->caption(), $this->tipallowed->RequiredErrorMessage));
			}
		}
		if (!CheckInteger($this->tipallowed->FormValue)) {
			AddMessage($FormError, $this->tipallowed->errorMessage());
		}
		if ($this->merchanttoaddtip->Required) {
			if (!$this->merchanttoaddtip->IsDetailKey && $this->merchanttoaddtip->FormValue != NULL && $this->merchanttoaddtip->FormValue == "") {
				AddMessage($FormError, str_replace("%s", $this->merchanttoaddtip->caption(), $this->merchanttoaddtip->RequiredErrorMessage));
			}
		}
		if (!CheckInteger($this->merchanttoaddtip->FormValue)) {
			AddMessage($FormError, $this->merchanttoaddtip->errorMessage());
		}
		if ($this->pis->Required) {
			if (!$this->pis->IsDetailKey && $this->pis->FormValue != NULL && $this->pis->FormValue == "") {
				AddMessage($FormError, str_replace("%s", $this->pis->caption(), $this->pis->RequiredErrorMessage));
			}
		}
		if ($this->ratetabletype->Required) {
			if (!$this->ratetabletype->IsDetailKey && $this->ratetabletype->FormValue != NULL && $this->ratetabletype->FormValue == "") {
				AddMessage($FormError, str_replace("%s", $this->ratetabletype->caption(), $this->ratetabletype->RequiredErrorMessage));
			}
		}
		if (!CheckInteger($this->ratetabletype->FormValue)) {
			AddMessage($FormError, $this->ratetabletype->errorMessage());
		}
		if ($this->ratetableid->Required) {
			if (!$this->ratetableid->IsDetailKey && $this->ratetableid->FormValue != NULL && $this->ratetableid->FormValue == "") {
				AddMessage($FormError, str_replace("%s", $this->ratetableid->caption(), $this->ratetableid->RequiredErrorMessage));
			}
		}
		if (!CheckInteger($this->ratetableid->FormValue)) {
			AddMessage($FormError, $this->ratetableid->errorMessage());
		}
		if ($this->officialdocnumber->Required) {
			if (!$this->officialdocnumber->IsDetailKey && $this->officialdocnumber->FormValue != NULL && $this->officialdocnumber->FormValue == "") {
				AddMessage($FormError, str_replace("%s", $this->officialdocnumber->caption(), $this->officialdocnumber->RequiredErrorMessage));
			}
		}
		if ($this->officialdocname->Required) {
			if (!$this->officialdocname->IsDetailKey && $this->officialdocname->FormValue != NULL && $this->officialdocname->FormValue == "") {
				AddMessage($FormError, str_replace("%s", $this->officialdocname->caption(), $this->officialdocname->RequiredErrorMessage));
			}
		}
		if ($this->businessname->Required) {
			if (!$this->businessname->IsDetailKey && $this->businessname->FormValue != NULL && $this->businessname->FormValue == "") {
				AddMessage($FormError, str_replace("%s", $this->businessname->caption(), $this->businessname->RequiredErrorMessage));
			}
		}
		if ($this->softposid->Required) {
			if (!$this->softposid->IsDetailKey && $this->softposid->FormValue != NULL && $this->softposid->FormValue == "") {
				AddMessage($FormError, str_replace("%s", $this->softposid->caption(), $this->softposid->RequiredErrorMessage));
			}
		}
		if ($this->taxamount->Required) {
			if (!$this->taxamount->IsDetailKey && $this->taxamount->FormValue != NULL && $this->taxamount->FormValue == "") {
				AddMessage($FormError, str_replace("%s", $this->taxamount->caption(), $this->taxamount->RequiredErrorMessage));
			}
		}
		if (!CheckNumber($this->taxamount->FormValue)) {
			AddMessage($FormError, $this->taxamount->errorMessage());
		}
		if ($this->variabletax->Required) {
			if (!$this->variabletax->IsDetailKey && $this->variabletax->FormValue != NULL && $this->variabletax->FormValue == "") {
				AddMessage($FormError, str_replace("%s", $this->variabletax->caption(), $this->variabletax->RequiredErrorMessage));
			}
		}
		if (!CheckInteger($this->variabletax->FormValue)) {
			AddMessage($FormError, $this->variabletax->errorMessage());
		}
		if ($this->logofilename->Required) {
			if (!$this->logofilename->IsDetailKey && $this->logofilename->FormValue != NULL && $this->logofilename->FormValue == "") {
				AddMessage($FormError, str_replace("%s", $this->logofilename->caption(), $this->logofilename->RequiredErrorMessage));
			}
		}
		if ($this->returndays->Required) {
			if (!$this->returndays->IsDetailKey && $this->returndays->FormValue != NULL && $this->returndays->FormValue == "") {
				AddMessage($FormError, str_replace("%s", $this->returndays->caption(), $this->returndays->RequiredErrorMessage));
			}
		}
		if (!CheckInteger($this->returndays->FormValue)) {
			AddMessage($FormError, $this->returndays->errorMessage());
		}
		if ($this->memberextrafieldsid->Required) {
			if (!$this->memberextrafieldsid->IsDetailKey && $this->memberextrafieldsid->FormValue != NULL && $this->memberextrafieldsid->FormValue == "") {
				AddMessage($FormError, str_replace("%s", $this->memberextrafieldsid->caption(), $this->memberextrafieldsid->RequiredErrorMessage));
			}
		}
		if (!CheckInteger($this->memberextrafieldsid->FormValue)) {
			AddMessage($FormError, $this->memberextrafieldsid->errorMessage());
		}
		if ($this->lastupdatedate->Required) {
			if (!$this->lastupdatedate->IsDetailKey && $this->lastupdatedate->FormValue != NULL && $this->lastupdatedate->FormValue == "") {
				AddMessage($FormError, str_replace("%s", $this->lastupdatedate->caption(), $this->lastupdatedate->RequiredErrorMessage));
			}
		}
		if (!CheckDate($this->lastupdatedate->FormValue)) {
			AddMessage($FormError, $this->lastupdatedate->errorMessage());
		}
		if ($this->remmitancetype->Required) {
			if (!$this->remmitancetype->IsDetailKey && $this->remmitancetype->FormValue != NULL && $this->remmitancetype->FormValue == "") {
				AddMessage($FormError, str_replace("%s", $this->remmitancetype->caption(), $this->remmitancetype->RequiredErrorMessage));
			}
		}
		if (!CheckInteger($this->remmitancetype->FormValue)) {
			AddMessage($FormError, $this->remmitancetype->errorMessage());
		}
		if ($this->withholdingtaxaccount->Required) {
			if (!$this->withholdingtaxaccount->IsDetailKey && $this->withholdingtaxaccount->FormValue != NULL && $this->withholdingtaxaccount->FormValue == "") {
				AddMessage($FormError, str_replace("%s", $this->withholdingtaxaccount->caption(), $this->withholdingtaxaccount->RequiredErrorMessage));
			}
		}
		if (!CheckInteger($this->withholdingtaxaccount->FormValue)) {
			AddMessage($FormError, $this->withholdingtaxaccount->errorMessage());
		}
		if ($this->businessphoneno->Required) {
			if (!$this->businessphoneno->IsDetailKey && $this->businessphoneno->FormValue != NULL && $this->businessphoneno->FormValue == "") {
				AddMessage($FormError, str_replace("%s", $this->businessphoneno->caption(), $this->businessphoneno->RequiredErrorMessage));
			}
		}
		if ($this->businessaddress1->Required) {
			if (!$this->businessaddress1->IsDetailKey && $this->businessaddress1->FormValue != NULL && $this->businessaddress1->FormValue == "") {
				AddMessage($FormError, str_replace("%s", $this->businessaddress1->caption(), $this->businessaddress1->RequiredErrorMessage));
			}
		}
		if ($this->businessaddress2->Required) {
			if (!$this->businessaddress2->IsDetailKey && $this->businessaddress2->FormValue != NULL && $this->businessaddress2->FormValue == "") {
				AddMessage($FormError, str_replace("%s", $this->businessaddress2->caption(), $this->businessaddress2->RequiredErrorMessage));
			}
		}
		if ($this->businesscity->Required) {
			if (!$this->businesscity->IsDetailKey && $this->businesscity->FormValue != NULL && $this->businesscity->FormValue == "") {
				AddMessage($FormError, str_replace("%s", $this->businesscity->caption(), $this->businesscity->RequiredErrorMessage));
			}
		}
		if ($this->businessstate->Required) {
			if (!$this->businessstate->IsDetailKey && $this->businessstate->FormValue != NULL && $this->businessstate->FormValue == "") {
				AddMessage($FormError, str_replace("%s", $this->businessstate->caption(), $this->businessstate->RequiredErrorMessage));
			}
		}
		if ($this->businesscountry->Required) {
			if (!$this->businesscountry->IsDetailKey && $this->businesscountry->FormValue != NULL && $this->businesscountry->FormValue == "") {
				AddMessage($FormError, str_replace("%s", $this->businesscountry->caption(), $this->businesscountry->RequiredErrorMessage));
			}
		}
		if ($this->businesszipcode->Required) {
			if (!$this->businesszipcode->IsDetailKey && $this->businesszipcode->FormValue != NULL && $this->businesszipcode->FormValue == "") {
				AddMessage($FormError, str_replace("%s", $this->businesszipcode->caption(), $this->businesszipcode->RequiredErrorMessage));
			}
		}
		if ($this->bankname->Required) {
			if (!$this->bankname->IsDetailKey && $this->bankname->FormValue != NULL && $this->bankname->FormValue == "") {
				AddMessage($FormError, str_replace("%s", $this->bankname->caption(), $this->bankname->RequiredErrorMessage));
			}
		}
		if ($this->bankbranchnumber->Required) {
			if (!$this->bankbranchnumber->IsDetailKey && $this->bankbranchnumber->FormValue != NULL && $this->bankbranchnumber->FormValue == "") {
				AddMessage($FormError, str_replace("%s", $this->bankbranchnumber->caption(), $this->bankbranchnumber->RequiredErrorMessage));
			}
		}
		if ($this->bankaccountnumber->Required) {
			if (!$this->bankaccountnumber->IsDetailKey && $this->bankaccountnumber->FormValue != NULL && $this->bankaccountnumber->FormValue == "") {
				AddMessage($FormError, str_replace("%s", $this->bankaccountnumber->caption(), $this->bankaccountnumber->RequiredErrorMessage));
			}
		}
		if ($this->other1->Required) {
			if (!$this->other1->IsDetailKey && $this->other1->FormValue != NULL && $this->other1->FormValue == "") {
				AddMessage($FormError, str_replace("%s", $this->other1->caption(), $this->other1->RequiredErrorMessage));
			}
		}
		if ($this->other2->Required) {
			if (!$this->other2->IsDetailKey && $this->other2->FormValue != NULL && $this->other2->FormValue == "") {
				AddMessage($FormError, str_replace("%s", $this->other2->caption(), $this->other2->RequiredErrorMessage));
			}
		}
		if ($this->other3->Required) {
			if (!$this->other3->IsDetailKey && $this->other3->FormValue != NULL && $this->other3->FormValue == "") {
				AddMessage($FormError, str_replace("%s", $this->other3->caption(), $this->other3->RequiredErrorMessage));
			}
		}
		if ($this->externalid->Required) {
			if (!$this->externalid->IsDetailKey && $this->externalid->FormValue != NULL && $this->externalid->FormValue == "") {
				AddMessage($FormError, str_replace("%s", $this->externalid->caption(), $this->externalid->RequiredErrorMessage));
			}
		}
		if ($this->couponpin->Required) {
			if (!$this->couponpin->IsDetailKey && $this->couponpin->FormValue != NULL && $this->couponpin->FormValue == "") {
				AddMessage($FormError, str_replace("%s", $this->couponpin->caption(), $this->couponpin->RequiredErrorMessage));
			}
		}
		if ($this->officialname->Required) {
			if (!$this->officialname->IsDetailKey && $this->officialname->FormValue != NULL && $this->officialname->FormValue == "") {
				AddMessage($FormError, str_replace("%s", $this->officialname->caption(), $this->officialname->RequiredErrorMessage));
			}
		}
		if ($this->swiftcode->Required) {
			if (!$this->swiftcode->IsDetailKey && $this->swiftcode->FormValue != NULL && $this->swiftcode->FormValue == "") {
				AddMessage($FormError, str_replace("%s", $this->swiftcode->caption(), $this->swiftcode->RequiredErrorMessage));
			}
		}
		if ($this->profilevalidated->Required) {
			if (!$this->profilevalidated->IsDetailKey && $this->profilevalidated->FormValue != NULL && $this->profilevalidated->FormValue == "") {
				AddMessage($FormError, str_replace("%s", $this->profilevalidated->caption(), $this->profilevalidated->RequiredErrorMessage));
			}
		}
		if (!CheckInteger($this->profilevalidated->FormValue)) {
			AddMessage($FormError, $this->profilevalidated->errorMessage());
		}
		if ($this->profilevalidationdate->Required) {
			if (!$this->profilevalidationdate->IsDetailKey && $this->profilevalidationdate->FormValue != NULL && $this->profilevalidationdate->FormValue == "") {
				AddMessage($FormError, str_replace("%s", $this->profilevalidationdate->caption(), $this->profilevalidationdate->RequiredErrorMessage));
			}
		}
		if (!CheckDate($this->profilevalidationdate->FormValue)) {
			AddMessage($FormError, $this->profilevalidationdate->errorMessage());
		}
		if ($this->industry->Required) {
			if (!$this->industry->IsDetailKey && $this->industry->FormValue != NULL && $this->industry->FormValue == "") {
				AddMessage($FormError, str_replace("%s", $this->industry->caption(), $this->industry->RequiredErrorMessage));
			}
		}
		if ($this->legalstructure->Required) {
			if (!$this->legalstructure->IsDetailKey && $this->legalstructure->FormValue != NULL && $this->legalstructure->FormValue == "") {
				AddMessage($FormError, str_replace("%s", $this->legalstructure->caption(), $this->legalstructure->RequiredErrorMessage));
			}
		}
		if ($this->extendedfields->Required) {
			if (!$this->extendedfields->IsDetailKey && $this->extendedfields->FormValue != NULL && $this->extendedfields->FormValue == "") {
				AddMessage($FormError, str_replace("%s", $this->extendedfields->caption(), $this->extendedfields->RequiredErrorMessage));
			}
		}

		// Return validate result
		$validateForm = ($FormError == "");

		// Call Form_CustomValidate event
		$formCustomError = "";
		$validateForm = $validateForm && $this->Form_CustomValidate($formCustomError);
		if ($formCustomError != "") {
			AddMessage($FormError, $formCustomError);
		}
		return $validateForm;
	}

	// Update record based on key values
	protected function editRow()
	{
		global $Security, $Language;
		$oldKeyFilter = $this->getRecordFilter();
		$filter = $this->applyUserIDFilters($oldKeyFilter);
		$conn = $this->getConnection();
		$this->CurrentFilter = $filter;
		$sql = $this->getCurrentSql();
		$conn->raiseErrorFn = Config("ERROR_FUNC");
		$rs = $conn->execute($sql);
		$conn->raiseErrorFn = "";
		if ($rs === FALSE)
			return FALSE;
		if ($rs->EOF) {
			$this->setFailureMessage($Language->phrase("NoRecord")); // Set no record message
			$editRow = FALSE; // Update Failed
		} else {

			// Save old values
			$rsold = &$rs->fields;
			$this->loadDbValues($rsold);
			$rsnew = [];

			// userid
			$this->_userid->setDbValueDef($rsnew, $this->_userid->CurrentValue, 0, $this->_userid->ReadOnly);

			// changed
			$this->changed->setDbValueDef($rsnew, $this->changed->CurrentValue, 0, $this->changed->ReadOnly);

			// active
			$this->active->setDbValueDef($rsnew, $this->active->CurrentValue, 0, $this->active->ReadOnly);

			// tipallowed
			$this->tipallowed->setDbValueDef($rsnew, $this->tipallowed->CurrentValue, 0, $this->tipallowed->ReadOnly);

			// merchanttoaddtip
			$this->merchanttoaddtip->setDbValueDef($rsnew, $this->merchanttoaddtip->CurrentValue, 0, $this->merchanttoaddtip->ReadOnly);

			// pis
			$this->pis->setDbValueDef($rsnew, $this->pis->CurrentValue, NULL, $this->pis->ReadOnly);

			// ratetabletype
			$this->ratetabletype->setDbValueDef($rsnew, $this->ratetabletype->CurrentValue, 0, $this->ratetabletype->ReadOnly);

			// ratetableid
			$this->ratetableid->setDbValueDef($rsnew, $this->ratetableid->CurrentValue, 0, $this->ratetableid->ReadOnly);

			// officialdocnumber
			$this->officialdocnumber->setDbValueDef($rsnew, $this->officialdocnumber->CurrentValue, NULL, $this->officialdocnumber->ReadOnly);

			// officialdocname
			$this->officialdocname->setDbValueDef($rsnew, $this->officialdocname->CurrentValue, NULL, $this->officialdocname->ReadOnly);

			// businessname
			$this->businessname->setDbValueDef($rsnew, $this->businessname->CurrentValue, "", $this->businessname->ReadOnly);

			// softposid
			$this->softposid->setDbValueDef($rsnew, $this->softposid->CurrentValue, NULL, $this->softposid->ReadOnly);

			// taxamount
			$this->taxamount->setDbValueDef($rsnew, $this->taxamount->CurrentValue, 0, $this->taxamount->ReadOnly);

			// variabletax
			$this->variabletax->setDbValueDef($rsnew, $this->variabletax->CurrentValue, 0, $this->variabletax->ReadOnly);

			// logofilename
			$this->logofilename->setDbValueDef($rsnew, $this->logofilename->CurrentValue, "", $this->logofilename->ReadOnly);

			// returndays
			$this->returndays->setDbValueDef($rsnew, $this->returndays->CurrentValue, 0, $this->returndays->ReadOnly);

			// memberextrafieldsid
			$this->memberextrafieldsid->setDbValueDef($rsnew, $this->memberextrafieldsid->CurrentValue, NULL, $this->memberextrafieldsid->ReadOnly);

			// lastupdatedate
			$this->lastupdatedate->setDbValueDef($rsnew, UnFormatDateTime($this->lastupdatedate->CurrentValue, 0), CurrentDate(), $this->lastupdatedate->ReadOnly);

			// remmitancetype
			$this->remmitancetype->setDbValueDef($rsnew, $this->remmitancetype->CurrentValue, 0, $this->remmitancetype->ReadOnly);

			// withholdingtaxaccount
			$this->withholdingtaxaccount->setDbValueDef($rsnew, $this->withholdingtaxaccount->CurrentValue, 0, $this->withholdingtaxaccount->ReadOnly);

			// businessphoneno
			$this->businessphoneno->setDbValueDef($rsnew, $this->businessphoneno->CurrentValue, NULL, $this->businessphoneno->ReadOnly);

			// businessaddress1
			$this->businessaddress1->setDbValueDef($rsnew, $this->businessaddress1->CurrentValue, NULL, $this->businessaddress1->ReadOnly);

			// businessaddress2
			$this->businessaddress2->setDbValueDef($rsnew, $this->businessaddress2->CurrentValue, NULL, $this->businessaddress2->ReadOnly);

			// businesscity
			$this->businesscity->setDbValueDef($rsnew, $this->businesscity->CurrentValue, NULL, $this->businesscity->ReadOnly);

			// businessstate
			$this->businessstate->setDbValueDef($rsnew, $this->businessstate->CurrentValue, NULL, $this->businessstate->ReadOnly);

			// businesscountry
			$this->businesscountry->setDbValueDef($rsnew, $this->businesscountry->CurrentValue, NULL, $this->businesscountry->ReadOnly);

			// businesszipcode
			$this->businesszipcode->setDbValueDef($rsnew, $this->businesszipcode->CurrentValue, NULL, $this->businesszipcode->ReadOnly);

			// bankname
			$this->bankname->setDbValueDef($rsnew, $this->bankname->CurrentValue, NULL, $this->bankname->ReadOnly);

			// bankbranchnumber
			$this->bankbranchnumber->setDbValueDef($rsnew, $this->bankbranchnumber->CurrentValue, NULL, $this->bankbranchnumber->ReadOnly);

			// bankaccountnumber
			$this->bankaccountnumber->setDbValueDef($rsnew, $this->bankaccountnumber->CurrentValue, NULL, $this->bankaccountnumber->ReadOnly);

			// other1
			$this->other1->setDbValueDef($rsnew, $this->other1->CurrentValue, NULL, $this->other1->ReadOnly);

			// other2
			$this->other2->setDbValueDef($rsnew, $this->other2->CurrentValue, NULL, $this->other2->ReadOnly);

			// other3
			$this->other3->setDbValueDef($rsnew, $this->other3->CurrentValue, NULL, $this->other3->ReadOnly);

			// externalid
			$this->externalid->setDbValueDef($rsnew, $this->externalid->CurrentValue, NULL, $this->externalid->ReadOnly);

			// couponpin
			$this->couponpin->setDbValueDef($rsnew, $this->couponpin->CurrentValue, NULL, $this->couponpin->ReadOnly);

			// officialname
			$this->officialname->setDbValueDef($rsnew, $this->officialname->CurrentValue, NULL, $this->officialname->ReadOnly);

			// swiftcode
			$this->swiftcode->setDbValueDef($rsnew, $this->swiftcode->CurrentValue, NULL, $this->swiftcode->ReadOnly);

			// profilevalidated
			$this->profilevalidated->setDbValueDef($rsnew, $this->profilevalidated->CurrentValue, 0, $this->profilevalidated->ReadOnly);

			// profilevalidationdate
			$this->profilevalidationdate->setDbValueDef($rsnew, UnFormatDateTime($this->profilevalidationdate->CurrentValue, 0), NULL, $this->profilevalidationdate->ReadOnly);

			// industry
			$this->industry->setDbValueDef($rsnew, $this->industry->CurrentValue, NULL, $this->industry->ReadOnly);

			// legalstructure
			$this->legalstructure->setDbValueDef($rsnew, $this->legalstructure->CurrentValue, NULL, $this->legalstructure->ReadOnly);

			// extendedfields
			$this->extendedfields->setDbValueDef($rsnew, $this->extendedfields->CurrentValue, NULL, $this->extendedfields->ReadOnly);

			// Call Row Updating event
			$updateRow = $this->Row_Updating($rsold, $rsnew);

			// Check for duplicate key when key changed
			if ($updateRow) {
				$newKeyFilter = $this->getRecordFilter($rsnew);
				if ($newKeyFilter != $oldKeyFilter) {
					$rsChk = $this->loadRs($newKeyFilter);
					if ($rsChk && !$rsChk->EOF) {
						$keyErrMsg = str_replace("%f", $newKeyFilter, $Language->phrase("DupKey"));
						$this->setFailureMessage($keyErrMsg);
						$rsChk->close();
						$updateRow = FALSE;
					}
				}
			}
			if ($updateRow) {
				$conn->raiseErrorFn = Config("ERROR_FUNC");
				if (count($rsnew) > 0)
					$editRow = $this->update($rsnew, "", $rsold);
				else
					$editRow = TRUE; // No field to update
				$conn->raiseErrorFn = "";
				if ($editRow) {
				}
			} else {
				if ($this->getSuccessMessage() != "" || $this->getFailureMessage() != "") {

					// Use the message, do nothing
				} elseif ($this->CancelMessage != "") {
					$this->setFailureMessage($this->CancelMessage);
					$this->CancelMessage = "";
				} else {
					$this->setFailureMessage($Language->phrase("UpdateCancelled"));
				}
				$editRow = FALSE;
			}
		}

		// Call Row_Updated event
		if ($editRow)
			$this->Row_Updated($rsold, $rsnew);
		$rs->close();

		// Clean upload path if any
		if ($editRow) {
		}

		// Write JSON for API request
		if (IsApi() && $editRow) {
			$row = $this->getRecordsFromRecordset([$rsnew], TRUE);
			WriteJson(["success" => TRUE, $this->TableVar => $row]);
		}
		return $editRow;
	}

	// Set up Breadcrumb
	protected function setupBreadcrumb()
	{
		global $Breadcrumb, $Language;
		$Breadcrumb = new Breadcrumb();
		$url = substr(CurrentUrl(), strrpos(CurrentUrl(), "/")+1);
		$Breadcrumb->add("list", $this->TableVar, $this->addMasterUrl("merchant_copy1list.php"), "", $this->TableVar, TRUE);
		$pageId = "edit";
		$Breadcrumb->add("edit", $pageId, $url);
	}

	// Setup lookup options
	public function setupLookupOptions($fld)
	{
		if ($fld->Lookup !== NULL && $fld->Lookup->Options === NULL) {

			// Get default connection and filter
			$conn = $this->getConnection();
			$lookupFilter = "";

			// No need to check any more
			$fld->Lookup->Options = [];

			// Set up lookup SQL and connection
			switch ($fld->FieldVar) {
				default:
					$lookupFilter = "";
					break;
			}

			// Always call to Lookup->getSql so that user can setup Lookup->Options in Lookup_Selecting server event
			$sql = $fld->Lookup->getSql(FALSE, "", $lookupFilter, $this);

			// Set up lookup cache
			if ($fld->UseLookupCache && $sql != "" && count($fld->Lookup->Options) == 0) {
				$totalCnt = $this->getRecordCount($sql, $conn);
				if ($totalCnt > $fld->LookupCacheCount) // Total count > cache count, do not cache
					return;
				$rs = $conn->execute($sql);
				$ar = [];
				while ($rs && !$rs->EOF) {
					$row = &$rs->fields;

					// Format the field values
					switch ($fld->FieldVar) {
					}
					$ar[strval($row[0])] = $row;
					$rs->moveNext();
				}
				if ($rs)
					$rs->close();
				$fld->Lookup->Options = $ar;
			}
		}
	}

	// Set up starting record parameters
	public function setupStartRecord()
	{
		if ($this->DisplayRecords == 0)
			return;
		if ($this->isPageRequest()) { // Validate request
			$startRec = Get(Config("TABLE_START_REC"));
			$pageNo = Get(Config("TABLE_PAGE_NO"));
			if ($pageNo !== NULL) { // Check for "pageno" parameter first
				if (is_numeric($pageNo)) {
					$this->StartRecord = ($pageNo - 1) * $this->DisplayRecords + 1;
					if ($this->StartRecord <= 0) {
						$this->StartRecord = 1;
					} elseif ($this->StartRecord >= (int)(($this->TotalRecords - 1)/$this->DisplayRecords) * $this->DisplayRecords + 1) {
						$this->StartRecord = (int)(($this->TotalRecords - 1)/$this->DisplayRecords) * $this->DisplayRecords + 1;
					}
					$this->setStartRecordNumber($this->StartRecord);
				}
			} elseif ($startRec !== NULL) { // Check for "start" parameter
				$this->StartRecord = $startRec;
				$this->setStartRecordNumber($this->StartRecord);
			}
		}
		$this->StartRecord = $this->getStartRecordNumber();

		// Check if correct start record counter
		if (!is_numeric($this->StartRecord) || $this->StartRecord == "") { // Avoid invalid start record counter
			$this->StartRecord = 1; // Reset start record counter
			$this->setStartRecordNumber($this->StartRecord);
		} elseif ($this->StartRecord > $this->TotalRecords) { // Avoid starting record > total records
			$this->StartRecord = (int)(($this->TotalRecords - 1)/$this->DisplayRecords) * $this->DisplayRecords + 1; // Point to last page first record
			$this->setStartRecordNumber($this->StartRecord);
		} elseif (($this->StartRecord - 1) % $this->DisplayRecords != 0) {
			$this->StartRecord = (int)(($this->StartRecord - 1)/$this->DisplayRecords) * $this->DisplayRecords + 1; // Point to page boundary
			$this->setStartRecordNumber($this->StartRecord);
		}
	}

	// Page Load event
	function Page_Load() {

		//echo "Page Load";
	}

	// Page Unload event
	function Page_Unload() {

		//echo "Page Unload";
	}

	// Page Redirecting event
	function Page_Redirecting(&$url) {

		// Example:
		//$url = "your URL";

	}

	// Message Showing event
	// $type = ''|'success'|'failure'|'warning'
	function Message_Showing(&$msg, $type) {
		if ($type == 'success') {

			//$msg = "your success message";
		} elseif ($type == 'failure') {

			//$msg = "your failure message";
		} elseif ($type == 'warning') {

			//$msg = "your warning message";
		} else {

			//$msg = "your message";
		}
	}

	// Page Render event
	function Page_Render() {

		//echo "Page Render";
	}

	// Page Data Rendering event
	function Page_DataRendering(&$header) {

		// Example:
		//$header = "your header";

	}

	// Page Data Rendered event
	function Page_DataRendered(&$footer) {

		// Example:
		//$footer = "your footer";

	}

	// Form Custom Validate event
	function Form_CustomValidate(&$customError) {

		// Return error message in CustomError
		return TRUE;
	}
} // End class
?>