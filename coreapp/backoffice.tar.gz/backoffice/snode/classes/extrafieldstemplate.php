<?php namespace PHPMaker2020\_4payadmin; ?>
<?php

/**
 * Table class for extrafieldstemplate
 */
class extrafieldstemplate extends DbTable
{
	protected $SqlFrom = "";
	protected $SqlSelect = "";
	protected $SqlSelectList = "";
	protected $SqlWhere = "";
	protected $SqlGroupBy = "";
	protected $SqlHaving = "";
	protected $SqlOrderBy = "";
	public $UseSessionForListSql = TRUE;

	// Column CSS classes
	public $LeftColumnClass = "col-sm-2 col-form-label ew-label";
	public $RightColumnClass = "col-sm-10";
	public $OffsetColumnClass = "col-sm-10 offset-sm-2";
	public $TableLeftColumnClass = "w-col-2";

	// Audit trail
	public $AuditTrailOnAdd = TRUE;
	public $AuditTrailOnEdit = TRUE;
	public $AuditTrailOnDelete = TRUE;
	public $AuditTrailOnView = FALSE;
	public $AuditTrailOnViewData = FALSE;
	public $AuditTrailOnSearch = FALSE;

	// Export
	public $ExportDoc;

	// Fields
	public $extrafieldsid;
	public $merchantid;
	public $name;
	public $field1label;
	public $field1type;
	public $field1mandatory;
	public $field1display;
	public $field1displaysequence;
	public $field1domain;
	public $field2label;
	public $field2type;
	public $field2mandatory;
	public $field2display;
	public $field2displaysequence;
	public $field2domain;
	public $field3label;
	public $field3type;
	public $field3mandatory;
	public $field3display;
	public $field3displaysequence;
	public $field3domain;
	public $field4label;
	public $field4type;
	public $field4mandatory;
	public $field4display;
	public $field4displaysequence;
	public $field4domain;
	public $field5label;
	public $field5type;
	public $field5mandatory;
	public $field5display;
	public $field5displaysequence;
	public $field5domain;
	public $field6label;
	public $field6type;
	public $field6mandatory;
	public $field6display;
	public $field6displaysequence;
	public $field6domain;
	public $field7label;
	public $field7type;
	public $field7mandatory;
	public $field7display;
	public $field7displaysequence;
	public $field7domain;
	public $field8label;
	public $field8type;
	public $field8mandatory;
	public $field8display;
	public $field8displaysequence;
	public $field8domain;
	public $field9label;
	public $field9type;
	public $field9mandatory;
	public $field9display;
	public $field9displaysequence;
	public $field9domain;
	public $field10label;
	public $field10type;
	public $field10mandatory;
	public $field10display;
	public $field10displaysequence;
	public $field10domain;
	public $lastupdatedate;

	// Constructor
	public function __construct()
	{
		global $Language, $CurrentLanguage;
		parent::__construct();

		// Language object
		if (!isset($Language))
			$Language = new Language();
		$this->TableVar = 'extrafieldstemplate';
		$this->TableName = 'extrafieldstemplate';
		$this->TableType = 'TABLE';

		// Update Table
		$this->UpdateTable = "`extrafieldstemplate`";
		$this->Dbid = 'DB';
		$this->ExportAll = TRUE;
		$this->ExportPageBreakCount = 0; // Page break per every n record (PDF only)
		$this->ExportPageOrientation = "portrait"; // Page orientation (PDF only)
		$this->ExportPageSize = "a4"; // Page size (PDF only)
		$this->ExportExcelPageOrientation = \PhpOffice\PhpSpreadsheet\Worksheet\PageSetup::ORIENTATION_DEFAULT; // Page orientation (PhpSpreadsheet only)
		$this->ExportExcelPageSize = \PhpOffice\PhpSpreadsheet\Worksheet\PageSetup::PAPERSIZE_A4; // Page size (PhpSpreadsheet only)
		$this->ExportWordPageOrientation = "portrait"; // Page orientation (PHPWord only)
		$this->ExportWordColumnWidth = NULL; // Cell width (PHPWord only)
		$this->DetailAdd = FALSE; // Allow detail add
		$this->DetailEdit = FALSE; // Allow detail edit
		$this->DetailView = FALSE; // Allow detail view
		$this->ShowMultipleDetails = FALSE; // Show multiple details
		$this->GridAddRowCount = 5;
		$this->AllowAddDeleteRow = TRUE; // Allow add/delete row
		$this->UserIDAllowSecurity = Config("DEFAULT_USER_ID_ALLOW_SECURITY"); // Default User ID allowed permissions
		$this->BasicSearch = new BasicSearch($this->TableVar);

		// extrafieldsid
		$this->extrafieldsid = new DbField('extrafieldstemplate', 'extrafieldstemplate', 'x_extrafieldsid', 'extrafieldsid', '`extrafieldsid`', '`extrafieldsid`', 3, 12, -1, FALSE, '`extrafieldsid`', FALSE, FALSE, FALSE, 'FORMATTED TEXT', 'NO');
		$this->extrafieldsid->IsAutoIncrement = TRUE; // Autoincrement field
		$this->extrafieldsid->IsPrimaryKey = TRUE; // Primary key field
		$this->extrafieldsid->Sortable = TRUE; // Allow sort
		$this->extrafieldsid->DefaultErrorMessage = $Language->phrase("IncorrectInteger");
		$this->fields['extrafieldsid'] = &$this->extrafieldsid;

		// merchantid
		$this->merchantid = new DbField('extrafieldstemplate', 'extrafieldstemplate', 'x_merchantid', 'merchantid', '`merchantid`', '`merchantid`', 3, 12, -1, FALSE, '`merchantid`', FALSE, FALSE, FALSE, 'FORMATTED TEXT', 'TEXT');
		$this->merchantid->Nullable = FALSE; // NOT NULL field
		$this->merchantid->Required = TRUE; // Required field
		$this->merchantid->Sortable = TRUE; // Allow sort
		$this->merchantid->DefaultErrorMessage = $Language->phrase("IncorrectInteger");
		$this->fields['merchantid'] = &$this->merchantid;

		// name
		$this->name = new DbField('extrafieldstemplate', 'extrafieldstemplate', 'x_name', 'name', '`name`', '`name`', 200, 30, -1, FALSE, '`name`', FALSE, FALSE, FALSE, 'FORMATTED TEXT', 'TEXT');
		$this->name->Nullable = FALSE; // NOT NULL field
		$this->name->Required = TRUE; // Required field
		$this->name->Sortable = TRUE; // Allow sort
		$this->fields['name'] = &$this->name;

		// field1label
		$this->field1label = new DbField('extrafieldstemplate', 'extrafieldstemplate', 'x_field1label', 'field1label', '`field1label`', '`field1label`', 200, 30, -1, FALSE, '`field1label`', FALSE, FALSE, FALSE, 'FORMATTED TEXT', 'TEXT');
		$this->field1label->Nullable = FALSE; // NOT NULL field
		$this->field1label->Required = TRUE; // Required field
		$this->field1label->Sortable = TRUE; // Allow sort
		$this->fields['field1label'] = &$this->field1label;

		// field1type
		$this->field1type = new DbField('extrafieldstemplate', 'extrafieldstemplate', 'x_field1type', 'field1type', '`field1type`', '`field1type`', 3, 1, -1, FALSE, '`field1type`', FALSE, FALSE, FALSE, 'FORMATTED TEXT', 'TEXT');
		$this->field1type->Nullable = FALSE; // NOT NULL field
		$this->field1type->Required = TRUE; // Required field
		$this->field1type->Sortable = TRUE; // Allow sort
		$this->field1type->DefaultErrorMessage = $Language->phrase("IncorrectInteger");
		$this->fields['field1type'] = &$this->field1type;

		// field1mandatory
		$this->field1mandatory = new DbField('extrafieldstemplate', 'extrafieldstemplate', 'x_field1mandatory', 'field1mandatory', '`field1mandatory`', '`field1mandatory`', 3, 1, -1, FALSE, '`field1mandatory`', FALSE, FALSE, FALSE, 'FORMATTED TEXT', 'TEXT');
		$this->field1mandatory->Nullable = FALSE; // NOT NULL field
		$this->field1mandatory->Required = TRUE; // Required field
		$this->field1mandatory->Sortable = TRUE; // Allow sort
		$this->field1mandatory->DefaultErrorMessage = $Language->phrase("IncorrectInteger");
		$this->fields['field1mandatory'] = &$this->field1mandatory;

		// field1display
		$this->field1display = new DbField('extrafieldstemplate', 'extrafieldstemplate', 'x_field1display', 'field1display', '`field1display`', '`field1display`', 3, 1, -1, FALSE, '`field1display`', FALSE, FALSE, FALSE, 'FORMATTED TEXT', 'TEXT');
		$this->field1display->Nullable = FALSE; // NOT NULL field
		$this->field1display->Required = TRUE; // Required field
		$this->field1display->Sortable = TRUE; // Allow sort
		$this->field1display->DefaultErrorMessage = $Language->phrase("IncorrectInteger");
		$this->fields['field1display'] = &$this->field1display;

		// field1displaysequence
		$this->field1displaysequence = new DbField('extrafieldstemplate', 'extrafieldstemplate', 'x_field1displaysequence', 'field1displaysequence', '`field1displaysequence`', '`field1displaysequence`', 3, 2, -1, FALSE, '`field1displaysequence`', FALSE, FALSE, FALSE, 'FORMATTED TEXT', 'TEXT');
		$this->field1displaysequence->Nullable = FALSE; // NOT NULL field
		$this->field1displaysequence->Required = TRUE; // Required field
		$this->field1displaysequence->Sortable = TRUE; // Allow sort
		$this->field1displaysequence->DefaultErrorMessage = $Language->phrase("IncorrectInteger");
		$this->fields['field1displaysequence'] = &$this->field1displaysequence;

		// field1domain
		$this->field1domain = new DbField('extrafieldstemplate', 'extrafieldstemplate', 'x_field1domain', 'field1domain', '`field1domain`', '`field1domain`', 3, 12, -1, FALSE, '`field1domain`', FALSE, FALSE, FALSE, 'FORMATTED TEXT', 'TEXT');
		$this->field1domain->Sortable = TRUE; // Allow sort
		$this->field1domain->DefaultErrorMessage = $Language->phrase("IncorrectInteger");
		$this->fields['field1domain'] = &$this->field1domain;

		// field2label
		$this->field2label = new DbField('extrafieldstemplate', 'extrafieldstemplate', 'x_field2label', 'field2label', '`field2label`', '`field2label`', 200, 30, -1, FALSE, '`field2label`', FALSE, FALSE, FALSE, 'FORMATTED TEXT', 'TEXT');
		$this->field2label->Nullable = FALSE; // NOT NULL field
		$this->field2label->Required = TRUE; // Required field
		$this->field2label->Sortable = TRUE; // Allow sort
		$this->fields['field2label'] = &$this->field2label;

		// field2type
		$this->field2type = new DbField('extrafieldstemplate', 'extrafieldstemplate', 'x_field2type', 'field2type', '`field2type`', '`field2type`', 3, 1, -1, FALSE, '`field2type`', FALSE, FALSE, FALSE, 'FORMATTED TEXT', 'TEXT');
		$this->field2type->Nullable = FALSE; // NOT NULL field
		$this->field2type->Required = TRUE; // Required field
		$this->field2type->Sortable = TRUE; // Allow sort
		$this->field2type->DefaultErrorMessage = $Language->phrase("IncorrectInteger");
		$this->fields['field2type'] = &$this->field2type;

		// field2mandatory
		$this->field2mandatory = new DbField('extrafieldstemplate', 'extrafieldstemplate', 'x_field2mandatory', 'field2mandatory', '`field2mandatory`', '`field2mandatory`', 3, 1, -1, FALSE, '`field2mandatory`', FALSE, FALSE, FALSE, 'FORMATTED TEXT', 'TEXT');
		$this->field2mandatory->Nullable = FALSE; // NOT NULL field
		$this->field2mandatory->Required = TRUE; // Required field
		$this->field2mandatory->Sortable = TRUE; // Allow sort
		$this->field2mandatory->DefaultErrorMessage = $Language->phrase("IncorrectInteger");
		$this->fields['field2mandatory'] = &$this->field2mandatory;

		// field2display
		$this->field2display = new DbField('extrafieldstemplate', 'extrafieldstemplate', 'x_field2display', 'field2display', '`field2display`', '`field2display`', 3, 1, -1, FALSE, '`field2display`', FALSE, FALSE, FALSE, 'FORMATTED TEXT', 'TEXT');
		$this->field2display->Nullable = FALSE; // NOT NULL field
		$this->field2display->Required = TRUE; // Required field
		$this->field2display->Sortable = TRUE; // Allow sort
		$this->field2display->DefaultErrorMessage = $Language->phrase("IncorrectInteger");
		$this->fields['field2display'] = &$this->field2display;

		// field2displaysequence
		$this->field2displaysequence = new DbField('extrafieldstemplate', 'extrafieldstemplate', 'x_field2displaysequence', 'field2displaysequence', '`field2displaysequence`', '`field2displaysequence`', 3, 2, -1, FALSE, '`field2displaysequence`', FALSE, FALSE, FALSE, 'FORMATTED TEXT', 'TEXT');
		$this->field2displaysequence->Nullable = FALSE; // NOT NULL field
		$this->field2displaysequence->Required = TRUE; // Required field
		$this->field2displaysequence->Sortable = TRUE; // Allow sort
		$this->field2displaysequence->DefaultErrorMessage = $Language->phrase("IncorrectInteger");
		$this->fields['field2displaysequence'] = &$this->field2displaysequence;

		// field2domain
		$this->field2domain = new DbField('extrafieldstemplate', 'extrafieldstemplate', 'x_field2domain', 'field2domain', '`field2domain`', '`field2domain`', 3, 12, -1, FALSE, '`field2domain`', FALSE, FALSE, FALSE, 'FORMATTED TEXT', 'TEXT');
		$this->field2domain->Sortable = TRUE; // Allow sort
		$this->field2domain->DefaultErrorMessage = $Language->phrase("IncorrectInteger");
		$this->fields['field2domain'] = &$this->field2domain;

		// field3label
		$this->field3label = new DbField('extrafieldstemplate', 'extrafieldstemplate', 'x_field3label', 'field3label', '`field3label`', '`field3label`', 200, 30, -1, FALSE, '`field3label`', FALSE, FALSE, FALSE, 'FORMATTED TEXT', 'TEXT');
		$this->field3label->Nullable = FALSE; // NOT NULL field
		$this->field3label->Required = TRUE; // Required field
		$this->field3label->Sortable = TRUE; // Allow sort
		$this->fields['field3label'] = &$this->field3label;

		// field3type
		$this->field3type = new DbField('extrafieldstemplate', 'extrafieldstemplate', 'x_field3type', 'field3type', '`field3type`', '`field3type`', 3, 1, -1, FALSE, '`field3type`', FALSE, FALSE, FALSE, 'FORMATTED TEXT', 'TEXT');
		$this->field3type->Nullable = FALSE; // NOT NULL field
		$this->field3type->Required = TRUE; // Required field
		$this->field3type->Sortable = TRUE; // Allow sort
		$this->field3type->DefaultErrorMessage = $Language->phrase("IncorrectInteger");
		$this->fields['field3type'] = &$this->field3type;

		// field3mandatory
		$this->field3mandatory = new DbField('extrafieldstemplate', 'extrafieldstemplate', 'x_field3mandatory', 'field3mandatory', '`field3mandatory`', '`field3mandatory`', 3, 1, -1, FALSE, '`field3mandatory`', FALSE, FALSE, FALSE, 'FORMATTED TEXT', 'TEXT');
		$this->field3mandatory->Nullable = FALSE; // NOT NULL field
		$this->field3mandatory->Required = TRUE; // Required field
		$this->field3mandatory->Sortable = TRUE; // Allow sort
		$this->field3mandatory->DefaultErrorMessage = $Language->phrase("IncorrectInteger");
		$this->fields['field3mandatory'] = &$this->field3mandatory;

		// field3display
		$this->field3display = new DbField('extrafieldstemplate', 'extrafieldstemplate', 'x_field3display', 'field3display', '`field3display`', '`field3display`', 3, 1, -1, FALSE, '`field3display`', FALSE, FALSE, FALSE, 'FORMATTED TEXT', 'TEXT');
		$this->field3display->Nullable = FALSE; // NOT NULL field
		$this->field3display->Required = TRUE; // Required field
		$this->field3display->Sortable = TRUE; // Allow sort
		$this->field3display->DefaultErrorMessage = $Language->phrase("IncorrectInteger");
		$this->fields['field3display'] = &$this->field3display;

		// field3displaysequence
		$this->field3displaysequence = new DbField('extrafieldstemplate', 'extrafieldstemplate', 'x_field3displaysequence', 'field3displaysequence', '`field3displaysequence`', '`field3displaysequence`', 3, 2, -1, FALSE, '`field3displaysequence`', FALSE, FALSE, FALSE, 'FORMATTED TEXT', 'TEXT');
		$this->field3displaysequence->Nullable = FALSE; // NOT NULL field
		$this->field3displaysequence->Required = TRUE; // Required field
		$this->field3displaysequence->Sortable = TRUE; // Allow sort
		$this->field3displaysequence->DefaultErrorMessage = $Language->phrase("IncorrectInteger");
		$this->fields['field3displaysequence'] = &$this->field3displaysequence;

		// field3domain
		$this->field3domain = new DbField('extrafieldstemplate', 'extrafieldstemplate', 'x_field3domain', 'field3domain', '`field3domain`', '`field3domain`', 3, 12, -1, FALSE, '`field3domain`', FALSE, FALSE, FALSE, 'FORMATTED TEXT', 'TEXT');
		$this->field3domain->Sortable = TRUE; // Allow sort
		$this->field3domain->DefaultErrorMessage = $Language->phrase("IncorrectInteger");
		$this->fields['field3domain'] = &$this->field3domain;

		// field4label
		$this->field4label = new DbField('extrafieldstemplate', 'extrafieldstemplate', 'x_field4label', 'field4label', '`field4label`', '`field4label`', 200, 30, -1, FALSE, '`field4label`', FALSE, FALSE, FALSE, 'FORMATTED TEXT', 'TEXT');
		$this->field4label->Nullable = FALSE; // NOT NULL field
		$this->field4label->Required = TRUE; // Required field
		$this->field4label->Sortable = TRUE; // Allow sort
		$this->fields['field4label'] = &$this->field4label;

		// field4type
		$this->field4type = new DbField('extrafieldstemplate', 'extrafieldstemplate', 'x_field4type', 'field4type', '`field4type`', '`field4type`', 3, 1, -1, FALSE, '`field4type`', FALSE, FALSE, FALSE, 'FORMATTED TEXT', 'TEXT');
		$this->field4type->Nullable = FALSE; // NOT NULL field
		$this->field4type->Required = TRUE; // Required field
		$this->field4type->Sortable = TRUE; // Allow sort
		$this->field4type->DefaultErrorMessage = $Language->phrase("IncorrectInteger");
		$this->fields['field4type'] = &$this->field4type;

		// field4mandatory
		$this->field4mandatory = new DbField('extrafieldstemplate', 'extrafieldstemplate', 'x_field4mandatory', 'field4mandatory', '`field4mandatory`', '`field4mandatory`', 3, 1, -1, FALSE, '`field4mandatory`', FALSE, FALSE, FALSE, 'FORMATTED TEXT', 'TEXT');
		$this->field4mandatory->Nullable = FALSE; // NOT NULL field
		$this->field4mandatory->Required = TRUE; // Required field
		$this->field4mandatory->Sortable = TRUE; // Allow sort
		$this->field4mandatory->DefaultErrorMessage = $Language->phrase("IncorrectInteger");
		$this->fields['field4mandatory'] = &$this->field4mandatory;

		// field4display
		$this->field4display = new DbField('extrafieldstemplate', 'extrafieldstemplate', 'x_field4display', 'field4display', '`field4display`', '`field4display`', 3, 1, -1, FALSE, '`field4display`', FALSE, FALSE, FALSE, 'FORMATTED TEXT', 'TEXT');
		$this->field4display->Nullable = FALSE; // NOT NULL field
		$this->field4display->Required = TRUE; // Required field
		$this->field4display->Sortable = TRUE; // Allow sort
		$this->field4display->DefaultErrorMessage = $Language->phrase("IncorrectInteger");
		$this->fields['field4display'] = &$this->field4display;

		// field4displaysequence
		$this->field4displaysequence = new DbField('extrafieldstemplate', 'extrafieldstemplate', 'x_field4displaysequence', 'field4displaysequence', '`field4displaysequence`', '`field4displaysequence`', 3, 2, -1, FALSE, '`field4displaysequence`', FALSE, FALSE, FALSE, 'FORMATTED TEXT', 'TEXT');
		$this->field4displaysequence->Nullable = FALSE; // NOT NULL field
		$this->field4displaysequence->Required = TRUE; // Required field
		$this->field4displaysequence->Sortable = TRUE; // Allow sort
		$this->field4displaysequence->DefaultErrorMessage = $Language->phrase("IncorrectInteger");
		$this->fields['field4displaysequence'] = &$this->field4displaysequence;

		// field4domain
		$this->field4domain = new DbField('extrafieldstemplate', 'extrafieldstemplate', 'x_field4domain', 'field4domain', '`field4domain`', '`field4domain`', 3, 12, -1, FALSE, '`field4domain`', FALSE, FALSE, FALSE, 'FORMATTED TEXT', 'TEXT');
		$this->field4domain->Sortable = TRUE; // Allow sort
		$this->field4domain->DefaultErrorMessage = $Language->phrase("IncorrectInteger");
		$this->fields['field4domain'] = &$this->field4domain;

		// field5label
		$this->field5label = new DbField('extrafieldstemplate', 'extrafieldstemplate', 'x_field5label', 'field5label', '`field5label`', '`field5label`', 200, 30, -1, FALSE, '`field5label`', FALSE, FALSE, FALSE, 'FORMATTED TEXT', 'TEXT');
		$this->field5label->Nullable = FALSE; // NOT NULL field
		$this->field5label->Required = TRUE; // Required field
		$this->field5label->Sortable = TRUE; // Allow sort
		$this->fields['field5label'] = &$this->field5label;

		// field5type
		$this->field5type = new DbField('extrafieldstemplate', 'extrafieldstemplate', 'x_field5type', 'field5type', '`field5type`', '`field5type`', 3, 1, -1, FALSE, '`field5type`', FALSE, FALSE, FALSE, 'FORMATTED TEXT', 'TEXT');
		$this->field5type->Nullable = FALSE; // NOT NULL field
		$this->field5type->Required = TRUE; // Required field
		$this->field5type->Sortable = TRUE; // Allow sort
		$this->field5type->DefaultErrorMessage = $Language->phrase("IncorrectInteger");
		$this->fields['field5type'] = &$this->field5type;

		// field5mandatory
		$this->field5mandatory = new DbField('extrafieldstemplate', 'extrafieldstemplate', 'x_field5mandatory', 'field5mandatory', '`field5mandatory`', '`field5mandatory`', 3, 1, -1, FALSE, '`field5mandatory`', FALSE, FALSE, FALSE, 'FORMATTED TEXT', 'TEXT');
		$this->field5mandatory->Nullable = FALSE; // NOT NULL field
		$this->field5mandatory->Required = TRUE; // Required field
		$this->field5mandatory->Sortable = TRUE; // Allow sort
		$this->field5mandatory->DefaultErrorMessage = $Language->phrase("IncorrectInteger");
		$this->fields['field5mandatory'] = &$this->field5mandatory;

		// field5display
		$this->field5display = new DbField('extrafieldstemplate', 'extrafieldstemplate', 'x_field5display', 'field5display', '`field5display`', '`field5display`', 3, 1, -1, FALSE, '`field5display`', FALSE, FALSE, FALSE, 'FORMATTED TEXT', 'TEXT');
		$this->field5display->Nullable = FALSE; // NOT NULL field
		$this->field5display->Required = TRUE; // Required field
		$this->field5display->Sortable = TRUE; // Allow sort
		$this->field5display->DefaultErrorMessage = $Language->phrase("IncorrectInteger");
		$this->fields['field5display'] = &$this->field5display;

		// field5displaysequence
		$this->field5displaysequence = new DbField('extrafieldstemplate', 'extrafieldstemplate', 'x_field5displaysequence', 'field5displaysequence', '`field5displaysequence`', '`field5displaysequence`', 3, 2, -1, FALSE, '`field5displaysequence`', FALSE, FALSE, FALSE, 'FORMATTED TEXT', 'TEXT');
		$this->field5displaysequence->Nullable = FALSE; // NOT NULL field
		$this->field5displaysequence->Required = TRUE; // Required field
		$this->field5displaysequence->Sortable = TRUE; // Allow sort
		$this->field5displaysequence->DefaultErrorMessage = $Language->phrase("IncorrectInteger");
		$this->fields['field5displaysequence'] = &$this->field5displaysequence;

		// field5domain
		$this->field5domain = new DbField('extrafieldstemplate', 'extrafieldstemplate', 'x_field5domain', 'field5domain', '`field5domain`', '`field5domain`', 3, 12, -1, FALSE, '`field5domain`', FALSE, FALSE, FALSE, 'FORMATTED TEXT', 'TEXT');
		$this->field5domain->Sortable = TRUE; // Allow sort
		$this->field5domain->DefaultErrorMessage = $Language->phrase("IncorrectInteger");
		$this->fields['field5domain'] = &$this->field5domain;

		// field6label
		$this->field6label = new DbField('extrafieldstemplate', 'extrafieldstemplate', 'x_field6label', 'field6label', '`field6label`', '`field6label`', 200, 30, -1, FALSE, '`field6label`', FALSE, FALSE, FALSE, 'FORMATTED TEXT', 'TEXT');
		$this->field6label->Nullable = FALSE; // NOT NULL field
		$this->field6label->Required = TRUE; // Required field
		$this->field6label->Sortable = TRUE; // Allow sort
		$this->fields['field6label'] = &$this->field6label;

		// field6type
		$this->field6type = new DbField('extrafieldstemplate', 'extrafieldstemplate', 'x_field6type', 'field6type', '`field6type`', '`field6type`', 3, 1, -1, FALSE, '`field6type`', FALSE, FALSE, FALSE, 'FORMATTED TEXT', 'TEXT');
		$this->field6type->Nullable = FALSE; // NOT NULL field
		$this->field6type->Required = TRUE; // Required field
		$this->field6type->Sortable = TRUE; // Allow sort
		$this->field6type->DefaultErrorMessage = $Language->phrase("IncorrectInteger");
		$this->fields['field6type'] = &$this->field6type;

		// field6mandatory
		$this->field6mandatory = new DbField('extrafieldstemplate', 'extrafieldstemplate', 'x_field6mandatory', 'field6mandatory', '`field6mandatory`', '`field6mandatory`', 3, 1, -1, FALSE, '`field6mandatory`', FALSE, FALSE, FALSE, 'FORMATTED TEXT', 'TEXT');
		$this->field6mandatory->Nullable = FALSE; // NOT NULL field
		$this->field6mandatory->Required = TRUE; // Required field
		$this->field6mandatory->Sortable = TRUE; // Allow sort
		$this->field6mandatory->DefaultErrorMessage = $Language->phrase("IncorrectInteger");
		$this->fields['field6mandatory'] = &$this->field6mandatory;

		// field6display
		$this->field6display = new DbField('extrafieldstemplate', 'extrafieldstemplate', 'x_field6display', 'field6display', '`field6display`', '`field6display`', 3, 1, -1, FALSE, '`field6display`', FALSE, FALSE, FALSE, 'FORMATTED TEXT', 'TEXT');
		$this->field6display->Nullable = FALSE; // NOT NULL field
		$this->field6display->Required = TRUE; // Required field
		$this->field6display->Sortable = TRUE; // Allow sort
		$this->field6display->DefaultErrorMessage = $Language->phrase("IncorrectInteger");
		$this->fields['field6display'] = &$this->field6display;

		// field6displaysequence
		$this->field6displaysequence = new DbField('extrafieldstemplate', 'extrafieldstemplate', 'x_field6displaysequence', 'field6displaysequence', '`field6displaysequence`', '`field6displaysequence`', 3, 2, -1, FALSE, '`field6displaysequence`', FALSE, FALSE, FALSE, 'FORMATTED TEXT', 'TEXT');
		$this->field6displaysequence->Nullable = FALSE; // NOT NULL field
		$this->field6displaysequence->Required = TRUE; // Required field
		$this->field6displaysequence->Sortable = TRUE; // Allow sort
		$this->field6displaysequence->DefaultErrorMessage = $Language->phrase("IncorrectInteger");
		$this->fields['field6displaysequence'] = &$this->field6displaysequence;

		// field6domain
		$this->field6domain = new DbField('extrafieldstemplate', 'extrafieldstemplate', 'x_field6domain', 'field6domain', '`field6domain`', '`field6domain`', 3, 12, -1, FALSE, '`field6domain`', FALSE, FALSE, FALSE, 'FORMATTED TEXT', 'TEXT');
		$this->field6domain->Nullable = FALSE; // NOT NULL field
		$this->field6domain->Required = TRUE; // Required field
		$this->field6domain->Sortable = TRUE; // Allow sort
		$this->field6domain->DefaultErrorMessage = $Language->phrase("IncorrectInteger");
		$this->fields['field6domain'] = &$this->field6domain;

		// field7label
		$this->field7label = new DbField('extrafieldstemplate', 'extrafieldstemplate', 'x_field7label', 'field7label', '`field7label`', '`field7label`', 200, 30, -1, FALSE, '`field7label`', FALSE, FALSE, FALSE, 'FORMATTED TEXT', 'TEXT');
		$this->field7label->Nullable = FALSE; // NOT NULL field
		$this->field7label->Required = TRUE; // Required field
		$this->field7label->Sortable = TRUE; // Allow sort
		$this->fields['field7label'] = &$this->field7label;

		// field7type
		$this->field7type = new DbField('extrafieldstemplate', 'extrafieldstemplate', 'x_field7type', 'field7type', '`field7type`', '`field7type`', 3, 1, -1, FALSE, '`field7type`', FALSE, FALSE, FALSE, 'FORMATTED TEXT', 'TEXT');
		$this->field7type->Nullable = FALSE; // NOT NULL field
		$this->field7type->Required = TRUE; // Required field
		$this->field7type->Sortable = TRUE; // Allow sort
		$this->field7type->DefaultErrorMessage = $Language->phrase("IncorrectInteger");
		$this->fields['field7type'] = &$this->field7type;

		// field7mandatory
		$this->field7mandatory = new DbField('extrafieldstemplate', 'extrafieldstemplate', 'x_field7mandatory', 'field7mandatory', '`field7mandatory`', '`field7mandatory`', 3, 1, -1, FALSE, '`field7mandatory`', FALSE, FALSE, FALSE, 'FORMATTED TEXT', 'TEXT');
		$this->field7mandatory->Nullable = FALSE; // NOT NULL field
		$this->field7mandatory->Required = TRUE; // Required field
		$this->field7mandatory->Sortable = TRUE; // Allow sort
		$this->field7mandatory->DefaultErrorMessage = $Language->phrase("IncorrectInteger");
		$this->fields['field7mandatory'] = &$this->field7mandatory;

		// field7display
		$this->field7display = new DbField('extrafieldstemplate', 'extrafieldstemplate', 'x_field7display', 'field7display', '`field7display`', '`field7display`', 3, 1, -1, FALSE, '`field7display`', FALSE, FALSE, FALSE, 'FORMATTED TEXT', 'TEXT');
		$this->field7display->Nullable = FALSE; // NOT NULL field
		$this->field7display->Required = TRUE; // Required field
		$this->field7display->Sortable = TRUE; // Allow sort
		$this->field7display->DefaultErrorMessage = $Language->phrase("IncorrectInteger");
		$this->fields['field7display'] = &$this->field7display;

		// field7displaysequence
		$this->field7displaysequence = new DbField('extrafieldstemplate', 'extrafieldstemplate', 'x_field7displaysequence', 'field7displaysequence', '`field7displaysequence`', '`field7displaysequence`', 3, 2, -1, FALSE, '`field7displaysequence`', FALSE, FALSE, FALSE, 'FORMATTED TEXT', 'TEXT');
		$this->field7displaysequence->Nullable = FALSE; // NOT NULL field
		$this->field7displaysequence->Required = TRUE; // Required field
		$this->field7displaysequence->Sortable = TRUE; // Allow sort
		$this->field7displaysequence->DefaultErrorMessage = $Language->phrase("IncorrectInteger");
		$this->fields['field7displaysequence'] = &$this->field7displaysequence;

		// field7domain
		$this->field7domain = new DbField('extrafieldstemplate', 'extrafieldstemplate', 'x_field7domain', 'field7domain', '`field7domain`', '`field7domain`', 3, 12, -1, FALSE, '`field7domain`', FALSE, FALSE, FALSE, 'FORMATTED TEXT', 'TEXT');
		$this->field7domain->Sortable = TRUE; // Allow sort
		$this->field7domain->DefaultErrorMessage = $Language->phrase("IncorrectInteger");
		$this->fields['field7domain'] = &$this->field7domain;

		// field8label
		$this->field8label = new DbField('extrafieldstemplate', 'extrafieldstemplate', 'x_field8label', 'field8label', '`field8label`', '`field8label`', 200, 30, -1, FALSE, '`field8label`', FALSE, FALSE, FALSE, 'FORMATTED TEXT', 'TEXT');
		$this->field8label->Nullable = FALSE; // NOT NULL field
		$this->field8label->Required = TRUE; // Required field
		$this->field8label->Sortable = TRUE; // Allow sort
		$this->fields['field8label'] = &$this->field8label;

		// field8type
		$this->field8type = new DbField('extrafieldstemplate', 'extrafieldstemplate', 'x_field8type', 'field8type', '`field8type`', '`field8type`', 3, 1, -1, FALSE, '`field8type`', FALSE, FALSE, FALSE, 'FORMATTED TEXT', 'TEXT');
		$this->field8type->Nullable = FALSE; // NOT NULL field
		$this->field8type->Required = TRUE; // Required field
		$this->field8type->Sortable = TRUE; // Allow sort
		$this->field8type->DefaultErrorMessage = $Language->phrase("IncorrectInteger");
		$this->fields['field8type'] = &$this->field8type;

		// field8mandatory
		$this->field8mandatory = new DbField('extrafieldstemplate', 'extrafieldstemplate', 'x_field8mandatory', 'field8mandatory', '`field8mandatory`', '`field8mandatory`', 3, 1, -1, FALSE, '`field8mandatory`', FALSE, FALSE, FALSE, 'FORMATTED TEXT', 'TEXT');
		$this->field8mandatory->Nullable = FALSE; // NOT NULL field
		$this->field8mandatory->Required = TRUE; // Required field
		$this->field8mandatory->Sortable = TRUE; // Allow sort
		$this->field8mandatory->DefaultErrorMessage = $Language->phrase("IncorrectInteger");
		$this->fields['field8mandatory'] = &$this->field8mandatory;

		// field8display
		$this->field8display = new DbField('extrafieldstemplate', 'extrafieldstemplate', 'x_field8display', 'field8display', '`field8display`', '`field8display`', 3, 1, -1, FALSE, '`field8display`', FALSE, FALSE, FALSE, 'FORMATTED TEXT', 'TEXT');
		$this->field8display->Nullable = FALSE; // NOT NULL field
		$this->field8display->Required = TRUE; // Required field
		$this->field8display->Sortable = TRUE; // Allow sort
		$this->field8display->DefaultErrorMessage = $Language->phrase("IncorrectInteger");
		$this->fields['field8display'] = &$this->field8display;

		// field8displaysequence
		$this->field8displaysequence = new DbField('extrafieldstemplate', 'extrafieldstemplate', 'x_field8displaysequence', 'field8displaysequence', '`field8displaysequence`', '`field8displaysequence`', 3, 2, -1, FALSE, '`field8displaysequence`', FALSE, FALSE, FALSE, 'FORMATTED TEXT', 'TEXT');
		$this->field8displaysequence->Nullable = FALSE; // NOT NULL field
		$this->field8displaysequence->Required = TRUE; // Required field
		$this->field8displaysequence->Sortable = TRUE; // Allow sort
		$this->field8displaysequence->DefaultErrorMessage = $Language->phrase("IncorrectInteger");
		$this->fields['field8displaysequence'] = &$this->field8displaysequence;

		// field8domain
		$this->field8domain = new DbField('extrafieldstemplate', 'extrafieldstemplate', 'x_field8domain', 'field8domain', '`field8domain`', '`field8domain`', 3, 12, -1, FALSE, '`field8domain`', FALSE, FALSE, FALSE, 'FORMATTED TEXT', 'TEXT');
		$this->field8domain->Sortable = TRUE; // Allow sort
		$this->field8domain->DefaultErrorMessage = $Language->phrase("IncorrectInteger");
		$this->fields['field8domain'] = &$this->field8domain;

		// field9label
		$this->field9label = new DbField('extrafieldstemplate', 'extrafieldstemplate', 'x_field9label', 'field9label', '`field9label`', '`field9label`', 200, 30, -1, FALSE, '`field9label`', FALSE, FALSE, FALSE, 'FORMATTED TEXT', 'TEXT');
		$this->field9label->Nullable = FALSE; // NOT NULL field
		$this->field9label->Required = TRUE; // Required field
		$this->field9label->Sortable = TRUE; // Allow sort
		$this->fields['field9label'] = &$this->field9label;

		// field9type
		$this->field9type = new DbField('extrafieldstemplate', 'extrafieldstemplate', 'x_field9type', 'field9type', '`field9type`', '`field9type`', 3, 1, -1, FALSE, '`field9type`', FALSE, FALSE, FALSE, 'FORMATTED TEXT', 'TEXT');
		$this->field9type->Nullable = FALSE; // NOT NULL field
		$this->field9type->Required = TRUE; // Required field
		$this->field9type->Sortable = TRUE; // Allow sort
		$this->field9type->DefaultErrorMessage = $Language->phrase("IncorrectInteger");
		$this->fields['field9type'] = &$this->field9type;

		// field9mandatory
		$this->field9mandatory = new DbField('extrafieldstemplate', 'extrafieldstemplate', 'x_field9mandatory', 'field9mandatory', '`field9mandatory`', '`field9mandatory`', 3, 1, -1, FALSE, '`field9mandatory`', FALSE, FALSE, FALSE, 'FORMATTED TEXT', 'TEXT');
		$this->field9mandatory->Nullable = FALSE; // NOT NULL field
		$this->field9mandatory->Required = TRUE; // Required field
		$this->field9mandatory->Sortable = TRUE; // Allow sort
		$this->field9mandatory->DefaultErrorMessage = $Language->phrase("IncorrectInteger");
		$this->fields['field9mandatory'] = &$this->field9mandatory;

		// field9display
		$this->field9display = new DbField('extrafieldstemplate', 'extrafieldstemplate', 'x_field9display', 'field9display', '`field9display`', '`field9display`', 3, 1, -1, FALSE, '`field9display`', FALSE, FALSE, FALSE, 'FORMATTED TEXT', 'TEXT');
		$this->field9display->Nullable = FALSE; // NOT NULL field
		$this->field9display->Required = TRUE; // Required field
		$this->field9display->Sortable = TRUE; // Allow sort
		$this->field9display->DefaultErrorMessage = $Language->phrase("IncorrectInteger");
		$this->fields['field9display'] = &$this->field9display;

		// field9displaysequence
		$this->field9displaysequence = new DbField('extrafieldstemplate', 'extrafieldstemplate', 'x_field9displaysequence', 'field9displaysequence', '`field9displaysequence`', '`field9displaysequence`', 3, 2, -1, FALSE, '`field9displaysequence`', FALSE, FALSE, FALSE, 'FORMATTED TEXT', 'TEXT');
		$this->field9displaysequence->Nullable = FALSE; // NOT NULL field
		$this->field9displaysequence->Required = TRUE; // Required field
		$this->field9displaysequence->Sortable = TRUE; // Allow sort
		$this->field9displaysequence->DefaultErrorMessage = $Language->phrase("IncorrectInteger");
		$this->fields['field9displaysequence'] = &$this->field9displaysequence;

		// field9domain
		$this->field9domain = new DbField('extrafieldstemplate', 'extrafieldstemplate', 'x_field9domain', 'field9domain', '`field9domain`', '`field9domain`', 3, 12, -1, FALSE, '`field9domain`', FALSE, FALSE, FALSE, 'FORMATTED TEXT', 'TEXT');
		$this->field9domain->Sortable = TRUE; // Allow sort
		$this->field9domain->DefaultErrorMessage = $Language->phrase("IncorrectInteger");
		$this->fields['field9domain'] = &$this->field9domain;

		// field10label
		$this->field10label = new DbField('extrafieldstemplate', 'extrafieldstemplate', 'x_field10label', 'field10label', '`field10label`', '`field10label`', 200, 30, -1, FALSE, '`field10label`', FALSE, FALSE, FALSE, 'FORMATTED TEXT', 'TEXT');
		$this->field10label->Nullable = FALSE; // NOT NULL field
		$this->field10label->Required = TRUE; // Required field
		$this->field10label->Sortable = TRUE; // Allow sort
		$this->fields['field10label'] = &$this->field10label;

		// field10type
		$this->field10type = new DbField('extrafieldstemplate', 'extrafieldstemplate', 'x_field10type', 'field10type', '`field10type`', '`field10type`', 3, 1, -1, FALSE, '`field10type`', FALSE, FALSE, FALSE, 'FORMATTED TEXT', 'TEXT');
		$this->field10type->Nullable = FALSE; // NOT NULL field
		$this->field10type->Required = TRUE; // Required field
		$this->field10type->Sortable = TRUE; // Allow sort
		$this->field10type->DefaultErrorMessage = $Language->phrase("IncorrectInteger");
		$this->fields['field10type'] = &$this->field10type;

		// field10mandatory
		$this->field10mandatory = new DbField('extrafieldstemplate', 'extrafieldstemplate', 'x_field10mandatory', 'field10mandatory', '`field10mandatory`', '`field10mandatory`', 3, 1, -1, FALSE, '`field10mandatory`', FALSE, FALSE, FALSE, 'FORMATTED TEXT', 'TEXT');
		$this->field10mandatory->Nullable = FALSE; // NOT NULL field
		$this->field10mandatory->Required = TRUE; // Required field
		$this->field10mandatory->Sortable = TRUE; // Allow sort
		$this->field10mandatory->DefaultErrorMessage = $Language->phrase("IncorrectInteger");
		$this->fields['field10mandatory'] = &$this->field10mandatory;

		// field10display
		$this->field10display = new DbField('extrafieldstemplate', 'extrafieldstemplate', 'x_field10display', 'field10display', '`field10display`', '`field10display`', 3, 1, -1, FALSE, '`field10display`', FALSE, FALSE, FALSE, 'FORMATTED TEXT', 'TEXT');
		$this->field10display->Nullable = FALSE; // NOT NULL field
		$this->field10display->Required = TRUE; // Required field
		$this->field10display->Sortable = TRUE; // Allow sort
		$this->field10display->DefaultErrorMessage = $Language->phrase("IncorrectInteger");
		$this->fields['field10display'] = &$this->field10display;

		// field10displaysequence
		$this->field10displaysequence = new DbField('extrafieldstemplate', 'extrafieldstemplate', 'x_field10displaysequence', 'field10displaysequence', '`field10displaysequence`', '`field10displaysequence`', 3, 2, -1, FALSE, '`field10displaysequence`', FALSE, FALSE, FALSE, 'FORMATTED TEXT', 'TEXT');
		$this->field10displaysequence->Nullable = FALSE; // NOT NULL field
		$this->field10displaysequence->Required = TRUE; // Required field
		$this->field10displaysequence->Sortable = TRUE; // Allow sort
		$this->field10displaysequence->DefaultErrorMessage = $Language->phrase("IncorrectInteger");
		$this->fields['field10displaysequence'] = &$this->field10displaysequence;

		// field10domain
		$this->field10domain = new DbField('extrafieldstemplate', 'extrafieldstemplate', 'x_field10domain', 'field10domain', '`field10domain`', '`field10domain`', 3, 12, -1, FALSE, '`field10domain`', FALSE, FALSE, FALSE, 'FORMATTED TEXT', 'TEXT');
		$this->field10domain->Sortable = TRUE; // Allow sort
		$this->field10domain->DefaultErrorMessage = $Language->phrase("IncorrectInteger");
		$this->fields['field10domain'] = &$this->field10domain;

		// lastupdatedate
		$this->lastupdatedate = new DbField('extrafieldstemplate', 'extrafieldstemplate', 'x_lastupdatedate', 'lastupdatedate', '`lastupdatedate`', CastDateFieldForLike("`lastupdatedate`", 0, "DB"), 135, 19, 0, FALSE, '`lastupdatedate`', FALSE, FALSE, FALSE, 'FORMATTED TEXT', 'TEXT');
		$this->lastupdatedate->Sortable = TRUE; // Allow sort
		$this->lastupdatedate->DefaultErrorMessage = str_replace("%s", $GLOBALS["DATE_FORMAT"], $Language->phrase("IncorrectDate"));
		$this->fields['lastupdatedate'] = &$this->lastupdatedate;
	}

	// Field Visibility
	public function getFieldVisibility($fldParm)
	{
		global $Security;
		return $this->$fldParm->Visible; // Returns original value
	}

	// Set left column class (must be predefined col-*-* classes of Bootstrap grid system)
	function setLeftColumnClass($class)
	{
		if (preg_match('/^col\-(\w+)\-(\d+)$/', $class, $match)) {
			$this->LeftColumnClass = $class . " col-form-label ew-label";
			$this->RightColumnClass = "col-" . $match[1] . "-" . strval(12 - (int)$match[2]);
			$this->OffsetColumnClass = $this->RightColumnClass . " " . str_replace("col-", "offset-", $class);
			$this->TableLeftColumnClass = preg_replace('/^col-\w+-(\d+)$/', "w-col-$1", $class); // Change to w-col-*
		}
	}

	// Single column sort
	public function updateSort(&$fld)
	{
		if ($this->CurrentOrder == $fld->Name) {
			$sortField = $fld->Expression;
			$lastSort = $fld->getSort();
			if ($this->CurrentOrderType == "ASC" || $this->CurrentOrderType == "DESC") {
				$thisSort = $this->CurrentOrderType;
			} else {
				$thisSort = ($lastSort == "ASC") ? "DESC" : "ASC";
			}
			$fld->setSort($thisSort);
			$this->setSessionOrderBy($sortField . " " . $thisSort); // Save to Session
		} else {
			$fld->setSort("");
		}
	}

	// Table level SQL
	public function getSqlFrom() // From
	{
		return ($this->SqlFrom != "") ? $this->SqlFrom : "`extrafieldstemplate`";
	}
	public function sqlFrom() // For backward compatibility
	{
		return $this->getSqlFrom();
	}
	public function setSqlFrom($v)
	{
		$this->SqlFrom = $v;
	}
	public function getSqlSelect() // Select
	{
		return ($this->SqlSelect != "") ? $this->SqlSelect : "SELECT * FROM " . $this->getSqlFrom();
	}
	public function sqlSelect() // For backward compatibility
	{
		return $this->getSqlSelect();
	}
	public function setSqlSelect($v)
	{
		$this->SqlSelect = $v;
	}
	public function getSqlWhere() // Where
	{
		$where = ($this->SqlWhere != "") ? $this->SqlWhere : "";
		$this->TableFilter = "";
		AddFilter($where, $this->TableFilter);
		return $where;
	}
	public function sqlWhere() // For backward compatibility
	{
		return $this->getSqlWhere();
	}
	public function setSqlWhere($v)
	{
		$this->SqlWhere = $v;
	}
	public function getSqlGroupBy() // Group By
	{
		return ($this->SqlGroupBy != "") ? $this->SqlGroupBy : "";
	}
	public function sqlGroupBy() // For backward compatibility
	{
		return $this->getSqlGroupBy();
	}
	public function setSqlGroupBy($v)
	{
		$this->SqlGroupBy = $v;
	}
	public function getSqlHaving() // Having
	{
		return ($this->SqlHaving != "") ? $this->SqlHaving : "";
	}
	public function sqlHaving() // For backward compatibility
	{
		return $this->getSqlHaving();
	}
	public function setSqlHaving($v)
	{
		$this->SqlHaving = $v;
	}
	public function getSqlOrderBy() // Order By
	{
		return ($this->SqlOrderBy != "") ? $this->SqlOrderBy : "";
	}
	public function sqlOrderBy() // For backward compatibility
	{
		return $this->getSqlOrderBy();
	}
	public function setSqlOrderBy($v)
	{
		$this->SqlOrderBy = $v;
	}

	// Apply User ID filters
	public function applyUserIDFilters($filter, $id = "")
	{
		return $filter;
	}

	// Check if User ID security allows view all
	public function userIDAllow($id = "")
	{
		$allow = $this->UserIDAllowSecurity;
		switch ($id) {
			case "add":
			case "copy":
			case "gridadd":
			case "register":
			case "addopt":
				return (($allow & 1) == 1);
			case "edit":
			case "gridedit":
			case "update":
			case "changepwd":
			case "forgotpwd":
				return (($allow & 4) == 4);
			case "delete":
				return (($allow & 2) == 2);
			case "view":
				return (($allow & 32) == 32);
			case "search":
				return (($allow & 64) == 64);
			case "lookup":
				return (($allow & 256) == 256);
			default:
				return (($allow & 8) == 8);
		}
	}

	// Get recordset
	public function getRecordset($sql, $rowcnt = -1, $offset = -1)
	{
		$conn = $this->getConnection();
		$conn->raiseErrorFn = Config("ERROR_FUNC");
		$rs = $conn->selectLimit($sql, $rowcnt, $offset);
		$conn->raiseErrorFn = "";
		return $rs;
	}

	// Get record count
	public function getRecordCount($sql, $c = NULL)
	{
		$cnt = -1;
		$rs = NULL;
		$sql = preg_replace('/\/\*BeginOrderBy\*\/[\s\S]+\/\*EndOrderBy\*\//', "", $sql); // Remove ORDER BY clause (MSSQL)
		$pattern = '/^SELECT\s([\s\S]+)\sFROM\s/i';

		// Skip Custom View / SubQuery / SELECT DISTINCT / ORDER BY
		if (($this->TableType == 'TABLE' || $this->TableType == 'VIEW' || $this->TableType == 'LINKTABLE') &&
			preg_match($pattern, $sql) && !preg_match('/\(\s*(SELECT[^)]+)\)/i', $sql) &&
			!preg_match('/^\s*select\s+distinct\s+/i', $sql) && !preg_match('/\s+order\s+by\s+/i', $sql)) {
			$sqlwrk = "SELECT COUNT(*) FROM " . preg_replace($pattern, "", $sql);
		} else {
			$sqlwrk = "SELECT COUNT(*) FROM (" . $sql . ") COUNT_TABLE";
		}
		$conn = $c ?: $this->getConnection();
		if ($rs = $conn->execute($sqlwrk)) {
			if (!$rs->EOF && $rs->FieldCount() > 0) {
				$cnt = $rs->fields[0];
				$rs->close();
			}
			return (int)$cnt;
		}

		// Unable to get count, get record count directly
		if ($rs = $conn->execute($sql)) {
			$cnt = $rs->RecordCount();
			$rs->close();
			return (int)$cnt;
		}
		return $cnt;
	}

	// Get SQL
	public function getSql($where, $orderBy = "")
	{
		return BuildSelectSql($this->getSqlSelect(), $this->getSqlWhere(),
			$this->getSqlGroupBy(), $this->getSqlHaving(), $this->getSqlOrderBy(),
			$where, $orderBy);
	}

	// Table SQL
	public function getCurrentSql()
	{
		$filter = $this->CurrentFilter;
		$filter = $this->applyUserIDFilters($filter);
		$sort = $this->getSessionOrderBy();
		return $this->getSql($filter, $sort);
	}

	// Table SQL with List page filter
	public function getListSql()
	{
		$filter = $this->UseSessionForListSql ? $this->getSessionWhere() : "";
		AddFilter($filter, $this->CurrentFilter);
		$filter = $this->applyUserIDFilters($filter);
		$this->Recordset_Selecting($filter);
		$select = $this->getSqlSelect();
		$sort = $this->UseSessionForListSql ? $this->getSessionOrderBy() : "";
		return BuildSelectSql($select, $this->getSqlWhere(), $this->getSqlGroupBy(),
			$this->getSqlHaving(), $this->getSqlOrderBy(), $filter, $sort);
	}

	// Get ORDER BY clause
	public function getOrderBy()
	{
		$sort = $this->getSessionOrderBy();
		return BuildSelectSql("", "", "", "", $this->getSqlOrderBy(), "", $sort);
	}

	// Get record count based on filter (for detail record count in master table pages)
	public function loadRecordCount($filter)
	{
		$origFilter = $this->CurrentFilter;
		$this->CurrentFilter = $filter;
		$this->Recordset_Selecting($this->CurrentFilter);
		$select = $this->TableType == 'CUSTOMVIEW' ? $this->getSqlSelect() : "SELECT * FROM " . $this->getSqlFrom();
		$groupBy = $this->TableType == 'CUSTOMVIEW' ? $this->getSqlGroupBy() : "";
		$having = $this->TableType == 'CUSTOMVIEW' ? $this->getSqlHaving() : "";
		$sql = BuildSelectSql($select, $this->getSqlWhere(), $groupBy, $having, "", $this->CurrentFilter, "");
		$cnt = $this->getRecordCount($sql);
		$this->CurrentFilter = $origFilter;
		return $cnt;
	}

	// Get record count (for current List page)
	public function listRecordCount()
	{
		$filter = $this->getSessionWhere();
		AddFilter($filter, $this->CurrentFilter);
		$filter = $this->applyUserIDFilters($filter);
		$this->Recordset_Selecting($filter);
		$select = $this->TableType == 'CUSTOMVIEW' ? $this->getSqlSelect() : "SELECT * FROM " . $this->getSqlFrom();
		$groupBy = $this->TableType == 'CUSTOMVIEW' ? $this->getSqlGroupBy() : "";
		$having = $this->TableType == 'CUSTOMVIEW' ? $this->getSqlHaving() : "";
		$sql = BuildSelectSql($select, $this->getSqlWhere(), $groupBy, $having, "", $filter, "");
		$cnt = $this->getRecordCount($sql);
		return $cnt;
	}

	// INSERT statement
	protected function insertSql(&$rs)
	{
		$names = "";
		$values = "";
		foreach ($rs as $name => $value) {
			if (!isset($this->fields[$name]) || $this->fields[$name]->IsCustom)
				continue;
			$names .= $this->fields[$name]->Expression . ",";
			$values .= QuotedValue($value, $this->fields[$name]->DataType, $this->Dbid) . ",";
		}
		$names = preg_replace('/,+$/', "", $names);
		$values = preg_replace('/,+$/', "", $values);
		return "INSERT INTO " . $this->UpdateTable . " (" . $names . ") VALUES (" . $values . ")";
	}

	// Insert
	public function insert(&$rs)
	{
		$conn = $this->getConnection();
		$success = $conn->execute($this->insertSql($rs));
		if ($success) {

			// Get insert id if necessary
			$this->extrafieldsid->setDbValue($conn->insert_ID());
			$rs['extrafieldsid'] = $this->extrafieldsid->DbValue;
			if ($this->AuditTrailOnAdd)
				$this->writeAuditTrailOnAdd($rs);
		}
		return $success;
	}

	// UPDATE statement
	protected function updateSql(&$rs, $where = "", $curfilter = TRUE)
	{
		$sql = "UPDATE " . $this->UpdateTable . " SET ";
		foreach ($rs as $name => $value) {
			if (!isset($this->fields[$name]) || $this->fields[$name]->IsCustom || $this->fields[$name]->IsAutoIncrement)
				continue;
			$sql .= $this->fields[$name]->Expression . "=";
			$sql .= QuotedValue($value, $this->fields[$name]->DataType, $this->Dbid) . ",";
		}
		$sql = preg_replace('/,+$/', "", $sql);
		$filter = ($curfilter) ? $this->CurrentFilter : "";
		if (is_array($where))
			$where = $this->arrayToFilter($where);
		AddFilter($filter, $where);
		if ($filter != "")
			$sql .= " WHERE " . $filter;
		return $sql;
	}

	// Update
	public function update(&$rs, $where = "", $rsold = NULL, $curfilter = TRUE)
	{
		$conn = $this->getConnection();
		$success = $conn->execute($this->updateSql($rs, $where, $curfilter));
		if ($success && $this->AuditTrailOnEdit && $rsold) {
			$rsaudit = $rs;
			$fldname = 'extrafieldsid';
			if (!array_key_exists($fldname, $rsaudit))
				$rsaudit[$fldname] = $rsold[$fldname];
			$this->writeAuditTrailOnEdit($rsold, $rsaudit);
		}
		return $success;
	}

	// DELETE statement
	protected function deleteSql(&$rs, $where = "", $curfilter = TRUE)
	{
		$sql = "DELETE FROM " . $this->UpdateTable . " WHERE ";
		if (is_array($where))
			$where = $this->arrayToFilter($where);
		if ($rs) {
			if (array_key_exists('extrafieldsid', $rs))
				AddFilter($where, QuotedName('extrafieldsid', $this->Dbid) . '=' . QuotedValue($rs['extrafieldsid'], $this->extrafieldsid->DataType, $this->Dbid));
		}
		$filter = ($curfilter) ? $this->CurrentFilter : "";
		AddFilter($filter, $where);
		if ($filter != "")
			$sql .= $filter;
		else
			$sql .= "0=1"; // Avoid delete
		return $sql;
	}

	// Delete
	public function delete(&$rs, $where = "", $curfilter = FALSE)
	{
		$success = TRUE;
		$conn = $this->getConnection();
		if ($success)
			$success = $conn->execute($this->deleteSql($rs, $where, $curfilter));
		if ($success && $this->AuditTrailOnDelete)
			$this->writeAuditTrailOnDelete($rs);
		return $success;
	}

	// Load DbValue from recordset or array
	protected function loadDbValues(&$rs)
	{
		if (!$rs || !is_array($rs) && $rs->EOF)
			return;
		$row = is_array($rs) ? $rs : $rs->fields;
		$this->extrafieldsid->DbValue = $row['extrafieldsid'];
		$this->merchantid->DbValue = $row['merchantid'];
		$this->name->DbValue = $row['name'];
		$this->field1label->DbValue = $row['field1label'];
		$this->field1type->DbValue = $row['field1type'];
		$this->field1mandatory->DbValue = $row['field1mandatory'];
		$this->field1display->DbValue = $row['field1display'];
		$this->field1displaysequence->DbValue = $row['field1displaysequence'];
		$this->field1domain->DbValue = $row['field1domain'];
		$this->field2label->DbValue = $row['field2label'];
		$this->field2type->DbValue = $row['field2type'];
		$this->field2mandatory->DbValue = $row['field2mandatory'];
		$this->field2display->DbValue = $row['field2display'];
		$this->field2displaysequence->DbValue = $row['field2displaysequence'];
		$this->field2domain->DbValue = $row['field2domain'];
		$this->field3label->DbValue = $row['field3label'];
		$this->field3type->DbValue = $row['field3type'];
		$this->field3mandatory->DbValue = $row['field3mandatory'];
		$this->field3display->DbValue = $row['field3display'];
		$this->field3displaysequence->DbValue = $row['field3displaysequence'];
		$this->field3domain->DbValue = $row['field3domain'];
		$this->field4label->DbValue = $row['field4label'];
		$this->field4type->DbValue = $row['field4type'];
		$this->field4mandatory->DbValue = $row['field4mandatory'];
		$this->field4display->DbValue = $row['field4display'];
		$this->field4displaysequence->DbValue = $row['field4displaysequence'];
		$this->field4domain->DbValue = $row['field4domain'];
		$this->field5label->DbValue = $row['field5label'];
		$this->field5type->DbValue = $row['field5type'];
		$this->field5mandatory->DbValue = $row['field5mandatory'];
		$this->field5display->DbValue = $row['field5display'];
		$this->field5displaysequence->DbValue = $row['field5displaysequence'];
		$this->field5domain->DbValue = $row['field5domain'];
		$this->field6label->DbValue = $row['field6label'];
		$this->field6type->DbValue = $row['field6type'];
		$this->field6mandatory->DbValue = $row['field6mandatory'];
		$this->field6display->DbValue = $row['field6display'];
		$this->field6displaysequence->DbValue = $row['field6displaysequence'];
		$this->field6domain->DbValue = $row['field6domain'];
		$this->field7label->DbValue = $row['field7label'];
		$this->field7type->DbValue = $row['field7type'];
		$this->field7mandatory->DbValue = $row['field7mandatory'];
		$this->field7display->DbValue = $row['field7display'];
		$this->field7displaysequence->DbValue = $row['field7displaysequence'];
		$this->field7domain->DbValue = $row['field7domain'];
		$this->field8label->DbValue = $row['field8label'];
		$this->field8type->DbValue = $row['field8type'];
		$this->field8mandatory->DbValue = $row['field8mandatory'];
		$this->field8display->DbValue = $row['field8display'];
		$this->field8displaysequence->DbValue = $row['field8displaysequence'];
		$this->field8domain->DbValue = $row['field8domain'];
		$this->field9label->DbValue = $row['field9label'];
		$this->field9type->DbValue = $row['field9type'];
		$this->field9mandatory->DbValue = $row['field9mandatory'];
		$this->field9display->DbValue = $row['field9display'];
		$this->field9displaysequence->DbValue = $row['field9displaysequence'];
		$this->field9domain->DbValue = $row['field9domain'];
		$this->field10label->DbValue = $row['field10label'];
		$this->field10type->DbValue = $row['field10type'];
		$this->field10mandatory->DbValue = $row['field10mandatory'];
		$this->field10display->DbValue = $row['field10display'];
		$this->field10displaysequence->DbValue = $row['field10displaysequence'];
		$this->field10domain->DbValue = $row['field10domain'];
		$this->lastupdatedate->DbValue = $row['lastupdatedate'];
	}

	// Delete uploaded files
	public function deleteUploadedFiles($row)
	{
		$this->loadDbValues($row);
	}

	// Record filter WHERE clause
	protected function sqlKeyFilter()
	{
		return "`extrafieldsid` = @extrafieldsid@";
	}

	// Get record filter
	public function getRecordFilter($row = NULL)
	{
		$keyFilter = $this->sqlKeyFilter();
		if (is_array($row))
			$val = array_key_exists('extrafieldsid', $row) ? $row['extrafieldsid'] : NULL;
		else
			$val = $this->extrafieldsid->OldValue !== NULL ? $this->extrafieldsid->OldValue : $this->extrafieldsid->CurrentValue;
		if (!is_numeric($val))
			return "0=1"; // Invalid key
		if ($val == NULL)
			return "0=1"; // Invalid key
		else
			$keyFilter = str_replace("@extrafieldsid@", AdjustSql($val, $this->Dbid), $keyFilter); // Replace key value
		return $keyFilter;
	}

	// Return page URL
	public function getReturnUrl()
	{
		$name = PROJECT_NAME . "_" . $this->TableVar . "_" . Config("TABLE_RETURN_URL");

		// Get referer URL automatically
		if (ServerVar("HTTP_REFERER") != "" && ReferPageName() != CurrentPageName() && ReferPageName() != "login.php") // Referer not same page or login page
			$_SESSION[$name] = ServerVar("HTTP_REFERER"); // Save to Session
		if (@$_SESSION[$name] != "") {
			return $_SESSION[$name];
		} else {
			return "extrafieldstemplatelist.php";
		}
	}
	public function setReturnUrl($v)
	{
		$_SESSION[PROJECT_NAME . "_" . $this->TableVar . "_" . Config("TABLE_RETURN_URL")] = $v;
	}

	// Get modal caption
	public function getModalCaption($pageName)
	{
		global $Language;
		if ($pageName == "extrafieldstemplateview.php")
			return $Language->phrase("View");
		elseif ($pageName == "extrafieldstemplateedit.php")
			return $Language->phrase("Edit");
		elseif ($pageName == "extrafieldstemplateadd.php")
			return $Language->phrase("Add");
		else
			return "";
	}

	// List URL
	public function getListUrl()
	{
		return "extrafieldstemplatelist.php";
	}

	// View URL
	public function getViewUrl($parm = "")
	{
		if ($parm != "")
			$url = $this->keyUrl("extrafieldstemplateview.php", $this->getUrlParm($parm));
		else
			$url = $this->keyUrl("extrafieldstemplateview.php", $this->getUrlParm(Config("TABLE_SHOW_DETAIL") . "="));
		return $this->addMasterUrl($url);
	}

	// Add URL
	public function getAddUrl($parm = "")
	{
		if ($parm != "")
			$url = "extrafieldstemplateadd.php?" . $this->getUrlParm($parm);
		else
			$url = "extrafieldstemplateadd.php";
		return $this->addMasterUrl($url);
	}

	// Edit URL
	public function getEditUrl($parm = "")
	{
		$url = $this->keyUrl("extrafieldstemplateedit.php", $this->getUrlParm($parm));
		return $this->addMasterUrl($url);
	}

	// Inline edit URL
	public function getInlineEditUrl()
	{
		$url = $this->keyUrl(CurrentPageName(), $this->getUrlParm("action=edit"));
		return $this->addMasterUrl($url);
	}

	// Copy URL
	public function getCopyUrl($parm = "")
	{
		$url = $this->keyUrl("extrafieldstemplateadd.php", $this->getUrlParm($parm));
		return $this->addMasterUrl($url);
	}

	// Inline copy URL
	public function getInlineCopyUrl()
	{
		$url = $this->keyUrl(CurrentPageName(), $this->getUrlParm("action=copy"));
		return $this->addMasterUrl($url);
	}

	// Delete URL
	public function getDeleteUrl()
	{
		return $this->keyUrl("extrafieldstemplatedelete.php", $this->getUrlParm());
	}

	// Add master url
	public function addMasterUrl($url)
	{
		return $url;
	}
	public function keyToJson($htmlEncode = FALSE)
	{
		$json = "";
		$json .= "extrafieldsid:" . JsonEncode($this->extrafieldsid->CurrentValue, "number");
		$json = "{" . $json . "}";
		if ($htmlEncode)
			$json = HtmlEncode($json);
		return $json;
	}

	// Add key value to URL
	public function keyUrl($url, $parm = "")
	{
		$url = $url . "?";
		if ($parm != "")
			$url .= $parm . "&";
		if ($this->extrafieldsid->CurrentValue != NULL) {
			$url .= "extrafieldsid=" . urlencode($this->extrafieldsid->CurrentValue);
		} else {
			return "javascript:ew.alert(ew.language.phrase('InvalidRecord'));";
		}
		return $url;
	}

	// Sort URL
	public function sortUrl(&$fld)
	{
		if ($this->CurrentAction || $this->isExport() ||
			in_array($fld->Type, [128, 204, 205])) { // Unsortable data type
				return "";
		} elseif ($fld->Sortable) {
			$urlParm = $this->getUrlParm("order=" . urlencode($fld->Name) . "&amp;ordertype=" . $fld->reverseSort());
			return $this->addMasterUrl(CurrentPageName() . "?" . $urlParm);
		} else {
			return "";
		}
	}

	// Get record keys from Post/Get/Session
	public function getRecordKeys()
	{
		$arKeys = [];
		$arKey = [];
		if (Param("key_m") !== NULL) {
			$arKeys = Param("key_m");
			$cnt = count($arKeys);
		} else {
			if (Param("extrafieldsid") !== NULL)
				$arKeys[] = Param("extrafieldsid");
			elseif (IsApi() && Key(0) !== NULL)
				$arKeys[] = Key(0);
			elseif (IsApi() && Route(2) !== NULL)
				$arKeys[] = Route(2);
			else
				$arKeys = NULL; // Do not setup

			//return $arKeys; // Do not return yet, so the values will also be checked by the following code
		}

		// Check keys
		$ar = [];
		if (is_array($arKeys)) {
			foreach ($arKeys as $key) {
				if (!is_numeric($key))
					continue;
				$ar[] = $key;
			}
		}
		return $ar;
	}

	// Get filter from record keys
	public function getFilterFromRecordKeys($setCurrent = TRUE)
	{
		$arKeys = $this->getRecordKeys();
		$keyFilter = "";
		foreach ($arKeys as $key) {
			if ($keyFilter != "") $keyFilter .= " OR ";
			if ($setCurrent)
				$this->extrafieldsid->CurrentValue = $key;
			else
				$this->extrafieldsid->OldValue = $key;
			$keyFilter .= "(" . $this->getRecordFilter() . ")";
		}
		return $keyFilter;
	}

	// Load rows based on filter
	public function &loadRs($filter)
	{

		// Set up filter (WHERE Clause)
		$sql = $this->getSql($filter);
		$conn = $this->getConnection();
		$rs = $conn->execute($sql);
		return $rs;
	}

	// Load row values from recordset
	public function loadListRowValues(&$rs)
	{
		$this->extrafieldsid->setDbValue($rs->fields('extrafieldsid'));
		$this->merchantid->setDbValue($rs->fields('merchantid'));
		$this->name->setDbValue($rs->fields('name'));
		$this->field1label->setDbValue($rs->fields('field1label'));
		$this->field1type->setDbValue($rs->fields('field1type'));
		$this->field1mandatory->setDbValue($rs->fields('field1mandatory'));
		$this->field1display->setDbValue($rs->fields('field1display'));
		$this->field1displaysequence->setDbValue($rs->fields('field1displaysequence'));
		$this->field1domain->setDbValue($rs->fields('field1domain'));
		$this->field2label->setDbValue($rs->fields('field2label'));
		$this->field2type->setDbValue($rs->fields('field2type'));
		$this->field2mandatory->setDbValue($rs->fields('field2mandatory'));
		$this->field2display->setDbValue($rs->fields('field2display'));
		$this->field2displaysequence->setDbValue($rs->fields('field2displaysequence'));
		$this->field2domain->setDbValue($rs->fields('field2domain'));
		$this->field3label->setDbValue($rs->fields('field3label'));
		$this->field3type->setDbValue($rs->fields('field3type'));
		$this->field3mandatory->setDbValue($rs->fields('field3mandatory'));
		$this->field3display->setDbValue($rs->fields('field3display'));
		$this->field3displaysequence->setDbValue($rs->fields('field3displaysequence'));
		$this->field3domain->setDbValue($rs->fields('field3domain'));
		$this->field4label->setDbValue($rs->fields('field4label'));
		$this->field4type->setDbValue($rs->fields('field4type'));
		$this->field4mandatory->setDbValue($rs->fields('field4mandatory'));
		$this->field4display->setDbValue($rs->fields('field4display'));
		$this->field4displaysequence->setDbValue($rs->fields('field4displaysequence'));
		$this->field4domain->setDbValue($rs->fields('field4domain'));
		$this->field5label->setDbValue($rs->fields('field5label'));
		$this->field5type->setDbValue($rs->fields('field5type'));
		$this->field5mandatory->setDbValue($rs->fields('field5mandatory'));
		$this->field5display->setDbValue($rs->fields('field5display'));
		$this->field5displaysequence->setDbValue($rs->fields('field5displaysequence'));
		$this->field5domain->setDbValue($rs->fields('field5domain'));
		$this->field6label->setDbValue($rs->fields('field6label'));
		$this->field6type->setDbValue($rs->fields('field6type'));
		$this->field6mandatory->setDbValue($rs->fields('field6mandatory'));
		$this->field6display->setDbValue($rs->fields('field6display'));
		$this->field6displaysequence->setDbValue($rs->fields('field6displaysequence'));
		$this->field6domain->setDbValue($rs->fields('field6domain'));
		$this->field7label->setDbValue($rs->fields('field7label'));
		$this->field7type->setDbValue($rs->fields('field7type'));
		$this->field7mandatory->setDbValue($rs->fields('field7mandatory'));
		$this->field7display->setDbValue($rs->fields('field7display'));
		$this->field7displaysequence->setDbValue($rs->fields('field7displaysequence'));
		$this->field7domain->setDbValue($rs->fields('field7domain'));
		$this->field8label->setDbValue($rs->fields('field8label'));
		$this->field8type->setDbValue($rs->fields('field8type'));
		$this->field8mandatory->setDbValue($rs->fields('field8mandatory'));
		$this->field8display->setDbValue($rs->fields('field8display'));
		$this->field8displaysequence->setDbValue($rs->fields('field8displaysequence'));
		$this->field8domain->setDbValue($rs->fields('field8domain'));
		$this->field9label->setDbValue($rs->fields('field9label'));
		$this->field9type->setDbValue($rs->fields('field9type'));
		$this->field9mandatory->setDbValue($rs->fields('field9mandatory'));
		$this->field9display->setDbValue($rs->fields('field9display'));
		$this->field9displaysequence->setDbValue($rs->fields('field9displaysequence'));
		$this->field9domain->setDbValue($rs->fields('field9domain'));
		$this->field10label->setDbValue($rs->fields('field10label'));
		$this->field10type->setDbValue($rs->fields('field10type'));
		$this->field10mandatory->setDbValue($rs->fields('field10mandatory'));
		$this->field10display->setDbValue($rs->fields('field10display'));
		$this->field10displaysequence->setDbValue($rs->fields('field10displaysequence'));
		$this->field10domain->setDbValue($rs->fields('field10domain'));
		$this->lastupdatedate->setDbValue($rs->fields('lastupdatedate'));
	}

	// Render list row values
	public function renderListRow()
	{
		global $Security, $CurrentLanguage, $Language;

		// Call Row Rendering event
		$this->Row_Rendering();

		// Common render codes
		// extrafieldsid
		// merchantid
		// name
		// field1label
		// field1type
		// field1mandatory
		// field1display
		// field1displaysequence
		// field1domain
		// field2label
		// field2type
		// field2mandatory
		// field2display
		// field2displaysequence
		// field2domain
		// field3label
		// field3type
		// field3mandatory
		// field3display
		// field3displaysequence
		// field3domain
		// field4label
		// field4type
		// field4mandatory
		// field4display
		// field4displaysequence
		// field4domain
		// field5label
		// field5type
		// field5mandatory
		// field5display
		// field5displaysequence
		// field5domain
		// field6label
		// field6type
		// field6mandatory
		// field6display
		// field6displaysequence
		// field6domain
		// field7label
		// field7type
		// field7mandatory
		// field7display
		// field7displaysequence
		// field7domain
		// field8label
		// field8type
		// field8mandatory
		// field8display
		// field8displaysequence
		// field8domain
		// field9label
		// field9type
		// field9mandatory
		// field9display
		// field9displaysequence
		// field9domain
		// field10label
		// field10type
		// field10mandatory
		// field10display
		// field10displaysequence
		// field10domain
		// lastupdatedate
		// extrafieldsid

		$this->extrafieldsid->ViewValue = $this->extrafieldsid->CurrentValue;
		$this->extrafieldsid->ViewCustomAttributes = "";

		// merchantid
		$this->merchantid->ViewValue = $this->merchantid->CurrentValue;
		$this->merchantid->ViewCustomAttributes = "";

		// name
		$this->name->ViewValue = $this->name->CurrentValue;
		$this->name->ViewCustomAttributes = "";

		// field1label
		$this->field1label->ViewValue = $this->field1label->CurrentValue;
		$this->field1label->ViewCustomAttributes = "";

		// field1type
		$this->field1type->ViewValue = $this->field1type->CurrentValue;
		$this->field1type->ViewCustomAttributes = "";

		// field1mandatory
		$this->field1mandatory->ViewValue = $this->field1mandatory->CurrentValue;
		$this->field1mandatory->ViewCustomAttributes = "";

		// field1display
		$this->field1display->ViewValue = $this->field1display->CurrentValue;
		$this->field1display->ViewCustomAttributes = "";

		// field1displaysequence
		$this->field1displaysequence->ViewValue = $this->field1displaysequence->CurrentValue;
		$this->field1displaysequence->ViewCustomAttributes = "";

		// field1domain
		$this->field1domain->ViewValue = $this->field1domain->CurrentValue;
		$this->field1domain->ViewCustomAttributes = "";

		// field2label
		$this->field2label->ViewValue = $this->field2label->CurrentValue;
		$this->field2label->ViewCustomAttributes = "";

		// field2type
		$this->field2type->ViewValue = $this->field2type->CurrentValue;
		$this->field2type->ViewCustomAttributes = "";

		// field2mandatory
		$this->field2mandatory->ViewValue = $this->field2mandatory->CurrentValue;
		$this->field2mandatory->ViewCustomAttributes = "";

		// field2display
		$this->field2display->ViewValue = $this->field2display->CurrentValue;
		$this->field2display->ViewCustomAttributes = "";

		// field2displaysequence
		$this->field2displaysequence->ViewValue = $this->field2displaysequence->CurrentValue;
		$this->field2displaysequence->ViewCustomAttributes = "";

		// field2domain
		$this->field2domain->ViewValue = $this->field2domain->CurrentValue;
		$this->field2domain->ViewCustomAttributes = "";

		// field3label
		$this->field3label->ViewValue = $this->field3label->CurrentValue;
		$this->field3label->ViewCustomAttributes = "";

		// field3type
		$this->field3type->ViewValue = $this->field3type->CurrentValue;
		$this->field3type->ViewCustomAttributes = "";

		// field3mandatory
		$this->field3mandatory->ViewValue = $this->field3mandatory->CurrentValue;
		$this->field3mandatory->ViewCustomAttributes = "";

		// field3display
		$this->field3display->ViewValue = $this->field3display->CurrentValue;
		$this->field3display->ViewCustomAttributes = "";

		// field3displaysequence
		$this->field3displaysequence->ViewValue = $this->field3displaysequence->CurrentValue;
		$this->field3displaysequence->ViewCustomAttributes = "";

		// field3domain
		$this->field3domain->ViewValue = $this->field3domain->CurrentValue;
		$this->field3domain->ViewCustomAttributes = "";

		// field4label
		$this->field4label->ViewValue = $this->field4label->CurrentValue;
		$this->field4label->ViewCustomAttributes = "";

		// field4type
		$this->field4type->ViewValue = $this->field4type->CurrentValue;
		$this->field4type->ViewCustomAttributes = "";

		// field4mandatory
		$this->field4mandatory->ViewValue = $this->field4mandatory->CurrentValue;
		$this->field4mandatory->ViewCustomAttributes = "";

		// field4display
		$this->field4display->ViewValue = $this->field4display->CurrentValue;
		$this->field4display->ViewCustomAttributes = "";

		// field4displaysequence
		$this->field4displaysequence->ViewValue = $this->field4displaysequence->CurrentValue;
		$this->field4displaysequence->ViewCustomAttributes = "";

		// field4domain
		$this->field4domain->ViewValue = $this->field4domain->CurrentValue;
		$this->field4domain->ViewCustomAttributes = "";

		// field5label
		$this->field5label->ViewValue = $this->field5label->CurrentValue;
		$this->field5label->ViewCustomAttributes = "";

		// field5type
		$this->field5type->ViewValue = $this->field5type->CurrentValue;
		$this->field5type->ViewCustomAttributes = "";

		// field5mandatory
		$this->field5mandatory->ViewValue = $this->field5mandatory->CurrentValue;
		$this->field5mandatory->ViewCustomAttributes = "";

		// field5display
		$this->field5display->ViewValue = $this->field5display->CurrentValue;
		$this->field5display->ViewCustomAttributes = "";

		// field5displaysequence
		$this->field5displaysequence->ViewValue = $this->field5displaysequence->CurrentValue;
		$this->field5displaysequence->ViewCustomAttributes = "";

		// field5domain
		$this->field5domain->ViewValue = $this->field5domain->CurrentValue;
		$this->field5domain->ViewCustomAttributes = "";

		// field6label
		$this->field6label->ViewValue = $this->field6label->CurrentValue;
		$this->field6label->ViewCustomAttributes = "";

		// field6type
		$this->field6type->ViewValue = $this->field6type->CurrentValue;
		$this->field6type->ViewCustomAttributes = "";

		// field6mandatory
		$this->field6mandatory->ViewValue = $this->field6mandatory->CurrentValue;
		$this->field6mandatory->ViewCustomAttributes = "";

		// field6display
		$this->field6display->ViewValue = $this->field6display->CurrentValue;
		$this->field6display->ViewCustomAttributes = "";

		// field6displaysequence
		$this->field6displaysequence->ViewValue = $this->field6displaysequence->CurrentValue;
		$this->field6displaysequence->ViewCustomAttributes = "";

		// field6domain
		$this->field6domain->ViewValue = $this->field6domain->CurrentValue;
		$this->field6domain->ViewCustomAttributes = "";

		// field7label
		$this->field7label->ViewValue = $this->field7label->CurrentValue;
		$this->field7label->ViewCustomAttributes = "";

		// field7type
		$this->field7type->ViewValue = $this->field7type->CurrentValue;
		$this->field7type->ViewCustomAttributes = "";

		// field7mandatory
		$this->field7mandatory->ViewValue = $this->field7mandatory->CurrentValue;
		$this->field7mandatory->ViewCustomAttributes = "";

		// field7display
		$this->field7display->ViewValue = $this->field7display->CurrentValue;
		$this->field7display->ViewCustomAttributes = "";

		// field7displaysequence
		$this->field7displaysequence->ViewValue = $this->field7displaysequence->CurrentValue;
		$this->field7displaysequence->ViewCustomAttributes = "";

		// field7domain
		$this->field7domain->ViewValue = $this->field7domain->CurrentValue;
		$this->field7domain->ViewCustomAttributes = "";

		// field8label
		$this->field8label->ViewValue = $this->field8label->CurrentValue;
		$this->field8label->ViewCustomAttributes = "";

		// field8type
		$this->field8type->ViewValue = $this->field8type->CurrentValue;
		$this->field8type->ViewCustomAttributes = "";

		// field8mandatory
		$this->field8mandatory->ViewValue = $this->field8mandatory->CurrentValue;
		$this->field8mandatory->ViewCustomAttributes = "";

		// field8display
		$this->field8display->ViewValue = $this->field8display->CurrentValue;
		$this->field8display->ViewCustomAttributes = "";

		// field8displaysequence
		$this->field8displaysequence->ViewValue = $this->field8displaysequence->CurrentValue;
		$this->field8displaysequence->ViewCustomAttributes = "";

		// field8domain
		$this->field8domain->ViewValue = $this->field8domain->CurrentValue;
		$this->field8domain->ViewCustomAttributes = "";

		// field9label
		$this->field9label->ViewValue = $this->field9label->CurrentValue;
		$this->field9label->ViewCustomAttributes = "";

		// field9type
		$this->field9type->ViewValue = $this->field9type->CurrentValue;
		$this->field9type->ViewCustomAttributes = "";

		// field9mandatory
		$this->field9mandatory->ViewValue = $this->field9mandatory->CurrentValue;
		$this->field9mandatory->ViewCustomAttributes = "";

		// field9display
		$this->field9display->ViewValue = $this->field9display->CurrentValue;
		$this->field9display->ViewCustomAttributes = "";

		// field9displaysequence
		$this->field9displaysequence->ViewValue = $this->field9displaysequence->CurrentValue;
		$this->field9displaysequence->ViewCustomAttributes = "";

		// field9domain
		$this->field9domain->ViewValue = $this->field9domain->CurrentValue;
		$this->field9domain->ViewCustomAttributes = "";

		// field10label
		$this->field10label->ViewValue = $this->field10label->CurrentValue;
		$this->field10label->ViewCustomAttributes = "";

		// field10type
		$this->field10type->ViewValue = $this->field10type->CurrentValue;
		$this->field10type->ViewCustomAttributes = "";

		// field10mandatory
		$this->field10mandatory->ViewValue = $this->field10mandatory->CurrentValue;
		$this->field10mandatory->ViewCustomAttributes = "";

		// field10display
		$this->field10display->ViewValue = $this->field10display->CurrentValue;
		$this->field10display->ViewCustomAttributes = "";

		// field10displaysequence
		$this->field10displaysequence->ViewValue = $this->field10displaysequence->CurrentValue;
		$this->field10displaysequence->ViewCustomAttributes = "";

		// field10domain
		$this->field10domain->ViewValue = $this->field10domain->CurrentValue;
		$this->field10domain->ViewCustomAttributes = "";

		// lastupdatedate
		$this->lastupdatedate->ViewValue = $this->lastupdatedate->CurrentValue;
		$this->lastupdatedate->ViewValue = FormatDateTime($this->lastupdatedate->ViewValue, 0);
		$this->lastupdatedate->ViewCustomAttributes = "";

		// extrafieldsid
		$this->extrafieldsid->LinkCustomAttributes = "";
		$this->extrafieldsid->HrefValue = "";
		$this->extrafieldsid->TooltipValue = "";

		// merchantid
		$this->merchantid->LinkCustomAttributes = "";
		$this->merchantid->HrefValue = "";
		$this->merchantid->TooltipValue = "";

		// name
		$this->name->LinkCustomAttributes = "";
		$this->name->HrefValue = "";
		$this->name->TooltipValue = "";

		// field1label
		$this->field1label->LinkCustomAttributes = "";
		$this->field1label->HrefValue = "";
		$this->field1label->TooltipValue = "";

		// field1type
		$this->field1type->LinkCustomAttributes = "";
		$this->field1type->HrefValue = "";
		$this->field1type->TooltipValue = "";

		// field1mandatory
		$this->field1mandatory->LinkCustomAttributes = "";
		$this->field1mandatory->HrefValue = "";
		$this->field1mandatory->TooltipValue = "";

		// field1display
		$this->field1display->LinkCustomAttributes = "";
		$this->field1display->HrefValue = "";
		$this->field1display->TooltipValue = "";

		// field1displaysequence
		$this->field1displaysequence->LinkCustomAttributes = "";
		$this->field1displaysequence->HrefValue = "";
		$this->field1displaysequence->TooltipValue = "";

		// field1domain
		$this->field1domain->LinkCustomAttributes = "";
		$this->field1domain->HrefValue = "";
		$this->field1domain->TooltipValue = "";

		// field2label
		$this->field2label->LinkCustomAttributes = "";
		$this->field2label->HrefValue = "";
		$this->field2label->TooltipValue = "";

		// field2type
		$this->field2type->LinkCustomAttributes = "";
		$this->field2type->HrefValue = "";
		$this->field2type->TooltipValue = "";

		// field2mandatory
		$this->field2mandatory->LinkCustomAttributes = "";
		$this->field2mandatory->HrefValue = "";
		$this->field2mandatory->TooltipValue = "";

		// field2display
		$this->field2display->LinkCustomAttributes = "";
		$this->field2display->HrefValue = "";
		$this->field2display->TooltipValue = "";

		// field2displaysequence
		$this->field2displaysequence->LinkCustomAttributes = "";
		$this->field2displaysequence->HrefValue = "";
		$this->field2displaysequence->TooltipValue = "";

		// field2domain
		$this->field2domain->LinkCustomAttributes = "";
		$this->field2domain->HrefValue = "";
		$this->field2domain->TooltipValue = "";

		// field3label
		$this->field3label->LinkCustomAttributes = "";
		$this->field3label->HrefValue = "";
		$this->field3label->TooltipValue = "";

		// field3type
		$this->field3type->LinkCustomAttributes = "";
		$this->field3type->HrefValue = "";
		$this->field3type->TooltipValue = "";

		// field3mandatory
		$this->field3mandatory->LinkCustomAttributes = "";
		$this->field3mandatory->HrefValue = "";
		$this->field3mandatory->TooltipValue = "";

		// field3display
		$this->field3display->LinkCustomAttributes = "";
		$this->field3display->HrefValue = "";
		$this->field3display->TooltipValue = "";

		// field3displaysequence
		$this->field3displaysequence->LinkCustomAttributes = "";
		$this->field3displaysequence->HrefValue = "";
		$this->field3displaysequence->TooltipValue = "";

		// field3domain
		$this->field3domain->LinkCustomAttributes = "";
		$this->field3domain->HrefValue = "";
		$this->field3domain->TooltipValue = "";

		// field4label
		$this->field4label->LinkCustomAttributes = "";
		$this->field4label->HrefValue = "";
		$this->field4label->TooltipValue = "";

		// field4type
		$this->field4type->LinkCustomAttributes = "";
		$this->field4type->HrefValue = "";
		$this->field4type->TooltipValue = "";

		// field4mandatory
		$this->field4mandatory->LinkCustomAttributes = "";
		$this->field4mandatory->HrefValue = "";
		$this->field4mandatory->TooltipValue = "";

		// field4display
		$this->field4display->LinkCustomAttributes = "";
		$this->field4display->HrefValue = "";
		$this->field4display->TooltipValue = "";

		// field4displaysequence
		$this->field4displaysequence->LinkCustomAttributes = "";
		$this->field4displaysequence->HrefValue = "";
		$this->field4displaysequence->TooltipValue = "";

		// field4domain
		$this->field4domain->LinkCustomAttributes = "";
		$this->field4domain->HrefValue = "";
		$this->field4domain->TooltipValue = "";

		// field5label
		$this->field5label->LinkCustomAttributes = "";
		$this->field5label->HrefValue = "";
		$this->field5label->TooltipValue = "";

		// field5type
		$this->field5type->LinkCustomAttributes = "";
		$this->field5type->HrefValue = "";
		$this->field5type->TooltipValue = "";

		// field5mandatory
		$this->field5mandatory->LinkCustomAttributes = "";
		$this->field5mandatory->HrefValue = "";
		$this->field5mandatory->TooltipValue = "";

		// field5display
		$this->field5display->LinkCustomAttributes = "";
		$this->field5display->HrefValue = "";
		$this->field5display->TooltipValue = "";

		// field5displaysequence
		$this->field5displaysequence->LinkCustomAttributes = "";
		$this->field5displaysequence->HrefValue = "";
		$this->field5displaysequence->TooltipValue = "";

		// field5domain
		$this->field5domain->LinkCustomAttributes = "";
		$this->field5domain->HrefValue = "";
		$this->field5domain->TooltipValue = "";

		// field6label
		$this->field6label->LinkCustomAttributes = "";
		$this->field6label->HrefValue = "";
		$this->field6label->TooltipValue = "";

		// field6type
		$this->field6type->LinkCustomAttributes = "";
		$this->field6type->HrefValue = "";
		$this->field6type->TooltipValue = "";

		// field6mandatory
		$this->field6mandatory->LinkCustomAttributes = "";
		$this->field6mandatory->HrefValue = "";
		$this->field6mandatory->TooltipValue = "";

		// field6display
		$this->field6display->LinkCustomAttributes = "";
		$this->field6display->HrefValue = "";
		$this->field6display->TooltipValue = "";

		// field6displaysequence
		$this->field6displaysequence->LinkCustomAttributes = "";
		$this->field6displaysequence->HrefValue = "";
		$this->field6displaysequence->TooltipValue = "";

		// field6domain
		$this->field6domain->LinkCustomAttributes = "";
		$this->field6domain->HrefValue = "";
		$this->field6domain->TooltipValue = "";

		// field7label
		$this->field7label->LinkCustomAttributes = "";
		$this->field7label->HrefValue = "";
		$this->field7label->TooltipValue = "";

		// field7type
		$this->field7type->LinkCustomAttributes = "";
		$this->field7type->HrefValue = "";
		$this->field7type->TooltipValue = "";

		// field7mandatory
		$this->field7mandatory->LinkCustomAttributes = "";
		$this->field7mandatory->HrefValue = "";
		$this->field7mandatory->TooltipValue = "";

		// field7display
		$this->field7display->LinkCustomAttributes = "";
		$this->field7display->HrefValue = "";
		$this->field7display->TooltipValue = "";

		// field7displaysequence
		$this->field7displaysequence->LinkCustomAttributes = "";
		$this->field7displaysequence->HrefValue = "";
		$this->field7displaysequence->TooltipValue = "";

		// field7domain
		$this->field7domain->LinkCustomAttributes = "";
		$this->field7domain->HrefValue = "";
		$this->field7domain->TooltipValue = "";

		// field8label
		$this->field8label->LinkCustomAttributes = "";
		$this->field8label->HrefValue = "";
		$this->field8label->TooltipValue = "";

		// field8type
		$this->field8type->LinkCustomAttributes = "";
		$this->field8type->HrefValue = "";
		$this->field8type->TooltipValue = "";

		// field8mandatory
		$this->field8mandatory->LinkCustomAttributes = "";
		$this->field8mandatory->HrefValue = "";
		$this->field8mandatory->TooltipValue = "";

		// field8display
		$this->field8display->LinkCustomAttributes = "";
		$this->field8display->HrefValue = "";
		$this->field8display->TooltipValue = "";

		// field8displaysequence
		$this->field8displaysequence->LinkCustomAttributes = "";
		$this->field8displaysequence->HrefValue = "";
		$this->field8displaysequence->TooltipValue = "";

		// field8domain
		$this->field8domain->LinkCustomAttributes = "";
		$this->field8domain->HrefValue = "";
		$this->field8domain->TooltipValue = "";

		// field9label
		$this->field9label->LinkCustomAttributes = "";
		$this->field9label->HrefValue = "";
		$this->field9label->TooltipValue = "";

		// field9type
		$this->field9type->LinkCustomAttributes = "";
		$this->field9type->HrefValue = "";
		$this->field9type->TooltipValue = "";

		// field9mandatory
		$this->field9mandatory->LinkCustomAttributes = "";
		$this->field9mandatory->HrefValue = "";
		$this->field9mandatory->TooltipValue = "";

		// field9display
		$this->field9display->LinkCustomAttributes = "";
		$this->field9display->HrefValue = "";
		$this->field9display->TooltipValue = "";

		// field9displaysequence
		$this->field9displaysequence->LinkCustomAttributes = "";
		$this->field9displaysequence->HrefValue = "";
		$this->field9displaysequence->TooltipValue = "";

		// field9domain
		$this->field9domain->LinkCustomAttributes = "";
		$this->field9domain->HrefValue = "";
		$this->field9domain->TooltipValue = "";

		// field10label
		$this->field10label->LinkCustomAttributes = "";
		$this->field10label->HrefValue = "";
		$this->field10label->TooltipValue = "";

		// field10type
		$this->field10type->LinkCustomAttributes = "";
		$this->field10type->HrefValue = "";
		$this->field10type->TooltipValue = "";

		// field10mandatory
		$this->field10mandatory->LinkCustomAttributes = "";
		$this->field10mandatory->HrefValue = "";
		$this->field10mandatory->TooltipValue = "";

		// field10display
		$this->field10display->LinkCustomAttributes = "";
		$this->field10display->HrefValue = "";
		$this->field10display->TooltipValue = "";

		// field10displaysequence
		$this->field10displaysequence->LinkCustomAttributes = "";
		$this->field10displaysequence->HrefValue = "";
		$this->field10displaysequence->TooltipValue = "";

		// field10domain
		$this->field10domain->LinkCustomAttributes = "";
		$this->field10domain->HrefValue = "";
		$this->field10domain->TooltipValue = "";

		// lastupdatedate
		$this->lastupdatedate->LinkCustomAttributes = "";
		$this->lastupdatedate->HrefValue = "";
		$this->lastupdatedate->TooltipValue = "";

		// Call Row Rendered event
		$this->Row_Rendered();

		// Save data for Custom Template
		$this->Rows[] = $this->customTemplateFieldValues();
	}

	// Render edit row values
	public function renderEditRow()
	{
		global $Security, $CurrentLanguage, $Language;

		// Call Row Rendering event
		$this->Row_Rendering();

		// extrafieldsid
		$this->extrafieldsid->EditAttrs["class"] = "form-control";
		$this->extrafieldsid->EditCustomAttributes = "";
		$this->extrafieldsid->EditValue = $this->extrafieldsid->CurrentValue;
		$this->extrafieldsid->ViewCustomAttributes = "";

		// merchantid
		$this->merchantid->EditAttrs["class"] = "form-control";
		$this->merchantid->EditCustomAttributes = "";
		$this->merchantid->EditValue = $this->merchantid->CurrentValue;
		$this->merchantid->PlaceHolder = RemoveHtml($this->merchantid->caption());

		// name
		$this->name->EditAttrs["class"] = "form-control";
		$this->name->EditCustomAttributes = "";
		if (!$this->name->Raw)
			$this->name->CurrentValue = HtmlDecode($this->name->CurrentValue);
		$this->name->EditValue = $this->name->CurrentValue;
		$this->name->PlaceHolder = RemoveHtml($this->name->caption());

		// field1label
		$this->field1label->EditAttrs["class"] = "form-control";
		$this->field1label->EditCustomAttributes = "";
		if (!$this->field1label->Raw)
			$this->field1label->CurrentValue = HtmlDecode($this->field1label->CurrentValue);
		$this->field1label->EditValue = $this->field1label->CurrentValue;
		$this->field1label->PlaceHolder = RemoveHtml($this->field1label->caption());

		// field1type
		$this->field1type->EditAttrs["class"] = "form-control";
		$this->field1type->EditCustomAttributes = "";
		$this->field1type->EditValue = $this->field1type->CurrentValue;
		$this->field1type->PlaceHolder = RemoveHtml($this->field1type->caption());

		// field1mandatory
		$this->field1mandatory->EditAttrs["class"] = "form-control";
		$this->field1mandatory->EditCustomAttributes = "";
		$this->field1mandatory->EditValue = $this->field1mandatory->CurrentValue;
		$this->field1mandatory->PlaceHolder = RemoveHtml($this->field1mandatory->caption());

		// field1display
		$this->field1display->EditAttrs["class"] = "form-control";
		$this->field1display->EditCustomAttributes = "";
		$this->field1display->EditValue = $this->field1display->CurrentValue;
		$this->field1display->PlaceHolder = RemoveHtml($this->field1display->caption());

		// field1displaysequence
		$this->field1displaysequence->EditAttrs["class"] = "form-control";
		$this->field1displaysequence->EditCustomAttributes = "";
		$this->field1displaysequence->EditValue = $this->field1displaysequence->CurrentValue;
		$this->field1displaysequence->PlaceHolder = RemoveHtml($this->field1displaysequence->caption());

		// field1domain
		$this->field1domain->EditAttrs["class"] = "form-control";
		$this->field1domain->EditCustomAttributes = "";
		$this->field1domain->EditValue = $this->field1domain->CurrentValue;
		$this->field1domain->PlaceHolder = RemoveHtml($this->field1domain->caption());

		// field2label
		$this->field2label->EditAttrs["class"] = "form-control";
		$this->field2label->EditCustomAttributes = "";
		if (!$this->field2label->Raw)
			$this->field2label->CurrentValue = HtmlDecode($this->field2label->CurrentValue);
		$this->field2label->EditValue = $this->field2label->CurrentValue;
		$this->field2label->PlaceHolder = RemoveHtml($this->field2label->caption());

		// field2type
		$this->field2type->EditAttrs["class"] = "form-control";
		$this->field2type->EditCustomAttributes = "";
		$this->field2type->EditValue = $this->field2type->CurrentValue;
		$this->field2type->PlaceHolder = RemoveHtml($this->field2type->caption());

		// field2mandatory
		$this->field2mandatory->EditAttrs["class"] = "form-control";
		$this->field2mandatory->EditCustomAttributes = "";
		$this->field2mandatory->EditValue = $this->field2mandatory->CurrentValue;
		$this->field2mandatory->PlaceHolder = RemoveHtml($this->field2mandatory->caption());

		// field2display
		$this->field2display->EditAttrs["class"] = "form-control";
		$this->field2display->EditCustomAttributes = "";
		$this->field2display->EditValue = $this->field2display->CurrentValue;
		$this->field2display->PlaceHolder = RemoveHtml($this->field2display->caption());

		// field2displaysequence
		$this->field2displaysequence->EditAttrs["class"] = "form-control";
		$this->field2displaysequence->EditCustomAttributes = "";
		$this->field2displaysequence->EditValue = $this->field2displaysequence->CurrentValue;
		$this->field2displaysequence->PlaceHolder = RemoveHtml($this->field2displaysequence->caption());

		// field2domain
		$this->field2domain->EditAttrs["class"] = "form-control";
		$this->field2domain->EditCustomAttributes = "";
		$this->field2domain->EditValue = $this->field2domain->CurrentValue;
		$this->field2domain->PlaceHolder = RemoveHtml($this->field2domain->caption());

		// field3label
		$this->field3label->EditAttrs["class"] = "form-control";
		$this->field3label->EditCustomAttributes = "";
		if (!$this->field3label->Raw)
			$this->field3label->CurrentValue = HtmlDecode($this->field3label->CurrentValue);
		$this->field3label->EditValue = $this->field3label->CurrentValue;
		$this->field3label->PlaceHolder = RemoveHtml($this->field3label->caption());

		// field3type
		$this->field3type->EditAttrs["class"] = "form-control";
		$this->field3type->EditCustomAttributes = "";
		$this->field3type->EditValue = $this->field3type->CurrentValue;
		$this->field3type->PlaceHolder = RemoveHtml($this->field3type->caption());

		// field3mandatory
		$this->field3mandatory->EditAttrs["class"] = "form-control";
		$this->field3mandatory->EditCustomAttributes = "";
		$this->field3mandatory->EditValue = $this->field3mandatory->CurrentValue;
		$this->field3mandatory->PlaceHolder = RemoveHtml($this->field3mandatory->caption());

		// field3display
		$this->field3display->EditAttrs["class"] = "form-control";
		$this->field3display->EditCustomAttributes = "";
		$this->field3display->EditValue = $this->field3display->CurrentValue;
		$this->field3display->PlaceHolder = RemoveHtml($this->field3display->caption());

		// field3displaysequence
		$this->field3displaysequence->EditAttrs["class"] = "form-control";
		$this->field3displaysequence->EditCustomAttributes = "";
		$this->field3displaysequence->EditValue = $this->field3displaysequence->CurrentValue;
		$this->field3displaysequence->PlaceHolder = RemoveHtml($this->field3displaysequence->caption());

		// field3domain
		$this->field3domain->EditAttrs["class"] = "form-control";
		$this->field3domain->EditCustomAttributes = "";
		$this->field3domain->EditValue = $this->field3domain->CurrentValue;
		$this->field3domain->PlaceHolder = RemoveHtml($this->field3domain->caption());

		// field4label
		$this->field4label->EditAttrs["class"] = "form-control";
		$this->field4label->EditCustomAttributes = "";
		if (!$this->field4label->Raw)
			$this->field4label->CurrentValue = HtmlDecode($this->field4label->CurrentValue);
		$this->field4label->EditValue = $this->field4label->CurrentValue;
		$this->field4label->PlaceHolder = RemoveHtml($this->field4label->caption());

		// field4type
		$this->field4type->EditAttrs["class"] = "form-control";
		$this->field4type->EditCustomAttributes = "";
		$this->field4type->EditValue = $this->field4type->CurrentValue;
		$this->field4type->PlaceHolder = RemoveHtml($this->field4type->caption());

		// field4mandatory
		$this->field4mandatory->EditAttrs["class"] = "form-control";
		$this->field4mandatory->EditCustomAttributes = "";
		$this->field4mandatory->EditValue = $this->field4mandatory->CurrentValue;
		$this->field4mandatory->PlaceHolder = RemoveHtml($this->field4mandatory->caption());

		// field4display
		$this->field4display->EditAttrs["class"] = "form-control";
		$this->field4display->EditCustomAttributes = "";
		$this->field4display->EditValue = $this->field4display->CurrentValue;
		$this->field4display->PlaceHolder = RemoveHtml($this->field4display->caption());

		// field4displaysequence
		$this->field4displaysequence->EditAttrs["class"] = "form-control";
		$this->field4displaysequence->EditCustomAttributes = "";
		$this->field4displaysequence->EditValue = $this->field4displaysequence->CurrentValue;
		$this->field4displaysequence->PlaceHolder = RemoveHtml($this->field4displaysequence->caption());

		// field4domain
		$this->field4domain->EditAttrs["class"] = "form-control";
		$this->field4domain->EditCustomAttributes = "";
		$this->field4domain->EditValue = $this->field4domain->CurrentValue;
		$this->field4domain->PlaceHolder = RemoveHtml($this->field4domain->caption());

		// field5label
		$this->field5label->EditAttrs["class"] = "form-control";
		$this->field5label->EditCustomAttributes = "";
		if (!$this->field5label->Raw)
			$this->field5label->CurrentValue = HtmlDecode($this->field5label->CurrentValue);
		$this->field5label->EditValue = $this->field5label->CurrentValue;
		$this->field5label->PlaceHolder = RemoveHtml($this->field5label->caption());

		// field5type
		$this->field5type->EditAttrs["class"] = "form-control";
		$this->field5type->EditCustomAttributes = "";
		$this->field5type->EditValue = $this->field5type->CurrentValue;
		$this->field5type->PlaceHolder = RemoveHtml($this->field5type->caption());

		// field5mandatory
		$this->field5mandatory->EditAttrs["class"] = "form-control";
		$this->field5mandatory->EditCustomAttributes = "";
		$this->field5mandatory->EditValue = $this->field5mandatory->CurrentValue;
		$this->field5mandatory->PlaceHolder = RemoveHtml($this->field5mandatory->caption());

		// field5display
		$this->field5display->EditAttrs["class"] = "form-control";
		$this->field5display->EditCustomAttributes = "";
		$this->field5display->EditValue = $this->field5display->CurrentValue;
		$this->field5display->PlaceHolder = RemoveHtml($this->field5display->caption());

		// field5displaysequence
		$this->field5displaysequence->EditAttrs["class"] = "form-control";
		$this->field5displaysequence->EditCustomAttributes = "";
		$this->field5displaysequence->EditValue = $this->field5displaysequence->CurrentValue;
		$this->field5displaysequence->PlaceHolder = RemoveHtml($this->field5displaysequence->caption());

		// field5domain
		$this->field5domain->EditAttrs["class"] = "form-control";
		$this->field5domain->EditCustomAttributes = "";
		$this->field5domain->EditValue = $this->field5domain->CurrentValue;
		$this->field5domain->PlaceHolder = RemoveHtml($this->field5domain->caption());

		// field6label
		$this->field6label->EditAttrs["class"] = "form-control";
		$this->field6label->EditCustomAttributes = "";
		if (!$this->field6label->Raw)
			$this->field6label->CurrentValue = HtmlDecode($this->field6label->CurrentValue);
		$this->field6label->EditValue = $this->field6label->CurrentValue;
		$this->field6label->PlaceHolder = RemoveHtml($this->field6label->caption());

		// field6type
		$this->field6type->EditAttrs["class"] = "form-control";
		$this->field6type->EditCustomAttributes = "";
		$this->field6type->EditValue = $this->field6type->CurrentValue;
		$this->field6type->PlaceHolder = RemoveHtml($this->field6type->caption());

		// field6mandatory
		$this->field6mandatory->EditAttrs["class"] = "form-control";
		$this->field6mandatory->EditCustomAttributes = "";
		$this->field6mandatory->EditValue = $this->field6mandatory->CurrentValue;
		$this->field6mandatory->PlaceHolder = RemoveHtml($this->field6mandatory->caption());

		// field6display
		$this->field6display->EditAttrs["class"] = "form-control";
		$this->field6display->EditCustomAttributes = "";
		$this->field6display->EditValue = $this->field6display->CurrentValue;
		$this->field6display->PlaceHolder = RemoveHtml($this->field6display->caption());

		// field6displaysequence
		$this->field6displaysequence->EditAttrs["class"] = "form-control";
		$this->field6displaysequence->EditCustomAttributes = "";
		$this->field6displaysequence->EditValue = $this->field6displaysequence->CurrentValue;
		$this->field6displaysequence->PlaceHolder = RemoveHtml($this->field6displaysequence->caption());

		// field6domain
		$this->field6domain->EditAttrs["class"] = "form-control";
		$this->field6domain->EditCustomAttributes = "";
		$this->field6domain->EditValue = $this->field6domain->CurrentValue;
		$this->field6domain->PlaceHolder = RemoveHtml($this->field6domain->caption());

		// field7label
		$this->field7label->EditAttrs["class"] = "form-control";
		$this->field7label->EditCustomAttributes = "";
		if (!$this->field7label->Raw)
			$this->field7label->CurrentValue = HtmlDecode($this->field7label->CurrentValue);
		$this->field7label->EditValue = $this->field7label->CurrentValue;
		$this->field7label->PlaceHolder = RemoveHtml($this->field7label->caption());

		// field7type
		$this->field7type->EditAttrs["class"] = "form-control";
		$this->field7type->EditCustomAttributes = "";
		$this->field7type->EditValue = $this->field7type->CurrentValue;
		$this->field7type->PlaceHolder = RemoveHtml($this->field7type->caption());

		// field7mandatory
		$this->field7mandatory->EditAttrs["class"] = "form-control";
		$this->field7mandatory->EditCustomAttributes = "";
		$this->field7mandatory->EditValue = $this->field7mandatory->CurrentValue;
		$this->field7mandatory->PlaceHolder = RemoveHtml($this->field7mandatory->caption());

		// field7display
		$this->field7display->EditAttrs["class"] = "form-control";
		$this->field7display->EditCustomAttributes = "";
		$this->field7display->EditValue = $this->field7display->CurrentValue;
		$this->field7display->PlaceHolder = RemoveHtml($this->field7display->caption());

		// field7displaysequence
		$this->field7displaysequence->EditAttrs["class"] = "form-control";
		$this->field7displaysequence->EditCustomAttributes = "";
		$this->field7displaysequence->EditValue = $this->field7displaysequence->CurrentValue;
		$this->field7displaysequence->PlaceHolder = RemoveHtml($this->field7displaysequence->caption());

		// field7domain
		$this->field7domain->EditAttrs["class"] = "form-control";
		$this->field7domain->EditCustomAttributes = "";
		$this->field7domain->EditValue = $this->field7domain->CurrentValue;
		$this->field7domain->PlaceHolder = RemoveHtml($this->field7domain->caption());

		// field8label
		$this->field8label->EditAttrs["class"] = "form-control";
		$this->field8label->EditCustomAttributes = "";
		if (!$this->field8label->Raw)
			$this->field8label->CurrentValue = HtmlDecode($this->field8label->CurrentValue);
		$this->field8label->EditValue = $this->field8label->CurrentValue;
		$this->field8label->PlaceHolder = RemoveHtml($this->field8label->caption());

		// field8type
		$this->field8type->EditAttrs["class"] = "form-control";
		$this->field8type->EditCustomAttributes = "";
		$this->field8type->EditValue = $this->field8type->CurrentValue;
		$this->field8type->PlaceHolder = RemoveHtml($this->field8type->caption());

		// field8mandatory
		$this->field8mandatory->EditAttrs["class"] = "form-control";
		$this->field8mandatory->EditCustomAttributes = "";
		$this->field8mandatory->EditValue = $this->field8mandatory->CurrentValue;
		$this->field8mandatory->PlaceHolder = RemoveHtml($this->field8mandatory->caption());

		// field8display
		$this->field8display->EditAttrs["class"] = "form-control";
		$this->field8display->EditCustomAttributes = "";
		$this->field8display->EditValue = $this->field8display->CurrentValue;
		$this->field8display->PlaceHolder = RemoveHtml($this->field8display->caption());

		// field8displaysequence
		$this->field8displaysequence->EditAttrs["class"] = "form-control";
		$this->field8displaysequence->EditCustomAttributes = "";
		$this->field8displaysequence->EditValue = $this->field8displaysequence->CurrentValue;
		$this->field8displaysequence->PlaceHolder = RemoveHtml($this->field8displaysequence->caption());

		// field8domain
		$this->field8domain->EditAttrs["class"] = "form-control";
		$this->field8domain->EditCustomAttributes = "";
		$this->field8domain->EditValue = $this->field8domain->CurrentValue;
		$this->field8domain->PlaceHolder = RemoveHtml($this->field8domain->caption());

		// field9label
		$this->field9label->EditAttrs["class"] = "form-control";
		$this->field9label->EditCustomAttributes = "";
		if (!$this->field9label->Raw)
			$this->field9label->CurrentValue = HtmlDecode($this->field9label->CurrentValue);
		$this->field9label->EditValue = $this->field9label->CurrentValue;
		$this->field9label->PlaceHolder = RemoveHtml($this->field9label->caption());

		// field9type
		$this->field9type->EditAttrs["class"] = "form-control";
		$this->field9type->EditCustomAttributes = "";
		$this->field9type->EditValue = $this->field9type->CurrentValue;
		$this->field9type->PlaceHolder = RemoveHtml($this->field9type->caption());

		// field9mandatory
		$this->field9mandatory->EditAttrs["class"] = "form-control";
		$this->field9mandatory->EditCustomAttributes = "";
		$this->field9mandatory->EditValue = $this->field9mandatory->CurrentValue;
		$this->field9mandatory->PlaceHolder = RemoveHtml($this->field9mandatory->caption());

		// field9display
		$this->field9display->EditAttrs["class"] = "form-control";
		$this->field9display->EditCustomAttributes = "";
		$this->field9display->EditValue = $this->field9display->CurrentValue;
		$this->field9display->PlaceHolder = RemoveHtml($this->field9display->caption());

		// field9displaysequence
		$this->field9displaysequence->EditAttrs["class"] = "form-control";
		$this->field9displaysequence->EditCustomAttributes = "";
		$this->field9displaysequence->EditValue = $this->field9displaysequence->CurrentValue;
		$this->field9displaysequence->PlaceHolder = RemoveHtml($this->field9displaysequence->caption());

		// field9domain
		$this->field9domain->EditAttrs["class"] = "form-control";
		$this->field9domain->EditCustomAttributes = "";
		$this->field9domain->EditValue = $this->field9domain->CurrentValue;
		$this->field9domain->PlaceHolder = RemoveHtml($this->field9domain->caption());

		// field10label
		$this->field10label->EditAttrs["class"] = "form-control";
		$this->field10label->EditCustomAttributes = "";
		if (!$this->field10label->Raw)
			$this->field10label->CurrentValue = HtmlDecode($this->field10label->CurrentValue);
		$this->field10label->EditValue = $this->field10label->CurrentValue;
		$this->field10label->PlaceHolder = RemoveHtml($this->field10label->caption());

		// field10type
		$this->field10type->EditAttrs["class"] = "form-control";
		$this->field10type->EditCustomAttributes = "";
		$this->field10type->EditValue = $this->field10type->CurrentValue;
		$this->field10type->PlaceHolder = RemoveHtml($this->field10type->caption());

		// field10mandatory
		$this->field10mandatory->EditAttrs["class"] = "form-control";
		$this->field10mandatory->EditCustomAttributes = "";
		$this->field10mandatory->EditValue = $this->field10mandatory->CurrentValue;
		$this->field10mandatory->PlaceHolder = RemoveHtml($this->field10mandatory->caption());

		// field10display
		$this->field10display->EditAttrs["class"] = "form-control";
		$this->field10display->EditCustomAttributes = "";
		$this->field10display->EditValue = $this->field10display->CurrentValue;
		$this->field10display->PlaceHolder = RemoveHtml($this->field10display->caption());

		// field10displaysequence
		$this->field10displaysequence->EditAttrs["class"] = "form-control";
		$this->field10displaysequence->EditCustomAttributes = "";
		$this->field10displaysequence->EditValue = $this->field10displaysequence->CurrentValue;
		$this->field10displaysequence->PlaceHolder = RemoveHtml($this->field10displaysequence->caption());

		// field10domain
		$this->field10domain->EditAttrs["class"] = "form-control";
		$this->field10domain->EditCustomAttributes = "";
		$this->field10domain->EditValue = $this->field10domain->CurrentValue;
		$this->field10domain->PlaceHolder = RemoveHtml($this->field10domain->caption());

		// lastupdatedate
		$this->lastupdatedate->EditAttrs["class"] = "form-control";
		$this->lastupdatedate->EditCustomAttributes = "";
		$this->lastupdatedate->EditValue = FormatDateTime($this->lastupdatedate->CurrentValue, 8);
		$this->lastupdatedate->PlaceHolder = RemoveHtml($this->lastupdatedate->caption());

		// Call Row Rendered event
		$this->Row_Rendered();
	}

	// Aggregate list row values
	public function aggregateListRowValues()
	{
	}

	// Aggregate list row (for rendering)
	public function aggregateListRow()
	{

		// Call Row Rendered event
		$this->Row_Rendered();
	}

	// Export data in HTML/CSV/Word/Excel/Email/PDF format
	public function exportDocument($doc, $recordset, $startRec = 1, $stopRec = 1, $exportPageType = "")
	{
		if (!$recordset || !$doc)
			return;
		if (!$doc->ExportCustom) {

			// Write header
			$doc->exportTableHeader();
			if ($doc->Horizontal) { // Horizontal format, write header
				$doc->beginExportRow();
				if ($exportPageType == "view") {
					$doc->exportCaption($this->extrafieldsid);
					$doc->exportCaption($this->merchantid);
					$doc->exportCaption($this->name);
					$doc->exportCaption($this->field1label);
					$doc->exportCaption($this->field1type);
					$doc->exportCaption($this->field1mandatory);
					$doc->exportCaption($this->field1display);
					$doc->exportCaption($this->field1displaysequence);
					$doc->exportCaption($this->field1domain);
					$doc->exportCaption($this->field2label);
					$doc->exportCaption($this->field2type);
					$doc->exportCaption($this->field2mandatory);
					$doc->exportCaption($this->field2display);
					$doc->exportCaption($this->field2displaysequence);
					$doc->exportCaption($this->field2domain);
					$doc->exportCaption($this->field3label);
					$doc->exportCaption($this->field3type);
					$doc->exportCaption($this->field3mandatory);
					$doc->exportCaption($this->field3display);
					$doc->exportCaption($this->field3displaysequence);
					$doc->exportCaption($this->field3domain);
					$doc->exportCaption($this->field4label);
					$doc->exportCaption($this->field4type);
					$doc->exportCaption($this->field4mandatory);
					$doc->exportCaption($this->field4display);
					$doc->exportCaption($this->field4displaysequence);
					$doc->exportCaption($this->field4domain);
					$doc->exportCaption($this->field5label);
					$doc->exportCaption($this->field5type);
					$doc->exportCaption($this->field5mandatory);
					$doc->exportCaption($this->field5display);
					$doc->exportCaption($this->field5displaysequence);
					$doc->exportCaption($this->field5domain);
					$doc->exportCaption($this->field6label);
					$doc->exportCaption($this->field6type);
					$doc->exportCaption($this->field6mandatory);
					$doc->exportCaption($this->field6display);
					$doc->exportCaption($this->field6displaysequence);
					$doc->exportCaption($this->field6domain);
					$doc->exportCaption($this->field7label);
					$doc->exportCaption($this->field7type);
					$doc->exportCaption($this->field7mandatory);
					$doc->exportCaption($this->field7display);
					$doc->exportCaption($this->field7displaysequence);
					$doc->exportCaption($this->field7domain);
					$doc->exportCaption($this->field8label);
					$doc->exportCaption($this->field8type);
					$doc->exportCaption($this->field8mandatory);
					$doc->exportCaption($this->field8display);
					$doc->exportCaption($this->field8displaysequence);
					$doc->exportCaption($this->field8domain);
					$doc->exportCaption($this->field9label);
					$doc->exportCaption($this->field9type);
					$doc->exportCaption($this->field9mandatory);
					$doc->exportCaption($this->field9display);
					$doc->exportCaption($this->field9displaysequence);
					$doc->exportCaption($this->field9domain);
					$doc->exportCaption($this->field10label);
					$doc->exportCaption($this->field10type);
					$doc->exportCaption($this->field10mandatory);
					$doc->exportCaption($this->field10display);
					$doc->exportCaption($this->field10displaysequence);
					$doc->exportCaption($this->field10domain);
					$doc->exportCaption($this->lastupdatedate);
				} else {
					$doc->exportCaption($this->extrafieldsid);
					$doc->exportCaption($this->merchantid);
					$doc->exportCaption($this->name);
					$doc->exportCaption($this->field1label);
					$doc->exportCaption($this->field1type);
					$doc->exportCaption($this->field1mandatory);
					$doc->exportCaption($this->field1display);
					$doc->exportCaption($this->field1displaysequence);
					$doc->exportCaption($this->field1domain);
					$doc->exportCaption($this->field2label);
					$doc->exportCaption($this->field2type);
					$doc->exportCaption($this->field2mandatory);
					$doc->exportCaption($this->field2display);
					$doc->exportCaption($this->field2displaysequence);
					$doc->exportCaption($this->field2domain);
					$doc->exportCaption($this->field3label);
					$doc->exportCaption($this->field3type);
					$doc->exportCaption($this->field3mandatory);
					$doc->exportCaption($this->field3display);
					$doc->exportCaption($this->field3displaysequence);
					$doc->exportCaption($this->field3domain);
					$doc->exportCaption($this->field4label);
					$doc->exportCaption($this->field4type);
					$doc->exportCaption($this->field4mandatory);
					$doc->exportCaption($this->field4display);
					$doc->exportCaption($this->field4displaysequence);
					$doc->exportCaption($this->field4domain);
					$doc->exportCaption($this->field5label);
					$doc->exportCaption($this->field5type);
					$doc->exportCaption($this->field5mandatory);
					$doc->exportCaption($this->field5display);
					$doc->exportCaption($this->field5displaysequence);
					$doc->exportCaption($this->field5domain);
					$doc->exportCaption($this->field6label);
					$doc->exportCaption($this->field6type);
					$doc->exportCaption($this->field6mandatory);
					$doc->exportCaption($this->field6display);
					$doc->exportCaption($this->field6displaysequence);
					$doc->exportCaption($this->field6domain);
					$doc->exportCaption($this->field7label);
					$doc->exportCaption($this->field7type);
					$doc->exportCaption($this->field7mandatory);
					$doc->exportCaption($this->field7display);
					$doc->exportCaption($this->field7displaysequence);
					$doc->exportCaption($this->field7domain);
					$doc->exportCaption($this->field8label);
					$doc->exportCaption($this->field8type);
					$doc->exportCaption($this->field8mandatory);
					$doc->exportCaption($this->field8display);
					$doc->exportCaption($this->field8displaysequence);
					$doc->exportCaption($this->field8domain);
					$doc->exportCaption($this->field9label);
					$doc->exportCaption($this->field9type);
					$doc->exportCaption($this->field9mandatory);
					$doc->exportCaption($this->field9display);
					$doc->exportCaption($this->field9displaysequence);
					$doc->exportCaption($this->field9domain);
					$doc->exportCaption($this->field10label);
					$doc->exportCaption($this->field10type);
					$doc->exportCaption($this->field10mandatory);
					$doc->exportCaption($this->field10display);
					$doc->exportCaption($this->field10displaysequence);
					$doc->exportCaption($this->field10domain);
					$doc->exportCaption($this->lastupdatedate);
				}
				$doc->endExportRow();
			}
		}

		// Move to first record
		$recCnt = $startRec - 1;
		if (!$recordset->EOF) {
			$recordset->moveFirst();
			if ($startRec > 1)
				$recordset->move($startRec - 1);
		}
		while (!$recordset->EOF && $recCnt < $stopRec) {
			$recCnt++;
			if ($recCnt >= $startRec) {
				$rowCnt = $recCnt - $startRec + 1;

				// Page break
				if ($this->ExportPageBreakCount > 0) {
					if ($rowCnt > 1 && ($rowCnt - 1) % $this->ExportPageBreakCount == 0)
						$doc->exportPageBreak();
				}
				$this->loadListRowValues($recordset);

				// Render row
				$this->RowType = ROWTYPE_VIEW; // Render view
				$this->resetAttributes();
				$this->renderListRow();
				if (!$doc->ExportCustom) {
					$doc->beginExportRow($rowCnt); // Allow CSS styles if enabled
					if ($exportPageType == "view") {
						$doc->exportField($this->extrafieldsid);
						$doc->exportField($this->merchantid);
						$doc->exportField($this->name);
						$doc->exportField($this->field1label);
						$doc->exportField($this->field1type);
						$doc->exportField($this->field1mandatory);
						$doc->exportField($this->field1display);
						$doc->exportField($this->field1displaysequence);
						$doc->exportField($this->field1domain);
						$doc->exportField($this->field2label);
						$doc->exportField($this->field2type);
						$doc->exportField($this->field2mandatory);
						$doc->exportField($this->field2display);
						$doc->exportField($this->field2displaysequence);
						$doc->exportField($this->field2domain);
						$doc->exportField($this->field3label);
						$doc->exportField($this->field3type);
						$doc->exportField($this->field3mandatory);
						$doc->exportField($this->field3display);
						$doc->exportField($this->field3displaysequence);
						$doc->exportField($this->field3domain);
						$doc->exportField($this->field4label);
						$doc->exportField($this->field4type);
						$doc->exportField($this->field4mandatory);
						$doc->exportField($this->field4display);
						$doc->exportField($this->field4displaysequence);
						$doc->exportField($this->field4domain);
						$doc->exportField($this->field5label);
						$doc->exportField($this->field5type);
						$doc->exportField($this->field5mandatory);
						$doc->exportField($this->field5display);
						$doc->exportField($this->field5displaysequence);
						$doc->exportField($this->field5domain);
						$doc->exportField($this->field6label);
						$doc->exportField($this->field6type);
						$doc->exportField($this->field6mandatory);
						$doc->exportField($this->field6display);
						$doc->exportField($this->field6displaysequence);
						$doc->exportField($this->field6domain);
						$doc->exportField($this->field7label);
						$doc->exportField($this->field7type);
						$doc->exportField($this->field7mandatory);
						$doc->exportField($this->field7display);
						$doc->exportField($this->field7displaysequence);
						$doc->exportField($this->field7domain);
						$doc->exportField($this->field8label);
						$doc->exportField($this->field8type);
						$doc->exportField($this->field8mandatory);
						$doc->exportField($this->field8display);
						$doc->exportField($this->field8displaysequence);
						$doc->exportField($this->field8domain);
						$doc->exportField($this->field9label);
						$doc->exportField($this->field9type);
						$doc->exportField($this->field9mandatory);
						$doc->exportField($this->field9display);
						$doc->exportField($this->field9displaysequence);
						$doc->exportField($this->field9domain);
						$doc->exportField($this->field10label);
						$doc->exportField($this->field10type);
						$doc->exportField($this->field10mandatory);
						$doc->exportField($this->field10display);
						$doc->exportField($this->field10displaysequence);
						$doc->exportField($this->field10domain);
						$doc->exportField($this->lastupdatedate);
					} else {
						$doc->exportField($this->extrafieldsid);
						$doc->exportField($this->merchantid);
						$doc->exportField($this->name);
						$doc->exportField($this->field1label);
						$doc->exportField($this->field1type);
						$doc->exportField($this->field1mandatory);
						$doc->exportField($this->field1display);
						$doc->exportField($this->field1displaysequence);
						$doc->exportField($this->field1domain);
						$doc->exportField($this->field2label);
						$doc->exportField($this->field2type);
						$doc->exportField($this->field2mandatory);
						$doc->exportField($this->field2display);
						$doc->exportField($this->field2displaysequence);
						$doc->exportField($this->field2domain);
						$doc->exportField($this->field3label);
						$doc->exportField($this->field3type);
						$doc->exportField($this->field3mandatory);
						$doc->exportField($this->field3display);
						$doc->exportField($this->field3displaysequence);
						$doc->exportField($this->field3domain);
						$doc->exportField($this->field4label);
						$doc->exportField($this->field4type);
						$doc->exportField($this->field4mandatory);
						$doc->exportField($this->field4display);
						$doc->exportField($this->field4displaysequence);
						$doc->exportField($this->field4domain);
						$doc->exportField($this->field5label);
						$doc->exportField($this->field5type);
						$doc->exportField($this->field5mandatory);
						$doc->exportField($this->field5display);
						$doc->exportField($this->field5displaysequence);
						$doc->exportField($this->field5domain);
						$doc->exportField($this->field6label);
						$doc->exportField($this->field6type);
						$doc->exportField($this->field6mandatory);
						$doc->exportField($this->field6display);
						$doc->exportField($this->field6displaysequence);
						$doc->exportField($this->field6domain);
						$doc->exportField($this->field7label);
						$doc->exportField($this->field7type);
						$doc->exportField($this->field7mandatory);
						$doc->exportField($this->field7display);
						$doc->exportField($this->field7displaysequence);
						$doc->exportField($this->field7domain);
						$doc->exportField($this->field8label);
						$doc->exportField($this->field8type);
						$doc->exportField($this->field8mandatory);
						$doc->exportField($this->field8display);
						$doc->exportField($this->field8displaysequence);
						$doc->exportField($this->field8domain);
						$doc->exportField($this->field9label);
						$doc->exportField($this->field9type);
						$doc->exportField($this->field9mandatory);
						$doc->exportField($this->field9display);
						$doc->exportField($this->field9displaysequence);
						$doc->exportField($this->field9domain);
						$doc->exportField($this->field10label);
						$doc->exportField($this->field10type);
						$doc->exportField($this->field10mandatory);
						$doc->exportField($this->field10display);
						$doc->exportField($this->field10displaysequence);
						$doc->exportField($this->field10domain);
						$doc->exportField($this->lastupdatedate);
					}
					$doc->endExportRow($rowCnt);
				}
			}

			// Call Row Export server event
			if ($doc->ExportCustom)
				$this->Row_Export($recordset->fields);
			$recordset->moveNext();
		}
		if (!$doc->ExportCustom) {
			$doc->exportTableFooter();
		}
	}

	// Get file data
	public function getFileData($fldparm, $key, $resize, $width = 0, $height = 0)
	{

		// No binary fields
		return FALSE;
	}

	// Write Audit Trail start/end for grid update
	public function writeAuditTrailDummy($typ)
	{
		$table = 'extrafieldstemplate';
		$usr = CurrentUserName();
		WriteAuditTrail("log", DbCurrentDateTime(), ScriptName(), $usr, $typ, $table, "", "", "", "");
	}

	// Write Audit Trail (add page)
	public function writeAuditTrailOnAdd(&$rs)
	{
		global $Language;
		if (!$this->AuditTrailOnAdd)
			return;
		$table = 'extrafieldstemplate';

		// Get key value
		$key = "";
		if ($key != "")
			$key .= Config("COMPOSITE_KEY_SEPARATOR");
		$key .= $rs['extrafieldsid'];

		// Write Audit Trail
		$dt = DbCurrentDateTime();
		$id = ScriptName();
		$usr = CurrentUserName();
		foreach (array_keys($rs) as $fldname) {
			if (array_key_exists($fldname, $this->fields) && $this->fields[$fldname]->DataType != DATATYPE_BLOB) { // Ignore BLOB fields
				if ($this->fields[$fldname]->HtmlTag == "PASSWORD") {
					$newvalue = $Language->phrase("PasswordMask"); // Password Field
				} elseif ($this->fields[$fldname]->DataType == DATATYPE_MEMO) {
					if (Config("AUDIT_TRAIL_TO_DATABASE"))
						$newvalue = $rs[$fldname];
					else
						$newvalue = "[MEMO]"; // Memo Field
				} elseif ($this->fields[$fldname]->DataType == DATATYPE_XML) {
					$newvalue = "[XML]"; // XML Field
				} else {
					$newvalue = $rs[$fldname];
				}
				WriteAuditTrail("log", $dt, $id, $usr, "A", $table, $fldname, $key, "", $newvalue);
			}
		}
	}

	// Write Audit Trail (edit page)
	public function writeAuditTrailOnEdit(&$rsold, &$rsnew)
	{
		global $Language;
		if (!$this->AuditTrailOnEdit)
			return;
		$table = 'extrafieldstemplate';

		// Get key value
		$key = "";
		if ($key != "")
			$key .= Config("COMPOSITE_KEY_SEPARATOR");
		$key .= $rsold['extrafieldsid'];

		// Write Audit Trail
		$dt = DbCurrentDateTime();
		$id = ScriptName();
		$usr = CurrentUserName();
		foreach (array_keys($rsnew) as $fldname) {
			if (array_key_exists($fldname, $this->fields) && array_key_exists($fldname, $rsold) && $this->fields[$fldname]->DataType != DATATYPE_BLOB) { // Ignore BLOB fields
				if ($this->fields[$fldname]->DataType == DATATYPE_DATE) { // DateTime field
					$modified = (FormatDateTime($rsold[$fldname], 0) != FormatDateTime($rsnew[$fldname], 0));
				} else {
					$modified = !CompareValue($rsold[$fldname], $rsnew[$fldname]);
				}
				if ($modified) {
					if ($this->fields[$fldname]->HtmlTag == "PASSWORD") { // Password Field
						$oldvalue = $Language->phrase("PasswordMask");
						$newvalue = $Language->phrase("PasswordMask");
					} elseif ($this->fields[$fldname]->DataType == DATATYPE_MEMO) { // Memo field
						if (Config("AUDIT_TRAIL_TO_DATABASE")) {
							$oldvalue = $rsold[$fldname];
							$newvalue = $rsnew[$fldname];
						} else {
							$oldvalue = "[MEMO]";
							$newvalue = "[MEMO]";
						}
					} elseif ($this->fields[$fldname]->DataType == DATATYPE_XML) { // XML field
						$oldvalue = "[XML]";
						$newvalue = "[XML]";
					} else {
						$oldvalue = $rsold[$fldname];
						$newvalue = $rsnew[$fldname];
					}
					WriteAuditTrail("log", $dt, $id, $usr, "U", $table, $fldname, $key, $oldvalue, $newvalue);
				}
			}
		}
	}

	// Write Audit Trail (delete page)
	public function writeAuditTrailOnDelete(&$rs)
	{
		global $Language;
		if (!$this->AuditTrailOnDelete)
			return;
		$table = 'extrafieldstemplate';

		// Get key value
		$key = "";
		if ($key != "")
			$key .= Config("COMPOSITE_KEY_SEPARATOR");
		$key .= $rs['extrafieldsid'];

		// Write Audit Trail
		$dt = DbCurrentDateTime();
		$id = ScriptName();
		$curUser = CurrentUserName();
		foreach (array_keys($rs) as $fldname) {
			if (array_key_exists($fldname, $this->fields) && $this->fields[$fldname]->DataType != DATATYPE_BLOB) { // Ignore BLOB fields
				if ($this->fields[$fldname]->HtmlTag == "PASSWORD") {
					$oldvalue = $Language->phrase("PasswordMask"); // Password Field
				} elseif ($this->fields[$fldname]->DataType == DATATYPE_MEMO) {
					if (Config("AUDIT_TRAIL_TO_DATABASE"))
						$oldvalue = $rs[$fldname];
					else
						$oldvalue = "[MEMO]"; // Memo field
				} elseif ($this->fields[$fldname]->DataType == DATATYPE_XML) {
					$oldvalue = "[XML]"; // XML field
				} else {
					$oldvalue = $rs[$fldname];
				}
				WriteAuditTrail("log", $dt, $id, $curUser, "D", $table, $fldname, $key, $oldvalue, "");
			}
		}
	}

	// Table level events
	// Recordset Selecting event
	function Recordset_Selecting(&$filter) {

		// Enter your code here
	}

	// Recordset Selected event
	function Recordset_Selected(&$rs) {

		//echo "Recordset Selected";
	}

	// Recordset Search Validated event
	function Recordset_SearchValidated() {

		// Example:
		//$this->MyField1->AdvancedSearch->SearchValue = "your search criteria"; // Search value

	}

	// Recordset Searching event
	function Recordset_Searching(&$filter) {

		// Enter your code here
	}

	// Row_Selecting event
	function Row_Selecting(&$filter) {

		// Enter your code here
	}

	// Row Selected event
	function Row_Selected(&$rs) {

		//echo "Row Selected";
	}

	// Row Inserting event
	function Row_Inserting($rsold, &$rsnew) {

		// Enter your code here
		// To cancel, set return value to FALSE

		return TRUE;
	}

	// Row Inserted event
	function Row_Inserted($rsold, &$rsnew) {

		//echo "Row Inserted"
	}

	// Row Updating event
	function Row_Updating($rsold, &$rsnew) {

		// Enter your code here
		// To cancel, set return value to FALSE

		return TRUE;
	}

	// Row Updated event
	function Row_Updated($rsold, &$rsnew) {

		//echo "Row Updated";
	}

	// Row Update Conflict event
	function Row_UpdateConflict($rsold, &$rsnew) {

		// Enter your code here
		// To ignore conflict, set return value to FALSE

		return TRUE;
	}

	// Grid Inserting event
	function Grid_Inserting() {

		// Enter your code here
		// To reject grid insert, set return value to FALSE

		return TRUE;
	}

	// Grid Inserted event
	function Grid_Inserted($rsnew) {

		//echo "Grid Inserted";
	}

	// Grid Updating event
	function Grid_Updating($rsold) {

		// Enter your code here
		// To reject grid update, set return value to FALSE

		return TRUE;
	}

	// Grid Updated event
	function Grid_Updated($rsold, $rsnew) {

		//echo "Grid Updated";
	}

	// Row Deleting event
	function Row_Deleting(&$rs) {

		// Enter your code here
		// To cancel, set return value to False

		return TRUE;
	}

	// Row Deleted event
	function Row_Deleted(&$rs) {

		//echo "Row Deleted";
	}

	// Email Sending event
	function Email_Sending($email, &$args) {

		//var_dump($email); var_dump($args); exit();
		return TRUE;
	}

	// Lookup Selecting event
	function Lookup_Selecting($fld, &$filter) {

		//var_dump($fld->Name, $fld->Lookup, $filter); // Uncomment to view the filter
		// Enter your code here

	}

	// Row Rendering event
	function Row_Rendering() {

		// Enter your code here
	}

	// Row Rendered event
	function Row_Rendered() {

		// To view properties of field class, use:
		//var_dump($this-><FieldName>);

	}

	// User ID Filtering event
	function UserID_Filtering(&$filter) {

		// Enter your code here
	}
}
?>