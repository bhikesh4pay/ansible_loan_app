<?php
namespace PHPMaker2020\_4payadmin;

/**
 * Page class
 */
class loanissued_list extends loanissued
{

	// Page ID
	public $PageID = "list";

	// Project ID
	public $ProjectID = "{153C2D2E-60EE-4944-8753-3935EB38E8D6}";

	// Table name
	public $TableName = 'loanissued';

	// Page object name
	public $PageObjName = "loanissued_list";

	// Grid form hidden field names
	public $FormName = "floanissuedlist";
	public $FormActionName = "k_action";
	public $FormKeyName = "k_key";
	public $FormOldKeyName = "k_oldkey";
	public $FormBlankRowName = "k_blankrow";
	public $FormKeyCountName = "key_count";

	// Page URLs
	public $AddUrl;
	public $EditUrl;
	public $CopyUrl;
	public $DeleteUrl;
	public $ViewUrl;
	public $ListUrl;

	// Export URLs
	public $ExportPrintUrl;
	public $ExportHtmlUrl;
	public $ExportExcelUrl;
	public $ExportWordUrl;
	public $ExportXmlUrl;
	public $ExportCsvUrl;
	public $ExportPdfUrl;

	// Custom export
	public $ExportExcelCustom = FALSE;
	public $ExportWordCustom = FALSE;
	public $ExportPdfCustom = FALSE;
	public $ExportEmailCustom = FALSE;

	// Update URLs
	public $InlineAddUrl;
	public $InlineCopyUrl;
	public $InlineEditUrl;
	public $GridAddUrl;
	public $GridEditUrl;
	public $MultiDeleteUrl;
	public $MultiUpdateUrl;

	// Audit Trail
	public $AuditTrailOnAdd = TRUE;
	public $AuditTrailOnEdit = TRUE;
	public $AuditTrailOnDelete = TRUE;
	public $AuditTrailOnView = FALSE;
	public $AuditTrailOnViewData = FALSE;
	public $AuditTrailOnSearch = FALSE;

	// Page headings
	public $Heading = "";
	public $Subheading = "";
	public $PageHeader;
	public $PageFooter;

	// Token
	public $Token = "";
	public $TokenTimeout = 0;
	public $CheckToken;

	// Page heading
	public function pageHeading()
	{
		global $Language;
		if ($this->Heading != "")
			return $this->Heading;
		if (method_exists($this, "tableCaption"))
			return $this->tableCaption();
		return "";
	}

	// Page subheading
	public function pageSubheading()
	{
		global $Language;
		if ($this->Subheading != "")
			return $this->Subheading;
		if ($this->TableName)
			return $Language->phrase($this->PageID);
		return "";
	}

	// Page name
	public function pageName()
	{
		return CurrentPageName();
	}

	// Page URL
	public function pageUrl()
	{
		$url = CurrentPageName() . "?";
		if ($this->UseTokenInUrl)
			$url .= "t=" . $this->TableVar . "&"; // Add page token
		return $url;
	}

	// Messages
	private $_message = "";
	private $_failureMessage = "";
	private $_successMessage = "";
	private $_warningMessage = "";

	// Get message
	public function getMessage()
	{
		return isset($_SESSION[SESSION_MESSAGE]) ? $_SESSION[SESSION_MESSAGE] : $this->_message;
	}

	// Set message
	public function setMessage($v)
	{
		AddMessage($this->_message, $v);
		$_SESSION[SESSION_MESSAGE] = $this->_message;
	}

	// Get failure message
	public function getFailureMessage()
	{
		return isset($_SESSION[SESSION_FAILURE_MESSAGE]) ? $_SESSION[SESSION_FAILURE_MESSAGE] : $this->_failureMessage;
	}

	// Set failure message
	public function setFailureMessage($v)
	{
		AddMessage($this->_failureMessage, $v);
		$_SESSION[SESSION_FAILURE_MESSAGE] = $this->_failureMessage;
	}

	// Get success message
	public function getSuccessMessage()
	{
		return isset($_SESSION[SESSION_SUCCESS_MESSAGE]) ? $_SESSION[SESSION_SUCCESS_MESSAGE] : $this->_successMessage;
	}

	// Set success message
	public function setSuccessMessage($v)
	{
		AddMessage($this->_successMessage, $v);
		$_SESSION[SESSION_SUCCESS_MESSAGE] = $this->_successMessage;
	}

	// Get warning message
	public function getWarningMessage()
	{
		return isset($_SESSION[SESSION_WARNING_MESSAGE]) ? $_SESSION[SESSION_WARNING_MESSAGE] : $this->_warningMessage;
	}

	// Set warning message
	public function setWarningMessage($v)
	{
		AddMessage($this->_warningMessage, $v);
		$_SESSION[SESSION_WARNING_MESSAGE] = $this->_warningMessage;
	}

	// Clear message
	public function clearMessage()
	{
		$this->_message = "";
		$_SESSION[SESSION_MESSAGE] = "";
	}

	// Clear failure message
	public function clearFailureMessage()
	{
		$this->_failureMessage = "";
		$_SESSION[SESSION_FAILURE_MESSAGE] = "";
	}

	// Clear success message
	public function clearSuccessMessage()
	{
		$this->_successMessage = "";
		$_SESSION[SESSION_SUCCESS_MESSAGE] = "";
	}

	// Clear warning message
	public function clearWarningMessage()
	{
		$this->_warningMessage = "";
		$_SESSION[SESSION_WARNING_MESSAGE] = "";
	}

	// Clear messages
	public function clearMessages()
	{
		$this->clearMessage();
		$this->clearFailureMessage();
		$this->clearSuccessMessage();
		$this->clearWarningMessage();
	}

	// Show message
	public function showMessage()
	{
		$hidden = FALSE;
		$html = "";

		// Message
		$message = $this->getMessage();
		if (method_exists($this, "Message_Showing"))
			$this->Message_Showing($message, "");
		if ($message != "") { // Message in Session, display
			if (!$hidden)
				$message = '<button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button>' . $message;
			$html .= '<div class="alert alert-info alert-dismissible ew-info"><i class="icon fas fa-info"></i>' . $message . '</div>';
			$_SESSION[SESSION_MESSAGE] = ""; // Clear message in Session
		}

		// Warning message
		$warningMessage = $this->getWarningMessage();
		if (method_exists($this, "Message_Showing"))
			$this->Message_Showing($warningMessage, "warning");
		if ($warningMessage != "") { // Message in Session, display
			if (!$hidden)
				$warningMessage = '<button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button>' . $warningMessage;
			$html .= '<div class="alert alert-warning alert-dismissible ew-warning"><i class="icon fas fa-exclamation"></i>' . $warningMessage . '</div>';
			$_SESSION[SESSION_WARNING_MESSAGE] = ""; // Clear message in Session
		}

		// Success message
		$successMessage = $this->getSuccessMessage();
		if (method_exists($this, "Message_Showing"))
			$this->Message_Showing($successMessage, "success");
		if ($successMessage != "") { // Message in Session, display
			if (!$hidden)
				$successMessage = '<button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button>' . $successMessage;
			$html .= '<div class="alert alert-success alert-dismissible ew-success"><i class="icon fas fa-check"></i>' . $successMessage . '</div>';
			$_SESSION[SESSION_SUCCESS_MESSAGE] = ""; // Clear message in Session
		}

		// Failure message
		$errorMessage = $this->getFailureMessage();
		if (method_exists($this, "Message_Showing"))
			$this->Message_Showing($errorMessage, "failure");
		if ($errorMessage != "") { // Message in Session, display
			if (!$hidden)
				$errorMessage = '<button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button>' . $errorMessage;
			$html .= '<div class="alert alert-danger alert-dismissible ew-error"><i class="icon fas fa-ban"></i>' . $errorMessage . '</div>';
			$_SESSION[SESSION_FAILURE_MESSAGE] = ""; // Clear message in Session
		}
		echo '<div class="ew-message-dialog' . (($hidden) ? ' d-none' : "") . '">' . $html . '</div>';
	}

	// Get message as array
	public function getMessages()
	{
		$ar = [];

		// Message
		$message = $this->getMessage();

		//if (method_exists($this, "Message_Showing"))
		//	$this->Message_Showing($message, "");

		if ($message != "") { // Message in Session, display
			$ar["message"] = $message;
			$_SESSION[SESSION_MESSAGE] = ""; // Clear message in Session
		}

		// Warning message
		$warningMessage = $this->getWarningMessage();

		//if (method_exists($this, "Message_Showing"))
		//	$this->Message_Showing($warningMessage, "warning");

		if ($warningMessage != "") { // Message in Session, display
			$ar["warningMessage"] = $warningMessage;
			$_SESSION[SESSION_WARNING_MESSAGE] = ""; // Clear message in Session
		}

		// Success message
		$successMessage = $this->getSuccessMessage();

		//if (method_exists($this, "Message_Showing"))
		//	$this->Message_Showing($successMessage, "success");

		if ($successMessage != "") { // Message in Session, display
			$ar["successMessage"] = $successMessage;
			$_SESSION[SESSION_SUCCESS_MESSAGE] = ""; // Clear message in Session
		}

		// Failure message
		$failureMessage = $this->getFailureMessage();

		//if (method_exists($this, "Message_Showing"))
		//	$this->Message_Showing($failureMessage, "failure");

		if ($failureMessage != "") { // Message in Session, display
			$ar["failureMessage"] = $failureMessage;
			$_SESSION[SESSION_FAILURE_MESSAGE] = ""; // Clear message in Session
		}
		return $ar;
	}

	// Show Page Header
	public function showPageHeader()
	{
		$header = $this->PageHeader;
		$this->Page_DataRendering($header);
		if ($header != "") { // Header exists, display
			echo '<p id="ew-page-header">' . $header . '</p>';
		}
	}

	// Show Page Footer
	public function showPageFooter()
	{
		$footer = $this->PageFooter;
		$this->Page_DataRendered($footer);
		if ($footer != "") { // Footer exists, display
			echo '<p id="ew-page-footer">' . $footer . '</p>';
		}
	}

	// Validate page request
	protected function isPageRequest()
	{
		global $CurrentForm;
		if ($this->UseTokenInUrl) {
			if ($CurrentForm)
				return ($this->TableVar == $CurrentForm->getValue("t"));
			if (Get("t") !== NULL)
				return ($this->TableVar == Get("t"));
		}
		return TRUE;
	}

	// Valid Post
	protected function validPost()
	{
		if (!$this->CheckToken || !IsPost() || IsApi())
			return TRUE;
		if (Post(Config("TOKEN_NAME")) === NULL)
			return FALSE;
		$fn = Config("CHECK_TOKEN_FUNC");
		if (is_callable($fn))
			return $fn(Post(Config("TOKEN_NAME")), $this->TokenTimeout);
		return FALSE;
	}

	// Create Token
	public function createToken()
	{
		global $CurrentToken;
		$fn = Config("CREATE_TOKEN_FUNC"); // Always create token, required by API file/lookup request
		if ($this->Token == "" && is_callable($fn)) // Create token
			$this->Token = $fn();
		$CurrentToken = $this->Token; // Save to global variable
	}

	// Constructor
	public function __construct()
	{
		global $Language, $DashboardReport;
		global $UserTable;

		// Check token
		$this->CheckToken = Config("CHECK_TOKEN");

		// Initialize
		$GLOBALS["Page"] = &$this;
		$this->TokenTimeout = SessionTimeoutTime();

		// Language object
		if (!isset($Language))
			$Language = new Language();

		// Parent constuctor
		parent::__construct();

		// Table object (loanissued)
		if (!isset($GLOBALS["loanissued"]) || get_class($GLOBALS["loanissued"]) == PROJECT_NAMESPACE . "loanissued") {
			$GLOBALS["loanissued"] = &$this;
			$GLOBALS["Table"] = &$GLOBALS["loanissued"];
		}

		// Initialize URLs
		$this->ExportPrintUrl = $this->pageUrl() . "export=print";
		$this->ExportExcelUrl = $this->pageUrl() . "export=excel";
		$this->ExportWordUrl = $this->pageUrl() . "export=word";
		$this->ExportPdfUrl = $this->pageUrl() . "export=pdf";
		$this->ExportHtmlUrl = $this->pageUrl() . "export=html";
		$this->ExportXmlUrl = $this->pageUrl() . "export=xml";
		$this->ExportCsvUrl = $this->pageUrl() . "export=csv";
		$this->AddUrl = "loanissuedadd.php?" . Config("TABLE_SHOW_DETAIL") . "=";
		$this->InlineAddUrl = $this->pageUrl() . "action=add";
		$this->GridAddUrl = $this->pageUrl() . "action=gridadd";
		$this->GridEditUrl = $this->pageUrl() . "action=gridedit";
		$this->MultiDeleteUrl = "loanissueddelete.php";
		$this->MultiUpdateUrl = "loanissuedupdate.php";

		// Table object (admin)
		if (!isset($GLOBALS['admin']))
			$GLOBALS['admin'] = new admin();

		// Table object (loancancelrequests)
		if (!isset($GLOBALS['loancancelrequests']))
			$GLOBALS['loancancelrequests'] = new loancancelrequests();

		// Table object (loanlimits)
		if (!isset($GLOBALS['loanlimits']))
			$GLOBALS['loanlimits'] = new loanlimits();

		// Table object (loanrequests)
		if (!isset($GLOBALS['loanrequests']))
			$GLOBALS['loanrequests'] = new loanrequests();

		// Page ID (for backward compatibility only)
		if (!defined(PROJECT_NAMESPACE . "PAGE_ID"))
			define(PROJECT_NAMESPACE . "PAGE_ID", 'list');

		// Table name (for backward compatibility only)
		if (!defined(PROJECT_NAMESPACE . "TABLE_NAME"))
			define(PROJECT_NAMESPACE . "TABLE_NAME", 'loanissued');

		// Start timer
		if (!isset($GLOBALS["DebugTimer"]))
			$GLOBALS["DebugTimer"] = new Timer();

		// Debug message
		LoadDebugMessage();

		// Open connection
		if (!isset($GLOBALS["Conn"]))
			$GLOBALS["Conn"] = $this->getConnection();

		// User table object (admin)
		$UserTable = $UserTable ?: new admin();

		// List options
		$this->ListOptions = new ListOptions();
		$this->ListOptions->TableVar = $this->TableVar;

		// Export options
		$this->ExportOptions = new ListOptions("div");
		$this->ExportOptions->TagClassName = "ew-export-option";

		// Import options
		$this->ImportOptions = new ListOptions("div");
		$this->ImportOptions->TagClassName = "ew-import-option";

		// Other options
		if (!$this->OtherOptions)
			$this->OtherOptions = new ListOptionsArray();
		$this->OtherOptions["addedit"] = new ListOptions("div");
		$this->OtherOptions["addedit"]->TagClassName = "ew-add-edit-option";
		$this->OtherOptions["detail"] = new ListOptions("div");
		$this->OtherOptions["detail"]->TagClassName = "ew-detail-option";
		$this->OtherOptions["action"] = new ListOptions("div");
		$this->OtherOptions["action"]->TagClassName = "ew-action-option";

		// Filter options
		$this->FilterOptions = new ListOptions("div");
		$this->FilterOptions->TagClassName = "ew-filter-option floanissuedlistsrch";

		// List actions
		$this->ListActions = new ListActions();
	}

	// Terminate page
	public function terminate($url = "")
	{
		global $ExportFileName, $TempImages, $DashboardReport;

		// Page Unload event
		$this->Page_Unload();

		// Global Page Unloaded event (in userfn*.php)
		Page_Unloaded();

		// Export
		global $loanissued;
		if ($this->CustomExport && $this->CustomExport == $this->Export && array_key_exists($this->CustomExport, Config("EXPORT_CLASSES"))) {
				$content = ob_get_contents();
			if ($ExportFileName == "")
				$ExportFileName = $this->TableVar;
			$class = PROJECT_NAMESPACE . Config("EXPORT_CLASSES." . $this->CustomExport);
			if (class_exists($class)) {
				$doc = new $class($loanissued);
				$doc->Text = @$content;
				if ($this->isExport("email"))
					echo $this->exportEmail($doc->Text);
				else
					$doc->export();
				DeleteTempImages(); // Delete temp images
				exit();
			}
		}
		if (!IsApi())
			$this->Page_Redirecting($url);

		// Close connection
		CloseConnections();

		// Return for API
		if (IsApi()) {
			$res = $url === TRUE;
			if (!$res) // Show error
				WriteJson(array_merge(["success" => FALSE], $this->getMessages()));
			return;
		}

		// Go to URL if specified
		if ($url != "") {
			if (!Config("DEBUG") && ob_get_length())
				ob_end_clean();
			SaveDebugMessage();
			AddHeader("Location", $url);
		}
		exit();
	}

	// Get records from recordset
	protected function getRecordsFromRecordset($rs, $current = FALSE)
	{
		$rows = [];
		if (is_object($rs)) { // Recordset
			while ($rs && !$rs->EOF) {
				$this->loadRowValues($rs); // Set up DbValue/CurrentValue
				$row = $this->getRecordFromArray($rs->fields);
				if ($current)
					return $row;
				else
					$rows[] = $row;
				$rs->moveNext();
			}
		} elseif (is_array($rs)) {
			foreach ($rs as $ar) {
				$row = $this->getRecordFromArray($ar);
				if ($current)
					return $row;
				else
					$rows[] = $row;
			}
		}
		return $rows;
	}

	// Get record from array
	protected function getRecordFromArray($ar)
	{
		$row = [];
		if (is_array($ar)) {
			foreach ($ar as $fldname => $val) {
				if (array_key_exists($fldname, $this->fields) && ($this->fields[$fldname]->Visible || $this->fields[$fldname]->IsPrimaryKey)) { // Primary key or Visible
					$fld = &$this->fields[$fldname];
					if ($fld->HtmlTag == "FILE") { // Upload field
						if (EmptyValue($val)) {
							$row[$fldname] = NULL;
						} else {
							if ($fld->DataType == DATATYPE_BLOB) {
								$url = FullUrl(GetApiUrl(Config("API_FILE_ACTION"),
									Config("API_OBJECT_NAME") . "=" . $fld->TableVar . "&" .
									Config("API_FIELD_NAME") . "=" . $fld->Param . "&" .
									Config("API_KEY_NAME") . "=" . rawurlencode($this->getRecordKeyValue($ar)))); //*** need to add this? API may not be in the same folder
								$row[$fldname] = ["type" => ContentType($val), "url" => $url, "name" => $fld->Param . ContentExtension($val)];
							} elseif (!$fld->UploadMultiple || !ContainsString($val, Config("MULTIPLE_UPLOAD_SEPARATOR"))) { // Single file
								$url = FullUrl(GetApiUrl(Config("API_FILE_ACTION"),
									Config("API_OBJECT_NAME") . "=" . $fld->TableVar . "&" .
									"fn=" . Encrypt($fld->physicalUploadPath() . $val)));
								$row[$fldname] = ["type" => MimeContentType($val), "url" => $url, "name" => $val];
							} else { // Multiple files
								$files = explode(Config("MULTIPLE_UPLOAD_SEPARATOR"), $val);
								$ar = [];
								foreach ($files as $file) {
									$url = FullUrl(GetApiUrl(Config("API_FILE_ACTION"),
										Config("API_OBJECT_NAME") . "=" . $fld->TableVar . "&" .
										"fn=" . Encrypt($fld->physicalUploadPath() . $file)));
									if (!EmptyValue($file))
										$ar[] = ["type" => MimeContentType($file), "url" => $url, "name" => $file];
								}
								$row[$fldname] = $ar;
							}
						}
					} else {
						if ($fld->DataType == DATATYPE_MEMO && $fld->MemoMaxLength > 0)
							$val = TruncateMemo($val, $fld->MemoMaxLength, $fld->TruncateMemoRemoveHtml);
						$row[$fldname] = $val;
					}
				}
			}
		}
		return $row;
	}

	// Get record key value from array
	protected function getRecordKeyValue($ar)
	{
		$key = "";
		if (is_array($ar)) {
			$key .= @$ar['loanid'];
		}
		return $key;
	}

	/**
	 * Hide fields for add/edit
	 *
	 * @return void
	 */
	protected function hideFieldsForAddEdit()
	{
		if ($this->isAdd() || $this->isCopy() || $this->isGridAdd())
			$this->loanid->Visible = FALSE;
	}

	// Lookup data
	public function lookup()
	{
		global $Language, $Security;
		if (!isset($Language))
			$Language = new Language(Config("LANGUAGE_FOLDER"), Post("language", ""));

		// Set up API request
		if (!ValidApiRequest())
			return FALSE;
		$this->setupApiSecurity();

		// Get lookup object
		$fieldName = Post("field");
		if (!array_key_exists($fieldName, $this->fields))
			return FALSE;
		$lookupField = $this->fields[$fieldName];
		$lookup = $lookupField->Lookup;
		if ($lookup === NULL)
			return FALSE;
		$tbl = $lookup->getTable();
		if (!$Security->allowLookup(Config("PROJECT_ID") . $tbl->TableName)) // Lookup permission
			return FALSE;

		// Get lookup parameters
		$lookupType = Post("ajax", "unknown");
		$pageSize = -1;
		$offset = -1;
		$searchValue = "";
		if (SameText($lookupType, "modal")) {
			$searchValue = Post("sv", "");
			$pageSize = Post("recperpage", 10);
			$offset = Post("start", 0);
		} elseif (SameText($lookupType, "autosuggest")) {
			$searchValue = Param("q", "");
			$pageSize = Param("n", -1);
			$pageSize = is_numeric($pageSize) ? (int)$pageSize : -1;
			if ($pageSize <= 0)
				$pageSize = Config("AUTO_SUGGEST_MAX_ENTRIES");
			$start = Param("start", -1);
			$start = is_numeric($start) ? (int)$start : -1;
			$page = Param("page", -1);
			$page = is_numeric($page) ? (int)$page : -1;
			$offset = $start >= 0 ? $start : ($page > 0 && $pageSize > 0 ? ($page - 1) * $pageSize : 0);
		}
		$userSelect = Decrypt(Post("s", ""));
		$userFilter = Decrypt(Post("f", ""));
		$userOrderBy = Decrypt(Post("o", ""));
		$keys = Post("keys");
		$lookup->LookupType = $lookupType; // Lookup type
		if ($keys !== NULL) { // Selected records from modal
			if (is_array($keys))
				$keys = implode(Config("MULTIPLE_OPTION_SEPARATOR"), $keys);
			$lookup->FilterFields = []; // Skip parent fields if any
			$lookup->FilterValues[] = $keys; // Lookup values
			$pageSize = -1; // Show all records
		} else { // Lookup values
			$lookup->FilterValues[] = Post("v0", Post("lookupValue", ""));
		}
		$cnt = is_array($lookup->FilterFields) ? count($lookup->FilterFields) : 0;
		for ($i = 1; $i <= $cnt; $i++)
			$lookup->FilterValues[] = Post("v" . $i, "");
		$lookup->SearchValue = $searchValue;
		$lookup->PageSize = $pageSize;
		$lookup->Offset = $offset;
		if ($userSelect != "")
			$lookup->UserSelect = $userSelect;
		if ($userFilter != "")
			$lookup->UserFilter = $userFilter;
		if ($userOrderBy != "")
			$lookup->UserOrderBy = $userOrderBy;
		$lookup->toJson($this); // Use settings from current page
	}

	// Set up API security
	public function setupApiSecurity()
	{
		global $Security;

		// Setup security for API request
		if ($Security->isLoggedIn()) $Security->TablePermission_Loading();
		$Security->loadCurrentUserLevel(Config("PROJECT_ID") . $this->TableName);
		if ($Security->isLoggedIn()) $Security->TablePermission_Loaded();
	}

	// Class variables
	public $ListOptions; // List options
	public $ExportOptions; // Export options
	public $SearchOptions; // Search options
	public $OtherOptions; // Other options
	public $FilterOptions; // Filter options
	public $ImportOptions; // Import options
	public $ListActions; // List actions
	public $SelectedCount = 0;
	public $SelectedIndex = 0;
	public $DisplayRecords = 10;
	public $StartRecord;
	public $StopRecord;
	public $TotalRecords = 0;
	public $RecordRange = 10;
	public $PageSizes = ""; // Page sizes (comma separated)
	public $DefaultSearchWhere = ""; // Default search WHERE clause
	public $SearchWhere = ""; // Search WHERE clause
	public $SearchPanelClass = "ew-search-panel collapse"; // Search Panel class
	public $SearchRowCount = 0; // For extended search
	public $SearchColumnCount = 0; // For extended search
	public $SearchFieldsPerRow = 1; // For extended search
	public $RecordCount = 0; // Record count
	public $EditRowCount;
	public $StartRowCount = 1;
	public $RowCount = 0;
	public $Attrs = []; // Row attributes and cell attributes
	public $RowIndex = 0; // Row index
	public $KeyCount = 0; // Key count
	public $RowAction = ""; // Row action
	public $RowOldKey = ""; // Row old key (for copy)
	public $MultiColumnClass = "col-sm";
	public $MultiColumnEditClass = "w-100";
	public $DbMasterFilter = ""; // Master filter
	public $DbDetailFilter = ""; // Detail filter
	public $MasterRecordExists;
	public $MultiSelectKey;
	public $Command;
	public $RestoreSearch = FALSE;
	public $loanissuedupgrades_Count;
	public $loaneventhistory_Count;
	public $loanlatefees_Count;
	public $loanapplied_Count;
	public $loanpayments_Count;
	public $loanpaymentplan_Count;
	public $DetailPages;
	public $OldRecordset;

	//
	// Page run
	//

	public function run()
	{
		global $ExportType, $CustomExportType, $ExportFileName, $UserProfile, $Language, $Security, $CurrentForm,
			$FormError, $SearchError;

		// User profile
		$UserProfile = new UserProfile();

		// Security
		if (ValidApiRequest()) { // API request
			$this->setupApiSecurity(); // Set up API Security
			if (!$Security->canList()) {
				SetStatus(401); // Unauthorized
				return;
			}
		} else {
			$Security = new AdvancedSecurity();
			if (IsPasswordExpired())
				$this->terminate(GetUrl("changepwd.php"));
			if (!$Security->isLoggedIn())
				$Security->autoLogin();
			if ($Security->isLoggedIn())
				$Security->TablePermission_Loading();
			$Security->loadCurrentUserLevel($this->ProjectID . $this->TableName);
			if ($Security->isLoggedIn())
				$Security->TablePermission_Loaded();
			if (!$Security->canList()) {
				$Security->saveLastUrl();
				$this->setFailureMessage(DeniedMessage()); // Set no permission
				$this->terminate(GetUrl("index.php"));
				return;
			}
		}

		// Get export parameters
		$custom = "";
		if (Param("export") !== NULL) {
			$this->Export = Param("export");
			$custom = Param("custom", "");
		} elseif (IsPost()) {
			if (Post("exporttype") !== NULL)
				$this->Export = Post("exporttype");
			$custom = Post("custom", "");
		} elseif (Get("cmd") == "json") {
			$this->Export = Get("cmd");
		} else {
			$this->setExportReturnUrl(CurrentUrl());
		}
		$ExportFileName = $this->TableVar; // Get export file, used in header

		// Get custom export parameters
		if ($this->isExport() && $custom != "") {
			$this->CustomExport = $this->Export;
			$this->Export = "print";
		}
		$CustomExportType = $this->CustomExport;
		$ExportType = $this->Export; // Get export parameter, used in header

		// Update Export URLs
		if (Config("USE_PHPEXCEL"))
			$this->ExportExcelCustom = FALSE;
		if ($this->ExportExcelCustom)
			$this->ExportExcelUrl .= "&amp;custom=1";
		if (Config("USE_PHPWORD"))
			$this->ExportWordCustom = FALSE;
		if ($this->ExportWordCustom)
			$this->ExportWordUrl .= "&amp;custom=1";
		if ($this->ExportPdfCustom)
			$this->ExportPdfUrl .= "&amp;custom=1";
		$this->CurrentAction = Param("action"); // Set up current action

		// Get grid add count
		$gridaddcnt = Get(Config("TABLE_GRID_ADD_ROW_COUNT"), "");
		if (is_numeric($gridaddcnt) && $gridaddcnt > 0)
			$this->GridAddRowCount = $gridaddcnt;

		// Set up list options
		$this->setupListOptions();

		// Setup export options
		$this->setupExportOptions();
		$this->loanid->setVisibility();
		$this->_userid->setVisibility();
		$this->issueddate->setVisibility();
		$this->currcode->setVisibility();
		$this->issuedamount->Visible = FALSE;
		$this->externalrefno->Visible = FALSE;
		$this->fullypaidind->setVisibility();
		$this->bankcode->Visible = FALSE;
		$this->feeperc->Visible = FALSE;
		$this->feeamount->Visible = FALSE;
		$this->taxperc->Visible = FALSE;
		$this->taxamount->Visible = FALSE;
		$this->totalamount->Visible = FALSE;
		$this->paymenttargetdate->Visible = FALSE;
		$this->feefixed->Visible = FALSE;
		$this->totalfees->Visible = FALSE;
		$this->approveruserid->Visible = FALSE;
		$this->docid->Visible = FALSE;
		$this->feesystemtotal->Visible = FALSE;
		$this->feeexternaltotal->Visible = FALSE;
		$this->feefranchiseetotal->Visible = FALSE;
		$this->feeresellertotal->Visible = FALSE;
		$this->purchasefeeid->Visible = FALSE;
		$this->cancellationrefid->Visible = FALSE;
		$this->cancellationdatetime->Visible = FALSE;
		$this->cancellationreason->Visible = FALSE;
		$this->lastupdatedate->Visible = FALSE;
		$this->feeexternaltotaltime->Visible = FALSE;
		$this->totalamountapplied->Visible = FALSE;
		$this->totalfeesapplied->Visible = FALSE;
		$this->totalprincipleandfees->Visible = FALSE;
		$this->taxamountbreakdown->Visible = FALSE;
		$this->feesystembreakdown->Visible = FALSE;
		$this->feeexternalbreakdown->Visible = FALSE;
		$this->feefranchiseebreakdown->Visible = FALSE;
		$this->feeresellerbreakdown->Visible = FALSE;
		$this->outstandingprinciple->Visible = FALSE;
		$this->outstandingfees->Visible = FALSE;
		$this->outstandingprincipleandfees->Visible = FALSE;
		$this->lastupdate->Visible = FALSE;
		$this->externalprovisioningrefno->Visible = FALSE;
		$this->loantype->Visible = FALSE;
		$this->numberofoutstandingdays->Visible = FALSE;
		$this->loandue->Visible = FALSE;
		$this->loanduedate->Visible = FALSE;
		$this->outstandinglatefees->Visible = FALSE;
		$this->disbursementtype->Visible = FALSE;
		$this->disbursementamount->Visible = FALSE;
		$this->loanconfirmed->setVisibility();
		$this->loanconfirmedtime->Visible = FALSE;
		$this->loanupgraded->Visible = FALSE;
		$this->stoplatefee->Visible = FALSE;
		$this->otherdetails1->Visible = FALSE;
		$this->lockflag->Visible = FALSE;
		$this->lastlatefeecalculatedate->Visible = FALSE;
		$this->notificationlockflag->Visible = FALSE;
		$this->lastnotificationdate->Visible = FALSE;
		$this->sendnotificationtextdate->Visible = FALSE;
		$this->termtype->setVisibility();
		$this->hideFieldsForAddEdit();

		// Global Page Loading event (in userfn*.php)
		Page_Loading();

		// Page Load event
		$this->Page_Load();

		// Check token
		if (!$this->validPost()) {
			Write($Language->phrase("InvalidPostRequest"));
			$this->terminate();
		}

		// Create Token
		$this->createToken();

		// Set up master detail parameters
		$this->setupMasterParms();

		// Setup other options
		$this->setupOtherOptions();

		// Set up custom action (compatible with old version)
		foreach ($this->CustomActions as $name => $action)
			$this->ListActions->add($name, $action);

		// Show checkbox column if multiple action
		foreach ($this->ListActions->Items as $listaction) {
			if ($listaction->Select == ACTION_MULTIPLE && $listaction->Allow) {
				$this->ListOptions["checkbox"]->Visible = TRUE;
				break;
			}
		}

		// Set up lookup cache
		$this->setupLookupOptions($this->currcode);
		$this->setupLookupOptions($this->loantype);
		$this->setupLookupOptions($this->loandue);
		$this->setupLookupOptions($this->loanconfirmed);
		$this->setupLookupOptions($this->loanupgraded);
		$this->setupLookupOptions($this->stoplatefee);

		// Search filters
		$srchAdvanced = ""; // Advanced search filter
		$srchBasic = ""; // Basic search filter
		$filter = "";

		// Get command
		$this->Command = strtolower(Get("cmd"));
		if ($this->isPageRequest()) { // Validate request

			// Process list action first
			if ($this->processListAction()) // Ajax request
				$this->terminate();

			// Set up records per page
			$this->setupDisplayRecords();

			// Handle reset command
			$this->resetCmd();

			// Set up Breadcrumb
			if (!$this->isExport())
				$this->setupBreadcrumb();

			// Hide list options
			if ($this->isExport()) {
				$this->ListOptions->hideAllOptions(["sequence"]);
				$this->ListOptions->UseDropDownButton = FALSE; // Disable drop down button
				$this->ListOptions->UseButtonGroup = FALSE; // Disable button group
			} elseif ($this->isGridAdd() || $this->isGridEdit()) {
				$this->ListOptions->hideAllOptions();
				$this->ListOptions->UseDropDownButton = FALSE; // Disable drop down button
				$this->ListOptions->UseButtonGroup = FALSE; // Disable button group
			}

			// Hide options
			if ($this->isExport() || $this->CurrentAction) {
				$this->ExportOptions->hideAllOptions();
				$this->FilterOptions->hideAllOptions();
				$this->ImportOptions->hideAllOptions();
			}

			// Hide other options
			if ($this->isExport())
				$this->OtherOptions->hideAllOptions();

			// Get default search criteria
			AddFilter($this->DefaultSearchWhere, $this->advancedSearchWhere(TRUE));

			// Get and validate search values for advanced search
			$this->loadSearchValues(); // Get search values

			// Process filter list
			if ($this->processFilterList())
				$this->terminate();
			if (!$this->validateSearch())
				$this->setFailureMessage($SearchError);

			// Restore search parms from Session if not searching / reset / export
			if (($this->isExport() || $this->Command != "search" && $this->Command != "reset" && $this->Command != "resetall") && $this->Command != "json" && $this->checkSearchParms())
				$this->restoreSearchParms();

			// Call Recordset SearchValidated event
			$this->Recordset_SearchValidated();

			// Set up sorting order
			$this->setupSortOrder();

			// Get search criteria for advanced search
			if ($SearchError == "")
				$srchAdvanced = $this->advancedSearchWhere();
		}

		// Restore display records
		if ($this->Command != "json" && $this->getRecordsPerPage() != "") {
			$this->DisplayRecords = $this->getRecordsPerPage(); // Restore from Session
		} else {
			$this->DisplayRecords = 10; // Load default
			$this->setRecordsPerPage($this->DisplayRecords); // Save default to Session
		}

		// Load Sorting Order
		if ($this->Command != "json")
			$this->loadSortOrder();

		// Load search default if no existing search criteria
		if (!$this->checkSearchParms()) {

			// Load advanced search from default
			if ($this->loadAdvancedSearchDefault()) {
				$srchAdvanced = $this->advancedSearchWhere();
			}
		}

		// Restore search settings from Session
		if ($SearchError == "")
			$this->loadAdvancedSearch();

		// Build search criteria
		AddFilter($this->SearchWhere, $srchAdvanced);
		AddFilter($this->SearchWhere, $srchBasic);

		// Call Recordset_Searching event
		$this->Recordset_Searching($this->SearchWhere);

		// Save search criteria
		if ($this->Command == "search" && !$this->RestoreSearch) {
			$this->setSearchWhere($this->SearchWhere); // Save to Session
			$this->StartRecord = 1; // Reset start record counter
			$this->setStartRecordNumber($this->StartRecord);
		} elseif ($this->Command != "json") {
			$this->SearchWhere = $this->getSearchWhere();
		}

		// Build filter
		$filter = "";
		if (!$Security->canList())
			$filter = "(0=1)"; // Filter all records

		// Restore master/detail filter
		$this->DbMasterFilter = $this->getMasterFilter(); // Restore master filter
		$this->DbDetailFilter = $this->getDetailFilter(); // Restore detail filter
		AddFilter($filter, $this->DbDetailFilter);
		AddFilter($filter, $this->SearchWhere);
		if ($filter == "") {
			$filter = "0=101";
			$this->SearchWhere = $filter;
		}

		// Load master record
		if ($this->CurrentMode != "add" && $this->getMasterFilter() != "" && $this->getCurrentMasterTable() == "loanrequests") {
			global $loanrequests;
			$rsmaster = $loanrequests->loadRs($this->DbMasterFilter);
			$this->MasterRecordExists = ($rsmaster && !$rsmaster->EOF);
			if (!$this->MasterRecordExists) {
				$this->setFailureMessage($Language->phrase("NoRecord")); // Set no record found
				$this->terminate("loanrequestslist.php"); // Return to master page
			} else {
				$loanrequests->loadListRowValues($rsmaster);
				$loanrequests->RowType = ROWTYPE_MASTER; // Master row
				$loanrequests->renderListRow();
				$rsmaster->close();
			}
		}

		// Load master record
		if ($this->CurrentMode != "add" && $this->getMasterFilter() != "" && $this->getCurrentMasterTable() == "loancancelrequests") {
			global $loancancelrequests;
			$rsmaster = $loancancelrequests->loadRs($this->DbMasterFilter);
			$this->MasterRecordExists = ($rsmaster && !$rsmaster->EOF);
			if (!$this->MasterRecordExists) {
				$this->setFailureMessage($Language->phrase("NoRecord")); // Set no record found
				$this->terminate("loancancelrequestslist.php"); // Return to master page
			} else {
				$loancancelrequests->loadListRowValues($rsmaster);
				$loancancelrequests->RowType = ROWTYPE_MASTER; // Master row
				$loancancelrequests->renderListRow();
				$rsmaster->close();
			}
		}

		// Load master record
		if ($this->CurrentMode != "add" && $this->getMasterFilter() != "" && $this->getCurrentMasterTable() == "loanlimits") {
			global $loanlimits;
			$rsmaster = $loanlimits->loadRs($this->DbMasterFilter);
			$this->MasterRecordExists = ($rsmaster && !$rsmaster->EOF);
			if (!$this->MasterRecordExists) {
				$this->setFailureMessage($Language->phrase("NoRecord")); // Set no record found
				$this->terminate("loanlimitslist.php"); // Return to master page
			} else {
				$loanlimits->loadListRowValues($rsmaster);
				$loanlimits->RowType = ROWTYPE_MASTER; // Master row
				$loanlimits->renderListRow();
				$rsmaster->close();
			}
		}

		// Set up filter
		if ($this->Command == "json") {
			$this->UseSessionForListSql = FALSE; // Do not use session for ListSQL
			$this->CurrentFilter = $filter;
		} else {
			$this->setSessionWhere($filter);
			$this->CurrentFilter = "";
		}

		// Export data only
		if (!$this->CustomExport && in_array($this->Export, array_keys(Config("EXPORT_CLASSES")))) {
			$this->exportData();
			$this->terminate();
		}
		if ($this->isGridAdd()) {
			$this->CurrentFilter = "0=1";
			$this->StartRecord = 1;
			$this->DisplayRecords = $this->GridAddRowCount;
			$this->TotalRecords = $this->DisplayRecords;
			$this->StopRecord = $this->DisplayRecords;
		} else {
			$selectLimit = $this->UseSelectLimit;
			if ($selectLimit) {
				$this->TotalRecords = $this->listRecordCount();
			} else {
				if ($this->Recordset = $this->loadRecordset())
					$this->TotalRecords = $this->Recordset->RecordCount();
			}
			$this->StartRecord = 1;
			if ($this->DisplayRecords <= 0 || ($this->isExport() && $this->ExportAll)) // Display all records
				$this->DisplayRecords = $this->TotalRecords;
			if (!($this->isExport() && $this->ExportAll)) // Set up start record position
				$this->setupStartRecord();
			if ($selectLimit)
				$this->Recordset = $this->loadRecordset($this->StartRecord - 1, $this->DisplayRecords);

			// Set no record found message
			if (!$this->CurrentAction && $this->TotalRecords == 0) {
				if (!$Security->canList())
					$this->setWarningMessage(DeniedMessage());
				if ($this->SearchWhere == "0=101")
					$this->setWarningMessage($Language->phrase("EnterSearchCriteria"));
				else
					$this->setWarningMessage($Language->phrase("NoRecord"));
			}

			// Audit trail on search
			if ($this->AuditTrailOnSearch && $this->Command == "search" && !$this->RestoreSearch) {
				$searchParm = ServerVar("QUERY_STRING");
				$searchSql = $this->getSessionWhere();
				$this->writeAuditTrailOnSearch($searchParm, $searchSql);
			}
		}

		// Search options
		$this->setupSearchOptions();

		// Set up search panel class
		if ($this->SearchWhere != "")
			AppendClass($this->SearchPanelClass, "show");

		// Normal return
		if (IsApi()) {
			$rows = $this->getRecordsFromRecordset($this->Recordset);
			$this->Recordset->close();
			WriteJson(["success" => TRUE, $this->TableVar => $rows, "totalRecordCount" => $this->TotalRecords]);
			$this->terminate(TRUE);
		}

		// Set up pager
		$this->Pager = new PrevNextPager($this->StartRecord, $this->getRecordsPerPage(), $this->TotalRecords, $this->PageSizes, $this->RecordRange, $this->AutoHidePager, $this->AutoHidePageSizeSelector);
	}

	// Set up number of records displayed per page
	protected function setupDisplayRecords()
	{
		$wrk = Get(Config("TABLE_REC_PER_PAGE"), "");
		if ($wrk != "") {
			if (is_numeric($wrk)) {
				$this->DisplayRecords = (int)$wrk;
			} else {
				if (SameText($wrk, "all")) { // Display all records
					$this->DisplayRecords = -1;
				} else {
					$this->DisplayRecords = 10; // Non-numeric, load default
				}
			}
			$this->setRecordsPerPage($this->DisplayRecords); // Save to Session

			// Reset start position
			$this->StartRecord = 1;
			$this->setStartRecordNumber($this->StartRecord);
		}
	}

	// Build filter for all keys
	protected function buildKeyFilter()
	{
		global $CurrentForm;
		$wrkFilter = "";

		// Update row index and get row key
		$rowindex = 1;
		$CurrentForm->Index = $rowindex;
		$thisKey = strval($CurrentForm->getValue($this->FormKeyName));
		while ($thisKey != "") {
			if ($this->setupKeyValues($thisKey)) {
				$filter = $this->getRecordFilter();
				if ($wrkFilter != "")
					$wrkFilter .= " OR ";
				$wrkFilter .= $filter;
			} else {
				$wrkFilter = "0=1";
				break;
			}

			// Update row index and get row key
			$rowindex++; // Next row
			$CurrentForm->Index = $rowindex;
			$thisKey = strval($CurrentForm->getValue($this->FormKeyName));
		}
		return $wrkFilter;
	}

	// Set up key values
	protected function setupKeyValues($key)
	{
		$arKeyFlds = explode(Config("COMPOSITE_KEY_SEPARATOR"), $key);
		if (count($arKeyFlds) >= 1) {
			$this->loanid->setOldValue($arKeyFlds[0]);
			if (!is_numeric($this->loanid->OldValue))
				return FALSE;
		}
		return TRUE;
	}

	// Get list of filters
	public function getFilterList()
	{
		global $UserProfile;

		// Initialize
		$filterList = "";
		$savedFilterList = "";

		// Load server side filters
		if (Config("SEARCH_FILTER_OPTION") == "Server" && isset($UserProfile))
			$savedFilterList = $UserProfile->getSearchFilters(CurrentUserName(), "floanissuedlistsrch");
		$filterList = Concat($filterList, $this->loanid->AdvancedSearch->toJson(), ","); // Field loanid
		$filterList = Concat($filterList, $this->_userid->AdvancedSearch->toJson(), ","); // Field userid
		$filterList = Concat($filterList, $this->issueddate->AdvancedSearch->toJson(), ","); // Field issueddate
		$filterList = Concat($filterList, $this->currcode->AdvancedSearch->toJson(), ","); // Field currcode
		$filterList = Concat($filterList, $this->issuedamount->AdvancedSearch->toJson(), ","); // Field issuedamount
		$filterList = Concat($filterList, $this->externalrefno->AdvancedSearch->toJson(), ","); // Field externalrefno
		$filterList = Concat($filterList, $this->fullypaidind->AdvancedSearch->toJson(), ","); // Field fullypaidind
		$filterList = Concat($filterList, $this->bankcode->AdvancedSearch->toJson(), ","); // Field bankcode
		$filterList = Concat($filterList, $this->feeperc->AdvancedSearch->toJson(), ","); // Field feeperc
		$filterList = Concat($filterList, $this->feeamount->AdvancedSearch->toJson(), ","); // Field feeamount
		$filterList = Concat($filterList, $this->taxperc->AdvancedSearch->toJson(), ","); // Field taxperc
		$filterList = Concat($filterList, $this->taxamount->AdvancedSearch->toJson(), ","); // Field taxamount
		$filterList = Concat($filterList, $this->totalamount->AdvancedSearch->toJson(), ","); // Field totalamount
		$filterList = Concat($filterList, $this->paymenttargetdate->AdvancedSearch->toJson(), ","); // Field paymenttargetdate
		$filterList = Concat($filterList, $this->feefixed->AdvancedSearch->toJson(), ","); // Field feefixed
		$filterList = Concat($filterList, $this->totalfees->AdvancedSearch->toJson(), ","); // Field totalfees
		$filterList = Concat($filterList, $this->approveruserid->AdvancedSearch->toJson(), ","); // Field approveruserid
		$filterList = Concat($filterList, $this->docid->AdvancedSearch->toJson(), ","); // Field docid
		$filterList = Concat($filterList, $this->feesystemtotal->AdvancedSearch->toJson(), ","); // Field feesystemtotal
		$filterList = Concat($filterList, $this->feeexternaltotal->AdvancedSearch->toJson(), ","); // Field feeexternaltotal
		$filterList = Concat($filterList, $this->feefranchiseetotal->AdvancedSearch->toJson(), ","); // Field feefranchiseetotal
		$filterList = Concat($filterList, $this->feeresellertotal->AdvancedSearch->toJson(), ","); // Field feeresellertotal
		$filterList = Concat($filterList, $this->purchasefeeid->AdvancedSearch->toJson(), ","); // Field purchasefeeid
		$filterList = Concat($filterList, $this->cancellationrefid->AdvancedSearch->toJson(), ","); // Field cancellationrefid
		$filterList = Concat($filterList, $this->cancellationdatetime->AdvancedSearch->toJson(), ","); // Field cancellationdatetime
		$filterList = Concat($filterList, $this->cancellationreason->AdvancedSearch->toJson(), ","); // Field cancellationreason
		$filterList = Concat($filterList, $this->lastupdatedate->AdvancedSearch->toJson(), ","); // Field lastupdatedate
		$filterList = Concat($filterList, $this->feeexternaltotaltime->AdvancedSearch->toJson(), ","); // Field feeexternaltotaltime
		$filterList = Concat($filterList, $this->totalamountapplied->AdvancedSearch->toJson(), ","); // Field totalamountapplied
		$filterList = Concat($filterList, $this->totalfeesapplied->AdvancedSearch->toJson(), ","); // Field totalfeesapplied
		$filterList = Concat($filterList, $this->totalprincipleandfees->AdvancedSearch->toJson(), ","); // Field totalprincipleandfees
		$filterList = Concat($filterList, $this->taxamountbreakdown->AdvancedSearch->toJson(), ","); // Field taxamountbreakdown
		$filterList = Concat($filterList, $this->feesystembreakdown->AdvancedSearch->toJson(), ","); // Field feesystembreakdown
		$filterList = Concat($filterList, $this->feeexternalbreakdown->AdvancedSearch->toJson(), ","); // Field feeexternalbreakdown
		$filterList = Concat($filterList, $this->feefranchiseebreakdown->AdvancedSearch->toJson(), ","); // Field feefranchiseebreakdown
		$filterList = Concat($filterList, $this->feeresellerbreakdown->AdvancedSearch->toJson(), ","); // Field feeresellerbreakdown
		$filterList = Concat($filterList, $this->outstandingprinciple->AdvancedSearch->toJson(), ","); // Field outstandingprinciple
		$filterList = Concat($filterList, $this->outstandingfees->AdvancedSearch->toJson(), ","); // Field outstandingfees
		$filterList = Concat($filterList, $this->outstandingprincipleandfees->AdvancedSearch->toJson(), ","); // Field outstandingprincipleandfees
		$filterList = Concat($filterList, $this->lastupdate->AdvancedSearch->toJson(), ","); // Field lastupdate
		$filterList = Concat($filterList, $this->externalprovisioningrefno->AdvancedSearch->toJson(), ","); // Field externalprovisioningrefno
		$filterList = Concat($filterList, $this->loantype->AdvancedSearch->toJson(), ","); // Field loantype
		$filterList = Concat($filterList, $this->numberofoutstandingdays->AdvancedSearch->toJson(), ","); // Field numberofoutstandingdays
		$filterList = Concat($filterList, $this->loandue->AdvancedSearch->toJson(), ","); // Field loandue
		$filterList = Concat($filterList, $this->loanduedate->AdvancedSearch->toJson(), ","); // Field loanduedate
		$filterList = Concat($filterList, $this->outstandinglatefees->AdvancedSearch->toJson(), ","); // Field outstandinglatefees
		$filterList = Concat($filterList, $this->disbursementtype->AdvancedSearch->toJson(), ","); // Field disbursementtype
		$filterList = Concat($filterList, $this->disbursementamount->AdvancedSearch->toJson(), ","); // Field disbursementamount
		$filterList = Concat($filterList, $this->loanconfirmed->AdvancedSearch->toJson(), ","); // Field loanconfirmed
		$filterList = Concat($filterList, $this->loanconfirmedtime->AdvancedSearch->toJson(), ","); // Field loanconfirmedtime
		$filterList = Concat($filterList, $this->loanupgraded->AdvancedSearch->toJson(), ","); // Field loanupgraded
		$filterList = Concat($filterList, $this->stoplatefee->AdvancedSearch->toJson(), ","); // Field stoplatefee
		$filterList = Concat($filterList, $this->otherdetails1->AdvancedSearch->toJson(), ","); // Field otherdetails1
		$filterList = Concat($filterList, $this->lockflag->AdvancedSearch->toJson(), ","); // Field lockflag
		$filterList = Concat($filterList, $this->lastlatefeecalculatedate->AdvancedSearch->toJson(), ","); // Field lastlatefeecalculatedate
		$filterList = Concat($filterList, $this->notificationlockflag->AdvancedSearch->toJson(), ","); // Field notificationlockflag
		$filterList = Concat($filterList, $this->lastnotificationdate->AdvancedSearch->toJson(), ","); // Field lastnotificationdate
		$filterList = Concat($filterList, $this->sendnotificationtextdate->AdvancedSearch->toJson(), ","); // Field sendnotificationtextdate
		$filterList = Concat($filterList, $this->termtype->AdvancedSearch->toJson(), ","); // Field termtype

		// Return filter list in JSON
		if ($filterList != "")
			$filterList = "\"data\":{" . $filterList . "}";
		if ($savedFilterList != "")
			$filterList = Concat($filterList, "\"filters\":" . $savedFilterList, ",");
		return ($filterList != "") ? "{" . $filterList . "}" : "null";
	}

	// Process filter list
	protected function processFilterList()
	{
		global $UserProfile;
		if (Post("ajax") == "savefilters") { // Save filter request (Ajax)
			$filters = Post("filters");
			$UserProfile->setSearchFilters(CurrentUserName(), "floanissuedlistsrch", $filters);
			WriteJson([["success" => TRUE]]); // Success
			return TRUE;
		} elseif (Post("cmd") == "resetfilter") {
			$this->restoreFilterList();
		}
		return FALSE;
	}

	// Restore list of filters
	protected function restoreFilterList()
	{

		// Return if not reset filter
		if (Post("cmd") !== "resetfilter")
			return FALSE;
		$filter = json_decode(Post("filter"), TRUE);
		$this->Command = "search";

		// Field loanid
		$this->loanid->AdvancedSearch->SearchValue = @$filter["x_loanid"];
		$this->loanid->AdvancedSearch->SearchOperator = @$filter["z_loanid"];
		$this->loanid->AdvancedSearch->SearchCondition = @$filter["v_loanid"];
		$this->loanid->AdvancedSearch->SearchValue2 = @$filter["y_loanid"];
		$this->loanid->AdvancedSearch->SearchOperator2 = @$filter["w_loanid"];
		$this->loanid->AdvancedSearch->save();

		// Field userid
		$this->_userid->AdvancedSearch->SearchValue = @$filter["x__userid"];
		$this->_userid->AdvancedSearch->SearchOperator = @$filter["z__userid"];
		$this->_userid->AdvancedSearch->SearchCondition = @$filter["v__userid"];
		$this->_userid->AdvancedSearch->SearchValue2 = @$filter["y__userid"];
		$this->_userid->AdvancedSearch->SearchOperator2 = @$filter["w__userid"];
		$this->_userid->AdvancedSearch->save();

		// Field issueddate
		$this->issueddate->AdvancedSearch->SearchValue = @$filter["x_issueddate"];
		$this->issueddate->AdvancedSearch->SearchOperator = @$filter["z_issueddate"];
		$this->issueddate->AdvancedSearch->SearchCondition = @$filter["v_issueddate"];
		$this->issueddate->AdvancedSearch->SearchValue2 = @$filter["y_issueddate"];
		$this->issueddate->AdvancedSearch->SearchOperator2 = @$filter["w_issueddate"];
		$this->issueddate->AdvancedSearch->save();

		// Field currcode
		$this->currcode->AdvancedSearch->SearchValue = @$filter["x_currcode"];
		$this->currcode->AdvancedSearch->SearchOperator = @$filter["z_currcode"];
		$this->currcode->AdvancedSearch->SearchCondition = @$filter["v_currcode"];
		$this->currcode->AdvancedSearch->SearchValue2 = @$filter["y_currcode"];
		$this->currcode->AdvancedSearch->SearchOperator2 = @$filter["w_currcode"];
		$this->currcode->AdvancedSearch->save();

		// Field issuedamount
		$this->issuedamount->AdvancedSearch->SearchValue = @$filter["x_issuedamount"];
		$this->issuedamount->AdvancedSearch->SearchOperator = @$filter["z_issuedamount"];
		$this->issuedamount->AdvancedSearch->SearchCondition = @$filter["v_issuedamount"];
		$this->issuedamount->AdvancedSearch->SearchValue2 = @$filter["y_issuedamount"];
		$this->issuedamount->AdvancedSearch->SearchOperator2 = @$filter["w_issuedamount"];
		$this->issuedamount->AdvancedSearch->save();

		// Field externalrefno
		$this->externalrefno->AdvancedSearch->SearchValue = @$filter["x_externalrefno"];
		$this->externalrefno->AdvancedSearch->SearchOperator = @$filter["z_externalrefno"];
		$this->externalrefno->AdvancedSearch->SearchCondition = @$filter["v_externalrefno"];
		$this->externalrefno->AdvancedSearch->SearchValue2 = @$filter["y_externalrefno"];
		$this->externalrefno->AdvancedSearch->SearchOperator2 = @$filter["w_externalrefno"];
		$this->externalrefno->AdvancedSearch->save();

		// Field fullypaidind
		$this->fullypaidind->AdvancedSearch->SearchValue = @$filter["x_fullypaidind"];
		$this->fullypaidind->AdvancedSearch->SearchOperator = @$filter["z_fullypaidind"];
		$this->fullypaidind->AdvancedSearch->SearchCondition = @$filter["v_fullypaidind"];
		$this->fullypaidind->AdvancedSearch->SearchValue2 = @$filter["y_fullypaidind"];
		$this->fullypaidind->AdvancedSearch->SearchOperator2 = @$filter["w_fullypaidind"];
		$this->fullypaidind->AdvancedSearch->save();

		// Field bankcode
		$this->bankcode->AdvancedSearch->SearchValue = @$filter["x_bankcode"];
		$this->bankcode->AdvancedSearch->SearchOperator = @$filter["z_bankcode"];
		$this->bankcode->AdvancedSearch->SearchCondition = @$filter["v_bankcode"];
		$this->bankcode->AdvancedSearch->SearchValue2 = @$filter["y_bankcode"];
		$this->bankcode->AdvancedSearch->SearchOperator2 = @$filter["w_bankcode"];
		$this->bankcode->AdvancedSearch->save();

		// Field feeperc
		$this->feeperc->AdvancedSearch->SearchValue = @$filter["x_feeperc"];
		$this->feeperc->AdvancedSearch->SearchOperator = @$filter["z_feeperc"];
		$this->feeperc->AdvancedSearch->SearchCondition = @$filter["v_feeperc"];
		$this->feeperc->AdvancedSearch->SearchValue2 = @$filter["y_feeperc"];
		$this->feeperc->AdvancedSearch->SearchOperator2 = @$filter["w_feeperc"];
		$this->feeperc->AdvancedSearch->save();

		// Field feeamount
		$this->feeamount->AdvancedSearch->SearchValue = @$filter["x_feeamount"];
		$this->feeamount->AdvancedSearch->SearchOperator = @$filter["z_feeamount"];
		$this->feeamount->AdvancedSearch->SearchCondition = @$filter["v_feeamount"];
		$this->feeamount->AdvancedSearch->SearchValue2 = @$filter["y_feeamount"];
		$this->feeamount->AdvancedSearch->SearchOperator2 = @$filter["w_feeamount"];
		$this->feeamount->AdvancedSearch->save();

		// Field taxperc
		$this->taxperc->AdvancedSearch->SearchValue = @$filter["x_taxperc"];
		$this->taxperc->AdvancedSearch->SearchOperator = @$filter["z_taxperc"];
		$this->taxperc->AdvancedSearch->SearchCondition = @$filter["v_taxperc"];
		$this->taxperc->AdvancedSearch->SearchValue2 = @$filter["y_taxperc"];
		$this->taxperc->AdvancedSearch->SearchOperator2 = @$filter["w_taxperc"];
		$this->taxperc->AdvancedSearch->save();

		// Field taxamount
		$this->taxamount->AdvancedSearch->SearchValue = @$filter["x_taxamount"];
		$this->taxamount->AdvancedSearch->SearchOperator = @$filter["z_taxamount"];
		$this->taxamount->AdvancedSearch->SearchCondition = @$filter["v_taxamount"];
		$this->taxamount->AdvancedSearch->SearchValue2 = @$filter["y_taxamount"];
		$this->taxamount->AdvancedSearch->SearchOperator2 = @$filter["w_taxamount"];
		$this->taxamount->AdvancedSearch->save();

		// Field totalamount
		$this->totalamount->AdvancedSearch->SearchValue = @$filter["x_totalamount"];
		$this->totalamount->AdvancedSearch->SearchOperator = @$filter["z_totalamount"];
		$this->totalamount->AdvancedSearch->SearchCondition = @$filter["v_totalamount"];
		$this->totalamount->AdvancedSearch->SearchValue2 = @$filter["y_totalamount"];
		$this->totalamount->AdvancedSearch->SearchOperator2 = @$filter["w_totalamount"];
		$this->totalamount->AdvancedSearch->save();

		// Field paymenttargetdate
		$this->paymenttargetdate->AdvancedSearch->SearchValue = @$filter["x_paymenttargetdate"];
		$this->paymenttargetdate->AdvancedSearch->SearchOperator = @$filter["z_paymenttargetdate"];
		$this->paymenttargetdate->AdvancedSearch->SearchCondition = @$filter["v_paymenttargetdate"];
		$this->paymenttargetdate->AdvancedSearch->SearchValue2 = @$filter["y_paymenttargetdate"];
		$this->paymenttargetdate->AdvancedSearch->SearchOperator2 = @$filter["w_paymenttargetdate"];
		$this->paymenttargetdate->AdvancedSearch->save();

		// Field feefixed
		$this->feefixed->AdvancedSearch->SearchValue = @$filter["x_feefixed"];
		$this->feefixed->AdvancedSearch->SearchOperator = @$filter["z_feefixed"];
		$this->feefixed->AdvancedSearch->SearchCondition = @$filter["v_feefixed"];
		$this->feefixed->AdvancedSearch->SearchValue2 = @$filter["y_feefixed"];
		$this->feefixed->AdvancedSearch->SearchOperator2 = @$filter["w_feefixed"];
		$this->feefixed->AdvancedSearch->save();

		// Field totalfees
		$this->totalfees->AdvancedSearch->SearchValue = @$filter["x_totalfees"];
		$this->totalfees->AdvancedSearch->SearchOperator = @$filter["z_totalfees"];
		$this->totalfees->AdvancedSearch->SearchCondition = @$filter["v_totalfees"];
		$this->totalfees->AdvancedSearch->SearchValue2 = @$filter["y_totalfees"];
		$this->totalfees->AdvancedSearch->SearchOperator2 = @$filter["w_totalfees"];
		$this->totalfees->AdvancedSearch->save();

		// Field approveruserid
		$this->approveruserid->AdvancedSearch->SearchValue = @$filter["x_approveruserid"];
		$this->approveruserid->AdvancedSearch->SearchOperator = @$filter["z_approveruserid"];
		$this->approveruserid->AdvancedSearch->SearchCondition = @$filter["v_approveruserid"];
		$this->approveruserid->AdvancedSearch->SearchValue2 = @$filter["y_approveruserid"];
		$this->approveruserid->AdvancedSearch->SearchOperator2 = @$filter["w_approveruserid"];
		$this->approveruserid->AdvancedSearch->save();

		// Field docid
		$this->docid->AdvancedSearch->SearchValue = @$filter["x_docid"];
		$this->docid->AdvancedSearch->SearchOperator = @$filter["z_docid"];
		$this->docid->AdvancedSearch->SearchCondition = @$filter["v_docid"];
		$this->docid->AdvancedSearch->SearchValue2 = @$filter["y_docid"];
		$this->docid->AdvancedSearch->SearchOperator2 = @$filter["w_docid"];
		$this->docid->AdvancedSearch->save();

		// Field feesystemtotal
		$this->feesystemtotal->AdvancedSearch->SearchValue = @$filter["x_feesystemtotal"];
		$this->feesystemtotal->AdvancedSearch->SearchOperator = @$filter["z_feesystemtotal"];
		$this->feesystemtotal->AdvancedSearch->SearchCondition = @$filter["v_feesystemtotal"];
		$this->feesystemtotal->AdvancedSearch->SearchValue2 = @$filter["y_feesystemtotal"];
		$this->feesystemtotal->AdvancedSearch->SearchOperator2 = @$filter["w_feesystemtotal"];
		$this->feesystemtotal->AdvancedSearch->save();

		// Field feeexternaltotal
		$this->feeexternaltotal->AdvancedSearch->SearchValue = @$filter["x_feeexternaltotal"];
		$this->feeexternaltotal->AdvancedSearch->SearchOperator = @$filter["z_feeexternaltotal"];
		$this->feeexternaltotal->AdvancedSearch->SearchCondition = @$filter["v_feeexternaltotal"];
		$this->feeexternaltotal->AdvancedSearch->SearchValue2 = @$filter["y_feeexternaltotal"];
		$this->feeexternaltotal->AdvancedSearch->SearchOperator2 = @$filter["w_feeexternaltotal"];
		$this->feeexternaltotal->AdvancedSearch->save();

		// Field feefranchiseetotal
		$this->feefranchiseetotal->AdvancedSearch->SearchValue = @$filter["x_feefranchiseetotal"];
		$this->feefranchiseetotal->AdvancedSearch->SearchOperator = @$filter["z_feefranchiseetotal"];
		$this->feefranchiseetotal->AdvancedSearch->SearchCondition = @$filter["v_feefranchiseetotal"];
		$this->feefranchiseetotal->AdvancedSearch->SearchValue2 = @$filter["y_feefranchiseetotal"];
		$this->feefranchiseetotal->AdvancedSearch->SearchOperator2 = @$filter["w_feefranchiseetotal"];
		$this->feefranchiseetotal->AdvancedSearch->save();

		// Field feeresellertotal
		$this->feeresellertotal->AdvancedSearch->SearchValue = @$filter["x_feeresellertotal"];
		$this->feeresellertotal->AdvancedSearch->SearchOperator = @$filter["z_feeresellertotal"];
		$this->feeresellertotal->AdvancedSearch->SearchCondition = @$filter["v_feeresellertotal"];
		$this->feeresellertotal->AdvancedSearch->SearchValue2 = @$filter["y_feeresellertotal"];
		$this->feeresellertotal->AdvancedSearch->SearchOperator2 = @$filter["w_feeresellertotal"];
		$this->feeresellertotal->AdvancedSearch->save();

		// Field purchasefeeid
		$this->purchasefeeid->AdvancedSearch->SearchValue = @$filter["x_purchasefeeid"];
		$this->purchasefeeid->AdvancedSearch->SearchOperator = @$filter["z_purchasefeeid"];
		$this->purchasefeeid->AdvancedSearch->SearchCondition = @$filter["v_purchasefeeid"];
		$this->purchasefeeid->AdvancedSearch->SearchValue2 = @$filter["y_purchasefeeid"];
		$this->purchasefeeid->AdvancedSearch->SearchOperator2 = @$filter["w_purchasefeeid"];
		$this->purchasefeeid->AdvancedSearch->save();

		// Field cancellationrefid
		$this->cancellationrefid->AdvancedSearch->SearchValue = @$filter["x_cancellationrefid"];
		$this->cancellationrefid->AdvancedSearch->SearchOperator = @$filter["z_cancellationrefid"];
		$this->cancellationrefid->AdvancedSearch->SearchCondition = @$filter["v_cancellationrefid"];
		$this->cancellationrefid->AdvancedSearch->SearchValue2 = @$filter["y_cancellationrefid"];
		$this->cancellationrefid->AdvancedSearch->SearchOperator2 = @$filter["w_cancellationrefid"];
		$this->cancellationrefid->AdvancedSearch->save();

		// Field cancellationdatetime
		$this->cancellationdatetime->AdvancedSearch->SearchValue = @$filter["x_cancellationdatetime"];
		$this->cancellationdatetime->AdvancedSearch->SearchOperator = @$filter["z_cancellationdatetime"];
		$this->cancellationdatetime->AdvancedSearch->SearchCondition = @$filter["v_cancellationdatetime"];
		$this->cancellationdatetime->AdvancedSearch->SearchValue2 = @$filter["y_cancellationdatetime"];
		$this->cancellationdatetime->AdvancedSearch->SearchOperator2 = @$filter["w_cancellationdatetime"];
		$this->cancellationdatetime->AdvancedSearch->save();

		// Field cancellationreason
		$this->cancellationreason->AdvancedSearch->SearchValue = @$filter["x_cancellationreason"];
		$this->cancellationreason->AdvancedSearch->SearchOperator = @$filter["z_cancellationreason"];
		$this->cancellationreason->AdvancedSearch->SearchCondition = @$filter["v_cancellationreason"];
		$this->cancellationreason->AdvancedSearch->SearchValue2 = @$filter["y_cancellationreason"];
		$this->cancellationreason->AdvancedSearch->SearchOperator2 = @$filter["w_cancellationreason"];
		$this->cancellationreason->AdvancedSearch->save();

		// Field lastupdatedate
		$this->lastupdatedate->AdvancedSearch->SearchValue = @$filter["x_lastupdatedate"];
		$this->lastupdatedate->AdvancedSearch->SearchOperator = @$filter["z_lastupdatedate"];
		$this->lastupdatedate->AdvancedSearch->SearchCondition = @$filter["v_lastupdatedate"];
		$this->lastupdatedate->AdvancedSearch->SearchValue2 = @$filter["y_lastupdatedate"];
		$this->lastupdatedate->AdvancedSearch->SearchOperator2 = @$filter["w_lastupdatedate"];
		$this->lastupdatedate->AdvancedSearch->save();

		// Field feeexternaltotaltime
		$this->feeexternaltotaltime->AdvancedSearch->SearchValue = @$filter["x_feeexternaltotaltime"];
		$this->feeexternaltotaltime->AdvancedSearch->SearchOperator = @$filter["z_feeexternaltotaltime"];
		$this->feeexternaltotaltime->AdvancedSearch->SearchCondition = @$filter["v_feeexternaltotaltime"];
		$this->feeexternaltotaltime->AdvancedSearch->SearchValue2 = @$filter["y_feeexternaltotaltime"];
		$this->feeexternaltotaltime->AdvancedSearch->SearchOperator2 = @$filter["w_feeexternaltotaltime"];
		$this->feeexternaltotaltime->AdvancedSearch->save();

		// Field totalamountapplied
		$this->totalamountapplied->AdvancedSearch->SearchValue = @$filter["x_totalamountapplied"];
		$this->totalamountapplied->AdvancedSearch->SearchOperator = @$filter["z_totalamountapplied"];
		$this->totalamountapplied->AdvancedSearch->SearchCondition = @$filter["v_totalamountapplied"];
		$this->totalamountapplied->AdvancedSearch->SearchValue2 = @$filter["y_totalamountapplied"];
		$this->totalamountapplied->AdvancedSearch->SearchOperator2 = @$filter["w_totalamountapplied"];
		$this->totalamountapplied->AdvancedSearch->save();

		// Field totalfeesapplied
		$this->totalfeesapplied->AdvancedSearch->SearchValue = @$filter["x_totalfeesapplied"];
		$this->totalfeesapplied->AdvancedSearch->SearchOperator = @$filter["z_totalfeesapplied"];
		$this->totalfeesapplied->AdvancedSearch->SearchCondition = @$filter["v_totalfeesapplied"];
		$this->totalfeesapplied->AdvancedSearch->SearchValue2 = @$filter["y_totalfeesapplied"];
		$this->totalfeesapplied->AdvancedSearch->SearchOperator2 = @$filter["w_totalfeesapplied"];
		$this->totalfeesapplied->AdvancedSearch->save();

		// Field totalprincipleandfees
		$this->totalprincipleandfees->AdvancedSearch->SearchValue = @$filter["x_totalprincipleandfees"];
		$this->totalprincipleandfees->AdvancedSearch->SearchOperator = @$filter["z_totalprincipleandfees"];
		$this->totalprincipleandfees->AdvancedSearch->SearchCondition = @$filter["v_totalprincipleandfees"];
		$this->totalprincipleandfees->AdvancedSearch->SearchValue2 = @$filter["y_totalprincipleandfees"];
		$this->totalprincipleandfees->AdvancedSearch->SearchOperator2 = @$filter["w_totalprincipleandfees"];
		$this->totalprincipleandfees->AdvancedSearch->save();

		// Field taxamountbreakdown
		$this->taxamountbreakdown->AdvancedSearch->SearchValue = @$filter["x_taxamountbreakdown"];
		$this->taxamountbreakdown->AdvancedSearch->SearchOperator = @$filter["z_taxamountbreakdown"];
		$this->taxamountbreakdown->AdvancedSearch->SearchCondition = @$filter["v_taxamountbreakdown"];
		$this->taxamountbreakdown->AdvancedSearch->SearchValue2 = @$filter["y_taxamountbreakdown"];
		$this->taxamountbreakdown->AdvancedSearch->SearchOperator2 = @$filter["w_taxamountbreakdown"];
		$this->taxamountbreakdown->AdvancedSearch->save();

		// Field feesystembreakdown
		$this->feesystembreakdown->AdvancedSearch->SearchValue = @$filter["x_feesystembreakdown"];
		$this->feesystembreakdown->AdvancedSearch->SearchOperator = @$filter["z_feesystembreakdown"];
		$this->feesystembreakdown->AdvancedSearch->SearchCondition = @$filter["v_feesystembreakdown"];
		$this->feesystembreakdown->AdvancedSearch->SearchValue2 = @$filter["y_feesystembreakdown"];
		$this->feesystembreakdown->AdvancedSearch->SearchOperator2 = @$filter["w_feesystembreakdown"];
		$this->feesystembreakdown->AdvancedSearch->save();

		// Field feeexternalbreakdown
		$this->feeexternalbreakdown->AdvancedSearch->SearchValue = @$filter["x_feeexternalbreakdown"];
		$this->feeexternalbreakdown->AdvancedSearch->SearchOperator = @$filter["z_feeexternalbreakdown"];
		$this->feeexternalbreakdown->AdvancedSearch->SearchCondition = @$filter["v_feeexternalbreakdown"];
		$this->feeexternalbreakdown->AdvancedSearch->SearchValue2 = @$filter["y_feeexternalbreakdown"];
		$this->feeexternalbreakdown->AdvancedSearch->SearchOperator2 = @$filter["w_feeexternalbreakdown"];
		$this->feeexternalbreakdown->AdvancedSearch->save();

		// Field feefranchiseebreakdown
		$this->feefranchiseebreakdown->AdvancedSearch->SearchValue = @$filter["x_feefranchiseebreakdown"];
		$this->feefranchiseebreakdown->AdvancedSearch->SearchOperator = @$filter["z_feefranchiseebreakdown"];
		$this->feefranchiseebreakdown->AdvancedSearch->SearchCondition = @$filter["v_feefranchiseebreakdown"];
		$this->feefranchiseebreakdown->AdvancedSearch->SearchValue2 = @$filter["y_feefranchiseebreakdown"];
		$this->feefranchiseebreakdown->AdvancedSearch->SearchOperator2 = @$filter["w_feefranchiseebreakdown"];
		$this->feefranchiseebreakdown->AdvancedSearch->save();

		// Field feeresellerbreakdown
		$this->feeresellerbreakdown->AdvancedSearch->SearchValue = @$filter["x_feeresellerbreakdown"];
		$this->feeresellerbreakdown->AdvancedSearch->SearchOperator = @$filter["z_feeresellerbreakdown"];
		$this->feeresellerbreakdown->AdvancedSearch->SearchCondition = @$filter["v_feeresellerbreakdown"];
		$this->feeresellerbreakdown->AdvancedSearch->SearchValue2 = @$filter["y_feeresellerbreakdown"];
		$this->feeresellerbreakdown->AdvancedSearch->SearchOperator2 = @$filter["w_feeresellerbreakdown"];
		$this->feeresellerbreakdown->AdvancedSearch->save();

		// Field outstandingprinciple
		$this->outstandingprinciple->AdvancedSearch->SearchValue = @$filter["x_outstandingprinciple"];
		$this->outstandingprinciple->AdvancedSearch->SearchOperator = @$filter["z_outstandingprinciple"];
		$this->outstandingprinciple->AdvancedSearch->SearchCondition = @$filter["v_outstandingprinciple"];
		$this->outstandingprinciple->AdvancedSearch->SearchValue2 = @$filter["y_outstandingprinciple"];
		$this->outstandingprinciple->AdvancedSearch->SearchOperator2 = @$filter["w_outstandingprinciple"];
		$this->outstandingprinciple->AdvancedSearch->save();

		// Field outstandingfees
		$this->outstandingfees->AdvancedSearch->SearchValue = @$filter["x_outstandingfees"];
		$this->outstandingfees->AdvancedSearch->SearchOperator = @$filter["z_outstandingfees"];
		$this->outstandingfees->AdvancedSearch->SearchCondition = @$filter["v_outstandingfees"];
		$this->outstandingfees->AdvancedSearch->SearchValue2 = @$filter["y_outstandingfees"];
		$this->outstandingfees->AdvancedSearch->SearchOperator2 = @$filter["w_outstandingfees"];
		$this->outstandingfees->AdvancedSearch->save();

		// Field outstandingprincipleandfees
		$this->outstandingprincipleandfees->AdvancedSearch->SearchValue = @$filter["x_outstandingprincipleandfees"];
		$this->outstandingprincipleandfees->AdvancedSearch->SearchOperator = @$filter["z_outstandingprincipleandfees"];
		$this->outstandingprincipleandfees->AdvancedSearch->SearchCondition = @$filter["v_outstandingprincipleandfees"];
		$this->outstandingprincipleandfees->AdvancedSearch->SearchValue2 = @$filter["y_outstandingprincipleandfees"];
		$this->outstandingprincipleandfees->AdvancedSearch->SearchOperator2 = @$filter["w_outstandingprincipleandfees"];
		$this->outstandingprincipleandfees->AdvancedSearch->save();

		// Field lastupdate
		$this->lastupdate->AdvancedSearch->SearchValue = @$filter["x_lastupdate"];
		$this->lastupdate->AdvancedSearch->SearchOperator = @$filter["z_lastupdate"];
		$this->lastupdate->AdvancedSearch->SearchCondition = @$filter["v_lastupdate"];
		$this->lastupdate->AdvancedSearch->SearchValue2 = @$filter["y_lastupdate"];
		$this->lastupdate->AdvancedSearch->SearchOperator2 = @$filter["w_lastupdate"];
		$this->lastupdate->AdvancedSearch->save();

		// Field externalprovisioningrefno
		$this->externalprovisioningrefno->AdvancedSearch->SearchValue = @$filter["x_externalprovisioningrefno"];
		$this->externalprovisioningrefno->AdvancedSearch->SearchOperator = @$filter["z_externalprovisioningrefno"];
		$this->externalprovisioningrefno->AdvancedSearch->SearchCondition = @$filter["v_externalprovisioningrefno"];
		$this->externalprovisioningrefno->AdvancedSearch->SearchValue2 = @$filter["y_externalprovisioningrefno"];
		$this->externalprovisioningrefno->AdvancedSearch->SearchOperator2 = @$filter["w_externalprovisioningrefno"];
		$this->externalprovisioningrefno->AdvancedSearch->save();

		// Field loantype
		$this->loantype->AdvancedSearch->SearchValue = @$filter["x_loantype"];
		$this->loantype->AdvancedSearch->SearchOperator = @$filter["z_loantype"];
		$this->loantype->AdvancedSearch->SearchCondition = @$filter["v_loantype"];
		$this->loantype->AdvancedSearch->SearchValue2 = @$filter["y_loantype"];
		$this->loantype->AdvancedSearch->SearchOperator2 = @$filter["w_loantype"];
		$this->loantype->AdvancedSearch->save();

		// Field numberofoutstandingdays
		$this->numberofoutstandingdays->AdvancedSearch->SearchValue = @$filter["x_numberofoutstandingdays"];
		$this->numberofoutstandingdays->AdvancedSearch->SearchOperator = @$filter["z_numberofoutstandingdays"];
		$this->numberofoutstandingdays->AdvancedSearch->SearchCondition = @$filter["v_numberofoutstandingdays"];
		$this->numberofoutstandingdays->AdvancedSearch->SearchValue2 = @$filter["y_numberofoutstandingdays"];
		$this->numberofoutstandingdays->AdvancedSearch->SearchOperator2 = @$filter["w_numberofoutstandingdays"];
		$this->numberofoutstandingdays->AdvancedSearch->save();

		// Field loandue
		$this->loandue->AdvancedSearch->SearchValue = @$filter["x_loandue"];
		$this->loandue->AdvancedSearch->SearchOperator = @$filter["z_loandue"];
		$this->loandue->AdvancedSearch->SearchCondition = @$filter["v_loandue"];
		$this->loandue->AdvancedSearch->SearchValue2 = @$filter["y_loandue"];
		$this->loandue->AdvancedSearch->SearchOperator2 = @$filter["w_loandue"];
		$this->loandue->AdvancedSearch->save();

		// Field loanduedate
		$this->loanduedate->AdvancedSearch->SearchValue = @$filter["x_loanduedate"];
		$this->loanduedate->AdvancedSearch->SearchOperator = @$filter["z_loanduedate"];
		$this->loanduedate->AdvancedSearch->SearchCondition = @$filter["v_loanduedate"];
		$this->loanduedate->AdvancedSearch->SearchValue2 = @$filter["y_loanduedate"];
		$this->loanduedate->AdvancedSearch->SearchOperator2 = @$filter["w_loanduedate"];
		$this->loanduedate->AdvancedSearch->save();

		// Field outstandinglatefees
		$this->outstandinglatefees->AdvancedSearch->SearchValue = @$filter["x_outstandinglatefees"];
		$this->outstandinglatefees->AdvancedSearch->SearchOperator = @$filter["z_outstandinglatefees"];
		$this->outstandinglatefees->AdvancedSearch->SearchCondition = @$filter["v_outstandinglatefees"];
		$this->outstandinglatefees->AdvancedSearch->SearchValue2 = @$filter["y_outstandinglatefees"];
		$this->outstandinglatefees->AdvancedSearch->SearchOperator2 = @$filter["w_outstandinglatefees"];
		$this->outstandinglatefees->AdvancedSearch->save();

		// Field disbursementtype
		$this->disbursementtype->AdvancedSearch->SearchValue = @$filter["x_disbursementtype"];
		$this->disbursementtype->AdvancedSearch->SearchOperator = @$filter["z_disbursementtype"];
		$this->disbursementtype->AdvancedSearch->SearchCondition = @$filter["v_disbursementtype"];
		$this->disbursementtype->AdvancedSearch->SearchValue2 = @$filter["y_disbursementtype"];
		$this->disbursementtype->AdvancedSearch->SearchOperator2 = @$filter["w_disbursementtype"];
		$this->disbursementtype->AdvancedSearch->save();

		// Field disbursementamount
		$this->disbursementamount->AdvancedSearch->SearchValue = @$filter["x_disbursementamount"];
		$this->disbursementamount->AdvancedSearch->SearchOperator = @$filter["z_disbursementamount"];
		$this->disbursementamount->AdvancedSearch->SearchCondition = @$filter["v_disbursementamount"];
		$this->disbursementamount->AdvancedSearch->SearchValue2 = @$filter["y_disbursementamount"];
		$this->disbursementamount->AdvancedSearch->SearchOperator2 = @$filter["w_disbursementamount"];
		$this->disbursementamount->AdvancedSearch->save();

		// Field loanconfirmed
		$this->loanconfirmed->AdvancedSearch->SearchValue = @$filter["x_loanconfirmed"];
		$this->loanconfirmed->AdvancedSearch->SearchOperator = @$filter["z_loanconfirmed"];
		$this->loanconfirmed->AdvancedSearch->SearchCondition = @$filter["v_loanconfirmed"];
		$this->loanconfirmed->AdvancedSearch->SearchValue2 = @$filter["y_loanconfirmed"];
		$this->loanconfirmed->AdvancedSearch->SearchOperator2 = @$filter["w_loanconfirmed"];
		$this->loanconfirmed->AdvancedSearch->save();

		// Field loanconfirmedtime
		$this->loanconfirmedtime->AdvancedSearch->SearchValue = @$filter["x_loanconfirmedtime"];
		$this->loanconfirmedtime->AdvancedSearch->SearchOperator = @$filter["z_loanconfirmedtime"];
		$this->loanconfirmedtime->AdvancedSearch->SearchCondition = @$filter["v_loanconfirmedtime"];
		$this->loanconfirmedtime->AdvancedSearch->SearchValue2 = @$filter["y_loanconfirmedtime"];
		$this->loanconfirmedtime->AdvancedSearch->SearchOperator2 = @$filter["w_loanconfirmedtime"];
		$this->loanconfirmedtime->AdvancedSearch->save();

		// Field loanupgraded
		$this->loanupgraded->AdvancedSearch->SearchValue = @$filter["x_loanupgraded"];
		$this->loanupgraded->AdvancedSearch->SearchOperator = @$filter["z_loanupgraded"];
		$this->loanupgraded->AdvancedSearch->SearchCondition = @$filter["v_loanupgraded"];
		$this->loanupgraded->AdvancedSearch->SearchValue2 = @$filter["y_loanupgraded"];
		$this->loanupgraded->AdvancedSearch->SearchOperator2 = @$filter["w_loanupgraded"];
		$this->loanupgraded->AdvancedSearch->save();

		// Field stoplatefee
		$this->stoplatefee->AdvancedSearch->SearchValue = @$filter["x_stoplatefee"];
		$this->stoplatefee->AdvancedSearch->SearchOperator = @$filter["z_stoplatefee"];
		$this->stoplatefee->AdvancedSearch->SearchCondition = @$filter["v_stoplatefee"];
		$this->stoplatefee->AdvancedSearch->SearchValue2 = @$filter["y_stoplatefee"];
		$this->stoplatefee->AdvancedSearch->SearchOperator2 = @$filter["w_stoplatefee"];
		$this->stoplatefee->AdvancedSearch->save();

		// Field otherdetails1
		$this->otherdetails1->AdvancedSearch->SearchValue = @$filter["x_otherdetails1"];
		$this->otherdetails1->AdvancedSearch->SearchOperator = @$filter["z_otherdetails1"];
		$this->otherdetails1->AdvancedSearch->SearchCondition = @$filter["v_otherdetails1"];
		$this->otherdetails1->AdvancedSearch->SearchValue2 = @$filter["y_otherdetails1"];
		$this->otherdetails1->AdvancedSearch->SearchOperator2 = @$filter["w_otherdetails1"];
		$this->otherdetails1->AdvancedSearch->save();

		// Field lockflag
		$this->lockflag->AdvancedSearch->SearchValue = @$filter["x_lockflag"];
		$this->lockflag->AdvancedSearch->SearchOperator = @$filter["z_lockflag"];
		$this->lockflag->AdvancedSearch->SearchCondition = @$filter["v_lockflag"];
		$this->lockflag->AdvancedSearch->SearchValue2 = @$filter["y_lockflag"];
		$this->lockflag->AdvancedSearch->SearchOperator2 = @$filter["w_lockflag"];
		$this->lockflag->AdvancedSearch->save();

		// Field lastlatefeecalculatedate
		$this->lastlatefeecalculatedate->AdvancedSearch->SearchValue = @$filter["x_lastlatefeecalculatedate"];
		$this->lastlatefeecalculatedate->AdvancedSearch->SearchOperator = @$filter["z_lastlatefeecalculatedate"];
		$this->lastlatefeecalculatedate->AdvancedSearch->SearchCondition = @$filter["v_lastlatefeecalculatedate"];
		$this->lastlatefeecalculatedate->AdvancedSearch->SearchValue2 = @$filter["y_lastlatefeecalculatedate"];
		$this->lastlatefeecalculatedate->AdvancedSearch->SearchOperator2 = @$filter["w_lastlatefeecalculatedate"];
		$this->lastlatefeecalculatedate->AdvancedSearch->save();

		// Field notificationlockflag
		$this->notificationlockflag->AdvancedSearch->SearchValue = @$filter["x_notificationlockflag"];
		$this->notificationlockflag->AdvancedSearch->SearchOperator = @$filter["z_notificationlockflag"];
		$this->notificationlockflag->AdvancedSearch->SearchCondition = @$filter["v_notificationlockflag"];
		$this->notificationlockflag->AdvancedSearch->SearchValue2 = @$filter["y_notificationlockflag"];
		$this->notificationlockflag->AdvancedSearch->SearchOperator2 = @$filter["w_notificationlockflag"];
		$this->notificationlockflag->AdvancedSearch->save();

		// Field lastnotificationdate
		$this->lastnotificationdate->AdvancedSearch->SearchValue = @$filter["x_lastnotificationdate"];
		$this->lastnotificationdate->AdvancedSearch->SearchOperator = @$filter["z_lastnotificationdate"];
		$this->lastnotificationdate->AdvancedSearch->SearchCondition = @$filter["v_lastnotificationdate"];
		$this->lastnotificationdate->AdvancedSearch->SearchValue2 = @$filter["y_lastnotificationdate"];
		$this->lastnotificationdate->AdvancedSearch->SearchOperator2 = @$filter["w_lastnotificationdate"];
		$this->lastnotificationdate->AdvancedSearch->save();

		// Field sendnotificationtextdate
		$this->sendnotificationtextdate->AdvancedSearch->SearchValue = @$filter["x_sendnotificationtextdate"];
		$this->sendnotificationtextdate->AdvancedSearch->SearchOperator = @$filter["z_sendnotificationtextdate"];
		$this->sendnotificationtextdate->AdvancedSearch->SearchCondition = @$filter["v_sendnotificationtextdate"];
		$this->sendnotificationtextdate->AdvancedSearch->SearchValue2 = @$filter["y_sendnotificationtextdate"];
		$this->sendnotificationtextdate->AdvancedSearch->SearchOperator2 = @$filter["w_sendnotificationtextdate"];
		$this->sendnotificationtextdate->AdvancedSearch->save();

		// Field termtype
		$this->termtype->AdvancedSearch->SearchValue = @$filter["x_termtype"];
		$this->termtype->AdvancedSearch->SearchOperator = @$filter["z_termtype"];
		$this->termtype->AdvancedSearch->SearchCondition = @$filter["v_termtype"];
		$this->termtype->AdvancedSearch->SearchValue2 = @$filter["y_termtype"];
		$this->termtype->AdvancedSearch->SearchOperator2 = @$filter["w_termtype"];
		$this->termtype->AdvancedSearch->save();
	}

	// Advanced search WHERE clause based on QueryString
	protected function advancedSearchWhere($default = FALSE)
	{
		global $Security;
		$where = "";
		if (!$Security->canSearch())
			return "";
		$this->buildSearchSql($where, $this->loanid, $default, FALSE); // loanid
		$this->buildSearchSql($where, $this->_userid, $default, FALSE); // userid
		$this->buildSearchSql($where, $this->issueddate, $default, FALSE); // issueddate
		$this->buildSearchSql($where, $this->currcode, $default, FALSE); // currcode
		$this->buildSearchSql($where, $this->issuedamount, $default, FALSE); // issuedamount
		$this->buildSearchSql($where, $this->externalrefno, $default, FALSE); // externalrefno
		$this->buildSearchSql($where, $this->fullypaidind, $default, FALSE); // fullypaidind
		$this->buildSearchSql($where, $this->bankcode, $default, FALSE); // bankcode
		$this->buildSearchSql($where, $this->feeperc, $default, FALSE); // feeperc
		$this->buildSearchSql($where, $this->feeamount, $default, FALSE); // feeamount
		$this->buildSearchSql($where, $this->taxperc, $default, FALSE); // taxperc
		$this->buildSearchSql($where, $this->taxamount, $default, FALSE); // taxamount
		$this->buildSearchSql($where, $this->totalamount, $default, FALSE); // totalamount
		$this->buildSearchSql($where, $this->paymenttargetdate, $default, FALSE); // paymenttargetdate
		$this->buildSearchSql($where, $this->feefixed, $default, FALSE); // feefixed
		$this->buildSearchSql($where, $this->totalfees, $default, FALSE); // totalfees
		$this->buildSearchSql($where, $this->approveruserid, $default, FALSE); // approveruserid
		$this->buildSearchSql($where, $this->docid, $default, FALSE); // docid
		$this->buildSearchSql($where, $this->feesystemtotal, $default, FALSE); // feesystemtotal
		$this->buildSearchSql($where, $this->feeexternaltotal, $default, FALSE); // feeexternaltotal
		$this->buildSearchSql($where, $this->feefranchiseetotal, $default, FALSE); // feefranchiseetotal
		$this->buildSearchSql($where, $this->feeresellertotal, $default, FALSE); // feeresellertotal
		$this->buildSearchSql($where, $this->purchasefeeid, $default, FALSE); // purchasefeeid
		$this->buildSearchSql($where, $this->cancellationrefid, $default, FALSE); // cancellationrefid
		$this->buildSearchSql($where, $this->cancellationdatetime, $default, FALSE); // cancellationdatetime
		$this->buildSearchSql($where, $this->cancellationreason, $default, FALSE); // cancellationreason
		$this->buildSearchSql($where, $this->lastupdatedate, $default, FALSE); // lastupdatedate
		$this->buildSearchSql($where, $this->feeexternaltotaltime, $default, FALSE); // feeexternaltotaltime
		$this->buildSearchSql($where, $this->totalamountapplied, $default, FALSE); // totalamountapplied
		$this->buildSearchSql($where, $this->totalfeesapplied, $default, FALSE); // totalfeesapplied
		$this->buildSearchSql($where, $this->totalprincipleandfees, $default, FALSE); // totalprincipleandfees
		$this->buildSearchSql($where, $this->taxamountbreakdown, $default, FALSE); // taxamountbreakdown
		$this->buildSearchSql($where, $this->feesystembreakdown, $default, FALSE); // feesystembreakdown
		$this->buildSearchSql($where, $this->feeexternalbreakdown, $default, FALSE); // feeexternalbreakdown
		$this->buildSearchSql($where, $this->feefranchiseebreakdown, $default, FALSE); // feefranchiseebreakdown
		$this->buildSearchSql($where, $this->feeresellerbreakdown, $default, FALSE); // feeresellerbreakdown
		$this->buildSearchSql($where, $this->outstandingprinciple, $default, FALSE); // outstandingprinciple
		$this->buildSearchSql($where, $this->outstandingfees, $default, FALSE); // outstandingfees
		$this->buildSearchSql($where, $this->outstandingprincipleandfees, $default, FALSE); // outstandingprincipleandfees
		$this->buildSearchSql($where, $this->lastupdate, $default, FALSE); // lastupdate
		$this->buildSearchSql($where, $this->externalprovisioningrefno, $default, FALSE); // externalprovisioningrefno
		$this->buildSearchSql($where, $this->loantype, $default, FALSE); // loantype
		$this->buildSearchSql($where, $this->numberofoutstandingdays, $default, FALSE); // numberofoutstandingdays
		$this->buildSearchSql($where, $this->loandue, $default, FALSE); // loandue
		$this->buildSearchSql($where, $this->loanduedate, $default, FALSE); // loanduedate
		$this->buildSearchSql($where, $this->outstandinglatefees, $default, FALSE); // outstandinglatefees
		$this->buildSearchSql($where, $this->disbursementtype, $default, FALSE); // disbursementtype
		$this->buildSearchSql($where, $this->disbursementamount, $default, FALSE); // disbursementamount
		$this->buildSearchSql($where, $this->loanconfirmed, $default, FALSE); // loanconfirmed
		$this->buildSearchSql($where, $this->loanconfirmedtime, $default, FALSE); // loanconfirmedtime
		$this->buildSearchSql($where, $this->loanupgraded, $default, FALSE); // loanupgraded
		$this->buildSearchSql($where, $this->stoplatefee, $default, FALSE); // stoplatefee
		$this->buildSearchSql($where, $this->otherdetails1, $default, FALSE); // otherdetails1
		$this->buildSearchSql($where, $this->lockflag, $default, FALSE); // lockflag
		$this->buildSearchSql($where, $this->lastlatefeecalculatedate, $default, FALSE); // lastlatefeecalculatedate
		$this->buildSearchSql($where, $this->notificationlockflag, $default, FALSE); // notificationlockflag
		$this->buildSearchSql($where, $this->lastnotificationdate, $default, FALSE); // lastnotificationdate
		$this->buildSearchSql($where, $this->sendnotificationtextdate, $default, FALSE); // sendnotificationtextdate
		$this->buildSearchSql($where, $this->termtype, $default, FALSE); // termtype

		// Set up search parm
		if (!$default && $where != "" && in_array($this->Command, ["", "reset", "resetall"])) {
			$this->Command = "search";
		}
		if (!$default && $this->Command == "search") {
			$this->loanid->AdvancedSearch->save(); // loanid
			$this->_userid->AdvancedSearch->save(); // userid
			$this->issueddate->AdvancedSearch->save(); // issueddate
			$this->currcode->AdvancedSearch->save(); // currcode
			$this->issuedamount->AdvancedSearch->save(); // issuedamount
			$this->externalrefno->AdvancedSearch->save(); // externalrefno
			$this->fullypaidind->AdvancedSearch->save(); // fullypaidind
			$this->bankcode->AdvancedSearch->save(); // bankcode
			$this->feeperc->AdvancedSearch->save(); // feeperc
			$this->feeamount->AdvancedSearch->save(); // feeamount
			$this->taxperc->AdvancedSearch->save(); // taxperc
			$this->taxamount->AdvancedSearch->save(); // taxamount
			$this->totalamount->AdvancedSearch->save(); // totalamount
			$this->paymenttargetdate->AdvancedSearch->save(); // paymenttargetdate
			$this->feefixed->AdvancedSearch->save(); // feefixed
			$this->totalfees->AdvancedSearch->save(); // totalfees
			$this->approveruserid->AdvancedSearch->save(); // approveruserid
			$this->docid->AdvancedSearch->save(); // docid
			$this->feesystemtotal->AdvancedSearch->save(); // feesystemtotal
			$this->feeexternaltotal->AdvancedSearch->save(); // feeexternaltotal
			$this->feefranchiseetotal->AdvancedSearch->save(); // feefranchiseetotal
			$this->feeresellertotal->AdvancedSearch->save(); // feeresellertotal
			$this->purchasefeeid->AdvancedSearch->save(); // purchasefeeid
			$this->cancellationrefid->AdvancedSearch->save(); // cancellationrefid
			$this->cancellationdatetime->AdvancedSearch->save(); // cancellationdatetime
			$this->cancellationreason->AdvancedSearch->save(); // cancellationreason
			$this->lastupdatedate->AdvancedSearch->save(); // lastupdatedate
			$this->feeexternaltotaltime->AdvancedSearch->save(); // feeexternaltotaltime
			$this->totalamountapplied->AdvancedSearch->save(); // totalamountapplied
			$this->totalfeesapplied->AdvancedSearch->save(); // totalfeesapplied
			$this->totalprincipleandfees->AdvancedSearch->save(); // totalprincipleandfees
			$this->taxamountbreakdown->AdvancedSearch->save(); // taxamountbreakdown
			$this->feesystembreakdown->AdvancedSearch->save(); // feesystembreakdown
			$this->feeexternalbreakdown->AdvancedSearch->save(); // feeexternalbreakdown
			$this->feefranchiseebreakdown->AdvancedSearch->save(); // feefranchiseebreakdown
			$this->feeresellerbreakdown->AdvancedSearch->save(); // feeresellerbreakdown
			$this->outstandingprinciple->AdvancedSearch->save(); // outstandingprinciple
			$this->outstandingfees->AdvancedSearch->save(); // outstandingfees
			$this->outstandingprincipleandfees->AdvancedSearch->save(); // outstandingprincipleandfees
			$this->lastupdate->AdvancedSearch->save(); // lastupdate
			$this->externalprovisioningrefno->AdvancedSearch->save(); // externalprovisioningrefno
			$this->loantype->AdvancedSearch->save(); // loantype
			$this->numberofoutstandingdays->AdvancedSearch->save(); // numberofoutstandingdays
			$this->loandue->AdvancedSearch->save(); // loandue
			$this->loanduedate->AdvancedSearch->save(); // loanduedate
			$this->outstandinglatefees->AdvancedSearch->save(); // outstandinglatefees
			$this->disbursementtype->AdvancedSearch->save(); // disbursementtype
			$this->disbursementamount->AdvancedSearch->save(); // disbursementamount
			$this->loanconfirmed->AdvancedSearch->save(); // loanconfirmed
			$this->loanconfirmedtime->AdvancedSearch->save(); // loanconfirmedtime
			$this->loanupgraded->AdvancedSearch->save(); // loanupgraded
			$this->stoplatefee->AdvancedSearch->save(); // stoplatefee
			$this->otherdetails1->AdvancedSearch->save(); // otherdetails1
			$this->lockflag->AdvancedSearch->save(); // lockflag
			$this->lastlatefeecalculatedate->AdvancedSearch->save(); // lastlatefeecalculatedate
			$this->notificationlockflag->AdvancedSearch->save(); // notificationlockflag
			$this->lastnotificationdate->AdvancedSearch->save(); // lastnotificationdate
			$this->sendnotificationtextdate->AdvancedSearch->save(); // sendnotificationtextdate
			$this->termtype->AdvancedSearch->save(); // termtype
		}
		return $where;
	}

	// Build search SQL
	protected function buildSearchSql(&$where, &$fld, $default, $multiValue)
	{
		$fldParm = $fld->Param;
		$fldVal = ($default) ? $fld->AdvancedSearch->SearchValueDefault : $fld->AdvancedSearch->SearchValue;
		$fldOpr = ($default) ? $fld->AdvancedSearch->SearchOperatorDefault : $fld->AdvancedSearch->SearchOperator;
		$fldCond = ($default) ? $fld->AdvancedSearch->SearchConditionDefault : $fld->AdvancedSearch->SearchCondition;
		$fldVal2 = ($default) ? $fld->AdvancedSearch->SearchValue2Default : $fld->AdvancedSearch->SearchValue2;
		$fldOpr2 = ($default) ? $fld->AdvancedSearch->SearchOperator2Default : $fld->AdvancedSearch->SearchOperator2;
		$wrk = "";
		if (is_array($fldVal))
			$fldVal = implode(Config("MULTIPLE_OPTION_SEPARATOR"), $fldVal);
		if (is_array($fldVal2))
			$fldVal2 = implode(Config("MULTIPLE_OPTION_SEPARATOR"), $fldVal2);
		$fldOpr = strtoupper(trim($fldOpr));
		if ($fldOpr == "")
			$fldOpr = "=";
		$fldOpr2 = strtoupper(trim($fldOpr2));
		if ($fldOpr2 == "")
			$fldOpr2 = "=";
		if (Config("SEARCH_MULTI_VALUE_OPTION") == 1 || !IsMultiSearchOperator($fldOpr))
			$multiValue = FALSE;
		if ($multiValue) {
			$wrk1 = ($fldVal != "") ? GetMultiSearchSql($fld, $fldOpr, $fldVal, $this->Dbid) : ""; // Field value 1
			$wrk2 = ($fldVal2 != "") ? GetMultiSearchSql($fld, $fldOpr2, $fldVal2, $this->Dbid) : ""; // Field value 2
			$wrk = $wrk1; // Build final SQL
			if ($wrk2 != "")
				$wrk = ($wrk != "") ? "($wrk) $fldCond ($wrk2)" : $wrk2;
		} else {
			$fldVal = $this->convertSearchValue($fld, $fldVal);
			$fldVal2 = $this->convertSearchValue($fld, $fldVal2);
			$wrk = GetSearchSql($fld, $fldVal, $fldOpr, $fldCond, $fldVal2, $fldOpr2, $this->Dbid);
		}
		AddFilter($where, $wrk);
	}

	// Convert search value
	protected function convertSearchValue(&$fld, $fldVal)
	{
		if ($fldVal == Config("NULL_VALUE") || $fldVal == Config("NOT_NULL_VALUE"))
			return $fldVal;
		$value = $fldVal;
		if ($fld->isBoolean()) {
			if ($fldVal != "")
				$value = (SameText($fldVal, "1") || SameText($fldVal, "y") || SameText($fldVal, "t")) ? $fld->TrueValue : $fld->FalseValue;
		} elseif ($fld->DataType == DATATYPE_DATE || $fld->DataType == DATATYPE_TIME) {
			if ($fldVal != "")
				$value = UnFormatDateTime($fldVal, $fld->DateTimeFormat);
		}
		return $value;
	}

	// Check if search parm exists
	protected function checkSearchParms()
	{
		if ($this->loanid->AdvancedSearch->issetSession())
			return TRUE;
		if ($this->_userid->AdvancedSearch->issetSession())
			return TRUE;
		if ($this->issueddate->AdvancedSearch->issetSession())
			return TRUE;
		if ($this->currcode->AdvancedSearch->issetSession())
			return TRUE;
		if ($this->issuedamount->AdvancedSearch->issetSession())
			return TRUE;
		if ($this->externalrefno->AdvancedSearch->issetSession())
			return TRUE;
		if ($this->fullypaidind->AdvancedSearch->issetSession())
			return TRUE;
		if ($this->bankcode->AdvancedSearch->issetSession())
			return TRUE;
		if ($this->feeperc->AdvancedSearch->issetSession())
			return TRUE;
		if ($this->feeamount->AdvancedSearch->issetSession())
			return TRUE;
		if ($this->taxperc->AdvancedSearch->issetSession())
			return TRUE;
		if ($this->taxamount->AdvancedSearch->issetSession())
			return TRUE;
		if ($this->totalamount->AdvancedSearch->issetSession())
			return TRUE;
		if ($this->paymenttargetdate->AdvancedSearch->issetSession())
			return TRUE;
		if ($this->feefixed->AdvancedSearch->issetSession())
			return TRUE;
		if ($this->totalfees->AdvancedSearch->issetSession())
			return TRUE;
		if ($this->approveruserid->AdvancedSearch->issetSession())
			return TRUE;
		if ($this->docid->AdvancedSearch->issetSession())
			return TRUE;
		if ($this->feesystemtotal->AdvancedSearch->issetSession())
			return TRUE;
		if ($this->feeexternaltotal->AdvancedSearch->issetSession())
			return TRUE;
		if ($this->feefranchiseetotal->AdvancedSearch->issetSession())
			return TRUE;
		if ($this->feeresellertotal->AdvancedSearch->issetSession())
			return TRUE;
		if ($this->purchasefeeid->AdvancedSearch->issetSession())
			return TRUE;
		if ($this->cancellationrefid->AdvancedSearch->issetSession())
			return TRUE;
		if ($this->cancellationdatetime->AdvancedSearch->issetSession())
			return TRUE;
		if ($this->cancellationreason->AdvancedSearch->issetSession())
			return TRUE;
		if ($this->lastupdatedate->AdvancedSearch->issetSession())
			return TRUE;
		if ($this->feeexternaltotaltime->AdvancedSearch->issetSession())
			return TRUE;
		if ($this->totalamountapplied->AdvancedSearch->issetSession())
			return TRUE;
		if ($this->totalfeesapplied->AdvancedSearch->issetSession())
			return TRUE;
		if ($this->totalprincipleandfees->AdvancedSearch->issetSession())
			return TRUE;
		if ($this->taxamountbreakdown->AdvancedSearch->issetSession())
			return TRUE;
		if ($this->feesystembreakdown->AdvancedSearch->issetSession())
			return TRUE;
		if ($this->feeexternalbreakdown->AdvancedSearch->issetSession())
			return TRUE;
		if ($this->feefranchiseebreakdown->AdvancedSearch->issetSession())
			return TRUE;
		if ($this->feeresellerbreakdown->AdvancedSearch->issetSession())
			return TRUE;
		if ($this->outstandingprinciple->AdvancedSearch->issetSession())
			return TRUE;
		if ($this->outstandingfees->AdvancedSearch->issetSession())
			return TRUE;
		if ($this->outstandingprincipleandfees->AdvancedSearch->issetSession())
			return TRUE;
		if ($this->lastupdate->AdvancedSearch->issetSession())
			return TRUE;
		if ($this->externalprovisioningrefno->AdvancedSearch->issetSession())
			return TRUE;
		if ($this->loantype->AdvancedSearch->issetSession())
			return TRUE;
		if ($this->numberofoutstandingdays->AdvancedSearch->issetSession())
			return TRUE;
		if ($this->loandue->AdvancedSearch->issetSession())
			return TRUE;
		if ($this->loanduedate->AdvancedSearch->issetSession())
			return TRUE;
		if ($this->outstandinglatefees->AdvancedSearch->issetSession())
			return TRUE;
		if ($this->disbursementtype->AdvancedSearch->issetSession())
			return TRUE;
		if ($this->disbursementamount->AdvancedSearch->issetSession())
			return TRUE;
		if ($this->loanconfirmed->AdvancedSearch->issetSession())
			return TRUE;
		if ($this->loanconfirmedtime->AdvancedSearch->issetSession())
			return TRUE;
		if ($this->loanupgraded->AdvancedSearch->issetSession())
			return TRUE;
		if ($this->stoplatefee->AdvancedSearch->issetSession())
			return TRUE;
		if ($this->otherdetails1->AdvancedSearch->issetSession())
			return TRUE;
		if ($this->lockflag->AdvancedSearch->issetSession())
			return TRUE;
		if ($this->lastlatefeecalculatedate->AdvancedSearch->issetSession())
			return TRUE;
		if ($this->notificationlockflag->AdvancedSearch->issetSession())
			return TRUE;
		if ($this->lastnotificationdate->AdvancedSearch->issetSession())
			return TRUE;
		if ($this->sendnotificationtextdate->AdvancedSearch->issetSession())
			return TRUE;
		if ($this->termtype->AdvancedSearch->issetSession())
			return TRUE;
		return FALSE;
	}

	// Clear all search parameters
	protected function resetSearchParms()
	{

		// Clear search WHERE clause
		$this->SearchWhere = "";
		$this->setSearchWhere($this->SearchWhere);

		// Clear advanced search parameters
		$this->resetAdvancedSearchParms();
	}

	// Load advanced search default values
	protected function loadAdvancedSearchDefault()
	{
		return FALSE;
	}

	// Clear all advanced search parameters
	protected function resetAdvancedSearchParms()
	{
		$this->loanid->AdvancedSearch->unsetSession();
		$this->_userid->AdvancedSearch->unsetSession();
		$this->issueddate->AdvancedSearch->unsetSession();
		$this->currcode->AdvancedSearch->unsetSession();
		$this->issuedamount->AdvancedSearch->unsetSession();
		$this->externalrefno->AdvancedSearch->unsetSession();
		$this->fullypaidind->AdvancedSearch->unsetSession();
		$this->bankcode->AdvancedSearch->unsetSession();
		$this->feeperc->AdvancedSearch->unsetSession();
		$this->feeamount->AdvancedSearch->unsetSession();
		$this->taxperc->AdvancedSearch->unsetSession();
		$this->taxamount->AdvancedSearch->unsetSession();
		$this->totalamount->AdvancedSearch->unsetSession();
		$this->paymenttargetdate->AdvancedSearch->unsetSession();
		$this->feefixed->AdvancedSearch->unsetSession();
		$this->totalfees->AdvancedSearch->unsetSession();
		$this->approveruserid->AdvancedSearch->unsetSession();
		$this->docid->AdvancedSearch->unsetSession();
		$this->feesystemtotal->AdvancedSearch->unsetSession();
		$this->feeexternaltotal->AdvancedSearch->unsetSession();
		$this->feefranchiseetotal->AdvancedSearch->unsetSession();
		$this->feeresellertotal->AdvancedSearch->unsetSession();
		$this->purchasefeeid->AdvancedSearch->unsetSession();
		$this->cancellationrefid->AdvancedSearch->unsetSession();
		$this->cancellationdatetime->AdvancedSearch->unsetSession();
		$this->cancellationreason->AdvancedSearch->unsetSession();
		$this->lastupdatedate->AdvancedSearch->unsetSession();
		$this->feeexternaltotaltime->AdvancedSearch->unsetSession();
		$this->totalamountapplied->AdvancedSearch->unsetSession();
		$this->totalfeesapplied->AdvancedSearch->unsetSession();
		$this->totalprincipleandfees->AdvancedSearch->unsetSession();
		$this->taxamountbreakdown->AdvancedSearch->unsetSession();
		$this->feesystembreakdown->AdvancedSearch->unsetSession();
		$this->feeexternalbreakdown->AdvancedSearch->unsetSession();
		$this->feefranchiseebreakdown->AdvancedSearch->unsetSession();
		$this->feeresellerbreakdown->AdvancedSearch->unsetSession();
		$this->outstandingprinciple->AdvancedSearch->unsetSession();
		$this->outstandingfees->AdvancedSearch->unsetSession();
		$this->outstandingprincipleandfees->AdvancedSearch->unsetSession();
		$this->lastupdate->AdvancedSearch->unsetSession();
		$this->externalprovisioningrefno->AdvancedSearch->unsetSession();
		$this->loantype->AdvancedSearch->unsetSession();
		$this->numberofoutstandingdays->AdvancedSearch->unsetSession();
		$this->loandue->AdvancedSearch->unsetSession();
		$this->loanduedate->AdvancedSearch->unsetSession();
		$this->outstandinglatefees->AdvancedSearch->unsetSession();
		$this->disbursementtype->AdvancedSearch->unsetSession();
		$this->disbursementamount->AdvancedSearch->unsetSession();
		$this->loanconfirmed->AdvancedSearch->unsetSession();
		$this->loanconfirmedtime->AdvancedSearch->unsetSession();
		$this->loanupgraded->AdvancedSearch->unsetSession();
		$this->stoplatefee->AdvancedSearch->unsetSession();
		$this->otherdetails1->AdvancedSearch->unsetSession();
		$this->lockflag->AdvancedSearch->unsetSession();
		$this->lastlatefeecalculatedate->AdvancedSearch->unsetSession();
		$this->notificationlockflag->AdvancedSearch->unsetSession();
		$this->lastnotificationdate->AdvancedSearch->unsetSession();
		$this->sendnotificationtextdate->AdvancedSearch->unsetSession();
		$this->termtype->AdvancedSearch->unsetSession();
	}

	// Restore all search parameters
	protected function restoreSearchParms()
	{
		$this->RestoreSearch = TRUE;

		// Restore advanced search values
		$this->loanid->AdvancedSearch->load();
		$this->_userid->AdvancedSearch->load();
		$this->issueddate->AdvancedSearch->load();
		$this->currcode->AdvancedSearch->load();
		$this->issuedamount->AdvancedSearch->load();
		$this->externalrefno->AdvancedSearch->load();
		$this->fullypaidind->AdvancedSearch->load();
		$this->bankcode->AdvancedSearch->load();
		$this->feeperc->AdvancedSearch->load();
		$this->feeamount->AdvancedSearch->load();
		$this->taxperc->AdvancedSearch->load();
		$this->taxamount->AdvancedSearch->load();
		$this->totalamount->AdvancedSearch->load();
		$this->paymenttargetdate->AdvancedSearch->load();
		$this->feefixed->AdvancedSearch->load();
		$this->totalfees->AdvancedSearch->load();
		$this->approveruserid->AdvancedSearch->load();
		$this->docid->AdvancedSearch->load();
		$this->feesystemtotal->AdvancedSearch->load();
		$this->feeexternaltotal->AdvancedSearch->load();
		$this->feefranchiseetotal->AdvancedSearch->load();
		$this->feeresellertotal->AdvancedSearch->load();
		$this->purchasefeeid->AdvancedSearch->load();
		$this->cancellationrefid->AdvancedSearch->load();
		$this->cancellationdatetime->AdvancedSearch->load();
		$this->cancellationreason->AdvancedSearch->load();
		$this->lastupdatedate->AdvancedSearch->load();
		$this->feeexternaltotaltime->AdvancedSearch->load();
		$this->totalamountapplied->AdvancedSearch->load();
		$this->totalfeesapplied->AdvancedSearch->load();
		$this->totalprincipleandfees->AdvancedSearch->load();
		$this->taxamountbreakdown->AdvancedSearch->load();
		$this->feesystembreakdown->AdvancedSearch->load();
		$this->feeexternalbreakdown->AdvancedSearch->load();
		$this->feefranchiseebreakdown->AdvancedSearch->load();
		$this->feeresellerbreakdown->AdvancedSearch->load();
		$this->outstandingprinciple->AdvancedSearch->load();
		$this->outstandingfees->AdvancedSearch->load();
		$this->outstandingprincipleandfees->AdvancedSearch->load();
		$this->lastupdate->AdvancedSearch->load();
		$this->externalprovisioningrefno->AdvancedSearch->load();
		$this->loantype->AdvancedSearch->load();
		$this->numberofoutstandingdays->AdvancedSearch->load();
		$this->loandue->AdvancedSearch->load();
		$this->loanduedate->AdvancedSearch->load();
		$this->outstandinglatefees->AdvancedSearch->load();
		$this->disbursementtype->AdvancedSearch->load();
		$this->disbursementamount->AdvancedSearch->load();
		$this->loanconfirmed->AdvancedSearch->load();
		$this->loanconfirmedtime->AdvancedSearch->load();
		$this->loanupgraded->AdvancedSearch->load();
		$this->stoplatefee->AdvancedSearch->load();
		$this->otherdetails1->AdvancedSearch->load();
		$this->lockflag->AdvancedSearch->load();
		$this->lastlatefeecalculatedate->AdvancedSearch->load();
		$this->notificationlockflag->AdvancedSearch->load();
		$this->lastnotificationdate->AdvancedSearch->load();
		$this->sendnotificationtextdate->AdvancedSearch->load();
		$this->termtype->AdvancedSearch->load();
	}

	// Set up sort parameters
	protected function setupSortOrder()
	{

		// Check for "order" parameter
		if (Get("order") !== NULL) {
			$this->CurrentOrder = Get("order");
			$this->CurrentOrderType = Get("ordertype", "");
			$this->updateSort($this->loanid); // loanid
			$this->updateSort($this->_userid); // userid
			$this->updateSort($this->issueddate); // issueddate
			$this->updateSort($this->currcode); // currcode
			$this->updateSort($this->fullypaidind); // fullypaidind
			$this->updateSort($this->loanconfirmed); // loanconfirmed
			$this->updateSort($this->termtype); // termtype
			$this->setStartRecordNumber(1); // Reset start position
		}
	}

	// Load sort order parameters
	protected function loadSortOrder()
	{
		$orderBy = $this->getSessionOrderBy(); // Get ORDER BY from Session
		if ($orderBy == "") {
			if ($this->getSqlOrderBy() != "") {
				$orderBy = $this->getSqlOrderBy();
				$this->setSessionOrderBy($orderBy);
				$this->issueddate->setSort("DESC");
			}
		}
	}

	// Reset command
	// - cmd=reset (Reset search parameters)
	// - cmd=resetall (Reset search and master/detail parameters)
	// - cmd=resetsort (Reset sort parameters)

	protected function resetCmd()
	{

		// Check if reset command
		if (StartsString("reset", $this->Command)) {

			// Reset search criteria
			if ($this->Command == "reset" || $this->Command == "resetall")
				$this->resetSearchParms();

			// Reset master/detail keys
			if ($this->Command == "resetall") {
				$this->setCurrentMasterTable(""); // Clear master table
				$this->DbMasterFilter = "";
				$this->DbDetailFilter = "";
				$this->loanid->setSessionValue("");
				$this->loanid->setSessionValue("");
				$this->_userid->setSessionValue("");
				$this->currcode->setSessionValue("");
			}

			// Reset sorting order
			if ($this->Command == "resetsort") {
				$orderBy = "";
				$this->setSessionOrderBy($orderBy);
				$this->loanid->setSort("");
				$this->_userid->setSort("");
				$this->issueddate->setSort("");
				$this->currcode->setSort("");
				$this->fullypaidind->setSort("");
				$this->loanconfirmed->setSort("");
				$this->termtype->setSort("");
			}

			// Reset start position
			$this->StartRecord = 1;
			$this->setStartRecordNumber($this->StartRecord);
		}
	}

	// Set up list options
	protected function setupListOptions()
	{
		global $Security, $Language;

		// Add group option item
		$item = &$this->ListOptions->add($this->ListOptions->GroupOptionName);
		$item->Body = "";
		$item->OnLeft = FALSE;
		$item->Visible = FALSE;

		// "view"
		$item = &$this->ListOptions->add("view");
		$item->CssClass = "text-nowrap";
		$item->Visible = $Security->canView();
		$item->OnLeft = FALSE;

		// "edit"
		$item = &$this->ListOptions->add("edit");
		$item->CssClass = "text-nowrap";
		$item->Visible = $Security->canEdit();
		$item->OnLeft = FALSE;

		// "copy"
		$item = &$this->ListOptions->add("copy");
		$item->CssClass = "text-nowrap";
		$item->Visible = $Security->canAdd();
		$item->OnLeft = FALSE;

		// "delete"
		$item = &$this->ListOptions->add("delete");
		$item->CssClass = "text-nowrap";
		$item->Visible = $Security->canDelete();
		$item->OnLeft = FALSE;

		// "detail_loanissuedupgrades"
		$item = &$this->ListOptions->add("detail_loanissuedupgrades");
		$item->CssClass = "text-nowrap";
		$item->Visible = $Security->allowList(CurrentProjectID() . 'loanissuedupgrades') && !$this->ShowMultipleDetails;
		$item->OnLeft = FALSE;
		$item->ShowInButtonGroup = FALSE;
		if (!isset($GLOBALS["loanissuedupgrades_grid"]))
			$GLOBALS["loanissuedupgrades_grid"] = new loanissuedupgrades_grid();

		// "detail_loaneventhistory"
		$item = &$this->ListOptions->add("detail_loaneventhistory");
		$item->CssClass = "text-nowrap";
		$item->Visible = $Security->allowList(CurrentProjectID() . 'loaneventhistory') && !$this->ShowMultipleDetails;
		$item->OnLeft = FALSE;
		$item->ShowInButtonGroup = FALSE;
		if (!isset($GLOBALS["loaneventhistory_grid"]))
			$GLOBALS["loaneventhistory_grid"] = new loaneventhistory_grid();

		// "detail_loanlatefees"
		$item = &$this->ListOptions->add("detail_loanlatefees");
		$item->CssClass = "text-nowrap";
		$item->Visible = $Security->allowList(CurrentProjectID() . 'loanlatefees') && !$this->ShowMultipleDetails;
		$item->OnLeft = FALSE;
		$item->ShowInButtonGroup = FALSE;
		if (!isset($GLOBALS["loanlatefees_grid"]))
			$GLOBALS["loanlatefees_grid"] = new loanlatefees_grid();

		// "detail_loanapplied"
		$item = &$this->ListOptions->add("detail_loanapplied");
		$item->CssClass = "text-nowrap";
		$item->Visible = $Security->allowList(CurrentProjectID() . 'loanapplied') && !$this->ShowMultipleDetails;
		$item->OnLeft = FALSE;
		$item->ShowInButtonGroup = FALSE;
		if (!isset($GLOBALS["loanapplied_grid"]))
			$GLOBALS["loanapplied_grid"] = new loanapplied_grid();

		// "detail_loanpayments"
		$item = &$this->ListOptions->add("detail_loanpayments");
		$item->CssClass = "text-nowrap";
		$item->Visible = $Security->allowList(CurrentProjectID() . 'loanpayments') && !$this->ShowMultipleDetails;
		$item->OnLeft = FALSE;
		$item->ShowInButtonGroup = FALSE;
		if (!isset($GLOBALS["loanpayments_grid"]))
			$GLOBALS["loanpayments_grid"] = new loanpayments_grid();

		// "detail_loanpaymentplan"
		$item = &$this->ListOptions->add("detail_loanpaymentplan");
		$item->CssClass = "text-nowrap";
		$item->Visible = $Security->allowList(CurrentProjectID() . 'loanpaymentplan') && !$this->ShowMultipleDetails;
		$item->OnLeft = FALSE;
		$item->ShowInButtonGroup = FALSE;
		if (!isset($GLOBALS["loanpaymentplan_grid"]))
			$GLOBALS["loanpaymentplan_grid"] = new loanpaymentplan_grid();

		// Multiple details
		if ($this->ShowMultipleDetails) {
			$item = &$this->ListOptions->add("details");
			$item->CssClass = "text-nowrap";
			$item->Visible = $this->ShowMultipleDetails;
			$item->OnLeft = FALSE;
			$item->ShowInButtonGroup = FALSE;
		}

		// Set up detail pages
		$pages = new SubPages();
		$pages->add("loanissuedupgrades");
		$pages->add("loaneventhistory");
		$pages->add("loanlatefees");
		$pages->add("loanapplied");
		$pages->add("loanpayments");
		$pages->add("loanpaymentplan");
		$this->DetailPages = $pages;

		// List actions
		$item = &$this->ListOptions->add("listactions");
		$item->CssClass = "text-nowrap";
		$item->OnLeft = FALSE;
		$item->Visible = FALSE;
		$item->ShowInButtonGroup = FALSE;
		$item->ShowInDropDown = FALSE;

		// "checkbox"
		$item = &$this->ListOptions->add("checkbox");
		$item->Visible = FALSE;
		$item->OnLeft = FALSE;
		$item->Header = "<div class=\"custom-control custom-checkbox d-inline-block\"><input type=\"checkbox\" name=\"key\" id=\"key\" class=\"custom-control-input\" onclick=\"ew.selectAllKey(this);\"><label class=\"custom-control-label\" for=\"key\"></label></div>";
		$item->ShowInDropDown = FALSE;
		$item->ShowInButtonGroup = FALSE;

		// Drop down button for ListOptions
		$this->ListOptions->UseDropDownButton = FALSE;
		$this->ListOptions->DropDownButtonPhrase = $Language->phrase("ButtonListOptions");
		$this->ListOptions->UseButtonGroup = FALSE;
		if ($this->ListOptions->UseButtonGroup && IsMobile())
			$this->ListOptions->UseDropDownButton = TRUE;

		//$this->ListOptions->ButtonClass = ""; // Class for button group
		// Call ListOptions_Load event

		$this->ListOptions_Load();
		$this->setupListOptionsExt();
		$item = $this->ListOptions[$this->ListOptions->GroupOptionName];
		$item->Visible = $this->ListOptions->groupOptionVisible();
	}

	// Render list options
	public function renderListOptions()
	{
		global $Security, $Language, $CurrentForm;
		$this->ListOptions->loadDefault();

		// Call ListOptions_Rendering event
		$this->ListOptions_Rendering();

		// "view"
		$opt = $this->ListOptions["view"];
		$viewcaption = HtmlTitle($Language->phrase("ViewLink"));
		if ($Security->canView()) {
			$opt->Body = "<a class=\"ew-row-link ew-view\" title=\"" . $viewcaption . "\" data-caption=\"" . $viewcaption . "\" href=\"" . HtmlEncode($this->ViewUrl) . "\">" . $Language->phrase("ViewLink") . "</a>";
		} else {
			$opt->Body = "";
		}

		// "edit"
		$opt = $this->ListOptions["edit"];
		$editcaption = HtmlTitle($Language->phrase("EditLink"));
		if ($Security->canEdit()) {
			$opt->Body = "<a class=\"ew-row-link ew-edit\" title=\"" . HtmlTitle($Language->phrase("EditLink")) . "\" data-caption=\"" . HtmlTitle($Language->phrase("EditLink")) . "\" href=\"" . HtmlEncode($this->EditUrl) . "\">" . $Language->phrase("EditLink") . "</a>";
		} else {
			$opt->Body = "";
		}

		// "copy"
		$opt = $this->ListOptions["copy"];
		$copycaption = HtmlTitle($Language->phrase("CopyLink"));
		if ($Security->canAdd()) {
			$opt->Body = "<a class=\"ew-row-link ew-copy\" title=\"" . $copycaption . "\" data-caption=\"" . $copycaption . "\" href=\"" . HtmlEncode($this->CopyUrl) . "\">" . $Language->phrase("CopyLink") . "</a>";
		} else {
			$opt->Body = "";
		}

		// "delete"
		$opt = $this->ListOptions["delete"];
		if ($Security->canDelete())
			$opt->Body = "<a class=\"ew-row-link ew-delete\"" . "" . " title=\"" . HtmlTitle($Language->phrase("DeleteLink")) . "\" data-caption=\"" . HtmlTitle($Language->phrase("DeleteLink")) . "\" href=\"" . HtmlEncode($this->DeleteUrl) . "\">" . $Language->phrase("DeleteLink") . "</a>";
		else
			$opt->Body = "";

		// Set up list action buttons
		$opt = $this->ListOptions["listactions"];
		if ($opt && !$this->isExport() && !$this->CurrentAction) {
			$body = "";
			$links = [];
			foreach ($this->ListActions->Items as $listaction) {
				if ($listaction->Select == ACTION_SINGLE && $listaction->Allow) {
					$action = $listaction->Action;
					$caption = $listaction->Caption;
					$icon = ($listaction->Icon != "") ? "<i class=\"" . HtmlEncode(str_replace(" ew-icon", "", $listaction->Icon)) . "\" data-caption=\"" . HtmlTitle($caption) . "\"></i> " : "";
					$links[] = "<li><a class=\"dropdown-item ew-action ew-list-action\" data-action=\"" . HtmlEncode($action) . "\" data-caption=\"" . HtmlTitle($caption) . "\" href=\"#\" onclick=\"return ew.submitAction(event,jQuery.extend({key:" . $this->keyToJson(TRUE) . "}," . $listaction->toJson(TRUE) . "));\">" . $icon . $listaction->Caption . "</a></li>";
					if (count($links) == 1) // Single button
						$body = "<a class=\"ew-action ew-list-action\" data-action=\"" . HtmlEncode($action) . "\" title=\"" . HtmlTitle($caption) . "\" data-caption=\"" . HtmlTitle($caption) . "\" href=\"#\" onclick=\"return ew.submitAction(event,jQuery.extend({key:" . $this->keyToJson(TRUE) . "}," . $listaction->toJson(TRUE) . "));\">" . $icon . $listaction->Caption . "</a>";
				}
			}
			if (count($links) > 1) { // More than one buttons, use dropdown
				$body = "<button class=\"dropdown-toggle btn btn-default ew-actions\" title=\"" . HtmlTitle($Language->phrase("ListActionButton")) . "\" data-toggle=\"dropdown\">" . $Language->phrase("ListActionButton") . "</button>";
				$content = "";
				foreach ($links as $link)
					$content .= "<li>" . $link . "</li>";
				$body .= "<ul class=\"dropdown-menu" . ($opt->OnLeft ? "" : " dropdown-menu-right") . "\">". $content . "</ul>";
				$body = "<div class=\"btn-group btn-group-sm\">" . $body . "</div>";
			}
			if (count($links) > 0) {
				$opt->Body = $body;
				$opt->Visible = TRUE;
			}
		}
		$detailViewTblVar = "";
		$detailCopyTblVar = "";
		$detailEditTblVar = "";

		// "detail_loanissuedupgrades"
		$opt = $this->ListOptions["detail_loanissuedupgrades"];
		if ($Security->allowList(CurrentProjectID() . 'loanissuedupgrades')) {
			$body = $Language->phrase("DetailLink") . $Language->TablePhrase("loanissuedupgrades", "TblCaption");
			$body .= "&nbsp;" . str_replace("%c", $this->loanissuedupgrades_Count, $Language->phrase("DetailCount"));
			$body = "<a class=\"btn btn-default ew-row-link ew-detail\" data-action=\"list\" href=\"" . HtmlEncode("loanissuedupgradeslist.php?" . Config("TABLE_SHOW_MASTER") . "=loanissued&fk_loanid=" . urlencode(strval($this->loanid->CurrentValue)) . "") . "\">" . $body . "</a>";
			$links = "";
			if ($GLOBALS["loanissuedupgrades_grid"]->DetailView && $Security->canView() && $Security->allowView(CurrentProjectID() . 'loanissued')) {
				$caption = $Language->phrase("MasterDetailViewLink");
				$url = $this->getViewUrl(Config("TABLE_SHOW_DETAIL") . "=loanissuedupgrades");
				$links .= "<li><a class=\"dropdown-item ew-row-link ew-detail-view\" data-action=\"view\" data-caption=\"" . HtmlTitle($caption) . "\" href=\"" . HtmlEncode($url) . "\">" . HtmlImageAndText($caption) . "</a></li>";
				if ($detailViewTblVar != "")
					$detailViewTblVar .= ",";
				$detailViewTblVar .= "loanissuedupgrades";
			}
			if ($GLOBALS["loanissuedupgrades_grid"]->DetailEdit && $Security->canEdit() && $Security->allowEdit(CurrentProjectID() . 'loanissued')) {
				$caption = $Language->phrase("MasterDetailEditLink");
				$url = $this->getEditUrl(Config("TABLE_SHOW_DETAIL") . "=loanissuedupgrades");
				$links .= "<li><a class=\"dropdown-item ew-row-link ew-detail-edit\" data-action=\"edit\" data-caption=\"" . HtmlTitle($caption) . "\" href=\"" . HtmlEncode($url) . "\">" . HtmlImageAndText($caption) . "</a></li>";
				if ($detailEditTblVar != "")
					$detailEditTblVar .= ",";
				$detailEditTblVar .= "loanissuedupgrades";
			}
			if ($GLOBALS["loanissuedupgrades_grid"]->DetailAdd && $Security->canAdd() && $Security->allowAdd(CurrentProjectID() . 'loanissued')) {
				$caption = $Language->phrase("MasterDetailCopyLink");
				$url = $this->getCopyUrl(Config("TABLE_SHOW_DETAIL") . "=loanissuedupgrades");
				$links .= "<li><a class=\"dropdown-item ew-row-link ew-detail-copy\" data-action=\"add\" data-caption=\"" . HtmlTitle($caption) . "\" href=\"" . HtmlEncode($url) . "\">" . HtmlImageAndText($caption) . "</a></li>";
				if ($detailCopyTblVar != "")
					$detailCopyTblVar .= ",";
				$detailCopyTblVar .= "loanissuedupgrades";
			}
			if ($links != "") {
				$body .= "<button class=\"dropdown-toggle btn btn-default ew-detail\" data-toggle=\"dropdown\"></button>";
				$body .= "<ul class=\"dropdown-menu\">". $links . "</ul>";
			}
			$body = "<div class=\"btn-group btn-group-sm ew-btn-group\">" . $body . "</div>";
			$opt->Body = $body;
			if ($this->ShowMultipleDetails)
				$opt->Visible = FALSE;
		}

		// "detail_loaneventhistory"
		$opt = $this->ListOptions["detail_loaneventhistory"];
		if ($Security->allowList(CurrentProjectID() . 'loaneventhistory')) {
			$body = $Language->phrase("DetailLink") . $Language->TablePhrase("loaneventhistory", "TblCaption");
			$body .= "&nbsp;" . str_replace("%c", $this->loaneventhistory_Count, $Language->phrase("DetailCount"));
			$body = "<a class=\"btn btn-default ew-row-link ew-detail\" data-action=\"list\" href=\"" . HtmlEncode("loaneventhistorylist.php?" . Config("TABLE_SHOW_MASTER") . "=loanissued&fk_loanid=" . urlencode(strval($this->loanid->CurrentValue)) . "") . "\">" . $body . "</a>";
			$links = "";
			if ($GLOBALS["loaneventhistory_grid"]->DetailView && $Security->canView() && $Security->allowView(CurrentProjectID() . 'loanissued')) {
				$caption = $Language->phrase("MasterDetailViewLink");
				$url = $this->getViewUrl(Config("TABLE_SHOW_DETAIL") . "=loaneventhistory");
				$links .= "<li><a class=\"dropdown-item ew-row-link ew-detail-view\" data-action=\"view\" data-caption=\"" . HtmlTitle($caption) . "\" href=\"" . HtmlEncode($url) . "\">" . HtmlImageAndText($caption) . "</a></li>";
				if ($detailViewTblVar != "")
					$detailViewTblVar .= ",";
				$detailViewTblVar .= "loaneventhistory";
			}
			if ($GLOBALS["loaneventhistory_grid"]->DetailEdit && $Security->canEdit() && $Security->allowEdit(CurrentProjectID() . 'loanissued')) {
				$caption = $Language->phrase("MasterDetailEditLink");
				$url = $this->getEditUrl(Config("TABLE_SHOW_DETAIL") . "=loaneventhistory");
				$links .= "<li><a class=\"dropdown-item ew-row-link ew-detail-edit\" data-action=\"edit\" data-caption=\"" . HtmlTitle($caption) . "\" href=\"" . HtmlEncode($url) . "\">" . HtmlImageAndText($caption) . "</a></li>";
				if ($detailEditTblVar != "")
					$detailEditTblVar .= ",";
				$detailEditTblVar .= "loaneventhistory";
			}
			if ($GLOBALS["loaneventhistory_grid"]->DetailAdd && $Security->canAdd() && $Security->allowAdd(CurrentProjectID() . 'loanissued')) {
				$caption = $Language->phrase("MasterDetailCopyLink");
				$url = $this->getCopyUrl(Config("TABLE_SHOW_DETAIL") . "=loaneventhistory");
				$links .= "<li><a class=\"dropdown-item ew-row-link ew-detail-copy\" data-action=\"add\" data-caption=\"" . HtmlTitle($caption) . "\" href=\"" . HtmlEncode($url) . "\">" . HtmlImageAndText($caption) . "</a></li>";
				if ($detailCopyTblVar != "")
					$detailCopyTblVar .= ",";
				$detailCopyTblVar .= "loaneventhistory";
			}
			if ($links != "") {
				$body .= "<button class=\"dropdown-toggle btn btn-default ew-detail\" data-toggle=\"dropdown\"></button>";
				$body .= "<ul class=\"dropdown-menu\">". $links . "</ul>";
			}
			$body = "<div class=\"btn-group btn-group-sm ew-btn-group\">" . $body . "</div>";
			$opt->Body = $body;
			if ($this->ShowMultipleDetails)
				$opt->Visible = FALSE;
		}

		// "detail_loanlatefees"
		$opt = $this->ListOptions["detail_loanlatefees"];
		if ($Security->allowList(CurrentProjectID() . 'loanlatefees')) {
			$body = $Language->phrase("DetailLink") . $Language->TablePhrase("loanlatefees", "TblCaption");
			$body .= "&nbsp;" . str_replace("%c", $this->loanlatefees_Count, $Language->phrase("DetailCount"));
			$body = "<a class=\"btn btn-default ew-row-link ew-detail\" data-action=\"list\" href=\"" . HtmlEncode("loanlatefeeslist.php?" . Config("TABLE_SHOW_MASTER") . "=loanissued&fk_loanid=" . urlencode(strval($this->loanid->CurrentValue)) . "&fk_currcode=" . urlencode(strval($this->currcode->CurrentValue)) . "&fk__userid=" . urlencode(strval($this->_userid->CurrentValue)) . "") . "\">" . $body . "</a>";
			$links = "";
			if ($GLOBALS["loanlatefees_grid"]->DetailView && $Security->canView() && $Security->allowView(CurrentProjectID() . 'loanissued')) {
				$caption = $Language->phrase("MasterDetailViewLink");
				$url = $this->getViewUrl(Config("TABLE_SHOW_DETAIL") . "=loanlatefees");
				$links .= "<li><a class=\"dropdown-item ew-row-link ew-detail-view\" data-action=\"view\" data-caption=\"" . HtmlTitle($caption) . "\" href=\"" . HtmlEncode($url) . "\">" . HtmlImageAndText($caption) . "</a></li>";
				if ($detailViewTblVar != "")
					$detailViewTblVar .= ",";
				$detailViewTblVar .= "loanlatefees";
			}
			if ($GLOBALS["loanlatefees_grid"]->DetailEdit && $Security->canEdit() && $Security->allowEdit(CurrentProjectID() . 'loanissued')) {
				$caption = $Language->phrase("MasterDetailEditLink");
				$url = $this->getEditUrl(Config("TABLE_SHOW_DETAIL") . "=loanlatefees");
				$links .= "<li><a class=\"dropdown-item ew-row-link ew-detail-edit\" data-action=\"edit\" data-caption=\"" . HtmlTitle($caption) . "\" href=\"" . HtmlEncode($url) . "\">" . HtmlImageAndText($caption) . "</a></li>";
				if ($detailEditTblVar != "")
					$detailEditTblVar .= ",";
				$detailEditTblVar .= "loanlatefees";
			}
			if ($GLOBALS["loanlatefees_grid"]->DetailAdd && $Security->canAdd() && $Security->allowAdd(CurrentProjectID() . 'loanissued')) {
				$caption = $Language->phrase("MasterDetailCopyLink");
				$url = $this->getCopyUrl(Config("TABLE_SHOW_DETAIL") . "=loanlatefees");
				$links .= "<li><a class=\"dropdown-item ew-row-link ew-detail-copy\" data-action=\"add\" data-caption=\"" . HtmlTitle($caption) . "\" href=\"" . HtmlEncode($url) . "\">" . HtmlImageAndText($caption) . "</a></li>";
				if ($detailCopyTblVar != "")
					$detailCopyTblVar .= ",";
				$detailCopyTblVar .= "loanlatefees";
			}
			if ($links != "") {
				$body .= "<button class=\"dropdown-toggle btn btn-default ew-detail\" data-toggle=\"dropdown\"></button>";
				$body .= "<ul class=\"dropdown-menu\">". $links . "</ul>";
			}
			$body = "<div class=\"btn-group btn-group-sm ew-btn-group\">" . $body . "</div>";
			$opt->Body = $body;
			if ($this->ShowMultipleDetails)
				$opt->Visible = FALSE;
		}

		// "detail_loanapplied"
		$opt = $this->ListOptions["detail_loanapplied"];
		if ($Security->allowList(CurrentProjectID() . 'loanapplied')) {
			$body = $Language->phrase("DetailLink") . $Language->TablePhrase("loanapplied", "TblCaption");
			$body .= "&nbsp;" . str_replace("%c", $this->loanapplied_Count, $Language->phrase("DetailCount"));
			$body = "<a class=\"btn btn-default ew-row-link ew-detail\" data-action=\"list\" href=\"" . HtmlEncode("loanappliedlist.php?" . Config("TABLE_SHOW_MASTER") . "=loanissued&fk_loanid=" . urlencode(strval($this->loanid->CurrentValue)) . "") . "\">" . $body . "</a>";
			$links = "";
			if ($GLOBALS["loanapplied_grid"]->DetailView && $Security->canView() && $Security->allowView(CurrentProjectID() . 'loanissued')) {
				$caption = $Language->phrase("MasterDetailViewLink");
				$url = $this->getViewUrl(Config("TABLE_SHOW_DETAIL") . "=loanapplied");
				$links .= "<li><a class=\"dropdown-item ew-row-link ew-detail-view\" data-action=\"view\" data-caption=\"" . HtmlTitle($caption) . "\" href=\"" . HtmlEncode($url) . "\">" . HtmlImageAndText($caption) . "</a></li>";
				if ($detailViewTblVar != "")
					$detailViewTblVar .= ",";
				$detailViewTblVar .= "loanapplied";
			}
			if ($GLOBALS["loanapplied_grid"]->DetailEdit && $Security->canEdit() && $Security->allowEdit(CurrentProjectID() . 'loanissued')) {
				$caption = $Language->phrase("MasterDetailEditLink");
				$url = $this->getEditUrl(Config("TABLE_SHOW_DETAIL") . "=loanapplied");
				$links .= "<li><a class=\"dropdown-item ew-row-link ew-detail-edit\" data-action=\"edit\" data-caption=\"" . HtmlTitle($caption) . "\" href=\"" . HtmlEncode($url) . "\">" . HtmlImageAndText($caption) . "</a></li>";
				if ($detailEditTblVar != "")
					$detailEditTblVar .= ",";
				$detailEditTblVar .= "loanapplied";
			}
			if ($GLOBALS["loanapplied_grid"]->DetailAdd && $Security->canAdd() && $Security->allowAdd(CurrentProjectID() . 'loanissued')) {
				$caption = $Language->phrase("MasterDetailCopyLink");
				$url = $this->getCopyUrl(Config("TABLE_SHOW_DETAIL") . "=loanapplied");
				$links .= "<li><a class=\"dropdown-item ew-row-link ew-detail-copy\" data-action=\"add\" data-caption=\"" . HtmlTitle($caption) . "\" href=\"" . HtmlEncode($url) . "\">" . HtmlImageAndText($caption) . "</a></li>";
				if ($detailCopyTblVar != "")
					$detailCopyTblVar .= ",";
				$detailCopyTblVar .= "loanapplied";
			}
			if ($links != "") {
				$body .= "<button class=\"dropdown-toggle btn btn-default ew-detail\" data-toggle=\"dropdown\"></button>";
				$body .= "<ul class=\"dropdown-menu\">". $links . "</ul>";
			}
			$body = "<div class=\"btn-group btn-group-sm ew-btn-group\">" . $body . "</div>";
			$opt->Body = $body;
			if ($this->ShowMultipleDetails)
				$opt->Visible = FALSE;
		}

		// "detail_loanpayments"
		$opt = $this->ListOptions["detail_loanpayments"];
		if ($Security->allowList(CurrentProjectID() . 'loanpayments')) {
			$body = $Language->phrase("DetailLink") . $Language->TablePhrase("loanpayments", "TblCaption");
			$body .= "&nbsp;" . str_replace("%c", $this->loanpayments_Count, $Language->phrase("DetailCount"));
			$body = "<a class=\"btn btn-default ew-row-link ew-detail\" data-action=\"list\" href=\"" . HtmlEncode("loanpaymentslist.php?" . Config("TABLE_SHOW_MASTER") . "=loanissued&fk_loanid=" . urlencode(strval($this->loanid->CurrentValue)) . "&fk_currcode=" . urlencode(strval($this->currcode->CurrentValue)) . "") . "\">" . $body . "</a>";
			$links = "";
			if ($GLOBALS["loanpayments_grid"]->DetailView && $Security->canView() && $Security->allowView(CurrentProjectID() . 'loanissued')) {
				$caption = $Language->phrase("MasterDetailViewLink");
				$url = $this->getViewUrl(Config("TABLE_SHOW_DETAIL") . "=loanpayments");
				$links .= "<li><a class=\"dropdown-item ew-row-link ew-detail-view\" data-action=\"view\" data-caption=\"" . HtmlTitle($caption) . "\" href=\"" . HtmlEncode($url) . "\">" . HtmlImageAndText($caption) . "</a></li>";
				if ($detailViewTblVar != "")
					$detailViewTblVar .= ",";
				$detailViewTblVar .= "loanpayments";
			}
			if ($GLOBALS["loanpayments_grid"]->DetailEdit && $Security->canEdit() && $Security->allowEdit(CurrentProjectID() . 'loanissued')) {
				$caption = $Language->phrase("MasterDetailEditLink");
				$url = $this->getEditUrl(Config("TABLE_SHOW_DETAIL") . "=loanpayments");
				$links .= "<li><a class=\"dropdown-item ew-row-link ew-detail-edit\" data-action=\"edit\" data-caption=\"" . HtmlTitle($caption) . "\" href=\"" . HtmlEncode($url) . "\">" . HtmlImageAndText($caption) . "</a></li>";
				if ($detailEditTblVar != "")
					$detailEditTblVar .= ",";
				$detailEditTblVar .= "loanpayments";
			}
			if ($GLOBALS["loanpayments_grid"]->DetailAdd && $Security->canAdd() && $Security->allowAdd(CurrentProjectID() . 'loanissued')) {
				$caption = $Language->phrase("MasterDetailCopyLink");
				$url = $this->getCopyUrl(Config("TABLE_SHOW_DETAIL") . "=loanpayments");
				$links .= "<li><a class=\"dropdown-item ew-row-link ew-detail-copy\" data-action=\"add\" data-caption=\"" . HtmlTitle($caption) . "\" href=\"" . HtmlEncode($url) . "\">" . HtmlImageAndText($caption) . "</a></li>";
				if ($detailCopyTblVar != "")
					$detailCopyTblVar .= ",";
				$detailCopyTblVar .= "loanpayments";
			}
			if ($links != "") {
				$body .= "<button class=\"dropdown-toggle btn btn-default ew-detail\" data-toggle=\"dropdown\"></button>";
				$body .= "<ul class=\"dropdown-menu\">". $links . "</ul>";
			}
			$body = "<div class=\"btn-group btn-group-sm ew-btn-group\">" . $body . "</div>";
			$opt->Body = $body;
			if ($this->ShowMultipleDetails)
				$opt->Visible = FALSE;
		}

		// "detail_loanpaymentplan"
		$opt = $this->ListOptions["detail_loanpaymentplan"];
		if ($Security->allowList(CurrentProjectID() . 'loanpaymentplan')) {
			$body = $Language->phrase("DetailLink") . $Language->TablePhrase("loanpaymentplan", "TblCaption");
			$body .= "&nbsp;" . str_replace("%c", $this->loanpaymentplan_Count, $Language->phrase("DetailCount"));
			$body = "<a class=\"btn btn-default ew-row-link ew-detail\" data-action=\"list\" href=\"" . HtmlEncode("loanpaymentplanlist.php?" . Config("TABLE_SHOW_MASTER") . "=loanissued&fk_loanid=" . urlencode(strval($this->loanid->CurrentValue)) . "") . "\">" . $body . "</a>";
			$links = "";
			if ($GLOBALS["loanpaymentplan_grid"]->DetailView && $Security->canView() && $Security->allowView(CurrentProjectID() . 'loanissued')) {
				$caption = $Language->phrase("MasterDetailViewLink");
				$url = $this->getViewUrl(Config("TABLE_SHOW_DETAIL") . "=loanpaymentplan");
				$links .= "<li><a class=\"dropdown-item ew-row-link ew-detail-view\" data-action=\"view\" data-caption=\"" . HtmlTitle($caption) . "\" href=\"" . HtmlEncode($url) . "\">" . HtmlImageAndText($caption) . "</a></li>";
				if ($detailViewTblVar != "")
					$detailViewTblVar .= ",";
				$detailViewTblVar .= "loanpaymentplan";
			}
			if ($GLOBALS["loanpaymentplan_grid"]->DetailEdit && $Security->canEdit() && $Security->allowEdit(CurrentProjectID() . 'loanissued')) {
				$caption = $Language->phrase("MasterDetailEditLink");
				$url = $this->getEditUrl(Config("TABLE_SHOW_DETAIL") . "=loanpaymentplan");
				$links .= "<li><a class=\"dropdown-item ew-row-link ew-detail-edit\" data-action=\"edit\" data-caption=\"" . HtmlTitle($caption) . "\" href=\"" . HtmlEncode($url) . "\">" . HtmlImageAndText($caption) . "</a></li>";
				if ($detailEditTblVar != "")
					$detailEditTblVar .= ",";
				$detailEditTblVar .= "loanpaymentplan";
			}
			if ($GLOBALS["loanpaymentplan_grid"]->DetailAdd && $Security->canAdd() && $Security->allowAdd(CurrentProjectID() . 'loanissued')) {
				$caption = $Language->phrase("MasterDetailCopyLink");
				$url = $this->getCopyUrl(Config("TABLE_SHOW_DETAIL") . "=loanpaymentplan");
				$links .= "<li><a class=\"dropdown-item ew-row-link ew-detail-copy\" data-action=\"add\" data-caption=\"" . HtmlTitle($caption) . "\" href=\"" . HtmlEncode($url) . "\">" . HtmlImageAndText($caption) . "</a></li>";
				if ($detailCopyTblVar != "")
					$detailCopyTblVar .= ",";
				$detailCopyTblVar .= "loanpaymentplan";
			}
			if ($links != "") {
				$body .= "<button class=\"dropdown-toggle btn btn-default ew-detail\" data-toggle=\"dropdown\"></button>";
				$body .= "<ul class=\"dropdown-menu\">". $links . "</ul>";
			}
			$body = "<div class=\"btn-group btn-group-sm ew-btn-group\">" . $body . "</div>";
			$opt->Body = $body;
			if ($this->ShowMultipleDetails)
				$opt->Visible = FALSE;
		}
		if ($this->ShowMultipleDetails) {
			$body = "<div class=\"btn-group btn-group-sm ew-btn-group\">";
			$links = "";
			if ($detailViewTblVar != "") {
				$links .= "<li><a class=\"dropdown-item ew-row-link ew-detail-view\" data-action=\"view\" data-caption=\"" . HtmlTitle($Language->phrase("MasterDetailViewLink")) . "\" href=\"" . HtmlEncode($this->getViewUrl(Config("TABLE_SHOW_DETAIL") . "=" . $detailViewTblVar)) . "\">" . HtmlImageAndText($Language->phrase("MasterDetailViewLink")) . "</a></li>";
			}
			if ($detailEditTblVar != "") {
				$links .= "<li><a class=\"dropdown-item ew-row-link ew-detail-edit\" data-action=\"edit\" data-caption=\"" . HtmlTitle($Language->phrase("MasterDetailEditLink")) . "\" href=\"" . HtmlEncode($this->getEditUrl(Config("TABLE_SHOW_DETAIL") . "=" . $detailEditTblVar)) . "\">" . HtmlImageAndText($Language->phrase("MasterDetailEditLink")) . "</a></li>";
			}
			if ($detailCopyTblVar != "") {
				$links .= "<li><a class=\"dropdown-item ew-row-link ew-detail-copy\" data-action=\"add\" data-caption=\"" . HtmlTitle($Language->phrase("MasterDetailCopyLink")) . "\" href=\"" . HtmlEncode($this->GetCopyUrl(Config("TABLE_SHOW_DETAIL") . "=" . $detailCopyTblVar)) . "\">" . HtmlImageAndText($Language->phrase("MasterDetailCopyLink")) . "</a></li>";
			}
			if ($links != "") {
				$body .= "<button class=\"dropdown-toggle btn btn-default ew-master-detail\" title=\"" . HtmlTitle($Language->phrase("MultipleMasterDetails")) . "\" data-toggle=\"dropdown\">" . $Language->phrase("MultipleMasterDetails") . "</button>";
				$body .= "<ul class=\"dropdown-menu ew-menu\">". $links . "</ul>";
			}
			$body .= "</div>";

			// Multiple details
			$opt = $this->ListOptions["details"];
			$opt->Body = $body;
		}

		// "checkbox"
		$opt = $this->ListOptions["checkbox"];
		$opt->Body = "<div class=\"custom-control custom-checkbox d-inline-block\"><input type=\"checkbox\" id=\"key_m_" . $this->RowCount . "\" name=\"key_m[]\" class=\"custom-control-input ew-multi-select\" value=\"" . HtmlEncode($this->loanid->CurrentValue) . "\" onclick=\"ew.clickMultiCheckbox(event);\"><label class=\"custom-control-label\" for=\"key_m_" . $this->RowCount . "\"></label></div>";
		$this->renderListOptionsExt();

		// Call ListOptions_Rendered event
		$this->ListOptions_Rendered();
	}

	// Set up other options
	protected function setupOtherOptions()
	{
		global $Language, $Security;
		$options = &$this->OtherOptions;
		$option = $options["addedit"];

		// Add
		$item = &$option->add("add");
		$addcaption = HtmlTitle($Language->phrase("AddLink"));
		$item->Body = "<a class=\"ew-add-edit ew-add\" title=\"" . $addcaption . "\" data-caption=\"" . $addcaption . "\" href=\"" . HtmlEncode($this->AddUrl) . "\">" . $Language->phrase("AddLink") . "</a>";
		$item->Visible = $this->AddUrl != "" && $Security->canAdd();
		$option = $options["detail"];
		$detailTableLink = "";
		$item = &$option->add("detailadd_loanissuedupgrades");
		$url = $this->getAddUrl(Config("TABLE_SHOW_DETAIL") . "=loanissuedupgrades");
		if (!isset($GLOBALS["loanissuedupgrades"]))
			$GLOBALS["loanissuedupgrades"] = new loanissuedupgrades();
		$caption = $Language->phrase("Add") . "&nbsp;" . $this->tableCaption() . "/" . $GLOBALS["loanissuedupgrades"]->tableCaption();
		$item->Body = "<a class=\"ew-detail-add-group ew-detail-add\" title=\"" . HtmlTitle($caption) . "\" data-caption=\"" . HtmlTitle($caption) . "\" href=\"" . HtmlEncode($url) . "\">" . $caption . "</a>";
		$item->Visible = ($GLOBALS["loanissuedupgrades"]->DetailAdd && $Security->allowAdd(CurrentProjectID() . 'loanissued') && $Security->canAdd());
		if ($item->Visible) {
			if ($detailTableLink != "")
				$detailTableLink .= ",";
			$detailTableLink .= "loanissuedupgrades";
		}
		$item = &$option->add("detailadd_loaneventhistory");
		$url = $this->getAddUrl(Config("TABLE_SHOW_DETAIL") . "=loaneventhistory");
		if (!isset($GLOBALS["loaneventhistory"]))
			$GLOBALS["loaneventhistory"] = new loaneventhistory();
		$caption = $Language->phrase("Add") . "&nbsp;" . $this->tableCaption() . "/" . $GLOBALS["loaneventhistory"]->tableCaption();
		$item->Body = "<a class=\"ew-detail-add-group ew-detail-add\" title=\"" . HtmlTitle($caption) . "\" data-caption=\"" . HtmlTitle($caption) . "\" href=\"" . HtmlEncode($url) . "\">" . $caption . "</a>";
		$item->Visible = ($GLOBALS["loaneventhistory"]->DetailAdd && $Security->allowAdd(CurrentProjectID() . 'loanissued') && $Security->canAdd());
		if ($item->Visible) {
			if ($detailTableLink != "")
				$detailTableLink .= ",";
			$detailTableLink .= "loaneventhistory";
		}
		$item = &$option->add("detailadd_loanlatefees");
		$url = $this->getAddUrl(Config("TABLE_SHOW_DETAIL") . "=loanlatefees");
		if (!isset($GLOBALS["loanlatefees"]))
			$GLOBALS["loanlatefees"] = new loanlatefees();
		$caption = $Language->phrase("Add") . "&nbsp;" . $this->tableCaption() . "/" . $GLOBALS["loanlatefees"]->tableCaption();
		$item->Body = "<a class=\"ew-detail-add-group ew-detail-add\" title=\"" . HtmlTitle($caption) . "\" data-caption=\"" . HtmlTitle($caption) . "\" href=\"" . HtmlEncode($url) . "\">" . $caption . "</a>";
		$item->Visible = ($GLOBALS["loanlatefees"]->DetailAdd && $Security->allowAdd(CurrentProjectID() . 'loanissued') && $Security->canAdd());
		if ($item->Visible) {
			if ($detailTableLink != "")
				$detailTableLink .= ",";
			$detailTableLink .= "loanlatefees";
		}
		$item = &$option->add("detailadd_loanapplied");
		$url = $this->getAddUrl(Config("TABLE_SHOW_DETAIL") . "=loanapplied");
		if (!isset($GLOBALS["loanapplied"]))
			$GLOBALS["loanapplied"] = new loanapplied();
		$caption = $Language->phrase("Add") . "&nbsp;" . $this->tableCaption() . "/" . $GLOBALS["loanapplied"]->tableCaption();
		$item->Body = "<a class=\"ew-detail-add-group ew-detail-add\" title=\"" . HtmlTitle($caption) . "\" data-caption=\"" . HtmlTitle($caption) . "\" href=\"" . HtmlEncode($url) . "\">" . $caption . "</a>";
		$item->Visible = ($GLOBALS["loanapplied"]->DetailAdd && $Security->allowAdd(CurrentProjectID() . 'loanissued') && $Security->canAdd());
		if ($item->Visible) {
			if ($detailTableLink != "")
				$detailTableLink .= ",";
			$detailTableLink .= "loanapplied";
		}
		$item = &$option->add("detailadd_loanpayments");
		$url = $this->getAddUrl(Config("TABLE_SHOW_DETAIL") . "=loanpayments");
		if (!isset($GLOBALS["loanpayments"]))
			$GLOBALS["loanpayments"] = new loanpayments();
		$caption = $Language->phrase("Add") . "&nbsp;" . $this->tableCaption() . "/" . $GLOBALS["loanpayments"]->tableCaption();
		$item->Body = "<a class=\"ew-detail-add-group ew-detail-add\" title=\"" . HtmlTitle($caption) . "\" data-caption=\"" . HtmlTitle($caption) . "\" href=\"" . HtmlEncode($url) . "\">" . $caption . "</a>";
		$item->Visible = ($GLOBALS["loanpayments"]->DetailAdd && $Security->allowAdd(CurrentProjectID() . 'loanissued') && $Security->canAdd());
		if ($item->Visible) {
			if ($detailTableLink != "")
				$detailTableLink .= ",";
			$detailTableLink .= "loanpayments";
		}
		$item = &$option->add("detailadd_loanpaymentplan");
		$url = $this->getAddUrl(Config("TABLE_SHOW_DETAIL") . "=loanpaymentplan");
		if (!isset($GLOBALS["loanpaymentplan"]))
			$GLOBALS["loanpaymentplan"] = new loanpaymentplan();
		$caption = $Language->phrase("Add") . "&nbsp;" . $this->tableCaption() . "/" . $GLOBALS["loanpaymentplan"]->tableCaption();
		$item->Body = "<a class=\"ew-detail-add-group ew-detail-add\" title=\"" . HtmlTitle($caption) . "\" data-caption=\"" . HtmlTitle($caption) . "\" href=\"" . HtmlEncode($url) . "\">" . $caption . "</a>";
		$item->Visible = ($GLOBALS["loanpaymentplan"]->DetailAdd && $Security->allowAdd(CurrentProjectID() . 'loanissued') && $Security->canAdd());
		if ($item->Visible) {
			if ($detailTableLink != "")
				$detailTableLink .= ",";
			$detailTableLink .= "loanpaymentplan";
		}

		// Add multiple details
		if ($this->ShowMultipleDetails) {
			$item = &$option->add("detailsadd");
			$url = $this->getAddUrl(Config("TABLE_SHOW_DETAIL") . "=" . $detailTableLink);
			$caption = $Language->phrase("AddMasterDetailLink");
			$item->Body = "<a class=\"ew-detail-add-group ew-detail-add\" title=\"" . HtmlTitle($caption) . "\" data-caption=\"" . HtmlTitle($caption) . "\" href=\"" . HtmlEncode($url) . "\">" . $caption . "</a>";
			$item->Visible = $detailTableLink != "" && $Security->canAdd();

			// Hide single master/detail items
			$ar = explode(",", $detailTableLink);
			$cnt = count($ar);
			for ($i = 0; $i < $cnt; $i++) {
				if ($item = $option["detailadd_" . $ar[$i]])
					$item->Visible = FALSE;
			}
		}
		$option = $options["action"];

		// Set up options default
		foreach ($options as $option) {
			$option->UseDropDownButton = FALSE;
			$option->UseButtonGroup = TRUE;

			//$option->ButtonClass = ""; // Class for button group
			$item = &$option->add($option->GroupOptionName);
			$item->Body = "";
			$item->Visible = FALSE;
		}
		$options["addedit"]->DropDownButtonPhrase = $Language->phrase("ButtonAddEdit");
		$options["detail"]->DropDownButtonPhrase = $Language->phrase("ButtonDetails");
		$options["action"]->DropDownButtonPhrase = $Language->phrase("ButtonActions");

		// Filter button
		$item = &$this->FilterOptions->add("savecurrentfilter");
		$item->Body = "<a class=\"ew-save-filter\" data-form=\"floanissuedlistsrch\" href=\"#\" onclick=\"return false;\">" . $Language->phrase("SaveCurrentFilter") . "</a>";
		$item->Visible = TRUE;
		$item = &$this->FilterOptions->add("deletefilter");
		$item->Body = "<a class=\"ew-delete-filter\" data-form=\"floanissuedlistsrch\" href=\"#\" onclick=\"return false;\">" . $Language->phrase("DeleteFilter") . "</a>";
		$item->Visible = TRUE;
		$this->FilterOptions->UseDropDownButton = TRUE;
		$this->FilterOptions->UseButtonGroup = !$this->FilterOptions->UseDropDownButton;
		$this->FilterOptions->DropDownButtonPhrase = $Language->phrase("Filters");

		// Add group option item
		$item = &$this->FilterOptions->add($this->FilterOptions->GroupOptionName);
		$item->Body = "";
		$item->Visible = FALSE;
	}

	// Render other options
	public function renderOtherOptions()
	{
		global $Language, $Security;
		$options = &$this->OtherOptions;
			$option = $options["action"];

			// Set up list action buttons
			foreach ($this->ListActions->Items as $listaction) {
				if ($listaction->Select == ACTION_MULTIPLE) {
					$item = &$option->add("custom_" . $listaction->Action);
					$caption = $listaction->Caption;
					$icon = ($listaction->Icon != "") ? "<i class=\"" . HtmlEncode($listaction->Icon) . "\" data-caption=\"" . HtmlEncode($caption) . "\"></i> " . $caption : $caption;
					$item->Body = "<a class=\"ew-action ew-list-action\" title=\"" . HtmlEncode($caption) . "\" data-caption=\"" . HtmlEncode($caption) . "\" href=\"#\" onclick=\"return ew.submitAction(event,jQuery.extend({f:document.floanissuedlist}," . $listaction->toJson(TRUE) . "));\">" . $icon . "</a>";
					$item->Visible = $listaction->Allow;
				}
			}

			// Hide grid edit and other options
			if ($this->TotalRecords <= 0) {
				$option = $options["addedit"];
				$item = $option["gridedit"];
				if ($item)
					$item->Visible = FALSE;
				$option = $options["action"];
				$option->hideAllOptions();
			}
	}

	// Process list action
	protected function processListAction()
	{
		global $Language, $Security;
		$userlist = "";
		$user = "";
		$filter = $this->getFilterFromRecordKeys();
		$userAction = Post("useraction", "");
		if ($filter != "" && $userAction != "") {

			// Check permission first
			$actionCaption = $userAction;
			if (array_key_exists($userAction, $this->ListActions->Items)) {
				$actionCaption = $this->ListActions[$userAction]->Caption;
				if (!$this->ListActions[$userAction]->Allow) {
					$errmsg = str_replace('%s', $actionCaption, $Language->phrase("CustomActionNotAllowed"));
					if (Post("ajax") == $userAction) // Ajax
						echo "<p class=\"text-danger\">" . $errmsg . "</p>";
					else
						$this->setFailureMessage($errmsg);
					return FALSE;
				}
			}
			$this->CurrentFilter = $filter;
			$sql = $this->getCurrentSql();
			$conn = $this->getConnection();
			$conn->raiseErrorFn = Config("ERROR_FUNC");
			$rs = $conn->execute($sql);
			$conn->raiseErrorFn = "";
			$this->CurrentAction = $userAction;

			// Call row action event
			if ($rs && !$rs->EOF) {
				$conn->beginTrans();
				$this->SelectedCount = $rs->RecordCount();
				$this->SelectedIndex = 0;
				while (!$rs->EOF) {
					$this->SelectedIndex++;
					$row = $rs->fields;
					$processed = $this->Row_CustomAction($userAction, $row);
					if (!$processed)
						break;
					$rs->moveNext();
				}
				if ($processed) {
					$conn->commitTrans(); // Commit the changes
					if ($this->getSuccessMessage() == "" && !ob_get_length()) // No output
						$this->setSuccessMessage(str_replace('%s', $actionCaption, $Language->phrase("CustomActionCompleted"))); // Set up success message
				} else {
					$conn->rollbackTrans(); // Rollback changes

					// Set up error message
					if ($this->getSuccessMessage() != "" || $this->getFailureMessage() != "") {

						// Use the message, do nothing
					} elseif ($this->CancelMessage != "") {
						$this->setFailureMessage($this->CancelMessage);
						$this->CancelMessage = "";
					} else {
						$this->setFailureMessage(str_replace('%s', $actionCaption, $Language->phrase("CustomActionFailed")));
					}
				}
			}
			if ($rs)
				$rs->close();
			$this->CurrentAction = ""; // Clear action
			if (Post("ajax") == $userAction) { // Ajax
				if ($this->getSuccessMessage() != "") {
					echo "<p class=\"text-success\">" . $this->getSuccessMessage() . "</p>";
					$this->clearSuccessMessage(); // Clear message
				}
				if ($this->getFailureMessage() != "") {
					echo "<p class=\"text-danger\">" . $this->getFailureMessage() . "</p>";
					$this->clearFailureMessage(); // Clear message
				}
				return TRUE;
			}
		}
		return FALSE; // Not ajax request
	}

// Set up list options (extended codes)
	protected function setupListOptionsExt()
	{

		// Hide detail items for dropdown if necessary
		$this->ListOptions->hideDetailItemsForDropDown();
	}

// Render list options (extended codes)
	protected function renderListOptionsExt()
	{
		global $Security, $Language;
		$links = "";
		$btngrps = "";
		$sqlwrk = "`loanid`=" . AdjustSql($this->loanid->CurrentValue, $this->Dbid) . "";

		// Column "detail_loanissuedupgrades"
		if ($this->DetailPages && $this->DetailPages["loanissuedupgrades"] && $this->DetailPages["loanissuedupgrades"]->Visible) {
			$link = "";
			$option = $this->ListOptions["detail_loanissuedupgrades"];
			$url = "loanissuedupgradespreview.php?t=loanissued&f=" . Encrypt($sqlwrk);
			$btngrp = "<div data-table=\"loanissuedupgrades\" data-url=\"" . $url . "\">";
			if ($Security->allowList(CurrentProjectID() . 'loanissued')) {
				$label = $Language->TablePhrase("loanissuedupgrades", "TblCaption");
				$label .= "&nbsp;" . JsEncode(str_replace("%c", $this->loanissuedupgrades_Count, $Language->phrase("DetailCount")));
				$link = "<li class=\"nav-item\"><a href=\"#\" class=\"nav-link\" data-toggle=\"tab\" data-table=\"loanissuedupgrades\" data-url=\"" . $url . "\">" . $label . "</a></li>";
				$links .= $link;
				$detaillnk = JsEncodeAttribute("loanissuedupgradeslist.php?" . Config("TABLE_SHOW_MASTER") . "=loanissued&fk_loanid=" . urlencode(strval($this->loanid->CurrentValue)) . "");
				$btngrp .= "<a href=\"#\" class=\"mr-2\" title=\"" . $Language->TablePhrase("loanissuedupgrades", "TblCaption") . "\" onclick=\"window.location='" . $detaillnk . "';return false;\">" . $Language->phrase("MasterDetailListLink") . "</a>";
			}
			if (!isset($GLOBALS["loanissuedupgrades_grid"]))
				$GLOBALS["loanissuedupgrades_grid"] = new loanissuedupgrades_grid();
			if ($GLOBALS["loanissuedupgrades_grid"]->DetailView && $Security->canView() && $Security->allowView(CurrentProjectID() . 'loanissued')) {
				$caption = $Language->phrase("MasterDetailViewLink");
				$url = $this->getViewUrl(Config("TABLE_SHOW_DETAIL") . "=loanissuedupgrades");
				$btngrp .= "<a href=\"#\" class=\"mr-2\" title=\"" . HtmlTitle($caption) . "\" onclick=\"window.location='" . HtmlEncode($url) . "';return false;\">" . $caption . "</a>";
			}
			if ($GLOBALS["loanissuedupgrades_grid"]->DetailEdit && $Security->canEdit() && $Security->allowEdit(CurrentProjectID() . 'loanissued')) {
				$caption = $Language->phrase("MasterDetailEditLink");
				$url = $this->getEditUrl(Config("TABLE_SHOW_DETAIL") . "=loanissuedupgrades");
				$btngrp .= "<a href=\"#\" class=\"mr-2\" title=\"" . HtmlTitle($caption) . "\" onclick=\"window.location='" . HtmlEncode($url) . "';return false;\">" . $caption . "</a>";
			}
			if ($GLOBALS["loanissuedupgrades_grid"]->DetailAdd && $Security->canAdd() && $Security->allowAdd(CurrentProjectID() . 'loanissued')) {
				$caption = $Language->phrase("MasterDetailCopyLink");
				$url = $this->getCopyUrl(Config("TABLE_SHOW_DETAIL") . "=loanissuedupgrades");
				$btngrp .= "<a href=\"#\" class=\"mr-2\" title=\"" . HtmlTitle($caption) . "\" onclick=\"window.location='" . HtmlEncode($url) . "';return false;\">" . $caption . "</a>";
			}
			$btngrp .= "</div>";
			if ($link != "") {
				$btngrps .= $btngrp;
				$option->Body .= "<div class=\"d-none ew-preview\">" . $link . $btngrp . "</div>";
			}
		}
		$sqlwrk = "`userid`=" . AdjustSql($this->loanid->CurrentValue, $this->Dbid) . "";

		// Column "detail_loaneventhistory"
		if ($this->DetailPages && $this->DetailPages["loaneventhistory"] && $this->DetailPages["loaneventhistory"]->Visible) {
			$link = "";
			$option = $this->ListOptions["detail_loaneventhistory"];
			$url = "loaneventhistorypreview.php?t=loanissued&f=" . Encrypt($sqlwrk);
			$btngrp = "<div data-table=\"loaneventhistory\" data-url=\"" . $url . "\">";
			if ($Security->allowList(CurrentProjectID() . 'loanissued')) {
				$label = $Language->TablePhrase("loaneventhistory", "TblCaption");
				$label .= "&nbsp;" . JsEncode(str_replace("%c", $this->loaneventhistory_Count, $Language->phrase("DetailCount")));
				$link = "<li class=\"nav-item\"><a href=\"#\" class=\"nav-link\" data-toggle=\"tab\" data-table=\"loaneventhistory\" data-url=\"" . $url . "\">" . $label . "</a></li>";
				$links .= $link;
				$detaillnk = JsEncodeAttribute("loaneventhistorylist.php?" . Config("TABLE_SHOW_MASTER") . "=loanissued&fk_loanid=" . urlencode(strval($this->loanid->CurrentValue)) . "");
				$btngrp .= "<a href=\"#\" class=\"mr-2\" title=\"" . $Language->TablePhrase("loaneventhistory", "TblCaption") . "\" onclick=\"window.location='" . $detaillnk . "';return false;\">" . $Language->phrase("MasterDetailListLink") . "</a>";
			}
			if (!isset($GLOBALS["loaneventhistory_grid"]))
				$GLOBALS["loaneventhistory_grid"] = new loaneventhistory_grid();
			if ($GLOBALS["loaneventhistory_grid"]->DetailView && $Security->canView() && $Security->allowView(CurrentProjectID() . 'loanissued')) {
				$caption = $Language->phrase("MasterDetailViewLink");
				$url = $this->getViewUrl(Config("TABLE_SHOW_DETAIL") . "=loaneventhistory");
				$btngrp .= "<a href=\"#\" class=\"mr-2\" title=\"" . HtmlTitle($caption) . "\" onclick=\"window.location='" . HtmlEncode($url) . "';return false;\">" . $caption . "</a>";
			}
			if ($GLOBALS["loaneventhistory_grid"]->DetailEdit && $Security->canEdit() && $Security->allowEdit(CurrentProjectID() . 'loanissued')) {
				$caption = $Language->phrase("MasterDetailEditLink");
				$url = $this->getEditUrl(Config("TABLE_SHOW_DETAIL") . "=loaneventhistory");
				$btngrp .= "<a href=\"#\" class=\"mr-2\" title=\"" . HtmlTitle($caption) . "\" onclick=\"window.location='" . HtmlEncode($url) . "';return false;\">" . $caption . "</a>";
			}
			if ($GLOBALS["loaneventhistory_grid"]->DetailAdd && $Security->canAdd() && $Security->allowAdd(CurrentProjectID() . 'loanissued')) {
				$caption = $Language->phrase("MasterDetailCopyLink");
				$url = $this->getCopyUrl(Config("TABLE_SHOW_DETAIL") . "=loaneventhistory");
				$btngrp .= "<a href=\"#\" class=\"mr-2\" title=\"" . HtmlTitle($caption) . "\" onclick=\"window.location='" . HtmlEncode($url) . "';return false;\">" . $caption . "</a>";
			}
			$btngrp .= "</div>";
			if ($link != "") {
				$btngrps .= $btngrp;
				$option->Body .= "<div class=\"d-none ew-preview\">" . $link . $btngrp . "</div>";
			}
		}
		$sqlwrk = "`loanid`=" . AdjustSql($this->loanid->CurrentValue, $this->Dbid) . "";
		$sqlwrk = $sqlwrk . " AND " . "`currcode`='" . AdjustSql($this->currcode->CurrentValue, $this->Dbid) . "'";
		$sqlwrk = $sqlwrk . " AND " . "`userid`=" . AdjustSql($this->_userid->CurrentValue, $this->Dbid) . "";

		// Column "detail_loanlatefees"
		if ($this->DetailPages && $this->DetailPages["loanlatefees"] && $this->DetailPages["loanlatefees"]->Visible) {
			$link = "";
			$option = $this->ListOptions["detail_loanlatefees"];
			$url = "loanlatefeespreview.php?t=loanissued&f=" . Encrypt($sqlwrk);
			$btngrp = "<div data-table=\"loanlatefees\" data-url=\"" . $url . "\">";
			if ($Security->allowList(CurrentProjectID() . 'loanissued')) {
				$label = $Language->TablePhrase("loanlatefees", "TblCaption");
				$label .= "&nbsp;" . JsEncode(str_replace("%c", $this->loanlatefees_Count, $Language->phrase("DetailCount")));
				$link = "<li class=\"nav-item\"><a href=\"#\" class=\"nav-link\" data-toggle=\"tab\" data-table=\"loanlatefees\" data-url=\"" . $url . "\">" . $label . "</a></li>";
				$links .= $link;
				$detaillnk = JsEncodeAttribute("loanlatefeeslist.php?" . Config("TABLE_SHOW_MASTER") . "=loanissued&fk_loanid=" . urlencode(strval($this->loanid->CurrentValue)) . "&fk_currcode=" . urlencode(strval($this->currcode->CurrentValue)) . "&fk__userid=" . urlencode(strval($this->_userid->CurrentValue)) . "");
				$btngrp .= "<a href=\"#\" class=\"mr-2\" title=\"" . $Language->TablePhrase("loanlatefees", "TblCaption") . "\" onclick=\"window.location='" . $detaillnk . "';return false;\">" . $Language->phrase("MasterDetailListLink") . "</a>";
			}
			if (!isset($GLOBALS["loanlatefees_grid"]))
				$GLOBALS["loanlatefees_grid"] = new loanlatefees_grid();
			if ($GLOBALS["loanlatefees_grid"]->DetailView && $Security->canView() && $Security->allowView(CurrentProjectID() . 'loanissued')) {
				$caption = $Language->phrase("MasterDetailViewLink");
				$url = $this->getViewUrl(Config("TABLE_SHOW_DETAIL") . "=loanlatefees");
				$btngrp .= "<a href=\"#\" class=\"mr-2\" title=\"" . HtmlTitle($caption) . "\" onclick=\"window.location='" . HtmlEncode($url) . "';return false;\">" . $caption . "</a>";
			}
			if ($GLOBALS["loanlatefees_grid"]->DetailEdit && $Security->canEdit() && $Security->allowEdit(CurrentProjectID() . 'loanissued')) {
				$caption = $Language->phrase("MasterDetailEditLink");
				$url = $this->getEditUrl(Config("TABLE_SHOW_DETAIL") . "=loanlatefees");
				$btngrp .= "<a href=\"#\" class=\"mr-2\" title=\"" . HtmlTitle($caption) . "\" onclick=\"window.location='" . HtmlEncode($url) . "';return false;\">" . $caption . "</a>";
			}
			if ($GLOBALS["loanlatefees_grid"]->DetailAdd && $Security->canAdd() && $Security->allowAdd(CurrentProjectID() . 'loanissued')) {
				$caption = $Language->phrase("MasterDetailCopyLink");
				$url = $this->getCopyUrl(Config("TABLE_SHOW_DETAIL") . "=loanlatefees");
				$btngrp .= "<a href=\"#\" class=\"mr-2\" title=\"" . HtmlTitle($caption) . "\" onclick=\"window.location='" . HtmlEncode($url) . "';return false;\">" . $caption . "</a>";
			}
			$btngrp .= "</div>";
			if ($link != "") {
				$btngrps .= $btngrp;
				$option->Body .= "<div class=\"d-none ew-preview\">" . $link . $btngrp . "</div>";
			}
		}
		$sqlwrk = "`loanid`=" . AdjustSql($this->loanid->CurrentValue, $this->Dbid) . "";

		// Column "detail_loanapplied"
		if ($this->DetailPages && $this->DetailPages["loanapplied"] && $this->DetailPages["loanapplied"]->Visible) {
			$link = "";
			$option = $this->ListOptions["detail_loanapplied"];
			$url = "loanappliedpreview.php?t=loanissued&f=" . Encrypt($sqlwrk);
			$btngrp = "<div data-table=\"loanapplied\" data-url=\"" . $url . "\">";
			if ($Security->allowList(CurrentProjectID() . 'loanissued')) {
				$label = $Language->TablePhrase("loanapplied", "TblCaption");
				$label .= "&nbsp;" . JsEncode(str_replace("%c", $this->loanapplied_Count, $Language->phrase("DetailCount")));
				$link = "<li class=\"nav-item\"><a href=\"#\" class=\"nav-link\" data-toggle=\"tab\" data-table=\"loanapplied\" data-url=\"" . $url . "\">" . $label . "</a></li>";
				$links .= $link;
				$detaillnk = JsEncodeAttribute("loanappliedlist.php?" . Config("TABLE_SHOW_MASTER") . "=loanissued&fk_loanid=" . urlencode(strval($this->loanid->CurrentValue)) . "");
				$btngrp .= "<a href=\"#\" class=\"mr-2\" title=\"" . $Language->TablePhrase("loanapplied", "TblCaption") . "\" onclick=\"window.location='" . $detaillnk . "';return false;\">" . $Language->phrase("MasterDetailListLink") . "</a>";
			}
			if (!isset($GLOBALS["loanapplied_grid"]))
				$GLOBALS["loanapplied_grid"] = new loanapplied_grid();
			if ($GLOBALS["loanapplied_grid"]->DetailView && $Security->canView() && $Security->allowView(CurrentProjectID() . 'loanissued')) {
				$caption = $Language->phrase("MasterDetailViewLink");
				$url = $this->getViewUrl(Config("TABLE_SHOW_DETAIL") . "=loanapplied");
				$btngrp .= "<a href=\"#\" class=\"mr-2\" title=\"" . HtmlTitle($caption) . "\" onclick=\"window.location='" . HtmlEncode($url) . "';return false;\">" . $caption . "</a>";
			}
			if ($GLOBALS["loanapplied_grid"]->DetailEdit && $Security->canEdit() && $Security->allowEdit(CurrentProjectID() . 'loanissued')) {
				$caption = $Language->phrase("MasterDetailEditLink");
				$url = $this->getEditUrl(Config("TABLE_SHOW_DETAIL") . "=loanapplied");
				$btngrp .= "<a href=\"#\" class=\"mr-2\" title=\"" . HtmlTitle($caption) . "\" onclick=\"window.location='" . HtmlEncode($url) . "';return false;\">" . $caption . "</a>";
			}
			if ($GLOBALS["loanapplied_grid"]->DetailAdd && $Security->canAdd() && $Security->allowAdd(CurrentProjectID() . 'loanissued')) {
				$caption = $Language->phrase("MasterDetailCopyLink");
				$url = $this->getCopyUrl(Config("TABLE_SHOW_DETAIL") . "=loanapplied");
				$btngrp .= "<a href=\"#\" class=\"mr-2\" title=\"" . HtmlTitle($caption) . "\" onclick=\"window.location='" . HtmlEncode($url) . "';return false;\">" . $caption . "</a>";
			}
			$btngrp .= "</div>";
			if ($link != "") {
				$btngrps .= $btngrp;
				$option->Body .= "<div class=\"d-none ew-preview\">" . $link . $btngrp . "</div>";
			}
		}
		$sqlwrk = "`loanid`=" . AdjustSql($this->loanid->CurrentValue, $this->Dbid) . "";
		$sqlwrk = $sqlwrk . " AND " . "`currcode`='" . AdjustSql($this->currcode->CurrentValue, $this->Dbid) . "'";

		// Column "detail_loanpayments"
		if ($this->DetailPages && $this->DetailPages["loanpayments"] && $this->DetailPages["loanpayments"]->Visible) {
			$link = "";
			$option = $this->ListOptions["detail_loanpayments"];
			$url = "loanpaymentspreview.php?t=loanissued&f=" . Encrypt($sqlwrk);
			$btngrp = "<div data-table=\"loanpayments\" data-url=\"" . $url . "\">";
			if ($Security->allowList(CurrentProjectID() . 'loanissued')) {
				$label = $Language->TablePhrase("loanpayments", "TblCaption");
				$label .= "&nbsp;" . JsEncode(str_replace("%c", $this->loanpayments_Count, $Language->phrase("DetailCount")));
				$link = "<li class=\"nav-item\"><a href=\"#\" class=\"nav-link\" data-toggle=\"tab\" data-table=\"loanpayments\" data-url=\"" . $url . "\">" . $label . "</a></li>";
				$links .= $link;
				$detaillnk = JsEncodeAttribute("loanpaymentslist.php?" . Config("TABLE_SHOW_MASTER") . "=loanissued&fk_loanid=" . urlencode(strval($this->loanid->CurrentValue)) . "&fk_currcode=" . urlencode(strval($this->currcode->CurrentValue)) . "");
				$btngrp .= "<a href=\"#\" class=\"mr-2\" title=\"" . $Language->TablePhrase("loanpayments", "TblCaption") . "\" onclick=\"window.location='" . $detaillnk . "';return false;\">" . $Language->phrase("MasterDetailListLink") . "</a>";
			}
			if (!isset($GLOBALS["loanpayments_grid"]))
				$GLOBALS["loanpayments_grid"] = new loanpayments_grid();
			if ($GLOBALS["loanpayments_grid"]->DetailView && $Security->canView() && $Security->allowView(CurrentProjectID() . 'loanissued')) {
				$caption = $Language->phrase("MasterDetailViewLink");
				$url = $this->getViewUrl(Config("TABLE_SHOW_DETAIL") . "=loanpayments");
				$btngrp .= "<a href=\"#\" class=\"mr-2\" title=\"" . HtmlTitle($caption) . "\" onclick=\"window.location='" . HtmlEncode($url) . "';return false;\">" . $caption . "</a>";
			}
			if ($GLOBALS["loanpayments_grid"]->DetailEdit && $Security->canEdit() && $Security->allowEdit(CurrentProjectID() . 'loanissued')) {
				$caption = $Language->phrase("MasterDetailEditLink");
				$url = $this->getEditUrl(Config("TABLE_SHOW_DETAIL") . "=loanpayments");
				$btngrp .= "<a href=\"#\" class=\"mr-2\" title=\"" . HtmlTitle($caption) . "\" onclick=\"window.location='" . HtmlEncode($url) . "';return false;\">" . $caption . "</a>";
			}
			if ($GLOBALS["loanpayments_grid"]->DetailAdd && $Security->canAdd() && $Security->allowAdd(CurrentProjectID() . 'loanissued')) {
				$caption = $Language->phrase("MasterDetailCopyLink");
				$url = $this->getCopyUrl(Config("TABLE_SHOW_DETAIL") . "=loanpayments");
				$btngrp .= "<a href=\"#\" class=\"mr-2\" title=\"" . HtmlTitle($caption) . "\" onclick=\"window.location='" . HtmlEncode($url) . "';return false;\">" . $caption . "</a>";
			}
			$btngrp .= "</div>";
			if ($link != "") {
				$btngrps .= $btngrp;
				$option->Body .= "<div class=\"d-none ew-preview\">" . $link . $btngrp . "</div>";
			}
		}
		$sqlwrk = "`loanid`=" . AdjustSql($this->loanid->CurrentValue, $this->Dbid) . "";

		// Column "detail_loanpaymentplan"
		if ($this->DetailPages && $this->DetailPages["loanpaymentplan"] && $this->DetailPages["loanpaymentplan"]->Visible) {
			$link = "";
			$option = $this->ListOptions["detail_loanpaymentplan"];
			$url = "loanpaymentplanpreview.php?t=loanissued&f=" . Encrypt($sqlwrk);
			$btngrp = "<div data-table=\"loanpaymentplan\" data-url=\"" . $url . "\">";
			if ($Security->allowList(CurrentProjectID() . 'loanissued')) {
				$label = $Language->TablePhrase("loanpaymentplan", "TblCaption");
				$label .= "&nbsp;" . JsEncode(str_replace("%c", $this->loanpaymentplan_Count, $Language->phrase("DetailCount")));
				$link = "<li class=\"nav-item\"><a href=\"#\" class=\"nav-link\" data-toggle=\"tab\" data-table=\"loanpaymentplan\" data-url=\"" . $url . "\">" . $label . "</a></li>";
				$links .= $link;
				$detaillnk = JsEncodeAttribute("loanpaymentplanlist.php?" . Config("TABLE_SHOW_MASTER") . "=loanissued&fk_loanid=" . urlencode(strval($this->loanid->CurrentValue)) . "");
				$btngrp .= "<a href=\"#\" class=\"mr-2\" title=\"" . $Language->TablePhrase("loanpaymentplan", "TblCaption") . "\" onclick=\"window.location='" . $detaillnk . "';return false;\">" . $Language->phrase("MasterDetailListLink") . "</a>";
			}
			if (!isset($GLOBALS["loanpaymentplan_grid"]))
				$GLOBALS["loanpaymentplan_grid"] = new loanpaymentplan_grid();
			if ($GLOBALS["loanpaymentplan_grid"]->DetailView && $Security->canView() && $Security->allowView(CurrentProjectID() . 'loanissued')) {
				$caption = $Language->phrase("MasterDetailViewLink");
				$url = $this->getViewUrl(Config("TABLE_SHOW_DETAIL") . "=loanpaymentplan");
				$btngrp .= "<a href=\"#\" class=\"mr-2\" title=\"" . HtmlTitle($caption) . "\" onclick=\"window.location='" . HtmlEncode($url) . "';return false;\">" . $caption . "</a>";
			}
			if ($GLOBALS["loanpaymentplan_grid"]->DetailEdit && $Security->canEdit() && $Security->allowEdit(CurrentProjectID() . 'loanissued')) {
				$caption = $Language->phrase("MasterDetailEditLink");
				$url = $this->getEditUrl(Config("TABLE_SHOW_DETAIL") . "=loanpaymentplan");
				$btngrp .= "<a href=\"#\" class=\"mr-2\" title=\"" . HtmlTitle($caption) . "\" onclick=\"window.location='" . HtmlEncode($url) . "';return false;\">" . $caption . "</a>";
			}
			if ($GLOBALS["loanpaymentplan_grid"]->DetailAdd && $Security->canAdd() && $Security->allowAdd(CurrentProjectID() . 'loanissued')) {
				$caption = $Language->phrase("MasterDetailCopyLink");
				$url = $this->getCopyUrl(Config("TABLE_SHOW_DETAIL") . "=loanpaymentplan");
				$btngrp .= "<a href=\"#\" class=\"mr-2\" title=\"" . HtmlTitle($caption) . "\" onclick=\"window.location='" . HtmlEncode($url) . "';return false;\">" . $caption . "</a>";
			}
			$btngrp .= "</div>";
			if ($link != "") {
				$btngrps .= $btngrp;
				$option->Body .= "<div class=\"d-none ew-preview\">" . $link . $btngrp . "</div>";
			}
		}

		// Hide detail items if necessary
		$this->ListOptions->hideDetailItemsForDropDown();

		// Column "preview"
		$option = $this->ListOptions["preview"];
		if (!$option) { // Add preview column
			$option = &$this->ListOptions->add("preview");
			$option->OnLeft = FALSE;
			if ($option->OnLeft) {
				$option->moveTo($this->ListOptions->itemPos("checkbox") + 1);
			} else {
				$option->moveTo($this->ListOptions->itemPos("checkbox"));
			}
			$option->Visible = !($this->isExport() || $this->isGridAdd() || $this->isGridEdit());
			$option->ShowInDropDown = FALSE;
			$option->ShowInButtonGroup = FALSE;
		}
		if ($option) {
			$option->Body = "<i class=\"ew-preview-row-btn ew-icon icon-expand\"></i>";
			$option->Body .= "<div class=\"d-none ew-preview\">" . $links . $btngrps . "</div>";
			if ($option->Visible)
				$option->Visible = $links != "";
		}

		// Column "details" (Multiple details)
		$option = $this->ListOptions["details"];
		if ($option) {
			$option->Body .= "<div class=\"d-none ew-preview\">" . $links . $btngrps . "</div>";
			if ($option->Visible)
				$option->Visible = $links != "";
		}
	}

	// Load search values for validation
	protected function loadSearchValues()
	{

		// Load search values
		$got = FALSE;

		// loanid
		if (!$this->isAddOrEdit() && $this->loanid->AdvancedSearch->get()) {
			$got = TRUE;
			if (($this->loanid->AdvancedSearch->SearchValue != "" || $this->loanid->AdvancedSearch->SearchValue2 != "") && $this->Command == "")
				$this->Command = "search";
		}

		// userid
		if (!$this->isAddOrEdit() && $this->_userid->AdvancedSearch->get()) {
			$got = TRUE;
			if (($this->_userid->AdvancedSearch->SearchValue != "" || $this->_userid->AdvancedSearch->SearchValue2 != "") && $this->Command == "")
				$this->Command = "search";
		}

		// issueddate
		if (!$this->isAddOrEdit() && $this->issueddate->AdvancedSearch->get()) {
			$got = TRUE;
			if (($this->issueddate->AdvancedSearch->SearchValue != "" || $this->issueddate->AdvancedSearch->SearchValue2 != "") && $this->Command == "")
				$this->Command = "search";
		}

		// currcode
		if (!$this->isAddOrEdit() && $this->currcode->AdvancedSearch->get()) {
			$got = TRUE;
			if (($this->currcode->AdvancedSearch->SearchValue != "" || $this->currcode->AdvancedSearch->SearchValue2 != "") && $this->Command == "")
				$this->Command = "search";
		}

		// issuedamount
		if (!$this->isAddOrEdit() && $this->issuedamount->AdvancedSearch->get()) {
			$got = TRUE;
			if (($this->issuedamount->AdvancedSearch->SearchValue != "" || $this->issuedamount->AdvancedSearch->SearchValue2 != "") && $this->Command == "")
				$this->Command = "search";
		}

		// externalrefno
		if (!$this->isAddOrEdit() && $this->externalrefno->AdvancedSearch->get()) {
			$got = TRUE;
			if (($this->externalrefno->AdvancedSearch->SearchValue != "" || $this->externalrefno->AdvancedSearch->SearchValue2 != "") && $this->Command == "")
				$this->Command = "search";
		}

		// fullypaidind
		if (!$this->isAddOrEdit() && $this->fullypaidind->AdvancedSearch->get()) {
			$got = TRUE;
			if (($this->fullypaidind->AdvancedSearch->SearchValue != "" || $this->fullypaidind->AdvancedSearch->SearchValue2 != "") && $this->Command == "")
				$this->Command = "search";
		}

		// bankcode
		if (!$this->isAddOrEdit() && $this->bankcode->AdvancedSearch->get()) {
			$got = TRUE;
			if (($this->bankcode->AdvancedSearch->SearchValue != "" || $this->bankcode->AdvancedSearch->SearchValue2 != "") && $this->Command == "")
				$this->Command = "search";
		}

		// feeperc
		if (!$this->isAddOrEdit() && $this->feeperc->AdvancedSearch->get()) {
			$got = TRUE;
			if (($this->feeperc->AdvancedSearch->SearchValue != "" || $this->feeperc->AdvancedSearch->SearchValue2 != "") && $this->Command == "")
				$this->Command = "search";
		}

		// feeamount
		if (!$this->isAddOrEdit() && $this->feeamount->AdvancedSearch->get()) {
			$got = TRUE;
			if (($this->feeamount->AdvancedSearch->SearchValue != "" || $this->feeamount->AdvancedSearch->SearchValue2 != "") && $this->Command == "")
				$this->Command = "search";
		}

		// taxperc
		if (!$this->isAddOrEdit() && $this->taxperc->AdvancedSearch->get()) {
			$got = TRUE;
			if (($this->taxperc->AdvancedSearch->SearchValue != "" || $this->taxperc->AdvancedSearch->SearchValue2 != "") && $this->Command == "")
				$this->Command = "search";
		}

		// taxamount
		if (!$this->isAddOrEdit() && $this->taxamount->AdvancedSearch->get()) {
			$got = TRUE;
			if (($this->taxamount->AdvancedSearch->SearchValue != "" || $this->taxamount->AdvancedSearch->SearchValue2 != "") && $this->Command == "")
				$this->Command = "search";
		}

		// totalamount
		if (!$this->isAddOrEdit() && $this->totalamount->AdvancedSearch->get()) {
			$got = TRUE;
			if (($this->totalamount->AdvancedSearch->SearchValue != "" || $this->totalamount->AdvancedSearch->SearchValue2 != "") && $this->Command == "")
				$this->Command = "search";
		}

		// paymenttargetdate
		if (!$this->isAddOrEdit() && $this->paymenttargetdate->AdvancedSearch->get()) {
			$got = TRUE;
			if (($this->paymenttargetdate->AdvancedSearch->SearchValue != "" || $this->paymenttargetdate->AdvancedSearch->SearchValue2 != "") && $this->Command == "")
				$this->Command = "search";
		}

		// feefixed
		if (!$this->isAddOrEdit() && $this->feefixed->AdvancedSearch->get()) {
			$got = TRUE;
			if (($this->feefixed->AdvancedSearch->SearchValue != "" || $this->feefixed->AdvancedSearch->SearchValue2 != "") && $this->Command == "")
				$this->Command = "search";
		}

		// totalfees
		if (!$this->isAddOrEdit() && $this->totalfees->AdvancedSearch->get()) {
			$got = TRUE;
			if (($this->totalfees->AdvancedSearch->SearchValue != "" || $this->totalfees->AdvancedSearch->SearchValue2 != "") && $this->Command == "")
				$this->Command = "search";
		}

		// approveruserid
		if (!$this->isAddOrEdit() && $this->approveruserid->AdvancedSearch->get()) {
			$got = TRUE;
			if (($this->approveruserid->AdvancedSearch->SearchValue != "" || $this->approveruserid->AdvancedSearch->SearchValue2 != "") && $this->Command == "")
				$this->Command = "search";
		}

		// docid
		if (!$this->isAddOrEdit() && $this->docid->AdvancedSearch->get()) {
			$got = TRUE;
			if (($this->docid->AdvancedSearch->SearchValue != "" || $this->docid->AdvancedSearch->SearchValue2 != "") && $this->Command == "")
				$this->Command = "search";
		}

		// feesystemtotal
		if (!$this->isAddOrEdit() && $this->feesystemtotal->AdvancedSearch->get()) {
			$got = TRUE;
			if (($this->feesystemtotal->AdvancedSearch->SearchValue != "" || $this->feesystemtotal->AdvancedSearch->SearchValue2 != "") && $this->Command == "")
				$this->Command = "search";
		}

		// feeexternaltotal
		if (!$this->isAddOrEdit() && $this->feeexternaltotal->AdvancedSearch->get()) {
			$got = TRUE;
			if (($this->feeexternaltotal->AdvancedSearch->SearchValue != "" || $this->feeexternaltotal->AdvancedSearch->SearchValue2 != "") && $this->Command == "")
				$this->Command = "search";
		}

		// feefranchiseetotal
		if (!$this->isAddOrEdit() && $this->feefranchiseetotal->AdvancedSearch->get()) {
			$got = TRUE;
			if (($this->feefranchiseetotal->AdvancedSearch->SearchValue != "" || $this->feefranchiseetotal->AdvancedSearch->SearchValue2 != "") && $this->Command == "")
				$this->Command = "search";
		}

		// feeresellertotal
		if (!$this->isAddOrEdit() && $this->feeresellertotal->AdvancedSearch->get()) {
			$got = TRUE;
			if (($this->feeresellertotal->AdvancedSearch->SearchValue != "" || $this->feeresellertotal->AdvancedSearch->SearchValue2 != "") && $this->Command == "")
				$this->Command = "search";
		}

		// purchasefeeid
		if (!$this->isAddOrEdit() && $this->purchasefeeid->AdvancedSearch->get()) {
			$got = TRUE;
			if (($this->purchasefeeid->AdvancedSearch->SearchValue != "" || $this->purchasefeeid->AdvancedSearch->SearchValue2 != "") && $this->Command == "")
				$this->Command = "search";
		}

		// cancellationrefid
		if (!$this->isAddOrEdit() && $this->cancellationrefid->AdvancedSearch->get()) {
			$got = TRUE;
			if (($this->cancellationrefid->AdvancedSearch->SearchValue != "" || $this->cancellationrefid->AdvancedSearch->SearchValue2 != "") && $this->Command == "")
				$this->Command = "search";
		}

		// cancellationdatetime
		if (!$this->isAddOrEdit() && $this->cancellationdatetime->AdvancedSearch->get()) {
			$got = TRUE;
			if (($this->cancellationdatetime->AdvancedSearch->SearchValue != "" || $this->cancellationdatetime->AdvancedSearch->SearchValue2 != "") && $this->Command == "")
				$this->Command = "search";
		}

		// cancellationreason
		if (!$this->isAddOrEdit() && $this->cancellationreason->AdvancedSearch->get()) {
			$got = TRUE;
			if (($this->cancellationreason->AdvancedSearch->SearchValue != "" || $this->cancellationreason->AdvancedSearch->SearchValue2 != "") && $this->Command == "")
				$this->Command = "search";
		}

		// lastupdatedate
		if (!$this->isAddOrEdit() && $this->lastupdatedate->AdvancedSearch->get()) {
			$got = TRUE;
			if (($this->lastupdatedate->AdvancedSearch->SearchValue != "" || $this->lastupdatedate->AdvancedSearch->SearchValue2 != "") && $this->Command == "")
				$this->Command = "search";
		}

		// feeexternaltotaltime
		if (!$this->isAddOrEdit() && $this->feeexternaltotaltime->AdvancedSearch->get()) {
			$got = TRUE;
			if (($this->feeexternaltotaltime->AdvancedSearch->SearchValue != "" || $this->feeexternaltotaltime->AdvancedSearch->SearchValue2 != "") && $this->Command == "")
				$this->Command = "search";
		}

		// totalamountapplied
		if (!$this->isAddOrEdit() && $this->totalamountapplied->AdvancedSearch->get()) {
			$got = TRUE;
			if (($this->totalamountapplied->AdvancedSearch->SearchValue != "" || $this->totalamountapplied->AdvancedSearch->SearchValue2 != "") && $this->Command == "")
				$this->Command = "search";
		}

		// totalfeesapplied
		if (!$this->isAddOrEdit() && $this->totalfeesapplied->AdvancedSearch->get()) {
			$got = TRUE;
			if (($this->totalfeesapplied->AdvancedSearch->SearchValue != "" || $this->totalfeesapplied->AdvancedSearch->SearchValue2 != "") && $this->Command == "")
				$this->Command = "search";
		}

		// totalprincipleandfees
		if (!$this->isAddOrEdit() && $this->totalprincipleandfees->AdvancedSearch->get()) {
			$got = TRUE;
			if (($this->totalprincipleandfees->AdvancedSearch->SearchValue != "" || $this->totalprincipleandfees->AdvancedSearch->SearchValue2 != "") && $this->Command == "")
				$this->Command = "search";
		}

		// taxamountbreakdown
		if (!$this->isAddOrEdit() && $this->taxamountbreakdown->AdvancedSearch->get()) {
			$got = TRUE;
			if (($this->taxamountbreakdown->AdvancedSearch->SearchValue != "" || $this->taxamountbreakdown->AdvancedSearch->SearchValue2 != "") && $this->Command == "")
				$this->Command = "search";
		}

		// feesystembreakdown
		if (!$this->isAddOrEdit() && $this->feesystembreakdown->AdvancedSearch->get()) {
			$got = TRUE;
			if (($this->feesystembreakdown->AdvancedSearch->SearchValue != "" || $this->feesystembreakdown->AdvancedSearch->SearchValue2 != "") && $this->Command == "")
				$this->Command = "search";
		}

		// feeexternalbreakdown
		if (!$this->isAddOrEdit() && $this->feeexternalbreakdown->AdvancedSearch->get()) {
			$got = TRUE;
			if (($this->feeexternalbreakdown->AdvancedSearch->SearchValue != "" || $this->feeexternalbreakdown->AdvancedSearch->SearchValue2 != "") && $this->Command == "")
				$this->Command = "search";
		}

		// feefranchiseebreakdown
		if (!$this->isAddOrEdit() && $this->feefranchiseebreakdown->AdvancedSearch->get()) {
			$got = TRUE;
			if (($this->feefranchiseebreakdown->AdvancedSearch->SearchValue != "" || $this->feefranchiseebreakdown->AdvancedSearch->SearchValue2 != "") && $this->Command == "")
				$this->Command = "search";
		}

		// feeresellerbreakdown
		if (!$this->isAddOrEdit() && $this->feeresellerbreakdown->AdvancedSearch->get()) {
			$got = TRUE;
			if (($this->feeresellerbreakdown->AdvancedSearch->SearchValue != "" || $this->feeresellerbreakdown->AdvancedSearch->SearchValue2 != "") && $this->Command == "")
				$this->Command = "search";
		}

		// outstandingprinciple
		if (!$this->isAddOrEdit() && $this->outstandingprinciple->AdvancedSearch->get()) {
			$got = TRUE;
			if (($this->outstandingprinciple->AdvancedSearch->SearchValue != "" || $this->outstandingprinciple->AdvancedSearch->SearchValue2 != "") && $this->Command == "")
				$this->Command = "search";
		}

		// outstandingfees
		if (!$this->isAddOrEdit() && $this->outstandingfees->AdvancedSearch->get()) {
			$got = TRUE;
			if (($this->outstandingfees->AdvancedSearch->SearchValue != "" || $this->outstandingfees->AdvancedSearch->SearchValue2 != "") && $this->Command == "")
				$this->Command = "search";
		}

		// outstandingprincipleandfees
		if (!$this->isAddOrEdit() && $this->outstandingprincipleandfees->AdvancedSearch->get()) {
			$got = TRUE;
			if (($this->outstandingprincipleandfees->AdvancedSearch->SearchValue != "" || $this->outstandingprincipleandfees->AdvancedSearch->SearchValue2 != "") && $this->Command == "")
				$this->Command = "search";
		}

		// lastupdate
		if (!$this->isAddOrEdit() && $this->lastupdate->AdvancedSearch->get()) {
			$got = TRUE;
			if (($this->lastupdate->AdvancedSearch->SearchValue != "" || $this->lastupdate->AdvancedSearch->SearchValue2 != "") && $this->Command == "")
				$this->Command = "search";
		}

		// externalprovisioningrefno
		if (!$this->isAddOrEdit() && $this->externalprovisioningrefno->AdvancedSearch->get()) {
			$got = TRUE;
			if (($this->externalprovisioningrefno->AdvancedSearch->SearchValue != "" || $this->externalprovisioningrefno->AdvancedSearch->SearchValue2 != "") && $this->Command == "")
				$this->Command = "search";
		}

		// loantype
		if (!$this->isAddOrEdit() && $this->loantype->AdvancedSearch->get()) {
			$got = TRUE;
			if (($this->loantype->AdvancedSearch->SearchValue != "" || $this->loantype->AdvancedSearch->SearchValue2 != "") && $this->Command == "")
				$this->Command = "search";
		}

		// numberofoutstandingdays
		if (!$this->isAddOrEdit() && $this->numberofoutstandingdays->AdvancedSearch->get()) {
			$got = TRUE;
			if (($this->numberofoutstandingdays->AdvancedSearch->SearchValue != "" || $this->numberofoutstandingdays->AdvancedSearch->SearchValue2 != "") && $this->Command == "")
				$this->Command = "search";
		}

		// loandue
		if (!$this->isAddOrEdit() && $this->loandue->AdvancedSearch->get()) {
			$got = TRUE;
			if (($this->loandue->AdvancedSearch->SearchValue != "" || $this->loandue->AdvancedSearch->SearchValue2 != "") && $this->Command == "")
				$this->Command = "search";
		}

		// loanduedate
		if (!$this->isAddOrEdit() && $this->loanduedate->AdvancedSearch->get()) {
			$got = TRUE;
			if (($this->loanduedate->AdvancedSearch->SearchValue != "" || $this->loanduedate->AdvancedSearch->SearchValue2 != "") && $this->Command == "")
				$this->Command = "search";
		}

		// outstandinglatefees
		if (!$this->isAddOrEdit() && $this->outstandinglatefees->AdvancedSearch->get()) {
			$got = TRUE;
			if (($this->outstandinglatefees->AdvancedSearch->SearchValue != "" || $this->outstandinglatefees->AdvancedSearch->SearchValue2 != "") && $this->Command == "")
				$this->Command = "search";
		}

		// disbursementtype
		if (!$this->isAddOrEdit() && $this->disbursementtype->AdvancedSearch->get()) {
			$got = TRUE;
			if (($this->disbursementtype->AdvancedSearch->SearchValue != "" || $this->disbursementtype->AdvancedSearch->SearchValue2 != "") && $this->Command == "")
				$this->Command = "search";
		}

		// disbursementamount
		if (!$this->isAddOrEdit() && $this->disbursementamount->AdvancedSearch->get()) {
			$got = TRUE;
			if (($this->disbursementamount->AdvancedSearch->SearchValue != "" || $this->disbursementamount->AdvancedSearch->SearchValue2 != "") && $this->Command == "")
				$this->Command = "search";
		}

		// loanconfirmed
		if (!$this->isAddOrEdit() && $this->loanconfirmed->AdvancedSearch->get()) {
			$got = TRUE;
			if (($this->loanconfirmed->AdvancedSearch->SearchValue != "" || $this->loanconfirmed->AdvancedSearch->SearchValue2 != "") && $this->Command == "")
				$this->Command = "search";
		}

		// loanconfirmedtime
		if (!$this->isAddOrEdit() && $this->loanconfirmedtime->AdvancedSearch->get()) {
			$got = TRUE;
			if (($this->loanconfirmedtime->AdvancedSearch->SearchValue != "" || $this->loanconfirmedtime->AdvancedSearch->SearchValue2 != "") && $this->Command == "")
				$this->Command = "search";
		}

		// loanupgraded
		if (!$this->isAddOrEdit() && $this->loanupgraded->AdvancedSearch->get()) {
			$got = TRUE;
			if (($this->loanupgraded->AdvancedSearch->SearchValue != "" || $this->loanupgraded->AdvancedSearch->SearchValue2 != "") && $this->Command == "")
				$this->Command = "search";
		}

		// stoplatefee
		if (!$this->isAddOrEdit() && $this->stoplatefee->AdvancedSearch->get()) {
			$got = TRUE;
			if (($this->stoplatefee->AdvancedSearch->SearchValue != "" || $this->stoplatefee->AdvancedSearch->SearchValue2 != "") && $this->Command == "")
				$this->Command = "search";
		}

		// otherdetails1
		if (!$this->isAddOrEdit() && $this->otherdetails1->AdvancedSearch->get()) {
			$got = TRUE;
			if (($this->otherdetails1->AdvancedSearch->SearchValue != "" || $this->otherdetails1->AdvancedSearch->SearchValue2 != "") && $this->Command == "")
				$this->Command = "search";
		}

		// lockflag
		if (!$this->isAddOrEdit() && $this->lockflag->AdvancedSearch->get()) {
			$got = TRUE;
			if (($this->lockflag->AdvancedSearch->SearchValue != "" || $this->lockflag->AdvancedSearch->SearchValue2 != "") && $this->Command == "")
				$this->Command = "search";
		}

		// lastlatefeecalculatedate
		if (!$this->isAddOrEdit() && $this->lastlatefeecalculatedate->AdvancedSearch->get()) {
			$got = TRUE;
			if (($this->lastlatefeecalculatedate->AdvancedSearch->SearchValue != "" || $this->lastlatefeecalculatedate->AdvancedSearch->SearchValue2 != "") && $this->Command == "")
				$this->Command = "search";
		}

		// notificationlockflag
		if (!$this->isAddOrEdit() && $this->notificationlockflag->AdvancedSearch->get()) {
			$got = TRUE;
			if (($this->notificationlockflag->AdvancedSearch->SearchValue != "" || $this->notificationlockflag->AdvancedSearch->SearchValue2 != "") && $this->Command == "")
				$this->Command = "search";
		}

		// lastnotificationdate
		if (!$this->isAddOrEdit() && $this->lastnotificationdate->AdvancedSearch->get()) {
			$got = TRUE;
			if (($this->lastnotificationdate->AdvancedSearch->SearchValue != "" || $this->lastnotificationdate->AdvancedSearch->SearchValue2 != "") && $this->Command == "")
				$this->Command = "search";
		}

		// sendnotificationtextdate
		if (!$this->isAddOrEdit() && $this->sendnotificationtextdate->AdvancedSearch->get()) {
			$got = TRUE;
			if (($this->sendnotificationtextdate->AdvancedSearch->SearchValue != "" || $this->sendnotificationtextdate->AdvancedSearch->SearchValue2 != "") && $this->Command == "")
				$this->Command = "search";
		}

		// termtype
		if (!$this->isAddOrEdit() && $this->termtype->AdvancedSearch->get()) {
			$got = TRUE;
			if (($this->termtype->AdvancedSearch->SearchValue != "" || $this->termtype->AdvancedSearch->SearchValue2 != "") && $this->Command == "")
				$this->Command = "search";
		}
		return $got;
	}

	// Load recordset
	public function loadRecordset($offset = -1, $rowcnt = -1)
	{

		// Load List page SQL
		$sql = $this->getListSql();
		$conn = $this->getConnection();

		// Load recordset
		$dbtype = GetConnectionType($this->Dbid);
		if ($this->UseSelectLimit) {
			$conn->raiseErrorFn = Config("ERROR_FUNC");
			if ($dbtype == "MSSQL") {
				$rs = $conn->selectLimit($sql, $rowcnt, $offset, ["_hasOrderBy" => trim($this->getOrderBy()) || trim($this->getSessionOrderBy())]);
			} else {
				$rs = $conn->selectLimit($sql, $rowcnt, $offset);
			}
			$conn->raiseErrorFn = "";
		} else {
			$rs = LoadRecordset($sql, $conn);
		}

		// Call Recordset Selected event
		$this->Recordset_Selected($rs);
		return $rs;
	}

	// Load row based on key values
	public function loadRow()
	{
		global $Security, $Language;
		$filter = $this->getRecordFilter();

		// Call Row Selecting event
		$this->Row_Selecting($filter);

		// Load SQL based on filter
		$this->CurrentFilter = $filter;
		$sql = $this->getCurrentSql();
		$conn = $this->getConnection();
		$res = FALSE;
		$rs = LoadRecordset($sql, $conn);
		if ($rs && !$rs->EOF) {
			$res = TRUE;
			$this->loadRowValues($rs); // Load row values
			$rs->close();
		}
		return $res;
	}

	// Load row values from recordset
	public function loadRowValues($rs = NULL)
	{
		if ($rs && !$rs->EOF)
			$row = $rs->fields;
		else
			$row = $this->newRow();

		// Call Row Selected event
		$this->Row_Selected($row);
		if (!$rs || $rs->EOF)
			return;
		$this->loanid->setDbValue($row['loanid']);
		$this->_userid->setDbValue($row['userid']);
		$this->issueddate->setDbValue($row['issueddate']);
		$this->currcode->setDbValue($row['currcode']);
		$this->issuedamount->setDbValue($row['issuedamount']);
		$this->externalrefno->setDbValue($row['externalrefno']);
		$this->fullypaidind->setDbValue($row['fullypaidind']);
		$this->bankcode->setDbValue($row['bankcode']);
		$this->feeperc->setDbValue($row['feeperc']);
		$this->feeamount->setDbValue($row['feeamount']);
		$this->taxperc->setDbValue($row['taxperc']);
		$this->taxamount->setDbValue($row['taxamount']);
		$this->totalamount->setDbValue($row['totalamount']);
		$this->paymenttargetdate->setDbValue($row['paymenttargetdate']);
		$this->feefixed->setDbValue($row['feefixed']);
		$this->totalfees->setDbValue($row['totalfees']);
		$this->approveruserid->setDbValue($row['approveruserid']);
		$this->docid->setDbValue($row['docid']);
		$this->feesystemtotal->setDbValue($row['feesystemtotal']);
		$this->feeexternaltotal->setDbValue($row['feeexternaltotal']);
		$this->feefranchiseetotal->setDbValue($row['feefranchiseetotal']);
		$this->feeresellertotal->setDbValue($row['feeresellertotal']);
		$this->purchasefeeid->setDbValue($row['purchasefeeid']);
		$this->cancellationrefid->setDbValue($row['cancellationrefid']);
		$this->cancellationdatetime->setDbValue($row['cancellationdatetime']);
		$this->cancellationreason->setDbValue($row['cancellationreason']);
		$this->lastupdatedate->setDbValue($row['lastupdatedate']);
		$this->feeexternaltotaltime->setDbValue($row['feeexternaltotaltime']);
		$this->totalamountapplied->setDbValue($row['totalamountapplied']);
		$this->totalfeesapplied->setDbValue($row['totalfeesapplied']);
		$this->totalprincipleandfees->setDbValue($row['totalprincipleandfees']);
		$this->taxamountbreakdown->setDbValue($row['taxamountbreakdown']);
		$this->feesystembreakdown->setDbValue($row['feesystembreakdown']);
		$this->feeexternalbreakdown->setDbValue($row['feeexternalbreakdown']);
		$this->feefranchiseebreakdown->setDbValue($row['feefranchiseebreakdown']);
		$this->feeresellerbreakdown->setDbValue($row['feeresellerbreakdown']);
		$this->outstandingprinciple->setDbValue($row['outstandingprinciple']);
		$this->outstandingfees->setDbValue($row['outstandingfees']);
		$this->outstandingprincipleandfees->setDbValue($row['outstandingprincipleandfees']);
		$this->lastupdate->setDbValue($row['lastupdate']);
		$this->externalprovisioningrefno->setDbValue($row['externalprovisioningrefno']);
		$this->loantype->setDbValue($row['loantype']);
		$this->numberofoutstandingdays->setDbValue($row['numberofoutstandingdays']);
		$this->loandue->setDbValue($row['loandue']);
		$this->loanduedate->setDbValue($row['loanduedate']);
		$this->outstandinglatefees->setDbValue($row['outstandinglatefees']);
		$this->disbursementtype->setDbValue($row['disbursementtype']);
		$this->disbursementamount->setDbValue($row['disbursementamount']);
		$this->loanconfirmed->setDbValue($row['loanconfirmed']);
		$this->loanconfirmedtime->setDbValue($row['loanconfirmedtime']);
		$this->loanupgraded->setDbValue($row['loanupgraded']);
		$this->stoplatefee->setDbValue($row['stoplatefee']);
		$this->otherdetails1->setDbValue($row['otherdetails1']);
		$this->lockflag->setDbValue($row['lockflag']);
		$this->lastlatefeecalculatedate->setDbValue($row['lastlatefeecalculatedate']);
		$this->notificationlockflag->setDbValue($row['notificationlockflag']);
		$this->lastnotificationdate->setDbValue($row['lastnotificationdate']);
		$this->sendnotificationtextdate->setDbValue($row['sendnotificationtextdate']);
		$this->termtype->setDbValue($row['termtype']);
		if (!isset($GLOBALS["loanissuedupgrades_grid"]))
			$GLOBALS["loanissuedupgrades_grid"] = new loanissuedupgrades_grid();
		$detailFilter = $GLOBALS["loanissuedupgrades"]->sqlDetailFilter_loanissued();
		$detailFilter = str_replace("@loanid@", AdjustSql($this->loanid->DbValue, "DB"), $detailFilter);
		$GLOBALS["loanissuedupgrades"]->setCurrentMasterTable("loanissued");
		$detailFilter = $GLOBALS["loanissuedupgrades"]->applyUserIDFilters($detailFilter);
		$this->loanissuedupgrades_Count = $GLOBALS["loanissuedupgrades"]->loadRecordCount($detailFilter);
		if (!isset($GLOBALS["loaneventhistory_grid"]))
			$GLOBALS["loaneventhistory_grid"] = new loaneventhistory_grid();
		$detailFilter = $GLOBALS["loaneventhistory"]->sqlDetailFilter_loanissued();
		$detailFilter = str_replace("@_userid@", AdjustSql($this->loanid->DbValue, "DB"), $detailFilter);
		$GLOBALS["loaneventhistory"]->setCurrentMasterTable("loanissued");
		$detailFilter = $GLOBALS["loaneventhistory"]->applyUserIDFilters($detailFilter);
		$this->loaneventhistory_Count = $GLOBALS["loaneventhistory"]->loadRecordCount($detailFilter);
		if (!isset($GLOBALS["loanlatefees_grid"]))
			$GLOBALS["loanlatefees_grid"] = new loanlatefees_grid();
		$detailFilter = $GLOBALS["loanlatefees"]->sqlDetailFilter_loanissued();
		$detailFilter = str_replace("@loanid@", AdjustSql($this->loanid->DbValue, "DB"), $detailFilter);
		$detailFilter = str_replace("@currcode@", AdjustSql($this->currcode->DbValue, "DB"), $detailFilter);
		$detailFilter = str_replace("@_userid@", AdjustSql($this->_userid->DbValue, "DB"), $detailFilter);
		$GLOBALS["loanlatefees"]->setCurrentMasterTable("loanissued");
		$detailFilter = $GLOBALS["loanlatefees"]->applyUserIDFilters($detailFilter);
		$this->loanlatefees_Count = $GLOBALS["loanlatefees"]->loadRecordCount($detailFilter);
		if (!isset($GLOBALS["loanapplied_grid"]))
			$GLOBALS["loanapplied_grid"] = new loanapplied_grid();
		$detailFilter = $GLOBALS["loanapplied"]->sqlDetailFilter_loanissued();
		$detailFilter = str_replace("@loanid@", AdjustSql($this->loanid->DbValue, "DB"), $detailFilter);
		$GLOBALS["loanapplied"]->setCurrentMasterTable("loanissued");
		$detailFilter = $GLOBALS["loanapplied"]->applyUserIDFilters($detailFilter);
		$this->loanapplied_Count = $GLOBALS["loanapplied"]->loadRecordCount($detailFilter);
		if (!isset($GLOBALS["loanpayments_grid"]))
			$GLOBALS["loanpayments_grid"] = new loanpayments_grid();
		$detailFilter = $GLOBALS["loanpayments"]->sqlDetailFilter_loanissued();
		$detailFilter = str_replace("@loanid@", AdjustSql($this->loanid->DbValue, "DB"), $detailFilter);
		$detailFilter = str_replace("@currcode@", AdjustSql($this->currcode->DbValue, "DB"), $detailFilter);
		$GLOBALS["loanpayments"]->setCurrentMasterTable("loanissued");
		$detailFilter = $GLOBALS["loanpayments"]->applyUserIDFilters($detailFilter);
		$this->loanpayments_Count = $GLOBALS["loanpayments"]->loadRecordCount($detailFilter);
		if (!isset($GLOBALS["loanpaymentplan_grid"]))
			$GLOBALS["loanpaymentplan_grid"] = new loanpaymentplan_grid();
		$detailFilter = $GLOBALS["loanpaymentplan"]->sqlDetailFilter_loanissued();
		$detailFilter = str_replace("@loanid@", AdjustSql($this->loanid->DbValue, "DB"), $detailFilter);
		$GLOBALS["loanpaymentplan"]->setCurrentMasterTable("loanissued");
		$detailFilter = $GLOBALS["loanpaymentplan"]->applyUserIDFilters($detailFilter);
		$this->loanpaymentplan_Count = $GLOBALS["loanpaymentplan"]->loadRecordCount($detailFilter);
	}

	// Return a row with default values
	protected function newRow()
	{
		$row = [];
		$row['loanid'] = NULL;
		$row['userid'] = NULL;
		$row['issueddate'] = NULL;
		$row['currcode'] = NULL;
		$row['issuedamount'] = NULL;
		$row['externalrefno'] = NULL;
		$row['fullypaidind'] = NULL;
		$row['bankcode'] = NULL;
		$row['feeperc'] = NULL;
		$row['feeamount'] = NULL;
		$row['taxperc'] = NULL;
		$row['taxamount'] = NULL;
		$row['totalamount'] = NULL;
		$row['paymenttargetdate'] = NULL;
		$row['feefixed'] = NULL;
		$row['totalfees'] = NULL;
		$row['approveruserid'] = NULL;
		$row['docid'] = NULL;
		$row['feesystemtotal'] = NULL;
		$row['feeexternaltotal'] = NULL;
		$row['feefranchiseetotal'] = NULL;
		$row['feeresellertotal'] = NULL;
		$row['purchasefeeid'] = NULL;
		$row['cancellationrefid'] = NULL;
		$row['cancellationdatetime'] = NULL;
		$row['cancellationreason'] = NULL;
		$row['lastupdatedate'] = NULL;
		$row['feeexternaltotaltime'] = NULL;
		$row['totalamountapplied'] = NULL;
		$row['totalfeesapplied'] = NULL;
		$row['totalprincipleandfees'] = NULL;
		$row['taxamountbreakdown'] = NULL;
		$row['feesystembreakdown'] = NULL;
		$row['feeexternalbreakdown'] = NULL;
		$row['feefranchiseebreakdown'] = NULL;
		$row['feeresellerbreakdown'] = NULL;
		$row['outstandingprinciple'] = NULL;
		$row['outstandingfees'] = NULL;
		$row['outstandingprincipleandfees'] = NULL;
		$row['lastupdate'] = NULL;
		$row['externalprovisioningrefno'] = NULL;
		$row['loantype'] = NULL;
		$row['numberofoutstandingdays'] = NULL;
		$row['loandue'] = NULL;
		$row['loanduedate'] = NULL;
		$row['outstandinglatefees'] = NULL;
		$row['disbursementtype'] = NULL;
		$row['disbursementamount'] = NULL;
		$row['loanconfirmed'] = NULL;
		$row['loanconfirmedtime'] = NULL;
		$row['loanupgraded'] = NULL;
		$row['stoplatefee'] = NULL;
		$row['otherdetails1'] = NULL;
		$row['lockflag'] = NULL;
		$row['lastlatefeecalculatedate'] = NULL;
		$row['notificationlockflag'] = NULL;
		$row['lastnotificationdate'] = NULL;
		$row['sendnotificationtextdate'] = NULL;
		$row['termtype'] = NULL;
		return $row;
	}

	// Load old record
	protected function loadOldRecord()
	{

		// Load key values from Session
		$validKey = TRUE;
		if (strval($this->getKey("loanid")) != "")
			$this->loanid->OldValue = $this->getKey("loanid"); // loanid
		else
			$validKey = FALSE;

		// Load old record
		$this->OldRecordset = NULL;
		if ($validKey) {
			$this->CurrentFilter = $this->getRecordFilter();
			$sql = $this->getCurrentSql();
			$conn = $this->getConnection();
			$this->OldRecordset = LoadRecordset($sql, $conn);
		}
		$this->loadRowValues($this->OldRecordset); // Load row values
		return $validKey;
	}

	// Render row values based on field settings
	public function renderRow()
	{
		global $Security, $Language, $CurrentLanguage;

		// Initialize URLs
		$this->ViewUrl = $this->getViewUrl();
		$this->EditUrl = $this->getEditUrl();
		$this->InlineEditUrl = $this->getInlineEditUrl();
		$this->CopyUrl = $this->getCopyUrl();
		$this->InlineCopyUrl = $this->getInlineCopyUrl();
		$this->DeleteUrl = $this->getDeleteUrl();

		// Call Row_Rendering event
		$this->Row_Rendering();

		// Common render codes for all row types
		// loanid
		// userid
		// issueddate
		// currcode
		// issuedamount
		// externalrefno
		// fullypaidind
		// bankcode
		// feeperc
		// feeamount
		// taxperc
		// taxamount
		// totalamount
		// paymenttargetdate
		// feefixed
		// totalfees
		// approveruserid
		// docid
		// feesystemtotal
		// feeexternaltotal
		// feefranchiseetotal
		// feeresellertotal
		// purchasefeeid
		// cancellationrefid
		// cancellationdatetime
		// cancellationreason
		// lastupdatedate
		// feeexternaltotaltime
		// totalamountapplied
		// totalfeesapplied
		// totalprincipleandfees
		// taxamountbreakdown
		// feesystembreakdown
		// feeexternalbreakdown
		// feefranchiseebreakdown
		// feeresellerbreakdown
		// outstandingprinciple
		// outstandingfees
		// outstandingprincipleandfees
		// lastupdate
		// externalprovisioningrefno
		// loantype
		// numberofoutstandingdays
		// loandue
		// loanduedate
		// outstandinglatefees
		// disbursementtype

		$this->disbursementtype->CellCssStyle = "white-space: nowrap;";

		// disbursementamount
		$this->disbursementamount->CellCssStyle = "white-space: nowrap;";

		// loanconfirmed
		// loanconfirmedtime
		// loanupgraded
		// stoplatefee
		// otherdetails1
		// lockflag
		// lastlatefeecalculatedate
		// notificationlockflag
		// lastnotificationdate
		// sendnotificationtextdate
		// termtype

		if ($this->RowType == ROWTYPE_VIEW) { // View row

			// loanid
			$this->loanid->ViewValue = $this->loanid->CurrentValue;
			$this->loanid->ViewCustomAttributes = "";

			// userid
			$this->_userid->ViewValue = $this->_userid->CurrentValue;
			$this->_userid->ViewCustomAttributes = "";

			// issueddate
			$this->issueddate->ViewValue = $this->issueddate->CurrentValue;
			$this->issueddate->ViewValue = FormatDateTime($this->issueddate->ViewValue, 1);
			$this->issueddate->ViewCustomAttributes = "";

			// currcode
			$curVal = strval($this->currcode->CurrentValue);
			if ($curVal != "") {
				$this->currcode->ViewValue = $this->currcode->lookupCacheOption($curVal);
				if ($this->currcode->ViewValue === NULL) { // Lookup from database
					$filterWrk = "`currCode`" . SearchString("=", $curVal, DATATYPE_STRING, "_4payreference");
					$lookupFilter = function() {
						return "`langID`='EN'";
					};
					$lookupFilter = $lookupFilter->bindTo($this);
					$sqlWrk = $this->currcode->Lookup->getSql(FALSE, $filterWrk, $lookupFilter, $this);
					$rswrk = Conn("_4payreference")->execute($sqlWrk);
					if ($rswrk && !$rswrk->EOF) { // Lookup values found
						$arwrk = [];
						$arwrk[1] = $rswrk->fields('df');
						$arwrk[2] = $rswrk->fields('df2');
						$this->currcode->ViewValue = $this->currcode->displayValue($arwrk);
						$rswrk->Close();
					} else {
						$this->currcode->ViewValue = $this->currcode->CurrentValue;
					}
				}
			} else {
				$this->currcode->ViewValue = NULL;
			}
			$this->currcode->ViewCustomAttributes = "";

			// issuedamount
			$this->issuedamount->ViewValue = $this->issuedamount->CurrentValue;
			$this->issuedamount->ViewValue = FormatNumber($this->issuedamount->ViewValue, 2, -2, -2, -2);
			$this->issuedamount->ViewCustomAttributes = "";

			// externalrefno
			$this->externalrefno->ViewValue = $this->externalrefno->CurrentValue;
			$this->externalrefno->ViewCustomAttributes = "";

			// fullypaidind
			if (strval($this->fullypaidind->CurrentValue) != "") {
				$this->fullypaidind->ViewValue = $this->fullypaidind->optionCaption($this->fullypaidind->CurrentValue);
			} else {
				$this->fullypaidind->ViewValue = NULL;
			}
			$this->fullypaidind->ViewCustomAttributes = "";

			// bankcode
			$this->bankcode->ViewValue = $this->bankcode->CurrentValue;
			$this->bankcode->ViewCustomAttributes = "";

			// feeperc
			$this->feeperc->ViewValue = $this->feeperc->CurrentValue;
			$this->feeperc->ViewValue = FormatNumber($this->feeperc->ViewValue, 2, -2, -2, -2);
			$this->feeperc->ViewCustomAttributes = "";

			// feeamount
			$this->feeamount->ViewValue = $this->feeamount->CurrentValue;
			$this->feeamount->ViewValue = FormatNumber($this->feeamount->ViewValue, 2, -2, -2, -2);
			$this->feeamount->ViewCustomAttributes = "";

			// taxperc
			$this->taxperc->ViewValue = $this->taxperc->CurrentValue;
			$this->taxperc->ViewValue = FormatNumber($this->taxperc->ViewValue, 2, -2, -2, -2);
			$this->taxperc->ViewCustomAttributes = "";

			// taxamount
			$this->taxamount->ViewValue = $this->taxamount->CurrentValue;
			$this->taxamount->ViewValue = FormatNumber($this->taxamount->ViewValue, 2, -2, -2, -2);
			$this->taxamount->ViewCustomAttributes = "";

			// totalamount
			$this->totalamount->ViewValue = $this->totalamount->CurrentValue;
			$this->totalamount->ViewValue = FormatNumber($this->totalamount->ViewValue, 2, -2, -2, -2);
			$this->totalamount->ViewCustomAttributes = "";

			// paymenttargetdate
			$this->paymenttargetdate->ViewValue = $this->paymenttargetdate->CurrentValue;
			$this->paymenttargetdate->ViewValue = FormatDateTime($this->paymenttargetdate->ViewValue, 0);
			$this->paymenttargetdate->ViewCustomAttributes = "";

			// feefixed
			$this->feefixed->ViewValue = $this->feefixed->CurrentValue;
			$this->feefixed->ViewValue = FormatNumber($this->feefixed->ViewValue, Config("DEFAULT_DECIMAL_PRECISION"));
			$this->feefixed->ViewCustomAttributes = "";

			// totalfees
			$this->totalfees->ViewValue = $this->totalfees->CurrentValue;
			$this->totalfees->ViewValue = FormatNumber($this->totalfees->ViewValue, Config("DEFAULT_DECIMAL_PRECISION"));
			$this->totalfees->ViewCustomAttributes = "";

			// approveruserid
			$this->approveruserid->ViewValue = $this->approveruserid->CurrentValue;
			$this->approveruserid->ViewCustomAttributes = "";

			// docid
			$this->docid->ViewValue = $this->docid->CurrentValue;
			$this->docid->ViewCustomAttributes = "";

			// feesystemtotal
			$this->feesystemtotal->ViewValue = $this->feesystemtotal->CurrentValue;
			$this->feesystemtotal->ViewValue = FormatNumber($this->feesystemtotal->ViewValue, Config("DEFAULT_DECIMAL_PRECISION"));
			$this->feesystemtotal->ViewCustomAttributes = "";

			// feeexternaltotal
			$this->feeexternaltotal->ViewValue = $this->feeexternaltotal->CurrentValue;
			$this->feeexternaltotal->ViewValue = FormatNumber($this->feeexternaltotal->ViewValue, Config("DEFAULT_DECIMAL_PRECISION"));
			$this->feeexternaltotal->ViewCustomAttributes = "";

			// feefranchiseetotal
			$this->feefranchiseetotal->ViewValue = $this->feefranchiseetotal->CurrentValue;
			$this->feefranchiseetotal->ViewValue = FormatNumber($this->feefranchiseetotal->ViewValue, Config("DEFAULT_DECIMAL_PRECISION"));
			$this->feefranchiseetotal->ViewCustomAttributes = "";

			// feeresellertotal
			$this->feeresellertotal->ViewValue = $this->feeresellertotal->CurrentValue;
			$this->feeresellertotal->ViewValue = FormatNumber($this->feeresellertotal->ViewValue, Config("DEFAULT_DECIMAL_PRECISION"));
			$this->feeresellertotal->ViewCustomAttributes = "";

			// purchasefeeid
			$this->purchasefeeid->ViewValue = $this->purchasefeeid->CurrentValue;
			$this->purchasefeeid->ViewCustomAttributes = "";

			// cancellationrefid
			$this->cancellationrefid->ViewValue = $this->cancellationrefid->CurrentValue;
			$this->cancellationrefid->ViewCustomAttributes = "";

			// cancellationdatetime
			$this->cancellationdatetime->ViewValue = $this->cancellationdatetime->CurrentValue;
			$this->cancellationdatetime->ViewValue = FormatDateTime($this->cancellationdatetime->ViewValue, 0);
			$this->cancellationdatetime->ViewCustomAttributes = "";

			// cancellationreason
			$this->cancellationreason->ViewValue = $this->cancellationreason->CurrentValue;
			$this->cancellationreason->ViewCustomAttributes = "";

			// lastupdatedate
			$this->lastupdatedate->ViewValue = $this->lastupdatedate->CurrentValue;
			$this->lastupdatedate->ViewValue = FormatDateTime($this->lastupdatedate->ViewValue, 0);
			$this->lastupdatedate->ViewCustomAttributes = "";

			// feeexternaltotaltime
			$this->feeexternaltotaltime->ViewValue = $this->feeexternaltotaltime->CurrentValue;
			$this->feeexternaltotaltime->ViewValue = FormatNumber($this->feeexternaltotaltime->ViewValue, 2, -2, -2, -2);
			$this->feeexternaltotaltime->ViewCustomAttributes = "";

			// totalamountapplied
			$this->totalamountapplied->ViewValue = $this->totalamountapplied->CurrentValue;
			$this->totalamountapplied->ViewValue = FormatNumber($this->totalamountapplied->ViewValue, 2, -2, -2, -2);
			$this->totalamountapplied->ViewCustomAttributes = "";

			// totalfeesapplied
			$this->totalfeesapplied->ViewValue = $this->totalfeesapplied->CurrentValue;
			$this->totalfeesapplied->ViewValue = FormatNumber($this->totalfeesapplied->ViewValue, 2, -2, -2, -2);
			$this->totalfeesapplied->ViewCustomAttributes = "";

			// totalprincipleandfees
			$this->totalprincipleandfees->ViewValue = $this->totalprincipleandfees->CurrentValue;
			$this->totalprincipleandfees->ViewValue = FormatNumber($this->totalprincipleandfees->ViewValue, 2, -2, -2, -2);
			$this->totalprincipleandfees->ViewCustomAttributes = "";

			// taxamountbreakdown
			$this->taxamountbreakdown->ViewValue = $this->taxamountbreakdown->CurrentValue;
			$this->taxamountbreakdown->ViewValue = FormatNumber($this->taxamountbreakdown->ViewValue, 2, -2, -2, -2);
			$this->taxamountbreakdown->ViewCustomAttributes = "";

			// feesystembreakdown
			$this->feesystembreakdown->ViewValue = $this->feesystembreakdown->CurrentValue;
			$this->feesystembreakdown->ViewValue = FormatNumber($this->feesystembreakdown->ViewValue, 2, -2, -2, -2);
			$this->feesystembreakdown->ViewCustomAttributes = "";

			// feeexternalbreakdown
			$this->feeexternalbreakdown->ViewValue = $this->feeexternalbreakdown->CurrentValue;
			$this->feeexternalbreakdown->ViewValue = FormatNumber($this->feeexternalbreakdown->ViewValue, 2, -2, -2, -2);
			$this->feeexternalbreakdown->ViewCustomAttributes = "";

			// feefranchiseebreakdown
			$this->feefranchiseebreakdown->ViewValue = $this->feefranchiseebreakdown->CurrentValue;
			$this->feefranchiseebreakdown->ViewValue = FormatNumber($this->feefranchiseebreakdown->ViewValue, 2, -2, -2, -2);
			$this->feefranchiseebreakdown->ViewCustomAttributes = "";

			// feeresellerbreakdown
			$this->feeresellerbreakdown->ViewValue = $this->feeresellerbreakdown->CurrentValue;
			$this->feeresellerbreakdown->ViewValue = FormatNumber($this->feeresellerbreakdown->ViewValue, 2, -2, -2, -2);
			$this->feeresellerbreakdown->ViewCustomAttributes = "";

			// outstandingprinciple
			$this->outstandingprinciple->ViewValue = $this->outstandingprinciple->CurrentValue;
			$this->outstandingprinciple->ViewValue = FormatNumber($this->outstandingprinciple->ViewValue, 2, -2, -2, -2);
			$this->outstandingprinciple->ViewCustomAttributes = "";

			// outstandingfees
			$this->outstandingfees->ViewValue = $this->outstandingfees->CurrentValue;
			$this->outstandingfees->ViewValue = FormatNumber($this->outstandingfees->ViewValue, 2, -2, -2, -2);
			$this->outstandingfees->ViewCustomAttributes = "";

			// outstandingprincipleandfees
			$this->outstandingprincipleandfees->ViewValue = $this->outstandingprincipleandfees->CurrentValue;
			$this->outstandingprincipleandfees->ViewValue = FormatNumber($this->outstandingprincipleandfees->ViewValue, 2, -2, -2, -2);
			$this->outstandingprincipleandfees->ViewCustomAttributes = "";

			// lastupdate
			$this->lastupdate->ViewValue = $this->lastupdate->CurrentValue;
			$this->lastupdate->ViewValue = FormatDateTime($this->lastupdate->ViewValue, 0);
			$this->lastupdate->ViewCustomAttributes = "";

			// externalprovisioningrefno
			$this->externalprovisioningrefno->ViewValue = $this->externalprovisioningrefno->CurrentValue;
			$this->externalprovisioningrefno->ViewCustomAttributes = "";

			// loantype
			$curVal = strval($this->loantype->CurrentValue);
			if ($curVal != "") {
				$this->loantype->ViewValue = $this->loantype->lookupCacheOption($curVal);
				if ($this->loantype->ViewValue === NULL) { // Lookup from database
					$filterWrk = "`loantype`" . SearchString("=", $curVal, DATATYPE_NUMBER, "_4payreference");
					$sqlWrk = $this->loantype->Lookup->getSql(FALSE, $filterWrk, '', $this);
					$rswrk = Conn("_4payreference")->execute($sqlWrk);
					if ($rswrk && !$rswrk->EOF) { // Lookup values found
						$arwrk = [];
						$arwrk[1] = FormatNumber($rswrk->fields('df'), 0, -2, -2, -2);
						$arwrk[2] = $rswrk->fields('df2');
						$this->loantype->ViewValue = $this->loantype->displayValue($arwrk);
						$rswrk->Close();
					} else {
						$this->loantype->ViewValue = $this->loantype->CurrentValue;
					}
				}
			} else {
				$this->loantype->ViewValue = NULL;
			}
			$this->loantype->ViewCustomAttributes = "";

			// numberofoutstandingdays
			$this->numberofoutstandingdays->ViewValue = $this->numberofoutstandingdays->CurrentValue;
			$this->numberofoutstandingdays->ViewValue = FormatNumber($this->numberofoutstandingdays->ViewValue, 0, -2, -2, -2);
			$this->numberofoutstandingdays->ViewCustomAttributes = "";

			// loandue
			$curVal = strval($this->loandue->CurrentValue);
			if ($curVal != "") {
				$this->loandue->ViewValue = $this->loandue->lookupCacheOption($curVal);
				if ($this->loandue->ViewValue === NULL) { // Lookup from database
					$filterWrk = "`id`" . SearchString("=", $curVal, DATATYPE_NUMBER, "");
					$sqlWrk = $this->loandue->Lookup->getSql(FALSE, $filterWrk, '', $this);
					$rswrk = Conn()->execute($sqlWrk);
					if ($rswrk && !$rswrk->EOF) { // Lookup values found
						$arwrk = [];
						$arwrk[1] = $rswrk->fields('df');
						$this->loandue->ViewValue = $this->loandue->displayValue($arwrk);
						$rswrk->Close();
					} else {
						$this->loandue->ViewValue = $this->loandue->CurrentValue;
					}
				}
			} else {
				$this->loandue->ViewValue = NULL;
			}
			$this->loandue->ViewCustomAttributes = "";

			// loanduedate
			$this->loanduedate->ViewValue = $this->loanduedate->CurrentValue;
			$this->loanduedate->ViewValue = FormatDateTime($this->loanduedate->ViewValue, 0);
			$this->loanduedate->ViewCustomAttributes = "";

			// outstandinglatefees
			$this->outstandinglatefees->ViewValue = $this->outstandinglatefees->CurrentValue;
			$this->outstandinglatefees->ViewValue = FormatNumber($this->outstandinglatefees->ViewValue, 2, -2, -2, -2);
			$this->outstandinglatefees->ViewCustomAttributes = "";

			// disbursementtype
			if (strval($this->disbursementtype->CurrentValue) != "") {
				$this->disbursementtype->ViewValue = $this->disbursementtype->optionCaption($this->disbursementtype->CurrentValue);
			} else {
				$this->disbursementtype->ViewValue = NULL;
			}
			$this->disbursementtype->ViewCustomAttributes = "";

			// disbursementamount
			$this->disbursementamount->ViewValue = $this->disbursementamount->CurrentValue;
			$this->disbursementamount->ViewValue = FormatNumber($this->disbursementamount->ViewValue, 2, -2, -2, -2);
			$this->disbursementamount->ViewCustomAttributes = "";

			// loanconfirmed
			$curVal = strval($this->loanconfirmed->CurrentValue);
			if ($curVal != "") {
				$this->loanconfirmed->ViewValue = $this->loanconfirmed->lookupCacheOption($curVal);
				if ($this->loanconfirmed->ViewValue === NULL) { // Lookup from database
					$filterWrk = "`id`" . SearchString("=", $curVal, DATATYPE_NUMBER, "");
					$sqlWrk = $this->loanconfirmed->Lookup->getSql(FALSE, $filterWrk, '', $this);
					$rswrk = Conn()->execute($sqlWrk);
					if ($rswrk && !$rswrk->EOF) { // Lookup values found
						$arwrk = [];
						$arwrk[1] = $rswrk->fields('df');
						$this->loanconfirmed->ViewValue = $this->loanconfirmed->displayValue($arwrk);
						$rswrk->Close();
					} else {
						$this->loanconfirmed->ViewValue = $this->loanconfirmed->CurrentValue;
					}
				}
			} else {
				$this->loanconfirmed->ViewValue = NULL;
			}
			$this->loanconfirmed->ViewCustomAttributes = "";

			// loanconfirmedtime
			$this->loanconfirmedtime->ViewValue = $this->loanconfirmedtime->CurrentValue;
			$this->loanconfirmedtime->ViewValue = FormatDateTime($this->loanconfirmedtime->ViewValue, 0);
			$this->loanconfirmedtime->ViewCustomAttributes = "";

			// loanupgraded
			$curVal = strval($this->loanupgraded->CurrentValue);
			if ($curVal != "") {
				$this->loanupgraded->ViewValue = $this->loanupgraded->lookupCacheOption($curVal);
				if ($this->loanupgraded->ViewValue === NULL) { // Lookup from database
					$filterWrk = "`statusID`" . SearchString("=", $curVal, DATATYPE_NUMBER, "");
					$lookupFilter = function() {
						return "`langID` = 'EN'";
					};
					$lookupFilter = $lookupFilter->bindTo($this);
					$sqlWrk = $this->loanupgraded->Lookup->getSql(FALSE, $filterWrk, $lookupFilter, $this);
					$rswrk = Conn()->execute($sqlWrk);
					if ($rswrk && !$rswrk->EOF) { // Lookup values found
						$arwrk = [];
						$arwrk[1] = $rswrk->fields('df');
						$this->loanupgraded->ViewValue = $this->loanupgraded->displayValue($arwrk);
						$rswrk->Close();
					} else {
						$this->loanupgraded->ViewValue = $this->loanupgraded->CurrentValue;
					}
				}
			} else {
				$this->loanupgraded->ViewValue = NULL;
			}
			$this->loanupgraded->ViewCustomAttributes = "";

			// stoplatefee
			$curVal = strval($this->stoplatefee->CurrentValue);
			if ($curVal != "") {
				$this->stoplatefee->ViewValue = $this->stoplatefee->lookupCacheOption($curVal);
				if ($this->stoplatefee->ViewValue === NULL) { // Lookup from database
					$filterWrk = "`statusID`" . SearchString("=", $curVal, DATATYPE_NUMBER, "");
					$lookupFilter = function() {
						return "`langID` = 'EN'";
					};
					$lookupFilter = $lookupFilter->bindTo($this);
					$sqlWrk = $this->stoplatefee->Lookup->getSql(FALSE, $filterWrk, $lookupFilter, $this);
					$rswrk = Conn()->execute($sqlWrk);
					if ($rswrk && !$rswrk->EOF) { // Lookup values found
						$arwrk = [];
						$arwrk[1] = $rswrk->fields('df');
						$this->stoplatefee->ViewValue = $this->stoplatefee->displayValue($arwrk);
						$rswrk->Close();
					} else {
						$this->stoplatefee->ViewValue = $this->stoplatefee->CurrentValue;
					}
				}
			} else {
				$this->stoplatefee->ViewValue = NULL;
			}
			$this->stoplatefee->ViewCustomAttributes = "";

			// otherdetails1
			$this->otherdetails1->ViewValue = $this->otherdetails1->CurrentValue;
			$this->otherdetails1->ViewCustomAttributes = "";

			// lockflag
			if (strval($this->lockflag->CurrentValue) != "") {
				$this->lockflag->ViewValue = $this->lockflag->optionCaption($this->lockflag->CurrentValue);
			} else {
				$this->lockflag->ViewValue = NULL;
			}
			$this->lockflag->ViewCustomAttributes = "";

			// lastlatefeecalculatedate
			$this->lastlatefeecalculatedate->ViewValue = $this->lastlatefeecalculatedate->CurrentValue;
			$this->lastlatefeecalculatedate->ViewValue = FormatDateTime($this->lastlatefeecalculatedate->ViewValue, 0);
			$this->lastlatefeecalculatedate->ViewCustomAttributes = "";

			// notificationlockflag
			if (strval($this->notificationlockflag->CurrentValue) != "") {
				$this->notificationlockflag->ViewValue = $this->notificationlockflag->optionCaption($this->notificationlockflag->CurrentValue);
			} else {
				$this->notificationlockflag->ViewValue = NULL;
			}
			$this->notificationlockflag->ViewCustomAttributes = "";

			// lastnotificationdate
			$this->lastnotificationdate->ViewValue = $this->lastnotificationdate->CurrentValue;
			$this->lastnotificationdate->ViewValue = FormatDateTime($this->lastnotificationdate->ViewValue, 0);
			$this->lastnotificationdate->ViewCustomAttributes = "";

			// sendnotificationtextdate
			$this->sendnotificationtextdate->ViewValue = $this->sendnotificationtextdate->CurrentValue;
			$this->sendnotificationtextdate->ViewValue = FormatDateTime($this->sendnotificationtextdate->ViewValue, 0);
			$this->sendnotificationtextdate->ViewCustomAttributes = "";

			// termtype
			if (strval($this->termtype->CurrentValue) != "") {
				$this->termtype->ViewValue = $this->termtype->optionCaption($this->termtype->CurrentValue);
			} else {
				$this->termtype->ViewValue = NULL;
			}
			$this->termtype->ViewCustomAttributes = "";

			// loanid
			$this->loanid->LinkCustomAttributes = "";
			$this->loanid->HrefValue = "";
			$this->loanid->TooltipValue = "";
			if (!$this->isExport())
				$this->loanid->ViewValue = $this->highlightValue($this->loanid);

			// userid
			$this->_userid->LinkCustomAttributes = "";
			if (!EmptyValue($this->_userid->CurrentValue)) {
				$this->_userid->HrefValue = "loanlimitslist.php?showmaster=vuser&fk_id=" . $this->_userid->CurrentValue; // Add prefix/suffix
				$this->_userid->LinkAttrs["target"] = ""; // Add target
				if ($this->isExport())
					$this->_userid->HrefValue = FullUrl($this->_userid->HrefValue, "href");
			} else {
				$this->_userid->HrefValue = "";
			}
			$this->_userid->TooltipValue = "";
			if (!$this->isExport())
				$this->_userid->ViewValue = $this->highlightValue($this->_userid);

			// issueddate
			$this->issueddate->LinkCustomAttributes = "";
			$this->issueddate->HrefValue = "";
			$this->issueddate->TooltipValue = "";

			// currcode
			$this->currcode->LinkCustomAttributes = "";
			$this->currcode->HrefValue = "";
			$this->currcode->TooltipValue = "";

			// fullypaidind
			$this->fullypaidind->LinkCustomAttributes = "";
			$this->fullypaidind->HrefValue = "";
			$this->fullypaidind->TooltipValue = "";

			// loanconfirmed
			$this->loanconfirmed->LinkCustomAttributes = "";
			$this->loanconfirmed->HrefValue = "";
			$this->loanconfirmed->TooltipValue = "";

			// termtype
			$this->termtype->LinkCustomAttributes = "";
			$this->termtype->HrefValue = "";
			$this->termtype->TooltipValue = "";
		}

		// Call Row Rendered event
		if ($this->RowType != ROWTYPE_AGGREGATEINIT)
			$this->Row_Rendered();
	}

	// Validate search
	protected function validateSearch()
	{
		global $SearchError;

		// Initialize
		$SearchError = "";

		// Check if validation required
		if (!Config("SERVER_VALIDATE"))
			return TRUE;

		// Return validate result
		$validateSearch = ($SearchError == "");

		// Call Form_CustomValidate event
		$formCustomError = "";
		$validateSearch = $validateSearch && $this->Form_CustomValidate($formCustomError);
		if ($formCustomError != "") {
			AddMessage($SearchError, $formCustomError);
		}
		return $validateSearch;
	}

	// Load advanced search
	public function loadAdvancedSearch()
	{
		$this->loanid->AdvancedSearch->load();
		$this->_userid->AdvancedSearch->load();
		$this->issueddate->AdvancedSearch->load();
		$this->currcode->AdvancedSearch->load();
		$this->issuedamount->AdvancedSearch->load();
		$this->externalrefno->AdvancedSearch->load();
		$this->fullypaidind->AdvancedSearch->load();
		$this->bankcode->AdvancedSearch->load();
		$this->feeperc->AdvancedSearch->load();
		$this->feeamount->AdvancedSearch->load();
		$this->taxperc->AdvancedSearch->load();
		$this->taxamount->AdvancedSearch->load();
		$this->totalamount->AdvancedSearch->load();
		$this->paymenttargetdate->AdvancedSearch->load();
		$this->feefixed->AdvancedSearch->load();
		$this->totalfees->AdvancedSearch->load();
		$this->approveruserid->AdvancedSearch->load();
		$this->docid->AdvancedSearch->load();
		$this->feesystemtotal->AdvancedSearch->load();
		$this->feeexternaltotal->AdvancedSearch->load();
		$this->feefranchiseetotal->AdvancedSearch->load();
		$this->feeresellertotal->AdvancedSearch->load();
		$this->purchasefeeid->AdvancedSearch->load();
		$this->cancellationrefid->AdvancedSearch->load();
		$this->cancellationdatetime->AdvancedSearch->load();
		$this->cancellationreason->AdvancedSearch->load();
		$this->lastupdatedate->AdvancedSearch->load();
		$this->feeexternaltotaltime->AdvancedSearch->load();
		$this->totalamountapplied->AdvancedSearch->load();
		$this->totalfeesapplied->AdvancedSearch->load();
		$this->totalprincipleandfees->AdvancedSearch->load();
		$this->taxamountbreakdown->AdvancedSearch->load();
		$this->feesystembreakdown->AdvancedSearch->load();
		$this->feeexternalbreakdown->AdvancedSearch->load();
		$this->feefranchiseebreakdown->AdvancedSearch->load();
		$this->feeresellerbreakdown->AdvancedSearch->load();
		$this->outstandingprinciple->AdvancedSearch->load();
		$this->outstandingfees->AdvancedSearch->load();
		$this->outstandingprincipleandfees->AdvancedSearch->load();
		$this->lastupdate->AdvancedSearch->load();
		$this->externalprovisioningrefno->AdvancedSearch->load();
		$this->loantype->AdvancedSearch->load();
		$this->numberofoutstandingdays->AdvancedSearch->load();
		$this->loandue->AdvancedSearch->load();
		$this->loanduedate->AdvancedSearch->load();
		$this->outstandinglatefees->AdvancedSearch->load();
		$this->disbursementtype->AdvancedSearch->load();
		$this->disbursementamount->AdvancedSearch->load();
		$this->loanconfirmed->AdvancedSearch->load();
		$this->loanconfirmedtime->AdvancedSearch->load();
		$this->loanupgraded->AdvancedSearch->load();
		$this->stoplatefee->AdvancedSearch->load();
		$this->otherdetails1->AdvancedSearch->load();
		$this->lockflag->AdvancedSearch->load();
		$this->lastlatefeecalculatedate->AdvancedSearch->load();
		$this->notificationlockflag->AdvancedSearch->load();
		$this->lastnotificationdate->AdvancedSearch->load();
		$this->sendnotificationtextdate->AdvancedSearch->load();
		$this->termtype->AdvancedSearch->load();
	}

	// Get export HTML tag
	protected function getExportTag($type, $custom = FALSE)
	{
		global $Language;
		if (SameText($type, "excel")) {
			if ($custom)
				return "<a href=\"#\" class=\"ew-export-link ew-excel\" title=\"" . HtmlEncode($Language->phrase("ExportToExcelText")) . "\" data-caption=\"" . HtmlEncode($Language->phrase("ExportToExcelText")) . "\" onclick=\"return ew.export(document.floanissuedlist, '" . $this->ExportExcelUrl . "', 'excel', true);\">" . $Language->phrase("ExportToExcel") . "</a>";
			else
				return "<a href=\"" . $this->ExportExcelUrl . "\" class=\"ew-export-link ew-excel\" title=\"" . HtmlEncode($Language->phrase("ExportToExcelText")) . "\" data-caption=\"" . HtmlEncode($Language->phrase("ExportToExcelText")) . "\">" . $Language->phrase("ExportToExcel") . "</a>";
		} elseif (SameText($type, "word")) {
			if ($custom)
				return "<a href=\"#\" class=\"ew-export-link ew-word\" title=\"" . HtmlEncode($Language->phrase("ExportToWordText")) . "\" data-caption=\"" . HtmlEncode($Language->phrase("ExportToWordText")) . "\" onclick=\"return ew.export(document.floanissuedlist, '" . $this->ExportWordUrl . "', 'word', true);\">" . $Language->phrase("ExportToWord") . "</a>";
			else
				return "<a href=\"" . $this->ExportWordUrl . "\" class=\"ew-export-link ew-word\" title=\"" . HtmlEncode($Language->phrase("ExportToWordText")) . "\" data-caption=\"" . HtmlEncode($Language->phrase("ExportToWordText")) . "\">" . $Language->phrase("ExportToWord") . "</a>";
		} elseif (SameText($type, "pdf")) {
			if ($custom)
				return "<a href=\"#\" class=\"ew-export-link ew-pdf\" title=\"" . HtmlEncode($Language->phrase("ExportToPDFText")) . "\" data-caption=\"" . HtmlEncode($Language->phrase("ExportToPDFText")) . "\" onclick=\"return ew.export(document.floanissuedlist, '" . $this->ExportPdfUrl . "', 'pdf', true);\">" . $Language->phrase("ExportToPDF") . "</a>";
			else
				return "<a href=\"" . $this->ExportPdfUrl . "\" class=\"ew-export-link ew-pdf\" title=\"" . HtmlEncode($Language->phrase("ExportToPDFText")) . "\" data-caption=\"" . HtmlEncode($Language->phrase("ExportToPDFText")) . "\">" . $Language->phrase("ExportToPDF") . "</a>";
		} elseif (SameText($type, "html")) {
			return "<a href=\"" . $this->ExportHtmlUrl . "\" class=\"ew-export-link ew-html\" title=\"" . HtmlEncode($Language->phrase("ExportToHtmlText")) . "\" data-caption=\"" . HtmlEncode($Language->phrase("ExportToHtmlText")) . "\">" . $Language->phrase("ExportToHtml") . "</a>";
		} elseif (SameText($type, "xml")) {
			return "<a href=\"" . $this->ExportXmlUrl . "\" class=\"ew-export-link ew-xml\" title=\"" . HtmlEncode($Language->phrase("ExportToXmlText")) . "\" data-caption=\"" . HtmlEncode($Language->phrase("ExportToXmlText")) . "\">" . $Language->phrase("ExportToXml") . "</a>";
		} elseif (SameText($type, "csv")) {
			return "<a href=\"" . $this->ExportCsvUrl . "\" class=\"ew-export-link ew-csv\" title=\"" . HtmlEncode($Language->phrase("ExportToCsvText")) . "\" data-caption=\"" . HtmlEncode($Language->phrase("ExportToCsvText")) . "\">" . $Language->phrase("ExportToCsv") . "</a>";
		} elseif (SameText($type, "email")) {
			$url = $custom ? ",url:'" . $this->pageUrl() . "export=email&amp;custom=1'" : "";
			return '<button id="emf_loanissued" class="ew-export-link ew-email" title="' . $Language->phrase("ExportToEmailText") . '" data-caption="' . $Language->phrase("ExportToEmailText") . '" onclick="ew.emailDialogShow({lnk:\'emf_loanissued\', hdr:ew.language.phrase(\'ExportToEmailText\'), f:document.floanissuedlist, sel:false' . $url . '});">' . $Language->phrase("ExportToEmail") . '</button>';
		} elseif (SameText($type, "print")) {
			return "<a href=\"" . $this->ExportPrintUrl . "\" class=\"ew-export-link ew-print\" title=\"" . HtmlEncode($Language->phrase("PrinterFriendlyText")) . "\" data-caption=\"" . HtmlEncode($Language->phrase("PrinterFriendlyText")) . "\">" . $Language->phrase("PrinterFriendly") . "</a>";
		}
	}

	// Set up export options
	protected function setupExportOptions()
	{
		global $Language;

		// Printer friendly
		$item = &$this->ExportOptions->add("print");
		$item->Body = $this->getExportTag("print");
		$item->Visible = TRUE;

		// Export to Excel
		$item = &$this->ExportOptions->add("excel");
		$item->Body = $this->getExportTag("excel");
		$item->Visible = TRUE;

		// Export to Word
		$item = &$this->ExportOptions->add("word");
		$item->Body = $this->getExportTag("word");
		$item->Visible = TRUE;

		// Export to Html
		$item = &$this->ExportOptions->add("html");
		$item->Body = $this->getExportTag("html");
		$item->Visible = TRUE;

		// Export to Xml
		$item = &$this->ExportOptions->add("xml");
		$item->Body = $this->getExportTag("xml");
		$item->Visible = FALSE;

		// Export to Csv
		$item = &$this->ExportOptions->add("csv");
		$item->Body = $this->getExportTag("csv");
		$item->Visible = TRUE;

		// Export to Pdf
		$item = &$this->ExportOptions->add("pdf");
		$item->Body = $this->getExportTag("pdf");
		$item->Visible = FALSE;

		// Export to Email
		$item = &$this->ExportOptions->add("email");
		$item->Body = $this->getExportTag("email");
		$item->Visible = TRUE;

		// Drop down button for export
		$this->ExportOptions->UseButtonGroup = TRUE;
		$this->ExportOptions->UseDropDownButton = TRUE;
		if ($this->ExportOptions->UseButtonGroup && IsMobile())
			$this->ExportOptions->UseDropDownButton = TRUE;
		$this->ExportOptions->DropDownButtonPhrase = $Language->phrase("ButtonExport");

		// Add group option item
		$item = &$this->ExportOptions->add($this->ExportOptions->GroupOptionName);
		$item->Body = "";
		$item->Visible = FALSE;
	}

	// Set up search options
	protected function setupSearchOptions()
	{
		global $Language;
		$this->SearchOptions = new ListOptions("div");
		$this->SearchOptions->TagClassName = "ew-search-option";

		// Show all button
		$item = &$this->SearchOptions->add("showall");
		$item->Body = "<a class=\"btn btn-default ew-show-all\" title=\"" . $Language->phrase("ResetSearch") . "\" data-caption=\"" . $Language->phrase("ResetSearch") . "\" href=\"" . $this->pageUrl() . "cmd=reset\">" . $Language->phrase("ResetSearchBtn") . "</a>";
		$item->Visible = ($this->SearchWhere != $this->DefaultSearchWhere && $this->SearchWhere != "0=101");

		// Advanced search button
		$item = &$this->SearchOptions->add("advancedsearch");
		$item->Body = "<a class=\"btn btn-default ew-advanced-search\" title=\"" . $Language->phrase("AdvancedSearch") . "\" data-caption=\"" . $Language->phrase("AdvancedSearch") . "\" href=\"loanissuedsrch.php\">" . $Language->phrase("AdvancedSearchBtn") . "</a>";
		$item->Visible = TRUE;

		// Search highlight button
		$item = &$this->SearchOptions->add("searchhighlight");
		$item->Body = "<a class=\"btn btn-default ew-highlight active\" href=\"#\" role=\"button\" title=\"" . $Language->phrase("Highlight") . "\" data-caption=\"" . $Language->phrase("Highlight") . "\" data-toggle=\"button\" data-form=\"floanissuedlistsrch\" data-name=\"" . $this->highlightName() . "\">" . $Language->phrase("HighlightBtn") . "</a>";
		$item->Visible = ($this->SearchWhere != "" && $this->TotalRecords > 0);

		// Button group for search
		$this->SearchOptions->UseDropDownButton = FALSE;
		$this->SearchOptions->UseButtonGroup = TRUE;
		$this->SearchOptions->DropDownButtonPhrase = $Language->phrase("ButtonSearch");

		// Add group option item
		$item = &$this->SearchOptions->add($this->SearchOptions->GroupOptionName);
		$item->Body = "";
		$item->Visible = FALSE;

		// Hide search options
		if ($this->isExport() || $this->CurrentAction)
			$this->SearchOptions->hideAllOptions();
		global $Security;
		if (!$Security->canSearch()) {
			$this->SearchOptions->hideAllOptions();
			$this->FilterOptions->hideAllOptions();
		}
	}

	/**
	 * Export data in HTML/CSV/Word/Excel/XML/Email/PDF format
	 *
	 * @param boolean $return Return the data rather than output it
	 * @return mixed
	 */
	public function exportData($return = FALSE)
	{
		global $Language;
		$utf8 = SameText(Config("PROJECT_CHARSET"), "utf-8");
		$selectLimit = $this->UseSelectLimit;

		// Load recordset
		if ($selectLimit) {
			$this->TotalRecords = $this->listRecordCount();
		} else {
			if (!$this->Recordset)
				$this->Recordset = $this->loadRecordset();
			$rs = &$this->Recordset;
			if ($rs)
				$this->TotalRecords = $rs->RecordCount();
		}
		$this->StartRecord = 1;

		// Export all
		if ($this->ExportAll) {
			set_time_limit(Config("EXPORT_ALL_TIME_LIMIT"));
			$this->DisplayRecords = $this->TotalRecords;
			$this->StopRecord = $this->TotalRecords;
		} else { // Export one page only
			$this->setupStartRecord(); // Set up start record position

			// Set the last record to display
			if ($this->DisplayRecords <= 0) {
				$this->StopRecord = $this->TotalRecords;
			} else {
				$this->StopRecord = $this->StartRecord + $this->DisplayRecords - 1;
			}
		}
		if ($selectLimit)
			$rs = $this->loadRecordset($this->StartRecord - 1, $this->DisplayRecords <= 0 ? $this->TotalRecords : $this->DisplayRecords);
		$this->ExportDoc = GetExportDocument($this, "h");
		$doc = &$this->ExportDoc;
		if (!$doc)
			$this->setFailureMessage($Language->phrase("ExportClassNotFound")); // Export class not found
		if (!$rs || !$doc) {
			RemoveHeader("Content-Type"); // Remove header
			RemoveHeader("Content-Disposition");
			$this->showMessage();
			return;
		}
		if ($selectLimit) {
			$this->StartRecord = 1;
			$this->StopRecord = $this->DisplayRecords <= 0 ? $this->TotalRecords : $this->DisplayRecords;
		}

		// Call Page Exporting server event
		$this->ExportDoc->ExportCustom = !$this->Page_Exporting();

		// Export master record
		if (Config("EXPORT_MASTER_RECORD") && $this->getMasterFilter() != "" && $this->getCurrentMasterTable() == "loanrequests") {
			global $loanrequests;
			if (!isset($loanrequests))
				$loanrequests = new loanrequests();
			$rsmaster = $loanrequests->loadRs($this->DbMasterFilter); // Load master record
			if ($rsmaster && !$rsmaster->EOF) {
				$exportStyle = $doc->Style;
				$doc->setStyle("v"); // Change to vertical
				if (!$this->isExport("csv") || Config("EXPORT_MASTER_RECORD_FOR_CSV")) {
					$doc->Table = &$loanrequests;
					$loanrequests->exportDocument($doc, $rsmaster);
					$doc->exportEmptyRow();
					$doc->Table = &$this;
				}
				$doc->setStyle($exportStyle); // Restore
				$rsmaster->close();
			}
		}

		// Export master record
		if (Config("EXPORT_MASTER_RECORD") && $this->getMasterFilter() != "" && $this->getCurrentMasterTable() == "loancancelrequests") {
			global $loancancelrequests;
			if (!isset($loancancelrequests))
				$loancancelrequests = new loancancelrequests();
			$rsmaster = $loancancelrequests->loadRs($this->DbMasterFilter); // Load master record
			if ($rsmaster && !$rsmaster->EOF) {
				$exportStyle = $doc->Style;
				$doc->setStyle("v"); // Change to vertical
				if (!$this->isExport("csv") || Config("EXPORT_MASTER_RECORD_FOR_CSV")) {
					$doc->Table = &$loancancelrequests;
					$loancancelrequests->exportDocument($doc, $rsmaster);
					$doc->exportEmptyRow();
					$doc->Table = &$this;
				}
				$doc->setStyle($exportStyle); // Restore
				$rsmaster->close();
			}
		}

		// Export master record
		if (Config("EXPORT_MASTER_RECORD") && $this->getMasterFilter() != "" && $this->getCurrentMasterTable() == "loanlimits") {
			global $loanlimits;
			if (!isset($loanlimits))
				$loanlimits = new loanlimits();
			$rsmaster = $loanlimits->loadRs($this->DbMasterFilter); // Load master record
			if ($rsmaster && !$rsmaster->EOF) {
				$exportStyle = $doc->Style;
				$doc->setStyle("v"); // Change to vertical
				if (!$this->isExport("csv") || Config("EXPORT_MASTER_RECORD_FOR_CSV")) {
					$doc->Table = &$loanlimits;
					$loanlimits->exportDocument($doc, $rsmaster);
					$doc->exportEmptyRow();
					$doc->Table = &$this;
				}
				$doc->setStyle($exportStyle); // Restore
				$rsmaster->close();
			}
		}
		$header = $this->PageHeader;
		$this->Page_DataRendering($header);
		$doc->Text .= $header;
		$this->exportDocument($doc, $rs, $this->StartRecord, $this->StopRecord, "");
		$footer = $this->PageFooter;
		$this->Page_DataRendered($footer);
		$doc->Text .= $footer;

		// Close recordset
		$rs->close();

		// Call Page Exported server event
		$this->Page_Exported();

		// Export header and footer
		$doc->exportHeaderAndFooter();

		// Clean output buffer (without destroying output buffer)
		$buffer = ob_get_contents(); // Save the output buffer
		if (!Config("DEBUG") && $buffer)
			ob_clean();

		// Write debug message if enabled
		if (Config("DEBUG") && !$this->isExport("pdf"))
			echo GetDebugMessage();

		// Output data
		if ($this->isExport("email")) {
			if ($return)
				return $doc->Text; // Return email content
			else
				echo $this->exportEmail($doc->Text); // Send email
		} else {
			$doc->export();
			if ($return) {
				RemoveHeader("Content-Type"); // Remove header
				RemoveHeader("Content-Disposition");
				$content = ob_get_contents();
				if ($content)
					ob_clean();
				if ($buffer)
					echo $buffer; // Resume the output buffer
				return $content;
			}
		}
	}

	// Export email
	protected function exportEmail($emailContent)
	{
		global $TempImages, $Language;
		$sender = Post("sender", "");
		$recipient = Post("recipient", "");
		$cc = Post("cc", "");
		$bcc = Post("bcc", "");

		// Subject
		$subject = Post("subject", "");
		$emailSubject = $subject;

		// Message
		$content = Post("message", "");
		$emailMessage = $content;

		// Check sender
		if ($sender == "") {
			return "<p class=\"text-danger\">" . $Language->phrase("EnterSenderEmail") . "</p>";
		}
		if (!CheckEmail($sender)) {
			return "<p class=\"text-danger\">" . $Language->phrase("EnterProperSenderEmail") . "</p>";
		}

		// Check recipient
		if (!CheckEmailList($recipient, Config("MAX_EMAIL_RECIPIENT"))) {
			return "<p class=\"text-danger\">" . $Language->phrase("EnterProperRecipientEmail") . "</p>";
		}

		// Check cc
		if (!CheckEmailList($cc, Config("MAX_EMAIL_RECIPIENT"))) {
			return "<p class=\"text-danger\">" . $Language->phrase("EnterProperCcEmail") . "</p>";
		}

		// Check bcc
		if (!CheckEmailList($bcc, Config("MAX_EMAIL_RECIPIENT"))) {
			return "<p class=\"text-danger\">" . $Language->phrase("EnterProperBccEmail") . "</p>";
		}

		// Check email sent count
		if (!isset($_SESSION[Config("EXPORT_EMAIL_COUNTER")]))
			$_SESSION[Config("EXPORT_EMAIL_COUNTER")] = 0;
		if ((int)$_SESSION[Config("EXPORT_EMAIL_COUNTER")] > Config("MAX_EMAIL_SENT_COUNT")) {
			return "<p class=\"text-danger\">" . $Language->phrase("ExceedMaxEmailExport") . "</p>";
		}

		// Send email
		$email = new Email();
		$email->Sender = $sender; // Sender
		$email->Recipient = $recipient; // Recipient
		$email->Cc = $cc; // Cc
		$email->Bcc = $bcc; // Bcc
		$email->Subject = $emailSubject; // Subject
		$email->Format = "html";
		if ($emailMessage != "")
			$emailMessage = RemoveXss($emailMessage) . "<br><br>";
		foreach ($TempImages as $tmpImage)
			$email->addEmbeddedImage($tmpImage);
		$email->Content = $emailMessage . CleanEmailContent($emailContent); // Content
		$eventArgs = [];
		if ($this->Recordset)
			$eventArgs["rs"] = &$this->Recordset;
		$emailSent = FALSE;
		if ($this->Email_Sending($email, $eventArgs))
			$emailSent = $email->send();

		// Check email sent status
		if ($emailSent) {

			// Update email sent count
			$_SESSION[Config("EXPORT_EMAIL_COUNTER")]++;

			// Sent email success
			return "<p class=\"text-success\">" . $Language->phrase("SendEmailSuccess") . "</p>"; // Set up success message
		} else {

			// Sent email failure
			return "<p class=\"text-danger\">" . $email->SendErrDescription . "</p>";
		}
	}

	// Set up master/detail based on QueryString
	protected function setupMasterParms()
	{
		$validMaster = FALSE;

		// Get the keys for master table
		if (($master = Get(Config("TABLE_SHOW_MASTER"), Get(Config("TABLE_MASTER")))) !== NULL) {
			$masterTblVar = $master;
			if ($masterTblVar == "") {
				$validMaster = TRUE;
				$this->DbMasterFilter = "";
				$this->DbDetailFilter = "";
			}
			if ($masterTblVar == "loanrequests") {
				$validMaster = TRUE;
				if (($parm = Get("fk_loanid", Get("loanid"))) !== NULL) {
					$GLOBALS["loanrequests"]->loanid->setQueryStringValue($parm);
					$this->loanid->setQueryStringValue($GLOBALS["loanrequests"]->loanid->QueryStringValue);
					$this->loanid->setSessionValue($this->loanid->QueryStringValue);
					if (!is_numeric($GLOBALS["loanrequests"]->loanid->QueryStringValue))
						$validMaster = FALSE;
				} else {
					$validMaster = FALSE;
				}
			}
			if ($masterTblVar == "loancancelrequests") {
				$validMaster = TRUE;
				if (($parm = Get("fk_cancelledloanid", Get("loanid"))) !== NULL) {
					$GLOBALS["loancancelrequests"]->cancelledloanid->setQueryStringValue($parm);
					$this->loanid->setQueryStringValue($GLOBALS["loancancelrequests"]->cancelledloanid->QueryStringValue);
					$this->loanid->setSessionValue($this->loanid->QueryStringValue);
					if (!is_numeric($GLOBALS["loancancelrequests"]->cancelledloanid->QueryStringValue))
						$validMaster = FALSE;
				} else {
					$validMaster = FALSE;
				}
			}
			if ($masterTblVar == "loanlimits") {
				$validMaster = TRUE;
				if (($parm = Get("fk__userid", Get("_userid"))) !== NULL) {
					$GLOBALS["loanlimits"]->_userid->setQueryStringValue($parm);
					$this->_userid->setQueryStringValue($GLOBALS["loanlimits"]->_userid->QueryStringValue);
					$this->_userid->setSessionValue($this->_userid->QueryStringValue);
					if (!is_numeric($GLOBALS["loanlimits"]->_userid->QueryStringValue))
						$validMaster = FALSE;
				} else {
					$validMaster = FALSE;
				}
				if (($parm = Get("fk_currcode", Get("currcode"))) !== NULL) {
					$GLOBALS["loanlimits"]->currcode->setQueryStringValue($parm);
					$this->currcode->setQueryStringValue($GLOBALS["loanlimits"]->currcode->QueryStringValue);
					$this->currcode->setSessionValue($this->currcode->QueryStringValue);
				} else {
					$validMaster = FALSE;
				}
			}
		} elseif (($master = Post(Config("TABLE_SHOW_MASTER"), Post(Config("TABLE_MASTER")))) !== NULL) {
			$masterTblVar = $master;
			if ($masterTblVar == "") {
				$validMaster = TRUE;
				$this->DbMasterFilter = "";
				$this->DbDetailFilter = "";
			}
			if ($masterTblVar == "loanrequests") {
				$validMaster = TRUE;
				if (($parm = Post("fk_loanid", Post("loanid"))) !== NULL) {
					$GLOBALS["loanrequests"]->loanid->setFormValue($parm);
					$this->loanid->setFormValue($GLOBALS["loanrequests"]->loanid->FormValue);
					$this->loanid->setSessionValue($this->loanid->FormValue);
					if (!is_numeric($GLOBALS["loanrequests"]->loanid->FormValue))
						$validMaster = FALSE;
				} else {
					$validMaster = FALSE;
				}
			}
			if ($masterTblVar == "loancancelrequests") {
				$validMaster = TRUE;
				if (($parm = Post("fk_cancelledloanid", Post("loanid"))) !== NULL) {
					$GLOBALS["loancancelrequests"]->cancelledloanid->setFormValue($parm);
					$this->loanid->setFormValue($GLOBALS["loancancelrequests"]->cancelledloanid->FormValue);
					$this->loanid->setSessionValue($this->loanid->FormValue);
					if (!is_numeric($GLOBALS["loancancelrequests"]->cancelledloanid->FormValue))
						$validMaster = FALSE;
				} else {
					$validMaster = FALSE;
				}
			}
			if ($masterTblVar == "loanlimits") {
				$validMaster = TRUE;
				if (($parm = Post("fk__userid", Post("_userid"))) !== NULL) {
					$GLOBALS["loanlimits"]->_userid->setFormValue($parm);
					$this->_userid->setFormValue($GLOBALS["loanlimits"]->_userid->FormValue);
					$this->_userid->setSessionValue($this->_userid->FormValue);
					if (!is_numeric($GLOBALS["loanlimits"]->_userid->FormValue))
						$validMaster = FALSE;
				} else {
					$validMaster = FALSE;
				}
				if (($parm = Post("fk_currcode", Post("currcode"))) !== NULL) {
					$GLOBALS["loanlimits"]->currcode->setFormValue($parm);
					$this->currcode->setFormValue($GLOBALS["loanlimits"]->currcode->FormValue);
					$this->currcode->setSessionValue($this->currcode->FormValue);
				} else {
					$validMaster = FALSE;
				}
			}
		}
		if ($validMaster) {

			// Update URL
			$this->AddUrl = $this->addMasterUrl($this->AddUrl);
			$this->InlineAddUrl = $this->addMasterUrl($this->InlineAddUrl);
			$this->GridAddUrl = $this->addMasterUrl($this->GridAddUrl);
			$this->GridEditUrl = $this->addMasterUrl($this->GridEditUrl);

			// Save current master table
			$this->setCurrentMasterTable($masterTblVar);

			// Reset start record counter (new master key)
			if (!$this->isAddOrEdit()) {
				$this->StartRecord = 1;
				$this->setStartRecordNumber($this->StartRecord);
			}

			// Clear previous master key from Session
			if ($masterTblVar != "loanrequests") {
				if ($this->loanid->CurrentValue == "")
					$this->loanid->setSessionValue("");
			}
			if ($masterTblVar != "loancancelrequests") {
				if ($this->loanid->CurrentValue == "")
					$this->loanid->setSessionValue("");
			}
			if ($masterTblVar != "loanlimits") {
				if ($this->_userid->CurrentValue == "")
					$this->_userid->setSessionValue("");
				if ($this->currcode->CurrentValue == "")
					$this->currcode->setSessionValue("");
			}
		}
		$this->DbMasterFilter = $this->getMasterFilter(); // Get master filter
		$this->DbDetailFilter = $this->getDetailFilter(); // Get detail filter
	}

	// Set up Breadcrumb
	protected function setupBreadcrumb()
	{
		global $Breadcrumb, $Language;
		$Breadcrumb = new Breadcrumb();
		$url = substr(CurrentUrl(), strrpos(CurrentUrl(), "/")+1);
		$url = preg_replace('/\?cmd=reset(all){0,1}$/i', '', $url); // Remove cmd=reset / cmd=resetall
		$Breadcrumb->add("list", $this->TableVar, $url, "", $this->TableVar, TRUE);
	}

	// Setup lookup options
	public function setupLookupOptions($fld)
	{
		if ($fld->Lookup !== NULL && $fld->Lookup->Options === NULL) {

			// Get default connection and filter
			$conn = $this->getConnection();
			$lookupFilter = "";

			// No need to check any more
			$fld->Lookup->Options = [];

			// Set up lookup SQL and connection
			switch ($fld->FieldVar) {
				case "x_currcode":
					$conn = Conn("_4payreference");
					$lookupFilter = function() {
						return "`langID`='EN'";
					};
					$lookupFilter = $lookupFilter->bindTo($this);
					break;
				case "x_fullypaidind":
					$lookupFilter = function() {
						return "`langID` = 'EN'";
					};
					$lookupFilter = $lookupFilter->bindTo($this);
					break;
				case "x_loantype":
					$conn = Conn("_4payreference");
					break;
				case "x_loandue":
					break;
				case "x_disbursementtype":
					$conn = Conn("_4payreference");
					break;
				case "x_loanconfirmed":
					break;
				case "x_loanupgraded":
					$lookupFilter = function() {
						return "`langID` = 'EN'";
					};
					$lookupFilter = $lookupFilter->bindTo($this);
					break;
				case "x_stoplatefee":
					$lookupFilter = function() {
						return "`langID` = 'EN'";
					};
					$lookupFilter = $lookupFilter->bindTo($this);
					break;
				case "x_lockflag":
					break;
				case "x_notificationlockflag":
					break;
				case "x_termtype":
					break;
				default:
					$lookupFilter = "";
					break;
			}

			// Always call to Lookup->getSql so that user can setup Lookup->Options in Lookup_Selecting server event
			$sql = $fld->Lookup->getSql(FALSE, "", $lookupFilter, $this);

			// Set up lookup cache
			if ($fld->UseLookupCache && $sql != "" && count($fld->Lookup->Options) == 0) {
				$totalCnt = $this->getRecordCount($sql, $conn);
				if ($totalCnt > $fld->LookupCacheCount) // Total count > cache count, do not cache
					return;
				$rs = $conn->execute($sql);
				$ar = [];
				while ($rs && !$rs->EOF) {
					$row = &$rs->fields;

					// Format the field values
					switch ($fld->FieldVar) {
						case "x_currcode":
							break;
						case "x_loantype":
							$row[1] = FormatNumber($row[1], 0, -2, -2, -2);
							$row['df'] = $row[1];
							break;
						case "x_loandue":
							break;
						case "x_loanconfirmed":
							break;
						case "x_loanupgraded":
							break;
						case "x_stoplatefee":
							break;
					}
					$ar[strval($row[0])] = $row;
					$rs->moveNext();
				}
				if ($rs)
					$rs->close();
				$fld->Lookup->Options = $ar;
			}
		}
	}

	// Set up starting record parameters
	public function setupStartRecord()
	{
		if ($this->DisplayRecords == 0)
			return;
		if ($this->isPageRequest()) { // Validate request
			$startRec = Get(Config("TABLE_START_REC"));
			$pageNo = Get(Config("TABLE_PAGE_NO"));
			if ($pageNo !== NULL) { // Check for "pageno" parameter first
				if (is_numeric($pageNo)) {
					$this->StartRecord = ($pageNo - 1) * $this->DisplayRecords + 1;
					if ($this->StartRecord <= 0) {
						$this->StartRecord = 1;
					} elseif ($this->StartRecord >= (int)(($this->TotalRecords - 1)/$this->DisplayRecords) * $this->DisplayRecords + 1) {
						$this->StartRecord = (int)(($this->TotalRecords - 1)/$this->DisplayRecords) * $this->DisplayRecords + 1;
					}
					$this->setStartRecordNumber($this->StartRecord);
				}
			} elseif ($startRec !== NULL) { // Check for "start" parameter
				$this->StartRecord = $startRec;
				$this->setStartRecordNumber($this->StartRecord);
			}
		}
		$this->StartRecord = $this->getStartRecordNumber();

		// Check if correct start record counter
		if (!is_numeric($this->StartRecord) || $this->StartRecord == "") { // Avoid invalid start record counter
			$this->StartRecord = 1; // Reset start record counter
			$this->setStartRecordNumber($this->StartRecord);
		} elseif ($this->StartRecord > $this->TotalRecords) { // Avoid starting record > total records
			$this->StartRecord = (int)(($this->TotalRecords - 1)/$this->DisplayRecords) * $this->DisplayRecords + 1; // Point to last page first record
			$this->setStartRecordNumber($this->StartRecord);
		} elseif (($this->StartRecord - 1) % $this->DisplayRecords != 0) {
			$this->StartRecord = (int)(($this->StartRecord - 1)/$this->DisplayRecords) * $this->DisplayRecords + 1; // Point to page boundary
			$this->setStartRecordNumber($this->StartRecord);
		}
	}

	// Page Load event
	function Page_Load() {

		//echo "Page Load";
	}

	// Page Unload event
	function Page_Unload() {

		//echo "Page Unload";
	}

	// Page Redirecting event
	function Page_Redirecting(&$url) {

		// Example:
		//$url = "your URL";

	}

	// Message Showing event
	// $type = ''|'success'|'failure'|'warning'
	function Message_Showing(&$msg, $type) {
		if ($type == 'success') {

			//$msg = "your success message";
		} elseif ($type == 'failure') {

			//$msg = "your failure message";
		} elseif ($type == 'warning') {

			//$msg = "your warning message";
		} else {

			//$msg = "your message";
		}
	}

	// Page Render event
	function Page_Render() {

		//echo "Page Render";
	}

	// Page Data Rendering event
	function Page_DataRendering(&$header) {

		// Example:
		//$header = "your header";

	}

	// Page Data Rendered event
	function Page_DataRendered(&$footer) {

		// Example:
		//$footer = "your footer";

	}

	// Form Custom Validate event
	function Form_CustomValidate(&$customError) {

		// Return error message in CustomError
		return TRUE;
	}

	// ListOptions Load event
	function ListOptions_Load() {

		// Example:
		//$opt = &$this->ListOptions->Add("new");
		//$opt->Header = "xxx";
		//$opt->OnLeft = TRUE; // Link on left
		//$opt->MoveTo(0); // Move to first column

	}

	// ListOptions Rendering event
	function ListOptions_Rendering() {

		//$GLOBALS["xxx_grid"]->DetailAdd = (...condition...); // Set to TRUE or FALSE conditionally
		//$GLOBALS["xxx_grid"]->DetailEdit = (...condition...); // Set to TRUE or FALSE conditionally
		//$GLOBALS["xxx_grid"]->DetailView = (...condition...); // Set to TRUE or FALSE conditionally

	}

	// ListOptions Rendered event
	function ListOptions_Rendered() {

		// Example:
		//$this->ListOptions["new"]->Body = "xxx";

	}

	// Row Custom Action event
	function Row_CustomAction($action, $row) {

		// Return FALSE to abort
		return TRUE;
	}

	// Page Exporting event
	// $this->ExportDoc = export document object
	function Page_Exporting() {

		//$this->ExportDoc->Text = "my header"; // Export header
		//return FALSE; // Return FALSE to skip default export and use Row_Export event

		return TRUE; // Return TRUE to use default export and skip Row_Export event
	}

	// Row Export event
	// $this->ExportDoc = export document object
	function Row_Export($rs) {

		//$this->ExportDoc->Text .= "my content"; // Build HTML with field value: $rs["MyField"] or $this->MyField->ViewValue
	}

	// Page Exported event
	// $this->ExportDoc = export document object
	function Page_Exported() {

		//$this->ExportDoc->Text .= "my footer"; // Export footer
		//echo $this->ExportDoc->Text;

	}

	// Page Importing event
	function Page_Importing($reader, &$options) {

		//var_dump($reader); // Import data reader
		//var_dump($options); // Show all options for importing
		//return FALSE; // Return FALSE to skip import

		return TRUE;
	}

	// Row Import event
	function Row_Import(&$row, $cnt) {

		//echo $cnt; // Import record count
		//var_dump($row); // Import row
		//return FALSE; // Return FALSE to skip import

		return TRUE;
	}

	// Page Imported event
	function Page_Imported($reader, $results) {

		//var_dump($reader); // Import data reader
		//var_dump($results); // Import results

	}
} // End class
?>