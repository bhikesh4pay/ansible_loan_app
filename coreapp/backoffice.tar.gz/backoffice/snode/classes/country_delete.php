<?php
namespace PHPMaker2020\_4payadmin;

/**
 * Page class
 */
class country_delete extends country
{

	// Page ID
	public $PageID = "delete";

	// Project ID
	public $ProjectID = "{153C2D2E-60EE-4944-8753-3935EB38E8D6}";

	// Table name
	public $TableName = 'country';

	// Page object name
	public $PageObjName = "country_delete";

	// Page headings
	public $Heading = "";
	public $Subheading = "";
	public $PageHeader;
	public $PageFooter;

	// Token
	public $Token = "";
	public $TokenTimeout = 0;
	public $CheckToken;

	// Page heading
	public function pageHeading()
	{
		global $Language;
		if ($this->Heading != "")
			return $this->Heading;
		if (method_exists($this, "tableCaption"))
			return $this->tableCaption();
		return "";
	}

	// Page subheading
	public function pageSubheading()
	{
		global $Language;
		if ($this->Subheading != "")
			return $this->Subheading;
		if ($this->TableName)
			return $Language->phrase($this->PageID);
		return "";
	}

	// Page name
	public function pageName()
	{
		return CurrentPageName();
	}

	// Page URL
	public function pageUrl()
	{
		$url = CurrentPageName() . "?";
		if ($this->UseTokenInUrl)
			$url .= "t=" . $this->TableVar . "&"; // Add page token
		return $url;
	}

	// Messages
	private $_message = "";
	private $_failureMessage = "";
	private $_successMessage = "";
	private $_warningMessage = "";

	// Get message
	public function getMessage()
	{
		return isset($_SESSION[SESSION_MESSAGE]) ? $_SESSION[SESSION_MESSAGE] : $this->_message;
	}

	// Set message
	public function setMessage($v)
	{
		AddMessage($this->_message, $v);
		$_SESSION[SESSION_MESSAGE] = $this->_message;
	}

	// Get failure message
	public function getFailureMessage()
	{
		return isset($_SESSION[SESSION_FAILURE_MESSAGE]) ? $_SESSION[SESSION_FAILURE_MESSAGE] : $this->_failureMessage;
	}

	// Set failure message
	public function setFailureMessage($v)
	{
		AddMessage($this->_failureMessage, $v);
		$_SESSION[SESSION_FAILURE_MESSAGE] = $this->_failureMessage;
	}

	// Get success message
	public function getSuccessMessage()
	{
		return isset($_SESSION[SESSION_SUCCESS_MESSAGE]) ? $_SESSION[SESSION_SUCCESS_MESSAGE] : $this->_successMessage;
	}

	// Set success message
	public function setSuccessMessage($v)
	{
		AddMessage($this->_successMessage, $v);
		$_SESSION[SESSION_SUCCESS_MESSAGE] = $this->_successMessage;
	}

	// Get warning message
	public function getWarningMessage()
	{
		return isset($_SESSION[SESSION_WARNING_MESSAGE]) ? $_SESSION[SESSION_WARNING_MESSAGE] : $this->_warningMessage;
	}

	// Set warning message
	public function setWarningMessage($v)
	{
		AddMessage($this->_warningMessage, $v);
		$_SESSION[SESSION_WARNING_MESSAGE] = $this->_warningMessage;
	}

	// Clear message
	public function clearMessage()
	{
		$this->_message = "";
		$_SESSION[SESSION_MESSAGE] = "";
	}

	// Clear failure message
	public function clearFailureMessage()
	{
		$this->_failureMessage = "";
		$_SESSION[SESSION_FAILURE_MESSAGE] = "";
	}

	// Clear success message
	public function clearSuccessMessage()
	{
		$this->_successMessage = "";
		$_SESSION[SESSION_SUCCESS_MESSAGE] = "";
	}

	// Clear warning message
	public function clearWarningMessage()
	{
		$this->_warningMessage = "";
		$_SESSION[SESSION_WARNING_MESSAGE] = "";
	}

	// Clear messages
	public function clearMessages()
	{
		$this->clearMessage();
		$this->clearFailureMessage();
		$this->clearSuccessMessage();
		$this->clearWarningMessage();
	}

	// Show message
	public function showMessage()
	{
		$hidden = FALSE;
		$html = "";

		// Message
		$message = $this->getMessage();
		if (method_exists($this, "Message_Showing"))
			$this->Message_Showing($message, "");
		if ($message != "") { // Message in Session, display
			if (!$hidden)
				$message = '<button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button>' . $message;
			$html .= '<div class="alert alert-info alert-dismissible ew-info"><i class="icon fas fa-info"></i>' . $message . '</div>';
			$_SESSION[SESSION_MESSAGE] = ""; // Clear message in Session
		}

		// Warning message
		$warningMessage = $this->getWarningMessage();
		if (method_exists($this, "Message_Showing"))
			$this->Message_Showing($warningMessage, "warning");
		if ($warningMessage != "") { // Message in Session, display
			if (!$hidden)
				$warningMessage = '<button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button>' . $warningMessage;
			$html .= '<div class="alert alert-warning alert-dismissible ew-warning"><i class="icon fas fa-exclamation"></i>' . $warningMessage . '</div>';
			$_SESSION[SESSION_WARNING_MESSAGE] = ""; // Clear message in Session
		}

		// Success message
		$successMessage = $this->getSuccessMessage();
		if (method_exists($this, "Message_Showing"))
			$this->Message_Showing($successMessage, "success");
		if ($successMessage != "") { // Message in Session, display
			if (!$hidden)
				$successMessage = '<button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button>' . $successMessage;
			$html .= '<div class="alert alert-success alert-dismissible ew-success"><i class="icon fas fa-check"></i>' . $successMessage . '</div>';
			$_SESSION[SESSION_SUCCESS_MESSAGE] = ""; // Clear message in Session
		}

		// Failure message
		$errorMessage = $this->getFailureMessage();
		if (method_exists($this, "Message_Showing"))
			$this->Message_Showing($errorMessage, "failure");
		if ($errorMessage != "") { // Message in Session, display
			if (!$hidden)
				$errorMessage = '<button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button>' . $errorMessage;
			$html .= '<div class="alert alert-danger alert-dismissible ew-error"><i class="icon fas fa-ban"></i>' . $errorMessage . '</div>';
			$_SESSION[SESSION_FAILURE_MESSAGE] = ""; // Clear message in Session
		}
		echo '<div class="ew-message-dialog' . (($hidden) ? ' d-none' : "") . '">' . $html . '</div>';
	}

	// Get message as array
	public function getMessages()
	{
		$ar = [];

		// Message
		$message = $this->getMessage();

		//if (method_exists($this, "Message_Showing"))
		//	$this->Message_Showing($message, "");

		if ($message != "") { // Message in Session, display
			$ar["message"] = $message;
			$_SESSION[SESSION_MESSAGE] = ""; // Clear message in Session
		}

		// Warning message
		$warningMessage = $this->getWarningMessage();

		//if (method_exists($this, "Message_Showing"))
		//	$this->Message_Showing($warningMessage, "warning");

		if ($warningMessage != "") { // Message in Session, display
			$ar["warningMessage"] = $warningMessage;
			$_SESSION[SESSION_WARNING_MESSAGE] = ""; // Clear message in Session
		}

		// Success message
		$successMessage = $this->getSuccessMessage();

		//if (method_exists($this, "Message_Showing"))
		//	$this->Message_Showing($successMessage, "success");

		if ($successMessage != "") { // Message in Session, display
			$ar["successMessage"] = $successMessage;
			$_SESSION[SESSION_SUCCESS_MESSAGE] = ""; // Clear message in Session
		}

		// Failure message
		$failureMessage = $this->getFailureMessage();

		//if (method_exists($this, "Message_Showing"))
		//	$this->Message_Showing($failureMessage, "failure");

		if ($failureMessage != "") { // Message in Session, display
			$ar["failureMessage"] = $failureMessage;
			$_SESSION[SESSION_FAILURE_MESSAGE] = ""; // Clear message in Session
		}
		return $ar;
	}

	// Show Page Header
	public function showPageHeader()
	{
		$header = $this->PageHeader;
		$this->Page_DataRendering($header);
		if ($header != "") { // Header exists, display
			echo '<p id="ew-page-header">' . $header . '</p>';
		}
	}

	// Show Page Footer
	public function showPageFooter()
	{
		$footer = $this->PageFooter;
		$this->Page_DataRendered($footer);
		if ($footer != "") { // Footer exists, display
			echo '<p id="ew-page-footer">' . $footer . '</p>';
		}
	}

	// Validate page request
	protected function isPageRequest()
	{
		global $CurrentForm;
		if ($this->UseTokenInUrl) {
			if ($CurrentForm)
				return ($this->TableVar == $CurrentForm->getValue("t"));
			if (Get("t") !== NULL)
				return ($this->TableVar == Get("t"));
		}
		return TRUE;
	}

	// Valid Post
	protected function validPost()
	{
		if (!$this->CheckToken || !IsPost() || IsApi())
			return TRUE;
		if (Post(Config("TOKEN_NAME")) === NULL)
			return FALSE;
		$fn = Config("CHECK_TOKEN_FUNC");
		if (is_callable($fn))
			return $fn(Post(Config("TOKEN_NAME")), $this->TokenTimeout);
		return FALSE;
	}

	// Create Token
	public function createToken()
	{
		global $CurrentToken;
		$fn = Config("CREATE_TOKEN_FUNC"); // Always create token, required by API file/lookup request
		if ($this->Token == "" && is_callable($fn)) // Create token
			$this->Token = $fn();
		$CurrentToken = $this->Token; // Save to global variable
	}

	// Constructor
	public function __construct()
	{
		global $Language, $DashboardReport;
		global $UserTable;

		// Check token
		$this->CheckToken = Config("CHECK_TOKEN");

		// Initialize
		$GLOBALS["Page"] = &$this;
		$this->TokenTimeout = SessionTimeoutTime();

		// Language object
		if (!isset($Language))
			$Language = new Language();

		// Parent constuctor
		parent::__construct();

		// Table object (country)
		if (!isset($GLOBALS["country"]) || get_class($GLOBALS["country"]) == PROJECT_NAMESPACE . "country") {
			$GLOBALS["country"] = &$this;
			$GLOBALS["Table"] = &$GLOBALS["country"];
		}

		// Table object (admin)
		if (!isset($GLOBALS['admin']))
			$GLOBALS['admin'] = new admin();

		// Page ID (for backward compatibility only)
		if (!defined(PROJECT_NAMESPACE . "PAGE_ID"))
			define(PROJECT_NAMESPACE . "PAGE_ID", 'delete');

		// Table name (for backward compatibility only)
		if (!defined(PROJECT_NAMESPACE . "TABLE_NAME"))
			define(PROJECT_NAMESPACE . "TABLE_NAME", 'country');

		// Start timer
		if (!isset($GLOBALS["DebugTimer"]))
			$GLOBALS["DebugTimer"] = new Timer();

		// Debug message
		LoadDebugMessage();

		// Open connection
		if (!isset($GLOBALS["Conn"]))
			$GLOBALS["Conn"] = $this->getConnection();

		// User table object (admin)
		$UserTable = $UserTable ?: new admin();
	}

	// Terminate page
	public function terminate($url = "")
	{
		global $ExportFileName, $TempImages, $DashboardReport;

		// Page Unload event
		$this->Page_Unload();

		// Global Page Unloaded event (in userfn*.php)
		Page_Unloaded();

		// Export
		global $country;
		if ($this->CustomExport && $this->CustomExport == $this->Export && array_key_exists($this->CustomExport, Config("EXPORT_CLASSES"))) {
				$content = ob_get_contents();
			if ($ExportFileName == "")
				$ExportFileName = $this->TableVar;
			$class = PROJECT_NAMESPACE . Config("EXPORT_CLASSES." . $this->CustomExport);
			if (class_exists($class)) {
				$doc = new $class($country);
				$doc->Text = @$content;
				if ($this->isExport("email"))
					echo $this->exportEmail($doc->Text);
				else
					$doc->export();
				DeleteTempImages(); // Delete temp images
				exit();
			}
		}
		if (!IsApi())
			$this->Page_Redirecting($url);

		// Close connection
		CloseConnections();

		// Return for API
		if (IsApi()) {
			$res = $url === TRUE;
			if (!$res) // Show error
				WriteJson(array_merge(["success" => FALSE], $this->getMessages()));
			return;
		}

		// Go to URL if specified
		if ($url != "") {
			if (!Config("DEBUG") && ob_get_length())
				ob_end_clean();
			SaveDebugMessage();
			AddHeader("Location", $url);
		}
		exit();
	}

	// Get records from recordset
	protected function getRecordsFromRecordset($rs, $current = FALSE)
	{
		$rows = [];
		if (is_object($rs)) { // Recordset
			while ($rs && !$rs->EOF) {
				$this->loadRowValues($rs); // Set up DbValue/CurrentValue
				$row = $this->getRecordFromArray($rs->fields);
				if ($current)
					return $row;
				else
					$rows[] = $row;
				$rs->moveNext();
			}
		} elseif (is_array($rs)) {
			foreach ($rs as $ar) {
				$row = $this->getRecordFromArray($ar);
				if ($current)
					return $row;
				else
					$rows[] = $row;
			}
		}
		return $rows;
	}

	// Get record from array
	protected function getRecordFromArray($ar)
	{
		$row = [];
		if (is_array($ar)) {
			foreach ($ar as $fldname => $val) {
				if (array_key_exists($fldname, $this->fields) && ($this->fields[$fldname]->Visible || $this->fields[$fldname]->IsPrimaryKey)) { // Primary key or Visible
					$fld = &$this->fields[$fldname];
					if ($fld->HtmlTag == "FILE") { // Upload field
						if (EmptyValue($val)) {
							$row[$fldname] = NULL;
						} else {
							if ($fld->DataType == DATATYPE_BLOB) {
								$url = FullUrl(GetApiUrl(Config("API_FILE_ACTION"),
									Config("API_OBJECT_NAME") . "=" . $fld->TableVar . "&" .
									Config("API_FIELD_NAME") . "=" . $fld->Param . "&" .
									Config("API_KEY_NAME") . "=" . rawurlencode($this->getRecordKeyValue($ar)))); //*** need to add this? API may not be in the same folder
								$row[$fldname] = ["type" => ContentType($val), "url" => $url, "name" => $fld->Param . ContentExtension($val)];
							} elseif (!$fld->UploadMultiple || !ContainsString($val, Config("MULTIPLE_UPLOAD_SEPARATOR"))) { // Single file
								$url = FullUrl(GetApiUrl(Config("API_FILE_ACTION"),
									Config("API_OBJECT_NAME") . "=" . $fld->TableVar . "&" .
									"fn=" . Encrypt($fld->physicalUploadPath() . $val)));
								$row[$fldname] = ["type" => MimeContentType($val), "url" => $url, "name" => $val];
							} else { // Multiple files
								$files = explode(Config("MULTIPLE_UPLOAD_SEPARATOR"), $val);
								$ar = [];
								foreach ($files as $file) {
									$url = FullUrl(GetApiUrl(Config("API_FILE_ACTION"),
										Config("API_OBJECT_NAME") . "=" . $fld->TableVar . "&" .
										"fn=" . Encrypt($fld->physicalUploadPath() . $file)));
									if (!EmptyValue($file))
										$ar[] = ["type" => MimeContentType($file), "url" => $url, "name" => $file];
								}
								$row[$fldname] = $ar;
							}
						}
					} else {
						$row[$fldname] = $val;
					}
				}
			}
		}
		return $row;
	}

	// Get record key value from array
	protected function getRecordKeyValue($ar)
	{
		$key = "";
		if (is_array($ar)) {
			$key .= @$ar['countryID'];
		}
		return $key;
	}

	/**
	 * Hide fields for add/edit
	 *
	 * @return void
	 */
	protected function hideFieldsForAddEdit()
	{
	}

	// Set up API security
	public function setupApiSecurity()
	{
		global $Security;

		// Setup security for API request
		if ($Security->isLoggedIn()) $Security->TablePermission_Loading();
		$Security->loadCurrentUserLevel(Config("PROJECT_ID") . $this->TableName);
		if ($Security->isLoggedIn()) $Security->TablePermission_Loaded();
	}
	public $DbMasterFilter = "";
	public $DbDetailFilter = "";
	public $StartRecord;
	public $TotalRecords = 0;
	public $RecordCount;
	public $RecKeys = [];
	public $StartRowCount = 1;
	public $RowCount = 0;

	//
	// Page run
	//

	public function run()
	{
		global $ExportType, $CustomExportType, $ExportFileName, $UserProfile, $Language, $Security, $CurrentForm;

		// User profile
		$UserProfile = new UserProfile();

		// Security
		if (ValidApiRequest()) { // API request
			$this->setupApiSecurity(); // Set up API Security
			if (!$Security->canDelete()) {
				SetStatus(401); // Unauthorized
				return;
			}
		} else {
			$Security = new AdvancedSecurity();
			if (IsPasswordExpired())
				$this->terminate(GetUrl("changepwd.php"));
			if (!$Security->isLoggedIn())
				$Security->autoLogin();
			if ($Security->isLoggedIn())
				$Security->TablePermission_Loading();
			$Security->loadCurrentUserLevel($this->ProjectID . $this->TableName);
			if ($Security->isLoggedIn())
				$Security->TablePermission_Loaded();
			if (!$Security->canDelete()) {
				$Security->saveLastUrl();
				$this->setFailureMessage(DeniedMessage()); // Set no permission
				if ($Security->canList())
					$this->terminate(GetUrl("countrylist.php"));
				else
					$this->terminate(GetUrl("login.php"));
				return;
			}
		}
		$this->CurrentAction = Param("action"); // Set up current action
		$this->countryID->setVisibility();
		$this->name->setVisibility();
		$this->challengegroupid->setVisibility();
		$this->selfregistrationcapable->setVisibility();
		$this->memberof4pay->setVisibility();
		$this->verificationgroupid->setVisibility();
		$this->timezoneid->setVisibility();
		$this->defaultcurrency->setVisibility();
		$this->defaultlangid->setVisibility();
		$this->phonecountrycode->setVisibility();
		$this->phoneinternationalcode->setVisibility();
		$this->phonelocalcode->setVisibility();
		$this->hasstates->setVisibility();
		$this->phonemaskid->setVisibility();
		$this->active->setVisibility();
		$this->webregistrationallowed->setVisibility();
		$this->iso2chars->setVisibility();
		$this->iso3digits->setVisibility();
		$this->smsverificationsupported->setVisibility();
		$this->smsgatewayid->setVisibility();
		$this->zipenabled->setVisibility();
		$this->zipcodedefaultvalue->setVisibility();
		$this->includeinlisting->setVisibility();
		$this->residencyriskscore->setVisibility();
		$this->nationalityriskscore->setVisibility();
		$this->hideFieldsForAddEdit();

		// Do not use lookup cache
		$this->setUseLookupCache(FALSE);

		// Global Page Loading event (in userfn*.php)
		Page_Loading();

		// Page Load event
		$this->Page_Load();

		// Check token
		if (!$this->validPost()) {
			Write($Language->phrase("InvalidPostRequest"));
			$this->terminate();
		}

		// Create Token
		$this->createToken();

		// Set up lookup cache
		// Check permission

		if (!$Security->canDelete()) {
			$this->setFailureMessage(DeniedMessage()); // No permission
			$this->terminate("countrylist.php");
			return;
		}

		// Set up Breadcrumb
		$this->setupBreadcrumb();

		// Load key parameters
		$this->RecKeys = $this->getRecordKeys(); // Load record keys
		$filter = $this->getFilterFromRecordKeys();
		if ($filter == "") {
			$this->terminate("countrylist.php"); // Prevent SQL injection, return to list
			return;
		}

		// Set up filter (WHERE Clause)
		$this->CurrentFilter = $filter;

		// Get action
		if (IsApi()) {
			$this->CurrentAction = "delete"; // Delete record directly
		} elseif (Post("action") !== NULL) {
			$this->CurrentAction = Post("action");
		} elseif (Get("action") == "1") {
			$this->CurrentAction = "delete"; // Delete record directly
		} else {
			$this->CurrentAction = "show"; // Display record
		}
		if ($this->isDelete()) {
			$this->SendEmail = TRUE; // Send email on delete success
			if ($this->deleteRows()) { // Delete rows
				if ($this->getSuccessMessage() == "")
					$this->setSuccessMessage($Language->phrase("DeleteSuccess")); // Set up success message
				if (IsApi()) {
					$this->terminate(TRUE);
					return;
				} else {
					$this->terminate($this->getReturnUrl()); // Return to caller
				}
			} else { // Delete failed
				if (IsApi()) {
					$this->terminate();
					return;
				}
				$this->CurrentAction = "show"; // Display record
			}
		}
		if ($this->isShow()) { // Load records for display
			if ($this->Recordset = $this->loadRecordset())
				$this->TotalRecords = $this->Recordset->RecordCount(); // Get record count
			if ($this->TotalRecords <= 0) { // No record found, exit
				if ($this->Recordset)
					$this->Recordset->close();
				$this->terminate("countrylist.php"); // Return to list
			}
		}
	}

	// Load recordset
	public function loadRecordset($offset = -1, $rowcnt = -1)
	{

		// Load List page SQL
		$sql = $this->getListSql();
		$conn = $this->getConnection();

		// Load recordset
		$dbtype = GetConnectionType($this->Dbid);
		if ($this->UseSelectLimit) {
			$conn->raiseErrorFn = Config("ERROR_FUNC");
			if ($dbtype == "MSSQL") {
				$rs = $conn->selectLimit($sql, $rowcnt, $offset, ["_hasOrderBy" => trim($this->getOrderBy()) || trim($this->getSessionOrderBy())]);
			} else {
				$rs = $conn->selectLimit($sql, $rowcnt, $offset);
			}
			$conn->raiseErrorFn = "";
		} else {
			$rs = LoadRecordset($sql, $conn);
		}

		// Call Recordset Selected event
		$this->Recordset_Selected($rs);
		return $rs;
	}

	// Load row based on key values
	public function loadRow()
	{
		global $Security, $Language;
		$filter = $this->getRecordFilter();

		// Call Row Selecting event
		$this->Row_Selecting($filter);

		// Load SQL based on filter
		$this->CurrentFilter = $filter;
		$sql = $this->getCurrentSql();
		$conn = $this->getConnection();
		$res = FALSE;
		$rs = LoadRecordset($sql, $conn);
		if ($rs && !$rs->EOF) {
			$res = TRUE;
			$this->loadRowValues($rs); // Load row values
			$rs->close();
		}
		return $res;
	}

	// Load row values from recordset
	public function loadRowValues($rs = NULL)
	{
		if ($rs && !$rs->EOF)
			$row = $rs->fields;
		else
			$row = $this->newRow();

		// Call Row Selected event
		$this->Row_Selected($row);
		if (!$rs || $rs->EOF)
			return;
		$this->countryID->setDbValue($row['countryID']);
		$this->name->setDbValue($row['name']);
		$this->challengegroupid->setDbValue($row['challengegroupid']);
		$this->selfregistrationcapable->setDbValue($row['selfregistrationcapable']);
		$this->memberof4pay->setDbValue($row['memberof4pay']);
		$this->verificationgroupid->setDbValue($row['verificationgroupid']);
		$this->timezoneid->setDbValue($row['timezoneid']);
		$this->defaultcurrency->setDbValue($row['defaultcurrency']);
		$this->defaultlangid->setDbValue($row['defaultlangid']);
		$this->phonecountrycode->setDbValue($row['phonecountrycode']);
		$this->phoneinternationalcode->setDbValue($row['phoneinternationalcode']);
		$this->phonelocalcode->setDbValue($row['phonelocalcode']);
		$this->hasstates->setDbValue($row['hasstates']);
		$this->phonemaskid->setDbValue($row['phonemaskid']);
		$this->active->setDbValue($row['active']);
		$this->webregistrationallowed->setDbValue($row['webregistrationallowed']);
		$this->iso2chars->setDbValue($row['iso2chars']);
		$this->iso3digits->setDbValue($row['iso3digits']);
		$this->smsverificationsupported->setDbValue($row['smsverificationsupported']);
		$this->smsgatewayid->setDbValue($row['smsgatewayid']);
		$this->zipenabled->setDbValue($row['zipenabled']);
		$this->zipcodedefaultvalue->setDbValue($row['zipcodedefaultvalue']);
		$this->includeinlisting->setDbValue($row['includeinlisting']);
		$this->residencyriskscore->setDbValue($row['residencyriskscore']);
		$this->nationalityriskscore->setDbValue($row['nationalityriskscore']);
	}

	// Return a row with default values
	protected function newRow()
	{
		$row = [];
		$row['countryID'] = NULL;
		$row['name'] = NULL;
		$row['challengegroupid'] = NULL;
		$row['selfregistrationcapable'] = NULL;
		$row['memberof4pay'] = NULL;
		$row['verificationgroupid'] = NULL;
		$row['timezoneid'] = NULL;
		$row['defaultcurrency'] = NULL;
		$row['defaultlangid'] = NULL;
		$row['phonecountrycode'] = NULL;
		$row['phoneinternationalcode'] = NULL;
		$row['phonelocalcode'] = NULL;
		$row['hasstates'] = NULL;
		$row['phonemaskid'] = NULL;
		$row['active'] = NULL;
		$row['webregistrationallowed'] = NULL;
		$row['iso2chars'] = NULL;
		$row['iso3digits'] = NULL;
		$row['smsverificationsupported'] = NULL;
		$row['smsgatewayid'] = NULL;
		$row['zipenabled'] = NULL;
		$row['zipcodedefaultvalue'] = NULL;
		$row['includeinlisting'] = NULL;
		$row['residencyriskscore'] = NULL;
		$row['nationalityriskscore'] = NULL;
		return $row;
	}

	// Render row values based on field settings
	public function renderRow()
	{
		global $Security, $Language, $CurrentLanguage;

		// Initialize URLs
		// Call Row_Rendering event

		$this->Row_Rendering();

		// Common render codes for all row types
		// countryID
		// name
		// challengegroupid
		// selfregistrationcapable
		// memberof4pay
		// verificationgroupid
		// timezoneid
		// defaultcurrency
		// defaultlangid
		// phonecountrycode
		// phoneinternationalcode
		// phonelocalcode
		// hasstates
		// phonemaskid
		// active
		// webregistrationallowed
		// iso2chars
		// iso3digits
		// smsverificationsupported
		// smsgatewayid
		// zipenabled
		// zipcodedefaultvalue
		// includeinlisting
		// residencyriskscore
		// nationalityriskscore

		if ($this->RowType == ROWTYPE_VIEW) { // View row

			// countryID
			$this->countryID->ViewValue = $this->countryID->CurrentValue;
			$this->countryID->ViewCustomAttributes = "";

			// name
			$this->name->ViewValue = $this->name->CurrentValue;
			$this->name->ViewCustomAttributes = "";

			// challengegroupid
			$this->challengegroupid->ViewValue = $this->challengegroupid->CurrentValue;
			$this->challengegroupid->ViewValue = FormatNumber($this->challengegroupid->ViewValue, 0, -2, -2, -2);
			$this->challengegroupid->ViewCustomAttributes = "";

			// selfregistrationcapable
			$this->selfregistrationcapable->ViewValue = $this->selfregistrationcapable->CurrentValue;
			$this->selfregistrationcapable->ViewValue = FormatNumber($this->selfregistrationcapable->ViewValue, 0, -2, -2, -2);
			$this->selfregistrationcapable->ViewCustomAttributes = "";

			// memberof4pay
			$this->memberof4pay->ViewValue = $this->memberof4pay->CurrentValue;
			$this->memberof4pay->ViewValue = FormatNumber($this->memberof4pay->ViewValue, 0, -2, -2, -2);
			$this->memberof4pay->ViewCustomAttributes = "";

			// verificationgroupid
			$this->verificationgroupid->ViewValue = $this->verificationgroupid->CurrentValue;
			$this->verificationgroupid->ViewValue = FormatNumber($this->verificationgroupid->ViewValue, 0, -2, -2, -2);
			$this->verificationgroupid->ViewCustomAttributes = "";

			// timezoneid
			$this->timezoneid->ViewValue = $this->timezoneid->CurrentValue;
			$this->timezoneid->ViewValue = FormatNumber($this->timezoneid->ViewValue, 0, -2, -2, -2);
			$this->timezoneid->ViewCustomAttributes = "";

			// defaultcurrency
			$this->defaultcurrency->ViewValue = $this->defaultcurrency->CurrentValue;
			$this->defaultcurrency->ViewCustomAttributes = "";

			// defaultlangid
			$this->defaultlangid->ViewValue = $this->defaultlangid->CurrentValue;
			$this->defaultlangid->ViewCustomAttributes = "";

			// phonecountrycode
			$this->phonecountrycode->ViewValue = $this->phonecountrycode->CurrentValue;
			$this->phonecountrycode->ViewCustomAttributes = "";

			// phoneinternationalcode
			$this->phoneinternationalcode->ViewValue = $this->phoneinternationalcode->CurrentValue;
			$this->phoneinternationalcode->ViewCustomAttributes = "";

			// phonelocalcode
			$this->phonelocalcode->ViewValue = $this->phonelocalcode->CurrentValue;
			$this->phonelocalcode->ViewCustomAttributes = "";

			// hasstates
			$this->hasstates->ViewValue = $this->hasstates->CurrentValue;
			$this->hasstates->ViewValue = FormatNumber($this->hasstates->ViewValue, 0, -2, -2, -2);
			$this->hasstates->ViewCustomAttributes = "";

			// phonemaskid
			$this->phonemaskid->ViewValue = $this->phonemaskid->CurrentValue;
			$this->phonemaskid->ViewValue = FormatNumber($this->phonemaskid->ViewValue, 0, -2, -2, -2);
			$this->phonemaskid->ViewCustomAttributes = "";

			// active
			$this->active->ViewValue = $this->active->CurrentValue;
			$this->active->ViewValue = FormatNumber($this->active->ViewValue, 0, -2, -2, -2);
			$this->active->ViewCustomAttributes = "";

			// webregistrationallowed
			$this->webregistrationallowed->ViewValue = $this->webregistrationallowed->CurrentValue;
			$this->webregistrationallowed->ViewValue = FormatNumber($this->webregistrationallowed->ViewValue, 0, -2, -2, -2);
			$this->webregistrationallowed->ViewCustomAttributes = "";

			// iso2chars
			$this->iso2chars->ViewValue = $this->iso2chars->CurrentValue;
			$this->iso2chars->ViewCustomAttributes = "";

			// iso3digits
			$this->iso3digits->ViewValue = $this->iso3digits->CurrentValue;
			$this->iso3digits->ViewCustomAttributes = "";

			// smsverificationsupported
			$this->smsverificationsupported->ViewValue = $this->smsverificationsupported->CurrentValue;
			$this->smsverificationsupported->ViewValue = FormatNumber($this->smsverificationsupported->ViewValue, 0, -2, -2, -2);
			$this->smsverificationsupported->ViewCustomAttributes = "";

			// smsgatewayid
			$this->smsgatewayid->ViewValue = $this->smsgatewayid->CurrentValue;
			$this->smsgatewayid->ViewValue = FormatNumber($this->smsgatewayid->ViewValue, 0, -2, -2, -2);
			$this->smsgatewayid->ViewCustomAttributes = "";

			// zipenabled
			$this->zipenabled->ViewValue = $this->zipenabled->CurrentValue;
			$this->zipenabled->ViewValue = FormatNumber($this->zipenabled->ViewValue, 0, -2, -2, -2);
			$this->zipenabled->ViewCustomAttributes = "";

			// zipcodedefaultvalue
			$this->zipcodedefaultvalue->ViewValue = $this->zipcodedefaultvalue->CurrentValue;
			$this->zipcodedefaultvalue->ViewCustomAttributes = "";

			// includeinlisting
			$this->includeinlisting->ViewValue = $this->includeinlisting->CurrentValue;
			$this->includeinlisting->ViewValue = FormatNumber($this->includeinlisting->ViewValue, 0, -2, -2, -2);
			$this->includeinlisting->ViewCustomAttributes = "";

			// residencyriskscore
			$this->residencyriskscore->ViewValue = $this->residencyriskscore->CurrentValue;
			$this->residencyriskscore->ViewValue = FormatNumber($this->residencyriskscore->ViewValue, 0, -2, -2, -2);
			$this->residencyriskscore->ViewCustomAttributes = "";

			// nationalityriskscore
			$this->nationalityriskscore->ViewValue = $this->nationalityriskscore->CurrentValue;
			$this->nationalityriskscore->ViewValue = FormatNumber($this->nationalityriskscore->ViewValue, 0, -2, -2, -2);
			$this->nationalityriskscore->ViewCustomAttributes = "";

			// countryID
			$this->countryID->LinkCustomAttributes = "";
			$this->countryID->HrefValue = "";
			$this->countryID->TooltipValue = "";

			// name
			$this->name->LinkCustomAttributes = "";
			$this->name->HrefValue = "";
			$this->name->TooltipValue = "";

			// challengegroupid
			$this->challengegroupid->LinkCustomAttributes = "";
			$this->challengegroupid->HrefValue = "";
			$this->challengegroupid->TooltipValue = "";

			// selfregistrationcapable
			$this->selfregistrationcapable->LinkCustomAttributes = "";
			$this->selfregistrationcapable->HrefValue = "";
			$this->selfregistrationcapable->TooltipValue = "";

			// memberof4pay
			$this->memberof4pay->LinkCustomAttributes = "";
			$this->memberof4pay->HrefValue = "";
			$this->memberof4pay->TooltipValue = "";

			// verificationgroupid
			$this->verificationgroupid->LinkCustomAttributes = "";
			$this->verificationgroupid->HrefValue = "";
			$this->verificationgroupid->TooltipValue = "";

			// timezoneid
			$this->timezoneid->LinkCustomAttributes = "";
			$this->timezoneid->HrefValue = "";
			$this->timezoneid->TooltipValue = "";

			// defaultcurrency
			$this->defaultcurrency->LinkCustomAttributes = "";
			$this->defaultcurrency->HrefValue = "";
			$this->defaultcurrency->TooltipValue = "";

			// defaultlangid
			$this->defaultlangid->LinkCustomAttributes = "";
			$this->defaultlangid->HrefValue = "";
			$this->defaultlangid->TooltipValue = "";

			// phonecountrycode
			$this->phonecountrycode->LinkCustomAttributes = "";
			$this->phonecountrycode->HrefValue = "";
			$this->phonecountrycode->TooltipValue = "";

			// phoneinternationalcode
			$this->phoneinternationalcode->LinkCustomAttributes = "";
			$this->phoneinternationalcode->HrefValue = "";
			$this->phoneinternationalcode->TooltipValue = "";

			// phonelocalcode
			$this->phonelocalcode->LinkCustomAttributes = "";
			$this->phonelocalcode->HrefValue = "";
			$this->phonelocalcode->TooltipValue = "";

			// hasstates
			$this->hasstates->LinkCustomAttributes = "";
			$this->hasstates->HrefValue = "";
			$this->hasstates->TooltipValue = "";

			// phonemaskid
			$this->phonemaskid->LinkCustomAttributes = "";
			$this->phonemaskid->HrefValue = "";
			$this->phonemaskid->TooltipValue = "";

			// active
			$this->active->LinkCustomAttributes = "";
			$this->active->HrefValue = "";
			$this->active->TooltipValue = "";

			// webregistrationallowed
			$this->webregistrationallowed->LinkCustomAttributes = "";
			$this->webregistrationallowed->HrefValue = "";
			$this->webregistrationallowed->TooltipValue = "";

			// iso2chars
			$this->iso2chars->LinkCustomAttributes = "";
			$this->iso2chars->HrefValue = "";
			$this->iso2chars->TooltipValue = "";

			// iso3digits
			$this->iso3digits->LinkCustomAttributes = "";
			$this->iso3digits->HrefValue = "";
			$this->iso3digits->TooltipValue = "";

			// smsverificationsupported
			$this->smsverificationsupported->LinkCustomAttributes = "";
			$this->smsverificationsupported->HrefValue = "";
			$this->smsverificationsupported->TooltipValue = "";

			// smsgatewayid
			$this->smsgatewayid->LinkCustomAttributes = "";
			$this->smsgatewayid->HrefValue = "";
			$this->smsgatewayid->TooltipValue = "";

			// zipenabled
			$this->zipenabled->LinkCustomAttributes = "";
			$this->zipenabled->HrefValue = "";
			$this->zipenabled->TooltipValue = "";

			// zipcodedefaultvalue
			$this->zipcodedefaultvalue->LinkCustomAttributes = "";
			$this->zipcodedefaultvalue->HrefValue = "";
			$this->zipcodedefaultvalue->TooltipValue = "";

			// includeinlisting
			$this->includeinlisting->LinkCustomAttributes = "";
			$this->includeinlisting->HrefValue = "";
			$this->includeinlisting->TooltipValue = "";

			// residencyriskscore
			$this->residencyriskscore->LinkCustomAttributes = "";
			$this->residencyriskscore->HrefValue = "";
			$this->residencyriskscore->TooltipValue = "";

			// nationalityriskscore
			$this->nationalityriskscore->LinkCustomAttributes = "";
			$this->nationalityriskscore->HrefValue = "";
			$this->nationalityriskscore->TooltipValue = "";
		}

		// Call Row Rendered event
		if ($this->RowType != ROWTYPE_AGGREGATEINIT)
			$this->Row_Rendered();
	}

	// Delete records based on current filter
	protected function deleteRows()
	{
		global $Language, $Security;
		if (!$Security->canDelete()) {
			$this->setFailureMessage($Language->phrase("NoDeletePermission")); // No delete permission
			return FALSE;
		}
		$deleteRows = TRUE;
		$sql = $this->getCurrentSql();
		$conn = $this->getConnection();
		$conn->raiseErrorFn = Config("ERROR_FUNC");
		$rs = $conn->execute($sql);
		$conn->raiseErrorFn = "";
		if ($rs === FALSE) {
			return FALSE;
		} elseif ($rs->EOF) {
			$this->setFailureMessage($Language->phrase("NoRecord")); // No record found
			$rs->close();
			return FALSE;
		}
		$rows = ($rs) ? $rs->getRows() : [];
		$conn->beginTrans();

		// Clone old rows
		$rsold = $rows;
		if ($rs)
			$rs->close();

		// Call row deleting event
		if ($deleteRows) {
			foreach ($rsold as $row) {
				$deleteRows = $this->Row_Deleting($row);
				if (!$deleteRows)
					break;
			}
		}
		if ($deleteRows) {
			$key = "";
			foreach ($rsold as $row) {
				$thisKey = "";
				if ($thisKey != "")
					$thisKey .= Config("COMPOSITE_KEY_SEPARATOR");
				$thisKey .= $row['countryID'];
				if (Config("DELETE_UPLOADED_FILES")) // Delete old files
					$this->deleteUploadedFiles($row);
				$conn->raiseErrorFn = Config("ERROR_FUNC");
				$deleteRows = $this->delete($row); // Delete
				$conn->raiseErrorFn = "";
				if ($deleteRows === FALSE)
					break;
				if ($key != "")
					$key .= ", ";
				$key .= $thisKey;
			}
		}
		if (!$deleteRows) {

			// Set up error message
			if ($this->getSuccessMessage() != "" || $this->getFailureMessage() != "") {

				// Use the message, do nothing
			} elseif ($this->CancelMessage != "") {
				$this->setFailureMessage($this->CancelMessage);
				$this->CancelMessage = "";
			} else {
				$this->setFailureMessage($Language->phrase("DeleteCancelled"));
			}
		}
		if ($deleteRows) {
			$conn->commitTrans(); // Commit the changes
		} else {
			$conn->rollbackTrans(); // Rollback changes
		}

		// Call Row Deleted event
		if ($deleteRows) {
			foreach ($rsold as $row) {
				$this->Row_Deleted($row);
			}
		}

		// Write JSON for API request (Support single row only)
		if (IsApi() && $deleteRows) {
			$row = $this->getRecordsFromRecordset($rsold, TRUE);
			WriteJson(["success" => TRUE, $this->TableVar => $row]);
		}
		return $deleteRows;
	}

	// Set up Breadcrumb
	protected function setupBreadcrumb()
	{
		global $Breadcrumb, $Language;
		$Breadcrumb = new Breadcrumb();
		$url = substr(CurrentUrl(), strrpos(CurrentUrl(), "/")+1);
		$Breadcrumb->add("list", $this->TableVar, $this->addMasterUrl("countrylist.php"), "", $this->TableVar, TRUE);
		$pageId = "delete";
		$Breadcrumb->add("delete", $pageId, $url);
	}

	// Setup lookup options
	public function setupLookupOptions($fld)
	{
		if ($fld->Lookup !== NULL && $fld->Lookup->Options === NULL) {

			// Get default connection and filter
			$conn = $this->getConnection();
			$lookupFilter = "";

			// No need to check any more
			$fld->Lookup->Options = [];

			// Set up lookup SQL and connection
			switch ($fld->FieldVar) {
				default:
					$lookupFilter = "";
					break;
			}

			// Always call to Lookup->getSql so that user can setup Lookup->Options in Lookup_Selecting server event
			$sql = $fld->Lookup->getSql(FALSE, "", $lookupFilter, $this);

			// Set up lookup cache
			if ($fld->UseLookupCache && $sql != "" && count($fld->Lookup->Options) == 0) {
				$totalCnt = $this->getRecordCount($sql, $conn);
				if ($totalCnt > $fld->LookupCacheCount) // Total count > cache count, do not cache
					return;
				$rs = $conn->execute($sql);
				$ar = [];
				while ($rs && !$rs->EOF) {
					$row = &$rs->fields;

					// Format the field values
					switch ($fld->FieldVar) {
					}
					$ar[strval($row[0])] = $row;
					$rs->moveNext();
				}
				if ($rs)
					$rs->close();
				$fld->Lookup->Options = $ar;
			}
		}
	}

	// Page Load event
	function Page_Load() {

		//echo "Page Load";
	}

	// Page Unload event
	function Page_Unload() {

		//echo "Page Unload";
	}

	// Page Redirecting event
	function Page_Redirecting(&$url) {

		// Example:
		//$url = "your URL";

	}

	// Message Showing event
	// $type = ''|'success'|'failure'|'warning'
	function Message_Showing(&$msg, $type) {
		if ($type == 'success') {

			//$msg = "your success message";
		} elseif ($type == 'failure') {

			//$msg = "your failure message";
		} elseif ($type == 'warning') {

			//$msg = "your warning message";
		} else {

			//$msg = "your message";
		}
	}

	// Page Render event
	function Page_Render() {

		//echo "Page Render";
	}

	// Page Data Rendering event
	function Page_DataRendering(&$header) {

		// Example:
		//$header = "your header";

	}

	// Page Data Rendered event
	function Page_DataRendered(&$footer) {

		// Example:
		//$footer = "your footer";

	}
} // End class
?>