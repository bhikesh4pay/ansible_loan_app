<?php
namespace PHPMaker2020\_4payadmin;

/**
 * Page class
 */
class extrafieldstemplate_add extends extrafieldstemplate
{

	// Page ID
	public $PageID = "add";

	// Project ID
	public $ProjectID = "{153C2D2E-60EE-4944-8753-3935EB38E8D6}";

	// Table name
	public $TableName = 'extrafieldstemplate';

	// Page object name
	public $PageObjName = "extrafieldstemplate_add";

	// Audit Trail
	public $AuditTrailOnAdd = TRUE;
	public $AuditTrailOnEdit = TRUE;
	public $AuditTrailOnDelete = TRUE;
	public $AuditTrailOnView = FALSE;
	public $AuditTrailOnViewData = FALSE;
	public $AuditTrailOnSearch = FALSE;

	// Page headings
	public $Heading = "";
	public $Subheading = "";
	public $PageHeader;
	public $PageFooter;

	// Token
	public $Token = "";
	public $TokenTimeout = 0;
	public $CheckToken;

	// Page heading
	public function pageHeading()
	{
		global $Language;
		if ($this->Heading != "")
			return $this->Heading;
		if (method_exists($this, "tableCaption"))
			return $this->tableCaption();
		return "";
	}

	// Page subheading
	public function pageSubheading()
	{
		global $Language;
		if ($this->Subheading != "")
			return $this->Subheading;
		if ($this->TableName)
			return $Language->phrase($this->PageID);
		return "";
	}

	// Page name
	public function pageName()
	{
		return CurrentPageName();
	}

	// Page URL
	public function pageUrl()
	{
		$url = CurrentPageName() . "?";
		if ($this->UseTokenInUrl)
			$url .= "t=" . $this->TableVar . "&"; // Add page token
		return $url;
	}

	// Messages
	private $_message = "";
	private $_failureMessage = "";
	private $_successMessage = "";
	private $_warningMessage = "";

	// Get message
	public function getMessage()
	{
		return isset($_SESSION[SESSION_MESSAGE]) ? $_SESSION[SESSION_MESSAGE] : $this->_message;
	}

	// Set message
	public function setMessage($v)
	{
		AddMessage($this->_message, $v);
		$_SESSION[SESSION_MESSAGE] = $this->_message;
	}

	// Get failure message
	public function getFailureMessage()
	{
		return isset($_SESSION[SESSION_FAILURE_MESSAGE]) ? $_SESSION[SESSION_FAILURE_MESSAGE] : $this->_failureMessage;
	}

	// Set failure message
	public function setFailureMessage($v)
	{
		AddMessage($this->_failureMessage, $v);
		$_SESSION[SESSION_FAILURE_MESSAGE] = $this->_failureMessage;
	}

	// Get success message
	public function getSuccessMessage()
	{
		return isset($_SESSION[SESSION_SUCCESS_MESSAGE]) ? $_SESSION[SESSION_SUCCESS_MESSAGE] : $this->_successMessage;
	}

	// Set success message
	public function setSuccessMessage($v)
	{
		AddMessage($this->_successMessage, $v);
		$_SESSION[SESSION_SUCCESS_MESSAGE] = $this->_successMessage;
	}

	// Get warning message
	public function getWarningMessage()
	{
		return isset($_SESSION[SESSION_WARNING_MESSAGE]) ? $_SESSION[SESSION_WARNING_MESSAGE] : $this->_warningMessage;
	}

	// Set warning message
	public function setWarningMessage($v)
	{
		AddMessage($this->_warningMessage, $v);
		$_SESSION[SESSION_WARNING_MESSAGE] = $this->_warningMessage;
	}

	// Clear message
	public function clearMessage()
	{
		$this->_message = "";
		$_SESSION[SESSION_MESSAGE] = "";
	}

	// Clear failure message
	public function clearFailureMessage()
	{
		$this->_failureMessage = "";
		$_SESSION[SESSION_FAILURE_MESSAGE] = "";
	}

	// Clear success message
	public function clearSuccessMessage()
	{
		$this->_successMessage = "";
		$_SESSION[SESSION_SUCCESS_MESSAGE] = "";
	}

	// Clear warning message
	public function clearWarningMessage()
	{
		$this->_warningMessage = "";
		$_SESSION[SESSION_WARNING_MESSAGE] = "";
	}

	// Clear messages
	public function clearMessages()
	{
		$this->clearMessage();
		$this->clearFailureMessage();
		$this->clearSuccessMessage();
		$this->clearWarningMessage();
	}

	// Show message
	public function showMessage()
	{
		$hidden = FALSE;
		$html = "";

		// Message
		$message = $this->getMessage();
		if (method_exists($this, "Message_Showing"))
			$this->Message_Showing($message, "");
		if ($message != "") { // Message in Session, display
			if (!$hidden)
				$message = '<button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button>' . $message;
			$html .= '<div class="alert alert-info alert-dismissible ew-info"><i class="icon fas fa-info"></i>' . $message . '</div>';
			$_SESSION[SESSION_MESSAGE] = ""; // Clear message in Session
		}

		// Warning message
		$warningMessage = $this->getWarningMessage();
		if (method_exists($this, "Message_Showing"))
			$this->Message_Showing($warningMessage, "warning");
		if ($warningMessage != "") { // Message in Session, display
			if (!$hidden)
				$warningMessage = '<button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button>' . $warningMessage;
			$html .= '<div class="alert alert-warning alert-dismissible ew-warning"><i class="icon fas fa-exclamation"></i>' . $warningMessage . '</div>';
			$_SESSION[SESSION_WARNING_MESSAGE] = ""; // Clear message in Session
		}

		// Success message
		$successMessage = $this->getSuccessMessage();
		if (method_exists($this, "Message_Showing"))
			$this->Message_Showing($successMessage, "success");
		if ($successMessage != "") { // Message in Session, display
			if (!$hidden)
				$successMessage = '<button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button>' . $successMessage;
			$html .= '<div class="alert alert-success alert-dismissible ew-success"><i class="icon fas fa-check"></i>' . $successMessage . '</div>';
			$_SESSION[SESSION_SUCCESS_MESSAGE] = ""; // Clear message in Session
		}

		// Failure message
		$errorMessage = $this->getFailureMessage();
		if (method_exists($this, "Message_Showing"))
			$this->Message_Showing($errorMessage, "failure");
		if ($errorMessage != "") { // Message in Session, display
			if (!$hidden)
				$errorMessage = '<button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button>' . $errorMessage;
			$html .= '<div class="alert alert-danger alert-dismissible ew-error"><i class="icon fas fa-ban"></i>' . $errorMessage . '</div>';
			$_SESSION[SESSION_FAILURE_MESSAGE] = ""; // Clear message in Session
		}
		echo '<div class="ew-message-dialog' . (($hidden) ? ' d-none' : "") . '">' . $html . '</div>';
	}

	// Get message as array
	public function getMessages()
	{
		$ar = [];

		// Message
		$message = $this->getMessage();

		//if (method_exists($this, "Message_Showing"))
		//	$this->Message_Showing($message, "");

		if ($message != "") { // Message in Session, display
			$ar["message"] = $message;
			$_SESSION[SESSION_MESSAGE] = ""; // Clear message in Session
		}

		// Warning message
		$warningMessage = $this->getWarningMessage();

		//if (method_exists($this, "Message_Showing"))
		//	$this->Message_Showing($warningMessage, "warning");

		if ($warningMessage != "") { // Message in Session, display
			$ar["warningMessage"] = $warningMessage;
			$_SESSION[SESSION_WARNING_MESSAGE] = ""; // Clear message in Session
		}

		// Success message
		$successMessage = $this->getSuccessMessage();

		//if (method_exists($this, "Message_Showing"))
		//	$this->Message_Showing($successMessage, "success");

		if ($successMessage != "") { // Message in Session, display
			$ar["successMessage"] = $successMessage;
			$_SESSION[SESSION_SUCCESS_MESSAGE] = ""; // Clear message in Session
		}

		// Failure message
		$failureMessage = $this->getFailureMessage();

		//if (method_exists($this, "Message_Showing"))
		//	$this->Message_Showing($failureMessage, "failure");

		if ($failureMessage != "") { // Message in Session, display
			$ar["failureMessage"] = $failureMessage;
			$_SESSION[SESSION_FAILURE_MESSAGE] = ""; // Clear message in Session
		}
		return $ar;
	}

	// Show Page Header
	public function showPageHeader()
	{
		$header = $this->PageHeader;
		$this->Page_DataRendering($header);
		if ($header != "") { // Header exists, display
			echo '<p id="ew-page-header">' . $header . '</p>';
		}
	}

	// Show Page Footer
	public function showPageFooter()
	{
		$footer = $this->PageFooter;
		$this->Page_DataRendered($footer);
		if ($footer != "") { // Footer exists, display
			echo '<p id="ew-page-footer">' . $footer . '</p>';
		}
	}

	// Validate page request
	protected function isPageRequest()
	{
		global $CurrentForm;
		if ($this->UseTokenInUrl) {
			if ($CurrentForm)
				return ($this->TableVar == $CurrentForm->getValue("t"));
			if (Get("t") !== NULL)
				return ($this->TableVar == Get("t"));
		}
		return TRUE;
	}

	// Valid Post
	protected function validPost()
	{
		if (!$this->CheckToken || !IsPost() || IsApi())
			return TRUE;
		if (Post(Config("TOKEN_NAME")) === NULL)
			return FALSE;
		$fn = Config("CHECK_TOKEN_FUNC");
		if (is_callable($fn))
			return $fn(Post(Config("TOKEN_NAME")), $this->TokenTimeout);
		return FALSE;
	}

	// Create Token
	public function createToken()
	{
		global $CurrentToken;
		$fn = Config("CREATE_TOKEN_FUNC"); // Always create token, required by API file/lookup request
		if ($this->Token == "" && is_callable($fn)) // Create token
			$this->Token = $fn();
		$CurrentToken = $this->Token; // Save to global variable
	}

	// Constructor
	public function __construct()
	{
		global $Language, $DashboardReport;
		global $UserTable;

		// Check token
		$this->CheckToken = Config("CHECK_TOKEN");

		// Initialize
		$GLOBALS["Page"] = &$this;
		$this->TokenTimeout = SessionTimeoutTime();

		// Language object
		if (!isset($Language))
			$Language = new Language();

		// Parent constuctor
		parent::__construct();

		// Table object (extrafieldstemplate)
		if (!isset($GLOBALS["extrafieldstemplate"]) || get_class($GLOBALS["extrafieldstemplate"]) == PROJECT_NAMESPACE . "extrafieldstemplate") {
			$GLOBALS["extrafieldstemplate"] = &$this;
			$GLOBALS["Table"] = &$GLOBALS["extrafieldstemplate"];
		}

		// Table object (admin)
		if (!isset($GLOBALS['admin']))
			$GLOBALS['admin'] = new admin();

		// Page ID (for backward compatibility only)
		if (!defined(PROJECT_NAMESPACE . "PAGE_ID"))
			define(PROJECT_NAMESPACE . "PAGE_ID", 'add');

		// Table name (for backward compatibility only)
		if (!defined(PROJECT_NAMESPACE . "TABLE_NAME"))
			define(PROJECT_NAMESPACE . "TABLE_NAME", 'extrafieldstemplate');

		// Start timer
		if (!isset($GLOBALS["DebugTimer"]))
			$GLOBALS["DebugTimer"] = new Timer();

		// Debug message
		LoadDebugMessage();

		// Open connection
		if (!isset($GLOBALS["Conn"]))
			$GLOBALS["Conn"] = $this->getConnection();

		// User table object (admin)
		$UserTable = $UserTable ?: new admin();
	}

	// Terminate page
	public function terminate($url = "")
	{
		global $ExportFileName, $TempImages, $DashboardReport;

		// Page Unload event
		$this->Page_Unload();

		// Global Page Unloaded event (in userfn*.php)
		Page_Unloaded();

		// Export
		global $extrafieldstemplate;
		if ($this->CustomExport && $this->CustomExport == $this->Export && array_key_exists($this->CustomExport, Config("EXPORT_CLASSES"))) {
				$content = ob_get_contents();
			if ($ExportFileName == "")
				$ExportFileName = $this->TableVar;
			$class = PROJECT_NAMESPACE . Config("EXPORT_CLASSES." . $this->CustomExport);
			if (class_exists($class)) {
				$doc = new $class($extrafieldstemplate);
				$doc->Text = @$content;
				if ($this->isExport("email"))
					echo $this->exportEmail($doc->Text);
				else
					$doc->export();
				DeleteTempImages(); // Delete temp images
				exit();
			}
		}
		if (!IsApi())
			$this->Page_Redirecting($url);

		// Close connection
		CloseConnections();

		// Return for API
		if (IsApi()) {
			$res = $url === TRUE;
			if (!$res) // Show error
				WriteJson(array_merge(["success" => FALSE], $this->getMessages()));
			return;
		}

		// Go to URL if specified
		if ($url != "") {
			if (!Config("DEBUG") && ob_get_length())
				ob_end_clean();

			// Handle modal response
			if ($this->IsModal) { // Show as modal
				$row = ["url" => $url, "modal" => "1"];
				$pageName = GetPageName($url);
				if ($pageName != $this->getListUrl()) { // Not List page
					$row["caption"] = $this->getModalCaption($pageName);
					if ($pageName == "extrafieldstemplateview.php")
						$row["view"] = "1";
				} else { // List page should not be shown as modal => error
					$row["error"] = $this->getFailureMessage();
					$this->clearFailureMessage();
				}
				WriteJson($row);
			} else {
				SaveDebugMessage();
				AddHeader("Location", $url);
			}
		}
		exit();
	}

	// Get records from recordset
	protected function getRecordsFromRecordset($rs, $current = FALSE)
	{
		$rows = [];
		if (is_object($rs)) { // Recordset
			while ($rs && !$rs->EOF) {
				$this->loadRowValues($rs); // Set up DbValue/CurrentValue
				$row = $this->getRecordFromArray($rs->fields);
				if ($current)
					return $row;
				else
					$rows[] = $row;
				$rs->moveNext();
			}
		} elseif (is_array($rs)) {
			foreach ($rs as $ar) {
				$row = $this->getRecordFromArray($ar);
				if ($current)
					return $row;
				else
					$rows[] = $row;
			}
		}
		return $rows;
	}

	// Get record from array
	protected function getRecordFromArray($ar)
	{
		$row = [];
		if (is_array($ar)) {
			foreach ($ar as $fldname => $val) {
				if (array_key_exists($fldname, $this->fields) && ($this->fields[$fldname]->Visible || $this->fields[$fldname]->IsPrimaryKey)) { // Primary key or Visible
					$fld = &$this->fields[$fldname];
					if ($fld->HtmlTag == "FILE") { // Upload field
						if (EmptyValue($val)) {
							$row[$fldname] = NULL;
						} else {
							if ($fld->DataType == DATATYPE_BLOB) {
								$url = FullUrl(GetApiUrl(Config("API_FILE_ACTION"),
									Config("API_OBJECT_NAME") . "=" . $fld->TableVar . "&" .
									Config("API_FIELD_NAME") . "=" . $fld->Param . "&" .
									Config("API_KEY_NAME") . "=" . rawurlencode($this->getRecordKeyValue($ar)))); //*** need to add this? API may not be in the same folder
								$row[$fldname] = ["type" => ContentType($val), "url" => $url, "name" => $fld->Param . ContentExtension($val)];
							} elseif (!$fld->UploadMultiple || !ContainsString($val, Config("MULTIPLE_UPLOAD_SEPARATOR"))) { // Single file
								$url = FullUrl(GetApiUrl(Config("API_FILE_ACTION"),
									Config("API_OBJECT_NAME") . "=" . $fld->TableVar . "&" .
									"fn=" . Encrypt($fld->physicalUploadPath() . $val)));
								$row[$fldname] = ["type" => MimeContentType($val), "url" => $url, "name" => $val];
							} else { // Multiple files
								$files = explode(Config("MULTIPLE_UPLOAD_SEPARATOR"), $val);
								$ar = [];
								foreach ($files as $file) {
									$url = FullUrl(GetApiUrl(Config("API_FILE_ACTION"),
										Config("API_OBJECT_NAME") . "=" . $fld->TableVar . "&" .
										"fn=" . Encrypt($fld->physicalUploadPath() . $file)));
									if (!EmptyValue($file))
										$ar[] = ["type" => MimeContentType($file), "url" => $url, "name" => $file];
								}
								$row[$fldname] = $ar;
							}
						}
					} else {
						$row[$fldname] = $val;
					}
				}
			}
		}
		return $row;
	}

	// Get record key value from array
	protected function getRecordKeyValue($ar)
	{
		$key = "";
		if (is_array($ar)) {
			$key .= @$ar['extrafieldsid'];
		}
		return $key;
	}

	/**
	 * Hide fields for add/edit
	 *
	 * @return void
	 */
	protected function hideFieldsForAddEdit()
	{
		if ($this->isAdd() || $this->isCopy() || $this->isGridAdd())
			$this->extrafieldsid->Visible = FALSE;
	}

	// Lookup data
	public function lookup()
	{
		global $Language, $Security;
		if (!isset($Language))
			$Language = new Language(Config("LANGUAGE_FOLDER"), Post("language", ""));

		// Set up API request
		if (!ValidApiRequest())
			return FALSE;
		$this->setupApiSecurity();

		// Get lookup object
		$fieldName = Post("field");
		if (!array_key_exists($fieldName, $this->fields))
			return FALSE;
		$lookupField = $this->fields[$fieldName];
		$lookup = $lookupField->Lookup;
		if ($lookup === NULL)
			return FALSE;
		$tbl = $lookup->getTable();
		if (!$Security->allowLookup(Config("PROJECT_ID") . $tbl->TableName)) // Lookup permission
			return FALSE;

		// Get lookup parameters
		$lookupType = Post("ajax", "unknown");
		$pageSize = -1;
		$offset = -1;
		$searchValue = "";
		if (SameText($lookupType, "modal")) {
			$searchValue = Post("sv", "");
			$pageSize = Post("recperpage", 10);
			$offset = Post("start", 0);
		} elseif (SameText($lookupType, "autosuggest")) {
			$searchValue = Param("q", "");
			$pageSize = Param("n", -1);
			$pageSize = is_numeric($pageSize) ? (int)$pageSize : -1;
			if ($pageSize <= 0)
				$pageSize = Config("AUTO_SUGGEST_MAX_ENTRIES");
			$start = Param("start", -1);
			$start = is_numeric($start) ? (int)$start : -1;
			$page = Param("page", -1);
			$page = is_numeric($page) ? (int)$page : -1;
			$offset = $start >= 0 ? $start : ($page > 0 && $pageSize > 0 ? ($page - 1) * $pageSize : 0);
		}
		$userSelect = Decrypt(Post("s", ""));
		$userFilter = Decrypt(Post("f", ""));
		$userOrderBy = Decrypt(Post("o", ""));
		$keys = Post("keys");
		$lookup->LookupType = $lookupType; // Lookup type
		if ($keys !== NULL) { // Selected records from modal
			if (is_array($keys))
				$keys = implode(Config("MULTIPLE_OPTION_SEPARATOR"), $keys);
			$lookup->FilterFields = []; // Skip parent fields if any
			$lookup->FilterValues[] = $keys; // Lookup values
			$pageSize = -1; // Show all records
		} else { // Lookup values
			$lookup->FilterValues[] = Post("v0", Post("lookupValue", ""));
		}
		$cnt = is_array($lookup->FilterFields) ? count($lookup->FilterFields) : 0;
		for ($i = 1; $i <= $cnt; $i++)
			$lookup->FilterValues[] = Post("v" . $i, "");
		$lookup->SearchValue = $searchValue;
		$lookup->PageSize = $pageSize;
		$lookup->Offset = $offset;
		if ($userSelect != "")
			$lookup->UserSelect = $userSelect;
		if ($userFilter != "")
			$lookup->UserFilter = $userFilter;
		if ($userOrderBy != "")
			$lookup->UserOrderBy = $userOrderBy;
		$lookup->toJson($this); // Use settings from current page
	}

	// Set up API security
	public function setupApiSecurity()
	{
		global $Security;

		// Setup security for API request
		if ($Security->isLoggedIn()) $Security->TablePermission_Loading();
		$Security->loadCurrentUserLevel(Config("PROJECT_ID") . $this->TableName);
		if ($Security->isLoggedIn()) $Security->TablePermission_Loaded();
	}
	public $FormClassName = "ew-horizontal ew-form ew-add-form";
	public $IsModal = FALSE;
	public $IsMobileOrModal = FALSE;
	public $DbMasterFilter = "";
	public $DbDetailFilter = "";
	public $StartRecord;
	public $Priv = 0;
	public $OldRecordset;
	public $CopyRecord;

	//
	// Page run
	//

	public function run()
	{
		global $ExportType, $CustomExportType, $ExportFileName, $UserProfile, $Language, $Security, $CurrentForm,
			$FormError, $SkipHeaderFooter;

		// Is modal
		$this->IsModal = (Param("modal") == "1");

		// User profile
		$UserProfile = new UserProfile();

		// Security
		if (ValidApiRequest()) { // API request
			$this->setupApiSecurity(); // Set up API Security
			if (!$Security->canAdd()) {
				SetStatus(401); // Unauthorized
				return;
			}
		} else {
			$Security = new AdvancedSecurity();
			if (IsPasswordExpired())
				$this->terminate(GetUrl("changepwd.php"));
			if (!$Security->isLoggedIn())
				$Security->autoLogin();
			if ($Security->isLoggedIn())
				$Security->TablePermission_Loading();
			$Security->loadCurrentUserLevel($this->ProjectID . $this->TableName);
			if ($Security->isLoggedIn())
				$Security->TablePermission_Loaded();
			if (!$Security->canAdd()) {
				$Security->saveLastUrl();
				$this->setFailureMessage(DeniedMessage()); // Set no permission
				if ($Security->canList())
					$this->terminate(GetUrl("extrafieldstemplatelist.php"));
				else
					$this->terminate(GetUrl("login.php"));
				return;
			}
		}

		// Create form object
		$CurrentForm = new HttpForm();
		$this->CurrentAction = Param("action"); // Set up current action
		$this->extrafieldsid->Visible = FALSE;
		$this->merchantid->setVisibility();
		$this->name->setVisibility();
		$this->field1label->setVisibility();
		$this->field1type->setVisibility();
		$this->field1mandatory->setVisibility();
		$this->field1display->setVisibility();
		$this->field1displaysequence->setVisibility();
		$this->field1domain->setVisibility();
		$this->field2label->setVisibility();
		$this->field2type->setVisibility();
		$this->field2mandatory->setVisibility();
		$this->field2display->setVisibility();
		$this->field2displaysequence->setVisibility();
		$this->field2domain->setVisibility();
		$this->field3label->setVisibility();
		$this->field3type->setVisibility();
		$this->field3mandatory->setVisibility();
		$this->field3display->setVisibility();
		$this->field3displaysequence->setVisibility();
		$this->field3domain->setVisibility();
		$this->field4label->setVisibility();
		$this->field4type->setVisibility();
		$this->field4mandatory->setVisibility();
		$this->field4display->setVisibility();
		$this->field4displaysequence->setVisibility();
		$this->field4domain->setVisibility();
		$this->field5label->setVisibility();
		$this->field5type->setVisibility();
		$this->field5mandatory->setVisibility();
		$this->field5display->setVisibility();
		$this->field5displaysequence->setVisibility();
		$this->field5domain->setVisibility();
		$this->field6label->setVisibility();
		$this->field6type->setVisibility();
		$this->field6mandatory->setVisibility();
		$this->field6display->setVisibility();
		$this->field6displaysequence->setVisibility();
		$this->field6domain->setVisibility();
		$this->field7label->setVisibility();
		$this->field7type->setVisibility();
		$this->field7mandatory->setVisibility();
		$this->field7display->setVisibility();
		$this->field7displaysequence->setVisibility();
		$this->field7domain->setVisibility();
		$this->field8label->setVisibility();
		$this->field8type->setVisibility();
		$this->field8mandatory->setVisibility();
		$this->field8display->setVisibility();
		$this->field8displaysequence->setVisibility();
		$this->field8domain->setVisibility();
		$this->field9label->setVisibility();
		$this->field9type->setVisibility();
		$this->field9mandatory->setVisibility();
		$this->field9display->setVisibility();
		$this->field9displaysequence->setVisibility();
		$this->field9domain->setVisibility();
		$this->field10label->setVisibility();
		$this->field10type->setVisibility();
		$this->field10mandatory->setVisibility();
		$this->field10display->setVisibility();
		$this->field10displaysequence->setVisibility();
		$this->field10domain->setVisibility();
		$this->lastupdatedate->setVisibility();
		$this->hideFieldsForAddEdit();

		// Do not use lookup cache
		$this->setUseLookupCache(FALSE);

		// Global Page Loading event (in userfn*.php)
		Page_Loading();

		// Page Load event
		$this->Page_Load();

		// Check token
		if (!$this->validPost()) {
			Write($Language->phrase("InvalidPostRequest"));
			$this->terminate();
		}

		// Create Token
		$this->createToken();

		// Set up lookup cache
		// Check permission

		if (!$Security->canAdd()) {
			$this->setFailureMessage(DeniedMessage()); // No permission
			$this->terminate("extrafieldstemplatelist.php");
			return;
		}

		// Check modal
		if ($this->IsModal)
			$SkipHeaderFooter = TRUE;
		$this->IsMobileOrModal = IsMobile() || $this->IsModal;
		$this->FormClassName = "ew-form ew-add-form ew-horizontal";
		$postBack = FALSE;

		// Set up current action
		if (IsApi()) {
			$this->CurrentAction = "insert"; // Add record directly
			$postBack = TRUE;
		} elseif (Post("action") !== NULL) {
			$this->CurrentAction = Post("action"); // Get form action
			$postBack = TRUE;
		} else { // Not post back

			// Load key values from QueryString
			$this->CopyRecord = TRUE;
			if (Get("extrafieldsid") !== NULL) {
				$this->extrafieldsid->setQueryStringValue(Get("extrafieldsid"));
				$this->setKey("extrafieldsid", $this->extrafieldsid->CurrentValue); // Set up key
			} else {
				$this->setKey("extrafieldsid", ""); // Clear key
				$this->CopyRecord = FALSE;
			}
			if ($this->CopyRecord) {
				$this->CurrentAction = "copy"; // Copy record
			} else {
				$this->CurrentAction = "show"; // Display blank record
			}
		}

		// Load old record / default values
		$loaded = $this->loadOldRecord();

		// Load form values
		if ($postBack) {
			$this->loadFormValues(); // Load form values
		}

		// Validate form if post back
		if ($postBack) {
			if (!$this->validateForm()) {
				$this->EventCancelled = TRUE; // Event cancelled
				$this->restoreFormValues(); // Restore form values
				$this->setFailureMessage($FormError);
				if (IsApi()) {
					$this->terminate();
					return;
				} else {
					$this->CurrentAction = "show"; // Form error, reset action
				}
			}
		}

		// Perform current action
		switch ($this->CurrentAction) {
			case "copy": // Copy an existing record
				if (!$loaded) { // Record not loaded
					if ($this->getFailureMessage() == "")
						$this->setFailureMessage($Language->phrase("NoRecord")); // No record found
					$this->terminate("extrafieldstemplatelist.php"); // No matching record, return to list
				}
				break;
			case "insert": // Add new record
				$this->SendEmail = TRUE; // Send email on add success
				if ($this->addRow($this->OldRecordset)) { // Add successful
					if ($this->getSuccessMessage() == "")
						$this->setSuccessMessage($Language->phrase("AddSuccess")); // Set up success message
					$returnUrl = $this->getReturnUrl();
					if (GetPageName($returnUrl) == "extrafieldstemplatelist.php")
						$returnUrl = $this->addMasterUrl($returnUrl); // List page, return to List page with correct master key if necessary
					elseif (GetPageName($returnUrl) == "extrafieldstemplateview.php")
						$returnUrl = $this->getViewUrl(); // View page, return to View page with keyurl directly
					if (IsApi()) { // Return to caller
						$this->terminate(TRUE);
						return;
					} else {
						$this->terminate($returnUrl);
					}
				} elseif (IsApi()) { // API request, return
					$this->terminate();
					return;
				} else {
					$this->EventCancelled = TRUE; // Event cancelled
					$this->restoreFormValues(); // Add failed, restore form values
				}
		}

		// Set up Breadcrumb
		$this->setupBreadcrumb();

		// Render row based on row type
		$this->RowType = ROWTYPE_ADD; // Render add type

		// Render row
		$this->resetAttributes();
		$this->renderRow();
	}

	// Get upload files
	protected function getUploadFiles()
	{
		global $CurrentForm, $Language;
	}

	// Load default values
	protected function loadDefaultValues()
	{
		$this->extrafieldsid->CurrentValue = NULL;
		$this->extrafieldsid->OldValue = $this->extrafieldsid->CurrentValue;
		$this->merchantid->CurrentValue = NULL;
		$this->merchantid->OldValue = $this->merchantid->CurrentValue;
		$this->name->CurrentValue = NULL;
		$this->name->OldValue = $this->name->CurrentValue;
		$this->field1label->CurrentValue = NULL;
		$this->field1label->OldValue = $this->field1label->CurrentValue;
		$this->field1type->CurrentValue = NULL;
		$this->field1type->OldValue = $this->field1type->CurrentValue;
		$this->field1mandatory->CurrentValue = NULL;
		$this->field1mandatory->OldValue = $this->field1mandatory->CurrentValue;
		$this->field1display->CurrentValue = NULL;
		$this->field1display->OldValue = $this->field1display->CurrentValue;
		$this->field1displaysequence->CurrentValue = NULL;
		$this->field1displaysequence->OldValue = $this->field1displaysequence->CurrentValue;
		$this->field1domain->CurrentValue = NULL;
		$this->field1domain->OldValue = $this->field1domain->CurrentValue;
		$this->field2label->CurrentValue = NULL;
		$this->field2label->OldValue = $this->field2label->CurrentValue;
		$this->field2type->CurrentValue = NULL;
		$this->field2type->OldValue = $this->field2type->CurrentValue;
		$this->field2mandatory->CurrentValue = NULL;
		$this->field2mandatory->OldValue = $this->field2mandatory->CurrentValue;
		$this->field2display->CurrentValue = NULL;
		$this->field2display->OldValue = $this->field2display->CurrentValue;
		$this->field2displaysequence->CurrentValue = NULL;
		$this->field2displaysequence->OldValue = $this->field2displaysequence->CurrentValue;
		$this->field2domain->CurrentValue = NULL;
		$this->field2domain->OldValue = $this->field2domain->CurrentValue;
		$this->field3label->CurrentValue = NULL;
		$this->field3label->OldValue = $this->field3label->CurrentValue;
		$this->field3type->CurrentValue = NULL;
		$this->field3type->OldValue = $this->field3type->CurrentValue;
		$this->field3mandatory->CurrentValue = NULL;
		$this->field3mandatory->OldValue = $this->field3mandatory->CurrentValue;
		$this->field3display->CurrentValue = NULL;
		$this->field3display->OldValue = $this->field3display->CurrentValue;
		$this->field3displaysequence->CurrentValue = NULL;
		$this->field3displaysequence->OldValue = $this->field3displaysequence->CurrentValue;
		$this->field3domain->CurrentValue = NULL;
		$this->field3domain->OldValue = $this->field3domain->CurrentValue;
		$this->field4label->CurrentValue = NULL;
		$this->field4label->OldValue = $this->field4label->CurrentValue;
		$this->field4type->CurrentValue = NULL;
		$this->field4type->OldValue = $this->field4type->CurrentValue;
		$this->field4mandatory->CurrentValue = NULL;
		$this->field4mandatory->OldValue = $this->field4mandatory->CurrentValue;
		$this->field4display->CurrentValue = NULL;
		$this->field4display->OldValue = $this->field4display->CurrentValue;
		$this->field4displaysequence->CurrentValue = NULL;
		$this->field4displaysequence->OldValue = $this->field4displaysequence->CurrentValue;
		$this->field4domain->CurrentValue = NULL;
		$this->field4domain->OldValue = $this->field4domain->CurrentValue;
		$this->field5label->CurrentValue = NULL;
		$this->field5label->OldValue = $this->field5label->CurrentValue;
		$this->field5type->CurrentValue = NULL;
		$this->field5type->OldValue = $this->field5type->CurrentValue;
		$this->field5mandatory->CurrentValue = NULL;
		$this->field5mandatory->OldValue = $this->field5mandatory->CurrentValue;
		$this->field5display->CurrentValue = NULL;
		$this->field5display->OldValue = $this->field5display->CurrentValue;
		$this->field5displaysequence->CurrentValue = NULL;
		$this->field5displaysequence->OldValue = $this->field5displaysequence->CurrentValue;
		$this->field5domain->CurrentValue = NULL;
		$this->field5domain->OldValue = $this->field5domain->CurrentValue;
		$this->field6label->CurrentValue = NULL;
		$this->field6label->OldValue = $this->field6label->CurrentValue;
		$this->field6type->CurrentValue = NULL;
		$this->field6type->OldValue = $this->field6type->CurrentValue;
		$this->field6mandatory->CurrentValue = NULL;
		$this->field6mandatory->OldValue = $this->field6mandatory->CurrentValue;
		$this->field6display->CurrentValue = NULL;
		$this->field6display->OldValue = $this->field6display->CurrentValue;
		$this->field6displaysequence->CurrentValue = NULL;
		$this->field6displaysequence->OldValue = $this->field6displaysequence->CurrentValue;
		$this->field6domain->CurrentValue = NULL;
		$this->field6domain->OldValue = $this->field6domain->CurrentValue;
		$this->field7label->CurrentValue = NULL;
		$this->field7label->OldValue = $this->field7label->CurrentValue;
		$this->field7type->CurrentValue = NULL;
		$this->field7type->OldValue = $this->field7type->CurrentValue;
		$this->field7mandatory->CurrentValue = NULL;
		$this->field7mandatory->OldValue = $this->field7mandatory->CurrentValue;
		$this->field7display->CurrentValue = NULL;
		$this->field7display->OldValue = $this->field7display->CurrentValue;
		$this->field7displaysequence->CurrentValue = NULL;
		$this->field7displaysequence->OldValue = $this->field7displaysequence->CurrentValue;
		$this->field7domain->CurrentValue = NULL;
		$this->field7domain->OldValue = $this->field7domain->CurrentValue;
		$this->field8label->CurrentValue = NULL;
		$this->field8label->OldValue = $this->field8label->CurrentValue;
		$this->field8type->CurrentValue = NULL;
		$this->field8type->OldValue = $this->field8type->CurrentValue;
		$this->field8mandatory->CurrentValue = NULL;
		$this->field8mandatory->OldValue = $this->field8mandatory->CurrentValue;
		$this->field8display->CurrentValue = NULL;
		$this->field8display->OldValue = $this->field8display->CurrentValue;
		$this->field8displaysequence->CurrentValue = NULL;
		$this->field8displaysequence->OldValue = $this->field8displaysequence->CurrentValue;
		$this->field8domain->CurrentValue = NULL;
		$this->field8domain->OldValue = $this->field8domain->CurrentValue;
		$this->field9label->CurrentValue = NULL;
		$this->field9label->OldValue = $this->field9label->CurrentValue;
		$this->field9type->CurrentValue = NULL;
		$this->field9type->OldValue = $this->field9type->CurrentValue;
		$this->field9mandatory->CurrentValue = NULL;
		$this->field9mandatory->OldValue = $this->field9mandatory->CurrentValue;
		$this->field9display->CurrentValue = NULL;
		$this->field9display->OldValue = $this->field9display->CurrentValue;
		$this->field9displaysequence->CurrentValue = NULL;
		$this->field9displaysequence->OldValue = $this->field9displaysequence->CurrentValue;
		$this->field9domain->CurrentValue = NULL;
		$this->field9domain->OldValue = $this->field9domain->CurrentValue;
		$this->field10label->CurrentValue = NULL;
		$this->field10label->OldValue = $this->field10label->CurrentValue;
		$this->field10type->CurrentValue = NULL;
		$this->field10type->OldValue = $this->field10type->CurrentValue;
		$this->field10mandatory->CurrentValue = NULL;
		$this->field10mandatory->OldValue = $this->field10mandatory->CurrentValue;
		$this->field10display->CurrentValue = NULL;
		$this->field10display->OldValue = $this->field10display->CurrentValue;
		$this->field10displaysequence->CurrentValue = NULL;
		$this->field10displaysequence->OldValue = $this->field10displaysequence->CurrentValue;
		$this->field10domain->CurrentValue = NULL;
		$this->field10domain->OldValue = $this->field10domain->CurrentValue;
		$this->lastupdatedate->CurrentValue = NULL;
		$this->lastupdatedate->OldValue = $this->lastupdatedate->CurrentValue;
	}

	// Load form values
	protected function loadFormValues()
	{

		// Load from form
		global $CurrentForm;

		// Check field name 'merchantid' first before field var 'x_merchantid'
		$val = $CurrentForm->hasValue("merchantid") ? $CurrentForm->getValue("merchantid") : $CurrentForm->getValue("x_merchantid");
		if (!$this->merchantid->IsDetailKey) {
			if (IsApi() && $val === NULL)
				$this->merchantid->Visible = FALSE; // Disable update for API request
			else
				$this->merchantid->setFormValue($val);
		}

		// Check field name 'name' first before field var 'x_name'
		$val = $CurrentForm->hasValue("name") ? $CurrentForm->getValue("name") : $CurrentForm->getValue("x_name");
		if (!$this->name->IsDetailKey) {
			if (IsApi() && $val === NULL)
				$this->name->Visible = FALSE; // Disable update for API request
			else
				$this->name->setFormValue($val);
		}

		// Check field name 'field1label' first before field var 'x_field1label'
		$val = $CurrentForm->hasValue("field1label") ? $CurrentForm->getValue("field1label") : $CurrentForm->getValue("x_field1label");
		if (!$this->field1label->IsDetailKey) {
			if (IsApi() && $val === NULL)
				$this->field1label->Visible = FALSE; // Disable update for API request
			else
				$this->field1label->setFormValue($val);
		}

		// Check field name 'field1type' first before field var 'x_field1type'
		$val = $CurrentForm->hasValue("field1type") ? $CurrentForm->getValue("field1type") : $CurrentForm->getValue("x_field1type");
		if (!$this->field1type->IsDetailKey) {
			if (IsApi() && $val === NULL)
				$this->field1type->Visible = FALSE; // Disable update for API request
			else
				$this->field1type->setFormValue($val);
		}

		// Check field name 'field1mandatory' first before field var 'x_field1mandatory'
		$val = $CurrentForm->hasValue("field1mandatory") ? $CurrentForm->getValue("field1mandatory") : $CurrentForm->getValue("x_field1mandatory");
		if (!$this->field1mandatory->IsDetailKey) {
			if (IsApi() && $val === NULL)
				$this->field1mandatory->Visible = FALSE; // Disable update for API request
			else
				$this->field1mandatory->setFormValue($val);
		}

		// Check field name 'field1display' first before field var 'x_field1display'
		$val = $CurrentForm->hasValue("field1display") ? $CurrentForm->getValue("field1display") : $CurrentForm->getValue("x_field1display");
		if (!$this->field1display->IsDetailKey) {
			if (IsApi() && $val === NULL)
				$this->field1display->Visible = FALSE; // Disable update for API request
			else
				$this->field1display->setFormValue($val);
		}

		// Check field name 'field1displaysequence' first before field var 'x_field1displaysequence'
		$val = $CurrentForm->hasValue("field1displaysequence") ? $CurrentForm->getValue("field1displaysequence") : $CurrentForm->getValue("x_field1displaysequence");
		if (!$this->field1displaysequence->IsDetailKey) {
			if (IsApi() && $val === NULL)
				$this->field1displaysequence->Visible = FALSE; // Disable update for API request
			else
				$this->field1displaysequence->setFormValue($val);
		}

		// Check field name 'field1domain' first before field var 'x_field1domain'
		$val = $CurrentForm->hasValue("field1domain") ? $CurrentForm->getValue("field1domain") : $CurrentForm->getValue("x_field1domain");
		if (!$this->field1domain->IsDetailKey) {
			if (IsApi() && $val === NULL)
				$this->field1domain->Visible = FALSE; // Disable update for API request
			else
				$this->field1domain->setFormValue($val);
		}

		// Check field name 'field2label' first before field var 'x_field2label'
		$val = $CurrentForm->hasValue("field2label") ? $CurrentForm->getValue("field2label") : $CurrentForm->getValue("x_field2label");
		if (!$this->field2label->IsDetailKey) {
			if (IsApi() && $val === NULL)
				$this->field2label->Visible = FALSE; // Disable update for API request
			else
				$this->field2label->setFormValue($val);
		}

		// Check field name 'field2type' first before field var 'x_field2type'
		$val = $CurrentForm->hasValue("field2type") ? $CurrentForm->getValue("field2type") : $CurrentForm->getValue("x_field2type");
		if (!$this->field2type->IsDetailKey) {
			if (IsApi() && $val === NULL)
				$this->field2type->Visible = FALSE; // Disable update for API request
			else
				$this->field2type->setFormValue($val);
		}

		// Check field name 'field2mandatory' first before field var 'x_field2mandatory'
		$val = $CurrentForm->hasValue("field2mandatory") ? $CurrentForm->getValue("field2mandatory") : $CurrentForm->getValue("x_field2mandatory");
		if (!$this->field2mandatory->IsDetailKey) {
			if (IsApi() && $val === NULL)
				$this->field2mandatory->Visible = FALSE; // Disable update for API request
			else
				$this->field2mandatory->setFormValue($val);
		}

		// Check field name 'field2display' first before field var 'x_field2display'
		$val = $CurrentForm->hasValue("field2display") ? $CurrentForm->getValue("field2display") : $CurrentForm->getValue("x_field2display");
		if (!$this->field2display->IsDetailKey) {
			if (IsApi() && $val === NULL)
				$this->field2display->Visible = FALSE; // Disable update for API request
			else
				$this->field2display->setFormValue($val);
		}

		// Check field name 'field2displaysequence' first before field var 'x_field2displaysequence'
		$val = $CurrentForm->hasValue("field2displaysequence") ? $CurrentForm->getValue("field2displaysequence") : $CurrentForm->getValue("x_field2displaysequence");
		if (!$this->field2displaysequence->IsDetailKey) {
			if (IsApi() && $val === NULL)
				$this->field2displaysequence->Visible = FALSE; // Disable update for API request
			else
				$this->field2displaysequence->setFormValue($val);
		}

		// Check field name 'field2domain' first before field var 'x_field2domain'
		$val = $CurrentForm->hasValue("field2domain") ? $CurrentForm->getValue("field2domain") : $CurrentForm->getValue("x_field2domain");
		if (!$this->field2domain->IsDetailKey) {
			if (IsApi() && $val === NULL)
				$this->field2domain->Visible = FALSE; // Disable update for API request
			else
				$this->field2domain->setFormValue($val);
		}

		// Check field name 'field3label' first before field var 'x_field3label'
		$val = $CurrentForm->hasValue("field3label") ? $CurrentForm->getValue("field3label") : $CurrentForm->getValue("x_field3label");
		if (!$this->field3label->IsDetailKey) {
			if (IsApi() && $val === NULL)
				$this->field3label->Visible = FALSE; // Disable update for API request
			else
				$this->field3label->setFormValue($val);
		}

		// Check field name 'field3type' first before field var 'x_field3type'
		$val = $CurrentForm->hasValue("field3type") ? $CurrentForm->getValue("field3type") : $CurrentForm->getValue("x_field3type");
		if (!$this->field3type->IsDetailKey) {
			if (IsApi() && $val === NULL)
				$this->field3type->Visible = FALSE; // Disable update for API request
			else
				$this->field3type->setFormValue($val);
		}

		// Check field name 'field3mandatory' first before field var 'x_field3mandatory'
		$val = $CurrentForm->hasValue("field3mandatory") ? $CurrentForm->getValue("field3mandatory") : $CurrentForm->getValue("x_field3mandatory");
		if (!$this->field3mandatory->IsDetailKey) {
			if (IsApi() && $val === NULL)
				$this->field3mandatory->Visible = FALSE; // Disable update for API request
			else
				$this->field3mandatory->setFormValue($val);
		}

		// Check field name 'field3display' first before field var 'x_field3display'
		$val = $CurrentForm->hasValue("field3display") ? $CurrentForm->getValue("field3display") : $CurrentForm->getValue("x_field3display");
		if (!$this->field3display->IsDetailKey) {
			if (IsApi() && $val === NULL)
				$this->field3display->Visible = FALSE; // Disable update for API request
			else
				$this->field3display->setFormValue($val);
		}

		// Check field name 'field3displaysequence' first before field var 'x_field3displaysequence'
		$val = $CurrentForm->hasValue("field3displaysequence") ? $CurrentForm->getValue("field3displaysequence") : $CurrentForm->getValue("x_field3displaysequence");
		if (!$this->field3displaysequence->IsDetailKey) {
			if (IsApi() && $val === NULL)
				$this->field3displaysequence->Visible = FALSE; // Disable update for API request
			else
				$this->field3displaysequence->setFormValue($val);
		}

		// Check field name 'field3domain' first before field var 'x_field3domain'
		$val = $CurrentForm->hasValue("field3domain") ? $CurrentForm->getValue("field3domain") : $CurrentForm->getValue("x_field3domain");
		if (!$this->field3domain->IsDetailKey) {
			if (IsApi() && $val === NULL)
				$this->field3domain->Visible = FALSE; // Disable update for API request
			else
				$this->field3domain->setFormValue($val);
		}

		// Check field name 'field4label' first before field var 'x_field4label'
		$val = $CurrentForm->hasValue("field4label") ? $CurrentForm->getValue("field4label") : $CurrentForm->getValue("x_field4label");
		if (!$this->field4label->IsDetailKey) {
			if (IsApi() && $val === NULL)
				$this->field4label->Visible = FALSE; // Disable update for API request
			else
				$this->field4label->setFormValue($val);
		}

		// Check field name 'field4type' first before field var 'x_field4type'
		$val = $CurrentForm->hasValue("field4type") ? $CurrentForm->getValue("field4type") : $CurrentForm->getValue("x_field4type");
		if (!$this->field4type->IsDetailKey) {
			if (IsApi() && $val === NULL)
				$this->field4type->Visible = FALSE; // Disable update for API request
			else
				$this->field4type->setFormValue($val);
		}

		// Check field name 'field4mandatory' first before field var 'x_field4mandatory'
		$val = $CurrentForm->hasValue("field4mandatory") ? $CurrentForm->getValue("field4mandatory") : $CurrentForm->getValue("x_field4mandatory");
		if (!$this->field4mandatory->IsDetailKey) {
			if (IsApi() && $val === NULL)
				$this->field4mandatory->Visible = FALSE; // Disable update for API request
			else
				$this->field4mandatory->setFormValue($val);
		}

		// Check field name 'field4display' first before field var 'x_field4display'
		$val = $CurrentForm->hasValue("field4display") ? $CurrentForm->getValue("field4display") : $CurrentForm->getValue("x_field4display");
		if (!$this->field4display->IsDetailKey) {
			if (IsApi() && $val === NULL)
				$this->field4display->Visible = FALSE; // Disable update for API request
			else
				$this->field4display->setFormValue($val);
		}

		// Check field name 'field4displaysequence' first before field var 'x_field4displaysequence'
		$val = $CurrentForm->hasValue("field4displaysequence") ? $CurrentForm->getValue("field4displaysequence") : $CurrentForm->getValue("x_field4displaysequence");
		if (!$this->field4displaysequence->IsDetailKey) {
			if (IsApi() && $val === NULL)
				$this->field4displaysequence->Visible = FALSE; // Disable update for API request
			else
				$this->field4displaysequence->setFormValue($val);
		}

		// Check field name 'field4domain' first before field var 'x_field4domain'
		$val = $CurrentForm->hasValue("field4domain") ? $CurrentForm->getValue("field4domain") : $CurrentForm->getValue("x_field4domain");
		if (!$this->field4domain->IsDetailKey) {
			if (IsApi() && $val === NULL)
				$this->field4domain->Visible = FALSE; // Disable update for API request
			else
				$this->field4domain->setFormValue($val);
		}

		// Check field name 'field5label' first before field var 'x_field5label'
		$val = $CurrentForm->hasValue("field5label") ? $CurrentForm->getValue("field5label") : $CurrentForm->getValue("x_field5label");
		if (!$this->field5label->IsDetailKey) {
			if (IsApi() && $val === NULL)
				$this->field5label->Visible = FALSE; // Disable update for API request
			else
				$this->field5label->setFormValue($val);
		}

		// Check field name 'field5type' first before field var 'x_field5type'
		$val = $CurrentForm->hasValue("field5type") ? $CurrentForm->getValue("field5type") : $CurrentForm->getValue("x_field5type");
		if (!$this->field5type->IsDetailKey) {
			if (IsApi() && $val === NULL)
				$this->field5type->Visible = FALSE; // Disable update for API request
			else
				$this->field5type->setFormValue($val);
		}

		// Check field name 'field5mandatory' first before field var 'x_field5mandatory'
		$val = $CurrentForm->hasValue("field5mandatory") ? $CurrentForm->getValue("field5mandatory") : $CurrentForm->getValue("x_field5mandatory");
		if (!$this->field5mandatory->IsDetailKey) {
			if (IsApi() && $val === NULL)
				$this->field5mandatory->Visible = FALSE; // Disable update for API request
			else
				$this->field5mandatory->setFormValue($val);
		}

		// Check field name 'field5display' first before field var 'x_field5display'
		$val = $CurrentForm->hasValue("field5display") ? $CurrentForm->getValue("field5display") : $CurrentForm->getValue("x_field5display");
		if (!$this->field5display->IsDetailKey) {
			if (IsApi() && $val === NULL)
				$this->field5display->Visible = FALSE; // Disable update for API request
			else
				$this->field5display->setFormValue($val);
		}

		// Check field name 'field5displaysequence' first before field var 'x_field5displaysequence'
		$val = $CurrentForm->hasValue("field5displaysequence") ? $CurrentForm->getValue("field5displaysequence") : $CurrentForm->getValue("x_field5displaysequence");
		if (!$this->field5displaysequence->IsDetailKey) {
			if (IsApi() && $val === NULL)
				$this->field5displaysequence->Visible = FALSE; // Disable update for API request
			else
				$this->field5displaysequence->setFormValue($val);
		}

		// Check field name 'field5domain' first before field var 'x_field5domain'
		$val = $CurrentForm->hasValue("field5domain") ? $CurrentForm->getValue("field5domain") : $CurrentForm->getValue("x_field5domain");
		if (!$this->field5domain->IsDetailKey) {
			if (IsApi() && $val === NULL)
				$this->field5domain->Visible = FALSE; // Disable update for API request
			else
				$this->field5domain->setFormValue($val);
		}

		// Check field name 'field6label' first before field var 'x_field6label'
		$val = $CurrentForm->hasValue("field6label") ? $CurrentForm->getValue("field6label") : $CurrentForm->getValue("x_field6label");
		if (!$this->field6label->IsDetailKey) {
			if (IsApi() && $val === NULL)
				$this->field6label->Visible = FALSE; // Disable update for API request
			else
				$this->field6label->setFormValue($val);
		}

		// Check field name 'field6type' first before field var 'x_field6type'
		$val = $CurrentForm->hasValue("field6type") ? $CurrentForm->getValue("field6type") : $CurrentForm->getValue("x_field6type");
		if (!$this->field6type->IsDetailKey) {
			if (IsApi() && $val === NULL)
				$this->field6type->Visible = FALSE; // Disable update for API request
			else
				$this->field6type->setFormValue($val);
		}

		// Check field name 'field6mandatory' first before field var 'x_field6mandatory'
		$val = $CurrentForm->hasValue("field6mandatory") ? $CurrentForm->getValue("field6mandatory") : $CurrentForm->getValue("x_field6mandatory");
		if (!$this->field6mandatory->IsDetailKey) {
			if (IsApi() && $val === NULL)
				$this->field6mandatory->Visible = FALSE; // Disable update for API request
			else
				$this->field6mandatory->setFormValue($val);
		}

		// Check field name 'field6display' first before field var 'x_field6display'
		$val = $CurrentForm->hasValue("field6display") ? $CurrentForm->getValue("field6display") : $CurrentForm->getValue("x_field6display");
		if (!$this->field6display->IsDetailKey) {
			if (IsApi() && $val === NULL)
				$this->field6display->Visible = FALSE; // Disable update for API request
			else
				$this->field6display->setFormValue($val);
		}

		// Check field name 'field6displaysequence' first before field var 'x_field6displaysequence'
		$val = $CurrentForm->hasValue("field6displaysequence") ? $CurrentForm->getValue("field6displaysequence") : $CurrentForm->getValue("x_field6displaysequence");
		if (!$this->field6displaysequence->IsDetailKey) {
			if (IsApi() && $val === NULL)
				$this->field6displaysequence->Visible = FALSE; // Disable update for API request
			else
				$this->field6displaysequence->setFormValue($val);
		}

		// Check field name 'field6domain' first before field var 'x_field6domain'
		$val = $CurrentForm->hasValue("field6domain") ? $CurrentForm->getValue("field6domain") : $CurrentForm->getValue("x_field6domain");
		if (!$this->field6domain->IsDetailKey) {
			if (IsApi() && $val === NULL)
				$this->field6domain->Visible = FALSE; // Disable update for API request
			else
				$this->field6domain->setFormValue($val);
		}

		// Check field name 'field7label' first before field var 'x_field7label'
		$val = $CurrentForm->hasValue("field7label") ? $CurrentForm->getValue("field7label") : $CurrentForm->getValue("x_field7label");
		if (!$this->field7label->IsDetailKey) {
			if (IsApi() && $val === NULL)
				$this->field7label->Visible = FALSE; // Disable update for API request
			else
				$this->field7label->setFormValue($val);
		}

		// Check field name 'field7type' first before field var 'x_field7type'
		$val = $CurrentForm->hasValue("field7type") ? $CurrentForm->getValue("field7type") : $CurrentForm->getValue("x_field7type");
		if (!$this->field7type->IsDetailKey) {
			if (IsApi() && $val === NULL)
				$this->field7type->Visible = FALSE; // Disable update for API request
			else
				$this->field7type->setFormValue($val);
		}

		// Check field name 'field7mandatory' first before field var 'x_field7mandatory'
		$val = $CurrentForm->hasValue("field7mandatory") ? $CurrentForm->getValue("field7mandatory") : $CurrentForm->getValue("x_field7mandatory");
		if (!$this->field7mandatory->IsDetailKey) {
			if (IsApi() && $val === NULL)
				$this->field7mandatory->Visible = FALSE; // Disable update for API request
			else
				$this->field7mandatory->setFormValue($val);
		}

		// Check field name 'field7display' first before field var 'x_field7display'
		$val = $CurrentForm->hasValue("field7display") ? $CurrentForm->getValue("field7display") : $CurrentForm->getValue("x_field7display");
		if (!$this->field7display->IsDetailKey) {
			if (IsApi() && $val === NULL)
				$this->field7display->Visible = FALSE; // Disable update for API request
			else
				$this->field7display->setFormValue($val);
		}

		// Check field name 'field7displaysequence' first before field var 'x_field7displaysequence'
		$val = $CurrentForm->hasValue("field7displaysequence") ? $CurrentForm->getValue("field7displaysequence") : $CurrentForm->getValue("x_field7displaysequence");
		if (!$this->field7displaysequence->IsDetailKey) {
			if (IsApi() && $val === NULL)
				$this->field7displaysequence->Visible = FALSE; // Disable update for API request
			else
				$this->field7displaysequence->setFormValue($val);
		}

		// Check field name 'field7domain' first before field var 'x_field7domain'
		$val = $CurrentForm->hasValue("field7domain") ? $CurrentForm->getValue("field7domain") : $CurrentForm->getValue("x_field7domain");
		if (!$this->field7domain->IsDetailKey) {
			if (IsApi() && $val === NULL)
				$this->field7domain->Visible = FALSE; // Disable update for API request
			else
				$this->field7domain->setFormValue($val);
		}

		// Check field name 'field8label' first before field var 'x_field8label'
		$val = $CurrentForm->hasValue("field8label") ? $CurrentForm->getValue("field8label") : $CurrentForm->getValue("x_field8label");
		if (!$this->field8label->IsDetailKey) {
			if (IsApi() && $val === NULL)
				$this->field8label->Visible = FALSE; // Disable update for API request
			else
				$this->field8label->setFormValue($val);
		}

		// Check field name 'field8type' first before field var 'x_field8type'
		$val = $CurrentForm->hasValue("field8type") ? $CurrentForm->getValue("field8type") : $CurrentForm->getValue("x_field8type");
		if (!$this->field8type->IsDetailKey) {
			if (IsApi() && $val === NULL)
				$this->field8type->Visible = FALSE; // Disable update for API request
			else
				$this->field8type->setFormValue($val);
		}

		// Check field name 'field8mandatory' first before field var 'x_field8mandatory'
		$val = $CurrentForm->hasValue("field8mandatory") ? $CurrentForm->getValue("field8mandatory") : $CurrentForm->getValue("x_field8mandatory");
		if (!$this->field8mandatory->IsDetailKey) {
			if (IsApi() && $val === NULL)
				$this->field8mandatory->Visible = FALSE; // Disable update for API request
			else
				$this->field8mandatory->setFormValue($val);
		}

		// Check field name 'field8display' first before field var 'x_field8display'
		$val = $CurrentForm->hasValue("field8display") ? $CurrentForm->getValue("field8display") : $CurrentForm->getValue("x_field8display");
		if (!$this->field8display->IsDetailKey) {
			if (IsApi() && $val === NULL)
				$this->field8display->Visible = FALSE; // Disable update for API request
			else
				$this->field8display->setFormValue($val);
		}

		// Check field name 'field8displaysequence' first before field var 'x_field8displaysequence'
		$val = $CurrentForm->hasValue("field8displaysequence") ? $CurrentForm->getValue("field8displaysequence") : $CurrentForm->getValue("x_field8displaysequence");
		if (!$this->field8displaysequence->IsDetailKey) {
			if (IsApi() && $val === NULL)
				$this->field8displaysequence->Visible = FALSE; // Disable update for API request
			else
				$this->field8displaysequence->setFormValue($val);
		}

		// Check field name 'field8domain' first before field var 'x_field8domain'
		$val = $CurrentForm->hasValue("field8domain") ? $CurrentForm->getValue("field8domain") : $CurrentForm->getValue("x_field8domain");
		if (!$this->field8domain->IsDetailKey) {
			if (IsApi() && $val === NULL)
				$this->field8domain->Visible = FALSE; // Disable update for API request
			else
				$this->field8domain->setFormValue($val);
		}

		// Check field name 'field9label' first before field var 'x_field9label'
		$val = $CurrentForm->hasValue("field9label") ? $CurrentForm->getValue("field9label") : $CurrentForm->getValue("x_field9label");
		if (!$this->field9label->IsDetailKey) {
			if (IsApi() && $val === NULL)
				$this->field9label->Visible = FALSE; // Disable update for API request
			else
				$this->field9label->setFormValue($val);
		}

		// Check field name 'field9type' first before field var 'x_field9type'
		$val = $CurrentForm->hasValue("field9type") ? $CurrentForm->getValue("field9type") : $CurrentForm->getValue("x_field9type");
		if (!$this->field9type->IsDetailKey) {
			if (IsApi() && $val === NULL)
				$this->field9type->Visible = FALSE; // Disable update for API request
			else
				$this->field9type->setFormValue($val);
		}

		// Check field name 'field9mandatory' first before field var 'x_field9mandatory'
		$val = $CurrentForm->hasValue("field9mandatory") ? $CurrentForm->getValue("field9mandatory") : $CurrentForm->getValue("x_field9mandatory");
		if (!$this->field9mandatory->IsDetailKey) {
			if (IsApi() && $val === NULL)
				$this->field9mandatory->Visible = FALSE; // Disable update for API request
			else
				$this->field9mandatory->setFormValue($val);
		}

		// Check field name 'field9display' first before field var 'x_field9display'
		$val = $CurrentForm->hasValue("field9display") ? $CurrentForm->getValue("field9display") : $CurrentForm->getValue("x_field9display");
		if (!$this->field9display->IsDetailKey) {
			if (IsApi() && $val === NULL)
				$this->field9display->Visible = FALSE; // Disable update for API request
			else
				$this->field9display->setFormValue($val);
		}

		// Check field name 'field9displaysequence' first before field var 'x_field9displaysequence'
		$val = $CurrentForm->hasValue("field9displaysequence") ? $CurrentForm->getValue("field9displaysequence") : $CurrentForm->getValue("x_field9displaysequence");
		if (!$this->field9displaysequence->IsDetailKey) {
			if (IsApi() && $val === NULL)
				$this->field9displaysequence->Visible = FALSE; // Disable update for API request
			else
				$this->field9displaysequence->setFormValue($val);
		}

		// Check field name 'field9domain' first before field var 'x_field9domain'
		$val = $CurrentForm->hasValue("field9domain") ? $CurrentForm->getValue("field9domain") : $CurrentForm->getValue("x_field9domain");
		if (!$this->field9domain->IsDetailKey) {
			if (IsApi() && $val === NULL)
				$this->field9domain->Visible = FALSE; // Disable update for API request
			else
				$this->field9domain->setFormValue($val);
		}

		// Check field name 'field10label' first before field var 'x_field10label'
		$val = $CurrentForm->hasValue("field10label") ? $CurrentForm->getValue("field10label") : $CurrentForm->getValue("x_field10label");
		if (!$this->field10label->IsDetailKey) {
			if (IsApi() && $val === NULL)
				$this->field10label->Visible = FALSE; // Disable update for API request
			else
				$this->field10label->setFormValue($val);
		}

		// Check field name 'field10type' first before field var 'x_field10type'
		$val = $CurrentForm->hasValue("field10type") ? $CurrentForm->getValue("field10type") : $CurrentForm->getValue("x_field10type");
		if (!$this->field10type->IsDetailKey) {
			if (IsApi() && $val === NULL)
				$this->field10type->Visible = FALSE; // Disable update for API request
			else
				$this->field10type->setFormValue($val);
		}

		// Check field name 'field10mandatory' first before field var 'x_field10mandatory'
		$val = $CurrentForm->hasValue("field10mandatory") ? $CurrentForm->getValue("field10mandatory") : $CurrentForm->getValue("x_field10mandatory");
		if (!$this->field10mandatory->IsDetailKey) {
			if (IsApi() && $val === NULL)
				$this->field10mandatory->Visible = FALSE; // Disable update for API request
			else
				$this->field10mandatory->setFormValue($val);
		}

		// Check field name 'field10display' first before field var 'x_field10display'
		$val = $CurrentForm->hasValue("field10display") ? $CurrentForm->getValue("field10display") : $CurrentForm->getValue("x_field10display");
		if (!$this->field10display->IsDetailKey) {
			if (IsApi() && $val === NULL)
				$this->field10display->Visible = FALSE; // Disable update for API request
			else
				$this->field10display->setFormValue($val);
		}

		// Check field name 'field10displaysequence' first before field var 'x_field10displaysequence'
		$val = $CurrentForm->hasValue("field10displaysequence") ? $CurrentForm->getValue("field10displaysequence") : $CurrentForm->getValue("x_field10displaysequence");
		if (!$this->field10displaysequence->IsDetailKey) {
			if (IsApi() && $val === NULL)
				$this->field10displaysequence->Visible = FALSE; // Disable update for API request
			else
				$this->field10displaysequence->setFormValue($val);
		}

		// Check field name 'field10domain' first before field var 'x_field10domain'
		$val = $CurrentForm->hasValue("field10domain") ? $CurrentForm->getValue("field10domain") : $CurrentForm->getValue("x_field10domain");
		if (!$this->field10domain->IsDetailKey) {
			if (IsApi() && $val === NULL)
				$this->field10domain->Visible = FALSE; // Disable update for API request
			else
				$this->field10domain->setFormValue($val);
		}

		// Check field name 'lastupdatedate' first before field var 'x_lastupdatedate'
		$val = $CurrentForm->hasValue("lastupdatedate") ? $CurrentForm->getValue("lastupdatedate") : $CurrentForm->getValue("x_lastupdatedate");
		if (!$this->lastupdatedate->IsDetailKey) {
			if (IsApi() && $val === NULL)
				$this->lastupdatedate->Visible = FALSE; // Disable update for API request
			else
				$this->lastupdatedate->setFormValue($val);
			$this->lastupdatedate->CurrentValue = UnFormatDateTime($this->lastupdatedate->CurrentValue, 0);
		}

		// Check field name 'extrafieldsid' first before field var 'x_extrafieldsid'
		$val = $CurrentForm->hasValue("extrafieldsid") ? $CurrentForm->getValue("extrafieldsid") : $CurrentForm->getValue("x_extrafieldsid");
	}

	// Restore form values
	public function restoreFormValues()
	{
		global $CurrentForm;
		$this->merchantid->CurrentValue = $this->merchantid->FormValue;
		$this->name->CurrentValue = $this->name->FormValue;
		$this->field1label->CurrentValue = $this->field1label->FormValue;
		$this->field1type->CurrentValue = $this->field1type->FormValue;
		$this->field1mandatory->CurrentValue = $this->field1mandatory->FormValue;
		$this->field1display->CurrentValue = $this->field1display->FormValue;
		$this->field1displaysequence->CurrentValue = $this->field1displaysequence->FormValue;
		$this->field1domain->CurrentValue = $this->field1domain->FormValue;
		$this->field2label->CurrentValue = $this->field2label->FormValue;
		$this->field2type->CurrentValue = $this->field2type->FormValue;
		$this->field2mandatory->CurrentValue = $this->field2mandatory->FormValue;
		$this->field2display->CurrentValue = $this->field2display->FormValue;
		$this->field2displaysequence->CurrentValue = $this->field2displaysequence->FormValue;
		$this->field2domain->CurrentValue = $this->field2domain->FormValue;
		$this->field3label->CurrentValue = $this->field3label->FormValue;
		$this->field3type->CurrentValue = $this->field3type->FormValue;
		$this->field3mandatory->CurrentValue = $this->field3mandatory->FormValue;
		$this->field3display->CurrentValue = $this->field3display->FormValue;
		$this->field3displaysequence->CurrentValue = $this->field3displaysequence->FormValue;
		$this->field3domain->CurrentValue = $this->field3domain->FormValue;
		$this->field4label->CurrentValue = $this->field4label->FormValue;
		$this->field4type->CurrentValue = $this->field4type->FormValue;
		$this->field4mandatory->CurrentValue = $this->field4mandatory->FormValue;
		$this->field4display->CurrentValue = $this->field4display->FormValue;
		$this->field4displaysequence->CurrentValue = $this->field4displaysequence->FormValue;
		$this->field4domain->CurrentValue = $this->field4domain->FormValue;
		$this->field5label->CurrentValue = $this->field5label->FormValue;
		$this->field5type->CurrentValue = $this->field5type->FormValue;
		$this->field5mandatory->CurrentValue = $this->field5mandatory->FormValue;
		$this->field5display->CurrentValue = $this->field5display->FormValue;
		$this->field5displaysequence->CurrentValue = $this->field5displaysequence->FormValue;
		$this->field5domain->CurrentValue = $this->field5domain->FormValue;
		$this->field6label->CurrentValue = $this->field6label->FormValue;
		$this->field6type->CurrentValue = $this->field6type->FormValue;
		$this->field6mandatory->CurrentValue = $this->field6mandatory->FormValue;
		$this->field6display->CurrentValue = $this->field6display->FormValue;
		$this->field6displaysequence->CurrentValue = $this->field6displaysequence->FormValue;
		$this->field6domain->CurrentValue = $this->field6domain->FormValue;
		$this->field7label->CurrentValue = $this->field7label->FormValue;
		$this->field7type->CurrentValue = $this->field7type->FormValue;
		$this->field7mandatory->CurrentValue = $this->field7mandatory->FormValue;
		$this->field7display->CurrentValue = $this->field7display->FormValue;
		$this->field7displaysequence->CurrentValue = $this->field7displaysequence->FormValue;
		$this->field7domain->CurrentValue = $this->field7domain->FormValue;
		$this->field8label->CurrentValue = $this->field8label->FormValue;
		$this->field8type->CurrentValue = $this->field8type->FormValue;
		$this->field8mandatory->CurrentValue = $this->field8mandatory->FormValue;
		$this->field8display->CurrentValue = $this->field8display->FormValue;
		$this->field8displaysequence->CurrentValue = $this->field8displaysequence->FormValue;
		$this->field8domain->CurrentValue = $this->field8domain->FormValue;
		$this->field9label->CurrentValue = $this->field9label->FormValue;
		$this->field9type->CurrentValue = $this->field9type->FormValue;
		$this->field9mandatory->CurrentValue = $this->field9mandatory->FormValue;
		$this->field9display->CurrentValue = $this->field9display->FormValue;
		$this->field9displaysequence->CurrentValue = $this->field9displaysequence->FormValue;
		$this->field9domain->CurrentValue = $this->field9domain->FormValue;
		$this->field10label->CurrentValue = $this->field10label->FormValue;
		$this->field10type->CurrentValue = $this->field10type->FormValue;
		$this->field10mandatory->CurrentValue = $this->field10mandatory->FormValue;
		$this->field10display->CurrentValue = $this->field10display->FormValue;
		$this->field10displaysequence->CurrentValue = $this->field10displaysequence->FormValue;
		$this->field10domain->CurrentValue = $this->field10domain->FormValue;
		$this->lastupdatedate->CurrentValue = $this->lastupdatedate->FormValue;
		$this->lastupdatedate->CurrentValue = UnFormatDateTime($this->lastupdatedate->CurrentValue, 0);
	}

	// Load row based on key values
	public function loadRow()
	{
		global $Security, $Language;
		$filter = $this->getRecordFilter();

		// Call Row Selecting event
		$this->Row_Selecting($filter);

		// Load SQL based on filter
		$this->CurrentFilter = $filter;
		$sql = $this->getCurrentSql();
		$conn = $this->getConnection();
		$res = FALSE;
		$rs = LoadRecordset($sql, $conn);
		if ($rs && !$rs->EOF) {
			$res = TRUE;
			$this->loadRowValues($rs); // Load row values
			$rs->close();
		}
		return $res;
	}

	// Load row values from recordset
	public function loadRowValues($rs = NULL)
	{
		if ($rs && !$rs->EOF)
			$row = $rs->fields;
		else
			$row = $this->newRow();

		// Call Row Selected event
		$this->Row_Selected($row);
		if (!$rs || $rs->EOF)
			return;
		$this->extrafieldsid->setDbValue($row['extrafieldsid']);
		$this->merchantid->setDbValue($row['merchantid']);
		$this->name->setDbValue($row['name']);
		$this->field1label->setDbValue($row['field1label']);
		$this->field1type->setDbValue($row['field1type']);
		$this->field1mandatory->setDbValue($row['field1mandatory']);
		$this->field1display->setDbValue($row['field1display']);
		$this->field1displaysequence->setDbValue($row['field1displaysequence']);
		$this->field1domain->setDbValue($row['field1domain']);
		$this->field2label->setDbValue($row['field2label']);
		$this->field2type->setDbValue($row['field2type']);
		$this->field2mandatory->setDbValue($row['field2mandatory']);
		$this->field2display->setDbValue($row['field2display']);
		$this->field2displaysequence->setDbValue($row['field2displaysequence']);
		$this->field2domain->setDbValue($row['field2domain']);
		$this->field3label->setDbValue($row['field3label']);
		$this->field3type->setDbValue($row['field3type']);
		$this->field3mandatory->setDbValue($row['field3mandatory']);
		$this->field3display->setDbValue($row['field3display']);
		$this->field3displaysequence->setDbValue($row['field3displaysequence']);
		$this->field3domain->setDbValue($row['field3domain']);
		$this->field4label->setDbValue($row['field4label']);
		$this->field4type->setDbValue($row['field4type']);
		$this->field4mandatory->setDbValue($row['field4mandatory']);
		$this->field4display->setDbValue($row['field4display']);
		$this->field4displaysequence->setDbValue($row['field4displaysequence']);
		$this->field4domain->setDbValue($row['field4domain']);
		$this->field5label->setDbValue($row['field5label']);
		$this->field5type->setDbValue($row['field5type']);
		$this->field5mandatory->setDbValue($row['field5mandatory']);
		$this->field5display->setDbValue($row['field5display']);
		$this->field5displaysequence->setDbValue($row['field5displaysequence']);
		$this->field5domain->setDbValue($row['field5domain']);
		$this->field6label->setDbValue($row['field6label']);
		$this->field6type->setDbValue($row['field6type']);
		$this->field6mandatory->setDbValue($row['field6mandatory']);
		$this->field6display->setDbValue($row['field6display']);
		$this->field6displaysequence->setDbValue($row['field6displaysequence']);
		$this->field6domain->setDbValue($row['field6domain']);
		$this->field7label->setDbValue($row['field7label']);
		$this->field7type->setDbValue($row['field7type']);
		$this->field7mandatory->setDbValue($row['field7mandatory']);
		$this->field7display->setDbValue($row['field7display']);
		$this->field7displaysequence->setDbValue($row['field7displaysequence']);
		$this->field7domain->setDbValue($row['field7domain']);
		$this->field8label->setDbValue($row['field8label']);
		$this->field8type->setDbValue($row['field8type']);
		$this->field8mandatory->setDbValue($row['field8mandatory']);
		$this->field8display->setDbValue($row['field8display']);
		$this->field8displaysequence->setDbValue($row['field8displaysequence']);
		$this->field8domain->setDbValue($row['field8domain']);
		$this->field9label->setDbValue($row['field9label']);
		$this->field9type->setDbValue($row['field9type']);
		$this->field9mandatory->setDbValue($row['field9mandatory']);
		$this->field9display->setDbValue($row['field9display']);
		$this->field9displaysequence->setDbValue($row['field9displaysequence']);
		$this->field9domain->setDbValue($row['field9domain']);
		$this->field10label->setDbValue($row['field10label']);
		$this->field10type->setDbValue($row['field10type']);
		$this->field10mandatory->setDbValue($row['field10mandatory']);
		$this->field10display->setDbValue($row['field10display']);
		$this->field10displaysequence->setDbValue($row['field10displaysequence']);
		$this->field10domain->setDbValue($row['field10domain']);
		$this->lastupdatedate->setDbValue($row['lastupdatedate']);
	}

	// Return a row with default values
	protected function newRow()
	{
		$this->loadDefaultValues();
		$row = [];
		$row['extrafieldsid'] = $this->extrafieldsid->CurrentValue;
		$row['merchantid'] = $this->merchantid->CurrentValue;
		$row['name'] = $this->name->CurrentValue;
		$row['field1label'] = $this->field1label->CurrentValue;
		$row['field1type'] = $this->field1type->CurrentValue;
		$row['field1mandatory'] = $this->field1mandatory->CurrentValue;
		$row['field1display'] = $this->field1display->CurrentValue;
		$row['field1displaysequence'] = $this->field1displaysequence->CurrentValue;
		$row['field1domain'] = $this->field1domain->CurrentValue;
		$row['field2label'] = $this->field2label->CurrentValue;
		$row['field2type'] = $this->field2type->CurrentValue;
		$row['field2mandatory'] = $this->field2mandatory->CurrentValue;
		$row['field2display'] = $this->field2display->CurrentValue;
		$row['field2displaysequence'] = $this->field2displaysequence->CurrentValue;
		$row['field2domain'] = $this->field2domain->CurrentValue;
		$row['field3label'] = $this->field3label->CurrentValue;
		$row['field3type'] = $this->field3type->CurrentValue;
		$row['field3mandatory'] = $this->field3mandatory->CurrentValue;
		$row['field3display'] = $this->field3display->CurrentValue;
		$row['field3displaysequence'] = $this->field3displaysequence->CurrentValue;
		$row['field3domain'] = $this->field3domain->CurrentValue;
		$row['field4label'] = $this->field4label->CurrentValue;
		$row['field4type'] = $this->field4type->CurrentValue;
		$row['field4mandatory'] = $this->field4mandatory->CurrentValue;
		$row['field4display'] = $this->field4display->CurrentValue;
		$row['field4displaysequence'] = $this->field4displaysequence->CurrentValue;
		$row['field4domain'] = $this->field4domain->CurrentValue;
		$row['field5label'] = $this->field5label->CurrentValue;
		$row['field5type'] = $this->field5type->CurrentValue;
		$row['field5mandatory'] = $this->field5mandatory->CurrentValue;
		$row['field5display'] = $this->field5display->CurrentValue;
		$row['field5displaysequence'] = $this->field5displaysequence->CurrentValue;
		$row['field5domain'] = $this->field5domain->CurrentValue;
		$row['field6label'] = $this->field6label->CurrentValue;
		$row['field6type'] = $this->field6type->CurrentValue;
		$row['field6mandatory'] = $this->field6mandatory->CurrentValue;
		$row['field6display'] = $this->field6display->CurrentValue;
		$row['field6displaysequence'] = $this->field6displaysequence->CurrentValue;
		$row['field6domain'] = $this->field6domain->CurrentValue;
		$row['field7label'] = $this->field7label->CurrentValue;
		$row['field7type'] = $this->field7type->CurrentValue;
		$row['field7mandatory'] = $this->field7mandatory->CurrentValue;
		$row['field7display'] = $this->field7display->CurrentValue;
		$row['field7displaysequence'] = $this->field7displaysequence->CurrentValue;
		$row['field7domain'] = $this->field7domain->CurrentValue;
		$row['field8label'] = $this->field8label->CurrentValue;
		$row['field8type'] = $this->field8type->CurrentValue;
		$row['field8mandatory'] = $this->field8mandatory->CurrentValue;
		$row['field8display'] = $this->field8display->CurrentValue;
		$row['field8displaysequence'] = $this->field8displaysequence->CurrentValue;
		$row['field8domain'] = $this->field8domain->CurrentValue;
		$row['field9label'] = $this->field9label->CurrentValue;
		$row['field9type'] = $this->field9type->CurrentValue;
		$row['field9mandatory'] = $this->field9mandatory->CurrentValue;
		$row['field9display'] = $this->field9display->CurrentValue;
		$row['field9displaysequence'] = $this->field9displaysequence->CurrentValue;
		$row['field9domain'] = $this->field9domain->CurrentValue;
		$row['field10label'] = $this->field10label->CurrentValue;
		$row['field10type'] = $this->field10type->CurrentValue;
		$row['field10mandatory'] = $this->field10mandatory->CurrentValue;
		$row['field10display'] = $this->field10display->CurrentValue;
		$row['field10displaysequence'] = $this->field10displaysequence->CurrentValue;
		$row['field10domain'] = $this->field10domain->CurrentValue;
		$row['lastupdatedate'] = $this->lastupdatedate->CurrentValue;
		return $row;
	}

	// Load old record
	protected function loadOldRecord()
	{

		// Load key values from Session
		$validKey = TRUE;
		if (strval($this->getKey("extrafieldsid")) != "")
			$this->extrafieldsid->OldValue = $this->getKey("extrafieldsid"); // extrafieldsid
		else
			$validKey = FALSE;

		// Load old record
		$this->OldRecordset = NULL;
		if ($validKey) {
			$this->CurrentFilter = $this->getRecordFilter();
			$sql = $this->getCurrentSql();
			$conn = $this->getConnection();
			$this->OldRecordset = LoadRecordset($sql, $conn);
		}
		$this->loadRowValues($this->OldRecordset); // Load row values
		return $validKey;
	}

	// Render row values based on field settings
	public function renderRow()
	{
		global $Security, $Language, $CurrentLanguage;

		// Initialize URLs
		// Call Row_Rendering event

		$this->Row_Rendering();

		// Common render codes for all row types
		// extrafieldsid
		// merchantid
		// name
		// field1label
		// field1type
		// field1mandatory
		// field1display
		// field1displaysequence
		// field1domain
		// field2label
		// field2type
		// field2mandatory
		// field2display
		// field2displaysequence
		// field2domain
		// field3label
		// field3type
		// field3mandatory
		// field3display
		// field3displaysequence
		// field3domain
		// field4label
		// field4type
		// field4mandatory
		// field4display
		// field4displaysequence
		// field4domain
		// field5label
		// field5type
		// field5mandatory
		// field5display
		// field5displaysequence
		// field5domain
		// field6label
		// field6type
		// field6mandatory
		// field6display
		// field6displaysequence
		// field6domain
		// field7label
		// field7type
		// field7mandatory
		// field7display
		// field7displaysequence
		// field7domain
		// field8label
		// field8type
		// field8mandatory
		// field8display
		// field8displaysequence
		// field8domain
		// field9label
		// field9type
		// field9mandatory
		// field9display
		// field9displaysequence
		// field9domain
		// field10label
		// field10type
		// field10mandatory
		// field10display
		// field10displaysequence
		// field10domain
		// lastupdatedate

		if ($this->RowType == ROWTYPE_VIEW) { // View row

			// extrafieldsid
			$this->extrafieldsid->ViewValue = $this->extrafieldsid->CurrentValue;
			$this->extrafieldsid->ViewCustomAttributes = "";

			// merchantid
			$this->merchantid->ViewValue = $this->merchantid->CurrentValue;
			$this->merchantid->ViewCustomAttributes = "";

			// name
			$this->name->ViewValue = $this->name->CurrentValue;
			$this->name->ViewCustomAttributes = "";

			// field1label
			$this->field1label->ViewValue = $this->field1label->CurrentValue;
			$this->field1label->ViewCustomAttributes = "";

			// field1type
			$this->field1type->ViewValue = $this->field1type->CurrentValue;
			$this->field1type->ViewCustomAttributes = "";

			// field1mandatory
			$this->field1mandatory->ViewValue = $this->field1mandatory->CurrentValue;
			$this->field1mandatory->ViewCustomAttributes = "";

			// field1display
			$this->field1display->ViewValue = $this->field1display->CurrentValue;
			$this->field1display->ViewCustomAttributes = "";

			// field1displaysequence
			$this->field1displaysequence->ViewValue = $this->field1displaysequence->CurrentValue;
			$this->field1displaysequence->ViewCustomAttributes = "";

			// field1domain
			$this->field1domain->ViewValue = $this->field1domain->CurrentValue;
			$this->field1domain->ViewCustomAttributes = "";

			// field2label
			$this->field2label->ViewValue = $this->field2label->CurrentValue;
			$this->field2label->ViewCustomAttributes = "";

			// field2type
			$this->field2type->ViewValue = $this->field2type->CurrentValue;
			$this->field2type->ViewCustomAttributes = "";

			// field2mandatory
			$this->field2mandatory->ViewValue = $this->field2mandatory->CurrentValue;
			$this->field2mandatory->ViewCustomAttributes = "";

			// field2display
			$this->field2display->ViewValue = $this->field2display->CurrentValue;
			$this->field2display->ViewCustomAttributes = "";

			// field2displaysequence
			$this->field2displaysequence->ViewValue = $this->field2displaysequence->CurrentValue;
			$this->field2displaysequence->ViewCustomAttributes = "";

			// field2domain
			$this->field2domain->ViewValue = $this->field2domain->CurrentValue;
			$this->field2domain->ViewCustomAttributes = "";

			// field3label
			$this->field3label->ViewValue = $this->field3label->CurrentValue;
			$this->field3label->ViewCustomAttributes = "";

			// field3type
			$this->field3type->ViewValue = $this->field3type->CurrentValue;
			$this->field3type->ViewCustomAttributes = "";

			// field3mandatory
			$this->field3mandatory->ViewValue = $this->field3mandatory->CurrentValue;
			$this->field3mandatory->ViewCustomAttributes = "";

			// field3display
			$this->field3display->ViewValue = $this->field3display->CurrentValue;
			$this->field3display->ViewCustomAttributes = "";

			// field3displaysequence
			$this->field3displaysequence->ViewValue = $this->field3displaysequence->CurrentValue;
			$this->field3displaysequence->ViewCustomAttributes = "";

			// field3domain
			$this->field3domain->ViewValue = $this->field3domain->CurrentValue;
			$this->field3domain->ViewCustomAttributes = "";

			// field4label
			$this->field4label->ViewValue = $this->field4label->CurrentValue;
			$this->field4label->ViewCustomAttributes = "";

			// field4type
			$this->field4type->ViewValue = $this->field4type->CurrentValue;
			$this->field4type->ViewCustomAttributes = "";

			// field4mandatory
			$this->field4mandatory->ViewValue = $this->field4mandatory->CurrentValue;
			$this->field4mandatory->ViewCustomAttributes = "";

			// field4display
			$this->field4display->ViewValue = $this->field4display->CurrentValue;
			$this->field4display->ViewCustomAttributes = "";

			// field4displaysequence
			$this->field4displaysequence->ViewValue = $this->field4displaysequence->CurrentValue;
			$this->field4displaysequence->ViewCustomAttributes = "";

			// field4domain
			$this->field4domain->ViewValue = $this->field4domain->CurrentValue;
			$this->field4domain->ViewCustomAttributes = "";

			// field5label
			$this->field5label->ViewValue = $this->field5label->CurrentValue;
			$this->field5label->ViewCustomAttributes = "";

			// field5type
			$this->field5type->ViewValue = $this->field5type->CurrentValue;
			$this->field5type->ViewCustomAttributes = "";

			// field5mandatory
			$this->field5mandatory->ViewValue = $this->field5mandatory->CurrentValue;
			$this->field5mandatory->ViewCustomAttributes = "";

			// field5display
			$this->field5display->ViewValue = $this->field5display->CurrentValue;
			$this->field5display->ViewCustomAttributes = "";

			// field5displaysequence
			$this->field5displaysequence->ViewValue = $this->field5displaysequence->CurrentValue;
			$this->field5displaysequence->ViewCustomAttributes = "";

			// field5domain
			$this->field5domain->ViewValue = $this->field5domain->CurrentValue;
			$this->field5domain->ViewCustomAttributes = "";

			// field6label
			$this->field6label->ViewValue = $this->field6label->CurrentValue;
			$this->field6label->ViewCustomAttributes = "";

			// field6type
			$this->field6type->ViewValue = $this->field6type->CurrentValue;
			$this->field6type->ViewCustomAttributes = "";

			// field6mandatory
			$this->field6mandatory->ViewValue = $this->field6mandatory->CurrentValue;
			$this->field6mandatory->ViewCustomAttributes = "";

			// field6display
			$this->field6display->ViewValue = $this->field6display->CurrentValue;
			$this->field6display->ViewCustomAttributes = "";

			// field6displaysequence
			$this->field6displaysequence->ViewValue = $this->field6displaysequence->CurrentValue;
			$this->field6displaysequence->ViewCustomAttributes = "";

			// field6domain
			$this->field6domain->ViewValue = $this->field6domain->CurrentValue;
			$this->field6domain->ViewCustomAttributes = "";

			// field7label
			$this->field7label->ViewValue = $this->field7label->CurrentValue;
			$this->field7label->ViewCustomAttributes = "";

			// field7type
			$this->field7type->ViewValue = $this->field7type->CurrentValue;
			$this->field7type->ViewCustomAttributes = "";

			// field7mandatory
			$this->field7mandatory->ViewValue = $this->field7mandatory->CurrentValue;
			$this->field7mandatory->ViewCustomAttributes = "";

			// field7display
			$this->field7display->ViewValue = $this->field7display->CurrentValue;
			$this->field7display->ViewCustomAttributes = "";

			// field7displaysequence
			$this->field7displaysequence->ViewValue = $this->field7displaysequence->CurrentValue;
			$this->field7displaysequence->ViewCustomAttributes = "";

			// field7domain
			$this->field7domain->ViewValue = $this->field7domain->CurrentValue;
			$this->field7domain->ViewCustomAttributes = "";

			// field8label
			$this->field8label->ViewValue = $this->field8label->CurrentValue;
			$this->field8label->ViewCustomAttributes = "";

			// field8type
			$this->field8type->ViewValue = $this->field8type->CurrentValue;
			$this->field8type->ViewCustomAttributes = "";

			// field8mandatory
			$this->field8mandatory->ViewValue = $this->field8mandatory->CurrentValue;
			$this->field8mandatory->ViewCustomAttributes = "";

			// field8display
			$this->field8display->ViewValue = $this->field8display->CurrentValue;
			$this->field8display->ViewCustomAttributes = "";

			// field8displaysequence
			$this->field8displaysequence->ViewValue = $this->field8displaysequence->CurrentValue;
			$this->field8displaysequence->ViewCustomAttributes = "";

			// field8domain
			$this->field8domain->ViewValue = $this->field8domain->CurrentValue;
			$this->field8domain->ViewCustomAttributes = "";

			// field9label
			$this->field9label->ViewValue = $this->field9label->CurrentValue;
			$this->field9label->ViewCustomAttributes = "";

			// field9type
			$this->field9type->ViewValue = $this->field9type->CurrentValue;
			$this->field9type->ViewCustomAttributes = "";

			// field9mandatory
			$this->field9mandatory->ViewValue = $this->field9mandatory->CurrentValue;
			$this->field9mandatory->ViewCustomAttributes = "";

			// field9display
			$this->field9display->ViewValue = $this->field9display->CurrentValue;
			$this->field9display->ViewCustomAttributes = "";

			// field9displaysequence
			$this->field9displaysequence->ViewValue = $this->field9displaysequence->CurrentValue;
			$this->field9displaysequence->ViewCustomAttributes = "";

			// field9domain
			$this->field9domain->ViewValue = $this->field9domain->CurrentValue;
			$this->field9domain->ViewCustomAttributes = "";

			// field10label
			$this->field10label->ViewValue = $this->field10label->CurrentValue;
			$this->field10label->ViewCustomAttributes = "";

			// field10type
			$this->field10type->ViewValue = $this->field10type->CurrentValue;
			$this->field10type->ViewCustomAttributes = "";

			// field10mandatory
			$this->field10mandatory->ViewValue = $this->field10mandatory->CurrentValue;
			$this->field10mandatory->ViewCustomAttributes = "";

			// field10display
			$this->field10display->ViewValue = $this->field10display->CurrentValue;
			$this->field10display->ViewCustomAttributes = "";

			// field10displaysequence
			$this->field10displaysequence->ViewValue = $this->field10displaysequence->CurrentValue;
			$this->field10displaysequence->ViewCustomAttributes = "";

			// field10domain
			$this->field10domain->ViewValue = $this->field10domain->CurrentValue;
			$this->field10domain->ViewCustomAttributes = "";

			// lastupdatedate
			$this->lastupdatedate->ViewValue = $this->lastupdatedate->CurrentValue;
			$this->lastupdatedate->ViewValue = FormatDateTime($this->lastupdatedate->ViewValue, 0);
			$this->lastupdatedate->ViewCustomAttributes = "";

			// merchantid
			$this->merchantid->LinkCustomAttributes = "";
			$this->merchantid->HrefValue = "";
			$this->merchantid->TooltipValue = "";

			// name
			$this->name->LinkCustomAttributes = "";
			$this->name->HrefValue = "";
			$this->name->TooltipValue = "";

			// field1label
			$this->field1label->LinkCustomAttributes = "";
			$this->field1label->HrefValue = "";
			$this->field1label->TooltipValue = "";

			// field1type
			$this->field1type->LinkCustomAttributes = "";
			$this->field1type->HrefValue = "";
			$this->field1type->TooltipValue = "";

			// field1mandatory
			$this->field1mandatory->LinkCustomAttributes = "";
			$this->field1mandatory->HrefValue = "";
			$this->field1mandatory->TooltipValue = "";

			// field1display
			$this->field1display->LinkCustomAttributes = "";
			$this->field1display->HrefValue = "";
			$this->field1display->TooltipValue = "";

			// field1displaysequence
			$this->field1displaysequence->LinkCustomAttributes = "";
			$this->field1displaysequence->HrefValue = "";
			$this->field1displaysequence->TooltipValue = "";

			// field1domain
			$this->field1domain->LinkCustomAttributes = "";
			$this->field1domain->HrefValue = "";
			$this->field1domain->TooltipValue = "";

			// field2label
			$this->field2label->LinkCustomAttributes = "";
			$this->field2label->HrefValue = "";
			$this->field2label->TooltipValue = "";

			// field2type
			$this->field2type->LinkCustomAttributes = "";
			$this->field2type->HrefValue = "";
			$this->field2type->TooltipValue = "";

			// field2mandatory
			$this->field2mandatory->LinkCustomAttributes = "";
			$this->field2mandatory->HrefValue = "";
			$this->field2mandatory->TooltipValue = "";

			// field2display
			$this->field2display->LinkCustomAttributes = "";
			$this->field2display->HrefValue = "";
			$this->field2display->TooltipValue = "";

			// field2displaysequence
			$this->field2displaysequence->LinkCustomAttributes = "";
			$this->field2displaysequence->HrefValue = "";
			$this->field2displaysequence->TooltipValue = "";

			// field2domain
			$this->field2domain->LinkCustomAttributes = "";
			$this->field2domain->HrefValue = "";
			$this->field2domain->TooltipValue = "";

			// field3label
			$this->field3label->LinkCustomAttributes = "";
			$this->field3label->HrefValue = "";
			$this->field3label->TooltipValue = "";

			// field3type
			$this->field3type->LinkCustomAttributes = "";
			$this->field3type->HrefValue = "";
			$this->field3type->TooltipValue = "";

			// field3mandatory
			$this->field3mandatory->LinkCustomAttributes = "";
			$this->field3mandatory->HrefValue = "";
			$this->field3mandatory->TooltipValue = "";

			// field3display
			$this->field3display->LinkCustomAttributes = "";
			$this->field3display->HrefValue = "";
			$this->field3display->TooltipValue = "";

			// field3displaysequence
			$this->field3displaysequence->LinkCustomAttributes = "";
			$this->field3displaysequence->HrefValue = "";
			$this->field3displaysequence->TooltipValue = "";

			// field3domain
			$this->field3domain->LinkCustomAttributes = "";
			$this->field3domain->HrefValue = "";
			$this->field3domain->TooltipValue = "";

			// field4label
			$this->field4label->LinkCustomAttributes = "";
			$this->field4label->HrefValue = "";
			$this->field4label->TooltipValue = "";

			// field4type
			$this->field4type->LinkCustomAttributes = "";
			$this->field4type->HrefValue = "";
			$this->field4type->TooltipValue = "";

			// field4mandatory
			$this->field4mandatory->LinkCustomAttributes = "";
			$this->field4mandatory->HrefValue = "";
			$this->field4mandatory->TooltipValue = "";

			// field4display
			$this->field4display->LinkCustomAttributes = "";
			$this->field4display->HrefValue = "";
			$this->field4display->TooltipValue = "";

			// field4displaysequence
			$this->field4displaysequence->LinkCustomAttributes = "";
			$this->field4displaysequence->HrefValue = "";
			$this->field4displaysequence->TooltipValue = "";

			// field4domain
			$this->field4domain->LinkCustomAttributes = "";
			$this->field4domain->HrefValue = "";
			$this->field4domain->TooltipValue = "";

			// field5label
			$this->field5label->LinkCustomAttributes = "";
			$this->field5label->HrefValue = "";
			$this->field5label->TooltipValue = "";

			// field5type
			$this->field5type->LinkCustomAttributes = "";
			$this->field5type->HrefValue = "";
			$this->field5type->TooltipValue = "";

			// field5mandatory
			$this->field5mandatory->LinkCustomAttributes = "";
			$this->field5mandatory->HrefValue = "";
			$this->field5mandatory->TooltipValue = "";

			// field5display
			$this->field5display->LinkCustomAttributes = "";
			$this->field5display->HrefValue = "";
			$this->field5display->TooltipValue = "";

			// field5displaysequence
			$this->field5displaysequence->LinkCustomAttributes = "";
			$this->field5displaysequence->HrefValue = "";
			$this->field5displaysequence->TooltipValue = "";

			// field5domain
			$this->field5domain->LinkCustomAttributes = "";
			$this->field5domain->HrefValue = "";
			$this->field5domain->TooltipValue = "";

			// field6label
			$this->field6label->LinkCustomAttributes = "";
			$this->field6label->HrefValue = "";
			$this->field6label->TooltipValue = "";

			// field6type
			$this->field6type->LinkCustomAttributes = "";
			$this->field6type->HrefValue = "";
			$this->field6type->TooltipValue = "";

			// field6mandatory
			$this->field6mandatory->LinkCustomAttributes = "";
			$this->field6mandatory->HrefValue = "";
			$this->field6mandatory->TooltipValue = "";

			// field6display
			$this->field6display->LinkCustomAttributes = "";
			$this->field6display->HrefValue = "";
			$this->field6display->TooltipValue = "";

			// field6displaysequence
			$this->field6displaysequence->LinkCustomAttributes = "";
			$this->field6displaysequence->HrefValue = "";
			$this->field6displaysequence->TooltipValue = "";

			// field6domain
			$this->field6domain->LinkCustomAttributes = "";
			$this->field6domain->HrefValue = "";
			$this->field6domain->TooltipValue = "";

			// field7label
			$this->field7label->LinkCustomAttributes = "";
			$this->field7label->HrefValue = "";
			$this->field7label->TooltipValue = "";

			// field7type
			$this->field7type->LinkCustomAttributes = "";
			$this->field7type->HrefValue = "";
			$this->field7type->TooltipValue = "";

			// field7mandatory
			$this->field7mandatory->LinkCustomAttributes = "";
			$this->field7mandatory->HrefValue = "";
			$this->field7mandatory->TooltipValue = "";

			// field7display
			$this->field7display->LinkCustomAttributes = "";
			$this->field7display->HrefValue = "";
			$this->field7display->TooltipValue = "";

			// field7displaysequence
			$this->field7displaysequence->LinkCustomAttributes = "";
			$this->field7displaysequence->HrefValue = "";
			$this->field7displaysequence->TooltipValue = "";

			// field7domain
			$this->field7domain->LinkCustomAttributes = "";
			$this->field7domain->HrefValue = "";
			$this->field7domain->TooltipValue = "";

			// field8label
			$this->field8label->LinkCustomAttributes = "";
			$this->field8label->HrefValue = "";
			$this->field8label->TooltipValue = "";

			// field8type
			$this->field8type->LinkCustomAttributes = "";
			$this->field8type->HrefValue = "";
			$this->field8type->TooltipValue = "";

			// field8mandatory
			$this->field8mandatory->LinkCustomAttributes = "";
			$this->field8mandatory->HrefValue = "";
			$this->field8mandatory->TooltipValue = "";

			// field8display
			$this->field8display->LinkCustomAttributes = "";
			$this->field8display->HrefValue = "";
			$this->field8display->TooltipValue = "";

			// field8displaysequence
			$this->field8displaysequence->LinkCustomAttributes = "";
			$this->field8displaysequence->HrefValue = "";
			$this->field8displaysequence->TooltipValue = "";

			// field8domain
			$this->field8domain->LinkCustomAttributes = "";
			$this->field8domain->HrefValue = "";
			$this->field8domain->TooltipValue = "";

			// field9label
			$this->field9label->LinkCustomAttributes = "";
			$this->field9label->HrefValue = "";
			$this->field9label->TooltipValue = "";

			// field9type
			$this->field9type->LinkCustomAttributes = "";
			$this->field9type->HrefValue = "";
			$this->field9type->TooltipValue = "";

			// field9mandatory
			$this->field9mandatory->LinkCustomAttributes = "";
			$this->field9mandatory->HrefValue = "";
			$this->field9mandatory->TooltipValue = "";

			// field9display
			$this->field9display->LinkCustomAttributes = "";
			$this->field9display->HrefValue = "";
			$this->field9display->TooltipValue = "";

			// field9displaysequence
			$this->field9displaysequence->LinkCustomAttributes = "";
			$this->field9displaysequence->HrefValue = "";
			$this->field9displaysequence->TooltipValue = "";

			// field9domain
			$this->field9domain->LinkCustomAttributes = "";
			$this->field9domain->HrefValue = "";
			$this->field9domain->TooltipValue = "";

			// field10label
			$this->field10label->LinkCustomAttributes = "";
			$this->field10label->HrefValue = "";
			$this->field10label->TooltipValue = "";

			// field10type
			$this->field10type->LinkCustomAttributes = "";
			$this->field10type->HrefValue = "";
			$this->field10type->TooltipValue = "";

			// field10mandatory
			$this->field10mandatory->LinkCustomAttributes = "";
			$this->field10mandatory->HrefValue = "";
			$this->field10mandatory->TooltipValue = "";

			// field10display
			$this->field10display->LinkCustomAttributes = "";
			$this->field10display->HrefValue = "";
			$this->field10display->TooltipValue = "";

			// field10displaysequence
			$this->field10displaysequence->LinkCustomAttributes = "";
			$this->field10displaysequence->HrefValue = "";
			$this->field10displaysequence->TooltipValue = "";

			// field10domain
			$this->field10domain->LinkCustomAttributes = "";
			$this->field10domain->HrefValue = "";
			$this->field10domain->TooltipValue = "";

			// lastupdatedate
			$this->lastupdatedate->LinkCustomAttributes = "";
			$this->lastupdatedate->HrefValue = "";
			$this->lastupdatedate->TooltipValue = "";
		} elseif ($this->RowType == ROWTYPE_ADD) { // Add row

			// merchantid
			$this->merchantid->EditAttrs["class"] = "form-control";
			$this->merchantid->EditCustomAttributes = "";
			$this->merchantid->EditValue = HtmlEncode($this->merchantid->CurrentValue);
			$this->merchantid->PlaceHolder = RemoveHtml($this->merchantid->caption());

			// name
			$this->name->EditAttrs["class"] = "form-control";
			$this->name->EditCustomAttributes = "";
			if (!$this->name->Raw)
				$this->name->CurrentValue = HtmlDecode($this->name->CurrentValue);
			$this->name->EditValue = HtmlEncode($this->name->CurrentValue);
			$this->name->PlaceHolder = RemoveHtml($this->name->caption());

			// field1label
			$this->field1label->EditAttrs["class"] = "form-control";
			$this->field1label->EditCustomAttributes = "";
			if (!$this->field1label->Raw)
				$this->field1label->CurrentValue = HtmlDecode($this->field1label->CurrentValue);
			$this->field1label->EditValue = HtmlEncode($this->field1label->CurrentValue);
			$this->field1label->PlaceHolder = RemoveHtml($this->field1label->caption());

			// field1type
			$this->field1type->EditAttrs["class"] = "form-control";
			$this->field1type->EditCustomAttributes = "";
			$this->field1type->EditValue = HtmlEncode($this->field1type->CurrentValue);
			$this->field1type->PlaceHolder = RemoveHtml($this->field1type->caption());

			// field1mandatory
			$this->field1mandatory->EditAttrs["class"] = "form-control";
			$this->field1mandatory->EditCustomAttributes = "";
			$this->field1mandatory->EditValue = HtmlEncode($this->field1mandatory->CurrentValue);
			$this->field1mandatory->PlaceHolder = RemoveHtml($this->field1mandatory->caption());

			// field1display
			$this->field1display->EditAttrs["class"] = "form-control";
			$this->field1display->EditCustomAttributes = "";
			$this->field1display->EditValue = HtmlEncode($this->field1display->CurrentValue);
			$this->field1display->PlaceHolder = RemoveHtml($this->field1display->caption());

			// field1displaysequence
			$this->field1displaysequence->EditAttrs["class"] = "form-control";
			$this->field1displaysequence->EditCustomAttributes = "";
			$this->field1displaysequence->EditValue = HtmlEncode($this->field1displaysequence->CurrentValue);
			$this->field1displaysequence->PlaceHolder = RemoveHtml($this->field1displaysequence->caption());

			// field1domain
			$this->field1domain->EditAttrs["class"] = "form-control";
			$this->field1domain->EditCustomAttributes = "";
			$this->field1domain->EditValue = HtmlEncode($this->field1domain->CurrentValue);
			$this->field1domain->PlaceHolder = RemoveHtml($this->field1domain->caption());

			// field2label
			$this->field2label->EditAttrs["class"] = "form-control";
			$this->field2label->EditCustomAttributes = "";
			if (!$this->field2label->Raw)
				$this->field2label->CurrentValue = HtmlDecode($this->field2label->CurrentValue);
			$this->field2label->EditValue = HtmlEncode($this->field2label->CurrentValue);
			$this->field2label->PlaceHolder = RemoveHtml($this->field2label->caption());

			// field2type
			$this->field2type->EditAttrs["class"] = "form-control";
			$this->field2type->EditCustomAttributes = "";
			$this->field2type->EditValue = HtmlEncode($this->field2type->CurrentValue);
			$this->field2type->PlaceHolder = RemoveHtml($this->field2type->caption());

			// field2mandatory
			$this->field2mandatory->EditAttrs["class"] = "form-control";
			$this->field2mandatory->EditCustomAttributes = "";
			$this->field2mandatory->EditValue = HtmlEncode($this->field2mandatory->CurrentValue);
			$this->field2mandatory->PlaceHolder = RemoveHtml($this->field2mandatory->caption());

			// field2display
			$this->field2display->EditAttrs["class"] = "form-control";
			$this->field2display->EditCustomAttributes = "";
			$this->field2display->EditValue = HtmlEncode($this->field2display->CurrentValue);
			$this->field2display->PlaceHolder = RemoveHtml($this->field2display->caption());

			// field2displaysequence
			$this->field2displaysequence->EditAttrs["class"] = "form-control";
			$this->field2displaysequence->EditCustomAttributes = "";
			$this->field2displaysequence->EditValue = HtmlEncode($this->field2displaysequence->CurrentValue);
			$this->field2displaysequence->PlaceHolder = RemoveHtml($this->field2displaysequence->caption());

			// field2domain
			$this->field2domain->EditAttrs["class"] = "form-control";
			$this->field2domain->EditCustomAttributes = "";
			$this->field2domain->EditValue = HtmlEncode($this->field2domain->CurrentValue);
			$this->field2domain->PlaceHolder = RemoveHtml($this->field2domain->caption());

			// field3label
			$this->field3label->EditAttrs["class"] = "form-control";
			$this->field3label->EditCustomAttributes = "";
			if (!$this->field3label->Raw)
				$this->field3label->CurrentValue = HtmlDecode($this->field3label->CurrentValue);
			$this->field3label->EditValue = HtmlEncode($this->field3label->CurrentValue);
			$this->field3label->PlaceHolder = RemoveHtml($this->field3label->caption());

			// field3type
			$this->field3type->EditAttrs["class"] = "form-control";
			$this->field3type->EditCustomAttributes = "";
			$this->field3type->EditValue = HtmlEncode($this->field3type->CurrentValue);
			$this->field3type->PlaceHolder = RemoveHtml($this->field3type->caption());

			// field3mandatory
			$this->field3mandatory->EditAttrs["class"] = "form-control";
			$this->field3mandatory->EditCustomAttributes = "";
			$this->field3mandatory->EditValue = HtmlEncode($this->field3mandatory->CurrentValue);
			$this->field3mandatory->PlaceHolder = RemoveHtml($this->field3mandatory->caption());

			// field3display
			$this->field3display->EditAttrs["class"] = "form-control";
			$this->field3display->EditCustomAttributes = "";
			$this->field3display->EditValue = HtmlEncode($this->field3display->CurrentValue);
			$this->field3display->PlaceHolder = RemoveHtml($this->field3display->caption());

			// field3displaysequence
			$this->field3displaysequence->EditAttrs["class"] = "form-control";
			$this->field3displaysequence->EditCustomAttributes = "";
			$this->field3displaysequence->EditValue = HtmlEncode($this->field3displaysequence->CurrentValue);
			$this->field3displaysequence->PlaceHolder = RemoveHtml($this->field3displaysequence->caption());

			// field3domain
			$this->field3domain->EditAttrs["class"] = "form-control";
			$this->field3domain->EditCustomAttributes = "";
			$this->field3domain->EditValue = HtmlEncode($this->field3domain->CurrentValue);
			$this->field3domain->PlaceHolder = RemoveHtml($this->field3domain->caption());

			// field4label
			$this->field4label->EditAttrs["class"] = "form-control";
			$this->field4label->EditCustomAttributes = "";
			if (!$this->field4label->Raw)
				$this->field4label->CurrentValue = HtmlDecode($this->field4label->CurrentValue);
			$this->field4label->EditValue = HtmlEncode($this->field4label->CurrentValue);
			$this->field4label->PlaceHolder = RemoveHtml($this->field4label->caption());

			// field4type
			$this->field4type->EditAttrs["class"] = "form-control";
			$this->field4type->EditCustomAttributes = "";
			$this->field4type->EditValue = HtmlEncode($this->field4type->CurrentValue);
			$this->field4type->PlaceHolder = RemoveHtml($this->field4type->caption());

			// field4mandatory
			$this->field4mandatory->EditAttrs["class"] = "form-control";
			$this->field4mandatory->EditCustomAttributes = "";
			$this->field4mandatory->EditValue = HtmlEncode($this->field4mandatory->CurrentValue);
			$this->field4mandatory->PlaceHolder = RemoveHtml($this->field4mandatory->caption());

			// field4display
			$this->field4display->EditAttrs["class"] = "form-control";
			$this->field4display->EditCustomAttributes = "";
			$this->field4display->EditValue = HtmlEncode($this->field4display->CurrentValue);
			$this->field4display->PlaceHolder = RemoveHtml($this->field4display->caption());

			// field4displaysequence
			$this->field4displaysequence->EditAttrs["class"] = "form-control";
			$this->field4displaysequence->EditCustomAttributes = "";
			$this->field4displaysequence->EditValue = HtmlEncode($this->field4displaysequence->CurrentValue);
			$this->field4displaysequence->PlaceHolder = RemoveHtml($this->field4displaysequence->caption());

			// field4domain
			$this->field4domain->EditAttrs["class"] = "form-control";
			$this->field4domain->EditCustomAttributes = "";
			$this->field4domain->EditValue = HtmlEncode($this->field4domain->CurrentValue);
			$this->field4domain->PlaceHolder = RemoveHtml($this->field4domain->caption());

			// field5label
			$this->field5label->EditAttrs["class"] = "form-control";
			$this->field5label->EditCustomAttributes = "";
			if (!$this->field5label->Raw)
				$this->field5label->CurrentValue = HtmlDecode($this->field5label->CurrentValue);
			$this->field5label->EditValue = HtmlEncode($this->field5label->CurrentValue);
			$this->field5label->PlaceHolder = RemoveHtml($this->field5label->caption());

			// field5type
			$this->field5type->EditAttrs["class"] = "form-control";
			$this->field5type->EditCustomAttributes = "";
			$this->field5type->EditValue = HtmlEncode($this->field5type->CurrentValue);
			$this->field5type->PlaceHolder = RemoveHtml($this->field5type->caption());

			// field5mandatory
			$this->field5mandatory->EditAttrs["class"] = "form-control";
			$this->field5mandatory->EditCustomAttributes = "";
			$this->field5mandatory->EditValue = HtmlEncode($this->field5mandatory->CurrentValue);
			$this->field5mandatory->PlaceHolder = RemoveHtml($this->field5mandatory->caption());

			// field5display
			$this->field5display->EditAttrs["class"] = "form-control";
			$this->field5display->EditCustomAttributes = "";
			$this->field5display->EditValue = HtmlEncode($this->field5display->CurrentValue);
			$this->field5display->PlaceHolder = RemoveHtml($this->field5display->caption());

			// field5displaysequence
			$this->field5displaysequence->EditAttrs["class"] = "form-control";
			$this->field5displaysequence->EditCustomAttributes = "";
			$this->field5displaysequence->EditValue = HtmlEncode($this->field5displaysequence->CurrentValue);
			$this->field5displaysequence->PlaceHolder = RemoveHtml($this->field5displaysequence->caption());

			// field5domain
			$this->field5domain->EditAttrs["class"] = "form-control";
			$this->field5domain->EditCustomAttributes = "";
			$this->field5domain->EditValue = HtmlEncode($this->field5domain->CurrentValue);
			$this->field5domain->PlaceHolder = RemoveHtml($this->field5domain->caption());

			// field6label
			$this->field6label->EditAttrs["class"] = "form-control";
			$this->field6label->EditCustomAttributes = "";
			if (!$this->field6label->Raw)
				$this->field6label->CurrentValue = HtmlDecode($this->field6label->CurrentValue);
			$this->field6label->EditValue = HtmlEncode($this->field6label->CurrentValue);
			$this->field6label->PlaceHolder = RemoveHtml($this->field6label->caption());

			// field6type
			$this->field6type->EditAttrs["class"] = "form-control";
			$this->field6type->EditCustomAttributes = "";
			$this->field6type->EditValue = HtmlEncode($this->field6type->CurrentValue);
			$this->field6type->PlaceHolder = RemoveHtml($this->field6type->caption());

			// field6mandatory
			$this->field6mandatory->EditAttrs["class"] = "form-control";
			$this->field6mandatory->EditCustomAttributes = "";
			$this->field6mandatory->EditValue = HtmlEncode($this->field6mandatory->CurrentValue);
			$this->field6mandatory->PlaceHolder = RemoveHtml($this->field6mandatory->caption());

			// field6display
			$this->field6display->EditAttrs["class"] = "form-control";
			$this->field6display->EditCustomAttributes = "";
			$this->field6display->EditValue = HtmlEncode($this->field6display->CurrentValue);
			$this->field6display->PlaceHolder = RemoveHtml($this->field6display->caption());

			// field6displaysequence
			$this->field6displaysequence->EditAttrs["class"] = "form-control";
			$this->field6displaysequence->EditCustomAttributes = "";
			$this->field6displaysequence->EditValue = HtmlEncode($this->field6displaysequence->CurrentValue);
			$this->field6displaysequence->PlaceHolder = RemoveHtml($this->field6displaysequence->caption());

			// field6domain
			$this->field6domain->EditAttrs["class"] = "form-control";
			$this->field6domain->EditCustomAttributes = "";
			$this->field6domain->EditValue = HtmlEncode($this->field6domain->CurrentValue);
			$this->field6domain->PlaceHolder = RemoveHtml($this->field6domain->caption());

			// field7label
			$this->field7label->EditAttrs["class"] = "form-control";
			$this->field7label->EditCustomAttributes = "";
			if (!$this->field7label->Raw)
				$this->field7label->CurrentValue = HtmlDecode($this->field7label->CurrentValue);
			$this->field7label->EditValue = HtmlEncode($this->field7label->CurrentValue);
			$this->field7label->PlaceHolder = RemoveHtml($this->field7label->caption());

			// field7type
			$this->field7type->EditAttrs["class"] = "form-control";
			$this->field7type->EditCustomAttributes = "";
			$this->field7type->EditValue = HtmlEncode($this->field7type->CurrentValue);
			$this->field7type->PlaceHolder = RemoveHtml($this->field7type->caption());

			// field7mandatory
			$this->field7mandatory->EditAttrs["class"] = "form-control";
			$this->field7mandatory->EditCustomAttributes = "";
			$this->field7mandatory->EditValue = HtmlEncode($this->field7mandatory->CurrentValue);
			$this->field7mandatory->PlaceHolder = RemoveHtml($this->field7mandatory->caption());

			// field7display
			$this->field7display->EditAttrs["class"] = "form-control";
			$this->field7display->EditCustomAttributes = "";
			$this->field7display->EditValue = HtmlEncode($this->field7display->CurrentValue);
			$this->field7display->PlaceHolder = RemoveHtml($this->field7display->caption());

			// field7displaysequence
			$this->field7displaysequence->EditAttrs["class"] = "form-control";
			$this->field7displaysequence->EditCustomAttributes = "";
			$this->field7displaysequence->EditValue = HtmlEncode($this->field7displaysequence->CurrentValue);
			$this->field7displaysequence->PlaceHolder = RemoveHtml($this->field7displaysequence->caption());

			// field7domain
			$this->field7domain->EditAttrs["class"] = "form-control";
			$this->field7domain->EditCustomAttributes = "";
			$this->field7domain->EditValue = HtmlEncode($this->field7domain->CurrentValue);
			$this->field7domain->PlaceHolder = RemoveHtml($this->field7domain->caption());

			// field8label
			$this->field8label->EditAttrs["class"] = "form-control";
			$this->field8label->EditCustomAttributes = "";
			if (!$this->field8label->Raw)
				$this->field8label->CurrentValue = HtmlDecode($this->field8label->CurrentValue);
			$this->field8label->EditValue = HtmlEncode($this->field8label->CurrentValue);
			$this->field8label->PlaceHolder = RemoveHtml($this->field8label->caption());

			// field8type
			$this->field8type->EditAttrs["class"] = "form-control";
			$this->field8type->EditCustomAttributes = "";
			$this->field8type->EditValue = HtmlEncode($this->field8type->CurrentValue);
			$this->field8type->PlaceHolder = RemoveHtml($this->field8type->caption());

			// field8mandatory
			$this->field8mandatory->EditAttrs["class"] = "form-control";
			$this->field8mandatory->EditCustomAttributes = "";
			$this->field8mandatory->EditValue = HtmlEncode($this->field8mandatory->CurrentValue);
			$this->field8mandatory->PlaceHolder = RemoveHtml($this->field8mandatory->caption());

			// field8display
			$this->field8display->EditAttrs["class"] = "form-control";
			$this->field8display->EditCustomAttributes = "";
			$this->field8display->EditValue = HtmlEncode($this->field8display->CurrentValue);
			$this->field8display->PlaceHolder = RemoveHtml($this->field8display->caption());

			// field8displaysequence
			$this->field8displaysequence->EditAttrs["class"] = "form-control";
			$this->field8displaysequence->EditCustomAttributes = "";
			$this->field8displaysequence->EditValue = HtmlEncode($this->field8displaysequence->CurrentValue);
			$this->field8displaysequence->PlaceHolder = RemoveHtml($this->field8displaysequence->caption());

			// field8domain
			$this->field8domain->EditAttrs["class"] = "form-control";
			$this->field8domain->EditCustomAttributes = "";
			$this->field8domain->EditValue = HtmlEncode($this->field8domain->CurrentValue);
			$this->field8domain->PlaceHolder = RemoveHtml($this->field8domain->caption());

			// field9label
			$this->field9label->EditAttrs["class"] = "form-control";
			$this->field9label->EditCustomAttributes = "";
			if (!$this->field9label->Raw)
				$this->field9label->CurrentValue = HtmlDecode($this->field9label->CurrentValue);
			$this->field9label->EditValue = HtmlEncode($this->field9label->CurrentValue);
			$this->field9label->PlaceHolder = RemoveHtml($this->field9label->caption());

			// field9type
			$this->field9type->EditAttrs["class"] = "form-control";
			$this->field9type->EditCustomAttributes = "";
			$this->field9type->EditValue = HtmlEncode($this->field9type->CurrentValue);
			$this->field9type->PlaceHolder = RemoveHtml($this->field9type->caption());

			// field9mandatory
			$this->field9mandatory->EditAttrs["class"] = "form-control";
			$this->field9mandatory->EditCustomAttributes = "";
			$this->field9mandatory->EditValue = HtmlEncode($this->field9mandatory->CurrentValue);
			$this->field9mandatory->PlaceHolder = RemoveHtml($this->field9mandatory->caption());

			// field9display
			$this->field9display->EditAttrs["class"] = "form-control";
			$this->field9display->EditCustomAttributes = "";
			$this->field9display->EditValue = HtmlEncode($this->field9display->CurrentValue);
			$this->field9display->PlaceHolder = RemoveHtml($this->field9display->caption());

			// field9displaysequence
			$this->field9displaysequence->EditAttrs["class"] = "form-control";
			$this->field9displaysequence->EditCustomAttributes = "";
			$this->field9displaysequence->EditValue = HtmlEncode($this->field9displaysequence->CurrentValue);
			$this->field9displaysequence->PlaceHolder = RemoveHtml($this->field9displaysequence->caption());

			// field9domain
			$this->field9domain->EditAttrs["class"] = "form-control";
			$this->field9domain->EditCustomAttributes = "";
			$this->field9domain->EditValue = HtmlEncode($this->field9domain->CurrentValue);
			$this->field9domain->PlaceHolder = RemoveHtml($this->field9domain->caption());

			// field10label
			$this->field10label->EditAttrs["class"] = "form-control";
			$this->field10label->EditCustomAttributes = "";
			if (!$this->field10label->Raw)
				$this->field10label->CurrentValue = HtmlDecode($this->field10label->CurrentValue);
			$this->field10label->EditValue = HtmlEncode($this->field10label->CurrentValue);
			$this->field10label->PlaceHolder = RemoveHtml($this->field10label->caption());

			// field10type
			$this->field10type->EditAttrs["class"] = "form-control";
			$this->field10type->EditCustomAttributes = "";
			$this->field10type->EditValue = HtmlEncode($this->field10type->CurrentValue);
			$this->field10type->PlaceHolder = RemoveHtml($this->field10type->caption());

			// field10mandatory
			$this->field10mandatory->EditAttrs["class"] = "form-control";
			$this->field10mandatory->EditCustomAttributes = "";
			$this->field10mandatory->EditValue = HtmlEncode($this->field10mandatory->CurrentValue);
			$this->field10mandatory->PlaceHolder = RemoveHtml($this->field10mandatory->caption());

			// field10display
			$this->field10display->EditAttrs["class"] = "form-control";
			$this->field10display->EditCustomAttributes = "";
			$this->field10display->EditValue = HtmlEncode($this->field10display->CurrentValue);
			$this->field10display->PlaceHolder = RemoveHtml($this->field10display->caption());

			// field10displaysequence
			$this->field10displaysequence->EditAttrs["class"] = "form-control";
			$this->field10displaysequence->EditCustomAttributes = "";
			$this->field10displaysequence->EditValue = HtmlEncode($this->field10displaysequence->CurrentValue);
			$this->field10displaysequence->PlaceHolder = RemoveHtml($this->field10displaysequence->caption());

			// field10domain
			$this->field10domain->EditAttrs["class"] = "form-control";
			$this->field10domain->EditCustomAttributes = "";
			$this->field10domain->EditValue = HtmlEncode($this->field10domain->CurrentValue);
			$this->field10domain->PlaceHolder = RemoveHtml($this->field10domain->caption());

			// lastupdatedate
			$this->lastupdatedate->EditAttrs["class"] = "form-control";
			$this->lastupdatedate->EditCustomAttributes = "";
			$this->lastupdatedate->EditValue = HtmlEncode(FormatDateTime($this->lastupdatedate->CurrentValue, 8));
			$this->lastupdatedate->PlaceHolder = RemoveHtml($this->lastupdatedate->caption());

			// Add refer script
			// merchantid

			$this->merchantid->LinkCustomAttributes = "";
			$this->merchantid->HrefValue = "";

			// name
			$this->name->LinkCustomAttributes = "";
			$this->name->HrefValue = "";

			// field1label
			$this->field1label->LinkCustomAttributes = "";
			$this->field1label->HrefValue = "";

			// field1type
			$this->field1type->LinkCustomAttributes = "";
			$this->field1type->HrefValue = "";

			// field1mandatory
			$this->field1mandatory->LinkCustomAttributes = "";
			$this->field1mandatory->HrefValue = "";

			// field1display
			$this->field1display->LinkCustomAttributes = "";
			$this->field1display->HrefValue = "";

			// field1displaysequence
			$this->field1displaysequence->LinkCustomAttributes = "";
			$this->field1displaysequence->HrefValue = "";

			// field1domain
			$this->field1domain->LinkCustomAttributes = "";
			$this->field1domain->HrefValue = "";

			// field2label
			$this->field2label->LinkCustomAttributes = "";
			$this->field2label->HrefValue = "";

			// field2type
			$this->field2type->LinkCustomAttributes = "";
			$this->field2type->HrefValue = "";

			// field2mandatory
			$this->field2mandatory->LinkCustomAttributes = "";
			$this->field2mandatory->HrefValue = "";

			// field2display
			$this->field2display->LinkCustomAttributes = "";
			$this->field2display->HrefValue = "";

			// field2displaysequence
			$this->field2displaysequence->LinkCustomAttributes = "";
			$this->field2displaysequence->HrefValue = "";

			// field2domain
			$this->field2domain->LinkCustomAttributes = "";
			$this->field2domain->HrefValue = "";

			// field3label
			$this->field3label->LinkCustomAttributes = "";
			$this->field3label->HrefValue = "";

			// field3type
			$this->field3type->LinkCustomAttributes = "";
			$this->field3type->HrefValue = "";

			// field3mandatory
			$this->field3mandatory->LinkCustomAttributes = "";
			$this->field3mandatory->HrefValue = "";

			// field3display
			$this->field3display->LinkCustomAttributes = "";
			$this->field3display->HrefValue = "";

			// field3displaysequence
			$this->field3displaysequence->LinkCustomAttributes = "";
			$this->field3displaysequence->HrefValue = "";

			// field3domain
			$this->field3domain->LinkCustomAttributes = "";
			$this->field3domain->HrefValue = "";

			// field4label
			$this->field4label->LinkCustomAttributes = "";
			$this->field4label->HrefValue = "";

			// field4type
			$this->field4type->LinkCustomAttributes = "";
			$this->field4type->HrefValue = "";

			// field4mandatory
			$this->field4mandatory->LinkCustomAttributes = "";
			$this->field4mandatory->HrefValue = "";

			// field4display
			$this->field4display->LinkCustomAttributes = "";
			$this->field4display->HrefValue = "";

			// field4displaysequence
			$this->field4displaysequence->LinkCustomAttributes = "";
			$this->field4displaysequence->HrefValue = "";

			// field4domain
			$this->field4domain->LinkCustomAttributes = "";
			$this->field4domain->HrefValue = "";

			// field5label
			$this->field5label->LinkCustomAttributes = "";
			$this->field5label->HrefValue = "";

			// field5type
			$this->field5type->LinkCustomAttributes = "";
			$this->field5type->HrefValue = "";

			// field5mandatory
			$this->field5mandatory->LinkCustomAttributes = "";
			$this->field5mandatory->HrefValue = "";

			// field5display
			$this->field5display->LinkCustomAttributes = "";
			$this->field5display->HrefValue = "";

			// field5displaysequence
			$this->field5displaysequence->LinkCustomAttributes = "";
			$this->field5displaysequence->HrefValue = "";

			// field5domain
			$this->field5domain->LinkCustomAttributes = "";
			$this->field5domain->HrefValue = "";

			// field6label
			$this->field6label->LinkCustomAttributes = "";
			$this->field6label->HrefValue = "";

			// field6type
			$this->field6type->LinkCustomAttributes = "";
			$this->field6type->HrefValue = "";

			// field6mandatory
			$this->field6mandatory->LinkCustomAttributes = "";
			$this->field6mandatory->HrefValue = "";

			// field6display
			$this->field6display->LinkCustomAttributes = "";
			$this->field6display->HrefValue = "";

			// field6displaysequence
			$this->field6displaysequence->LinkCustomAttributes = "";
			$this->field6displaysequence->HrefValue = "";

			// field6domain
			$this->field6domain->LinkCustomAttributes = "";
			$this->field6domain->HrefValue = "";

			// field7label
			$this->field7label->LinkCustomAttributes = "";
			$this->field7label->HrefValue = "";

			// field7type
			$this->field7type->LinkCustomAttributes = "";
			$this->field7type->HrefValue = "";

			// field7mandatory
			$this->field7mandatory->LinkCustomAttributes = "";
			$this->field7mandatory->HrefValue = "";

			// field7display
			$this->field7display->LinkCustomAttributes = "";
			$this->field7display->HrefValue = "";

			// field7displaysequence
			$this->field7displaysequence->LinkCustomAttributes = "";
			$this->field7displaysequence->HrefValue = "";

			// field7domain
			$this->field7domain->LinkCustomAttributes = "";
			$this->field7domain->HrefValue = "";

			// field8label
			$this->field8label->LinkCustomAttributes = "";
			$this->field8label->HrefValue = "";

			// field8type
			$this->field8type->LinkCustomAttributes = "";
			$this->field8type->HrefValue = "";

			// field8mandatory
			$this->field8mandatory->LinkCustomAttributes = "";
			$this->field8mandatory->HrefValue = "";

			// field8display
			$this->field8display->LinkCustomAttributes = "";
			$this->field8display->HrefValue = "";

			// field8displaysequence
			$this->field8displaysequence->LinkCustomAttributes = "";
			$this->field8displaysequence->HrefValue = "";

			// field8domain
			$this->field8domain->LinkCustomAttributes = "";
			$this->field8domain->HrefValue = "";

			// field9label
			$this->field9label->LinkCustomAttributes = "";
			$this->field9label->HrefValue = "";

			// field9type
			$this->field9type->LinkCustomAttributes = "";
			$this->field9type->HrefValue = "";

			// field9mandatory
			$this->field9mandatory->LinkCustomAttributes = "";
			$this->field9mandatory->HrefValue = "";

			// field9display
			$this->field9display->LinkCustomAttributes = "";
			$this->field9display->HrefValue = "";

			// field9displaysequence
			$this->field9displaysequence->LinkCustomAttributes = "";
			$this->field9displaysequence->HrefValue = "";

			// field9domain
			$this->field9domain->LinkCustomAttributes = "";
			$this->field9domain->HrefValue = "";

			// field10label
			$this->field10label->LinkCustomAttributes = "";
			$this->field10label->HrefValue = "";

			// field10type
			$this->field10type->LinkCustomAttributes = "";
			$this->field10type->HrefValue = "";

			// field10mandatory
			$this->field10mandatory->LinkCustomAttributes = "";
			$this->field10mandatory->HrefValue = "";

			// field10display
			$this->field10display->LinkCustomAttributes = "";
			$this->field10display->HrefValue = "";

			// field10displaysequence
			$this->field10displaysequence->LinkCustomAttributes = "";
			$this->field10displaysequence->HrefValue = "";

			// field10domain
			$this->field10domain->LinkCustomAttributes = "";
			$this->field10domain->HrefValue = "";

			// lastupdatedate
			$this->lastupdatedate->LinkCustomAttributes = "";
			$this->lastupdatedate->HrefValue = "";
		}
		if ($this->RowType == ROWTYPE_ADD || $this->RowType == ROWTYPE_EDIT || $this->RowType == ROWTYPE_SEARCH) // Add/Edit/Search row
			$this->setupFieldTitles();

		// Call Row Rendered event
		if ($this->RowType != ROWTYPE_AGGREGATEINIT)
			$this->Row_Rendered();
	}

	// Validate form
	protected function validateForm()
	{
		global $Language, $FormError;

		// Initialize form error message
		$FormError = "";

		// Check if validation required
		if (!Config("SERVER_VALIDATE"))
			return ($FormError == "");
		if ($this->merchantid->Required) {
			if (!$this->merchantid->IsDetailKey && $this->merchantid->FormValue != NULL && $this->merchantid->FormValue == "") {
				AddMessage($FormError, str_replace("%s", $this->merchantid->caption(), $this->merchantid->RequiredErrorMessage));
			}
		}
		if (!CheckInteger($this->merchantid->FormValue)) {
			AddMessage($FormError, $this->merchantid->errorMessage());
		}
		if ($this->name->Required) {
			if (!$this->name->IsDetailKey && $this->name->FormValue != NULL && $this->name->FormValue == "") {
				AddMessage($FormError, str_replace("%s", $this->name->caption(), $this->name->RequiredErrorMessage));
			}
		}
		if ($this->field1label->Required) {
			if (!$this->field1label->IsDetailKey && $this->field1label->FormValue != NULL && $this->field1label->FormValue == "") {
				AddMessage($FormError, str_replace("%s", $this->field1label->caption(), $this->field1label->RequiredErrorMessage));
			}
		}
		if ($this->field1type->Required) {
			if (!$this->field1type->IsDetailKey && $this->field1type->FormValue != NULL && $this->field1type->FormValue == "") {
				AddMessage($FormError, str_replace("%s", $this->field1type->caption(), $this->field1type->RequiredErrorMessage));
			}
		}
		if (!CheckInteger($this->field1type->FormValue)) {
			AddMessage($FormError, $this->field1type->errorMessage());
		}
		if ($this->field1mandatory->Required) {
			if (!$this->field1mandatory->IsDetailKey && $this->field1mandatory->FormValue != NULL && $this->field1mandatory->FormValue == "") {
				AddMessage($FormError, str_replace("%s", $this->field1mandatory->caption(), $this->field1mandatory->RequiredErrorMessage));
			}
		}
		if (!CheckInteger($this->field1mandatory->FormValue)) {
			AddMessage($FormError, $this->field1mandatory->errorMessage());
		}
		if ($this->field1display->Required) {
			if (!$this->field1display->IsDetailKey && $this->field1display->FormValue != NULL && $this->field1display->FormValue == "") {
				AddMessage($FormError, str_replace("%s", $this->field1display->caption(), $this->field1display->RequiredErrorMessage));
			}
		}
		if (!CheckInteger($this->field1display->FormValue)) {
			AddMessage($FormError, $this->field1display->errorMessage());
		}
		if ($this->field1displaysequence->Required) {
			if (!$this->field1displaysequence->IsDetailKey && $this->field1displaysequence->FormValue != NULL && $this->field1displaysequence->FormValue == "") {
				AddMessage($FormError, str_replace("%s", $this->field1displaysequence->caption(), $this->field1displaysequence->RequiredErrorMessage));
			}
		}
		if (!CheckInteger($this->field1displaysequence->FormValue)) {
			AddMessage($FormError, $this->field1displaysequence->errorMessage());
		}
		if ($this->field1domain->Required) {
			if (!$this->field1domain->IsDetailKey && $this->field1domain->FormValue != NULL && $this->field1domain->FormValue == "") {
				AddMessage($FormError, str_replace("%s", $this->field1domain->caption(), $this->field1domain->RequiredErrorMessage));
			}
		}
		if (!CheckInteger($this->field1domain->FormValue)) {
			AddMessage($FormError, $this->field1domain->errorMessage());
		}
		if ($this->field2label->Required) {
			if (!$this->field2label->IsDetailKey && $this->field2label->FormValue != NULL && $this->field2label->FormValue == "") {
				AddMessage($FormError, str_replace("%s", $this->field2label->caption(), $this->field2label->RequiredErrorMessage));
			}
		}
		if ($this->field2type->Required) {
			if (!$this->field2type->IsDetailKey && $this->field2type->FormValue != NULL && $this->field2type->FormValue == "") {
				AddMessage($FormError, str_replace("%s", $this->field2type->caption(), $this->field2type->RequiredErrorMessage));
			}
		}
		if (!CheckInteger($this->field2type->FormValue)) {
			AddMessage($FormError, $this->field2type->errorMessage());
		}
		if ($this->field2mandatory->Required) {
			if (!$this->field2mandatory->IsDetailKey && $this->field2mandatory->FormValue != NULL && $this->field2mandatory->FormValue == "") {
				AddMessage($FormError, str_replace("%s", $this->field2mandatory->caption(), $this->field2mandatory->RequiredErrorMessage));
			}
		}
		if (!CheckInteger($this->field2mandatory->FormValue)) {
			AddMessage($FormError, $this->field2mandatory->errorMessage());
		}
		if ($this->field2display->Required) {
			if (!$this->field2display->IsDetailKey && $this->field2display->FormValue != NULL && $this->field2display->FormValue == "") {
				AddMessage($FormError, str_replace("%s", $this->field2display->caption(), $this->field2display->RequiredErrorMessage));
			}
		}
		if (!CheckInteger($this->field2display->FormValue)) {
			AddMessage($FormError, $this->field2display->errorMessage());
		}
		if ($this->field2displaysequence->Required) {
			if (!$this->field2displaysequence->IsDetailKey && $this->field2displaysequence->FormValue != NULL && $this->field2displaysequence->FormValue == "") {
				AddMessage($FormError, str_replace("%s", $this->field2displaysequence->caption(), $this->field2displaysequence->RequiredErrorMessage));
			}
		}
		if (!CheckInteger($this->field2displaysequence->FormValue)) {
			AddMessage($FormError, $this->field2displaysequence->errorMessage());
		}
		if ($this->field2domain->Required) {
			if (!$this->field2domain->IsDetailKey && $this->field2domain->FormValue != NULL && $this->field2domain->FormValue == "") {
				AddMessage($FormError, str_replace("%s", $this->field2domain->caption(), $this->field2domain->RequiredErrorMessage));
			}
		}
		if (!CheckInteger($this->field2domain->FormValue)) {
			AddMessage($FormError, $this->field2domain->errorMessage());
		}
		if ($this->field3label->Required) {
			if (!$this->field3label->IsDetailKey && $this->field3label->FormValue != NULL && $this->field3label->FormValue == "") {
				AddMessage($FormError, str_replace("%s", $this->field3label->caption(), $this->field3label->RequiredErrorMessage));
			}
		}
		if ($this->field3type->Required) {
			if (!$this->field3type->IsDetailKey && $this->field3type->FormValue != NULL && $this->field3type->FormValue == "") {
				AddMessage($FormError, str_replace("%s", $this->field3type->caption(), $this->field3type->RequiredErrorMessage));
			}
		}
		if (!CheckInteger($this->field3type->FormValue)) {
			AddMessage($FormError, $this->field3type->errorMessage());
		}
		if ($this->field3mandatory->Required) {
			if (!$this->field3mandatory->IsDetailKey && $this->field3mandatory->FormValue != NULL && $this->field3mandatory->FormValue == "") {
				AddMessage($FormError, str_replace("%s", $this->field3mandatory->caption(), $this->field3mandatory->RequiredErrorMessage));
			}
		}
		if (!CheckInteger($this->field3mandatory->FormValue)) {
			AddMessage($FormError, $this->field3mandatory->errorMessage());
		}
		if ($this->field3display->Required) {
			if (!$this->field3display->IsDetailKey && $this->field3display->FormValue != NULL && $this->field3display->FormValue == "") {
				AddMessage($FormError, str_replace("%s", $this->field3display->caption(), $this->field3display->RequiredErrorMessage));
			}
		}
		if (!CheckInteger($this->field3display->FormValue)) {
			AddMessage($FormError, $this->field3display->errorMessage());
		}
		if ($this->field3displaysequence->Required) {
			if (!$this->field3displaysequence->IsDetailKey && $this->field3displaysequence->FormValue != NULL && $this->field3displaysequence->FormValue == "") {
				AddMessage($FormError, str_replace("%s", $this->field3displaysequence->caption(), $this->field3displaysequence->RequiredErrorMessage));
			}
		}
		if (!CheckInteger($this->field3displaysequence->FormValue)) {
			AddMessage($FormError, $this->field3displaysequence->errorMessage());
		}
		if ($this->field3domain->Required) {
			if (!$this->field3domain->IsDetailKey && $this->field3domain->FormValue != NULL && $this->field3domain->FormValue == "") {
				AddMessage($FormError, str_replace("%s", $this->field3domain->caption(), $this->field3domain->RequiredErrorMessage));
			}
		}
		if (!CheckInteger($this->field3domain->FormValue)) {
			AddMessage($FormError, $this->field3domain->errorMessage());
		}
		if ($this->field4label->Required) {
			if (!$this->field4label->IsDetailKey && $this->field4label->FormValue != NULL && $this->field4label->FormValue == "") {
				AddMessage($FormError, str_replace("%s", $this->field4label->caption(), $this->field4label->RequiredErrorMessage));
			}
		}
		if ($this->field4type->Required) {
			if (!$this->field4type->IsDetailKey && $this->field4type->FormValue != NULL && $this->field4type->FormValue == "") {
				AddMessage($FormError, str_replace("%s", $this->field4type->caption(), $this->field4type->RequiredErrorMessage));
			}
		}
		if (!CheckInteger($this->field4type->FormValue)) {
			AddMessage($FormError, $this->field4type->errorMessage());
		}
		if ($this->field4mandatory->Required) {
			if (!$this->field4mandatory->IsDetailKey && $this->field4mandatory->FormValue != NULL && $this->field4mandatory->FormValue == "") {
				AddMessage($FormError, str_replace("%s", $this->field4mandatory->caption(), $this->field4mandatory->RequiredErrorMessage));
			}
		}
		if (!CheckInteger($this->field4mandatory->FormValue)) {
			AddMessage($FormError, $this->field4mandatory->errorMessage());
		}
		if ($this->field4display->Required) {
			if (!$this->field4display->IsDetailKey && $this->field4display->FormValue != NULL && $this->field4display->FormValue == "") {
				AddMessage($FormError, str_replace("%s", $this->field4display->caption(), $this->field4display->RequiredErrorMessage));
			}
		}
		if (!CheckInteger($this->field4display->FormValue)) {
			AddMessage($FormError, $this->field4display->errorMessage());
		}
		if ($this->field4displaysequence->Required) {
			if (!$this->field4displaysequence->IsDetailKey && $this->field4displaysequence->FormValue != NULL && $this->field4displaysequence->FormValue == "") {
				AddMessage($FormError, str_replace("%s", $this->field4displaysequence->caption(), $this->field4displaysequence->RequiredErrorMessage));
			}
		}
		if (!CheckInteger($this->field4displaysequence->FormValue)) {
			AddMessage($FormError, $this->field4displaysequence->errorMessage());
		}
		if ($this->field4domain->Required) {
			if (!$this->field4domain->IsDetailKey && $this->field4domain->FormValue != NULL && $this->field4domain->FormValue == "") {
				AddMessage($FormError, str_replace("%s", $this->field4domain->caption(), $this->field4domain->RequiredErrorMessage));
			}
		}
		if (!CheckInteger($this->field4domain->FormValue)) {
			AddMessage($FormError, $this->field4domain->errorMessage());
		}
		if ($this->field5label->Required) {
			if (!$this->field5label->IsDetailKey && $this->field5label->FormValue != NULL && $this->field5label->FormValue == "") {
				AddMessage($FormError, str_replace("%s", $this->field5label->caption(), $this->field5label->RequiredErrorMessage));
			}
		}
		if ($this->field5type->Required) {
			if (!$this->field5type->IsDetailKey && $this->field5type->FormValue != NULL && $this->field5type->FormValue == "") {
				AddMessage($FormError, str_replace("%s", $this->field5type->caption(), $this->field5type->RequiredErrorMessage));
			}
		}
		if (!CheckInteger($this->field5type->FormValue)) {
			AddMessage($FormError, $this->field5type->errorMessage());
		}
		if ($this->field5mandatory->Required) {
			if (!$this->field5mandatory->IsDetailKey && $this->field5mandatory->FormValue != NULL && $this->field5mandatory->FormValue == "") {
				AddMessage($FormError, str_replace("%s", $this->field5mandatory->caption(), $this->field5mandatory->RequiredErrorMessage));
			}
		}
		if (!CheckInteger($this->field5mandatory->FormValue)) {
			AddMessage($FormError, $this->field5mandatory->errorMessage());
		}
		if ($this->field5display->Required) {
			if (!$this->field5display->IsDetailKey && $this->field5display->FormValue != NULL && $this->field5display->FormValue == "") {
				AddMessage($FormError, str_replace("%s", $this->field5display->caption(), $this->field5display->RequiredErrorMessage));
			}
		}
		if (!CheckInteger($this->field5display->FormValue)) {
			AddMessage($FormError, $this->field5display->errorMessage());
		}
		if ($this->field5displaysequence->Required) {
			if (!$this->field5displaysequence->IsDetailKey && $this->field5displaysequence->FormValue != NULL && $this->field5displaysequence->FormValue == "") {
				AddMessage($FormError, str_replace("%s", $this->field5displaysequence->caption(), $this->field5displaysequence->RequiredErrorMessage));
			}
		}
		if (!CheckInteger($this->field5displaysequence->FormValue)) {
			AddMessage($FormError, $this->field5displaysequence->errorMessage());
		}
		if ($this->field5domain->Required) {
			if (!$this->field5domain->IsDetailKey && $this->field5domain->FormValue != NULL && $this->field5domain->FormValue == "") {
				AddMessage($FormError, str_replace("%s", $this->field5domain->caption(), $this->field5domain->RequiredErrorMessage));
			}
		}
		if (!CheckInteger($this->field5domain->FormValue)) {
			AddMessage($FormError, $this->field5domain->errorMessage());
		}
		if ($this->field6label->Required) {
			if (!$this->field6label->IsDetailKey && $this->field6label->FormValue != NULL && $this->field6label->FormValue == "") {
				AddMessage($FormError, str_replace("%s", $this->field6label->caption(), $this->field6label->RequiredErrorMessage));
			}
		}
		if ($this->field6type->Required) {
			if (!$this->field6type->IsDetailKey && $this->field6type->FormValue != NULL && $this->field6type->FormValue == "") {
				AddMessage($FormError, str_replace("%s", $this->field6type->caption(), $this->field6type->RequiredErrorMessage));
			}
		}
		if (!CheckInteger($this->field6type->FormValue)) {
			AddMessage($FormError, $this->field6type->errorMessage());
		}
		if ($this->field6mandatory->Required) {
			if (!$this->field6mandatory->IsDetailKey && $this->field6mandatory->FormValue != NULL && $this->field6mandatory->FormValue == "") {
				AddMessage($FormError, str_replace("%s", $this->field6mandatory->caption(), $this->field6mandatory->RequiredErrorMessage));
			}
		}
		if (!CheckInteger($this->field6mandatory->FormValue)) {
			AddMessage($FormError, $this->field6mandatory->errorMessage());
		}
		if ($this->field6display->Required) {
			if (!$this->field6display->IsDetailKey && $this->field6display->FormValue != NULL && $this->field6display->FormValue == "") {
				AddMessage($FormError, str_replace("%s", $this->field6display->caption(), $this->field6display->RequiredErrorMessage));
			}
		}
		if (!CheckInteger($this->field6display->FormValue)) {
			AddMessage($FormError, $this->field6display->errorMessage());
		}
		if ($this->field6displaysequence->Required) {
			if (!$this->field6displaysequence->IsDetailKey && $this->field6displaysequence->FormValue != NULL && $this->field6displaysequence->FormValue == "") {
				AddMessage($FormError, str_replace("%s", $this->field6displaysequence->caption(), $this->field6displaysequence->RequiredErrorMessage));
			}
		}
		if (!CheckInteger($this->field6displaysequence->FormValue)) {
			AddMessage($FormError, $this->field6displaysequence->errorMessage());
		}
		if ($this->field6domain->Required) {
			if (!$this->field6domain->IsDetailKey && $this->field6domain->FormValue != NULL && $this->field6domain->FormValue == "") {
				AddMessage($FormError, str_replace("%s", $this->field6domain->caption(), $this->field6domain->RequiredErrorMessage));
			}
		}
		if (!CheckInteger($this->field6domain->FormValue)) {
			AddMessage($FormError, $this->field6domain->errorMessage());
		}
		if ($this->field7label->Required) {
			if (!$this->field7label->IsDetailKey && $this->field7label->FormValue != NULL && $this->field7label->FormValue == "") {
				AddMessage($FormError, str_replace("%s", $this->field7label->caption(), $this->field7label->RequiredErrorMessage));
			}
		}
		if ($this->field7type->Required) {
			if (!$this->field7type->IsDetailKey && $this->field7type->FormValue != NULL && $this->field7type->FormValue == "") {
				AddMessage($FormError, str_replace("%s", $this->field7type->caption(), $this->field7type->RequiredErrorMessage));
			}
		}
		if (!CheckInteger($this->field7type->FormValue)) {
			AddMessage($FormError, $this->field7type->errorMessage());
		}
		if ($this->field7mandatory->Required) {
			if (!$this->field7mandatory->IsDetailKey && $this->field7mandatory->FormValue != NULL && $this->field7mandatory->FormValue == "") {
				AddMessage($FormError, str_replace("%s", $this->field7mandatory->caption(), $this->field7mandatory->RequiredErrorMessage));
			}
		}
		if (!CheckInteger($this->field7mandatory->FormValue)) {
			AddMessage($FormError, $this->field7mandatory->errorMessage());
		}
		if ($this->field7display->Required) {
			if (!$this->field7display->IsDetailKey && $this->field7display->FormValue != NULL && $this->field7display->FormValue == "") {
				AddMessage($FormError, str_replace("%s", $this->field7display->caption(), $this->field7display->RequiredErrorMessage));
			}
		}
		if (!CheckInteger($this->field7display->FormValue)) {
			AddMessage($FormError, $this->field7display->errorMessage());
		}
		if ($this->field7displaysequence->Required) {
			if (!$this->field7displaysequence->IsDetailKey && $this->field7displaysequence->FormValue != NULL && $this->field7displaysequence->FormValue == "") {
				AddMessage($FormError, str_replace("%s", $this->field7displaysequence->caption(), $this->field7displaysequence->RequiredErrorMessage));
			}
		}
		if (!CheckInteger($this->field7displaysequence->FormValue)) {
			AddMessage($FormError, $this->field7displaysequence->errorMessage());
		}
		if ($this->field7domain->Required) {
			if (!$this->field7domain->IsDetailKey && $this->field7domain->FormValue != NULL && $this->field7domain->FormValue == "") {
				AddMessage($FormError, str_replace("%s", $this->field7domain->caption(), $this->field7domain->RequiredErrorMessage));
			}
		}
		if (!CheckInteger($this->field7domain->FormValue)) {
			AddMessage($FormError, $this->field7domain->errorMessage());
		}
		if ($this->field8label->Required) {
			if (!$this->field8label->IsDetailKey && $this->field8label->FormValue != NULL && $this->field8label->FormValue == "") {
				AddMessage($FormError, str_replace("%s", $this->field8label->caption(), $this->field8label->RequiredErrorMessage));
			}
		}
		if ($this->field8type->Required) {
			if (!$this->field8type->IsDetailKey && $this->field8type->FormValue != NULL && $this->field8type->FormValue == "") {
				AddMessage($FormError, str_replace("%s", $this->field8type->caption(), $this->field8type->RequiredErrorMessage));
			}
		}
		if (!CheckInteger($this->field8type->FormValue)) {
			AddMessage($FormError, $this->field8type->errorMessage());
		}
		if ($this->field8mandatory->Required) {
			if (!$this->field8mandatory->IsDetailKey && $this->field8mandatory->FormValue != NULL && $this->field8mandatory->FormValue == "") {
				AddMessage($FormError, str_replace("%s", $this->field8mandatory->caption(), $this->field8mandatory->RequiredErrorMessage));
			}
		}
		if (!CheckInteger($this->field8mandatory->FormValue)) {
			AddMessage($FormError, $this->field8mandatory->errorMessage());
		}
		if ($this->field8display->Required) {
			if (!$this->field8display->IsDetailKey && $this->field8display->FormValue != NULL && $this->field8display->FormValue == "") {
				AddMessage($FormError, str_replace("%s", $this->field8display->caption(), $this->field8display->RequiredErrorMessage));
			}
		}
		if (!CheckInteger($this->field8display->FormValue)) {
			AddMessage($FormError, $this->field8display->errorMessage());
		}
		if ($this->field8displaysequence->Required) {
			if (!$this->field8displaysequence->IsDetailKey && $this->field8displaysequence->FormValue != NULL && $this->field8displaysequence->FormValue == "") {
				AddMessage($FormError, str_replace("%s", $this->field8displaysequence->caption(), $this->field8displaysequence->RequiredErrorMessage));
			}
		}
		if (!CheckInteger($this->field8displaysequence->FormValue)) {
			AddMessage($FormError, $this->field8displaysequence->errorMessage());
		}
		if ($this->field8domain->Required) {
			if (!$this->field8domain->IsDetailKey && $this->field8domain->FormValue != NULL && $this->field8domain->FormValue == "") {
				AddMessage($FormError, str_replace("%s", $this->field8domain->caption(), $this->field8domain->RequiredErrorMessage));
			}
		}
		if (!CheckInteger($this->field8domain->FormValue)) {
			AddMessage($FormError, $this->field8domain->errorMessage());
		}
		if ($this->field9label->Required) {
			if (!$this->field9label->IsDetailKey && $this->field9label->FormValue != NULL && $this->field9label->FormValue == "") {
				AddMessage($FormError, str_replace("%s", $this->field9label->caption(), $this->field9label->RequiredErrorMessage));
			}
		}
		if ($this->field9type->Required) {
			if (!$this->field9type->IsDetailKey && $this->field9type->FormValue != NULL && $this->field9type->FormValue == "") {
				AddMessage($FormError, str_replace("%s", $this->field9type->caption(), $this->field9type->RequiredErrorMessage));
			}
		}
		if (!CheckInteger($this->field9type->FormValue)) {
			AddMessage($FormError, $this->field9type->errorMessage());
		}
		if ($this->field9mandatory->Required) {
			if (!$this->field9mandatory->IsDetailKey && $this->field9mandatory->FormValue != NULL && $this->field9mandatory->FormValue == "") {
				AddMessage($FormError, str_replace("%s", $this->field9mandatory->caption(), $this->field9mandatory->RequiredErrorMessage));
			}
		}
		if (!CheckInteger($this->field9mandatory->FormValue)) {
			AddMessage($FormError, $this->field9mandatory->errorMessage());
		}
		if ($this->field9display->Required) {
			if (!$this->field9display->IsDetailKey && $this->field9display->FormValue != NULL && $this->field9display->FormValue == "") {
				AddMessage($FormError, str_replace("%s", $this->field9display->caption(), $this->field9display->RequiredErrorMessage));
			}
		}
		if (!CheckInteger($this->field9display->FormValue)) {
			AddMessage($FormError, $this->field9display->errorMessage());
		}
		if ($this->field9displaysequence->Required) {
			if (!$this->field9displaysequence->IsDetailKey && $this->field9displaysequence->FormValue != NULL && $this->field9displaysequence->FormValue == "") {
				AddMessage($FormError, str_replace("%s", $this->field9displaysequence->caption(), $this->field9displaysequence->RequiredErrorMessage));
			}
		}
		if (!CheckInteger($this->field9displaysequence->FormValue)) {
			AddMessage($FormError, $this->field9displaysequence->errorMessage());
		}
		if ($this->field9domain->Required) {
			if (!$this->field9domain->IsDetailKey && $this->field9domain->FormValue != NULL && $this->field9domain->FormValue == "") {
				AddMessage($FormError, str_replace("%s", $this->field9domain->caption(), $this->field9domain->RequiredErrorMessage));
			}
		}
		if (!CheckInteger($this->field9domain->FormValue)) {
			AddMessage($FormError, $this->field9domain->errorMessage());
		}
		if ($this->field10label->Required) {
			if (!$this->field10label->IsDetailKey && $this->field10label->FormValue != NULL && $this->field10label->FormValue == "") {
				AddMessage($FormError, str_replace("%s", $this->field10label->caption(), $this->field10label->RequiredErrorMessage));
			}
		}
		if ($this->field10type->Required) {
			if (!$this->field10type->IsDetailKey && $this->field10type->FormValue != NULL && $this->field10type->FormValue == "") {
				AddMessage($FormError, str_replace("%s", $this->field10type->caption(), $this->field10type->RequiredErrorMessage));
			}
		}
		if (!CheckInteger($this->field10type->FormValue)) {
			AddMessage($FormError, $this->field10type->errorMessage());
		}
		if ($this->field10mandatory->Required) {
			if (!$this->field10mandatory->IsDetailKey && $this->field10mandatory->FormValue != NULL && $this->field10mandatory->FormValue == "") {
				AddMessage($FormError, str_replace("%s", $this->field10mandatory->caption(), $this->field10mandatory->RequiredErrorMessage));
			}
		}
		if (!CheckInteger($this->field10mandatory->FormValue)) {
			AddMessage($FormError, $this->field10mandatory->errorMessage());
		}
		if ($this->field10display->Required) {
			if (!$this->field10display->IsDetailKey && $this->field10display->FormValue != NULL && $this->field10display->FormValue == "") {
				AddMessage($FormError, str_replace("%s", $this->field10display->caption(), $this->field10display->RequiredErrorMessage));
			}
		}
		if (!CheckInteger($this->field10display->FormValue)) {
			AddMessage($FormError, $this->field10display->errorMessage());
		}
		if ($this->field10displaysequence->Required) {
			if (!$this->field10displaysequence->IsDetailKey && $this->field10displaysequence->FormValue != NULL && $this->field10displaysequence->FormValue == "") {
				AddMessage($FormError, str_replace("%s", $this->field10displaysequence->caption(), $this->field10displaysequence->RequiredErrorMessage));
			}
		}
		if (!CheckInteger($this->field10displaysequence->FormValue)) {
			AddMessage($FormError, $this->field10displaysequence->errorMessage());
		}
		if ($this->field10domain->Required) {
			if (!$this->field10domain->IsDetailKey && $this->field10domain->FormValue != NULL && $this->field10domain->FormValue == "") {
				AddMessage($FormError, str_replace("%s", $this->field10domain->caption(), $this->field10domain->RequiredErrorMessage));
			}
		}
		if (!CheckInteger($this->field10domain->FormValue)) {
			AddMessage($FormError, $this->field10domain->errorMessage());
		}
		if ($this->lastupdatedate->Required) {
			if (!$this->lastupdatedate->IsDetailKey && $this->lastupdatedate->FormValue != NULL && $this->lastupdatedate->FormValue == "") {
				AddMessage($FormError, str_replace("%s", $this->lastupdatedate->caption(), $this->lastupdatedate->RequiredErrorMessage));
			}
		}
		if (!CheckDate($this->lastupdatedate->FormValue)) {
			AddMessage($FormError, $this->lastupdatedate->errorMessage());
		}

		// Return validate result
		$validateForm = ($FormError == "");

		// Call Form_CustomValidate event
		$formCustomError = "";
		$validateForm = $validateForm && $this->Form_CustomValidate($formCustomError);
		if ($formCustomError != "") {
			AddMessage($FormError, $formCustomError);
		}
		return $validateForm;
	}

	// Add record
	protected function addRow($rsold = NULL)
	{
		global $Language, $Security;
		$conn = $this->getConnection();

		// Load db values from rsold
		$this->loadDbValues($rsold);
		if ($rsold) {
		}
		$rsnew = [];

		// merchantid
		$this->merchantid->setDbValueDef($rsnew, $this->merchantid->CurrentValue, 0, FALSE);

		// name
		$this->name->setDbValueDef($rsnew, $this->name->CurrentValue, "", FALSE);

		// field1label
		$this->field1label->setDbValueDef($rsnew, $this->field1label->CurrentValue, "", FALSE);

		// field1type
		$this->field1type->setDbValueDef($rsnew, $this->field1type->CurrentValue, 0, FALSE);

		// field1mandatory
		$this->field1mandatory->setDbValueDef($rsnew, $this->field1mandatory->CurrentValue, 0, FALSE);

		// field1display
		$this->field1display->setDbValueDef($rsnew, $this->field1display->CurrentValue, 0, FALSE);

		// field1displaysequence
		$this->field1displaysequence->setDbValueDef($rsnew, $this->field1displaysequence->CurrentValue, 0, FALSE);

		// field1domain
		$this->field1domain->setDbValueDef($rsnew, $this->field1domain->CurrentValue, NULL, FALSE);

		// field2label
		$this->field2label->setDbValueDef($rsnew, $this->field2label->CurrentValue, "", FALSE);

		// field2type
		$this->field2type->setDbValueDef($rsnew, $this->field2type->CurrentValue, 0, FALSE);

		// field2mandatory
		$this->field2mandatory->setDbValueDef($rsnew, $this->field2mandatory->CurrentValue, 0, FALSE);

		// field2display
		$this->field2display->setDbValueDef($rsnew, $this->field2display->CurrentValue, 0, FALSE);

		// field2displaysequence
		$this->field2displaysequence->setDbValueDef($rsnew, $this->field2displaysequence->CurrentValue, 0, FALSE);

		// field2domain
		$this->field2domain->setDbValueDef($rsnew, $this->field2domain->CurrentValue, NULL, FALSE);

		// field3label
		$this->field3label->setDbValueDef($rsnew, $this->field3label->CurrentValue, "", FALSE);

		// field3type
		$this->field3type->setDbValueDef($rsnew, $this->field3type->CurrentValue, 0, FALSE);

		// field3mandatory
		$this->field3mandatory->setDbValueDef($rsnew, $this->field3mandatory->CurrentValue, 0, FALSE);

		// field3display
		$this->field3display->setDbValueDef($rsnew, $this->field3display->CurrentValue, 0, FALSE);

		// field3displaysequence
		$this->field3displaysequence->setDbValueDef($rsnew, $this->field3displaysequence->CurrentValue, 0, FALSE);

		// field3domain
		$this->field3domain->setDbValueDef($rsnew, $this->field3domain->CurrentValue, NULL, FALSE);

		// field4label
		$this->field4label->setDbValueDef($rsnew, $this->field4label->CurrentValue, "", FALSE);

		// field4type
		$this->field4type->setDbValueDef($rsnew, $this->field4type->CurrentValue, 0, FALSE);

		// field4mandatory
		$this->field4mandatory->setDbValueDef($rsnew, $this->field4mandatory->CurrentValue, 0, FALSE);

		// field4display
		$this->field4display->setDbValueDef($rsnew, $this->field4display->CurrentValue, 0, FALSE);

		// field4displaysequence
		$this->field4displaysequence->setDbValueDef($rsnew, $this->field4displaysequence->CurrentValue, 0, FALSE);

		// field4domain
		$this->field4domain->setDbValueDef($rsnew, $this->field4domain->CurrentValue, NULL, FALSE);

		// field5label
		$this->field5label->setDbValueDef($rsnew, $this->field5label->CurrentValue, "", FALSE);

		// field5type
		$this->field5type->setDbValueDef($rsnew, $this->field5type->CurrentValue, 0, FALSE);

		// field5mandatory
		$this->field5mandatory->setDbValueDef($rsnew, $this->field5mandatory->CurrentValue, 0, FALSE);

		// field5display
		$this->field5display->setDbValueDef($rsnew, $this->field5display->CurrentValue, 0, FALSE);

		// field5displaysequence
		$this->field5displaysequence->setDbValueDef($rsnew, $this->field5displaysequence->CurrentValue, 0, FALSE);

		// field5domain
		$this->field5domain->setDbValueDef($rsnew, $this->field5domain->CurrentValue, NULL, FALSE);

		// field6label
		$this->field6label->setDbValueDef($rsnew, $this->field6label->CurrentValue, "", FALSE);

		// field6type
		$this->field6type->setDbValueDef($rsnew, $this->field6type->CurrentValue, 0, FALSE);

		// field6mandatory
		$this->field6mandatory->setDbValueDef($rsnew, $this->field6mandatory->CurrentValue, 0, FALSE);

		// field6display
		$this->field6display->setDbValueDef($rsnew, $this->field6display->CurrentValue, 0, FALSE);

		// field6displaysequence
		$this->field6displaysequence->setDbValueDef($rsnew, $this->field6displaysequence->CurrentValue, 0, FALSE);

		// field6domain
		$this->field6domain->setDbValueDef($rsnew, $this->field6domain->CurrentValue, 0, FALSE);

		// field7label
		$this->field7label->setDbValueDef($rsnew, $this->field7label->CurrentValue, "", FALSE);

		// field7type
		$this->field7type->setDbValueDef($rsnew, $this->field7type->CurrentValue, 0, FALSE);

		// field7mandatory
		$this->field7mandatory->setDbValueDef($rsnew, $this->field7mandatory->CurrentValue, 0, FALSE);

		// field7display
		$this->field7display->setDbValueDef($rsnew, $this->field7display->CurrentValue, 0, FALSE);

		// field7displaysequence
		$this->field7displaysequence->setDbValueDef($rsnew, $this->field7displaysequence->CurrentValue, 0, FALSE);

		// field7domain
		$this->field7domain->setDbValueDef($rsnew, $this->field7domain->CurrentValue, NULL, FALSE);

		// field8label
		$this->field8label->setDbValueDef($rsnew, $this->field8label->CurrentValue, "", FALSE);

		// field8type
		$this->field8type->setDbValueDef($rsnew, $this->field8type->CurrentValue, 0, FALSE);

		// field8mandatory
		$this->field8mandatory->setDbValueDef($rsnew, $this->field8mandatory->CurrentValue, 0, FALSE);

		// field8display
		$this->field8display->setDbValueDef($rsnew, $this->field8display->CurrentValue, 0, FALSE);

		// field8displaysequence
		$this->field8displaysequence->setDbValueDef($rsnew, $this->field8displaysequence->CurrentValue, 0, FALSE);

		// field8domain
		$this->field8domain->setDbValueDef($rsnew, $this->field8domain->CurrentValue, NULL, FALSE);

		// field9label
		$this->field9label->setDbValueDef($rsnew, $this->field9label->CurrentValue, "", FALSE);

		// field9type
		$this->field9type->setDbValueDef($rsnew, $this->field9type->CurrentValue, 0, FALSE);

		// field9mandatory
		$this->field9mandatory->setDbValueDef($rsnew, $this->field9mandatory->CurrentValue, 0, FALSE);

		// field9display
		$this->field9display->setDbValueDef($rsnew, $this->field9display->CurrentValue, 0, FALSE);

		// field9displaysequence
		$this->field9displaysequence->setDbValueDef($rsnew, $this->field9displaysequence->CurrentValue, 0, FALSE);

		// field9domain
		$this->field9domain->setDbValueDef($rsnew, $this->field9domain->CurrentValue, NULL, FALSE);

		// field10label
		$this->field10label->setDbValueDef($rsnew, $this->field10label->CurrentValue, "", FALSE);

		// field10type
		$this->field10type->setDbValueDef($rsnew, $this->field10type->CurrentValue, 0, FALSE);

		// field10mandatory
		$this->field10mandatory->setDbValueDef($rsnew, $this->field10mandatory->CurrentValue, 0, FALSE);

		// field10display
		$this->field10display->setDbValueDef($rsnew, $this->field10display->CurrentValue, 0, FALSE);

		// field10displaysequence
		$this->field10displaysequence->setDbValueDef($rsnew, $this->field10displaysequence->CurrentValue, 0, FALSE);

		// field10domain
		$this->field10domain->setDbValueDef($rsnew, $this->field10domain->CurrentValue, NULL, FALSE);

		// lastupdatedate
		$this->lastupdatedate->setDbValueDef($rsnew, UnFormatDateTime($this->lastupdatedate->CurrentValue, 0), NULL, FALSE);

		// Call Row Inserting event
		$rs = ($rsold) ? $rsold->fields : NULL;
		$insertRow = $this->Row_Inserting($rs, $rsnew);
		if ($insertRow) {
			$conn->raiseErrorFn = Config("ERROR_FUNC");
			$addRow = $this->insert($rsnew);
			$conn->raiseErrorFn = "";
			if ($addRow) {
			}
		} else {
			if ($this->getSuccessMessage() != "" || $this->getFailureMessage() != "") {

				// Use the message, do nothing
			} elseif ($this->CancelMessage != "") {
				$this->setFailureMessage($this->CancelMessage);
				$this->CancelMessage = "";
			} else {
				$this->setFailureMessage($Language->phrase("InsertCancelled"));
			}
			$addRow = FALSE;
		}
		if ($addRow) {

			// Call Row Inserted event
			$rs = ($rsold) ? $rsold->fields : NULL;
			$this->Row_Inserted($rs, $rsnew);
		}

		// Clean upload path if any
		if ($addRow) {
		}

		// Write JSON for API request
		if (IsApi() && $addRow) {
			$row = $this->getRecordsFromRecordset([$rsnew], TRUE);
			WriteJson(["success" => TRUE, $this->TableVar => $row]);
		}
		return $addRow;
	}

	// Set up Breadcrumb
	protected function setupBreadcrumb()
	{
		global $Breadcrumb, $Language;
		$Breadcrumb = new Breadcrumb();
		$url = substr(CurrentUrl(), strrpos(CurrentUrl(), "/")+1);
		$Breadcrumb->add("list", $this->TableVar, $this->addMasterUrl("extrafieldstemplatelist.php"), "", $this->TableVar, TRUE);
		$pageId = ($this->isCopy()) ? "Copy" : "Add";
		$Breadcrumb->add("add", $pageId, $url);
	}

	// Setup lookup options
	public function setupLookupOptions($fld)
	{
		if ($fld->Lookup !== NULL && $fld->Lookup->Options === NULL) {

			// Get default connection and filter
			$conn = $this->getConnection();
			$lookupFilter = "";

			// No need to check any more
			$fld->Lookup->Options = [];

			// Set up lookup SQL and connection
			switch ($fld->FieldVar) {
				default:
					$lookupFilter = "";
					break;
			}

			// Always call to Lookup->getSql so that user can setup Lookup->Options in Lookup_Selecting server event
			$sql = $fld->Lookup->getSql(FALSE, "", $lookupFilter, $this);

			// Set up lookup cache
			if ($fld->UseLookupCache && $sql != "" && count($fld->Lookup->Options) == 0) {
				$totalCnt = $this->getRecordCount($sql, $conn);
				if ($totalCnt > $fld->LookupCacheCount) // Total count > cache count, do not cache
					return;
				$rs = $conn->execute($sql);
				$ar = [];
				while ($rs && !$rs->EOF) {
					$row = &$rs->fields;

					// Format the field values
					switch ($fld->FieldVar) {
					}
					$ar[strval($row[0])] = $row;
					$rs->moveNext();
				}
				if ($rs)
					$rs->close();
				$fld->Lookup->Options = $ar;
			}
		}
	}

	// Page Load event
	function Page_Load() {

		//echo "Page Load";
	}

	// Page Unload event
	function Page_Unload() {

		//echo "Page Unload";
	}

	// Page Redirecting event
	function Page_Redirecting(&$url) {

		// Example:
		//$url = "your URL";

	}

	// Message Showing event
	// $type = ''|'success'|'failure'|'warning'
	function Message_Showing(&$msg, $type) {
		if ($type == 'success') {

			//$msg = "your success message";
		} elseif ($type == 'failure') {

			//$msg = "your failure message";
		} elseif ($type == 'warning') {

			//$msg = "your warning message";
		} else {

			//$msg = "your message";
		}
	}

	// Page Render event
	function Page_Render() {

		//echo "Page Render";
	}

	// Page Data Rendering event
	function Page_DataRendering(&$header) {

		// Example:
		//$header = "your header";

	}

	// Page Data Rendered event
	function Page_DataRendered(&$footer) {

		// Example:
		//$footer = "your footer";

	}

	// Form Custom Validate event
	function Form_CustomValidate(&$customError) {

		// Return error message in CustomError
		return TRUE;
	}
} // End class
?>