<?php namespace PHPMaker2020\_4payadmin; ?>
<?php

/**
 * Table class for userpi
 */
class userpi extends DbTable
{
	protected $SqlFrom = "";
	protected $SqlSelect = "";
	protected $SqlSelectList = "";
	protected $SqlWhere = "";
	protected $SqlGroupBy = "";
	protected $SqlHaving = "";
	protected $SqlOrderBy = "";
	public $UseSessionForListSql = TRUE;

	// Column CSS classes
	public $LeftColumnClass = "col-sm-2 col-form-label ew-label";
	public $RightColumnClass = "col-sm-10";
	public $OffsetColumnClass = "col-sm-10 offset-sm-2";
	public $TableLeftColumnClass = "w-col-2";

	// Audit trail
	public $AuditTrailOnAdd = TRUE;
	public $AuditTrailOnEdit = TRUE;
	public $AuditTrailOnDelete = TRUE;
	public $AuditTrailOnView = FALSE;
	public $AuditTrailOnViewData = FALSE;
	public $AuditTrailOnSearch = FALSE;

	// Export
	public $ExportDoc;

	// Fields
	public $id;
	public $_userid;
	public $tokenid;
	public $cardno;
	public $lastupdated;
	public $piid;
	public $deleted;
	public $currcode;
	public $friendlyname;
	public $_key;
	public $verified;
	public $addeddatetime;
	public $piexpirytime;
	public $verifiedtime;
	public $vaultid;
	public $defaultpi;
	public $acctID;
	public $addedbyuserid;
	public $pendingtransfer;
	public $sensitivedataid;
	public $purchaseid;
	public $paymentid;
	public $others;
	public $others2;
	public $pinhash;
	public $pinexpiry;
	public $deletiontime;
	public $servicefeeexempted;
	public $purposeofaccount;
	public $extendedfields;

	// Constructor
	public function __construct()
	{
		global $Language, $CurrentLanguage;
		parent::__construct();

		// Language object
		if (!isset($Language))
			$Language = new Language();
		$this->TableVar = 'userpi';
		$this->TableName = 'userpi';
		$this->TableType = 'TABLE';

		// Update Table
		$this->UpdateTable = "`userpi`";
		$this->Dbid = 'DB';
		$this->ExportAll = TRUE;
		$this->ExportPageBreakCount = 0; // Page break per every n record (PDF only)
		$this->ExportPageOrientation = "portrait"; // Page orientation (PDF only)
		$this->ExportPageSize = "a4"; // Page size (PDF only)
		$this->ExportExcelPageOrientation = \PhpOffice\PhpSpreadsheet\Worksheet\PageSetup::ORIENTATION_DEFAULT; // Page orientation (PhpSpreadsheet only)
		$this->ExportExcelPageSize = \PhpOffice\PhpSpreadsheet\Worksheet\PageSetup::PAPERSIZE_A4; // Page size (PhpSpreadsheet only)
		$this->ExportWordPageOrientation = "portrait"; // Page orientation (PHPWord only)
		$this->ExportWordColumnWidth = NULL; // Cell width (PHPWord only)
		$this->DetailAdd = FALSE; // Allow detail add
		$this->DetailEdit = FALSE; // Allow detail edit
		$this->DetailView = TRUE; // Allow detail view
		$this->ShowMultipleDetails = FALSE; // Show multiple details
		$this->GridAddRowCount = 5;
		$this->AllowAddDeleteRow = TRUE; // Allow add/delete row
		$this->UserIDAllowSecurity = Config("DEFAULT_USER_ID_ALLOW_SECURITY"); // Default User ID allowed permissions
		$this->BasicSearch = new BasicSearch($this->TableVar);

		// id
		$this->id = new DbField('userpi', 'userpi', 'x_id', 'id', '`id`', '`id`', 20, 12, -1, FALSE, '`id`', FALSE, FALSE, FALSE, 'FORMATTED TEXT', 'NO');
		$this->id->IsAutoIncrement = TRUE; // Autoincrement field
		$this->id->IsPrimaryKey = TRUE; // Primary key field
		$this->id->IsForeignKey = TRUE; // Foreign key field
		$this->id->Sortable = TRUE; // Allow sort
		$this->id->DefaultErrorMessage = $Language->phrase("IncorrectInteger");
		$this->fields['id'] = &$this->id;

		// userid
		$this->_userid = new DbField('userpi', 'userpi', 'x__userid', 'userid', '`userid`', '`userid`', 20, 12, -1, FALSE, '`userid`', FALSE, FALSE, FALSE, 'FORMATTED TEXT', 'TEXT');
		$this->_userid->IsForeignKey = TRUE; // Foreign key field
		$this->_userid->Nullable = FALSE; // NOT NULL field
		$this->_userid->Required = TRUE; // Required field
		$this->_userid->Sortable = TRUE; // Allow sort
		$this->_userid->DefaultErrorMessage = $Language->phrase("IncorrectInteger");
		$this->fields['userid'] = &$this->_userid;

		// tokenid
		$this->tokenid = new DbField('userpi', 'userpi', 'x_tokenid', 'tokenid', '`tokenid`', '`tokenid`', 200, 50, -1, FALSE, '`tokenid`', FALSE, FALSE, FALSE, 'FORMATTED TEXT', 'TEXT');
		$this->tokenid->Nullable = FALSE; // NOT NULL field
		$this->tokenid->Required = TRUE; // Required field
		$this->tokenid->Sortable = TRUE; // Allow sort
		$this->fields['tokenid'] = &$this->tokenid;

		// cardno
		$this->cardno = new DbField('userpi', 'userpi', 'x_cardno', 'cardno', '`cardno`', '`cardno`', 200, 50, -1, FALSE, '`cardno`', FALSE, FALSE, FALSE, 'FORMATTED TEXT', 'TEXT');
		$this->cardno->Nullable = FALSE; // NOT NULL field
		$this->cardno->Required = TRUE; // Required field
		$this->cardno->Sortable = TRUE; // Allow sort
		$this->fields['cardno'] = &$this->cardno;

		// lastupdated
		$this->lastupdated = new DbField('userpi', 'userpi', 'x_lastupdated', 'lastupdated', '`lastupdated`', CastDateFieldForLike("`lastupdated`", 10, "DB"), 135, 19, 10, FALSE, '`lastupdated`', FALSE, FALSE, FALSE, 'FORMATTED TEXT', 'TEXT');
		$this->lastupdated->Required = TRUE; // Required field
		$this->lastupdated->Sortable = TRUE; // Allow sort
		$this->lastupdated->DefaultErrorMessage = str_replace("%s", $GLOBALS["DATE_SEPARATOR"], $Language->phrase("IncorrectDateMDY"));
		$this->fields['lastupdated'] = &$this->lastupdated;

		// piid
		$this->piid = new DbField('userpi', 'userpi', 'x_piid', 'piid', '`piid`', '`piid`', 3, 5, -1, FALSE, '`piid`', FALSE, FALSE, FALSE, 'FORMATTED TEXT', 'SELECT');
		$this->piid->Nullable = FALSE; // NOT NULL field
		$this->piid->Required = TRUE; // Required field
		$this->piid->Sortable = TRUE; // Allow sort
		$this->piid->UsePleaseSelect = TRUE; // Use PleaseSelect by default
		$this->piid->PleaseSelectText = $Language->phrase("PleaseSelect"); // "PleaseSelect" text
		$this->piid->Lookup = new Lookup('piid', 'paymentinstrument', FALSE, 'id', ["name","","",""], [], [], [], [], [], [], '`name`', '');
		$this->piid->DefaultErrorMessage = $Language->phrase("IncorrectInteger");
		$this->fields['piid'] = &$this->piid;

		// deleted
		$this->deleted = new DbField('userpi', 'userpi', 'x_deleted', 'deleted', '`deleted`', '`deleted`', 3, 1, -1, FALSE, '`deleted`', FALSE, FALSE, FALSE, 'FORMATTED TEXT', 'SELECT');
		$this->deleted->Nullable = FALSE; // NOT NULL field
		$this->deleted->Required = TRUE; // Required field
		$this->deleted->Sortable = TRUE; // Allow sort
		$this->deleted->UsePleaseSelect = TRUE; // Use PleaseSelect by default
		$this->deleted->PleaseSelectText = $Language->phrase("PleaseSelect"); // "PleaseSelect" text
		$this->deleted->Lookup = new Lookup('deleted', 'booleanvalues', FALSE, 'id', ["NAME","","",""], [], [], [], [], [], [], '', '');
		$this->deleted->OptionCount = 4;
		$this->deleted->DefaultErrorMessage = $Language->phrase("IncorrectInteger");
		$this->fields['deleted'] = &$this->deleted;

		// currcode
		$this->currcode = new DbField('userpi', 'userpi', 'x_currcode', 'currcode', '`currcode`', '`currcode`', 200, 3, -1, FALSE, '`currcode`', FALSE, FALSE, FALSE, 'FORMATTED TEXT', 'SELECT');
		$this->currcode->Nullable = FALSE; // NOT NULL field
		$this->currcode->Required = TRUE; // Required field
		$this->currcode->Sortable = TRUE; // Allow sort
		$this->currcode->UsePleaseSelect = TRUE; // Use PleaseSelect by default
		$this->currcode->PleaseSelectText = $Language->phrase("PleaseSelect"); // "PleaseSelect" text
		$this->currcode->Lookup = new Lookup('currcode', 'curr', FALSE, 'currCode', ["currCode","","",""], [], [], [], [], [], [], '', '');
		$this->fields['currcode'] = &$this->currcode;

		// friendlyname
		$this->friendlyname = new DbField('userpi', 'userpi', 'x_friendlyname', 'friendlyname', '`friendlyname`', '`friendlyname`', 200, 100, -1, FALSE, '`friendlyname`', FALSE, FALSE, FALSE, 'FORMATTED TEXT', 'TEXT');
		$this->friendlyname->Sortable = TRUE; // Allow sort
		$this->fields['friendlyname'] = &$this->friendlyname;

		// key
		$this->_key = new DbField('userpi', 'userpi', 'x__key', 'key', '`key`', '`key`', 201, 1500, -1, FALSE, '`key`', FALSE, FALSE, FALSE, 'FORMATTED TEXT', 'TEXTAREA');
		$this->_key->Nullable = FALSE; // NOT NULL field
		$this->_key->Required = TRUE; // Required field
		$this->_key->Sortable = TRUE; // Allow sort
		$this->fields['key'] = &$this->_key;

		// verified
		$this->verified = new DbField('userpi', 'userpi', 'x_verified', 'verified', '`verified`', '`verified`', 3, 1, -1, FALSE, '`verified`', FALSE, FALSE, FALSE, 'FORMATTED TEXT', 'RADIO');
		$this->verified->Nullable = FALSE; // NOT NULL field
		$this->verified->Required = TRUE; // Required field
		$this->verified->Sortable = TRUE; // Allow sort
		$this->verified->Lookup = new Lookup('verified', 'booleanvalues', FALSE, 'id', ["NAME","","",""], [], [], [], [], [], [], '', '');
		$this->verified->DefaultErrorMessage = $Language->phrase("IncorrectInteger");
		$this->fields['verified'] = &$this->verified;

		// addeddatetime
		$this->addeddatetime = new DbField('userpi', 'userpi', 'x_addeddatetime', 'addeddatetime', '`addeddatetime`', CastDateFieldForLike("`addeddatetime`", 0, "DB"), 135, 19, 0, FALSE, '`addeddatetime`', FALSE, FALSE, FALSE, 'FORMATTED TEXT', 'TEXT');
		$this->addeddatetime->Sortable = TRUE; // Allow sort
		$this->addeddatetime->DefaultErrorMessage = str_replace("%s", $GLOBALS["DATE_FORMAT"], $Language->phrase("IncorrectDate"));
		$this->fields['addeddatetime'] = &$this->addeddatetime;

		// piexpirytime
		$this->piexpirytime = new DbField('userpi', 'userpi', 'x_piexpirytime', 'piexpirytime', '`piexpirytime`', CastDateFieldForLike("`piexpirytime`", 1, "DB"), 135, 19, 1, FALSE, '`piexpirytime`', FALSE, FALSE, FALSE, 'FORMATTED TEXT', 'TEXT');
		$this->piexpirytime->Sortable = TRUE; // Allow sort
		$this->piexpirytime->DefaultErrorMessage = str_replace("%s", $GLOBALS["DATE_FORMAT"], $Language->phrase("IncorrectDate"));
		$this->fields['piexpirytime'] = &$this->piexpirytime;

		// verifiedtime
		$this->verifiedtime = new DbField('userpi', 'userpi', 'x_verifiedtime', 'verifiedtime', '`verifiedtime`', CastDateFieldForLike("`verifiedtime`", 1, "DB"), 135, 19, 1, FALSE, '`verifiedtime`', FALSE, FALSE, FALSE, 'FORMATTED TEXT', 'TEXT');
		$this->verifiedtime->Sortable = TRUE; // Allow sort
		$this->verifiedtime->DefaultErrorMessage = str_replace("%s", $GLOBALS["DATE_FORMAT"], $Language->phrase("IncorrectDate"));
		$this->fields['verifiedtime'] = &$this->verifiedtime;

		// vaultid
		$this->vaultid = new DbField('userpi', 'userpi', 'x_vaultid', 'vaultid', '`vaultid`', '`vaultid`', 3, 2, -1, FALSE, '`vaultid`', FALSE, FALSE, FALSE, 'FORMATTED TEXT', 'SELECT');
		$this->vaultid->Nullable = FALSE; // NOT NULL field
		$this->vaultid->Required = TRUE; // Required field
		$this->vaultid->Sortable = TRUE; // Allow sort
		$this->vaultid->UsePleaseSelect = TRUE; // Use PleaseSelect by default
		$this->vaultid->PleaseSelectText = $Language->phrase("PleaseSelect"); // "PleaseSelect" text
		$this->vaultid->Lookup = new Lookup('vaultid', 'vault', FALSE, 'vaultid', ["modulename","","",""], [], [], [], [], [], [], '', '');
		$this->vaultid->DefaultErrorMessage = $Language->phrase("IncorrectInteger");
		$this->fields['vaultid'] = &$this->vaultid;

		// defaultpi
		$this->defaultpi = new DbField('userpi', 'userpi', 'x_defaultpi', 'defaultpi', '`defaultpi`', '`defaultpi`', 3, 1, -1, FALSE, '`defaultpi`', FALSE, FALSE, FALSE, 'FORMATTED TEXT', 'RADIO');
		$this->defaultpi->Nullable = FALSE; // NOT NULL field
		$this->defaultpi->Required = TRUE; // Required field
		$this->defaultpi->Sortable = TRUE; // Allow sort
		$this->defaultpi->Lookup = new Lookup('defaultpi', 'booleanvalues', FALSE, 'id', ["NAME","","",""], [], [], [], [], [], [], '', '');
		$this->defaultpi->DefaultErrorMessage = $Language->phrase("IncorrectInteger");
		$this->fields['defaultpi'] = &$this->defaultpi;

		// acctID
		$this->acctID = new DbField('userpi', 'userpi', 'x_acctID', 'acctID', '`acctID`', '`acctID`', 20, 12, -1, FALSE, '`acctID`', FALSE, FALSE, FALSE, 'FORMATTED TEXT', 'TEXT');
		$this->acctID->Nullable = FALSE; // NOT NULL field
		$this->acctID->Sortable = TRUE; // Allow sort
		$this->acctID->DefaultErrorMessage = $Language->phrase("IncorrectInteger");
		$this->fields['acctID'] = &$this->acctID;

		// addedbyuserid
		$this->addedbyuserid = new DbField('userpi', 'userpi', 'x_addedbyuserid', 'addedbyuserid', '`addedbyuserid`', '`addedbyuserid`', 3, 12, -1, FALSE, '`addedbyuserid`', FALSE, FALSE, FALSE, 'FORMATTED TEXT', 'TEXT');
		$this->addedbyuserid->Nullable = FALSE; // NOT NULL field
		$this->addedbyuserid->Sortable = TRUE; // Allow sort
		$this->addedbyuserid->DefaultErrorMessage = $Language->phrase("IncorrectInteger");
		$this->fields['addedbyuserid'] = &$this->addedbyuserid;

		// pendingtransfer
		$this->pendingtransfer = new DbField('userpi', 'userpi', 'x_pendingtransfer', 'pendingtransfer', '`pendingtransfer`', '`pendingtransfer`', 3, 1, -1, FALSE, '`pendingtransfer`', FALSE, FALSE, FALSE, 'FORMATTED TEXT', 'SELECT');
		$this->pendingtransfer->Nullable = FALSE; // NOT NULL field
		$this->pendingtransfer->Sortable = TRUE; // Allow sort
		$this->pendingtransfer->UsePleaseSelect = TRUE; // Use PleaseSelect by default
		$this->pendingtransfer->PleaseSelectText = $Language->phrase("PleaseSelect"); // "PleaseSelect" text
		$this->pendingtransfer->Lookup = new Lookup('pendingtransfer', 'vdualstatus', FALSE, 'statusID', ["label","","",""], [], [], [], [], [], [], '', '');
		$this->pendingtransfer->DefaultErrorMessage = $Language->phrase("IncorrectInteger");
		$this->fields['pendingtransfer'] = &$this->pendingtransfer;

		// sensitivedataid
		$this->sensitivedataid = new DbField('userpi', 'userpi', 'x_sensitivedataid', 'sensitivedataid', '`sensitivedataid`', '`sensitivedataid`', 20, 12, -1, FALSE, '`sensitivedataid`', FALSE, FALSE, FALSE, 'FORMATTED TEXT', 'TEXT');
		$this->sensitivedataid->Nullable = FALSE; // NOT NULL field
		$this->sensitivedataid->Sortable = FALSE; // Allow sort
		$this->sensitivedataid->DefaultErrorMessage = $Language->phrase("IncorrectInteger");
		$this->fields['sensitivedataid'] = &$this->sensitivedataid;

		// purchaseid
		$this->purchaseid = new DbField('userpi', 'userpi', 'x_purchaseid', 'purchaseid', '`purchaseid`', '`purchaseid`', 20, 12, -1, FALSE, '`purchaseid`', FALSE, FALSE, FALSE, 'FORMATTED TEXT', 'TEXT');
		$this->purchaseid->Nullable = FALSE; // NOT NULL field
		$this->purchaseid->Sortable = TRUE; // Allow sort
		$this->purchaseid->DefaultErrorMessage = $Language->phrase("IncorrectInteger");
		$this->fields['purchaseid'] = &$this->purchaseid;

		// paymentid
		$this->paymentid = new DbField('userpi', 'userpi', 'x_paymentid', 'paymentid', '`paymentid`', '`paymentid`', 20, 12, -1, FALSE, '`paymentid`', FALSE, FALSE, FALSE, 'FORMATTED TEXT', 'TEXT');
		$this->paymentid->Nullable = FALSE; // NOT NULL field
		$this->paymentid->Sortable = TRUE; // Allow sort
		$this->paymentid->DefaultErrorMessage = $Language->phrase("IncorrectInteger");
		$this->fields['paymentid'] = &$this->paymentid;

		// others
		$this->others = new DbField('userpi', 'userpi', 'x_others', 'others', '`others`', '`others`', 201, 1000, -1, FALSE, '`others`', FALSE, FALSE, FALSE, 'FORMATTED TEXT', 'TEXTAREA');
		$this->others->Sortable = TRUE; // Allow sort
		$this->fields['others'] = &$this->others;

		// others2
		$this->others2 = new DbField('userpi', 'userpi', 'x_others2', 'others2', '`others2`', '`others2`', 201, 1000, -1, FALSE, '`others2`', FALSE, FALSE, FALSE, 'FORMATTED TEXT', 'TEXTAREA');
		$this->others2->Sortable = TRUE; // Allow sort
		$this->fields['others2'] = &$this->others2;

		// pinhash
		$this->pinhash = new DbField('userpi', 'userpi', 'x_pinhash', 'pinhash', '`pinhash`', '`pinhash`', 200, 200, -1, FALSE, '`pinhash`', FALSE, FALSE, FALSE, 'FORMATTED TEXT', 'PASSWORD');
		$this->pinhash->Sortable = TRUE; // Allow sort
		$this->fields['pinhash'] = &$this->pinhash;

		// pinexpiry
		$this->pinexpiry = new DbField('userpi', 'userpi', 'x_pinexpiry', 'pinexpiry', '`pinexpiry`', CastDateFieldForLike("`pinexpiry`", 0, "DB"), 133, 10, 0, FALSE, '`pinexpiry`', FALSE, FALSE, FALSE, 'FORMATTED TEXT', 'TEXT');
		$this->pinexpiry->Sortable = TRUE; // Allow sort
		$this->pinexpiry->DefaultErrorMessage = str_replace("%s", $GLOBALS["DATE_FORMAT"], $Language->phrase("IncorrectDate"));
		$this->fields['pinexpiry'] = &$this->pinexpiry;

		// deletiontime
		$this->deletiontime = new DbField('userpi', 'userpi', 'x_deletiontime', 'deletiontime', '`deletiontime`', CastDateFieldForLike("`deletiontime`", 2, "DB"), 135, 19, 2, FALSE, '`deletiontime`', FALSE, FALSE, FALSE, 'FORMATTED TEXT', 'TEXT');
		$this->deletiontime->Sortable = TRUE; // Allow sort
		$this->deletiontime->DefaultErrorMessage = str_replace("%s", $GLOBALS["DATE_FORMAT"], $Language->phrase("IncorrectDate"));
		$this->fields['deletiontime'] = &$this->deletiontime;

		// servicefeeexempted
		$this->servicefeeexempted = new DbField('userpi', 'userpi', 'x_servicefeeexempted', 'servicefeeexempted', '`servicefeeexempted`', '`servicefeeexempted`', 3, 1, -1, FALSE, '`servicefeeexempted`', FALSE, FALSE, FALSE, 'FORMATTED TEXT', 'SELECT');
		$this->servicefeeexempted->Nullable = FALSE; // NOT NULL field
		$this->servicefeeexempted->Sortable = TRUE; // Allow sort
		$this->servicefeeexempted->UsePleaseSelect = TRUE; // Use PleaseSelect by default
		$this->servicefeeexempted->PleaseSelectText = $Language->phrase("PleaseSelect"); // "PleaseSelect" text
		$this->servicefeeexempted->Lookup = new Lookup('servicefeeexempted', 'vdualstatus', FALSE, 'statusID', ["label","","",""], [], [], [], [], [], [], '', '');
		$this->servicefeeexempted->DefaultErrorMessage = $Language->phrase("IncorrectInteger");
		$this->fields['servicefeeexempted'] = &$this->servicefeeexempted;

		// purposeofaccount
		$this->purposeofaccount = new DbField('userpi', 'userpi', 'x_purposeofaccount', 'purposeofaccount', '`purposeofaccount`', '`purposeofaccount`', 200, 3, -1, FALSE, '`purposeofaccount`', FALSE, FALSE, FALSE, 'FORMATTED TEXT', 'SELECT');
		$this->purposeofaccount->Sortable = TRUE; // Allow sort
		$this->purposeofaccount->UsePleaseSelect = TRUE; // Use PleaseSelect by default
		$this->purposeofaccount->PleaseSelectText = $Language->phrase("PleaseSelect"); // "PleaseSelect" text
		$this->purposeofaccount->Lookup = new Lookup('purposeofaccount', 'pipurpose', FALSE, 'typeID', ["name","","",""], [], [], [], [], [], [], '', '');
		$this->fields['purposeofaccount'] = &$this->purposeofaccount;

		// extendedfields
		$this->extendedfields = new DbField('userpi', 'userpi', 'x_extendedfields', 'extendedfields', '`extendedfields`', '`extendedfields`', 201, 0, -1, FALSE, '`extendedfields`', FALSE, FALSE, FALSE, 'FORMATTED TEXT', 'TEXTAREA');
		$this->extendedfields->Sortable = TRUE; // Allow sort
		$this->fields['extendedfields'] = &$this->extendedfields;
	}

	// Field Visibility
	public function getFieldVisibility($fldParm)
	{
		global $Security;
		return $this->$fldParm->Visible; // Returns original value
	}

	// Set left column class (must be predefined col-*-* classes of Bootstrap grid system)
	function setLeftColumnClass($class)
	{
		if (preg_match('/^col\-(\w+)\-(\d+)$/', $class, $match)) {
			$this->LeftColumnClass = $class . " col-form-label ew-label";
			$this->RightColumnClass = "col-" . $match[1] . "-" . strval(12 - (int)$match[2]);
			$this->OffsetColumnClass = $this->RightColumnClass . " " . str_replace("col-", "offset-", $class);
			$this->TableLeftColumnClass = preg_replace('/^col-\w+-(\d+)$/', "w-col-$1", $class); // Change to w-col-*
		}
	}

	// Single column sort
	public function updateSort(&$fld)
	{
		if ($this->CurrentOrder == $fld->Name) {
			$sortField = $fld->Expression;
			$lastSort = $fld->getSort();
			if ($this->CurrentOrderType == "ASC" || $this->CurrentOrderType == "DESC") {
				$thisSort = $this->CurrentOrderType;
			} else {
				$thisSort = ($lastSort == "ASC") ? "DESC" : "ASC";
			}
			$fld->setSort($thisSort);
			$this->setSessionOrderBy($sortField . " " . $thisSort); // Save to Session
		} else {
			$fld->setSort("");
		}
	}

	// Current master table name
	public function getCurrentMasterTable()
	{
		return @$_SESSION[PROJECT_NAME . "_" . $this->TableVar . "_" . Config("TABLE_MASTER_TABLE")];
	}
	public function setCurrentMasterTable($v)
	{
		$_SESSION[PROJECT_NAME . "_" . $this->TableVar . "_" . Config("TABLE_MASTER_TABLE")] = $v;
	}

	// Session master WHERE clause
	public function getMasterFilter()
	{

		// Master filter
		$masterFilter = "";
		if ($this->getCurrentMasterTable() == "user") {
			if ($this->_userid->getSessionValue() != "")
				$masterFilter .= "`id`=" . QuotedValue($this->_userid->getSessionValue(), DATATYPE_NUMBER, "DB");
			else
				return "";
		}
		return $masterFilter;
	}

	// Session detail WHERE clause
	public function getDetailFilter()
	{

		// Detail filter
		$detailFilter = "";
		if ($this->getCurrentMasterTable() == "user") {
			if ($this->_userid->getSessionValue() != "")
				$detailFilter .= "`userid`=" . QuotedValue($this->_userid->getSessionValue(), DATATYPE_NUMBER, "DB");
			else
				return "";
		}
		return $detailFilter;
	}

	// Master filter
	public function sqlMasterFilter_user()
	{
		return "`id`=@id@";
	}

	// Detail filter
	public function sqlDetailFilter_user()
	{
		return "`userid`=@_userid@";
	}

	// Current detail table name
	public function getCurrentDetailTable()
	{
		return @$_SESSION[PROJECT_NAME . "_" . $this->TableVar . "_" . Config("TABLE_DETAIL_TABLE")];
	}
	public function setCurrentDetailTable($v)
	{
		$_SESSION[PROJECT_NAME . "_" . $this->TableVar . "_" . Config("TABLE_DETAIL_TABLE")] = $v;
	}

	// Get detail url
	public function getDetailUrl()
	{

		// Detail url
		$detailUrl = "";
		if ($this->getCurrentDetailTable() == "feehistory") {
			$detailUrl = $GLOBALS["feehistory"]->getListUrl() . "?" . Config("TABLE_SHOW_MASTER") . "=" . $this->TableVar;
			$detailUrl .= "&fk_id=" . urlencode($this->id->CurrentValue);
		}
		if ($this->getCurrentDetailTable() == "useritem") {
			$detailUrl = $GLOBALS["useritem"]->getListUrl() . "?" . Config("TABLE_SHOW_MASTER") . "=" . $this->TableVar;
			$detailUrl .= "&fk_id=" . urlencode($this->id->CurrentValue);
		}
		if ($detailUrl == "")
			$detailUrl = "userpilist.php";
		return $detailUrl;
	}

	// Table level SQL
	public function getSqlFrom() // From
	{
		return ($this->SqlFrom != "") ? $this->SqlFrom : "`userpi`";
	}
	public function sqlFrom() // For backward compatibility
	{
		return $this->getSqlFrom();
	}
	public function setSqlFrom($v)
	{
		$this->SqlFrom = $v;
	}
	public function getSqlSelect() // Select
	{
		return ($this->SqlSelect != "") ? $this->SqlSelect : "SELECT * FROM " . $this->getSqlFrom();
	}
	public function sqlSelect() // For backward compatibility
	{
		return $this->getSqlSelect();
	}
	public function setSqlSelect($v)
	{
		$this->SqlSelect = $v;
	}
	public function getSqlWhere() // Where
	{
		$where = ($this->SqlWhere != "") ? $this->SqlWhere : "";
		$this->TableFilter = "";
		AddFilter($where, $this->TableFilter);
		return $where;
	}
	public function sqlWhere() // For backward compatibility
	{
		return $this->getSqlWhere();
	}
	public function setSqlWhere($v)
	{
		$this->SqlWhere = $v;
	}
	public function getSqlGroupBy() // Group By
	{
		return ($this->SqlGroupBy != "") ? $this->SqlGroupBy : "";
	}
	public function sqlGroupBy() // For backward compatibility
	{
		return $this->getSqlGroupBy();
	}
	public function setSqlGroupBy($v)
	{
		$this->SqlGroupBy = $v;
	}
	public function getSqlHaving() // Having
	{
		return ($this->SqlHaving != "") ? $this->SqlHaving : "";
	}
	public function sqlHaving() // For backward compatibility
	{
		return $this->getSqlHaving();
	}
	public function setSqlHaving($v)
	{
		$this->SqlHaving = $v;
	}
	public function getSqlOrderBy() // Order By
	{
		return ($this->SqlOrderBy != "") ? $this->SqlOrderBy : "";
	}
	public function sqlOrderBy() // For backward compatibility
	{
		return $this->getSqlOrderBy();
	}
	public function setSqlOrderBy($v)
	{
		$this->SqlOrderBy = $v;
	}

	// Apply User ID filters
	public function applyUserIDFilters($filter, $id = "")
	{
		return $filter;
	}

	// Check if User ID security allows view all
	public function userIDAllow($id = "")
	{
		$allow = $this->UserIDAllowSecurity;
		switch ($id) {
			case "add":
			case "copy":
			case "gridadd":
			case "register":
			case "addopt":
				return (($allow & 1) == 1);
			case "edit":
			case "gridedit":
			case "update":
			case "changepwd":
			case "forgotpwd":
				return (($allow & 4) == 4);
			case "delete":
				return (($allow & 2) == 2);
			case "view":
				return (($allow & 32) == 32);
			case "search":
				return (($allow & 64) == 64);
			case "lookup":
				return (($allow & 256) == 256);
			default:
				return (($allow & 8) == 8);
		}
	}

	// Get recordset
	public function getRecordset($sql, $rowcnt = -1, $offset = -1)
	{
		$conn = $this->getConnection();
		$conn->raiseErrorFn = Config("ERROR_FUNC");
		$rs = $conn->selectLimit($sql, $rowcnt, $offset);
		$conn->raiseErrorFn = "";
		return $rs;
	}

	// Get record count
	public function getRecordCount($sql, $c = NULL)
	{
		$cnt = -1;
		$rs = NULL;
		$sql = preg_replace('/\/\*BeginOrderBy\*\/[\s\S]+\/\*EndOrderBy\*\//', "", $sql); // Remove ORDER BY clause (MSSQL)
		$pattern = '/^SELECT\s([\s\S]+)\sFROM\s/i';

		// Skip Custom View / SubQuery / SELECT DISTINCT / ORDER BY
		if (($this->TableType == 'TABLE' || $this->TableType == 'VIEW' || $this->TableType == 'LINKTABLE') &&
			preg_match($pattern, $sql) && !preg_match('/\(\s*(SELECT[^)]+)\)/i', $sql) &&
			!preg_match('/^\s*select\s+distinct\s+/i', $sql) && !preg_match('/\s+order\s+by\s+/i', $sql)) {
			$sqlwrk = "SELECT COUNT(*) FROM " . preg_replace($pattern, "", $sql);
		} else {
			$sqlwrk = "SELECT COUNT(*) FROM (" . $sql . ") COUNT_TABLE";
		}
		$conn = $c ?: $this->getConnection();
		if ($rs = $conn->execute($sqlwrk)) {
			if (!$rs->EOF && $rs->FieldCount() > 0) {
				$cnt = $rs->fields[0];
				$rs->close();
			}
			return (int)$cnt;
		}

		// Unable to get count, get record count directly
		if ($rs = $conn->execute($sql)) {
			$cnt = $rs->RecordCount();
			$rs->close();
			return (int)$cnt;
		}
		return $cnt;
	}

	// Get SQL
	public function getSql($where, $orderBy = "")
	{
		return BuildSelectSql($this->getSqlSelect(), $this->getSqlWhere(),
			$this->getSqlGroupBy(), $this->getSqlHaving(), $this->getSqlOrderBy(),
			$where, $orderBy);
	}

	// Table SQL
	public function getCurrentSql()
	{
		$filter = $this->CurrentFilter;
		$filter = $this->applyUserIDFilters($filter);
		$sort = $this->getSessionOrderBy();
		return $this->getSql($filter, $sort);
	}

	// Table SQL with List page filter
	public function getListSql()
	{
		$filter = $this->UseSessionForListSql ? $this->getSessionWhere() : "";
		AddFilter($filter, $this->CurrentFilter);
		$filter = $this->applyUserIDFilters($filter);
		$this->Recordset_Selecting($filter);
		$select = $this->getSqlSelect();
		$sort = $this->UseSessionForListSql ? $this->getSessionOrderBy() : "";
		return BuildSelectSql($select, $this->getSqlWhere(), $this->getSqlGroupBy(),
			$this->getSqlHaving(), $this->getSqlOrderBy(), $filter, $sort);
	}

	// Get ORDER BY clause
	public function getOrderBy()
	{
		$sort = $this->getSessionOrderBy();
		return BuildSelectSql("", "", "", "", $this->getSqlOrderBy(), "", $sort);
	}

	// Get record count based on filter (for detail record count in master table pages)
	public function loadRecordCount($filter)
	{
		$origFilter = $this->CurrentFilter;
		$this->CurrentFilter = $filter;
		$this->Recordset_Selecting($this->CurrentFilter);
		$select = $this->TableType == 'CUSTOMVIEW' ? $this->getSqlSelect() : "SELECT * FROM " . $this->getSqlFrom();
		$groupBy = $this->TableType == 'CUSTOMVIEW' ? $this->getSqlGroupBy() : "";
		$having = $this->TableType == 'CUSTOMVIEW' ? $this->getSqlHaving() : "";
		$sql = BuildSelectSql($select, $this->getSqlWhere(), $groupBy, $having, "", $this->CurrentFilter, "");
		$cnt = $this->getRecordCount($sql);
		$this->CurrentFilter = $origFilter;
		return $cnt;
	}

	// Get record count (for current List page)
	public function listRecordCount()
	{
		$filter = $this->getSessionWhere();
		AddFilter($filter, $this->CurrentFilter);
		$filter = $this->applyUserIDFilters($filter);
		$this->Recordset_Selecting($filter);
		$select = $this->TableType == 'CUSTOMVIEW' ? $this->getSqlSelect() : "SELECT * FROM " . $this->getSqlFrom();
		$groupBy = $this->TableType == 'CUSTOMVIEW' ? $this->getSqlGroupBy() : "";
		$having = $this->TableType == 'CUSTOMVIEW' ? $this->getSqlHaving() : "";
		$sql = BuildSelectSql($select, $this->getSqlWhere(), $groupBy, $having, "", $filter, "");
		$cnt = $this->getRecordCount($sql);
		return $cnt;
	}

	// INSERT statement
	protected function insertSql(&$rs)
	{
		$names = "";
		$values = "";
		foreach ($rs as $name => $value) {
			if (!isset($this->fields[$name]) || $this->fields[$name]->IsCustom)
				continue;
			$names .= $this->fields[$name]->Expression . ",";
			$values .= QuotedValue($value, $this->fields[$name]->DataType, $this->Dbid) . ",";
		}
		$names = preg_replace('/,+$/', "", $names);
		$values = preg_replace('/,+$/', "", $values);
		return "INSERT INTO " . $this->UpdateTable . " (" . $names . ") VALUES (" . $values . ")";
	}

	// Insert
	public function insert(&$rs)
	{
		$conn = $this->getConnection();
		$success = $conn->execute($this->insertSql($rs));
		if ($success) {

			// Get insert id if necessary
			$this->id->setDbValue($conn->insert_ID());
			$rs['id'] = $this->id->DbValue;
			if ($this->AuditTrailOnAdd)
				$this->writeAuditTrailOnAdd($rs);
		}
		return $success;
	}

	// UPDATE statement
	protected function updateSql(&$rs, $where = "", $curfilter = TRUE)
	{
		$sql = "UPDATE " . $this->UpdateTable . " SET ";
		foreach ($rs as $name => $value) {
			if (!isset($this->fields[$name]) || $this->fields[$name]->IsCustom || $this->fields[$name]->IsAutoIncrement)
				continue;
			$sql .= $this->fields[$name]->Expression . "=";
			$sql .= QuotedValue($value, $this->fields[$name]->DataType, $this->Dbid) . ",";
		}
		$sql = preg_replace('/,+$/', "", $sql);
		$filter = ($curfilter) ? $this->CurrentFilter : "";
		if (is_array($where))
			$where = $this->arrayToFilter($where);
		AddFilter($filter, $where);
		if ($filter != "")
			$sql .= " WHERE " . $filter;
		return $sql;
	}

	// Update
	public function update(&$rs, $where = "", $rsold = NULL, $curfilter = TRUE)
	{
		$conn = $this->getConnection();

		// Cascade Update detail table 'feehistory'
		$cascadeUpdate = FALSE;
		$rscascade = [];
		if ($rsold && (isset($rs['id']) && $rsold['id'] != $rs['id'])) { // Update detail field 'userpi'
			$cascadeUpdate = TRUE;
			$rscascade['userpi'] = $rs['id'];
		}
		if ($cascadeUpdate) {
			if (!isset($GLOBALS["feehistory"]))
				$GLOBALS["feehistory"] = new feehistory();
			$rswrk = $GLOBALS["feehistory"]->loadRs("`userpi` = " . QuotedValue($rsold['id'], DATATYPE_NUMBER, 'DB'));
			while ($rswrk && !$rswrk->EOF) {
				$rskey = [];
				$fldname = 'userpi';
				$rskey[$fldname] = $rswrk->fields[$fldname];
				$fldname = 'feedate';
				$rskey[$fldname] = $rswrk->fields[$fldname];
				$fldname = 'transtype';
				$rskey[$fldname] = $rswrk->fields[$fldname];
				$rsdtlold = &$rswrk->fields;
				$rsdtlnew = array_merge($rsdtlold, $rscascade);

				// Call Row_Updating event
				$success = $GLOBALS["feehistory"]->Row_Updating($rsdtlold, $rsdtlnew);
				if ($success)
					$success = $GLOBALS["feehistory"]->update($rscascade, $rskey, $rswrk->fields);
				if (!$success)
					return FALSE;

				// Call Row_Updated event
				$GLOBALS["feehistory"]->Row_Updated($rsdtlold, $rsdtlnew);
				$rswrk->moveNext();
			}
		}
		$success = $conn->execute($this->updateSql($rs, $where, $curfilter));
		if ($success && $this->AuditTrailOnEdit && $rsold) {
			$rsaudit = $rs;
			$fldname = 'id';
			if (!array_key_exists($fldname, $rsaudit))
				$rsaudit[$fldname] = $rsold[$fldname];
			$this->writeAuditTrailOnEdit($rsold, $rsaudit);
		}
		return $success;
	}

	// DELETE statement
	protected function deleteSql(&$rs, $where = "", $curfilter = TRUE)
	{
		$sql = "DELETE FROM " . $this->UpdateTable . " WHERE ";
		if (is_array($where))
			$where = $this->arrayToFilter($where);
		if ($rs) {
			if (array_key_exists('id', $rs))
				AddFilter($where, QuotedName('id', $this->Dbid) . '=' . QuotedValue($rs['id'], $this->id->DataType, $this->Dbid));
		}
		$filter = ($curfilter) ? $this->CurrentFilter : "";
		AddFilter($filter, $where);
		if ($filter != "")
			$sql .= $filter;
		else
			$sql .= "0=1"; // Avoid delete
		return $sql;
	}

	// Delete
	public function delete(&$rs, $where = "", $curfilter = FALSE)
	{
		$success = TRUE;
		$conn = $this->getConnection();

		// Cascade delete detail table 'feehistory'
		if (!isset($GLOBALS["feehistory"]))
			$GLOBALS["feehistory"] = new feehistory();
		$rscascade = $GLOBALS["feehistory"]->loadRs("`userpi` = " . QuotedValue($rs['id'], DATATYPE_NUMBER, "DB"));
		$dtlrows = ($rscascade) ? $rscascade->getRows() : [];

		// Call Row Deleting event
		foreach ($dtlrows as $dtlrow) {
			$success = $GLOBALS["feehistory"]->Row_Deleting($dtlrow);
			if (!$success)
				break;
		}
		if ($success) {
			foreach ($dtlrows as $dtlrow) {
				$success = $GLOBALS["feehistory"]->delete($dtlrow); // Delete
				if (!$success)
					break;
			}
		}

		// Call Row Deleted event
		if ($success) {
			foreach ($dtlrows as $dtlrow)
				$GLOBALS["feehistory"]->Row_Deleted($dtlrow);
		}
		if ($success)
			$success = $conn->execute($this->deleteSql($rs, $where, $curfilter));
		if ($success && $this->AuditTrailOnDelete)
			$this->writeAuditTrailOnDelete($rs);
		return $success;
	}

	// Load DbValue from recordset or array
	protected function loadDbValues(&$rs)
	{
		if (!$rs || !is_array($rs) && $rs->EOF)
			return;
		$row = is_array($rs) ? $rs : $rs->fields;
		$this->id->DbValue = $row['id'];
		$this->_userid->DbValue = $row['userid'];
		$this->tokenid->DbValue = $row['tokenid'];
		$this->cardno->DbValue = $row['cardno'];
		$this->lastupdated->DbValue = $row['lastupdated'];
		$this->piid->DbValue = $row['piid'];
		$this->deleted->DbValue = $row['deleted'];
		$this->currcode->DbValue = $row['currcode'];
		$this->friendlyname->DbValue = $row['friendlyname'];
		$this->_key->DbValue = $row['key'];
		$this->verified->DbValue = $row['verified'];
		$this->addeddatetime->DbValue = $row['addeddatetime'];
		$this->piexpirytime->DbValue = $row['piexpirytime'];
		$this->verifiedtime->DbValue = $row['verifiedtime'];
		$this->vaultid->DbValue = $row['vaultid'];
		$this->defaultpi->DbValue = $row['defaultpi'];
		$this->acctID->DbValue = $row['acctID'];
		$this->addedbyuserid->DbValue = $row['addedbyuserid'];
		$this->pendingtransfer->DbValue = $row['pendingtransfer'];
		$this->sensitivedataid->DbValue = $row['sensitivedataid'];
		$this->purchaseid->DbValue = $row['purchaseid'];
		$this->paymentid->DbValue = $row['paymentid'];
		$this->others->DbValue = $row['others'];
		$this->others2->DbValue = $row['others2'];
		$this->pinhash->DbValue = $row['pinhash'];
		$this->pinexpiry->DbValue = $row['pinexpiry'];
		$this->deletiontime->DbValue = $row['deletiontime'];
		$this->servicefeeexempted->DbValue = $row['servicefeeexempted'];
		$this->purposeofaccount->DbValue = $row['purposeofaccount'];
		$this->extendedfields->DbValue = $row['extendedfields'];
	}

	// Delete uploaded files
	public function deleteUploadedFiles($row)
	{
		$this->loadDbValues($row);
	}

	// Record filter WHERE clause
	protected function sqlKeyFilter()
	{
		return "`id` = @id@";
	}

	// Get record filter
	public function getRecordFilter($row = NULL)
	{
		$keyFilter = $this->sqlKeyFilter();
		if (is_array($row))
			$val = array_key_exists('id', $row) ? $row['id'] : NULL;
		else
			$val = $this->id->OldValue !== NULL ? $this->id->OldValue : $this->id->CurrentValue;
		if (!is_numeric($val))
			return "0=1"; // Invalid key
		if ($val == NULL)
			return "0=1"; // Invalid key
		else
			$keyFilter = str_replace("@id@", AdjustSql($val, $this->Dbid), $keyFilter); // Replace key value
		return $keyFilter;
	}

	// Return page URL
	public function getReturnUrl()
	{
		$name = PROJECT_NAME . "_" . $this->TableVar . "_" . Config("TABLE_RETURN_URL");

		// Get referer URL automatically
		if (ServerVar("HTTP_REFERER") != "" && ReferPageName() != CurrentPageName() && ReferPageName() != "login.php") // Referer not same page or login page
			$_SESSION[$name] = ServerVar("HTTP_REFERER"); // Save to Session
		if (@$_SESSION[$name] != "") {
			return $_SESSION[$name];
		} else {
			return "userpilist.php";
		}
	}
	public function setReturnUrl($v)
	{
		$_SESSION[PROJECT_NAME . "_" . $this->TableVar . "_" . Config("TABLE_RETURN_URL")] = $v;
	}

	// Get modal caption
	public function getModalCaption($pageName)
	{
		global $Language;
		if ($pageName == "userpiview.php")
			return $Language->phrase("View");
		elseif ($pageName == "userpiedit.php")
			return $Language->phrase("Edit");
		elseif ($pageName == "userpiadd.php")
			return $Language->phrase("Add");
		else
			return "";
	}

	// List URL
	public function getListUrl()
	{
		return "userpilist.php";
	}

	// View URL
	public function getViewUrl($parm = "")
	{
		if ($parm != "")
			$url = $this->keyUrl("userpiview.php", $this->getUrlParm($parm));
		else
			$url = $this->keyUrl("userpiview.php", $this->getUrlParm(Config("TABLE_SHOW_DETAIL") . "="));
		return $this->addMasterUrl($url);
	}

	// Add URL
	public function getAddUrl($parm = "")
	{
		if ($parm != "")
			$url = "userpiadd.php?" . $this->getUrlParm($parm);
		else
			$url = "userpiadd.php";
		return $this->addMasterUrl($url);
	}

	// Edit URL
	public function getEditUrl($parm = "")
	{
		if ($parm != "")
			$url = $this->keyUrl("userpiedit.php", $this->getUrlParm($parm));
		else
			$url = $this->keyUrl("userpiedit.php", $this->getUrlParm(Config("TABLE_SHOW_DETAIL") . "="));
		return $this->addMasterUrl($url);
	}

	// Inline edit URL
	public function getInlineEditUrl()
	{
		$url = $this->keyUrl(CurrentPageName(), $this->getUrlParm("action=edit"));
		return $this->addMasterUrl($url);
	}

	// Copy URL
	public function getCopyUrl($parm = "")
	{
		if ($parm != "")
			$url = $this->keyUrl("userpiadd.php", $this->getUrlParm($parm));
		else
			$url = $this->keyUrl("userpiadd.php", $this->getUrlParm(Config("TABLE_SHOW_DETAIL") . "="));
		return $this->addMasterUrl($url);
	}

	// Inline copy URL
	public function getInlineCopyUrl()
	{
		$url = $this->keyUrl(CurrentPageName(), $this->getUrlParm("action=copy"));
		return $this->addMasterUrl($url);
	}

	// Delete URL
	public function getDeleteUrl()
	{
		return $this->keyUrl("userpidelete.php", $this->getUrlParm());
	}

	// Add master url
	public function addMasterUrl($url)
	{
		if ($this->getCurrentMasterTable() == "user" && !ContainsString($url, Config("TABLE_SHOW_MASTER") . "=")) {
			$url .= (ContainsString($url, "?") ? "&" : "?") . Config("TABLE_SHOW_MASTER") . "=" . $this->getCurrentMasterTable();
			$url .= "&fk_id=" . urlencode($this->_userid->CurrentValue);
		}
		return $url;
	}
	public function keyToJson($htmlEncode = FALSE)
	{
		$json = "";
		$json .= "id:" . JsonEncode($this->id->CurrentValue, "number");
		$json = "{" . $json . "}";
		if ($htmlEncode)
			$json = HtmlEncode($json);
		return $json;
	}

	// Add key value to URL
	public function keyUrl($url, $parm = "")
	{
		$url = $url . "?";
		if ($parm != "")
			$url .= $parm . "&";
		if ($this->id->CurrentValue != NULL) {
			$url .= "id=" . urlencode($this->id->CurrentValue);
		} else {
			return "javascript:ew.alert(ew.language.phrase('InvalidRecord'));";
		}
		return $url;
	}

	// Sort URL
	public function sortUrl(&$fld)
	{
		if ($this->CurrentAction || $this->isExport() ||
			in_array($fld->Type, [128, 204, 205])) { // Unsortable data type
				return "";
		} elseif ($fld->Sortable) {
			$urlParm = $this->getUrlParm("order=" . urlencode($fld->Name) . "&amp;ordertype=" . $fld->reverseSort());
			return $this->addMasterUrl(CurrentPageName() . "?" . $urlParm);
		} else {
			return "";
		}
	}

	// Get record keys from Post/Get/Session
	public function getRecordKeys()
	{
		$arKeys = [];
		$arKey = [];
		if (Param("key_m") !== NULL) {
			$arKeys = Param("key_m");
			$cnt = count($arKeys);
		} else {
			if (Param("id") !== NULL)
				$arKeys[] = Param("id");
			elseif (IsApi() && Key(0) !== NULL)
				$arKeys[] = Key(0);
			elseif (IsApi() && Route(2) !== NULL)
				$arKeys[] = Route(2);
			else
				$arKeys = NULL; // Do not setup

			//return $arKeys; // Do not return yet, so the values will also be checked by the following code
		}

		// Check keys
		$ar = [];
		if (is_array($arKeys)) {
			foreach ($arKeys as $key) {
				if (!is_numeric($key))
					continue;
				$ar[] = $key;
			}
		}
		return $ar;
	}

	// Get filter from record keys
	public function getFilterFromRecordKeys($setCurrent = TRUE)
	{
		$arKeys = $this->getRecordKeys();
		$keyFilter = "";
		foreach ($arKeys as $key) {
			if ($keyFilter != "") $keyFilter .= " OR ";
			if ($setCurrent)
				$this->id->CurrentValue = $key;
			else
				$this->id->OldValue = $key;
			$keyFilter .= "(" . $this->getRecordFilter() . ")";
		}
		return $keyFilter;
	}

	// Load rows based on filter
	public function &loadRs($filter)
	{

		// Set up filter (WHERE Clause)
		$sql = $this->getSql($filter);
		$conn = $this->getConnection();
		$rs = $conn->execute($sql);
		return $rs;
	}

	// Load row values from recordset
	public function loadListRowValues(&$rs)
	{
		$this->id->setDbValue($rs->fields('id'));
		$this->_userid->setDbValue($rs->fields('userid'));
		$this->tokenid->setDbValue($rs->fields('tokenid'));
		$this->cardno->setDbValue($rs->fields('cardno'));
		$this->lastupdated->setDbValue($rs->fields('lastupdated'));
		$this->piid->setDbValue($rs->fields('piid'));
		$this->deleted->setDbValue($rs->fields('deleted'));
		$this->currcode->setDbValue($rs->fields('currcode'));
		$this->friendlyname->setDbValue($rs->fields('friendlyname'));
		$this->_key->setDbValue($rs->fields('key'));
		$this->verified->setDbValue($rs->fields('verified'));
		$this->addeddatetime->setDbValue($rs->fields('addeddatetime'));
		$this->piexpirytime->setDbValue($rs->fields('piexpirytime'));
		$this->verifiedtime->setDbValue($rs->fields('verifiedtime'));
		$this->vaultid->setDbValue($rs->fields('vaultid'));
		$this->defaultpi->setDbValue($rs->fields('defaultpi'));
		$this->acctID->setDbValue($rs->fields('acctID'));
		$this->addedbyuserid->setDbValue($rs->fields('addedbyuserid'));
		$this->pendingtransfer->setDbValue($rs->fields('pendingtransfer'));
		$this->sensitivedataid->setDbValue($rs->fields('sensitivedataid'));
		$this->purchaseid->setDbValue($rs->fields('purchaseid'));
		$this->paymentid->setDbValue($rs->fields('paymentid'));
		$this->others->setDbValue($rs->fields('others'));
		$this->others2->setDbValue($rs->fields('others2'));
		$this->pinhash->setDbValue($rs->fields('pinhash'));
		$this->pinexpiry->setDbValue($rs->fields('pinexpiry'));
		$this->deletiontime->setDbValue($rs->fields('deletiontime'));
		$this->servicefeeexempted->setDbValue($rs->fields('servicefeeexempted'));
		$this->purposeofaccount->setDbValue($rs->fields('purposeofaccount'));
		$this->extendedfields->setDbValue($rs->fields('extendedfields'));
	}

	// Render list row values
	public function renderListRow()
	{
		global $Security, $CurrentLanguage, $Language;

		// Call Row Rendering event
		$this->Row_Rendering();

		// Common render codes
		// id
		// userid
		// tokenid

		$this->tokenid->CellCssStyle = "white-space: nowrap;";

		// cardno
		// lastupdated
		// piid
		// deleted
		// currcode
		// friendlyname
		// key
		// verified
		// addeddatetime
		// piexpirytime
		// verifiedtime
		// vaultid
		// defaultpi
		// acctID
		// addedbyuserid
		// pendingtransfer
		// sensitivedataid

		$this->sensitivedataid->CellCssStyle = "white-space: nowrap;";

		// purchaseid
		// paymentid
		// others
		// others2
		// pinhash
		// pinexpiry
		// deletiontime
		// servicefeeexempted
		// purposeofaccount
		// extendedfields
		// id

		$this->id->ViewValue = $this->id->CurrentValue;
		$this->id->ViewCustomAttributes = "";

		// userid
		$this->_userid->ViewValue = $this->_userid->CurrentValue;
		$this->_userid->ViewCustomAttributes = "";

		// tokenid
		$this->tokenid->ViewValue = $this->tokenid->CurrentValue;
		$this->tokenid->ViewCustomAttributes = "";

		// cardno
		$this->cardno->ViewValue = $this->cardno->CurrentValue;
		$this->cardno->ViewCustomAttributes = "";

		// lastupdated
		$this->lastupdated->ViewValue = $this->lastupdated->CurrentValue;
		$this->lastupdated->ViewValue = FormatDateTime($this->lastupdated->ViewValue, 10);
		$this->lastupdated->ViewCustomAttributes = "";

		// piid
		$curVal = strval($this->piid->CurrentValue);
		if ($curVal != "") {
			$this->piid->ViewValue = $this->piid->lookupCacheOption($curVal);
			if ($this->piid->ViewValue === NULL) { // Lookup from database
				$filterWrk = "`id`" . SearchString("=", $curVal, DATATYPE_NUMBER, "_4payreference");
				$sqlWrk = $this->piid->Lookup->getSql(FALSE, $filterWrk, '', $this);
				$rswrk = Conn("_4payreference")->execute($sqlWrk);
				if ($rswrk && !$rswrk->EOF) { // Lookup values found
					$arwrk = [];
					$arwrk[1] = $rswrk->fields('df');
					$this->piid->ViewValue = $this->piid->displayValue($arwrk);
					$rswrk->Close();
				} else {
					$this->piid->ViewValue = $this->piid->CurrentValue;
				}
			}
		} else {
			$this->piid->ViewValue = NULL;
		}
		$this->piid->ViewCustomAttributes = "";

		// deleted
		if (strval($this->deleted->CurrentValue) != "") {
			$this->deleted->ViewValue = $this->deleted->optionCaption($this->deleted->CurrentValue);
		} else {
			$this->deleted->ViewValue = NULL;
		}
		$this->deleted->ViewCustomAttributes = "";

		// currcode
		$curVal = strval($this->currcode->CurrentValue);
		if ($curVal != "") {
			$this->currcode->ViewValue = $this->currcode->lookupCacheOption($curVal);
			if ($this->currcode->ViewValue === NULL) { // Lookup from database
				$filterWrk = "`currCode`" . SearchString("=", $curVal, DATATYPE_STRING, "_4payreference");
				$sqlWrk = $this->currcode->Lookup->getSql(FALSE, $filterWrk, '', $this);
				$rswrk = Conn("_4payreference")->execute($sqlWrk);
				if ($rswrk && !$rswrk->EOF) { // Lookup values found
					$arwrk = [];
					$arwrk[1] = $rswrk->fields('df');
					$this->currcode->ViewValue = $this->currcode->displayValue($arwrk);
					$rswrk->Close();
				} else {
					$this->currcode->ViewValue = $this->currcode->CurrentValue;
				}
			}
		} else {
			$this->currcode->ViewValue = NULL;
		}
		$this->currcode->ViewCustomAttributes = "";

		// friendlyname
		$this->friendlyname->ViewValue = $this->friendlyname->CurrentValue;
		$this->friendlyname->ViewCustomAttributes = "";

		// key
		$this->_key->ViewValue = $this->_key->CurrentValue;
		$this->_key->ViewCustomAttributes = "";

		// verified
		$curVal = strval($this->verified->CurrentValue);
		if ($curVal != "") {
			$this->verified->ViewValue = $this->verified->lookupCacheOption($curVal);
			if ($this->verified->ViewValue === NULL) { // Lookup from database
				$filterWrk = "`id`" . SearchString("=", $curVal, DATATYPE_NUMBER, "");
				$sqlWrk = $this->verified->Lookup->getSql(FALSE, $filterWrk, '', $this);
				$rswrk = Conn()->execute($sqlWrk);
				if ($rswrk && !$rswrk->EOF) { // Lookup values found
					$arwrk = [];
					$arwrk[1] = $rswrk->fields('df');
					$this->verified->ViewValue = $this->verified->displayValue($arwrk);
					$rswrk->Close();
				} else {
					$this->verified->ViewValue = $this->verified->CurrentValue;
				}
			}
		} else {
			$this->verified->ViewValue = NULL;
		}
		$this->verified->ViewCustomAttributes = "";

		// addeddatetime
		$this->addeddatetime->ViewValue = $this->addeddatetime->CurrentValue;
		$this->addeddatetime->ViewValue = FormatDateTime($this->addeddatetime->ViewValue, 0);
		$this->addeddatetime->ViewCustomAttributes = "";

		// piexpirytime
		$this->piexpirytime->ViewValue = $this->piexpirytime->CurrentValue;
		$this->piexpirytime->ViewValue = FormatDateTime($this->piexpirytime->ViewValue, 1);
		$this->piexpirytime->ViewCustomAttributes = "";

		// verifiedtime
		$this->verifiedtime->ViewValue = $this->verifiedtime->CurrentValue;
		$this->verifiedtime->ViewValue = FormatDateTime($this->verifiedtime->ViewValue, 1);
		$this->verifiedtime->ViewCustomAttributes = "";

		// vaultid
		$curVal = strval($this->vaultid->CurrentValue);
		if ($curVal != "") {
			$this->vaultid->ViewValue = $this->vaultid->lookupCacheOption($curVal);
			if ($this->vaultid->ViewValue === NULL) { // Lookup from database
				$filterWrk = "`vaultid`" . SearchString("=", $curVal, DATATYPE_NUMBER, "_4payreference");
				$sqlWrk = $this->vaultid->Lookup->getSql(FALSE, $filterWrk, '', $this);
				$rswrk = Conn("_4payreference")->execute($sqlWrk);
				if ($rswrk && !$rswrk->EOF) { // Lookup values found
					$arwrk = [];
					$arwrk[1] = $rswrk->fields('df');
					$this->vaultid->ViewValue = $this->vaultid->displayValue($arwrk);
					$rswrk->Close();
				} else {
					$this->vaultid->ViewValue = $this->vaultid->CurrentValue;
				}
			}
		} else {
			$this->vaultid->ViewValue = NULL;
		}
		$this->vaultid->ViewCustomAttributes = "";

		// defaultpi
		$curVal = strval($this->defaultpi->CurrentValue);
		if ($curVal != "") {
			$this->defaultpi->ViewValue = $this->defaultpi->lookupCacheOption($curVal);
			if ($this->defaultpi->ViewValue === NULL) { // Lookup from database
				$filterWrk = "`id`" . SearchString("=", $curVal, DATATYPE_NUMBER, "");
				$sqlWrk = $this->defaultpi->Lookup->getSql(FALSE, $filterWrk, '', $this);
				$rswrk = Conn()->execute($sqlWrk);
				if ($rswrk && !$rswrk->EOF) { // Lookup values found
					$arwrk = [];
					$arwrk[1] = $rswrk->fields('df');
					$this->defaultpi->ViewValue = $this->defaultpi->displayValue($arwrk);
					$rswrk->Close();
				} else {
					$this->defaultpi->ViewValue = $this->defaultpi->CurrentValue;
				}
			}
		} else {
			$this->defaultpi->ViewValue = NULL;
		}
		$this->defaultpi->ViewCustomAttributes = "";

		// acctID
		$this->acctID->ViewValue = $this->acctID->CurrentValue;
		$this->acctID->ViewCustomAttributes = "";

		// addedbyuserid
		$this->addedbyuserid->ViewValue = $this->addedbyuserid->CurrentValue;
		$this->addedbyuserid->ViewValue = FormatNumber($this->addedbyuserid->ViewValue, 0, -2, -2, -2);
		$this->addedbyuserid->ViewCustomAttributes = "";

		// pendingtransfer
		$curVal = strval($this->pendingtransfer->CurrentValue);
		if ($curVal != "") {
			$this->pendingtransfer->ViewValue = $this->pendingtransfer->lookupCacheOption($curVal);
			if ($this->pendingtransfer->ViewValue === NULL) { // Lookup from database
				$filterWrk = "`statusID`" . SearchString("=", $curVal, DATATYPE_NUMBER, "");
				$lookupFilter = function() {
					return "`langID` = 'EN'";
				};
				$lookupFilter = $lookupFilter->bindTo($this);
				$sqlWrk = $this->pendingtransfer->Lookup->getSql(FALSE, $filterWrk, $lookupFilter, $this);
				$rswrk = Conn()->execute($sqlWrk);
				if ($rswrk && !$rswrk->EOF) { // Lookup values found
					$arwrk = [];
					$arwrk[1] = $rswrk->fields('df');
					$this->pendingtransfer->ViewValue = $this->pendingtransfer->displayValue($arwrk);
					$rswrk->Close();
				} else {
					$this->pendingtransfer->ViewValue = $this->pendingtransfer->CurrentValue;
				}
			}
		} else {
			$this->pendingtransfer->ViewValue = NULL;
		}
		$this->pendingtransfer->ViewCustomAttributes = "";

		// sensitivedataid
		$this->sensitivedataid->ViewValue = $this->sensitivedataid->CurrentValue;
		$this->sensitivedataid->ViewValue = FormatNumber($this->sensitivedataid->ViewValue, 0, -2, -2, -2);
		$this->sensitivedataid->ViewCustomAttributes = "";

		// purchaseid
		$this->purchaseid->ViewValue = $this->purchaseid->CurrentValue;
		$this->purchaseid->ViewValue = FormatNumber($this->purchaseid->ViewValue, 0, -2, -2, -2);
		$this->purchaseid->ViewCustomAttributes = "";

		// paymentid
		$this->paymentid->ViewValue = $this->paymentid->CurrentValue;
		$this->paymentid->ViewValue = FormatNumber($this->paymentid->ViewValue, 0, -2, -2, -2);
		$this->paymentid->ViewCustomAttributes = "";

		// others
		$this->others->ViewValue = $this->others->CurrentValue;
		$this->others->ViewCustomAttributes = "";

		// others2
		$this->others2->ViewValue = $this->others2->CurrentValue;
		$this->others2->ViewCustomAttributes = "";

		// pinhash
		$this->pinhash->ViewValue = $Language->phrase("PasswordMask");
		$this->pinhash->ViewCustomAttributes = "";

		// pinexpiry
		$this->pinexpiry->ViewValue = $this->pinexpiry->CurrentValue;
		$this->pinexpiry->ViewValue = FormatDateTime($this->pinexpiry->ViewValue, 0);
		$this->pinexpiry->ViewCustomAttributes = "";

		// deletiontime
		$this->deletiontime->ViewValue = $this->deletiontime->CurrentValue;
		$this->deletiontime->ViewValue = FormatDateTime($this->deletiontime->ViewValue, 2);
		$this->deletiontime->ViewCustomAttributes = "";

		// servicefeeexempted
		$curVal = strval($this->servicefeeexempted->CurrentValue);
		if ($curVal != "") {
			$this->servicefeeexempted->ViewValue = $this->servicefeeexempted->lookupCacheOption($curVal);
			if ($this->servicefeeexempted->ViewValue === NULL) { // Lookup from database
				$filterWrk = "`statusID`" . SearchString("=", $curVal, DATATYPE_NUMBER, "");
				$lookupFilter = function() {
					return "`langID` = 'EN'";
				};
				$lookupFilter = $lookupFilter->bindTo($this);
				$sqlWrk = $this->servicefeeexempted->Lookup->getSql(FALSE, $filterWrk, $lookupFilter, $this);
				$rswrk = Conn()->execute($sqlWrk);
				if ($rswrk && !$rswrk->EOF) { // Lookup values found
					$arwrk = [];
					$arwrk[1] = $rswrk->fields('df');
					$this->servicefeeexempted->ViewValue = $this->servicefeeexempted->displayValue($arwrk);
					$rswrk->Close();
				} else {
					$this->servicefeeexempted->ViewValue = $this->servicefeeexempted->CurrentValue;
				}
			}
		} else {
			$this->servicefeeexempted->ViewValue = NULL;
		}
		$this->servicefeeexempted->ViewCustomAttributes = "";

		// purposeofaccount
		$curVal = strval($this->purposeofaccount->CurrentValue);
		if ($curVal != "") {
			$this->purposeofaccount->ViewValue = $this->purposeofaccount->lookupCacheOption($curVal);
			if ($this->purposeofaccount->ViewValue === NULL) { // Lookup from database
				$filterWrk = "`typeID`" . SearchString("=", $curVal, DATATYPE_STRING, "_4payreference");
				$sqlWrk = $this->purposeofaccount->Lookup->getSql(FALSE, $filterWrk, '', $this);
				$rswrk = Conn("_4payreference")->execute($sqlWrk);
				if ($rswrk && !$rswrk->EOF) { // Lookup values found
					$arwrk = [];
					$arwrk[1] = $rswrk->fields('df');
					$this->purposeofaccount->ViewValue = $this->purposeofaccount->displayValue($arwrk);
					$rswrk->Close();
				} else {
					$this->purposeofaccount->ViewValue = $this->purposeofaccount->CurrentValue;
				}
			}
		} else {
			$this->purposeofaccount->ViewValue = NULL;
		}
		$this->purposeofaccount->ViewCustomAttributes = "";

		// extendedfields
		$this->extendedfields->ViewValue = $this->extendedfields->CurrentValue;
		$this->extendedfields->ViewCustomAttributes = "";

		// id
		$this->id->LinkCustomAttributes = "";
		if (!EmptyValue($this->id->CurrentValue)) {
			$this->id->HrefValue = "userpiview.php?showdetail=&id=" . $this->id->CurrentValue; // Add prefix/suffix
			$this->id->LinkAttrs["target"] = ""; // Add target
			if ($this->isExport())
				$this->id->HrefValue = FullUrl($this->id->HrefValue, "href");
		} else {
			$this->id->HrefValue = "";
		}
		$this->id->TooltipValue = "";

		// userid
		$this->_userid->LinkCustomAttributes = "";
		if (!EmptyValue($this->_userid->CurrentValue)) {
			$this->_userid->HrefValue = "userview.php?showdetail=&id=" . $this->_userid->CurrentValue; // Add prefix/suffix
			$this->_userid->LinkAttrs["target"] = ""; // Add target
			if ($this->isExport())
				$this->_userid->HrefValue = FullUrl($this->_userid->HrefValue, "href");
		} else {
			$this->_userid->HrefValue = "";
		}
		$this->_userid->TooltipValue = "";

		// tokenid
		$this->tokenid->LinkCustomAttributes = "";
		$this->tokenid->HrefValue = "";
		$this->tokenid->TooltipValue = "";

		// cardno
		$this->cardno->LinkCustomAttributes = "";
		$this->cardno->HrefValue = "";
		$this->cardno->TooltipValue = "";

		// lastupdated
		$this->lastupdated->LinkCustomAttributes = "";
		$this->lastupdated->HrefValue = "";
		$this->lastupdated->TooltipValue = "";

		// piid
		$this->piid->LinkCustomAttributes = "";
		$this->piid->HrefValue = "";
		$this->piid->TooltipValue = "";

		// deleted
		$this->deleted->LinkCustomAttributes = "";
		$this->deleted->HrefValue = "";
		$this->deleted->TooltipValue = "";

		// currcode
		$this->currcode->LinkCustomAttributes = "";
		$this->currcode->HrefValue = "";
		$this->currcode->TooltipValue = "";

		// friendlyname
		$this->friendlyname->LinkCustomAttributes = "";
		$this->friendlyname->HrefValue = "";
		$this->friendlyname->TooltipValue = "";

		// key
		$this->_key->LinkCustomAttributes = "";
		$this->_key->HrefValue = "";
		$this->_key->TooltipValue = "";

		// verified
		$this->verified->LinkCustomAttributes = "";
		$this->verified->HrefValue = "";
		$this->verified->TooltipValue = "";

		// addeddatetime
		$this->addeddatetime->LinkCustomAttributes = "";
		$this->addeddatetime->HrefValue = "";
		$this->addeddatetime->TooltipValue = "";

		// piexpirytime
		$this->piexpirytime->LinkCustomAttributes = "";
		$this->piexpirytime->HrefValue = "";
		$this->piexpirytime->TooltipValue = "";

		// verifiedtime
		$this->verifiedtime->LinkCustomAttributes = "";
		$this->verifiedtime->HrefValue = "";
		$this->verifiedtime->TooltipValue = "";

		// vaultid
		$this->vaultid->LinkCustomAttributes = "";
		$this->vaultid->HrefValue = "";
		$this->vaultid->TooltipValue = "";

		// defaultpi
		$this->defaultpi->LinkCustomAttributes = "";
		$this->defaultpi->HrefValue = "";
		$this->defaultpi->TooltipValue = "";

		// acctID
		$this->acctID->LinkCustomAttributes = "";
		if (!EmptyValue($this->acctID->CurrentValue)) {
			$this->acctID->HrefValue = "acctbalancelist.php?x_acctID=" . $this->acctID->CurrentValue . "&z_acctID=%3D&cmd=search"; // Add prefix/suffix
			$this->acctID->LinkAttrs["target"] = ""; // Add target
			if ($this->isExport())
				$this->acctID->HrefValue = FullUrl($this->acctID->HrefValue, "href");
		} else {
			$this->acctID->HrefValue = "";
		}
		$this->acctID->TooltipValue = "";

		// addedbyuserid
		$this->addedbyuserid->LinkCustomAttributes = "";
		$this->addedbyuserid->HrefValue = "";
		$this->addedbyuserid->TooltipValue = "";

		// pendingtransfer
		$this->pendingtransfer->LinkCustomAttributes = "";
		$this->pendingtransfer->HrefValue = "";
		$this->pendingtransfer->TooltipValue = "";

		// sensitivedataid
		$this->sensitivedataid->LinkCustomAttributes = "";
		$this->sensitivedataid->HrefValue = "";
		$this->sensitivedataid->TooltipValue = "";

		// purchaseid
		$this->purchaseid->LinkCustomAttributes = "";
		$this->purchaseid->HrefValue = "";
		$this->purchaseid->TooltipValue = "";

		// paymentid
		$this->paymentid->LinkCustomAttributes = "";
		$this->paymentid->HrefValue = "";
		$this->paymentid->TooltipValue = "";

		// others
		$this->others->LinkCustomAttributes = "";
		$this->others->HrefValue = "";
		$this->others->TooltipValue = "";

		// others2
		$this->others2->LinkCustomAttributes = "";
		$this->others2->HrefValue = "";
		$this->others2->TooltipValue = "";

		// pinhash
		$this->pinhash->LinkCustomAttributes = "";
		$this->pinhash->HrefValue = "";
		$this->pinhash->TooltipValue = "";

		// pinexpiry
		$this->pinexpiry->LinkCustomAttributes = "";
		$this->pinexpiry->HrefValue = "";
		$this->pinexpiry->TooltipValue = "";

		// deletiontime
		$this->deletiontime->LinkCustomAttributes = "";
		$this->deletiontime->HrefValue = "";
		$this->deletiontime->TooltipValue = "";

		// servicefeeexempted
		$this->servicefeeexempted->LinkCustomAttributes = "";
		$this->servicefeeexempted->HrefValue = "";
		$this->servicefeeexempted->TooltipValue = "";

		// purposeofaccount
		$this->purposeofaccount->LinkCustomAttributes = "";
		$this->purposeofaccount->HrefValue = "";
		$this->purposeofaccount->TooltipValue = "";

		// extendedfields
		$this->extendedfields->LinkCustomAttributes = "";
		$this->extendedfields->HrefValue = "";
		$this->extendedfields->TooltipValue = "";

		// Call Row Rendered event
		$this->Row_Rendered();

		// Save data for Custom Template
		$this->Rows[] = $this->customTemplateFieldValues();
	}

	// Render edit row values
	public function renderEditRow()
	{
		global $Security, $CurrentLanguage, $Language;

		// Call Row Rendering event
		$this->Row_Rendering();

		// id
		$this->id->EditAttrs["class"] = "form-control";
		$this->id->EditCustomAttributes = "";
		$this->id->EditValue = $this->id->CurrentValue;
		$this->id->ViewCustomAttributes = "";

		// userid
		$this->_userid->EditAttrs["class"] = "form-control";
		$this->_userid->EditCustomAttributes = "";
		if ($this->_userid->getSessionValue() != "") {
			$this->_userid->CurrentValue = $this->_userid->getSessionValue();
			$this->_userid->ViewValue = $this->_userid->CurrentValue;
			$this->_userid->ViewCustomAttributes = "";
		} else {
			$this->_userid->EditValue = $this->_userid->CurrentValue;
			$this->_userid->PlaceHolder = RemoveHtml($this->_userid->caption());
		}

		// tokenid
		$this->tokenid->EditAttrs["class"] = "form-control";
		$this->tokenid->EditCustomAttributes = "";
		if (!$this->tokenid->Raw)
			$this->tokenid->CurrentValue = HtmlDecode($this->tokenid->CurrentValue);
		$this->tokenid->EditValue = $this->tokenid->CurrentValue;
		$this->tokenid->PlaceHolder = RemoveHtml($this->tokenid->caption());

		// cardno
		$this->cardno->EditAttrs["class"] = "form-control";
		$this->cardno->EditCustomAttributes = "";
		if (!$this->cardno->Raw)
			$this->cardno->CurrentValue = HtmlDecode($this->cardno->CurrentValue);
		$this->cardno->EditValue = $this->cardno->CurrentValue;
		$this->cardno->PlaceHolder = RemoveHtml($this->cardno->caption());

		// lastupdated
		$this->lastupdated->EditAttrs["class"] = "form-control";
		$this->lastupdated->EditCustomAttributes = "";
		$this->lastupdated->EditValue = FormatDateTime($this->lastupdated->CurrentValue, 10);
		$this->lastupdated->PlaceHolder = RemoveHtml($this->lastupdated->caption());

		// piid
		$this->piid->EditAttrs["class"] = "form-control";
		$this->piid->EditCustomAttributes = "";

		// deleted
		$this->deleted->EditAttrs["class"] = "form-control";
		$this->deleted->EditCustomAttributes = "";
		$this->deleted->EditValue = $this->deleted->options(TRUE);

		// currcode
		$this->currcode->EditAttrs["class"] = "form-control";
		$this->currcode->EditCustomAttributes = "";

		// friendlyname
		$this->friendlyname->EditAttrs["class"] = "form-control";
		$this->friendlyname->EditCustomAttributes = "";
		if (!$this->friendlyname->Raw)
			$this->friendlyname->CurrentValue = HtmlDecode($this->friendlyname->CurrentValue);
		$this->friendlyname->EditValue = $this->friendlyname->CurrentValue;
		$this->friendlyname->PlaceHolder = RemoveHtml($this->friendlyname->caption());

		// key
		$this->_key->EditAttrs["class"] = "form-control";
		$this->_key->EditCustomAttributes = "";
		$this->_key->EditValue = $this->_key->CurrentValue;
		$this->_key->PlaceHolder = RemoveHtml($this->_key->caption());

		// verified
		$this->verified->EditCustomAttributes = "";

		// addeddatetime
		$this->addeddatetime->EditAttrs["class"] = "form-control";
		$this->addeddatetime->EditCustomAttributes = "";
		$this->addeddatetime->EditValue = FormatDateTime($this->addeddatetime->CurrentValue, 8);
		$this->addeddatetime->PlaceHolder = RemoveHtml($this->addeddatetime->caption());

		// piexpirytime
		$this->piexpirytime->EditAttrs["class"] = "form-control";
		$this->piexpirytime->EditCustomAttributes = "";
		$this->piexpirytime->EditValue = FormatDateTime($this->piexpirytime->CurrentValue, 8);
		$this->piexpirytime->PlaceHolder = RemoveHtml($this->piexpirytime->caption());

		// verifiedtime
		$this->verifiedtime->EditAttrs["class"] = "form-control";
		$this->verifiedtime->EditCustomAttributes = "";
		$this->verifiedtime->EditValue = FormatDateTime($this->verifiedtime->CurrentValue, 8);
		$this->verifiedtime->PlaceHolder = RemoveHtml($this->verifiedtime->caption());

		// vaultid
		$this->vaultid->EditAttrs["class"] = "form-control";
		$this->vaultid->EditCustomAttributes = "";

		// defaultpi
		$this->defaultpi->EditCustomAttributes = "";

		// acctID
		$this->acctID->EditAttrs["class"] = "form-control";
		$this->acctID->EditCustomAttributes = "";
		$this->acctID->EditValue = $this->acctID->CurrentValue;
		$this->acctID->PlaceHolder = RemoveHtml($this->acctID->caption());

		// addedbyuserid
		$this->addedbyuserid->EditAttrs["class"] = "form-control";
		$this->addedbyuserid->EditCustomAttributes = "";
		$this->addedbyuserid->EditValue = $this->addedbyuserid->CurrentValue;
		$this->addedbyuserid->PlaceHolder = RemoveHtml($this->addedbyuserid->caption());

		// pendingtransfer
		$this->pendingtransfer->EditAttrs["class"] = "form-control";
		$this->pendingtransfer->EditCustomAttributes = "";

		// sensitivedataid
		$this->sensitivedataid->EditAttrs["class"] = "form-control";
		$this->sensitivedataid->EditCustomAttributes = "";
		$this->sensitivedataid->EditValue = $this->sensitivedataid->CurrentValue;
		$this->sensitivedataid->PlaceHolder = RemoveHtml($this->sensitivedataid->caption());

		// purchaseid
		$this->purchaseid->EditAttrs["class"] = "form-control";
		$this->purchaseid->EditCustomAttributes = "";
		$this->purchaseid->EditValue = $this->purchaseid->CurrentValue;
		$this->purchaseid->PlaceHolder = RemoveHtml($this->purchaseid->caption());

		// paymentid
		$this->paymentid->EditAttrs["class"] = "form-control";
		$this->paymentid->EditCustomAttributes = "";
		$this->paymentid->EditValue = $this->paymentid->CurrentValue;
		$this->paymentid->PlaceHolder = RemoveHtml($this->paymentid->caption());

		// others
		$this->others->EditAttrs["class"] = "form-control";
		$this->others->EditCustomAttributes = "";
		$this->others->EditValue = $this->others->CurrentValue;
		$this->others->PlaceHolder = RemoveHtml($this->others->caption());

		// others2
		$this->others2->EditAttrs["class"] = "form-control";
		$this->others2->EditCustomAttributes = "";
		$this->others2->EditValue = $this->others2->CurrentValue;
		$this->others2->PlaceHolder = RemoveHtml($this->others2->caption());

		// pinhash
		$this->pinhash->EditAttrs["class"] = "form-control";
		$this->pinhash->EditCustomAttributes = "";
		$this->pinhash->EditValue = $this->pinhash->CurrentValue;
		$this->pinhash->PlaceHolder = RemoveHtml($this->pinhash->caption());

		// pinexpiry
		$this->pinexpiry->EditAttrs["class"] = "form-control";
		$this->pinexpiry->EditCustomAttributes = "";
		$this->pinexpiry->EditValue = FormatDateTime($this->pinexpiry->CurrentValue, 8);
		$this->pinexpiry->PlaceHolder = RemoveHtml($this->pinexpiry->caption());

		// deletiontime
		$this->deletiontime->EditAttrs["class"] = "form-control";
		$this->deletiontime->EditCustomAttributes = "";
		$this->deletiontime->EditValue = FormatDateTime($this->deletiontime->CurrentValue, 2);
		$this->deletiontime->PlaceHolder = RemoveHtml($this->deletiontime->caption());

		// servicefeeexempted
		$this->servicefeeexempted->EditAttrs["class"] = "form-control";
		$this->servicefeeexempted->EditCustomAttributes = "";

		// purposeofaccount
		$this->purposeofaccount->EditAttrs["class"] = "form-control";
		$this->purposeofaccount->EditCustomAttributes = "";

		// extendedfields
		$this->extendedfields->EditAttrs["class"] = "form-control";
		$this->extendedfields->EditCustomAttributes = "";
		$this->extendedfields->EditValue = $this->extendedfields->CurrentValue;
		$this->extendedfields->PlaceHolder = RemoveHtml($this->extendedfields->caption());

		// Call Row Rendered event
		$this->Row_Rendered();
	}

	// Aggregate list row values
	public function aggregateListRowValues()
	{
	}

	// Aggregate list row (for rendering)
	public function aggregateListRow()
	{

		// Call Row Rendered event
		$this->Row_Rendered();
	}

	// Export data in HTML/CSV/Word/Excel/Email/PDF format
	public function exportDocument($doc, $recordset, $startRec = 1, $stopRec = 1, $exportPageType = "")
	{
		if (!$recordset || !$doc)
			return;
		if (!$doc->ExportCustom) {

			// Write header
			$doc->exportTableHeader();
			if ($doc->Horizontal) { // Horizontal format, write header
				$doc->beginExportRow();
				if ($exportPageType == "view") {
					$doc->exportCaption($this->id);
					$doc->exportCaption($this->_userid);
					$doc->exportCaption($this->cardno);
					$doc->exportCaption($this->lastupdated);
					$doc->exportCaption($this->piid);
					$doc->exportCaption($this->deleted);
					$doc->exportCaption($this->currcode);
					$doc->exportCaption($this->friendlyname);
					$doc->exportCaption($this->verified);
					$doc->exportCaption($this->addeddatetime);
					$doc->exportCaption($this->piexpirytime);
					$doc->exportCaption($this->verifiedtime);
					$doc->exportCaption($this->vaultid);
					$doc->exportCaption($this->defaultpi);
					$doc->exportCaption($this->acctID);
					$doc->exportCaption($this->addedbyuserid);
					$doc->exportCaption($this->pendingtransfer);
					$doc->exportCaption($this->sensitivedataid);
					$doc->exportCaption($this->purchaseid);
					$doc->exportCaption($this->paymentid);
					$doc->exportCaption($this->others);
					$doc->exportCaption($this->others2);
					$doc->exportCaption($this->pinhash);
					$doc->exportCaption($this->pinexpiry);
					$doc->exportCaption($this->deletiontime);
					$doc->exportCaption($this->servicefeeexempted);
					$doc->exportCaption($this->purposeofaccount);
					$doc->exportCaption($this->extendedfields);
				} else {
					$doc->exportCaption($this->id);
					$doc->exportCaption($this->_userid);
					$doc->exportCaption($this->cardno);
					$doc->exportCaption($this->lastupdated);
					$doc->exportCaption($this->piid);
					$doc->exportCaption($this->deleted);
					$doc->exportCaption($this->currcode);
					$doc->exportCaption($this->friendlyname);
					$doc->exportCaption($this->verified);
					$doc->exportCaption($this->addeddatetime);
					$doc->exportCaption($this->piexpirytime);
					$doc->exportCaption($this->verifiedtime);
					$doc->exportCaption($this->vaultid);
					$doc->exportCaption($this->defaultpi);
					$doc->exportCaption($this->acctID);
					$doc->exportCaption($this->addedbyuserid);
					$doc->exportCaption($this->pendingtransfer);
					$doc->exportCaption($this->purchaseid);
					$doc->exportCaption($this->paymentid);
					$doc->exportCaption($this->others);
					$doc->exportCaption($this->others2);
					$doc->exportCaption($this->pinhash);
					$doc->exportCaption($this->pinexpiry);
					$doc->exportCaption($this->deletiontime);
					$doc->exportCaption($this->servicefeeexempted);
					$doc->exportCaption($this->purposeofaccount);
				}
				$doc->endExportRow();
			}
		}

		// Move to first record
		$recCnt = $startRec - 1;
		if (!$recordset->EOF) {
			$recordset->moveFirst();
			if ($startRec > 1)
				$recordset->move($startRec - 1);
		}
		while (!$recordset->EOF && $recCnt < $stopRec) {
			$recCnt++;
			if ($recCnt >= $startRec) {
				$rowCnt = $recCnt - $startRec + 1;

				// Page break
				if ($this->ExportPageBreakCount > 0) {
					if ($rowCnt > 1 && ($rowCnt - 1) % $this->ExportPageBreakCount == 0)
						$doc->exportPageBreak();
				}
				$this->loadListRowValues($recordset);

				// Render row
				$this->RowType = ROWTYPE_VIEW; // Render view
				$this->resetAttributes();
				$this->renderListRow();
				if (!$doc->ExportCustom) {
					$doc->beginExportRow($rowCnt); // Allow CSS styles if enabled
					if ($exportPageType == "view") {
						$doc->exportField($this->id);
						$doc->exportField($this->_userid);
						$doc->exportField($this->cardno);
						$doc->exportField($this->lastupdated);
						$doc->exportField($this->piid);
						$doc->exportField($this->deleted);
						$doc->exportField($this->currcode);
						$doc->exportField($this->friendlyname);
						$doc->exportField($this->verified);
						$doc->exportField($this->addeddatetime);
						$doc->exportField($this->piexpirytime);
						$doc->exportField($this->verifiedtime);
						$doc->exportField($this->vaultid);
						$doc->exportField($this->defaultpi);
						$doc->exportField($this->acctID);
						$doc->exportField($this->addedbyuserid);
						$doc->exportField($this->pendingtransfer);
						$doc->exportField($this->sensitivedataid);
						$doc->exportField($this->purchaseid);
						$doc->exportField($this->paymentid);
						$doc->exportField($this->others);
						$doc->exportField($this->others2);
						$doc->exportField($this->pinhash);
						$doc->exportField($this->pinexpiry);
						$doc->exportField($this->deletiontime);
						$doc->exportField($this->servicefeeexempted);
						$doc->exportField($this->purposeofaccount);
						$doc->exportField($this->extendedfields);
					} else {
						$doc->exportField($this->id);
						$doc->exportField($this->_userid);
						$doc->exportField($this->cardno);
						$doc->exportField($this->lastupdated);
						$doc->exportField($this->piid);
						$doc->exportField($this->deleted);
						$doc->exportField($this->currcode);
						$doc->exportField($this->friendlyname);
						$doc->exportField($this->verified);
						$doc->exportField($this->addeddatetime);
						$doc->exportField($this->piexpirytime);
						$doc->exportField($this->verifiedtime);
						$doc->exportField($this->vaultid);
						$doc->exportField($this->defaultpi);
						$doc->exportField($this->acctID);
						$doc->exportField($this->addedbyuserid);
						$doc->exportField($this->pendingtransfer);
						$doc->exportField($this->purchaseid);
						$doc->exportField($this->paymentid);
						$doc->exportField($this->others);
						$doc->exportField($this->others2);
						$doc->exportField($this->pinhash);
						$doc->exportField($this->pinexpiry);
						$doc->exportField($this->deletiontime);
						$doc->exportField($this->servicefeeexempted);
						$doc->exportField($this->purposeofaccount);
					}
					$doc->endExportRow($rowCnt);
				}
			}

			// Call Row Export server event
			if ($doc->ExportCustom)
				$this->Row_Export($recordset->fields);
			$recordset->moveNext();
		}
		if (!$doc->ExportCustom) {
			$doc->exportTableFooter();
		}
	}

	// Get file data
	public function getFileData($fldparm, $key, $resize, $width = 0, $height = 0)
	{

		// No binary fields
		return FALSE;
	}

	// Write Audit Trail start/end for grid update
	public function writeAuditTrailDummy($typ)
	{
		$table = 'userpi';
		$usr = CurrentUserName();
		WriteAuditTrail("log", DbCurrentDateTime(), ScriptName(), $usr, $typ, $table, "", "", "", "");
	}

	// Write Audit Trail (add page)
	public function writeAuditTrailOnAdd(&$rs)
	{
		global $Language;
		if (!$this->AuditTrailOnAdd)
			return;
		$table = 'userpi';

		// Get key value
		$key = "";
		if ($key != "")
			$key .= Config("COMPOSITE_KEY_SEPARATOR");
		$key .= $rs['id'];

		// Write Audit Trail
		$dt = DbCurrentDateTime();
		$id = ScriptName();
		$usr = CurrentUserName();
		foreach (array_keys($rs) as $fldname) {
			if (array_key_exists($fldname, $this->fields) && $this->fields[$fldname]->DataType != DATATYPE_BLOB) { // Ignore BLOB fields
				if ($this->fields[$fldname]->HtmlTag == "PASSWORD") {
					$newvalue = $Language->phrase("PasswordMask"); // Password Field
				} elseif ($this->fields[$fldname]->DataType == DATATYPE_MEMO) {
					if (Config("AUDIT_TRAIL_TO_DATABASE"))
						$newvalue = $rs[$fldname];
					else
						$newvalue = "[MEMO]"; // Memo Field
				} elseif ($this->fields[$fldname]->DataType == DATATYPE_XML) {
					$newvalue = "[XML]"; // XML Field
				} else {
					$newvalue = $rs[$fldname];
				}
				WriteAuditTrail("log", $dt, $id, $usr, "A", $table, $fldname, $key, "", $newvalue);
			}
		}
	}

	// Write Audit Trail (edit page)
	public function writeAuditTrailOnEdit(&$rsold, &$rsnew)
	{
		global $Language;
		if (!$this->AuditTrailOnEdit)
			return;
		$table = 'userpi';

		// Get key value
		$key = "";
		if ($key != "")
			$key .= Config("COMPOSITE_KEY_SEPARATOR");
		$key .= $rsold['id'];

		// Write Audit Trail
		$dt = DbCurrentDateTime();
		$id = ScriptName();
		$usr = CurrentUserName();
		foreach (array_keys($rsnew) as $fldname) {
			if (array_key_exists($fldname, $this->fields) && array_key_exists($fldname, $rsold) && $this->fields[$fldname]->DataType != DATATYPE_BLOB) { // Ignore BLOB fields
				if ($this->fields[$fldname]->DataType == DATATYPE_DATE) { // DateTime field
					$modified = (FormatDateTime($rsold[$fldname], 0) != FormatDateTime($rsnew[$fldname], 0));
				} else {
					$modified = !CompareValue($rsold[$fldname], $rsnew[$fldname]);
				}
				if ($modified) {
					if ($this->fields[$fldname]->HtmlTag == "PASSWORD") { // Password Field
						$oldvalue = $Language->phrase("PasswordMask");
						$newvalue = $Language->phrase("PasswordMask");
					} elseif ($this->fields[$fldname]->DataType == DATATYPE_MEMO) { // Memo field
						if (Config("AUDIT_TRAIL_TO_DATABASE")) {
							$oldvalue = $rsold[$fldname];
							$newvalue = $rsnew[$fldname];
						} else {
							$oldvalue = "[MEMO]";
							$newvalue = "[MEMO]";
						}
					} elseif ($this->fields[$fldname]->DataType == DATATYPE_XML) { // XML field
						$oldvalue = "[XML]";
						$newvalue = "[XML]";
					} else {
						$oldvalue = $rsold[$fldname];
						$newvalue = $rsnew[$fldname];
					}
					WriteAuditTrail("log", $dt, $id, $usr, "U", $table, $fldname, $key, $oldvalue, $newvalue);
				}
			}
		}
	}

	// Write Audit Trail (delete page)
	public function writeAuditTrailOnDelete(&$rs)
	{
		global $Language;
		if (!$this->AuditTrailOnDelete)
			return;
		$table = 'userpi';

		// Get key value
		$key = "";
		if ($key != "")
			$key .= Config("COMPOSITE_KEY_SEPARATOR");
		$key .= $rs['id'];

		// Write Audit Trail
		$dt = DbCurrentDateTime();
		$id = ScriptName();
		$curUser = CurrentUserName();
		foreach (array_keys($rs) as $fldname) {
			if (array_key_exists($fldname, $this->fields) && $this->fields[$fldname]->DataType != DATATYPE_BLOB) { // Ignore BLOB fields
				if ($this->fields[$fldname]->HtmlTag == "PASSWORD") {
					$oldvalue = $Language->phrase("PasswordMask"); // Password Field
				} elseif ($this->fields[$fldname]->DataType == DATATYPE_MEMO) {
					if (Config("AUDIT_TRAIL_TO_DATABASE"))
						$oldvalue = $rs[$fldname];
					else
						$oldvalue = "[MEMO]"; // Memo field
				} elseif ($this->fields[$fldname]->DataType == DATATYPE_XML) {
					$oldvalue = "[XML]"; // XML field
				} else {
					$oldvalue = $rs[$fldname];
				}
				WriteAuditTrail("log", $dt, $id, $curUser, "D", $table, $fldname, $key, $oldvalue, "");
			}
		}
	}

	// Table level events
	// Recordset Selecting event
	function Recordset_Selecting(&$filter) {

		// Enter your code here
	}

	// Recordset Selected event
	function Recordset_Selected(&$rs) {

		//echo "Recordset Selected";
	}

	// Recordset Search Validated event
	function Recordset_SearchValidated() {

		// Example:
		//$this->MyField1->AdvancedSearch->SearchValue = "your search criteria"; // Search value

	}

	// Recordset Searching event
	function Recordset_Searching(&$filter) {

		// Enter your code here
	}

	// Row_Selecting event
	function Row_Selecting(&$filter) {

		// Enter your code here
	}

	// Row Selected event
	function Row_Selected(&$rs) {

		//echo "Row Selected";
	}

	// Row Inserting event
	function Row_Inserting($rsold, &$rsnew) {

		// Enter your code here
		// To cancel, set return value to FALSE

		return TRUE;
	}

	// Row Inserted event
	function Row_Inserted($rsold, &$rsnew) {

		//echo "Row Inserted"
	}

	// Row Updating event
	function Row_Updating($rsold, &$rsnew) {

		// Enter your code here
		// To cancel, set return value to FALSE

		return TRUE;
	}

	// Row Updated event
	function Row_Updated($rsold, &$rsnew) {

		//echo "Row Updated";
	}

	// Row Update Conflict event
	function Row_UpdateConflict($rsold, &$rsnew) {

		// Enter your code here
		// To ignore conflict, set return value to FALSE

		return TRUE;
	}

	// Grid Inserting event
	function Grid_Inserting() {

		// Enter your code here
		// To reject grid insert, set return value to FALSE

		return TRUE;
	}

	// Grid Inserted event
	function Grid_Inserted($rsnew) {

		//echo "Grid Inserted";
	}

	// Grid Updating event
	function Grid_Updating($rsold) {

		// Enter your code here
		// To reject grid update, set return value to FALSE

		return TRUE;
	}

	// Grid Updated event
	function Grid_Updated($rsold, $rsnew) {

		//echo "Grid Updated";
	}

	// Row Deleting event
	function Row_Deleting(&$rs) {

		// Enter your code here
		// To cancel, set return value to False

		return TRUE;
	}

	// Row Deleted event
	function Row_Deleted(&$rs) {

		//echo "Row Deleted";
	}

	// Email Sending event
	function Email_Sending($email, &$args) {

		//var_dump($email); var_dump($args); exit();
		return TRUE;
	}

	// Lookup Selecting event
	function Lookup_Selecting($fld, &$filter) {

		//var_dump($fld->Name, $fld->Lookup, $filter); // Uncomment to view the filter
		// Enter your code here

	}

	// Row Rendering event
	function Row_Rendering() {

		// Enter your code here
	}

	// Row Rendered event
	function Row_Rendered() {

		// To view properties of field class, use:
		//var_dump($this-><FieldName>);

	}

	// User ID Filtering event
	function UserID_Filtering(&$filter) {

		// Enter your code here
	}
}
?>