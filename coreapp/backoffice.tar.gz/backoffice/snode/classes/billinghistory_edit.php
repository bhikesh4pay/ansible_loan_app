<?php
namespace PHPMaker2020\_4payadmin;

/**
 * Page class
 */
class billinghistory_edit extends billinghistory
{

	// Page ID
	public $PageID = "edit";

	// Project ID
	public $ProjectID = "{153C2D2E-60EE-4944-8753-3935EB38E8D6}";

	// Table name
	public $TableName = 'billinghistory';

	// Page object name
	public $PageObjName = "billinghistory_edit";

	// Audit Trail
	public $AuditTrailOnAdd = TRUE;
	public $AuditTrailOnEdit = TRUE;
	public $AuditTrailOnDelete = TRUE;
	public $AuditTrailOnView = FALSE;
	public $AuditTrailOnViewData = FALSE;
	public $AuditTrailOnSearch = FALSE;

	// Page headings
	public $Heading = "";
	public $Subheading = "";
	public $PageHeader;
	public $PageFooter;

	// Token
	public $Token = "";
	public $TokenTimeout = 0;
	public $CheckToken;

	// Page heading
	public function pageHeading()
	{
		global $Language;
		if ($this->Heading != "")
			return $this->Heading;
		if (method_exists($this, "tableCaption"))
			return $this->tableCaption();
		return "";
	}

	// Page subheading
	public function pageSubheading()
	{
		global $Language;
		if ($this->Subheading != "")
			return $this->Subheading;
		if ($this->TableName)
			return $Language->phrase($this->PageID);
		return "";
	}

	// Page name
	public function pageName()
	{
		return CurrentPageName();
	}

	// Page URL
	public function pageUrl()
	{
		$url = CurrentPageName() . "?";
		if ($this->UseTokenInUrl)
			$url .= "t=" . $this->TableVar . "&"; // Add page token
		return $url;
	}

	// Messages
	private $_message = "";
	private $_failureMessage = "";
	private $_successMessage = "";
	private $_warningMessage = "";

	// Get message
	public function getMessage()
	{
		return isset($_SESSION[SESSION_MESSAGE]) ? $_SESSION[SESSION_MESSAGE] : $this->_message;
	}

	// Set message
	public function setMessage($v)
	{
		AddMessage($this->_message, $v);
		$_SESSION[SESSION_MESSAGE] = $this->_message;
	}

	// Get failure message
	public function getFailureMessage()
	{
		return isset($_SESSION[SESSION_FAILURE_MESSAGE]) ? $_SESSION[SESSION_FAILURE_MESSAGE] : $this->_failureMessage;
	}

	// Set failure message
	public function setFailureMessage($v)
	{
		AddMessage($this->_failureMessage, $v);
		$_SESSION[SESSION_FAILURE_MESSAGE] = $this->_failureMessage;
	}

	// Get success message
	public function getSuccessMessage()
	{
		return isset($_SESSION[SESSION_SUCCESS_MESSAGE]) ? $_SESSION[SESSION_SUCCESS_MESSAGE] : $this->_successMessage;
	}

	// Set success message
	public function setSuccessMessage($v)
	{
		AddMessage($this->_successMessage, $v);
		$_SESSION[SESSION_SUCCESS_MESSAGE] = $this->_successMessage;
	}

	// Get warning message
	public function getWarningMessage()
	{
		return isset($_SESSION[SESSION_WARNING_MESSAGE]) ? $_SESSION[SESSION_WARNING_MESSAGE] : $this->_warningMessage;
	}

	// Set warning message
	public function setWarningMessage($v)
	{
		AddMessage($this->_warningMessage, $v);
		$_SESSION[SESSION_WARNING_MESSAGE] = $this->_warningMessage;
	}

	// Clear message
	public function clearMessage()
	{
		$this->_message = "";
		$_SESSION[SESSION_MESSAGE] = "";
	}

	// Clear failure message
	public function clearFailureMessage()
	{
		$this->_failureMessage = "";
		$_SESSION[SESSION_FAILURE_MESSAGE] = "";
	}

	// Clear success message
	public function clearSuccessMessage()
	{
		$this->_successMessage = "";
		$_SESSION[SESSION_SUCCESS_MESSAGE] = "";
	}

	// Clear warning message
	public function clearWarningMessage()
	{
		$this->_warningMessage = "";
		$_SESSION[SESSION_WARNING_MESSAGE] = "";
	}

	// Clear messages
	public function clearMessages()
	{
		$this->clearMessage();
		$this->clearFailureMessage();
		$this->clearSuccessMessage();
		$this->clearWarningMessage();
	}

	// Show message
	public function showMessage()
	{
		$hidden = FALSE;
		$html = "";

		// Message
		$message = $this->getMessage();
		if (method_exists($this, "Message_Showing"))
			$this->Message_Showing($message, "");
		if ($message != "") { // Message in Session, display
			if (!$hidden)
				$message = '<button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button>' . $message;
			$html .= '<div class="alert alert-info alert-dismissible ew-info"><i class="icon fas fa-info"></i>' . $message . '</div>';
			$_SESSION[SESSION_MESSAGE] = ""; // Clear message in Session
		}

		// Warning message
		$warningMessage = $this->getWarningMessage();
		if (method_exists($this, "Message_Showing"))
			$this->Message_Showing($warningMessage, "warning");
		if ($warningMessage != "") { // Message in Session, display
			if (!$hidden)
				$warningMessage = '<button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button>' . $warningMessage;
			$html .= '<div class="alert alert-warning alert-dismissible ew-warning"><i class="icon fas fa-exclamation"></i>' . $warningMessage . '</div>';
			$_SESSION[SESSION_WARNING_MESSAGE] = ""; // Clear message in Session
		}

		// Success message
		$successMessage = $this->getSuccessMessage();
		if (method_exists($this, "Message_Showing"))
			$this->Message_Showing($successMessage, "success");
		if ($successMessage != "") { // Message in Session, display
			if (!$hidden)
				$successMessage = '<button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button>' . $successMessage;
			$html .= '<div class="alert alert-success alert-dismissible ew-success"><i class="icon fas fa-check"></i>' . $successMessage . '</div>';
			$_SESSION[SESSION_SUCCESS_MESSAGE] = ""; // Clear message in Session
		}

		// Failure message
		$errorMessage = $this->getFailureMessage();
		if (method_exists($this, "Message_Showing"))
			$this->Message_Showing($errorMessage, "failure");
		if ($errorMessage != "") { // Message in Session, display
			if (!$hidden)
				$errorMessage = '<button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button>' . $errorMessage;
			$html .= '<div class="alert alert-danger alert-dismissible ew-error"><i class="icon fas fa-ban"></i>' . $errorMessage . '</div>';
			$_SESSION[SESSION_FAILURE_MESSAGE] = ""; // Clear message in Session
		}
		echo '<div class="ew-message-dialog' . (($hidden) ? ' d-none' : "") . '">' . $html . '</div>';
	}

	// Get message as array
	public function getMessages()
	{
		$ar = [];

		// Message
		$message = $this->getMessage();

		//if (method_exists($this, "Message_Showing"))
		//	$this->Message_Showing($message, "");

		if ($message != "") { // Message in Session, display
			$ar["message"] = $message;
			$_SESSION[SESSION_MESSAGE] = ""; // Clear message in Session
		}

		// Warning message
		$warningMessage = $this->getWarningMessage();

		//if (method_exists($this, "Message_Showing"))
		//	$this->Message_Showing($warningMessage, "warning");

		if ($warningMessage != "") { // Message in Session, display
			$ar["warningMessage"] = $warningMessage;
			$_SESSION[SESSION_WARNING_MESSAGE] = ""; // Clear message in Session
		}

		// Success message
		$successMessage = $this->getSuccessMessage();

		//if (method_exists($this, "Message_Showing"))
		//	$this->Message_Showing($successMessage, "success");

		if ($successMessage != "") { // Message in Session, display
			$ar["successMessage"] = $successMessage;
			$_SESSION[SESSION_SUCCESS_MESSAGE] = ""; // Clear message in Session
		}

		// Failure message
		$failureMessage = $this->getFailureMessage();

		//if (method_exists($this, "Message_Showing"))
		//	$this->Message_Showing($failureMessage, "failure");

		if ($failureMessage != "") { // Message in Session, display
			$ar["failureMessage"] = $failureMessage;
			$_SESSION[SESSION_FAILURE_MESSAGE] = ""; // Clear message in Session
		}
		return $ar;
	}

	// Show Page Header
	public function showPageHeader()
	{
		$header = $this->PageHeader;
		$this->Page_DataRendering($header);
		if ($header != "") { // Header exists, display
			echo '<p id="ew-page-header">' . $header . '</p>';
		}
	}

	// Show Page Footer
	public function showPageFooter()
	{
		$footer = $this->PageFooter;
		$this->Page_DataRendered($footer);
		if ($footer != "") { // Footer exists, display
			echo '<p id="ew-page-footer">' . $footer . '</p>';
		}
	}

	// Validate page request
	protected function isPageRequest()
	{
		global $CurrentForm;
		if ($this->UseTokenInUrl) {
			if ($CurrentForm)
				return ($this->TableVar == $CurrentForm->getValue("t"));
			if (Get("t") !== NULL)
				return ($this->TableVar == Get("t"));
		}
		return TRUE;
	}

	// Valid Post
	protected function validPost()
	{
		if (!$this->CheckToken || !IsPost() || IsApi())
			return TRUE;
		if (Post(Config("TOKEN_NAME")) === NULL)
			return FALSE;
		$fn = Config("CHECK_TOKEN_FUNC");
		if (is_callable($fn))
			return $fn(Post(Config("TOKEN_NAME")), $this->TokenTimeout);
		return FALSE;
	}

	// Create Token
	public function createToken()
	{
		global $CurrentToken;
		$fn = Config("CREATE_TOKEN_FUNC"); // Always create token, required by API file/lookup request
		if ($this->Token == "" && is_callable($fn)) // Create token
			$this->Token = $fn();
		$CurrentToken = $this->Token; // Save to global variable
	}

	// Constructor
	public function __construct()
	{
		global $Language, $DashboardReport;
		global $UserTable;

		// Check token
		$this->CheckToken = Config("CHECK_TOKEN");

		// Initialize
		$GLOBALS["Page"] = &$this;
		$this->TokenTimeout = SessionTimeoutTime();

		// Language object
		if (!isset($Language))
			$Language = new Language();

		// Parent constuctor
		parent::__construct();

		// Table object (billinghistory)
		if (!isset($GLOBALS["billinghistory"]) || get_class($GLOBALS["billinghistory"]) == PROJECT_NAMESPACE . "billinghistory") {
			$GLOBALS["billinghistory"] = &$this;
			$GLOBALS["Table"] = &$GLOBALS["billinghistory"];
		}

		// Table object (admin)
		if (!isset($GLOBALS['admin']))
			$GLOBALS['admin'] = new admin();

		// Page ID (for backward compatibility only)
		if (!defined(PROJECT_NAMESPACE . "PAGE_ID"))
			define(PROJECT_NAMESPACE . "PAGE_ID", 'edit');

		// Table name (for backward compatibility only)
		if (!defined(PROJECT_NAMESPACE . "TABLE_NAME"))
			define(PROJECT_NAMESPACE . "TABLE_NAME", 'billinghistory');

		// Start timer
		if (!isset($GLOBALS["DebugTimer"]))
			$GLOBALS["DebugTimer"] = new Timer();

		// Debug message
		LoadDebugMessage();

		// Open connection
		if (!isset($GLOBALS["Conn"]))
			$GLOBALS["Conn"] = $this->getConnection();

		// User table object (admin)
		$UserTable = $UserTable ?: new admin();
	}

	// Terminate page
	public function terminate($url = "")
	{
		global $ExportFileName, $TempImages, $DashboardReport;

		// Page Unload event
		$this->Page_Unload();

		// Global Page Unloaded event (in userfn*.php)
		Page_Unloaded();

		// Export
		global $billinghistory;
		if ($this->CustomExport && $this->CustomExport == $this->Export && array_key_exists($this->CustomExport, Config("EXPORT_CLASSES"))) {
				$content = ob_get_contents();
			if ($ExportFileName == "")
				$ExportFileName = $this->TableVar;
			$class = PROJECT_NAMESPACE . Config("EXPORT_CLASSES." . $this->CustomExport);
			if (class_exists($class)) {
				$doc = new $class($billinghistory);
				$doc->Text = @$content;
				if ($this->isExport("email"))
					echo $this->exportEmail($doc->Text);
				else
					$doc->export();
				DeleteTempImages(); // Delete temp images
				exit();
			}
		}
		if (!IsApi())
			$this->Page_Redirecting($url);

		// Close connection
		CloseConnections();

		// Return for API
		if (IsApi()) {
			$res = $url === TRUE;
			if (!$res) // Show error
				WriteJson(array_merge(["success" => FALSE], $this->getMessages()));
			return;
		}

		// Go to URL if specified
		if ($url != "") {
			if (!Config("DEBUG") && ob_get_length())
				ob_end_clean();

			// Handle modal response
			if ($this->IsModal) { // Show as modal
				$row = ["url" => $url, "modal" => "1"];
				$pageName = GetPageName($url);
				if ($pageName != $this->getListUrl()) { // Not List page
					$row["caption"] = $this->getModalCaption($pageName);
					if ($pageName == "billinghistoryview.php")
						$row["view"] = "1";
				} else { // List page should not be shown as modal => error
					$row["error"] = $this->getFailureMessage();
					$this->clearFailureMessage();
				}
				WriteJson($row);
			} else {
				SaveDebugMessage();
				AddHeader("Location", $url);
			}
		}
		exit();
	}

	// Get records from recordset
	protected function getRecordsFromRecordset($rs, $current = FALSE)
	{
		$rows = [];
		if (is_object($rs)) { // Recordset
			while ($rs && !$rs->EOF) {
				$this->loadRowValues($rs); // Set up DbValue/CurrentValue
				$row = $this->getRecordFromArray($rs->fields);
				if ($current)
					return $row;
				else
					$rows[] = $row;
				$rs->moveNext();
			}
		} elseif (is_array($rs)) {
			foreach ($rs as $ar) {
				$row = $this->getRecordFromArray($ar);
				if ($current)
					return $row;
				else
					$rows[] = $row;
			}
		}
		return $rows;
	}

	// Get record from array
	protected function getRecordFromArray($ar)
	{
		$row = [];
		if (is_array($ar)) {
			foreach ($ar as $fldname => $val) {
				if (array_key_exists($fldname, $this->fields) && ($this->fields[$fldname]->Visible || $this->fields[$fldname]->IsPrimaryKey)) { // Primary key or Visible
					$fld = &$this->fields[$fldname];
					if ($fld->HtmlTag == "FILE") { // Upload field
						if (EmptyValue($val)) {
							$row[$fldname] = NULL;
						} else {
							if ($fld->DataType == DATATYPE_BLOB) {
								$url = FullUrl(GetApiUrl(Config("API_FILE_ACTION"),
									Config("API_OBJECT_NAME") . "=" . $fld->TableVar . "&" .
									Config("API_FIELD_NAME") . "=" . $fld->Param . "&" .
									Config("API_KEY_NAME") . "=" . rawurlencode($this->getRecordKeyValue($ar)))); //*** need to add this? API may not be in the same folder
								$row[$fldname] = ["type" => ContentType($val), "url" => $url, "name" => $fld->Param . ContentExtension($val)];
							} elseif (!$fld->UploadMultiple || !ContainsString($val, Config("MULTIPLE_UPLOAD_SEPARATOR"))) { // Single file
								$url = FullUrl(GetApiUrl(Config("API_FILE_ACTION"),
									Config("API_OBJECT_NAME") . "=" . $fld->TableVar . "&" .
									"fn=" . Encrypt($fld->physicalUploadPath() . $val)));
								$row[$fldname] = ["type" => MimeContentType($val), "url" => $url, "name" => $val];
							} else { // Multiple files
								$files = explode(Config("MULTIPLE_UPLOAD_SEPARATOR"), $val);
								$ar = [];
								foreach ($files as $file) {
									$url = FullUrl(GetApiUrl(Config("API_FILE_ACTION"),
										Config("API_OBJECT_NAME") . "=" . $fld->TableVar . "&" .
										"fn=" . Encrypt($fld->physicalUploadPath() . $file)));
									if (!EmptyValue($file))
										$ar[] = ["type" => MimeContentType($file), "url" => $url, "name" => $file];
								}
								$row[$fldname] = $ar;
							}
						}
					} else {
						$row[$fldname] = $val;
					}
				}
			}
		}
		return $row;
	}

	// Get record key value from array
	protected function getRecordKeyValue($ar)
	{
		$key = "";
		if (is_array($ar)) {
			$key .= @$ar['recid'];
		}
		return $key;
	}

	/**
	 * Hide fields for add/edit
	 *
	 * @return void
	 */
	protected function hideFieldsForAddEdit()
	{
		if ($this->isAdd() || $this->isCopy() || $this->isGridAdd())
			$this->recid->Visible = FALSE;
	}

	// Lookup data
	public function lookup()
	{
		global $Language, $Security;
		if (!isset($Language))
			$Language = new Language(Config("LANGUAGE_FOLDER"), Post("language", ""));

		// Set up API request
		if (!ValidApiRequest())
			return FALSE;
		$this->setupApiSecurity();

		// Get lookup object
		$fieldName = Post("field");
		if (!array_key_exists($fieldName, $this->fields))
			return FALSE;
		$lookupField = $this->fields[$fieldName];
		$lookup = $lookupField->Lookup;
		if ($lookup === NULL)
			return FALSE;
		$tbl = $lookup->getTable();
		if (!$Security->allowLookup(Config("PROJECT_ID") . $tbl->TableName)) // Lookup permission
			return FALSE;

		// Get lookup parameters
		$lookupType = Post("ajax", "unknown");
		$pageSize = -1;
		$offset = -1;
		$searchValue = "";
		if (SameText($lookupType, "modal")) {
			$searchValue = Post("sv", "");
			$pageSize = Post("recperpage", 10);
			$offset = Post("start", 0);
		} elseif (SameText($lookupType, "autosuggest")) {
			$searchValue = Param("q", "");
			$pageSize = Param("n", -1);
			$pageSize = is_numeric($pageSize) ? (int)$pageSize : -1;
			if ($pageSize <= 0)
				$pageSize = Config("AUTO_SUGGEST_MAX_ENTRIES");
			$start = Param("start", -1);
			$start = is_numeric($start) ? (int)$start : -1;
			$page = Param("page", -1);
			$page = is_numeric($page) ? (int)$page : -1;
			$offset = $start >= 0 ? $start : ($page > 0 && $pageSize > 0 ? ($page - 1) * $pageSize : 0);
		}
		$userSelect = Decrypt(Post("s", ""));
		$userFilter = Decrypt(Post("f", ""));
		$userOrderBy = Decrypt(Post("o", ""));
		$keys = Post("keys");
		$lookup->LookupType = $lookupType; // Lookup type
		if ($keys !== NULL) { // Selected records from modal
			if (is_array($keys))
				$keys = implode(Config("MULTIPLE_OPTION_SEPARATOR"), $keys);
			$lookup->FilterFields = []; // Skip parent fields if any
			$lookup->FilterValues[] = $keys; // Lookup values
			$pageSize = -1; // Show all records
		} else { // Lookup values
			$lookup->FilterValues[] = Post("v0", Post("lookupValue", ""));
		}
		$cnt = is_array($lookup->FilterFields) ? count($lookup->FilterFields) : 0;
		for ($i = 1; $i <= $cnt; $i++)
			$lookup->FilterValues[] = Post("v" . $i, "");
		$lookup->SearchValue = $searchValue;
		$lookup->PageSize = $pageSize;
		$lookup->Offset = $offset;
		if ($userSelect != "")
			$lookup->UserSelect = $userSelect;
		if ($userFilter != "")
			$lookup->UserFilter = $userFilter;
		if ($userOrderBy != "")
			$lookup->UserOrderBy = $userOrderBy;
		$lookup->toJson($this); // Use settings from current page
	}

	// Set up API security
	public function setupApiSecurity()
	{
		global $Security;

		// Setup security for API request
		if ($Security->isLoggedIn()) $Security->TablePermission_Loading();
		$Security->loadCurrentUserLevel(Config("PROJECT_ID") . $this->TableName);
		if ($Security->isLoggedIn()) $Security->TablePermission_Loaded();
	}
	public $FormClassName = "ew-horizontal ew-form ew-edit-form";
	public $IsModal = FALSE;
	public $IsMobileOrModal = FALSE;
	public $DbMasterFilter;
	public $DbDetailFilter;

	//
	// Page run
	//

	public function run()
	{
		global $ExportType, $CustomExportType, $ExportFileName, $UserProfile, $Language, $Security, $CurrentForm,
			$FormError, $SkipHeaderFooter;

		// Is modal
		$this->IsModal = (Param("modal") == "1");

		// User profile
		$UserProfile = new UserProfile();

		// Security
		if (ValidApiRequest()) { // API request
			$this->setupApiSecurity(); // Set up API Security
			if (!$Security->canEdit()) {
				SetStatus(401); // Unauthorized
				return;
			}
		} else {
			$Security = new AdvancedSecurity();
			if (IsPasswordExpired())
				$this->terminate(GetUrl("changepwd.php"));
			if (!$Security->isLoggedIn())
				$Security->autoLogin();
			if ($Security->isLoggedIn())
				$Security->TablePermission_Loading();
			$Security->loadCurrentUserLevel($this->ProjectID . $this->TableName);
			if ($Security->isLoggedIn())
				$Security->TablePermission_Loaded();
			if (!$Security->canEdit()) {
				$Security->saveLastUrl();
				$this->setFailureMessage(DeniedMessage()); // Set no permission
				if ($Security->canList())
					$this->terminate(GetUrl("billinghistorylist.php"));
				else
					$this->terminate(GetUrl("login.php"));
				return;
			}
		}

		// Create form object
		$CurrentForm = new HttpForm();
		$this->CurrentAction = Param("action"); // Set up current action
		$this->recid->setVisibility();
		$this->serviceid->setVisibility();
		$this->brokerid->setVisibility();
		$this->customeracctno->setVisibility();
		$this->currcode->setVisibility();
		$this->amount->Visible = FALSE;
		$this->balance->setVisibility();
		$this->confcode->setVisibility();
		$this->success->setVisibility();
		$this->transdate->setVisibility();
		$this->_userid->setVisibility();
		$this->billerresponse->setVisibility();
		$this->paymenttype->setVisibility();
		$this->customername->setVisibility();
		$this->parentuserid->setVisibility();
		$this->refno->setVisibility();
		$this->feeid->setVisibility();
		$this->_tabletype->setVisibility();
		$this->feemerchanttotal->setVisibility();
		$this->feeconsumertotal->setVisibility();
		$this->feesystemtotal->setVisibility();
		$this->feeexternaltotal->setVisibility();
		$this->feefranchiseetotal->setVisibility();
		$this->feeresellertotal->setVisibility();
		$this->branchname->setVisibility();
		$this->clerkname->setVisibility();
		$this->taxamount->setVisibility();
		$this->totalamount->setVisibility();
		$this->taxperc->setVisibility();
		$this->txgroupid->Visible = FALSE;
		$this->otherdetails->setVisibility();
		$this->transgroupid->setVisibility();
		$this->department->setVisibility();
		$this->billingresponse2->setVisibility();
		$this->purchaseid->setVisibility();
		$this->paymentid->setVisibility();
		$this->hideFieldsForAddEdit();

		// Do not use lookup cache
		$this->setUseLookupCache(FALSE);

		// Global Page Loading event (in userfn*.php)
		Page_Loading();

		// Page Load event
		$this->Page_Load();

		// Check token
		if (!$this->validPost()) {
			Write($Language->phrase("InvalidPostRequest"));
			$this->terminate();
		}

		// Create Token
		$this->createToken();

		// Set up lookup cache
		$this->setupLookupOptions($this->serviceid);
		$this->setupLookupOptions($this->success);
		$this->setupLookupOptions($this->department);

		// Check permission
		if (!$Security->canEdit()) {
			$this->setFailureMessage(DeniedMessage()); // No permission
			$this->terminate("billinghistorylist.php");
			return;
		}

		// Check modal
		if ($this->IsModal)
			$SkipHeaderFooter = TRUE;
		$this->IsMobileOrModal = IsMobile() || $this->IsModal;
		$this->FormClassName = "ew-form ew-edit-form ew-horizontal";
		$loaded = FALSE;
		$postBack = FALSE;

		// Set up current action and primary key
		if (IsApi()) {

			// Load key values
			$loaded = TRUE;
			if (Get("recid") !== NULL) {
				$this->recid->setQueryStringValue(Get("recid"));
				$this->recid->setOldValue($this->recid->QueryStringValue);
			} elseif (Key(0) !== NULL) {
				$this->recid->setQueryStringValue(Key(0));
				$this->recid->setOldValue($this->recid->QueryStringValue);
			} elseif (Post("recid") !== NULL) {
				$this->recid->setFormValue(Post("recid"));
				$this->recid->setOldValue($this->recid->FormValue);
			} elseif (Route(2) !== NULL) {
				$this->recid->setQueryStringValue(Route(2));
				$this->recid->setOldValue($this->recid->QueryStringValue);
			} else {
				$loaded = FALSE; // Unable to load key
			}

			// Load record
			if ($loaded)
				$loaded = $this->loadRow();
			if (!$loaded) {
				$this->setFailureMessage($Language->phrase("NoRecord")); // Set no record message
				$this->terminate();
				return;
			}
			$this->CurrentAction = "update"; // Update record directly
			$postBack = TRUE;
		} else {
			if (Post("action") !== NULL) {
				$this->CurrentAction = Post("action"); // Get action code
				if (!$this->isShow()) // Not reload record, handle as postback
					$postBack = TRUE;

				// Load key from Form
				if ($CurrentForm->hasValue("x_recid")) {
					$this->recid->setFormValue($CurrentForm->getValue("x_recid"));
				}
			} else {
				$this->CurrentAction = "show"; // Default action is display

				// Load key from QueryString / Route
				$loadByQuery = FALSE;
				if (Get("recid") !== NULL) {
					$this->recid->setQueryStringValue(Get("recid"));
					$loadByQuery = TRUE;
				} elseif (Route(2) !== NULL) {
					$this->recid->setQueryStringValue(Route(2));
					$loadByQuery = TRUE;
				} else {
					$this->recid->CurrentValue = NULL;
				}
			}

			// Load current record
			$loaded = $this->loadRow();
		}

		// Process form if post back
		if ($postBack) {
			$this->loadFormValues(); // Get form values
		}

		// Validate form if post back
		if ($postBack) {
			if (!$this->validateForm()) {
				$this->setFailureMessage($FormError);
				$this->EventCancelled = TRUE; // Event cancelled
				$this->restoreFormValues();
				if (IsApi()) {
					$this->terminate();
					return;
				} else {
					$this->CurrentAction = ""; // Form error, reset action
				}
			}
		}

		// Perform current action
		switch ($this->CurrentAction) {
			case "show": // Get a record to display
				if (!$loaded) { // Load record based on key
					if ($this->getFailureMessage() == "")
						$this->setFailureMessage($Language->phrase("NoRecord")); // No record found
					$this->terminate("billinghistorylist.php"); // No matching record, return to list
				}
				break;
			case "update": // Update
				$returnUrl = $this->getReturnUrl();
				if (GetPageName($returnUrl) == "billinghistorylist.php")
					$returnUrl = $this->addMasterUrl($returnUrl); // List page, return to List page with correct master key if necessary
				$this->SendEmail = TRUE; // Send email on update success
				if ($this->editRow()) { // Update record based on key
					if ($this->getSuccessMessage() == "")
						$this->setSuccessMessage($Language->phrase("UpdateSuccess")); // Update success
					if (IsApi()) {
						$this->terminate(TRUE);
						return;
					} else {
						$this->terminate($returnUrl); // Return to caller
					}
				} elseif (IsApi()) { // API request, return
					$this->terminate();
					return;
				} elseif ($this->getFailureMessage() == $Language->phrase("NoRecord")) {
					$this->terminate($returnUrl); // Return to caller
				} else {
					$this->EventCancelled = TRUE; // Event cancelled
					$this->restoreFormValues(); // Restore form values if update failed
				}
		}

		// Set up Breadcrumb
		$this->setupBreadcrumb();

		// Render the record
		$this->RowType = ROWTYPE_EDIT; // Render as Edit
		$this->resetAttributes();
		$this->renderRow();
	}

	// Get upload files
	protected function getUploadFiles()
	{
		global $CurrentForm, $Language;
	}

	// Load form values
	protected function loadFormValues()
	{

		// Load from form
		global $CurrentForm;

		// Check field name 'recid' first before field var 'x_recid'
		$val = $CurrentForm->hasValue("recid") ? $CurrentForm->getValue("recid") : $CurrentForm->getValue("x_recid");
		if (!$this->recid->IsDetailKey)
			$this->recid->setFormValue($val);

		// Check field name 'serviceid' first before field var 'x_serviceid'
		$val = $CurrentForm->hasValue("serviceid") ? $CurrentForm->getValue("serviceid") : $CurrentForm->getValue("x_serviceid");
		if (!$this->serviceid->IsDetailKey) {
			if (IsApi() && $val === NULL)
				$this->serviceid->Visible = FALSE; // Disable update for API request
			else
				$this->serviceid->setFormValue($val);
		}

		// Check field name 'brokerid' first before field var 'x_brokerid'
		$val = $CurrentForm->hasValue("brokerid") ? $CurrentForm->getValue("brokerid") : $CurrentForm->getValue("x_brokerid");
		if (!$this->brokerid->IsDetailKey) {
			if (IsApi() && $val === NULL)
				$this->brokerid->Visible = FALSE; // Disable update for API request
			else
				$this->brokerid->setFormValue($val);
		}

		// Check field name 'customeracctno' first before field var 'x_customeracctno'
		$val = $CurrentForm->hasValue("customeracctno") ? $CurrentForm->getValue("customeracctno") : $CurrentForm->getValue("x_customeracctno");
		if (!$this->customeracctno->IsDetailKey) {
			if (IsApi() && $val === NULL)
				$this->customeracctno->Visible = FALSE; // Disable update for API request
			else
				$this->customeracctno->setFormValue($val);
		}

		// Check field name 'currcode' first before field var 'x_currcode'
		$val = $CurrentForm->hasValue("currcode") ? $CurrentForm->getValue("currcode") : $CurrentForm->getValue("x_currcode");
		if (!$this->currcode->IsDetailKey) {
			if (IsApi() && $val === NULL)
				$this->currcode->Visible = FALSE; // Disable update for API request
			else
				$this->currcode->setFormValue($val);
		}

		// Check field name 'balance' first before field var 'x_balance'
		$val = $CurrentForm->hasValue("balance") ? $CurrentForm->getValue("balance") : $CurrentForm->getValue("x_balance");
		if (!$this->balance->IsDetailKey) {
			if (IsApi() && $val === NULL)
				$this->balance->Visible = FALSE; // Disable update for API request
			else
				$this->balance->setFormValue($val);
		}

		// Check field name 'confcode' first before field var 'x_confcode'
		$val = $CurrentForm->hasValue("confcode") ? $CurrentForm->getValue("confcode") : $CurrentForm->getValue("x_confcode");
		if (!$this->confcode->IsDetailKey) {
			if (IsApi() && $val === NULL)
				$this->confcode->Visible = FALSE; // Disable update for API request
			else
				$this->confcode->setFormValue($val);
		}

		// Check field name 'success' first before field var 'x_success'
		$val = $CurrentForm->hasValue("success") ? $CurrentForm->getValue("success") : $CurrentForm->getValue("x_success");
		if (!$this->success->IsDetailKey) {
			if (IsApi() && $val === NULL)
				$this->success->Visible = FALSE; // Disable update for API request
			else
				$this->success->setFormValue($val);
		}

		// Check field name 'transdate' first before field var 'x_transdate'
		$val = $CurrentForm->hasValue("transdate") ? $CurrentForm->getValue("transdate") : $CurrentForm->getValue("x_transdate");
		if (!$this->transdate->IsDetailKey) {
			if (IsApi() && $val === NULL)
				$this->transdate->Visible = FALSE; // Disable update for API request
			else
				$this->transdate->setFormValue($val);
			$this->transdate->CurrentValue = UnFormatDateTime($this->transdate->CurrentValue, 2);
		}

		// Check field name 'userid' first before field var 'x__userid'
		$val = $CurrentForm->hasValue("userid") ? $CurrentForm->getValue("userid") : $CurrentForm->getValue("x__userid");
		if (!$this->_userid->IsDetailKey) {
			if (IsApi() && $val === NULL)
				$this->_userid->Visible = FALSE; // Disable update for API request
			else
				$this->_userid->setFormValue($val);
		}

		// Check field name 'billerresponse' first before field var 'x_billerresponse'
		$val = $CurrentForm->hasValue("billerresponse") ? $CurrentForm->getValue("billerresponse") : $CurrentForm->getValue("x_billerresponse");
		if (!$this->billerresponse->IsDetailKey) {
			if (IsApi() && $val === NULL)
				$this->billerresponse->Visible = FALSE; // Disable update for API request
			else
				$this->billerresponse->setFormValue($val);
		}

		// Check field name 'paymenttype' first before field var 'x_paymenttype'
		$val = $CurrentForm->hasValue("paymenttype") ? $CurrentForm->getValue("paymenttype") : $CurrentForm->getValue("x_paymenttype");
		if (!$this->paymenttype->IsDetailKey) {
			if (IsApi() && $val === NULL)
				$this->paymenttype->Visible = FALSE; // Disable update for API request
			else
				$this->paymenttype->setFormValue($val);
		}

		// Check field name 'customername' first before field var 'x_customername'
		$val = $CurrentForm->hasValue("customername") ? $CurrentForm->getValue("customername") : $CurrentForm->getValue("x_customername");
		if (!$this->customername->IsDetailKey) {
			if (IsApi() && $val === NULL)
				$this->customername->Visible = FALSE; // Disable update for API request
			else
				$this->customername->setFormValue($val);
		}

		// Check field name 'parentuserid' first before field var 'x_parentuserid'
		$val = $CurrentForm->hasValue("parentuserid") ? $CurrentForm->getValue("parentuserid") : $CurrentForm->getValue("x_parentuserid");
		if (!$this->parentuserid->IsDetailKey) {
			if (IsApi() && $val === NULL)
				$this->parentuserid->Visible = FALSE; // Disable update for API request
			else
				$this->parentuserid->setFormValue($val);
		}

		// Check field name 'refno' first before field var 'x_refno'
		$val = $CurrentForm->hasValue("refno") ? $CurrentForm->getValue("refno") : $CurrentForm->getValue("x_refno");
		if (!$this->refno->IsDetailKey) {
			if (IsApi() && $val === NULL)
				$this->refno->Visible = FALSE; // Disable update for API request
			else
				$this->refno->setFormValue($val);
		}

		// Check field name 'feeid' first before field var 'x_feeid'
		$val = $CurrentForm->hasValue("feeid") ? $CurrentForm->getValue("feeid") : $CurrentForm->getValue("x_feeid");
		if (!$this->feeid->IsDetailKey) {
			if (IsApi() && $val === NULL)
				$this->feeid->Visible = FALSE; // Disable update for API request
			else
				$this->feeid->setFormValue($val);
		}

		// Check field name 'tabletype' first before field var 'x__tabletype'
		$val = $CurrentForm->hasValue("tabletype") ? $CurrentForm->getValue("tabletype") : $CurrentForm->getValue("x__tabletype");
		if (!$this->_tabletype->IsDetailKey) {
			if (IsApi() && $val === NULL)
				$this->_tabletype->Visible = FALSE; // Disable update for API request
			else
				$this->_tabletype->setFormValue($val);
		}

		// Check field name 'feemerchanttotal' first before field var 'x_feemerchanttotal'
		$val = $CurrentForm->hasValue("feemerchanttotal") ? $CurrentForm->getValue("feemerchanttotal") : $CurrentForm->getValue("x_feemerchanttotal");
		if (!$this->feemerchanttotal->IsDetailKey) {
			if (IsApi() && $val === NULL)
				$this->feemerchanttotal->Visible = FALSE; // Disable update for API request
			else
				$this->feemerchanttotal->setFormValue($val);
		}

		// Check field name 'feeconsumertotal' first before field var 'x_feeconsumertotal'
		$val = $CurrentForm->hasValue("feeconsumertotal") ? $CurrentForm->getValue("feeconsumertotal") : $CurrentForm->getValue("x_feeconsumertotal");
		if (!$this->feeconsumertotal->IsDetailKey) {
			if (IsApi() && $val === NULL)
				$this->feeconsumertotal->Visible = FALSE; // Disable update for API request
			else
				$this->feeconsumertotal->setFormValue($val);
		}

		// Check field name 'feesystemtotal' first before field var 'x_feesystemtotal'
		$val = $CurrentForm->hasValue("feesystemtotal") ? $CurrentForm->getValue("feesystemtotal") : $CurrentForm->getValue("x_feesystemtotal");
		if (!$this->feesystemtotal->IsDetailKey) {
			if (IsApi() && $val === NULL)
				$this->feesystemtotal->Visible = FALSE; // Disable update for API request
			else
				$this->feesystemtotal->setFormValue($val);
		}

		// Check field name 'feeexternaltotal' first before field var 'x_feeexternaltotal'
		$val = $CurrentForm->hasValue("feeexternaltotal") ? $CurrentForm->getValue("feeexternaltotal") : $CurrentForm->getValue("x_feeexternaltotal");
		if (!$this->feeexternaltotal->IsDetailKey) {
			if (IsApi() && $val === NULL)
				$this->feeexternaltotal->Visible = FALSE; // Disable update for API request
			else
				$this->feeexternaltotal->setFormValue($val);
		}

		// Check field name 'feefranchiseetotal' first before field var 'x_feefranchiseetotal'
		$val = $CurrentForm->hasValue("feefranchiseetotal") ? $CurrentForm->getValue("feefranchiseetotal") : $CurrentForm->getValue("x_feefranchiseetotal");
		if (!$this->feefranchiseetotal->IsDetailKey) {
			if (IsApi() && $val === NULL)
				$this->feefranchiseetotal->Visible = FALSE; // Disable update for API request
			else
				$this->feefranchiseetotal->setFormValue($val);
		}

		// Check field name 'feeresellertotal' first before field var 'x_feeresellertotal'
		$val = $CurrentForm->hasValue("feeresellertotal") ? $CurrentForm->getValue("feeresellertotal") : $CurrentForm->getValue("x_feeresellertotal");
		if (!$this->feeresellertotal->IsDetailKey) {
			if (IsApi() && $val === NULL)
				$this->feeresellertotal->Visible = FALSE; // Disable update for API request
			else
				$this->feeresellertotal->setFormValue($val);
		}

		// Check field name 'branchname' first before field var 'x_branchname'
		$val = $CurrentForm->hasValue("branchname") ? $CurrentForm->getValue("branchname") : $CurrentForm->getValue("x_branchname");
		if (!$this->branchname->IsDetailKey) {
			if (IsApi() && $val === NULL)
				$this->branchname->Visible = FALSE; // Disable update for API request
			else
				$this->branchname->setFormValue($val);
		}

		// Check field name 'clerkname' first before field var 'x_clerkname'
		$val = $CurrentForm->hasValue("clerkname") ? $CurrentForm->getValue("clerkname") : $CurrentForm->getValue("x_clerkname");
		if (!$this->clerkname->IsDetailKey) {
			if (IsApi() && $val === NULL)
				$this->clerkname->Visible = FALSE; // Disable update for API request
			else
				$this->clerkname->setFormValue($val);
		}

		// Check field name 'taxamount' first before field var 'x_taxamount'
		$val = $CurrentForm->hasValue("taxamount") ? $CurrentForm->getValue("taxamount") : $CurrentForm->getValue("x_taxamount");
		if (!$this->taxamount->IsDetailKey) {
			if (IsApi() && $val === NULL)
				$this->taxamount->Visible = FALSE; // Disable update for API request
			else
				$this->taxamount->setFormValue($val);
		}

		// Check field name 'totalamount' first before field var 'x_totalamount'
		$val = $CurrentForm->hasValue("totalamount") ? $CurrentForm->getValue("totalamount") : $CurrentForm->getValue("x_totalamount");
		if (!$this->totalamount->IsDetailKey) {
			if (IsApi() && $val === NULL)
				$this->totalamount->Visible = FALSE; // Disable update for API request
			else
				$this->totalamount->setFormValue($val);
		}

		// Check field name 'taxperc' first before field var 'x_taxperc'
		$val = $CurrentForm->hasValue("taxperc") ? $CurrentForm->getValue("taxperc") : $CurrentForm->getValue("x_taxperc");
		if (!$this->taxperc->IsDetailKey) {
			if (IsApi() && $val === NULL)
				$this->taxperc->Visible = FALSE; // Disable update for API request
			else
				$this->taxperc->setFormValue($val);
		}

		// Check field name 'otherdetails' first before field var 'x_otherdetails'
		$val = $CurrentForm->hasValue("otherdetails") ? $CurrentForm->getValue("otherdetails") : $CurrentForm->getValue("x_otherdetails");
		if (!$this->otherdetails->IsDetailKey) {
			if (IsApi() && $val === NULL)
				$this->otherdetails->Visible = FALSE; // Disable update for API request
			else
				$this->otherdetails->setFormValue($val);
		}

		// Check field name 'transgroupid' first before field var 'x_transgroupid'
		$val = $CurrentForm->hasValue("transgroupid") ? $CurrentForm->getValue("transgroupid") : $CurrentForm->getValue("x_transgroupid");
		if (!$this->transgroupid->IsDetailKey) {
			if (IsApi() && $val === NULL)
				$this->transgroupid->Visible = FALSE; // Disable update for API request
			else
				$this->transgroupid->setFormValue($val);
		}

		// Check field name 'department' first before field var 'x_department'
		$val = $CurrentForm->hasValue("department") ? $CurrentForm->getValue("department") : $CurrentForm->getValue("x_department");
		if (!$this->department->IsDetailKey) {
			if (IsApi() && $val === NULL)
				$this->department->Visible = FALSE; // Disable update for API request
			else
				$this->department->setFormValue($val);
		}

		// Check field name 'billingresponse2' first before field var 'x_billingresponse2'
		$val = $CurrentForm->hasValue("billingresponse2") ? $CurrentForm->getValue("billingresponse2") : $CurrentForm->getValue("x_billingresponse2");
		if (!$this->billingresponse2->IsDetailKey) {
			if (IsApi() && $val === NULL)
				$this->billingresponse2->Visible = FALSE; // Disable update for API request
			else
				$this->billingresponse2->setFormValue($val);
		}

		// Check field name 'purchaseid' first before field var 'x_purchaseid'
		$val = $CurrentForm->hasValue("purchaseid") ? $CurrentForm->getValue("purchaseid") : $CurrentForm->getValue("x_purchaseid");
		if (!$this->purchaseid->IsDetailKey) {
			if (IsApi() && $val === NULL)
				$this->purchaseid->Visible = FALSE; // Disable update for API request
			else
				$this->purchaseid->setFormValue($val);
		}

		// Check field name 'paymentid' first before field var 'x_paymentid'
		$val = $CurrentForm->hasValue("paymentid") ? $CurrentForm->getValue("paymentid") : $CurrentForm->getValue("x_paymentid");
		if (!$this->paymentid->IsDetailKey) {
			if (IsApi() && $val === NULL)
				$this->paymentid->Visible = FALSE; // Disable update for API request
			else
				$this->paymentid->setFormValue($val);
		}
	}

	// Restore form values
	public function restoreFormValues()
	{
		global $CurrentForm;
		$this->recid->CurrentValue = $this->recid->FormValue;
		$this->serviceid->CurrentValue = $this->serviceid->FormValue;
		$this->brokerid->CurrentValue = $this->brokerid->FormValue;
		$this->customeracctno->CurrentValue = $this->customeracctno->FormValue;
		$this->currcode->CurrentValue = $this->currcode->FormValue;
		$this->balance->CurrentValue = $this->balance->FormValue;
		$this->confcode->CurrentValue = $this->confcode->FormValue;
		$this->success->CurrentValue = $this->success->FormValue;
		$this->transdate->CurrentValue = $this->transdate->FormValue;
		$this->transdate->CurrentValue = UnFormatDateTime($this->transdate->CurrentValue, 2);
		$this->_userid->CurrentValue = $this->_userid->FormValue;
		$this->billerresponse->CurrentValue = $this->billerresponse->FormValue;
		$this->paymenttype->CurrentValue = $this->paymenttype->FormValue;
		$this->customername->CurrentValue = $this->customername->FormValue;
		$this->parentuserid->CurrentValue = $this->parentuserid->FormValue;
		$this->refno->CurrentValue = $this->refno->FormValue;
		$this->feeid->CurrentValue = $this->feeid->FormValue;
		$this->_tabletype->CurrentValue = $this->_tabletype->FormValue;
		$this->feemerchanttotal->CurrentValue = $this->feemerchanttotal->FormValue;
		$this->feeconsumertotal->CurrentValue = $this->feeconsumertotal->FormValue;
		$this->feesystemtotal->CurrentValue = $this->feesystemtotal->FormValue;
		$this->feeexternaltotal->CurrentValue = $this->feeexternaltotal->FormValue;
		$this->feefranchiseetotal->CurrentValue = $this->feefranchiseetotal->FormValue;
		$this->feeresellertotal->CurrentValue = $this->feeresellertotal->FormValue;
		$this->branchname->CurrentValue = $this->branchname->FormValue;
		$this->clerkname->CurrentValue = $this->clerkname->FormValue;
		$this->taxamount->CurrentValue = $this->taxamount->FormValue;
		$this->totalamount->CurrentValue = $this->totalamount->FormValue;
		$this->taxperc->CurrentValue = $this->taxperc->FormValue;
		$this->otherdetails->CurrentValue = $this->otherdetails->FormValue;
		$this->transgroupid->CurrentValue = $this->transgroupid->FormValue;
		$this->department->CurrentValue = $this->department->FormValue;
		$this->billingresponse2->CurrentValue = $this->billingresponse2->FormValue;
		$this->purchaseid->CurrentValue = $this->purchaseid->FormValue;
		$this->paymentid->CurrentValue = $this->paymentid->FormValue;
	}

	// Load row based on key values
	public function loadRow()
	{
		global $Security, $Language;
		$filter = $this->getRecordFilter();

		// Call Row Selecting event
		$this->Row_Selecting($filter);

		// Load SQL based on filter
		$this->CurrentFilter = $filter;
		$sql = $this->getCurrentSql();
		$conn = $this->getConnection();
		$res = FALSE;
		$rs = LoadRecordset($sql, $conn);
		if ($rs && !$rs->EOF) {
			$res = TRUE;
			$this->loadRowValues($rs); // Load row values
			$rs->close();
		}
		return $res;
	}

	// Load row values from recordset
	public function loadRowValues($rs = NULL)
	{
		if ($rs && !$rs->EOF)
			$row = $rs->fields;
		else
			$row = $this->newRow();

		// Call Row Selected event
		$this->Row_Selected($row);
		if (!$rs || $rs->EOF)
			return;
		$this->recid->setDbValue($row['recid']);
		$this->serviceid->setDbValue($row['serviceid']);
		$this->brokerid->setDbValue($row['brokerid']);
		$this->customeracctno->setDbValue($row['customeracctno']);
		$this->currcode->setDbValue($row['currcode']);
		$this->amount->setDbValue($row['amount']);
		$this->balance->setDbValue($row['balance']);
		$this->confcode->setDbValue($row['confcode']);
		$this->success->setDbValue($row['success']);
		$this->transdate->setDbValue($row['transdate']);
		$this->_userid->setDbValue($row['userid']);
		$this->billerresponse->setDbValue($row['billerresponse']);
		$this->paymenttype->setDbValue($row['paymenttype']);
		$this->customername->setDbValue($row['customername']);
		$this->parentuserid->setDbValue($row['parentuserid']);
		$this->refno->setDbValue($row['refno']);
		$this->feeid->setDbValue($row['feeid']);
		$this->_tabletype->setDbValue($row['tabletype']);
		$this->feemerchanttotal->setDbValue($row['feemerchanttotal']);
		$this->feeconsumertotal->setDbValue($row['feeconsumertotal']);
		$this->feesystemtotal->setDbValue($row['feesystemtotal']);
		$this->feeexternaltotal->setDbValue($row['feeexternaltotal']);
		$this->feefranchiseetotal->setDbValue($row['feefranchiseetotal']);
		$this->feeresellertotal->setDbValue($row['feeresellertotal']);
		$this->branchname->setDbValue($row['branchname']);
		$this->clerkname->setDbValue($row['clerkname']);
		$this->taxamount->setDbValue($row['taxamount']);
		$this->totalamount->setDbValue($row['totalamount']);
		$this->taxperc->setDbValue($row['taxperc']);
		$this->txgroupid->setDbValue($row['txgroupid']);
		$this->otherdetails->setDbValue($row['otherdetails']);
		$this->transgroupid->setDbValue($row['transgroupid']);
		$this->department->setDbValue($row['department']);
		$this->billingresponse2->setDbValue($row['billingresponse2']);
		$this->purchaseid->setDbValue($row['purchaseid']);
		$this->paymentid->setDbValue($row['paymentid']);
	}

	// Return a row with default values
	protected function newRow()
	{
		$row = [];
		$row['recid'] = NULL;
		$row['serviceid'] = NULL;
		$row['brokerid'] = NULL;
		$row['customeracctno'] = NULL;
		$row['currcode'] = NULL;
		$row['amount'] = NULL;
		$row['balance'] = NULL;
		$row['confcode'] = NULL;
		$row['success'] = NULL;
		$row['transdate'] = NULL;
		$row['userid'] = NULL;
		$row['billerresponse'] = NULL;
		$row['paymenttype'] = NULL;
		$row['customername'] = NULL;
		$row['parentuserid'] = NULL;
		$row['refno'] = NULL;
		$row['feeid'] = NULL;
		$row['tabletype'] = NULL;
		$row['feemerchanttotal'] = NULL;
		$row['feeconsumertotal'] = NULL;
		$row['feesystemtotal'] = NULL;
		$row['feeexternaltotal'] = NULL;
		$row['feefranchiseetotal'] = NULL;
		$row['feeresellertotal'] = NULL;
		$row['branchname'] = NULL;
		$row['clerkname'] = NULL;
		$row['taxamount'] = NULL;
		$row['totalamount'] = NULL;
		$row['taxperc'] = NULL;
		$row['txgroupid'] = NULL;
		$row['otherdetails'] = NULL;
		$row['transgroupid'] = NULL;
		$row['department'] = NULL;
		$row['billingresponse2'] = NULL;
		$row['purchaseid'] = NULL;
		$row['paymentid'] = NULL;
		return $row;
	}

	// Load old record
	protected function loadOldRecord()
	{

		// Load key values from Session
		$validKey = TRUE;
		if (strval($this->getKey("recid")) != "")
			$this->recid->OldValue = $this->getKey("recid"); // recid
		else
			$validKey = FALSE;

		// Load old record
		$this->OldRecordset = NULL;
		if ($validKey) {
			$this->CurrentFilter = $this->getRecordFilter();
			$sql = $this->getCurrentSql();
			$conn = $this->getConnection();
			$this->OldRecordset = LoadRecordset($sql, $conn);
		}
		$this->loadRowValues($this->OldRecordset); // Load row values
		return $validKey;
	}

	// Render row values based on field settings
	public function renderRow()
	{
		global $Security, $Language, $CurrentLanguage;

		// Initialize URLs
		// Convert decimal values if posted back

		if ($this->balance->FormValue == $this->balance->CurrentValue && is_numeric(ConvertToFloatString($this->balance->CurrentValue)))
			$this->balance->CurrentValue = ConvertToFloatString($this->balance->CurrentValue);

		// Convert decimal values if posted back
		if ($this->feemerchanttotal->FormValue == $this->feemerchanttotal->CurrentValue && is_numeric(ConvertToFloatString($this->feemerchanttotal->CurrentValue)))
			$this->feemerchanttotal->CurrentValue = ConvertToFloatString($this->feemerchanttotal->CurrentValue);

		// Convert decimal values if posted back
		if ($this->feeconsumertotal->FormValue == $this->feeconsumertotal->CurrentValue && is_numeric(ConvertToFloatString($this->feeconsumertotal->CurrentValue)))
			$this->feeconsumertotal->CurrentValue = ConvertToFloatString($this->feeconsumertotal->CurrentValue);

		// Convert decimal values if posted back
		if ($this->feesystemtotal->FormValue == $this->feesystemtotal->CurrentValue && is_numeric(ConvertToFloatString($this->feesystemtotal->CurrentValue)))
			$this->feesystemtotal->CurrentValue = ConvertToFloatString($this->feesystemtotal->CurrentValue);

		// Convert decimal values if posted back
		if ($this->feeexternaltotal->FormValue == $this->feeexternaltotal->CurrentValue && is_numeric(ConvertToFloatString($this->feeexternaltotal->CurrentValue)))
			$this->feeexternaltotal->CurrentValue = ConvertToFloatString($this->feeexternaltotal->CurrentValue);

		// Convert decimal values if posted back
		if ($this->feefranchiseetotal->FormValue == $this->feefranchiseetotal->CurrentValue && is_numeric(ConvertToFloatString($this->feefranchiseetotal->CurrentValue)))
			$this->feefranchiseetotal->CurrentValue = ConvertToFloatString($this->feefranchiseetotal->CurrentValue);

		// Convert decimal values if posted back
		if ($this->feeresellertotal->FormValue == $this->feeresellertotal->CurrentValue && is_numeric(ConvertToFloatString($this->feeresellertotal->CurrentValue)))
			$this->feeresellertotal->CurrentValue = ConvertToFloatString($this->feeresellertotal->CurrentValue);

		// Convert decimal values if posted back
		if ($this->taxamount->FormValue == $this->taxamount->CurrentValue && is_numeric(ConvertToFloatString($this->taxamount->CurrentValue)))
			$this->taxamount->CurrentValue = ConvertToFloatString($this->taxamount->CurrentValue);

		// Convert decimal values if posted back
		if ($this->totalamount->FormValue == $this->totalamount->CurrentValue && is_numeric(ConvertToFloatString($this->totalamount->CurrentValue)))
			$this->totalamount->CurrentValue = ConvertToFloatString($this->totalamount->CurrentValue);

		// Convert decimal values if posted back
		if ($this->taxperc->FormValue == $this->taxperc->CurrentValue && is_numeric(ConvertToFloatString($this->taxperc->CurrentValue)))
			$this->taxperc->CurrentValue = ConvertToFloatString($this->taxperc->CurrentValue);

		// Call Row_Rendering event
		$this->Row_Rendering();

		// Common render codes for all row types
		// recid
		// serviceid
		// brokerid
		// customeracctno
		// currcode
		// amount
		// balance
		// confcode
		// success
		// transdate
		// userid
		// billerresponse
		// paymenttype
		// customername
		// parentuserid
		// refno
		// feeid
		// tabletype
		// feemerchanttotal
		// feeconsumertotal
		// feesystemtotal
		// feeexternaltotal
		// feefranchiseetotal
		// feeresellertotal
		// branchname
		// clerkname
		// taxamount
		// totalamount
		// taxperc
		// txgroupid
		// otherdetails
		// transgroupid
		// department
		// billingresponse2
		// purchaseid
		// paymentid

		if ($this->RowType == ROWTYPE_VIEW) { // View row

			// recid
			$this->recid->ViewValue = $this->recid->CurrentValue;
			$this->recid->ViewCustomAttributes = "";

			// serviceid
			$this->serviceid->ViewValue = $this->serviceid->CurrentValue;
			$curVal = strval($this->serviceid->CurrentValue);
			if ($curVal != "") {
				$this->serviceid->ViewValue = $this->serviceid->lookupCacheOption($curVal);
				if ($this->serviceid->ViewValue === NULL) { // Lookup from database
					$filterWrk = "`serviceid`" . SearchString("=", $curVal, DATATYPE_NUMBER, "_4payreference");
					$sqlWrk = $this->serviceid->Lookup->getSql(FALSE, $filterWrk, '', $this);
					$rswrk = Conn("_4payreference")->execute($sqlWrk);
					if ($rswrk && !$rswrk->EOF) { // Lookup values found
						$arwrk = [];
						$arwrk[1] = $rswrk->fields('df');
						$this->serviceid->ViewValue = $this->serviceid->displayValue($arwrk);
						$rswrk->Close();
					} else {
						$this->serviceid->ViewValue = $this->serviceid->CurrentValue;
					}
				}
			} else {
				$this->serviceid->ViewValue = NULL;
			}
			$this->serviceid->ViewCustomAttributes = "";

			// brokerid
			$this->brokerid->ViewValue = $this->brokerid->CurrentValue;
			$this->brokerid->ViewCustomAttributes = "";

			// customeracctno
			$this->customeracctno->ViewValue = $this->customeracctno->CurrentValue;
			$this->customeracctno->ViewCustomAttributes = "";

			// currcode
			$this->currcode->ViewValue = $this->currcode->CurrentValue;
			$this->currcode->ViewCustomAttributes = "";

			// amount
			$this->amount->ViewValue = $this->amount->CurrentValue;
			$this->amount->ViewValue = FormatNumber($this->amount->ViewValue, 0, -2, -2, -2);
			$this->amount->CellCssStyle .= "text-align: right;";
			$this->amount->ViewCustomAttributes = "";

			// balance
			$this->balance->ViewValue = $this->balance->CurrentValue;
			$this->balance->ViewValue = FormatNumber($this->balance->ViewValue, 0, -2, -2, -2);
			$this->balance->CellCssStyle .= "text-align: right;";
			$this->balance->ViewCustomAttributes = "";

			// confcode
			$this->confcode->ViewValue = $this->confcode->CurrentValue;
			$this->confcode->ViewCustomAttributes = "";

			// success
			$this->success->ViewValue = $this->success->CurrentValue;
			$curVal = strval($this->success->CurrentValue);
			if ($curVal != "") {
				$this->success->ViewValue = $this->success->lookupCacheOption($curVal);
				if ($this->success->ViewValue === NULL) { // Lookup from database
					$filterWrk = "`id`" . SearchString("=", $curVal, DATATYPE_NUMBER, "");
					$sqlWrk = $this->success->Lookup->getSql(FALSE, $filterWrk, '', $this);
					$rswrk = Conn()->execute($sqlWrk);
					if ($rswrk && !$rswrk->EOF) { // Lookup values found
						$arwrk = [];
						$arwrk[1] = $rswrk->fields('df');
						$this->success->ViewValue = $this->success->displayValue($arwrk);
						$rswrk->Close();
					} else {
						$this->success->ViewValue = $this->success->CurrentValue;
					}
				}
			} else {
				$this->success->ViewValue = NULL;
			}
			$this->success->ViewCustomAttributes = "";

			// transdate
			$this->transdate->ViewValue = $this->transdate->CurrentValue;
			$this->transdate->ViewValue = FormatDateTime($this->transdate->ViewValue, 2);
			$this->transdate->ViewCustomAttributes = "";

			// userid
			$this->_userid->ViewValue = $this->_userid->CurrentValue;
			$this->_userid->ViewCustomAttributes = "";

			// billerresponse
			$this->billerresponse->ViewValue = $this->billerresponse->CurrentValue;
			$this->billerresponse->ViewCustomAttributes = "";

			// paymenttype
			if (strval($this->paymenttype->CurrentValue) != "") {
				$this->paymenttype->ViewValue = $this->paymenttype->optionCaption($this->paymenttype->CurrentValue);
			} else {
				$this->paymenttype->ViewValue = NULL;
			}
			$this->paymenttype->ViewCustomAttributes = "";

			// customername
			$this->customername->ViewValue = $this->customername->CurrentValue;
			$this->customername->ViewCustomAttributes = "";

			// parentuserid
			$this->parentuserid->ViewValue = $this->parentuserid->CurrentValue;
			$this->parentuserid->ViewCustomAttributes = "";

			// refno
			$this->refno->ViewValue = $this->refno->CurrentValue;
			$this->refno->ViewCustomAttributes = "";

			// feeid
			$this->feeid->ViewValue = $this->feeid->CurrentValue;
			$this->feeid->ViewValue = FormatNumber($this->feeid->ViewValue, 0, -2, -2, -2);
			$this->feeid->ViewCustomAttributes = "";

			// tabletype
			$this->_tabletype->ViewValue = $this->_tabletype->CurrentValue;
			$this->_tabletype->ViewValue = FormatNumber($this->_tabletype->ViewValue, 0, -2, -2, -2);
			$this->_tabletype->ViewCustomAttributes = "";

			// feemerchanttotal
			$this->feemerchanttotal->ViewValue = $this->feemerchanttotal->CurrentValue;
			$this->feemerchanttotal->ViewValue = FormatNumber($this->feemerchanttotal->ViewValue, 2, -2, -2, -2);
			$this->feemerchanttotal->ViewCustomAttributes = "";

			// feeconsumertotal
			$this->feeconsumertotal->ViewValue = $this->feeconsumertotal->CurrentValue;
			$this->feeconsumertotal->ViewValue = FormatNumber($this->feeconsumertotal->ViewValue, 2, -2, -2, -2);
			$this->feeconsumertotal->ViewCustomAttributes = "";

			// feesystemtotal
			$this->feesystemtotal->ViewValue = $this->feesystemtotal->CurrentValue;
			$this->feesystemtotal->ViewValue = FormatNumber($this->feesystemtotal->ViewValue, 2, -2, -2, -2);
			$this->feesystemtotal->ViewCustomAttributes = "";

			// feeexternaltotal
			$this->feeexternaltotal->ViewValue = $this->feeexternaltotal->CurrentValue;
			$this->feeexternaltotal->ViewValue = FormatNumber($this->feeexternaltotal->ViewValue, 2, -2, -2, -2);
			$this->feeexternaltotal->ViewCustomAttributes = "";

			// feefranchiseetotal
			$this->feefranchiseetotal->ViewValue = $this->feefranchiseetotal->CurrentValue;
			$this->feefranchiseetotal->ViewValue = FormatNumber($this->feefranchiseetotal->ViewValue, 2, -2, -2, -2);
			$this->feefranchiseetotal->ViewCustomAttributes = "";

			// feeresellertotal
			$this->feeresellertotal->ViewValue = $this->feeresellertotal->CurrentValue;
			$this->feeresellertotal->ViewValue = FormatNumber($this->feeresellertotal->ViewValue, 2, -2, -2, -2);
			$this->feeresellertotal->ViewCustomAttributes = "";

			// branchname
			$this->branchname->ViewValue = $this->branchname->CurrentValue;
			$this->branchname->ViewCustomAttributes = "";

			// clerkname
			$this->clerkname->ViewValue = $this->clerkname->CurrentValue;
			$this->clerkname->ViewCustomAttributes = "";

			// taxamount
			$this->taxamount->ViewValue = $this->taxamount->CurrentValue;
			$this->taxamount->ViewValue = FormatNumber($this->taxamount->ViewValue, 2, -2, -2, -2);
			$this->taxamount->ViewCustomAttributes = "";

			// totalamount
			$this->totalamount->ViewValue = $this->totalamount->CurrentValue;
			$this->totalamount->ViewValue = FormatNumber($this->totalamount->ViewValue, 2, -2, -2, -2);
			$this->totalamount->ViewCustomAttributes = "";

			// taxperc
			$this->taxperc->ViewValue = $this->taxperc->CurrentValue;
			$this->taxperc->ViewValue = FormatNumber($this->taxperc->ViewValue, 2, -2, -2, -2);
			$this->taxperc->ViewCustomAttributes = "";

			// otherdetails
			$this->otherdetails->ViewValue = $this->otherdetails->CurrentValue;
			$this->otherdetails->ViewCustomAttributes = "";

			// transgroupid
			$this->transgroupid->ViewValue = $this->transgroupid->CurrentValue;
			$this->transgroupid->ViewValue = FormatNumber($this->transgroupid->ViewValue, 0, -2, -2, -2);
			$this->transgroupid->ViewCustomAttributes = "";

			// department
			$curVal = strval($this->department->CurrentValue);
			if ($curVal != "") {
				$this->department->ViewValue = $this->department->lookupCacheOption($curVal);
				if ($this->department->ViewValue === NULL) { // Lookup from database
					$filterWrk = "`domainatt`" . SearchString("=", $curVal, DATATYPE_STRING, "_4payreference");
					$sqlWrk = $this->department->Lookup->getSql(FALSE, $filterWrk, '', $this);
					$rswrk = Conn("_4payreference")->execute($sqlWrk);
					if ($rswrk && !$rswrk->EOF) { // Lookup values found
						$arwrk = [];
						$arwrk[1] = $rswrk->fields('df');
						$this->department->ViewValue = $this->department->displayValue($arwrk);
						$rswrk->Close();
					} else {
						$this->department->ViewValue = $this->department->CurrentValue;
					}
				}
			} else {
				$this->department->ViewValue = NULL;
			}
			$this->department->ViewCustomAttributes = "";

			// billingresponse2
			$this->billingresponse2->ViewValue = $this->billingresponse2->CurrentValue;
			$this->billingresponse2->ViewCustomAttributes = "";

			// purchaseid
			$this->purchaseid->ViewValue = $this->purchaseid->CurrentValue;
			$this->purchaseid->ViewValue = FormatNumber($this->purchaseid->ViewValue, 0, -2, -2, -2);
			$this->purchaseid->ViewCustomAttributes = "";

			// paymentid
			$this->paymentid->ViewValue = $this->paymentid->CurrentValue;
			$this->paymentid->ViewValue = FormatNumber($this->paymentid->ViewValue, 0, -2, -2, -2);
			$this->paymentid->ViewCustomAttributes = "";

			// recid
			$this->recid->LinkCustomAttributes = "";
			$this->recid->HrefValue = "";
			$this->recid->TooltipValue = "";

			// serviceid
			$this->serviceid->LinkCustomAttributes = "";
			$this->serviceid->HrefValue = "";
			$this->serviceid->TooltipValue = "";

			// brokerid
			$this->brokerid->LinkCustomAttributes = "";
			$this->brokerid->HrefValue = "";
			$this->brokerid->TooltipValue = "";

			// customeracctno
			$this->customeracctno->LinkCustomAttributes = "";
			$this->customeracctno->HrefValue = "";
			$this->customeracctno->TooltipValue = "";

			// currcode
			$this->currcode->LinkCustomAttributes = "";
			$this->currcode->HrefValue = "";
			$this->currcode->TooltipValue = "";

			// balance
			$this->balance->LinkCustomAttributes = "";
			$this->balance->HrefValue = "";
			$this->balance->TooltipValue = "";

			// confcode
			$this->confcode->LinkCustomAttributes = "";
			$this->confcode->HrefValue = "";
			$this->confcode->TooltipValue = "";

			// success
			$this->success->LinkCustomAttributes = "";
			$this->success->HrefValue = "";
			$this->success->TooltipValue = "";

			// transdate
			$this->transdate->LinkCustomAttributes = "";
			$this->transdate->HrefValue = "";
			$this->transdate->TooltipValue = "";

			// userid
			$this->_userid->LinkCustomAttributes = "";
			$this->_userid->HrefValue = "";
			$this->_userid->TooltipValue = "";

			// billerresponse
			$this->billerresponse->LinkCustomAttributes = "";
			$this->billerresponse->HrefValue = "";
			$this->billerresponse->TooltipValue = "";

			// paymenttype
			$this->paymenttype->LinkCustomAttributes = "";
			$this->paymenttype->HrefValue = "";
			$this->paymenttype->TooltipValue = "";

			// customername
			$this->customername->LinkCustomAttributes = "";
			$this->customername->HrefValue = "";
			$this->customername->TooltipValue = "";

			// parentuserid
			$this->parentuserid->LinkCustomAttributes = "";
			$this->parentuserid->HrefValue = "";
			$this->parentuserid->TooltipValue = "";

			// refno
			$this->refno->LinkCustomAttributes = "";
			$this->refno->HrefValue = "";
			$this->refno->TooltipValue = "";

			// feeid
			$this->feeid->LinkCustomAttributes = "";
			$this->feeid->HrefValue = "";
			$this->feeid->TooltipValue = "";

			// tabletype
			$this->_tabletype->LinkCustomAttributes = "";
			$this->_tabletype->HrefValue = "";
			$this->_tabletype->TooltipValue = "";

			// feemerchanttotal
			$this->feemerchanttotal->LinkCustomAttributes = "";
			$this->feemerchanttotal->HrefValue = "";
			$this->feemerchanttotal->TooltipValue = "";

			// feeconsumertotal
			$this->feeconsumertotal->LinkCustomAttributes = "";
			$this->feeconsumertotal->HrefValue = "";
			$this->feeconsumertotal->TooltipValue = "";

			// feesystemtotal
			$this->feesystemtotal->LinkCustomAttributes = "";
			$this->feesystemtotal->HrefValue = "";
			$this->feesystemtotal->TooltipValue = "";

			// feeexternaltotal
			$this->feeexternaltotal->LinkCustomAttributes = "";
			$this->feeexternaltotal->HrefValue = "";
			$this->feeexternaltotal->TooltipValue = "";

			// feefranchiseetotal
			$this->feefranchiseetotal->LinkCustomAttributes = "";
			$this->feefranchiseetotal->HrefValue = "";
			$this->feefranchiseetotal->TooltipValue = "";

			// feeresellertotal
			$this->feeresellertotal->LinkCustomAttributes = "";
			$this->feeresellertotal->HrefValue = "";
			$this->feeresellertotal->TooltipValue = "";

			// branchname
			$this->branchname->LinkCustomAttributes = "";
			$this->branchname->HrefValue = "";
			$this->branchname->TooltipValue = "";

			// clerkname
			$this->clerkname->LinkCustomAttributes = "";
			$this->clerkname->HrefValue = "";
			$this->clerkname->TooltipValue = "";

			// taxamount
			$this->taxamount->LinkCustomAttributes = "";
			$this->taxamount->HrefValue = "";
			$this->taxamount->TooltipValue = "";

			// totalamount
			$this->totalamount->LinkCustomAttributes = "";
			$this->totalamount->HrefValue = "";
			$this->totalamount->TooltipValue = "";

			// taxperc
			$this->taxperc->LinkCustomAttributes = "";
			$this->taxperc->HrefValue = "";
			$this->taxperc->TooltipValue = "";

			// otherdetails
			$this->otherdetails->LinkCustomAttributes = "";
			$this->otherdetails->HrefValue = "";
			$this->otherdetails->TooltipValue = "";

			// transgroupid
			$this->transgroupid->LinkCustomAttributes = "";
			if (!EmptyValue($this->transgroupid->CurrentValue)) {
				$this->transgroupid->HrefValue = "transgroupview.php?showdetail=&groupID=" . $this->transgroupid->CurrentValue; // Add prefix/suffix
				$this->transgroupid->LinkAttrs["target"] = ""; // Add target
				if ($this->isExport())
					$this->transgroupid->HrefValue = FullUrl($this->transgroupid->HrefValue, "href");
			} else {
				$this->transgroupid->HrefValue = "";
			}
			$this->transgroupid->TooltipValue = "";

			// department
			$this->department->LinkCustomAttributes = "";
			$this->department->HrefValue = "";
			$this->department->TooltipValue = "";

			// billingresponse2
			$this->billingresponse2->LinkCustomAttributes = "";
			$this->billingresponse2->HrefValue = "";
			$this->billingresponse2->TooltipValue = "";

			// purchaseid
			$this->purchaseid->LinkCustomAttributes = "";
			if (!EmptyValue($this->purchaseid->CurrentValue)) {
				$this->purchaseid->HrefValue = "userpurchaseview.php?showdetail=&purchaseid=" . $this->purchaseid->CurrentValue; // Add prefix/suffix
				$this->purchaseid->LinkAttrs["target"] = "_self"; // Add target
				if ($this->isExport())
					$this->purchaseid->HrefValue = FullUrl($this->purchaseid->HrefValue, "href");
			} else {
				$this->purchaseid->HrefValue = "";
			}
			$this->purchaseid->TooltipValue = "";

			// paymentid
			$this->paymentid->LinkCustomAttributes = "";
			if (!EmptyValue($this->paymentid->CurrentValue)) {
				$this->paymentid->HrefValue = "userpurchasepaymentview.php?showmaster=userpurchase&paymentid=" . $this->paymentid->CurrentValue; // Add prefix/suffix
				$this->paymentid->LinkAttrs["target"] = "_self"; // Add target
				if ($this->isExport())
					$this->paymentid->HrefValue = FullUrl($this->paymentid->HrefValue, "href");
			} else {
				$this->paymentid->HrefValue = "";
			}
			$this->paymentid->TooltipValue = "";
		} elseif ($this->RowType == ROWTYPE_EDIT) { // Edit row

			// recid
			$this->recid->EditAttrs["class"] = "form-control";
			$this->recid->EditCustomAttributes = "";
			$this->recid->EditValue = $this->recid->CurrentValue;
			$this->recid->ViewCustomAttributes = "";

			// serviceid
			$this->serviceid->EditAttrs["class"] = "form-control";
			$this->serviceid->EditCustomAttributes = "";
			$this->serviceid->EditValue = HtmlEncode($this->serviceid->CurrentValue);
			$curVal = strval($this->serviceid->CurrentValue);
			if ($curVal != "") {
				$this->serviceid->EditValue = $this->serviceid->lookupCacheOption($curVal);
				if ($this->serviceid->EditValue === NULL) { // Lookup from database
					$filterWrk = "`serviceid`" . SearchString("=", $curVal, DATATYPE_NUMBER, "_4payreference");
					$sqlWrk = $this->serviceid->Lookup->getSql(FALSE, $filterWrk, '', $this);
					$rswrk = Conn("_4payreference")->execute($sqlWrk);
					if ($rswrk && !$rswrk->EOF) { // Lookup values found
						$arwrk = [];
						$arwrk[1] = HtmlEncode($rswrk->fields('df'));
						$this->serviceid->EditValue = $this->serviceid->displayValue($arwrk);
						$rswrk->Close();
					} else {
						$this->serviceid->EditValue = HtmlEncode($this->serviceid->CurrentValue);
					}
				}
			} else {
				$this->serviceid->EditValue = NULL;
			}
			$this->serviceid->PlaceHolder = RemoveHtml($this->serviceid->caption());

			// brokerid
			$this->brokerid->EditAttrs["class"] = "form-control";
			$this->brokerid->EditCustomAttributes = "";
			$this->brokerid->EditValue = HtmlEncode($this->brokerid->CurrentValue);
			$this->brokerid->PlaceHolder = RemoveHtml($this->brokerid->caption());

			// customeracctno
			$this->customeracctno->EditAttrs["class"] = "form-control";
			$this->customeracctno->EditCustomAttributes = "";
			if (!$this->customeracctno->Raw)
				$this->customeracctno->CurrentValue = HtmlDecode($this->customeracctno->CurrentValue);
			$this->customeracctno->EditValue = HtmlEncode($this->customeracctno->CurrentValue);
			$this->customeracctno->PlaceHolder = RemoveHtml($this->customeracctno->caption());

			// currcode
			$this->currcode->EditAttrs["class"] = "form-control";
			$this->currcode->EditCustomAttributes = "";
			if (!$this->currcode->Raw)
				$this->currcode->CurrentValue = HtmlDecode($this->currcode->CurrentValue);
			$this->currcode->EditValue = HtmlEncode($this->currcode->CurrentValue);
			$this->currcode->PlaceHolder = RemoveHtml($this->currcode->caption());

			// balance
			$this->balance->EditAttrs["class"] = "form-control";
			$this->balance->EditCustomAttributes = "";
			$this->balance->EditValue = HtmlEncode($this->balance->CurrentValue);
			$this->balance->PlaceHolder = RemoveHtml($this->balance->caption());
			if (strval($this->balance->EditValue) != "" && is_numeric($this->balance->EditValue))
				$this->balance->EditValue = FormatNumber($this->balance->EditValue, -2, -2, -2, -2);
			

			// confcode
			$this->confcode->EditAttrs["class"] = "form-control";
			$this->confcode->EditCustomAttributes = "";
			if (!$this->confcode->Raw)
				$this->confcode->CurrentValue = HtmlDecode($this->confcode->CurrentValue);
			$this->confcode->EditValue = HtmlEncode($this->confcode->CurrentValue);
			$this->confcode->PlaceHolder = RemoveHtml($this->confcode->caption());

			// success
			$this->success->EditAttrs["class"] = "form-control";
			$this->success->EditCustomAttributes = "";
			$this->success->EditValue = HtmlEncode($this->success->CurrentValue);
			$curVal = strval($this->success->CurrentValue);
			if ($curVal != "") {
				$this->success->EditValue = $this->success->lookupCacheOption($curVal);
				if ($this->success->EditValue === NULL) { // Lookup from database
					$filterWrk = "`id`" . SearchString("=", $curVal, DATATYPE_NUMBER, "");
					$sqlWrk = $this->success->Lookup->getSql(FALSE, $filterWrk, '', $this);
					$rswrk = Conn()->execute($sqlWrk);
					if ($rswrk && !$rswrk->EOF) { // Lookup values found
						$arwrk = [];
						$arwrk[1] = HtmlEncode($rswrk->fields('df'));
						$this->success->EditValue = $this->success->displayValue($arwrk);
						$rswrk->Close();
					} else {
						$this->success->EditValue = HtmlEncode($this->success->CurrentValue);
					}
				}
			} else {
				$this->success->EditValue = NULL;
			}
			$this->success->PlaceHolder = RemoveHtml($this->success->caption());

			// transdate
			$this->transdate->EditAttrs["class"] = "form-control";
			$this->transdate->EditCustomAttributes = "";
			$this->transdate->EditValue = HtmlEncode(FormatDateTime($this->transdate->CurrentValue, 2));
			$this->transdate->PlaceHolder = RemoveHtml($this->transdate->caption());

			// userid
			$this->_userid->EditAttrs["class"] = "form-control";
			$this->_userid->EditCustomAttributes = "";
			$this->_userid->EditValue = HtmlEncode($this->_userid->CurrentValue);
			$this->_userid->PlaceHolder = RemoveHtml($this->_userid->caption());

			// billerresponse
			$this->billerresponse->EditAttrs["class"] = "form-control";
			$this->billerresponse->EditCustomAttributes = "";
			if (!$this->billerresponse->Raw)
				$this->billerresponse->CurrentValue = HtmlDecode($this->billerresponse->CurrentValue);
			$this->billerresponse->EditValue = HtmlEncode($this->billerresponse->CurrentValue);
			$this->billerresponse->PlaceHolder = RemoveHtml($this->billerresponse->caption());

			// paymenttype
			$this->paymenttype->EditAttrs["class"] = "form-control";
			$this->paymenttype->EditCustomAttributes = "";
			$this->paymenttype->EditValue = $this->paymenttype->options(TRUE);

			// customername
			$this->customername->EditAttrs["class"] = "form-control";
			$this->customername->EditCustomAttributes = "";
			if (!$this->customername->Raw)
				$this->customername->CurrentValue = HtmlDecode($this->customername->CurrentValue);
			$this->customername->EditValue = HtmlEncode($this->customername->CurrentValue);
			$this->customername->PlaceHolder = RemoveHtml($this->customername->caption());

			// parentuserid
			$this->parentuserid->EditAttrs["class"] = "form-control";
			$this->parentuserid->EditCustomAttributes = "";
			$this->parentuserid->EditValue = $this->parentuserid->CurrentValue;
			$this->parentuserid->ViewCustomAttributes = "";

			// refno
			$this->refno->EditAttrs["class"] = "form-control";
			$this->refno->EditCustomAttributes = "";
			if (!$this->refno->Raw)
				$this->refno->CurrentValue = HtmlDecode($this->refno->CurrentValue);
			$this->refno->EditValue = HtmlEncode($this->refno->CurrentValue);
			$this->refno->PlaceHolder = RemoveHtml($this->refno->caption());

			// feeid
			$this->feeid->EditAttrs["class"] = "form-control";
			$this->feeid->EditCustomAttributes = "";
			$this->feeid->EditValue = HtmlEncode($this->feeid->CurrentValue);
			$this->feeid->PlaceHolder = RemoveHtml($this->feeid->caption());

			// tabletype
			$this->_tabletype->EditAttrs["class"] = "form-control";
			$this->_tabletype->EditCustomAttributes = "";
			$this->_tabletype->EditValue = HtmlEncode($this->_tabletype->CurrentValue);
			$this->_tabletype->PlaceHolder = RemoveHtml($this->_tabletype->caption());

			// feemerchanttotal
			$this->feemerchanttotal->EditAttrs["class"] = "form-control";
			$this->feemerchanttotal->EditCustomAttributes = "";
			$this->feemerchanttotal->EditValue = HtmlEncode($this->feemerchanttotal->CurrentValue);
			$this->feemerchanttotal->PlaceHolder = RemoveHtml($this->feemerchanttotal->caption());
			if (strval($this->feemerchanttotal->EditValue) != "" && is_numeric($this->feemerchanttotal->EditValue))
				$this->feemerchanttotal->EditValue = FormatNumber($this->feemerchanttotal->EditValue, -2, -2, -2, -2);
			

			// feeconsumertotal
			$this->feeconsumertotal->EditAttrs["class"] = "form-control";
			$this->feeconsumertotal->EditCustomAttributes = "";
			$this->feeconsumertotal->EditValue = HtmlEncode($this->feeconsumertotal->CurrentValue);
			$this->feeconsumertotal->PlaceHolder = RemoveHtml($this->feeconsumertotal->caption());
			if (strval($this->feeconsumertotal->EditValue) != "" && is_numeric($this->feeconsumertotal->EditValue))
				$this->feeconsumertotal->EditValue = FormatNumber($this->feeconsumertotal->EditValue, -2, -2, -2, -2);
			

			// feesystemtotal
			$this->feesystemtotal->EditAttrs["class"] = "form-control";
			$this->feesystemtotal->EditCustomAttributes = "";
			$this->feesystemtotal->EditValue = HtmlEncode($this->feesystemtotal->CurrentValue);
			$this->feesystemtotal->PlaceHolder = RemoveHtml($this->feesystemtotal->caption());
			if (strval($this->feesystemtotal->EditValue) != "" && is_numeric($this->feesystemtotal->EditValue))
				$this->feesystemtotal->EditValue = FormatNumber($this->feesystemtotal->EditValue, -2, -2, -2, -2);
			

			// feeexternaltotal
			$this->feeexternaltotal->EditAttrs["class"] = "form-control";
			$this->feeexternaltotal->EditCustomAttributes = "";
			$this->feeexternaltotal->EditValue = HtmlEncode($this->feeexternaltotal->CurrentValue);
			$this->feeexternaltotal->PlaceHolder = RemoveHtml($this->feeexternaltotal->caption());
			if (strval($this->feeexternaltotal->EditValue) != "" && is_numeric($this->feeexternaltotal->EditValue))
				$this->feeexternaltotal->EditValue = FormatNumber($this->feeexternaltotal->EditValue, -2, -2, -2, -2);
			

			// feefranchiseetotal
			$this->feefranchiseetotal->EditAttrs["class"] = "form-control";
			$this->feefranchiseetotal->EditCustomAttributes = "";
			$this->feefranchiseetotal->EditValue = HtmlEncode($this->feefranchiseetotal->CurrentValue);
			$this->feefranchiseetotal->PlaceHolder = RemoveHtml($this->feefranchiseetotal->caption());
			if (strval($this->feefranchiseetotal->EditValue) != "" && is_numeric($this->feefranchiseetotal->EditValue))
				$this->feefranchiseetotal->EditValue = FormatNumber($this->feefranchiseetotal->EditValue, -2, -2, -2, -2);
			

			// feeresellertotal
			$this->feeresellertotal->EditAttrs["class"] = "form-control";
			$this->feeresellertotal->EditCustomAttributes = "";
			$this->feeresellertotal->EditValue = HtmlEncode($this->feeresellertotal->CurrentValue);
			$this->feeresellertotal->PlaceHolder = RemoveHtml($this->feeresellertotal->caption());
			if (strval($this->feeresellertotal->EditValue) != "" && is_numeric($this->feeresellertotal->EditValue))
				$this->feeresellertotal->EditValue = FormatNumber($this->feeresellertotal->EditValue, -2, -2, -2, -2);
			

			// branchname
			$this->branchname->EditAttrs["class"] = "form-control";
			$this->branchname->EditCustomAttributes = "";
			if (!$this->branchname->Raw)
				$this->branchname->CurrentValue = HtmlDecode($this->branchname->CurrentValue);
			$this->branchname->EditValue = HtmlEncode($this->branchname->CurrentValue);
			$this->branchname->PlaceHolder = RemoveHtml($this->branchname->caption());

			// clerkname
			$this->clerkname->EditAttrs["class"] = "form-control";
			$this->clerkname->EditCustomAttributes = "";
			if (!$this->clerkname->Raw)
				$this->clerkname->CurrentValue = HtmlDecode($this->clerkname->CurrentValue);
			$this->clerkname->EditValue = HtmlEncode($this->clerkname->CurrentValue);
			$this->clerkname->PlaceHolder = RemoveHtml($this->clerkname->caption());

			// taxamount
			$this->taxamount->EditAttrs["class"] = "form-control";
			$this->taxamount->EditCustomAttributes = "";
			$this->taxamount->EditValue = HtmlEncode($this->taxamount->CurrentValue);
			$this->taxamount->PlaceHolder = RemoveHtml($this->taxamount->caption());
			if (strval($this->taxamount->EditValue) != "" && is_numeric($this->taxamount->EditValue))
				$this->taxamount->EditValue = FormatNumber($this->taxamount->EditValue, -2, -2, -2, -2);
			

			// totalamount
			$this->totalamount->EditAttrs["class"] = "form-control";
			$this->totalamount->EditCustomAttributes = "";
			$this->totalamount->EditValue = HtmlEncode($this->totalamount->CurrentValue);
			$this->totalamount->PlaceHolder = RemoveHtml($this->totalamount->caption());
			if (strval($this->totalamount->EditValue) != "" && is_numeric($this->totalamount->EditValue))
				$this->totalamount->EditValue = FormatNumber($this->totalamount->EditValue, -2, -2, -2, -2);
			

			// taxperc
			$this->taxperc->EditAttrs["class"] = "form-control";
			$this->taxperc->EditCustomAttributes = "";
			$this->taxperc->EditValue = HtmlEncode($this->taxperc->CurrentValue);
			$this->taxperc->PlaceHolder = RemoveHtml($this->taxperc->caption());
			if (strval($this->taxperc->EditValue) != "" && is_numeric($this->taxperc->EditValue))
				$this->taxperc->EditValue = FormatNumber($this->taxperc->EditValue, -2, -2, -2, -2);
			

			// otherdetails
			$this->otherdetails->EditAttrs["class"] = "form-control";
			$this->otherdetails->EditCustomAttributes = "";
			if (!$this->otherdetails->Raw)
				$this->otherdetails->CurrentValue = HtmlDecode($this->otherdetails->CurrentValue);
			$this->otherdetails->EditValue = HtmlEncode($this->otherdetails->CurrentValue);
			$this->otherdetails->PlaceHolder = RemoveHtml($this->otherdetails->caption());

			// transgroupid
			$this->transgroupid->EditAttrs["class"] = "form-control";
			$this->transgroupid->EditCustomAttributes = "";
			$this->transgroupid->EditValue = HtmlEncode($this->transgroupid->CurrentValue);
			$this->transgroupid->PlaceHolder = RemoveHtml($this->transgroupid->caption());

			// department
			$this->department->EditAttrs["class"] = "form-control";
			$this->department->EditCustomAttributes = "";
			$curVal = trim(strval($this->department->CurrentValue));
			if ($curVal != "")
				$this->department->ViewValue = $this->department->lookupCacheOption($curVal);
			else
				$this->department->ViewValue = $this->department->Lookup !== NULL && is_array($this->department->Lookup->Options) ? $curVal : NULL;
			if ($this->department->ViewValue !== NULL) { // Load from cache
				$this->department->EditValue = array_values($this->department->Lookup->Options);
			} else { // Lookup from database
				if ($curVal == "") {
					$filterWrk = "0=1";
				} else {
					$filterWrk = "`domainatt`" . SearchString("=", $this->department->CurrentValue, DATATYPE_STRING, "_4payreference");
				}
				$sqlWrk = $this->department->Lookup->getSql(TRUE, $filterWrk, '', $this);
				$rswrk = Conn("_4payreference")->execute($sqlWrk);
				$arwrk = $rswrk ? $rswrk->getRows() : [];
				if ($rswrk)
					$rswrk->close();
				$this->department->EditValue = $arwrk;
			}

			// billingresponse2
			$this->billingresponse2->EditAttrs["class"] = "form-control";
			$this->billingresponse2->EditCustomAttributes = "";
			$this->billingresponse2->EditValue = HtmlEncode($this->billingresponse2->CurrentValue);
			$this->billingresponse2->PlaceHolder = RemoveHtml($this->billingresponse2->caption());

			// purchaseid
			$this->purchaseid->EditAttrs["class"] = "form-control";
			$this->purchaseid->EditCustomAttributes = "";
			$this->purchaseid->EditValue = HtmlEncode($this->purchaseid->CurrentValue);
			$this->purchaseid->PlaceHolder = RemoveHtml($this->purchaseid->caption());

			// paymentid
			$this->paymentid->EditAttrs["class"] = "form-control";
			$this->paymentid->EditCustomAttributes = "";
			$this->paymentid->EditValue = HtmlEncode($this->paymentid->CurrentValue);
			$this->paymentid->PlaceHolder = RemoveHtml($this->paymentid->caption());

			// Edit refer script
			// recid

			$this->recid->LinkCustomAttributes = "";
			$this->recid->HrefValue = "";

			// serviceid
			$this->serviceid->LinkCustomAttributes = "";
			$this->serviceid->HrefValue = "";

			// brokerid
			$this->brokerid->LinkCustomAttributes = "";
			$this->brokerid->HrefValue = "";

			// customeracctno
			$this->customeracctno->LinkCustomAttributes = "";
			$this->customeracctno->HrefValue = "";

			// currcode
			$this->currcode->LinkCustomAttributes = "";
			$this->currcode->HrefValue = "";

			// balance
			$this->balance->LinkCustomAttributes = "";
			$this->balance->HrefValue = "";

			// confcode
			$this->confcode->LinkCustomAttributes = "";
			$this->confcode->HrefValue = "";

			// success
			$this->success->LinkCustomAttributes = "";
			$this->success->HrefValue = "";

			// transdate
			$this->transdate->LinkCustomAttributes = "";
			$this->transdate->HrefValue = "";

			// userid
			$this->_userid->LinkCustomAttributes = "";
			$this->_userid->HrefValue = "";

			// billerresponse
			$this->billerresponse->LinkCustomAttributes = "";
			$this->billerresponse->HrefValue = "";

			// paymenttype
			$this->paymenttype->LinkCustomAttributes = "";
			$this->paymenttype->HrefValue = "";

			// customername
			$this->customername->LinkCustomAttributes = "";
			$this->customername->HrefValue = "";

			// parentuserid
			$this->parentuserid->LinkCustomAttributes = "";
			$this->parentuserid->HrefValue = "";
			$this->parentuserid->TooltipValue = "";

			// refno
			$this->refno->LinkCustomAttributes = "";
			$this->refno->HrefValue = "";

			// feeid
			$this->feeid->LinkCustomAttributes = "";
			$this->feeid->HrefValue = "";

			// tabletype
			$this->_tabletype->LinkCustomAttributes = "";
			$this->_tabletype->HrefValue = "";

			// feemerchanttotal
			$this->feemerchanttotal->LinkCustomAttributes = "";
			$this->feemerchanttotal->HrefValue = "";

			// feeconsumertotal
			$this->feeconsumertotal->LinkCustomAttributes = "";
			$this->feeconsumertotal->HrefValue = "";

			// feesystemtotal
			$this->feesystemtotal->LinkCustomAttributes = "";
			$this->feesystemtotal->HrefValue = "";

			// feeexternaltotal
			$this->feeexternaltotal->LinkCustomAttributes = "";
			$this->feeexternaltotal->HrefValue = "";

			// feefranchiseetotal
			$this->feefranchiseetotal->LinkCustomAttributes = "";
			$this->feefranchiseetotal->HrefValue = "";

			// feeresellertotal
			$this->feeresellertotal->LinkCustomAttributes = "";
			$this->feeresellertotal->HrefValue = "";

			// branchname
			$this->branchname->LinkCustomAttributes = "";
			$this->branchname->HrefValue = "";

			// clerkname
			$this->clerkname->LinkCustomAttributes = "";
			$this->clerkname->HrefValue = "";

			// taxamount
			$this->taxamount->LinkCustomAttributes = "";
			$this->taxamount->HrefValue = "";

			// totalamount
			$this->totalamount->LinkCustomAttributes = "";
			$this->totalamount->HrefValue = "";

			// taxperc
			$this->taxperc->LinkCustomAttributes = "";
			$this->taxperc->HrefValue = "";

			// otherdetails
			$this->otherdetails->LinkCustomAttributes = "";
			$this->otherdetails->HrefValue = "";

			// transgroupid
			$this->transgroupid->LinkCustomAttributes = "";
			if (!EmptyValue($this->transgroupid->CurrentValue)) {
				$this->transgroupid->HrefValue = "transgroupview.php?showdetail=&groupID=" . $this->transgroupid->CurrentValue; // Add prefix/suffix
				$this->transgroupid->LinkAttrs["target"] = ""; // Add target
				if ($this->isExport())
					$this->transgroupid->HrefValue = FullUrl($this->transgroupid->HrefValue, "href");
			} else {
				$this->transgroupid->HrefValue = "";
			}

			// department
			$this->department->LinkCustomAttributes = "";
			$this->department->HrefValue = "";

			// billingresponse2
			$this->billingresponse2->LinkCustomAttributes = "";
			$this->billingresponse2->HrefValue = "";

			// purchaseid
			$this->purchaseid->LinkCustomAttributes = "";
			if (!EmptyValue($this->purchaseid->CurrentValue)) {
				$this->purchaseid->HrefValue = "userpurchaseview.php?showdetail=&purchaseid=" . $this->purchaseid->CurrentValue; // Add prefix/suffix
				$this->purchaseid->LinkAttrs["target"] = "_self"; // Add target
				if ($this->isExport())
					$this->purchaseid->HrefValue = FullUrl($this->purchaseid->HrefValue, "href");
			} else {
				$this->purchaseid->HrefValue = "";
			}

			// paymentid
			$this->paymentid->LinkCustomAttributes = "";
			if (!EmptyValue($this->paymentid->CurrentValue)) {
				$this->paymentid->HrefValue = "userpurchasepaymentview.php?showmaster=userpurchase&paymentid=" . $this->paymentid->CurrentValue; // Add prefix/suffix
				$this->paymentid->LinkAttrs["target"] = "_self"; // Add target
				if ($this->isExport())
					$this->paymentid->HrefValue = FullUrl($this->paymentid->HrefValue, "href");
			} else {
				$this->paymentid->HrefValue = "";
			}
		}
		if ($this->RowType == ROWTYPE_ADD || $this->RowType == ROWTYPE_EDIT || $this->RowType == ROWTYPE_SEARCH) // Add/Edit/Search row
			$this->setupFieldTitles();

		// Call Row Rendered event
		if ($this->RowType != ROWTYPE_AGGREGATEINIT)
			$this->Row_Rendered();
	}

	// Validate form
	protected function validateForm()
	{
		global $Language, $FormError;

		// Initialize form error message
		$FormError = "";

		// Check if validation required
		if (!Config("SERVER_VALIDATE"))
			return ($FormError == "");
		if ($this->recid->Required) {
			if (!$this->recid->IsDetailKey && $this->recid->FormValue != NULL && $this->recid->FormValue == "") {
				AddMessage($FormError, str_replace("%s", $this->recid->caption(), $this->recid->RequiredErrorMessage));
			}
		}
		if ($this->serviceid->Required) {
			if (!$this->serviceid->IsDetailKey && $this->serviceid->FormValue != NULL && $this->serviceid->FormValue == "") {
				AddMessage($FormError, str_replace("%s", $this->serviceid->caption(), $this->serviceid->RequiredErrorMessage));
			}
		}
		if (!CheckInteger($this->serviceid->FormValue)) {
			AddMessage($FormError, $this->serviceid->errorMessage());
		}
		if ($this->brokerid->Required) {
			if (!$this->brokerid->IsDetailKey && $this->brokerid->FormValue != NULL && $this->brokerid->FormValue == "") {
				AddMessage($FormError, str_replace("%s", $this->brokerid->caption(), $this->brokerid->RequiredErrorMessage));
			}
		}
		if (!CheckInteger($this->brokerid->FormValue)) {
			AddMessage($FormError, $this->brokerid->errorMessage());
		}
		if ($this->customeracctno->Required) {
			if (!$this->customeracctno->IsDetailKey && $this->customeracctno->FormValue != NULL && $this->customeracctno->FormValue == "") {
				AddMessage($FormError, str_replace("%s", $this->customeracctno->caption(), $this->customeracctno->RequiredErrorMessage));
			}
		}
		if ($this->currcode->Required) {
			if (!$this->currcode->IsDetailKey && $this->currcode->FormValue != NULL && $this->currcode->FormValue == "") {
				AddMessage($FormError, str_replace("%s", $this->currcode->caption(), $this->currcode->RequiredErrorMessage));
			}
		}
		if ($this->balance->Required) {
			if (!$this->balance->IsDetailKey && $this->balance->FormValue != NULL && $this->balance->FormValue == "") {
				AddMessage($FormError, str_replace("%s", $this->balance->caption(), $this->balance->RequiredErrorMessage));
			}
		}
		if (!CheckNumber($this->balance->FormValue)) {
			AddMessage($FormError, $this->balance->errorMessage());
		}
		if ($this->confcode->Required) {
			if (!$this->confcode->IsDetailKey && $this->confcode->FormValue != NULL && $this->confcode->FormValue == "") {
				AddMessage($FormError, str_replace("%s", $this->confcode->caption(), $this->confcode->RequiredErrorMessage));
			}
		}
		if ($this->success->Required) {
			if (!$this->success->IsDetailKey && $this->success->FormValue != NULL && $this->success->FormValue == "") {
				AddMessage($FormError, str_replace("%s", $this->success->caption(), $this->success->RequiredErrorMessage));
			}
		}
		if (!CheckInteger($this->success->FormValue)) {
			AddMessage($FormError, $this->success->errorMessage());
		}
		if ($this->transdate->Required) {
			if (!$this->transdate->IsDetailKey && $this->transdate->FormValue != NULL && $this->transdate->FormValue == "") {
				AddMessage($FormError, str_replace("%s", $this->transdate->caption(), $this->transdate->RequiredErrorMessage));
			}
		}
		if (!CheckDate($this->transdate->FormValue)) {
			AddMessage($FormError, $this->transdate->errorMessage());
		}
		if ($this->_userid->Required) {
			if (!$this->_userid->IsDetailKey && $this->_userid->FormValue != NULL && $this->_userid->FormValue == "") {
				AddMessage($FormError, str_replace("%s", $this->_userid->caption(), $this->_userid->RequiredErrorMessage));
			}
		}
		if (!CheckInteger($this->_userid->FormValue)) {
			AddMessage($FormError, $this->_userid->errorMessage());
		}
		if ($this->billerresponse->Required) {
			if (!$this->billerresponse->IsDetailKey && $this->billerresponse->FormValue != NULL && $this->billerresponse->FormValue == "") {
				AddMessage($FormError, str_replace("%s", $this->billerresponse->caption(), $this->billerresponse->RequiredErrorMessage));
			}
		}
		if ($this->paymenttype->Required) {
			if (!$this->paymenttype->IsDetailKey && $this->paymenttype->FormValue != NULL && $this->paymenttype->FormValue == "") {
				AddMessage($FormError, str_replace("%s", $this->paymenttype->caption(), $this->paymenttype->RequiredErrorMessage));
			}
		}
		if ($this->customername->Required) {
			if (!$this->customername->IsDetailKey && $this->customername->FormValue != NULL && $this->customername->FormValue == "") {
				AddMessage($FormError, str_replace("%s", $this->customername->caption(), $this->customername->RequiredErrorMessage));
			}
		}
		if ($this->parentuserid->Required) {
			if (!$this->parentuserid->IsDetailKey && $this->parentuserid->FormValue != NULL && $this->parentuserid->FormValue == "") {
				AddMessage($FormError, str_replace("%s", $this->parentuserid->caption(), $this->parentuserid->RequiredErrorMessage));
			}
		}
		if ($this->refno->Required) {
			if (!$this->refno->IsDetailKey && $this->refno->FormValue != NULL && $this->refno->FormValue == "") {
				AddMessage($FormError, str_replace("%s", $this->refno->caption(), $this->refno->RequiredErrorMessage));
			}
		}
		if ($this->feeid->Required) {
			if (!$this->feeid->IsDetailKey && $this->feeid->FormValue != NULL && $this->feeid->FormValue == "") {
				AddMessage($FormError, str_replace("%s", $this->feeid->caption(), $this->feeid->RequiredErrorMessage));
			}
		}
		if (!CheckInteger($this->feeid->FormValue)) {
			AddMessage($FormError, $this->feeid->errorMessage());
		}
		if ($this->_tabletype->Required) {
			if (!$this->_tabletype->IsDetailKey && $this->_tabletype->FormValue != NULL && $this->_tabletype->FormValue == "") {
				AddMessage($FormError, str_replace("%s", $this->_tabletype->caption(), $this->_tabletype->RequiredErrorMessage));
			}
		}
		if (!CheckInteger($this->_tabletype->FormValue)) {
			AddMessage($FormError, $this->_tabletype->errorMessage());
		}
		if ($this->feemerchanttotal->Required) {
			if (!$this->feemerchanttotal->IsDetailKey && $this->feemerchanttotal->FormValue != NULL && $this->feemerchanttotal->FormValue == "") {
				AddMessage($FormError, str_replace("%s", $this->feemerchanttotal->caption(), $this->feemerchanttotal->RequiredErrorMessage));
			}
		}
		if (!CheckNumber($this->feemerchanttotal->FormValue)) {
			AddMessage($FormError, $this->feemerchanttotal->errorMessage());
		}
		if ($this->feeconsumertotal->Required) {
			if (!$this->feeconsumertotal->IsDetailKey && $this->feeconsumertotal->FormValue != NULL && $this->feeconsumertotal->FormValue == "") {
				AddMessage($FormError, str_replace("%s", $this->feeconsumertotal->caption(), $this->feeconsumertotal->RequiredErrorMessage));
			}
		}
		if (!CheckNumber($this->feeconsumertotal->FormValue)) {
			AddMessage($FormError, $this->feeconsumertotal->errorMessage());
		}
		if ($this->feesystemtotal->Required) {
			if (!$this->feesystemtotal->IsDetailKey && $this->feesystemtotal->FormValue != NULL && $this->feesystemtotal->FormValue == "") {
				AddMessage($FormError, str_replace("%s", $this->feesystemtotal->caption(), $this->feesystemtotal->RequiredErrorMessage));
			}
		}
		if (!CheckNumber($this->feesystemtotal->FormValue)) {
			AddMessage($FormError, $this->feesystemtotal->errorMessage());
		}
		if ($this->feeexternaltotal->Required) {
			if (!$this->feeexternaltotal->IsDetailKey && $this->feeexternaltotal->FormValue != NULL && $this->feeexternaltotal->FormValue == "") {
				AddMessage($FormError, str_replace("%s", $this->feeexternaltotal->caption(), $this->feeexternaltotal->RequiredErrorMessage));
			}
		}
		if (!CheckNumber($this->feeexternaltotal->FormValue)) {
			AddMessage($FormError, $this->feeexternaltotal->errorMessage());
		}
		if ($this->feefranchiseetotal->Required) {
			if (!$this->feefranchiseetotal->IsDetailKey && $this->feefranchiseetotal->FormValue != NULL && $this->feefranchiseetotal->FormValue == "") {
				AddMessage($FormError, str_replace("%s", $this->feefranchiseetotal->caption(), $this->feefranchiseetotal->RequiredErrorMessage));
			}
		}
		if (!CheckNumber($this->feefranchiseetotal->FormValue)) {
			AddMessage($FormError, $this->feefranchiseetotal->errorMessage());
		}
		if ($this->feeresellertotal->Required) {
			if (!$this->feeresellertotal->IsDetailKey && $this->feeresellertotal->FormValue != NULL && $this->feeresellertotal->FormValue == "") {
				AddMessage($FormError, str_replace("%s", $this->feeresellertotal->caption(), $this->feeresellertotal->RequiredErrorMessage));
			}
		}
		if (!CheckNumber($this->feeresellertotal->FormValue)) {
			AddMessage($FormError, $this->feeresellertotal->errorMessage());
		}
		if ($this->branchname->Required) {
			if (!$this->branchname->IsDetailKey && $this->branchname->FormValue != NULL && $this->branchname->FormValue == "") {
				AddMessage($FormError, str_replace("%s", $this->branchname->caption(), $this->branchname->RequiredErrorMessage));
			}
		}
		if ($this->clerkname->Required) {
			if (!$this->clerkname->IsDetailKey && $this->clerkname->FormValue != NULL && $this->clerkname->FormValue == "") {
				AddMessage($FormError, str_replace("%s", $this->clerkname->caption(), $this->clerkname->RequiredErrorMessage));
			}
		}
		if ($this->taxamount->Required) {
			if (!$this->taxamount->IsDetailKey && $this->taxamount->FormValue != NULL && $this->taxamount->FormValue == "") {
				AddMessage($FormError, str_replace("%s", $this->taxamount->caption(), $this->taxamount->RequiredErrorMessage));
			}
		}
		if (!CheckNumber($this->taxamount->FormValue)) {
			AddMessage($FormError, $this->taxamount->errorMessage());
		}
		if ($this->totalamount->Required) {
			if (!$this->totalamount->IsDetailKey && $this->totalamount->FormValue != NULL && $this->totalamount->FormValue == "") {
				AddMessage($FormError, str_replace("%s", $this->totalamount->caption(), $this->totalamount->RequiredErrorMessage));
			}
		}
		if (!CheckNumber($this->totalamount->FormValue)) {
			AddMessage($FormError, $this->totalamount->errorMessage());
		}
		if ($this->taxperc->Required) {
			if (!$this->taxperc->IsDetailKey && $this->taxperc->FormValue != NULL && $this->taxperc->FormValue == "") {
				AddMessage($FormError, str_replace("%s", $this->taxperc->caption(), $this->taxperc->RequiredErrorMessage));
			}
		}
		if (!CheckNumber($this->taxperc->FormValue)) {
			AddMessage($FormError, $this->taxperc->errorMessage());
		}
		if ($this->otherdetails->Required) {
			if (!$this->otherdetails->IsDetailKey && $this->otherdetails->FormValue != NULL && $this->otherdetails->FormValue == "") {
				AddMessage($FormError, str_replace("%s", $this->otherdetails->caption(), $this->otherdetails->RequiredErrorMessage));
			}
		}
		if ($this->transgroupid->Required) {
			if (!$this->transgroupid->IsDetailKey && $this->transgroupid->FormValue != NULL && $this->transgroupid->FormValue == "") {
				AddMessage($FormError, str_replace("%s", $this->transgroupid->caption(), $this->transgroupid->RequiredErrorMessage));
			}
		}
		if (!CheckInteger($this->transgroupid->FormValue)) {
			AddMessage($FormError, $this->transgroupid->errorMessage());
		}
		if ($this->department->Required) {
			if (!$this->department->IsDetailKey && $this->department->FormValue != NULL && $this->department->FormValue == "") {
				AddMessage($FormError, str_replace("%s", $this->department->caption(), $this->department->RequiredErrorMessage));
			}
		}
		if ($this->billingresponse2->Required) {
			if (!$this->billingresponse2->IsDetailKey && $this->billingresponse2->FormValue != NULL && $this->billingresponse2->FormValue == "") {
				AddMessage($FormError, str_replace("%s", $this->billingresponse2->caption(), $this->billingresponse2->RequiredErrorMessage));
			}
		}
		if ($this->purchaseid->Required) {
			if (!$this->purchaseid->IsDetailKey && $this->purchaseid->FormValue != NULL && $this->purchaseid->FormValue == "") {
				AddMessage($FormError, str_replace("%s", $this->purchaseid->caption(), $this->purchaseid->RequiredErrorMessage));
			}
		}
		if (!CheckInteger($this->purchaseid->FormValue)) {
			AddMessage($FormError, $this->purchaseid->errorMessage());
		}
		if ($this->paymentid->Required) {
			if (!$this->paymentid->IsDetailKey && $this->paymentid->FormValue != NULL && $this->paymentid->FormValue == "") {
				AddMessage($FormError, str_replace("%s", $this->paymentid->caption(), $this->paymentid->RequiredErrorMessage));
			}
		}
		if (!CheckInteger($this->paymentid->FormValue)) {
			AddMessage($FormError, $this->paymentid->errorMessage());
		}

		// Return validate result
		$validateForm = ($FormError == "");

		// Call Form_CustomValidate event
		$formCustomError = "";
		$validateForm = $validateForm && $this->Form_CustomValidate($formCustomError);
		if ($formCustomError != "") {
			AddMessage($FormError, $formCustomError);
		}
		return $validateForm;
	}

	// Update record based on key values
	protected function editRow()
	{
		global $Security, $Language;
		$oldKeyFilter = $this->getRecordFilter();
		$filter = $this->applyUserIDFilters($oldKeyFilter);
		$conn = $this->getConnection();
		$this->CurrentFilter = $filter;
		$sql = $this->getCurrentSql();
		$conn->raiseErrorFn = Config("ERROR_FUNC");
		$rs = $conn->execute($sql);
		$conn->raiseErrorFn = "";
		if ($rs === FALSE)
			return FALSE;
		if ($rs->EOF) {
			$this->setFailureMessage($Language->phrase("NoRecord")); // Set no record message
			$editRow = FALSE; // Update Failed
		} else {

			// Save old values
			$rsold = &$rs->fields;
			$this->loadDbValues($rsold);
			$rsnew = [];

			// serviceid
			$this->serviceid->setDbValueDef($rsnew, $this->serviceid->CurrentValue, 0, $this->serviceid->ReadOnly);

			// brokerid
			$this->brokerid->setDbValueDef($rsnew, $this->brokerid->CurrentValue, 0, $this->brokerid->ReadOnly);

			// customeracctno
			$this->customeracctno->setDbValueDef($rsnew, $this->customeracctno->CurrentValue, "", $this->customeracctno->ReadOnly);

			// currcode
			$this->currcode->setDbValueDef($rsnew, $this->currcode->CurrentValue, "", $this->currcode->ReadOnly);

			// balance
			$this->balance->setDbValueDef($rsnew, $this->balance->CurrentValue, 0, $this->balance->ReadOnly);

			// confcode
			$this->confcode->setDbValueDef($rsnew, $this->confcode->CurrentValue, NULL, $this->confcode->ReadOnly);

			// success
			$this->success->setDbValueDef($rsnew, $this->success->CurrentValue, 0, $this->success->ReadOnly);

			// transdate
			$this->transdate->setDbValueDef($rsnew, UnFormatDateTime($this->transdate->CurrentValue, 2), NULL, $this->transdate->ReadOnly);

			// userid
			$this->_userid->setDbValueDef($rsnew, $this->_userid->CurrentValue, 0, $this->_userid->ReadOnly);

			// billerresponse
			$this->billerresponse->setDbValueDef($rsnew, $this->billerresponse->CurrentValue, NULL, $this->billerresponse->ReadOnly);

			// paymenttype
			$this->paymenttype->setDbValueDef($rsnew, $this->paymenttype->CurrentValue, 0, $this->paymenttype->ReadOnly);

			// customername
			$this->customername->setDbValueDef($rsnew, $this->customername->CurrentValue, NULL, $this->customername->ReadOnly);

			// refno
			$this->refno->setDbValueDef($rsnew, $this->refno->CurrentValue, NULL, $this->refno->ReadOnly);

			// feeid
			$this->feeid->setDbValueDef($rsnew, $this->feeid->CurrentValue, 0, $this->feeid->ReadOnly);

			// tabletype
			$this->_tabletype->setDbValueDef($rsnew, $this->_tabletype->CurrentValue, 0, $this->_tabletype->ReadOnly);

			// feemerchanttotal
			$this->feemerchanttotal->setDbValueDef($rsnew, $this->feemerchanttotal->CurrentValue, 0, $this->feemerchanttotal->ReadOnly);

			// feeconsumertotal
			$this->feeconsumertotal->setDbValueDef($rsnew, $this->feeconsumertotal->CurrentValue, 0, $this->feeconsumertotal->ReadOnly);

			// feesystemtotal
			$this->feesystemtotal->setDbValueDef($rsnew, $this->feesystemtotal->CurrentValue, 0, $this->feesystemtotal->ReadOnly);

			// feeexternaltotal
			$this->feeexternaltotal->setDbValueDef($rsnew, $this->feeexternaltotal->CurrentValue, 0, $this->feeexternaltotal->ReadOnly);

			// feefranchiseetotal
			$this->feefranchiseetotal->setDbValueDef($rsnew, $this->feefranchiseetotal->CurrentValue, 0, $this->feefranchiseetotal->ReadOnly);

			// feeresellertotal
			$this->feeresellertotal->setDbValueDef($rsnew, $this->feeresellertotal->CurrentValue, 0, $this->feeresellertotal->ReadOnly);

			// branchname
			$this->branchname->setDbValueDef($rsnew, $this->branchname->CurrentValue, NULL, $this->branchname->ReadOnly);

			// clerkname
			$this->clerkname->setDbValueDef($rsnew, $this->clerkname->CurrentValue, NULL, $this->clerkname->ReadOnly);

			// taxamount
			$this->taxamount->setDbValueDef($rsnew, $this->taxamount->CurrentValue, NULL, $this->taxamount->ReadOnly);

			// totalamount
			$this->totalamount->setDbValueDef($rsnew, $this->totalamount->CurrentValue, NULL, $this->totalamount->ReadOnly);

			// taxperc
			$this->taxperc->setDbValueDef($rsnew, $this->taxperc->CurrentValue, NULL, $this->taxperc->ReadOnly);

			// otherdetails
			$this->otherdetails->setDbValueDef($rsnew, $this->otherdetails->CurrentValue, NULL, $this->otherdetails->ReadOnly);

			// transgroupid
			$this->transgroupid->setDbValueDef($rsnew, $this->transgroupid->CurrentValue, NULL, $this->transgroupid->ReadOnly);

			// department
			$this->department->setDbValueDef($rsnew, $this->department->CurrentValue, NULL, $this->department->ReadOnly);

			// billingresponse2
			$this->billingresponse2->setDbValueDef($rsnew, $this->billingresponse2->CurrentValue, NULL, $this->billingresponse2->ReadOnly);

			// purchaseid
			$this->purchaseid->setDbValueDef($rsnew, $this->purchaseid->CurrentValue, 0, $this->purchaseid->ReadOnly);

			// paymentid
			$this->paymentid->setDbValueDef($rsnew, $this->paymentid->CurrentValue, 0, $this->paymentid->ReadOnly);

			// Call Row Updating event
			$updateRow = $this->Row_Updating($rsold, $rsnew);

			// Check for duplicate key when key changed
			if ($updateRow) {
				$newKeyFilter = $this->getRecordFilter($rsnew);
				if ($newKeyFilter != $oldKeyFilter) {
					$rsChk = $this->loadRs($newKeyFilter);
					if ($rsChk && !$rsChk->EOF) {
						$keyErrMsg = str_replace("%f", $newKeyFilter, $Language->phrase("DupKey"));
						$this->setFailureMessage($keyErrMsg);
						$rsChk->close();
						$updateRow = FALSE;
					}
				}
			}
			if ($updateRow) {
				$conn->raiseErrorFn = Config("ERROR_FUNC");
				if (count($rsnew) > 0)
					$editRow = $this->update($rsnew, "", $rsold);
				else
					$editRow = TRUE; // No field to update
				$conn->raiseErrorFn = "";
				if ($editRow) {
				}
			} else {
				if ($this->getSuccessMessage() != "" || $this->getFailureMessage() != "") {

					// Use the message, do nothing
				} elseif ($this->CancelMessage != "") {
					$this->setFailureMessage($this->CancelMessage);
					$this->CancelMessage = "";
				} else {
					$this->setFailureMessage($Language->phrase("UpdateCancelled"));
				}
				$editRow = FALSE;
			}
		}

		// Call Row_Updated event
		if ($editRow)
			$this->Row_Updated($rsold, $rsnew);
		$rs->close();

		// Clean upload path if any
		if ($editRow) {
		}

		// Write JSON for API request
		if (IsApi() && $editRow) {
			$row = $this->getRecordsFromRecordset([$rsnew], TRUE);
			WriteJson(["success" => TRUE, $this->TableVar => $row]);
		}
		return $editRow;
	}

	// Set up Breadcrumb
	protected function setupBreadcrumb()
	{
		global $Breadcrumb, $Language;
		$Breadcrumb = new Breadcrumb();
		$url = substr(CurrentUrl(), strrpos(CurrentUrl(), "/")+1);
		$Breadcrumb->add("list", $this->TableVar, $this->addMasterUrl("billinghistorylist.php"), "", $this->TableVar, TRUE);
		$pageId = "edit";
		$Breadcrumb->add("edit", $pageId, $url);
	}

	// Setup lookup options
	public function setupLookupOptions($fld)
	{
		if ($fld->Lookup !== NULL && $fld->Lookup->Options === NULL) {

			// Get default connection and filter
			$conn = $this->getConnection();
			$lookupFilter = "";

			// No need to check any more
			$fld->Lookup->Options = [];

			// Set up lookup SQL and connection
			switch ($fld->FieldVar) {
				case "x_serviceid":
					$conn = Conn("_4payreference");
					break;
				case "x_success":
					break;
				case "x_paymenttype":
					break;
				case "x_department":
					$conn = Conn("_4payreference");
					break;
				default:
					$lookupFilter = "";
					break;
			}

			// Always call to Lookup->getSql so that user can setup Lookup->Options in Lookup_Selecting server event
			$sql = $fld->Lookup->getSql(FALSE, "", $lookupFilter, $this);

			// Set up lookup cache
			if ($fld->UseLookupCache && $sql != "" && count($fld->Lookup->Options) == 0) {
				$totalCnt = $this->getRecordCount($sql, $conn);
				if ($totalCnt > $fld->LookupCacheCount) // Total count > cache count, do not cache
					return;
				$rs = $conn->execute($sql);
				$ar = [];
				while ($rs && !$rs->EOF) {
					$row = &$rs->fields;

					// Format the field values
					switch ($fld->FieldVar) {
						case "x_serviceid":
							break;
						case "x_success":
							break;
						case "x_department":
							break;
					}
					$ar[strval($row[0])] = $row;
					$rs->moveNext();
				}
				if ($rs)
					$rs->close();
				$fld->Lookup->Options = $ar;
			}
		}
	}

	// Set up starting record parameters
	public function setupStartRecord()
	{
		if ($this->DisplayRecords == 0)
			return;
		if ($this->isPageRequest()) { // Validate request
			$startRec = Get(Config("TABLE_START_REC"));
			$pageNo = Get(Config("TABLE_PAGE_NO"));
			if ($pageNo !== NULL) { // Check for "pageno" parameter first
				if (is_numeric($pageNo)) {
					$this->StartRecord = ($pageNo - 1) * $this->DisplayRecords + 1;
					if ($this->StartRecord <= 0) {
						$this->StartRecord = 1;
					} elseif ($this->StartRecord >= (int)(($this->TotalRecords - 1)/$this->DisplayRecords) * $this->DisplayRecords + 1) {
						$this->StartRecord = (int)(($this->TotalRecords - 1)/$this->DisplayRecords) * $this->DisplayRecords + 1;
					}
					$this->setStartRecordNumber($this->StartRecord);
				}
			} elseif ($startRec !== NULL) { // Check for "start" parameter
				$this->StartRecord = $startRec;
				$this->setStartRecordNumber($this->StartRecord);
			}
		}
		$this->StartRecord = $this->getStartRecordNumber();

		// Check if correct start record counter
		if (!is_numeric($this->StartRecord) || $this->StartRecord == "") { // Avoid invalid start record counter
			$this->StartRecord = 1; // Reset start record counter
			$this->setStartRecordNumber($this->StartRecord);
		} elseif ($this->StartRecord > $this->TotalRecords) { // Avoid starting record > total records
			$this->StartRecord = (int)(($this->TotalRecords - 1)/$this->DisplayRecords) * $this->DisplayRecords + 1; // Point to last page first record
			$this->setStartRecordNumber($this->StartRecord);
		} elseif (($this->StartRecord - 1) % $this->DisplayRecords != 0) {
			$this->StartRecord = (int)(($this->StartRecord - 1)/$this->DisplayRecords) * $this->DisplayRecords + 1; // Point to page boundary
			$this->setStartRecordNumber($this->StartRecord);
		}
	}

	// Page Load event
	function Page_Load() {

		//echo "Page Load";
	}

	// Page Unload event
	function Page_Unload() {

		//echo "Page Unload";
	}

	// Page Redirecting event
	function Page_Redirecting(&$url) {

		// Example:
		//$url = "your URL";

	}

	// Message Showing event
	// $type = ''|'success'|'failure'|'warning'
	function Message_Showing(&$msg, $type) {
		if ($type == 'success') {

			//$msg = "your success message";
		} elseif ($type == 'failure') {

			//$msg = "your failure message";
		} elseif ($type == 'warning') {

			//$msg = "your warning message";
		} else {

			//$msg = "your message";
		}
	}

	// Page Render event
	function Page_Render() {

		//echo "Page Render";
	}

	// Page Data Rendering event
	function Page_DataRendering(&$header) {

		// Example:
		//$header = "your header";

	}

	// Page Data Rendered event
	function Page_DataRendered(&$footer) {

		// Example:
		//$footer = "your footer";

	}

	// Form Custom Validate event
	function Form_CustomValidate(&$customError) {

		// Return error message in CustomError
		return TRUE;
	}
} // End class
?>