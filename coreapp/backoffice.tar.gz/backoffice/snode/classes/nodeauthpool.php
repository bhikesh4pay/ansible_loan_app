<?php namespace PHPMaker2020\_4payadmin; ?>
<?php

/**
 * Table class for nodeauthpool
 */
class nodeauthpool extends DbTable
{
	protected $SqlFrom = "";
	protected $SqlSelect = "";
	protected $SqlSelectList = "";
	protected $SqlWhere = "";
	protected $SqlGroupBy = "";
	protected $SqlHaving = "";
	protected $SqlOrderBy = "";
	public $UseSessionForListSql = TRUE;

	// Column CSS classes
	public $LeftColumnClass = "col-sm-2 col-form-label ew-label";
	public $RightColumnClass = "col-sm-10";
	public $OffsetColumnClass = "col-sm-10 offset-sm-2";
	public $TableLeftColumnClass = "w-col-2";

	// Audit trail
	public $AuditTrailOnAdd = TRUE;
	public $AuditTrailOnEdit = TRUE;
	public $AuditTrailOnDelete = TRUE;
	public $AuditTrailOnView = FALSE;
	public $AuditTrailOnViewData = FALSE;
	public $AuditTrailOnSearch = FALSE;

	// Export
	public $ExportDoc;

	// Fields
	public $authid;
	public $txid;
	public $merchantid;
	public $profileid;
	public $status;
	public $authtime;
	public $expirationTimeInMinutes;
	public $expirationTime;
	public $_userid;
	public $usersnodeid;
	public $firstname;
	public $lastname;

	// Constructor
	public function __construct()
	{
		global $Language, $CurrentLanguage;
		parent::__construct();

		// Language object
		if (!isset($Language))
			$Language = new Language();
		$this->TableVar = 'nodeauthpool';
		$this->TableName = 'nodeauthpool';
		$this->TableType = 'TABLE';

		// Update Table
		$this->UpdateTable = "`nodeauthpool`";
		$this->Dbid = 'DB';
		$this->ExportAll = TRUE;
		$this->ExportPageBreakCount = 0; // Page break per every n record (PDF only)
		$this->ExportPageOrientation = "portrait"; // Page orientation (PDF only)
		$this->ExportPageSize = "a4"; // Page size (PDF only)
		$this->ExportExcelPageOrientation = \PhpOffice\PhpSpreadsheet\Worksheet\PageSetup::ORIENTATION_DEFAULT; // Page orientation (PhpSpreadsheet only)
		$this->ExportExcelPageSize = \PhpOffice\PhpSpreadsheet\Worksheet\PageSetup::PAPERSIZE_A4; // Page size (PhpSpreadsheet only)
		$this->ExportWordPageOrientation = "portrait"; // Page orientation (PHPWord only)
		$this->ExportWordColumnWidth = NULL; // Cell width (PHPWord only)
		$this->DetailAdd = FALSE; // Allow detail add
		$this->DetailEdit = FALSE; // Allow detail edit
		$this->DetailView = FALSE; // Allow detail view
		$this->ShowMultipleDetails = FALSE; // Show multiple details
		$this->GridAddRowCount = 5;
		$this->AllowAddDeleteRow = TRUE; // Allow add/delete row
		$this->UserIDAllowSecurity = Config("DEFAULT_USER_ID_ALLOW_SECURITY"); // Default User ID allowed permissions
		$this->BasicSearch = new BasicSearch($this->TableVar);

		// authid
		$this->authid = new DbField('nodeauthpool', 'nodeauthpool', 'x_authid', 'authid', '`authid`', '`authid`', 3, 12, -1, FALSE, '`authid`', FALSE, FALSE, FALSE, 'FORMATTED TEXT', 'NO');
		$this->authid->IsAutoIncrement = TRUE; // Autoincrement field
		$this->authid->IsPrimaryKey = TRUE; // Primary key field
		$this->authid->Sortable = TRUE; // Allow sort
		$this->authid->DefaultErrorMessage = $Language->phrase("IncorrectInteger");
		$this->fields['authid'] = &$this->authid;

		// txid
		$this->txid = new DbField('nodeauthpool', 'nodeauthpool', 'x_txid', 'txid', '`txid`', '`txid`', 200, 10, -1, FALSE, '`txid`', FALSE, FALSE, FALSE, 'FORMATTED TEXT', 'TEXT');
		$this->txid->Nullable = FALSE; // NOT NULL field
		$this->txid->Required = TRUE; // Required field
		$this->txid->Sortable = TRUE; // Allow sort
		$this->fields['txid'] = &$this->txid;

		// merchantid
		$this->merchantid = new DbField('nodeauthpool', 'nodeauthpool', 'x_merchantid', 'merchantid', '`merchantid`', '`merchantid`', 3, 12, -1, FALSE, '`merchantid`', FALSE, FALSE, FALSE, 'FORMATTED TEXT', 'TEXT');
		$this->merchantid->Nullable = FALSE; // NOT NULL field
		$this->merchantid->Required = TRUE; // Required field
		$this->merchantid->Sortable = TRUE; // Allow sort
		$this->merchantid->DefaultErrorMessage = $Language->phrase("IncorrectInteger");
		$this->fields['merchantid'] = &$this->merchantid;

		// profileid
		$this->profileid = new DbField('nodeauthpool', 'nodeauthpool', 'x_profileid', 'profileid', '`profileid`', '`profileid`', 3, 12, -1, FALSE, '`profileid`', FALSE, FALSE, FALSE, 'FORMATTED TEXT', 'TEXT');
		$this->profileid->Nullable = FALSE; // NOT NULL field
		$this->profileid->Required = TRUE; // Required field
		$this->profileid->Sortable = TRUE; // Allow sort
		$this->profileid->DefaultErrorMessage = $Language->phrase("IncorrectInteger");
		$this->fields['profileid'] = &$this->profileid;

		// status
		$this->status = new DbField('nodeauthpool', 'nodeauthpool', 'x_status', 'status', '`status`', '`status`', 3, 3, -1, FALSE, '`status`', FALSE, FALSE, FALSE, 'FORMATTED TEXT', 'TEXT');
		$this->status->Nullable = FALSE; // NOT NULL field
		$this->status->Required = TRUE; // Required field
		$this->status->Sortable = TRUE; // Allow sort
		$this->status->DefaultErrorMessage = $Language->phrase("IncorrectInteger");
		$this->fields['status'] = &$this->status;

		// authtime
		$this->authtime = new DbField('nodeauthpool', 'nodeauthpool', 'x_authtime', 'authtime', '`authtime`', CastDateFieldForLike("`authtime`", 0, "DB"), 135, 19, 0, FALSE, '`authtime`', FALSE, FALSE, FALSE, 'FORMATTED TEXT', 'TEXT');
		$this->authtime->Sortable = TRUE; // Allow sort
		$this->authtime->DefaultErrorMessage = str_replace("%s", $GLOBALS["DATE_FORMAT"], $Language->phrase("IncorrectDate"));
		$this->fields['authtime'] = &$this->authtime;

		// expirationTimeInMinutes
		$this->expirationTimeInMinutes = new DbField('nodeauthpool', 'nodeauthpool', 'x_expirationTimeInMinutes', 'expirationTimeInMinutes', '`expirationTimeInMinutes`', '`expirationTimeInMinutes`', 3, 6, -1, FALSE, '`expirationTimeInMinutes`', FALSE, FALSE, FALSE, 'FORMATTED TEXT', 'TEXT');
		$this->expirationTimeInMinutes->Nullable = FALSE; // NOT NULL field
		$this->expirationTimeInMinutes->Required = TRUE; // Required field
		$this->expirationTimeInMinutes->Sortable = TRUE; // Allow sort
		$this->expirationTimeInMinutes->DefaultErrorMessage = $Language->phrase("IncorrectInteger");
		$this->fields['expirationTimeInMinutes'] = &$this->expirationTimeInMinutes;

		// expirationTime
		$this->expirationTime = new DbField('nodeauthpool', 'nodeauthpool', 'x_expirationTime', 'expirationTime', '`expirationTime`', CastDateFieldForLike("`expirationTime`", 0, "DB"), 135, 19, 0, FALSE, '`expirationTime`', FALSE, FALSE, FALSE, 'FORMATTED TEXT', 'TEXT');
		$this->expirationTime->Sortable = TRUE; // Allow sort
		$this->expirationTime->DefaultErrorMessage = str_replace("%s", $GLOBALS["DATE_FORMAT"], $Language->phrase("IncorrectDate"));
		$this->fields['expirationTime'] = &$this->expirationTime;

		// userid
		$this->_userid = new DbField('nodeauthpool', 'nodeauthpool', 'x__userid', 'userid', '`userid`', '`userid`', 3, 12, -1, FALSE, '`userid`', FALSE, FALSE, FALSE, 'FORMATTED TEXT', 'TEXT');
		$this->_userid->Sortable = TRUE; // Allow sort
		$this->_userid->DefaultErrorMessage = $Language->phrase("IncorrectInteger");
		$this->fields['userid'] = &$this->_userid;

		// usersnodeid
		$this->usersnodeid = new DbField('nodeauthpool', 'nodeauthpool', 'x_usersnodeid', 'usersnodeid', '`usersnodeid`', '`usersnodeid`', 3, 5, -1, FALSE, '`usersnodeid`', FALSE, FALSE, FALSE, 'FORMATTED TEXT', 'TEXT');
		$this->usersnodeid->Sortable = TRUE; // Allow sort
		$this->usersnodeid->DefaultErrorMessage = $Language->phrase("IncorrectInteger");
		$this->fields['usersnodeid'] = &$this->usersnodeid;

		// firstname
		$this->firstname = new DbField('nodeauthpool', 'nodeauthpool', 'x_firstname', 'firstname', '`firstname`', '`firstname`', 200, 60, -1, FALSE, '`firstname`', FALSE, FALSE, FALSE, 'FORMATTED TEXT', 'TEXT');
		$this->firstname->Sortable = TRUE; // Allow sort
		$this->fields['firstname'] = &$this->firstname;

		// lastname
		$this->lastname = new DbField('nodeauthpool', 'nodeauthpool', 'x_lastname', 'lastname', '`lastname`', '`lastname`', 200, 60, -1, FALSE, '`lastname`', FALSE, FALSE, FALSE, 'FORMATTED TEXT', 'TEXT');
		$this->lastname->Sortable = TRUE; // Allow sort
		$this->fields['lastname'] = &$this->lastname;
	}

	// Field Visibility
	public function getFieldVisibility($fldParm)
	{
		global $Security;
		return $this->$fldParm->Visible; // Returns original value
	}

	// Set left column class (must be predefined col-*-* classes of Bootstrap grid system)
	function setLeftColumnClass($class)
	{
		if (preg_match('/^col\-(\w+)\-(\d+)$/', $class, $match)) {
			$this->LeftColumnClass = $class . " col-form-label ew-label";
			$this->RightColumnClass = "col-" . $match[1] . "-" . strval(12 - (int)$match[2]);
			$this->OffsetColumnClass = $this->RightColumnClass . " " . str_replace("col-", "offset-", $class);
			$this->TableLeftColumnClass = preg_replace('/^col-\w+-(\d+)$/', "w-col-$1", $class); // Change to w-col-*
		}
	}

	// Single column sort
	public function updateSort(&$fld)
	{
		if ($this->CurrentOrder == $fld->Name) {
			$sortField = $fld->Expression;
			$lastSort = $fld->getSort();
			if ($this->CurrentOrderType == "ASC" || $this->CurrentOrderType == "DESC") {
				$thisSort = $this->CurrentOrderType;
			} else {
				$thisSort = ($lastSort == "ASC") ? "DESC" : "ASC";
			}
			$fld->setSort($thisSort);
			$this->setSessionOrderBy($sortField . " " . $thisSort); // Save to Session
		} else {
			$fld->setSort("");
		}
	}

	// Table level SQL
	public function getSqlFrom() // From
	{
		return ($this->SqlFrom != "") ? $this->SqlFrom : "`nodeauthpool`";
	}
	public function sqlFrom() // For backward compatibility
	{
		return $this->getSqlFrom();
	}
	public function setSqlFrom($v)
	{
		$this->SqlFrom = $v;
	}
	public function getSqlSelect() // Select
	{
		return ($this->SqlSelect != "") ? $this->SqlSelect : "SELECT * FROM " . $this->getSqlFrom();
	}
	public function sqlSelect() // For backward compatibility
	{
		return $this->getSqlSelect();
	}
	public function setSqlSelect($v)
	{
		$this->SqlSelect = $v;
	}
	public function getSqlWhere() // Where
	{
		$where = ($this->SqlWhere != "") ? $this->SqlWhere : "";
		$this->TableFilter = "";
		AddFilter($where, $this->TableFilter);
		return $where;
	}
	public function sqlWhere() // For backward compatibility
	{
		return $this->getSqlWhere();
	}
	public function setSqlWhere($v)
	{
		$this->SqlWhere = $v;
	}
	public function getSqlGroupBy() // Group By
	{
		return ($this->SqlGroupBy != "") ? $this->SqlGroupBy : "";
	}
	public function sqlGroupBy() // For backward compatibility
	{
		return $this->getSqlGroupBy();
	}
	public function setSqlGroupBy($v)
	{
		$this->SqlGroupBy = $v;
	}
	public function getSqlHaving() // Having
	{
		return ($this->SqlHaving != "") ? $this->SqlHaving : "";
	}
	public function sqlHaving() // For backward compatibility
	{
		return $this->getSqlHaving();
	}
	public function setSqlHaving($v)
	{
		$this->SqlHaving = $v;
	}
	public function getSqlOrderBy() // Order By
	{
		return ($this->SqlOrderBy != "") ? $this->SqlOrderBy : "";
	}
	public function sqlOrderBy() // For backward compatibility
	{
		return $this->getSqlOrderBy();
	}
	public function setSqlOrderBy($v)
	{
		$this->SqlOrderBy = $v;
	}

	// Apply User ID filters
	public function applyUserIDFilters($filter, $id = "")
	{
		return $filter;
	}

	// Check if User ID security allows view all
	public function userIDAllow($id = "")
	{
		$allow = $this->UserIDAllowSecurity;
		switch ($id) {
			case "add":
			case "copy":
			case "gridadd":
			case "register":
			case "addopt":
				return (($allow & 1) == 1);
			case "edit":
			case "gridedit":
			case "update":
			case "changepwd":
			case "forgotpwd":
				return (($allow & 4) == 4);
			case "delete":
				return (($allow & 2) == 2);
			case "view":
				return (($allow & 32) == 32);
			case "search":
				return (($allow & 64) == 64);
			case "lookup":
				return (($allow & 256) == 256);
			default:
				return (($allow & 8) == 8);
		}
	}

	// Get recordset
	public function getRecordset($sql, $rowcnt = -1, $offset = -1)
	{
		$conn = $this->getConnection();
		$conn->raiseErrorFn = Config("ERROR_FUNC");
		$rs = $conn->selectLimit($sql, $rowcnt, $offset);
		$conn->raiseErrorFn = "";
		return $rs;
	}

	// Get record count
	public function getRecordCount($sql, $c = NULL)
	{
		$cnt = -1;
		$rs = NULL;
		$sql = preg_replace('/\/\*BeginOrderBy\*\/[\s\S]+\/\*EndOrderBy\*\//', "", $sql); // Remove ORDER BY clause (MSSQL)
		$pattern = '/^SELECT\s([\s\S]+)\sFROM\s/i';

		// Skip Custom View / SubQuery / SELECT DISTINCT / ORDER BY
		if (($this->TableType == 'TABLE' || $this->TableType == 'VIEW' || $this->TableType == 'LINKTABLE') &&
			preg_match($pattern, $sql) && !preg_match('/\(\s*(SELECT[^)]+)\)/i', $sql) &&
			!preg_match('/^\s*select\s+distinct\s+/i', $sql) && !preg_match('/\s+order\s+by\s+/i', $sql)) {
			$sqlwrk = "SELECT COUNT(*) FROM " . preg_replace($pattern, "", $sql);
		} else {
			$sqlwrk = "SELECT COUNT(*) FROM (" . $sql . ") COUNT_TABLE";
		}
		$conn = $c ?: $this->getConnection();
		if ($rs = $conn->execute($sqlwrk)) {
			if (!$rs->EOF && $rs->FieldCount() > 0) {
				$cnt = $rs->fields[0];
				$rs->close();
			}
			return (int)$cnt;
		}

		// Unable to get count, get record count directly
		if ($rs = $conn->execute($sql)) {
			$cnt = $rs->RecordCount();
			$rs->close();
			return (int)$cnt;
		}
		return $cnt;
	}

	// Get SQL
	public function getSql($where, $orderBy = "")
	{
		return BuildSelectSql($this->getSqlSelect(), $this->getSqlWhere(),
			$this->getSqlGroupBy(), $this->getSqlHaving(), $this->getSqlOrderBy(),
			$where, $orderBy);
	}

	// Table SQL
	public function getCurrentSql()
	{
		$filter = $this->CurrentFilter;
		$filter = $this->applyUserIDFilters($filter);
		$sort = $this->getSessionOrderBy();
		return $this->getSql($filter, $sort);
	}

	// Table SQL with List page filter
	public function getListSql()
	{
		$filter = $this->UseSessionForListSql ? $this->getSessionWhere() : "";
		AddFilter($filter, $this->CurrentFilter);
		$filter = $this->applyUserIDFilters($filter);
		$this->Recordset_Selecting($filter);
		$select = $this->getSqlSelect();
		$sort = $this->UseSessionForListSql ? $this->getSessionOrderBy() : "";
		return BuildSelectSql($select, $this->getSqlWhere(), $this->getSqlGroupBy(),
			$this->getSqlHaving(), $this->getSqlOrderBy(), $filter, $sort);
	}

	// Get ORDER BY clause
	public function getOrderBy()
	{
		$sort = $this->getSessionOrderBy();
		return BuildSelectSql("", "", "", "", $this->getSqlOrderBy(), "", $sort);
	}

	// Get record count based on filter (for detail record count in master table pages)
	public function loadRecordCount($filter)
	{
		$origFilter = $this->CurrentFilter;
		$this->CurrentFilter = $filter;
		$this->Recordset_Selecting($this->CurrentFilter);
		$select = $this->TableType == 'CUSTOMVIEW' ? $this->getSqlSelect() : "SELECT * FROM " . $this->getSqlFrom();
		$groupBy = $this->TableType == 'CUSTOMVIEW' ? $this->getSqlGroupBy() : "";
		$having = $this->TableType == 'CUSTOMVIEW' ? $this->getSqlHaving() : "";
		$sql = BuildSelectSql($select, $this->getSqlWhere(), $groupBy, $having, "", $this->CurrentFilter, "");
		$cnt = $this->getRecordCount($sql);
		$this->CurrentFilter = $origFilter;
		return $cnt;
	}

	// Get record count (for current List page)
	public function listRecordCount()
	{
		$filter = $this->getSessionWhere();
		AddFilter($filter, $this->CurrentFilter);
		$filter = $this->applyUserIDFilters($filter);
		$this->Recordset_Selecting($filter);
		$select = $this->TableType == 'CUSTOMVIEW' ? $this->getSqlSelect() : "SELECT * FROM " . $this->getSqlFrom();
		$groupBy = $this->TableType == 'CUSTOMVIEW' ? $this->getSqlGroupBy() : "";
		$having = $this->TableType == 'CUSTOMVIEW' ? $this->getSqlHaving() : "";
		$sql = BuildSelectSql($select, $this->getSqlWhere(), $groupBy, $having, "", $filter, "");
		$cnt = $this->getRecordCount($sql);
		return $cnt;
	}

	// INSERT statement
	protected function insertSql(&$rs)
	{
		$names = "";
		$values = "";
		foreach ($rs as $name => $value) {
			if (!isset($this->fields[$name]) || $this->fields[$name]->IsCustom)
				continue;
			$names .= $this->fields[$name]->Expression . ",";
			$values .= QuotedValue($value, $this->fields[$name]->DataType, $this->Dbid) . ",";
		}
		$names = preg_replace('/,+$/', "", $names);
		$values = preg_replace('/,+$/', "", $values);
		return "INSERT INTO " . $this->UpdateTable . " (" . $names . ") VALUES (" . $values . ")";
	}

	// Insert
	public function insert(&$rs)
	{
		$conn = $this->getConnection();
		$success = $conn->execute($this->insertSql($rs));
		if ($success) {

			// Get insert id if necessary
			$this->authid->setDbValue($conn->insert_ID());
			$rs['authid'] = $this->authid->DbValue;
			if ($this->AuditTrailOnAdd)
				$this->writeAuditTrailOnAdd($rs);
		}
		return $success;
	}

	// UPDATE statement
	protected function updateSql(&$rs, $where = "", $curfilter = TRUE)
	{
		$sql = "UPDATE " . $this->UpdateTable . " SET ";
		foreach ($rs as $name => $value) {
			if (!isset($this->fields[$name]) || $this->fields[$name]->IsCustom || $this->fields[$name]->IsAutoIncrement)
				continue;
			$sql .= $this->fields[$name]->Expression . "=";
			$sql .= QuotedValue($value, $this->fields[$name]->DataType, $this->Dbid) . ",";
		}
		$sql = preg_replace('/,+$/', "", $sql);
		$filter = ($curfilter) ? $this->CurrentFilter : "";
		if (is_array($where))
			$where = $this->arrayToFilter($where);
		AddFilter($filter, $where);
		if ($filter != "")
			$sql .= " WHERE " . $filter;
		return $sql;
	}

	// Update
	public function update(&$rs, $where = "", $rsold = NULL, $curfilter = TRUE)
	{
		$conn = $this->getConnection();
		$success = $conn->execute($this->updateSql($rs, $where, $curfilter));
		if ($success && $this->AuditTrailOnEdit && $rsold) {
			$rsaudit = $rs;
			$fldname = 'authid';
			if (!array_key_exists($fldname, $rsaudit))
				$rsaudit[$fldname] = $rsold[$fldname];
			$this->writeAuditTrailOnEdit($rsold, $rsaudit);
		}
		return $success;
	}

	// DELETE statement
	protected function deleteSql(&$rs, $where = "", $curfilter = TRUE)
	{
		$sql = "DELETE FROM " . $this->UpdateTable . " WHERE ";
		if (is_array($where))
			$where = $this->arrayToFilter($where);
		if ($rs) {
			if (array_key_exists('authid', $rs))
				AddFilter($where, QuotedName('authid', $this->Dbid) . '=' . QuotedValue($rs['authid'], $this->authid->DataType, $this->Dbid));
		}
		$filter = ($curfilter) ? $this->CurrentFilter : "";
		AddFilter($filter, $where);
		if ($filter != "")
			$sql .= $filter;
		else
			$sql .= "0=1"; // Avoid delete
		return $sql;
	}

	// Delete
	public function delete(&$rs, $where = "", $curfilter = FALSE)
	{
		$success = TRUE;
		$conn = $this->getConnection();
		if ($success)
			$success = $conn->execute($this->deleteSql($rs, $where, $curfilter));
		if ($success && $this->AuditTrailOnDelete)
			$this->writeAuditTrailOnDelete($rs);
		return $success;
	}

	// Load DbValue from recordset or array
	protected function loadDbValues(&$rs)
	{
		if (!$rs || !is_array($rs) && $rs->EOF)
			return;
		$row = is_array($rs) ? $rs : $rs->fields;
		$this->authid->DbValue = $row['authid'];
		$this->txid->DbValue = $row['txid'];
		$this->merchantid->DbValue = $row['merchantid'];
		$this->profileid->DbValue = $row['profileid'];
		$this->status->DbValue = $row['status'];
		$this->authtime->DbValue = $row['authtime'];
		$this->expirationTimeInMinutes->DbValue = $row['expirationTimeInMinutes'];
		$this->expirationTime->DbValue = $row['expirationTime'];
		$this->_userid->DbValue = $row['userid'];
		$this->usersnodeid->DbValue = $row['usersnodeid'];
		$this->firstname->DbValue = $row['firstname'];
		$this->lastname->DbValue = $row['lastname'];
	}

	// Delete uploaded files
	public function deleteUploadedFiles($row)
	{
		$this->loadDbValues($row);
	}

	// Record filter WHERE clause
	protected function sqlKeyFilter()
	{
		return "`authid` = @authid@";
	}

	// Get record filter
	public function getRecordFilter($row = NULL)
	{
		$keyFilter = $this->sqlKeyFilter();
		if (is_array($row))
			$val = array_key_exists('authid', $row) ? $row['authid'] : NULL;
		else
			$val = $this->authid->OldValue !== NULL ? $this->authid->OldValue : $this->authid->CurrentValue;
		if (!is_numeric($val))
			return "0=1"; // Invalid key
		if ($val == NULL)
			return "0=1"; // Invalid key
		else
			$keyFilter = str_replace("@authid@", AdjustSql($val, $this->Dbid), $keyFilter); // Replace key value
		return $keyFilter;
	}

	// Return page URL
	public function getReturnUrl()
	{
		$name = PROJECT_NAME . "_" . $this->TableVar . "_" . Config("TABLE_RETURN_URL");

		// Get referer URL automatically
		if (ServerVar("HTTP_REFERER") != "" && ReferPageName() != CurrentPageName() && ReferPageName() != "login.php") // Referer not same page or login page
			$_SESSION[$name] = ServerVar("HTTP_REFERER"); // Save to Session
		if (@$_SESSION[$name] != "") {
			return $_SESSION[$name];
		} else {
			return "nodeauthpoollist.php";
		}
	}
	public function setReturnUrl($v)
	{
		$_SESSION[PROJECT_NAME . "_" . $this->TableVar . "_" . Config("TABLE_RETURN_URL")] = $v;
	}

	// Get modal caption
	public function getModalCaption($pageName)
	{
		global $Language;
		if ($pageName == "nodeauthpoolview.php")
			return $Language->phrase("View");
		elseif ($pageName == "nodeauthpooledit.php")
			return $Language->phrase("Edit");
		elseif ($pageName == "nodeauthpooladd.php")
			return $Language->phrase("Add");
		else
			return "";
	}

	// List URL
	public function getListUrl()
	{
		return "nodeauthpoollist.php";
	}

	// View URL
	public function getViewUrl($parm = "")
	{
		if ($parm != "")
			$url = $this->keyUrl("nodeauthpoolview.php", $this->getUrlParm($parm));
		else
			$url = $this->keyUrl("nodeauthpoolview.php", $this->getUrlParm(Config("TABLE_SHOW_DETAIL") . "="));
		return $this->addMasterUrl($url);
	}

	// Add URL
	public function getAddUrl($parm = "")
	{
		if ($parm != "")
			$url = "nodeauthpooladd.php?" . $this->getUrlParm($parm);
		else
			$url = "nodeauthpooladd.php";
		return $this->addMasterUrl($url);
	}

	// Edit URL
	public function getEditUrl($parm = "")
	{
		$url = $this->keyUrl("nodeauthpooledit.php", $this->getUrlParm($parm));
		return $this->addMasterUrl($url);
	}

	// Inline edit URL
	public function getInlineEditUrl()
	{
		$url = $this->keyUrl(CurrentPageName(), $this->getUrlParm("action=edit"));
		return $this->addMasterUrl($url);
	}

	// Copy URL
	public function getCopyUrl($parm = "")
	{
		$url = $this->keyUrl("nodeauthpooladd.php", $this->getUrlParm($parm));
		return $this->addMasterUrl($url);
	}

	// Inline copy URL
	public function getInlineCopyUrl()
	{
		$url = $this->keyUrl(CurrentPageName(), $this->getUrlParm("action=copy"));
		return $this->addMasterUrl($url);
	}

	// Delete URL
	public function getDeleteUrl()
	{
		return $this->keyUrl("nodeauthpooldelete.php", $this->getUrlParm());
	}

	// Add master url
	public function addMasterUrl($url)
	{
		return $url;
	}
	public function keyToJson($htmlEncode = FALSE)
	{
		$json = "";
		$json .= "authid:" . JsonEncode($this->authid->CurrentValue, "number");
		$json = "{" . $json . "}";
		if ($htmlEncode)
			$json = HtmlEncode($json);
		return $json;
	}

	// Add key value to URL
	public function keyUrl($url, $parm = "")
	{
		$url = $url . "?";
		if ($parm != "")
			$url .= $parm . "&";
		if ($this->authid->CurrentValue != NULL) {
			$url .= "authid=" . urlencode($this->authid->CurrentValue);
		} else {
			return "javascript:ew.alert(ew.language.phrase('InvalidRecord'));";
		}
		return $url;
	}

	// Sort URL
	public function sortUrl(&$fld)
	{
		if ($this->CurrentAction || $this->isExport() ||
			in_array($fld->Type, [128, 204, 205])) { // Unsortable data type
				return "";
		} elseif ($fld->Sortable) {
			$urlParm = $this->getUrlParm("order=" . urlencode($fld->Name) . "&amp;ordertype=" . $fld->reverseSort());
			return $this->addMasterUrl(CurrentPageName() . "?" . $urlParm);
		} else {
			return "";
		}
	}

	// Get record keys from Post/Get/Session
	public function getRecordKeys()
	{
		$arKeys = [];
		$arKey = [];
		if (Param("key_m") !== NULL) {
			$arKeys = Param("key_m");
			$cnt = count($arKeys);
		} else {
			if (Param("authid") !== NULL)
				$arKeys[] = Param("authid");
			elseif (IsApi() && Key(0) !== NULL)
				$arKeys[] = Key(0);
			elseif (IsApi() && Route(2) !== NULL)
				$arKeys[] = Route(2);
			else
				$arKeys = NULL; // Do not setup

			//return $arKeys; // Do not return yet, so the values will also be checked by the following code
		}

		// Check keys
		$ar = [];
		if (is_array($arKeys)) {
			foreach ($arKeys as $key) {
				if (!is_numeric($key))
					continue;
				$ar[] = $key;
			}
		}
		return $ar;
	}

	// Get filter from record keys
	public function getFilterFromRecordKeys($setCurrent = TRUE)
	{
		$arKeys = $this->getRecordKeys();
		$keyFilter = "";
		foreach ($arKeys as $key) {
			if ($keyFilter != "") $keyFilter .= " OR ";
			if ($setCurrent)
				$this->authid->CurrentValue = $key;
			else
				$this->authid->OldValue = $key;
			$keyFilter .= "(" . $this->getRecordFilter() . ")";
		}
		return $keyFilter;
	}

	// Load rows based on filter
	public function &loadRs($filter)
	{

		// Set up filter (WHERE Clause)
		$sql = $this->getSql($filter);
		$conn = $this->getConnection();
		$rs = $conn->execute($sql);
		return $rs;
	}

	// Load row values from recordset
	public function loadListRowValues(&$rs)
	{
		$this->authid->setDbValue($rs->fields('authid'));
		$this->txid->setDbValue($rs->fields('txid'));
		$this->merchantid->setDbValue($rs->fields('merchantid'));
		$this->profileid->setDbValue($rs->fields('profileid'));
		$this->status->setDbValue($rs->fields('status'));
		$this->authtime->setDbValue($rs->fields('authtime'));
		$this->expirationTimeInMinutes->setDbValue($rs->fields('expirationTimeInMinutes'));
		$this->expirationTime->setDbValue($rs->fields('expirationTime'));
		$this->_userid->setDbValue($rs->fields('userid'));
		$this->usersnodeid->setDbValue($rs->fields('usersnodeid'));
		$this->firstname->setDbValue($rs->fields('firstname'));
		$this->lastname->setDbValue($rs->fields('lastname'));
	}

	// Render list row values
	public function renderListRow()
	{
		global $Security, $CurrentLanguage, $Language;

		// Call Row Rendering event
		$this->Row_Rendering();

		// Common render codes
		// authid
		// txid
		// merchantid
		// profileid
		// status
		// authtime
		// expirationTimeInMinutes
		// expirationTime
		// userid
		// usersnodeid
		// firstname
		// lastname
		// authid

		$this->authid->ViewValue = $this->authid->CurrentValue;
		$this->authid->ViewCustomAttributes = "";

		// txid
		$this->txid->ViewValue = $this->txid->CurrentValue;
		$this->txid->ViewCustomAttributes = "";

		// merchantid
		$this->merchantid->ViewValue = $this->merchantid->CurrentValue;
		$this->merchantid->ViewCustomAttributes = "";

		// profileid
		$this->profileid->ViewValue = $this->profileid->CurrentValue;
		$this->profileid->ViewCustomAttributes = "";

		// status
		$this->status->ViewValue = $this->status->CurrentValue;
		$this->status->ViewCustomAttributes = "";

		// authtime
		$this->authtime->ViewValue = $this->authtime->CurrentValue;
		$this->authtime->ViewValue = FormatDateTime($this->authtime->ViewValue, 0);
		$this->authtime->ViewCustomAttributes = "";

		// expirationTimeInMinutes
		$this->expirationTimeInMinutes->ViewValue = $this->expirationTimeInMinutes->CurrentValue;
		$this->expirationTimeInMinutes->ViewCustomAttributes = "";

		// expirationTime
		$this->expirationTime->ViewValue = $this->expirationTime->CurrentValue;
		$this->expirationTime->ViewValue = FormatDateTime($this->expirationTime->ViewValue, 0);
		$this->expirationTime->ViewCustomAttributes = "";

		// userid
		$this->_userid->ViewValue = $this->_userid->CurrentValue;
		$this->_userid->ViewCustomAttributes = "";

		// usersnodeid
		$this->usersnodeid->ViewValue = $this->usersnodeid->CurrentValue;
		$this->usersnodeid->ViewCustomAttributes = "";

		// firstname
		$this->firstname->ViewValue = $this->firstname->CurrentValue;
		$this->firstname->ViewCustomAttributes = "";

		// lastname
		$this->lastname->ViewValue = $this->lastname->CurrentValue;
		$this->lastname->ViewCustomAttributes = "";

		// authid
		$this->authid->LinkCustomAttributes = "";
		$this->authid->HrefValue = "";
		$this->authid->TooltipValue = "";

		// txid
		$this->txid->LinkCustomAttributes = "";
		$this->txid->HrefValue = "";
		$this->txid->TooltipValue = "";

		// merchantid
		$this->merchantid->LinkCustomAttributes = "";
		$this->merchantid->HrefValue = "";
		$this->merchantid->TooltipValue = "";

		// profileid
		$this->profileid->LinkCustomAttributes = "";
		$this->profileid->HrefValue = "";
		$this->profileid->TooltipValue = "";

		// status
		$this->status->LinkCustomAttributes = "";
		$this->status->HrefValue = "";
		$this->status->TooltipValue = "";

		// authtime
		$this->authtime->LinkCustomAttributes = "";
		$this->authtime->HrefValue = "";
		$this->authtime->TooltipValue = "";

		// expirationTimeInMinutes
		$this->expirationTimeInMinutes->LinkCustomAttributes = "";
		$this->expirationTimeInMinutes->HrefValue = "";
		$this->expirationTimeInMinutes->TooltipValue = "";

		// expirationTime
		$this->expirationTime->LinkCustomAttributes = "";
		$this->expirationTime->HrefValue = "";
		$this->expirationTime->TooltipValue = "";

		// userid
		$this->_userid->LinkCustomAttributes = "";
		$this->_userid->HrefValue = "";
		$this->_userid->TooltipValue = "";

		// usersnodeid
		$this->usersnodeid->LinkCustomAttributes = "";
		$this->usersnodeid->HrefValue = "";
		$this->usersnodeid->TooltipValue = "";

		// firstname
		$this->firstname->LinkCustomAttributes = "";
		$this->firstname->HrefValue = "";
		$this->firstname->TooltipValue = "";

		// lastname
		$this->lastname->LinkCustomAttributes = "";
		$this->lastname->HrefValue = "";
		$this->lastname->TooltipValue = "";

		// Call Row Rendered event
		$this->Row_Rendered();

		// Save data for Custom Template
		$this->Rows[] = $this->customTemplateFieldValues();
	}

	// Render edit row values
	public function renderEditRow()
	{
		global $Security, $CurrentLanguage, $Language;

		// Call Row Rendering event
		$this->Row_Rendering();

		// authid
		$this->authid->EditAttrs["class"] = "form-control";
		$this->authid->EditCustomAttributes = "";
		$this->authid->EditValue = $this->authid->CurrentValue;
		$this->authid->ViewCustomAttributes = "";

		// txid
		$this->txid->EditAttrs["class"] = "form-control";
		$this->txid->EditCustomAttributes = "";
		if (!$this->txid->Raw)
			$this->txid->CurrentValue = HtmlDecode($this->txid->CurrentValue);
		$this->txid->EditValue = $this->txid->CurrentValue;
		$this->txid->PlaceHolder = RemoveHtml($this->txid->caption());

		// merchantid
		$this->merchantid->EditAttrs["class"] = "form-control";
		$this->merchantid->EditCustomAttributes = "";
		$this->merchantid->EditValue = $this->merchantid->CurrentValue;
		$this->merchantid->PlaceHolder = RemoveHtml($this->merchantid->caption());

		// profileid
		$this->profileid->EditAttrs["class"] = "form-control";
		$this->profileid->EditCustomAttributes = "";
		$this->profileid->EditValue = $this->profileid->CurrentValue;
		$this->profileid->PlaceHolder = RemoveHtml($this->profileid->caption());

		// status
		$this->status->EditAttrs["class"] = "form-control";
		$this->status->EditCustomAttributes = "";
		$this->status->EditValue = $this->status->CurrentValue;
		$this->status->PlaceHolder = RemoveHtml($this->status->caption());

		// authtime
		$this->authtime->EditAttrs["class"] = "form-control";
		$this->authtime->EditCustomAttributes = "";
		$this->authtime->EditValue = FormatDateTime($this->authtime->CurrentValue, 8);
		$this->authtime->PlaceHolder = RemoveHtml($this->authtime->caption());

		// expirationTimeInMinutes
		$this->expirationTimeInMinutes->EditAttrs["class"] = "form-control";
		$this->expirationTimeInMinutes->EditCustomAttributes = "";
		$this->expirationTimeInMinutes->EditValue = $this->expirationTimeInMinutes->CurrentValue;
		$this->expirationTimeInMinutes->PlaceHolder = RemoveHtml($this->expirationTimeInMinutes->caption());

		// expirationTime
		$this->expirationTime->EditAttrs["class"] = "form-control";
		$this->expirationTime->EditCustomAttributes = "";
		$this->expirationTime->EditValue = FormatDateTime($this->expirationTime->CurrentValue, 8);
		$this->expirationTime->PlaceHolder = RemoveHtml($this->expirationTime->caption());

		// userid
		$this->_userid->EditAttrs["class"] = "form-control";
		$this->_userid->EditCustomAttributes = "";
		$this->_userid->EditValue = $this->_userid->CurrentValue;
		$this->_userid->PlaceHolder = RemoveHtml($this->_userid->caption());

		// usersnodeid
		$this->usersnodeid->EditAttrs["class"] = "form-control";
		$this->usersnodeid->EditCustomAttributes = "";
		$this->usersnodeid->EditValue = $this->usersnodeid->CurrentValue;
		$this->usersnodeid->PlaceHolder = RemoveHtml($this->usersnodeid->caption());

		// firstname
		$this->firstname->EditAttrs["class"] = "form-control";
		$this->firstname->EditCustomAttributes = "";
		if (!$this->firstname->Raw)
			$this->firstname->CurrentValue = HtmlDecode($this->firstname->CurrentValue);
		$this->firstname->EditValue = $this->firstname->CurrentValue;
		$this->firstname->PlaceHolder = RemoveHtml($this->firstname->caption());

		// lastname
		$this->lastname->EditAttrs["class"] = "form-control";
		$this->lastname->EditCustomAttributes = "";
		if (!$this->lastname->Raw)
			$this->lastname->CurrentValue = HtmlDecode($this->lastname->CurrentValue);
		$this->lastname->EditValue = $this->lastname->CurrentValue;
		$this->lastname->PlaceHolder = RemoveHtml($this->lastname->caption());

		// Call Row Rendered event
		$this->Row_Rendered();
	}

	// Aggregate list row values
	public function aggregateListRowValues()
	{
	}

	// Aggregate list row (for rendering)
	public function aggregateListRow()
	{

		// Call Row Rendered event
		$this->Row_Rendered();
	}

	// Export data in HTML/CSV/Word/Excel/Email/PDF format
	public function exportDocument($doc, $recordset, $startRec = 1, $stopRec = 1, $exportPageType = "")
	{
		if (!$recordset || !$doc)
			return;
		if (!$doc->ExportCustom) {

			// Write header
			$doc->exportTableHeader();
			if ($doc->Horizontal) { // Horizontal format, write header
				$doc->beginExportRow();
				if ($exportPageType == "view") {
					$doc->exportCaption($this->authid);
					$doc->exportCaption($this->txid);
					$doc->exportCaption($this->merchantid);
					$doc->exportCaption($this->profileid);
					$doc->exportCaption($this->status);
					$doc->exportCaption($this->authtime);
					$doc->exportCaption($this->expirationTimeInMinutes);
					$doc->exportCaption($this->expirationTime);
					$doc->exportCaption($this->_userid);
					$doc->exportCaption($this->usersnodeid);
					$doc->exportCaption($this->firstname);
					$doc->exportCaption($this->lastname);
				} else {
					$doc->exportCaption($this->authid);
					$doc->exportCaption($this->txid);
					$doc->exportCaption($this->merchantid);
					$doc->exportCaption($this->profileid);
					$doc->exportCaption($this->status);
					$doc->exportCaption($this->authtime);
					$doc->exportCaption($this->expirationTimeInMinutes);
					$doc->exportCaption($this->expirationTime);
					$doc->exportCaption($this->_userid);
					$doc->exportCaption($this->usersnodeid);
					$doc->exportCaption($this->firstname);
					$doc->exportCaption($this->lastname);
				}
				$doc->endExportRow();
			}
		}

		// Move to first record
		$recCnt = $startRec - 1;
		if (!$recordset->EOF) {
			$recordset->moveFirst();
			if ($startRec > 1)
				$recordset->move($startRec - 1);
		}
		while (!$recordset->EOF && $recCnt < $stopRec) {
			$recCnt++;
			if ($recCnt >= $startRec) {
				$rowCnt = $recCnt - $startRec + 1;

				// Page break
				if ($this->ExportPageBreakCount > 0) {
					if ($rowCnt > 1 && ($rowCnt - 1) % $this->ExportPageBreakCount == 0)
						$doc->exportPageBreak();
				}
				$this->loadListRowValues($recordset);

				// Render row
				$this->RowType = ROWTYPE_VIEW; // Render view
				$this->resetAttributes();
				$this->renderListRow();
				if (!$doc->ExportCustom) {
					$doc->beginExportRow($rowCnt); // Allow CSS styles if enabled
					if ($exportPageType == "view") {
						$doc->exportField($this->authid);
						$doc->exportField($this->txid);
						$doc->exportField($this->merchantid);
						$doc->exportField($this->profileid);
						$doc->exportField($this->status);
						$doc->exportField($this->authtime);
						$doc->exportField($this->expirationTimeInMinutes);
						$doc->exportField($this->expirationTime);
						$doc->exportField($this->_userid);
						$doc->exportField($this->usersnodeid);
						$doc->exportField($this->firstname);
						$doc->exportField($this->lastname);
					} else {
						$doc->exportField($this->authid);
						$doc->exportField($this->txid);
						$doc->exportField($this->merchantid);
						$doc->exportField($this->profileid);
						$doc->exportField($this->status);
						$doc->exportField($this->authtime);
						$doc->exportField($this->expirationTimeInMinutes);
						$doc->exportField($this->expirationTime);
						$doc->exportField($this->_userid);
						$doc->exportField($this->usersnodeid);
						$doc->exportField($this->firstname);
						$doc->exportField($this->lastname);
					}
					$doc->endExportRow($rowCnt);
				}
			}

			// Call Row Export server event
			if ($doc->ExportCustom)
				$this->Row_Export($recordset->fields);
			$recordset->moveNext();
		}
		if (!$doc->ExportCustom) {
			$doc->exportTableFooter();
		}
	}

	// Get file data
	public function getFileData($fldparm, $key, $resize, $width = 0, $height = 0)
	{

		// No binary fields
		return FALSE;
	}

	// Write Audit Trail start/end for grid update
	public function writeAuditTrailDummy($typ)
	{
		$table = 'nodeauthpool';
		$usr = CurrentUserName();
		WriteAuditTrail("log", DbCurrentDateTime(), ScriptName(), $usr, $typ, $table, "", "", "", "");
	}

	// Write Audit Trail (add page)
	public function writeAuditTrailOnAdd(&$rs)
	{
		global $Language;
		if (!$this->AuditTrailOnAdd)
			return;
		$table = 'nodeauthpool';

		// Get key value
		$key = "";
		if ($key != "")
			$key .= Config("COMPOSITE_KEY_SEPARATOR");
		$key .= $rs['authid'];

		// Write Audit Trail
		$dt = DbCurrentDateTime();
		$id = ScriptName();
		$usr = CurrentUserName();
		foreach (array_keys($rs) as $fldname) {
			if (array_key_exists($fldname, $this->fields) && $this->fields[$fldname]->DataType != DATATYPE_BLOB) { // Ignore BLOB fields
				if ($this->fields[$fldname]->HtmlTag == "PASSWORD") {
					$newvalue = $Language->phrase("PasswordMask"); // Password Field
				} elseif ($this->fields[$fldname]->DataType == DATATYPE_MEMO) {
					if (Config("AUDIT_TRAIL_TO_DATABASE"))
						$newvalue = $rs[$fldname];
					else
						$newvalue = "[MEMO]"; // Memo Field
				} elseif ($this->fields[$fldname]->DataType == DATATYPE_XML) {
					$newvalue = "[XML]"; // XML Field
				} else {
					$newvalue = $rs[$fldname];
				}
				WriteAuditTrail("log", $dt, $id, $usr, "A", $table, $fldname, $key, "", $newvalue);
			}
		}
	}

	// Write Audit Trail (edit page)
	public function writeAuditTrailOnEdit(&$rsold, &$rsnew)
	{
		global $Language;
		if (!$this->AuditTrailOnEdit)
			return;
		$table = 'nodeauthpool';

		// Get key value
		$key = "";
		if ($key != "")
			$key .= Config("COMPOSITE_KEY_SEPARATOR");
		$key .= $rsold['authid'];

		// Write Audit Trail
		$dt = DbCurrentDateTime();
		$id = ScriptName();
		$usr = CurrentUserName();
		foreach (array_keys($rsnew) as $fldname) {
			if (array_key_exists($fldname, $this->fields) && array_key_exists($fldname, $rsold) && $this->fields[$fldname]->DataType != DATATYPE_BLOB) { // Ignore BLOB fields
				if ($this->fields[$fldname]->DataType == DATATYPE_DATE) { // DateTime field
					$modified = (FormatDateTime($rsold[$fldname], 0) != FormatDateTime($rsnew[$fldname], 0));
				} else {
					$modified = !CompareValue($rsold[$fldname], $rsnew[$fldname]);
				}
				if ($modified) {
					if ($this->fields[$fldname]->HtmlTag == "PASSWORD") { // Password Field
						$oldvalue = $Language->phrase("PasswordMask");
						$newvalue = $Language->phrase("PasswordMask");
					} elseif ($this->fields[$fldname]->DataType == DATATYPE_MEMO) { // Memo field
						if (Config("AUDIT_TRAIL_TO_DATABASE")) {
							$oldvalue = $rsold[$fldname];
							$newvalue = $rsnew[$fldname];
						} else {
							$oldvalue = "[MEMO]";
							$newvalue = "[MEMO]";
						}
					} elseif ($this->fields[$fldname]->DataType == DATATYPE_XML) { // XML field
						$oldvalue = "[XML]";
						$newvalue = "[XML]";
					} else {
						$oldvalue = $rsold[$fldname];
						$newvalue = $rsnew[$fldname];
					}
					WriteAuditTrail("log", $dt, $id, $usr, "U", $table, $fldname, $key, $oldvalue, $newvalue);
				}
			}
		}
	}

	// Write Audit Trail (delete page)
	public function writeAuditTrailOnDelete(&$rs)
	{
		global $Language;
		if (!$this->AuditTrailOnDelete)
			return;
		$table = 'nodeauthpool';

		// Get key value
		$key = "";
		if ($key != "")
			$key .= Config("COMPOSITE_KEY_SEPARATOR");
		$key .= $rs['authid'];

		// Write Audit Trail
		$dt = DbCurrentDateTime();
		$id = ScriptName();
		$curUser = CurrentUserName();
		foreach (array_keys($rs) as $fldname) {
			if (array_key_exists($fldname, $this->fields) && $this->fields[$fldname]->DataType != DATATYPE_BLOB) { // Ignore BLOB fields
				if ($this->fields[$fldname]->HtmlTag == "PASSWORD") {
					$oldvalue = $Language->phrase("PasswordMask"); // Password Field
				} elseif ($this->fields[$fldname]->DataType == DATATYPE_MEMO) {
					if (Config("AUDIT_TRAIL_TO_DATABASE"))
						$oldvalue = $rs[$fldname];
					else
						$oldvalue = "[MEMO]"; // Memo field
				} elseif ($this->fields[$fldname]->DataType == DATATYPE_XML) {
					$oldvalue = "[XML]"; // XML field
				} else {
					$oldvalue = $rs[$fldname];
				}
				WriteAuditTrail("log", $dt, $id, $curUser, "D", $table, $fldname, $key, $oldvalue, "");
			}
		}
	}

	// Table level events
	// Recordset Selecting event
	function Recordset_Selecting(&$filter) {

		// Enter your code here
	}

	// Recordset Selected event
	function Recordset_Selected(&$rs) {

		//echo "Recordset Selected";
	}

	// Recordset Search Validated event
	function Recordset_SearchValidated() {

		// Example:
		//$this->MyField1->AdvancedSearch->SearchValue = "your search criteria"; // Search value

	}

	// Recordset Searching event
	function Recordset_Searching(&$filter) {

		// Enter your code here
	}

	// Row_Selecting event
	function Row_Selecting(&$filter) {

		// Enter your code here
	}

	// Row Selected event
	function Row_Selected(&$rs) {

		//echo "Row Selected";
	}

	// Row Inserting event
	function Row_Inserting($rsold, &$rsnew) {

		// Enter your code here
		// To cancel, set return value to FALSE

		return TRUE;
	}

	// Row Inserted event
	function Row_Inserted($rsold, &$rsnew) {

		//echo "Row Inserted"
	}

	// Row Updating event
	function Row_Updating($rsold, &$rsnew) {

		// Enter your code here
		// To cancel, set return value to FALSE

		return TRUE;
	}

	// Row Updated event
	function Row_Updated($rsold, &$rsnew) {

		//echo "Row Updated";
	}

	// Row Update Conflict event
	function Row_UpdateConflict($rsold, &$rsnew) {

		// Enter your code here
		// To ignore conflict, set return value to FALSE

		return TRUE;
	}

	// Grid Inserting event
	function Grid_Inserting() {

		// Enter your code here
		// To reject grid insert, set return value to FALSE

		return TRUE;
	}

	// Grid Inserted event
	function Grid_Inserted($rsnew) {

		//echo "Grid Inserted";
	}

	// Grid Updating event
	function Grid_Updating($rsold) {

		// Enter your code here
		// To reject grid update, set return value to FALSE

		return TRUE;
	}

	// Grid Updated event
	function Grid_Updated($rsold, $rsnew) {

		//echo "Grid Updated";
	}

	// Row Deleting event
	function Row_Deleting(&$rs) {

		// Enter your code here
		// To cancel, set return value to False

		return TRUE;
	}

	// Row Deleted event
	function Row_Deleted(&$rs) {

		//echo "Row Deleted";
	}

	// Email Sending event
	function Email_Sending($email, &$args) {

		//var_dump($email); var_dump($args); exit();
		return TRUE;
	}

	// Lookup Selecting event
	function Lookup_Selecting($fld, &$filter) {

		//var_dump($fld->Name, $fld->Lookup, $filter); // Uncomment to view the filter
		// Enter your code here

	}

	// Row Rendering event
	function Row_Rendering() {

		// Enter your code here
	}

	// Row Rendered event
	function Row_Rendered() {

		// To view properties of field class, use:
		//var_dump($this-><FieldName>);

	}

	// User ID Filtering event
	function UserID_Filtering(&$filter) {

		// Enter your code here
	}
}
?>