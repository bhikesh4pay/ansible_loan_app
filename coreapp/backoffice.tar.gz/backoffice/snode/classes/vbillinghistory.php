<?php namespace PHPMaker2020\_4payadmin; ?>
<?php

/**
 * Table class for vbillinghistory
 */
class vbillinghistory extends DbTable
{
	protected $SqlFrom = "";
	protected $SqlSelect = "";
	protected $SqlSelectList = "";
	protected $SqlWhere = "";
	protected $SqlGroupBy = "";
	protected $SqlHaving = "";
	protected $SqlOrderBy = "";
	public $UseSessionForListSql = TRUE;

	// Column CSS classes
	public $LeftColumnClass = "col-sm-2 col-form-label ew-label";
	public $RightColumnClass = "col-sm-10";
	public $OffsetColumnClass = "col-sm-10 offset-sm-2";
	public $TableLeftColumnClass = "w-col-2";

	// Export
	public $ExportDoc;

	// Fields
	public $recid;
	public $brokeremail;
	public $brokerid;
	public $transdate;
	public $serviceid;
	public $billingservicename;
	public $customeracctno;
	public $refno;
	public $currcode;
	public $amount;
	public $balance;
	public $confcode;
	public $success;
	public $_userid;
	public $billerresponse;
	public $paymenttype;
	public $customername;
	public $parentuserid;
	public $businessname;
	public $businessphoneno;
	public $businessaddress1;
	public $businessaddress2;
	public $businesscity;
	public $businessstate;
	public $businesscountry;
	public $feeid;
	public $_tabletype;
	public $feemerchanttotal;
	public $feeconsumertotal;
	public $feesystemtotal;
	public $feeexternaltotal;
	public $feefranchiseetotal;
	public $feeresellertotal;
	public $officialdocnumber;
	public $branchname;
	public $clerkname;
	public $taxamount;
	public $totalamount;
	public $taxperc;
	public $department;
	public $billingresponse2;
	public $purchaseid;
	public $paymentid;
	public $transgroupid;
	public $otherdetails;

	// Constructor
	public function __construct()
	{
		global $Language, $CurrentLanguage;
		parent::__construct();

		// Language object
		if (!isset($Language))
			$Language = new Language();
		$this->TableVar = 'vbillinghistory';
		$this->TableName = 'vbillinghistory';
		$this->TableType = 'VIEW';

		// Update Table
		$this->UpdateTable = "`vbillinghistory`";
		$this->Dbid = 'DB';
		$this->ExportAll = TRUE;
		$this->ExportPageBreakCount = 0; // Page break per every n record (PDF only)
		$this->ExportPageOrientation = "portrait"; // Page orientation (PDF only)
		$this->ExportPageSize = "a4"; // Page size (PDF only)
		$this->ExportExcelPageOrientation = \PhpOffice\PhpSpreadsheet\Worksheet\PageSetup::ORIENTATION_DEFAULT; // Page orientation (PhpSpreadsheet only)
		$this->ExportExcelPageSize = \PhpOffice\PhpSpreadsheet\Worksheet\PageSetup::PAPERSIZE_A4; // Page size (PhpSpreadsheet only)
		$this->ExportWordPageOrientation = "portrait"; // Page orientation (PHPWord only)
		$this->ExportWordColumnWidth = NULL; // Cell width (PHPWord only)
		$this->DetailAdd = FALSE; // Allow detail add
		$this->DetailEdit = FALSE; // Allow detail edit
		$this->DetailView = FALSE; // Allow detail view
		$this->ShowMultipleDetails = FALSE; // Show multiple details
		$this->GridAddRowCount = 5;
		$this->AllowAddDeleteRow = TRUE; // Allow add/delete row
		$this->UserIDAllowSecurity = Config("DEFAULT_USER_ID_ALLOW_SECURITY"); // Default User ID allowed permissions
		$this->BasicSearch = new BasicSearch($this->TableVar);

		// recid
		$this->recid = new DbField('vbillinghistory', 'vbillinghistory', 'x_recid', 'recid', '`recid`', '`recid`', 3, 15, -1, FALSE, '`recid`', FALSE, FALSE, FALSE, 'FORMATTED TEXT', 'NO');
		$this->recid->IsAutoIncrement = TRUE; // Autoincrement field
		$this->recid->IsPrimaryKey = TRUE; // Primary key field
		$this->recid->Sortable = TRUE; // Allow sort
		$this->recid->DefaultErrorMessage = $Language->phrase("IncorrectInteger");
		$this->fields['recid'] = &$this->recid;

		// brokeremail
		$this->brokeremail = new DbField('vbillinghistory', 'vbillinghistory', 'x_brokeremail', 'brokeremail', '`brokeremail`', '`brokeremail`', 200, 100, -1, FALSE, '`brokeremail`', FALSE, FALSE, FALSE, 'FORMATTED TEXT', 'TEXT');
		$this->brokeremail->IsPrimaryKey = TRUE; // Primary key field
		$this->brokeremail->Nullable = FALSE; // NOT NULL field
		$this->brokeremail->Required = TRUE; // Required field
		$this->brokeremail->Sortable = TRUE; // Allow sort
		$this->brokeremail->Lookup = new Lookup('brokeremail', 'useremailaccount', FALSE, 'emailAccount', ["emailAccount","","",""], [], [], [], [], [], [], '', '');
		$this->fields['brokeremail'] = &$this->brokeremail;

		// brokerid
		$this->brokerid = new DbField('vbillinghistory', 'vbillinghistory', 'x_brokerid', 'brokerid', '`brokerid`', '`brokerid`', 3, 12, -1, FALSE, '`brokerid`', FALSE, FALSE, FALSE, 'FORMATTED TEXT', 'TEXT');
		$this->brokerid->Nullable = FALSE; // NOT NULL field
		$this->brokerid->Required = TRUE; // Required field
		$this->brokerid->Sortable = TRUE; // Allow sort
		$this->brokerid->DefaultErrorMessage = $Language->phrase("IncorrectInteger");
		$this->fields['brokerid'] = &$this->brokerid;

		// transdate
		$this->transdate = new DbField('vbillinghistory', 'vbillinghistory', 'x_transdate', 'transdate', '`transdate`', CastDateFieldForLike("`transdate`", 2, "DB"), 135, 19, 2, FALSE, '`transdate`', FALSE, FALSE, FALSE, 'FORMATTED TEXT', 'TEXT');
		$this->transdate->Sortable = TRUE; // Allow sort
		$this->transdate->DefaultErrorMessage = str_replace("%s", $GLOBALS["DATE_FORMAT"], $Language->phrase("IncorrectDate"));
		$this->fields['transdate'] = &$this->transdate;

		// serviceid
		$this->serviceid = new DbField('vbillinghistory', 'vbillinghistory', 'x_serviceid', 'serviceid', '`serviceid`', '`serviceid`', 3, 8, -1, FALSE, '`serviceid`', FALSE, FALSE, FALSE, 'FORMATTED TEXT', 'CHECKBOX');
		$this->serviceid->Nullable = FALSE; // NOT NULL field
		$this->serviceid->Required = TRUE; // Required field
		$this->serviceid->Sortable = TRUE; // Allow sort
		$this->serviceid->Lookup = new Lookup('serviceid', 'bilingservices', FALSE, 'serviceid', ["name","","",""], [], [], [], [], [], [], '', '');
		$this->serviceid->DefaultErrorMessage = $Language->phrase("IncorrectInteger");
		$this->fields['serviceid'] = &$this->serviceid;

		// billingservicename
		$this->billingservicename = new DbField('vbillinghistory', 'vbillinghistory', 'x_billingservicename', 'billingservicename', '`billingservicename`', '`billingservicename`', 200, 50, -1, FALSE, '`billingservicename`', FALSE, FALSE, FALSE, 'FORMATTED TEXT', 'TEXT');
		$this->billingservicename->Nullable = FALSE; // NOT NULL field
		$this->billingservicename->Required = TRUE; // Required field
		$this->billingservicename->Sortable = FALSE; // Allow sort
		$this->fields['billingservicename'] = &$this->billingservicename;

		// customeracctno
		$this->customeracctno = new DbField('vbillinghistory', 'vbillinghistory', 'x_customeracctno', 'customeracctno', '`customeracctno`', '`customeracctno`', 200, 60, -1, FALSE, '`customeracctno`', FALSE, FALSE, FALSE, 'FORMATTED TEXT', 'TEXT');
		$this->customeracctno->Nullable = FALSE; // NOT NULL field
		$this->customeracctno->Required = TRUE; // Required field
		$this->customeracctno->Sortable = TRUE; // Allow sort
		$this->fields['customeracctno'] = &$this->customeracctno;

		// refno
		$this->refno = new DbField('vbillinghistory', 'vbillinghistory', 'x_refno', 'refno', '`refno`', '`refno`', 200, 25, -1, FALSE, '`refno`', FALSE, FALSE, FALSE, 'FORMATTED TEXT', 'TEXT');
		$this->refno->Sortable = TRUE; // Allow sort
		$this->fields['refno'] = &$this->refno;

		// currcode
		$this->currcode = new DbField('vbillinghistory', 'vbillinghistory', 'x_currcode', 'currcode', '`currcode`', '`currcode`', 200, 3, -1, FALSE, '`currcode`', FALSE, FALSE, FALSE, 'FORMATTED TEXT', 'TEXT');
		$this->currcode->Nullable = FALSE; // NOT NULL field
		$this->currcode->Required = TRUE; // Required field
		$this->currcode->Sortable = TRUE; // Allow sort
		$this->fields['currcode'] = &$this->currcode;

		// amount
		$this->amount = new DbField('vbillinghistory', 'vbillinghistory', 'x_amount', 'amount', '`amount`', '`amount`', 131, 15, -1, FALSE, '`amount`', FALSE, FALSE, FALSE, 'FORMATTED TEXT', 'TEXT');
		$this->amount->Nullable = FALSE; // NOT NULL field
		$this->amount->Required = TRUE; // Required field
		$this->amount->Sortable = TRUE; // Allow sort
		$this->amount->DefaultErrorMessage = $Language->phrase("IncorrectFloat");
		$this->fields['amount'] = &$this->amount;

		// balance
		$this->balance = new DbField('vbillinghistory', 'vbillinghistory', 'x_balance', 'balance', '`balance`', '`balance`', 131, 15, -1, FALSE, '`balance`', FALSE, FALSE, FALSE, 'FORMATTED TEXT', 'TEXT');
		$this->balance->Nullable = FALSE; // NOT NULL field
		$this->balance->Required = TRUE; // Required field
		$this->balance->Sortable = TRUE; // Allow sort
		$this->balance->DefaultErrorMessage = $Language->phrase("IncorrectFloat");
		$this->fields['balance'] = &$this->balance;

		// confcode
		$this->confcode = new DbField('vbillinghistory', 'vbillinghistory', 'x_confcode', 'confcode', '`confcode`', '`confcode`', 200, 20, -1, FALSE, '`confcode`', FALSE, FALSE, FALSE, 'FORMATTED TEXT', 'TEXT');
		$this->confcode->Sortable = TRUE; // Allow sort
		$this->fields['confcode'] = &$this->confcode;

		// success
		$this->success = new DbField('vbillinghistory', 'vbillinghistory', 'x_success', 'success', '`success`', '`success`', 3, 1, -1, FALSE, '`success`', FALSE, FALSE, FALSE, 'FORMATTED TEXT', 'SELECT');
		$this->success->Nullable = FALSE; // NOT NULL field
		$this->success->Sortable = TRUE; // Allow sort
		$this->success->UsePleaseSelect = TRUE; // Use PleaseSelect by default
		$this->success->PleaseSelectText = $Language->phrase("PleaseSelect"); // "PleaseSelect" text
		$this->success->Lookup = new Lookup('success', 'vdualstatus', FALSE, 'statusID', ["label","","",""], [], [], [], [], [], [], '', '');
		$this->success->OptionCount = 3;
		$this->success->DefaultErrorMessage = $Language->phrase("IncorrectInteger");
		$this->fields['success'] = &$this->success;

		// userid
		$this->_userid = new DbField('vbillinghistory', 'vbillinghistory', 'x__userid', 'userid', '`userid`', '`userid`', 3, 12, -1, FALSE, '`userid`', FALSE, FALSE, FALSE, 'FORMATTED TEXT', 'TEXT');
		$this->_userid->Nullable = FALSE; // NOT NULL field
		$this->_userid->Sortable = TRUE; // Allow sort
		$this->_userid->DefaultErrorMessage = $Language->phrase("IncorrectInteger");
		$this->fields['userid'] = &$this->_userid;

		// billerresponse
		$this->billerresponse = new DbField('vbillinghistory', 'vbillinghistory', 'x_billerresponse', 'billerresponse', '`billerresponse`', '`billerresponse`', 201, -1, -1, FALSE, '`billerresponse`', FALSE, FALSE, FALSE, 'FORMATTED TEXT', 'TEXTAREA');
		$this->billerresponse->Sortable = TRUE; // Allow sort
		$this->fields['billerresponse'] = &$this->billerresponse;

		// paymenttype
		$this->paymenttype = new DbField('vbillinghistory', 'vbillinghistory', 'x_paymenttype', 'paymenttype', '`paymenttype`', '`paymenttype`', 3, 1, -1, FALSE, '`paymenttype`', FALSE, FALSE, FALSE, 'FORMATTED TEXT', 'SELECT');
		$this->paymenttype->Nullable = FALSE; // NOT NULL field
		$this->paymenttype->Sortable = TRUE; // Allow sort
		$this->paymenttype->UsePleaseSelect = TRUE; // Use PleaseSelect by default
		$this->paymenttype->PleaseSelectText = $Language->phrase("PleaseSelect"); // "PleaseSelect" text
		$this->paymenttype->Lookup = new Lookup('paymenttype', 'vbillinghistory', FALSE, '', ["","","",""], [], [], [], [], [], [], '', '');
		$this->paymenttype->OptionCount = 5;
		$this->paymenttype->DefaultErrorMessage = $Language->phrase("IncorrectInteger");
		$this->fields['paymenttype'] = &$this->paymenttype;

		// customername
		$this->customername = new DbField('vbillinghistory', 'vbillinghistory', 'x_customername', 'customername', '`customername`', '`customername`', 200, 60, -1, FALSE, '`customername`', FALSE, FALSE, FALSE, 'FORMATTED TEXT', 'TEXT');
		$this->customername->Sortable = TRUE; // Allow sort
		$this->fields['customername'] = &$this->customername;

		// parentuserid
		$this->parentuserid = new DbField('vbillinghistory', 'vbillinghistory', 'x_parentuserid', 'parentuserid', '`parentuserid`', '`parentuserid`', 3, 15, -1, FALSE, '`parentuserid`', FALSE, FALSE, FALSE, 'FORMATTED TEXT', 'TEXT');
		$this->parentuserid->Nullable = FALSE; // NOT NULL field
		$this->parentuserid->Sortable = TRUE; // Allow sort
		$this->parentuserid->DefaultErrorMessage = $Language->phrase("IncorrectInteger");
		$this->fields['parentuserid'] = &$this->parentuserid;

		// businessname
		$this->businessname = new DbField('vbillinghistory', 'vbillinghistory', 'x_businessname', 'businessname', '`businessname`', '`businessname`', 200, 60, -1, FALSE, '`businessname`', FALSE, FALSE, FALSE, 'FORMATTED TEXT', 'TEXT');
		$this->businessname->Nullable = FALSE; // NOT NULL field
		$this->businessname->Required = TRUE; // Required field
		$this->businessname->Sortable = TRUE; // Allow sort
		$this->fields['businessname'] = &$this->businessname;

		// businessphoneno
		$this->businessphoneno = new DbField('vbillinghistory', 'vbillinghistory', 'x_businessphoneno', 'businessphoneno', '`businessphoneno`', '`businessphoneno`', 200, 15, -1, FALSE, '`businessphoneno`', FALSE, FALSE, FALSE, 'FORMATTED TEXT', 'TEXT');
		$this->businessphoneno->Sortable = TRUE; // Allow sort
		$this->fields['businessphoneno'] = &$this->businessphoneno;

		// businessaddress1
		$this->businessaddress1 = new DbField('vbillinghistory', 'vbillinghistory', 'x_businessaddress1', 'businessaddress1', '`businessaddress1`', '`businessaddress1`', 200, 60, -1, FALSE, '`businessaddress1`', FALSE, FALSE, FALSE, 'FORMATTED TEXT', 'TEXT');
		$this->businessaddress1->Sortable = TRUE; // Allow sort
		$this->fields['businessaddress1'] = &$this->businessaddress1;

		// businessaddress2
		$this->businessaddress2 = new DbField('vbillinghistory', 'vbillinghistory', 'x_businessaddress2', 'businessaddress2', '`businessaddress2`', '`businessaddress2`', 200, 60, -1, FALSE, '`businessaddress2`', FALSE, FALSE, FALSE, 'FORMATTED TEXT', 'TEXT');
		$this->businessaddress2->Sortable = TRUE; // Allow sort
		$this->fields['businessaddress2'] = &$this->businessaddress2;

		// businesscity
		$this->businesscity = new DbField('vbillinghistory', 'vbillinghistory', 'x_businesscity', 'businesscity', '`businesscity`', '`businesscity`', 200, 60, -1, FALSE, '`businesscity`', FALSE, FALSE, FALSE, 'FORMATTED TEXT', 'TEXT');
		$this->businesscity->Sortable = TRUE; // Allow sort
		$this->fields['businesscity'] = &$this->businesscity;

		// businessstate
		$this->businessstate = new DbField('vbillinghistory', 'vbillinghistory', 'x_businessstate', 'businessstate', '`businessstate`', '`businessstate`', 200, 3, -1, FALSE, '`businessstate`', FALSE, FALSE, FALSE, 'FORMATTED TEXT', 'TEXT');
		$this->businessstate->Sortable = TRUE; // Allow sort
		$this->fields['businessstate'] = &$this->businessstate;

		// businesscountry
		$this->businesscountry = new DbField('vbillinghistory', 'vbillinghistory', 'x_businesscountry', 'businesscountry', '`businesscountry`', '`businesscountry`', 200, 3, -1, FALSE, '`businesscountry`', FALSE, FALSE, FALSE, 'FORMATTED TEXT', 'TEXT');
		$this->businesscountry->Sortable = TRUE; // Allow sort
		$this->fields['businesscountry'] = &$this->businesscountry;

		// feeid
		$this->feeid = new DbField('vbillinghistory', 'vbillinghistory', 'x_feeid', 'feeid', '`feeid`', '`feeid`', 3, 10, -1, FALSE, '`feeid`', FALSE, FALSE, FALSE, 'FORMATTED TEXT', 'TEXT');
		$this->feeid->Nullable = FALSE; // NOT NULL field
		$this->feeid->Sortable = TRUE; // Allow sort
		$this->feeid->DefaultErrorMessage = $Language->phrase("IncorrectInteger");
		$this->fields['feeid'] = &$this->feeid;

		// tabletype
		$this->_tabletype = new DbField('vbillinghistory', 'vbillinghistory', 'x__tabletype', 'tabletype', '`tabletype`', '`tabletype`', 3, 1, -1, FALSE, '`tabletype`', FALSE, FALSE, FALSE, 'FORMATTED TEXT', 'TEXT');
		$this->_tabletype->Nullable = FALSE; // NOT NULL field
		$this->_tabletype->Sortable = TRUE; // Allow sort
		$this->_tabletype->DefaultErrorMessage = $Language->phrase("IncorrectInteger");
		$this->fields['tabletype'] = &$this->_tabletype;

		// feemerchanttotal
		$this->feemerchanttotal = new DbField('vbillinghistory', 'vbillinghistory', 'x_feemerchanttotal', 'feemerchanttotal', '`feemerchanttotal`', '`feemerchanttotal`', 131, 10, -1, FALSE, '`feemerchanttotal`', FALSE, FALSE, FALSE, 'FORMATTED TEXT', 'TEXT');
		$this->feemerchanttotal->Nullable = FALSE; // NOT NULL field
		$this->feemerchanttotal->Sortable = TRUE; // Allow sort
		$this->feemerchanttotal->DefaultErrorMessage = $Language->phrase("IncorrectFloat");
		$this->fields['feemerchanttotal'] = &$this->feemerchanttotal;

		// feeconsumertotal
		$this->feeconsumertotal = new DbField('vbillinghistory', 'vbillinghistory', 'x_feeconsumertotal', 'feeconsumertotal', '`feeconsumertotal`', '`feeconsumertotal`', 131, 10, -1, FALSE, '`feeconsumertotal`', FALSE, FALSE, FALSE, 'FORMATTED TEXT', 'TEXT');
		$this->feeconsumertotal->Nullable = FALSE; // NOT NULL field
		$this->feeconsumertotal->Sortable = TRUE; // Allow sort
		$this->feeconsumertotal->DefaultErrorMessage = $Language->phrase("IncorrectFloat");
		$this->fields['feeconsumertotal'] = &$this->feeconsumertotal;

		// feesystemtotal
		$this->feesystemtotal = new DbField('vbillinghistory', 'vbillinghistory', 'x_feesystemtotal', 'feesystemtotal', '`feesystemtotal`', '`feesystemtotal`', 131, 10, -1, FALSE, '`feesystemtotal`', FALSE, FALSE, FALSE, 'FORMATTED TEXT', 'TEXT');
		$this->feesystemtotal->Nullable = FALSE; // NOT NULL field
		$this->feesystemtotal->Sortable = TRUE; // Allow sort
		$this->feesystemtotal->DefaultErrorMessage = $Language->phrase("IncorrectFloat");
		$this->fields['feesystemtotal'] = &$this->feesystemtotal;

		// feeexternaltotal
		$this->feeexternaltotal = new DbField('vbillinghistory', 'vbillinghistory', 'x_feeexternaltotal', 'feeexternaltotal', '`feeexternaltotal`', '`feeexternaltotal`', 131, 10, -1, FALSE, '`feeexternaltotal`', FALSE, FALSE, FALSE, 'FORMATTED TEXT', 'TEXT');
		$this->feeexternaltotal->Nullable = FALSE; // NOT NULL field
		$this->feeexternaltotal->Sortable = TRUE; // Allow sort
		$this->feeexternaltotal->DefaultErrorMessage = $Language->phrase("IncorrectFloat");
		$this->fields['feeexternaltotal'] = &$this->feeexternaltotal;

		// feefranchiseetotal
		$this->feefranchiseetotal = new DbField('vbillinghistory', 'vbillinghistory', 'x_feefranchiseetotal', 'feefranchiseetotal', '`feefranchiseetotal`', '`feefranchiseetotal`', 131, 10, -1, FALSE, '`feefranchiseetotal`', FALSE, FALSE, FALSE, 'FORMATTED TEXT', 'TEXT');
		$this->feefranchiseetotal->Nullable = FALSE; // NOT NULL field
		$this->feefranchiseetotal->Sortable = TRUE; // Allow sort
		$this->feefranchiseetotal->DefaultErrorMessage = $Language->phrase("IncorrectFloat");
		$this->fields['feefranchiseetotal'] = &$this->feefranchiseetotal;

		// feeresellertotal
		$this->feeresellertotal = new DbField('vbillinghistory', 'vbillinghistory', 'x_feeresellertotal', 'feeresellertotal', '`feeresellertotal`', '`feeresellertotal`', 131, 10, -1, FALSE, '`feeresellertotal`', FALSE, FALSE, FALSE, 'FORMATTED TEXT', 'TEXT');
		$this->feeresellertotal->Nullable = FALSE; // NOT NULL field
		$this->feeresellertotal->Sortable = TRUE; // Allow sort
		$this->feeresellertotal->DefaultErrorMessage = $Language->phrase("IncorrectFloat");
		$this->fields['feeresellertotal'] = &$this->feeresellertotal;

		// officialdocnumber
		$this->officialdocnumber = new DbField('vbillinghistory', 'vbillinghistory', 'x_officialdocnumber', 'officialdocnumber', '`officialdocnumber`', '`officialdocnumber`', 200, 20, -1, FALSE, '`officialdocnumber`', FALSE, FALSE, FALSE, 'FORMATTED TEXT', 'TEXT');
		$this->officialdocnumber->Sortable = TRUE; // Allow sort
		$this->fields['officialdocnumber'] = &$this->officialdocnumber;

		// branchname
		$this->branchname = new DbField('vbillinghistory', 'vbillinghistory', 'x_branchname', 'branchname', '`branchname`', '`branchname`', 200, 50, -1, FALSE, '`branchname`', FALSE, FALSE, FALSE, 'FORMATTED TEXT', 'TEXT');
		$this->branchname->Sortable = TRUE; // Allow sort
		$this->fields['branchname'] = &$this->branchname;

		// clerkname
		$this->clerkname = new DbField('vbillinghistory', 'vbillinghistory', 'x_clerkname', 'clerkname', '`clerkname`', '`clerkname`', 200, 50, -1, FALSE, '`clerkname`', FALSE, FALSE, FALSE, 'FORMATTED TEXT', 'TEXT');
		$this->clerkname->Sortable = TRUE; // Allow sort
		$this->fields['clerkname'] = &$this->clerkname;

		// taxamount
		$this->taxamount = new DbField('vbillinghistory', 'vbillinghistory', 'x_taxamount', 'taxamount', '`taxamount`', '`taxamount`', 131, 10, -1, FALSE, '`taxamount`', FALSE, FALSE, FALSE, 'FORMATTED TEXT', 'TEXT');
		$this->taxamount->Sortable = TRUE; // Allow sort
		$this->taxamount->DefaultErrorMessage = $Language->phrase("IncorrectFloat");
		$this->fields['taxamount'] = &$this->taxamount;

		// totalamount
		$this->totalamount = new DbField('vbillinghistory', 'vbillinghistory', 'x_totalamount', 'totalamount', '`totalamount`', '`totalamount`', 131, 10, -1, FALSE, '`totalamount`', FALSE, FALSE, FALSE, 'FORMATTED TEXT', 'TEXT');
		$this->totalamount->Sortable = TRUE; // Allow sort
		$this->totalamount->DefaultErrorMessage = $Language->phrase("IncorrectFloat");
		$this->fields['totalamount'] = &$this->totalamount;

		// taxperc
		$this->taxperc = new DbField('vbillinghistory', 'vbillinghistory', 'x_taxperc', 'taxperc', '`taxperc`', '`taxperc`', 131, 4, -1, FALSE, '`taxperc`', FALSE, FALSE, FALSE, 'FORMATTED TEXT', 'TEXT');
		$this->taxperc->Sortable = TRUE; // Allow sort
		$this->taxperc->DefaultErrorMessage = $Language->phrase("IncorrectFloat");
		$this->fields['taxperc'] = &$this->taxperc;

		// department
		$this->department = new DbField('vbillinghistory', 'vbillinghistory', 'x_department', 'department', '`department`', '`department`', 200, 50, -1, FALSE, '`department`', FALSE, FALSE, FALSE, 'FORMATTED TEXT', 'SELECT');
		$this->department->Sortable = TRUE; // Allow sort
		$this->department->UsePleaseSelect = TRUE; // Use PleaseSelect by default
		$this->department->PleaseSelectText = $Language->phrase("PleaseSelect"); // "PleaseSelect" text
		$this->department->Lookup = new Lookup('department', 'domainattributes', FALSE, 'domainatt', ["attname","","",""], [], [], [], [], [], [], '', '');
		$this->fields['department'] = &$this->department;

		// billingresponse2
		$this->billingresponse2 = new DbField('vbillinghistory', 'vbillinghistory', 'x_billingresponse2', 'billingresponse2', '`billingresponse2`', '`billingresponse2`', 201, -1, -1, FALSE, '`billingresponse2`', FALSE, FALSE, FALSE, 'FORMATTED TEXT', 'TEXTAREA');
		$this->billingresponse2->Sortable = TRUE; // Allow sort
		$this->fields['billingresponse2'] = &$this->billingresponse2;

		// purchaseid
		$this->purchaseid = new DbField('vbillinghistory', 'vbillinghistory', 'x_purchaseid', 'purchaseid', '`purchaseid`', '`purchaseid`', 20, 12, -1, FALSE, '`purchaseid`', FALSE, FALSE, FALSE, 'FORMATTED TEXT', 'TEXT');
		$this->purchaseid->IsForeignKey = TRUE; // Foreign key field
		$this->purchaseid->Nullable = FALSE; // NOT NULL field
		$this->purchaseid->Sortable = TRUE; // Allow sort
		$this->purchaseid->DefaultErrorMessage = $Language->phrase("IncorrectInteger");
		$this->fields['purchaseid'] = &$this->purchaseid;

		// paymentid
		$this->paymentid = new DbField('vbillinghistory', 'vbillinghistory', 'x_paymentid', 'paymentid', '`paymentid`', '`paymentid`', 20, 12, -1, FALSE, '`paymentid`', FALSE, FALSE, FALSE, 'FORMATTED TEXT', 'TEXT');
		$this->paymentid->Nullable = FALSE; // NOT NULL field
		$this->paymentid->Required = TRUE; // Required field
		$this->paymentid->Sortable = TRUE; // Allow sort
		$this->paymentid->DefaultErrorMessage = $Language->phrase("IncorrectInteger");
		$this->fields['paymentid'] = &$this->paymentid;

		// transgroupid
		$this->transgroupid = new DbField('vbillinghistory', 'vbillinghistory', 'x_transgroupid', 'transgroupid', '`transgroupid`', '`transgroupid`', 20, 12, -1, FALSE, '`transgroupid`', FALSE, FALSE, FALSE, 'FORMATTED TEXT', 'TEXT');
		$this->transgroupid->Sortable = TRUE; // Allow sort
		$this->transgroupid->DefaultErrorMessage = $Language->phrase("IncorrectInteger");
		$this->fields['transgroupid'] = &$this->transgroupid;

		// otherdetails
		$this->otherdetails = new DbField('vbillinghistory', 'vbillinghistory', 'x_otherdetails', 'otherdetails', '`otherdetails`', '`otherdetails`', 201, 350, -1, FALSE, '`otherdetails`', FALSE, FALSE, FALSE, 'FORMATTED TEXT', 'TEXTAREA');
		$this->otherdetails->Sortable = TRUE; // Allow sort
		$this->fields['otherdetails'] = &$this->otherdetails;
	}

	// Field Visibility
	public function getFieldVisibility($fldParm)
	{
		global $Security;
		return $this->$fldParm->Visible; // Returns original value
	}

	// Set left column class (must be predefined col-*-* classes of Bootstrap grid system)
	function setLeftColumnClass($class)
	{
		if (preg_match('/^col\-(\w+)\-(\d+)$/', $class, $match)) {
			$this->LeftColumnClass = $class . " col-form-label ew-label";
			$this->RightColumnClass = "col-" . $match[1] . "-" . strval(12 - (int)$match[2]);
			$this->OffsetColumnClass = $this->RightColumnClass . " " . str_replace("col-", "offset-", $class);
			$this->TableLeftColumnClass = preg_replace('/^col-\w+-(\d+)$/', "w-col-$1", $class); // Change to w-col-*
		}
	}

	// Single column sort
	public function updateSort(&$fld)
	{
		if ($this->CurrentOrder == $fld->Name) {
			$sortField = $fld->Expression;
			$lastSort = $fld->getSort();
			if ($this->CurrentOrderType == "ASC" || $this->CurrentOrderType == "DESC") {
				$thisSort = $this->CurrentOrderType;
			} else {
				$thisSort = ($lastSort == "ASC") ? "DESC" : "ASC";
			}
			$fld->setSort($thisSort);
			$this->setSessionOrderBy($sortField . " " . $thisSort); // Save to Session
		} else {
			$fld->setSort("");
		}
	}

	// Current master table name
	public function getCurrentMasterTable()
	{
		return @$_SESSION[PROJECT_NAME . "_" . $this->TableVar . "_" . Config("TABLE_MASTER_TABLE")];
	}
	public function setCurrentMasterTable($v)
	{
		$_SESSION[PROJECT_NAME . "_" . $this->TableVar . "_" . Config("TABLE_MASTER_TABLE")] = $v;
	}

	// Session master WHERE clause
	public function getMasterFilter()
	{

		// Master filter
		$masterFilter = "";
		if ($this->getCurrentMasterTable() == "userpurchasereturn") {
			if ($this->purchaseid->getSessionValue() != "")
				$masterFilter .= "`purchaseid`=" . QuotedValue($this->purchaseid->getSessionValue(), DATATYPE_NUMBER, "DB");
			else
				return "";
		}
		if ($this->getCurrentMasterTable() == "userpurchase") {
			if ($this->purchaseid->getSessionValue() != "")
				$masterFilter .= "`purchaseid`=" . QuotedValue($this->purchaseid->getSessionValue(), DATATYPE_NUMBER, "DB");
			else
				return "";
		}
		return $masterFilter;
	}

	// Session detail WHERE clause
	public function getDetailFilter()
	{

		// Detail filter
		$detailFilter = "";
		if ($this->getCurrentMasterTable() == "userpurchasereturn") {
			if ($this->purchaseid->getSessionValue() != "")
				$detailFilter .= "`purchaseid`=" . QuotedValue($this->purchaseid->getSessionValue(), DATATYPE_NUMBER, "DB");
			else
				return "";
		}
		if ($this->getCurrentMasterTable() == "userpurchase") {
			if ($this->purchaseid->getSessionValue() != "")
				$detailFilter .= "`purchaseid`=" . QuotedValue($this->purchaseid->getSessionValue(), DATATYPE_NUMBER, "DB");
			else
				return "";
		}
		return $detailFilter;
	}

	// Master filter
	public function sqlMasterFilter_userpurchasereturn()
	{
		return "`purchaseid`=@purchaseid@";
	}

	// Detail filter
	public function sqlDetailFilter_userpurchasereturn()
	{
		return "`purchaseid`=@purchaseid@";
	}

	// Master filter
	public function sqlMasterFilter_userpurchase()
	{
		return "`purchaseid`=@purchaseid@";
	}

	// Detail filter
	public function sqlDetailFilter_userpurchase()
	{
		return "`purchaseid`=@purchaseid@";
	}

	// Table level SQL
	public function getSqlFrom() // From
	{
		return ($this->SqlFrom != "") ? $this->SqlFrom : "`vbillinghistory`";
	}
	public function sqlFrom() // For backward compatibility
	{
		return $this->getSqlFrom();
	}
	public function setSqlFrom($v)
	{
		$this->SqlFrom = $v;
	}
	public function getSqlSelect() // Select
	{
		return ($this->SqlSelect != "") ? $this->SqlSelect : "SELECT * FROM " . $this->getSqlFrom();
	}
	public function sqlSelect() // For backward compatibility
	{
		return $this->getSqlSelect();
	}
	public function setSqlSelect($v)
	{
		$this->SqlSelect = $v;
	}
	public function getSqlWhere() // Where
	{
		$where = ($this->SqlWhere != "") ? $this->SqlWhere : "";
		$this->TableFilter = "";
		AddFilter($where, $this->TableFilter);
		return $where;
	}
	public function sqlWhere() // For backward compatibility
	{
		return $this->getSqlWhere();
	}
	public function setSqlWhere($v)
	{
		$this->SqlWhere = $v;
	}
	public function getSqlGroupBy() // Group By
	{
		return ($this->SqlGroupBy != "") ? $this->SqlGroupBy : "";
	}
	public function sqlGroupBy() // For backward compatibility
	{
		return $this->getSqlGroupBy();
	}
	public function setSqlGroupBy($v)
	{
		$this->SqlGroupBy = $v;
	}
	public function getSqlHaving() // Having
	{
		return ($this->SqlHaving != "") ? $this->SqlHaving : "";
	}
	public function sqlHaving() // For backward compatibility
	{
		return $this->getSqlHaving();
	}
	public function setSqlHaving($v)
	{
		$this->SqlHaving = $v;
	}
	public function getSqlOrderBy() // Order By
	{
		return ($this->SqlOrderBy != "") ? $this->SqlOrderBy : "";
	}
	public function sqlOrderBy() // For backward compatibility
	{
		return $this->getSqlOrderBy();
	}
	public function setSqlOrderBy($v)
	{
		$this->SqlOrderBy = $v;
	}

	// Apply User ID filters
	public function applyUserIDFilters($filter, $id = "")
	{
		return $filter;
	}

	// Check if User ID security allows view all
	public function userIDAllow($id = "")
	{
		$allow = $this->UserIDAllowSecurity;
		switch ($id) {
			case "add":
			case "copy":
			case "gridadd":
			case "register":
			case "addopt":
				return (($allow & 1) == 1);
			case "edit":
			case "gridedit":
			case "update":
			case "changepwd":
			case "forgotpwd":
				return (($allow & 4) == 4);
			case "delete":
				return (($allow & 2) == 2);
			case "view":
				return (($allow & 32) == 32);
			case "search":
				return (($allow & 64) == 64);
			case "lookup":
				return (($allow & 256) == 256);
			default:
				return (($allow & 8) == 8);
		}
	}

	// Get recordset
	public function getRecordset($sql, $rowcnt = -1, $offset = -1)
	{
		$conn = $this->getConnection();
		$conn->raiseErrorFn = Config("ERROR_FUNC");
		$rs = $conn->selectLimit($sql, $rowcnt, $offset);
		$conn->raiseErrorFn = "";
		return $rs;
	}

	// Get record count
	public function getRecordCount($sql, $c = NULL)
	{
		$cnt = -1;
		$rs = NULL;
		$sql = preg_replace('/\/\*BeginOrderBy\*\/[\s\S]+\/\*EndOrderBy\*\//', "", $sql); // Remove ORDER BY clause (MSSQL)
		$pattern = '/^SELECT\s([\s\S]+)\sFROM\s/i';

		// Skip Custom View / SubQuery / SELECT DISTINCT / ORDER BY
		if (($this->TableType == 'TABLE' || $this->TableType == 'VIEW' || $this->TableType == 'LINKTABLE') &&
			preg_match($pattern, $sql) && !preg_match('/\(\s*(SELECT[^)]+)\)/i', $sql) &&
			!preg_match('/^\s*select\s+distinct\s+/i', $sql) && !preg_match('/\s+order\s+by\s+/i', $sql)) {
			$sqlwrk = "SELECT COUNT(*) FROM " . preg_replace($pattern, "", $sql);
		} else {
			$sqlwrk = "SELECT COUNT(*) FROM (" . $sql . ") COUNT_TABLE";
		}
		$conn = $c ?: $this->getConnection();
		if ($rs = $conn->execute($sqlwrk)) {
			if (!$rs->EOF && $rs->FieldCount() > 0) {
				$cnt = $rs->fields[0];
				$rs->close();
			}
			return (int)$cnt;
		}

		// Unable to get count, get record count directly
		if ($rs = $conn->execute($sql)) {
			$cnt = $rs->RecordCount();
			$rs->close();
			return (int)$cnt;
		}
		return $cnt;
	}

	// Get SQL
	public function getSql($where, $orderBy = "")
	{
		return BuildSelectSql($this->getSqlSelect(), $this->getSqlWhere(),
			$this->getSqlGroupBy(), $this->getSqlHaving(), $this->getSqlOrderBy(),
			$where, $orderBy);
	}

	// Table SQL
	public function getCurrentSql()
	{
		$filter = $this->CurrentFilter;
		$filter = $this->applyUserIDFilters($filter);
		$sort = $this->getSessionOrderBy();
		return $this->getSql($filter, $sort);
	}

	// Table SQL with List page filter
	public function getListSql()
	{
		$filter = $this->UseSessionForListSql ? $this->getSessionWhere() : "";
		AddFilter($filter, $this->CurrentFilter);
		$filter = $this->applyUserIDFilters($filter);
		$this->Recordset_Selecting($filter);
		$select = $this->getSqlSelect();
		$sort = $this->UseSessionForListSql ? $this->getSessionOrderBy() : "";
		return BuildSelectSql($select, $this->getSqlWhere(), $this->getSqlGroupBy(),
			$this->getSqlHaving(), $this->getSqlOrderBy(), $filter, $sort);
	}

	// Get ORDER BY clause
	public function getOrderBy()
	{
		$sort = $this->getSessionOrderBy();
		return BuildSelectSql("", "", "", "", $this->getSqlOrderBy(), "", $sort);
	}

	// Get record count based on filter (for detail record count in master table pages)
	public function loadRecordCount($filter)
	{
		$origFilter = $this->CurrentFilter;
		$this->CurrentFilter = $filter;
		$this->Recordset_Selecting($this->CurrentFilter);
		$select = $this->TableType == 'CUSTOMVIEW' ? $this->getSqlSelect() : "SELECT * FROM " . $this->getSqlFrom();
		$groupBy = $this->TableType == 'CUSTOMVIEW' ? $this->getSqlGroupBy() : "";
		$having = $this->TableType == 'CUSTOMVIEW' ? $this->getSqlHaving() : "";
		$sql = BuildSelectSql($select, $this->getSqlWhere(), $groupBy, $having, "", $this->CurrentFilter, "");
		$cnt = $this->getRecordCount($sql);
		$this->CurrentFilter = $origFilter;
		return $cnt;
	}

	// Get record count (for current List page)
	public function listRecordCount()
	{
		$filter = $this->getSessionWhere();
		AddFilter($filter, $this->CurrentFilter);
		$filter = $this->applyUserIDFilters($filter);
		$this->Recordset_Selecting($filter);
		$select = $this->TableType == 'CUSTOMVIEW' ? $this->getSqlSelect() : "SELECT * FROM " . $this->getSqlFrom();
		$groupBy = $this->TableType == 'CUSTOMVIEW' ? $this->getSqlGroupBy() : "";
		$having = $this->TableType == 'CUSTOMVIEW' ? $this->getSqlHaving() : "";
		$sql = BuildSelectSql($select, $this->getSqlWhere(), $groupBy, $having, "", $filter, "");
		$cnt = $this->getRecordCount($sql);
		return $cnt;
	}

	// INSERT statement
	protected function insertSql(&$rs)
	{
		$names = "";
		$values = "";
		foreach ($rs as $name => $value) {
			if (!isset($this->fields[$name]) || $this->fields[$name]->IsCustom)
				continue;
			$names .= $this->fields[$name]->Expression . ",";
			$values .= QuotedValue($value, $this->fields[$name]->DataType, $this->Dbid) . ",";
		}
		$names = preg_replace('/,+$/', "", $names);
		$values = preg_replace('/,+$/', "", $values);
		return "INSERT INTO " . $this->UpdateTable . " (" . $names . ") VALUES (" . $values . ")";
	}

	// Insert
	public function insert(&$rs)
	{
		$conn = $this->getConnection();
		$success = $conn->execute($this->insertSql($rs));
		if ($success) {

			// Get insert id if necessary
			$this->recid->setDbValue($conn->insert_ID());
			$rs['recid'] = $this->recid->DbValue;
		}
		return $success;
	}

	// UPDATE statement
	protected function updateSql(&$rs, $where = "", $curfilter = TRUE)
	{
		$sql = "UPDATE " . $this->UpdateTable . " SET ";
		foreach ($rs as $name => $value) {
			if (!isset($this->fields[$name]) || $this->fields[$name]->IsCustom || $this->fields[$name]->IsAutoIncrement)
				continue;
			$sql .= $this->fields[$name]->Expression . "=";
			$sql .= QuotedValue($value, $this->fields[$name]->DataType, $this->Dbid) . ",";
		}
		$sql = preg_replace('/,+$/', "", $sql);
		$filter = ($curfilter) ? $this->CurrentFilter : "";
		if (is_array($where))
			$where = $this->arrayToFilter($where);
		AddFilter($filter, $where);
		if ($filter != "")
			$sql .= " WHERE " . $filter;
		return $sql;
	}

	// Update
	public function update(&$rs, $where = "", $rsold = NULL, $curfilter = TRUE)
	{
		$conn = $this->getConnection();
		$success = $conn->execute($this->updateSql($rs, $where, $curfilter));
		return $success;
	}

	// DELETE statement
	protected function deleteSql(&$rs, $where = "", $curfilter = TRUE)
	{
		$sql = "DELETE FROM " . $this->UpdateTable . " WHERE ";
		if (is_array($where))
			$where = $this->arrayToFilter($where);
		if ($rs) {
			if (array_key_exists('recid', $rs))
				AddFilter($where, QuotedName('recid', $this->Dbid) . '=' . QuotedValue($rs['recid'], $this->recid->DataType, $this->Dbid));
			if (array_key_exists('brokeremail', $rs))
				AddFilter($where, QuotedName('brokeremail', $this->Dbid) . '=' . QuotedValue($rs['brokeremail'], $this->brokeremail->DataType, $this->Dbid));
		}
		$filter = ($curfilter) ? $this->CurrentFilter : "";
		AddFilter($filter, $where);
		if ($filter != "")
			$sql .= $filter;
		else
			$sql .= "0=1"; // Avoid delete
		return $sql;
	}

	// Delete
	public function delete(&$rs, $where = "", $curfilter = FALSE)
	{
		$success = TRUE;
		$conn = $this->getConnection();
		if ($success)
			$success = $conn->execute($this->deleteSql($rs, $where, $curfilter));
		return $success;
	}

	// Load DbValue from recordset or array
	protected function loadDbValues(&$rs)
	{
		if (!$rs || !is_array($rs) && $rs->EOF)
			return;
		$row = is_array($rs) ? $rs : $rs->fields;
		$this->recid->DbValue = $row['recid'];
		$this->brokeremail->DbValue = $row['brokeremail'];
		$this->brokerid->DbValue = $row['brokerid'];
		$this->transdate->DbValue = $row['transdate'];
		$this->serviceid->DbValue = $row['serviceid'];
		$this->billingservicename->DbValue = $row['billingservicename'];
		$this->customeracctno->DbValue = $row['customeracctno'];
		$this->refno->DbValue = $row['refno'];
		$this->currcode->DbValue = $row['currcode'];
		$this->amount->DbValue = $row['amount'];
		$this->balance->DbValue = $row['balance'];
		$this->confcode->DbValue = $row['confcode'];
		$this->success->DbValue = $row['success'];
		$this->_userid->DbValue = $row['userid'];
		$this->billerresponse->DbValue = $row['billerresponse'];
		$this->paymenttype->DbValue = $row['paymenttype'];
		$this->customername->DbValue = $row['customername'];
		$this->parentuserid->DbValue = $row['parentuserid'];
		$this->businessname->DbValue = $row['businessname'];
		$this->businessphoneno->DbValue = $row['businessphoneno'];
		$this->businessaddress1->DbValue = $row['businessaddress1'];
		$this->businessaddress2->DbValue = $row['businessaddress2'];
		$this->businesscity->DbValue = $row['businesscity'];
		$this->businessstate->DbValue = $row['businessstate'];
		$this->businesscountry->DbValue = $row['businesscountry'];
		$this->feeid->DbValue = $row['feeid'];
		$this->_tabletype->DbValue = $row['tabletype'];
		$this->feemerchanttotal->DbValue = $row['feemerchanttotal'];
		$this->feeconsumertotal->DbValue = $row['feeconsumertotal'];
		$this->feesystemtotal->DbValue = $row['feesystemtotal'];
		$this->feeexternaltotal->DbValue = $row['feeexternaltotal'];
		$this->feefranchiseetotal->DbValue = $row['feefranchiseetotal'];
		$this->feeresellertotal->DbValue = $row['feeresellertotal'];
		$this->officialdocnumber->DbValue = $row['officialdocnumber'];
		$this->branchname->DbValue = $row['branchname'];
		$this->clerkname->DbValue = $row['clerkname'];
		$this->taxamount->DbValue = $row['taxamount'];
		$this->totalamount->DbValue = $row['totalamount'];
		$this->taxperc->DbValue = $row['taxperc'];
		$this->department->DbValue = $row['department'];
		$this->billingresponse2->DbValue = $row['billingresponse2'];
		$this->purchaseid->DbValue = $row['purchaseid'];
		$this->paymentid->DbValue = $row['paymentid'];
		$this->transgroupid->DbValue = $row['transgroupid'];
		$this->otherdetails->DbValue = $row['otherdetails'];
	}

	// Delete uploaded files
	public function deleteUploadedFiles($row)
	{
		$this->loadDbValues($row);
	}

	// Record filter WHERE clause
	protected function sqlKeyFilter()
	{
		return "`recid` = @recid@ AND `brokeremail` = '@brokeremail@'";
	}

	// Get record filter
	public function getRecordFilter($row = NULL)
	{
		$keyFilter = $this->sqlKeyFilter();
		if (is_array($row))
			$val = array_key_exists('recid', $row) ? $row['recid'] : NULL;
		else
			$val = $this->recid->OldValue !== NULL ? $this->recid->OldValue : $this->recid->CurrentValue;
		if (!is_numeric($val))
			return "0=1"; // Invalid key
		if ($val == NULL)
			return "0=1"; // Invalid key
		else
			$keyFilter = str_replace("@recid@", AdjustSql($val, $this->Dbid), $keyFilter); // Replace key value
		if (is_array($row))
			$val = array_key_exists('brokeremail', $row) ? $row['brokeremail'] : NULL;
		else
			$val = $this->brokeremail->OldValue !== NULL ? $this->brokeremail->OldValue : $this->brokeremail->CurrentValue;
		if ($val == NULL)
			return "0=1"; // Invalid key
		else
			$keyFilter = str_replace("@brokeremail@", AdjustSql($val, $this->Dbid), $keyFilter); // Replace key value
		return $keyFilter;
	}

	// Return page URL
	public function getReturnUrl()
	{
		$name = PROJECT_NAME . "_" . $this->TableVar . "_" . Config("TABLE_RETURN_URL");

		// Get referer URL automatically
		if (ServerVar("HTTP_REFERER") != "" && ReferPageName() != CurrentPageName() && ReferPageName() != "login.php") // Referer not same page or login page
			$_SESSION[$name] = ServerVar("HTTP_REFERER"); // Save to Session
		if (@$_SESSION[$name] != "") {
			return $_SESSION[$name];
		} else {
			return "vbillinghistorylist.php";
		}
	}
	public function setReturnUrl($v)
	{
		$_SESSION[PROJECT_NAME . "_" . $this->TableVar . "_" . Config("TABLE_RETURN_URL")] = $v;
	}

	// Get modal caption
	public function getModalCaption($pageName)
	{
		global $Language;
		if ($pageName == "vbillinghistoryview.php")
			return $Language->phrase("View");
		elseif ($pageName == "vbillinghistoryedit.php")
			return $Language->phrase("Edit");
		elseif ($pageName == "vbillinghistoryadd.php")
			return $Language->phrase("Add");
		else
			return "";
	}

	// List URL
	public function getListUrl()
	{
		return "vbillinghistorylist.php";
	}

	// View URL
	public function getViewUrl($parm = "")
	{
		if ($parm != "")
			$url = $this->keyUrl("vbillinghistoryview.php", $this->getUrlParm($parm));
		else
			$url = $this->keyUrl("vbillinghistoryview.php", $this->getUrlParm(Config("TABLE_SHOW_DETAIL") . "="));
		return $this->addMasterUrl($url);
	}

	// Add URL
	public function getAddUrl($parm = "")
	{
		if ($parm != "")
			$url = "vbillinghistoryadd.php?" . $this->getUrlParm($parm);
		else
			$url = "vbillinghistoryadd.php";
		return $this->addMasterUrl($url);
	}

	// Edit URL
	public function getEditUrl($parm = "")
	{
		$url = $this->keyUrl("vbillinghistoryedit.php", $this->getUrlParm($parm));
		return $this->addMasterUrl($url);
	}

	// Inline edit URL
	public function getInlineEditUrl()
	{
		$url = $this->keyUrl(CurrentPageName(), $this->getUrlParm("action=edit"));
		return $this->addMasterUrl($url);
	}

	// Copy URL
	public function getCopyUrl($parm = "")
	{
		$url = $this->keyUrl("vbillinghistoryadd.php", $this->getUrlParm($parm));
		return $this->addMasterUrl($url);
	}

	// Inline copy URL
	public function getInlineCopyUrl()
	{
		$url = $this->keyUrl(CurrentPageName(), $this->getUrlParm("action=copy"));
		return $this->addMasterUrl($url);
	}

	// Delete URL
	public function getDeleteUrl()
	{
		return $this->keyUrl("vbillinghistorydelete.php", $this->getUrlParm());
	}

	// Add master url
	public function addMasterUrl($url)
	{
		if ($this->getCurrentMasterTable() == "userpurchasereturn" && !ContainsString($url, Config("TABLE_SHOW_MASTER") . "=")) {
			$url .= (ContainsString($url, "?") ? "&" : "?") . Config("TABLE_SHOW_MASTER") . "=" . $this->getCurrentMasterTable();
			$url .= "&fk_purchaseid=" . urlencode($this->purchaseid->CurrentValue);
		}
		if ($this->getCurrentMasterTable() == "userpurchase" && !ContainsString($url, Config("TABLE_SHOW_MASTER") . "=")) {
			$url .= (ContainsString($url, "?") ? "&" : "?") . Config("TABLE_SHOW_MASTER") . "=" . $this->getCurrentMasterTable();
			$url .= "&fk_purchaseid=" . urlencode($this->purchaseid->CurrentValue);
		}
		return $url;
	}
	public function keyToJson($htmlEncode = FALSE)
	{
		$json = "";
		$json .= "recid:" . JsonEncode($this->recid->CurrentValue, "number");
		$json .= ",brokeremail:" . JsonEncode($this->brokeremail->CurrentValue, "string");
		$json = "{" . $json . "}";
		if ($htmlEncode)
			$json = HtmlEncode($json);
		return $json;
	}

	// Add key value to URL
	public function keyUrl($url, $parm = "")
	{
		$url = $url . "?";
		if ($parm != "")
			$url .= $parm . "&";
		if ($this->recid->CurrentValue != NULL) {
			$url .= "recid=" . urlencode($this->recid->CurrentValue);
		} else {
			return "javascript:ew.alert(ew.language.phrase('InvalidRecord'));";
		}
		if ($this->brokeremail->CurrentValue != NULL) {
			$url .= "&brokeremail=" . urlencode($this->brokeremail->CurrentValue);
		} else {
			return "javascript:ew.alert(ew.language.phrase('InvalidRecord'));";
		}
		return $url;
	}

	// Sort URL
	public function sortUrl(&$fld)
	{
		if ($this->CurrentAction || $this->isExport() ||
			in_array($fld->Type, [128, 204, 205])) { // Unsortable data type
				return "";
		} elseif ($fld->Sortable) {
			$urlParm = $this->getUrlParm("order=" . urlencode($fld->Name) . "&amp;ordertype=" . $fld->reverseSort());
			return $this->addMasterUrl(CurrentPageName() . "?" . $urlParm);
		} else {
			return "";
		}
	}

	// Get record keys from Post/Get/Session
	public function getRecordKeys()
	{
		$arKeys = [];
		$arKey = [];
		if (Param("key_m") !== NULL) {
			$arKeys = Param("key_m");
			$cnt = count($arKeys);
			for ($i = 0; $i < $cnt; $i++)
				$arKeys[$i] = explode(Config("COMPOSITE_KEY_SEPARATOR"), $arKeys[$i]);
		} else {
			if (Param("recid") !== NULL)
				$arKey[] = Param("recid");
			elseif (IsApi() && Key(0) !== NULL)
				$arKey[] = Key(0);
			elseif (IsApi() && Route(2) !== NULL)
				$arKey[] = Route(2);
			else
				$arKeys = NULL; // Do not setup
			if (Param("brokeremail") !== NULL)
				$arKey[] = Param("brokeremail");
			elseif (IsApi() && Key(1) !== NULL)
				$arKey[] = Key(1);
			elseif (IsApi() && Route(3) !== NULL)
				$arKey[] = Route(3);
			else
				$arKeys = NULL; // Do not setup
			if (is_array($arKeys)) $arKeys[] = $arKey;

			//return $arKeys; // Do not return yet, so the values will also be checked by the following code
		}

		// Check keys
		$ar = [];
		if (is_array($arKeys)) {
			foreach ($arKeys as $key) {
				if (!is_array($key) || count($key) != 2)
					continue; // Just skip so other keys will still work
				if (!is_numeric($key[0])) // recid
					continue;
				$ar[] = $key;
			}
		}
		return $ar;
	}

	// Get filter from record keys
	public function getFilterFromRecordKeys($setCurrent = TRUE)
	{
		$arKeys = $this->getRecordKeys();
		$keyFilter = "";
		foreach ($arKeys as $key) {
			if ($keyFilter != "") $keyFilter .= " OR ";
			if ($setCurrent)
				$this->recid->CurrentValue = $key[0];
			else
				$this->recid->OldValue = $key[0];
			if ($setCurrent)
				$this->brokeremail->CurrentValue = $key[1];
			else
				$this->brokeremail->OldValue = $key[1];
			$keyFilter .= "(" . $this->getRecordFilter() . ")";
		}
		return $keyFilter;
	}

	// Load rows based on filter
	public function &loadRs($filter)
	{

		// Set up filter (WHERE Clause)
		$sql = $this->getSql($filter);
		$conn = $this->getConnection();
		$rs = $conn->execute($sql);
		return $rs;
	}

	// Load row values from recordset
	public function loadListRowValues(&$rs)
	{
		$this->recid->setDbValue($rs->fields('recid'));
		$this->brokeremail->setDbValue($rs->fields('brokeremail'));
		$this->brokerid->setDbValue($rs->fields('brokerid'));
		$this->transdate->setDbValue($rs->fields('transdate'));
		$this->serviceid->setDbValue($rs->fields('serviceid'));
		$this->billingservicename->setDbValue($rs->fields('billingservicename'));
		$this->customeracctno->setDbValue($rs->fields('customeracctno'));
		$this->refno->setDbValue($rs->fields('refno'));
		$this->currcode->setDbValue($rs->fields('currcode'));
		$this->amount->setDbValue($rs->fields('amount'));
		$this->balance->setDbValue($rs->fields('balance'));
		$this->confcode->setDbValue($rs->fields('confcode'));
		$this->success->setDbValue($rs->fields('success'));
		$this->_userid->setDbValue($rs->fields('userid'));
		$this->billerresponse->setDbValue($rs->fields('billerresponse'));
		$this->paymenttype->setDbValue($rs->fields('paymenttype'));
		$this->customername->setDbValue($rs->fields('customername'));
		$this->parentuserid->setDbValue($rs->fields('parentuserid'));
		$this->businessname->setDbValue($rs->fields('businessname'));
		$this->businessphoneno->setDbValue($rs->fields('businessphoneno'));
		$this->businessaddress1->setDbValue($rs->fields('businessaddress1'));
		$this->businessaddress2->setDbValue($rs->fields('businessaddress2'));
		$this->businesscity->setDbValue($rs->fields('businesscity'));
		$this->businessstate->setDbValue($rs->fields('businessstate'));
		$this->businesscountry->setDbValue($rs->fields('businesscountry'));
		$this->feeid->setDbValue($rs->fields('feeid'));
		$this->_tabletype->setDbValue($rs->fields('tabletype'));
		$this->feemerchanttotal->setDbValue($rs->fields('feemerchanttotal'));
		$this->feeconsumertotal->setDbValue($rs->fields('feeconsumertotal'));
		$this->feesystemtotal->setDbValue($rs->fields('feesystemtotal'));
		$this->feeexternaltotal->setDbValue($rs->fields('feeexternaltotal'));
		$this->feefranchiseetotal->setDbValue($rs->fields('feefranchiseetotal'));
		$this->feeresellertotal->setDbValue($rs->fields('feeresellertotal'));
		$this->officialdocnumber->setDbValue($rs->fields('officialdocnumber'));
		$this->branchname->setDbValue($rs->fields('branchname'));
		$this->clerkname->setDbValue($rs->fields('clerkname'));
		$this->taxamount->setDbValue($rs->fields('taxamount'));
		$this->totalamount->setDbValue($rs->fields('totalamount'));
		$this->taxperc->setDbValue($rs->fields('taxperc'));
		$this->department->setDbValue($rs->fields('department'));
		$this->billingresponse2->setDbValue($rs->fields('billingresponse2'));
		$this->purchaseid->setDbValue($rs->fields('purchaseid'));
		$this->paymentid->setDbValue($rs->fields('paymentid'));
		$this->transgroupid->setDbValue($rs->fields('transgroupid'));
		$this->otherdetails->setDbValue($rs->fields('otherdetails'));
	}

	// Render list row values
	public function renderListRow()
	{
		global $Security, $CurrentLanguage, $Language;

		// Call Row Rendering event
		$this->Row_Rendering();

		// Common render codes
		// recid
		// brokeremail
		// brokerid
		// transdate
		// serviceid
		// billingservicename

		$this->billingservicename->CellCssStyle = "white-space: nowrap;";

		// customeracctno
		// refno
		// currcode
		// amount
		// balance
		// confcode
		// success
		// userid
		// billerresponse
		// paymenttype
		// customername
		// parentuserid
		// businessname
		// businessphoneno
		// businessaddress1
		// businessaddress2
		// businesscity
		// businessstate
		// businesscountry
		// feeid
		// tabletype
		// feemerchanttotal
		// feeconsumertotal
		// feesystemtotal
		// feeexternaltotal
		// feefranchiseetotal
		// feeresellertotal
		// officialdocnumber
		// branchname
		// clerkname
		// taxamount
		// totalamount
		// taxperc
		// department
		// billingresponse2
		// purchaseid
		// paymentid
		// transgroupid
		// otherdetails
		// recid

		$this->recid->ViewValue = $this->recid->CurrentValue;
		$this->recid->ViewCustomAttributes = "";

		// brokeremail
		$this->brokeremail->ViewValue = $this->brokeremail->CurrentValue;
		$curVal = strval($this->brokeremail->CurrentValue);
		if ($curVal != "") {
			$this->brokeremail->ViewValue = $this->brokeremail->lookupCacheOption($curVal);
			if ($this->brokeremail->ViewValue === NULL) { // Lookup from database
				$filterWrk = "`emailAccount`" . SearchString("=", $curVal, DATATYPE_STRING, "");
				$sqlWrk = $this->brokeremail->Lookup->getSql(FALSE, $filterWrk, '', $this);
				$rswrk = Conn()->execute($sqlWrk);
				if ($rswrk && !$rswrk->EOF) { // Lookup values found
					$arwrk = [];
					$arwrk[1] = $rswrk->fields('df');
					$this->brokeremail->ViewValue = $this->brokeremail->displayValue($arwrk);
					$rswrk->Close();
				} else {
					$this->brokeremail->ViewValue = $this->brokeremail->CurrentValue;
				}
			}
		} else {
			$this->brokeremail->ViewValue = NULL;
		}
		$this->brokeremail->ViewCustomAttributes = "";

		// brokerid
		$this->brokerid->ViewValue = $this->brokerid->CurrentValue;
		$this->brokerid->ViewCustomAttributes = "";

		// transdate
		$this->transdate->ViewValue = $this->transdate->CurrentValue;
		$this->transdate->ViewValue = FormatDateTime($this->transdate->ViewValue, 2);
		$this->transdate->ViewCustomAttributes = "";

		// serviceid
		$curVal = strval($this->serviceid->CurrentValue);
		if ($curVal != "") {
			$this->serviceid->ViewValue = $this->serviceid->lookupCacheOption($curVal);
			if ($this->serviceid->ViewValue === NULL) { // Lookup from database
				$arwrk = explode(",", $curVal);
				$filterWrk = "";
				foreach ($arwrk as $wrk) {
					if ($filterWrk != "")
						$filterWrk .= " OR ";
					$filterWrk .= "`serviceid`" . SearchString("=", trim($wrk), DATATYPE_NUMBER, "_4payreference");
				}
				$sqlWrk = $this->serviceid->Lookup->getSql(FALSE, $filterWrk, '', $this);
				$rswrk = Conn("_4payreference")->execute($sqlWrk);
				if ($rswrk && !$rswrk->EOF) { // Lookup values found
					$this->serviceid->ViewValue = new OptionValues();
					$ari = 0;
					while (!$rswrk->EOF) {
						$arwrk = [];
						$arwrk[1] = $rswrk->fields('df');
						$this->serviceid->ViewValue->add($this->serviceid->displayValue($arwrk));
						$rswrk->MoveNext();
						$ari++;
					}
					$rswrk->Close();
				} else {
					$this->serviceid->ViewValue = $this->serviceid->CurrentValue;
				}
			}
		} else {
			$this->serviceid->ViewValue = NULL;
		}
		$this->serviceid->ViewCustomAttributes = "";

		// billingservicename
		$this->billingservicename->ViewValue = $this->billingservicename->CurrentValue;
		$this->billingservicename->ViewCustomAttributes = "";

		// customeracctno
		$this->customeracctno->ViewValue = $this->customeracctno->CurrentValue;
		$this->customeracctno->ViewCustomAttributes = "";

		// refno
		$this->refno->ViewValue = $this->refno->CurrentValue;
		$this->refno->ViewCustomAttributes = "";

		// currcode
		$this->currcode->ViewValue = $this->currcode->CurrentValue;
		$this->currcode->ViewCustomAttributes = "";

		// amount
		$this->amount->ViewValue = $this->amount->CurrentValue;
		$this->amount->ViewValue = FormatNumber($this->amount->ViewValue, Config("DEFAULT_DECIMAL_PRECISION"));
		$this->amount->ViewCustomAttributes = "";

		// balance
		$this->balance->ViewValue = $this->balance->CurrentValue;
		$this->balance->ViewValue = FormatNumber($this->balance->ViewValue, Config("DEFAULT_DECIMAL_PRECISION"));
		$this->balance->ViewCustomAttributes = "";

		// confcode
		$this->confcode->ViewValue = $this->confcode->CurrentValue;
		$this->confcode->ViewCustomAttributes = "";

		// success
		if (strval($this->success->CurrentValue) != "") {
			$this->success->ViewValue = $this->success->optionCaption($this->success->CurrentValue);
		} else {
			$this->success->ViewValue = NULL;
		}
		$this->success->ViewCustomAttributes = "";

		// userid
		$this->_userid->ViewValue = $this->_userid->CurrentValue;
		$this->_userid->ViewCustomAttributes = "";

		// billerresponse
		$this->billerresponse->ViewValue = $this->billerresponse->CurrentValue;
		$this->billerresponse->ViewCustomAttributes = "";

		// paymenttype
		if (strval($this->paymenttype->CurrentValue) != "") {
			$this->paymenttype->ViewValue = $this->paymenttype->optionCaption($this->paymenttype->CurrentValue);
		} else {
			$this->paymenttype->ViewValue = NULL;
		}
		$this->paymenttype->ViewCustomAttributes = "";

		// customername
		$this->customername->ViewValue = $this->customername->CurrentValue;
		$this->customername->ViewCustomAttributes = "";

		// parentuserid
		$this->parentuserid->ViewValue = $this->parentuserid->CurrentValue;
		$this->parentuserid->ViewCustomAttributes = "";

		// businessname
		$this->businessname->ViewValue = $this->businessname->CurrentValue;
		$this->businessname->ViewCustomAttributes = "";

		// businessphoneno
		$this->businessphoneno->ViewValue = $this->businessphoneno->CurrentValue;
		$this->businessphoneno->ViewCustomAttributes = "";

		// businessaddress1
		$this->businessaddress1->ViewValue = $this->businessaddress1->CurrentValue;
		$this->businessaddress1->ViewCustomAttributes = "";

		// businessaddress2
		$this->businessaddress2->ViewValue = $this->businessaddress2->CurrentValue;
		$this->businessaddress2->ViewCustomAttributes = "";

		// businesscity
		$this->businesscity->ViewValue = $this->businesscity->CurrentValue;
		$this->businesscity->ViewCustomAttributes = "";

		// businessstate
		$this->businessstate->ViewValue = $this->businessstate->CurrentValue;
		$this->businessstate->ViewCustomAttributes = "";

		// businesscountry
		$this->businesscountry->ViewValue = $this->businesscountry->CurrentValue;
		$this->businesscountry->ViewCustomAttributes = "";

		// feeid
		$this->feeid->ViewValue = $this->feeid->CurrentValue;
		$this->feeid->ViewValue = FormatNumber($this->feeid->ViewValue, 0, -2, -2, -2);
		$this->feeid->ViewCustomAttributes = "";

		// tabletype
		$this->_tabletype->ViewValue = $this->_tabletype->CurrentValue;
		$this->_tabletype->ViewValue = FormatNumber($this->_tabletype->ViewValue, 0, -2, -2, -2);
		$this->_tabletype->ViewCustomAttributes = "";

		// feemerchanttotal
		$this->feemerchanttotal->ViewValue = $this->feemerchanttotal->CurrentValue;
		$this->feemerchanttotal->ViewValue = FormatNumber($this->feemerchanttotal->ViewValue, 2, -2, -2, -2);
		$this->feemerchanttotal->ViewCustomAttributes = "";

		// feeconsumertotal
		$this->feeconsumertotal->ViewValue = $this->feeconsumertotal->CurrentValue;
		$this->feeconsumertotal->ViewValue = FormatNumber($this->feeconsumertotal->ViewValue, 2, -2, -2, -2);
		$this->feeconsumertotal->ViewCustomAttributes = "";

		// feesystemtotal
		$this->feesystemtotal->ViewValue = $this->feesystemtotal->CurrentValue;
		$this->feesystemtotal->ViewValue = FormatNumber($this->feesystemtotal->ViewValue, 2, -2, -2, -2);
		$this->feesystemtotal->ViewCustomAttributes = "";

		// feeexternaltotal
		$this->feeexternaltotal->ViewValue = $this->feeexternaltotal->CurrentValue;
		$this->feeexternaltotal->ViewValue = FormatNumber($this->feeexternaltotal->ViewValue, 2, -2, -2, -2);
		$this->feeexternaltotal->ViewCustomAttributes = "";

		// feefranchiseetotal
		$this->feefranchiseetotal->ViewValue = $this->feefranchiseetotal->CurrentValue;
		$this->feefranchiseetotal->ViewValue = FormatNumber($this->feefranchiseetotal->ViewValue, 2, -2, -2, -2);
		$this->feefranchiseetotal->ViewCustomAttributes = "";

		// feeresellertotal
		$this->feeresellertotal->ViewValue = $this->feeresellertotal->CurrentValue;
		$this->feeresellertotal->ViewValue = FormatNumber($this->feeresellertotal->ViewValue, 2, -2, -2, -2);
		$this->feeresellertotal->ViewCustomAttributes = "";

		// officialdocnumber
		$this->officialdocnumber->ViewValue = $this->officialdocnumber->CurrentValue;
		$this->officialdocnumber->ViewCustomAttributes = "";

		// branchname
		$this->branchname->ViewValue = $this->branchname->CurrentValue;
		$this->branchname->ViewCustomAttributes = "";

		// clerkname
		$this->clerkname->ViewValue = $this->clerkname->CurrentValue;
		$this->clerkname->ViewCustomAttributes = "";

		// taxamount
		$this->taxamount->ViewValue = $this->taxamount->CurrentValue;
		$this->taxamount->ViewValue = FormatNumber($this->taxamount->ViewValue, 2, -2, -2, -2);
		$this->taxamount->ViewCustomAttributes = "";

		// totalamount
		$this->totalamount->ViewValue = $this->totalamount->CurrentValue;
		$this->totalamount->ViewValue = FormatNumber($this->totalamount->ViewValue, 2, -2, -2, -2);
		$this->totalamount->ViewCustomAttributes = "";

		// taxperc
		$this->taxperc->ViewValue = $this->taxperc->CurrentValue;
		$this->taxperc->ViewValue = FormatNumber($this->taxperc->ViewValue, 2, -2, -2, -2);
		$this->taxperc->ViewCustomAttributes = "";

		// department
		$curVal = strval($this->department->CurrentValue);
		if ($curVal != "") {
			$this->department->ViewValue = $this->department->lookupCacheOption($curVal);
			if ($this->department->ViewValue === NULL) { // Lookup from database
				$filterWrk = "`domainatt`" . SearchString("=", $curVal, DATATYPE_STRING, "_4payreference");
				$sqlWrk = $this->department->Lookup->getSql(FALSE, $filterWrk, '', $this);
				$rswrk = Conn("_4payreference")->execute($sqlWrk);
				if ($rswrk && !$rswrk->EOF) { // Lookup values found
					$arwrk = [];
					$arwrk[1] = $rswrk->fields('df');
					$this->department->ViewValue = $this->department->displayValue($arwrk);
					$rswrk->Close();
				} else {
					$this->department->ViewValue = $this->department->CurrentValue;
				}
			}
		} else {
			$this->department->ViewValue = NULL;
		}
		$this->department->ViewCustomAttributes = "";

		// billingresponse2
		$this->billingresponse2->ViewValue = $this->billingresponse2->CurrentValue;
		$this->billingresponse2->ViewCustomAttributes = "";

		// purchaseid
		$this->purchaseid->ViewValue = $this->purchaseid->CurrentValue;
		$this->purchaseid->ViewValue = FormatNumber($this->purchaseid->ViewValue, 0, -2, -2, -2);
		$this->purchaseid->ViewCustomAttributes = "";

		// paymentid
		$this->paymentid->ViewValue = $this->paymentid->CurrentValue;
		$this->paymentid->ViewValue = FormatNumber($this->paymentid->ViewValue, 0, -2, -2, -2);
		$this->paymentid->ViewCustomAttributes = "";

		// transgroupid
		$this->transgroupid->ViewValue = $this->transgroupid->CurrentValue;
		$this->transgroupid->ViewValue = FormatNumber($this->transgroupid->ViewValue, 0, -2, -2, -2);
		$this->transgroupid->ViewCustomAttributes = "";

		// otherdetails
		$this->otherdetails->ViewValue = $this->otherdetails->CurrentValue;
		$this->otherdetails->ViewCustomAttributes = "";

		// recid
		$this->recid->LinkCustomAttributes = "";
		$this->recid->HrefValue = "";
		$this->recid->TooltipValue = "";

		// brokeremail
		$this->brokeremail->LinkCustomAttributes = "";
		$this->brokeremail->HrefValue = "";
		$this->brokeremail->TooltipValue = "";

		// brokerid
		$this->brokerid->LinkCustomAttributes = "";
		$this->brokerid->HrefValue = "";
		$this->brokerid->TooltipValue = "";

		// transdate
		$this->transdate->LinkCustomAttributes = "";
		$this->transdate->HrefValue = "";
		$this->transdate->TooltipValue = "";

		// serviceid
		$this->serviceid->LinkCustomAttributes = "";
		$this->serviceid->HrefValue = "";
		$this->serviceid->TooltipValue = "";

		// billingservicename
		$this->billingservicename->LinkCustomAttributes = "";
		$this->billingservicename->HrefValue = "";
		$this->billingservicename->TooltipValue = "";

		// customeracctno
		$this->customeracctno->LinkCustomAttributes = "";
		$this->customeracctno->HrefValue = "";
		$this->customeracctno->TooltipValue = "";

		// refno
		$this->refno->LinkCustomAttributes = "";
		$this->refno->HrefValue = "";
		$this->refno->TooltipValue = "";

		// currcode
		$this->currcode->LinkCustomAttributes = "";
		$this->currcode->HrefValue = "";
		$this->currcode->TooltipValue = "";

		// amount
		$this->amount->LinkCustomAttributes = "";
		$this->amount->HrefValue = "";
		$this->amount->TooltipValue = "";

		// balance
		$this->balance->LinkCustomAttributes = "";
		$this->balance->HrefValue = "";
		$this->balance->TooltipValue = "";

		// confcode
		$this->confcode->LinkCustomAttributes = "";
		$this->confcode->HrefValue = "";
		$this->confcode->TooltipValue = "";

		// success
		$this->success->LinkCustomAttributes = "";
		$this->success->HrefValue = "";
		$this->success->TooltipValue = "";

		// userid
		$this->_userid->LinkCustomAttributes = "";
		$this->_userid->HrefValue = "";
		$this->_userid->TooltipValue = "";

		// billerresponse
		$this->billerresponse->LinkCustomAttributes = "";
		$this->billerresponse->HrefValue = "";
		$this->billerresponse->TooltipValue = "";

		// paymenttype
		$this->paymenttype->LinkCustomAttributes = "";
		$this->paymenttype->HrefValue = "";
		$this->paymenttype->TooltipValue = "";

		// customername
		$this->customername->LinkCustomAttributes = "";
		$this->customername->HrefValue = "";
		$this->customername->TooltipValue = "";

		// parentuserid
		$this->parentuserid->LinkCustomAttributes = "";
		$this->parentuserid->HrefValue = "";
		$this->parentuserid->TooltipValue = "";

		// businessname
		$this->businessname->LinkCustomAttributes = "";
		$this->businessname->HrefValue = "";
		$this->businessname->TooltipValue = "";

		// businessphoneno
		$this->businessphoneno->LinkCustomAttributes = "";
		$this->businessphoneno->HrefValue = "";
		$this->businessphoneno->TooltipValue = "";

		// businessaddress1
		$this->businessaddress1->LinkCustomAttributes = "";
		$this->businessaddress1->HrefValue = "";
		$this->businessaddress1->TooltipValue = "";

		// businessaddress2
		$this->businessaddress2->LinkCustomAttributes = "";
		$this->businessaddress2->HrefValue = "";
		$this->businessaddress2->TooltipValue = "";

		// businesscity
		$this->businesscity->LinkCustomAttributes = "";
		$this->businesscity->HrefValue = "";
		$this->businesscity->TooltipValue = "";

		// businessstate
		$this->businessstate->LinkCustomAttributes = "";
		$this->businessstate->HrefValue = "";
		$this->businessstate->TooltipValue = "";

		// businesscountry
		$this->businesscountry->LinkCustomAttributes = "";
		$this->businesscountry->HrefValue = "";
		$this->businesscountry->TooltipValue = "";

		// feeid
		$this->feeid->LinkCustomAttributes = "";
		$this->feeid->HrefValue = "";
		$this->feeid->TooltipValue = "";

		// tabletype
		$this->_tabletype->LinkCustomAttributes = "";
		$this->_tabletype->HrefValue = "";
		$this->_tabletype->TooltipValue = "";

		// feemerchanttotal
		$this->feemerchanttotal->LinkCustomAttributes = "";
		$this->feemerchanttotal->HrefValue = "";
		$this->feemerchanttotal->TooltipValue = "";

		// feeconsumertotal
		$this->feeconsumertotal->LinkCustomAttributes = "";
		$this->feeconsumertotal->HrefValue = "";
		$this->feeconsumertotal->TooltipValue = "";

		// feesystemtotal
		$this->feesystemtotal->LinkCustomAttributes = "";
		$this->feesystemtotal->HrefValue = "";
		$this->feesystemtotal->TooltipValue = "";

		// feeexternaltotal
		$this->feeexternaltotal->LinkCustomAttributes = "";
		$this->feeexternaltotal->HrefValue = "";
		$this->feeexternaltotal->TooltipValue = "";

		// feefranchiseetotal
		$this->feefranchiseetotal->LinkCustomAttributes = "";
		$this->feefranchiseetotal->HrefValue = "";
		$this->feefranchiseetotal->TooltipValue = "";

		// feeresellertotal
		$this->feeresellertotal->LinkCustomAttributes = "";
		$this->feeresellertotal->HrefValue = "";
		$this->feeresellertotal->TooltipValue = "";

		// officialdocnumber
		$this->officialdocnumber->LinkCustomAttributes = "";
		$this->officialdocnumber->HrefValue = "";
		$this->officialdocnumber->TooltipValue = "";

		// branchname
		$this->branchname->LinkCustomAttributes = "";
		$this->branchname->HrefValue = "";
		$this->branchname->TooltipValue = "";

		// clerkname
		$this->clerkname->LinkCustomAttributes = "";
		$this->clerkname->HrefValue = "";
		$this->clerkname->TooltipValue = "";

		// taxamount
		$this->taxamount->LinkCustomAttributes = "";
		$this->taxamount->HrefValue = "";
		$this->taxamount->TooltipValue = "";

		// totalamount
		$this->totalamount->LinkCustomAttributes = "";
		$this->totalamount->HrefValue = "";
		$this->totalamount->TooltipValue = "";

		// taxperc
		$this->taxperc->LinkCustomAttributes = "";
		$this->taxperc->HrefValue = "";
		$this->taxperc->TooltipValue = "";

		// department
		$this->department->LinkCustomAttributes = "";
		$this->department->HrefValue = "";
		$this->department->TooltipValue = "";

		// billingresponse2
		$this->billingresponse2->LinkCustomAttributes = "";
		$this->billingresponse2->HrefValue = "";
		$this->billingresponse2->TooltipValue = "";

		// purchaseid
		$this->purchaseid->LinkCustomAttributes = "";
		if (!EmptyValue($this->purchaseid->CurrentValue)) {
			$this->purchaseid->HrefValue = "userpurchaseview.php?showdetail=&purchaseid=" . $this->purchaseid->CurrentValue; // Add prefix/suffix
			$this->purchaseid->LinkAttrs["target"] = "_self"; // Add target
			if ($this->isExport())
				$this->purchaseid->HrefValue = FullUrl($this->purchaseid->HrefValue, "href");
		} else {
			$this->purchaseid->HrefValue = "";
		}
		$this->purchaseid->TooltipValue = "";

		// paymentid
		$this->paymentid->LinkCustomAttributes = "";
		if (!EmptyValue($this->paymentid->CurrentValue)) {
			$this->paymentid->HrefValue = "userpurchasepaymentview.php?showdetail=&showmaster=userpurchase&paymentid=" . $this->paymentid->CurrentValue; // Add prefix/suffix
			$this->paymentid->LinkAttrs["target"] = "_self"; // Add target
			if ($this->isExport())
				$this->paymentid->HrefValue = FullUrl($this->paymentid->HrefValue, "href");
		} else {
			$this->paymentid->HrefValue = "";
		}
		$this->paymentid->TooltipValue = "";

		// transgroupid
		$this->transgroupid->LinkCustomAttributes = "";
		$this->transgroupid->HrefValue = "";
		$this->transgroupid->TooltipValue = "";

		// otherdetails
		$this->otherdetails->LinkCustomAttributes = "";
		$this->otherdetails->HrefValue = "";
		$this->otherdetails->TooltipValue = "";

		// Call Row Rendered event
		$this->Row_Rendered();

		// Save data for Custom Template
		$this->Rows[] = $this->customTemplateFieldValues();
	}

	// Render edit row values
	public function renderEditRow()
	{
		global $Security, $CurrentLanguage, $Language;

		// Call Row Rendering event
		$this->Row_Rendering();

		// recid
		$this->recid->EditAttrs["class"] = "form-control";
		$this->recid->EditCustomAttributes = "";
		$this->recid->EditValue = $this->recid->CurrentValue;
		$this->recid->ViewCustomAttributes = "";

		// brokeremail
		$this->brokeremail->EditAttrs["class"] = "form-control";
		$this->brokeremail->EditCustomAttributes = "";
		if (!$this->brokeremail->Raw)
			$this->brokeremail->CurrentValue = HtmlDecode($this->brokeremail->CurrentValue);
		$this->brokeremail->EditValue = $this->brokeremail->CurrentValue;
		$this->brokeremail->PlaceHolder = RemoveHtml($this->brokeremail->caption());

		// brokerid
		$this->brokerid->EditAttrs["class"] = "form-control";
		$this->brokerid->EditCustomAttributes = "";
		$this->brokerid->EditValue = $this->brokerid->CurrentValue;
		$this->brokerid->PlaceHolder = RemoveHtml($this->brokerid->caption());

		// transdate
		$this->transdate->EditAttrs["class"] = "form-control";
		$this->transdate->EditCustomAttributes = "";
		$this->transdate->EditValue = FormatDateTime($this->transdate->CurrentValue, 2);
		$this->transdate->PlaceHolder = RemoveHtml($this->transdate->caption());

		// serviceid
		$this->serviceid->EditCustomAttributes = "";

		// billingservicename
		$this->billingservicename->EditAttrs["class"] = "form-control";
		$this->billingservicename->EditCustomAttributes = "";
		if (!$this->billingservicename->Raw)
			$this->billingservicename->CurrentValue = HtmlDecode($this->billingservicename->CurrentValue);
		$this->billingservicename->EditValue = $this->billingservicename->CurrentValue;
		$this->billingservicename->PlaceHolder = RemoveHtml($this->billingservicename->caption());

		// customeracctno
		$this->customeracctno->EditAttrs["class"] = "form-control";
		$this->customeracctno->EditCustomAttributes = "";
		if (!$this->customeracctno->Raw)
			$this->customeracctno->CurrentValue = HtmlDecode($this->customeracctno->CurrentValue);
		$this->customeracctno->EditValue = $this->customeracctno->CurrentValue;
		$this->customeracctno->PlaceHolder = RemoveHtml($this->customeracctno->caption());

		// refno
		$this->refno->EditAttrs["class"] = "form-control";
		$this->refno->EditCustomAttributes = "";
		if (!$this->refno->Raw)
			$this->refno->CurrentValue = HtmlDecode($this->refno->CurrentValue);
		$this->refno->EditValue = $this->refno->CurrentValue;
		$this->refno->PlaceHolder = RemoveHtml($this->refno->caption());

		// currcode
		$this->currcode->EditAttrs["class"] = "form-control";
		$this->currcode->EditCustomAttributes = "";
		if (!$this->currcode->Raw)
			$this->currcode->CurrentValue = HtmlDecode($this->currcode->CurrentValue);
		$this->currcode->EditValue = $this->currcode->CurrentValue;
		$this->currcode->PlaceHolder = RemoveHtml($this->currcode->caption());

		// amount
		$this->amount->EditAttrs["class"] = "form-control";
		$this->amount->EditCustomAttributes = "";
		$this->amount->EditValue = $this->amount->CurrentValue;
		$this->amount->PlaceHolder = RemoveHtml($this->amount->caption());
		if (strval($this->amount->EditValue) != "" && is_numeric($this->amount->EditValue))
			$this->amount->EditValue = FormatNumber($this->amount->EditValue, -2, -1, -2, 0);
		

		// balance
		$this->balance->EditAttrs["class"] = "form-control";
		$this->balance->EditCustomAttributes = "";
		$this->balance->EditValue = $this->balance->CurrentValue;
		$this->balance->PlaceHolder = RemoveHtml($this->balance->caption());
		if (strval($this->balance->EditValue) != "" && is_numeric($this->balance->EditValue))
			$this->balance->EditValue = FormatNumber($this->balance->EditValue, -2, -1, -2, 0);
		

		// confcode
		$this->confcode->EditAttrs["class"] = "form-control";
		$this->confcode->EditCustomAttributes = "";
		if (!$this->confcode->Raw)
			$this->confcode->CurrentValue = HtmlDecode($this->confcode->CurrentValue);
		$this->confcode->EditValue = $this->confcode->CurrentValue;
		$this->confcode->PlaceHolder = RemoveHtml($this->confcode->caption());

		// success
		$this->success->EditAttrs["class"] = "form-control";
		$this->success->EditCustomAttributes = "";
		$this->success->EditValue = $this->success->options(TRUE);

		// userid
		$this->_userid->EditAttrs["class"] = "form-control";
		$this->_userid->EditCustomAttributes = "";
		$this->_userid->EditValue = $this->_userid->CurrentValue;
		$this->_userid->PlaceHolder = RemoveHtml($this->_userid->caption());

		// billerresponse
		$this->billerresponse->EditAttrs["class"] = "form-control";
		$this->billerresponse->EditCustomAttributes = "";
		$this->billerresponse->EditValue = $this->billerresponse->CurrentValue;
		$this->billerresponse->PlaceHolder = RemoveHtml($this->billerresponse->caption());

		// paymenttype
		$this->paymenttype->EditAttrs["class"] = "form-control";
		$this->paymenttype->EditCustomAttributes = "";
		$this->paymenttype->EditValue = $this->paymenttype->options(TRUE);

		// customername
		$this->customername->EditAttrs["class"] = "form-control";
		$this->customername->EditCustomAttributes = "";
		if (!$this->customername->Raw)
			$this->customername->CurrentValue = HtmlDecode($this->customername->CurrentValue);
		$this->customername->EditValue = $this->customername->CurrentValue;
		$this->customername->PlaceHolder = RemoveHtml($this->customername->caption());

		// parentuserid
		$this->parentuserid->EditAttrs["class"] = "form-control";
		$this->parentuserid->EditCustomAttributes = "";
		$this->parentuserid->EditValue = $this->parentuserid->CurrentValue;
		$this->parentuserid->PlaceHolder = RemoveHtml($this->parentuserid->caption());

		// businessname
		$this->businessname->EditAttrs["class"] = "form-control";
		$this->businessname->EditCustomAttributes = "";
		if (!$this->businessname->Raw)
			$this->businessname->CurrentValue = HtmlDecode($this->businessname->CurrentValue);
		$this->businessname->EditValue = $this->businessname->CurrentValue;
		$this->businessname->PlaceHolder = RemoveHtml($this->businessname->caption());

		// businessphoneno
		$this->businessphoneno->EditAttrs["class"] = "form-control";
		$this->businessphoneno->EditCustomAttributes = "";
		if (!$this->businessphoneno->Raw)
			$this->businessphoneno->CurrentValue = HtmlDecode($this->businessphoneno->CurrentValue);
		$this->businessphoneno->EditValue = $this->businessphoneno->CurrentValue;
		$this->businessphoneno->PlaceHolder = RemoveHtml($this->businessphoneno->caption());

		// businessaddress1
		$this->businessaddress1->EditAttrs["class"] = "form-control";
		$this->businessaddress1->EditCustomAttributes = "";
		if (!$this->businessaddress1->Raw)
			$this->businessaddress1->CurrentValue = HtmlDecode($this->businessaddress1->CurrentValue);
		$this->businessaddress1->EditValue = $this->businessaddress1->CurrentValue;
		$this->businessaddress1->PlaceHolder = RemoveHtml($this->businessaddress1->caption());

		// businessaddress2
		$this->businessaddress2->EditAttrs["class"] = "form-control";
		$this->businessaddress2->EditCustomAttributes = "";
		if (!$this->businessaddress2->Raw)
			$this->businessaddress2->CurrentValue = HtmlDecode($this->businessaddress2->CurrentValue);
		$this->businessaddress2->EditValue = $this->businessaddress2->CurrentValue;
		$this->businessaddress2->PlaceHolder = RemoveHtml($this->businessaddress2->caption());

		// businesscity
		$this->businesscity->EditAttrs["class"] = "form-control";
		$this->businesscity->EditCustomAttributes = "";
		if (!$this->businesscity->Raw)
			$this->businesscity->CurrentValue = HtmlDecode($this->businesscity->CurrentValue);
		$this->businesscity->EditValue = $this->businesscity->CurrentValue;
		$this->businesscity->PlaceHolder = RemoveHtml($this->businesscity->caption());

		// businessstate
		$this->businessstate->EditAttrs["class"] = "form-control";
		$this->businessstate->EditCustomAttributes = "";
		if (!$this->businessstate->Raw)
			$this->businessstate->CurrentValue = HtmlDecode($this->businessstate->CurrentValue);
		$this->businessstate->EditValue = $this->businessstate->CurrentValue;
		$this->businessstate->PlaceHolder = RemoveHtml($this->businessstate->caption());

		// businesscountry
		$this->businesscountry->EditAttrs["class"] = "form-control";
		$this->businesscountry->EditCustomAttributes = "";
		if (!$this->businesscountry->Raw)
			$this->businesscountry->CurrentValue = HtmlDecode($this->businesscountry->CurrentValue);
		$this->businesscountry->EditValue = $this->businesscountry->CurrentValue;
		$this->businesscountry->PlaceHolder = RemoveHtml($this->businesscountry->caption());

		// feeid
		$this->feeid->EditAttrs["class"] = "form-control";
		$this->feeid->EditCustomAttributes = "";
		$this->feeid->EditValue = $this->feeid->CurrentValue;
		$this->feeid->PlaceHolder = RemoveHtml($this->feeid->caption());

		// tabletype
		$this->_tabletype->EditAttrs["class"] = "form-control";
		$this->_tabletype->EditCustomAttributes = "";
		$this->_tabletype->EditValue = $this->_tabletype->CurrentValue;
		$this->_tabletype->PlaceHolder = RemoveHtml($this->_tabletype->caption());

		// feemerchanttotal
		$this->feemerchanttotal->EditAttrs["class"] = "form-control";
		$this->feemerchanttotal->EditCustomAttributes = "";
		$this->feemerchanttotal->EditValue = $this->feemerchanttotal->CurrentValue;
		$this->feemerchanttotal->PlaceHolder = RemoveHtml($this->feemerchanttotal->caption());
		if (strval($this->feemerchanttotal->EditValue) != "" && is_numeric($this->feemerchanttotal->EditValue))
			$this->feemerchanttotal->EditValue = FormatNumber($this->feemerchanttotal->EditValue, -2, -2, -2, -2);
		

		// feeconsumertotal
		$this->feeconsumertotal->EditAttrs["class"] = "form-control";
		$this->feeconsumertotal->EditCustomAttributes = "";
		$this->feeconsumertotal->EditValue = $this->feeconsumertotal->CurrentValue;
		$this->feeconsumertotal->PlaceHolder = RemoveHtml($this->feeconsumertotal->caption());
		if (strval($this->feeconsumertotal->EditValue) != "" && is_numeric($this->feeconsumertotal->EditValue))
			$this->feeconsumertotal->EditValue = FormatNumber($this->feeconsumertotal->EditValue, -2, -2, -2, -2);
		

		// feesystemtotal
		$this->feesystemtotal->EditAttrs["class"] = "form-control";
		$this->feesystemtotal->EditCustomAttributes = "";
		$this->feesystemtotal->EditValue = $this->feesystemtotal->CurrentValue;
		$this->feesystemtotal->PlaceHolder = RemoveHtml($this->feesystemtotal->caption());
		if (strval($this->feesystemtotal->EditValue) != "" && is_numeric($this->feesystemtotal->EditValue))
			$this->feesystemtotal->EditValue = FormatNumber($this->feesystemtotal->EditValue, -2, -2, -2, -2);
		

		// feeexternaltotal
		$this->feeexternaltotal->EditAttrs["class"] = "form-control";
		$this->feeexternaltotal->EditCustomAttributes = "";
		$this->feeexternaltotal->EditValue = $this->feeexternaltotal->CurrentValue;
		$this->feeexternaltotal->PlaceHolder = RemoveHtml($this->feeexternaltotal->caption());
		if (strval($this->feeexternaltotal->EditValue) != "" && is_numeric($this->feeexternaltotal->EditValue))
			$this->feeexternaltotal->EditValue = FormatNumber($this->feeexternaltotal->EditValue, -2, -2, -2, -2);
		

		// feefranchiseetotal
		$this->feefranchiseetotal->EditAttrs["class"] = "form-control";
		$this->feefranchiseetotal->EditCustomAttributes = "";
		$this->feefranchiseetotal->EditValue = $this->feefranchiseetotal->CurrentValue;
		$this->feefranchiseetotal->PlaceHolder = RemoveHtml($this->feefranchiseetotal->caption());
		if (strval($this->feefranchiseetotal->EditValue) != "" && is_numeric($this->feefranchiseetotal->EditValue))
			$this->feefranchiseetotal->EditValue = FormatNumber($this->feefranchiseetotal->EditValue, -2, -2, -2, -2);
		

		// feeresellertotal
		$this->feeresellertotal->EditAttrs["class"] = "form-control";
		$this->feeresellertotal->EditCustomAttributes = "";
		$this->feeresellertotal->EditValue = $this->feeresellertotal->CurrentValue;
		$this->feeresellertotal->PlaceHolder = RemoveHtml($this->feeresellertotal->caption());
		if (strval($this->feeresellertotal->EditValue) != "" && is_numeric($this->feeresellertotal->EditValue))
			$this->feeresellertotal->EditValue = FormatNumber($this->feeresellertotal->EditValue, -2, -2, -2, -2);
		

		// officialdocnumber
		$this->officialdocnumber->EditAttrs["class"] = "form-control";
		$this->officialdocnumber->EditCustomAttributes = "";
		if (!$this->officialdocnumber->Raw)
			$this->officialdocnumber->CurrentValue = HtmlDecode($this->officialdocnumber->CurrentValue);
		$this->officialdocnumber->EditValue = $this->officialdocnumber->CurrentValue;
		$this->officialdocnumber->PlaceHolder = RemoveHtml($this->officialdocnumber->caption());

		// branchname
		$this->branchname->EditAttrs["class"] = "form-control";
		$this->branchname->EditCustomAttributes = "";
		if (!$this->branchname->Raw)
			$this->branchname->CurrentValue = HtmlDecode($this->branchname->CurrentValue);
		$this->branchname->EditValue = $this->branchname->CurrentValue;
		$this->branchname->PlaceHolder = RemoveHtml($this->branchname->caption());

		// clerkname
		$this->clerkname->EditAttrs["class"] = "form-control";
		$this->clerkname->EditCustomAttributes = "";
		if (!$this->clerkname->Raw)
			$this->clerkname->CurrentValue = HtmlDecode($this->clerkname->CurrentValue);
		$this->clerkname->EditValue = $this->clerkname->CurrentValue;
		$this->clerkname->PlaceHolder = RemoveHtml($this->clerkname->caption());

		// taxamount
		$this->taxamount->EditAttrs["class"] = "form-control";
		$this->taxamount->EditCustomAttributes = "";
		$this->taxamount->EditValue = $this->taxamount->CurrentValue;
		$this->taxamount->PlaceHolder = RemoveHtml($this->taxamount->caption());
		if (strval($this->taxamount->EditValue) != "" && is_numeric($this->taxamount->EditValue))
			$this->taxamount->EditValue = FormatNumber($this->taxamount->EditValue, -2, -2, -2, -2);
		

		// totalamount
		$this->totalamount->EditAttrs["class"] = "form-control";
		$this->totalamount->EditCustomAttributes = "";
		$this->totalamount->EditValue = $this->totalamount->CurrentValue;
		$this->totalamount->PlaceHolder = RemoveHtml($this->totalamount->caption());
		if (strval($this->totalamount->EditValue) != "" && is_numeric($this->totalamount->EditValue))
			$this->totalamount->EditValue = FormatNumber($this->totalamount->EditValue, -2, -2, -2, -2);
		

		// taxperc
		$this->taxperc->EditAttrs["class"] = "form-control";
		$this->taxperc->EditCustomAttributes = "";
		$this->taxperc->EditValue = $this->taxperc->CurrentValue;
		$this->taxperc->PlaceHolder = RemoveHtml($this->taxperc->caption());
		if (strval($this->taxperc->EditValue) != "" && is_numeric($this->taxperc->EditValue))
			$this->taxperc->EditValue = FormatNumber($this->taxperc->EditValue, -2, -2, -2, -2);
		

		// department
		$this->department->EditAttrs["class"] = "form-control";
		$this->department->EditCustomAttributes = "";

		// billingresponse2
		$this->billingresponse2->EditAttrs["class"] = "form-control";
		$this->billingresponse2->EditCustomAttributes = "";
		$this->billingresponse2->EditValue = $this->billingresponse2->CurrentValue;
		$this->billingresponse2->PlaceHolder = RemoveHtml($this->billingresponse2->caption());

		// purchaseid
		$this->purchaseid->EditAttrs["class"] = "form-control";
		$this->purchaseid->EditCustomAttributes = "";
		if ($this->purchaseid->getSessionValue() != "") {
			$this->purchaseid->CurrentValue = $this->purchaseid->getSessionValue();
			$this->purchaseid->ViewValue = $this->purchaseid->CurrentValue;
			$this->purchaseid->ViewValue = FormatNumber($this->purchaseid->ViewValue, 0, -2, -2, -2);
			$this->purchaseid->ViewCustomAttributes = "";
		} else {
			$this->purchaseid->EditValue = $this->purchaseid->CurrentValue;
			$this->purchaseid->PlaceHolder = RemoveHtml($this->purchaseid->caption());
		}

		// paymentid
		$this->paymentid->EditAttrs["class"] = "form-control";
		$this->paymentid->EditCustomAttributes = "";
		$this->paymentid->EditValue = $this->paymentid->CurrentValue;
		$this->paymentid->PlaceHolder = RemoveHtml($this->paymentid->caption());

		// transgroupid
		$this->transgroupid->EditAttrs["class"] = "form-control";
		$this->transgroupid->EditCustomAttributes = "";
		$this->transgroupid->EditValue = $this->transgroupid->CurrentValue;
		$this->transgroupid->PlaceHolder = RemoveHtml($this->transgroupid->caption());

		// otherdetails
		$this->otherdetails->EditAttrs["class"] = "form-control";
		$this->otherdetails->EditCustomAttributes = "";
		$this->otherdetails->EditValue = $this->otherdetails->CurrentValue;
		$this->otherdetails->PlaceHolder = RemoveHtml($this->otherdetails->caption());

		// Call Row Rendered event
		$this->Row_Rendered();
	}

	// Aggregate list row values
	public function aggregateListRowValues()
	{
	}

	// Aggregate list row (for rendering)
	public function aggregateListRow()
	{

		// Call Row Rendered event
		$this->Row_Rendered();
	}

	// Export data in HTML/CSV/Word/Excel/Email/PDF format
	public function exportDocument($doc, $recordset, $startRec = 1, $stopRec = 1, $exportPageType = "")
	{
		if (!$recordset || !$doc)
			return;
		if (!$doc->ExportCustom) {

			// Write header
			$doc->exportTableHeader();
			if ($doc->Horizontal) { // Horizontal format, write header
				$doc->beginExportRow();
				if ($exportPageType == "view") {
					$doc->exportCaption($this->recid);
					$doc->exportCaption($this->brokeremail);
					$doc->exportCaption($this->brokerid);
					$doc->exportCaption($this->transdate);
					$doc->exportCaption($this->serviceid);
					$doc->exportCaption($this->customeracctno);
					$doc->exportCaption($this->refno);
					$doc->exportCaption($this->currcode);
					$doc->exportCaption($this->amount);
					$doc->exportCaption($this->balance);
					$doc->exportCaption($this->confcode);
					$doc->exportCaption($this->success);
					$doc->exportCaption($this->_userid);
					$doc->exportCaption($this->billerresponse);
					$doc->exportCaption($this->paymenttype);
					$doc->exportCaption($this->customername);
					$doc->exportCaption($this->parentuserid);
					$doc->exportCaption($this->businessname);
					$doc->exportCaption($this->businessphoneno);
					$doc->exportCaption($this->businessaddress1);
					$doc->exportCaption($this->businessaddress2);
					$doc->exportCaption($this->businesscity);
					$doc->exportCaption($this->businessstate);
					$doc->exportCaption($this->businesscountry);
					$doc->exportCaption($this->feeid);
					$doc->exportCaption($this->_tabletype);
					$doc->exportCaption($this->feemerchanttotal);
					$doc->exportCaption($this->feeconsumertotal);
					$doc->exportCaption($this->feesystemtotal);
					$doc->exportCaption($this->feeexternaltotal);
					$doc->exportCaption($this->feefranchiseetotal);
					$doc->exportCaption($this->feeresellertotal);
					$doc->exportCaption($this->officialdocnumber);
					$doc->exportCaption($this->branchname);
					$doc->exportCaption($this->clerkname);
					$doc->exportCaption($this->taxamount);
					$doc->exportCaption($this->totalamount);
					$doc->exportCaption($this->taxperc);
					$doc->exportCaption($this->department);
					$doc->exportCaption($this->billingresponse2);
					$doc->exportCaption($this->purchaseid);
					$doc->exportCaption($this->paymentid);
					$doc->exportCaption($this->transgroupid);
					$doc->exportCaption($this->otherdetails);
				} else {
					$doc->exportCaption($this->recid);
					$doc->exportCaption($this->brokeremail);
					$doc->exportCaption($this->brokerid);
					$doc->exportCaption($this->transdate);
					$doc->exportCaption($this->serviceid);
					$doc->exportCaption($this->customeracctno);
					$doc->exportCaption($this->refno);
					$doc->exportCaption($this->currcode);
					$doc->exportCaption($this->amount);
					$doc->exportCaption($this->balance);
					$doc->exportCaption($this->confcode);
					$doc->exportCaption($this->success);
					$doc->exportCaption($this->_userid);
					$doc->exportCaption($this->paymenttype);
					$doc->exportCaption($this->customername);
					$doc->exportCaption($this->parentuserid);
					$doc->exportCaption($this->businessname);
					$doc->exportCaption($this->businessphoneno);
					$doc->exportCaption($this->businessaddress1);
					$doc->exportCaption($this->businessaddress2);
					$doc->exportCaption($this->businesscity);
					$doc->exportCaption($this->businessstate);
					$doc->exportCaption($this->businesscountry);
					$doc->exportCaption($this->feeid);
					$doc->exportCaption($this->_tabletype);
					$doc->exportCaption($this->feemerchanttotal);
					$doc->exportCaption($this->feeconsumertotal);
					$doc->exportCaption($this->feesystemtotal);
					$doc->exportCaption($this->feeexternaltotal);
					$doc->exportCaption($this->feefranchiseetotal);
					$doc->exportCaption($this->feeresellertotal);
					$doc->exportCaption($this->officialdocnumber);
					$doc->exportCaption($this->branchname);
					$doc->exportCaption($this->clerkname);
					$doc->exportCaption($this->taxamount);
					$doc->exportCaption($this->totalamount);
					$doc->exportCaption($this->taxperc);
					$doc->exportCaption($this->department);
					$doc->exportCaption($this->purchaseid);
					$doc->exportCaption($this->paymentid);
					$doc->exportCaption($this->transgroupid);
				}
				$doc->endExportRow();
			}
		}

		// Move to first record
		$recCnt = $startRec - 1;
		if (!$recordset->EOF) {
			$recordset->moveFirst();
			if ($startRec > 1)
				$recordset->move($startRec - 1);
		}
		while (!$recordset->EOF && $recCnt < $stopRec) {
			$recCnt++;
			if ($recCnt >= $startRec) {
				$rowCnt = $recCnt - $startRec + 1;

				// Page break
				if ($this->ExportPageBreakCount > 0) {
					if ($rowCnt > 1 && ($rowCnt - 1) % $this->ExportPageBreakCount == 0)
						$doc->exportPageBreak();
				}
				$this->loadListRowValues($recordset);

				// Render row
				$this->RowType = ROWTYPE_VIEW; // Render view
				$this->resetAttributes();
				$this->renderListRow();
				if (!$doc->ExportCustom) {
					$doc->beginExportRow($rowCnt); // Allow CSS styles if enabled
					if ($exportPageType == "view") {
						$doc->exportField($this->recid);
						$doc->exportField($this->brokeremail);
						$doc->exportField($this->brokerid);
						$doc->exportField($this->transdate);
						$doc->exportField($this->serviceid);
						$doc->exportField($this->customeracctno);
						$doc->exportField($this->refno);
						$doc->exportField($this->currcode);
						$doc->exportField($this->amount);
						$doc->exportField($this->balance);
						$doc->exportField($this->confcode);
						$doc->exportField($this->success);
						$doc->exportField($this->_userid);
						$doc->exportField($this->billerresponse);
						$doc->exportField($this->paymenttype);
						$doc->exportField($this->customername);
						$doc->exportField($this->parentuserid);
						$doc->exportField($this->businessname);
						$doc->exportField($this->businessphoneno);
						$doc->exportField($this->businessaddress1);
						$doc->exportField($this->businessaddress2);
						$doc->exportField($this->businesscity);
						$doc->exportField($this->businessstate);
						$doc->exportField($this->businesscountry);
						$doc->exportField($this->feeid);
						$doc->exportField($this->_tabletype);
						$doc->exportField($this->feemerchanttotal);
						$doc->exportField($this->feeconsumertotal);
						$doc->exportField($this->feesystemtotal);
						$doc->exportField($this->feeexternaltotal);
						$doc->exportField($this->feefranchiseetotal);
						$doc->exportField($this->feeresellertotal);
						$doc->exportField($this->officialdocnumber);
						$doc->exportField($this->branchname);
						$doc->exportField($this->clerkname);
						$doc->exportField($this->taxamount);
						$doc->exportField($this->totalamount);
						$doc->exportField($this->taxperc);
						$doc->exportField($this->department);
						$doc->exportField($this->billingresponse2);
						$doc->exportField($this->purchaseid);
						$doc->exportField($this->paymentid);
						$doc->exportField($this->transgroupid);
						$doc->exportField($this->otherdetails);
					} else {
						$doc->exportField($this->recid);
						$doc->exportField($this->brokeremail);
						$doc->exportField($this->brokerid);
						$doc->exportField($this->transdate);
						$doc->exportField($this->serviceid);
						$doc->exportField($this->customeracctno);
						$doc->exportField($this->refno);
						$doc->exportField($this->currcode);
						$doc->exportField($this->amount);
						$doc->exportField($this->balance);
						$doc->exportField($this->confcode);
						$doc->exportField($this->success);
						$doc->exportField($this->_userid);
						$doc->exportField($this->paymenttype);
						$doc->exportField($this->customername);
						$doc->exportField($this->parentuserid);
						$doc->exportField($this->businessname);
						$doc->exportField($this->businessphoneno);
						$doc->exportField($this->businessaddress1);
						$doc->exportField($this->businessaddress2);
						$doc->exportField($this->businesscity);
						$doc->exportField($this->businessstate);
						$doc->exportField($this->businesscountry);
						$doc->exportField($this->feeid);
						$doc->exportField($this->_tabletype);
						$doc->exportField($this->feemerchanttotal);
						$doc->exportField($this->feeconsumertotal);
						$doc->exportField($this->feesystemtotal);
						$doc->exportField($this->feeexternaltotal);
						$doc->exportField($this->feefranchiseetotal);
						$doc->exportField($this->feeresellertotal);
						$doc->exportField($this->officialdocnumber);
						$doc->exportField($this->branchname);
						$doc->exportField($this->clerkname);
						$doc->exportField($this->taxamount);
						$doc->exportField($this->totalamount);
						$doc->exportField($this->taxperc);
						$doc->exportField($this->department);
						$doc->exportField($this->purchaseid);
						$doc->exportField($this->paymentid);
						$doc->exportField($this->transgroupid);
					}
					$doc->endExportRow($rowCnt);
				}
			}

			// Call Row Export server event
			if ($doc->ExportCustom)
				$this->Row_Export($recordset->fields);
			$recordset->moveNext();
		}
		if (!$doc->ExportCustom) {
			$doc->exportTableFooter();
		}
	}

	// Get file data
	public function getFileData($fldparm, $key, $resize, $width = 0, $height = 0)
	{

		// No binary fields
		return FALSE;
	}

	// Table level events
	// Recordset Selecting event
	function Recordset_Selecting(&$filter) {

		// Enter your code here
	}

	// Recordset Selected event
	function Recordset_Selected(&$rs) {

		//echo "Recordset Selected";
	}

	// Recordset Search Validated event
	function Recordset_SearchValidated() {

		// Example:
		//$this->MyField1->AdvancedSearch->SearchValue = "your search criteria"; // Search value

	}

	// Recordset Searching event
	function Recordset_Searching(&$filter) {

		// Enter your code here
	}

	// Row_Selecting event
	function Row_Selecting(&$filter) {

		// Enter your code here
	}

	// Row Selected event
	function Row_Selected(&$rs) {

		//echo "Row Selected";
	}

	// Row Inserting event
	function Row_Inserting($rsold, &$rsnew) {

		// Enter your code here
		// To cancel, set return value to FALSE

		return TRUE;
	}

	// Row Inserted event
	function Row_Inserted($rsold, &$rsnew) {

		//echo "Row Inserted"
	}

	// Row Updating event
	function Row_Updating($rsold, &$rsnew) {

		// Enter your code here
		// To cancel, set return value to FALSE

		return TRUE;
	}

	// Row Updated event
	function Row_Updated($rsold, &$rsnew) {

		//echo "Row Updated";
	}

	// Row Update Conflict event
	function Row_UpdateConflict($rsold, &$rsnew) {

		// Enter your code here
		// To ignore conflict, set return value to FALSE

		return TRUE;
	}

	// Grid Inserting event
	function Grid_Inserting() {

		// Enter your code here
		// To reject grid insert, set return value to FALSE

		return TRUE;
	}

	// Grid Inserted event
	function Grid_Inserted($rsnew) {

		//echo "Grid Inserted";
	}

	// Grid Updating event
	function Grid_Updating($rsold) {

		// Enter your code here
		// To reject grid update, set return value to FALSE

		return TRUE;
	}

	// Grid Updated event
	function Grid_Updated($rsold, $rsnew) {

		//echo "Grid Updated";
	}

	// Row Deleting event
	function Row_Deleting(&$rs) {

		// Enter your code here
		// To cancel, set return value to False

		return TRUE;
	}

	// Row Deleted event
	function Row_Deleted(&$rs) {

		//echo "Row Deleted";
	}

	// Email Sending event
	function Email_Sending($email, &$args) {

		//var_dump($email); var_dump($args); exit();
		return TRUE;
	}

	// Lookup Selecting event
	function Lookup_Selecting($fld, &$filter) {

		//var_dump($fld->Name, $fld->Lookup, $filter); // Uncomment to view the filter
		// Enter your code here

	}

	// Row Rendering event
	function Row_Rendering() {

		// Enter your code here
	}

	// Row Rendered event
	function Row_Rendered() {

		// To view properties of field class, use:
		//var_dump($this-><FieldName>);

	}

	// User ID Filtering event
	function UserID_Filtering(&$filter) {

		// Enter your code here
	}
}
?>