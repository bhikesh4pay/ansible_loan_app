<?php namespace PHPMaker2020\_4payadmin; ?>
<?php

/**
 * Table class for timezone
 */
class timezone extends DbTable
{
	protected $SqlFrom = "";
	protected $SqlSelect = "";
	protected $SqlSelectList = "";
	protected $SqlWhere = "";
	protected $SqlGroupBy = "";
	protected $SqlHaving = "";
	protected $SqlOrderBy = "";
	public $UseSessionForListSql = TRUE;

	// Column CSS classes
	public $LeftColumnClass = "col-sm-2 col-form-label ew-label";
	public $RightColumnClass = "col-sm-10";
	public $OffsetColumnClass = "col-sm-10 offset-sm-2";
	public $TableLeftColumnClass = "w-col-2";

	// Export
	public $ExportDoc;

	// Fields
	public $timeZoneID;
	public $name;
	public $abbreviationNormal;
	public $abbreviationDST;
	public $normalDifferenceWithGMT;
	public $dstDifferenceWithGMT;
	public $effectiveDateTimeInGMT;
	public $endDateTimeINGMT;

	// Constructor
	public function __construct()
	{
		global $Language, $CurrentLanguage;
		parent::__construct();

		// Language object
		if (!isset($Language))
			$Language = new Language();
		$this->TableVar = 'timezone';
		$this->TableName = 'timezone';
		$this->TableType = 'LINKTABLE';

		// Update Table
		$this->UpdateTable = "`timezone`";
		$this->Dbid = '_4payreference';
		$this->ExportAll = TRUE;
		$this->ExportPageBreakCount = 0; // Page break per every n record (PDF only)
		$this->ExportPageOrientation = "portrait"; // Page orientation (PDF only)
		$this->ExportPageSize = "a4"; // Page size (PDF only)
		$this->ExportExcelPageOrientation = \PhpOffice\PhpSpreadsheet\Worksheet\PageSetup::ORIENTATION_DEFAULT; // Page orientation (PhpSpreadsheet only)
		$this->ExportExcelPageSize = \PhpOffice\PhpSpreadsheet\Worksheet\PageSetup::PAPERSIZE_A4; // Page size (PhpSpreadsheet only)
		$this->ExportWordPageOrientation = "portrait"; // Page orientation (PHPWord only)
		$this->ExportWordColumnWidth = NULL; // Cell width (PHPWord only)
		$this->DetailAdd = FALSE; // Allow detail add
		$this->DetailEdit = FALSE; // Allow detail edit
		$this->DetailView = FALSE; // Allow detail view
		$this->ShowMultipleDetails = FALSE; // Show multiple details
		$this->GridAddRowCount = 5;
		$this->AllowAddDeleteRow = TRUE; // Allow add/delete row
		$this->UserIDAllowSecurity = Config("DEFAULT_USER_ID_ALLOW_SECURITY"); // Default User ID allowed permissions
		$this->BasicSearch = new BasicSearch($this->TableVar);

		// timeZoneID
		$this->timeZoneID = new DbField('timezone', 'timezone', 'x_timeZoneID', 'timeZoneID', '`timeZoneID`', '`timeZoneID`', 3, 3, -1, FALSE, '`timeZoneID`', FALSE, FALSE, FALSE, 'FORMATTED TEXT', 'TEXT');
		$this->timeZoneID->IsPrimaryKey = TRUE; // Primary key field
		$this->timeZoneID->Nullable = FALSE; // NOT NULL field
		$this->timeZoneID->Required = TRUE; // Required field
		$this->timeZoneID->Sortable = TRUE; // Allow sort
		$this->timeZoneID->DefaultErrorMessage = $Language->phrase("IncorrectInteger");
		$this->fields['timeZoneID'] = &$this->timeZoneID;

		// name
		$this->name = new DbField('timezone', 'timezone', 'x_name', 'name', '`name`', '`name`', 200, 60, -1, FALSE, '`name`', FALSE, FALSE, FALSE, 'FORMATTED TEXT', 'TEXT');
		$this->name->Nullable = FALSE; // NOT NULL field
		$this->name->Required = TRUE; // Required field
		$this->name->Sortable = TRUE; // Allow sort
		$this->fields['name'] = &$this->name;

		// abbreviationNormal
		$this->abbreviationNormal = new DbField('timezone', 'timezone', 'x_abbreviationNormal', 'abbreviationNormal', '`abbreviationNormal`', '`abbreviationNormal`', 200, 3, -1, FALSE, '`abbreviationNormal`', FALSE, FALSE, FALSE, 'FORMATTED TEXT', 'TEXT');
		$this->abbreviationNormal->Nullable = FALSE; // NOT NULL field
		$this->abbreviationNormal->Required = TRUE; // Required field
		$this->abbreviationNormal->Sortable = TRUE; // Allow sort
		$this->fields['abbreviationNormal'] = &$this->abbreviationNormal;

		// abbreviationDST
		$this->abbreviationDST = new DbField('timezone', 'timezone', 'x_abbreviationDST', 'abbreviationDST', '`abbreviationDST`', '`abbreviationDST`', 200, 3, -1, FALSE, '`abbreviationDST`', FALSE, FALSE, FALSE, 'FORMATTED TEXT', 'TEXT');
		$this->abbreviationDST->Nullable = FALSE; // NOT NULL field
		$this->abbreviationDST->Required = TRUE; // Required field
		$this->abbreviationDST->Sortable = TRUE; // Allow sort
		$this->fields['abbreviationDST'] = &$this->abbreviationDST;

		// normalDifferenceWithGMT
		$this->normalDifferenceWithGMT = new DbField('timezone', 'timezone', 'x_normalDifferenceWithGMT', 'normalDifferenceWithGMT', '`normalDifferenceWithGMT`', '`normalDifferenceWithGMT`', 131, 4, -1, FALSE, '`normalDifferenceWithGMT`', FALSE, FALSE, FALSE, 'FORMATTED TEXT', 'TEXT');
		$this->normalDifferenceWithGMT->Nullable = FALSE; // NOT NULL field
		$this->normalDifferenceWithGMT->Required = TRUE; // Required field
		$this->normalDifferenceWithGMT->Sortable = TRUE; // Allow sort
		$this->normalDifferenceWithGMT->DefaultErrorMessage = $Language->phrase("IncorrectFloat");
		$this->fields['normalDifferenceWithGMT'] = &$this->normalDifferenceWithGMT;

		// dstDifferenceWithGMT
		$this->dstDifferenceWithGMT = new DbField('timezone', 'timezone', 'x_dstDifferenceWithGMT', 'dstDifferenceWithGMT', '`dstDifferenceWithGMT`', '`dstDifferenceWithGMT`', 131, 4, -1, FALSE, '`dstDifferenceWithGMT`', FALSE, FALSE, FALSE, 'FORMATTED TEXT', 'TEXT');
		$this->dstDifferenceWithGMT->Nullable = FALSE; // NOT NULL field
		$this->dstDifferenceWithGMT->Required = TRUE; // Required field
		$this->dstDifferenceWithGMT->Sortable = TRUE; // Allow sort
		$this->dstDifferenceWithGMT->DefaultErrorMessage = $Language->phrase("IncorrectFloat");
		$this->fields['dstDifferenceWithGMT'] = &$this->dstDifferenceWithGMT;

		// effectiveDateTimeInGMT
		$this->effectiveDateTimeInGMT = new DbField('timezone', 'timezone', 'x_effectiveDateTimeInGMT', 'effectiveDateTimeInGMT', '`effectiveDateTimeInGMT`', CastDateFieldForLike("`effectiveDateTimeInGMT`", 0, "_4payreference"), 135, 19, 0, FALSE, '`effectiveDateTimeInGMT`', FALSE, FALSE, FALSE, 'FORMATTED TEXT', 'TEXT');
		$this->effectiveDateTimeInGMT->Nullable = FALSE; // NOT NULL field
		$this->effectiveDateTimeInGMT->Required = TRUE; // Required field
		$this->effectiveDateTimeInGMT->Sortable = TRUE; // Allow sort
		$this->effectiveDateTimeInGMT->DefaultErrorMessage = str_replace("%s", $GLOBALS["DATE_FORMAT"], $Language->phrase("IncorrectDate"));
		$this->fields['effectiveDateTimeInGMT'] = &$this->effectiveDateTimeInGMT;

		// endDateTimeINGMT
		$this->endDateTimeINGMT = new DbField('timezone', 'timezone', 'x_endDateTimeINGMT', 'endDateTimeINGMT', '`endDateTimeINGMT`', CastDateFieldForLike("`endDateTimeINGMT`", 0, "_4payreference"), 135, 19, 0, FALSE, '`endDateTimeINGMT`', FALSE, FALSE, FALSE, 'FORMATTED TEXT', 'TEXT');
		$this->endDateTimeINGMT->Nullable = FALSE; // NOT NULL field
		$this->endDateTimeINGMT->Required = TRUE; // Required field
		$this->endDateTimeINGMT->Sortable = TRUE; // Allow sort
		$this->endDateTimeINGMT->DefaultErrorMessage = str_replace("%s", $GLOBALS["DATE_FORMAT"], $Language->phrase("IncorrectDate"));
		$this->fields['endDateTimeINGMT'] = &$this->endDateTimeINGMT;
	}

	// Field Visibility
	public function getFieldVisibility($fldParm)
	{
		global $Security;
		return $this->$fldParm->Visible; // Returns original value
	}

	// Set left column class (must be predefined col-*-* classes of Bootstrap grid system)
	function setLeftColumnClass($class)
	{
		if (preg_match('/^col\-(\w+)\-(\d+)$/', $class, $match)) {
			$this->LeftColumnClass = $class . " col-form-label ew-label";
			$this->RightColumnClass = "col-" . $match[1] . "-" . strval(12 - (int)$match[2]);
			$this->OffsetColumnClass = $this->RightColumnClass . " " . str_replace("col-", "offset-", $class);
			$this->TableLeftColumnClass = preg_replace('/^col-\w+-(\d+)$/', "w-col-$1", $class); // Change to w-col-*
		}
	}

	// Single column sort
	public function updateSort(&$fld)
	{
		if ($this->CurrentOrder == $fld->Name) {
			$sortField = $fld->Expression;
			$lastSort = $fld->getSort();
			if ($this->CurrentOrderType == "ASC" || $this->CurrentOrderType == "DESC") {
				$thisSort = $this->CurrentOrderType;
			} else {
				$thisSort = ($lastSort == "ASC") ? "DESC" : "ASC";
			}
			$fld->setSort($thisSort);
			$this->setSessionOrderBy($sortField . " " . $thisSort); // Save to Session
		} else {
			$fld->setSort("");
		}
	}

	// Table level SQL
	public function getSqlFrom() // From
	{
		return ($this->SqlFrom != "") ? $this->SqlFrom : "`timezone`";
	}
	public function sqlFrom() // For backward compatibility
	{
		return $this->getSqlFrom();
	}
	public function setSqlFrom($v)
	{
		$this->SqlFrom = $v;
	}
	public function getSqlSelect() // Select
	{
		return ($this->SqlSelect != "") ? $this->SqlSelect : "SELECT * FROM " . $this->getSqlFrom();
	}
	public function sqlSelect() // For backward compatibility
	{
		return $this->getSqlSelect();
	}
	public function setSqlSelect($v)
	{
		$this->SqlSelect = $v;
	}
	public function getSqlWhere() // Where
	{
		$where = ($this->SqlWhere != "") ? $this->SqlWhere : "";
		$this->TableFilter = "";
		AddFilter($where, $this->TableFilter);
		return $where;
	}
	public function sqlWhere() // For backward compatibility
	{
		return $this->getSqlWhere();
	}
	public function setSqlWhere($v)
	{
		$this->SqlWhere = $v;
	}
	public function getSqlGroupBy() // Group By
	{
		return ($this->SqlGroupBy != "") ? $this->SqlGroupBy : "";
	}
	public function sqlGroupBy() // For backward compatibility
	{
		return $this->getSqlGroupBy();
	}
	public function setSqlGroupBy($v)
	{
		$this->SqlGroupBy = $v;
	}
	public function getSqlHaving() // Having
	{
		return ($this->SqlHaving != "") ? $this->SqlHaving : "";
	}
	public function sqlHaving() // For backward compatibility
	{
		return $this->getSqlHaving();
	}
	public function setSqlHaving($v)
	{
		$this->SqlHaving = $v;
	}
	public function getSqlOrderBy() // Order By
	{
		return ($this->SqlOrderBy != "") ? $this->SqlOrderBy : "";
	}
	public function sqlOrderBy() // For backward compatibility
	{
		return $this->getSqlOrderBy();
	}
	public function setSqlOrderBy($v)
	{
		$this->SqlOrderBy = $v;
	}

	// Apply User ID filters
	public function applyUserIDFilters($filter, $id = "")
	{
		return $filter;
	}

	// Check if User ID security allows view all
	public function userIDAllow($id = "")
	{
		$allow = $this->UserIDAllowSecurity;
		switch ($id) {
			case "add":
			case "copy":
			case "gridadd":
			case "register":
			case "addopt":
				return (($allow & 1) == 1);
			case "edit":
			case "gridedit":
			case "update":
			case "changepwd":
			case "forgotpwd":
				return (($allow & 4) == 4);
			case "delete":
				return (($allow & 2) == 2);
			case "view":
				return (($allow & 32) == 32);
			case "search":
				return (($allow & 64) == 64);
			case "lookup":
				return (($allow & 256) == 256);
			default:
				return (($allow & 8) == 8);
		}
	}

	// Get recordset
	public function getRecordset($sql, $rowcnt = -1, $offset = -1)
	{
		$conn = $this->getConnection();
		$conn->raiseErrorFn = Config("ERROR_FUNC");
		$rs = $conn->selectLimit($sql, $rowcnt, $offset);
		$conn->raiseErrorFn = "";
		return $rs;
	}

	// Get record count
	public function getRecordCount($sql, $c = NULL)
	{
		$cnt = -1;
		$rs = NULL;
		$sql = preg_replace('/\/\*BeginOrderBy\*\/[\s\S]+\/\*EndOrderBy\*\//', "", $sql); // Remove ORDER BY clause (MSSQL)
		$pattern = '/^SELECT\s([\s\S]+)\sFROM\s/i';

		// Skip Custom View / SubQuery / SELECT DISTINCT / ORDER BY
		if (($this->TableType == 'TABLE' || $this->TableType == 'VIEW' || $this->TableType == 'LINKTABLE') &&
			preg_match($pattern, $sql) && !preg_match('/\(\s*(SELECT[^)]+)\)/i', $sql) &&
			!preg_match('/^\s*select\s+distinct\s+/i', $sql) && !preg_match('/\s+order\s+by\s+/i', $sql)) {
			$sqlwrk = "SELECT COUNT(*) FROM " . preg_replace($pattern, "", $sql);
		} else {
			$sqlwrk = "SELECT COUNT(*) FROM (" . $sql . ") COUNT_TABLE";
		}
		$conn = $c ?: $this->getConnection();
		if ($rs = $conn->execute($sqlwrk)) {
			if (!$rs->EOF && $rs->FieldCount() > 0) {
				$cnt = $rs->fields[0];
				$rs->close();
			}
			return (int)$cnt;
		}

		// Unable to get count, get record count directly
		if ($rs = $conn->execute($sql)) {
			$cnt = $rs->RecordCount();
			$rs->close();
			return (int)$cnt;
		}
		return $cnt;
	}

	// Get SQL
	public function getSql($where, $orderBy = "")
	{
		return BuildSelectSql($this->getSqlSelect(), $this->getSqlWhere(),
			$this->getSqlGroupBy(), $this->getSqlHaving(), $this->getSqlOrderBy(),
			$where, $orderBy);
	}

	// Table SQL
	public function getCurrentSql()
	{
		$filter = $this->CurrentFilter;
		$filter = $this->applyUserIDFilters($filter);
		$sort = $this->getSessionOrderBy();
		return $this->getSql($filter, $sort);
	}

	// Table SQL with List page filter
	public function getListSql()
	{
		$filter = $this->UseSessionForListSql ? $this->getSessionWhere() : "";
		AddFilter($filter, $this->CurrentFilter);
		$filter = $this->applyUserIDFilters($filter);
		$this->Recordset_Selecting($filter);
		$select = $this->getSqlSelect();
		$sort = $this->UseSessionForListSql ? $this->getSessionOrderBy() : "";
		return BuildSelectSql($select, $this->getSqlWhere(), $this->getSqlGroupBy(),
			$this->getSqlHaving(), $this->getSqlOrderBy(), $filter, $sort);
	}

	// Get ORDER BY clause
	public function getOrderBy()
	{
		$sort = $this->getSessionOrderBy();
		return BuildSelectSql("", "", "", "", $this->getSqlOrderBy(), "", $sort);
	}

	// Get record count based on filter (for detail record count in master table pages)
	public function loadRecordCount($filter)
	{
		$origFilter = $this->CurrentFilter;
		$this->CurrentFilter = $filter;
		$this->Recordset_Selecting($this->CurrentFilter);
		$select = $this->TableType == 'CUSTOMVIEW' ? $this->getSqlSelect() : "SELECT * FROM " . $this->getSqlFrom();
		$groupBy = $this->TableType == 'CUSTOMVIEW' ? $this->getSqlGroupBy() : "";
		$having = $this->TableType == 'CUSTOMVIEW' ? $this->getSqlHaving() : "";
		$sql = BuildSelectSql($select, $this->getSqlWhere(), $groupBy, $having, "", $this->CurrentFilter, "");
		$cnt = $this->getRecordCount($sql);
		$this->CurrentFilter = $origFilter;
		return $cnt;
	}

	// Get record count (for current List page)
	public function listRecordCount()
	{
		$filter = $this->getSessionWhere();
		AddFilter($filter, $this->CurrentFilter);
		$filter = $this->applyUserIDFilters($filter);
		$this->Recordset_Selecting($filter);
		$select = $this->TableType == 'CUSTOMVIEW' ? $this->getSqlSelect() : "SELECT * FROM " . $this->getSqlFrom();
		$groupBy = $this->TableType == 'CUSTOMVIEW' ? $this->getSqlGroupBy() : "";
		$having = $this->TableType == 'CUSTOMVIEW' ? $this->getSqlHaving() : "";
		$sql = BuildSelectSql($select, $this->getSqlWhere(), $groupBy, $having, "", $filter, "");
		$cnt = $this->getRecordCount($sql);
		return $cnt;
	}

	// INSERT statement
	protected function insertSql(&$rs)
	{
		$names = "";
		$values = "";
		foreach ($rs as $name => $value) {
			if (!isset($this->fields[$name]) || $this->fields[$name]->IsCustom)
				continue;
			$names .= $this->fields[$name]->Expression . ",";
			$values .= QuotedValue($value, $this->fields[$name]->DataType, $this->Dbid) . ",";
		}
		$names = preg_replace('/,+$/', "", $names);
		$values = preg_replace('/,+$/', "", $values);
		return "INSERT INTO " . $this->UpdateTable . " (" . $names . ") VALUES (" . $values . ")";
	}

	// Insert
	public function insert(&$rs)
	{
		$conn = $this->getConnection();
		$success = $conn->execute($this->insertSql($rs));
		if ($success) {
		}
		return $success;
	}

	// UPDATE statement
	protected function updateSql(&$rs, $where = "", $curfilter = TRUE)
	{
		$sql = "UPDATE " . $this->UpdateTable . " SET ";
		foreach ($rs as $name => $value) {
			if (!isset($this->fields[$name]) || $this->fields[$name]->IsCustom || $this->fields[$name]->IsAutoIncrement)
				continue;
			$sql .= $this->fields[$name]->Expression . "=";
			$sql .= QuotedValue($value, $this->fields[$name]->DataType, $this->Dbid) . ",";
		}
		$sql = preg_replace('/,+$/', "", $sql);
		$filter = ($curfilter) ? $this->CurrentFilter : "";
		if (is_array($where))
			$where = $this->arrayToFilter($where);
		AddFilter($filter, $where);
		if ($filter != "")
			$sql .= " WHERE " . $filter;
		return $sql;
	}

	// Update
	public function update(&$rs, $where = "", $rsold = NULL, $curfilter = TRUE)
	{
		$conn = $this->getConnection();
		$success = $conn->execute($this->updateSql($rs, $where, $curfilter));
		return $success;
	}

	// DELETE statement
	protected function deleteSql(&$rs, $where = "", $curfilter = TRUE)
	{
		$sql = "DELETE FROM " . $this->UpdateTable . " WHERE ";
		if (is_array($where))
			$where = $this->arrayToFilter($where);
		if ($rs) {
			if (array_key_exists('timeZoneID', $rs))
				AddFilter($where, QuotedName('timeZoneID', $this->Dbid) . '=' . QuotedValue($rs['timeZoneID'], $this->timeZoneID->DataType, $this->Dbid));
		}
		$filter = ($curfilter) ? $this->CurrentFilter : "";
		AddFilter($filter, $where);
		if ($filter != "")
			$sql .= $filter;
		else
			$sql .= "0=1"; // Avoid delete
		return $sql;
	}

	// Delete
	public function delete(&$rs, $where = "", $curfilter = FALSE)
	{
		$success = TRUE;
		$conn = $this->getConnection();
		if ($success)
			$success = $conn->execute($this->deleteSql($rs, $where, $curfilter));
		return $success;
	}

	// Load DbValue from recordset or array
	protected function loadDbValues(&$rs)
	{
		if (!$rs || !is_array($rs) && $rs->EOF)
			return;
		$row = is_array($rs) ? $rs : $rs->fields;
		$this->timeZoneID->DbValue = $row['timeZoneID'];
		$this->name->DbValue = $row['name'];
		$this->abbreviationNormal->DbValue = $row['abbreviationNormal'];
		$this->abbreviationDST->DbValue = $row['abbreviationDST'];
		$this->normalDifferenceWithGMT->DbValue = $row['normalDifferenceWithGMT'];
		$this->dstDifferenceWithGMT->DbValue = $row['dstDifferenceWithGMT'];
		$this->effectiveDateTimeInGMT->DbValue = $row['effectiveDateTimeInGMT'];
		$this->endDateTimeINGMT->DbValue = $row['endDateTimeINGMT'];
	}

	// Delete uploaded files
	public function deleteUploadedFiles($row)
	{
		$this->loadDbValues($row);
	}

	// Record filter WHERE clause
	protected function sqlKeyFilter()
	{
		return "`timeZoneID` = @timeZoneID@";
	}

	// Get record filter
	public function getRecordFilter($row = NULL)
	{
		$keyFilter = $this->sqlKeyFilter();
		if (is_array($row))
			$val = array_key_exists('timeZoneID', $row) ? $row['timeZoneID'] : NULL;
		else
			$val = $this->timeZoneID->OldValue !== NULL ? $this->timeZoneID->OldValue : $this->timeZoneID->CurrentValue;
		if (!is_numeric($val))
			return "0=1"; // Invalid key
		if ($val == NULL)
			return "0=1"; // Invalid key
		else
			$keyFilter = str_replace("@timeZoneID@", AdjustSql($val, $this->Dbid), $keyFilter); // Replace key value
		return $keyFilter;
	}

	// Return page URL
	public function getReturnUrl()
	{
		$name = PROJECT_NAME . "_" . $this->TableVar . "_" . Config("TABLE_RETURN_URL");

		// Get referer URL automatically
		if (ServerVar("HTTP_REFERER") != "" && ReferPageName() != CurrentPageName() && ReferPageName() != "login.php") // Referer not same page or login page
			$_SESSION[$name] = ServerVar("HTTP_REFERER"); // Save to Session
		if (@$_SESSION[$name] != "") {
			return $_SESSION[$name];
		} else {
			return "timezonelist.php";
		}
	}
	public function setReturnUrl($v)
	{
		$_SESSION[PROJECT_NAME . "_" . $this->TableVar . "_" . Config("TABLE_RETURN_URL")] = $v;
	}

	// Get modal caption
	public function getModalCaption($pageName)
	{
		global $Language;
		if ($pageName == "timezoneview.php")
			return $Language->phrase("View");
		elseif ($pageName == "timezoneedit.php")
			return $Language->phrase("Edit");
		elseif ($pageName == "timezoneadd.php")
			return $Language->phrase("Add");
		else
			return "";
	}

	// List URL
	public function getListUrl()
	{
		return "timezonelist.php";
	}

	// View URL
	public function getViewUrl($parm = "")
	{
		if ($parm != "")
			$url = $this->keyUrl("timezoneview.php", $this->getUrlParm($parm));
		else
			$url = $this->keyUrl("timezoneview.php", $this->getUrlParm(Config("TABLE_SHOW_DETAIL") . "="));
		return $this->addMasterUrl($url);
	}

	// Add URL
	public function getAddUrl($parm = "")
	{
		if ($parm != "")
			$url = "timezoneadd.php?" . $this->getUrlParm($parm);
		else
			$url = "timezoneadd.php";
		return $this->addMasterUrl($url);
	}

	// Edit URL
	public function getEditUrl($parm = "")
	{
		$url = $this->keyUrl("timezoneedit.php", $this->getUrlParm($parm));
		return $this->addMasterUrl($url);
	}

	// Inline edit URL
	public function getInlineEditUrl()
	{
		$url = $this->keyUrl(CurrentPageName(), $this->getUrlParm("action=edit"));
		return $this->addMasterUrl($url);
	}

	// Copy URL
	public function getCopyUrl($parm = "")
	{
		$url = $this->keyUrl("timezoneadd.php", $this->getUrlParm($parm));
		return $this->addMasterUrl($url);
	}

	// Inline copy URL
	public function getInlineCopyUrl()
	{
		$url = $this->keyUrl(CurrentPageName(), $this->getUrlParm("action=copy"));
		return $this->addMasterUrl($url);
	}

	// Delete URL
	public function getDeleteUrl()
	{
		return $this->keyUrl("timezonedelete.php", $this->getUrlParm());
	}

	// Add master url
	public function addMasterUrl($url)
	{
		return $url;
	}
	public function keyToJson($htmlEncode = FALSE)
	{
		$json = "";
		$json .= "timeZoneID:" . JsonEncode($this->timeZoneID->CurrentValue, "number");
		$json = "{" . $json . "}";
		if ($htmlEncode)
			$json = HtmlEncode($json);
		return $json;
	}

	// Add key value to URL
	public function keyUrl($url, $parm = "")
	{
		$url = $url . "?";
		if ($parm != "")
			$url .= $parm . "&";
		if ($this->timeZoneID->CurrentValue != NULL) {
			$url .= "timeZoneID=" . urlencode($this->timeZoneID->CurrentValue);
		} else {
			return "javascript:ew.alert(ew.language.phrase('InvalidRecord'));";
		}
		return $url;
	}

	// Sort URL
	public function sortUrl(&$fld)
	{
		if ($this->CurrentAction || $this->isExport() ||
			in_array($fld->Type, [128, 204, 205])) { // Unsortable data type
				return "";
		} elseif ($fld->Sortable) {
			$urlParm = $this->getUrlParm("order=" . urlencode($fld->Name) . "&amp;ordertype=" . $fld->reverseSort());
			return $this->addMasterUrl(CurrentPageName() . "?" . $urlParm);
		} else {
			return "";
		}
	}

	// Get record keys from Post/Get/Session
	public function getRecordKeys()
	{
		$arKeys = [];
		$arKey = [];
		if (Param("key_m") !== NULL) {
			$arKeys = Param("key_m");
			$cnt = count($arKeys);
		} else {
			if (Param("timeZoneID") !== NULL)
				$arKeys[] = Param("timeZoneID");
			elseif (IsApi() && Key(0) !== NULL)
				$arKeys[] = Key(0);
			elseif (IsApi() && Route(2) !== NULL)
				$arKeys[] = Route(2);
			else
				$arKeys = NULL; // Do not setup

			//return $arKeys; // Do not return yet, so the values will also be checked by the following code
		}

		// Check keys
		$ar = [];
		if (is_array($arKeys)) {
			foreach ($arKeys as $key) {
				if (!is_numeric($key))
					continue;
				$ar[] = $key;
			}
		}
		return $ar;
	}

	// Get filter from record keys
	public function getFilterFromRecordKeys($setCurrent = TRUE)
	{
		$arKeys = $this->getRecordKeys();
		$keyFilter = "";
		foreach ($arKeys as $key) {
			if ($keyFilter != "") $keyFilter .= " OR ";
			if ($setCurrent)
				$this->timeZoneID->CurrentValue = $key;
			else
				$this->timeZoneID->OldValue = $key;
			$keyFilter .= "(" . $this->getRecordFilter() . ")";
		}
		return $keyFilter;
	}

	// Load rows based on filter
	public function &loadRs($filter)
	{

		// Set up filter (WHERE Clause)
		$sql = $this->getSql($filter);
		$conn = $this->getConnection();
		$rs = $conn->execute($sql);
		return $rs;
	}

	// Load row values from recordset
	public function loadListRowValues(&$rs)
	{
		$this->timeZoneID->setDbValue($rs->fields('timeZoneID'));
		$this->name->setDbValue($rs->fields('name'));
		$this->abbreviationNormal->setDbValue($rs->fields('abbreviationNormal'));
		$this->abbreviationDST->setDbValue($rs->fields('abbreviationDST'));
		$this->normalDifferenceWithGMT->setDbValue($rs->fields('normalDifferenceWithGMT'));
		$this->dstDifferenceWithGMT->setDbValue($rs->fields('dstDifferenceWithGMT'));
		$this->effectiveDateTimeInGMT->setDbValue($rs->fields('effectiveDateTimeInGMT'));
		$this->endDateTimeINGMT->setDbValue($rs->fields('endDateTimeINGMT'));
	}

	// Render list row values
	public function renderListRow()
	{
		global $Security, $CurrentLanguage, $Language;

		// Call Row Rendering event
		$this->Row_Rendering();

		// Common render codes
		// timeZoneID
		// name
		// abbreviationNormal
		// abbreviationDST
		// normalDifferenceWithGMT
		// dstDifferenceWithGMT
		// effectiveDateTimeInGMT
		// endDateTimeINGMT
		// timeZoneID

		$this->timeZoneID->ViewValue = $this->timeZoneID->CurrentValue;
		$this->timeZoneID->ViewCustomAttributes = "";

		// name
		$this->name->ViewValue = $this->name->CurrentValue;
		$this->name->ViewCustomAttributes = "";

		// abbreviationNormal
		$this->abbreviationNormal->ViewValue = $this->abbreviationNormal->CurrentValue;
		$this->abbreviationNormal->ViewCustomAttributes = "";

		// abbreviationDST
		$this->abbreviationDST->ViewValue = $this->abbreviationDST->CurrentValue;
		$this->abbreviationDST->ViewCustomAttributes = "";

		// normalDifferenceWithGMT
		$this->normalDifferenceWithGMT->ViewValue = $this->normalDifferenceWithGMT->CurrentValue;
		$this->normalDifferenceWithGMT->ViewValue = FormatNumber($this->normalDifferenceWithGMT->ViewValue, Config("DEFAULT_DECIMAL_PRECISION"));
		$this->normalDifferenceWithGMT->ViewCustomAttributes = "";

		// dstDifferenceWithGMT
		$this->dstDifferenceWithGMT->ViewValue = $this->dstDifferenceWithGMT->CurrentValue;
		$this->dstDifferenceWithGMT->ViewValue = FormatNumber($this->dstDifferenceWithGMT->ViewValue, Config("DEFAULT_DECIMAL_PRECISION"));
		$this->dstDifferenceWithGMT->ViewCustomAttributes = "";

		// effectiveDateTimeInGMT
		$this->effectiveDateTimeInGMT->ViewValue = $this->effectiveDateTimeInGMT->CurrentValue;
		$this->effectiveDateTimeInGMT->ViewValue = FormatDateTime($this->effectiveDateTimeInGMT->ViewValue, 0);
		$this->effectiveDateTimeInGMT->ViewCustomAttributes = "";

		// endDateTimeINGMT
		$this->endDateTimeINGMT->ViewValue = $this->endDateTimeINGMT->CurrentValue;
		$this->endDateTimeINGMT->ViewValue = FormatDateTime($this->endDateTimeINGMT->ViewValue, 0);
		$this->endDateTimeINGMT->ViewCustomAttributes = "";

		// timeZoneID
		$this->timeZoneID->LinkCustomAttributes = "";
		$this->timeZoneID->HrefValue = "";
		$this->timeZoneID->TooltipValue = "";

		// name
		$this->name->LinkCustomAttributes = "";
		$this->name->HrefValue = "";
		$this->name->TooltipValue = "";

		// abbreviationNormal
		$this->abbreviationNormal->LinkCustomAttributes = "";
		$this->abbreviationNormal->HrefValue = "";
		$this->abbreviationNormal->TooltipValue = "";

		// abbreviationDST
		$this->abbreviationDST->LinkCustomAttributes = "";
		$this->abbreviationDST->HrefValue = "";
		$this->abbreviationDST->TooltipValue = "";

		// normalDifferenceWithGMT
		$this->normalDifferenceWithGMT->LinkCustomAttributes = "";
		$this->normalDifferenceWithGMT->HrefValue = "";
		$this->normalDifferenceWithGMT->TooltipValue = "";

		// dstDifferenceWithGMT
		$this->dstDifferenceWithGMT->LinkCustomAttributes = "";
		$this->dstDifferenceWithGMT->HrefValue = "";
		$this->dstDifferenceWithGMT->TooltipValue = "";

		// effectiveDateTimeInGMT
		$this->effectiveDateTimeInGMT->LinkCustomAttributes = "";
		$this->effectiveDateTimeInGMT->HrefValue = "";
		$this->effectiveDateTimeInGMT->TooltipValue = "";

		// endDateTimeINGMT
		$this->endDateTimeINGMT->LinkCustomAttributes = "";
		$this->endDateTimeINGMT->HrefValue = "";
		$this->endDateTimeINGMT->TooltipValue = "";

		// Call Row Rendered event
		$this->Row_Rendered();

		// Save data for Custom Template
		$this->Rows[] = $this->customTemplateFieldValues();
	}

	// Render edit row values
	public function renderEditRow()
	{
		global $Security, $CurrentLanguage, $Language;

		// Call Row Rendering event
		$this->Row_Rendering();

		// timeZoneID
		$this->timeZoneID->EditAttrs["class"] = "form-control";
		$this->timeZoneID->EditCustomAttributes = "";
		$this->timeZoneID->EditValue = $this->timeZoneID->CurrentValue;
		$this->timeZoneID->PlaceHolder = RemoveHtml($this->timeZoneID->caption());

		// name
		$this->name->EditAttrs["class"] = "form-control";
		$this->name->EditCustomAttributes = "";
		if (!$this->name->Raw)
			$this->name->CurrentValue = HtmlDecode($this->name->CurrentValue);
		$this->name->EditValue = $this->name->CurrentValue;
		$this->name->PlaceHolder = RemoveHtml($this->name->caption());

		// abbreviationNormal
		$this->abbreviationNormal->EditAttrs["class"] = "form-control";
		$this->abbreviationNormal->EditCustomAttributes = "";
		if (!$this->abbreviationNormal->Raw)
			$this->abbreviationNormal->CurrentValue = HtmlDecode($this->abbreviationNormal->CurrentValue);
		$this->abbreviationNormal->EditValue = $this->abbreviationNormal->CurrentValue;
		$this->abbreviationNormal->PlaceHolder = RemoveHtml($this->abbreviationNormal->caption());

		// abbreviationDST
		$this->abbreviationDST->EditAttrs["class"] = "form-control";
		$this->abbreviationDST->EditCustomAttributes = "";
		if (!$this->abbreviationDST->Raw)
			$this->abbreviationDST->CurrentValue = HtmlDecode($this->abbreviationDST->CurrentValue);
		$this->abbreviationDST->EditValue = $this->abbreviationDST->CurrentValue;
		$this->abbreviationDST->PlaceHolder = RemoveHtml($this->abbreviationDST->caption());

		// normalDifferenceWithGMT
		$this->normalDifferenceWithGMT->EditAttrs["class"] = "form-control";
		$this->normalDifferenceWithGMT->EditCustomAttributes = "";
		$this->normalDifferenceWithGMT->EditValue = $this->normalDifferenceWithGMT->CurrentValue;
		$this->normalDifferenceWithGMT->PlaceHolder = RemoveHtml($this->normalDifferenceWithGMT->caption());
		if (strval($this->normalDifferenceWithGMT->EditValue) != "" && is_numeric($this->normalDifferenceWithGMT->EditValue))
			$this->normalDifferenceWithGMT->EditValue = FormatNumber($this->normalDifferenceWithGMT->EditValue, -2, -1, -2, 0);
		

		// dstDifferenceWithGMT
		$this->dstDifferenceWithGMT->EditAttrs["class"] = "form-control";
		$this->dstDifferenceWithGMT->EditCustomAttributes = "";
		$this->dstDifferenceWithGMT->EditValue = $this->dstDifferenceWithGMT->CurrentValue;
		$this->dstDifferenceWithGMT->PlaceHolder = RemoveHtml($this->dstDifferenceWithGMT->caption());
		if (strval($this->dstDifferenceWithGMT->EditValue) != "" && is_numeric($this->dstDifferenceWithGMT->EditValue))
			$this->dstDifferenceWithGMT->EditValue = FormatNumber($this->dstDifferenceWithGMT->EditValue, -2, -1, -2, 0);
		

		// effectiveDateTimeInGMT
		$this->effectiveDateTimeInGMT->EditAttrs["class"] = "form-control";
		$this->effectiveDateTimeInGMT->EditCustomAttributes = "";
		$this->effectiveDateTimeInGMT->EditValue = FormatDateTime($this->effectiveDateTimeInGMT->CurrentValue, 8);
		$this->effectiveDateTimeInGMT->PlaceHolder = RemoveHtml($this->effectiveDateTimeInGMT->caption());

		// endDateTimeINGMT
		$this->endDateTimeINGMT->EditAttrs["class"] = "form-control";
		$this->endDateTimeINGMT->EditCustomAttributes = "";
		$this->endDateTimeINGMT->EditValue = FormatDateTime($this->endDateTimeINGMT->CurrentValue, 8);
		$this->endDateTimeINGMT->PlaceHolder = RemoveHtml($this->endDateTimeINGMT->caption());

		// Call Row Rendered event
		$this->Row_Rendered();
	}

	// Aggregate list row values
	public function aggregateListRowValues()
	{
	}

	// Aggregate list row (for rendering)
	public function aggregateListRow()
	{

		// Call Row Rendered event
		$this->Row_Rendered();
	}

	// Export data in HTML/CSV/Word/Excel/Email/PDF format
	public function exportDocument($doc, $recordset, $startRec = 1, $stopRec = 1, $exportPageType = "")
	{
		if (!$recordset || !$doc)
			return;
		if (!$doc->ExportCustom) {

			// Write header
			$doc->exportTableHeader();
			if ($doc->Horizontal) { // Horizontal format, write header
				$doc->beginExportRow();
				if ($exportPageType == "view") {
					$doc->exportCaption($this->timeZoneID);
					$doc->exportCaption($this->name);
					$doc->exportCaption($this->abbreviationNormal);
					$doc->exportCaption($this->abbreviationDST);
					$doc->exportCaption($this->normalDifferenceWithGMT);
					$doc->exportCaption($this->dstDifferenceWithGMT);
					$doc->exportCaption($this->effectiveDateTimeInGMT);
					$doc->exportCaption($this->endDateTimeINGMT);
				} else {
					$doc->exportCaption($this->timeZoneID);
					$doc->exportCaption($this->name);
					$doc->exportCaption($this->abbreviationNormal);
					$doc->exportCaption($this->abbreviationDST);
					$doc->exportCaption($this->normalDifferenceWithGMT);
					$doc->exportCaption($this->dstDifferenceWithGMT);
					$doc->exportCaption($this->effectiveDateTimeInGMT);
					$doc->exportCaption($this->endDateTimeINGMT);
				}
				$doc->endExportRow();
			}
		}

		// Move to first record
		$recCnt = $startRec - 1;
		if (!$recordset->EOF) {
			$recordset->moveFirst();
			if ($startRec > 1)
				$recordset->move($startRec - 1);
		}
		while (!$recordset->EOF && $recCnt < $stopRec) {
			$recCnt++;
			if ($recCnt >= $startRec) {
				$rowCnt = $recCnt - $startRec + 1;

				// Page break
				if ($this->ExportPageBreakCount > 0) {
					if ($rowCnt > 1 && ($rowCnt - 1) % $this->ExportPageBreakCount == 0)
						$doc->exportPageBreak();
				}
				$this->loadListRowValues($recordset);

				// Render row
				$this->RowType = ROWTYPE_VIEW; // Render view
				$this->resetAttributes();
				$this->renderListRow();
				if (!$doc->ExportCustom) {
					$doc->beginExportRow($rowCnt); // Allow CSS styles if enabled
					if ($exportPageType == "view") {
						$doc->exportField($this->timeZoneID);
						$doc->exportField($this->name);
						$doc->exportField($this->abbreviationNormal);
						$doc->exportField($this->abbreviationDST);
						$doc->exportField($this->normalDifferenceWithGMT);
						$doc->exportField($this->dstDifferenceWithGMT);
						$doc->exportField($this->effectiveDateTimeInGMT);
						$doc->exportField($this->endDateTimeINGMT);
					} else {
						$doc->exportField($this->timeZoneID);
						$doc->exportField($this->name);
						$doc->exportField($this->abbreviationNormal);
						$doc->exportField($this->abbreviationDST);
						$doc->exportField($this->normalDifferenceWithGMT);
						$doc->exportField($this->dstDifferenceWithGMT);
						$doc->exportField($this->effectiveDateTimeInGMT);
						$doc->exportField($this->endDateTimeINGMT);
					}
					$doc->endExportRow($rowCnt);
				}
			}

			// Call Row Export server event
			if ($doc->ExportCustom)
				$this->Row_Export($recordset->fields);
			$recordset->moveNext();
		}
		if (!$doc->ExportCustom) {
			$doc->exportTableFooter();
		}
	}

	// Get file data
	public function getFileData($fldparm, $key, $resize, $width = 0, $height = 0)
	{

		// No binary fields
		return FALSE;
	}

	// Table level events
	// Recordset Selecting event
	function Recordset_Selecting(&$filter) {

		// Enter your code here
	}

	// Recordset Selected event
	function Recordset_Selected(&$rs) {

		//echo "Recordset Selected";
	}

	// Recordset Search Validated event
	function Recordset_SearchValidated() {

		// Example:
		//$this->MyField1->AdvancedSearch->SearchValue = "your search criteria"; // Search value

	}

	// Recordset Searching event
	function Recordset_Searching(&$filter) {

		// Enter your code here
	}

	// Row_Selecting event
	function Row_Selecting(&$filter) {

		// Enter your code here
	}

	// Row Selected event
	function Row_Selected(&$rs) {

		//echo "Row Selected";
	}

	// Row Inserting event
	function Row_Inserting($rsold, &$rsnew) {

		// Enter your code here
		// To cancel, set return value to FALSE

		return TRUE;
	}

	// Row Inserted event
	function Row_Inserted($rsold, &$rsnew) {

		//echo "Row Inserted"
	}

	// Row Updating event
	function Row_Updating($rsold, &$rsnew) {

		// Enter your code here
		// To cancel, set return value to FALSE

		return TRUE;
	}

	// Row Updated event
	function Row_Updated($rsold, &$rsnew) {

		//echo "Row Updated";
	}

	// Row Update Conflict event
	function Row_UpdateConflict($rsold, &$rsnew) {

		// Enter your code here
		// To ignore conflict, set return value to FALSE

		return TRUE;
	}

	// Grid Inserting event
	function Grid_Inserting() {

		// Enter your code here
		// To reject grid insert, set return value to FALSE

		return TRUE;
	}

	// Grid Inserted event
	function Grid_Inserted($rsnew) {

		//echo "Grid Inserted";
	}

	// Grid Updating event
	function Grid_Updating($rsold) {

		// Enter your code here
		// To reject grid update, set return value to FALSE

		return TRUE;
	}

	// Grid Updated event
	function Grid_Updated($rsold, $rsnew) {

		//echo "Grid Updated";
	}

	// Row Deleting event
	function Row_Deleting(&$rs) {

		// Enter your code here
		// To cancel, set return value to False

		return TRUE;
	}

	// Row Deleted event
	function Row_Deleted(&$rs) {

		//echo "Row Deleted";
	}

	// Email Sending event
	function Email_Sending($email, &$args) {

		//var_dump($email); var_dump($args); exit();
		return TRUE;
	}

	// Lookup Selecting event
	function Lookup_Selecting($fld, &$filter) {

		//var_dump($fld->Name, $fld->Lookup, $filter); // Uncomment to view the filter
		// Enter your code here

	}

	// Row Rendering event
	function Row_Rendering() {

		// Enter your code here
	}

	// Row Rendered event
	function Row_Rendered() {

		// To view properties of field class, use:
		//var_dump($this-><FieldName>);

	}

	// User ID Filtering event
	function UserID_Filtering(&$filter) {

		// Enter your code here
	}
}
?>