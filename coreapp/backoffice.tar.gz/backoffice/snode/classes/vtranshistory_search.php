<?php
namespace PHPMaker2020\_4payadmin;

/**
 * Page class
 */
class vtranshistory_search extends vtranshistory
{

	// Page ID
	public $PageID = "search";

	// Project ID
	public $ProjectID = "{153C2D2E-60EE-4944-8753-3935EB38E8D6}";

	// Table name
	public $TableName = 'vtranshistory';

	// Page object name
	public $PageObjName = "vtranshistory_search";

	// Page headings
	public $Heading = "";
	public $Subheading = "";
	public $PageHeader;
	public $PageFooter;

	// Token
	public $Token = "";
	public $TokenTimeout = 0;
	public $CheckToken;

	// Page heading
	public function pageHeading()
	{
		global $Language;
		if ($this->Heading != "")
			return $this->Heading;
		if (method_exists($this, "tableCaption"))
			return $this->tableCaption();
		return "";
	}

	// Page subheading
	public function pageSubheading()
	{
		global $Language;
		if ($this->Subheading != "")
			return $this->Subheading;
		if ($this->TableName)
			return $Language->phrase($this->PageID);
		return "";
	}

	// Page name
	public function pageName()
	{
		return CurrentPageName();
	}

	// Page URL
	public function pageUrl()
	{
		$url = CurrentPageName() . "?";
		if ($this->UseTokenInUrl)
			$url .= "t=" . $this->TableVar . "&"; // Add page token
		return $url;
	}

	// Messages
	private $_message = "";
	private $_failureMessage = "";
	private $_successMessage = "";
	private $_warningMessage = "";

	// Get message
	public function getMessage()
	{
		return isset($_SESSION[SESSION_MESSAGE]) ? $_SESSION[SESSION_MESSAGE] : $this->_message;
	}

	// Set message
	public function setMessage($v)
	{
		AddMessage($this->_message, $v);
		$_SESSION[SESSION_MESSAGE] = $this->_message;
	}

	// Get failure message
	public function getFailureMessage()
	{
		return isset($_SESSION[SESSION_FAILURE_MESSAGE]) ? $_SESSION[SESSION_FAILURE_MESSAGE] : $this->_failureMessage;
	}

	// Set failure message
	public function setFailureMessage($v)
	{
		AddMessage($this->_failureMessage, $v);
		$_SESSION[SESSION_FAILURE_MESSAGE] = $this->_failureMessage;
	}

	// Get success message
	public function getSuccessMessage()
	{
		return isset($_SESSION[SESSION_SUCCESS_MESSAGE]) ? $_SESSION[SESSION_SUCCESS_MESSAGE] : $this->_successMessage;
	}

	// Set success message
	public function setSuccessMessage($v)
	{
		AddMessage($this->_successMessage, $v);
		$_SESSION[SESSION_SUCCESS_MESSAGE] = $this->_successMessage;
	}

	// Get warning message
	public function getWarningMessage()
	{
		return isset($_SESSION[SESSION_WARNING_MESSAGE]) ? $_SESSION[SESSION_WARNING_MESSAGE] : $this->_warningMessage;
	}

	// Set warning message
	public function setWarningMessage($v)
	{
		AddMessage($this->_warningMessage, $v);
		$_SESSION[SESSION_WARNING_MESSAGE] = $this->_warningMessage;
	}

	// Clear message
	public function clearMessage()
	{
		$this->_message = "";
		$_SESSION[SESSION_MESSAGE] = "";
	}

	// Clear failure message
	public function clearFailureMessage()
	{
		$this->_failureMessage = "";
		$_SESSION[SESSION_FAILURE_MESSAGE] = "";
	}

	// Clear success message
	public function clearSuccessMessage()
	{
		$this->_successMessage = "";
		$_SESSION[SESSION_SUCCESS_MESSAGE] = "";
	}

	// Clear warning message
	public function clearWarningMessage()
	{
		$this->_warningMessage = "";
		$_SESSION[SESSION_WARNING_MESSAGE] = "";
	}

	// Clear messages
	public function clearMessages()
	{
		$this->clearMessage();
		$this->clearFailureMessage();
		$this->clearSuccessMessage();
		$this->clearWarningMessage();
	}

	// Show message
	public function showMessage()
	{
		$hidden = FALSE;
		$html = "";

		// Message
		$message = $this->getMessage();
		if (method_exists($this, "Message_Showing"))
			$this->Message_Showing($message, "");
		if ($message != "") { // Message in Session, display
			if (!$hidden)
				$message = '<button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button>' . $message;
			$html .= '<div class="alert alert-info alert-dismissible ew-info"><i class="icon fas fa-info"></i>' . $message . '</div>';
			$_SESSION[SESSION_MESSAGE] = ""; // Clear message in Session
		}

		// Warning message
		$warningMessage = $this->getWarningMessage();
		if (method_exists($this, "Message_Showing"))
			$this->Message_Showing($warningMessage, "warning");
		if ($warningMessage != "") { // Message in Session, display
			if (!$hidden)
				$warningMessage = '<button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button>' . $warningMessage;
			$html .= '<div class="alert alert-warning alert-dismissible ew-warning"><i class="icon fas fa-exclamation"></i>' . $warningMessage . '</div>';
			$_SESSION[SESSION_WARNING_MESSAGE] = ""; // Clear message in Session
		}

		// Success message
		$successMessage = $this->getSuccessMessage();
		if (method_exists($this, "Message_Showing"))
			$this->Message_Showing($successMessage, "success");
		if ($successMessage != "") { // Message in Session, display
			if (!$hidden)
				$successMessage = '<button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button>' . $successMessage;
			$html .= '<div class="alert alert-success alert-dismissible ew-success"><i class="icon fas fa-check"></i>' . $successMessage . '</div>';
			$_SESSION[SESSION_SUCCESS_MESSAGE] = ""; // Clear message in Session
		}

		// Failure message
		$errorMessage = $this->getFailureMessage();
		if (method_exists($this, "Message_Showing"))
			$this->Message_Showing($errorMessage, "failure");
		if ($errorMessage != "") { // Message in Session, display
			if (!$hidden)
				$errorMessage = '<button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button>' . $errorMessage;
			$html .= '<div class="alert alert-danger alert-dismissible ew-error"><i class="icon fas fa-ban"></i>' . $errorMessage . '</div>';
			$_SESSION[SESSION_FAILURE_MESSAGE] = ""; // Clear message in Session
		}
		echo '<div class="ew-message-dialog' . (($hidden) ? ' d-none' : "") . '">' . $html . '</div>';
	}

	// Get message as array
	public function getMessages()
	{
		$ar = [];

		// Message
		$message = $this->getMessage();

		//if (method_exists($this, "Message_Showing"))
		//	$this->Message_Showing($message, "");

		if ($message != "") { // Message in Session, display
			$ar["message"] = $message;
			$_SESSION[SESSION_MESSAGE] = ""; // Clear message in Session
		}

		// Warning message
		$warningMessage = $this->getWarningMessage();

		//if (method_exists($this, "Message_Showing"))
		//	$this->Message_Showing($warningMessage, "warning");

		if ($warningMessage != "") { // Message in Session, display
			$ar["warningMessage"] = $warningMessage;
			$_SESSION[SESSION_WARNING_MESSAGE] = ""; // Clear message in Session
		}

		// Success message
		$successMessage = $this->getSuccessMessage();

		//if (method_exists($this, "Message_Showing"))
		//	$this->Message_Showing($successMessage, "success");

		if ($successMessage != "") { // Message in Session, display
			$ar["successMessage"] = $successMessage;
			$_SESSION[SESSION_SUCCESS_MESSAGE] = ""; // Clear message in Session
		}

		// Failure message
		$failureMessage = $this->getFailureMessage();

		//if (method_exists($this, "Message_Showing"))
		//	$this->Message_Showing($failureMessage, "failure");

		if ($failureMessage != "") { // Message in Session, display
			$ar["failureMessage"] = $failureMessage;
			$_SESSION[SESSION_FAILURE_MESSAGE] = ""; // Clear message in Session
		}
		return $ar;
	}

	// Show Page Header
	public function showPageHeader()
	{
		$header = $this->PageHeader;
		$this->Page_DataRendering($header);
		if ($header != "") { // Header exists, display
			echo '<p id="ew-page-header">' . $header . '</p>';
		}
	}

	// Show Page Footer
	public function showPageFooter()
	{
		$footer = $this->PageFooter;
		$this->Page_DataRendered($footer);
		if ($footer != "") { // Footer exists, display
			echo '<p id="ew-page-footer">' . $footer . '</p>';
		}
	}

	// Validate page request
	protected function isPageRequest()
	{
		global $CurrentForm;
		if ($this->UseTokenInUrl) {
			if ($CurrentForm)
				return ($this->TableVar == $CurrentForm->getValue("t"));
			if (Get("t") !== NULL)
				return ($this->TableVar == Get("t"));
		}
		return TRUE;
	}

	// Valid Post
	protected function validPost()
	{
		if (!$this->CheckToken || !IsPost() || IsApi())
			return TRUE;
		if (Post(Config("TOKEN_NAME")) === NULL)
			return FALSE;
		$fn = Config("CHECK_TOKEN_FUNC");
		if (is_callable($fn))
			return $fn(Post(Config("TOKEN_NAME")), $this->TokenTimeout);
		return FALSE;
	}

	// Create Token
	public function createToken()
	{
		global $CurrentToken;
		$fn = Config("CREATE_TOKEN_FUNC"); // Always create token, required by API file/lookup request
		if ($this->Token == "" && is_callable($fn)) // Create token
			$this->Token = $fn();
		$CurrentToken = $this->Token; // Save to global variable
	}

	// Constructor
	public function __construct()
	{
		global $Language, $DashboardReport;
		global $UserTable;

		// Check token
		$this->CheckToken = Config("CHECK_TOKEN");

		// Initialize
		$GLOBALS["Page"] = &$this;
		$this->TokenTimeout = SessionTimeoutTime();

		// Language object
		if (!isset($Language))
			$Language = new Language();

		// Parent constuctor
		parent::__construct();

		// Table object (vtranshistory)
		if (!isset($GLOBALS["vtranshistory"]) || get_class($GLOBALS["vtranshistory"]) == PROJECT_NAMESPACE . "vtranshistory") {
			$GLOBALS["vtranshistory"] = &$this;
			$GLOBALS["Table"] = &$GLOBALS["vtranshistory"];
		}

		// Table object (acctbalance)
		if (!isset($GLOBALS['acctbalance']))
			$GLOBALS['acctbalance'] = new acctbalance();

		// Table object (admin)
		if (!isset($GLOBALS['admin']))
			$GLOBALS['admin'] = new admin();

		// Page ID (for backward compatibility only)
		if (!defined(PROJECT_NAMESPACE . "PAGE_ID"))
			define(PROJECT_NAMESPACE . "PAGE_ID", 'search');

		// Table name (for backward compatibility only)
		if (!defined(PROJECT_NAMESPACE . "TABLE_NAME"))
			define(PROJECT_NAMESPACE . "TABLE_NAME", 'vtranshistory');

		// Start timer
		if (!isset($GLOBALS["DebugTimer"]))
			$GLOBALS["DebugTimer"] = new Timer();

		// Debug message
		LoadDebugMessage();

		// Open connection
		if (!isset($GLOBALS["Conn"]))
			$GLOBALS["Conn"] = $this->getConnection();

		// User table object (admin)
		$UserTable = $UserTable ?: new admin();
	}

	// Terminate page
	public function terminate($url = "")
	{
		global $ExportFileName, $TempImages, $DashboardReport;

		// Page Unload event
		$this->Page_Unload();

		// Global Page Unloaded event (in userfn*.php)
		Page_Unloaded();

		// Export
		global $vtranshistory;
		if ($this->CustomExport && $this->CustomExport == $this->Export && array_key_exists($this->CustomExport, Config("EXPORT_CLASSES"))) {
				$content = ob_get_contents();
			if ($ExportFileName == "")
				$ExportFileName = $this->TableVar;
			$class = PROJECT_NAMESPACE . Config("EXPORT_CLASSES." . $this->CustomExport);
			if (class_exists($class)) {
				$doc = new $class($vtranshistory);
				$doc->Text = @$content;
				if ($this->isExport("email"))
					echo $this->exportEmail($doc->Text);
				else
					$doc->export();
				DeleteTempImages(); // Delete temp images
				exit();
			}
		}
		if (!IsApi())
			$this->Page_Redirecting($url);

		// Close connection
		CloseConnections();

		// Return for API
		if (IsApi()) {
			$res = $url === TRUE;
			if (!$res) // Show error
				WriteJson(array_merge(["success" => FALSE], $this->getMessages()));
			return;
		}

		// Go to URL if specified
		if ($url != "") {
			if (!Config("DEBUG") && ob_get_length())
				ob_end_clean();

			// Handle modal response
			if ($this->IsModal) { // Show as modal
				$row = ["url" => $url, "modal" => "1"];
				$pageName = GetPageName($url);
				if ($pageName != $this->getListUrl()) { // Not List page
					$row["caption"] = $this->getModalCaption($pageName);
					if ($pageName == "vtranshistoryview.php")
						$row["view"] = "1";
				} else { // List page should not be shown as modal => error
					$row["error"] = $this->getFailureMessage();
					$this->clearFailureMessage();
				}
				WriteJson($row);
			} else {
				SaveDebugMessage();
				AddHeader("Location", $url);
			}
		}
		exit();
	}

	// Get records from recordset
	protected function getRecordsFromRecordset($rs, $current = FALSE)
	{
		$rows = [];
		if (is_object($rs)) { // Recordset
			while ($rs && !$rs->EOF) {
				$this->loadRowValues($rs); // Set up DbValue/CurrentValue
				$row = $this->getRecordFromArray($rs->fields);
				if ($current)
					return $row;
				else
					$rows[] = $row;
				$rs->moveNext();
			}
		} elseif (is_array($rs)) {
			foreach ($rs as $ar) {
				$row = $this->getRecordFromArray($ar);
				if ($current)
					return $row;
				else
					$rows[] = $row;
			}
		}
		return $rows;
	}

	// Get record from array
	protected function getRecordFromArray($ar)
	{
		$row = [];
		if (is_array($ar)) {
			foreach ($ar as $fldname => $val) {
				if (array_key_exists($fldname, $this->fields) && ($this->fields[$fldname]->Visible || $this->fields[$fldname]->IsPrimaryKey)) { // Primary key or Visible
					$fld = &$this->fields[$fldname];
					if ($fld->HtmlTag == "FILE") { // Upload field
						if (EmptyValue($val)) {
							$row[$fldname] = NULL;
						} else {
							if ($fld->DataType == DATATYPE_BLOB) {
								$url = FullUrl(GetApiUrl(Config("API_FILE_ACTION"),
									Config("API_OBJECT_NAME") . "=" . $fld->TableVar . "&" .
									Config("API_FIELD_NAME") . "=" . $fld->Param . "&" .
									Config("API_KEY_NAME") . "=" . rawurlencode($this->getRecordKeyValue($ar)))); //*** need to add this? API may not be in the same folder
								$row[$fldname] = ["type" => ContentType($val), "url" => $url, "name" => $fld->Param . ContentExtension($val)];
							} elseif (!$fld->UploadMultiple || !ContainsString($val, Config("MULTIPLE_UPLOAD_SEPARATOR"))) { // Single file
								$url = FullUrl(GetApiUrl(Config("API_FILE_ACTION"),
									Config("API_OBJECT_NAME") . "=" . $fld->TableVar . "&" .
									"fn=" . Encrypt($fld->physicalUploadPath() . $val)));
								$row[$fldname] = ["type" => MimeContentType($val), "url" => $url, "name" => $val];
							} else { // Multiple files
								$files = explode(Config("MULTIPLE_UPLOAD_SEPARATOR"), $val);
								$ar = [];
								foreach ($files as $file) {
									$url = FullUrl(GetApiUrl(Config("API_FILE_ACTION"),
										Config("API_OBJECT_NAME") . "=" . $fld->TableVar . "&" .
										"fn=" . Encrypt($fld->physicalUploadPath() . $file)));
									if (!EmptyValue($file))
										$ar[] = ["type" => MimeContentType($file), "url" => $url, "name" => $file];
								}
								$row[$fldname] = $ar;
							}
						}
					} else {
						$row[$fldname] = $val;
					}
				}
			}
		}
		return $row;
	}

	// Get record key value from array
	protected function getRecordKeyValue($ar)
	{
		$key = "";
		if (is_array($ar)) {
			$key .= @$ar['transID'];
		}
		return $key;
	}

	/**
	 * Hide fields for add/edit
	 *
	 * @return void
	 */
	protected function hideFieldsForAddEdit()
	{
		if ($this->isAdd() || $this->isCopy() || $this->isGridAdd())
			$this->transID->Visible = FALSE;
		if ($this->isAddOrEdit())
			$this->transLineID->Visible = FALSE;
	}

	// Lookup data
	public function lookup()
	{
		global $Language, $Security;
		if (!isset($Language))
			$Language = new Language(Config("LANGUAGE_FOLDER"), Post("language", ""));

		// Set up API request
		if (!ValidApiRequest())
			return FALSE;
		$this->setupApiSecurity();

		// Get lookup object
		$fieldName = Post("field");
		if (!array_key_exists($fieldName, $this->fields))
			return FALSE;
		$lookupField = $this->fields[$fieldName];
		$lookup = $lookupField->Lookup;
		if ($lookup === NULL)
			return FALSE;
		$tbl = $lookup->getTable();
		if (!$Security->allowLookup(Config("PROJECT_ID") . $tbl->TableName)) // Lookup permission
			return FALSE;

		// Get lookup parameters
		$lookupType = Post("ajax", "unknown");
		$pageSize = -1;
		$offset = -1;
		$searchValue = "";
		if (SameText($lookupType, "modal")) {
			$searchValue = Post("sv", "");
			$pageSize = Post("recperpage", 10);
			$offset = Post("start", 0);
		} elseif (SameText($lookupType, "autosuggest")) {
			$searchValue = Param("q", "");
			$pageSize = Param("n", -1);
			$pageSize = is_numeric($pageSize) ? (int)$pageSize : -1;
			if ($pageSize <= 0)
				$pageSize = Config("AUTO_SUGGEST_MAX_ENTRIES");
			$start = Param("start", -1);
			$start = is_numeric($start) ? (int)$start : -1;
			$page = Param("page", -1);
			$page = is_numeric($page) ? (int)$page : -1;
			$offset = $start >= 0 ? $start : ($page > 0 && $pageSize > 0 ? ($page - 1) * $pageSize : 0);
		}
		$userSelect = Decrypt(Post("s", ""));
		$userFilter = Decrypt(Post("f", ""));
		$userOrderBy = Decrypt(Post("o", ""));
		$keys = Post("keys");
		$lookup->LookupType = $lookupType; // Lookup type
		if ($keys !== NULL) { // Selected records from modal
			if (is_array($keys))
				$keys = implode(Config("MULTIPLE_OPTION_SEPARATOR"), $keys);
			$lookup->FilterFields = []; // Skip parent fields if any
			$lookup->FilterValues[] = $keys; // Lookup values
			$pageSize = -1; // Show all records
		} else { // Lookup values
			$lookup->FilterValues[] = Post("v0", Post("lookupValue", ""));
		}
		$cnt = is_array($lookup->FilterFields) ? count($lookup->FilterFields) : 0;
		for ($i = 1; $i <= $cnt; $i++)
			$lookup->FilterValues[] = Post("v" . $i, "");
		$lookup->SearchValue = $searchValue;
		$lookup->PageSize = $pageSize;
		$lookup->Offset = $offset;
		if ($userSelect != "")
			$lookup->UserSelect = $userSelect;
		if ($userFilter != "")
			$lookup->UserFilter = $userFilter;
		if ($userOrderBy != "")
			$lookup->UserOrderBy = $userOrderBy;
		$lookup->toJson($this); // Use settings from current page
	}

	// Set up API security
	public function setupApiSecurity()
	{
		global $Security;

		// Setup security for API request
		if ($Security->isLoggedIn()) $Security->TablePermission_Loading();
		$Security->loadCurrentUserLevel(Config("PROJECT_ID") . $this->TableName);
		if ($Security->isLoggedIn()) $Security->TablePermission_Loaded();
	}
	public $FormClassName = "ew-horizontal ew-form ew-search-form";
	public $IsModal = FALSE;
	public $IsMobileOrModal = FALSE;

	//
	// Page run
	//

	public function run()
	{
		global $ExportType, $CustomExportType, $ExportFileName, $UserProfile, $Language, $Security, $CurrentForm,
			$SearchError, $SkipHeaderFooter;

		// Is modal
		$this->IsModal = (Param("modal") == "1");

		// User profile
		$UserProfile = new UserProfile();

		// Security
		if (ValidApiRequest()) { // API request
			$this->setupApiSecurity(); // Set up API Security
		} else {
			$Security = new AdvancedSecurity();
			if (IsPasswordExpired())
				$this->terminate(GetUrl("changepwd.php"));
			if (!$Security->isLoggedIn())
				$Security->autoLogin();
			if ($Security->isLoggedIn())
				$Security->TablePermission_Loading();
			$Security->loadCurrentUserLevel($this->ProjectID . $this->TableName);
			if ($Security->isLoggedIn())
				$Security->TablePermission_Loaded();
			if (!$Security->canSearch()) {
				$Security->saveLastUrl();
				$this->setFailureMessage(DeniedMessage()); // Set no permission
				if ($Security->canList())
					$this->terminate(GetUrl("vtranshistorylist.php"));
				else
					$this->terminate(GetUrl("login.php"));
				return;
			}
		}

		// Create form object
		$CurrentForm = new HttpForm();
		$this->CurrentAction = Param("action"); // Set up current action
		$this->acctID->setVisibility();
		$this->currID->setVisibility();
		$this->amount->setVisibility();
		$this->transTime->setVisibility();
		$this->transType->Visible = FALSE;
		$this->transtypelabel->setVisibility();
		$this->sourceUserID->setVisibility();
		$this->destinationUserID->setVisibility();
		$this->referenceTXID->setVisibility();
		$this->langID->Visible = FALSE;
		$this->transID->setVisibility();
		$this->sourceNodeID->setVisibility();
		$this->destinationNodeID->setVisibility();
		$this->msg->setVisibility();
		$this->transLineID->setVisibility();
		$this->hideFieldsForAddEdit();

		// Do not use lookup cache
		$this->setUseLookupCache(FALSE);

		// Global Page Loading event (in userfn*.php)
		Page_Loading();

		// Page Load event
		$this->Page_Load();

		// Check token
		if (!$this->validPost()) {
			Write($Language->phrase("InvalidPostRequest"));
			$this->terminate();
		}

		// Create Token
		$this->createToken();

		// Set up lookup cache
		$this->setupLookupOptions($this->transtypelabel);

		// Set up Breadcrumb
		$this->setupBreadcrumb();

		// Check modal
		if ($this->IsModal)
			$SkipHeaderFooter = TRUE;
		$this->IsMobileOrModal = IsMobile() || $this->IsModal;
		if ($this->isPageRequest()) { // Validate request

			// Get action
			$this->CurrentAction = Post("action");
			if ($this->isSearch()) {

				// Build search string for advanced search, remove blank field
				$this->loadSearchValues(); // Get search values
				if ($this->validateSearch()) {
					$srchStr = $this->buildAdvancedSearch();
				} else {
					$srchStr = "";
					$this->setFailureMessage($SearchError);
				}
				if ($srchStr != "") {
					$srchStr = $this->getUrlParm($srchStr);
					$srchStr = "vtranshistorylist.php" . "?" . $srchStr;
					$this->terminate($srchStr); // Go to list page
				}
			}
		}

		// Restore search settings from Session
		if ($SearchError == "")
			$this->loadAdvancedSearch();

		// Render row for search
		$this->RowType = ROWTYPE_SEARCH;
		$this->resetAttributes();
		$this->renderRow();
	}

	// Build advanced search
	protected function buildAdvancedSearch()
	{
		$srchUrl = "";
		$this->buildSearchUrl($srchUrl, $this->acctID); // acctID
		$this->buildSearchUrl($srchUrl, $this->currID); // currID
		$this->buildSearchUrl($srchUrl, $this->amount); // amount
		$this->buildSearchUrl($srchUrl, $this->transTime); // transTime
		$this->buildSearchUrl($srchUrl, $this->transtypelabel); // transtypelabel
		$this->buildSearchUrl($srchUrl, $this->sourceUserID); // sourceUserID
		$this->buildSearchUrl($srchUrl, $this->destinationUserID); // destinationUserID
		$this->buildSearchUrl($srchUrl, $this->referenceTXID); // referenceTXID
		$this->buildSearchUrl($srchUrl, $this->transID); // transID
		$this->buildSearchUrl($srchUrl, $this->sourceNodeID); // sourceNodeID
		$this->buildSearchUrl($srchUrl, $this->destinationNodeID); // destinationNodeID
		$this->buildSearchUrl($srchUrl, $this->msg); // msg
		$this->buildSearchUrl($srchUrl, $this->transLineID); // transLineID
		if ($srchUrl != "")
			$srchUrl .= "&";
		$srchUrl .= "cmd=search";
		return $srchUrl;
	}

	// Build search URL
	protected function buildSearchUrl(&$url, &$fld, $oprOnly = FALSE)
	{
		global $CurrentForm;
		$wrk = "";
		$fldParm = $fld->Param;
		$fldVal = $CurrentForm->getValue("x_$fldParm");
		$fldOpr = $CurrentForm->getValue("z_$fldParm");
		$fldCond = $CurrentForm->getValue("v_$fldParm");
		$fldVal2 = $CurrentForm->getValue("y_$fldParm");
		$fldOpr2 = $CurrentForm->getValue("w_$fldParm");
		if (is_array($fldVal))
			$fldVal = implode(Config("MULTIPLE_OPTION_SEPARATOR"), $fldVal);
		if (is_array($fldVal2))
			$fldVal2 = implode(Config("MULTIPLE_OPTION_SEPARATOR"), $fldVal2);
		$fldOpr = strtoupper(trim($fldOpr));
		$fldDataType = ($fld->IsVirtual) ? DATATYPE_STRING : $fld->DataType;
		if ($fldOpr == "BETWEEN") {
			$isValidValue = ($fldDataType != DATATYPE_NUMBER) ||
				($fldDataType == DATATYPE_NUMBER && $this->searchValueIsNumeric($fld, $fldVal) && $this->searchValueIsNumeric($fld, $fldVal2));
			if ($fldVal != "" && $fldVal2 != "" && $isValidValue) {
				$wrk = "x_" . $fldParm . "=" . urlencode($fldVal) .
					"&y_" . $fldParm . "=" . urlencode($fldVal2) .
					"&z_" . $fldParm . "=" . urlencode($fldOpr);
			}
		} else {
			$isValidValue = ($fldDataType != DATATYPE_NUMBER) ||
				($fldDataType == DATATYPE_NUMBER && $this->searchValueIsNumeric($fld, $fldVal));
			if ($fldVal != "" && $isValidValue && IsValidOperator($fldOpr, $fldDataType)) {
				$wrk = "x_" . $fldParm . "=" . urlencode($fldVal) .
					"&z_" . $fldParm . "=" . urlencode($fldOpr);
			} elseif ($fldOpr == "IS NULL" || $fldOpr == "IS NOT NULL" || ($fldOpr != "" && $oprOnly && IsValidOperator($fldOpr, $fldDataType))) {
				$wrk = "z_" . $fldParm . "=" . urlencode($fldOpr);
			}
			$isValidValue = ($fldDataType != DATATYPE_NUMBER) ||
				($fldDataType == DATATYPE_NUMBER && $this->searchValueIsNumeric($fld, $fldVal2));
			if ($fldVal2 != "" && $isValidValue && IsValidOperator($fldOpr2, $fldDataType)) {
				if ($wrk != "")
					$wrk .= "&v_" . $fldParm . "=" . urlencode($fldCond) . "&";
				$wrk .= "y_" . $fldParm . "=" . urlencode($fldVal2) .
					"&w_" . $fldParm . "=" . urlencode($fldOpr2);
			} elseif ($fldOpr2 == "IS NULL" || $fldOpr2 == "IS NOT NULL" || ($fldOpr2 != "" && $oprOnly && IsValidOperator($fldOpr2, $fldDataType))) {
				if ($wrk != "")
					$wrk .= "&v_" . $fldParm . "=" . urlencode($fldCond) . "&";
				$wrk .= "w_" . $fldParm . "=" . urlencode($fldOpr2);
			}
		}
		if ($wrk != "") {
			if ($url != "")
				$url .= "&";
			$url .= $wrk;
		}
	}
	protected function searchValueIsNumeric($fld, $value)
	{
		if (IsFloatFormat($fld->Type))
			$value = ConvertToFloatString($value);
		return is_numeric($value);
	}

	// Load search values for validation
	protected function loadSearchValues()
	{

		// Load search values
		$got = FALSE;
		if ($this->acctID->AdvancedSearch->post())
			$got = TRUE;
		if ($this->currID->AdvancedSearch->post())
			$got = TRUE;
		if ($this->amount->AdvancedSearch->post())
			$got = TRUE;
		if ($this->transTime->AdvancedSearch->post())
			$got = TRUE;
		if ($this->transtypelabel->AdvancedSearch->post())
			$got = TRUE;
		if ($this->sourceUserID->AdvancedSearch->post())
			$got = TRUE;
		if ($this->destinationUserID->AdvancedSearch->post())
			$got = TRUE;
		if ($this->referenceTXID->AdvancedSearch->post())
			$got = TRUE;
		if ($this->transID->AdvancedSearch->post())
			$got = TRUE;
		if ($this->sourceNodeID->AdvancedSearch->post())
			$got = TRUE;
		if ($this->destinationNodeID->AdvancedSearch->post())
			$got = TRUE;
		if ($this->msg->AdvancedSearch->post())
			$got = TRUE;
		if ($this->transLineID->AdvancedSearch->post())
			$got = TRUE;
		return $got;
	}

	// Render row values based on field settings
	public function renderRow()
	{
		global $Security, $Language, $CurrentLanguage;

		// Initialize URLs
		// Convert decimal values if posted back

		if ($this->amount->FormValue == $this->amount->CurrentValue && is_numeric(ConvertToFloatString($this->amount->CurrentValue)))
			$this->amount->CurrentValue = ConvertToFloatString($this->amount->CurrentValue);

		// Call Row_Rendering event
		$this->Row_Rendering();

		// Common render codes for all row types
		// acctID
		// currID
		// amount
		// transTime
		// transType
		// transtypelabel
		// sourceUserID
		// destinationUserID
		// referenceTXID
		// langID
		// transID
		// sourceNodeID
		// destinationNodeID
		// msg
		// transLineID

		if ($this->RowType == ROWTYPE_VIEW) { // View row

			// acctID
			$this->acctID->ViewValue = $this->acctID->CurrentValue;
			$this->acctID->ViewCustomAttributes = "";

			// currID
			$this->currID->ViewValue = $this->currID->CurrentValue;
			$this->currID->ViewCustomAttributes = "";

			// amount
			$this->amount->ViewValue = $this->amount->CurrentValue;
			$this->amount->ViewValue = FormatNumber($this->amount->ViewValue, Config("DEFAULT_DECIMAL_PRECISION"));
			$this->amount->ViewCustomAttributes = "";

			// transTime
			$this->transTime->ViewValue = $this->transTime->CurrentValue;
			$this->transTime->ViewValue = FormatDateTime($this->transTime->ViewValue, 1);
			$this->transTime->ViewCustomAttributes = "";

			// transtypelabel
			$curVal = strval($this->transtypelabel->CurrentValue);
			if ($curVal != "") {
				$this->transtypelabel->ViewValue = $this->transtypelabel->lookupCacheOption($curVal);
				if ($this->transtypelabel->ViewValue === NULL) { // Lookup from database
					$filterWrk = "`label`" . SearchString("=", $curVal, DATATYPE_MEMO, "_4payreference");
					$sqlWrk = $this->transtypelabel->Lookup->getSql(FALSE, $filterWrk, '', $this);
					$rswrk = Conn("_4payreference")->execute($sqlWrk);
					if ($rswrk && !$rswrk->EOF) { // Lookup values found
						$arwrk = [];
						$arwrk[1] = $rswrk->fields('df');
						$this->transtypelabel->ViewValue = $this->transtypelabel->displayValue($arwrk);
						$rswrk->Close();
					} else {
						$this->transtypelabel->ViewValue = $this->transtypelabel->CurrentValue;
					}
				}
			} else {
				$this->transtypelabel->ViewValue = NULL;
			}
			$this->transtypelabel->ViewCustomAttributes = "";

			// sourceUserID
			$this->sourceUserID->ViewValue = $this->sourceUserID->CurrentValue;
			$this->sourceUserID->ViewCustomAttributes = "";

			// destinationUserID
			$this->destinationUserID->ViewValue = $this->destinationUserID->CurrentValue;
			$this->destinationUserID->ViewCustomAttributes = "";

			// referenceTXID
			$this->referenceTXID->ViewValue = $this->referenceTXID->CurrentValue;
			$this->referenceTXID->ViewCustomAttributes = "";

			// transID
			$this->transID->ViewValue = $this->transID->CurrentValue;
			$this->transID->ViewCustomAttributes = "";

			// sourceNodeID
			$this->sourceNodeID->ViewValue = $this->sourceNodeID->CurrentValue;
			$this->sourceNodeID->ViewCustomAttributes = "";

			// destinationNodeID
			$this->destinationNodeID->ViewValue = $this->destinationNodeID->CurrentValue;
			$this->destinationNodeID->ViewCustomAttributes = "";

			// msg
			$this->msg->ViewValue = $this->msg->CurrentValue;
			$this->msg->ViewCustomAttributes = "";

			// transLineID
			$this->transLineID->ViewValue = $this->transLineID->CurrentValue;
			$this->transLineID->ViewCustomAttributes = "";

			// acctID
			$this->acctID->LinkCustomAttributes = "";
			$this->acctID->HrefValue = "";
			$this->acctID->TooltipValue = "";

			// currID
			$this->currID->LinkCustomAttributes = "";
			$this->currID->HrefValue = "";
			$this->currID->TooltipValue = "";

			// amount
			$this->amount->LinkCustomAttributes = "";
			$this->amount->HrefValue = "";
			$this->amount->TooltipValue = "";

			// transTime
			$this->transTime->LinkCustomAttributes = "";
			$this->transTime->HrefValue = "";
			$this->transTime->TooltipValue = "";

			// transtypelabel
			$this->transtypelabel->LinkCustomAttributes = "";
			$this->transtypelabel->HrefValue = "";
			$this->transtypelabel->TooltipValue = "";

			// sourceUserID
			$this->sourceUserID->LinkCustomAttributes = "";
			$this->sourceUserID->HrefValue = "";
			$this->sourceUserID->TooltipValue = "";

			// destinationUserID
			$this->destinationUserID->LinkCustomAttributes = "";
			$this->destinationUserID->HrefValue = "";
			$this->destinationUserID->TooltipValue = "";

			// referenceTXID
			$this->referenceTXID->LinkCustomAttributes = "";
			$this->referenceTXID->HrefValue = "";
			$this->referenceTXID->TooltipValue = "";

			// transID
			$this->transID->LinkCustomAttributes = "";
			$this->transID->HrefValue = "";
			$this->transID->TooltipValue = "";

			// sourceNodeID
			$this->sourceNodeID->LinkCustomAttributes = "";
			$this->sourceNodeID->HrefValue = "";
			$this->sourceNodeID->TooltipValue = "";

			// destinationNodeID
			$this->destinationNodeID->LinkCustomAttributes = "";
			$this->destinationNodeID->HrefValue = "";
			$this->destinationNodeID->TooltipValue = "";

			// msg
			$this->msg->LinkCustomAttributes = "";
			$this->msg->HrefValue = "";
			$this->msg->TooltipValue = "";

			// transLineID
			$this->transLineID->LinkCustomAttributes = "";
			$this->transLineID->HrefValue = "";
			$this->transLineID->TooltipValue = "";
		} elseif ($this->RowType == ROWTYPE_SEARCH) { // Search row

			// acctID
			$this->acctID->EditAttrs["class"] = "form-control";
			$this->acctID->EditCustomAttributes = "";
			$this->acctID->EditValue = HtmlEncode($this->acctID->AdvancedSearch->SearchValue);
			$this->acctID->PlaceHolder = RemoveHtml($this->acctID->caption());

			// currID
			$this->currID->EditAttrs["class"] = "form-control";
			$this->currID->EditCustomAttributes = "";
			if (!$this->currID->Raw)
				$this->currID->AdvancedSearch->SearchValue = HtmlDecode($this->currID->AdvancedSearch->SearchValue);
			$this->currID->EditValue = HtmlEncode($this->currID->AdvancedSearch->SearchValue);
			$this->currID->PlaceHolder = RemoveHtml($this->currID->caption());

			// amount
			$this->amount->EditAttrs["class"] = "form-control";
			$this->amount->EditCustomAttributes = "";
			$this->amount->EditValue = HtmlEncode($this->amount->AdvancedSearch->SearchValue);
			$this->amount->PlaceHolder = RemoveHtml($this->amount->caption());

			// transTime
			$this->transTime->EditAttrs["class"] = "form-control";
			$this->transTime->EditCustomAttributes = "";
			$this->transTime->EditValue = HtmlEncode(FormatDateTime(UnFormatDateTime($this->transTime->AdvancedSearch->SearchValue, 1), 8));
			$this->transTime->PlaceHolder = RemoveHtml($this->transTime->caption());
			$this->transTime->EditAttrs["class"] = "form-control";
			$this->transTime->EditCustomAttributes = "";
			$this->transTime->EditValue2 = HtmlEncode(FormatDateTime(UnFormatDateTime($this->transTime->AdvancedSearch->SearchValue2, 1), 8));
			$this->transTime->PlaceHolder = RemoveHtml($this->transTime->caption());

			// transtypelabel
			$this->transtypelabel->EditCustomAttributes = "";
			$curVal = trim(strval($this->transtypelabel->AdvancedSearch->SearchValue));
			if ($curVal != "")
				$this->transtypelabel->AdvancedSearch->ViewValue = $this->transtypelabel->lookupCacheOption($curVal);
			else
				$this->transtypelabel->AdvancedSearch->ViewValue = $this->transtypelabel->Lookup !== NULL && is_array($this->transtypelabel->Lookup->Options) ? $curVal : NULL;
			if ($this->transtypelabel->AdvancedSearch->ViewValue !== NULL) { // Load from cache
				$this->transtypelabel->EditValue = array_values($this->transtypelabel->Lookup->Options);
				if ($this->transtypelabel->AdvancedSearch->ViewValue == "")
					$this->transtypelabel->AdvancedSearch->ViewValue = $Language->phrase("PleaseSelect");
			} else { // Lookup from database
				if ($curVal == "") {
					$filterWrk = "0=1";
				} else {
					$filterWrk = "`label`" . SearchString("=", $this->transtypelabel->AdvancedSearch->SearchValue, DATATYPE_MEMO, "_4payreference");
				}
				$sqlWrk = $this->transtypelabel->Lookup->getSql(TRUE, $filterWrk, '', $this);
				$rswrk = Conn("_4payreference")->execute($sqlWrk);
				if ($rswrk && !$rswrk->EOF) { // Lookup values found
					$arwrk = [];
					$arwrk[1] = HtmlEncode($rswrk->fields('df'));
					$this->transtypelabel->AdvancedSearch->ViewValue = $this->transtypelabel->displayValue($arwrk);
				} else {
					$this->transtypelabel->AdvancedSearch->ViewValue = $Language->phrase("PleaseSelect");
				}
				$arwrk = $rswrk ? $rswrk->getRows() : [];
				if ($rswrk)
					$rswrk->close();
				$this->transtypelabel->EditValue = $arwrk;
			}
			$this->transtypelabel->EditCustomAttributes = "";
			$curVal = trim(strval($this->transtypelabel->AdvancedSearch->SearchValue2));
			if ($curVal != "")
				$this->transtypelabel->AdvancedSearch->ViewValue2 = $this->transtypelabel->lookupCacheOption($curVal);
			else
				$this->transtypelabel->AdvancedSearch->ViewValue2 = $this->transtypelabel->Lookup !== NULL && is_array($this->transtypelabel->Lookup->Options) ? $curVal : NULL;
			if ($this->transtypelabel->AdvancedSearch->ViewValue2 !== NULL) { // Load from cache
				$this->transtypelabel->EditValue2 = array_values($this->transtypelabel->Lookup->Options);
				if ($this->transtypelabel->AdvancedSearch->ViewValue2 == "")
					$this->transtypelabel->AdvancedSearch->ViewValue2 = $Language->phrase("PleaseSelect");
			} else { // Lookup from database
				if ($curVal == "") {
					$filterWrk = "0=1";
				} else {
					$filterWrk = "`label`" . SearchString("=", $this->transtypelabel->AdvancedSearch->SearchValue2, DATATYPE_MEMO, "_4payreference");
				}
				$sqlWrk = $this->transtypelabel->Lookup->getSql(TRUE, $filterWrk, '', $this);
				$rswrk = Conn("_4payreference")->execute($sqlWrk);
				if ($rswrk && !$rswrk->EOF) { // Lookup values found
					$arwrk = [];
					$arwrk[1] = HtmlEncode($rswrk->fields('df'));
					$this->transtypelabel->AdvancedSearch->ViewValue2 = $this->transtypelabel->displayValue($arwrk);
				} else {
					$this->transtypelabel->AdvancedSearch->ViewValue2 = $Language->phrase("PleaseSelect");
				}
				$arwrk = $rswrk ? $rswrk->getRows() : [];
				if ($rswrk)
					$rswrk->close();
				$this->transtypelabel->EditValue2 = $arwrk;
			}

			// sourceUserID
			$this->sourceUserID->EditAttrs["class"] = "form-control";
			$this->sourceUserID->EditCustomAttributes = "";
			$this->sourceUserID->EditValue = HtmlEncode($this->sourceUserID->AdvancedSearch->SearchValue);
			$this->sourceUserID->PlaceHolder = RemoveHtml($this->sourceUserID->caption());

			// destinationUserID
			$this->destinationUserID->EditAttrs["class"] = "form-control";
			$this->destinationUserID->EditCustomAttributes = "";
			$this->destinationUserID->EditValue = HtmlEncode($this->destinationUserID->AdvancedSearch->SearchValue);
			$this->destinationUserID->PlaceHolder = RemoveHtml($this->destinationUserID->caption());

			// referenceTXID
			$this->referenceTXID->EditAttrs["class"] = "form-control";
			$this->referenceTXID->EditCustomAttributes = "";
			if (!$this->referenceTXID->Raw)
				$this->referenceTXID->AdvancedSearch->SearchValue = HtmlDecode($this->referenceTXID->AdvancedSearch->SearchValue);
			$this->referenceTXID->EditValue = HtmlEncode($this->referenceTXID->AdvancedSearch->SearchValue);
			$this->referenceTXID->PlaceHolder = RemoveHtml($this->referenceTXID->caption());

			// transID
			$this->transID->EditAttrs["class"] = "form-control";
			$this->transID->EditCustomAttributes = "";
			$this->transID->EditValue = HtmlEncode($this->transID->AdvancedSearch->SearchValue);
			$this->transID->PlaceHolder = RemoveHtml($this->transID->caption());

			// sourceNodeID
			$this->sourceNodeID->EditAttrs["class"] = "form-control";
			$this->sourceNodeID->EditCustomAttributes = "";
			$this->sourceNodeID->EditValue = HtmlEncode($this->sourceNodeID->AdvancedSearch->SearchValue);
			$this->sourceNodeID->PlaceHolder = RemoveHtml($this->sourceNodeID->caption());

			// destinationNodeID
			$this->destinationNodeID->EditAttrs["class"] = "form-control";
			$this->destinationNodeID->EditCustomAttributes = "";
			$this->destinationNodeID->EditValue = HtmlEncode($this->destinationNodeID->AdvancedSearch->SearchValue);
			$this->destinationNodeID->PlaceHolder = RemoveHtml($this->destinationNodeID->caption());

			// msg
			$this->msg->EditAttrs["class"] = "form-control";
			$this->msg->EditCustomAttributes = "";
			if (!$this->msg->Raw)
				$this->msg->AdvancedSearch->SearchValue = HtmlDecode($this->msg->AdvancedSearch->SearchValue);
			$this->msg->EditValue = HtmlEncode($this->msg->AdvancedSearch->SearchValue);
			$this->msg->PlaceHolder = RemoveHtml($this->msg->caption());

			// transLineID
			$this->transLineID->EditAttrs["class"] = "form-control";
			$this->transLineID->EditCustomAttributes = "";
			$this->transLineID->EditValue = HtmlEncode($this->transLineID->AdvancedSearch->SearchValue);
			$this->transLineID->PlaceHolder = RemoveHtml($this->transLineID->caption());
		}
		if ($this->RowType == ROWTYPE_ADD || $this->RowType == ROWTYPE_EDIT || $this->RowType == ROWTYPE_SEARCH) // Add/Edit/Search row
			$this->setupFieldTitles();

		// Call Row Rendered event
		if ($this->RowType != ROWTYPE_AGGREGATEINIT)
			$this->Row_Rendered();
	}

	// Validate search
	protected function validateSearch()
	{
		global $SearchError;

		// Initialize
		$SearchError = "";

		// Check if validation required
		if (!Config("SERVER_VALIDATE"))
			return TRUE;
		if (!CheckInteger($this->acctID->AdvancedSearch->SearchValue)) {
			AddMessage($SearchError, $this->acctID->errorMessage());
		}
		if (!CheckNumber($this->amount->AdvancedSearch->SearchValue)) {
			AddMessage($SearchError, $this->amount->errorMessage());
		}
		if (!CheckDate($this->transTime->AdvancedSearch->SearchValue)) {
			AddMessage($SearchError, $this->transTime->errorMessage());
		}
		if (!CheckDate($this->transTime->AdvancedSearch->SearchValue2)) {
			AddMessage($SearchError, $this->transTime->errorMessage());
		}
		if (!CheckInteger($this->sourceUserID->AdvancedSearch->SearchValue)) {
			AddMessage($SearchError, $this->sourceUserID->errorMessage());
		}
		if (!CheckInteger($this->destinationUserID->AdvancedSearch->SearchValue)) {
			AddMessage($SearchError, $this->destinationUserID->errorMessage());
		}
		if (!CheckInteger($this->transID->AdvancedSearch->SearchValue)) {
			AddMessage($SearchError, $this->transID->errorMessage());
		}
		if (!CheckInteger($this->sourceNodeID->AdvancedSearch->SearchValue)) {
			AddMessage($SearchError, $this->sourceNodeID->errorMessage());
		}
		if (!CheckInteger($this->destinationNodeID->AdvancedSearch->SearchValue)) {
			AddMessage($SearchError, $this->destinationNodeID->errorMessage());
		}
		if (!CheckInteger($this->transLineID->AdvancedSearch->SearchValue)) {
			AddMessage($SearchError, $this->transLineID->errorMessage());
		}

		// Return validate result
		$validateSearch = ($SearchError == "");

		// Call Form_CustomValidate event
		$formCustomError = "";
		$validateSearch = $validateSearch && $this->Form_CustomValidate($formCustomError);
		if ($formCustomError != "") {
			AddMessage($SearchError, $formCustomError);
		}
		return $validateSearch;
	}

	// Load advanced search
	public function loadAdvancedSearch()
	{
		$this->acctID->AdvancedSearch->load();
		$this->currID->AdvancedSearch->load();
		$this->amount->AdvancedSearch->load();
		$this->transTime->AdvancedSearch->load();
		$this->transtypelabel->AdvancedSearch->load();
		$this->sourceUserID->AdvancedSearch->load();
		$this->destinationUserID->AdvancedSearch->load();
		$this->referenceTXID->AdvancedSearch->load();
		$this->transID->AdvancedSearch->load();
		$this->sourceNodeID->AdvancedSearch->load();
		$this->destinationNodeID->AdvancedSearch->load();
		$this->msg->AdvancedSearch->load();
		$this->transLineID->AdvancedSearch->load();
	}

	// Set up Breadcrumb
	protected function setupBreadcrumb()
	{
		global $Breadcrumb, $Language;
		$Breadcrumb = new Breadcrumb();
		$url = substr(CurrentUrl(), strrpos(CurrentUrl(), "/")+1);
		$Breadcrumb->add("list", $this->TableVar, $this->addMasterUrl("vtranshistorylist.php"), "", $this->TableVar, TRUE);
		$pageId = "search";
		$Breadcrumb->add("search", $pageId, $url);
	}

	// Setup lookup options
	public function setupLookupOptions($fld)
	{
		if ($fld->Lookup !== NULL && $fld->Lookup->Options === NULL) {

			// Get default connection and filter
			$conn = $this->getConnection();
			$lookupFilter = "";

			// No need to check any more
			$fld->Lookup->Options = [];

			// Set up lookup SQL and connection
			switch ($fld->FieldVar) {
				case "x_transtypelabel":
					$conn = Conn("_4payreference");
					break;
				default:
					$lookupFilter = "";
					break;
			}

			// Always call to Lookup->getSql so that user can setup Lookup->Options in Lookup_Selecting server event
			$sql = $fld->Lookup->getSql(FALSE, "", $lookupFilter, $this);

			// Set up lookup cache
			if ($fld->UseLookupCache && $sql != "" && count($fld->Lookup->Options) == 0) {
				$totalCnt = $this->getRecordCount($sql, $conn);
				if ($totalCnt > $fld->LookupCacheCount) // Total count > cache count, do not cache
					return;
				$rs = $conn->execute($sql);
				$ar = [];
				while ($rs && !$rs->EOF) {
					$row = &$rs->fields;

					// Format the field values
					switch ($fld->FieldVar) {
						case "x_transtypelabel":
							break;
					}
					$ar[strval($row[0])] = $row;
					$rs->moveNext();
				}
				if ($rs)
					$rs->close();
				$fld->Lookup->Options = $ar;
			}
		}
	}

	// Page Load event
	function Page_Load() {

		//echo "Page Load";
	}

	// Page Unload event
	function Page_Unload() {

		//echo "Page Unload";
	}

	// Page Redirecting event
	function Page_Redirecting(&$url) {

		// Example:
		//$url = "your URL";

	}

	// Message Showing event
	// $type = ''|'success'|'failure'|'warning'
	function Message_Showing(&$msg, $type) {
		if ($type == 'success') {

			//$msg = "your success message";
		} elseif ($type == 'failure') {

			//$msg = "your failure message";
		} elseif ($type == 'warning') {

			//$msg = "your warning message";
		} else {

			//$msg = "your message";
		}
	}

	// Page Render event
	function Page_Render() {

		//echo "Page Render";
	}

	// Page Data Rendering event
	function Page_DataRendering(&$header) {

		// Example:
		//$header = "your header";

	}

	// Page Data Rendered event
	function Page_DataRendered(&$footer) {

		// Example:
		//$footer = "your footer";

	}

	// Form Custom Validate event
	function Form_CustomValidate(&$customError) {

		// Return error message in CustomError
		return TRUE;
	}
} // End class
?>