<?php
namespace PHPMaker2020\_4payadmin;

/**
 * Page class
 */
class invoices_edit extends invoices
{

	// Page ID
	public $PageID = "edit";

	// Project ID
	public $ProjectID = "{153C2D2E-60EE-4944-8753-3935EB38E8D6}";

	// Table name
	public $TableName = 'invoices';

	// Page object name
	public $PageObjName = "invoices_edit";

	// Audit Trail
	public $AuditTrailOnAdd = TRUE;
	public $AuditTrailOnEdit = TRUE;
	public $AuditTrailOnDelete = TRUE;
	public $AuditTrailOnView = FALSE;
	public $AuditTrailOnViewData = FALSE;
	public $AuditTrailOnSearch = FALSE;

	// Page headings
	public $Heading = "";
	public $Subheading = "";
	public $PageHeader;
	public $PageFooter;

	// Token
	public $Token = "";
	public $TokenTimeout = 0;
	public $CheckToken;

	// Page heading
	public function pageHeading()
	{
		global $Language;
		if ($this->Heading != "")
			return $this->Heading;
		if (method_exists($this, "tableCaption"))
			return $this->tableCaption();
		return "";
	}

	// Page subheading
	public function pageSubheading()
	{
		global $Language;
		if ($this->Subheading != "")
			return $this->Subheading;
		if ($this->TableName)
			return $Language->phrase($this->PageID);
		return "";
	}

	// Page name
	public function pageName()
	{
		return CurrentPageName();
	}

	// Page URL
	public function pageUrl()
	{
		$url = CurrentPageName() . "?";
		if ($this->UseTokenInUrl)
			$url .= "t=" . $this->TableVar . "&"; // Add page token
		return $url;
	}

	// Messages
	private $_message = "";
	private $_failureMessage = "";
	private $_successMessage = "";
	private $_warningMessage = "";

	// Get message
	public function getMessage()
	{
		return isset($_SESSION[SESSION_MESSAGE]) ? $_SESSION[SESSION_MESSAGE] : $this->_message;
	}

	// Set message
	public function setMessage($v)
	{
		AddMessage($this->_message, $v);
		$_SESSION[SESSION_MESSAGE] = $this->_message;
	}

	// Get failure message
	public function getFailureMessage()
	{
		return isset($_SESSION[SESSION_FAILURE_MESSAGE]) ? $_SESSION[SESSION_FAILURE_MESSAGE] : $this->_failureMessage;
	}

	// Set failure message
	public function setFailureMessage($v)
	{
		AddMessage($this->_failureMessage, $v);
		$_SESSION[SESSION_FAILURE_MESSAGE] = $this->_failureMessage;
	}

	// Get success message
	public function getSuccessMessage()
	{
		return isset($_SESSION[SESSION_SUCCESS_MESSAGE]) ? $_SESSION[SESSION_SUCCESS_MESSAGE] : $this->_successMessage;
	}

	// Set success message
	public function setSuccessMessage($v)
	{
		AddMessage($this->_successMessage, $v);
		$_SESSION[SESSION_SUCCESS_MESSAGE] = $this->_successMessage;
	}

	// Get warning message
	public function getWarningMessage()
	{
		return isset($_SESSION[SESSION_WARNING_MESSAGE]) ? $_SESSION[SESSION_WARNING_MESSAGE] : $this->_warningMessage;
	}

	// Set warning message
	public function setWarningMessage($v)
	{
		AddMessage($this->_warningMessage, $v);
		$_SESSION[SESSION_WARNING_MESSAGE] = $this->_warningMessage;
	}

	// Clear message
	public function clearMessage()
	{
		$this->_message = "";
		$_SESSION[SESSION_MESSAGE] = "";
	}

	// Clear failure message
	public function clearFailureMessage()
	{
		$this->_failureMessage = "";
		$_SESSION[SESSION_FAILURE_MESSAGE] = "";
	}

	// Clear success message
	public function clearSuccessMessage()
	{
		$this->_successMessage = "";
		$_SESSION[SESSION_SUCCESS_MESSAGE] = "";
	}

	// Clear warning message
	public function clearWarningMessage()
	{
		$this->_warningMessage = "";
		$_SESSION[SESSION_WARNING_MESSAGE] = "";
	}

	// Clear messages
	public function clearMessages()
	{
		$this->clearMessage();
		$this->clearFailureMessage();
		$this->clearSuccessMessage();
		$this->clearWarningMessage();
	}

	// Show message
	public function showMessage()
	{
		$hidden = FALSE;
		$html = "";

		// Message
		$message = $this->getMessage();
		if (method_exists($this, "Message_Showing"))
			$this->Message_Showing($message, "");
		if ($message != "") { // Message in Session, display
			if (!$hidden)
				$message = '<button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button>' . $message;
			$html .= '<div class="alert alert-info alert-dismissible ew-info"><i class="icon fas fa-info"></i>' . $message . '</div>';
			$_SESSION[SESSION_MESSAGE] = ""; // Clear message in Session
		}

		// Warning message
		$warningMessage = $this->getWarningMessage();
		if (method_exists($this, "Message_Showing"))
			$this->Message_Showing($warningMessage, "warning");
		if ($warningMessage != "") { // Message in Session, display
			if (!$hidden)
				$warningMessage = '<button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button>' . $warningMessage;
			$html .= '<div class="alert alert-warning alert-dismissible ew-warning"><i class="icon fas fa-exclamation"></i>' . $warningMessage . '</div>';
			$_SESSION[SESSION_WARNING_MESSAGE] = ""; // Clear message in Session
		}

		// Success message
		$successMessage = $this->getSuccessMessage();
		if (method_exists($this, "Message_Showing"))
			$this->Message_Showing($successMessage, "success");
		if ($successMessage != "") { // Message in Session, display
			if (!$hidden)
				$successMessage = '<button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button>' . $successMessage;
			$html .= '<div class="alert alert-success alert-dismissible ew-success"><i class="icon fas fa-check"></i>' . $successMessage . '</div>';
			$_SESSION[SESSION_SUCCESS_MESSAGE] = ""; // Clear message in Session
		}

		// Failure message
		$errorMessage = $this->getFailureMessage();
		if (method_exists($this, "Message_Showing"))
			$this->Message_Showing($errorMessage, "failure");
		if ($errorMessage != "") { // Message in Session, display
			if (!$hidden)
				$errorMessage = '<button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button>' . $errorMessage;
			$html .= '<div class="alert alert-danger alert-dismissible ew-error"><i class="icon fas fa-ban"></i>' . $errorMessage . '</div>';
			$_SESSION[SESSION_FAILURE_MESSAGE] = ""; // Clear message in Session
		}
		echo '<div class="ew-message-dialog' . (($hidden) ? ' d-none' : "") . '">' . $html . '</div>';
	}

	// Get message as array
	public function getMessages()
	{
		$ar = [];

		// Message
		$message = $this->getMessage();

		//if (method_exists($this, "Message_Showing"))
		//	$this->Message_Showing($message, "");

		if ($message != "") { // Message in Session, display
			$ar["message"] = $message;
			$_SESSION[SESSION_MESSAGE] = ""; // Clear message in Session
		}

		// Warning message
		$warningMessage = $this->getWarningMessage();

		//if (method_exists($this, "Message_Showing"))
		//	$this->Message_Showing($warningMessage, "warning");

		if ($warningMessage != "") { // Message in Session, display
			$ar["warningMessage"] = $warningMessage;
			$_SESSION[SESSION_WARNING_MESSAGE] = ""; // Clear message in Session
		}

		// Success message
		$successMessage = $this->getSuccessMessage();

		//if (method_exists($this, "Message_Showing"))
		//	$this->Message_Showing($successMessage, "success");

		if ($successMessage != "") { // Message in Session, display
			$ar["successMessage"] = $successMessage;
			$_SESSION[SESSION_SUCCESS_MESSAGE] = ""; // Clear message in Session
		}

		// Failure message
		$failureMessage = $this->getFailureMessage();

		//if (method_exists($this, "Message_Showing"))
		//	$this->Message_Showing($failureMessage, "failure");

		if ($failureMessage != "") { // Message in Session, display
			$ar["failureMessage"] = $failureMessage;
			$_SESSION[SESSION_FAILURE_MESSAGE] = ""; // Clear message in Session
		}
		return $ar;
	}

	// Show Page Header
	public function showPageHeader()
	{
		$header = $this->PageHeader;
		$this->Page_DataRendering($header);
		if ($header != "") { // Header exists, display
			echo '<p id="ew-page-header">' . $header . '</p>';
		}
	}

	// Show Page Footer
	public function showPageFooter()
	{
		$footer = $this->PageFooter;
		$this->Page_DataRendered($footer);
		if ($footer != "") { // Footer exists, display
			echo '<p id="ew-page-footer">' . $footer . '</p>';
		}
	}

	// Validate page request
	protected function isPageRequest()
	{
		global $CurrentForm;
		if ($this->UseTokenInUrl) {
			if ($CurrentForm)
				return ($this->TableVar == $CurrentForm->getValue("t"));
			if (Get("t") !== NULL)
				return ($this->TableVar == Get("t"));
		}
		return TRUE;
	}

	// Valid Post
	protected function validPost()
	{
		if (!$this->CheckToken || !IsPost() || IsApi())
			return TRUE;
		if (Post(Config("TOKEN_NAME")) === NULL)
			return FALSE;
		$fn = Config("CHECK_TOKEN_FUNC");
		if (is_callable($fn))
			return $fn(Post(Config("TOKEN_NAME")), $this->TokenTimeout);
		return FALSE;
	}

	// Create Token
	public function createToken()
	{
		global $CurrentToken;
		$fn = Config("CREATE_TOKEN_FUNC"); // Always create token, required by API file/lookup request
		if ($this->Token == "" && is_callable($fn)) // Create token
			$this->Token = $fn();
		$CurrentToken = $this->Token; // Save to global variable
	}

	// Constructor
	public function __construct()
	{
		global $Language, $DashboardReport;
		global $UserTable;

		// Check token
		$this->CheckToken = Config("CHECK_TOKEN");

		// Initialize
		$GLOBALS["Page"] = &$this;
		$this->TokenTimeout = SessionTimeoutTime();

		// Language object
		if (!isset($Language))
			$Language = new Language();

		// Parent constuctor
		parent::__construct();

		// Table object (invoices)
		if (!isset($GLOBALS["invoices"]) || get_class($GLOBALS["invoices"]) == PROJECT_NAMESPACE . "invoices") {
			$GLOBALS["invoices"] = &$this;
			$GLOBALS["Table"] = &$GLOBALS["invoices"];
		}

		// Table object (admin)
		if (!isset($GLOBALS['admin']))
			$GLOBALS['admin'] = new admin();

		// Page ID (for backward compatibility only)
		if (!defined(PROJECT_NAMESPACE . "PAGE_ID"))
			define(PROJECT_NAMESPACE . "PAGE_ID", 'edit');

		// Table name (for backward compatibility only)
		if (!defined(PROJECT_NAMESPACE . "TABLE_NAME"))
			define(PROJECT_NAMESPACE . "TABLE_NAME", 'invoices');

		// Start timer
		if (!isset($GLOBALS["DebugTimer"]))
			$GLOBALS["DebugTimer"] = new Timer();

		// Debug message
		LoadDebugMessage();

		// Open connection
		if (!isset($GLOBALS["Conn"]))
			$GLOBALS["Conn"] = $this->getConnection();

		// User table object (admin)
		$UserTable = $UserTable ?: new admin();
	}

	// Terminate page
	public function terminate($url = "")
	{
		global $ExportFileName, $TempImages, $DashboardReport;

		// Page Unload event
		$this->Page_Unload();

		// Global Page Unloaded event (in userfn*.php)
		Page_Unloaded();

		// Export
		global $invoices;
		if ($this->CustomExport && $this->CustomExport == $this->Export && array_key_exists($this->CustomExport, Config("EXPORT_CLASSES"))) {
				$content = ob_get_contents();
			if ($ExportFileName == "")
				$ExportFileName = $this->TableVar;
			$class = PROJECT_NAMESPACE . Config("EXPORT_CLASSES." . $this->CustomExport);
			if (class_exists($class)) {
				$doc = new $class($invoices);
				$doc->Text = @$content;
				if ($this->isExport("email"))
					echo $this->exportEmail($doc->Text);
				else
					$doc->export();
				DeleteTempImages(); // Delete temp images
				exit();
			}
		}
		if (!IsApi())
			$this->Page_Redirecting($url);

		// Close connection
		CloseConnections();

		// Return for API
		if (IsApi()) {
			$res = $url === TRUE;
			if (!$res) // Show error
				WriteJson(array_merge(["success" => FALSE], $this->getMessages()));
			return;
		}

		// Go to URL if specified
		if ($url != "") {
			if (!Config("DEBUG") && ob_get_length())
				ob_end_clean();

			// Handle modal response
			if ($this->IsModal) { // Show as modal
				$row = ["url" => $url, "modal" => "1"];
				$pageName = GetPageName($url);
				if ($pageName != $this->getListUrl()) { // Not List page
					$row["caption"] = $this->getModalCaption($pageName);
					if ($pageName == "invoicesview.php")
						$row["view"] = "1";
				} else { // List page should not be shown as modal => error
					$row["error"] = $this->getFailureMessage();
					$this->clearFailureMessage();
				}
				WriteJson($row);
			} else {
				SaveDebugMessage();
				AddHeader("Location", $url);
			}
		}
		exit();
	}

	// Get records from recordset
	protected function getRecordsFromRecordset($rs, $current = FALSE)
	{
		$rows = [];
		if (is_object($rs)) { // Recordset
			while ($rs && !$rs->EOF) {
				$this->loadRowValues($rs); // Set up DbValue/CurrentValue
				$row = $this->getRecordFromArray($rs->fields);
				if ($current)
					return $row;
				else
					$rows[] = $row;
				$rs->moveNext();
			}
		} elseif (is_array($rs)) {
			foreach ($rs as $ar) {
				$row = $this->getRecordFromArray($ar);
				if ($current)
					return $row;
				else
					$rows[] = $row;
			}
		}
		return $rows;
	}

	// Get record from array
	protected function getRecordFromArray($ar)
	{
		$row = [];
		if (is_array($ar)) {
			foreach ($ar as $fldname => $val) {
				if (array_key_exists($fldname, $this->fields) && ($this->fields[$fldname]->Visible || $this->fields[$fldname]->IsPrimaryKey)) { // Primary key or Visible
					$fld = &$this->fields[$fldname];
					if ($fld->HtmlTag == "FILE") { // Upload field
						if (EmptyValue($val)) {
							$row[$fldname] = NULL;
						} else {
							if ($fld->DataType == DATATYPE_BLOB) {
								$url = FullUrl(GetApiUrl(Config("API_FILE_ACTION"),
									Config("API_OBJECT_NAME") . "=" . $fld->TableVar . "&" .
									Config("API_FIELD_NAME") . "=" . $fld->Param . "&" .
									Config("API_KEY_NAME") . "=" . rawurlencode($this->getRecordKeyValue($ar)))); //*** need to add this? API may not be in the same folder
								$row[$fldname] = ["type" => ContentType($val), "url" => $url, "name" => $fld->Param . ContentExtension($val)];
							} elseif (!$fld->UploadMultiple || !ContainsString($val, Config("MULTIPLE_UPLOAD_SEPARATOR"))) { // Single file
								$url = FullUrl(GetApiUrl(Config("API_FILE_ACTION"),
									Config("API_OBJECT_NAME") . "=" . $fld->TableVar . "&" .
									"fn=" . Encrypt($fld->physicalUploadPath() . $val)));
								$row[$fldname] = ["type" => MimeContentType($val), "url" => $url, "name" => $val];
							} else { // Multiple files
								$files = explode(Config("MULTIPLE_UPLOAD_SEPARATOR"), $val);
								$ar = [];
								foreach ($files as $file) {
									$url = FullUrl(GetApiUrl(Config("API_FILE_ACTION"),
										Config("API_OBJECT_NAME") . "=" . $fld->TableVar . "&" .
										"fn=" . Encrypt($fld->physicalUploadPath() . $file)));
									if (!EmptyValue($file))
										$ar[] = ["type" => MimeContentType($file), "url" => $url, "name" => $file];
								}
								$row[$fldname] = $ar;
							}
						}
					} else {
						$row[$fldname] = $val;
					}
				}
			}
		}
		return $row;
	}

	// Get record key value from array
	protected function getRecordKeyValue($ar)
	{
		$key = "";
		if (is_array($ar)) {
			$key .= @$ar['invoiceid'];
		}
		return $key;
	}

	/**
	 * Hide fields for add/edit
	 *
	 * @return void
	 */
	protected function hideFieldsForAddEdit()
	{
		if ($this->isAdd() || $this->isCopy() || $this->isGridAdd())
			$this->invoiceid->Visible = FALSE;
	}

	// Lookup data
	public function lookup()
	{
		global $Language, $Security;
		if (!isset($Language))
			$Language = new Language(Config("LANGUAGE_FOLDER"), Post("language", ""));

		// Set up API request
		if (!ValidApiRequest())
			return FALSE;
		$this->setupApiSecurity();

		// Get lookup object
		$fieldName = Post("field");
		if (!array_key_exists($fieldName, $this->fields))
			return FALSE;
		$lookupField = $this->fields[$fieldName];
		$lookup = $lookupField->Lookup;
		if ($lookup === NULL)
			return FALSE;
		$tbl = $lookup->getTable();
		if (!$Security->allowLookup(Config("PROJECT_ID") . $tbl->TableName)) // Lookup permission
			return FALSE;

		// Get lookup parameters
		$lookupType = Post("ajax", "unknown");
		$pageSize = -1;
		$offset = -1;
		$searchValue = "";
		if (SameText($lookupType, "modal")) {
			$searchValue = Post("sv", "");
			$pageSize = Post("recperpage", 10);
			$offset = Post("start", 0);
		} elseif (SameText($lookupType, "autosuggest")) {
			$searchValue = Param("q", "");
			$pageSize = Param("n", -1);
			$pageSize = is_numeric($pageSize) ? (int)$pageSize : -1;
			if ($pageSize <= 0)
				$pageSize = Config("AUTO_SUGGEST_MAX_ENTRIES");
			$start = Param("start", -1);
			$start = is_numeric($start) ? (int)$start : -1;
			$page = Param("page", -1);
			$page = is_numeric($page) ? (int)$page : -1;
			$offset = $start >= 0 ? $start : ($page > 0 && $pageSize > 0 ? ($page - 1) * $pageSize : 0);
		}
		$userSelect = Decrypt(Post("s", ""));
		$userFilter = Decrypt(Post("f", ""));
		$userOrderBy = Decrypt(Post("o", ""));
		$keys = Post("keys");
		$lookup->LookupType = $lookupType; // Lookup type
		if ($keys !== NULL) { // Selected records from modal
			if (is_array($keys))
				$keys = implode(Config("MULTIPLE_OPTION_SEPARATOR"), $keys);
			$lookup->FilterFields = []; // Skip parent fields if any
			$lookup->FilterValues[] = $keys; // Lookup values
			$pageSize = -1; // Show all records
		} else { // Lookup values
			$lookup->FilterValues[] = Post("v0", Post("lookupValue", ""));
		}
		$cnt = is_array($lookup->FilterFields) ? count($lookup->FilterFields) : 0;
		for ($i = 1; $i <= $cnt; $i++)
			$lookup->FilterValues[] = Post("v" . $i, "");
		$lookup->SearchValue = $searchValue;
		$lookup->PageSize = $pageSize;
		$lookup->Offset = $offset;
		if ($userSelect != "")
			$lookup->UserSelect = $userSelect;
		if ($userFilter != "")
			$lookup->UserFilter = $userFilter;
		if ($userOrderBy != "")
			$lookup->UserOrderBy = $userOrderBy;
		$lookup->toJson($this); // Use settings from current page
	}

	// Set up API security
	public function setupApiSecurity()
	{
		global $Security;

		// Setup security for API request
		if ($Security->isLoggedIn()) $Security->TablePermission_Loading();
		$Security->loadCurrentUserLevel(Config("PROJECT_ID") . $this->TableName);
		if ($Security->isLoggedIn()) $Security->TablePermission_Loaded();
	}
	public $FormClassName = "ew-horizontal ew-form ew-edit-form";
	public $IsModal = FALSE;
	public $IsMobileOrModal = FALSE;
	public $DbMasterFilter;
	public $DbDetailFilter;

	//
	// Page run
	//

	public function run()
	{
		global $ExportType, $CustomExportType, $ExportFileName, $UserProfile, $Language, $Security, $CurrentForm,
			$FormError, $SkipHeaderFooter;

		// Is modal
		$this->IsModal = (Param("modal") == "1");

		// User profile
		$UserProfile = new UserProfile();

		// Security
		if (ValidApiRequest()) { // API request
			$this->setupApiSecurity(); // Set up API Security
			if (!$Security->canEdit()) {
				SetStatus(401); // Unauthorized
				return;
			}
		} else {
			$Security = new AdvancedSecurity();
			if (IsPasswordExpired())
				$this->terminate(GetUrl("changepwd.php"));
			if (!$Security->isLoggedIn())
				$Security->autoLogin();
			if ($Security->isLoggedIn())
				$Security->TablePermission_Loading();
			$Security->loadCurrentUserLevel($this->ProjectID . $this->TableName);
			if ($Security->isLoggedIn())
				$Security->TablePermission_Loaded();
			if (!$Security->canEdit()) {
				$Security->saveLastUrl();
				$this->setFailureMessage(DeniedMessage()); // Set no permission
				if ($Security->canList())
					$this->terminate(GetUrl("invoiceslist.php"));
				else
					$this->terminate(GetUrl("login.php"));
				return;
			}
		}

		// Create form object
		$CurrentForm = new HttpForm();
		$this->CurrentAction = Param("action"); // Set up current action
		$this->invoiceid->setVisibility();
		$this->invoicerefno->setVisibility();
		$this->invoicedate->setVisibility();
		$this->duedate->setVisibility();
		$this->merchantid->setVisibility();
		$this->memberid->setVisibility();
		$this->additionalmessage->setVisibility();
		$this->currencycode->setVisibility();
		$this->currencycodesettlement->setVisibility();
		$this->lastupdatedate->setVisibility();
		$this->status->setVisibility();
		$this->customstatus->setVisibility();
		$this->useritemrecid->setVisibility();
		$this->otherdata->setVisibility();
		$this->salesrepid->setVisibility();
		$this->customerid->setVisibility();
		$this->amount->setVisibility();
		$this->paid->setVisibility();
		$this->transactionfee->setVisibility();
		$this->rate->setVisibility();
		$this->expirydate->setVisibility();
		$this->filename->setVisibility();
		$this->otherdata2->setVisibility();
		$this->otherdata3->setVisibility();
		$this->supplierid->setVisibility();
		$this->settlementamount->setVisibility();
		$this->creationdate->setVisibility();
		$this->hideFieldsForAddEdit();

		// Do not use lookup cache
		$this->setUseLookupCache(FALSE);

		// Global Page Loading event (in userfn*.php)
		Page_Loading();

		// Page Load event
		$this->Page_Load();

		// Check token
		if (!$this->validPost()) {
			Write($Language->phrase("InvalidPostRequest"));
			$this->terminate();
		}

		// Create Token
		$this->createToken();

		// Set up lookup cache
		$this->setupLookupOptions($this->customstatus);
		$this->setupLookupOptions($this->salesrepid);
		$this->setupLookupOptions($this->customerid);
		$this->setupLookupOptions($this->supplierid);

		// Check permission
		if (!$Security->canEdit()) {
			$this->setFailureMessage(DeniedMessage()); // No permission
			$this->terminate("invoiceslist.php");
			return;
		}

		// Check modal
		if ($this->IsModal)
			$SkipHeaderFooter = TRUE;
		$this->IsMobileOrModal = IsMobile() || $this->IsModal;
		$this->FormClassName = "ew-form ew-edit-form ew-horizontal";
		$loaded = FALSE;
		$postBack = FALSE;

		// Set up current action and primary key
		if (IsApi()) {

			// Load key values
			$loaded = TRUE;
			if (Get("invoiceid") !== NULL) {
				$this->invoiceid->setQueryStringValue(Get("invoiceid"));
				$this->invoiceid->setOldValue($this->invoiceid->QueryStringValue);
			} elseif (Key(0) !== NULL) {
				$this->invoiceid->setQueryStringValue(Key(0));
				$this->invoiceid->setOldValue($this->invoiceid->QueryStringValue);
			} elseif (Post("invoiceid") !== NULL) {
				$this->invoiceid->setFormValue(Post("invoiceid"));
				$this->invoiceid->setOldValue($this->invoiceid->FormValue);
			} elseif (Route(2) !== NULL) {
				$this->invoiceid->setQueryStringValue(Route(2));
				$this->invoiceid->setOldValue($this->invoiceid->QueryStringValue);
			} else {
				$loaded = FALSE; // Unable to load key
			}

			// Load record
			if ($loaded)
				$loaded = $this->loadRow();
			if (!$loaded) {
				$this->setFailureMessage($Language->phrase("NoRecord")); // Set no record message
				$this->terminate();
				return;
			}
			$this->CurrentAction = "update"; // Update record directly
			$postBack = TRUE;
		} else {
			if (Post("action") !== NULL) {
				$this->CurrentAction = Post("action"); // Get action code
				if (!$this->isShow()) // Not reload record, handle as postback
					$postBack = TRUE;

				// Load key from Form
				if ($CurrentForm->hasValue("x_invoiceid")) {
					$this->invoiceid->setFormValue($CurrentForm->getValue("x_invoiceid"));
				}
			} else {
				$this->CurrentAction = "show"; // Default action is display

				// Load key from QueryString / Route
				$loadByQuery = FALSE;
				if (Get("invoiceid") !== NULL) {
					$this->invoiceid->setQueryStringValue(Get("invoiceid"));
					$loadByQuery = TRUE;
				} elseif (Route(2) !== NULL) {
					$this->invoiceid->setQueryStringValue(Route(2));
					$loadByQuery = TRUE;
				} else {
					$this->invoiceid->CurrentValue = NULL;
				}
			}

			// Load current record
			$loaded = $this->loadRow();
		}

		// Process form if post back
		if ($postBack) {
			$this->loadFormValues(); // Get form values

			// Set up detail parameters
			$this->setupDetailParms();
		}

		// Validate form if post back
		if ($postBack) {
			if (!$this->validateForm()) {
				$this->setFailureMessage($FormError);
				$this->EventCancelled = TRUE; // Event cancelled
				$this->restoreFormValues();
				if (IsApi()) {
					$this->terminate();
					return;
				} else {
					$this->CurrentAction = ""; // Form error, reset action
				}
			}
		}

		// Perform current action
		switch ($this->CurrentAction) {
			case "show": // Get a record to display
				if (!$loaded) { // Load record based on key
					if ($this->getFailureMessage() == "")
						$this->setFailureMessage($Language->phrase("NoRecord")); // No record found
					$this->terminate("invoiceslist.php"); // No matching record, return to list
				}

				// Set up detail parameters
				$this->setupDetailParms();
				break;
			case "update": // Update
				if ($this->getCurrentDetailTable() != "") // Master/detail edit
					$returnUrl = $this->getViewUrl(Config("TABLE_SHOW_DETAIL") . "=" . $this->getCurrentDetailTable()); // Master/Detail view page
				else
					$returnUrl = $this->getReturnUrl();
				if (GetPageName($returnUrl) == "invoiceslist.php")
					$returnUrl = $this->addMasterUrl($returnUrl); // List page, return to List page with correct master key if necessary
				$this->SendEmail = TRUE; // Send email on update success
				if ($this->editRow()) { // Update record based on key
					if ($this->getSuccessMessage() == "")
						$this->setSuccessMessage($Language->phrase("UpdateSuccess")); // Update success
					if (IsApi()) {
						$this->terminate(TRUE);
						return;
					} else {
						$this->terminate($returnUrl); // Return to caller
					}
				} elseif (IsApi()) { // API request, return
					$this->terminate();
					return;
				} elseif ($this->getFailureMessage() == $Language->phrase("NoRecord")) {
					$this->terminate($returnUrl); // Return to caller
				} else {
					$this->EventCancelled = TRUE; // Event cancelled
					$this->restoreFormValues(); // Restore form values if update failed

					// Set up detail parameters
					$this->setupDetailParms();
				}
		}

		// Set up Breadcrumb
		$this->setupBreadcrumb();

		// Render the record
		$this->RowType = ROWTYPE_EDIT; // Render as Edit
		$this->resetAttributes();
		$this->renderRow();
	}

	// Get upload files
	protected function getUploadFiles()
	{
		global $CurrentForm, $Language;
	}

	// Load form values
	protected function loadFormValues()
	{

		// Load from form
		global $CurrentForm;

		// Check field name 'invoiceid' first before field var 'x_invoiceid'
		$val = $CurrentForm->hasValue("invoiceid") ? $CurrentForm->getValue("invoiceid") : $CurrentForm->getValue("x_invoiceid");
		if (!$this->invoiceid->IsDetailKey)
			$this->invoiceid->setFormValue($val);

		// Check field name 'invoicerefno' first before field var 'x_invoicerefno'
		$val = $CurrentForm->hasValue("invoicerefno") ? $CurrentForm->getValue("invoicerefno") : $CurrentForm->getValue("x_invoicerefno");
		if (!$this->invoicerefno->IsDetailKey) {
			if (IsApi() && $val === NULL)
				$this->invoicerefno->Visible = FALSE; // Disable update for API request
			else
				$this->invoicerefno->setFormValue($val);
		}

		// Check field name 'invoicedate' first before field var 'x_invoicedate'
		$val = $CurrentForm->hasValue("invoicedate") ? $CurrentForm->getValue("invoicedate") : $CurrentForm->getValue("x_invoicedate");
		if (!$this->invoicedate->IsDetailKey) {
			if (IsApi() && $val === NULL)
				$this->invoicedate->Visible = FALSE; // Disable update for API request
			else
				$this->invoicedate->setFormValue($val);
			$this->invoicedate->CurrentValue = UnFormatDateTime($this->invoicedate->CurrentValue, 0);
		}

		// Check field name 'duedate' first before field var 'x_duedate'
		$val = $CurrentForm->hasValue("duedate") ? $CurrentForm->getValue("duedate") : $CurrentForm->getValue("x_duedate");
		if (!$this->duedate->IsDetailKey) {
			if (IsApi() && $val === NULL)
				$this->duedate->Visible = FALSE; // Disable update for API request
			else
				$this->duedate->setFormValue($val);
			$this->duedate->CurrentValue = UnFormatDateTime($this->duedate->CurrentValue, 0);
		}

		// Check field name 'merchantid' first before field var 'x_merchantid'
		$val = $CurrentForm->hasValue("merchantid") ? $CurrentForm->getValue("merchantid") : $CurrentForm->getValue("x_merchantid");
		if (!$this->merchantid->IsDetailKey) {
			if (IsApi() && $val === NULL)
				$this->merchantid->Visible = FALSE; // Disable update for API request
			else
				$this->merchantid->setFormValue($val);
		}

		// Check field name 'memberid' first before field var 'x_memberid'
		$val = $CurrentForm->hasValue("memberid") ? $CurrentForm->getValue("memberid") : $CurrentForm->getValue("x_memberid");
		if (!$this->memberid->IsDetailKey) {
			if (IsApi() && $val === NULL)
				$this->memberid->Visible = FALSE; // Disable update for API request
			else
				$this->memberid->setFormValue($val);
		}

		// Check field name 'additionalmessage' first before field var 'x_additionalmessage'
		$val = $CurrentForm->hasValue("additionalmessage") ? $CurrentForm->getValue("additionalmessage") : $CurrentForm->getValue("x_additionalmessage");
		if (!$this->additionalmessage->IsDetailKey) {
			if (IsApi() && $val === NULL)
				$this->additionalmessage->Visible = FALSE; // Disable update for API request
			else
				$this->additionalmessage->setFormValue($val);
		}

		// Check field name 'currencycode' first before field var 'x_currencycode'
		$val = $CurrentForm->hasValue("currencycode") ? $CurrentForm->getValue("currencycode") : $CurrentForm->getValue("x_currencycode");
		if (!$this->currencycode->IsDetailKey) {
			if (IsApi() && $val === NULL)
				$this->currencycode->Visible = FALSE; // Disable update for API request
			else
				$this->currencycode->setFormValue($val);
		}

		// Check field name 'currencycodesettlement' first before field var 'x_currencycodesettlement'
		$val = $CurrentForm->hasValue("currencycodesettlement") ? $CurrentForm->getValue("currencycodesettlement") : $CurrentForm->getValue("x_currencycodesettlement");
		if (!$this->currencycodesettlement->IsDetailKey) {
			if (IsApi() && $val === NULL)
				$this->currencycodesettlement->Visible = FALSE; // Disable update for API request
			else
				$this->currencycodesettlement->setFormValue($val);
		}

		// Check field name 'lastupdatedate' first before field var 'x_lastupdatedate'
		$val = $CurrentForm->hasValue("lastupdatedate") ? $CurrentForm->getValue("lastupdatedate") : $CurrentForm->getValue("x_lastupdatedate");
		if (!$this->lastupdatedate->IsDetailKey) {
			if (IsApi() && $val === NULL)
				$this->lastupdatedate->Visible = FALSE; // Disable update for API request
			else
				$this->lastupdatedate->setFormValue($val);
			$this->lastupdatedate->CurrentValue = UnFormatDateTime($this->lastupdatedate->CurrentValue, 0);
		}

		// Check field name 'status' first before field var 'x_status'
		$val = $CurrentForm->hasValue("status") ? $CurrentForm->getValue("status") : $CurrentForm->getValue("x_status");
		if (!$this->status->IsDetailKey) {
			if (IsApi() && $val === NULL)
				$this->status->Visible = FALSE; // Disable update for API request
			else
				$this->status->setFormValue($val);
		}

		// Check field name 'customstatus' first before field var 'x_customstatus'
		$val = $CurrentForm->hasValue("customstatus") ? $CurrentForm->getValue("customstatus") : $CurrentForm->getValue("x_customstatus");
		if (!$this->customstatus->IsDetailKey) {
			if (IsApi() && $val === NULL)
				$this->customstatus->Visible = FALSE; // Disable update for API request
			else
				$this->customstatus->setFormValue($val);
		}

		// Check field name 'useritemrecid' first before field var 'x_useritemrecid'
		$val = $CurrentForm->hasValue("useritemrecid") ? $CurrentForm->getValue("useritemrecid") : $CurrentForm->getValue("x_useritemrecid");
		if (!$this->useritemrecid->IsDetailKey) {
			if (IsApi() && $val === NULL)
				$this->useritemrecid->Visible = FALSE; // Disable update for API request
			else
				$this->useritemrecid->setFormValue($val);
		}

		// Check field name 'otherdata' first before field var 'x_otherdata'
		$val = $CurrentForm->hasValue("otherdata") ? $CurrentForm->getValue("otherdata") : $CurrentForm->getValue("x_otherdata");
		if (!$this->otherdata->IsDetailKey) {
			if (IsApi() && $val === NULL)
				$this->otherdata->Visible = FALSE; // Disable update for API request
			else
				$this->otherdata->setFormValue($val);
		}

		// Check field name 'salesrepid' first before field var 'x_salesrepid'
		$val = $CurrentForm->hasValue("salesrepid") ? $CurrentForm->getValue("salesrepid") : $CurrentForm->getValue("x_salesrepid");
		if (!$this->salesrepid->IsDetailKey) {
			if (IsApi() && $val === NULL)
				$this->salesrepid->Visible = FALSE; // Disable update for API request
			else
				$this->salesrepid->setFormValue($val);
		}

		// Check field name 'customerid' first before field var 'x_customerid'
		$val = $CurrentForm->hasValue("customerid") ? $CurrentForm->getValue("customerid") : $CurrentForm->getValue("x_customerid");
		if (!$this->customerid->IsDetailKey) {
			if (IsApi() && $val === NULL)
				$this->customerid->Visible = FALSE; // Disable update for API request
			else
				$this->customerid->setFormValue($val);
		}

		// Check field name 'amount' first before field var 'x_amount'
		$val = $CurrentForm->hasValue("amount") ? $CurrentForm->getValue("amount") : $CurrentForm->getValue("x_amount");
		if (!$this->amount->IsDetailKey) {
			if (IsApi() && $val === NULL)
				$this->amount->Visible = FALSE; // Disable update for API request
			else
				$this->amount->setFormValue($val);
		}

		// Check field name 'paid' first before field var 'x_paid'
		$val = $CurrentForm->hasValue("paid") ? $CurrentForm->getValue("paid") : $CurrentForm->getValue("x_paid");
		if (!$this->paid->IsDetailKey) {
			if (IsApi() && $val === NULL)
				$this->paid->Visible = FALSE; // Disable update for API request
			else
				$this->paid->setFormValue($val);
		}

		// Check field name 'transactionfee' first before field var 'x_transactionfee'
		$val = $CurrentForm->hasValue("transactionfee") ? $CurrentForm->getValue("transactionfee") : $CurrentForm->getValue("x_transactionfee");
		if (!$this->transactionfee->IsDetailKey) {
			if (IsApi() && $val === NULL)
				$this->transactionfee->Visible = FALSE; // Disable update for API request
			else
				$this->transactionfee->setFormValue($val);
		}

		// Check field name 'rate' first before field var 'x_rate'
		$val = $CurrentForm->hasValue("rate") ? $CurrentForm->getValue("rate") : $CurrentForm->getValue("x_rate");
		if (!$this->rate->IsDetailKey) {
			if (IsApi() && $val === NULL)
				$this->rate->Visible = FALSE; // Disable update for API request
			else
				$this->rate->setFormValue($val);
		}

		// Check field name 'expirydate' first before field var 'x_expirydate'
		$val = $CurrentForm->hasValue("expirydate") ? $CurrentForm->getValue("expirydate") : $CurrentForm->getValue("x_expirydate");
		if (!$this->expirydate->IsDetailKey) {
			if (IsApi() && $val === NULL)
				$this->expirydate->Visible = FALSE; // Disable update for API request
			else
				$this->expirydate->setFormValue($val);
			$this->expirydate->CurrentValue = UnFormatDateTime($this->expirydate->CurrentValue, 0);
		}

		// Check field name 'filename' first before field var 'x_filename'
		$val = $CurrentForm->hasValue("filename") ? $CurrentForm->getValue("filename") : $CurrentForm->getValue("x_filename");
		if (!$this->filename->IsDetailKey) {
			if (IsApi() && $val === NULL)
				$this->filename->Visible = FALSE; // Disable update for API request
			else
				$this->filename->setFormValue($val);
		}

		// Check field name 'otherdata2' first before field var 'x_otherdata2'
		$val = $CurrentForm->hasValue("otherdata2") ? $CurrentForm->getValue("otherdata2") : $CurrentForm->getValue("x_otherdata2");
		if (!$this->otherdata2->IsDetailKey) {
			if (IsApi() && $val === NULL)
				$this->otherdata2->Visible = FALSE; // Disable update for API request
			else
				$this->otherdata2->setFormValue($val);
		}

		// Check field name 'otherdata3' first before field var 'x_otherdata3'
		$val = $CurrentForm->hasValue("otherdata3") ? $CurrentForm->getValue("otherdata3") : $CurrentForm->getValue("x_otherdata3");
		if (!$this->otherdata3->IsDetailKey) {
			if (IsApi() && $val === NULL)
				$this->otherdata3->Visible = FALSE; // Disable update for API request
			else
				$this->otherdata3->setFormValue($val);
		}

		// Check field name 'supplierid' first before field var 'x_supplierid'
		$val = $CurrentForm->hasValue("supplierid") ? $CurrentForm->getValue("supplierid") : $CurrentForm->getValue("x_supplierid");
		if (!$this->supplierid->IsDetailKey) {
			if (IsApi() && $val === NULL)
				$this->supplierid->Visible = FALSE; // Disable update for API request
			else
				$this->supplierid->setFormValue($val);
		}

		// Check field name 'settlementamount' first before field var 'x_settlementamount'
		$val = $CurrentForm->hasValue("settlementamount") ? $CurrentForm->getValue("settlementamount") : $CurrentForm->getValue("x_settlementamount");
		if (!$this->settlementamount->IsDetailKey) {
			if (IsApi() && $val === NULL)
				$this->settlementamount->Visible = FALSE; // Disable update for API request
			else
				$this->settlementamount->setFormValue($val);
		}

		// Check field name 'creationdate' first before field var 'x_creationdate'
		$val = $CurrentForm->hasValue("creationdate") ? $CurrentForm->getValue("creationdate") : $CurrentForm->getValue("x_creationdate");
		if (!$this->creationdate->IsDetailKey) {
			if (IsApi() && $val === NULL)
				$this->creationdate->Visible = FALSE; // Disable update for API request
			else
				$this->creationdate->setFormValue($val);
			$this->creationdate->CurrentValue = UnFormatDateTime($this->creationdate->CurrentValue, 0);
		}
	}

	// Restore form values
	public function restoreFormValues()
	{
		global $CurrentForm;
		$this->invoiceid->CurrentValue = $this->invoiceid->FormValue;
		$this->invoicerefno->CurrentValue = $this->invoicerefno->FormValue;
		$this->invoicedate->CurrentValue = $this->invoicedate->FormValue;
		$this->invoicedate->CurrentValue = UnFormatDateTime($this->invoicedate->CurrentValue, 0);
		$this->duedate->CurrentValue = $this->duedate->FormValue;
		$this->duedate->CurrentValue = UnFormatDateTime($this->duedate->CurrentValue, 0);
		$this->merchantid->CurrentValue = $this->merchantid->FormValue;
		$this->memberid->CurrentValue = $this->memberid->FormValue;
		$this->additionalmessage->CurrentValue = $this->additionalmessage->FormValue;
		$this->currencycode->CurrentValue = $this->currencycode->FormValue;
		$this->currencycodesettlement->CurrentValue = $this->currencycodesettlement->FormValue;
		$this->lastupdatedate->CurrentValue = $this->lastupdatedate->FormValue;
		$this->lastupdatedate->CurrentValue = UnFormatDateTime($this->lastupdatedate->CurrentValue, 0);
		$this->status->CurrentValue = $this->status->FormValue;
		$this->customstatus->CurrentValue = $this->customstatus->FormValue;
		$this->useritemrecid->CurrentValue = $this->useritemrecid->FormValue;
		$this->otherdata->CurrentValue = $this->otherdata->FormValue;
		$this->salesrepid->CurrentValue = $this->salesrepid->FormValue;
		$this->customerid->CurrentValue = $this->customerid->FormValue;
		$this->amount->CurrentValue = $this->amount->FormValue;
		$this->paid->CurrentValue = $this->paid->FormValue;
		$this->transactionfee->CurrentValue = $this->transactionfee->FormValue;
		$this->rate->CurrentValue = $this->rate->FormValue;
		$this->expirydate->CurrentValue = $this->expirydate->FormValue;
		$this->expirydate->CurrentValue = UnFormatDateTime($this->expirydate->CurrentValue, 0);
		$this->filename->CurrentValue = $this->filename->FormValue;
		$this->otherdata2->CurrentValue = $this->otherdata2->FormValue;
		$this->otherdata3->CurrentValue = $this->otherdata3->FormValue;
		$this->supplierid->CurrentValue = $this->supplierid->FormValue;
		$this->settlementamount->CurrentValue = $this->settlementamount->FormValue;
		$this->creationdate->CurrentValue = $this->creationdate->FormValue;
		$this->creationdate->CurrentValue = UnFormatDateTime($this->creationdate->CurrentValue, 0);
	}

	// Load row based on key values
	public function loadRow()
	{
		global $Security, $Language;
		$filter = $this->getRecordFilter();

		// Call Row Selecting event
		$this->Row_Selecting($filter);

		// Load SQL based on filter
		$this->CurrentFilter = $filter;
		$sql = $this->getCurrentSql();
		$conn = $this->getConnection();
		$res = FALSE;
		$rs = LoadRecordset($sql, $conn);
		if ($rs && !$rs->EOF) {
			$res = TRUE;
			$this->loadRowValues($rs); // Load row values
			$rs->close();
		}
		return $res;
	}

	// Load row values from recordset
	public function loadRowValues($rs = NULL)
	{
		if ($rs && !$rs->EOF)
			$row = $rs->fields;
		else
			$row = $this->newRow();

		// Call Row Selected event
		$this->Row_Selected($row);
		if (!$rs || $rs->EOF)
			return;
		$this->invoiceid->setDbValue($row['invoiceid']);
		$this->invoicerefno->setDbValue($row['invoicerefno']);
		$this->invoicedate->setDbValue($row['invoicedate']);
		$this->duedate->setDbValue($row['duedate']);
		$this->merchantid->setDbValue($row['merchantid']);
		$this->memberid->setDbValue($row['memberid']);
		$this->additionalmessage->setDbValue($row['additionalmessage']);
		$this->currencycode->setDbValue($row['currencycode']);
		$this->currencycodesettlement->setDbValue($row['currencycodesettlement']);
		$this->lastupdatedate->setDbValue($row['lastupdatedate']);
		$this->status->setDbValue($row['status']);
		$this->customstatus->setDbValue($row['customstatus']);
		$this->useritemrecid->setDbValue($row['useritemrecid']);
		$this->otherdata->setDbValue($row['otherdata']);
		$this->salesrepid->setDbValue($row['salesrepid']);
		$this->customerid->setDbValue($row['customerid']);
		$this->amount->setDbValue($row['amount']);
		$this->paid->setDbValue($row['paid']);
		$this->transactionfee->setDbValue($row['transactionfee']);
		$this->rate->setDbValue($row['rate']);
		$this->expirydate->setDbValue($row['expirydate']);
		$this->filename->setDbValue($row['filename']);
		$this->otherdata2->setDbValue($row['otherdata2']);
		$this->otherdata3->setDbValue($row['otherdata3']);
		$this->supplierid->setDbValue($row['supplierid']);
		$this->settlementamount->setDbValue($row['settlementamount']);
		$this->creationdate->setDbValue($row['creationdate']);
	}

	// Return a row with default values
	protected function newRow()
	{
		$row = [];
		$row['invoiceid'] = NULL;
		$row['invoicerefno'] = NULL;
		$row['invoicedate'] = NULL;
		$row['duedate'] = NULL;
		$row['merchantid'] = NULL;
		$row['memberid'] = NULL;
		$row['additionalmessage'] = NULL;
		$row['currencycode'] = NULL;
		$row['currencycodesettlement'] = NULL;
		$row['lastupdatedate'] = NULL;
		$row['status'] = NULL;
		$row['customstatus'] = NULL;
		$row['useritemrecid'] = NULL;
		$row['otherdata'] = NULL;
		$row['salesrepid'] = NULL;
		$row['customerid'] = NULL;
		$row['amount'] = NULL;
		$row['paid'] = NULL;
		$row['transactionfee'] = NULL;
		$row['rate'] = NULL;
		$row['expirydate'] = NULL;
		$row['filename'] = NULL;
		$row['otherdata2'] = NULL;
		$row['otherdata3'] = NULL;
		$row['supplierid'] = NULL;
		$row['settlementamount'] = NULL;
		$row['creationdate'] = NULL;
		return $row;
	}

	// Load old record
	protected function loadOldRecord()
	{

		// Load key values from Session
		$validKey = TRUE;
		if (strval($this->getKey("invoiceid")) != "")
			$this->invoiceid->OldValue = $this->getKey("invoiceid"); // invoiceid
		else
			$validKey = FALSE;

		// Load old record
		$this->OldRecordset = NULL;
		if ($validKey) {
			$this->CurrentFilter = $this->getRecordFilter();
			$sql = $this->getCurrentSql();
			$conn = $this->getConnection();
			$this->OldRecordset = LoadRecordset($sql, $conn);
		}
		$this->loadRowValues($this->OldRecordset); // Load row values
		return $validKey;
	}

	// Render row values based on field settings
	public function renderRow()
	{
		global $Security, $Language, $CurrentLanguage;

		// Initialize URLs
		// Convert decimal values if posted back

		if ($this->amount->FormValue == $this->amount->CurrentValue && is_numeric(ConvertToFloatString($this->amount->CurrentValue)))
			$this->amount->CurrentValue = ConvertToFloatString($this->amount->CurrentValue);

		// Convert decimal values if posted back
		if ($this->transactionfee->FormValue == $this->transactionfee->CurrentValue && is_numeric(ConvertToFloatString($this->transactionfee->CurrentValue)))
			$this->transactionfee->CurrentValue = ConvertToFloatString($this->transactionfee->CurrentValue);

		// Convert decimal values if posted back
		if ($this->rate->FormValue == $this->rate->CurrentValue && is_numeric(ConvertToFloatString($this->rate->CurrentValue)))
			$this->rate->CurrentValue = ConvertToFloatString($this->rate->CurrentValue);

		// Convert decimal values if posted back
		if ($this->settlementamount->FormValue == $this->settlementamount->CurrentValue && is_numeric(ConvertToFloatString($this->settlementamount->CurrentValue)))
			$this->settlementamount->CurrentValue = ConvertToFloatString($this->settlementamount->CurrentValue);

		// Call Row_Rendering event
		$this->Row_Rendering();

		// Common render codes for all row types
		// invoiceid
		// invoicerefno
		// invoicedate
		// duedate
		// merchantid
		// memberid
		// additionalmessage
		// currencycode
		// currencycodesettlement
		// lastupdatedate
		// status
		// customstatus
		// useritemrecid
		// otherdata
		// salesrepid
		// customerid
		// amount
		// paid
		// transactionfee
		// rate
		// expirydate
		// filename
		// otherdata2
		// otherdata3
		// supplierid
		// settlementamount
		// creationdate

		if ($this->RowType == ROWTYPE_VIEW) { // View row

			// invoiceid
			$this->invoiceid->ViewValue = $this->invoiceid->CurrentValue;
			$this->invoiceid->ViewCustomAttributes = "";

			// invoicerefno
			$this->invoicerefno->ViewValue = $this->invoicerefno->CurrentValue;
			$this->invoicerefno->ViewCustomAttributes = "";

			// invoicedate
			$this->invoicedate->ViewValue = $this->invoicedate->CurrentValue;
			$this->invoicedate->ViewValue = FormatDateTime($this->invoicedate->ViewValue, 0);
			$this->invoicedate->ViewCustomAttributes = "";

			// duedate
			$this->duedate->ViewValue = $this->duedate->CurrentValue;
			$this->duedate->ViewValue = FormatDateTime($this->duedate->ViewValue, 0);
			$this->duedate->ViewCustomAttributes = "";

			// merchantid
			$this->merchantid->ViewValue = $this->merchantid->CurrentValue;
			$this->merchantid->ViewCustomAttributes = "";

			// memberid
			$this->memberid->ViewValue = $this->memberid->CurrentValue;
			$this->memberid->ViewCustomAttributes = "";

			// additionalmessage
			$this->additionalmessage->ViewValue = $this->additionalmessage->CurrentValue;
			$this->additionalmessage->ViewCustomAttributes = "";

			// currencycode
			$this->currencycode->ViewValue = $this->currencycode->CurrentValue;
			$this->currencycode->ViewCustomAttributes = "";

			// currencycodesettlement
			$this->currencycodesettlement->ViewValue = $this->currencycodesettlement->CurrentValue;
			$this->currencycodesettlement->ViewCustomAttributes = "";

			// lastupdatedate
			$this->lastupdatedate->ViewValue = $this->lastupdatedate->CurrentValue;
			$this->lastupdatedate->ViewValue = FormatDateTime($this->lastupdatedate->ViewValue, 0);
			$this->lastupdatedate->ViewCustomAttributes = "";

			// status
			if (strval($this->status->CurrentValue) != "") {
				$this->status->ViewValue = $this->status->optionCaption($this->status->CurrentValue);
			} else {
				$this->status->ViewValue = NULL;
			}
			$this->status->ViewCustomAttributes = "";

			// customstatus
			$curVal = strval($this->customstatus->CurrentValue);
			if ($curVal != "") {
				$this->customstatus->ViewValue = $this->customstatus->lookupCacheOption($curVal);
				if ($this->customstatus->ViewValue === NULL) { // Lookup from database
					$filterWrk = "`statusid`" . SearchString("=", $curVal, DATATYPE_NUMBER, "_4payreference");
					$sqlWrk = $this->customstatus->Lookup->getSql(FALSE, $filterWrk, '', $this);
					$rswrk = Conn("_4payreference")->execute($sqlWrk);
					if ($rswrk && !$rswrk->EOF) { // Lookup values found
						$arwrk = [];
						$arwrk[1] = $rswrk->fields('df');
						$this->customstatus->ViewValue = $this->customstatus->displayValue($arwrk);
						$rswrk->Close();
					} else {
						$this->customstatus->ViewValue = $this->customstatus->CurrentValue;
					}
				}
			} else {
				$this->customstatus->ViewValue = NULL;
			}
			$this->customstatus->ViewCustomAttributes = "";

			// useritemrecid
			$this->useritemrecid->ViewValue = $this->useritemrecid->CurrentValue;
			$this->useritemrecid->ViewValue = FormatNumber($this->useritemrecid->ViewValue, 0, -2, -2, -2);
			$this->useritemrecid->ViewCustomAttributes = "";

			// otherdata
			$this->otherdata->ViewValue = $this->otherdata->CurrentValue;
			$this->otherdata->ViewCustomAttributes = "";

			// salesrepid
			$this->salesrepid->ViewValue = $this->salesrepid->CurrentValue;
			$curVal = strval($this->salesrepid->CurrentValue);
			if ($curVal != "") {
				$this->salesrepid->ViewValue = $this->salesrepid->lookupCacheOption($curVal);
				if ($this->salesrepid->ViewValue === NULL) { // Lookup from database
					$filterWrk = "`id`" . SearchString("=", $curVal, DATATYPE_NUMBER, "");
					$sqlWrk = $this->salesrepid->Lookup->getSql(FALSE, $filterWrk, '', $this);
					$rswrk = Conn()->execute($sqlWrk);
					if ($rswrk && !$rswrk->EOF) { // Lookup values found
						$arwrk = [];
						$arwrk[1] = $rswrk->fields('df');
						$arwrk[2] = $rswrk->fields('df2');
						$this->salesrepid->ViewValue = $this->salesrepid->displayValue($arwrk);
						$rswrk->Close();
					} else {
						$this->salesrepid->ViewValue = $this->salesrepid->CurrentValue;
					}
				}
			} else {
				$this->salesrepid->ViewValue = NULL;
			}
			$this->salesrepid->ViewCustomAttributes = "";

			// customerid
			$this->customerid->ViewValue = $this->customerid->CurrentValue;
			$curVal = strval($this->customerid->CurrentValue);
			if ($curVal != "") {
				$this->customerid->ViewValue = $this->customerid->lookupCacheOption($curVal);
				if ($this->customerid->ViewValue === NULL) { // Lookup from database
					$filterWrk = "`id`" . SearchString("=", $curVal, DATATYPE_NUMBER, "");
					$sqlWrk = $this->customerid->Lookup->getSql(FALSE, $filterWrk, '', $this);
					$rswrk = Conn()->execute($sqlWrk);
					if ($rswrk && !$rswrk->EOF) { // Lookup values found
						$arwrk = [];
						$arwrk[1] = $rswrk->fields('df');
						$arwrk[2] = $rswrk->fields('df2');
						$this->customerid->ViewValue = $this->customerid->displayValue($arwrk);
						$rswrk->Close();
					} else {
						$this->customerid->ViewValue = $this->customerid->CurrentValue;
					}
				}
			} else {
				$this->customerid->ViewValue = NULL;
			}
			$this->customerid->ViewCustomAttributes = "";

			// amount
			$this->amount->ViewValue = $this->amount->CurrentValue;
			$this->amount->ViewValue = FormatNumber($this->amount->ViewValue, 2, -2, -2, -2);
			$this->amount->ViewCustomAttributes = "";

			// paid
			$this->paid->ViewValue = $this->paid->CurrentValue;
			$this->paid->ViewCustomAttributes = "";

			// transactionfee
			$this->transactionfee->ViewValue = $this->transactionfee->CurrentValue;
			$this->transactionfee->ViewValue = FormatNumber($this->transactionfee->ViewValue, 2, -2, -2, -2);
			$this->transactionfee->ViewCustomAttributes = "";

			// rate
			$this->rate->ViewValue = $this->rate->CurrentValue;
			$this->rate->ViewValue = FormatNumber($this->rate->ViewValue, 2, -2, -2, -2);
			$this->rate->ViewCustomAttributes = "";

			// expirydate
			$this->expirydate->ViewValue = $this->expirydate->CurrentValue;
			$this->expirydate->ViewValue = FormatDateTime($this->expirydate->ViewValue, 0);
			$this->expirydate->ViewCustomAttributes = "";

			// filename
			$this->filename->ViewValue = $this->filename->CurrentValue;
			$this->filename->ViewCustomAttributes = "";

			// otherdata2
			$this->otherdata2->ViewValue = $this->otherdata2->CurrentValue;
			$this->otherdata2->ViewCustomAttributes = "";

			// otherdata3
			$this->otherdata3->ViewValue = $this->otherdata3->CurrentValue;
			$this->otherdata3->ViewCustomAttributes = "";

			// supplierid
			$this->supplierid->ViewValue = $this->supplierid->CurrentValue;
			$curVal = strval($this->supplierid->CurrentValue);
			if ($curVal != "") {
				$this->supplierid->ViewValue = $this->supplierid->lookupCacheOption($curVal);
				if ($this->supplierid->ViewValue === NULL) { // Lookup from database
					$filterWrk = "`userid`" . SearchString("=", $curVal, DATATYPE_NUMBER, "");
					$sqlWrk = $this->supplierid->Lookup->getSql(FALSE, $filterWrk, '', $this);
					$rswrk = Conn()->execute($sqlWrk);
					if ($rswrk && !$rswrk->EOF) { // Lookup values found
						$arwrk = [];
						$arwrk[1] = $rswrk->fields('df');
						$this->supplierid->ViewValue = $this->supplierid->displayValue($arwrk);
						$rswrk->Close();
					} else {
						$this->supplierid->ViewValue = $this->supplierid->CurrentValue;
					}
				}
			} else {
				$this->supplierid->ViewValue = NULL;
			}
			$this->supplierid->ViewCustomAttributes = "";

			// settlementamount
			$this->settlementamount->ViewValue = $this->settlementamount->CurrentValue;
			$this->settlementamount->ViewValue = FormatNumber($this->settlementamount->ViewValue, 2, -2, -2, -2);
			$this->settlementamount->ViewCustomAttributes = "";

			// creationdate
			$this->creationdate->ViewValue = $this->creationdate->CurrentValue;
			$this->creationdate->ViewValue = FormatDateTime($this->creationdate->ViewValue, 0);
			$this->creationdate->ViewCustomAttributes = "";

			// invoiceid
			$this->invoiceid->LinkCustomAttributes = "";
			$this->invoiceid->HrefValue = "";
			$this->invoiceid->TooltipValue = "";

			// invoicerefno
			$this->invoicerefno->LinkCustomAttributes = "";
			$this->invoicerefno->HrefValue = "";
			$this->invoicerefno->TooltipValue = "";

			// invoicedate
			$this->invoicedate->LinkCustomAttributes = "";
			$this->invoicedate->HrefValue = "";
			$this->invoicedate->TooltipValue = "";

			// duedate
			$this->duedate->LinkCustomAttributes = "";
			$this->duedate->HrefValue = "";
			$this->duedate->TooltipValue = "";

			// merchantid
			$this->merchantid->LinkCustomAttributes = "";
			$this->merchantid->HrefValue = "";
			$this->merchantid->TooltipValue = "";

			// memberid
			$this->memberid->LinkCustomAttributes = "";
			$this->memberid->HrefValue = "";
			$this->memberid->TooltipValue = "";

			// additionalmessage
			$this->additionalmessage->LinkCustomAttributes = "";
			$this->additionalmessage->HrefValue = "";
			$this->additionalmessage->TooltipValue = "";

			// currencycode
			$this->currencycode->LinkCustomAttributes = "";
			$this->currencycode->HrefValue = "";
			$this->currencycode->TooltipValue = "";

			// currencycodesettlement
			$this->currencycodesettlement->LinkCustomAttributes = "";
			$this->currencycodesettlement->HrefValue = "";
			$this->currencycodesettlement->TooltipValue = "";

			// lastupdatedate
			$this->lastupdatedate->LinkCustomAttributes = "";
			$this->lastupdatedate->HrefValue = "";
			$this->lastupdatedate->TooltipValue = "";

			// status
			$this->status->LinkCustomAttributes = "";
			$this->status->HrefValue = "";
			$this->status->TooltipValue = "";

			// customstatus
			$this->customstatus->LinkCustomAttributes = "";
			$this->customstatus->HrefValue = "";
			$this->customstatus->TooltipValue = "";

			// useritemrecid
			$this->useritemrecid->LinkCustomAttributes = "";
			$this->useritemrecid->HrefValue = "";
			$this->useritemrecid->TooltipValue = "";

			// otherdata
			$this->otherdata->LinkCustomAttributes = "";
			$this->otherdata->HrefValue = "";
			$this->otherdata->TooltipValue = "";

			// salesrepid
			$this->salesrepid->LinkCustomAttributes = "";
			$this->salesrepid->HrefValue = "";
			$this->salesrepid->TooltipValue = "";

			// customerid
			$this->customerid->LinkCustomAttributes = "";
			$this->customerid->HrefValue = "";
			$this->customerid->TooltipValue = "";

			// amount
			$this->amount->LinkCustomAttributes = "";
			$this->amount->HrefValue = "";
			$this->amount->TooltipValue = "";

			// paid
			$this->paid->LinkCustomAttributes = "";
			$this->paid->HrefValue = "";
			$this->paid->TooltipValue = "";

			// transactionfee
			$this->transactionfee->LinkCustomAttributes = "";
			$this->transactionfee->HrefValue = "";
			$this->transactionfee->TooltipValue = "";

			// rate
			$this->rate->LinkCustomAttributes = "";
			$this->rate->HrefValue = "";
			$this->rate->TooltipValue = "";

			// expirydate
			$this->expirydate->LinkCustomAttributes = "";
			$this->expirydate->HrefValue = "";
			$this->expirydate->TooltipValue = "";

			// filename
			$this->filename->LinkCustomAttributes = "";
			$this->filename->HrefValue = "";
			$this->filename->TooltipValue = "";

			// otherdata2
			$this->otherdata2->LinkCustomAttributes = "";
			$this->otherdata2->HrefValue = "";
			$this->otherdata2->TooltipValue = "";

			// otherdata3
			$this->otherdata3->LinkCustomAttributes = "";
			$this->otherdata3->HrefValue = "";
			$this->otherdata3->TooltipValue = "";

			// supplierid
			$this->supplierid->LinkCustomAttributes = "";
			$this->supplierid->HrefValue = "";
			$this->supplierid->TooltipValue = "";

			// settlementamount
			$this->settlementamount->LinkCustomAttributes = "";
			$this->settlementamount->HrefValue = "";
			$this->settlementamount->TooltipValue = "";

			// creationdate
			$this->creationdate->LinkCustomAttributes = "";
			$this->creationdate->HrefValue = "";
			$this->creationdate->TooltipValue = "";
		} elseif ($this->RowType == ROWTYPE_EDIT) { // Edit row

			// invoiceid
			$this->invoiceid->EditAttrs["class"] = "form-control";
			$this->invoiceid->EditCustomAttributes = "";
			$this->invoiceid->EditValue = $this->invoiceid->CurrentValue;
			$this->invoiceid->ViewCustomAttributes = "";

			// invoicerefno
			$this->invoicerefno->EditAttrs["class"] = "form-control";
			$this->invoicerefno->EditCustomAttributes = "";
			if (!$this->invoicerefno->Raw)
				$this->invoicerefno->CurrentValue = HtmlDecode($this->invoicerefno->CurrentValue);
			$this->invoicerefno->EditValue = HtmlEncode($this->invoicerefno->CurrentValue);
			$this->invoicerefno->PlaceHolder = RemoveHtml($this->invoicerefno->caption());

			// invoicedate
			$this->invoicedate->EditAttrs["class"] = "form-control";
			$this->invoicedate->EditCustomAttributes = "";
			$this->invoicedate->EditValue = HtmlEncode(FormatDateTime($this->invoicedate->CurrentValue, 8));
			$this->invoicedate->PlaceHolder = RemoveHtml($this->invoicedate->caption());

			// duedate
			$this->duedate->EditAttrs["class"] = "form-control";
			$this->duedate->EditCustomAttributes = "";
			$this->duedate->EditValue = HtmlEncode(FormatDateTime($this->duedate->CurrentValue, 8));
			$this->duedate->PlaceHolder = RemoveHtml($this->duedate->caption());

			// merchantid
			$this->merchantid->EditAttrs["class"] = "form-control";
			$this->merchantid->EditCustomAttributes = "";
			$this->merchantid->EditValue = HtmlEncode($this->merchantid->CurrentValue);
			$this->merchantid->PlaceHolder = RemoveHtml($this->merchantid->caption());

			// memberid
			$this->memberid->EditAttrs["class"] = "form-control";
			$this->memberid->EditCustomAttributes = "";
			$this->memberid->EditValue = HtmlEncode($this->memberid->CurrentValue);
			$this->memberid->PlaceHolder = RemoveHtml($this->memberid->caption());

			// additionalmessage
			$this->additionalmessage->EditAttrs["class"] = "form-control";
			$this->additionalmessage->EditCustomAttributes = "";
			if (!$this->additionalmessage->Raw)
				$this->additionalmessage->CurrentValue = HtmlDecode($this->additionalmessage->CurrentValue);
			$this->additionalmessage->EditValue = HtmlEncode($this->additionalmessage->CurrentValue);
			$this->additionalmessage->PlaceHolder = RemoveHtml($this->additionalmessage->caption());

			// currencycode
			$this->currencycode->EditAttrs["class"] = "form-control";
			$this->currencycode->EditCustomAttributes = "";
			if (!$this->currencycode->Raw)
				$this->currencycode->CurrentValue = HtmlDecode($this->currencycode->CurrentValue);
			$this->currencycode->EditValue = HtmlEncode($this->currencycode->CurrentValue);
			$this->currencycode->PlaceHolder = RemoveHtml($this->currencycode->caption());

			// currencycodesettlement
			$this->currencycodesettlement->EditAttrs["class"] = "form-control";
			$this->currencycodesettlement->EditCustomAttributes = "";
			if (!$this->currencycodesettlement->Raw)
				$this->currencycodesettlement->CurrentValue = HtmlDecode($this->currencycodesettlement->CurrentValue);
			$this->currencycodesettlement->EditValue = HtmlEncode($this->currencycodesettlement->CurrentValue);
			$this->currencycodesettlement->PlaceHolder = RemoveHtml($this->currencycodesettlement->caption());

			// lastupdatedate
			$this->lastupdatedate->EditAttrs["class"] = "form-control";
			$this->lastupdatedate->EditCustomAttributes = "";
			$this->lastupdatedate->EditValue = HtmlEncode(FormatDateTime($this->lastupdatedate->CurrentValue, 8));
			$this->lastupdatedate->PlaceHolder = RemoveHtml($this->lastupdatedate->caption());

			// status
			$this->status->EditAttrs["class"] = "form-control";
			$this->status->EditCustomAttributes = "";
			$this->status->EditValue = $this->status->options(TRUE);

			// customstatus
			$this->customstatus->EditAttrs["class"] = "form-control";
			$this->customstatus->EditCustomAttributes = "";
			$curVal = trim(strval($this->customstatus->CurrentValue));
			if ($curVal != "")
				$this->customstatus->ViewValue = $this->customstatus->lookupCacheOption($curVal);
			else
				$this->customstatus->ViewValue = $this->customstatus->Lookup !== NULL && is_array($this->customstatus->Lookup->Options) ? $curVal : NULL;
			if ($this->customstatus->ViewValue !== NULL) { // Load from cache
				$this->customstatus->EditValue = array_values($this->customstatus->Lookup->Options);
			} else { // Lookup from database
				if ($curVal == "") {
					$filterWrk = "0=1";
				} else {
					$filterWrk = "`statusid`" . SearchString("=", $this->customstatus->CurrentValue, DATATYPE_NUMBER, "_4payreference");
				}
				$sqlWrk = $this->customstatus->Lookup->getSql(TRUE, $filterWrk, '', $this);
				$rswrk = Conn("_4payreference")->execute($sqlWrk);
				$arwrk = $rswrk ? $rswrk->getRows() : [];
				if ($rswrk)
					$rswrk->close();
				$this->customstatus->EditValue = $arwrk;
			}

			// useritemrecid
			$this->useritemrecid->EditAttrs["class"] = "form-control";
			$this->useritemrecid->EditCustomAttributes = "";
			$this->useritemrecid->EditValue = HtmlEncode($this->useritemrecid->CurrentValue);
			$this->useritemrecid->PlaceHolder = RemoveHtml($this->useritemrecid->caption());

			// otherdata
			$this->otherdata->EditAttrs["class"] = "form-control";
			$this->otherdata->EditCustomAttributes = "";
			$this->otherdata->EditValue = HtmlEncode($this->otherdata->CurrentValue);
			$this->otherdata->PlaceHolder = RemoveHtml($this->otherdata->caption());

			// salesrepid
			$this->salesrepid->EditAttrs["class"] = "form-control";
			$this->salesrepid->EditCustomAttributes = "";
			$this->salesrepid->EditValue = HtmlEncode($this->salesrepid->CurrentValue);
			$curVal = strval($this->salesrepid->CurrentValue);
			if ($curVal != "") {
				$this->salesrepid->EditValue = $this->salesrepid->lookupCacheOption($curVal);
				if ($this->salesrepid->EditValue === NULL) { // Lookup from database
					$filterWrk = "`id`" . SearchString("=", $curVal, DATATYPE_NUMBER, "");
					$sqlWrk = $this->salesrepid->Lookup->getSql(FALSE, $filterWrk, '', $this);
					$rswrk = Conn()->execute($sqlWrk);
					if ($rswrk && !$rswrk->EOF) { // Lookup values found
						$arwrk = [];
						$arwrk[1] = HtmlEncode($rswrk->fields('df'));
						$arwrk[2] = HtmlEncode($rswrk->fields('df2'));
						$this->salesrepid->EditValue = $this->salesrepid->displayValue($arwrk);
						$rswrk->Close();
					} else {
						$this->salesrepid->EditValue = HtmlEncode($this->salesrepid->CurrentValue);
					}
				}
			} else {
				$this->salesrepid->EditValue = NULL;
			}
			$this->salesrepid->PlaceHolder = RemoveHtml($this->salesrepid->caption());

			// customerid
			$this->customerid->EditAttrs["class"] = "form-control";
			$this->customerid->EditCustomAttributes = "";
			$this->customerid->EditValue = HtmlEncode($this->customerid->CurrentValue);
			$curVal = strval($this->customerid->CurrentValue);
			if ($curVal != "") {
				$this->customerid->EditValue = $this->customerid->lookupCacheOption($curVal);
				if ($this->customerid->EditValue === NULL) { // Lookup from database
					$filterWrk = "`id`" . SearchString("=", $curVal, DATATYPE_NUMBER, "");
					$sqlWrk = $this->customerid->Lookup->getSql(FALSE, $filterWrk, '', $this);
					$rswrk = Conn()->execute($sqlWrk);
					if ($rswrk && !$rswrk->EOF) { // Lookup values found
						$arwrk = [];
						$arwrk[1] = HtmlEncode($rswrk->fields('df'));
						$arwrk[2] = HtmlEncode($rswrk->fields('df2'));
						$this->customerid->EditValue = $this->customerid->displayValue($arwrk);
						$rswrk->Close();
					} else {
						$this->customerid->EditValue = HtmlEncode($this->customerid->CurrentValue);
					}
				}
			} else {
				$this->customerid->EditValue = NULL;
			}
			$this->customerid->PlaceHolder = RemoveHtml($this->customerid->caption());

			// amount
			$this->amount->EditAttrs["class"] = "form-control";
			$this->amount->EditCustomAttributes = "";
			$this->amount->EditValue = HtmlEncode($this->amount->CurrentValue);
			$this->amount->PlaceHolder = RemoveHtml($this->amount->caption());
			if (strval($this->amount->EditValue) != "" && is_numeric($this->amount->EditValue))
				$this->amount->EditValue = FormatNumber($this->amount->EditValue, -2, -2, -2, -2);
			

			// paid
			$this->paid->EditAttrs["class"] = "form-control";
			$this->paid->EditCustomAttributes = "";
			$this->paid->EditValue = HtmlEncode($this->paid->CurrentValue);
			$this->paid->PlaceHolder = RemoveHtml($this->paid->caption());

			// transactionfee
			$this->transactionfee->EditAttrs["class"] = "form-control";
			$this->transactionfee->EditCustomAttributes = "";
			$this->transactionfee->EditValue = HtmlEncode($this->transactionfee->CurrentValue);
			$this->transactionfee->PlaceHolder = RemoveHtml($this->transactionfee->caption());
			if (strval($this->transactionfee->EditValue) != "" && is_numeric($this->transactionfee->EditValue))
				$this->transactionfee->EditValue = FormatNumber($this->transactionfee->EditValue, -2, -2, -2, -2);
			

			// rate
			$this->rate->EditAttrs["class"] = "form-control";
			$this->rate->EditCustomAttributes = "";
			$this->rate->EditValue = HtmlEncode($this->rate->CurrentValue);
			$this->rate->PlaceHolder = RemoveHtml($this->rate->caption());
			if (strval($this->rate->EditValue) != "" && is_numeric($this->rate->EditValue))
				$this->rate->EditValue = FormatNumber($this->rate->EditValue, -2, -2, -2, -2);
			

			// expirydate
			$this->expirydate->EditAttrs["class"] = "form-control";
			$this->expirydate->EditCustomAttributes = "";
			$this->expirydate->EditValue = HtmlEncode(FormatDateTime($this->expirydate->CurrentValue, 8));
			$this->expirydate->PlaceHolder = RemoveHtml($this->expirydate->caption());

			// filename
			$this->filename->EditAttrs["class"] = "form-control";
			$this->filename->EditCustomAttributes = "";
			if (!$this->filename->Raw)
				$this->filename->CurrentValue = HtmlDecode($this->filename->CurrentValue);
			$this->filename->EditValue = HtmlEncode($this->filename->CurrentValue);
			$this->filename->PlaceHolder = RemoveHtml($this->filename->caption());

			// otherdata2
			$this->otherdata2->EditAttrs["class"] = "form-control";
			$this->otherdata2->EditCustomAttributes = "";
			$this->otherdata2->EditValue = HtmlEncode($this->otherdata2->CurrentValue);
			$this->otherdata2->PlaceHolder = RemoveHtml($this->otherdata2->caption());

			// otherdata3
			$this->otherdata3->EditAttrs["class"] = "form-control";
			$this->otherdata3->EditCustomAttributes = "";
			$this->otherdata3->EditValue = HtmlEncode($this->otherdata3->CurrentValue);
			$this->otherdata3->PlaceHolder = RemoveHtml($this->otherdata3->caption());

			// supplierid
			$this->supplierid->EditAttrs["class"] = "form-control";
			$this->supplierid->EditCustomAttributes = "";
			$this->supplierid->EditValue = HtmlEncode($this->supplierid->CurrentValue);
			$curVal = strval($this->supplierid->CurrentValue);
			if ($curVal != "") {
				$this->supplierid->EditValue = $this->supplierid->lookupCacheOption($curVal);
				if ($this->supplierid->EditValue === NULL) { // Lookup from database
					$filterWrk = "`userid`" . SearchString("=", $curVal, DATATYPE_NUMBER, "");
					$sqlWrk = $this->supplierid->Lookup->getSql(FALSE, $filterWrk, '', $this);
					$rswrk = Conn()->execute($sqlWrk);
					if ($rswrk && !$rswrk->EOF) { // Lookup values found
						$arwrk = [];
						$arwrk[1] = HtmlEncode($rswrk->fields('df'));
						$this->supplierid->EditValue = $this->supplierid->displayValue($arwrk);
						$rswrk->Close();
					} else {
						$this->supplierid->EditValue = HtmlEncode($this->supplierid->CurrentValue);
					}
				}
			} else {
				$this->supplierid->EditValue = NULL;
			}
			$this->supplierid->PlaceHolder = RemoveHtml($this->supplierid->caption());

			// settlementamount
			$this->settlementamount->EditAttrs["class"] = "form-control";
			$this->settlementamount->EditCustomAttributes = "";
			$this->settlementamount->EditValue = HtmlEncode($this->settlementamount->CurrentValue);
			$this->settlementamount->PlaceHolder = RemoveHtml($this->settlementamount->caption());
			if (strval($this->settlementamount->EditValue) != "" && is_numeric($this->settlementamount->EditValue))
				$this->settlementamount->EditValue = FormatNumber($this->settlementamount->EditValue, -2, -2, -2, -2);
			

			// creationdate
			$this->creationdate->EditAttrs["class"] = "form-control";
			$this->creationdate->EditCustomAttributes = "";
			$this->creationdate->EditValue = HtmlEncode(FormatDateTime($this->creationdate->CurrentValue, 8));
			$this->creationdate->PlaceHolder = RemoveHtml($this->creationdate->caption());

			// Edit refer script
			// invoiceid

			$this->invoiceid->LinkCustomAttributes = "";
			$this->invoiceid->HrefValue = "";

			// invoicerefno
			$this->invoicerefno->LinkCustomAttributes = "";
			$this->invoicerefno->HrefValue = "";

			// invoicedate
			$this->invoicedate->LinkCustomAttributes = "";
			$this->invoicedate->HrefValue = "";

			// duedate
			$this->duedate->LinkCustomAttributes = "";
			$this->duedate->HrefValue = "";

			// merchantid
			$this->merchantid->LinkCustomAttributes = "";
			$this->merchantid->HrefValue = "";

			// memberid
			$this->memberid->LinkCustomAttributes = "";
			$this->memberid->HrefValue = "";

			// additionalmessage
			$this->additionalmessage->LinkCustomAttributes = "";
			$this->additionalmessage->HrefValue = "";

			// currencycode
			$this->currencycode->LinkCustomAttributes = "";
			$this->currencycode->HrefValue = "";

			// currencycodesettlement
			$this->currencycodesettlement->LinkCustomAttributes = "";
			$this->currencycodesettlement->HrefValue = "";

			// lastupdatedate
			$this->lastupdatedate->LinkCustomAttributes = "";
			$this->lastupdatedate->HrefValue = "";

			// status
			$this->status->LinkCustomAttributes = "";
			$this->status->HrefValue = "";

			// customstatus
			$this->customstatus->LinkCustomAttributes = "";
			$this->customstatus->HrefValue = "";

			// useritemrecid
			$this->useritemrecid->LinkCustomAttributes = "";
			$this->useritemrecid->HrefValue = "";

			// otherdata
			$this->otherdata->LinkCustomAttributes = "";
			$this->otherdata->HrefValue = "";

			// salesrepid
			$this->salesrepid->LinkCustomAttributes = "";
			$this->salesrepid->HrefValue = "";

			// customerid
			$this->customerid->LinkCustomAttributes = "";
			$this->customerid->HrefValue = "";

			// amount
			$this->amount->LinkCustomAttributes = "";
			$this->amount->HrefValue = "";

			// paid
			$this->paid->LinkCustomAttributes = "";
			$this->paid->HrefValue = "";

			// transactionfee
			$this->transactionfee->LinkCustomAttributes = "";
			$this->transactionfee->HrefValue = "";

			// rate
			$this->rate->LinkCustomAttributes = "";
			$this->rate->HrefValue = "";

			// expirydate
			$this->expirydate->LinkCustomAttributes = "";
			$this->expirydate->HrefValue = "";

			// filename
			$this->filename->LinkCustomAttributes = "";
			$this->filename->HrefValue = "";

			// otherdata2
			$this->otherdata2->LinkCustomAttributes = "";
			$this->otherdata2->HrefValue = "";

			// otherdata3
			$this->otherdata3->LinkCustomAttributes = "";
			$this->otherdata3->HrefValue = "";

			// supplierid
			$this->supplierid->LinkCustomAttributes = "";
			$this->supplierid->HrefValue = "";

			// settlementamount
			$this->settlementamount->LinkCustomAttributes = "";
			$this->settlementamount->HrefValue = "";

			// creationdate
			$this->creationdate->LinkCustomAttributes = "";
			$this->creationdate->HrefValue = "";
		}
		if ($this->RowType == ROWTYPE_ADD || $this->RowType == ROWTYPE_EDIT || $this->RowType == ROWTYPE_SEARCH) // Add/Edit/Search row
			$this->setupFieldTitles();

		// Call Row Rendered event
		if ($this->RowType != ROWTYPE_AGGREGATEINIT)
			$this->Row_Rendered();
	}

	// Validate form
	protected function validateForm()
	{
		global $Language, $FormError;

		// Initialize form error message
		$FormError = "";

		// Check if validation required
		if (!Config("SERVER_VALIDATE"))
			return ($FormError == "");
		if ($this->invoiceid->Required) {
			if (!$this->invoiceid->IsDetailKey && $this->invoiceid->FormValue != NULL && $this->invoiceid->FormValue == "") {
				AddMessage($FormError, str_replace("%s", $this->invoiceid->caption(), $this->invoiceid->RequiredErrorMessage));
			}
		}
		if ($this->invoicerefno->Required) {
			if (!$this->invoicerefno->IsDetailKey && $this->invoicerefno->FormValue != NULL && $this->invoicerefno->FormValue == "") {
				AddMessage($FormError, str_replace("%s", $this->invoicerefno->caption(), $this->invoicerefno->RequiredErrorMessage));
			}
		}
		if ($this->invoicedate->Required) {
			if (!$this->invoicedate->IsDetailKey && $this->invoicedate->FormValue != NULL && $this->invoicedate->FormValue == "") {
				AddMessage($FormError, str_replace("%s", $this->invoicedate->caption(), $this->invoicedate->RequiredErrorMessage));
			}
		}
		if (!CheckDate($this->invoicedate->FormValue)) {
			AddMessage($FormError, $this->invoicedate->errorMessage());
		}
		if ($this->duedate->Required) {
			if (!$this->duedate->IsDetailKey && $this->duedate->FormValue != NULL && $this->duedate->FormValue == "") {
				AddMessage($FormError, str_replace("%s", $this->duedate->caption(), $this->duedate->RequiredErrorMessage));
			}
		}
		if (!CheckDate($this->duedate->FormValue)) {
			AddMessage($FormError, $this->duedate->errorMessage());
		}
		if ($this->merchantid->Required) {
			if (!$this->merchantid->IsDetailKey && $this->merchantid->FormValue != NULL && $this->merchantid->FormValue == "") {
				AddMessage($FormError, str_replace("%s", $this->merchantid->caption(), $this->merchantid->RequiredErrorMessage));
			}
		}
		if (!CheckInteger($this->merchantid->FormValue)) {
			AddMessage($FormError, $this->merchantid->errorMessage());
		}
		if ($this->memberid->Required) {
			if (!$this->memberid->IsDetailKey && $this->memberid->FormValue != NULL && $this->memberid->FormValue == "") {
				AddMessage($FormError, str_replace("%s", $this->memberid->caption(), $this->memberid->RequiredErrorMessage));
			}
		}
		if (!CheckInteger($this->memberid->FormValue)) {
			AddMessage($FormError, $this->memberid->errorMessage());
		}
		if ($this->additionalmessage->Required) {
			if (!$this->additionalmessage->IsDetailKey && $this->additionalmessage->FormValue != NULL && $this->additionalmessage->FormValue == "") {
				AddMessage($FormError, str_replace("%s", $this->additionalmessage->caption(), $this->additionalmessage->RequiredErrorMessage));
			}
		}
		if ($this->currencycode->Required) {
			if (!$this->currencycode->IsDetailKey && $this->currencycode->FormValue != NULL && $this->currencycode->FormValue == "") {
				AddMessage($FormError, str_replace("%s", $this->currencycode->caption(), $this->currencycode->RequiredErrorMessage));
			}
		}
		if ($this->currencycodesettlement->Required) {
			if (!$this->currencycodesettlement->IsDetailKey && $this->currencycodesettlement->FormValue != NULL && $this->currencycodesettlement->FormValue == "") {
				AddMessage($FormError, str_replace("%s", $this->currencycodesettlement->caption(), $this->currencycodesettlement->RequiredErrorMessage));
			}
		}
		if ($this->lastupdatedate->Required) {
			if (!$this->lastupdatedate->IsDetailKey && $this->lastupdatedate->FormValue != NULL && $this->lastupdatedate->FormValue == "") {
				AddMessage($FormError, str_replace("%s", $this->lastupdatedate->caption(), $this->lastupdatedate->RequiredErrorMessage));
			}
		}
		if (!CheckDate($this->lastupdatedate->FormValue)) {
			AddMessage($FormError, $this->lastupdatedate->errorMessage());
		}
		if ($this->status->Required) {
			if (!$this->status->IsDetailKey && $this->status->FormValue != NULL && $this->status->FormValue == "") {
				AddMessage($FormError, str_replace("%s", $this->status->caption(), $this->status->RequiredErrorMessage));
			}
		}
		if ($this->customstatus->Required) {
			if (!$this->customstatus->IsDetailKey && $this->customstatus->FormValue != NULL && $this->customstatus->FormValue == "") {
				AddMessage($FormError, str_replace("%s", $this->customstatus->caption(), $this->customstatus->RequiredErrorMessage));
			}
		}
		if ($this->useritemrecid->Required) {
			if (!$this->useritemrecid->IsDetailKey && $this->useritemrecid->FormValue != NULL && $this->useritemrecid->FormValue == "") {
				AddMessage($FormError, str_replace("%s", $this->useritemrecid->caption(), $this->useritemrecid->RequiredErrorMessage));
			}
		}
		if (!CheckInteger($this->useritemrecid->FormValue)) {
			AddMessage($FormError, $this->useritemrecid->errorMessage());
		}
		if ($this->otherdata->Required) {
			if (!$this->otherdata->IsDetailKey && $this->otherdata->FormValue != NULL && $this->otherdata->FormValue == "") {
				AddMessage($FormError, str_replace("%s", $this->otherdata->caption(), $this->otherdata->RequiredErrorMessage));
			}
		}
		if ($this->salesrepid->Required) {
			if (!$this->salesrepid->IsDetailKey && $this->salesrepid->FormValue != NULL && $this->salesrepid->FormValue == "") {
				AddMessage($FormError, str_replace("%s", $this->salesrepid->caption(), $this->salesrepid->RequiredErrorMessage));
			}
		}
		if (!CheckInteger($this->salesrepid->FormValue)) {
			AddMessage($FormError, $this->salesrepid->errorMessage());
		}
		if ($this->customerid->Required) {
			if (!$this->customerid->IsDetailKey && $this->customerid->FormValue != NULL && $this->customerid->FormValue == "") {
				AddMessage($FormError, str_replace("%s", $this->customerid->caption(), $this->customerid->RequiredErrorMessage));
			}
		}
		if (!CheckInteger($this->customerid->FormValue)) {
			AddMessage($FormError, $this->customerid->errorMessage());
		}
		if ($this->amount->Required) {
			if (!$this->amount->IsDetailKey && $this->amount->FormValue != NULL && $this->amount->FormValue == "") {
				AddMessage($FormError, str_replace("%s", $this->amount->caption(), $this->amount->RequiredErrorMessage));
			}
		}
		if (!CheckNumber($this->amount->FormValue)) {
			AddMessage($FormError, $this->amount->errorMessage());
		}
		if ($this->paid->Required) {
			if (!$this->paid->IsDetailKey && $this->paid->FormValue != NULL && $this->paid->FormValue == "") {
				AddMessage($FormError, str_replace("%s", $this->paid->caption(), $this->paid->RequiredErrorMessage));
			}
		}
		if (!CheckInteger($this->paid->FormValue)) {
			AddMessage($FormError, $this->paid->errorMessage());
		}
		if ($this->transactionfee->Required) {
			if (!$this->transactionfee->IsDetailKey && $this->transactionfee->FormValue != NULL && $this->transactionfee->FormValue == "") {
				AddMessage($FormError, str_replace("%s", $this->transactionfee->caption(), $this->transactionfee->RequiredErrorMessage));
			}
		}
		if (!CheckNumber($this->transactionfee->FormValue)) {
			AddMessage($FormError, $this->transactionfee->errorMessage());
		}
		if ($this->rate->Required) {
			if (!$this->rate->IsDetailKey && $this->rate->FormValue != NULL && $this->rate->FormValue == "") {
				AddMessage($FormError, str_replace("%s", $this->rate->caption(), $this->rate->RequiredErrorMessage));
			}
		}
		if (!CheckNumber($this->rate->FormValue)) {
			AddMessage($FormError, $this->rate->errorMessage());
		}
		if ($this->expirydate->Required) {
			if (!$this->expirydate->IsDetailKey && $this->expirydate->FormValue != NULL && $this->expirydate->FormValue == "") {
				AddMessage($FormError, str_replace("%s", $this->expirydate->caption(), $this->expirydate->RequiredErrorMessage));
			}
		}
		if (!CheckDate($this->expirydate->FormValue)) {
			AddMessage($FormError, $this->expirydate->errorMessage());
		}
		if ($this->filename->Required) {
			if (!$this->filename->IsDetailKey && $this->filename->FormValue != NULL && $this->filename->FormValue == "") {
				AddMessage($FormError, str_replace("%s", $this->filename->caption(), $this->filename->RequiredErrorMessage));
			}
		}
		if ($this->otherdata2->Required) {
			if (!$this->otherdata2->IsDetailKey && $this->otherdata2->FormValue != NULL && $this->otherdata2->FormValue == "") {
				AddMessage($FormError, str_replace("%s", $this->otherdata2->caption(), $this->otherdata2->RequiredErrorMessage));
			}
		}
		if ($this->otherdata3->Required) {
			if (!$this->otherdata3->IsDetailKey && $this->otherdata3->FormValue != NULL && $this->otherdata3->FormValue == "") {
				AddMessage($FormError, str_replace("%s", $this->otherdata3->caption(), $this->otherdata3->RequiredErrorMessage));
			}
		}
		if ($this->supplierid->Required) {
			if (!$this->supplierid->IsDetailKey && $this->supplierid->FormValue != NULL && $this->supplierid->FormValue == "") {
				AddMessage($FormError, str_replace("%s", $this->supplierid->caption(), $this->supplierid->RequiredErrorMessage));
			}
		}
		if (!CheckInteger($this->supplierid->FormValue)) {
			AddMessage($FormError, $this->supplierid->errorMessage());
		}
		if ($this->settlementamount->Required) {
			if (!$this->settlementamount->IsDetailKey && $this->settlementamount->FormValue != NULL && $this->settlementamount->FormValue == "") {
				AddMessage($FormError, str_replace("%s", $this->settlementamount->caption(), $this->settlementamount->RequiredErrorMessage));
			}
		}
		if (!CheckNumber($this->settlementamount->FormValue)) {
			AddMessage($FormError, $this->settlementamount->errorMessage());
		}
		if ($this->creationdate->Required) {
			if (!$this->creationdate->IsDetailKey && $this->creationdate->FormValue != NULL && $this->creationdate->FormValue == "") {
				AddMessage($FormError, str_replace("%s", $this->creationdate->caption(), $this->creationdate->RequiredErrorMessage));
			}
		}
		if (!CheckDate($this->creationdate->FormValue)) {
			AddMessage($FormError, $this->creationdate->errorMessage());
		}

		// Validate detail grid
		$detailTblVar = explode(",", $this->getCurrentDetailTable());
		if (in_array("invoiceline", $detailTblVar) && $GLOBALS["invoiceline"]->DetailEdit) {
			if (!isset($GLOBALS["invoiceline_grid"]))
				$GLOBALS["invoiceline_grid"] = new invoiceline_grid(); // Get detail page object
			$GLOBALS["invoiceline_grid"]->validateGridForm();
		}
		if (in_array("invoicedocs", $detailTblVar) && $GLOBALS["invoicedocs"]->DetailEdit) {
			if (!isset($GLOBALS["invoicedocs_grid"]))
				$GLOBALS["invoicedocs_grid"] = new invoicedocs_grid(); // Get detail page object
			$GLOBALS["invoicedocs_grid"]->validateGridForm();
		}
		if (in_array("invoicescustomstatushistory", $detailTblVar) && $GLOBALS["invoicescustomstatushistory"]->DetailEdit) {
			if (!isset($GLOBALS["invoicescustomstatushistory_grid"]))
				$GLOBALS["invoicescustomstatushistory_grid"] = new invoicescustomstatushistory_grid(); // Get detail page object
			$GLOBALS["invoicescustomstatushistory_grid"]->validateGridForm();
		}

		// Return validate result
		$validateForm = ($FormError == "");

		// Call Form_CustomValidate event
		$formCustomError = "";
		$validateForm = $validateForm && $this->Form_CustomValidate($formCustomError);
		if ($formCustomError != "") {
			AddMessage($FormError, $formCustomError);
		}
		return $validateForm;
	}

	// Update record based on key values
	protected function editRow()
	{
		global $Security, $Language;
		$oldKeyFilter = $this->getRecordFilter();
		$filter = $this->applyUserIDFilters($oldKeyFilter);
		$conn = $this->getConnection();
		$this->CurrentFilter = $filter;
		$sql = $this->getCurrentSql();
		$conn->raiseErrorFn = Config("ERROR_FUNC");
		$rs = $conn->execute($sql);
		$conn->raiseErrorFn = "";
		if ($rs === FALSE)
			return FALSE;
		if ($rs->EOF) {
			$this->setFailureMessage($Language->phrase("NoRecord")); // Set no record message
			$editRow = FALSE; // Update Failed
		} else {

			// Begin transaction
			if ($this->getCurrentDetailTable() != "")
				$conn->beginTrans();

			// Save old values
			$rsold = &$rs->fields;
			$this->loadDbValues($rsold);
			$rsnew = [];

			// invoicerefno
			$this->invoicerefno->setDbValueDef($rsnew, $this->invoicerefno->CurrentValue, "", $this->invoicerefno->ReadOnly);

			// invoicedate
			$this->invoicedate->setDbValueDef($rsnew, UnFormatDateTime($this->invoicedate->CurrentValue, 0), CurrentDate(), $this->invoicedate->ReadOnly);

			// duedate
			$this->duedate->setDbValueDef($rsnew, UnFormatDateTime($this->duedate->CurrentValue, 0), CurrentDate(), $this->duedate->ReadOnly);

			// merchantid
			$this->merchantid->setDbValueDef($rsnew, $this->merchantid->CurrentValue, 0, $this->merchantid->ReadOnly);

			// memberid
			$this->memberid->setDbValueDef($rsnew, $this->memberid->CurrentValue, 0, $this->memberid->ReadOnly);

			// additionalmessage
			$this->additionalmessage->setDbValueDef($rsnew, $this->additionalmessage->CurrentValue, NULL, $this->additionalmessage->ReadOnly);

			// currencycode
			$this->currencycode->setDbValueDef($rsnew, $this->currencycode->CurrentValue, "", $this->currencycode->ReadOnly);

			// currencycodesettlement
			$this->currencycodesettlement->setDbValueDef($rsnew, $this->currencycodesettlement->CurrentValue, NULL, $this->currencycodesettlement->ReadOnly);

			// lastupdatedate
			$this->lastupdatedate->setDbValueDef($rsnew, UnFormatDateTime($this->lastupdatedate->CurrentValue, 0), NULL, $this->lastupdatedate->ReadOnly);

			// status
			$this->status->setDbValueDef($rsnew, $this->status->CurrentValue, 0, $this->status->ReadOnly);

			// customstatus
			$this->customstatus->setDbValueDef($rsnew, $this->customstatus->CurrentValue, 0, $this->customstatus->ReadOnly);

			// useritemrecid
			$this->useritemrecid->setDbValueDef($rsnew, $this->useritemrecid->CurrentValue, 0, $this->useritemrecid->ReadOnly);

			// otherdata
			$this->otherdata->setDbValueDef($rsnew, $this->otherdata->CurrentValue, NULL, $this->otherdata->ReadOnly);

			// salesrepid
			$this->salesrepid->setDbValueDef($rsnew, $this->salesrepid->CurrentValue, 0, $this->salesrepid->ReadOnly);

			// customerid
			$this->customerid->setDbValueDef($rsnew, $this->customerid->CurrentValue, 0, $this->customerid->ReadOnly);

			// amount
			$this->amount->setDbValueDef($rsnew, $this->amount->CurrentValue, 0, $this->amount->ReadOnly);

			// paid
			$this->paid->setDbValueDef($rsnew, $this->paid->CurrentValue, 0, $this->paid->ReadOnly);

			// transactionfee
			$this->transactionfee->setDbValueDef($rsnew, $this->transactionfee->CurrentValue, 0, $this->transactionfee->ReadOnly);

			// rate
			$this->rate->setDbValueDef($rsnew, $this->rate->CurrentValue, 0, $this->rate->ReadOnly);

			// expirydate
			$this->expirydate->setDbValueDef($rsnew, UnFormatDateTime($this->expirydate->CurrentValue, 0), NULL, $this->expirydate->ReadOnly);

			// filename
			$this->filename->setDbValueDef($rsnew, $this->filename->CurrentValue, NULL, $this->filename->ReadOnly);

			// otherdata2
			$this->otherdata2->setDbValueDef($rsnew, $this->otherdata2->CurrentValue, NULL, $this->otherdata2->ReadOnly);

			// otherdata3
			$this->otherdata3->setDbValueDef($rsnew, $this->otherdata3->CurrentValue, NULL, $this->otherdata3->ReadOnly);

			// supplierid
			$this->supplierid->setDbValueDef($rsnew, $this->supplierid->CurrentValue, 0, $this->supplierid->ReadOnly);

			// settlementamount
			$this->settlementamount->setDbValueDef($rsnew, $this->settlementamount->CurrentValue, 0, $this->settlementamount->ReadOnly);

			// creationdate
			$this->creationdate->setDbValueDef($rsnew, UnFormatDateTime($this->creationdate->CurrentValue, 0), NULL, $this->creationdate->ReadOnly);

			// Call Row Updating event
			$updateRow = $this->Row_Updating($rsold, $rsnew);

			// Check for duplicate key when key changed
			if ($updateRow) {
				$newKeyFilter = $this->getRecordFilter($rsnew);
				if ($newKeyFilter != $oldKeyFilter) {
					$rsChk = $this->loadRs($newKeyFilter);
					if ($rsChk && !$rsChk->EOF) {
						$keyErrMsg = str_replace("%f", $newKeyFilter, $Language->phrase("DupKey"));
						$this->setFailureMessage($keyErrMsg);
						$rsChk->close();
						$updateRow = FALSE;
					}
				}
			}
			if ($updateRow) {
				$conn->raiseErrorFn = Config("ERROR_FUNC");
				if (count($rsnew) > 0)
					$editRow = $this->update($rsnew, "", $rsold);
				else
					$editRow = TRUE; // No field to update
				$conn->raiseErrorFn = "";
				if ($editRow) {
				}

				// Update detail records
				$detailTblVar = explode(",", $this->getCurrentDetailTable());
				if ($editRow) {
					if (in_array("invoiceline", $detailTblVar) && $GLOBALS["invoiceline"]->DetailEdit) {
						if (!isset($GLOBALS["invoiceline_grid"]))
							$GLOBALS["invoiceline_grid"] = new invoiceline_grid(); // Get detail page object
						$Security->loadCurrentUserLevel($this->ProjectID . "invoiceline"); // Load user level of detail table
						$editRow = $GLOBALS["invoiceline_grid"]->gridUpdate();
						$Security->loadCurrentUserLevel($this->ProjectID . $this->TableName); // Restore user level of master table
					}
				}
				if ($editRow) {
					if (in_array("invoicedocs", $detailTblVar) && $GLOBALS["invoicedocs"]->DetailEdit) {
						if (!isset($GLOBALS["invoicedocs_grid"]))
							$GLOBALS["invoicedocs_grid"] = new invoicedocs_grid(); // Get detail page object
						$Security->loadCurrentUserLevel($this->ProjectID . "invoicedocs"); // Load user level of detail table
						$editRow = $GLOBALS["invoicedocs_grid"]->gridUpdate();
						$Security->loadCurrentUserLevel($this->ProjectID . $this->TableName); // Restore user level of master table
					}
				}
				if ($editRow) {
					if (in_array("invoicescustomstatushistory", $detailTblVar) && $GLOBALS["invoicescustomstatushistory"]->DetailEdit) {
						if (!isset($GLOBALS["invoicescustomstatushistory_grid"]))
							$GLOBALS["invoicescustomstatushistory_grid"] = new invoicescustomstatushistory_grid(); // Get detail page object
						$Security->loadCurrentUserLevel($this->ProjectID . "invoicescustomstatushistory"); // Load user level of detail table
						$editRow = $GLOBALS["invoicescustomstatushistory_grid"]->gridUpdate();
						$Security->loadCurrentUserLevel($this->ProjectID . $this->TableName); // Restore user level of master table
					}
				}

				// Commit/Rollback transaction
				if ($this->getCurrentDetailTable() != "") {
					if ($editRow) {
						$conn->commitTrans(); // Commit transaction
					} else {
						$conn->rollbackTrans(); // Rollback transaction
					}
				}
			} else {
				if ($this->getSuccessMessage() != "" || $this->getFailureMessage() != "") {

					// Use the message, do nothing
				} elseif ($this->CancelMessage != "") {
					$this->setFailureMessage($this->CancelMessage);
					$this->CancelMessage = "";
				} else {
					$this->setFailureMessage($Language->phrase("UpdateCancelled"));
				}
				$editRow = FALSE;
			}
		}

		// Call Row_Updated event
		if ($editRow)
			$this->Row_Updated($rsold, $rsnew);
		$rs->close();

		// Clean upload path if any
		if ($editRow) {
		}

		// Write JSON for API request
		if (IsApi() && $editRow) {
			$row = $this->getRecordsFromRecordset([$rsnew], TRUE);
			WriteJson(["success" => TRUE, $this->TableVar => $row]);
		}
		return $editRow;
	}

	// Set up detail parms based on QueryString
	protected function setupDetailParms()
	{

		// Get the keys for master table
		$detailTblVar = Get(Config("TABLE_SHOW_DETAIL"));
		if ($detailTblVar !== NULL) {
			$this->setCurrentDetailTable($detailTblVar);
		} else {
			$detailTblVar = $this->getCurrentDetailTable();
		}
		if ($detailTblVar != "") {
			$detailTblVar = explode(",", $detailTblVar);
			if (in_array("invoiceline", $detailTblVar)) {
				if (!isset($GLOBALS["invoiceline_grid"]))
					$GLOBALS["invoiceline_grid"] = new invoiceline_grid();
				if ($GLOBALS["invoiceline_grid"]->DetailEdit) {
					$GLOBALS["invoiceline_grid"]->CurrentMode = "edit";
					$GLOBALS["invoiceline_grid"]->CurrentAction = "gridedit";

					// Save current master table to detail table
					$GLOBALS["invoiceline_grid"]->setCurrentMasterTable($this->TableVar);
					$GLOBALS["invoiceline_grid"]->setStartRecordNumber(1);
					$GLOBALS["invoiceline_grid"]->invoiceid->IsDetailKey = TRUE;
					$GLOBALS["invoiceline_grid"]->invoiceid->CurrentValue = $this->invoiceid->CurrentValue;
					$GLOBALS["invoiceline_grid"]->invoiceid->setSessionValue($GLOBALS["invoiceline_grid"]->invoiceid->CurrentValue);
				}
			}
			if (in_array("invoicedocs", $detailTblVar)) {
				if (!isset($GLOBALS["invoicedocs_grid"]))
					$GLOBALS["invoicedocs_grid"] = new invoicedocs_grid();
				if ($GLOBALS["invoicedocs_grid"]->DetailEdit) {
					$GLOBALS["invoicedocs_grid"]->CurrentMode = "edit";
					$GLOBALS["invoicedocs_grid"]->CurrentAction = "gridedit";

					// Save current master table to detail table
					$GLOBALS["invoicedocs_grid"]->setCurrentMasterTable($this->TableVar);
					$GLOBALS["invoicedocs_grid"]->setStartRecordNumber(1);
					$GLOBALS["invoicedocs_grid"]->invoiceid->IsDetailKey = TRUE;
					$GLOBALS["invoicedocs_grid"]->invoiceid->CurrentValue = $this->invoiceid->CurrentValue;
					$GLOBALS["invoicedocs_grid"]->invoiceid->setSessionValue($GLOBALS["invoicedocs_grid"]->invoiceid->CurrentValue);
				}
			}
			if (in_array("invoicescustomstatushistory", $detailTblVar)) {
				if (!isset($GLOBALS["invoicescustomstatushistory_grid"]))
					$GLOBALS["invoicescustomstatushistory_grid"] = new invoicescustomstatushistory_grid();
				if ($GLOBALS["invoicescustomstatushistory_grid"]->DetailEdit) {
					$GLOBALS["invoicescustomstatushistory_grid"]->CurrentMode = "edit";
					$GLOBALS["invoicescustomstatushistory_grid"]->CurrentAction = "gridedit";

					// Save current master table to detail table
					$GLOBALS["invoicescustomstatushistory_grid"]->setCurrentMasterTable($this->TableVar);
					$GLOBALS["invoicescustomstatushistory_grid"]->setStartRecordNumber(1);
					$GLOBALS["invoicescustomstatushistory_grid"]->invoiceid->IsDetailKey = TRUE;
					$GLOBALS["invoicescustomstatushistory_grid"]->invoiceid->CurrentValue = $this->invoiceid->CurrentValue;
					$GLOBALS["invoicescustomstatushistory_grid"]->invoiceid->setSessionValue($GLOBALS["invoicescustomstatushistory_grid"]->invoiceid->CurrentValue);
				}
			}
		}
	}

	// Set up Breadcrumb
	protected function setupBreadcrumb()
	{
		global $Breadcrumb, $Language;
		$Breadcrumb = new Breadcrumb();
		$url = substr(CurrentUrl(), strrpos(CurrentUrl(), "/")+1);
		$Breadcrumb->add("list", $this->TableVar, $this->addMasterUrl("invoiceslist.php"), "", $this->TableVar, TRUE);
		$pageId = "edit";
		$Breadcrumb->add("edit", $pageId, $url);
	}

	// Setup lookup options
	public function setupLookupOptions($fld)
	{
		if ($fld->Lookup !== NULL && $fld->Lookup->Options === NULL) {

			// Get default connection and filter
			$conn = $this->getConnection();
			$lookupFilter = "";

			// No need to check any more
			$fld->Lookup->Options = [];

			// Set up lookup SQL and connection
			switch ($fld->FieldVar) {
				case "x_status":
					break;
				case "x_customstatus":
					$conn = Conn("_4payreference");
					break;
				case "x_salesrepid":
					break;
				case "x_customerid":
					break;
				case "x_supplierid":
					break;
				default:
					$lookupFilter = "";
					break;
			}

			// Always call to Lookup->getSql so that user can setup Lookup->Options in Lookup_Selecting server event
			$sql = $fld->Lookup->getSql(FALSE, "", $lookupFilter, $this);

			// Set up lookup cache
			if ($fld->UseLookupCache && $sql != "" && count($fld->Lookup->Options) == 0) {
				$totalCnt = $this->getRecordCount($sql, $conn);
				if ($totalCnt > $fld->LookupCacheCount) // Total count > cache count, do not cache
					return;
				$rs = $conn->execute($sql);
				$ar = [];
				while ($rs && !$rs->EOF) {
					$row = &$rs->fields;

					// Format the field values
					switch ($fld->FieldVar) {
						case "x_customstatus":
							break;
						case "x_salesrepid":
							break;
						case "x_customerid":
							break;
						case "x_supplierid":
							break;
					}
					$ar[strval($row[0])] = $row;
					$rs->moveNext();
				}
				if ($rs)
					$rs->close();
				$fld->Lookup->Options = $ar;
			}
		}
	}

	// Set up starting record parameters
	public function setupStartRecord()
	{
		if ($this->DisplayRecords == 0)
			return;
		if ($this->isPageRequest()) { // Validate request
			$startRec = Get(Config("TABLE_START_REC"));
			$pageNo = Get(Config("TABLE_PAGE_NO"));
			if ($pageNo !== NULL) { // Check for "pageno" parameter first
				if (is_numeric($pageNo)) {
					$this->StartRecord = ($pageNo - 1) * $this->DisplayRecords + 1;
					if ($this->StartRecord <= 0) {
						$this->StartRecord = 1;
					} elseif ($this->StartRecord >= (int)(($this->TotalRecords - 1)/$this->DisplayRecords) * $this->DisplayRecords + 1) {
						$this->StartRecord = (int)(($this->TotalRecords - 1)/$this->DisplayRecords) * $this->DisplayRecords + 1;
					}
					$this->setStartRecordNumber($this->StartRecord);
				}
			} elseif ($startRec !== NULL) { // Check for "start" parameter
				$this->StartRecord = $startRec;
				$this->setStartRecordNumber($this->StartRecord);
			}
		}
		$this->StartRecord = $this->getStartRecordNumber();

		// Check if correct start record counter
		if (!is_numeric($this->StartRecord) || $this->StartRecord == "") { // Avoid invalid start record counter
			$this->StartRecord = 1; // Reset start record counter
			$this->setStartRecordNumber($this->StartRecord);
		} elseif ($this->StartRecord > $this->TotalRecords) { // Avoid starting record > total records
			$this->StartRecord = (int)(($this->TotalRecords - 1)/$this->DisplayRecords) * $this->DisplayRecords + 1; // Point to last page first record
			$this->setStartRecordNumber($this->StartRecord);
		} elseif (($this->StartRecord - 1) % $this->DisplayRecords != 0) {
			$this->StartRecord = (int)(($this->StartRecord - 1)/$this->DisplayRecords) * $this->DisplayRecords + 1; // Point to page boundary
			$this->setStartRecordNumber($this->StartRecord);
		}
	}

	// Page Load event
	function Page_Load() {

		//echo "Page Load";
	}

	// Page Unload event
	function Page_Unload() {

		//echo "Page Unload";
	}

	// Page Redirecting event
	function Page_Redirecting(&$url) {

		// Example:
		//$url = "your URL";

	}

	// Message Showing event
	// $type = ''|'success'|'failure'|'warning'
	function Message_Showing(&$msg, $type) {
		if ($type == 'success') {

			//$msg = "your success message";
		} elseif ($type == 'failure') {

			//$msg = "your failure message";
		} elseif ($type == 'warning') {

			//$msg = "your warning message";
		} else {

			//$msg = "your message";
		}
	}

	// Page Render event
	function Page_Render() {

		//echo "Page Render";
	}

	// Page Data Rendering event
	function Page_DataRendering(&$header) {

		// Example:
		//$header = "your header";

	}

	// Page Data Rendered event
	function Page_DataRendered(&$footer) {

		// Example:
		//$footer = "your footer";

	}

	// Form Custom Validate event
	function Form_CustomValidate(&$customError) {

		// Return error message in CustomError
		return TRUE;
	}
} // End class
?>