<?php namespace PHPMaker2020\_4payadmin; ?>
<?php

/**
 * Table class for vmerchantbridgeitem
 */
class vmerchantbridgeitem extends DbTable
{
	protected $SqlFrom = "";
	protected $SqlSelect = "";
	protected $SqlSelectList = "";
	protected $SqlWhere = "";
	protected $SqlGroupBy = "";
	protected $SqlHaving = "";
	protected $SqlOrderBy = "";
	public $UseSessionForListSql = TRUE;

	// Column CSS classes
	public $LeftColumnClass = "col-sm-2 col-form-label ew-label";
	public $RightColumnClass = "col-sm-10";
	public $OffsetColumnClass = "col-sm-10 offset-sm-2";
	public $TableLeftColumnClass = "w-col-2";

	// Export
	public $ExportDoc;

	// Fields
	public $bridgeid;
	public $itemid;
	public $merchantid;
	public $externalcode;
	public $descshort;
	public $desclong;
	public $fixedamount;
	public $startamount;
	public $endamount;
	public $onsale;
	public $currcode;
	public $saleamount;
	public $active;
	public $field1label;
	public $field2label;
	public $field3label;
	public $timebound;
	public $starttime;
	public $endtime;
	public $restrictionid;
	public $verifyip;
	public $label1;
	public $label2;
	public $label3;
	public $location;
	public $supportedamounts;
	public $productsandservices;
	public $requiredfields;
	public $notificationemails;
	public $txid;
	public $posid;
	public $purchasedate;
	public $commissiondate;
	public $serialno;
	public $endoflifedate;
	public $shipdate;
	public $make;
	public $model;
	public $returneddate;
	public $friendlyname;
	public $notificationsms;

	// Constructor
	public function __construct()
	{
		global $Language, $CurrentLanguage;
		parent::__construct();

		// Language object
		if (!isset($Language))
			$Language = new Language();
		$this->TableVar = 'vmerchantbridgeitem';
		$this->TableName = 'vmerchantbridgeitem';
		$this->TableType = 'VIEW';

		// Update Table
		$this->UpdateTable = "`vmerchantbridgeitem`";
		$this->Dbid = 'DB';
		$this->ExportAll = TRUE;
		$this->ExportPageBreakCount = 0; // Page break per every n record (PDF only)
		$this->ExportPageOrientation = "portrait"; // Page orientation (PDF only)
		$this->ExportPageSize = "a4"; // Page size (PDF only)
		$this->ExportExcelPageOrientation = \PhpOffice\PhpSpreadsheet\Worksheet\PageSetup::ORIENTATION_DEFAULT; // Page orientation (PhpSpreadsheet only)
		$this->ExportExcelPageSize = \PhpOffice\PhpSpreadsheet\Worksheet\PageSetup::PAPERSIZE_A4; // Page size (PhpSpreadsheet only)
		$this->ExportWordPageOrientation = "portrait"; // Page orientation (PHPWord only)
		$this->ExportWordColumnWidth = NULL; // Cell width (PHPWord only)
		$this->DetailAdd = FALSE; // Allow detail add
		$this->DetailEdit = FALSE; // Allow detail edit
		$this->DetailView = FALSE; // Allow detail view
		$this->ShowMultipleDetails = FALSE; // Show multiple details
		$this->GridAddRowCount = 5;
		$this->AllowAddDeleteRow = TRUE; // Allow add/delete row
		$this->UserIDAllowSecurity = Config("DEFAULT_USER_ID_ALLOW_SECURITY"); // Default User ID allowed permissions
		$this->BasicSearch = new BasicSearch($this->TableVar);

		// bridgeid
		$this->bridgeid = new DbField('vmerchantbridgeitem', 'vmerchantbridgeitem', 'x_bridgeid', 'bridgeid', '`bridgeid`', '`bridgeid`', 20, 12, -1, FALSE, '`bridgeid`', FALSE, FALSE, FALSE, 'FORMATTED TEXT', 'NO');
		$this->bridgeid->IsAutoIncrement = TRUE; // Autoincrement field
		$this->bridgeid->IsPrimaryKey = TRUE; // Primary key field
		$this->bridgeid->Sortable = TRUE; // Allow sort
		$this->bridgeid->DefaultErrorMessage = $Language->phrase("IncorrectInteger");
		$this->fields['bridgeid'] = &$this->bridgeid;

		// itemid
		$this->itemid = new DbField('vmerchantbridgeitem', 'vmerchantbridgeitem', 'x_itemid', 'itemid', '`itemid`', '`itemid`', 20, 12, -1, FALSE, '`itemid`', FALSE, FALSE, FALSE, 'FORMATTED TEXT', 'NO');
		$this->itemid->IsAutoIncrement = TRUE; // Autoincrement field
		$this->itemid->IsPrimaryKey = TRUE; // Primary key field
		$this->itemid->Sortable = TRUE; // Allow sort
		$this->itemid->DefaultErrorMessage = $Language->phrase("IncorrectInteger");
		$this->fields['itemid'] = &$this->itemid;

		// merchantid
		$this->merchantid = new DbField('vmerchantbridgeitem', 'vmerchantbridgeitem', 'x_merchantid', 'merchantid', '`merchantid`', '`merchantid`', 20, 12, -1, FALSE, '`merchantid`', FALSE, FALSE, FALSE, 'FORMATTED TEXT', 'TEXT');
		$this->merchantid->Nullable = FALSE; // NOT NULL field
		$this->merchantid->Required = TRUE; // Required field
		$this->merchantid->Sortable = TRUE; // Allow sort
		$this->merchantid->DefaultErrorMessage = $Language->phrase("IncorrectInteger");
		$this->fields['merchantid'] = &$this->merchantid;

		// externalcode
		$this->externalcode = new DbField('vmerchantbridgeitem', 'vmerchantbridgeitem', 'x_externalcode', 'externalcode', '`externalcode`', '`externalcode`', 200, 50, -1, FALSE, '`externalcode`', FALSE, FALSE, FALSE, 'FORMATTED TEXT', 'TEXT');
		$this->externalcode->Sortable = TRUE; // Allow sort
		$this->fields['externalcode'] = &$this->externalcode;

		// descshort
		$this->descshort = new DbField('vmerchantbridgeitem', 'vmerchantbridgeitem', 'x_descshort', 'descshort', '`descshort`', '`descshort`', 200, 40, -1, FALSE, '`descshort`', FALSE, FALSE, FALSE, 'FORMATTED TEXT', 'TEXT');
		$this->descshort->Nullable = FALSE; // NOT NULL field
		$this->descshort->Required = TRUE; // Required field
		$this->descshort->Sortable = TRUE; // Allow sort
		$this->fields['descshort'] = &$this->descshort;

		// desclong
		$this->desclong = new DbField('vmerchantbridgeitem', 'vmerchantbridgeitem', 'x_desclong', 'desclong', '`desclong`', '`desclong`', 201, -1, -1, FALSE, '`desclong`', FALSE, FALSE, FALSE, 'FORMATTED TEXT', 'TEXTAREA');
		$this->desclong->Sortable = TRUE; // Allow sort
		$this->fields['desclong'] = &$this->desclong;

		// fixedamount
		$this->fixedamount = new DbField('vmerchantbridgeitem', 'vmerchantbridgeitem', 'x_fixedamount', 'fixedamount', '`fixedamount`', '`fixedamount`', 3, 1, -1, FALSE, '`fixedamount`', FALSE, FALSE, FALSE, 'FORMATTED TEXT', 'TEXT');
		$this->fixedamount->Nullable = FALSE; // NOT NULL field
		$this->fixedamount->Required = TRUE; // Required field
		$this->fixedamount->Sortable = TRUE; // Allow sort
		$this->fixedamount->DefaultErrorMessage = $Language->phrase("IncorrectInteger");
		$this->fields['fixedamount'] = &$this->fixedamount;

		// startamount
		$this->startamount = new DbField('vmerchantbridgeitem', 'vmerchantbridgeitem', 'x_startamount', 'startamount', '`startamount`', '`startamount`', 131, 12, -1, FALSE, '`startamount`', FALSE, FALSE, FALSE, 'FORMATTED TEXT', 'TEXT');
		$this->startamount->Nullable = FALSE; // NOT NULL field
		$this->startamount->Sortable = TRUE; // Allow sort
		$this->startamount->DefaultErrorMessage = $Language->phrase("IncorrectFloat");
		$this->fields['startamount'] = &$this->startamount;

		// endamount
		$this->endamount = new DbField('vmerchantbridgeitem', 'vmerchantbridgeitem', 'x_endamount', 'endamount', '`endamount`', '`endamount`', 131, 12, -1, FALSE, '`endamount`', FALSE, FALSE, FALSE, 'FORMATTED TEXT', 'TEXT');
		$this->endamount->Nullable = FALSE; // NOT NULL field
		$this->endamount->Sortable = TRUE; // Allow sort
		$this->endamount->DefaultErrorMessage = $Language->phrase("IncorrectFloat");
		$this->fields['endamount'] = &$this->endamount;

		// onsale
		$this->onsale = new DbField('vmerchantbridgeitem', 'vmerchantbridgeitem', 'x_onsale', 'onsale', '`onsale`', '`onsale`', 3, 1, -1, FALSE, '`onsale`', FALSE, FALSE, FALSE, 'FORMATTED TEXT', 'TEXT');
		$this->onsale->Nullable = FALSE; // NOT NULL field
		$this->onsale->Required = TRUE; // Required field
		$this->onsale->Sortable = TRUE; // Allow sort
		$this->onsale->DefaultErrorMessage = $Language->phrase("IncorrectInteger");
		$this->fields['onsale'] = &$this->onsale;

		// currcode
		$this->currcode = new DbField('vmerchantbridgeitem', 'vmerchantbridgeitem', 'x_currcode', 'currcode', '`currcode`', '`currcode`', 200, 3, -1, FALSE, '`currcode`', FALSE, FALSE, FALSE, 'FORMATTED TEXT', 'TEXT');
		$this->currcode->Nullable = FALSE; // NOT NULL field
		$this->currcode->Required = TRUE; // Required field
		$this->currcode->Sortable = TRUE; // Allow sort
		$this->fields['currcode'] = &$this->currcode;

		// saleamount
		$this->saleamount = new DbField('vmerchantbridgeitem', 'vmerchantbridgeitem', 'x_saleamount', 'saleamount', '`saleamount`', '`saleamount`', 131, 12, -1, FALSE, '`saleamount`', FALSE, FALSE, FALSE, 'FORMATTED TEXT', 'TEXT');
		$this->saleamount->Nullable = FALSE; // NOT NULL field
		$this->saleamount->Sortable = TRUE; // Allow sort
		$this->saleamount->DefaultErrorMessage = $Language->phrase("IncorrectFloat");
		$this->fields['saleamount'] = &$this->saleamount;

		// active
		$this->active = new DbField('vmerchantbridgeitem', 'vmerchantbridgeitem', 'x_active', 'active', '`active`', '`active`', 3, 1, -1, FALSE, '`active`', FALSE, FALSE, FALSE, 'FORMATTED TEXT', 'TEXT');
		$this->active->Nullable = FALSE; // NOT NULL field
		$this->active->Sortable = TRUE; // Allow sort
		$this->active->DefaultErrorMessage = $Language->phrase("IncorrectInteger");
		$this->fields['active'] = &$this->active;

		// field1label
		$this->field1label = new DbField('vmerchantbridgeitem', 'vmerchantbridgeitem', 'x_field1label', 'field1label', '`field1label`', '`field1label`', 200, 50, -1, FALSE, '`field1label`', FALSE, FALSE, FALSE, 'FORMATTED TEXT', 'TEXT');
		$this->field1label->Sortable = TRUE; // Allow sort
		$this->fields['field1label'] = &$this->field1label;

		// field2label
		$this->field2label = new DbField('vmerchantbridgeitem', 'vmerchantbridgeitem', 'x_field2label', 'field2label', '`field2label`', '`field2label`', 200, 50, -1, FALSE, '`field2label`', FALSE, FALSE, FALSE, 'FORMATTED TEXT', 'TEXT');
		$this->field2label->Sortable = TRUE; // Allow sort
		$this->fields['field2label'] = &$this->field2label;

		// field3label
		$this->field3label = new DbField('vmerchantbridgeitem', 'vmerchantbridgeitem', 'x_field3label', 'field3label', '`field3label`', '`field3label`', 200, 50, -1, FALSE, '`field3label`', FALSE, FALSE, FALSE, 'FORMATTED TEXT', 'TEXT');
		$this->field3label->Sortable = TRUE; // Allow sort
		$this->fields['field3label'] = &$this->field3label;

		// timebound
		$this->timebound = new DbField('vmerchantbridgeitem', 'vmerchantbridgeitem', 'x_timebound', 'timebound', '`timebound`', '`timebound`', 3, 1, -1, FALSE, '`timebound`', FALSE, FALSE, FALSE, 'FORMATTED TEXT', 'TEXT');
		$this->timebound->Nullable = FALSE; // NOT NULL field
		$this->timebound->Sortable = TRUE; // Allow sort
		$this->timebound->DefaultErrorMessage = $Language->phrase("IncorrectInteger");
		$this->fields['timebound'] = &$this->timebound;

		// starttime
		$this->starttime = new DbField('vmerchantbridgeitem', 'vmerchantbridgeitem', 'x_starttime', 'starttime', '`starttime`', CastDateFieldForLike("`starttime`", 4, "DB"), 134, 10, 4, FALSE, '`starttime`', FALSE, FALSE, FALSE, 'FORMATTED TEXT', 'TEXT');
		$this->starttime->Sortable = TRUE; // Allow sort
		$this->starttime->DefaultErrorMessage = str_replace("%s", $GLOBALS["TIME_SEPARATOR"], $Language->phrase("IncorrectTime"));
		$this->fields['starttime'] = &$this->starttime;

		// endtime
		$this->endtime = new DbField('vmerchantbridgeitem', 'vmerchantbridgeitem', 'x_endtime', 'endtime', '`endtime`', CastDateFieldForLike("`endtime`", 4, "DB"), 134, 10, 4, FALSE, '`endtime`', FALSE, FALSE, FALSE, 'FORMATTED TEXT', 'TEXT');
		$this->endtime->Sortable = TRUE; // Allow sort
		$this->endtime->DefaultErrorMessage = str_replace("%s", $GLOBALS["TIME_SEPARATOR"], $Language->phrase("IncorrectTime"));
		$this->fields['endtime'] = &$this->endtime;

		// restrictionid
		$this->restrictionid = new DbField('vmerchantbridgeitem', 'vmerchantbridgeitem', 'x_restrictionid', 'restrictionid', '`restrictionid`', '`restrictionid`', 200, 10, -1, FALSE, '`restrictionid`', FALSE, FALSE, FALSE, 'FORMATTED TEXT', 'TEXT');
		$this->restrictionid->Sortable = TRUE; // Allow sort
		$this->fields['restrictionid'] = &$this->restrictionid;

		// verifyip
		$this->verifyip = new DbField('vmerchantbridgeitem', 'vmerchantbridgeitem', 'x_verifyip', 'verifyip', '`verifyip`', '`verifyip`', 3, 1, -1, FALSE, '`verifyip`', FALSE, FALSE, FALSE, 'FORMATTED TEXT', 'TEXT');
		$this->verifyip->Nullable = FALSE; // NOT NULL field
		$this->verifyip->Sortable = TRUE; // Allow sort
		$this->verifyip->DefaultErrorMessage = $Language->phrase("IncorrectInteger");
		$this->fields['verifyip'] = &$this->verifyip;

		// label1
		$this->label1 = new DbField('vmerchantbridgeitem', 'vmerchantbridgeitem', 'x_label1', 'label1', '`label1`', '`label1`', 200, 50, -1, FALSE, '`label1`', FALSE, FALSE, FALSE, 'FORMATTED TEXT', 'TEXT');
		$this->label1->Sortable = TRUE; // Allow sort
		$this->fields['label1'] = &$this->label1;

		// label2
		$this->label2 = new DbField('vmerchantbridgeitem', 'vmerchantbridgeitem', 'x_label2', 'label2', '`label2`', '`label2`', 200, 50, -1, FALSE, '`label2`', FALSE, FALSE, FALSE, 'FORMATTED TEXT', 'TEXT');
		$this->label2->Sortable = TRUE; // Allow sort
		$this->fields['label2'] = &$this->label2;

		// label3
		$this->label3 = new DbField('vmerchantbridgeitem', 'vmerchantbridgeitem', 'x_label3', 'label3', '`label3`', '`label3`', 200, 50, -1, FALSE, '`label3`', FALSE, FALSE, FALSE, 'FORMATTED TEXT', 'TEXT');
		$this->label3->Sortable = TRUE; // Allow sort
		$this->fields['label3'] = &$this->label3;

		// location
		$this->location = new DbField('vmerchantbridgeitem', 'vmerchantbridgeitem', 'x_location', 'location', '`location`', '`location`', 200, 255, -1, FALSE, '`location`', FALSE, FALSE, FALSE, 'FORMATTED TEXT', 'TEXT');
		$this->location->Sortable = TRUE; // Allow sort
		$this->fields['location'] = &$this->location;

		// supportedamounts
		$this->supportedamounts = new DbField('vmerchantbridgeitem', 'vmerchantbridgeitem', 'x_supportedamounts', 'supportedamounts', '`supportedamounts`', '`supportedamounts`', 201, 0, -1, FALSE, '`supportedamounts`', FALSE, FALSE, FALSE, 'FORMATTED TEXT', 'TEXT');
		$this->supportedamounts->Sortable = TRUE; // Allow sort
		$this->fields['supportedamounts'] = &$this->supportedamounts;

		// productsandservices
		$this->productsandservices = new DbField('vmerchantbridgeitem', 'vmerchantbridgeitem', 'x_productsandservices', 'productsandservices', '`productsandservices`', '`productsandservices`', 201, 0, -1, FALSE, '`productsandservices`', FALSE, FALSE, FALSE, 'FORMATTED TEXT', 'TEXT');
		$this->productsandservices->Sortable = TRUE; // Allow sort
		$this->fields['productsandservices'] = &$this->productsandservices;

		// requiredfields
		$this->requiredfields = new DbField('vmerchantbridgeitem', 'vmerchantbridgeitem', 'x_requiredfields', 'requiredfields', '`requiredfields`', '`requiredfields`', 201, 0, -1, FALSE, '`requiredfields`', FALSE, FALSE, FALSE, 'FORMATTED TEXT', 'TEXT');
		$this->requiredfields->Sortable = TRUE; // Allow sort
		$this->fields['requiredfields'] = &$this->requiredfields;

		// notificationemails
		$this->notificationemails = new DbField('vmerchantbridgeitem', 'vmerchantbridgeitem', 'x_notificationemails', 'notificationemails', '`notificationemails`', '`notificationemails`', 201, 0, -1, FALSE, '`notificationemails`', FALSE, FALSE, FALSE, 'FORMATTED TEXT', 'TEXT');
		$this->notificationemails->Sortable = TRUE; // Allow sort
		$this->fields['notificationemails'] = &$this->notificationemails;

		// txid
		$this->txid = new DbField('vmerchantbridgeitem', 'vmerchantbridgeitem', 'x_txid', 'txid', '`txid`', '`txid`', 200, 15, -1, FALSE, '`txid`', FALSE, FALSE, FALSE, 'FORMATTED TEXT', 'TEXT');
		$this->txid->Sortable = TRUE; // Allow sort
		$this->fields['txid'] = &$this->txid;

		// posid
		$this->posid = new DbField('vmerchantbridgeitem', 'vmerchantbridgeitem', 'x_posid', 'posid', '`posid`', '`posid`', 20, 12, -1, FALSE, '`posid`', FALSE, FALSE, FALSE, 'FORMATTED TEXT', 'TEXT');
		$this->posid->Sortable = TRUE; // Allow sort
		$this->posid->DefaultErrorMessage = $Language->phrase("IncorrectInteger");
		$this->fields['posid'] = &$this->posid;

		// purchasedate
		$this->purchasedate = new DbField('vmerchantbridgeitem', 'vmerchantbridgeitem', 'x_purchasedate', 'purchasedate', '`purchasedate`', CastDateFieldForLike("`purchasedate`", 0, "DB"), 135, 19, 0, FALSE, '`purchasedate`', FALSE, FALSE, FALSE, 'FORMATTED TEXT', 'TEXT');
		$this->purchasedate->Sortable = TRUE; // Allow sort
		$this->purchasedate->DefaultErrorMessage = str_replace("%s", $GLOBALS["DATE_FORMAT"], $Language->phrase("IncorrectDate"));
		$this->fields['purchasedate'] = &$this->purchasedate;

		// commissiondate
		$this->commissiondate = new DbField('vmerchantbridgeitem', 'vmerchantbridgeitem', 'x_commissiondate', 'commissiondate', '`commissiondate`', CastDateFieldForLike("`commissiondate`", 0, "DB"), 135, 19, 0, FALSE, '`commissiondate`', FALSE, FALSE, FALSE, 'FORMATTED TEXT', 'TEXT');
		$this->commissiondate->Sortable = TRUE; // Allow sort
		$this->commissiondate->DefaultErrorMessage = str_replace("%s", $GLOBALS["DATE_FORMAT"], $Language->phrase("IncorrectDate"));
		$this->fields['commissiondate'] = &$this->commissiondate;

		// serialno
		$this->serialno = new DbField('vmerchantbridgeitem', 'vmerchantbridgeitem', 'x_serialno', 'serialno', '`serialno`', '`serialno`', 200, 20, -1, FALSE, '`serialno`', FALSE, FALSE, FALSE, 'FORMATTED TEXT', 'TEXT');
		$this->serialno->Sortable = TRUE; // Allow sort
		$this->fields['serialno'] = &$this->serialno;

		// endoflifedate
		$this->endoflifedate = new DbField('vmerchantbridgeitem', 'vmerchantbridgeitem', 'x_endoflifedate', 'endoflifedate', '`endoflifedate`', CastDateFieldForLike("`endoflifedate`", 0, "DB"), 135, 19, 0, FALSE, '`endoflifedate`', FALSE, FALSE, FALSE, 'FORMATTED TEXT', 'TEXT');
		$this->endoflifedate->Sortable = TRUE; // Allow sort
		$this->endoflifedate->DefaultErrorMessage = str_replace("%s", $GLOBALS["DATE_FORMAT"], $Language->phrase("IncorrectDate"));
		$this->fields['endoflifedate'] = &$this->endoflifedate;

		// shipdate
		$this->shipdate = new DbField('vmerchantbridgeitem', 'vmerchantbridgeitem', 'x_shipdate', 'shipdate', '`shipdate`', CastDateFieldForLike("`shipdate`", 0, "DB"), 135, 19, 0, FALSE, '`shipdate`', FALSE, FALSE, FALSE, 'FORMATTED TEXT', 'TEXT');
		$this->shipdate->Sortable = TRUE; // Allow sort
		$this->shipdate->DefaultErrorMessage = str_replace("%s", $GLOBALS["DATE_FORMAT"], $Language->phrase("IncorrectDate"));
		$this->fields['shipdate'] = &$this->shipdate;

		// make
		$this->make = new DbField('vmerchantbridgeitem', 'vmerchantbridgeitem', 'x_make', 'make', '`make`', '`make`', 200, 20, -1, FALSE, '`make`', FALSE, FALSE, FALSE, 'FORMATTED TEXT', 'TEXT');
		$this->make->Sortable = TRUE; // Allow sort
		$this->fields['make'] = &$this->make;

		// model
		$this->model = new DbField('vmerchantbridgeitem', 'vmerchantbridgeitem', 'x_model', 'model', '`model`', '`model`', 200, 20, -1, FALSE, '`model`', FALSE, FALSE, FALSE, 'FORMATTED TEXT', 'TEXT');
		$this->model->Sortable = TRUE; // Allow sort
		$this->fields['model'] = &$this->model;

		// returneddate
		$this->returneddate = new DbField('vmerchantbridgeitem', 'vmerchantbridgeitem', 'x_returneddate', 'returneddate', '`returneddate`', CastDateFieldForLike("`returneddate`", 0, "DB"), 135, 19, 0, FALSE, '`returneddate`', FALSE, FALSE, FALSE, 'FORMATTED TEXT', 'TEXT');
		$this->returneddate->Sortable = TRUE; // Allow sort
		$this->returneddate->DefaultErrorMessage = str_replace("%s", $GLOBALS["DATE_FORMAT"], $Language->phrase("IncorrectDate"));
		$this->fields['returneddate'] = &$this->returneddate;

		// friendlyname
		$this->friendlyname = new DbField('vmerchantbridgeitem', 'vmerchantbridgeitem', 'x_friendlyname', 'friendlyname', '`friendlyname`', '`friendlyname`', 200, 50, -1, FALSE, '`friendlyname`', FALSE, FALSE, FALSE, 'FORMATTED TEXT', 'TEXT');
		$this->friendlyname->Sortable = TRUE; // Allow sort
		$this->fields['friendlyname'] = &$this->friendlyname;

		// notificationsms
		$this->notificationsms = new DbField('vmerchantbridgeitem', 'vmerchantbridgeitem', 'x_notificationsms', 'notificationsms', '`notificationsms`', '`notificationsms`', 201, 0, -1, FALSE, '`notificationsms`', FALSE, FALSE, FALSE, 'FORMATTED TEXT', 'TEXTAREA');
		$this->notificationsms->Sortable = TRUE; // Allow sort
		$this->fields['notificationsms'] = &$this->notificationsms;
	}

	// Field Visibility
	public function getFieldVisibility($fldParm)
	{
		global $Security;
		return $this->$fldParm->Visible; // Returns original value
	}

	// Set left column class (must be predefined col-*-* classes of Bootstrap grid system)
	function setLeftColumnClass($class)
	{
		if (preg_match('/^col\-(\w+)\-(\d+)$/', $class, $match)) {
			$this->LeftColumnClass = $class . " col-form-label ew-label";
			$this->RightColumnClass = "col-" . $match[1] . "-" . strval(12 - (int)$match[2]);
			$this->OffsetColumnClass = $this->RightColumnClass . " " . str_replace("col-", "offset-", $class);
			$this->TableLeftColumnClass = preg_replace('/^col-\w+-(\d+)$/', "w-col-$1", $class); // Change to w-col-*
		}
	}

	// Single column sort
	public function updateSort(&$fld)
	{
		if ($this->CurrentOrder == $fld->Name) {
			$sortField = $fld->Expression;
			$lastSort = $fld->getSort();
			if ($this->CurrentOrderType == "ASC" || $this->CurrentOrderType == "DESC") {
				$thisSort = $this->CurrentOrderType;
			} else {
				$thisSort = ($lastSort == "ASC") ? "DESC" : "ASC";
			}
			$fld->setSort($thisSort);
			$this->setSessionOrderBy($sortField . " " . $thisSort); // Save to Session
		} else {
			$fld->setSort("");
		}
	}

	// Table level SQL
	public function getSqlFrom() // From
	{
		return ($this->SqlFrom != "") ? $this->SqlFrom : "`vmerchantbridgeitem`";
	}
	public function sqlFrom() // For backward compatibility
	{
		return $this->getSqlFrom();
	}
	public function setSqlFrom($v)
	{
		$this->SqlFrom = $v;
	}
	public function getSqlSelect() // Select
	{
		return ($this->SqlSelect != "") ? $this->SqlSelect : "SELECT * FROM " . $this->getSqlFrom();
	}
	public function sqlSelect() // For backward compatibility
	{
		return $this->getSqlSelect();
	}
	public function setSqlSelect($v)
	{
		$this->SqlSelect = $v;
	}
	public function getSqlWhere() // Where
	{
		$where = ($this->SqlWhere != "") ? $this->SqlWhere : "";
		$this->TableFilter = "";
		AddFilter($where, $this->TableFilter);
		return $where;
	}
	public function sqlWhere() // For backward compatibility
	{
		return $this->getSqlWhere();
	}
	public function setSqlWhere($v)
	{
		$this->SqlWhere = $v;
	}
	public function getSqlGroupBy() // Group By
	{
		return ($this->SqlGroupBy != "") ? $this->SqlGroupBy : "";
	}
	public function sqlGroupBy() // For backward compatibility
	{
		return $this->getSqlGroupBy();
	}
	public function setSqlGroupBy($v)
	{
		$this->SqlGroupBy = $v;
	}
	public function getSqlHaving() // Having
	{
		return ($this->SqlHaving != "") ? $this->SqlHaving : "";
	}
	public function sqlHaving() // For backward compatibility
	{
		return $this->getSqlHaving();
	}
	public function setSqlHaving($v)
	{
		$this->SqlHaving = $v;
	}
	public function getSqlOrderBy() // Order By
	{
		return ($this->SqlOrderBy != "") ? $this->SqlOrderBy : "";
	}
	public function sqlOrderBy() // For backward compatibility
	{
		return $this->getSqlOrderBy();
	}
	public function setSqlOrderBy($v)
	{
		$this->SqlOrderBy = $v;
	}

	// Apply User ID filters
	public function applyUserIDFilters($filter, $id = "")
	{
		return $filter;
	}

	// Check if User ID security allows view all
	public function userIDAllow($id = "")
	{
		$allow = $this->UserIDAllowSecurity;
		switch ($id) {
			case "add":
			case "copy":
			case "gridadd":
			case "register":
			case "addopt":
				return (($allow & 1) == 1);
			case "edit":
			case "gridedit":
			case "update":
			case "changepwd":
			case "forgotpwd":
				return (($allow & 4) == 4);
			case "delete":
				return (($allow & 2) == 2);
			case "view":
				return (($allow & 32) == 32);
			case "search":
				return (($allow & 64) == 64);
			case "lookup":
				return (($allow & 256) == 256);
			default:
				return (($allow & 8) == 8);
		}
	}

	// Get recordset
	public function getRecordset($sql, $rowcnt = -1, $offset = -1)
	{
		$conn = $this->getConnection();
		$conn->raiseErrorFn = Config("ERROR_FUNC");
		$rs = $conn->selectLimit($sql, $rowcnt, $offset);
		$conn->raiseErrorFn = "";
		return $rs;
	}

	// Get record count
	public function getRecordCount($sql, $c = NULL)
	{
		$cnt = -1;
		$rs = NULL;
		$sql = preg_replace('/\/\*BeginOrderBy\*\/[\s\S]+\/\*EndOrderBy\*\//', "", $sql); // Remove ORDER BY clause (MSSQL)
		$pattern = '/^SELECT\s([\s\S]+)\sFROM\s/i';

		// Skip Custom View / SubQuery / SELECT DISTINCT / ORDER BY
		if (($this->TableType == 'TABLE' || $this->TableType == 'VIEW' || $this->TableType == 'LINKTABLE') &&
			preg_match($pattern, $sql) && !preg_match('/\(\s*(SELECT[^)]+)\)/i', $sql) &&
			!preg_match('/^\s*select\s+distinct\s+/i', $sql) && !preg_match('/\s+order\s+by\s+/i', $sql)) {
			$sqlwrk = "SELECT COUNT(*) FROM " . preg_replace($pattern, "", $sql);
		} else {
			$sqlwrk = "SELECT COUNT(*) FROM (" . $sql . ") COUNT_TABLE";
		}
		$conn = $c ?: $this->getConnection();
		if ($rs = $conn->execute($sqlwrk)) {
			if (!$rs->EOF && $rs->FieldCount() > 0) {
				$cnt = $rs->fields[0];
				$rs->close();
			}
			return (int)$cnt;
		}

		// Unable to get count, get record count directly
		if ($rs = $conn->execute($sql)) {
			$cnt = $rs->RecordCount();
			$rs->close();
			return (int)$cnt;
		}
		return $cnt;
	}

	// Get SQL
	public function getSql($where, $orderBy = "")
	{
		return BuildSelectSql($this->getSqlSelect(), $this->getSqlWhere(),
			$this->getSqlGroupBy(), $this->getSqlHaving(), $this->getSqlOrderBy(),
			$where, $orderBy);
	}

	// Table SQL
	public function getCurrentSql()
	{
		$filter = $this->CurrentFilter;
		$filter = $this->applyUserIDFilters($filter);
		$sort = $this->getSessionOrderBy();
		return $this->getSql($filter, $sort);
	}

	// Table SQL with List page filter
	public function getListSql()
	{
		$filter = $this->UseSessionForListSql ? $this->getSessionWhere() : "";
		AddFilter($filter, $this->CurrentFilter);
		$filter = $this->applyUserIDFilters($filter);
		$this->Recordset_Selecting($filter);
		$select = $this->getSqlSelect();
		$sort = $this->UseSessionForListSql ? $this->getSessionOrderBy() : "";
		return BuildSelectSql($select, $this->getSqlWhere(), $this->getSqlGroupBy(),
			$this->getSqlHaving(), $this->getSqlOrderBy(), $filter, $sort);
	}

	// Get ORDER BY clause
	public function getOrderBy()
	{
		$sort = $this->getSessionOrderBy();
		return BuildSelectSql("", "", "", "", $this->getSqlOrderBy(), "", $sort);
	}

	// Get record count based on filter (for detail record count in master table pages)
	public function loadRecordCount($filter)
	{
		$origFilter = $this->CurrentFilter;
		$this->CurrentFilter = $filter;
		$this->Recordset_Selecting($this->CurrentFilter);
		$select = $this->TableType == 'CUSTOMVIEW' ? $this->getSqlSelect() : "SELECT * FROM " . $this->getSqlFrom();
		$groupBy = $this->TableType == 'CUSTOMVIEW' ? $this->getSqlGroupBy() : "";
		$having = $this->TableType == 'CUSTOMVIEW' ? $this->getSqlHaving() : "";
		$sql = BuildSelectSql($select, $this->getSqlWhere(), $groupBy, $having, "", $this->CurrentFilter, "");
		$cnt = $this->getRecordCount($sql);
		$this->CurrentFilter = $origFilter;
		return $cnt;
	}

	// Get record count (for current List page)
	public function listRecordCount()
	{
		$filter = $this->getSessionWhere();
		AddFilter($filter, $this->CurrentFilter);
		$filter = $this->applyUserIDFilters($filter);
		$this->Recordset_Selecting($filter);
		$select = $this->TableType == 'CUSTOMVIEW' ? $this->getSqlSelect() : "SELECT * FROM " . $this->getSqlFrom();
		$groupBy = $this->TableType == 'CUSTOMVIEW' ? $this->getSqlGroupBy() : "";
		$having = $this->TableType == 'CUSTOMVIEW' ? $this->getSqlHaving() : "";
		$sql = BuildSelectSql($select, $this->getSqlWhere(), $groupBy, $having, "", $filter, "");
		$cnt = $this->getRecordCount($sql);
		return $cnt;
	}

	// INSERT statement
	protected function insertSql(&$rs)
	{
		$names = "";
		$values = "";
		foreach ($rs as $name => $value) {
			if (!isset($this->fields[$name]) || $this->fields[$name]->IsCustom)
				continue;
			$names .= $this->fields[$name]->Expression . ",";
			$values .= QuotedValue($value, $this->fields[$name]->DataType, $this->Dbid) . ",";
		}
		$names = preg_replace('/,+$/', "", $names);
		$values = preg_replace('/,+$/', "", $values);
		return "INSERT INTO " . $this->UpdateTable . " (" . $names . ") VALUES (" . $values . ")";
	}

	// Insert
	public function insert(&$rs)
	{
		$conn = $this->getConnection();
		$success = $conn->execute($this->insertSql($rs));
		if ($success) {

			// Get insert id if necessary
			$this->bridgeid->setDbValue($conn->insert_ID());
			$rs['bridgeid'] = $this->bridgeid->DbValue;

			// Get insert id if necessary
			$this->itemid->setDbValue($conn->insert_ID());
			$rs['itemid'] = $this->itemid->DbValue;
		}
		return $success;
	}

	// UPDATE statement
	protected function updateSql(&$rs, $where = "", $curfilter = TRUE)
	{
		$sql = "UPDATE " . $this->UpdateTable . " SET ";
		foreach ($rs as $name => $value) {
			if (!isset($this->fields[$name]) || $this->fields[$name]->IsCustom || $this->fields[$name]->IsAutoIncrement)
				continue;
			$sql .= $this->fields[$name]->Expression . "=";
			$sql .= QuotedValue($value, $this->fields[$name]->DataType, $this->Dbid) . ",";
		}
		$sql = preg_replace('/,+$/', "", $sql);
		$filter = ($curfilter) ? $this->CurrentFilter : "";
		if (is_array($where))
			$where = $this->arrayToFilter($where);
		AddFilter($filter, $where);
		if ($filter != "")
			$sql .= " WHERE " . $filter;
		return $sql;
	}

	// Update
	public function update(&$rs, $where = "", $rsold = NULL, $curfilter = TRUE)
	{
		$conn = $this->getConnection();
		$success = $conn->execute($this->updateSql($rs, $where, $curfilter));
		return $success;
	}

	// DELETE statement
	protected function deleteSql(&$rs, $where = "", $curfilter = TRUE)
	{
		$sql = "DELETE FROM " . $this->UpdateTable . " WHERE ";
		if (is_array($where))
			$where = $this->arrayToFilter($where);
		if ($rs) {
			if (array_key_exists('bridgeid', $rs))
				AddFilter($where, QuotedName('bridgeid', $this->Dbid) . '=' . QuotedValue($rs['bridgeid'], $this->bridgeid->DataType, $this->Dbid));
			if (array_key_exists('itemid', $rs))
				AddFilter($where, QuotedName('itemid', $this->Dbid) . '=' . QuotedValue($rs['itemid'], $this->itemid->DataType, $this->Dbid));
		}
		$filter = ($curfilter) ? $this->CurrentFilter : "";
		AddFilter($filter, $where);
		if ($filter != "")
			$sql .= $filter;
		else
			$sql .= "0=1"; // Avoid delete
		return $sql;
	}

	// Delete
	public function delete(&$rs, $where = "", $curfilter = FALSE)
	{
		$success = TRUE;
		$conn = $this->getConnection();
		if ($success)
			$success = $conn->execute($this->deleteSql($rs, $where, $curfilter));
		return $success;
	}

	// Load DbValue from recordset or array
	protected function loadDbValues(&$rs)
	{
		if (!$rs || !is_array($rs) && $rs->EOF)
			return;
		$row = is_array($rs) ? $rs : $rs->fields;
		$this->bridgeid->DbValue = $row['bridgeid'];
		$this->itemid->DbValue = $row['itemid'];
		$this->merchantid->DbValue = $row['merchantid'];
		$this->externalcode->DbValue = $row['externalcode'];
		$this->descshort->DbValue = $row['descshort'];
		$this->desclong->DbValue = $row['desclong'];
		$this->fixedamount->DbValue = $row['fixedamount'];
		$this->startamount->DbValue = $row['startamount'];
		$this->endamount->DbValue = $row['endamount'];
		$this->onsale->DbValue = $row['onsale'];
		$this->currcode->DbValue = $row['currcode'];
		$this->saleamount->DbValue = $row['saleamount'];
		$this->active->DbValue = $row['active'];
		$this->field1label->DbValue = $row['field1label'];
		$this->field2label->DbValue = $row['field2label'];
		$this->field3label->DbValue = $row['field3label'];
		$this->timebound->DbValue = $row['timebound'];
		$this->starttime->DbValue = $row['starttime'];
		$this->endtime->DbValue = $row['endtime'];
		$this->restrictionid->DbValue = $row['restrictionid'];
		$this->verifyip->DbValue = $row['verifyip'];
		$this->label1->DbValue = $row['label1'];
		$this->label2->DbValue = $row['label2'];
		$this->label3->DbValue = $row['label3'];
		$this->location->DbValue = $row['location'];
		$this->supportedamounts->DbValue = $row['supportedamounts'];
		$this->productsandservices->DbValue = $row['productsandservices'];
		$this->requiredfields->DbValue = $row['requiredfields'];
		$this->notificationemails->DbValue = $row['notificationemails'];
		$this->txid->DbValue = $row['txid'];
		$this->posid->DbValue = $row['posid'];
		$this->purchasedate->DbValue = $row['purchasedate'];
		$this->commissiondate->DbValue = $row['commissiondate'];
		$this->serialno->DbValue = $row['serialno'];
		$this->endoflifedate->DbValue = $row['endoflifedate'];
		$this->shipdate->DbValue = $row['shipdate'];
		$this->make->DbValue = $row['make'];
		$this->model->DbValue = $row['model'];
		$this->returneddate->DbValue = $row['returneddate'];
		$this->friendlyname->DbValue = $row['friendlyname'];
		$this->notificationsms->DbValue = $row['notificationsms'];
	}

	// Delete uploaded files
	public function deleteUploadedFiles($row)
	{
		$this->loadDbValues($row);
	}

	// Record filter WHERE clause
	protected function sqlKeyFilter()
	{
		return "`bridgeid` = @bridgeid@ AND `itemid` = @itemid@";
	}

	// Get record filter
	public function getRecordFilter($row = NULL)
	{
		$keyFilter = $this->sqlKeyFilter();
		if (is_array($row))
			$val = array_key_exists('bridgeid', $row) ? $row['bridgeid'] : NULL;
		else
			$val = $this->bridgeid->OldValue !== NULL ? $this->bridgeid->OldValue : $this->bridgeid->CurrentValue;
		if (!is_numeric($val))
			return "0=1"; // Invalid key
		if ($val == NULL)
			return "0=1"; // Invalid key
		else
			$keyFilter = str_replace("@bridgeid@", AdjustSql($val, $this->Dbid), $keyFilter); // Replace key value
		if (is_array($row))
			$val = array_key_exists('itemid', $row) ? $row['itemid'] : NULL;
		else
			$val = $this->itemid->OldValue !== NULL ? $this->itemid->OldValue : $this->itemid->CurrentValue;
		if (!is_numeric($val))
			return "0=1"; // Invalid key
		if ($val == NULL)
			return "0=1"; // Invalid key
		else
			$keyFilter = str_replace("@itemid@", AdjustSql($val, $this->Dbid), $keyFilter); // Replace key value
		return $keyFilter;
	}

	// Return page URL
	public function getReturnUrl()
	{
		$name = PROJECT_NAME . "_" . $this->TableVar . "_" . Config("TABLE_RETURN_URL");

		// Get referer URL automatically
		if (ServerVar("HTTP_REFERER") != "" && ReferPageName() != CurrentPageName() && ReferPageName() != "login.php") // Referer not same page or login page
			$_SESSION[$name] = ServerVar("HTTP_REFERER"); // Save to Session
		if (@$_SESSION[$name] != "") {
			return $_SESSION[$name];
		} else {
			return "vmerchantbridgeitemlist.php";
		}
	}
	public function setReturnUrl($v)
	{
		$_SESSION[PROJECT_NAME . "_" . $this->TableVar . "_" . Config("TABLE_RETURN_URL")] = $v;
	}

	// Get modal caption
	public function getModalCaption($pageName)
	{
		global $Language;
		if ($pageName == "vmerchantbridgeitemview.php")
			return $Language->phrase("View");
		elseif ($pageName == "vmerchantbridgeitemedit.php")
			return $Language->phrase("Edit");
		elseif ($pageName == "vmerchantbridgeitemadd.php")
			return $Language->phrase("Add");
		else
			return "";
	}

	// List URL
	public function getListUrl()
	{
		return "vmerchantbridgeitemlist.php";
	}

	// View URL
	public function getViewUrl($parm = "")
	{
		if ($parm != "")
			$url = $this->keyUrl("vmerchantbridgeitemview.php", $this->getUrlParm($parm));
		else
			$url = $this->keyUrl("vmerchantbridgeitemview.php", $this->getUrlParm(Config("TABLE_SHOW_DETAIL") . "="));
		return $this->addMasterUrl($url);
	}

	// Add URL
	public function getAddUrl($parm = "")
	{
		if ($parm != "")
			$url = "vmerchantbridgeitemadd.php?" . $this->getUrlParm($parm);
		else
			$url = "vmerchantbridgeitemadd.php";
		return $this->addMasterUrl($url);
	}

	// Edit URL
	public function getEditUrl($parm = "")
	{
		$url = $this->keyUrl("vmerchantbridgeitemedit.php", $this->getUrlParm($parm));
		return $this->addMasterUrl($url);
	}

	// Inline edit URL
	public function getInlineEditUrl()
	{
		$url = $this->keyUrl(CurrentPageName(), $this->getUrlParm("action=edit"));
		return $this->addMasterUrl($url);
	}

	// Copy URL
	public function getCopyUrl($parm = "")
	{
		$url = $this->keyUrl("vmerchantbridgeitemadd.php", $this->getUrlParm($parm));
		return $this->addMasterUrl($url);
	}

	// Inline copy URL
	public function getInlineCopyUrl()
	{
		$url = $this->keyUrl(CurrentPageName(), $this->getUrlParm("action=copy"));
		return $this->addMasterUrl($url);
	}

	// Delete URL
	public function getDeleteUrl()
	{
		return $this->keyUrl("vmerchantbridgeitemdelete.php", $this->getUrlParm());
	}

	// Add master url
	public function addMasterUrl($url)
	{
		return $url;
	}
	public function keyToJson($htmlEncode = FALSE)
	{
		$json = "";
		$json .= "bridgeid:" . JsonEncode($this->bridgeid->CurrentValue, "number");
		$json .= ",itemid:" . JsonEncode($this->itemid->CurrentValue, "number");
		$json = "{" . $json . "}";
		if ($htmlEncode)
			$json = HtmlEncode($json);
		return $json;
	}

	// Add key value to URL
	public function keyUrl($url, $parm = "")
	{
		$url = $url . "?";
		if ($parm != "")
			$url .= $parm . "&";
		if ($this->bridgeid->CurrentValue != NULL) {
			$url .= "bridgeid=" . urlencode($this->bridgeid->CurrentValue);
		} else {
			return "javascript:ew.alert(ew.language.phrase('InvalidRecord'));";
		}
		if ($this->itemid->CurrentValue != NULL) {
			$url .= "&itemid=" . urlencode($this->itemid->CurrentValue);
		} else {
			return "javascript:ew.alert(ew.language.phrase('InvalidRecord'));";
		}
		return $url;
	}

	// Sort URL
	public function sortUrl(&$fld)
	{
		if ($this->CurrentAction || $this->isExport() ||
			in_array($fld->Type, [128, 204, 205])) { // Unsortable data type
				return "";
		} elseif ($fld->Sortable) {
			$urlParm = $this->getUrlParm("order=" . urlencode($fld->Name) . "&amp;ordertype=" . $fld->reverseSort());
			return $this->addMasterUrl(CurrentPageName() . "?" . $urlParm);
		} else {
			return "";
		}
	}

	// Get record keys from Post/Get/Session
	public function getRecordKeys()
	{
		$arKeys = [];
		$arKey = [];
		if (Param("key_m") !== NULL) {
			$arKeys = Param("key_m");
			$cnt = count($arKeys);
			for ($i = 0; $i < $cnt; $i++)
				$arKeys[$i] = explode(Config("COMPOSITE_KEY_SEPARATOR"), $arKeys[$i]);
		} else {
			if (Param("bridgeid") !== NULL)
				$arKey[] = Param("bridgeid");
			elseif (IsApi() && Key(0) !== NULL)
				$arKey[] = Key(0);
			elseif (IsApi() && Route(2) !== NULL)
				$arKey[] = Route(2);
			else
				$arKeys = NULL; // Do not setup
			if (Param("itemid") !== NULL)
				$arKey[] = Param("itemid");
			elseif (IsApi() && Key(1) !== NULL)
				$arKey[] = Key(1);
			elseif (IsApi() && Route(3) !== NULL)
				$arKey[] = Route(3);
			else
				$arKeys = NULL; // Do not setup
			if (is_array($arKeys)) $arKeys[] = $arKey;

			//return $arKeys; // Do not return yet, so the values will also be checked by the following code
		}

		// Check keys
		$ar = [];
		if (is_array($arKeys)) {
			foreach ($arKeys as $key) {
				if (!is_array($key) || count($key) != 2)
					continue; // Just skip so other keys will still work
				if (!is_numeric($key[0])) // bridgeid
					continue;
				if (!is_numeric($key[1])) // itemid
					continue;
				$ar[] = $key;
			}
		}
		return $ar;
	}

	// Get filter from record keys
	public function getFilterFromRecordKeys($setCurrent = TRUE)
	{
		$arKeys = $this->getRecordKeys();
		$keyFilter = "";
		foreach ($arKeys as $key) {
			if ($keyFilter != "") $keyFilter .= " OR ";
			if ($setCurrent)
				$this->bridgeid->CurrentValue = $key[0];
			else
				$this->bridgeid->OldValue = $key[0];
			if ($setCurrent)
				$this->itemid->CurrentValue = $key[1];
			else
				$this->itemid->OldValue = $key[1];
			$keyFilter .= "(" . $this->getRecordFilter() . ")";
		}
		return $keyFilter;
	}

	// Load rows based on filter
	public function &loadRs($filter)
	{

		// Set up filter (WHERE Clause)
		$sql = $this->getSql($filter);
		$conn = $this->getConnection();
		$rs = $conn->execute($sql);
		return $rs;
	}

	// Load row values from recordset
	public function loadListRowValues(&$rs)
	{
		$this->bridgeid->setDbValue($rs->fields('bridgeid'));
		$this->itemid->setDbValue($rs->fields('itemid'));
		$this->merchantid->setDbValue($rs->fields('merchantid'));
		$this->externalcode->setDbValue($rs->fields('externalcode'));
		$this->descshort->setDbValue($rs->fields('descshort'));
		$this->desclong->setDbValue($rs->fields('desclong'));
		$this->fixedamount->setDbValue($rs->fields('fixedamount'));
		$this->startamount->setDbValue($rs->fields('startamount'));
		$this->endamount->setDbValue($rs->fields('endamount'));
		$this->onsale->setDbValue($rs->fields('onsale'));
		$this->currcode->setDbValue($rs->fields('currcode'));
		$this->saleamount->setDbValue($rs->fields('saleamount'));
		$this->active->setDbValue($rs->fields('active'));
		$this->field1label->setDbValue($rs->fields('field1label'));
		$this->field2label->setDbValue($rs->fields('field2label'));
		$this->field3label->setDbValue($rs->fields('field3label'));
		$this->timebound->setDbValue($rs->fields('timebound'));
		$this->starttime->setDbValue($rs->fields('starttime'));
		$this->endtime->setDbValue($rs->fields('endtime'));
		$this->restrictionid->setDbValue($rs->fields('restrictionid'));
		$this->verifyip->setDbValue($rs->fields('verifyip'));
		$this->label1->setDbValue($rs->fields('label1'));
		$this->label2->setDbValue($rs->fields('label2'));
		$this->label3->setDbValue($rs->fields('label3'));
		$this->location->setDbValue($rs->fields('location'));
		$this->supportedamounts->setDbValue($rs->fields('supportedamounts'));
		$this->productsandservices->setDbValue($rs->fields('productsandservices'));
		$this->requiredfields->setDbValue($rs->fields('requiredfields'));
		$this->notificationemails->setDbValue($rs->fields('notificationemails'));
		$this->txid->setDbValue($rs->fields('txid'));
		$this->posid->setDbValue($rs->fields('posid'));
		$this->purchasedate->setDbValue($rs->fields('purchasedate'));
		$this->commissiondate->setDbValue($rs->fields('commissiondate'));
		$this->serialno->setDbValue($rs->fields('serialno'));
		$this->endoflifedate->setDbValue($rs->fields('endoflifedate'));
		$this->shipdate->setDbValue($rs->fields('shipdate'));
		$this->make->setDbValue($rs->fields('make'));
		$this->model->setDbValue($rs->fields('model'));
		$this->returneddate->setDbValue($rs->fields('returneddate'));
		$this->friendlyname->setDbValue($rs->fields('friendlyname'));
		$this->notificationsms->setDbValue($rs->fields('notificationsms'));
	}

	// Render list row values
	public function renderListRow()
	{
		global $Security, $CurrentLanguage, $Language;

		// Call Row Rendering event
		$this->Row_Rendering();

		// Common render codes
		// bridgeid
		// itemid
		// merchantid
		// externalcode
		// descshort
		// desclong
		// fixedamount
		// startamount
		// endamount
		// onsale
		// currcode
		// saleamount
		// active
		// field1label
		// field2label
		// field3label
		// timebound
		// starttime
		// endtime
		// restrictionid
		// verifyip
		// label1
		// label2
		// label3
		// location
		// supportedamounts
		// productsandservices
		// requiredfields
		// notificationemails
		// txid
		// posid
		// purchasedate
		// commissiondate
		// serialno
		// endoflifedate
		// shipdate
		// make
		// model
		// returneddate
		// friendlyname
		// notificationsms
		// bridgeid

		$this->bridgeid->ViewValue = $this->bridgeid->CurrentValue;
		$this->bridgeid->ViewValue = FormatNumber($this->bridgeid->ViewValue, 0, -2, -2, -2);
		$this->bridgeid->ViewCustomAttributes = "";

		// itemid
		$this->itemid->ViewValue = $this->itemid->CurrentValue;
		$this->itemid->ViewCustomAttributes = "";

		// merchantid
		$this->merchantid->ViewValue = $this->merchantid->CurrentValue;
		$this->merchantid->ViewValue = FormatNumber($this->merchantid->ViewValue, 0, -2, -2, -2);
		$this->merchantid->ViewCustomAttributes = "";

		// externalcode
		$this->externalcode->ViewValue = $this->externalcode->CurrentValue;
		$this->externalcode->ViewCustomAttributes = "";

		// descshort
		$this->descshort->ViewValue = $this->descshort->CurrentValue;
		$this->descshort->ViewCustomAttributes = "";

		// desclong
		$this->desclong->ViewValue = $this->desclong->CurrentValue;
		$this->desclong->ViewCustomAttributes = "";

		// fixedamount
		$this->fixedamount->ViewValue = $this->fixedamount->CurrentValue;
		$this->fixedamount->ViewValue = FormatNumber($this->fixedamount->ViewValue, 0, -2, -2, -2);
		$this->fixedamount->ViewCustomAttributes = "";

		// startamount
		$this->startamount->ViewValue = $this->startamount->CurrentValue;
		$this->startamount->ViewValue = FormatNumber($this->startamount->ViewValue, 2, -2, -2, -2);
		$this->startamount->ViewCustomAttributes = "";

		// endamount
		$this->endamount->ViewValue = $this->endamount->CurrentValue;
		$this->endamount->ViewValue = FormatNumber($this->endamount->ViewValue, 2, -2, -2, -2);
		$this->endamount->ViewCustomAttributes = "";

		// onsale
		$this->onsale->ViewValue = $this->onsale->CurrentValue;
		$this->onsale->ViewValue = FormatNumber($this->onsale->ViewValue, 0, -2, -2, -2);
		$this->onsale->ViewCustomAttributes = "";

		// currcode
		$this->currcode->ViewValue = $this->currcode->CurrentValue;
		$this->currcode->ViewCustomAttributes = "";

		// saleamount
		$this->saleamount->ViewValue = $this->saleamount->CurrentValue;
		$this->saleamount->ViewValue = FormatNumber($this->saleamount->ViewValue, 2, -2, -2, -2);
		$this->saleamount->ViewCustomAttributes = "";

		// active
		$this->active->ViewValue = $this->active->CurrentValue;
		$this->active->ViewValue = FormatNumber($this->active->ViewValue, 0, -2, -2, -2);
		$this->active->ViewCustomAttributes = "";

		// field1label
		$this->field1label->ViewValue = $this->field1label->CurrentValue;
		$this->field1label->ViewCustomAttributes = "";

		// field2label
		$this->field2label->ViewValue = $this->field2label->CurrentValue;
		$this->field2label->ViewCustomAttributes = "";

		// field3label
		$this->field3label->ViewValue = $this->field3label->CurrentValue;
		$this->field3label->ViewCustomAttributes = "";

		// timebound
		$this->timebound->ViewValue = $this->timebound->CurrentValue;
		$this->timebound->ViewValue = FormatNumber($this->timebound->ViewValue, 0, -2, -2, -2);
		$this->timebound->ViewCustomAttributes = "";

		// starttime
		$this->starttime->ViewValue = $this->starttime->CurrentValue;
		$this->starttime->ViewValue = FormatDateTime($this->starttime->ViewValue, 4);
		$this->starttime->ViewCustomAttributes = "";

		// endtime
		$this->endtime->ViewValue = $this->endtime->CurrentValue;
		$this->endtime->ViewValue = FormatDateTime($this->endtime->ViewValue, 4);
		$this->endtime->ViewCustomAttributes = "";

		// restrictionid
		$this->restrictionid->ViewValue = $this->restrictionid->CurrentValue;
		$this->restrictionid->ViewCustomAttributes = "";

		// verifyip
		$this->verifyip->ViewValue = $this->verifyip->CurrentValue;
		$this->verifyip->ViewValue = FormatNumber($this->verifyip->ViewValue, 0, -2, -2, -2);
		$this->verifyip->ViewCustomAttributes = "";

		// label1
		$this->label1->ViewValue = $this->label1->CurrentValue;
		$this->label1->ViewCustomAttributes = "";

		// label2
		$this->label2->ViewValue = $this->label2->CurrentValue;
		$this->label2->ViewCustomAttributes = "";

		// label3
		$this->label3->ViewValue = $this->label3->CurrentValue;
		$this->label3->ViewCustomAttributes = "";

		// location
		$this->location->ViewValue = $this->location->CurrentValue;
		$this->location->ViewCustomAttributes = "";

		// supportedamounts
		$this->supportedamounts->ViewValue = $this->supportedamounts->CurrentValue;
		$this->supportedamounts->ViewCustomAttributes = "";

		// productsandservices
		$this->productsandservices->ViewValue = $this->productsandservices->CurrentValue;
		$this->productsandservices->ViewCustomAttributes = "";

		// requiredfields
		$this->requiredfields->ViewValue = $this->requiredfields->CurrentValue;
		$this->requiredfields->ViewCustomAttributes = "";

		// notificationemails
		$this->notificationemails->ViewValue = $this->notificationemails->CurrentValue;
		$this->notificationemails->ViewCustomAttributes = "";

		// txid
		$this->txid->ViewValue = $this->txid->CurrentValue;
		$this->txid->ViewCustomAttributes = "";

		// posid
		$this->posid->ViewValue = $this->posid->CurrentValue;
		$this->posid->ViewValue = FormatNumber($this->posid->ViewValue, 0, -2, -2, -2);
		$this->posid->ViewCustomAttributes = "";

		// purchasedate
		$this->purchasedate->ViewValue = $this->purchasedate->CurrentValue;
		$this->purchasedate->ViewValue = FormatDateTime($this->purchasedate->ViewValue, 0);
		$this->purchasedate->ViewCustomAttributes = "";

		// commissiondate
		$this->commissiondate->ViewValue = $this->commissiondate->CurrentValue;
		$this->commissiondate->ViewValue = FormatDateTime($this->commissiondate->ViewValue, 0);
		$this->commissiondate->ViewCustomAttributes = "";

		// serialno
		$this->serialno->ViewValue = $this->serialno->CurrentValue;
		$this->serialno->ViewCustomAttributes = "";

		// endoflifedate
		$this->endoflifedate->ViewValue = $this->endoflifedate->CurrentValue;
		$this->endoflifedate->ViewValue = FormatDateTime($this->endoflifedate->ViewValue, 0);
		$this->endoflifedate->ViewCustomAttributes = "";

		// shipdate
		$this->shipdate->ViewValue = $this->shipdate->CurrentValue;
		$this->shipdate->ViewValue = FormatDateTime($this->shipdate->ViewValue, 0);
		$this->shipdate->ViewCustomAttributes = "";

		// make
		$this->make->ViewValue = $this->make->CurrentValue;
		$this->make->ViewCustomAttributes = "";

		// model
		$this->model->ViewValue = $this->model->CurrentValue;
		$this->model->ViewCustomAttributes = "";

		// returneddate
		$this->returneddate->ViewValue = $this->returneddate->CurrentValue;
		$this->returneddate->ViewValue = FormatDateTime($this->returneddate->ViewValue, 0);
		$this->returneddate->ViewCustomAttributes = "";

		// friendlyname
		$this->friendlyname->ViewValue = $this->friendlyname->CurrentValue;
		$this->friendlyname->ViewCustomAttributes = "";

		// notificationsms
		$this->notificationsms->ViewValue = $this->notificationsms->CurrentValue;
		$this->notificationsms->ViewCustomAttributes = "";

		// bridgeid
		$this->bridgeid->LinkCustomAttributes = "";
		$this->bridgeid->HrefValue = "";
		$this->bridgeid->TooltipValue = "";

		// itemid
		$this->itemid->LinkCustomAttributes = "";
		$this->itemid->HrefValue = "";
		$this->itemid->TooltipValue = "";

		// merchantid
		$this->merchantid->LinkCustomAttributes = "";
		$this->merchantid->HrefValue = "";
		$this->merchantid->TooltipValue = "";

		// externalcode
		$this->externalcode->LinkCustomAttributes = "";
		$this->externalcode->HrefValue = "";
		$this->externalcode->TooltipValue = "";

		// descshort
		$this->descshort->LinkCustomAttributes = "";
		$this->descshort->HrefValue = "";
		$this->descshort->TooltipValue = "";

		// desclong
		$this->desclong->LinkCustomAttributes = "";
		$this->desclong->HrefValue = "";
		$this->desclong->TooltipValue = "";

		// fixedamount
		$this->fixedamount->LinkCustomAttributes = "";
		$this->fixedamount->HrefValue = "";
		$this->fixedamount->TooltipValue = "";

		// startamount
		$this->startamount->LinkCustomAttributes = "";
		$this->startamount->HrefValue = "";
		$this->startamount->TooltipValue = "";

		// endamount
		$this->endamount->LinkCustomAttributes = "";
		$this->endamount->HrefValue = "";
		$this->endamount->TooltipValue = "";

		// onsale
		$this->onsale->LinkCustomAttributes = "";
		$this->onsale->HrefValue = "";
		$this->onsale->TooltipValue = "";

		// currcode
		$this->currcode->LinkCustomAttributes = "";
		$this->currcode->HrefValue = "";
		$this->currcode->TooltipValue = "";

		// saleamount
		$this->saleamount->LinkCustomAttributes = "";
		$this->saleamount->HrefValue = "";
		$this->saleamount->TooltipValue = "";

		// active
		$this->active->LinkCustomAttributes = "";
		$this->active->HrefValue = "";
		$this->active->TooltipValue = "";

		// field1label
		$this->field1label->LinkCustomAttributes = "";
		$this->field1label->HrefValue = "";
		$this->field1label->TooltipValue = "";

		// field2label
		$this->field2label->LinkCustomAttributes = "";
		$this->field2label->HrefValue = "";
		$this->field2label->TooltipValue = "";

		// field3label
		$this->field3label->LinkCustomAttributes = "";
		$this->field3label->HrefValue = "";
		$this->field3label->TooltipValue = "";

		// timebound
		$this->timebound->LinkCustomAttributes = "";
		$this->timebound->HrefValue = "";
		$this->timebound->TooltipValue = "";

		// starttime
		$this->starttime->LinkCustomAttributes = "";
		$this->starttime->HrefValue = "";
		$this->starttime->TooltipValue = "";

		// endtime
		$this->endtime->LinkCustomAttributes = "";
		$this->endtime->HrefValue = "";
		$this->endtime->TooltipValue = "";

		// restrictionid
		$this->restrictionid->LinkCustomAttributes = "";
		$this->restrictionid->HrefValue = "";
		$this->restrictionid->TooltipValue = "";

		// verifyip
		$this->verifyip->LinkCustomAttributes = "";
		$this->verifyip->HrefValue = "";
		$this->verifyip->TooltipValue = "";

		// label1
		$this->label1->LinkCustomAttributes = "";
		$this->label1->HrefValue = "";
		$this->label1->TooltipValue = "";

		// label2
		$this->label2->LinkCustomAttributes = "";
		$this->label2->HrefValue = "";
		$this->label2->TooltipValue = "";

		// label3
		$this->label3->LinkCustomAttributes = "";
		$this->label3->HrefValue = "";
		$this->label3->TooltipValue = "";

		// location
		$this->location->LinkCustomAttributes = "";
		$this->location->HrefValue = "";
		$this->location->TooltipValue = "";

		// supportedamounts
		$this->supportedamounts->LinkCustomAttributes = "";
		$this->supportedamounts->HrefValue = "";
		$this->supportedamounts->TooltipValue = "";

		// productsandservices
		$this->productsandservices->LinkCustomAttributes = "";
		$this->productsandservices->HrefValue = "";
		$this->productsandservices->TooltipValue = "";

		// requiredfields
		$this->requiredfields->LinkCustomAttributes = "";
		$this->requiredfields->HrefValue = "";
		$this->requiredfields->TooltipValue = "";

		// notificationemails
		$this->notificationemails->LinkCustomAttributes = "";
		$this->notificationemails->HrefValue = "";
		$this->notificationemails->TooltipValue = "";

		// txid
		$this->txid->LinkCustomAttributes = "";
		$this->txid->HrefValue = "";
		$this->txid->TooltipValue = "";

		// posid
		$this->posid->LinkCustomAttributes = "";
		$this->posid->HrefValue = "";
		$this->posid->TooltipValue = "";

		// purchasedate
		$this->purchasedate->LinkCustomAttributes = "";
		$this->purchasedate->HrefValue = "";
		$this->purchasedate->TooltipValue = "";

		// commissiondate
		$this->commissiondate->LinkCustomAttributes = "";
		$this->commissiondate->HrefValue = "";
		$this->commissiondate->TooltipValue = "";

		// serialno
		$this->serialno->LinkCustomAttributes = "";
		$this->serialno->HrefValue = "";
		$this->serialno->TooltipValue = "";

		// endoflifedate
		$this->endoflifedate->LinkCustomAttributes = "";
		$this->endoflifedate->HrefValue = "";
		$this->endoflifedate->TooltipValue = "";

		// shipdate
		$this->shipdate->LinkCustomAttributes = "";
		$this->shipdate->HrefValue = "";
		$this->shipdate->TooltipValue = "";

		// make
		$this->make->LinkCustomAttributes = "";
		$this->make->HrefValue = "";
		$this->make->TooltipValue = "";

		// model
		$this->model->LinkCustomAttributes = "";
		$this->model->HrefValue = "";
		$this->model->TooltipValue = "";

		// returneddate
		$this->returneddate->LinkCustomAttributes = "";
		$this->returneddate->HrefValue = "";
		$this->returneddate->TooltipValue = "";

		// friendlyname
		$this->friendlyname->LinkCustomAttributes = "";
		$this->friendlyname->HrefValue = "";
		$this->friendlyname->TooltipValue = "";

		// notificationsms
		$this->notificationsms->LinkCustomAttributes = "";
		$this->notificationsms->HrefValue = "";
		$this->notificationsms->TooltipValue = "";

		// Call Row Rendered event
		$this->Row_Rendered();

		// Save data for Custom Template
		$this->Rows[] = $this->customTemplateFieldValues();
	}

	// Render edit row values
	public function renderEditRow()
	{
		global $Security, $CurrentLanguage, $Language;

		// Call Row Rendering event
		$this->Row_Rendering();

		// bridgeid
		$this->bridgeid->EditAttrs["class"] = "form-control";
		$this->bridgeid->EditCustomAttributes = "";
		$this->bridgeid->EditValue = $this->bridgeid->CurrentValue;
		$this->bridgeid->EditValue = FormatNumber($this->bridgeid->EditValue, 0, -2, -2, -2);
		$this->bridgeid->ViewCustomAttributes = "";

		// itemid
		$this->itemid->EditAttrs["class"] = "form-control";
		$this->itemid->EditCustomAttributes = "";
		$this->itemid->EditValue = $this->itemid->CurrentValue;
		$this->itemid->ViewCustomAttributes = "";

		// merchantid
		$this->merchantid->EditAttrs["class"] = "form-control";
		$this->merchantid->EditCustomAttributes = "";
		$this->merchantid->EditValue = $this->merchantid->CurrentValue;
		$this->merchantid->PlaceHolder = RemoveHtml($this->merchantid->caption());

		// externalcode
		$this->externalcode->EditAttrs["class"] = "form-control";
		$this->externalcode->EditCustomAttributes = "";
		if (!$this->externalcode->Raw)
			$this->externalcode->CurrentValue = HtmlDecode($this->externalcode->CurrentValue);
		$this->externalcode->EditValue = $this->externalcode->CurrentValue;
		$this->externalcode->PlaceHolder = RemoveHtml($this->externalcode->caption());

		// descshort
		$this->descshort->EditAttrs["class"] = "form-control";
		$this->descshort->EditCustomAttributes = "";
		if (!$this->descshort->Raw)
			$this->descshort->CurrentValue = HtmlDecode($this->descshort->CurrentValue);
		$this->descshort->EditValue = $this->descshort->CurrentValue;
		$this->descshort->PlaceHolder = RemoveHtml($this->descshort->caption());

		// desclong
		$this->desclong->EditAttrs["class"] = "form-control";
		$this->desclong->EditCustomAttributes = "";
		$this->desclong->EditValue = $this->desclong->CurrentValue;
		$this->desclong->PlaceHolder = RemoveHtml($this->desclong->caption());

		// fixedamount
		$this->fixedamount->EditAttrs["class"] = "form-control";
		$this->fixedamount->EditCustomAttributes = "";
		$this->fixedamount->EditValue = $this->fixedamount->CurrentValue;
		$this->fixedamount->PlaceHolder = RemoveHtml($this->fixedamount->caption());

		// startamount
		$this->startamount->EditAttrs["class"] = "form-control";
		$this->startamount->EditCustomAttributes = "";
		$this->startamount->EditValue = $this->startamount->CurrentValue;
		$this->startamount->PlaceHolder = RemoveHtml($this->startamount->caption());
		if (strval($this->startamount->EditValue) != "" && is_numeric($this->startamount->EditValue))
			$this->startamount->EditValue = FormatNumber($this->startamount->EditValue, -2, -2, -2, -2);
		

		// endamount
		$this->endamount->EditAttrs["class"] = "form-control";
		$this->endamount->EditCustomAttributes = "";
		$this->endamount->EditValue = $this->endamount->CurrentValue;
		$this->endamount->PlaceHolder = RemoveHtml($this->endamount->caption());
		if (strval($this->endamount->EditValue) != "" && is_numeric($this->endamount->EditValue))
			$this->endamount->EditValue = FormatNumber($this->endamount->EditValue, -2, -2, -2, -2);
		

		// onsale
		$this->onsale->EditAttrs["class"] = "form-control";
		$this->onsale->EditCustomAttributes = "";
		$this->onsale->EditValue = $this->onsale->CurrentValue;
		$this->onsale->PlaceHolder = RemoveHtml($this->onsale->caption());

		// currcode
		$this->currcode->EditAttrs["class"] = "form-control";
		$this->currcode->EditCustomAttributes = "";
		if (!$this->currcode->Raw)
			$this->currcode->CurrentValue = HtmlDecode($this->currcode->CurrentValue);
		$this->currcode->EditValue = $this->currcode->CurrentValue;
		$this->currcode->PlaceHolder = RemoveHtml($this->currcode->caption());

		// saleamount
		$this->saleamount->EditAttrs["class"] = "form-control";
		$this->saleamount->EditCustomAttributes = "";
		$this->saleamount->EditValue = $this->saleamount->CurrentValue;
		$this->saleamount->PlaceHolder = RemoveHtml($this->saleamount->caption());
		if (strval($this->saleamount->EditValue) != "" && is_numeric($this->saleamount->EditValue))
			$this->saleamount->EditValue = FormatNumber($this->saleamount->EditValue, -2, -2, -2, -2);
		

		// active
		$this->active->EditAttrs["class"] = "form-control";
		$this->active->EditCustomAttributes = "";
		$this->active->EditValue = $this->active->CurrentValue;
		$this->active->PlaceHolder = RemoveHtml($this->active->caption());

		// field1label
		$this->field1label->EditAttrs["class"] = "form-control";
		$this->field1label->EditCustomAttributes = "";
		if (!$this->field1label->Raw)
			$this->field1label->CurrentValue = HtmlDecode($this->field1label->CurrentValue);
		$this->field1label->EditValue = $this->field1label->CurrentValue;
		$this->field1label->PlaceHolder = RemoveHtml($this->field1label->caption());

		// field2label
		$this->field2label->EditAttrs["class"] = "form-control";
		$this->field2label->EditCustomAttributes = "";
		if (!$this->field2label->Raw)
			$this->field2label->CurrentValue = HtmlDecode($this->field2label->CurrentValue);
		$this->field2label->EditValue = $this->field2label->CurrentValue;
		$this->field2label->PlaceHolder = RemoveHtml($this->field2label->caption());

		// field3label
		$this->field3label->EditAttrs["class"] = "form-control";
		$this->field3label->EditCustomAttributes = "";
		if (!$this->field3label->Raw)
			$this->field3label->CurrentValue = HtmlDecode($this->field3label->CurrentValue);
		$this->field3label->EditValue = $this->field3label->CurrentValue;
		$this->field3label->PlaceHolder = RemoveHtml($this->field3label->caption());

		// timebound
		$this->timebound->EditAttrs["class"] = "form-control";
		$this->timebound->EditCustomAttributes = "";
		$this->timebound->EditValue = $this->timebound->CurrentValue;
		$this->timebound->PlaceHolder = RemoveHtml($this->timebound->caption());

		// starttime
		$this->starttime->EditAttrs["class"] = "form-control";
		$this->starttime->EditCustomAttributes = "";
		$this->starttime->EditValue = $this->starttime->CurrentValue;
		$this->starttime->PlaceHolder = RemoveHtml($this->starttime->caption());

		// endtime
		$this->endtime->EditAttrs["class"] = "form-control";
		$this->endtime->EditCustomAttributes = "";
		$this->endtime->EditValue = $this->endtime->CurrentValue;
		$this->endtime->PlaceHolder = RemoveHtml($this->endtime->caption());

		// restrictionid
		$this->restrictionid->EditAttrs["class"] = "form-control";
		$this->restrictionid->EditCustomAttributes = "";
		if (!$this->restrictionid->Raw)
			$this->restrictionid->CurrentValue = HtmlDecode($this->restrictionid->CurrentValue);
		$this->restrictionid->EditValue = $this->restrictionid->CurrentValue;
		$this->restrictionid->PlaceHolder = RemoveHtml($this->restrictionid->caption());

		// verifyip
		$this->verifyip->EditAttrs["class"] = "form-control";
		$this->verifyip->EditCustomAttributes = "";
		$this->verifyip->EditValue = $this->verifyip->CurrentValue;
		$this->verifyip->PlaceHolder = RemoveHtml($this->verifyip->caption());

		// label1
		$this->label1->EditAttrs["class"] = "form-control";
		$this->label1->EditCustomAttributes = "";
		if (!$this->label1->Raw)
			$this->label1->CurrentValue = HtmlDecode($this->label1->CurrentValue);
		$this->label1->EditValue = $this->label1->CurrentValue;
		$this->label1->PlaceHolder = RemoveHtml($this->label1->caption());

		// label2
		$this->label2->EditAttrs["class"] = "form-control";
		$this->label2->EditCustomAttributes = "";
		if (!$this->label2->Raw)
			$this->label2->CurrentValue = HtmlDecode($this->label2->CurrentValue);
		$this->label2->EditValue = $this->label2->CurrentValue;
		$this->label2->PlaceHolder = RemoveHtml($this->label2->caption());

		// label3
		$this->label3->EditAttrs["class"] = "form-control";
		$this->label3->EditCustomAttributes = "";
		if (!$this->label3->Raw)
			$this->label3->CurrentValue = HtmlDecode($this->label3->CurrentValue);
		$this->label3->EditValue = $this->label3->CurrentValue;
		$this->label3->PlaceHolder = RemoveHtml($this->label3->caption());

		// location
		$this->location->EditAttrs["class"] = "form-control";
		$this->location->EditCustomAttributes = "";
		if (!$this->location->Raw)
			$this->location->CurrentValue = HtmlDecode($this->location->CurrentValue);
		$this->location->EditValue = $this->location->CurrentValue;
		$this->location->PlaceHolder = RemoveHtml($this->location->caption());

		// supportedamounts
		$this->supportedamounts->EditAttrs["class"] = "form-control";
		$this->supportedamounts->EditCustomAttributes = "";
		if (!$this->supportedamounts->Raw)
			$this->supportedamounts->CurrentValue = HtmlDecode($this->supportedamounts->CurrentValue);
		$this->supportedamounts->EditValue = $this->supportedamounts->CurrentValue;
		$this->supportedamounts->PlaceHolder = RemoveHtml($this->supportedamounts->caption());

		// productsandservices
		$this->productsandservices->EditAttrs["class"] = "form-control";
		$this->productsandservices->EditCustomAttributes = "";
		if (!$this->productsandservices->Raw)
			$this->productsandservices->CurrentValue = HtmlDecode($this->productsandservices->CurrentValue);
		$this->productsandservices->EditValue = $this->productsandservices->CurrentValue;
		$this->productsandservices->PlaceHolder = RemoveHtml($this->productsandservices->caption());

		// requiredfields
		$this->requiredfields->EditAttrs["class"] = "form-control";
		$this->requiredfields->EditCustomAttributes = "";
		if (!$this->requiredfields->Raw)
			$this->requiredfields->CurrentValue = HtmlDecode($this->requiredfields->CurrentValue);
		$this->requiredfields->EditValue = $this->requiredfields->CurrentValue;
		$this->requiredfields->PlaceHolder = RemoveHtml($this->requiredfields->caption());

		// notificationemails
		$this->notificationemails->EditAttrs["class"] = "form-control";
		$this->notificationemails->EditCustomAttributes = "";
		if (!$this->notificationemails->Raw)
			$this->notificationemails->CurrentValue = HtmlDecode($this->notificationemails->CurrentValue);
		$this->notificationemails->EditValue = $this->notificationemails->CurrentValue;
		$this->notificationemails->PlaceHolder = RemoveHtml($this->notificationemails->caption());

		// txid
		$this->txid->EditAttrs["class"] = "form-control";
		$this->txid->EditCustomAttributes = "";
		if (!$this->txid->Raw)
			$this->txid->CurrentValue = HtmlDecode($this->txid->CurrentValue);
		$this->txid->EditValue = $this->txid->CurrentValue;
		$this->txid->PlaceHolder = RemoveHtml($this->txid->caption());

		// posid
		$this->posid->EditAttrs["class"] = "form-control";
		$this->posid->EditCustomAttributes = "";
		$this->posid->EditValue = $this->posid->CurrentValue;
		$this->posid->PlaceHolder = RemoveHtml($this->posid->caption());

		// purchasedate
		$this->purchasedate->EditAttrs["class"] = "form-control";
		$this->purchasedate->EditCustomAttributes = "";
		$this->purchasedate->EditValue = FormatDateTime($this->purchasedate->CurrentValue, 8);
		$this->purchasedate->PlaceHolder = RemoveHtml($this->purchasedate->caption());

		// commissiondate
		$this->commissiondate->EditAttrs["class"] = "form-control";
		$this->commissiondate->EditCustomAttributes = "";
		$this->commissiondate->EditValue = FormatDateTime($this->commissiondate->CurrentValue, 8);
		$this->commissiondate->PlaceHolder = RemoveHtml($this->commissiondate->caption());

		// serialno
		$this->serialno->EditAttrs["class"] = "form-control";
		$this->serialno->EditCustomAttributes = "";
		if (!$this->serialno->Raw)
			$this->serialno->CurrentValue = HtmlDecode($this->serialno->CurrentValue);
		$this->serialno->EditValue = $this->serialno->CurrentValue;
		$this->serialno->PlaceHolder = RemoveHtml($this->serialno->caption());

		// endoflifedate
		$this->endoflifedate->EditAttrs["class"] = "form-control";
		$this->endoflifedate->EditCustomAttributes = "";
		$this->endoflifedate->EditValue = FormatDateTime($this->endoflifedate->CurrentValue, 8);
		$this->endoflifedate->PlaceHolder = RemoveHtml($this->endoflifedate->caption());

		// shipdate
		$this->shipdate->EditAttrs["class"] = "form-control";
		$this->shipdate->EditCustomAttributes = "";
		$this->shipdate->EditValue = FormatDateTime($this->shipdate->CurrentValue, 8);
		$this->shipdate->PlaceHolder = RemoveHtml($this->shipdate->caption());

		// make
		$this->make->EditAttrs["class"] = "form-control";
		$this->make->EditCustomAttributes = "";
		if (!$this->make->Raw)
			$this->make->CurrentValue = HtmlDecode($this->make->CurrentValue);
		$this->make->EditValue = $this->make->CurrentValue;
		$this->make->PlaceHolder = RemoveHtml($this->make->caption());

		// model
		$this->model->EditAttrs["class"] = "form-control";
		$this->model->EditCustomAttributes = "";
		if (!$this->model->Raw)
			$this->model->CurrentValue = HtmlDecode($this->model->CurrentValue);
		$this->model->EditValue = $this->model->CurrentValue;
		$this->model->PlaceHolder = RemoveHtml($this->model->caption());

		// returneddate
		$this->returneddate->EditAttrs["class"] = "form-control";
		$this->returneddate->EditCustomAttributes = "";
		$this->returneddate->EditValue = FormatDateTime($this->returneddate->CurrentValue, 8);
		$this->returneddate->PlaceHolder = RemoveHtml($this->returneddate->caption());

		// friendlyname
		$this->friendlyname->EditAttrs["class"] = "form-control";
		$this->friendlyname->EditCustomAttributes = "";
		if (!$this->friendlyname->Raw)
			$this->friendlyname->CurrentValue = HtmlDecode($this->friendlyname->CurrentValue);
		$this->friendlyname->EditValue = $this->friendlyname->CurrentValue;
		$this->friendlyname->PlaceHolder = RemoveHtml($this->friendlyname->caption());

		// notificationsms
		$this->notificationsms->EditAttrs["class"] = "form-control";
		$this->notificationsms->EditCustomAttributes = "";
		$this->notificationsms->EditValue = $this->notificationsms->CurrentValue;
		$this->notificationsms->PlaceHolder = RemoveHtml($this->notificationsms->caption());

		// Call Row Rendered event
		$this->Row_Rendered();
	}

	// Aggregate list row values
	public function aggregateListRowValues()
	{
	}

	// Aggregate list row (for rendering)
	public function aggregateListRow()
	{

		// Call Row Rendered event
		$this->Row_Rendered();
	}

	// Export data in HTML/CSV/Word/Excel/Email/PDF format
	public function exportDocument($doc, $recordset, $startRec = 1, $stopRec = 1, $exportPageType = "")
	{
		if (!$recordset || !$doc)
			return;
		if (!$doc->ExportCustom) {

			// Write header
			$doc->exportTableHeader();
			if ($doc->Horizontal) { // Horizontal format, write header
				$doc->beginExportRow();
				if ($exportPageType == "view") {
					$doc->exportCaption($this->bridgeid);
					$doc->exportCaption($this->itemid);
					$doc->exportCaption($this->merchantid);
					$doc->exportCaption($this->externalcode);
					$doc->exportCaption($this->descshort);
					$doc->exportCaption($this->desclong);
					$doc->exportCaption($this->fixedamount);
					$doc->exportCaption($this->startamount);
					$doc->exportCaption($this->endamount);
					$doc->exportCaption($this->onsale);
					$doc->exportCaption($this->currcode);
					$doc->exportCaption($this->saleamount);
					$doc->exportCaption($this->active);
					$doc->exportCaption($this->field1label);
					$doc->exportCaption($this->field2label);
					$doc->exportCaption($this->field3label);
					$doc->exportCaption($this->timebound);
					$doc->exportCaption($this->starttime);
					$doc->exportCaption($this->endtime);
					$doc->exportCaption($this->restrictionid);
					$doc->exportCaption($this->verifyip);
					$doc->exportCaption($this->label1);
					$doc->exportCaption($this->label2);
					$doc->exportCaption($this->label3);
					$doc->exportCaption($this->location);
					$doc->exportCaption($this->supportedamounts);
					$doc->exportCaption($this->productsandservices);
					$doc->exportCaption($this->requiredfields);
					$doc->exportCaption($this->notificationemails);
					$doc->exportCaption($this->txid);
					$doc->exportCaption($this->posid);
					$doc->exportCaption($this->purchasedate);
					$doc->exportCaption($this->commissiondate);
					$doc->exportCaption($this->serialno);
					$doc->exportCaption($this->endoflifedate);
					$doc->exportCaption($this->shipdate);
					$doc->exportCaption($this->make);
					$doc->exportCaption($this->model);
					$doc->exportCaption($this->returneddate);
					$doc->exportCaption($this->friendlyname);
					$doc->exportCaption($this->notificationsms);
				} else {
					$doc->exportCaption($this->bridgeid);
					$doc->exportCaption($this->itemid);
					$doc->exportCaption($this->merchantid);
					$doc->exportCaption($this->externalcode);
					$doc->exportCaption($this->descshort);
					$doc->exportCaption($this->fixedamount);
					$doc->exportCaption($this->startamount);
					$doc->exportCaption($this->endamount);
					$doc->exportCaption($this->onsale);
					$doc->exportCaption($this->currcode);
					$doc->exportCaption($this->saleamount);
					$doc->exportCaption($this->active);
					$doc->exportCaption($this->field1label);
					$doc->exportCaption($this->field2label);
					$doc->exportCaption($this->field3label);
					$doc->exportCaption($this->timebound);
					$doc->exportCaption($this->starttime);
					$doc->exportCaption($this->endtime);
					$doc->exportCaption($this->restrictionid);
					$doc->exportCaption($this->verifyip);
					$doc->exportCaption($this->label1);
					$doc->exportCaption($this->label2);
					$doc->exportCaption($this->label3);
					$doc->exportCaption($this->location);
					$doc->exportCaption($this->supportedamounts);
					$doc->exportCaption($this->productsandservices);
					$doc->exportCaption($this->requiredfields);
					$doc->exportCaption($this->notificationemails);
					$doc->exportCaption($this->txid);
					$doc->exportCaption($this->posid);
					$doc->exportCaption($this->purchasedate);
					$doc->exportCaption($this->commissiondate);
					$doc->exportCaption($this->serialno);
					$doc->exportCaption($this->endoflifedate);
					$doc->exportCaption($this->shipdate);
					$doc->exportCaption($this->make);
					$doc->exportCaption($this->model);
					$doc->exportCaption($this->returneddate);
					$doc->exportCaption($this->friendlyname);
				}
				$doc->endExportRow();
			}
		}

		// Move to first record
		$recCnt = $startRec - 1;
		if (!$recordset->EOF) {
			$recordset->moveFirst();
			if ($startRec > 1)
				$recordset->move($startRec - 1);
		}
		while (!$recordset->EOF && $recCnt < $stopRec) {
			$recCnt++;
			if ($recCnt >= $startRec) {
				$rowCnt = $recCnt - $startRec + 1;

				// Page break
				if ($this->ExportPageBreakCount > 0) {
					if ($rowCnt > 1 && ($rowCnt - 1) % $this->ExportPageBreakCount == 0)
						$doc->exportPageBreak();
				}
				$this->loadListRowValues($recordset);

				// Render row
				$this->RowType = ROWTYPE_VIEW; // Render view
				$this->resetAttributes();
				$this->renderListRow();
				if (!$doc->ExportCustom) {
					$doc->beginExportRow($rowCnt); // Allow CSS styles if enabled
					if ($exportPageType == "view") {
						$doc->exportField($this->bridgeid);
						$doc->exportField($this->itemid);
						$doc->exportField($this->merchantid);
						$doc->exportField($this->externalcode);
						$doc->exportField($this->descshort);
						$doc->exportField($this->desclong);
						$doc->exportField($this->fixedamount);
						$doc->exportField($this->startamount);
						$doc->exportField($this->endamount);
						$doc->exportField($this->onsale);
						$doc->exportField($this->currcode);
						$doc->exportField($this->saleamount);
						$doc->exportField($this->active);
						$doc->exportField($this->field1label);
						$doc->exportField($this->field2label);
						$doc->exportField($this->field3label);
						$doc->exportField($this->timebound);
						$doc->exportField($this->starttime);
						$doc->exportField($this->endtime);
						$doc->exportField($this->restrictionid);
						$doc->exportField($this->verifyip);
						$doc->exportField($this->label1);
						$doc->exportField($this->label2);
						$doc->exportField($this->label3);
						$doc->exportField($this->location);
						$doc->exportField($this->supportedamounts);
						$doc->exportField($this->productsandservices);
						$doc->exportField($this->requiredfields);
						$doc->exportField($this->notificationemails);
						$doc->exportField($this->txid);
						$doc->exportField($this->posid);
						$doc->exportField($this->purchasedate);
						$doc->exportField($this->commissiondate);
						$doc->exportField($this->serialno);
						$doc->exportField($this->endoflifedate);
						$doc->exportField($this->shipdate);
						$doc->exportField($this->make);
						$doc->exportField($this->model);
						$doc->exportField($this->returneddate);
						$doc->exportField($this->friendlyname);
						$doc->exportField($this->notificationsms);
					} else {
						$doc->exportField($this->bridgeid);
						$doc->exportField($this->itemid);
						$doc->exportField($this->merchantid);
						$doc->exportField($this->externalcode);
						$doc->exportField($this->descshort);
						$doc->exportField($this->fixedamount);
						$doc->exportField($this->startamount);
						$doc->exportField($this->endamount);
						$doc->exportField($this->onsale);
						$doc->exportField($this->currcode);
						$doc->exportField($this->saleamount);
						$doc->exportField($this->active);
						$doc->exportField($this->field1label);
						$doc->exportField($this->field2label);
						$doc->exportField($this->field3label);
						$doc->exportField($this->timebound);
						$doc->exportField($this->starttime);
						$doc->exportField($this->endtime);
						$doc->exportField($this->restrictionid);
						$doc->exportField($this->verifyip);
						$doc->exportField($this->label1);
						$doc->exportField($this->label2);
						$doc->exportField($this->label3);
						$doc->exportField($this->location);
						$doc->exportField($this->supportedamounts);
						$doc->exportField($this->productsandservices);
						$doc->exportField($this->requiredfields);
						$doc->exportField($this->notificationemails);
						$doc->exportField($this->txid);
						$doc->exportField($this->posid);
						$doc->exportField($this->purchasedate);
						$doc->exportField($this->commissiondate);
						$doc->exportField($this->serialno);
						$doc->exportField($this->endoflifedate);
						$doc->exportField($this->shipdate);
						$doc->exportField($this->make);
						$doc->exportField($this->model);
						$doc->exportField($this->returneddate);
						$doc->exportField($this->friendlyname);
					}
					$doc->endExportRow($rowCnt);
				}
			}

			// Call Row Export server event
			if ($doc->ExportCustom)
				$this->Row_Export($recordset->fields);
			$recordset->moveNext();
		}
		if (!$doc->ExportCustom) {
			$doc->exportTableFooter();
		}
	}

	// Get file data
	public function getFileData($fldparm, $key, $resize, $width = 0, $height = 0)
	{

		// No binary fields
		return FALSE;
	}

	// Table level events
	// Recordset Selecting event
	function Recordset_Selecting(&$filter) {

		// Enter your code here
	}

	// Recordset Selected event
	function Recordset_Selected(&$rs) {

		//echo "Recordset Selected";
	}

	// Recordset Search Validated event
	function Recordset_SearchValidated() {

		// Example:
		//$this->MyField1->AdvancedSearch->SearchValue = "your search criteria"; // Search value

	}

	// Recordset Searching event
	function Recordset_Searching(&$filter) {

		// Enter your code here
	}

	// Row_Selecting event
	function Row_Selecting(&$filter) {

		// Enter your code here
	}

	// Row Selected event
	function Row_Selected(&$rs) {

		//echo "Row Selected";
	}

	// Row Inserting event
	function Row_Inserting($rsold, &$rsnew) {

		// Enter your code here
		// To cancel, set return value to FALSE

		return TRUE;
	}

	// Row Inserted event
	function Row_Inserted($rsold, &$rsnew) {

		//echo "Row Inserted"
	}

	// Row Updating event
	function Row_Updating($rsold, &$rsnew) {

		// Enter your code here
		// To cancel, set return value to FALSE

		return TRUE;
	}

	// Row Updated event
	function Row_Updated($rsold, &$rsnew) {

		//echo "Row Updated";
	}

	// Row Update Conflict event
	function Row_UpdateConflict($rsold, &$rsnew) {

		// Enter your code here
		// To ignore conflict, set return value to FALSE

		return TRUE;
	}

	// Grid Inserting event
	function Grid_Inserting() {

		// Enter your code here
		// To reject grid insert, set return value to FALSE

		return TRUE;
	}

	// Grid Inserted event
	function Grid_Inserted($rsnew) {

		//echo "Grid Inserted";
	}

	// Grid Updating event
	function Grid_Updating($rsold) {

		// Enter your code here
		// To reject grid update, set return value to FALSE

		return TRUE;
	}

	// Grid Updated event
	function Grid_Updated($rsold, $rsnew) {

		//echo "Grid Updated";
	}

	// Row Deleting event
	function Row_Deleting(&$rs) {

		// Enter your code here
		// To cancel, set return value to False

		return TRUE;
	}

	// Row Deleted event
	function Row_Deleted(&$rs) {

		//echo "Row Deleted";
	}

	// Email Sending event
	function Email_Sending($email, &$args) {

		//var_dump($email); var_dump($args); exit();
		return TRUE;
	}

	// Lookup Selecting event
	function Lookup_Selecting($fld, &$filter) {

		//var_dump($fld->Name, $fld->Lookup, $filter); // Uncomment to view the filter
		// Enter your code here

	}

	// Row Rendering event
	function Row_Rendering() {

		// Enter your code here
	}

	// Row Rendered event
	function Row_Rendered() {

		// To view properties of field class, use:
		//var_dump($this-><FieldName>);

	}

	// User ID Filtering event
	function UserID_Filtering(&$filter) {

		// Enter your code here
	}
}
?>