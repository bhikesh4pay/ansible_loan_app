<?php
namespace PHPMaker2020\_4payadmin;

/**
 * Page class
 */
class loaninfohistory_list extends loaninfohistory
{

	// Page ID
	public $PageID = "list";

	// Project ID
	public $ProjectID = "{153C2D2E-60EE-4944-8753-3935EB38E8D6}";

	// Table name
	public $TableName = 'loaninfohistory';

	// Page object name
	public $PageObjName = "loaninfohistory_list";

	// Grid form hidden field names
	public $FormName = "floaninfohistorylist";
	public $FormActionName = "k_action";
	public $FormKeyName = "k_key";
	public $FormOldKeyName = "k_oldkey";
	public $FormBlankRowName = "k_blankrow";
	public $FormKeyCountName = "key_count";

	// Page URLs
	public $AddUrl;
	public $EditUrl;
	public $CopyUrl;
	public $DeleteUrl;
	public $ViewUrl;
	public $ListUrl;

	// Export URLs
	public $ExportPrintUrl;
	public $ExportHtmlUrl;
	public $ExportExcelUrl;
	public $ExportWordUrl;
	public $ExportXmlUrl;
	public $ExportCsvUrl;
	public $ExportPdfUrl;

	// Custom export
	public $ExportExcelCustom = FALSE;
	public $ExportWordCustom = FALSE;
	public $ExportPdfCustom = FALSE;
	public $ExportEmailCustom = FALSE;

	// Update URLs
	public $InlineAddUrl;
	public $InlineCopyUrl;
	public $InlineEditUrl;
	public $GridAddUrl;
	public $GridEditUrl;
	public $MultiDeleteUrl;
	public $MultiUpdateUrl;

	// Audit Trail
	public $AuditTrailOnAdd = TRUE;
	public $AuditTrailOnEdit = TRUE;
	public $AuditTrailOnDelete = TRUE;
	public $AuditTrailOnView = FALSE;
	public $AuditTrailOnViewData = FALSE;
	public $AuditTrailOnSearch = FALSE;

	// Page headings
	public $Heading = "";
	public $Subheading = "";
	public $PageHeader;
	public $PageFooter;

	// Token
	public $Token = "";
	public $TokenTimeout = 0;
	public $CheckToken;

	// Page heading
	public function pageHeading()
	{
		global $Language;
		if ($this->Heading != "")
			return $this->Heading;
		if (method_exists($this, "tableCaption"))
			return $this->tableCaption();
		return "";
	}

	// Page subheading
	public function pageSubheading()
	{
		global $Language;
		if ($this->Subheading != "")
			return $this->Subheading;
		if ($this->TableName)
			return $Language->phrase($this->PageID);
		return "";
	}

	// Page name
	public function pageName()
	{
		return CurrentPageName();
	}

	// Page URL
	public function pageUrl()
	{
		$url = CurrentPageName() . "?";
		if ($this->UseTokenInUrl)
			$url .= "t=" . $this->TableVar . "&"; // Add page token
		return $url;
	}

	// Messages
	private $_message = "";
	private $_failureMessage = "";
	private $_successMessage = "";
	private $_warningMessage = "";

	// Get message
	public function getMessage()
	{
		return isset($_SESSION[SESSION_MESSAGE]) ? $_SESSION[SESSION_MESSAGE] : $this->_message;
	}

	// Set message
	public function setMessage($v)
	{
		AddMessage($this->_message, $v);
		$_SESSION[SESSION_MESSAGE] = $this->_message;
	}

	// Get failure message
	public function getFailureMessage()
	{
		return isset($_SESSION[SESSION_FAILURE_MESSAGE]) ? $_SESSION[SESSION_FAILURE_MESSAGE] : $this->_failureMessage;
	}

	// Set failure message
	public function setFailureMessage($v)
	{
		AddMessage($this->_failureMessage, $v);
		$_SESSION[SESSION_FAILURE_MESSAGE] = $this->_failureMessage;
	}

	// Get success message
	public function getSuccessMessage()
	{
		return isset($_SESSION[SESSION_SUCCESS_MESSAGE]) ? $_SESSION[SESSION_SUCCESS_MESSAGE] : $this->_successMessage;
	}

	// Set success message
	public function setSuccessMessage($v)
	{
		AddMessage($this->_successMessage, $v);
		$_SESSION[SESSION_SUCCESS_MESSAGE] = $this->_successMessage;
	}

	// Get warning message
	public function getWarningMessage()
	{
		return isset($_SESSION[SESSION_WARNING_MESSAGE]) ? $_SESSION[SESSION_WARNING_MESSAGE] : $this->_warningMessage;
	}

	// Set warning message
	public function setWarningMessage($v)
	{
		AddMessage($this->_warningMessage, $v);
		$_SESSION[SESSION_WARNING_MESSAGE] = $this->_warningMessage;
	}

	// Clear message
	public function clearMessage()
	{
		$this->_message = "";
		$_SESSION[SESSION_MESSAGE] = "";
	}

	// Clear failure message
	public function clearFailureMessage()
	{
		$this->_failureMessage = "";
		$_SESSION[SESSION_FAILURE_MESSAGE] = "";
	}

	// Clear success message
	public function clearSuccessMessage()
	{
		$this->_successMessage = "";
		$_SESSION[SESSION_SUCCESS_MESSAGE] = "";
	}

	// Clear warning message
	public function clearWarningMessage()
	{
		$this->_warningMessage = "";
		$_SESSION[SESSION_WARNING_MESSAGE] = "";
	}

	// Clear messages
	public function clearMessages()
	{
		$this->clearMessage();
		$this->clearFailureMessage();
		$this->clearSuccessMessage();
		$this->clearWarningMessage();
	}

	// Show message
	public function showMessage()
	{
		$hidden = FALSE;
		$html = "";

		// Message
		$message = $this->getMessage();
		if (method_exists($this, "Message_Showing"))
			$this->Message_Showing($message, "");
		if ($message != "") { // Message in Session, display
			if (!$hidden)
				$message = '<button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button>' . $message;
			$html .= '<div class="alert alert-info alert-dismissible ew-info"><i class="icon fas fa-info"></i>' . $message . '</div>';
			$_SESSION[SESSION_MESSAGE] = ""; // Clear message in Session
		}

		// Warning message
		$warningMessage = $this->getWarningMessage();
		if (method_exists($this, "Message_Showing"))
			$this->Message_Showing($warningMessage, "warning");
		if ($warningMessage != "") { // Message in Session, display
			if (!$hidden)
				$warningMessage = '<button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button>' . $warningMessage;
			$html .= '<div class="alert alert-warning alert-dismissible ew-warning"><i class="icon fas fa-exclamation"></i>' . $warningMessage . '</div>';
			$_SESSION[SESSION_WARNING_MESSAGE] = ""; // Clear message in Session
		}

		// Success message
		$successMessage = $this->getSuccessMessage();
		if (method_exists($this, "Message_Showing"))
			$this->Message_Showing($successMessage, "success");
		if ($successMessage != "") { // Message in Session, display
			if (!$hidden)
				$successMessage = '<button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button>' . $successMessage;
			$html .= '<div class="alert alert-success alert-dismissible ew-success"><i class="icon fas fa-check"></i>' . $successMessage . '</div>';
			$_SESSION[SESSION_SUCCESS_MESSAGE] = ""; // Clear message in Session
		}

		// Failure message
		$errorMessage = $this->getFailureMessage();
		if (method_exists($this, "Message_Showing"))
			$this->Message_Showing($errorMessage, "failure");
		if ($errorMessage != "") { // Message in Session, display
			if (!$hidden)
				$errorMessage = '<button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button>' . $errorMessage;
			$html .= '<div class="alert alert-danger alert-dismissible ew-error"><i class="icon fas fa-ban"></i>' . $errorMessage . '</div>';
			$_SESSION[SESSION_FAILURE_MESSAGE] = ""; // Clear message in Session
		}
		echo '<div class="ew-message-dialog' . (($hidden) ? ' d-none' : "") . '">' . $html . '</div>';
	}

	// Get message as array
	public function getMessages()
	{
		$ar = [];

		// Message
		$message = $this->getMessage();

		//if (method_exists($this, "Message_Showing"))
		//	$this->Message_Showing($message, "");

		if ($message != "") { // Message in Session, display
			$ar["message"] = $message;
			$_SESSION[SESSION_MESSAGE] = ""; // Clear message in Session
		}

		// Warning message
		$warningMessage = $this->getWarningMessage();

		//if (method_exists($this, "Message_Showing"))
		//	$this->Message_Showing($warningMessage, "warning");

		if ($warningMessage != "") { // Message in Session, display
			$ar["warningMessage"] = $warningMessage;
			$_SESSION[SESSION_WARNING_MESSAGE] = ""; // Clear message in Session
		}

		// Success message
		$successMessage = $this->getSuccessMessage();

		//if (method_exists($this, "Message_Showing"))
		//	$this->Message_Showing($successMessage, "success");

		if ($successMessage != "") { // Message in Session, display
			$ar["successMessage"] = $successMessage;
			$_SESSION[SESSION_SUCCESS_MESSAGE] = ""; // Clear message in Session
		}

		// Failure message
		$failureMessage = $this->getFailureMessage();

		//if (method_exists($this, "Message_Showing"))
		//	$this->Message_Showing($failureMessage, "failure");

		if ($failureMessage != "") { // Message in Session, display
			$ar["failureMessage"] = $failureMessage;
			$_SESSION[SESSION_FAILURE_MESSAGE] = ""; // Clear message in Session
		}
		return $ar;
	}

	// Show Page Header
	public function showPageHeader()
	{
		$header = $this->PageHeader;
		$this->Page_DataRendering($header);
		if ($header != "") { // Header exists, display
			echo '<p id="ew-page-header">' . $header . '</p>';
		}
	}

	// Show Page Footer
	public function showPageFooter()
	{
		$footer = $this->PageFooter;
		$this->Page_DataRendered($footer);
		if ($footer != "") { // Footer exists, display
			echo '<p id="ew-page-footer">' . $footer . '</p>';
		}
	}

	// Validate page request
	protected function isPageRequest()
	{
		global $CurrentForm;
		if ($this->UseTokenInUrl) {
			if ($CurrentForm)
				return ($this->TableVar == $CurrentForm->getValue("t"));
			if (Get("t") !== NULL)
				return ($this->TableVar == Get("t"));
		}
		return TRUE;
	}

	// Valid Post
	protected function validPost()
	{
		if (!$this->CheckToken || !IsPost() || IsApi())
			return TRUE;
		if (Post(Config("TOKEN_NAME")) === NULL)
			return FALSE;
		$fn = Config("CHECK_TOKEN_FUNC");
		if (is_callable($fn))
			return $fn(Post(Config("TOKEN_NAME")), $this->TokenTimeout);
		return FALSE;
	}

	// Create Token
	public function createToken()
	{
		global $CurrentToken;
		$fn = Config("CREATE_TOKEN_FUNC"); // Always create token, required by API file/lookup request
		if ($this->Token == "" && is_callable($fn)) // Create token
			$this->Token = $fn();
		$CurrentToken = $this->Token; // Save to global variable
	}

	// Constructor
	public function __construct()
	{
		global $Language, $DashboardReport;
		global $UserTable;

		// Check token
		$this->CheckToken = Config("CHECK_TOKEN");

		// Initialize
		$GLOBALS["Page"] = &$this;
		$this->TokenTimeout = SessionTimeoutTime();

		// Language object
		if (!isset($Language))
			$Language = new Language();

		// Parent constuctor
		parent::__construct();

		// Table object (loaninfohistory)
		if (!isset($GLOBALS["loaninfohistory"]) || get_class($GLOBALS["loaninfohistory"]) == PROJECT_NAMESPACE . "loaninfohistory") {
			$GLOBALS["loaninfohistory"] = &$this;
			$GLOBALS["Table"] = &$GLOBALS["loaninfohistory"];
		}

		// Initialize URLs
		$this->ExportPrintUrl = $this->pageUrl() . "export=print";
		$this->ExportExcelUrl = $this->pageUrl() . "export=excel";
		$this->ExportWordUrl = $this->pageUrl() . "export=word";
		$this->ExportPdfUrl = $this->pageUrl() . "export=pdf";
		$this->ExportHtmlUrl = $this->pageUrl() . "export=html";
		$this->ExportXmlUrl = $this->pageUrl() . "export=xml";
		$this->ExportCsvUrl = $this->pageUrl() . "export=csv";
		$this->AddUrl = "loaninfohistoryadd.php";
		$this->InlineAddUrl = $this->pageUrl() . "action=add";
		$this->GridAddUrl = $this->pageUrl() . "action=gridadd";
		$this->GridEditUrl = $this->pageUrl() . "action=gridedit";
		$this->MultiDeleteUrl = "loaninfohistorydelete.php";
		$this->MultiUpdateUrl = "loaninfohistoryupdate.php";

		// Table object (admin)
		if (!isset($GLOBALS['admin']))
			$GLOBALS['admin'] = new admin();

		// Page ID (for backward compatibility only)
		if (!defined(PROJECT_NAMESPACE . "PAGE_ID"))
			define(PROJECT_NAMESPACE . "PAGE_ID", 'list');

		// Table name (for backward compatibility only)
		if (!defined(PROJECT_NAMESPACE . "TABLE_NAME"))
			define(PROJECT_NAMESPACE . "TABLE_NAME", 'loaninfohistory');

		// Start timer
		if (!isset($GLOBALS["DebugTimer"]))
			$GLOBALS["DebugTimer"] = new Timer();

		// Debug message
		LoadDebugMessage();

		// Open connection
		if (!isset($GLOBALS["Conn"]))
			$GLOBALS["Conn"] = $this->getConnection();

		// User table object (admin)
		$UserTable = $UserTable ?: new admin();

		// List options
		$this->ListOptions = new ListOptions();
		$this->ListOptions->TableVar = $this->TableVar;

		// Export options
		$this->ExportOptions = new ListOptions("div");
		$this->ExportOptions->TagClassName = "ew-export-option";

		// Import options
		$this->ImportOptions = new ListOptions("div");
		$this->ImportOptions->TagClassName = "ew-import-option";

		// Other options
		if (!$this->OtherOptions)
			$this->OtherOptions = new ListOptionsArray();
		$this->OtherOptions["addedit"] = new ListOptions("div");
		$this->OtherOptions["addedit"]->TagClassName = "ew-add-edit-option";
		$this->OtherOptions["detail"] = new ListOptions("div");
		$this->OtherOptions["detail"]->TagClassName = "ew-detail-option";
		$this->OtherOptions["action"] = new ListOptions("div");
		$this->OtherOptions["action"]->TagClassName = "ew-action-option";

		// Filter options
		$this->FilterOptions = new ListOptions("div");
		$this->FilterOptions->TagClassName = "ew-filter-option floaninfohistorylistsrch";

		// List actions
		$this->ListActions = new ListActions();
	}

	// Terminate page
	public function terminate($url = "")
	{
		global $ExportFileName, $TempImages, $DashboardReport;

		// Page Unload event
		$this->Page_Unload();

		// Global Page Unloaded event (in userfn*.php)
		Page_Unloaded();

		// Export
		global $loaninfohistory;
		if ($this->CustomExport && $this->CustomExport == $this->Export && array_key_exists($this->CustomExport, Config("EXPORT_CLASSES"))) {
				$content = ob_get_contents();
			if ($ExportFileName == "")
				$ExportFileName = $this->TableVar;
			$class = PROJECT_NAMESPACE . Config("EXPORT_CLASSES." . $this->CustomExport);
			if (class_exists($class)) {
				$doc = new $class($loaninfohistory);
				$doc->Text = @$content;
				if ($this->isExport("email"))
					echo $this->exportEmail($doc->Text);
				else
					$doc->export();
				DeleteTempImages(); // Delete temp images
				exit();
			}
		}
		if (!IsApi())
			$this->Page_Redirecting($url);

		// Close connection
		CloseConnections();

		// Return for API
		if (IsApi()) {
			$res = $url === TRUE;
			if (!$res) // Show error
				WriteJson(array_merge(["success" => FALSE], $this->getMessages()));
			return;
		}

		// Go to URL if specified
		if ($url != "") {
			if (!Config("DEBUG") && ob_get_length())
				ob_end_clean();
			SaveDebugMessage();
			AddHeader("Location", $url);
		}
		exit();
	}

	// Get records from recordset
	protected function getRecordsFromRecordset($rs, $current = FALSE)
	{
		$rows = [];
		if (is_object($rs)) { // Recordset
			while ($rs && !$rs->EOF) {
				$this->loadRowValues($rs); // Set up DbValue/CurrentValue
				$row = $this->getRecordFromArray($rs->fields);
				if ($current)
					return $row;
				else
					$rows[] = $row;
				$rs->moveNext();
			}
		} elseif (is_array($rs)) {
			foreach ($rs as $ar) {
				$row = $this->getRecordFromArray($ar);
				if ($current)
					return $row;
				else
					$rows[] = $row;
			}
		}
		return $rows;
	}

	// Get record from array
	protected function getRecordFromArray($ar)
	{
		$row = [];
		if (is_array($ar)) {
			foreach ($ar as $fldname => $val) {
				if (array_key_exists($fldname, $this->fields) && ($this->fields[$fldname]->Visible || $this->fields[$fldname]->IsPrimaryKey)) { // Primary key or Visible
					$fld = &$this->fields[$fldname];
					if ($fld->HtmlTag == "FILE") { // Upload field
						if (EmptyValue($val)) {
							$row[$fldname] = NULL;
						} else {
							if ($fld->DataType == DATATYPE_BLOB) {
								$url = FullUrl(GetApiUrl(Config("API_FILE_ACTION"),
									Config("API_OBJECT_NAME") . "=" . $fld->TableVar . "&" .
									Config("API_FIELD_NAME") . "=" . $fld->Param . "&" .
									Config("API_KEY_NAME") . "=" . rawurlencode($this->getRecordKeyValue($ar)))); //*** need to add this? API may not be in the same folder
								$row[$fldname] = ["type" => ContentType($val), "url" => $url, "name" => $fld->Param . ContentExtension($val)];
							} elseif (!$fld->UploadMultiple || !ContainsString($val, Config("MULTIPLE_UPLOAD_SEPARATOR"))) { // Single file
								$url = FullUrl(GetApiUrl(Config("API_FILE_ACTION"),
									Config("API_OBJECT_NAME") . "=" . $fld->TableVar . "&" .
									"fn=" . Encrypt($fld->physicalUploadPath() . $val)));
								$row[$fldname] = ["type" => MimeContentType($val), "url" => $url, "name" => $val];
							} else { // Multiple files
								$files = explode(Config("MULTIPLE_UPLOAD_SEPARATOR"), $val);
								$ar = [];
								foreach ($files as $file) {
									$url = FullUrl(GetApiUrl(Config("API_FILE_ACTION"),
										Config("API_OBJECT_NAME") . "=" . $fld->TableVar . "&" .
										"fn=" . Encrypt($fld->physicalUploadPath() . $file)));
									if (!EmptyValue($file))
										$ar[] = ["type" => MimeContentType($file), "url" => $url, "name" => $file];
								}
								$row[$fldname] = $ar;
							}
						}
					} else {
						if ($fld->DataType == DATATYPE_MEMO && $fld->MemoMaxLength > 0)
							$val = TruncateMemo($val, $fld->MemoMaxLength, $fld->TruncateMemoRemoveHtml);
						$row[$fldname] = $val;
					}
				}
			}
		}
		return $row;
	}

	// Get record key value from array
	protected function getRecordKeyValue($ar)
	{
		$key = "";
		if (is_array($ar)) {
			$key .= @$ar['infoid'];
		}
		return $key;
	}

	/**
	 * Hide fields for add/edit
	 *
	 * @return void
	 */
	protected function hideFieldsForAddEdit()
	{
		if ($this->isAdd() || $this->isCopy() || $this->isGridAdd())
			$this->infoid->Visible = FALSE;
	}

	// Lookup data
	public function lookup()
	{
		global $Language, $Security;
		if (!isset($Language))
			$Language = new Language(Config("LANGUAGE_FOLDER"), Post("language", ""));

		// Set up API request
		if (!ValidApiRequest())
			return FALSE;
		$this->setupApiSecurity();

		// Get lookup object
		$fieldName = Post("field");
		if (!array_key_exists($fieldName, $this->fields))
			return FALSE;
		$lookupField = $this->fields[$fieldName];
		$lookup = $lookupField->Lookup;
		if ($lookup === NULL)
			return FALSE;
		$tbl = $lookup->getTable();
		if (!$Security->allowLookup(Config("PROJECT_ID") . $tbl->TableName)) // Lookup permission
			return FALSE;

		// Get lookup parameters
		$lookupType = Post("ajax", "unknown");
		$pageSize = -1;
		$offset = -1;
		$searchValue = "";
		if (SameText($lookupType, "modal")) {
			$searchValue = Post("sv", "");
			$pageSize = Post("recperpage", 10);
			$offset = Post("start", 0);
		} elseif (SameText($lookupType, "autosuggest")) {
			$searchValue = Param("q", "");
			$pageSize = Param("n", -1);
			$pageSize = is_numeric($pageSize) ? (int)$pageSize : -1;
			if ($pageSize <= 0)
				$pageSize = Config("AUTO_SUGGEST_MAX_ENTRIES");
			$start = Param("start", -1);
			$start = is_numeric($start) ? (int)$start : -1;
			$page = Param("page", -1);
			$page = is_numeric($page) ? (int)$page : -1;
			$offset = $start >= 0 ? $start : ($page > 0 && $pageSize > 0 ? ($page - 1) * $pageSize : 0);
		}
		$userSelect = Decrypt(Post("s", ""));
		$userFilter = Decrypt(Post("f", ""));
		$userOrderBy = Decrypt(Post("o", ""));
		$keys = Post("keys");
		$lookup->LookupType = $lookupType; // Lookup type
		if ($keys !== NULL) { // Selected records from modal
			if (is_array($keys))
				$keys = implode(Config("MULTIPLE_OPTION_SEPARATOR"), $keys);
			$lookup->FilterFields = []; // Skip parent fields if any
			$lookup->FilterValues[] = $keys; // Lookup values
			$pageSize = -1; // Show all records
		} else { // Lookup values
			$lookup->FilterValues[] = Post("v0", Post("lookupValue", ""));
		}
		$cnt = is_array($lookup->FilterFields) ? count($lookup->FilterFields) : 0;
		for ($i = 1; $i <= $cnt; $i++)
			$lookup->FilterValues[] = Post("v" . $i, "");
		$lookup->SearchValue = $searchValue;
		$lookup->PageSize = $pageSize;
		$lookup->Offset = $offset;
		if ($userSelect != "")
			$lookup->UserSelect = $userSelect;
		if ($userFilter != "")
			$lookup->UserFilter = $userFilter;
		if ($userOrderBy != "")
			$lookup->UserOrderBy = $userOrderBy;
		$lookup->toJson($this); // Use settings from current page
	}

	// Set up API security
	public function setupApiSecurity()
	{
		global $Security;

		// Setup security for API request
		if ($Security->isLoggedIn()) $Security->TablePermission_Loading();
		$Security->loadCurrentUserLevel(Config("PROJECT_ID") . $this->TableName);
		if ($Security->isLoggedIn()) $Security->TablePermission_Loaded();
	}

	// Class variables
	public $ListOptions; // List options
	public $ExportOptions; // Export options
	public $SearchOptions; // Search options
	public $OtherOptions; // Other options
	public $FilterOptions; // Filter options
	public $ImportOptions; // Import options
	public $ListActions; // List actions
	public $SelectedCount = 0;
	public $SelectedIndex = 0;
	public $DisplayRecords = 10;
	public $StartRecord;
	public $StopRecord;
	public $TotalRecords = 0;
	public $RecordRange = 10;
	public $PageSizes = ""; // Page sizes (comma separated)
	public $DefaultSearchWhere = ""; // Default search WHERE clause
	public $SearchWhere = ""; // Search WHERE clause
	public $SearchPanelClass = "ew-search-panel collapse"; // Search Panel class
	public $SearchRowCount = 0; // For extended search
	public $SearchColumnCount = 0; // For extended search
	public $SearchFieldsPerRow = 1; // For extended search
	public $RecordCount = 0; // Record count
	public $EditRowCount;
	public $StartRowCount = 1;
	public $RowCount = 0;
	public $Attrs = []; // Row attributes and cell attributes
	public $RowIndex = 0; // Row index
	public $KeyCount = 0; // Key count
	public $RowAction = ""; // Row action
	public $RowOldKey = ""; // Row old key (for copy)
	public $MultiColumnClass = "col-sm";
	public $MultiColumnEditClass = "w-100";
	public $DbMasterFilter = ""; // Master filter
	public $DbDetailFilter = ""; // Detail filter
	public $MasterRecordExists;
	public $MultiSelectKey;
	public $Command;
	public $RestoreSearch = FALSE;
	public $DetailPages;
	public $OldRecordset;

	//
	// Page run
	//

	public function run()
	{
		global $ExportType, $CustomExportType, $ExportFileName, $UserProfile, $Language, $Security, $CurrentForm,
			$FormError, $SearchError;

		// User profile
		$UserProfile = new UserProfile();

		// Security
		if (ValidApiRequest()) { // API request
			$this->setupApiSecurity(); // Set up API Security
			if (!$Security->canList()) {
				SetStatus(401); // Unauthorized
				return;
			}
		} else {
			$Security = new AdvancedSecurity();
			if (IsPasswordExpired())
				$this->terminate(GetUrl("changepwd.php"));
			if (!$Security->isLoggedIn())
				$Security->autoLogin();
			if ($Security->isLoggedIn())
				$Security->TablePermission_Loading();
			$Security->loadCurrentUserLevel($this->ProjectID . $this->TableName);
			if ($Security->isLoggedIn())
				$Security->TablePermission_Loaded();
			if (!$Security->canList()) {
				$Security->saveLastUrl();
				$this->setFailureMessage(DeniedMessage()); // Set no permission
				$this->terminate(GetUrl("index.php"));
				return;
			}
		}

		// Get export parameters
		$custom = "";
		if (Param("export") !== NULL) {
			$this->Export = Param("export");
			$custom = Param("custom", "");
		} elseif (IsPost()) {
			if (Post("exporttype") !== NULL)
				$this->Export = Post("exporttype");
			$custom = Post("custom", "");
		} elseif (Get("cmd") == "json") {
			$this->Export = Get("cmd");
		} else {
			$this->setExportReturnUrl(CurrentUrl());
		}
		$ExportFileName = $this->TableVar; // Get export file, used in header

		// Get custom export parameters
		if ($this->isExport() && $custom != "") {
			$this->CustomExport = $this->Export;
			$this->Export = "print";
		}
		$CustomExportType = $this->CustomExport;
		$ExportType = $this->Export; // Get export parameter, used in header

		// Update Export URLs
		if (Config("USE_PHPEXCEL"))
			$this->ExportExcelCustom = FALSE;
		if ($this->ExportExcelCustom)
			$this->ExportExcelUrl .= "&amp;custom=1";
		if (Config("USE_PHPWORD"))
			$this->ExportWordCustom = FALSE;
		if ($this->ExportWordCustom)
			$this->ExportWordUrl .= "&amp;custom=1";
		if ($this->ExportPdfCustom)
			$this->ExportPdfUrl .= "&amp;custom=1";
		$this->CurrentAction = Param("action"); // Set up current action

		// Get grid add count
		$gridaddcnt = Get(Config("TABLE_GRID_ADD_ROW_COUNT"), "");
		if (is_numeric($gridaddcnt) && $gridaddcnt > 0)
			$this->GridAddRowCount = $gridaddcnt;

		// Set up list options
		$this->setupListOptions();

		// Setup export options
		$this->setupExportOptions();
		$this->infoid->setVisibility();
		$this->_userid->setVisibility();
		$this->externalrefid->setVisibility();
		$this->currcode->setVisibility();
		$this->sampleloantype->setVisibility();
		$this->sampleamount->setVisibility();
		$this->sampleamountforfeecalculation->setVisibility();
		$this->eligibleamount->setVisibility();
		$this->outstandingloanprinciple->setVisibility();
		$this->outstandingloanfees->setVisibility();
		$this->availableforloan->setVisibility();
		$this->status->setVisibility();
		$this->optin->setVisibility();
		$this->sampleloanfeespretax->setVisibility();
		$this->feetaxpercentage->setVisibility();
		$this->feetaxamount->setVisibility();
		$this->sampleloanfeesposttax->setVisibility();
		$this->feesystemtotal->setVisibility();
		$this->feeexternaltotal->setVisibility();
		$this->feefranchiseetotal->setVisibility();
		$this->feeresellertotal->setVisibility();
		$this->outstandingloan->setVisibility();
		$this->outstandingloanlatefees->setVisibility();
		$this->intent->setVisibility();
		$this->msg->setVisibility();
		$this->infotime->setVisibility();
		$this->hideFieldsForAddEdit();

		// Global Page Loading event (in userfn*.php)
		Page_Loading();

		// Page Load event
		$this->Page_Load();

		// Check token
		if (!$this->validPost()) {
			Write($Language->phrase("InvalidPostRequest"));
			$this->terminate();
		}

		// Create Token
		$this->createToken();

		// Setup other options
		$this->setupOtherOptions();

		// Set up custom action (compatible with old version)
		foreach ($this->CustomActions as $name => $action)
			$this->ListActions->add($name, $action);

		// Show checkbox column if multiple action
		foreach ($this->ListActions->Items as $listaction) {
			if ($listaction->Select == ACTION_MULTIPLE && $listaction->Allow) {
				$this->ListOptions["checkbox"]->Visible = TRUE;
				break;
			}
		}

		// Set up lookup cache
		// Search filters

		$srchAdvanced = ""; // Advanced search filter
		$srchBasic = ""; // Basic search filter
		$filter = "";

		// Get command
		$this->Command = strtolower(Get("cmd"));
		if ($this->isPageRequest()) { // Validate request

			// Process list action first
			if ($this->processListAction()) // Ajax request
				$this->terminate();

			// Set up records per page
			$this->setupDisplayRecords();

			// Handle reset command
			$this->resetCmd();

			// Set up Breadcrumb
			if (!$this->isExport())
				$this->setupBreadcrumb();

			// Hide list options
			if ($this->isExport()) {
				$this->ListOptions->hideAllOptions(["sequence"]);
				$this->ListOptions->UseDropDownButton = FALSE; // Disable drop down button
				$this->ListOptions->UseButtonGroup = FALSE; // Disable button group
			} elseif ($this->isGridAdd() || $this->isGridEdit()) {
				$this->ListOptions->hideAllOptions();
				$this->ListOptions->UseDropDownButton = FALSE; // Disable drop down button
				$this->ListOptions->UseButtonGroup = FALSE; // Disable button group
			}

			// Hide options
			if ($this->isExport() || $this->CurrentAction) {
				$this->ExportOptions->hideAllOptions();
				$this->FilterOptions->hideAllOptions();
				$this->ImportOptions->hideAllOptions();
			}

			// Hide other options
			if ($this->isExport())
				$this->OtherOptions->hideAllOptions();

			// Get default search criteria
			AddFilter($this->DefaultSearchWhere, $this->advancedSearchWhere(TRUE));

			// Get and validate search values for advanced search
			$this->loadSearchValues(); // Get search values

			// Process filter list
			if ($this->processFilterList())
				$this->terminate();
			if (!$this->validateSearch())
				$this->setFailureMessage($SearchError);

			// Restore search parms from Session if not searching / reset / export
			if (($this->isExport() || $this->Command != "search" && $this->Command != "reset" && $this->Command != "resetall") && $this->Command != "json" && $this->checkSearchParms())
				$this->restoreSearchParms();

			// Call Recordset SearchValidated event
			$this->Recordset_SearchValidated();

			// Set up sorting order
			$this->setupSortOrder();

			// Get search criteria for advanced search
			if ($SearchError == "")
				$srchAdvanced = $this->advancedSearchWhere();
		}

		// Restore display records
		if ($this->Command != "json" && $this->getRecordsPerPage() != "") {
			$this->DisplayRecords = $this->getRecordsPerPage(); // Restore from Session
		} else {
			$this->DisplayRecords = 10; // Load default
			$this->setRecordsPerPage($this->DisplayRecords); // Save default to Session
		}

		// Load Sorting Order
		if ($this->Command != "json")
			$this->loadSortOrder();

		// Load search default if no existing search criteria
		if (!$this->checkSearchParms()) {

			// Load advanced search from default
			if ($this->loadAdvancedSearchDefault()) {
				$srchAdvanced = $this->advancedSearchWhere();
			}
		}

		// Restore search settings from Session
		if ($SearchError == "")
			$this->loadAdvancedSearch();

		// Build search criteria
		AddFilter($this->SearchWhere, $srchAdvanced);
		AddFilter($this->SearchWhere, $srchBasic);

		// Call Recordset_Searching event
		$this->Recordset_Searching($this->SearchWhere);

		// Save search criteria
		if ($this->Command == "search" && !$this->RestoreSearch) {
			$this->setSearchWhere($this->SearchWhere); // Save to Session
			$this->StartRecord = 1; // Reset start record counter
			$this->setStartRecordNumber($this->StartRecord);
		} elseif ($this->Command != "json") {
			$this->SearchWhere = $this->getSearchWhere();
		}

		// Build filter
		$filter = "";
		if (!$Security->canList())
			$filter = "(0=1)"; // Filter all records
		AddFilter($filter, $this->DbDetailFilter);
		AddFilter($filter, $this->SearchWhere);
		if ($filter == "") {
			$filter = "0=101";
			$this->SearchWhere = $filter;
		}

		// Set up filter
		if ($this->Command == "json") {
			$this->UseSessionForListSql = FALSE; // Do not use session for ListSQL
			$this->CurrentFilter = $filter;
		} else {
			$this->setSessionWhere($filter);
			$this->CurrentFilter = "";
		}

		// Export data only
		if (!$this->CustomExport && in_array($this->Export, array_keys(Config("EXPORT_CLASSES")))) {
			$this->exportData();
			$this->terminate();
		}
		if ($this->isGridAdd()) {
			$this->CurrentFilter = "0=1";
			$this->StartRecord = 1;
			$this->DisplayRecords = $this->GridAddRowCount;
			$this->TotalRecords = $this->DisplayRecords;
			$this->StopRecord = $this->DisplayRecords;
		} else {
			$selectLimit = $this->UseSelectLimit;
			if ($selectLimit) {
				$this->TotalRecords = $this->listRecordCount();
			} else {
				if ($this->Recordset = $this->loadRecordset())
					$this->TotalRecords = $this->Recordset->RecordCount();
			}
			$this->StartRecord = 1;
			if ($this->DisplayRecords <= 0 || ($this->isExport() && $this->ExportAll)) // Display all records
				$this->DisplayRecords = $this->TotalRecords;
			if (!($this->isExport() && $this->ExportAll)) // Set up start record position
				$this->setupStartRecord();
			if ($selectLimit)
				$this->Recordset = $this->loadRecordset($this->StartRecord - 1, $this->DisplayRecords);

			// Set no record found message
			if (!$this->CurrentAction && $this->TotalRecords == 0) {
				if (!$Security->canList())
					$this->setWarningMessage(DeniedMessage());
				if ($this->SearchWhere == "0=101")
					$this->setWarningMessage($Language->phrase("EnterSearchCriteria"));
				else
					$this->setWarningMessage($Language->phrase("NoRecord"));
			}

			// Audit trail on search
			if ($this->AuditTrailOnSearch && $this->Command == "search" && !$this->RestoreSearch) {
				$searchParm = ServerVar("QUERY_STRING");
				$searchSql = $this->getSessionWhere();
				$this->writeAuditTrailOnSearch($searchParm, $searchSql);
			}
		}

		// Search options
		$this->setupSearchOptions();

		// Set up search panel class
		if ($this->SearchWhere != "")
			AppendClass($this->SearchPanelClass, "show");

		// Normal return
		if (IsApi()) {
			$rows = $this->getRecordsFromRecordset($this->Recordset);
			$this->Recordset->close();
			WriteJson(["success" => TRUE, $this->TableVar => $rows, "totalRecordCount" => $this->TotalRecords]);
			$this->terminate(TRUE);
		}

		// Set up pager
		$this->Pager = new PrevNextPager($this->StartRecord, $this->getRecordsPerPage(), $this->TotalRecords, $this->PageSizes, $this->RecordRange, $this->AutoHidePager, $this->AutoHidePageSizeSelector);
	}

	// Set up number of records displayed per page
	protected function setupDisplayRecords()
	{
		$wrk = Get(Config("TABLE_REC_PER_PAGE"), "");
		if ($wrk != "") {
			if (is_numeric($wrk)) {
				$this->DisplayRecords = (int)$wrk;
			} else {
				if (SameText($wrk, "all")) { // Display all records
					$this->DisplayRecords = -1;
				} else {
					$this->DisplayRecords = 10; // Non-numeric, load default
				}
			}
			$this->setRecordsPerPage($this->DisplayRecords); // Save to Session

			// Reset start position
			$this->StartRecord = 1;
			$this->setStartRecordNumber($this->StartRecord);
		}
	}

	// Build filter for all keys
	protected function buildKeyFilter()
	{
		global $CurrentForm;
		$wrkFilter = "";

		// Update row index and get row key
		$rowindex = 1;
		$CurrentForm->Index = $rowindex;
		$thisKey = strval($CurrentForm->getValue($this->FormKeyName));
		while ($thisKey != "") {
			if ($this->setupKeyValues($thisKey)) {
				$filter = $this->getRecordFilter();
				if ($wrkFilter != "")
					$wrkFilter .= " OR ";
				$wrkFilter .= $filter;
			} else {
				$wrkFilter = "0=1";
				break;
			}

			// Update row index and get row key
			$rowindex++; // Next row
			$CurrentForm->Index = $rowindex;
			$thisKey = strval($CurrentForm->getValue($this->FormKeyName));
		}
		return $wrkFilter;
	}

	// Set up key values
	protected function setupKeyValues($key)
	{
		$arKeyFlds = explode(Config("COMPOSITE_KEY_SEPARATOR"), $key);
		if (count($arKeyFlds) >= 1) {
			$this->infoid->setOldValue($arKeyFlds[0]);
			if (!is_numeric($this->infoid->OldValue))
				return FALSE;
		}
		return TRUE;
	}

	// Get list of filters
	public function getFilterList()
	{
		global $UserProfile;

		// Initialize
		$filterList = "";
		$savedFilterList = "";

		// Load server side filters
		if (Config("SEARCH_FILTER_OPTION") == "Server" && isset($UserProfile))
			$savedFilterList = $UserProfile->getSearchFilters(CurrentUserName(), "floaninfohistorylistsrch");
		$filterList = Concat($filterList, $this->infoid->AdvancedSearch->toJson(), ","); // Field infoid
		$filterList = Concat($filterList, $this->_userid->AdvancedSearch->toJson(), ","); // Field userid
		$filterList = Concat($filterList, $this->externalrefid->AdvancedSearch->toJson(), ","); // Field externalrefid
		$filterList = Concat($filterList, $this->currcode->AdvancedSearch->toJson(), ","); // Field currcode
		$filterList = Concat($filterList, $this->sampleloantype->AdvancedSearch->toJson(), ","); // Field sampleloantype
		$filterList = Concat($filterList, $this->sampleamount->AdvancedSearch->toJson(), ","); // Field sampleamount
		$filterList = Concat($filterList, $this->sampleamountforfeecalculation->AdvancedSearch->toJson(), ","); // Field sampleamountforfeecalculation
		$filterList = Concat($filterList, $this->eligibleamount->AdvancedSearch->toJson(), ","); // Field eligibleamount
		$filterList = Concat($filterList, $this->outstandingloanprinciple->AdvancedSearch->toJson(), ","); // Field outstandingloanprinciple
		$filterList = Concat($filterList, $this->outstandingloanfees->AdvancedSearch->toJson(), ","); // Field outstandingloanfees
		$filterList = Concat($filterList, $this->availableforloan->AdvancedSearch->toJson(), ","); // Field availableforloan
		$filterList = Concat($filterList, $this->status->AdvancedSearch->toJson(), ","); // Field status
		$filterList = Concat($filterList, $this->optin->AdvancedSearch->toJson(), ","); // Field optin
		$filterList = Concat($filterList, $this->sampleloanfeespretax->AdvancedSearch->toJson(), ","); // Field sampleloanfeespretax
		$filterList = Concat($filterList, $this->feetaxpercentage->AdvancedSearch->toJson(), ","); // Field feetaxpercentage
		$filterList = Concat($filterList, $this->feetaxamount->AdvancedSearch->toJson(), ","); // Field feetaxamount
		$filterList = Concat($filterList, $this->sampleloanfeesposttax->AdvancedSearch->toJson(), ","); // Field sampleloanfeesposttax
		$filterList = Concat($filterList, $this->feesystemtotal->AdvancedSearch->toJson(), ","); // Field feesystemtotal
		$filterList = Concat($filterList, $this->feeexternaltotal->AdvancedSearch->toJson(), ","); // Field feeexternaltotal
		$filterList = Concat($filterList, $this->feefranchiseetotal->AdvancedSearch->toJson(), ","); // Field feefranchiseetotal
		$filterList = Concat($filterList, $this->feeresellertotal->AdvancedSearch->toJson(), ","); // Field feeresellertotal
		$filterList = Concat($filterList, $this->outstandingloan->AdvancedSearch->toJson(), ","); // Field outstandingloan
		$filterList = Concat($filterList, $this->outstandingloanlatefees->AdvancedSearch->toJson(), ","); // Field outstandingloanlatefees
		$filterList = Concat($filterList, $this->intent->AdvancedSearch->toJson(), ","); // Field intent
		$filterList = Concat($filterList, $this->msg->AdvancedSearch->toJson(), ","); // Field msg
		$filterList = Concat($filterList, $this->infotime->AdvancedSearch->toJson(), ","); // Field infotime

		// Return filter list in JSON
		if ($filterList != "")
			$filterList = "\"data\":{" . $filterList . "}";
		if ($savedFilterList != "")
			$filterList = Concat($filterList, "\"filters\":" . $savedFilterList, ",");
		return ($filterList != "") ? "{" . $filterList . "}" : "null";
	}

	// Process filter list
	protected function processFilterList()
	{
		global $UserProfile;
		if (Post("ajax") == "savefilters") { // Save filter request (Ajax)
			$filters = Post("filters");
			$UserProfile->setSearchFilters(CurrentUserName(), "floaninfohistorylistsrch", $filters);
			WriteJson([["success" => TRUE]]); // Success
			return TRUE;
		} elseif (Post("cmd") == "resetfilter") {
			$this->restoreFilterList();
		}
		return FALSE;
	}

	// Restore list of filters
	protected function restoreFilterList()
	{

		// Return if not reset filter
		if (Post("cmd") !== "resetfilter")
			return FALSE;
		$filter = json_decode(Post("filter"), TRUE);
		$this->Command = "search";

		// Field infoid
		$this->infoid->AdvancedSearch->SearchValue = @$filter["x_infoid"];
		$this->infoid->AdvancedSearch->SearchOperator = @$filter["z_infoid"];
		$this->infoid->AdvancedSearch->SearchCondition = @$filter["v_infoid"];
		$this->infoid->AdvancedSearch->SearchValue2 = @$filter["y_infoid"];
		$this->infoid->AdvancedSearch->SearchOperator2 = @$filter["w_infoid"];
		$this->infoid->AdvancedSearch->save();

		// Field userid
		$this->_userid->AdvancedSearch->SearchValue = @$filter["x__userid"];
		$this->_userid->AdvancedSearch->SearchOperator = @$filter["z__userid"];
		$this->_userid->AdvancedSearch->SearchCondition = @$filter["v__userid"];
		$this->_userid->AdvancedSearch->SearchValue2 = @$filter["y__userid"];
		$this->_userid->AdvancedSearch->SearchOperator2 = @$filter["w__userid"];
		$this->_userid->AdvancedSearch->save();

		// Field externalrefid
		$this->externalrefid->AdvancedSearch->SearchValue = @$filter["x_externalrefid"];
		$this->externalrefid->AdvancedSearch->SearchOperator = @$filter["z_externalrefid"];
		$this->externalrefid->AdvancedSearch->SearchCondition = @$filter["v_externalrefid"];
		$this->externalrefid->AdvancedSearch->SearchValue2 = @$filter["y_externalrefid"];
		$this->externalrefid->AdvancedSearch->SearchOperator2 = @$filter["w_externalrefid"];
		$this->externalrefid->AdvancedSearch->save();

		// Field currcode
		$this->currcode->AdvancedSearch->SearchValue = @$filter["x_currcode"];
		$this->currcode->AdvancedSearch->SearchOperator = @$filter["z_currcode"];
		$this->currcode->AdvancedSearch->SearchCondition = @$filter["v_currcode"];
		$this->currcode->AdvancedSearch->SearchValue2 = @$filter["y_currcode"];
		$this->currcode->AdvancedSearch->SearchOperator2 = @$filter["w_currcode"];
		$this->currcode->AdvancedSearch->save();

		// Field sampleloantype
		$this->sampleloantype->AdvancedSearch->SearchValue = @$filter["x_sampleloantype"];
		$this->sampleloantype->AdvancedSearch->SearchOperator = @$filter["z_sampleloantype"];
		$this->sampleloantype->AdvancedSearch->SearchCondition = @$filter["v_sampleloantype"];
		$this->sampleloantype->AdvancedSearch->SearchValue2 = @$filter["y_sampleloantype"];
		$this->sampleloantype->AdvancedSearch->SearchOperator2 = @$filter["w_sampleloantype"];
		$this->sampleloantype->AdvancedSearch->save();

		// Field sampleamount
		$this->sampleamount->AdvancedSearch->SearchValue = @$filter["x_sampleamount"];
		$this->sampleamount->AdvancedSearch->SearchOperator = @$filter["z_sampleamount"];
		$this->sampleamount->AdvancedSearch->SearchCondition = @$filter["v_sampleamount"];
		$this->sampleamount->AdvancedSearch->SearchValue2 = @$filter["y_sampleamount"];
		$this->sampleamount->AdvancedSearch->SearchOperator2 = @$filter["w_sampleamount"];
		$this->sampleamount->AdvancedSearch->save();

		// Field sampleamountforfeecalculation
		$this->sampleamountforfeecalculation->AdvancedSearch->SearchValue = @$filter["x_sampleamountforfeecalculation"];
		$this->sampleamountforfeecalculation->AdvancedSearch->SearchOperator = @$filter["z_sampleamountforfeecalculation"];
		$this->sampleamountforfeecalculation->AdvancedSearch->SearchCondition = @$filter["v_sampleamountforfeecalculation"];
		$this->sampleamountforfeecalculation->AdvancedSearch->SearchValue2 = @$filter["y_sampleamountforfeecalculation"];
		$this->sampleamountforfeecalculation->AdvancedSearch->SearchOperator2 = @$filter["w_sampleamountforfeecalculation"];
		$this->sampleamountforfeecalculation->AdvancedSearch->save();

		// Field eligibleamount
		$this->eligibleamount->AdvancedSearch->SearchValue = @$filter["x_eligibleamount"];
		$this->eligibleamount->AdvancedSearch->SearchOperator = @$filter["z_eligibleamount"];
		$this->eligibleamount->AdvancedSearch->SearchCondition = @$filter["v_eligibleamount"];
		$this->eligibleamount->AdvancedSearch->SearchValue2 = @$filter["y_eligibleamount"];
		$this->eligibleamount->AdvancedSearch->SearchOperator2 = @$filter["w_eligibleamount"];
		$this->eligibleamount->AdvancedSearch->save();

		// Field outstandingloanprinciple
		$this->outstandingloanprinciple->AdvancedSearch->SearchValue = @$filter["x_outstandingloanprinciple"];
		$this->outstandingloanprinciple->AdvancedSearch->SearchOperator = @$filter["z_outstandingloanprinciple"];
		$this->outstandingloanprinciple->AdvancedSearch->SearchCondition = @$filter["v_outstandingloanprinciple"];
		$this->outstandingloanprinciple->AdvancedSearch->SearchValue2 = @$filter["y_outstandingloanprinciple"];
		$this->outstandingloanprinciple->AdvancedSearch->SearchOperator2 = @$filter["w_outstandingloanprinciple"];
		$this->outstandingloanprinciple->AdvancedSearch->save();

		// Field outstandingloanfees
		$this->outstandingloanfees->AdvancedSearch->SearchValue = @$filter["x_outstandingloanfees"];
		$this->outstandingloanfees->AdvancedSearch->SearchOperator = @$filter["z_outstandingloanfees"];
		$this->outstandingloanfees->AdvancedSearch->SearchCondition = @$filter["v_outstandingloanfees"];
		$this->outstandingloanfees->AdvancedSearch->SearchValue2 = @$filter["y_outstandingloanfees"];
		$this->outstandingloanfees->AdvancedSearch->SearchOperator2 = @$filter["w_outstandingloanfees"];
		$this->outstandingloanfees->AdvancedSearch->save();

		// Field availableforloan
		$this->availableforloan->AdvancedSearch->SearchValue = @$filter["x_availableforloan"];
		$this->availableforloan->AdvancedSearch->SearchOperator = @$filter["z_availableforloan"];
		$this->availableforloan->AdvancedSearch->SearchCondition = @$filter["v_availableforloan"];
		$this->availableforloan->AdvancedSearch->SearchValue2 = @$filter["y_availableforloan"];
		$this->availableforloan->AdvancedSearch->SearchOperator2 = @$filter["w_availableforloan"];
		$this->availableforloan->AdvancedSearch->save();

		// Field status
		$this->status->AdvancedSearch->SearchValue = @$filter["x_status"];
		$this->status->AdvancedSearch->SearchOperator = @$filter["z_status"];
		$this->status->AdvancedSearch->SearchCondition = @$filter["v_status"];
		$this->status->AdvancedSearch->SearchValue2 = @$filter["y_status"];
		$this->status->AdvancedSearch->SearchOperator2 = @$filter["w_status"];
		$this->status->AdvancedSearch->save();

		// Field optin
		$this->optin->AdvancedSearch->SearchValue = @$filter["x_optin"];
		$this->optin->AdvancedSearch->SearchOperator = @$filter["z_optin"];
		$this->optin->AdvancedSearch->SearchCondition = @$filter["v_optin"];
		$this->optin->AdvancedSearch->SearchValue2 = @$filter["y_optin"];
		$this->optin->AdvancedSearch->SearchOperator2 = @$filter["w_optin"];
		$this->optin->AdvancedSearch->save();

		// Field sampleloanfeespretax
		$this->sampleloanfeespretax->AdvancedSearch->SearchValue = @$filter["x_sampleloanfeespretax"];
		$this->sampleloanfeespretax->AdvancedSearch->SearchOperator = @$filter["z_sampleloanfeespretax"];
		$this->sampleloanfeespretax->AdvancedSearch->SearchCondition = @$filter["v_sampleloanfeespretax"];
		$this->sampleloanfeespretax->AdvancedSearch->SearchValue2 = @$filter["y_sampleloanfeespretax"];
		$this->sampleloanfeespretax->AdvancedSearch->SearchOperator2 = @$filter["w_sampleloanfeespretax"];
		$this->sampleloanfeespretax->AdvancedSearch->save();

		// Field feetaxpercentage
		$this->feetaxpercentage->AdvancedSearch->SearchValue = @$filter["x_feetaxpercentage"];
		$this->feetaxpercentage->AdvancedSearch->SearchOperator = @$filter["z_feetaxpercentage"];
		$this->feetaxpercentage->AdvancedSearch->SearchCondition = @$filter["v_feetaxpercentage"];
		$this->feetaxpercentage->AdvancedSearch->SearchValue2 = @$filter["y_feetaxpercentage"];
		$this->feetaxpercentage->AdvancedSearch->SearchOperator2 = @$filter["w_feetaxpercentage"];
		$this->feetaxpercentage->AdvancedSearch->save();

		// Field feetaxamount
		$this->feetaxamount->AdvancedSearch->SearchValue = @$filter["x_feetaxamount"];
		$this->feetaxamount->AdvancedSearch->SearchOperator = @$filter["z_feetaxamount"];
		$this->feetaxamount->AdvancedSearch->SearchCondition = @$filter["v_feetaxamount"];
		$this->feetaxamount->AdvancedSearch->SearchValue2 = @$filter["y_feetaxamount"];
		$this->feetaxamount->AdvancedSearch->SearchOperator2 = @$filter["w_feetaxamount"];
		$this->feetaxamount->AdvancedSearch->save();

		// Field sampleloanfeesposttax
		$this->sampleloanfeesposttax->AdvancedSearch->SearchValue = @$filter["x_sampleloanfeesposttax"];
		$this->sampleloanfeesposttax->AdvancedSearch->SearchOperator = @$filter["z_sampleloanfeesposttax"];
		$this->sampleloanfeesposttax->AdvancedSearch->SearchCondition = @$filter["v_sampleloanfeesposttax"];
		$this->sampleloanfeesposttax->AdvancedSearch->SearchValue2 = @$filter["y_sampleloanfeesposttax"];
		$this->sampleloanfeesposttax->AdvancedSearch->SearchOperator2 = @$filter["w_sampleloanfeesposttax"];
		$this->sampleloanfeesposttax->AdvancedSearch->save();

		// Field feesystemtotal
		$this->feesystemtotal->AdvancedSearch->SearchValue = @$filter["x_feesystemtotal"];
		$this->feesystemtotal->AdvancedSearch->SearchOperator = @$filter["z_feesystemtotal"];
		$this->feesystemtotal->AdvancedSearch->SearchCondition = @$filter["v_feesystemtotal"];
		$this->feesystemtotal->AdvancedSearch->SearchValue2 = @$filter["y_feesystemtotal"];
		$this->feesystemtotal->AdvancedSearch->SearchOperator2 = @$filter["w_feesystemtotal"];
		$this->feesystemtotal->AdvancedSearch->save();

		// Field feeexternaltotal
		$this->feeexternaltotal->AdvancedSearch->SearchValue = @$filter["x_feeexternaltotal"];
		$this->feeexternaltotal->AdvancedSearch->SearchOperator = @$filter["z_feeexternaltotal"];
		$this->feeexternaltotal->AdvancedSearch->SearchCondition = @$filter["v_feeexternaltotal"];
		$this->feeexternaltotal->AdvancedSearch->SearchValue2 = @$filter["y_feeexternaltotal"];
		$this->feeexternaltotal->AdvancedSearch->SearchOperator2 = @$filter["w_feeexternaltotal"];
		$this->feeexternaltotal->AdvancedSearch->save();

		// Field feefranchiseetotal
		$this->feefranchiseetotal->AdvancedSearch->SearchValue = @$filter["x_feefranchiseetotal"];
		$this->feefranchiseetotal->AdvancedSearch->SearchOperator = @$filter["z_feefranchiseetotal"];
		$this->feefranchiseetotal->AdvancedSearch->SearchCondition = @$filter["v_feefranchiseetotal"];
		$this->feefranchiseetotal->AdvancedSearch->SearchValue2 = @$filter["y_feefranchiseetotal"];
		$this->feefranchiseetotal->AdvancedSearch->SearchOperator2 = @$filter["w_feefranchiseetotal"];
		$this->feefranchiseetotal->AdvancedSearch->save();

		// Field feeresellertotal
		$this->feeresellertotal->AdvancedSearch->SearchValue = @$filter["x_feeresellertotal"];
		$this->feeresellertotal->AdvancedSearch->SearchOperator = @$filter["z_feeresellertotal"];
		$this->feeresellertotal->AdvancedSearch->SearchCondition = @$filter["v_feeresellertotal"];
		$this->feeresellertotal->AdvancedSearch->SearchValue2 = @$filter["y_feeresellertotal"];
		$this->feeresellertotal->AdvancedSearch->SearchOperator2 = @$filter["w_feeresellertotal"];
		$this->feeresellertotal->AdvancedSearch->save();

		// Field outstandingloan
		$this->outstandingloan->AdvancedSearch->SearchValue = @$filter["x_outstandingloan"];
		$this->outstandingloan->AdvancedSearch->SearchOperator = @$filter["z_outstandingloan"];
		$this->outstandingloan->AdvancedSearch->SearchCondition = @$filter["v_outstandingloan"];
		$this->outstandingloan->AdvancedSearch->SearchValue2 = @$filter["y_outstandingloan"];
		$this->outstandingloan->AdvancedSearch->SearchOperator2 = @$filter["w_outstandingloan"];
		$this->outstandingloan->AdvancedSearch->save();

		// Field outstandingloanlatefees
		$this->outstandingloanlatefees->AdvancedSearch->SearchValue = @$filter["x_outstandingloanlatefees"];
		$this->outstandingloanlatefees->AdvancedSearch->SearchOperator = @$filter["z_outstandingloanlatefees"];
		$this->outstandingloanlatefees->AdvancedSearch->SearchCondition = @$filter["v_outstandingloanlatefees"];
		$this->outstandingloanlatefees->AdvancedSearch->SearchValue2 = @$filter["y_outstandingloanlatefees"];
		$this->outstandingloanlatefees->AdvancedSearch->SearchOperator2 = @$filter["w_outstandingloanlatefees"];
		$this->outstandingloanlatefees->AdvancedSearch->save();

		// Field intent
		$this->intent->AdvancedSearch->SearchValue = @$filter["x_intent"];
		$this->intent->AdvancedSearch->SearchOperator = @$filter["z_intent"];
		$this->intent->AdvancedSearch->SearchCondition = @$filter["v_intent"];
		$this->intent->AdvancedSearch->SearchValue2 = @$filter["y_intent"];
		$this->intent->AdvancedSearch->SearchOperator2 = @$filter["w_intent"];
		$this->intent->AdvancedSearch->save();

		// Field msg
		$this->msg->AdvancedSearch->SearchValue = @$filter["x_msg"];
		$this->msg->AdvancedSearch->SearchOperator = @$filter["z_msg"];
		$this->msg->AdvancedSearch->SearchCondition = @$filter["v_msg"];
		$this->msg->AdvancedSearch->SearchValue2 = @$filter["y_msg"];
		$this->msg->AdvancedSearch->SearchOperator2 = @$filter["w_msg"];
		$this->msg->AdvancedSearch->save();

		// Field infotime
		$this->infotime->AdvancedSearch->SearchValue = @$filter["x_infotime"];
		$this->infotime->AdvancedSearch->SearchOperator = @$filter["z_infotime"];
		$this->infotime->AdvancedSearch->SearchCondition = @$filter["v_infotime"];
		$this->infotime->AdvancedSearch->SearchValue2 = @$filter["y_infotime"];
		$this->infotime->AdvancedSearch->SearchOperator2 = @$filter["w_infotime"];
		$this->infotime->AdvancedSearch->save();
	}

	// Advanced search WHERE clause based on QueryString
	protected function advancedSearchWhere($default = FALSE)
	{
		global $Security;
		$where = "";
		if (!$Security->canSearch())
			return "";
		$this->buildSearchSql($where, $this->infoid, $default, FALSE); // infoid
		$this->buildSearchSql($where, $this->_userid, $default, FALSE); // userid
		$this->buildSearchSql($where, $this->externalrefid, $default, FALSE); // externalrefid
		$this->buildSearchSql($where, $this->currcode, $default, FALSE); // currcode
		$this->buildSearchSql($where, $this->sampleloantype, $default, FALSE); // sampleloantype
		$this->buildSearchSql($where, $this->sampleamount, $default, FALSE); // sampleamount
		$this->buildSearchSql($where, $this->sampleamountforfeecalculation, $default, FALSE); // sampleamountforfeecalculation
		$this->buildSearchSql($where, $this->eligibleamount, $default, FALSE); // eligibleamount
		$this->buildSearchSql($where, $this->outstandingloanprinciple, $default, FALSE); // outstandingloanprinciple
		$this->buildSearchSql($where, $this->outstandingloanfees, $default, FALSE); // outstandingloanfees
		$this->buildSearchSql($where, $this->availableforloan, $default, FALSE); // availableforloan
		$this->buildSearchSql($where, $this->status, $default, FALSE); // status
		$this->buildSearchSql($where, $this->optin, $default, FALSE); // optin
		$this->buildSearchSql($where, $this->sampleloanfeespretax, $default, FALSE); // sampleloanfeespretax
		$this->buildSearchSql($where, $this->feetaxpercentage, $default, FALSE); // feetaxpercentage
		$this->buildSearchSql($where, $this->feetaxamount, $default, FALSE); // feetaxamount
		$this->buildSearchSql($where, $this->sampleloanfeesposttax, $default, FALSE); // sampleloanfeesposttax
		$this->buildSearchSql($where, $this->feesystemtotal, $default, FALSE); // feesystemtotal
		$this->buildSearchSql($where, $this->feeexternaltotal, $default, FALSE); // feeexternaltotal
		$this->buildSearchSql($where, $this->feefranchiseetotal, $default, FALSE); // feefranchiseetotal
		$this->buildSearchSql($where, $this->feeresellertotal, $default, FALSE); // feeresellertotal
		$this->buildSearchSql($where, $this->outstandingloan, $default, FALSE); // outstandingloan
		$this->buildSearchSql($where, $this->outstandingloanlatefees, $default, FALSE); // outstandingloanlatefees
		$this->buildSearchSql($where, $this->intent, $default, FALSE); // intent
		$this->buildSearchSql($where, $this->msg, $default, FALSE); // msg
		$this->buildSearchSql($where, $this->infotime, $default, FALSE); // infotime

		// Set up search parm
		if (!$default && $where != "" && in_array($this->Command, ["", "reset", "resetall"])) {
			$this->Command = "search";
		}
		if (!$default && $this->Command == "search") {
			$this->infoid->AdvancedSearch->save(); // infoid
			$this->_userid->AdvancedSearch->save(); // userid
			$this->externalrefid->AdvancedSearch->save(); // externalrefid
			$this->currcode->AdvancedSearch->save(); // currcode
			$this->sampleloantype->AdvancedSearch->save(); // sampleloantype
			$this->sampleamount->AdvancedSearch->save(); // sampleamount
			$this->sampleamountforfeecalculation->AdvancedSearch->save(); // sampleamountforfeecalculation
			$this->eligibleamount->AdvancedSearch->save(); // eligibleamount
			$this->outstandingloanprinciple->AdvancedSearch->save(); // outstandingloanprinciple
			$this->outstandingloanfees->AdvancedSearch->save(); // outstandingloanfees
			$this->availableforloan->AdvancedSearch->save(); // availableforloan
			$this->status->AdvancedSearch->save(); // status
			$this->optin->AdvancedSearch->save(); // optin
			$this->sampleloanfeespretax->AdvancedSearch->save(); // sampleloanfeespretax
			$this->feetaxpercentage->AdvancedSearch->save(); // feetaxpercentage
			$this->feetaxamount->AdvancedSearch->save(); // feetaxamount
			$this->sampleloanfeesposttax->AdvancedSearch->save(); // sampleloanfeesposttax
			$this->feesystemtotal->AdvancedSearch->save(); // feesystemtotal
			$this->feeexternaltotal->AdvancedSearch->save(); // feeexternaltotal
			$this->feefranchiseetotal->AdvancedSearch->save(); // feefranchiseetotal
			$this->feeresellertotal->AdvancedSearch->save(); // feeresellertotal
			$this->outstandingloan->AdvancedSearch->save(); // outstandingloan
			$this->outstandingloanlatefees->AdvancedSearch->save(); // outstandingloanlatefees
			$this->intent->AdvancedSearch->save(); // intent
			$this->msg->AdvancedSearch->save(); // msg
			$this->infotime->AdvancedSearch->save(); // infotime
		}
		return $where;
	}

	// Build search SQL
	protected function buildSearchSql(&$where, &$fld, $default, $multiValue)
	{
		$fldParm = $fld->Param;
		$fldVal = ($default) ? $fld->AdvancedSearch->SearchValueDefault : $fld->AdvancedSearch->SearchValue;
		$fldOpr = ($default) ? $fld->AdvancedSearch->SearchOperatorDefault : $fld->AdvancedSearch->SearchOperator;
		$fldCond = ($default) ? $fld->AdvancedSearch->SearchConditionDefault : $fld->AdvancedSearch->SearchCondition;
		$fldVal2 = ($default) ? $fld->AdvancedSearch->SearchValue2Default : $fld->AdvancedSearch->SearchValue2;
		$fldOpr2 = ($default) ? $fld->AdvancedSearch->SearchOperator2Default : $fld->AdvancedSearch->SearchOperator2;
		$wrk = "";
		if (is_array($fldVal))
			$fldVal = implode(Config("MULTIPLE_OPTION_SEPARATOR"), $fldVal);
		if (is_array($fldVal2))
			$fldVal2 = implode(Config("MULTIPLE_OPTION_SEPARATOR"), $fldVal2);
		$fldOpr = strtoupper(trim($fldOpr));
		if ($fldOpr == "")
			$fldOpr = "=";
		$fldOpr2 = strtoupper(trim($fldOpr2));
		if ($fldOpr2 == "")
			$fldOpr2 = "=";
		if (Config("SEARCH_MULTI_VALUE_OPTION") == 1 || !IsMultiSearchOperator($fldOpr))
			$multiValue = FALSE;
		if ($multiValue) {
			$wrk1 = ($fldVal != "") ? GetMultiSearchSql($fld, $fldOpr, $fldVal, $this->Dbid) : ""; // Field value 1
			$wrk2 = ($fldVal2 != "") ? GetMultiSearchSql($fld, $fldOpr2, $fldVal2, $this->Dbid) : ""; // Field value 2
			$wrk = $wrk1; // Build final SQL
			if ($wrk2 != "")
				$wrk = ($wrk != "") ? "($wrk) $fldCond ($wrk2)" : $wrk2;
		} else {
			$fldVal = $this->convertSearchValue($fld, $fldVal);
			$fldVal2 = $this->convertSearchValue($fld, $fldVal2);
			$wrk = GetSearchSql($fld, $fldVal, $fldOpr, $fldCond, $fldVal2, $fldOpr2, $this->Dbid);
		}
		AddFilter($where, $wrk);
	}

	// Convert search value
	protected function convertSearchValue(&$fld, $fldVal)
	{
		if ($fldVal == Config("NULL_VALUE") || $fldVal == Config("NOT_NULL_VALUE"))
			return $fldVal;
		$value = $fldVal;
		if ($fld->isBoolean()) {
			if ($fldVal != "")
				$value = (SameText($fldVal, "1") || SameText($fldVal, "y") || SameText($fldVal, "t")) ? $fld->TrueValue : $fld->FalseValue;
		} elseif ($fld->DataType == DATATYPE_DATE || $fld->DataType == DATATYPE_TIME) {
			if ($fldVal != "")
				$value = UnFormatDateTime($fldVal, $fld->DateTimeFormat);
		}
		return $value;
	}

	// Check if search parm exists
	protected function checkSearchParms()
	{
		if ($this->infoid->AdvancedSearch->issetSession())
			return TRUE;
		if ($this->_userid->AdvancedSearch->issetSession())
			return TRUE;
		if ($this->externalrefid->AdvancedSearch->issetSession())
			return TRUE;
		if ($this->currcode->AdvancedSearch->issetSession())
			return TRUE;
		if ($this->sampleloantype->AdvancedSearch->issetSession())
			return TRUE;
		if ($this->sampleamount->AdvancedSearch->issetSession())
			return TRUE;
		if ($this->sampleamountforfeecalculation->AdvancedSearch->issetSession())
			return TRUE;
		if ($this->eligibleamount->AdvancedSearch->issetSession())
			return TRUE;
		if ($this->outstandingloanprinciple->AdvancedSearch->issetSession())
			return TRUE;
		if ($this->outstandingloanfees->AdvancedSearch->issetSession())
			return TRUE;
		if ($this->availableforloan->AdvancedSearch->issetSession())
			return TRUE;
		if ($this->status->AdvancedSearch->issetSession())
			return TRUE;
		if ($this->optin->AdvancedSearch->issetSession())
			return TRUE;
		if ($this->sampleloanfeespretax->AdvancedSearch->issetSession())
			return TRUE;
		if ($this->feetaxpercentage->AdvancedSearch->issetSession())
			return TRUE;
		if ($this->feetaxamount->AdvancedSearch->issetSession())
			return TRUE;
		if ($this->sampleloanfeesposttax->AdvancedSearch->issetSession())
			return TRUE;
		if ($this->feesystemtotal->AdvancedSearch->issetSession())
			return TRUE;
		if ($this->feeexternaltotal->AdvancedSearch->issetSession())
			return TRUE;
		if ($this->feefranchiseetotal->AdvancedSearch->issetSession())
			return TRUE;
		if ($this->feeresellertotal->AdvancedSearch->issetSession())
			return TRUE;
		if ($this->outstandingloan->AdvancedSearch->issetSession())
			return TRUE;
		if ($this->outstandingloanlatefees->AdvancedSearch->issetSession())
			return TRUE;
		if ($this->intent->AdvancedSearch->issetSession())
			return TRUE;
		if ($this->msg->AdvancedSearch->issetSession())
			return TRUE;
		if ($this->infotime->AdvancedSearch->issetSession())
			return TRUE;
		return FALSE;
	}

	// Clear all search parameters
	protected function resetSearchParms()
	{

		// Clear search WHERE clause
		$this->SearchWhere = "";
		$this->setSearchWhere($this->SearchWhere);

		// Clear advanced search parameters
		$this->resetAdvancedSearchParms();
	}

	// Load advanced search default values
	protected function loadAdvancedSearchDefault()
	{
		return FALSE;
	}

	// Clear all advanced search parameters
	protected function resetAdvancedSearchParms()
	{
		$this->infoid->AdvancedSearch->unsetSession();
		$this->_userid->AdvancedSearch->unsetSession();
		$this->externalrefid->AdvancedSearch->unsetSession();
		$this->currcode->AdvancedSearch->unsetSession();
		$this->sampleloantype->AdvancedSearch->unsetSession();
		$this->sampleamount->AdvancedSearch->unsetSession();
		$this->sampleamountforfeecalculation->AdvancedSearch->unsetSession();
		$this->eligibleamount->AdvancedSearch->unsetSession();
		$this->outstandingloanprinciple->AdvancedSearch->unsetSession();
		$this->outstandingloanfees->AdvancedSearch->unsetSession();
		$this->availableforloan->AdvancedSearch->unsetSession();
		$this->status->AdvancedSearch->unsetSession();
		$this->optin->AdvancedSearch->unsetSession();
		$this->sampleloanfeespretax->AdvancedSearch->unsetSession();
		$this->feetaxpercentage->AdvancedSearch->unsetSession();
		$this->feetaxamount->AdvancedSearch->unsetSession();
		$this->sampleloanfeesposttax->AdvancedSearch->unsetSession();
		$this->feesystemtotal->AdvancedSearch->unsetSession();
		$this->feeexternaltotal->AdvancedSearch->unsetSession();
		$this->feefranchiseetotal->AdvancedSearch->unsetSession();
		$this->feeresellertotal->AdvancedSearch->unsetSession();
		$this->outstandingloan->AdvancedSearch->unsetSession();
		$this->outstandingloanlatefees->AdvancedSearch->unsetSession();
		$this->intent->AdvancedSearch->unsetSession();
		$this->msg->AdvancedSearch->unsetSession();
		$this->infotime->AdvancedSearch->unsetSession();
	}

	// Restore all search parameters
	protected function restoreSearchParms()
	{
		$this->RestoreSearch = TRUE;

		// Restore advanced search values
		$this->infoid->AdvancedSearch->load();
		$this->_userid->AdvancedSearch->load();
		$this->externalrefid->AdvancedSearch->load();
		$this->currcode->AdvancedSearch->load();
		$this->sampleloantype->AdvancedSearch->load();
		$this->sampleamount->AdvancedSearch->load();
		$this->sampleamountforfeecalculation->AdvancedSearch->load();
		$this->eligibleamount->AdvancedSearch->load();
		$this->outstandingloanprinciple->AdvancedSearch->load();
		$this->outstandingloanfees->AdvancedSearch->load();
		$this->availableforloan->AdvancedSearch->load();
		$this->status->AdvancedSearch->load();
		$this->optin->AdvancedSearch->load();
		$this->sampleloanfeespretax->AdvancedSearch->load();
		$this->feetaxpercentage->AdvancedSearch->load();
		$this->feetaxamount->AdvancedSearch->load();
		$this->sampleloanfeesposttax->AdvancedSearch->load();
		$this->feesystemtotal->AdvancedSearch->load();
		$this->feeexternaltotal->AdvancedSearch->load();
		$this->feefranchiseetotal->AdvancedSearch->load();
		$this->feeresellertotal->AdvancedSearch->load();
		$this->outstandingloan->AdvancedSearch->load();
		$this->outstandingloanlatefees->AdvancedSearch->load();
		$this->intent->AdvancedSearch->load();
		$this->msg->AdvancedSearch->load();
		$this->infotime->AdvancedSearch->load();
	}

	// Set up sort parameters
	protected function setupSortOrder()
	{

		// Check for "order" parameter
		if (Get("order") !== NULL) {
			$this->CurrentOrder = Get("order");
			$this->CurrentOrderType = Get("ordertype", "");
			$this->updateSort($this->infoid); // infoid
			$this->updateSort($this->_userid); // userid
			$this->updateSort($this->externalrefid); // externalrefid
			$this->updateSort($this->currcode); // currcode
			$this->updateSort($this->sampleloantype); // sampleloantype
			$this->updateSort($this->sampleamount); // sampleamount
			$this->updateSort($this->sampleamountforfeecalculation); // sampleamountforfeecalculation
			$this->updateSort($this->eligibleamount); // eligibleamount
			$this->updateSort($this->outstandingloanprinciple); // outstandingloanprinciple
			$this->updateSort($this->outstandingloanfees); // outstandingloanfees
			$this->updateSort($this->availableforloan); // availableforloan
			$this->updateSort($this->status); // status
			$this->updateSort($this->optin); // optin
			$this->updateSort($this->sampleloanfeespretax); // sampleloanfeespretax
			$this->updateSort($this->feetaxpercentage); // feetaxpercentage
			$this->updateSort($this->feetaxamount); // feetaxamount
			$this->updateSort($this->sampleloanfeesposttax); // sampleloanfeesposttax
			$this->updateSort($this->feesystemtotal); // feesystemtotal
			$this->updateSort($this->feeexternaltotal); // feeexternaltotal
			$this->updateSort($this->feefranchiseetotal); // feefranchiseetotal
			$this->updateSort($this->feeresellertotal); // feeresellertotal
			$this->updateSort($this->outstandingloan); // outstandingloan
			$this->updateSort($this->outstandingloanlatefees); // outstandingloanlatefees
			$this->updateSort($this->intent); // intent
			$this->updateSort($this->msg); // msg
			$this->updateSort($this->infotime); // infotime
			$this->setStartRecordNumber(1); // Reset start position
		}
	}

	// Load sort order parameters
	protected function loadSortOrder()
	{
		$orderBy = $this->getSessionOrderBy(); // Get ORDER BY from Session
		if ($orderBy == "") {
			if ($this->getSqlOrderBy() != "") {
				$orderBy = $this->getSqlOrderBy();
				$this->setSessionOrderBy($orderBy);
			}
		}
	}

	// Reset command
	// - cmd=reset (Reset search parameters)
	// - cmd=resetall (Reset search and master/detail parameters)
	// - cmd=resetsort (Reset sort parameters)

	protected function resetCmd()
	{

		// Check if reset command
		if (StartsString("reset", $this->Command)) {

			// Reset search criteria
			if ($this->Command == "reset" || $this->Command == "resetall")
				$this->resetSearchParms();

			// Reset sorting order
			if ($this->Command == "resetsort") {
				$orderBy = "";
				$this->setSessionOrderBy($orderBy);
				$this->infoid->setSort("");
				$this->_userid->setSort("");
				$this->externalrefid->setSort("");
				$this->currcode->setSort("");
				$this->sampleloantype->setSort("");
				$this->sampleamount->setSort("");
				$this->sampleamountforfeecalculation->setSort("");
				$this->eligibleamount->setSort("");
				$this->outstandingloanprinciple->setSort("");
				$this->outstandingloanfees->setSort("");
				$this->availableforloan->setSort("");
				$this->status->setSort("");
				$this->optin->setSort("");
				$this->sampleloanfeespretax->setSort("");
				$this->feetaxpercentage->setSort("");
				$this->feetaxamount->setSort("");
				$this->sampleloanfeesposttax->setSort("");
				$this->feesystemtotal->setSort("");
				$this->feeexternaltotal->setSort("");
				$this->feefranchiseetotal->setSort("");
				$this->feeresellertotal->setSort("");
				$this->outstandingloan->setSort("");
				$this->outstandingloanlatefees->setSort("");
				$this->intent->setSort("");
				$this->msg->setSort("");
				$this->infotime->setSort("");
			}

			// Reset start position
			$this->StartRecord = 1;
			$this->setStartRecordNumber($this->StartRecord);
		}
	}

	// Set up list options
	protected function setupListOptions()
	{
		global $Security, $Language;

		// Add group option item
		$item = &$this->ListOptions->add($this->ListOptions->GroupOptionName);
		$item->Body = "";
		$item->OnLeft = FALSE;
		$item->Visible = FALSE;

		// "view"
		$item = &$this->ListOptions->add("view");
		$item->CssClass = "text-nowrap";
		$item->Visible = $Security->canView();
		$item->OnLeft = FALSE;

		// "edit"
		$item = &$this->ListOptions->add("edit");
		$item->CssClass = "text-nowrap";
		$item->Visible = $Security->canEdit();
		$item->OnLeft = FALSE;

		// "copy"
		$item = &$this->ListOptions->add("copy");
		$item->CssClass = "text-nowrap";
		$item->Visible = $Security->canAdd();
		$item->OnLeft = FALSE;

		// "delete"
		$item = &$this->ListOptions->add("delete");
		$item->CssClass = "text-nowrap";
		$item->Visible = $Security->canDelete();
		$item->OnLeft = FALSE;

		// List actions
		$item = &$this->ListOptions->add("listactions");
		$item->CssClass = "text-nowrap";
		$item->OnLeft = FALSE;
		$item->Visible = FALSE;
		$item->ShowInButtonGroup = FALSE;
		$item->ShowInDropDown = FALSE;

		// "checkbox"
		$item = &$this->ListOptions->add("checkbox");
		$item->Visible = FALSE;
		$item->OnLeft = FALSE;
		$item->Header = "<div class=\"custom-control custom-checkbox d-inline-block\"><input type=\"checkbox\" name=\"key\" id=\"key\" class=\"custom-control-input\" onclick=\"ew.selectAllKey(this);\"><label class=\"custom-control-label\" for=\"key\"></label></div>";
		$item->ShowInDropDown = FALSE;
		$item->ShowInButtonGroup = FALSE;

		// Drop down button for ListOptions
		$this->ListOptions->UseDropDownButton = FALSE;
		$this->ListOptions->DropDownButtonPhrase = $Language->phrase("ButtonListOptions");
		$this->ListOptions->UseButtonGroup = FALSE;
		if ($this->ListOptions->UseButtonGroup && IsMobile())
			$this->ListOptions->UseDropDownButton = TRUE;

		//$this->ListOptions->ButtonClass = ""; // Class for button group
		// Call ListOptions_Load event

		$this->ListOptions_Load();
		$this->setupListOptionsExt();
		$item = $this->ListOptions[$this->ListOptions->GroupOptionName];
		$item->Visible = $this->ListOptions->groupOptionVisible();
	}

	// Render list options
	public function renderListOptions()
	{
		global $Security, $Language, $CurrentForm;
		$this->ListOptions->loadDefault();

		// Call ListOptions_Rendering event
		$this->ListOptions_Rendering();

		// "view"
		$opt = $this->ListOptions["view"];
		$viewcaption = HtmlTitle($Language->phrase("ViewLink"));
		if ($Security->canView()) {
			$opt->Body = "<a class=\"ew-row-link ew-view\" title=\"" . $viewcaption . "\" data-caption=\"" . $viewcaption . "\" href=\"" . HtmlEncode($this->ViewUrl) . "\">" . $Language->phrase("ViewLink") . "</a>";
		} else {
			$opt->Body = "";
		}

		// "edit"
		$opt = $this->ListOptions["edit"];
		$editcaption = HtmlTitle($Language->phrase("EditLink"));
		if ($Security->canEdit()) {
			$opt->Body = "<a class=\"ew-row-link ew-edit\" title=\"" . HtmlTitle($Language->phrase("EditLink")) . "\" data-caption=\"" . HtmlTitle($Language->phrase("EditLink")) . "\" href=\"" . HtmlEncode($this->EditUrl) . "\">" . $Language->phrase("EditLink") . "</a>";
		} else {
			$opt->Body = "";
		}

		// "copy"
		$opt = $this->ListOptions["copy"];
		$copycaption = HtmlTitle($Language->phrase("CopyLink"));
		if ($Security->canAdd()) {
			$opt->Body = "<a class=\"ew-row-link ew-copy\" title=\"" . $copycaption . "\" data-caption=\"" . $copycaption . "\" href=\"" . HtmlEncode($this->CopyUrl) . "\">" . $Language->phrase("CopyLink") . "</a>";
		} else {
			$opt->Body = "";
		}

		// "delete"
		$opt = $this->ListOptions["delete"];
		if ($Security->canDelete())
			$opt->Body = "<a class=\"ew-row-link ew-delete\"" . "" . " title=\"" . HtmlTitle($Language->phrase("DeleteLink")) . "\" data-caption=\"" . HtmlTitle($Language->phrase("DeleteLink")) . "\" href=\"" . HtmlEncode($this->DeleteUrl) . "\">" . $Language->phrase("DeleteLink") . "</a>";
		else
			$opt->Body = "";

		// Set up list action buttons
		$opt = $this->ListOptions["listactions"];
		if ($opt && !$this->isExport() && !$this->CurrentAction) {
			$body = "";
			$links = [];
			foreach ($this->ListActions->Items as $listaction) {
				if ($listaction->Select == ACTION_SINGLE && $listaction->Allow) {
					$action = $listaction->Action;
					$caption = $listaction->Caption;
					$icon = ($listaction->Icon != "") ? "<i class=\"" . HtmlEncode(str_replace(" ew-icon", "", $listaction->Icon)) . "\" data-caption=\"" . HtmlTitle($caption) . "\"></i> " : "";
					$links[] = "<li><a class=\"dropdown-item ew-action ew-list-action\" data-action=\"" . HtmlEncode($action) . "\" data-caption=\"" . HtmlTitle($caption) . "\" href=\"#\" onclick=\"return ew.submitAction(event,jQuery.extend({key:" . $this->keyToJson(TRUE) . "}," . $listaction->toJson(TRUE) . "));\">" . $icon . $listaction->Caption . "</a></li>";
					if (count($links) == 1) // Single button
						$body = "<a class=\"ew-action ew-list-action\" data-action=\"" . HtmlEncode($action) . "\" title=\"" . HtmlTitle($caption) . "\" data-caption=\"" . HtmlTitle($caption) . "\" href=\"#\" onclick=\"return ew.submitAction(event,jQuery.extend({key:" . $this->keyToJson(TRUE) . "}," . $listaction->toJson(TRUE) . "));\">" . $icon . $listaction->Caption . "</a>";
				}
			}
			if (count($links) > 1) { // More than one buttons, use dropdown
				$body = "<button class=\"dropdown-toggle btn btn-default ew-actions\" title=\"" . HtmlTitle($Language->phrase("ListActionButton")) . "\" data-toggle=\"dropdown\">" . $Language->phrase("ListActionButton") . "</button>";
				$content = "";
				foreach ($links as $link)
					$content .= "<li>" . $link . "</li>";
				$body .= "<ul class=\"dropdown-menu" . ($opt->OnLeft ? "" : " dropdown-menu-right") . "\">". $content . "</ul>";
				$body = "<div class=\"btn-group btn-group-sm\">" . $body . "</div>";
			}
			if (count($links) > 0) {
				$opt->Body = $body;
				$opt->Visible = TRUE;
			}
		}

		// "checkbox"
		$opt = $this->ListOptions["checkbox"];
		$opt->Body = "<div class=\"custom-control custom-checkbox d-inline-block\"><input type=\"checkbox\" id=\"key_m_" . $this->RowCount . "\" name=\"key_m[]\" class=\"custom-control-input ew-multi-select\" value=\"" . HtmlEncode($this->infoid->CurrentValue) . "\" onclick=\"ew.clickMultiCheckbox(event);\"><label class=\"custom-control-label\" for=\"key_m_" . $this->RowCount . "\"></label></div>";
		$this->renderListOptionsExt();

		// Call ListOptions_Rendered event
		$this->ListOptions_Rendered();
	}

	// Set up other options
	protected function setupOtherOptions()
	{
		global $Language, $Security;
		$options = &$this->OtherOptions;
		$option = $options["addedit"];

		// Add
		$item = &$option->add("add");
		$addcaption = HtmlTitle($Language->phrase("AddLink"));
		$item->Body = "<a class=\"ew-add-edit ew-add\" title=\"" . $addcaption . "\" data-caption=\"" . $addcaption . "\" href=\"" . HtmlEncode($this->AddUrl) . "\">" . $Language->phrase("AddLink") . "</a>";
		$item->Visible = $this->AddUrl != "" && $Security->canAdd();
		$option = $options["action"];

		// Set up options default
		foreach ($options as $option) {
			$option->UseDropDownButton = FALSE;
			$option->UseButtonGroup = TRUE;

			//$option->ButtonClass = ""; // Class for button group
			$item = &$option->add($option->GroupOptionName);
			$item->Body = "";
			$item->Visible = FALSE;
		}
		$options["addedit"]->DropDownButtonPhrase = $Language->phrase("ButtonAddEdit");
		$options["detail"]->DropDownButtonPhrase = $Language->phrase("ButtonDetails");
		$options["action"]->DropDownButtonPhrase = $Language->phrase("ButtonActions");

		// Filter button
		$item = &$this->FilterOptions->add("savecurrentfilter");
		$item->Body = "<a class=\"ew-save-filter\" data-form=\"floaninfohistorylistsrch\" href=\"#\" onclick=\"return false;\">" . $Language->phrase("SaveCurrentFilter") . "</a>";
		$item->Visible = TRUE;
		$item = &$this->FilterOptions->add("deletefilter");
		$item->Body = "<a class=\"ew-delete-filter\" data-form=\"floaninfohistorylistsrch\" href=\"#\" onclick=\"return false;\">" . $Language->phrase("DeleteFilter") . "</a>";
		$item->Visible = TRUE;
		$this->FilterOptions->UseDropDownButton = TRUE;
		$this->FilterOptions->UseButtonGroup = !$this->FilterOptions->UseDropDownButton;
		$this->FilterOptions->DropDownButtonPhrase = $Language->phrase("Filters");

		// Add group option item
		$item = &$this->FilterOptions->add($this->FilterOptions->GroupOptionName);
		$item->Body = "";
		$item->Visible = FALSE;
	}

	// Render other options
	public function renderOtherOptions()
	{
		global $Language, $Security;
		$options = &$this->OtherOptions;
			$option = $options["action"];

			// Set up list action buttons
			foreach ($this->ListActions->Items as $listaction) {
				if ($listaction->Select == ACTION_MULTIPLE) {
					$item = &$option->add("custom_" . $listaction->Action);
					$caption = $listaction->Caption;
					$icon = ($listaction->Icon != "") ? "<i class=\"" . HtmlEncode($listaction->Icon) . "\" data-caption=\"" . HtmlEncode($caption) . "\"></i> " . $caption : $caption;
					$item->Body = "<a class=\"ew-action ew-list-action\" title=\"" . HtmlEncode($caption) . "\" data-caption=\"" . HtmlEncode($caption) . "\" href=\"#\" onclick=\"return ew.submitAction(event,jQuery.extend({f:document.floaninfohistorylist}," . $listaction->toJson(TRUE) . "));\">" . $icon . "</a>";
					$item->Visible = $listaction->Allow;
				}
			}

			// Hide grid edit and other options
			if ($this->TotalRecords <= 0) {
				$option = $options["addedit"];
				$item = $option["gridedit"];
				if ($item)
					$item->Visible = FALSE;
				$option = $options["action"];
				$option->hideAllOptions();
			}
	}

	// Process list action
	protected function processListAction()
	{
		global $Language, $Security;
		$userlist = "";
		$user = "";
		$filter = $this->getFilterFromRecordKeys();
		$userAction = Post("useraction", "");
		if ($filter != "" && $userAction != "") {

			// Check permission first
			$actionCaption = $userAction;
			if (array_key_exists($userAction, $this->ListActions->Items)) {
				$actionCaption = $this->ListActions[$userAction]->Caption;
				if (!$this->ListActions[$userAction]->Allow) {
					$errmsg = str_replace('%s', $actionCaption, $Language->phrase("CustomActionNotAllowed"));
					if (Post("ajax") == $userAction) // Ajax
						echo "<p class=\"text-danger\">" . $errmsg . "</p>";
					else
						$this->setFailureMessage($errmsg);
					return FALSE;
				}
			}
			$this->CurrentFilter = $filter;
			$sql = $this->getCurrentSql();
			$conn = $this->getConnection();
			$conn->raiseErrorFn = Config("ERROR_FUNC");
			$rs = $conn->execute($sql);
			$conn->raiseErrorFn = "";
			$this->CurrentAction = $userAction;

			// Call row action event
			if ($rs && !$rs->EOF) {
				$conn->beginTrans();
				$this->SelectedCount = $rs->RecordCount();
				$this->SelectedIndex = 0;
				while (!$rs->EOF) {
					$this->SelectedIndex++;
					$row = $rs->fields;
					$processed = $this->Row_CustomAction($userAction, $row);
					if (!$processed)
						break;
					$rs->moveNext();
				}
				if ($processed) {
					$conn->commitTrans(); // Commit the changes
					if ($this->getSuccessMessage() == "" && !ob_get_length()) // No output
						$this->setSuccessMessage(str_replace('%s', $actionCaption, $Language->phrase("CustomActionCompleted"))); // Set up success message
				} else {
					$conn->rollbackTrans(); // Rollback changes

					// Set up error message
					if ($this->getSuccessMessage() != "" || $this->getFailureMessage() != "") {

						// Use the message, do nothing
					} elseif ($this->CancelMessage != "") {
						$this->setFailureMessage($this->CancelMessage);
						$this->CancelMessage = "";
					} else {
						$this->setFailureMessage(str_replace('%s', $actionCaption, $Language->phrase("CustomActionFailed")));
					}
				}
			}
			if ($rs)
				$rs->close();
			$this->CurrentAction = ""; // Clear action
			if (Post("ajax") == $userAction) { // Ajax
				if ($this->getSuccessMessage() != "") {
					echo "<p class=\"text-success\">" . $this->getSuccessMessage() . "</p>";
					$this->clearSuccessMessage(); // Clear message
				}
				if ($this->getFailureMessage() != "") {
					echo "<p class=\"text-danger\">" . $this->getFailureMessage() . "</p>";
					$this->clearFailureMessage(); // Clear message
				}
				return TRUE;
			}
		}
		return FALSE; // Not ajax request
	}

// Set up list options (extended codes)
	protected function setupListOptionsExt()
	{

		// Hide detail items for dropdown if necessary
		$this->ListOptions->hideDetailItemsForDropDown();
	}

// Render list options (extended codes)
	protected function renderListOptionsExt()
	{
		global $Security, $Language;
	}

	// Load search values for validation
	protected function loadSearchValues()
	{

		// Load search values
		$got = FALSE;

		// infoid
		if (!$this->isAddOrEdit() && $this->infoid->AdvancedSearch->get()) {
			$got = TRUE;
			if (($this->infoid->AdvancedSearch->SearchValue != "" || $this->infoid->AdvancedSearch->SearchValue2 != "") && $this->Command == "")
				$this->Command = "search";
		}

		// userid
		if (!$this->isAddOrEdit() && $this->_userid->AdvancedSearch->get()) {
			$got = TRUE;
			if (($this->_userid->AdvancedSearch->SearchValue != "" || $this->_userid->AdvancedSearch->SearchValue2 != "") && $this->Command == "")
				$this->Command = "search";
		}

		// externalrefid
		if (!$this->isAddOrEdit() && $this->externalrefid->AdvancedSearch->get()) {
			$got = TRUE;
			if (($this->externalrefid->AdvancedSearch->SearchValue != "" || $this->externalrefid->AdvancedSearch->SearchValue2 != "") && $this->Command == "")
				$this->Command = "search";
		}

		// currcode
		if (!$this->isAddOrEdit() && $this->currcode->AdvancedSearch->get()) {
			$got = TRUE;
			if (($this->currcode->AdvancedSearch->SearchValue != "" || $this->currcode->AdvancedSearch->SearchValue2 != "") && $this->Command == "")
				$this->Command = "search";
		}

		// sampleloantype
		if (!$this->isAddOrEdit() && $this->sampleloantype->AdvancedSearch->get()) {
			$got = TRUE;
			if (($this->sampleloantype->AdvancedSearch->SearchValue != "" || $this->sampleloantype->AdvancedSearch->SearchValue2 != "") && $this->Command == "")
				$this->Command = "search";
		}

		// sampleamount
		if (!$this->isAddOrEdit() && $this->sampleamount->AdvancedSearch->get()) {
			$got = TRUE;
			if (($this->sampleamount->AdvancedSearch->SearchValue != "" || $this->sampleamount->AdvancedSearch->SearchValue2 != "") && $this->Command == "")
				$this->Command = "search";
		}

		// sampleamountforfeecalculation
		if (!$this->isAddOrEdit() && $this->sampleamountforfeecalculation->AdvancedSearch->get()) {
			$got = TRUE;
			if (($this->sampleamountforfeecalculation->AdvancedSearch->SearchValue != "" || $this->sampleamountforfeecalculation->AdvancedSearch->SearchValue2 != "") && $this->Command == "")
				$this->Command = "search";
		}

		// eligibleamount
		if (!$this->isAddOrEdit() && $this->eligibleamount->AdvancedSearch->get()) {
			$got = TRUE;
			if (($this->eligibleamount->AdvancedSearch->SearchValue != "" || $this->eligibleamount->AdvancedSearch->SearchValue2 != "") && $this->Command == "")
				$this->Command = "search";
		}

		// outstandingloanprinciple
		if (!$this->isAddOrEdit() && $this->outstandingloanprinciple->AdvancedSearch->get()) {
			$got = TRUE;
			if (($this->outstandingloanprinciple->AdvancedSearch->SearchValue != "" || $this->outstandingloanprinciple->AdvancedSearch->SearchValue2 != "") && $this->Command == "")
				$this->Command = "search";
		}

		// outstandingloanfees
		if (!$this->isAddOrEdit() && $this->outstandingloanfees->AdvancedSearch->get()) {
			$got = TRUE;
			if (($this->outstandingloanfees->AdvancedSearch->SearchValue != "" || $this->outstandingloanfees->AdvancedSearch->SearchValue2 != "") && $this->Command == "")
				$this->Command = "search";
		}

		// availableforloan
		if (!$this->isAddOrEdit() && $this->availableforloan->AdvancedSearch->get()) {
			$got = TRUE;
			if (($this->availableforloan->AdvancedSearch->SearchValue != "" || $this->availableforloan->AdvancedSearch->SearchValue2 != "") && $this->Command == "")
				$this->Command = "search";
		}

		// status
		if (!$this->isAddOrEdit() && $this->status->AdvancedSearch->get()) {
			$got = TRUE;
			if (($this->status->AdvancedSearch->SearchValue != "" || $this->status->AdvancedSearch->SearchValue2 != "") && $this->Command == "")
				$this->Command = "search";
		}

		// optin
		if (!$this->isAddOrEdit() && $this->optin->AdvancedSearch->get()) {
			$got = TRUE;
			if (($this->optin->AdvancedSearch->SearchValue != "" || $this->optin->AdvancedSearch->SearchValue2 != "") && $this->Command == "")
				$this->Command = "search";
		}

		// sampleloanfeespretax
		if (!$this->isAddOrEdit() && $this->sampleloanfeespretax->AdvancedSearch->get()) {
			$got = TRUE;
			if (($this->sampleloanfeespretax->AdvancedSearch->SearchValue != "" || $this->sampleloanfeespretax->AdvancedSearch->SearchValue2 != "") && $this->Command == "")
				$this->Command = "search";
		}

		// feetaxpercentage
		if (!$this->isAddOrEdit() && $this->feetaxpercentage->AdvancedSearch->get()) {
			$got = TRUE;
			if (($this->feetaxpercentage->AdvancedSearch->SearchValue != "" || $this->feetaxpercentage->AdvancedSearch->SearchValue2 != "") && $this->Command == "")
				$this->Command = "search";
		}

		// feetaxamount
		if (!$this->isAddOrEdit() && $this->feetaxamount->AdvancedSearch->get()) {
			$got = TRUE;
			if (($this->feetaxamount->AdvancedSearch->SearchValue != "" || $this->feetaxamount->AdvancedSearch->SearchValue2 != "") && $this->Command == "")
				$this->Command = "search";
		}

		// sampleloanfeesposttax
		if (!$this->isAddOrEdit() && $this->sampleloanfeesposttax->AdvancedSearch->get()) {
			$got = TRUE;
			if (($this->sampleloanfeesposttax->AdvancedSearch->SearchValue != "" || $this->sampleloanfeesposttax->AdvancedSearch->SearchValue2 != "") && $this->Command == "")
				$this->Command = "search";
		}

		// feesystemtotal
		if (!$this->isAddOrEdit() && $this->feesystemtotal->AdvancedSearch->get()) {
			$got = TRUE;
			if (($this->feesystemtotal->AdvancedSearch->SearchValue != "" || $this->feesystemtotal->AdvancedSearch->SearchValue2 != "") && $this->Command == "")
				$this->Command = "search";
		}

		// feeexternaltotal
		if (!$this->isAddOrEdit() && $this->feeexternaltotal->AdvancedSearch->get()) {
			$got = TRUE;
			if (($this->feeexternaltotal->AdvancedSearch->SearchValue != "" || $this->feeexternaltotal->AdvancedSearch->SearchValue2 != "") && $this->Command == "")
				$this->Command = "search";
		}

		// feefranchiseetotal
		if (!$this->isAddOrEdit() && $this->feefranchiseetotal->AdvancedSearch->get()) {
			$got = TRUE;
			if (($this->feefranchiseetotal->AdvancedSearch->SearchValue != "" || $this->feefranchiseetotal->AdvancedSearch->SearchValue2 != "") && $this->Command == "")
				$this->Command = "search";
		}

		// feeresellertotal
		if (!$this->isAddOrEdit() && $this->feeresellertotal->AdvancedSearch->get()) {
			$got = TRUE;
			if (($this->feeresellertotal->AdvancedSearch->SearchValue != "" || $this->feeresellertotal->AdvancedSearch->SearchValue2 != "") && $this->Command == "")
				$this->Command = "search";
		}

		// outstandingloan
		if (!$this->isAddOrEdit() && $this->outstandingloan->AdvancedSearch->get()) {
			$got = TRUE;
			if (($this->outstandingloan->AdvancedSearch->SearchValue != "" || $this->outstandingloan->AdvancedSearch->SearchValue2 != "") && $this->Command == "")
				$this->Command = "search";
		}

		// outstandingloanlatefees
		if (!$this->isAddOrEdit() && $this->outstandingloanlatefees->AdvancedSearch->get()) {
			$got = TRUE;
			if (($this->outstandingloanlatefees->AdvancedSearch->SearchValue != "" || $this->outstandingloanlatefees->AdvancedSearch->SearchValue2 != "") && $this->Command == "")
				$this->Command = "search";
		}

		// intent
		if (!$this->isAddOrEdit() && $this->intent->AdvancedSearch->get()) {
			$got = TRUE;
			if (($this->intent->AdvancedSearch->SearchValue != "" || $this->intent->AdvancedSearch->SearchValue2 != "") && $this->Command == "")
				$this->Command = "search";
		}

		// msg
		if (!$this->isAddOrEdit() && $this->msg->AdvancedSearch->get()) {
			$got = TRUE;
			if (($this->msg->AdvancedSearch->SearchValue != "" || $this->msg->AdvancedSearch->SearchValue2 != "") && $this->Command == "")
				$this->Command = "search";
		}

		// infotime
		if (!$this->isAddOrEdit() && $this->infotime->AdvancedSearch->get()) {
			$got = TRUE;
			if (($this->infotime->AdvancedSearch->SearchValue != "" || $this->infotime->AdvancedSearch->SearchValue2 != "") && $this->Command == "")
				$this->Command = "search";
		}
		return $got;
	}

	// Load recordset
	public function loadRecordset($offset = -1, $rowcnt = -1)
	{

		// Load List page SQL
		$sql = $this->getListSql();
		$conn = $this->getConnection();

		// Load recordset
		$dbtype = GetConnectionType($this->Dbid);
		if ($this->UseSelectLimit) {
			$conn->raiseErrorFn = Config("ERROR_FUNC");
			if ($dbtype == "MSSQL") {
				$rs = $conn->selectLimit($sql, $rowcnt, $offset, ["_hasOrderBy" => trim($this->getOrderBy()) || trim($this->getSessionOrderBy())]);
			} else {
				$rs = $conn->selectLimit($sql, $rowcnt, $offset);
			}
			$conn->raiseErrorFn = "";
		} else {
			$rs = LoadRecordset($sql, $conn);
		}

		// Call Recordset Selected event
		$this->Recordset_Selected($rs);
		return $rs;
	}

	// Load row based on key values
	public function loadRow()
	{
		global $Security, $Language;
		$filter = $this->getRecordFilter();

		// Call Row Selecting event
		$this->Row_Selecting($filter);

		// Load SQL based on filter
		$this->CurrentFilter = $filter;
		$sql = $this->getCurrentSql();
		$conn = $this->getConnection();
		$res = FALSE;
		$rs = LoadRecordset($sql, $conn);
		if ($rs && !$rs->EOF) {
			$res = TRUE;
			$this->loadRowValues($rs); // Load row values
			$rs->close();
		}
		return $res;
	}

	// Load row values from recordset
	public function loadRowValues($rs = NULL)
	{
		if ($rs && !$rs->EOF)
			$row = $rs->fields;
		else
			$row = $this->newRow();

		// Call Row Selected event
		$this->Row_Selected($row);
		if (!$rs || $rs->EOF)
			return;
		$this->infoid->setDbValue($row['infoid']);
		$this->_userid->setDbValue($row['userid']);
		$this->externalrefid->setDbValue($row['externalrefid']);
		$this->currcode->setDbValue($row['currcode']);
		$this->sampleloantype->setDbValue($row['sampleloantype']);
		$this->sampleamount->setDbValue($row['sampleamount']);
		$this->sampleamountforfeecalculation->setDbValue($row['sampleamountforfeecalculation']);
		$this->eligibleamount->setDbValue($row['eligibleamount']);
		$this->outstandingloanprinciple->setDbValue($row['outstandingloanprinciple']);
		$this->outstandingloanfees->setDbValue($row['outstandingloanfees']);
		$this->availableforloan->setDbValue($row['availableforloan']);
		$this->status->setDbValue($row['status']);
		$this->optin->setDbValue($row['optin']);
		$this->sampleloanfeespretax->setDbValue($row['sampleloanfeespretax']);
		$this->feetaxpercentage->setDbValue($row['feetaxpercentage']);
		$this->feetaxamount->setDbValue($row['feetaxamount']);
		$this->sampleloanfeesposttax->setDbValue($row['sampleloanfeesposttax']);
		$this->feesystemtotal->setDbValue($row['feesystemtotal']);
		$this->feeexternaltotal->setDbValue($row['feeexternaltotal']);
		$this->feefranchiseetotal->setDbValue($row['feefranchiseetotal']);
		$this->feeresellertotal->setDbValue($row['feeresellertotal']);
		$this->outstandingloan->setDbValue($row['outstandingloan']);
		$this->outstandingloanlatefees->setDbValue($row['outstandingloanlatefees']);
		$this->intent->setDbValue($row['intent']);
		$this->msg->setDbValue($row['msg']);
		$this->infotime->setDbValue($row['infotime']);
	}

	// Return a row with default values
	protected function newRow()
	{
		$row = [];
		$row['infoid'] = NULL;
		$row['userid'] = NULL;
		$row['externalrefid'] = NULL;
		$row['currcode'] = NULL;
		$row['sampleloantype'] = NULL;
		$row['sampleamount'] = NULL;
		$row['sampleamountforfeecalculation'] = NULL;
		$row['eligibleamount'] = NULL;
		$row['outstandingloanprinciple'] = NULL;
		$row['outstandingloanfees'] = NULL;
		$row['availableforloan'] = NULL;
		$row['status'] = NULL;
		$row['optin'] = NULL;
		$row['sampleloanfeespretax'] = NULL;
		$row['feetaxpercentage'] = NULL;
		$row['feetaxamount'] = NULL;
		$row['sampleloanfeesposttax'] = NULL;
		$row['feesystemtotal'] = NULL;
		$row['feeexternaltotal'] = NULL;
		$row['feefranchiseetotal'] = NULL;
		$row['feeresellertotal'] = NULL;
		$row['outstandingloan'] = NULL;
		$row['outstandingloanlatefees'] = NULL;
		$row['intent'] = NULL;
		$row['msg'] = NULL;
		$row['infotime'] = NULL;
		return $row;
	}

	// Load old record
	protected function loadOldRecord()
	{

		// Load key values from Session
		$validKey = TRUE;
		if (strval($this->getKey("infoid")) != "")
			$this->infoid->OldValue = $this->getKey("infoid"); // infoid
		else
			$validKey = FALSE;

		// Load old record
		$this->OldRecordset = NULL;
		if ($validKey) {
			$this->CurrentFilter = $this->getRecordFilter();
			$sql = $this->getCurrentSql();
			$conn = $this->getConnection();
			$this->OldRecordset = LoadRecordset($sql, $conn);
		}
		$this->loadRowValues($this->OldRecordset); // Load row values
		return $validKey;
	}

	// Render row values based on field settings
	public function renderRow()
	{
		global $Security, $Language, $CurrentLanguage;

		// Initialize URLs
		$this->ViewUrl = $this->getViewUrl();
		$this->EditUrl = $this->getEditUrl();
		$this->InlineEditUrl = $this->getInlineEditUrl();
		$this->CopyUrl = $this->getCopyUrl();
		$this->InlineCopyUrl = $this->getInlineCopyUrl();
		$this->DeleteUrl = $this->getDeleteUrl();

		// Convert decimal values if posted back
		if ($this->sampleamount->FormValue == $this->sampleamount->CurrentValue && is_numeric(ConvertToFloatString($this->sampleamount->CurrentValue)))
			$this->sampleamount->CurrentValue = ConvertToFloatString($this->sampleamount->CurrentValue);

		// Convert decimal values if posted back
		if ($this->sampleamountforfeecalculation->FormValue == $this->sampleamountforfeecalculation->CurrentValue && is_numeric(ConvertToFloatString($this->sampleamountforfeecalculation->CurrentValue)))
			$this->sampleamountforfeecalculation->CurrentValue = ConvertToFloatString($this->sampleamountforfeecalculation->CurrentValue);

		// Convert decimal values if posted back
		if ($this->eligibleamount->FormValue == $this->eligibleamount->CurrentValue && is_numeric(ConvertToFloatString($this->eligibleamount->CurrentValue)))
			$this->eligibleamount->CurrentValue = ConvertToFloatString($this->eligibleamount->CurrentValue);

		// Convert decimal values if posted back
		if ($this->outstandingloanprinciple->FormValue == $this->outstandingloanprinciple->CurrentValue && is_numeric(ConvertToFloatString($this->outstandingloanprinciple->CurrentValue)))
			$this->outstandingloanprinciple->CurrentValue = ConvertToFloatString($this->outstandingloanprinciple->CurrentValue);

		// Convert decimal values if posted back
		if ($this->outstandingloanfees->FormValue == $this->outstandingloanfees->CurrentValue && is_numeric(ConvertToFloatString($this->outstandingloanfees->CurrentValue)))
			$this->outstandingloanfees->CurrentValue = ConvertToFloatString($this->outstandingloanfees->CurrentValue);

		// Convert decimal values if posted back
		if ($this->availableforloan->FormValue == $this->availableforloan->CurrentValue && is_numeric(ConvertToFloatString($this->availableforloan->CurrentValue)))
			$this->availableforloan->CurrentValue = ConvertToFloatString($this->availableforloan->CurrentValue);

		// Convert decimal values if posted back
		if ($this->sampleloanfeespretax->FormValue == $this->sampleloanfeespretax->CurrentValue && is_numeric(ConvertToFloatString($this->sampleloanfeespretax->CurrentValue)))
			$this->sampleloanfeespretax->CurrentValue = ConvertToFloatString($this->sampleloanfeespretax->CurrentValue);

		// Convert decimal values if posted back
		if ($this->feetaxpercentage->FormValue == $this->feetaxpercentage->CurrentValue && is_numeric(ConvertToFloatString($this->feetaxpercentage->CurrentValue)))
			$this->feetaxpercentage->CurrentValue = ConvertToFloatString($this->feetaxpercentage->CurrentValue);

		// Convert decimal values if posted back
		if ($this->feetaxamount->FormValue == $this->feetaxamount->CurrentValue && is_numeric(ConvertToFloatString($this->feetaxamount->CurrentValue)))
			$this->feetaxamount->CurrentValue = ConvertToFloatString($this->feetaxamount->CurrentValue);

		// Convert decimal values if posted back
		if ($this->sampleloanfeesposttax->FormValue == $this->sampleloanfeesposttax->CurrentValue && is_numeric(ConvertToFloatString($this->sampleloanfeesposttax->CurrentValue)))
			$this->sampleloanfeesposttax->CurrentValue = ConvertToFloatString($this->sampleloanfeesposttax->CurrentValue);

		// Convert decimal values if posted back
		if ($this->feesystemtotal->FormValue == $this->feesystemtotal->CurrentValue && is_numeric(ConvertToFloatString($this->feesystemtotal->CurrentValue)))
			$this->feesystemtotal->CurrentValue = ConvertToFloatString($this->feesystemtotal->CurrentValue);

		// Convert decimal values if posted back
		if ($this->feeexternaltotal->FormValue == $this->feeexternaltotal->CurrentValue && is_numeric(ConvertToFloatString($this->feeexternaltotal->CurrentValue)))
			$this->feeexternaltotal->CurrentValue = ConvertToFloatString($this->feeexternaltotal->CurrentValue);

		// Convert decimal values if posted back
		if ($this->feefranchiseetotal->FormValue == $this->feefranchiseetotal->CurrentValue && is_numeric(ConvertToFloatString($this->feefranchiseetotal->CurrentValue)))
			$this->feefranchiseetotal->CurrentValue = ConvertToFloatString($this->feefranchiseetotal->CurrentValue);

		// Convert decimal values if posted back
		if ($this->feeresellertotal->FormValue == $this->feeresellertotal->CurrentValue && is_numeric(ConvertToFloatString($this->feeresellertotal->CurrentValue)))
			$this->feeresellertotal->CurrentValue = ConvertToFloatString($this->feeresellertotal->CurrentValue);

		// Convert decimal values if posted back
		if ($this->outstandingloan->FormValue == $this->outstandingloan->CurrentValue && is_numeric(ConvertToFloatString($this->outstandingloan->CurrentValue)))
			$this->outstandingloan->CurrentValue = ConvertToFloatString($this->outstandingloan->CurrentValue);

		// Convert decimal values if posted back
		if ($this->outstandingloanlatefees->FormValue == $this->outstandingloanlatefees->CurrentValue && is_numeric(ConvertToFloatString($this->outstandingloanlatefees->CurrentValue)))
			$this->outstandingloanlatefees->CurrentValue = ConvertToFloatString($this->outstandingloanlatefees->CurrentValue);

		// Call Row_Rendering event
		$this->Row_Rendering();

		// Common render codes for all row types
		// infoid
		// userid
		// externalrefid
		// currcode
		// sampleloantype
		// sampleamount
		// sampleamountforfeecalculation
		// eligibleamount
		// outstandingloanprinciple
		// outstandingloanfees
		// availableforloan
		// status
		// optin
		// sampleloanfeespretax
		// feetaxpercentage
		// feetaxamount
		// sampleloanfeesposttax
		// feesystemtotal
		// feeexternaltotal
		// feefranchiseetotal
		// feeresellertotal
		// outstandingloan
		// outstandingloanlatefees
		// intent
		// msg
		// infotime

		if ($this->RowType == ROWTYPE_VIEW) { // View row

			// infoid
			$this->infoid->ViewValue = $this->infoid->CurrentValue;
			$this->infoid->ViewCustomAttributes = "";

			// userid
			$this->_userid->ViewValue = $this->_userid->CurrentValue;
			$this->_userid->ViewCustomAttributes = "";

			// externalrefid
			$this->externalrefid->ViewValue = $this->externalrefid->CurrentValue;
			$this->externalrefid->ViewCustomAttributes = "";

			// currcode
			$this->currcode->ViewValue = $this->currcode->CurrentValue;
			$this->currcode->ViewCustomAttributes = "";

			// sampleloantype
			$this->sampleloantype->ViewValue = $this->sampleloantype->CurrentValue;
			$this->sampleloantype->ViewCustomAttributes = "";

			// sampleamount
			$this->sampleamount->ViewValue = $this->sampleamount->CurrentValue;
			$this->sampleamount->ViewValue = FormatNumber($this->sampleamount->ViewValue, Config("DEFAULT_DECIMAL_PRECISION"));
			$this->sampleamount->ViewCustomAttributes = "";

			// sampleamountforfeecalculation
			$this->sampleamountforfeecalculation->ViewValue = $this->sampleamountforfeecalculation->CurrentValue;
			$this->sampleamountforfeecalculation->ViewValue = FormatNumber($this->sampleamountforfeecalculation->ViewValue, Config("DEFAULT_DECIMAL_PRECISION"));
			$this->sampleamountforfeecalculation->ViewCustomAttributes = "";

			// eligibleamount
			$this->eligibleamount->ViewValue = $this->eligibleamount->CurrentValue;
			$this->eligibleamount->ViewValue = FormatNumber($this->eligibleamount->ViewValue, Config("DEFAULT_DECIMAL_PRECISION"));
			$this->eligibleamount->ViewCustomAttributes = "";

			// outstandingloanprinciple
			$this->outstandingloanprinciple->ViewValue = $this->outstandingloanprinciple->CurrentValue;
			$this->outstandingloanprinciple->ViewValue = FormatNumber($this->outstandingloanprinciple->ViewValue, Config("DEFAULT_DECIMAL_PRECISION"));
			$this->outstandingloanprinciple->ViewCustomAttributes = "";

			// outstandingloanfees
			$this->outstandingloanfees->ViewValue = $this->outstandingloanfees->CurrentValue;
			$this->outstandingloanfees->ViewValue = FormatNumber($this->outstandingloanfees->ViewValue, Config("DEFAULT_DECIMAL_PRECISION"));
			$this->outstandingloanfees->ViewCustomAttributes = "";

			// availableforloan
			$this->availableforloan->ViewValue = $this->availableforloan->CurrentValue;
			$this->availableforloan->ViewValue = FormatNumber($this->availableforloan->ViewValue, Config("DEFAULT_DECIMAL_PRECISION"));
			$this->availableforloan->ViewCustomAttributes = "";

			// status
			$this->status->ViewValue = $this->status->CurrentValue;
			$this->status->ViewCustomAttributes = "";

			// optin
			$this->optin->ViewValue = $this->optin->CurrentValue;
			$this->optin->ViewCustomAttributes = "";

			// sampleloanfeespretax
			$this->sampleloanfeespretax->ViewValue = $this->sampleloanfeespretax->CurrentValue;
			$this->sampleloanfeespretax->ViewValue = FormatNumber($this->sampleloanfeespretax->ViewValue, Config("DEFAULT_DECIMAL_PRECISION"));
			$this->sampleloanfeespretax->ViewCustomAttributes = "";

			// feetaxpercentage
			$this->feetaxpercentage->ViewValue = $this->feetaxpercentage->CurrentValue;
			$this->feetaxpercentage->ViewValue = FormatNumber($this->feetaxpercentage->ViewValue, Config("DEFAULT_DECIMAL_PRECISION"));
			$this->feetaxpercentage->ViewCustomAttributes = "";

			// feetaxamount
			$this->feetaxamount->ViewValue = $this->feetaxamount->CurrentValue;
			$this->feetaxamount->ViewValue = FormatNumber($this->feetaxamount->ViewValue, Config("DEFAULT_DECIMAL_PRECISION"));
			$this->feetaxamount->ViewCustomAttributes = "";

			// sampleloanfeesposttax
			$this->sampleloanfeesposttax->ViewValue = $this->sampleloanfeesposttax->CurrentValue;
			$this->sampleloanfeesposttax->ViewValue = FormatNumber($this->sampleloanfeesposttax->ViewValue, Config("DEFAULT_DECIMAL_PRECISION"));
			$this->sampleloanfeesposttax->ViewCustomAttributes = "";

			// feesystemtotal
			$this->feesystemtotal->ViewValue = $this->feesystemtotal->CurrentValue;
			$this->feesystemtotal->ViewValue = FormatNumber($this->feesystemtotal->ViewValue, Config("DEFAULT_DECIMAL_PRECISION"));
			$this->feesystemtotal->ViewCustomAttributes = "";

			// feeexternaltotal
			$this->feeexternaltotal->ViewValue = $this->feeexternaltotal->CurrentValue;
			$this->feeexternaltotal->ViewValue = FormatNumber($this->feeexternaltotal->ViewValue, Config("DEFAULT_DECIMAL_PRECISION"));
			$this->feeexternaltotal->ViewCustomAttributes = "";

			// feefranchiseetotal
			$this->feefranchiseetotal->ViewValue = $this->feefranchiseetotal->CurrentValue;
			$this->feefranchiseetotal->ViewValue = FormatNumber($this->feefranchiseetotal->ViewValue, Config("DEFAULT_DECIMAL_PRECISION"));
			$this->feefranchiseetotal->ViewCustomAttributes = "";

			// feeresellertotal
			$this->feeresellertotal->ViewValue = $this->feeresellertotal->CurrentValue;
			$this->feeresellertotal->ViewValue = FormatNumber($this->feeresellertotal->ViewValue, Config("DEFAULT_DECIMAL_PRECISION"));
			$this->feeresellertotal->ViewCustomAttributes = "";

			// outstandingloan
			$this->outstandingloan->ViewValue = $this->outstandingloan->CurrentValue;
			$this->outstandingloan->ViewValue = FormatNumber($this->outstandingloan->ViewValue, 2, -2, -2, -2);
			$this->outstandingloan->ViewCustomAttributes = "";

			// outstandingloanlatefees
			$this->outstandingloanlatefees->ViewValue = $this->outstandingloanlatefees->CurrentValue;
			$this->outstandingloanlatefees->ViewValue = FormatNumber($this->outstandingloanlatefees->ViewValue, 2, -2, -2, -2);
			$this->outstandingloanlatefees->ViewCustomAttributes = "";

			// intent
			$this->intent->ViewValue = $this->intent->CurrentValue;
			$this->intent->ViewCustomAttributes = "";

			// msg
			$this->msg->ViewValue = $this->msg->CurrentValue;
			$this->msg->ViewCustomAttributes = "";

			// infotime
			$this->infotime->ViewValue = $this->infotime->CurrentValue;
			$this->infotime->ViewValue = FormatDateTime($this->infotime->ViewValue, 0);
			$this->infotime->ViewCustomAttributes = "";

			// infoid
			$this->infoid->LinkCustomAttributes = "";
			$this->infoid->HrefValue = "";
			$this->infoid->TooltipValue = "";
			if (!$this->isExport())
				$this->infoid->ViewValue = $this->highlightValue($this->infoid);

			// userid
			$this->_userid->LinkCustomAttributes = "";
			$this->_userid->HrefValue = "";
			$this->_userid->TooltipValue = "";
			if (!$this->isExport())
				$this->_userid->ViewValue = $this->highlightValue($this->_userid);

			// externalrefid
			$this->externalrefid->LinkCustomAttributes = "";
			$this->externalrefid->HrefValue = "";
			$this->externalrefid->TooltipValue = "";
			if (!$this->isExport())
				$this->externalrefid->ViewValue = $this->highlightValue($this->externalrefid);

			// currcode
			$this->currcode->LinkCustomAttributes = "";
			$this->currcode->HrefValue = "";
			$this->currcode->TooltipValue = "";
			if (!$this->isExport())
				$this->currcode->ViewValue = $this->highlightValue($this->currcode);

			// sampleloantype
			$this->sampleloantype->LinkCustomAttributes = "";
			$this->sampleloantype->HrefValue = "";
			$this->sampleloantype->TooltipValue = "";
			if (!$this->isExport())
				$this->sampleloantype->ViewValue = $this->highlightValue($this->sampleloantype);

			// sampleamount
			$this->sampleamount->LinkCustomAttributes = "";
			$this->sampleamount->HrefValue = "";
			$this->sampleamount->TooltipValue = "";
			if (!$this->isExport())
				$this->sampleamount->ViewValue = $this->highlightValue($this->sampleamount);

			// sampleamountforfeecalculation
			$this->sampleamountforfeecalculation->LinkCustomAttributes = "";
			$this->sampleamountforfeecalculation->HrefValue = "";
			$this->sampleamountforfeecalculation->TooltipValue = "";
			if (!$this->isExport())
				$this->sampleamountforfeecalculation->ViewValue = $this->highlightValue($this->sampleamountforfeecalculation);

			// eligibleamount
			$this->eligibleamount->LinkCustomAttributes = "";
			$this->eligibleamount->HrefValue = "";
			$this->eligibleamount->TooltipValue = "";
			if (!$this->isExport())
				$this->eligibleamount->ViewValue = $this->highlightValue($this->eligibleamount);

			// outstandingloanprinciple
			$this->outstandingloanprinciple->LinkCustomAttributes = "";
			$this->outstandingloanprinciple->HrefValue = "";
			$this->outstandingloanprinciple->TooltipValue = "";
			if (!$this->isExport())
				$this->outstandingloanprinciple->ViewValue = $this->highlightValue($this->outstandingloanprinciple);

			// outstandingloanfees
			$this->outstandingloanfees->LinkCustomAttributes = "";
			$this->outstandingloanfees->HrefValue = "";
			$this->outstandingloanfees->TooltipValue = "";
			if (!$this->isExport())
				$this->outstandingloanfees->ViewValue = $this->highlightValue($this->outstandingloanfees);

			// availableforloan
			$this->availableforloan->LinkCustomAttributes = "";
			$this->availableforloan->HrefValue = "";
			$this->availableforloan->TooltipValue = "";
			if (!$this->isExport())
				$this->availableforloan->ViewValue = $this->highlightValue($this->availableforloan);

			// status
			$this->status->LinkCustomAttributes = "";
			$this->status->HrefValue = "";
			$this->status->TooltipValue = "";
			if (!$this->isExport())
				$this->status->ViewValue = $this->highlightValue($this->status);

			// optin
			$this->optin->LinkCustomAttributes = "";
			$this->optin->HrefValue = "";
			$this->optin->TooltipValue = "";
			if (!$this->isExport())
				$this->optin->ViewValue = $this->highlightValue($this->optin);

			// sampleloanfeespretax
			$this->sampleloanfeespretax->LinkCustomAttributes = "";
			$this->sampleloanfeespretax->HrefValue = "";
			$this->sampleloanfeespretax->TooltipValue = "";
			if (!$this->isExport())
				$this->sampleloanfeespretax->ViewValue = $this->highlightValue($this->sampleloanfeespretax);

			// feetaxpercentage
			$this->feetaxpercentage->LinkCustomAttributes = "";
			$this->feetaxpercentage->HrefValue = "";
			$this->feetaxpercentage->TooltipValue = "";
			if (!$this->isExport())
				$this->feetaxpercentage->ViewValue = $this->highlightValue($this->feetaxpercentage);

			// feetaxamount
			$this->feetaxamount->LinkCustomAttributes = "";
			$this->feetaxamount->HrefValue = "";
			$this->feetaxamount->TooltipValue = "";
			if (!$this->isExport())
				$this->feetaxamount->ViewValue = $this->highlightValue($this->feetaxamount);

			// sampleloanfeesposttax
			$this->sampleloanfeesposttax->LinkCustomAttributes = "";
			$this->sampleloanfeesposttax->HrefValue = "";
			$this->sampleloanfeesposttax->TooltipValue = "";
			if (!$this->isExport())
				$this->sampleloanfeesposttax->ViewValue = $this->highlightValue($this->sampleloanfeesposttax);

			// feesystemtotal
			$this->feesystemtotal->LinkCustomAttributes = "";
			$this->feesystemtotal->HrefValue = "";
			$this->feesystemtotal->TooltipValue = "";
			if (!$this->isExport())
				$this->feesystemtotal->ViewValue = $this->highlightValue($this->feesystemtotal);

			// feeexternaltotal
			$this->feeexternaltotal->LinkCustomAttributes = "";
			$this->feeexternaltotal->HrefValue = "";
			$this->feeexternaltotal->TooltipValue = "";
			if (!$this->isExport())
				$this->feeexternaltotal->ViewValue = $this->highlightValue($this->feeexternaltotal);

			// feefranchiseetotal
			$this->feefranchiseetotal->LinkCustomAttributes = "";
			$this->feefranchiseetotal->HrefValue = "";
			$this->feefranchiseetotal->TooltipValue = "";
			if (!$this->isExport())
				$this->feefranchiseetotal->ViewValue = $this->highlightValue($this->feefranchiseetotal);

			// feeresellertotal
			$this->feeresellertotal->LinkCustomAttributes = "";
			$this->feeresellertotal->HrefValue = "";
			$this->feeresellertotal->TooltipValue = "";
			if (!$this->isExport())
				$this->feeresellertotal->ViewValue = $this->highlightValue($this->feeresellertotal);

			// outstandingloan
			$this->outstandingloan->LinkCustomAttributes = "";
			$this->outstandingloan->HrefValue = "";
			$this->outstandingloan->TooltipValue = "";

			// outstandingloanlatefees
			$this->outstandingloanlatefees->LinkCustomAttributes = "";
			$this->outstandingloanlatefees->HrefValue = "";
			$this->outstandingloanlatefees->TooltipValue = "";

			// intent
			$this->intent->LinkCustomAttributes = "";
			$this->intent->HrefValue = "";
			$this->intent->TooltipValue = "";
			if (!$this->isExport())
				$this->intent->ViewValue = $this->highlightValue($this->intent);

			// msg
			$this->msg->LinkCustomAttributes = "";
			$this->msg->HrefValue = "";
			$this->msg->TooltipValue = "";
			if (!$this->isExport())
				$this->msg->ViewValue = $this->highlightValue($this->msg);

			// infotime
			$this->infotime->LinkCustomAttributes = "";
			$this->infotime->HrefValue = "";
			$this->infotime->TooltipValue = "";
		}

		// Call Row Rendered event
		if ($this->RowType != ROWTYPE_AGGREGATEINIT)
			$this->Row_Rendered();
	}

	// Validate search
	protected function validateSearch()
	{
		global $SearchError;

		// Initialize
		$SearchError = "";

		// Check if validation required
		if (!Config("SERVER_VALIDATE"))
			return TRUE;

		// Return validate result
		$validateSearch = ($SearchError == "");

		// Call Form_CustomValidate event
		$formCustomError = "";
		$validateSearch = $validateSearch && $this->Form_CustomValidate($formCustomError);
		if ($formCustomError != "") {
			AddMessage($SearchError, $formCustomError);
		}
		return $validateSearch;
	}

	// Load advanced search
	public function loadAdvancedSearch()
	{
		$this->infoid->AdvancedSearch->load();
		$this->_userid->AdvancedSearch->load();
		$this->externalrefid->AdvancedSearch->load();
		$this->currcode->AdvancedSearch->load();
		$this->sampleloantype->AdvancedSearch->load();
		$this->sampleamount->AdvancedSearch->load();
		$this->sampleamountforfeecalculation->AdvancedSearch->load();
		$this->eligibleamount->AdvancedSearch->load();
		$this->outstandingloanprinciple->AdvancedSearch->load();
		$this->outstandingloanfees->AdvancedSearch->load();
		$this->availableforloan->AdvancedSearch->load();
		$this->status->AdvancedSearch->load();
		$this->optin->AdvancedSearch->load();
		$this->sampleloanfeespretax->AdvancedSearch->load();
		$this->feetaxpercentage->AdvancedSearch->load();
		$this->feetaxamount->AdvancedSearch->load();
		$this->sampleloanfeesposttax->AdvancedSearch->load();
		$this->feesystemtotal->AdvancedSearch->load();
		$this->feeexternaltotal->AdvancedSearch->load();
		$this->feefranchiseetotal->AdvancedSearch->load();
		$this->feeresellertotal->AdvancedSearch->load();
		$this->outstandingloan->AdvancedSearch->load();
		$this->outstandingloanlatefees->AdvancedSearch->load();
		$this->intent->AdvancedSearch->load();
		$this->msg->AdvancedSearch->load();
		$this->infotime->AdvancedSearch->load();
	}

	// Get export HTML tag
	protected function getExportTag($type, $custom = FALSE)
	{
		global $Language;
		if (SameText($type, "excel")) {
			if ($custom)
				return "<a href=\"#\" class=\"ew-export-link ew-excel\" title=\"" . HtmlEncode($Language->phrase("ExportToExcelText")) . "\" data-caption=\"" . HtmlEncode($Language->phrase("ExportToExcelText")) . "\" onclick=\"return ew.export(document.floaninfohistorylist, '" . $this->ExportExcelUrl . "', 'excel', true);\">" . $Language->phrase("ExportToExcel") . "</a>";
			else
				return "<a href=\"" . $this->ExportExcelUrl . "\" class=\"ew-export-link ew-excel\" title=\"" . HtmlEncode($Language->phrase("ExportToExcelText")) . "\" data-caption=\"" . HtmlEncode($Language->phrase("ExportToExcelText")) . "\">" . $Language->phrase("ExportToExcel") . "</a>";
		} elseif (SameText($type, "word")) {
			if ($custom)
				return "<a href=\"#\" class=\"ew-export-link ew-word\" title=\"" . HtmlEncode($Language->phrase("ExportToWordText")) . "\" data-caption=\"" . HtmlEncode($Language->phrase("ExportToWordText")) . "\" onclick=\"return ew.export(document.floaninfohistorylist, '" . $this->ExportWordUrl . "', 'word', true);\">" . $Language->phrase("ExportToWord") . "</a>";
			else
				return "<a href=\"" . $this->ExportWordUrl . "\" class=\"ew-export-link ew-word\" title=\"" . HtmlEncode($Language->phrase("ExportToWordText")) . "\" data-caption=\"" . HtmlEncode($Language->phrase("ExportToWordText")) . "\">" . $Language->phrase("ExportToWord") . "</a>";
		} elseif (SameText($type, "pdf")) {
			if ($custom)
				return "<a href=\"#\" class=\"ew-export-link ew-pdf\" title=\"" . HtmlEncode($Language->phrase("ExportToPDFText")) . "\" data-caption=\"" . HtmlEncode($Language->phrase("ExportToPDFText")) . "\" onclick=\"return ew.export(document.floaninfohistorylist, '" . $this->ExportPdfUrl . "', 'pdf', true);\">" . $Language->phrase("ExportToPDF") . "</a>";
			else
				return "<a href=\"" . $this->ExportPdfUrl . "\" class=\"ew-export-link ew-pdf\" title=\"" . HtmlEncode($Language->phrase("ExportToPDFText")) . "\" data-caption=\"" . HtmlEncode($Language->phrase("ExportToPDFText")) . "\">" . $Language->phrase("ExportToPDF") . "</a>";
		} elseif (SameText($type, "html")) {
			return "<a href=\"" . $this->ExportHtmlUrl . "\" class=\"ew-export-link ew-html\" title=\"" . HtmlEncode($Language->phrase("ExportToHtmlText")) . "\" data-caption=\"" . HtmlEncode($Language->phrase("ExportToHtmlText")) . "\">" . $Language->phrase("ExportToHtml") . "</a>";
		} elseif (SameText($type, "xml")) {
			return "<a href=\"" . $this->ExportXmlUrl . "\" class=\"ew-export-link ew-xml\" title=\"" . HtmlEncode($Language->phrase("ExportToXmlText")) . "\" data-caption=\"" . HtmlEncode($Language->phrase("ExportToXmlText")) . "\">" . $Language->phrase("ExportToXml") . "</a>";
		} elseif (SameText($type, "csv")) {
			return "<a href=\"" . $this->ExportCsvUrl . "\" class=\"ew-export-link ew-csv\" title=\"" . HtmlEncode($Language->phrase("ExportToCsvText")) . "\" data-caption=\"" . HtmlEncode($Language->phrase("ExportToCsvText")) . "\">" . $Language->phrase("ExportToCsv") . "</a>";
		} elseif (SameText($type, "email")) {
			$url = $custom ? ",url:'" . $this->pageUrl() . "export=email&amp;custom=1'" : "";
			return '<button id="emf_loaninfohistory" class="ew-export-link ew-email" title="' . $Language->phrase("ExportToEmailText") . '" data-caption="' . $Language->phrase("ExportToEmailText") . '" onclick="ew.emailDialogShow({lnk:\'emf_loaninfohistory\', hdr:ew.language.phrase(\'ExportToEmailText\'), f:document.floaninfohistorylist, sel:false' . $url . '});">' . $Language->phrase("ExportToEmail") . '</button>';
		} elseif (SameText($type, "print")) {
			return "<a href=\"" . $this->ExportPrintUrl . "\" class=\"ew-export-link ew-print\" title=\"" . HtmlEncode($Language->phrase("PrinterFriendlyText")) . "\" data-caption=\"" . HtmlEncode($Language->phrase("PrinterFriendlyText")) . "\">" . $Language->phrase("PrinterFriendly") . "</a>";
		}
	}

	// Set up export options
	protected function setupExportOptions()
	{
		global $Language;

		// Printer friendly
		$item = &$this->ExportOptions->add("print");
		$item->Body = $this->getExportTag("print");
		$item->Visible = TRUE;

		// Export to Excel
		$item = &$this->ExportOptions->add("excel");
		$item->Body = $this->getExportTag("excel");
		$item->Visible = TRUE;

		// Export to Word
		$item = &$this->ExportOptions->add("word");
		$item->Body = $this->getExportTag("word");
		$item->Visible = TRUE;

		// Export to Html
		$item = &$this->ExportOptions->add("html");
		$item->Body = $this->getExportTag("html");
		$item->Visible = TRUE;

		// Export to Xml
		$item = &$this->ExportOptions->add("xml");
		$item->Body = $this->getExportTag("xml");
		$item->Visible = FALSE;

		// Export to Csv
		$item = &$this->ExportOptions->add("csv");
		$item->Body = $this->getExportTag("csv");
		$item->Visible = TRUE;

		// Export to Pdf
		$item = &$this->ExportOptions->add("pdf");
		$item->Body = $this->getExportTag("pdf");
		$item->Visible = FALSE;

		// Export to Email
		$item = &$this->ExportOptions->add("email");
		$item->Body = $this->getExportTag("email");
		$item->Visible = TRUE;

		// Drop down button for export
		$this->ExportOptions->UseButtonGroup = TRUE;
		$this->ExportOptions->UseDropDownButton = TRUE;
		if ($this->ExportOptions->UseButtonGroup && IsMobile())
			$this->ExportOptions->UseDropDownButton = TRUE;
		$this->ExportOptions->DropDownButtonPhrase = $Language->phrase("ButtonExport");

		// Add group option item
		$item = &$this->ExportOptions->add($this->ExportOptions->GroupOptionName);
		$item->Body = "";
		$item->Visible = FALSE;
	}

	// Set up search options
	protected function setupSearchOptions()
	{
		global $Language;
		$this->SearchOptions = new ListOptions("div");
		$this->SearchOptions->TagClassName = "ew-search-option";

		// Show all button
		$item = &$this->SearchOptions->add("showall");
		$item->Body = "<a class=\"btn btn-default ew-show-all\" title=\"" . $Language->phrase("ResetSearch") . "\" data-caption=\"" . $Language->phrase("ResetSearch") . "\" href=\"" . $this->pageUrl() . "cmd=reset\">" . $Language->phrase("ResetSearchBtn") . "</a>";
		$item->Visible = ($this->SearchWhere != $this->DefaultSearchWhere && $this->SearchWhere != "0=101");

		// Advanced search button
		$item = &$this->SearchOptions->add("advancedsearch");
		$item->Body = "<a class=\"btn btn-default ew-advanced-search\" title=\"" . $Language->phrase("AdvancedSearch") . "\" data-caption=\"" . $Language->phrase("AdvancedSearch") . "\" href=\"loaninfohistorysrch.php\">" . $Language->phrase("AdvancedSearchBtn") . "</a>";
		$item->Visible = TRUE;

		// Search highlight button
		$item = &$this->SearchOptions->add("searchhighlight");
		$item->Body = "<a class=\"btn btn-default ew-highlight active\" href=\"#\" role=\"button\" title=\"" . $Language->phrase("Highlight") . "\" data-caption=\"" . $Language->phrase("Highlight") . "\" data-toggle=\"button\" data-form=\"floaninfohistorylistsrch\" data-name=\"" . $this->highlightName() . "\">" . $Language->phrase("HighlightBtn") . "</a>";
		$item->Visible = ($this->SearchWhere != "" && $this->TotalRecords > 0);

		// Button group for search
		$this->SearchOptions->UseDropDownButton = FALSE;
		$this->SearchOptions->UseButtonGroup = TRUE;
		$this->SearchOptions->DropDownButtonPhrase = $Language->phrase("ButtonSearch");

		// Add group option item
		$item = &$this->SearchOptions->add($this->SearchOptions->GroupOptionName);
		$item->Body = "";
		$item->Visible = FALSE;

		// Hide search options
		if ($this->isExport() || $this->CurrentAction)
			$this->SearchOptions->hideAllOptions();
		global $Security;
		if (!$Security->canSearch()) {
			$this->SearchOptions->hideAllOptions();
			$this->FilterOptions->hideAllOptions();
		}
	}

	/**
	 * Export data in HTML/CSV/Word/Excel/XML/Email/PDF format
	 *
	 * @param boolean $return Return the data rather than output it
	 * @return mixed
	 */
	public function exportData($return = FALSE)
	{
		global $Language;
		$utf8 = SameText(Config("PROJECT_CHARSET"), "utf-8");
		$selectLimit = $this->UseSelectLimit;

		// Load recordset
		if ($selectLimit) {
			$this->TotalRecords = $this->listRecordCount();
		} else {
			if (!$this->Recordset)
				$this->Recordset = $this->loadRecordset();
			$rs = &$this->Recordset;
			if ($rs)
				$this->TotalRecords = $rs->RecordCount();
		}
		$this->StartRecord = 1;

		// Export all
		if ($this->ExportAll) {
			set_time_limit(Config("EXPORT_ALL_TIME_LIMIT"));
			$this->DisplayRecords = $this->TotalRecords;
			$this->StopRecord = $this->TotalRecords;
		} else { // Export one page only
			$this->setupStartRecord(); // Set up start record position

			// Set the last record to display
			if ($this->DisplayRecords <= 0) {
				$this->StopRecord = $this->TotalRecords;
			} else {
				$this->StopRecord = $this->StartRecord + $this->DisplayRecords - 1;
			}
		}
		if ($selectLimit)
			$rs = $this->loadRecordset($this->StartRecord - 1, $this->DisplayRecords <= 0 ? $this->TotalRecords : $this->DisplayRecords);
		$this->ExportDoc = GetExportDocument($this, "h");
		$doc = &$this->ExportDoc;
		if (!$doc)
			$this->setFailureMessage($Language->phrase("ExportClassNotFound")); // Export class not found
		if (!$rs || !$doc) {
			RemoveHeader("Content-Type"); // Remove header
			RemoveHeader("Content-Disposition");
			$this->showMessage();
			return;
		}
		if ($selectLimit) {
			$this->StartRecord = 1;
			$this->StopRecord = $this->DisplayRecords <= 0 ? $this->TotalRecords : $this->DisplayRecords;
		}

		// Call Page Exporting server event
		$this->ExportDoc->ExportCustom = !$this->Page_Exporting();
		$header = $this->PageHeader;
		$this->Page_DataRendering($header);
		$doc->Text .= $header;
		$this->exportDocument($doc, $rs, $this->StartRecord, $this->StopRecord, "");
		$footer = $this->PageFooter;
		$this->Page_DataRendered($footer);
		$doc->Text .= $footer;

		// Close recordset
		$rs->close();

		// Call Page Exported server event
		$this->Page_Exported();

		// Export header and footer
		$doc->exportHeaderAndFooter();

		// Clean output buffer (without destroying output buffer)
		$buffer = ob_get_contents(); // Save the output buffer
		if (!Config("DEBUG") && $buffer)
			ob_clean();

		// Write debug message if enabled
		if (Config("DEBUG") && !$this->isExport("pdf"))
			echo GetDebugMessage();

		// Output data
		if ($this->isExport("email")) {
			if ($return)
				return $doc->Text; // Return email content
			else
				echo $this->exportEmail($doc->Text); // Send email
		} else {
			$doc->export();
			if ($return) {
				RemoveHeader("Content-Type"); // Remove header
				RemoveHeader("Content-Disposition");
				$content = ob_get_contents();
				if ($content)
					ob_clean();
				if ($buffer)
					echo $buffer; // Resume the output buffer
				return $content;
			}
		}
	}

	// Export email
	protected function exportEmail($emailContent)
	{
		global $TempImages, $Language;
		$sender = Post("sender", "");
		$recipient = Post("recipient", "");
		$cc = Post("cc", "");
		$bcc = Post("bcc", "");

		// Subject
		$subject = Post("subject", "");
		$emailSubject = $subject;

		// Message
		$content = Post("message", "");
		$emailMessage = $content;

		// Check sender
		if ($sender == "") {
			return "<p class=\"text-danger\">" . $Language->phrase("EnterSenderEmail") . "</p>";
		}
		if (!CheckEmail($sender)) {
			return "<p class=\"text-danger\">" . $Language->phrase("EnterProperSenderEmail") . "</p>";
		}

		// Check recipient
		if (!CheckEmailList($recipient, Config("MAX_EMAIL_RECIPIENT"))) {
			return "<p class=\"text-danger\">" . $Language->phrase("EnterProperRecipientEmail") . "</p>";
		}

		// Check cc
		if (!CheckEmailList($cc, Config("MAX_EMAIL_RECIPIENT"))) {
			return "<p class=\"text-danger\">" . $Language->phrase("EnterProperCcEmail") . "</p>";
		}

		// Check bcc
		if (!CheckEmailList($bcc, Config("MAX_EMAIL_RECIPIENT"))) {
			return "<p class=\"text-danger\">" . $Language->phrase("EnterProperBccEmail") . "</p>";
		}

		// Check email sent count
		if (!isset($_SESSION[Config("EXPORT_EMAIL_COUNTER")]))
			$_SESSION[Config("EXPORT_EMAIL_COUNTER")] = 0;
		if ((int)$_SESSION[Config("EXPORT_EMAIL_COUNTER")] > Config("MAX_EMAIL_SENT_COUNT")) {
			return "<p class=\"text-danger\">" . $Language->phrase("ExceedMaxEmailExport") . "</p>";
		}

		// Send email
		$email = new Email();
		$email->Sender = $sender; // Sender
		$email->Recipient = $recipient; // Recipient
		$email->Cc = $cc; // Cc
		$email->Bcc = $bcc; // Bcc
		$email->Subject = $emailSubject; // Subject
		$email->Format = "html";
		if ($emailMessage != "")
			$emailMessage = RemoveXss($emailMessage) . "<br><br>";
		foreach ($TempImages as $tmpImage)
			$email->addEmbeddedImage($tmpImage);
		$email->Content = $emailMessage . CleanEmailContent($emailContent); // Content
		$eventArgs = [];
		if ($this->Recordset)
			$eventArgs["rs"] = &$this->Recordset;
		$emailSent = FALSE;
		if ($this->Email_Sending($email, $eventArgs))
			$emailSent = $email->send();

		// Check email sent status
		if ($emailSent) {

			// Update email sent count
			$_SESSION[Config("EXPORT_EMAIL_COUNTER")]++;

			// Sent email success
			return "<p class=\"text-success\">" . $Language->phrase("SendEmailSuccess") . "</p>"; // Set up success message
		} else {

			// Sent email failure
			return "<p class=\"text-danger\">" . $email->SendErrDescription . "</p>";
		}
	}

	// Set up Breadcrumb
	protected function setupBreadcrumb()
	{
		global $Breadcrumb, $Language;
		$Breadcrumb = new Breadcrumb();
		$url = substr(CurrentUrl(), strrpos(CurrentUrl(), "/")+1);
		$url = preg_replace('/\?cmd=reset(all){0,1}$/i', '', $url); // Remove cmd=reset / cmd=resetall
		$Breadcrumb->add("list", $this->TableVar, $url, "", $this->TableVar, TRUE);
	}

	// Setup lookup options
	public function setupLookupOptions($fld)
	{
		if ($fld->Lookup !== NULL && $fld->Lookup->Options === NULL) {

			// Get default connection and filter
			$conn = $this->getConnection();
			$lookupFilter = "";

			// No need to check any more
			$fld->Lookup->Options = [];

			// Set up lookup SQL and connection
			switch ($fld->FieldVar) {
				default:
					$lookupFilter = "";
					break;
			}

			// Always call to Lookup->getSql so that user can setup Lookup->Options in Lookup_Selecting server event
			$sql = $fld->Lookup->getSql(FALSE, "", $lookupFilter, $this);

			// Set up lookup cache
			if ($fld->UseLookupCache && $sql != "" && count($fld->Lookup->Options) == 0) {
				$totalCnt = $this->getRecordCount($sql, $conn);
				if ($totalCnt > $fld->LookupCacheCount) // Total count > cache count, do not cache
					return;
				$rs = $conn->execute($sql);
				$ar = [];
				while ($rs && !$rs->EOF) {
					$row = &$rs->fields;

					// Format the field values
					switch ($fld->FieldVar) {
					}
					$ar[strval($row[0])] = $row;
					$rs->moveNext();
				}
				if ($rs)
					$rs->close();
				$fld->Lookup->Options = $ar;
			}
		}
	}

	// Set up starting record parameters
	public function setupStartRecord()
	{
		if ($this->DisplayRecords == 0)
			return;
		if ($this->isPageRequest()) { // Validate request
			$startRec = Get(Config("TABLE_START_REC"));
			$pageNo = Get(Config("TABLE_PAGE_NO"));
			if ($pageNo !== NULL) { // Check for "pageno" parameter first
				if (is_numeric($pageNo)) {
					$this->StartRecord = ($pageNo - 1) * $this->DisplayRecords + 1;
					if ($this->StartRecord <= 0) {
						$this->StartRecord = 1;
					} elseif ($this->StartRecord >= (int)(($this->TotalRecords - 1)/$this->DisplayRecords) * $this->DisplayRecords + 1) {
						$this->StartRecord = (int)(($this->TotalRecords - 1)/$this->DisplayRecords) * $this->DisplayRecords + 1;
					}
					$this->setStartRecordNumber($this->StartRecord);
				}
			} elseif ($startRec !== NULL) { // Check for "start" parameter
				$this->StartRecord = $startRec;
				$this->setStartRecordNumber($this->StartRecord);
			}
		}
		$this->StartRecord = $this->getStartRecordNumber();

		// Check if correct start record counter
		if (!is_numeric($this->StartRecord) || $this->StartRecord == "") { // Avoid invalid start record counter
			$this->StartRecord = 1; // Reset start record counter
			$this->setStartRecordNumber($this->StartRecord);
		} elseif ($this->StartRecord > $this->TotalRecords) { // Avoid starting record > total records
			$this->StartRecord = (int)(($this->TotalRecords - 1)/$this->DisplayRecords) * $this->DisplayRecords + 1; // Point to last page first record
			$this->setStartRecordNumber($this->StartRecord);
		} elseif (($this->StartRecord - 1) % $this->DisplayRecords != 0) {
			$this->StartRecord = (int)(($this->StartRecord - 1)/$this->DisplayRecords) * $this->DisplayRecords + 1; // Point to page boundary
			$this->setStartRecordNumber($this->StartRecord);
		}
	}

	// Page Load event
	function Page_Load() {

		//echo "Page Load";
	}

	// Page Unload event
	function Page_Unload() {

		//echo "Page Unload";
	}

	// Page Redirecting event
	function Page_Redirecting(&$url) {

		// Example:
		//$url = "your URL";

	}

	// Message Showing event
	// $type = ''|'success'|'failure'|'warning'
	function Message_Showing(&$msg, $type) {
		if ($type == 'success') {

			//$msg = "your success message";
		} elseif ($type == 'failure') {

			//$msg = "your failure message";
		} elseif ($type == 'warning') {

			//$msg = "your warning message";
		} else {

			//$msg = "your message";
		}
	}

	// Page Render event
	function Page_Render() {

		//echo "Page Render";
	}

	// Page Data Rendering event
	function Page_DataRendering(&$header) {

		// Example:
		//$header = "your header";

	}

	// Page Data Rendered event
	function Page_DataRendered(&$footer) {

		// Example:
		//$footer = "your footer";

	}

	// Form Custom Validate event
	function Form_CustomValidate(&$customError) {

		// Return error message in CustomError
		return TRUE;
	}

	// ListOptions Load event
	function ListOptions_Load() {

		// Example:
		//$opt = &$this->ListOptions->Add("new");
		//$opt->Header = "xxx";
		//$opt->OnLeft = TRUE; // Link on left
		//$opt->MoveTo(0); // Move to first column

	}

	// ListOptions Rendering event
	function ListOptions_Rendering() {

		//$GLOBALS["xxx_grid"]->DetailAdd = (...condition...); // Set to TRUE or FALSE conditionally
		//$GLOBALS["xxx_grid"]->DetailEdit = (...condition...); // Set to TRUE or FALSE conditionally
		//$GLOBALS["xxx_grid"]->DetailView = (...condition...); // Set to TRUE or FALSE conditionally

	}

	// ListOptions Rendered event
	function ListOptions_Rendered() {

		// Example:
		//$this->ListOptions["new"]->Body = "xxx";

	}

	// Row Custom Action event
	function Row_CustomAction($action, $row) {

		// Return FALSE to abort
		return TRUE;
	}

	// Page Exporting event
	// $this->ExportDoc = export document object
	function Page_Exporting() {

		//$this->ExportDoc->Text = "my header"; // Export header
		//return FALSE; // Return FALSE to skip default export and use Row_Export event

		return TRUE; // Return TRUE to use default export and skip Row_Export event
	}

	// Row Export event
	// $this->ExportDoc = export document object
	function Row_Export($rs) {

		//$this->ExportDoc->Text .= "my content"; // Build HTML with field value: $rs["MyField"] or $this->MyField->ViewValue
	}

	// Page Exported event
	// $this->ExportDoc = export document object
	function Page_Exported() {

		//$this->ExportDoc->Text .= "my footer"; // Export footer
		//echo $this->ExportDoc->Text;

	}

	// Page Importing event
	function Page_Importing($reader, &$options) {

		//var_dump($reader); // Import data reader
		//var_dump($options); // Show all options for importing
		//return FALSE; // Return FALSE to skip import

		return TRUE;
	}

	// Row Import event
	function Row_Import(&$row, $cnt) {

		//echo $cnt; // Import record count
		//var_dump($row); // Import row
		//return FALSE; // Return FALSE to skip import

		return TRUE;
	}

	// Page Imported event
	function Page_Imported($reader, $results) {

		//var_dump($reader); // Import data reader
		//var_dump($results); // Import results

	}
} // End class
?>