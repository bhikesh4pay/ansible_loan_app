<?php
namespace PHPMaker2020\_4payadmin;

/**
 * Page class
 */
class purchaseorder_add extends purchaseorder
{

	// Page ID
	public $PageID = "add";

	// Project ID
	public $ProjectID = "{153C2D2E-60EE-4944-8753-3935EB38E8D6}";

	// Table name
	public $TableName = 'purchaseorder';

	// Page object name
	public $PageObjName = "purchaseorder_add";

	// Audit Trail
	public $AuditTrailOnAdd = TRUE;
	public $AuditTrailOnEdit = TRUE;
	public $AuditTrailOnDelete = TRUE;
	public $AuditTrailOnView = FALSE;
	public $AuditTrailOnViewData = FALSE;
	public $AuditTrailOnSearch = FALSE;

	// Page headings
	public $Heading = "";
	public $Subheading = "";
	public $PageHeader;
	public $PageFooter;

	// Token
	public $Token = "";
	public $TokenTimeout = 0;
	public $CheckToken;

	// Page heading
	public function pageHeading()
	{
		global $Language;
		if ($this->Heading != "")
			return $this->Heading;
		if (method_exists($this, "tableCaption"))
			return $this->tableCaption();
		return "";
	}

	// Page subheading
	public function pageSubheading()
	{
		global $Language;
		if ($this->Subheading != "")
			return $this->Subheading;
		if ($this->TableName)
			return $Language->phrase($this->PageID);
		return "";
	}

	// Page name
	public function pageName()
	{
		return CurrentPageName();
	}

	// Page URL
	public function pageUrl()
	{
		$url = CurrentPageName() . "?";
		if ($this->UseTokenInUrl)
			$url .= "t=" . $this->TableVar . "&"; // Add page token
		return $url;
	}

	// Messages
	private $_message = "";
	private $_failureMessage = "";
	private $_successMessage = "";
	private $_warningMessage = "";

	// Get message
	public function getMessage()
	{
		return isset($_SESSION[SESSION_MESSAGE]) ? $_SESSION[SESSION_MESSAGE] : $this->_message;
	}

	// Set message
	public function setMessage($v)
	{
		AddMessage($this->_message, $v);
		$_SESSION[SESSION_MESSAGE] = $this->_message;
	}

	// Get failure message
	public function getFailureMessage()
	{
		return isset($_SESSION[SESSION_FAILURE_MESSAGE]) ? $_SESSION[SESSION_FAILURE_MESSAGE] : $this->_failureMessage;
	}

	// Set failure message
	public function setFailureMessage($v)
	{
		AddMessage($this->_failureMessage, $v);
		$_SESSION[SESSION_FAILURE_MESSAGE] = $this->_failureMessage;
	}

	// Get success message
	public function getSuccessMessage()
	{
		return isset($_SESSION[SESSION_SUCCESS_MESSAGE]) ? $_SESSION[SESSION_SUCCESS_MESSAGE] : $this->_successMessage;
	}

	// Set success message
	public function setSuccessMessage($v)
	{
		AddMessage($this->_successMessage, $v);
		$_SESSION[SESSION_SUCCESS_MESSAGE] = $this->_successMessage;
	}

	// Get warning message
	public function getWarningMessage()
	{
		return isset($_SESSION[SESSION_WARNING_MESSAGE]) ? $_SESSION[SESSION_WARNING_MESSAGE] : $this->_warningMessage;
	}

	// Set warning message
	public function setWarningMessage($v)
	{
		AddMessage($this->_warningMessage, $v);
		$_SESSION[SESSION_WARNING_MESSAGE] = $this->_warningMessage;
	}

	// Clear message
	public function clearMessage()
	{
		$this->_message = "";
		$_SESSION[SESSION_MESSAGE] = "";
	}

	// Clear failure message
	public function clearFailureMessage()
	{
		$this->_failureMessage = "";
		$_SESSION[SESSION_FAILURE_MESSAGE] = "";
	}

	// Clear success message
	public function clearSuccessMessage()
	{
		$this->_successMessage = "";
		$_SESSION[SESSION_SUCCESS_MESSAGE] = "";
	}

	// Clear warning message
	public function clearWarningMessage()
	{
		$this->_warningMessage = "";
		$_SESSION[SESSION_WARNING_MESSAGE] = "";
	}

	// Clear messages
	public function clearMessages()
	{
		$this->clearMessage();
		$this->clearFailureMessage();
		$this->clearSuccessMessage();
		$this->clearWarningMessage();
	}

	// Show message
	public function showMessage()
	{
		$hidden = FALSE;
		$html = "";

		// Message
		$message = $this->getMessage();
		if (method_exists($this, "Message_Showing"))
			$this->Message_Showing($message, "");
		if ($message != "") { // Message in Session, display
			if (!$hidden)
				$message = '<button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button>' . $message;
			$html .= '<div class="alert alert-info alert-dismissible ew-info"><i class="icon fas fa-info"></i>' . $message . '</div>';
			$_SESSION[SESSION_MESSAGE] = ""; // Clear message in Session
		}

		// Warning message
		$warningMessage = $this->getWarningMessage();
		if (method_exists($this, "Message_Showing"))
			$this->Message_Showing($warningMessage, "warning");
		if ($warningMessage != "") { // Message in Session, display
			if (!$hidden)
				$warningMessage = '<button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button>' . $warningMessage;
			$html .= '<div class="alert alert-warning alert-dismissible ew-warning"><i class="icon fas fa-exclamation"></i>' . $warningMessage . '</div>';
			$_SESSION[SESSION_WARNING_MESSAGE] = ""; // Clear message in Session
		}

		// Success message
		$successMessage = $this->getSuccessMessage();
		if (method_exists($this, "Message_Showing"))
			$this->Message_Showing($successMessage, "success");
		if ($successMessage != "") { // Message in Session, display
			if (!$hidden)
				$successMessage = '<button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button>' . $successMessage;
			$html .= '<div class="alert alert-success alert-dismissible ew-success"><i class="icon fas fa-check"></i>' . $successMessage . '</div>';
			$_SESSION[SESSION_SUCCESS_MESSAGE] = ""; // Clear message in Session
		}

		// Failure message
		$errorMessage = $this->getFailureMessage();
		if (method_exists($this, "Message_Showing"))
			$this->Message_Showing($errorMessage, "failure");
		if ($errorMessage != "") { // Message in Session, display
			if (!$hidden)
				$errorMessage = '<button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button>' . $errorMessage;
			$html .= '<div class="alert alert-danger alert-dismissible ew-error"><i class="icon fas fa-ban"></i>' . $errorMessage . '</div>';
			$_SESSION[SESSION_FAILURE_MESSAGE] = ""; // Clear message in Session
		}
		echo '<div class="ew-message-dialog' . (($hidden) ? ' d-none' : "") . '">' . $html . '</div>';
	}

	// Get message as array
	public function getMessages()
	{
		$ar = [];

		// Message
		$message = $this->getMessage();

		//if (method_exists($this, "Message_Showing"))
		//	$this->Message_Showing($message, "");

		if ($message != "") { // Message in Session, display
			$ar["message"] = $message;
			$_SESSION[SESSION_MESSAGE] = ""; // Clear message in Session
		}

		// Warning message
		$warningMessage = $this->getWarningMessage();

		//if (method_exists($this, "Message_Showing"))
		//	$this->Message_Showing($warningMessage, "warning");

		if ($warningMessage != "") { // Message in Session, display
			$ar["warningMessage"] = $warningMessage;
			$_SESSION[SESSION_WARNING_MESSAGE] = ""; // Clear message in Session
		}

		// Success message
		$successMessage = $this->getSuccessMessage();

		//if (method_exists($this, "Message_Showing"))
		//	$this->Message_Showing($successMessage, "success");

		if ($successMessage != "") { // Message in Session, display
			$ar["successMessage"] = $successMessage;
			$_SESSION[SESSION_SUCCESS_MESSAGE] = ""; // Clear message in Session
		}

		// Failure message
		$failureMessage = $this->getFailureMessage();

		//if (method_exists($this, "Message_Showing"))
		//	$this->Message_Showing($failureMessage, "failure");

		if ($failureMessage != "") { // Message in Session, display
			$ar["failureMessage"] = $failureMessage;
			$_SESSION[SESSION_FAILURE_MESSAGE] = ""; // Clear message in Session
		}
		return $ar;
	}

	// Show Page Header
	public function showPageHeader()
	{
		$header = $this->PageHeader;
		$this->Page_DataRendering($header);
		if ($header != "") { // Header exists, display
			echo '<p id="ew-page-header">' . $header . '</p>';
		}
	}

	// Show Page Footer
	public function showPageFooter()
	{
		$footer = $this->PageFooter;
		$this->Page_DataRendered($footer);
		if ($footer != "") { // Footer exists, display
			echo '<p id="ew-page-footer">' . $footer . '</p>';
		}
	}

	// Validate page request
	protected function isPageRequest()
	{
		global $CurrentForm;
		if ($this->UseTokenInUrl) {
			if ($CurrentForm)
				return ($this->TableVar == $CurrentForm->getValue("t"));
			if (Get("t") !== NULL)
				return ($this->TableVar == Get("t"));
		}
		return TRUE;
	}

	// Valid Post
	protected function validPost()
	{
		if (!$this->CheckToken || !IsPost() || IsApi())
			return TRUE;
		if (Post(Config("TOKEN_NAME")) === NULL)
			return FALSE;
		$fn = Config("CHECK_TOKEN_FUNC");
		if (is_callable($fn))
			return $fn(Post(Config("TOKEN_NAME")), $this->TokenTimeout);
		return FALSE;
	}

	// Create Token
	public function createToken()
	{
		global $CurrentToken;
		$fn = Config("CREATE_TOKEN_FUNC"); // Always create token, required by API file/lookup request
		if ($this->Token == "" && is_callable($fn)) // Create token
			$this->Token = $fn();
		$CurrentToken = $this->Token; // Save to global variable
	}

	// Constructor
	public function __construct()
	{
		global $Language, $DashboardReport;
		global $UserTable;

		// Check token
		$this->CheckToken = Config("CHECK_TOKEN");

		// Initialize
		$GLOBALS["Page"] = &$this;
		$this->TokenTimeout = SessionTimeoutTime();

		// Language object
		if (!isset($Language))
			$Language = new Language();

		// Parent constuctor
		parent::__construct();

		// Table object (purchaseorder)
		if (!isset($GLOBALS["purchaseorder"]) || get_class($GLOBALS["purchaseorder"]) == PROJECT_NAMESPACE . "purchaseorder") {
			$GLOBALS["purchaseorder"] = &$this;
			$GLOBALS["Table"] = &$GLOBALS["purchaseorder"];
		}

		// Table object (admin)
		if (!isset($GLOBALS['admin']))
			$GLOBALS['admin'] = new admin();

		// Page ID (for backward compatibility only)
		if (!defined(PROJECT_NAMESPACE . "PAGE_ID"))
			define(PROJECT_NAMESPACE . "PAGE_ID", 'add');

		// Table name (for backward compatibility only)
		if (!defined(PROJECT_NAMESPACE . "TABLE_NAME"))
			define(PROJECT_NAMESPACE . "TABLE_NAME", 'purchaseorder');

		// Start timer
		if (!isset($GLOBALS["DebugTimer"]))
			$GLOBALS["DebugTimer"] = new Timer();

		// Debug message
		LoadDebugMessage();

		// Open connection
		if (!isset($GLOBALS["Conn"]))
			$GLOBALS["Conn"] = $this->getConnection();

		// User table object (admin)
		$UserTable = $UserTable ?: new admin();
	}

	// Terminate page
	public function terminate($url = "")
	{
		global $ExportFileName, $TempImages, $DashboardReport;

		// Page Unload event
		$this->Page_Unload();

		// Global Page Unloaded event (in userfn*.php)
		Page_Unloaded();

		// Export
		global $purchaseorder;
		if ($this->CustomExport && $this->CustomExport == $this->Export && array_key_exists($this->CustomExport, Config("EXPORT_CLASSES"))) {
				$content = ob_get_contents();
			if ($ExportFileName == "")
				$ExportFileName = $this->TableVar;
			$class = PROJECT_NAMESPACE . Config("EXPORT_CLASSES." . $this->CustomExport);
			if (class_exists($class)) {
				$doc = new $class($purchaseorder);
				$doc->Text = @$content;
				if ($this->isExport("email"))
					echo $this->exportEmail($doc->Text);
				else
					$doc->export();
				DeleteTempImages(); // Delete temp images
				exit();
			}
		}
		if (!IsApi())
			$this->Page_Redirecting($url);

		// Close connection
		CloseConnections();

		// Return for API
		if (IsApi()) {
			$res = $url === TRUE;
			if (!$res) // Show error
				WriteJson(array_merge(["success" => FALSE], $this->getMessages()));
			return;
		}

		// Go to URL if specified
		if ($url != "") {
			if (!Config("DEBUG") && ob_get_length())
				ob_end_clean();

			// Handle modal response
			if ($this->IsModal) { // Show as modal
				$row = ["url" => $url, "modal" => "1"];
				$pageName = GetPageName($url);
				if ($pageName != $this->getListUrl()) { // Not List page
					$row["caption"] = $this->getModalCaption($pageName);
					if ($pageName == "purchaseorderview.php")
						$row["view"] = "1";
				} else { // List page should not be shown as modal => error
					$row["error"] = $this->getFailureMessage();
					$this->clearFailureMessage();
				}
				WriteJson($row);
			} else {
				SaveDebugMessage();
				AddHeader("Location", $url);
			}
		}
		exit();
	}

	// Get records from recordset
	protected function getRecordsFromRecordset($rs, $current = FALSE)
	{
		$rows = [];
		if (is_object($rs)) { // Recordset
			while ($rs && !$rs->EOF) {
				$this->loadRowValues($rs); // Set up DbValue/CurrentValue
				$row = $this->getRecordFromArray($rs->fields);
				if ($current)
					return $row;
				else
					$rows[] = $row;
				$rs->moveNext();
			}
		} elseif (is_array($rs)) {
			foreach ($rs as $ar) {
				$row = $this->getRecordFromArray($ar);
				if ($current)
					return $row;
				else
					$rows[] = $row;
			}
		}
		return $rows;
	}

	// Get record from array
	protected function getRecordFromArray($ar)
	{
		$row = [];
		if (is_array($ar)) {
			foreach ($ar as $fldname => $val) {
				if (array_key_exists($fldname, $this->fields) && ($this->fields[$fldname]->Visible || $this->fields[$fldname]->IsPrimaryKey)) { // Primary key or Visible
					$fld = &$this->fields[$fldname];
					if ($fld->HtmlTag == "FILE") { // Upload field
						if (EmptyValue($val)) {
							$row[$fldname] = NULL;
						} else {
							if ($fld->DataType == DATATYPE_BLOB) {
								$url = FullUrl(GetApiUrl(Config("API_FILE_ACTION"),
									Config("API_OBJECT_NAME") . "=" . $fld->TableVar . "&" .
									Config("API_FIELD_NAME") . "=" . $fld->Param . "&" .
									Config("API_KEY_NAME") . "=" . rawurlencode($this->getRecordKeyValue($ar)))); //*** need to add this? API may not be in the same folder
								$row[$fldname] = ["type" => ContentType($val), "url" => $url, "name" => $fld->Param . ContentExtension($val)];
							} elseif (!$fld->UploadMultiple || !ContainsString($val, Config("MULTIPLE_UPLOAD_SEPARATOR"))) { // Single file
								$url = FullUrl(GetApiUrl(Config("API_FILE_ACTION"),
									Config("API_OBJECT_NAME") . "=" . $fld->TableVar . "&" .
									"fn=" . Encrypt($fld->physicalUploadPath() . $val)));
								$row[$fldname] = ["type" => MimeContentType($val), "url" => $url, "name" => $val];
							} else { // Multiple files
								$files = explode(Config("MULTIPLE_UPLOAD_SEPARATOR"), $val);
								$ar = [];
								foreach ($files as $file) {
									$url = FullUrl(GetApiUrl(Config("API_FILE_ACTION"),
										Config("API_OBJECT_NAME") . "=" . $fld->TableVar . "&" .
										"fn=" . Encrypt($fld->physicalUploadPath() . $file)));
									if (!EmptyValue($file))
										$ar[] = ["type" => MimeContentType($file), "url" => $url, "name" => $file];
								}
								$row[$fldname] = $ar;
							}
						}
					} else {
						$row[$fldname] = $val;
					}
				}
			}
		}
		return $row;
	}

	// Get record key value from array
	protected function getRecordKeyValue($ar)
	{
		$key = "";
		if (is_array($ar)) {
			$key .= @$ar['poid'];
		}
		return $key;
	}

	/**
	 * Hide fields for add/edit
	 *
	 * @return void
	 */
	protected function hideFieldsForAddEdit()
	{
		if ($this->isAdd() || $this->isCopy() || $this->isGridAdd())
			$this->poid->Visible = FALSE;
	}

	// Lookup data
	public function lookup()
	{
		global $Language, $Security;
		if (!isset($Language))
			$Language = new Language(Config("LANGUAGE_FOLDER"), Post("language", ""));

		// Set up API request
		if (!ValidApiRequest())
			return FALSE;
		$this->setupApiSecurity();

		// Get lookup object
		$fieldName = Post("field");
		if (!array_key_exists($fieldName, $this->fields))
			return FALSE;
		$lookupField = $this->fields[$fieldName];
		$lookup = $lookupField->Lookup;
		if ($lookup === NULL)
			return FALSE;
		$tbl = $lookup->getTable();
		if (!$Security->allowLookup(Config("PROJECT_ID") . $tbl->TableName)) // Lookup permission
			return FALSE;

		// Get lookup parameters
		$lookupType = Post("ajax", "unknown");
		$pageSize = -1;
		$offset = -1;
		$searchValue = "";
		if (SameText($lookupType, "modal")) {
			$searchValue = Post("sv", "");
			$pageSize = Post("recperpage", 10);
			$offset = Post("start", 0);
		} elseif (SameText($lookupType, "autosuggest")) {
			$searchValue = Param("q", "");
			$pageSize = Param("n", -1);
			$pageSize = is_numeric($pageSize) ? (int)$pageSize : -1;
			if ($pageSize <= 0)
				$pageSize = Config("AUTO_SUGGEST_MAX_ENTRIES");
			$start = Param("start", -1);
			$start = is_numeric($start) ? (int)$start : -1;
			$page = Param("page", -1);
			$page = is_numeric($page) ? (int)$page : -1;
			$offset = $start >= 0 ? $start : ($page > 0 && $pageSize > 0 ? ($page - 1) * $pageSize : 0);
		}
		$userSelect = Decrypt(Post("s", ""));
		$userFilter = Decrypt(Post("f", ""));
		$userOrderBy = Decrypt(Post("o", ""));
		$keys = Post("keys");
		$lookup->LookupType = $lookupType; // Lookup type
		if ($keys !== NULL) { // Selected records from modal
			if (is_array($keys))
				$keys = implode(Config("MULTIPLE_OPTION_SEPARATOR"), $keys);
			$lookup->FilterFields = []; // Skip parent fields if any
			$lookup->FilterValues[] = $keys; // Lookup values
			$pageSize = -1; // Show all records
		} else { // Lookup values
			$lookup->FilterValues[] = Post("v0", Post("lookupValue", ""));
		}
		$cnt = is_array($lookup->FilterFields) ? count($lookup->FilterFields) : 0;
		for ($i = 1; $i <= $cnt; $i++)
			$lookup->FilterValues[] = Post("v" . $i, "");
		$lookup->SearchValue = $searchValue;
		$lookup->PageSize = $pageSize;
		$lookup->Offset = $offset;
		if ($userSelect != "")
			$lookup->UserSelect = $userSelect;
		if ($userFilter != "")
			$lookup->UserFilter = $userFilter;
		if ($userOrderBy != "")
			$lookup->UserOrderBy = $userOrderBy;
		$lookup->toJson($this); // Use settings from current page
	}

	// Set up API security
	public function setupApiSecurity()
	{
		global $Security;

		// Setup security for API request
		if ($Security->isLoggedIn()) $Security->TablePermission_Loading();
		$Security->loadCurrentUserLevel(Config("PROJECT_ID") . $this->TableName);
		if ($Security->isLoggedIn()) $Security->TablePermission_Loaded();
	}
	public $FormClassName = "ew-horizontal ew-form ew-add-form";
	public $IsModal = FALSE;
	public $IsMobileOrModal = FALSE;
	public $DbMasterFilter = "";
	public $DbDetailFilter = "";
	public $StartRecord;
	public $Priv = 0;
	public $OldRecordset;
	public $CopyRecord;

	//
	// Page run
	//

	public function run()
	{
		global $ExportType, $CustomExportType, $ExportFileName, $UserProfile, $Language, $Security, $CurrentForm,
			$FormError, $SkipHeaderFooter;

		// Is modal
		$this->IsModal = (Param("modal") == "1");

		// User profile
		$UserProfile = new UserProfile();

		// Security
		if (ValidApiRequest()) { // API request
			$this->setupApiSecurity(); // Set up API Security
			if (!$Security->canAdd()) {
				SetStatus(401); // Unauthorized
				return;
			}
		} else {
			$Security = new AdvancedSecurity();
			if (IsPasswordExpired())
				$this->terminate(GetUrl("changepwd.php"));
			if (!$Security->isLoggedIn())
				$Security->autoLogin();
			if ($Security->isLoggedIn())
				$Security->TablePermission_Loading();
			$Security->loadCurrentUserLevel($this->ProjectID . $this->TableName);
			if ($Security->isLoggedIn())
				$Security->TablePermission_Loaded();
			if (!$Security->canAdd()) {
				$Security->saveLastUrl();
				$this->setFailureMessage(DeniedMessage()); // Set no permission
				if ($Security->canList())
					$this->terminate(GetUrl("purchaseorderlist.php"));
				else
					$this->terminate(GetUrl("login.php"));
				return;
			}
		}

		// Create form object
		$CurrentForm = new HttpForm();
		$this->CurrentAction = Param("action"); // Set up current action
		$this->poid->Visible = FALSE;
		$this->txid->setVisibility();
		$this->merchantID->setVisibility();
		$this->_userID->setVisibility();
		$this->transferTime->setVisibility();
		$this->merchantSurcharge->setVisibility();
		$this->currID->setVisibility();
		$this->purchaseAmount->setVisibility();
		$this->taxAmount->setVisibility();
		$this->tipAmount->setVisibility();
		$this->serviceFeeToCustomer->setVisibility();
		$this->TotalAmountForCustomer->setVisibility();
		$this->serviceFeeToMerchant->setVisibility();
		$this->status->setVisibility();
		$this->shoppingCartID->setVisibility();
		$this->merchantRefID->setVisibility();
		$this->feeid->setVisibility();
		$this->ratetabletype->setVisibility();
		$this->userpi->setVisibility();
		$this->piid->setVisibility();
		$this->feesystemshare->setVisibility();
		$this->feeexternalshare->setVisibility();
		$this->feefranchiseeshare->setVisibility();
		$this->feeresellershare->setVisibility();
		$this->lastupdatetime->setVisibility();
		$this->expirationTimeInMinutes->setVisibility();
		$this->expirationTime->setVisibility();
		$this->itemdesc->setVisibility();
		$this->customeruserid->setVisibility();
		$this->paymentid->setVisibility();
		$this->purchaseid->setVisibility();
		$this->eftid->setVisibility();
		$this->targetUserID->setVisibility();
		$this->messageType->setVisibility();
		$this->targetemail->setVisibility();
		$this->targetpresentationcode->setVisibility();
		$this->targetcomments->setVisibility();
		$this->targetrecipientname->setVisibility();
		$this->targetsendername->setVisibility();
		$this->salesrepid->setVisibility();
		$this->currIDSettlement->setVisibility();
		$this->hideFieldsForAddEdit();

		// Do not use lookup cache
		$this->setUseLookupCache(FALSE);

		// Global Page Loading event (in userfn*.php)
		Page_Loading();

		// Page Load event
		$this->Page_Load();

		// Check token
		if (!$this->validPost()) {
			Write($Language->phrase("InvalidPostRequest"));
			$this->terminate();
		}

		// Create Token
		$this->createToken();

		// Set up lookup cache
		$this->setupLookupOptions($this->piid);
		$this->setupLookupOptions($this->salesrepid);

		// Check permission
		if (!$Security->canAdd()) {
			$this->setFailureMessage(DeniedMessage()); // No permission
			$this->terminate("purchaseorderlist.php");
			return;
		}

		// Check modal
		if ($this->IsModal)
			$SkipHeaderFooter = TRUE;
		$this->IsMobileOrModal = IsMobile() || $this->IsModal;
		$this->FormClassName = "ew-form ew-add-form ew-horizontal";
		$postBack = FALSE;

		// Set up current action
		if (IsApi()) {
			$this->CurrentAction = "insert"; // Add record directly
			$postBack = TRUE;
		} elseif (Post("action") !== NULL) {
			$this->CurrentAction = Post("action"); // Get form action
			$postBack = TRUE;
		} else { // Not post back

			// Load key values from QueryString
			$this->CopyRecord = TRUE;
			if (Get("poid") !== NULL) {
				$this->poid->setQueryStringValue(Get("poid"));
				$this->setKey("poid", $this->poid->CurrentValue); // Set up key
			} else {
				$this->setKey("poid", ""); // Clear key
				$this->CopyRecord = FALSE;
			}
			if ($this->CopyRecord) {
				$this->CurrentAction = "copy"; // Copy record
			} else {
				$this->CurrentAction = "show"; // Display blank record
			}
		}

		// Load old record / default values
		$loaded = $this->loadOldRecord();

		// Load form values
		if ($postBack) {
			$this->loadFormValues(); // Load form values
		}

		// Set up detail parameters
		$this->setupDetailParms();

		// Validate form if post back
		if ($postBack) {
			if (!$this->validateForm()) {
				$this->EventCancelled = TRUE; // Event cancelled
				$this->restoreFormValues(); // Restore form values
				$this->setFailureMessage($FormError);
				if (IsApi()) {
					$this->terminate();
					return;
				} else {
					$this->CurrentAction = "show"; // Form error, reset action
				}
			}
		}

		// Perform current action
		switch ($this->CurrentAction) {
			case "copy": // Copy an existing record
				if (!$loaded) { // Record not loaded
					if ($this->getFailureMessage() == "")
						$this->setFailureMessage($Language->phrase("NoRecord")); // No record found
					$this->terminate("purchaseorderlist.php"); // No matching record, return to list
				}

				// Set up detail parameters
				$this->setupDetailParms();
				break;
			case "insert": // Add new record
				$this->SendEmail = TRUE; // Send email on add success
				if ($this->addRow($this->OldRecordset)) { // Add successful
					if ($this->getSuccessMessage() == "")
						$this->setSuccessMessage($Language->phrase("AddSuccess")); // Set up success message
					if ($this->getCurrentDetailTable() != "") // Master/detail add
						$returnUrl = $this->getDetailUrl();
					else
						$returnUrl = $this->getReturnUrl();
					if (GetPageName($returnUrl) == "purchaseorderlist.php")
						$returnUrl = $this->addMasterUrl($returnUrl); // List page, return to List page with correct master key if necessary
					elseif (GetPageName($returnUrl) == "purchaseorderview.php")
						$returnUrl = $this->getViewUrl(); // View page, return to View page with keyurl directly
					if (IsApi()) { // Return to caller
						$this->terminate(TRUE);
						return;
					} else {
						$this->terminate($returnUrl);
					}
				} elseif (IsApi()) { // API request, return
					$this->terminate();
					return;
				} else {
					$this->EventCancelled = TRUE; // Event cancelled
					$this->restoreFormValues(); // Add failed, restore form values

					// Set up detail parameters
					$this->setupDetailParms();
				}
		}

		// Set up Breadcrumb
		$this->setupBreadcrumb();

		// Render row based on row type
		$this->RowType = ROWTYPE_ADD; // Render add type

		// Render row
		$this->resetAttributes();
		$this->renderRow();
	}

	// Get upload files
	protected function getUploadFiles()
	{
		global $CurrentForm, $Language;
	}

	// Load default values
	protected function loadDefaultValues()
	{
		$this->poid->CurrentValue = NULL;
		$this->poid->OldValue = $this->poid->CurrentValue;
		$this->txid->CurrentValue = NULL;
		$this->txid->OldValue = $this->txid->CurrentValue;
		$this->merchantID->CurrentValue = NULL;
		$this->merchantID->OldValue = $this->merchantID->CurrentValue;
		$this->_userID->CurrentValue = NULL;
		$this->_userID->OldValue = $this->_userID->CurrentValue;
		$this->transferTime->CurrentValue = NULL;
		$this->transferTime->OldValue = $this->transferTime->CurrentValue;
		$this->merchantSurcharge->CurrentValue = 0.00;
		$this->currID->CurrentValue = NULL;
		$this->currID->OldValue = $this->currID->CurrentValue;
		$this->purchaseAmount->CurrentValue = 0.00;
		$this->taxAmount->CurrentValue = 0.00;
		$this->tipAmount->CurrentValue = 0.00;
		$this->serviceFeeToCustomer->CurrentValue = 0.00;
		$this->TotalAmountForCustomer->CurrentValue = 0.00;
		$this->serviceFeeToMerchant->CurrentValue = 0.00;
		$this->status->CurrentValue = NULL;
		$this->status->OldValue = $this->status->CurrentValue;
		$this->shoppingCartID->CurrentValue = NULL;
		$this->shoppingCartID->OldValue = $this->shoppingCartID->CurrentValue;
		$this->merchantRefID->CurrentValue = NULL;
		$this->merchantRefID->OldValue = $this->merchantRefID->CurrentValue;
		$this->feeid->CurrentValue = NULL;
		$this->feeid->OldValue = $this->feeid->CurrentValue;
		$this->ratetabletype->CurrentValue = NULL;
		$this->ratetabletype->OldValue = $this->ratetabletype->CurrentValue;
		$this->userpi->CurrentValue = NULL;
		$this->userpi->OldValue = $this->userpi->CurrentValue;
		$this->piid->CurrentValue = NULL;
		$this->piid->OldValue = $this->piid->CurrentValue;
		$this->feesystemshare->CurrentValue = 0.00;
		$this->feeexternalshare->CurrentValue = NULL;
		$this->feeexternalshare->OldValue = $this->feeexternalshare->CurrentValue;
		$this->feefranchiseeshare->CurrentValue = NULL;
		$this->feefranchiseeshare->OldValue = $this->feefranchiseeshare->CurrentValue;
		$this->feeresellershare->CurrentValue = NULL;
		$this->feeresellershare->OldValue = $this->feeresellershare->CurrentValue;
		$this->lastupdatetime->CurrentValue = NULL;
		$this->lastupdatetime->OldValue = $this->lastupdatetime->CurrentValue;
		$this->expirationTimeInMinutes->CurrentValue = 0;
		$this->expirationTime->CurrentValue = NULL;
		$this->expirationTime->OldValue = $this->expirationTime->CurrentValue;
		$this->itemdesc->CurrentValue = NULL;
		$this->itemdesc->OldValue = $this->itemdesc->CurrentValue;
		$this->customeruserid->CurrentValue = NULL;
		$this->customeruserid->OldValue = $this->customeruserid->CurrentValue;
		$this->paymentid->CurrentValue = 0;
		$this->purchaseid->CurrentValue = 0;
		$this->eftid->CurrentValue = 0;
		$this->targetUserID->CurrentValue = 0;
		$this->messageType->CurrentValue = 0;
		$this->targetemail->CurrentValue = NULL;
		$this->targetemail->OldValue = $this->targetemail->CurrentValue;
		$this->targetpresentationcode->CurrentValue = 0;
		$this->targetcomments->CurrentValue = NULL;
		$this->targetcomments->OldValue = $this->targetcomments->CurrentValue;
		$this->targetrecipientname->CurrentValue = NULL;
		$this->targetrecipientname->OldValue = $this->targetrecipientname->CurrentValue;
		$this->targetsendername->CurrentValue = NULL;
		$this->targetsendername->OldValue = $this->targetsendername->CurrentValue;
		$this->salesrepid->CurrentValue = 0;
		$this->currIDSettlement->CurrentValue = NULL;
		$this->currIDSettlement->OldValue = $this->currIDSettlement->CurrentValue;
	}

	// Load form values
	protected function loadFormValues()
	{

		// Load from form
		global $CurrentForm;

		// Check field name 'txid' first before field var 'x_txid'
		$val = $CurrentForm->hasValue("txid") ? $CurrentForm->getValue("txid") : $CurrentForm->getValue("x_txid");
		if (!$this->txid->IsDetailKey) {
			if (IsApi() && $val === NULL)
				$this->txid->Visible = FALSE; // Disable update for API request
			else
				$this->txid->setFormValue($val);
		}

		// Check field name 'merchantID' first before field var 'x_merchantID'
		$val = $CurrentForm->hasValue("merchantID") ? $CurrentForm->getValue("merchantID") : $CurrentForm->getValue("x_merchantID");
		if (!$this->merchantID->IsDetailKey) {
			if (IsApi() && $val === NULL)
				$this->merchantID->Visible = FALSE; // Disable update for API request
			else
				$this->merchantID->setFormValue($val);
		}

		// Check field name 'userID' first before field var 'x__userID'
		$val = $CurrentForm->hasValue("userID") ? $CurrentForm->getValue("userID") : $CurrentForm->getValue("x__userID");
		if (!$this->_userID->IsDetailKey) {
			if (IsApi() && $val === NULL)
				$this->_userID->Visible = FALSE; // Disable update for API request
			else
				$this->_userID->setFormValue($val);
		}

		// Check field name 'transferTime' first before field var 'x_transferTime'
		$val = $CurrentForm->hasValue("transferTime") ? $CurrentForm->getValue("transferTime") : $CurrentForm->getValue("x_transferTime");
		if (!$this->transferTime->IsDetailKey) {
			if (IsApi() && $val === NULL)
				$this->transferTime->Visible = FALSE; // Disable update for API request
			else
				$this->transferTime->setFormValue($val);
			$this->transferTime->CurrentValue = UnFormatDateTime($this->transferTime->CurrentValue, 0);
		}

		// Check field name 'merchantSurcharge' first before field var 'x_merchantSurcharge'
		$val = $CurrentForm->hasValue("merchantSurcharge") ? $CurrentForm->getValue("merchantSurcharge") : $CurrentForm->getValue("x_merchantSurcharge");
		if (!$this->merchantSurcharge->IsDetailKey) {
			if (IsApi() && $val === NULL)
				$this->merchantSurcharge->Visible = FALSE; // Disable update for API request
			else
				$this->merchantSurcharge->setFormValue($val);
		}

		// Check field name 'currID' first before field var 'x_currID'
		$val = $CurrentForm->hasValue("currID") ? $CurrentForm->getValue("currID") : $CurrentForm->getValue("x_currID");
		if (!$this->currID->IsDetailKey) {
			if (IsApi() && $val === NULL)
				$this->currID->Visible = FALSE; // Disable update for API request
			else
				$this->currID->setFormValue($val);
		}

		// Check field name 'purchaseAmount' first before field var 'x_purchaseAmount'
		$val = $CurrentForm->hasValue("purchaseAmount") ? $CurrentForm->getValue("purchaseAmount") : $CurrentForm->getValue("x_purchaseAmount");
		if (!$this->purchaseAmount->IsDetailKey) {
			if (IsApi() && $val === NULL)
				$this->purchaseAmount->Visible = FALSE; // Disable update for API request
			else
				$this->purchaseAmount->setFormValue($val);
		}

		// Check field name 'taxAmount' first before field var 'x_taxAmount'
		$val = $CurrentForm->hasValue("taxAmount") ? $CurrentForm->getValue("taxAmount") : $CurrentForm->getValue("x_taxAmount");
		if (!$this->taxAmount->IsDetailKey) {
			if (IsApi() && $val === NULL)
				$this->taxAmount->Visible = FALSE; // Disable update for API request
			else
				$this->taxAmount->setFormValue($val);
		}

		// Check field name 'tipAmount' first before field var 'x_tipAmount'
		$val = $CurrentForm->hasValue("tipAmount") ? $CurrentForm->getValue("tipAmount") : $CurrentForm->getValue("x_tipAmount");
		if (!$this->tipAmount->IsDetailKey) {
			if (IsApi() && $val === NULL)
				$this->tipAmount->Visible = FALSE; // Disable update for API request
			else
				$this->tipAmount->setFormValue($val);
		}

		// Check field name 'serviceFeeToCustomer' first before field var 'x_serviceFeeToCustomer'
		$val = $CurrentForm->hasValue("serviceFeeToCustomer") ? $CurrentForm->getValue("serviceFeeToCustomer") : $CurrentForm->getValue("x_serviceFeeToCustomer");
		if (!$this->serviceFeeToCustomer->IsDetailKey) {
			if (IsApi() && $val === NULL)
				$this->serviceFeeToCustomer->Visible = FALSE; // Disable update for API request
			else
				$this->serviceFeeToCustomer->setFormValue($val);
		}

		// Check field name 'TotalAmountForCustomer' first before field var 'x_TotalAmountForCustomer'
		$val = $CurrentForm->hasValue("TotalAmountForCustomer") ? $CurrentForm->getValue("TotalAmountForCustomer") : $CurrentForm->getValue("x_TotalAmountForCustomer");
		if (!$this->TotalAmountForCustomer->IsDetailKey) {
			if (IsApi() && $val === NULL)
				$this->TotalAmountForCustomer->Visible = FALSE; // Disable update for API request
			else
				$this->TotalAmountForCustomer->setFormValue($val);
		}

		// Check field name 'serviceFeeToMerchant' first before field var 'x_serviceFeeToMerchant'
		$val = $CurrentForm->hasValue("serviceFeeToMerchant") ? $CurrentForm->getValue("serviceFeeToMerchant") : $CurrentForm->getValue("x_serviceFeeToMerchant");
		if (!$this->serviceFeeToMerchant->IsDetailKey) {
			if (IsApi() && $val === NULL)
				$this->serviceFeeToMerchant->Visible = FALSE; // Disable update for API request
			else
				$this->serviceFeeToMerchant->setFormValue($val);
		}

		// Check field name 'status' first before field var 'x_status'
		$val = $CurrentForm->hasValue("status") ? $CurrentForm->getValue("status") : $CurrentForm->getValue("x_status");
		if (!$this->status->IsDetailKey) {
			if (IsApi() && $val === NULL)
				$this->status->Visible = FALSE; // Disable update for API request
			else
				$this->status->setFormValue($val);
		}

		// Check field name 'shoppingCartID' first before field var 'x_shoppingCartID'
		$val = $CurrentForm->hasValue("shoppingCartID") ? $CurrentForm->getValue("shoppingCartID") : $CurrentForm->getValue("x_shoppingCartID");
		if (!$this->shoppingCartID->IsDetailKey) {
			if (IsApi() && $val === NULL)
				$this->shoppingCartID->Visible = FALSE; // Disable update for API request
			else
				$this->shoppingCartID->setFormValue($val);
		}

		// Check field name 'merchantRefID' first before field var 'x_merchantRefID'
		$val = $CurrentForm->hasValue("merchantRefID") ? $CurrentForm->getValue("merchantRefID") : $CurrentForm->getValue("x_merchantRefID");
		if (!$this->merchantRefID->IsDetailKey) {
			if (IsApi() && $val === NULL)
				$this->merchantRefID->Visible = FALSE; // Disable update for API request
			else
				$this->merchantRefID->setFormValue($val);
		}

		// Check field name 'feeid' first before field var 'x_feeid'
		$val = $CurrentForm->hasValue("feeid") ? $CurrentForm->getValue("feeid") : $CurrentForm->getValue("x_feeid");
		if (!$this->feeid->IsDetailKey) {
			if (IsApi() && $val === NULL)
				$this->feeid->Visible = FALSE; // Disable update for API request
			else
				$this->feeid->setFormValue($val);
		}

		// Check field name 'ratetabletype' first before field var 'x_ratetabletype'
		$val = $CurrentForm->hasValue("ratetabletype") ? $CurrentForm->getValue("ratetabletype") : $CurrentForm->getValue("x_ratetabletype");
		if (!$this->ratetabletype->IsDetailKey) {
			if (IsApi() && $val === NULL)
				$this->ratetabletype->Visible = FALSE; // Disable update for API request
			else
				$this->ratetabletype->setFormValue($val);
		}

		// Check field name 'userpi' first before field var 'x_userpi'
		$val = $CurrentForm->hasValue("userpi") ? $CurrentForm->getValue("userpi") : $CurrentForm->getValue("x_userpi");
		if (!$this->userpi->IsDetailKey) {
			if (IsApi() && $val === NULL)
				$this->userpi->Visible = FALSE; // Disable update for API request
			else
				$this->userpi->setFormValue($val);
		}

		// Check field name 'piid' first before field var 'x_piid'
		$val = $CurrentForm->hasValue("piid") ? $CurrentForm->getValue("piid") : $CurrentForm->getValue("x_piid");
		if (!$this->piid->IsDetailKey) {
			if (IsApi() && $val === NULL)
				$this->piid->Visible = FALSE; // Disable update for API request
			else
				$this->piid->setFormValue($val);
		}

		// Check field name 'feesystemshare' first before field var 'x_feesystemshare'
		$val = $CurrentForm->hasValue("feesystemshare") ? $CurrentForm->getValue("feesystemshare") : $CurrentForm->getValue("x_feesystemshare");
		if (!$this->feesystemshare->IsDetailKey) {
			if (IsApi() && $val === NULL)
				$this->feesystemshare->Visible = FALSE; // Disable update for API request
			else
				$this->feesystemshare->setFormValue($val);
		}

		// Check field name 'feeexternalshare' first before field var 'x_feeexternalshare'
		$val = $CurrentForm->hasValue("feeexternalshare") ? $CurrentForm->getValue("feeexternalshare") : $CurrentForm->getValue("x_feeexternalshare");
		if (!$this->feeexternalshare->IsDetailKey) {
			if (IsApi() && $val === NULL)
				$this->feeexternalshare->Visible = FALSE; // Disable update for API request
			else
				$this->feeexternalshare->setFormValue($val);
		}

		// Check field name 'feefranchiseeshare' first before field var 'x_feefranchiseeshare'
		$val = $CurrentForm->hasValue("feefranchiseeshare") ? $CurrentForm->getValue("feefranchiseeshare") : $CurrentForm->getValue("x_feefranchiseeshare");
		if (!$this->feefranchiseeshare->IsDetailKey) {
			if (IsApi() && $val === NULL)
				$this->feefranchiseeshare->Visible = FALSE; // Disable update for API request
			else
				$this->feefranchiseeshare->setFormValue($val);
		}

		// Check field name 'feeresellershare' first before field var 'x_feeresellershare'
		$val = $CurrentForm->hasValue("feeresellershare") ? $CurrentForm->getValue("feeresellershare") : $CurrentForm->getValue("x_feeresellershare");
		if (!$this->feeresellershare->IsDetailKey) {
			if (IsApi() && $val === NULL)
				$this->feeresellershare->Visible = FALSE; // Disable update for API request
			else
				$this->feeresellershare->setFormValue($val);
		}

		// Check field name 'lastupdatetime' first before field var 'x_lastupdatetime'
		$val = $CurrentForm->hasValue("lastupdatetime") ? $CurrentForm->getValue("lastupdatetime") : $CurrentForm->getValue("x_lastupdatetime");
		if (!$this->lastupdatetime->IsDetailKey) {
			if (IsApi() && $val === NULL)
				$this->lastupdatetime->Visible = FALSE; // Disable update for API request
			else
				$this->lastupdatetime->setFormValue($val);
			$this->lastupdatetime->CurrentValue = UnFormatDateTime($this->lastupdatetime->CurrentValue, 0);
		}

		// Check field name 'expirationTimeInMinutes' first before field var 'x_expirationTimeInMinutes'
		$val = $CurrentForm->hasValue("expirationTimeInMinutes") ? $CurrentForm->getValue("expirationTimeInMinutes") : $CurrentForm->getValue("x_expirationTimeInMinutes");
		if (!$this->expirationTimeInMinutes->IsDetailKey) {
			if (IsApi() && $val === NULL)
				$this->expirationTimeInMinutes->Visible = FALSE; // Disable update for API request
			else
				$this->expirationTimeInMinutes->setFormValue($val);
		}

		// Check field name 'expirationTime' first before field var 'x_expirationTime'
		$val = $CurrentForm->hasValue("expirationTime") ? $CurrentForm->getValue("expirationTime") : $CurrentForm->getValue("x_expirationTime");
		if (!$this->expirationTime->IsDetailKey) {
			if (IsApi() && $val === NULL)
				$this->expirationTime->Visible = FALSE; // Disable update for API request
			else
				$this->expirationTime->setFormValue($val);
			$this->expirationTime->CurrentValue = UnFormatDateTime($this->expirationTime->CurrentValue, 0);
		}

		// Check field name 'itemdesc' first before field var 'x_itemdesc'
		$val = $CurrentForm->hasValue("itemdesc") ? $CurrentForm->getValue("itemdesc") : $CurrentForm->getValue("x_itemdesc");
		if (!$this->itemdesc->IsDetailKey) {
			if (IsApi() && $val === NULL)
				$this->itemdesc->Visible = FALSE; // Disable update for API request
			else
				$this->itemdesc->setFormValue($val);
		}

		// Check field name 'customeruserid' first before field var 'x_customeruserid'
		$val = $CurrentForm->hasValue("customeruserid") ? $CurrentForm->getValue("customeruserid") : $CurrentForm->getValue("x_customeruserid");
		if (!$this->customeruserid->IsDetailKey) {
			if (IsApi() && $val === NULL)
				$this->customeruserid->Visible = FALSE; // Disable update for API request
			else
				$this->customeruserid->setFormValue($val);
		}

		// Check field name 'paymentid' first before field var 'x_paymentid'
		$val = $CurrentForm->hasValue("paymentid") ? $CurrentForm->getValue("paymentid") : $CurrentForm->getValue("x_paymentid");
		if (!$this->paymentid->IsDetailKey) {
			if (IsApi() && $val === NULL)
				$this->paymentid->Visible = FALSE; // Disable update for API request
			else
				$this->paymentid->setFormValue($val);
		}

		// Check field name 'purchaseid' first before field var 'x_purchaseid'
		$val = $CurrentForm->hasValue("purchaseid") ? $CurrentForm->getValue("purchaseid") : $CurrentForm->getValue("x_purchaseid");
		if (!$this->purchaseid->IsDetailKey) {
			if (IsApi() && $val === NULL)
				$this->purchaseid->Visible = FALSE; // Disable update for API request
			else
				$this->purchaseid->setFormValue($val);
		}

		// Check field name 'eftid' first before field var 'x_eftid'
		$val = $CurrentForm->hasValue("eftid") ? $CurrentForm->getValue("eftid") : $CurrentForm->getValue("x_eftid");
		if (!$this->eftid->IsDetailKey) {
			if (IsApi() && $val === NULL)
				$this->eftid->Visible = FALSE; // Disable update for API request
			else
				$this->eftid->setFormValue($val);
		}

		// Check field name 'targetUserID' first before field var 'x_targetUserID'
		$val = $CurrentForm->hasValue("targetUserID") ? $CurrentForm->getValue("targetUserID") : $CurrentForm->getValue("x_targetUserID");
		if (!$this->targetUserID->IsDetailKey) {
			if (IsApi() && $val === NULL)
				$this->targetUserID->Visible = FALSE; // Disable update for API request
			else
				$this->targetUserID->setFormValue($val);
		}

		// Check field name 'messageType' first before field var 'x_messageType'
		$val = $CurrentForm->hasValue("messageType") ? $CurrentForm->getValue("messageType") : $CurrentForm->getValue("x_messageType");
		if (!$this->messageType->IsDetailKey) {
			if (IsApi() && $val === NULL)
				$this->messageType->Visible = FALSE; // Disable update for API request
			else
				$this->messageType->setFormValue($val);
		}

		// Check field name 'targetemail' first before field var 'x_targetemail'
		$val = $CurrentForm->hasValue("targetemail") ? $CurrentForm->getValue("targetemail") : $CurrentForm->getValue("x_targetemail");
		if (!$this->targetemail->IsDetailKey) {
			if (IsApi() && $val === NULL)
				$this->targetemail->Visible = FALSE; // Disable update for API request
			else
				$this->targetemail->setFormValue($val);
		}

		// Check field name 'targetpresentationcode' first before field var 'x_targetpresentationcode'
		$val = $CurrentForm->hasValue("targetpresentationcode") ? $CurrentForm->getValue("targetpresentationcode") : $CurrentForm->getValue("x_targetpresentationcode");
		if (!$this->targetpresentationcode->IsDetailKey) {
			if (IsApi() && $val === NULL)
				$this->targetpresentationcode->Visible = FALSE; // Disable update for API request
			else
				$this->targetpresentationcode->setFormValue($val);
		}

		// Check field name 'targetcomments' first before field var 'x_targetcomments'
		$val = $CurrentForm->hasValue("targetcomments") ? $CurrentForm->getValue("targetcomments") : $CurrentForm->getValue("x_targetcomments");
		if (!$this->targetcomments->IsDetailKey) {
			if (IsApi() && $val === NULL)
				$this->targetcomments->Visible = FALSE; // Disable update for API request
			else
				$this->targetcomments->setFormValue($val);
		}

		// Check field name 'targetrecipientname' first before field var 'x_targetrecipientname'
		$val = $CurrentForm->hasValue("targetrecipientname") ? $CurrentForm->getValue("targetrecipientname") : $CurrentForm->getValue("x_targetrecipientname");
		if (!$this->targetrecipientname->IsDetailKey) {
			if (IsApi() && $val === NULL)
				$this->targetrecipientname->Visible = FALSE; // Disable update for API request
			else
				$this->targetrecipientname->setFormValue($val);
		}

		// Check field name 'targetsendername' first before field var 'x_targetsendername'
		$val = $CurrentForm->hasValue("targetsendername") ? $CurrentForm->getValue("targetsendername") : $CurrentForm->getValue("x_targetsendername");
		if (!$this->targetsendername->IsDetailKey) {
			if (IsApi() && $val === NULL)
				$this->targetsendername->Visible = FALSE; // Disable update for API request
			else
				$this->targetsendername->setFormValue($val);
		}

		// Check field name 'salesrepid' first before field var 'x_salesrepid'
		$val = $CurrentForm->hasValue("salesrepid") ? $CurrentForm->getValue("salesrepid") : $CurrentForm->getValue("x_salesrepid");
		if (!$this->salesrepid->IsDetailKey) {
			if (IsApi() && $val === NULL)
				$this->salesrepid->Visible = FALSE; // Disable update for API request
			else
				$this->salesrepid->setFormValue($val);
		}

		// Check field name 'currIDSettlement' first before field var 'x_currIDSettlement'
		$val = $CurrentForm->hasValue("currIDSettlement") ? $CurrentForm->getValue("currIDSettlement") : $CurrentForm->getValue("x_currIDSettlement");
		if (!$this->currIDSettlement->IsDetailKey) {
			if (IsApi() && $val === NULL)
				$this->currIDSettlement->Visible = FALSE; // Disable update for API request
			else
				$this->currIDSettlement->setFormValue($val);
		}

		// Check field name 'poid' first before field var 'x_poid'
		$val = $CurrentForm->hasValue("poid") ? $CurrentForm->getValue("poid") : $CurrentForm->getValue("x_poid");
	}

	// Restore form values
	public function restoreFormValues()
	{
		global $CurrentForm;
		$this->txid->CurrentValue = $this->txid->FormValue;
		$this->merchantID->CurrentValue = $this->merchantID->FormValue;
		$this->_userID->CurrentValue = $this->_userID->FormValue;
		$this->transferTime->CurrentValue = $this->transferTime->FormValue;
		$this->transferTime->CurrentValue = UnFormatDateTime($this->transferTime->CurrentValue, 0);
		$this->merchantSurcharge->CurrentValue = $this->merchantSurcharge->FormValue;
		$this->currID->CurrentValue = $this->currID->FormValue;
		$this->purchaseAmount->CurrentValue = $this->purchaseAmount->FormValue;
		$this->taxAmount->CurrentValue = $this->taxAmount->FormValue;
		$this->tipAmount->CurrentValue = $this->tipAmount->FormValue;
		$this->serviceFeeToCustomer->CurrentValue = $this->serviceFeeToCustomer->FormValue;
		$this->TotalAmountForCustomer->CurrentValue = $this->TotalAmountForCustomer->FormValue;
		$this->serviceFeeToMerchant->CurrentValue = $this->serviceFeeToMerchant->FormValue;
		$this->status->CurrentValue = $this->status->FormValue;
		$this->shoppingCartID->CurrentValue = $this->shoppingCartID->FormValue;
		$this->merchantRefID->CurrentValue = $this->merchantRefID->FormValue;
		$this->feeid->CurrentValue = $this->feeid->FormValue;
		$this->ratetabletype->CurrentValue = $this->ratetabletype->FormValue;
		$this->userpi->CurrentValue = $this->userpi->FormValue;
		$this->piid->CurrentValue = $this->piid->FormValue;
		$this->feesystemshare->CurrentValue = $this->feesystemshare->FormValue;
		$this->feeexternalshare->CurrentValue = $this->feeexternalshare->FormValue;
		$this->feefranchiseeshare->CurrentValue = $this->feefranchiseeshare->FormValue;
		$this->feeresellershare->CurrentValue = $this->feeresellershare->FormValue;
		$this->lastupdatetime->CurrentValue = $this->lastupdatetime->FormValue;
		$this->lastupdatetime->CurrentValue = UnFormatDateTime($this->lastupdatetime->CurrentValue, 0);
		$this->expirationTimeInMinutes->CurrentValue = $this->expirationTimeInMinutes->FormValue;
		$this->expirationTime->CurrentValue = $this->expirationTime->FormValue;
		$this->expirationTime->CurrentValue = UnFormatDateTime($this->expirationTime->CurrentValue, 0);
		$this->itemdesc->CurrentValue = $this->itemdesc->FormValue;
		$this->customeruserid->CurrentValue = $this->customeruserid->FormValue;
		$this->paymentid->CurrentValue = $this->paymentid->FormValue;
		$this->purchaseid->CurrentValue = $this->purchaseid->FormValue;
		$this->eftid->CurrentValue = $this->eftid->FormValue;
		$this->targetUserID->CurrentValue = $this->targetUserID->FormValue;
		$this->messageType->CurrentValue = $this->messageType->FormValue;
		$this->targetemail->CurrentValue = $this->targetemail->FormValue;
		$this->targetpresentationcode->CurrentValue = $this->targetpresentationcode->FormValue;
		$this->targetcomments->CurrentValue = $this->targetcomments->FormValue;
		$this->targetrecipientname->CurrentValue = $this->targetrecipientname->FormValue;
		$this->targetsendername->CurrentValue = $this->targetsendername->FormValue;
		$this->salesrepid->CurrentValue = $this->salesrepid->FormValue;
		$this->currIDSettlement->CurrentValue = $this->currIDSettlement->FormValue;
	}

	// Load row based on key values
	public function loadRow()
	{
		global $Security, $Language;
		$filter = $this->getRecordFilter();

		// Call Row Selecting event
		$this->Row_Selecting($filter);

		// Load SQL based on filter
		$this->CurrentFilter = $filter;
		$sql = $this->getCurrentSql();
		$conn = $this->getConnection();
		$res = FALSE;
		$rs = LoadRecordset($sql, $conn);
		if ($rs && !$rs->EOF) {
			$res = TRUE;
			$this->loadRowValues($rs); // Load row values
			$rs->close();
		}
		return $res;
	}

	// Load row values from recordset
	public function loadRowValues($rs = NULL)
	{
		if ($rs && !$rs->EOF)
			$row = $rs->fields;
		else
			$row = $this->newRow();

		// Call Row Selected event
		$this->Row_Selected($row);
		if (!$rs || $rs->EOF)
			return;
		$this->poid->setDbValue($row['poid']);
		$this->txid->setDbValue($row['txid']);
		$this->merchantID->setDbValue($row['merchantID']);
		$this->_userID->setDbValue($row['userID']);
		$this->transferTime->setDbValue($row['transferTime']);
		$this->merchantSurcharge->setDbValue($row['merchantSurcharge']);
		$this->currID->setDbValue($row['currID']);
		$this->purchaseAmount->setDbValue($row['purchaseAmount']);
		$this->taxAmount->setDbValue($row['taxAmount']);
		$this->tipAmount->setDbValue($row['tipAmount']);
		$this->serviceFeeToCustomer->setDbValue($row['serviceFeeToCustomer']);
		$this->TotalAmountForCustomer->setDbValue($row['TotalAmountForCustomer']);
		$this->serviceFeeToMerchant->setDbValue($row['serviceFeeToMerchant']);
		$this->status->setDbValue($row['status']);
		$this->shoppingCartID->setDbValue($row['shoppingCartID']);
		$this->merchantRefID->setDbValue($row['merchantRefID']);
		$this->feeid->setDbValue($row['feeid']);
		$this->ratetabletype->setDbValue($row['ratetabletype']);
		$this->userpi->setDbValue($row['userpi']);
		$this->piid->setDbValue($row['piid']);
		$this->feesystemshare->setDbValue($row['feesystemshare']);
		$this->feeexternalshare->setDbValue($row['feeexternalshare']);
		$this->feefranchiseeshare->setDbValue($row['feefranchiseeshare']);
		$this->feeresellershare->setDbValue($row['feeresellershare']);
		$this->lastupdatetime->setDbValue($row['lastupdatetime']);
		$this->expirationTimeInMinutes->setDbValue($row['expirationTimeInMinutes']);
		$this->expirationTime->setDbValue($row['expirationTime']);
		$this->itemdesc->setDbValue($row['itemdesc']);
		$this->customeruserid->setDbValue($row['customeruserid']);
		$this->paymentid->setDbValue($row['paymentid']);
		$this->purchaseid->setDbValue($row['purchaseid']);
		$this->eftid->setDbValue($row['eftid']);
		$this->targetUserID->setDbValue($row['targetUserID']);
		$this->messageType->setDbValue($row['messageType']);
		$this->targetemail->setDbValue($row['targetemail']);
		$this->targetpresentationcode->setDbValue($row['targetpresentationcode']);
		$this->targetcomments->setDbValue($row['targetcomments']);
		$this->targetrecipientname->setDbValue($row['targetrecipientname']);
		$this->targetsendername->setDbValue($row['targetsendername']);
		$this->salesrepid->setDbValue($row['salesrepid']);
		$this->currIDSettlement->setDbValue($row['currIDSettlement']);
	}

	// Return a row with default values
	protected function newRow()
	{
		$this->loadDefaultValues();
		$row = [];
		$row['poid'] = $this->poid->CurrentValue;
		$row['txid'] = $this->txid->CurrentValue;
		$row['merchantID'] = $this->merchantID->CurrentValue;
		$row['userID'] = $this->_userID->CurrentValue;
		$row['transferTime'] = $this->transferTime->CurrentValue;
		$row['merchantSurcharge'] = $this->merchantSurcharge->CurrentValue;
		$row['currID'] = $this->currID->CurrentValue;
		$row['purchaseAmount'] = $this->purchaseAmount->CurrentValue;
		$row['taxAmount'] = $this->taxAmount->CurrentValue;
		$row['tipAmount'] = $this->tipAmount->CurrentValue;
		$row['serviceFeeToCustomer'] = $this->serviceFeeToCustomer->CurrentValue;
		$row['TotalAmountForCustomer'] = $this->TotalAmountForCustomer->CurrentValue;
		$row['serviceFeeToMerchant'] = $this->serviceFeeToMerchant->CurrentValue;
		$row['status'] = $this->status->CurrentValue;
		$row['shoppingCartID'] = $this->shoppingCartID->CurrentValue;
		$row['merchantRefID'] = $this->merchantRefID->CurrentValue;
		$row['feeid'] = $this->feeid->CurrentValue;
		$row['ratetabletype'] = $this->ratetabletype->CurrentValue;
		$row['userpi'] = $this->userpi->CurrentValue;
		$row['piid'] = $this->piid->CurrentValue;
		$row['feesystemshare'] = $this->feesystemshare->CurrentValue;
		$row['feeexternalshare'] = $this->feeexternalshare->CurrentValue;
		$row['feefranchiseeshare'] = $this->feefranchiseeshare->CurrentValue;
		$row['feeresellershare'] = $this->feeresellershare->CurrentValue;
		$row['lastupdatetime'] = $this->lastupdatetime->CurrentValue;
		$row['expirationTimeInMinutes'] = $this->expirationTimeInMinutes->CurrentValue;
		$row['expirationTime'] = $this->expirationTime->CurrentValue;
		$row['itemdesc'] = $this->itemdesc->CurrentValue;
		$row['customeruserid'] = $this->customeruserid->CurrentValue;
		$row['paymentid'] = $this->paymentid->CurrentValue;
		$row['purchaseid'] = $this->purchaseid->CurrentValue;
		$row['eftid'] = $this->eftid->CurrentValue;
		$row['targetUserID'] = $this->targetUserID->CurrentValue;
		$row['messageType'] = $this->messageType->CurrentValue;
		$row['targetemail'] = $this->targetemail->CurrentValue;
		$row['targetpresentationcode'] = $this->targetpresentationcode->CurrentValue;
		$row['targetcomments'] = $this->targetcomments->CurrentValue;
		$row['targetrecipientname'] = $this->targetrecipientname->CurrentValue;
		$row['targetsendername'] = $this->targetsendername->CurrentValue;
		$row['salesrepid'] = $this->salesrepid->CurrentValue;
		$row['currIDSettlement'] = $this->currIDSettlement->CurrentValue;
		return $row;
	}

	// Load old record
	protected function loadOldRecord()
	{

		// Load key values from Session
		$validKey = TRUE;
		if (strval($this->getKey("poid")) != "")
			$this->poid->OldValue = $this->getKey("poid"); // poid
		else
			$validKey = FALSE;

		// Load old record
		$this->OldRecordset = NULL;
		if ($validKey) {
			$this->CurrentFilter = $this->getRecordFilter();
			$sql = $this->getCurrentSql();
			$conn = $this->getConnection();
			$this->OldRecordset = LoadRecordset($sql, $conn);
		}
		$this->loadRowValues($this->OldRecordset); // Load row values
		return $validKey;
	}

	// Render row values based on field settings
	public function renderRow()
	{
		global $Security, $Language, $CurrentLanguage;

		// Initialize URLs
		// Convert decimal values if posted back

		if ($this->merchantSurcharge->FormValue == $this->merchantSurcharge->CurrentValue && is_numeric(ConvertToFloatString($this->merchantSurcharge->CurrentValue)))
			$this->merchantSurcharge->CurrentValue = ConvertToFloatString($this->merchantSurcharge->CurrentValue);

		// Convert decimal values if posted back
		if ($this->purchaseAmount->FormValue == $this->purchaseAmount->CurrentValue && is_numeric(ConvertToFloatString($this->purchaseAmount->CurrentValue)))
			$this->purchaseAmount->CurrentValue = ConvertToFloatString($this->purchaseAmount->CurrentValue);

		// Convert decimal values if posted back
		if ($this->taxAmount->FormValue == $this->taxAmount->CurrentValue && is_numeric(ConvertToFloatString($this->taxAmount->CurrentValue)))
			$this->taxAmount->CurrentValue = ConvertToFloatString($this->taxAmount->CurrentValue);

		// Convert decimal values if posted back
		if ($this->tipAmount->FormValue == $this->tipAmount->CurrentValue && is_numeric(ConvertToFloatString($this->tipAmount->CurrentValue)))
			$this->tipAmount->CurrentValue = ConvertToFloatString($this->tipAmount->CurrentValue);

		// Convert decimal values if posted back
		if ($this->serviceFeeToCustomer->FormValue == $this->serviceFeeToCustomer->CurrentValue && is_numeric(ConvertToFloatString($this->serviceFeeToCustomer->CurrentValue)))
			$this->serviceFeeToCustomer->CurrentValue = ConvertToFloatString($this->serviceFeeToCustomer->CurrentValue);

		// Convert decimal values if posted back
		if ($this->TotalAmountForCustomer->FormValue == $this->TotalAmountForCustomer->CurrentValue && is_numeric(ConvertToFloatString($this->TotalAmountForCustomer->CurrentValue)))
			$this->TotalAmountForCustomer->CurrentValue = ConvertToFloatString($this->TotalAmountForCustomer->CurrentValue);

		// Convert decimal values if posted back
		if ($this->serviceFeeToMerchant->FormValue == $this->serviceFeeToMerchant->CurrentValue && is_numeric(ConvertToFloatString($this->serviceFeeToMerchant->CurrentValue)))
			$this->serviceFeeToMerchant->CurrentValue = ConvertToFloatString($this->serviceFeeToMerchant->CurrentValue);

		// Convert decimal values if posted back
		if ($this->feesystemshare->FormValue == $this->feesystemshare->CurrentValue && is_numeric(ConvertToFloatString($this->feesystemshare->CurrentValue)))
			$this->feesystemshare->CurrentValue = ConvertToFloatString($this->feesystemshare->CurrentValue);

		// Convert decimal values if posted back
		if ($this->feeexternalshare->FormValue == $this->feeexternalshare->CurrentValue && is_numeric(ConvertToFloatString($this->feeexternalshare->CurrentValue)))
			$this->feeexternalshare->CurrentValue = ConvertToFloatString($this->feeexternalshare->CurrentValue);

		// Convert decimal values if posted back
		if ($this->feefranchiseeshare->FormValue == $this->feefranchiseeshare->CurrentValue && is_numeric(ConvertToFloatString($this->feefranchiseeshare->CurrentValue)))
			$this->feefranchiseeshare->CurrentValue = ConvertToFloatString($this->feefranchiseeshare->CurrentValue);

		// Convert decimal values if posted back
		if ($this->feeresellershare->FormValue == $this->feeresellershare->CurrentValue && is_numeric(ConvertToFloatString($this->feeresellershare->CurrentValue)))
			$this->feeresellershare->CurrentValue = ConvertToFloatString($this->feeresellershare->CurrentValue);

		// Call Row_Rendering event
		$this->Row_Rendering();

		// Common render codes for all row types
		// poid
		// txid
		// merchantID
		// userID
		// transferTime
		// merchantSurcharge
		// currID
		// purchaseAmount
		// taxAmount
		// tipAmount
		// serviceFeeToCustomer
		// TotalAmountForCustomer
		// serviceFeeToMerchant
		// status
		// shoppingCartID
		// merchantRefID
		// feeid
		// ratetabletype
		// userpi
		// piid
		// feesystemshare
		// feeexternalshare
		// feefranchiseeshare
		// feeresellershare
		// lastupdatetime
		// expirationTimeInMinutes
		// expirationTime
		// itemdesc
		// customeruserid
		// paymentid
		// purchaseid
		// eftid
		// targetUserID
		// messageType
		// targetemail
		// targetpresentationcode
		// targetcomments
		// targetrecipientname
		// targetsendername
		// salesrepid
		// currIDSettlement

		if ($this->RowType == ROWTYPE_VIEW) { // View row

			// poid
			$this->poid->ViewValue = $this->poid->CurrentValue;
			$this->poid->ViewCustomAttributes = "";

			// txid
			$this->txid->ViewValue = $this->txid->CurrentValue;
			$this->txid->ViewCustomAttributes = "";

			// merchantID
			$this->merchantID->ViewValue = $this->merchantID->CurrentValue;
			$this->merchantID->ViewValue = FormatNumber($this->merchantID->ViewValue, 0, -2, -2, -2);
			$this->merchantID->ViewCustomAttributes = "";

			// userID
			$this->_userID->ViewValue = $this->_userID->CurrentValue;
			$this->_userID->ViewValue = FormatNumber($this->_userID->ViewValue, 0, -2, -2, -2);
			$this->_userID->ViewCustomAttributes = "";

			// transferTime
			$this->transferTime->ViewValue = $this->transferTime->CurrentValue;
			$this->transferTime->ViewValue = FormatDateTime($this->transferTime->ViewValue, 0);
			$this->transferTime->ViewCustomAttributes = "";

			// merchantSurcharge
			$this->merchantSurcharge->ViewValue = $this->merchantSurcharge->CurrentValue;
			$this->merchantSurcharge->ViewValue = FormatNumber($this->merchantSurcharge->ViewValue, 2, -2, -2, -2);
			$this->merchantSurcharge->ViewCustomAttributes = "";

			// currID
			$this->currID->ViewValue = $this->currID->CurrentValue;
			$this->currID->ViewCustomAttributes = "";

			// purchaseAmount
			$this->purchaseAmount->ViewValue = $this->purchaseAmount->CurrentValue;
			$this->purchaseAmount->ViewValue = FormatNumber($this->purchaseAmount->ViewValue, 2, -2, -2, -2);
			$this->purchaseAmount->ViewCustomAttributes = "";

			// taxAmount
			$this->taxAmount->ViewValue = $this->taxAmount->CurrentValue;
			$this->taxAmount->ViewValue = FormatNumber($this->taxAmount->ViewValue, 2, -2, -2, -2);
			$this->taxAmount->ViewCustomAttributes = "";

			// tipAmount
			$this->tipAmount->ViewValue = $this->tipAmount->CurrentValue;
			$this->tipAmount->ViewValue = FormatNumber($this->tipAmount->ViewValue, 2, -2, -2, -2);
			$this->tipAmount->ViewCustomAttributes = "";

			// serviceFeeToCustomer
			$this->serviceFeeToCustomer->ViewValue = $this->serviceFeeToCustomer->CurrentValue;
			$this->serviceFeeToCustomer->ViewValue = FormatNumber($this->serviceFeeToCustomer->ViewValue, 2, -2, -2, -2);
			$this->serviceFeeToCustomer->ViewCustomAttributes = "";

			// TotalAmountForCustomer
			$this->TotalAmountForCustomer->ViewValue = $this->TotalAmountForCustomer->CurrentValue;
			$this->TotalAmountForCustomer->ViewValue = FormatNumber($this->TotalAmountForCustomer->ViewValue, 2, -2, -2, -2);
			$this->TotalAmountForCustomer->ViewCustomAttributes = "";

			// serviceFeeToMerchant
			$this->serviceFeeToMerchant->ViewValue = $this->serviceFeeToMerchant->CurrentValue;
			$this->serviceFeeToMerchant->ViewValue = FormatNumber($this->serviceFeeToMerchant->ViewValue, 2, -2, -2, -2);
			$this->serviceFeeToMerchant->ViewCustomAttributes = "";

			// status
			if (strval($this->status->CurrentValue) != "") {
				$this->status->ViewValue = $this->status->optionCaption($this->status->CurrentValue);
			} else {
				$this->status->ViewValue = NULL;
			}
			$this->status->ViewCustomAttributes = "";

			// shoppingCartID
			$this->shoppingCartID->ViewValue = $this->shoppingCartID->CurrentValue;
			$this->shoppingCartID->ViewCustomAttributes = "";

			// merchantRefID
			$this->merchantRefID->ViewValue = $this->merchantRefID->CurrentValue;
			$this->merchantRefID->ViewCustomAttributes = "";

			// feeid
			$this->feeid->ViewValue = $this->feeid->CurrentValue;
			$this->feeid->ViewValue = FormatNumber($this->feeid->ViewValue, 0, -2, -2, -2);
			$this->feeid->ViewCustomAttributes = "";

			// ratetabletype
			$this->ratetabletype->ViewValue = $this->ratetabletype->CurrentValue;
			$this->ratetabletype->ViewValue = FormatNumber($this->ratetabletype->ViewValue, 0, -2, -2, -2);
			$this->ratetabletype->ViewCustomAttributes = "";

			// userpi
			$this->userpi->ViewValue = $this->userpi->CurrentValue;
			$this->userpi->ViewValue = FormatNumber($this->userpi->ViewValue, 0, -2, -2, -2);
			$this->userpi->ViewCustomAttributes = "";

			// piid
			$curVal = strval($this->piid->CurrentValue);
			if ($curVal != "") {
				$this->piid->ViewValue = $this->piid->lookupCacheOption($curVal);
				if ($this->piid->ViewValue === NULL) { // Lookup from database
					$filterWrk = "`id`" . SearchString("=", $curVal, DATATYPE_NUMBER, "_4payreference");
					$sqlWrk = $this->piid->Lookup->getSql(FALSE, $filterWrk, '', $this);
					$rswrk = Conn("_4payreference")->execute($sqlWrk);
					if ($rswrk && !$rswrk->EOF) { // Lookup values found
						$arwrk = [];
						$arwrk[1] = $rswrk->fields('df');
						$arwrk[2] = $rswrk->fields('df2');
						$this->piid->ViewValue = $this->piid->displayValue($arwrk);
						$rswrk->Close();
					} else {
						$this->piid->ViewValue = $this->piid->CurrentValue;
					}
				}
			} else {
				$this->piid->ViewValue = NULL;
			}
			$this->piid->ViewCustomAttributes = "";

			// feesystemshare
			$this->feesystemshare->ViewValue = $this->feesystemshare->CurrentValue;
			$this->feesystemshare->ViewValue = FormatNumber($this->feesystemshare->ViewValue, 2, -2, -2, -2);
			$this->feesystemshare->ViewCustomAttributes = "";

			// feeexternalshare
			$this->feeexternalshare->ViewValue = $this->feeexternalshare->CurrentValue;
			$this->feeexternalshare->ViewValue = FormatNumber($this->feeexternalshare->ViewValue, 2, -2, -2, -2);
			$this->feeexternalshare->ViewCustomAttributes = "";

			// feefranchiseeshare
			$this->feefranchiseeshare->ViewValue = $this->feefranchiseeshare->CurrentValue;
			$this->feefranchiseeshare->ViewValue = FormatNumber($this->feefranchiseeshare->ViewValue, 2, -2, -2, -2);
			$this->feefranchiseeshare->ViewCustomAttributes = "";

			// feeresellershare
			$this->feeresellershare->ViewValue = $this->feeresellershare->CurrentValue;
			$this->feeresellershare->ViewValue = FormatNumber($this->feeresellershare->ViewValue, 2, -2, -2, -2);
			$this->feeresellershare->ViewCustomAttributes = "";

			// lastupdatetime
			$this->lastupdatetime->ViewValue = $this->lastupdatetime->CurrentValue;
			$this->lastupdatetime->ViewValue = FormatDateTime($this->lastupdatetime->ViewValue, 0);
			$this->lastupdatetime->ViewCustomAttributes = "";

			// expirationTimeInMinutes
			$this->expirationTimeInMinutes->ViewValue = $this->expirationTimeInMinutes->CurrentValue;
			$this->expirationTimeInMinutes->ViewValue = FormatNumber($this->expirationTimeInMinutes->ViewValue, 0, -2, -2, -2);
			$this->expirationTimeInMinutes->ViewCustomAttributes = "";

			// expirationTime
			$this->expirationTime->ViewValue = $this->expirationTime->CurrentValue;
			$this->expirationTime->ViewValue = FormatDateTime($this->expirationTime->ViewValue, 0);
			$this->expirationTime->ViewCustomAttributes = "";

			// itemdesc
			$this->itemdesc->ViewValue = $this->itemdesc->CurrentValue;
			$this->itemdesc->ViewCustomAttributes = "";

			// customeruserid
			$this->customeruserid->ViewValue = $this->customeruserid->CurrentValue;
			$this->customeruserid->ViewValue = FormatNumber($this->customeruserid->ViewValue, 0, -2, -2, -2);
			$this->customeruserid->ViewCustomAttributes = "";

			// paymentid
			$this->paymentid->ViewValue = $this->paymentid->CurrentValue;
			$this->paymentid->ViewValue = FormatNumber($this->paymentid->ViewValue, 0, -2, -2, -2);
			$this->paymentid->ViewCustomAttributes = "";

			// purchaseid
			$this->purchaseid->ViewValue = $this->purchaseid->CurrentValue;
			$this->purchaseid->ViewValue = FormatNumber($this->purchaseid->ViewValue, 0, -2, -2, -2);
			$this->purchaseid->ViewCustomAttributes = "";

			// eftid
			$this->eftid->ViewValue = $this->eftid->CurrentValue;
			$this->eftid->ViewValue = FormatNumber($this->eftid->ViewValue, 0, -2, -2, -2);
			$this->eftid->ViewCustomAttributes = "";

			// targetUserID
			$this->targetUserID->ViewValue = $this->targetUserID->CurrentValue;
			$this->targetUserID->ViewValue = FormatNumber($this->targetUserID->ViewValue, 0, -2, -2, -2);
			$this->targetUserID->ViewCustomAttributes = "";

			// messageType
			$this->messageType->ViewValue = $this->messageType->CurrentValue;
			$this->messageType->ViewValue = FormatNumber($this->messageType->ViewValue, 0, -2, -2, -2);
			$this->messageType->ViewCustomAttributes = "";

			// targetemail
			$this->targetemail->ViewValue = $this->targetemail->CurrentValue;
			$this->targetemail->ViewCustomAttributes = "";

			// targetpresentationcode
			$this->targetpresentationcode->ViewValue = $this->targetpresentationcode->CurrentValue;
			$this->targetpresentationcode->ViewValue = FormatNumber($this->targetpresentationcode->ViewValue, 0, -2, -2, -2);
			$this->targetpresentationcode->ViewCustomAttributes = "";

			// targetcomments
			$this->targetcomments->ViewValue = $this->targetcomments->CurrentValue;
			$this->targetcomments->ViewCustomAttributes = "";

			// targetrecipientname
			$this->targetrecipientname->ViewValue = $this->targetrecipientname->CurrentValue;
			$this->targetrecipientname->ViewCustomAttributes = "";

			// targetsendername
			$this->targetsendername->ViewValue = $this->targetsendername->CurrentValue;
			$this->targetsendername->ViewCustomAttributes = "";

			// salesrepid
			$this->salesrepid->ViewValue = $this->salesrepid->CurrentValue;
			$curVal = strval($this->salesrepid->CurrentValue);
			if ($curVal != "") {
				$this->salesrepid->ViewValue = $this->salesrepid->lookupCacheOption($curVal);
				if ($this->salesrepid->ViewValue === NULL) { // Lookup from database
					$filterWrk = "`id`" . SearchString("=", $curVal, DATATYPE_NUMBER, "");
					$sqlWrk = $this->salesrepid->Lookup->getSql(FALSE, $filterWrk, '', $this);
					$rswrk = Conn()->execute($sqlWrk);
					if ($rswrk && !$rswrk->EOF) { // Lookup values found
						$arwrk = [];
						$arwrk[1] = $rswrk->fields('df');
						$arwrk[2] = $rswrk->fields('df2');
						$this->salesrepid->ViewValue = $this->salesrepid->displayValue($arwrk);
						$rswrk->Close();
					} else {
						$this->salesrepid->ViewValue = $this->salesrepid->CurrentValue;
					}
				}
			} else {
				$this->salesrepid->ViewValue = NULL;
			}
			$this->salesrepid->ViewCustomAttributes = "";

			// currIDSettlement
			$this->currIDSettlement->ViewValue = $this->currIDSettlement->CurrentValue;
			$this->currIDSettlement->ViewCustomAttributes = "";

			// txid
			$this->txid->LinkCustomAttributes = "";
			$this->txid->HrefValue = "";
			$this->txid->TooltipValue = "";

			// merchantID
			$this->merchantID->LinkCustomAttributes = "";
			$this->merchantID->HrefValue = "";
			$this->merchantID->TooltipValue = "";

			// userID
			$this->_userID->LinkCustomAttributes = "";
			$this->_userID->HrefValue = "";
			$this->_userID->TooltipValue = "";

			// transferTime
			$this->transferTime->LinkCustomAttributes = "";
			$this->transferTime->HrefValue = "";
			$this->transferTime->TooltipValue = "";

			// merchantSurcharge
			$this->merchantSurcharge->LinkCustomAttributes = "";
			$this->merchantSurcharge->HrefValue = "";
			$this->merchantSurcharge->TooltipValue = "";

			// currID
			$this->currID->LinkCustomAttributes = "";
			$this->currID->HrefValue = "";
			$this->currID->TooltipValue = "";

			// purchaseAmount
			$this->purchaseAmount->LinkCustomAttributes = "";
			$this->purchaseAmount->HrefValue = "";
			$this->purchaseAmount->TooltipValue = "";

			// taxAmount
			$this->taxAmount->LinkCustomAttributes = "";
			$this->taxAmount->HrefValue = "";
			$this->taxAmount->TooltipValue = "";

			// tipAmount
			$this->tipAmount->LinkCustomAttributes = "";
			$this->tipAmount->HrefValue = "";
			$this->tipAmount->TooltipValue = "";

			// serviceFeeToCustomer
			$this->serviceFeeToCustomer->LinkCustomAttributes = "";
			$this->serviceFeeToCustomer->HrefValue = "";
			$this->serviceFeeToCustomer->TooltipValue = "";

			// TotalAmountForCustomer
			$this->TotalAmountForCustomer->LinkCustomAttributes = "";
			$this->TotalAmountForCustomer->HrefValue = "";
			$this->TotalAmountForCustomer->TooltipValue = "";

			// serviceFeeToMerchant
			$this->serviceFeeToMerchant->LinkCustomAttributes = "";
			$this->serviceFeeToMerchant->HrefValue = "";
			$this->serviceFeeToMerchant->TooltipValue = "";

			// status
			$this->status->LinkCustomAttributes = "";
			$this->status->HrefValue = "";
			$this->status->TooltipValue = "";

			// shoppingCartID
			$this->shoppingCartID->LinkCustomAttributes = "";
			$this->shoppingCartID->HrefValue = "";
			$this->shoppingCartID->TooltipValue = "";

			// merchantRefID
			$this->merchantRefID->LinkCustomAttributes = "";
			$this->merchantRefID->HrefValue = "";
			$this->merchantRefID->TooltipValue = "";

			// feeid
			$this->feeid->LinkCustomAttributes = "";
			$this->feeid->HrefValue = "";
			$this->feeid->TooltipValue = "";

			// ratetabletype
			$this->ratetabletype->LinkCustomAttributes = "";
			$this->ratetabletype->HrefValue = "";
			$this->ratetabletype->TooltipValue = "";

			// userpi
			$this->userpi->LinkCustomAttributes = "";
			$this->userpi->HrefValue = "";
			$this->userpi->TooltipValue = "";

			// piid
			$this->piid->LinkCustomAttributes = "";
			$this->piid->HrefValue = "";
			$this->piid->TooltipValue = "";

			// feesystemshare
			$this->feesystemshare->LinkCustomAttributes = "";
			$this->feesystemshare->HrefValue = "";
			$this->feesystemshare->TooltipValue = "";

			// feeexternalshare
			$this->feeexternalshare->LinkCustomAttributes = "";
			$this->feeexternalshare->HrefValue = "";
			$this->feeexternalshare->TooltipValue = "";

			// feefranchiseeshare
			$this->feefranchiseeshare->LinkCustomAttributes = "";
			$this->feefranchiseeshare->HrefValue = "";
			$this->feefranchiseeshare->TooltipValue = "";

			// feeresellershare
			$this->feeresellershare->LinkCustomAttributes = "";
			$this->feeresellershare->HrefValue = "";
			$this->feeresellershare->TooltipValue = "";

			// lastupdatetime
			$this->lastupdatetime->LinkCustomAttributes = "";
			$this->lastupdatetime->HrefValue = "";
			$this->lastupdatetime->TooltipValue = "";

			// expirationTimeInMinutes
			$this->expirationTimeInMinutes->LinkCustomAttributes = "";
			$this->expirationTimeInMinutes->HrefValue = "";
			$this->expirationTimeInMinutes->TooltipValue = "";

			// expirationTime
			$this->expirationTime->LinkCustomAttributes = "";
			$this->expirationTime->HrefValue = "";
			$this->expirationTime->TooltipValue = "";

			// itemdesc
			$this->itemdesc->LinkCustomAttributes = "";
			$this->itemdesc->HrefValue = "";
			$this->itemdesc->TooltipValue = "";

			// customeruserid
			$this->customeruserid->LinkCustomAttributes = "";
			$this->customeruserid->HrefValue = "";
			$this->customeruserid->TooltipValue = "";

			// paymentid
			$this->paymentid->LinkCustomAttributes = "";
			$this->paymentid->HrefValue = "";
			$this->paymentid->TooltipValue = "";

			// purchaseid
			$this->purchaseid->LinkCustomAttributes = "";
			$this->purchaseid->HrefValue = "";
			$this->purchaseid->TooltipValue = "";

			// eftid
			$this->eftid->LinkCustomAttributes = "";
			$this->eftid->HrefValue = "";
			$this->eftid->TooltipValue = "";

			// targetUserID
			$this->targetUserID->LinkCustomAttributes = "";
			$this->targetUserID->HrefValue = "";
			$this->targetUserID->TooltipValue = "";

			// messageType
			$this->messageType->LinkCustomAttributes = "";
			$this->messageType->HrefValue = "";
			$this->messageType->TooltipValue = "";

			// targetemail
			$this->targetemail->LinkCustomAttributes = "";
			$this->targetemail->HrefValue = "";
			$this->targetemail->TooltipValue = "";

			// targetpresentationcode
			$this->targetpresentationcode->LinkCustomAttributes = "";
			$this->targetpresentationcode->HrefValue = "";
			$this->targetpresentationcode->TooltipValue = "";

			// targetcomments
			$this->targetcomments->LinkCustomAttributes = "";
			$this->targetcomments->HrefValue = "";
			$this->targetcomments->TooltipValue = "";

			// targetrecipientname
			$this->targetrecipientname->LinkCustomAttributes = "";
			$this->targetrecipientname->HrefValue = "";
			$this->targetrecipientname->TooltipValue = "";

			// targetsendername
			$this->targetsendername->LinkCustomAttributes = "";
			$this->targetsendername->HrefValue = "";
			$this->targetsendername->TooltipValue = "";

			// salesrepid
			$this->salesrepid->LinkCustomAttributes = "";
			$this->salesrepid->HrefValue = "";
			$this->salesrepid->TooltipValue = "";

			// currIDSettlement
			$this->currIDSettlement->LinkCustomAttributes = "";
			$this->currIDSettlement->HrefValue = "";
			$this->currIDSettlement->TooltipValue = "";
		} elseif ($this->RowType == ROWTYPE_ADD) { // Add row

			// txid
			$this->txid->EditAttrs["class"] = "form-control";
			$this->txid->EditCustomAttributes = "";
			if (!$this->txid->Raw)
				$this->txid->CurrentValue = HtmlDecode($this->txid->CurrentValue);
			$this->txid->EditValue = HtmlEncode($this->txid->CurrentValue);
			$this->txid->PlaceHolder = RemoveHtml($this->txid->caption());

			// merchantID
			$this->merchantID->EditAttrs["class"] = "form-control";
			$this->merchantID->EditCustomAttributes = "";
			$this->merchantID->EditValue = HtmlEncode($this->merchantID->CurrentValue);
			$this->merchantID->PlaceHolder = RemoveHtml($this->merchantID->caption());

			// userID
			$this->_userID->EditAttrs["class"] = "form-control";
			$this->_userID->EditCustomAttributes = "";
			$this->_userID->EditValue = HtmlEncode($this->_userID->CurrentValue);
			$this->_userID->PlaceHolder = RemoveHtml($this->_userID->caption());

			// transferTime
			$this->transferTime->EditAttrs["class"] = "form-control";
			$this->transferTime->EditCustomAttributes = "";
			$this->transferTime->EditValue = HtmlEncode(FormatDateTime($this->transferTime->CurrentValue, 8));
			$this->transferTime->PlaceHolder = RemoveHtml($this->transferTime->caption());

			// merchantSurcharge
			$this->merchantSurcharge->EditAttrs["class"] = "form-control";
			$this->merchantSurcharge->EditCustomAttributes = "";
			$this->merchantSurcharge->EditValue = HtmlEncode($this->merchantSurcharge->CurrentValue);
			$this->merchantSurcharge->PlaceHolder = RemoveHtml($this->merchantSurcharge->caption());
			if (strval($this->merchantSurcharge->EditValue) != "" && is_numeric($this->merchantSurcharge->EditValue))
				$this->merchantSurcharge->EditValue = FormatNumber($this->merchantSurcharge->EditValue, -2, -2, -2, -2);
			

			// currID
			$this->currID->EditAttrs["class"] = "form-control";
			$this->currID->EditCustomAttributes = "";
			if (!$this->currID->Raw)
				$this->currID->CurrentValue = HtmlDecode($this->currID->CurrentValue);
			$this->currID->EditValue = HtmlEncode($this->currID->CurrentValue);
			$this->currID->PlaceHolder = RemoveHtml($this->currID->caption());

			// purchaseAmount
			$this->purchaseAmount->EditAttrs["class"] = "form-control";
			$this->purchaseAmount->EditCustomAttributes = "";
			$this->purchaseAmount->EditValue = HtmlEncode($this->purchaseAmount->CurrentValue);
			$this->purchaseAmount->PlaceHolder = RemoveHtml($this->purchaseAmount->caption());
			if (strval($this->purchaseAmount->EditValue) != "" && is_numeric($this->purchaseAmount->EditValue))
				$this->purchaseAmount->EditValue = FormatNumber($this->purchaseAmount->EditValue, -2, -2, -2, -2);
			

			// taxAmount
			$this->taxAmount->EditAttrs["class"] = "form-control";
			$this->taxAmount->EditCustomAttributes = "";
			$this->taxAmount->EditValue = HtmlEncode($this->taxAmount->CurrentValue);
			$this->taxAmount->PlaceHolder = RemoveHtml($this->taxAmount->caption());
			if (strval($this->taxAmount->EditValue) != "" && is_numeric($this->taxAmount->EditValue))
				$this->taxAmount->EditValue = FormatNumber($this->taxAmount->EditValue, -2, -2, -2, -2);
			

			// tipAmount
			$this->tipAmount->EditAttrs["class"] = "form-control";
			$this->tipAmount->EditCustomAttributes = "";
			$this->tipAmount->EditValue = HtmlEncode($this->tipAmount->CurrentValue);
			$this->tipAmount->PlaceHolder = RemoveHtml($this->tipAmount->caption());
			if (strval($this->tipAmount->EditValue) != "" && is_numeric($this->tipAmount->EditValue))
				$this->tipAmount->EditValue = FormatNumber($this->tipAmount->EditValue, -2, -2, -2, -2);
			

			// serviceFeeToCustomer
			$this->serviceFeeToCustomer->EditAttrs["class"] = "form-control";
			$this->serviceFeeToCustomer->EditCustomAttributes = "";
			$this->serviceFeeToCustomer->EditValue = HtmlEncode($this->serviceFeeToCustomer->CurrentValue);
			$this->serviceFeeToCustomer->PlaceHolder = RemoveHtml($this->serviceFeeToCustomer->caption());
			if (strval($this->serviceFeeToCustomer->EditValue) != "" && is_numeric($this->serviceFeeToCustomer->EditValue))
				$this->serviceFeeToCustomer->EditValue = FormatNumber($this->serviceFeeToCustomer->EditValue, -2, -2, -2, -2);
			

			// TotalAmountForCustomer
			$this->TotalAmountForCustomer->EditAttrs["class"] = "form-control";
			$this->TotalAmountForCustomer->EditCustomAttributes = "";
			$this->TotalAmountForCustomer->EditValue = HtmlEncode($this->TotalAmountForCustomer->CurrentValue);
			$this->TotalAmountForCustomer->PlaceHolder = RemoveHtml($this->TotalAmountForCustomer->caption());
			if (strval($this->TotalAmountForCustomer->EditValue) != "" && is_numeric($this->TotalAmountForCustomer->EditValue))
				$this->TotalAmountForCustomer->EditValue = FormatNumber($this->TotalAmountForCustomer->EditValue, -2, -2, -2, -2);
			

			// serviceFeeToMerchant
			$this->serviceFeeToMerchant->EditAttrs["class"] = "form-control";
			$this->serviceFeeToMerchant->EditCustomAttributes = "";
			$this->serviceFeeToMerchant->EditValue = HtmlEncode($this->serviceFeeToMerchant->CurrentValue);
			$this->serviceFeeToMerchant->PlaceHolder = RemoveHtml($this->serviceFeeToMerchant->caption());
			if (strval($this->serviceFeeToMerchant->EditValue) != "" && is_numeric($this->serviceFeeToMerchant->EditValue))
				$this->serviceFeeToMerchant->EditValue = FormatNumber($this->serviceFeeToMerchant->EditValue, -2, -2, -2, -2);
			

			// status
			$this->status->EditAttrs["class"] = "form-control";
			$this->status->EditCustomAttributes = "";
			$this->status->EditValue = $this->status->options(TRUE);

			// shoppingCartID
			$this->shoppingCartID->EditAttrs["class"] = "form-control";
			$this->shoppingCartID->EditCustomAttributes = "";
			if (!$this->shoppingCartID->Raw)
				$this->shoppingCartID->CurrentValue = HtmlDecode($this->shoppingCartID->CurrentValue);
			$this->shoppingCartID->EditValue = HtmlEncode($this->shoppingCartID->CurrentValue);
			$this->shoppingCartID->PlaceHolder = RemoveHtml($this->shoppingCartID->caption());

			// merchantRefID
			$this->merchantRefID->EditAttrs["class"] = "form-control";
			$this->merchantRefID->EditCustomAttributes = "";
			if (!$this->merchantRefID->Raw)
				$this->merchantRefID->CurrentValue = HtmlDecode($this->merchantRefID->CurrentValue);
			$this->merchantRefID->EditValue = HtmlEncode($this->merchantRefID->CurrentValue);
			$this->merchantRefID->PlaceHolder = RemoveHtml($this->merchantRefID->caption());

			// feeid
			$this->feeid->EditAttrs["class"] = "form-control";
			$this->feeid->EditCustomAttributes = "";
			$this->feeid->EditValue = HtmlEncode($this->feeid->CurrentValue);
			$this->feeid->PlaceHolder = RemoveHtml($this->feeid->caption());

			// ratetabletype
			$this->ratetabletype->EditAttrs["class"] = "form-control";
			$this->ratetabletype->EditCustomAttributes = "";
			$this->ratetabletype->EditValue = HtmlEncode($this->ratetabletype->CurrentValue);
			$this->ratetabletype->PlaceHolder = RemoveHtml($this->ratetabletype->caption());

			// userpi
			$this->userpi->EditAttrs["class"] = "form-control";
			$this->userpi->EditCustomAttributes = "";
			$this->userpi->EditValue = HtmlEncode($this->userpi->CurrentValue);
			$this->userpi->PlaceHolder = RemoveHtml($this->userpi->caption());

			// piid
			$this->piid->EditAttrs["class"] = "form-control";
			$this->piid->EditCustomAttributes = "";
			$curVal = trim(strval($this->piid->CurrentValue));
			if ($curVal != "")
				$this->piid->ViewValue = $this->piid->lookupCacheOption($curVal);
			else
				$this->piid->ViewValue = $this->piid->Lookup !== NULL && is_array($this->piid->Lookup->Options) ? $curVal : NULL;
			if ($this->piid->ViewValue !== NULL) { // Load from cache
				$this->piid->EditValue = array_values($this->piid->Lookup->Options);
			} else { // Lookup from database
				if ($curVal == "") {
					$filterWrk = "0=1";
				} else {
					$filterWrk = "`id`" . SearchString("=", $this->piid->CurrentValue, DATATYPE_NUMBER, "_4payreference");
				}
				$sqlWrk = $this->piid->Lookup->getSql(TRUE, $filterWrk, '', $this);
				$rswrk = Conn("_4payreference")->execute($sqlWrk);
				$arwrk = $rswrk ? $rswrk->getRows() : [];
				if ($rswrk)
					$rswrk->close();
				$this->piid->EditValue = $arwrk;
			}

			// feesystemshare
			$this->feesystemshare->EditAttrs["class"] = "form-control";
			$this->feesystemshare->EditCustomAttributes = "";
			$this->feesystemshare->EditValue = HtmlEncode($this->feesystemshare->CurrentValue);
			$this->feesystemshare->PlaceHolder = RemoveHtml($this->feesystemshare->caption());
			if (strval($this->feesystemshare->EditValue) != "" && is_numeric($this->feesystemshare->EditValue))
				$this->feesystemshare->EditValue = FormatNumber($this->feesystemshare->EditValue, -2, -2, -2, -2);
			

			// feeexternalshare
			$this->feeexternalshare->EditAttrs["class"] = "form-control";
			$this->feeexternalshare->EditCustomAttributes = "";
			$this->feeexternalshare->EditValue = HtmlEncode($this->feeexternalshare->CurrentValue);
			$this->feeexternalshare->PlaceHolder = RemoveHtml($this->feeexternalshare->caption());
			if (strval($this->feeexternalshare->EditValue) != "" && is_numeric($this->feeexternalshare->EditValue))
				$this->feeexternalshare->EditValue = FormatNumber($this->feeexternalshare->EditValue, -2, -2, -2, -2);
			

			// feefranchiseeshare
			$this->feefranchiseeshare->EditAttrs["class"] = "form-control";
			$this->feefranchiseeshare->EditCustomAttributes = "";
			$this->feefranchiseeshare->EditValue = HtmlEncode($this->feefranchiseeshare->CurrentValue);
			$this->feefranchiseeshare->PlaceHolder = RemoveHtml($this->feefranchiseeshare->caption());
			if (strval($this->feefranchiseeshare->EditValue) != "" && is_numeric($this->feefranchiseeshare->EditValue))
				$this->feefranchiseeshare->EditValue = FormatNumber($this->feefranchiseeshare->EditValue, -2, -2, -2, -2);
			

			// feeresellershare
			$this->feeresellershare->EditAttrs["class"] = "form-control";
			$this->feeresellershare->EditCustomAttributes = "";
			$this->feeresellershare->EditValue = HtmlEncode($this->feeresellershare->CurrentValue);
			$this->feeresellershare->PlaceHolder = RemoveHtml($this->feeresellershare->caption());
			if (strval($this->feeresellershare->EditValue) != "" && is_numeric($this->feeresellershare->EditValue))
				$this->feeresellershare->EditValue = FormatNumber($this->feeresellershare->EditValue, -2, -2, -2, -2);
			

			// lastupdatetime
			$this->lastupdatetime->EditAttrs["class"] = "form-control";
			$this->lastupdatetime->EditCustomAttributes = "";
			$this->lastupdatetime->EditValue = HtmlEncode(FormatDateTime($this->lastupdatetime->CurrentValue, 8));
			$this->lastupdatetime->PlaceHolder = RemoveHtml($this->lastupdatetime->caption());

			// expirationTimeInMinutes
			$this->expirationTimeInMinutes->EditAttrs["class"] = "form-control";
			$this->expirationTimeInMinutes->EditCustomAttributes = "";
			$this->expirationTimeInMinutes->EditValue = HtmlEncode($this->expirationTimeInMinutes->CurrentValue);
			$this->expirationTimeInMinutes->PlaceHolder = RemoveHtml($this->expirationTimeInMinutes->caption());

			// expirationTime
			$this->expirationTime->EditAttrs["class"] = "form-control";
			$this->expirationTime->EditCustomAttributes = "";
			$this->expirationTime->EditValue = HtmlEncode(FormatDateTime($this->expirationTime->CurrentValue, 8));
			$this->expirationTime->PlaceHolder = RemoveHtml($this->expirationTime->caption());

			// itemdesc
			$this->itemdesc->EditAttrs["class"] = "form-control";
			$this->itemdesc->EditCustomAttributes = "";
			if (!$this->itemdesc->Raw)
				$this->itemdesc->CurrentValue = HtmlDecode($this->itemdesc->CurrentValue);
			$this->itemdesc->EditValue = HtmlEncode($this->itemdesc->CurrentValue);
			$this->itemdesc->PlaceHolder = RemoveHtml($this->itemdesc->caption());

			// customeruserid
			$this->customeruserid->EditAttrs["class"] = "form-control";
			$this->customeruserid->EditCustomAttributes = "";
			$this->customeruserid->EditValue = HtmlEncode($this->customeruserid->CurrentValue);
			$this->customeruserid->PlaceHolder = RemoveHtml($this->customeruserid->caption());

			// paymentid
			$this->paymentid->EditAttrs["class"] = "form-control";
			$this->paymentid->EditCustomAttributes = "";
			$this->paymentid->EditValue = HtmlEncode($this->paymentid->CurrentValue);
			$this->paymentid->PlaceHolder = RemoveHtml($this->paymentid->caption());

			// purchaseid
			$this->purchaseid->EditAttrs["class"] = "form-control";
			$this->purchaseid->EditCustomAttributes = "";
			$this->purchaseid->EditValue = HtmlEncode($this->purchaseid->CurrentValue);
			$this->purchaseid->PlaceHolder = RemoveHtml($this->purchaseid->caption());

			// eftid
			$this->eftid->EditAttrs["class"] = "form-control";
			$this->eftid->EditCustomAttributes = "";
			$this->eftid->EditValue = HtmlEncode($this->eftid->CurrentValue);
			$this->eftid->PlaceHolder = RemoveHtml($this->eftid->caption());

			// targetUserID
			$this->targetUserID->EditAttrs["class"] = "form-control";
			$this->targetUserID->EditCustomAttributes = "";
			$this->targetUserID->EditValue = HtmlEncode($this->targetUserID->CurrentValue);
			$this->targetUserID->PlaceHolder = RemoveHtml($this->targetUserID->caption());

			// messageType
			$this->messageType->EditAttrs["class"] = "form-control";
			$this->messageType->EditCustomAttributes = "";
			$this->messageType->EditValue = HtmlEncode($this->messageType->CurrentValue);
			$this->messageType->PlaceHolder = RemoveHtml($this->messageType->caption());

			// targetemail
			$this->targetemail->EditAttrs["class"] = "form-control";
			$this->targetemail->EditCustomAttributes = "";
			if (!$this->targetemail->Raw)
				$this->targetemail->CurrentValue = HtmlDecode($this->targetemail->CurrentValue);
			$this->targetemail->EditValue = HtmlEncode($this->targetemail->CurrentValue);
			$this->targetemail->PlaceHolder = RemoveHtml($this->targetemail->caption());

			// targetpresentationcode
			$this->targetpresentationcode->EditAttrs["class"] = "form-control";
			$this->targetpresentationcode->EditCustomAttributes = "";
			$this->targetpresentationcode->EditValue = HtmlEncode($this->targetpresentationcode->CurrentValue);
			$this->targetpresentationcode->PlaceHolder = RemoveHtml($this->targetpresentationcode->caption());

			// targetcomments
			$this->targetcomments->EditAttrs["class"] = "form-control";
			$this->targetcomments->EditCustomAttributes = "";
			if (!$this->targetcomments->Raw)
				$this->targetcomments->CurrentValue = HtmlDecode($this->targetcomments->CurrentValue);
			$this->targetcomments->EditValue = HtmlEncode($this->targetcomments->CurrentValue);
			$this->targetcomments->PlaceHolder = RemoveHtml($this->targetcomments->caption());

			// targetrecipientname
			$this->targetrecipientname->EditAttrs["class"] = "form-control";
			$this->targetrecipientname->EditCustomAttributes = "";
			if (!$this->targetrecipientname->Raw)
				$this->targetrecipientname->CurrentValue = HtmlDecode($this->targetrecipientname->CurrentValue);
			$this->targetrecipientname->EditValue = HtmlEncode($this->targetrecipientname->CurrentValue);
			$this->targetrecipientname->PlaceHolder = RemoveHtml($this->targetrecipientname->caption());

			// targetsendername
			$this->targetsendername->EditAttrs["class"] = "form-control";
			$this->targetsendername->EditCustomAttributes = "";
			if (!$this->targetsendername->Raw)
				$this->targetsendername->CurrentValue = HtmlDecode($this->targetsendername->CurrentValue);
			$this->targetsendername->EditValue = HtmlEncode($this->targetsendername->CurrentValue);
			$this->targetsendername->PlaceHolder = RemoveHtml($this->targetsendername->caption());

			// salesrepid
			$this->salesrepid->EditAttrs["class"] = "form-control";
			$this->salesrepid->EditCustomAttributes = "";
			$this->salesrepid->EditValue = HtmlEncode($this->salesrepid->CurrentValue);
			$curVal = strval($this->salesrepid->CurrentValue);
			if ($curVal != "") {
				$this->salesrepid->EditValue = $this->salesrepid->lookupCacheOption($curVal);
				if ($this->salesrepid->EditValue === NULL) { // Lookup from database
					$filterWrk = "`id`" . SearchString("=", $curVal, DATATYPE_NUMBER, "");
					$sqlWrk = $this->salesrepid->Lookup->getSql(FALSE, $filterWrk, '', $this);
					$rswrk = Conn()->execute($sqlWrk);
					if ($rswrk && !$rswrk->EOF) { // Lookup values found
						$arwrk = [];
						$arwrk[1] = HtmlEncode($rswrk->fields('df'));
						$arwrk[2] = HtmlEncode($rswrk->fields('df2'));
						$this->salesrepid->EditValue = $this->salesrepid->displayValue($arwrk);
						$rswrk->Close();
					} else {
						$this->salesrepid->EditValue = HtmlEncode($this->salesrepid->CurrentValue);
					}
				}
			} else {
				$this->salesrepid->EditValue = NULL;
			}
			$this->salesrepid->PlaceHolder = RemoveHtml($this->salesrepid->caption());

			// currIDSettlement
			$this->currIDSettlement->EditAttrs["class"] = "form-control";
			$this->currIDSettlement->EditCustomAttributes = "";
			if (!$this->currIDSettlement->Raw)
				$this->currIDSettlement->CurrentValue = HtmlDecode($this->currIDSettlement->CurrentValue);
			$this->currIDSettlement->EditValue = HtmlEncode($this->currIDSettlement->CurrentValue);
			$this->currIDSettlement->PlaceHolder = RemoveHtml($this->currIDSettlement->caption());

			// Add refer script
			// txid

			$this->txid->LinkCustomAttributes = "";
			$this->txid->HrefValue = "";

			// merchantID
			$this->merchantID->LinkCustomAttributes = "";
			$this->merchantID->HrefValue = "";

			// userID
			$this->_userID->LinkCustomAttributes = "";
			$this->_userID->HrefValue = "";

			// transferTime
			$this->transferTime->LinkCustomAttributes = "";
			$this->transferTime->HrefValue = "";

			// merchantSurcharge
			$this->merchantSurcharge->LinkCustomAttributes = "";
			$this->merchantSurcharge->HrefValue = "";

			// currID
			$this->currID->LinkCustomAttributes = "";
			$this->currID->HrefValue = "";

			// purchaseAmount
			$this->purchaseAmount->LinkCustomAttributes = "";
			$this->purchaseAmount->HrefValue = "";

			// taxAmount
			$this->taxAmount->LinkCustomAttributes = "";
			$this->taxAmount->HrefValue = "";

			// tipAmount
			$this->tipAmount->LinkCustomAttributes = "";
			$this->tipAmount->HrefValue = "";

			// serviceFeeToCustomer
			$this->serviceFeeToCustomer->LinkCustomAttributes = "";
			$this->serviceFeeToCustomer->HrefValue = "";

			// TotalAmountForCustomer
			$this->TotalAmountForCustomer->LinkCustomAttributes = "";
			$this->TotalAmountForCustomer->HrefValue = "";

			// serviceFeeToMerchant
			$this->serviceFeeToMerchant->LinkCustomAttributes = "";
			$this->serviceFeeToMerchant->HrefValue = "";

			// status
			$this->status->LinkCustomAttributes = "";
			$this->status->HrefValue = "";

			// shoppingCartID
			$this->shoppingCartID->LinkCustomAttributes = "";
			$this->shoppingCartID->HrefValue = "";

			// merchantRefID
			$this->merchantRefID->LinkCustomAttributes = "";
			$this->merchantRefID->HrefValue = "";

			// feeid
			$this->feeid->LinkCustomAttributes = "";
			$this->feeid->HrefValue = "";

			// ratetabletype
			$this->ratetabletype->LinkCustomAttributes = "";
			$this->ratetabletype->HrefValue = "";

			// userpi
			$this->userpi->LinkCustomAttributes = "";
			$this->userpi->HrefValue = "";

			// piid
			$this->piid->LinkCustomAttributes = "";
			$this->piid->HrefValue = "";

			// feesystemshare
			$this->feesystemshare->LinkCustomAttributes = "";
			$this->feesystemshare->HrefValue = "";

			// feeexternalshare
			$this->feeexternalshare->LinkCustomAttributes = "";
			$this->feeexternalshare->HrefValue = "";

			// feefranchiseeshare
			$this->feefranchiseeshare->LinkCustomAttributes = "";
			$this->feefranchiseeshare->HrefValue = "";

			// feeresellershare
			$this->feeresellershare->LinkCustomAttributes = "";
			$this->feeresellershare->HrefValue = "";

			// lastupdatetime
			$this->lastupdatetime->LinkCustomAttributes = "";
			$this->lastupdatetime->HrefValue = "";

			// expirationTimeInMinutes
			$this->expirationTimeInMinutes->LinkCustomAttributes = "";
			$this->expirationTimeInMinutes->HrefValue = "";

			// expirationTime
			$this->expirationTime->LinkCustomAttributes = "";
			$this->expirationTime->HrefValue = "";

			// itemdesc
			$this->itemdesc->LinkCustomAttributes = "";
			$this->itemdesc->HrefValue = "";

			// customeruserid
			$this->customeruserid->LinkCustomAttributes = "";
			$this->customeruserid->HrefValue = "";

			// paymentid
			$this->paymentid->LinkCustomAttributes = "";
			$this->paymentid->HrefValue = "";

			// purchaseid
			$this->purchaseid->LinkCustomAttributes = "";
			$this->purchaseid->HrefValue = "";

			// eftid
			$this->eftid->LinkCustomAttributes = "";
			$this->eftid->HrefValue = "";

			// targetUserID
			$this->targetUserID->LinkCustomAttributes = "";
			$this->targetUserID->HrefValue = "";

			// messageType
			$this->messageType->LinkCustomAttributes = "";
			$this->messageType->HrefValue = "";

			// targetemail
			$this->targetemail->LinkCustomAttributes = "";
			$this->targetemail->HrefValue = "";

			// targetpresentationcode
			$this->targetpresentationcode->LinkCustomAttributes = "";
			$this->targetpresentationcode->HrefValue = "";

			// targetcomments
			$this->targetcomments->LinkCustomAttributes = "";
			$this->targetcomments->HrefValue = "";

			// targetrecipientname
			$this->targetrecipientname->LinkCustomAttributes = "";
			$this->targetrecipientname->HrefValue = "";

			// targetsendername
			$this->targetsendername->LinkCustomAttributes = "";
			$this->targetsendername->HrefValue = "";

			// salesrepid
			$this->salesrepid->LinkCustomAttributes = "";
			$this->salesrepid->HrefValue = "";

			// currIDSettlement
			$this->currIDSettlement->LinkCustomAttributes = "";
			$this->currIDSettlement->HrefValue = "";
		}
		if ($this->RowType == ROWTYPE_ADD || $this->RowType == ROWTYPE_EDIT || $this->RowType == ROWTYPE_SEARCH) // Add/Edit/Search row
			$this->setupFieldTitles();

		// Call Row Rendered event
		if ($this->RowType != ROWTYPE_AGGREGATEINIT)
			$this->Row_Rendered();
	}

	// Validate form
	protected function validateForm()
	{
		global $Language, $FormError;

		// Initialize form error message
		$FormError = "";

		// Check if validation required
		if (!Config("SERVER_VALIDATE"))
			return ($FormError == "");
		if ($this->txid->Required) {
			if (!$this->txid->IsDetailKey && $this->txid->FormValue != NULL && $this->txid->FormValue == "") {
				AddMessage($FormError, str_replace("%s", $this->txid->caption(), $this->txid->RequiredErrorMessage));
			}
		}
		if ($this->merchantID->Required) {
			if (!$this->merchantID->IsDetailKey && $this->merchantID->FormValue != NULL && $this->merchantID->FormValue == "") {
				AddMessage($FormError, str_replace("%s", $this->merchantID->caption(), $this->merchantID->RequiredErrorMessage));
			}
		}
		if (!CheckInteger($this->merchantID->FormValue)) {
			AddMessage($FormError, $this->merchantID->errorMessage());
		}
		if ($this->_userID->Required) {
			if (!$this->_userID->IsDetailKey && $this->_userID->FormValue != NULL && $this->_userID->FormValue == "") {
				AddMessage($FormError, str_replace("%s", $this->_userID->caption(), $this->_userID->RequiredErrorMessage));
			}
		}
		if (!CheckInteger($this->_userID->FormValue)) {
			AddMessage($FormError, $this->_userID->errorMessage());
		}
		if ($this->transferTime->Required) {
			if (!$this->transferTime->IsDetailKey && $this->transferTime->FormValue != NULL && $this->transferTime->FormValue == "") {
				AddMessage($FormError, str_replace("%s", $this->transferTime->caption(), $this->transferTime->RequiredErrorMessage));
			}
		}
		if (!CheckDate($this->transferTime->FormValue)) {
			AddMessage($FormError, $this->transferTime->errorMessage());
		}
		if ($this->merchantSurcharge->Required) {
			if (!$this->merchantSurcharge->IsDetailKey && $this->merchantSurcharge->FormValue != NULL && $this->merchantSurcharge->FormValue == "") {
				AddMessage($FormError, str_replace("%s", $this->merchantSurcharge->caption(), $this->merchantSurcharge->RequiredErrorMessage));
			}
		}
		if (!CheckNumber($this->merchantSurcharge->FormValue)) {
			AddMessage($FormError, $this->merchantSurcharge->errorMessage());
		}
		if ($this->currID->Required) {
			if (!$this->currID->IsDetailKey && $this->currID->FormValue != NULL && $this->currID->FormValue == "") {
				AddMessage($FormError, str_replace("%s", $this->currID->caption(), $this->currID->RequiredErrorMessage));
			}
		}
		if ($this->purchaseAmount->Required) {
			if (!$this->purchaseAmount->IsDetailKey && $this->purchaseAmount->FormValue != NULL && $this->purchaseAmount->FormValue == "") {
				AddMessage($FormError, str_replace("%s", $this->purchaseAmount->caption(), $this->purchaseAmount->RequiredErrorMessage));
			}
		}
		if (!CheckNumber($this->purchaseAmount->FormValue)) {
			AddMessage($FormError, $this->purchaseAmount->errorMessage());
		}
		if ($this->taxAmount->Required) {
			if (!$this->taxAmount->IsDetailKey && $this->taxAmount->FormValue != NULL && $this->taxAmount->FormValue == "") {
				AddMessage($FormError, str_replace("%s", $this->taxAmount->caption(), $this->taxAmount->RequiredErrorMessage));
			}
		}
		if (!CheckNumber($this->taxAmount->FormValue)) {
			AddMessage($FormError, $this->taxAmount->errorMessage());
		}
		if ($this->tipAmount->Required) {
			if (!$this->tipAmount->IsDetailKey && $this->tipAmount->FormValue != NULL && $this->tipAmount->FormValue == "") {
				AddMessage($FormError, str_replace("%s", $this->tipAmount->caption(), $this->tipAmount->RequiredErrorMessage));
			}
		}
		if (!CheckNumber($this->tipAmount->FormValue)) {
			AddMessage($FormError, $this->tipAmount->errorMessage());
		}
		if ($this->serviceFeeToCustomer->Required) {
			if (!$this->serviceFeeToCustomer->IsDetailKey && $this->serviceFeeToCustomer->FormValue != NULL && $this->serviceFeeToCustomer->FormValue == "") {
				AddMessage($FormError, str_replace("%s", $this->serviceFeeToCustomer->caption(), $this->serviceFeeToCustomer->RequiredErrorMessage));
			}
		}
		if (!CheckNumber($this->serviceFeeToCustomer->FormValue)) {
			AddMessage($FormError, $this->serviceFeeToCustomer->errorMessage());
		}
		if ($this->TotalAmountForCustomer->Required) {
			if (!$this->TotalAmountForCustomer->IsDetailKey && $this->TotalAmountForCustomer->FormValue != NULL && $this->TotalAmountForCustomer->FormValue == "") {
				AddMessage($FormError, str_replace("%s", $this->TotalAmountForCustomer->caption(), $this->TotalAmountForCustomer->RequiredErrorMessage));
			}
		}
		if (!CheckNumber($this->TotalAmountForCustomer->FormValue)) {
			AddMessage($FormError, $this->TotalAmountForCustomer->errorMessage());
		}
		if ($this->serviceFeeToMerchant->Required) {
			if (!$this->serviceFeeToMerchant->IsDetailKey && $this->serviceFeeToMerchant->FormValue != NULL && $this->serviceFeeToMerchant->FormValue == "") {
				AddMessage($FormError, str_replace("%s", $this->serviceFeeToMerchant->caption(), $this->serviceFeeToMerchant->RequiredErrorMessage));
			}
		}
		if (!CheckNumber($this->serviceFeeToMerchant->FormValue)) {
			AddMessage($FormError, $this->serviceFeeToMerchant->errorMessage());
		}
		if ($this->status->Required) {
			if (!$this->status->IsDetailKey && $this->status->FormValue != NULL && $this->status->FormValue == "") {
				AddMessage($FormError, str_replace("%s", $this->status->caption(), $this->status->RequiredErrorMessage));
			}
		}
		if ($this->shoppingCartID->Required) {
			if (!$this->shoppingCartID->IsDetailKey && $this->shoppingCartID->FormValue != NULL && $this->shoppingCartID->FormValue == "") {
				AddMessage($FormError, str_replace("%s", $this->shoppingCartID->caption(), $this->shoppingCartID->RequiredErrorMessage));
			}
		}
		if ($this->merchantRefID->Required) {
			if (!$this->merchantRefID->IsDetailKey && $this->merchantRefID->FormValue != NULL && $this->merchantRefID->FormValue == "") {
				AddMessage($FormError, str_replace("%s", $this->merchantRefID->caption(), $this->merchantRefID->RequiredErrorMessage));
			}
		}
		if ($this->feeid->Required) {
			if (!$this->feeid->IsDetailKey && $this->feeid->FormValue != NULL && $this->feeid->FormValue == "") {
				AddMessage($FormError, str_replace("%s", $this->feeid->caption(), $this->feeid->RequiredErrorMessage));
			}
		}
		if (!CheckInteger($this->feeid->FormValue)) {
			AddMessage($FormError, $this->feeid->errorMessage());
		}
		if ($this->ratetabletype->Required) {
			if (!$this->ratetabletype->IsDetailKey && $this->ratetabletype->FormValue != NULL && $this->ratetabletype->FormValue == "") {
				AddMessage($FormError, str_replace("%s", $this->ratetabletype->caption(), $this->ratetabletype->RequiredErrorMessage));
			}
		}
		if (!CheckInteger($this->ratetabletype->FormValue)) {
			AddMessage($FormError, $this->ratetabletype->errorMessage());
		}
		if ($this->userpi->Required) {
			if (!$this->userpi->IsDetailKey && $this->userpi->FormValue != NULL && $this->userpi->FormValue == "") {
				AddMessage($FormError, str_replace("%s", $this->userpi->caption(), $this->userpi->RequiredErrorMessage));
			}
		}
		if (!CheckInteger($this->userpi->FormValue)) {
			AddMessage($FormError, $this->userpi->errorMessage());
		}
		if ($this->piid->Required) {
			if (!$this->piid->IsDetailKey && $this->piid->FormValue != NULL && $this->piid->FormValue == "") {
				AddMessage($FormError, str_replace("%s", $this->piid->caption(), $this->piid->RequiredErrorMessage));
			}
		}
		if ($this->feesystemshare->Required) {
			if (!$this->feesystemshare->IsDetailKey && $this->feesystemshare->FormValue != NULL && $this->feesystemshare->FormValue == "") {
				AddMessage($FormError, str_replace("%s", $this->feesystemshare->caption(), $this->feesystemshare->RequiredErrorMessage));
			}
		}
		if (!CheckNumber($this->feesystemshare->FormValue)) {
			AddMessage($FormError, $this->feesystemshare->errorMessage());
		}
		if ($this->feeexternalshare->Required) {
			if (!$this->feeexternalshare->IsDetailKey && $this->feeexternalshare->FormValue != NULL && $this->feeexternalshare->FormValue == "") {
				AddMessage($FormError, str_replace("%s", $this->feeexternalshare->caption(), $this->feeexternalshare->RequiredErrorMessage));
			}
		}
		if (!CheckNumber($this->feeexternalshare->FormValue)) {
			AddMessage($FormError, $this->feeexternalshare->errorMessage());
		}
		if ($this->feefranchiseeshare->Required) {
			if (!$this->feefranchiseeshare->IsDetailKey && $this->feefranchiseeshare->FormValue != NULL && $this->feefranchiseeshare->FormValue == "") {
				AddMessage($FormError, str_replace("%s", $this->feefranchiseeshare->caption(), $this->feefranchiseeshare->RequiredErrorMessage));
			}
		}
		if (!CheckNumber($this->feefranchiseeshare->FormValue)) {
			AddMessage($FormError, $this->feefranchiseeshare->errorMessage());
		}
		if ($this->feeresellershare->Required) {
			if (!$this->feeresellershare->IsDetailKey && $this->feeresellershare->FormValue != NULL && $this->feeresellershare->FormValue == "") {
				AddMessage($FormError, str_replace("%s", $this->feeresellershare->caption(), $this->feeresellershare->RequiredErrorMessage));
			}
		}
		if (!CheckNumber($this->feeresellershare->FormValue)) {
			AddMessage($FormError, $this->feeresellershare->errorMessage());
		}
		if ($this->lastupdatetime->Required) {
			if (!$this->lastupdatetime->IsDetailKey && $this->lastupdatetime->FormValue != NULL && $this->lastupdatetime->FormValue == "") {
				AddMessage($FormError, str_replace("%s", $this->lastupdatetime->caption(), $this->lastupdatetime->RequiredErrorMessage));
			}
		}
		if (!CheckDate($this->lastupdatetime->FormValue)) {
			AddMessage($FormError, $this->lastupdatetime->errorMessage());
		}
		if ($this->expirationTimeInMinutes->Required) {
			if (!$this->expirationTimeInMinutes->IsDetailKey && $this->expirationTimeInMinutes->FormValue != NULL && $this->expirationTimeInMinutes->FormValue == "") {
				AddMessage($FormError, str_replace("%s", $this->expirationTimeInMinutes->caption(), $this->expirationTimeInMinutes->RequiredErrorMessage));
			}
		}
		if (!CheckInteger($this->expirationTimeInMinutes->FormValue)) {
			AddMessage($FormError, $this->expirationTimeInMinutes->errorMessage());
		}
		if ($this->expirationTime->Required) {
			if (!$this->expirationTime->IsDetailKey && $this->expirationTime->FormValue != NULL && $this->expirationTime->FormValue == "") {
				AddMessage($FormError, str_replace("%s", $this->expirationTime->caption(), $this->expirationTime->RequiredErrorMessage));
			}
		}
		if (!CheckDate($this->expirationTime->FormValue)) {
			AddMessage($FormError, $this->expirationTime->errorMessage());
		}
		if ($this->itemdesc->Required) {
			if (!$this->itemdesc->IsDetailKey && $this->itemdesc->FormValue != NULL && $this->itemdesc->FormValue == "") {
				AddMessage($FormError, str_replace("%s", $this->itemdesc->caption(), $this->itemdesc->RequiredErrorMessage));
			}
		}
		if ($this->customeruserid->Required) {
			if (!$this->customeruserid->IsDetailKey && $this->customeruserid->FormValue != NULL && $this->customeruserid->FormValue == "") {
				AddMessage($FormError, str_replace("%s", $this->customeruserid->caption(), $this->customeruserid->RequiredErrorMessage));
			}
		}
		if (!CheckInteger($this->customeruserid->FormValue)) {
			AddMessage($FormError, $this->customeruserid->errorMessage());
		}
		if ($this->paymentid->Required) {
			if (!$this->paymentid->IsDetailKey && $this->paymentid->FormValue != NULL && $this->paymentid->FormValue == "") {
				AddMessage($FormError, str_replace("%s", $this->paymentid->caption(), $this->paymentid->RequiredErrorMessage));
			}
		}
		if (!CheckInteger($this->paymentid->FormValue)) {
			AddMessage($FormError, $this->paymentid->errorMessage());
		}
		if ($this->purchaseid->Required) {
			if (!$this->purchaseid->IsDetailKey && $this->purchaseid->FormValue != NULL && $this->purchaseid->FormValue == "") {
				AddMessage($FormError, str_replace("%s", $this->purchaseid->caption(), $this->purchaseid->RequiredErrorMessage));
			}
		}
		if (!CheckInteger($this->purchaseid->FormValue)) {
			AddMessage($FormError, $this->purchaseid->errorMessage());
		}
		if ($this->eftid->Required) {
			if (!$this->eftid->IsDetailKey && $this->eftid->FormValue != NULL && $this->eftid->FormValue == "") {
				AddMessage($FormError, str_replace("%s", $this->eftid->caption(), $this->eftid->RequiredErrorMessage));
			}
		}
		if (!CheckInteger($this->eftid->FormValue)) {
			AddMessage($FormError, $this->eftid->errorMessage());
		}
		if ($this->targetUserID->Required) {
			if (!$this->targetUserID->IsDetailKey && $this->targetUserID->FormValue != NULL && $this->targetUserID->FormValue == "") {
				AddMessage($FormError, str_replace("%s", $this->targetUserID->caption(), $this->targetUserID->RequiredErrorMessage));
			}
		}
		if (!CheckInteger($this->targetUserID->FormValue)) {
			AddMessage($FormError, $this->targetUserID->errorMessage());
		}
		if ($this->messageType->Required) {
			if (!$this->messageType->IsDetailKey && $this->messageType->FormValue != NULL && $this->messageType->FormValue == "") {
				AddMessage($FormError, str_replace("%s", $this->messageType->caption(), $this->messageType->RequiredErrorMessage));
			}
		}
		if (!CheckInteger($this->messageType->FormValue)) {
			AddMessage($FormError, $this->messageType->errorMessage());
		}
		if ($this->targetemail->Required) {
			if (!$this->targetemail->IsDetailKey && $this->targetemail->FormValue != NULL && $this->targetemail->FormValue == "") {
				AddMessage($FormError, str_replace("%s", $this->targetemail->caption(), $this->targetemail->RequiredErrorMessage));
			}
		}
		if ($this->targetpresentationcode->Required) {
			if (!$this->targetpresentationcode->IsDetailKey && $this->targetpresentationcode->FormValue != NULL && $this->targetpresentationcode->FormValue == "") {
				AddMessage($FormError, str_replace("%s", $this->targetpresentationcode->caption(), $this->targetpresentationcode->RequiredErrorMessage));
			}
		}
		if (!CheckInteger($this->targetpresentationcode->FormValue)) {
			AddMessage($FormError, $this->targetpresentationcode->errorMessage());
		}
		if ($this->targetcomments->Required) {
			if (!$this->targetcomments->IsDetailKey && $this->targetcomments->FormValue != NULL && $this->targetcomments->FormValue == "") {
				AddMessage($FormError, str_replace("%s", $this->targetcomments->caption(), $this->targetcomments->RequiredErrorMessage));
			}
		}
		if ($this->targetrecipientname->Required) {
			if (!$this->targetrecipientname->IsDetailKey && $this->targetrecipientname->FormValue != NULL && $this->targetrecipientname->FormValue == "") {
				AddMessage($FormError, str_replace("%s", $this->targetrecipientname->caption(), $this->targetrecipientname->RequiredErrorMessage));
			}
		}
		if ($this->targetsendername->Required) {
			if (!$this->targetsendername->IsDetailKey && $this->targetsendername->FormValue != NULL && $this->targetsendername->FormValue == "") {
				AddMessage($FormError, str_replace("%s", $this->targetsendername->caption(), $this->targetsendername->RequiredErrorMessage));
			}
		}
		if ($this->salesrepid->Required) {
			if (!$this->salesrepid->IsDetailKey && $this->salesrepid->FormValue != NULL && $this->salesrepid->FormValue == "") {
				AddMessage($FormError, str_replace("%s", $this->salesrepid->caption(), $this->salesrepid->RequiredErrorMessage));
			}
		}
		if (!CheckInteger($this->salesrepid->FormValue)) {
			AddMessage($FormError, $this->salesrepid->errorMessage());
		}
		if ($this->currIDSettlement->Required) {
			if (!$this->currIDSettlement->IsDetailKey && $this->currIDSettlement->FormValue != NULL && $this->currIDSettlement->FormValue == "") {
				AddMessage($FormError, str_replace("%s", $this->currIDSettlement->caption(), $this->currIDSettlement->RequiredErrorMessage));
			}
		}

		// Validate detail grid
		$detailTblVar = explode(",", $this->getCurrentDetailTable());
		if (in_array("purchasepoitem", $detailTblVar) && $GLOBALS["purchasepoitem"]->DetailAdd) {
			if (!isset($GLOBALS["purchasepoitem_grid"]))
				$GLOBALS["purchasepoitem_grid"] = new purchasepoitem_grid(); // Get detail page object
			$GLOBALS["purchasepoitem_grid"]->validateGridForm();
		}

		// Return validate result
		$validateForm = ($FormError == "");

		// Call Form_CustomValidate event
		$formCustomError = "";
		$validateForm = $validateForm && $this->Form_CustomValidate($formCustomError);
		if ($formCustomError != "") {
			AddMessage($FormError, $formCustomError);
		}
		return $validateForm;
	}

	// Add record
	protected function addRow($rsold = NULL)
	{
		global $Language, $Security;
		$conn = $this->getConnection();

		// Begin transaction
		if ($this->getCurrentDetailTable() != "")
			$conn->beginTrans();

		// Load db values from rsold
		$this->loadDbValues($rsold);
		if ($rsold) {
		}
		$rsnew = [];

		// txid
		$this->txid->setDbValueDef($rsnew, $this->txid->CurrentValue, "", FALSE);

		// merchantID
		$this->merchantID->setDbValueDef($rsnew, $this->merchantID->CurrentValue, 0, FALSE);

		// userID
		$this->_userID->setDbValueDef($rsnew, $this->_userID->CurrentValue, 0, FALSE);

		// transferTime
		$this->transferTime->setDbValueDef($rsnew, UnFormatDateTime($this->transferTime->CurrentValue, 0), NULL, FALSE);

		// merchantSurcharge
		$this->merchantSurcharge->setDbValueDef($rsnew, $this->merchantSurcharge->CurrentValue, 0, strval($this->merchantSurcharge->CurrentValue) == "");

		// currID
		$this->currID->setDbValueDef($rsnew, $this->currID->CurrentValue, "", FALSE);

		// purchaseAmount
		$this->purchaseAmount->setDbValueDef($rsnew, $this->purchaseAmount->CurrentValue, 0, strval($this->purchaseAmount->CurrentValue) == "");

		// taxAmount
		$this->taxAmount->setDbValueDef($rsnew, $this->taxAmount->CurrentValue, 0, strval($this->taxAmount->CurrentValue) == "");

		// tipAmount
		$this->tipAmount->setDbValueDef($rsnew, $this->tipAmount->CurrentValue, 0, strval($this->tipAmount->CurrentValue) == "");

		// serviceFeeToCustomer
		$this->serviceFeeToCustomer->setDbValueDef($rsnew, $this->serviceFeeToCustomer->CurrentValue, 0, strval($this->serviceFeeToCustomer->CurrentValue) == "");

		// TotalAmountForCustomer
		$this->TotalAmountForCustomer->setDbValueDef($rsnew, $this->TotalAmountForCustomer->CurrentValue, 0, strval($this->TotalAmountForCustomer->CurrentValue) == "");

		// serviceFeeToMerchant
		$this->serviceFeeToMerchant->setDbValueDef($rsnew, $this->serviceFeeToMerchant->CurrentValue, 0, strval($this->serviceFeeToMerchant->CurrentValue) == "");

		// status
		$this->status->setDbValueDef($rsnew, $this->status->CurrentValue, 0, FALSE);

		// shoppingCartID
		$this->shoppingCartID->setDbValueDef($rsnew, $this->shoppingCartID->CurrentValue, NULL, FALSE);

		// merchantRefID
		$this->merchantRefID->setDbValueDef($rsnew, $this->merchantRefID->CurrentValue, NULL, FALSE);

		// feeid
		$this->feeid->setDbValueDef($rsnew, $this->feeid->CurrentValue, 0, FALSE);

		// ratetabletype
		$this->ratetabletype->setDbValueDef($rsnew, $this->ratetabletype->CurrentValue, 0, FALSE);

		// userpi
		$this->userpi->setDbValueDef($rsnew, $this->userpi->CurrentValue, 0, FALSE);

		// piid
		$this->piid->setDbValueDef($rsnew, $this->piid->CurrentValue, 0, FALSE);

		// feesystemshare
		$this->feesystemshare->setDbValueDef($rsnew, $this->feesystemshare->CurrentValue, 0, strval($this->feesystemshare->CurrentValue) == "");

		// feeexternalshare
		$this->feeexternalshare->setDbValueDef($rsnew, $this->feeexternalshare->CurrentValue, 0, FALSE);

		// feefranchiseeshare
		$this->feefranchiseeshare->setDbValueDef($rsnew, $this->feefranchiseeshare->CurrentValue, 0, FALSE);

		// feeresellershare
		$this->feeresellershare->setDbValueDef($rsnew, $this->feeresellershare->CurrentValue, 0, FALSE);

		// lastupdatetime
		$this->lastupdatetime->setDbValueDef($rsnew, UnFormatDateTime($this->lastupdatetime->CurrentValue, 0), CurrentDate(), FALSE);

		// expirationTimeInMinutes
		$this->expirationTimeInMinutes->setDbValueDef($rsnew, $this->expirationTimeInMinutes->CurrentValue, 0, strval($this->expirationTimeInMinutes->CurrentValue) == "");

		// expirationTime
		$this->expirationTime->setDbValueDef($rsnew, UnFormatDateTime($this->expirationTime->CurrentValue, 0), NULL, FALSE);

		// itemdesc
		$this->itemdesc->setDbValueDef($rsnew, $this->itemdesc->CurrentValue, NULL, FALSE);

		// customeruserid
		$this->customeruserid->setDbValueDef($rsnew, $this->customeruserid->CurrentValue, 0, FALSE);

		// paymentid
		$this->paymentid->setDbValueDef($rsnew, $this->paymentid->CurrentValue, 0, strval($this->paymentid->CurrentValue) == "");

		// purchaseid
		$this->purchaseid->setDbValueDef($rsnew, $this->purchaseid->CurrentValue, 0, strval($this->purchaseid->CurrentValue) == "");

		// eftid
		$this->eftid->setDbValueDef($rsnew, $this->eftid->CurrentValue, 0, strval($this->eftid->CurrentValue) == "");

		// targetUserID
		$this->targetUserID->setDbValueDef($rsnew, $this->targetUserID->CurrentValue, 0, strval($this->targetUserID->CurrentValue) == "");

		// messageType
		$this->messageType->setDbValueDef($rsnew, $this->messageType->CurrentValue, 0, strval($this->messageType->CurrentValue) == "");

		// targetemail
		$this->targetemail->setDbValueDef($rsnew, $this->targetemail->CurrentValue, NULL, FALSE);

		// targetpresentationcode
		$this->targetpresentationcode->setDbValueDef($rsnew, $this->targetpresentationcode->CurrentValue, 0, strval($this->targetpresentationcode->CurrentValue) == "");

		// targetcomments
		$this->targetcomments->setDbValueDef($rsnew, $this->targetcomments->CurrentValue, NULL, FALSE);

		// targetrecipientname
		$this->targetrecipientname->setDbValueDef($rsnew, $this->targetrecipientname->CurrentValue, NULL, FALSE);

		// targetsendername
		$this->targetsendername->setDbValueDef($rsnew, $this->targetsendername->CurrentValue, NULL, FALSE);

		// salesrepid
		$this->salesrepid->setDbValueDef($rsnew, $this->salesrepid->CurrentValue, 0, strval($this->salesrepid->CurrentValue) == "");

		// currIDSettlement
		$this->currIDSettlement->setDbValueDef($rsnew, $this->currIDSettlement->CurrentValue, NULL, FALSE);

		// Call Row Inserting event
		$rs = ($rsold) ? $rsold->fields : NULL;
		$insertRow = $this->Row_Inserting($rs, $rsnew);
		if ($insertRow) {
			$conn->raiseErrorFn = Config("ERROR_FUNC");
			$addRow = $this->insert($rsnew);
			$conn->raiseErrorFn = "";
			if ($addRow) {
			}
		} else {
			if ($this->getSuccessMessage() != "" || $this->getFailureMessage() != "") {

				// Use the message, do nothing
			} elseif ($this->CancelMessage != "") {
				$this->setFailureMessage($this->CancelMessage);
				$this->CancelMessage = "";
			} else {
				$this->setFailureMessage($Language->phrase("InsertCancelled"));
			}
			$addRow = FALSE;
		}

		// Add detail records
		if ($addRow) {
			$detailTblVar = explode(",", $this->getCurrentDetailTable());
			if (in_array("purchasepoitem", $detailTblVar) && $GLOBALS["purchasepoitem"]->DetailAdd) {
				$GLOBALS["purchasepoitem"]->poid->setSessionValue($this->poid->CurrentValue); // Set master key
				if (!isset($GLOBALS["purchasepoitem_grid"]))
					$GLOBALS["purchasepoitem_grid"] = new purchasepoitem_grid(); // Get detail page object
				$Security->loadCurrentUserLevel($this->ProjectID . "purchasepoitem"); // Load user level of detail table
				$addRow = $GLOBALS["purchasepoitem_grid"]->gridInsert();
				$Security->loadCurrentUserLevel($this->ProjectID . $this->TableName); // Restore user level of master table
				if (!$addRow) {
					$GLOBALS["purchasepoitem"]->poid->setSessionValue(""); // Clear master key if insert failed
				}
			}
		}

		// Commit/Rollback transaction
		if ($this->getCurrentDetailTable() != "") {
			if ($addRow) {
				$conn->commitTrans(); // Commit transaction
			} else {
				$conn->rollbackTrans(); // Rollback transaction
			}
		}
		if ($addRow) {

			// Call Row Inserted event
			$rs = ($rsold) ? $rsold->fields : NULL;
			$this->Row_Inserted($rs, $rsnew);
		}

		// Clean upload path if any
		if ($addRow) {
		}

		// Write JSON for API request
		if (IsApi() && $addRow) {
			$row = $this->getRecordsFromRecordset([$rsnew], TRUE);
			WriteJson(["success" => TRUE, $this->TableVar => $row]);
		}
		return $addRow;
	}

	// Set up detail parms based on QueryString
	protected function setupDetailParms()
	{

		// Get the keys for master table
		$detailTblVar = Get(Config("TABLE_SHOW_DETAIL"));
		if ($detailTblVar !== NULL) {
			$this->setCurrentDetailTable($detailTblVar);
		} else {
			$detailTblVar = $this->getCurrentDetailTable();
		}
		if ($detailTblVar != "") {
			$detailTblVar = explode(",", $detailTblVar);
			if (in_array("purchasepoitem", $detailTblVar)) {
				if (!isset($GLOBALS["purchasepoitem_grid"]))
					$GLOBALS["purchasepoitem_grid"] = new purchasepoitem_grid();
				if ($GLOBALS["purchasepoitem_grid"]->DetailAdd) {
					if ($this->CopyRecord)
						$GLOBALS["purchasepoitem_grid"]->CurrentMode = "copy";
					else
						$GLOBALS["purchasepoitem_grid"]->CurrentMode = "add";
					$GLOBALS["purchasepoitem_grid"]->CurrentAction = "gridadd";

					// Save current master table to detail table
					$GLOBALS["purchasepoitem_grid"]->setCurrentMasterTable($this->TableVar);
					$GLOBALS["purchasepoitem_grid"]->setStartRecordNumber(1);
					$GLOBALS["purchasepoitem_grid"]->poid->IsDetailKey = TRUE;
					$GLOBALS["purchasepoitem_grid"]->poid->CurrentValue = $this->poid->CurrentValue;
					$GLOBALS["purchasepoitem_grid"]->poid->setSessionValue($GLOBALS["purchasepoitem_grid"]->poid->CurrentValue);
				}
			}
		}
	}

	// Set up Breadcrumb
	protected function setupBreadcrumb()
	{
		global $Breadcrumb, $Language;
		$Breadcrumb = new Breadcrumb();
		$url = substr(CurrentUrl(), strrpos(CurrentUrl(), "/")+1);
		$Breadcrumb->add("list", $this->TableVar, $this->addMasterUrl("purchaseorderlist.php"), "", $this->TableVar, TRUE);
		$pageId = ($this->isCopy()) ? "Copy" : "Add";
		$Breadcrumb->add("add", $pageId, $url);
	}

	// Setup lookup options
	public function setupLookupOptions($fld)
	{
		if ($fld->Lookup !== NULL && $fld->Lookup->Options === NULL) {

			// Get default connection and filter
			$conn = $this->getConnection();
			$lookupFilter = "";

			// No need to check any more
			$fld->Lookup->Options = [];

			// Set up lookup SQL and connection
			switch ($fld->FieldVar) {
				case "x_status":
					break;
				case "x_piid":
					$conn = Conn("_4payreference");
					break;
				case "x_salesrepid":
					break;
				default:
					$lookupFilter = "";
					break;
			}

			// Always call to Lookup->getSql so that user can setup Lookup->Options in Lookup_Selecting server event
			$sql = $fld->Lookup->getSql(FALSE, "", $lookupFilter, $this);

			// Set up lookup cache
			if ($fld->UseLookupCache && $sql != "" && count($fld->Lookup->Options) == 0) {
				$totalCnt = $this->getRecordCount($sql, $conn);
				if ($totalCnt > $fld->LookupCacheCount) // Total count > cache count, do not cache
					return;
				$rs = $conn->execute($sql);
				$ar = [];
				while ($rs && !$rs->EOF) {
					$row = &$rs->fields;

					// Format the field values
					switch ($fld->FieldVar) {
						case "x_piid":
							break;
						case "x_salesrepid":
							break;
					}
					$ar[strval($row[0])] = $row;
					$rs->moveNext();
				}
				if ($rs)
					$rs->close();
				$fld->Lookup->Options = $ar;
			}
		}
	}

	// Page Load event
	function Page_Load() {

		//echo "Page Load";
	}

	// Page Unload event
	function Page_Unload() {

		//echo "Page Unload";
	}

	// Page Redirecting event
	function Page_Redirecting(&$url) {

		// Example:
		//$url = "your URL";

	}

	// Message Showing event
	// $type = ''|'success'|'failure'|'warning'
	function Message_Showing(&$msg, $type) {
		if ($type == 'success') {

			//$msg = "your success message";
		} elseif ($type == 'failure') {

			//$msg = "your failure message";
		} elseif ($type == 'warning') {

			//$msg = "your warning message";
		} else {

			//$msg = "your message";
		}
	}

	// Page Render event
	function Page_Render() {

		//echo "Page Render";
	}

	// Page Data Rendering event
	function Page_DataRendering(&$header) {

		// Example:
		//$header = "your header";

	}

	// Page Data Rendered event
	function Page_DataRendered(&$footer) {

		// Example:
		//$footer = "your footer";

	}

	// Form Custom Validate event
	function Form_CustomValidate(&$customError) {

		// Return error message in CustomError
		return TRUE;
	}
} // End class
?>