<?php
namespace PHPMaker2020\_4payadmin;

/**
 * Page class
 */
class vtranshistorycardtypes_grid extends vtranshistorycardtypes
{

	// Page ID
	public $PageID = "grid";

	// Project ID
	public $ProjectID = "{153C2D2E-60EE-4944-8753-3935EB38E8D6}";

	// Table name
	public $TableName = 'vtranshistorycardtypes';

	// Page object name
	public $PageObjName = "vtranshistorycardtypes_grid";

	// Grid form hidden field names
	public $FormName = "fvtranshistorycardtypesgrid";
	public $FormActionName = "k_action";
	public $FormKeyName = "k_key";
	public $FormOldKeyName = "k_oldkey";
	public $FormBlankRowName = "k_blankrow";
	public $FormKeyCountName = "key_count";

	// Page URLs
	public $AddUrl;
	public $EditUrl;
	public $CopyUrl;
	public $DeleteUrl;
	public $ViewUrl;
	public $ListUrl;

	// Page headings
	public $Heading = "";
	public $Subheading = "";
	public $PageHeader;
	public $PageFooter;

	// Token
	public $Token = "";
	public $TokenTimeout = 0;
	public $CheckToken;

	// Page heading
	public function pageHeading()
	{
		global $Language;
		if ($this->Heading != "")
			return $this->Heading;
		if (method_exists($this, "tableCaption"))
			return $this->tableCaption();
		return "";
	}

	// Page subheading
	public function pageSubheading()
	{
		global $Language;
		if ($this->Subheading != "")
			return $this->Subheading;
		if ($this->TableName)
			return $Language->phrase($this->PageID);
		return "";
	}

	// Page name
	public function pageName()
	{
		return CurrentPageName();
	}

	// Page URL
	public function pageUrl()
	{
		$url = CurrentPageName() . "?";
		if ($this->UseTokenInUrl)
			$url .= "t=" . $this->TableVar . "&"; // Add page token
		return $url;
	}

	// Messages
	private $_message = "";
	private $_failureMessage = "";
	private $_successMessage = "";
	private $_warningMessage = "";

	// Get message
	public function getMessage()
	{
		return isset($_SESSION[SESSION_MESSAGE]) ? $_SESSION[SESSION_MESSAGE] : $this->_message;
	}

	// Set message
	public function setMessage($v)
	{
		AddMessage($this->_message, $v);
		$_SESSION[SESSION_MESSAGE] = $this->_message;
	}

	// Get failure message
	public function getFailureMessage()
	{
		return isset($_SESSION[SESSION_FAILURE_MESSAGE]) ? $_SESSION[SESSION_FAILURE_MESSAGE] : $this->_failureMessage;
	}

	// Set failure message
	public function setFailureMessage($v)
	{
		AddMessage($this->_failureMessage, $v);
		$_SESSION[SESSION_FAILURE_MESSAGE] = $this->_failureMessage;
	}

	// Get success message
	public function getSuccessMessage()
	{
		return isset($_SESSION[SESSION_SUCCESS_MESSAGE]) ? $_SESSION[SESSION_SUCCESS_MESSAGE] : $this->_successMessage;
	}

	// Set success message
	public function setSuccessMessage($v)
	{
		AddMessage($this->_successMessage, $v);
		$_SESSION[SESSION_SUCCESS_MESSAGE] = $this->_successMessage;
	}

	// Get warning message
	public function getWarningMessage()
	{
		return isset($_SESSION[SESSION_WARNING_MESSAGE]) ? $_SESSION[SESSION_WARNING_MESSAGE] : $this->_warningMessage;
	}

	// Set warning message
	public function setWarningMessage($v)
	{
		AddMessage($this->_warningMessage, $v);
		$_SESSION[SESSION_WARNING_MESSAGE] = $this->_warningMessage;
	}

	// Clear message
	public function clearMessage()
	{
		$this->_message = "";
		$_SESSION[SESSION_MESSAGE] = "";
	}

	// Clear failure message
	public function clearFailureMessage()
	{
		$this->_failureMessage = "";
		$_SESSION[SESSION_FAILURE_MESSAGE] = "";
	}

	// Clear success message
	public function clearSuccessMessage()
	{
		$this->_successMessage = "";
		$_SESSION[SESSION_SUCCESS_MESSAGE] = "";
	}

	// Clear warning message
	public function clearWarningMessage()
	{
		$this->_warningMessage = "";
		$_SESSION[SESSION_WARNING_MESSAGE] = "";
	}

	// Clear messages
	public function clearMessages()
	{
		$this->clearMessage();
		$this->clearFailureMessage();
		$this->clearSuccessMessage();
		$this->clearWarningMessage();
	}

	// Show message
	public function showMessage()
	{
		$hidden = FALSE;
		$html = "";

		// Message
		$message = $this->getMessage();
		if (method_exists($this, "Message_Showing"))
			$this->Message_Showing($message, "");
		if ($message != "") { // Message in Session, display
			if (!$hidden)
				$message = '<button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button>' . $message;
			$html .= '<div class="alert alert-info alert-dismissible ew-info"><i class="icon fas fa-info"></i>' . $message . '</div>';
			$_SESSION[SESSION_MESSAGE] = ""; // Clear message in Session
		}

		// Warning message
		$warningMessage = $this->getWarningMessage();
		if (method_exists($this, "Message_Showing"))
			$this->Message_Showing($warningMessage, "warning");
		if ($warningMessage != "") { // Message in Session, display
			if (!$hidden)
				$warningMessage = '<button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button>' . $warningMessage;
			$html .= '<div class="alert alert-warning alert-dismissible ew-warning"><i class="icon fas fa-exclamation"></i>' . $warningMessage . '</div>';
			$_SESSION[SESSION_WARNING_MESSAGE] = ""; // Clear message in Session
		}

		// Success message
		$successMessage = $this->getSuccessMessage();
		if (method_exists($this, "Message_Showing"))
			$this->Message_Showing($successMessage, "success");
		if ($successMessage != "") { // Message in Session, display
			if (!$hidden)
				$successMessage = '<button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button>' . $successMessage;
			$html .= '<div class="alert alert-success alert-dismissible ew-success"><i class="icon fas fa-check"></i>' . $successMessage . '</div>';
			$_SESSION[SESSION_SUCCESS_MESSAGE] = ""; // Clear message in Session
		}

		// Failure message
		$errorMessage = $this->getFailureMessage();
		if (method_exists($this, "Message_Showing"))
			$this->Message_Showing($errorMessage, "failure");
		if ($errorMessage != "") { // Message in Session, display
			if (!$hidden)
				$errorMessage = '<button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button>' . $errorMessage;
			$html .= '<div class="alert alert-danger alert-dismissible ew-error"><i class="icon fas fa-ban"></i>' . $errorMessage . '</div>';
			$_SESSION[SESSION_FAILURE_MESSAGE] = ""; // Clear message in Session
		}
		echo '<div class="ew-message-dialog' . (($hidden) ? ' d-none' : "") . '">' . $html . '</div>';
	}

	// Get message as array
	public function getMessages()
	{
		$ar = [];

		// Message
		$message = $this->getMessage();

		//if (method_exists($this, "Message_Showing"))
		//	$this->Message_Showing($message, "");

		if ($message != "") { // Message in Session, display
			$ar["message"] = $message;
			$_SESSION[SESSION_MESSAGE] = ""; // Clear message in Session
		}

		// Warning message
		$warningMessage = $this->getWarningMessage();

		//if (method_exists($this, "Message_Showing"))
		//	$this->Message_Showing($warningMessage, "warning");

		if ($warningMessage != "") { // Message in Session, display
			$ar["warningMessage"] = $warningMessage;
			$_SESSION[SESSION_WARNING_MESSAGE] = ""; // Clear message in Session
		}

		// Success message
		$successMessage = $this->getSuccessMessage();

		//if (method_exists($this, "Message_Showing"))
		//	$this->Message_Showing($successMessage, "success");

		if ($successMessage != "") { // Message in Session, display
			$ar["successMessage"] = $successMessage;
			$_SESSION[SESSION_SUCCESS_MESSAGE] = ""; // Clear message in Session
		}

		// Failure message
		$failureMessage = $this->getFailureMessage();

		//if (method_exists($this, "Message_Showing"))
		//	$this->Message_Showing($failureMessage, "failure");

		if ($failureMessage != "") { // Message in Session, display
			$ar["failureMessage"] = $failureMessage;
			$_SESSION[SESSION_FAILURE_MESSAGE] = ""; // Clear message in Session
		}
		return $ar;
	}

	// Show Page Header
	public function showPageHeader()
	{
		$header = $this->PageHeader;
		$this->Page_DataRendering($header);
		if ($header != "") { // Header exists, display
			echo '<p id="ew-page-header">' . $header . '</p>';
		}
	}

	// Show Page Footer
	public function showPageFooter()
	{
		$footer = $this->PageFooter;
		$this->Page_DataRendered($footer);
		if ($footer != "") { // Footer exists, display
			echo '<p id="ew-page-footer">' . $footer . '</p>';
		}
	}

	// Validate page request
	protected function isPageRequest()
	{
		global $CurrentForm;
		if ($this->UseTokenInUrl) {
			if ($CurrentForm)
				return ($this->TableVar == $CurrentForm->getValue("t"));
			if (Get("t") !== NULL)
				return ($this->TableVar == Get("t"));
		}
		return TRUE;
	}

	// Valid Post
	protected function validPost()
	{
		if (!$this->CheckToken || !IsPost() || IsApi())
			return TRUE;
		if (Post(Config("TOKEN_NAME")) === NULL)
			return FALSE;
		$fn = Config("CHECK_TOKEN_FUNC");
		if (is_callable($fn))
			return $fn(Post(Config("TOKEN_NAME")), $this->TokenTimeout);
		return FALSE;
	}

	// Create Token
	public function createToken()
	{
		global $CurrentToken;
		$fn = Config("CREATE_TOKEN_FUNC"); // Always create token, required by API file/lookup request
		if ($this->Token == "" && is_callable($fn)) // Create token
			$this->Token = $fn();
		$CurrentToken = $this->Token; // Save to global variable
	}

	// Constructor
	public function __construct()
	{
		global $Language, $DashboardReport;
		global $UserTable;

		// Check token
		$this->CheckToken = Config("CHECK_TOKEN");

		// Initialize
		$this->FormActionName .= "_" . $this->FormName;
		$this->FormKeyName .= "_" . $this->FormName;
		$this->FormOldKeyName .= "_" . $this->FormName;
		$this->FormBlankRowName .= "_" . $this->FormName;
		$this->FormKeyCountName .= "_" . $this->FormName;
		$GLOBALS["Grid"] = &$this;
		$this->TokenTimeout = SessionTimeoutTime();

		// Language object
		if (!isset($Language))
			$Language = new Language();

		// Parent constuctor
		parent::__construct();

		// Table object (vtranshistorycardtypes)
		if (!isset($GLOBALS["vtranshistorycardtypes"]) || get_class($GLOBALS["vtranshistorycardtypes"]) == PROJECT_NAMESPACE . "vtranshistorycardtypes") {
			$GLOBALS["vtranshistorycardtypes"] = &$this;

			// $GLOBALS["MasterTable"] = &$GLOBALS["Table"];
			// if (!isset($GLOBALS["Table"]))
			// 	$GLOBALS["Table"] = &$GLOBALS["vtranshistorycardtypes"];

		}
		$this->AddUrl = "vtranshistorycardtypesadd.php";

		// Table object (admin)
		if (!isset($GLOBALS['admin']))
			$GLOBALS['admin'] = new admin();

		// Page ID (for backward compatibility only)
		if (!defined(PROJECT_NAMESPACE . "PAGE_ID"))
			define(PROJECT_NAMESPACE . "PAGE_ID", 'grid');

		// Table name (for backward compatibility only)
		if (!defined(PROJECT_NAMESPACE . "TABLE_NAME"))
			define(PROJECT_NAMESPACE . "TABLE_NAME", 'vtranshistorycardtypes');

		// Start timer
		if (!isset($GLOBALS["DebugTimer"]))
			$GLOBALS["DebugTimer"] = new Timer();

		// Debug message
		LoadDebugMessage();

		// Open connection
		if (!isset($GLOBALS["Conn"]))
			$GLOBALS["Conn"] = $this->getConnection();

		// User table object (admin)
		$UserTable = $UserTable ?: new admin();

		// List options
		$this->ListOptions = new ListOptions();
		$this->ListOptions->TableVar = $this->TableVar;

		// Other options
		if (!$this->OtherOptions)
			$this->OtherOptions = new ListOptionsArray();
		$this->OtherOptions["addedit"] = new ListOptions("div");
		$this->OtherOptions["addedit"]->TagClassName = "ew-add-edit-option";
	}

	// Terminate page
	public function terminate($url = "")
	{
		global $ExportFileName, $TempImages, $DashboardReport;

		// Export
		global $vtranshistorycardtypes;
		if ($this->CustomExport && $this->CustomExport == $this->Export && array_key_exists($this->CustomExport, Config("EXPORT_CLASSES"))) {
				$content = ob_get_contents();
			if ($ExportFileName == "")
				$ExportFileName = $this->TableVar;
			$class = PROJECT_NAMESPACE . Config("EXPORT_CLASSES." . $this->CustomExport);
			if (class_exists($class)) {
				$doc = new $class($vtranshistorycardtypes);
				$doc->Text = @$content;
				if ($this->isExport("email"))
					echo $this->exportEmail($doc->Text);
				else
					$doc->export();
				DeleteTempImages(); // Delete temp images
				exit();
			}
		}

//		$GLOBALS["Table"] = &$GLOBALS["MasterTable"];
		unset($GLOBALS["Grid"]);
		if ($url === "")
			return;
		if (!IsApi())
			$this->Page_Redirecting($url);

		// Return for API
		if (IsApi()) {
			$res = $url === TRUE;
			if (!$res) // Show error
				WriteJson(array_merge(["success" => FALSE], $this->getMessages()));
			return;
		}

		// Go to URL if specified
		if ($url != "") {
			if (!Config("DEBUG") && ob_get_length())
				ob_end_clean();
			SaveDebugMessage();
			AddHeader("Location", $url);
		}
		exit();
	}

	// Get records from recordset
	protected function getRecordsFromRecordset($rs, $current = FALSE)
	{
		$rows = [];
		if (is_object($rs)) { // Recordset
			while ($rs && !$rs->EOF) {
				$this->loadRowValues($rs); // Set up DbValue/CurrentValue
				$row = $this->getRecordFromArray($rs->fields);
				if ($current)
					return $row;
				else
					$rows[] = $row;
				$rs->moveNext();
			}
		} elseif (is_array($rs)) {
			foreach ($rs as $ar) {
				$row = $this->getRecordFromArray($ar);
				if ($current)
					return $row;
				else
					$rows[] = $row;
			}
		}
		return $rows;
	}

	// Get record from array
	protected function getRecordFromArray($ar)
	{
		$row = [];
		if (is_array($ar)) {
			foreach ($ar as $fldname => $val) {
				if (array_key_exists($fldname, $this->fields) && ($this->fields[$fldname]->Visible || $this->fields[$fldname]->IsPrimaryKey)) { // Primary key or Visible
					$fld = &$this->fields[$fldname];
					if ($fld->HtmlTag == "FILE") { // Upload field
						if (EmptyValue($val)) {
							$row[$fldname] = NULL;
						} else {
							if ($fld->DataType == DATATYPE_BLOB) {
								$url = FullUrl(GetApiUrl(Config("API_FILE_ACTION"),
									Config("API_OBJECT_NAME") . "=" . $fld->TableVar . "&" .
									Config("API_FIELD_NAME") . "=" . $fld->Param . "&" .
									Config("API_KEY_NAME") . "=" . rawurlencode($this->getRecordKeyValue($ar)))); //*** need to add this? API may not be in the same folder
								$row[$fldname] = ["type" => ContentType($val), "url" => $url, "name" => $fld->Param . ContentExtension($val)];
							} elseif (!$fld->UploadMultiple || !ContainsString($val, Config("MULTIPLE_UPLOAD_SEPARATOR"))) { // Single file
								$url = FullUrl(GetApiUrl(Config("API_FILE_ACTION"),
									Config("API_OBJECT_NAME") . "=" . $fld->TableVar . "&" .
									"fn=" . Encrypt($fld->physicalUploadPath() . $val)));
								$row[$fldname] = ["type" => MimeContentType($val), "url" => $url, "name" => $val];
							} else { // Multiple files
								$files = explode(Config("MULTIPLE_UPLOAD_SEPARATOR"), $val);
								$ar = [];
								foreach ($files as $file) {
									$url = FullUrl(GetApiUrl(Config("API_FILE_ACTION"),
										Config("API_OBJECT_NAME") . "=" . $fld->TableVar . "&" .
										"fn=" . Encrypt($fld->physicalUploadPath() . $file)));
									if (!EmptyValue($file))
										$ar[] = ["type" => MimeContentType($file), "url" => $url, "name" => $file];
								}
								$row[$fldname] = $ar;
							}
						}
					} else {
						$row[$fldname] = $val;
					}
				}
			}
		}
		return $row;
	}

	// Get record key value from array
	protected function getRecordKeyValue($ar)
	{
		$key = "";
		if (is_array($ar)) {
			$key .= @$ar['transID'] . Config("COMPOSITE_KEY_SEPARATOR");
			$key .= @$ar['langID'] . Config("COMPOSITE_KEY_SEPARATOR");
			$key .= @$ar['transLineID'];
		}
		return $key;
	}

	/**
	 * Hide fields for add/edit
	 *
	 * @return void
	 */
	protected function hideFieldsForAddEdit()
	{
		if ($this->isAdd() || $this->isCopy() || $this->isGridAdd())
			$this->transID->Visible = FALSE;
		if ($this->isAdd() || $this->isCopy() || $this->isGridAdd())
			$this->transLineID->Visible = FALSE;
	}

	// Lookup data
	public function lookup()
	{
		global $Language, $Security;
		if (!isset($Language))
			$Language = new Language(Config("LANGUAGE_FOLDER"), Post("language", ""));

		// Set up API request
		if (!ValidApiRequest())
			return FALSE;
		$this->setupApiSecurity();

		// Get lookup object
		$fieldName = Post("field");
		if (!array_key_exists($fieldName, $this->fields))
			return FALSE;
		$lookupField = $this->fields[$fieldName];
		$lookup = $lookupField->Lookup;
		if ($lookup === NULL)
			return FALSE;
		$tbl = $lookup->getTable();
		if (!$Security->allowLookup(Config("PROJECT_ID") . $tbl->TableName)) // Lookup permission
			return FALSE;

		// Get lookup parameters
		$lookupType = Post("ajax", "unknown");
		$pageSize = -1;
		$offset = -1;
		$searchValue = "";
		if (SameText($lookupType, "modal")) {
			$searchValue = Post("sv", "");
			$pageSize = Post("recperpage", 10);
			$offset = Post("start", 0);
		} elseif (SameText($lookupType, "autosuggest")) {
			$searchValue = Param("q", "");
			$pageSize = Param("n", -1);
			$pageSize = is_numeric($pageSize) ? (int)$pageSize : -1;
			if ($pageSize <= 0)
				$pageSize = Config("AUTO_SUGGEST_MAX_ENTRIES");
			$start = Param("start", -1);
			$start = is_numeric($start) ? (int)$start : -1;
			$page = Param("page", -1);
			$page = is_numeric($page) ? (int)$page : -1;
			$offset = $start >= 0 ? $start : ($page > 0 && $pageSize > 0 ? ($page - 1) * $pageSize : 0);
		}
		$userSelect = Decrypt(Post("s", ""));
		$userFilter = Decrypt(Post("f", ""));
		$userOrderBy = Decrypt(Post("o", ""));
		$keys = Post("keys");
		$lookup->LookupType = $lookupType; // Lookup type
		if ($keys !== NULL) { // Selected records from modal
			if (is_array($keys))
				$keys = implode(Config("MULTIPLE_OPTION_SEPARATOR"), $keys);
			$lookup->FilterFields = []; // Skip parent fields if any
			$lookup->FilterValues[] = $keys; // Lookup values
			$pageSize = -1; // Show all records
		} else { // Lookup values
			$lookup->FilterValues[] = Post("v0", Post("lookupValue", ""));
		}
		$cnt = is_array($lookup->FilterFields) ? count($lookup->FilterFields) : 0;
		for ($i = 1; $i <= $cnt; $i++)
			$lookup->FilterValues[] = Post("v" . $i, "");
		$lookup->SearchValue = $searchValue;
		$lookup->PageSize = $pageSize;
		$lookup->Offset = $offset;
		if ($userSelect != "")
			$lookup->UserSelect = $userSelect;
		if ($userFilter != "")
			$lookup->UserFilter = $userFilter;
		if ($userOrderBy != "")
			$lookup->UserOrderBy = $userOrderBy;
		$lookup->toJson($this); // Use settings from current page
	}

	// Set up API security
	public function setupApiSecurity()
	{
		global $Security;

		// Setup security for API request
		if ($Security->isLoggedIn()) $Security->TablePermission_Loading();
		$Security->loadCurrentUserLevel(Config("PROJECT_ID") . $this->TableName);
		if ($Security->isLoggedIn()) $Security->TablePermission_Loaded();
	}

	// Class variables
	public $ListOptions; // List options
	public $ExportOptions; // Export options
	public $SearchOptions; // Search options
	public $OtherOptions; // Other options
	public $FilterOptions; // Filter options
	public $ImportOptions; // Import options
	public $ListActions; // List actions
	public $SelectedCount = 0;
	public $SelectedIndex = 0;
	public $ShowOtherOptions = FALSE;
	public $DisplayRecords = 10;
	public $StartRecord;
	public $StopRecord;
	public $TotalRecords = 0;
	public $RecordRange = 10;
	public $PageSizes = ""; // Page sizes (comma separated)
	public $DefaultSearchWhere = ""; // Default search WHERE clause
	public $SearchWhere = ""; // Search WHERE clause
	public $SearchPanelClass = "ew-search-panel collapse"; // Search Panel class
	public $SearchRowCount = 0; // For extended search
	public $SearchColumnCount = 0; // For extended search
	public $SearchFieldsPerRow = 1; // For extended search
	public $RecordCount = 0; // Record count
	public $EditRowCount;
	public $StartRowCount = 1;
	public $RowCount = 0;
	public $Attrs = []; // Row attributes and cell attributes
	public $RowIndex = 0; // Row index
	public $KeyCount = 0; // Key count
	public $RowAction = ""; // Row action
	public $RowOldKey = ""; // Row old key (for copy)
	public $MultiColumnClass = "col-sm";
	public $MultiColumnEditClass = "w-100";
	public $DbMasterFilter = ""; // Master filter
	public $DbDetailFilter = ""; // Detail filter
	public $MasterRecordExists;
	public $MultiSelectKey;
	public $Command;
	public $RestoreSearch = FALSE;
	public $DetailPages;
	public $OldRecordset;

	//
	// Page run
	//

	public function run()
	{
		global $ExportType, $CustomExportType, $ExportFileName, $UserProfile, $Language, $Security, $CurrentForm,
			$FormError, $SearchError;

		// User profile
		$UserProfile = new UserProfile();

		// Security
		if (ValidApiRequest()) { // API request
			$this->setupApiSecurity(); // Set up API Security
		} else {
			$Security = new AdvancedSecurity();
			if (IsPasswordExpired())
				$this->terminate(GetUrl("changepwd.php"));
			if (!$Security->isLoggedIn())
				$Security->autoLogin();
			if ($Security->isLoggedIn())
				$Security->TablePermission_Loading();
			$Security->loadCurrentUserLevel($this->ProjectID . $this->TableName);
			if ($Security->isLoggedIn())
				$Security->TablePermission_Loaded();
			if (!$Security->canList()) {
				$Security->saveLastUrl();
				$this->setFailureMessage(DeniedMessage()); // Set no permission
				$this->terminate(GetUrl("index.php"));
				return;
			}
		}

		// Get grid add count
		$gridaddcnt = Get(Config("TABLE_GRID_ADD_ROW_COUNT"), "");
		if (is_numeric($gridaddcnt) && $gridaddcnt > 0)
			$this->GridAddRowCount = $gridaddcnt;

		// Set up list options
		$this->setupListOptions();
		$this->transID->setVisibility();
		$this->acctID->setVisibility();
		$this->transType->setVisibility();
		$this->transtypelabel->Visible = FALSE;
		$this->currID->setVisibility();
		$this->amount->setVisibility();
		$this->transTime->setVisibility();
		$this->sourceUserID->setVisibility();
		$this->destinationUserID->setVisibility();
		$this->referenceTXID->setVisibility();
		$this->langID->Visible = FALSE;
		$this->sourceNodeID->Visible = FALSE;
		$this->destinationNodeID->Visible = FALSE;
		$this->msg->setVisibility();
		$this->transLineID->Visible = FALSE;
		$this->piid->Visible = FALSE;
		$this->hideFieldsForAddEdit();

		// Global Page Loading event (in userfn*.php)
		Page_Loading();

		// Page Load event
		$this->Page_Load();

		// Check token
		if (!$this->validPost()) {
			Write($Language->phrase("InvalidPostRequest"));
			$this->terminate();
		}

		// Create Token
		$this->createToken();

		// Set up master detail parameters
		$this->setupMasterParms();

		// Setup other options
		$this->setupOtherOptions();

		// Set up lookup cache
		$this->setupLookupOptions($this->transType);

		// Search filters
		$srchAdvanced = ""; // Advanced search filter
		$srchBasic = ""; // Basic search filter
		$filter = "";

		// Get command
		$this->Command = strtolower(Get("cmd"));
		if ($this->isPageRequest()) { // Validate request

			// Set up records per page
			$this->setupDisplayRecords();

			// Handle reset command
			$this->resetCmd();

			// Hide list options
			if ($this->isExport()) {
				$this->ListOptions->hideAllOptions(["sequence"]);
				$this->ListOptions->UseDropDownButton = FALSE; // Disable drop down button
				$this->ListOptions->UseButtonGroup = FALSE; // Disable button group
			} elseif ($this->isGridAdd() || $this->isGridEdit()) {
				$this->ListOptions->hideAllOptions();
				$this->ListOptions->UseDropDownButton = FALSE; // Disable drop down button
				$this->ListOptions->UseButtonGroup = FALSE; // Disable button group
			}

			// Show grid delete link for grid add / grid edit
			if ($this->AllowAddDeleteRow) {
				if ($this->isGridAdd() || $this->isGridEdit()) {
					$item = $this->ListOptions["griddelete"];
					if ($item)
						$item->Visible = TRUE;
				}
			}

			// Set up sorting order
			$this->setupSortOrder();
		}

		// Restore display records
		if ($this->Command != "json" && $this->getRecordsPerPage() != "") {
			$this->DisplayRecords = $this->getRecordsPerPage(); // Restore from Session
		} else {
			$this->DisplayRecords = 10; // Load default
			$this->setRecordsPerPage($this->DisplayRecords); // Save default to Session
		}

		// Load Sorting Order
		if ($this->Command != "json")
			$this->loadSortOrder();

		// Build filter
		$filter = "";
		if (!$Security->canList())
			$filter = "(0=1)"; // Filter all records

		// Restore master/detail filter
		$this->DbMasterFilter = $this->getMasterFilter(); // Restore master filter
		$this->DbDetailFilter = $this->getDetailFilter(); // Restore detail filter
		AddFilter($filter, $this->DbDetailFilter);
		AddFilter($filter, $this->SearchWhere);

		// Load master record
		if ($this->CurrentMode != "add" && $this->getMasterFilter() != "" && $this->getCurrentMasterTable() == "paymentinstrument") {
			global $paymentinstrument;
			$rsmaster = $paymentinstrument->loadRs($this->DbMasterFilter);
			$this->MasterRecordExists = ($rsmaster && !$rsmaster->EOF);
			if (!$this->MasterRecordExists) {
				$this->setFailureMessage($Language->phrase("NoRecord")); // Set no record found
				$this->terminate("paymentinstrumentlist.php"); // Return to master page
			} else {
				$paymentinstrument->loadListRowValues($rsmaster);
				$paymentinstrument->RowType = ROWTYPE_MASTER; // Master row
				$paymentinstrument->renderListRow();
				$rsmaster->close();
			}
		}

		// Set up filter
		if ($this->Command == "json") {
			$this->UseSessionForListSql = FALSE; // Do not use session for ListSQL
			$this->CurrentFilter = $filter;
		} else {
			$this->setSessionWhere($filter);
			$this->CurrentFilter = "";
		}
		if ($this->isGridAdd()) {
			if ($this->CurrentMode == "copy") {
				$selectLimit = $this->UseSelectLimit;
				if ($selectLimit) {
					$this->TotalRecords = $this->listRecordCount();
					$this->Recordset = $this->loadRecordset($this->StartRecord - 1, $this->DisplayRecords);
				} else {
					if ($this->Recordset = $this->loadRecordset())
						$this->TotalRecords = $this->Recordset->RecordCount();
				}
				$this->StartRecord = 1;
				$this->DisplayRecords = $this->TotalRecords;
			} else {
				$this->CurrentFilter = "0=1";
				$this->StartRecord = 1;
				$this->DisplayRecords = $this->GridAddRowCount;
			}
			$this->TotalRecords = $this->DisplayRecords;
			$this->StopRecord = $this->DisplayRecords;
		} else {
			$selectLimit = $this->UseSelectLimit;
			if ($selectLimit) {
				$this->TotalRecords = $this->listRecordCount();
			} else {
				if ($this->Recordset = $this->loadRecordset())
					$this->TotalRecords = $this->Recordset->RecordCount();
			}
			$this->StartRecord = 1;
			$this->DisplayRecords = $this->TotalRecords; // Display all records
			if ($selectLimit)
				$this->Recordset = $this->loadRecordset($this->StartRecord - 1, $this->DisplayRecords);
		}

		// Normal return
		if (IsApi()) {
			$rows = $this->getRecordsFromRecordset($this->Recordset);
			$this->Recordset->close();
			WriteJson(["success" => TRUE, $this->TableVar => $rows, "totalRecordCount" => $this->TotalRecords]);
			$this->terminate(TRUE);
		}

		// Set up pager
		$this->Pager = new PrevNextPager($this->StartRecord, $this->getRecordsPerPage(), $this->TotalRecords, $this->PageSizes, $this->RecordRange, $this->AutoHidePager, $this->AutoHidePageSizeSelector);
	}

	// Set up number of records displayed per page
	protected function setupDisplayRecords()
	{
		$wrk = Get(Config("TABLE_REC_PER_PAGE"), "");
		if ($wrk != "") {
			if (is_numeric($wrk)) {
				$this->DisplayRecords = (int)$wrk;
			} else {
				if (SameText($wrk, "all")) { // Display all records
					$this->DisplayRecords = -1;
				} else {
					$this->DisplayRecords = 10; // Non-numeric, load default
				}
			}
			$this->setRecordsPerPage($this->DisplayRecords); // Save to Session

			// Reset start position
			$this->StartRecord = 1;
			$this->setStartRecordNumber($this->StartRecord);
		}
	}

	// Exit inline mode
	protected function clearInlineMode()
	{
		$this->amount->FormValue = ""; // Clear form value
		$this->LastAction = $this->CurrentAction; // Save last action
		$this->CurrentAction = ""; // Clear action
		$_SESSION[SESSION_INLINE_MODE] = ""; // Clear inline mode
	}

	// Switch to Grid Add mode
	protected function gridAddMode()
	{
		$this->CurrentAction = "gridadd";
		$_SESSION[SESSION_INLINE_MODE] = "gridadd";
		$this->hideFieldsForAddEdit();
	}

	// Switch to Grid Edit mode
	protected function gridEditMode()
	{
		$this->CurrentAction = "gridedit";
		$_SESSION[SESSION_INLINE_MODE] = "gridedit";
		$this->hideFieldsForAddEdit();
	}

	// Perform update to grid
	public function gridUpdate()
	{
		global $Language, $CurrentForm, $FormError;
		$gridUpdate = TRUE;

		// Get old recordset
		$this->CurrentFilter = $this->buildKeyFilter();
		if ($this->CurrentFilter == "")
			$this->CurrentFilter = "0=1";
		$sql = $this->getCurrentSql();
		$conn = $this->getConnection();
		if ($rs = $conn->execute($sql)) {
			$rsold = $rs->getRows();
			$rs->close();
		}

		// Call Grid Updating event
		if (!$this->Grid_Updating($rsold)) {
			if ($this->getFailureMessage() == "")
				$this->setFailureMessage($Language->phrase("GridEditCancelled")); // Set grid edit cancelled message
			return FALSE;
		}
		$key = "";

		// Update row index and get row key
		$CurrentForm->Index = -1;
		$rowcnt = strval($CurrentForm->getValue($this->FormKeyCountName));
		if ($rowcnt == "" || !is_numeric($rowcnt))
			$rowcnt = 0;

		// Update all rows based on key
		for ($rowindex = 1; $rowindex <= $rowcnt; $rowindex++) {
			$CurrentForm->Index = $rowindex;
			$rowkey = strval($CurrentForm->getValue($this->FormKeyName));
			$rowaction = strval($CurrentForm->getValue($this->FormActionName));

			// Load all values and keys
			if ($rowaction != "insertdelete") { // Skip insert then deleted rows
				$this->loadFormValues(); // Get form values
				if ($rowaction == "" || $rowaction == "edit" || $rowaction == "delete") {
					$gridUpdate = $this->setupKeyValues($rowkey); // Set up key values
				} else {
					$gridUpdate = TRUE;
				}

				// Skip empty row
				if ($rowaction == "insert" && $this->emptyRow()) {

					// No action required
				// Validate form and insert/update/delete record

				} elseif ($gridUpdate) {
					if ($rowaction == "delete") {
						$this->CurrentFilter = $this->getRecordFilter();
						$gridUpdate = $this->deleteRows(); // Delete this row
					} else if (!$this->validateForm()) {
						$gridUpdate = FALSE; // Form error, reset action
						$this->setFailureMessage($FormError);
					} else {
						if ($rowaction == "insert") {
							$gridUpdate = $this->addRow(); // Insert this row
						} else {
							if ($rowkey != "") {
								$this->SendEmail = FALSE; // Do not send email on update success
								$gridUpdate = $this->editRow(); // Update this row
							}
						} // End update
					}
				}
				if ($gridUpdate) {
					if ($key != "")
						$key .= ", ";
					$key .= $rowkey;
				} else {
					break;
				}
			}
		}
		if ($gridUpdate) {

			// Get new recordset
			if ($rs = $conn->execute($sql)) {
				$rsnew = $rs->getRows();
				$rs->close();
			}

			// Call Grid_Updated event
			$this->Grid_Updated($rsold, $rsnew);
			$this->clearInlineMode(); // Clear inline edit mode
		} else {
			if ($this->getFailureMessage() == "")
				$this->setFailureMessage($Language->phrase("UpdateFailed")); // Set update failed message
		}
		return $gridUpdate;
	}

	// Build filter for all keys
	protected function buildKeyFilter()
	{
		global $CurrentForm;
		$wrkFilter = "";

		// Update row index and get row key
		$rowindex = 1;
		$CurrentForm->Index = $rowindex;
		$thisKey = strval($CurrentForm->getValue($this->FormKeyName));
		while ($thisKey != "") {
			if ($this->setupKeyValues($thisKey)) {
				$filter = $this->getRecordFilter();
				if ($wrkFilter != "")
					$wrkFilter .= " OR ";
				$wrkFilter .= $filter;
			} else {
				$wrkFilter = "0=1";
				break;
			}

			// Update row index and get row key
			$rowindex++; // Next row
			$CurrentForm->Index = $rowindex;
			$thisKey = strval($CurrentForm->getValue($this->FormKeyName));
		}
		return $wrkFilter;
	}

	// Set up key values
	protected function setupKeyValues($key)
	{
		$arKeyFlds = explode(Config("COMPOSITE_KEY_SEPARATOR"), $key);
		if (count($arKeyFlds) >= 3) {
			$this->transID->setOldValue($arKeyFlds[0]);
			if (!is_numeric($this->transID->OldValue))
				return FALSE;
			$this->langID->setOldValue($arKeyFlds[1]);
			$this->transLineID->setOldValue($arKeyFlds[2]);
			if (!is_numeric($this->transLineID->OldValue))
				return FALSE;
		}
		return TRUE;
	}

	// Perform Grid Add
	public function gridInsert()
	{
		global $Language, $CurrentForm, $FormError;
		$rowindex = 1;
		$gridInsert = FALSE;
		$conn = $this->getConnection();

		// Call Grid Inserting event
		if (!$this->Grid_Inserting()) {
			if ($this->getFailureMessage() == "")
				$this->setFailureMessage($Language->phrase("GridAddCancelled")); // Set grid add cancelled message
			return FALSE;
		}

		// Init key filter
		$wrkfilter = "";
		$addcnt = 0;
		$key = "";

		// Get row count
		$CurrentForm->Index = -1;
		$rowcnt = strval($CurrentForm->getValue($this->FormKeyCountName));
		if ($rowcnt == "" || !is_numeric($rowcnt))
			$rowcnt = 0;

		// Insert all rows
		for ($rowindex = 1; $rowindex <= $rowcnt; $rowindex++) {

			// Load current row values
			$CurrentForm->Index = $rowindex;
			$rowaction = strval($CurrentForm->getValue($this->FormActionName));
			if ($rowaction != "" && $rowaction != "insert")
				continue; // Skip
			if ($rowaction == "insert") {
				$this->RowOldKey = strval($CurrentForm->getValue($this->FormOldKeyName));
				$this->loadOldRecord(); // Load old record
			}
			$this->loadFormValues(); // Get form values
			if (!$this->emptyRow()) {
				$addcnt++;
				$this->SendEmail = FALSE; // Do not send email on insert success

				// Validate form
				if (!$this->validateForm()) {
					$gridInsert = FALSE; // Form error, reset action
					$this->setFailureMessage($FormError);
				} else {
					$gridInsert = $this->addRow($this->OldRecordset); // Insert this row
				}
				if ($gridInsert) {
					if ($key != "")
						$key .= Config("COMPOSITE_KEY_SEPARATOR");
					$key .= $this->transID->CurrentValue;
					if ($key != "")
						$key .= Config("COMPOSITE_KEY_SEPARATOR");
					$key .= $this->langID->CurrentValue;
					if ($key != "")
						$key .= Config("COMPOSITE_KEY_SEPARATOR");
					$key .= $this->transLineID->CurrentValue;

					// Add filter for this record
					$filter = $this->getRecordFilter();
					if ($wrkfilter != "")
						$wrkfilter .= " OR ";
					$wrkfilter .= $filter;
				} else {
					break;
				}
			}
		}
		if ($addcnt == 0) { // No record inserted
			$this->clearInlineMode(); // Clear grid add mode and return
			return TRUE;
		}
		if ($gridInsert) {

			// Get new recordset
			$this->CurrentFilter = $wrkfilter;
			$sql = $this->getCurrentSql();
			if ($rs = $conn->execute($sql)) {
				$rsnew = $rs->getRows();
				$rs->close();
			}

			// Call Grid_Inserted event
			$this->Grid_Inserted($rsnew);
			$this->clearInlineMode(); // Clear grid add mode
		} else {
			if ($this->getFailureMessage() == "")
				$this->setFailureMessage($Language->phrase("InsertFailed")); // Set insert failed message
		}
		return $gridInsert;
	}

	// Check if empty row
	public function emptyRow()
	{
		global $CurrentForm;
		if ($CurrentForm->hasValue("x_acctID") && $CurrentForm->hasValue("o_acctID") && $this->acctID->CurrentValue != $this->acctID->OldValue)
			return FALSE;
		if ($CurrentForm->hasValue("x_transType") && $CurrentForm->hasValue("o_transType") && $this->transType->CurrentValue != $this->transType->OldValue)
			return FALSE;
		if ($CurrentForm->hasValue("x_currID") && $CurrentForm->hasValue("o_currID") && $this->currID->CurrentValue != $this->currID->OldValue)
			return FALSE;
		if ($CurrentForm->hasValue("x_amount") && $CurrentForm->hasValue("o_amount") && $this->amount->CurrentValue != $this->amount->OldValue)
			return FALSE;
		if ($CurrentForm->hasValue("x_transTime") && $CurrentForm->hasValue("o_transTime") && $this->transTime->CurrentValue != $this->transTime->OldValue)
			return FALSE;
		if ($CurrentForm->hasValue("x_sourceUserID") && $CurrentForm->hasValue("o_sourceUserID") && $this->sourceUserID->CurrentValue != $this->sourceUserID->OldValue)
			return FALSE;
		if ($CurrentForm->hasValue("x_destinationUserID") && $CurrentForm->hasValue("o_destinationUserID") && $this->destinationUserID->CurrentValue != $this->destinationUserID->OldValue)
			return FALSE;
		if ($CurrentForm->hasValue("x_referenceTXID") && $CurrentForm->hasValue("o_referenceTXID") && $this->referenceTXID->CurrentValue != $this->referenceTXID->OldValue)
			return FALSE;
		if ($CurrentForm->hasValue("x_msg") && $CurrentForm->hasValue("o_msg") && $this->msg->CurrentValue != $this->msg->OldValue)
			return FALSE;
		return TRUE;
	}

	// Validate grid form
	public function validateGridForm()
	{
		global $CurrentForm;

		// Get row count
		$CurrentForm->Index = -1;
		$rowcnt = strval($CurrentForm->getValue($this->FormKeyCountName));
		if ($rowcnt == "" || !is_numeric($rowcnt))
			$rowcnt = 0;

		// Validate all records
		for ($rowindex = 1; $rowindex <= $rowcnt; $rowindex++) {

			// Load current row values
			$CurrentForm->Index = $rowindex;
			$rowaction = strval($CurrentForm->getValue($this->FormActionName));
			if ($rowaction != "delete" && $rowaction != "insertdelete") {
				$this->loadFormValues(); // Get form values
				if ($rowaction == "insert" && $this->emptyRow()) {

					// Ignore
				} else if (!$this->validateForm()) {
					return FALSE;
				}
			}
		}
		return TRUE;
	}

	// Get all form values of the grid
	public function getGridFormValues()
	{
		global $CurrentForm;

		// Get row count
		$CurrentForm->Index = -1;
		$rowcnt = strval($CurrentForm->getValue($this->FormKeyCountName));
		if ($rowcnt == "" || !is_numeric($rowcnt))
			$rowcnt = 0;
		$rows = [];

		// Loop through all records
		for ($rowindex = 1; $rowindex <= $rowcnt; $rowindex++) {

			// Load current row values
			$CurrentForm->Index = $rowindex;
			$rowaction = strval($CurrentForm->getValue($this->FormActionName));
			if ($rowaction != "delete" && $rowaction != "insertdelete") {
				$this->loadFormValues(); // Get form values
				if ($rowaction == "insert" && $this->emptyRow()) {

					// Ignore
				} else {
					$rows[] = $this->getFieldValues("FormValue"); // Return row as array
				}
			}
		}
		return $rows; // Return as array of array
	}

	// Restore form values for current row
	public function restoreCurrentRowFormValues($idx)
	{
		global $CurrentForm;

		// Get row based on current index
		$CurrentForm->Index = $idx;
		$this->loadFormValues(); // Load form values
	}

	// Set up sort parameters
	protected function setupSortOrder()
	{

		// Check for "order" parameter
		if (Get("order") !== NULL) {
			$this->CurrentOrder = Get("order");
			$this->CurrentOrderType = Get("ordertype", "");
			$this->setStartRecordNumber(1); // Reset start position
		}
	}

	// Load sort order parameters
	protected function loadSortOrder()
	{
		$orderBy = $this->getSessionOrderBy(); // Get ORDER BY from Session
		if ($orderBy == "") {
			if ($this->getSqlOrderBy() != "") {
				$orderBy = $this->getSqlOrderBy();
				$this->setSessionOrderBy($orderBy);
			}
		}
	}

	// Reset command
	// - cmd=reset (Reset search parameters)
	// - cmd=resetall (Reset search and master/detail parameters)
	// - cmd=resetsort (Reset sort parameters)

	protected function resetCmd()
	{

		// Check if reset command
		if (StartsString("reset", $this->Command)) {

			// Reset master/detail keys
			if ($this->Command == "resetall") {
				$this->setCurrentMasterTable(""); // Clear master table
				$this->DbMasterFilter = "";
				$this->DbDetailFilter = "";
				$this->piid->setSessionValue("");
			}

			// Reset sorting order
			if ($this->Command == "resetsort") {
				$orderBy = "";
				$this->setSessionOrderBy($orderBy);
			}

			// Reset start position
			$this->StartRecord = 1;
			$this->setStartRecordNumber($this->StartRecord);
		}
	}

	// Set up list options
	protected function setupListOptions()
	{
		global $Security, $Language;

		// "griddelete"
		if ($this->AllowAddDeleteRow) {
			$item = &$this->ListOptions->add("griddelete");
			$item->CssClass = "text-nowrap";
			$item->OnLeft = FALSE;
			$item->Visible = FALSE; // Default hidden
		}

		// Add group option item
		$item = &$this->ListOptions->add($this->ListOptions->GroupOptionName);
		$item->Body = "";
		$item->OnLeft = FALSE;
		$item->Visible = FALSE;

		// Drop down button for ListOptions
		$this->ListOptions->UseDropDownButton = FALSE;
		$this->ListOptions->DropDownButtonPhrase = $Language->phrase("ButtonListOptions");
		$this->ListOptions->UseButtonGroup = FALSE;
		if ($this->ListOptions->UseButtonGroup && IsMobile())
			$this->ListOptions->UseDropDownButton = TRUE;

		//$this->ListOptions->ButtonClass = ""; // Class for button group
		// Call ListOptions_Load event

		$this->ListOptions_Load();
		$item = $this->ListOptions[$this->ListOptions->GroupOptionName];
		$item->Visible = $this->ListOptions->groupOptionVisible();
	}

	// Render list options
	public function renderListOptions()
	{
		global $Security, $Language, $CurrentForm;
		$this->ListOptions->loadDefault();

		// Call ListOptions_Rendering event
		$this->ListOptions_Rendering();

		// Set up row action and key
		if (is_numeric($this->RowIndex) && $this->CurrentMode != "view") {
			$CurrentForm->Index = $this->RowIndex;
			$actionName = str_replace("k_", "k" . $this->RowIndex . "_", $this->FormActionName);
			$oldKeyName = str_replace("k_", "k" . $this->RowIndex . "_", $this->FormOldKeyName);
			$keyName = str_replace("k_", "k" . $this->RowIndex . "_", $this->FormKeyName);
			$blankRowName = str_replace("k_", "k" . $this->RowIndex . "_", $this->FormBlankRowName);
			if ($this->RowAction != "")
				$this->MultiSelectKey .= "<input type=\"hidden\" name=\"" . $actionName . "\" id=\"" . $actionName . "\" value=\"" . $this->RowAction . "\">";
			if ($CurrentForm->hasValue($this->FormOldKeyName))
				$this->RowOldKey = strval($CurrentForm->getValue($this->FormOldKeyName));
			if ($this->RowOldKey != "")
				$this->MultiSelectKey .= "<input type=\"hidden\" name=\"" . $oldKeyName . "\" id=\"" . $oldKeyName . "\" value=\"" . HtmlEncode($this->RowOldKey) . "\">";
			if ($this->RowAction == "delete") {
				$rowkey = $CurrentForm->getValue($this->FormKeyName);
				$this->setupKeyValues($rowkey);

				// Reload hidden key for delete
				$this->MultiSelectKey .= "<input type=\"hidden\" name=\"" . $keyName . "\" id=\"" . $keyName . "\" value=\"" . HtmlEncode($rowkey) . "\">";
			}
			if ($this->RowAction == "insert" && $this->isConfirm() && $this->emptyRow())
				$this->MultiSelectKey .= "<input type=\"hidden\" name=\"" . $blankRowName . "\" id=\"" . $blankRowName . "\" value=\"1\">";
		}

		// "delete"
		if ($this->AllowAddDeleteRow) {
			if ($this->CurrentMode == "add" || $this->CurrentMode == "copy" || $this->CurrentMode == "edit") {
				$options = &$this->ListOptions;
				$options->UseButtonGroup = TRUE; // Use button group for grid delete button
				$opt = $options["griddelete"];
				if (is_numeric($this->RowIndex) && ($this->RowAction == "" || $this->RowAction == "edit")) { // Do not allow delete existing record
					$opt->Body = "&nbsp;";
				} else {
					$opt->Body = "<a class=\"ew-grid-link ew-grid-delete\" title=\"" . HtmlTitle($Language->phrase("DeleteLink")) . "\" data-caption=\"" . HtmlTitle($Language->phrase("DeleteLink")) . "\" onclick=\"return ew.deleteGridRow(this, " . $this->RowIndex . ");\">" . $Language->phrase("DeleteLink") . "</a>";
				}
			}
		}
		if ($this->CurrentMode == "view") { // View mode
		} // End View mode
		if ($this->CurrentMode == "edit" && is_numeric($this->RowIndex) && $this->RowAction != "delete") {
			$this->MultiSelectKey .= "<input type=\"hidden\" name=\"" . $keyName . "\" id=\"" . $keyName . "\" value=\"" . $this->transID->CurrentValue . Config("COMPOSITE_KEY_SEPARATOR") . $this->langID->CurrentValue . Config("COMPOSITE_KEY_SEPARATOR") . $this->transLineID->CurrentValue . "\">";
		}
		$this->renderListOptionsExt();

		// Call ListOptions_Rendered event
		$this->ListOptions_Rendered();
	}

	// Set record key
	public function setRecordKey(&$key, $rs)
	{
		$key = "";
		if ($key != "")
			$key .= Config("COMPOSITE_KEY_SEPARATOR");
		$key .= $rs->fields('transID');
		if ($key != "")
			$key .= Config("COMPOSITE_KEY_SEPARATOR");
		$key .= $rs->fields('langID');
		if ($key != "")
			$key .= Config("COMPOSITE_KEY_SEPARATOR");
		$key .= $rs->fields('transLineID');
	}

	// Set up other options
	protected function setupOtherOptions()
	{
		global $Language, $Security;
		$option = $this->OtherOptions["addedit"];
		$option->UseDropDownButton = FALSE;
		$option->DropDownButtonPhrase = $Language->phrase("ButtonAddEdit");
		$option->UseButtonGroup = TRUE;

		//$option->ButtonClass = ""; // Class for button group
		$item = &$option->add($option->GroupOptionName);
		$item->Body = "";
		$item->Visible = FALSE;
	}

	// Render other options
	public function renderOtherOptions()
	{
		global $Language, $Security;
		$options = &$this->OtherOptions;
		if (($this->CurrentMode == "add" || $this->CurrentMode == "copy" || $this->CurrentMode == "edit") && !$this->isConfirm()) { // Check add/copy/edit mode
			if ($this->AllowAddDeleteRow) {
				$option = $options["addedit"];
				$option->UseDropDownButton = FALSE;
				$item = &$option->add("addblankrow");
				$item->Body = "<a class=\"ew-add-edit ew-add-blank-row\" title=\"" . HtmlTitle($Language->phrase("AddBlankRow")) . "\" data-caption=\"" . HtmlTitle($Language->phrase("AddBlankRow")) . "\" href=\"#\" onclick=\"return ew.addGridRow(this);\">" . $Language->phrase("AddBlankRow") . "</a>";
				$item->Visible = FALSE;
				$this->ShowOtherOptions = $item->Visible;
			}
		}
		if ($this->CurrentMode == "view") { // Check view mode
			$option = $options["addedit"];
			$item = $option["add"];
			$this->ShowOtherOptions = $item && $item->Visible;
		}
	}

// Set up list options (extended codes)
	protected function setupListOptionsExt()
	{

		// Hide detail items for dropdown if necessary
		$this->ListOptions->hideDetailItemsForDropDown();
	}

// Render list options (extended codes)
	protected function renderListOptionsExt()
	{
		global $Security, $Language;
		$links = "";
		$btngrps = "";
		$sqlwrk = "`acctID`=" . AdjustSql($this->acctID->CurrentValue, $this->Dbid) . "";

		// Column "detail_vcardacctbalance"
		if ($this->DetailPages && $this->DetailPages["vcardacctbalance"] && $this->DetailPages["vcardacctbalance"]->Visible) {
			$link = "";
			$option = $this->ListOptions["detail_vcardacctbalance"];
			$url = "vcardacctbalancepreview.php?t=vtranshistorycardtypes&f=" . Encrypt($sqlwrk);
			$btngrp = "<div data-table=\"vcardacctbalance\" data-url=\"" . $url . "\">";
			if ($Security->allowList(CurrentProjectID() . 'vtranshistorycardtypes')) {
				$label = $Language->TablePhrase("vcardacctbalance", "TblCaption");
				$link = "<li class=\"nav-item\"><a href=\"#\" class=\"nav-link\" data-toggle=\"tab\" data-table=\"vcardacctbalance\" data-url=\"" . $url . "\">" . $label . "</a></li>";
				$links .= $link;
				$detaillnk = JsEncodeAttribute("vcardacctbalancelist.php?" . Config("TABLE_SHOW_MASTER") . "=vtranshistorycardtypes&fk_acctID=" . urlencode(strval($this->acctID->CurrentValue)) . "");
				$btngrp .= "<a href=\"#\" class=\"mr-2\" title=\"" . $Language->TablePhrase("vcardacctbalance", "TblCaption") . "\" onclick=\"window.location='" . $detaillnk . "';return false;\">" . $Language->phrase("MasterDetailListLink") . "</a>";
			}
			if (!isset($GLOBALS["vcardacctbalance_grid"]))
				$GLOBALS["vcardacctbalance_grid"] = new vcardacctbalance_grid();
			if ($GLOBALS["vcardacctbalance_grid"]->DetailView && $Security->canView() && $Security->allowView(CurrentProjectID() . 'vtranshistorycardtypes')) {
				$caption = $Language->phrase("MasterDetailViewLink");
				$url = $this->getViewUrl(Config("TABLE_SHOW_DETAIL") . "=vcardacctbalance");
				$btngrp .= "<a href=\"#\" class=\"mr-2\" title=\"" . HtmlTitle($caption) . "\" onclick=\"window.location='" . HtmlEncode($url) . "';return false;\">" . $caption . "</a>";
			}
			$btngrp .= "</div>";
			if ($link != "") {
				$btngrps .= $btngrp;
				$option->Body .= "<div class=\"d-none ew-preview\">" . $link . $btngrp . "</div>";
			}
		}

		// Hide detail items if necessary
		$this->ListOptions->hideDetailItemsForDropDown();

		// Column "preview"
		$option = $this->ListOptions["preview"];
		if (!$option) { // Add preview column
			$option = &$this->ListOptions->add("preview");
			$option->OnLeft = FALSE;
			if ($option->OnLeft) {
				$option->moveTo($this->ListOptions->itemPos("checkbox") + 1);
			} else {
				$option->moveTo($this->ListOptions->itemPos("checkbox"));
			}
			$option->Visible = !($this->isExport() || $this->isGridAdd() || $this->isGridEdit());
			$option->ShowInDropDown = FALSE;
			$option->ShowInButtonGroup = FALSE;
		}
		if ($option) {
			$option->Body = "<i class=\"ew-preview-row-btn ew-icon icon-expand\"></i>";
			$option->Body .= "<div class=\"d-none ew-preview\">" . $links . $btngrps . "</div>";
			if ($option->Visible)
				$option->Visible = $links != "";
		}

		// Column "details" (Multiple details)
		$option = $this->ListOptions["details"];
		if ($option) {
			$option->Body .= "<div class=\"d-none ew-preview\">" . $links . $btngrps . "</div>";
			if ($option->Visible)
				$option->Visible = $links != "";
		}
	}

	// Get upload files
	protected function getUploadFiles()
	{
		global $CurrentForm, $Language;
	}

	// Load default values
	protected function loadDefaultValues()
	{
		$this->transID->CurrentValue = NULL;
		$this->transID->OldValue = $this->transID->CurrentValue;
		$this->acctID->CurrentValue = NULL;
		$this->acctID->OldValue = $this->acctID->CurrentValue;
		$this->transType->CurrentValue = 0;
		$this->transType->OldValue = $this->transType->CurrentValue;
		$this->transtypelabel->CurrentValue = NULL;
		$this->transtypelabel->OldValue = $this->transtypelabel->CurrentValue;
		$this->currID->CurrentValue = NULL;
		$this->currID->OldValue = $this->currID->CurrentValue;
		$this->amount->CurrentValue = 0.00;
		$this->amount->OldValue = $this->amount->CurrentValue;
		$this->transTime->CurrentValue = "0000-00-00 00:00:00";
		$this->transTime->OldValue = $this->transTime->CurrentValue;
		$this->sourceUserID->CurrentValue = NULL;
		$this->sourceUserID->OldValue = $this->sourceUserID->CurrentValue;
		$this->destinationUserID->CurrentValue = NULL;
		$this->destinationUserID->OldValue = $this->destinationUserID->CurrentValue;
		$this->referenceTXID->CurrentValue = NULL;
		$this->referenceTXID->OldValue = $this->referenceTXID->CurrentValue;
		$this->langID->CurrentValue = NULL;
		$this->langID->OldValue = $this->langID->CurrentValue;
		$this->sourceNodeID->CurrentValue = NULL;
		$this->sourceNodeID->OldValue = $this->sourceNodeID->CurrentValue;
		$this->destinationNodeID->CurrentValue = NULL;
		$this->destinationNodeID->OldValue = $this->destinationNodeID->CurrentValue;
		$this->msg->CurrentValue = NULL;
		$this->msg->OldValue = $this->msg->CurrentValue;
		$this->transLineID->CurrentValue = NULL;
		$this->transLineID->OldValue = $this->transLineID->CurrentValue;
		$this->piid->CurrentValue = NULL;
		$this->piid->OldValue = $this->piid->CurrentValue;
	}

	// Load form values
	protected function loadFormValues()
	{

		// Load from form
		global $CurrentForm;
		$CurrentForm->FormName = $this->FormName;

		// Check field name 'transID' first before field var 'x_transID'
		$val = $CurrentForm->hasValue("transID") ? $CurrentForm->getValue("transID") : $CurrentForm->getValue("x_transID");
		if (!$this->transID->IsDetailKey && !$this->isGridAdd() && !$this->isAdd())
			$this->transID->setFormValue($val);

		// Check field name 'acctID' first before field var 'x_acctID'
		$val = $CurrentForm->hasValue("acctID") ? $CurrentForm->getValue("acctID") : $CurrentForm->getValue("x_acctID");
		if (!$this->acctID->IsDetailKey) {
			if (IsApi() && $val === NULL)
				$this->acctID->Visible = FALSE; // Disable update for API request
			else
				$this->acctID->setFormValue($val);
		}
		if ($CurrentForm->hasValue("o_acctID"))
			$this->acctID->setOldValue($CurrentForm->getValue("o_acctID"));

		// Check field name 'transType' first before field var 'x_transType'
		$val = $CurrentForm->hasValue("transType") ? $CurrentForm->getValue("transType") : $CurrentForm->getValue("x_transType");
		if (!$this->transType->IsDetailKey) {
			if (IsApi() && $val === NULL)
				$this->transType->Visible = FALSE; // Disable update for API request
			else
				$this->transType->setFormValue($val);
		}
		if ($CurrentForm->hasValue("o_transType"))
			$this->transType->setOldValue($CurrentForm->getValue("o_transType"));

		// Check field name 'currID' first before field var 'x_currID'
		$val = $CurrentForm->hasValue("currID") ? $CurrentForm->getValue("currID") : $CurrentForm->getValue("x_currID");
		if (!$this->currID->IsDetailKey) {
			if (IsApi() && $val === NULL)
				$this->currID->Visible = FALSE; // Disable update for API request
			else
				$this->currID->setFormValue($val);
		}
		if ($CurrentForm->hasValue("o_currID"))
			$this->currID->setOldValue($CurrentForm->getValue("o_currID"));

		// Check field name 'amount' first before field var 'x_amount'
		$val = $CurrentForm->hasValue("amount") ? $CurrentForm->getValue("amount") : $CurrentForm->getValue("x_amount");
		if (!$this->amount->IsDetailKey) {
			if (IsApi() && $val === NULL)
				$this->amount->Visible = FALSE; // Disable update for API request
			else
				$this->amount->setFormValue($val);
		}
		if ($CurrentForm->hasValue("o_amount"))
			$this->amount->setOldValue($CurrentForm->getValue("o_amount"));

		// Check field name 'transTime' first before field var 'x_transTime'
		$val = $CurrentForm->hasValue("transTime") ? $CurrentForm->getValue("transTime") : $CurrentForm->getValue("x_transTime");
		if (!$this->transTime->IsDetailKey) {
			if (IsApi() && $val === NULL)
				$this->transTime->Visible = FALSE; // Disable update for API request
			else
				$this->transTime->setFormValue($val);
			$this->transTime->CurrentValue = UnFormatDateTime($this->transTime->CurrentValue, 0);
		}
		if ($CurrentForm->hasValue("o_transTime"))
			$this->transTime->setOldValue($CurrentForm->getValue("o_transTime"));

		// Check field name 'sourceUserID' first before field var 'x_sourceUserID'
		$val = $CurrentForm->hasValue("sourceUserID") ? $CurrentForm->getValue("sourceUserID") : $CurrentForm->getValue("x_sourceUserID");
		if (!$this->sourceUserID->IsDetailKey) {
			if (IsApi() && $val === NULL)
				$this->sourceUserID->Visible = FALSE; // Disable update for API request
			else
				$this->sourceUserID->setFormValue($val);
		}
		if ($CurrentForm->hasValue("o_sourceUserID"))
			$this->sourceUserID->setOldValue($CurrentForm->getValue("o_sourceUserID"));

		// Check field name 'destinationUserID' first before field var 'x_destinationUserID'
		$val = $CurrentForm->hasValue("destinationUserID") ? $CurrentForm->getValue("destinationUserID") : $CurrentForm->getValue("x_destinationUserID");
		if (!$this->destinationUserID->IsDetailKey) {
			if (IsApi() && $val === NULL)
				$this->destinationUserID->Visible = FALSE; // Disable update for API request
			else
				$this->destinationUserID->setFormValue($val);
		}
		if ($CurrentForm->hasValue("o_destinationUserID"))
			$this->destinationUserID->setOldValue($CurrentForm->getValue("o_destinationUserID"));

		// Check field name 'referenceTXID' first before field var 'x_referenceTXID'
		$val = $CurrentForm->hasValue("referenceTXID") ? $CurrentForm->getValue("referenceTXID") : $CurrentForm->getValue("x_referenceTXID");
		if (!$this->referenceTXID->IsDetailKey) {
			if (IsApi() && $val === NULL)
				$this->referenceTXID->Visible = FALSE; // Disable update for API request
			else
				$this->referenceTXID->setFormValue($val);
		}
		if ($CurrentForm->hasValue("o_referenceTXID"))
			$this->referenceTXID->setOldValue($CurrentForm->getValue("o_referenceTXID"));

		// Check field name 'msg' first before field var 'x_msg'
		$val = $CurrentForm->hasValue("msg") ? $CurrentForm->getValue("msg") : $CurrentForm->getValue("x_msg");
		if (!$this->msg->IsDetailKey) {
			if (IsApi() && $val === NULL)
				$this->msg->Visible = FALSE; // Disable update for API request
			else
				$this->msg->setFormValue($val);
		}
		if ($CurrentForm->hasValue("o_msg"))
			$this->msg->setOldValue($CurrentForm->getValue("o_msg"));

		// Check field name 'langID' first before field var 'x_langID'
		$val = $CurrentForm->hasValue("langID") ? $CurrentForm->getValue("langID") : $CurrentForm->getValue("x_langID");
		if (!$this->langID->IsDetailKey)
			$this->langID->setFormValue($val);

		// Check field name 'transLineID' first before field var 'x_transLineID'
		$val = $CurrentForm->hasValue("transLineID") ? $CurrentForm->getValue("transLineID") : $CurrentForm->getValue("x_transLineID");
		if (!$this->transLineID->IsDetailKey && !$this->isGridAdd() && !$this->isAdd())
			$this->transLineID->setFormValue($val);
	}

	// Restore form values
	public function restoreFormValues()
	{
		global $CurrentForm;
		$this->langID->CurrentValue = $this->langID->FormValue;
		if (!$this->isGridAdd() && !$this->isAdd())
			$this->transLineID->CurrentValue = $this->transLineID->FormValue;
		if (!$this->isGridAdd() && !$this->isAdd())
			$this->transID->CurrentValue = $this->transID->FormValue;
		$this->acctID->CurrentValue = $this->acctID->FormValue;
		$this->transType->CurrentValue = $this->transType->FormValue;
		$this->currID->CurrentValue = $this->currID->FormValue;
		$this->amount->CurrentValue = $this->amount->FormValue;
		$this->transTime->CurrentValue = $this->transTime->FormValue;
		$this->transTime->CurrentValue = UnFormatDateTime($this->transTime->CurrentValue, 0);
		$this->sourceUserID->CurrentValue = $this->sourceUserID->FormValue;
		$this->destinationUserID->CurrentValue = $this->destinationUserID->FormValue;
		$this->referenceTXID->CurrentValue = $this->referenceTXID->FormValue;
		$this->msg->CurrentValue = $this->msg->FormValue;
	}

	// Load recordset
	public function loadRecordset($offset = -1, $rowcnt = -1)
	{

		// Load List page SQL
		$sql = $this->getListSql();
		$conn = $this->getConnection();

		// Load recordset
		$dbtype = GetConnectionType($this->Dbid);
		if ($this->UseSelectLimit) {
			$conn->raiseErrorFn = Config("ERROR_FUNC");
			if ($dbtype == "MSSQL") {
				$rs = $conn->selectLimit($sql, $rowcnt, $offset, ["_hasOrderBy" => trim($this->getOrderBy()) || trim($this->getSessionOrderBy())]);
			} else {
				$rs = $conn->selectLimit($sql, $rowcnt, $offset);
			}
			$conn->raiseErrorFn = "";
		} else {
			$rs = LoadRecordset($sql, $conn);
		}

		// Call Recordset Selected event
		$this->Recordset_Selected($rs);
		return $rs;
	}

	// Load row based on key values
	public function loadRow()
	{
		global $Security, $Language;
		$filter = $this->getRecordFilter();

		// Call Row Selecting event
		$this->Row_Selecting($filter);

		// Load SQL based on filter
		$this->CurrentFilter = $filter;
		$sql = $this->getCurrentSql();
		$conn = $this->getConnection();
		$res = FALSE;
		$rs = LoadRecordset($sql, $conn);
		if ($rs && !$rs->EOF) {
			$res = TRUE;
			$this->loadRowValues($rs); // Load row values
			$rs->close();
		}
		return $res;
	}

	// Load row values from recordset
	public function loadRowValues($rs = NULL)
	{
		if ($rs && !$rs->EOF)
			$row = $rs->fields;
		else
			$row = $this->newRow();

		// Call Row Selected event
		$this->Row_Selected($row);
		if (!$rs || $rs->EOF)
			return;
		$this->transID->setDbValue($row['transID']);
		$this->acctID->setDbValue($row['acctID']);
		$this->transType->setDbValue($row['transType']);
		$this->transtypelabel->setDbValue($row['transtypelabel']);
		$this->currID->setDbValue($row['currID']);
		$this->amount->setDbValue($row['amount']);
		$this->transTime->setDbValue($row['transTime']);
		$this->sourceUserID->setDbValue($row['sourceUserID']);
		$this->destinationUserID->setDbValue($row['destinationUserID']);
		$this->referenceTXID->setDbValue($row['referenceTXID']);
		$this->langID->setDbValue($row['langID']);
		$this->sourceNodeID->setDbValue($row['sourceNodeID']);
		$this->destinationNodeID->setDbValue($row['destinationNodeID']);
		$this->msg->setDbValue($row['msg']);
		$this->transLineID->setDbValue($row['transLineID']);
		$this->piid->setDbValue($row['piid']);
	}

	// Return a row with default values
	protected function newRow()
	{
		$this->loadDefaultValues();
		$row = [];
		$row['transID'] = $this->transID->CurrentValue;
		$row['acctID'] = $this->acctID->CurrentValue;
		$row['transType'] = $this->transType->CurrentValue;
		$row['transtypelabel'] = $this->transtypelabel->CurrentValue;
		$row['currID'] = $this->currID->CurrentValue;
		$row['amount'] = $this->amount->CurrentValue;
		$row['transTime'] = $this->transTime->CurrentValue;
		$row['sourceUserID'] = $this->sourceUserID->CurrentValue;
		$row['destinationUserID'] = $this->destinationUserID->CurrentValue;
		$row['referenceTXID'] = $this->referenceTXID->CurrentValue;
		$row['langID'] = $this->langID->CurrentValue;
		$row['sourceNodeID'] = $this->sourceNodeID->CurrentValue;
		$row['destinationNodeID'] = $this->destinationNodeID->CurrentValue;
		$row['msg'] = $this->msg->CurrentValue;
		$row['transLineID'] = $this->transLineID->CurrentValue;
		$row['piid'] = $this->piid->CurrentValue;
		return $row;
	}

	// Load old record
	protected function loadOldRecord()
	{

		// Load key values from Session
		$validKey = TRUE;
		$keys = explode(Config("COMPOSITE_KEY_SEPARATOR"), $this->RowOldKey);
		$cnt = count($keys);
		if ($cnt >= 3) {
			if (strval($keys[0]) != "")
				$this->transID->OldValue = strval($keys[0]); // transID
			else
				$validKey = FALSE;
			if (strval($keys[1]) != "")
				$this->langID->OldValue = strval($keys[1]); // langID
			else
				$validKey = FALSE;
			if (strval($keys[2]) != "")
				$this->transLineID->OldValue = strval($keys[2]); // transLineID
			else
				$validKey = FALSE;
		} else {
			$validKey = FALSE;
		}

		// Load old record
		$this->OldRecordset = NULL;
		if ($validKey) {
			$this->CurrentFilter = $this->getRecordFilter();
			$sql = $this->getCurrentSql();
			$conn = $this->getConnection();
			$this->OldRecordset = LoadRecordset($sql, $conn);
		}
		$this->loadRowValues($this->OldRecordset); // Load row values
		return $validKey;
	}

	// Render row values based on field settings
	public function renderRow()
	{
		global $Security, $Language, $CurrentLanguage;

		// Initialize URLs
		$this->ViewUrl = $this->getViewUrl();
		$this->EditUrl = $this->getEditUrl();
		$this->CopyUrl = $this->getCopyUrl();
		$this->DeleteUrl = $this->getDeleteUrl();

		// Convert decimal values if posted back
		if ($this->amount->FormValue == $this->amount->CurrentValue && is_numeric(ConvertToFloatString($this->amount->CurrentValue)))
			$this->amount->CurrentValue = ConvertToFloatString($this->amount->CurrentValue);

		// Call Row_Rendering event
		$this->Row_Rendering();

		// Common render codes for all row types
		// transID
		// acctID
		// transType
		// transtypelabel

		$this->transtypelabel->CellCssStyle = "white-space: nowrap;";

		// currID
		// amount
		// transTime
		// sourceUserID
		// destinationUserID
		// referenceTXID
		// langID

		$this->langID->CellCssStyle = "white-space: nowrap;";

		// sourceNodeID
		$this->sourceNodeID->CellCssStyle = "white-space: nowrap;";

		// destinationNodeID
		$this->destinationNodeID->CellCssStyle = "white-space: nowrap;";

		// msg
		// transLineID

		$this->transLineID->CellCssStyle = "white-space: nowrap;";

		// piid
		$this->piid->CellCssStyle = "white-space: nowrap;";
		if ($this->RowType == ROWTYPE_VIEW) { // View row

			// transID
			$this->transID->ViewValue = $this->transID->CurrentValue;
			$this->transID->ViewCustomAttributes = "";

			// acctID
			$this->acctID->ViewValue = $this->acctID->CurrentValue;
			$this->acctID->ViewCustomAttributes = "";

			// transType
			$curVal = strval($this->transType->CurrentValue);
			if ($curVal != "") {
				$this->transType->ViewValue = $this->transType->lookupCacheOption($curVal);
				if ($this->transType->ViewValue === NULL) { // Lookup from database
					$filterWrk = "`typeID`" . SearchString("=", $curVal, DATATYPE_NUMBER, "_4payreference");
					$lookupFilter = function() {
						return "`langID` = 'EN'";
					};
					$lookupFilter = $lookupFilter->bindTo($this);
					$sqlWrk = $this->transType->Lookup->getSql(FALSE, $filterWrk, $lookupFilter, $this);
					$rswrk = Conn("_4payreference")->execute($sqlWrk);
					if ($rswrk && !$rswrk->EOF) { // Lookup values found
						$arwrk = [];
						$arwrk[1] = $rswrk->fields('df');
						$this->transType->ViewValue = $this->transType->displayValue($arwrk);
						$rswrk->Close();
					} else {
						$this->transType->ViewValue = $this->transType->CurrentValue;
					}
				}
			} else {
				$this->transType->ViewValue = NULL;
			}
			$this->transType->ViewCustomAttributes = "";

			// currID
			$this->currID->ViewValue = $this->currID->CurrentValue;
			$this->currID->ViewCustomAttributes = "";

			// amount
			$this->amount->ViewValue = $this->amount->CurrentValue;
			$this->amount->ViewValue = FormatNumber($this->amount->ViewValue, 2, -2, -1, -2);
			$this->amount->ViewCustomAttributes = "";

			// transTime
			$this->transTime->ViewValue = $this->transTime->CurrentValue;
			$this->transTime->ViewValue = FormatDateTime($this->transTime->ViewValue, 0);
			$this->transTime->ViewCustomAttributes = "";

			// sourceUserID
			$this->sourceUserID->ViewValue = $this->sourceUserID->CurrentValue;
			$this->sourceUserID->ViewCustomAttributes = "";

			// destinationUserID
			$this->destinationUserID->ViewValue = $this->destinationUserID->CurrentValue;
			$this->destinationUserID->ViewCustomAttributes = "";

			// referenceTXID
			$this->referenceTXID->ViewValue = $this->referenceTXID->CurrentValue;
			$this->referenceTXID->ViewCustomAttributes = "";

			// msg
			$this->msg->ViewValue = $this->msg->CurrentValue;
			$this->msg->ViewCustomAttributes = "";

			// transID
			$this->transID->LinkCustomAttributes = "";
			if (!EmptyValue($this->transID->CurrentValue)) {
				$this->transID->HrefValue = "transhistorylist.php?showmaster=transgroup&fk_groupID=" . $this->transID->CurrentValue; // Add prefix/suffix
				$this->transID->LinkAttrs["target"] = ""; // Add target
				if ($this->isExport())
					$this->transID->HrefValue = FullUrl($this->transID->HrefValue, "href");
			} else {
				$this->transID->HrefValue = "";
			}
			$this->transID->TooltipValue = "";

			// acctID
			$this->acctID->LinkCustomAttributes = "";
			if (!EmptyValue($this->acctID->CurrentValue)) {
				$this->acctID->HrefValue = "acctbalancelist.php?x_acctID=" . $this->acctID->CurrentValue . "&z_acctID=%3D&cmd=search"; // Add prefix/suffix
				$this->acctID->LinkAttrs["target"] = ""; // Add target
				if ($this->isExport())
					$this->acctID->HrefValue = FullUrl($this->acctID->HrefValue, "href");
			} else {
				$this->acctID->HrefValue = "";
			}
			$this->acctID->TooltipValue = "";

			// transType
			$this->transType->LinkCustomAttributes = "";
			$this->transType->HrefValue = "";
			$this->transType->TooltipValue = "";

			// currID
			$this->currID->LinkCustomAttributes = "";
			$this->currID->HrefValue = "";
			$this->currID->TooltipValue = "";

			// amount
			$this->amount->LinkCustomAttributes = "";
			$this->amount->HrefValue = "";
			$this->amount->TooltipValue = "";

			// transTime
			$this->transTime->LinkCustomAttributes = "";
			$this->transTime->HrefValue = "";
			$this->transTime->TooltipValue = "";

			// sourceUserID
			$this->sourceUserID->LinkCustomAttributes = "";
			$this->sourceUserID->HrefValue = "";
			$this->sourceUserID->TooltipValue = "";

			// destinationUserID
			$this->destinationUserID->LinkCustomAttributes = "";
			$this->destinationUserID->HrefValue = "";
			$this->destinationUserID->TooltipValue = "";

			// referenceTXID
			$this->referenceTXID->LinkCustomAttributes = "";
			$this->referenceTXID->HrefValue = "";
			$this->referenceTXID->TooltipValue = "";

			// msg
			$this->msg->LinkCustomAttributes = "";
			$this->msg->HrefValue = "";
			$this->msg->TooltipValue = "";
		} elseif ($this->RowType == ROWTYPE_ADD) { // Add row

			// transID
			// acctID

			$this->acctID->EditAttrs["class"] = "form-control";
			$this->acctID->EditCustomAttributes = "";
			$this->acctID->EditValue = HtmlEncode($this->acctID->CurrentValue);
			$this->acctID->PlaceHolder = RemoveHtml($this->acctID->caption());

			// transType
			$this->transType->EditAttrs["class"] = "form-control";
			$this->transType->EditCustomAttributes = "";
			$curVal = trim(strval($this->transType->CurrentValue));
			if ($curVal != "")
				$this->transType->ViewValue = $this->transType->lookupCacheOption($curVal);
			else
				$this->transType->ViewValue = $this->transType->Lookup !== NULL && is_array($this->transType->Lookup->Options) ? $curVal : NULL;
			if ($this->transType->ViewValue !== NULL) { // Load from cache
				$this->transType->EditValue = array_values($this->transType->Lookup->Options);
			} else { // Lookup from database
				if ($curVal == "") {
					$filterWrk = "0=1";
				} else {
					$filterWrk = "`typeID`" . SearchString("=", $this->transType->CurrentValue, DATATYPE_NUMBER, "_4payreference");
				}
				$lookupFilter = function() {
					return "`langID` = 'EN'";
				};
				$lookupFilter = $lookupFilter->bindTo($this);
				$sqlWrk = $this->transType->Lookup->getSql(TRUE, $filterWrk, $lookupFilter, $this);
				$rswrk = Conn("_4payreference")->execute($sqlWrk);
				$arwrk = $rswrk ? $rswrk->getRows() : [];
				if ($rswrk)
					$rswrk->close();
				$this->transType->EditValue = $arwrk;
			}

			// currID
			$this->currID->EditAttrs["class"] = "form-control";
			$this->currID->EditCustomAttributes = "";
			if (!$this->currID->Raw)
				$this->currID->CurrentValue = HtmlDecode($this->currID->CurrentValue);
			$this->currID->EditValue = HtmlEncode($this->currID->CurrentValue);
			$this->currID->PlaceHolder = RemoveHtml($this->currID->caption());

			// amount
			$this->amount->EditAttrs["class"] = "form-control";
			$this->amount->EditCustomAttributes = "";
			$this->amount->EditValue = HtmlEncode($this->amount->CurrentValue);
			$this->amount->PlaceHolder = RemoveHtml($this->amount->caption());
			if (strval($this->amount->EditValue) != "" && is_numeric($this->amount->EditValue)) {
				$this->amount->EditValue = FormatNumber($this->amount->EditValue, -2, -2, -2, -2);
				$this->amount->OldValue = $this->amount->EditValue;
			}
			

			// transTime
			$this->transTime->EditAttrs["class"] = "form-control";
			$this->transTime->EditCustomAttributes = "";
			$this->transTime->EditValue = HtmlEncode(FormatDateTime($this->transTime->CurrentValue, 8));
			$this->transTime->PlaceHolder = RemoveHtml($this->transTime->caption());

			// sourceUserID
			$this->sourceUserID->EditAttrs["class"] = "form-control";
			$this->sourceUserID->EditCustomAttributes = "";
			$this->sourceUserID->EditValue = HtmlEncode($this->sourceUserID->CurrentValue);
			$this->sourceUserID->PlaceHolder = RemoveHtml($this->sourceUserID->caption());

			// destinationUserID
			$this->destinationUserID->EditAttrs["class"] = "form-control";
			$this->destinationUserID->EditCustomAttributes = "";
			$this->destinationUserID->EditValue = HtmlEncode($this->destinationUserID->CurrentValue);
			$this->destinationUserID->PlaceHolder = RemoveHtml($this->destinationUserID->caption());

			// referenceTXID
			$this->referenceTXID->EditAttrs["class"] = "form-control";
			$this->referenceTXID->EditCustomAttributes = "";
			if (!$this->referenceTXID->Raw)
				$this->referenceTXID->CurrentValue = HtmlDecode($this->referenceTXID->CurrentValue);
			$this->referenceTXID->EditValue = HtmlEncode($this->referenceTXID->CurrentValue);
			$this->referenceTXID->PlaceHolder = RemoveHtml($this->referenceTXID->caption());

			// msg
			$this->msg->EditAttrs["class"] = "form-control";
			$this->msg->EditCustomAttributes = "";
			if (!$this->msg->Raw)
				$this->msg->CurrentValue = HtmlDecode($this->msg->CurrentValue);
			$this->msg->EditValue = HtmlEncode($this->msg->CurrentValue);
			$this->msg->PlaceHolder = RemoveHtml($this->msg->caption());

			// Add refer script
			// transID

			$this->transID->LinkCustomAttributes = "";
			if (!EmptyValue($this->transID->CurrentValue)) {
				$this->transID->HrefValue = "transhistorylist.php?showmaster=transgroup&fk_groupID=" . $this->transID->CurrentValue; // Add prefix/suffix
				$this->transID->LinkAttrs["target"] = ""; // Add target
				if ($this->isExport())
					$this->transID->HrefValue = FullUrl($this->transID->HrefValue, "href");
			} else {
				$this->transID->HrefValue = "";
			}

			// acctID
			$this->acctID->LinkCustomAttributes = "";
			if (!EmptyValue($this->acctID->CurrentValue)) {
				$this->acctID->HrefValue = "acctbalancelist.php?x_acctID=" . $this->acctID->CurrentValue . "&z_acctID=%3D&cmd=search"; // Add prefix/suffix
				$this->acctID->LinkAttrs["target"] = ""; // Add target
				if ($this->isExport())
					$this->acctID->HrefValue = FullUrl($this->acctID->HrefValue, "href");
			} else {
				$this->acctID->HrefValue = "";
			}

			// transType
			$this->transType->LinkCustomAttributes = "";
			$this->transType->HrefValue = "";

			// currID
			$this->currID->LinkCustomAttributes = "";
			$this->currID->HrefValue = "";

			// amount
			$this->amount->LinkCustomAttributes = "";
			$this->amount->HrefValue = "";

			// transTime
			$this->transTime->LinkCustomAttributes = "";
			$this->transTime->HrefValue = "";

			// sourceUserID
			$this->sourceUserID->LinkCustomAttributes = "";
			$this->sourceUserID->HrefValue = "";

			// destinationUserID
			$this->destinationUserID->LinkCustomAttributes = "";
			$this->destinationUserID->HrefValue = "";

			// referenceTXID
			$this->referenceTXID->LinkCustomAttributes = "";
			$this->referenceTXID->HrefValue = "";

			// msg
			$this->msg->LinkCustomAttributes = "";
			$this->msg->HrefValue = "";
		} elseif ($this->RowType == ROWTYPE_EDIT) { // Edit row

			// transID
			$this->transID->EditAttrs["class"] = "form-control";
			$this->transID->EditCustomAttributes = "";
			$this->transID->EditValue = $this->transID->CurrentValue;
			$this->transID->ViewCustomAttributes = "";

			// acctID
			$this->acctID->EditAttrs["class"] = "form-control";
			$this->acctID->EditCustomAttributes = "";
			$this->acctID->EditValue = HtmlEncode($this->acctID->CurrentValue);
			$this->acctID->PlaceHolder = RemoveHtml($this->acctID->caption());

			// transType
			$this->transType->EditAttrs["class"] = "form-control";
			$this->transType->EditCustomAttributes = "";
			$curVal = trim(strval($this->transType->CurrentValue));
			if ($curVal != "")
				$this->transType->ViewValue = $this->transType->lookupCacheOption($curVal);
			else
				$this->transType->ViewValue = $this->transType->Lookup !== NULL && is_array($this->transType->Lookup->Options) ? $curVal : NULL;
			if ($this->transType->ViewValue !== NULL) { // Load from cache
				$this->transType->EditValue = array_values($this->transType->Lookup->Options);
			} else { // Lookup from database
				if ($curVal == "") {
					$filterWrk = "0=1";
				} else {
					$filterWrk = "`typeID`" . SearchString("=", $this->transType->CurrentValue, DATATYPE_NUMBER, "_4payreference");
				}
				$lookupFilter = function() {
					return "`langID` = 'EN'";
				};
				$lookupFilter = $lookupFilter->bindTo($this);
				$sqlWrk = $this->transType->Lookup->getSql(TRUE, $filterWrk, $lookupFilter, $this);
				$rswrk = Conn("_4payreference")->execute($sqlWrk);
				$arwrk = $rswrk ? $rswrk->getRows() : [];
				if ($rswrk)
					$rswrk->close();
				$this->transType->EditValue = $arwrk;
			}

			// currID
			$this->currID->EditAttrs["class"] = "form-control";
			$this->currID->EditCustomAttributes = "";
			if (!$this->currID->Raw)
				$this->currID->CurrentValue = HtmlDecode($this->currID->CurrentValue);
			$this->currID->EditValue = HtmlEncode($this->currID->CurrentValue);
			$this->currID->PlaceHolder = RemoveHtml($this->currID->caption());

			// amount
			$this->amount->EditAttrs["class"] = "form-control";
			$this->amount->EditCustomAttributes = "";
			$this->amount->EditValue = HtmlEncode($this->amount->CurrentValue);
			$this->amount->PlaceHolder = RemoveHtml($this->amount->caption());
			if (strval($this->amount->EditValue) != "" && is_numeric($this->amount->EditValue)) {
				$this->amount->EditValue = FormatNumber($this->amount->EditValue, -2, -2, -2, -2);
				$this->amount->OldValue = $this->amount->EditValue;
			}
			

			// transTime
			$this->transTime->EditAttrs["class"] = "form-control";
			$this->transTime->EditCustomAttributes = "";
			$this->transTime->EditValue = HtmlEncode(FormatDateTime($this->transTime->CurrentValue, 8));
			$this->transTime->PlaceHolder = RemoveHtml($this->transTime->caption());

			// sourceUserID
			$this->sourceUserID->EditAttrs["class"] = "form-control";
			$this->sourceUserID->EditCustomAttributes = "";
			$this->sourceUserID->EditValue = HtmlEncode($this->sourceUserID->CurrentValue);
			$this->sourceUserID->PlaceHolder = RemoveHtml($this->sourceUserID->caption());

			// destinationUserID
			$this->destinationUserID->EditAttrs["class"] = "form-control";
			$this->destinationUserID->EditCustomAttributes = "";
			$this->destinationUserID->EditValue = HtmlEncode($this->destinationUserID->CurrentValue);
			$this->destinationUserID->PlaceHolder = RemoveHtml($this->destinationUserID->caption());

			// referenceTXID
			$this->referenceTXID->EditAttrs["class"] = "form-control";
			$this->referenceTXID->EditCustomAttributes = "";
			if (!$this->referenceTXID->Raw)
				$this->referenceTXID->CurrentValue = HtmlDecode($this->referenceTXID->CurrentValue);
			$this->referenceTXID->EditValue = HtmlEncode($this->referenceTXID->CurrentValue);
			$this->referenceTXID->PlaceHolder = RemoveHtml($this->referenceTXID->caption());

			// msg
			$this->msg->EditAttrs["class"] = "form-control";
			$this->msg->EditCustomAttributes = "";
			if (!$this->msg->Raw)
				$this->msg->CurrentValue = HtmlDecode($this->msg->CurrentValue);
			$this->msg->EditValue = HtmlEncode($this->msg->CurrentValue);
			$this->msg->PlaceHolder = RemoveHtml($this->msg->caption());

			// Edit refer script
			// transID

			$this->transID->LinkCustomAttributes = "";
			if (!EmptyValue($this->transID->CurrentValue)) {
				$this->transID->HrefValue = "transhistorylist.php?showmaster=transgroup&fk_groupID=" . $this->transID->CurrentValue; // Add prefix/suffix
				$this->transID->LinkAttrs["target"] = ""; // Add target
				if ($this->isExport())
					$this->transID->HrefValue = FullUrl($this->transID->HrefValue, "href");
			} else {
				$this->transID->HrefValue = "";
			}

			// acctID
			$this->acctID->LinkCustomAttributes = "";
			if (!EmptyValue($this->acctID->CurrentValue)) {
				$this->acctID->HrefValue = "acctbalancelist.php?x_acctID=" . $this->acctID->CurrentValue . "&z_acctID=%3D&cmd=search"; // Add prefix/suffix
				$this->acctID->LinkAttrs["target"] = ""; // Add target
				if ($this->isExport())
					$this->acctID->HrefValue = FullUrl($this->acctID->HrefValue, "href");
			} else {
				$this->acctID->HrefValue = "";
			}

			// transType
			$this->transType->LinkCustomAttributes = "";
			$this->transType->HrefValue = "";

			// currID
			$this->currID->LinkCustomAttributes = "";
			$this->currID->HrefValue = "";

			// amount
			$this->amount->LinkCustomAttributes = "";
			$this->amount->HrefValue = "";

			// transTime
			$this->transTime->LinkCustomAttributes = "";
			$this->transTime->HrefValue = "";

			// sourceUserID
			$this->sourceUserID->LinkCustomAttributes = "";
			$this->sourceUserID->HrefValue = "";

			// destinationUserID
			$this->destinationUserID->LinkCustomAttributes = "";
			$this->destinationUserID->HrefValue = "";

			// referenceTXID
			$this->referenceTXID->LinkCustomAttributes = "";
			$this->referenceTXID->HrefValue = "";

			// msg
			$this->msg->LinkCustomAttributes = "";
			$this->msg->HrefValue = "";
		}
		if ($this->RowType == ROWTYPE_ADD || $this->RowType == ROWTYPE_EDIT || $this->RowType == ROWTYPE_SEARCH) // Add/Edit/Search row
			$this->setupFieldTitles();

		// Call Row Rendered event
		if ($this->RowType != ROWTYPE_AGGREGATEINIT)
			$this->Row_Rendered();
	}

	// Validate form
	protected function validateForm()
	{
		global $Language, $FormError;

		// Check if validation required
		if (!Config("SERVER_VALIDATE"))
			return ($FormError == "");
		if ($this->transID->Required) {
			if (!$this->transID->IsDetailKey && $this->transID->FormValue != NULL && $this->transID->FormValue == "") {
				AddMessage($FormError, str_replace("%s", $this->transID->caption(), $this->transID->RequiredErrorMessage));
			}
		}
		if ($this->acctID->Required) {
			if (!$this->acctID->IsDetailKey && $this->acctID->FormValue != NULL && $this->acctID->FormValue == "") {
				AddMessage($FormError, str_replace("%s", $this->acctID->caption(), $this->acctID->RequiredErrorMessage));
			}
		}
		if (!CheckInteger($this->acctID->FormValue)) {
			AddMessage($FormError, $this->acctID->errorMessage());
		}
		if ($this->transType->Required) {
			if (!$this->transType->IsDetailKey && $this->transType->FormValue != NULL && $this->transType->FormValue == "") {
				AddMessage($FormError, str_replace("%s", $this->transType->caption(), $this->transType->RequiredErrorMessage));
			}
		}
		if ($this->currID->Required) {
			if (!$this->currID->IsDetailKey && $this->currID->FormValue != NULL && $this->currID->FormValue == "") {
				AddMessage($FormError, str_replace("%s", $this->currID->caption(), $this->currID->RequiredErrorMessage));
			}
		}
		if ($this->amount->Required) {
			if (!$this->amount->IsDetailKey && $this->amount->FormValue != NULL && $this->amount->FormValue == "") {
				AddMessage($FormError, str_replace("%s", $this->amount->caption(), $this->amount->RequiredErrorMessage));
			}
		}
		if (!CheckNumber($this->amount->FormValue)) {
			AddMessage($FormError, $this->amount->errorMessage());
		}
		if ($this->transTime->Required) {
			if (!$this->transTime->IsDetailKey && $this->transTime->FormValue != NULL && $this->transTime->FormValue == "") {
				AddMessage($FormError, str_replace("%s", $this->transTime->caption(), $this->transTime->RequiredErrorMessage));
			}
		}
		if (!CheckDate($this->transTime->FormValue)) {
			AddMessage($FormError, $this->transTime->errorMessage());
		}
		if ($this->sourceUserID->Required) {
			if (!$this->sourceUserID->IsDetailKey && $this->sourceUserID->FormValue != NULL && $this->sourceUserID->FormValue == "") {
				AddMessage($FormError, str_replace("%s", $this->sourceUserID->caption(), $this->sourceUserID->RequiredErrorMessage));
			}
		}
		if (!CheckInteger($this->sourceUserID->FormValue)) {
			AddMessage($FormError, $this->sourceUserID->errorMessage());
		}
		if ($this->destinationUserID->Required) {
			if (!$this->destinationUserID->IsDetailKey && $this->destinationUserID->FormValue != NULL && $this->destinationUserID->FormValue == "") {
				AddMessage($FormError, str_replace("%s", $this->destinationUserID->caption(), $this->destinationUserID->RequiredErrorMessage));
			}
		}
		if (!CheckInteger($this->destinationUserID->FormValue)) {
			AddMessage($FormError, $this->destinationUserID->errorMessage());
		}
		if ($this->referenceTXID->Required) {
			if (!$this->referenceTXID->IsDetailKey && $this->referenceTXID->FormValue != NULL && $this->referenceTXID->FormValue == "") {
				AddMessage($FormError, str_replace("%s", $this->referenceTXID->caption(), $this->referenceTXID->RequiredErrorMessage));
			}
		}
		if ($this->msg->Required) {
			if (!$this->msg->IsDetailKey && $this->msg->FormValue != NULL && $this->msg->FormValue == "") {
				AddMessage($FormError, str_replace("%s", $this->msg->caption(), $this->msg->RequiredErrorMessage));
			}
		}

		// Return validate result
		$validateForm = ($FormError == "");

		// Call Form_CustomValidate event
		$formCustomError = "";
		$validateForm = $validateForm && $this->Form_CustomValidate($formCustomError);
		if ($formCustomError != "") {
			AddMessage($FormError, $formCustomError);
		}
		return $validateForm;
	}

	// Delete records based on current filter
	protected function deleteRows()
	{
		global $Language, $Security;
		if (!$Security->canDelete()) {
			$this->setFailureMessage($Language->phrase("NoDeletePermission")); // No delete permission
			return FALSE;
		}
		$deleteRows = TRUE;
		$sql = $this->getCurrentSql();
		$conn = $this->getConnection();
		$conn->raiseErrorFn = Config("ERROR_FUNC");
		$rs = $conn->execute($sql);
		$conn->raiseErrorFn = "";
		if ($rs === FALSE) {
			return FALSE;
		} elseif ($rs->EOF) {
			$this->setFailureMessage($Language->phrase("NoRecord")); // No record found
			$rs->close();
			return FALSE;
		}
		$rows = ($rs) ? $rs->getRows() : [];

		// Clone old rows
		$rsold = $rows;
		if ($rs)
			$rs->close();

		// Call row deleting event
		if ($deleteRows) {
			foreach ($rsold as $row) {
				$deleteRows = $this->Row_Deleting($row);
				if (!$deleteRows)
					break;
			}
		}
		if ($deleteRows) {
			$key = "";
			foreach ($rsold as $row) {
				$thisKey = "";
				if ($thisKey != "")
					$thisKey .= Config("COMPOSITE_KEY_SEPARATOR");
				$thisKey .= $row['transID'];
				if ($thisKey != "")
					$thisKey .= Config("COMPOSITE_KEY_SEPARATOR");
				$thisKey .= $row['langID'];
				if ($thisKey != "")
					$thisKey .= Config("COMPOSITE_KEY_SEPARATOR");
				$thisKey .= $row['transLineID'];
				if (Config("DELETE_UPLOADED_FILES")) // Delete old files
					$this->deleteUploadedFiles($row);
				$conn->raiseErrorFn = Config("ERROR_FUNC");
				$deleteRows = $this->delete($row); // Delete
				$conn->raiseErrorFn = "";
				if ($deleteRows === FALSE)
					break;
				if ($key != "")
					$key .= ", ";
				$key .= $thisKey;
			}
		}
		if (!$deleteRows) {

			// Set up error message
			if ($this->getSuccessMessage() != "" || $this->getFailureMessage() != "") {

				// Use the message, do nothing
			} elseif ($this->CancelMessage != "") {
				$this->setFailureMessage($this->CancelMessage);
				$this->CancelMessage = "";
			} else {
				$this->setFailureMessage($Language->phrase("DeleteCancelled"));
			}
		}

		// Call Row Deleted event
		if ($deleteRows) {
			foreach ($rsold as $row) {
				$this->Row_Deleted($row);
			}
		}

		// Write JSON for API request (Support single row only)
		if (IsApi() && $deleteRows) {
			$row = $this->getRecordsFromRecordset($rsold, TRUE);
			WriteJson(["success" => TRUE, $this->TableVar => $row]);
		}
		return $deleteRows;
	}

	// Update record based on key values
	protected function editRow()
	{
		global $Security, $Language;
		$oldKeyFilter = $this->getRecordFilter();
		$filter = $this->applyUserIDFilters($oldKeyFilter);
		$conn = $this->getConnection();
		$this->CurrentFilter = $filter;
		$sql = $this->getCurrentSql();
		$conn->raiseErrorFn = Config("ERROR_FUNC");
		$rs = $conn->execute($sql);
		$conn->raiseErrorFn = "";
		if ($rs === FALSE)
			return FALSE;
		if ($rs->EOF) {
			$this->setFailureMessage($Language->phrase("NoRecord")); // Set no record message
			$editRow = FALSE; // Update Failed
		} else {

			// Save old values
			$rsold = &$rs->fields;
			$this->loadDbValues($rsold);
			$rsnew = [];

			// acctID
			$this->acctID->setDbValueDef($rsnew, $this->acctID->CurrentValue, 0, $this->acctID->ReadOnly);

			// transType
			$this->transType->setDbValueDef($rsnew, $this->transType->CurrentValue, 0, $this->transType->ReadOnly);

			// currID
			$this->currID->setDbValueDef($rsnew, $this->currID->CurrentValue, "", $this->currID->ReadOnly);

			// amount
			$this->amount->setDbValueDef($rsnew, $this->amount->CurrentValue, 0, $this->amount->ReadOnly);

			// transTime
			$this->transTime->setDbValueDef($rsnew, UnFormatDateTime($this->transTime->CurrentValue, 0), NULL, $this->transTime->ReadOnly);

			// sourceUserID
			$this->sourceUserID->setDbValueDef($rsnew, $this->sourceUserID->CurrentValue, 0, $this->sourceUserID->ReadOnly);

			// destinationUserID
			$this->destinationUserID->setDbValueDef($rsnew, $this->destinationUserID->CurrentValue, 0, $this->destinationUserID->ReadOnly);

			// referenceTXID
			$this->referenceTXID->setDbValueDef($rsnew, $this->referenceTXID->CurrentValue, "", $this->referenceTXID->ReadOnly);

			// msg
			$this->msg->setDbValueDef($rsnew, $this->msg->CurrentValue, NULL, $this->msg->ReadOnly);

			// Check referential integrity for master table 'paymentinstrument'
			$validMasterRecord = TRUE;
			$masterFilter = $this->sqlMasterFilter_paymentinstrument();
			$keyValue = isset($rsnew['piid']) ? $rsnew['piid'] : $rsold['piid'];
			if (strval($keyValue) != "") {
				$masterFilter = str_replace("@id@", AdjustSql($keyValue), $masterFilter);
			} else {
				$validMasterRecord = FALSE;
			}
			if ($validMasterRecord) {
				if (!isset($GLOBALS["paymentinstrument"]))
					$GLOBALS["paymentinstrument"] = new paymentinstrument();
				$rsmaster = $GLOBALS["paymentinstrument"]->loadRs($masterFilter);
				$validMasterRecord = ($rsmaster && !$rsmaster->EOF);
				$rsmaster->close();
			}
			if (!$validMasterRecord) {
				$relatedRecordMsg = str_replace("%t", "paymentinstrument", $Language->phrase("RelatedRecordRequired"));
				$this->setFailureMessage($relatedRecordMsg);
				$rs->close();
				return FALSE;
			}

			// Call Row Updating event
			$updateRow = $this->Row_Updating($rsold, $rsnew);

			// Check for duplicate key when key changed
			if ($updateRow) {
				$newKeyFilter = $this->getRecordFilter($rsnew);
				if ($newKeyFilter != $oldKeyFilter) {
					$rsChk = $this->loadRs($newKeyFilter);
					if ($rsChk && !$rsChk->EOF) {
						$keyErrMsg = str_replace("%f", $newKeyFilter, $Language->phrase("DupKey"));
						$this->setFailureMessage($keyErrMsg);
						$rsChk->close();
						$updateRow = FALSE;
					}
				}
			}
			if ($updateRow) {
				$conn->raiseErrorFn = Config("ERROR_FUNC");
				if (count($rsnew) > 0)
					$editRow = $this->update($rsnew, "", $rsold);
				else
					$editRow = TRUE; // No field to update
				$conn->raiseErrorFn = "";
				if ($editRow) {
				}
			} else {
				if ($this->getSuccessMessage() != "" || $this->getFailureMessage() != "") {

					// Use the message, do nothing
				} elseif ($this->CancelMessage != "") {
					$this->setFailureMessage($this->CancelMessage);
					$this->CancelMessage = "";
				} else {
					$this->setFailureMessage($Language->phrase("UpdateCancelled"));
				}
				$editRow = FALSE;
			}
		}

		// Call Row_Updated event
		if ($editRow)
			$this->Row_Updated($rsold, $rsnew);
		$rs->close();

		// Clean upload path if any
		if ($editRow) {
		}

		// Write JSON for API request
		if (IsApi() && $editRow) {
			$row = $this->getRecordsFromRecordset([$rsnew], TRUE);
			WriteJson(["success" => TRUE, $this->TableVar => $row]);
		}
		return $editRow;
	}

	// Add record
	protected function addRow($rsold = NULL)
	{
		global $Language, $Security;

		// Set up foreign key field value from Session
			if ($this->getCurrentMasterTable() == "paymentinstrument") {
				$this->piid->CurrentValue = $this->piid->getSessionValue();
			}

		// Check referential integrity for master table 'vtranshistorycardtypes'
		$validMasterRecord = TRUE;
		$masterFilter = $this->sqlMasterFilter_paymentinstrument();
		if ($this->piid->getSessionValue() != "") {
			$masterFilter = str_replace("@id@", AdjustSql($this->piid->getSessionValue(), "_4payreference"), $masterFilter);
		} else {
			$validMasterRecord = FALSE;
		}
		if ($validMasterRecord) {
			if (!isset($GLOBALS["paymentinstrument"]))
				$GLOBALS["paymentinstrument"] = new paymentinstrument();
			$rsmaster = $GLOBALS["paymentinstrument"]->loadRs($masterFilter);
			$validMasterRecord = ($rsmaster && !$rsmaster->EOF);
			$rsmaster->close();
		}
		if (!$validMasterRecord) {
			$relatedRecordMsg = str_replace("%t", "paymentinstrument", $Language->phrase("RelatedRecordRequired"));
			$this->setFailureMessage($relatedRecordMsg);
			return FALSE;
		}
		$conn = $this->getConnection();

		// Load db values from rsold
		$this->loadDbValues($rsold);
		if ($rsold) {
		}
		$rsnew = [];

		// acctID
		$this->acctID->setDbValueDef($rsnew, $this->acctID->CurrentValue, 0, FALSE);

		// transType
		$this->transType->setDbValueDef($rsnew, $this->transType->CurrentValue, 0, strval($this->transType->CurrentValue) == "");

		// currID
		$this->currID->setDbValueDef($rsnew, $this->currID->CurrentValue, "", FALSE);

		// amount
		$this->amount->setDbValueDef($rsnew, $this->amount->CurrentValue, 0, strval($this->amount->CurrentValue) == "");

		// transTime
		$this->transTime->setDbValueDef($rsnew, UnFormatDateTime($this->transTime->CurrentValue, 0), NULL, strval($this->transTime->CurrentValue) == "");

		// sourceUserID
		$this->sourceUserID->setDbValueDef($rsnew, $this->sourceUserID->CurrentValue, 0, FALSE);

		// destinationUserID
		$this->destinationUserID->setDbValueDef($rsnew, $this->destinationUserID->CurrentValue, 0, FALSE);

		// referenceTXID
		$this->referenceTXID->setDbValueDef($rsnew, $this->referenceTXID->CurrentValue, "", FALSE);

		// msg
		$this->msg->setDbValueDef($rsnew, $this->msg->CurrentValue, NULL, FALSE);

		// piid
		if ($this->piid->getSessionValue() != "") {
			$rsnew['piid'] = $this->piid->getSessionValue();
		}

		// Call Row Inserting event
		$rs = ($rsold) ? $rsold->fields : NULL;
		$insertRow = $this->Row_Inserting($rs, $rsnew);

		// Check if key value entered
		if ($insertRow && $this->ValidateKey && strval($rsnew['langID']) == "") {
			$this->setFailureMessage($Language->phrase("InvalidKeyValue"));
			$insertRow = FALSE;
		}
		if ($insertRow) {
			$conn->raiseErrorFn = Config("ERROR_FUNC");
			$addRow = $this->insert($rsnew);
			$conn->raiseErrorFn = "";
			if ($addRow) {
			}
		} else {
			if ($this->getSuccessMessage() != "" || $this->getFailureMessage() != "") {

				// Use the message, do nothing
			} elseif ($this->CancelMessage != "") {
				$this->setFailureMessage($this->CancelMessage);
				$this->CancelMessage = "";
			} else {
				$this->setFailureMessage($Language->phrase("InsertCancelled"));
			}
			$addRow = FALSE;
		}
		if ($addRow) {

			// Call Row Inserted event
			$rs = ($rsold) ? $rsold->fields : NULL;
			$this->Row_Inserted($rs, $rsnew);
		}

		// Clean upload path if any
		if ($addRow) {
		}

		// Write JSON for API request
		if (IsApi() && $addRow) {
			$row = $this->getRecordsFromRecordset([$rsnew], TRUE);
			WriteJson(["success" => TRUE, $this->TableVar => $row]);
		}
		return $addRow;
	}

	// Set up master/detail based on QueryString
	protected function setupMasterParms()
	{

		// Hide foreign keys
		$masterTblVar = $this->getCurrentMasterTable();
		if ($masterTblVar == "paymentinstrument") {
			$this->piid->Visible = FALSE;
			if ($GLOBALS["paymentinstrument"]->EventCancelled)
				$this->EventCancelled = TRUE;
		}
		$this->DbMasterFilter = $this->getMasterFilter(); // Get master filter
		$this->DbDetailFilter = $this->getDetailFilter(); // Get detail filter
	}

	// Setup lookup options
	public function setupLookupOptions($fld)
	{
		if ($fld->Lookup !== NULL && $fld->Lookup->Options === NULL) {

			// Get default connection and filter
			$conn = $this->getConnection();
			$lookupFilter = "";

			// No need to check any more
			$fld->Lookup->Options = [];

			// Set up lookup SQL and connection
			switch ($fld->FieldVar) {
				case "x_transType":
					$conn = Conn("_4payreference");
					$lookupFilter = function() {
						return "`langID` = 'EN'";
					};
					$lookupFilter = $lookupFilter->bindTo($this);
					break;
				default:
					$lookupFilter = "";
					break;
			}

			// Always call to Lookup->getSql so that user can setup Lookup->Options in Lookup_Selecting server event
			$sql = $fld->Lookup->getSql(FALSE, "", $lookupFilter, $this);

			// Set up lookup cache
			if ($fld->UseLookupCache && $sql != "" && count($fld->Lookup->Options) == 0) {
				$totalCnt = $this->getRecordCount($sql, $conn);
				if ($totalCnt > $fld->LookupCacheCount) // Total count > cache count, do not cache
					return;
				$rs = $conn->execute($sql);
				$ar = [];
				while ($rs && !$rs->EOF) {
					$row = &$rs->fields;

					// Format the field values
					switch ($fld->FieldVar) {
						case "x_transType":
							break;
					}
					$ar[strval($row[0])] = $row;
					$rs->moveNext();
				}
				if ($rs)
					$rs->close();
				$fld->Lookup->Options = $ar;
			}
		}
	}

	// Page Load event
	function Page_Load() {

		//echo "Page Load";
	}

	// Page Unload event
	function Page_Unload() {

		//echo "Page Unload";
	}

	// Page Redirecting event
	function Page_Redirecting(&$url) {

		// Example:
		//$url = "your URL";

	}

	// Message Showing event
	// $type = ''|'success'|'failure'|'warning'
	function Message_Showing(&$msg, $type) {
		if ($type == 'success') {

			//$msg = "your success message";
		} elseif ($type == 'failure') {

			//$msg = "your failure message";
		} elseif ($type == 'warning') {

			//$msg = "your warning message";
		} else {

			//$msg = "your message";
		}
	}

	// Page Render event
	function Page_Render() {

		//echo "Page Render";
	}

	// Page Data Rendering event
	function Page_DataRendering(&$header) {

		// Example:
		//$header = "your header";

	}

	// Page Data Rendered event
	function Page_DataRendered(&$footer) {

		// Example:
		//$footer = "your footer";

	}

	// Form Custom Validate event
	function Form_CustomValidate(&$customError) {

		// Return error message in CustomError
		return TRUE;
	}

	// ListOptions Load event
	function ListOptions_Load() {

		// Example:
		//$opt = &$this->ListOptions->Add("new");
		//$opt->Header = "xxx";
		//$opt->OnLeft = TRUE; // Link on left
		//$opt->MoveTo(0); // Move to first column

	}

	// ListOptions Rendering event
	function ListOptions_Rendering() {

		//$GLOBALS["xxx_grid"]->DetailAdd = (...condition...); // Set to TRUE or FALSE conditionally
		//$GLOBALS["xxx_grid"]->DetailEdit = (...condition...); // Set to TRUE or FALSE conditionally
		//$GLOBALS["xxx_grid"]->DetailView = (...condition...); // Set to TRUE or FALSE conditionally

	}

	// ListOptions Rendered event
	function ListOptions_Rendered() {

		// Example:
		//$this->ListOptions["new"]->Body = "xxx";

	}
} // End class
?>