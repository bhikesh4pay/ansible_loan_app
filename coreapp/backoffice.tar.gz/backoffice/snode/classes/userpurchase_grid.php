<?php
namespace PHPMaker2020\_4payadmin;

/**
 * Page class
 */
class userpurchase_grid extends userpurchase
{

	// Page ID
	public $PageID = "grid";

	// Project ID
	public $ProjectID = "{153C2D2E-60EE-4944-8753-3935EB38E8D6}";

	// Table name
	public $TableName = 'userpurchase';

	// Page object name
	public $PageObjName = "userpurchase_grid";

	// Grid form hidden field names
	public $FormName = "fuserpurchasegrid";
	public $FormActionName = "k_action";
	public $FormKeyName = "k_key";
	public $FormOldKeyName = "k_oldkey";
	public $FormBlankRowName = "k_blankrow";
	public $FormKeyCountName = "key_count";

	// Page URLs
	public $AddUrl;
	public $EditUrl;
	public $CopyUrl;
	public $DeleteUrl;
	public $ViewUrl;
	public $ListUrl;

	// Audit Trail
	public $AuditTrailOnAdd = TRUE;
	public $AuditTrailOnEdit = TRUE;
	public $AuditTrailOnDelete = TRUE;
	public $AuditTrailOnView = FALSE;
	public $AuditTrailOnViewData = FALSE;
	public $AuditTrailOnSearch = FALSE;

	// Page headings
	public $Heading = "";
	public $Subheading = "";
	public $PageHeader;
	public $PageFooter;

	// Token
	public $Token = "";
	public $TokenTimeout = 0;
	public $CheckToken;

	// Page heading
	public function pageHeading()
	{
		global $Language;
		if ($this->Heading != "")
			return $this->Heading;
		if (method_exists($this, "tableCaption"))
			return $this->tableCaption();
		return "";
	}

	// Page subheading
	public function pageSubheading()
	{
		global $Language;
		if ($this->Subheading != "")
			return $this->Subheading;
		if ($this->TableName)
			return $Language->phrase($this->PageID);
		return "";
	}

	// Page name
	public function pageName()
	{
		return CurrentPageName();
	}

	// Page URL
	public function pageUrl()
	{
		$url = CurrentPageName() . "?";
		if ($this->UseTokenInUrl)
			$url .= "t=" . $this->TableVar . "&"; // Add page token
		return $url;
	}

	// Messages
	private $_message = "";
	private $_failureMessage = "";
	private $_successMessage = "";
	private $_warningMessage = "";

	// Get message
	public function getMessage()
	{
		return isset($_SESSION[SESSION_MESSAGE]) ? $_SESSION[SESSION_MESSAGE] : $this->_message;
	}

	// Set message
	public function setMessage($v)
	{
		AddMessage($this->_message, $v);
		$_SESSION[SESSION_MESSAGE] = $this->_message;
	}

	// Get failure message
	public function getFailureMessage()
	{
		return isset($_SESSION[SESSION_FAILURE_MESSAGE]) ? $_SESSION[SESSION_FAILURE_MESSAGE] : $this->_failureMessage;
	}

	// Set failure message
	public function setFailureMessage($v)
	{
		AddMessage($this->_failureMessage, $v);
		$_SESSION[SESSION_FAILURE_MESSAGE] = $this->_failureMessage;
	}

	// Get success message
	public function getSuccessMessage()
	{
		return isset($_SESSION[SESSION_SUCCESS_MESSAGE]) ? $_SESSION[SESSION_SUCCESS_MESSAGE] : $this->_successMessage;
	}

	// Set success message
	public function setSuccessMessage($v)
	{
		AddMessage($this->_successMessage, $v);
		$_SESSION[SESSION_SUCCESS_MESSAGE] = $this->_successMessage;
	}

	// Get warning message
	public function getWarningMessage()
	{
		return isset($_SESSION[SESSION_WARNING_MESSAGE]) ? $_SESSION[SESSION_WARNING_MESSAGE] : $this->_warningMessage;
	}

	// Set warning message
	public function setWarningMessage($v)
	{
		AddMessage($this->_warningMessage, $v);
		$_SESSION[SESSION_WARNING_MESSAGE] = $this->_warningMessage;
	}

	// Clear message
	public function clearMessage()
	{
		$this->_message = "";
		$_SESSION[SESSION_MESSAGE] = "";
	}

	// Clear failure message
	public function clearFailureMessage()
	{
		$this->_failureMessage = "";
		$_SESSION[SESSION_FAILURE_MESSAGE] = "";
	}

	// Clear success message
	public function clearSuccessMessage()
	{
		$this->_successMessage = "";
		$_SESSION[SESSION_SUCCESS_MESSAGE] = "";
	}

	// Clear warning message
	public function clearWarningMessage()
	{
		$this->_warningMessage = "";
		$_SESSION[SESSION_WARNING_MESSAGE] = "";
	}

	// Clear messages
	public function clearMessages()
	{
		$this->clearMessage();
		$this->clearFailureMessage();
		$this->clearSuccessMessage();
		$this->clearWarningMessage();
	}

	// Show message
	public function showMessage()
	{
		$hidden = FALSE;
		$html = "";

		// Message
		$message = $this->getMessage();
		if (method_exists($this, "Message_Showing"))
			$this->Message_Showing($message, "");
		if ($message != "") { // Message in Session, display
			if (!$hidden)
				$message = '<button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button>' . $message;
			$html .= '<div class="alert alert-info alert-dismissible ew-info"><i class="icon fas fa-info"></i>' . $message . '</div>';
			$_SESSION[SESSION_MESSAGE] = ""; // Clear message in Session
		}

		// Warning message
		$warningMessage = $this->getWarningMessage();
		if (method_exists($this, "Message_Showing"))
			$this->Message_Showing($warningMessage, "warning");
		if ($warningMessage != "") { // Message in Session, display
			if (!$hidden)
				$warningMessage = '<button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button>' . $warningMessage;
			$html .= '<div class="alert alert-warning alert-dismissible ew-warning"><i class="icon fas fa-exclamation"></i>' . $warningMessage . '</div>';
			$_SESSION[SESSION_WARNING_MESSAGE] = ""; // Clear message in Session
		}

		// Success message
		$successMessage = $this->getSuccessMessage();
		if (method_exists($this, "Message_Showing"))
			$this->Message_Showing($successMessage, "success");
		if ($successMessage != "") { // Message in Session, display
			if (!$hidden)
				$successMessage = '<button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button>' . $successMessage;
			$html .= '<div class="alert alert-success alert-dismissible ew-success"><i class="icon fas fa-check"></i>' . $successMessage . '</div>';
			$_SESSION[SESSION_SUCCESS_MESSAGE] = ""; // Clear message in Session
		}

		// Failure message
		$errorMessage = $this->getFailureMessage();
		if (method_exists($this, "Message_Showing"))
			$this->Message_Showing($errorMessage, "failure");
		if ($errorMessage != "") { // Message in Session, display
			if (!$hidden)
				$errorMessage = '<button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button>' . $errorMessage;
			$html .= '<div class="alert alert-danger alert-dismissible ew-error"><i class="icon fas fa-ban"></i>' . $errorMessage . '</div>';
			$_SESSION[SESSION_FAILURE_MESSAGE] = ""; // Clear message in Session
		}
		echo '<div class="ew-message-dialog' . (($hidden) ? ' d-none' : "") . '">' . $html . '</div>';
	}

	// Get message as array
	public function getMessages()
	{
		$ar = [];

		// Message
		$message = $this->getMessage();

		//if (method_exists($this, "Message_Showing"))
		//	$this->Message_Showing($message, "");

		if ($message != "") { // Message in Session, display
			$ar["message"] = $message;
			$_SESSION[SESSION_MESSAGE] = ""; // Clear message in Session
		}

		// Warning message
		$warningMessage = $this->getWarningMessage();

		//if (method_exists($this, "Message_Showing"))
		//	$this->Message_Showing($warningMessage, "warning");

		if ($warningMessage != "") { // Message in Session, display
			$ar["warningMessage"] = $warningMessage;
			$_SESSION[SESSION_WARNING_MESSAGE] = ""; // Clear message in Session
		}

		// Success message
		$successMessage = $this->getSuccessMessage();

		//if (method_exists($this, "Message_Showing"))
		//	$this->Message_Showing($successMessage, "success");

		if ($successMessage != "") { // Message in Session, display
			$ar["successMessage"] = $successMessage;
			$_SESSION[SESSION_SUCCESS_MESSAGE] = ""; // Clear message in Session
		}

		// Failure message
		$failureMessage = $this->getFailureMessage();

		//if (method_exists($this, "Message_Showing"))
		//	$this->Message_Showing($failureMessage, "failure");

		if ($failureMessage != "") { // Message in Session, display
			$ar["failureMessage"] = $failureMessage;
			$_SESSION[SESSION_FAILURE_MESSAGE] = ""; // Clear message in Session
		}
		return $ar;
	}

	// Show Page Header
	public function showPageHeader()
	{
		$header = $this->PageHeader;
		$this->Page_DataRendering($header);
		if ($header != "") { // Header exists, display
			echo '<p id="ew-page-header">' . $header . '</p>';
		}
	}

	// Show Page Footer
	public function showPageFooter()
	{
		$footer = $this->PageFooter;
		$this->Page_DataRendered($footer);
		if ($footer != "") { // Footer exists, display
			echo '<p id="ew-page-footer">' . $footer . '</p>';
		}
	}

	// Validate page request
	protected function isPageRequest()
	{
		global $CurrentForm;
		if ($this->UseTokenInUrl) {
			if ($CurrentForm)
				return ($this->TableVar == $CurrentForm->getValue("t"));
			if (Get("t") !== NULL)
				return ($this->TableVar == Get("t"));
		}
		return TRUE;
	}

	// Valid Post
	protected function validPost()
	{
		if (!$this->CheckToken || !IsPost() || IsApi())
			return TRUE;
		if (Post(Config("TOKEN_NAME")) === NULL)
			return FALSE;
		$fn = Config("CHECK_TOKEN_FUNC");
		if (is_callable($fn))
			return $fn(Post(Config("TOKEN_NAME")), $this->TokenTimeout);
		return FALSE;
	}

	// Create Token
	public function createToken()
	{
		global $CurrentToken;
		$fn = Config("CREATE_TOKEN_FUNC"); // Always create token, required by API file/lookup request
		if ($this->Token == "" && is_callable($fn)) // Create token
			$this->Token = $fn();
		$CurrentToken = $this->Token; // Save to global variable
	}

	// Constructor
	public function __construct()
	{
		global $Language, $DashboardReport;
		global $UserTable;

		// Check token
		$this->CheckToken = Config("CHECK_TOKEN");

		// Initialize
		$this->FormActionName .= "_" . $this->FormName;
		$this->FormKeyName .= "_" . $this->FormName;
		$this->FormOldKeyName .= "_" . $this->FormName;
		$this->FormBlankRowName .= "_" . $this->FormName;
		$this->FormKeyCountName .= "_" . $this->FormName;
		$GLOBALS["Grid"] = &$this;
		$this->TokenTimeout = SessionTimeoutTime();

		// Language object
		if (!isset($Language))
			$Language = new Language();

		// Parent constuctor
		parent::__construct();

		// Table object (userpurchase)
		if (!isset($GLOBALS["userpurchase"]) || get_class($GLOBALS["userpurchase"]) == PROJECT_NAMESPACE . "userpurchase") {
			$GLOBALS["userpurchase"] = &$this;

			// $GLOBALS["MasterTable"] = &$GLOBALS["Table"];
			// if (!isset($GLOBALS["Table"]))
			// 	$GLOBALS["Table"] = &$GLOBALS["userpurchase"];

		}
		$this->AddUrl = "userpurchaseadd.php";

		// Table object (admin)
		if (!isset($GLOBALS['admin']))
			$GLOBALS['admin'] = new admin();

		// Page ID (for backward compatibility only)
		if (!defined(PROJECT_NAMESPACE . "PAGE_ID"))
			define(PROJECT_NAMESPACE . "PAGE_ID", 'grid');

		// Table name (for backward compatibility only)
		if (!defined(PROJECT_NAMESPACE . "TABLE_NAME"))
			define(PROJECT_NAMESPACE . "TABLE_NAME", 'userpurchase');

		// Start timer
		if (!isset($GLOBALS["DebugTimer"]))
			$GLOBALS["DebugTimer"] = new Timer();

		// Debug message
		LoadDebugMessage();

		// Open connection
		if (!isset($GLOBALS["Conn"]))
			$GLOBALS["Conn"] = $this->getConnection();

		// User table object (admin)
		$UserTable = $UserTable ?: new admin();

		// List options
		$this->ListOptions = new ListOptions();
		$this->ListOptions->TableVar = $this->TableVar;

		// Other options
		if (!$this->OtherOptions)
			$this->OtherOptions = new ListOptionsArray();
		$this->OtherOptions["addedit"] = new ListOptions("div");
		$this->OtherOptions["addedit"]->TagClassName = "ew-add-edit-option";
	}

	// Terminate page
	public function terminate($url = "")
	{
		global $ExportFileName, $TempImages, $DashboardReport;

		// Export
		global $userpurchase;
		if ($this->CustomExport && $this->CustomExport == $this->Export && array_key_exists($this->CustomExport, Config("EXPORT_CLASSES"))) {
				$content = ob_get_contents();
			if ($ExportFileName == "")
				$ExportFileName = $this->TableVar;
			$class = PROJECT_NAMESPACE . Config("EXPORT_CLASSES." . $this->CustomExport);
			if (class_exists($class)) {
				$doc = new $class($userpurchase);
				$doc->Text = @$content;
				if ($this->isExport("email"))
					echo $this->exportEmail($doc->Text);
				else
					$doc->export();
				DeleteTempImages(); // Delete temp images
				exit();
			}
		}

//		$GLOBALS["Table"] = &$GLOBALS["MasterTable"];
		unset($GLOBALS["Grid"]);
		if ($url === "")
			return;
		if (!IsApi())
			$this->Page_Redirecting($url);

		// Return for API
		if (IsApi()) {
			$res = $url === TRUE;
			if (!$res) // Show error
				WriteJson(array_merge(["success" => FALSE], $this->getMessages()));
			return;
		}

		// Go to URL if specified
		if ($url != "") {
			if (!Config("DEBUG") && ob_get_length())
				ob_end_clean();
			SaveDebugMessage();
			AddHeader("Location", $url);
		}
		exit();
	}

	// Get records from recordset
	protected function getRecordsFromRecordset($rs, $current = FALSE)
	{
		$rows = [];
		if (is_object($rs)) { // Recordset
			while ($rs && !$rs->EOF) {
				$this->loadRowValues($rs); // Set up DbValue/CurrentValue
				$row = $this->getRecordFromArray($rs->fields);
				if ($current)
					return $row;
				else
					$rows[] = $row;
				$rs->moveNext();
			}
		} elseif (is_array($rs)) {
			foreach ($rs as $ar) {
				$row = $this->getRecordFromArray($ar);
				if ($current)
					return $row;
				else
					$rows[] = $row;
			}
		}
		return $rows;
	}

	// Get record from array
	protected function getRecordFromArray($ar)
	{
		$row = [];
		if (is_array($ar)) {
			foreach ($ar as $fldname => $val) {
				if (array_key_exists($fldname, $this->fields) && ($this->fields[$fldname]->Visible || $this->fields[$fldname]->IsPrimaryKey)) { // Primary key or Visible
					$fld = &$this->fields[$fldname];
					if ($fld->HtmlTag == "FILE") { // Upload field
						if (EmptyValue($val)) {
							$row[$fldname] = NULL;
						} else {
							if ($fld->DataType == DATATYPE_BLOB) {
								$url = FullUrl(GetApiUrl(Config("API_FILE_ACTION"),
									Config("API_OBJECT_NAME") . "=" . $fld->TableVar . "&" .
									Config("API_FIELD_NAME") . "=" . $fld->Param . "&" .
									Config("API_KEY_NAME") . "=" . rawurlencode($this->getRecordKeyValue($ar)))); //*** need to add this? API may not be in the same folder
								$row[$fldname] = ["type" => ContentType($val), "url" => $url, "name" => $fld->Param . ContentExtension($val)];
							} elseif (!$fld->UploadMultiple || !ContainsString($val, Config("MULTIPLE_UPLOAD_SEPARATOR"))) { // Single file
								$url = FullUrl(GetApiUrl(Config("API_FILE_ACTION"),
									Config("API_OBJECT_NAME") . "=" . $fld->TableVar . "&" .
									"fn=" . Encrypt($fld->physicalUploadPath() . $val)));
								$row[$fldname] = ["type" => MimeContentType($val), "url" => $url, "name" => $val];
							} else { // Multiple files
								$files = explode(Config("MULTIPLE_UPLOAD_SEPARATOR"), $val);
								$ar = [];
								foreach ($files as $file) {
									$url = FullUrl(GetApiUrl(Config("API_FILE_ACTION"),
										Config("API_OBJECT_NAME") . "=" . $fld->TableVar . "&" .
										"fn=" . Encrypt($fld->physicalUploadPath() . $file)));
									if (!EmptyValue($file))
										$ar[] = ["type" => MimeContentType($file), "url" => $url, "name" => $file];
								}
								$row[$fldname] = $ar;
							}
						}
					} else {
						$row[$fldname] = $val;
					}
				}
			}
		}
		return $row;
	}

	// Get record key value from array
	protected function getRecordKeyValue($ar)
	{
		$key = "";
		if (is_array($ar)) {
			$key .= @$ar['purchaseid'];
		}
		return $key;
	}

	/**
	 * Hide fields for add/edit
	 *
	 * @return void
	 */
	protected function hideFieldsForAddEdit()
	{
		if ($this->isAdd() || $this->isCopy() || $this->isGridAdd())
			$this->purchaseid->Visible = FALSE;
	}

	// Lookup data
	public function lookup()
	{
		global $Language, $Security;
		if (!isset($Language))
			$Language = new Language(Config("LANGUAGE_FOLDER"), Post("language", ""));

		// Set up API request
		if (!ValidApiRequest())
			return FALSE;
		$this->setupApiSecurity();

		// Get lookup object
		$fieldName = Post("field");
		if (!array_key_exists($fieldName, $this->fields))
			return FALSE;
		$lookupField = $this->fields[$fieldName];
		$lookup = $lookupField->Lookup;
		if ($lookup === NULL)
			return FALSE;
		$tbl = $lookup->getTable();
		if (!$Security->allowLookup(Config("PROJECT_ID") . $tbl->TableName)) // Lookup permission
			return FALSE;

		// Get lookup parameters
		$lookupType = Post("ajax", "unknown");
		$pageSize = -1;
		$offset = -1;
		$searchValue = "";
		if (SameText($lookupType, "modal")) {
			$searchValue = Post("sv", "");
			$pageSize = Post("recperpage", 10);
			$offset = Post("start", 0);
		} elseif (SameText($lookupType, "autosuggest")) {
			$searchValue = Param("q", "");
			$pageSize = Param("n", -1);
			$pageSize = is_numeric($pageSize) ? (int)$pageSize : -1;
			if ($pageSize <= 0)
				$pageSize = Config("AUTO_SUGGEST_MAX_ENTRIES");
			$start = Param("start", -1);
			$start = is_numeric($start) ? (int)$start : -1;
			$page = Param("page", -1);
			$page = is_numeric($page) ? (int)$page : -1;
			$offset = $start >= 0 ? $start : ($page > 0 && $pageSize > 0 ? ($page - 1) * $pageSize : 0);
		}
		$userSelect = Decrypt(Post("s", ""));
		$userFilter = Decrypt(Post("f", ""));
		$userOrderBy = Decrypt(Post("o", ""));
		$keys = Post("keys");
		$lookup->LookupType = $lookupType; // Lookup type
		if ($keys !== NULL) { // Selected records from modal
			if (is_array($keys))
				$keys = implode(Config("MULTIPLE_OPTION_SEPARATOR"), $keys);
			$lookup->FilterFields = []; // Skip parent fields if any
			$lookup->FilterValues[] = $keys; // Lookup values
			$pageSize = -1; // Show all records
		} else { // Lookup values
			$lookup->FilterValues[] = Post("v0", Post("lookupValue", ""));
		}
		$cnt = is_array($lookup->FilterFields) ? count($lookup->FilterFields) : 0;
		for ($i = 1; $i <= $cnt; $i++)
			$lookup->FilterValues[] = Post("v" . $i, "");
		$lookup->SearchValue = $searchValue;
		$lookup->PageSize = $pageSize;
		$lookup->Offset = $offset;
		if ($userSelect != "")
			$lookup->UserSelect = $userSelect;
		if ($userFilter != "")
			$lookup->UserFilter = $userFilter;
		if ($userOrderBy != "")
			$lookup->UserOrderBy = $userOrderBy;
		$lookup->toJson($this); // Use settings from current page
	}

	// Set up API security
	public function setupApiSecurity()
	{
		global $Security;

		// Setup security for API request
		if ($Security->isLoggedIn()) $Security->TablePermission_Loading();
		$Security->loadCurrentUserLevel(Config("PROJECT_ID") . $this->TableName);
		if ($Security->isLoggedIn()) $Security->TablePermission_Loaded();
	}

	// Class variables
	public $ListOptions; // List options
	public $ExportOptions; // Export options
	public $SearchOptions; // Search options
	public $OtherOptions; // Other options
	public $FilterOptions; // Filter options
	public $ImportOptions; // Import options
	public $ListActions; // List actions
	public $SelectedCount = 0;
	public $SelectedIndex = 0;
	public $ShowOtherOptions = FALSE;
	public $DisplayRecords = 10;
	public $StartRecord;
	public $StopRecord;
	public $TotalRecords = 0;
	public $RecordRange = 10;
	public $PageSizes = ""; // Page sizes (comma separated)
	public $DefaultSearchWhere = ""; // Default search WHERE clause
	public $SearchWhere = ""; // Search WHERE clause
	public $SearchPanelClass = "ew-search-panel collapse"; // Search Panel class
	public $SearchRowCount = 0; // For extended search
	public $SearchColumnCount = 0; // For extended search
	public $SearchFieldsPerRow = 1; // For extended search
	public $RecordCount = 0; // Record count
	public $EditRowCount;
	public $StartRowCount = 1;
	public $RowCount = 0;
	public $Attrs = []; // Row attributes and cell attributes
	public $RowIndex = 0; // Row index
	public $KeyCount = 0; // Key count
	public $RowAction = ""; // Row action
	public $RowOldKey = ""; // Row old key (for copy)
	public $MultiColumnClass = "col-sm";
	public $MultiColumnEditClass = "w-100";
	public $DbMasterFilter = ""; // Master filter
	public $DbDetailFilter = ""; // Detail filter
	public $MasterRecordExists;
	public $MultiSelectKey;
	public $Command;
	public $RestoreSearch = FALSE;
	public $DetailPages;
	public $OldRecordset;

	//
	// Page run
	//

	public function run()
	{
		global $ExportType, $CustomExportType, $ExportFileName, $UserProfile, $Language, $Security, $CurrentForm,
			$FormError, $SearchError;

		// User profile
		$UserProfile = new UserProfile();

		// Security
		if (ValidApiRequest()) { // API request
			$this->setupApiSecurity(); // Set up API Security
		} else {
			$Security = new AdvancedSecurity();
			if (IsPasswordExpired())
				$this->terminate(GetUrl("changepwd.php"));
			if (!$Security->isLoggedIn())
				$Security->autoLogin();
			if ($Security->isLoggedIn())
				$Security->TablePermission_Loading();
			$Security->loadCurrentUserLevel($this->ProjectID . $this->TableName);
			if ($Security->isLoggedIn())
				$Security->TablePermission_Loaded();
			if (!$Security->canList()) {
				$Security->saveLastUrl();
				$this->setFailureMessage(DeniedMessage()); // Set no permission
				$this->terminate(GetUrl("index.php"));
				return;
			}
		}

		// Get grid add count
		$gridaddcnt = Get(Config("TABLE_GRID_ADD_ROW_COUNT"), "");
		if (is_numeric($gridaddcnt) && $gridaddcnt > 0)
			$this->GridAddRowCount = $gridaddcnt;

		// Set up list options
		$this->setupListOptions();
		$this->purchaseid->setVisibility();
		$this->_userid->setVisibility();
		$this->merchantnodeid->Visible = FALSE;
		$this->merchantid->setVisibility();
		$this->merchantbusinessname->Visible = FALSE;
		$this->merchanttransferid->setVisibility();
		$this->merchantuserid->Visible = FALSE;
		$this->purchasedate->setVisibility();
		$this->txid->setVisibility();
		$this->userpi->setVisibility();
		$this->otherconfirmref->Visible = FALSE;
		$this->currencycode->setVisibility();
		$this->purchaseamount->setVisibility();
		$this->tipamount->Visible = FALSE;
		$this->merchantfees->Visible = FALSE;
		$this->consumerfees->Visible = FALSE;
		$this->transferid->Visible = FALSE;
		$this->merchantSurcharge->Visible = FALSE;
		$this->taxAmount->Visible = FALSE;
		$this->totalAmounForCustomer->Visible = FALSE;
		$this->feeid->Visible = FALSE;
		$this->ratetabletype->Visible = FALSE;
		$this->itemdesc->Visible = FALSE;
		$this->shoppingCartID->Visible = FALSE;
		$this->merchantRefID->Visible = FALSE;
		$this->refunded->Visible = FALSE;
		$this->tokenid->Visible = FALSE;
		$this->cardno->Visible = FALSE;
		$this->vaultid->Visible = FALSE;
		$this->refundrequested->Visible = FALSE;
		$this->refundrequesttxid->Visible = FALSE;
		$this->feesystemshare->Visible = FALSE;
		$this->feeexternalshare->Visible = FALSE;
		$this->feefranchiseeshare->Visible = FALSE;
		$this->feeresellershare->Visible = FALSE;
		$this->_key->Visible = FALSE;
		$this->serviceFeeToCustomerbk1amt->Visible = FALSE;
		$this->serviceFeeToCustomerbk1type->Visible = FALSE;
		$this->serviceFeeToCustomerbk2amt->Visible = FALSE;
		$this->serviceFeeToCustomerbk2type->Visible = FALSE;
		$this->serviceFeeToCustomerbk3amt->Visible = FALSE;
		$this->serviceFeeToCustomerbk3type->Visible = FALSE;
		$this->taxAmountbk1amt->Visible = FALSE;
		$this->taxAmountbk1type->Visible = FALSE;
		$this->taxAmountbk2amt->Visible = FALSE;
		$this->taxAmountbk2type->Visible = FALSE;
		$this->taxAmountbk3amt->Visible = FALSE;
		$this->taxAmountbk3type->Visible = FALSE;
		$this->originalpurchaseamount->Visible = FALSE;
		$this->discountamount->Visible = FALSE;
		$this->discountpercentage->Visible = FALSE;
		$this->txgroupid->Visible = FALSE;
		$this->success_status->setVisibility();
		$this->error_msg->Visible = FALSE;
		$this->userpiid->setVisibility();
		$this->notes->Visible = FALSE;
		$this->lastpurchasereaddate->Visible = FALSE;
		$this->retryapicount->Visible = FALSE;
		$this->hideFieldsForAddEdit();

		// Global Page Loading event (in userfn*.php)
		Page_Loading();

		// Page Load event
		$this->Page_Load();

		// Check token
		if (!$this->validPost()) {
			Write($Language->phrase("InvalidPostRequest"));
			$this->terminate();
		}

		// Create Token
		$this->createToken();

		// Set up master detail parameters
		$this->setupMasterParms();

		// Setup other options
		$this->setupOtherOptions();

		// Set up lookup cache
		$this->setupLookupOptions($this->userpi);

		// Search filters
		$srchAdvanced = ""; // Advanced search filter
		$srchBasic = ""; // Basic search filter
		$filter = "";

		// Get command
		$this->Command = strtolower(Get("cmd"));
		if ($this->isPageRequest()) { // Validate request

			// Set up records per page
			$this->setupDisplayRecords();

			// Handle reset command
			$this->resetCmd();

			// Hide list options
			if ($this->isExport()) {
				$this->ListOptions->hideAllOptions(["sequence"]);
				$this->ListOptions->UseDropDownButton = FALSE; // Disable drop down button
				$this->ListOptions->UseButtonGroup = FALSE; // Disable button group
			} elseif ($this->isGridAdd() || $this->isGridEdit()) {
				$this->ListOptions->hideAllOptions();
				$this->ListOptions->UseDropDownButton = FALSE; // Disable drop down button
				$this->ListOptions->UseButtonGroup = FALSE; // Disable button group
			}

			// Show grid delete link for grid add / grid edit
			if ($this->AllowAddDeleteRow) {
				if ($this->isGridAdd() || $this->isGridEdit()) {
					$item = $this->ListOptions["griddelete"];
					if ($item)
						$item->Visible = TRUE;
				}
			}

			// Set up sorting order
			$this->setupSortOrder();
		}

		// Restore display records
		if ($this->Command != "json" && $this->getRecordsPerPage() != "") {
			$this->DisplayRecords = $this->getRecordsPerPage(); // Restore from Session
		} else {
			$this->DisplayRecords = 10; // Load default
			$this->setRecordsPerPage($this->DisplayRecords); // Save default to Session
		}

		// Load Sorting Order
		if ($this->Command != "json")
			$this->loadSortOrder();

		// Build filter
		$filter = "";
		if (!$Security->canList())
			$filter = "(0=1)"; // Filter all records

		// Restore master/detail filter
		$this->DbMasterFilter = $this->getMasterFilter(); // Restore master filter
		$this->DbDetailFilter = $this->getDetailFilter(); // Restore detail filter
		AddFilter($filter, $this->DbDetailFilter);
		AddFilter($filter, $this->SearchWhere);

		// Load master record
		if ($this->CurrentMode != "add" && $this->getMasterFilter() != "" && $this->getCurrentMasterTable() == "user") {
			global $user;
			$rsmaster = $user->loadRs($this->DbMasterFilter);
			$this->MasterRecordExists = ($rsmaster && !$rsmaster->EOF);
			if (!$this->MasterRecordExists) {
				$this->setFailureMessage($Language->phrase("NoRecord")); // Set no record found
				$this->terminate("userlist.php"); // Return to master page
			} else {
				$user->loadListRowValues($rsmaster);
				$user->RowType = ROWTYPE_MASTER; // Master row
				$user->renderListRow();
				$rsmaster->close();
			}
		}

		// Set up filter
		if ($this->Command == "json") {
			$this->UseSessionForListSql = FALSE; // Do not use session for ListSQL
			$this->CurrentFilter = $filter;
		} else {
			$this->setSessionWhere($filter);
			$this->CurrentFilter = "";
		}
		if ($this->isGridAdd()) {
			if ($this->CurrentMode == "copy") {
				$selectLimit = $this->UseSelectLimit;
				if ($selectLimit) {
					$this->TotalRecords = $this->listRecordCount();
					$this->Recordset = $this->loadRecordset($this->StartRecord - 1, $this->DisplayRecords);
				} else {
					if ($this->Recordset = $this->loadRecordset())
						$this->TotalRecords = $this->Recordset->RecordCount();
				}
				$this->StartRecord = 1;
				$this->DisplayRecords = $this->TotalRecords;
			} else {
				$this->CurrentFilter = "0=1";
				$this->StartRecord = 1;
				$this->DisplayRecords = $this->GridAddRowCount;
			}
			$this->TotalRecords = $this->DisplayRecords;
			$this->StopRecord = $this->DisplayRecords;
		} else {
			$selectLimit = $this->UseSelectLimit;
			if ($selectLimit) {
				$this->TotalRecords = $this->listRecordCount();
			} else {
				if ($this->Recordset = $this->loadRecordset())
					$this->TotalRecords = $this->Recordset->RecordCount();
			}
			$this->StartRecord = 1;
			$this->DisplayRecords = $this->TotalRecords; // Display all records
			if ($selectLimit)
				$this->Recordset = $this->loadRecordset($this->StartRecord - 1, $this->DisplayRecords);
		}

		// Normal return
		if (IsApi()) {
			$rows = $this->getRecordsFromRecordset($this->Recordset);
			$this->Recordset->close();
			WriteJson(["success" => TRUE, $this->TableVar => $rows, "totalRecordCount" => $this->TotalRecords]);
			$this->terminate(TRUE);
		}

		// Set up pager
		$this->Pager = new PrevNextPager($this->StartRecord, $this->getRecordsPerPage(), $this->TotalRecords, $this->PageSizes, $this->RecordRange, $this->AutoHidePager, $this->AutoHidePageSizeSelector);
	}

	// Set up number of records displayed per page
	protected function setupDisplayRecords()
	{
		$wrk = Get(Config("TABLE_REC_PER_PAGE"), "");
		if ($wrk != "") {
			if (is_numeric($wrk)) {
				$this->DisplayRecords = (int)$wrk;
			} else {
				if (SameText($wrk, "all")) { // Display all records
					$this->DisplayRecords = -1;
				} else {
					$this->DisplayRecords = 10; // Non-numeric, load default
				}
			}
			$this->setRecordsPerPage($this->DisplayRecords); // Save to Session

			// Reset start position
			$this->StartRecord = 1;
			$this->setStartRecordNumber($this->StartRecord);
		}
	}

	// Exit inline mode
	protected function clearInlineMode()
	{
		$this->purchaseamount->FormValue = ""; // Clear form value
		$this->LastAction = $this->CurrentAction; // Save last action
		$this->CurrentAction = ""; // Clear action
		$_SESSION[SESSION_INLINE_MODE] = ""; // Clear inline mode
	}

	// Switch to Grid Add mode
	protected function gridAddMode()
	{
		$this->CurrentAction = "gridadd";
		$_SESSION[SESSION_INLINE_MODE] = "gridadd";
		$this->hideFieldsForAddEdit();
	}

	// Switch to Grid Edit mode
	protected function gridEditMode()
	{
		$this->CurrentAction = "gridedit";
		$_SESSION[SESSION_INLINE_MODE] = "gridedit";
		$this->hideFieldsForAddEdit();
	}

	// Perform update to grid
	public function gridUpdate()
	{
		global $Language, $CurrentForm, $FormError;
		$gridUpdate = TRUE;

		// Get old recordset
		$this->CurrentFilter = $this->buildKeyFilter();
		if ($this->CurrentFilter == "")
			$this->CurrentFilter = "0=1";
		$sql = $this->getCurrentSql();
		$conn = $this->getConnection();
		if ($rs = $conn->execute($sql)) {
			$rsold = $rs->getRows();
			$rs->close();
		}

		// Call Grid Updating event
		if (!$this->Grid_Updating($rsold)) {
			if ($this->getFailureMessage() == "")
				$this->setFailureMessage($Language->phrase("GridEditCancelled")); // Set grid edit cancelled message
			return FALSE;
		}
		if ($this->AuditTrailOnEdit)
			$this->writeAuditTrailDummy($Language->phrase("BatchUpdateBegin")); // Batch update begin
		$key = "";

		// Update row index and get row key
		$CurrentForm->Index = -1;
		$rowcnt = strval($CurrentForm->getValue($this->FormKeyCountName));
		if ($rowcnt == "" || !is_numeric($rowcnt))
			$rowcnt = 0;

		// Update all rows based on key
		for ($rowindex = 1; $rowindex <= $rowcnt; $rowindex++) {
			$CurrentForm->Index = $rowindex;
			$rowkey = strval($CurrentForm->getValue($this->FormKeyName));
			$rowaction = strval($CurrentForm->getValue($this->FormActionName));

			// Load all values and keys
			if ($rowaction != "insertdelete") { // Skip insert then deleted rows
				$this->loadFormValues(); // Get form values
				if ($rowaction == "" || $rowaction == "edit" || $rowaction == "delete") {
					$gridUpdate = $this->setupKeyValues($rowkey); // Set up key values
				} else {
					$gridUpdate = TRUE;
				}

				// Skip empty row
				if ($rowaction == "insert" && $this->emptyRow()) {

					// No action required
				// Validate form and insert/update/delete record

				} elseif ($gridUpdate) {
					if ($rowaction == "delete") {
						$this->CurrentFilter = $this->getRecordFilter();
						$gridUpdate = $this->deleteRows(); // Delete this row
					} else if (!$this->validateForm()) {
						$gridUpdate = FALSE; // Form error, reset action
						$this->setFailureMessage($FormError);
					} else {
						if ($rowaction == "insert") {
							$gridUpdate = $this->addRow(); // Insert this row
						} else {
							if ($rowkey != "") {
								$this->SendEmail = FALSE; // Do not send email on update success
								$gridUpdate = $this->editRow(); // Update this row
							}
						} // End update
					}
				}
				if ($gridUpdate) {
					if ($key != "")
						$key .= ", ";
					$key .= $rowkey;
				} else {
					break;
				}
			}
		}
		if ($gridUpdate) {

			// Get new recordset
			if ($rs = $conn->execute($sql)) {
				$rsnew = $rs->getRows();
				$rs->close();
			}

			// Call Grid_Updated event
			$this->Grid_Updated($rsold, $rsnew);
			if ($this->AuditTrailOnEdit)
				$this->writeAuditTrailDummy($Language->phrase("BatchUpdateSuccess")); // Batch update success
			$this->clearInlineMode(); // Clear inline edit mode
		} else {
			if ($this->AuditTrailOnEdit)
				$this->writeAuditTrailDummy($Language->phrase("BatchUpdateRollback")); // Batch update rollback
			if ($this->getFailureMessage() == "")
				$this->setFailureMessage($Language->phrase("UpdateFailed")); // Set update failed message
		}
		return $gridUpdate;
	}

	// Build filter for all keys
	protected function buildKeyFilter()
	{
		global $CurrentForm;
		$wrkFilter = "";

		// Update row index and get row key
		$rowindex = 1;
		$CurrentForm->Index = $rowindex;
		$thisKey = strval($CurrentForm->getValue($this->FormKeyName));
		while ($thisKey != "") {
			if ($this->setupKeyValues($thisKey)) {
				$filter = $this->getRecordFilter();
				if ($wrkFilter != "")
					$wrkFilter .= " OR ";
				$wrkFilter .= $filter;
			} else {
				$wrkFilter = "0=1";
				break;
			}

			// Update row index and get row key
			$rowindex++; // Next row
			$CurrentForm->Index = $rowindex;
			$thisKey = strval($CurrentForm->getValue($this->FormKeyName));
		}
		return $wrkFilter;
	}

	// Set up key values
	protected function setupKeyValues($key)
	{
		$arKeyFlds = explode(Config("COMPOSITE_KEY_SEPARATOR"), $key);
		if (count($arKeyFlds) >= 1) {
			$this->purchaseid->setOldValue($arKeyFlds[0]);
			if (!is_numeric($this->purchaseid->OldValue))
				return FALSE;
		}
		return TRUE;
	}

	// Perform Grid Add
	public function gridInsert()
	{
		global $Language, $CurrentForm, $FormError;
		$rowindex = 1;
		$gridInsert = FALSE;
		$conn = $this->getConnection();

		// Call Grid Inserting event
		if (!$this->Grid_Inserting()) {
			if ($this->getFailureMessage() == "")
				$this->setFailureMessage($Language->phrase("GridAddCancelled")); // Set grid add cancelled message
			return FALSE;
		}

		// Init key filter
		$wrkfilter = "";
		$addcnt = 0;
		if ($this->AuditTrailOnAdd)
			$this->writeAuditTrailDummy($Language->phrase("BatchInsertBegin")); // Batch insert begin
		$key = "";

		// Get row count
		$CurrentForm->Index = -1;
		$rowcnt = strval($CurrentForm->getValue($this->FormKeyCountName));
		if ($rowcnt == "" || !is_numeric($rowcnt))
			$rowcnt = 0;

		// Insert all rows
		for ($rowindex = 1; $rowindex <= $rowcnt; $rowindex++) {

			// Load current row values
			$CurrentForm->Index = $rowindex;
			$rowaction = strval($CurrentForm->getValue($this->FormActionName));
			if ($rowaction != "" && $rowaction != "insert")
				continue; // Skip
			if ($rowaction == "insert") {
				$this->RowOldKey = strval($CurrentForm->getValue($this->FormOldKeyName));
				$this->loadOldRecord(); // Load old record
			}
			$this->loadFormValues(); // Get form values
			if (!$this->emptyRow()) {
				$addcnt++;
				$this->SendEmail = FALSE; // Do not send email on insert success

				// Validate form
				if (!$this->validateForm()) {
					$gridInsert = FALSE; // Form error, reset action
					$this->setFailureMessage($FormError);
				} else {
					$gridInsert = $this->addRow($this->OldRecordset); // Insert this row
				}
				if ($gridInsert) {
					if ($key != "")
						$key .= Config("COMPOSITE_KEY_SEPARATOR");
					$key .= $this->purchaseid->CurrentValue;

					// Add filter for this record
					$filter = $this->getRecordFilter();
					if ($wrkfilter != "")
						$wrkfilter .= " OR ";
					$wrkfilter .= $filter;
				} else {
					break;
				}
			}
		}
		if ($addcnt == 0) { // No record inserted
			$this->clearInlineMode(); // Clear grid add mode and return
			return TRUE;
		}
		if ($gridInsert) {

			// Get new recordset
			$this->CurrentFilter = $wrkfilter;
			$sql = $this->getCurrentSql();
			if ($rs = $conn->execute($sql)) {
				$rsnew = $rs->getRows();
				$rs->close();
			}

			// Call Grid_Inserted event
			$this->Grid_Inserted($rsnew);
			if ($this->AuditTrailOnAdd)
				$this->writeAuditTrailDummy($Language->phrase("BatchInsertSuccess")); // Batch insert success
			$this->clearInlineMode(); // Clear grid add mode
		} else {
			if ($this->AuditTrailOnAdd)
				$this->writeAuditTrailDummy($Language->phrase("BatchInsertRollback")); // Batch insert rollback
			if ($this->getFailureMessage() == "")
				$this->setFailureMessage($Language->phrase("InsertFailed")); // Set insert failed message
		}
		return $gridInsert;
	}

	// Check if empty row
	public function emptyRow()
	{
		global $CurrentForm;
		if ($CurrentForm->hasValue("x__userid") && $CurrentForm->hasValue("o__userid") && $this->_userid->CurrentValue != $this->_userid->OldValue)
			return FALSE;
		if ($CurrentForm->hasValue("x_merchantid") && $CurrentForm->hasValue("o_merchantid") && $this->merchantid->CurrentValue != $this->merchantid->OldValue)
			return FALSE;
		if ($CurrentForm->hasValue("x_merchanttransferid") && $CurrentForm->hasValue("o_merchanttransferid") && $this->merchanttransferid->CurrentValue != $this->merchanttransferid->OldValue)
			return FALSE;
		if ($CurrentForm->hasValue("x_purchasedate") && $CurrentForm->hasValue("o_purchasedate") && $this->purchasedate->CurrentValue != $this->purchasedate->OldValue)
			return FALSE;
		if ($CurrentForm->hasValue("x_txid") && $CurrentForm->hasValue("o_txid") && $this->txid->CurrentValue != $this->txid->OldValue)
			return FALSE;
		if ($CurrentForm->hasValue("x_userpi") && $CurrentForm->hasValue("o_userpi") && $this->userpi->CurrentValue != $this->userpi->OldValue)
			return FALSE;
		if ($CurrentForm->hasValue("x_currencycode") && $CurrentForm->hasValue("o_currencycode") && $this->currencycode->CurrentValue != $this->currencycode->OldValue)
			return FALSE;
		if ($CurrentForm->hasValue("x_purchaseamount") && $CurrentForm->hasValue("o_purchaseamount") && $this->purchaseamount->CurrentValue != $this->purchaseamount->OldValue)
			return FALSE;
		if ($CurrentForm->hasValue("x_success_status") && $CurrentForm->hasValue("o_success_status") && $this->success_status->CurrentValue != $this->success_status->OldValue)
			return FALSE;
		if ($CurrentForm->hasValue("x_userpiid") && $CurrentForm->hasValue("o_userpiid") && $this->userpiid->CurrentValue != $this->userpiid->OldValue)
			return FALSE;
		return TRUE;
	}

	// Validate grid form
	public function validateGridForm()
	{
		global $CurrentForm;

		// Get row count
		$CurrentForm->Index = -1;
		$rowcnt = strval($CurrentForm->getValue($this->FormKeyCountName));
		if ($rowcnt == "" || !is_numeric($rowcnt))
			$rowcnt = 0;

		// Validate all records
		for ($rowindex = 1; $rowindex <= $rowcnt; $rowindex++) {

			// Load current row values
			$CurrentForm->Index = $rowindex;
			$rowaction = strval($CurrentForm->getValue($this->FormActionName));
			if ($rowaction != "delete" && $rowaction != "insertdelete") {
				$this->loadFormValues(); // Get form values
				if ($rowaction == "insert" && $this->emptyRow()) {

					// Ignore
				} else if (!$this->validateForm()) {
					return FALSE;
				}
			}
		}
		return TRUE;
	}

	// Get all form values of the grid
	public function getGridFormValues()
	{
		global $CurrentForm;

		// Get row count
		$CurrentForm->Index = -1;
		$rowcnt = strval($CurrentForm->getValue($this->FormKeyCountName));
		if ($rowcnt == "" || !is_numeric($rowcnt))
			$rowcnt = 0;
		$rows = [];

		// Loop through all records
		for ($rowindex = 1; $rowindex <= $rowcnt; $rowindex++) {

			// Load current row values
			$CurrentForm->Index = $rowindex;
			$rowaction = strval($CurrentForm->getValue($this->FormActionName));
			if ($rowaction != "delete" && $rowaction != "insertdelete") {
				$this->loadFormValues(); // Get form values
				if ($rowaction == "insert" && $this->emptyRow()) {

					// Ignore
				} else {
					$rows[] = $this->getFieldValues("FormValue"); // Return row as array
				}
			}
		}
		return $rows; // Return as array of array
	}

	// Restore form values for current row
	public function restoreCurrentRowFormValues($idx)
	{
		global $CurrentForm;

		// Get row based on current index
		$CurrentForm->Index = $idx;
		$this->loadFormValues(); // Load form values
	}

	// Set up sort parameters
	protected function setupSortOrder()
	{

		// Check for "order" parameter
		if (Get("order") !== NULL) {
			$this->CurrentOrder = Get("order");
			$this->CurrentOrderType = Get("ordertype", "");
			$this->setStartRecordNumber(1); // Reset start position
		}
	}

	// Load sort order parameters
	protected function loadSortOrder()
	{
		$orderBy = $this->getSessionOrderBy(); // Get ORDER BY from Session
		if ($orderBy == "") {
			if ($this->getSqlOrderBy() != "") {
				$orderBy = $this->getSqlOrderBy();
				$this->setSessionOrderBy($orderBy);
			}
		}
	}

	// Reset command
	// - cmd=reset (Reset search parameters)
	// - cmd=resetall (Reset search and master/detail parameters)
	// - cmd=resetsort (Reset sort parameters)

	protected function resetCmd()
	{

		// Check if reset command
		if (StartsString("reset", $this->Command)) {

			// Reset master/detail keys
			if ($this->Command == "resetall") {
				$this->setCurrentMasterTable(""); // Clear master table
				$this->DbMasterFilter = "";
				$this->DbDetailFilter = "";
				$this->_userid->setSessionValue("");
			}

			// Reset sorting order
			if ($this->Command == "resetsort") {
				$orderBy = "";
				$this->setSessionOrderBy($orderBy);
			}

			// Reset start position
			$this->StartRecord = 1;
			$this->setStartRecordNumber($this->StartRecord);
		}
	}

	// Set up list options
	protected function setupListOptions()
	{
		global $Security, $Language;

		// "griddelete"
		if ($this->AllowAddDeleteRow) {
			$item = &$this->ListOptions->add("griddelete");
			$item->CssClass = "text-nowrap";
			$item->OnLeft = FALSE;
			$item->Visible = FALSE; // Default hidden
		}

		// Add group option item
		$item = &$this->ListOptions->add($this->ListOptions->GroupOptionName);
		$item->Body = "";
		$item->OnLeft = FALSE;
		$item->Visible = FALSE;

		// "view"
		$item = &$this->ListOptions->add("view");
		$item->CssClass = "text-nowrap";
		$item->Visible = $Security->canView();
		$item->OnLeft = FALSE;

		// "edit"
		$item = &$this->ListOptions->add("edit");
		$item->CssClass = "text-nowrap";
		$item->Visible = $Security->canEdit();
		$item->OnLeft = FALSE;

		// "copy"
		$item = &$this->ListOptions->add("copy");
		$item->CssClass = "text-nowrap";
		$item->Visible = $Security->canAdd();
		$item->OnLeft = FALSE;

		// "delete"
		$item = &$this->ListOptions->add("delete");
		$item->CssClass = "text-nowrap";
		$item->Visible = $Security->canDelete();
		$item->OnLeft = FALSE;

		// Drop down button for ListOptions
		$this->ListOptions->UseDropDownButton = FALSE;
		$this->ListOptions->DropDownButtonPhrase = $Language->phrase("ButtonListOptions");
		$this->ListOptions->UseButtonGroup = FALSE;
		if ($this->ListOptions->UseButtonGroup && IsMobile())
			$this->ListOptions->UseDropDownButton = TRUE;

		//$this->ListOptions->ButtonClass = ""; // Class for button group
		// Call ListOptions_Load event

		$this->ListOptions_Load();
		$item = $this->ListOptions[$this->ListOptions->GroupOptionName];
		$item->Visible = $this->ListOptions->groupOptionVisible();
	}

	// Render list options
	public function renderListOptions()
	{
		global $Security, $Language, $CurrentForm;
		$this->ListOptions->loadDefault();

		// Call ListOptions_Rendering event
		$this->ListOptions_Rendering();

		// Set up row action and key
		if (is_numeric($this->RowIndex) && $this->CurrentMode != "view") {
			$CurrentForm->Index = $this->RowIndex;
			$actionName = str_replace("k_", "k" . $this->RowIndex . "_", $this->FormActionName);
			$oldKeyName = str_replace("k_", "k" . $this->RowIndex . "_", $this->FormOldKeyName);
			$keyName = str_replace("k_", "k" . $this->RowIndex . "_", $this->FormKeyName);
			$blankRowName = str_replace("k_", "k" . $this->RowIndex . "_", $this->FormBlankRowName);
			if ($this->RowAction != "")
				$this->MultiSelectKey .= "<input type=\"hidden\" name=\"" . $actionName . "\" id=\"" . $actionName . "\" value=\"" . $this->RowAction . "\">";
			if ($CurrentForm->hasValue($this->FormOldKeyName))
				$this->RowOldKey = strval($CurrentForm->getValue($this->FormOldKeyName));
			if ($this->RowOldKey != "")
				$this->MultiSelectKey .= "<input type=\"hidden\" name=\"" . $oldKeyName . "\" id=\"" . $oldKeyName . "\" value=\"" . HtmlEncode($this->RowOldKey) . "\">";
			if ($this->RowAction == "delete") {
				$rowkey = $CurrentForm->getValue($this->FormKeyName);
				$this->setupKeyValues($rowkey);

				// Reload hidden key for delete
				$this->MultiSelectKey .= "<input type=\"hidden\" name=\"" . $keyName . "\" id=\"" . $keyName . "\" value=\"" . HtmlEncode($rowkey) . "\">";
			}
			if ($this->RowAction == "insert" && $this->isConfirm() && $this->emptyRow())
				$this->MultiSelectKey .= "<input type=\"hidden\" name=\"" . $blankRowName . "\" id=\"" . $blankRowName . "\" value=\"1\">";
		}

		// "delete"
		if ($this->AllowAddDeleteRow) {
			if ($this->CurrentMode == "add" || $this->CurrentMode == "copy" || $this->CurrentMode == "edit") {
				$options = &$this->ListOptions;
				$options->UseButtonGroup = TRUE; // Use button group for grid delete button
				$opt = $options["griddelete"];
				if (!$Security->canDelete() && is_numeric($this->RowIndex) && ($this->RowAction == "" || $this->RowAction == "edit")) { // Do not allow delete existing record
					$opt->Body = "&nbsp;";
				} else {
					$opt->Body = "<a class=\"ew-grid-link ew-grid-delete\" title=\"" . HtmlTitle($Language->phrase("DeleteLink")) . "\" data-caption=\"" . HtmlTitle($Language->phrase("DeleteLink")) . "\" onclick=\"return ew.deleteGridRow(this, " . $this->RowIndex . ");\">" . $Language->phrase("DeleteLink") . "</a>";
				}
			}
		}
		if ($this->CurrentMode == "view") { // View mode

		// "view"
		$opt = $this->ListOptions["view"];
		$viewcaption = HtmlTitle($Language->phrase("ViewLink"));
		if ($Security->canView()) {
			$opt->Body = "<a class=\"ew-row-link ew-view\" title=\"" . $viewcaption . "\" data-caption=\"" . $viewcaption . "\" href=\"" . HtmlEncode($this->ViewUrl) . "\">" . $Language->phrase("ViewLink") . "</a>";
		} else {
			$opt->Body = "";
		}

		// "edit"
		$opt = $this->ListOptions["edit"];
		$editcaption = HtmlTitle($Language->phrase("EditLink"));
		if ($Security->canEdit()) {
			$opt->Body = "<a class=\"ew-row-link ew-edit\" title=\"" . HtmlTitle($Language->phrase("EditLink")) . "\" data-caption=\"" . HtmlTitle($Language->phrase("EditLink")) . "\" href=\"" . HtmlEncode($this->EditUrl) . "\">" . $Language->phrase("EditLink") . "</a>";
		} else {
			$opt->Body = "";
		}

		// "copy"
		$opt = $this->ListOptions["copy"];
		$copycaption = HtmlTitle($Language->phrase("CopyLink"));
		if ($Security->canAdd()) {
			$opt->Body = "<a class=\"ew-row-link ew-copy\" title=\"" . $copycaption . "\" data-caption=\"" . $copycaption . "\" href=\"" . HtmlEncode($this->CopyUrl) . "\">" . $Language->phrase("CopyLink") . "</a>";
		} else {
			$opt->Body = "";
		}

		// "delete"
		$opt = $this->ListOptions["delete"];
		if ($Security->canDelete())
			$opt->Body = "<a class=\"ew-row-link ew-delete\"" . "" . " title=\"" . HtmlTitle($Language->phrase("DeleteLink")) . "\" data-caption=\"" . HtmlTitle($Language->phrase("DeleteLink")) . "\" href=\"" . HtmlEncode($this->DeleteUrl) . "\">" . $Language->phrase("DeleteLink") . "</a>";
		else
			$opt->Body = "";
		} // End View mode
		if ($this->CurrentMode == "edit" && is_numeric($this->RowIndex) && $this->RowAction != "delete") {
			$this->MultiSelectKey .= "<input type=\"hidden\" name=\"" . $keyName . "\" id=\"" . $keyName . "\" value=\"" . $this->purchaseid->CurrentValue . "\">";
		}
		$this->renderListOptionsExt();

		// Call ListOptions_Rendered event
		$this->ListOptions_Rendered();
	}

	// Set record key
	public function setRecordKey(&$key, $rs)
	{
		$key = "";
		if ($key != "")
			$key .= Config("COMPOSITE_KEY_SEPARATOR");
		$key .= $rs->fields('purchaseid');
	}

	// Set up other options
	protected function setupOtherOptions()
	{
		global $Language, $Security;
		$option = $this->OtherOptions["addedit"];
		$option->UseDropDownButton = FALSE;
		$option->DropDownButtonPhrase = $Language->phrase("ButtonAddEdit");
		$option->UseButtonGroup = TRUE;

		//$option->ButtonClass = ""; // Class for button group
		$item = &$option->add($option->GroupOptionName);
		$item->Body = "";
		$item->Visible = FALSE;

		// Add
		if ($this->CurrentMode == "view") { // Check view mode
			$item = &$option->add("add");
			$addcaption = HtmlTitle($Language->phrase("AddLink"));
			$this->AddUrl = $this->getAddUrl();
			$item->Body = "<a class=\"ew-add-edit ew-add\" title=\"" . $addcaption . "\" data-caption=\"" . $addcaption . "\" href=\"" . HtmlEncode($this->AddUrl) . "\">" . $Language->phrase("AddLink") . "</a>";
			$item->Visible = $this->AddUrl != "" && $Security->canAdd();
		}
	}

	// Render other options
	public function renderOtherOptions()
	{
		global $Language, $Security;
		$options = &$this->OtherOptions;
		if (($this->CurrentMode == "add" || $this->CurrentMode == "copy" || $this->CurrentMode == "edit") && !$this->isConfirm()) { // Check add/copy/edit mode
			if ($this->AllowAddDeleteRow) {
				$option = $options["addedit"];
				$option->UseDropDownButton = FALSE;
				$item = &$option->add("addblankrow");
				$item->Body = "<a class=\"ew-add-edit ew-add-blank-row\" title=\"" . HtmlTitle($Language->phrase("AddBlankRow")) . "\" data-caption=\"" . HtmlTitle($Language->phrase("AddBlankRow")) . "\" href=\"#\" onclick=\"return ew.addGridRow(this);\">" . $Language->phrase("AddBlankRow") . "</a>";
				$item->Visible = $Security->canAdd();
				$this->ShowOtherOptions = $item->Visible;
			}
		}
		if ($this->CurrentMode == "view") { // Check view mode
			$option = $options["addedit"];
			$item = $option["add"];
			$this->ShowOtherOptions = $item && $item->Visible;
		}
	}

// Set up list options (extended codes)
	protected function setupListOptionsExt()
	{

		// Hide detail items for dropdown if necessary
		$this->ListOptions->hideDetailItemsForDropDown();
	}

// Render list options (extended codes)
	protected function renderListOptionsExt()
	{
		global $Security, $Language;
		$links = "";
		$btngrps = "";
		$sqlwrk = "`purchaseid`=" . AdjustSql($this->purchaseid->CurrentValue, $this->Dbid) . "";

		// Column "detail_userpurchasepayment"
		if ($this->DetailPages && $this->DetailPages["userpurchasepayment"] && $this->DetailPages["userpurchasepayment"]->Visible) {
			$link = "";
			$option = $this->ListOptions["detail_userpurchasepayment"];
			$url = "userpurchasepaymentpreview.php?t=userpurchase&f=" . Encrypt($sqlwrk);
			$btngrp = "<div data-table=\"userpurchasepayment\" data-url=\"" . $url . "\">";
			if ($Security->allowList(CurrentProjectID() . 'userpurchase')) {
				$label = $Language->TablePhrase("userpurchasepayment", "TblCaption");
				$link = "<li class=\"nav-item\"><a href=\"#\" class=\"nav-link\" data-toggle=\"tab\" data-table=\"userpurchasepayment\" data-url=\"" . $url . "\">" . $label . "</a></li>";
				$links .= $link;
				$detaillnk = JsEncodeAttribute("userpurchasepaymentlist.php?" . Config("TABLE_SHOW_MASTER") . "=userpurchase&fk_purchaseid=" . urlencode(strval($this->purchaseid->CurrentValue)) . "");
				$btngrp .= "<a href=\"#\" class=\"mr-2\" title=\"" . $Language->TablePhrase("userpurchasepayment", "TblCaption") . "\" onclick=\"window.location='" . $detaillnk . "';return false;\">" . $Language->phrase("MasterDetailListLink") . "</a>";
			}
			if (!isset($GLOBALS["userpurchasepayment_grid"]))
				$GLOBALS["userpurchasepayment_grid"] = new userpurchasepayment_grid();
			if ($GLOBALS["userpurchasepayment_grid"]->DetailView && $Security->canView() && $Security->allowView(CurrentProjectID() . 'userpurchase')) {
				$caption = $Language->phrase("MasterDetailViewLink");
				$url = $this->getViewUrl(Config("TABLE_SHOW_DETAIL") . "=userpurchasepayment");
				$btngrp .= "<a href=\"#\" class=\"mr-2\" title=\"" . HtmlTitle($caption) . "\" onclick=\"window.location='" . HtmlEncode($url) . "';return false;\">" . $caption . "</a>";
			}
			if ($GLOBALS["userpurchasepayment_grid"]->DetailEdit && $Security->canEdit() && $Security->allowEdit(CurrentProjectID() . 'userpurchase')) {
				$caption = $Language->phrase("MasterDetailEditLink");
				$url = $this->getEditUrl(Config("TABLE_SHOW_DETAIL") . "=userpurchasepayment");
				$btngrp .= "<a href=\"#\" class=\"mr-2\" title=\"" . HtmlTitle($caption) . "\" onclick=\"window.location='" . HtmlEncode($url) . "';return false;\">" . $caption . "</a>";
			}
			if ($GLOBALS["userpurchasepayment_grid"]->DetailAdd && $Security->canAdd() && $Security->allowAdd(CurrentProjectID() . 'userpurchase')) {
				$caption = $Language->phrase("MasterDetailCopyLink");
				$url = $this->getCopyUrl(Config("TABLE_SHOW_DETAIL") . "=userpurchasepayment");
				$btngrp .= "<a href=\"#\" class=\"mr-2\" title=\"" . HtmlTitle($caption) . "\" onclick=\"window.location='" . HtmlEncode($url) . "';return false;\">" . $caption . "</a>";
			}
			$btngrp .= "</div>";
			if ($link != "") {
				$btngrps .= $btngrp;
				$option->Body .= "<div class=\"d-none ew-preview\">" . $link . $btngrp . "</div>";
			}
		}
		$sqlwrk = "`purchaseid`=" . AdjustSql($this->purchaseid->CurrentValue, $this->Dbid) . "";

		// Column "detail_userpurchasereturn"
		if ($this->DetailPages && $this->DetailPages["userpurchasereturn"] && $this->DetailPages["userpurchasereturn"]->Visible) {
			$link = "";
			$option = $this->ListOptions["detail_userpurchasereturn"];
			$url = "userpurchasereturnpreview.php?t=userpurchase&f=" . Encrypt($sqlwrk);
			$btngrp = "<div data-table=\"userpurchasereturn\" data-url=\"" . $url . "\">";
			if ($Security->allowList(CurrentProjectID() . 'userpurchase')) {
				$label = $Language->TablePhrase("userpurchasereturn", "TblCaption");
				$link = "<li class=\"nav-item\"><a href=\"#\" class=\"nav-link\" data-toggle=\"tab\" data-table=\"userpurchasereturn\" data-url=\"" . $url . "\">" . $label . "</a></li>";
				$links .= $link;
				$detaillnk = JsEncodeAttribute("userpurchasereturnlist.php?" . Config("TABLE_SHOW_MASTER") . "=userpurchase&fk_purchaseid=" . urlencode(strval($this->purchaseid->CurrentValue)) . "");
				$btngrp .= "<a href=\"#\" class=\"mr-2\" title=\"" . $Language->TablePhrase("userpurchasereturn", "TblCaption") . "\" onclick=\"window.location='" . $detaillnk . "';return false;\">" . $Language->phrase("MasterDetailListLink") . "</a>";
			}
			if (!isset($GLOBALS["userpurchasereturn_grid"]))
				$GLOBALS["userpurchasereturn_grid"] = new userpurchasereturn_grid();
			if ($GLOBALS["userpurchasereturn_grid"]->DetailView && $Security->canView() && $Security->allowView(CurrentProjectID() . 'userpurchase')) {
				$caption = $Language->phrase("MasterDetailViewLink");
				$url = $this->getViewUrl(Config("TABLE_SHOW_DETAIL") . "=userpurchasereturn");
				$btngrp .= "<a href=\"#\" class=\"mr-2\" title=\"" . HtmlTitle($caption) . "\" onclick=\"window.location='" . HtmlEncode($url) . "';return false;\">" . $caption . "</a>";
			}
			if ($GLOBALS["userpurchasereturn_grid"]->DetailEdit && $Security->canEdit() && $Security->allowEdit(CurrentProjectID() . 'userpurchase')) {
				$caption = $Language->phrase("MasterDetailEditLink");
				$url = $this->getEditUrl(Config("TABLE_SHOW_DETAIL") . "=userpurchasereturn");
				$btngrp .= "<a href=\"#\" class=\"mr-2\" title=\"" . HtmlTitle($caption) . "\" onclick=\"window.location='" . HtmlEncode($url) . "';return false;\">" . $caption . "</a>";
			}
			if ($GLOBALS["userpurchasereturn_grid"]->DetailAdd && $Security->canAdd() && $Security->allowAdd(CurrentProjectID() . 'userpurchase')) {
				$caption = $Language->phrase("MasterDetailCopyLink");
				$url = $this->getCopyUrl(Config("TABLE_SHOW_DETAIL") . "=userpurchasereturn");
				$btngrp .= "<a href=\"#\" class=\"mr-2\" title=\"" . HtmlTitle($caption) . "\" onclick=\"window.location='" . HtmlEncode($url) . "';return false;\">" . $caption . "</a>";
			}
			$btngrp .= "</div>";
			if ($link != "") {
				$btngrps .= $btngrp;
				$option->Body .= "<div class=\"d-none ew-preview\">" . $link . $btngrp . "</div>";
			}
		}
		$sqlwrk = "`purchaseid`=" . AdjustSql($this->purchaseid->CurrentValue, $this->Dbid) . "";

		// Column "detail_vbillinghistory"
		if ($this->DetailPages && $this->DetailPages["vbillinghistory"] && $this->DetailPages["vbillinghistory"]->Visible) {
			$link = "";
			$option = $this->ListOptions["detail_vbillinghistory"];
			$url = "vbillinghistorypreview.php?t=userpurchase&f=" . Encrypt($sqlwrk);
			$btngrp = "<div data-table=\"vbillinghistory\" data-url=\"" . $url . "\">";
			if ($Security->allowList(CurrentProjectID() . 'userpurchase')) {
				$label = $Language->TablePhrase("vbillinghistory", "TblCaption");
				$link = "<li class=\"nav-item\"><a href=\"#\" class=\"nav-link\" data-toggle=\"tab\" data-table=\"vbillinghistory\" data-url=\"" . $url . "\">" . $label . "</a></li>";
				$links .= $link;
				$detaillnk = JsEncodeAttribute("vbillinghistorylist.php?" . Config("TABLE_SHOW_MASTER") . "=userpurchase&fk_purchaseid=" . urlencode(strval($this->purchaseid->CurrentValue)) . "");
				$btngrp .= "<a href=\"#\" class=\"mr-2\" title=\"" . $Language->TablePhrase("vbillinghistory", "TblCaption") . "\" onclick=\"window.location='" . $detaillnk . "';return false;\">" . $Language->phrase("MasterDetailListLink") . "</a>";
			}
			if (!isset($GLOBALS["vbillinghistory_grid"]))
				$GLOBALS["vbillinghistory_grid"] = new vbillinghistory_grid();
			if ($GLOBALS["vbillinghistory_grid"]->DetailView && $Security->canView() && $Security->allowView(CurrentProjectID() . 'userpurchase')) {
				$caption = $Language->phrase("MasterDetailViewLink");
				$url = $this->getViewUrl(Config("TABLE_SHOW_DETAIL") . "=vbillinghistory");
				$btngrp .= "<a href=\"#\" class=\"mr-2\" title=\"" . HtmlTitle($caption) . "\" onclick=\"window.location='" . HtmlEncode($url) . "';return false;\">" . $caption . "</a>";
			}
			if ($GLOBALS["vbillinghistory_grid"]->DetailEdit && $Security->canEdit() && $Security->allowEdit(CurrentProjectID() . 'userpurchase')) {
				$caption = $Language->phrase("MasterDetailEditLink");
				$url = $this->getEditUrl(Config("TABLE_SHOW_DETAIL") . "=vbillinghistory");
				$btngrp .= "<a href=\"#\" class=\"mr-2\" title=\"" . HtmlTitle($caption) . "\" onclick=\"window.location='" . HtmlEncode($url) . "';return false;\">" . $caption . "</a>";
			}
			$btngrp .= "</div>";
			if ($link != "") {
				$btngrps .= $btngrp;
				$option->Body .= "<div class=\"d-none ew-preview\">" . $link . $btngrp . "</div>";
			}
		}

		// Hide detail items if necessary
		$this->ListOptions->hideDetailItemsForDropDown();

		// Column "preview"
		$option = $this->ListOptions["preview"];
		if (!$option) { // Add preview column
			$option = &$this->ListOptions->add("preview");
			$option->OnLeft = FALSE;
			if ($option->OnLeft) {
				$option->moveTo($this->ListOptions->itemPos("checkbox") + 1);
			} else {
				$option->moveTo($this->ListOptions->itemPos("checkbox"));
			}
			$option->Visible = !($this->isExport() || $this->isGridAdd() || $this->isGridEdit());
			$option->ShowInDropDown = FALSE;
			$option->ShowInButtonGroup = FALSE;
		}
		if ($option) {
			$option->Body = "<i class=\"ew-preview-row-btn ew-icon icon-expand\"></i>";
			$option->Body .= "<div class=\"d-none ew-preview\">" . $links . $btngrps . "</div>";
			if ($option->Visible)
				$option->Visible = $links != "";
		}

		// Column "details" (Multiple details)
		$option = $this->ListOptions["details"];
		if ($option) {
			$option->Body .= "<div class=\"d-none ew-preview\">" . $links . $btngrps . "</div>";
			if ($option->Visible)
				$option->Visible = $links != "";
		}
	}

	// Get upload files
	protected function getUploadFiles()
	{
		global $CurrentForm, $Language;
	}

	// Load default values
	protected function loadDefaultValues()
	{
		$this->purchaseid->CurrentValue = NULL;
		$this->purchaseid->OldValue = $this->purchaseid->CurrentValue;
		$this->_userid->CurrentValue = NULL;
		$this->_userid->OldValue = $this->_userid->CurrentValue;
		$this->merchantnodeid->CurrentValue = NULL;
		$this->merchantnodeid->OldValue = $this->merchantnodeid->CurrentValue;
		$this->merchantid->CurrentValue = NULL;
		$this->merchantid->OldValue = $this->merchantid->CurrentValue;
		$this->merchantbusinessname->CurrentValue = NULL;
		$this->merchantbusinessname->OldValue = $this->merchantbusinessname->CurrentValue;
		$this->merchanttransferid->CurrentValue = NULL;
		$this->merchanttransferid->OldValue = $this->merchanttransferid->CurrentValue;
		$this->merchantuserid->CurrentValue = NULL;
		$this->merchantuserid->OldValue = $this->merchantuserid->CurrentValue;
		$this->purchasedate->CurrentValue = NULL;
		$this->purchasedate->OldValue = $this->purchasedate->CurrentValue;
		$this->txid->CurrentValue = NULL;
		$this->txid->OldValue = $this->txid->CurrentValue;
		$this->userpi->CurrentValue = NULL;
		$this->userpi->OldValue = $this->userpi->CurrentValue;
		$this->otherconfirmref->CurrentValue = NULL;
		$this->otherconfirmref->OldValue = $this->otherconfirmref->CurrentValue;
		$this->currencycode->CurrentValue = NULL;
		$this->currencycode->OldValue = $this->currencycode->CurrentValue;
		$this->purchaseamount->CurrentValue = 0.00;
		$this->purchaseamount->OldValue = $this->purchaseamount->CurrentValue;
		$this->tipamount->CurrentValue = 0.00;
		$this->tipamount->OldValue = $this->tipamount->CurrentValue;
		$this->merchantfees->CurrentValue = 0.00;
		$this->merchantfees->OldValue = $this->merchantfees->CurrentValue;
		$this->consumerfees->CurrentValue = 0.00;
		$this->consumerfees->OldValue = $this->consumerfees->CurrentValue;
		$this->transferid->CurrentValue = NULL;
		$this->transferid->OldValue = $this->transferid->CurrentValue;
		$this->merchantSurcharge->CurrentValue = NULL;
		$this->merchantSurcharge->OldValue = $this->merchantSurcharge->CurrentValue;
		$this->taxAmount->CurrentValue = NULL;
		$this->taxAmount->OldValue = $this->taxAmount->CurrentValue;
		$this->totalAmounForCustomer->CurrentValue = NULL;
		$this->totalAmounForCustomer->OldValue = $this->totalAmounForCustomer->CurrentValue;
		$this->feeid->CurrentValue = NULL;
		$this->feeid->OldValue = $this->feeid->CurrentValue;
		$this->ratetabletype->CurrentValue = NULL;
		$this->ratetabletype->OldValue = $this->ratetabletype->CurrentValue;
		$this->itemdesc->CurrentValue = NULL;
		$this->itemdesc->OldValue = $this->itemdesc->CurrentValue;
		$this->shoppingCartID->CurrentValue = NULL;
		$this->shoppingCartID->OldValue = $this->shoppingCartID->CurrentValue;
		$this->merchantRefID->CurrentValue = NULL;
		$this->merchantRefID->OldValue = $this->merchantRefID->CurrentValue;
		$this->refunded->CurrentValue = 0;
		$this->refunded->OldValue = $this->refunded->CurrentValue;
		$this->tokenid->CurrentValue = NULL;
		$this->tokenid->OldValue = $this->tokenid->CurrentValue;
		$this->cardno->CurrentValue = NULL;
		$this->cardno->OldValue = $this->cardno->CurrentValue;
		$this->vaultid->CurrentValue = NULL;
		$this->vaultid->OldValue = $this->vaultid->CurrentValue;
		$this->refundrequested->CurrentValue = 0;
		$this->refundrequested->OldValue = $this->refundrequested->CurrentValue;
		$this->refundrequesttxid->CurrentValue = NULL;
		$this->refundrequesttxid->OldValue = $this->refundrequesttxid->CurrentValue;
		$this->feesystemshare->CurrentValue = 0.00;
		$this->feesystemshare->OldValue = $this->feesystemshare->CurrentValue;
		$this->feeexternalshare->CurrentValue = 0.00;
		$this->feeexternalshare->OldValue = $this->feeexternalshare->CurrentValue;
		$this->feefranchiseeshare->CurrentValue = 0.00;
		$this->feefranchiseeshare->OldValue = $this->feefranchiseeshare->CurrentValue;
		$this->feeresellershare->CurrentValue = 0.00;
		$this->feeresellershare->OldValue = $this->feeresellershare->CurrentValue;
		$this->_key->CurrentValue = NULL;
		$this->_key->OldValue = $this->_key->CurrentValue;
		$this->serviceFeeToCustomerbk1amt->CurrentValue = 0.00;
		$this->serviceFeeToCustomerbk1amt->OldValue = $this->serviceFeeToCustomerbk1amt->CurrentValue;
		$this->serviceFeeToCustomerbk1type->CurrentValue = NULL;
		$this->serviceFeeToCustomerbk1type->OldValue = $this->serviceFeeToCustomerbk1type->CurrentValue;
		$this->serviceFeeToCustomerbk2amt->CurrentValue = 0.00;
		$this->serviceFeeToCustomerbk2amt->OldValue = $this->serviceFeeToCustomerbk2amt->CurrentValue;
		$this->serviceFeeToCustomerbk2type->CurrentValue = NULL;
		$this->serviceFeeToCustomerbk2type->OldValue = $this->serviceFeeToCustomerbk2type->CurrentValue;
		$this->serviceFeeToCustomerbk3amt->CurrentValue = 0.00;
		$this->serviceFeeToCustomerbk3amt->OldValue = $this->serviceFeeToCustomerbk3amt->CurrentValue;
		$this->serviceFeeToCustomerbk3type->CurrentValue = NULL;
		$this->serviceFeeToCustomerbk3type->OldValue = $this->serviceFeeToCustomerbk3type->CurrentValue;
		$this->taxAmountbk1amt->CurrentValue = 0.00;
		$this->taxAmountbk1amt->OldValue = $this->taxAmountbk1amt->CurrentValue;
		$this->taxAmountbk1type->CurrentValue = NULL;
		$this->taxAmountbk1type->OldValue = $this->taxAmountbk1type->CurrentValue;
		$this->taxAmountbk2amt->CurrentValue = 0.00;
		$this->taxAmountbk2amt->OldValue = $this->taxAmountbk2amt->CurrentValue;
		$this->taxAmountbk2type->CurrentValue = NULL;
		$this->taxAmountbk2type->OldValue = $this->taxAmountbk2type->CurrentValue;
		$this->taxAmountbk3amt->CurrentValue = 0.00;
		$this->taxAmountbk3amt->OldValue = $this->taxAmountbk3amt->CurrentValue;
		$this->taxAmountbk3type->CurrentValue = NULL;
		$this->taxAmountbk3type->OldValue = $this->taxAmountbk3type->CurrentValue;
		$this->originalpurchaseamount->CurrentValue = 0.00;
		$this->originalpurchaseamount->OldValue = $this->originalpurchaseamount->CurrentValue;
		$this->discountamount->CurrentValue = 0.00;
		$this->discountamount->OldValue = $this->discountamount->CurrentValue;
		$this->discountpercentage->CurrentValue = 0;
		$this->discountpercentage->OldValue = $this->discountpercentage->CurrentValue;
		$this->txgroupid->CurrentValue = 0;
		$this->txgroupid->OldValue = $this->txgroupid->CurrentValue;
		$this->success_status->CurrentValue = 1;
		$this->success_status->OldValue = $this->success_status->CurrentValue;
		$this->error_msg->CurrentValue = NULL;
		$this->error_msg->OldValue = $this->error_msg->CurrentValue;
		$this->userpiid->CurrentValue = NULL;
		$this->userpiid->OldValue = $this->userpiid->CurrentValue;
		$this->notes->CurrentValue = NULL;
		$this->notes->OldValue = $this->notes->CurrentValue;
		$this->lastpurchasereaddate->CurrentValue = NULL;
		$this->lastpurchasereaddate->OldValue = $this->lastpurchasereaddate->CurrentValue;
		$this->retryapicount->CurrentValue = 0;
		$this->retryapicount->OldValue = $this->retryapicount->CurrentValue;
	}

	// Load form values
	protected function loadFormValues()
	{

		// Load from form
		global $CurrentForm;
		$CurrentForm->FormName = $this->FormName;

		// Check field name 'purchaseid' first before field var 'x_purchaseid'
		$val = $CurrentForm->hasValue("purchaseid") ? $CurrentForm->getValue("purchaseid") : $CurrentForm->getValue("x_purchaseid");
		if (!$this->purchaseid->IsDetailKey && !$this->isGridAdd() && !$this->isAdd())
			$this->purchaseid->setFormValue($val);

		// Check field name 'userid' first before field var 'x__userid'
		$val = $CurrentForm->hasValue("userid") ? $CurrentForm->getValue("userid") : $CurrentForm->getValue("x__userid");
		if (!$this->_userid->IsDetailKey) {
			if (IsApi() && $val === NULL)
				$this->_userid->Visible = FALSE; // Disable update for API request
			else
				$this->_userid->setFormValue($val);
		}
		if ($CurrentForm->hasValue("o__userid"))
			$this->_userid->setOldValue($CurrentForm->getValue("o__userid"));

		// Check field name 'merchantid' first before field var 'x_merchantid'
		$val = $CurrentForm->hasValue("merchantid") ? $CurrentForm->getValue("merchantid") : $CurrentForm->getValue("x_merchantid");
		if (!$this->merchantid->IsDetailKey) {
			if (IsApi() && $val === NULL)
				$this->merchantid->Visible = FALSE; // Disable update for API request
			else
				$this->merchantid->setFormValue($val);
		}
		if ($CurrentForm->hasValue("o_merchantid"))
			$this->merchantid->setOldValue($CurrentForm->getValue("o_merchantid"));

		// Check field name 'merchanttransferid' first before field var 'x_merchanttransferid'
		$val = $CurrentForm->hasValue("merchanttransferid") ? $CurrentForm->getValue("merchanttransferid") : $CurrentForm->getValue("x_merchanttransferid");
		if (!$this->merchanttransferid->IsDetailKey) {
			if (IsApi() && $val === NULL)
				$this->merchanttransferid->Visible = FALSE; // Disable update for API request
			else
				$this->merchanttransferid->setFormValue($val);
		}
		if ($CurrentForm->hasValue("o_merchanttransferid"))
			$this->merchanttransferid->setOldValue($CurrentForm->getValue("o_merchanttransferid"));

		// Check field name 'purchasedate' first before field var 'x_purchasedate'
		$val = $CurrentForm->hasValue("purchasedate") ? $CurrentForm->getValue("purchasedate") : $CurrentForm->getValue("x_purchasedate");
		if (!$this->purchasedate->IsDetailKey) {
			if (IsApi() && $val === NULL)
				$this->purchasedate->Visible = FALSE; // Disable update for API request
			else
				$this->purchasedate->setFormValue($val);
			$this->purchasedate->CurrentValue = UnFormatDateTime($this->purchasedate->CurrentValue, 1);
		}
		if ($CurrentForm->hasValue("o_purchasedate"))
			$this->purchasedate->setOldValue($CurrentForm->getValue("o_purchasedate"));

		// Check field name 'txid' first before field var 'x_txid'
		$val = $CurrentForm->hasValue("txid") ? $CurrentForm->getValue("txid") : $CurrentForm->getValue("x_txid");
		if (!$this->txid->IsDetailKey) {
			if (IsApi() && $val === NULL)
				$this->txid->Visible = FALSE; // Disable update for API request
			else
				$this->txid->setFormValue($val);
		}
		if ($CurrentForm->hasValue("o_txid"))
			$this->txid->setOldValue($CurrentForm->getValue("o_txid"));

		// Check field name 'userpi' first before field var 'x_userpi'
		$val = $CurrentForm->hasValue("userpi") ? $CurrentForm->getValue("userpi") : $CurrentForm->getValue("x_userpi");
		if (!$this->userpi->IsDetailKey) {
			if (IsApi() && $val === NULL)
				$this->userpi->Visible = FALSE; // Disable update for API request
			else
				$this->userpi->setFormValue($val);
		}
		if ($CurrentForm->hasValue("o_userpi"))
			$this->userpi->setOldValue($CurrentForm->getValue("o_userpi"));

		// Check field name 'currencycode' first before field var 'x_currencycode'
		$val = $CurrentForm->hasValue("currencycode") ? $CurrentForm->getValue("currencycode") : $CurrentForm->getValue("x_currencycode");
		if (!$this->currencycode->IsDetailKey) {
			if (IsApi() && $val === NULL)
				$this->currencycode->Visible = FALSE; // Disable update for API request
			else
				$this->currencycode->setFormValue($val);
		}
		if ($CurrentForm->hasValue("o_currencycode"))
			$this->currencycode->setOldValue($CurrentForm->getValue("o_currencycode"));

		// Check field name 'purchaseamount' first before field var 'x_purchaseamount'
		$val = $CurrentForm->hasValue("purchaseamount") ? $CurrentForm->getValue("purchaseamount") : $CurrentForm->getValue("x_purchaseamount");
		if (!$this->purchaseamount->IsDetailKey) {
			if (IsApi() && $val === NULL)
				$this->purchaseamount->Visible = FALSE; // Disable update for API request
			else
				$this->purchaseamount->setFormValue($val);
		}
		if ($CurrentForm->hasValue("o_purchaseamount"))
			$this->purchaseamount->setOldValue($CurrentForm->getValue("o_purchaseamount"));

		// Check field name 'success_status' first before field var 'x_success_status'
		$val = $CurrentForm->hasValue("success_status") ? $CurrentForm->getValue("success_status") : $CurrentForm->getValue("x_success_status");
		if (!$this->success_status->IsDetailKey) {
			if (IsApi() && $val === NULL)
				$this->success_status->Visible = FALSE; // Disable update for API request
			else
				$this->success_status->setFormValue($val);
		}
		if ($CurrentForm->hasValue("o_success_status"))
			$this->success_status->setOldValue($CurrentForm->getValue("o_success_status"));

		// Check field name 'userpiid' first before field var 'x_userpiid'
		$val = $CurrentForm->hasValue("userpiid") ? $CurrentForm->getValue("userpiid") : $CurrentForm->getValue("x_userpiid");
		if (!$this->userpiid->IsDetailKey) {
			if (IsApi() && $val === NULL)
				$this->userpiid->Visible = FALSE; // Disable update for API request
			else
				$this->userpiid->setFormValue($val);
		}
		if ($CurrentForm->hasValue("o_userpiid"))
			$this->userpiid->setOldValue($CurrentForm->getValue("o_userpiid"));
	}

	// Restore form values
	public function restoreFormValues()
	{
		global $CurrentForm;
		if (!$this->isGridAdd() && !$this->isAdd())
			$this->purchaseid->CurrentValue = $this->purchaseid->FormValue;
		$this->_userid->CurrentValue = $this->_userid->FormValue;
		$this->merchantid->CurrentValue = $this->merchantid->FormValue;
		$this->merchanttransferid->CurrentValue = $this->merchanttransferid->FormValue;
		$this->purchasedate->CurrentValue = $this->purchasedate->FormValue;
		$this->purchasedate->CurrentValue = UnFormatDateTime($this->purchasedate->CurrentValue, 1);
		$this->txid->CurrentValue = $this->txid->FormValue;
		$this->userpi->CurrentValue = $this->userpi->FormValue;
		$this->currencycode->CurrentValue = $this->currencycode->FormValue;
		$this->purchaseamount->CurrentValue = $this->purchaseamount->FormValue;
		$this->success_status->CurrentValue = $this->success_status->FormValue;
		$this->userpiid->CurrentValue = $this->userpiid->FormValue;
	}

	// Load recordset
	public function loadRecordset($offset = -1, $rowcnt = -1)
	{

		// Load List page SQL
		$sql = $this->getListSql();
		$conn = $this->getConnection();

		// Load recordset
		$dbtype = GetConnectionType($this->Dbid);
		if ($this->UseSelectLimit) {
			$conn->raiseErrorFn = Config("ERROR_FUNC");
			if ($dbtype == "MSSQL") {
				$rs = $conn->selectLimit($sql, $rowcnt, $offset, ["_hasOrderBy" => trim($this->getOrderBy()) || trim($this->getSessionOrderBy())]);
			} else {
				$rs = $conn->selectLimit($sql, $rowcnt, $offset);
			}
			$conn->raiseErrorFn = "";
		} else {
			$rs = LoadRecordset($sql, $conn);
		}

		// Call Recordset Selected event
		$this->Recordset_Selected($rs);
		return $rs;
	}

	// Load row based on key values
	public function loadRow()
	{
		global $Security, $Language;
		$filter = $this->getRecordFilter();

		// Call Row Selecting event
		$this->Row_Selecting($filter);

		// Load SQL based on filter
		$this->CurrentFilter = $filter;
		$sql = $this->getCurrentSql();
		$conn = $this->getConnection();
		$res = FALSE;
		$rs = LoadRecordset($sql, $conn);
		if ($rs && !$rs->EOF) {
			$res = TRUE;
			$this->loadRowValues($rs); // Load row values
			$rs->close();
		}
		return $res;
	}

	// Load row values from recordset
	public function loadRowValues($rs = NULL)
	{
		if ($rs && !$rs->EOF)
			$row = $rs->fields;
		else
			$row = $this->newRow();

		// Call Row Selected event
		$this->Row_Selected($row);
		if (!$rs || $rs->EOF)
			return;
		$this->purchaseid->setDbValue($row['purchaseid']);
		$this->_userid->setDbValue($row['userid']);
		$this->merchantnodeid->setDbValue($row['merchantnodeid']);
		$this->merchantid->setDbValue($row['merchantid']);
		$this->merchantbusinessname->setDbValue($row['merchantbusinessname']);
		$this->merchanttransferid->setDbValue($row['merchanttransferid']);
		$this->merchantuserid->setDbValue($row['merchantuserid']);
		$this->purchasedate->setDbValue($row['purchasedate']);
		$this->txid->setDbValue($row['txid']);
		$this->userpi->setDbValue($row['userpi']);
		$this->otherconfirmref->setDbValue($row['otherconfirmref']);
		$this->currencycode->setDbValue($row['currencycode']);
		$this->purchaseamount->setDbValue($row['purchaseamount']);
		$this->tipamount->setDbValue($row['tipamount']);
		$this->merchantfees->setDbValue($row['merchantfees']);
		$this->consumerfees->setDbValue($row['consumerfees']);
		$this->transferid->setDbValue($row['transferid']);
		$this->merchantSurcharge->setDbValue($row['merchantSurcharge']);
		$this->taxAmount->setDbValue($row['taxAmount']);
		$this->totalAmounForCustomer->setDbValue($row['totalAmounForCustomer']);
		$this->feeid->setDbValue($row['feeid']);
		$this->ratetabletype->setDbValue($row['ratetabletype']);
		$this->itemdesc->setDbValue($row['itemdesc']);
		$this->shoppingCartID->setDbValue($row['shoppingCartID']);
		$this->merchantRefID->setDbValue($row['merchantRefID']);
		$this->refunded->setDbValue($row['refunded']);
		$this->tokenid->setDbValue($row['tokenid']);
		$this->cardno->setDbValue($row['cardno']);
		$this->vaultid->setDbValue($row['vaultid']);
		$this->refundrequested->setDbValue($row['refundrequested']);
		$this->refundrequesttxid->setDbValue($row['refundrequesttxid']);
		$this->feesystemshare->setDbValue($row['feesystemshare']);
		$this->feeexternalshare->setDbValue($row['feeexternalshare']);
		$this->feefranchiseeshare->setDbValue($row['feefranchiseeshare']);
		$this->feeresellershare->setDbValue($row['feeresellershare']);
		$this->_key->setDbValue($row['key']);
		$this->serviceFeeToCustomerbk1amt->setDbValue($row['serviceFeeToCustomerbk1amt']);
		$this->serviceFeeToCustomerbk1type->setDbValue($row['serviceFeeToCustomerbk1type']);
		$this->serviceFeeToCustomerbk2amt->setDbValue($row['serviceFeeToCustomerbk2amt']);
		$this->serviceFeeToCustomerbk2type->setDbValue($row['serviceFeeToCustomerbk2type']);
		$this->serviceFeeToCustomerbk3amt->setDbValue($row['serviceFeeToCustomerbk3amt']);
		$this->serviceFeeToCustomerbk3type->setDbValue($row['serviceFeeToCustomerbk3type']);
		$this->taxAmountbk1amt->setDbValue($row['taxAmountbk1amt']);
		$this->taxAmountbk1type->setDbValue($row['taxAmountbk1type']);
		$this->taxAmountbk2amt->setDbValue($row['taxAmountbk2amt']);
		$this->taxAmountbk2type->setDbValue($row['taxAmountbk2type']);
		$this->taxAmountbk3amt->setDbValue($row['taxAmountbk3amt']);
		$this->taxAmountbk3type->setDbValue($row['taxAmountbk3type']);
		$this->originalpurchaseamount->setDbValue($row['originalpurchaseamount']);
		$this->discountamount->setDbValue($row['discountamount']);
		$this->discountpercentage->setDbValue($row['discountpercentage']);
		$this->txgroupid->setDbValue($row['txgroupid']);
		$this->success_status->setDbValue($row['success_status']);
		$this->error_msg->setDbValue($row['error_msg']);
		$this->userpiid->setDbValue($row['userpiid']);
		$this->notes->setDbValue($row['notes']);
		$this->lastpurchasereaddate->setDbValue($row['lastpurchasereaddate']);
		$this->retryapicount->setDbValue($row['retryapicount']);
	}

	// Return a row with default values
	protected function newRow()
	{
		$this->loadDefaultValues();
		$row = [];
		$row['purchaseid'] = $this->purchaseid->CurrentValue;
		$row['userid'] = $this->_userid->CurrentValue;
		$row['merchantnodeid'] = $this->merchantnodeid->CurrentValue;
		$row['merchantid'] = $this->merchantid->CurrentValue;
		$row['merchantbusinessname'] = $this->merchantbusinessname->CurrentValue;
		$row['merchanttransferid'] = $this->merchanttransferid->CurrentValue;
		$row['merchantuserid'] = $this->merchantuserid->CurrentValue;
		$row['purchasedate'] = $this->purchasedate->CurrentValue;
		$row['txid'] = $this->txid->CurrentValue;
		$row['userpi'] = $this->userpi->CurrentValue;
		$row['otherconfirmref'] = $this->otherconfirmref->CurrentValue;
		$row['currencycode'] = $this->currencycode->CurrentValue;
		$row['purchaseamount'] = $this->purchaseamount->CurrentValue;
		$row['tipamount'] = $this->tipamount->CurrentValue;
		$row['merchantfees'] = $this->merchantfees->CurrentValue;
		$row['consumerfees'] = $this->consumerfees->CurrentValue;
		$row['transferid'] = $this->transferid->CurrentValue;
		$row['merchantSurcharge'] = $this->merchantSurcharge->CurrentValue;
		$row['taxAmount'] = $this->taxAmount->CurrentValue;
		$row['totalAmounForCustomer'] = $this->totalAmounForCustomer->CurrentValue;
		$row['feeid'] = $this->feeid->CurrentValue;
		$row['ratetabletype'] = $this->ratetabletype->CurrentValue;
		$row['itemdesc'] = $this->itemdesc->CurrentValue;
		$row['shoppingCartID'] = $this->shoppingCartID->CurrentValue;
		$row['merchantRefID'] = $this->merchantRefID->CurrentValue;
		$row['refunded'] = $this->refunded->CurrentValue;
		$row['tokenid'] = $this->tokenid->CurrentValue;
		$row['cardno'] = $this->cardno->CurrentValue;
		$row['vaultid'] = $this->vaultid->CurrentValue;
		$row['refundrequested'] = $this->refundrequested->CurrentValue;
		$row['refundrequesttxid'] = $this->refundrequesttxid->CurrentValue;
		$row['feesystemshare'] = $this->feesystemshare->CurrentValue;
		$row['feeexternalshare'] = $this->feeexternalshare->CurrentValue;
		$row['feefranchiseeshare'] = $this->feefranchiseeshare->CurrentValue;
		$row['feeresellershare'] = $this->feeresellershare->CurrentValue;
		$row['key'] = $this->_key->CurrentValue;
		$row['serviceFeeToCustomerbk1amt'] = $this->serviceFeeToCustomerbk1amt->CurrentValue;
		$row['serviceFeeToCustomerbk1type'] = $this->serviceFeeToCustomerbk1type->CurrentValue;
		$row['serviceFeeToCustomerbk2amt'] = $this->serviceFeeToCustomerbk2amt->CurrentValue;
		$row['serviceFeeToCustomerbk2type'] = $this->serviceFeeToCustomerbk2type->CurrentValue;
		$row['serviceFeeToCustomerbk3amt'] = $this->serviceFeeToCustomerbk3amt->CurrentValue;
		$row['serviceFeeToCustomerbk3type'] = $this->serviceFeeToCustomerbk3type->CurrentValue;
		$row['taxAmountbk1amt'] = $this->taxAmountbk1amt->CurrentValue;
		$row['taxAmountbk1type'] = $this->taxAmountbk1type->CurrentValue;
		$row['taxAmountbk2amt'] = $this->taxAmountbk2amt->CurrentValue;
		$row['taxAmountbk2type'] = $this->taxAmountbk2type->CurrentValue;
		$row['taxAmountbk3amt'] = $this->taxAmountbk3amt->CurrentValue;
		$row['taxAmountbk3type'] = $this->taxAmountbk3type->CurrentValue;
		$row['originalpurchaseamount'] = $this->originalpurchaseamount->CurrentValue;
		$row['discountamount'] = $this->discountamount->CurrentValue;
		$row['discountpercentage'] = $this->discountpercentage->CurrentValue;
		$row['txgroupid'] = $this->txgroupid->CurrentValue;
		$row['success_status'] = $this->success_status->CurrentValue;
		$row['error_msg'] = $this->error_msg->CurrentValue;
		$row['userpiid'] = $this->userpiid->CurrentValue;
		$row['notes'] = $this->notes->CurrentValue;
		$row['lastpurchasereaddate'] = $this->lastpurchasereaddate->CurrentValue;
		$row['retryapicount'] = $this->retryapicount->CurrentValue;
		return $row;
	}

	// Load old record
	protected function loadOldRecord()
	{

		// Load key values from Session
		$validKey = TRUE;
		$keys = [$this->RowOldKey];
		$cnt = count($keys);
		if ($cnt >= 1) {
			if (strval($keys[0]) != "")
				$this->purchaseid->OldValue = strval($keys[0]); // purchaseid
			else
				$validKey = FALSE;
		} else {
			$validKey = FALSE;
		}

		// Load old record
		$this->OldRecordset = NULL;
		if ($validKey) {
			$this->CurrentFilter = $this->getRecordFilter();
			$sql = $this->getCurrentSql();
			$conn = $this->getConnection();
			$this->OldRecordset = LoadRecordset($sql, $conn);
		}
		$this->loadRowValues($this->OldRecordset); // Load row values
		return $validKey;
	}

	// Render row values based on field settings
	public function renderRow()
	{
		global $Security, $Language, $CurrentLanguage;

		// Initialize URLs
		$this->ViewUrl = $this->getViewUrl();
		$this->EditUrl = $this->getEditUrl();
		$this->CopyUrl = $this->getCopyUrl();
		$this->DeleteUrl = $this->getDeleteUrl();

		// Convert decimal values if posted back
		if ($this->purchaseamount->FormValue == $this->purchaseamount->CurrentValue && is_numeric(ConvertToFloatString($this->purchaseamount->CurrentValue)))
			$this->purchaseamount->CurrentValue = ConvertToFloatString($this->purchaseamount->CurrentValue);

		// Call Row_Rendering event
		$this->Row_Rendering();

		// Common render codes for all row types
		// purchaseid
		// userid
		// merchantnodeid
		// merchantid
		// merchantbusinessname
		// merchanttransferid
		// merchantuserid
		// purchasedate
		// txid
		// userpi
		// otherconfirmref
		// currencycode
		// purchaseamount
		// tipamount
		// merchantfees
		// consumerfees
		// transferid
		// merchantSurcharge
		// taxAmount
		// totalAmounForCustomer
		// feeid
		// ratetabletype
		// itemdesc
		// shoppingCartID
		// merchantRefID
		// refunded
		// tokenid
		// cardno
		// vaultid
		// refundrequested
		// refundrequesttxid
		// feesystemshare
		// feeexternalshare
		// feefranchiseeshare
		// feeresellershare
		// key
		// serviceFeeToCustomerbk1amt
		// serviceFeeToCustomerbk1type
		// serviceFeeToCustomerbk2amt
		// serviceFeeToCustomerbk2type
		// serviceFeeToCustomerbk3amt
		// serviceFeeToCustomerbk3type
		// taxAmountbk1amt
		// taxAmountbk1type
		// taxAmountbk2amt
		// taxAmountbk2type
		// taxAmountbk3amt
		// taxAmountbk3type
		// originalpurchaseamount
		// discountamount
		// discountpercentage
		// txgroupid
		// success_status
		// error_msg
		// userpiid
		// notes
		// lastpurchasereaddate
		// retryapicount

		if ($this->RowType == ROWTYPE_VIEW) { // View row

			// purchaseid
			$this->purchaseid->ViewValue = $this->purchaseid->CurrentValue;
			$this->purchaseid->ViewCustomAttributes = "";

			// userid
			$this->_userid->ViewValue = $this->_userid->CurrentValue;
			$this->_userid->ViewCustomAttributes = "";

			// merchantnodeid
			$this->merchantnodeid->ViewValue = $this->merchantnodeid->CurrentValue;
			$this->merchantnodeid->ViewCustomAttributes = "";

			// merchantid
			$this->merchantid->ViewValue = $this->merchantid->CurrentValue;
			$this->merchantid->ViewCustomAttributes = "";

			// merchantbusinessname
			$this->merchantbusinessname->ViewValue = $this->merchantbusinessname->CurrentValue;
			$this->merchantbusinessname->ViewCustomAttributes = "";

			// merchanttransferid
			$this->merchanttransferid->ViewValue = $this->merchanttransferid->CurrentValue;
			$this->merchanttransferid->ViewCustomAttributes = "";

			// merchantuserid
			$this->merchantuserid->ViewValue = $this->merchantuserid->CurrentValue;
			$this->merchantuserid->ViewCustomAttributes = "";

			// purchasedate
			$this->purchasedate->ViewValue = $this->purchasedate->CurrentValue;
			$this->purchasedate->ViewValue = FormatDateTime($this->purchasedate->ViewValue, 1);
			$this->purchasedate->ViewCustomAttributes = "";

			// txid
			$this->txid->ViewValue = $this->txid->CurrentValue;
			$this->txid->ViewCustomAttributes = "";

			// userpi
			$this->userpi->ViewValue = $this->userpi->CurrentValue;
			$curVal = strval($this->userpi->CurrentValue);
			if ($curVal != "") {
				$this->userpi->ViewValue = $this->userpi->lookupCacheOption($curVal);
				if ($this->userpi->ViewValue === NULL) { // Lookup from database
					$filterWrk = "`id`" . SearchString("=", $curVal, DATATYPE_NUMBER, "");
					$sqlWrk = $this->userpi->Lookup->getSql(FALSE, $filterWrk, '', $this);
					$rswrk = Conn()->execute($sqlWrk);
					if ($rswrk && !$rswrk->EOF) { // Lookup values found
						$arwrk = [];
						$arwrk[1] = $rswrk->fields('df');
						$arwrk[2] = $rswrk->fields('df2');
						$this->userpi->ViewValue = $this->userpi->displayValue($arwrk);
						$rswrk->Close();
					} else {
						$this->userpi->ViewValue = $this->userpi->CurrentValue;
					}
				}
			} else {
				$this->userpi->ViewValue = NULL;
			}
			$this->userpi->ViewCustomAttributes = "";

			// otherconfirmref
			$this->otherconfirmref->ViewValue = $this->otherconfirmref->CurrentValue;
			$this->otherconfirmref->ViewCustomAttributes = "";

			// currencycode
			$this->currencycode->ViewValue = $this->currencycode->CurrentValue;
			$this->currencycode->ViewCustomAttributes = "";

			// purchaseamount
			$this->purchaseamount->ViewValue = $this->purchaseamount->CurrentValue;
			$this->purchaseamount->ViewValue = FormatNumber($this->purchaseamount->ViewValue, 2, -2, -1, -1);
			$this->purchaseamount->CellCssStyle .= "text-align: right;";
			$this->purchaseamount->ViewCustomAttributes = "";

			// tipamount
			$this->tipamount->ViewValue = $this->tipamount->CurrentValue;
			$this->tipamount->ViewValue = FormatNumber($this->tipamount->ViewValue, Config("DEFAULT_DECIMAL_PRECISION"));
			$this->tipamount->ViewCustomAttributes = "";

			// merchantfees
			$this->merchantfees->ViewValue = $this->merchantfees->CurrentValue;
			$this->merchantfees->ViewValue = FormatNumber($this->merchantfees->ViewValue, Config("DEFAULT_DECIMAL_PRECISION"));
			$this->merchantfees->ViewCustomAttributes = "";

			// consumerfees
			$this->consumerfees->ViewValue = $this->consumerfees->CurrentValue;
			$this->consumerfees->ViewValue = FormatNumber($this->consumerfees->ViewValue, Config("DEFAULT_DECIMAL_PRECISION"));
			$this->consumerfees->ViewCustomAttributes = "";

			// transferid
			$this->transferid->ViewValue = $this->transferid->CurrentValue;
			$this->transferid->ViewCustomAttributes = "";

			// merchantSurcharge
			$this->merchantSurcharge->ViewValue = $this->merchantSurcharge->CurrentValue;
			$this->merchantSurcharge->ViewValue = FormatNumber($this->merchantSurcharge->ViewValue, Config("DEFAULT_DECIMAL_PRECISION"));
			$this->merchantSurcharge->ViewCustomAttributes = "";

			// taxAmount
			$this->taxAmount->ViewValue = $this->taxAmount->CurrentValue;
			$this->taxAmount->ViewValue = FormatNumber($this->taxAmount->ViewValue, Config("DEFAULT_DECIMAL_PRECISION"));
			$this->taxAmount->ViewCustomAttributes = "";

			// totalAmounForCustomer
			$this->totalAmounForCustomer->ViewValue = $this->totalAmounForCustomer->CurrentValue;
			$this->totalAmounForCustomer->ViewValue = FormatNumber($this->totalAmounForCustomer->ViewValue, Config("DEFAULT_DECIMAL_PRECISION"));
			$this->totalAmounForCustomer->ViewCustomAttributes = "";

			// feeid
			$this->feeid->ViewValue = $this->feeid->CurrentValue;
			$this->feeid->ViewCustomAttributes = "";

			// ratetabletype
			$this->ratetabletype->ViewValue = $this->ratetabletype->CurrentValue;
			$this->ratetabletype->ViewCustomAttributes = "";

			// itemdesc
			$this->itemdesc->ViewValue = $this->itemdesc->CurrentValue;
			$this->itemdesc->ViewCustomAttributes = "";

			// shoppingCartID
			$this->shoppingCartID->ViewValue = $this->shoppingCartID->CurrentValue;
			$this->shoppingCartID->ViewCustomAttributes = "";

			// merchantRefID
			$this->merchantRefID->ViewValue = $this->merchantRefID->CurrentValue;
			$this->merchantRefID->ViewCustomAttributes = "";

			// refunded
			if (strval($this->refunded->CurrentValue) != "") {
				$this->refunded->ViewValue = $this->refunded->optionCaption($this->refunded->CurrentValue);
			} else {
				$this->refunded->ViewValue = NULL;
			}
			$this->refunded->ViewCustomAttributes = "";

			// tokenid
			$this->tokenid->ViewValue = $this->tokenid->CurrentValue;
			$this->tokenid->ViewCustomAttributes = "";

			// cardno
			$this->cardno->ViewValue = $this->cardno->CurrentValue;
			$this->cardno->ViewCustomAttributes = "";

			// vaultid
			$this->vaultid->ViewValue = $this->vaultid->CurrentValue;
			$this->vaultid->ViewCustomAttributes = "";

			// refundrequested
			$this->refundrequested->ViewValue = $this->refundrequested->CurrentValue;
			$this->refundrequested->ViewCustomAttributes = "";

			// refundrequesttxid
			$this->refundrequesttxid->ViewValue = $this->refundrequesttxid->CurrentValue;
			$this->refundrequesttxid->ViewCustomAttributes = "";

			// feesystemshare
			$this->feesystemshare->ViewValue = $this->feesystemshare->CurrentValue;
			$this->feesystemshare->ViewValue = FormatNumber($this->feesystemshare->ViewValue, Config("DEFAULT_DECIMAL_PRECISION"));
			$this->feesystemshare->ViewCustomAttributes = "";

			// feeexternalshare
			$this->feeexternalshare->ViewValue = $this->feeexternalshare->CurrentValue;
			$this->feeexternalshare->ViewValue = FormatNumber($this->feeexternalshare->ViewValue, Config("DEFAULT_DECIMAL_PRECISION"));
			$this->feeexternalshare->ViewCustomAttributes = "";

			// feefranchiseeshare
			$this->feefranchiseeshare->ViewValue = $this->feefranchiseeshare->CurrentValue;
			$this->feefranchiseeshare->ViewValue = FormatNumber($this->feefranchiseeshare->ViewValue, Config("DEFAULT_DECIMAL_PRECISION"));
			$this->feefranchiseeshare->ViewCustomAttributes = "";

			// feeresellershare
			$this->feeresellershare->ViewValue = $this->feeresellershare->CurrentValue;
			$this->feeresellershare->ViewValue = FormatNumber($this->feeresellershare->ViewValue, Config("DEFAULT_DECIMAL_PRECISION"));
			$this->feeresellershare->ViewCustomAttributes = "";

			// serviceFeeToCustomerbk1amt
			$this->serviceFeeToCustomerbk1amt->ViewValue = $this->serviceFeeToCustomerbk1amt->CurrentValue;
			$this->serviceFeeToCustomerbk1amt->ViewValue = FormatNumber($this->serviceFeeToCustomerbk1amt->ViewValue, 2, -2, -2, -2);
			$this->serviceFeeToCustomerbk1amt->ViewCustomAttributes = "";

			// serviceFeeToCustomerbk1type
			$this->serviceFeeToCustomerbk1type->ViewValue = $this->serviceFeeToCustomerbk1type->CurrentValue;
			$this->serviceFeeToCustomerbk1type->ViewCustomAttributes = "";

			// serviceFeeToCustomerbk2amt
			$this->serviceFeeToCustomerbk2amt->ViewValue = $this->serviceFeeToCustomerbk2amt->CurrentValue;
			$this->serviceFeeToCustomerbk2amt->ViewValue = FormatNumber($this->serviceFeeToCustomerbk2amt->ViewValue, 2, -2, -2, -2);
			$this->serviceFeeToCustomerbk2amt->ViewCustomAttributes = "";

			// serviceFeeToCustomerbk2type
			$this->serviceFeeToCustomerbk2type->ViewValue = $this->serviceFeeToCustomerbk2type->CurrentValue;
			$this->serviceFeeToCustomerbk2type->ViewCustomAttributes = "";

			// serviceFeeToCustomerbk3amt
			$this->serviceFeeToCustomerbk3amt->ViewValue = $this->serviceFeeToCustomerbk3amt->CurrentValue;
			$this->serviceFeeToCustomerbk3amt->ViewValue = FormatNumber($this->serviceFeeToCustomerbk3amt->ViewValue, 2, -2, -2, -2);
			$this->serviceFeeToCustomerbk3amt->ViewCustomAttributes = "";

			// serviceFeeToCustomerbk3type
			$this->serviceFeeToCustomerbk3type->ViewValue = $this->serviceFeeToCustomerbk3type->CurrentValue;
			$this->serviceFeeToCustomerbk3type->ViewCustomAttributes = "";

			// taxAmountbk1amt
			$this->taxAmountbk1amt->ViewValue = $this->taxAmountbk1amt->CurrentValue;
			$this->taxAmountbk1amt->ViewValue = FormatNumber($this->taxAmountbk1amt->ViewValue, 2, -2, -2, -2);
			$this->taxAmountbk1amt->ViewCustomAttributes = "";

			// taxAmountbk1type
			$this->taxAmountbk1type->ViewValue = $this->taxAmountbk1type->CurrentValue;
			$this->taxAmountbk1type->ViewCustomAttributes = "";

			// taxAmountbk2amt
			$this->taxAmountbk2amt->ViewValue = $this->taxAmountbk2amt->CurrentValue;
			$this->taxAmountbk2amt->ViewValue = FormatNumber($this->taxAmountbk2amt->ViewValue, 2, -2, -2, -2);
			$this->taxAmountbk2amt->ViewCustomAttributes = "";

			// taxAmountbk2type
			$this->taxAmountbk2type->ViewValue = $this->taxAmountbk2type->CurrentValue;
			$this->taxAmountbk2type->ViewCustomAttributes = "";

			// taxAmountbk3amt
			$this->taxAmountbk3amt->ViewValue = $this->taxAmountbk3amt->CurrentValue;
			$this->taxAmountbk3amt->ViewValue = FormatNumber($this->taxAmountbk3amt->ViewValue, 2, -2, -2, -2);
			$this->taxAmountbk3amt->ViewCustomAttributes = "";

			// taxAmountbk3type
			$this->taxAmountbk3type->ViewValue = $this->taxAmountbk3type->CurrentValue;
			$this->taxAmountbk3type->ViewCustomAttributes = "";

			// originalpurchaseamount
			$this->originalpurchaseamount->ViewValue = $this->originalpurchaseamount->CurrentValue;
			$this->originalpurchaseamount->ViewValue = FormatNumber($this->originalpurchaseamount->ViewValue, 2, -2, -2, -2);
			$this->originalpurchaseamount->ViewCustomAttributes = "";

			// discountamount
			$this->discountamount->ViewValue = $this->discountamount->CurrentValue;
			$this->discountamount->ViewValue = FormatNumber($this->discountamount->ViewValue, 2, -2, -2, -2);
			$this->discountamount->ViewCustomAttributes = "";

			// discountpercentage
			$this->discountpercentage->ViewValue = $this->discountpercentage->CurrentValue;
			$this->discountpercentage->ViewValue = FormatNumber($this->discountpercentage->ViewValue, 0, -2, -2, -2);
			$this->discountpercentage->ViewCustomAttributes = "";

			// txgroupid
			$this->txgroupid->ViewValue = $this->txgroupid->CurrentValue;
			$this->txgroupid->ViewValue = FormatNumber($this->txgroupid->ViewValue, 0, -2, -2, -2);
			$this->txgroupid->ViewCustomAttributes = "";

			// success_status
			if (strval($this->success_status->CurrentValue) != "") {
				$this->success_status->ViewValue = $this->success_status->optionCaption($this->success_status->CurrentValue);
			} else {
				$this->success_status->ViewValue = NULL;
			}
			$this->success_status->ViewCustomAttributes = "";

			// error_msg
			$this->error_msg->ViewValue = $this->error_msg->CurrentValue;
			$this->error_msg->ViewCustomAttributes = "";

			// userpiid
			$this->userpiid->ViewValue = $this->userpiid->CurrentValue;
			$this->userpiid->ViewValue = FormatNumber($this->userpiid->ViewValue, 0, -2, -2, -2);
			$this->userpiid->ViewCustomAttributes = "";

			// notes
			$this->notes->ViewValue = $this->notes->CurrentValue;
			$this->notes->ViewCustomAttributes = "";

			// lastpurchasereaddate
			$this->lastpurchasereaddate->ViewValue = $this->lastpurchasereaddate->CurrentValue;
			$this->lastpurchasereaddate->ViewValue = FormatDateTime($this->lastpurchasereaddate->ViewValue, 0);
			$this->lastpurchasereaddate->ViewCustomAttributes = "";

			// retryapicount
			$this->retryapicount->ViewValue = $this->retryapicount->CurrentValue;
			$this->retryapicount->ViewValue = FormatNumber($this->retryapicount->ViewValue, 0, -2, -2, -2);
			$this->retryapicount->ViewCustomAttributes = "";

			// purchaseid
			$this->purchaseid->LinkCustomAttributes = "";
			if (!EmptyValue($this->purchaseid->CurrentValue)) {
				$this->purchaseid->HrefValue = "userpurchaseview.php?showdetail=&purchaseid=" . $this->purchaseid->CurrentValue; // Add prefix/suffix
				$this->purchaseid->LinkAttrs["target"] = ""; // Add target
				if ($this->isExport())
					$this->purchaseid->HrefValue = FullUrl($this->purchaseid->HrefValue, "href");
			} else {
				$this->purchaseid->HrefValue = "";
			}
			$this->purchaseid->TooltipValue = "";
			if (!$this->isExport())
				$this->purchaseid->ViewValue = $this->highlightValue($this->purchaseid);

			// userid
			$this->_userid->LinkCustomAttributes = "";
			if (!EmptyValue($this->_userid->CurrentValue)) {
				$this->_userid->HrefValue = "userview.php?showdetail=&id=" . $this->_userid->CurrentValue; // Add prefix/suffix
				$this->_userid->LinkAttrs["target"] = ""; // Add target
				if ($this->isExport())
					$this->_userid->HrefValue = FullUrl($this->_userid->HrefValue, "href");
			} else {
				$this->_userid->HrefValue = "";
			}
			$this->_userid->TooltipValue = "";
			if (!$this->isExport())
				$this->_userid->ViewValue = $this->highlightValue($this->_userid);

			// merchantid
			$this->merchantid->LinkCustomAttributes = "";
			$this->merchantid->HrefValue = "";
			$this->merchantid->TooltipValue = "";
			if (!$this->isExport())
				$this->merchantid->ViewValue = $this->highlightValue($this->merchantid);

			// merchanttransferid
			$this->merchanttransferid->LinkCustomAttributes = "";
			$this->merchanttransferid->HrefValue = "";
			$this->merchanttransferid->TooltipValue = "";
			if (!$this->isExport())
				$this->merchanttransferid->ViewValue = $this->highlightValue($this->merchanttransferid);

			// purchasedate
			$this->purchasedate->LinkCustomAttributes = "";
			$this->purchasedate->HrefValue = "";
			$this->purchasedate->TooltipValue = "";

			// txid
			$this->txid->LinkCustomAttributes = "";
			$this->txid->HrefValue = "";
			$this->txid->TooltipValue = "";
			if (!$this->isExport())
				$this->txid->ViewValue = $this->highlightValue($this->txid);

			// userpi
			$this->userpi->LinkCustomAttributes = "";
			$this->userpi->HrefValue = "";
			$this->userpi->TooltipValue = "";
			if (!$this->isExport())
				$this->userpi->ViewValue = $this->highlightValue($this->userpi);

			// currencycode
			$this->currencycode->LinkCustomAttributes = "";
			$this->currencycode->HrefValue = "";
			$this->currencycode->TooltipValue = "";
			if (!$this->isExport())
				$this->currencycode->ViewValue = $this->highlightValue($this->currencycode);

			// purchaseamount
			$this->purchaseamount->LinkCustomAttributes = "";
			$this->purchaseamount->HrefValue = "";
			$this->purchaseamount->TooltipValue = "";

			// success_status
			$this->success_status->LinkCustomAttributes = "";
			$this->success_status->HrefValue = "";
			$this->success_status->TooltipValue = "";

			// userpiid
			$this->userpiid->LinkCustomAttributes = "";
			$this->userpiid->HrefValue = "";
			$this->userpiid->TooltipValue = "";
		} elseif ($this->RowType == ROWTYPE_ADD) { // Add row

			// purchaseid
			// userid

			$this->_userid->EditAttrs["class"] = "form-control";
			$this->_userid->EditCustomAttributes = "";
			if ($this->_userid->getSessionValue() != "") {
				$this->_userid->CurrentValue = $this->_userid->getSessionValue();
				$this->_userid->OldValue = $this->_userid->CurrentValue;
				$this->_userid->ViewValue = $this->_userid->CurrentValue;
				$this->_userid->ViewCustomAttributes = "";
			} else {
				$this->_userid->EditValue = HtmlEncode($this->_userid->CurrentValue);
				$this->_userid->PlaceHolder = RemoveHtml($this->_userid->caption());
			}

			// merchantid
			$this->merchantid->EditAttrs["class"] = "form-control";
			$this->merchantid->EditCustomAttributes = "";
			$this->merchantid->EditValue = HtmlEncode($this->merchantid->CurrentValue);
			$this->merchantid->PlaceHolder = RemoveHtml($this->merchantid->caption());

			// merchanttransferid
			$this->merchanttransferid->EditAttrs["class"] = "form-control";
			$this->merchanttransferid->EditCustomAttributes = "";
			$this->merchanttransferid->EditValue = HtmlEncode($this->merchanttransferid->CurrentValue);
			$this->merchanttransferid->PlaceHolder = RemoveHtml($this->merchanttransferid->caption());

			// purchasedate
			$this->purchasedate->EditAttrs["class"] = "form-control";
			$this->purchasedate->EditCustomAttributes = "";
			$this->purchasedate->EditValue = HtmlEncode(FormatDateTime($this->purchasedate->CurrentValue, 8));
			$this->purchasedate->PlaceHolder = RemoveHtml($this->purchasedate->caption());

			// txid
			$this->txid->EditAttrs["class"] = "form-control";
			$this->txid->EditCustomAttributes = "";
			if (!$this->txid->Raw)
				$this->txid->CurrentValue = HtmlDecode($this->txid->CurrentValue);
			$this->txid->EditValue = HtmlEncode($this->txid->CurrentValue);
			$this->txid->PlaceHolder = RemoveHtml($this->txid->caption());

			// userpi
			$this->userpi->EditAttrs["class"] = "form-control";
			$this->userpi->EditCustomAttributes = "";
			$this->userpi->EditValue = HtmlEncode($this->userpi->CurrentValue);
			$curVal = strval($this->userpi->CurrentValue);
			if ($curVal != "") {
				$this->userpi->EditValue = $this->userpi->lookupCacheOption($curVal);
				if ($this->userpi->EditValue === NULL) { // Lookup from database
					$filterWrk = "`id`" . SearchString("=", $curVal, DATATYPE_NUMBER, "");
					$sqlWrk = $this->userpi->Lookup->getSql(FALSE, $filterWrk, '', $this);
					$rswrk = Conn()->execute($sqlWrk);
					if ($rswrk && !$rswrk->EOF) { // Lookup values found
						$arwrk = [];
						$arwrk[1] = HtmlEncode($rswrk->fields('df'));
						$arwrk[2] = HtmlEncode($rswrk->fields('df2'));
						$this->userpi->EditValue = $this->userpi->displayValue($arwrk);
						$rswrk->Close();
					} else {
						$this->userpi->EditValue = HtmlEncode($this->userpi->CurrentValue);
					}
				}
			} else {
				$this->userpi->EditValue = NULL;
			}
			$this->userpi->PlaceHolder = RemoveHtml($this->userpi->caption());

			// currencycode
			$this->currencycode->EditAttrs["class"] = "form-control";
			$this->currencycode->EditCustomAttributes = "";
			if (!$this->currencycode->Raw)
				$this->currencycode->CurrentValue = HtmlDecode($this->currencycode->CurrentValue);
			$this->currencycode->EditValue = HtmlEncode($this->currencycode->CurrentValue);
			$this->currencycode->PlaceHolder = RemoveHtml($this->currencycode->caption());

			// purchaseamount
			$this->purchaseamount->EditAttrs["class"] = "form-control";
			$this->purchaseamount->EditCustomAttributes = "";
			$this->purchaseamount->EditValue = HtmlEncode($this->purchaseamount->CurrentValue);
			$this->purchaseamount->PlaceHolder = RemoveHtml($this->purchaseamount->caption());
			if (strval($this->purchaseamount->EditValue) != "" && is_numeric($this->purchaseamount->EditValue)) {
				$this->purchaseamount->EditValue = FormatNumber($this->purchaseamount->EditValue, -2, -2, -2, -1);
				$this->purchaseamount->OldValue = $this->purchaseamount->EditValue;
			}
			

			// success_status
			$this->success_status->EditAttrs["class"] = "form-control";
			$this->success_status->EditCustomAttributes = "";
			$this->success_status->EditValue = $this->success_status->options(TRUE);

			// userpiid
			$this->userpiid->EditAttrs["class"] = "form-control";
			$this->userpiid->EditCustomAttributes = "";
			$this->userpiid->EditValue = HtmlEncode($this->userpiid->CurrentValue);
			$this->userpiid->PlaceHolder = RemoveHtml($this->userpiid->caption());

			// Add refer script
			// purchaseid

			$this->purchaseid->LinkCustomAttributes = "";
			if (!EmptyValue($this->purchaseid->CurrentValue)) {
				$this->purchaseid->HrefValue = "userpurchaseview.php?showdetail=&purchaseid=" . $this->purchaseid->CurrentValue; // Add prefix/suffix
				$this->purchaseid->LinkAttrs["target"] = ""; // Add target
				if ($this->isExport())
					$this->purchaseid->HrefValue = FullUrl($this->purchaseid->HrefValue, "href");
			} else {
				$this->purchaseid->HrefValue = "";
			}

			// userid
			$this->_userid->LinkCustomAttributes = "";
			if (!EmptyValue($this->_userid->CurrentValue)) {
				$this->_userid->HrefValue = "userview.php?showdetail=&id=" . $this->_userid->CurrentValue; // Add prefix/suffix
				$this->_userid->LinkAttrs["target"] = ""; // Add target
				if ($this->isExport())
					$this->_userid->HrefValue = FullUrl($this->_userid->HrefValue, "href");
			} else {
				$this->_userid->HrefValue = "";
			}

			// merchantid
			$this->merchantid->LinkCustomAttributes = "";
			$this->merchantid->HrefValue = "";

			// merchanttransferid
			$this->merchanttransferid->LinkCustomAttributes = "";
			$this->merchanttransferid->HrefValue = "";

			// purchasedate
			$this->purchasedate->LinkCustomAttributes = "";
			$this->purchasedate->HrefValue = "";

			// txid
			$this->txid->LinkCustomAttributes = "";
			$this->txid->HrefValue = "";

			// userpi
			$this->userpi->LinkCustomAttributes = "";
			$this->userpi->HrefValue = "";

			// currencycode
			$this->currencycode->LinkCustomAttributes = "";
			$this->currencycode->HrefValue = "";

			// purchaseamount
			$this->purchaseamount->LinkCustomAttributes = "";
			$this->purchaseamount->HrefValue = "";

			// success_status
			$this->success_status->LinkCustomAttributes = "";
			$this->success_status->HrefValue = "";

			// userpiid
			$this->userpiid->LinkCustomAttributes = "";
			$this->userpiid->HrefValue = "";
		} elseif ($this->RowType == ROWTYPE_EDIT) { // Edit row

			// purchaseid
			$this->purchaseid->EditAttrs["class"] = "form-control";
			$this->purchaseid->EditCustomAttributes = "";
			$this->purchaseid->EditValue = $this->purchaseid->CurrentValue;
			$this->purchaseid->ViewCustomAttributes = "";

			// userid
			$this->_userid->EditAttrs["class"] = "form-control";
			$this->_userid->EditCustomAttributes = "";
			if ($this->_userid->getSessionValue() != "") {
				$this->_userid->CurrentValue = $this->_userid->getSessionValue();
				$this->_userid->OldValue = $this->_userid->CurrentValue;
				$this->_userid->ViewValue = $this->_userid->CurrentValue;
				$this->_userid->ViewCustomAttributes = "";
			} else {
				$this->_userid->EditValue = HtmlEncode($this->_userid->CurrentValue);
				$this->_userid->PlaceHolder = RemoveHtml($this->_userid->caption());
			}

			// merchantid
			$this->merchantid->EditAttrs["class"] = "form-control";
			$this->merchantid->EditCustomAttributes = "";
			$this->merchantid->EditValue = HtmlEncode($this->merchantid->CurrentValue);
			$this->merchantid->PlaceHolder = RemoveHtml($this->merchantid->caption());

			// merchanttransferid
			$this->merchanttransferid->EditAttrs["class"] = "form-control";
			$this->merchanttransferid->EditCustomAttributes = "";
			$this->merchanttransferid->EditValue = HtmlEncode($this->merchanttransferid->CurrentValue);
			$this->merchanttransferid->PlaceHolder = RemoveHtml($this->merchanttransferid->caption());

			// purchasedate
			$this->purchasedate->EditAttrs["class"] = "form-control";
			$this->purchasedate->EditCustomAttributes = "";
			$this->purchasedate->EditValue = HtmlEncode(FormatDateTime($this->purchasedate->CurrentValue, 8));
			$this->purchasedate->PlaceHolder = RemoveHtml($this->purchasedate->caption());

			// txid
			$this->txid->EditAttrs["class"] = "form-control";
			$this->txid->EditCustomAttributes = "";
			if (!$this->txid->Raw)
				$this->txid->CurrentValue = HtmlDecode($this->txid->CurrentValue);
			$this->txid->EditValue = HtmlEncode($this->txid->CurrentValue);
			$this->txid->PlaceHolder = RemoveHtml($this->txid->caption());

			// userpi
			$this->userpi->EditAttrs["class"] = "form-control";
			$this->userpi->EditCustomAttributes = "";
			$this->userpi->EditValue = HtmlEncode($this->userpi->CurrentValue);
			$curVal = strval($this->userpi->CurrentValue);
			if ($curVal != "") {
				$this->userpi->EditValue = $this->userpi->lookupCacheOption($curVal);
				if ($this->userpi->EditValue === NULL) { // Lookup from database
					$filterWrk = "`id`" . SearchString("=", $curVal, DATATYPE_NUMBER, "");
					$sqlWrk = $this->userpi->Lookup->getSql(FALSE, $filterWrk, '', $this);
					$rswrk = Conn()->execute($sqlWrk);
					if ($rswrk && !$rswrk->EOF) { // Lookup values found
						$arwrk = [];
						$arwrk[1] = HtmlEncode($rswrk->fields('df'));
						$arwrk[2] = HtmlEncode($rswrk->fields('df2'));
						$this->userpi->EditValue = $this->userpi->displayValue($arwrk);
						$rswrk->Close();
					} else {
						$this->userpi->EditValue = HtmlEncode($this->userpi->CurrentValue);
					}
				}
			} else {
				$this->userpi->EditValue = NULL;
			}
			$this->userpi->PlaceHolder = RemoveHtml($this->userpi->caption());

			// currencycode
			$this->currencycode->EditAttrs["class"] = "form-control";
			$this->currencycode->EditCustomAttributes = "";
			if (!$this->currencycode->Raw)
				$this->currencycode->CurrentValue = HtmlDecode($this->currencycode->CurrentValue);
			$this->currencycode->EditValue = HtmlEncode($this->currencycode->CurrentValue);
			$this->currencycode->PlaceHolder = RemoveHtml($this->currencycode->caption());

			// purchaseamount
			$this->purchaseamount->EditAttrs["class"] = "form-control";
			$this->purchaseamount->EditCustomAttributes = "";
			$this->purchaseamount->EditValue = HtmlEncode($this->purchaseamount->CurrentValue);
			$this->purchaseamount->PlaceHolder = RemoveHtml($this->purchaseamount->caption());
			if (strval($this->purchaseamount->EditValue) != "" && is_numeric($this->purchaseamount->EditValue)) {
				$this->purchaseamount->EditValue = FormatNumber($this->purchaseamount->EditValue, -2, -2, -2, -1);
				$this->purchaseamount->OldValue = $this->purchaseamount->EditValue;
			}
			

			// success_status
			$this->success_status->EditAttrs["class"] = "form-control";
			$this->success_status->EditCustomAttributes = "";
			$this->success_status->EditValue = $this->success_status->options(TRUE);

			// userpiid
			$this->userpiid->EditAttrs["class"] = "form-control";
			$this->userpiid->EditCustomAttributes = "";
			$this->userpiid->EditValue = HtmlEncode($this->userpiid->CurrentValue);
			$this->userpiid->PlaceHolder = RemoveHtml($this->userpiid->caption());

			// Edit refer script
			// purchaseid

			$this->purchaseid->LinkCustomAttributes = "";
			if (!EmptyValue($this->purchaseid->CurrentValue)) {
				$this->purchaseid->HrefValue = "userpurchaseview.php?showdetail=&purchaseid=" . $this->purchaseid->CurrentValue; // Add prefix/suffix
				$this->purchaseid->LinkAttrs["target"] = ""; // Add target
				if ($this->isExport())
					$this->purchaseid->HrefValue = FullUrl($this->purchaseid->HrefValue, "href");
			} else {
				$this->purchaseid->HrefValue = "";
			}

			// userid
			$this->_userid->LinkCustomAttributes = "";
			if (!EmptyValue($this->_userid->CurrentValue)) {
				$this->_userid->HrefValue = "userview.php?showdetail=&id=" . $this->_userid->CurrentValue; // Add prefix/suffix
				$this->_userid->LinkAttrs["target"] = ""; // Add target
				if ($this->isExport())
					$this->_userid->HrefValue = FullUrl($this->_userid->HrefValue, "href");
			} else {
				$this->_userid->HrefValue = "";
			}

			// merchantid
			$this->merchantid->LinkCustomAttributes = "";
			$this->merchantid->HrefValue = "";

			// merchanttransferid
			$this->merchanttransferid->LinkCustomAttributes = "";
			$this->merchanttransferid->HrefValue = "";

			// purchasedate
			$this->purchasedate->LinkCustomAttributes = "";
			$this->purchasedate->HrefValue = "";

			// txid
			$this->txid->LinkCustomAttributes = "";
			$this->txid->HrefValue = "";

			// userpi
			$this->userpi->LinkCustomAttributes = "";
			$this->userpi->HrefValue = "";

			// currencycode
			$this->currencycode->LinkCustomAttributes = "";
			$this->currencycode->HrefValue = "";

			// purchaseamount
			$this->purchaseamount->LinkCustomAttributes = "";
			$this->purchaseamount->HrefValue = "";

			// success_status
			$this->success_status->LinkCustomAttributes = "";
			$this->success_status->HrefValue = "";

			// userpiid
			$this->userpiid->LinkCustomAttributes = "";
			$this->userpiid->HrefValue = "";
		}
		if ($this->RowType == ROWTYPE_ADD || $this->RowType == ROWTYPE_EDIT || $this->RowType == ROWTYPE_SEARCH) // Add/Edit/Search row
			$this->setupFieldTitles();

		// Call Row Rendered event
		if ($this->RowType != ROWTYPE_AGGREGATEINIT)
			$this->Row_Rendered();
	}

	// Validate form
	protected function validateForm()
	{
		global $Language, $FormError;

		// Check if validation required
		if (!Config("SERVER_VALIDATE"))
			return ($FormError == "");
		if ($this->purchaseid->Required) {
			if (!$this->purchaseid->IsDetailKey && $this->purchaseid->FormValue != NULL && $this->purchaseid->FormValue == "") {
				AddMessage($FormError, str_replace("%s", $this->purchaseid->caption(), $this->purchaseid->RequiredErrorMessage));
			}
		}
		if ($this->_userid->Required) {
			if (!$this->_userid->IsDetailKey && $this->_userid->FormValue != NULL && $this->_userid->FormValue == "") {
				AddMessage($FormError, str_replace("%s", $this->_userid->caption(), $this->_userid->RequiredErrorMessage));
			}
		}
		if (!CheckInteger($this->_userid->FormValue)) {
			AddMessage($FormError, $this->_userid->errorMessage());
		}
		if ($this->merchantid->Required) {
			if (!$this->merchantid->IsDetailKey && $this->merchantid->FormValue != NULL && $this->merchantid->FormValue == "") {
				AddMessage($FormError, str_replace("%s", $this->merchantid->caption(), $this->merchantid->RequiredErrorMessage));
			}
		}
		if (!CheckInteger($this->merchantid->FormValue)) {
			AddMessage($FormError, $this->merchantid->errorMessage());
		}
		if ($this->merchanttransferid->Required) {
			if (!$this->merchanttransferid->IsDetailKey && $this->merchanttransferid->FormValue != NULL && $this->merchanttransferid->FormValue == "") {
				AddMessage($FormError, str_replace("%s", $this->merchanttransferid->caption(), $this->merchanttransferid->RequiredErrorMessage));
			}
		}
		if (!CheckInteger($this->merchanttransferid->FormValue)) {
			AddMessage($FormError, $this->merchanttransferid->errorMessage());
		}
		if ($this->purchasedate->Required) {
			if (!$this->purchasedate->IsDetailKey && $this->purchasedate->FormValue != NULL && $this->purchasedate->FormValue == "") {
				AddMessage($FormError, str_replace("%s", $this->purchasedate->caption(), $this->purchasedate->RequiredErrorMessage));
			}
		}
		if (!CheckDate($this->purchasedate->FormValue)) {
			AddMessage($FormError, $this->purchasedate->errorMessage());
		}
		if ($this->txid->Required) {
			if (!$this->txid->IsDetailKey && $this->txid->FormValue != NULL && $this->txid->FormValue == "") {
				AddMessage($FormError, str_replace("%s", $this->txid->caption(), $this->txid->RequiredErrorMessage));
			}
		}
		if ($this->userpi->Required) {
			if (!$this->userpi->IsDetailKey && $this->userpi->FormValue != NULL && $this->userpi->FormValue == "") {
				AddMessage($FormError, str_replace("%s", $this->userpi->caption(), $this->userpi->RequiredErrorMessage));
			}
		}
		if (!CheckInteger($this->userpi->FormValue)) {
			AddMessage($FormError, $this->userpi->errorMessage());
		}
		if ($this->currencycode->Required) {
			if (!$this->currencycode->IsDetailKey && $this->currencycode->FormValue != NULL && $this->currencycode->FormValue == "") {
				AddMessage($FormError, str_replace("%s", $this->currencycode->caption(), $this->currencycode->RequiredErrorMessage));
			}
		}
		if ($this->purchaseamount->Required) {
			if (!$this->purchaseamount->IsDetailKey && $this->purchaseamount->FormValue != NULL && $this->purchaseamount->FormValue == "") {
				AddMessage($FormError, str_replace("%s", $this->purchaseamount->caption(), $this->purchaseamount->RequiredErrorMessage));
			}
		}
		if (!CheckNumber($this->purchaseamount->FormValue)) {
			AddMessage($FormError, $this->purchaseamount->errorMessage());
		}
		if ($this->success_status->Required) {
			if (!$this->success_status->IsDetailKey && $this->success_status->FormValue != NULL && $this->success_status->FormValue == "") {
				AddMessage($FormError, str_replace("%s", $this->success_status->caption(), $this->success_status->RequiredErrorMessage));
			}
		}
		if ($this->userpiid->Required) {
			if (!$this->userpiid->IsDetailKey && $this->userpiid->FormValue != NULL && $this->userpiid->FormValue == "") {
				AddMessage($FormError, str_replace("%s", $this->userpiid->caption(), $this->userpiid->RequiredErrorMessage));
			}
		}
		if (!CheckInteger($this->userpiid->FormValue)) {
			AddMessage($FormError, $this->userpiid->errorMessage());
		}

		// Return validate result
		$validateForm = ($FormError == "");

		// Call Form_CustomValidate event
		$formCustomError = "";
		$validateForm = $validateForm && $this->Form_CustomValidate($formCustomError);
		if ($formCustomError != "") {
			AddMessage($FormError, $formCustomError);
		}
		return $validateForm;
	}

	// Delete records based on current filter
	protected function deleteRows()
	{
		global $Language, $Security;
		if (!$Security->canDelete()) {
			$this->setFailureMessage($Language->phrase("NoDeletePermission")); // No delete permission
			return FALSE;
		}
		$deleteRows = TRUE;
		$sql = $this->getCurrentSql();
		$conn = $this->getConnection();
		$conn->raiseErrorFn = Config("ERROR_FUNC");
		$rs = $conn->execute($sql);
		$conn->raiseErrorFn = "";
		if ($rs === FALSE) {
			return FALSE;
		} elseif ($rs->EOF) {
			$this->setFailureMessage($Language->phrase("NoRecord")); // No record found
			$rs->close();
			return FALSE;
		}
		$rows = ($rs) ? $rs->getRows() : [];
		if ($this->AuditTrailOnDelete)
			$this->writeAuditTrailDummy($Language->phrase("BatchDeleteBegin")); // Batch delete begin

		// Clone old rows
		$rsold = $rows;
		if ($rs)
			$rs->close();

		// Call row deleting event
		if ($deleteRows) {
			foreach ($rsold as $row) {
				$deleteRows = $this->Row_Deleting($row);
				if (!$deleteRows)
					break;
			}
		}
		if ($deleteRows) {
			$key = "";
			foreach ($rsold as $row) {
				$thisKey = "";
				if ($thisKey != "")
					$thisKey .= Config("COMPOSITE_KEY_SEPARATOR");
				$thisKey .= $row['purchaseid'];
				if (Config("DELETE_UPLOADED_FILES")) // Delete old files
					$this->deleteUploadedFiles($row);
				$conn->raiseErrorFn = Config("ERROR_FUNC");
				$deleteRows = $this->delete($row); // Delete
				$conn->raiseErrorFn = "";
				if ($deleteRows === FALSE)
					break;
				if ($key != "")
					$key .= ", ";
				$key .= $thisKey;
			}
		}
		if (!$deleteRows) {

			// Set up error message
			if ($this->getSuccessMessage() != "" || $this->getFailureMessage() != "") {

				// Use the message, do nothing
			} elseif ($this->CancelMessage != "") {
				$this->setFailureMessage($this->CancelMessage);
				$this->CancelMessage = "";
			} else {
				$this->setFailureMessage($Language->phrase("DeleteCancelled"));
			}
		}

		// Call Row Deleted event
		if ($deleteRows) {
			foreach ($rsold as $row) {
				$this->Row_Deleted($row);
			}
		}

		// Write JSON for API request (Support single row only)
		if (IsApi() && $deleteRows) {
			$row = $this->getRecordsFromRecordset($rsold, TRUE);
			WriteJson(["success" => TRUE, $this->TableVar => $row]);
		}
		return $deleteRows;
	}

	// Update record based on key values
	protected function editRow()
	{
		global $Security, $Language;
		$oldKeyFilter = $this->getRecordFilter();
		$filter = $this->applyUserIDFilters($oldKeyFilter);
		$conn = $this->getConnection();
		$this->CurrentFilter = $filter;
		$sql = $this->getCurrentSql();
		$conn->raiseErrorFn = Config("ERROR_FUNC");
		$rs = $conn->execute($sql);
		$conn->raiseErrorFn = "";
		if ($rs === FALSE)
			return FALSE;
		if ($rs->EOF) {
			$this->setFailureMessage($Language->phrase("NoRecord")); // Set no record message
			$editRow = FALSE; // Update Failed
		} else {

			// Save old values
			$rsold = &$rs->fields;
			$this->loadDbValues($rsold);
			$rsnew = [];

			// userid
			$this->_userid->setDbValueDef($rsnew, $this->_userid->CurrentValue, 0, $this->_userid->ReadOnly);

			// merchantid
			$this->merchantid->setDbValueDef($rsnew, $this->merchantid->CurrentValue, 0, $this->merchantid->ReadOnly);

			// merchanttransferid
			$this->merchanttransferid->setDbValueDef($rsnew, $this->merchanttransferid->CurrentValue, 0, $this->merchanttransferid->ReadOnly);

			// purchasedate
			$this->purchasedate->setDbValueDef($rsnew, UnFormatDateTime($this->purchasedate->CurrentValue, 1), NULL, $this->purchasedate->ReadOnly);

			// txid
			$this->txid->setDbValueDef($rsnew, $this->txid->CurrentValue, "", $this->txid->ReadOnly);

			// userpi
			$this->userpi->setDbValueDef($rsnew, $this->userpi->CurrentValue, 0, $this->userpi->ReadOnly);

			// currencycode
			$this->currencycode->setDbValueDef($rsnew, $this->currencycode->CurrentValue, NULL, $this->currencycode->ReadOnly);

			// purchaseamount
			$this->purchaseamount->setDbValueDef($rsnew, $this->purchaseamount->CurrentValue, 0, $this->purchaseamount->ReadOnly);

			// success_status
			$this->success_status->setDbValueDef($rsnew, $this->success_status->CurrentValue, 0, $this->success_status->ReadOnly);

			// userpiid
			$this->userpiid->setDbValueDef($rsnew, $this->userpiid->CurrentValue, NULL, $this->userpiid->ReadOnly);

			// Call Row Updating event
			$updateRow = $this->Row_Updating($rsold, $rsnew);

			// Check for duplicate key when key changed
			if ($updateRow) {
				$newKeyFilter = $this->getRecordFilter($rsnew);
				if ($newKeyFilter != $oldKeyFilter) {
					$rsChk = $this->loadRs($newKeyFilter);
					if ($rsChk && !$rsChk->EOF) {
						$keyErrMsg = str_replace("%f", $newKeyFilter, $Language->phrase("DupKey"));
						$this->setFailureMessage($keyErrMsg);
						$rsChk->close();
						$updateRow = FALSE;
					}
				}
			}
			if ($updateRow) {
				$conn->raiseErrorFn = Config("ERROR_FUNC");
				if (count($rsnew) > 0)
					$editRow = $this->update($rsnew, "", $rsold);
				else
					$editRow = TRUE; // No field to update
				$conn->raiseErrorFn = "";
				if ($editRow) {
				}
			} else {
				if ($this->getSuccessMessage() != "" || $this->getFailureMessage() != "") {

					// Use the message, do nothing
				} elseif ($this->CancelMessage != "") {
					$this->setFailureMessage($this->CancelMessage);
					$this->CancelMessage = "";
				} else {
					$this->setFailureMessage($Language->phrase("UpdateCancelled"));
				}
				$editRow = FALSE;
			}
		}

		// Call Row_Updated event
		if ($editRow)
			$this->Row_Updated($rsold, $rsnew);
		$rs->close();

		// Clean upload path if any
		if ($editRow) {
		}

		// Write JSON for API request
		if (IsApi() && $editRow) {
			$row = $this->getRecordsFromRecordset([$rsnew], TRUE);
			WriteJson(["success" => TRUE, $this->TableVar => $row]);
		}
		return $editRow;
	}

	// Add record
	protected function addRow($rsold = NULL)
	{
		global $Language, $Security;

		// Set up foreign key field value from Session
			if ($this->getCurrentMasterTable() == "user") {
				$this->_userid->CurrentValue = $this->_userid->getSessionValue();
			}
		$conn = $this->getConnection();

		// Load db values from rsold
		$this->loadDbValues($rsold);
		if ($rsold) {
		}
		$rsnew = [];

		// userid
		$this->_userid->setDbValueDef($rsnew, $this->_userid->CurrentValue, 0, FALSE);

		// merchantid
		$this->merchantid->setDbValueDef($rsnew, $this->merchantid->CurrentValue, 0, FALSE);

		// merchanttransferid
		$this->merchanttransferid->setDbValueDef($rsnew, $this->merchanttransferid->CurrentValue, 0, FALSE);

		// purchasedate
		$this->purchasedate->setDbValueDef($rsnew, UnFormatDateTime($this->purchasedate->CurrentValue, 1), NULL, FALSE);

		// txid
		$this->txid->setDbValueDef($rsnew, $this->txid->CurrentValue, "", FALSE);

		// userpi
		$this->userpi->setDbValueDef($rsnew, $this->userpi->CurrentValue, 0, FALSE);

		// currencycode
		$this->currencycode->setDbValueDef($rsnew, $this->currencycode->CurrentValue, NULL, FALSE);

		// purchaseamount
		$this->purchaseamount->setDbValueDef($rsnew, $this->purchaseamount->CurrentValue, 0, strval($this->purchaseamount->CurrentValue) == "");

		// success_status
		$this->success_status->setDbValueDef($rsnew, $this->success_status->CurrentValue, 0, strval($this->success_status->CurrentValue) == "");

		// userpiid
		$this->userpiid->setDbValueDef($rsnew, $this->userpiid->CurrentValue, NULL, FALSE);

		// Call Row Inserting event
		$rs = ($rsold) ? $rsold->fields : NULL;
		$insertRow = $this->Row_Inserting($rs, $rsnew);
		if ($insertRow) {
			$conn->raiseErrorFn = Config("ERROR_FUNC");
			$addRow = $this->insert($rsnew);
			$conn->raiseErrorFn = "";
			if ($addRow) {
			}
		} else {
			if ($this->getSuccessMessage() != "" || $this->getFailureMessage() != "") {

				// Use the message, do nothing
			} elseif ($this->CancelMessage != "") {
				$this->setFailureMessage($this->CancelMessage);
				$this->CancelMessage = "";
			} else {
				$this->setFailureMessage($Language->phrase("InsertCancelled"));
			}
			$addRow = FALSE;
		}
		if ($addRow) {

			// Call Row Inserted event
			$rs = ($rsold) ? $rsold->fields : NULL;
			$this->Row_Inserted($rs, $rsnew);
		}

		// Clean upload path if any
		if ($addRow) {
		}

		// Write JSON for API request
		if (IsApi() && $addRow) {
			$row = $this->getRecordsFromRecordset([$rsnew], TRUE);
			WriteJson(["success" => TRUE, $this->TableVar => $row]);
		}
		return $addRow;
	}

	// Set up master/detail based on QueryString
	protected function setupMasterParms()
	{

		// Hide foreign keys
		$masterTblVar = $this->getCurrentMasterTable();
		if ($masterTblVar == "user") {
			$this->_userid->Visible = FALSE;
			if ($GLOBALS["user"]->EventCancelled)
				$this->EventCancelled = TRUE;
		}
		$this->DbMasterFilter = $this->getMasterFilter(); // Get master filter
		$this->DbDetailFilter = $this->getDetailFilter(); // Get detail filter
	}

	// Setup lookup options
	public function setupLookupOptions($fld)
	{
		if ($fld->Lookup !== NULL && $fld->Lookup->Options === NULL) {

			// Get default connection and filter
			$conn = $this->getConnection();
			$lookupFilter = "";

			// No need to check any more
			$fld->Lookup->Options = [];

			// Set up lookup SQL and connection
			switch ($fld->FieldVar) {
				case "x_userpi":
					break;
				case "x_refunded":
					break;
				case "x_success_status":
					break;
				default:
					$lookupFilter = "";
					break;
			}

			// Always call to Lookup->getSql so that user can setup Lookup->Options in Lookup_Selecting server event
			$sql = $fld->Lookup->getSql(FALSE, "", $lookupFilter, $this);

			// Set up lookup cache
			if ($fld->UseLookupCache && $sql != "" && count($fld->Lookup->Options) == 0) {
				$totalCnt = $this->getRecordCount($sql, $conn);
				if ($totalCnt > $fld->LookupCacheCount) // Total count > cache count, do not cache
					return;
				$rs = $conn->execute($sql);
				$ar = [];
				while ($rs && !$rs->EOF) {
					$row = &$rs->fields;

					// Format the field values
					switch ($fld->FieldVar) {
						case "x_userpi":
							break;
					}
					$ar[strval($row[0])] = $row;
					$rs->moveNext();
				}
				if ($rs)
					$rs->close();
				$fld->Lookup->Options = $ar;
			}
		}
	}

	// Page Load event
	function Page_Load() {

		//echo "Page Load";
	}

	// Page Unload event
	function Page_Unload() {

		//echo "Page Unload";
	}

	// Page Redirecting event
	function Page_Redirecting(&$url) {

		// Example:
		//$url = "your URL";

	}

	// Message Showing event
	// $type = ''|'success'|'failure'|'warning'
	function Message_Showing(&$msg, $type) {
		if ($type == 'success') {

			//$msg = "your success message";
		} elseif ($type == 'failure') {

			//$msg = "your failure message";
		} elseif ($type == 'warning') {

			//$msg = "your warning message";
		} else {

			//$msg = "your message";
		}
	}

	// Page Render event
	function Page_Render() {

		//echo "Page Render";
	}

	// Page Data Rendering event
	function Page_DataRendering(&$header) {

		// Example:
		//$header = "your header";

	}

	// Page Data Rendered event
	function Page_DataRendered(&$footer) {

		// Example:
		//$footer = "your footer";

	}

	// Form Custom Validate event
	function Form_CustomValidate(&$customError) {

		// Return error message in CustomError
		return TRUE;
	}

	// ListOptions Load event
	function ListOptions_Load() {

		// Example:
		//$opt = &$this->ListOptions->Add("new");
		//$opt->Header = "xxx";
		//$opt->OnLeft = TRUE; // Link on left
		//$opt->MoveTo(0); // Move to first column

	}

	// ListOptions Rendering event
	function ListOptions_Rendering() {

		//$GLOBALS["xxx_grid"]->DetailAdd = (...condition...); // Set to TRUE or FALSE conditionally
		//$GLOBALS["xxx_grid"]->DetailEdit = (...condition...); // Set to TRUE or FALSE conditionally
		//$GLOBALS["xxx_grid"]->DetailView = (...condition...); // Set to TRUE or FALSE conditionally

	}

	// ListOptions Rendered event
	function ListOptions_Rendered() {

		// Example:
		//$this->ListOptions["new"]->Body = "xxx";

	}
} // End class
?>