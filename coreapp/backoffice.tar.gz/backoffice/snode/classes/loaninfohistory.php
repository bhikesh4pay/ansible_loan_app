<?php namespace PHPMaker2020\_4payadmin; ?>
<?php

/**
 * Table class for loaninfohistory
 */
class loaninfohistory extends DbTable
{
	protected $SqlFrom = "";
	protected $SqlSelect = "";
	protected $SqlSelectList = "";
	protected $SqlWhere = "";
	protected $SqlGroupBy = "";
	protected $SqlHaving = "";
	protected $SqlOrderBy = "";
	public $UseSessionForListSql = TRUE;

	// Column CSS classes
	public $LeftColumnClass = "col-sm-2 col-form-label ew-label";
	public $RightColumnClass = "col-sm-10";
	public $OffsetColumnClass = "col-sm-10 offset-sm-2";
	public $TableLeftColumnClass = "w-col-2";

	// Audit trail
	public $AuditTrailOnAdd = TRUE;
	public $AuditTrailOnEdit = TRUE;
	public $AuditTrailOnDelete = TRUE;
	public $AuditTrailOnView = FALSE;
	public $AuditTrailOnViewData = FALSE;
	public $AuditTrailOnSearch = FALSE;

	// Export
	public $ExportDoc;

	// Fields
	public $infoid;
	public $_userid;
	public $externalrefid;
	public $currcode;
	public $sampleloantype;
	public $sampleamount;
	public $sampleamountforfeecalculation;
	public $eligibleamount;
	public $outstandingloanprinciple;
	public $outstandingloanfees;
	public $availableforloan;
	public $status;
	public $optin;
	public $sampleloanfeespretax;
	public $feetaxpercentage;
	public $feetaxamount;
	public $sampleloanfeesposttax;
	public $feesystemtotal;
	public $feeexternaltotal;
	public $feefranchiseetotal;
	public $feeresellertotal;
	public $outstandingloan;
	public $outstandingloanlatefees;
	public $intent;
	public $msg;
	public $infotime;

	// Constructor
	public function __construct()
	{
		global $Language, $CurrentLanguage;
		parent::__construct();

		// Language object
		if (!isset($Language))
			$Language = new Language();
		$this->TableVar = 'loaninfohistory';
		$this->TableName = 'loaninfohistory';
		$this->TableType = 'TABLE';

		// Update Table
		$this->UpdateTable = "`loaninfohistory`";
		$this->Dbid = 'DB';
		$this->ExportAll = TRUE;
		$this->ExportPageBreakCount = 0; // Page break per every n record (PDF only)
		$this->ExportPageOrientation = "portrait"; // Page orientation (PDF only)
		$this->ExportPageSize = "a4"; // Page size (PDF only)
		$this->ExportExcelPageOrientation = \PhpOffice\PhpSpreadsheet\Worksheet\PageSetup::ORIENTATION_DEFAULT; // Page orientation (PhpSpreadsheet only)
		$this->ExportExcelPageSize = \PhpOffice\PhpSpreadsheet\Worksheet\PageSetup::PAPERSIZE_A4; // Page size (PhpSpreadsheet only)
		$this->ExportWordPageOrientation = "portrait"; // Page orientation (PHPWord only)
		$this->ExportWordColumnWidth = NULL; // Cell width (PHPWord only)
		$this->DetailAdd = FALSE; // Allow detail add
		$this->DetailEdit = FALSE; // Allow detail edit
		$this->DetailView = FALSE; // Allow detail view
		$this->ShowMultipleDetails = FALSE; // Show multiple details
		$this->GridAddRowCount = 5;
		$this->AllowAddDeleteRow = TRUE; // Allow add/delete row
		$this->UserIDAllowSecurity = Config("DEFAULT_USER_ID_ALLOW_SECURITY"); // Default User ID allowed permissions
		$this->BasicSearch = new BasicSearch($this->TableVar);

		// infoid
		$this->infoid = new DbField('loaninfohistory', 'loaninfohistory', 'x_infoid', 'infoid', '`infoid`', '`infoid`', 20, 15, -1, FALSE, '`infoid`', FALSE, FALSE, FALSE, 'FORMATTED TEXT', 'NO');
		$this->infoid->IsAutoIncrement = TRUE; // Autoincrement field
		$this->infoid->IsPrimaryKey = TRUE; // Primary key field
		$this->infoid->Sortable = TRUE; // Allow sort
		$this->infoid->DefaultErrorMessage = $Language->phrase("IncorrectInteger");
		$this->fields['infoid'] = &$this->infoid;

		// userid
		$this->_userid = new DbField('loaninfohistory', 'loaninfohistory', 'x__userid', 'userid', '`userid`', '`userid`', 20, 15, -1, FALSE, '`userid`', FALSE, FALSE, FALSE, 'FORMATTED TEXT', 'TEXT');
		$this->_userid->Nullable = FALSE; // NOT NULL field
		$this->_userid->Required = TRUE; // Required field
		$this->_userid->Sortable = TRUE; // Allow sort
		$this->_userid->DefaultErrorMessage = $Language->phrase("IncorrectInteger");
		$this->fields['userid'] = &$this->_userid;

		// externalrefid
		$this->externalrefid = new DbField('loaninfohistory', 'loaninfohistory', 'x_externalrefid', 'externalrefid', '`externalrefid`', '`externalrefid`', 200, 30, -1, FALSE, '`externalrefid`', FALSE, FALSE, FALSE, 'FORMATTED TEXT', 'TEXT');
		$this->externalrefid->Sortable = TRUE; // Allow sort
		$this->fields['externalrefid'] = &$this->externalrefid;

		// currcode
		$this->currcode = new DbField('loaninfohistory', 'loaninfohistory', 'x_currcode', 'currcode', '`currcode`', '`currcode`', 200, 3, -1, FALSE, '`currcode`', FALSE, FALSE, FALSE, 'FORMATTED TEXT', 'TEXT');
		$this->currcode->Nullable = FALSE; // NOT NULL field
		$this->currcode->Required = TRUE; // Required field
		$this->currcode->Sortable = TRUE; // Allow sort
		$this->fields['currcode'] = &$this->currcode;

		// sampleloantype
		$this->sampleloantype = new DbField('loaninfohistory', 'loaninfohistory', 'x_sampleloantype', 'sampleloantype', '`sampleloantype`', '`sampleloantype`', 3, 2, -1, FALSE, '`sampleloantype`', FALSE, FALSE, FALSE, 'FORMATTED TEXT', 'TEXT');
		$this->sampleloantype->Nullable = FALSE; // NOT NULL field
		$this->sampleloantype->Required = TRUE; // Required field
		$this->sampleloantype->Sortable = TRUE; // Allow sort
		$this->sampleloantype->DefaultErrorMessage = $Language->phrase("IncorrectInteger");
		$this->fields['sampleloantype'] = &$this->sampleloantype;

		// sampleamount
		$this->sampleamount = new DbField('loaninfohistory', 'loaninfohistory', 'x_sampleamount', 'sampleamount', '`sampleamount`', '`sampleamount`', 131, 12, -1, FALSE, '`sampleamount`', FALSE, FALSE, FALSE, 'FORMATTED TEXT', 'TEXT');
		$this->sampleamount->Nullable = FALSE; // NOT NULL field
		$this->sampleamount->Required = TRUE; // Required field
		$this->sampleamount->Sortable = TRUE; // Allow sort
		$this->sampleamount->DefaultErrorMessage = $Language->phrase("IncorrectFloat");
		$this->fields['sampleamount'] = &$this->sampleamount;

		// sampleamountforfeecalculation
		$this->sampleamountforfeecalculation = new DbField('loaninfohistory', 'loaninfohistory', 'x_sampleamountforfeecalculation', 'sampleamountforfeecalculation', '`sampleamountforfeecalculation`', '`sampleamountforfeecalculation`', 131, 12, -1, FALSE, '`sampleamountforfeecalculation`', FALSE, FALSE, FALSE, 'FORMATTED TEXT', 'TEXT');
		$this->sampleamountforfeecalculation->Nullable = FALSE; // NOT NULL field
		$this->sampleamountforfeecalculation->Required = TRUE; // Required field
		$this->sampleamountforfeecalculation->Sortable = TRUE; // Allow sort
		$this->sampleamountforfeecalculation->DefaultErrorMessage = $Language->phrase("IncorrectFloat");
		$this->fields['sampleamountforfeecalculation'] = &$this->sampleamountforfeecalculation;

		// eligibleamount
		$this->eligibleamount = new DbField('loaninfohistory', 'loaninfohistory', 'x_eligibleamount', 'eligibleamount', '`eligibleamount`', '`eligibleamount`', 131, 12, -1, FALSE, '`eligibleamount`', FALSE, FALSE, FALSE, 'FORMATTED TEXT', 'TEXT');
		$this->eligibleamount->Nullable = FALSE; // NOT NULL field
		$this->eligibleamount->Required = TRUE; // Required field
		$this->eligibleamount->Sortable = TRUE; // Allow sort
		$this->eligibleamount->DefaultErrorMessage = $Language->phrase("IncorrectFloat");
		$this->fields['eligibleamount'] = &$this->eligibleamount;

		// outstandingloanprinciple
		$this->outstandingloanprinciple = new DbField('loaninfohistory', 'loaninfohistory', 'x_outstandingloanprinciple', 'outstandingloanprinciple', '`outstandingloanprinciple`', '`outstandingloanprinciple`', 131, 12, -1, FALSE, '`outstandingloanprinciple`', FALSE, FALSE, FALSE, 'FORMATTED TEXT', 'TEXT');
		$this->outstandingloanprinciple->Nullable = FALSE; // NOT NULL field
		$this->outstandingloanprinciple->Required = TRUE; // Required field
		$this->outstandingloanprinciple->Sortable = TRUE; // Allow sort
		$this->outstandingloanprinciple->DefaultErrorMessage = $Language->phrase("IncorrectFloat");
		$this->fields['outstandingloanprinciple'] = &$this->outstandingloanprinciple;

		// outstandingloanfees
		$this->outstandingloanfees = new DbField('loaninfohistory', 'loaninfohistory', 'x_outstandingloanfees', 'outstandingloanfees', '`outstandingloanfees`', '`outstandingloanfees`', 131, 12, -1, FALSE, '`outstandingloanfees`', FALSE, FALSE, FALSE, 'FORMATTED TEXT', 'TEXT');
		$this->outstandingloanfees->Nullable = FALSE; // NOT NULL field
		$this->outstandingloanfees->Required = TRUE; // Required field
		$this->outstandingloanfees->Sortable = TRUE; // Allow sort
		$this->outstandingloanfees->DefaultErrorMessage = $Language->phrase("IncorrectFloat");
		$this->fields['outstandingloanfees'] = &$this->outstandingloanfees;

		// availableforloan
		$this->availableforloan = new DbField('loaninfohistory', 'loaninfohistory', 'x_availableforloan', 'availableforloan', '`availableforloan`', '`availableforloan`', 131, 12, -1, FALSE, '`availableforloan`', FALSE, FALSE, FALSE, 'FORMATTED TEXT', 'TEXT');
		$this->availableforloan->Nullable = FALSE; // NOT NULL field
		$this->availableforloan->Required = TRUE; // Required field
		$this->availableforloan->Sortable = TRUE; // Allow sort
		$this->availableforloan->DefaultErrorMessage = $Language->phrase("IncorrectFloat");
		$this->fields['availableforloan'] = &$this->availableforloan;

		// status
		$this->status = new DbField('loaninfohistory', 'loaninfohistory', 'x_status', 'status', '`status`', '`status`', 3, 1, -1, FALSE, '`status`', FALSE, FALSE, FALSE, 'FORMATTED TEXT', 'TEXT');
		$this->status->Nullable = FALSE; // NOT NULL field
		$this->status->Required = TRUE; // Required field
		$this->status->Sortable = TRUE; // Allow sort
		$this->status->DefaultErrorMessage = $Language->phrase("IncorrectInteger");
		$this->fields['status'] = &$this->status;

		// optin
		$this->optin = new DbField('loaninfohistory', 'loaninfohistory', 'x_optin', 'optin', '`optin`', '`optin`', 3, 1, -1, FALSE, '`optin`', FALSE, FALSE, FALSE, 'FORMATTED TEXT', 'TEXT');
		$this->optin->Nullable = FALSE; // NOT NULL field
		$this->optin->Required = TRUE; // Required field
		$this->optin->Sortable = TRUE; // Allow sort
		$this->optin->DefaultErrorMessage = $Language->phrase("IncorrectInteger");
		$this->fields['optin'] = &$this->optin;

		// sampleloanfeespretax
		$this->sampleloanfeespretax = new DbField('loaninfohistory', 'loaninfohistory', 'x_sampleloanfeespretax', 'sampleloanfeespretax', '`sampleloanfeespretax`', '`sampleloanfeespretax`', 131, 12, -1, FALSE, '`sampleloanfeespretax`', FALSE, FALSE, FALSE, 'FORMATTED TEXT', 'TEXT');
		$this->sampleloanfeespretax->Nullable = FALSE; // NOT NULL field
		$this->sampleloanfeespretax->Required = TRUE; // Required field
		$this->sampleloanfeespretax->Sortable = TRUE; // Allow sort
		$this->sampleloanfeespretax->DefaultErrorMessage = $Language->phrase("IncorrectFloat");
		$this->fields['sampleloanfeespretax'] = &$this->sampleloanfeespretax;

		// feetaxpercentage
		$this->feetaxpercentage = new DbField('loaninfohistory', 'loaninfohistory', 'x_feetaxpercentage', 'feetaxpercentage', '`feetaxpercentage`', '`feetaxpercentage`', 131, 12, -1, FALSE, '`feetaxpercentage`', FALSE, FALSE, FALSE, 'FORMATTED TEXT', 'TEXT');
		$this->feetaxpercentage->Nullable = FALSE; // NOT NULL field
		$this->feetaxpercentage->Required = TRUE; // Required field
		$this->feetaxpercentage->Sortable = TRUE; // Allow sort
		$this->feetaxpercentage->DefaultErrorMessage = $Language->phrase("IncorrectFloat");
		$this->fields['feetaxpercentage'] = &$this->feetaxpercentage;

		// feetaxamount
		$this->feetaxamount = new DbField('loaninfohistory', 'loaninfohistory', 'x_feetaxamount', 'feetaxamount', '`feetaxamount`', '`feetaxamount`', 131, 12, -1, FALSE, '`feetaxamount`', FALSE, FALSE, FALSE, 'FORMATTED TEXT', 'TEXT');
		$this->feetaxamount->Nullable = FALSE; // NOT NULL field
		$this->feetaxamount->Required = TRUE; // Required field
		$this->feetaxamount->Sortable = TRUE; // Allow sort
		$this->feetaxamount->DefaultErrorMessage = $Language->phrase("IncorrectFloat");
		$this->fields['feetaxamount'] = &$this->feetaxamount;

		// sampleloanfeesposttax
		$this->sampleloanfeesposttax = new DbField('loaninfohistory', 'loaninfohistory', 'x_sampleloanfeesposttax', 'sampleloanfeesposttax', '`sampleloanfeesposttax`', '`sampleloanfeesposttax`', 131, 12, -1, FALSE, '`sampleloanfeesposttax`', FALSE, FALSE, FALSE, 'FORMATTED TEXT', 'TEXT');
		$this->sampleloanfeesposttax->Nullable = FALSE; // NOT NULL field
		$this->sampleloanfeesposttax->Required = TRUE; // Required field
		$this->sampleloanfeesposttax->Sortable = TRUE; // Allow sort
		$this->sampleloanfeesposttax->DefaultErrorMessage = $Language->phrase("IncorrectFloat");
		$this->fields['sampleloanfeesposttax'] = &$this->sampleloanfeesposttax;

		// feesystemtotal
		$this->feesystemtotal = new DbField('loaninfohistory', 'loaninfohistory', 'x_feesystemtotal', 'feesystemtotal', '`feesystemtotal`', '`feesystemtotal`', 131, 12, -1, FALSE, '`feesystemtotal`', FALSE, FALSE, FALSE, 'FORMATTED TEXT', 'TEXT');
		$this->feesystemtotal->Nullable = FALSE; // NOT NULL field
		$this->feesystemtotal->Required = TRUE; // Required field
		$this->feesystemtotal->Sortable = TRUE; // Allow sort
		$this->feesystemtotal->DefaultErrorMessage = $Language->phrase("IncorrectFloat");
		$this->fields['feesystemtotal'] = &$this->feesystemtotal;

		// feeexternaltotal
		$this->feeexternaltotal = new DbField('loaninfohistory', 'loaninfohistory', 'x_feeexternaltotal', 'feeexternaltotal', '`feeexternaltotal`', '`feeexternaltotal`', 131, 12, -1, FALSE, '`feeexternaltotal`', FALSE, FALSE, FALSE, 'FORMATTED TEXT', 'TEXT');
		$this->feeexternaltotal->Nullable = FALSE; // NOT NULL field
		$this->feeexternaltotal->Required = TRUE; // Required field
		$this->feeexternaltotal->Sortable = TRUE; // Allow sort
		$this->feeexternaltotal->DefaultErrorMessage = $Language->phrase("IncorrectFloat");
		$this->fields['feeexternaltotal'] = &$this->feeexternaltotal;

		// feefranchiseetotal
		$this->feefranchiseetotal = new DbField('loaninfohistory', 'loaninfohistory', 'x_feefranchiseetotal', 'feefranchiseetotal', '`feefranchiseetotal`', '`feefranchiseetotal`', 131, 12, -1, FALSE, '`feefranchiseetotal`', FALSE, FALSE, FALSE, 'FORMATTED TEXT', 'TEXT');
		$this->feefranchiseetotal->Nullable = FALSE; // NOT NULL field
		$this->feefranchiseetotal->Required = TRUE; // Required field
		$this->feefranchiseetotal->Sortable = TRUE; // Allow sort
		$this->feefranchiseetotal->DefaultErrorMessage = $Language->phrase("IncorrectFloat");
		$this->fields['feefranchiseetotal'] = &$this->feefranchiseetotal;

		// feeresellertotal
		$this->feeresellertotal = new DbField('loaninfohistory', 'loaninfohistory', 'x_feeresellertotal', 'feeresellertotal', '`feeresellertotal`', '`feeresellertotal`', 131, 12, -1, FALSE, '`feeresellertotal`', FALSE, FALSE, FALSE, 'FORMATTED TEXT', 'TEXT');
		$this->feeresellertotal->Nullable = FALSE; // NOT NULL field
		$this->feeresellertotal->Required = TRUE; // Required field
		$this->feeresellertotal->Sortable = TRUE; // Allow sort
		$this->feeresellertotal->DefaultErrorMessage = $Language->phrase("IncorrectFloat");
		$this->fields['feeresellertotal'] = &$this->feeresellertotal;

		// outstandingloan
		$this->outstandingloan = new DbField('loaninfohistory', 'loaninfohistory', 'x_outstandingloan', 'outstandingloan', '`outstandingloan`', '`outstandingloan`', 131, 12, -1, FALSE, '`outstandingloan`', FALSE, FALSE, FALSE, 'FORMATTED TEXT', 'TEXT');
		$this->outstandingloan->Sortable = TRUE; // Allow sort
		$this->outstandingloan->DefaultErrorMessage = $Language->phrase("IncorrectFloat");
		$this->fields['outstandingloan'] = &$this->outstandingloan;

		// outstandingloanlatefees
		$this->outstandingloanlatefees = new DbField('loaninfohistory', 'loaninfohistory', 'x_outstandingloanlatefees', 'outstandingloanlatefees', '`outstandingloanlatefees`', '`outstandingloanlatefees`', 131, 12, -1, FALSE, '`outstandingloanlatefees`', FALSE, FALSE, FALSE, 'FORMATTED TEXT', 'TEXT');
		$this->outstandingloanlatefees->Sortable = TRUE; // Allow sort
		$this->outstandingloanlatefees->DefaultErrorMessage = $Language->phrase("IncorrectFloat");
		$this->fields['outstandingloanlatefees'] = &$this->outstandingloanlatefees;

		// intent
		$this->intent = new DbField('loaninfohistory', 'loaninfohistory', 'x_intent', 'intent', '`intent`', '`intent`', 200, 2, -1, FALSE, '`intent`', FALSE, FALSE, FALSE, 'FORMATTED TEXT', 'TEXT');
		$this->intent->Sortable = TRUE; // Allow sort
		$this->fields['intent'] = &$this->intent;

		// msg
		$this->msg = new DbField('loaninfohistory', 'loaninfohistory', 'x_msg', 'msg', '`msg`', '`msg`', 200, 15, -1, FALSE, '`msg`', FALSE, FALSE, FALSE, 'FORMATTED TEXT', 'TEXT');
		$this->msg->Sortable = TRUE; // Allow sort
		$this->fields['msg'] = &$this->msg;

		// infotime
		$this->infotime = new DbField('loaninfohistory', 'loaninfohistory', 'x_infotime', 'infotime', '`infotime`', CastDateFieldForLike("`infotime`", 0, "DB"), 135, 19, 0, FALSE, '`infotime`', FALSE, FALSE, FALSE, 'FORMATTED TEXT', 'TEXT');
		$this->infotime->Sortable = TRUE; // Allow sort
		$this->infotime->DefaultErrorMessage = str_replace("%s", $GLOBALS["DATE_FORMAT"], $Language->phrase("IncorrectDate"));
		$this->fields['infotime'] = &$this->infotime;
	}

	// Field Visibility
	public function getFieldVisibility($fldParm)
	{
		global $Security;
		return $this->$fldParm->Visible; // Returns original value
	}

	// Set left column class (must be predefined col-*-* classes of Bootstrap grid system)
	function setLeftColumnClass($class)
	{
		if (preg_match('/^col\-(\w+)\-(\d+)$/', $class, $match)) {
			$this->LeftColumnClass = $class . " col-form-label ew-label";
			$this->RightColumnClass = "col-" . $match[1] . "-" . strval(12 - (int)$match[2]);
			$this->OffsetColumnClass = $this->RightColumnClass . " " . str_replace("col-", "offset-", $class);
			$this->TableLeftColumnClass = preg_replace('/^col-\w+-(\d+)$/', "w-col-$1", $class); // Change to w-col-*
		}
	}

	// Single column sort
	public function updateSort(&$fld)
	{
		if ($this->CurrentOrder == $fld->Name) {
			$sortField = $fld->Expression;
			$lastSort = $fld->getSort();
			if ($this->CurrentOrderType == "ASC" || $this->CurrentOrderType == "DESC") {
				$thisSort = $this->CurrentOrderType;
			} else {
				$thisSort = ($lastSort == "ASC") ? "DESC" : "ASC";
			}
			$fld->setSort($thisSort);
			$this->setSessionOrderBy($sortField . " " . $thisSort); // Save to Session
		} else {
			$fld->setSort("");
		}
	}

	// Table level SQL
	public function getSqlFrom() // From
	{
		return ($this->SqlFrom != "") ? $this->SqlFrom : "`loaninfohistory`";
	}
	public function sqlFrom() // For backward compatibility
	{
		return $this->getSqlFrom();
	}
	public function setSqlFrom($v)
	{
		$this->SqlFrom = $v;
	}
	public function getSqlSelect() // Select
	{
		return ($this->SqlSelect != "") ? $this->SqlSelect : "SELECT * FROM " . $this->getSqlFrom();
	}
	public function sqlSelect() // For backward compatibility
	{
		return $this->getSqlSelect();
	}
	public function setSqlSelect($v)
	{
		$this->SqlSelect = $v;
	}
	public function getSqlWhere() // Where
	{
		$where = ($this->SqlWhere != "") ? $this->SqlWhere : "";
		$this->TableFilter = "";
		AddFilter($where, $this->TableFilter);
		return $where;
	}
	public function sqlWhere() // For backward compatibility
	{
		return $this->getSqlWhere();
	}
	public function setSqlWhere($v)
	{
		$this->SqlWhere = $v;
	}
	public function getSqlGroupBy() // Group By
	{
		return ($this->SqlGroupBy != "") ? $this->SqlGroupBy : "";
	}
	public function sqlGroupBy() // For backward compatibility
	{
		return $this->getSqlGroupBy();
	}
	public function setSqlGroupBy($v)
	{
		$this->SqlGroupBy = $v;
	}
	public function getSqlHaving() // Having
	{
		return ($this->SqlHaving != "") ? $this->SqlHaving : "";
	}
	public function sqlHaving() // For backward compatibility
	{
		return $this->getSqlHaving();
	}
	public function setSqlHaving($v)
	{
		$this->SqlHaving = $v;
	}
	public function getSqlOrderBy() // Order By
	{
		return ($this->SqlOrderBy != "") ? $this->SqlOrderBy : "";
	}
	public function sqlOrderBy() // For backward compatibility
	{
		return $this->getSqlOrderBy();
	}
	public function setSqlOrderBy($v)
	{
		$this->SqlOrderBy = $v;
	}

	// Apply User ID filters
	public function applyUserIDFilters($filter, $id = "")
	{
		return $filter;
	}

	// Check if User ID security allows view all
	public function userIDAllow($id = "")
	{
		$allow = $this->UserIDAllowSecurity;
		switch ($id) {
			case "add":
			case "copy":
			case "gridadd":
			case "register":
			case "addopt":
				return (($allow & 1) == 1);
			case "edit":
			case "gridedit":
			case "update":
			case "changepwd":
			case "forgotpwd":
				return (($allow & 4) == 4);
			case "delete":
				return (($allow & 2) == 2);
			case "view":
				return (($allow & 32) == 32);
			case "search":
				return (($allow & 64) == 64);
			case "lookup":
				return (($allow & 256) == 256);
			default:
				return (($allow & 8) == 8);
		}
	}

	// Get recordset
	public function getRecordset($sql, $rowcnt = -1, $offset = -1)
	{
		$conn = $this->getConnection();
		$conn->raiseErrorFn = Config("ERROR_FUNC");
		$rs = $conn->selectLimit($sql, $rowcnt, $offset);
		$conn->raiseErrorFn = "";
		return $rs;
	}

	// Get record count
	public function getRecordCount($sql, $c = NULL)
	{
		$cnt = -1;
		$rs = NULL;
		$sql = preg_replace('/\/\*BeginOrderBy\*\/[\s\S]+\/\*EndOrderBy\*\//', "", $sql); // Remove ORDER BY clause (MSSQL)
		$pattern = '/^SELECT\s([\s\S]+)\sFROM\s/i';

		// Skip Custom View / SubQuery / SELECT DISTINCT / ORDER BY
		if (($this->TableType == 'TABLE' || $this->TableType == 'VIEW' || $this->TableType == 'LINKTABLE') &&
			preg_match($pattern, $sql) && !preg_match('/\(\s*(SELECT[^)]+)\)/i', $sql) &&
			!preg_match('/^\s*select\s+distinct\s+/i', $sql) && !preg_match('/\s+order\s+by\s+/i', $sql)) {
			$sqlwrk = "SELECT COUNT(*) FROM " . preg_replace($pattern, "", $sql);
		} else {
			$sqlwrk = "SELECT COUNT(*) FROM (" . $sql . ") COUNT_TABLE";
		}
		$conn = $c ?: $this->getConnection();
		if ($rs = $conn->execute($sqlwrk)) {
			if (!$rs->EOF && $rs->FieldCount() > 0) {
				$cnt = $rs->fields[0];
				$rs->close();
			}
			return (int)$cnt;
		}

		// Unable to get count, get record count directly
		if ($rs = $conn->execute($sql)) {
			$cnt = $rs->RecordCount();
			$rs->close();
			return (int)$cnt;
		}
		return $cnt;
	}

	// Get SQL
	public function getSql($where, $orderBy = "")
	{
		return BuildSelectSql($this->getSqlSelect(), $this->getSqlWhere(),
			$this->getSqlGroupBy(), $this->getSqlHaving(), $this->getSqlOrderBy(),
			$where, $orderBy);
	}

	// Table SQL
	public function getCurrentSql()
	{
		$filter = $this->CurrentFilter;
		$filter = $this->applyUserIDFilters($filter);
		$sort = $this->getSessionOrderBy();
		return $this->getSql($filter, $sort);
	}

	// Table SQL with List page filter
	public function getListSql()
	{
		$filter = $this->UseSessionForListSql ? $this->getSessionWhere() : "";
		AddFilter($filter, $this->CurrentFilter);
		$filter = $this->applyUserIDFilters($filter);
		$this->Recordset_Selecting($filter);
		$select = $this->getSqlSelect();
		$sort = $this->UseSessionForListSql ? $this->getSessionOrderBy() : "";
		return BuildSelectSql($select, $this->getSqlWhere(), $this->getSqlGroupBy(),
			$this->getSqlHaving(), $this->getSqlOrderBy(), $filter, $sort);
	}

	// Get ORDER BY clause
	public function getOrderBy()
	{
		$sort = $this->getSessionOrderBy();
		return BuildSelectSql("", "", "", "", $this->getSqlOrderBy(), "", $sort);
	}

	// Get record count based on filter (for detail record count in master table pages)
	public function loadRecordCount($filter)
	{
		$origFilter = $this->CurrentFilter;
		$this->CurrentFilter = $filter;
		$this->Recordset_Selecting($this->CurrentFilter);
		$select = $this->TableType == 'CUSTOMVIEW' ? $this->getSqlSelect() : "SELECT * FROM " . $this->getSqlFrom();
		$groupBy = $this->TableType == 'CUSTOMVIEW' ? $this->getSqlGroupBy() : "";
		$having = $this->TableType == 'CUSTOMVIEW' ? $this->getSqlHaving() : "";
		$sql = BuildSelectSql($select, $this->getSqlWhere(), $groupBy, $having, "", $this->CurrentFilter, "");
		$cnt = $this->getRecordCount($sql);
		$this->CurrentFilter = $origFilter;
		return $cnt;
	}

	// Get record count (for current List page)
	public function listRecordCount()
	{
		$filter = $this->getSessionWhere();
		AddFilter($filter, $this->CurrentFilter);
		$filter = $this->applyUserIDFilters($filter);
		$this->Recordset_Selecting($filter);
		$select = $this->TableType == 'CUSTOMVIEW' ? $this->getSqlSelect() : "SELECT * FROM " . $this->getSqlFrom();
		$groupBy = $this->TableType == 'CUSTOMVIEW' ? $this->getSqlGroupBy() : "";
		$having = $this->TableType == 'CUSTOMVIEW' ? $this->getSqlHaving() : "";
		$sql = BuildSelectSql($select, $this->getSqlWhere(), $groupBy, $having, "", $filter, "");
		$cnt = $this->getRecordCount($sql);
		return $cnt;
	}

	// INSERT statement
	protected function insertSql(&$rs)
	{
		$names = "";
		$values = "";
		foreach ($rs as $name => $value) {
			if (!isset($this->fields[$name]) || $this->fields[$name]->IsCustom)
				continue;
			$names .= $this->fields[$name]->Expression . ",";
			$values .= QuotedValue($value, $this->fields[$name]->DataType, $this->Dbid) . ",";
		}
		$names = preg_replace('/,+$/', "", $names);
		$values = preg_replace('/,+$/', "", $values);
		return "INSERT INTO " . $this->UpdateTable . " (" . $names . ") VALUES (" . $values . ")";
	}

	// Insert
	public function insert(&$rs)
	{
		$conn = $this->getConnection();
		$success = $conn->execute($this->insertSql($rs));
		if ($success) {

			// Get insert id if necessary
			$this->infoid->setDbValue($conn->insert_ID());
			$rs['infoid'] = $this->infoid->DbValue;
			if ($this->AuditTrailOnAdd)
				$this->writeAuditTrailOnAdd($rs);
		}
		return $success;
	}

	// UPDATE statement
	protected function updateSql(&$rs, $where = "", $curfilter = TRUE)
	{
		$sql = "UPDATE " . $this->UpdateTable . " SET ";
		foreach ($rs as $name => $value) {
			if (!isset($this->fields[$name]) || $this->fields[$name]->IsCustom || $this->fields[$name]->IsAutoIncrement)
				continue;
			$sql .= $this->fields[$name]->Expression . "=";
			$sql .= QuotedValue($value, $this->fields[$name]->DataType, $this->Dbid) . ",";
		}
		$sql = preg_replace('/,+$/', "", $sql);
		$filter = ($curfilter) ? $this->CurrentFilter : "";
		if (is_array($where))
			$where = $this->arrayToFilter($where);
		AddFilter($filter, $where);
		if ($filter != "")
			$sql .= " WHERE " . $filter;
		return $sql;
	}

	// Update
	public function update(&$rs, $where = "", $rsold = NULL, $curfilter = TRUE)
	{
		$conn = $this->getConnection();
		$success = $conn->execute($this->updateSql($rs, $where, $curfilter));
		if ($success && $this->AuditTrailOnEdit && $rsold) {
			$rsaudit = $rs;
			$fldname = 'infoid';
			if (!array_key_exists($fldname, $rsaudit))
				$rsaudit[$fldname] = $rsold[$fldname];
			$this->writeAuditTrailOnEdit($rsold, $rsaudit);
		}
		return $success;
	}

	// DELETE statement
	protected function deleteSql(&$rs, $where = "", $curfilter = TRUE)
	{
		$sql = "DELETE FROM " . $this->UpdateTable . " WHERE ";
		if (is_array($where))
			$where = $this->arrayToFilter($where);
		if ($rs) {
			if (array_key_exists('infoid', $rs))
				AddFilter($where, QuotedName('infoid', $this->Dbid) . '=' . QuotedValue($rs['infoid'], $this->infoid->DataType, $this->Dbid));
		}
		$filter = ($curfilter) ? $this->CurrentFilter : "";
		AddFilter($filter, $where);
		if ($filter != "")
			$sql .= $filter;
		else
			$sql .= "0=1"; // Avoid delete
		return $sql;
	}

	// Delete
	public function delete(&$rs, $where = "", $curfilter = FALSE)
	{
		$success = TRUE;
		$conn = $this->getConnection();
		if ($success)
			$success = $conn->execute($this->deleteSql($rs, $where, $curfilter));
		if ($success && $this->AuditTrailOnDelete)
			$this->writeAuditTrailOnDelete($rs);
		return $success;
	}

	// Load DbValue from recordset or array
	protected function loadDbValues(&$rs)
	{
		if (!$rs || !is_array($rs) && $rs->EOF)
			return;
		$row = is_array($rs) ? $rs : $rs->fields;
		$this->infoid->DbValue = $row['infoid'];
		$this->_userid->DbValue = $row['userid'];
		$this->externalrefid->DbValue = $row['externalrefid'];
		$this->currcode->DbValue = $row['currcode'];
		$this->sampleloantype->DbValue = $row['sampleloantype'];
		$this->sampleamount->DbValue = $row['sampleamount'];
		$this->sampleamountforfeecalculation->DbValue = $row['sampleamountforfeecalculation'];
		$this->eligibleamount->DbValue = $row['eligibleamount'];
		$this->outstandingloanprinciple->DbValue = $row['outstandingloanprinciple'];
		$this->outstandingloanfees->DbValue = $row['outstandingloanfees'];
		$this->availableforloan->DbValue = $row['availableforloan'];
		$this->status->DbValue = $row['status'];
		$this->optin->DbValue = $row['optin'];
		$this->sampleloanfeespretax->DbValue = $row['sampleloanfeespretax'];
		$this->feetaxpercentage->DbValue = $row['feetaxpercentage'];
		$this->feetaxamount->DbValue = $row['feetaxamount'];
		$this->sampleloanfeesposttax->DbValue = $row['sampleloanfeesposttax'];
		$this->feesystemtotal->DbValue = $row['feesystemtotal'];
		$this->feeexternaltotal->DbValue = $row['feeexternaltotal'];
		$this->feefranchiseetotal->DbValue = $row['feefranchiseetotal'];
		$this->feeresellertotal->DbValue = $row['feeresellertotal'];
		$this->outstandingloan->DbValue = $row['outstandingloan'];
		$this->outstandingloanlatefees->DbValue = $row['outstandingloanlatefees'];
		$this->intent->DbValue = $row['intent'];
		$this->msg->DbValue = $row['msg'];
		$this->infotime->DbValue = $row['infotime'];
	}

	// Delete uploaded files
	public function deleteUploadedFiles($row)
	{
		$this->loadDbValues($row);
	}

	// Record filter WHERE clause
	protected function sqlKeyFilter()
	{
		return "`infoid` = @infoid@";
	}

	// Get record filter
	public function getRecordFilter($row = NULL)
	{
		$keyFilter = $this->sqlKeyFilter();
		if (is_array($row))
			$val = array_key_exists('infoid', $row) ? $row['infoid'] : NULL;
		else
			$val = $this->infoid->OldValue !== NULL ? $this->infoid->OldValue : $this->infoid->CurrentValue;
		if (!is_numeric($val))
			return "0=1"; // Invalid key
		if ($val == NULL)
			return "0=1"; // Invalid key
		else
			$keyFilter = str_replace("@infoid@", AdjustSql($val, $this->Dbid), $keyFilter); // Replace key value
		return $keyFilter;
	}

	// Return page URL
	public function getReturnUrl()
	{
		$name = PROJECT_NAME . "_" . $this->TableVar . "_" . Config("TABLE_RETURN_URL");

		// Get referer URL automatically
		if (ServerVar("HTTP_REFERER") != "" && ReferPageName() != CurrentPageName() && ReferPageName() != "login.php") // Referer not same page or login page
			$_SESSION[$name] = ServerVar("HTTP_REFERER"); // Save to Session
		if (@$_SESSION[$name] != "") {
			return $_SESSION[$name];
		} else {
			return "loaninfohistorylist.php";
		}
	}
	public function setReturnUrl($v)
	{
		$_SESSION[PROJECT_NAME . "_" . $this->TableVar . "_" . Config("TABLE_RETURN_URL")] = $v;
	}

	// Get modal caption
	public function getModalCaption($pageName)
	{
		global $Language;
		if ($pageName == "loaninfohistoryview.php")
			return $Language->phrase("View");
		elseif ($pageName == "loaninfohistoryedit.php")
			return $Language->phrase("Edit");
		elseif ($pageName == "loaninfohistoryadd.php")
			return $Language->phrase("Add");
		else
			return "";
	}

	// List URL
	public function getListUrl()
	{
		return "loaninfohistorylist.php";
	}

	// View URL
	public function getViewUrl($parm = "")
	{
		if ($parm != "")
			$url = $this->keyUrl("loaninfohistoryview.php", $this->getUrlParm($parm));
		else
			$url = $this->keyUrl("loaninfohistoryview.php", $this->getUrlParm(Config("TABLE_SHOW_DETAIL") . "="));
		return $this->addMasterUrl($url);
	}

	// Add URL
	public function getAddUrl($parm = "")
	{
		if ($parm != "")
			$url = "loaninfohistoryadd.php?" . $this->getUrlParm($parm);
		else
			$url = "loaninfohistoryadd.php";
		return $this->addMasterUrl($url);
	}

	// Edit URL
	public function getEditUrl($parm = "")
	{
		$url = $this->keyUrl("loaninfohistoryedit.php", $this->getUrlParm($parm));
		return $this->addMasterUrl($url);
	}

	// Inline edit URL
	public function getInlineEditUrl()
	{
		$url = $this->keyUrl(CurrentPageName(), $this->getUrlParm("action=edit"));
		return $this->addMasterUrl($url);
	}

	// Copy URL
	public function getCopyUrl($parm = "")
	{
		$url = $this->keyUrl("loaninfohistoryadd.php", $this->getUrlParm($parm));
		return $this->addMasterUrl($url);
	}

	// Inline copy URL
	public function getInlineCopyUrl()
	{
		$url = $this->keyUrl(CurrentPageName(), $this->getUrlParm("action=copy"));
		return $this->addMasterUrl($url);
	}

	// Delete URL
	public function getDeleteUrl()
	{
		return $this->keyUrl("loaninfohistorydelete.php", $this->getUrlParm());
	}

	// Add master url
	public function addMasterUrl($url)
	{
		return $url;
	}
	public function keyToJson($htmlEncode = FALSE)
	{
		$json = "";
		$json .= "infoid:" . JsonEncode($this->infoid->CurrentValue, "number");
		$json = "{" . $json . "}";
		if ($htmlEncode)
			$json = HtmlEncode($json);
		return $json;
	}

	// Add key value to URL
	public function keyUrl($url, $parm = "")
	{
		$url = $url . "?";
		if ($parm != "")
			$url .= $parm . "&";
		if ($this->infoid->CurrentValue != NULL) {
			$url .= "infoid=" . urlencode($this->infoid->CurrentValue);
		} else {
			return "javascript:ew.alert(ew.language.phrase('InvalidRecord'));";
		}
		return $url;
	}

	// Sort URL
	public function sortUrl(&$fld)
	{
		if ($this->CurrentAction || $this->isExport() ||
			in_array($fld->Type, [128, 204, 205])) { // Unsortable data type
				return "";
		} elseif ($fld->Sortable) {
			$urlParm = $this->getUrlParm("order=" . urlencode($fld->Name) . "&amp;ordertype=" . $fld->reverseSort());
			return $this->addMasterUrl(CurrentPageName() . "?" . $urlParm);
		} else {
			return "";
		}
	}

	// Get record keys from Post/Get/Session
	public function getRecordKeys()
	{
		$arKeys = [];
		$arKey = [];
		if (Param("key_m") !== NULL) {
			$arKeys = Param("key_m");
			$cnt = count($arKeys);
		} else {
			if (Param("infoid") !== NULL)
				$arKeys[] = Param("infoid");
			elseif (IsApi() && Key(0) !== NULL)
				$arKeys[] = Key(0);
			elseif (IsApi() && Route(2) !== NULL)
				$arKeys[] = Route(2);
			else
				$arKeys = NULL; // Do not setup

			//return $arKeys; // Do not return yet, so the values will also be checked by the following code
		}

		// Check keys
		$ar = [];
		if (is_array($arKeys)) {
			foreach ($arKeys as $key) {
				if (!is_numeric($key))
					continue;
				$ar[] = $key;
			}
		}
		return $ar;
	}

	// Get filter from record keys
	public function getFilterFromRecordKeys($setCurrent = TRUE)
	{
		$arKeys = $this->getRecordKeys();
		$keyFilter = "";
		foreach ($arKeys as $key) {
			if ($keyFilter != "") $keyFilter .= " OR ";
			if ($setCurrent)
				$this->infoid->CurrentValue = $key;
			else
				$this->infoid->OldValue = $key;
			$keyFilter .= "(" . $this->getRecordFilter() . ")";
		}
		return $keyFilter;
	}

	// Load rows based on filter
	public function &loadRs($filter)
	{

		// Set up filter (WHERE Clause)
		$sql = $this->getSql($filter);
		$conn = $this->getConnection();
		$rs = $conn->execute($sql);
		return $rs;
	}

	// Load row values from recordset
	public function loadListRowValues(&$rs)
	{
		$this->infoid->setDbValue($rs->fields('infoid'));
		$this->_userid->setDbValue($rs->fields('userid'));
		$this->externalrefid->setDbValue($rs->fields('externalrefid'));
		$this->currcode->setDbValue($rs->fields('currcode'));
		$this->sampleloantype->setDbValue($rs->fields('sampleloantype'));
		$this->sampleamount->setDbValue($rs->fields('sampleamount'));
		$this->sampleamountforfeecalculation->setDbValue($rs->fields('sampleamountforfeecalculation'));
		$this->eligibleamount->setDbValue($rs->fields('eligibleamount'));
		$this->outstandingloanprinciple->setDbValue($rs->fields('outstandingloanprinciple'));
		$this->outstandingloanfees->setDbValue($rs->fields('outstandingloanfees'));
		$this->availableforloan->setDbValue($rs->fields('availableforloan'));
		$this->status->setDbValue($rs->fields('status'));
		$this->optin->setDbValue($rs->fields('optin'));
		$this->sampleloanfeespretax->setDbValue($rs->fields('sampleloanfeespretax'));
		$this->feetaxpercentage->setDbValue($rs->fields('feetaxpercentage'));
		$this->feetaxamount->setDbValue($rs->fields('feetaxamount'));
		$this->sampleloanfeesposttax->setDbValue($rs->fields('sampleloanfeesposttax'));
		$this->feesystemtotal->setDbValue($rs->fields('feesystemtotal'));
		$this->feeexternaltotal->setDbValue($rs->fields('feeexternaltotal'));
		$this->feefranchiseetotal->setDbValue($rs->fields('feefranchiseetotal'));
		$this->feeresellertotal->setDbValue($rs->fields('feeresellertotal'));
		$this->outstandingloan->setDbValue($rs->fields('outstandingloan'));
		$this->outstandingloanlatefees->setDbValue($rs->fields('outstandingloanlatefees'));
		$this->intent->setDbValue($rs->fields('intent'));
		$this->msg->setDbValue($rs->fields('msg'));
		$this->infotime->setDbValue($rs->fields('infotime'));
	}

	// Render list row values
	public function renderListRow()
	{
		global $Security, $CurrentLanguage, $Language;

		// Call Row Rendering event
		$this->Row_Rendering();

		// Common render codes
		// infoid
		// userid
		// externalrefid
		// currcode
		// sampleloantype
		// sampleamount
		// sampleamountforfeecalculation
		// eligibleamount
		// outstandingloanprinciple
		// outstandingloanfees
		// availableforloan
		// status
		// optin
		// sampleloanfeespretax
		// feetaxpercentage
		// feetaxamount
		// sampleloanfeesposttax
		// feesystemtotal
		// feeexternaltotal
		// feefranchiseetotal
		// feeresellertotal
		// outstandingloan
		// outstandingloanlatefees
		// intent
		// msg
		// infotime
		// infoid

		$this->infoid->ViewValue = $this->infoid->CurrentValue;
		$this->infoid->ViewCustomAttributes = "";

		// userid
		$this->_userid->ViewValue = $this->_userid->CurrentValue;
		$this->_userid->ViewCustomAttributes = "";

		// externalrefid
		$this->externalrefid->ViewValue = $this->externalrefid->CurrentValue;
		$this->externalrefid->ViewCustomAttributes = "";

		// currcode
		$this->currcode->ViewValue = $this->currcode->CurrentValue;
		$this->currcode->ViewCustomAttributes = "";

		// sampleloantype
		$this->sampleloantype->ViewValue = $this->sampleloantype->CurrentValue;
		$this->sampleloantype->ViewCustomAttributes = "";

		// sampleamount
		$this->sampleamount->ViewValue = $this->sampleamount->CurrentValue;
		$this->sampleamount->ViewValue = FormatNumber($this->sampleamount->ViewValue, Config("DEFAULT_DECIMAL_PRECISION"));
		$this->sampleamount->ViewCustomAttributes = "";

		// sampleamountforfeecalculation
		$this->sampleamountforfeecalculation->ViewValue = $this->sampleamountforfeecalculation->CurrentValue;
		$this->sampleamountforfeecalculation->ViewValue = FormatNumber($this->sampleamountforfeecalculation->ViewValue, Config("DEFAULT_DECIMAL_PRECISION"));
		$this->sampleamountforfeecalculation->ViewCustomAttributes = "";

		// eligibleamount
		$this->eligibleamount->ViewValue = $this->eligibleamount->CurrentValue;
		$this->eligibleamount->ViewValue = FormatNumber($this->eligibleamount->ViewValue, Config("DEFAULT_DECIMAL_PRECISION"));
		$this->eligibleamount->ViewCustomAttributes = "";

		// outstandingloanprinciple
		$this->outstandingloanprinciple->ViewValue = $this->outstandingloanprinciple->CurrentValue;
		$this->outstandingloanprinciple->ViewValue = FormatNumber($this->outstandingloanprinciple->ViewValue, Config("DEFAULT_DECIMAL_PRECISION"));
		$this->outstandingloanprinciple->ViewCustomAttributes = "";

		// outstandingloanfees
		$this->outstandingloanfees->ViewValue = $this->outstandingloanfees->CurrentValue;
		$this->outstandingloanfees->ViewValue = FormatNumber($this->outstandingloanfees->ViewValue, Config("DEFAULT_DECIMAL_PRECISION"));
		$this->outstandingloanfees->ViewCustomAttributes = "";

		// availableforloan
		$this->availableforloan->ViewValue = $this->availableforloan->CurrentValue;
		$this->availableforloan->ViewValue = FormatNumber($this->availableforloan->ViewValue, Config("DEFAULT_DECIMAL_PRECISION"));
		$this->availableforloan->ViewCustomAttributes = "";

		// status
		$this->status->ViewValue = $this->status->CurrentValue;
		$this->status->ViewCustomAttributes = "";

		// optin
		$this->optin->ViewValue = $this->optin->CurrentValue;
		$this->optin->ViewCustomAttributes = "";

		// sampleloanfeespretax
		$this->sampleloanfeespretax->ViewValue = $this->sampleloanfeespretax->CurrentValue;
		$this->sampleloanfeespretax->ViewValue = FormatNumber($this->sampleloanfeespretax->ViewValue, Config("DEFAULT_DECIMAL_PRECISION"));
		$this->sampleloanfeespretax->ViewCustomAttributes = "";

		// feetaxpercentage
		$this->feetaxpercentage->ViewValue = $this->feetaxpercentage->CurrentValue;
		$this->feetaxpercentage->ViewValue = FormatNumber($this->feetaxpercentage->ViewValue, Config("DEFAULT_DECIMAL_PRECISION"));
		$this->feetaxpercentage->ViewCustomAttributes = "";

		// feetaxamount
		$this->feetaxamount->ViewValue = $this->feetaxamount->CurrentValue;
		$this->feetaxamount->ViewValue = FormatNumber($this->feetaxamount->ViewValue, Config("DEFAULT_DECIMAL_PRECISION"));
		$this->feetaxamount->ViewCustomAttributes = "";

		// sampleloanfeesposttax
		$this->sampleloanfeesposttax->ViewValue = $this->sampleloanfeesposttax->CurrentValue;
		$this->sampleloanfeesposttax->ViewValue = FormatNumber($this->sampleloanfeesposttax->ViewValue, Config("DEFAULT_DECIMAL_PRECISION"));
		$this->sampleloanfeesposttax->ViewCustomAttributes = "";

		// feesystemtotal
		$this->feesystemtotal->ViewValue = $this->feesystemtotal->CurrentValue;
		$this->feesystemtotal->ViewValue = FormatNumber($this->feesystemtotal->ViewValue, Config("DEFAULT_DECIMAL_PRECISION"));
		$this->feesystemtotal->ViewCustomAttributes = "";

		// feeexternaltotal
		$this->feeexternaltotal->ViewValue = $this->feeexternaltotal->CurrentValue;
		$this->feeexternaltotal->ViewValue = FormatNumber($this->feeexternaltotal->ViewValue, Config("DEFAULT_DECIMAL_PRECISION"));
		$this->feeexternaltotal->ViewCustomAttributes = "";

		// feefranchiseetotal
		$this->feefranchiseetotal->ViewValue = $this->feefranchiseetotal->CurrentValue;
		$this->feefranchiseetotal->ViewValue = FormatNumber($this->feefranchiseetotal->ViewValue, Config("DEFAULT_DECIMAL_PRECISION"));
		$this->feefranchiseetotal->ViewCustomAttributes = "";

		// feeresellertotal
		$this->feeresellertotal->ViewValue = $this->feeresellertotal->CurrentValue;
		$this->feeresellertotal->ViewValue = FormatNumber($this->feeresellertotal->ViewValue, Config("DEFAULT_DECIMAL_PRECISION"));
		$this->feeresellertotal->ViewCustomAttributes = "";

		// outstandingloan
		$this->outstandingloan->ViewValue = $this->outstandingloan->CurrentValue;
		$this->outstandingloan->ViewValue = FormatNumber($this->outstandingloan->ViewValue, 2, -2, -2, -2);
		$this->outstandingloan->ViewCustomAttributes = "";

		// outstandingloanlatefees
		$this->outstandingloanlatefees->ViewValue = $this->outstandingloanlatefees->CurrentValue;
		$this->outstandingloanlatefees->ViewValue = FormatNumber($this->outstandingloanlatefees->ViewValue, 2, -2, -2, -2);
		$this->outstandingloanlatefees->ViewCustomAttributes = "";

		// intent
		$this->intent->ViewValue = $this->intent->CurrentValue;
		$this->intent->ViewCustomAttributes = "";

		// msg
		$this->msg->ViewValue = $this->msg->CurrentValue;
		$this->msg->ViewCustomAttributes = "";

		// infotime
		$this->infotime->ViewValue = $this->infotime->CurrentValue;
		$this->infotime->ViewValue = FormatDateTime($this->infotime->ViewValue, 0);
		$this->infotime->ViewCustomAttributes = "";

		// infoid
		$this->infoid->LinkCustomAttributes = "";
		$this->infoid->HrefValue = "";
		$this->infoid->TooltipValue = "";

		// userid
		$this->_userid->LinkCustomAttributes = "";
		$this->_userid->HrefValue = "";
		$this->_userid->TooltipValue = "";

		// externalrefid
		$this->externalrefid->LinkCustomAttributes = "";
		$this->externalrefid->HrefValue = "";
		$this->externalrefid->TooltipValue = "";

		// currcode
		$this->currcode->LinkCustomAttributes = "";
		$this->currcode->HrefValue = "";
		$this->currcode->TooltipValue = "";

		// sampleloantype
		$this->sampleloantype->LinkCustomAttributes = "";
		$this->sampleloantype->HrefValue = "";
		$this->sampleloantype->TooltipValue = "";

		// sampleamount
		$this->sampleamount->LinkCustomAttributes = "";
		$this->sampleamount->HrefValue = "";
		$this->sampleamount->TooltipValue = "";

		// sampleamountforfeecalculation
		$this->sampleamountforfeecalculation->LinkCustomAttributes = "";
		$this->sampleamountforfeecalculation->HrefValue = "";
		$this->sampleamountforfeecalculation->TooltipValue = "";

		// eligibleamount
		$this->eligibleamount->LinkCustomAttributes = "";
		$this->eligibleamount->HrefValue = "";
		$this->eligibleamount->TooltipValue = "";

		// outstandingloanprinciple
		$this->outstandingloanprinciple->LinkCustomAttributes = "";
		$this->outstandingloanprinciple->HrefValue = "";
		$this->outstandingloanprinciple->TooltipValue = "";

		// outstandingloanfees
		$this->outstandingloanfees->LinkCustomAttributes = "";
		$this->outstandingloanfees->HrefValue = "";
		$this->outstandingloanfees->TooltipValue = "";

		// availableforloan
		$this->availableforloan->LinkCustomAttributes = "";
		$this->availableforloan->HrefValue = "";
		$this->availableforloan->TooltipValue = "";

		// status
		$this->status->LinkCustomAttributes = "";
		$this->status->HrefValue = "";
		$this->status->TooltipValue = "";

		// optin
		$this->optin->LinkCustomAttributes = "";
		$this->optin->HrefValue = "";
		$this->optin->TooltipValue = "";

		// sampleloanfeespretax
		$this->sampleloanfeespretax->LinkCustomAttributes = "";
		$this->sampleloanfeespretax->HrefValue = "";
		$this->sampleloanfeespretax->TooltipValue = "";

		// feetaxpercentage
		$this->feetaxpercentage->LinkCustomAttributes = "";
		$this->feetaxpercentage->HrefValue = "";
		$this->feetaxpercentage->TooltipValue = "";

		// feetaxamount
		$this->feetaxamount->LinkCustomAttributes = "";
		$this->feetaxamount->HrefValue = "";
		$this->feetaxamount->TooltipValue = "";

		// sampleloanfeesposttax
		$this->sampleloanfeesposttax->LinkCustomAttributes = "";
		$this->sampleloanfeesposttax->HrefValue = "";
		$this->sampleloanfeesposttax->TooltipValue = "";

		// feesystemtotal
		$this->feesystemtotal->LinkCustomAttributes = "";
		$this->feesystemtotal->HrefValue = "";
		$this->feesystemtotal->TooltipValue = "";

		// feeexternaltotal
		$this->feeexternaltotal->LinkCustomAttributes = "";
		$this->feeexternaltotal->HrefValue = "";
		$this->feeexternaltotal->TooltipValue = "";

		// feefranchiseetotal
		$this->feefranchiseetotal->LinkCustomAttributes = "";
		$this->feefranchiseetotal->HrefValue = "";
		$this->feefranchiseetotal->TooltipValue = "";

		// feeresellertotal
		$this->feeresellertotal->LinkCustomAttributes = "";
		$this->feeresellertotal->HrefValue = "";
		$this->feeresellertotal->TooltipValue = "";

		// outstandingloan
		$this->outstandingloan->LinkCustomAttributes = "";
		$this->outstandingloan->HrefValue = "";
		$this->outstandingloan->TooltipValue = "";

		// outstandingloanlatefees
		$this->outstandingloanlatefees->LinkCustomAttributes = "";
		$this->outstandingloanlatefees->HrefValue = "";
		$this->outstandingloanlatefees->TooltipValue = "";

		// intent
		$this->intent->LinkCustomAttributes = "";
		$this->intent->HrefValue = "";
		$this->intent->TooltipValue = "";

		// msg
		$this->msg->LinkCustomAttributes = "";
		$this->msg->HrefValue = "";
		$this->msg->TooltipValue = "";

		// infotime
		$this->infotime->LinkCustomAttributes = "";
		$this->infotime->HrefValue = "";
		$this->infotime->TooltipValue = "";

		// Call Row Rendered event
		$this->Row_Rendered();

		// Save data for Custom Template
		$this->Rows[] = $this->customTemplateFieldValues();
	}

	// Render edit row values
	public function renderEditRow()
	{
		global $Security, $CurrentLanguage, $Language;

		// Call Row Rendering event
		$this->Row_Rendering();

		// infoid
		$this->infoid->EditAttrs["class"] = "form-control";
		$this->infoid->EditCustomAttributes = "";
		$this->infoid->EditValue = $this->infoid->CurrentValue;
		$this->infoid->ViewCustomAttributes = "";

		// userid
		$this->_userid->EditAttrs["class"] = "form-control";
		$this->_userid->EditCustomAttributes = "";
		$this->_userid->EditValue = $this->_userid->CurrentValue;
		$this->_userid->PlaceHolder = RemoveHtml($this->_userid->caption());

		// externalrefid
		$this->externalrefid->EditAttrs["class"] = "form-control";
		$this->externalrefid->EditCustomAttributes = "";
		if (!$this->externalrefid->Raw)
			$this->externalrefid->CurrentValue = HtmlDecode($this->externalrefid->CurrentValue);
		$this->externalrefid->EditValue = $this->externalrefid->CurrentValue;
		$this->externalrefid->PlaceHolder = RemoveHtml($this->externalrefid->caption());

		// currcode
		$this->currcode->EditAttrs["class"] = "form-control";
		$this->currcode->EditCustomAttributes = "";
		if (!$this->currcode->Raw)
			$this->currcode->CurrentValue = HtmlDecode($this->currcode->CurrentValue);
		$this->currcode->EditValue = $this->currcode->CurrentValue;
		$this->currcode->PlaceHolder = RemoveHtml($this->currcode->caption());

		// sampleloantype
		$this->sampleloantype->EditAttrs["class"] = "form-control";
		$this->sampleloantype->EditCustomAttributes = "";
		$this->sampleloantype->EditValue = $this->sampleloantype->CurrentValue;
		$this->sampleloantype->PlaceHolder = RemoveHtml($this->sampleloantype->caption());

		// sampleamount
		$this->sampleamount->EditAttrs["class"] = "form-control";
		$this->sampleamount->EditCustomAttributes = "";
		$this->sampleamount->EditValue = $this->sampleamount->CurrentValue;
		$this->sampleamount->PlaceHolder = RemoveHtml($this->sampleamount->caption());
		if (strval($this->sampleamount->EditValue) != "" && is_numeric($this->sampleamount->EditValue))
			$this->sampleamount->EditValue = FormatNumber($this->sampleamount->EditValue, -2, -1, -2, 0);
		

		// sampleamountforfeecalculation
		$this->sampleamountforfeecalculation->EditAttrs["class"] = "form-control";
		$this->sampleamountforfeecalculation->EditCustomAttributes = "";
		$this->sampleamountforfeecalculation->EditValue = $this->sampleamountforfeecalculation->CurrentValue;
		$this->sampleamountforfeecalculation->PlaceHolder = RemoveHtml($this->sampleamountforfeecalculation->caption());
		if (strval($this->sampleamountforfeecalculation->EditValue) != "" && is_numeric($this->sampleamountforfeecalculation->EditValue))
			$this->sampleamountforfeecalculation->EditValue = FormatNumber($this->sampleamountforfeecalculation->EditValue, -2, -1, -2, 0);
		

		// eligibleamount
		$this->eligibleamount->EditAttrs["class"] = "form-control";
		$this->eligibleamount->EditCustomAttributes = "";
		$this->eligibleamount->EditValue = $this->eligibleamount->CurrentValue;
		$this->eligibleamount->PlaceHolder = RemoveHtml($this->eligibleamount->caption());
		if (strval($this->eligibleamount->EditValue) != "" && is_numeric($this->eligibleamount->EditValue))
			$this->eligibleamount->EditValue = FormatNumber($this->eligibleamount->EditValue, -2, -1, -2, 0);
		

		// outstandingloanprinciple
		$this->outstandingloanprinciple->EditAttrs["class"] = "form-control";
		$this->outstandingloanprinciple->EditCustomAttributes = "";
		$this->outstandingloanprinciple->EditValue = $this->outstandingloanprinciple->CurrentValue;
		$this->outstandingloanprinciple->PlaceHolder = RemoveHtml($this->outstandingloanprinciple->caption());
		if (strval($this->outstandingloanprinciple->EditValue) != "" && is_numeric($this->outstandingloanprinciple->EditValue))
			$this->outstandingloanprinciple->EditValue = FormatNumber($this->outstandingloanprinciple->EditValue, -2, -1, -2, 0);
		

		// outstandingloanfees
		$this->outstandingloanfees->EditAttrs["class"] = "form-control";
		$this->outstandingloanfees->EditCustomAttributes = "";
		$this->outstandingloanfees->EditValue = $this->outstandingloanfees->CurrentValue;
		$this->outstandingloanfees->PlaceHolder = RemoveHtml($this->outstandingloanfees->caption());
		if (strval($this->outstandingloanfees->EditValue) != "" && is_numeric($this->outstandingloanfees->EditValue))
			$this->outstandingloanfees->EditValue = FormatNumber($this->outstandingloanfees->EditValue, -2, -1, -2, 0);
		

		// availableforloan
		$this->availableforloan->EditAttrs["class"] = "form-control";
		$this->availableforloan->EditCustomAttributes = "";
		$this->availableforloan->EditValue = $this->availableforloan->CurrentValue;
		$this->availableforloan->PlaceHolder = RemoveHtml($this->availableforloan->caption());
		if (strval($this->availableforloan->EditValue) != "" && is_numeric($this->availableforloan->EditValue))
			$this->availableforloan->EditValue = FormatNumber($this->availableforloan->EditValue, -2, -1, -2, 0);
		

		// status
		$this->status->EditAttrs["class"] = "form-control";
		$this->status->EditCustomAttributes = "";
		$this->status->EditValue = $this->status->CurrentValue;
		$this->status->PlaceHolder = RemoveHtml($this->status->caption());

		// optin
		$this->optin->EditAttrs["class"] = "form-control";
		$this->optin->EditCustomAttributes = "";
		$this->optin->EditValue = $this->optin->CurrentValue;
		$this->optin->PlaceHolder = RemoveHtml($this->optin->caption());

		// sampleloanfeespretax
		$this->sampleloanfeespretax->EditAttrs["class"] = "form-control";
		$this->sampleloanfeespretax->EditCustomAttributes = "";
		$this->sampleloanfeespretax->EditValue = $this->sampleloanfeespretax->CurrentValue;
		$this->sampleloanfeespretax->PlaceHolder = RemoveHtml($this->sampleloanfeespretax->caption());
		if (strval($this->sampleloanfeespretax->EditValue) != "" && is_numeric($this->sampleloanfeespretax->EditValue))
			$this->sampleloanfeespretax->EditValue = FormatNumber($this->sampleloanfeespretax->EditValue, -2, -1, -2, 0);
		

		// feetaxpercentage
		$this->feetaxpercentage->EditAttrs["class"] = "form-control";
		$this->feetaxpercentage->EditCustomAttributes = "";
		$this->feetaxpercentage->EditValue = $this->feetaxpercentage->CurrentValue;
		$this->feetaxpercentage->PlaceHolder = RemoveHtml($this->feetaxpercentage->caption());
		if (strval($this->feetaxpercentage->EditValue) != "" && is_numeric($this->feetaxpercentage->EditValue))
			$this->feetaxpercentage->EditValue = FormatNumber($this->feetaxpercentage->EditValue, -2, -1, -2, 0);
		

		// feetaxamount
		$this->feetaxamount->EditAttrs["class"] = "form-control";
		$this->feetaxamount->EditCustomAttributes = "";
		$this->feetaxamount->EditValue = $this->feetaxamount->CurrentValue;
		$this->feetaxamount->PlaceHolder = RemoveHtml($this->feetaxamount->caption());
		if (strval($this->feetaxamount->EditValue) != "" && is_numeric($this->feetaxamount->EditValue))
			$this->feetaxamount->EditValue = FormatNumber($this->feetaxamount->EditValue, -2, -1, -2, 0);
		

		// sampleloanfeesposttax
		$this->sampleloanfeesposttax->EditAttrs["class"] = "form-control";
		$this->sampleloanfeesposttax->EditCustomAttributes = "";
		$this->sampleloanfeesposttax->EditValue = $this->sampleloanfeesposttax->CurrentValue;
		$this->sampleloanfeesposttax->PlaceHolder = RemoveHtml($this->sampleloanfeesposttax->caption());
		if (strval($this->sampleloanfeesposttax->EditValue) != "" && is_numeric($this->sampleloanfeesposttax->EditValue))
			$this->sampleloanfeesposttax->EditValue = FormatNumber($this->sampleloanfeesposttax->EditValue, -2, -1, -2, 0);
		

		// feesystemtotal
		$this->feesystemtotal->EditAttrs["class"] = "form-control";
		$this->feesystemtotal->EditCustomAttributes = "";
		$this->feesystemtotal->EditValue = $this->feesystemtotal->CurrentValue;
		$this->feesystemtotal->PlaceHolder = RemoveHtml($this->feesystemtotal->caption());
		if (strval($this->feesystemtotal->EditValue) != "" && is_numeric($this->feesystemtotal->EditValue))
			$this->feesystemtotal->EditValue = FormatNumber($this->feesystemtotal->EditValue, -2, -1, -2, 0);
		

		// feeexternaltotal
		$this->feeexternaltotal->EditAttrs["class"] = "form-control";
		$this->feeexternaltotal->EditCustomAttributes = "";
		$this->feeexternaltotal->EditValue = $this->feeexternaltotal->CurrentValue;
		$this->feeexternaltotal->PlaceHolder = RemoveHtml($this->feeexternaltotal->caption());
		if (strval($this->feeexternaltotal->EditValue) != "" && is_numeric($this->feeexternaltotal->EditValue))
			$this->feeexternaltotal->EditValue = FormatNumber($this->feeexternaltotal->EditValue, -2, -1, -2, 0);
		

		// feefranchiseetotal
		$this->feefranchiseetotal->EditAttrs["class"] = "form-control";
		$this->feefranchiseetotal->EditCustomAttributes = "";
		$this->feefranchiseetotal->EditValue = $this->feefranchiseetotal->CurrentValue;
		$this->feefranchiseetotal->PlaceHolder = RemoveHtml($this->feefranchiseetotal->caption());
		if (strval($this->feefranchiseetotal->EditValue) != "" && is_numeric($this->feefranchiseetotal->EditValue))
			$this->feefranchiseetotal->EditValue = FormatNumber($this->feefranchiseetotal->EditValue, -2, -1, -2, 0);
		

		// feeresellertotal
		$this->feeresellertotal->EditAttrs["class"] = "form-control";
		$this->feeresellertotal->EditCustomAttributes = "";
		$this->feeresellertotal->EditValue = $this->feeresellertotal->CurrentValue;
		$this->feeresellertotal->PlaceHolder = RemoveHtml($this->feeresellertotal->caption());
		if (strval($this->feeresellertotal->EditValue) != "" && is_numeric($this->feeresellertotal->EditValue))
			$this->feeresellertotal->EditValue = FormatNumber($this->feeresellertotal->EditValue, -2, -1, -2, 0);
		

		// outstandingloan
		$this->outstandingloan->EditAttrs["class"] = "form-control";
		$this->outstandingloan->EditCustomAttributes = "";
		$this->outstandingloan->EditValue = $this->outstandingloan->CurrentValue;
		$this->outstandingloan->PlaceHolder = RemoveHtml($this->outstandingloan->caption());
		if (strval($this->outstandingloan->EditValue) != "" && is_numeric($this->outstandingloan->EditValue))
			$this->outstandingloan->EditValue = FormatNumber($this->outstandingloan->EditValue, -2, -2, -2, -2);
		

		// outstandingloanlatefees
		$this->outstandingloanlatefees->EditAttrs["class"] = "form-control";
		$this->outstandingloanlatefees->EditCustomAttributes = "";
		$this->outstandingloanlatefees->EditValue = $this->outstandingloanlatefees->CurrentValue;
		$this->outstandingloanlatefees->PlaceHolder = RemoveHtml($this->outstandingloanlatefees->caption());
		if (strval($this->outstandingloanlatefees->EditValue) != "" && is_numeric($this->outstandingloanlatefees->EditValue))
			$this->outstandingloanlatefees->EditValue = FormatNumber($this->outstandingloanlatefees->EditValue, -2, -2, -2, -2);
		

		// intent
		$this->intent->EditAttrs["class"] = "form-control";
		$this->intent->EditCustomAttributes = "";
		if (!$this->intent->Raw)
			$this->intent->CurrentValue = HtmlDecode($this->intent->CurrentValue);
		$this->intent->EditValue = $this->intent->CurrentValue;
		$this->intent->PlaceHolder = RemoveHtml($this->intent->caption());

		// msg
		$this->msg->EditAttrs["class"] = "form-control";
		$this->msg->EditCustomAttributes = "";
		if (!$this->msg->Raw)
			$this->msg->CurrentValue = HtmlDecode($this->msg->CurrentValue);
		$this->msg->EditValue = $this->msg->CurrentValue;
		$this->msg->PlaceHolder = RemoveHtml($this->msg->caption());

		// infotime
		$this->infotime->EditAttrs["class"] = "form-control";
		$this->infotime->EditCustomAttributes = "";
		$this->infotime->EditValue = FormatDateTime($this->infotime->CurrentValue, 8);
		$this->infotime->PlaceHolder = RemoveHtml($this->infotime->caption());

		// Call Row Rendered event
		$this->Row_Rendered();
	}

	// Aggregate list row values
	public function aggregateListRowValues()
	{
	}

	// Aggregate list row (for rendering)
	public function aggregateListRow()
	{

		// Call Row Rendered event
		$this->Row_Rendered();
	}

	// Export data in HTML/CSV/Word/Excel/Email/PDF format
	public function exportDocument($doc, $recordset, $startRec = 1, $stopRec = 1, $exportPageType = "")
	{
		if (!$recordset || !$doc)
			return;
		if (!$doc->ExportCustom) {

			// Write header
			$doc->exportTableHeader();
			if ($doc->Horizontal) { // Horizontal format, write header
				$doc->beginExportRow();
				if ($exportPageType == "view") {
					$doc->exportCaption($this->infoid);
					$doc->exportCaption($this->_userid);
					$doc->exportCaption($this->externalrefid);
					$doc->exportCaption($this->currcode);
					$doc->exportCaption($this->sampleloantype);
					$doc->exportCaption($this->sampleamount);
					$doc->exportCaption($this->sampleamountforfeecalculation);
					$doc->exportCaption($this->eligibleamount);
					$doc->exportCaption($this->outstandingloanprinciple);
					$doc->exportCaption($this->outstandingloanfees);
					$doc->exportCaption($this->availableforloan);
					$doc->exportCaption($this->status);
					$doc->exportCaption($this->optin);
					$doc->exportCaption($this->sampleloanfeespretax);
					$doc->exportCaption($this->feetaxpercentage);
					$doc->exportCaption($this->feetaxamount);
					$doc->exportCaption($this->sampleloanfeesposttax);
					$doc->exportCaption($this->feesystemtotal);
					$doc->exportCaption($this->feeexternaltotal);
					$doc->exportCaption($this->feefranchiseetotal);
					$doc->exportCaption($this->feeresellertotal);
					$doc->exportCaption($this->outstandingloan);
					$doc->exportCaption($this->outstandingloanlatefees);
					$doc->exportCaption($this->intent);
					$doc->exportCaption($this->msg);
					$doc->exportCaption($this->infotime);
				} else {
					$doc->exportCaption($this->infoid);
					$doc->exportCaption($this->_userid);
					$doc->exportCaption($this->externalrefid);
					$doc->exportCaption($this->currcode);
					$doc->exportCaption($this->sampleloantype);
					$doc->exportCaption($this->sampleamount);
					$doc->exportCaption($this->sampleamountforfeecalculation);
					$doc->exportCaption($this->eligibleamount);
					$doc->exportCaption($this->outstandingloanprinciple);
					$doc->exportCaption($this->outstandingloanfees);
					$doc->exportCaption($this->availableforloan);
					$doc->exportCaption($this->status);
					$doc->exportCaption($this->optin);
					$doc->exportCaption($this->sampleloanfeespretax);
					$doc->exportCaption($this->feetaxpercentage);
					$doc->exportCaption($this->feetaxamount);
					$doc->exportCaption($this->sampleloanfeesposttax);
					$doc->exportCaption($this->feesystemtotal);
					$doc->exportCaption($this->feeexternaltotal);
					$doc->exportCaption($this->feefranchiseetotal);
					$doc->exportCaption($this->feeresellertotal);
					$doc->exportCaption($this->outstandingloan);
					$doc->exportCaption($this->outstandingloanlatefees);
					$doc->exportCaption($this->intent);
					$doc->exportCaption($this->msg);
					$doc->exportCaption($this->infotime);
				}
				$doc->endExportRow();
			}
		}

		// Move to first record
		$recCnt = $startRec - 1;
		if (!$recordset->EOF) {
			$recordset->moveFirst();
			if ($startRec > 1)
				$recordset->move($startRec - 1);
		}
		while (!$recordset->EOF && $recCnt < $stopRec) {
			$recCnt++;
			if ($recCnt >= $startRec) {
				$rowCnt = $recCnt - $startRec + 1;

				// Page break
				if ($this->ExportPageBreakCount > 0) {
					if ($rowCnt > 1 && ($rowCnt - 1) % $this->ExportPageBreakCount == 0)
						$doc->exportPageBreak();
				}
				$this->loadListRowValues($recordset);

				// Render row
				$this->RowType = ROWTYPE_VIEW; // Render view
				$this->resetAttributes();
				$this->renderListRow();
				if (!$doc->ExportCustom) {
					$doc->beginExportRow($rowCnt); // Allow CSS styles if enabled
					if ($exportPageType == "view") {
						$doc->exportField($this->infoid);
						$doc->exportField($this->_userid);
						$doc->exportField($this->externalrefid);
						$doc->exportField($this->currcode);
						$doc->exportField($this->sampleloantype);
						$doc->exportField($this->sampleamount);
						$doc->exportField($this->sampleamountforfeecalculation);
						$doc->exportField($this->eligibleamount);
						$doc->exportField($this->outstandingloanprinciple);
						$doc->exportField($this->outstandingloanfees);
						$doc->exportField($this->availableforloan);
						$doc->exportField($this->status);
						$doc->exportField($this->optin);
						$doc->exportField($this->sampleloanfeespretax);
						$doc->exportField($this->feetaxpercentage);
						$doc->exportField($this->feetaxamount);
						$doc->exportField($this->sampleloanfeesposttax);
						$doc->exportField($this->feesystemtotal);
						$doc->exportField($this->feeexternaltotal);
						$doc->exportField($this->feefranchiseetotal);
						$doc->exportField($this->feeresellertotal);
						$doc->exportField($this->outstandingloan);
						$doc->exportField($this->outstandingloanlatefees);
						$doc->exportField($this->intent);
						$doc->exportField($this->msg);
						$doc->exportField($this->infotime);
					} else {
						$doc->exportField($this->infoid);
						$doc->exportField($this->_userid);
						$doc->exportField($this->externalrefid);
						$doc->exportField($this->currcode);
						$doc->exportField($this->sampleloantype);
						$doc->exportField($this->sampleamount);
						$doc->exportField($this->sampleamountforfeecalculation);
						$doc->exportField($this->eligibleamount);
						$doc->exportField($this->outstandingloanprinciple);
						$doc->exportField($this->outstandingloanfees);
						$doc->exportField($this->availableforloan);
						$doc->exportField($this->status);
						$doc->exportField($this->optin);
						$doc->exportField($this->sampleloanfeespretax);
						$doc->exportField($this->feetaxpercentage);
						$doc->exportField($this->feetaxamount);
						$doc->exportField($this->sampleloanfeesposttax);
						$doc->exportField($this->feesystemtotal);
						$doc->exportField($this->feeexternaltotal);
						$doc->exportField($this->feefranchiseetotal);
						$doc->exportField($this->feeresellertotal);
						$doc->exportField($this->outstandingloan);
						$doc->exportField($this->outstandingloanlatefees);
						$doc->exportField($this->intent);
						$doc->exportField($this->msg);
						$doc->exportField($this->infotime);
					}
					$doc->endExportRow($rowCnt);
				}
			}

			// Call Row Export server event
			if ($doc->ExportCustom)
				$this->Row_Export($recordset->fields);
			$recordset->moveNext();
		}
		if (!$doc->ExportCustom) {
			$doc->exportTableFooter();
		}
	}

	// Get file data
	public function getFileData($fldparm, $key, $resize, $width = 0, $height = 0)
	{

		// No binary fields
		return FALSE;
	}

	// Write Audit Trail start/end for grid update
	public function writeAuditTrailDummy($typ)
	{
		$table = 'loaninfohistory';
		$usr = CurrentUserName();
		WriteAuditTrail("log", DbCurrentDateTime(), ScriptName(), $usr, $typ, $table, "", "", "", "");
	}

	// Write Audit Trail (add page)
	public function writeAuditTrailOnAdd(&$rs)
	{
		global $Language;
		if (!$this->AuditTrailOnAdd)
			return;
		$table = 'loaninfohistory';

		// Get key value
		$key = "";
		if ($key != "")
			$key .= Config("COMPOSITE_KEY_SEPARATOR");
		$key .= $rs['infoid'];

		// Write Audit Trail
		$dt = DbCurrentDateTime();
		$id = ScriptName();
		$usr = CurrentUserName();
		foreach (array_keys($rs) as $fldname) {
			if (array_key_exists($fldname, $this->fields) && $this->fields[$fldname]->DataType != DATATYPE_BLOB) { // Ignore BLOB fields
				if ($this->fields[$fldname]->HtmlTag == "PASSWORD") {
					$newvalue = $Language->phrase("PasswordMask"); // Password Field
				} elseif ($this->fields[$fldname]->DataType == DATATYPE_MEMO) {
					if (Config("AUDIT_TRAIL_TO_DATABASE"))
						$newvalue = $rs[$fldname];
					else
						$newvalue = "[MEMO]"; // Memo Field
				} elseif ($this->fields[$fldname]->DataType == DATATYPE_XML) {
					$newvalue = "[XML]"; // XML Field
				} else {
					$newvalue = $rs[$fldname];
				}
				WriteAuditTrail("log", $dt, $id, $usr, "A", $table, $fldname, $key, "", $newvalue);
			}
		}
	}

	// Write Audit Trail (edit page)
	public function writeAuditTrailOnEdit(&$rsold, &$rsnew)
	{
		global $Language;
		if (!$this->AuditTrailOnEdit)
			return;
		$table = 'loaninfohistory';

		// Get key value
		$key = "";
		if ($key != "")
			$key .= Config("COMPOSITE_KEY_SEPARATOR");
		$key .= $rsold['infoid'];

		// Write Audit Trail
		$dt = DbCurrentDateTime();
		$id = ScriptName();
		$usr = CurrentUserName();
		foreach (array_keys($rsnew) as $fldname) {
			if (array_key_exists($fldname, $this->fields) && array_key_exists($fldname, $rsold) && $this->fields[$fldname]->DataType != DATATYPE_BLOB) { // Ignore BLOB fields
				if ($this->fields[$fldname]->DataType == DATATYPE_DATE) { // DateTime field
					$modified = (FormatDateTime($rsold[$fldname], 0) != FormatDateTime($rsnew[$fldname], 0));
				} else {
					$modified = !CompareValue($rsold[$fldname], $rsnew[$fldname]);
				}
				if ($modified) {
					if ($this->fields[$fldname]->HtmlTag == "PASSWORD") { // Password Field
						$oldvalue = $Language->phrase("PasswordMask");
						$newvalue = $Language->phrase("PasswordMask");
					} elseif ($this->fields[$fldname]->DataType == DATATYPE_MEMO) { // Memo field
						if (Config("AUDIT_TRAIL_TO_DATABASE")) {
							$oldvalue = $rsold[$fldname];
							$newvalue = $rsnew[$fldname];
						} else {
							$oldvalue = "[MEMO]";
							$newvalue = "[MEMO]";
						}
					} elseif ($this->fields[$fldname]->DataType == DATATYPE_XML) { // XML field
						$oldvalue = "[XML]";
						$newvalue = "[XML]";
					} else {
						$oldvalue = $rsold[$fldname];
						$newvalue = $rsnew[$fldname];
					}
					WriteAuditTrail("log", $dt, $id, $usr, "U", $table, $fldname, $key, $oldvalue, $newvalue);
				}
			}
		}
	}

	// Write Audit Trail (delete page)
	public function writeAuditTrailOnDelete(&$rs)
	{
		global $Language;
		if (!$this->AuditTrailOnDelete)
			return;
		$table = 'loaninfohistory';

		// Get key value
		$key = "";
		if ($key != "")
			$key .= Config("COMPOSITE_KEY_SEPARATOR");
		$key .= $rs['infoid'];

		// Write Audit Trail
		$dt = DbCurrentDateTime();
		$id = ScriptName();
		$curUser = CurrentUserName();
		foreach (array_keys($rs) as $fldname) {
			if (array_key_exists($fldname, $this->fields) && $this->fields[$fldname]->DataType != DATATYPE_BLOB) { // Ignore BLOB fields
				if ($this->fields[$fldname]->HtmlTag == "PASSWORD") {
					$oldvalue = $Language->phrase("PasswordMask"); // Password Field
				} elseif ($this->fields[$fldname]->DataType == DATATYPE_MEMO) {
					if (Config("AUDIT_TRAIL_TO_DATABASE"))
						$oldvalue = $rs[$fldname];
					else
						$oldvalue = "[MEMO]"; // Memo field
				} elseif ($this->fields[$fldname]->DataType == DATATYPE_XML) {
					$oldvalue = "[XML]"; // XML field
				} else {
					$oldvalue = $rs[$fldname];
				}
				WriteAuditTrail("log", $dt, $id, $curUser, "D", $table, $fldname, $key, $oldvalue, "");
			}
		}
	}

	// Table level events
	// Recordset Selecting event
	function Recordset_Selecting(&$filter) {

		// Enter your code here
	}

	// Recordset Selected event
	function Recordset_Selected(&$rs) {

		//echo "Recordset Selected";
	}

	// Recordset Search Validated event
	function Recordset_SearchValidated() {

		// Example:
		//$this->MyField1->AdvancedSearch->SearchValue = "your search criteria"; // Search value

	}

	// Recordset Searching event
	function Recordset_Searching(&$filter) {

		// Enter your code here
	}

	// Row_Selecting event
	function Row_Selecting(&$filter) {

		// Enter your code here
	}

	// Row Selected event
	function Row_Selected(&$rs) {

		//echo "Row Selected";
	}

	// Row Inserting event
	function Row_Inserting($rsold, &$rsnew) {

		// Enter your code here
		// To cancel, set return value to FALSE

		return TRUE;
	}

	// Row Inserted event
	function Row_Inserted($rsold, &$rsnew) {

		//echo "Row Inserted"
	}

	// Row Updating event
	function Row_Updating($rsold, &$rsnew) {

		// Enter your code here
		// To cancel, set return value to FALSE

		return TRUE;
	}

	// Row Updated event
	function Row_Updated($rsold, &$rsnew) {

		//echo "Row Updated";
	}

	// Row Update Conflict event
	function Row_UpdateConflict($rsold, &$rsnew) {

		// Enter your code here
		// To ignore conflict, set return value to FALSE

		return TRUE;
	}

	// Grid Inserting event
	function Grid_Inserting() {

		// Enter your code here
		// To reject grid insert, set return value to FALSE

		return TRUE;
	}

	// Grid Inserted event
	function Grid_Inserted($rsnew) {

		//echo "Grid Inserted";
	}

	// Grid Updating event
	function Grid_Updating($rsold) {

		// Enter your code here
		// To reject grid update, set return value to FALSE

		return TRUE;
	}

	// Grid Updated event
	function Grid_Updated($rsold, $rsnew) {

		//echo "Grid Updated";
	}

	// Row Deleting event
	function Row_Deleting(&$rs) {

		// Enter your code here
		// To cancel, set return value to False

		return TRUE;
	}

	// Row Deleted event
	function Row_Deleted(&$rs) {

		//echo "Row Deleted";
	}

	// Email Sending event
	function Email_Sending($email, &$args) {

		//var_dump($email); var_dump($args); exit();
		return TRUE;
	}

	// Lookup Selecting event
	function Lookup_Selecting($fld, &$filter) {

		//var_dump($fld->Name, $fld->Lookup, $filter); // Uncomment to view the filter
		// Enter your code here

	}

	// Row Rendering event
	function Row_Rendering() {

		// Enter your code here
	}

	// Row Rendered event
	function Row_Rendered() {

		// To view properties of field class, use:
		//var_dump($this-><FieldName>);

	}

	// User ID Filtering event
	function UserID_Filtering(&$filter) {

		// Enter your code here
	}
}
?>