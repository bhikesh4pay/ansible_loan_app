<?php namespace PHPMaker2020\_4payadmin; ?>
<?php

/**
 * Table class for useritem
 */
class useritem extends DbTable
{
	protected $SqlFrom = "";
	protected $SqlSelect = "";
	protected $SqlSelectList = "";
	protected $SqlWhere = "";
	protected $SqlGroupBy = "";
	protected $SqlHaving = "";
	protected $SqlOrderBy = "";
	public $UseSessionForListSql = TRUE;

	// Column CSS classes
	public $LeftColumnClass = "col-sm-2 col-form-label ew-label";
	public $RightColumnClass = "col-sm-10";
	public $OffsetColumnClass = "col-sm-10 offset-sm-2";
	public $TableLeftColumnClass = "w-col-2";

	// Audit trail
	public $AuditTrailOnAdd = TRUE;
	public $AuditTrailOnEdit = TRUE;
	public $AuditTrailOnDelete = TRUE;
	public $AuditTrailOnView = FALSE;
	public $AuditTrailOnViewData = FALSE;
	public $AuditTrailOnSearch = FALSE;

	// Export
	public $ExportDoc;

	// Fields
	public $recid;
	public $_userid;
	public $userpi;
	public $itemid;
	public $creationdate;
	public $lastupdatedate;
	public $lookup1;
	public $lookup2;
	public $lookup3;
	public $itemdata;
	public $expirytime;
	public $lastusedate;
	public $masterrecid;

	// Constructor
	public function __construct()
	{
		global $Language, $CurrentLanguage;
		parent::__construct();

		// Language object
		if (!isset($Language))
			$Language = new Language();
		$this->TableVar = 'useritem';
		$this->TableName = 'useritem';
		$this->TableType = 'TABLE';

		// Update Table
		$this->UpdateTable = "`useritem`";
		$this->Dbid = 'DB';
		$this->ExportAll = TRUE;
		$this->ExportPageBreakCount = 0; // Page break per every n record (PDF only)
		$this->ExportPageOrientation = "portrait"; // Page orientation (PDF only)
		$this->ExportPageSize = "a4"; // Page size (PDF only)
		$this->ExportExcelPageOrientation = \PhpOffice\PhpSpreadsheet\Worksheet\PageSetup::ORIENTATION_DEFAULT; // Page orientation (PhpSpreadsheet only)
		$this->ExportExcelPageSize = \PhpOffice\PhpSpreadsheet\Worksheet\PageSetup::PAPERSIZE_A4; // Page size (PhpSpreadsheet only)
		$this->ExportWordPageOrientation = "portrait"; // Page orientation (PHPWord only)
		$this->ExportWordColumnWidth = NULL; // Cell width (PHPWord only)
		$this->DetailAdd = FALSE; // Allow detail add
		$this->DetailEdit = FALSE; // Allow detail edit
		$this->DetailView = FALSE; // Allow detail view
		$this->ShowMultipleDetails = FALSE; // Show multiple details
		$this->GridAddRowCount = 5;
		$this->AllowAddDeleteRow = TRUE; // Allow add/delete row
		$this->UserIDAllowSecurity = Config("DEFAULT_USER_ID_ALLOW_SECURITY"); // Default User ID allowed permissions
		$this->BasicSearch = new BasicSearch($this->TableVar);

		// recid
		$this->recid = new DbField('useritem', 'useritem', 'x_recid', 'recid', '`recid`', '`recid`', 20, 12, -1, FALSE, '`recid`', FALSE, FALSE, FALSE, 'FORMATTED TEXT', 'NO');
		$this->recid->IsAutoIncrement = TRUE; // Autoincrement field
		$this->recid->IsPrimaryKey = TRUE; // Primary key field
		$this->recid->Sortable = TRUE; // Allow sort
		$this->recid->DefaultErrorMessage = $Language->phrase("IncorrectInteger");
		$this->fields['recid'] = &$this->recid;

		// userid
		$this->_userid = new DbField('useritem', 'useritem', 'x__userid', 'userid', '`userid`', '`userid`', 20, 12, -1, FALSE, '`userid`', FALSE, FALSE, FALSE, 'FORMATTED TEXT', 'SELECT');
		$this->_userid->Nullable = FALSE; // NOT NULL field
		$this->_userid->Required = TRUE; // Required field
		$this->_userid->Sortable = TRUE; // Allow sort
		$this->_userid->UsePleaseSelect = TRUE; // Use PleaseSelect by default
		$this->_userid->PleaseSelectText = $Language->phrase("PleaseSelect"); // "PleaseSelect" text
		$this->_userid->Lookup = new Lookup('userid', 'vuser', FALSE, 'id', ["firstName","lastName","emailAccount",""], [], [], [], [], [], [], '', '');
		$this->_userid->DefaultErrorMessage = $Language->phrase("IncorrectInteger");
		$this->fields['userid'] = &$this->_userid;

		// userpi
		$this->userpi = new DbField('useritem', 'useritem', 'x_userpi', 'userpi', '`userpi`', '`userpi`', 20, 12, -1, FALSE, '`userpi`', FALSE, FALSE, FALSE, 'FORMATTED TEXT', 'SELECT');
		$this->userpi->IsForeignKey = TRUE; // Foreign key field
		$this->userpi->Nullable = FALSE; // NOT NULL field
		$this->userpi->Required = TRUE; // Required field
		$this->userpi->Sortable = TRUE; // Allow sort
		$this->userpi->UsePleaseSelect = TRUE; // Use PleaseSelect by default
		$this->userpi->PleaseSelectText = $Language->phrase("PleaseSelect"); // "PleaseSelect" text
		$this->userpi->Lookup = new Lookup('userpi', 'paymentinstrument', FALSE, 'id', ["name","id","",""], [], [], [], [], [], [], '', '');
		$this->userpi->DefaultErrorMessage = $Language->phrase("IncorrectInteger");
		$this->fields['userpi'] = &$this->userpi;

		// itemid
		$this->itemid = new DbField('useritem', 'useritem', 'x_itemid', 'itemid', '`itemid`', '`itemid`', 20, 12, -1, FALSE, '`itemid`', FALSE, FALSE, FALSE, 'FORMATTED TEXT', 'TEXT');
		$this->itemid->Nullable = FALSE; // NOT NULL field
		$this->itemid->Required = TRUE; // Required field
		$this->itemid->Sortable = TRUE; // Allow sort
		$this->itemid->DefaultErrorMessage = $Language->phrase("IncorrectInteger");
		$this->fields['itemid'] = &$this->itemid;

		// creationdate
		$this->creationdate = new DbField('useritem', 'useritem', 'x_creationdate', 'creationdate', '`creationdate`', CastDateFieldForLike("`creationdate`", 0, "DB"), 135, 19, 0, FALSE, '`creationdate`', FALSE, FALSE, FALSE, 'FORMATTED TEXT', 'TEXT');
		$this->creationdate->Sortable = TRUE; // Allow sort
		$this->creationdate->DefaultErrorMessage = str_replace("%s", $GLOBALS["DATE_FORMAT"], $Language->phrase("IncorrectDate"));
		$this->fields['creationdate'] = &$this->creationdate;

		// lastupdatedate
		$this->lastupdatedate = new DbField('useritem', 'useritem', 'x_lastupdatedate', 'lastupdatedate', '`lastupdatedate`', CastDateFieldForLike("`lastupdatedate`", 0, "DB"), 135, 19, 0, FALSE, '`lastupdatedate`', FALSE, FALSE, FALSE, 'FORMATTED TEXT', 'TEXT');
		$this->lastupdatedate->Sortable = TRUE; // Allow sort
		$this->lastupdatedate->DefaultErrorMessage = str_replace("%s", $GLOBALS["DATE_FORMAT"], $Language->phrase("IncorrectDate"));
		$this->fields['lastupdatedate'] = &$this->lastupdatedate;

		// lookup1
		$this->lookup1 = new DbField('useritem', 'useritem', 'x_lookup1', 'lookup1', '`lookup1`', '`lookup1`', 200, 50, -1, FALSE, '`lookup1`', FALSE, FALSE, FALSE, 'FORMATTED TEXT', 'TEXT');
		$this->lookup1->Sortable = TRUE; // Allow sort
		$this->fields['lookup1'] = &$this->lookup1;

		// lookup2
		$this->lookup2 = new DbField('useritem', 'useritem', 'x_lookup2', 'lookup2', '`lookup2`', '`lookup2`', 200, 100, -1, FALSE, '`lookup2`', FALSE, FALSE, FALSE, 'FORMATTED TEXT', 'TEXT');
		$this->lookup2->Sortable = TRUE; // Allow sort
		$this->fields['lookup2'] = &$this->lookup2;

		// lookup3
		$this->lookup3 = new DbField('useritem', 'useritem', 'x_lookup3', 'lookup3', '`lookup3`', '`lookup3`', 200, 50, -1, FALSE, '`lookup3`', FALSE, FALSE, FALSE, 'FORMATTED TEXT', 'TEXT');
		$this->lookup3->Sortable = TRUE; // Allow sort
		$this->fields['lookup3'] = &$this->lookup3;

		// itemdata
		$this->itemdata = new DbField('useritem', 'useritem', 'x_itemdata', 'itemdata', '`itemdata`', '`itemdata`', 201, 0, -1, FALSE, '`itemdata`', FALSE, FALSE, FALSE, 'FORMATTED TEXT', 'TEXTAREA');
		$this->itemdata->Sortable = TRUE; // Allow sort
		$this->fields['itemdata'] = &$this->itemdata;

		// expirytime
		$this->expirytime = new DbField('useritem', 'useritem', 'x_expirytime', 'expirytime', '`expirytime`', CastDateFieldForLike("`expirytime`", 1, "DB"), 135, 19, 1, FALSE, '`expirytime`', FALSE, FALSE, FALSE, 'FORMATTED TEXT', 'TEXT');
		$this->expirytime->Sortable = TRUE; // Allow sort
		$this->expirytime->DefaultErrorMessage = str_replace("%s", $GLOBALS["DATE_FORMAT"], $Language->phrase("IncorrectDate"));
		$this->fields['expirytime'] = &$this->expirytime;

		// lastusedate
		$this->lastusedate = new DbField('useritem', 'useritem', 'x_lastusedate', 'lastusedate', '`lastusedate`', CastDateFieldForLike("`lastusedate`", 1, "DB"), 135, 19, 1, FALSE, '`lastusedate`', FALSE, FALSE, FALSE, 'FORMATTED TEXT', 'TEXT');
		$this->lastusedate->Sortable = TRUE; // Allow sort
		$this->lastusedate->DefaultErrorMessage = str_replace("%s", $GLOBALS["DATE_FORMAT"], $Language->phrase("IncorrectDate"));
		$this->fields['lastusedate'] = &$this->lastusedate;

		// masterrecid
		$this->masterrecid = new DbField('useritem', 'useritem', 'x_masterrecid', 'masterrecid', '`masterrecid`', '`masterrecid`', 20, 12, -1, FALSE, '`masterrecid`', FALSE, FALSE, FALSE, 'FORMATTED TEXT', 'TEXT');
		$this->masterrecid->Nullable = FALSE; // NOT NULL field
		$this->masterrecid->Sortable = TRUE; // Allow sort
		$this->masterrecid->DefaultErrorMessage = $Language->phrase("IncorrectInteger");
		$this->fields['masterrecid'] = &$this->masterrecid;
	}

	// Field Visibility
	public function getFieldVisibility($fldParm)
	{
		global $Security;
		return $this->$fldParm->Visible; // Returns original value
	}

	// Set left column class (must be predefined col-*-* classes of Bootstrap grid system)
	function setLeftColumnClass($class)
	{
		if (preg_match('/^col\-(\w+)\-(\d+)$/', $class, $match)) {
			$this->LeftColumnClass = $class . " col-form-label ew-label";
			$this->RightColumnClass = "col-" . $match[1] . "-" . strval(12 - (int)$match[2]);
			$this->OffsetColumnClass = $this->RightColumnClass . " " . str_replace("col-", "offset-", $class);
			$this->TableLeftColumnClass = preg_replace('/^col-\w+-(\d+)$/', "w-col-$1", $class); // Change to w-col-*
		}
	}

	// Single column sort
	public function updateSort(&$fld)
	{
		if ($this->CurrentOrder == $fld->Name) {
			$sortField = $fld->Expression;
			$lastSort = $fld->getSort();
			if ($this->CurrentOrderType == "ASC" || $this->CurrentOrderType == "DESC") {
				$thisSort = $this->CurrentOrderType;
			} else {
				$thisSort = ($lastSort == "ASC") ? "DESC" : "ASC";
			}
			$fld->setSort($thisSort);
			$this->setSessionOrderBy($sortField . " " . $thisSort); // Save to Session
		} else {
			$fld->setSort("");
		}
	}

	// Current master table name
	public function getCurrentMasterTable()
	{
		return @$_SESSION[PROJECT_NAME . "_" . $this->TableVar . "_" . Config("TABLE_MASTER_TABLE")];
	}
	public function setCurrentMasterTable($v)
	{
		$_SESSION[PROJECT_NAME . "_" . $this->TableVar . "_" . Config("TABLE_MASTER_TABLE")] = $v;
	}

	// Session master WHERE clause
	public function getMasterFilter()
	{

		// Master filter
		$masterFilter = "";
		if ($this->getCurrentMasterTable() == "userpi") {
			if ($this->userpi->getSessionValue() != "")
				$masterFilter .= "`id`=" . QuotedValue($this->userpi->getSessionValue(), DATATYPE_NUMBER, "DB");
			else
				return "";
		}
		return $masterFilter;
	}

	// Session detail WHERE clause
	public function getDetailFilter()
	{

		// Detail filter
		$detailFilter = "";
		if ($this->getCurrentMasterTable() == "userpi") {
			if ($this->userpi->getSessionValue() != "")
				$detailFilter .= "`userpi`=" . QuotedValue($this->userpi->getSessionValue(), DATATYPE_NUMBER, "DB");
			else
				return "";
		}
		return $detailFilter;
	}

	// Master filter
	public function sqlMasterFilter_userpi()
	{
		return "`id`=@id@";
	}

	// Detail filter
	public function sqlDetailFilter_userpi()
	{
		return "`userpi`=@userpi@";
	}

	// Table level SQL
	public function getSqlFrom() // From
	{
		return ($this->SqlFrom != "") ? $this->SqlFrom : "`useritem`";
	}
	public function sqlFrom() // For backward compatibility
	{
		return $this->getSqlFrom();
	}
	public function setSqlFrom($v)
	{
		$this->SqlFrom = $v;
	}
	public function getSqlSelect() // Select
	{
		return ($this->SqlSelect != "") ? $this->SqlSelect : "SELECT * FROM " . $this->getSqlFrom();
	}
	public function sqlSelect() // For backward compatibility
	{
		return $this->getSqlSelect();
	}
	public function setSqlSelect($v)
	{
		$this->SqlSelect = $v;
	}
	public function getSqlWhere() // Where
	{
		$where = ($this->SqlWhere != "") ? $this->SqlWhere : "";
		$this->TableFilter = "";
		AddFilter($where, $this->TableFilter);
		return $where;
	}
	public function sqlWhere() // For backward compatibility
	{
		return $this->getSqlWhere();
	}
	public function setSqlWhere($v)
	{
		$this->SqlWhere = $v;
	}
	public function getSqlGroupBy() // Group By
	{
		return ($this->SqlGroupBy != "") ? $this->SqlGroupBy : "";
	}
	public function sqlGroupBy() // For backward compatibility
	{
		return $this->getSqlGroupBy();
	}
	public function setSqlGroupBy($v)
	{
		$this->SqlGroupBy = $v;
	}
	public function getSqlHaving() // Having
	{
		return ($this->SqlHaving != "") ? $this->SqlHaving : "";
	}
	public function sqlHaving() // For backward compatibility
	{
		return $this->getSqlHaving();
	}
	public function setSqlHaving($v)
	{
		$this->SqlHaving = $v;
	}
	public function getSqlOrderBy() // Order By
	{
		return ($this->SqlOrderBy != "") ? $this->SqlOrderBy : "";
	}
	public function sqlOrderBy() // For backward compatibility
	{
		return $this->getSqlOrderBy();
	}
	public function setSqlOrderBy($v)
	{
		$this->SqlOrderBy = $v;
	}

	// Apply User ID filters
	public function applyUserIDFilters($filter, $id = "")
	{
		return $filter;
	}

	// Check if User ID security allows view all
	public function userIDAllow($id = "")
	{
		$allow = $this->UserIDAllowSecurity;
		switch ($id) {
			case "add":
			case "copy":
			case "gridadd":
			case "register":
			case "addopt":
				return (($allow & 1) == 1);
			case "edit":
			case "gridedit":
			case "update":
			case "changepwd":
			case "forgotpwd":
				return (($allow & 4) == 4);
			case "delete":
				return (($allow & 2) == 2);
			case "view":
				return (($allow & 32) == 32);
			case "search":
				return (($allow & 64) == 64);
			case "lookup":
				return (($allow & 256) == 256);
			default:
				return (($allow & 8) == 8);
		}
	}

	// Get recordset
	public function getRecordset($sql, $rowcnt = -1, $offset = -1)
	{
		$conn = $this->getConnection();
		$conn->raiseErrorFn = Config("ERROR_FUNC");
		$rs = $conn->selectLimit($sql, $rowcnt, $offset);
		$conn->raiseErrorFn = "";
		return $rs;
	}

	// Get record count
	public function getRecordCount($sql, $c = NULL)
	{
		$cnt = -1;
		$rs = NULL;
		$sql = preg_replace('/\/\*BeginOrderBy\*\/[\s\S]+\/\*EndOrderBy\*\//', "", $sql); // Remove ORDER BY clause (MSSQL)
		$pattern = '/^SELECT\s([\s\S]+)\sFROM\s/i';

		// Skip Custom View / SubQuery / SELECT DISTINCT / ORDER BY
		if (($this->TableType == 'TABLE' || $this->TableType == 'VIEW' || $this->TableType == 'LINKTABLE') &&
			preg_match($pattern, $sql) && !preg_match('/\(\s*(SELECT[^)]+)\)/i', $sql) &&
			!preg_match('/^\s*select\s+distinct\s+/i', $sql) && !preg_match('/\s+order\s+by\s+/i', $sql)) {
			$sqlwrk = "SELECT COUNT(*) FROM " . preg_replace($pattern, "", $sql);
		} else {
			$sqlwrk = "SELECT COUNT(*) FROM (" . $sql . ") COUNT_TABLE";
		}
		$conn = $c ?: $this->getConnection();
		if ($rs = $conn->execute($sqlwrk)) {
			if (!$rs->EOF && $rs->FieldCount() > 0) {
				$cnt = $rs->fields[0];
				$rs->close();
			}
			return (int)$cnt;
		}

		// Unable to get count, get record count directly
		if ($rs = $conn->execute($sql)) {
			$cnt = $rs->RecordCount();
			$rs->close();
			return (int)$cnt;
		}
		return $cnt;
	}

	// Get SQL
	public function getSql($where, $orderBy = "")
	{
		return BuildSelectSql($this->getSqlSelect(), $this->getSqlWhere(),
			$this->getSqlGroupBy(), $this->getSqlHaving(), $this->getSqlOrderBy(),
			$where, $orderBy);
	}

	// Table SQL
	public function getCurrentSql()
	{
		$filter = $this->CurrentFilter;
		$filter = $this->applyUserIDFilters($filter);
		$sort = $this->getSessionOrderBy();
		return $this->getSql($filter, $sort);
	}

	// Table SQL with List page filter
	public function getListSql()
	{
		$filter = $this->UseSessionForListSql ? $this->getSessionWhere() : "";
		AddFilter($filter, $this->CurrentFilter);
		$filter = $this->applyUserIDFilters($filter);
		$this->Recordset_Selecting($filter);
		$select = $this->getSqlSelect();
		$sort = $this->UseSessionForListSql ? $this->getSessionOrderBy() : "";
		return BuildSelectSql($select, $this->getSqlWhere(), $this->getSqlGroupBy(),
			$this->getSqlHaving(), $this->getSqlOrderBy(), $filter, $sort);
	}

	// Get ORDER BY clause
	public function getOrderBy()
	{
		$sort = $this->getSessionOrderBy();
		return BuildSelectSql("", "", "", "", $this->getSqlOrderBy(), "", $sort);
	}

	// Get record count based on filter (for detail record count in master table pages)
	public function loadRecordCount($filter)
	{
		$origFilter = $this->CurrentFilter;
		$this->CurrentFilter = $filter;
		$this->Recordset_Selecting($this->CurrentFilter);
		$select = $this->TableType == 'CUSTOMVIEW' ? $this->getSqlSelect() : "SELECT * FROM " . $this->getSqlFrom();
		$groupBy = $this->TableType == 'CUSTOMVIEW' ? $this->getSqlGroupBy() : "";
		$having = $this->TableType == 'CUSTOMVIEW' ? $this->getSqlHaving() : "";
		$sql = BuildSelectSql($select, $this->getSqlWhere(), $groupBy, $having, "", $this->CurrentFilter, "");
		$cnt = $this->getRecordCount($sql);
		$this->CurrentFilter = $origFilter;
		return $cnt;
	}

	// Get record count (for current List page)
	public function listRecordCount()
	{
		$filter = $this->getSessionWhere();
		AddFilter($filter, $this->CurrentFilter);
		$filter = $this->applyUserIDFilters($filter);
		$this->Recordset_Selecting($filter);
		$select = $this->TableType == 'CUSTOMVIEW' ? $this->getSqlSelect() : "SELECT * FROM " . $this->getSqlFrom();
		$groupBy = $this->TableType == 'CUSTOMVIEW' ? $this->getSqlGroupBy() : "";
		$having = $this->TableType == 'CUSTOMVIEW' ? $this->getSqlHaving() : "";
		$sql = BuildSelectSql($select, $this->getSqlWhere(), $groupBy, $having, "", $filter, "");
		$cnt = $this->getRecordCount($sql);
		return $cnt;
	}

	// INSERT statement
	protected function insertSql(&$rs)
	{
		$names = "";
		$values = "";
		foreach ($rs as $name => $value) {
			if (!isset($this->fields[$name]) || $this->fields[$name]->IsCustom)
				continue;
			$names .= $this->fields[$name]->Expression . ",";
			$values .= QuotedValue($value, $this->fields[$name]->DataType, $this->Dbid) . ",";
		}
		$names = preg_replace('/,+$/', "", $names);
		$values = preg_replace('/,+$/', "", $values);
		return "INSERT INTO " . $this->UpdateTable . " (" . $names . ") VALUES (" . $values . ")";
	}

	// Insert
	public function insert(&$rs)
	{
		$conn = $this->getConnection();
		$success = $conn->execute($this->insertSql($rs));
		if ($success) {

			// Get insert id if necessary
			$this->recid->setDbValue($conn->insert_ID());
			$rs['recid'] = $this->recid->DbValue;
			if ($this->AuditTrailOnAdd)
				$this->writeAuditTrailOnAdd($rs);
		}
		return $success;
	}

	// UPDATE statement
	protected function updateSql(&$rs, $where = "", $curfilter = TRUE)
	{
		$sql = "UPDATE " . $this->UpdateTable . " SET ";
		foreach ($rs as $name => $value) {
			if (!isset($this->fields[$name]) || $this->fields[$name]->IsCustom || $this->fields[$name]->IsAutoIncrement)
				continue;
			$sql .= $this->fields[$name]->Expression . "=";
			$sql .= QuotedValue($value, $this->fields[$name]->DataType, $this->Dbid) . ",";
		}
		$sql = preg_replace('/,+$/', "", $sql);
		$filter = ($curfilter) ? $this->CurrentFilter : "";
		if (is_array($where))
			$where = $this->arrayToFilter($where);
		AddFilter($filter, $where);
		if ($filter != "")
			$sql .= " WHERE " . $filter;
		return $sql;
	}

	// Update
	public function update(&$rs, $where = "", $rsold = NULL, $curfilter = TRUE)
	{
		$conn = $this->getConnection();
		$success = $conn->execute($this->updateSql($rs, $where, $curfilter));
		if ($success && $this->AuditTrailOnEdit && $rsold) {
			$rsaudit = $rs;
			$fldname = 'recid';
			if (!array_key_exists($fldname, $rsaudit))
				$rsaudit[$fldname] = $rsold[$fldname];
			$this->writeAuditTrailOnEdit($rsold, $rsaudit);
		}
		return $success;
	}

	// DELETE statement
	protected function deleteSql(&$rs, $where = "", $curfilter = TRUE)
	{
		$sql = "DELETE FROM " . $this->UpdateTable . " WHERE ";
		if (is_array($where))
			$where = $this->arrayToFilter($where);
		if ($rs) {
			if (array_key_exists('recid', $rs))
				AddFilter($where, QuotedName('recid', $this->Dbid) . '=' . QuotedValue($rs['recid'], $this->recid->DataType, $this->Dbid));
		}
		$filter = ($curfilter) ? $this->CurrentFilter : "";
		AddFilter($filter, $where);
		if ($filter != "")
			$sql .= $filter;
		else
			$sql .= "0=1"; // Avoid delete
		return $sql;
	}

	// Delete
	public function delete(&$rs, $where = "", $curfilter = FALSE)
	{
		$success = TRUE;
		$conn = $this->getConnection();
		if ($success)
			$success = $conn->execute($this->deleteSql($rs, $where, $curfilter));
		if ($success && $this->AuditTrailOnDelete)
			$this->writeAuditTrailOnDelete($rs);
		return $success;
	}

	// Load DbValue from recordset or array
	protected function loadDbValues(&$rs)
	{
		if (!$rs || !is_array($rs) && $rs->EOF)
			return;
		$row = is_array($rs) ? $rs : $rs->fields;
		$this->recid->DbValue = $row['recid'];
		$this->_userid->DbValue = $row['userid'];
		$this->userpi->DbValue = $row['userpi'];
		$this->itemid->DbValue = $row['itemid'];
		$this->creationdate->DbValue = $row['creationdate'];
		$this->lastupdatedate->DbValue = $row['lastupdatedate'];
		$this->lookup1->DbValue = $row['lookup1'];
		$this->lookup2->DbValue = $row['lookup2'];
		$this->lookup3->DbValue = $row['lookup3'];
		$this->itemdata->DbValue = $row['itemdata'];
		$this->expirytime->DbValue = $row['expirytime'];
		$this->lastusedate->DbValue = $row['lastusedate'];
		$this->masterrecid->DbValue = $row['masterrecid'];
	}

	// Delete uploaded files
	public function deleteUploadedFiles($row)
	{
		$this->loadDbValues($row);
	}

	// Record filter WHERE clause
	protected function sqlKeyFilter()
	{
		return "`recid` = @recid@";
	}

	// Get record filter
	public function getRecordFilter($row = NULL)
	{
		$keyFilter = $this->sqlKeyFilter();
		if (is_array($row))
			$val = array_key_exists('recid', $row) ? $row['recid'] : NULL;
		else
			$val = $this->recid->OldValue !== NULL ? $this->recid->OldValue : $this->recid->CurrentValue;
		if (!is_numeric($val))
			return "0=1"; // Invalid key
		if ($val == NULL)
			return "0=1"; // Invalid key
		else
			$keyFilter = str_replace("@recid@", AdjustSql($val, $this->Dbid), $keyFilter); // Replace key value
		return $keyFilter;
	}

	// Return page URL
	public function getReturnUrl()
	{
		$name = PROJECT_NAME . "_" . $this->TableVar . "_" . Config("TABLE_RETURN_URL");

		// Get referer URL automatically
		if (ServerVar("HTTP_REFERER") != "" && ReferPageName() != CurrentPageName() && ReferPageName() != "login.php") // Referer not same page or login page
			$_SESSION[$name] = ServerVar("HTTP_REFERER"); // Save to Session
		if (@$_SESSION[$name] != "") {
			return $_SESSION[$name];
		} else {
			return "useritemlist.php";
		}
	}
	public function setReturnUrl($v)
	{
		$_SESSION[PROJECT_NAME . "_" . $this->TableVar . "_" . Config("TABLE_RETURN_URL")] = $v;
	}

	// Get modal caption
	public function getModalCaption($pageName)
	{
		global $Language;
		if ($pageName == "useritemview.php")
			return $Language->phrase("View");
		elseif ($pageName == "useritemedit.php")
			return $Language->phrase("Edit");
		elseif ($pageName == "useritemadd.php")
			return $Language->phrase("Add");
		else
			return "";
	}

	// List URL
	public function getListUrl()
	{
		return "useritemlist.php";
	}

	// View URL
	public function getViewUrl($parm = "")
	{
		if ($parm != "")
			$url = $this->keyUrl("useritemview.php", $this->getUrlParm($parm));
		else
			$url = $this->keyUrl("useritemview.php", $this->getUrlParm(Config("TABLE_SHOW_DETAIL") . "="));
		return $this->addMasterUrl($url);
	}

	// Add URL
	public function getAddUrl($parm = "")
	{
		if ($parm != "")
			$url = "useritemadd.php?" . $this->getUrlParm($parm);
		else
			$url = "useritemadd.php";
		return $this->addMasterUrl($url);
	}

	// Edit URL
	public function getEditUrl($parm = "")
	{
		$url = $this->keyUrl("useritemedit.php", $this->getUrlParm($parm));
		return $this->addMasterUrl($url);
	}

	// Inline edit URL
	public function getInlineEditUrl()
	{
		$url = $this->keyUrl(CurrentPageName(), $this->getUrlParm("action=edit"));
		return $this->addMasterUrl($url);
	}

	// Copy URL
	public function getCopyUrl($parm = "")
	{
		$url = $this->keyUrl("useritemadd.php", $this->getUrlParm($parm));
		return $this->addMasterUrl($url);
	}

	// Inline copy URL
	public function getInlineCopyUrl()
	{
		$url = $this->keyUrl(CurrentPageName(), $this->getUrlParm("action=copy"));
		return $this->addMasterUrl($url);
	}

	// Delete URL
	public function getDeleteUrl()
	{
		return $this->keyUrl("useritemdelete.php", $this->getUrlParm());
	}

	// Add master url
	public function addMasterUrl($url)
	{
		if ($this->getCurrentMasterTable() == "userpi" && !ContainsString($url, Config("TABLE_SHOW_MASTER") . "=")) {
			$url .= (ContainsString($url, "?") ? "&" : "?") . Config("TABLE_SHOW_MASTER") . "=" . $this->getCurrentMasterTable();
			$url .= "&fk_id=" . urlencode($this->userpi->CurrentValue);
		}
		return $url;
	}
	public function keyToJson($htmlEncode = FALSE)
	{
		$json = "";
		$json .= "recid:" . JsonEncode($this->recid->CurrentValue, "number");
		$json = "{" . $json . "}";
		if ($htmlEncode)
			$json = HtmlEncode($json);
		return $json;
	}

	// Add key value to URL
	public function keyUrl($url, $parm = "")
	{
		$url = $url . "?";
		if ($parm != "")
			$url .= $parm . "&";
		if ($this->recid->CurrentValue != NULL) {
			$url .= "recid=" . urlencode($this->recid->CurrentValue);
		} else {
			return "javascript:ew.alert(ew.language.phrase('InvalidRecord'));";
		}
		return $url;
	}

	// Sort URL
	public function sortUrl(&$fld)
	{
		if ($this->CurrentAction || $this->isExport() ||
			in_array($fld->Type, [128, 204, 205])) { // Unsortable data type
				return "";
		} elseif ($fld->Sortable) {
			$urlParm = $this->getUrlParm("order=" . urlencode($fld->Name) . "&amp;ordertype=" . $fld->reverseSort());
			return $this->addMasterUrl(CurrentPageName() . "?" . $urlParm);
		} else {
			return "";
		}
	}

	// Get record keys from Post/Get/Session
	public function getRecordKeys()
	{
		$arKeys = [];
		$arKey = [];
		if (Param("key_m") !== NULL) {
			$arKeys = Param("key_m");
			$cnt = count($arKeys);
		} else {
			if (Param("recid") !== NULL)
				$arKeys[] = Param("recid");
			elseif (IsApi() && Key(0) !== NULL)
				$arKeys[] = Key(0);
			elseif (IsApi() && Route(2) !== NULL)
				$arKeys[] = Route(2);
			else
				$arKeys = NULL; // Do not setup

			//return $arKeys; // Do not return yet, so the values will also be checked by the following code
		}

		// Check keys
		$ar = [];
		if (is_array($arKeys)) {
			foreach ($arKeys as $key) {
				if (!is_numeric($key))
					continue;
				$ar[] = $key;
			}
		}
		return $ar;
	}

	// Get filter from record keys
	public function getFilterFromRecordKeys($setCurrent = TRUE)
	{
		$arKeys = $this->getRecordKeys();
		$keyFilter = "";
		foreach ($arKeys as $key) {
			if ($keyFilter != "") $keyFilter .= " OR ";
			if ($setCurrent)
				$this->recid->CurrentValue = $key;
			else
				$this->recid->OldValue = $key;
			$keyFilter .= "(" . $this->getRecordFilter() . ")";
		}
		return $keyFilter;
	}

	// Load rows based on filter
	public function &loadRs($filter)
	{

		// Set up filter (WHERE Clause)
		$sql = $this->getSql($filter);
		$conn = $this->getConnection();
		$rs = $conn->execute($sql);
		return $rs;
	}

	// Load row values from recordset
	public function loadListRowValues(&$rs)
	{
		$this->recid->setDbValue($rs->fields('recid'));
		$this->_userid->setDbValue($rs->fields('userid'));
		$this->userpi->setDbValue($rs->fields('userpi'));
		$this->itemid->setDbValue($rs->fields('itemid'));
		$this->creationdate->setDbValue($rs->fields('creationdate'));
		$this->lastupdatedate->setDbValue($rs->fields('lastupdatedate'));
		$this->lookup1->setDbValue($rs->fields('lookup1'));
		$this->lookup2->setDbValue($rs->fields('lookup2'));
		$this->lookup3->setDbValue($rs->fields('lookup3'));
		$this->itemdata->setDbValue($rs->fields('itemdata'));
		$this->expirytime->setDbValue($rs->fields('expirytime'));
		$this->lastusedate->setDbValue($rs->fields('lastusedate'));
		$this->masterrecid->setDbValue($rs->fields('masterrecid'));
	}

	// Render list row values
	public function renderListRow()
	{
		global $Security, $CurrentLanguage, $Language;

		// Call Row Rendering event
		$this->Row_Rendering();

		// Common render codes
		// recid
		// userid
		// userpi
		// itemid
		// creationdate
		// lastupdatedate
		// lookup1
		// lookup2
		// lookup3
		// itemdata
		// expirytime
		// lastusedate
		// masterrecid
		// recid

		$this->recid->ViewValue = $this->recid->CurrentValue;
		$this->recid->ViewCustomAttributes = "";

		// userid
		$curVal = strval($this->_userid->CurrentValue);
		if ($curVal != "") {
			$this->_userid->ViewValue = $this->_userid->lookupCacheOption($curVal);
			if ($this->_userid->ViewValue === NULL) { // Lookup from database
				$filterWrk = "`id`" . SearchString("=", $curVal, DATATYPE_NUMBER, "");
				$sqlWrk = $this->_userid->Lookup->getSql(FALSE, $filterWrk, '', $this);
				$rswrk = Conn()->execute($sqlWrk);
				if ($rswrk && !$rswrk->EOF) { // Lookup values found
					$arwrk = [];
					$arwrk[1] = $rswrk->fields('df');
					$arwrk[2] = $rswrk->fields('df2');
					$arwrk[3] = $rswrk->fields('df3');
					$this->_userid->ViewValue = $this->_userid->displayValue($arwrk);
					$rswrk->Close();
				} else {
					$this->_userid->ViewValue = $this->_userid->CurrentValue;
				}
			}
		} else {
			$this->_userid->ViewValue = NULL;
		}
		$this->_userid->ViewCustomAttributes = "";

		// userpi
		$curVal = strval($this->userpi->CurrentValue);
		if ($curVal != "") {
			$this->userpi->ViewValue = $this->userpi->lookupCacheOption($curVal);
			if ($this->userpi->ViewValue === NULL) { // Lookup from database
				$filterWrk = "`id`" . SearchString("=", $curVal, DATATYPE_NUMBER, "_4payreference");
				$sqlWrk = $this->userpi->Lookup->getSql(FALSE, $filterWrk, '', $this);
				$rswrk = Conn("_4payreference")->execute($sqlWrk);
				if ($rswrk && !$rswrk->EOF) { // Lookup values found
					$arwrk = [];
					$arwrk[1] = $rswrk->fields('df');
					$arwrk[2] = $rswrk->fields('df2');
					$this->userpi->ViewValue = $this->userpi->displayValue($arwrk);
					$rswrk->Close();
				} else {
					$this->userpi->ViewValue = $this->userpi->CurrentValue;
				}
			}
		} else {
			$this->userpi->ViewValue = NULL;
		}
		$this->userpi->ViewCustomAttributes = "";

		// itemid
		$this->itemid->ViewValue = $this->itemid->CurrentValue;
		$this->itemid->ViewValue = FormatNumber($this->itemid->ViewValue, 0, -2, -2, -2);
		$this->itemid->ViewCustomAttributes = "";

		// creationdate
		$this->creationdate->ViewValue = $this->creationdate->CurrentValue;
		$this->creationdate->ViewValue = FormatDateTime($this->creationdate->ViewValue, 0);
		$this->creationdate->ViewCustomAttributes = "";

		// lastupdatedate
		$this->lastupdatedate->ViewValue = $this->lastupdatedate->CurrentValue;
		$this->lastupdatedate->ViewValue = FormatDateTime($this->lastupdatedate->ViewValue, 0);
		$this->lastupdatedate->ViewCustomAttributes = "";

		// lookup1
		$this->lookup1->ViewValue = $this->lookup1->CurrentValue;
		$this->lookup1->ViewCustomAttributes = "";

		// lookup2
		$this->lookup2->ViewValue = $this->lookup2->CurrentValue;
		$this->lookup2->ViewCustomAttributes = "";

		// lookup3
		$this->lookup3->ViewValue = $this->lookup3->CurrentValue;
		$this->lookup3->ViewCustomAttributes = "";

		// itemdata
		$this->itemdata->ViewValue = $this->itemdata->CurrentValue;
		$this->itemdata->ViewCustomAttributes = "";

		// expirytime
		$this->expirytime->ViewValue = $this->expirytime->CurrentValue;
		$this->expirytime->ViewValue = FormatDateTime($this->expirytime->ViewValue, 1);
		$this->expirytime->ViewCustomAttributes = "";

		// lastusedate
		$this->lastusedate->ViewValue = $this->lastusedate->CurrentValue;
		$this->lastusedate->ViewValue = FormatDateTime($this->lastusedate->ViewValue, 1);
		$this->lastusedate->ViewCustomAttributes = "";

		// masterrecid
		$this->masterrecid->ViewValue = $this->masterrecid->CurrentValue;
		$this->masterrecid->ViewValue = FormatNumber($this->masterrecid->ViewValue, 0, -2, -2, -2);
		$this->masterrecid->ViewCustomAttributes = "";

		// recid
		$this->recid->LinkCustomAttributes = "";
		$this->recid->HrefValue = "";
		$this->recid->TooltipValue = "";

		// userid
		$this->_userid->LinkCustomAttributes = "";
		$this->_userid->HrefValue = "";
		$this->_userid->TooltipValue = "";

		// userpi
		$this->userpi->LinkCustomAttributes = "";
		$this->userpi->HrefValue = "";
		$this->userpi->TooltipValue = "";

		// itemid
		$this->itemid->LinkCustomAttributes = "";
		$this->itemid->HrefValue = "";
		$this->itemid->TooltipValue = "";

		// creationdate
		$this->creationdate->LinkCustomAttributes = "";
		$this->creationdate->HrefValue = "";
		$this->creationdate->TooltipValue = "";

		// lastupdatedate
		$this->lastupdatedate->LinkCustomAttributes = "";
		$this->lastupdatedate->HrefValue = "";
		$this->lastupdatedate->TooltipValue = "";

		// lookup1
		$this->lookup1->LinkCustomAttributes = "";
		$this->lookup1->HrefValue = "";
		$this->lookup1->TooltipValue = "";

		// lookup2
		$this->lookup2->LinkCustomAttributes = "";
		$this->lookup2->HrefValue = "";
		$this->lookup2->TooltipValue = "";

		// lookup3
		$this->lookup3->LinkCustomAttributes = "";
		$this->lookup3->HrefValue = "";
		$this->lookup3->TooltipValue = "";

		// itemdata
		$this->itemdata->LinkCustomAttributes = "";
		$this->itemdata->HrefValue = "";
		$this->itemdata->TooltipValue = "";

		// expirytime
		$this->expirytime->LinkCustomAttributes = "";
		$this->expirytime->HrefValue = "";
		$this->expirytime->TooltipValue = "";

		// lastusedate
		$this->lastusedate->LinkCustomAttributes = "";
		$this->lastusedate->HrefValue = "";
		$this->lastusedate->TooltipValue = "";

		// masterrecid
		$this->masterrecid->LinkCustomAttributes = "";
		$this->masterrecid->HrefValue = "";
		$this->masterrecid->TooltipValue = "";

		// Call Row Rendered event
		$this->Row_Rendered();

		// Save data for Custom Template
		$this->Rows[] = $this->customTemplateFieldValues();
	}

	// Render edit row values
	public function renderEditRow()
	{
		global $Security, $CurrentLanguage, $Language;

		// Call Row Rendering event
		$this->Row_Rendering();

		// recid
		$this->recid->EditAttrs["class"] = "form-control";
		$this->recid->EditCustomAttributes = "";
		$this->recid->EditValue = $this->recid->CurrentValue;
		$this->recid->ViewCustomAttributes = "";

		// userid
		$this->_userid->EditAttrs["class"] = "form-control";
		$this->_userid->EditCustomAttributes = "";

		// userpi
		$this->userpi->EditAttrs["class"] = "form-control";
		$this->userpi->EditCustomAttributes = "";
		if ($this->userpi->getSessionValue() != "") {
			$this->userpi->CurrentValue = $this->userpi->getSessionValue();
			$curVal = strval($this->userpi->CurrentValue);
			if ($curVal != "") {
				$this->userpi->ViewValue = $this->userpi->lookupCacheOption($curVal);
				if ($this->userpi->ViewValue === NULL) { // Lookup from database
					$filterWrk = "`id`" . SearchString("=", $curVal, DATATYPE_NUMBER, "_4payreference");
					$sqlWrk = $this->userpi->Lookup->getSql(FALSE, $filterWrk, '', $this);
					$rswrk = Conn("_4payreference")->execute($sqlWrk);
					if ($rswrk && !$rswrk->EOF) { // Lookup values found
						$arwrk = [];
						$arwrk[1] = $rswrk->fields('df');
						$arwrk[2] = $rswrk->fields('df2');
						$this->userpi->ViewValue = $this->userpi->displayValue($arwrk);
						$rswrk->Close();
					} else {
						$this->userpi->ViewValue = $this->userpi->CurrentValue;
					}
				}
			} else {
				$this->userpi->ViewValue = NULL;
			}
			$this->userpi->ViewCustomAttributes = "";
		} else {
		}

		// itemid
		$this->itemid->EditAttrs["class"] = "form-control";
		$this->itemid->EditCustomAttributes = "";
		$this->itemid->EditValue = $this->itemid->CurrentValue;
		$this->itemid->PlaceHolder = RemoveHtml($this->itemid->caption());

		// creationdate
		$this->creationdate->EditAttrs["class"] = "form-control";
		$this->creationdate->EditCustomAttributes = "";
		$this->creationdate->EditValue = FormatDateTime($this->creationdate->CurrentValue, 8);
		$this->creationdate->PlaceHolder = RemoveHtml($this->creationdate->caption());

		// lastupdatedate
		$this->lastupdatedate->EditAttrs["class"] = "form-control";
		$this->lastupdatedate->EditCustomAttributes = "";
		$this->lastupdatedate->EditValue = FormatDateTime($this->lastupdatedate->CurrentValue, 8);
		$this->lastupdatedate->PlaceHolder = RemoveHtml($this->lastupdatedate->caption());

		// lookup1
		$this->lookup1->EditAttrs["class"] = "form-control";
		$this->lookup1->EditCustomAttributes = "";
		if (!$this->lookup1->Raw)
			$this->lookup1->CurrentValue = HtmlDecode($this->lookup1->CurrentValue);
		$this->lookup1->EditValue = $this->lookup1->CurrentValue;
		$this->lookup1->PlaceHolder = RemoveHtml($this->lookup1->caption());

		// lookup2
		$this->lookup2->EditAttrs["class"] = "form-control";
		$this->lookup2->EditCustomAttributes = "";
		if (!$this->lookup2->Raw)
			$this->lookup2->CurrentValue = HtmlDecode($this->lookup2->CurrentValue);
		$this->lookup2->EditValue = $this->lookup2->CurrentValue;
		$this->lookup2->PlaceHolder = RemoveHtml($this->lookup2->caption());

		// lookup3
		$this->lookup3->EditAttrs["class"] = "form-control";
		$this->lookup3->EditCustomAttributes = "";
		if (!$this->lookup3->Raw)
			$this->lookup3->CurrentValue = HtmlDecode($this->lookup3->CurrentValue);
		$this->lookup3->EditValue = $this->lookup3->CurrentValue;
		$this->lookup3->PlaceHolder = RemoveHtml($this->lookup3->caption());

		// itemdata
		$this->itemdata->EditAttrs["class"] = "form-control";
		$this->itemdata->EditCustomAttributes = "";
		$this->itemdata->EditValue = $this->itemdata->CurrentValue;
		$this->itemdata->PlaceHolder = RemoveHtml($this->itemdata->caption());

		// expirytime
		$this->expirytime->EditAttrs["class"] = "form-control";
		$this->expirytime->EditCustomAttributes = "";
		$this->expirytime->EditValue = FormatDateTime($this->expirytime->CurrentValue, 8);
		$this->expirytime->PlaceHolder = RemoveHtml($this->expirytime->caption());

		// lastusedate
		$this->lastusedate->EditAttrs["class"] = "form-control";
		$this->lastusedate->EditCustomAttributes = "";
		$this->lastusedate->EditValue = FormatDateTime($this->lastusedate->CurrentValue, 8);
		$this->lastusedate->PlaceHolder = RemoveHtml($this->lastusedate->caption());

		// masterrecid
		$this->masterrecid->EditAttrs["class"] = "form-control";
		$this->masterrecid->EditCustomAttributes = "";
		$this->masterrecid->EditValue = $this->masterrecid->CurrentValue;
		$this->masterrecid->PlaceHolder = RemoveHtml($this->masterrecid->caption());

		// Call Row Rendered event
		$this->Row_Rendered();
	}

	// Aggregate list row values
	public function aggregateListRowValues()
	{
	}

	// Aggregate list row (for rendering)
	public function aggregateListRow()
	{

		// Call Row Rendered event
		$this->Row_Rendered();
	}

	// Export data in HTML/CSV/Word/Excel/Email/PDF format
	public function exportDocument($doc, $recordset, $startRec = 1, $stopRec = 1, $exportPageType = "")
	{
		if (!$recordset || !$doc)
			return;
		if (!$doc->ExportCustom) {

			// Write header
			$doc->exportTableHeader();
			if ($doc->Horizontal) { // Horizontal format, write header
				$doc->beginExportRow();
				if ($exportPageType == "view") {
					$doc->exportCaption($this->recid);
					$doc->exportCaption($this->_userid);
					$doc->exportCaption($this->userpi);
					$doc->exportCaption($this->itemid);
					$doc->exportCaption($this->creationdate);
					$doc->exportCaption($this->lastupdatedate);
					$doc->exportCaption($this->lookup1);
					$doc->exportCaption($this->lookup2);
					$doc->exportCaption($this->lookup3);
					$doc->exportCaption($this->itemdata);
					$doc->exportCaption($this->expirytime);
					$doc->exportCaption($this->lastusedate);
					$doc->exportCaption($this->masterrecid);
				} else {
					$doc->exportCaption($this->recid);
					$doc->exportCaption($this->_userid);
					$doc->exportCaption($this->userpi);
					$doc->exportCaption($this->itemid);
					$doc->exportCaption($this->creationdate);
					$doc->exportCaption($this->lastupdatedate);
					$doc->exportCaption($this->lookup1);
					$doc->exportCaption($this->lookup2);
					$doc->exportCaption($this->lookup3);
					$doc->exportCaption($this->expirytime);
					$doc->exportCaption($this->lastusedate);
					$doc->exportCaption($this->masterrecid);
				}
				$doc->endExportRow();
			}
		}

		// Move to first record
		$recCnt = $startRec - 1;
		if (!$recordset->EOF) {
			$recordset->moveFirst();
			if ($startRec > 1)
				$recordset->move($startRec - 1);
		}
		while (!$recordset->EOF && $recCnt < $stopRec) {
			$recCnt++;
			if ($recCnt >= $startRec) {
				$rowCnt = $recCnt - $startRec + 1;

				// Page break
				if ($this->ExportPageBreakCount > 0) {
					if ($rowCnt > 1 && ($rowCnt - 1) % $this->ExportPageBreakCount == 0)
						$doc->exportPageBreak();
				}
				$this->loadListRowValues($recordset);

				// Render row
				$this->RowType = ROWTYPE_VIEW; // Render view
				$this->resetAttributes();
				$this->renderListRow();
				if (!$doc->ExportCustom) {
					$doc->beginExportRow($rowCnt); // Allow CSS styles if enabled
					if ($exportPageType == "view") {
						$doc->exportField($this->recid);
						$doc->exportField($this->_userid);
						$doc->exportField($this->userpi);
						$doc->exportField($this->itemid);
						$doc->exportField($this->creationdate);
						$doc->exportField($this->lastupdatedate);
						$doc->exportField($this->lookup1);
						$doc->exportField($this->lookup2);
						$doc->exportField($this->lookup3);
						$doc->exportField($this->itemdata);
						$doc->exportField($this->expirytime);
						$doc->exportField($this->lastusedate);
						$doc->exportField($this->masterrecid);
					} else {
						$doc->exportField($this->recid);
						$doc->exportField($this->_userid);
						$doc->exportField($this->userpi);
						$doc->exportField($this->itemid);
						$doc->exportField($this->creationdate);
						$doc->exportField($this->lastupdatedate);
						$doc->exportField($this->lookup1);
						$doc->exportField($this->lookup2);
						$doc->exportField($this->lookup3);
						$doc->exportField($this->expirytime);
						$doc->exportField($this->lastusedate);
						$doc->exportField($this->masterrecid);
					}
					$doc->endExportRow($rowCnt);
				}
			}

			// Call Row Export server event
			if ($doc->ExportCustom)
				$this->Row_Export($recordset->fields);
			$recordset->moveNext();
		}
		if (!$doc->ExportCustom) {
			$doc->exportTableFooter();
		}
	}

	// Get file data
	public function getFileData($fldparm, $key, $resize, $width = 0, $height = 0)
	{

		// No binary fields
		return FALSE;
	}

	// Write Audit Trail start/end for grid update
	public function writeAuditTrailDummy($typ)
	{
		$table = 'useritem';
		$usr = CurrentUserName();
		WriteAuditTrail("log", DbCurrentDateTime(), ScriptName(), $usr, $typ, $table, "", "", "", "");
	}

	// Write Audit Trail (add page)
	public function writeAuditTrailOnAdd(&$rs)
	{
		global $Language;
		if (!$this->AuditTrailOnAdd)
			return;
		$table = 'useritem';

		// Get key value
		$key = "";
		if ($key != "")
			$key .= Config("COMPOSITE_KEY_SEPARATOR");
		$key .= $rs['recid'];

		// Write Audit Trail
		$dt = DbCurrentDateTime();
		$id = ScriptName();
		$usr = CurrentUserName();
		foreach (array_keys($rs) as $fldname) {
			if (array_key_exists($fldname, $this->fields) && $this->fields[$fldname]->DataType != DATATYPE_BLOB) { // Ignore BLOB fields
				if ($this->fields[$fldname]->HtmlTag == "PASSWORD") {
					$newvalue = $Language->phrase("PasswordMask"); // Password Field
				} elseif ($this->fields[$fldname]->DataType == DATATYPE_MEMO) {
					if (Config("AUDIT_TRAIL_TO_DATABASE"))
						$newvalue = $rs[$fldname];
					else
						$newvalue = "[MEMO]"; // Memo Field
				} elseif ($this->fields[$fldname]->DataType == DATATYPE_XML) {
					$newvalue = "[XML]"; // XML Field
				} else {
					$newvalue = $rs[$fldname];
				}
				WriteAuditTrail("log", $dt, $id, $usr, "A", $table, $fldname, $key, "", $newvalue);
			}
		}
	}

	// Write Audit Trail (edit page)
	public function writeAuditTrailOnEdit(&$rsold, &$rsnew)
	{
		global $Language;
		if (!$this->AuditTrailOnEdit)
			return;
		$table = 'useritem';

		// Get key value
		$key = "";
		if ($key != "")
			$key .= Config("COMPOSITE_KEY_SEPARATOR");
		$key .= $rsold['recid'];

		// Write Audit Trail
		$dt = DbCurrentDateTime();
		$id = ScriptName();
		$usr = CurrentUserName();
		foreach (array_keys($rsnew) as $fldname) {
			if (array_key_exists($fldname, $this->fields) && array_key_exists($fldname, $rsold) && $this->fields[$fldname]->DataType != DATATYPE_BLOB) { // Ignore BLOB fields
				if ($this->fields[$fldname]->DataType == DATATYPE_DATE) { // DateTime field
					$modified = (FormatDateTime($rsold[$fldname], 0) != FormatDateTime($rsnew[$fldname], 0));
				} else {
					$modified = !CompareValue($rsold[$fldname], $rsnew[$fldname]);
				}
				if ($modified) {
					if ($this->fields[$fldname]->HtmlTag == "PASSWORD") { // Password Field
						$oldvalue = $Language->phrase("PasswordMask");
						$newvalue = $Language->phrase("PasswordMask");
					} elseif ($this->fields[$fldname]->DataType == DATATYPE_MEMO) { // Memo field
						if (Config("AUDIT_TRAIL_TO_DATABASE")) {
							$oldvalue = $rsold[$fldname];
							$newvalue = $rsnew[$fldname];
						} else {
							$oldvalue = "[MEMO]";
							$newvalue = "[MEMO]";
						}
					} elseif ($this->fields[$fldname]->DataType == DATATYPE_XML) { // XML field
						$oldvalue = "[XML]";
						$newvalue = "[XML]";
					} else {
						$oldvalue = $rsold[$fldname];
						$newvalue = $rsnew[$fldname];
					}
					WriteAuditTrail("log", $dt, $id, $usr, "U", $table, $fldname, $key, $oldvalue, $newvalue);
				}
			}
		}
	}

	// Write Audit Trail (delete page)
	public function writeAuditTrailOnDelete(&$rs)
	{
		global $Language;
		if (!$this->AuditTrailOnDelete)
			return;
		$table = 'useritem';

		// Get key value
		$key = "";
		if ($key != "")
			$key .= Config("COMPOSITE_KEY_SEPARATOR");
		$key .= $rs['recid'];

		// Write Audit Trail
		$dt = DbCurrentDateTime();
		$id = ScriptName();
		$curUser = CurrentUserName();
		foreach (array_keys($rs) as $fldname) {
			if (array_key_exists($fldname, $this->fields) && $this->fields[$fldname]->DataType != DATATYPE_BLOB) { // Ignore BLOB fields
				if ($this->fields[$fldname]->HtmlTag == "PASSWORD") {
					$oldvalue = $Language->phrase("PasswordMask"); // Password Field
				} elseif ($this->fields[$fldname]->DataType == DATATYPE_MEMO) {
					if (Config("AUDIT_TRAIL_TO_DATABASE"))
						$oldvalue = $rs[$fldname];
					else
						$oldvalue = "[MEMO]"; // Memo field
				} elseif ($this->fields[$fldname]->DataType == DATATYPE_XML) {
					$oldvalue = "[XML]"; // XML field
				} else {
					$oldvalue = $rs[$fldname];
				}
				WriteAuditTrail("log", $dt, $id, $curUser, "D", $table, $fldname, $key, $oldvalue, "");
			}
		}
	}

	// Table level events
	// Recordset Selecting event
	function Recordset_Selecting(&$filter) {

		// Enter your code here
	}

	// Recordset Selected event
	function Recordset_Selected(&$rs) {

		//echo "Recordset Selected";
	}

	// Recordset Search Validated event
	function Recordset_SearchValidated() {

		// Example:
		//$this->MyField1->AdvancedSearch->SearchValue = "your search criteria"; // Search value

	}

	// Recordset Searching event
	function Recordset_Searching(&$filter) {

		// Enter your code here
	}

	// Row_Selecting event
	function Row_Selecting(&$filter) {

		// Enter your code here
	}

	// Row Selected event
	function Row_Selected(&$rs) {

		//echo "Row Selected";
	}

	// Row Inserting event
	function Row_Inserting($rsold, &$rsnew) {

		// Enter your code here
		// To cancel, set return value to FALSE

		return TRUE;
	}

	// Row Inserted event
	function Row_Inserted($rsold, &$rsnew) {

		//echo "Row Inserted"
	}

	// Row Updating event
	function Row_Updating($rsold, &$rsnew) {

		// Enter your code here
		// To cancel, set return value to FALSE

		return TRUE;
	}

	// Row Updated event
	function Row_Updated($rsold, &$rsnew) {

		//echo "Row Updated";
	}

	// Row Update Conflict event
	function Row_UpdateConflict($rsold, &$rsnew) {

		// Enter your code here
		// To ignore conflict, set return value to FALSE

		return TRUE;
	}

	// Grid Inserting event
	function Grid_Inserting() {

		// Enter your code here
		// To reject grid insert, set return value to FALSE

		return TRUE;
	}

	// Grid Inserted event
	function Grid_Inserted($rsnew) {

		//echo "Grid Inserted";
	}

	// Grid Updating event
	function Grid_Updating($rsold) {

		// Enter your code here
		// To reject grid update, set return value to FALSE

		return TRUE;
	}

	// Grid Updated event
	function Grid_Updated($rsold, $rsnew) {

		//echo "Grid Updated";
	}

	// Row Deleting event
	function Row_Deleting(&$rs) {

		// Enter your code here
		// To cancel, set return value to False

		return TRUE;
	}

	// Row Deleted event
	function Row_Deleted(&$rs) {

		//echo "Row Deleted";
	}

	// Email Sending event
	function Email_Sending($email, &$args) {

		//var_dump($email); var_dump($args); exit();
		return TRUE;
	}

	// Lookup Selecting event
	function Lookup_Selecting($fld, &$filter) {

		//var_dump($fld->Name, $fld->Lookup, $filter); // Uncomment to view the filter
		// Enter your code here

	}

	// Row Rendering event
	function Row_Rendering() {

		// Enter your code here
	}

	// Row Rendered event
	function Row_Rendered() {

		// To view properties of field class, use:
		//var_dump($this-><FieldName>);

	}

	// User ID Filtering event
	function UserID_Filtering(&$filter) {

		// Enter your code here
	}
}
?>