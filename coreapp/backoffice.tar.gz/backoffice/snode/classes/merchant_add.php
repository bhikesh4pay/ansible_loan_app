<?php
namespace PHPMaker2020\_4payadmin;

/**
 * Page class
 */
class merchant_add extends merchant
{

	// Page ID
	public $PageID = "add";

	// Project ID
	public $ProjectID = "{153C2D2E-60EE-4944-8753-3935EB38E8D6}";

	// Table name
	public $TableName = 'merchant';

	// Page object name
	public $PageObjName = "merchant_add";

	// Audit Trail
	public $AuditTrailOnAdd = TRUE;
	public $AuditTrailOnEdit = TRUE;
	public $AuditTrailOnDelete = TRUE;
	public $AuditTrailOnView = FALSE;
	public $AuditTrailOnViewData = FALSE;
	public $AuditTrailOnSearch = FALSE;

	// Page headings
	public $Heading = "";
	public $Subheading = "";
	public $PageHeader;
	public $PageFooter;

	// Token
	public $Token = "";
	public $TokenTimeout = 0;
	public $CheckToken;

	// Page heading
	public function pageHeading()
	{
		global $Language;
		if ($this->Heading != "")
			return $this->Heading;
		if (method_exists($this, "tableCaption"))
			return $this->tableCaption();
		return "";
	}

	// Page subheading
	public function pageSubheading()
	{
		global $Language;
		if ($this->Subheading != "")
			return $this->Subheading;
		if ($this->TableName)
			return $Language->phrase($this->PageID);
		return "";
	}

	// Page name
	public function pageName()
	{
		return CurrentPageName();
	}

	// Page URL
	public function pageUrl()
	{
		$url = CurrentPageName() . "?";
		if ($this->UseTokenInUrl)
			$url .= "t=" . $this->TableVar . "&"; // Add page token
		return $url;
	}

	// Messages
	private $_message = "";
	private $_failureMessage = "";
	private $_successMessage = "";
	private $_warningMessage = "";

	// Get message
	public function getMessage()
	{
		return isset($_SESSION[SESSION_MESSAGE]) ? $_SESSION[SESSION_MESSAGE] : $this->_message;
	}

	// Set message
	public function setMessage($v)
	{
		AddMessage($this->_message, $v);
		$_SESSION[SESSION_MESSAGE] = $this->_message;
	}

	// Get failure message
	public function getFailureMessage()
	{
		return isset($_SESSION[SESSION_FAILURE_MESSAGE]) ? $_SESSION[SESSION_FAILURE_MESSAGE] : $this->_failureMessage;
	}

	// Set failure message
	public function setFailureMessage($v)
	{
		AddMessage($this->_failureMessage, $v);
		$_SESSION[SESSION_FAILURE_MESSAGE] = $this->_failureMessage;
	}

	// Get success message
	public function getSuccessMessage()
	{
		return isset($_SESSION[SESSION_SUCCESS_MESSAGE]) ? $_SESSION[SESSION_SUCCESS_MESSAGE] : $this->_successMessage;
	}

	// Set success message
	public function setSuccessMessage($v)
	{
		AddMessage($this->_successMessage, $v);
		$_SESSION[SESSION_SUCCESS_MESSAGE] = $this->_successMessage;
	}

	// Get warning message
	public function getWarningMessage()
	{
		return isset($_SESSION[SESSION_WARNING_MESSAGE]) ? $_SESSION[SESSION_WARNING_MESSAGE] : $this->_warningMessage;
	}

	// Set warning message
	public function setWarningMessage($v)
	{
		AddMessage($this->_warningMessage, $v);
		$_SESSION[SESSION_WARNING_MESSAGE] = $this->_warningMessage;
	}

	// Clear message
	public function clearMessage()
	{
		$this->_message = "";
		$_SESSION[SESSION_MESSAGE] = "";
	}

	// Clear failure message
	public function clearFailureMessage()
	{
		$this->_failureMessage = "";
		$_SESSION[SESSION_FAILURE_MESSAGE] = "";
	}

	// Clear success message
	public function clearSuccessMessage()
	{
		$this->_successMessage = "";
		$_SESSION[SESSION_SUCCESS_MESSAGE] = "";
	}

	// Clear warning message
	public function clearWarningMessage()
	{
		$this->_warningMessage = "";
		$_SESSION[SESSION_WARNING_MESSAGE] = "";
	}

	// Clear messages
	public function clearMessages()
	{
		$this->clearMessage();
		$this->clearFailureMessage();
		$this->clearSuccessMessage();
		$this->clearWarningMessage();
	}

	// Show message
	public function showMessage()
	{
		$hidden = FALSE;
		$html = "";

		// Message
		$message = $this->getMessage();
		if (method_exists($this, "Message_Showing"))
			$this->Message_Showing($message, "");
		if ($message != "") { // Message in Session, display
			if (!$hidden)
				$message = '<button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button>' . $message;
			$html .= '<div class="alert alert-info alert-dismissible ew-info"><i class="icon fas fa-info"></i>' . $message . '</div>';
			$_SESSION[SESSION_MESSAGE] = ""; // Clear message in Session
		}

		// Warning message
		$warningMessage = $this->getWarningMessage();
		if (method_exists($this, "Message_Showing"))
			$this->Message_Showing($warningMessage, "warning");
		if ($warningMessage != "") { // Message in Session, display
			if (!$hidden)
				$warningMessage = '<button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button>' . $warningMessage;
			$html .= '<div class="alert alert-warning alert-dismissible ew-warning"><i class="icon fas fa-exclamation"></i>' . $warningMessage . '</div>';
			$_SESSION[SESSION_WARNING_MESSAGE] = ""; // Clear message in Session
		}

		// Success message
		$successMessage = $this->getSuccessMessage();
		if (method_exists($this, "Message_Showing"))
			$this->Message_Showing($successMessage, "success");
		if ($successMessage != "") { // Message in Session, display
			if (!$hidden)
				$successMessage = '<button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button>' . $successMessage;
			$html .= '<div class="alert alert-success alert-dismissible ew-success"><i class="icon fas fa-check"></i>' . $successMessage . '</div>';
			$_SESSION[SESSION_SUCCESS_MESSAGE] = ""; // Clear message in Session
		}

		// Failure message
		$errorMessage = $this->getFailureMessage();
		if (method_exists($this, "Message_Showing"))
			$this->Message_Showing($errorMessage, "failure");
		if ($errorMessage != "") { // Message in Session, display
			if (!$hidden)
				$errorMessage = '<button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button>' . $errorMessage;
			$html .= '<div class="alert alert-danger alert-dismissible ew-error"><i class="icon fas fa-ban"></i>' . $errorMessage . '</div>';
			$_SESSION[SESSION_FAILURE_MESSAGE] = ""; // Clear message in Session
		}
		echo '<div class="ew-message-dialog' . (($hidden) ? ' d-none' : "") . '">' . $html . '</div>';
	}

	// Get message as array
	public function getMessages()
	{
		$ar = [];

		// Message
		$message = $this->getMessage();

		//if (method_exists($this, "Message_Showing"))
		//	$this->Message_Showing($message, "");

		if ($message != "") { // Message in Session, display
			$ar["message"] = $message;
			$_SESSION[SESSION_MESSAGE] = ""; // Clear message in Session
		}

		// Warning message
		$warningMessage = $this->getWarningMessage();

		//if (method_exists($this, "Message_Showing"))
		//	$this->Message_Showing($warningMessage, "warning");

		if ($warningMessage != "") { // Message in Session, display
			$ar["warningMessage"] = $warningMessage;
			$_SESSION[SESSION_WARNING_MESSAGE] = ""; // Clear message in Session
		}

		// Success message
		$successMessage = $this->getSuccessMessage();

		//if (method_exists($this, "Message_Showing"))
		//	$this->Message_Showing($successMessage, "success");

		if ($successMessage != "") { // Message in Session, display
			$ar["successMessage"] = $successMessage;
			$_SESSION[SESSION_SUCCESS_MESSAGE] = ""; // Clear message in Session
		}

		// Failure message
		$failureMessage = $this->getFailureMessage();

		//if (method_exists($this, "Message_Showing"))
		//	$this->Message_Showing($failureMessage, "failure");

		if ($failureMessage != "") { // Message in Session, display
			$ar["failureMessage"] = $failureMessage;
			$_SESSION[SESSION_FAILURE_MESSAGE] = ""; // Clear message in Session
		}
		return $ar;
	}

	// Show Page Header
	public function showPageHeader()
	{
		$header = $this->PageHeader;
		$this->Page_DataRendering($header);
		if ($header != "") { // Header exists, display
			echo '<p id="ew-page-header">' . $header . '</p>';
		}
	}

	// Show Page Footer
	public function showPageFooter()
	{
		$footer = $this->PageFooter;
		$this->Page_DataRendered($footer);
		if ($footer != "") { // Footer exists, display
			echo '<p id="ew-page-footer">' . $footer . '</p>';
		}
	}

	// Validate page request
	protected function isPageRequest()
	{
		global $CurrentForm;
		if ($this->UseTokenInUrl) {
			if ($CurrentForm)
				return ($this->TableVar == $CurrentForm->getValue("t"));
			if (Get("t") !== NULL)
				return ($this->TableVar == Get("t"));
		}
		return TRUE;
	}

	// Valid Post
	protected function validPost()
	{
		if (!$this->CheckToken || !IsPost() || IsApi())
			return TRUE;
		if (Post(Config("TOKEN_NAME")) === NULL)
			return FALSE;
		$fn = Config("CHECK_TOKEN_FUNC");
		if (is_callable($fn))
			return $fn(Post(Config("TOKEN_NAME")), $this->TokenTimeout);
		return FALSE;
	}

	// Create Token
	public function createToken()
	{
		global $CurrentToken;
		$fn = Config("CREATE_TOKEN_FUNC"); // Always create token, required by API file/lookup request
		if ($this->Token == "" && is_callable($fn)) // Create token
			$this->Token = $fn();
		$CurrentToken = $this->Token; // Save to global variable
	}

	// Constructor
	public function __construct()
	{
		global $Language, $DashboardReport;
		global $UserTable;

		// Check token
		$this->CheckToken = Config("CHECK_TOKEN");

		// Initialize
		$GLOBALS["Page"] = &$this;
		$this->TokenTimeout = SessionTimeoutTime();

		// Language object
		if (!isset($Language))
			$Language = new Language();

		// Parent constuctor
		parent::__construct();

		// Table object (merchant)
		if (!isset($GLOBALS["merchant"]) || get_class($GLOBALS["merchant"]) == PROJECT_NAMESPACE . "merchant") {
			$GLOBALS["merchant"] = &$this;
			$GLOBALS["Table"] = &$GLOBALS["merchant"];
		}

		// Table object (admin)
		if (!isset($GLOBALS['admin']))
			$GLOBALS['admin'] = new admin();

		// Page ID (for backward compatibility only)
		if (!defined(PROJECT_NAMESPACE . "PAGE_ID"))
			define(PROJECT_NAMESPACE . "PAGE_ID", 'add');

		// Table name (for backward compatibility only)
		if (!defined(PROJECT_NAMESPACE . "TABLE_NAME"))
			define(PROJECT_NAMESPACE . "TABLE_NAME", 'merchant');

		// Start timer
		if (!isset($GLOBALS["DebugTimer"]))
			$GLOBALS["DebugTimer"] = new Timer();

		// Debug message
		LoadDebugMessage();

		// Open connection
		if (!isset($GLOBALS["Conn"]))
			$GLOBALS["Conn"] = $this->getConnection();

		// User table object (admin)
		$UserTable = $UserTable ?: new admin();
	}

	// Terminate page
	public function terminate($url = "")
	{
		global $ExportFileName, $TempImages, $DashboardReport;

		// Page Unload event
		$this->Page_Unload();

		// Global Page Unloaded event (in userfn*.php)
		Page_Unloaded();

		// Export
		global $merchant;
		if ($this->CustomExport && $this->CustomExport == $this->Export && array_key_exists($this->CustomExport, Config("EXPORT_CLASSES"))) {
				$content = ob_get_contents();
			if ($ExportFileName == "")
				$ExportFileName = $this->TableVar;
			$class = PROJECT_NAMESPACE . Config("EXPORT_CLASSES." . $this->CustomExport);
			if (class_exists($class)) {
				$doc = new $class($merchant);
				$doc->Text = @$content;
				if ($this->isExport("email"))
					echo $this->exportEmail($doc->Text);
				else
					$doc->export();
				DeleteTempImages(); // Delete temp images
				exit();
			}
		}
		if (!IsApi())
			$this->Page_Redirecting($url);

		// Close connection
		CloseConnections();

		// Return for API
		if (IsApi()) {
			$res = $url === TRUE;
			if (!$res) // Show error
				WriteJson(array_merge(["success" => FALSE], $this->getMessages()));
			return;
		}

		// Go to URL if specified
		if ($url != "") {
			if (!Config("DEBUG") && ob_get_length())
				ob_end_clean();

			// Handle modal response
			if ($this->IsModal) { // Show as modal
				$row = ["url" => $url, "modal" => "1"];
				$pageName = GetPageName($url);
				if ($pageName != $this->getListUrl()) { // Not List page
					$row["caption"] = $this->getModalCaption($pageName);
					if ($pageName == "merchantview.php")
						$row["view"] = "1";
				} else { // List page should not be shown as modal => error
					$row["error"] = $this->getFailureMessage();
					$this->clearFailureMessage();
				}
				WriteJson($row);
			} else {
				SaveDebugMessage();
				AddHeader("Location", $url);
			}
		}
		exit();
	}

	// Get records from recordset
	protected function getRecordsFromRecordset($rs, $current = FALSE)
	{
		$rows = [];
		if (is_object($rs)) { // Recordset
			while ($rs && !$rs->EOF) {
				$this->loadRowValues($rs); // Set up DbValue/CurrentValue
				$row = $this->getRecordFromArray($rs->fields);
				if ($current)
					return $row;
				else
					$rows[] = $row;
				$rs->moveNext();
			}
		} elseif (is_array($rs)) {
			foreach ($rs as $ar) {
				$row = $this->getRecordFromArray($ar);
				if ($current)
					return $row;
				else
					$rows[] = $row;
			}
		}
		return $rows;
	}

	// Get record from array
	protected function getRecordFromArray($ar)
	{
		$row = [];
		if (is_array($ar)) {
			foreach ($ar as $fldname => $val) {
				if (array_key_exists($fldname, $this->fields) && ($this->fields[$fldname]->Visible || $this->fields[$fldname]->IsPrimaryKey)) { // Primary key or Visible
					$fld = &$this->fields[$fldname];
					if ($fld->HtmlTag == "FILE") { // Upload field
						if (EmptyValue($val)) {
							$row[$fldname] = NULL;
						} else {
							if ($fld->DataType == DATATYPE_BLOB) {
								$url = FullUrl(GetApiUrl(Config("API_FILE_ACTION"),
									Config("API_OBJECT_NAME") . "=" . $fld->TableVar . "&" .
									Config("API_FIELD_NAME") . "=" . $fld->Param . "&" .
									Config("API_KEY_NAME") . "=" . rawurlencode($this->getRecordKeyValue($ar)))); //*** need to add this? API may not be in the same folder
								$row[$fldname] = ["type" => ContentType($val), "url" => $url, "name" => $fld->Param . ContentExtension($val)];
							} elseif (!$fld->UploadMultiple || !ContainsString($val, Config("MULTIPLE_UPLOAD_SEPARATOR"))) { // Single file
								$url = FullUrl(GetApiUrl(Config("API_FILE_ACTION"),
									Config("API_OBJECT_NAME") . "=" . $fld->TableVar . "&" .
									"fn=" . Encrypt($fld->physicalUploadPath() . $val)));
								$row[$fldname] = ["type" => MimeContentType($val), "url" => $url, "name" => $val];
							} else { // Multiple files
								$files = explode(Config("MULTIPLE_UPLOAD_SEPARATOR"), $val);
								$ar = [];
								foreach ($files as $file) {
									$url = FullUrl(GetApiUrl(Config("API_FILE_ACTION"),
										Config("API_OBJECT_NAME") . "=" . $fld->TableVar . "&" .
										"fn=" . Encrypt($fld->physicalUploadPath() . $file)));
									if (!EmptyValue($file))
										$ar[] = ["type" => MimeContentType($file), "url" => $url, "name" => $file];
								}
								$row[$fldname] = $ar;
							}
						}
					} else {
						$row[$fldname] = $val;
					}
				}
			}
		}
		return $row;
	}

	// Get record key value from array
	protected function getRecordKeyValue($ar)
	{
		$key = "";
		if (is_array($ar)) {
			$key .= @$ar['userid'];
		}
		return $key;
	}

	/**
	 * Hide fields for add/edit
	 *
	 * @return void
	 */
	protected function hideFieldsForAddEdit()
	{
	}

	// Lookup data
	public function lookup()
	{
		global $Language, $Security;
		if (!isset($Language))
			$Language = new Language(Config("LANGUAGE_FOLDER"), Post("language", ""));

		// Set up API request
		if (!ValidApiRequest())
			return FALSE;
		$this->setupApiSecurity();

		// Get lookup object
		$fieldName = Post("field");
		if (!array_key_exists($fieldName, $this->fields))
			return FALSE;
		$lookupField = $this->fields[$fieldName];
		$lookup = $lookupField->Lookup;
		if ($lookup === NULL)
			return FALSE;
		$tbl = $lookup->getTable();
		if (!$Security->allowLookup(Config("PROJECT_ID") . $tbl->TableName)) // Lookup permission
			return FALSE;

		// Get lookup parameters
		$lookupType = Post("ajax", "unknown");
		$pageSize = -1;
		$offset = -1;
		$searchValue = "";
		if (SameText($lookupType, "modal")) {
			$searchValue = Post("sv", "");
			$pageSize = Post("recperpage", 10);
			$offset = Post("start", 0);
		} elseif (SameText($lookupType, "autosuggest")) {
			$searchValue = Param("q", "");
			$pageSize = Param("n", -1);
			$pageSize = is_numeric($pageSize) ? (int)$pageSize : -1;
			if ($pageSize <= 0)
				$pageSize = Config("AUTO_SUGGEST_MAX_ENTRIES");
			$start = Param("start", -1);
			$start = is_numeric($start) ? (int)$start : -1;
			$page = Param("page", -1);
			$page = is_numeric($page) ? (int)$page : -1;
			$offset = $start >= 0 ? $start : ($page > 0 && $pageSize > 0 ? ($page - 1) * $pageSize : 0);
		}
		$userSelect = Decrypt(Post("s", ""));
		$userFilter = Decrypt(Post("f", ""));
		$userOrderBy = Decrypt(Post("o", ""));
		$keys = Post("keys");
		$lookup->LookupType = $lookupType; // Lookup type
		if ($keys !== NULL) { // Selected records from modal
			if (is_array($keys))
				$keys = implode(Config("MULTIPLE_OPTION_SEPARATOR"), $keys);
			$lookup->FilterFields = []; // Skip parent fields if any
			$lookup->FilterValues[] = $keys; // Lookup values
			$pageSize = -1; // Show all records
		} else { // Lookup values
			$lookup->FilterValues[] = Post("v0", Post("lookupValue", ""));
		}
		$cnt = is_array($lookup->FilterFields) ? count($lookup->FilterFields) : 0;
		for ($i = 1; $i <= $cnt; $i++)
			$lookup->FilterValues[] = Post("v" . $i, "");
		$lookup->SearchValue = $searchValue;
		$lookup->PageSize = $pageSize;
		$lookup->Offset = $offset;
		if ($userSelect != "")
			$lookup->UserSelect = $userSelect;
		if ($userFilter != "")
			$lookup->UserFilter = $userFilter;
		if ($userOrderBy != "")
			$lookup->UserOrderBy = $userOrderBy;
		$lookup->toJson($this); // Use settings from current page
	}

	// Set up API security
	public function setupApiSecurity()
	{
		global $Security;

		// Setup security for API request
		if ($Security->isLoggedIn()) $Security->TablePermission_Loading();
		$Security->loadCurrentUserLevel(Config("PROJECT_ID") . $this->TableName);
		if ($Security->isLoggedIn()) $Security->TablePermission_Loaded();
	}
	public $FormClassName = "ew-horizontal ew-form ew-add-form";
	public $IsModal = FALSE;
	public $IsMobileOrModal = FALSE;
	public $DbMasterFilter = "";
	public $DbDetailFilter = "";
	public $StartRecord;
	public $Priv = 0;
	public $OldRecordset;
	public $CopyRecord;
	public $MultiPages; // Multi pages object
	public $DetailPages; // Detail pages object

	//
	// Page run
	//

	public function run()
	{
		global $ExportType, $CustomExportType, $ExportFileName, $UserProfile, $Language, $Security, $CurrentForm,
			$FormError, $SkipHeaderFooter;

		// Is modal
		$this->IsModal = (Param("modal") == "1");

		// User profile
		$UserProfile = new UserProfile();

		// Security
		if (ValidApiRequest()) { // API request
			$this->setupApiSecurity(); // Set up API Security
			if (!$Security->canAdd()) {
				SetStatus(401); // Unauthorized
				return;
			}
		} else {
			$Security = new AdvancedSecurity();
			if (IsPasswordExpired())
				$this->terminate(GetUrl("changepwd.php"));
			if (!$Security->isLoggedIn())
				$Security->autoLogin();
			if ($Security->isLoggedIn())
				$Security->TablePermission_Loading();
			$Security->loadCurrentUserLevel($this->ProjectID . $this->TableName);
			if ($Security->isLoggedIn())
				$Security->TablePermission_Loaded();
			if (!$Security->canAdd()) {
				$Security->saveLastUrl();
				$this->setFailureMessage(DeniedMessage()); // Set no permission
				if ($Security->canList())
					$this->terminate(GetUrl("merchantlist.php"));
				else
					$this->terminate(GetUrl("login.php"));
				return;
			}
		}

		// Create form object
		$CurrentForm = new HttpForm();
		$this->CurrentAction = Param("action"); // Set up current action
		$this->_userid->setVisibility();
		$this->businessname->setVisibility();
		$this->officialname->setVisibility();
		$this->changed->setVisibility();
		$this->active->setVisibility();
		$this->tipallowed->setVisibility();
		$this->merchanttoaddtip->setVisibility();
		$this->pis->setVisibility();
		$this->ratetableid->setVisibility();
		$this->ratetabletype->setVisibility();
		$this->officialdocnumber->setVisibility();
		$this->officialdocname->setVisibility();
		$this->softposid->setVisibility();
		$this->taxamount->setVisibility();
		$this->variabletax->setVisibility();
		$this->logofilename->setVisibility();
		$this->returndays->setVisibility();
		$this->memberextrafieldsid->setVisibility();
		$this->lastupdatedate->setVisibility();
		$this->remmitancetype->setVisibility();
		$this->withholdingtaxaccount->setVisibility();
		$this->businessphoneno->setVisibility();
		$this->businessaddress1->setVisibility();
		$this->businessaddress2->setVisibility();
		$this->businesscity->setVisibility();
		$this->businesscountry->setVisibility();
		$this->businessstate->setVisibility();
		$this->businesszipcode->setVisibility();
		$this->bankname->setVisibility();
		$this->bankbranchnumber->setVisibility();
		$this->bankaccountnumber->setVisibility();
		$this->other1->setVisibility();
		$this->other2->setVisibility();
		$this->other3->setVisibility();
		$this->externalid->setVisibility();
		$this->couponpin->setVisibility();
		$this->swiftcode->setVisibility();
		$this->profilevalidated->setVisibility();
		$this->profilevalidationdate->setVisibility();
		$this->industry->setVisibility();
		$this->legalstructure->setVisibility();
		$this->extendedfields->setVisibility();
		$this->hideFieldsForAddEdit();

		// Do not use lookup cache
		$this->setUseLookupCache(FALSE);

		// Set up multi page object
		$this->setupMultiPages();

		// Set up detail page object
		$this->setupDetailPages();

		// Global Page Loading event (in userfn*.php)
		Page_Loading();

		// Page Load event
		$this->Page_Load();

		// Check token
		if (!$this->validPost()) {
			Write($Language->phrase("InvalidPostRequest"));
			$this->terminate();
		}

		// Create Token
		$this->createToken();

		// Set up lookup cache
		$this->setupLookupOptions($this->changed);
		$this->setupLookupOptions($this->active);
		$this->setupLookupOptions($this->tipallowed);
		$this->setupLookupOptions($this->merchanttoaddtip);
		$this->setupLookupOptions($this->ratetabletype);
		$this->setupLookupOptions($this->variabletax);
		$this->setupLookupOptions($this->businesscountry);
		$this->setupLookupOptions($this->businessstate);
		$this->setupLookupOptions($this->profilevalidated);
		$this->setupLookupOptions($this->industry);
		$this->setupLookupOptions($this->legalstructure);

		// Check permission
		if (!$Security->canAdd()) {
			$this->setFailureMessage(DeniedMessage()); // No permission
			$this->terminate("merchantlist.php");
			return;
		}

		// Check modal
		if ($this->IsModal)
			$SkipHeaderFooter = TRUE;
		$this->IsMobileOrModal = IsMobile() || $this->IsModal;
		$this->FormClassName = "ew-form ew-add-form ew-horizontal";
		$postBack = FALSE;

		// Set up current action
		if (IsApi()) {
			$this->CurrentAction = "insert"; // Add record directly
			$postBack = TRUE;
		} elseif (Post("action") !== NULL) {
			$this->CurrentAction = Post("action"); // Get form action
			$postBack = TRUE;
		} else { // Not post back

			// Load key values from QueryString
			$this->CopyRecord = TRUE;
			if (Get("_userid") !== NULL) {
				$this->_userid->setQueryStringValue(Get("_userid"));
				$this->setKey("_userid", $this->_userid->CurrentValue); // Set up key
			} else {
				$this->setKey("_userid", ""); // Clear key
				$this->CopyRecord = FALSE;
			}
			if ($this->CopyRecord) {
				$this->CurrentAction = "copy"; // Copy record
			} else {
				$this->CurrentAction = "show"; // Display blank record
			}
		}

		// Load old record / default values
		$loaded = $this->loadOldRecord();

		// Load form values
		if ($postBack) {
			$this->loadFormValues(); // Load form values
		}

		// Set up detail parameters
		$this->setupDetailParms();

		// Validate form if post back
		if ($postBack) {
			if (!$this->validateForm()) {
				$this->EventCancelled = TRUE; // Event cancelled
				$this->restoreFormValues(); // Restore form values
				$this->setFailureMessage($FormError);
				if (IsApi()) {
					$this->terminate();
					return;
				} else {
					$this->CurrentAction = "show"; // Form error, reset action
				}
			}
		}

		// Perform current action
		switch ($this->CurrentAction) {
			case "copy": // Copy an existing record
				if (!$loaded) { // Record not loaded
					if ($this->getFailureMessage() == "")
						$this->setFailureMessage($Language->phrase("NoRecord")); // No record found
					$this->terminate("merchantlist.php"); // No matching record, return to list
				}

				// Set up detail parameters
				$this->setupDetailParms();
				break;
			case "insert": // Add new record
				$this->SendEmail = TRUE; // Send email on add success
				if ($this->addRow($this->OldRecordset)) { // Add successful
					if ($this->getSuccessMessage() == "")
						$this->setSuccessMessage($Language->phrase("AddSuccess")); // Set up success message
					if ($this->getCurrentDetailTable() != "") // Master/detail add
						$returnUrl = $this->getDetailUrl();
					else
						$returnUrl = $this->getReturnUrl();
					if (GetPageName($returnUrl) == "merchantlist.php")
						$returnUrl = $this->addMasterUrl($returnUrl); // List page, return to List page with correct master key if necessary
					elseif (GetPageName($returnUrl) == "merchantview.php")
						$returnUrl = $this->getViewUrl(); // View page, return to View page with keyurl directly
					if (IsApi()) { // Return to caller
						$this->terminate(TRUE);
						return;
					} else {
						$this->terminate($returnUrl);
					}
				} elseif (IsApi()) { // API request, return
					$this->terminate();
					return;
				} else {
					$this->EventCancelled = TRUE; // Event cancelled
					$this->restoreFormValues(); // Add failed, restore form values

					// Set up detail parameters
					$this->setupDetailParms();
				}
		}

		// Set up Breadcrumb
		$this->setupBreadcrumb();

		// Render row based on row type
		$this->RowType = ROWTYPE_ADD; // Render add type

		// Render row
		$this->resetAttributes();
		$this->renderRow();
	}

	// Get upload files
	protected function getUploadFiles()
	{
		global $CurrentForm, $Language;
	}

	// Load default values
	protected function loadDefaultValues()
	{
		$this->_userid->CurrentValue = NULL;
		$this->_userid->OldValue = $this->_userid->CurrentValue;
		$this->businessname->CurrentValue = NULL;
		$this->businessname->OldValue = $this->businessname->CurrentValue;
		$this->officialname->CurrentValue = NULL;
		$this->officialname->OldValue = $this->officialname->CurrentValue;
		$this->changed->CurrentValue = 1;
		$this->active->CurrentValue = NULL;
		$this->active->OldValue = $this->active->CurrentValue;
		$this->tipallowed->CurrentValue = 0;
		$this->merchanttoaddtip->CurrentValue = 0;
		$this->pis->CurrentValue = NULL;
		$this->pis->OldValue = $this->pis->CurrentValue;
		$this->ratetableid->CurrentValue = NULL;
		$this->ratetableid->OldValue = $this->ratetableid->CurrentValue;
		$this->ratetabletype->CurrentValue = NULL;
		$this->ratetabletype->OldValue = $this->ratetabletype->CurrentValue;
		$this->officialdocnumber->CurrentValue = NULL;
		$this->officialdocnumber->OldValue = $this->officialdocnumber->CurrentValue;
		$this->officialdocname->CurrentValue = NULL;
		$this->officialdocname->OldValue = $this->officialdocname->CurrentValue;
		$this->softposid->CurrentValue = NULL;
		$this->softposid->OldValue = $this->softposid->CurrentValue;
		$this->taxamount->CurrentValue = 0.00;
		$this->variabletax->CurrentValue = 1;
		$this->logofilename->CurrentValue = "merchantnologo.jpg";
		$this->returndays->CurrentValue = 0;
		$this->memberextrafieldsid->CurrentValue = NULL;
		$this->memberextrafieldsid->OldValue = $this->memberextrafieldsid->CurrentValue;
		$this->lastupdatedate->CurrentValue = NULL;
		$this->lastupdatedate->OldValue = $this->lastupdatedate->CurrentValue;
		$this->remmitancetype->CurrentValue = 0;
		$this->withholdingtaxaccount->CurrentValue = 0;
		$this->businessphoneno->CurrentValue = NULL;
		$this->businessphoneno->OldValue = $this->businessphoneno->CurrentValue;
		$this->businessaddress1->CurrentValue = NULL;
		$this->businessaddress1->OldValue = $this->businessaddress1->CurrentValue;
		$this->businessaddress2->CurrentValue = NULL;
		$this->businessaddress2->OldValue = $this->businessaddress2->CurrentValue;
		$this->businesscity->CurrentValue = NULL;
		$this->businesscity->OldValue = $this->businesscity->CurrentValue;
		$this->businesscountry->CurrentValue = NULL;
		$this->businesscountry->OldValue = $this->businesscountry->CurrentValue;
		$this->businessstate->CurrentValue = NULL;
		$this->businessstate->OldValue = $this->businessstate->CurrentValue;
		$this->businesszipcode->CurrentValue = NULL;
		$this->businesszipcode->OldValue = $this->businesszipcode->CurrentValue;
		$this->bankname->CurrentValue = NULL;
		$this->bankname->OldValue = $this->bankname->CurrentValue;
		$this->bankbranchnumber->CurrentValue = NULL;
		$this->bankbranchnumber->OldValue = $this->bankbranchnumber->CurrentValue;
		$this->bankaccountnumber->CurrentValue = NULL;
		$this->bankaccountnumber->OldValue = $this->bankaccountnumber->CurrentValue;
		$this->other1->CurrentValue = NULL;
		$this->other1->OldValue = $this->other1->CurrentValue;
		$this->other2->CurrentValue = NULL;
		$this->other2->OldValue = $this->other2->CurrentValue;
		$this->other3->CurrentValue = NULL;
		$this->other3->OldValue = $this->other3->CurrentValue;
		$this->externalid->CurrentValue = NULL;
		$this->externalid->OldValue = $this->externalid->CurrentValue;
		$this->couponpin->CurrentValue = NULL;
		$this->couponpin->OldValue = $this->couponpin->CurrentValue;
		$this->swiftcode->CurrentValue = NULL;
		$this->swiftcode->OldValue = $this->swiftcode->CurrentValue;
		$this->profilevalidated->CurrentValue = 0;
		$this->profilevalidationdate->CurrentValue = NULL;
		$this->profilevalidationdate->OldValue = $this->profilevalidationdate->CurrentValue;
		$this->industry->CurrentValue = NULL;
		$this->industry->OldValue = $this->industry->CurrentValue;
		$this->legalstructure->CurrentValue = NULL;
		$this->legalstructure->OldValue = $this->legalstructure->CurrentValue;
		$this->extendedfields->CurrentValue = NULL;
		$this->extendedfields->OldValue = $this->extendedfields->CurrentValue;
	}

	// Load form values
	protected function loadFormValues()
	{

		// Load from form
		global $CurrentForm;

		// Check field name 'userid' first before field var 'x__userid'
		$val = $CurrentForm->hasValue("userid") ? $CurrentForm->getValue("userid") : $CurrentForm->getValue("x__userid");
		if (!$this->_userid->IsDetailKey) {
			if (IsApi() && $val === NULL)
				$this->_userid->Visible = FALSE; // Disable update for API request
			else
				$this->_userid->setFormValue($val);
		}

		// Check field name 'businessname' first before field var 'x_businessname'
		$val = $CurrentForm->hasValue("businessname") ? $CurrentForm->getValue("businessname") : $CurrentForm->getValue("x_businessname");
		if (!$this->businessname->IsDetailKey) {
			if (IsApi() && $val === NULL)
				$this->businessname->Visible = FALSE; // Disable update for API request
			else
				$this->businessname->setFormValue($val);
		}

		// Check field name 'officialname' first before field var 'x_officialname'
		$val = $CurrentForm->hasValue("officialname") ? $CurrentForm->getValue("officialname") : $CurrentForm->getValue("x_officialname");
		if (!$this->officialname->IsDetailKey) {
			if (IsApi() && $val === NULL)
				$this->officialname->Visible = FALSE; // Disable update for API request
			else
				$this->officialname->setFormValue($val);
		}

		// Check field name 'changed' first before field var 'x_changed'
		$val = $CurrentForm->hasValue("changed") ? $CurrentForm->getValue("changed") : $CurrentForm->getValue("x_changed");
		if (!$this->changed->IsDetailKey) {
			if (IsApi() && $val === NULL)
				$this->changed->Visible = FALSE; // Disable update for API request
			else
				$this->changed->setFormValue($val);
		}

		// Check field name 'active' first before field var 'x_active'
		$val = $CurrentForm->hasValue("active") ? $CurrentForm->getValue("active") : $CurrentForm->getValue("x_active");
		if (!$this->active->IsDetailKey) {
			if (IsApi() && $val === NULL)
				$this->active->Visible = FALSE; // Disable update for API request
			else
				$this->active->setFormValue($val);
		}

		// Check field name 'tipallowed' first before field var 'x_tipallowed'
		$val = $CurrentForm->hasValue("tipallowed") ? $CurrentForm->getValue("tipallowed") : $CurrentForm->getValue("x_tipallowed");
		if (!$this->tipallowed->IsDetailKey) {
			if (IsApi() && $val === NULL)
				$this->tipallowed->Visible = FALSE; // Disable update for API request
			else
				$this->tipallowed->setFormValue($val);
		}

		// Check field name 'merchanttoaddtip' first before field var 'x_merchanttoaddtip'
		$val = $CurrentForm->hasValue("merchanttoaddtip") ? $CurrentForm->getValue("merchanttoaddtip") : $CurrentForm->getValue("x_merchanttoaddtip");
		if (!$this->merchanttoaddtip->IsDetailKey) {
			if (IsApi() && $val === NULL)
				$this->merchanttoaddtip->Visible = FALSE; // Disable update for API request
			else
				$this->merchanttoaddtip->setFormValue($val);
		}

		// Check field name 'pis' first before field var 'x_pis'
		$val = $CurrentForm->hasValue("pis") ? $CurrentForm->getValue("pis") : $CurrentForm->getValue("x_pis");
		if (!$this->pis->IsDetailKey) {
			if (IsApi() && $val === NULL)
				$this->pis->Visible = FALSE; // Disable update for API request
			else
				$this->pis->setFormValue($val);
		}

		// Check field name 'ratetableid' first before field var 'x_ratetableid'
		$val = $CurrentForm->hasValue("ratetableid") ? $CurrentForm->getValue("ratetableid") : $CurrentForm->getValue("x_ratetableid");
		if (!$this->ratetableid->IsDetailKey) {
			if (IsApi() && $val === NULL)
				$this->ratetableid->Visible = FALSE; // Disable update for API request
			else
				$this->ratetableid->setFormValue($val);
		}

		// Check field name 'ratetabletype' first before field var 'x_ratetabletype'
		$val = $CurrentForm->hasValue("ratetabletype") ? $CurrentForm->getValue("ratetabletype") : $CurrentForm->getValue("x_ratetabletype");
		if (!$this->ratetabletype->IsDetailKey) {
			if (IsApi() && $val === NULL)
				$this->ratetabletype->Visible = FALSE; // Disable update for API request
			else
				$this->ratetabletype->setFormValue($val);
		}

		// Check field name 'officialdocnumber' first before field var 'x_officialdocnumber'
		$val = $CurrentForm->hasValue("officialdocnumber") ? $CurrentForm->getValue("officialdocnumber") : $CurrentForm->getValue("x_officialdocnumber");
		if (!$this->officialdocnumber->IsDetailKey) {
			if (IsApi() && $val === NULL)
				$this->officialdocnumber->Visible = FALSE; // Disable update for API request
			else
				$this->officialdocnumber->setFormValue($val);
		}

		// Check field name 'officialdocname' first before field var 'x_officialdocname'
		$val = $CurrentForm->hasValue("officialdocname") ? $CurrentForm->getValue("officialdocname") : $CurrentForm->getValue("x_officialdocname");
		if (!$this->officialdocname->IsDetailKey) {
			if (IsApi() && $val === NULL)
				$this->officialdocname->Visible = FALSE; // Disable update for API request
			else
				$this->officialdocname->setFormValue($val);
		}

		// Check field name 'softposid' first before field var 'x_softposid'
		$val = $CurrentForm->hasValue("softposid") ? $CurrentForm->getValue("softposid") : $CurrentForm->getValue("x_softposid");
		if (!$this->softposid->IsDetailKey) {
			if (IsApi() && $val === NULL)
				$this->softposid->Visible = FALSE; // Disable update for API request
			else
				$this->softposid->setFormValue($val);
		}

		// Check field name 'taxamount' first before field var 'x_taxamount'
		$val = $CurrentForm->hasValue("taxamount") ? $CurrentForm->getValue("taxamount") : $CurrentForm->getValue("x_taxamount");
		if (!$this->taxamount->IsDetailKey) {
			if (IsApi() && $val === NULL)
				$this->taxamount->Visible = FALSE; // Disable update for API request
			else
				$this->taxamount->setFormValue($val);
		}

		// Check field name 'variabletax' first before field var 'x_variabletax'
		$val = $CurrentForm->hasValue("variabletax") ? $CurrentForm->getValue("variabletax") : $CurrentForm->getValue("x_variabletax");
		if (!$this->variabletax->IsDetailKey) {
			if (IsApi() && $val === NULL)
				$this->variabletax->Visible = FALSE; // Disable update for API request
			else
				$this->variabletax->setFormValue($val);
		}

		// Check field name 'logofilename' first before field var 'x_logofilename'
		$val = $CurrentForm->hasValue("logofilename") ? $CurrentForm->getValue("logofilename") : $CurrentForm->getValue("x_logofilename");
		if (!$this->logofilename->IsDetailKey) {
			if (IsApi() && $val === NULL)
				$this->logofilename->Visible = FALSE; // Disable update for API request
			else
				$this->logofilename->setFormValue($val);
		}

		// Check field name 'returndays' first before field var 'x_returndays'
		$val = $CurrentForm->hasValue("returndays") ? $CurrentForm->getValue("returndays") : $CurrentForm->getValue("x_returndays");
		if (!$this->returndays->IsDetailKey) {
			if (IsApi() && $val === NULL)
				$this->returndays->Visible = FALSE; // Disable update for API request
			else
				$this->returndays->setFormValue($val);
		}

		// Check field name 'memberextrafieldsid' first before field var 'x_memberextrafieldsid'
		$val = $CurrentForm->hasValue("memberextrafieldsid") ? $CurrentForm->getValue("memberextrafieldsid") : $CurrentForm->getValue("x_memberextrafieldsid");
		if (!$this->memberextrafieldsid->IsDetailKey) {
			if (IsApi() && $val === NULL)
				$this->memberextrafieldsid->Visible = FALSE; // Disable update for API request
			else
				$this->memberextrafieldsid->setFormValue($val);
		}

		// Check field name 'lastupdatedate' first before field var 'x_lastupdatedate'
		$val = $CurrentForm->hasValue("lastupdatedate") ? $CurrentForm->getValue("lastupdatedate") : $CurrentForm->getValue("x_lastupdatedate");
		if (!$this->lastupdatedate->IsDetailKey) {
			if (IsApi() && $val === NULL)
				$this->lastupdatedate->Visible = FALSE; // Disable update for API request
			else
				$this->lastupdatedate->setFormValue($val);
			$this->lastupdatedate->CurrentValue = UnFormatDateTime($this->lastupdatedate->CurrentValue, 0);
		}

		// Check field name 'remmitancetype' first before field var 'x_remmitancetype'
		$val = $CurrentForm->hasValue("remmitancetype") ? $CurrentForm->getValue("remmitancetype") : $CurrentForm->getValue("x_remmitancetype");
		if (!$this->remmitancetype->IsDetailKey) {
			if (IsApi() && $val === NULL)
				$this->remmitancetype->Visible = FALSE; // Disable update for API request
			else
				$this->remmitancetype->setFormValue($val);
		}

		// Check field name 'withholdingtaxaccount' first before field var 'x_withholdingtaxaccount'
		$val = $CurrentForm->hasValue("withholdingtaxaccount") ? $CurrentForm->getValue("withholdingtaxaccount") : $CurrentForm->getValue("x_withholdingtaxaccount");
		if (!$this->withholdingtaxaccount->IsDetailKey) {
			if (IsApi() && $val === NULL)
				$this->withholdingtaxaccount->Visible = FALSE; // Disable update for API request
			else
				$this->withholdingtaxaccount->setFormValue($val);
		}

		// Check field name 'businessphoneno' first before field var 'x_businessphoneno'
		$val = $CurrentForm->hasValue("businessphoneno") ? $CurrentForm->getValue("businessphoneno") : $CurrentForm->getValue("x_businessphoneno");
		if (!$this->businessphoneno->IsDetailKey) {
			if (IsApi() && $val === NULL)
				$this->businessphoneno->Visible = FALSE; // Disable update for API request
			else
				$this->businessphoneno->setFormValue($val);
		}

		// Check field name 'businessaddress1' first before field var 'x_businessaddress1'
		$val = $CurrentForm->hasValue("businessaddress1") ? $CurrentForm->getValue("businessaddress1") : $CurrentForm->getValue("x_businessaddress1");
		if (!$this->businessaddress1->IsDetailKey) {
			if (IsApi() && $val === NULL)
				$this->businessaddress1->Visible = FALSE; // Disable update for API request
			else
				$this->businessaddress1->setFormValue($val);
		}

		// Check field name 'businessaddress2' first before field var 'x_businessaddress2'
		$val = $CurrentForm->hasValue("businessaddress2") ? $CurrentForm->getValue("businessaddress2") : $CurrentForm->getValue("x_businessaddress2");
		if (!$this->businessaddress2->IsDetailKey) {
			if (IsApi() && $val === NULL)
				$this->businessaddress2->Visible = FALSE; // Disable update for API request
			else
				$this->businessaddress2->setFormValue($val);
		}

		// Check field name 'businesscity' first before field var 'x_businesscity'
		$val = $CurrentForm->hasValue("businesscity") ? $CurrentForm->getValue("businesscity") : $CurrentForm->getValue("x_businesscity");
		if (!$this->businesscity->IsDetailKey) {
			if (IsApi() && $val === NULL)
				$this->businesscity->Visible = FALSE; // Disable update for API request
			else
				$this->businesscity->setFormValue($val);
		}

		// Check field name 'businesscountry' first before field var 'x_businesscountry'
		$val = $CurrentForm->hasValue("businesscountry") ? $CurrentForm->getValue("businesscountry") : $CurrentForm->getValue("x_businesscountry");
		if (!$this->businesscountry->IsDetailKey) {
			if (IsApi() && $val === NULL)
				$this->businesscountry->Visible = FALSE; // Disable update for API request
			else
				$this->businesscountry->setFormValue($val);
		}

		// Check field name 'businessstate' first before field var 'x_businessstate'
		$val = $CurrentForm->hasValue("businessstate") ? $CurrentForm->getValue("businessstate") : $CurrentForm->getValue("x_businessstate");
		if (!$this->businessstate->IsDetailKey) {
			if (IsApi() && $val === NULL)
				$this->businessstate->Visible = FALSE; // Disable update for API request
			else
				$this->businessstate->setFormValue($val);
		}

		// Check field name 'businesszipcode' first before field var 'x_businesszipcode'
		$val = $CurrentForm->hasValue("businesszipcode") ? $CurrentForm->getValue("businesszipcode") : $CurrentForm->getValue("x_businesszipcode");
		if (!$this->businesszipcode->IsDetailKey) {
			if (IsApi() && $val === NULL)
				$this->businesszipcode->Visible = FALSE; // Disable update for API request
			else
				$this->businesszipcode->setFormValue($val);
		}

		// Check field name 'bankname' first before field var 'x_bankname'
		$val = $CurrentForm->hasValue("bankname") ? $CurrentForm->getValue("bankname") : $CurrentForm->getValue("x_bankname");
		if (!$this->bankname->IsDetailKey) {
			if (IsApi() && $val === NULL)
				$this->bankname->Visible = FALSE; // Disable update for API request
			else
				$this->bankname->setFormValue($val);
		}

		// Check field name 'bankbranchnumber' first before field var 'x_bankbranchnumber'
		$val = $CurrentForm->hasValue("bankbranchnumber") ? $CurrentForm->getValue("bankbranchnumber") : $CurrentForm->getValue("x_bankbranchnumber");
		if (!$this->bankbranchnumber->IsDetailKey) {
			if (IsApi() && $val === NULL)
				$this->bankbranchnumber->Visible = FALSE; // Disable update for API request
			else
				$this->bankbranchnumber->setFormValue($val);
		}

		// Check field name 'bankaccountnumber' first before field var 'x_bankaccountnumber'
		$val = $CurrentForm->hasValue("bankaccountnumber") ? $CurrentForm->getValue("bankaccountnumber") : $CurrentForm->getValue("x_bankaccountnumber");
		if (!$this->bankaccountnumber->IsDetailKey) {
			if (IsApi() && $val === NULL)
				$this->bankaccountnumber->Visible = FALSE; // Disable update for API request
			else
				$this->bankaccountnumber->setFormValue($val);
		}

		// Check field name 'other1' first before field var 'x_other1'
		$val = $CurrentForm->hasValue("other1") ? $CurrentForm->getValue("other1") : $CurrentForm->getValue("x_other1");
		if (!$this->other1->IsDetailKey) {
			if (IsApi() && $val === NULL)
				$this->other1->Visible = FALSE; // Disable update for API request
			else
				$this->other1->setFormValue($val);
		}

		// Check field name 'other2' first before field var 'x_other2'
		$val = $CurrentForm->hasValue("other2") ? $CurrentForm->getValue("other2") : $CurrentForm->getValue("x_other2");
		if (!$this->other2->IsDetailKey) {
			if (IsApi() && $val === NULL)
				$this->other2->Visible = FALSE; // Disable update for API request
			else
				$this->other2->setFormValue($val);
		}

		// Check field name 'other3' first before field var 'x_other3'
		$val = $CurrentForm->hasValue("other3") ? $CurrentForm->getValue("other3") : $CurrentForm->getValue("x_other3");
		if (!$this->other3->IsDetailKey) {
			if (IsApi() && $val === NULL)
				$this->other3->Visible = FALSE; // Disable update for API request
			else
				$this->other3->setFormValue($val);
		}

		// Check field name 'externalid' first before field var 'x_externalid'
		$val = $CurrentForm->hasValue("externalid") ? $CurrentForm->getValue("externalid") : $CurrentForm->getValue("x_externalid");
		if (!$this->externalid->IsDetailKey) {
			if (IsApi() && $val === NULL)
				$this->externalid->Visible = FALSE; // Disable update for API request
			else
				$this->externalid->setFormValue($val);
		}

		// Check field name 'couponpin' first before field var 'x_couponpin'
		$val = $CurrentForm->hasValue("couponpin") ? $CurrentForm->getValue("couponpin") : $CurrentForm->getValue("x_couponpin");
		if (!$this->couponpin->IsDetailKey) {
			if (IsApi() && $val === NULL)
				$this->couponpin->Visible = FALSE; // Disable update for API request
			else
				$this->couponpin->setFormValue($val);
		}

		// Check field name 'swiftcode' first before field var 'x_swiftcode'
		$val = $CurrentForm->hasValue("swiftcode") ? $CurrentForm->getValue("swiftcode") : $CurrentForm->getValue("x_swiftcode");
		if (!$this->swiftcode->IsDetailKey) {
			if (IsApi() && $val === NULL)
				$this->swiftcode->Visible = FALSE; // Disable update for API request
			else
				$this->swiftcode->setFormValue($val);
		}

		// Check field name 'profilevalidated' first before field var 'x_profilevalidated'
		$val = $CurrentForm->hasValue("profilevalidated") ? $CurrentForm->getValue("profilevalidated") : $CurrentForm->getValue("x_profilevalidated");
		if (!$this->profilevalidated->IsDetailKey) {
			if (IsApi() && $val === NULL)
				$this->profilevalidated->Visible = FALSE; // Disable update for API request
			else
				$this->profilevalidated->setFormValue($val);
		}

		// Check field name 'profilevalidationdate' first before field var 'x_profilevalidationdate'
		$val = $CurrentForm->hasValue("profilevalidationdate") ? $CurrentForm->getValue("profilevalidationdate") : $CurrentForm->getValue("x_profilevalidationdate");
		if (!$this->profilevalidationdate->IsDetailKey) {
			if (IsApi() && $val === NULL)
				$this->profilevalidationdate->Visible = FALSE; // Disable update for API request
			else
				$this->profilevalidationdate->setFormValue($val);
			$this->profilevalidationdate->CurrentValue = UnFormatDateTime($this->profilevalidationdate->CurrentValue, 0);
		}

		// Check field name 'industry' first before field var 'x_industry'
		$val = $CurrentForm->hasValue("industry") ? $CurrentForm->getValue("industry") : $CurrentForm->getValue("x_industry");
		if (!$this->industry->IsDetailKey) {
			if (IsApi() && $val === NULL)
				$this->industry->Visible = FALSE; // Disable update for API request
			else
				$this->industry->setFormValue($val);
		}

		// Check field name 'legalstructure' first before field var 'x_legalstructure'
		$val = $CurrentForm->hasValue("legalstructure") ? $CurrentForm->getValue("legalstructure") : $CurrentForm->getValue("x_legalstructure");
		if (!$this->legalstructure->IsDetailKey) {
			if (IsApi() && $val === NULL)
				$this->legalstructure->Visible = FALSE; // Disable update for API request
			else
				$this->legalstructure->setFormValue($val);
		}

		// Check field name 'extendedfields' first before field var 'x_extendedfields'
		$val = $CurrentForm->hasValue("extendedfields") ? $CurrentForm->getValue("extendedfields") : $CurrentForm->getValue("x_extendedfields");
		if (!$this->extendedfields->IsDetailKey) {
			if (IsApi() && $val === NULL)
				$this->extendedfields->Visible = FALSE; // Disable update for API request
			else
				$this->extendedfields->setFormValue($val);
		}
	}

	// Restore form values
	public function restoreFormValues()
	{
		global $CurrentForm;
		$this->_userid->CurrentValue = $this->_userid->FormValue;
		$this->businessname->CurrentValue = $this->businessname->FormValue;
		$this->officialname->CurrentValue = $this->officialname->FormValue;
		$this->changed->CurrentValue = $this->changed->FormValue;
		$this->active->CurrentValue = $this->active->FormValue;
		$this->tipallowed->CurrentValue = $this->tipallowed->FormValue;
		$this->merchanttoaddtip->CurrentValue = $this->merchanttoaddtip->FormValue;
		$this->pis->CurrentValue = $this->pis->FormValue;
		$this->ratetableid->CurrentValue = $this->ratetableid->FormValue;
		$this->ratetabletype->CurrentValue = $this->ratetabletype->FormValue;
		$this->officialdocnumber->CurrentValue = $this->officialdocnumber->FormValue;
		$this->officialdocname->CurrentValue = $this->officialdocname->FormValue;
		$this->softposid->CurrentValue = $this->softposid->FormValue;
		$this->taxamount->CurrentValue = $this->taxamount->FormValue;
		$this->variabletax->CurrentValue = $this->variabletax->FormValue;
		$this->logofilename->CurrentValue = $this->logofilename->FormValue;
		$this->returndays->CurrentValue = $this->returndays->FormValue;
		$this->memberextrafieldsid->CurrentValue = $this->memberextrafieldsid->FormValue;
		$this->lastupdatedate->CurrentValue = $this->lastupdatedate->FormValue;
		$this->lastupdatedate->CurrentValue = UnFormatDateTime($this->lastupdatedate->CurrentValue, 0);
		$this->remmitancetype->CurrentValue = $this->remmitancetype->FormValue;
		$this->withholdingtaxaccount->CurrentValue = $this->withholdingtaxaccount->FormValue;
		$this->businessphoneno->CurrentValue = $this->businessphoneno->FormValue;
		$this->businessaddress1->CurrentValue = $this->businessaddress1->FormValue;
		$this->businessaddress2->CurrentValue = $this->businessaddress2->FormValue;
		$this->businesscity->CurrentValue = $this->businesscity->FormValue;
		$this->businesscountry->CurrentValue = $this->businesscountry->FormValue;
		$this->businessstate->CurrentValue = $this->businessstate->FormValue;
		$this->businesszipcode->CurrentValue = $this->businesszipcode->FormValue;
		$this->bankname->CurrentValue = $this->bankname->FormValue;
		$this->bankbranchnumber->CurrentValue = $this->bankbranchnumber->FormValue;
		$this->bankaccountnumber->CurrentValue = $this->bankaccountnumber->FormValue;
		$this->other1->CurrentValue = $this->other1->FormValue;
		$this->other2->CurrentValue = $this->other2->FormValue;
		$this->other3->CurrentValue = $this->other3->FormValue;
		$this->externalid->CurrentValue = $this->externalid->FormValue;
		$this->couponpin->CurrentValue = $this->couponpin->FormValue;
		$this->swiftcode->CurrentValue = $this->swiftcode->FormValue;
		$this->profilevalidated->CurrentValue = $this->profilevalidated->FormValue;
		$this->profilevalidationdate->CurrentValue = $this->profilevalidationdate->FormValue;
		$this->profilevalidationdate->CurrentValue = UnFormatDateTime($this->profilevalidationdate->CurrentValue, 0);
		$this->industry->CurrentValue = $this->industry->FormValue;
		$this->legalstructure->CurrentValue = $this->legalstructure->FormValue;
		$this->extendedfields->CurrentValue = $this->extendedfields->FormValue;
	}

	// Load row based on key values
	public function loadRow()
	{
		global $Security, $Language;
		$filter = $this->getRecordFilter();

		// Call Row Selecting event
		$this->Row_Selecting($filter);

		// Load SQL based on filter
		$this->CurrentFilter = $filter;
		$sql = $this->getCurrentSql();
		$conn = $this->getConnection();
		$res = FALSE;
		$rs = LoadRecordset($sql, $conn);
		if ($rs && !$rs->EOF) {
			$res = TRUE;
			$this->loadRowValues($rs); // Load row values
			$rs->close();
		}
		return $res;
	}

	// Load row values from recordset
	public function loadRowValues($rs = NULL)
	{
		if ($rs && !$rs->EOF)
			$row = $rs->fields;
		else
			$row = $this->newRow();

		// Call Row Selected event
		$this->Row_Selected($row);
		if (!$rs || $rs->EOF)
			return;
		$this->_userid->setDbValue($row['userid']);
		$this->businessname->setDbValue($row['businessname']);
		$this->officialname->setDbValue($row['officialname']);
		$this->changed->setDbValue($row['changed']);
		$this->active->setDbValue($row['active']);
		$this->tipallowed->setDbValue($row['tipallowed']);
		$this->merchanttoaddtip->setDbValue($row['merchanttoaddtip']);
		$this->pis->setDbValue($row['pis']);
		$this->ratetableid->setDbValue($row['ratetableid']);
		$this->ratetabletype->setDbValue($row['ratetabletype']);
		$this->officialdocnumber->setDbValue($row['officialdocnumber']);
		$this->officialdocname->setDbValue($row['officialdocname']);
		$this->softposid->setDbValue($row['softposid']);
		$this->taxamount->setDbValue($row['taxamount']);
		$this->variabletax->setDbValue($row['variabletax']);
		$this->logofilename->setDbValue($row['logofilename']);
		$this->returndays->setDbValue($row['returndays']);
		$this->memberextrafieldsid->setDbValue($row['memberextrafieldsid']);
		$this->lastupdatedate->setDbValue($row['lastupdatedate']);
		$this->remmitancetype->setDbValue($row['remmitancetype']);
		$this->withholdingtaxaccount->setDbValue($row['withholdingtaxaccount']);
		$this->businessphoneno->setDbValue($row['businessphoneno']);
		$this->businessaddress1->setDbValue($row['businessaddress1']);
		$this->businessaddress2->setDbValue($row['businessaddress2']);
		$this->businesscity->setDbValue($row['businesscity']);
		$this->businesscountry->setDbValue($row['businesscountry']);
		$this->businessstate->setDbValue($row['businessstate']);
		$this->businesszipcode->setDbValue($row['businesszipcode']);
		$this->bankname->setDbValue($row['bankname']);
		$this->bankbranchnumber->setDbValue($row['bankbranchnumber']);
		$this->bankaccountnumber->setDbValue($row['bankaccountnumber']);
		$this->other1->setDbValue($row['other1']);
		$this->other2->setDbValue($row['other2']);
		$this->other3->setDbValue($row['other3']);
		$this->externalid->setDbValue($row['externalid']);
		$this->couponpin->setDbValue($row['couponpin']);
		$this->swiftcode->setDbValue($row['swiftcode']);
		$this->profilevalidated->setDbValue($row['profilevalidated']);
		$this->profilevalidationdate->setDbValue($row['profilevalidationdate']);
		$this->industry->setDbValue($row['industry']);
		$this->legalstructure->setDbValue($row['legalstructure']);
		$this->extendedfields->setDbValue($row['extendedfields']);
	}

	// Return a row with default values
	protected function newRow()
	{
		$this->loadDefaultValues();
		$row = [];
		$row['userid'] = $this->_userid->CurrentValue;
		$row['businessname'] = $this->businessname->CurrentValue;
		$row['officialname'] = $this->officialname->CurrentValue;
		$row['changed'] = $this->changed->CurrentValue;
		$row['active'] = $this->active->CurrentValue;
		$row['tipallowed'] = $this->tipallowed->CurrentValue;
		$row['merchanttoaddtip'] = $this->merchanttoaddtip->CurrentValue;
		$row['pis'] = $this->pis->CurrentValue;
		$row['ratetableid'] = $this->ratetableid->CurrentValue;
		$row['ratetabletype'] = $this->ratetabletype->CurrentValue;
		$row['officialdocnumber'] = $this->officialdocnumber->CurrentValue;
		$row['officialdocname'] = $this->officialdocname->CurrentValue;
		$row['softposid'] = $this->softposid->CurrentValue;
		$row['taxamount'] = $this->taxamount->CurrentValue;
		$row['variabletax'] = $this->variabletax->CurrentValue;
		$row['logofilename'] = $this->logofilename->CurrentValue;
		$row['returndays'] = $this->returndays->CurrentValue;
		$row['memberextrafieldsid'] = $this->memberextrafieldsid->CurrentValue;
		$row['lastupdatedate'] = $this->lastupdatedate->CurrentValue;
		$row['remmitancetype'] = $this->remmitancetype->CurrentValue;
		$row['withholdingtaxaccount'] = $this->withholdingtaxaccount->CurrentValue;
		$row['businessphoneno'] = $this->businessphoneno->CurrentValue;
		$row['businessaddress1'] = $this->businessaddress1->CurrentValue;
		$row['businessaddress2'] = $this->businessaddress2->CurrentValue;
		$row['businesscity'] = $this->businesscity->CurrentValue;
		$row['businesscountry'] = $this->businesscountry->CurrentValue;
		$row['businessstate'] = $this->businessstate->CurrentValue;
		$row['businesszipcode'] = $this->businesszipcode->CurrentValue;
		$row['bankname'] = $this->bankname->CurrentValue;
		$row['bankbranchnumber'] = $this->bankbranchnumber->CurrentValue;
		$row['bankaccountnumber'] = $this->bankaccountnumber->CurrentValue;
		$row['other1'] = $this->other1->CurrentValue;
		$row['other2'] = $this->other2->CurrentValue;
		$row['other3'] = $this->other3->CurrentValue;
		$row['externalid'] = $this->externalid->CurrentValue;
		$row['couponpin'] = $this->couponpin->CurrentValue;
		$row['swiftcode'] = $this->swiftcode->CurrentValue;
		$row['profilevalidated'] = $this->profilevalidated->CurrentValue;
		$row['profilevalidationdate'] = $this->profilevalidationdate->CurrentValue;
		$row['industry'] = $this->industry->CurrentValue;
		$row['legalstructure'] = $this->legalstructure->CurrentValue;
		$row['extendedfields'] = $this->extendedfields->CurrentValue;
		return $row;
	}

	// Load old record
	protected function loadOldRecord()
	{

		// Load key values from Session
		$validKey = TRUE;
		if (strval($this->getKey("_userid")) != "")
			$this->_userid->OldValue = $this->getKey("_userid"); // userid
		else
			$validKey = FALSE;

		// Load old record
		$this->OldRecordset = NULL;
		if ($validKey) {
			$this->CurrentFilter = $this->getRecordFilter();
			$sql = $this->getCurrentSql();
			$conn = $this->getConnection();
			$this->OldRecordset = LoadRecordset($sql, $conn);
		}
		$this->loadRowValues($this->OldRecordset); // Load row values
		return $validKey;
	}

	// Render row values based on field settings
	public function renderRow()
	{
		global $Security, $Language, $CurrentLanguage;

		// Initialize URLs
		// Convert decimal values if posted back

		if ($this->taxamount->FormValue == $this->taxamount->CurrentValue && is_numeric(ConvertToFloatString($this->taxamount->CurrentValue)))
			$this->taxamount->CurrentValue = ConvertToFloatString($this->taxamount->CurrentValue);

		// Call Row_Rendering event
		$this->Row_Rendering();

		// Common render codes for all row types
		// userid
		// businessname
		// officialname
		// changed
		// active
		// tipallowed
		// merchanttoaddtip
		// pis
		// ratetableid
		// ratetabletype
		// officialdocnumber
		// officialdocname
		// softposid
		// taxamount
		// variabletax
		// logofilename
		// returndays
		// memberextrafieldsid
		// lastupdatedate
		// remmitancetype
		// withholdingtaxaccount
		// businessphoneno
		// businessaddress1
		// businessaddress2
		// businesscity
		// businesscountry
		// businessstate
		// businesszipcode
		// bankname
		// bankbranchnumber
		// bankaccountnumber
		// other1
		// other2
		// other3
		// externalid
		// couponpin
		// swiftcode
		// profilevalidated
		// profilevalidationdate
		// industry
		// legalstructure
		// extendedfields

		if ($this->RowType == ROWTYPE_VIEW) { // View row

			// userid
			$this->_userid->ViewValue = $this->_userid->CurrentValue;
			$this->_userid->ViewCustomAttributes = "";

			// businessname
			$this->businessname->ViewValue = $this->businessname->CurrentValue;
			$this->businessname->ViewCustomAttributes = "";

			// officialname
			$this->officialname->ViewValue = $this->officialname->CurrentValue;
			$this->officialname->ViewCustomAttributes = "";

			// changed
			$curVal = strval($this->changed->CurrentValue);
			if ($curVal != "") {
				$this->changed->ViewValue = $this->changed->lookupCacheOption($curVal);
				if ($this->changed->ViewValue === NULL) { // Lookup from database
					$filterWrk = "`id`" . SearchString("=", $curVal, DATATYPE_NUMBER, "");
					$sqlWrk = $this->changed->Lookup->getSql(FALSE, $filterWrk, '', $this);
					$rswrk = Conn()->execute($sqlWrk);
					if ($rswrk && !$rswrk->EOF) { // Lookup values found
						$arwrk = [];
						$arwrk[1] = $rswrk->fields('df');
						$this->changed->ViewValue = $this->changed->displayValue($arwrk);
						$rswrk->Close();
					} else {
						$this->changed->ViewValue = $this->changed->CurrentValue;
					}
				}
			} else {
				$this->changed->ViewValue = NULL;
			}
			$this->changed->ViewCustomAttributes = "";

			// active
			$curVal = strval($this->active->CurrentValue);
			if ($curVal != "") {
				$this->active->ViewValue = $this->active->lookupCacheOption($curVal);
				if ($this->active->ViewValue === NULL) { // Lookup from database
					$filterWrk = "`id`" . SearchString("=", $curVal, DATATYPE_NUMBER, "");
					$sqlWrk = $this->active->Lookup->getSql(FALSE, $filterWrk, '', $this);
					$rswrk = Conn()->execute($sqlWrk);
					if ($rswrk && !$rswrk->EOF) { // Lookup values found
						$arwrk = [];
						$arwrk[1] = $rswrk->fields('df');
						$this->active->ViewValue = $this->active->displayValue($arwrk);
						$rswrk->Close();
					} else {
						$this->active->ViewValue = $this->active->CurrentValue;
					}
				}
			} else {
				$this->active->ViewValue = NULL;
			}
			$this->active->ViewCustomAttributes = "";

			// tipallowed
			$curVal = strval($this->tipallowed->CurrentValue);
			if ($curVal != "") {
				$this->tipallowed->ViewValue = $this->tipallowed->lookupCacheOption($curVal);
				if ($this->tipallowed->ViewValue === NULL) { // Lookup from database
					$filterWrk = "`id`" . SearchString("=", $curVal, DATATYPE_NUMBER, "");
					$sqlWrk = $this->tipallowed->Lookup->getSql(FALSE, $filterWrk, '', $this);
					$rswrk = Conn()->execute($sqlWrk);
					if ($rswrk && !$rswrk->EOF) { // Lookup values found
						$arwrk = [];
						$arwrk[1] = $rswrk->fields('df');
						$this->tipallowed->ViewValue = $this->tipallowed->displayValue($arwrk);
						$rswrk->Close();
					} else {
						$this->tipallowed->ViewValue = $this->tipallowed->CurrentValue;
					}
				}
			} else {
				$this->tipallowed->ViewValue = NULL;
			}
			$this->tipallowed->ViewCustomAttributes = "";

			// merchanttoaddtip
			$curVal = strval($this->merchanttoaddtip->CurrentValue);
			if ($curVal != "") {
				$this->merchanttoaddtip->ViewValue = $this->merchanttoaddtip->lookupCacheOption($curVal);
				if ($this->merchanttoaddtip->ViewValue === NULL) { // Lookup from database
					$filterWrk = "`id`" . SearchString("=", $curVal, DATATYPE_NUMBER, "");
					$sqlWrk = $this->merchanttoaddtip->Lookup->getSql(FALSE, $filterWrk, '', $this);
					$rswrk = Conn()->execute($sqlWrk);
					if ($rswrk && !$rswrk->EOF) { // Lookup values found
						$arwrk = [];
						$arwrk[1] = $rswrk->fields('df');
						$this->merchanttoaddtip->ViewValue = $this->merchanttoaddtip->displayValue($arwrk);
						$rswrk->Close();
					} else {
						$this->merchanttoaddtip->ViewValue = $this->merchanttoaddtip->CurrentValue;
					}
				}
			} else {
				$this->merchanttoaddtip->ViewValue = NULL;
			}
			$this->merchanttoaddtip->ViewCustomAttributes = "";

			// pis
			$this->pis->ViewValue = $this->pis->CurrentValue;
			$this->pis->ViewCustomAttributes = "";

			// ratetableid
			$this->ratetableid->ViewValue = $this->ratetableid->CurrentValue;
			$this->ratetableid->ViewCustomAttributes = "";

			// ratetabletype
			$curVal = strval($this->ratetabletype->CurrentValue);
			if ($curVal != "") {
				$this->ratetabletype->ViewValue = $this->ratetabletype->lookupCacheOption($curVal);
				if ($this->ratetabletype->ViewValue === NULL) { // Lookup from database
					$filterWrk = "`typeid`" . SearchString("=", $curVal, DATATYPE_NUMBER, "");
					$sqlWrk = $this->ratetabletype->Lookup->getSql(FALSE, $filterWrk, '', $this);
					$rswrk = Conn()->execute($sqlWrk);
					if ($rswrk && !$rswrk->EOF) { // Lookup values found
						$arwrk = [];
						$arwrk[1] = $rswrk->fields('df');
						$this->ratetabletype->ViewValue = $this->ratetabletype->displayValue($arwrk);
						$rswrk->Close();
					} else {
						$this->ratetabletype->ViewValue = $this->ratetabletype->CurrentValue;
					}
				}
			} else {
				$this->ratetabletype->ViewValue = NULL;
			}
			$this->ratetabletype->ViewCustomAttributes = "";

			// officialdocnumber
			$this->officialdocnumber->ViewValue = $this->officialdocnumber->CurrentValue;
			$this->officialdocnumber->ViewCustomAttributes = "";

			// officialdocname
			$this->officialdocname->ViewValue = $this->officialdocname->CurrentValue;
			$this->officialdocname->ViewCustomAttributes = "";

			// softposid
			$this->softposid->ViewValue = $this->softposid->CurrentValue;
			$this->softposid->ViewCustomAttributes = "";

			// taxamount
			$this->taxamount->ViewValue = $this->taxamount->CurrentValue;
			$this->taxamount->ViewValue = FormatNumber($this->taxamount->ViewValue, 2, -2, -2, -2);
			$this->taxamount->ViewCustomAttributes = "";

			// variabletax
			$curVal = strval($this->variabletax->CurrentValue);
			if ($curVal != "") {
				$this->variabletax->ViewValue = $this->variabletax->lookupCacheOption($curVal);
				if ($this->variabletax->ViewValue === NULL) { // Lookup from database
					$filterWrk = "`id`" . SearchString("=", $curVal, DATATYPE_NUMBER, "");
					$sqlWrk = $this->variabletax->Lookup->getSql(FALSE, $filterWrk, '', $this);
					$rswrk = Conn()->execute($sqlWrk);
					if ($rswrk && !$rswrk->EOF) { // Lookup values found
						$arwrk = [];
						$arwrk[1] = $rswrk->fields('df');
						$this->variabletax->ViewValue = $this->variabletax->displayValue($arwrk);
						$rswrk->Close();
					} else {
						$this->variabletax->ViewValue = $this->variabletax->CurrentValue;
					}
				}
			} else {
				$this->variabletax->ViewValue = NULL;
			}
			$this->variabletax->ViewCustomAttributes = "";

			// logofilename
			$this->logofilename->ViewValue = $this->logofilename->CurrentValue;
			$this->logofilename->ViewCustomAttributes = "";

			// returndays
			$this->returndays->ViewValue = $this->returndays->CurrentValue;
			$this->returndays->ViewValue = FormatNumber($this->returndays->ViewValue, 0, -2, -2, -2);
			$this->returndays->ViewCustomAttributes = "";

			// memberextrafieldsid
			$this->memberextrafieldsid->ViewValue = $this->memberextrafieldsid->CurrentValue;
			$this->memberextrafieldsid->ViewCustomAttributes = "";

			// lastupdatedate
			$this->lastupdatedate->ViewValue = $this->lastupdatedate->CurrentValue;
			$this->lastupdatedate->ViewValue = FormatDateTime($this->lastupdatedate->ViewValue, 0);
			$this->lastupdatedate->ViewCustomAttributes = "";

			// remmitancetype
			if (strval($this->remmitancetype->CurrentValue) != "") {
				$this->remmitancetype->ViewValue = $this->remmitancetype->optionCaption($this->remmitancetype->CurrentValue);
			} else {
				$this->remmitancetype->ViewValue = NULL;
			}
			$this->remmitancetype->ViewCustomAttributes = "";

			// withholdingtaxaccount
			$this->withholdingtaxaccount->ViewValue = $this->withholdingtaxaccount->CurrentValue;
			$this->withholdingtaxaccount->ViewCustomAttributes = "";

			// businessphoneno
			$this->businessphoneno->ViewValue = $this->businessphoneno->CurrentValue;
			$this->businessphoneno->ViewCustomAttributes = "";

			// businessaddress1
			$this->businessaddress1->ViewValue = $this->businessaddress1->CurrentValue;
			$this->businessaddress1->ViewCustomAttributes = "";

			// businessaddress2
			$this->businessaddress2->ViewValue = $this->businessaddress2->CurrentValue;
			$this->businessaddress2->ViewCustomAttributes = "";

			// businesscity
			$this->businesscity->ViewValue = $this->businesscity->CurrentValue;
			$this->businesscity->ViewCustomAttributes = "";

			// businesscountry
			$curVal = strval($this->businesscountry->CurrentValue);
			if ($curVal != "") {
				$this->businesscountry->ViewValue = $this->businesscountry->lookupCacheOption($curVal);
				if ($this->businesscountry->ViewValue === NULL) { // Lookup from database
					$filterWrk = "`countryID`" . SearchString("=", $curVal, DATATYPE_STRING, "_4payreference");
					$sqlWrk = $this->businesscountry->Lookup->getSql(FALSE, $filterWrk, '', $this);
					$rswrk = Conn("_4payreference")->execute($sqlWrk);
					if ($rswrk && !$rswrk->EOF) { // Lookup values found
						$arwrk = [];
						$arwrk[1] = $rswrk->fields('df');
						$this->businesscountry->ViewValue = $this->businesscountry->displayValue($arwrk);
						$rswrk->Close();
					} else {
						$this->businesscountry->ViewValue = $this->businesscountry->CurrentValue;
					}
				}
			} else {
				$this->businesscountry->ViewValue = NULL;
			}
			$this->businesscountry->ViewCustomAttributes = "";

			// businessstate
			$curVal = strval($this->businessstate->CurrentValue);
			if ($curVal != "") {
				$this->businessstate->ViewValue = $this->businessstate->lookupCacheOption($curVal);
				if ($this->businessstate->ViewValue === NULL) { // Lookup from database
					$filterWrk = "`stateid`" . SearchString("=", $curVal, DATATYPE_STRING, "_4payreference");
					$sqlWrk = $this->businessstate->Lookup->getSql(FALSE, $filterWrk, '', $this);
					$rswrk = Conn("_4payreference")->execute($sqlWrk);
					if ($rswrk && !$rswrk->EOF) { // Lookup values found
						$arwrk = [];
						$arwrk[1] = $rswrk->fields('df');
						$this->businessstate->ViewValue = $this->businessstate->displayValue($arwrk);
						$rswrk->Close();
					} else {
						$this->businessstate->ViewValue = $this->businessstate->CurrentValue;
					}
				}
			} else {
				$this->businessstate->ViewValue = NULL;
			}
			$this->businessstate->ViewCustomAttributes = "";

			// businesszipcode
			$this->businesszipcode->ViewValue = $this->businesszipcode->CurrentValue;
			$this->businesszipcode->ViewCustomAttributes = "";

			// bankname
			$this->bankname->ViewValue = $this->bankname->CurrentValue;
			$this->bankname->ViewCustomAttributes = "";

			// bankbranchnumber
			$this->bankbranchnumber->ViewValue = $this->bankbranchnumber->CurrentValue;
			$this->bankbranchnumber->ViewCustomAttributes = "";

			// bankaccountnumber
			$this->bankaccountnumber->ViewValue = $this->bankaccountnumber->CurrentValue;
			$this->bankaccountnumber->ViewCustomAttributes = "";

			// other1
			$this->other1->ViewValue = $this->other1->CurrentValue;
			$this->other1->ViewCustomAttributes = "";

			// other2
			$this->other2->ViewValue = $this->other2->CurrentValue;
			$this->other2->ViewCustomAttributes = "";

			// other3
			$this->other3->ViewValue = $this->other3->CurrentValue;
			$this->other3->ViewCustomAttributes = "";

			// externalid
			$this->externalid->ViewValue = $this->externalid->CurrentValue;
			$this->externalid->ViewCustomAttributes = "";

			// couponpin
			$this->couponpin->ViewValue = $this->couponpin->CurrentValue;
			$this->couponpin->ViewCustomAttributes = "";

			// swiftcode
			$this->swiftcode->ViewValue = $this->swiftcode->CurrentValue;
			$this->swiftcode->ViewCustomAttributes = "";

			// profilevalidated
			$curVal = strval($this->profilevalidated->CurrentValue);
			if ($curVal != "") {
				$this->profilevalidated->ViewValue = $this->profilevalidated->lookupCacheOption($curVal);
				if ($this->profilevalidated->ViewValue === NULL) { // Lookup from database
					$filterWrk = "`statusID`" . SearchString("=", $curVal, DATATYPE_NUMBER, "");
					$lookupFilter = function() {
						return "`langID` = 'EN'";
					};
					$lookupFilter = $lookupFilter->bindTo($this);
					$sqlWrk = $this->profilevalidated->Lookup->getSql(FALSE, $filterWrk, $lookupFilter, $this);
					$rswrk = Conn()->execute($sqlWrk);
					if ($rswrk && !$rswrk->EOF) { // Lookup values found
						$arwrk = [];
						$arwrk[1] = $rswrk->fields('df');
						$this->profilevalidated->ViewValue = $this->profilevalidated->displayValue($arwrk);
						$rswrk->Close();
					} else {
						$this->profilevalidated->ViewValue = $this->profilevalidated->CurrentValue;
					}
				}
			} else {
				$this->profilevalidated->ViewValue = NULL;
			}
			$this->profilevalidated->ViewCustomAttributes = "";

			// profilevalidationdate
			$this->profilevalidationdate->ViewValue = $this->profilevalidationdate->CurrentValue;
			$this->profilevalidationdate->ViewValue = FormatDateTime($this->profilevalidationdate->ViewValue, 0);
			$this->profilevalidationdate->ViewCustomAttributes = "";

			// industry
			$curVal = strval($this->industry->CurrentValue);
			if ($curVal != "") {
				$this->industry->ViewValue = $this->industry->lookupCacheOption($curVal);
				if ($this->industry->ViewValue === NULL) { // Lookup from database
					$filterWrk = "`typeID`" . SearchString("=", $curVal, DATATYPE_STRING, "_4payreference");
					$sqlWrk = $this->industry->Lookup->getSql(FALSE, $filterWrk, '', $this);
					$rswrk = Conn("_4payreference")->execute($sqlWrk);
					if ($rswrk && !$rswrk->EOF) { // Lookup values found
						$arwrk = [];
						$arwrk[1] = $rswrk->fields('df');
						$this->industry->ViewValue = $this->industry->displayValue($arwrk);
						$rswrk->Close();
					} else {
						$this->industry->ViewValue = $this->industry->CurrentValue;
					}
				}
			} else {
				$this->industry->ViewValue = NULL;
			}
			$this->industry->ViewCustomAttributes = "";

			// legalstructure
			$curVal = strval($this->legalstructure->CurrentValue);
			if ($curVal != "") {
				$this->legalstructure->ViewValue = $this->legalstructure->lookupCacheOption($curVal);
				if ($this->legalstructure->ViewValue === NULL) { // Lookup from database
					$filterWrk = "`typeID`" . SearchString("=", $curVal, DATATYPE_STRING, "_4payreference");
					$sqlWrk = $this->legalstructure->Lookup->getSql(FALSE, $filterWrk, '', $this);
					$rswrk = Conn("_4payreference")->execute($sqlWrk);
					if ($rswrk && !$rswrk->EOF) { // Lookup values found
						$arwrk = [];
						$arwrk[1] = $rswrk->fields('df');
						$this->legalstructure->ViewValue = $this->legalstructure->displayValue($arwrk);
						$rswrk->Close();
					} else {
						$this->legalstructure->ViewValue = $this->legalstructure->CurrentValue;
					}
				}
			} else {
				$this->legalstructure->ViewValue = NULL;
			}
			$this->legalstructure->ViewCustomAttributes = "";

			// extendedfields
			$this->extendedfields->ViewValue = $this->extendedfields->CurrentValue;
			$this->extendedfields->ViewCustomAttributes = "";

			// userid
			$this->_userid->LinkCustomAttributes = "";
			if (!EmptyValue($this->_userid->CurrentValue)) {
				$this->_userid->HrefValue = "userview.php?showdetail=&id=" . $this->_userid->CurrentValue; // Add prefix/suffix
				$this->_userid->LinkAttrs["target"] = ""; // Add target
				if ($this->isExport())
					$this->_userid->HrefValue = FullUrl($this->_userid->HrefValue, "href");
			} else {
				$this->_userid->HrefValue = "";
			}
			$this->_userid->TooltipValue = "";

			// businessname
			$this->businessname->LinkCustomAttributes = "";
			$this->businessname->HrefValue = "";
			$this->businessname->TooltipValue = "";

			// officialname
			$this->officialname->LinkCustomAttributes = "";
			$this->officialname->HrefValue = "";
			$this->officialname->TooltipValue = "";

			// changed
			$this->changed->LinkCustomAttributes = "";
			$this->changed->HrefValue = "";
			$this->changed->TooltipValue = "";

			// active
			$this->active->LinkCustomAttributes = "";
			$this->active->HrefValue = "";
			$this->active->TooltipValue = "";

			// tipallowed
			$this->tipallowed->LinkCustomAttributes = "";
			$this->tipallowed->HrefValue = "";
			$this->tipallowed->TooltipValue = "";

			// merchanttoaddtip
			$this->merchanttoaddtip->LinkCustomAttributes = "";
			$this->merchanttoaddtip->HrefValue = "";
			$this->merchanttoaddtip->TooltipValue = "";

			// pis
			$this->pis->LinkCustomAttributes = "";
			$this->pis->HrefValue = "";
			$this->pis->TooltipValue = "";

			// ratetableid
			$this->ratetableid->LinkCustomAttributes = "";
			$this->ratetableid->HrefValue = "";
			$this->ratetableid->TooltipValue = "";

			// ratetabletype
			$this->ratetabletype->LinkCustomAttributes = "";
			$this->ratetabletype->HrefValue = "";
			$this->ratetabletype->TooltipValue = "";

			// officialdocnumber
			$this->officialdocnumber->LinkCustomAttributes = "";
			$this->officialdocnumber->HrefValue = "";
			$this->officialdocnumber->TooltipValue = "";

			// officialdocname
			$this->officialdocname->LinkCustomAttributes = "";
			$this->officialdocname->HrefValue = "";
			$this->officialdocname->TooltipValue = "";

			// softposid
			$this->softposid->LinkCustomAttributes = "";
			$this->softposid->HrefValue = "";
			$this->softposid->TooltipValue = "";

			// taxamount
			$this->taxamount->LinkCustomAttributes = "";
			$this->taxamount->HrefValue = "";
			$this->taxamount->TooltipValue = "";

			// variabletax
			$this->variabletax->LinkCustomAttributes = "";
			$this->variabletax->HrefValue = "";
			$this->variabletax->TooltipValue = "";

			// logofilename
			$this->logofilename->LinkCustomAttributes = "";
			$this->logofilename->HrefValue = "";
			$this->logofilename->TooltipValue = "";

			// returndays
			$this->returndays->LinkCustomAttributes = "";
			$this->returndays->HrefValue = "";
			$this->returndays->TooltipValue = "";

			// memberextrafieldsid
			$this->memberextrafieldsid->LinkCustomAttributes = "";
			$this->memberextrafieldsid->HrefValue = "";
			$this->memberextrafieldsid->TooltipValue = "";

			// lastupdatedate
			$this->lastupdatedate->LinkCustomAttributes = "";
			$this->lastupdatedate->HrefValue = "";
			$this->lastupdatedate->TooltipValue = "";

			// remmitancetype
			$this->remmitancetype->LinkCustomAttributes = "";
			$this->remmitancetype->HrefValue = "";
			$this->remmitancetype->TooltipValue = "";

			// withholdingtaxaccount
			$this->withholdingtaxaccount->LinkCustomAttributes = "";
			$this->withholdingtaxaccount->HrefValue = "";
			$this->withholdingtaxaccount->TooltipValue = "";

			// businessphoneno
			$this->businessphoneno->LinkCustomAttributes = "";
			$this->businessphoneno->HrefValue = "";
			$this->businessphoneno->TooltipValue = "";

			// businessaddress1
			$this->businessaddress1->LinkCustomAttributes = "";
			$this->businessaddress1->HrefValue = "";
			$this->businessaddress1->TooltipValue = "";

			// businessaddress2
			$this->businessaddress2->LinkCustomAttributes = "";
			$this->businessaddress2->HrefValue = "";
			$this->businessaddress2->TooltipValue = "";

			// businesscity
			$this->businesscity->LinkCustomAttributes = "";
			$this->businesscity->HrefValue = "";
			$this->businesscity->TooltipValue = "";

			// businesscountry
			$this->businesscountry->LinkCustomAttributes = "";
			$this->businesscountry->HrefValue = "";
			$this->businesscountry->TooltipValue = "";

			// businessstate
			$this->businessstate->LinkCustomAttributes = "";
			$this->businessstate->HrefValue = "";
			$this->businessstate->TooltipValue = "";

			// businesszipcode
			$this->businesszipcode->LinkCustomAttributes = "";
			$this->businesszipcode->HrefValue = "";
			$this->businesszipcode->TooltipValue = "";

			// bankname
			$this->bankname->LinkCustomAttributes = "";
			$this->bankname->HrefValue = "";
			$this->bankname->TooltipValue = "";

			// bankbranchnumber
			$this->bankbranchnumber->LinkCustomAttributes = "";
			$this->bankbranchnumber->HrefValue = "";
			$this->bankbranchnumber->TooltipValue = "";

			// bankaccountnumber
			$this->bankaccountnumber->LinkCustomAttributes = "";
			$this->bankaccountnumber->HrefValue = "";
			$this->bankaccountnumber->TooltipValue = "";

			// other1
			$this->other1->LinkCustomAttributes = "";
			$this->other1->HrefValue = "";
			$this->other1->TooltipValue = "";

			// other2
			$this->other2->LinkCustomAttributes = "";
			$this->other2->HrefValue = "";
			$this->other2->TooltipValue = "";

			// other3
			$this->other3->LinkCustomAttributes = "";
			$this->other3->HrefValue = "";
			$this->other3->TooltipValue = "";

			// externalid
			$this->externalid->LinkCustomAttributes = "";
			$this->externalid->HrefValue = "";
			$this->externalid->TooltipValue = "";

			// couponpin
			$this->couponpin->LinkCustomAttributes = "";
			$this->couponpin->HrefValue = "";
			$this->couponpin->TooltipValue = "";

			// swiftcode
			$this->swiftcode->LinkCustomAttributes = "";
			$this->swiftcode->HrefValue = "";
			$this->swiftcode->TooltipValue = "";

			// profilevalidated
			$this->profilevalidated->LinkCustomAttributes = "";
			$this->profilevalidated->HrefValue = "";
			$this->profilevalidated->TooltipValue = "";

			// profilevalidationdate
			$this->profilevalidationdate->LinkCustomAttributes = "";
			$this->profilevalidationdate->HrefValue = "";
			$this->profilevalidationdate->TooltipValue = "";

			// industry
			$this->industry->LinkCustomAttributes = "";
			$this->industry->HrefValue = "";
			$this->industry->TooltipValue = "";

			// legalstructure
			$this->legalstructure->LinkCustomAttributes = "";
			$this->legalstructure->HrefValue = "";
			$this->legalstructure->TooltipValue = "";

			// extendedfields
			$this->extendedfields->LinkCustomAttributes = "";
			$this->extendedfields->HrefValue = "";
			$this->extendedfields->TooltipValue = "";
		} elseif ($this->RowType == ROWTYPE_ADD) { // Add row

			// userid
			$this->_userid->EditAttrs["class"] = "form-control";
			$this->_userid->EditCustomAttributes = "";
			$this->_userid->EditValue = HtmlEncode($this->_userid->CurrentValue);
			$this->_userid->PlaceHolder = RemoveHtml($this->_userid->caption());

			// businessname
			$this->businessname->EditAttrs["class"] = "form-control";
			$this->businessname->EditCustomAttributes = "";
			if (!$this->businessname->Raw)
				$this->businessname->CurrentValue = HtmlDecode($this->businessname->CurrentValue);
			$this->businessname->EditValue = HtmlEncode($this->businessname->CurrentValue);
			$this->businessname->PlaceHolder = RemoveHtml($this->businessname->caption());

			// officialname
			$this->officialname->EditAttrs["class"] = "form-control";
			$this->officialname->EditCustomAttributes = "";
			if (!$this->officialname->Raw)
				$this->officialname->CurrentValue = HtmlDecode($this->officialname->CurrentValue);
			$this->officialname->EditValue = HtmlEncode($this->officialname->CurrentValue);
			$this->officialname->PlaceHolder = RemoveHtml($this->officialname->caption());

			// changed
			$this->changed->EditCustomAttributes = "";
			$curVal = trim(strval($this->changed->CurrentValue));
			if ($curVal != "")
				$this->changed->ViewValue = $this->changed->lookupCacheOption($curVal);
			else
				$this->changed->ViewValue = $this->changed->Lookup !== NULL && is_array($this->changed->Lookup->Options) ? $curVal : NULL;
			if ($this->changed->ViewValue !== NULL) { // Load from cache
				$this->changed->EditValue = array_values($this->changed->Lookup->Options);
			} else { // Lookup from database
				if ($curVal == "") {
					$filterWrk = "0=1";
				} else {
					$filterWrk = "`id`" . SearchString("=", $this->changed->CurrentValue, DATATYPE_NUMBER, "");
				}
				$sqlWrk = $this->changed->Lookup->getSql(TRUE, $filterWrk, '', $this);
				$rswrk = Conn()->execute($sqlWrk);
				$arwrk = $rswrk ? $rswrk->getRows() : [];
				if ($rswrk)
					$rswrk->close();
				$this->changed->EditValue = $arwrk;
			}

			// active
			$this->active->EditCustomAttributes = "";
			$curVal = trim(strval($this->active->CurrentValue));
			if ($curVal != "")
				$this->active->ViewValue = $this->active->lookupCacheOption($curVal);
			else
				$this->active->ViewValue = $this->active->Lookup !== NULL && is_array($this->active->Lookup->Options) ? $curVal : NULL;
			if ($this->active->ViewValue !== NULL) { // Load from cache
				$this->active->EditValue = array_values($this->active->Lookup->Options);
			} else { // Lookup from database
				if ($curVal == "") {
					$filterWrk = "0=1";
				} else {
					$filterWrk = "`id`" . SearchString("=", $this->active->CurrentValue, DATATYPE_NUMBER, "");
				}
				$sqlWrk = $this->active->Lookup->getSql(TRUE, $filterWrk, '', $this);
				$rswrk = Conn()->execute($sqlWrk);
				$arwrk = $rswrk ? $rswrk->getRows() : [];
				if ($rswrk)
					$rswrk->close();
				$this->active->EditValue = $arwrk;
			}

			// tipallowed
			$this->tipallowed->EditCustomAttributes = "";
			$curVal = trim(strval($this->tipallowed->CurrentValue));
			if ($curVal != "")
				$this->tipallowed->ViewValue = $this->tipallowed->lookupCacheOption($curVal);
			else
				$this->tipallowed->ViewValue = $this->tipallowed->Lookup !== NULL && is_array($this->tipallowed->Lookup->Options) ? $curVal : NULL;
			if ($this->tipallowed->ViewValue !== NULL) { // Load from cache
				$this->tipallowed->EditValue = array_values($this->tipallowed->Lookup->Options);
			} else { // Lookup from database
				if ($curVal == "") {
					$filterWrk = "0=1";
				} else {
					$filterWrk = "`id`" . SearchString("=", $this->tipallowed->CurrentValue, DATATYPE_NUMBER, "");
				}
				$sqlWrk = $this->tipallowed->Lookup->getSql(TRUE, $filterWrk, '', $this);
				$rswrk = Conn()->execute($sqlWrk);
				$arwrk = $rswrk ? $rswrk->getRows() : [];
				if ($rswrk)
					$rswrk->close();
				$this->tipallowed->EditValue = $arwrk;
			}

			// merchanttoaddtip
			$this->merchanttoaddtip->EditCustomAttributes = "";
			$curVal = trim(strval($this->merchanttoaddtip->CurrentValue));
			if ($curVal != "")
				$this->merchanttoaddtip->ViewValue = $this->merchanttoaddtip->lookupCacheOption($curVal);
			else
				$this->merchanttoaddtip->ViewValue = $this->merchanttoaddtip->Lookup !== NULL && is_array($this->merchanttoaddtip->Lookup->Options) ? $curVal : NULL;
			if ($this->merchanttoaddtip->ViewValue !== NULL) { // Load from cache
				$this->merchanttoaddtip->EditValue = array_values($this->merchanttoaddtip->Lookup->Options);
			} else { // Lookup from database
				if ($curVal == "") {
					$filterWrk = "0=1";
				} else {
					$filterWrk = "`id`" . SearchString("=", $this->merchanttoaddtip->CurrentValue, DATATYPE_NUMBER, "");
				}
				$sqlWrk = $this->merchanttoaddtip->Lookup->getSql(TRUE, $filterWrk, '', $this);
				$rswrk = Conn()->execute($sqlWrk);
				$arwrk = $rswrk ? $rswrk->getRows() : [];
				if ($rswrk)
					$rswrk->close();
				$this->merchanttoaddtip->EditValue = $arwrk;
			}

			// pis
			$this->pis->EditAttrs["class"] = "form-control";
			$this->pis->EditCustomAttributes = "";
			if (!$this->pis->Raw)
				$this->pis->CurrentValue = HtmlDecode($this->pis->CurrentValue);
			$this->pis->EditValue = HtmlEncode($this->pis->CurrentValue);
			$this->pis->PlaceHolder = RemoveHtml($this->pis->caption());

			// ratetableid
			$this->ratetableid->EditAttrs["class"] = "form-control";
			$this->ratetableid->EditCustomAttributes = "";
			$this->ratetableid->EditValue = HtmlEncode($this->ratetableid->CurrentValue);
			$this->ratetableid->PlaceHolder = RemoveHtml($this->ratetableid->caption());

			// ratetabletype
			$this->ratetabletype->EditCustomAttributes = "";
			$curVal = trim(strval($this->ratetabletype->CurrentValue));
			if ($curVal != "")
				$this->ratetabletype->ViewValue = $this->ratetabletype->lookupCacheOption($curVal);
			else
				$this->ratetabletype->ViewValue = $this->ratetabletype->Lookup !== NULL && is_array($this->ratetabletype->Lookup->Options) ? $curVal : NULL;
			if ($this->ratetabletype->ViewValue !== NULL) { // Load from cache
				$this->ratetabletype->EditValue = array_values($this->ratetabletype->Lookup->Options);
				if ($this->ratetabletype->ViewValue == "")
					$this->ratetabletype->ViewValue = $Language->phrase("PleaseSelect");
			} else { // Lookup from database
				if ($curVal == "") {
					$filterWrk = "0=1";
				} else {
					$filterWrk = "`typeid`" . SearchString("=", $this->ratetabletype->CurrentValue, DATATYPE_NUMBER, "");
				}
				$sqlWrk = $this->ratetabletype->Lookup->getSql(TRUE, $filterWrk, '', $this);
				$rswrk = Conn()->execute($sqlWrk);
				if ($rswrk && !$rswrk->EOF) { // Lookup values found
					$arwrk = [];
					$arwrk[1] = HtmlEncode($rswrk->fields('df'));
					$this->ratetabletype->ViewValue = $this->ratetabletype->displayValue($arwrk);
				} else {
					$this->ratetabletype->ViewValue = $Language->phrase("PleaseSelect");
				}
				$arwrk = $rswrk ? $rswrk->getRows() : [];
				if ($rswrk)
					$rswrk->close();
				$this->ratetabletype->EditValue = $arwrk;
			}

			// officialdocnumber
			$this->officialdocnumber->EditAttrs["class"] = "form-control";
			$this->officialdocnumber->EditCustomAttributes = "";
			if (!$this->officialdocnumber->Raw)
				$this->officialdocnumber->CurrentValue = HtmlDecode($this->officialdocnumber->CurrentValue);
			$this->officialdocnumber->EditValue = HtmlEncode($this->officialdocnumber->CurrentValue);
			$this->officialdocnumber->PlaceHolder = RemoveHtml($this->officialdocnumber->caption());

			// officialdocname
			$this->officialdocname->EditAttrs["class"] = "form-control";
			$this->officialdocname->EditCustomAttributes = "";
			if (!$this->officialdocname->Raw)
				$this->officialdocname->CurrentValue = HtmlDecode($this->officialdocname->CurrentValue);
			$this->officialdocname->EditValue = HtmlEncode($this->officialdocname->CurrentValue);
			$this->officialdocname->PlaceHolder = RemoveHtml($this->officialdocname->caption());

			// softposid
			$this->softposid->EditAttrs["class"] = "form-control";
			$this->softposid->EditCustomAttributes = "";
			if (!$this->softposid->Raw)
				$this->softposid->CurrentValue = HtmlDecode($this->softposid->CurrentValue);
			$this->softposid->EditValue = HtmlEncode($this->softposid->CurrentValue);
			$this->softposid->PlaceHolder = RemoveHtml($this->softposid->caption());

			// taxamount
			$this->taxamount->EditAttrs["class"] = "form-control";
			$this->taxamount->EditCustomAttributes = "";
			$this->taxamount->EditValue = HtmlEncode($this->taxamount->CurrentValue);
			$this->taxamount->PlaceHolder = RemoveHtml($this->taxamount->caption());
			if (strval($this->taxamount->EditValue) != "" && is_numeric($this->taxamount->EditValue))
				$this->taxamount->EditValue = FormatNumber($this->taxamount->EditValue, -2, -2, -2, -2);
			

			// variabletax
			$this->variabletax->EditCustomAttributes = "";
			$curVal = trim(strval($this->variabletax->CurrentValue));
			if ($curVal != "")
				$this->variabletax->ViewValue = $this->variabletax->lookupCacheOption($curVal);
			else
				$this->variabletax->ViewValue = $this->variabletax->Lookup !== NULL && is_array($this->variabletax->Lookup->Options) ? $curVal : NULL;
			if ($this->variabletax->ViewValue !== NULL) { // Load from cache
				$this->variabletax->EditValue = array_values($this->variabletax->Lookup->Options);
			} else { // Lookup from database
				if ($curVal == "") {
					$filterWrk = "0=1";
				} else {
					$filterWrk = "`id`" . SearchString("=", $this->variabletax->CurrentValue, DATATYPE_NUMBER, "");
				}
				$sqlWrk = $this->variabletax->Lookup->getSql(TRUE, $filterWrk, '', $this);
				$rswrk = Conn()->execute($sqlWrk);
				$arwrk = $rswrk ? $rswrk->getRows() : [];
				if ($rswrk)
					$rswrk->close();
				$this->variabletax->EditValue = $arwrk;
			}

			// logofilename
			$this->logofilename->EditAttrs["class"] = "form-control";
			$this->logofilename->EditCustomAttributes = "";
			if (!$this->logofilename->Raw)
				$this->logofilename->CurrentValue = HtmlDecode($this->logofilename->CurrentValue);
			$this->logofilename->EditValue = HtmlEncode($this->logofilename->CurrentValue);
			$this->logofilename->PlaceHolder = RemoveHtml($this->logofilename->caption());

			// returndays
			$this->returndays->EditAttrs["class"] = "form-control";
			$this->returndays->EditCustomAttributes = "";
			$this->returndays->EditValue = HtmlEncode($this->returndays->CurrentValue);
			$this->returndays->PlaceHolder = RemoveHtml($this->returndays->caption());

			// memberextrafieldsid
			$this->memberextrafieldsid->EditAttrs["class"] = "form-control";
			$this->memberextrafieldsid->EditCustomAttributes = "";
			$this->memberextrafieldsid->EditValue = HtmlEncode($this->memberextrafieldsid->CurrentValue);
			$this->memberextrafieldsid->PlaceHolder = RemoveHtml($this->memberextrafieldsid->caption());

			// lastupdatedate
			$this->lastupdatedate->EditAttrs["class"] = "form-control";
			$this->lastupdatedate->EditCustomAttributes = "";
			$this->lastupdatedate->EditValue = HtmlEncode(FormatDateTime($this->lastupdatedate->CurrentValue, 8));
			$this->lastupdatedate->PlaceHolder = RemoveHtml($this->lastupdatedate->caption());

			// remmitancetype
			$this->remmitancetype->EditAttrs["class"] = "form-control";
			$this->remmitancetype->EditCustomAttributes = "";
			$this->remmitancetype->EditValue = $this->remmitancetype->options(TRUE);

			// withholdingtaxaccount
			$this->withholdingtaxaccount->EditAttrs["class"] = "form-control";
			$this->withholdingtaxaccount->EditCustomAttributes = "";
			$this->withholdingtaxaccount->EditValue = HtmlEncode($this->withholdingtaxaccount->CurrentValue);
			$this->withholdingtaxaccount->PlaceHolder = RemoveHtml($this->withholdingtaxaccount->caption());

			// businessphoneno
			$this->businessphoneno->EditAttrs["class"] = "form-control";
			$this->businessphoneno->EditCustomAttributes = "";
			if (!$this->businessphoneno->Raw)
				$this->businessphoneno->CurrentValue = HtmlDecode($this->businessphoneno->CurrentValue);
			$this->businessphoneno->EditValue = HtmlEncode($this->businessphoneno->CurrentValue);
			$this->businessphoneno->PlaceHolder = RemoveHtml($this->businessphoneno->caption());

			// businessaddress1
			$this->businessaddress1->EditAttrs["class"] = "form-control";
			$this->businessaddress1->EditCustomAttributes = "";
			if (!$this->businessaddress1->Raw)
				$this->businessaddress1->CurrentValue = HtmlDecode($this->businessaddress1->CurrentValue);
			$this->businessaddress1->EditValue = HtmlEncode($this->businessaddress1->CurrentValue);
			$this->businessaddress1->PlaceHolder = RemoveHtml($this->businessaddress1->caption());

			// businessaddress2
			$this->businessaddress2->EditAttrs["class"] = "form-control";
			$this->businessaddress2->EditCustomAttributes = "";
			if (!$this->businessaddress2->Raw)
				$this->businessaddress2->CurrentValue = HtmlDecode($this->businessaddress2->CurrentValue);
			$this->businessaddress2->EditValue = HtmlEncode($this->businessaddress2->CurrentValue);
			$this->businessaddress2->PlaceHolder = RemoveHtml($this->businessaddress2->caption());

			// businesscity
			$this->businesscity->EditAttrs["class"] = "form-control";
			$this->businesscity->EditCustomAttributes = "";
			if (!$this->businesscity->Raw)
				$this->businesscity->CurrentValue = HtmlDecode($this->businesscity->CurrentValue);
			$this->businesscity->EditValue = HtmlEncode($this->businesscity->CurrentValue);
			$this->businesscity->PlaceHolder = RemoveHtml($this->businesscity->caption());

			// businesscountry
			$this->businesscountry->EditCustomAttributes = "";
			$curVal = trim(strval($this->businesscountry->CurrentValue));
			if ($curVal != "")
				$this->businesscountry->ViewValue = $this->businesscountry->lookupCacheOption($curVal);
			else
				$this->businesscountry->ViewValue = $this->businesscountry->Lookup !== NULL && is_array($this->businesscountry->Lookup->Options) ? $curVal : NULL;
			if ($this->businesscountry->ViewValue !== NULL) { // Load from cache
				$this->businesscountry->EditValue = array_values($this->businesscountry->Lookup->Options);
				if ($this->businesscountry->ViewValue == "")
					$this->businesscountry->ViewValue = $Language->phrase("PleaseSelect");
			} else { // Lookup from database
				if ($curVal == "") {
					$filterWrk = "0=1";
				} else {
					$filterWrk = "`countryID`" . SearchString("=", $this->businesscountry->CurrentValue, DATATYPE_STRING, "_4payreference");
				}
				$sqlWrk = $this->businesscountry->Lookup->getSql(TRUE, $filterWrk, '', $this);
				$rswrk = Conn("_4payreference")->execute($sqlWrk);
				if ($rswrk && !$rswrk->EOF) { // Lookup values found
					$arwrk = [];
					$arwrk[1] = HtmlEncode($rswrk->fields('df'));
					$this->businesscountry->ViewValue = $this->businesscountry->displayValue($arwrk);
				} else {
					$this->businesscountry->ViewValue = $Language->phrase("PleaseSelect");
				}
				$arwrk = $rswrk ? $rswrk->getRows() : [];
				if ($rswrk)
					$rswrk->close();
				$this->businesscountry->EditValue = $arwrk;
			}

			// businessstate
			$this->businessstate->EditCustomAttributes = "";
			$curVal = trim(strval($this->businessstate->CurrentValue));
			if ($curVal != "")
				$this->businessstate->ViewValue = $this->businessstate->lookupCacheOption($curVal);
			else
				$this->businessstate->ViewValue = $this->businessstate->Lookup !== NULL && is_array($this->businessstate->Lookup->Options) ? $curVal : NULL;
			if ($this->businessstate->ViewValue !== NULL) { // Load from cache
				$this->businessstate->EditValue = array_values($this->businessstate->Lookup->Options);
				if ($this->businessstate->ViewValue == "")
					$this->businessstate->ViewValue = $Language->phrase("PleaseSelect");
			} else { // Lookup from database
				if ($curVal == "") {
					$filterWrk = "0=1";
				} else {
					$filterWrk = "`stateid`" . SearchString("=", $this->businessstate->CurrentValue, DATATYPE_STRING, "_4payreference");
				}
				$sqlWrk = $this->businessstate->Lookup->getSql(TRUE, $filterWrk, '', $this);
				$rswrk = Conn("_4payreference")->execute($sqlWrk);
				if ($rswrk && !$rswrk->EOF) { // Lookup values found
					$arwrk = [];
					$arwrk[1] = HtmlEncode($rswrk->fields('df'));
					$this->businessstate->ViewValue = $this->businessstate->displayValue($arwrk);
				} else {
					$this->businessstate->ViewValue = $Language->phrase("PleaseSelect");
				}
				$arwrk = $rswrk ? $rswrk->getRows() : [];
				if ($rswrk)
					$rswrk->close();
				$this->businessstate->EditValue = $arwrk;
			}

			// businesszipcode
			$this->businesszipcode->EditAttrs["class"] = "form-control";
			$this->businesszipcode->EditCustomAttributes = "";
			if (!$this->businesszipcode->Raw)
				$this->businesszipcode->CurrentValue = HtmlDecode($this->businesszipcode->CurrentValue);
			$this->businesszipcode->EditValue = HtmlEncode($this->businesszipcode->CurrentValue);
			$this->businesszipcode->PlaceHolder = RemoveHtml($this->businesszipcode->caption());

			// bankname
			$this->bankname->EditAttrs["class"] = "form-control";
			$this->bankname->EditCustomAttributes = "";
			if (!$this->bankname->Raw)
				$this->bankname->CurrentValue = HtmlDecode($this->bankname->CurrentValue);
			$this->bankname->EditValue = HtmlEncode($this->bankname->CurrentValue);
			$this->bankname->PlaceHolder = RemoveHtml($this->bankname->caption());

			// bankbranchnumber
			$this->bankbranchnumber->EditAttrs["class"] = "form-control";
			$this->bankbranchnumber->EditCustomAttributes = "";
			if (!$this->bankbranchnumber->Raw)
				$this->bankbranchnumber->CurrentValue = HtmlDecode($this->bankbranchnumber->CurrentValue);
			$this->bankbranchnumber->EditValue = HtmlEncode($this->bankbranchnumber->CurrentValue);
			$this->bankbranchnumber->PlaceHolder = RemoveHtml($this->bankbranchnumber->caption());

			// bankaccountnumber
			$this->bankaccountnumber->EditAttrs["class"] = "form-control";
			$this->bankaccountnumber->EditCustomAttributes = "";
			if (!$this->bankaccountnumber->Raw)
				$this->bankaccountnumber->CurrentValue = HtmlDecode($this->bankaccountnumber->CurrentValue);
			$this->bankaccountnumber->EditValue = HtmlEncode($this->bankaccountnumber->CurrentValue);
			$this->bankaccountnumber->PlaceHolder = RemoveHtml($this->bankaccountnumber->caption());

			// other1
			$this->other1->EditAttrs["class"] = "form-control";
			$this->other1->EditCustomAttributes = "";
			if (!$this->other1->Raw)
				$this->other1->CurrentValue = HtmlDecode($this->other1->CurrentValue);
			$this->other1->EditValue = HtmlEncode($this->other1->CurrentValue);
			$this->other1->PlaceHolder = RemoveHtml($this->other1->caption());

			// other2
			$this->other2->EditAttrs["class"] = "form-control";
			$this->other2->EditCustomAttributes = "";
			if (!$this->other2->Raw)
				$this->other2->CurrentValue = HtmlDecode($this->other2->CurrentValue);
			$this->other2->EditValue = HtmlEncode($this->other2->CurrentValue);
			$this->other2->PlaceHolder = RemoveHtml($this->other2->caption());

			// other3
			$this->other3->EditAttrs["class"] = "form-control";
			$this->other3->EditCustomAttributes = "";
			if (!$this->other3->Raw)
				$this->other3->CurrentValue = HtmlDecode($this->other3->CurrentValue);
			$this->other3->EditValue = HtmlEncode($this->other3->CurrentValue);
			$this->other3->PlaceHolder = RemoveHtml($this->other3->caption());

			// externalid
			$this->externalid->EditAttrs["class"] = "form-control";
			$this->externalid->EditCustomAttributes = "";
			if (!$this->externalid->Raw)
				$this->externalid->CurrentValue = HtmlDecode($this->externalid->CurrentValue);
			$this->externalid->EditValue = HtmlEncode($this->externalid->CurrentValue);
			$this->externalid->PlaceHolder = RemoveHtml($this->externalid->caption());

			// couponpin
			$this->couponpin->EditAttrs["class"] = "form-control";
			$this->couponpin->EditCustomAttributes = "";
			if (!$this->couponpin->Raw)
				$this->couponpin->CurrentValue = HtmlDecode($this->couponpin->CurrentValue);
			$this->couponpin->EditValue = HtmlEncode($this->couponpin->CurrentValue);
			$this->couponpin->PlaceHolder = RemoveHtml($this->couponpin->caption());

			// swiftcode
			$this->swiftcode->EditAttrs["class"] = "form-control";
			$this->swiftcode->EditCustomAttributes = "";
			if (!$this->swiftcode->Raw)
				$this->swiftcode->CurrentValue = HtmlDecode($this->swiftcode->CurrentValue);
			$this->swiftcode->EditValue = HtmlEncode($this->swiftcode->CurrentValue);
			$this->swiftcode->PlaceHolder = RemoveHtml($this->swiftcode->caption());

			// profilevalidated
			$this->profilevalidated->EditCustomAttributes = "";
			$curVal = trim(strval($this->profilevalidated->CurrentValue));
			if ($curVal != "")
				$this->profilevalidated->ViewValue = $this->profilevalidated->lookupCacheOption($curVal);
			else
				$this->profilevalidated->ViewValue = $this->profilevalidated->Lookup !== NULL && is_array($this->profilevalidated->Lookup->Options) ? $curVal : NULL;
			if ($this->profilevalidated->ViewValue !== NULL) { // Load from cache
				$this->profilevalidated->EditValue = array_values($this->profilevalidated->Lookup->Options);
			} else { // Lookup from database
				if ($curVal == "") {
					$filterWrk = "0=1";
				} else {
					$filterWrk = "`statusID`" . SearchString("=", $this->profilevalidated->CurrentValue, DATATYPE_NUMBER, "");
				}
				$lookupFilter = function() {
					return "`langID` = 'EN'";
				};
				$lookupFilter = $lookupFilter->bindTo($this);
				$sqlWrk = $this->profilevalidated->Lookup->getSql(TRUE, $filterWrk, $lookupFilter, $this);
				$rswrk = Conn()->execute($sqlWrk);
				$arwrk = $rswrk ? $rswrk->getRows() : [];
				if ($rswrk)
					$rswrk->close();
				$this->profilevalidated->EditValue = $arwrk;
			}

			// profilevalidationdate
			$this->profilevalidationdate->EditAttrs["class"] = "form-control";
			$this->profilevalidationdate->EditCustomAttributes = "";
			$this->profilevalidationdate->EditValue = HtmlEncode(FormatDateTime($this->profilevalidationdate->CurrentValue, 8));
			$this->profilevalidationdate->PlaceHolder = RemoveHtml($this->profilevalidationdate->caption());

			// industry
			$this->industry->EditAttrs["class"] = "form-control";
			$this->industry->EditCustomAttributes = "";
			$curVal = trim(strval($this->industry->CurrentValue));
			if ($curVal != "")
				$this->industry->ViewValue = $this->industry->lookupCacheOption($curVal);
			else
				$this->industry->ViewValue = $this->industry->Lookup !== NULL && is_array($this->industry->Lookup->Options) ? $curVal : NULL;
			if ($this->industry->ViewValue !== NULL) { // Load from cache
				$this->industry->EditValue = array_values($this->industry->Lookup->Options);
			} else { // Lookup from database
				if ($curVal == "") {
					$filterWrk = "0=1";
				} else {
					$filterWrk = "`typeID`" . SearchString("=", $this->industry->CurrentValue, DATATYPE_STRING, "_4payreference");
				}
				$sqlWrk = $this->industry->Lookup->getSql(TRUE, $filterWrk, '', $this);
				$rswrk = Conn("_4payreference")->execute($sqlWrk);
				$arwrk = $rswrk ? $rswrk->getRows() : [];
				if ($rswrk)
					$rswrk->close();
				$this->industry->EditValue = $arwrk;
			}

			// legalstructure
			$this->legalstructure->EditAttrs["class"] = "form-control";
			$this->legalstructure->EditCustomAttributes = "";
			$curVal = trim(strval($this->legalstructure->CurrentValue));
			if ($curVal != "")
				$this->legalstructure->ViewValue = $this->legalstructure->lookupCacheOption($curVal);
			else
				$this->legalstructure->ViewValue = $this->legalstructure->Lookup !== NULL && is_array($this->legalstructure->Lookup->Options) ? $curVal : NULL;
			if ($this->legalstructure->ViewValue !== NULL) { // Load from cache
				$this->legalstructure->EditValue = array_values($this->legalstructure->Lookup->Options);
			} else { // Lookup from database
				if ($curVal == "") {
					$filterWrk = "0=1";
				} else {
					$filterWrk = "`typeID`" . SearchString("=", $this->legalstructure->CurrentValue, DATATYPE_STRING, "_4payreference");
				}
				$sqlWrk = $this->legalstructure->Lookup->getSql(TRUE, $filterWrk, '', $this);
				$rswrk = Conn("_4payreference")->execute($sqlWrk);
				$arwrk = $rswrk ? $rswrk->getRows() : [];
				if ($rswrk)
					$rswrk->close();
				$this->legalstructure->EditValue = $arwrk;
			}

			// extendedfields
			$this->extendedfields->EditAttrs["class"] = "form-control";
			$this->extendedfields->EditCustomAttributes = "";
			$this->extendedfields->EditValue = HtmlEncode($this->extendedfields->CurrentValue);
			$this->extendedfields->PlaceHolder = RemoveHtml($this->extendedfields->caption());

			// Add refer script
			// userid

			$this->_userid->LinkCustomAttributes = "";
			if (!EmptyValue($this->_userid->CurrentValue)) {
				$this->_userid->HrefValue = "userview.php?showdetail=&id=" . $this->_userid->CurrentValue; // Add prefix/suffix
				$this->_userid->LinkAttrs["target"] = ""; // Add target
				if ($this->isExport())
					$this->_userid->HrefValue = FullUrl($this->_userid->HrefValue, "href");
			} else {
				$this->_userid->HrefValue = "";
			}

			// businessname
			$this->businessname->LinkCustomAttributes = "";
			$this->businessname->HrefValue = "";

			// officialname
			$this->officialname->LinkCustomAttributes = "";
			$this->officialname->HrefValue = "";

			// changed
			$this->changed->LinkCustomAttributes = "";
			$this->changed->HrefValue = "";

			// active
			$this->active->LinkCustomAttributes = "";
			$this->active->HrefValue = "";

			// tipallowed
			$this->tipallowed->LinkCustomAttributes = "";
			$this->tipallowed->HrefValue = "";

			// merchanttoaddtip
			$this->merchanttoaddtip->LinkCustomAttributes = "";
			$this->merchanttoaddtip->HrefValue = "";

			// pis
			$this->pis->LinkCustomAttributes = "";
			$this->pis->HrefValue = "";

			// ratetableid
			$this->ratetableid->LinkCustomAttributes = "";
			$this->ratetableid->HrefValue = "";

			// ratetabletype
			$this->ratetabletype->LinkCustomAttributes = "";
			$this->ratetabletype->HrefValue = "";

			// officialdocnumber
			$this->officialdocnumber->LinkCustomAttributes = "";
			$this->officialdocnumber->HrefValue = "";

			// officialdocname
			$this->officialdocname->LinkCustomAttributes = "";
			$this->officialdocname->HrefValue = "";

			// softposid
			$this->softposid->LinkCustomAttributes = "";
			$this->softposid->HrefValue = "";

			// taxamount
			$this->taxamount->LinkCustomAttributes = "";
			$this->taxamount->HrefValue = "";

			// variabletax
			$this->variabletax->LinkCustomAttributes = "";
			$this->variabletax->HrefValue = "";

			// logofilename
			$this->logofilename->LinkCustomAttributes = "";
			$this->logofilename->HrefValue = "";

			// returndays
			$this->returndays->LinkCustomAttributes = "";
			$this->returndays->HrefValue = "";

			// memberextrafieldsid
			$this->memberextrafieldsid->LinkCustomAttributes = "";
			$this->memberextrafieldsid->HrefValue = "";

			// lastupdatedate
			$this->lastupdatedate->LinkCustomAttributes = "";
			$this->lastupdatedate->HrefValue = "";

			// remmitancetype
			$this->remmitancetype->LinkCustomAttributes = "";
			$this->remmitancetype->HrefValue = "";

			// withholdingtaxaccount
			$this->withholdingtaxaccount->LinkCustomAttributes = "";
			$this->withholdingtaxaccount->HrefValue = "";

			// businessphoneno
			$this->businessphoneno->LinkCustomAttributes = "";
			$this->businessphoneno->HrefValue = "";

			// businessaddress1
			$this->businessaddress1->LinkCustomAttributes = "";
			$this->businessaddress1->HrefValue = "";

			// businessaddress2
			$this->businessaddress2->LinkCustomAttributes = "";
			$this->businessaddress2->HrefValue = "";

			// businesscity
			$this->businesscity->LinkCustomAttributes = "";
			$this->businesscity->HrefValue = "";

			// businesscountry
			$this->businesscountry->LinkCustomAttributes = "";
			$this->businesscountry->HrefValue = "";

			// businessstate
			$this->businessstate->LinkCustomAttributes = "";
			$this->businessstate->HrefValue = "";

			// businesszipcode
			$this->businesszipcode->LinkCustomAttributes = "";
			$this->businesszipcode->HrefValue = "";

			// bankname
			$this->bankname->LinkCustomAttributes = "";
			$this->bankname->HrefValue = "";

			// bankbranchnumber
			$this->bankbranchnumber->LinkCustomAttributes = "";
			$this->bankbranchnumber->HrefValue = "";

			// bankaccountnumber
			$this->bankaccountnumber->LinkCustomAttributes = "";
			$this->bankaccountnumber->HrefValue = "";

			// other1
			$this->other1->LinkCustomAttributes = "";
			$this->other1->HrefValue = "";

			// other2
			$this->other2->LinkCustomAttributes = "";
			$this->other2->HrefValue = "";

			// other3
			$this->other3->LinkCustomAttributes = "";
			$this->other3->HrefValue = "";

			// externalid
			$this->externalid->LinkCustomAttributes = "";
			$this->externalid->HrefValue = "";

			// couponpin
			$this->couponpin->LinkCustomAttributes = "";
			$this->couponpin->HrefValue = "";

			// swiftcode
			$this->swiftcode->LinkCustomAttributes = "";
			$this->swiftcode->HrefValue = "";

			// profilevalidated
			$this->profilevalidated->LinkCustomAttributes = "";
			$this->profilevalidated->HrefValue = "";

			// profilevalidationdate
			$this->profilevalidationdate->LinkCustomAttributes = "";
			$this->profilevalidationdate->HrefValue = "";

			// industry
			$this->industry->LinkCustomAttributes = "";
			$this->industry->HrefValue = "";

			// legalstructure
			$this->legalstructure->LinkCustomAttributes = "";
			$this->legalstructure->HrefValue = "";

			// extendedfields
			$this->extendedfields->LinkCustomAttributes = "";
			$this->extendedfields->HrefValue = "";
		}
		if ($this->RowType == ROWTYPE_ADD || $this->RowType == ROWTYPE_EDIT || $this->RowType == ROWTYPE_SEARCH) // Add/Edit/Search row
			$this->setupFieldTitles();

		// Call Row Rendered event
		if ($this->RowType != ROWTYPE_AGGREGATEINIT)
			$this->Row_Rendered();
	}

	// Validate form
	protected function validateForm()
	{
		global $Language, $FormError;

		// Initialize form error message
		$FormError = "";

		// Check if validation required
		if (!Config("SERVER_VALIDATE"))
			return ($FormError == "");
		if ($this->_userid->Required) {
			if (!$this->_userid->IsDetailKey && $this->_userid->FormValue != NULL && $this->_userid->FormValue == "") {
				AddMessage($FormError, str_replace("%s", $this->_userid->caption(), $this->_userid->RequiredErrorMessage));
			}
		}
		if (!CheckInteger($this->_userid->FormValue)) {
			AddMessage($FormError, $this->_userid->errorMessage());
		}
		if ($this->businessname->Required) {
			if (!$this->businessname->IsDetailKey && $this->businessname->FormValue != NULL && $this->businessname->FormValue == "") {
				AddMessage($FormError, str_replace("%s", $this->businessname->caption(), $this->businessname->RequiredErrorMessage));
			}
		}
		if ($this->officialname->Required) {
			if (!$this->officialname->IsDetailKey && $this->officialname->FormValue != NULL && $this->officialname->FormValue == "") {
				AddMessage($FormError, str_replace("%s", $this->officialname->caption(), $this->officialname->RequiredErrorMessage));
			}
		}
		if ($this->changed->Required) {
			if ($this->changed->FormValue == "") {
				AddMessage($FormError, str_replace("%s", $this->changed->caption(), $this->changed->RequiredErrorMessage));
			}
		}
		if ($this->active->Required) {
			if ($this->active->FormValue == "") {
				AddMessage($FormError, str_replace("%s", $this->active->caption(), $this->active->RequiredErrorMessage));
			}
		}
		if ($this->tipallowed->Required) {
			if ($this->tipallowed->FormValue == "") {
				AddMessage($FormError, str_replace("%s", $this->tipallowed->caption(), $this->tipallowed->RequiredErrorMessage));
			}
		}
		if ($this->merchanttoaddtip->Required) {
			if ($this->merchanttoaddtip->FormValue == "") {
				AddMessage($FormError, str_replace("%s", $this->merchanttoaddtip->caption(), $this->merchanttoaddtip->RequiredErrorMessage));
			}
		}
		if ($this->pis->Required) {
			if (!$this->pis->IsDetailKey && $this->pis->FormValue != NULL && $this->pis->FormValue == "") {
				AddMessage($FormError, str_replace("%s", $this->pis->caption(), $this->pis->RequiredErrorMessage));
			}
		}
		if ($this->ratetableid->Required) {
			if (!$this->ratetableid->IsDetailKey && $this->ratetableid->FormValue != NULL && $this->ratetableid->FormValue == "") {
				AddMessage($FormError, str_replace("%s", $this->ratetableid->caption(), $this->ratetableid->RequiredErrorMessage));
			}
		}
		if (!CheckInteger($this->ratetableid->FormValue)) {
			AddMessage($FormError, $this->ratetableid->errorMessage());
		}
		if ($this->ratetabletype->Required) {
			if (!$this->ratetabletype->IsDetailKey && $this->ratetabletype->FormValue != NULL && $this->ratetabletype->FormValue == "") {
				AddMessage($FormError, str_replace("%s", $this->ratetabletype->caption(), $this->ratetabletype->RequiredErrorMessage));
			}
		}
		if ($this->officialdocnumber->Required) {
			if (!$this->officialdocnumber->IsDetailKey && $this->officialdocnumber->FormValue != NULL && $this->officialdocnumber->FormValue == "") {
				AddMessage($FormError, str_replace("%s", $this->officialdocnumber->caption(), $this->officialdocnumber->RequiredErrorMessage));
			}
		}
		if ($this->officialdocname->Required) {
			if (!$this->officialdocname->IsDetailKey && $this->officialdocname->FormValue != NULL && $this->officialdocname->FormValue == "") {
				AddMessage($FormError, str_replace("%s", $this->officialdocname->caption(), $this->officialdocname->RequiredErrorMessage));
			}
		}
		if ($this->softposid->Required) {
			if (!$this->softposid->IsDetailKey && $this->softposid->FormValue != NULL && $this->softposid->FormValue == "") {
				AddMessage($FormError, str_replace("%s", $this->softposid->caption(), $this->softposid->RequiredErrorMessage));
			}
		}
		if ($this->taxamount->Required) {
			if (!$this->taxamount->IsDetailKey && $this->taxamount->FormValue != NULL && $this->taxamount->FormValue == "") {
				AddMessage($FormError, str_replace("%s", $this->taxamount->caption(), $this->taxamount->RequiredErrorMessage));
			}
		}
		if (!CheckNumber($this->taxamount->FormValue)) {
			AddMessage($FormError, $this->taxamount->errorMessage());
		}
		if ($this->variabletax->Required) {
			if ($this->variabletax->FormValue == "") {
				AddMessage($FormError, str_replace("%s", $this->variabletax->caption(), $this->variabletax->RequiredErrorMessage));
			}
		}
		if ($this->logofilename->Required) {
			if (!$this->logofilename->IsDetailKey && $this->logofilename->FormValue != NULL && $this->logofilename->FormValue == "") {
				AddMessage($FormError, str_replace("%s", $this->logofilename->caption(), $this->logofilename->RequiredErrorMessage));
			}
		}
		if ($this->returndays->Required) {
			if (!$this->returndays->IsDetailKey && $this->returndays->FormValue != NULL && $this->returndays->FormValue == "") {
				AddMessage($FormError, str_replace("%s", $this->returndays->caption(), $this->returndays->RequiredErrorMessage));
			}
		}
		if (!CheckInteger($this->returndays->FormValue)) {
			AddMessage($FormError, $this->returndays->errorMessage());
		}
		if ($this->memberextrafieldsid->Required) {
			if (!$this->memberextrafieldsid->IsDetailKey && $this->memberextrafieldsid->FormValue != NULL && $this->memberextrafieldsid->FormValue == "") {
				AddMessage($FormError, str_replace("%s", $this->memberextrafieldsid->caption(), $this->memberextrafieldsid->RequiredErrorMessage));
			}
		}
		if (!CheckInteger($this->memberextrafieldsid->FormValue)) {
			AddMessage($FormError, $this->memberextrafieldsid->errorMessage());
		}
		if ($this->lastupdatedate->Required) {
			if (!$this->lastupdatedate->IsDetailKey && $this->lastupdatedate->FormValue != NULL && $this->lastupdatedate->FormValue == "") {
				AddMessage($FormError, str_replace("%s", $this->lastupdatedate->caption(), $this->lastupdatedate->RequiredErrorMessage));
			}
		}
		if (!CheckDate($this->lastupdatedate->FormValue)) {
			AddMessage($FormError, $this->lastupdatedate->errorMessage());
		}
		if ($this->remmitancetype->Required) {
			if (!$this->remmitancetype->IsDetailKey && $this->remmitancetype->FormValue != NULL && $this->remmitancetype->FormValue == "") {
				AddMessage($FormError, str_replace("%s", $this->remmitancetype->caption(), $this->remmitancetype->RequiredErrorMessage));
			}
		}
		if ($this->withholdingtaxaccount->Required) {
			if (!$this->withholdingtaxaccount->IsDetailKey && $this->withholdingtaxaccount->FormValue != NULL && $this->withholdingtaxaccount->FormValue == "") {
				AddMessage($FormError, str_replace("%s", $this->withholdingtaxaccount->caption(), $this->withholdingtaxaccount->RequiredErrorMessage));
			}
		}
		if (!CheckInteger($this->withholdingtaxaccount->FormValue)) {
			AddMessage($FormError, $this->withholdingtaxaccount->errorMessage());
		}
		if ($this->businessphoneno->Required) {
			if (!$this->businessphoneno->IsDetailKey && $this->businessphoneno->FormValue != NULL && $this->businessphoneno->FormValue == "") {
				AddMessage($FormError, str_replace("%s", $this->businessphoneno->caption(), $this->businessphoneno->RequiredErrorMessage));
			}
		}
		if ($this->businessaddress1->Required) {
			if (!$this->businessaddress1->IsDetailKey && $this->businessaddress1->FormValue != NULL && $this->businessaddress1->FormValue == "") {
				AddMessage($FormError, str_replace("%s", $this->businessaddress1->caption(), $this->businessaddress1->RequiredErrorMessage));
			}
		}
		if ($this->businessaddress2->Required) {
			if (!$this->businessaddress2->IsDetailKey && $this->businessaddress2->FormValue != NULL && $this->businessaddress2->FormValue == "") {
				AddMessage($FormError, str_replace("%s", $this->businessaddress2->caption(), $this->businessaddress2->RequiredErrorMessage));
			}
		}
		if ($this->businesscity->Required) {
			if (!$this->businesscity->IsDetailKey && $this->businesscity->FormValue != NULL && $this->businesscity->FormValue == "") {
				AddMessage($FormError, str_replace("%s", $this->businesscity->caption(), $this->businesscity->RequiredErrorMessage));
			}
		}
		if ($this->businesscountry->Required) {
			if (!$this->businesscountry->IsDetailKey && $this->businesscountry->FormValue != NULL && $this->businesscountry->FormValue == "") {
				AddMessage($FormError, str_replace("%s", $this->businesscountry->caption(), $this->businesscountry->RequiredErrorMessage));
			}
		}
		if ($this->businessstate->Required) {
			if (!$this->businessstate->IsDetailKey && $this->businessstate->FormValue != NULL && $this->businessstate->FormValue == "") {
				AddMessage($FormError, str_replace("%s", $this->businessstate->caption(), $this->businessstate->RequiredErrorMessage));
			}
		}
		if ($this->businesszipcode->Required) {
			if (!$this->businesszipcode->IsDetailKey && $this->businesszipcode->FormValue != NULL && $this->businesszipcode->FormValue == "") {
				AddMessage($FormError, str_replace("%s", $this->businesszipcode->caption(), $this->businesszipcode->RequiredErrorMessage));
			}
		}
		if ($this->bankname->Required) {
			if (!$this->bankname->IsDetailKey && $this->bankname->FormValue != NULL && $this->bankname->FormValue == "") {
				AddMessage($FormError, str_replace("%s", $this->bankname->caption(), $this->bankname->RequiredErrorMessage));
			}
		}
		if ($this->bankbranchnumber->Required) {
			if (!$this->bankbranchnumber->IsDetailKey && $this->bankbranchnumber->FormValue != NULL && $this->bankbranchnumber->FormValue == "") {
				AddMessage($FormError, str_replace("%s", $this->bankbranchnumber->caption(), $this->bankbranchnumber->RequiredErrorMessage));
			}
		}
		if ($this->bankaccountnumber->Required) {
			if (!$this->bankaccountnumber->IsDetailKey && $this->bankaccountnumber->FormValue != NULL && $this->bankaccountnumber->FormValue == "") {
				AddMessage($FormError, str_replace("%s", $this->bankaccountnumber->caption(), $this->bankaccountnumber->RequiredErrorMessage));
			}
		}
		if ($this->other1->Required) {
			if (!$this->other1->IsDetailKey && $this->other1->FormValue != NULL && $this->other1->FormValue == "") {
				AddMessage($FormError, str_replace("%s", $this->other1->caption(), $this->other1->RequiredErrorMessage));
			}
		}
		if ($this->other2->Required) {
			if (!$this->other2->IsDetailKey && $this->other2->FormValue != NULL && $this->other2->FormValue == "") {
				AddMessage($FormError, str_replace("%s", $this->other2->caption(), $this->other2->RequiredErrorMessage));
			}
		}
		if ($this->other3->Required) {
			if (!$this->other3->IsDetailKey && $this->other3->FormValue != NULL && $this->other3->FormValue == "") {
				AddMessage($FormError, str_replace("%s", $this->other3->caption(), $this->other3->RequiredErrorMessage));
			}
		}
		if ($this->externalid->Required) {
			if (!$this->externalid->IsDetailKey && $this->externalid->FormValue != NULL && $this->externalid->FormValue == "") {
				AddMessage($FormError, str_replace("%s", $this->externalid->caption(), $this->externalid->RequiredErrorMessage));
			}
		}
		if ($this->couponpin->Required) {
			if (!$this->couponpin->IsDetailKey && $this->couponpin->FormValue != NULL && $this->couponpin->FormValue == "") {
				AddMessage($FormError, str_replace("%s", $this->couponpin->caption(), $this->couponpin->RequiredErrorMessage));
			}
		}
		if ($this->swiftcode->Required) {
			if (!$this->swiftcode->IsDetailKey && $this->swiftcode->FormValue != NULL && $this->swiftcode->FormValue == "") {
				AddMessage($FormError, str_replace("%s", $this->swiftcode->caption(), $this->swiftcode->RequiredErrorMessage));
			}
		}
		if ($this->profilevalidated->Required) {
			if ($this->profilevalidated->FormValue == "") {
				AddMessage($FormError, str_replace("%s", $this->profilevalidated->caption(), $this->profilevalidated->RequiredErrorMessage));
			}
		}
		if ($this->profilevalidationdate->Required) {
			if (!$this->profilevalidationdate->IsDetailKey && $this->profilevalidationdate->FormValue != NULL && $this->profilevalidationdate->FormValue == "") {
				AddMessage($FormError, str_replace("%s", $this->profilevalidationdate->caption(), $this->profilevalidationdate->RequiredErrorMessage));
			}
		}
		if (!CheckDate($this->profilevalidationdate->FormValue)) {
			AddMessage($FormError, $this->profilevalidationdate->errorMessage());
		}
		if ($this->industry->Required) {
			if (!$this->industry->IsDetailKey && $this->industry->FormValue != NULL && $this->industry->FormValue == "") {
				AddMessage($FormError, str_replace("%s", $this->industry->caption(), $this->industry->RequiredErrorMessage));
			}
		}
		if ($this->legalstructure->Required) {
			if (!$this->legalstructure->IsDetailKey && $this->legalstructure->FormValue != NULL && $this->legalstructure->FormValue == "") {
				AddMessage($FormError, str_replace("%s", $this->legalstructure->caption(), $this->legalstructure->RequiredErrorMessage));
			}
		}
		if ($this->extendedfields->Required) {
			if (!$this->extendedfields->IsDetailKey && $this->extendedfields->FormValue != NULL && $this->extendedfields->FormValue == "") {
				AddMessage($FormError, str_replace("%s", $this->extendedfields->caption(), $this->extendedfields->RequiredErrorMessage));
			}
		}

		// Validate detail grid
		$detailTblVar = explode(",", $this->getCurrentDetailTable());
		if (in_array("billinggroupbrokers", $detailTblVar) && $GLOBALS["billinggroupbrokers"]->DetailAdd) {
			if (!isset($GLOBALS["billinggroupbrokers_grid"]))
				$GLOBALS["billinggroupbrokers_grid"] = new billinggroupbrokers_grid(); // Get detail page object
			$GLOBALS["billinggroupbrokers_grid"]->validateGridForm();
		}
		if (in_array("billingservicebrokers", $detailTblVar) && $GLOBALS["billingservicebrokers"]->DetailAdd) {
			if (!isset($GLOBALS["billingservicebrokers_grid"]))
				$GLOBALS["billingservicebrokers_grid"] = new billingservicebrokers_grid(); // Get detail page object
			$GLOBALS["billingservicebrokers_grid"]->validateGridForm();
		}
		if (in_array("merchantgp", $detailTblVar) && $GLOBALS["merchantgp"]->DetailAdd) {
			if (!isset($GLOBALS["merchantgp_grid"]))
				$GLOBALS["merchantgp_grid"] = new merchantgp_grid(); // Get detail page object
			$GLOBALS["merchantgp_grid"]->validateGridForm();
		}
		if (in_array("merchantpi", $detailTblVar) && $GLOBALS["merchantpi"]->DetailAdd) {
			if (!isset($GLOBALS["merchantpi_grid"]))
				$GLOBALS["merchantpi_grid"] = new merchantpi_grid(); // Get detail page object
			$GLOBALS["merchantpi_grid"]->validateGridForm();
		}
		if (in_array("merchantpassivebridge", $detailTblVar) && $GLOBALS["merchantpassivebridge"]->DetailAdd) {
			if (!isset($GLOBALS["merchantpassivebridge_grid"]))
				$GLOBALS["merchantpassivebridge_grid"] = new merchantpassivebridge_grid(); // Get detail page object
			$GLOBALS["merchantpassivebridge_grid"]->validateGridForm();
		}
		if (in_array("merchantthreshold", $detailTblVar) && $GLOBALS["merchantthreshold"]->DetailAdd) {
			if (!isset($GLOBALS["merchantthreshold_grid"]))
				$GLOBALS["merchantthreshold_grid"] = new merchantthreshold_grid(); // Get detail page object
			$GLOBALS["merchantthreshold_grid"]->validateGridForm();
		}
		if (in_array("merchantremmitance", $detailTblVar) && $GLOBALS["merchantremmitance"]->DetailAdd) {
			if (!isset($GLOBALS["merchantremmitance_grid"]))
				$GLOBALS["merchantremmitance_grid"] = new merchantremmitance_grid(); // Get detail page object
			$GLOBALS["merchantremmitance_grid"]->validateGridForm();
		}
		if (in_array("merchantsales", $detailTblVar) && $GLOBALS["merchantsales"]->DetailAdd) {
			if (!isset($GLOBALS["merchantsales_grid"]))
				$GLOBALS["merchantsales_grid"] = new merchantsales_grid(); // Get detail page object
			$GLOBALS["merchantsales_grid"]->validateGridForm();
		}
		if (in_array("merchantkycdocs", $detailTblVar) && $GLOBALS["merchantkycdocs"]->DetailAdd) {
			if (!isset($GLOBALS["merchantkycdocs_grid"]))
				$GLOBALS["merchantkycdocs_grid"] = new merchantkycdocs_grid(); // Get detail page object
			$GLOBALS["merchantkycdocs_grid"]->validateGridForm();
		}

		// Return validate result
		$validateForm = ($FormError == "");

		// Call Form_CustomValidate event
		$formCustomError = "";
		$validateForm = $validateForm && $this->Form_CustomValidate($formCustomError);
		if ($formCustomError != "") {
			AddMessage($FormError, $formCustomError);
		}
		return $validateForm;
	}

	// Add record
	protected function addRow($rsold = NULL)
	{
		global $Language, $Security;
		$conn = $this->getConnection();

		// Begin transaction
		if ($this->getCurrentDetailTable() != "")
			$conn->beginTrans();

		// Load db values from rsold
		$this->loadDbValues($rsold);
		if ($rsold) {
		}
		$rsnew = [];

		// userid
		$this->_userid->setDbValueDef($rsnew, $this->_userid->CurrentValue, 0, FALSE);

		// businessname
		$this->businessname->setDbValueDef($rsnew, $this->businessname->CurrentValue, "", FALSE);

		// officialname
		$this->officialname->setDbValueDef($rsnew, $this->officialname->CurrentValue, NULL, FALSE);

		// changed
		$this->changed->setDbValueDef($rsnew, $this->changed->CurrentValue, 0, strval($this->changed->CurrentValue) == "");

		// active
		$this->active->setDbValueDef($rsnew, $this->active->CurrentValue, 0, FALSE);

		// tipallowed
		$this->tipallowed->setDbValueDef($rsnew, $this->tipallowed->CurrentValue, 0, strval($this->tipallowed->CurrentValue) == "");

		// merchanttoaddtip
		$this->merchanttoaddtip->setDbValueDef($rsnew, $this->merchanttoaddtip->CurrentValue, 0, strval($this->merchanttoaddtip->CurrentValue) == "");

		// pis
		$this->pis->setDbValueDef($rsnew, $this->pis->CurrentValue, NULL, FALSE);

		// ratetableid
		$this->ratetableid->setDbValueDef($rsnew, $this->ratetableid->CurrentValue, 0, FALSE);

		// ratetabletype
		$this->ratetabletype->setDbValueDef($rsnew, $this->ratetabletype->CurrentValue, 0, FALSE);

		// officialdocnumber
		$this->officialdocnumber->setDbValueDef($rsnew, $this->officialdocnumber->CurrentValue, NULL, FALSE);

		// officialdocname
		$this->officialdocname->setDbValueDef($rsnew, $this->officialdocname->CurrentValue, NULL, FALSE);

		// softposid
		$this->softposid->setDbValueDef($rsnew, $this->softposid->CurrentValue, NULL, FALSE);

		// taxamount
		$this->taxamount->setDbValueDef($rsnew, $this->taxamount->CurrentValue, 0, strval($this->taxamount->CurrentValue) == "");

		// variabletax
		$this->variabletax->setDbValueDef($rsnew, $this->variabletax->CurrentValue, 0, strval($this->variabletax->CurrentValue) == "");

		// logofilename
		$this->logofilename->setDbValueDef($rsnew, $this->logofilename->CurrentValue, "", strval($this->logofilename->CurrentValue) == "");

		// returndays
		$this->returndays->setDbValueDef($rsnew, $this->returndays->CurrentValue, 0, strval($this->returndays->CurrentValue) == "");

		// memberextrafieldsid
		$this->memberextrafieldsid->setDbValueDef($rsnew, $this->memberextrafieldsid->CurrentValue, NULL, FALSE);

		// lastupdatedate
		$this->lastupdatedate->setDbValueDef($rsnew, UnFormatDateTime($this->lastupdatedate->CurrentValue, 0), CurrentDate(), FALSE);

		// remmitancetype
		$this->remmitancetype->setDbValueDef($rsnew, $this->remmitancetype->CurrentValue, 0, strval($this->remmitancetype->CurrentValue) == "");

		// withholdingtaxaccount
		$this->withholdingtaxaccount->setDbValueDef($rsnew, $this->withholdingtaxaccount->CurrentValue, 0, strval($this->withholdingtaxaccount->CurrentValue) == "");

		// businessphoneno
		$this->businessphoneno->setDbValueDef($rsnew, $this->businessphoneno->CurrentValue, NULL, FALSE);

		// businessaddress1
		$this->businessaddress1->setDbValueDef($rsnew, $this->businessaddress1->CurrentValue, NULL, FALSE);

		// businessaddress2
		$this->businessaddress2->setDbValueDef($rsnew, $this->businessaddress2->CurrentValue, NULL, FALSE);

		// businesscity
		$this->businesscity->setDbValueDef($rsnew, $this->businesscity->CurrentValue, NULL, FALSE);

		// businesscountry
		$this->businesscountry->setDbValueDef($rsnew, $this->businesscountry->CurrentValue, NULL, FALSE);

		// businessstate
		$this->businessstate->setDbValueDef($rsnew, $this->businessstate->CurrentValue, NULL, FALSE);

		// businesszipcode
		$this->businesszipcode->setDbValueDef($rsnew, $this->businesszipcode->CurrentValue, NULL, FALSE);

		// bankname
		$this->bankname->setDbValueDef($rsnew, $this->bankname->CurrentValue, NULL, FALSE);

		// bankbranchnumber
		$this->bankbranchnumber->setDbValueDef($rsnew, $this->bankbranchnumber->CurrentValue, NULL, FALSE);

		// bankaccountnumber
		$this->bankaccountnumber->setDbValueDef($rsnew, $this->bankaccountnumber->CurrentValue, NULL, FALSE);

		// other1
		$this->other1->setDbValueDef($rsnew, $this->other1->CurrentValue, NULL, FALSE);

		// other2
		$this->other2->setDbValueDef($rsnew, $this->other2->CurrentValue, NULL, FALSE);

		// other3
		$this->other3->setDbValueDef($rsnew, $this->other3->CurrentValue, NULL, FALSE);

		// externalid
		$this->externalid->setDbValueDef($rsnew, $this->externalid->CurrentValue, NULL, FALSE);

		// couponpin
		$this->couponpin->setDbValueDef($rsnew, $this->couponpin->CurrentValue, NULL, FALSE);

		// swiftcode
		$this->swiftcode->setDbValueDef($rsnew, $this->swiftcode->CurrentValue, NULL, FALSE);

		// profilevalidated
		$this->profilevalidated->setDbValueDef($rsnew, $this->profilevalidated->CurrentValue, 0, strval($this->profilevalidated->CurrentValue) == "");

		// profilevalidationdate
		$this->profilevalidationdate->setDbValueDef($rsnew, UnFormatDateTime($this->profilevalidationdate->CurrentValue, 0), NULL, FALSE);

		// industry
		$this->industry->setDbValueDef($rsnew, $this->industry->CurrentValue, NULL, FALSE);

		// legalstructure
		$this->legalstructure->setDbValueDef($rsnew, $this->legalstructure->CurrentValue, NULL, FALSE);

		// extendedfields
		$this->extendedfields->setDbValueDef($rsnew, $this->extendedfields->CurrentValue, NULL, FALSE);

		// Call Row Inserting event
		$rs = ($rsold) ? $rsold->fields : NULL;
		$insertRow = $this->Row_Inserting($rs, $rsnew);

		// Check if key value entered
		if ($insertRow && $this->ValidateKey && strval($rsnew['userid']) == "") {
			$this->setFailureMessage($Language->phrase("InvalidKeyValue"));
			$insertRow = FALSE;
		}

		// Check for duplicate key
		if ($insertRow && $this->ValidateKey) {
			$filter = $this->getRecordFilter($rsnew);
			$rsChk = $this->loadRs($filter);
			if ($rsChk && !$rsChk->EOF) {
				$keyErrMsg = str_replace("%f", $filter, $Language->phrase("DupKey"));
				$this->setFailureMessage($keyErrMsg);
				$rsChk->close();
				$insertRow = FALSE;
			}
		}
		if ($insertRow) {
			$conn->raiseErrorFn = Config("ERROR_FUNC");
			$addRow = $this->insert($rsnew);
			$conn->raiseErrorFn = "";
			if ($addRow) {
			}
		} else {
			if ($this->getSuccessMessage() != "" || $this->getFailureMessage() != "") {

				// Use the message, do nothing
			} elseif ($this->CancelMessage != "") {
				$this->setFailureMessage($this->CancelMessage);
				$this->CancelMessage = "";
			} else {
				$this->setFailureMessage($Language->phrase("InsertCancelled"));
			}
			$addRow = FALSE;
		}

		// Add detail records
		if ($addRow) {
			$detailTblVar = explode(",", $this->getCurrentDetailTable());
			if (in_array("billinggroupbrokers", $detailTblVar) && $GLOBALS["billinggroupbrokers"]->DetailAdd) {
				$GLOBALS["billinggroupbrokers"]->brokeruserid->setSessionValue($this->_userid->CurrentValue); // Set master key
				if (!isset($GLOBALS["billinggroupbrokers_grid"]))
					$GLOBALS["billinggroupbrokers_grid"] = new billinggroupbrokers_grid(); // Get detail page object
				$Security->loadCurrentUserLevel($this->ProjectID . "billinggroupbrokers"); // Load user level of detail table
				$addRow = $GLOBALS["billinggroupbrokers_grid"]->gridInsert();
				$Security->loadCurrentUserLevel($this->ProjectID . $this->TableName); // Restore user level of master table
				if (!$addRow) {
					$GLOBALS["billinggroupbrokers"]->brokeruserid->setSessionValue(""); // Clear master key if insert failed
				}
			}
			if (in_array("billingservicebrokers", $detailTblVar) && $GLOBALS["billingservicebrokers"]->DetailAdd) {
				$GLOBALS["billingservicebrokers"]->brokeruserid->setSessionValue($this->_userid->CurrentValue); // Set master key
				if (!isset($GLOBALS["billingservicebrokers_grid"]))
					$GLOBALS["billingservicebrokers_grid"] = new billingservicebrokers_grid(); // Get detail page object
				$Security->loadCurrentUserLevel($this->ProjectID . "billingservicebrokers"); // Load user level of detail table
				$addRow = $GLOBALS["billingservicebrokers_grid"]->gridInsert();
				$Security->loadCurrentUserLevel($this->ProjectID . $this->TableName); // Restore user level of master table
				if (!$addRow) {
					$GLOBALS["billingservicebrokers"]->brokeruserid->setSessionValue(""); // Clear master key if insert failed
				}
			}
			if (in_array("merchantgp", $detailTblVar) && $GLOBALS["merchantgp"]->DetailAdd) {
				$GLOBALS["merchantgp"]->_userid->setSessionValue($this->_userid->CurrentValue); // Set master key
				if (!isset($GLOBALS["merchantgp_grid"]))
					$GLOBALS["merchantgp_grid"] = new merchantgp_grid(); // Get detail page object
				$Security->loadCurrentUserLevel($this->ProjectID . "merchantgp"); // Load user level of detail table
				$addRow = $GLOBALS["merchantgp_grid"]->gridInsert();
				$Security->loadCurrentUserLevel($this->ProjectID . $this->TableName); // Restore user level of master table
				if (!$addRow) {
					$GLOBALS["merchantgp"]->_userid->setSessionValue(""); // Clear master key if insert failed
				}
			}
			if (in_array("merchantpi", $detailTblVar) && $GLOBALS["merchantpi"]->DetailAdd) {
				$GLOBALS["merchantpi"]->_userid->setSessionValue($this->_userid->CurrentValue); // Set master key
				if (!isset($GLOBALS["merchantpi_grid"]))
					$GLOBALS["merchantpi_grid"] = new merchantpi_grid(); // Get detail page object
				$Security->loadCurrentUserLevel($this->ProjectID . "merchantpi"); // Load user level of detail table
				$addRow = $GLOBALS["merchantpi_grid"]->gridInsert();
				$Security->loadCurrentUserLevel($this->ProjectID . $this->TableName); // Restore user level of master table
				if (!$addRow) {
					$GLOBALS["merchantpi"]->_userid->setSessionValue(""); // Clear master key if insert failed
				}
			}
			if (in_array("merchantpassivebridge", $detailTblVar) && $GLOBALS["merchantpassivebridge"]->DetailAdd) {
				$GLOBALS["merchantpassivebridge"]->merchantid->setSessionValue($this->_userid->CurrentValue); // Set master key
				if (!isset($GLOBALS["merchantpassivebridge_grid"]))
					$GLOBALS["merchantpassivebridge_grid"] = new merchantpassivebridge_grid(); // Get detail page object
				$Security->loadCurrentUserLevel($this->ProjectID . "merchantpassivebridge"); // Load user level of detail table
				$addRow = $GLOBALS["merchantpassivebridge_grid"]->gridInsert();
				$Security->loadCurrentUserLevel($this->ProjectID . $this->TableName); // Restore user level of master table
				if (!$addRow) {
					$GLOBALS["merchantpassivebridge"]->merchantid->setSessionValue(""); // Clear master key if insert failed
				}
			}
			if (in_array("merchantthreshold", $detailTblVar) && $GLOBALS["merchantthreshold"]->DetailAdd) {
				$GLOBALS["merchantthreshold"]->_userid->setSessionValue($this->_userid->CurrentValue); // Set master key
				if (!isset($GLOBALS["merchantthreshold_grid"]))
					$GLOBALS["merchantthreshold_grid"] = new merchantthreshold_grid(); // Get detail page object
				$Security->loadCurrentUserLevel($this->ProjectID . "merchantthreshold"); // Load user level of detail table
				$addRow = $GLOBALS["merchantthreshold_grid"]->gridInsert();
				$Security->loadCurrentUserLevel($this->ProjectID . $this->TableName); // Restore user level of master table
				if (!$addRow) {
					$GLOBALS["merchantthreshold"]->_userid->setSessionValue(""); // Clear master key if insert failed
				}
			}
			if (in_array("merchantremmitance", $detailTblVar) && $GLOBALS["merchantremmitance"]->DetailAdd) {
				$GLOBALS["merchantremmitance"]->_userid->setSessionValue($this->_userid->CurrentValue); // Set master key
				if (!isset($GLOBALS["merchantremmitance_grid"]))
					$GLOBALS["merchantremmitance_grid"] = new merchantremmitance_grid(); // Get detail page object
				$Security->loadCurrentUserLevel($this->ProjectID . "merchantremmitance"); // Load user level of detail table
				$addRow = $GLOBALS["merchantremmitance_grid"]->gridInsert();
				$Security->loadCurrentUserLevel($this->ProjectID . $this->TableName); // Restore user level of master table
				if (!$addRow) {
					$GLOBALS["merchantremmitance"]->_userid->setSessionValue(""); // Clear master key if insert failed
				}
			}
			if (in_array("merchantsales", $detailTblVar) && $GLOBALS["merchantsales"]->DetailAdd) {
				$GLOBALS["merchantsales"]->merchantID->setSessionValue($this->_userid->CurrentValue); // Set master key
				if (!isset($GLOBALS["merchantsales_grid"]))
					$GLOBALS["merchantsales_grid"] = new merchantsales_grid(); // Get detail page object
				$Security->loadCurrentUserLevel($this->ProjectID . "merchantsales"); // Load user level of detail table
				$addRow = $GLOBALS["merchantsales_grid"]->gridInsert();
				$Security->loadCurrentUserLevel($this->ProjectID . $this->TableName); // Restore user level of master table
				if (!$addRow) {
					$GLOBALS["merchantsales"]->merchantID->setSessionValue(""); // Clear master key if insert failed
				}
			}
			if (in_array("merchantkycdocs", $detailTblVar) && $GLOBALS["merchantkycdocs"]->DetailAdd) {
				$GLOBALS["merchantkycdocs"]->_userid->setSessionValue($this->_userid->CurrentValue); // Set master key
				if (!isset($GLOBALS["merchantkycdocs_grid"]))
					$GLOBALS["merchantkycdocs_grid"] = new merchantkycdocs_grid(); // Get detail page object
				$Security->loadCurrentUserLevel($this->ProjectID . "merchantkycdocs"); // Load user level of detail table
				$addRow = $GLOBALS["merchantkycdocs_grid"]->gridInsert();
				$Security->loadCurrentUserLevel($this->ProjectID . $this->TableName); // Restore user level of master table
				if (!$addRow) {
					$GLOBALS["merchantkycdocs"]->_userid->setSessionValue(""); // Clear master key if insert failed
				}
			}
		}

		// Commit/Rollback transaction
		if ($this->getCurrentDetailTable() != "") {
			if ($addRow) {
				$conn->commitTrans(); // Commit transaction
			} else {
				$conn->rollbackTrans(); // Rollback transaction
			}
		}
		if ($addRow) {

			// Call Row Inserted event
			$rs = ($rsold) ? $rsold->fields : NULL;
			$this->Row_Inserted($rs, $rsnew);
		}

		// Clean upload path if any
		if ($addRow) {
		}

		// Write JSON for API request
		if (IsApi() && $addRow) {
			$row = $this->getRecordsFromRecordset([$rsnew], TRUE);
			WriteJson(["success" => TRUE, $this->TableVar => $row]);
		}
		return $addRow;
	}

	// Set up detail parms based on QueryString
	protected function setupDetailParms()
	{

		// Get the keys for master table
		$detailTblVar = Get(Config("TABLE_SHOW_DETAIL"));
		if ($detailTblVar !== NULL) {
			$this->setCurrentDetailTable($detailTblVar);
		} else {
			$detailTblVar = $this->getCurrentDetailTable();
		}
		if ($detailTblVar != "") {
			$detailTblVar = explode(",", $detailTblVar);
			if (in_array("billinggroupbrokers", $detailTblVar)) {
				if (!isset($GLOBALS["billinggroupbrokers_grid"]))
					$GLOBALS["billinggroupbrokers_grid"] = new billinggroupbrokers_grid();
				if ($GLOBALS["billinggroupbrokers_grid"]->DetailAdd) {
					if ($this->CopyRecord)
						$GLOBALS["billinggroupbrokers_grid"]->CurrentMode = "copy";
					else
						$GLOBALS["billinggroupbrokers_grid"]->CurrentMode = "add";
					$GLOBALS["billinggroupbrokers_grid"]->CurrentAction = "gridadd";

					// Save current master table to detail table
					$GLOBALS["billinggroupbrokers_grid"]->setCurrentMasterTable($this->TableVar);
					$GLOBALS["billinggroupbrokers_grid"]->setStartRecordNumber(1);
					$GLOBALS["billinggroupbrokers_grid"]->brokeruserid->IsDetailKey = TRUE;
					$GLOBALS["billinggroupbrokers_grid"]->brokeruserid->CurrentValue = $this->_userid->CurrentValue;
					$GLOBALS["billinggroupbrokers_grid"]->brokeruserid->setSessionValue($GLOBALS["billinggroupbrokers_grid"]->brokeruserid->CurrentValue);
				}
			}
			if (in_array("billingservicebrokers", $detailTblVar)) {
				if (!isset($GLOBALS["billingservicebrokers_grid"]))
					$GLOBALS["billingservicebrokers_grid"] = new billingservicebrokers_grid();
				if ($GLOBALS["billingservicebrokers_grid"]->DetailAdd) {
					if ($this->CopyRecord)
						$GLOBALS["billingservicebrokers_grid"]->CurrentMode = "copy";
					else
						$GLOBALS["billingservicebrokers_grid"]->CurrentMode = "add";
					$GLOBALS["billingservicebrokers_grid"]->CurrentAction = "gridadd";

					// Save current master table to detail table
					$GLOBALS["billingservicebrokers_grid"]->setCurrentMasterTable($this->TableVar);
					$GLOBALS["billingservicebrokers_grid"]->setStartRecordNumber(1);
					$GLOBALS["billingservicebrokers_grid"]->brokeruserid->IsDetailKey = TRUE;
					$GLOBALS["billingservicebrokers_grid"]->brokeruserid->CurrentValue = $this->_userid->CurrentValue;
					$GLOBALS["billingservicebrokers_grid"]->brokeruserid->setSessionValue($GLOBALS["billingservicebrokers_grid"]->brokeruserid->CurrentValue);
				}
			}
			if (in_array("merchantgp", $detailTblVar)) {
				if (!isset($GLOBALS["merchantgp_grid"]))
					$GLOBALS["merchantgp_grid"] = new merchantgp_grid();
				if ($GLOBALS["merchantgp_grid"]->DetailAdd) {
					if ($this->CopyRecord)
						$GLOBALS["merchantgp_grid"]->CurrentMode = "copy";
					else
						$GLOBALS["merchantgp_grid"]->CurrentMode = "add";
					$GLOBALS["merchantgp_grid"]->CurrentAction = "gridadd";

					// Save current master table to detail table
					$GLOBALS["merchantgp_grid"]->setCurrentMasterTable($this->TableVar);
					$GLOBALS["merchantgp_grid"]->setStartRecordNumber(1);
					$GLOBALS["merchantgp_grid"]->_userid->IsDetailKey = TRUE;
					$GLOBALS["merchantgp_grid"]->_userid->CurrentValue = $this->_userid->CurrentValue;
					$GLOBALS["merchantgp_grid"]->_userid->setSessionValue($GLOBALS["merchantgp_grid"]->_userid->CurrentValue);
				}
			}
			if (in_array("merchantpi", $detailTblVar)) {
				if (!isset($GLOBALS["merchantpi_grid"]))
					$GLOBALS["merchantpi_grid"] = new merchantpi_grid();
				if ($GLOBALS["merchantpi_grid"]->DetailAdd) {
					if ($this->CopyRecord)
						$GLOBALS["merchantpi_grid"]->CurrentMode = "copy";
					else
						$GLOBALS["merchantpi_grid"]->CurrentMode = "add";
					$GLOBALS["merchantpi_grid"]->CurrentAction = "gridadd";

					// Save current master table to detail table
					$GLOBALS["merchantpi_grid"]->setCurrentMasterTable($this->TableVar);
					$GLOBALS["merchantpi_grid"]->setStartRecordNumber(1);
					$GLOBALS["merchantpi_grid"]->_userid->IsDetailKey = TRUE;
					$GLOBALS["merchantpi_grid"]->_userid->CurrentValue = $this->_userid->CurrentValue;
					$GLOBALS["merchantpi_grid"]->_userid->setSessionValue($GLOBALS["merchantpi_grid"]->_userid->CurrentValue);
					$GLOBALS["merchantpi_grid"]->gatewayid->setSessionValue(""); // Clear session key
				}
			}
			if (in_array("merchantpassivebridge", $detailTblVar)) {
				if (!isset($GLOBALS["merchantpassivebridge_grid"]))
					$GLOBALS["merchantpassivebridge_grid"] = new merchantpassivebridge_grid();
				if ($GLOBALS["merchantpassivebridge_grid"]->DetailAdd) {
					if ($this->CopyRecord)
						$GLOBALS["merchantpassivebridge_grid"]->CurrentMode = "copy";
					else
						$GLOBALS["merchantpassivebridge_grid"]->CurrentMode = "add";
					$GLOBALS["merchantpassivebridge_grid"]->CurrentAction = "gridadd";

					// Save current master table to detail table
					$GLOBALS["merchantpassivebridge_grid"]->setCurrentMasterTable($this->TableVar);
					$GLOBALS["merchantpassivebridge_grid"]->setStartRecordNumber(1);
					$GLOBALS["merchantpassivebridge_grid"]->merchantid->IsDetailKey = TRUE;
					$GLOBALS["merchantpassivebridge_grid"]->merchantid->CurrentValue = $this->_userid->CurrentValue;
					$GLOBALS["merchantpassivebridge_grid"]->merchantid->setSessionValue($GLOBALS["merchantpassivebridge_grid"]->merchantid->CurrentValue);
				}
			}
			if (in_array("merchantthreshold", $detailTblVar)) {
				if (!isset($GLOBALS["merchantthreshold_grid"]))
					$GLOBALS["merchantthreshold_grid"] = new merchantthreshold_grid();
				if ($GLOBALS["merchantthreshold_grid"]->DetailAdd) {
					if ($this->CopyRecord)
						$GLOBALS["merchantthreshold_grid"]->CurrentMode = "copy";
					else
						$GLOBALS["merchantthreshold_grid"]->CurrentMode = "add";
					$GLOBALS["merchantthreshold_grid"]->CurrentAction = "gridadd";

					// Save current master table to detail table
					$GLOBALS["merchantthreshold_grid"]->setCurrentMasterTable($this->TableVar);
					$GLOBALS["merchantthreshold_grid"]->setStartRecordNumber(1);
					$GLOBALS["merchantthreshold_grid"]->_userid->IsDetailKey = TRUE;
					$GLOBALS["merchantthreshold_grid"]->_userid->CurrentValue = $this->_userid->CurrentValue;
					$GLOBALS["merchantthreshold_grid"]->_userid->setSessionValue($GLOBALS["merchantthreshold_grid"]->_userid->CurrentValue);
				}
			}
			if (in_array("merchantremmitance", $detailTblVar)) {
				if (!isset($GLOBALS["merchantremmitance_grid"]))
					$GLOBALS["merchantremmitance_grid"] = new merchantremmitance_grid();
				if ($GLOBALS["merchantremmitance_grid"]->DetailAdd) {
					if ($this->CopyRecord)
						$GLOBALS["merchantremmitance_grid"]->CurrentMode = "copy";
					else
						$GLOBALS["merchantremmitance_grid"]->CurrentMode = "add";
					$GLOBALS["merchantremmitance_grid"]->CurrentAction = "gridadd";

					// Save current master table to detail table
					$GLOBALS["merchantremmitance_grid"]->setCurrentMasterTable($this->TableVar);
					$GLOBALS["merchantremmitance_grid"]->setStartRecordNumber(1);
					$GLOBALS["merchantremmitance_grid"]->_userid->IsDetailKey = TRUE;
					$GLOBALS["merchantremmitance_grid"]->_userid->CurrentValue = $this->_userid->CurrentValue;
					$GLOBALS["merchantremmitance_grid"]->_userid->setSessionValue($GLOBALS["merchantremmitance_grid"]->_userid->CurrentValue);
				}
			}
			if (in_array("merchantsales", $detailTblVar)) {
				if (!isset($GLOBALS["merchantsales_grid"]))
					$GLOBALS["merchantsales_grid"] = new merchantsales_grid();
				if ($GLOBALS["merchantsales_grid"]->DetailAdd) {
					if ($this->CopyRecord)
						$GLOBALS["merchantsales_grid"]->CurrentMode = "copy";
					else
						$GLOBALS["merchantsales_grid"]->CurrentMode = "add";
					$GLOBALS["merchantsales_grid"]->CurrentAction = "gridadd";

					// Save current master table to detail table
					$GLOBALS["merchantsales_grid"]->setCurrentMasterTable($this->TableVar);
					$GLOBALS["merchantsales_grid"]->setStartRecordNumber(1);
					$GLOBALS["merchantsales_grid"]->merchantID->IsDetailKey = TRUE;
					$GLOBALS["merchantsales_grid"]->merchantID->CurrentValue = $this->_userid->CurrentValue;
					$GLOBALS["merchantsales_grid"]->merchantID->setSessionValue($GLOBALS["merchantsales_grid"]->merchantID->CurrentValue);
				}
			}
			if (in_array("merchantkycdocs", $detailTblVar)) {
				if (!isset($GLOBALS["merchantkycdocs_grid"]))
					$GLOBALS["merchantkycdocs_grid"] = new merchantkycdocs_grid();
				if ($GLOBALS["merchantkycdocs_grid"]->DetailAdd) {
					if ($this->CopyRecord)
						$GLOBALS["merchantkycdocs_grid"]->CurrentMode = "copy";
					else
						$GLOBALS["merchantkycdocs_grid"]->CurrentMode = "add";
					$GLOBALS["merchantkycdocs_grid"]->CurrentAction = "gridadd";

					// Save current master table to detail table
					$GLOBALS["merchantkycdocs_grid"]->setCurrentMasterTable($this->TableVar);
					$GLOBALS["merchantkycdocs_grid"]->setStartRecordNumber(1);
					$GLOBALS["merchantkycdocs_grid"]->_userid->IsDetailKey = TRUE;
					$GLOBALS["merchantkycdocs_grid"]->_userid->CurrentValue = $this->_userid->CurrentValue;
					$GLOBALS["merchantkycdocs_grid"]->_userid->setSessionValue($GLOBALS["merchantkycdocs_grid"]->_userid->CurrentValue);
				}
			}
		}
	}

	// Set up Breadcrumb
	protected function setupBreadcrumb()
	{
		global $Breadcrumb, $Language;
		$Breadcrumb = new Breadcrumb();
		$url = substr(CurrentUrl(), strrpos(CurrentUrl(), "/")+1);
		$Breadcrumb->add("list", $this->TableVar, $this->addMasterUrl("merchantlist.php"), "", $this->TableVar, TRUE);
		$pageId = ($this->isCopy()) ? "Copy" : "Add";
		$Breadcrumb->add("add", $pageId, $url);
	}

	// Set up multi pages
	protected function setupMultiPages()
	{
		$pages = new SubPages();
		$pages->Style = "tabs";
		$pages->add(0);
		$pages->add(1);
		$pages->add(2);
		$this->MultiPages = $pages;
	}

	// Set up detail pages
	protected function setupDetailPages()
	{
		$pages = new SubPages();
		$pages->Style = "tabs";
		$pages->add('billinggroupbrokers');
		$pages->add('billingservicebrokers');
		$pages->add('merchantgp');
		$pages->add('merchantpi');
		$pages->add('merchantpassivebridge');
		$pages->add('merchantthreshold');
		$pages->add('merchantremmitance');
		$pages->add('merchantsales');
		$pages->add('merchantkycdocs');
		$this->DetailPages = $pages;
	}

	// Setup lookup options
	public function setupLookupOptions($fld)
	{
		if ($fld->Lookup !== NULL && $fld->Lookup->Options === NULL) {

			// Get default connection and filter
			$conn = $this->getConnection();
			$lookupFilter = "";

			// No need to check any more
			$fld->Lookup->Options = [];

			// Set up lookup SQL and connection
			switch ($fld->FieldVar) {
				case "x_changed":
					break;
				case "x_active":
					break;
				case "x_tipallowed":
					break;
				case "x_merchanttoaddtip":
					break;
				case "x_ratetabletype":
					break;
				case "x_variabletax":
					break;
				case "x_remmitancetype":
					break;
				case "x_businesscountry":
					$conn = Conn("_4payreference");
					break;
				case "x_businessstate":
					$conn = Conn("_4payreference");
					break;
				case "x_profilevalidated":
					$lookupFilter = function() {
						return "`langID` = 'EN'";
					};
					$lookupFilter = $lookupFilter->bindTo($this);
					break;
				case "x_industry":
					$conn = Conn("_4payreference");
					break;
				case "x_legalstructure":
					$conn = Conn("_4payreference");
					break;
				default:
					$lookupFilter = "";
					break;
			}

			// Always call to Lookup->getSql so that user can setup Lookup->Options in Lookup_Selecting server event
			$sql = $fld->Lookup->getSql(FALSE, "", $lookupFilter, $this);

			// Set up lookup cache
			if ($fld->UseLookupCache && $sql != "" && count($fld->Lookup->Options) == 0) {
				$totalCnt = $this->getRecordCount($sql, $conn);
				if ($totalCnt > $fld->LookupCacheCount) // Total count > cache count, do not cache
					return;
				$rs = $conn->execute($sql);
				$ar = [];
				while ($rs && !$rs->EOF) {
					$row = &$rs->fields;

					// Format the field values
					switch ($fld->FieldVar) {
						case "x_changed":
							break;
						case "x_active":
							break;
						case "x_tipallowed":
							break;
						case "x_merchanttoaddtip":
							break;
						case "x_ratetabletype":
							break;
						case "x_variabletax":
							break;
						case "x_businesscountry":
							break;
						case "x_businessstate":
							break;
						case "x_profilevalidated":
							break;
						case "x_industry":
							break;
						case "x_legalstructure":
							break;
					}
					$ar[strval($row[0])] = $row;
					$rs->moveNext();
				}
				if ($rs)
					$rs->close();
				$fld->Lookup->Options = $ar;
			}
		}
	}

	// Page Load event
	function Page_Load() {

		//echo "Page Load";
	}

	// Page Unload event
	function Page_Unload() {

		//echo "Page Unload";
	}

	// Page Redirecting event
	function Page_Redirecting(&$url) {

		// Example:
		//$url = "your URL";

	}

	// Message Showing event
	// $type = ''|'success'|'failure'|'warning'
	function Message_Showing(&$msg, $type) {
		if ($type == 'success') {

			//$msg = "your success message";
		} elseif ($type == 'failure') {

			//$msg = "your failure message";
		} elseif ($type == 'warning') {

			//$msg = "your warning message";
		} else {

			//$msg = "your message";
		}
	}

	// Page Render event
	function Page_Render() {

		//echo "Page Render";
	}

	// Page Data Rendering event
	function Page_DataRendering(&$header) {

		// Example:
		//$header = "your header";

	}

	// Page Data Rendered event
	function Page_DataRendered(&$footer) {

		// Example:
		//$footer = "your footer";

	}

	// Form Custom Validate event
	function Form_CustomValidate(&$customError) {

		// Return error message in CustomError
		return TRUE;
	}
} // End class
?>