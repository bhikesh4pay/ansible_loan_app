<?php namespace PHPMaker2020\_4payadmin; ?>
<?php

/**
 * Table class for userpurchase
 */
class userpurchase extends DbTable
{
	protected $SqlFrom = "";
	protected $SqlSelect = "";
	protected $SqlSelectList = "";
	protected $SqlWhere = "";
	protected $SqlGroupBy = "";
	protected $SqlHaving = "";
	protected $SqlOrderBy = "";
	public $UseSessionForListSql = TRUE;

	// Column CSS classes
	public $LeftColumnClass = "col-sm-2 col-form-label ew-label";
	public $RightColumnClass = "col-sm-10";
	public $OffsetColumnClass = "col-sm-10 offset-sm-2";
	public $TableLeftColumnClass = "w-col-2";

	// Audit trail
	public $AuditTrailOnAdd = TRUE;
	public $AuditTrailOnEdit = TRUE;
	public $AuditTrailOnDelete = TRUE;
	public $AuditTrailOnView = FALSE;
	public $AuditTrailOnViewData = FALSE;
	public $AuditTrailOnSearch = FALSE;

	// Export
	public $ExportDoc;

	// Fields
	public $purchaseid;
	public $_userid;
	public $merchantnodeid;
	public $merchantid;
	public $merchantbusinessname;
	public $merchanttransferid;
	public $merchantuserid;
	public $purchasedate;
	public $txid;
	public $userpi;
	public $otherconfirmref;
	public $currencycode;
	public $purchaseamount;
	public $tipamount;
	public $merchantfees;
	public $consumerfees;
	public $transferid;
	public $merchantSurcharge;
	public $taxAmount;
	public $totalAmounForCustomer;
	public $feeid;
	public $ratetabletype;
	public $itemdesc;
	public $shoppingCartID;
	public $merchantRefID;
	public $refunded;
	public $tokenid;
	public $cardno;
	public $vaultid;
	public $refundrequested;
	public $refundrequesttxid;
	public $feesystemshare;
	public $feeexternalshare;
	public $feefranchiseeshare;
	public $feeresellershare;
	public $_key;
	public $serviceFeeToCustomerbk1amt;
	public $serviceFeeToCustomerbk1type;
	public $serviceFeeToCustomerbk2amt;
	public $serviceFeeToCustomerbk2type;
	public $serviceFeeToCustomerbk3amt;
	public $serviceFeeToCustomerbk3type;
	public $taxAmountbk1amt;
	public $taxAmountbk1type;
	public $taxAmountbk2amt;
	public $taxAmountbk2type;
	public $taxAmountbk3amt;
	public $taxAmountbk3type;
	public $originalpurchaseamount;
	public $discountamount;
	public $discountpercentage;
	public $txgroupid;
	public $success_status;
	public $error_msg;
	public $userpiid;
	public $notes;
	public $lastpurchasereaddate;
	public $retryapicount;

	// Constructor
	public function __construct()
	{
		global $Language, $CurrentLanguage;
		parent::__construct();

		// Language object
		if (!isset($Language))
			$Language = new Language();
		$this->TableVar = 'userpurchase';
		$this->TableName = 'userpurchase';
		$this->TableType = 'TABLE';

		// Update Table
		$this->UpdateTable = "`userpurchase`";
		$this->Dbid = 'DB';
		$this->ExportAll = TRUE;
		$this->ExportPageBreakCount = 0; // Page break per every n record (PDF only)
		$this->ExportPageOrientation = "portrait"; // Page orientation (PDF only)
		$this->ExportPageSize = "a4"; // Page size (PDF only)
		$this->ExportExcelPageOrientation = \PhpOffice\PhpSpreadsheet\Worksheet\PageSetup::ORIENTATION_DEFAULT; // Page orientation (PhpSpreadsheet only)
		$this->ExportExcelPageSize = \PhpOffice\PhpSpreadsheet\Worksheet\PageSetup::PAPERSIZE_A4; // Page size (PhpSpreadsheet only)
		$this->ExportWordPageOrientation = "portrait"; // Page orientation (PHPWord only)
		$this->ExportWordColumnWidth = NULL; // Cell width (PHPWord only)
		$this->DetailAdd = FALSE; // Allow detail add
		$this->DetailEdit = FALSE; // Allow detail edit
		$this->DetailView = TRUE; // Allow detail view
		$this->ShowMultipleDetails = FALSE; // Show multiple details
		$this->GridAddRowCount = 5;
		$this->AllowAddDeleteRow = TRUE; // Allow add/delete row
		$this->UserIDAllowSecurity = Config("DEFAULT_USER_ID_ALLOW_SECURITY"); // Default User ID allowed permissions
		$this->BasicSearch = new BasicSearch($this->TableVar);

		// purchaseid
		$this->purchaseid = new DbField('userpurchase', 'userpurchase', 'x_purchaseid', 'purchaseid', '`purchaseid`', '`purchaseid`', 3, 15, -1, FALSE, '`purchaseid`', FALSE, FALSE, FALSE, 'FORMATTED TEXT', 'NO');
		$this->purchaseid->IsAutoIncrement = TRUE; // Autoincrement field
		$this->purchaseid->IsPrimaryKey = TRUE; // Primary key field
		$this->purchaseid->IsForeignKey = TRUE; // Foreign key field
		$this->purchaseid->Sortable = TRUE; // Allow sort
		$this->purchaseid->DefaultErrorMessage = $Language->phrase("IncorrectInteger");
		$this->fields['purchaseid'] = &$this->purchaseid;

		// userid
		$this->_userid = new DbField('userpurchase', 'userpurchase', 'x__userid', 'userid', '`userid`', '`userid`', 3, 12, -1, FALSE, '`userid`', FALSE, FALSE, FALSE, 'FORMATTED TEXT', 'TEXT');
		$this->_userid->IsForeignKey = TRUE; // Foreign key field
		$this->_userid->Nullable = FALSE; // NOT NULL field
		$this->_userid->Required = TRUE; // Required field
		$this->_userid->Sortable = TRUE; // Allow sort
		$this->_userid->DefaultErrorMessage = $Language->phrase("IncorrectInteger");
		$this->fields['userid'] = &$this->_userid;

		// merchantnodeid
		$this->merchantnodeid = new DbField('userpurchase', 'userpurchase', 'x_merchantnodeid', 'merchantnodeid', '`merchantnodeid`', '`merchantnodeid`', 3, 5, -1, FALSE, '`merchantnodeid`', FALSE, FALSE, FALSE, 'FORMATTED TEXT', 'TEXT');
		$this->merchantnodeid->Nullable = FALSE; // NOT NULL field
		$this->merchantnodeid->Required = TRUE; // Required field
		$this->merchantnodeid->Sortable = TRUE; // Allow sort
		$this->merchantnodeid->DefaultErrorMessage = $Language->phrase("IncorrectInteger");
		$this->fields['merchantnodeid'] = &$this->merchantnodeid;

		// merchantid
		$this->merchantid = new DbField('userpurchase', 'userpurchase', 'x_merchantid', 'merchantid', '`merchantid`', '`merchantid`', 3, 12, -1, FALSE, '`merchantid`', FALSE, FALSE, FALSE, 'FORMATTED TEXT', 'TEXT');
		$this->merchantid->Nullable = FALSE; // NOT NULL field
		$this->merchantid->Required = TRUE; // Required field
		$this->merchantid->Sortable = TRUE; // Allow sort
		$this->merchantid->DefaultErrorMessage = $Language->phrase("IncorrectInteger");
		$this->fields['merchantid'] = &$this->merchantid;

		// merchantbusinessname
		$this->merchantbusinessname = new DbField('userpurchase', 'userpurchase', 'x_merchantbusinessname', 'merchantbusinessname', '`merchantbusinessname`', '`merchantbusinessname`', 200, 60, -1, FALSE, '`merchantbusinessname`', FALSE, FALSE, FALSE, 'FORMATTED TEXT', 'TEXT');
		$this->merchantbusinessname->Sortable = TRUE; // Allow sort
		$this->fields['merchantbusinessname'] = &$this->merchantbusinessname;

		// merchanttransferid
		$this->merchanttransferid = new DbField('userpurchase', 'userpurchase', 'x_merchanttransferid', 'merchanttransferid', '`merchanttransferid`', '`merchanttransferid`', 3, 12, -1, FALSE, '`merchanttransferid`', FALSE, FALSE, FALSE, 'FORMATTED TEXT', 'TEXT');
		$this->merchanttransferid->Nullable = FALSE; // NOT NULL field
		$this->merchanttransferid->Required = TRUE; // Required field
		$this->merchanttransferid->Sortable = TRUE; // Allow sort
		$this->merchanttransferid->DefaultErrorMessage = $Language->phrase("IncorrectInteger");
		$this->fields['merchanttransferid'] = &$this->merchanttransferid;

		// merchantuserid
		$this->merchantuserid = new DbField('userpurchase', 'userpurchase', 'x_merchantuserid', 'merchantuserid', '`merchantuserid`', '`merchantuserid`', 3, 12, -1, FALSE, '`merchantuserid`', FALSE, FALSE, FALSE, 'FORMATTED TEXT', 'TEXT');
		$this->merchantuserid->Nullable = FALSE; // NOT NULL field
		$this->merchantuserid->Required = TRUE; // Required field
		$this->merchantuserid->Sortable = TRUE; // Allow sort
		$this->merchantuserid->DefaultErrorMessage = $Language->phrase("IncorrectInteger");
		$this->fields['merchantuserid'] = &$this->merchantuserid;

		// purchasedate
		$this->purchasedate = new DbField('userpurchase', 'userpurchase', 'x_purchasedate', 'purchasedate', '`purchasedate`', CastDateFieldForLike("`purchasedate`", 1, "DB"), 135, 19, 1, FALSE, '`purchasedate`', FALSE, FALSE, FALSE, 'FORMATTED TEXT', 'TEXT');
		$this->purchasedate->Required = TRUE; // Required field
		$this->purchasedate->Sortable = TRUE; // Allow sort
		$this->purchasedate->DefaultErrorMessage = str_replace("%s", $GLOBALS["DATE_FORMAT"], $Language->phrase("IncorrectDate"));
		$this->fields['purchasedate'] = &$this->purchasedate;

		// txid
		$this->txid = new DbField('userpurchase', 'userpurchase', 'x_txid', 'txid', '`txid`', '`txid`', 200, 10, -1, FALSE, '`txid`', FALSE, FALSE, FALSE, 'FORMATTED TEXT', 'TEXT');
		$this->txid->Nullable = FALSE; // NOT NULL field
		$this->txid->Required = TRUE; // Required field
		$this->txid->Sortable = TRUE; // Allow sort
		$this->fields['txid'] = &$this->txid;

		// userpi
		$this->userpi = new DbField('userpurchase', 'userpurchase', 'x_userpi', 'userpi', '`userpi`', '`userpi`', 3, 12, -1, FALSE, '`userpi`', FALSE, FALSE, FALSE, 'FORMATTED TEXT', 'TEXT');
		$this->userpi->Nullable = FALSE; // NOT NULL field
		$this->userpi->Required = TRUE; // Required field
		$this->userpi->Sortable = TRUE; // Allow sort
		$this->userpi->Lookup = new Lookup('userpi', 'rpaymentinstrument', FALSE, 'id', ["id","name","",""], [], [], [], [], [], [], '', '');
		$this->userpi->DefaultErrorMessage = $Language->phrase("IncorrectInteger");
		$this->fields['userpi'] = &$this->userpi;

		// otherconfirmref
		$this->otherconfirmref = new DbField('userpurchase', 'userpurchase', 'x_otherconfirmref', 'otherconfirmref', '`otherconfirmref`', '`otherconfirmref`', 201, 1000, -1, FALSE, '`otherconfirmref`', FALSE, FALSE, FALSE, 'FORMATTED TEXT', 'TEXT');
		$this->otherconfirmref->Nullable = FALSE; // NOT NULL field
		$this->otherconfirmref->Required = TRUE; // Required field
		$this->otherconfirmref->Sortable = TRUE; // Allow sort
		$this->fields['otherconfirmref'] = &$this->otherconfirmref;

		// currencycode
		$this->currencycode = new DbField('userpurchase', 'userpurchase', 'x_currencycode', 'currencycode', '`currencycode`', '`currencycode`', 200, 3, -1, FALSE, '`currencycode`', FALSE, FALSE, FALSE, 'FORMATTED TEXT', 'TEXT');
		$this->currencycode->Sortable = TRUE; // Allow sort
		$this->fields['currencycode'] = &$this->currencycode;

		// purchaseamount
		$this->purchaseamount = new DbField('userpurchase', 'userpurchase', 'x_purchaseamount', 'purchaseamount', '`purchaseamount`', '`purchaseamount`', 5, 15, -1, FALSE, '`purchaseamount`', FALSE, FALSE, FALSE, 'FORMATTED TEXT', 'TEXT');
		$this->purchaseamount->Nullable = FALSE; // NOT NULL field
		$this->purchaseamount->Sortable = TRUE; // Allow sort
		$this->purchaseamount->DefaultErrorMessage = $Language->phrase("IncorrectFloat");
		$this->fields['purchaseamount'] = &$this->purchaseamount;

		// tipamount
		$this->tipamount = new DbField('userpurchase', 'userpurchase', 'x_tipamount', 'tipamount', '`tipamount`', '`tipamount`', 5, 15, -1, FALSE, '`tipamount`', FALSE, FALSE, FALSE, 'FORMATTED TEXT', 'TEXT');
		$this->tipamount->Nullable = FALSE; // NOT NULL field
		$this->tipamount->Required = TRUE; // Required field
		$this->tipamount->Sortable = TRUE; // Allow sort
		$this->tipamount->DefaultErrorMessage = $Language->phrase("IncorrectFloat");
		$this->fields['tipamount'] = &$this->tipamount;

		// merchantfees
		$this->merchantfees = new DbField('userpurchase', 'userpurchase', 'x_merchantfees', 'merchantfees', '`merchantfees`', '`merchantfees`', 5, 15, -1, FALSE, '`merchantfees`', FALSE, FALSE, FALSE, 'FORMATTED TEXT', 'TEXT');
		$this->merchantfees->Nullable = FALSE; // NOT NULL field
		$this->merchantfees->Required = TRUE; // Required field
		$this->merchantfees->Sortable = TRUE; // Allow sort
		$this->merchantfees->DefaultErrorMessage = $Language->phrase("IncorrectFloat");
		$this->fields['merchantfees'] = &$this->merchantfees;

		// consumerfees
		$this->consumerfees = new DbField('userpurchase', 'userpurchase', 'x_consumerfees', 'consumerfees', '`consumerfees`', '`consumerfees`', 5, 15, -1, FALSE, '`consumerfees`', FALSE, FALSE, FALSE, 'FORMATTED TEXT', 'TEXT');
		$this->consumerfees->Nullable = FALSE; // NOT NULL field
		$this->consumerfees->Required = TRUE; // Required field
		$this->consumerfees->Sortable = TRUE; // Allow sort
		$this->consumerfees->DefaultErrorMessage = $Language->phrase("IncorrectFloat");
		$this->fields['consumerfees'] = &$this->consumerfees;

		// transferid
		$this->transferid = new DbField('userpurchase', 'userpurchase', 'x_transferid', 'transferid', '`transferid`', '`transferid`', 3, 12, -1, FALSE, '`transferid`', FALSE, FALSE, FALSE, 'FORMATTED TEXT', 'TEXT');
		$this->transferid->Sortable = TRUE; // Allow sort
		$this->transferid->DefaultErrorMessage = $Language->phrase("IncorrectInteger");
		$this->fields['transferid'] = &$this->transferid;

		// merchantSurcharge
		$this->merchantSurcharge = new DbField('userpurchase', 'userpurchase', 'x_merchantSurcharge', 'merchantSurcharge', '`merchantSurcharge`', '`merchantSurcharge`', 131, 20, -1, FALSE, '`merchantSurcharge`', FALSE, FALSE, FALSE, 'FORMATTED TEXT', 'TEXT');
		$this->merchantSurcharge->Sortable = TRUE; // Allow sort
		$this->merchantSurcharge->DefaultErrorMessage = $Language->phrase("IncorrectFloat");
		$this->fields['merchantSurcharge'] = &$this->merchantSurcharge;

		// taxAmount
		$this->taxAmount = new DbField('userpurchase', 'userpurchase', 'x_taxAmount', 'taxAmount', '`taxAmount`', '`taxAmount`', 131, 20, -1, FALSE, '`taxAmount`', FALSE, FALSE, FALSE, 'FORMATTED TEXT', 'TEXT');
		$this->taxAmount->Sortable = TRUE; // Allow sort
		$this->taxAmount->DefaultErrorMessage = $Language->phrase("IncorrectFloat");
		$this->fields['taxAmount'] = &$this->taxAmount;

		// totalAmounForCustomer
		$this->totalAmounForCustomer = new DbField('userpurchase', 'userpurchase', 'x_totalAmounForCustomer', 'totalAmounForCustomer', '`totalAmounForCustomer`', '`totalAmounForCustomer`', 131, 20, -1, FALSE, '`totalAmounForCustomer`', FALSE, FALSE, FALSE, 'FORMATTED TEXT', 'TEXT');
		$this->totalAmounForCustomer->Sortable = TRUE; // Allow sort
		$this->totalAmounForCustomer->DefaultErrorMessage = $Language->phrase("IncorrectFloat");
		$this->fields['totalAmounForCustomer'] = &$this->totalAmounForCustomer;

		// feeid
		$this->feeid = new DbField('userpurchase', 'userpurchase', 'x_feeid', 'feeid', '`feeid`', '`feeid`', 3, 10, -1, FALSE, '`feeid`', FALSE, FALSE, FALSE, 'FORMATTED TEXT', 'TEXT');
		$this->feeid->Sortable = TRUE; // Allow sort
		$this->feeid->DefaultErrorMessage = $Language->phrase("IncorrectInteger");
		$this->fields['feeid'] = &$this->feeid;

		// ratetabletype
		$this->ratetabletype = new DbField('userpurchase', 'userpurchase', 'x_ratetabletype', 'ratetabletype', '`ratetabletype`', '`ratetabletype`', 3, 1, -1, FALSE, '`ratetabletype`', FALSE, FALSE, FALSE, 'FORMATTED TEXT', 'TEXT');
		$this->ratetabletype->Sortable = TRUE; // Allow sort
		$this->ratetabletype->DefaultErrorMessage = $Language->phrase("IncorrectInteger");
		$this->fields['ratetabletype'] = &$this->ratetabletype;

		// itemdesc
		$this->itemdesc = new DbField('userpurchase', 'userpurchase', 'x_itemdesc', 'itemdesc', '`itemdesc`', '`itemdesc`', 200, 100, -1, FALSE, '`itemdesc`', FALSE, FALSE, FALSE, 'FORMATTED TEXT', 'TEXT');
		$this->itemdesc->Sortable = TRUE; // Allow sort
		$this->fields['itemdesc'] = &$this->itemdesc;

		// shoppingCartID
		$this->shoppingCartID = new DbField('userpurchase', 'userpurchase', 'x_shoppingCartID', 'shoppingCartID', '`shoppingCartID`', '`shoppingCartID`', 200, 20, -1, FALSE, '`shoppingCartID`', FALSE, FALSE, FALSE, 'FORMATTED TEXT', 'TEXT');
		$this->shoppingCartID->Sortable = TRUE; // Allow sort
		$this->fields['shoppingCartID'] = &$this->shoppingCartID;

		// merchantRefID
		$this->merchantRefID = new DbField('userpurchase', 'userpurchase', 'x_merchantRefID', 'merchantRefID', '`merchantRefID`', '`merchantRefID`', 200, 30, -1, FALSE, '`merchantRefID`', FALSE, FALSE, FALSE, 'FORMATTED TEXT', 'TEXT');
		$this->merchantRefID->Sortable = TRUE; // Allow sort
		$this->fields['merchantRefID'] = &$this->merchantRefID;

		// refunded
		$this->refunded = new DbField('userpurchase', 'userpurchase', 'x_refunded', 'refunded', '`refunded`', '`refunded`', 3, 1, -1, FALSE, '`refunded`', FALSE, FALSE, FALSE, 'FORMATTED TEXT', 'SELECT');
		$this->refunded->Nullable = FALSE; // NOT NULL field
		$this->refunded->Required = TRUE; // Required field
		$this->refunded->Sortable = TRUE; // Allow sort
		$this->refunded->UsePleaseSelect = TRUE; // Use PleaseSelect by default
		$this->refunded->PleaseSelectText = $Language->phrase("PleaseSelect"); // "PleaseSelect" text
		$this->refunded->Lookup = new Lookup('refunded', 'userpurchase', FALSE, '', ["","","",""], [], [], [], [], [], [], '', '');
		$this->refunded->OptionCount = 3;
		$this->refunded->DefaultErrorMessage = $Language->phrase("IncorrectInteger");
		$this->fields['refunded'] = &$this->refunded;

		// tokenid
		$this->tokenid = new DbField('userpurchase', 'userpurchase', 'x_tokenid', 'tokenid', '`tokenid`', '`tokenid`', 200, 50, -1, FALSE, '`tokenid`', FALSE, FALSE, FALSE, 'FORMATTED TEXT', 'TEXT');
		$this->tokenid->Sortable = TRUE; // Allow sort
		$this->fields['tokenid'] = &$this->tokenid;

		// cardno
		$this->cardno = new DbField('userpurchase', 'userpurchase', 'x_cardno', 'cardno', '`cardno`', '`cardno`', 200, 4, -1, FALSE, '`cardno`', FALSE, FALSE, FALSE, 'FORMATTED TEXT', 'TEXT');
		$this->cardno->Sortable = TRUE; // Allow sort
		$this->fields['cardno'] = &$this->cardno;

		// vaultid
		$this->vaultid = new DbField('userpurchase', 'userpurchase', 'x_vaultid', 'vaultid', '`vaultid`', '`vaultid`', 3, 2, -1, FALSE, '`vaultid`', FALSE, FALSE, FALSE, 'FORMATTED TEXT', 'TEXT');
		$this->vaultid->Sortable = TRUE; // Allow sort
		$this->vaultid->DefaultErrorMessage = $Language->phrase("IncorrectInteger");
		$this->fields['vaultid'] = &$this->vaultid;

		// refundrequested
		$this->refundrequested = new DbField('userpurchase', 'userpurchase', 'x_refundrequested', 'refundrequested', '`refundrequested`', '`refundrequested`', 3, 1, -1, FALSE, '`refundrequested`', FALSE, FALSE, FALSE, 'FORMATTED TEXT', 'TEXT');
		$this->refundrequested->Nullable = FALSE; // NOT NULL field
		$this->refundrequested->Required = TRUE; // Required field
		$this->refundrequested->Sortable = TRUE; // Allow sort
		$this->refundrequested->DefaultErrorMessage = $Language->phrase("IncorrectInteger");
		$this->fields['refundrequested'] = &$this->refundrequested;

		// refundrequesttxid
		$this->refundrequesttxid = new DbField('userpurchase', 'userpurchase', 'x_refundrequesttxid', 'refundrequesttxid', '`refundrequesttxid`', '`refundrequesttxid`', 200, 9, -1, FALSE, '`refundrequesttxid`', FALSE, FALSE, FALSE, 'FORMATTED TEXT', 'TEXT');
		$this->refundrequesttxid->Sortable = TRUE; // Allow sort
		$this->fields['refundrequesttxid'] = &$this->refundrequesttxid;

		// feesystemshare
		$this->feesystemshare = new DbField('userpurchase', 'userpurchase', 'x_feesystemshare', 'feesystemshare', '`feesystemshare`', '`feesystemshare`', 131, 20, -1, FALSE, '`feesystemshare`', FALSE, FALSE, FALSE, 'FORMATTED TEXT', 'TEXT');
		$this->feesystemshare->Nullable = FALSE; // NOT NULL field
		$this->feesystemshare->Required = TRUE; // Required field
		$this->feesystemshare->Sortable = TRUE; // Allow sort
		$this->feesystemshare->DefaultErrorMessage = $Language->phrase("IncorrectFloat");
		$this->fields['feesystemshare'] = &$this->feesystemshare;

		// feeexternalshare
		$this->feeexternalshare = new DbField('userpurchase', 'userpurchase', 'x_feeexternalshare', 'feeexternalshare', '`feeexternalshare`', '`feeexternalshare`', 131, 20, -1, FALSE, '`feeexternalshare`', FALSE, FALSE, FALSE, 'FORMATTED TEXT', 'TEXT');
		$this->feeexternalshare->Nullable = FALSE; // NOT NULL field
		$this->feeexternalshare->Required = TRUE; // Required field
		$this->feeexternalshare->Sortable = TRUE; // Allow sort
		$this->feeexternalshare->DefaultErrorMessage = $Language->phrase("IncorrectFloat");
		$this->fields['feeexternalshare'] = &$this->feeexternalshare;

		// feefranchiseeshare
		$this->feefranchiseeshare = new DbField('userpurchase', 'userpurchase', 'x_feefranchiseeshare', 'feefranchiseeshare', '`feefranchiseeshare`', '`feefranchiseeshare`', 131, 20, -1, FALSE, '`feefranchiseeshare`', FALSE, FALSE, FALSE, 'FORMATTED TEXT', 'TEXT');
		$this->feefranchiseeshare->Nullable = FALSE; // NOT NULL field
		$this->feefranchiseeshare->Required = TRUE; // Required field
		$this->feefranchiseeshare->Sortable = TRUE; // Allow sort
		$this->feefranchiseeshare->DefaultErrorMessage = $Language->phrase("IncorrectFloat");
		$this->fields['feefranchiseeshare'] = &$this->feefranchiseeshare;

		// feeresellershare
		$this->feeresellershare = new DbField('userpurchase', 'userpurchase', 'x_feeresellershare', 'feeresellershare', '`feeresellershare`', '`feeresellershare`', 131, 20, -1, FALSE, '`feeresellershare`', FALSE, FALSE, FALSE, 'FORMATTED TEXT', 'TEXT');
		$this->feeresellershare->Nullable = FALSE; // NOT NULL field
		$this->feeresellershare->Required = TRUE; // Required field
		$this->feeresellershare->Sortable = TRUE; // Allow sort
		$this->feeresellershare->DefaultErrorMessage = $Language->phrase("IncorrectFloat");
		$this->fields['feeresellershare'] = &$this->feeresellershare;

		// key
		$this->_key = new DbField('userpurchase', 'userpurchase', 'x__key', 'key', '`key`', '`key`', 201, 1500, -1, FALSE, '`key`', FALSE, FALSE, FALSE, 'FORMATTED TEXT', 'TEXTAREA');
		$this->_key->Sortable = TRUE; // Allow sort
		$this->fields['key'] = &$this->_key;

		// serviceFeeToCustomerbk1amt
		$this->serviceFeeToCustomerbk1amt = new DbField('userpurchase', 'userpurchase', 'x_serviceFeeToCustomerbk1amt', 'serviceFeeToCustomerbk1amt', '`serviceFeeToCustomerbk1amt`', '`serviceFeeToCustomerbk1amt`', 131, 20, -1, FALSE, '`serviceFeeToCustomerbk1amt`', FALSE, FALSE, FALSE, 'FORMATTED TEXT', 'TEXT');
		$this->serviceFeeToCustomerbk1amt->Nullable = FALSE; // NOT NULL field
		$this->serviceFeeToCustomerbk1amt->Sortable = TRUE; // Allow sort
		$this->serviceFeeToCustomerbk1amt->DefaultErrorMessage = $Language->phrase("IncorrectFloat");
		$this->fields['serviceFeeToCustomerbk1amt'] = &$this->serviceFeeToCustomerbk1amt;

		// serviceFeeToCustomerbk1type
		$this->serviceFeeToCustomerbk1type = new DbField('userpurchase', 'userpurchase', 'x_serviceFeeToCustomerbk1type', 'serviceFeeToCustomerbk1type', '`serviceFeeToCustomerbk1type`', '`serviceFeeToCustomerbk1type`', 200, 15, -1, FALSE, '`serviceFeeToCustomerbk1type`', FALSE, FALSE, FALSE, 'FORMATTED TEXT', 'TEXT');
		$this->serviceFeeToCustomerbk1type->Sortable = TRUE; // Allow sort
		$this->fields['serviceFeeToCustomerbk1type'] = &$this->serviceFeeToCustomerbk1type;

		// serviceFeeToCustomerbk2amt
		$this->serviceFeeToCustomerbk2amt = new DbField('userpurchase', 'userpurchase', 'x_serviceFeeToCustomerbk2amt', 'serviceFeeToCustomerbk2amt', '`serviceFeeToCustomerbk2amt`', '`serviceFeeToCustomerbk2amt`', 131, 20, -1, FALSE, '`serviceFeeToCustomerbk2amt`', FALSE, FALSE, FALSE, 'FORMATTED TEXT', 'TEXT');
		$this->serviceFeeToCustomerbk2amt->Nullable = FALSE; // NOT NULL field
		$this->serviceFeeToCustomerbk2amt->Sortable = TRUE; // Allow sort
		$this->serviceFeeToCustomerbk2amt->DefaultErrorMessage = $Language->phrase("IncorrectFloat");
		$this->fields['serviceFeeToCustomerbk2amt'] = &$this->serviceFeeToCustomerbk2amt;

		// serviceFeeToCustomerbk2type
		$this->serviceFeeToCustomerbk2type = new DbField('userpurchase', 'userpurchase', 'x_serviceFeeToCustomerbk2type', 'serviceFeeToCustomerbk2type', '`serviceFeeToCustomerbk2type`', '`serviceFeeToCustomerbk2type`', 200, 15, -1, FALSE, '`serviceFeeToCustomerbk2type`', FALSE, FALSE, FALSE, 'FORMATTED TEXT', 'TEXT');
		$this->serviceFeeToCustomerbk2type->Sortable = TRUE; // Allow sort
		$this->fields['serviceFeeToCustomerbk2type'] = &$this->serviceFeeToCustomerbk2type;

		// serviceFeeToCustomerbk3amt
		$this->serviceFeeToCustomerbk3amt = new DbField('userpurchase', 'userpurchase', 'x_serviceFeeToCustomerbk3amt', 'serviceFeeToCustomerbk3amt', '`serviceFeeToCustomerbk3amt`', '`serviceFeeToCustomerbk3amt`', 131, 20, -1, FALSE, '`serviceFeeToCustomerbk3amt`', FALSE, FALSE, FALSE, 'FORMATTED TEXT', 'TEXT');
		$this->serviceFeeToCustomerbk3amt->Nullable = FALSE; // NOT NULL field
		$this->serviceFeeToCustomerbk3amt->Sortable = TRUE; // Allow sort
		$this->serviceFeeToCustomerbk3amt->DefaultErrorMessage = $Language->phrase("IncorrectFloat");
		$this->fields['serviceFeeToCustomerbk3amt'] = &$this->serviceFeeToCustomerbk3amt;

		// serviceFeeToCustomerbk3type
		$this->serviceFeeToCustomerbk3type = new DbField('userpurchase', 'userpurchase', 'x_serviceFeeToCustomerbk3type', 'serviceFeeToCustomerbk3type', '`serviceFeeToCustomerbk3type`', '`serviceFeeToCustomerbk3type`', 200, 15, -1, FALSE, '`serviceFeeToCustomerbk3type`', FALSE, FALSE, FALSE, 'FORMATTED TEXT', 'TEXT');
		$this->serviceFeeToCustomerbk3type->Sortable = TRUE; // Allow sort
		$this->fields['serviceFeeToCustomerbk3type'] = &$this->serviceFeeToCustomerbk3type;

		// taxAmountbk1amt
		$this->taxAmountbk1amt = new DbField('userpurchase', 'userpurchase', 'x_taxAmountbk1amt', 'taxAmountbk1amt', '`taxAmountbk1amt`', '`taxAmountbk1amt`', 131, 20, -1, FALSE, '`taxAmountbk1amt`', FALSE, FALSE, FALSE, 'FORMATTED TEXT', 'TEXT');
		$this->taxAmountbk1amt->Nullable = FALSE; // NOT NULL field
		$this->taxAmountbk1amt->Sortable = TRUE; // Allow sort
		$this->taxAmountbk1amt->DefaultErrorMessage = $Language->phrase("IncorrectFloat");
		$this->fields['taxAmountbk1amt'] = &$this->taxAmountbk1amt;

		// taxAmountbk1type
		$this->taxAmountbk1type = new DbField('userpurchase', 'userpurchase', 'x_taxAmountbk1type', 'taxAmountbk1type', '`taxAmountbk1type`', '`taxAmountbk1type`', 200, 15, -1, FALSE, '`taxAmountbk1type`', FALSE, FALSE, FALSE, 'FORMATTED TEXT', 'TEXT');
		$this->taxAmountbk1type->Sortable = TRUE; // Allow sort
		$this->fields['taxAmountbk1type'] = &$this->taxAmountbk1type;

		// taxAmountbk2amt
		$this->taxAmountbk2amt = new DbField('userpurchase', 'userpurchase', 'x_taxAmountbk2amt', 'taxAmountbk2amt', '`taxAmountbk2amt`', '`taxAmountbk2amt`', 131, 20, -1, FALSE, '`taxAmountbk2amt`', FALSE, FALSE, FALSE, 'FORMATTED TEXT', 'TEXT');
		$this->taxAmountbk2amt->Nullable = FALSE; // NOT NULL field
		$this->taxAmountbk2amt->Sortable = TRUE; // Allow sort
		$this->taxAmountbk2amt->DefaultErrorMessage = $Language->phrase("IncorrectFloat");
		$this->fields['taxAmountbk2amt'] = &$this->taxAmountbk2amt;

		// taxAmountbk2type
		$this->taxAmountbk2type = new DbField('userpurchase', 'userpurchase', 'x_taxAmountbk2type', 'taxAmountbk2type', '`taxAmountbk2type`', '`taxAmountbk2type`', 200, 15, -1, FALSE, '`taxAmountbk2type`', FALSE, FALSE, FALSE, 'FORMATTED TEXT', 'TEXT');
		$this->taxAmountbk2type->Sortable = TRUE; // Allow sort
		$this->fields['taxAmountbk2type'] = &$this->taxAmountbk2type;

		// taxAmountbk3amt
		$this->taxAmountbk3amt = new DbField('userpurchase', 'userpurchase', 'x_taxAmountbk3amt', 'taxAmountbk3amt', '`taxAmountbk3amt`', '`taxAmountbk3amt`', 131, 20, -1, FALSE, '`taxAmountbk3amt`', FALSE, FALSE, FALSE, 'FORMATTED TEXT', 'TEXT');
		$this->taxAmountbk3amt->Nullable = FALSE; // NOT NULL field
		$this->taxAmountbk3amt->Sortable = TRUE; // Allow sort
		$this->taxAmountbk3amt->DefaultErrorMessage = $Language->phrase("IncorrectFloat");
		$this->fields['taxAmountbk3amt'] = &$this->taxAmountbk3amt;

		// taxAmountbk3type
		$this->taxAmountbk3type = new DbField('userpurchase', 'userpurchase', 'x_taxAmountbk3type', 'taxAmountbk3type', '`taxAmountbk3type`', '`taxAmountbk3type`', 200, 15, -1, FALSE, '`taxAmountbk3type`', FALSE, FALSE, FALSE, 'FORMATTED TEXT', 'TEXT');
		$this->taxAmountbk3type->Sortable = TRUE; // Allow sort
		$this->fields['taxAmountbk3type'] = &$this->taxAmountbk3type;

		// originalpurchaseamount
		$this->originalpurchaseamount = new DbField('userpurchase', 'userpurchase', 'x_originalpurchaseamount', 'originalpurchaseamount', '`originalpurchaseamount`', '`originalpurchaseamount`', 131, 20, -1, FALSE, '`originalpurchaseamount`', FALSE, FALSE, FALSE, 'FORMATTED TEXT', 'TEXT');
		$this->originalpurchaseamount->Nullable = FALSE; // NOT NULL field
		$this->originalpurchaseamount->Sortable = TRUE; // Allow sort
		$this->originalpurchaseamount->DefaultErrorMessage = $Language->phrase("IncorrectFloat");
		$this->fields['originalpurchaseamount'] = &$this->originalpurchaseamount;

		// discountamount
		$this->discountamount = new DbField('userpurchase', 'userpurchase', 'x_discountamount', 'discountamount', '`discountamount`', '`discountamount`', 131, 20, -1, FALSE, '`discountamount`', FALSE, FALSE, FALSE, 'FORMATTED TEXT', 'TEXT');
		$this->discountamount->Nullable = FALSE; // NOT NULL field
		$this->discountamount->Sortable = TRUE; // Allow sort
		$this->discountamount->DefaultErrorMessage = $Language->phrase("IncorrectFloat");
		$this->fields['discountamount'] = &$this->discountamount;

		// discountpercentage
		$this->discountpercentage = new DbField('userpurchase', 'userpurchase', 'x_discountpercentage', 'discountpercentage', '`discountpercentage`', '`discountpercentage`', 3, 1, -1, FALSE, '`discountpercentage`', FALSE, FALSE, FALSE, 'FORMATTED TEXT', 'TEXT');
		$this->discountpercentage->Nullable = FALSE; // NOT NULL field
		$this->discountpercentage->Sortable = TRUE; // Allow sort
		$this->discountpercentage->DefaultErrorMessage = $Language->phrase("IncorrectInteger");
		$this->fields['discountpercentage'] = &$this->discountpercentage;

		// txgroupid
		$this->txgroupid = new DbField('userpurchase', 'userpurchase', 'x_txgroupid', 'txgroupid', '`txgroupid`', '`txgroupid`', 20, 15, -1, FALSE, '`txgroupid`', FALSE, FALSE, FALSE, 'FORMATTED TEXT', 'TEXT');
		$this->txgroupid->Nullable = FALSE; // NOT NULL field
		$this->txgroupid->Sortable = TRUE; // Allow sort
		$this->txgroupid->DefaultErrorMessage = $Language->phrase("IncorrectInteger");
		$this->fields['txgroupid'] = &$this->txgroupid;

		// success_status
		$this->success_status = new DbField('userpurchase', 'userpurchase', 'x_success_status', 'success_status', '`success_status`', '`success_status`', 3, 1, -1, FALSE, '`success_status`', FALSE, FALSE, FALSE, 'FORMATTED TEXT', 'SELECT');
		$this->success_status->Nullable = FALSE; // NOT NULL field
		$this->success_status->Sortable = TRUE; // Allow sort
		$this->success_status->UsePleaseSelect = TRUE; // Use PleaseSelect by default
		$this->success_status->PleaseSelectText = $Language->phrase("PleaseSelect"); // "PleaseSelect" text
		$this->success_status->Lookup = new Lookup('success_status', 'userpurchase', FALSE, '', ["","","",""], [], [], [], [], [], [], '', '');
		$this->success_status->OptionCount = 4;
		$this->success_status->DefaultErrorMessage = $Language->phrase("IncorrectInteger");
		$this->fields['success_status'] = &$this->success_status;

		// error_msg
		$this->error_msg = new DbField('userpurchase', 'userpurchase', 'x_error_msg', 'error_msg', '`error_msg`', '`error_msg`', 200, 255, -1, FALSE, '`error_msg`', FALSE, FALSE, FALSE, 'FORMATTED TEXT', 'TEXT');
		$this->error_msg->Sortable = TRUE; // Allow sort
		$this->fields['error_msg'] = &$this->error_msg;

		// userpiid
		$this->userpiid = new DbField('userpurchase', 'userpurchase', 'x_userpiid', 'userpiid', '`userpiid`', '`userpiid`', 3, 5, -1, FALSE, '`userpiid`', FALSE, FALSE, FALSE, 'FORMATTED TEXT', 'TEXT');
		$this->userpiid->Sortable = TRUE; // Allow sort
		$this->userpiid->DefaultErrorMessage = $Language->phrase("IncorrectInteger");
		$this->fields['userpiid'] = &$this->userpiid;

		// notes
		$this->notes = new DbField('userpurchase', 'userpurchase', 'x_notes', 'notes', '`notes`', '`notes`', 200, 255, -1, FALSE, '`notes`', FALSE, FALSE, FALSE, 'FORMATTED TEXT', 'TEXT');
		$this->notes->Sortable = TRUE; // Allow sort
		$this->fields['notes'] = &$this->notes;

		// lastpurchasereaddate
		$this->lastpurchasereaddate = new DbField('userpurchase', 'userpurchase', 'x_lastpurchasereaddate', 'lastpurchasereaddate', '`lastpurchasereaddate`', CastDateFieldForLike("`lastpurchasereaddate`", 0, "DB"), 135, 19, 0, FALSE, '`lastpurchasereaddate`', FALSE, FALSE, FALSE, 'FORMATTED TEXT', 'TEXT');
		$this->lastpurchasereaddate->Sortable = TRUE; // Allow sort
		$this->lastpurchasereaddate->DefaultErrorMessage = str_replace("%s", $GLOBALS["DATE_FORMAT"], $Language->phrase("IncorrectDate"));
		$this->fields['lastpurchasereaddate'] = &$this->lastpurchasereaddate;

		// retryapicount
		$this->retryapicount = new DbField('userpurchase', 'userpurchase', 'x_retryapicount', 'retryapicount', '`retryapicount`', '`retryapicount`', 3, 1, -1, FALSE, '`retryapicount`', FALSE, FALSE, FALSE, 'FORMATTED TEXT', 'TEXT');
		$this->retryapicount->Sortable = TRUE; // Allow sort
		$this->retryapicount->DefaultErrorMessage = $Language->phrase("IncorrectInteger");
		$this->fields['retryapicount'] = &$this->retryapicount;
	}

	// Field Visibility
	public function getFieldVisibility($fldParm)
	{
		global $Security;
		return $this->$fldParm->Visible; // Returns original value
	}

	// Set left column class (must be predefined col-*-* classes of Bootstrap grid system)
	function setLeftColumnClass($class)
	{
		if (preg_match('/^col\-(\w+)\-(\d+)$/', $class, $match)) {
			$this->LeftColumnClass = $class . " col-form-label ew-label";
			$this->RightColumnClass = "col-" . $match[1] . "-" . strval(12 - (int)$match[2]);
			$this->OffsetColumnClass = $this->RightColumnClass . " " . str_replace("col-", "offset-", $class);
			$this->TableLeftColumnClass = preg_replace('/^col-\w+-(\d+)$/', "w-col-$1", $class); // Change to w-col-*
		}
	}

	// Single column sort
	public function updateSort(&$fld)
	{
		if ($this->CurrentOrder == $fld->Name) {
			$sortField = $fld->Expression;
			$lastSort = $fld->getSort();
			if ($this->CurrentOrderType == "ASC" || $this->CurrentOrderType == "DESC") {
				$thisSort = $this->CurrentOrderType;
			} else {
				$thisSort = ($lastSort == "ASC") ? "DESC" : "ASC";
			}
			$fld->setSort($thisSort);
			$this->setSessionOrderBy($sortField . " " . $thisSort); // Save to Session
		} else {
			$fld->setSort("");
		}
	}

	// Current master table name
	public function getCurrentMasterTable()
	{
		return @$_SESSION[PROJECT_NAME . "_" . $this->TableVar . "_" . Config("TABLE_MASTER_TABLE")];
	}
	public function setCurrentMasterTable($v)
	{
		$_SESSION[PROJECT_NAME . "_" . $this->TableVar . "_" . Config("TABLE_MASTER_TABLE")] = $v;
	}

	// Session master WHERE clause
	public function getMasterFilter()
	{

		// Master filter
		$masterFilter = "";
		if ($this->getCurrentMasterTable() == "user") {
			if ($this->_userid->getSessionValue() != "")
				$masterFilter .= "`id`=" . QuotedValue($this->_userid->getSessionValue(), DATATYPE_NUMBER, "DB");
			else
				return "";
		}
		return $masterFilter;
	}

	// Session detail WHERE clause
	public function getDetailFilter()
	{

		// Detail filter
		$detailFilter = "";
		if ($this->getCurrentMasterTable() == "user") {
			if ($this->_userid->getSessionValue() != "")
				$detailFilter .= "`userid`=" . QuotedValue($this->_userid->getSessionValue(), DATATYPE_NUMBER, "DB");
			else
				return "";
		}
		return $detailFilter;
	}

	// Master filter
	public function sqlMasterFilter_user()
	{
		return "`id`=@id@";
	}

	// Detail filter
	public function sqlDetailFilter_user()
	{
		return "`userid`=@_userid@";
	}

	// Current detail table name
	public function getCurrentDetailTable()
	{
		return @$_SESSION[PROJECT_NAME . "_" . $this->TableVar . "_" . Config("TABLE_DETAIL_TABLE")];
	}
	public function setCurrentDetailTable($v)
	{
		$_SESSION[PROJECT_NAME . "_" . $this->TableVar . "_" . Config("TABLE_DETAIL_TABLE")] = $v;
	}

	// Get detail url
	public function getDetailUrl()
	{

		// Detail url
		$detailUrl = "";
		if ($this->getCurrentDetailTable() == "userpurchasepayment") {
			$detailUrl = $GLOBALS["userpurchasepayment"]->getListUrl() . "?" . Config("TABLE_SHOW_MASTER") . "=" . $this->TableVar;
			$detailUrl .= "&fk_purchaseid=" . urlencode($this->purchaseid->CurrentValue);
		}
		if ($this->getCurrentDetailTable() == "userpurchasereturn") {
			$detailUrl = $GLOBALS["userpurchasereturn"]->getListUrl() . "?" . Config("TABLE_SHOW_MASTER") . "=" . $this->TableVar;
			$detailUrl .= "&fk_purchaseid=" . urlencode($this->purchaseid->CurrentValue);
		}
		if ($this->getCurrentDetailTable() == "vbillinghistory") {
			$detailUrl = $GLOBALS["vbillinghistory"]->getListUrl() . "?" . Config("TABLE_SHOW_MASTER") . "=" . $this->TableVar;
			$detailUrl .= "&fk_purchaseid=" . urlencode($this->purchaseid->CurrentValue);
		}
		if ($detailUrl == "")
			$detailUrl = "userpurchaselist.php";
		return $detailUrl;
	}

	// Table level SQL
	public function getSqlFrom() // From
	{
		return ($this->SqlFrom != "") ? $this->SqlFrom : "`userpurchase`";
	}
	public function sqlFrom() // For backward compatibility
	{
		return $this->getSqlFrom();
	}
	public function setSqlFrom($v)
	{
		$this->SqlFrom = $v;
	}
	public function getSqlSelect() // Select
	{
		return ($this->SqlSelect != "") ? $this->SqlSelect : "SELECT * FROM " . $this->getSqlFrom();
	}
	public function sqlSelect() // For backward compatibility
	{
		return $this->getSqlSelect();
	}
	public function setSqlSelect($v)
	{
		$this->SqlSelect = $v;
	}
	public function getSqlWhere() // Where
	{
		$where = ($this->SqlWhere != "") ? $this->SqlWhere : "";
		$this->TableFilter = "";
		AddFilter($where, $this->TableFilter);
		return $where;
	}
	public function sqlWhere() // For backward compatibility
	{
		return $this->getSqlWhere();
	}
	public function setSqlWhere($v)
	{
		$this->SqlWhere = $v;
	}
	public function getSqlGroupBy() // Group By
	{
		return ($this->SqlGroupBy != "") ? $this->SqlGroupBy : "";
	}
	public function sqlGroupBy() // For backward compatibility
	{
		return $this->getSqlGroupBy();
	}
	public function setSqlGroupBy($v)
	{
		$this->SqlGroupBy = $v;
	}
	public function getSqlHaving() // Having
	{
		return ($this->SqlHaving != "") ? $this->SqlHaving : "";
	}
	public function sqlHaving() // For backward compatibility
	{
		return $this->getSqlHaving();
	}
	public function setSqlHaving($v)
	{
		$this->SqlHaving = $v;
	}
	public function getSqlOrderBy() // Order By
	{
		return ($this->SqlOrderBy != "") ? $this->SqlOrderBy : "";
	}
	public function sqlOrderBy() // For backward compatibility
	{
		return $this->getSqlOrderBy();
	}
	public function setSqlOrderBy($v)
	{
		$this->SqlOrderBy = $v;
	}

	// Apply User ID filters
	public function applyUserIDFilters($filter, $id = "")
	{
		return $filter;
	}

	// Check if User ID security allows view all
	public function userIDAllow($id = "")
	{
		$allow = $this->UserIDAllowSecurity;
		switch ($id) {
			case "add":
			case "copy":
			case "gridadd":
			case "register":
			case "addopt":
				return (($allow & 1) == 1);
			case "edit":
			case "gridedit":
			case "update":
			case "changepwd":
			case "forgotpwd":
				return (($allow & 4) == 4);
			case "delete":
				return (($allow & 2) == 2);
			case "view":
				return (($allow & 32) == 32);
			case "search":
				return (($allow & 64) == 64);
			case "lookup":
				return (($allow & 256) == 256);
			default:
				return (($allow & 8) == 8);
		}
	}

	// Get recordset
	public function getRecordset($sql, $rowcnt = -1, $offset = -1)
	{
		$conn = $this->getConnection();
		$conn->raiseErrorFn = Config("ERROR_FUNC");
		$rs = $conn->selectLimit($sql, $rowcnt, $offset);
		$conn->raiseErrorFn = "";
		return $rs;
	}

	// Get record count
	public function getRecordCount($sql, $c = NULL)
	{
		$cnt = -1;
		$rs = NULL;
		$sql = preg_replace('/\/\*BeginOrderBy\*\/[\s\S]+\/\*EndOrderBy\*\//', "", $sql); // Remove ORDER BY clause (MSSQL)
		$pattern = '/^SELECT\s([\s\S]+)\sFROM\s/i';

		// Skip Custom View / SubQuery / SELECT DISTINCT / ORDER BY
		if (($this->TableType == 'TABLE' || $this->TableType == 'VIEW' || $this->TableType == 'LINKTABLE') &&
			preg_match($pattern, $sql) && !preg_match('/\(\s*(SELECT[^)]+)\)/i', $sql) &&
			!preg_match('/^\s*select\s+distinct\s+/i', $sql) && !preg_match('/\s+order\s+by\s+/i', $sql)) {
			$sqlwrk = "SELECT COUNT(*) FROM " . preg_replace($pattern, "", $sql);
		} else {
			$sqlwrk = "SELECT COUNT(*) FROM (" . $sql . ") COUNT_TABLE";
		}
		$conn = $c ?: $this->getConnection();
		if ($rs = $conn->execute($sqlwrk)) {
			if (!$rs->EOF && $rs->FieldCount() > 0) {
				$cnt = $rs->fields[0];
				$rs->close();
			}
			return (int)$cnt;
		}

		// Unable to get count, get record count directly
		if ($rs = $conn->execute($sql)) {
			$cnt = $rs->RecordCount();
			$rs->close();
			return (int)$cnt;
		}
		return $cnt;
	}

	// Get SQL
	public function getSql($where, $orderBy = "")
	{
		return BuildSelectSql($this->getSqlSelect(), $this->getSqlWhere(),
			$this->getSqlGroupBy(), $this->getSqlHaving(), $this->getSqlOrderBy(),
			$where, $orderBy);
	}

	// Table SQL
	public function getCurrentSql()
	{
		$filter = $this->CurrentFilter;
		$filter = $this->applyUserIDFilters($filter);
		$sort = $this->getSessionOrderBy();
		return $this->getSql($filter, $sort);
	}

	// Table SQL with List page filter
	public function getListSql()
	{
		$filter = $this->UseSessionForListSql ? $this->getSessionWhere() : "";
		AddFilter($filter, $this->CurrentFilter);
		$filter = $this->applyUserIDFilters($filter);
		$this->Recordset_Selecting($filter);
		$select = $this->getSqlSelect();
		$sort = $this->UseSessionForListSql ? $this->getSessionOrderBy() : "";
		return BuildSelectSql($select, $this->getSqlWhere(), $this->getSqlGroupBy(),
			$this->getSqlHaving(), $this->getSqlOrderBy(), $filter, $sort);
	}

	// Get ORDER BY clause
	public function getOrderBy()
	{
		$sort = $this->getSessionOrderBy();
		return BuildSelectSql("", "", "", "", $this->getSqlOrderBy(), "", $sort);
	}

	// Get record count based on filter (for detail record count in master table pages)
	public function loadRecordCount($filter)
	{
		$origFilter = $this->CurrentFilter;
		$this->CurrentFilter = $filter;
		$this->Recordset_Selecting($this->CurrentFilter);
		$select = $this->TableType == 'CUSTOMVIEW' ? $this->getSqlSelect() : "SELECT * FROM " . $this->getSqlFrom();
		$groupBy = $this->TableType == 'CUSTOMVIEW' ? $this->getSqlGroupBy() : "";
		$having = $this->TableType == 'CUSTOMVIEW' ? $this->getSqlHaving() : "";
		$sql = BuildSelectSql($select, $this->getSqlWhere(), $groupBy, $having, "", $this->CurrentFilter, "");
		$cnt = $this->getRecordCount($sql);
		$this->CurrentFilter = $origFilter;
		return $cnt;
	}

	// Get record count (for current List page)
	public function listRecordCount()
	{
		$filter = $this->getSessionWhere();
		AddFilter($filter, $this->CurrentFilter);
		$filter = $this->applyUserIDFilters($filter);
		$this->Recordset_Selecting($filter);
		$select = $this->TableType == 'CUSTOMVIEW' ? $this->getSqlSelect() : "SELECT * FROM " . $this->getSqlFrom();
		$groupBy = $this->TableType == 'CUSTOMVIEW' ? $this->getSqlGroupBy() : "";
		$having = $this->TableType == 'CUSTOMVIEW' ? $this->getSqlHaving() : "";
		$sql = BuildSelectSql($select, $this->getSqlWhere(), $groupBy, $having, "", $filter, "");
		$cnt = $this->getRecordCount($sql);
		return $cnt;
	}

	// INSERT statement
	protected function insertSql(&$rs)
	{
		$names = "";
		$values = "";
		foreach ($rs as $name => $value) {
			if (!isset($this->fields[$name]) || $this->fields[$name]->IsCustom)
				continue;
			$names .= $this->fields[$name]->Expression . ",";
			$values .= QuotedValue($value, $this->fields[$name]->DataType, $this->Dbid) . ",";
		}
		$names = preg_replace('/,+$/', "", $names);
		$values = preg_replace('/,+$/', "", $values);
		return "INSERT INTO " . $this->UpdateTable . " (" . $names . ") VALUES (" . $values . ")";
	}

	// Insert
	public function insert(&$rs)
	{
		$conn = $this->getConnection();
		$success = $conn->execute($this->insertSql($rs));
		if ($success) {

			// Get insert id if necessary
			$this->purchaseid->setDbValue($conn->insert_ID());
			$rs['purchaseid'] = $this->purchaseid->DbValue;
			if ($this->AuditTrailOnAdd)
				$this->writeAuditTrailOnAdd($rs);
		}
		return $success;
	}

	// UPDATE statement
	protected function updateSql(&$rs, $where = "", $curfilter = TRUE)
	{
		$sql = "UPDATE " . $this->UpdateTable . " SET ";
		foreach ($rs as $name => $value) {
			if (!isset($this->fields[$name]) || $this->fields[$name]->IsCustom || $this->fields[$name]->IsAutoIncrement)
				continue;
			$sql .= $this->fields[$name]->Expression . "=";
			$sql .= QuotedValue($value, $this->fields[$name]->DataType, $this->Dbid) . ",";
		}
		$sql = preg_replace('/,+$/', "", $sql);
		$filter = ($curfilter) ? $this->CurrentFilter : "";
		if (is_array($where))
			$where = $this->arrayToFilter($where);
		AddFilter($filter, $where);
		if ($filter != "")
			$sql .= " WHERE " . $filter;
		return $sql;
	}

	// Update
	public function update(&$rs, $where = "", $rsold = NULL, $curfilter = TRUE)
	{
		$conn = $this->getConnection();
		$success = $conn->execute($this->updateSql($rs, $where, $curfilter));
		if ($success && $this->AuditTrailOnEdit && $rsold) {
			$rsaudit = $rs;
			$fldname = 'purchaseid';
			if (!array_key_exists($fldname, $rsaudit))
				$rsaudit[$fldname] = $rsold[$fldname];
			$this->writeAuditTrailOnEdit($rsold, $rsaudit);
		}
		return $success;
	}

	// DELETE statement
	protected function deleteSql(&$rs, $where = "", $curfilter = TRUE)
	{
		$sql = "DELETE FROM " . $this->UpdateTable . " WHERE ";
		if (is_array($where))
			$where = $this->arrayToFilter($where);
		if ($rs) {
			if (array_key_exists('purchaseid', $rs))
				AddFilter($where, QuotedName('purchaseid', $this->Dbid) . '=' . QuotedValue($rs['purchaseid'], $this->purchaseid->DataType, $this->Dbid));
		}
		$filter = ($curfilter) ? $this->CurrentFilter : "";
		AddFilter($filter, $where);
		if ($filter != "")
			$sql .= $filter;
		else
			$sql .= "0=1"; // Avoid delete
		return $sql;
	}

	// Delete
	public function delete(&$rs, $where = "", $curfilter = FALSE)
	{
		$success = TRUE;
		$conn = $this->getConnection();
		if ($success)
			$success = $conn->execute($this->deleteSql($rs, $where, $curfilter));
		if ($success && $this->AuditTrailOnDelete)
			$this->writeAuditTrailOnDelete($rs);
		return $success;
	}

	// Load DbValue from recordset or array
	protected function loadDbValues(&$rs)
	{
		if (!$rs || !is_array($rs) && $rs->EOF)
			return;
		$row = is_array($rs) ? $rs : $rs->fields;
		$this->purchaseid->DbValue = $row['purchaseid'];
		$this->_userid->DbValue = $row['userid'];
		$this->merchantnodeid->DbValue = $row['merchantnodeid'];
		$this->merchantid->DbValue = $row['merchantid'];
		$this->merchantbusinessname->DbValue = $row['merchantbusinessname'];
		$this->merchanttransferid->DbValue = $row['merchanttransferid'];
		$this->merchantuserid->DbValue = $row['merchantuserid'];
		$this->purchasedate->DbValue = $row['purchasedate'];
		$this->txid->DbValue = $row['txid'];
		$this->userpi->DbValue = $row['userpi'];
		$this->otherconfirmref->DbValue = $row['otherconfirmref'];
		$this->currencycode->DbValue = $row['currencycode'];
		$this->purchaseamount->DbValue = $row['purchaseamount'];
		$this->tipamount->DbValue = $row['tipamount'];
		$this->merchantfees->DbValue = $row['merchantfees'];
		$this->consumerfees->DbValue = $row['consumerfees'];
		$this->transferid->DbValue = $row['transferid'];
		$this->merchantSurcharge->DbValue = $row['merchantSurcharge'];
		$this->taxAmount->DbValue = $row['taxAmount'];
		$this->totalAmounForCustomer->DbValue = $row['totalAmounForCustomer'];
		$this->feeid->DbValue = $row['feeid'];
		$this->ratetabletype->DbValue = $row['ratetabletype'];
		$this->itemdesc->DbValue = $row['itemdesc'];
		$this->shoppingCartID->DbValue = $row['shoppingCartID'];
		$this->merchantRefID->DbValue = $row['merchantRefID'];
		$this->refunded->DbValue = $row['refunded'];
		$this->tokenid->DbValue = $row['tokenid'];
		$this->cardno->DbValue = $row['cardno'];
		$this->vaultid->DbValue = $row['vaultid'];
		$this->refundrequested->DbValue = $row['refundrequested'];
		$this->refundrequesttxid->DbValue = $row['refundrequesttxid'];
		$this->feesystemshare->DbValue = $row['feesystemshare'];
		$this->feeexternalshare->DbValue = $row['feeexternalshare'];
		$this->feefranchiseeshare->DbValue = $row['feefranchiseeshare'];
		$this->feeresellershare->DbValue = $row['feeresellershare'];
		$this->_key->DbValue = $row['key'];
		$this->serviceFeeToCustomerbk1amt->DbValue = $row['serviceFeeToCustomerbk1amt'];
		$this->serviceFeeToCustomerbk1type->DbValue = $row['serviceFeeToCustomerbk1type'];
		$this->serviceFeeToCustomerbk2amt->DbValue = $row['serviceFeeToCustomerbk2amt'];
		$this->serviceFeeToCustomerbk2type->DbValue = $row['serviceFeeToCustomerbk2type'];
		$this->serviceFeeToCustomerbk3amt->DbValue = $row['serviceFeeToCustomerbk3amt'];
		$this->serviceFeeToCustomerbk3type->DbValue = $row['serviceFeeToCustomerbk3type'];
		$this->taxAmountbk1amt->DbValue = $row['taxAmountbk1amt'];
		$this->taxAmountbk1type->DbValue = $row['taxAmountbk1type'];
		$this->taxAmountbk2amt->DbValue = $row['taxAmountbk2amt'];
		$this->taxAmountbk2type->DbValue = $row['taxAmountbk2type'];
		$this->taxAmountbk3amt->DbValue = $row['taxAmountbk3amt'];
		$this->taxAmountbk3type->DbValue = $row['taxAmountbk3type'];
		$this->originalpurchaseamount->DbValue = $row['originalpurchaseamount'];
		$this->discountamount->DbValue = $row['discountamount'];
		$this->discountpercentage->DbValue = $row['discountpercentage'];
		$this->txgroupid->DbValue = $row['txgroupid'];
		$this->success_status->DbValue = $row['success_status'];
		$this->error_msg->DbValue = $row['error_msg'];
		$this->userpiid->DbValue = $row['userpiid'];
		$this->notes->DbValue = $row['notes'];
		$this->lastpurchasereaddate->DbValue = $row['lastpurchasereaddate'];
		$this->retryapicount->DbValue = $row['retryapicount'];
	}

	// Delete uploaded files
	public function deleteUploadedFiles($row)
	{
		$this->loadDbValues($row);
	}

	// Record filter WHERE clause
	protected function sqlKeyFilter()
	{
		return "`purchaseid` = @purchaseid@";
	}

	// Get record filter
	public function getRecordFilter($row = NULL)
	{
		$keyFilter = $this->sqlKeyFilter();
		if (is_array($row))
			$val = array_key_exists('purchaseid', $row) ? $row['purchaseid'] : NULL;
		else
			$val = $this->purchaseid->OldValue !== NULL ? $this->purchaseid->OldValue : $this->purchaseid->CurrentValue;
		if (!is_numeric($val))
			return "0=1"; // Invalid key
		if ($val == NULL)
			return "0=1"; // Invalid key
		else
			$keyFilter = str_replace("@purchaseid@", AdjustSql($val, $this->Dbid), $keyFilter); // Replace key value
		return $keyFilter;
	}

	// Return page URL
	public function getReturnUrl()
	{
		$name = PROJECT_NAME . "_" . $this->TableVar . "_" . Config("TABLE_RETURN_URL");

		// Get referer URL automatically
		if (ServerVar("HTTP_REFERER") != "" && ReferPageName() != CurrentPageName() && ReferPageName() != "login.php") // Referer not same page or login page
			$_SESSION[$name] = ServerVar("HTTP_REFERER"); // Save to Session
		if (@$_SESSION[$name] != "") {
			return $_SESSION[$name];
		} else {
			return "userpurchaselist.php";
		}
	}
	public function setReturnUrl($v)
	{
		$_SESSION[PROJECT_NAME . "_" . $this->TableVar . "_" . Config("TABLE_RETURN_URL")] = $v;
	}

	// Get modal caption
	public function getModalCaption($pageName)
	{
		global $Language;
		if ($pageName == "userpurchaseview.php")
			return $Language->phrase("View");
		elseif ($pageName == "userpurchaseedit.php")
			return $Language->phrase("Edit");
		elseif ($pageName == "userpurchaseadd.php")
			return $Language->phrase("Add");
		else
			return "";
	}

	// List URL
	public function getListUrl()
	{
		return "userpurchaselist.php";
	}

	// View URL
	public function getViewUrl($parm = "")
	{
		if ($parm != "")
			$url = $this->keyUrl("userpurchaseview.php", $this->getUrlParm($parm));
		else
			$url = $this->keyUrl("userpurchaseview.php", $this->getUrlParm(Config("TABLE_SHOW_DETAIL") . "="));
		return $this->addMasterUrl($url);
	}

	// Add URL
	public function getAddUrl($parm = "")
	{
		if ($parm != "")
			$url = "userpurchaseadd.php?" . $this->getUrlParm($parm);
		else
			$url = "userpurchaseadd.php";
		return $this->addMasterUrl($url);
	}

	// Edit URL
	public function getEditUrl($parm = "")
	{
		if ($parm != "")
			$url = $this->keyUrl("userpurchaseedit.php", $this->getUrlParm($parm));
		else
			$url = $this->keyUrl("userpurchaseedit.php", $this->getUrlParm(Config("TABLE_SHOW_DETAIL") . "="));
		return $this->addMasterUrl($url);
	}

	// Inline edit URL
	public function getInlineEditUrl()
	{
		$url = $this->keyUrl(CurrentPageName(), $this->getUrlParm("action=edit"));
		return $this->addMasterUrl($url);
	}

	// Copy URL
	public function getCopyUrl($parm = "")
	{
		if ($parm != "")
			$url = $this->keyUrl("userpurchaseadd.php", $this->getUrlParm($parm));
		else
			$url = $this->keyUrl("userpurchaseadd.php", $this->getUrlParm(Config("TABLE_SHOW_DETAIL") . "="));
		return $this->addMasterUrl($url);
	}

	// Inline copy URL
	public function getInlineCopyUrl()
	{
		$url = $this->keyUrl(CurrentPageName(), $this->getUrlParm("action=copy"));
		return $this->addMasterUrl($url);
	}

	// Delete URL
	public function getDeleteUrl()
	{
		return $this->keyUrl("userpurchasedelete.php", $this->getUrlParm());
	}

	// Add master url
	public function addMasterUrl($url)
	{
		if ($this->getCurrentMasterTable() == "user" && !ContainsString($url, Config("TABLE_SHOW_MASTER") . "=")) {
			$url .= (ContainsString($url, "?") ? "&" : "?") . Config("TABLE_SHOW_MASTER") . "=" . $this->getCurrentMasterTable();
			$url .= "&fk_id=" . urlencode($this->_userid->CurrentValue);
		}
		return $url;
	}
	public function keyToJson($htmlEncode = FALSE)
	{
		$json = "";
		$json .= "purchaseid:" . JsonEncode($this->purchaseid->CurrentValue, "number");
		$json = "{" . $json . "}";
		if ($htmlEncode)
			$json = HtmlEncode($json);
		return $json;
	}

	// Add key value to URL
	public function keyUrl($url, $parm = "")
	{
		$url = $url . "?";
		if ($parm != "")
			$url .= $parm . "&";
		if ($this->purchaseid->CurrentValue != NULL) {
			$url .= "purchaseid=" . urlencode($this->purchaseid->CurrentValue);
		} else {
			return "javascript:ew.alert(ew.language.phrase('InvalidRecord'));";
		}
		return $url;
	}

	// Sort URL
	public function sortUrl(&$fld)
	{
		if ($this->CurrentAction || $this->isExport() ||
			in_array($fld->Type, [128, 204, 205])) { // Unsortable data type
				return "";
		} elseif ($fld->Sortable) {
			$urlParm = $this->getUrlParm("order=" . urlencode($fld->Name) . "&amp;ordertype=" . $fld->reverseSort());
			return $this->addMasterUrl(CurrentPageName() . "?" . $urlParm);
		} else {
			return "";
		}
	}

	// Get record keys from Post/Get/Session
	public function getRecordKeys()
	{
		$arKeys = [];
		$arKey = [];
		if (Param("key_m") !== NULL) {
			$arKeys = Param("key_m");
			$cnt = count($arKeys);
		} else {
			if (Param("purchaseid") !== NULL)
				$arKeys[] = Param("purchaseid");
			elseif (IsApi() && Key(0) !== NULL)
				$arKeys[] = Key(0);
			elseif (IsApi() && Route(2) !== NULL)
				$arKeys[] = Route(2);
			else
				$arKeys = NULL; // Do not setup

			//return $arKeys; // Do not return yet, so the values will also be checked by the following code
		}

		// Check keys
		$ar = [];
		if (is_array($arKeys)) {
			foreach ($arKeys as $key) {
				if (!is_numeric($key))
					continue;
				$ar[] = $key;
			}
		}
		return $ar;
	}

	// Get filter from record keys
	public function getFilterFromRecordKeys($setCurrent = TRUE)
	{
		$arKeys = $this->getRecordKeys();
		$keyFilter = "";
		foreach ($arKeys as $key) {
			if ($keyFilter != "") $keyFilter .= " OR ";
			if ($setCurrent)
				$this->purchaseid->CurrentValue = $key;
			else
				$this->purchaseid->OldValue = $key;
			$keyFilter .= "(" . $this->getRecordFilter() . ")";
		}
		return $keyFilter;
	}

	// Load rows based on filter
	public function &loadRs($filter)
	{

		// Set up filter (WHERE Clause)
		$sql = $this->getSql($filter);
		$conn = $this->getConnection();
		$rs = $conn->execute($sql);
		return $rs;
	}

	// Load row values from recordset
	public function loadListRowValues(&$rs)
	{
		$this->purchaseid->setDbValue($rs->fields('purchaseid'));
		$this->_userid->setDbValue($rs->fields('userid'));
		$this->merchantnodeid->setDbValue($rs->fields('merchantnodeid'));
		$this->merchantid->setDbValue($rs->fields('merchantid'));
		$this->merchantbusinessname->setDbValue($rs->fields('merchantbusinessname'));
		$this->merchanttransferid->setDbValue($rs->fields('merchanttransferid'));
		$this->merchantuserid->setDbValue($rs->fields('merchantuserid'));
		$this->purchasedate->setDbValue($rs->fields('purchasedate'));
		$this->txid->setDbValue($rs->fields('txid'));
		$this->userpi->setDbValue($rs->fields('userpi'));
		$this->otherconfirmref->setDbValue($rs->fields('otherconfirmref'));
		$this->currencycode->setDbValue($rs->fields('currencycode'));
		$this->purchaseamount->setDbValue($rs->fields('purchaseamount'));
		$this->tipamount->setDbValue($rs->fields('tipamount'));
		$this->merchantfees->setDbValue($rs->fields('merchantfees'));
		$this->consumerfees->setDbValue($rs->fields('consumerfees'));
		$this->transferid->setDbValue($rs->fields('transferid'));
		$this->merchantSurcharge->setDbValue($rs->fields('merchantSurcharge'));
		$this->taxAmount->setDbValue($rs->fields('taxAmount'));
		$this->totalAmounForCustomer->setDbValue($rs->fields('totalAmounForCustomer'));
		$this->feeid->setDbValue($rs->fields('feeid'));
		$this->ratetabletype->setDbValue($rs->fields('ratetabletype'));
		$this->itemdesc->setDbValue($rs->fields('itemdesc'));
		$this->shoppingCartID->setDbValue($rs->fields('shoppingCartID'));
		$this->merchantRefID->setDbValue($rs->fields('merchantRefID'));
		$this->refunded->setDbValue($rs->fields('refunded'));
		$this->tokenid->setDbValue($rs->fields('tokenid'));
		$this->cardno->setDbValue($rs->fields('cardno'));
		$this->vaultid->setDbValue($rs->fields('vaultid'));
		$this->refundrequested->setDbValue($rs->fields('refundrequested'));
		$this->refundrequesttxid->setDbValue($rs->fields('refundrequesttxid'));
		$this->feesystemshare->setDbValue($rs->fields('feesystemshare'));
		$this->feeexternalshare->setDbValue($rs->fields('feeexternalshare'));
		$this->feefranchiseeshare->setDbValue($rs->fields('feefranchiseeshare'));
		$this->feeresellershare->setDbValue($rs->fields('feeresellershare'));
		$this->_key->setDbValue($rs->fields('key'));
		$this->serviceFeeToCustomerbk1amt->setDbValue($rs->fields('serviceFeeToCustomerbk1amt'));
		$this->serviceFeeToCustomerbk1type->setDbValue($rs->fields('serviceFeeToCustomerbk1type'));
		$this->serviceFeeToCustomerbk2amt->setDbValue($rs->fields('serviceFeeToCustomerbk2amt'));
		$this->serviceFeeToCustomerbk2type->setDbValue($rs->fields('serviceFeeToCustomerbk2type'));
		$this->serviceFeeToCustomerbk3amt->setDbValue($rs->fields('serviceFeeToCustomerbk3amt'));
		$this->serviceFeeToCustomerbk3type->setDbValue($rs->fields('serviceFeeToCustomerbk3type'));
		$this->taxAmountbk1amt->setDbValue($rs->fields('taxAmountbk1amt'));
		$this->taxAmountbk1type->setDbValue($rs->fields('taxAmountbk1type'));
		$this->taxAmountbk2amt->setDbValue($rs->fields('taxAmountbk2amt'));
		$this->taxAmountbk2type->setDbValue($rs->fields('taxAmountbk2type'));
		$this->taxAmountbk3amt->setDbValue($rs->fields('taxAmountbk3amt'));
		$this->taxAmountbk3type->setDbValue($rs->fields('taxAmountbk3type'));
		$this->originalpurchaseamount->setDbValue($rs->fields('originalpurchaseamount'));
		$this->discountamount->setDbValue($rs->fields('discountamount'));
		$this->discountpercentage->setDbValue($rs->fields('discountpercentage'));
		$this->txgroupid->setDbValue($rs->fields('txgroupid'));
		$this->success_status->setDbValue($rs->fields('success_status'));
		$this->error_msg->setDbValue($rs->fields('error_msg'));
		$this->userpiid->setDbValue($rs->fields('userpiid'));
		$this->notes->setDbValue($rs->fields('notes'));
		$this->lastpurchasereaddate->setDbValue($rs->fields('lastpurchasereaddate'));
		$this->retryapicount->setDbValue($rs->fields('retryapicount'));
	}

	// Render list row values
	public function renderListRow()
	{
		global $Security, $CurrentLanguage, $Language;

		// Call Row Rendering event
		$this->Row_Rendering();

		// Common render codes
		// purchaseid
		// userid
		// merchantnodeid
		// merchantid
		// merchantbusinessname
		// merchanttransferid
		// merchantuserid
		// purchasedate
		// txid
		// userpi
		// otherconfirmref
		// currencycode
		// purchaseamount
		// tipamount
		// merchantfees
		// consumerfees
		// transferid
		// merchantSurcharge
		// taxAmount
		// totalAmounForCustomer
		// feeid
		// ratetabletype
		// itemdesc
		// shoppingCartID
		// merchantRefID
		// refunded
		// tokenid
		// cardno
		// vaultid
		// refundrequested
		// refundrequesttxid
		// feesystemshare
		// feeexternalshare
		// feefranchiseeshare
		// feeresellershare
		// key
		// serviceFeeToCustomerbk1amt
		// serviceFeeToCustomerbk1type
		// serviceFeeToCustomerbk2amt
		// serviceFeeToCustomerbk2type
		// serviceFeeToCustomerbk3amt
		// serviceFeeToCustomerbk3type
		// taxAmountbk1amt
		// taxAmountbk1type
		// taxAmountbk2amt
		// taxAmountbk2type
		// taxAmountbk3amt
		// taxAmountbk3type
		// originalpurchaseamount
		// discountamount
		// discountpercentage
		// txgroupid
		// success_status
		// error_msg
		// userpiid
		// notes
		// lastpurchasereaddate
		// retryapicount
		// purchaseid

		$this->purchaseid->ViewValue = $this->purchaseid->CurrentValue;
		$this->purchaseid->ViewCustomAttributes = "";

		// userid
		$this->_userid->ViewValue = $this->_userid->CurrentValue;
		$this->_userid->ViewCustomAttributes = "";

		// merchantnodeid
		$this->merchantnodeid->ViewValue = $this->merchantnodeid->CurrentValue;
		$this->merchantnodeid->ViewCustomAttributes = "";

		// merchantid
		$this->merchantid->ViewValue = $this->merchantid->CurrentValue;
		$this->merchantid->ViewCustomAttributes = "";

		// merchantbusinessname
		$this->merchantbusinessname->ViewValue = $this->merchantbusinessname->CurrentValue;
		$this->merchantbusinessname->ViewCustomAttributes = "";

		// merchanttransferid
		$this->merchanttransferid->ViewValue = $this->merchanttransferid->CurrentValue;
		$this->merchanttransferid->ViewCustomAttributes = "";

		// merchantuserid
		$this->merchantuserid->ViewValue = $this->merchantuserid->CurrentValue;
		$this->merchantuserid->ViewCustomAttributes = "";

		// purchasedate
		$this->purchasedate->ViewValue = $this->purchasedate->CurrentValue;
		$this->purchasedate->ViewValue = FormatDateTime($this->purchasedate->ViewValue, 1);
		$this->purchasedate->ViewCustomAttributes = "";

		// txid
		$this->txid->ViewValue = $this->txid->CurrentValue;
		$this->txid->ViewCustomAttributes = "";

		// userpi
		$this->userpi->ViewValue = $this->userpi->CurrentValue;
		$curVal = strval($this->userpi->CurrentValue);
		if ($curVal != "") {
			$this->userpi->ViewValue = $this->userpi->lookupCacheOption($curVal);
			if ($this->userpi->ViewValue === NULL) { // Lookup from database
				$filterWrk = "`id`" . SearchString("=", $curVal, DATATYPE_NUMBER, "");
				$sqlWrk = $this->userpi->Lookup->getSql(FALSE, $filterWrk, '', $this);
				$rswrk = Conn()->execute($sqlWrk);
				if ($rswrk && !$rswrk->EOF) { // Lookup values found
					$arwrk = [];
					$arwrk[1] = $rswrk->fields('df');
					$arwrk[2] = $rswrk->fields('df2');
					$this->userpi->ViewValue = $this->userpi->displayValue($arwrk);
					$rswrk->Close();
				} else {
					$this->userpi->ViewValue = $this->userpi->CurrentValue;
				}
			}
		} else {
			$this->userpi->ViewValue = NULL;
		}
		$this->userpi->ViewCustomAttributes = "";

		// otherconfirmref
		$this->otherconfirmref->ViewValue = $this->otherconfirmref->CurrentValue;
		$this->otherconfirmref->ViewCustomAttributes = "";

		// currencycode
		$this->currencycode->ViewValue = $this->currencycode->CurrentValue;
		$this->currencycode->ViewCustomAttributes = "";

		// purchaseamount
		$this->purchaseamount->ViewValue = $this->purchaseamount->CurrentValue;
		$this->purchaseamount->ViewValue = FormatNumber($this->purchaseamount->ViewValue, 2, -2, -1, -1);
		$this->purchaseamount->CellCssStyle .= "text-align: right;";
		$this->purchaseamount->ViewCustomAttributes = "";

		// tipamount
		$this->tipamount->ViewValue = $this->tipamount->CurrentValue;
		$this->tipamount->ViewValue = FormatNumber($this->tipamount->ViewValue, Config("DEFAULT_DECIMAL_PRECISION"));
		$this->tipamount->ViewCustomAttributes = "";

		// merchantfees
		$this->merchantfees->ViewValue = $this->merchantfees->CurrentValue;
		$this->merchantfees->ViewValue = FormatNumber($this->merchantfees->ViewValue, Config("DEFAULT_DECIMAL_PRECISION"));
		$this->merchantfees->ViewCustomAttributes = "";

		// consumerfees
		$this->consumerfees->ViewValue = $this->consumerfees->CurrentValue;
		$this->consumerfees->ViewValue = FormatNumber($this->consumerfees->ViewValue, Config("DEFAULT_DECIMAL_PRECISION"));
		$this->consumerfees->ViewCustomAttributes = "";

		// transferid
		$this->transferid->ViewValue = $this->transferid->CurrentValue;
		$this->transferid->ViewCustomAttributes = "";

		// merchantSurcharge
		$this->merchantSurcharge->ViewValue = $this->merchantSurcharge->CurrentValue;
		$this->merchantSurcharge->ViewValue = FormatNumber($this->merchantSurcharge->ViewValue, Config("DEFAULT_DECIMAL_PRECISION"));
		$this->merchantSurcharge->ViewCustomAttributes = "";

		// taxAmount
		$this->taxAmount->ViewValue = $this->taxAmount->CurrentValue;
		$this->taxAmount->ViewValue = FormatNumber($this->taxAmount->ViewValue, Config("DEFAULT_DECIMAL_PRECISION"));
		$this->taxAmount->ViewCustomAttributes = "";

		// totalAmounForCustomer
		$this->totalAmounForCustomer->ViewValue = $this->totalAmounForCustomer->CurrentValue;
		$this->totalAmounForCustomer->ViewValue = FormatNumber($this->totalAmounForCustomer->ViewValue, Config("DEFAULT_DECIMAL_PRECISION"));
		$this->totalAmounForCustomer->ViewCustomAttributes = "";

		// feeid
		$this->feeid->ViewValue = $this->feeid->CurrentValue;
		$this->feeid->ViewCustomAttributes = "";

		// ratetabletype
		$this->ratetabletype->ViewValue = $this->ratetabletype->CurrentValue;
		$this->ratetabletype->ViewCustomAttributes = "";

		// itemdesc
		$this->itemdesc->ViewValue = $this->itemdesc->CurrentValue;
		$this->itemdesc->ViewCustomAttributes = "";

		// shoppingCartID
		$this->shoppingCartID->ViewValue = $this->shoppingCartID->CurrentValue;
		$this->shoppingCartID->ViewCustomAttributes = "";

		// merchantRefID
		$this->merchantRefID->ViewValue = $this->merchantRefID->CurrentValue;
		$this->merchantRefID->ViewCustomAttributes = "";

		// refunded
		if (strval($this->refunded->CurrentValue) != "") {
			$this->refunded->ViewValue = $this->refunded->optionCaption($this->refunded->CurrentValue);
		} else {
			$this->refunded->ViewValue = NULL;
		}
		$this->refunded->ViewCustomAttributes = "";

		// tokenid
		$this->tokenid->ViewValue = $this->tokenid->CurrentValue;
		$this->tokenid->ViewCustomAttributes = "";

		// cardno
		$this->cardno->ViewValue = $this->cardno->CurrentValue;
		$this->cardno->ViewCustomAttributes = "";

		// vaultid
		$this->vaultid->ViewValue = $this->vaultid->CurrentValue;
		$this->vaultid->ViewCustomAttributes = "";

		// refundrequested
		$this->refundrequested->ViewValue = $this->refundrequested->CurrentValue;
		$this->refundrequested->ViewCustomAttributes = "";

		// refundrequesttxid
		$this->refundrequesttxid->ViewValue = $this->refundrequesttxid->CurrentValue;
		$this->refundrequesttxid->ViewCustomAttributes = "";

		// feesystemshare
		$this->feesystemshare->ViewValue = $this->feesystemshare->CurrentValue;
		$this->feesystemshare->ViewValue = FormatNumber($this->feesystemshare->ViewValue, Config("DEFAULT_DECIMAL_PRECISION"));
		$this->feesystemshare->ViewCustomAttributes = "";

		// feeexternalshare
		$this->feeexternalshare->ViewValue = $this->feeexternalshare->CurrentValue;
		$this->feeexternalshare->ViewValue = FormatNumber($this->feeexternalshare->ViewValue, Config("DEFAULT_DECIMAL_PRECISION"));
		$this->feeexternalshare->ViewCustomAttributes = "";

		// feefranchiseeshare
		$this->feefranchiseeshare->ViewValue = $this->feefranchiseeshare->CurrentValue;
		$this->feefranchiseeshare->ViewValue = FormatNumber($this->feefranchiseeshare->ViewValue, Config("DEFAULT_DECIMAL_PRECISION"));
		$this->feefranchiseeshare->ViewCustomAttributes = "";

		// feeresellershare
		$this->feeresellershare->ViewValue = $this->feeresellershare->CurrentValue;
		$this->feeresellershare->ViewValue = FormatNumber($this->feeresellershare->ViewValue, Config("DEFAULT_DECIMAL_PRECISION"));
		$this->feeresellershare->ViewCustomAttributes = "";

		// key
		$this->_key->ViewValue = $this->_key->CurrentValue;
		$this->_key->ViewCustomAttributes = "";

		// serviceFeeToCustomerbk1amt
		$this->serviceFeeToCustomerbk1amt->ViewValue = $this->serviceFeeToCustomerbk1amt->CurrentValue;
		$this->serviceFeeToCustomerbk1amt->ViewValue = FormatNumber($this->serviceFeeToCustomerbk1amt->ViewValue, 2, -2, -2, -2);
		$this->serviceFeeToCustomerbk1amt->ViewCustomAttributes = "";

		// serviceFeeToCustomerbk1type
		$this->serviceFeeToCustomerbk1type->ViewValue = $this->serviceFeeToCustomerbk1type->CurrentValue;
		$this->serviceFeeToCustomerbk1type->ViewCustomAttributes = "";

		// serviceFeeToCustomerbk2amt
		$this->serviceFeeToCustomerbk2amt->ViewValue = $this->serviceFeeToCustomerbk2amt->CurrentValue;
		$this->serviceFeeToCustomerbk2amt->ViewValue = FormatNumber($this->serviceFeeToCustomerbk2amt->ViewValue, 2, -2, -2, -2);
		$this->serviceFeeToCustomerbk2amt->ViewCustomAttributes = "";

		// serviceFeeToCustomerbk2type
		$this->serviceFeeToCustomerbk2type->ViewValue = $this->serviceFeeToCustomerbk2type->CurrentValue;
		$this->serviceFeeToCustomerbk2type->ViewCustomAttributes = "";

		// serviceFeeToCustomerbk3amt
		$this->serviceFeeToCustomerbk3amt->ViewValue = $this->serviceFeeToCustomerbk3amt->CurrentValue;
		$this->serviceFeeToCustomerbk3amt->ViewValue = FormatNumber($this->serviceFeeToCustomerbk3amt->ViewValue, 2, -2, -2, -2);
		$this->serviceFeeToCustomerbk3amt->ViewCustomAttributes = "";

		// serviceFeeToCustomerbk3type
		$this->serviceFeeToCustomerbk3type->ViewValue = $this->serviceFeeToCustomerbk3type->CurrentValue;
		$this->serviceFeeToCustomerbk3type->ViewCustomAttributes = "";

		// taxAmountbk1amt
		$this->taxAmountbk1amt->ViewValue = $this->taxAmountbk1amt->CurrentValue;
		$this->taxAmountbk1amt->ViewValue = FormatNumber($this->taxAmountbk1amt->ViewValue, 2, -2, -2, -2);
		$this->taxAmountbk1amt->ViewCustomAttributes = "";

		// taxAmountbk1type
		$this->taxAmountbk1type->ViewValue = $this->taxAmountbk1type->CurrentValue;
		$this->taxAmountbk1type->ViewCustomAttributes = "";

		// taxAmountbk2amt
		$this->taxAmountbk2amt->ViewValue = $this->taxAmountbk2amt->CurrentValue;
		$this->taxAmountbk2amt->ViewValue = FormatNumber($this->taxAmountbk2amt->ViewValue, 2, -2, -2, -2);
		$this->taxAmountbk2amt->ViewCustomAttributes = "";

		// taxAmountbk2type
		$this->taxAmountbk2type->ViewValue = $this->taxAmountbk2type->CurrentValue;
		$this->taxAmountbk2type->ViewCustomAttributes = "";

		// taxAmountbk3amt
		$this->taxAmountbk3amt->ViewValue = $this->taxAmountbk3amt->CurrentValue;
		$this->taxAmountbk3amt->ViewValue = FormatNumber($this->taxAmountbk3amt->ViewValue, 2, -2, -2, -2);
		$this->taxAmountbk3amt->ViewCustomAttributes = "";

		// taxAmountbk3type
		$this->taxAmountbk3type->ViewValue = $this->taxAmountbk3type->CurrentValue;
		$this->taxAmountbk3type->ViewCustomAttributes = "";

		// originalpurchaseamount
		$this->originalpurchaseamount->ViewValue = $this->originalpurchaseamount->CurrentValue;
		$this->originalpurchaseamount->ViewValue = FormatNumber($this->originalpurchaseamount->ViewValue, 2, -2, -2, -2);
		$this->originalpurchaseamount->ViewCustomAttributes = "";

		// discountamount
		$this->discountamount->ViewValue = $this->discountamount->CurrentValue;
		$this->discountamount->ViewValue = FormatNumber($this->discountamount->ViewValue, 2, -2, -2, -2);
		$this->discountamount->ViewCustomAttributes = "";

		// discountpercentage
		$this->discountpercentage->ViewValue = $this->discountpercentage->CurrentValue;
		$this->discountpercentage->ViewValue = FormatNumber($this->discountpercentage->ViewValue, 0, -2, -2, -2);
		$this->discountpercentage->ViewCustomAttributes = "";

		// txgroupid
		$this->txgroupid->ViewValue = $this->txgroupid->CurrentValue;
		$this->txgroupid->ViewValue = FormatNumber($this->txgroupid->ViewValue, 0, -2, -2, -2);
		$this->txgroupid->ViewCustomAttributes = "";

		// success_status
		if (strval($this->success_status->CurrentValue) != "") {
			$this->success_status->ViewValue = $this->success_status->optionCaption($this->success_status->CurrentValue);
		} else {
			$this->success_status->ViewValue = NULL;
		}
		$this->success_status->ViewCustomAttributes = "";

		// error_msg
		$this->error_msg->ViewValue = $this->error_msg->CurrentValue;
		$this->error_msg->ViewCustomAttributes = "";

		// userpiid
		$this->userpiid->ViewValue = $this->userpiid->CurrentValue;
		$this->userpiid->ViewValue = FormatNumber($this->userpiid->ViewValue, 0, -2, -2, -2);
		$this->userpiid->ViewCustomAttributes = "";

		// notes
		$this->notes->ViewValue = $this->notes->CurrentValue;
		$this->notes->ViewCustomAttributes = "";

		// lastpurchasereaddate
		$this->lastpurchasereaddate->ViewValue = $this->lastpurchasereaddate->CurrentValue;
		$this->lastpurchasereaddate->ViewValue = FormatDateTime($this->lastpurchasereaddate->ViewValue, 0);
		$this->lastpurchasereaddate->ViewCustomAttributes = "";

		// retryapicount
		$this->retryapicount->ViewValue = $this->retryapicount->CurrentValue;
		$this->retryapicount->ViewValue = FormatNumber($this->retryapicount->ViewValue, 0, -2, -2, -2);
		$this->retryapicount->ViewCustomAttributes = "";

		// purchaseid
		$this->purchaseid->LinkCustomAttributes = "";
		if (!EmptyValue($this->purchaseid->CurrentValue)) {
			$this->purchaseid->HrefValue = "userpurchaseview.php?showdetail=&purchaseid=" . $this->purchaseid->CurrentValue; // Add prefix/suffix
			$this->purchaseid->LinkAttrs["target"] = ""; // Add target
			if ($this->isExport())
				$this->purchaseid->HrefValue = FullUrl($this->purchaseid->HrefValue, "href");
		} else {
			$this->purchaseid->HrefValue = "";
		}
		$this->purchaseid->TooltipValue = "";

		// userid
		$this->_userid->LinkCustomAttributes = "";
		if (!EmptyValue($this->_userid->CurrentValue)) {
			$this->_userid->HrefValue = "userview.php?showdetail=&id=" . $this->_userid->CurrentValue; // Add prefix/suffix
			$this->_userid->LinkAttrs["target"] = ""; // Add target
			if ($this->isExport())
				$this->_userid->HrefValue = FullUrl($this->_userid->HrefValue, "href");
		} else {
			$this->_userid->HrefValue = "";
		}
		$this->_userid->TooltipValue = "";

		// merchantnodeid
		$this->merchantnodeid->LinkCustomAttributes = "";
		$this->merchantnodeid->HrefValue = "";
		$this->merchantnodeid->TooltipValue = "";

		// merchantid
		$this->merchantid->LinkCustomAttributes = "";
		$this->merchantid->HrefValue = "";
		$this->merchantid->TooltipValue = "";

		// merchantbusinessname
		$this->merchantbusinessname->LinkCustomAttributes = "";
		$this->merchantbusinessname->HrefValue = "";
		$this->merchantbusinessname->TooltipValue = "";

		// merchanttransferid
		$this->merchanttransferid->LinkCustomAttributes = "";
		$this->merchanttransferid->HrefValue = "";
		$this->merchanttransferid->TooltipValue = "";

		// merchantuserid
		$this->merchantuserid->LinkCustomAttributes = "";
		$this->merchantuserid->HrefValue = "";
		$this->merchantuserid->TooltipValue = "";

		// purchasedate
		$this->purchasedate->LinkCustomAttributes = "";
		$this->purchasedate->HrefValue = "";
		$this->purchasedate->TooltipValue = "";

		// txid
		$this->txid->LinkCustomAttributes = "";
		$this->txid->HrefValue = "";
		$this->txid->TooltipValue = "";

		// userpi
		$this->userpi->LinkCustomAttributes = "";
		$this->userpi->HrefValue = "";
		$this->userpi->TooltipValue = "";

		// otherconfirmref
		$this->otherconfirmref->LinkCustomAttributes = "";
		$this->otherconfirmref->HrefValue = "";
		$this->otherconfirmref->TooltipValue = "";

		// currencycode
		$this->currencycode->LinkCustomAttributes = "";
		$this->currencycode->HrefValue = "";
		$this->currencycode->TooltipValue = "";

		// purchaseamount
		$this->purchaseamount->LinkCustomAttributes = "";
		$this->purchaseamount->HrefValue = "";
		$this->purchaseamount->TooltipValue = "";

		// tipamount
		$this->tipamount->LinkCustomAttributes = "";
		$this->tipamount->HrefValue = "";
		$this->tipamount->TooltipValue = "";

		// merchantfees
		$this->merchantfees->LinkCustomAttributes = "";
		$this->merchantfees->HrefValue = "";
		$this->merchantfees->TooltipValue = "";

		// consumerfees
		$this->consumerfees->LinkCustomAttributes = "";
		$this->consumerfees->HrefValue = "";
		$this->consumerfees->TooltipValue = "";

		// transferid
		$this->transferid->LinkCustomAttributes = "";
		$this->transferid->HrefValue = "";
		$this->transferid->TooltipValue = "";

		// merchantSurcharge
		$this->merchantSurcharge->LinkCustomAttributes = "";
		$this->merchantSurcharge->HrefValue = "";
		$this->merchantSurcharge->TooltipValue = "";

		// taxAmount
		$this->taxAmount->LinkCustomAttributes = "";
		$this->taxAmount->HrefValue = "";
		$this->taxAmount->TooltipValue = "";

		// totalAmounForCustomer
		$this->totalAmounForCustomer->LinkCustomAttributes = "";
		$this->totalAmounForCustomer->HrefValue = "";
		$this->totalAmounForCustomer->TooltipValue = "";

		// feeid
		$this->feeid->LinkCustomAttributes = "";
		$this->feeid->HrefValue = "";
		$this->feeid->TooltipValue = "";

		// ratetabletype
		$this->ratetabletype->LinkCustomAttributes = "";
		$this->ratetabletype->HrefValue = "";
		$this->ratetabletype->TooltipValue = "";

		// itemdesc
		$this->itemdesc->LinkCustomAttributes = "";
		$this->itemdesc->HrefValue = "";
		$this->itemdesc->TooltipValue = "";

		// shoppingCartID
		$this->shoppingCartID->LinkCustomAttributes = "";
		$this->shoppingCartID->HrefValue = "";
		$this->shoppingCartID->TooltipValue = "";

		// merchantRefID
		$this->merchantRefID->LinkCustomAttributes = "";
		$this->merchantRefID->HrefValue = "";
		$this->merchantRefID->TooltipValue = "";

		// refunded
		$this->refunded->LinkCustomAttributes = "";
		$this->refunded->HrefValue = "";
		$this->refunded->TooltipValue = "";

		// tokenid
		$this->tokenid->LinkCustomAttributes = "";
		$this->tokenid->HrefValue = "";
		$this->tokenid->TooltipValue = "";

		// cardno
		$this->cardno->LinkCustomAttributes = "";
		$this->cardno->HrefValue = "";
		$this->cardno->TooltipValue = "";

		// vaultid
		$this->vaultid->LinkCustomAttributes = "";
		$this->vaultid->HrefValue = "";
		$this->vaultid->TooltipValue = "";

		// refundrequested
		$this->refundrequested->LinkCustomAttributes = "";
		$this->refundrequested->HrefValue = "";
		$this->refundrequested->TooltipValue = "";

		// refundrequesttxid
		$this->refundrequesttxid->LinkCustomAttributes = "";
		$this->refundrequesttxid->HrefValue = "";
		$this->refundrequesttxid->TooltipValue = "";

		// feesystemshare
		$this->feesystemshare->LinkCustomAttributes = "";
		$this->feesystemshare->HrefValue = "";
		$this->feesystemshare->TooltipValue = "";

		// feeexternalshare
		$this->feeexternalshare->LinkCustomAttributes = "";
		$this->feeexternalshare->HrefValue = "";
		$this->feeexternalshare->TooltipValue = "";

		// feefranchiseeshare
		$this->feefranchiseeshare->LinkCustomAttributes = "";
		$this->feefranchiseeshare->HrefValue = "";
		$this->feefranchiseeshare->TooltipValue = "";

		// feeresellershare
		$this->feeresellershare->LinkCustomAttributes = "";
		$this->feeresellershare->HrefValue = "";
		$this->feeresellershare->TooltipValue = "";

		// key
		$this->_key->LinkCustomAttributes = "";
		$this->_key->HrefValue = "";
		$this->_key->TooltipValue = "";

		// serviceFeeToCustomerbk1amt
		$this->serviceFeeToCustomerbk1amt->LinkCustomAttributes = "";
		$this->serviceFeeToCustomerbk1amt->HrefValue = "";
		$this->serviceFeeToCustomerbk1amt->TooltipValue = "";

		// serviceFeeToCustomerbk1type
		$this->serviceFeeToCustomerbk1type->LinkCustomAttributes = "";
		$this->serviceFeeToCustomerbk1type->HrefValue = "";
		$this->serviceFeeToCustomerbk1type->TooltipValue = "";

		// serviceFeeToCustomerbk2amt
		$this->serviceFeeToCustomerbk2amt->LinkCustomAttributes = "";
		$this->serviceFeeToCustomerbk2amt->HrefValue = "";
		$this->serviceFeeToCustomerbk2amt->TooltipValue = "";

		// serviceFeeToCustomerbk2type
		$this->serviceFeeToCustomerbk2type->LinkCustomAttributes = "";
		$this->serviceFeeToCustomerbk2type->HrefValue = "";
		$this->serviceFeeToCustomerbk2type->TooltipValue = "";

		// serviceFeeToCustomerbk3amt
		$this->serviceFeeToCustomerbk3amt->LinkCustomAttributes = "";
		$this->serviceFeeToCustomerbk3amt->HrefValue = "";
		$this->serviceFeeToCustomerbk3amt->TooltipValue = "";

		// serviceFeeToCustomerbk3type
		$this->serviceFeeToCustomerbk3type->LinkCustomAttributes = "";
		$this->serviceFeeToCustomerbk3type->HrefValue = "";
		$this->serviceFeeToCustomerbk3type->TooltipValue = "";

		// taxAmountbk1amt
		$this->taxAmountbk1amt->LinkCustomAttributes = "";
		$this->taxAmountbk1amt->HrefValue = "";
		$this->taxAmountbk1amt->TooltipValue = "";

		// taxAmountbk1type
		$this->taxAmountbk1type->LinkCustomAttributes = "";
		$this->taxAmountbk1type->HrefValue = "";
		$this->taxAmountbk1type->TooltipValue = "";

		// taxAmountbk2amt
		$this->taxAmountbk2amt->LinkCustomAttributes = "";
		$this->taxAmountbk2amt->HrefValue = "";
		$this->taxAmountbk2amt->TooltipValue = "";

		// taxAmountbk2type
		$this->taxAmountbk2type->LinkCustomAttributes = "";
		$this->taxAmountbk2type->HrefValue = "";
		$this->taxAmountbk2type->TooltipValue = "";

		// taxAmountbk3amt
		$this->taxAmountbk3amt->LinkCustomAttributes = "";
		$this->taxAmountbk3amt->HrefValue = "";
		$this->taxAmountbk3amt->TooltipValue = "";

		// taxAmountbk3type
		$this->taxAmountbk3type->LinkCustomAttributes = "";
		$this->taxAmountbk3type->HrefValue = "";
		$this->taxAmountbk3type->TooltipValue = "";

		// originalpurchaseamount
		$this->originalpurchaseamount->LinkCustomAttributes = "";
		$this->originalpurchaseamount->HrefValue = "";
		$this->originalpurchaseamount->TooltipValue = "";

		// discountamount
		$this->discountamount->LinkCustomAttributes = "";
		$this->discountamount->HrefValue = "";
		$this->discountamount->TooltipValue = "";

		// discountpercentage
		$this->discountpercentage->LinkCustomAttributes = "";
		$this->discountpercentage->HrefValue = "";
		$this->discountpercentage->TooltipValue = "";

		// txgroupid
		$this->txgroupid->LinkCustomAttributes = "";
		if (!EmptyValue($this->txgroupid->CurrentValue)) {
			$this->txgroupid->HrefValue = "transhistorylist.php?showmaster=transgroup&fk_groupID=" . $this->txgroupid->CurrentValue; // Add prefix/suffix
			$this->txgroupid->LinkAttrs["target"] = ""; // Add target
			if ($this->isExport())
				$this->txgroupid->HrefValue = FullUrl($this->txgroupid->HrefValue, "href");
		} else {
			$this->txgroupid->HrefValue = "";
		}
		$this->txgroupid->TooltipValue = "";

		// success_status
		$this->success_status->LinkCustomAttributes = "";
		$this->success_status->HrefValue = "";
		$this->success_status->TooltipValue = "";

		// error_msg
		$this->error_msg->LinkCustomAttributes = "";
		$this->error_msg->HrefValue = "";
		$this->error_msg->TooltipValue = "";

		// userpiid
		$this->userpiid->LinkCustomAttributes = "";
		$this->userpiid->HrefValue = "";
		$this->userpiid->TooltipValue = "";

		// notes
		$this->notes->LinkCustomAttributes = "";
		$this->notes->HrefValue = "";
		$this->notes->TooltipValue = "";

		// lastpurchasereaddate
		$this->lastpurchasereaddate->LinkCustomAttributes = "";
		$this->lastpurchasereaddate->HrefValue = "";
		$this->lastpurchasereaddate->TooltipValue = "";

		// retryapicount
		$this->retryapicount->LinkCustomAttributes = "";
		$this->retryapicount->HrefValue = "";
		$this->retryapicount->TooltipValue = "";

		// Call Row Rendered event
		$this->Row_Rendered();

		// Save data for Custom Template
		$this->Rows[] = $this->customTemplateFieldValues();
	}

	// Render edit row values
	public function renderEditRow()
	{
		global $Security, $CurrentLanguage, $Language;

		// Call Row Rendering event
		$this->Row_Rendering();

		// purchaseid
		$this->purchaseid->EditAttrs["class"] = "form-control";
		$this->purchaseid->EditCustomAttributes = "";
		$this->purchaseid->EditValue = $this->purchaseid->CurrentValue;
		$this->purchaseid->ViewCustomAttributes = "";

		// userid
		$this->_userid->EditAttrs["class"] = "form-control";
		$this->_userid->EditCustomAttributes = "";
		if ($this->_userid->getSessionValue() != "") {
			$this->_userid->CurrentValue = $this->_userid->getSessionValue();
			$this->_userid->ViewValue = $this->_userid->CurrentValue;
			$this->_userid->ViewCustomAttributes = "";
		} else {
			$this->_userid->EditValue = $this->_userid->CurrentValue;
			$this->_userid->PlaceHolder = RemoveHtml($this->_userid->caption());
		}

		// merchantnodeid
		$this->merchantnodeid->EditAttrs["class"] = "form-control";
		$this->merchantnodeid->EditCustomAttributes = "";
		$this->merchantnodeid->EditValue = $this->merchantnodeid->CurrentValue;
		$this->merchantnodeid->PlaceHolder = RemoveHtml($this->merchantnodeid->caption());

		// merchantid
		$this->merchantid->EditAttrs["class"] = "form-control";
		$this->merchantid->EditCustomAttributes = "";
		$this->merchantid->EditValue = $this->merchantid->CurrentValue;
		$this->merchantid->PlaceHolder = RemoveHtml($this->merchantid->caption());

		// merchantbusinessname
		$this->merchantbusinessname->EditAttrs["class"] = "form-control";
		$this->merchantbusinessname->EditCustomAttributes = "";
		if (!$this->merchantbusinessname->Raw)
			$this->merchantbusinessname->CurrentValue = HtmlDecode($this->merchantbusinessname->CurrentValue);
		$this->merchantbusinessname->EditValue = $this->merchantbusinessname->CurrentValue;
		$this->merchantbusinessname->PlaceHolder = RemoveHtml($this->merchantbusinessname->caption());

		// merchanttransferid
		$this->merchanttransferid->EditAttrs["class"] = "form-control";
		$this->merchanttransferid->EditCustomAttributes = "";
		$this->merchanttransferid->EditValue = $this->merchanttransferid->CurrentValue;
		$this->merchanttransferid->PlaceHolder = RemoveHtml($this->merchanttransferid->caption());

		// merchantuserid
		$this->merchantuserid->EditAttrs["class"] = "form-control";
		$this->merchantuserid->EditCustomAttributes = "";
		$this->merchantuserid->EditValue = $this->merchantuserid->CurrentValue;
		$this->merchantuserid->PlaceHolder = RemoveHtml($this->merchantuserid->caption());

		// purchasedate
		$this->purchasedate->EditAttrs["class"] = "form-control";
		$this->purchasedate->EditCustomAttributes = "";
		$this->purchasedate->EditValue = FormatDateTime($this->purchasedate->CurrentValue, 8);
		$this->purchasedate->PlaceHolder = RemoveHtml($this->purchasedate->caption());

		// txid
		$this->txid->EditAttrs["class"] = "form-control";
		$this->txid->EditCustomAttributes = "";
		if (!$this->txid->Raw)
			$this->txid->CurrentValue = HtmlDecode($this->txid->CurrentValue);
		$this->txid->EditValue = $this->txid->CurrentValue;
		$this->txid->PlaceHolder = RemoveHtml($this->txid->caption());

		// userpi
		$this->userpi->EditAttrs["class"] = "form-control";
		$this->userpi->EditCustomAttributes = "";
		$this->userpi->EditValue = $this->userpi->CurrentValue;
		$this->userpi->PlaceHolder = RemoveHtml($this->userpi->caption());

		// otherconfirmref
		$this->otherconfirmref->EditAttrs["class"] = "form-control";
		$this->otherconfirmref->EditCustomAttributes = "";
		if (!$this->otherconfirmref->Raw)
			$this->otherconfirmref->CurrentValue = HtmlDecode($this->otherconfirmref->CurrentValue);
		$this->otherconfirmref->EditValue = $this->otherconfirmref->CurrentValue;
		$this->otherconfirmref->PlaceHolder = RemoveHtml($this->otherconfirmref->caption());

		// currencycode
		$this->currencycode->EditAttrs["class"] = "form-control";
		$this->currencycode->EditCustomAttributes = "";
		if (!$this->currencycode->Raw)
			$this->currencycode->CurrentValue = HtmlDecode($this->currencycode->CurrentValue);
		$this->currencycode->EditValue = $this->currencycode->CurrentValue;
		$this->currencycode->PlaceHolder = RemoveHtml($this->currencycode->caption());

		// purchaseamount
		$this->purchaseamount->EditAttrs["class"] = "form-control";
		$this->purchaseamount->EditCustomAttributes = "";
		$this->purchaseamount->EditValue = $this->purchaseamount->CurrentValue;
		$this->purchaseamount->PlaceHolder = RemoveHtml($this->purchaseamount->caption());
		if (strval($this->purchaseamount->EditValue) != "" && is_numeric($this->purchaseamount->EditValue))
			$this->purchaseamount->EditValue = FormatNumber($this->purchaseamount->EditValue, -2, -2, -2, -1);
		

		// tipamount
		$this->tipamount->EditAttrs["class"] = "form-control";
		$this->tipamount->EditCustomAttributes = "";
		$this->tipamount->EditValue = $this->tipamount->CurrentValue;
		$this->tipamount->PlaceHolder = RemoveHtml($this->tipamount->caption());
		if (strval($this->tipamount->EditValue) != "" && is_numeric($this->tipamount->EditValue))
			$this->tipamount->EditValue = FormatNumber($this->tipamount->EditValue, -2, -1, -2, 0);
		

		// merchantfees
		$this->merchantfees->EditAttrs["class"] = "form-control";
		$this->merchantfees->EditCustomAttributes = "";
		$this->merchantfees->EditValue = $this->merchantfees->CurrentValue;
		$this->merchantfees->PlaceHolder = RemoveHtml($this->merchantfees->caption());
		if (strval($this->merchantfees->EditValue) != "" && is_numeric($this->merchantfees->EditValue))
			$this->merchantfees->EditValue = FormatNumber($this->merchantfees->EditValue, -2, -1, -2, 0);
		

		// consumerfees
		$this->consumerfees->EditAttrs["class"] = "form-control";
		$this->consumerfees->EditCustomAttributes = "";
		$this->consumerfees->EditValue = $this->consumerfees->CurrentValue;
		$this->consumerfees->PlaceHolder = RemoveHtml($this->consumerfees->caption());
		if (strval($this->consumerfees->EditValue) != "" && is_numeric($this->consumerfees->EditValue))
			$this->consumerfees->EditValue = FormatNumber($this->consumerfees->EditValue, -2, -1, -2, 0);
		

		// transferid
		$this->transferid->EditAttrs["class"] = "form-control";
		$this->transferid->EditCustomAttributes = "";
		$this->transferid->EditValue = $this->transferid->CurrentValue;
		$this->transferid->PlaceHolder = RemoveHtml($this->transferid->caption());

		// merchantSurcharge
		$this->merchantSurcharge->EditAttrs["class"] = "form-control";
		$this->merchantSurcharge->EditCustomAttributes = "";
		$this->merchantSurcharge->EditValue = $this->merchantSurcharge->CurrentValue;
		$this->merchantSurcharge->PlaceHolder = RemoveHtml($this->merchantSurcharge->caption());
		if (strval($this->merchantSurcharge->EditValue) != "" && is_numeric($this->merchantSurcharge->EditValue))
			$this->merchantSurcharge->EditValue = FormatNumber($this->merchantSurcharge->EditValue, -2, -1, -2, 0);
		

		// taxAmount
		$this->taxAmount->EditAttrs["class"] = "form-control";
		$this->taxAmount->EditCustomAttributes = "";
		$this->taxAmount->EditValue = $this->taxAmount->CurrentValue;
		$this->taxAmount->PlaceHolder = RemoveHtml($this->taxAmount->caption());
		if (strval($this->taxAmount->EditValue) != "" && is_numeric($this->taxAmount->EditValue))
			$this->taxAmount->EditValue = FormatNumber($this->taxAmount->EditValue, -2, -1, -2, 0);
		

		// totalAmounForCustomer
		$this->totalAmounForCustomer->EditAttrs["class"] = "form-control";
		$this->totalAmounForCustomer->EditCustomAttributes = "";
		$this->totalAmounForCustomer->EditValue = $this->totalAmounForCustomer->CurrentValue;
		$this->totalAmounForCustomer->PlaceHolder = RemoveHtml($this->totalAmounForCustomer->caption());
		if (strval($this->totalAmounForCustomer->EditValue) != "" && is_numeric($this->totalAmounForCustomer->EditValue))
			$this->totalAmounForCustomer->EditValue = FormatNumber($this->totalAmounForCustomer->EditValue, -2, -1, -2, 0);
		

		// feeid
		$this->feeid->EditAttrs["class"] = "form-control";
		$this->feeid->EditCustomAttributes = "";
		$this->feeid->EditValue = $this->feeid->CurrentValue;
		$this->feeid->PlaceHolder = RemoveHtml($this->feeid->caption());

		// ratetabletype
		$this->ratetabletype->EditAttrs["class"] = "form-control";
		$this->ratetabletype->EditCustomAttributes = "";
		$this->ratetabletype->EditValue = $this->ratetabletype->CurrentValue;
		$this->ratetabletype->PlaceHolder = RemoveHtml($this->ratetabletype->caption());

		// itemdesc
		$this->itemdesc->EditAttrs["class"] = "form-control";
		$this->itemdesc->EditCustomAttributes = "";
		if (!$this->itemdesc->Raw)
			$this->itemdesc->CurrentValue = HtmlDecode($this->itemdesc->CurrentValue);
		$this->itemdesc->EditValue = $this->itemdesc->CurrentValue;
		$this->itemdesc->PlaceHolder = RemoveHtml($this->itemdesc->caption());

		// shoppingCartID
		$this->shoppingCartID->EditAttrs["class"] = "form-control";
		$this->shoppingCartID->EditCustomAttributes = "";
		if (!$this->shoppingCartID->Raw)
			$this->shoppingCartID->CurrentValue = HtmlDecode($this->shoppingCartID->CurrentValue);
		$this->shoppingCartID->EditValue = $this->shoppingCartID->CurrentValue;
		$this->shoppingCartID->PlaceHolder = RemoveHtml($this->shoppingCartID->caption());

		// merchantRefID
		$this->merchantRefID->EditAttrs["class"] = "form-control";
		$this->merchantRefID->EditCustomAttributes = "";
		if (!$this->merchantRefID->Raw)
			$this->merchantRefID->CurrentValue = HtmlDecode($this->merchantRefID->CurrentValue);
		$this->merchantRefID->EditValue = $this->merchantRefID->CurrentValue;
		$this->merchantRefID->PlaceHolder = RemoveHtml($this->merchantRefID->caption());

		// refunded
		$this->refunded->EditAttrs["class"] = "form-control";
		$this->refunded->EditCustomAttributes = "";
		$this->refunded->EditValue = $this->refunded->options(TRUE);

		// tokenid
		$this->tokenid->EditAttrs["class"] = "form-control";
		$this->tokenid->EditCustomAttributes = "";
		if (!$this->tokenid->Raw)
			$this->tokenid->CurrentValue = HtmlDecode($this->tokenid->CurrentValue);
		$this->tokenid->EditValue = $this->tokenid->CurrentValue;
		$this->tokenid->PlaceHolder = RemoveHtml($this->tokenid->caption());

		// cardno
		$this->cardno->EditAttrs["class"] = "form-control";
		$this->cardno->EditCustomAttributes = "";
		if (!$this->cardno->Raw)
			$this->cardno->CurrentValue = HtmlDecode($this->cardno->CurrentValue);
		$this->cardno->EditValue = $this->cardno->CurrentValue;
		$this->cardno->PlaceHolder = RemoveHtml($this->cardno->caption());

		// vaultid
		$this->vaultid->EditAttrs["class"] = "form-control";
		$this->vaultid->EditCustomAttributes = "";
		$this->vaultid->EditValue = $this->vaultid->CurrentValue;
		$this->vaultid->PlaceHolder = RemoveHtml($this->vaultid->caption());

		// refundrequested
		$this->refundrequested->EditAttrs["class"] = "form-control";
		$this->refundrequested->EditCustomAttributes = "";
		$this->refundrequested->EditValue = $this->refundrequested->CurrentValue;
		$this->refundrequested->PlaceHolder = RemoveHtml($this->refundrequested->caption());

		// refundrequesttxid
		$this->refundrequesttxid->EditAttrs["class"] = "form-control";
		$this->refundrequesttxid->EditCustomAttributes = "";
		if (!$this->refundrequesttxid->Raw)
			$this->refundrequesttxid->CurrentValue = HtmlDecode($this->refundrequesttxid->CurrentValue);
		$this->refundrequesttxid->EditValue = $this->refundrequesttxid->CurrentValue;
		$this->refundrequesttxid->PlaceHolder = RemoveHtml($this->refundrequesttxid->caption());

		// feesystemshare
		$this->feesystemshare->EditAttrs["class"] = "form-control";
		$this->feesystemshare->EditCustomAttributes = "";
		$this->feesystemshare->EditValue = $this->feesystemshare->CurrentValue;
		$this->feesystemshare->PlaceHolder = RemoveHtml($this->feesystemshare->caption());
		if (strval($this->feesystemshare->EditValue) != "" && is_numeric($this->feesystemshare->EditValue))
			$this->feesystemshare->EditValue = FormatNumber($this->feesystemshare->EditValue, -2, -1, -2, 0);
		

		// feeexternalshare
		$this->feeexternalshare->EditAttrs["class"] = "form-control";
		$this->feeexternalshare->EditCustomAttributes = "";
		$this->feeexternalshare->EditValue = $this->feeexternalshare->CurrentValue;
		$this->feeexternalshare->PlaceHolder = RemoveHtml($this->feeexternalshare->caption());
		if (strval($this->feeexternalshare->EditValue) != "" && is_numeric($this->feeexternalshare->EditValue))
			$this->feeexternalshare->EditValue = FormatNumber($this->feeexternalshare->EditValue, -2, -1, -2, 0);
		

		// feefranchiseeshare
		$this->feefranchiseeshare->EditAttrs["class"] = "form-control";
		$this->feefranchiseeshare->EditCustomAttributes = "";
		$this->feefranchiseeshare->EditValue = $this->feefranchiseeshare->CurrentValue;
		$this->feefranchiseeshare->PlaceHolder = RemoveHtml($this->feefranchiseeshare->caption());
		if (strval($this->feefranchiseeshare->EditValue) != "" && is_numeric($this->feefranchiseeshare->EditValue))
			$this->feefranchiseeshare->EditValue = FormatNumber($this->feefranchiseeshare->EditValue, -2, -1, -2, 0);
		

		// feeresellershare
		$this->feeresellershare->EditAttrs["class"] = "form-control";
		$this->feeresellershare->EditCustomAttributes = "";
		$this->feeresellershare->EditValue = $this->feeresellershare->CurrentValue;
		$this->feeresellershare->PlaceHolder = RemoveHtml($this->feeresellershare->caption());
		if (strval($this->feeresellershare->EditValue) != "" && is_numeric($this->feeresellershare->EditValue))
			$this->feeresellershare->EditValue = FormatNumber($this->feeresellershare->EditValue, -2, -1, -2, 0);
		

		// key
		$this->_key->EditAttrs["class"] = "form-control";
		$this->_key->EditCustomAttributes = "";
		$this->_key->EditValue = $this->_key->CurrentValue;
		$this->_key->PlaceHolder = RemoveHtml($this->_key->caption());

		// serviceFeeToCustomerbk1amt
		$this->serviceFeeToCustomerbk1amt->EditAttrs["class"] = "form-control";
		$this->serviceFeeToCustomerbk1amt->EditCustomAttributes = "";
		$this->serviceFeeToCustomerbk1amt->EditValue = $this->serviceFeeToCustomerbk1amt->CurrentValue;
		$this->serviceFeeToCustomerbk1amt->PlaceHolder = RemoveHtml($this->serviceFeeToCustomerbk1amt->caption());
		if (strval($this->serviceFeeToCustomerbk1amt->EditValue) != "" && is_numeric($this->serviceFeeToCustomerbk1amt->EditValue))
			$this->serviceFeeToCustomerbk1amt->EditValue = FormatNumber($this->serviceFeeToCustomerbk1amt->EditValue, -2, -2, -2, -2);
		

		// serviceFeeToCustomerbk1type
		$this->serviceFeeToCustomerbk1type->EditAttrs["class"] = "form-control";
		$this->serviceFeeToCustomerbk1type->EditCustomAttributes = "";
		if (!$this->serviceFeeToCustomerbk1type->Raw)
			$this->serviceFeeToCustomerbk1type->CurrentValue = HtmlDecode($this->serviceFeeToCustomerbk1type->CurrentValue);
		$this->serviceFeeToCustomerbk1type->EditValue = $this->serviceFeeToCustomerbk1type->CurrentValue;
		$this->serviceFeeToCustomerbk1type->PlaceHolder = RemoveHtml($this->serviceFeeToCustomerbk1type->caption());

		// serviceFeeToCustomerbk2amt
		$this->serviceFeeToCustomerbk2amt->EditAttrs["class"] = "form-control";
		$this->serviceFeeToCustomerbk2amt->EditCustomAttributes = "";
		$this->serviceFeeToCustomerbk2amt->EditValue = $this->serviceFeeToCustomerbk2amt->CurrentValue;
		$this->serviceFeeToCustomerbk2amt->PlaceHolder = RemoveHtml($this->serviceFeeToCustomerbk2amt->caption());
		if (strval($this->serviceFeeToCustomerbk2amt->EditValue) != "" && is_numeric($this->serviceFeeToCustomerbk2amt->EditValue))
			$this->serviceFeeToCustomerbk2amt->EditValue = FormatNumber($this->serviceFeeToCustomerbk2amt->EditValue, -2, -2, -2, -2);
		

		// serviceFeeToCustomerbk2type
		$this->serviceFeeToCustomerbk2type->EditAttrs["class"] = "form-control";
		$this->serviceFeeToCustomerbk2type->EditCustomAttributes = "";
		if (!$this->serviceFeeToCustomerbk2type->Raw)
			$this->serviceFeeToCustomerbk2type->CurrentValue = HtmlDecode($this->serviceFeeToCustomerbk2type->CurrentValue);
		$this->serviceFeeToCustomerbk2type->EditValue = $this->serviceFeeToCustomerbk2type->CurrentValue;
		$this->serviceFeeToCustomerbk2type->PlaceHolder = RemoveHtml($this->serviceFeeToCustomerbk2type->caption());

		// serviceFeeToCustomerbk3amt
		$this->serviceFeeToCustomerbk3amt->EditAttrs["class"] = "form-control";
		$this->serviceFeeToCustomerbk3amt->EditCustomAttributes = "";
		$this->serviceFeeToCustomerbk3amt->EditValue = $this->serviceFeeToCustomerbk3amt->CurrentValue;
		$this->serviceFeeToCustomerbk3amt->PlaceHolder = RemoveHtml($this->serviceFeeToCustomerbk3amt->caption());
		if (strval($this->serviceFeeToCustomerbk3amt->EditValue) != "" && is_numeric($this->serviceFeeToCustomerbk3amt->EditValue))
			$this->serviceFeeToCustomerbk3amt->EditValue = FormatNumber($this->serviceFeeToCustomerbk3amt->EditValue, -2, -2, -2, -2);
		

		// serviceFeeToCustomerbk3type
		$this->serviceFeeToCustomerbk3type->EditAttrs["class"] = "form-control";
		$this->serviceFeeToCustomerbk3type->EditCustomAttributes = "";
		if (!$this->serviceFeeToCustomerbk3type->Raw)
			$this->serviceFeeToCustomerbk3type->CurrentValue = HtmlDecode($this->serviceFeeToCustomerbk3type->CurrentValue);
		$this->serviceFeeToCustomerbk3type->EditValue = $this->serviceFeeToCustomerbk3type->CurrentValue;
		$this->serviceFeeToCustomerbk3type->PlaceHolder = RemoveHtml($this->serviceFeeToCustomerbk3type->caption());

		// taxAmountbk1amt
		$this->taxAmountbk1amt->EditAttrs["class"] = "form-control";
		$this->taxAmountbk1amt->EditCustomAttributes = "";
		$this->taxAmountbk1amt->EditValue = $this->taxAmountbk1amt->CurrentValue;
		$this->taxAmountbk1amt->PlaceHolder = RemoveHtml($this->taxAmountbk1amt->caption());
		if (strval($this->taxAmountbk1amt->EditValue) != "" && is_numeric($this->taxAmountbk1amt->EditValue))
			$this->taxAmountbk1amt->EditValue = FormatNumber($this->taxAmountbk1amt->EditValue, -2, -2, -2, -2);
		

		// taxAmountbk1type
		$this->taxAmountbk1type->EditAttrs["class"] = "form-control";
		$this->taxAmountbk1type->EditCustomAttributes = "";
		if (!$this->taxAmountbk1type->Raw)
			$this->taxAmountbk1type->CurrentValue = HtmlDecode($this->taxAmountbk1type->CurrentValue);
		$this->taxAmountbk1type->EditValue = $this->taxAmountbk1type->CurrentValue;
		$this->taxAmountbk1type->PlaceHolder = RemoveHtml($this->taxAmountbk1type->caption());

		// taxAmountbk2amt
		$this->taxAmountbk2amt->EditAttrs["class"] = "form-control";
		$this->taxAmountbk2amt->EditCustomAttributes = "";
		$this->taxAmountbk2amt->EditValue = $this->taxAmountbk2amt->CurrentValue;
		$this->taxAmountbk2amt->PlaceHolder = RemoveHtml($this->taxAmountbk2amt->caption());
		if (strval($this->taxAmountbk2amt->EditValue) != "" && is_numeric($this->taxAmountbk2amt->EditValue))
			$this->taxAmountbk2amt->EditValue = FormatNumber($this->taxAmountbk2amt->EditValue, -2, -2, -2, -2);
		

		// taxAmountbk2type
		$this->taxAmountbk2type->EditAttrs["class"] = "form-control";
		$this->taxAmountbk2type->EditCustomAttributes = "";
		if (!$this->taxAmountbk2type->Raw)
			$this->taxAmountbk2type->CurrentValue = HtmlDecode($this->taxAmountbk2type->CurrentValue);
		$this->taxAmountbk2type->EditValue = $this->taxAmountbk2type->CurrentValue;
		$this->taxAmountbk2type->PlaceHolder = RemoveHtml($this->taxAmountbk2type->caption());

		// taxAmountbk3amt
		$this->taxAmountbk3amt->EditAttrs["class"] = "form-control";
		$this->taxAmountbk3amt->EditCustomAttributes = "";
		$this->taxAmountbk3amt->EditValue = $this->taxAmountbk3amt->CurrentValue;
		$this->taxAmountbk3amt->PlaceHolder = RemoveHtml($this->taxAmountbk3amt->caption());
		if (strval($this->taxAmountbk3amt->EditValue) != "" && is_numeric($this->taxAmountbk3amt->EditValue))
			$this->taxAmountbk3amt->EditValue = FormatNumber($this->taxAmountbk3amt->EditValue, -2, -2, -2, -2);
		

		// taxAmountbk3type
		$this->taxAmountbk3type->EditAttrs["class"] = "form-control";
		$this->taxAmountbk3type->EditCustomAttributes = "";
		if (!$this->taxAmountbk3type->Raw)
			$this->taxAmountbk3type->CurrentValue = HtmlDecode($this->taxAmountbk3type->CurrentValue);
		$this->taxAmountbk3type->EditValue = $this->taxAmountbk3type->CurrentValue;
		$this->taxAmountbk3type->PlaceHolder = RemoveHtml($this->taxAmountbk3type->caption());

		// originalpurchaseamount
		$this->originalpurchaseamount->EditAttrs["class"] = "form-control";
		$this->originalpurchaseamount->EditCustomAttributes = "";
		$this->originalpurchaseamount->EditValue = $this->originalpurchaseamount->CurrentValue;
		$this->originalpurchaseamount->PlaceHolder = RemoveHtml($this->originalpurchaseamount->caption());
		if (strval($this->originalpurchaseamount->EditValue) != "" && is_numeric($this->originalpurchaseamount->EditValue))
			$this->originalpurchaseamount->EditValue = FormatNumber($this->originalpurchaseamount->EditValue, -2, -2, -2, -2);
		

		// discountamount
		$this->discountamount->EditAttrs["class"] = "form-control";
		$this->discountamount->EditCustomAttributes = "";
		$this->discountamount->EditValue = $this->discountamount->CurrentValue;
		$this->discountamount->PlaceHolder = RemoveHtml($this->discountamount->caption());
		if (strval($this->discountamount->EditValue) != "" && is_numeric($this->discountamount->EditValue))
			$this->discountamount->EditValue = FormatNumber($this->discountamount->EditValue, -2, -2, -2, -2);
		

		// discountpercentage
		$this->discountpercentage->EditAttrs["class"] = "form-control";
		$this->discountpercentage->EditCustomAttributes = "";
		$this->discountpercentage->EditValue = $this->discountpercentage->CurrentValue;
		$this->discountpercentage->PlaceHolder = RemoveHtml($this->discountpercentage->caption());

		// txgroupid
		$this->txgroupid->EditAttrs["class"] = "form-control";
		$this->txgroupid->EditCustomAttributes = "";
		$this->txgroupid->EditValue = $this->txgroupid->CurrentValue;
		$this->txgroupid->PlaceHolder = RemoveHtml($this->txgroupid->caption());

		// success_status
		$this->success_status->EditAttrs["class"] = "form-control";
		$this->success_status->EditCustomAttributes = "";
		$this->success_status->EditValue = $this->success_status->options(TRUE);

		// error_msg
		$this->error_msg->EditAttrs["class"] = "form-control";
		$this->error_msg->EditCustomAttributes = "";
		if (!$this->error_msg->Raw)
			$this->error_msg->CurrentValue = HtmlDecode($this->error_msg->CurrentValue);
		$this->error_msg->EditValue = $this->error_msg->CurrentValue;
		$this->error_msg->PlaceHolder = RemoveHtml($this->error_msg->caption());

		// userpiid
		$this->userpiid->EditAttrs["class"] = "form-control";
		$this->userpiid->EditCustomAttributes = "";
		$this->userpiid->EditValue = $this->userpiid->CurrentValue;
		$this->userpiid->PlaceHolder = RemoveHtml($this->userpiid->caption());

		// notes
		$this->notes->EditAttrs["class"] = "form-control";
		$this->notes->EditCustomAttributes = "";
		if (!$this->notes->Raw)
			$this->notes->CurrentValue = HtmlDecode($this->notes->CurrentValue);
		$this->notes->EditValue = $this->notes->CurrentValue;
		$this->notes->PlaceHolder = RemoveHtml($this->notes->caption());

		// lastpurchasereaddate
		$this->lastpurchasereaddate->EditAttrs["class"] = "form-control";
		$this->lastpurchasereaddate->EditCustomAttributes = "";
		$this->lastpurchasereaddate->EditValue = FormatDateTime($this->lastpurchasereaddate->CurrentValue, 8);
		$this->lastpurchasereaddate->PlaceHolder = RemoveHtml($this->lastpurchasereaddate->caption());

		// retryapicount
		$this->retryapicount->EditAttrs["class"] = "form-control";
		$this->retryapicount->EditCustomAttributes = "";
		$this->retryapicount->EditValue = $this->retryapicount->CurrentValue;
		$this->retryapicount->PlaceHolder = RemoveHtml($this->retryapicount->caption());

		// Call Row Rendered event
		$this->Row_Rendered();
	}

	// Aggregate list row values
	public function aggregateListRowValues()
	{
	}

	// Aggregate list row (for rendering)
	public function aggregateListRow()
	{

		// Call Row Rendered event
		$this->Row_Rendered();
	}

	// Export data in HTML/CSV/Word/Excel/Email/PDF format
	public function exportDocument($doc, $recordset, $startRec = 1, $stopRec = 1, $exportPageType = "")
	{
		if (!$recordset || !$doc)
			return;
		if (!$doc->ExportCustom) {

			// Write header
			$doc->exportTableHeader();
			if ($doc->Horizontal) { // Horizontal format, write header
				$doc->beginExportRow();
				if ($exportPageType == "view") {
					$doc->exportCaption($this->purchaseid);
					$doc->exportCaption($this->_userid);
					$doc->exportCaption($this->merchantnodeid);
					$doc->exportCaption($this->merchantid);
					$doc->exportCaption($this->merchantbusinessname);
					$doc->exportCaption($this->merchanttransferid);
					$doc->exportCaption($this->merchantuserid);
					$doc->exportCaption($this->purchasedate);
					$doc->exportCaption($this->txid);
					$doc->exportCaption($this->userpi);
					$doc->exportCaption($this->otherconfirmref);
					$doc->exportCaption($this->currencycode);
					$doc->exportCaption($this->purchaseamount);
					$doc->exportCaption($this->tipamount);
					$doc->exportCaption($this->merchantfees);
					$doc->exportCaption($this->consumerfees);
					$doc->exportCaption($this->transferid);
					$doc->exportCaption($this->merchantSurcharge);
					$doc->exportCaption($this->taxAmount);
					$doc->exportCaption($this->totalAmounForCustomer);
					$doc->exportCaption($this->feeid);
					$doc->exportCaption($this->ratetabletype);
					$doc->exportCaption($this->itemdesc);
					$doc->exportCaption($this->shoppingCartID);
					$doc->exportCaption($this->merchantRefID);
					$doc->exportCaption($this->refunded);
					$doc->exportCaption($this->tokenid);
					$doc->exportCaption($this->cardno);
					$doc->exportCaption($this->vaultid);
					$doc->exportCaption($this->refundrequested);
					$doc->exportCaption($this->refundrequesttxid);
					$doc->exportCaption($this->feesystemshare);
					$doc->exportCaption($this->feeexternalshare);
					$doc->exportCaption($this->feefranchiseeshare);
					$doc->exportCaption($this->feeresellershare);
					$doc->exportCaption($this->_key);
					$doc->exportCaption($this->serviceFeeToCustomerbk1amt);
					$doc->exportCaption($this->serviceFeeToCustomerbk1type);
					$doc->exportCaption($this->serviceFeeToCustomerbk2amt);
					$doc->exportCaption($this->serviceFeeToCustomerbk2type);
					$doc->exportCaption($this->serviceFeeToCustomerbk3amt);
					$doc->exportCaption($this->serviceFeeToCustomerbk3type);
					$doc->exportCaption($this->taxAmountbk1amt);
					$doc->exportCaption($this->taxAmountbk1type);
					$doc->exportCaption($this->taxAmountbk2amt);
					$doc->exportCaption($this->taxAmountbk2type);
					$doc->exportCaption($this->taxAmountbk3amt);
					$doc->exportCaption($this->taxAmountbk3type);
					$doc->exportCaption($this->originalpurchaseamount);
					$doc->exportCaption($this->discountamount);
					$doc->exportCaption($this->discountpercentage);
					$doc->exportCaption($this->txgroupid);
					$doc->exportCaption($this->success_status);
					$doc->exportCaption($this->error_msg);
					$doc->exportCaption($this->userpiid);
					$doc->exportCaption($this->notes);
					$doc->exportCaption($this->lastpurchasereaddate);
					$doc->exportCaption($this->retryapicount);
				} else {
					$doc->exportCaption($this->purchaseid);
					$doc->exportCaption($this->_userid);
					$doc->exportCaption($this->merchantnodeid);
					$doc->exportCaption($this->merchantid);
					$doc->exportCaption($this->merchantbusinessname);
					$doc->exportCaption($this->merchanttransferid);
					$doc->exportCaption($this->merchantuserid);
					$doc->exportCaption($this->purchasedate);
					$doc->exportCaption($this->txid);
					$doc->exportCaption($this->userpi);
					$doc->exportCaption($this->otherconfirmref);
					$doc->exportCaption($this->currencycode);
					$doc->exportCaption($this->purchaseamount);
					$doc->exportCaption($this->tipamount);
					$doc->exportCaption($this->merchantfees);
					$doc->exportCaption($this->consumerfees);
					$doc->exportCaption($this->transferid);
					$doc->exportCaption($this->merchantSurcharge);
					$doc->exportCaption($this->taxAmount);
					$doc->exportCaption($this->totalAmounForCustomer);
					$doc->exportCaption($this->feeid);
					$doc->exportCaption($this->ratetabletype);
					$doc->exportCaption($this->itemdesc);
					$doc->exportCaption($this->shoppingCartID);
					$doc->exportCaption($this->merchantRefID);
					$doc->exportCaption($this->refunded);
					$doc->exportCaption($this->tokenid);
					$doc->exportCaption($this->cardno);
					$doc->exportCaption($this->vaultid);
					$doc->exportCaption($this->refundrequested);
					$doc->exportCaption($this->refundrequesttxid);
					$doc->exportCaption($this->feesystemshare);
					$doc->exportCaption($this->feeexternalshare);
					$doc->exportCaption($this->feefranchiseeshare);
					$doc->exportCaption($this->feeresellershare);
					$doc->exportCaption($this->serviceFeeToCustomerbk1amt);
					$doc->exportCaption($this->serviceFeeToCustomerbk1type);
					$doc->exportCaption($this->serviceFeeToCustomerbk2amt);
					$doc->exportCaption($this->serviceFeeToCustomerbk2type);
					$doc->exportCaption($this->serviceFeeToCustomerbk3amt);
					$doc->exportCaption($this->serviceFeeToCustomerbk3type);
					$doc->exportCaption($this->taxAmountbk1amt);
					$doc->exportCaption($this->taxAmountbk1type);
					$doc->exportCaption($this->taxAmountbk2amt);
					$doc->exportCaption($this->taxAmountbk2type);
					$doc->exportCaption($this->taxAmountbk3amt);
					$doc->exportCaption($this->taxAmountbk3type);
					$doc->exportCaption($this->originalpurchaseamount);
					$doc->exportCaption($this->discountamount);
					$doc->exportCaption($this->discountpercentage);
					$doc->exportCaption($this->txgroupid);
					$doc->exportCaption($this->success_status);
					$doc->exportCaption($this->error_msg);
					$doc->exportCaption($this->userpiid);
					$doc->exportCaption($this->notes);
					$doc->exportCaption($this->lastpurchasereaddate);
					$doc->exportCaption($this->retryapicount);
				}
				$doc->endExportRow();
			}
		}

		// Move to first record
		$recCnt = $startRec - 1;
		if (!$recordset->EOF) {
			$recordset->moveFirst();
			if ($startRec > 1)
				$recordset->move($startRec - 1);
		}
		while (!$recordset->EOF && $recCnt < $stopRec) {
			$recCnt++;
			if ($recCnt >= $startRec) {
				$rowCnt = $recCnt - $startRec + 1;

				// Page break
				if ($this->ExportPageBreakCount > 0) {
					if ($rowCnt > 1 && ($rowCnt - 1) % $this->ExportPageBreakCount == 0)
						$doc->exportPageBreak();
				}
				$this->loadListRowValues($recordset);

				// Render row
				$this->RowType = ROWTYPE_VIEW; // Render view
				$this->resetAttributes();
				$this->renderListRow();
				if (!$doc->ExportCustom) {
					$doc->beginExportRow($rowCnt); // Allow CSS styles if enabled
					if ($exportPageType == "view") {
						$doc->exportField($this->purchaseid);
						$doc->exportField($this->_userid);
						$doc->exportField($this->merchantnodeid);
						$doc->exportField($this->merchantid);
						$doc->exportField($this->merchantbusinessname);
						$doc->exportField($this->merchanttransferid);
						$doc->exportField($this->merchantuserid);
						$doc->exportField($this->purchasedate);
						$doc->exportField($this->txid);
						$doc->exportField($this->userpi);
						$doc->exportField($this->otherconfirmref);
						$doc->exportField($this->currencycode);
						$doc->exportField($this->purchaseamount);
						$doc->exportField($this->tipamount);
						$doc->exportField($this->merchantfees);
						$doc->exportField($this->consumerfees);
						$doc->exportField($this->transferid);
						$doc->exportField($this->merchantSurcharge);
						$doc->exportField($this->taxAmount);
						$doc->exportField($this->totalAmounForCustomer);
						$doc->exportField($this->feeid);
						$doc->exportField($this->ratetabletype);
						$doc->exportField($this->itemdesc);
						$doc->exportField($this->shoppingCartID);
						$doc->exportField($this->merchantRefID);
						$doc->exportField($this->refunded);
						$doc->exportField($this->tokenid);
						$doc->exportField($this->cardno);
						$doc->exportField($this->vaultid);
						$doc->exportField($this->refundrequested);
						$doc->exportField($this->refundrequesttxid);
						$doc->exportField($this->feesystemshare);
						$doc->exportField($this->feeexternalshare);
						$doc->exportField($this->feefranchiseeshare);
						$doc->exportField($this->feeresellershare);
						$doc->exportField($this->_key);
						$doc->exportField($this->serviceFeeToCustomerbk1amt);
						$doc->exportField($this->serviceFeeToCustomerbk1type);
						$doc->exportField($this->serviceFeeToCustomerbk2amt);
						$doc->exportField($this->serviceFeeToCustomerbk2type);
						$doc->exportField($this->serviceFeeToCustomerbk3amt);
						$doc->exportField($this->serviceFeeToCustomerbk3type);
						$doc->exportField($this->taxAmountbk1amt);
						$doc->exportField($this->taxAmountbk1type);
						$doc->exportField($this->taxAmountbk2amt);
						$doc->exportField($this->taxAmountbk2type);
						$doc->exportField($this->taxAmountbk3amt);
						$doc->exportField($this->taxAmountbk3type);
						$doc->exportField($this->originalpurchaseamount);
						$doc->exportField($this->discountamount);
						$doc->exportField($this->discountpercentage);
						$doc->exportField($this->txgroupid);
						$doc->exportField($this->success_status);
						$doc->exportField($this->error_msg);
						$doc->exportField($this->userpiid);
						$doc->exportField($this->notes);
						$doc->exportField($this->lastpurchasereaddate);
						$doc->exportField($this->retryapicount);
					} else {
						$doc->exportField($this->purchaseid);
						$doc->exportField($this->_userid);
						$doc->exportField($this->merchantnodeid);
						$doc->exportField($this->merchantid);
						$doc->exportField($this->merchantbusinessname);
						$doc->exportField($this->merchanttransferid);
						$doc->exportField($this->merchantuserid);
						$doc->exportField($this->purchasedate);
						$doc->exportField($this->txid);
						$doc->exportField($this->userpi);
						$doc->exportField($this->otherconfirmref);
						$doc->exportField($this->currencycode);
						$doc->exportField($this->purchaseamount);
						$doc->exportField($this->tipamount);
						$doc->exportField($this->merchantfees);
						$doc->exportField($this->consumerfees);
						$doc->exportField($this->transferid);
						$doc->exportField($this->merchantSurcharge);
						$doc->exportField($this->taxAmount);
						$doc->exportField($this->totalAmounForCustomer);
						$doc->exportField($this->feeid);
						$doc->exportField($this->ratetabletype);
						$doc->exportField($this->itemdesc);
						$doc->exportField($this->shoppingCartID);
						$doc->exportField($this->merchantRefID);
						$doc->exportField($this->refunded);
						$doc->exportField($this->tokenid);
						$doc->exportField($this->cardno);
						$doc->exportField($this->vaultid);
						$doc->exportField($this->refundrequested);
						$doc->exportField($this->refundrequesttxid);
						$doc->exportField($this->feesystemshare);
						$doc->exportField($this->feeexternalshare);
						$doc->exportField($this->feefranchiseeshare);
						$doc->exportField($this->feeresellershare);
						$doc->exportField($this->serviceFeeToCustomerbk1amt);
						$doc->exportField($this->serviceFeeToCustomerbk1type);
						$doc->exportField($this->serviceFeeToCustomerbk2amt);
						$doc->exportField($this->serviceFeeToCustomerbk2type);
						$doc->exportField($this->serviceFeeToCustomerbk3amt);
						$doc->exportField($this->serviceFeeToCustomerbk3type);
						$doc->exportField($this->taxAmountbk1amt);
						$doc->exportField($this->taxAmountbk1type);
						$doc->exportField($this->taxAmountbk2amt);
						$doc->exportField($this->taxAmountbk2type);
						$doc->exportField($this->taxAmountbk3amt);
						$doc->exportField($this->taxAmountbk3type);
						$doc->exportField($this->originalpurchaseamount);
						$doc->exportField($this->discountamount);
						$doc->exportField($this->discountpercentage);
						$doc->exportField($this->txgroupid);
						$doc->exportField($this->success_status);
						$doc->exportField($this->error_msg);
						$doc->exportField($this->userpiid);
						$doc->exportField($this->notes);
						$doc->exportField($this->lastpurchasereaddate);
						$doc->exportField($this->retryapicount);
					}
					$doc->endExportRow($rowCnt);
				}
			}

			// Call Row Export server event
			if ($doc->ExportCustom)
				$this->Row_Export($recordset->fields);
			$recordset->moveNext();
		}
		if (!$doc->ExportCustom) {
			$doc->exportTableFooter();
		}
	}

	// Get file data
	public function getFileData($fldparm, $key, $resize, $width = 0, $height = 0)
	{

		// No binary fields
		return FALSE;
	}

	// Write Audit Trail start/end for grid update
	public function writeAuditTrailDummy($typ)
	{
		$table = 'userpurchase';
		$usr = CurrentUserName();
		WriteAuditTrail("log", DbCurrentDateTime(), ScriptName(), $usr, $typ, $table, "", "", "", "");
	}

	// Write Audit Trail (add page)
	public function writeAuditTrailOnAdd(&$rs)
	{
		global $Language;
		if (!$this->AuditTrailOnAdd)
			return;
		$table = 'userpurchase';

		// Get key value
		$key = "";
		if ($key != "")
			$key .= Config("COMPOSITE_KEY_SEPARATOR");
		$key .= $rs['purchaseid'];

		// Write Audit Trail
		$dt = DbCurrentDateTime();
		$id = ScriptName();
		$usr = CurrentUserName();
		foreach (array_keys($rs) as $fldname) {
			if (array_key_exists($fldname, $this->fields) && $this->fields[$fldname]->DataType != DATATYPE_BLOB) { // Ignore BLOB fields
				if ($this->fields[$fldname]->HtmlTag == "PASSWORD") {
					$newvalue = $Language->phrase("PasswordMask"); // Password Field
				} elseif ($this->fields[$fldname]->DataType == DATATYPE_MEMO) {
					if (Config("AUDIT_TRAIL_TO_DATABASE"))
						$newvalue = $rs[$fldname];
					else
						$newvalue = "[MEMO]"; // Memo Field
				} elseif ($this->fields[$fldname]->DataType == DATATYPE_XML) {
					$newvalue = "[XML]"; // XML Field
				} else {
					$newvalue = $rs[$fldname];
				}
				WriteAuditTrail("log", $dt, $id, $usr, "A", $table, $fldname, $key, "", $newvalue);
			}
		}
	}

	// Write Audit Trail (edit page)
	public function writeAuditTrailOnEdit(&$rsold, &$rsnew)
	{
		global $Language;
		if (!$this->AuditTrailOnEdit)
			return;
		$table = 'userpurchase';

		// Get key value
		$key = "";
		if ($key != "")
			$key .= Config("COMPOSITE_KEY_SEPARATOR");
		$key .= $rsold['purchaseid'];

		// Write Audit Trail
		$dt = DbCurrentDateTime();
		$id = ScriptName();
		$usr = CurrentUserName();
		foreach (array_keys($rsnew) as $fldname) {
			if (array_key_exists($fldname, $this->fields) && array_key_exists($fldname, $rsold) && $this->fields[$fldname]->DataType != DATATYPE_BLOB) { // Ignore BLOB fields
				if ($this->fields[$fldname]->DataType == DATATYPE_DATE) { // DateTime field
					$modified = (FormatDateTime($rsold[$fldname], 0) != FormatDateTime($rsnew[$fldname], 0));
				} else {
					$modified = !CompareValue($rsold[$fldname], $rsnew[$fldname]);
				}
				if ($modified) {
					if ($this->fields[$fldname]->HtmlTag == "PASSWORD") { // Password Field
						$oldvalue = $Language->phrase("PasswordMask");
						$newvalue = $Language->phrase("PasswordMask");
					} elseif ($this->fields[$fldname]->DataType == DATATYPE_MEMO) { // Memo field
						if (Config("AUDIT_TRAIL_TO_DATABASE")) {
							$oldvalue = $rsold[$fldname];
							$newvalue = $rsnew[$fldname];
						} else {
							$oldvalue = "[MEMO]";
							$newvalue = "[MEMO]";
						}
					} elseif ($this->fields[$fldname]->DataType == DATATYPE_XML) { // XML field
						$oldvalue = "[XML]";
						$newvalue = "[XML]";
					} else {
						$oldvalue = $rsold[$fldname];
						$newvalue = $rsnew[$fldname];
					}
					WriteAuditTrail("log", $dt, $id, $usr, "U", $table, $fldname, $key, $oldvalue, $newvalue);
				}
			}
		}
	}

	// Write Audit Trail (delete page)
	public function writeAuditTrailOnDelete(&$rs)
	{
		global $Language;
		if (!$this->AuditTrailOnDelete)
			return;
		$table = 'userpurchase';

		// Get key value
		$key = "";
		if ($key != "")
			$key .= Config("COMPOSITE_KEY_SEPARATOR");
		$key .= $rs['purchaseid'];

		// Write Audit Trail
		$dt = DbCurrentDateTime();
		$id = ScriptName();
		$curUser = CurrentUserName();
		foreach (array_keys($rs) as $fldname) {
			if (array_key_exists($fldname, $this->fields) && $this->fields[$fldname]->DataType != DATATYPE_BLOB) { // Ignore BLOB fields
				if ($this->fields[$fldname]->HtmlTag == "PASSWORD") {
					$oldvalue = $Language->phrase("PasswordMask"); // Password Field
				} elseif ($this->fields[$fldname]->DataType == DATATYPE_MEMO) {
					if (Config("AUDIT_TRAIL_TO_DATABASE"))
						$oldvalue = $rs[$fldname];
					else
						$oldvalue = "[MEMO]"; // Memo field
				} elseif ($this->fields[$fldname]->DataType == DATATYPE_XML) {
					$oldvalue = "[XML]"; // XML field
				} else {
					$oldvalue = $rs[$fldname];
				}
				WriteAuditTrail("log", $dt, $id, $curUser, "D", $table, $fldname, $key, $oldvalue, "");
			}
		}
	}

	// Table level events
	// Recordset Selecting event
	function Recordset_Selecting(&$filter) {

		// Enter your code here
	}

	// Recordset Selected event
	function Recordset_Selected(&$rs) {

		//echo "Recordset Selected";
	}

	// Recordset Search Validated event
	function Recordset_SearchValidated() {

		// Example:
		//$this->MyField1->AdvancedSearch->SearchValue = "your search criteria"; // Search value

	}

	// Recordset Searching event
	function Recordset_Searching(&$filter) {

		// Enter your code here
	}

	// Row_Selecting event
	function Row_Selecting(&$filter) {

		// Enter your code here
	}

	// Row Selected event
	function Row_Selected(&$rs) {

		//echo "Row Selected";
	}

	// Row Inserting event
	function Row_Inserting($rsold, &$rsnew) {

		// Enter your code here
		// To cancel, set return value to FALSE

		return TRUE;
	}

	// Row Inserted event
	function Row_Inserted($rsold, &$rsnew) {

		//echo "Row Inserted"
	}

	// Row Updating event
	function Row_Updating($rsold, &$rsnew) {

		// Enter your code here
		// To cancel, set return value to FALSE

		return TRUE;
	}

	// Row Updated event
	function Row_Updated($rsold, &$rsnew) {

		//echo "Row Updated";
	}

	// Row Update Conflict event
	function Row_UpdateConflict($rsold, &$rsnew) {

		// Enter your code here
		// To ignore conflict, set return value to FALSE

		return TRUE;
	}

	// Grid Inserting event
	function Grid_Inserting() {

		// Enter your code here
		// To reject grid insert, set return value to FALSE

		return TRUE;
	}

	// Grid Inserted event
	function Grid_Inserted($rsnew) {

		//echo "Grid Inserted";
	}

	// Grid Updating event
	function Grid_Updating($rsold) {

		// Enter your code here
		// To reject grid update, set return value to FALSE

		return TRUE;
	}

	// Grid Updated event
	function Grid_Updated($rsold, $rsnew) {

		//echo "Grid Updated";
	}

	// Row Deleting event
	function Row_Deleting(&$rs) {

		// Enter your code here
		// To cancel, set return value to False

		return TRUE;
	}

	// Row Deleted event
	function Row_Deleted(&$rs) {

		//echo "Row Deleted";
	}

	// Email Sending event
	function Email_Sending($email, &$args) {

		//var_dump($email); var_dump($args); exit();
		return TRUE;
	}

	// Lookup Selecting event
	function Lookup_Selecting($fld, &$filter) {

		//var_dump($fld->Name, $fld->Lookup, $filter); // Uncomment to view the filter
		// Enter your code here

	}

	// Row Rendering event
	function Row_Rendering() {

		// Enter your code here
	}

	// Row Rendered event
	function Row_Rendered() {

		// To view properties of field class, use:
		//var_dump($this-><FieldName>);

	}

	// User ID Filtering event
	function UserID_Filtering(&$filter) {

		// Enter your code here
	}
}
?>