<?php
namespace PHPMaker2020\_4payadmin;

// Autoload
include_once "autoload.php";

// Session
if (session_status() !== PHP_SESSION_ACTIVE)
	\Delight\Cookie\Session::start(Config("COOKIE_SAMESITE")); // Init session data

// Output buffering
ob_start();
?>
<?php

// Write header
WriteHeader(FALSE);

// Create page object
$vloanlatefees_list = new vloanlatefees_list();

// Run the page
$vloanlatefees_list->run();

// Setup login status
SetupLoginStatus();
SetClientVar("login", LoginStatus());

// Global Page Rendering event (in userfn*.php)
Page_Rendering();

// Page Rendering event
$vloanlatefees_list->Page_Render();
?>
<?php include_once "header.php"; ?>
<?php if (!$vloanlatefees_list->isExport()) { ?>
<script>
var fvloanlatefeeslist, currentPageID;
loadjs.ready("head", function() {

	// Form object
	currentPageID = ew.PAGE_ID = "list";
	fvloanlatefeeslist = currentForm = new ew.Form("fvloanlatefeeslist", "list");
	fvloanlatefeeslist.formKeyCountName = '<?php echo $vloanlatefees_list->FormKeyCountName ?>';
	loadjs.done("fvloanlatefeeslist");
});
var fvloanlatefeeslistsrch;
loadjs.ready("head", function() {

	// Form object for search
	fvloanlatefeeslistsrch = currentSearchForm = new ew.Form("fvloanlatefeeslistsrch");

	// Dynamic selection lists
	// Filters

	fvloanlatefeeslistsrch.filterList = <?php echo $vloanlatefees_list->getFilterList() ?>;

	// Init search panel as collapsed
	fvloanlatefeeslistsrch.initSearchPanel = true;
	loadjs.done("fvloanlatefeeslistsrch");
});
</script>
<style type="text/css">
.ew-table-preview-row { /* main table preview row color */
	background-color: #FFFFFF; /* preview row color */
}
.ew-table-preview-row .ew-grid {
	display: table;
}
</style>
<div id="ew-preview" class="d-none"><!-- preview -->
	<div class="ew-nav-tabs"><!-- .ew-nav-tabs -->
		<ul class="nav nav-tabs"></ul>
		<div class="tab-content"><!-- .tab-content -->
			<div class="tab-pane fade active show"></div>
		</div><!-- /.tab-content -->
	</div><!-- /.ew-nav-tabs -->
</div><!-- /preview -->
<script>
loadjs.ready("head", function() {
	ew.PREVIEW_PLACEMENT = ew.CSS_FLIP ? "right" : "left";
	ew.PREVIEW_SINGLE_ROW = false;
	ew.PREVIEW_OVERLAY = false;
	loadjs("js/ewpreview.js", "preview");
});
</script>
<script>
loadjs.ready("head", function() {

	// Client script
	// Write your client script here, no need to add script tags.

});
</script>
<?php } ?>
<?php if (!$vloanlatefees_list->isExport()) { ?>
<div class="btn-toolbar ew-toolbar">
<?php if ($vloanlatefees_list->TotalRecords > 0 && $vloanlatefees_list->ExportOptions->visible()) { ?>
<?php $vloanlatefees_list->ExportOptions->render("body") ?>
<?php } ?>
<?php if ($vloanlatefees_list->ImportOptions->visible()) { ?>
<?php $vloanlatefees_list->ImportOptions->render("body") ?>
<?php } ?>
<?php if ($vloanlatefees_list->SearchOptions->visible()) { ?>
<?php $vloanlatefees_list->SearchOptions->render("body") ?>
<?php } ?>
<?php if ($vloanlatefees_list->FilterOptions->visible()) { ?>
<?php $vloanlatefees_list->FilterOptions->render("body") ?>
<?php } ?>
<div class="clearfix"></div>
</div>
<?php } ?>
<?php
$vloanlatefees_list->renderOtherOptions();
?>
<?php if ($Security->CanSearch()) { ?>
<?php if (!$vloanlatefees_list->isExport() && !$vloanlatefees->CurrentAction) { ?>
<form name="fvloanlatefeeslistsrch" id="fvloanlatefeeslistsrch" class="form-inline ew-form ew-ext-search-form" action="<?php echo CurrentPageName() ?>">
<div id="fvloanlatefeeslistsrch-search-panel" class="<?php echo $vloanlatefees_list->SearchPanelClass ?>">
<input type="hidden" name="cmd" value="search">
<input type="hidden" name="t" value="vloanlatefees">
	<div class="ew-extended-search">
<div id="xsr_<?php echo $vloanlatefees_list->SearchRowCount + 1 ?>" class="ew-row d-sm-flex">
	<div class="ew-quick-search input-group">
		<input type="text" name="<?php echo Config("TABLE_BASIC_SEARCH") ?>" id="<?php echo Config("TABLE_BASIC_SEARCH") ?>" class="form-control" value="<?php echo HtmlEncode($vloanlatefees_list->BasicSearch->getKeyword()) ?>" placeholder="<?php echo HtmlEncode($Language->phrase("Search")) ?>">
		<input type="hidden" name="<?php echo Config("TABLE_BASIC_SEARCH_TYPE") ?>" id="<?php echo Config("TABLE_BASIC_SEARCH_TYPE") ?>" value="<?php echo HtmlEncode($vloanlatefees_list->BasicSearch->getType()) ?>">
		<div class="input-group-append">
			<button class="btn btn-primary" name="btn-submit" id="btn-submit" type="submit"><?php echo $Language->phrase("SearchBtn") ?></button>
			<button type="button" data-toggle="dropdown" class="btn btn-primary dropdown-toggle dropdown-toggle-split" aria-haspopup="true" aria-expanded="false"><span id="searchtype"><?php echo $vloanlatefees_list->BasicSearch->getTypeNameShort() ?></span></button>
			<div class="dropdown-menu dropdown-menu-right">
				<a class="dropdown-item<?php if ($vloanlatefees_list->BasicSearch->getType() == "") { ?> active<?php } ?>" href="#" onclick="return ew.setSearchType(this);"><?php echo $Language->phrase("QuickSearchAuto") ?></a>
				<a class="dropdown-item<?php if ($vloanlatefees_list->BasicSearch->getType() == "=") { ?> active<?php } ?>" href="#" onclick="return ew.setSearchType(this, '=');"><?php echo $Language->phrase("QuickSearchExact") ?></a>
				<a class="dropdown-item<?php if ($vloanlatefees_list->BasicSearch->getType() == "AND") { ?> active<?php } ?>" href="#" onclick="return ew.setSearchType(this, 'AND');"><?php echo $Language->phrase("QuickSearchAll") ?></a>
				<a class="dropdown-item<?php if ($vloanlatefees_list->BasicSearch->getType() == "OR") { ?> active<?php } ?>" href="#" onclick="return ew.setSearchType(this, 'OR');"><?php echo $Language->phrase("QuickSearchAny") ?></a>
			</div>
		</div>
	</div>
</div>
	</div><!-- /.ew-extended-search -->
</div><!-- /.ew-search-panel -->
</form>
<?php } ?>
<?php } ?>
<?php $vloanlatefees_list->showPageHeader(); ?>
<?php
$vloanlatefees_list->showMessage();
?>
<?php if ($vloanlatefees_list->TotalRecords > 0 || $vloanlatefees->CurrentAction) { ?>
<div class="card ew-card ew-grid<?php if ($vloanlatefees_list->isAddOrEdit()) { ?> ew-grid-add-edit<?php } ?> vloanlatefees">
<form name="fvloanlatefeeslist" id="fvloanlatefeeslist" class="form-inline ew-form ew-list-form" action="<?php echo CurrentPageName() ?>" method="post">
<?php if ($Page->CheckToken) { ?>
<input type="hidden" name="<?php echo Config("TOKEN_NAME") ?>" value="<?php echo $Page->Token ?>">
<?php } ?>
<input type="hidden" name="t" value="vloanlatefees">
<div id="gmp_vloanlatefees" class="<?php echo ResponsiveTableClass() ?>card-body ew-grid-middle-panel">
<?php if ($vloanlatefees_list->TotalRecords > 0 || $vloanlatefees_list->isGridEdit()) { ?>
<table id="tbl_vloanlatefeeslist" class="table ew-table"><!-- .ew-table -->
<thead>
	<tr class="ew-table-header">
<?php

// Header row
$vloanlatefees->RowType = ROWTYPE_HEADER;

// Render list options
$vloanlatefees_list->renderListOptions();

// Render list options (header, left)
$vloanlatefees_list->ListOptions->render("header", "left");
?>
<?php if ($vloanlatefees_list->emailAccount->Visible) { // emailAccount ?>
	<?php if ($vloanlatefees_list->SortUrl($vloanlatefees_list->emailAccount) == "") { ?>
		<th data-name="emailAccount" class="<?php echo $vloanlatefees_list->emailAccount->headerCellClass() ?>"><div id="elh_vloanlatefees_emailAccount" class="vloanlatefees_emailAccount"><div class="ew-table-header-caption"><?php echo $vloanlatefees_list->emailAccount->caption() ?></div></div></th>
	<?php } else { ?>
		<th data-name="emailAccount" class="<?php echo $vloanlatefees_list->emailAccount->headerCellClass() ?>"><div class="ew-pointer" onclick="ew.sort(event, '<?php echo $vloanlatefees_list->SortUrl($vloanlatefees_list->emailAccount) ?>', 1);"><div id="elh_vloanlatefees_emailAccount" class="vloanlatefees_emailAccount">
			<div class="ew-table-header-btn"><span class="ew-table-header-caption"><?php echo $vloanlatefees_list->emailAccount->caption() ?><?php echo $Language->phrase("SrchLegend") ?></span><span class="ew-table-header-sort"><?php if ($vloanlatefees_list->emailAccount->getSort() == "ASC") { ?><i class="fas fa-sort-up"></i><?php } elseif ($vloanlatefees_list->emailAccount->getSort() == "DESC") { ?><i class="fas fa-sort-down"></i><?php } ?></span></div>
		</div></div></th>
	<?php } ?>
<?php } ?>
<?php if ($vloanlatefees_list->latefeeid->Visible) { // latefeeid ?>
	<?php if ($vloanlatefees_list->SortUrl($vloanlatefees_list->latefeeid) == "") { ?>
		<th data-name="latefeeid" class="<?php echo $vloanlatefees_list->latefeeid->headerCellClass() ?>"><div id="elh_vloanlatefees_latefeeid" class="vloanlatefees_latefeeid"><div class="ew-table-header-caption"><?php echo $vloanlatefees_list->latefeeid->caption() ?></div></div></th>
	<?php } else { ?>
		<th data-name="latefeeid" class="<?php echo $vloanlatefees_list->latefeeid->headerCellClass() ?>"><div class="ew-pointer" onclick="ew.sort(event, '<?php echo $vloanlatefees_list->SortUrl($vloanlatefees_list->latefeeid) ?>', 1);"><div id="elh_vloanlatefees_latefeeid" class="vloanlatefees_latefeeid">
			<div class="ew-table-header-btn"><span class="ew-table-header-caption"><?php echo $vloanlatefees_list->latefeeid->caption() ?></span><span class="ew-table-header-sort"><?php if ($vloanlatefees_list->latefeeid->getSort() == "ASC") { ?><i class="fas fa-sort-up"></i><?php } elseif ($vloanlatefees_list->latefeeid->getSort() == "DESC") { ?><i class="fas fa-sort-down"></i><?php } ?></span></div>
		</div></div></th>
	<?php } ?>
<?php } ?>
<?php if ($vloanlatefees_list->_userid->Visible) { // userid ?>
	<?php if ($vloanlatefees_list->SortUrl($vloanlatefees_list->_userid) == "") { ?>
		<th data-name="_userid" class="<?php echo $vloanlatefees_list->_userid->headerCellClass() ?>"><div id="elh_vloanlatefees__userid" class="vloanlatefees__userid"><div class="ew-table-header-caption"><?php echo $vloanlatefees_list->_userid->caption() ?></div></div></th>
	<?php } else { ?>
		<th data-name="_userid" class="<?php echo $vloanlatefees_list->_userid->headerCellClass() ?>"><div class="ew-pointer" onclick="ew.sort(event, '<?php echo $vloanlatefees_list->SortUrl($vloanlatefees_list->_userid) ?>', 1);"><div id="elh_vloanlatefees__userid" class="vloanlatefees__userid">
			<div class="ew-table-header-btn"><span class="ew-table-header-caption"><?php echo $vloanlatefees_list->_userid->caption() ?></span><span class="ew-table-header-sort"><?php if ($vloanlatefees_list->_userid->getSort() == "ASC") { ?><i class="fas fa-sort-up"></i><?php } elseif ($vloanlatefees_list->_userid->getSort() == "DESC") { ?><i class="fas fa-sort-down"></i><?php } ?></span></div>
		</div></div></th>
	<?php } ?>
<?php } ?>
<?php if ($vloanlatefees_list->currcode->Visible) { // currcode ?>
	<?php if ($vloanlatefees_list->SortUrl($vloanlatefees_list->currcode) == "") { ?>
		<th data-name="currcode" class="<?php echo $vloanlatefees_list->currcode->headerCellClass() ?>"><div id="elh_vloanlatefees_currcode" class="vloanlatefees_currcode"><div class="ew-table-header-caption"><?php echo $vloanlatefees_list->currcode->caption() ?></div></div></th>
	<?php } else { ?>
		<th data-name="currcode" class="<?php echo $vloanlatefees_list->currcode->headerCellClass() ?>"><div class="ew-pointer" onclick="ew.sort(event, '<?php echo $vloanlatefees_list->SortUrl($vloanlatefees_list->currcode) ?>', 1);"><div id="elh_vloanlatefees_currcode" class="vloanlatefees_currcode">
			<div class="ew-table-header-btn"><span class="ew-table-header-caption"><?php echo $vloanlatefees_list->currcode->caption() ?><?php echo $Language->phrase("SrchLegend") ?></span><span class="ew-table-header-sort"><?php if ($vloanlatefees_list->currcode->getSort() == "ASC") { ?><i class="fas fa-sort-up"></i><?php } elseif ($vloanlatefees_list->currcode->getSort() == "DESC") { ?><i class="fas fa-sort-down"></i><?php } ?></span></div>
		</div></div></th>
	<?php } ?>
<?php } ?>
<?php if ($vloanlatefees_list->outstandingamount->Visible) { // outstandingamount ?>
	<?php if ($vloanlatefees_list->SortUrl($vloanlatefees_list->outstandingamount) == "") { ?>
		<th data-name="outstandingamount" class="<?php echo $vloanlatefees_list->outstandingamount->headerCellClass() ?>"><div id="elh_vloanlatefees_outstandingamount" class="vloanlatefees_outstandingamount"><div class="ew-table-header-caption"><?php echo $vloanlatefees_list->outstandingamount->caption() ?></div></div></th>
	<?php } else { ?>
		<th data-name="outstandingamount" class="<?php echo $vloanlatefees_list->outstandingamount->headerCellClass() ?>"><div class="ew-pointer" onclick="ew.sort(event, '<?php echo $vloanlatefees_list->SortUrl($vloanlatefees_list->outstandingamount) ?>', 1);"><div id="elh_vloanlatefees_outstandingamount" class="vloanlatefees_outstandingamount">
			<div class="ew-table-header-btn"><span class="ew-table-header-caption"><?php echo $vloanlatefees_list->outstandingamount->caption() ?></span><span class="ew-table-header-sort"><?php if ($vloanlatefees_list->outstandingamount->getSort() == "ASC") { ?><i class="fas fa-sort-up"></i><?php } elseif ($vloanlatefees_list->outstandingamount->getSort() == "DESC") { ?><i class="fas fa-sort-down"></i><?php } ?></span></div>
		</div></div></th>
	<?php } ?>
<?php } ?>
<?php if ($vloanlatefees_list->latefee->Visible) { // latefee ?>
	<?php if ($vloanlatefees_list->SortUrl($vloanlatefees_list->latefee) == "") { ?>
		<th data-name="latefee" class="<?php echo $vloanlatefees_list->latefee->headerCellClass() ?>"><div id="elh_vloanlatefees_latefee" class="vloanlatefees_latefee"><div class="ew-table-header-caption"><?php echo $vloanlatefees_list->latefee->caption() ?></div></div></th>
	<?php } else { ?>
		<th data-name="latefee" class="<?php echo $vloanlatefees_list->latefee->headerCellClass() ?>"><div class="ew-pointer" onclick="ew.sort(event, '<?php echo $vloanlatefees_list->SortUrl($vloanlatefees_list->latefee) ?>', 1);"><div id="elh_vloanlatefees_latefee" class="vloanlatefees_latefee">
			<div class="ew-table-header-btn"><span class="ew-table-header-caption"><?php echo $vloanlatefees_list->latefee->caption() ?></span><span class="ew-table-header-sort"><?php if ($vloanlatefees_list->latefee->getSort() == "ASC") { ?><i class="fas fa-sort-up"></i><?php } elseif ($vloanlatefees_list->latefee->getSort() == "DESC") { ?><i class="fas fa-sort-down"></i><?php } ?></span></div>
		</div></div></th>
	<?php } ?>
<?php } ?>
<?php if ($vloanlatefees_list->paidamount->Visible) { // paidamount ?>
	<?php if ($vloanlatefees_list->SortUrl($vloanlatefees_list->paidamount) == "") { ?>
		<th data-name="paidamount" class="<?php echo $vloanlatefees_list->paidamount->headerCellClass() ?>"><div id="elh_vloanlatefees_paidamount" class="vloanlatefees_paidamount"><div class="ew-table-header-caption"><?php echo $vloanlatefees_list->paidamount->caption() ?></div></div></th>
	<?php } else { ?>
		<th data-name="paidamount" class="<?php echo $vloanlatefees_list->paidamount->headerCellClass() ?>"><div class="ew-pointer" onclick="ew.sort(event, '<?php echo $vloanlatefees_list->SortUrl($vloanlatefees_list->paidamount) ?>', 1);"><div id="elh_vloanlatefees_paidamount" class="vloanlatefees_paidamount">
			<div class="ew-table-header-btn"><span class="ew-table-header-caption"><?php echo $vloanlatefees_list->paidamount->caption() ?></span><span class="ew-table-header-sort"><?php if ($vloanlatefees_list->paidamount->getSort() == "ASC") { ?><i class="fas fa-sort-up"></i><?php } elseif ($vloanlatefees_list->paidamount->getSort() == "DESC") { ?><i class="fas fa-sort-down"></i><?php } ?></span></div>
		</div></div></th>
	<?php } ?>
<?php } ?>
<?php if ($vloanlatefees_list->fullypaid->Visible) { // fullypaid ?>
	<?php if ($vloanlatefees_list->SortUrl($vloanlatefees_list->fullypaid) == "") { ?>
		<th data-name="fullypaid" class="<?php echo $vloanlatefees_list->fullypaid->headerCellClass() ?>"><div id="elh_vloanlatefees_fullypaid" class="vloanlatefees_fullypaid"><div class="ew-table-header-caption"><?php echo $vloanlatefees_list->fullypaid->caption() ?></div></div></th>
	<?php } else { ?>
		<th data-name="fullypaid" class="<?php echo $vloanlatefees_list->fullypaid->headerCellClass() ?>"><div class="ew-pointer" onclick="ew.sort(event, '<?php echo $vloanlatefees_list->SortUrl($vloanlatefees_list->fullypaid) ?>', 1);"><div id="elh_vloanlatefees_fullypaid" class="vloanlatefees_fullypaid">
			<div class="ew-table-header-btn"><span class="ew-table-header-caption"><?php echo $vloanlatefees_list->fullypaid->caption() ?></span><span class="ew-table-header-sort"><?php if ($vloanlatefees_list->fullypaid->getSort() == "ASC") { ?><i class="fas fa-sort-up"></i><?php } elseif ($vloanlatefees_list->fullypaid->getSort() == "DESC") { ?><i class="fas fa-sort-down"></i><?php } ?></span></div>
		</div></div></th>
	<?php } ?>
<?php } ?>
<?php if ($vloanlatefees_list->transdate->Visible) { // transdate ?>
	<?php if ($vloanlatefees_list->SortUrl($vloanlatefees_list->transdate) == "") { ?>
		<th data-name="transdate" class="<?php echo $vloanlatefees_list->transdate->headerCellClass() ?>"><div id="elh_vloanlatefees_transdate" class="vloanlatefees_transdate"><div class="ew-table-header-caption"><?php echo $vloanlatefees_list->transdate->caption() ?></div></div></th>
	<?php } else { ?>
		<th data-name="transdate" class="<?php echo $vloanlatefees_list->transdate->headerCellClass() ?>"><div class="ew-pointer" onclick="ew.sort(event, '<?php echo $vloanlatefees_list->SortUrl($vloanlatefees_list->transdate) ?>', 1);"><div id="elh_vloanlatefees_transdate" class="vloanlatefees_transdate">
			<div class="ew-table-header-btn"><span class="ew-table-header-caption"><?php echo $vloanlatefees_list->transdate->caption() ?></span><span class="ew-table-header-sort"><?php if ($vloanlatefees_list->transdate->getSort() == "ASC") { ?><i class="fas fa-sort-up"></i><?php } elseif ($vloanlatefees_list->transdate->getSort() == "DESC") { ?><i class="fas fa-sort-down"></i><?php } ?></span></div>
		</div></div></th>
	<?php } ?>
<?php } ?>
<?php

// Render list options (header, right)
$vloanlatefees_list->ListOptions->render("header", "right");
?>
	</tr>
</thead>
<tbody>
<?php
if ($vloanlatefees_list->ExportAll && $vloanlatefees_list->isExport()) {
	$vloanlatefees_list->StopRecord = $vloanlatefees_list->TotalRecords;
} else {

	// Set the last record to display
	if ($vloanlatefees_list->TotalRecords > $vloanlatefees_list->StartRecord + $vloanlatefees_list->DisplayRecords - 1)
		$vloanlatefees_list->StopRecord = $vloanlatefees_list->StartRecord + $vloanlatefees_list->DisplayRecords - 1;
	else
		$vloanlatefees_list->StopRecord = $vloanlatefees_list->TotalRecords;
}
$vloanlatefees_list->RecordCount = $vloanlatefees_list->StartRecord - 1;
if ($vloanlatefees_list->Recordset && !$vloanlatefees_list->Recordset->EOF) {
	$vloanlatefees_list->Recordset->moveFirst();
	$selectLimit = $vloanlatefees_list->UseSelectLimit;
	if (!$selectLimit && $vloanlatefees_list->StartRecord > 1)
		$vloanlatefees_list->Recordset->move($vloanlatefees_list->StartRecord - 1);
} elseif (!$vloanlatefees->AllowAddDeleteRow && $vloanlatefees_list->StopRecord == 0) {
	$vloanlatefees_list->StopRecord = $vloanlatefees->GridAddRowCount;
}

// Initialize aggregate
$vloanlatefees->RowType = ROWTYPE_AGGREGATEINIT;
$vloanlatefees->resetAttributes();
$vloanlatefees_list->renderRow();
while ($vloanlatefees_list->RecordCount < $vloanlatefees_list->StopRecord) {
	$vloanlatefees_list->RecordCount++;
	if ($vloanlatefees_list->RecordCount >= $vloanlatefees_list->StartRecord) {
		$vloanlatefees_list->RowCount++;

		// Set up key count
		$vloanlatefees_list->KeyCount = $vloanlatefees_list->RowIndex;

		// Init row class and style
		$vloanlatefees->resetAttributes();
		$vloanlatefees->CssClass = "";
		if ($vloanlatefees_list->isGridAdd()) {
		} else {
			$vloanlatefees_list->loadRowValues($vloanlatefees_list->Recordset); // Load row values
		}
		$vloanlatefees->RowType = ROWTYPE_VIEW; // Render view

		// Set up row id / data-rowindex
		$vloanlatefees->RowAttrs->merge(["data-rowindex" => $vloanlatefees_list->RowCount, "id" => "r" . $vloanlatefees_list->RowCount . "_vloanlatefees", "data-rowtype" => $vloanlatefees->RowType]);

		// Render row
		$vloanlatefees_list->renderRow();

		// Render list options
		$vloanlatefees_list->renderListOptions();
?>
	<tr <?php echo $vloanlatefees->rowAttributes() ?>>
<?php

// Render list options (body, left)
$vloanlatefees_list->ListOptions->render("body", "left", $vloanlatefees_list->RowCount);
?>
	<?php if ($vloanlatefees_list->emailAccount->Visible) { // emailAccount ?>
		<td data-name="emailAccount" <?php echo $vloanlatefees_list->emailAccount->cellAttributes() ?>>
<span id="el<?php echo $vloanlatefees_list->RowCount ?>_vloanlatefees_emailAccount">
<span<?php echo $vloanlatefees_list->emailAccount->viewAttributes() ?>><?php echo $vloanlatefees_list->emailAccount->getViewValue() ?></span>
</span>
</td>
	<?php } ?>
	<?php if ($vloanlatefees_list->latefeeid->Visible) { // latefeeid ?>
		<td data-name="latefeeid" <?php echo $vloanlatefees_list->latefeeid->cellAttributes() ?>>
<span id="el<?php echo $vloanlatefees_list->RowCount ?>_vloanlatefees_latefeeid">
<span<?php echo $vloanlatefees_list->latefeeid->viewAttributes() ?>><?php echo $vloanlatefees_list->latefeeid->getViewValue() ?></span>
</span>
</td>
	<?php } ?>
	<?php if ($vloanlatefees_list->_userid->Visible) { // userid ?>
		<td data-name="_userid" <?php echo $vloanlatefees_list->_userid->cellAttributes() ?>>
<span id="el<?php echo $vloanlatefees_list->RowCount ?>_vloanlatefees__userid">
<span<?php echo $vloanlatefees_list->_userid->viewAttributes() ?>><?php echo $vloanlatefees_list->_userid->getViewValue() ?></span>
</span>
</td>
	<?php } ?>
	<?php if ($vloanlatefees_list->currcode->Visible) { // currcode ?>
		<td data-name="currcode" <?php echo $vloanlatefees_list->currcode->cellAttributes() ?>>
<span id="el<?php echo $vloanlatefees_list->RowCount ?>_vloanlatefees_currcode">
<span<?php echo $vloanlatefees_list->currcode->viewAttributes() ?>><?php echo $vloanlatefees_list->currcode->getViewValue() ?></span>
</span>
</td>
	<?php } ?>
	<?php if ($vloanlatefees_list->outstandingamount->Visible) { // outstandingamount ?>
		<td data-name="outstandingamount" <?php echo $vloanlatefees_list->outstandingamount->cellAttributes() ?>>
<span id="el<?php echo $vloanlatefees_list->RowCount ?>_vloanlatefees_outstandingamount">
<span<?php echo $vloanlatefees_list->outstandingamount->viewAttributes() ?>><?php echo $vloanlatefees_list->outstandingamount->getViewValue() ?></span>
</span>
</td>
	<?php } ?>
	<?php if ($vloanlatefees_list->latefee->Visible) { // latefee ?>
		<td data-name="latefee" <?php echo $vloanlatefees_list->latefee->cellAttributes() ?>>
<span id="el<?php echo $vloanlatefees_list->RowCount ?>_vloanlatefees_latefee">
<span<?php echo $vloanlatefees_list->latefee->viewAttributes() ?>><?php echo $vloanlatefees_list->latefee->getViewValue() ?></span>
</span>
</td>
	<?php } ?>
	<?php if ($vloanlatefees_list->paidamount->Visible) { // paidamount ?>
		<td data-name="paidamount" <?php echo $vloanlatefees_list->paidamount->cellAttributes() ?>>
<span id="el<?php echo $vloanlatefees_list->RowCount ?>_vloanlatefees_paidamount">
<span<?php echo $vloanlatefees_list->paidamount->viewAttributes() ?>><?php echo $vloanlatefees_list->paidamount->getViewValue() ?></span>
</span>
</td>
	<?php } ?>
	<?php if ($vloanlatefees_list->fullypaid->Visible) { // fullypaid ?>
		<td data-name="fullypaid" <?php echo $vloanlatefees_list->fullypaid->cellAttributes() ?>>
<span id="el<?php echo $vloanlatefees_list->RowCount ?>_vloanlatefees_fullypaid">
<span<?php echo $vloanlatefees_list->fullypaid->viewAttributes() ?>><?php echo $vloanlatefees_list->fullypaid->getViewValue() ?></span>
</span>
</td>
	<?php } ?>
	<?php if ($vloanlatefees_list->transdate->Visible) { // transdate ?>
		<td data-name="transdate" <?php echo $vloanlatefees_list->transdate->cellAttributes() ?>>
<span id="el<?php echo $vloanlatefees_list->RowCount ?>_vloanlatefees_transdate">
<span<?php echo $vloanlatefees_list->transdate->viewAttributes() ?>><?php echo $vloanlatefees_list->transdate->getViewValue() ?></span>
</span>
</td>
	<?php } ?>
<?php

// Render list options (body, right)
$vloanlatefees_list->ListOptions->render("body", "right", $vloanlatefees_list->RowCount);
?>
	</tr>
<?php
	}
	if (!$vloanlatefees_list->isGridAdd())
		$vloanlatefees_list->Recordset->moveNext();
}
?>
</tbody>
</table><!-- /.ew-table -->
<?php } ?>
</div><!-- /.ew-grid-middle-panel -->
<?php if (!$vloanlatefees->CurrentAction) { ?>
<input type="hidden" name="action" id="action" value="">
<?php } ?>
</form><!-- /.ew-list-form -->
<?php

// Close recordset
if ($vloanlatefees_list->Recordset)
	$vloanlatefees_list->Recordset->Close();
?>
<?php if (!$vloanlatefees_list->isExport()) { ?>
<div class="card-footer ew-grid-lower-panel">
<?php if (!$vloanlatefees_list->isGridAdd()) { ?>
<form name="ew-pager-form" class="form-inline ew-form ew-pager-form" action="<?php echo CurrentPageName() ?>">
<?php echo $vloanlatefees_list->Pager->render() ?>
</form>
<?php } ?>
<div class="ew-list-other-options">
<?php $vloanlatefees_list->OtherOptions->render("body", "bottom") ?>
</div>
<div class="clearfix"></div>
</div>
<?php } ?>
</div><!-- /.ew-grid -->
<?php } ?>
<?php if ($vloanlatefees_list->TotalRecords == 0 && !$vloanlatefees->CurrentAction) { // Show other options ?>
<div class="ew-list-other-options">
<?php $vloanlatefees_list->OtherOptions->render("body") ?>
</div>
<div class="clearfix"></div>
<?php } ?>
<?php
$vloanlatefees_list->showPageFooter();
if (Config("DEBUG"))
	echo GetDebugMessage();
?>
<?php if (!$vloanlatefees_list->isExport()) { ?>
<script>
loadjs.ready("load", function() {

	// Startup script
	// Write your table-specific startup script here
	// console.log("page loaded");

});
</script>
<?php } ?>
<?php include_once "footer.php"; ?>
<?php
$vloanlatefees_list->terminate();
?>