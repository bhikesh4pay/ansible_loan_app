<?php
namespace PHPMaker2020\_4payadmin;

// Autoload
include_once "autoload.php";

// Session
if (session_status() !== PHP_SESSION_ACTIVE)
	\Delight\Cookie\Session::start(Config("COOKIE_SAMESITE")); // Init session data

// Output buffering
ob_start();
?>
<?php

// Write header
WriteHeader(FALSE);

// Create page object
$memberpendingpayment_edit = new memberpendingpayment_edit();

// Run the page
$memberpendingpayment_edit->run();

// Setup login status
SetupLoginStatus();
SetClientVar("login", LoginStatus());

// Global Page Rendering event (in userfn*.php)
Page_Rendering();

// Page Rendering event
$memberpendingpayment_edit->Page_Render();
?>
<?php include_once "header.php"; ?>
<script>
var fmemberpendingpaymentedit, currentPageID;
loadjs.ready("head", function() {

	// Form object
	currentPageID = ew.PAGE_ID = "edit";
	fmemberpendingpaymentedit = currentForm = new ew.Form("fmemberpendingpaymentedit", "edit");

	// Validate form
	fmemberpendingpaymentedit.validate = function() {
		if (!this.validateRequired)
			return true; // Ignore validation
		var $ = jQuery, fobj = this.getForm(), $fobj = $(fobj);
		if ($fobj.find("#confirm").val() == "confirm")
			return true;
		var elm, felm, uelm, addcnt = 0;
		var $k = $fobj.find("#" + this.formKeyCountName); // Get key_count
		var rowcnt = ($k[0]) ? parseInt($k.val(), 10) : 1;
		var startcnt = (rowcnt == 0) ? 0 : 1; // Check rowcnt == 0 => Inline-Add
		var gridinsert = ["insert", "gridinsert"].includes($fobj.find("#action").val()) && $k[0];
		for (var i = startcnt; i <= rowcnt; i++) {
			var infix = ($k[0]) ? String(i) : "";
			$fobj.data("rowindex", infix);
			<?php if ($memberpendingpayment_edit->pendingid->Required) { ?>
				elm = this.getElements("x" + infix + "_pendingid");
				if (elm && !ew.isHidden(elm) && !ew.hasValue(elm))
					return this.onError(elm, "<?php echo JsEncode(str_replace("%s", $memberpendingpayment_edit->pendingid->caption(), $memberpendingpayment_edit->pendingid->RequiredErrorMessage)) ?>");
			<?php } ?>
			<?php if ($memberpendingpayment_edit->merchantid->Required) { ?>
				elm = this.getElements("x" + infix + "_merchantid");
				if (elm && !ew.isHidden(elm) && !ew.hasValue(elm))
					return this.onError(elm, "<?php echo JsEncode(str_replace("%s", $memberpendingpayment_edit->merchantid->caption(), $memberpendingpayment_edit->merchantid->RequiredErrorMessage)) ?>");
			<?php } ?>
				elm = this.getElements("x" + infix + "_merchantid");
				if (elm && !ew.checkInteger(elm.value))
					return this.onError(elm, "<?php echo JsEncode($memberpendingpayment_edit->merchantid->errorMessage()) ?>");
			<?php if ($memberpendingpayment_edit->memberid->Required) { ?>
				elm = this.getElements("x" + infix + "_memberid");
				if (elm && !ew.isHidden(elm) && !ew.hasValue(elm))
					return this.onError(elm, "<?php echo JsEncode(str_replace("%s", $memberpendingpayment_edit->memberid->caption(), $memberpendingpayment_edit->memberid->RequiredErrorMessage)) ?>");
			<?php } ?>
				elm = this.getElements("x" + infix + "_memberid");
				if (elm && !ew.checkInteger(elm.value))
					return this.onError(elm, "<?php echo JsEncode($memberpendingpayment_edit->memberid->errorMessage()) ?>");
			<?php if ($memberpendingpayment_edit->paymentdata->Required) { ?>
				elm = this.getElements("x" + infix + "_paymentdata");
				if (elm && !ew.isHidden(elm) && !ew.hasValue(elm))
					return this.onError(elm, "<?php echo JsEncode(str_replace("%s", $memberpendingpayment_edit->paymentdata->caption(), $memberpendingpayment_edit->paymentdata->RequiredErrorMessage)) ?>");
			<?php } ?>

				// Call Form_CustomValidate event
				if (!this.Form_CustomValidate(fobj))
					return false;
		}

		// Process detail forms
		var dfs = $fobj.find("input[name='detailpage']").get();
		for (var i = 0; i < dfs.length; i++) {
			var df = dfs[i], val = df.value;
			if (val && ew.forms[val])
				if (!ew.forms[val].validate())
					return false;
		}
		return true;
	}

	// Form_CustomValidate
	fmemberpendingpaymentedit.Form_CustomValidate = function(fobj) { // DO NOT CHANGE THIS LINE!

		// Your custom validation code here, return false if invalid.
		return true;
	}

	// Use JavaScript validation or not
	fmemberpendingpaymentedit.validateRequired = <?php echo Config("CLIENT_VALIDATE") ? "true" : "false" ?>;

	// Dynamic selection lists
	loadjs.done("fmemberpendingpaymentedit");
});
</script>
<script>
loadjs.ready("head", function() {

	// Client script
	// Write your client script here, no need to add script tags.

});
</script>
<?php $memberpendingpayment_edit->showPageHeader(); ?>
<?php
$memberpendingpayment_edit->showMessage();
?>
<form name="fmemberpendingpaymentedit" id="fmemberpendingpaymentedit" class="<?php echo $memberpendingpayment_edit->FormClassName ?>" action="<?php echo CurrentPageName() ?>" method="post">
<?php if ($Page->CheckToken) { ?>
<input type="hidden" name="<?php echo Config("TOKEN_NAME") ?>" value="<?php echo $Page->Token ?>">
<?php } ?>
<input type="hidden" name="t" value="memberpendingpayment">
<input type="hidden" name="action" id="action" value="update">
<input type="hidden" name="modal" value="<?php echo (int)$memberpendingpayment_edit->IsModal ?>">
<div class="ew-edit-div"><!-- page* -->
<?php if ($memberpendingpayment_edit->pendingid->Visible) { // pendingid ?>
	<div id="r_pendingid" class="form-group row">
		<label id="elh_memberpendingpayment_pendingid" class="<?php echo $memberpendingpayment_edit->LeftColumnClass ?>"><?php echo $memberpendingpayment_edit->pendingid->caption() ?><?php echo $memberpendingpayment_edit->pendingid->Required ? $Language->phrase("FieldRequiredIndicator") : "" ?></label>
		<div class="<?php echo $memberpendingpayment_edit->RightColumnClass ?>"><div <?php echo $memberpendingpayment_edit->pendingid->cellAttributes() ?>>
<span id="el_memberpendingpayment_pendingid">
<span<?php echo $memberpendingpayment_edit->pendingid->viewAttributes() ?>><input type="text" readonly class="form-control-plaintext" value="<?php echo HtmlEncode(RemoveHtml($memberpendingpayment_edit->pendingid->EditValue)) ?>"></span>
</span>
<input type="hidden" data-table="memberpendingpayment" data-field="x_pendingid" name="x_pendingid" id="x_pendingid" value="<?php echo HtmlEncode($memberpendingpayment_edit->pendingid->CurrentValue) ?>">
<?php echo $memberpendingpayment_edit->pendingid->CustomMsg ?></div></div>
	</div>
<?php } ?>
<?php if ($memberpendingpayment_edit->merchantid->Visible) { // merchantid ?>
	<div id="r_merchantid" class="form-group row">
		<label id="elh_memberpendingpayment_merchantid" for="x_merchantid" class="<?php echo $memberpendingpayment_edit->LeftColumnClass ?>"><?php echo $memberpendingpayment_edit->merchantid->caption() ?><?php echo $memberpendingpayment_edit->merchantid->Required ? $Language->phrase("FieldRequiredIndicator") : "" ?></label>
		<div class="<?php echo $memberpendingpayment_edit->RightColumnClass ?>"><div <?php echo $memberpendingpayment_edit->merchantid->cellAttributes() ?>>
<span id="el_memberpendingpayment_merchantid">
<input type="text" data-table="memberpendingpayment" data-field="x_merchantid" name="x_merchantid" id="x_merchantid" size="30" placeholder="<?php echo HtmlEncode($memberpendingpayment_edit->merchantid->getPlaceHolder()) ?>" value="<?php echo $memberpendingpayment_edit->merchantid->EditValue ?>"<?php echo $memberpendingpayment_edit->merchantid->editAttributes() ?>>
</span>
<?php echo $memberpendingpayment_edit->merchantid->CustomMsg ?></div></div>
	</div>
<?php } ?>
<?php if ($memberpendingpayment_edit->memberid->Visible) { // memberid ?>
	<div id="r_memberid" class="form-group row">
		<label id="elh_memberpendingpayment_memberid" for="x_memberid" class="<?php echo $memberpendingpayment_edit->LeftColumnClass ?>"><?php echo $memberpendingpayment_edit->memberid->caption() ?><?php echo $memberpendingpayment_edit->memberid->Required ? $Language->phrase("FieldRequiredIndicator") : "" ?></label>
		<div class="<?php echo $memberpendingpayment_edit->RightColumnClass ?>"><div <?php echo $memberpendingpayment_edit->memberid->cellAttributes() ?>>
<span id="el_memberpendingpayment_memberid">
<input type="text" data-table="memberpendingpayment" data-field="x_memberid" name="x_memberid" id="x_memberid" size="30" placeholder="<?php echo HtmlEncode($memberpendingpayment_edit->memberid->getPlaceHolder()) ?>" value="<?php echo $memberpendingpayment_edit->memberid->EditValue ?>"<?php echo $memberpendingpayment_edit->memberid->editAttributes() ?>>
</span>
<?php echo $memberpendingpayment_edit->memberid->CustomMsg ?></div></div>
	</div>
<?php } ?>
<?php if ($memberpendingpayment_edit->paymentdata->Visible) { // paymentdata ?>
	<div id="r_paymentdata" class="form-group row">
		<label id="elh_memberpendingpayment_paymentdata" for="x_paymentdata" class="<?php echo $memberpendingpayment_edit->LeftColumnClass ?>"><?php echo $memberpendingpayment_edit->paymentdata->caption() ?><?php echo $memberpendingpayment_edit->paymentdata->Required ? $Language->phrase("FieldRequiredIndicator") : "" ?></label>
		<div class="<?php echo $memberpendingpayment_edit->RightColumnClass ?>"><div <?php echo $memberpendingpayment_edit->paymentdata->cellAttributes() ?>>
<span id="el_memberpendingpayment_paymentdata">
<textarea data-table="memberpendingpayment" data-field="x_paymentdata" name="x_paymentdata" id="x_paymentdata" cols="35" rows="4" placeholder="<?php echo HtmlEncode($memberpendingpayment_edit->paymentdata->getPlaceHolder()) ?>"<?php echo $memberpendingpayment_edit->paymentdata->editAttributes() ?>><?php echo $memberpendingpayment_edit->paymentdata->EditValue ?></textarea>
</span>
<?php echo $memberpendingpayment_edit->paymentdata->CustomMsg ?></div></div>
	</div>
<?php } ?>
</div><!-- /page* -->
<?php if (!$memberpendingpayment_edit->IsModal) { ?>
<div class="form-group row"><!-- buttons .form-group -->
	<div class="<?php echo $memberpendingpayment_edit->OffsetColumnClass ?>"><!-- buttons offset -->
<button class="btn btn-primary ew-btn" name="btn-action" id="btn-action" type="submit"><?php echo $Language->phrase("SaveBtn") ?></button>
<button class="btn btn-default ew-btn" name="btn-cancel" id="btn-cancel" type="button" data-href="<?php echo $memberpendingpayment_edit->getReturnUrl() ?>"><?php echo $Language->phrase("CancelBtn") ?></button>
	</div><!-- /buttons offset -->
</div><!-- /buttons .form-group -->
<?php } ?>
</form>
<?php
$memberpendingpayment_edit->showPageFooter();
if (Config("DEBUG"))
	echo GetDebugMessage();
?>
<script>
loadjs.ready("load", function() {

	// Startup script
	// Write your table-specific startup script here
	// console.log("page loaded");

});
</script>
<?php include_once "footer.php"; ?>
<?php
$memberpendingpayment_edit->terminate();
?>