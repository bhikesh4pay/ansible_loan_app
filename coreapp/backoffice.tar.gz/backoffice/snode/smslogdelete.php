<?php
namespace PHPMaker2020\_4payadmin;

// Autoload
include_once "autoload.php";

// Session
if (session_status() !== PHP_SESSION_ACTIVE)
	\Delight\Cookie\Session::start(Config("COOKIE_SAMESITE")); // Init session data

// Output buffering
ob_start();
?>
<?php

// Write header
WriteHeader(FALSE);

// Create page object
$smslog_delete = new smslog_delete();

// Run the page
$smslog_delete->run();

// Setup login status
SetupLoginStatus();
SetClientVar("login", LoginStatus());

// Global Page Rendering event (in userfn*.php)
Page_Rendering();

// Page Rendering event
$smslog_delete->Page_Render();
?>
<?php include_once "header.php"; ?>
<script>
var fsmslogdelete, currentPageID;
loadjs.ready("head", function() {

	// Form object
	currentPageID = ew.PAGE_ID = "delete";
	fsmslogdelete = currentForm = new ew.Form("fsmslogdelete", "delete");
	loadjs.done("fsmslogdelete");
});
</script>
<script>
loadjs.ready("head", function() {

	// Client script
	// Write your client script here, no need to add script tags.

});
</script>
<?php $smslog_delete->showPageHeader(); ?>
<?php
$smslog_delete->showMessage();
?>
<form name="fsmslogdelete" id="fsmslogdelete" class="form-inline ew-form ew-delete-form" action="<?php echo CurrentPageName() ?>" method="post">
<?php if ($Page->CheckToken) { ?>
<input type="hidden" name="<?php echo Config("TOKEN_NAME") ?>" value="<?php echo $Page->Token ?>">
<?php } ?>
<input type="hidden" name="t" value="smslog">
<input type="hidden" name="action" id="action" value="delete">
<?php foreach ($smslog_delete->RecKeys as $key) { ?>
<?php $keyvalue = is_array($key) ? implode(Config("COMPOSITE_KEY_SEPARATOR"), $key) : $key; ?>
<input type="hidden" name="key_m[]" value="<?php echo HtmlEncode($keyvalue) ?>">
<?php } ?>
<div class="card ew-card ew-grid">
<div class="<?php echo ResponsiveTableClass() ?>card-body ew-grid-middle-panel">
<table class="table ew-table">
	<thead>
	<tr class="ew-table-header">
<?php if ($smslog_delete->smsid->Visible) { // smsid ?>
		<th class="<?php echo $smslog_delete->smsid->headerCellClass() ?>"><span id="elh_smslog_smsid" class="smslog_smsid"><?php echo $smslog_delete->smsid->caption() ?></span></th>
<?php } ?>
<?php if ($smslog_delete->_userid->Visible) { // userid ?>
		<th class="<?php echo $smslog_delete->_userid->headerCellClass() ?>"><span id="elh_smslog__userid" class="smslog__userid"><?php echo $smslog_delete->_userid->caption() ?></span></th>
<?php } ?>
<?php if ($smslog_delete->dt->Visible) { // dt ?>
		<th class="<?php echo $smslog_delete->dt->headerCellClass() ?>"><span id="elh_smslog_dt" class="smslog_dt"><?php echo $smslog_delete->dt->caption() ?></span></th>
<?php } ?>
<?php if ($smslog_delete->phoneno->Visible) { // phoneno ?>
		<th class="<?php echo $smslog_delete->phoneno->headerCellClass() ?>"><span id="elh_smslog_phoneno" class="smslog_phoneno"><?php echo $smslog_delete->phoneno->caption() ?></span></th>
<?php } ?>
<?php if ($smslog_delete->phonetxt->Visible) { // phonetxt ?>
		<th class="<?php echo $smslog_delete->phonetxt->headerCellClass() ?>"><span id="elh_smslog_phonetxt" class="smslog_phonetxt"><?php echo $smslog_delete->phonetxt->caption() ?></span></th>
<?php } ?>
<?php if ($smslog_delete->externalid->Visible) { // externalid ?>
		<th class="<?php echo $smslog_delete->externalid->headerCellClass() ?>"><span id="elh_smslog_externalid" class="smslog_externalid"><?php echo $smslog_delete->externalid->caption() ?></span></th>
<?php } ?>
<?php if ($smslog_delete->statusmsg->Visible) { // statusmsg ?>
		<th class="<?php echo $smslog_delete->statusmsg->headerCellClass() ?>"><span id="elh_smslog_statusmsg" class="smslog_statusmsg"><?php echo $smslog_delete->statusmsg->caption() ?></span></th>
<?php } ?>
<?php if ($smslog_delete->loanid->Visible) { // loanid ?>
		<th class="<?php echo $smslog_delete->loanid->headerCellClass() ?>"><span id="elh_smslog_loanid" class="smslog_loanid"><?php echo $smslog_delete->loanid->caption() ?></span></th>
<?php } ?>
<?php if ($smslog_delete->gatewayid->Visible) { // gatewayid ?>
		<th class="<?php echo $smslog_delete->gatewayid->headerCellClass() ?>"><span id="elh_smslog_gatewayid" class="smslog_gatewayid"><?php echo $smslog_delete->gatewayid->caption() ?></span></th>
<?php } ?>
	</tr>
	</thead>
	<tbody>
<?php
$smslog_delete->RecordCount = 0;
$i = 0;
while (!$smslog_delete->Recordset->EOF) {
	$smslog_delete->RecordCount++;
	$smslog_delete->RowCount++;

	// Set row properties
	$smslog->resetAttributes();
	$smslog->RowType = ROWTYPE_VIEW; // View

	// Get the field contents
	$smslog_delete->loadRowValues($smslog_delete->Recordset);

	// Render row
	$smslog_delete->renderRow();
?>
	<tr <?php echo $smslog->rowAttributes() ?>>
<?php if ($smslog_delete->smsid->Visible) { // smsid ?>
		<td <?php echo $smslog_delete->smsid->cellAttributes() ?>>
<span id="el<?php echo $smslog_delete->RowCount ?>_smslog_smsid" class="smslog_smsid">
<span<?php echo $smslog_delete->smsid->viewAttributes() ?>><?php echo $smslog_delete->smsid->getViewValue() ?></span>
</span>
</td>
<?php } ?>
<?php if ($smslog_delete->_userid->Visible) { // userid ?>
		<td <?php echo $smslog_delete->_userid->cellAttributes() ?>>
<span id="el<?php echo $smslog_delete->RowCount ?>_smslog__userid" class="smslog__userid">
<span<?php echo $smslog_delete->_userid->viewAttributes() ?>><?php echo $smslog_delete->_userid->getViewValue() ?></span>
</span>
</td>
<?php } ?>
<?php if ($smslog_delete->dt->Visible) { // dt ?>
		<td <?php echo $smslog_delete->dt->cellAttributes() ?>>
<span id="el<?php echo $smslog_delete->RowCount ?>_smslog_dt" class="smslog_dt">
<span<?php echo $smslog_delete->dt->viewAttributes() ?>><?php echo $smslog_delete->dt->getViewValue() ?></span>
</span>
</td>
<?php } ?>
<?php if ($smslog_delete->phoneno->Visible) { // phoneno ?>
		<td <?php echo $smslog_delete->phoneno->cellAttributes() ?>>
<span id="el<?php echo $smslog_delete->RowCount ?>_smslog_phoneno" class="smslog_phoneno">
<span<?php echo $smslog_delete->phoneno->viewAttributes() ?>><?php echo $smslog_delete->phoneno->getViewValue() ?></span>
</span>
</td>
<?php } ?>
<?php if ($smslog_delete->phonetxt->Visible) { // phonetxt ?>
		<td <?php echo $smslog_delete->phonetxt->cellAttributes() ?>>
<span id="el<?php echo $smslog_delete->RowCount ?>_smslog_phonetxt" class="smslog_phonetxt">
<span<?php echo $smslog_delete->phonetxt->viewAttributes() ?>><?php echo $smslog_delete->phonetxt->getViewValue() ?></span>
</span>
</td>
<?php } ?>
<?php if ($smslog_delete->externalid->Visible) { // externalid ?>
		<td <?php echo $smslog_delete->externalid->cellAttributes() ?>>
<span id="el<?php echo $smslog_delete->RowCount ?>_smslog_externalid" class="smslog_externalid">
<span<?php echo $smslog_delete->externalid->viewAttributes() ?>><?php echo $smslog_delete->externalid->getViewValue() ?></span>
</span>
</td>
<?php } ?>
<?php if ($smslog_delete->statusmsg->Visible) { // statusmsg ?>
		<td <?php echo $smslog_delete->statusmsg->cellAttributes() ?>>
<span id="el<?php echo $smslog_delete->RowCount ?>_smslog_statusmsg" class="smslog_statusmsg">
<span<?php echo $smslog_delete->statusmsg->viewAttributes() ?>><?php echo $smslog_delete->statusmsg->getViewValue() ?></span>
</span>
</td>
<?php } ?>
<?php if ($smslog_delete->loanid->Visible) { // loanid ?>
		<td <?php echo $smslog_delete->loanid->cellAttributes() ?>>
<span id="el<?php echo $smslog_delete->RowCount ?>_smslog_loanid" class="smslog_loanid">
<span<?php echo $smslog_delete->loanid->viewAttributes() ?>><?php if (!EmptyString($smslog_delete->loanid->getViewValue()) && $smslog_delete->loanid->linkAttributes() != "") { ?>
<a<?php echo $smslog_delete->loanid->linkAttributes() ?>><?php echo $smslog_delete->loanid->getViewValue() ?></a>
<?php } else { ?>
<?php echo $smslog_delete->loanid->getViewValue() ?>
<?php } ?></span>
</span>
</td>
<?php } ?>
<?php if ($smslog_delete->gatewayid->Visible) { // gatewayid ?>
		<td <?php echo $smslog_delete->gatewayid->cellAttributes() ?>>
<span id="el<?php echo $smslog_delete->RowCount ?>_smslog_gatewayid" class="smslog_gatewayid">
<span<?php echo $smslog_delete->gatewayid->viewAttributes() ?>><?php echo $smslog_delete->gatewayid->getViewValue() ?></span>
</span>
</td>
<?php } ?>
	</tr>
<?php
	$smslog_delete->Recordset->moveNext();
}
$smslog_delete->Recordset->close();
?>
</tbody>
</table>
</div>
</div>
<div>
<button class="btn btn-primary ew-btn" name="btn-action" id="btn-action" type="submit"><?php echo $Language->phrase("DeleteBtn") ?></button>
<button class="btn btn-default ew-btn" name="btn-cancel" id="btn-cancel" type="button" data-href="<?php echo $smslog_delete->getReturnUrl() ?>"><?php echo $Language->phrase("CancelBtn") ?></button>
</div>
</form>
<?php
$smslog_delete->showPageFooter();
if (Config("DEBUG"))
	echo GetDebugMessage();
?>
<script>
loadjs.ready("load", function() {

	// Startup script
	// Write your table-specific startup script here
	// console.log("page loaded");

});
</script>
<?php include_once "footer.php"; ?>
<?php
$smslog_delete->terminate();
?>