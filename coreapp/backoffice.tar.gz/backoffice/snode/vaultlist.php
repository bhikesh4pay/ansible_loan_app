<?php
namespace PHPMaker2020\_4payadmin;

// Autoload
include_once "autoload.php";

// Session
if (session_status() !== PHP_SESSION_ACTIVE)
	\Delight\Cookie\Session::start(Config("COOKIE_SAMESITE")); // Init session data

// Output buffering
ob_start();
?>
<?php

// Write header
WriteHeader(FALSE);

// Create page object
$vault_list = new vault_list();

// Run the page
$vault_list->run();

// Setup login status
SetupLoginStatus();
SetClientVar("login", LoginStatus());

// Global Page Rendering event (in userfn*.php)
Page_Rendering();

// Page Rendering event
$vault_list->Page_Render();
?>
<?php include_once "header.php"; ?>
<?php if (!$vault_list->isExport()) { ?>
<script>
var fvaultlist, currentPageID;
loadjs.ready("head", function() {

	// Form object
	currentPageID = ew.PAGE_ID = "list";
	fvaultlist = currentForm = new ew.Form("fvaultlist", "list");
	fvaultlist.formKeyCountName = '<?php echo $vault_list->FormKeyCountName ?>';
	loadjs.done("fvaultlist");
});
var fvaultlistsrch;
loadjs.ready("head", function() {

	// Form object for search
	fvaultlistsrch = currentSearchForm = new ew.Form("fvaultlistsrch");

	// Dynamic selection lists
	// Filters

	fvaultlistsrch.filterList = <?php echo $vault_list->getFilterList() ?>;

	// Init search panel as collapsed
	fvaultlistsrch.initSearchPanel = true;
	loadjs.done("fvaultlistsrch");
});
</script>
<style type="text/css">
.ew-table-preview-row { /* main table preview row color */
	background-color: #FFFFFF; /* preview row color */
}
.ew-table-preview-row .ew-grid {
	display: table;
}
</style>
<div id="ew-preview" class="d-none"><!-- preview -->
	<div class="ew-nav-tabs"><!-- .ew-nav-tabs -->
		<ul class="nav nav-tabs"></ul>
		<div class="tab-content"><!-- .tab-content -->
			<div class="tab-pane fade active show"></div>
		</div><!-- /.tab-content -->
	</div><!-- /.ew-nav-tabs -->
</div><!-- /preview -->
<script>
loadjs.ready("head", function() {
	ew.PREVIEW_PLACEMENT = ew.CSS_FLIP ? "right" : "left";
	ew.PREVIEW_SINGLE_ROW = false;
	ew.PREVIEW_OVERLAY = false;
	loadjs("js/ewpreview.js", "preview");
});
</script>
<script>
loadjs.ready("head", function() {

	// Client script
	// Write your client script here, no need to add script tags.

});
</script>
<?php } ?>
<?php if (!$vault_list->isExport()) { ?>
<div class="btn-toolbar ew-toolbar">
<?php if ($vault_list->TotalRecords > 0 && $vault_list->ExportOptions->visible()) { ?>
<?php $vault_list->ExportOptions->render("body") ?>
<?php } ?>
<?php if ($vault_list->ImportOptions->visible()) { ?>
<?php $vault_list->ImportOptions->render("body") ?>
<?php } ?>
<?php if ($vault_list->SearchOptions->visible()) { ?>
<?php $vault_list->SearchOptions->render("body") ?>
<?php } ?>
<?php if ($vault_list->FilterOptions->visible()) { ?>
<?php $vault_list->FilterOptions->render("body") ?>
<?php } ?>
<div class="clearfix"></div>
</div>
<?php } ?>
<?php
$vault_list->renderOtherOptions();
?>
<?php if ($Security->CanSearch()) { ?>
<?php if (!$vault_list->isExport() && !$vault->CurrentAction) { ?>
<form name="fvaultlistsrch" id="fvaultlistsrch" class="form-inline ew-form ew-ext-search-form" action="<?php echo CurrentPageName() ?>">
<div id="fvaultlistsrch-search-panel" class="<?php echo $vault_list->SearchPanelClass ?>">
<input type="hidden" name="cmd" value="search">
<input type="hidden" name="t" value="vault">
	<div class="ew-extended-search">
<div id="xsr_<?php echo $vault_list->SearchRowCount + 1 ?>" class="ew-row d-sm-flex">
	<div class="ew-quick-search input-group">
		<input type="text" name="<?php echo Config("TABLE_BASIC_SEARCH") ?>" id="<?php echo Config("TABLE_BASIC_SEARCH") ?>" class="form-control" value="<?php echo HtmlEncode($vault_list->BasicSearch->getKeyword()) ?>" placeholder="<?php echo HtmlEncode($Language->phrase("Search")) ?>">
		<input type="hidden" name="<?php echo Config("TABLE_BASIC_SEARCH_TYPE") ?>" id="<?php echo Config("TABLE_BASIC_SEARCH_TYPE") ?>" value="<?php echo HtmlEncode($vault_list->BasicSearch->getType()) ?>">
		<div class="input-group-append">
			<button class="btn btn-primary" name="btn-submit" id="btn-submit" type="submit"><?php echo $Language->phrase("SearchBtn") ?></button>
			<button type="button" data-toggle="dropdown" class="btn btn-primary dropdown-toggle dropdown-toggle-split" aria-haspopup="true" aria-expanded="false"><span id="searchtype"><?php echo $vault_list->BasicSearch->getTypeNameShort() ?></span></button>
			<div class="dropdown-menu dropdown-menu-right">
				<a class="dropdown-item<?php if ($vault_list->BasicSearch->getType() == "") { ?> active<?php } ?>" href="#" onclick="return ew.setSearchType(this);"><?php echo $Language->phrase("QuickSearchAuto") ?></a>
				<a class="dropdown-item<?php if ($vault_list->BasicSearch->getType() == "=") { ?> active<?php } ?>" href="#" onclick="return ew.setSearchType(this, '=');"><?php echo $Language->phrase("QuickSearchExact") ?></a>
				<a class="dropdown-item<?php if ($vault_list->BasicSearch->getType() == "AND") { ?> active<?php } ?>" href="#" onclick="return ew.setSearchType(this, 'AND');"><?php echo $Language->phrase("QuickSearchAll") ?></a>
				<a class="dropdown-item<?php if ($vault_list->BasicSearch->getType() == "OR") { ?> active<?php } ?>" href="#" onclick="return ew.setSearchType(this, 'OR');"><?php echo $Language->phrase("QuickSearchAny") ?></a>
			</div>
		</div>
	</div>
</div>
	</div><!-- /.ew-extended-search -->
</div><!-- /.ew-search-panel -->
</form>
<?php } ?>
<?php } ?>
<?php $vault_list->showPageHeader(); ?>
<?php
$vault_list->showMessage();
?>
<?php if ($vault_list->TotalRecords > 0 || $vault->CurrentAction) { ?>
<div class="card ew-card ew-grid<?php if ($vault_list->isAddOrEdit()) { ?> ew-grid-add-edit<?php } ?> vault">
<form name="fvaultlist" id="fvaultlist" class="form-inline ew-form ew-list-form" action="<?php echo CurrentPageName() ?>" method="post">
<?php if ($Page->CheckToken) { ?>
<input type="hidden" name="<?php echo Config("TOKEN_NAME") ?>" value="<?php echo $Page->Token ?>">
<?php } ?>
<input type="hidden" name="t" value="vault">
<div id="gmp_vault" class="<?php echo ResponsiveTableClass() ?>card-body ew-grid-middle-panel">
<?php if ($vault_list->TotalRecords > 0 || $vault_list->isGridEdit()) { ?>
<table id="tbl_vaultlist" class="table ew-table"><!-- .ew-table -->
<thead>
	<tr class="ew-table-header">
<?php

// Header row
$vault->RowType = ROWTYPE_HEADER;

// Render list options
$vault_list->renderListOptions();

// Render list options (header, left)
$vault_list->ListOptions->render("header", "left");
?>
<?php if ($vault_list->vaultid->Visible) { // vaultid ?>
	<?php if ($vault_list->SortUrl($vault_list->vaultid) == "") { ?>
		<th data-name="vaultid" class="<?php echo $vault_list->vaultid->headerCellClass() ?>"><div id="elh_vault_vaultid" class="vault_vaultid"><div class="ew-table-header-caption"><?php echo $vault_list->vaultid->caption() ?></div></div></th>
	<?php } else { ?>
		<th data-name="vaultid" class="<?php echo $vault_list->vaultid->headerCellClass() ?>"><div class="ew-pointer" onclick="ew.sort(event, '<?php echo $vault_list->SortUrl($vault_list->vaultid) ?>', 1);"><div id="elh_vault_vaultid" class="vault_vaultid">
			<div class="ew-table-header-btn"><span class="ew-table-header-caption"><?php echo $vault_list->vaultid->caption() ?></span><span class="ew-table-header-sort"><?php if ($vault_list->vaultid->getSort() == "ASC") { ?><i class="fas fa-sort-up"></i><?php } elseif ($vault_list->vaultid->getSort() == "DESC") { ?><i class="fas fa-sort-down"></i><?php } ?></span></div>
		</div></div></th>
	<?php } ?>
<?php } ?>
<?php if ($vault_list->modulename->Visible) { // modulename ?>
	<?php if ($vault_list->SortUrl($vault_list->modulename) == "") { ?>
		<th data-name="modulename" class="<?php echo $vault_list->modulename->headerCellClass() ?>"><div id="elh_vault_modulename" class="vault_modulename"><div class="ew-table-header-caption"><?php echo $vault_list->modulename->caption() ?></div></div></th>
	<?php } else { ?>
		<th data-name="modulename" class="<?php echo $vault_list->modulename->headerCellClass() ?>"><div class="ew-pointer" onclick="ew.sort(event, '<?php echo $vault_list->SortUrl($vault_list->modulename) ?>', 1);"><div id="elh_vault_modulename" class="vault_modulename">
			<div class="ew-table-header-btn"><span class="ew-table-header-caption"><?php echo $vault_list->modulename->caption() ?><?php echo $Language->phrase("SrchLegend") ?></span><span class="ew-table-header-sort"><?php if ($vault_list->modulename->getSort() == "ASC") { ?><i class="fas fa-sort-up"></i><?php } elseif ($vault_list->modulename->getSort() == "DESC") { ?><i class="fas fa-sort-down"></i><?php } ?></span></div>
		</div></div></th>
	<?php } ?>
<?php } ?>
<?php if ($vault_list->_addurl->Visible) { // addurl ?>
	<?php if ($vault_list->SortUrl($vault_list->_addurl) == "") { ?>
		<th data-name="_addurl" class="<?php echo $vault_list->_addurl->headerCellClass() ?>"><div id="elh_vault__addurl" class="vault__addurl"><div class="ew-table-header-caption"><?php echo $vault_list->_addurl->caption() ?></div></div></th>
	<?php } else { ?>
		<th data-name="_addurl" class="<?php echo $vault_list->_addurl->headerCellClass() ?>"><div class="ew-pointer" onclick="ew.sort(event, '<?php echo $vault_list->SortUrl($vault_list->_addurl) ?>', 1);"><div id="elh_vault__addurl" class="vault__addurl">
			<div class="ew-table-header-btn"><span class="ew-table-header-caption"><?php echo $vault_list->_addurl->caption() ?><?php echo $Language->phrase("SrchLegend") ?></span><span class="ew-table-header-sort"><?php if ($vault_list->_addurl->getSort() == "ASC") { ?><i class="fas fa-sort-up"></i><?php } elseif ($vault_list->_addurl->getSort() == "DESC") { ?><i class="fas fa-sort-down"></i><?php } ?></span></div>
		</div></div></th>
	<?php } ?>
<?php } ?>
<?php if ($vault_list->readurl->Visible) { // readurl ?>
	<?php if ($vault_list->SortUrl($vault_list->readurl) == "") { ?>
		<th data-name="readurl" class="<?php echo $vault_list->readurl->headerCellClass() ?>"><div id="elh_vault_readurl" class="vault_readurl"><div class="ew-table-header-caption"><?php echo $vault_list->readurl->caption() ?></div></div></th>
	<?php } else { ?>
		<th data-name="readurl" class="<?php echo $vault_list->readurl->headerCellClass() ?>"><div class="ew-pointer" onclick="ew.sort(event, '<?php echo $vault_list->SortUrl($vault_list->readurl) ?>', 1);"><div id="elh_vault_readurl" class="vault_readurl">
			<div class="ew-table-header-btn"><span class="ew-table-header-caption"><?php echo $vault_list->readurl->caption() ?><?php echo $Language->phrase("SrchLegend") ?></span><span class="ew-table-header-sort"><?php if ($vault_list->readurl->getSort() == "ASC") { ?><i class="fas fa-sort-up"></i><?php } elseif ($vault_list->readurl->getSort() == "DESC") { ?><i class="fas fa-sort-down"></i><?php } ?></span></div>
		</div></div></th>
	<?php } ?>
<?php } ?>
<?php if ($vault_list->_deleteurl->Visible) { // deleteurl ?>
	<?php if ($vault_list->SortUrl($vault_list->_deleteurl) == "") { ?>
		<th data-name="_deleteurl" class="<?php echo $vault_list->_deleteurl->headerCellClass() ?>"><div id="elh_vault__deleteurl" class="vault__deleteurl"><div class="ew-table-header-caption"><?php echo $vault_list->_deleteurl->caption() ?></div></div></th>
	<?php } else { ?>
		<th data-name="_deleteurl" class="<?php echo $vault_list->_deleteurl->headerCellClass() ?>"><div class="ew-pointer" onclick="ew.sort(event, '<?php echo $vault_list->SortUrl($vault_list->_deleteurl) ?>', 1);"><div id="elh_vault__deleteurl" class="vault__deleteurl">
			<div class="ew-table-header-btn"><span class="ew-table-header-caption"><?php echo $vault_list->_deleteurl->caption() ?><?php echo $Language->phrase("SrchLegend") ?></span><span class="ew-table-header-sort"><?php if ($vault_list->_deleteurl->getSort() == "ASC") { ?><i class="fas fa-sort-up"></i><?php } elseif ($vault_list->_deleteurl->getSort() == "DESC") { ?><i class="fas fa-sort-down"></i><?php } ?></span></div>
		</div></div></th>
	<?php } ?>
<?php } ?>
<?php if ($vault_list->updateurl->Visible) { // updateurl ?>
	<?php if ($vault_list->SortUrl($vault_list->updateurl) == "") { ?>
		<th data-name="updateurl" class="<?php echo $vault_list->updateurl->headerCellClass() ?>"><div id="elh_vault_updateurl" class="vault_updateurl"><div class="ew-table-header-caption"><?php echo $vault_list->updateurl->caption() ?></div></div></th>
	<?php } else { ?>
		<th data-name="updateurl" class="<?php echo $vault_list->updateurl->headerCellClass() ?>"><div class="ew-pointer" onclick="ew.sort(event, '<?php echo $vault_list->SortUrl($vault_list->updateurl) ?>', 1);"><div id="elh_vault_updateurl" class="vault_updateurl">
			<div class="ew-table-header-btn"><span class="ew-table-header-caption"><?php echo $vault_list->updateurl->caption() ?><?php echo $Language->phrase("SrchLegend") ?></span><span class="ew-table-header-sort"><?php if ($vault_list->updateurl->getSort() == "ASC") { ?><i class="fas fa-sort-up"></i><?php } elseif ($vault_list->updateurl->getSort() == "DESC") { ?><i class="fas fa-sort-down"></i><?php } ?></span></div>
		</div></div></th>
	<?php } ?>
<?php } ?>
<?php

// Render list options (header, right)
$vault_list->ListOptions->render("header", "right");
?>
	</tr>
</thead>
<tbody>
<?php
if ($vault_list->ExportAll && $vault_list->isExport()) {
	$vault_list->StopRecord = $vault_list->TotalRecords;
} else {

	// Set the last record to display
	if ($vault_list->TotalRecords > $vault_list->StartRecord + $vault_list->DisplayRecords - 1)
		$vault_list->StopRecord = $vault_list->StartRecord + $vault_list->DisplayRecords - 1;
	else
		$vault_list->StopRecord = $vault_list->TotalRecords;
}
$vault_list->RecordCount = $vault_list->StartRecord - 1;
if ($vault_list->Recordset && !$vault_list->Recordset->EOF) {
	$vault_list->Recordset->moveFirst();
	$selectLimit = $vault_list->UseSelectLimit;
	if (!$selectLimit && $vault_list->StartRecord > 1)
		$vault_list->Recordset->move($vault_list->StartRecord - 1);
} elseif (!$vault->AllowAddDeleteRow && $vault_list->StopRecord == 0) {
	$vault_list->StopRecord = $vault->GridAddRowCount;
}

// Initialize aggregate
$vault->RowType = ROWTYPE_AGGREGATEINIT;
$vault->resetAttributes();
$vault_list->renderRow();
while ($vault_list->RecordCount < $vault_list->StopRecord) {
	$vault_list->RecordCount++;
	if ($vault_list->RecordCount >= $vault_list->StartRecord) {
		$vault_list->RowCount++;

		// Set up key count
		$vault_list->KeyCount = $vault_list->RowIndex;

		// Init row class and style
		$vault->resetAttributes();
		$vault->CssClass = "";
		if ($vault_list->isGridAdd()) {
		} else {
			$vault_list->loadRowValues($vault_list->Recordset); // Load row values
		}
		$vault->RowType = ROWTYPE_VIEW; // Render view

		// Set up row id / data-rowindex
		$vault->RowAttrs->merge(["data-rowindex" => $vault_list->RowCount, "id" => "r" . $vault_list->RowCount . "_vault", "data-rowtype" => $vault->RowType]);

		// Render row
		$vault_list->renderRow();

		// Render list options
		$vault_list->renderListOptions();
?>
	<tr <?php echo $vault->rowAttributes() ?>>
<?php

// Render list options (body, left)
$vault_list->ListOptions->render("body", "left", $vault_list->RowCount);
?>
	<?php if ($vault_list->vaultid->Visible) { // vaultid ?>
		<td data-name="vaultid" <?php echo $vault_list->vaultid->cellAttributes() ?>>
<span id="el<?php echo $vault_list->RowCount ?>_vault_vaultid">
<span<?php echo $vault_list->vaultid->viewAttributes() ?>><?php echo $vault_list->vaultid->getViewValue() ?></span>
</span>
</td>
	<?php } ?>
	<?php if ($vault_list->modulename->Visible) { // modulename ?>
		<td data-name="modulename" <?php echo $vault_list->modulename->cellAttributes() ?>>
<span id="el<?php echo $vault_list->RowCount ?>_vault_modulename">
<span<?php echo $vault_list->modulename->viewAttributes() ?>><?php echo $vault_list->modulename->getViewValue() ?></span>
</span>
</td>
	<?php } ?>
	<?php if ($vault_list->_addurl->Visible) { // addurl ?>
		<td data-name="_addurl" <?php echo $vault_list->_addurl->cellAttributes() ?>>
<span id="el<?php echo $vault_list->RowCount ?>_vault__addurl">
<span<?php echo $vault_list->_addurl->viewAttributes() ?>><?php echo $vault_list->_addurl->getViewValue() ?></span>
</span>
</td>
	<?php } ?>
	<?php if ($vault_list->readurl->Visible) { // readurl ?>
		<td data-name="readurl" <?php echo $vault_list->readurl->cellAttributes() ?>>
<span id="el<?php echo $vault_list->RowCount ?>_vault_readurl">
<span<?php echo $vault_list->readurl->viewAttributes() ?>><?php echo $vault_list->readurl->getViewValue() ?></span>
</span>
</td>
	<?php } ?>
	<?php if ($vault_list->_deleteurl->Visible) { // deleteurl ?>
		<td data-name="_deleteurl" <?php echo $vault_list->_deleteurl->cellAttributes() ?>>
<span id="el<?php echo $vault_list->RowCount ?>_vault__deleteurl">
<span<?php echo $vault_list->_deleteurl->viewAttributes() ?>><?php echo $vault_list->_deleteurl->getViewValue() ?></span>
</span>
</td>
	<?php } ?>
	<?php if ($vault_list->updateurl->Visible) { // updateurl ?>
		<td data-name="updateurl" <?php echo $vault_list->updateurl->cellAttributes() ?>>
<span id="el<?php echo $vault_list->RowCount ?>_vault_updateurl">
<span<?php echo $vault_list->updateurl->viewAttributes() ?>><?php echo $vault_list->updateurl->getViewValue() ?></span>
</span>
</td>
	<?php } ?>
<?php

// Render list options (body, right)
$vault_list->ListOptions->render("body", "right", $vault_list->RowCount);
?>
	</tr>
<?php
	}
	if (!$vault_list->isGridAdd())
		$vault_list->Recordset->moveNext();
}
?>
</tbody>
</table><!-- /.ew-table -->
<?php } ?>
</div><!-- /.ew-grid-middle-panel -->
<?php if (!$vault->CurrentAction) { ?>
<input type="hidden" name="action" id="action" value="">
<?php } ?>
</form><!-- /.ew-list-form -->
<?php

// Close recordset
if ($vault_list->Recordset)
	$vault_list->Recordset->Close();
?>
<?php if (!$vault_list->isExport()) { ?>
<div class="card-footer ew-grid-lower-panel">
<?php if (!$vault_list->isGridAdd()) { ?>
<form name="ew-pager-form" class="form-inline ew-form ew-pager-form" action="<?php echo CurrentPageName() ?>">
<?php echo $vault_list->Pager->render() ?>
</form>
<?php } ?>
<div class="ew-list-other-options">
<?php $vault_list->OtherOptions->render("body", "bottom") ?>
</div>
<div class="clearfix"></div>
</div>
<?php } ?>
</div><!-- /.ew-grid -->
<?php } ?>
<?php if ($vault_list->TotalRecords == 0 && !$vault->CurrentAction) { // Show other options ?>
<div class="ew-list-other-options">
<?php $vault_list->OtherOptions->render("body") ?>
</div>
<div class="clearfix"></div>
<?php } ?>
<?php
$vault_list->showPageFooter();
if (Config("DEBUG"))
	echo GetDebugMessage();
?>
<?php if (!$vault_list->isExport()) { ?>
<script>
loadjs.ready("load", function() {

	// Startup script
	// Write your table-specific startup script here
	// console.log("page loaded");

});
</script>
<?php } ?>
<?php include_once "footer.php"; ?>
<?php
$vault_list->terminate();
?>