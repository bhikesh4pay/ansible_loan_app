<?php
namespace PHPMaker2020\_4payadmin;

// Autoload
include_once "autoload.php";

// Session
if (session_status() !== PHP_SESSION_ACTIVE)
	\Delight\Cookie\Session::start(Config("COOKIE_SAMESITE")); // Init session data

// Output buffering
ob_start();
?>
<?php

// Write header
WriteHeader(FALSE);

// Create page object
$usersessionhistory_list = new usersessionhistory_list();

// Run the page
$usersessionhistory_list->run();

// Setup login status
SetupLoginStatus();
SetClientVar("login", LoginStatus());

// Global Page Rendering event (in userfn*.php)
Page_Rendering();

// Page Rendering event
$usersessionhistory_list->Page_Render();
?>
<?php include_once "header.php"; ?>
<?php if (!$usersessionhistory_list->isExport()) { ?>
<script>
var fusersessionhistorylist, currentPageID;
loadjs.ready("head", function() {

	// Form object
	currentPageID = ew.PAGE_ID = "list";
	fusersessionhistorylist = currentForm = new ew.Form("fusersessionhistorylist", "list");
	fusersessionhistorylist.formKeyCountName = '<?php echo $usersessionhistory_list->FormKeyCountName ?>';
	loadjs.done("fusersessionhistorylist");
});
var fusersessionhistorylistsrch;
loadjs.ready("head", function() {

	// Form object for search
	fusersessionhistorylistsrch = currentSearchForm = new ew.Form("fusersessionhistorylistsrch");

	// Dynamic selection lists
	// Filters

	fusersessionhistorylistsrch.filterList = <?php echo $usersessionhistory_list->getFilterList() ?>;

	// Init search panel as collapsed
	fusersessionhistorylistsrch.initSearchPanel = true;
	loadjs.done("fusersessionhistorylistsrch");
});
</script>
<style type="text/css">
.ew-table-preview-row { /* main table preview row color */
	background-color: #FFFFFF; /* preview row color */
}
.ew-table-preview-row .ew-grid {
	display: table;
}
</style>
<div id="ew-preview" class="d-none"><!-- preview -->
	<div class="ew-nav-tabs"><!-- .ew-nav-tabs -->
		<ul class="nav nav-tabs"></ul>
		<div class="tab-content"><!-- .tab-content -->
			<div class="tab-pane fade active show"></div>
		</div><!-- /.tab-content -->
	</div><!-- /.ew-nav-tabs -->
</div><!-- /preview -->
<script>
loadjs.ready("head", function() {
	ew.PREVIEW_PLACEMENT = ew.CSS_FLIP ? "right" : "left";
	ew.PREVIEW_SINGLE_ROW = false;
	ew.PREVIEW_OVERLAY = false;
	loadjs("js/ewpreview.js", "preview");
});
</script>
<script>
loadjs.ready("head", function() {

	// Client script
	// Write your client script here, no need to add script tags.

});
</script>
<?php } ?>
<?php if (!$usersessionhistory_list->isExport()) { ?>
<div class="btn-toolbar ew-toolbar">
<?php if ($usersessionhistory_list->TotalRecords > 0 && $usersessionhistory_list->ExportOptions->visible()) { ?>
<?php $usersessionhistory_list->ExportOptions->render("body") ?>
<?php } ?>
<?php if ($usersessionhistory_list->ImportOptions->visible()) { ?>
<?php $usersessionhistory_list->ImportOptions->render("body") ?>
<?php } ?>
<?php if ($usersessionhistory_list->SearchOptions->visible()) { ?>
<?php $usersessionhistory_list->SearchOptions->render("body") ?>
<?php } ?>
<?php if ($usersessionhistory_list->FilterOptions->visible()) { ?>
<?php $usersessionhistory_list->FilterOptions->render("body") ?>
<?php } ?>
<div class="clearfix"></div>
</div>
<?php } ?>
<?php if (!$usersessionhistory_list->isExport() || Config("EXPORT_MASTER_RECORD") && $usersessionhistory_list->isExport("print")) { ?>
<?php
if ($usersessionhistory_list->DbMasterFilter != "" && $usersessionhistory->getCurrentMasterTable() == "usersession") {
	if ($usersessionhistory_list->MasterRecordExists) {
		include_once "usersessionmaster.php";
	}
}
?>
<?php } ?>
<?php
$usersessionhistory_list->renderOtherOptions();
?>
<?php if ($Security->CanSearch()) { ?>
<?php if (!$usersessionhistory_list->isExport() && !$usersessionhistory->CurrentAction) { ?>
<form name="fusersessionhistorylistsrch" id="fusersessionhistorylistsrch" class="form-inline ew-form ew-ext-search-form" action="<?php echo CurrentPageName() ?>">
<div id="fusersessionhistorylistsrch-search-panel" class="<?php echo $usersessionhistory_list->SearchPanelClass ?>">
<input type="hidden" name="cmd" value="search">
<input type="hidden" name="t" value="usersessionhistory">
	<div class="ew-extended-search">
<div id="xsr_<?php echo $usersessionhistory_list->SearchRowCount + 1 ?>" class="ew-row d-sm-flex">
	<div class="ew-quick-search input-group">
		<input type="text" name="<?php echo Config("TABLE_BASIC_SEARCH") ?>" id="<?php echo Config("TABLE_BASIC_SEARCH") ?>" class="form-control" value="<?php echo HtmlEncode($usersessionhistory_list->BasicSearch->getKeyword()) ?>" placeholder="<?php echo HtmlEncode($Language->phrase("Search")) ?>">
		<input type="hidden" name="<?php echo Config("TABLE_BASIC_SEARCH_TYPE") ?>" id="<?php echo Config("TABLE_BASIC_SEARCH_TYPE") ?>" value="<?php echo HtmlEncode($usersessionhistory_list->BasicSearch->getType()) ?>">
		<div class="input-group-append">
			<button class="btn btn-primary" name="btn-submit" id="btn-submit" type="submit"><?php echo $Language->phrase("SearchBtn") ?></button>
			<button type="button" data-toggle="dropdown" class="btn btn-primary dropdown-toggle dropdown-toggle-split" aria-haspopup="true" aria-expanded="false"><span id="searchtype"><?php echo $usersessionhistory_list->BasicSearch->getTypeNameShort() ?></span></button>
			<div class="dropdown-menu dropdown-menu-right">
				<a class="dropdown-item<?php if ($usersessionhistory_list->BasicSearch->getType() == "") { ?> active<?php } ?>" href="#" onclick="return ew.setSearchType(this);"><?php echo $Language->phrase("QuickSearchAuto") ?></a>
				<a class="dropdown-item<?php if ($usersessionhistory_list->BasicSearch->getType() == "=") { ?> active<?php } ?>" href="#" onclick="return ew.setSearchType(this, '=');"><?php echo $Language->phrase("QuickSearchExact") ?></a>
				<a class="dropdown-item<?php if ($usersessionhistory_list->BasicSearch->getType() == "AND") { ?> active<?php } ?>" href="#" onclick="return ew.setSearchType(this, 'AND');"><?php echo $Language->phrase("QuickSearchAll") ?></a>
				<a class="dropdown-item<?php if ($usersessionhistory_list->BasicSearch->getType() == "OR") { ?> active<?php } ?>" href="#" onclick="return ew.setSearchType(this, 'OR');"><?php echo $Language->phrase("QuickSearchAny") ?></a>
			</div>
		</div>
	</div>
</div>
	</div><!-- /.ew-extended-search -->
</div><!-- /.ew-search-panel -->
</form>
<?php } ?>
<?php } ?>
<?php $usersessionhistory_list->showPageHeader(); ?>
<?php
$usersessionhistory_list->showMessage();
?>
<?php if ($usersessionhistory_list->TotalRecords > 0 || $usersessionhistory->CurrentAction) { ?>
<div class="card ew-card ew-grid<?php if ($usersessionhistory_list->isAddOrEdit()) { ?> ew-grid-add-edit<?php } ?> usersessionhistory">
<form name="fusersessionhistorylist" id="fusersessionhistorylist" class="form-inline ew-form ew-list-form" action="<?php echo CurrentPageName() ?>" method="post">
<?php if ($Page->CheckToken) { ?>
<input type="hidden" name="<?php echo Config("TOKEN_NAME") ?>" value="<?php echo $Page->Token ?>">
<?php } ?>
<input type="hidden" name="t" value="usersessionhistory">
<?php if ($usersessionhistory->getCurrentMasterTable() == "usersession" && $usersessionhistory->CurrentAction) { ?>
<input type="hidden" name="<?php echo Config("TABLE_SHOW_MASTER") ?>" value="usersession">
<input type="hidden" name="fk__userid" value="<?php echo HtmlEncode($usersessionhistory_list->_userid->getSessionValue()) ?>">
<input type="hidden" name="fk_sessionid" value="<?php echo HtmlEncode($usersessionhistory_list->sessionid->getSessionValue()) ?>">
<?php } ?>
<div id="gmp_usersessionhistory" class="<?php echo ResponsiveTableClass() ?>card-body ew-grid-middle-panel">
<?php if ($usersessionhistory_list->TotalRecords > 0 || $usersessionhistory_list->isGridEdit()) { ?>
<table id="tbl_usersessionhistorylist" class="table ew-table"><!-- .ew-table -->
<thead>
	<tr class="ew-table-header">
<?php

// Header row
$usersessionhistory->RowType = ROWTYPE_HEADER;

// Render list options
$usersessionhistory_list->renderListOptions();

// Render list options (header, left)
$usersessionhistory_list->ListOptions->render("header", "left");
?>
<?php if ($usersessionhistory_list->recid->Visible) { // recid ?>
	<?php if ($usersessionhistory_list->SortUrl($usersessionhistory_list->recid) == "") { ?>
		<th data-name="recid" class="<?php echo $usersessionhistory_list->recid->headerCellClass() ?>"><div id="elh_usersessionhistory_recid" class="usersessionhistory_recid"><div class="ew-table-header-caption"><?php echo $usersessionhistory_list->recid->caption() ?></div></div></th>
	<?php } else { ?>
		<th data-name="recid" class="<?php echo $usersessionhistory_list->recid->headerCellClass() ?>"><div class="ew-pointer" onclick="ew.sort(event, '<?php echo $usersessionhistory_list->SortUrl($usersessionhistory_list->recid) ?>', 1);"><div id="elh_usersessionhistory_recid" class="usersessionhistory_recid">
			<div class="ew-table-header-btn"><span class="ew-table-header-caption"><?php echo $usersessionhistory_list->recid->caption() ?></span><span class="ew-table-header-sort"><?php if ($usersessionhistory_list->recid->getSort() == "ASC") { ?><i class="fas fa-sort-up"></i><?php } elseif ($usersessionhistory_list->recid->getSort() == "DESC") { ?><i class="fas fa-sort-down"></i><?php } ?></span></div>
		</div></div></th>
	<?php } ?>
<?php } ?>
<?php if ($usersessionhistory_list->_userid->Visible) { // userid ?>
	<?php if ($usersessionhistory_list->SortUrl($usersessionhistory_list->_userid) == "") { ?>
		<th data-name="_userid" class="<?php echo $usersessionhistory_list->_userid->headerCellClass() ?>"><div id="elh_usersessionhistory__userid" class="usersessionhistory__userid"><div class="ew-table-header-caption"><?php echo $usersessionhistory_list->_userid->caption() ?></div></div></th>
	<?php } else { ?>
		<th data-name="_userid" class="<?php echo $usersessionhistory_list->_userid->headerCellClass() ?>"><div class="ew-pointer" onclick="ew.sort(event, '<?php echo $usersessionhistory_list->SortUrl($usersessionhistory_list->_userid) ?>', 1);"><div id="elh_usersessionhistory__userid" class="usersessionhistory__userid">
			<div class="ew-table-header-btn"><span class="ew-table-header-caption"><?php echo $usersessionhistory_list->_userid->caption() ?></span><span class="ew-table-header-sort"><?php if ($usersessionhistory_list->_userid->getSort() == "ASC") { ?><i class="fas fa-sort-up"></i><?php } elseif ($usersessionhistory_list->_userid->getSort() == "DESC") { ?><i class="fas fa-sort-down"></i><?php } ?></span></div>
		</div></div></th>
	<?php } ?>
<?php } ?>
<?php if ($usersessionhistory_list->sessionid->Visible) { // sessionid ?>
	<?php if ($usersessionhistory_list->SortUrl($usersessionhistory_list->sessionid) == "") { ?>
		<th data-name="sessionid" class="<?php echo $usersessionhistory_list->sessionid->headerCellClass() ?>"><div id="elh_usersessionhistory_sessionid" class="usersessionhistory_sessionid"><div class="ew-table-header-caption"><?php echo $usersessionhistory_list->sessionid->caption() ?></div></div></th>
	<?php } else { ?>
		<th data-name="sessionid" class="<?php echo $usersessionhistory_list->sessionid->headerCellClass() ?>"><div class="ew-pointer" onclick="ew.sort(event, '<?php echo $usersessionhistory_list->SortUrl($usersessionhistory_list->sessionid) ?>', 1);"><div id="elh_usersessionhistory_sessionid" class="usersessionhistory_sessionid">
			<div class="ew-table-header-btn"><span class="ew-table-header-caption"><?php echo $usersessionhistory_list->sessionid->caption() ?><?php echo $Language->phrase("SrchLegend") ?></span><span class="ew-table-header-sort"><?php if ($usersessionhistory_list->sessionid->getSort() == "ASC") { ?><i class="fas fa-sort-up"></i><?php } elseif ($usersessionhistory_list->sessionid->getSort() == "DESC") { ?><i class="fas fa-sort-down"></i><?php } ?></span></div>
		</div></div></th>
	<?php } ?>
<?php } ?>
<?php if ($usersessionhistory_list->updatetime->Visible) { // updatetime ?>
	<?php if ($usersessionhistory_list->SortUrl($usersessionhistory_list->updatetime) == "") { ?>
		<th data-name="updatetime" class="<?php echo $usersessionhistory_list->updatetime->headerCellClass() ?>"><div id="elh_usersessionhistory_updatetime" class="usersessionhistory_updatetime"><div class="ew-table-header-caption"><?php echo $usersessionhistory_list->updatetime->caption() ?></div></div></th>
	<?php } else { ?>
		<th data-name="updatetime" class="<?php echo $usersessionhistory_list->updatetime->headerCellClass() ?>"><div class="ew-pointer" onclick="ew.sort(event, '<?php echo $usersessionhistory_list->SortUrl($usersessionhistory_list->updatetime) ?>', 1);"><div id="elh_usersessionhistory_updatetime" class="usersessionhistory_updatetime">
			<div class="ew-table-header-btn"><span class="ew-table-header-caption"><?php echo $usersessionhistory_list->updatetime->caption() ?></span><span class="ew-table-header-sort"><?php if ($usersessionhistory_list->updatetime->getSort() == "ASC") { ?><i class="fas fa-sort-up"></i><?php } elseif ($usersessionhistory_list->updatetime->getSort() == "DESC") { ?><i class="fas fa-sort-down"></i><?php } ?></span></div>
		</div></div></th>
	<?php } ?>
<?php } ?>
<?php if ($usersessionhistory_list->tag->Visible) { // tag ?>
	<?php if ($usersessionhistory_list->SortUrl($usersessionhistory_list->tag) == "") { ?>
		<th data-name="tag" class="<?php echo $usersessionhistory_list->tag->headerCellClass() ?>"><div id="elh_usersessionhistory_tag" class="usersessionhistory_tag"><div class="ew-table-header-caption"><?php echo $usersessionhistory_list->tag->caption() ?></div></div></th>
	<?php } else { ?>
		<th data-name="tag" class="<?php echo $usersessionhistory_list->tag->headerCellClass() ?>"><div class="ew-pointer" onclick="ew.sort(event, '<?php echo $usersessionhistory_list->SortUrl($usersessionhistory_list->tag) ?>', 1);"><div id="elh_usersessionhistory_tag" class="usersessionhistory_tag">
			<div class="ew-table-header-btn"><span class="ew-table-header-caption"><?php echo $usersessionhistory_list->tag->caption() ?><?php echo $Language->phrase("SrchLegend") ?></span><span class="ew-table-header-sort"><?php if ($usersessionhistory_list->tag->getSort() == "ASC") { ?><i class="fas fa-sort-up"></i><?php } elseif ($usersessionhistory_list->tag->getSort() == "DESC") { ?><i class="fas fa-sort-down"></i><?php } ?></span></div>
		</div></div></th>
	<?php } ?>
<?php } ?>
<?php

// Render list options (header, right)
$usersessionhistory_list->ListOptions->render("header", "right");
?>
	</tr>
</thead>
<tbody>
<?php
if ($usersessionhistory_list->ExportAll && $usersessionhistory_list->isExport()) {
	$usersessionhistory_list->StopRecord = $usersessionhistory_list->TotalRecords;
} else {

	// Set the last record to display
	if ($usersessionhistory_list->TotalRecords > $usersessionhistory_list->StartRecord + $usersessionhistory_list->DisplayRecords - 1)
		$usersessionhistory_list->StopRecord = $usersessionhistory_list->StartRecord + $usersessionhistory_list->DisplayRecords - 1;
	else
		$usersessionhistory_list->StopRecord = $usersessionhistory_list->TotalRecords;
}
$usersessionhistory_list->RecordCount = $usersessionhistory_list->StartRecord - 1;
if ($usersessionhistory_list->Recordset && !$usersessionhistory_list->Recordset->EOF) {
	$usersessionhistory_list->Recordset->moveFirst();
	$selectLimit = $usersessionhistory_list->UseSelectLimit;
	if (!$selectLimit && $usersessionhistory_list->StartRecord > 1)
		$usersessionhistory_list->Recordset->move($usersessionhistory_list->StartRecord - 1);
} elseif (!$usersessionhistory->AllowAddDeleteRow && $usersessionhistory_list->StopRecord == 0) {
	$usersessionhistory_list->StopRecord = $usersessionhistory->GridAddRowCount;
}

// Initialize aggregate
$usersessionhistory->RowType = ROWTYPE_AGGREGATEINIT;
$usersessionhistory->resetAttributes();
$usersessionhistory_list->renderRow();
while ($usersessionhistory_list->RecordCount < $usersessionhistory_list->StopRecord) {
	$usersessionhistory_list->RecordCount++;
	if ($usersessionhistory_list->RecordCount >= $usersessionhistory_list->StartRecord) {
		$usersessionhistory_list->RowCount++;

		// Set up key count
		$usersessionhistory_list->KeyCount = $usersessionhistory_list->RowIndex;

		// Init row class and style
		$usersessionhistory->resetAttributes();
		$usersessionhistory->CssClass = "";
		if ($usersessionhistory_list->isGridAdd()) {
		} else {
			$usersessionhistory_list->loadRowValues($usersessionhistory_list->Recordset); // Load row values
		}
		$usersessionhistory->RowType = ROWTYPE_VIEW; // Render view

		// Set up row id / data-rowindex
		$usersessionhistory->RowAttrs->merge(["data-rowindex" => $usersessionhistory_list->RowCount, "id" => "r" . $usersessionhistory_list->RowCount . "_usersessionhistory", "data-rowtype" => $usersessionhistory->RowType]);

		// Render row
		$usersessionhistory_list->renderRow();

		// Render list options
		$usersessionhistory_list->renderListOptions();
?>
	<tr <?php echo $usersessionhistory->rowAttributes() ?>>
<?php

// Render list options (body, left)
$usersessionhistory_list->ListOptions->render("body", "left", $usersessionhistory_list->RowCount);
?>
	<?php if ($usersessionhistory_list->recid->Visible) { // recid ?>
		<td data-name="recid" <?php echo $usersessionhistory_list->recid->cellAttributes() ?>>
<span id="el<?php echo $usersessionhistory_list->RowCount ?>_usersessionhistory_recid">
<span<?php echo $usersessionhistory_list->recid->viewAttributes() ?>><?php echo $usersessionhistory_list->recid->getViewValue() ?></span>
</span>
</td>
	<?php } ?>
	<?php if ($usersessionhistory_list->_userid->Visible) { // userid ?>
		<td data-name="_userid" <?php echo $usersessionhistory_list->_userid->cellAttributes() ?>>
<span id="el<?php echo $usersessionhistory_list->RowCount ?>_usersessionhistory__userid">
<span<?php echo $usersessionhistory_list->_userid->viewAttributes() ?>><?php echo $usersessionhistory_list->_userid->getViewValue() ?></span>
</span>
</td>
	<?php } ?>
	<?php if ($usersessionhistory_list->sessionid->Visible) { // sessionid ?>
		<td data-name="sessionid" <?php echo $usersessionhistory_list->sessionid->cellAttributes() ?>>
<span id="el<?php echo $usersessionhistory_list->RowCount ?>_usersessionhistory_sessionid">
<span<?php echo $usersessionhistory_list->sessionid->viewAttributes() ?>><?php echo $usersessionhistory_list->sessionid->getViewValue() ?></span>
</span>
</td>
	<?php } ?>
	<?php if ($usersessionhistory_list->updatetime->Visible) { // updatetime ?>
		<td data-name="updatetime" <?php echo $usersessionhistory_list->updatetime->cellAttributes() ?>>
<span id="el<?php echo $usersessionhistory_list->RowCount ?>_usersessionhistory_updatetime">
<span<?php echo $usersessionhistory_list->updatetime->viewAttributes() ?>><?php echo $usersessionhistory_list->updatetime->getViewValue() ?></span>
</span>
</td>
	<?php } ?>
	<?php if ($usersessionhistory_list->tag->Visible) { // tag ?>
		<td data-name="tag" <?php echo $usersessionhistory_list->tag->cellAttributes() ?>>
<span id="el<?php echo $usersessionhistory_list->RowCount ?>_usersessionhistory_tag">
<span<?php echo $usersessionhistory_list->tag->viewAttributes() ?>><?php echo $usersessionhistory_list->tag->getViewValue() ?></span>
</span>
</td>
	<?php } ?>
<?php

// Render list options (body, right)
$usersessionhistory_list->ListOptions->render("body", "right", $usersessionhistory_list->RowCount);
?>
	</tr>
<?php
	}
	if (!$usersessionhistory_list->isGridAdd())
		$usersessionhistory_list->Recordset->moveNext();
}
?>
</tbody>
</table><!-- /.ew-table -->
<?php } ?>
</div><!-- /.ew-grid-middle-panel -->
<?php if (!$usersessionhistory->CurrentAction) { ?>
<input type="hidden" name="action" id="action" value="">
<?php } ?>
</form><!-- /.ew-list-form -->
<?php

// Close recordset
if ($usersessionhistory_list->Recordset)
	$usersessionhistory_list->Recordset->Close();
?>
<?php if (!$usersessionhistory_list->isExport()) { ?>
<div class="card-footer ew-grid-lower-panel">
<?php if (!$usersessionhistory_list->isGridAdd()) { ?>
<form name="ew-pager-form" class="form-inline ew-form ew-pager-form" action="<?php echo CurrentPageName() ?>">
<?php echo $usersessionhistory_list->Pager->render() ?>
</form>
<?php } ?>
<div class="ew-list-other-options">
<?php $usersessionhistory_list->OtherOptions->render("body", "bottom") ?>
</div>
<div class="clearfix"></div>
</div>
<?php } ?>
</div><!-- /.ew-grid -->
<?php } ?>
<?php if ($usersessionhistory_list->TotalRecords == 0 && !$usersessionhistory->CurrentAction) { // Show other options ?>
<div class="ew-list-other-options">
<?php $usersessionhistory_list->OtherOptions->render("body") ?>
</div>
<div class="clearfix"></div>
<?php } ?>
<?php
$usersessionhistory_list->showPageFooter();
if (Config("DEBUG"))
	echo GetDebugMessage();
?>
<?php if (!$usersessionhistory_list->isExport()) { ?>
<script>
loadjs.ready("load", function() {

	// Startup script
	// Write your table-specific startup script here
	// console.log("page loaded");

});
</script>
<?php } ?>
<?php include_once "footer.php"; ?>
<?php
$usersessionhistory_list->terminate();
?>