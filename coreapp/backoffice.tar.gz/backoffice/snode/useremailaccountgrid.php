<?php
namespace PHPMaker2020\_4payadmin;

// Write header
WriteHeader(FALSE);

// Create page object
if (!isset($useremailaccount_grid))
	$useremailaccount_grid = new useremailaccount_grid();

// Run the page
$useremailaccount_grid->run();

// Setup login status
SetupLoginStatus();
SetClientVar("login", LoginStatus());

// Global Page Rendering event (in userfn*.php)
Page_Rendering();

// Page Rendering event
$useremailaccount_grid->Page_Render();
?>
<?php if (!$useremailaccount_grid->isExport()) { ?>
<script>
var fuseremailaccountgrid, currentPageID;
loadjs.ready("head", function() {

	// Form object
	fuseremailaccountgrid = new ew.Form("fuseremailaccountgrid", "grid");
	fuseremailaccountgrid.formKeyCountName = '<?php echo $useremailaccount_grid->FormKeyCountName ?>';

	// Validate form
	fuseremailaccountgrid.validate = function() {
		if (!this.validateRequired)
			return true; // Ignore validation
		var $ = jQuery, fobj = this.getForm(), $fobj = $(fobj);
		if ($fobj.find("#confirm").val() == "confirm")
			return true;
		var elm, felm, uelm, addcnt = 0;
		var $k = $fobj.find("#" + this.formKeyCountName); // Get key_count
		var rowcnt = ($k[0]) ? parseInt($k.val(), 10) : 1;
		var startcnt = (rowcnt == 0) ? 0 : 1; // Check rowcnt == 0 => Inline-Add
		var gridinsert = ["insert", "gridinsert"].includes($fobj.find("#action").val()) && $k[0];
		for (var i = startcnt; i <= rowcnt; i++) {
			var infix = ($k[0]) ? String(i) : "";
			$fobj.data("rowindex", infix);
			var checkrow = (gridinsert) ? !this.emptyRow(infix) : true;
			if (checkrow) {
				addcnt++;
			<?php if ($useremailaccount_grid->_userID->Required) { ?>
				elm = this.getElements("x" + infix + "__userID");
				if (elm && !ew.isHidden(elm) && !ew.hasValue(elm))
					return this.onError(elm, "<?php echo JsEncode(str_replace("%s", $useremailaccount_grid->_userID->caption(), $useremailaccount_grid->_userID->RequiredErrorMessage)) ?>");
			<?php } ?>
				elm = this.getElements("x" + infix + "__userID");
				if (elm && !ew.checkInteger(elm.value))
					return this.onError(elm, "<?php echo JsEncode($useremailaccount_grid->_userID->errorMessage()) ?>");
			<?php if ($useremailaccount_grid->emailAccount->Required) { ?>
				elm = this.getElements("x" + infix + "_emailAccount");
				if (elm && !ew.isHidden(elm) && !ew.hasValue(elm))
					return this.onError(elm, "<?php echo JsEncode(str_replace("%s", $useremailaccount_grid->emailAccount->caption(), $useremailaccount_grid->emailAccount->RequiredErrorMessage)) ?>");
			<?php } ?>
			<?php if ($useremailaccount_grid->dateAdded->Required) { ?>
				elm = this.getElements("x" + infix + "_dateAdded");
				if (elm && !ew.isHidden(elm) && !ew.hasValue(elm))
					return this.onError(elm, "<?php echo JsEncode(str_replace("%s", $useremailaccount_grid->dateAdded->caption(), $useremailaccount_grid->dateAdded->RequiredErrorMessage)) ?>");
			<?php } ?>
				elm = this.getElements("x" + infix + "_dateAdded");
				if (elm && !ew.checkDateDef(elm.value))
					return this.onError(elm, "<?php echo JsEncode($useremailaccount_grid->dateAdded->errorMessage()) ?>");
			<?php if ($useremailaccount_grid->confirmationReceived->Required) { ?>
				elm = this.getElements("x" + infix + "_confirmationReceived");
				if (elm && !ew.isHidden(elm) && !ew.hasValue(elm))
					return this.onError(elm, "<?php echo JsEncode(str_replace("%s", $useremailaccount_grid->confirmationReceived->caption(), $useremailaccount_grid->confirmationReceived->RequiredErrorMessage)) ?>");
			<?php } ?>
			<?php if ($useremailaccount_grid->active->Required) { ?>
				elm = this.getElements("x" + infix + "_active");
				if (elm && !ew.isHidden(elm) && !ew.hasValue(elm))
					return this.onError(elm, "<?php echo JsEncode(str_replace("%s", $useremailaccount_grid->active->caption(), $useremailaccount_grid->active->RequiredErrorMessage)) ?>");
			<?php } ?>

				// Call Form_CustomValidate event
				if (!this.Form_CustomValidate(fobj))
					return false;
			} // End Grid Add checking
		}
		return true;
	}

	// Check empty row
	fuseremailaccountgrid.emptyRow = function(infix) {
		var fobj = this._form;
		if (ew.valueChanged(fobj, infix, "_userID", false)) return false;
		if (ew.valueChanged(fobj, infix, "emailAccount", false)) return false;
		if (ew.valueChanged(fobj, infix, "dateAdded", false)) return false;
		if (ew.valueChanged(fobj, infix, "confirmationReceived", false)) return false;
		if (ew.valueChanged(fobj, infix, "active", false)) return false;
		return true;
	}

	// Form_CustomValidate
	fuseremailaccountgrid.Form_CustomValidate = function(fobj) { // DO NOT CHANGE THIS LINE!

		// Your custom validation code here, return false if invalid.
		return true;
	}

	// Use JavaScript validation or not
	fuseremailaccountgrid.validateRequired = <?php echo Config("CLIENT_VALIDATE") ? "true" : "false" ?>;

	// Dynamic selection lists
	fuseremailaccountgrid.lists["x_confirmationReceived"] = <?php echo $useremailaccount_grid->confirmationReceived->Lookup->toClientList($useremailaccount_grid) ?>;
	fuseremailaccountgrid.lists["x_confirmationReceived"].options = <?php echo JsonEncode($useremailaccount_grid->confirmationReceived->lookupOptions()) ?>;
	fuseremailaccountgrid.lists["x_active"] = <?php echo $useremailaccount_grid->active->Lookup->toClientList($useremailaccount_grid) ?>;
	fuseremailaccountgrid.lists["x_active"].options = <?php echo JsonEncode($useremailaccount_grid->active->lookupOptions()) ?>;
	loadjs.done("fuseremailaccountgrid");
});
</script>
<?php } ?>
<?php
$useremailaccount_grid->renderOtherOptions();
?>
<?php if ($useremailaccount_grid->TotalRecords > 0 || $useremailaccount->CurrentAction) { ?>
<div class="card ew-card ew-grid<?php if ($useremailaccount_grid->isAddOrEdit()) { ?> ew-grid-add-edit<?php } ?> useremailaccount">
<div id="fuseremailaccountgrid" class="ew-form ew-list-form form-inline">
<div id="gmp_useremailaccount" class="<?php echo ResponsiveTableClass() ?>card-body ew-grid-middle-panel">
<table id="tbl_useremailaccountgrid" class="table ew-table"><!-- .ew-table -->
<thead>
	<tr class="ew-table-header">
<?php

// Header row
$useremailaccount->RowType = ROWTYPE_HEADER;

// Render list options
$useremailaccount_grid->renderListOptions();

// Render list options (header, left)
$useremailaccount_grid->ListOptions->render("header", "left");
?>
<?php if ($useremailaccount_grid->_userID->Visible) { // userID ?>
	<?php if ($useremailaccount_grid->SortUrl($useremailaccount_grid->_userID) == "") { ?>
		<th data-name="_userID" class="<?php echo $useremailaccount_grid->_userID->headerCellClass() ?>"><div id="elh_useremailaccount__userID" class="useremailaccount__userID"><div class="ew-table-header-caption"><?php echo $useremailaccount_grid->_userID->caption() ?></div></div></th>
	<?php } else { ?>
		<th data-name="_userID" class="<?php echo $useremailaccount_grid->_userID->headerCellClass() ?>"><div><div id="elh_useremailaccount__userID" class="useremailaccount__userID">
			<div class="ew-table-header-btn"><span class="ew-table-header-caption"><?php echo $useremailaccount_grid->_userID->caption() ?></span><span class="ew-table-header-sort"><?php if ($useremailaccount_grid->_userID->getSort() == "ASC") { ?><i class="fas fa-sort-up"></i><?php } elseif ($useremailaccount_grid->_userID->getSort() == "DESC") { ?><i class="fas fa-sort-down"></i><?php } ?></span></div>
		</div></div></th>
	<?php } ?>
<?php } ?>
<?php if ($useremailaccount_grid->emailAccount->Visible) { // emailAccount ?>
	<?php if ($useremailaccount_grid->SortUrl($useremailaccount_grid->emailAccount) == "") { ?>
		<th data-name="emailAccount" class="<?php echo $useremailaccount_grid->emailAccount->headerCellClass() ?>"><div id="elh_useremailaccount_emailAccount" class="useremailaccount_emailAccount"><div class="ew-table-header-caption"><?php echo $useremailaccount_grid->emailAccount->caption() ?></div></div></th>
	<?php } else { ?>
		<th data-name="emailAccount" class="<?php echo $useremailaccount_grid->emailAccount->headerCellClass() ?>"><div><div id="elh_useremailaccount_emailAccount" class="useremailaccount_emailAccount">
			<div class="ew-table-header-btn"><span class="ew-table-header-caption"><?php echo $useremailaccount_grid->emailAccount->caption() ?></span><span class="ew-table-header-sort"><?php if ($useremailaccount_grid->emailAccount->getSort() == "ASC") { ?><i class="fas fa-sort-up"></i><?php } elseif ($useremailaccount_grid->emailAccount->getSort() == "DESC") { ?><i class="fas fa-sort-down"></i><?php } ?></span></div>
		</div></div></th>
	<?php } ?>
<?php } ?>
<?php if ($useremailaccount_grid->dateAdded->Visible) { // dateAdded ?>
	<?php if ($useremailaccount_grid->SortUrl($useremailaccount_grid->dateAdded) == "") { ?>
		<th data-name="dateAdded" class="<?php echo $useremailaccount_grid->dateAdded->headerCellClass() ?>"><div id="elh_useremailaccount_dateAdded" class="useremailaccount_dateAdded"><div class="ew-table-header-caption"><?php echo $useremailaccount_grid->dateAdded->caption() ?></div></div></th>
	<?php } else { ?>
		<th data-name="dateAdded" class="<?php echo $useremailaccount_grid->dateAdded->headerCellClass() ?>"><div><div id="elh_useremailaccount_dateAdded" class="useremailaccount_dateAdded">
			<div class="ew-table-header-btn"><span class="ew-table-header-caption"><?php echo $useremailaccount_grid->dateAdded->caption() ?></span><span class="ew-table-header-sort"><?php if ($useremailaccount_grid->dateAdded->getSort() == "ASC") { ?><i class="fas fa-sort-up"></i><?php } elseif ($useremailaccount_grid->dateAdded->getSort() == "DESC") { ?><i class="fas fa-sort-down"></i><?php } ?></span></div>
		</div></div></th>
	<?php } ?>
<?php } ?>
<?php if ($useremailaccount_grid->confirmationReceived->Visible) { // confirmationReceived ?>
	<?php if ($useremailaccount_grid->SortUrl($useremailaccount_grid->confirmationReceived) == "") { ?>
		<th data-name="confirmationReceived" class="<?php echo $useremailaccount_grid->confirmationReceived->headerCellClass() ?>"><div id="elh_useremailaccount_confirmationReceived" class="useremailaccount_confirmationReceived"><div class="ew-table-header-caption"><?php echo $useremailaccount_grid->confirmationReceived->caption() ?></div></div></th>
	<?php } else { ?>
		<th data-name="confirmationReceived" class="<?php echo $useremailaccount_grid->confirmationReceived->headerCellClass() ?>"><div><div id="elh_useremailaccount_confirmationReceived" class="useremailaccount_confirmationReceived">
			<div class="ew-table-header-btn"><span class="ew-table-header-caption"><?php echo $useremailaccount_grid->confirmationReceived->caption() ?></span><span class="ew-table-header-sort"><?php if ($useremailaccount_grid->confirmationReceived->getSort() == "ASC") { ?><i class="fas fa-sort-up"></i><?php } elseif ($useremailaccount_grid->confirmationReceived->getSort() == "DESC") { ?><i class="fas fa-sort-down"></i><?php } ?></span></div>
		</div></div></th>
	<?php } ?>
<?php } ?>
<?php if ($useremailaccount_grid->active->Visible) { // active ?>
	<?php if ($useremailaccount_grid->SortUrl($useremailaccount_grid->active) == "") { ?>
		<th data-name="active" class="<?php echo $useremailaccount_grid->active->headerCellClass() ?>"><div id="elh_useremailaccount_active" class="useremailaccount_active"><div class="ew-table-header-caption"><?php echo $useremailaccount_grid->active->caption() ?></div></div></th>
	<?php } else { ?>
		<th data-name="active" class="<?php echo $useremailaccount_grid->active->headerCellClass() ?>"><div><div id="elh_useremailaccount_active" class="useremailaccount_active">
			<div class="ew-table-header-btn"><span class="ew-table-header-caption"><?php echo $useremailaccount_grid->active->caption() ?></span><span class="ew-table-header-sort"><?php if ($useremailaccount_grid->active->getSort() == "ASC") { ?><i class="fas fa-sort-up"></i><?php } elseif ($useremailaccount_grid->active->getSort() == "DESC") { ?><i class="fas fa-sort-down"></i><?php } ?></span></div>
		</div></div></th>
	<?php } ?>
<?php } ?>
<?php

// Render list options (header, right)
$useremailaccount_grid->ListOptions->render("header", "right");
?>
	</tr>
</thead>
<tbody>
<?php
$useremailaccount_grid->StartRecord = 1;
$useremailaccount_grid->StopRecord = $useremailaccount_grid->TotalRecords; // Show all records

// Restore number of post back records
if ($CurrentForm && ($useremailaccount->isConfirm() || $useremailaccount_grid->EventCancelled)) {
	$CurrentForm->Index = -1;
	if ($CurrentForm->hasValue($useremailaccount_grid->FormKeyCountName) && ($useremailaccount_grid->isGridAdd() || $useremailaccount_grid->isGridEdit() || $useremailaccount->isConfirm())) {
		$useremailaccount_grid->KeyCount = $CurrentForm->getValue($useremailaccount_grid->FormKeyCountName);
		$useremailaccount_grid->StopRecord = $useremailaccount_grid->StartRecord + $useremailaccount_grid->KeyCount - 1;
	}
}
$useremailaccount_grid->RecordCount = $useremailaccount_grid->StartRecord - 1;
if ($useremailaccount_grid->Recordset && !$useremailaccount_grid->Recordset->EOF) {
	$useremailaccount_grid->Recordset->moveFirst();
	$selectLimit = $useremailaccount_grid->UseSelectLimit;
	if (!$selectLimit && $useremailaccount_grid->StartRecord > 1)
		$useremailaccount_grid->Recordset->move($useremailaccount_grid->StartRecord - 1);
} elseif (!$useremailaccount->AllowAddDeleteRow && $useremailaccount_grid->StopRecord == 0) {
	$useremailaccount_grid->StopRecord = $useremailaccount->GridAddRowCount;
}

// Initialize aggregate
$useremailaccount->RowType = ROWTYPE_AGGREGATEINIT;
$useremailaccount->resetAttributes();
$useremailaccount_grid->renderRow();
if ($useremailaccount_grid->isGridAdd())
	$useremailaccount_grid->RowIndex = 0;
if ($useremailaccount_grid->isGridEdit())
	$useremailaccount_grid->RowIndex = 0;
while ($useremailaccount_grid->RecordCount < $useremailaccount_grid->StopRecord) {
	$useremailaccount_grid->RecordCount++;
	if ($useremailaccount_grid->RecordCount >= $useremailaccount_grid->StartRecord) {
		$useremailaccount_grid->RowCount++;
		if ($useremailaccount_grid->isGridAdd() || $useremailaccount_grid->isGridEdit() || $useremailaccount->isConfirm()) {
			$useremailaccount_grid->RowIndex++;
			$CurrentForm->Index = $useremailaccount_grid->RowIndex;
			if ($CurrentForm->hasValue($useremailaccount_grid->FormActionName) && ($useremailaccount->isConfirm() || $useremailaccount_grid->EventCancelled))
				$useremailaccount_grid->RowAction = strval($CurrentForm->getValue($useremailaccount_grid->FormActionName));
			elseif ($useremailaccount_grid->isGridAdd())
				$useremailaccount_grid->RowAction = "insert";
			else
				$useremailaccount_grid->RowAction = "";
		}

		// Set up key count
		$useremailaccount_grid->KeyCount = $useremailaccount_grid->RowIndex;

		// Init row class and style
		$useremailaccount->resetAttributes();
		$useremailaccount->CssClass = "";
		if ($useremailaccount_grid->isGridAdd()) {
			if ($useremailaccount->CurrentMode == "copy") {
				$useremailaccount_grid->loadRowValues($useremailaccount_grid->Recordset); // Load row values
				$useremailaccount_grid->setRecordKey($useremailaccount_grid->RowOldKey, $useremailaccount_grid->Recordset); // Set old record key
			} else {
				$useremailaccount_grid->loadRowValues(); // Load default values
				$useremailaccount_grid->RowOldKey = ""; // Clear old key value
			}
		} else {
			$useremailaccount_grid->loadRowValues($useremailaccount_grid->Recordset); // Load row values
		}
		$useremailaccount->RowType = ROWTYPE_VIEW; // Render view
		if ($useremailaccount_grid->isGridAdd()) // Grid add
			$useremailaccount->RowType = ROWTYPE_ADD; // Render add
		if ($useremailaccount_grid->isGridAdd() && $useremailaccount->EventCancelled && !$CurrentForm->hasValue("k_blankrow")) // Insert failed
			$useremailaccount_grid->restoreCurrentRowFormValues($useremailaccount_grid->RowIndex); // Restore form values
		if ($useremailaccount_grid->isGridEdit()) { // Grid edit
			if ($useremailaccount->EventCancelled)
				$useremailaccount_grid->restoreCurrentRowFormValues($useremailaccount_grid->RowIndex); // Restore form values
			if ($useremailaccount_grid->RowAction == "insert")
				$useremailaccount->RowType = ROWTYPE_ADD; // Render add
			else
				$useremailaccount->RowType = ROWTYPE_EDIT; // Render edit
		}
		if ($useremailaccount_grid->isGridEdit() && ($useremailaccount->RowType == ROWTYPE_EDIT || $useremailaccount->RowType == ROWTYPE_ADD) && $useremailaccount->EventCancelled) // Update failed
			$useremailaccount_grid->restoreCurrentRowFormValues($useremailaccount_grid->RowIndex); // Restore form values
		if ($useremailaccount->RowType == ROWTYPE_EDIT) // Edit row
			$useremailaccount_grid->EditRowCount++;
		if ($useremailaccount->isConfirm()) // Confirm row
			$useremailaccount_grid->restoreCurrentRowFormValues($useremailaccount_grid->RowIndex); // Restore form values

		// Set up row id / data-rowindex
		$useremailaccount->RowAttrs->merge(["data-rowindex" => $useremailaccount_grid->RowCount, "id" => "r" . $useremailaccount_grid->RowCount . "_useremailaccount", "data-rowtype" => $useremailaccount->RowType]);

		// Render row
		$useremailaccount_grid->renderRow();

		// Render list options
		$useremailaccount_grid->renderListOptions();

		// Skip delete row / empty row for confirm page
		if ($useremailaccount_grid->RowAction != "delete" && $useremailaccount_grid->RowAction != "insertdelete" && !($useremailaccount_grid->RowAction == "insert" && $useremailaccount->isConfirm() && $useremailaccount_grid->emptyRow())) {
?>
	<tr <?php echo $useremailaccount->rowAttributes() ?>>
<?php

// Render list options (body, left)
$useremailaccount_grid->ListOptions->render("body", "left", $useremailaccount_grid->RowCount);
?>
	<?php if ($useremailaccount_grid->_userID->Visible) { // userID ?>
		<td data-name="_userID" <?php echo $useremailaccount_grid->_userID->cellAttributes() ?>>
<?php if ($useremailaccount->RowType == ROWTYPE_ADD) { // Add record ?>
<?php if ($useremailaccount_grid->_userID->getSessionValue() != "") { ?>
<span id="el<?php echo $useremailaccount_grid->RowCount ?>_useremailaccount__userID" class="form-group">
<span<?php echo $useremailaccount_grid->_userID->viewAttributes() ?>><?php if (!EmptyString($useremailaccount_grid->_userID->ViewValue) && $useremailaccount_grid->_userID->linkAttributes() != "") { ?>
<a<?php echo $useremailaccount_grid->_userID->linkAttributes() ?>><input type="text" readonly class="form-control-plaintext" value="<?php echo HtmlEncode(RemoveHtml($useremailaccount_grid->_userID->ViewValue)) ?>"></a>
<?php } else { ?>
<input type="text" readonly class="form-control-plaintext" value="<?php echo HtmlEncode(RemoveHtml($useremailaccount_grid->_userID->ViewValue)) ?>">
<?php } ?></span>
</span>
<input type="hidden" id="x<?php echo $useremailaccount_grid->RowIndex ?>__userID" name="x<?php echo $useremailaccount_grid->RowIndex ?>__userID" value="<?php echo HtmlEncode($useremailaccount_grid->_userID->CurrentValue) ?>">
<?php } else { ?>
<span id="el<?php echo $useremailaccount_grid->RowCount ?>_useremailaccount__userID" class="form-group">
<input type="text" data-table="useremailaccount" data-field="x__userID" name="x<?php echo $useremailaccount_grid->RowIndex ?>__userID" id="x<?php echo $useremailaccount_grid->RowIndex ?>__userID" size="30" placeholder="<?php echo HtmlEncode($useremailaccount_grid->_userID->getPlaceHolder()) ?>" value="<?php echo $useremailaccount_grid->_userID->EditValue ?>"<?php echo $useremailaccount_grid->_userID->editAttributes() ?>>
</span>
<?php } ?>
<input type="hidden" data-table="useremailaccount" data-field="x__userID" name="o<?php echo $useremailaccount_grid->RowIndex ?>__userID" id="o<?php echo $useremailaccount_grid->RowIndex ?>__userID" value="<?php echo HtmlEncode($useremailaccount_grid->_userID->OldValue) ?>">
<?php } ?>
<?php if ($useremailaccount->RowType == ROWTYPE_EDIT) { // Edit record ?>
<?php if ($useremailaccount_grid->_userID->getSessionValue() != "") { ?>

<span id="el<?php echo $useremailaccount_grid->RowCount ?>_useremailaccount__userID" class="form-group">
<span<?php echo $useremailaccount_grid->_userID->viewAttributes() ?>><?php if (!EmptyString($useremailaccount_grid->_userID->EditValue) && $useremailaccount_grid->_userID->linkAttributes() != "") { ?>
<a<?php echo $useremailaccount_grid->_userID->linkAttributes() ?>><input type="text" readonly class="form-control-plaintext" value="<?php echo HtmlEncode(RemoveHtml($useremailaccount_grid->_userID->EditValue)) ?>"></a>
<?php } else { ?>
<input type="text" readonly class="form-control-plaintext" value="<?php echo HtmlEncode(RemoveHtml($useremailaccount_grid->_userID->EditValue)) ?>">
<?php } ?></span>
</span>

<input type="hidden" id="x<?php echo $useremailaccount_grid->RowIndex ?>__userID" name="x<?php echo $useremailaccount_grid->RowIndex ?>__userID" value="<?php echo HtmlEncode($useremailaccount_grid->_userID->CurrentValue) ?>">
<?php } else { ?>

<input type="text" data-table="useremailaccount" data-field="x__userID" name="x<?php echo $useremailaccount_grid->RowIndex ?>__userID" id="x<?php echo $useremailaccount_grid->RowIndex ?>__userID" size="30" placeholder="<?php echo HtmlEncode($useremailaccount_grid->_userID->getPlaceHolder()) ?>" value="<?php echo $useremailaccount_grid->_userID->EditValue ?>"<?php echo $useremailaccount_grid->_userID->editAttributes() ?>>

<?php } ?>

<input type="hidden" data-table="useremailaccount" data-field="x__userID" name="o<?php echo $useremailaccount_grid->RowIndex ?>__userID" id="o<?php echo $useremailaccount_grid->RowIndex ?>__userID" value="<?php echo HtmlEncode($useremailaccount_grid->_userID->OldValue != null ? $useremailaccount_grid->_userID->OldValue : $useremailaccount_grid->_userID->CurrentValue) ?>">
<?php } ?>
<?php if ($useremailaccount->RowType == ROWTYPE_VIEW) { // View record ?>
<span id="el<?php echo $useremailaccount_grid->RowCount ?>_useremailaccount__userID">
<span<?php echo $useremailaccount_grid->_userID->viewAttributes() ?>><?php if (!EmptyString($useremailaccount_grid->_userID->getViewValue()) && $useremailaccount_grid->_userID->linkAttributes() != "") { ?>
<a<?php echo $useremailaccount_grid->_userID->linkAttributes() ?>><?php echo $useremailaccount_grid->_userID->getViewValue() ?></a>
<?php } else { ?>
<?php echo $useremailaccount_grid->_userID->getViewValue() ?>
<?php } ?></span>
</span>
<?php if (!$useremailaccount->isConfirm()) { ?>
<input type="hidden" data-table="useremailaccount" data-field="x__userID" name="x<?php echo $useremailaccount_grid->RowIndex ?>__userID" id="x<?php echo $useremailaccount_grid->RowIndex ?>__userID" value="<?php echo HtmlEncode($useremailaccount_grid->_userID->FormValue) ?>">
<input type="hidden" data-table="useremailaccount" data-field="x__userID" name="o<?php echo $useremailaccount_grid->RowIndex ?>__userID" id="o<?php echo $useremailaccount_grid->RowIndex ?>__userID" value="<?php echo HtmlEncode($useremailaccount_grid->_userID->OldValue) ?>">
<?php } else { ?>
<input type="hidden" data-table="useremailaccount" data-field="x__userID" name="fuseremailaccountgrid$x<?php echo $useremailaccount_grid->RowIndex ?>__userID" id="fuseremailaccountgrid$x<?php echo $useremailaccount_grid->RowIndex ?>__userID" value="<?php echo HtmlEncode($useremailaccount_grid->_userID->FormValue) ?>">
<input type="hidden" data-table="useremailaccount" data-field="x__userID" name="fuseremailaccountgrid$o<?php echo $useremailaccount_grid->RowIndex ?>__userID" id="fuseremailaccountgrid$o<?php echo $useremailaccount_grid->RowIndex ?>__userID" value="<?php echo HtmlEncode($useremailaccount_grid->_userID->OldValue) ?>">
<?php } ?>
<?php } ?>
</td>
	<?php } ?>
	<?php if ($useremailaccount_grid->emailAccount->Visible) { // emailAccount ?>
		<td data-name="emailAccount" <?php echo $useremailaccount_grid->emailAccount->cellAttributes() ?>>
<?php if ($useremailaccount->RowType == ROWTYPE_ADD) { // Add record ?>
<span id="el<?php echo $useremailaccount_grid->RowCount ?>_useremailaccount_emailAccount" class="form-group">
<input type="text" data-table="useremailaccount" data-field="x_emailAccount" name="x<?php echo $useremailaccount_grid->RowIndex ?>_emailAccount" id="x<?php echo $useremailaccount_grid->RowIndex ?>_emailAccount" size="30" maxlength="60" placeholder="<?php echo HtmlEncode($useremailaccount_grid->emailAccount->getPlaceHolder()) ?>" value="<?php echo $useremailaccount_grid->emailAccount->EditValue ?>"<?php echo $useremailaccount_grid->emailAccount->editAttributes() ?>>
</span>
<input type="hidden" data-table="useremailaccount" data-field="x_emailAccount" name="o<?php echo $useremailaccount_grid->RowIndex ?>_emailAccount" id="o<?php echo $useremailaccount_grid->RowIndex ?>_emailAccount" value="<?php echo HtmlEncode($useremailaccount_grid->emailAccount->OldValue) ?>">
<?php } ?>
<?php if ($useremailaccount->RowType == ROWTYPE_EDIT) { // Edit record ?>
<input type="text" data-table="useremailaccount" data-field="x_emailAccount" name="x<?php echo $useremailaccount_grid->RowIndex ?>_emailAccount" id="x<?php echo $useremailaccount_grid->RowIndex ?>_emailAccount" size="30" maxlength="60" placeholder="<?php echo HtmlEncode($useremailaccount_grid->emailAccount->getPlaceHolder()) ?>" value="<?php echo $useremailaccount_grid->emailAccount->EditValue ?>"<?php echo $useremailaccount_grid->emailAccount->editAttributes() ?>>
<input type="hidden" data-table="useremailaccount" data-field="x_emailAccount" name="o<?php echo $useremailaccount_grid->RowIndex ?>_emailAccount" id="o<?php echo $useremailaccount_grid->RowIndex ?>_emailAccount" value="<?php echo HtmlEncode($useremailaccount_grid->emailAccount->OldValue != null ? $useremailaccount_grid->emailAccount->OldValue : $useremailaccount_grid->emailAccount->CurrentValue) ?>">
<?php } ?>
<?php if ($useremailaccount->RowType == ROWTYPE_VIEW) { // View record ?>
<span id="el<?php echo $useremailaccount_grid->RowCount ?>_useremailaccount_emailAccount">
<span<?php echo $useremailaccount_grid->emailAccount->viewAttributes() ?>><?php echo $useremailaccount_grid->emailAccount->getViewValue() ?></span>
</span>
<?php if (!$useremailaccount->isConfirm()) { ?>
<input type="hidden" data-table="useremailaccount" data-field="x_emailAccount" name="x<?php echo $useremailaccount_grid->RowIndex ?>_emailAccount" id="x<?php echo $useremailaccount_grid->RowIndex ?>_emailAccount" value="<?php echo HtmlEncode($useremailaccount_grid->emailAccount->FormValue) ?>">
<input type="hidden" data-table="useremailaccount" data-field="x_emailAccount" name="o<?php echo $useremailaccount_grid->RowIndex ?>_emailAccount" id="o<?php echo $useremailaccount_grid->RowIndex ?>_emailAccount" value="<?php echo HtmlEncode($useremailaccount_grid->emailAccount->OldValue) ?>">
<?php } else { ?>
<input type="hidden" data-table="useremailaccount" data-field="x_emailAccount" name="fuseremailaccountgrid$x<?php echo $useremailaccount_grid->RowIndex ?>_emailAccount" id="fuseremailaccountgrid$x<?php echo $useremailaccount_grid->RowIndex ?>_emailAccount" value="<?php echo HtmlEncode($useremailaccount_grid->emailAccount->FormValue) ?>">
<input type="hidden" data-table="useremailaccount" data-field="x_emailAccount" name="fuseremailaccountgrid$o<?php echo $useremailaccount_grid->RowIndex ?>_emailAccount" id="fuseremailaccountgrid$o<?php echo $useremailaccount_grid->RowIndex ?>_emailAccount" value="<?php echo HtmlEncode($useremailaccount_grid->emailAccount->OldValue) ?>">
<?php } ?>
<?php } ?>
</td>
	<?php } ?>
	<?php if ($useremailaccount_grid->dateAdded->Visible) { // dateAdded ?>
		<td data-name="dateAdded" <?php echo $useremailaccount_grid->dateAdded->cellAttributes() ?>>
<?php if ($useremailaccount->RowType == ROWTYPE_ADD) { // Add record ?>
<span id="el<?php echo $useremailaccount_grid->RowCount ?>_useremailaccount_dateAdded" class="form-group">
<input type="text" data-table="useremailaccount" data-field="x_dateAdded" data-format="1" name="x<?php echo $useremailaccount_grid->RowIndex ?>_dateAdded" id="x<?php echo $useremailaccount_grid->RowIndex ?>_dateAdded" placeholder="<?php echo HtmlEncode($useremailaccount_grid->dateAdded->getPlaceHolder()) ?>" value="<?php echo $useremailaccount_grid->dateAdded->EditValue ?>"<?php echo $useremailaccount_grid->dateAdded->editAttributes() ?>>
<?php if (!$useremailaccount_grid->dateAdded->ReadOnly && !$useremailaccount_grid->dateAdded->Disabled && !isset($useremailaccount_grid->dateAdded->EditAttrs["readonly"]) && !isset($useremailaccount_grid->dateAdded->EditAttrs["disabled"])) { ?>
<script>
loadjs.ready(["fuseremailaccountgrid", "datetimepicker"], function() {
	ew.createDateTimePicker("fuseremailaccountgrid", "x<?php echo $useremailaccount_grid->RowIndex ?>_dateAdded", {"ignoreReadonly":true,"useCurrent":false,"format":1});
});
</script>
<?php } ?>
</span>
<input type="hidden" data-table="useremailaccount" data-field="x_dateAdded" name="o<?php echo $useremailaccount_grid->RowIndex ?>_dateAdded" id="o<?php echo $useremailaccount_grid->RowIndex ?>_dateAdded" value="<?php echo HtmlEncode($useremailaccount_grid->dateAdded->OldValue) ?>">
<?php } ?>
<?php if ($useremailaccount->RowType == ROWTYPE_EDIT) { // Edit record ?>
<span id="el<?php echo $useremailaccount_grid->RowCount ?>_useremailaccount_dateAdded" class="form-group">
<input type="text" data-table="useremailaccount" data-field="x_dateAdded" data-format="1" name="x<?php echo $useremailaccount_grid->RowIndex ?>_dateAdded" id="x<?php echo $useremailaccount_grid->RowIndex ?>_dateAdded" placeholder="<?php echo HtmlEncode($useremailaccount_grid->dateAdded->getPlaceHolder()) ?>" value="<?php echo $useremailaccount_grid->dateAdded->EditValue ?>"<?php echo $useremailaccount_grid->dateAdded->editAttributes() ?>>
<?php if (!$useremailaccount_grid->dateAdded->ReadOnly && !$useremailaccount_grid->dateAdded->Disabled && !isset($useremailaccount_grid->dateAdded->EditAttrs["readonly"]) && !isset($useremailaccount_grid->dateAdded->EditAttrs["disabled"])) { ?>
<script>
loadjs.ready(["fuseremailaccountgrid", "datetimepicker"], function() {
	ew.createDateTimePicker("fuseremailaccountgrid", "x<?php echo $useremailaccount_grid->RowIndex ?>_dateAdded", {"ignoreReadonly":true,"useCurrent":false,"format":1});
});
</script>
<?php } ?>
</span>
<?php } ?>
<?php if ($useremailaccount->RowType == ROWTYPE_VIEW) { // View record ?>
<span id="el<?php echo $useremailaccount_grid->RowCount ?>_useremailaccount_dateAdded">
<span<?php echo $useremailaccount_grid->dateAdded->viewAttributes() ?>><?php echo $useremailaccount_grid->dateAdded->getViewValue() ?></span>
</span>
<?php if (!$useremailaccount->isConfirm()) { ?>
<input type="hidden" data-table="useremailaccount" data-field="x_dateAdded" name="x<?php echo $useremailaccount_grid->RowIndex ?>_dateAdded" id="x<?php echo $useremailaccount_grid->RowIndex ?>_dateAdded" value="<?php echo HtmlEncode($useremailaccount_grid->dateAdded->FormValue) ?>">
<input type="hidden" data-table="useremailaccount" data-field="x_dateAdded" name="o<?php echo $useremailaccount_grid->RowIndex ?>_dateAdded" id="o<?php echo $useremailaccount_grid->RowIndex ?>_dateAdded" value="<?php echo HtmlEncode($useremailaccount_grid->dateAdded->OldValue) ?>">
<?php } else { ?>
<input type="hidden" data-table="useremailaccount" data-field="x_dateAdded" name="fuseremailaccountgrid$x<?php echo $useremailaccount_grid->RowIndex ?>_dateAdded" id="fuseremailaccountgrid$x<?php echo $useremailaccount_grid->RowIndex ?>_dateAdded" value="<?php echo HtmlEncode($useremailaccount_grid->dateAdded->FormValue) ?>">
<input type="hidden" data-table="useremailaccount" data-field="x_dateAdded" name="fuseremailaccountgrid$o<?php echo $useremailaccount_grid->RowIndex ?>_dateAdded" id="fuseremailaccountgrid$o<?php echo $useremailaccount_grid->RowIndex ?>_dateAdded" value="<?php echo HtmlEncode($useremailaccount_grid->dateAdded->OldValue) ?>">
<?php } ?>
<?php } ?>
</td>
	<?php } ?>
	<?php if ($useremailaccount_grid->confirmationReceived->Visible) { // confirmationReceived ?>
		<td data-name="confirmationReceived" <?php echo $useremailaccount_grid->confirmationReceived->cellAttributes() ?>>
<?php if ($useremailaccount->RowType == ROWTYPE_ADD) { // Add record ?>
<span id="el<?php echo $useremailaccount_grid->RowCount ?>_useremailaccount_confirmationReceived" class="form-group">
<div id="tp_x<?php echo $useremailaccount_grid->RowIndex ?>_confirmationReceived" class="ew-template"><input type="radio" class="custom-control-input" data-table="useremailaccount" data-field="x_confirmationReceived" data-value-separator="<?php echo $useremailaccount_grid->confirmationReceived->displayValueSeparatorAttribute() ?>" name="x<?php echo $useremailaccount_grid->RowIndex ?>_confirmationReceived" id="x<?php echo $useremailaccount_grid->RowIndex ?>_confirmationReceived" value="{value}"<?php echo $useremailaccount_grid->confirmationReceived->editAttributes() ?>></div>
<div id="dsl_x<?php echo $useremailaccount_grid->RowIndex ?>_confirmationReceived" data-repeatcolumn="5" class="ew-item-list d-none"><div>
<?php echo $useremailaccount_grid->confirmationReceived->radioButtonListHtml(FALSE, "x{$useremailaccount_grid->RowIndex}_confirmationReceived") ?>
</div></div>
<?php echo $useremailaccount_grid->confirmationReceived->Lookup->getParamTag($useremailaccount_grid, "p_x" . $useremailaccount_grid->RowIndex . "_confirmationReceived") ?>
</span>
<input type="hidden" data-table="useremailaccount" data-field="x_confirmationReceived" name="o<?php echo $useremailaccount_grid->RowIndex ?>_confirmationReceived" id="o<?php echo $useremailaccount_grid->RowIndex ?>_confirmationReceived" value="<?php echo HtmlEncode($useremailaccount_grid->confirmationReceived->OldValue) ?>">
<?php } ?>
<?php if ($useremailaccount->RowType == ROWTYPE_EDIT) { // Edit record ?>
<span id="el<?php echo $useremailaccount_grid->RowCount ?>_useremailaccount_confirmationReceived" class="form-group">
<div id="tp_x<?php echo $useremailaccount_grid->RowIndex ?>_confirmationReceived" class="ew-template"><input type="radio" class="custom-control-input" data-table="useremailaccount" data-field="x_confirmationReceived" data-value-separator="<?php echo $useremailaccount_grid->confirmationReceived->displayValueSeparatorAttribute() ?>" name="x<?php echo $useremailaccount_grid->RowIndex ?>_confirmationReceived" id="x<?php echo $useremailaccount_grid->RowIndex ?>_confirmationReceived" value="{value}"<?php echo $useremailaccount_grid->confirmationReceived->editAttributes() ?>></div>
<div id="dsl_x<?php echo $useremailaccount_grid->RowIndex ?>_confirmationReceived" data-repeatcolumn="5" class="ew-item-list d-none"><div>
<?php echo $useremailaccount_grid->confirmationReceived->radioButtonListHtml(FALSE, "x{$useremailaccount_grid->RowIndex}_confirmationReceived") ?>
</div></div>
<?php echo $useremailaccount_grid->confirmationReceived->Lookup->getParamTag($useremailaccount_grid, "p_x" . $useremailaccount_grid->RowIndex . "_confirmationReceived") ?>
</span>
<?php } ?>
<?php if ($useremailaccount->RowType == ROWTYPE_VIEW) { // View record ?>
<span id="el<?php echo $useremailaccount_grid->RowCount ?>_useremailaccount_confirmationReceived">
<span<?php echo $useremailaccount_grid->confirmationReceived->viewAttributes() ?>><?php echo $useremailaccount_grid->confirmationReceived->getViewValue() ?></span>
</span>
<?php if (!$useremailaccount->isConfirm()) { ?>
<input type="hidden" data-table="useremailaccount" data-field="x_confirmationReceived" name="x<?php echo $useremailaccount_grid->RowIndex ?>_confirmationReceived" id="x<?php echo $useremailaccount_grid->RowIndex ?>_confirmationReceived" value="<?php echo HtmlEncode($useremailaccount_grid->confirmationReceived->FormValue) ?>">
<input type="hidden" data-table="useremailaccount" data-field="x_confirmationReceived" name="o<?php echo $useremailaccount_grid->RowIndex ?>_confirmationReceived" id="o<?php echo $useremailaccount_grid->RowIndex ?>_confirmationReceived" value="<?php echo HtmlEncode($useremailaccount_grid->confirmationReceived->OldValue) ?>">
<?php } else { ?>
<input type="hidden" data-table="useremailaccount" data-field="x_confirmationReceived" name="fuseremailaccountgrid$x<?php echo $useremailaccount_grid->RowIndex ?>_confirmationReceived" id="fuseremailaccountgrid$x<?php echo $useremailaccount_grid->RowIndex ?>_confirmationReceived" value="<?php echo HtmlEncode($useremailaccount_grid->confirmationReceived->FormValue) ?>">
<input type="hidden" data-table="useremailaccount" data-field="x_confirmationReceived" name="fuseremailaccountgrid$o<?php echo $useremailaccount_grid->RowIndex ?>_confirmationReceived" id="fuseremailaccountgrid$o<?php echo $useremailaccount_grid->RowIndex ?>_confirmationReceived" value="<?php echo HtmlEncode($useremailaccount_grid->confirmationReceived->OldValue) ?>">
<?php } ?>
<?php } ?>
</td>
	<?php } ?>
	<?php if ($useremailaccount_grid->active->Visible) { // active ?>
		<td data-name="active" <?php echo $useremailaccount_grid->active->cellAttributes() ?>>
<?php if ($useremailaccount->RowType == ROWTYPE_ADD) { // Add record ?>
<span id="el<?php echo $useremailaccount_grid->RowCount ?>_useremailaccount_active" class="form-group">
<div id="tp_x<?php echo $useremailaccount_grid->RowIndex ?>_active" class="ew-template"><input type="radio" class="custom-control-input" data-table="useremailaccount" data-field="x_active" data-value-separator="<?php echo $useremailaccount_grid->active->displayValueSeparatorAttribute() ?>" name="x<?php echo $useremailaccount_grid->RowIndex ?>_active" id="x<?php echo $useremailaccount_grid->RowIndex ?>_active" value="{value}"<?php echo $useremailaccount_grid->active->editAttributes() ?>></div>
<div id="dsl_x<?php echo $useremailaccount_grid->RowIndex ?>_active" data-repeatcolumn="5" class="ew-item-list d-none"><div>
<?php echo $useremailaccount_grid->active->radioButtonListHtml(FALSE, "x{$useremailaccount_grid->RowIndex}_active") ?>
</div></div>
<?php echo $useremailaccount_grid->active->Lookup->getParamTag($useremailaccount_grid, "p_x" . $useremailaccount_grid->RowIndex . "_active") ?>
</span>
<input type="hidden" data-table="useremailaccount" data-field="x_active" name="o<?php echo $useremailaccount_grid->RowIndex ?>_active" id="o<?php echo $useremailaccount_grid->RowIndex ?>_active" value="<?php echo HtmlEncode($useremailaccount_grid->active->OldValue) ?>">
<?php } ?>
<?php if ($useremailaccount->RowType == ROWTYPE_EDIT) { // Edit record ?>
<span id="el<?php echo $useremailaccount_grid->RowCount ?>_useremailaccount_active" class="form-group">
<div id="tp_x<?php echo $useremailaccount_grid->RowIndex ?>_active" class="ew-template"><input type="radio" class="custom-control-input" data-table="useremailaccount" data-field="x_active" data-value-separator="<?php echo $useremailaccount_grid->active->displayValueSeparatorAttribute() ?>" name="x<?php echo $useremailaccount_grid->RowIndex ?>_active" id="x<?php echo $useremailaccount_grid->RowIndex ?>_active" value="{value}"<?php echo $useremailaccount_grid->active->editAttributes() ?>></div>
<div id="dsl_x<?php echo $useremailaccount_grid->RowIndex ?>_active" data-repeatcolumn="5" class="ew-item-list d-none"><div>
<?php echo $useremailaccount_grid->active->radioButtonListHtml(FALSE, "x{$useremailaccount_grid->RowIndex}_active") ?>
</div></div>
<?php echo $useremailaccount_grid->active->Lookup->getParamTag($useremailaccount_grid, "p_x" . $useremailaccount_grid->RowIndex . "_active") ?>
</span>
<?php } ?>
<?php if ($useremailaccount->RowType == ROWTYPE_VIEW) { // View record ?>
<span id="el<?php echo $useremailaccount_grid->RowCount ?>_useremailaccount_active">
<span<?php echo $useremailaccount_grid->active->viewAttributes() ?>><?php echo $useremailaccount_grid->active->getViewValue() ?></span>
</span>
<?php if (!$useremailaccount->isConfirm()) { ?>
<input type="hidden" data-table="useremailaccount" data-field="x_active" name="x<?php echo $useremailaccount_grid->RowIndex ?>_active" id="x<?php echo $useremailaccount_grid->RowIndex ?>_active" value="<?php echo HtmlEncode($useremailaccount_grid->active->FormValue) ?>">
<input type="hidden" data-table="useremailaccount" data-field="x_active" name="o<?php echo $useremailaccount_grid->RowIndex ?>_active" id="o<?php echo $useremailaccount_grid->RowIndex ?>_active" value="<?php echo HtmlEncode($useremailaccount_grid->active->OldValue) ?>">
<?php } else { ?>
<input type="hidden" data-table="useremailaccount" data-field="x_active" name="fuseremailaccountgrid$x<?php echo $useremailaccount_grid->RowIndex ?>_active" id="fuseremailaccountgrid$x<?php echo $useremailaccount_grid->RowIndex ?>_active" value="<?php echo HtmlEncode($useremailaccount_grid->active->FormValue) ?>">
<input type="hidden" data-table="useremailaccount" data-field="x_active" name="fuseremailaccountgrid$o<?php echo $useremailaccount_grid->RowIndex ?>_active" id="fuseremailaccountgrid$o<?php echo $useremailaccount_grid->RowIndex ?>_active" value="<?php echo HtmlEncode($useremailaccount_grid->active->OldValue) ?>">
<?php } ?>
<?php } ?>
</td>
	<?php } ?>
<?php

// Render list options (body, right)
$useremailaccount_grid->ListOptions->render("body", "right", $useremailaccount_grid->RowCount);
?>
	</tr>
<?php if ($useremailaccount->RowType == ROWTYPE_ADD || $useremailaccount->RowType == ROWTYPE_EDIT) { ?>
<script>
loadjs.ready(["fuseremailaccountgrid", "load"], function() {
	fuseremailaccountgrid.updateLists(<?php echo $useremailaccount_grid->RowIndex ?>);
});
</script>
<?php } ?>
<?php
	}
	} // End delete row checking
	if (!$useremailaccount_grid->isGridAdd() || $useremailaccount->CurrentMode == "copy")
		if (!$useremailaccount_grid->Recordset->EOF)
			$useremailaccount_grid->Recordset->moveNext();
}
?>
<?php
	if ($useremailaccount->CurrentMode == "add" || $useremailaccount->CurrentMode == "copy" || $useremailaccount->CurrentMode == "edit") {
		$useremailaccount_grid->RowIndex = '$rowindex$';
		$useremailaccount_grid->loadRowValues();

		// Set row properties
		$useremailaccount->resetAttributes();
		$useremailaccount->RowAttrs->merge(["data-rowindex" => $useremailaccount_grid->RowIndex, "id" => "r0_useremailaccount", "data-rowtype" => ROWTYPE_ADD]);
		$useremailaccount->RowAttrs->appendClass("ew-template");
		$useremailaccount->RowType = ROWTYPE_ADD;

		// Render row
		$useremailaccount_grid->renderRow();

		// Render list options
		$useremailaccount_grid->renderListOptions();
		$useremailaccount_grid->StartRowCount = 0;
?>
	<tr <?php echo $useremailaccount->rowAttributes() ?>>
<?php

// Render list options (body, left)
$useremailaccount_grid->ListOptions->render("body", "left", $useremailaccount_grid->RowIndex);
?>
	<?php if ($useremailaccount_grid->_userID->Visible) { // userID ?>
		<td data-name="_userID">
<?php if (!$useremailaccount->isConfirm()) { ?>
<?php if ($useremailaccount_grid->_userID->getSessionValue() != "") { ?>
<span id="el$rowindex$_useremailaccount__userID" class="form-group useremailaccount__userID">
<span<?php echo $useremailaccount_grid->_userID->viewAttributes() ?>><?php if (!EmptyString($useremailaccount_grid->_userID->ViewValue) && $useremailaccount_grid->_userID->linkAttributes() != "") { ?>
<a<?php echo $useremailaccount_grid->_userID->linkAttributes() ?>><input type="text" readonly class="form-control-plaintext" value="<?php echo HtmlEncode(RemoveHtml($useremailaccount_grid->_userID->ViewValue)) ?>"></a>
<?php } else { ?>
<input type="text" readonly class="form-control-plaintext" value="<?php echo HtmlEncode(RemoveHtml($useremailaccount_grid->_userID->ViewValue)) ?>">
<?php } ?></span>
</span>
<input type="hidden" id="x<?php echo $useremailaccount_grid->RowIndex ?>__userID" name="x<?php echo $useremailaccount_grid->RowIndex ?>__userID" value="<?php echo HtmlEncode($useremailaccount_grid->_userID->CurrentValue) ?>">
<?php } else { ?>
<span id="el$rowindex$_useremailaccount__userID" class="form-group useremailaccount__userID">
<input type="text" data-table="useremailaccount" data-field="x__userID" name="x<?php echo $useremailaccount_grid->RowIndex ?>__userID" id="x<?php echo $useremailaccount_grid->RowIndex ?>__userID" size="30" placeholder="<?php echo HtmlEncode($useremailaccount_grid->_userID->getPlaceHolder()) ?>" value="<?php echo $useremailaccount_grid->_userID->EditValue ?>"<?php echo $useremailaccount_grid->_userID->editAttributes() ?>>
</span>
<?php } ?>
<?php } else { ?>
<span id="el$rowindex$_useremailaccount__userID" class="form-group useremailaccount__userID">
<span<?php echo $useremailaccount_grid->_userID->viewAttributes() ?>><?php if (!EmptyString($useremailaccount_grid->_userID->ViewValue) && $useremailaccount_grid->_userID->linkAttributes() != "") { ?>
<a<?php echo $useremailaccount_grid->_userID->linkAttributes() ?>><input type="text" readonly class="form-control-plaintext" value="<?php echo HtmlEncode(RemoveHtml($useremailaccount_grid->_userID->ViewValue)) ?>"></a>
<?php } else { ?>
<input type="text" readonly class="form-control-plaintext" value="<?php echo HtmlEncode(RemoveHtml($useremailaccount_grid->_userID->ViewValue)) ?>">
<?php } ?></span>
</span>
<input type="hidden" data-table="useremailaccount" data-field="x__userID" name="x<?php echo $useremailaccount_grid->RowIndex ?>__userID" id="x<?php echo $useremailaccount_grid->RowIndex ?>__userID" value="<?php echo HtmlEncode($useremailaccount_grid->_userID->FormValue) ?>">
<?php } ?>
<input type="hidden" data-table="useremailaccount" data-field="x__userID" name="o<?php echo $useremailaccount_grid->RowIndex ?>__userID" id="o<?php echo $useremailaccount_grid->RowIndex ?>__userID" value="<?php echo HtmlEncode($useremailaccount_grid->_userID->OldValue) ?>">
</td>
	<?php } ?>
	<?php if ($useremailaccount_grid->emailAccount->Visible) { // emailAccount ?>
		<td data-name="emailAccount">
<?php if (!$useremailaccount->isConfirm()) { ?>
<span id="el$rowindex$_useremailaccount_emailAccount" class="form-group useremailaccount_emailAccount">
<input type="text" data-table="useremailaccount" data-field="x_emailAccount" name="x<?php echo $useremailaccount_grid->RowIndex ?>_emailAccount" id="x<?php echo $useremailaccount_grid->RowIndex ?>_emailAccount" size="30" maxlength="60" placeholder="<?php echo HtmlEncode($useremailaccount_grid->emailAccount->getPlaceHolder()) ?>" value="<?php echo $useremailaccount_grid->emailAccount->EditValue ?>"<?php echo $useremailaccount_grid->emailAccount->editAttributes() ?>>
</span>
<?php } else { ?>
<span id="el$rowindex$_useremailaccount_emailAccount" class="form-group useremailaccount_emailAccount">
<span<?php echo $useremailaccount_grid->emailAccount->viewAttributes() ?>><input type="text" readonly class="form-control-plaintext" value="<?php echo HtmlEncode(RemoveHtml($useremailaccount_grid->emailAccount->ViewValue)) ?>"></span>
</span>
<input type="hidden" data-table="useremailaccount" data-field="x_emailAccount" name="x<?php echo $useremailaccount_grid->RowIndex ?>_emailAccount" id="x<?php echo $useremailaccount_grid->RowIndex ?>_emailAccount" value="<?php echo HtmlEncode($useremailaccount_grid->emailAccount->FormValue) ?>">
<?php } ?>
<input type="hidden" data-table="useremailaccount" data-field="x_emailAccount" name="o<?php echo $useremailaccount_grid->RowIndex ?>_emailAccount" id="o<?php echo $useremailaccount_grid->RowIndex ?>_emailAccount" value="<?php echo HtmlEncode($useremailaccount_grid->emailAccount->OldValue) ?>">
</td>
	<?php } ?>
	<?php if ($useremailaccount_grid->dateAdded->Visible) { // dateAdded ?>
		<td data-name="dateAdded">
<?php if (!$useremailaccount->isConfirm()) { ?>
<span id="el$rowindex$_useremailaccount_dateAdded" class="form-group useremailaccount_dateAdded">
<input type="text" data-table="useremailaccount" data-field="x_dateAdded" data-format="1" name="x<?php echo $useremailaccount_grid->RowIndex ?>_dateAdded" id="x<?php echo $useremailaccount_grid->RowIndex ?>_dateAdded" placeholder="<?php echo HtmlEncode($useremailaccount_grid->dateAdded->getPlaceHolder()) ?>" value="<?php echo $useremailaccount_grid->dateAdded->EditValue ?>"<?php echo $useremailaccount_grid->dateAdded->editAttributes() ?>>
<?php if (!$useremailaccount_grid->dateAdded->ReadOnly && !$useremailaccount_grid->dateAdded->Disabled && !isset($useremailaccount_grid->dateAdded->EditAttrs["readonly"]) && !isset($useremailaccount_grid->dateAdded->EditAttrs["disabled"])) { ?>
<script>
loadjs.ready(["fuseremailaccountgrid", "datetimepicker"], function() {
	ew.createDateTimePicker("fuseremailaccountgrid", "x<?php echo $useremailaccount_grid->RowIndex ?>_dateAdded", {"ignoreReadonly":true,"useCurrent":false,"format":1});
});
</script>
<?php } ?>
</span>
<?php } else { ?>
<span id="el$rowindex$_useremailaccount_dateAdded" class="form-group useremailaccount_dateAdded">
<span<?php echo $useremailaccount_grid->dateAdded->viewAttributes() ?>><input type="text" readonly class="form-control-plaintext" value="<?php echo HtmlEncode(RemoveHtml($useremailaccount_grid->dateAdded->ViewValue)) ?>"></span>
</span>
<input type="hidden" data-table="useremailaccount" data-field="x_dateAdded" name="x<?php echo $useremailaccount_grid->RowIndex ?>_dateAdded" id="x<?php echo $useremailaccount_grid->RowIndex ?>_dateAdded" value="<?php echo HtmlEncode($useremailaccount_grid->dateAdded->FormValue) ?>">
<?php } ?>
<input type="hidden" data-table="useremailaccount" data-field="x_dateAdded" name="o<?php echo $useremailaccount_grid->RowIndex ?>_dateAdded" id="o<?php echo $useremailaccount_grid->RowIndex ?>_dateAdded" value="<?php echo HtmlEncode($useremailaccount_grid->dateAdded->OldValue) ?>">
</td>
	<?php } ?>
	<?php if ($useremailaccount_grid->confirmationReceived->Visible) { // confirmationReceived ?>
		<td data-name="confirmationReceived">
<?php if (!$useremailaccount->isConfirm()) { ?>
<span id="el$rowindex$_useremailaccount_confirmationReceived" class="form-group useremailaccount_confirmationReceived">
<div id="tp_x<?php echo $useremailaccount_grid->RowIndex ?>_confirmationReceived" class="ew-template"><input type="radio" class="custom-control-input" data-table="useremailaccount" data-field="x_confirmationReceived" data-value-separator="<?php echo $useremailaccount_grid->confirmationReceived->displayValueSeparatorAttribute() ?>" name="x<?php echo $useremailaccount_grid->RowIndex ?>_confirmationReceived" id="x<?php echo $useremailaccount_grid->RowIndex ?>_confirmationReceived" value="{value}"<?php echo $useremailaccount_grid->confirmationReceived->editAttributes() ?>></div>
<div id="dsl_x<?php echo $useremailaccount_grid->RowIndex ?>_confirmationReceived" data-repeatcolumn="5" class="ew-item-list d-none"><div>
<?php echo $useremailaccount_grid->confirmationReceived->radioButtonListHtml(FALSE, "x{$useremailaccount_grid->RowIndex}_confirmationReceived") ?>
</div></div>
<?php echo $useremailaccount_grid->confirmationReceived->Lookup->getParamTag($useremailaccount_grid, "p_x" . $useremailaccount_grid->RowIndex . "_confirmationReceived") ?>
</span>
<?php } else { ?>
<span id="el$rowindex$_useremailaccount_confirmationReceived" class="form-group useremailaccount_confirmationReceived">
<span<?php echo $useremailaccount_grid->confirmationReceived->viewAttributes() ?>><input type="text" readonly class="form-control-plaintext" value="<?php echo HtmlEncode(RemoveHtml($useremailaccount_grid->confirmationReceived->ViewValue)) ?>"></span>
</span>
<input type="hidden" data-table="useremailaccount" data-field="x_confirmationReceived" name="x<?php echo $useremailaccount_grid->RowIndex ?>_confirmationReceived" id="x<?php echo $useremailaccount_grid->RowIndex ?>_confirmationReceived" value="<?php echo HtmlEncode($useremailaccount_grid->confirmationReceived->FormValue) ?>">
<?php } ?>
<input type="hidden" data-table="useremailaccount" data-field="x_confirmationReceived" name="o<?php echo $useremailaccount_grid->RowIndex ?>_confirmationReceived" id="o<?php echo $useremailaccount_grid->RowIndex ?>_confirmationReceived" value="<?php echo HtmlEncode($useremailaccount_grid->confirmationReceived->OldValue) ?>">
</td>
	<?php } ?>
	<?php if ($useremailaccount_grid->active->Visible) { // active ?>
		<td data-name="active">
<?php if (!$useremailaccount->isConfirm()) { ?>
<span id="el$rowindex$_useremailaccount_active" class="form-group useremailaccount_active">
<div id="tp_x<?php echo $useremailaccount_grid->RowIndex ?>_active" class="ew-template"><input type="radio" class="custom-control-input" data-table="useremailaccount" data-field="x_active" data-value-separator="<?php echo $useremailaccount_grid->active->displayValueSeparatorAttribute() ?>" name="x<?php echo $useremailaccount_grid->RowIndex ?>_active" id="x<?php echo $useremailaccount_grid->RowIndex ?>_active" value="{value}"<?php echo $useremailaccount_grid->active->editAttributes() ?>></div>
<div id="dsl_x<?php echo $useremailaccount_grid->RowIndex ?>_active" data-repeatcolumn="5" class="ew-item-list d-none"><div>
<?php echo $useremailaccount_grid->active->radioButtonListHtml(FALSE, "x{$useremailaccount_grid->RowIndex}_active") ?>
</div></div>
<?php echo $useremailaccount_grid->active->Lookup->getParamTag($useremailaccount_grid, "p_x" . $useremailaccount_grid->RowIndex . "_active") ?>
</span>
<?php } else { ?>
<span id="el$rowindex$_useremailaccount_active" class="form-group useremailaccount_active">
<span<?php echo $useremailaccount_grid->active->viewAttributes() ?>><input type="text" readonly class="form-control-plaintext" value="<?php echo HtmlEncode(RemoveHtml($useremailaccount_grid->active->ViewValue)) ?>"></span>
</span>
<input type="hidden" data-table="useremailaccount" data-field="x_active" name="x<?php echo $useremailaccount_grid->RowIndex ?>_active" id="x<?php echo $useremailaccount_grid->RowIndex ?>_active" value="<?php echo HtmlEncode($useremailaccount_grid->active->FormValue) ?>">
<?php } ?>
<input type="hidden" data-table="useremailaccount" data-field="x_active" name="o<?php echo $useremailaccount_grid->RowIndex ?>_active" id="o<?php echo $useremailaccount_grid->RowIndex ?>_active" value="<?php echo HtmlEncode($useremailaccount_grid->active->OldValue) ?>">
</td>
	<?php } ?>
<?php

// Render list options (body, right)
$useremailaccount_grid->ListOptions->render("body", "right", $useremailaccount_grid->RowIndex);
?>
<script>
loadjs.ready(["fuseremailaccountgrid", "load"], function() {
	fuseremailaccountgrid.updateLists(<?php echo $useremailaccount_grid->RowIndex ?>);
});
</script>
	</tr>
<?php
	}
?>
</tbody>
</table><!-- /.ew-table -->
</div><!-- /.ew-grid-middle-panel -->
<?php if ($useremailaccount->CurrentMode == "add" || $useremailaccount->CurrentMode == "copy") { ?>
<input type="hidden" name="<?php echo $useremailaccount_grid->FormKeyCountName ?>" id="<?php echo $useremailaccount_grid->FormKeyCountName ?>" value="<?php echo $useremailaccount_grid->KeyCount ?>">
<?php echo $useremailaccount_grid->MultiSelectKey ?>
<?php } ?>
<?php if ($useremailaccount->CurrentMode == "edit") { ?>
<input type="hidden" name="<?php echo $useremailaccount_grid->FormKeyCountName ?>" id="<?php echo $useremailaccount_grid->FormKeyCountName ?>" value="<?php echo $useremailaccount_grid->KeyCount ?>">
<?php echo $useremailaccount_grid->MultiSelectKey ?>
<?php } ?>
<?php if ($useremailaccount->CurrentMode == "") { ?>
<input type="hidden" name="action" id="action" value="">
<?php } ?>
<input type="hidden" name="detailpage" value="fuseremailaccountgrid">
</div><!-- /.ew-list-form -->
<?php

// Close recordset
if ($useremailaccount_grid->Recordset)
	$useremailaccount_grid->Recordset->Close();
?>
<?php if ($useremailaccount_grid->ShowOtherOptions) { ?>
<div class="card-footer ew-grid-lower-panel">
<?php $useremailaccount_grid->OtherOptions->render("body", "bottom") ?>
</div>
<div class="clearfix"></div>
<?php } ?>
</div><!-- /.ew-grid -->
<?php } ?>
<?php if ($useremailaccount_grid->TotalRecords == 0 && !$useremailaccount->CurrentAction) { // Show other options ?>
<div class="ew-list-other-options">
<?php $useremailaccount_grid->OtherOptions->render("body") ?>
</div>
<div class="clearfix"></div>
<?php } ?>
<?php if (!$useremailaccount_grid->isExport()) { ?>
<script>
loadjs.ready("load", function() {

	// Startup script
	// Write your table-specific startup script here
	// console.log("page loaded");

});
</script>
<?php } ?>
<?php
$useremailaccount_grid->terminate();
?>