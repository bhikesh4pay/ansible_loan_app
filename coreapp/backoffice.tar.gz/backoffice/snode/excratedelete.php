<?php
namespace PHPMaker2020\_4payadmin;

// Autoload
include_once "autoload.php";

// Session
if (session_status() !== PHP_SESSION_ACTIVE)
	\Delight\Cookie\Session::start(Config("COOKIE_SAMESITE")); // Init session data

// Output buffering
ob_start();
?>
<?php

// Write header
WriteHeader(FALSE);

// Create page object
$excrate_delete = new excrate_delete();

// Run the page
$excrate_delete->run();

// Setup login status
SetupLoginStatus();
SetClientVar("login", LoginStatus());

// Global Page Rendering event (in userfn*.php)
Page_Rendering();

// Page Rendering event
$excrate_delete->Page_Render();
?>
<?php include_once "header.php"; ?>
<script>
var fexcratedelete, currentPageID;
loadjs.ready("head", function() {

	// Form object
	currentPageID = ew.PAGE_ID = "delete";
	fexcratedelete = currentForm = new ew.Form("fexcratedelete", "delete");
	loadjs.done("fexcratedelete");
});
</script>
<script>
loadjs.ready("head", function() {

	// Client script
	// Write your client script here, no need to add script tags.

});
</script>
<?php $excrate_delete->showPageHeader(); ?>
<?php
$excrate_delete->showMessage();
?>
<form name="fexcratedelete" id="fexcratedelete" class="form-inline ew-form ew-delete-form" action="<?php echo CurrentPageName() ?>" method="post">
<?php if ($Page->CheckToken) { ?>
<input type="hidden" name="<?php echo Config("TOKEN_NAME") ?>" value="<?php echo $Page->Token ?>">
<?php } ?>
<input type="hidden" name="t" value="excrate">
<input type="hidden" name="action" id="action" value="delete">
<?php foreach ($excrate_delete->RecKeys as $key) { ?>
<?php $keyvalue = is_array($key) ? implode(Config("COMPOSITE_KEY_SEPARATOR"), $key) : $key; ?>
<input type="hidden" name="key_m[]" value="<?php echo HtmlEncode($keyvalue) ?>">
<?php } ?>
<div class="card ew-card ew-grid">
<div class="<?php echo ResponsiveTableClass() ?>card-body ew-grid-middle-panel">
<table class="table ew-table">
	<thead>
	<tr class="ew-table-header">
<?php if ($excrate_delete->_userID->Visible) { // userID ?>
		<th class="<?php echo $excrate_delete->_userID->headerCellClass() ?>"><span id="elh_excrate__userID" class="excrate__userID"><?php echo $excrate_delete->_userID->caption() ?></span></th>
<?php } ?>
<?php if ($excrate_delete->baseCurr->Visible) { // baseCurr ?>
		<th class="<?php echo $excrate_delete->baseCurr->headerCellClass() ?>"><span id="elh_excrate_baseCurr" class="excrate_baseCurr"><?php echo $excrate_delete->baseCurr->caption() ?></span></th>
<?php } ?>
<?php if ($excrate_delete->tradingCurr->Visible) { // tradingCurr ?>
		<th class="<?php echo $excrate_delete->tradingCurr->headerCellClass() ?>"><span id="elh_excrate_tradingCurr" class="excrate_tradingCurr"><?php echo $excrate_delete->tradingCurr->caption() ?></span></th>
<?php } ?>
<?php if ($excrate_delete->sellingRate->Visible) { // sellingRate ?>
		<th class="<?php echo $excrate_delete->sellingRate->headerCellClass() ?>"><span id="elh_excrate_sellingRate" class="excrate_sellingRate"><?php echo $excrate_delete->sellingRate->caption() ?></span></th>
<?php } ?>
<?php if ($excrate_delete->buyingRate->Visible) { // buyingRate ?>
		<th class="<?php echo $excrate_delete->buyingRate->headerCellClass() ?>"><span id="elh_excrate_buyingRate" class="excrate_buyingRate"><?php echo $excrate_delete->buyingRate->caption() ?></span></th>
<?php } ?>
<?php if ($excrate_delete->status->Visible) { // status ?>
		<th class="<?php echo $excrate_delete->status->headerCellClass() ?>"><span id="elh_excrate_status" class="excrate_status"><?php echo $excrate_delete->status->caption() ?></span></th>
<?php } ?>
	</tr>
	</thead>
	<tbody>
<?php
$excrate_delete->RecordCount = 0;
$i = 0;
while (!$excrate_delete->Recordset->EOF) {
	$excrate_delete->RecordCount++;
	$excrate_delete->RowCount++;

	// Set row properties
	$excrate->resetAttributes();
	$excrate->RowType = ROWTYPE_VIEW; // View

	// Get the field contents
	$excrate_delete->loadRowValues($excrate_delete->Recordset);

	// Render row
	$excrate_delete->renderRow();
?>
	<tr <?php echo $excrate->rowAttributes() ?>>
<?php if ($excrate_delete->_userID->Visible) { // userID ?>
		<td <?php echo $excrate_delete->_userID->cellAttributes() ?>>
<span id="el<?php echo $excrate_delete->RowCount ?>_excrate__userID" class="excrate__userID">
<span<?php echo $excrate_delete->_userID->viewAttributes() ?>><?php echo $excrate_delete->_userID->getViewValue() ?></span>
</span>
</td>
<?php } ?>
<?php if ($excrate_delete->baseCurr->Visible) { // baseCurr ?>
		<td <?php echo $excrate_delete->baseCurr->cellAttributes() ?>>
<span id="el<?php echo $excrate_delete->RowCount ?>_excrate_baseCurr" class="excrate_baseCurr">
<span<?php echo $excrate_delete->baseCurr->viewAttributes() ?>><?php echo $excrate_delete->baseCurr->getViewValue() ?></span>
</span>
</td>
<?php } ?>
<?php if ($excrate_delete->tradingCurr->Visible) { // tradingCurr ?>
		<td <?php echo $excrate_delete->tradingCurr->cellAttributes() ?>>
<span id="el<?php echo $excrate_delete->RowCount ?>_excrate_tradingCurr" class="excrate_tradingCurr">
<span<?php echo $excrate_delete->tradingCurr->viewAttributes() ?>><?php echo $excrate_delete->tradingCurr->getViewValue() ?></span>
</span>
</td>
<?php } ?>
<?php if ($excrate_delete->sellingRate->Visible) { // sellingRate ?>
		<td <?php echo $excrate_delete->sellingRate->cellAttributes() ?>>
<span id="el<?php echo $excrate_delete->RowCount ?>_excrate_sellingRate" class="excrate_sellingRate">
<span<?php echo $excrate_delete->sellingRate->viewAttributes() ?>><?php echo $excrate_delete->sellingRate->getViewValue() ?></span>
</span>
</td>
<?php } ?>
<?php if ($excrate_delete->buyingRate->Visible) { // buyingRate ?>
		<td <?php echo $excrate_delete->buyingRate->cellAttributes() ?>>
<span id="el<?php echo $excrate_delete->RowCount ?>_excrate_buyingRate" class="excrate_buyingRate">
<span<?php echo $excrate_delete->buyingRate->viewAttributes() ?>><?php echo $excrate_delete->buyingRate->getViewValue() ?></span>
</span>
</td>
<?php } ?>
<?php if ($excrate_delete->status->Visible) { // status ?>
		<td <?php echo $excrate_delete->status->cellAttributes() ?>>
<span id="el<?php echo $excrate_delete->RowCount ?>_excrate_status" class="excrate_status">
<span<?php echo $excrate_delete->status->viewAttributes() ?>><?php echo $excrate_delete->status->getViewValue() ?></span>
</span>
</td>
<?php } ?>
	</tr>
<?php
	$excrate_delete->Recordset->moveNext();
}
$excrate_delete->Recordset->close();
?>
</tbody>
</table>
</div>
</div>
<div>
<button class="btn btn-primary ew-btn" name="btn-action" id="btn-action" type="submit"><?php echo $Language->phrase("DeleteBtn") ?></button>
<button class="btn btn-default ew-btn" name="btn-cancel" id="btn-cancel" type="button" data-href="<?php echo $excrate_delete->getReturnUrl() ?>"><?php echo $Language->phrase("CancelBtn") ?></button>
</div>
</form>
<?php
$excrate_delete->showPageFooter();
if (Config("DEBUG"))
	echo GetDebugMessage();
?>
<script>
loadjs.ready("load", function() {

	// Startup script
	// Write your table-specific startup script here
	// console.log("page loaded");

});
</script>
<?php include_once "footer.php"; ?>
<?php
$excrate_delete->terminate();
?>