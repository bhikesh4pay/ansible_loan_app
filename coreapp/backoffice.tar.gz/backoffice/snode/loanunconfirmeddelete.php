<?php
namespace PHPMaker2020\_4payadmin;

// Autoload
include_once "autoload.php";

// Session
if (session_status() !== PHP_SESSION_ACTIVE)
	\Delight\Cookie\Session::start(Config("COOKIE_SAMESITE")); // Init session data

// Output buffering
ob_start();
?>
<?php

// Write header
WriteHeader(FALSE);

// Create page object
$loanunconfirmed_delete = new loanunconfirmed_delete();

// Run the page
$loanunconfirmed_delete->run();

// Setup login status
SetupLoginStatus();
SetClientVar("login", LoginStatus());

// Global Page Rendering event (in userfn*.php)
Page_Rendering();

// Page Rendering event
$loanunconfirmed_delete->Page_Render();
?>
<?php include_once "header.php"; ?>
<script>
var floanunconfirmeddelete, currentPageID;
loadjs.ready("head", function() {

	// Form object
	currentPageID = ew.PAGE_ID = "delete";
	floanunconfirmeddelete = currentForm = new ew.Form("floanunconfirmeddelete", "delete");
	loadjs.done("floanunconfirmeddelete");
});
</script>
<script>
loadjs.ready("head", function() {

	// Client script
	// Write your client script here, no need to add script tags.

});
</script>
<?php $loanunconfirmed_delete->showPageHeader(); ?>
<?php
$loanunconfirmed_delete->showMessage();
?>
<form name="floanunconfirmeddelete" id="floanunconfirmeddelete" class="form-inline ew-form ew-delete-form" action="<?php echo CurrentPageName() ?>" method="post">
<?php if ($Page->CheckToken) { ?>
<input type="hidden" name="<?php echo Config("TOKEN_NAME") ?>" value="<?php echo $Page->Token ?>">
<?php } ?>
<input type="hidden" name="t" value="loanunconfirmed">
<input type="hidden" name="action" id="action" value="delete">
<?php foreach ($loanunconfirmed_delete->RecKeys as $key) { ?>
<?php $keyvalue = is_array($key) ? implode(Config("COMPOSITE_KEY_SEPARATOR"), $key) : $key; ?>
<input type="hidden" name="key_m[]" value="<?php echo HtmlEncode($keyvalue) ?>">
<?php } ?>
<div class="card ew-card ew-grid">
<div class="<?php echo ResponsiveTableClass() ?>card-body ew-grid-middle-panel">
<table class="table ew-table">
	<thead>
	<tr class="ew-table-header">
<?php if ($loanunconfirmed_delete->loanid->Visible) { // loanid ?>
		<th class="<?php echo $loanunconfirmed_delete->loanid->headerCellClass() ?>"><span id="elh_loanunconfirmed_loanid" class="loanunconfirmed_loanid"><?php echo $loanunconfirmed_delete->loanid->caption() ?></span></th>
<?php } ?>
<?php if ($loanunconfirmed_delete->loggedtime->Visible) { // loggedtime ?>
		<th class="<?php echo $loanunconfirmed_delete->loggedtime->headerCellClass() ?>"><span id="elh_loanunconfirmed_loggedtime" class="loanunconfirmed_loggedtime"><?php echo $loanunconfirmed_delete->loggedtime->caption() ?></span></th>
<?php } ?>
<?php if ($loanunconfirmed_delete->trycount->Visible) { // trycount ?>
		<th class="<?php echo $loanunconfirmed_delete->trycount->headerCellClass() ?>"><span id="elh_loanunconfirmed_trycount" class="loanunconfirmed_trycount"><?php echo $loanunconfirmed_delete->trycount->caption() ?></span></th>
<?php } ?>
<?php if ($loanunconfirmed_delete->lasttrytime->Visible) { // lasttrytime ?>
		<th class="<?php echo $loanunconfirmed_delete->lasttrytime->headerCellClass() ?>"><span id="elh_loanunconfirmed_lasttrytime" class="loanunconfirmed_lasttrytime"><?php echo $loanunconfirmed_delete->lasttrytime->caption() ?></span></th>
<?php } ?>
	</tr>
	</thead>
	<tbody>
<?php
$loanunconfirmed_delete->RecordCount = 0;
$i = 0;
while (!$loanunconfirmed_delete->Recordset->EOF) {
	$loanunconfirmed_delete->RecordCount++;
	$loanunconfirmed_delete->RowCount++;

	// Set row properties
	$loanunconfirmed->resetAttributes();
	$loanunconfirmed->RowType = ROWTYPE_VIEW; // View

	// Get the field contents
	$loanunconfirmed_delete->loadRowValues($loanunconfirmed_delete->Recordset);

	// Render row
	$loanunconfirmed_delete->renderRow();
?>
	<tr <?php echo $loanunconfirmed->rowAttributes() ?>>
<?php if ($loanunconfirmed_delete->loanid->Visible) { // loanid ?>
		<td <?php echo $loanunconfirmed_delete->loanid->cellAttributes() ?>>
<span id="el<?php echo $loanunconfirmed_delete->RowCount ?>_loanunconfirmed_loanid" class="loanunconfirmed_loanid">
<span<?php echo $loanunconfirmed_delete->loanid->viewAttributes() ?>><?php if (!EmptyString($loanunconfirmed_delete->loanid->getViewValue()) && $loanunconfirmed_delete->loanid->linkAttributes() != "") { ?>
<a<?php echo $loanunconfirmed_delete->loanid->linkAttributes() ?>><?php echo $loanunconfirmed_delete->loanid->getViewValue() ?></a>
<?php } else { ?>
<?php echo $loanunconfirmed_delete->loanid->getViewValue() ?>
<?php } ?></span>
</span>
</td>
<?php } ?>
<?php if ($loanunconfirmed_delete->loggedtime->Visible) { // loggedtime ?>
		<td <?php echo $loanunconfirmed_delete->loggedtime->cellAttributes() ?>>
<span id="el<?php echo $loanunconfirmed_delete->RowCount ?>_loanunconfirmed_loggedtime" class="loanunconfirmed_loggedtime">
<span<?php echo $loanunconfirmed_delete->loggedtime->viewAttributes() ?>><?php echo $loanunconfirmed_delete->loggedtime->getViewValue() ?></span>
</span>
</td>
<?php } ?>
<?php if ($loanunconfirmed_delete->trycount->Visible) { // trycount ?>
		<td <?php echo $loanunconfirmed_delete->trycount->cellAttributes() ?>>
<span id="el<?php echo $loanunconfirmed_delete->RowCount ?>_loanunconfirmed_trycount" class="loanunconfirmed_trycount">
<span<?php echo $loanunconfirmed_delete->trycount->viewAttributes() ?>><?php echo $loanunconfirmed_delete->trycount->getViewValue() ?></span>
</span>
</td>
<?php } ?>
<?php if ($loanunconfirmed_delete->lasttrytime->Visible) { // lasttrytime ?>
		<td <?php echo $loanunconfirmed_delete->lasttrytime->cellAttributes() ?>>
<span id="el<?php echo $loanunconfirmed_delete->RowCount ?>_loanunconfirmed_lasttrytime" class="loanunconfirmed_lasttrytime">
<span<?php echo $loanunconfirmed_delete->lasttrytime->viewAttributes() ?>><?php echo $loanunconfirmed_delete->lasttrytime->getViewValue() ?></span>
</span>
</td>
<?php } ?>
	</tr>
<?php
	$loanunconfirmed_delete->Recordset->moveNext();
}
$loanunconfirmed_delete->Recordset->close();
?>
</tbody>
</table>
</div>
</div>
<div>
<button class="btn btn-primary ew-btn" name="btn-action" id="btn-action" type="submit"><?php echo $Language->phrase("DeleteBtn") ?></button>
<button class="btn btn-default ew-btn" name="btn-cancel" id="btn-cancel" type="button" data-href="<?php echo $loanunconfirmed_delete->getReturnUrl() ?>"><?php echo $Language->phrase("CancelBtn") ?></button>
</div>
</form>
<?php
$loanunconfirmed_delete->showPageFooter();
if (Config("DEBUG"))
	echo GetDebugMessage();
?>
<script>
loadjs.ready("load", function() {

	// Startup script
	// Write your table-specific startup script here
	// console.log("page loaded");

});
</script>
<?php include_once "footer.php"; ?>
<?php
$loanunconfirmed_delete->terminate();
?>