<?php
namespace PHPMaker2020\_4payadmin;

// Autoload
include_once "autoload.php";

// Session
if (session_status() !== PHP_SESSION_ACTIVE)
	\Delight\Cookie\Session::start(Config("COOKIE_SAMESITE")); // Init session data

// Output buffering
ob_start();
?>
<?php

// Write header
WriteHeader(FALSE);

// Create page object
$nodepipool_search = new nodepipool_search();

// Run the page
$nodepipool_search->run();

// Setup login status
SetupLoginStatus();
SetClientVar("login", LoginStatus());

// Global Page Rendering event (in userfn*.php)
Page_Rendering();

// Page Rendering event
$nodepipool_search->Page_Render();
?>
<?php include_once "header.php"; ?>
<script>
var fnodepipoolsearch, currentPageID;
loadjs.ready("head", function() {

	// Form object for search
	<?php if ($nodepipool_search->IsModal) { ?>
	fnodepipoolsearch = currentAdvancedSearchForm = new ew.Form("fnodepipoolsearch", "search");
	<?php } else { ?>
	fnodepipoolsearch = currentForm = new ew.Form("fnodepipoolsearch", "search");
	<?php } ?>
	currentPageID = ew.PAGE_ID = "search";

	// Validate function for search
	fnodepipoolsearch.validate = function(fobj) {
		if (!this.validateRequired)
			return true; // Ignore validation
		fobj = fobj || this._form;
		var infix = "";
		elm = this.getElements("x" + infix + "_transferID");
		if (elm && !ew.checkInteger(elm.value))
			return this.onError(elm, "<?php echo JsEncode($nodepipool_search->transferID->errorMessage()) ?>");
		elm = this.getElements("x" + infix + "_sourceUserID");
		if (elm && !ew.checkInteger(elm.value))
			return this.onError(elm, "<?php echo JsEncode($nodepipool_search->sourceUserID->errorMessage()) ?>");
		elm = this.getElements("x" + infix + "_transferTime");
		if (elm && !ew.checkDateDef(elm.value))
			return this.onError(elm, "<?php echo JsEncode($nodepipool_search->transferTime->errorMessage()) ?>");
		elm = this.getElements("x" + infix + "_type");
		if (elm && !ew.checkInteger(elm.value))
			return this.onError(elm, "<?php echo JsEncode($nodepipool_search->type->errorMessage()) ?>");
		elm = this.getElements("x" + infix + "_lastUpdateDateTime");
		if (elm && !ew.checkDateDef(elm.value))
			return this.onError(elm, "<?php echo JsEncode($nodepipool_search->lastUpdateDateTime->errorMessage()) ?>");
		elm = this.getElements("x" + infix + "_status");
		if (elm && !ew.checkInteger(elm.value))
			return this.onError(elm, "<?php echo JsEncode($nodepipool_search->status->errorMessage()) ?>");
		elm = this.getElements("x" + infix + "_tries");
		if (elm && !ew.checkInteger(elm.value))
			return this.onError(elm, "<?php echo JsEncode($nodepipool_search->tries->errorMessage()) ?>");
		elm = this.getElements("x" + infix + "_locked");
		if (elm && !ew.checkInteger(elm.value))
			return this.onError(elm, "<?php echo JsEncode($nodepipool_search->locked->errorMessage()) ?>");
		elm = this.getElements("x" + infix + "_internal");
		if (elm && !ew.checkInteger(elm.value))
			return this.onError(elm, "<?php echo JsEncode($nodepipool_search->internal->errorMessage()) ?>");
		elm = this.getElements("x" + infix + "_senderpi");
		if (elm && !ew.checkInteger(elm.value))
			return this.onError(elm, "<?php echo JsEncode($nodepipool_search->senderpi->errorMessage()) ?>");
		elm = this.getElements("x" + infix + "_senderpiid");
		if (elm && !ew.checkInteger(elm.value))
			return this.onError(elm, "<?php echo JsEncode($nodepipool_search->senderpiid->errorMessage()) ?>");
		elm = this.getElements("x" + infix + "_presentationcode");
		if (elm && !ew.checkInteger(elm.value))
			return this.onError(elm, "<?php echo JsEncode($nodepipool_search->presentationcode->errorMessage()) ?>");

		// Call Form_CustomValidate event
		if (!this.Form_CustomValidate(fobj))
			return false;
		return true;
	}

	// Form_CustomValidate
	fnodepipoolsearch.Form_CustomValidate = function(fobj) { // DO NOT CHANGE THIS LINE!

		// Your custom validation code here, return false if invalid.
		return true;
	}

	// Use JavaScript validation or not
	fnodepipoolsearch.validateRequired = <?php echo Config("CLIENT_VALIDATE") ? "true" : "false" ?>;

	// Dynamic selection lists
	loadjs.done("fnodepipoolsearch");
});
</script>
<script>
loadjs.ready("head", function() {

	// Client script
	// Write your client script here, no need to add script tags.

});
</script>
<?php $nodepipool_search->showPageHeader(); ?>
<?php
$nodepipool_search->showMessage();
?>
<form name="fnodepipoolsearch" id="fnodepipoolsearch" class="<?php echo $nodepipool_search->FormClassName ?>" action="<?php echo CurrentPageName() ?>" method="post">
<?php if ($Page->CheckToken) { ?>
<input type="hidden" name="<?php echo Config("TOKEN_NAME") ?>" value="<?php echo $Page->Token ?>">
<?php } ?>
<input type="hidden" name="t" value="nodepipool">
<input type="hidden" name="action" id="action" value="search">
<input type="hidden" name="modal" value="<?php echo (int)$nodepipool_search->IsModal ?>">
<div class="ew-search-div"><!-- page* -->
<?php if ($nodepipool_search->transferID->Visible) { // transferID ?>
	<div id="r_transferID" class="form-group row">
		<label for="x_transferID" class="<?php echo $nodepipool_search->LeftColumnClass ?>"><span id="elh_nodepipool_transferID"><?php echo $nodepipool_search->transferID->caption() ?></span>
		<span class="ew-search-operator">
<?php echo $Language->phrase("=") ?>
<input type="hidden" name="z_transferID" id="z_transferID" value="=">
</span>
		</label>
		<div class="<?php echo $nodepipool_search->RightColumnClass ?>"><div <?php echo $nodepipool_search->transferID->cellAttributes() ?>>
			<span id="el_nodepipool_transferID" class="ew-search-field">
<input type="text" data-table="nodepipool" data-field="x_transferID" name="x_transferID" id="x_transferID" maxlength="12" placeholder="<?php echo HtmlEncode($nodepipool_search->transferID->getPlaceHolder()) ?>" value="<?php echo $nodepipool_search->transferID->EditValue ?>"<?php echo $nodepipool_search->transferID->editAttributes() ?>>
</span>
		</div></div>
	</div>
<?php } ?>
<?php if ($nodepipool_search->txid->Visible) { // txid ?>
	<div id="r_txid" class="form-group row">
		<label for="x_txid" class="<?php echo $nodepipool_search->LeftColumnClass ?>"><span id="elh_nodepipool_txid"><?php echo $nodepipool_search->txid->caption() ?></span>
		<span class="ew-search-operator">
<?php echo $Language->phrase("LIKE") ?>
<input type="hidden" name="z_txid" id="z_txid" value="LIKE">
</span>
		</label>
		<div class="<?php echo $nodepipool_search->RightColumnClass ?>"><div <?php echo $nodepipool_search->txid->cellAttributes() ?>>
			<span id="el_nodepipool_txid" class="ew-search-field">
<input type="text" data-table="nodepipool" data-field="x_txid" name="x_txid" id="x_txid" size="30" maxlength="10" placeholder="<?php echo HtmlEncode($nodepipool_search->txid->getPlaceHolder()) ?>" value="<?php echo $nodepipool_search->txid->EditValue ?>"<?php echo $nodepipool_search->txid->editAttributes() ?>>
</span>
		</div></div>
	</div>
<?php } ?>
<?php if ($nodepipool_search->sourceUserID->Visible) { // sourceUserID ?>
	<div id="r_sourceUserID" class="form-group row">
		<label for="x_sourceUserID" class="<?php echo $nodepipool_search->LeftColumnClass ?>"><span id="elh_nodepipool_sourceUserID"><?php echo $nodepipool_search->sourceUserID->caption() ?></span>
		<span class="ew-search-operator">
<?php echo $Language->phrase("=") ?>
<input type="hidden" name="z_sourceUserID" id="z_sourceUserID" value="=">
</span>
		</label>
		<div class="<?php echo $nodepipool_search->RightColumnClass ?>"><div <?php echo $nodepipool_search->sourceUserID->cellAttributes() ?>>
			<span id="el_nodepipool_sourceUserID" class="ew-search-field">
<input type="text" data-table="nodepipool" data-field="x_sourceUserID" name="x_sourceUserID" id="x_sourceUserID" size="30" maxlength="12" placeholder="<?php echo HtmlEncode($nodepipool_search->sourceUserID->getPlaceHolder()) ?>" value="<?php echo $nodepipool_search->sourceUserID->EditValue ?>"<?php echo $nodepipool_search->sourceUserID->editAttributes() ?>>
</span>
		</div></div>
	</div>
<?php } ?>
<?php if ($nodepipool_search->transferTime->Visible) { // transferTime ?>
	<div id="r_transferTime" class="form-group row">
		<label for="x_transferTime" class="<?php echo $nodepipool_search->LeftColumnClass ?>"><span id="elh_nodepipool_transferTime"><?php echo $nodepipool_search->transferTime->caption() ?></span>
		<span class="ew-search-operator">
<?php echo $Language->phrase("=") ?>
<input type="hidden" name="z_transferTime" id="z_transferTime" value="=">
</span>
		</label>
		<div class="<?php echo $nodepipool_search->RightColumnClass ?>"><div <?php echo $nodepipool_search->transferTime->cellAttributes() ?>>
			<span id="el_nodepipool_transferTime" class="ew-search-field">
<input type="text" data-table="nodepipool" data-field="x_transferTime" name="x_transferTime" id="x_transferTime" maxlength="19" placeholder="<?php echo HtmlEncode($nodepipool_search->transferTime->getPlaceHolder()) ?>" value="<?php echo $nodepipool_search->transferTime->EditValue ?>"<?php echo $nodepipool_search->transferTime->editAttributes() ?>>
<?php if (!$nodepipool_search->transferTime->ReadOnly && !$nodepipool_search->transferTime->Disabled && !isset($nodepipool_search->transferTime->EditAttrs["readonly"]) && !isset($nodepipool_search->transferTime->EditAttrs["disabled"])) { ?>
<script>
loadjs.ready(["fnodepipoolsearch", "datetimepicker"], function() {
	ew.createDateTimePicker("fnodepipoolsearch", "x_transferTime", {"ignoreReadonly":true,"useCurrent":false,"format":0});
});
</script>
<?php } ?>
</span>
		</div></div>
	</div>
<?php } ?>
<?php if ($nodepipool_search->comments->Visible) { // comments ?>
	<div id="r_comments" class="form-group row">
		<label for="x_comments" class="<?php echo $nodepipool_search->LeftColumnClass ?>"><span id="elh_nodepipool_comments"><?php echo $nodepipool_search->comments->caption() ?></span>
		<span class="ew-search-operator">
<?php echo $Language->phrase("LIKE") ?>
<input type="hidden" name="z_comments" id="z_comments" value="LIKE">
</span>
		</label>
		<div class="<?php echo $nodepipool_search->RightColumnClass ?>"><div <?php echo $nodepipool_search->comments->cellAttributes() ?>>
			<span id="el_nodepipool_comments" class="ew-search-field">
<input type="text" data-table="nodepipool" data-field="x_comments" name="x_comments" id="x_comments" size="30" maxlength="150" placeholder="<?php echo HtmlEncode($nodepipool_search->comments->getPlaceHolder()) ?>" value="<?php echo $nodepipool_search->comments->EditValue ?>"<?php echo $nodepipool_search->comments->editAttributes() ?>>
</span>
		</div></div>
	</div>
<?php } ?>
<?php if ($nodepipool_search->type->Visible) { // type ?>
	<div id="r_type" class="form-group row">
		<label for="x_type" class="<?php echo $nodepipool_search->LeftColumnClass ?>"><span id="elh_nodepipool_type"><?php echo $nodepipool_search->type->caption() ?></span>
		<span class="ew-search-operator">
<?php echo $Language->phrase("=") ?>
<input type="hidden" name="z_type" id="z_type" value="=">
</span>
		</label>
		<div class="<?php echo $nodepipool_search->RightColumnClass ?>"><div <?php echo $nodepipool_search->type->cellAttributes() ?>>
			<span id="el_nodepipool_type" class="ew-search-field">
<input type="text" data-table="nodepipool" data-field="x_type" name="x_type" id="x_type" size="30" maxlength="1" placeholder="<?php echo HtmlEncode($nodepipool_search->type->getPlaceHolder()) ?>" value="<?php echo $nodepipool_search->type->EditValue ?>"<?php echo $nodepipool_search->type->editAttributes() ?>>
</span>
		</div></div>
	</div>
<?php } ?>
<?php if ($nodepipool_search->lastUpdateDateTime->Visible) { // lastUpdateDateTime ?>
	<div id="r_lastUpdateDateTime" class="form-group row">
		<label for="x_lastUpdateDateTime" class="<?php echo $nodepipool_search->LeftColumnClass ?>"><span id="elh_nodepipool_lastUpdateDateTime"><?php echo $nodepipool_search->lastUpdateDateTime->caption() ?></span>
		<span class="ew-search-operator">
<?php echo $Language->phrase("=") ?>
<input type="hidden" name="z_lastUpdateDateTime" id="z_lastUpdateDateTime" value="=">
</span>
		</label>
		<div class="<?php echo $nodepipool_search->RightColumnClass ?>"><div <?php echo $nodepipool_search->lastUpdateDateTime->cellAttributes() ?>>
			<span id="el_nodepipool_lastUpdateDateTime" class="ew-search-field">
<input type="text" data-table="nodepipool" data-field="x_lastUpdateDateTime" name="x_lastUpdateDateTime" id="x_lastUpdateDateTime" maxlength="19" placeholder="<?php echo HtmlEncode($nodepipool_search->lastUpdateDateTime->getPlaceHolder()) ?>" value="<?php echo $nodepipool_search->lastUpdateDateTime->EditValue ?>"<?php echo $nodepipool_search->lastUpdateDateTime->editAttributes() ?>>
<?php if (!$nodepipool_search->lastUpdateDateTime->ReadOnly && !$nodepipool_search->lastUpdateDateTime->Disabled && !isset($nodepipool_search->lastUpdateDateTime->EditAttrs["readonly"]) && !isset($nodepipool_search->lastUpdateDateTime->EditAttrs["disabled"])) { ?>
<script>
loadjs.ready(["fnodepipoolsearch", "datetimepicker"], function() {
	ew.createDateTimePicker("fnodepipoolsearch", "x_lastUpdateDateTime", {"ignoreReadonly":true,"useCurrent":false,"format":0});
});
</script>
<?php } ?>
</span>
		</div></div>
	</div>
<?php } ?>
<?php if ($nodepipool_search->confirmCode->Visible) { // confirmCode ?>
	<div id="r_confirmCode" class="form-group row">
		<label for="x_confirmCode" class="<?php echo $nodepipool_search->LeftColumnClass ?>"><span id="elh_nodepipool_confirmCode"><?php echo $nodepipool_search->confirmCode->caption() ?></span>
		<span class="ew-search-operator">
<?php echo $Language->phrase("LIKE") ?>
<input type="hidden" name="z_confirmCode" id="z_confirmCode" value="LIKE">
</span>
		</label>
		<div class="<?php echo $nodepipool_search->RightColumnClass ?>"><div <?php echo $nodepipool_search->confirmCode->cellAttributes() ?>>
			<span id="el_nodepipool_confirmCode" class="ew-search-field">
<input type="text" data-table="nodepipool" data-field="x_confirmCode" name="x_confirmCode" id="x_confirmCode" size="30" maxlength="100" placeholder="<?php echo HtmlEncode($nodepipool_search->confirmCode->getPlaceHolder()) ?>" value="<?php echo $nodepipool_search->confirmCode->EditValue ?>"<?php echo $nodepipool_search->confirmCode->editAttributes() ?>>
</span>
		</div></div>
	</div>
<?php } ?>
<?php if ($nodepipool_search->status->Visible) { // status ?>
	<div id="r_status" class="form-group row">
		<label for="x_status" class="<?php echo $nodepipool_search->LeftColumnClass ?>"><span id="elh_nodepipool_status"><?php echo $nodepipool_search->status->caption() ?></span>
		<span class="ew-search-operator">
<?php echo $Language->phrase("=") ?>
<input type="hidden" name="z_status" id="z_status" value="=">
</span>
		</label>
		<div class="<?php echo $nodepipool_search->RightColumnClass ?>"><div <?php echo $nodepipool_search->status->cellAttributes() ?>>
			<span id="el_nodepipool_status" class="ew-search-field">
<input type="text" data-table="nodepipool" data-field="x_status" name="x_status" id="x_status" size="30" maxlength="2" placeholder="<?php echo HtmlEncode($nodepipool_search->status->getPlaceHolder()) ?>" value="<?php echo $nodepipool_search->status->EditValue ?>"<?php echo $nodepipool_search->status->editAttributes() ?>>
</span>
		</div></div>
	</div>
<?php } ?>
<?php if ($nodepipool_search->tries->Visible) { // tries ?>
	<div id="r_tries" class="form-group row">
		<label for="x_tries" class="<?php echo $nodepipool_search->LeftColumnClass ?>"><span id="elh_nodepipool_tries"><?php echo $nodepipool_search->tries->caption() ?></span>
		<span class="ew-search-operator">
<?php echo $Language->phrase("=") ?>
<input type="hidden" name="z_tries" id="z_tries" value="=">
</span>
		</label>
		<div class="<?php echo $nodepipool_search->RightColumnClass ?>"><div <?php echo $nodepipool_search->tries->cellAttributes() ?>>
			<span id="el_nodepipool_tries" class="ew-search-field">
<input type="text" data-table="nodepipool" data-field="x_tries" name="x_tries" id="x_tries" size="30" maxlength="2" placeholder="<?php echo HtmlEncode($nodepipool_search->tries->getPlaceHolder()) ?>" value="<?php echo $nodepipool_search->tries->EditValue ?>"<?php echo $nodepipool_search->tries->editAttributes() ?>>
</span>
		</div></div>
	</div>
<?php } ?>
<?php if ($nodepipool_search->locked->Visible) { // locked ?>
	<div id="r_locked" class="form-group row">
		<label for="x_locked" class="<?php echo $nodepipool_search->LeftColumnClass ?>"><span id="elh_nodepipool_locked"><?php echo $nodepipool_search->locked->caption() ?></span>
		<span class="ew-search-operator">
<?php echo $Language->phrase("=") ?>
<input type="hidden" name="z_locked" id="z_locked" value="=">
</span>
		</label>
		<div class="<?php echo $nodepipool_search->RightColumnClass ?>"><div <?php echo $nodepipool_search->locked->cellAttributes() ?>>
			<span id="el_nodepipool_locked" class="ew-search-field">
<input type="text" data-table="nodepipool" data-field="x_locked" name="x_locked" id="x_locked" size="30" maxlength="1" placeholder="<?php echo HtmlEncode($nodepipool_search->locked->getPlaceHolder()) ?>" value="<?php echo $nodepipool_search->locked->EditValue ?>"<?php echo $nodepipool_search->locked->editAttributes() ?>>
</span>
		</div></div>
	</div>
<?php } ?>
<?php if ($nodepipool_search->internal->Visible) { // internal ?>
	<div id="r_internal" class="form-group row">
		<label for="x_internal" class="<?php echo $nodepipool_search->LeftColumnClass ?>"><span id="elh_nodepipool_internal"><?php echo $nodepipool_search->internal->caption() ?></span>
		<span class="ew-search-operator">
<?php echo $Language->phrase("=") ?>
<input type="hidden" name="z_internal" id="z_internal" value="=">
</span>
		</label>
		<div class="<?php echo $nodepipool_search->RightColumnClass ?>"><div <?php echo $nodepipool_search->internal->cellAttributes() ?>>
			<span id="el_nodepipool_internal" class="ew-search-field">
<input type="text" data-table="nodepipool" data-field="x_internal" name="x_internal" id="x_internal" size="30" maxlength="1" placeholder="<?php echo HtmlEncode($nodepipool_search->internal->getPlaceHolder()) ?>" value="<?php echo $nodepipool_search->internal->EditValue ?>"<?php echo $nodepipool_search->internal->editAttributes() ?>>
</span>
		</div></div>
	</div>
<?php } ?>
<?php if ($nodepipool_search->senderpi->Visible) { // senderpi ?>
	<div id="r_senderpi" class="form-group row">
		<label for="x_senderpi" class="<?php echo $nodepipool_search->LeftColumnClass ?>"><span id="elh_nodepipool_senderpi"><?php echo $nodepipool_search->senderpi->caption() ?></span>
		<span class="ew-search-operator">
<?php echo $Language->phrase("=") ?>
<input type="hidden" name="z_senderpi" id="z_senderpi" value="=">
</span>
		</label>
		<div class="<?php echo $nodepipool_search->RightColumnClass ?>"><div <?php echo $nodepipool_search->senderpi->cellAttributes() ?>>
			<span id="el_nodepipool_senderpi" class="ew-search-field">
<input type="text" data-table="nodepipool" data-field="x_senderpi" name="x_senderpi" id="x_senderpi" size="30" maxlength="12" placeholder="<?php echo HtmlEncode($nodepipool_search->senderpi->getPlaceHolder()) ?>" value="<?php echo $nodepipool_search->senderpi->EditValue ?>"<?php echo $nodepipool_search->senderpi->editAttributes() ?>>
</span>
		</div></div>
	</div>
<?php } ?>
<?php if ($nodepipool_search->senderpiid->Visible) { // senderpiid ?>
	<div id="r_senderpiid" class="form-group row">
		<label for="x_senderpiid" class="<?php echo $nodepipool_search->LeftColumnClass ?>"><span id="elh_nodepipool_senderpiid"><?php echo $nodepipool_search->senderpiid->caption() ?></span>
		<span class="ew-search-operator">
<?php echo $Language->phrase("=") ?>
<input type="hidden" name="z_senderpiid" id="z_senderpiid" value="=">
</span>
		</label>
		<div class="<?php echo $nodepipool_search->RightColumnClass ?>"><div <?php echo $nodepipool_search->senderpiid->cellAttributes() ?>>
			<span id="el_nodepipool_senderpiid" class="ew-search-field">
<input type="text" data-table="nodepipool" data-field="x_senderpiid" name="x_senderpiid" id="x_senderpiid" size="30" maxlength="5" placeholder="<?php echo HtmlEncode($nodepipool_search->senderpiid->getPlaceHolder()) ?>" value="<?php echo $nodepipool_search->senderpiid->EditValue ?>"<?php echo $nodepipool_search->senderpiid->editAttributes() ?>>
</span>
		</div></div>
	</div>
<?php } ?>
<?php if ($nodepipool_search->recipientid->Visible) { // recipientid ?>
	<div id="r_recipientid" class="form-group row">
		<label for="x_recipientid" class="<?php echo $nodepipool_search->LeftColumnClass ?>"><span id="elh_nodepipool_recipientid"><?php echo $nodepipool_search->recipientid->caption() ?></span>
		<span class="ew-search-operator">
<?php echo $Language->phrase("LIKE") ?>
<input type="hidden" name="z_recipientid" id="z_recipientid" value="LIKE">
</span>
		</label>
		<div class="<?php echo $nodepipool_search->RightColumnClass ?>"><div <?php echo $nodepipool_search->recipientid->cellAttributes() ?>>
			<span id="el_nodepipool_recipientid" class="ew-search-field">
<input type="text" data-table="nodepipool" data-field="x_recipientid" name="x_recipientid" id="x_recipientid" size="30" maxlength="60" placeholder="<?php echo HtmlEncode($nodepipool_search->recipientid->getPlaceHolder()) ?>" value="<?php echo $nodepipool_search->recipientid->EditValue ?>"<?php echo $nodepipool_search->recipientid->editAttributes() ?>>
</span>
		</div></div>
	</div>
<?php } ?>
<?php if ($nodepipool_search->presentationcode->Visible) { // presentationcode ?>
	<div id="r_presentationcode" class="form-group row">
		<label for="x_presentationcode" class="<?php echo $nodepipool_search->LeftColumnClass ?>"><span id="elh_nodepipool_presentationcode"><?php echo $nodepipool_search->presentationcode->caption() ?></span>
		<span class="ew-search-operator">
<?php echo $Language->phrase("=") ?>
<input type="hidden" name="z_presentationcode" id="z_presentationcode" value="=">
</span>
		</label>
		<div class="<?php echo $nodepipool_search->RightColumnClass ?>"><div <?php echo $nodepipool_search->presentationcode->cellAttributes() ?>>
			<span id="el_nodepipool_presentationcode" class="ew-search-field">
<input type="text" data-table="nodepipool" data-field="x_presentationcode" name="x_presentationcode" id="x_presentationcode" size="30" maxlength="5" placeholder="<?php echo HtmlEncode($nodepipool_search->presentationcode->getPlaceHolder()) ?>" value="<?php echo $nodepipool_search->presentationcode->EditValue ?>"<?php echo $nodepipool_search->presentationcode->editAttributes() ?>>
</span>
		</div></div>
	</div>
<?php } ?>
<?php if ($nodepipool_search->recipientname->Visible) { // recipientname ?>
	<div id="r_recipientname" class="form-group row">
		<label for="x_recipientname" class="<?php echo $nodepipool_search->LeftColumnClass ?>"><span id="elh_nodepipool_recipientname"><?php echo $nodepipool_search->recipientname->caption() ?></span>
		<span class="ew-search-operator">
<?php echo $Language->phrase("LIKE") ?>
<input type="hidden" name="z_recipientname" id="z_recipientname" value="LIKE">
</span>
		</label>
		<div class="<?php echo $nodepipool_search->RightColumnClass ?>"><div <?php echo $nodepipool_search->recipientname->cellAttributes() ?>>
			<span id="el_nodepipool_recipientname" class="ew-search-field">
<input type="text" data-table="nodepipool" data-field="x_recipientname" name="x_recipientname" id="x_recipientname" size="30" maxlength="100" placeholder="<?php echo HtmlEncode($nodepipool_search->recipientname->getPlaceHolder()) ?>" value="<?php echo $nodepipool_search->recipientname->EditValue ?>"<?php echo $nodepipool_search->recipientname->editAttributes() ?>>
</span>
		</div></div>
	</div>
<?php } ?>
<?php if ($nodepipool_search->sendername->Visible) { // sendername ?>
	<div id="r_sendername" class="form-group row">
		<label for="x_sendername" class="<?php echo $nodepipool_search->LeftColumnClass ?>"><span id="elh_nodepipool_sendername"><?php echo $nodepipool_search->sendername->caption() ?></span>
		<span class="ew-search-operator">
<?php echo $Language->phrase("LIKE") ?>
<input type="hidden" name="z_sendername" id="z_sendername" value="LIKE">
</span>
		</label>
		<div class="<?php echo $nodepipool_search->RightColumnClass ?>"><div <?php echo $nodepipool_search->sendername->cellAttributes() ?>>
			<span id="el_nodepipool_sendername" class="ew-search-field">
<input type="text" data-table="nodepipool" data-field="x_sendername" name="x_sendername" id="x_sendername" size="30" maxlength="100" placeholder="<?php echo HtmlEncode($nodepipool_search->sendername->getPlaceHolder()) ?>" value="<?php echo $nodepipool_search->sendername->EditValue ?>"<?php echo $nodepipool_search->sendername->editAttributes() ?>>
</span>
		</div></div>
	</div>
<?php } ?>
<?php if ($nodepipool_search->description->Visible) { // description ?>
	<div id="r_description" class="form-group row">
		<label for="x_description" class="<?php echo $nodepipool_search->LeftColumnClass ?>"><span id="elh_nodepipool_description"><?php echo $nodepipool_search->description->caption() ?></span>
		<span class="ew-search-operator">
<?php echo $Language->phrase("LIKE") ?>
<input type="hidden" name="z_description" id="z_description" value="LIKE">
</span>
		</label>
		<div class="<?php echo $nodepipool_search->RightColumnClass ?>"><div <?php echo $nodepipool_search->description->cellAttributes() ?>>
			<span id="el_nodepipool_description" class="ew-search-field">
<input type="text" data-table="nodepipool" data-field="x_description" name="x_description" id="x_description" size="30" maxlength="45" placeholder="<?php echo HtmlEncode($nodepipool_search->description->getPlaceHolder()) ?>" value="<?php echo $nodepipool_search->description->EditValue ?>"<?php echo $nodepipool_search->description->editAttributes() ?>>
</span>
		</div></div>
	</div>
<?php } ?>
</div><!-- /page* -->
<?php if (!$nodepipool_search->IsModal) { ?>
<div class="form-group row"><!-- buttons .form-group -->
	<div class="<?php echo $nodepipool_search->OffsetColumnClass ?>"><!-- buttons offset -->
<button class="btn btn-primary ew-btn" name="btn-action" id="btn-action" type="submit"><?php echo $Language->phrase("Search") ?></button>
<button class="btn btn-default ew-btn" name="btn-reset" id="btn-reset" type="button" onclick="ew.clearForm(this.form);"><?php echo $Language->phrase("Reset") ?></button>
	</div><!-- /buttons offset -->
</div><!-- /buttons .form-group -->
<?php } ?>
</form>
<?php
$nodepipool_search->showPageFooter();
if (Config("DEBUG"))
	echo GetDebugMessage();
?>
<script>
loadjs.ready("load", function() {

	// Startup script
	// Write your table-specific startup script here
	// console.log("page loaded");

});
</script>
<?php include_once "footer.php"; ?>
<?php
$nodepipool_search->terminate();
?>