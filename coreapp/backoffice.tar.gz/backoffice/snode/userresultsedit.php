<?php
namespace PHPMaker2020\_4payadmin;

// Autoload
include_once "autoload.php";

// Session
if (session_status() !== PHP_SESSION_ACTIVE)
	\Delight\Cookie\Session::start(Config("COOKIE_SAMESITE")); // Init session data

// Output buffering
ob_start();
?>
<?php

// Write header
WriteHeader(FALSE);

// Create page object
$userresults_edit = new userresults_edit();

// Run the page
$userresults_edit->run();

// Setup login status
SetupLoginStatus();
SetClientVar("login", LoginStatus());

// Global Page Rendering event (in userfn*.php)
Page_Rendering();

// Page Rendering event
$userresults_edit->Page_Render();
?>
<?php include_once "header.php"; ?>
<script>
var fuserresultsedit, currentPageID;
loadjs.ready("head", function() {

	// Form object
	currentPageID = ew.PAGE_ID = "edit";
	fuserresultsedit = currentForm = new ew.Form("fuserresultsedit", "edit");

	// Validate form
	fuserresultsedit.validate = function() {
		if (!this.validateRequired)
			return true; // Ignore validation
		var $ = jQuery, fobj = this.getForm(), $fobj = $(fobj);
		if ($fobj.find("#confirm").val() == "confirm")
			return true;
		var elm, felm, uelm, addcnt = 0;
		var $k = $fobj.find("#" + this.formKeyCountName); // Get key_count
		var rowcnt = ($k[0]) ? parseInt($k.val(), 10) : 1;
		var startcnt = (rowcnt == 0) ? 0 : 1; // Check rowcnt == 0 => Inline-Add
		var gridinsert = ["insert", "gridinsert"].includes($fobj.find("#action").val()) && $k[0];
		for (var i = startcnt; i <= rowcnt; i++) {
			var infix = ($k[0]) ? String(i) : "";
			$fobj.data("rowindex", infix);
			<?php if ($userresults_edit->recid->Required) { ?>
				elm = this.getElements("x" + infix + "_recid");
				if (elm && !ew.isHidden(elm) && !ew.hasValue(elm))
					return this.onError(elm, "<?php echo JsEncode(str_replace("%s", $userresults_edit->recid->caption(), $userresults_edit->recid->RequiredErrorMessage)) ?>");
			<?php } ?>
			<?php if ($userresults_edit->_userid->Required) { ?>
				elm = this.getElements("x" + infix + "__userid");
				if (elm && !ew.isHidden(elm) && !ew.hasValue(elm))
					return this.onError(elm, "<?php echo JsEncode(str_replace("%s", $userresults_edit->_userid->caption(), $userresults_edit->_userid->RequiredErrorMessage)) ?>");
			<?php } ?>
				elm = this.getElements("x" + infix + "__userid");
				if (elm && !ew.checkInteger(elm.value))
					return this.onError(elm, "<?php echo JsEncode($userresults_edit->_userid->errorMessage()) ?>");
			<?php if ($userresults_edit->resulttype->Required) { ?>
				elm = this.getElements("x" + infix + "_resulttype");
				if (elm && !ew.isHidden(elm) && !ew.hasValue(elm))
					return this.onError(elm, "<?php echo JsEncode(str_replace("%s", $userresults_edit->resulttype->caption(), $userresults_edit->resulttype->RequiredErrorMessage)) ?>");
			<?php } ?>
			<?php if ($userresults_edit->requesttime->Required) { ?>
				elm = this.getElements("x" + infix + "_requesttime");
				if (elm && !ew.isHidden(elm) && !ew.hasValue(elm))
					return this.onError(elm, "<?php echo JsEncode(str_replace("%s", $userresults_edit->requesttime->caption(), $userresults_edit->requesttime->RequiredErrorMessage)) ?>");
			<?php } ?>
				elm = this.getElements("x" + infix + "_requesttime");
				if (elm && !ew.checkDateDef(elm.value))
					return this.onError(elm, "<?php echo JsEncode($userresults_edit->requesttime->errorMessage()) ?>");
			<?php if ($userresults_edit->result_payload->Required) { ?>
				elm = this.getElements("x" + infix + "_result_payload");
				if (elm && !ew.isHidden(elm) && !ew.hasValue(elm))
					return this.onError(elm, "<?php echo JsEncode(str_replace("%s", $userresults_edit->result_payload->caption(), $userresults_edit->result_payload->RequiredErrorMessage)) ?>");
			<?php } ?>
			<?php if ($userresults_edit->score->Required) { ?>
				elm = this.getElements("x" + infix + "_score");
				if (elm && !ew.isHidden(elm) && !ew.hasValue(elm))
					return this.onError(elm, "<?php echo JsEncode(str_replace("%s", $userresults_edit->score->caption(), $userresults_edit->score->RequiredErrorMessage)) ?>");
			<?php } ?>
				elm = this.getElements("x" + infix + "_score");
				if (elm && !ew.checkInteger(elm.value))
					return this.onError(elm, "<?php echo JsEncode($userresults_edit->score->errorMessage()) ?>");

				// Call Form_CustomValidate event
				if (!this.Form_CustomValidate(fobj))
					return false;
		}

		// Process detail forms
		var dfs = $fobj.find("input[name='detailpage']").get();
		for (var i = 0; i < dfs.length; i++) {
			var df = dfs[i], val = df.value;
			if (val && ew.forms[val])
				if (!ew.forms[val].validate())
					return false;
		}
		return true;
	}

	// Form_CustomValidate
	fuserresultsedit.Form_CustomValidate = function(fobj) { // DO NOT CHANGE THIS LINE!

		// Your custom validation code here, return false if invalid.
		return true;
	}

	// Use JavaScript validation or not
	fuserresultsedit.validateRequired = <?php echo Config("CLIENT_VALIDATE") ? "true" : "false" ?>;

	// Dynamic selection lists
	loadjs.done("fuserresultsedit");
});
</script>
<script>
loadjs.ready("head", function() {

	// Client script
	// Write your client script here, no need to add script tags.

});
</script>
<?php $userresults_edit->showPageHeader(); ?>
<?php
$userresults_edit->showMessage();
?>
<form name="fuserresultsedit" id="fuserresultsedit" class="<?php echo $userresults_edit->FormClassName ?>" action="<?php echo CurrentPageName() ?>" method="post">
<?php if ($Page->CheckToken) { ?>
<input type="hidden" name="<?php echo Config("TOKEN_NAME") ?>" value="<?php echo $Page->Token ?>">
<?php } ?>
<input type="hidden" name="t" value="userresults">
<input type="hidden" name="action" id="action" value="update">
<input type="hidden" name="modal" value="<?php echo (int)$userresults_edit->IsModal ?>">
<div class="ew-edit-div"><!-- page* -->
<?php if ($userresults_edit->recid->Visible) { // recid ?>
	<div id="r_recid" class="form-group row">
		<label id="elh_userresults_recid" class="<?php echo $userresults_edit->LeftColumnClass ?>"><?php echo $userresults_edit->recid->caption() ?><?php echo $userresults_edit->recid->Required ? $Language->phrase("FieldRequiredIndicator") : "" ?></label>
		<div class="<?php echo $userresults_edit->RightColumnClass ?>"><div <?php echo $userresults_edit->recid->cellAttributes() ?>>
<span id="el_userresults_recid">
<span<?php echo $userresults_edit->recid->viewAttributes() ?>><input type="text" readonly class="form-control-plaintext" value="<?php echo HtmlEncode(RemoveHtml($userresults_edit->recid->EditValue)) ?>"></span>
</span>
<input type="hidden" data-table="userresults" data-field="x_recid" name="x_recid" id="x_recid" value="<?php echo HtmlEncode($userresults_edit->recid->CurrentValue) ?>">
<?php echo $userresults_edit->recid->CustomMsg ?></div></div>
	</div>
<?php } ?>
<?php if ($userresults_edit->_userid->Visible) { // userid ?>
	<div id="r__userid" class="form-group row">
		<label id="elh_userresults__userid" for="x__userid" class="<?php echo $userresults_edit->LeftColumnClass ?>"><?php echo $userresults_edit->_userid->caption() ?><?php echo $userresults_edit->_userid->Required ? $Language->phrase("FieldRequiredIndicator") : "" ?></label>
		<div class="<?php echo $userresults_edit->RightColumnClass ?>"><div <?php echo $userresults_edit->_userid->cellAttributes() ?>>
<span id="el_userresults__userid">
<input type="text" data-table="userresults" data-field="x__userid" name="x__userid" id="x__userid" size="30" maxlength="12" placeholder="<?php echo HtmlEncode($userresults_edit->_userid->getPlaceHolder()) ?>" value="<?php echo $userresults_edit->_userid->EditValue ?>"<?php echo $userresults_edit->_userid->editAttributes() ?>>
</span>
<?php echo $userresults_edit->_userid->CustomMsg ?></div></div>
	</div>
<?php } ?>
<?php if ($userresults_edit->resulttype->Visible) { // resulttype ?>
	<div id="r_resulttype" class="form-group row">
		<label id="elh_userresults_resulttype" for="x_resulttype" class="<?php echo $userresults_edit->LeftColumnClass ?>"><?php echo $userresults_edit->resulttype->caption() ?><?php echo $userresults_edit->resulttype->Required ? $Language->phrase("FieldRequiredIndicator") : "" ?></label>
		<div class="<?php echo $userresults_edit->RightColumnClass ?>"><div <?php echo $userresults_edit->resulttype->cellAttributes() ?>>
<span id="el_userresults_resulttype">
<input type="text" data-table="userresults" data-field="x_resulttype" name="x_resulttype" id="x_resulttype" size="30" maxlength="10" placeholder="<?php echo HtmlEncode($userresults_edit->resulttype->getPlaceHolder()) ?>" value="<?php echo $userresults_edit->resulttype->EditValue ?>"<?php echo $userresults_edit->resulttype->editAttributes() ?>>
</span>
<?php echo $userresults_edit->resulttype->CustomMsg ?></div></div>
	</div>
<?php } ?>
<?php if ($userresults_edit->requesttime->Visible) { // requesttime ?>
	<div id="r_requesttime" class="form-group row">
		<label id="elh_userresults_requesttime" for="x_requesttime" class="<?php echo $userresults_edit->LeftColumnClass ?>"><?php echo $userresults_edit->requesttime->caption() ?><?php echo $userresults_edit->requesttime->Required ? $Language->phrase("FieldRequiredIndicator") : "" ?></label>
		<div class="<?php echo $userresults_edit->RightColumnClass ?>"><div <?php echo $userresults_edit->requesttime->cellAttributes() ?>>
<span id="el_userresults_requesttime">
<input type="text" data-table="userresults" data-field="x_requesttime" name="x_requesttime" id="x_requesttime" maxlength="19" placeholder="<?php echo HtmlEncode($userresults_edit->requesttime->getPlaceHolder()) ?>" value="<?php echo $userresults_edit->requesttime->EditValue ?>"<?php echo $userresults_edit->requesttime->editAttributes() ?>>
<?php if (!$userresults_edit->requesttime->ReadOnly && !$userresults_edit->requesttime->Disabled && !isset($userresults_edit->requesttime->EditAttrs["readonly"]) && !isset($userresults_edit->requesttime->EditAttrs["disabled"])) { ?>
<script>
loadjs.ready(["fuserresultsedit", "datetimepicker"], function() {
	ew.createDateTimePicker("fuserresultsedit", "x_requesttime", {"ignoreReadonly":true,"useCurrent":false,"format":0});
});
</script>
<?php } ?>
</span>
<?php echo $userresults_edit->requesttime->CustomMsg ?></div></div>
	</div>
<?php } ?>
<?php if ($userresults_edit->result_payload->Visible) { // result_payload ?>
	<div id="r_result_payload" class="form-group row">
		<label id="elh_userresults_result_payload" for="x_result_payload" class="<?php echo $userresults_edit->LeftColumnClass ?>"><?php echo $userresults_edit->result_payload->caption() ?><?php echo $userresults_edit->result_payload->Required ? $Language->phrase("FieldRequiredIndicator") : "" ?></label>
		<div class="<?php echo $userresults_edit->RightColumnClass ?>"><div <?php echo $userresults_edit->result_payload->cellAttributes() ?>>
<span id="el_userresults_result_payload">
<textarea data-table="userresults" data-field="x_result_payload" name="x_result_payload" id="x_result_payload" cols="35" rows="4" placeholder="<?php echo HtmlEncode($userresults_edit->result_payload->getPlaceHolder()) ?>"<?php echo $userresults_edit->result_payload->editAttributes() ?>><?php echo $userresults_edit->result_payload->EditValue ?></textarea>
</span>
<?php echo $userresults_edit->result_payload->CustomMsg ?></div></div>
	</div>
<?php } ?>
<?php if ($userresults_edit->score->Visible) { // score ?>
	<div id="r_score" class="form-group row">
		<label id="elh_userresults_score" for="x_score" class="<?php echo $userresults_edit->LeftColumnClass ?>"><?php echo $userresults_edit->score->caption() ?><?php echo $userresults_edit->score->Required ? $Language->phrase("FieldRequiredIndicator") : "" ?></label>
		<div class="<?php echo $userresults_edit->RightColumnClass ?>"><div <?php echo $userresults_edit->score->cellAttributes() ?>>
<span id="el_userresults_score">
<input type="text" data-table="userresults" data-field="x_score" name="x_score" id="x_score" size="30" maxlength="7" placeholder="<?php echo HtmlEncode($userresults_edit->score->getPlaceHolder()) ?>" value="<?php echo $userresults_edit->score->EditValue ?>"<?php echo $userresults_edit->score->editAttributes() ?>>
</span>
<?php echo $userresults_edit->score->CustomMsg ?></div></div>
	</div>
<?php } ?>
</div><!-- /page* -->
<?php if (!$userresults_edit->IsModal) { ?>
<div class="form-group row"><!-- buttons .form-group -->
	<div class="<?php echo $userresults_edit->OffsetColumnClass ?>"><!-- buttons offset -->
<button class="btn btn-primary ew-btn" name="btn-action" id="btn-action" type="submit"><?php echo $Language->phrase("SaveBtn") ?></button>
<button class="btn btn-default ew-btn" name="btn-cancel" id="btn-cancel" type="button" data-href="<?php echo $userresults_edit->getReturnUrl() ?>"><?php echo $Language->phrase("CancelBtn") ?></button>
	</div><!-- /buttons offset -->
</div><!-- /buttons .form-group -->
<?php } ?>
</form>
<?php
$userresults_edit->showPageFooter();
if (Config("DEBUG"))
	echo GetDebugMessage();
?>
<script>
loadjs.ready("load", function() {

	// Startup script
	// Write your table-specific startup script here
	// console.log("page loaded");

});
</script>
<?php include_once "footer.php"; ?>
<?php
$userresults_edit->terminate();
?>