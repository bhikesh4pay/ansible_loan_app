<?php
namespace PHPMaker2020\_4payadmin;

// Autoload
include_once "autoload.php";

// Session
if (session_status() !== PHP_SESSION_ACTIVE)
	\Delight\Cookie\Session::start(Config("COOKIE_SAMESITE")); // Init session data

// Output buffering
ob_start();
?>
<?php

// Write header
WriteHeader(FALSE, "utf-8");

// Create page object
$userpurchasepayment_preview = new userpurchasepayment_preview();

// Run the page
$userpurchasepayment_preview->run();

// Setup login status
SetupLoginStatus();
SetClientVar("login", LoginStatus());

// Global Page Rendering event (in userfn*.php)
Page_Rendering();

// Page Rendering event
$userpurchasepayment_preview->Page_Render();
?>
<?php $userpurchasepayment_preview->showPageHeader(); ?>
<?php if ($userpurchasepayment_preview->TotalRecords > 0) { ?>
<div class="card ew-grid userpurchasepayment"><!-- .card -->
<div class="<?php echo ResponsiveTableClass() ?>card-body ew-grid-middle-panel ew-preview-middle-panel"><!-- .table-responsive -->
<table class="table ew-table ew-preview-table"><!-- .table -->
	<thead><!-- Table header -->
		<tr class="ew-table-header">
<?php

// Render list options
$userpurchasepayment_preview->renderListOptions();

// Render list options (header, left)
$userpurchasepayment_preview->ListOptions->render("header", "left");
?>
<?php if ($userpurchasepayment_preview->paymentid->Visible) { // paymentid ?>
	<?php if ($userpurchasepayment->SortUrl($userpurchasepayment_preview->paymentid) == "") { ?>
		<th class="<?php echo $userpurchasepayment_preview->paymentid->headerCellClass() ?>"><?php echo $userpurchasepayment_preview->paymentid->caption() ?></th>
	<?php } else { ?>
		<th class="<?php echo $userpurchasepayment_preview->paymentid->headerCellClass() ?>"><div class="ew-pointer" data-sort="<?php echo HtmlEncode($userpurchasepayment_preview->paymentid->Name) ?>" data-sort-order="<?php echo $userpurchasepayment_preview->SortField == $userpurchasepayment_preview->paymentid->Name && $userpurchasepayment_preview->SortOrder == "ASC" ? "DESC" : "ASC" ?>">
			<div class="ew-table-header-btn"><span class="ew-table-header-caption"><?php echo $userpurchasepayment_preview->paymentid->caption() ?></span><span class="ew-table-header-sort"><?php if ($userpurchasepayment_preview->SortField == $userpurchasepayment_preview->paymentid->Name) { ?><?php if ($userpurchasepayment_preview->SortOrder == "ASC") { ?><i class="fas fa-sort-up"></i><?php } elseif ($userpurchasepayment_preview->SortOrder == "DESC") { ?><i class="fas fa-sort-down"></i><?php } ?><?php } ?></span>
		</div></div></th>
	<?php } ?>
<?php } ?>
<?php if ($userpurchasepayment_preview->purchaseid->Visible) { // purchaseid ?>
	<?php if ($userpurchasepayment->SortUrl($userpurchasepayment_preview->purchaseid) == "") { ?>
		<th class="<?php echo $userpurchasepayment_preview->purchaseid->headerCellClass() ?>"><?php echo $userpurchasepayment_preview->purchaseid->caption() ?></th>
	<?php } else { ?>
		<th class="<?php echo $userpurchasepayment_preview->purchaseid->headerCellClass() ?>"><div class="ew-pointer" data-sort="<?php echo HtmlEncode($userpurchasepayment_preview->purchaseid->Name) ?>" data-sort-order="<?php echo $userpurchasepayment_preview->SortField == $userpurchasepayment_preview->purchaseid->Name && $userpurchasepayment_preview->SortOrder == "ASC" ? "DESC" : "ASC" ?>">
			<div class="ew-table-header-btn"><span class="ew-table-header-caption"><?php echo $userpurchasepayment_preview->purchaseid->caption() ?></span><span class="ew-table-header-sort"><?php if ($userpurchasepayment_preview->SortField == $userpurchasepayment_preview->purchaseid->Name) { ?><?php if ($userpurchasepayment_preview->SortOrder == "ASC") { ?><i class="fas fa-sort-up"></i><?php } elseif ($userpurchasepayment_preview->SortOrder == "DESC") { ?><i class="fas fa-sort-down"></i><?php } ?><?php } ?></span>
		</div></div></th>
	<?php } ?>
<?php } ?>
<?php if ($userpurchasepayment_preview->userpiid->Visible) { // userpiid ?>
	<?php if ($userpurchasepayment->SortUrl($userpurchasepayment_preview->userpiid) == "") { ?>
		<th class="<?php echo $userpurchasepayment_preview->userpiid->headerCellClass() ?>"><?php echo $userpurchasepayment_preview->userpiid->caption() ?></th>
	<?php } else { ?>
		<th class="<?php echo $userpurchasepayment_preview->userpiid->headerCellClass() ?>"><div class="ew-pointer" data-sort="<?php echo HtmlEncode($userpurchasepayment_preview->userpiid->Name) ?>" data-sort-order="<?php echo $userpurchasepayment_preview->SortField == $userpurchasepayment_preview->userpiid->Name && $userpurchasepayment_preview->SortOrder == "ASC" ? "DESC" : "ASC" ?>">
			<div class="ew-table-header-btn"><span class="ew-table-header-caption"><?php echo $userpurchasepayment_preview->userpiid->caption() ?></span><span class="ew-table-header-sort"><?php if ($userpurchasepayment_preview->SortField == $userpurchasepayment_preview->userpiid->Name) { ?><?php if ($userpurchasepayment_preview->SortOrder == "ASC") { ?><i class="fas fa-sort-up"></i><?php } elseif ($userpurchasepayment_preview->SortOrder == "DESC") { ?><i class="fas fa-sort-down"></i><?php } ?><?php } ?></span>
		</div></div></th>
	<?php } ?>
<?php } ?>
<?php if ($userpurchasepayment_preview->currencycode->Visible) { // currencycode ?>
	<?php if ($userpurchasepayment->SortUrl($userpurchasepayment_preview->currencycode) == "") { ?>
		<th class="<?php echo $userpurchasepayment_preview->currencycode->headerCellClass() ?>"><?php echo $userpurchasepayment_preview->currencycode->caption() ?></th>
	<?php } else { ?>
		<th class="<?php echo $userpurchasepayment_preview->currencycode->headerCellClass() ?>"><div class="ew-pointer" data-sort="<?php echo HtmlEncode($userpurchasepayment_preview->currencycode->Name) ?>" data-sort-order="<?php echo $userpurchasepayment_preview->SortField == $userpurchasepayment_preview->currencycode->Name && $userpurchasepayment_preview->SortOrder == "ASC" ? "DESC" : "ASC" ?>">
			<div class="ew-table-header-btn"><span class="ew-table-header-caption"><?php echo $userpurchasepayment_preview->currencycode->caption() ?></span><span class="ew-table-header-sort"><?php if ($userpurchasepayment_preview->SortField == $userpurchasepayment_preview->currencycode->Name) { ?><?php if ($userpurchasepayment_preview->SortOrder == "ASC") { ?><i class="fas fa-sort-up"></i><?php } elseif ($userpurchasepayment_preview->SortOrder == "DESC") { ?><i class="fas fa-sort-down"></i><?php } ?><?php } ?></span>
		</div></div></th>
	<?php } ?>
<?php } ?>
<?php if ($userpurchasepayment_preview->paidsuccessfully->Visible) { // paidsuccessfully ?>
	<?php if ($userpurchasepayment->SortUrl($userpurchasepayment_preview->paidsuccessfully) == "") { ?>
		<th class="<?php echo $userpurchasepayment_preview->paidsuccessfully->headerCellClass() ?>"><?php echo $userpurchasepayment_preview->paidsuccessfully->caption() ?></th>
	<?php } else { ?>
		<th class="<?php echo $userpurchasepayment_preview->paidsuccessfully->headerCellClass() ?>"><div class="ew-pointer" data-sort="<?php echo HtmlEncode($userpurchasepayment_preview->paidsuccessfully->Name) ?>" data-sort-order="<?php echo $userpurchasepayment_preview->SortField == $userpurchasepayment_preview->paidsuccessfully->Name && $userpurchasepayment_preview->SortOrder == "ASC" ? "DESC" : "ASC" ?>">
			<div class="ew-table-header-btn"><span class="ew-table-header-caption"><?php echo $userpurchasepayment_preview->paidsuccessfully->caption() ?></span><span class="ew-table-header-sort"><?php if ($userpurchasepayment_preview->SortField == $userpurchasepayment_preview->paidsuccessfully->Name) { ?><?php if ($userpurchasepayment_preview->SortOrder == "ASC") { ?><i class="fas fa-sort-up"></i><?php } elseif ($userpurchasepayment_preview->SortOrder == "DESC") { ?><i class="fas fa-sort-down"></i><?php } ?><?php } ?></span>
		</div></div></th>
	<?php } ?>
<?php } ?>
<?php if ($userpurchasepayment_preview->refunded->Visible) { // refunded ?>
	<?php if ($userpurchasepayment->SortUrl($userpurchasepayment_preview->refunded) == "") { ?>
		<th class="<?php echo $userpurchasepayment_preview->refunded->headerCellClass() ?>"><?php echo $userpurchasepayment_preview->refunded->caption() ?></th>
	<?php } else { ?>
		<th class="<?php echo $userpurchasepayment_preview->refunded->headerCellClass() ?>"><div class="ew-pointer" data-sort="<?php echo HtmlEncode($userpurchasepayment_preview->refunded->Name) ?>" data-sort-order="<?php echo $userpurchasepayment_preview->SortField == $userpurchasepayment_preview->refunded->Name && $userpurchasepayment_preview->SortOrder == "ASC" ? "DESC" : "ASC" ?>">
			<div class="ew-table-header-btn"><span class="ew-table-header-caption"><?php echo $userpurchasepayment_preview->refunded->caption() ?></span><span class="ew-table-header-sort"><?php if ($userpurchasepayment_preview->SortField == $userpurchasepayment_preview->refunded->Name) { ?><?php if ($userpurchasepayment_preview->SortOrder == "ASC") { ?><i class="fas fa-sort-up"></i><?php } elseif ($userpurchasepayment_preview->SortOrder == "DESC") { ?><i class="fas fa-sort-down"></i><?php } ?><?php } ?></span>
		</div></div></th>
	<?php } ?>
<?php } ?>
<?php if ($userpurchasepayment_preview->paymentdatetime->Visible) { // paymentdatetime ?>
	<?php if ($userpurchasepayment->SortUrl($userpurchasepayment_preview->paymentdatetime) == "") { ?>
		<th class="<?php echo $userpurchasepayment_preview->paymentdatetime->headerCellClass() ?>"><?php echo $userpurchasepayment_preview->paymentdatetime->caption() ?></th>
	<?php } else { ?>
		<th class="<?php echo $userpurchasepayment_preview->paymentdatetime->headerCellClass() ?>"><div class="ew-pointer" data-sort="<?php echo HtmlEncode($userpurchasepayment_preview->paymentdatetime->Name) ?>" data-sort-order="<?php echo $userpurchasepayment_preview->SortField == $userpurchasepayment_preview->paymentdatetime->Name && $userpurchasepayment_preview->SortOrder == "ASC" ? "DESC" : "ASC" ?>">
			<div class="ew-table-header-btn"><span class="ew-table-header-caption"><?php echo $userpurchasepayment_preview->paymentdatetime->caption() ?></span><span class="ew-table-header-sort"><?php if ($userpurchasepayment_preview->SortField == $userpurchasepayment_preview->paymentdatetime->Name) { ?><?php if ($userpurchasepayment_preview->SortOrder == "ASC") { ?><i class="fas fa-sort-up"></i><?php } elseif ($userpurchasepayment_preview->SortOrder == "DESC") { ?><i class="fas fa-sort-down"></i><?php } ?><?php } ?></span>
		</div></div></th>
	<?php } ?>
<?php } ?>
<?php

// Render list options (header, right)
$userpurchasepayment_preview->ListOptions->render("header", "right");
?>
		</tr>
	</thead>
	<tbody><!-- Table body -->
<?php
$userpurchasepayment_preview->RecCount = 0;
$userpurchasepayment_preview->RowCount = 0;
while ($userpurchasepayment_preview->Recordset && !$userpurchasepayment_preview->Recordset->EOF) {

	// Init row class and style
	$userpurchasepayment_preview->RecCount++;
	$userpurchasepayment_preview->RowCount++;
	$userpurchasepayment_preview->CssStyle = "";
	$userpurchasepayment_preview->loadListRowValues($userpurchasepayment_preview->Recordset);

	// Render row
	$userpurchasepayment->RowType = ROWTYPE_PREVIEW; // Preview record
	$userpurchasepayment_preview->resetAttributes();
	$userpurchasepayment_preview->renderListRow();

	// Render list options
	$userpurchasepayment_preview->renderListOptions();
?>
	<tr <?php echo $userpurchasepayment->rowAttributes() ?>>
<?php

// Render list options (body, left)
$userpurchasepayment_preview->ListOptions->render("body", "left", $userpurchasepayment_preview->RowCount);
?>
<?php if ($userpurchasepayment_preview->paymentid->Visible) { // paymentid ?>
		<!-- paymentid -->
		<td<?php echo $userpurchasepayment_preview->paymentid->cellAttributes() ?>>
<span<?php echo $userpurchasepayment_preview->paymentid->viewAttributes() ?>><?php echo $userpurchasepayment_preview->paymentid->getViewValue() ?></span>
</td>
<?php } ?>
<?php if ($userpurchasepayment_preview->purchaseid->Visible) { // purchaseid ?>
		<!-- purchaseid -->
		<td<?php echo $userpurchasepayment_preview->purchaseid->cellAttributes() ?>>
<span<?php echo $userpurchasepayment_preview->purchaseid->viewAttributes() ?>><?php if (!EmptyString($userpurchasepayment_preview->purchaseid->getViewValue()) && $userpurchasepayment_preview->purchaseid->linkAttributes() != "") { ?>
<a<?php echo $userpurchasepayment_preview->purchaseid->linkAttributes() ?>><?php echo $userpurchasepayment_preview->purchaseid->getViewValue() ?></a>
<?php } else { ?>
<?php echo $userpurchasepayment_preview->purchaseid->getViewValue() ?>
<?php } ?></span>
</td>
<?php } ?>
<?php if ($userpurchasepayment_preview->userpiid->Visible) { // userpiid ?>
		<!-- userpiid -->
		<td<?php echo $userpurchasepayment_preview->userpiid->cellAttributes() ?>>
<span<?php echo $userpurchasepayment_preview->userpiid->viewAttributes() ?>><?php echo $userpurchasepayment_preview->userpiid->getViewValue() ?></span>
</td>
<?php } ?>
<?php if ($userpurchasepayment_preview->currencycode->Visible) { // currencycode ?>
		<!-- currencycode -->
		<td<?php echo $userpurchasepayment_preview->currencycode->cellAttributes() ?>>
<span<?php echo $userpurchasepayment_preview->currencycode->viewAttributes() ?>><?php echo $userpurchasepayment_preview->currencycode->getViewValue() ?></span>
</td>
<?php } ?>
<?php if ($userpurchasepayment_preview->paidsuccessfully->Visible) { // paidsuccessfully ?>
		<!-- paidsuccessfully -->
		<td<?php echo $userpurchasepayment_preview->paidsuccessfully->cellAttributes() ?>>
<span<?php echo $userpurchasepayment_preview->paidsuccessfully->viewAttributes() ?>><?php echo $userpurchasepayment_preview->paidsuccessfully->getViewValue() ?></span>
</td>
<?php } ?>
<?php if ($userpurchasepayment_preview->refunded->Visible) { // refunded ?>
		<!-- refunded -->
		<td<?php echo $userpurchasepayment_preview->refunded->cellAttributes() ?>>
<span<?php echo $userpurchasepayment_preview->refunded->viewAttributes() ?>><?php echo $userpurchasepayment_preview->refunded->getViewValue() ?></span>
</td>
<?php } ?>
<?php if ($userpurchasepayment_preview->paymentdatetime->Visible) { // paymentdatetime ?>
		<!-- paymentdatetime -->
		<td<?php echo $userpurchasepayment_preview->paymentdatetime->cellAttributes() ?>>
<span<?php echo $userpurchasepayment_preview->paymentdatetime->viewAttributes() ?>><?php echo $userpurchasepayment_preview->paymentdatetime->getViewValue() ?></span>
</td>
<?php } ?>
<?php

// Render list options (body, right)
$userpurchasepayment_preview->ListOptions->render("body", "right", $userpurchasepayment_preview->RowCount);
?>
	</tr>
<?php
	$userpurchasepayment_preview->Recordset->MoveNext();
} // while
?>
	</tbody>
</table><!-- /.table -->
</div><!-- /.table-responsive -->
<div class="card-footer ew-grid-lower-panel ew-preview-lower-panel"><!-- .card-footer -->
<?php echo $userpurchasepayment_preview->Pager->render() ?>
<?php } else { // No record ?>
<div class="card no-border">
<div class="ew-detail-count"><?php echo $Language->phrase("NoRecord") ?></div>
<?php } ?>
<div class="ew-preview-other-options">
<?php
	foreach ($userpurchasepayment_preview->OtherOptions as $option)
		$option->render("body");
?>
</div>
<?php if ($userpurchasepayment_preview->TotalRecords > 0) { ?>
<div class="clearfix"></div>
</div><!-- /.card-footer -->
<?php } ?>
</div><!-- /.card -->
<?php
$userpurchasepayment_preview->showPageFooter();
if (Config("DEBUG"))
	echo GetDebugMessage();
?>
<?php
if ($userpurchasepayment_preview->Recordset)
	$userpurchasepayment_preview->Recordset->Close();

// Output
$content = ob_get_contents();
ob_end_clean();
echo ConvertToUtf8($content);
?>
<?php
$userpurchasepayment_preview->terminate();
?>