<?php
namespace PHPMaker2020\_4payadmin;

// Autoload
include_once "autoload.php";

// Session
if (session_status() !== PHP_SESSION_ACTIVE)
	\Delight\Cookie\Session::start(Config("COOKIE_SAMESITE")); // Init session data

// Output buffering
ob_start();
?>
<?php

// Write header
WriteHeader(FALSE);

// Create page object
$loan360v2_list = new loan360v2_list();

// Run the page
$loan360v2_list->run();

// Setup login status
SetupLoginStatus();
SetClientVar("login", LoginStatus());

// Global Page Rendering event (in userfn*.php)
Page_Rendering();

// Page Rendering event
$loan360v2_list->Page_Render();
?>
<?php include_once "header.php"; ?>
<?php if (!$loan360v2_list->isExport()) { ?>
<script>
var floan360v2list, currentPageID;
loadjs.ready("head", function() {

	// Form object
	currentPageID = ew.PAGE_ID = "list";
	floan360v2list = currentForm = new ew.Form("floan360v2list", "list");
	floan360v2list.formKeyCountName = '<?php echo $loan360v2_list->FormKeyCountName ?>';
	loadjs.done("floan360v2list");
});
</script>
<style type="text/css">
.ew-table-preview-row { /* main table preview row color */
	background-color: #FFFFFF; /* preview row color */
}
.ew-table-preview-row .ew-grid {
	display: table;
}
</style>
<div id="ew-preview" class="d-none"><!-- preview -->
	<div class="ew-nav-tabs"><!-- .ew-nav-tabs -->
		<ul class="nav nav-tabs"></ul>
		<div class="tab-content"><!-- .tab-content -->
			<div class="tab-pane fade active show"></div>
		</div><!-- /.tab-content -->
	</div><!-- /.ew-nav-tabs -->
</div><!-- /preview -->
<script>
loadjs.ready("head", function() {
	ew.PREVIEW_PLACEMENT = ew.CSS_FLIP ? "right" : "left";
	ew.PREVIEW_SINGLE_ROW = false;
	ew.PREVIEW_OVERLAY = false;
	loadjs("js/ewpreview.js", "preview");
});
</script>
<script>
loadjs.ready("head", function() {

	// Client script
	$("#tbl_loan360v2list").hide();
});
</script>
<?php } ?>
<?php if (!$loan360v2_list->isExport()) { ?>
<div class="btn-toolbar ew-toolbar">
<?php if ($loan360v2_list->TotalRecords > 0 && $loan360v2_list->ExportOptions->visible()) { ?>
<?php $loan360v2_list->ExportOptions->render("body") ?>
<?php } ?>
<?php if ($loan360v2_list->ImportOptions->visible()) { ?>
<?php $loan360v2_list->ImportOptions->render("body") ?>
<?php } ?>
<div class="clearfix"></div>
</div>
<?php } ?>
<?php
$loan360v2_list->renderOtherOptions();
?>
<?php $loan360v2_list->showPageHeader(); ?>
<?php
$loan360v2_list->showMessage();
?>
<?php if ($loan360v2_list->TotalRecords > 0 || $loan360v2->CurrentAction) { ?>
<div class="card ew-card ew-grid<?php if ($loan360v2_list->isAddOrEdit()) { ?> ew-grid-add-edit<?php } ?> loan360v2">
<form name="floan360v2list" id="floan360v2list" class="form-inline ew-form ew-list-form" action="<?php echo CurrentPageName() ?>" method="post">
<?php if ($Page->CheckToken) { ?>
<input type="hidden" name="<?php echo Config("TOKEN_NAME") ?>" value="<?php echo $Page->Token ?>">
<?php } ?>
<input type="hidden" name="t" value="loan360v2">
<div id="gmp_loan360v2" class="<?php echo ResponsiveTableClass() ?>card-body ew-grid-middle-panel">
<?php if ($loan360v2_list->TotalRecords > 0 || $loan360v2_list->isGridEdit()) { ?>
<table id="tbl_loan360v2list" class="table ew-table"><!-- .ew-table -->
<thead>
	<tr class="ew-table-header">
<?php

// Header row
$loan360v2->RowType = ROWTYPE_HEADER;

// Render list options
$loan360v2_list->renderListOptions();

// Render list options (header, left)
$loan360v2_list->ListOptions->render("header", "left");
?>
<?php if ($loan360v2_list->date->Visible) { // date ?>
	<?php if ($loan360v2_list->SortUrl($loan360v2_list->date) == "") { ?>
		<th data-name="date" class="<?php echo $loan360v2_list->date->headerCellClass() ?>"><div id="elh_loan360v2_date" class="loan360v2_date"><div class="ew-table-header-caption"><?php echo $loan360v2_list->date->caption() ?></div></div></th>
	<?php } else { ?>
		<th data-name="date" class="<?php echo $loan360v2_list->date->headerCellClass() ?>"><div class="ew-pointer" onclick="ew.sort(event, '<?php echo $loan360v2_list->SortUrl($loan360v2_list->date) ?>', 1);"><div id="elh_loan360v2_date" class="loan360v2_date">
			<div class="ew-table-header-btn"><span class="ew-table-header-caption"><?php echo $loan360v2_list->date->caption() ?></span><span class="ew-table-header-sort"><?php if ($loan360v2_list->date->getSort() == "ASC") { ?><i class="fas fa-sort-up"></i><?php } elseif ($loan360v2_list->date->getSort() == "DESC") { ?><i class="fas fa-sort-down"></i><?php } ?></span></div>
		</div></div></th>
	<?php } ?>
<?php } ?>
<?php

// Render list options (header, right)
$loan360v2_list->ListOptions->render("header", "right");
?>
	</tr>
</thead>
<tbody>
<?php
if ($loan360v2_list->ExportAll && $loan360v2_list->isExport()) {
	$loan360v2_list->StopRecord = $loan360v2_list->TotalRecords;
} else {

	// Set the last record to display
	if ($loan360v2_list->TotalRecords > $loan360v2_list->StartRecord + $loan360v2_list->DisplayRecords - 1)
		$loan360v2_list->StopRecord = $loan360v2_list->StartRecord + $loan360v2_list->DisplayRecords - 1;
	else
		$loan360v2_list->StopRecord = $loan360v2_list->TotalRecords;
}
$loan360v2_list->RecordCount = $loan360v2_list->StartRecord - 1;
if ($loan360v2_list->Recordset && !$loan360v2_list->Recordset->EOF) {
	$loan360v2_list->Recordset->moveFirst();
	$selectLimit = $loan360v2_list->UseSelectLimit;
	if (!$selectLimit && $loan360v2_list->StartRecord > 1)
		$loan360v2_list->Recordset->move($loan360v2_list->StartRecord - 1);
} elseif (!$loan360v2->AllowAddDeleteRow && $loan360v2_list->StopRecord == 0) {
	$loan360v2_list->StopRecord = $loan360v2->GridAddRowCount;
}

// Initialize aggregate
$loan360v2->RowType = ROWTYPE_AGGREGATEINIT;
$loan360v2->resetAttributes();
$loan360v2_list->renderRow();
while ($loan360v2_list->RecordCount < $loan360v2_list->StopRecord) {
	$loan360v2_list->RecordCount++;
	if ($loan360v2_list->RecordCount >= $loan360v2_list->StartRecord) {
		$loan360v2_list->RowCount++;

		// Set up key count
		$loan360v2_list->KeyCount = $loan360v2_list->RowIndex;

		// Init row class and style
		$loan360v2->resetAttributes();
		$loan360v2->CssClass = "";
		if ($loan360v2_list->isGridAdd()) {
		} else {
			$loan360v2_list->loadRowValues($loan360v2_list->Recordset); // Load row values
		}
		$loan360v2->RowType = ROWTYPE_VIEW; // Render view

		// Set up row id / data-rowindex
		$loan360v2->RowAttrs->merge(["data-rowindex" => $loan360v2_list->RowCount, "id" => "r" . $loan360v2_list->RowCount . "_loan360v2", "data-rowtype" => $loan360v2->RowType]);

		// Render row
		$loan360v2_list->renderRow();

		// Render list options
		$loan360v2_list->renderListOptions();
?>
	<tr <?php echo $loan360v2->rowAttributes() ?>>
<?php

// Render list options (body, left)
$loan360v2_list->ListOptions->render("body", "left", $loan360v2_list->RowCount);
?>
	<?php if ($loan360v2_list->date->Visible) { // date ?>
		<td data-name="date" <?php echo $loan360v2_list->date->cellAttributes() ?>>
<span id="el<?php echo $loan360v2_list->RowCount ?>_loan360v2_date">
<span<?php echo $loan360v2_list->date->viewAttributes() ?>><?php echo $loan360v2_list->date->getViewValue() ?></span>
</span>
</td>
	<?php } ?>
<?php

// Render list options (body, right)
$loan360v2_list->ListOptions->render("body", "right", $loan360v2_list->RowCount);
?>
	</tr>
<?php
	}
	if (!$loan360v2_list->isGridAdd())
		$loan360v2_list->Recordset->moveNext();
}
?>
</tbody>
</table><!-- /.ew-table -->
<?php } ?>
</div><!-- /.ew-grid-middle-panel -->
<?php if (!$loan360v2->CurrentAction) { ?>
<input type="hidden" name="action" id="action" value="">
<?php } ?>
</form><!-- /.ew-list-form -->
<?php

// Close recordset
if ($loan360v2_list->Recordset)
	$loan360v2_list->Recordset->Close();
?>
<?php if (!$loan360v2_list->isExport()) { ?>
<div class="card-footer ew-grid-lower-panel">
<?php if (!$loan360v2_list->isGridAdd()) { ?>
<form name="ew-pager-form" class="form-inline ew-form ew-pager-form" action="<?php echo CurrentPageName() ?>">
<?php echo $loan360v2_list->Pager->render() ?>
</form>
<?php } ?>
<div class="ew-list-other-options">
<?php $loan360v2_list->OtherOptions->render("body", "bottom") ?>
</div>
<div class="clearfix"></div>
</div>
<?php } ?>
</div><!-- /.ew-grid -->
<?php } ?>
<?php if ($loan360v2_list->TotalRecords == 0 && !$loan360v2->CurrentAction) { // Show other options ?>
<div class="ew-list-other-options">
<?php $loan360v2_list->OtherOptions->render("body") ?>
</div>
<div class="clearfix"></div>
<?php } ?>
<?php
$loan360v2_list->showPageFooter();
if (Config("DEBUG"))
	echo GetDebugMessage();
?>
<?php if (!$loan360v2_list->isExport()) { ?>
<script>
loadjs.ready("load", function() {

	// Startup script
	// Write your table-specific startup script here
	// console.log("page loaded");

});
</script>
<?php } ?>
<?php include_once "footer.php"; ?>
<?php
$loan360v2_list->terminate();
?>