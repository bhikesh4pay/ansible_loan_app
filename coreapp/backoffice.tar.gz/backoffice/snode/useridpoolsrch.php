<?php
namespace PHPMaker2020\_4payadmin;

// Autoload
include_once "autoload.php";

// Session
if (session_status() !== PHP_SESSION_ACTIVE)
	\Delight\Cookie\Session::start(Config("COOKIE_SAMESITE")); // Init session data

// Output buffering
ob_start();
?>
<?php

// Write header
WriteHeader(FALSE);

// Create page object
$useridpool_search = new useridpool_search();

// Run the page
$useridpool_search->run();

// Setup login status
SetupLoginStatus();
SetClientVar("login", LoginStatus());

// Global Page Rendering event (in userfn*.php)
Page_Rendering();

// Page Rendering event
$useridpool_search->Page_Render();
?>
<?php include_once "header.php"; ?>
<script>
var fuseridpoolsearch, currentPageID;
loadjs.ready("head", function() {

	// Form object for search
	<?php if ($useridpool_search->IsModal) { ?>
	fuseridpoolsearch = currentAdvancedSearchForm = new ew.Form("fuseridpoolsearch", "search");
	<?php } else { ?>
	fuseridpoolsearch = currentForm = new ew.Form("fuseridpoolsearch", "search");
	<?php } ?>
	currentPageID = ew.PAGE_ID = "search";

	// Validate function for search
	fuseridpoolsearch.validate = function(fobj) {
		if (!this.validateRequired)
			return true; // Ignore validation
		fobj = fobj || this._form;
		var infix = "";
		elm = this.getElements("x" + infix + "_id");
		if (elm && !ew.checkInteger(elm.value))
			return this.onError(elm, "<?php echo JsEncode($useridpool_search->id->errorMessage()) ?>");
		elm = this.getElements("x" + infix + "__userid");
		if (elm && !ew.checkInteger(elm.value))
			return this.onError(elm, "<?php echo JsEncode($useridpool_search->_userid->errorMessage()) ?>");
		elm = this.getElements("x" + infix + "_expirytime");
		if (elm && !ew.checkUSDate(elm.value))
			return this.onError(elm, "<?php echo JsEncode($useridpool_search->expirytime->errorMessage()) ?>");

		// Call Form_CustomValidate event
		if (!this.Form_CustomValidate(fobj))
			return false;
		return true;
	}

	// Form_CustomValidate
	fuseridpoolsearch.Form_CustomValidate = function(fobj) { // DO NOT CHANGE THIS LINE!

		// Your custom validation code here, return false if invalid.
		return true;
	}

	// Use JavaScript validation or not
	fuseridpoolsearch.validateRequired = <?php echo Config("CLIENT_VALIDATE") ? "true" : "false" ?>;

	// Dynamic selection lists
	loadjs.done("fuseridpoolsearch");
});
</script>
<script>
loadjs.ready("head", function() {

	// Client script
	// Write your client script here, no need to add script tags.

});
</script>
<?php $useridpool_search->showPageHeader(); ?>
<?php
$useridpool_search->showMessage();
?>
<form name="fuseridpoolsearch" id="fuseridpoolsearch" class="<?php echo $useridpool_search->FormClassName ?>" action="<?php echo CurrentPageName() ?>" method="post">
<?php if ($Page->CheckToken) { ?>
<input type="hidden" name="<?php echo Config("TOKEN_NAME") ?>" value="<?php echo $Page->Token ?>">
<?php } ?>
<input type="hidden" name="t" value="useridpool">
<input type="hidden" name="action" id="action" value="search">
<input type="hidden" name="modal" value="<?php echo (int)$useridpool_search->IsModal ?>">
<div class="ew-search-div"><!-- page* -->
<?php if ($useridpool_search->id->Visible) { // id ?>
	<div id="r_id" class="form-group row">
		<label for="x_id" class="<?php echo $useridpool_search->LeftColumnClass ?>"><span id="elh_useridpool_id"><?php echo $useridpool_search->id->caption() ?></span>
		<span class="ew-search-operator">
<?php echo $Language->phrase("=") ?>
<input type="hidden" name="z_id" id="z_id" value="=">
</span>
		</label>
		<div class="<?php echo $useridpool_search->RightColumnClass ?>"><div <?php echo $useridpool_search->id->cellAttributes() ?>>
			<span id="el_useridpool_id" class="ew-search-field">
<input type="text" data-table="useridpool" data-field="x_id" name="x_id" id="x_id" placeholder="<?php echo HtmlEncode($useridpool_search->id->getPlaceHolder()) ?>" value="<?php echo $useridpool_search->id->EditValue ?>"<?php echo $useridpool_search->id->editAttributes() ?>>
</span>
		</div></div>
	</div>
<?php } ?>
<?php if ($useridpool_search->_userid->Visible) { // userid ?>
	<div id="r__userid" class="form-group row">
		<label for="x__userid" class="<?php echo $useridpool_search->LeftColumnClass ?>"><span id="elh_useridpool__userid"><?php echo $useridpool_search->_userid->caption() ?></span>
		<span class="ew-search-operator">
<?php echo $Language->phrase("=") ?>
<input type="hidden" name="z__userid" id="z__userid" value="=">
</span>
		</label>
		<div class="<?php echo $useridpool_search->RightColumnClass ?>"><div <?php echo $useridpool_search->_userid->cellAttributes() ?>>
			<span id="el_useridpool__userid" class="ew-search-field">
<input type="text" data-table="useridpool" data-field="x__userid" name="x__userid" id="x__userid" size="30" placeholder="<?php echo HtmlEncode($useridpool_search->_userid->getPlaceHolder()) ?>" value="<?php echo $useridpool_search->_userid->EditValue ?>"<?php echo $useridpool_search->_userid->editAttributes() ?>>
</span>
		</div></div>
	</div>
<?php } ?>
<?php if ($useridpool_search->txcode->Visible) { // txcode ?>
	<div id="r_txcode" class="form-group row">
		<label for="x_txcode" class="<?php echo $useridpool_search->LeftColumnClass ?>"><span id="elh_useridpool_txcode"><?php echo $useridpool_search->txcode->caption() ?></span>
		<span class="ew-search-operator">
<?php echo $Language->phrase("LIKE") ?>
<input type="hidden" name="z_txcode" id="z_txcode" value="LIKE">
</span>
		</label>
		<div class="<?php echo $useridpool_search->RightColumnClass ?>"><div <?php echo $useridpool_search->txcode->cellAttributes() ?>>
			<span id="el_useridpool_txcode" class="ew-search-field">
<input type="text" data-table="useridpool" data-field="x_txcode" name="x_txcode" id="x_txcode" size="30" maxlength="10" placeholder="<?php echo HtmlEncode($useridpool_search->txcode->getPlaceHolder()) ?>" value="<?php echo $useridpool_search->txcode->EditValue ?>"<?php echo $useridpool_search->txcode->editAttributes() ?>>
</span>
		</div></div>
	</div>
<?php } ?>
<?php if ($useridpool_search->expirytime->Visible) { // expirytime ?>
	<div id="r_expirytime" class="form-group row">
		<label for="x_expirytime" class="<?php echo $useridpool_search->LeftColumnClass ?>"><span id="elh_useridpool_expirytime"><?php echo $useridpool_search->expirytime->caption() ?></span>
		<span class="ew-search-operator">
<?php echo $Language->phrase("=") ?>
<input type="hidden" name="z_expirytime" id="z_expirytime" value="=">
</span>
		</label>
		<div class="<?php echo $useridpool_search->RightColumnClass ?>"><div <?php echo $useridpool_search->expirytime->cellAttributes() ?>>
			<span id="el_useridpool_expirytime" class="ew-search-field">
<input type="text" data-table="useridpool" data-field="x_expirytime" data-format="10" name="x_expirytime" id="x_expirytime" placeholder="<?php echo HtmlEncode($useridpool_search->expirytime->getPlaceHolder()) ?>" value="<?php echo $useridpool_search->expirytime->EditValue ?>"<?php echo $useridpool_search->expirytime->editAttributes() ?>>
<?php if (!$useridpool_search->expirytime->ReadOnly && !$useridpool_search->expirytime->Disabled && !isset($useridpool_search->expirytime->EditAttrs["readonly"]) && !isset($useridpool_search->expirytime->EditAttrs["disabled"])) { ?>
<script>
loadjs.ready(["fuseridpoolsearch", "datetimepicker"], function() {
	ew.createDateTimePicker("fuseridpoolsearch", "x_expirytime", {"ignoreReadonly":true,"useCurrent":false,"format":10});
});
</script>
<?php } ?>
</span>
		</div></div>
	</div>
<?php } ?>
</div><!-- /page* -->
<?php if (!$useridpool_search->IsModal) { ?>
<div class="form-group row"><!-- buttons .form-group -->
	<div class="<?php echo $useridpool_search->OffsetColumnClass ?>"><!-- buttons offset -->
<button class="btn btn-primary ew-btn" name="btn-action" id="btn-action" type="submit"><?php echo $Language->phrase("Search") ?></button>
<button class="btn btn-default ew-btn" name="btn-reset" id="btn-reset" type="button" onclick="ew.clearForm(this.form);"><?php echo $Language->phrase("Reset") ?></button>
	</div><!-- /buttons offset -->
</div><!-- /buttons .form-group -->
<?php } ?>
</form>
<?php
$useridpool_search->showPageFooter();
if (Config("DEBUG"))
	echo GetDebugMessage();
?>
<script>
loadjs.ready("load", function() {

	// Startup script
	// Write your table-specific startup script here
	// console.log("page loaded");

});
</script>
<?php include_once "footer.php"; ?>
<?php
$useridpool_search->terminate();
?>