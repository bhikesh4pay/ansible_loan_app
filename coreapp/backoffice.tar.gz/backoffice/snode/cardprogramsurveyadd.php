<?php
namespace PHPMaker2020\_4payadmin;

// Autoload
include_once "autoload.php";

// Session
if (session_status() !== PHP_SESSION_ACTIVE)
	\Delight\Cookie\Session::start(Config("COOKIE_SAMESITE")); // Init session data

// Output buffering
ob_start();
?>
<?php

// Write header
WriteHeader(FALSE);

// Create page object
$cardprogramsurvey_add = new cardprogramsurvey_add();

// Run the page
$cardprogramsurvey_add->run();

// Setup login status
SetupLoginStatus();
SetClientVar("login", LoginStatus());

// Global Page Rendering event (in userfn*.php)
Page_Rendering();

// Page Rendering event
$cardprogramsurvey_add->Page_Render();
?>
<?php include_once "header.php"; ?>
<script>
var fcardprogramsurveyadd, currentPageID;
loadjs.ready("head", function() {

	// Form object
	currentPageID = ew.PAGE_ID = "add";
	fcardprogramsurveyadd = currentForm = new ew.Form("fcardprogramsurveyadd", "add");

	// Validate form
	fcardprogramsurveyadd.validate = function() {
		if (!this.validateRequired)
			return true; // Ignore validation
		var $ = jQuery, fobj = this.getForm(), $fobj = $(fobj);
		if ($fobj.find("#confirm").val() == "confirm")
			return true;
		var elm, felm, uelm, addcnt = 0;
		var $k = $fobj.find("#" + this.formKeyCountName); // Get key_count
		var rowcnt = ($k[0]) ? parseInt($k.val(), 10) : 1;
		var startcnt = (rowcnt == 0) ? 0 : 1; // Check rowcnt == 0 => Inline-Add
		var gridinsert = ["insert", "gridinsert"].includes($fobj.find("#action").val()) && $k[0];
		for (var i = startcnt; i <= rowcnt; i++) {
			var infix = ($k[0]) ? String(i) : "";
			$fobj.data("rowindex", infix);
			<?php if ($cardprogramsurvey_add->surveygroupid->Required) { ?>
				elm = this.getElements("x" + infix + "_surveygroupid");
				if (elm && !ew.isHidden(elm) && !ew.hasValue(elm))
					return this.onError(elm, "<?php echo JsEncode(str_replace("%s", $cardprogramsurvey_add->surveygroupid->caption(), $cardprogramsurvey_add->surveygroupid->RequiredErrorMessage)) ?>");
			<?php } ?>
				elm = this.getElements("x" + infix + "_surveygroupid");
				if (elm && !ew.checkInteger(elm.value))
					return this.onError(elm, "<?php echo JsEncode($cardprogramsurvey_add->surveygroupid->errorMessage()) ?>");
			<?php if ($cardprogramsurvey_add->surveytype->Required) { ?>
				elm = this.getElements("x" + infix + "_surveytype");
				if (elm && !ew.isHidden(elm) && !ew.hasValue(elm))
					return this.onError(elm, "<?php echo JsEncode(str_replace("%s", $cardprogramsurvey_add->surveytype->caption(), $cardprogramsurvey_add->surveytype->RequiredErrorMessage)) ?>");
			<?php } ?>
			<?php if ($cardprogramsurvey_add->surveyname->Required) { ?>
				elm = this.getElements("x" + infix + "_surveyname");
				if (elm && !ew.isHidden(elm) && !ew.hasValue(elm))
					return this.onError(elm, "<?php echo JsEncode(str_replace("%s", $cardprogramsurvey_add->surveyname->caption(), $cardprogramsurvey_add->surveyname->RequiredErrorMessage)) ?>");
			<?php } ?>
			<?php if ($cardprogramsurvey_add->active->Required) { ?>
				elm = this.getElements("x" + infix + "_active");
				if (elm && !ew.isHidden(elm) && !ew.hasValue(elm))
					return this.onError(elm, "<?php echo JsEncode(str_replace("%s", $cardprogramsurvey_add->active->caption(), $cardprogramsurvey_add->active->RequiredErrorMessage)) ?>");
			<?php } ?>
			<?php if ($cardprogramsurvey_add->properties->Required) { ?>
				elm = this.getElements("x" + infix + "_properties");
				if (elm && !ew.isHidden(elm) && !ew.hasValue(elm))
					return this.onError(elm, "<?php echo JsEncode(str_replace("%s", $cardprogramsurvey_add->properties->caption(), $cardprogramsurvey_add->properties->RequiredErrorMessage)) ?>");
			<?php } ?>
			<?php if ($cardprogramsurvey_add->lastupdatedate->Required) { ?>
				elm = this.getElements("x" + infix + "_lastupdatedate");
				if (elm && !ew.isHidden(elm) && !ew.hasValue(elm))
					return this.onError(elm, "<?php echo JsEncode(str_replace("%s", $cardprogramsurvey_add->lastupdatedate->caption(), $cardprogramsurvey_add->lastupdatedate->RequiredErrorMessage)) ?>");
			<?php } ?>
				elm = this.getElements("x" + infix + "_lastupdatedate");
				if (elm && !ew.checkDateDef(elm.value))
					return this.onError(elm, "<?php echo JsEncode($cardprogramsurvey_add->lastupdatedate->errorMessage()) ?>");
			<?php if ($cardprogramsurvey_add->creationdate->Required) { ?>
				elm = this.getElements("x" + infix + "_creationdate");
				if (elm && !ew.isHidden(elm) && !ew.hasValue(elm))
					return this.onError(elm, "<?php echo JsEncode(str_replace("%s", $cardprogramsurvey_add->creationdate->caption(), $cardprogramsurvey_add->creationdate->RequiredErrorMessage)) ?>");
			<?php } ?>
				elm = this.getElements("x" + infix + "_creationdate");
				if (elm && !ew.checkDateDef(elm.value))
					return this.onError(elm, "<?php echo JsEncode($cardprogramsurvey_add->creationdate->errorMessage()) ?>");

				// Call Form_CustomValidate event
				if (!this.Form_CustomValidate(fobj))
					return false;
		}

		// Process detail forms
		var dfs = $fobj.find("input[name='detailpage']").get();
		for (var i = 0; i < dfs.length; i++) {
			var df = dfs[i], val = df.value;
			if (val && ew.forms[val])
				if (!ew.forms[val].validate())
					return false;
		}
		return true;
	}

	// Form_CustomValidate
	fcardprogramsurveyadd.Form_CustomValidate = function(fobj) { // DO NOT CHANGE THIS LINE!

		// Your custom validation code here, return false if invalid.
		return true;
	}

	// Use JavaScript validation or not
	fcardprogramsurveyadd.validateRequired = <?php echo Config("CLIENT_VALIDATE") ? "true" : "false" ?>;

	// Dynamic selection lists
	fcardprogramsurveyadd.lists["x_surveytype"] = <?php echo $cardprogramsurvey_add->surveytype->Lookup->toClientList($cardprogramsurvey_add) ?>;
	fcardprogramsurveyadd.lists["x_surveytype"].options = <?php echo JsonEncode($cardprogramsurvey_add->surveytype->options(FALSE, TRUE)) ?>;
	fcardprogramsurveyadd.lists["x_active"] = <?php echo $cardprogramsurvey_add->active->Lookup->toClientList($cardprogramsurvey_add) ?>;
	fcardprogramsurveyadd.lists["x_active"].options = <?php echo JsonEncode($cardprogramsurvey_add->active->lookupOptions()) ?>;
	loadjs.done("fcardprogramsurveyadd");
});
</script>
<script>
loadjs.ready("head", function() {

	// Client script
	// Write your client script here, no need to add script tags.

});
</script>
<?php $cardprogramsurvey_add->showPageHeader(); ?>
<?php
$cardprogramsurvey_add->showMessage();
?>
<form name="fcardprogramsurveyadd" id="fcardprogramsurveyadd" class="<?php echo $cardprogramsurvey_add->FormClassName ?>" action="<?php echo CurrentPageName() ?>" method="post">
<?php if ($Page->CheckToken) { ?>
<input type="hidden" name="<?php echo Config("TOKEN_NAME") ?>" value="<?php echo $Page->Token ?>">
<?php } ?>
<input type="hidden" name="t" value="cardprogramsurvey">
<input type="hidden" name="action" id="action" value="insert">
<input type="hidden" name="modal" value="<?php echo (int)$cardprogramsurvey_add->IsModal ?>">
<?php if ($cardprogramsurvey->getCurrentMasterTable() == "cardprogramsurveygroup") { ?>
<input type="hidden" name="<?php echo Config("TABLE_SHOW_MASTER") ?>" value="cardprogramsurveygroup">
<input type="hidden" name="fk_groupid" value="<?php echo HtmlEncode($cardprogramsurvey_add->surveygroupid->getSessionValue()) ?>">
<?php } ?>
<div class="ew-add-div"><!-- page* -->
<?php if ($cardprogramsurvey_add->surveygroupid->Visible) { // surveygroupid ?>
	<div id="r_surveygroupid" class="form-group row">
		<label id="elh_cardprogramsurvey_surveygroupid" for="x_surveygroupid" class="<?php echo $cardprogramsurvey_add->LeftColumnClass ?>"><?php echo $cardprogramsurvey_add->surveygroupid->caption() ?><?php echo $cardprogramsurvey_add->surveygroupid->Required ? $Language->phrase("FieldRequiredIndicator") : "" ?></label>
		<div class="<?php echo $cardprogramsurvey_add->RightColumnClass ?>"><div <?php echo $cardprogramsurvey_add->surveygroupid->cellAttributes() ?>>
<?php if ($cardprogramsurvey_add->surveygroupid->getSessionValue() != "") { ?>
<span id="el_cardprogramsurvey_surveygroupid">
<span<?php echo $cardprogramsurvey_add->surveygroupid->viewAttributes() ?>><input type="text" readonly class="form-control-plaintext" value="<?php echo HtmlEncode(RemoveHtml($cardprogramsurvey_add->surveygroupid->ViewValue)) ?>"></span>
</span>
<input type="hidden" id="x_surveygroupid" name="x_surveygroupid" value="<?php echo HtmlEncode($cardprogramsurvey_add->surveygroupid->CurrentValue) ?>">
<?php } else { ?>
<span id="el_cardprogramsurvey_surveygroupid">
<input type="text" data-table="cardprogramsurvey" data-field="x_surveygroupid" name="x_surveygroupid" id="x_surveygroupid" size="30" maxlength="10" placeholder="<?php echo HtmlEncode($cardprogramsurvey_add->surveygroupid->getPlaceHolder()) ?>" value="<?php echo $cardprogramsurvey_add->surveygroupid->EditValue ?>"<?php echo $cardprogramsurvey_add->surveygroupid->editAttributes() ?>>
</span>
<?php } ?>
<?php echo $cardprogramsurvey_add->surveygroupid->CustomMsg ?></div></div>
	</div>
<?php } ?>
<?php if ($cardprogramsurvey_add->surveytype->Visible) { // surveytype ?>
	<div id="r_surveytype" class="form-group row">
		<label id="elh_cardprogramsurvey_surveytype" for="x_surveytype" class="<?php echo $cardprogramsurvey_add->LeftColumnClass ?>"><?php echo $cardprogramsurvey_add->surveytype->caption() ?><?php echo $cardprogramsurvey_add->surveytype->Required ? $Language->phrase("FieldRequiredIndicator") : "" ?></label>
		<div class="<?php echo $cardprogramsurvey_add->RightColumnClass ?>"><div <?php echo $cardprogramsurvey_add->surveytype->cellAttributes() ?>>
<span id="el_cardprogramsurvey_surveytype">
<div class="input-group">
	<select class="custom-select ew-custom-select" data-table="cardprogramsurvey" data-field="x_surveytype" data-value-separator="<?php echo $cardprogramsurvey_add->surveytype->displayValueSeparatorAttribute() ?>" id="x_surveytype" name="x_surveytype"<?php echo $cardprogramsurvey_add->surveytype->editAttributes() ?>>
			<?php echo $cardprogramsurvey_add->surveytype->selectOptionListHtml("x_surveytype") ?>
		</select>
</div>
</span>
<?php echo $cardprogramsurvey_add->surveytype->CustomMsg ?></div></div>
	</div>
<?php } ?>
<?php if ($cardprogramsurvey_add->surveyname->Visible) { // surveyname ?>
	<div id="r_surveyname" class="form-group row">
		<label id="elh_cardprogramsurvey_surveyname" for="x_surveyname" class="<?php echo $cardprogramsurvey_add->LeftColumnClass ?>"><?php echo $cardprogramsurvey_add->surveyname->caption() ?><?php echo $cardprogramsurvey_add->surveyname->Required ? $Language->phrase("FieldRequiredIndicator") : "" ?></label>
		<div class="<?php echo $cardprogramsurvey_add->RightColumnClass ?>"><div <?php echo $cardprogramsurvey_add->surveyname->cellAttributes() ?>>
<span id="el_cardprogramsurvey_surveyname">
<input type="text" data-table="cardprogramsurvey" data-field="x_surveyname" name="x_surveyname" id="x_surveyname" size="30" maxlength="60" placeholder="<?php echo HtmlEncode($cardprogramsurvey_add->surveyname->getPlaceHolder()) ?>" value="<?php echo $cardprogramsurvey_add->surveyname->EditValue ?>"<?php echo $cardprogramsurvey_add->surveyname->editAttributes() ?>>
</span>
<?php echo $cardprogramsurvey_add->surveyname->CustomMsg ?></div></div>
	</div>
<?php } ?>
<?php if ($cardprogramsurvey_add->active->Visible) { // active ?>
	<div id="r_active" class="form-group row">
		<label id="elh_cardprogramsurvey_active" class="<?php echo $cardprogramsurvey_add->LeftColumnClass ?>"><?php echo $cardprogramsurvey_add->active->caption() ?><?php echo $cardprogramsurvey_add->active->Required ? $Language->phrase("FieldRequiredIndicator") : "" ?></label>
		<div class="<?php echo $cardprogramsurvey_add->RightColumnClass ?>"><div <?php echo $cardprogramsurvey_add->active->cellAttributes() ?>>
<span id="el_cardprogramsurvey_active">
<div id="tp_x_active" class="ew-template"><input type="radio" class="custom-control-input" data-table="cardprogramsurvey" data-field="x_active" data-value-separator="<?php echo $cardprogramsurvey_add->active->displayValueSeparatorAttribute() ?>" name="x_active" id="x_active" value="{value}"<?php echo $cardprogramsurvey_add->active->editAttributes() ?>></div>
<div id="dsl_x_active" data-repeatcolumn="5" class="ew-item-list d-none"><div>
<?php echo $cardprogramsurvey_add->active->radioButtonListHtml(FALSE, "x_active") ?>
</div></div>
<?php echo $cardprogramsurvey_add->active->Lookup->getParamTag($cardprogramsurvey_add, "p_x_active") ?>
</span>
<?php echo $cardprogramsurvey_add->active->CustomMsg ?></div></div>
	</div>
<?php } ?>
<?php if ($cardprogramsurvey_add->properties->Visible) { // properties ?>
	<div id="r_properties" class="form-group row">
		<label id="elh_cardprogramsurvey_properties" for="x_properties" class="<?php echo $cardprogramsurvey_add->LeftColumnClass ?>"><?php echo $cardprogramsurvey_add->properties->caption() ?><?php echo $cardprogramsurvey_add->properties->Required ? $Language->phrase("FieldRequiredIndicator") : "" ?></label>
		<div class="<?php echo $cardprogramsurvey_add->RightColumnClass ?>"><div <?php echo $cardprogramsurvey_add->properties->cellAttributes() ?>>
<span id="el_cardprogramsurvey_properties">
<textarea data-table="cardprogramsurvey" data-field="x_properties" name="x_properties" id="x_properties" cols="35" rows="4" placeholder="<?php echo HtmlEncode($cardprogramsurvey_add->properties->getPlaceHolder()) ?>"<?php echo $cardprogramsurvey_add->properties->editAttributes() ?>><?php echo $cardprogramsurvey_add->properties->EditValue ?></textarea>
</span>
<?php echo $cardprogramsurvey_add->properties->CustomMsg ?></div></div>
	</div>
<?php } ?>
<?php if ($cardprogramsurvey_add->lastupdatedate->Visible) { // lastupdatedate ?>
	<div id="r_lastupdatedate" class="form-group row">
		<label id="elh_cardprogramsurvey_lastupdatedate" for="x_lastupdatedate" class="<?php echo $cardprogramsurvey_add->LeftColumnClass ?>"><?php echo $cardprogramsurvey_add->lastupdatedate->caption() ?><?php echo $cardprogramsurvey_add->lastupdatedate->Required ? $Language->phrase("FieldRequiredIndicator") : "" ?></label>
		<div class="<?php echo $cardprogramsurvey_add->RightColumnClass ?>"><div <?php echo $cardprogramsurvey_add->lastupdatedate->cellAttributes() ?>>
<span id="el_cardprogramsurvey_lastupdatedate">
<input type="text" data-table="cardprogramsurvey" data-field="x_lastupdatedate" name="x_lastupdatedate" id="x_lastupdatedate" maxlength="19" placeholder="<?php echo HtmlEncode($cardprogramsurvey_add->lastupdatedate->getPlaceHolder()) ?>" value="<?php echo $cardprogramsurvey_add->lastupdatedate->EditValue ?>"<?php echo $cardprogramsurvey_add->lastupdatedate->editAttributes() ?>>
<?php if (!$cardprogramsurvey_add->lastupdatedate->ReadOnly && !$cardprogramsurvey_add->lastupdatedate->Disabled && !isset($cardprogramsurvey_add->lastupdatedate->EditAttrs["readonly"]) && !isset($cardprogramsurvey_add->lastupdatedate->EditAttrs["disabled"])) { ?>
<script>
loadjs.ready(["fcardprogramsurveyadd", "datetimepicker"], function() {
	ew.createDateTimePicker("fcardprogramsurveyadd", "x_lastupdatedate", {"ignoreReadonly":true,"useCurrent":false,"format":0});
});
</script>
<?php } ?>
</span>
<?php echo $cardprogramsurvey_add->lastupdatedate->CustomMsg ?></div></div>
	</div>
<?php } ?>
<?php if ($cardprogramsurvey_add->creationdate->Visible) { // creationdate ?>
	<div id="r_creationdate" class="form-group row">
		<label id="elh_cardprogramsurvey_creationdate" for="x_creationdate" class="<?php echo $cardprogramsurvey_add->LeftColumnClass ?>"><?php echo $cardprogramsurvey_add->creationdate->caption() ?><?php echo $cardprogramsurvey_add->creationdate->Required ? $Language->phrase("FieldRequiredIndicator") : "" ?></label>
		<div class="<?php echo $cardprogramsurvey_add->RightColumnClass ?>"><div <?php echo $cardprogramsurvey_add->creationdate->cellAttributes() ?>>
<span id="el_cardprogramsurvey_creationdate">
<input type="text" data-table="cardprogramsurvey" data-field="x_creationdate" name="x_creationdate" id="x_creationdate" maxlength="19" placeholder="<?php echo HtmlEncode($cardprogramsurvey_add->creationdate->getPlaceHolder()) ?>" value="<?php echo $cardprogramsurvey_add->creationdate->EditValue ?>"<?php echo $cardprogramsurvey_add->creationdate->editAttributes() ?>>
<?php if (!$cardprogramsurvey_add->creationdate->ReadOnly && !$cardprogramsurvey_add->creationdate->Disabled && !isset($cardprogramsurvey_add->creationdate->EditAttrs["readonly"]) && !isset($cardprogramsurvey_add->creationdate->EditAttrs["disabled"])) { ?>
<script>
loadjs.ready(["fcardprogramsurveyadd", "datetimepicker"], function() {
	ew.createDateTimePicker("fcardprogramsurveyadd", "x_creationdate", {"ignoreReadonly":true,"useCurrent":false,"format":0});
});
</script>
<?php } ?>
</span>
<?php echo $cardprogramsurvey_add->creationdate->CustomMsg ?></div></div>
	</div>
<?php } ?>
</div><!-- /page* -->
<?php if (!$cardprogramsurvey_add->IsModal) { ?>
<div class="form-group row"><!-- buttons .form-group -->
	<div class="<?php echo $cardprogramsurvey_add->OffsetColumnClass ?>"><!-- buttons offset -->
<button class="btn btn-primary ew-btn" name="btn-action" id="btn-action" type="submit"><?php echo $Language->phrase("AddBtn") ?></button>
<button class="btn btn-default ew-btn" name="btn-cancel" id="btn-cancel" type="button" data-href="<?php echo $cardprogramsurvey_add->getReturnUrl() ?>"><?php echo $Language->phrase("CancelBtn") ?></button>
	</div><!-- /buttons offset -->
</div><!-- /buttons .form-group -->
<?php } ?>
</form>
<?php
$cardprogramsurvey_add->showPageFooter();
if (Config("DEBUG"))
	echo GetDebugMessage();
?>
<script>
loadjs.ready("load", function() {

	// Startup script
	// Write your table-specific startup script here
	// console.log("page loaded");

});
</script>
<?php include_once "footer.php"; ?>
<?php
$cardprogramsurvey_add->terminate();
?>