<?php
namespace PHPMaker2020\_4payadmin;

// Autoload
include_once "autoload.php";

// Session
if (session_status() !== PHP_SESSION_ACTIVE)
	\Delight\Cookie\Session::start(Config("COOKIE_SAMESITE")); // Init session data

// Output buffering
ob_start();
?>
<?php

// Write header
WriteHeader(FALSE);

// Create page object
$loanlimitshistory_add = new loanlimitshistory_add();

// Run the page
$loanlimitshistory_add->run();

// Setup login status
SetupLoginStatus();
SetClientVar("login", LoginStatus());

// Global Page Rendering event (in userfn*.php)
Page_Rendering();

// Page Rendering event
$loanlimitshistory_add->Page_Render();
?>
<?php include_once "header.php"; ?>
<script>
var floanlimitshistoryadd, currentPageID;
loadjs.ready("head", function() {

	// Form object
	currentPageID = ew.PAGE_ID = "add";
	floanlimitshistoryadd = currentForm = new ew.Form("floanlimitshistoryadd", "add");

	// Validate form
	floanlimitshistoryadd.validate = function() {
		if (!this.validateRequired)
			return true; // Ignore validation
		var $ = jQuery, fobj = this.getForm(), $fobj = $(fobj);
		if ($fobj.find("#confirm").val() == "confirm")
			return true;
		var elm, felm, uelm, addcnt = 0;
		var $k = $fobj.find("#" + this.formKeyCountName); // Get key_count
		var rowcnt = ($k[0]) ? parseInt($k.val(), 10) : 1;
		var startcnt = (rowcnt == 0) ? 0 : 1; // Check rowcnt == 0 => Inline-Add
		var gridinsert = ["insert", "gridinsert"].includes($fobj.find("#action").val()) && $k[0];
		for (var i = startcnt; i <= rowcnt; i++) {
			var infix = ($k[0]) ? String(i) : "";
			$fobj.data("rowindex", infix);
			<?php if ($loanlimitshistory_add->_userid->Required) { ?>
				elm = this.getElements("x" + infix + "__userid");
				if (elm && !ew.isHidden(elm) && !ew.hasValue(elm))
					return this.onError(elm, "<?php echo JsEncode(str_replace("%s", $loanlimitshistory_add->_userid->caption(), $loanlimitshistory_add->_userid->RequiredErrorMessage)) ?>");
			<?php } ?>
				elm = this.getElements("x" + infix + "__userid");
				if (elm && !ew.checkInteger(elm.value))
					return this.onError(elm, "<?php echo JsEncode($loanlimitshistory_add->_userid->errorMessage()) ?>");
			<?php if ($loanlimitshistory_add->curr->Required) { ?>
				elm = this.getElements("x" + infix + "_curr");
				if (elm && !ew.isHidden(elm) && !ew.hasValue(elm))
					return this.onError(elm, "<?php echo JsEncode(str_replace("%s", $loanlimitshistory_add->curr->caption(), $loanlimitshistory_add->curr->RequiredErrorMessage)) ?>");
			<?php } ?>
			<?php if ($loanlimitshistory_add->fromlimit->Required) { ?>
				elm = this.getElements("x" + infix + "_fromlimit");
				if (elm && !ew.isHidden(elm) && !ew.hasValue(elm))
					return this.onError(elm, "<?php echo JsEncode(str_replace("%s", $loanlimitshistory_add->fromlimit->caption(), $loanlimitshistory_add->fromlimit->RequiredErrorMessage)) ?>");
			<?php } ?>
				elm = this.getElements("x" + infix + "_fromlimit");
				if (elm && !ew.checkNumber(elm.value))
					return this.onError(elm, "<?php echo JsEncode($loanlimitshistory_add->fromlimit->errorMessage()) ?>");
			<?php if ($loanlimitshistory_add->tolimit->Required) { ?>
				elm = this.getElements("x" + infix + "_tolimit");
				if (elm && !ew.isHidden(elm) && !ew.hasValue(elm))
					return this.onError(elm, "<?php echo JsEncode(str_replace("%s", $loanlimitshistory_add->tolimit->caption(), $loanlimitshistory_add->tolimit->RequiredErrorMessage)) ?>");
			<?php } ?>
				elm = this.getElements("x" + infix + "_tolimit");
				if (elm && !ew.checkNumber(elm.value))
					return this.onError(elm, "<?php echo JsEncode($loanlimitshistory_add->tolimit->errorMessage()) ?>");
			<?php if ($loanlimitshistory_add->changedate->Required) { ?>
				elm = this.getElements("x" + infix + "_changedate");
				if (elm && !ew.isHidden(elm) && !ew.hasValue(elm))
					return this.onError(elm, "<?php echo JsEncode(str_replace("%s", $loanlimitshistory_add->changedate->caption(), $loanlimitshistory_add->changedate->RequiredErrorMessage)) ?>");
			<?php } ?>
				elm = this.getElements("x" + infix + "_changedate");
				if (elm && !ew.checkDateDef(elm.value))
					return this.onError(elm, "<?php echo JsEncode($loanlimitshistory_add->changedate->errorMessage()) ?>");

				// Call Form_CustomValidate event
				if (!this.Form_CustomValidate(fobj))
					return false;
		}

		// Process detail forms
		var dfs = $fobj.find("input[name='detailpage']").get();
		for (var i = 0; i < dfs.length; i++) {
			var df = dfs[i], val = df.value;
			if (val && ew.forms[val])
				if (!ew.forms[val].validate())
					return false;
		}
		return true;
	}

	// Form_CustomValidate
	floanlimitshistoryadd.Form_CustomValidate = function(fobj) { // DO NOT CHANGE THIS LINE!

		// Your custom validation code here, return false if invalid.
		return true;
	}

	// Use JavaScript validation or not
	floanlimitshistoryadd.validateRequired = <?php echo Config("CLIENT_VALIDATE") ? "true" : "false" ?>;

	// Dynamic selection lists
	loadjs.done("floanlimitshistoryadd");
});
</script>
<script>
loadjs.ready("head", function() {

	// Client script
	// Write your client script here, no need to add script tags.

});
</script>
<?php $loanlimitshistory_add->showPageHeader(); ?>
<?php
$loanlimitshistory_add->showMessage();
?>
<form name="floanlimitshistoryadd" id="floanlimitshistoryadd" class="<?php echo $loanlimitshistory_add->FormClassName ?>" action="<?php echo CurrentPageName() ?>" method="post">
<?php if ($Page->CheckToken) { ?>
<input type="hidden" name="<?php echo Config("TOKEN_NAME") ?>" value="<?php echo $Page->Token ?>">
<?php } ?>
<input type="hidden" name="t" value="loanlimitshistory">
<input type="hidden" name="action" id="action" value="insert">
<input type="hidden" name="modal" value="<?php echo (int)$loanlimitshistory_add->IsModal ?>">
<?php if ($loanlimitshistory->getCurrentMasterTable() == "loanlimits") { ?>
<input type="hidden" name="<?php echo Config("TABLE_SHOW_MASTER") ?>" value="loanlimits">
<input type="hidden" name="fk__userid" value="<?php echo HtmlEncode($loanlimitshistory_add->_userid->getSessionValue()) ?>">
<input type="hidden" name="fk_currcode" value="<?php echo HtmlEncode($loanlimitshistory_add->curr->getSessionValue()) ?>">
<?php } ?>
<div class="ew-add-div"><!-- page* -->
<?php if ($loanlimitshistory_add->_userid->Visible) { // userid ?>
	<div id="r__userid" class="form-group row">
		<label id="elh_loanlimitshistory__userid" for="x__userid" class="<?php echo $loanlimitshistory_add->LeftColumnClass ?>"><?php echo $loanlimitshistory_add->_userid->caption() ?><?php echo $loanlimitshistory_add->_userid->Required ? $Language->phrase("FieldRequiredIndicator") : "" ?></label>
		<div class="<?php echo $loanlimitshistory_add->RightColumnClass ?>"><div <?php echo $loanlimitshistory_add->_userid->cellAttributes() ?>>
<?php if ($loanlimitshistory_add->_userid->getSessionValue() != "") { ?>
<span id="el_loanlimitshistory__userid">
<span<?php echo $loanlimitshistory_add->_userid->viewAttributes() ?>><input type="text" readonly class="form-control-plaintext" value="<?php echo HtmlEncode(RemoveHtml($loanlimitshistory_add->_userid->ViewValue)) ?>"></span>
</span>
<input type="hidden" id="x__userid" name="x__userid" value="<?php echo HtmlEncode($loanlimitshistory_add->_userid->CurrentValue) ?>">
<?php } else { ?>
<span id="el_loanlimitshistory__userid">
<input type="text" data-table="loanlimitshistory" data-field="x__userid" name="x__userid" id="x__userid" size="30" maxlength="12" placeholder="<?php echo HtmlEncode($loanlimitshistory_add->_userid->getPlaceHolder()) ?>" value="<?php echo $loanlimitshistory_add->_userid->EditValue ?>"<?php echo $loanlimitshistory_add->_userid->editAttributes() ?>>
</span>
<?php } ?>
<?php echo $loanlimitshistory_add->_userid->CustomMsg ?></div></div>
	</div>
<?php } ?>
<?php if ($loanlimitshistory_add->curr->Visible) { // curr ?>
	<div id="r_curr" class="form-group row">
		<label id="elh_loanlimitshistory_curr" for="x_curr" class="<?php echo $loanlimitshistory_add->LeftColumnClass ?>"><?php echo $loanlimitshistory_add->curr->caption() ?><?php echo $loanlimitshistory_add->curr->Required ? $Language->phrase("FieldRequiredIndicator") : "" ?></label>
		<div class="<?php echo $loanlimitshistory_add->RightColumnClass ?>"><div <?php echo $loanlimitshistory_add->curr->cellAttributes() ?>>
<?php if ($loanlimitshistory_add->curr->getSessionValue() != "") { ?>
<span id="el_loanlimitshistory_curr">
<span<?php echo $loanlimitshistory_add->curr->viewAttributes() ?>><input type="text" readonly class="form-control-plaintext" value="<?php echo HtmlEncode(RemoveHtml($loanlimitshistory_add->curr->ViewValue)) ?>"></span>
</span>
<input type="hidden" id="x_curr" name="x_curr" value="<?php echo HtmlEncode($loanlimitshistory_add->curr->CurrentValue) ?>">
<?php } else { ?>
<span id="el_loanlimitshistory_curr">
<input type="text" data-table="loanlimitshistory" data-field="x_curr" name="x_curr" id="x_curr" size="30" maxlength="3" placeholder="<?php echo HtmlEncode($loanlimitshistory_add->curr->getPlaceHolder()) ?>" value="<?php echo $loanlimitshistory_add->curr->EditValue ?>"<?php echo $loanlimitshistory_add->curr->editAttributes() ?>>
</span>
<?php } ?>
<?php echo $loanlimitshistory_add->curr->CustomMsg ?></div></div>
	</div>
<?php } ?>
<?php if ($loanlimitshistory_add->fromlimit->Visible) { // fromlimit ?>
	<div id="r_fromlimit" class="form-group row">
		<label id="elh_loanlimitshistory_fromlimit" for="x_fromlimit" class="<?php echo $loanlimitshistory_add->LeftColumnClass ?>"><?php echo $loanlimitshistory_add->fromlimit->caption() ?><?php echo $loanlimitshistory_add->fromlimit->Required ? $Language->phrase("FieldRequiredIndicator") : "" ?></label>
		<div class="<?php echo $loanlimitshistory_add->RightColumnClass ?>"><div <?php echo $loanlimitshistory_add->fromlimit->cellAttributes() ?>>
<span id="el_loanlimitshistory_fromlimit">
<input type="text" data-table="loanlimitshistory" data-field="x_fromlimit" name="x_fromlimit" id="x_fromlimit" size="30" maxlength="12" placeholder="<?php echo HtmlEncode($loanlimitshistory_add->fromlimit->getPlaceHolder()) ?>" value="<?php echo $loanlimitshistory_add->fromlimit->EditValue ?>"<?php echo $loanlimitshistory_add->fromlimit->editAttributes() ?>>
</span>
<?php echo $loanlimitshistory_add->fromlimit->CustomMsg ?></div></div>
	</div>
<?php } ?>
<?php if ($loanlimitshistory_add->tolimit->Visible) { // tolimit ?>
	<div id="r_tolimit" class="form-group row">
		<label id="elh_loanlimitshistory_tolimit" for="x_tolimit" class="<?php echo $loanlimitshistory_add->LeftColumnClass ?>"><?php echo $loanlimitshistory_add->tolimit->caption() ?><?php echo $loanlimitshistory_add->tolimit->Required ? $Language->phrase("FieldRequiredIndicator") : "" ?></label>
		<div class="<?php echo $loanlimitshistory_add->RightColumnClass ?>"><div <?php echo $loanlimitshistory_add->tolimit->cellAttributes() ?>>
<span id="el_loanlimitshistory_tolimit">
<input type="text" data-table="loanlimitshistory" data-field="x_tolimit" name="x_tolimit" id="x_tolimit" size="30" maxlength="12" placeholder="<?php echo HtmlEncode($loanlimitshistory_add->tolimit->getPlaceHolder()) ?>" value="<?php echo $loanlimitshistory_add->tolimit->EditValue ?>"<?php echo $loanlimitshistory_add->tolimit->editAttributes() ?>>
</span>
<?php echo $loanlimitshistory_add->tolimit->CustomMsg ?></div></div>
	</div>
<?php } ?>
<?php if ($loanlimitshistory_add->changedate->Visible) { // changedate ?>
	<div id="r_changedate" class="form-group row">
		<label id="elh_loanlimitshistory_changedate" for="x_changedate" class="<?php echo $loanlimitshistory_add->LeftColumnClass ?>"><?php echo $loanlimitshistory_add->changedate->caption() ?><?php echo $loanlimitshistory_add->changedate->Required ? $Language->phrase("FieldRequiredIndicator") : "" ?></label>
		<div class="<?php echo $loanlimitshistory_add->RightColumnClass ?>"><div <?php echo $loanlimitshistory_add->changedate->cellAttributes() ?>>
<span id="el_loanlimitshistory_changedate">
<input type="text" data-table="loanlimitshistory" data-field="x_changedate" name="x_changedate" id="x_changedate" maxlength="19" placeholder="<?php echo HtmlEncode($loanlimitshistory_add->changedate->getPlaceHolder()) ?>" value="<?php echo $loanlimitshistory_add->changedate->EditValue ?>"<?php echo $loanlimitshistory_add->changedate->editAttributes() ?>>
<?php if (!$loanlimitshistory_add->changedate->ReadOnly && !$loanlimitshistory_add->changedate->Disabled && !isset($loanlimitshistory_add->changedate->EditAttrs["readonly"]) && !isset($loanlimitshistory_add->changedate->EditAttrs["disabled"])) { ?>
<script>
loadjs.ready(["floanlimitshistoryadd", "datetimepicker"], function() {
	ew.createDateTimePicker("floanlimitshistoryadd", "x_changedate", {"ignoreReadonly":true,"useCurrent":false,"format":0});
});
</script>
<?php } ?>
</span>
<?php echo $loanlimitshistory_add->changedate->CustomMsg ?></div></div>
	</div>
<?php } ?>
</div><!-- /page* -->
<?php if (!$loanlimitshistory_add->IsModal) { ?>
<div class="form-group row"><!-- buttons .form-group -->
	<div class="<?php echo $loanlimitshistory_add->OffsetColumnClass ?>"><!-- buttons offset -->
<button class="btn btn-primary ew-btn" name="btn-action" id="btn-action" type="submit"><?php echo $Language->phrase("AddBtn") ?></button>
<button class="btn btn-default ew-btn" name="btn-cancel" id="btn-cancel" type="button" data-href="<?php echo $loanlimitshistory_add->getReturnUrl() ?>"><?php echo $Language->phrase("CancelBtn") ?></button>
	</div><!-- /buttons offset -->
</div><!-- /buttons .form-group -->
<?php } ?>
</form>
<?php
$loanlimitshistory_add->showPageFooter();
if (Config("DEBUG"))
	echo GetDebugMessage();
?>
<script>
loadjs.ready("load", function() {

	// Startup script
	// Write your table-specific startup script here
	// console.log("page loaded");

});
</script>
<?php include_once "footer.php"; ?>
<?php
$loanlimitshistory_add->terminate();
?>