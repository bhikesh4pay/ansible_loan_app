<?php
namespace PHPMaker2020\_4payadmin;

// Autoload
include_once "autoload.php";

// Session
if (session_status() !== PHP_SESSION_ACTIVE)
	\Delight\Cookie\Session::start(Config("COOKIE_SAMESITE")); // Init session data

// Output buffering
ob_start();
?>
<?php

// Write header
WriteHeader(FALSE);

// Create page object
$feehistory_delete = new feehistory_delete();

// Run the page
$feehistory_delete->run();

// Setup login status
SetupLoginStatus();
SetClientVar("login", LoginStatus());

// Global Page Rendering event (in userfn*.php)
Page_Rendering();

// Page Rendering event
$feehistory_delete->Page_Render();
?>
<?php include_once "header.php"; ?>
<script>
var ffeehistorydelete, currentPageID;
loadjs.ready("head", function() {

	// Form object
	currentPageID = ew.PAGE_ID = "delete";
	ffeehistorydelete = currentForm = new ew.Form("ffeehistorydelete", "delete");
	loadjs.done("ffeehistorydelete");
});
</script>
<script>
loadjs.ready("head", function() {

	// Client script
	// Write your client script here, no need to add script tags.

});
</script>
<?php $feehistory_delete->showPageHeader(); ?>
<?php
$feehistory_delete->showMessage();
?>
<form name="ffeehistorydelete" id="ffeehistorydelete" class="form-inline ew-form ew-delete-form" action="<?php echo CurrentPageName() ?>" method="post">
<?php if ($Page->CheckToken) { ?>
<input type="hidden" name="<?php echo Config("TOKEN_NAME") ?>" value="<?php echo $Page->Token ?>">
<?php } ?>
<input type="hidden" name="t" value="feehistory">
<input type="hidden" name="action" id="action" value="delete">
<?php foreach ($feehistory_delete->RecKeys as $key) { ?>
<?php $keyvalue = is_array($key) ? implode(Config("COMPOSITE_KEY_SEPARATOR"), $key) : $key; ?>
<input type="hidden" name="key_m[]" value="<?php echo HtmlEncode($keyvalue) ?>">
<?php } ?>
<div class="card ew-card ew-grid">
<div class="<?php echo ResponsiveTableClass() ?>card-body ew-grid-middle-panel">
<table class="table ew-table">
	<thead>
	<tr class="ew-table-header">
<?php if ($feehistory_delete->userpi->Visible) { // userpi ?>
		<th class="<?php echo $feehistory_delete->userpi->headerCellClass() ?>"><span id="elh_feehistory_userpi" class="feehistory_userpi"><?php echo $feehistory_delete->userpi->caption() ?></span></th>
<?php } ?>
<?php if ($feehistory_delete->feedate->Visible) { // feedate ?>
		<th class="<?php echo $feehistory_delete->feedate->headerCellClass() ?>"><span id="elh_feehistory_feedate" class="feehistory_feedate"><?php echo $feehistory_delete->feedate->caption() ?></span></th>
<?php } ?>
<?php if ($feehistory_delete->transtype->Visible) { // transtype ?>
		<th class="<?php echo $feehistory_delete->transtype->headerCellClass() ?>"><span id="elh_feehistory_transtype" class="feehistory_transtype"><?php echo $feehistory_delete->transtype->caption() ?></span></th>
<?php } ?>
<?php if ($feehistory_delete->currcode->Visible) { // currcode ?>
		<th class="<?php echo $feehistory_delete->currcode->headerCellClass() ?>"><span id="elh_feehistory_currcode" class="feehistory_currcode"><?php echo $feehistory_delete->currcode->caption() ?></span></th>
<?php } ?>
<?php if ($feehistory_delete->feeamount->Visible) { // feeamount ?>
		<th class="<?php echo $feehistory_delete->feeamount->headerCellClass() ?>"><span id="elh_feehistory_feeamount" class="feehistory_feeamount"><?php echo $feehistory_delete->feeamount->caption() ?></span></th>
<?php } ?>
	</tr>
	</thead>
	<tbody>
<?php
$feehistory_delete->RecordCount = 0;
$i = 0;
while (!$feehistory_delete->Recordset->EOF) {
	$feehistory_delete->RecordCount++;
	$feehistory_delete->RowCount++;

	// Set row properties
	$feehistory->resetAttributes();
	$feehistory->RowType = ROWTYPE_VIEW; // View

	// Get the field contents
	$feehistory_delete->loadRowValues($feehistory_delete->Recordset);

	// Render row
	$feehistory_delete->renderRow();
?>
	<tr <?php echo $feehistory->rowAttributes() ?>>
<?php if ($feehistory_delete->userpi->Visible) { // userpi ?>
		<td <?php echo $feehistory_delete->userpi->cellAttributes() ?>>
<span id="el<?php echo $feehistory_delete->RowCount ?>_feehistory_userpi" class="feehistory_userpi">
<span<?php echo $feehistory_delete->userpi->viewAttributes() ?>><?php echo $feehistory_delete->userpi->getViewValue() ?></span>
</span>
</td>
<?php } ?>
<?php if ($feehistory_delete->feedate->Visible) { // feedate ?>
		<td <?php echo $feehistory_delete->feedate->cellAttributes() ?>>
<span id="el<?php echo $feehistory_delete->RowCount ?>_feehistory_feedate" class="feehistory_feedate">
<span<?php echo $feehistory_delete->feedate->viewAttributes() ?>><?php echo $feehistory_delete->feedate->getViewValue() ?></span>
</span>
</td>
<?php } ?>
<?php if ($feehistory_delete->transtype->Visible) { // transtype ?>
		<td <?php echo $feehistory_delete->transtype->cellAttributes() ?>>
<span id="el<?php echo $feehistory_delete->RowCount ?>_feehistory_transtype" class="feehistory_transtype">
<span<?php echo $feehistory_delete->transtype->viewAttributes() ?>><?php echo $feehistory_delete->transtype->getViewValue() ?></span>
</span>
</td>
<?php } ?>
<?php if ($feehistory_delete->currcode->Visible) { // currcode ?>
		<td <?php echo $feehistory_delete->currcode->cellAttributes() ?>>
<span id="el<?php echo $feehistory_delete->RowCount ?>_feehistory_currcode" class="feehistory_currcode">
<span<?php echo $feehistory_delete->currcode->viewAttributes() ?>><?php echo $feehistory_delete->currcode->getViewValue() ?></span>
</span>
</td>
<?php } ?>
<?php if ($feehistory_delete->feeamount->Visible) { // feeamount ?>
		<td <?php echo $feehistory_delete->feeamount->cellAttributes() ?>>
<span id="el<?php echo $feehistory_delete->RowCount ?>_feehistory_feeamount" class="feehistory_feeamount">
<span<?php echo $feehistory_delete->feeamount->viewAttributes() ?>><?php echo $feehistory_delete->feeamount->getViewValue() ?></span>
</span>
</td>
<?php } ?>
	</tr>
<?php
	$feehistory_delete->Recordset->moveNext();
}
$feehistory_delete->Recordset->close();
?>
</tbody>
</table>
</div>
</div>
<div>
<button class="btn btn-primary ew-btn" name="btn-action" id="btn-action" type="submit"><?php echo $Language->phrase("DeleteBtn") ?></button>
<button class="btn btn-default ew-btn" name="btn-cancel" id="btn-cancel" type="button" data-href="<?php echo $feehistory_delete->getReturnUrl() ?>"><?php echo $Language->phrase("CancelBtn") ?></button>
</div>
</form>
<?php
$feehistory_delete->showPageFooter();
if (Config("DEBUG"))
	echo GetDebugMessage();
?>
<script>
loadjs.ready("load", function() {

	// Startup script
	// Write your table-specific startup script here
	// console.log("page loaded");

});
</script>
<?php include_once "footer.php"; ?>
<?php
$feehistory_delete->terminate();
?>