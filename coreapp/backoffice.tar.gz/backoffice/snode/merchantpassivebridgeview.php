<?php
namespace PHPMaker2020\_4payadmin;

// Autoload
include_once "autoload.php";

// Session
if (session_status() !== PHP_SESSION_ACTIVE)
	\Delight\Cookie\Session::start(Config("COOKIE_SAMESITE")); // Init session data

// Output buffering
ob_start();
?>
<?php

// Write header
WriteHeader(FALSE);

// Create page object
$merchantpassivebridge_view = new merchantpassivebridge_view();

// Run the page
$merchantpassivebridge_view->run();

// Setup login status
SetupLoginStatus();
SetClientVar("login", LoginStatus());

// Global Page Rendering event (in userfn*.php)
Page_Rendering();

// Page Rendering event
$merchantpassivebridge_view->Page_Render();
?>
<?php include_once "header.php"; ?>
<?php if (!$merchantpassivebridge_view->isExport()) { ?>
<script>
var fmerchantpassivebridgeview, currentPageID;
loadjs.ready("head", function() {

	// Form object
	currentPageID = ew.PAGE_ID = "view";
	fmerchantpassivebridgeview = currentForm = new ew.Form("fmerchantpassivebridgeview", "view");
	loadjs.done("fmerchantpassivebridgeview");
});
</script>
<script>
loadjs.ready("head", function() {

	// Client script
	// Write your client script here, no need to add script tags.

});
</script>
<?php } ?>
<?php if (!$merchantpassivebridge_view->isExport()) { ?>
<div class="btn-toolbar ew-toolbar">
<?php $merchantpassivebridge_view->ExportOptions->render("body") ?>
<?php $merchantpassivebridge_view->OtherOptions->render("body") ?>
<div class="clearfix"></div>
</div>
<?php } ?>
<?php $merchantpassivebridge_view->showPageHeader(); ?>
<?php
$merchantpassivebridge_view->showMessage();
?>
<form name="fmerchantpassivebridgeview" id="fmerchantpassivebridgeview" class="form-inline ew-form ew-view-form" action="<?php echo CurrentPageName() ?>" method="post">
<?php if ($Page->CheckToken) { ?>
<input type="hidden" name="<?php echo Config("TOKEN_NAME") ?>" value="<?php echo $Page->Token ?>">
<?php } ?>
<input type="hidden" name="t" value="merchantpassivebridge">
<input type="hidden" name="modal" value="<?php echo (int)$merchantpassivebridge_view->IsModal ?>">
<table class="table table-striped table-sm ew-view-table">
<?php if ($merchantpassivebridge_view->merchantid->Visible) { // merchantid ?>
	<tr id="r_merchantid">
		<td class="<?php echo $merchantpassivebridge_view->TableLeftColumnClass ?>"><span id="elh_merchantpassivebridge_merchantid"><?php echo $merchantpassivebridge_view->merchantid->caption() ?></span></td>
		<td data-name="merchantid" <?php echo $merchantpassivebridge_view->merchantid->cellAttributes() ?>>
<span id="el_merchantpassivebridge_merchantid">
<span<?php echo $merchantpassivebridge_view->merchantid->viewAttributes() ?>><?php echo $merchantpassivebridge_view->merchantid->getViewValue() ?></span>
</span>
</td>
	</tr>
<?php } ?>
<?php if ($merchantpassivebridge_view->bridgeid->Visible) { // bridgeid ?>
	<tr id="r_bridgeid">
		<td class="<?php echo $merchantpassivebridge_view->TableLeftColumnClass ?>"><span id="elh_merchantpassivebridge_bridgeid"><?php echo $merchantpassivebridge_view->bridgeid->caption() ?></span></td>
		<td data-name="bridgeid" <?php echo $merchantpassivebridge_view->bridgeid->cellAttributes() ?>>
<span id="el_merchantpassivebridge_bridgeid">
<span<?php echo $merchantpassivebridge_view->bridgeid->viewAttributes() ?>><?php echo $merchantpassivebridge_view->bridgeid->getViewValue() ?></span>
</span>
</td>
	</tr>
<?php } ?>
<?php if ($merchantpassivebridge_view->bridgetxid->Visible) { // bridgetxid ?>
	<tr id="r_bridgetxid">
		<td class="<?php echo $merchantpassivebridge_view->TableLeftColumnClass ?>"><span id="elh_merchantpassivebridge_bridgetxid"><?php echo $merchantpassivebridge_view->bridgetxid->caption() ?></span></td>
		<td data-name="bridgetxid" <?php echo $merchantpassivebridge_view->bridgetxid->cellAttributes() ?>>
<span id="el_merchantpassivebridge_bridgetxid">
<span<?php echo $merchantpassivebridge_view->bridgetxid->viewAttributes() ?>><?php echo $merchantpassivebridge_view->bridgetxid->getViewValue() ?></span>
</span>
</td>
	</tr>
<?php } ?>
<?php if ($merchantpassivebridge_view->friendlyname->Visible) { // friendlyname ?>
	<tr id="r_friendlyname">
		<td class="<?php echo $merchantpassivebridge_view->TableLeftColumnClass ?>"><span id="elh_merchantpassivebridge_friendlyname"><?php echo $merchantpassivebridge_view->friendlyname->caption() ?></span></td>
		<td data-name="friendlyname" <?php echo $merchantpassivebridge_view->friendlyname->cellAttributes() ?>>
<span id="el_merchantpassivebridge_friendlyname">
<span<?php echo $merchantpassivebridge_view->friendlyname->viewAttributes() ?>><?php echo $merchantpassivebridge_view->friendlyname->getViewValue() ?></span>
</span>
</td>
	</tr>
<?php } ?>
<?php if ($merchantpassivebridge_view->status->Visible) { // status ?>
	<tr id="r_status">
		<td class="<?php echo $merchantpassivebridge_view->TableLeftColumnClass ?>"><span id="elh_merchantpassivebridge_status"><?php echo $merchantpassivebridge_view->status->caption() ?></span></td>
		<td data-name="status" <?php echo $merchantpassivebridge_view->status->cellAttributes() ?>>
<span id="el_merchantpassivebridge_status">
<span<?php echo $merchantpassivebridge_view->status->viewAttributes() ?>><?php echo $merchantpassivebridge_view->status->getViewValue() ?></span>
</span>
</td>
	</tr>
<?php } ?>
<?php if ($merchantpassivebridge_view->lastupdatedate->Visible) { // lastupdatedate ?>
	<tr id="r_lastupdatedate">
		<td class="<?php echo $merchantpassivebridge_view->TableLeftColumnClass ?>"><span id="elh_merchantpassivebridge_lastupdatedate"><?php echo $merchantpassivebridge_view->lastupdatedate->caption() ?></span></td>
		<td data-name="lastupdatedate" <?php echo $merchantpassivebridge_view->lastupdatedate->cellAttributes() ?>>
<span id="el_merchantpassivebridge_lastupdatedate">
<span<?php echo $merchantpassivebridge_view->lastupdatedate->viewAttributes() ?>><?php echo $merchantpassivebridge_view->lastupdatedate->getViewValue() ?></span>
</span>
</td>
	</tr>
<?php } ?>
<?php if ($merchantpassivebridge_view->_userid->Visible) { // userid ?>
	<tr id="r__userid">
		<td class="<?php echo $merchantpassivebridge_view->TableLeftColumnClass ?>"><span id="elh_merchantpassivebridge__userid"><?php echo $merchantpassivebridge_view->_userid->caption() ?></span></td>
		<td data-name="_userid" <?php echo $merchantpassivebridge_view->_userid->cellAttributes() ?>>
<span id="el_merchantpassivebridge__userid">
<span<?php echo $merchantpassivebridge_view->_userid->viewAttributes() ?>><?php echo $merchantpassivebridge_view->_userid->getViewValue() ?></span>
</span>
</td>
	</tr>
<?php } ?>
</table>
</form>
<?php
$merchantpassivebridge_view->showPageFooter();
if (Config("DEBUG"))
	echo GetDebugMessage();
?>
<?php if (!$merchantpassivebridge_view->isExport()) { ?>
<script>
loadjs.ready("load", function() {

	// Startup script
	// Write your table-specific startup script here
	// console.log("page loaded");

});
</script>
<?php } ?>
<?php include_once "footer.php"; ?>
<?php
$merchantpassivebridge_view->terminate();
?>