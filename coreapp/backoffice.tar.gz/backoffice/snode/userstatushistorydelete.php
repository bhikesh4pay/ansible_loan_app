<?php
namespace PHPMaker2020\_4payadmin;

// Autoload
include_once "autoload.php";

// Session
if (session_status() !== PHP_SESSION_ACTIVE)
	\Delight\Cookie\Session::start(Config("COOKIE_SAMESITE")); // Init session data

// Output buffering
ob_start();
?>
<?php

// Write header
WriteHeader(FALSE);

// Create page object
$userstatushistory_delete = new userstatushistory_delete();

// Run the page
$userstatushistory_delete->run();

// Setup login status
SetupLoginStatus();
SetClientVar("login", LoginStatus());

// Global Page Rendering event (in userfn*.php)
Page_Rendering();

// Page Rendering event
$userstatushistory_delete->Page_Render();
?>
<?php include_once "header.php"; ?>
<script>
var fuserstatushistorydelete, currentPageID;
loadjs.ready("head", function() {

	// Form object
	currentPageID = ew.PAGE_ID = "delete";
	fuserstatushistorydelete = currentForm = new ew.Form("fuserstatushistorydelete", "delete");
	loadjs.done("fuserstatushistorydelete");
});
</script>
<script>
loadjs.ready("head", function() {

	// Client script
	// Write your client script here, no need to add script tags.

});
</script>
<?php $userstatushistory_delete->showPageHeader(); ?>
<?php
$userstatushistory_delete->showMessage();
?>
<form name="fuserstatushistorydelete" id="fuserstatushistorydelete" class="form-inline ew-form ew-delete-form" action="<?php echo CurrentPageName() ?>" method="post">
<?php if ($Page->CheckToken) { ?>
<input type="hidden" name="<?php echo Config("TOKEN_NAME") ?>" value="<?php echo $Page->Token ?>">
<?php } ?>
<input type="hidden" name="t" value="userstatushistory">
<input type="hidden" name="action" id="action" value="delete">
<?php foreach ($userstatushistory_delete->RecKeys as $key) { ?>
<?php $keyvalue = is_array($key) ? implode(Config("COMPOSITE_KEY_SEPARATOR"), $key) : $key; ?>
<input type="hidden" name="key_m[]" value="<?php echo HtmlEncode($keyvalue) ?>">
<?php } ?>
<div class="card ew-card ew-grid">
<div class="<?php echo ResponsiveTableClass() ?>card-body ew-grid-middle-panel">
<table class="table ew-table">
	<thead>
	<tr class="ew-table-header">
<?php if ($userstatushistory_delete->changeid->Visible) { // changeid ?>
		<th class="<?php echo $userstatushistory_delete->changeid->headerCellClass() ?>"><span id="elh_userstatushistory_changeid" class="userstatushistory_changeid"><?php echo $userstatushistory_delete->changeid->caption() ?></span></th>
<?php } ?>
<?php if ($userstatushistory_delete->_userid->Visible) { // userid ?>
		<th class="<?php echo $userstatushistory_delete->_userid->headerCellClass() ?>"><span id="elh_userstatushistory__userid" class="userstatushistory__userid"><?php echo $userstatushistory_delete->_userid->caption() ?></span></th>
<?php } ?>
<?php if ($userstatushistory_delete->oldstatus->Visible) { // oldstatus ?>
		<th class="<?php echo $userstatushistory_delete->oldstatus->headerCellClass() ?>"><span id="elh_userstatushistory_oldstatus" class="userstatushistory_oldstatus"><?php echo $userstatushistory_delete->oldstatus->caption() ?></span></th>
<?php } ?>
<?php if ($userstatushistory_delete->newstatus->Visible) { // newstatus ?>
		<th class="<?php echo $userstatushistory_delete->newstatus->headerCellClass() ?>"><span id="elh_userstatushistory_newstatus" class="userstatushistory_newstatus"><?php echo $userstatushistory_delete->newstatus->caption() ?></span></th>
<?php } ?>
<?php if ($userstatushistory_delete->changetime->Visible) { // changetime ?>
		<th class="<?php echo $userstatushistory_delete->changetime->headerCellClass() ?>"><span id="elh_userstatushistory_changetime" class="userstatushistory_changetime"><?php echo $userstatushistory_delete->changetime->caption() ?></span></th>
<?php } ?>
	</tr>
	</thead>
	<tbody>
<?php
$userstatushistory_delete->RecordCount = 0;
$i = 0;
while (!$userstatushistory_delete->Recordset->EOF) {
	$userstatushistory_delete->RecordCount++;
	$userstatushistory_delete->RowCount++;

	// Set row properties
	$userstatushistory->resetAttributes();
	$userstatushistory->RowType = ROWTYPE_VIEW; // View

	// Get the field contents
	$userstatushistory_delete->loadRowValues($userstatushistory_delete->Recordset);

	// Render row
	$userstatushistory_delete->renderRow();
?>
	<tr <?php echo $userstatushistory->rowAttributes() ?>>
<?php if ($userstatushistory_delete->changeid->Visible) { // changeid ?>
		<td <?php echo $userstatushistory_delete->changeid->cellAttributes() ?>>
<span id="el<?php echo $userstatushistory_delete->RowCount ?>_userstatushistory_changeid" class="userstatushistory_changeid">
<span<?php echo $userstatushistory_delete->changeid->viewAttributes() ?>><?php echo $userstatushistory_delete->changeid->getViewValue() ?></span>
</span>
</td>
<?php } ?>
<?php if ($userstatushistory_delete->_userid->Visible) { // userid ?>
		<td <?php echo $userstatushistory_delete->_userid->cellAttributes() ?>>
<span id="el<?php echo $userstatushistory_delete->RowCount ?>_userstatushistory__userid" class="userstatushistory__userid">
<span<?php echo $userstatushistory_delete->_userid->viewAttributes() ?>><?php echo $userstatushistory_delete->_userid->getViewValue() ?></span>
</span>
</td>
<?php } ?>
<?php if ($userstatushistory_delete->oldstatus->Visible) { // oldstatus ?>
		<td <?php echo $userstatushistory_delete->oldstatus->cellAttributes() ?>>
<span id="el<?php echo $userstatushistory_delete->RowCount ?>_userstatushistory_oldstatus" class="userstatushistory_oldstatus">
<span<?php echo $userstatushistory_delete->oldstatus->viewAttributes() ?>><?php echo $userstatushistory_delete->oldstatus->getViewValue() ?></span>
</span>
</td>
<?php } ?>
<?php if ($userstatushistory_delete->newstatus->Visible) { // newstatus ?>
		<td <?php echo $userstatushistory_delete->newstatus->cellAttributes() ?>>
<span id="el<?php echo $userstatushistory_delete->RowCount ?>_userstatushistory_newstatus" class="userstatushistory_newstatus">
<span<?php echo $userstatushistory_delete->newstatus->viewAttributes() ?>><?php echo $userstatushistory_delete->newstatus->getViewValue() ?></span>
</span>
</td>
<?php } ?>
<?php if ($userstatushistory_delete->changetime->Visible) { // changetime ?>
		<td <?php echo $userstatushistory_delete->changetime->cellAttributes() ?>>
<span id="el<?php echo $userstatushistory_delete->RowCount ?>_userstatushistory_changetime" class="userstatushistory_changetime">
<span<?php echo $userstatushistory_delete->changetime->viewAttributes() ?>><?php echo $userstatushistory_delete->changetime->getViewValue() ?></span>
</span>
</td>
<?php } ?>
	</tr>
<?php
	$userstatushistory_delete->Recordset->moveNext();
}
$userstatushistory_delete->Recordset->close();
?>
</tbody>
</table>
</div>
</div>
<div>
<button class="btn btn-primary ew-btn" name="btn-action" id="btn-action" type="submit"><?php echo $Language->phrase("DeleteBtn") ?></button>
<button class="btn btn-default ew-btn" name="btn-cancel" id="btn-cancel" type="button" data-href="<?php echo $userstatushistory_delete->getReturnUrl() ?>"><?php echo $Language->phrase("CancelBtn") ?></button>
</div>
</form>
<?php
$userstatushistory_delete->showPageFooter();
if (Config("DEBUG"))
	echo GetDebugMessage();
?>
<script>
loadjs.ready("load", function() {

	// Startup script
	// Write your table-specific startup script here
	// console.log("page loaded");

});
</script>
<?php include_once "footer.php"; ?>
<?php
$userstatushistory_delete->terminate();
?>