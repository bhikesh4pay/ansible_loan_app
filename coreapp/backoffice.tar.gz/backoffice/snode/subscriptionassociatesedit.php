<?php
namespace PHPMaker2020\_4payadmin;

// Autoload
include_once "autoload.php";

// Session
if (session_status() !== PHP_SESSION_ACTIVE)
	\Delight\Cookie\Session::start(Config("COOKIE_SAMESITE")); // Init session data

// Output buffering
ob_start();
?>
<?php

// Write header
WriteHeader(FALSE);

// Create page object
$subscriptionassociates_edit = new subscriptionassociates_edit();

// Run the page
$subscriptionassociates_edit->run();

// Setup login status
SetupLoginStatus();
SetClientVar("login", LoginStatus());

// Global Page Rendering event (in userfn*.php)
Page_Rendering();

// Page Rendering event
$subscriptionassociates_edit->Page_Render();
?>
<?php include_once "header.php"; ?>
<script>
var fsubscriptionassociatesedit, currentPageID;
loadjs.ready("head", function() {

	// Form object
	currentPageID = ew.PAGE_ID = "edit";
	fsubscriptionassociatesedit = currentForm = new ew.Form("fsubscriptionassociatesedit", "edit");

	// Validate form
	fsubscriptionassociatesedit.validate = function() {
		if (!this.validateRequired)
			return true; // Ignore validation
		var $ = jQuery, fobj = this.getForm(), $fobj = $(fobj);
		if ($fobj.find("#confirm").val() == "confirm")
			return true;
		var elm, felm, uelm, addcnt = 0;
		var $k = $fobj.find("#" + this.formKeyCountName); // Get key_count
		var rowcnt = ($k[0]) ? parseInt($k.val(), 10) : 1;
		var startcnt = (rowcnt == 0) ? 0 : 1; // Check rowcnt == 0 => Inline-Add
		var gridinsert = ["insert", "gridinsert"].includes($fobj.find("#action").val()) && $k[0];
		for (var i = startcnt; i <= rowcnt; i++) {
			var infix = ($k[0]) ? String(i) : "";
			$fobj.data("rowindex", infix);
			<?php if ($subscriptionassociates_edit->associationid->Required) { ?>
				elm = this.getElements("x" + infix + "_associationid");
				if (elm && !ew.isHidden(elm) && !ew.hasValue(elm))
					return this.onError(elm, "<?php echo JsEncode(str_replace("%s", $subscriptionassociates_edit->associationid->caption(), $subscriptionassociates_edit->associationid->RequiredErrorMessage)) ?>");
			<?php } ?>
			<?php if ($subscriptionassociates_edit->subscriptionplanid->Required) { ?>
				elm = this.getElements("x" + infix + "_subscriptionplanid");
				if (elm && !ew.isHidden(elm) && !ew.hasValue(elm))
					return this.onError(elm, "<?php echo JsEncode(str_replace("%s", $subscriptionassociates_edit->subscriptionplanid->caption(), $subscriptionassociates_edit->subscriptionplanid->RequiredErrorMessage)) ?>");
			<?php } ?>
				elm = this.getElements("x" + infix + "_subscriptionplanid");
				if (elm && !ew.checkInteger(elm.value))
					return this.onError(elm, "<?php echo JsEncode($subscriptionassociates_edit->subscriptionplanid->errorMessage()) ?>");
			<?php if ($subscriptionassociates_edit->groupid->Required) { ?>
				elm = this.getElements("x" + infix + "_groupid");
				if (elm && !ew.isHidden(elm) && !ew.hasValue(elm))
					return this.onError(elm, "<?php echo JsEncode(str_replace("%s", $subscriptionassociates_edit->groupid->caption(), $subscriptionassociates_edit->groupid->RequiredErrorMessage)) ?>");
			<?php } ?>
				elm = this.getElements("x" + infix + "_groupid");
				if (elm && !ew.checkInteger(elm.value))
					return this.onError(elm, "<?php echo JsEncode($subscriptionassociates_edit->groupid->errorMessage()) ?>");
			<?php if ($subscriptionassociates_edit->_userid->Required) { ?>
				elm = this.getElements("x" + infix + "__userid");
				if (elm && !ew.isHidden(elm) && !ew.hasValue(elm))
					return this.onError(elm, "<?php echo JsEncode(str_replace("%s", $subscriptionassociates_edit->_userid->caption(), $subscriptionassociates_edit->_userid->RequiredErrorMessage)) ?>");
			<?php } ?>
				elm = this.getElements("x" + infix + "__userid");
				if (elm && !ew.checkInteger(elm.value))
					return this.onError(elm, "<?php echo JsEncode($subscriptionassociates_edit->_userid->errorMessage()) ?>");
			<?php if ($subscriptionassociates_edit->firstname->Required) { ?>
				elm = this.getElements("x" + infix + "_firstname");
				if (elm && !ew.isHidden(elm) && !ew.hasValue(elm))
					return this.onError(elm, "<?php echo JsEncode(str_replace("%s", $subscriptionassociates_edit->firstname->caption(), $subscriptionassociates_edit->firstname->RequiredErrorMessage)) ?>");
			<?php } ?>
			<?php if ($subscriptionassociates_edit->lastname->Required) { ?>
				elm = this.getElements("x" + infix + "_lastname");
				if (elm && !ew.isHidden(elm) && !ew.hasValue(elm))
					return this.onError(elm, "<?php echo JsEncode(str_replace("%s", $subscriptionassociates_edit->lastname->caption(), $subscriptionassociates_edit->lastname->RequiredErrorMessage)) ?>");
			<?php } ?>
			<?php if ($subscriptionassociates_edit->notes->Required) { ?>
				elm = this.getElements("x" + infix + "_notes");
				if (elm && !ew.isHidden(elm) && !ew.hasValue(elm))
					return this.onError(elm, "<?php echo JsEncode(str_replace("%s", $subscriptionassociates_edit->notes->caption(), $subscriptionassociates_edit->notes->RequiredErrorMessage)) ?>");
			<?php } ?>
			<?php if ($subscriptionassociates_edit->lastupdatedate->Required) { ?>
				elm = this.getElements("x" + infix + "_lastupdatedate");
				if (elm && !ew.isHidden(elm) && !ew.hasValue(elm))
					return this.onError(elm, "<?php echo JsEncode(str_replace("%s", $subscriptionassociates_edit->lastupdatedate->caption(), $subscriptionassociates_edit->lastupdatedate->RequiredErrorMessage)) ?>");
			<?php } ?>
				elm = this.getElements("x" + infix + "_lastupdatedate");
				if (elm && !ew.checkDateDef(elm.value))
					return this.onError(elm, "<?php echo JsEncode($subscriptionassociates_edit->lastupdatedate->errorMessage()) ?>");

				// Call Form_CustomValidate event
				if (!this.Form_CustomValidate(fobj))
					return false;
		}

		// Process detail forms
		var dfs = $fobj.find("input[name='detailpage']").get();
		for (var i = 0; i < dfs.length; i++) {
			var df = dfs[i], val = df.value;
			if (val && ew.forms[val])
				if (!ew.forms[val].validate())
					return false;
		}
		return true;
	}

	// Form_CustomValidate
	fsubscriptionassociatesedit.Form_CustomValidate = function(fobj) { // DO NOT CHANGE THIS LINE!

		// Your custom validation code here, return false if invalid.
		return true;
	}

	// Use JavaScript validation or not
	fsubscriptionassociatesedit.validateRequired = <?php echo Config("CLIENT_VALIDATE") ? "true" : "false" ?>;

	// Dynamic selection lists
	loadjs.done("fsubscriptionassociatesedit");
});
</script>
<script>
loadjs.ready("head", function() {

	// Client script
	// Write your client script here, no need to add script tags.

});
</script>
<?php $subscriptionassociates_edit->showPageHeader(); ?>
<?php
$subscriptionassociates_edit->showMessage();
?>
<form name="fsubscriptionassociatesedit" id="fsubscriptionassociatesedit" class="<?php echo $subscriptionassociates_edit->FormClassName ?>" action="<?php echo CurrentPageName() ?>" method="post">
<?php if ($Page->CheckToken) { ?>
<input type="hidden" name="<?php echo Config("TOKEN_NAME") ?>" value="<?php echo $Page->Token ?>">
<?php } ?>
<input type="hidden" name="t" value="subscriptionassociates">
<input type="hidden" name="action" id="action" value="update">
<input type="hidden" name="modal" value="<?php echo (int)$subscriptionassociates_edit->IsModal ?>">
<div class="ew-edit-div"><!-- page* -->
<?php if ($subscriptionassociates_edit->associationid->Visible) { // associationid ?>
	<div id="r_associationid" class="form-group row">
		<label id="elh_subscriptionassociates_associationid" class="<?php echo $subscriptionassociates_edit->LeftColumnClass ?>"><?php echo $subscriptionassociates_edit->associationid->caption() ?><?php echo $subscriptionassociates_edit->associationid->Required ? $Language->phrase("FieldRequiredIndicator") : "" ?></label>
		<div class="<?php echo $subscriptionassociates_edit->RightColumnClass ?>"><div <?php echo $subscriptionassociates_edit->associationid->cellAttributes() ?>>
<span id="el_subscriptionassociates_associationid">
<span<?php echo $subscriptionassociates_edit->associationid->viewAttributes() ?>><input type="text" readonly class="form-control-plaintext" value="<?php echo HtmlEncode(RemoveHtml($subscriptionassociates_edit->associationid->EditValue)) ?>"></span>
</span>
<input type="hidden" data-table="subscriptionassociates" data-field="x_associationid" name="x_associationid" id="x_associationid" value="<?php echo HtmlEncode($subscriptionassociates_edit->associationid->CurrentValue) ?>">
<?php echo $subscriptionassociates_edit->associationid->CustomMsg ?></div></div>
	</div>
<?php } ?>
<?php if ($subscriptionassociates_edit->subscriptionplanid->Visible) { // subscriptionplanid ?>
	<div id="r_subscriptionplanid" class="form-group row">
		<label id="elh_subscriptionassociates_subscriptionplanid" for="x_subscriptionplanid" class="<?php echo $subscriptionassociates_edit->LeftColumnClass ?>"><?php echo $subscriptionassociates_edit->subscriptionplanid->caption() ?><?php echo $subscriptionassociates_edit->subscriptionplanid->Required ? $Language->phrase("FieldRequiredIndicator") : "" ?></label>
		<div class="<?php echo $subscriptionassociates_edit->RightColumnClass ?>"><div <?php echo $subscriptionassociates_edit->subscriptionplanid->cellAttributes() ?>>
<span id="el_subscriptionassociates_subscriptionplanid">
<input type="text" data-table="subscriptionassociates" data-field="x_subscriptionplanid" name="x_subscriptionplanid" id="x_subscriptionplanid" size="30" placeholder="<?php echo HtmlEncode($subscriptionassociates_edit->subscriptionplanid->getPlaceHolder()) ?>" value="<?php echo $subscriptionassociates_edit->subscriptionplanid->EditValue ?>"<?php echo $subscriptionassociates_edit->subscriptionplanid->editAttributes() ?>>
</span>
<?php echo $subscriptionassociates_edit->subscriptionplanid->CustomMsg ?></div></div>
	</div>
<?php } ?>
<?php if ($subscriptionassociates_edit->groupid->Visible) { // groupid ?>
	<div id="r_groupid" class="form-group row">
		<label id="elh_subscriptionassociates_groupid" for="x_groupid" class="<?php echo $subscriptionassociates_edit->LeftColumnClass ?>"><?php echo $subscriptionassociates_edit->groupid->caption() ?><?php echo $subscriptionassociates_edit->groupid->Required ? $Language->phrase("FieldRequiredIndicator") : "" ?></label>
		<div class="<?php echo $subscriptionassociates_edit->RightColumnClass ?>"><div <?php echo $subscriptionassociates_edit->groupid->cellAttributes() ?>>
<span id="el_subscriptionassociates_groupid">
<input type="text" data-table="subscriptionassociates" data-field="x_groupid" name="x_groupid" id="x_groupid" size="30" placeholder="<?php echo HtmlEncode($subscriptionassociates_edit->groupid->getPlaceHolder()) ?>" value="<?php echo $subscriptionassociates_edit->groupid->EditValue ?>"<?php echo $subscriptionassociates_edit->groupid->editAttributes() ?>>
</span>
<?php echo $subscriptionassociates_edit->groupid->CustomMsg ?></div></div>
	</div>
<?php } ?>
<?php if ($subscriptionassociates_edit->_userid->Visible) { // userid ?>
	<div id="r__userid" class="form-group row">
		<label id="elh_subscriptionassociates__userid" for="x__userid" class="<?php echo $subscriptionassociates_edit->LeftColumnClass ?>"><?php echo $subscriptionassociates_edit->_userid->caption() ?><?php echo $subscriptionassociates_edit->_userid->Required ? $Language->phrase("FieldRequiredIndicator") : "" ?></label>
		<div class="<?php echo $subscriptionassociates_edit->RightColumnClass ?>"><div <?php echo $subscriptionassociates_edit->_userid->cellAttributes() ?>>
<span id="el_subscriptionassociates__userid">
<input type="text" data-table="subscriptionassociates" data-field="x__userid" name="x__userid" id="x__userid" size="30" placeholder="<?php echo HtmlEncode($subscriptionassociates_edit->_userid->getPlaceHolder()) ?>" value="<?php echo $subscriptionassociates_edit->_userid->EditValue ?>"<?php echo $subscriptionassociates_edit->_userid->editAttributes() ?>>
</span>
<?php echo $subscriptionassociates_edit->_userid->CustomMsg ?></div></div>
	</div>
<?php } ?>
<?php if ($subscriptionassociates_edit->firstname->Visible) { // firstname ?>
	<div id="r_firstname" class="form-group row">
		<label id="elh_subscriptionassociates_firstname" for="x_firstname" class="<?php echo $subscriptionassociates_edit->LeftColumnClass ?>"><?php echo $subscriptionassociates_edit->firstname->caption() ?><?php echo $subscriptionassociates_edit->firstname->Required ? $Language->phrase("FieldRequiredIndicator") : "" ?></label>
		<div class="<?php echo $subscriptionassociates_edit->RightColumnClass ?>"><div <?php echo $subscriptionassociates_edit->firstname->cellAttributes() ?>>
<span id="el_subscriptionassociates_firstname">
<input type="text" data-table="subscriptionassociates" data-field="x_firstname" name="x_firstname" id="x_firstname" size="30" maxlength="30" placeholder="<?php echo HtmlEncode($subscriptionassociates_edit->firstname->getPlaceHolder()) ?>" value="<?php echo $subscriptionassociates_edit->firstname->EditValue ?>"<?php echo $subscriptionassociates_edit->firstname->editAttributes() ?>>
</span>
<?php echo $subscriptionassociates_edit->firstname->CustomMsg ?></div></div>
	</div>
<?php } ?>
<?php if ($subscriptionassociates_edit->lastname->Visible) { // lastname ?>
	<div id="r_lastname" class="form-group row">
		<label id="elh_subscriptionassociates_lastname" for="x_lastname" class="<?php echo $subscriptionassociates_edit->LeftColumnClass ?>"><?php echo $subscriptionassociates_edit->lastname->caption() ?><?php echo $subscriptionassociates_edit->lastname->Required ? $Language->phrase("FieldRequiredIndicator") : "" ?></label>
		<div class="<?php echo $subscriptionassociates_edit->RightColumnClass ?>"><div <?php echo $subscriptionassociates_edit->lastname->cellAttributes() ?>>
<span id="el_subscriptionassociates_lastname">
<input type="text" data-table="subscriptionassociates" data-field="x_lastname" name="x_lastname" id="x_lastname" size="30" maxlength="30" placeholder="<?php echo HtmlEncode($subscriptionassociates_edit->lastname->getPlaceHolder()) ?>" value="<?php echo $subscriptionassociates_edit->lastname->EditValue ?>"<?php echo $subscriptionassociates_edit->lastname->editAttributes() ?>>
</span>
<?php echo $subscriptionassociates_edit->lastname->CustomMsg ?></div></div>
	</div>
<?php } ?>
<?php if ($subscriptionassociates_edit->notes->Visible) { // notes ?>
	<div id="r_notes" class="form-group row">
		<label id="elh_subscriptionassociates_notes" for="x_notes" class="<?php echo $subscriptionassociates_edit->LeftColumnClass ?>"><?php echo $subscriptionassociates_edit->notes->caption() ?><?php echo $subscriptionassociates_edit->notes->Required ? $Language->phrase("FieldRequiredIndicator") : "" ?></label>
		<div class="<?php echo $subscriptionassociates_edit->RightColumnClass ?>"><div <?php echo $subscriptionassociates_edit->notes->cellAttributes() ?>>
<span id="el_subscriptionassociates_notes">
<input type="text" data-table="subscriptionassociates" data-field="x_notes" name="x_notes" id="x_notes" size="30" maxlength="30" placeholder="<?php echo HtmlEncode($subscriptionassociates_edit->notes->getPlaceHolder()) ?>" value="<?php echo $subscriptionassociates_edit->notes->EditValue ?>"<?php echo $subscriptionassociates_edit->notes->editAttributes() ?>>
</span>
<?php echo $subscriptionassociates_edit->notes->CustomMsg ?></div></div>
	</div>
<?php } ?>
<?php if ($subscriptionassociates_edit->lastupdatedate->Visible) { // lastupdatedate ?>
	<div id="r_lastupdatedate" class="form-group row">
		<label id="elh_subscriptionassociates_lastupdatedate" for="x_lastupdatedate" class="<?php echo $subscriptionassociates_edit->LeftColumnClass ?>"><?php echo $subscriptionassociates_edit->lastupdatedate->caption() ?><?php echo $subscriptionassociates_edit->lastupdatedate->Required ? $Language->phrase("FieldRequiredIndicator") : "" ?></label>
		<div class="<?php echo $subscriptionassociates_edit->RightColumnClass ?>"><div <?php echo $subscriptionassociates_edit->lastupdatedate->cellAttributes() ?>>
<span id="el_subscriptionassociates_lastupdatedate">
<input type="text" data-table="subscriptionassociates" data-field="x_lastupdatedate" name="x_lastupdatedate" id="x_lastupdatedate" placeholder="<?php echo HtmlEncode($subscriptionassociates_edit->lastupdatedate->getPlaceHolder()) ?>" value="<?php echo $subscriptionassociates_edit->lastupdatedate->EditValue ?>"<?php echo $subscriptionassociates_edit->lastupdatedate->editAttributes() ?>>
</span>
<?php echo $subscriptionassociates_edit->lastupdatedate->CustomMsg ?></div></div>
	</div>
<?php } ?>
</div><!-- /page* -->
<?php if (!$subscriptionassociates_edit->IsModal) { ?>
<div class="form-group row"><!-- buttons .form-group -->
	<div class="<?php echo $subscriptionassociates_edit->OffsetColumnClass ?>"><!-- buttons offset -->
<button class="btn btn-primary ew-btn" name="btn-action" id="btn-action" type="submit"><?php echo $Language->phrase("SaveBtn") ?></button>
<button class="btn btn-default ew-btn" name="btn-cancel" id="btn-cancel" type="button" data-href="<?php echo $subscriptionassociates_edit->getReturnUrl() ?>"><?php echo $Language->phrase("CancelBtn") ?></button>
	</div><!-- /buttons offset -->
</div><!-- /buttons .form-group -->
<?php } ?>
</form>
<?php
$subscriptionassociates_edit->showPageFooter();
if (Config("DEBUG"))
	echo GetDebugMessage();
?>
<script>
loadjs.ready("load", function() {

	// Startup script
	// Write your table-specific startup script here
	// console.log("page loaded");

});
</script>
<?php include_once "footer.php"; ?>
<?php
$subscriptionassociates_edit->terminate();
?>