<?php
namespace PHPMaker2020\_4payadmin;

// Autoload
include_once "autoload.php";

// Session
if (session_status() !== PHP_SESSION_ACTIVE)
	\Delight\Cookie\Session::start(Config("COOKIE_SAMESITE")); // Init session data

// Output buffering
ob_start();
?>
<?php

// Write header
WriteHeader(FALSE);

// Create page object
$user_list = new user_list();

// Run the page
$user_list->run();

// Setup login status
SetupLoginStatus();
SetClientVar("login", LoginStatus());

// Global Page Rendering event (in userfn*.php)
Page_Rendering();

// Page Rendering event
$user_list->Page_Render();
?>
<?php include_once "header.php"; ?>
<?php if (!$user_list->isExport()) { ?>
<script>
var fuserlist, currentPageID;
loadjs.ready("head", function() {

	// Form object
	currentPageID = ew.PAGE_ID = "list";
	fuserlist = currentForm = new ew.Form("fuserlist", "list");
	fuserlist.formKeyCountName = '<?php echo $user_list->FormKeyCountName ?>';
	loadjs.done("fuserlist");
});
var fuserlistsrch;
loadjs.ready("head", function() {

	// Form object for search
	fuserlistsrch = currentSearchForm = new ew.Form("fuserlistsrch");

	// Dynamic selection lists
	// Filters

	fuserlistsrch.filterList = <?php echo $user_list->getFilterList() ?>;
	loadjs.done("fuserlistsrch");
});
</script>
<style type="text/css">
.ew-table-preview-row { /* main table preview row color */
	background-color: #FFFFFF; /* preview row color */
}
.ew-table-preview-row .ew-grid {
	display: table;
}
</style>
<div id="ew-preview" class="d-none"><!-- preview -->
	<div class="ew-nav-tabs"><!-- .ew-nav-tabs -->
		<ul class="nav nav-tabs"></ul>
		<div class="tab-content"><!-- .tab-content -->
			<div class="tab-pane fade active show"></div>
		</div><!-- /.tab-content -->
	</div><!-- /.ew-nav-tabs -->
</div><!-- /preview -->
<script>
loadjs.ready("head", function() {
	ew.PREVIEW_PLACEMENT = ew.CSS_FLIP ? "right" : "left";
	ew.PREVIEW_SINGLE_ROW = false;
	ew.PREVIEW_OVERLAY = false;
	loadjs("js/ewpreview.js", "preview");
});
</script>
<script>
loadjs.ready("head", function() {

	// Client script
	// Write your client script here, no need to add script tags.

});
</script>
<?php } ?>
<?php if (!$user_list->isExport()) { ?>
<div class="btn-toolbar ew-toolbar">
<?php if ($user_list->TotalRecords > 0 && $user_list->ExportOptions->visible()) { ?>
<?php $user_list->ExportOptions->render("body") ?>
<?php } ?>
<?php if ($user_list->ImportOptions->visible()) { ?>
<?php $user_list->ImportOptions->render("body") ?>
<?php } ?>
<?php if ($user_list->SearchOptions->visible()) { ?>
<?php $user_list->SearchOptions->render("body") ?>
<?php } ?>
<?php if ($user_list->FilterOptions->visible()) { ?>
<?php $user_list->FilterOptions->render("body") ?>
<?php } ?>
<div class="clearfix"></div>
</div>
<?php } ?>
<?php
$user_list->renderOtherOptions();
?>
<?php if ($Security->CanSearch()) { ?>
<?php if (!$user_list->isExport() && !$user->CurrentAction) { ?>
<form name="fuserlistsrch" id="fuserlistsrch" class="form-inline ew-form ew-ext-search-form" action="<?php echo CurrentPageName() ?>">
<div id="fuserlistsrch-search-panel" class="<?php echo $user_list->SearchPanelClass ?>">
<input type="hidden" name="cmd" value="search">
<input type="hidden" name="t" value="user">
	<div class="ew-extended-search">
<div id="xsr_<?php echo $user_list->SearchRowCount + 1 ?>" class="ew-row d-sm-flex">
	<div class="ew-quick-search input-group">
		<input type="text" name="<?php echo Config("TABLE_BASIC_SEARCH") ?>" id="<?php echo Config("TABLE_BASIC_SEARCH") ?>" class="form-control" value="<?php echo HtmlEncode($user_list->BasicSearch->getKeyword()) ?>" placeholder="<?php echo HtmlEncode($Language->phrase("Search")) ?>">
		<input type="hidden" name="<?php echo Config("TABLE_BASIC_SEARCH_TYPE") ?>" id="<?php echo Config("TABLE_BASIC_SEARCH_TYPE") ?>" value="<?php echo HtmlEncode($user_list->BasicSearch->getType()) ?>">
		<div class="input-group-append">
			<button class="btn btn-primary" name="btn-submit" id="btn-submit" type="submit"><?php echo $Language->phrase("SearchBtn") ?></button>
			<button type="button" data-toggle="dropdown" class="btn btn-primary dropdown-toggle dropdown-toggle-split" aria-haspopup="true" aria-expanded="false"><span id="searchtype"><?php echo $user_list->BasicSearch->getTypeNameShort() ?></span></button>
			<div class="dropdown-menu dropdown-menu-right">
				<a class="dropdown-item<?php if ($user_list->BasicSearch->getType() == "") { ?> active<?php } ?>" href="#" onclick="return ew.setSearchType(this);"><?php echo $Language->phrase("QuickSearchAuto") ?></a>
				<a class="dropdown-item<?php if ($user_list->BasicSearch->getType() == "=") { ?> active<?php } ?>" href="#" onclick="return ew.setSearchType(this, '=');"><?php echo $Language->phrase("QuickSearchExact") ?></a>
				<a class="dropdown-item<?php if ($user_list->BasicSearch->getType() == "AND") { ?> active<?php } ?>" href="#" onclick="return ew.setSearchType(this, 'AND');"><?php echo $Language->phrase("QuickSearchAll") ?></a>
				<a class="dropdown-item<?php if ($user_list->BasicSearch->getType() == "OR") { ?> active<?php } ?>" href="#" onclick="return ew.setSearchType(this, 'OR');"><?php echo $Language->phrase("QuickSearchAny") ?></a>
			</div>
		</div>
	</div>
</div>
	</div><!-- /.ew-extended-search -->
</div><!-- /.ew-search-panel -->
</form>
<?php } ?>
<?php } ?>
<?php $user_list->showPageHeader(); ?>
<?php
$user_list->showMessage();
?>
<?php if ($user_list->TotalRecords > 0 || $user->CurrentAction) { ?>
<div class="card ew-card ew-grid<?php if ($user_list->isAddOrEdit()) { ?> ew-grid-add-edit<?php } ?> user">
<form name="fuserlist" id="fuserlist" class="form-inline ew-form ew-list-form" action="<?php echo CurrentPageName() ?>" method="post">
<?php if ($Page->CheckToken) { ?>
<input type="hidden" name="<?php echo Config("TOKEN_NAME") ?>" value="<?php echo $Page->Token ?>">
<?php } ?>
<input type="hidden" name="t" value="user">
<div id="gmp_user" class="<?php echo ResponsiveTableClass() ?>card-body ew-grid-middle-panel">
<?php if ($user_list->TotalRecords > 0 || $user_list->isGridEdit()) { ?>
<table id="tbl_userlist" class="table ew-table"><!-- .ew-table -->
<thead>
	<tr class="ew-table-header">
<?php

// Header row
$user->RowType = ROWTYPE_HEADER;

// Render list options
$user_list->renderListOptions();

// Render list options (header, left)
$user_list->ListOptions->render("header", "left");
?>
<?php if ($user_list->id->Visible) { // id ?>
	<?php if ($user_list->SortUrl($user_list->id) == "") { ?>
		<th data-name="id" class="<?php echo $user_list->id->headerCellClass() ?>"><div id="elh_user_id" class="user_id"><div class="ew-table-header-caption"><?php echo $user_list->id->caption() ?></div></div></th>
	<?php } else { ?>
		<th data-name="id" class="<?php echo $user_list->id->headerCellClass() ?>"><div class="ew-pointer" onclick="ew.sort(event, '<?php echo $user_list->SortUrl($user_list->id) ?>', 1);"><div id="elh_user_id" class="user_id">
			<div class="ew-table-header-btn"><span class="ew-table-header-caption"><?php echo $user_list->id->caption() ?></span><span class="ew-table-header-sort"><?php if ($user_list->id->getSort() == "ASC") { ?><i class="fas fa-sort-up"></i><?php } elseif ($user_list->id->getSort() == "DESC") { ?><i class="fas fa-sort-down"></i><?php } ?></span></div>
		</div></div></th>
	<?php } ?>
<?php } ?>
<?php if ($user_list->firstName->Visible) { // firstName ?>
	<?php if ($user_list->SortUrl($user_list->firstName) == "") { ?>
		<th data-name="firstName" class="<?php echo $user_list->firstName->headerCellClass() ?>"><div id="elh_user_firstName" class="user_firstName"><div class="ew-table-header-caption"><?php echo $user_list->firstName->caption() ?></div></div></th>
	<?php } else { ?>
		<th data-name="firstName" class="<?php echo $user_list->firstName->headerCellClass() ?>"><div class="ew-pointer" onclick="ew.sort(event, '<?php echo $user_list->SortUrl($user_list->firstName) ?>', 1);"><div id="elh_user_firstName" class="user_firstName">
			<div class="ew-table-header-btn"><span class="ew-table-header-caption"><?php echo $user_list->firstName->caption() ?><?php echo $Language->phrase("SrchLegend") ?></span><span class="ew-table-header-sort"><?php if ($user_list->firstName->getSort() == "ASC") { ?><i class="fas fa-sort-up"></i><?php } elseif ($user_list->firstName->getSort() == "DESC") { ?><i class="fas fa-sort-down"></i><?php } ?></span></div>
		</div></div></th>
	<?php } ?>
<?php } ?>
<?php if ($user_list->lastName->Visible) { // lastName ?>
	<?php if ($user_list->SortUrl($user_list->lastName) == "") { ?>
		<th data-name="lastName" class="<?php echo $user_list->lastName->headerCellClass() ?>"><div id="elh_user_lastName" class="user_lastName"><div class="ew-table-header-caption"><?php echo $user_list->lastName->caption() ?></div></div></th>
	<?php } else { ?>
		<th data-name="lastName" class="<?php echo $user_list->lastName->headerCellClass() ?>"><div class="ew-pointer" onclick="ew.sort(event, '<?php echo $user_list->SortUrl($user_list->lastName) ?>', 1);"><div id="elh_user_lastName" class="user_lastName">
			<div class="ew-table-header-btn"><span class="ew-table-header-caption"><?php echo $user_list->lastName->caption() ?><?php echo $Language->phrase("SrchLegend") ?></span><span class="ew-table-header-sort"><?php if ($user_list->lastName->getSort() == "ASC") { ?><i class="fas fa-sort-up"></i><?php } elseif ($user_list->lastName->getSort() == "DESC") { ?><i class="fas fa-sort-down"></i><?php } ?></span></div>
		</div></div></th>
	<?php } ?>
<?php } ?>
<?php if ($user_list->dateAdded->Visible) { // dateAdded ?>
	<?php if ($user_list->SortUrl($user_list->dateAdded) == "") { ?>
		<th data-name="dateAdded" class="<?php echo $user_list->dateAdded->headerCellClass() ?>"><div id="elh_user_dateAdded" class="user_dateAdded"><div class="ew-table-header-caption"><?php echo $user_list->dateAdded->caption() ?></div></div></th>
	<?php } else { ?>
		<th data-name="dateAdded" class="<?php echo $user_list->dateAdded->headerCellClass() ?>"><div class="ew-pointer" onclick="ew.sort(event, '<?php echo $user_list->SortUrl($user_list->dateAdded) ?>', 1);"><div id="elh_user_dateAdded" class="user_dateAdded">
			<div class="ew-table-header-btn"><span class="ew-table-header-caption"><?php echo $user_list->dateAdded->caption() ?></span><span class="ew-table-header-sort"><?php if ($user_list->dateAdded->getSort() == "ASC") { ?><i class="fas fa-sort-up"></i><?php } elseif ($user_list->dateAdded->getSort() == "DESC") { ?><i class="fas fa-sort-down"></i><?php } ?></span></div>
		</div></div></th>
	<?php } ?>
<?php } ?>
<?php if ($user_list->telephoneno->Visible) { // telephoneno ?>
	<?php if ($user_list->SortUrl($user_list->telephoneno) == "") { ?>
		<th data-name="telephoneno" class="<?php echo $user_list->telephoneno->headerCellClass() ?>"><div id="elh_user_telephoneno" class="user_telephoneno"><div class="ew-table-header-caption"><?php echo $user_list->telephoneno->caption() ?></div></div></th>
	<?php } else { ?>
		<th data-name="telephoneno" class="<?php echo $user_list->telephoneno->headerCellClass() ?>"><div class="ew-pointer" onclick="ew.sort(event, '<?php echo $user_list->SortUrl($user_list->telephoneno) ?>', 1);"><div id="elh_user_telephoneno" class="user_telephoneno">
			<div class="ew-table-header-btn"><span class="ew-table-header-caption"><?php echo $user_list->telephoneno->caption() ?><?php echo $Language->phrase("SrchLegend") ?></span><span class="ew-table-header-sort"><?php if ($user_list->telephoneno->getSort() == "ASC") { ?><i class="fas fa-sort-up"></i><?php } elseif ($user_list->telephoneno->getSort() == "DESC") { ?><i class="fas fa-sort-down"></i><?php } ?></span></div>
		</div></div></th>
	<?php } ?>
<?php } ?>
<?php if ($user_list->countryid->Visible) { // countryid ?>
	<?php if ($user_list->SortUrl($user_list->countryid) == "") { ?>
		<th data-name="countryid" class="<?php echo $user_list->countryid->headerCellClass() ?>"><div id="elh_user_countryid" class="user_countryid"><div class="ew-table-header-caption"><?php echo $user_list->countryid->caption() ?></div></div></th>
	<?php } else { ?>
		<th data-name="countryid" class="<?php echo $user_list->countryid->headerCellClass() ?>"><div class="ew-pointer" onclick="ew.sort(event, '<?php echo $user_list->SortUrl($user_list->countryid) ?>', 1);"><div id="elh_user_countryid" class="user_countryid">
			<div class="ew-table-header-btn"><span class="ew-table-header-caption"><?php echo $user_list->countryid->caption() ?></span><span class="ew-table-header-sort"><?php if ($user_list->countryid->getSort() == "ASC") { ?><i class="fas fa-sort-up"></i><?php } elseif ($user_list->countryid->getSort() == "DESC") { ?><i class="fas fa-sort-down"></i><?php } ?></span></div>
		</div></div></th>
	<?php } ?>
<?php } ?>
<?php if ($user_list->stateid->Visible) { // stateid ?>
	<?php if ($user_list->SortUrl($user_list->stateid) == "") { ?>
		<th data-name="stateid" class="<?php echo $user_list->stateid->headerCellClass() ?>"><div id="elh_user_stateid" class="user_stateid"><div class="ew-table-header-caption"><?php echo $user_list->stateid->caption() ?></div></div></th>
	<?php } else { ?>
		<th data-name="stateid" class="<?php echo $user_list->stateid->headerCellClass() ?>"><div class="ew-pointer" onclick="ew.sort(event, '<?php echo $user_list->SortUrl($user_list->stateid) ?>', 1);"><div id="elh_user_stateid" class="user_stateid">
			<div class="ew-table-header-btn"><span class="ew-table-header-caption"><?php echo $user_list->stateid->caption() ?></span><span class="ew-table-header-sort"><?php if ($user_list->stateid->getSort() == "ASC") { ?><i class="fas fa-sort-up"></i><?php } elseif ($user_list->stateid->getSort() == "DESC") { ?><i class="fas fa-sort-down"></i><?php } ?></span></div>
		</div></div></th>
	<?php } ?>
<?php } ?>
<?php if ($user_list->userType->Visible) { // userType ?>
	<?php if ($user_list->SortUrl($user_list->userType) == "") { ?>
		<th data-name="userType" class="<?php echo $user_list->userType->headerCellClass() ?>"><div id="elh_user_userType" class="user_userType"><div class="ew-table-header-caption"><?php echo $user_list->userType->caption() ?></div></div></th>
	<?php } else { ?>
		<th data-name="userType" class="<?php echo $user_list->userType->headerCellClass() ?>"><div class="ew-pointer" onclick="ew.sort(event, '<?php echo $user_list->SortUrl($user_list->userType) ?>', 1);"><div id="elh_user_userType" class="user_userType">
			<div class="ew-table-header-btn"><span class="ew-table-header-caption"><?php echo $user_list->userType->caption() ?></span><span class="ew-table-header-sort"><?php if ($user_list->userType->getSort() == "ASC") { ?><i class="fas fa-sort-up"></i><?php } elseif ($user_list->userType->getSort() == "DESC") { ?><i class="fas fa-sort-down"></i><?php } ?></span></div>
		</div></div></th>
	<?php } ?>
<?php } ?>
<?php if ($user_list->brokerid->Visible) { // brokerid ?>
	<?php if ($user_list->SortUrl($user_list->brokerid) == "") { ?>
		<th data-name="brokerid" class="<?php echo $user_list->brokerid->headerCellClass() ?>"><div id="elh_user_brokerid" class="user_brokerid"><div class="ew-table-header-caption"><?php echo $user_list->brokerid->caption() ?></div></div></th>
	<?php } else { ?>
		<th data-name="brokerid" class="<?php echo $user_list->brokerid->headerCellClass() ?>"><div class="ew-pointer" onclick="ew.sort(event, '<?php echo $user_list->SortUrl($user_list->brokerid) ?>', 1);"><div id="elh_user_brokerid" class="user_brokerid">
			<div class="ew-table-header-btn"><span class="ew-table-header-caption"><?php echo $user_list->brokerid->caption() ?></span><span class="ew-table-header-sort"><?php if ($user_list->brokerid->getSort() == "ASC") { ?><i class="fas fa-sort-up"></i><?php } elseif ($user_list->brokerid->getSort() == "DESC") { ?><i class="fas fa-sort-down"></i><?php } ?></span></div>
		</div></div></th>
	<?php } ?>
<?php } ?>
<?php if ($user_list->parentuserid->Visible) { // parentuserid ?>
	<?php if ($user_list->SortUrl($user_list->parentuserid) == "") { ?>
		<th data-name="parentuserid" class="<?php echo $user_list->parentuserid->headerCellClass() ?>"><div id="elh_user_parentuserid" class="user_parentuserid"><div class="ew-table-header-caption"><?php echo $user_list->parentuserid->caption() ?></div></div></th>
	<?php } else { ?>
		<th data-name="parentuserid" class="<?php echo $user_list->parentuserid->headerCellClass() ?>"><div class="ew-pointer" onclick="ew.sort(event, '<?php echo $user_list->SortUrl($user_list->parentuserid) ?>', 1);"><div id="elh_user_parentuserid" class="user_parentuserid">
			<div class="ew-table-header-btn"><span class="ew-table-header-caption"><?php echo $user_list->parentuserid->caption() ?></span><span class="ew-table-header-sort"><?php if ($user_list->parentuserid->getSort() == "ASC") { ?><i class="fas fa-sort-up"></i><?php } elseif ($user_list->parentuserid->getSort() == "DESC") { ?><i class="fas fa-sort-down"></i><?php } ?></span></div>
		</div></div></th>
	<?php } ?>
<?php } ?>
<?php if ($user_list->profilestatus->Visible) { // profilestatus ?>
	<?php if ($user_list->SortUrl($user_list->profilestatus) == "") { ?>
		<th data-name="profilestatus" class="<?php echo $user_list->profilestatus->headerCellClass() ?>"><div id="elh_user_profilestatus" class="user_profilestatus"><div class="ew-table-header-caption"><?php echo $user_list->profilestatus->caption() ?></div></div></th>
	<?php } else { ?>
		<th data-name="profilestatus" class="<?php echo $user_list->profilestatus->headerCellClass() ?>"><div class="ew-pointer" onclick="ew.sort(event, '<?php echo $user_list->SortUrl($user_list->profilestatus) ?>', 1);"><div id="elh_user_profilestatus" class="user_profilestatus">
			<div class="ew-table-header-btn"><span class="ew-table-header-caption"><?php echo $user_list->profilestatus->caption() ?></span><span class="ew-table-header-sort"><?php if ($user_list->profilestatus->getSort() == "ASC") { ?><i class="fas fa-sort-up"></i><?php } elseif ($user_list->profilestatus->getSort() == "DESC") { ?><i class="fas fa-sort-down"></i><?php } ?></span></div>
		</div></div></th>
	<?php } ?>
<?php } ?>
<?php if ($user_list->lastprofilestatuschangedate->Visible) { // lastprofilestatuschangedate ?>
	<?php if ($user_list->SortUrl($user_list->lastprofilestatuschangedate) == "") { ?>
		<th data-name="lastprofilestatuschangedate" class="<?php echo $user_list->lastprofilestatuschangedate->headerCellClass() ?>"><div id="elh_user_lastprofilestatuschangedate" class="user_lastprofilestatuschangedate"><div class="ew-table-header-caption"><?php echo $user_list->lastprofilestatuschangedate->caption() ?></div></div></th>
	<?php } else { ?>
		<th data-name="lastprofilestatuschangedate" class="<?php echo $user_list->lastprofilestatuschangedate->headerCellClass() ?>"><div class="ew-pointer" onclick="ew.sort(event, '<?php echo $user_list->SortUrl($user_list->lastprofilestatuschangedate) ?>', 1);"><div id="elh_user_lastprofilestatuschangedate" class="user_lastprofilestatuschangedate">
			<div class="ew-table-header-btn"><span class="ew-table-header-caption"><?php echo $user_list->lastprofilestatuschangedate->caption() ?></span><span class="ew-table-header-sort"><?php if ($user_list->lastprofilestatuschangedate->getSort() == "ASC") { ?><i class="fas fa-sort-up"></i><?php } elseif ($user_list->lastprofilestatuschangedate->getSort() == "DESC") { ?><i class="fas fa-sort-down"></i><?php } ?></span></div>
		</div></div></th>
	<?php } ?>
<?php } ?>
<?php

// Render list options (header, right)
$user_list->ListOptions->render("header", "right");
?>
	</tr>
</thead>
<tbody>
<?php
if ($user_list->ExportAll && $user_list->isExport()) {
	$user_list->StopRecord = $user_list->TotalRecords;
} else {

	// Set the last record to display
	if ($user_list->TotalRecords > $user_list->StartRecord + $user_list->DisplayRecords - 1)
		$user_list->StopRecord = $user_list->StartRecord + $user_list->DisplayRecords - 1;
	else
		$user_list->StopRecord = $user_list->TotalRecords;
}
$user_list->RecordCount = $user_list->StartRecord - 1;
if ($user_list->Recordset && !$user_list->Recordset->EOF) {
	$user_list->Recordset->moveFirst();
	$selectLimit = $user_list->UseSelectLimit;
	if (!$selectLimit && $user_list->StartRecord > 1)
		$user_list->Recordset->move($user_list->StartRecord - 1);
} elseif (!$user->AllowAddDeleteRow && $user_list->StopRecord == 0) {
	$user_list->StopRecord = $user->GridAddRowCount;
}

// Initialize aggregate
$user->RowType = ROWTYPE_AGGREGATEINIT;
$user->resetAttributes();
$user_list->renderRow();
while ($user_list->RecordCount < $user_list->StopRecord) {
	$user_list->RecordCount++;
	if ($user_list->RecordCount >= $user_list->StartRecord) {
		$user_list->RowCount++;

		// Set up key count
		$user_list->KeyCount = $user_list->RowIndex;

		// Init row class and style
		$user->resetAttributes();
		$user->CssClass = "";
		if ($user_list->isGridAdd()) {
		} else {
			$user_list->loadRowValues($user_list->Recordset); // Load row values
		}
		$user->RowType = ROWTYPE_VIEW; // Render view

		// Set up row id / data-rowindex
		$user->RowAttrs->merge(["data-rowindex" => $user_list->RowCount, "id" => "r" . $user_list->RowCount . "_user", "data-rowtype" => $user->RowType]);

		// Render row
		$user_list->renderRow();

		// Render list options
		$user_list->renderListOptions();
?>
	<tr <?php echo $user->rowAttributes() ?>>
<?php

// Render list options (body, left)
$user_list->ListOptions->render("body", "left", $user_list->RowCount);
?>
	<?php if ($user_list->id->Visible) { // id ?>
		<td data-name="id" <?php echo $user_list->id->cellAttributes() ?>>
<span id="el<?php echo $user_list->RowCount ?>_user_id">
<span<?php echo $user_list->id->viewAttributes() ?>><?php echo $user_list->id->getViewValue() ?></span>
</span>
</td>
	<?php } ?>
	<?php if ($user_list->firstName->Visible) { // firstName ?>
		<td data-name="firstName" <?php echo $user_list->firstName->cellAttributes() ?>>
<span id="el<?php echo $user_list->RowCount ?>_user_firstName">
<span<?php echo $user_list->firstName->viewAttributes() ?>><?php echo $user_list->firstName->getViewValue() ?></span>
</span>
</td>
	<?php } ?>
	<?php if ($user_list->lastName->Visible) { // lastName ?>
		<td data-name="lastName" <?php echo $user_list->lastName->cellAttributes() ?>>
<span id="el<?php echo $user_list->RowCount ?>_user_lastName">
<span<?php echo $user_list->lastName->viewAttributes() ?>><?php echo $user_list->lastName->getViewValue() ?></span>
</span>
</td>
	<?php } ?>
	<?php if ($user_list->dateAdded->Visible) { // dateAdded ?>
		<td data-name="dateAdded" <?php echo $user_list->dateAdded->cellAttributes() ?>>
<span id="el<?php echo $user_list->RowCount ?>_user_dateAdded">
<span<?php echo $user_list->dateAdded->viewAttributes() ?>><?php echo $user_list->dateAdded->getViewValue() ?></span>
</span>
</td>
	<?php } ?>
	<?php if ($user_list->telephoneno->Visible) { // telephoneno ?>
		<td data-name="telephoneno" <?php echo $user_list->telephoneno->cellAttributes() ?>>
<span id="el<?php echo $user_list->RowCount ?>_user_telephoneno">
<span<?php echo $user_list->telephoneno->viewAttributes() ?>><?php echo $user_list->telephoneno->getViewValue() ?></span>
</span>
</td>
	<?php } ?>
	<?php if ($user_list->countryid->Visible) { // countryid ?>
		<td data-name="countryid" <?php echo $user_list->countryid->cellAttributes() ?>>
<span id="el<?php echo $user_list->RowCount ?>_user_countryid">
<span<?php echo $user_list->countryid->viewAttributes() ?>><?php echo $user_list->countryid->getViewValue() ?></span>
</span>
</td>
	<?php } ?>
	<?php if ($user_list->stateid->Visible) { // stateid ?>
		<td data-name="stateid" <?php echo $user_list->stateid->cellAttributes() ?>>
<span id="el<?php echo $user_list->RowCount ?>_user_stateid">
<span<?php echo $user_list->stateid->viewAttributes() ?>><?php echo $user_list->stateid->getViewValue() ?></span>
</span>
</td>
	<?php } ?>
	<?php if ($user_list->userType->Visible) { // userType ?>
		<td data-name="userType" <?php echo $user_list->userType->cellAttributes() ?>>
<span id="el<?php echo $user_list->RowCount ?>_user_userType">
<span<?php echo $user_list->userType->viewAttributes() ?>><?php echo $user_list->userType->getViewValue() ?></span>
</span>
</td>
	<?php } ?>
	<?php if ($user_list->brokerid->Visible) { // brokerid ?>
		<td data-name="brokerid" <?php echo $user_list->brokerid->cellAttributes() ?>>
<span id="el<?php echo $user_list->RowCount ?>_user_brokerid">
<span<?php echo $user_list->brokerid->viewAttributes() ?>><?php echo $user_list->brokerid->getViewValue() ?></span>
</span>
</td>
	<?php } ?>
	<?php if ($user_list->parentuserid->Visible) { // parentuserid ?>
		<td data-name="parentuserid" <?php echo $user_list->parentuserid->cellAttributes() ?>>
<span id="el<?php echo $user_list->RowCount ?>_user_parentuserid">
<span<?php echo $user_list->parentuserid->viewAttributes() ?>><?php echo $user_list->parentuserid->getViewValue() ?></span>
</span>
</td>
	<?php } ?>
	<?php if ($user_list->profilestatus->Visible) { // profilestatus ?>
		<td data-name="profilestatus" <?php echo $user_list->profilestatus->cellAttributes() ?>>
<span id="el<?php echo $user_list->RowCount ?>_user_profilestatus">
<span<?php echo $user_list->profilestatus->viewAttributes() ?>><?php echo $user_list->profilestatus->getViewValue() ?></span>
</span>
</td>
	<?php } ?>
	<?php if ($user_list->lastprofilestatuschangedate->Visible) { // lastprofilestatuschangedate ?>
		<td data-name="lastprofilestatuschangedate" <?php echo $user_list->lastprofilestatuschangedate->cellAttributes() ?>>
<span id="el<?php echo $user_list->RowCount ?>_user_lastprofilestatuschangedate">
<span<?php echo $user_list->lastprofilestatuschangedate->viewAttributes() ?>><?php echo $user_list->lastprofilestatuschangedate->getViewValue() ?></span>
</span>
</td>
	<?php } ?>
<?php

// Render list options (body, right)
$user_list->ListOptions->render("body", "right", $user_list->RowCount);
?>
	</tr>
<?php
	}
	if (!$user_list->isGridAdd())
		$user_list->Recordset->moveNext();
}
?>
</tbody>
</table><!-- /.ew-table -->
<?php } ?>
</div><!-- /.ew-grid-middle-panel -->
<?php if (!$user->CurrentAction) { ?>
<input type="hidden" name="action" id="action" value="">
<?php } ?>
</form><!-- /.ew-list-form -->
<?php

// Close recordset
if ($user_list->Recordset)
	$user_list->Recordset->Close();
?>
<?php if (!$user_list->isExport()) { ?>
<div class="card-footer ew-grid-lower-panel">
<?php if (!$user_list->isGridAdd()) { ?>
<form name="ew-pager-form" class="form-inline ew-form ew-pager-form" action="<?php echo CurrentPageName() ?>">
<?php echo $user_list->Pager->render() ?>
</form>
<?php } ?>
<div class="ew-list-other-options">
<?php $user_list->OtherOptions->render("body", "bottom") ?>
</div>
<div class="clearfix"></div>
</div>
<?php } ?>
</div><!-- /.ew-grid -->
<?php } ?>
<?php if ($user_list->TotalRecords == 0 && !$user->CurrentAction) { // Show other options ?>
<div class="ew-list-other-options">
<?php $user_list->OtherOptions->render("body") ?>
</div>
<div class="clearfix"></div>
<?php } ?>
<?php
$user_list->showPageFooter();
if (Config("DEBUG"))
	echo GetDebugMessage();
?>
<?php if (!$user_list->isExport()) { ?>
<script>
loadjs.ready("load", function() {

	// Startup script
	// Write your table-specific startup script here
	// console.log("page loaded");

});
</script>
<?php } ?>
<?php include_once "footer.php"; ?>
<?php
$user_list->terminate();
?>