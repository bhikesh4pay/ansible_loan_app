<?php
namespace PHPMaker2020\_4payadmin;

// Autoload
include_once "autoload.php";

// Session
if (session_status() !== PHP_SESSION_ACTIVE)
	\Delight\Cookie\Session::start(Config("COOKIE_SAMESITE")); // Init session data

// Output buffering
ob_start();
?>
<?php

// Write header
WriteHeader(FALSE);

// Create page object
$nodeloadhubpool_add = new nodeloadhubpool_add();

// Run the page
$nodeloadhubpool_add->run();

// Setup login status
SetupLoginStatus();
SetClientVar("login", LoginStatus());

// Global Page Rendering event (in userfn*.php)
Page_Rendering();

// Page Rendering event
$nodeloadhubpool_add->Page_Render();
?>
<?php include_once "header.php"; ?>
<script>
var fnodeloadhubpooladd, currentPageID;
loadjs.ready("head", function() {

	// Form object
	currentPageID = ew.PAGE_ID = "add";
	fnodeloadhubpooladd = currentForm = new ew.Form("fnodeloadhubpooladd", "add");

	// Validate form
	fnodeloadhubpooladd.validate = function() {
		if (!this.validateRequired)
			return true; // Ignore validation
		var $ = jQuery, fobj = this.getForm(), $fobj = $(fobj);
		if ($fobj.find("#confirm").val() == "confirm")
			return true;
		var elm, felm, uelm, addcnt = 0;
		var $k = $fobj.find("#" + this.formKeyCountName); // Get key_count
		var rowcnt = ($k[0]) ? parseInt($k.val(), 10) : 1;
		var startcnt = (rowcnt == 0) ? 0 : 1; // Check rowcnt == 0 => Inline-Add
		var gridinsert = ["insert", "gridinsert"].includes($fobj.find("#action").val()) && $k[0];
		for (var i = startcnt; i <= rowcnt; i++) {
			var infix = ($k[0]) ? String(i) : "";
			$fobj.data("rowindex", infix);
			<?php if ($nodeloadhubpool_add->txid->Required) { ?>
				elm = this.getElements("x" + infix + "_txid");
				if (elm && !ew.isHidden(elm) && !ew.hasValue(elm))
					return this.onError(elm, "<?php echo JsEncode(str_replace("%s", $nodeloadhubpool_add->txid->caption(), $nodeloadhubpool_add->txid->RequiredErrorMessage)) ?>");
			<?php } ?>
			<?php if ($nodeloadhubpool_add->sourceUserID->Required) { ?>
				elm = this.getElements("x" + infix + "_sourceUserID");
				if (elm && !ew.isHidden(elm) && !ew.hasValue(elm))
					return this.onError(elm, "<?php echo JsEncode(str_replace("%s", $nodeloadhubpool_add->sourceUserID->caption(), $nodeloadhubpool_add->sourceUserID->RequiredErrorMessage)) ?>");
			<?php } ?>
				elm = this.getElements("x" + infix + "_sourceUserID");
				if (elm && !ew.checkInteger(elm.value))
					return this.onError(elm, "<?php echo JsEncode($nodeloadhubpool_add->sourceUserID->errorMessage()) ?>");
			<?php if ($nodeloadhubpool_add->requesttime->Required) { ?>
				elm = this.getElements("x" + infix + "_requesttime");
				if (elm && !ew.isHidden(elm) && !ew.hasValue(elm))
					return this.onError(elm, "<?php echo JsEncode(str_replace("%s", $nodeloadhubpool_add->requesttime->caption(), $nodeloadhubpool_add->requesttime->RequiredErrorMessage)) ?>");
			<?php } ?>
				elm = this.getElements("x" + infix + "_requesttime");
				if (elm && !ew.checkDateDef(elm.value))
					return this.onError(elm, "<?php echo JsEncode($nodeloadhubpool_add->requesttime->errorMessage()) ?>");
			<?php if ($nodeloadhubpool_add->currID->Required) { ?>
				elm = this.getElements("x" + infix + "_currID");
				if (elm && !ew.isHidden(elm) && !ew.hasValue(elm))
					return this.onError(elm, "<?php echo JsEncode(str_replace("%s", $nodeloadhubpool_add->currID->caption(), $nodeloadhubpool_add->currID->RequiredErrorMessage)) ?>");
			<?php } ?>
			<?php if ($nodeloadhubpool_add->amounttopup->Required) { ?>
				elm = this.getElements("x" + infix + "_amounttopup");
				if (elm && !ew.isHidden(elm) && !ew.hasValue(elm))
					return this.onError(elm, "<?php echo JsEncode(str_replace("%s", $nodeloadhubpool_add->amounttopup->caption(), $nodeloadhubpool_add->amounttopup->RequiredErrorMessage)) ?>");
			<?php } ?>
				elm = this.getElements("x" + infix + "_amounttopup");
				if (elm && !ew.checkNumber(elm.value))
					return this.onError(elm, "<?php echo JsEncode($nodeloadhubpool_add->amounttopup->errorMessage()) ?>");
			<?php if ($nodeloadhubpool_add->lastUpdateDateTime->Required) { ?>
				elm = this.getElements("x" + infix + "_lastUpdateDateTime");
				if (elm && !ew.isHidden(elm) && !ew.hasValue(elm))
					return this.onError(elm, "<?php echo JsEncode(str_replace("%s", $nodeloadhubpool_add->lastUpdateDateTime->caption(), $nodeloadhubpool_add->lastUpdateDateTime->RequiredErrorMessage)) ?>");
			<?php } ?>
				elm = this.getElements("x" + infix + "_lastUpdateDateTime");
				if (elm && !ew.checkDateDef(elm.value))
					return this.onError(elm, "<?php echo JsEncode($nodeloadhubpool_add->lastUpdateDateTime->errorMessage()) ?>");
			<?php if ($nodeloadhubpool_add->feeid->Required) { ?>
				elm = this.getElements("x" + infix + "_feeid");
				if (elm && !ew.isHidden(elm) && !ew.hasValue(elm))
					return this.onError(elm, "<?php echo JsEncode(str_replace("%s", $nodeloadhubpool_add->feeid->caption(), $nodeloadhubpool_add->feeid->RequiredErrorMessage)) ?>");
			<?php } ?>
				elm = this.getElements("x" + infix + "_feeid");
				if (elm && !ew.checkInteger(elm.value))
					return this.onError(elm, "<?php echo JsEncode($nodeloadhubpool_add->feeid->errorMessage()) ?>");
			<?php if ($nodeloadhubpool_add->serviceFee->Required) { ?>
				elm = this.getElements("x" + infix + "_serviceFee");
				if (elm && !ew.isHidden(elm) && !ew.hasValue(elm))
					return this.onError(elm, "<?php echo JsEncode(str_replace("%s", $nodeloadhubpool_add->serviceFee->caption(), $nodeloadhubpool_add->serviceFee->RequiredErrorMessage)) ?>");
			<?php } ?>
				elm = this.getElements("x" + infix + "_serviceFee");
				if (elm && !ew.checkNumber(elm.value))
					return this.onError(elm, "<?php echo JsEncode($nodeloadhubpool_add->serviceFee->errorMessage()) ?>");
			<?php if ($nodeloadhubpool_add->status->Required) { ?>
				elm = this.getElements("x" + infix + "_status");
				if (elm && !ew.isHidden(elm) && !ew.hasValue(elm))
					return this.onError(elm, "<?php echo JsEncode(str_replace("%s", $nodeloadhubpool_add->status->caption(), $nodeloadhubpool_add->status->RequiredErrorMessage)) ?>");
			<?php } ?>
			<?php if ($nodeloadhubpool_add->LHTranstime->Required) { ?>
				elm = this.getElements("x" + infix + "_LHTranstime");
				if (elm && !ew.isHidden(elm) && !ew.hasValue(elm))
					return this.onError(elm, "<?php echo JsEncode(str_replace("%s", $nodeloadhubpool_add->LHTranstime->caption(), $nodeloadhubpool_add->LHTranstime->RequiredErrorMessage)) ?>");
			<?php } ?>
			<?php if ($nodeloadhubpool_add->LHTransNo->Required) { ?>
				elm = this.getElements("x" + infix + "_LHTransNo");
				if (elm && !ew.isHidden(elm) && !ew.hasValue(elm))
					return this.onError(elm, "<?php echo JsEncode(str_replace("%s", $nodeloadhubpool_add->LHTransNo->caption(), $nodeloadhubpool_add->LHTransNo->RequiredErrorMessage)) ?>");
			<?php } ?>
			<?php if ($nodeloadhubpool_add->LHRef->Required) { ?>
				elm = this.getElements("x" + infix + "_LHRef");
				if (elm && !ew.isHidden(elm) && !ew.hasValue(elm))
					return this.onError(elm, "<?php echo JsEncode(str_replace("%s", $nodeloadhubpool_add->LHRef->caption(), $nodeloadhubpool_add->LHRef->RequiredErrorMessage)) ?>");
			<?php } ?>

				// Call Form_CustomValidate event
				if (!this.Form_CustomValidate(fobj))
					return false;
		}

		// Process detail forms
		var dfs = $fobj.find("input[name='detailpage']").get();
		for (var i = 0; i < dfs.length; i++) {
			var df = dfs[i], val = df.value;
			if (val && ew.forms[val])
				if (!ew.forms[val].validate())
					return false;
		}
		return true;
	}

	// Form_CustomValidate
	fnodeloadhubpooladd.Form_CustomValidate = function(fobj) { // DO NOT CHANGE THIS LINE!

		// Your custom validation code here, return false if invalid.
		return true;
	}

	// Use JavaScript validation or not
	fnodeloadhubpooladd.validateRequired = <?php echo Config("CLIENT_VALIDATE") ? "true" : "false" ?>;

	// Dynamic selection lists
	loadjs.done("fnodeloadhubpooladd");
});
</script>
<script>
loadjs.ready("head", function() {

	// Client script
	// Write your client script here, no need to add script tags.

});
</script>
<?php $nodeloadhubpool_add->showPageHeader(); ?>
<?php
$nodeloadhubpool_add->showMessage();
?>
<form name="fnodeloadhubpooladd" id="fnodeloadhubpooladd" class="<?php echo $nodeloadhubpool_add->FormClassName ?>" action="<?php echo CurrentPageName() ?>" method="post">
<?php if ($Page->CheckToken) { ?>
<input type="hidden" name="<?php echo Config("TOKEN_NAME") ?>" value="<?php echo $Page->Token ?>">
<?php } ?>
<input type="hidden" name="t" value="nodeloadhubpool">
<input type="hidden" name="action" id="action" value="insert">
<input type="hidden" name="modal" value="<?php echo (int)$nodeloadhubpool_add->IsModal ?>">
<div class="ew-add-div"><!-- page* -->
<?php if ($nodeloadhubpool_add->txid->Visible) { // txid ?>
	<div id="r_txid" class="form-group row">
		<label id="elh_nodeloadhubpool_txid" for="x_txid" class="<?php echo $nodeloadhubpool_add->LeftColumnClass ?>"><?php echo $nodeloadhubpool_add->txid->caption() ?><?php echo $nodeloadhubpool_add->txid->Required ? $Language->phrase("FieldRequiredIndicator") : "" ?></label>
		<div class="<?php echo $nodeloadhubpool_add->RightColumnClass ?>"><div <?php echo $nodeloadhubpool_add->txid->cellAttributes() ?>>
<span id="el_nodeloadhubpool_txid">
<input type="text" data-table="nodeloadhubpool" data-field="x_txid" name="x_txid" id="x_txid" size="30" maxlength="20" placeholder="<?php echo HtmlEncode($nodeloadhubpool_add->txid->getPlaceHolder()) ?>" value="<?php echo $nodeloadhubpool_add->txid->EditValue ?>"<?php echo $nodeloadhubpool_add->txid->editAttributes() ?>>
</span>
<?php echo $nodeloadhubpool_add->txid->CustomMsg ?></div></div>
	</div>
<?php } ?>
<?php if ($nodeloadhubpool_add->sourceUserID->Visible) { // sourceUserID ?>
	<div id="r_sourceUserID" class="form-group row">
		<label id="elh_nodeloadhubpool_sourceUserID" for="x_sourceUserID" class="<?php echo $nodeloadhubpool_add->LeftColumnClass ?>"><?php echo $nodeloadhubpool_add->sourceUserID->caption() ?><?php echo $nodeloadhubpool_add->sourceUserID->Required ? $Language->phrase("FieldRequiredIndicator") : "" ?></label>
		<div class="<?php echo $nodeloadhubpool_add->RightColumnClass ?>"><div <?php echo $nodeloadhubpool_add->sourceUserID->cellAttributes() ?>>
<span id="el_nodeloadhubpool_sourceUserID">
<input type="text" data-table="nodeloadhubpool" data-field="x_sourceUserID" name="x_sourceUserID" id="x_sourceUserID" size="30" placeholder="<?php echo HtmlEncode($nodeloadhubpool_add->sourceUserID->getPlaceHolder()) ?>" value="<?php echo $nodeloadhubpool_add->sourceUserID->EditValue ?>"<?php echo $nodeloadhubpool_add->sourceUserID->editAttributes() ?>>
</span>
<?php echo $nodeloadhubpool_add->sourceUserID->CustomMsg ?></div></div>
	</div>
<?php } ?>
<?php if ($nodeloadhubpool_add->requesttime->Visible) { // requesttime ?>
	<div id="r_requesttime" class="form-group row">
		<label id="elh_nodeloadhubpool_requesttime" for="x_requesttime" class="<?php echo $nodeloadhubpool_add->LeftColumnClass ?>"><?php echo $nodeloadhubpool_add->requesttime->caption() ?><?php echo $nodeloadhubpool_add->requesttime->Required ? $Language->phrase("FieldRequiredIndicator") : "" ?></label>
		<div class="<?php echo $nodeloadhubpool_add->RightColumnClass ?>"><div <?php echo $nodeloadhubpool_add->requesttime->cellAttributes() ?>>
<span id="el_nodeloadhubpool_requesttime">
<input type="text" data-table="nodeloadhubpool" data-field="x_requesttime" name="x_requesttime" id="x_requesttime" placeholder="<?php echo HtmlEncode($nodeloadhubpool_add->requesttime->getPlaceHolder()) ?>" value="<?php echo $nodeloadhubpool_add->requesttime->EditValue ?>"<?php echo $nodeloadhubpool_add->requesttime->editAttributes() ?>>
</span>
<?php echo $nodeloadhubpool_add->requesttime->CustomMsg ?></div></div>
	</div>
<?php } ?>
<?php if ($nodeloadhubpool_add->currID->Visible) { // currID ?>
	<div id="r_currID" class="form-group row">
		<label id="elh_nodeloadhubpool_currID" for="x_currID" class="<?php echo $nodeloadhubpool_add->LeftColumnClass ?>"><?php echo $nodeloadhubpool_add->currID->caption() ?><?php echo $nodeloadhubpool_add->currID->Required ? $Language->phrase("FieldRequiredIndicator") : "" ?></label>
		<div class="<?php echo $nodeloadhubpool_add->RightColumnClass ?>"><div <?php echo $nodeloadhubpool_add->currID->cellAttributes() ?>>
<span id="el_nodeloadhubpool_currID">
<input type="text" data-table="nodeloadhubpool" data-field="x_currID" name="x_currID" id="x_currID" size="30" maxlength="3" placeholder="<?php echo HtmlEncode($nodeloadhubpool_add->currID->getPlaceHolder()) ?>" value="<?php echo $nodeloadhubpool_add->currID->EditValue ?>"<?php echo $nodeloadhubpool_add->currID->editAttributes() ?>>
</span>
<?php echo $nodeloadhubpool_add->currID->CustomMsg ?></div></div>
	</div>
<?php } ?>
<?php if ($nodeloadhubpool_add->amounttopup->Visible) { // amounttopup ?>
	<div id="r_amounttopup" class="form-group row">
		<label id="elh_nodeloadhubpool_amounttopup" for="x_amounttopup" class="<?php echo $nodeloadhubpool_add->LeftColumnClass ?>"><?php echo $nodeloadhubpool_add->amounttopup->caption() ?><?php echo $nodeloadhubpool_add->amounttopup->Required ? $Language->phrase("FieldRequiredIndicator") : "" ?></label>
		<div class="<?php echo $nodeloadhubpool_add->RightColumnClass ?>"><div <?php echo $nodeloadhubpool_add->amounttopup->cellAttributes() ?>>
<span id="el_nodeloadhubpool_amounttopup">
<input type="text" data-table="nodeloadhubpool" data-field="x_amounttopup" name="x_amounttopup" id="x_amounttopup" size="30" placeholder="<?php echo HtmlEncode($nodeloadhubpool_add->amounttopup->getPlaceHolder()) ?>" value="<?php echo $nodeloadhubpool_add->amounttopup->EditValue ?>"<?php echo $nodeloadhubpool_add->amounttopup->editAttributes() ?>>
</span>
<?php echo $nodeloadhubpool_add->amounttopup->CustomMsg ?></div></div>
	</div>
<?php } ?>
<?php if ($nodeloadhubpool_add->lastUpdateDateTime->Visible) { // lastUpdateDateTime ?>
	<div id="r_lastUpdateDateTime" class="form-group row">
		<label id="elh_nodeloadhubpool_lastUpdateDateTime" for="x_lastUpdateDateTime" class="<?php echo $nodeloadhubpool_add->LeftColumnClass ?>"><?php echo $nodeloadhubpool_add->lastUpdateDateTime->caption() ?><?php echo $nodeloadhubpool_add->lastUpdateDateTime->Required ? $Language->phrase("FieldRequiredIndicator") : "" ?></label>
		<div class="<?php echo $nodeloadhubpool_add->RightColumnClass ?>"><div <?php echo $nodeloadhubpool_add->lastUpdateDateTime->cellAttributes() ?>>
<span id="el_nodeloadhubpool_lastUpdateDateTime">
<input type="text" data-table="nodeloadhubpool" data-field="x_lastUpdateDateTime" data-format="1" name="x_lastUpdateDateTime" id="x_lastUpdateDateTime" placeholder="<?php echo HtmlEncode($nodeloadhubpool_add->lastUpdateDateTime->getPlaceHolder()) ?>" value="<?php echo $nodeloadhubpool_add->lastUpdateDateTime->EditValue ?>"<?php echo $nodeloadhubpool_add->lastUpdateDateTime->editAttributes() ?>>
</span>
<?php echo $nodeloadhubpool_add->lastUpdateDateTime->CustomMsg ?></div></div>
	</div>
<?php } ?>
<?php if ($nodeloadhubpool_add->feeid->Visible) { // feeid ?>
	<div id="r_feeid" class="form-group row">
		<label id="elh_nodeloadhubpool_feeid" for="x_feeid" class="<?php echo $nodeloadhubpool_add->LeftColumnClass ?>"><?php echo $nodeloadhubpool_add->feeid->caption() ?><?php echo $nodeloadhubpool_add->feeid->Required ? $Language->phrase("FieldRequiredIndicator") : "" ?></label>
		<div class="<?php echo $nodeloadhubpool_add->RightColumnClass ?>"><div <?php echo $nodeloadhubpool_add->feeid->cellAttributes() ?>>
<span id="el_nodeloadhubpool_feeid">
<input type="text" data-table="nodeloadhubpool" data-field="x_feeid" name="x_feeid" id="x_feeid" size="30" placeholder="<?php echo HtmlEncode($nodeloadhubpool_add->feeid->getPlaceHolder()) ?>" value="<?php echo $nodeloadhubpool_add->feeid->EditValue ?>"<?php echo $nodeloadhubpool_add->feeid->editAttributes() ?>>
</span>
<?php echo $nodeloadhubpool_add->feeid->CustomMsg ?></div></div>
	</div>
<?php } ?>
<?php if ($nodeloadhubpool_add->serviceFee->Visible) { // serviceFee ?>
	<div id="r_serviceFee" class="form-group row">
		<label id="elh_nodeloadhubpool_serviceFee" for="x_serviceFee" class="<?php echo $nodeloadhubpool_add->LeftColumnClass ?>"><?php echo $nodeloadhubpool_add->serviceFee->caption() ?><?php echo $nodeloadhubpool_add->serviceFee->Required ? $Language->phrase("FieldRequiredIndicator") : "" ?></label>
		<div class="<?php echo $nodeloadhubpool_add->RightColumnClass ?>"><div <?php echo $nodeloadhubpool_add->serviceFee->cellAttributes() ?>>
<span id="el_nodeloadhubpool_serviceFee">
<input type="text" data-table="nodeloadhubpool" data-field="x_serviceFee" name="x_serviceFee" id="x_serviceFee" size="30" placeholder="<?php echo HtmlEncode($nodeloadhubpool_add->serviceFee->getPlaceHolder()) ?>" value="<?php echo $nodeloadhubpool_add->serviceFee->EditValue ?>"<?php echo $nodeloadhubpool_add->serviceFee->editAttributes() ?>>
</span>
<?php echo $nodeloadhubpool_add->serviceFee->CustomMsg ?></div></div>
	</div>
<?php } ?>
<?php if ($nodeloadhubpool_add->status->Visible) { // status ?>
	<div id="r_status" class="form-group row">
		<label id="elh_nodeloadhubpool_status" for="x_status" class="<?php echo $nodeloadhubpool_add->LeftColumnClass ?>"><?php echo $nodeloadhubpool_add->status->caption() ?><?php echo $nodeloadhubpool_add->status->Required ? $Language->phrase("FieldRequiredIndicator") : "" ?></label>
		<div class="<?php echo $nodeloadhubpool_add->RightColumnClass ?>"><div <?php echo $nodeloadhubpool_add->status->cellAttributes() ?>>
<span id="el_nodeloadhubpool_status">
<input type="text" data-table="nodeloadhubpool" data-field="x_status" name="x_status" id="x_status" size="30" maxlength="1" placeholder="<?php echo HtmlEncode($nodeloadhubpool_add->status->getPlaceHolder()) ?>" value="<?php echo $nodeloadhubpool_add->status->EditValue ?>"<?php echo $nodeloadhubpool_add->status->editAttributes() ?>>
</span>
<?php echo $nodeloadhubpool_add->status->CustomMsg ?></div></div>
	</div>
<?php } ?>
<?php if ($nodeloadhubpool_add->LHTranstime->Visible) { // LHTranstime ?>
	<div id="r_LHTranstime" class="form-group row">
		<label id="elh_nodeloadhubpool_LHTranstime" for="x_LHTranstime" class="<?php echo $nodeloadhubpool_add->LeftColumnClass ?>"><?php echo $nodeloadhubpool_add->LHTranstime->caption() ?><?php echo $nodeloadhubpool_add->LHTranstime->Required ? $Language->phrase("FieldRequiredIndicator") : "" ?></label>
		<div class="<?php echo $nodeloadhubpool_add->RightColumnClass ?>"><div <?php echo $nodeloadhubpool_add->LHTranstime->cellAttributes() ?>>
<span id="el_nodeloadhubpool_LHTranstime">
<input type="text" data-table="nodeloadhubpool" data-field="x_LHTranstime" name="x_LHTranstime" id="x_LHTranstime" size="30" maxlength="19" placeholder="<?php echo HtmlEncode($nodeloadhubpool_add->LHTranstime->getPlaceHolder()) ?>" value="<?php echo $nodeloadhubpool_add->LHTranstime->EditValue ?>"<?php echo $nodeloadhubpool_add->LHTranstime->editAttributes() ?>>
</span>
<?php echo $nodeloadhubpool_add->LHTranstime->CustomMsg ?></div></div>
	</div>
<?php } ?>
<?php if ($nodeloadhubpool_add->LHTransNo->Visible) { // LHTransNo ?>
	<div id="r_LHTransNo" class="form-group row">
		<label id="elh_nodeloadhubpool_LHTransNo" for="x_LHTransNo" class="<?php echo $nodeloadhubpool_add->LeftColumnClass ?>"><?php echo $nodeloadhubpool_add->LHTransNo->caption() ?><?php echo $nodeloadhubpool_add->LHTransNo->Required ? $Language->phrase("FieldRequiredIndicator") : "" ?></label>
		<div class="<?php echo $nodeloadhubpool_add->RightColumnClass ?>"><div <?php echo $nodeloadhubpool_add->LHTransNo->cellAttributes() ?>>
<span id="el_nodeloadhubpool_LHTransNo">
<input type="text" data-table="nodeloadhubpool" data-field="x_LHTransNo" name="x_LHTransNo" id="x_LHTransNo" size="30" maxlength="13" placeholder="<?php echo HtmlEncode($nodeloadhubpool_add->LHTransNo->getPlaceHolder()) ?>" value="<?php echo $nodeloadhubpool_add->LHTransNo->EditValue ?>"<?php echo $nodeloadhubpool_add->LHTransNo->editAttributes() ?>>
</span>
<?php echo $nodeloadhubpool_add->LHTransNo->CustomMsg ?></div></div>
	</div>
<?php } ?>
<?php if ($nodeloadhubpool_add->LHRef->Visible) { // LHRef ?>
	<div id="r_LHRef" class="form-group row">
		<label id="elh_nodeloadhubpool_LHRef" for="x_LHRef" class="<?php echo $nodeloadhubpool_add->LeftColumnClass ?>"><?php echo $nodeloadhubpool_add->LHRef->caption() ?><?php echo $nodeloadhubpool_add->LHRef->Required ? $Language->phrase("FieldRequiredIndicator") : "" ?></label>
		<div class="<?php echo $nodeloadhubpool_add->RightColumnClass ?>"><div <?php echo $nodeloadhubpool_add->LHRef->cellAttributes() ?>>
<span id="el_nodeloadhubpool_LHRef">
<input type="text" data-table="nodeloadhubpool" data-field="x_LHRef" name="x_LHRef" id="x_LHRef" size="30" maxlength="6" placeholder="<?php echo HtmlEncode($nodeloadhubpool_add->LHRef->getPlaceHolder()) ?>" value="<?php echo $nodeloadhubpool_add->LHRef->EditValue ?>"<?php echo $nodeloadhubpool_add->LHRef->editAttributes() ?>>
</span>
<?php echo $nodeloadhubpool_add->LHRef->CustomMsg ?></div></div>
	</div>
<?php } ?>
</div><!-- /page* -->
<?php if (!$nodeloadhubpool_add->IsModal) { ?>
<div class="form-group row"><!-- buttons .form-group -->
	<div class="<?php echo $nodeloadhubpool_add->OffsetColumnClass ?>"><!-- buttons offset -->
<button class="btn btn-primary ew-btn" name="btn-action" id="btn-action" type="submit"><?php echo $Language->phrase("AddBtn") ?></button>
<button class="btn btn-default ew-btn" name="btn-cancel" id="btn-cancel" type="button" data-href="<?php echo $nodeloadhubpool_add->getReturnUrl() ?>"><?php echo $Language->phrase("CancelBtn") ?></button>
	</div><!-- /buttons offset -->
</div><!-- /buttons .form-group -->
<?php } ?>
</form>
<?php
$nodeloadhubpool_add->showPageFooter();
if (Config("DEBUG"))
	echo GetDebugMessage();
?>
<script>
loadjs.ready("load", function() {

	// Startup script
	// Write your table-specific startup script here
	// console.log("page loaded");

});
</script>
<?php include_once "footer.php"; ?>
<?php
$nodeloadhubpool_add->terminate();
?>