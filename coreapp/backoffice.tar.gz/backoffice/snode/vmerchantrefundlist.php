<?php
namespace PHPMaker2020\_4payadmin;

// Autoload
include_once "autoload.php";

// Session
if (session_status() !== PHP_SESSION_ACTIVE)
	\Delight\Cookie\Session::start(Config("COOKIE_SAMESITE")); // Init session data

// Output buffering
ob_start();
?>
<?php

// Write header
WriteHeader(FALSE);

// Create page object
$vmerchantrefund_list = new vmerchantrefund_list();

// Run the page
$vmerchantrefund_list->run();

// Setup login status
SetupLoginStatus();
SetClientVar("login", LoginStatus());

// Global Page Rendering event (in userfn*.php)
Page_Rendering();

// Page Rendering event
$vmerchantrefund_list->Page_Render();
?>
<?php include_once "header.php"; ?>
<?php if (!$vmerchantrefund_list->isExport()) { ?>
<script>
var fvmerchantrefundlist, currentPageID;
loadjs.ready("head", function() {

	// Form object
	currentPageID = ew.PAGE_ID = "list";
	fvmerchantrefundlist = currentForm = new ew.Form("fvmerchantrefundlist", "list");
	fvmerchantrefundlist.formKeyCountName = '<?php echo $vmerchantrefund_list->FormKeyCountName ?>';
	loadjs.done("fvmerchantrefundlist");
});
var fvmerchantrefundlistsrch;
loadjs.ready("head", function() {

	// Form object for search
	fvmerchantrefundlistsrch = currentSearchForm = new ew.Form("fvmerchantrefundlistsrch");

	// Dynamic selection lists
	// Filters

	fvmerchantrefundlistsrch.filterList = <?php echo $vmerchantrefund_list->getFilterList() ?>;

	// Init search panel as collapsed
	fvmerchantrefundlistsrch.initSearchPanel = true;
	loadjs.done("fvmerchantrefundlistsrch");
});
</script>
<style type="text/css">
.ew-table-preview-row { /* main table preview row color */
	background-color: #FFFFFF; /* preview row color */
}
.ew-table-preview-row .ew-grid {
	display: table;
}
</style>
<div id="ew-preview" class="d-none"><!-- preview -->
	<div class="ew-nav-tabs"><!-- .ew-nav-tabs -->
		<ul class="nav nav-tabs"></ul>
		<div class="tab-content"><!-- .tab-content -->
			<div class="tab-pane fade active show"></div>
		</div><!-- /.tab-content -->
	</div><!-- /.ew-nav-tabs -->
</div><!-- /preview -->
<script>
loadjs.ready("head", function() {
	ew.PREVIEW_PLACEMENT = ew.CSS_FLIP ? "right" : "left";
	ew.PREVIEW_SINGLE_ROW = false;
	ew.PREVIEW_OVERLAY = false;
	loadjs("js/ewpreview.js", "preview");
});
</script>
<script>
loadjs.ready("head", function() {

	// Client script
	// Write your client script here, no need to add script tags.

});
</script>
<?php } ?>
<?php if (!$vmerchantrefund_list->isExport()) { ?>
<div class="btn-toolbar ew-toolbar">
<?php if ($vmerchantrefund_list->TotalRecords > 0 && $vmerchantrefund_list->ExportOptions->visible()) { ?>
<?php $vmerchantrefund_list->ExportOptions->render("body") ?>
<?php } ?>
<?php if ($vmerchantrefund_list->ImportOptions->visible()) { ?>
<?php $vmerchantrefund_list->ImportOptions->render("body") ?>
<?php } ?>
<?php if ($vmerchantrefund_list->SearchOptions->visible()) { ?>
<?php $vmerchantrefund_list->SearchOptions->render("body") ?>
<?php } ?>
<?php if ($vmerchantrefund_list->FilterOptions->visible()) { ?>
<?php $vmerchantrefund_list->FilterOptions->render("body") ?>
<?php } ?>
<div class="clearfix"></div>
</div>
<?php } ?>
<?php
$vmerchantrefund_list->renderOtherOptions();
?>
<?php if ($Security->CanSearch()) { ?>
<?php if (!$vmerchantrefund_list->isExport() && !$vmerchantrefund->CurrentAction) { ?>
<form name="fvmerchantrefundlistsrch" id="fvmerchantrefundlistsrch" class="form-inline ew-form ew-ext-search-form" action="<?php echo CurrentPageName() ?>">
<div id="fvmerchantrefundlistsrch-search-panel" class="<?php echo $vmerchantrefund_list->SearchPanelClass ?>">
<input type="hidden" name="cmd" value="search">
<input type="hidden" name="t" value="vmerchantrefund">
	<div class="ew-extended-search">
<div id="xsr_<?php echo $vmerchantrefund_list->SearchRowCount + 1 ?>" class="ew-row d-sm-flex">
	<div class="ew-quick-search input-group">
		<input type="text" name="<?php echo Config("TABLE_BASIC_SEARCH") ?>" id="<?php echo Config("TABLE_BASIC_SEARCH") ?>" class="form-control" value="<?php echo HtmlEncode($vmerchantrefund_list->BasicSearch->getKeyword()) ?>" placeholder="<?php echo HtmlEncode($Language->phrase("Search")) ?>">
		<input type="hidden" name="<?php echo Config("TABLE_BASIC_SEARCH_TYPE") ?>" id="<?php echo Config("TABLE_BASIC_SEARCH_TYPE") ?>" value="<?php echo HtmlEncode($vmerchantrefund_list->BasicSearch->getType()) ?>">
		<div class="input-group-append">
			<button class="btn btn-primary" name="btn-submit" id="btn-submit" type="submit"><?php echo $Language->phrase("SearchBtn") ?></button>
			<button type="button" data-toggle="dropdown" class="btn btn-primary dropdown-toggle dropdown-toggle-split" aria-haspopup="true" aria-expanded="false"><span id="searchtype"><?php echo $vmerchantrefund_list->BasicSearch->getTypeNameShort() ?></span></button>
			<div class="dropdown-menu dropdown-menu-right">
				<a class="dropdown-item<?php if ($vmerchantrefund_list->BasicSearch->getType() == "") { ?> active<?php } ?>" href="#" onclick="return ew.setSearchType(this);"><?php echo $Language->phrase("QuickSearchAuto") ?></a>
				<a class="dropdown-item<?php if ($vmerchantrefund_list->BasicSearch->getType() == "=") { ?> active<?php } ?>" href="#" onclick="return ew.setSearchType(this, '=');"><?php echo $Language->phrase("QuickSearchExact") ?></a>
				<a class="dropdown-item<?php if ($vmerchantrefund_list->BasicSearch->getType() == "AND") { ?> active<?php } ?>" href="#" onclick="return ew.setSearchType(this, 'AND');"><?php echo $Language->phrase("QuickSearchAll") ?></a>
				<a class="dropdown-item<?php if ($vmerchantrefund_list->BasicSearch->getType() == "OR") { ?> active<?php } ?>" href="#" onclick="return ew.setSearchType(this, 'OR');"><?php echo $Language->phrase("QuickSearchAny") ?></a>
			</div>
		</div>
	</div>
</div>
	</div><!-- /.ew-extended-search -->
</div><!-- /.ew-search-panel -->
</form>
<?php } ?>
<?php } ?>
<?php $vmerchantrefund_list->showPageHeader(); ?>
<?php
$vmerchantrefund_list->showMessage();
?>
<?php if ($vmerchantrefund_list->TotalRecords > 0 || $vmerchantrefund->CurrentAction) { ?>
<div class="card ew-card ew-grid<?php if ($vmerchantrefund_list->isAddOrEdit()) { ?> ew-grid-add-edit<?php } ?> vmerchantrefund">
<form name="fvmerchantrefundlist" id="fvmerchantrefundlist" class="form-inline ew-form ew-list-form" action="<?php echo CurrentPageName() ?>" method="post">
<?php if ($Page->CheckToken) { ?>
<input type="hidden" name="<?php echo Config("TOKEN_NAME") ?>" value="<?php echo $Page->Token ?>">
<?php } ?>
<input type="hidden" name="t" value="vmerchantrefund">
<div id="gmp_vmerchantrefund" class="<?php echo ResponsiveTableClass() ?>card-body ew-grid-middle-panel">
<?php if ($vmerchantrefund_list->TotalRecords > 0 || $vmerchantrefund_list->isGridEdit()) { ?>
<table id="tbl_vmerchantrefundlist" class="table ew-table"><!-- .ew-table -->
<thead>
	<tr class="ew-table-header">
<?php

// Header row
$vmerchantrefund->RowType = ROWTYPE_HEADER;

// Render list options
$vmerchantrefund_list->renderListOptions();

// Render list options (header, left)
$vmerchantrefund_list->ListOptions->render("header", "left");
?>
<?php if ($vmerchantrefund_list->transferID->Visible) { // transferID ?>
	<?php if ($vmerchantrefund_list->SortUrl($vmerchantrefund_list->transferID) == "") { ?>
		<th data-name="transferID" class="<?php echo $vmerchantrefund_list->transferID->headerCellClass() ?>"><div id="elh_vmerchantrefund_transferID" class="vmerchantrefund_transferID"><div class="ew-table-header-caption"><?php echo $vmerchantrefund_list->transferID->caption() ?></div></div></th>
	<?php } else { ?>
		<th data-name="transferID" class="<?php echo $vmerchantrefund_list->transferID->headerCellClass() ?>"><div class="ew-pointer" onclick="ew.sort(event, '<?php echo $vmerchantrefund_list->SortUrl($vmerchantrefund_list->transferID) ?>', 1);"><div id="elh_vmerchantrefund_transferID" class="vmerchantrefund_transferID">
			<div class="ew-table-header-btn"><span class="ew-table-header-caption"><?php echo $vmerchantrefund_list->transferID->caption() ?></span><span class="ew-table-header-sort"><?php if ($vmerchantrefund_list->transferID->getSort() == "ASC") { ?><i class="fas fa-sort-up"></i><?php } elseif ($vmerchantrefund_list->transferID->getSort() == "DESC") { ?><i class="fas fa-sort-down"></i><?php } ?></span></div>
		</div></div></th>
	<?php } ?>
<?php } ?>
<?php if ($vmerchantrefund_list->merchantid->Visible) { // merchantid ?>
	<?php if ($vmerchantrefund_list->SortUrl($vmerchantrefund_list->merchantid) == "") { ?>
		<th data-name="merchantid" class="<?php echo $vmerchantrefund_list->merchantid->headerCellClass() ?>"><div id="elh_vmerchantrefund_merchantid" class="vmerchantrefund_merchantid"><div class="ew-table-header-caption"><?php echo $vmerchantrefund_list->merchantid->caption() ?></div></div></th>
	<?php } else { ?>
		<th data-name="merchantid" class="<?php echo $vmerchantrefund_list->merchantid->headerCellClass() ?>"><div class="ew-pointer" onclick="ew.sort(event, '<?php echo $vmerchantrefund_list->SortUrl($vmerchantrefund_list->merchantid) ?>', 1);"><div id="elh_vmerchantrefund_merchantid" class="vmerchantrefund_merchantid">
			<div class="ew-table-header-btn"><span class="ew-table-header-caption"><?php echo $vmerchantrefund_list->merchantid->caption() ?></span><span class="ew-table-header-sort"><?php if ($vmerchantrefund_list->merchantid->getSort() == "ASC") { ?><i class="fas fa-sort-up"></i><?php } elseif ($vmerchantrefund_list->merchantid->getSort() == "DESC") { ?><i class="fas fa-sort-down"></i><?php } ?></span></div>
		</div></div></th>
	<?php } ?>
<?php } ?>
<?php if ($vmerchantrefund_list->txid->Visible) { // txid ?>
	<?php if ($vmerchantrefund_list->SortUrl($vmerchantrefund_list->txid) == "") { ?>
		<th data-name="txid" class="<?php echo $vmerchantrefund_list->txid->headerCellClass() ?>"><div id="elh_vmerchantrefund_txid" class="vmerchantrefund_txid"><div class="ew-table-header-caption"><?php echo $vmerchantrefund_list->txid->caption() ?></div></div></th>
	<?php } else { ?>
		<th data-name="txid" class="<?php echo $vmerchantrefund_list->txid->headerCellClass() ?>"><div class="ew-pointer" onclick="ew.sort(event, '<?php echo $vmerchantrefund_list->SortUrl($vmerchantrefund_list->txid) ?>', 1);"><div id="elh_vmerchantrefund_txid" class="vmerchantrefund_txid">
			<div class="ew-table-header-btn"><span class="ew-table-header-caption"><?php echo $vmerchantrefund_list->txid->caption() ?><?php echo $Language->phrase("SrchLegend") ?></span><span class="ew-table-header-sort"><?php if ($vmerchantrefund_list->txid->getSort() == "ASC") { ?><i class="fas fa-sort-up"></i><?php } elseif ($vmerchantrefund_list->txid->getSort() == "DESC") { ?><i class="fas fa-sort-down"></i><?php } ?></span></div>
		</div></div></th>
	<?php } ?>
<?php } ?>
<?php if ($vmerchantrefund_list->returnTime->Visible) { // returnTime ?>
	<?php if ($vmerchantrefund_list->SortUrl($vmerchantrefund_list->returnTime) == "") { ?>
		<th data-name="returnTime" class="<?php echo $vmerchantrefund_list->returnTime->headerCellClass() ?>"><div id="elh_vmerchantrefund_returnTime" class="vmerchantrefund_returnTime"><div class="ew-table-header-caption"><?php echo $vmerchantrefund_list->returnTime->caption() ?></div></div></th>
	<?php } else { ?>
		<th data-name="returnTime" class="<?php echo $vmerchantrefund_list->returnTime->headerCellClass() ?>"><div class="ew-pointer" onclick="ew.sort(event, '<?php echo $vmerchantrefund_list->SortUrl($vmerchantrefund_list->returnTime) ?>', 1);"><div id="elh_vmerchantrefund_returnTime" class="vmerchantrefund_returnTime">
			<div class="ew-table-header-btn"><span class="ew-table-header-caption"><?php echo $vmerchantrefund_list->returnTime->caption() ?></span><span class="ew-table-header-sort"><?php if ($vmerchantrefund_list->returnTime->getSort() == "ASC") { ?><i class="fas fa-sort-up"></i><?php } elseif ($vmerchantrefund_list->returnTime->getSort() == "DESC") { ?><i class="fas fa-sort-down"></i><?php } ?></span></div>
		</div></div></th>
	<?php } ?>
<?php } ?>
<?php if ($vmerchantrefund_list->merchantSurcharge->Visible) { // merchantSurcharge ?>
	<?php if ($vmerchantrefund_list->SortUrl($vmerchantrefund_list->merchantSurcharge) == "") { ?>
		<th data-name="merchantSurcharge" class="<?php echo $vmerchantrefund_list->merchantSurcharge->headerCellClass() ?>"><div id="elh_vmerchantrefund_merchantSurcharge" class="vmerchantrefund_merchantSurcharge"><div class="ew-table-header-caption"><?php echo $vmerchantrefund_list->merchantSurcharge->caption() ?></div></div></th>
	<?php } else { ?>
		<th data-name="merchantSurcharge" class="<?php echo $vmerchantrefund_list->merchantSurcharge->headerCellClass() ?>"><div class="ew-pointer" onclick="ew.sort(event, '<?php echo $vmerchantrefund_list->SortUrl($vmerchantrefund_list->merchantSurcharge) ?>', 1);"><div id="elh_vmerchantrefund_merchantSurcharge" class="vmerchantrefund_merchantSurcharge">
			<div class="ew-table-header-btn"><span class="ew-table-header-caption"><?php echo $vmerchantrefund_list->merchantSurcharge->caption() ?></span><span class="ew-table-header-sort"><?php if ($vmerchantrefund_list->merchantSurcharge->getSort() == "ASC") { ?><i class="fas fa-sort-up"></i><?php } elseif ($vmerchantrefund_list->merchantSurcharge->getSort() == "DESC") { ?><i class="fas fa-sort-down"></i><?php } ?></span></div>
		</div></div></th>
	<?php } ?>
<?php } ?>
<?php if ($vmerchantrefund_list->currID->Visible) { // currID ?>
	<?php if ($vmerchantrefund_list->SortUrl($vmerchantrefund_list->currID) == "") { ?>
		<th data-name="currID" class="<?php echo $vmerchantrefund_list->currID->headerCellClass() ?>"><div id="elh_vmerchantrefund_currID" class="vmerchantrefund_currID"><div class="ew-table-header-caption"><?php echo $vmerchantrefund_list->currID->caption() ?></div></div></th>
	<?php } else { ?>
		<th data-name="currID" class="<?php echo $vmerchantrefund_list->currID->headerCellClass() ?>"><div class="ew-pointer" onclick="ew.sort(event, '<?php echo $vmerchantrefund_list->SortUrl($vmerchantrefund_list->currID) ?>', 1);"><div id="elh_vmerchantrefund_currID" class="vmerchantrefund_currID">
			<div class="ew-table-header-btn"><span class="ew-table-header-caption"><?php echo $vmerchantrefund_list->currID->caption() ?><?php echo $Language->phrase("SrchLegend") ?></span><span class="ew-table-header-sort"><?php if ($vmerchantrefund_list->currID->getSort() == "ASC") { ?><i class="fas fa-sort-up"></i><?php } elseif ($vmerchantrefund_list->currID->getSort() == "DESC") { ?><i class="fas fa-sort-down"></i><?php } ?></span></div>
		</div></div></th>
	<?php } ?>
<?php } ?>
<?php if ($vmerchantrefund_list->purchaseAmount->Visible) { // purchaseAmount ?>
	<?php if ($vmerchantrefund_list->SortUrl($vmerchantrefund_list->purchaseAmount) == "") { ?>
		<th data-name="purchaseAmount" class="<?php echo $vmerchantrefund_list->purchaseAmount->headerCellClass() ?>"><div id="elh_vmerchantrefund_purchaseAmount" class="vmerchantrefund_purchaseAmount"><div class="ew-table-header-caption"><?php echo $vmerchantrefund_list->purchaseAmount->caption() ?></div></div></th>
	<?php } else { ?>
		<th data-name="purchaseAmount" class="<?php echo $vmerchantrefund_list->purchaseAmount->headerCellClass() ?>"><div class="ew-pointer" onclick="ew.sort(event, '<?php echo $vmerchantrefund_list->SortUrl($vmerchantrefund_list->purchaseAmount) ?>', 1);"><div id="elh_vmerchantrefund_purchaseAmount" class="vmerchantrefund_purchaseAmount">
			<div class="ew-table-header-btn"><span class="ew-table-header-caption"><?php echo $vmerchantrefund_list->purchaseAmount->caption() ?></span><span class="ew-table-header-sort"><?php if ($vmerchantrefund_list->purchaseAmount->getSort() == "ASC") { ?><i class="fas fa-sort-up"></i><?php } elseif ($vmerchantrefund_list->purchaseAmount->getSort() == "DESC") { ?><i class="fas fa-sort-down"></i><?php } ?></span></div>
		</div></div></th>
	<?php } ?>
<?php } ?>
<?php if ($vmerchantrefund_list->taxAmount->Visible) { // taxAmount ?>
	<?php if ($vmerchantrefund_list->SortUrl($vmerchantrefund_list->taxAmount) == "") { ?>
		<th data-name="taxAmount" class="<?php echo $vmerchantrefund_list->taxAmount->headerCellClass() ?>"><div id="elh_vmerchantrefund_taxAmount" class="vmerchantrefund_taxAmount"><div class="ew-table-header-caption"><?php echo $vmerchantrefund_list->taxAmount->caption() ?></div></div></th>
	<?php } else { ?>
		<th data-name="taxAmount" class="<?php echo $vmerchantrefund_list->taxAmount->headerCellClass() ?>"><div class="ew-pointer" onclick="ew.sort(event, '<?php echo $vmerchantrefund_list->SortUrl($vmerchantrefund_list->taxAmount) ?>', 1);"><div id="elh_vmerchantrefund_taxAmount" class="vmerchantrefund_taxAmount">
			<div class="ew-table-header-btn"><span class="ew-table-header-caption"><?php echo $vmerchantrefund_list->taxAmount->caption() ?></span><span class="ew-table-header-sort"><?php if ($vmerchantrefund_list->taxAmount->getSort() == "ASC") { ?><i class="fas fa-sort-up"></i><?php } elseif ($vmerchantrefund_list->taxAmount->getSort() == "DESC") { ?><i class="fas fa-sort-down"></i><?php } ?></span></div>
		</div></div></th>
	<?php } ?>
<?php } ?>
<?php if ($vmerchantrefund_list->tipAmount->Visible) { // tipAmount ?>
	<?php if ($vmerchantrefund_list->SortUrl($vmerchantrefund_list->tipAmount) == "") { ?>
		<th data-name="tipAmount" class="<?php echo $vmerchantrefund_list->tipAmount->headerCellClass() ?>"><div id="elh_vmerchantrefund_tipAmount" class="vmerchantrefund_tipAmount"><div class="ew-table-header-caption"><?php echo $vmerchantrefund_list->tipAmount->caption() ?></div></div></th>
	<?php } else { ?>
		<th data-name="tipAmount" class="<?php echo $vmerchantrefund_list->tipAmount->headerCellClass() ?>"><div class="ew-pointer" onclick="ew.sort(event, '<?php echo $vmerchantrefund_list->SortUrl($vmerchantrefund_list->tipAmount) ?>', 1);"><div id="elh_vmerchantrefund_tipAmount" class="vmerchantrefund_tipAmount">
			<div class="ew-table-header-btn"><span class="ew-table-header-caption"><?php echo $vmerchantrefund_list->tipAmount->caption() ?></span><span class="ew-table-header-sort"><?php if ($vmerchantrefund_list->tipAmount->getSort() == "ASC") { ?><i class="fas fa-sort-up"></i><?php } elseif ($vmerchantrefund_list->tipAmount->getSort() == "DESC") { ?><i class="fas fa-sort-down"></i><?php } ?></span></div>
		</div></div></th>
	<?php } ?>
<?php } ?>
<?php if ($vmerchantrefund_list->serviceFeeToCustomer->Visible) { // serviceFeeToCustomer ?>
	<?php if ($vmerchantrefund_list->SortUrl($vmerchantrefund_list->serviceFeeToCustomer) == "") { ?>
		<th data-name="serviceFeeToCustomer" class="<?php echo $vmerchantrefund_list->serviceFeeToCustomer->headerCellClass() ?>"><div id="elh_vmerchantrefund_serviceFeeToCustomer" class="vmerchantrefund_serviceFeeToCustomer"><div class="ew-table-header-caption"><?php echo $vmerchantrefund_list->serviceFeeToCustomer->caption() ?></div></div></th>
	<?php } else { ?>
		<th data-name="serviceFeeToCustomer" class="<?php echo $vmerchantrefund_list->serviceFeeToCustomer->headerCellClass() ?>"><div class="ew-pointer" onclick="ew.sort(event, '<?php echo $vmerchantrefund_list->SortUrl($vmerchantrefund_list->serviceFeeToCustomer) ?>', 1);"><div id="elh_vmerchantrefund_serviceFeeToCustomer" class="vmerchantrefund_serviceFeeToCustomer">
			<div class="ew-table-header-btn"><span class="ew-table-header-caption"><?php echo $vmerchantrefund_list->serviceFeeToCustomer->caption() ?></span><span class="ew-table-header-sort"><?php if ($vmerchantrefund_list->serviceFeeToCustomer->getSort() == "ASC") { ?><i class="fas fa-sort-up"></i><?php } elseif ($vmerchantrefund_list->serviceFeeToCustomer->getSort() == "DESC") { ?><i class="fas fa-sort-down"></i><?php } ?></span></div>
		</div></div></th>
	<?php } ?>
<?php } ?>
<?php if ($vmerchantrefund_list->TotalAmountForCustomer->Visible) { // TotalAmountForCustomer ?>
	<?php if ($vmerchantrefund_list->SortUrl($vmerchantrefund_list->TotalAmountForCustomer) == "") { ?>
		<th data-name="TotalAmountForCustomer" class="<?php echo $vmerchantrefund_list->TotalAmountForCustomer->headerCellClass() ?>"><div id="elh_vmerchantrefund_TotalAmountForCustomer" class="vmerchantrefund_TotalAmountForCustomer"><div class="ew-table-header-caption"><?php echo $vmerchantrefund_list->TotalAmountForCustomer->caption() ?></div></div></th>
	<?php } else { ?>
		<th data-name="TotalAmountForCustomer" class="<?php echo $vmerchantrefund_list->TotalAmountForCustomer->headerCellClass() ?>"><div class="ew-pointer" onclick="ew.sort(event, '<?php echo $vmerchantrefund_list->SortUrl($vmerchantrefund_list->TotalAmountForCustomer) ?>', 1);"><div id="elh_vmerchantrefund_TotalAmountForCustomer" class="vmerchantrefund_TotalAmountForCustomer">
			<div class="ew-table-header-btn"><span class="ew-table-header-caption"><?php echo $vmerchantrefund_list->TotalAmountForCustomer->caption() ?></span><span class="ew-table-header-sort"><?php if ($vmerchantrefund_list->TotalAmountForCustomer->getSort() == "ASC") { ?><i class="fas fa-sort-up"></i><?php } elseif ($vmerchantrefund_list->TotalAmountForCustomer->getSort() == "DESC") { ?><i class="fas fa-sort-down"></i><?php } ?></span></div>
		</div></div></th>
	<?php } ?>
<?php } ?>
<?php if ($vmerchantrefund_list->serviceFeeToMerchant->Visible) { // serviceFeeToMerchant ?>
	<?php if ($vmerchantrefund_list->SortUrl($vmerchantrefund_list->serviceFeeToMerchant) == "") { ?>
		<th data-name="serviceFeeToMerchant" class="<?php echo $vmerchantrefund_list->serviceFeeToMerchant->headerCellClass() ?>"><div id="elh_vmerchantrefund_serviceFeeToMerchant" class="vmerchantrefund_serviceFeeToMerchant"><div class="ew-table-header-caption"><?php echo $vmerchantrefund_list->serviceFeeToMerchant->caption() ?></div></div></th>
	<?php } else { ?>
		<th data-name="serviceFeeToMerchant" class="<?php echo $vmerchantrefund_list->serviceFeeToMerchant->headerCellClass() ?>"><div class="ew-pointer" onclick="ew.sort(event, '<?php echo $vmerchantrefund_list->SortUrl($vmerchantrefund_list->serviceFeeToMerchant) ?>', 1);"><div id="elh_vmerchantrefund_serviceFeeToMerchant" class="vmerchantrefund_serviceFeeToMerchant">
			<div class="ew-table-header-btn"><span class="ew-table-header-caption"><?php echo $vmerchantrefund_list->serviceFeeToMerchant->caption() ?></span><span class="ew-table-header-sort"><?php if ($vmerchantrefund_list->serviceFeeToMerchant->getSort() == "ASC") { ?><i class="fas fa-sort-up"></i><?php } elseif ($vmerchantrefund_list->serviceFeeToMerchant->getSort() == "DESC") { ?><i class="fas fa-sort-down"></i><?php } ?></span></div>
		</div></div></th>
	<?php } ?>
<?php } ?>
<?php if ($vmerchantrefund_list->merchantRefID->Visible) { // merchantRefID ?>
	<?php if ($vmerchantrefund_list->SortUrl($vmerchantrefund_list->merchantRefID) == "") { ?>
		<th data-name="merchantRefID" class="<?php echo $vmerchantrefund_list->merchantRefID->headerCellClass() ?>"><div id="elh_vmerchantrefund_merchantRefID" class="vmerchantrefund_merchantRefID"><div class="ew-table-header-caption"><?php echo $vmerchantrefund_list->merchantRefID->caption() ?></div></div></th>
	<?php } else { ?>
		<th data-name="merchantRefID" class="<?php echo $vmerchantrefund_list->merchantRefID->headerCellClass() ?>"><div class="ew-pointer" onclick="ew.sort(event, '<?php echo $vmerchantrefund_list->SortUrl($vmerchantrefund_list->merchantRefID) ?>', 1);"><div id="elh_vmerchantrefund_merchantRefID" class="vmerchantrefund_merchantRefID">
			<div class="ew-table-header-btn"><span class="ew-table-header-caption"><?php echo $vmerchantrefund_list->merchantRefID->caption() ?><?php echo $Language->phrase("SrchLegend") ?></span><span class="ew-table-header-sort"><?php if ($vmerchantrefund_list->merchantRefID->getSort() == "ASC") { ?><i class="fas fa-sort-up"></i><?php } elseif ($vmerchantrefund_list->merchantRefID->getSort() == "DESC") { ?><i class="fas fa-sort-down"></i><?php } ?></span></div>
		</div></div></th>
	<?php } ?>
<?php } ?>
<?php if ($vmerchantrefund_list->feesystemshare->Visible) { // feesystemshare ?>
	<?php if ($vmerchantrefund_list->SortUrl($vmerchantrefund_list->feesystemshare) == "") { ?>
		<th data-name="feesystemshare" class="<?php echo $vmerchantrefund_list->feesystemshare->headerCellClass() ?>"><div id="elh_vmerchantrefund_feesystemshare" class="vmerchantrefund_feesystemshare"><div class="ew-table-header-caption"><?php echo $vmerchantrefund_list->feesystemshare->caption() ?></div></div></th>
	<?php } else { ?>
		<th data-name="feesystemshare" class="<?php echo $vmerchantrefund_list->feesystemshare->headerCellClass() ?>"><div class="ew-pointer" onclick="ew.sort(event, '<?php echo $vmerchantrefund_list->SortUrl($vmerchantrefund_list->feesystemshare) ?>', 1);"><div id="elh_vmerchantrefund_feesystemshare" class="vmerchantrefund_feesystemshare">
			<div class="ew-table-header-btn"><span class="ew-table-header-caption"><?php echo $vmerchantrefund_list->feesystemshare->caption() ?></span><span class="ew-table-header-sort"><?php if ($vmerchantrefund_list->feesystemshare->getSort() == "ASC") { ?><i class="fas fa-sort-up"></i><?php } elseif ($vmerchantrefund_list->feesystemshare->getSort() == "DESC") { ?><i class="fas fa-sort-down"></i><?php } ?></span></div>
		</div></div></th>
	<?php } ?>
<?php } ?>
<?php if ($vmerchantrefund_list->feeexternalshare->Visible) { // feeexternalshare ?>
	<?php if ($vmerchantrefund_list->SortUrl($vmerchantrefund_list->feeexternalshare) == "") { ?>
		<th data-name="feeexternalshare" class="<?php echo $vmerchantrefund_list->feeexternalshare->headerCellClass() ?>"><div id="elh_vmerchantrefund_feeexternalshare" class="vmerchantrefund_feeexternalshare"><div class="ew-table-header-caption"><?php echo $vmerchantrefund_list->feeexternalshare->caption() ?></div></div></th>
	<?php } else { ?>
		<th data-name="feeexternalshare" class="<?php echo $vmerchantrefund_list->feeexternalshare->headerCellClass() ?>"><div class="ew-pointer" onclick="ew.sort(event, '<?php echo $vmerchantrefund_list->SortUrl($vmerchantrefund_list->feeexternalshare) ?>', 1);"><div id="elh_vmerchantrefund_feeexternalshare" class="vmerchantrefund_feeexternalshare">
			<div class="ew-table-header-btn"><span class="ew-table-header-caption"><?php echo $vmerchantrefund_list->feeexternalshare->caption() ?></span><span class="ew-table-header-sort"><?php if ($vmerchantrefund_list->feeexternalshare->getSort() == "ASC") { ?><i class="fas fa-sort-up"></i><?php } elseif ($vmerchantrefund_list->feeexternalshare->getSort() == "DESC") { ?><i class="fas fa-sort-down"></i><?php } ?></span></div>
		</div></div></th>
	<?php } ?>
<?php } ?>
<?php if ($vmerchantrefund_list->feefranchiseeshare->Visible) { // feefranchiseeshare ?>
	<?php if ($vmerchantrefund_list->SortUrl($vmerchantrefund_list->feefranchiseeshare) == "") { ?>
		<th data-name="feefranchiseeshare" class="<?php echo $vmerchantrefund_list->feefranchiseeshare->headerCellClass() ?>"><div id="elh_vmerchantrefund_feefranchiseeshare" class="vmerchantrefund_feefranchiseeshare"><div class="ew-table-header-caption"><?php echo $vmerchantrefund_list->feefranchiseeshare->caption() ?></div></div></th>
	<?php } else { ?>
		<th data-name="feefranchiseeshare" class="<?php echo $vmerchantrefund_list->feefranchiseeshare->headerCellClass() ?>"><div class="ew-pointer" onclick="ew.sort(event, '<?php echo $vmerchantrefund_list->SortUrl($vmerchantrefund_list->feefranchiseeshare) ?>', 1);"><div id="elh_vmerchantrefund_feefranchiseeshare" class="vmerchantrefund_feefranchiseeshare">
			<div class="ew-table-header-btn"><span class="ew-table-header-caption"><?php echo $vmerchantrefund_list->feefranchiseeshare->caption() ?></span><span class="ew-table-header-sort"><?php if ($vmerchantrefund_list->feefranchiseeshare->getSort() == "ASC") { ?><i class="fas fa-sort-up"></i><?php } elseif ($vmerchantrefund_list->feefranchiseeshare->getSort() == "DESC") { ?><i class="fas fa-sort-down"></i><?php } ?></span></div>
		</div></div></th>
	<?php } ?>
<?php } ?>
<?php if ($vmerchantrefund_list->feeresellershare->Visible) { // feeresellershare ?>
	<?php if ($vmerchantrefund_list->SortUrl($vmerchantrefund_list->feeresellershare) == "") { ?>
		<th data-name="feeresellershare" class="<?php echo $vmerchantrefund_list->feeresellershare->headerCellClass() ?>"><div id="elh_vmerchantrefund_feeresellershare" class="vmerchantrefund_feeresellershare"><div class="ew-table-header-caption"><?php echo $vmerchantrefund_list->feeresellershare->caption() ?></div></div></th>
	<?php } else { ?>
		<th data-name="feeresellershare" class="<?php echo $vmerchantrefund_list->feeresellershare->headerCellClass() ?>"><div class="ew-pointer" onclick="ew.sort(event, '<?php echo $vmerchantrefund_list->SortUrl($vmerchantrefund_list->feeresellershare) ?>', 1);"><div id="elh_vmerchantrefund_feeresellershare" class="vmerchantrefund_feeresellershare">
			<div class="ew-table-header-btn"><span class="ew-table-header-caption"><?php echo $vmerchantrefund_list->feeresellershare->caption() ?></span><span class="ew-table-header-sort"><?php if ($vmerchantrefund_list->feeresellershare->getSort() == "ASC") { ?><i class="fas fa-sort-up"></i><?php } elseif ($vmerchantrefund_list->feeresellershare->getSort() == "DESC") { ?><i class="fas fa-sort-down"></i><?php } ?></span></div>
		</div></div></th>
	<?php } ?>
<?php } ?>
<?php if ($vmerchantrefund_list->userpiid->Visible) { // userpiid ?>
	<?php if ($vmerchantrefund_list->SortUrl($vmerchantrefund_list->userpiid) == "") { ?>
		<th data-name="userpiid" class="<?php echo $vmerchantrefund_list->userpiid->headerCellClass() ?>"><div id="elh_vmerchantrefund_userpiid" class="vmerchantrefund_userpiid"><div class="ew-table-header-caption"><?php echo $vmerchantrefund_list->userpiid->caption() ?></div></div></th>
	<?php } else { ?>
		<th data-name="userpiid" class="<?php echo $vmerchantrefund_list->userpiid->headerCellClass() ?>"><div class="ew-pointer" onclick="ew.sort(event, '<?php echo $vmerchantrefund_list->SortUrl($vmerchantrefund_list->userpiid) ?>', 1);"><div id="elh_vmerchantrefund_userpiid" class="vmerchantrefund_userpiid">
			<div class="ew-table-header-btn"><span class="ew-table-header-caption"><?php echo $vmerchantrefund_list->userpiid->caption() ?></span><span class="ew-table-header-sort"><?php if ($vmerchantrefund_list->userpiid->getSort() == "ASC") { ?><i class="fas fa-sort-up"></i><?php } elseif ($vmerchantrefund_list->userpiid->getSort() == "DESC") { ?><i class="fas fa-sort-down"></i><?php } ?></span></div>
		</div></div></th>
	<?php } ?>
<?php } ?>
<?php if ($vmerchantrefund_list->businessname->Visible) { // businessname ?>
	<?php if ($vmerchantrefund_list->SortUrl($vmerchantrefund_list->businessname) == "") { ?>
		<th data-name="businessname" class="<?php echo $vmerchantrefund_list->businessname->headerCellClass() ?>"><div id="elh_vmerchantrefund_businessname" class="vmerchantrefund_businessname"><div class="ew-table-header-caption"><?php echo $vmerchantrefund_list->businessname->caption() ?></div></div></th>
	<?php } else { ?>
		<th data-name="businessname" class="<?php echo $vmerchantrefund_list->businessname->headerCellClass() ?>"><div class="ew-pointer" onclick="ew.sort(event, '<?php echo $vmerchantrefund_list->SortUrl($vmerchantrefund_list->businessname) ?>', 1);"><div id="elh_vmerchantrefund_businessname" class="vmerchantrefund_businessname">
			<div class="ew-table-header-btn"><span class="ew-table-header-caption"><?php echo $vmerchantrefund_list->businessname->caption() ?><?php echo $Language->phrase("SrchLegend") ?></span><span class="ew-table-header-sort"><?php if ($vmerchantrefund_list->businessname->getSort() == "ASC") { ?><i class="fas fa-sort-up"></i><?php } elseif ($vmerchantrefund_list->businessname->getSort() == "DESC") { ?><i class="fas fa-sort-down"></i><?php } ?></span></div>
		</div></div></th>
	<?php } ?>
<?php } ?>
<?php if ($vmerchantrefund_list->originalpurchaseamount->Visible) { // originalpurchaseamount ?>
	<?php if ($vmerchantrefund_list->SortUrl($vmerchantrefund_list->originalpurchaseamount) == "") { ?>
		<th data-name="originalpurchaseamount" class="<?php echo $vmerchantrefund_list->originalpurchaseamount->headerCellClass() ?>"><div id="elh_vmerchantrefund_originalpurchaseamount" class="vmerchantrefund_originalpurchaseamount"><div class="ew-table-header-caption"><?php echo $vmerchantrefund_list->originalpurchaseamount->caption() ?></div></div></th>
	<?php } else { ?>
		<th data-name="originalpurchaseamount" class="<?php echo $vmerchantrefund_list->originalpurchaseamount->headerCellClass() ?>"><div class="ew-pointer" onclick="ew.sort(event, '<?php echo $vmerchantrefund_list->SortUrl($vmerchantrefund_list->originalpurchaseamount) ?>', 1);"><div id="elh_vmerchantrefund_originalpurchaseamount" class="vmerchantrefund_originalpurchaseamount">
			<div class="ew-table-header-btn"><span class="ew-table-header-caption"><?php echo $vmerchantrefund_list->originalpurchaseamount->caption() ?></span><span class="ew-table-header-sort"><?php if ($vmerchantrefund_list->originalpurchaseamount->getSort() == "ASC") { ?><i class="fas fa-sort-up"></i><?php } elseif ($vmerchantrefund_list->originalpurchaseamount->getSort() == "DESC") { ?><i class="fas fa-sort-down"></i><?php } ?></span></div>
		</div></div></th>
	<?php } ?>
<?php } ?>
<?php if ($vmerchantrefund_list->transferTime->Visible) { // transferTime ?>
	<?php if ($vmerchantrefund_list->SortUrl($vmerchantrefund_list->transferTime) == "") { ?>
		<th data-name="transferTime" class="<?php echo $vmerchantrefund_list->transferTime->headerCellClass() ?>"><div id="elh_vmerchantrefund_transferTime" class="vmerchantrefund_transferTime"><div class="ew-table-header-caption"><?php echo $vmerchantrefund_list->transferTime->caption() ?></div></div></th>
	<?php } else { ?>
		<th data-name="transferTime" class="<?php echo $vmerchantrefund_list->transferTime->headerCellClass() ?>"><div class="ew-pointer" onclick="ew.sort(event, '<?php echo $vmerchantrefund_list->SortUrl($vmerchantrefund_list->transferTime) ?>', 1);"><div id="elh_vmerchantrefund_transferTime" class="vmerchantrefund_transferTime">
			<div class="ew-table-header-btn"><span class="ew-table-header-caption"><?php echo $vmerchantrefund_list->transferTime->caption() ?></span><span class="ew-table-header-sort"><?php if ($vmerchantrefund_list->transferTime->getSort() == "ASC") { ?><i class="fas fa-sort-up"></i><?php } elseif ($vmerchantrefund_list->transferTime->getSort() == "DESC") { ?><i class="fas fa-sort-down"></i><?php } ?></span></div>
		</div></div></th>
	<?php } ?>
<?php } ?>
<?php if ($vmerchantrefund_list->merchantuserid->Visible) { // merchantuserid ?>
	<?php if ($vmerchantrefund_list->SortUrl($vmerchantrefund_list->merchantuserid) == "") { ?>
		<th data-name="merchantuserid" class="<?php echo $vmerchantrefund_list->merchantuserid->headerCellClass() ?>"><div id="elh_vmerchantrefund_merchantuserid" class="vmerchantrefund_merchantuserid"><div class="ew-table-header-caption"><?php echo $vmerchantrefund_list->merchantuserid->caption() ?></div></div></th>
	<?php } else { ?>
		<th data-name="merchantuserid" class="<?php echo $vmerchantrefund_list->merchantuserid->headerCellClass() ?>"><div class="ew-pointer" onclick="ew.sort(event, '<?php echo $vmerchantrefund_list->SortUrl($vmerchantrefund_list->merchantuserid) ?>', 1);"><div id="elh_vmerchantrefund_merchantuserid" class="vmerchantrefund_merchantuserid">
			<div class="ew-table-header-btn"><span class="ew-table-header-caption"><?php echo $vmerchantrefund_list->merchantuserid->caption() ?></span><span class="ew-table-header-sort"><?php if ($vmerchantrefund_list->merchantuserid->getSort() == "ASC") { ?><i class="fas fa-sort-up"></i><?php } elseif ($vmerchantrefund_list->merchantuserid->getSort() == "DESC") { ?><i class="fas fa-sort-down"></i><?php } ?></span></div>
		</div></div></th>
	<?php } ?>
<?php } ?>
<?php if ($vmerchantrefund_list->firstName->Visible) { // firstName ?>
	<?php if ($vmerchantrefund_list->SortUrl($vmerchantrefund_list->firstName) == "") { ?>
		<th data-name="firstName" class="<?php echo $vmerchantrefund_list->firstName->headerCellClass() ?>"><div id="elh_vmerchantrefund_firstName" class="vmerchantrefund_firstName"><div class="ew-table-header-caption"><?php echo $vmerchantrefund_list->firstName->caption() ?></div></div></th>
	<?php } else { ?>
		<th data-name="firstName" class="<?php echo $vmerchantrefund_list->firstName->headerCellClass() ?>"><div class="ew-pointer" onclick="ew.sort(event, '<?php echo $vmerchantrefund_list->SortUrl($vmerchantrefund_list->firstName) ?>', 1);"><div id="elh_vmerchantrefund_firstName" class="vmerchantrefund_firstName">
			<div class="ew-table-header-btn"><span class="ew-table-header-caption"><?php echo $vmerchantrefund_list->firstName->caption() ?><?php echo $Language->phrase("SrchLegend") ?></span><span class="ew-table-header-sort"><?php if ($vmerchantrefund_list->firstName->getSort() == "ASC") { ?><i class="fas fa-sort-up"></i><?php } elseif ($vmerchantrefund_list->firstName->getSort() == "DESC") { ?><i class="fas fa-sort-down"></i><?php } ?></span></div>
		</div></div></th>
	<?php } ?>
<?php } ?>
<?php if ($vmerchantrefund_list->lastName->Visible) { // lastName ?>
	<?php if ($vmerchantrefund_list->SortUrl($vmerchantrefund_list->lastName) == "") { ?>
		<th data-name="lastName" class="<?php echo $vmerchantrefund_list->lastName->headerCellClass() ?>"><div id="elh_vmerchantrefund_lastName" class="vmerchantrefund_lastName"><div class="ew-table-header-caption"><?php echo $vmerchantrefund_list->lastName->caption() ?></div></div></th>
	<?php } else { ?>
		<th data-name="lastName" class="<?php echo $vmerchantrefund_list->lastName->headerCellClass() ?>"><div class="ew-pointer" onclick="ew.sort(event, '<?php echo $vmerchantrefund_list->SortUrl($vmerchantrefund_list->lastName) ?>', 1);"><div id="elh_vmerchantrefund_lastName" class="vmerchantrefund_lastName">
			<div class="ew-table-header-btn"><span class="ew-table-header-caption"><?php echo $vmerchantrefund_list->lastName->caption() ?><?php echo $Language->phrase("SrchLegend") ?></span><span class="ew-table-header-sort"><?php if ($vmerchantrefund_list->lastName->getSort() == "ASC") { ?><i class="fas fa-sort-up"></i><?php } elseif ($vmerchantrefund_list->lastName->getSort() == "DESC") { ?><i class="fas fa-sort-down"></i><?php } ?></span></div>
		</div></div></th>
	<?php } ?>
<?php } ?>
<?php if ($vmerchantrefund_list->customerpurchaseid->Visible) { // customerpurchaseid ?>
	<?php if ($vmerchantrefund_list->SortUrl($vmerchantrefund_list->customerpurchaseid) == "") { ?>
		<th data-name="customerpurchaseid" class="<?php echo $vmerchantrefund_list->customerpurchaseid->headerCellClass() ?>"><div id="elh_vmerchantrefund_customerpurchaseid" class="vmerchantrefund_customerpurchaseid"><div class="ew-table-header-caption"><?php echo $vmerchantrefund_list->customerpurchaseid->caption() ?></div></div></th>
	<?php } else { ?>
		<th data-name="customerpurchaseid" class="<?php echo $vmerchantrefund_list->customerpurchaseid->headerCellClass() ?>"><div class="ew-pointer" onclick="ew.sort(event, '<?php echo $vmerchantrefund_list->SortUrl($vmerchantrefund_list->customerpurchaseid) ?>', 1);"><div id="elh_vmerchantrefund_customerpurchaseid" class="vmerchantrefund_customerpurchaseid">
			<div class="ew-table-header-btn"><span class="ew-table-header-caption"><?php echo $vmerchantrefund_list->customerpurchaseid->caption() ?></span><span class="ew-table-header-sort"><?php if ($vmerchantrefund_list->customerpurchaseid->getSort() == "ASC") { ?><i class="fas fa-sort-up"></i><?php } elseif ($vmerchantrefund_list->customerpurchaseid->getSort() == "DESC") { ?><i class="fas fa-sort-down"></i><?php } ?></span></div>
		</div></div></th>
	<?php } ?>
<?php } ?>
<?php

// Render list options (header, right)
$vmerchantrefund_list->ListOptions->render("header", "right");
?>
	</tr>
</thead>
<tbody>
<?php
if ($vmerchantrefund_list->ExportAll && $vmerchantrefund_list->isExport()) {
	$vmerchantrefund_list->StopRecord = $vmerchantrefund_list->TotalRecords;
} else {

	// Set the last record to display
	if ($vmerchantrefund_list->TotalRecords > $vmerchantrefund_list->StartRecord + $vmerchantrefund_list->DisplayRecords - 1)
		$vmerchantrefund_list->StopRecord = $vmerchantrefund_list->StartRecord + $vmerchantrefund_list->DisplayRecords - 1;
	else
		$vmerchantrefund_list->StopRecord = $vmerchantrefund_list->TotalRecords;
}
$vmerchantrefund_list->RecordCount = $vmerchantrefund_list->StartRecord - 1;
if ($vmerchantrefund_list->Recordset && !$vmerchantrefund_list->Recordset->EOF) {
	$vmerchantrefund_list->Recordset->moveFirst();
	$selectLimit = $vmerchantrefund_list->UseSelectLimit;
	if (!$selectLimit && $vmerchantrefund_list->StartRecord > 1)
		$vmerchantrefund_list->Recordset->move($vmerchantrefund_list->StartRecord - 1);
} elseif (!$vmerchantrefund->AllowAddDeleteRow && $vmerchantrefund_list->StopRecord == 0) {
	$vmerchantrefund_list->StopRecord = $vmerchantrefund->GridAddRowCount;
}

// Initialize aggregate
$vmerchantrefund->RowType = ROWTYPE_AGGREGATEINIT;
$vmerchantrefund->resetAttributes();
$vmerchantrefund_list->renderRow();
while ($vmerchantrefund_list->RecordCount < $vmerchantrefund_list->StopRecord) {
	$vmerchantrefund_list->RecordCount++;
	if ($vmerchantrefund_list->RecordCount >= $vmerchantrefund_list->StartRecord) {
		$vmerchantrefund_list->RowCount++;

		// Set up key count
		$vmerchantrefund_list->KeyCount = $vmerchantrefund_list->RowIndex;

		// Init row class and style
		$vmerchantrefund->resetAttributes();
		$vmerchantrefund->CssClass = "";
		if ($vmerchantrefund_list->isGridAdd()) {
		} else {
			$vmerchantrefund_list->loadRowValues($vmerchantrefund_list->Recordset); // Load row values
		}
		$vmerchantrefund->RowType = ROWTYPE_VIEW; // Render view

		// Set up row id / data-rowindex
		$vmerchantrefund->RowAttrs->merge(["data-rowindex" => $vmerchantrefund_list->RowCount, "id" => "r" . $vmerchantrefund_list->RowCount . "_vmerchantrefund", "data-rowtype" => $vmerchantrefund->RowType]);

		// Render row
		$vmerchantrefund_list->renderRow();

		// Render list options
		$vmerchantrefund_list->renderListOptions();
?>
	<tr <?php echo $vmerchantrefund->rowAttributes() ?>>
<?php

// Render list options (body, left)
$vmerchantrefund_list->ListOptions->render("body", "left", $vmerchantrefund_list->RowCount);
?>
	<?php if ($vmerchantrefund_list->transferID->Visible) { // transferID ?>
		<td data-name="transferID" <?php echo $vmerchantrefund_list->transferID->cellAttributes() ?>>
<span id="el<?php echo $vmerchantrefund_list->RowCount ?>_vmerchantrefund_transferID">
<span<?php echo $vmerchantrefund_list->transferID->viewAttributes() ?>><?php echo $vmerchantrefund_list->transferID->getViewValue() ?></span>
</span>
</td>
	<?php } ?>
	<?php if ($vmerchantrefund_list->merchantid->Visible) { // merchantid ?>
		<td data-name="merchantid" <?php echo $vmerchantrefund_list->merchantid->cellAttributes() ?>>
<span id="el<?php echo $vmerchantrefund_list->RowCount ?>_vmerchantrefund_merchantid">
<span<?php echo $vmerchantrefund_list->merchantid->viewAttributes() ?>><?php echo $vmerchantrefund_list->merchantid->getViewValue() ?></span>
</span>
</td>
	<?php } ?>
	<?php if ($vmerchantrefund_list->txid->Visible) { // txid ?>
		<td data-name="txid" <?php echo $vmerchantrefund_list->txid->cellAttributes() ?>>
<span id="el<?php echo $vmerchantrefund_list->RowCount ?>_vmerchantrefund_txid">
<span<?php echo $vmerchantrefund_list->txid->viewAttributes() ?>><?php echo $vmerchantrefund_list->txid->getViewValue() ?></span>
</span>
</td>
	<?php } ?>
	<?php if ($vmerchantrefund_list->returnTime->Visible) { // returnTime ?>
		<td data-name="returnTime" <?php echo $vmerchantrefund_list->returnTime->cellAttributes() ?>>
<span id="el<?php echo $vmerchantrefund_list->RowCount ?>_vmerchantrefund_returnTime">
<span<?php echo $vmerchantrefund_list->returnTime->viewAttributes() ?>><?php echo $vmerchantrefund_list->returnTime->getViewValue() ?></span>
</span>
</td>
	<?php } ?>
	<?php if ($vmerchantrefund_list->merchantSurcharge->Visible) { // merchantSurcharge ?>
		<td data-name="merchantSurcharge" <?php echo $vmerchantrefund_list->merchantSurcharge->cellAttributes() ?>>
<span id="el<?php echo $vmerchantrefund_list->RowCount ?>_vmerchantrefund_merchantSurcharge">
<span<?php echo $vmerchantrefund_list->merchantSurcharge->viewAttributes() ?>><?php echo $vmerchantrefund_list->merchantSurcharge->getViewValue() ?></span>
</span>
</td>
	<?php } ?>
	<?php if ($vmerchantrefund_list->currID->Visible) { // currID ?>
		<td data-name="currID" <?php echo $vmerchantrefund_list->currID->cellAttributes() ?>>
<span id="el<?php echo $vmerchantrefund_list->RowCount ?>_vmerchantrefund_currID">
<span<?php echo $vmerchantrefund_list->currID->viewAttributes() ?>><?php echo $vmerchantrefund_list->currID->getViewValue() ?></span>
</span>
</td>
	<?php } ?>
	<?php if ($vmerchantrefund_list->purchaseAmount->Visible) { // purchaseAmount ?>
		<td data-name="purchaseAmount" <?php echo $vmerchantrefund_list->purchaseAmount->cellAttributes() ?>>
<span id="el<?php echo $vmerchantrefund_list->RowCount ?>_vmerchantrefund_purchaseAmount">
<span<?php echo $vmerchantrefund_list->purchaseAmount->viewAttributes() ?>><?php echo $vmerchantrefund_list->purchaseAmount->getViewValue() ?></span>
</span>
</td>
	<?php } ?>
	<?php if ($vmerchantrefund_list->taxAmount->Visible) { // taxAmount ?>
		<td data-name="taxAmount" <?php echo $vmerchantrefund_list->taxAmount->cellAttributes() ?>>
<span id="el<?php echo $vmerchantrefund_list->RowCount ?>_vmerchantrefund_taxAmount">
<span<?php echo $vmerchantrefund_list->taxAmount->viewAttributes() ?>><?php echo $vmerchantrefund_list->taxAmount->getViewValue() ?></span>
</span>
</td>
	<?php } ?>
	<?php if ($vmerchantrefund_list->tipAmount->Visible) { // tipAmount ?>
		<td data-name="tipAmount" <?php echo $vmerchantrefund_list->tipAmount->cellAttributes() ?>>
<span id="el<?php echo $vmerchantrefund_list->RowCount ?>_vmerchantrefund_tipAmount">
<span<?php echo $vmerchantrefund_list->tipAmount->viewAttributes() ?>><?php echo $vmerchantrefund_list->tipAmount->getViewValue() ?></span>
</span>
</td>
	<?php } ?>
	<?php if ($vmerchantrefund_list->serviceFeeToCustomer->Visible) { // serviceFeeToCustomer ?>
		<td data-name="serviceFeeToCustomer" <?php echo $vmerchantrefund_list->serviceFeeToCustomer->cellAttributes() ?>>
<span id="el<?php echo $vmerchantrefund_list->RowCount ?>_vmerchantrefund_serviceFeeToCustomer">
<span<?php echo $vmerchantrefund_list->serviceFeeToCustomer->viewAttributes() ?>><?php echo $vmerchantrefund_list->serviceFeeToCustomer->getViewValue() ?></span>
</span>
</td>
	<?php } ?>
	<?php if ($vmerchantrefund_list->TotalAmountForCustomer->Visible) { // TotalAmountForCustomer ?>
		<td data-name="TotalAmountForCustomer" <?php echo $vmerchantrefund_list->TotalAmountForCustomer->cellAttributes() ?>>
<span id="el<?php echo $vmerchantrefund_list->RowCount ?>_vmerchantrefund_TotalAmountForCustomer">
<span<?php echo $vmerchantrefund_list->TotalAmountForCustomer->viewAttributes() ?>><?php echo $vmerchantrefund_list->TotalAmountForCustomer->getViewValue() ?></span>
</span>
</td>
	<?php } ?>
	<?php if ($vmerchantrefund_list->serviceFeeToMerchant->Visible) { // serviceFeeToMerchant ?>
		<td data-name="serviceFeeToMerchant" <?php echo $vmerchantrefund_list->serviceFeeToMerchant->cellAttributes() ?>>
<span id="el<?php echo $vmerchantrefund_list->RowCount ?>_vmerchantrefund_serviceFeeToMerchant">
<span<?php echo $vmerchantrefund_list->serviceFeeToMerchant->viewAttributes() ?>><?php echo $vmerchantrefund_list->serviceFeeToMerchant->getViewValue() ?></span>
</span>
</td>
	<?php } ?>
	<?php if ($vmerchantrefund_list->merchantRefID->Visible) { // merchantRefID ?>
		<td data-name="merchantRefID" <?php echo $vmerchantrefund_list->merchantRefID->cellAttributes() ?>>
<span id="el<?php echo $vmerchantrefund_list->RowCount ?>_vmerchantrefund_merchantRefID">
<span<?php echo $vmerchantrefund_list->merchantRefID->viewAttributes() ?>><?php echo $vmerchantrefund_list->merchantRefID->getViewValue() ?></span>
</span>
</td>
	<?php } ?>
	<?php if ($vmerchantrefund_list->feesystemshare->Visible) { // feesystemshare ?>
		<td data-name="feesystemshare" <?php echo $vmerchantrefund_list->feesystemshare->cellAttributes() ?>>
<span id="el<?php echo $vmerchantrefund_list->RowCount ?>_vmerchantrefund_feesystemshare">
<span<?php echo $vmerchantrefund_list->feesystemshare->viewAttributes() ?>><?php echo $vmerchantrefund_list->feesystemshare->getViewValue() ?></span>
</span>
</td>
	<?php } ?>
	<?php if ($vmerchantrefund_list->feeexternalshare->Visible) { // feeexternalshare ?>
		<td data-name="feeexternalshare" <?php echo $vmerchantrefund_list->feeexternalshare->cellAttributes() ?>>
<span id="el<?php echo $vmerchantrefund_list->RowCount ?>_vmerchantrefund_feeexternalshare">
<span<?php echo $vmerchantrefund_list->feeexternalshare->viewAttributes() ?>><?php echo $vmerchantrefund_list->feeexternalshare->getViewValue() ?></span>
</span>
</td>
	<?php } ?>
	<?php if ($vmerchantrefund_list->feefranchiseeshare->Visible) { // feefranchiseeshare ?>
		<td data-name="feefranchiseeshare" <?php echo $vmerchantrefund_list->feefranchiseeshare->cellAttributes() ?>>
<span id="el<?php echo $vmerchantrefund_list->RowCount ?>_vmerchantrefund_feefranchiseeshare">
<span<?php echo $vmerchantrefund_list->feefranchiseeshare->viewAttributes() ?>><?php echo $vmerchantrefund_list->feefranchiseeshare->getViewValue() ?></span>
</span>
</td>
	<?php } ?>
	<?php if ($vmerchantrefund_list->feeresellershare->Visible) { // feeresellershare ?>
		<td data-name="feeresellershare" <?php echo $vmerchantrefund_list->feeresellershare->cellAttributes() ?>>
<span id="el<?php echo $vmerchantrefund_list->RowCount ?>_vmerchantrefund_feeresellershare">
<span<?php echo $vmerchantrefund_list->feeresellershare->viewAttributes() ?>><?php echo $vmerchantrefund_list->feeresellershare->getViewValue() ?></span>
</span>
</td>
	<?php } ?>
	<?php if ($vmerchantrefund_list->userpiid->Visible) { // userpiid ?>
		<td data-name="userpiid" <?php echo $vmerchantrefund_list->userpiid->cellAttributes() ?>>
<span id="el<?php echo $vmerchantrefund_list->RowCount ?>_vmerchantrefund_userpiid">
<span<?php echo $vmerchantrefund_list->userpiid->viewAttributes() ?>><?php echo $vmerchantrefund_list->userpiid->getViewValue() ?></span>
</span>
</td>
	<?php } ?>
	<?php if ($vmerchantrefund_list->businessname->Visible) { // businessname ?>
		<td data-name="businessname" <?php echo $vmerchantrefund_list->businessname->cellAttributes() ?>>
<span id="el<?php echo $vmerchantrefund_list->RowCount ?>_vmerchantrefund_businessname">
<span<?php echo $vmerchantrefund_list->businessname->viewAttributes() ?>><?php echo $vmerchantrefund_list->businessname->getViewValue() ?></span>
</span>
</td>
	<?php } ?>
	<?php if ($vmerchantrefund_list->originalpurchaseamount->Visible) { // originalpurchaseamount ?>
		<td data-name="originalpurchaseamount" <?php echo $vmerchantrefund_list->originalpurchaseamount->cellAttributes() ?>>
<span id="el<?php echo $vmerchantrefund_list->RowCount ?>_vmerchantrefund_originalpurchaseamount">
<span<?php echo $vmerchantrefund_list->originalpurchaseamount->viewAttributes() ?>><?php echo $vmerchantrefund_list->originalpurchaseamount->getViewValue() ?></span>
</span>
</td>
	<?php } ?>
	<?php if ($vmerchantrefund_list->transferTime->Visible) { // transferTime ?>
		<td data-name="transferTime" <?php echo $vmerchantrefund_list->transferTime->cellAttributes() ?>>
<span id="el<?php echo $vmerchantrefund_list->RowCount ?>_vmerchantrefund_transferTime">
<span<?php echo $vmerchantrefund_list->transferTime->viewAttributes() ?>><?php echo $vmerchantrefund_list->transferTime->getViewValue() ?></span>
</span>
</td>
	<?php } ?>
	<?php if ($vmerchantrefund_list->merchantuserid->Visible) { // merchantuserid ?>
		<td data-name="merchantuserid" <?php echo $vmerchantrefund_list->merchantuserid->cellAttributes() ?>>
<span id="el<?php echo $vmerchantrefund_list->RowCount ?>_vmerchantrefund_merchantuserid">
<span<?php echo $vmerchantrefund_list->merchantuserid->viewAttributes() ?>><?php echo $vmerchantrefund_list->merchantuserid->getViewValue() ?></span>
</span>
</td>
	<?php } ?>
	<?php if ($vmerchantrefund_list->firstName->Visible) { // firstName ?>
		<td data-name="firstName" <?php echo $vmerchantrefund_list->firstName->cellAttributes() ?>>
<span id="el<?php echo $vmerchantrefund_list->RowCount ?>_vmerchantrefund_firstName">
<span<?php echo $vmerchantrefund_list->firstName->viewAttributes() ?>><?php echo $vmerchantrefund_list->firstName->getViewValue() ?></span>
</span>
</td>
	<?php } ?>
	<?php if ($vmerchantrefund_list->lastName->Visible) { // lastName ?>
		<td data-name="lastName" <?php echo $vmerchantrefund_list->lastName->cellAttributes() ?>>
<span id="el<?php echo $vmerchantrefund_list->RowCount ?>_vmerchantrefund_lastName">
<span<?php echo $vmerchantrefund_list->lastName->viewAttributes() ?>><?php echo $vmerchantrefund_list->lastName->getViewValue() ?></span>
</span>
</td>
	<?php } ?>
	<?php if ($vmerchantrefund_list->customerpurchaseid->Visible) { // customerpurchaseid ?>
		<td data-name="customerpurchaseid" <?php echo $vmerchantrefund_list->customerpurchaseid->cellAttributes() ?>>
<span id="el<?php echo $vmerchantrefund_list->RowCount ?>_vmerchantrefund_customerpurchaseid">
<span<?php echo $vmerchantrefund_list->customerpurchaseid->viewAttributes() ?>><?php echo $vmerchantrefund_list->customerpurchaseid->getViewValue() ?></span>
</span>
</td>
	<?php } ?>
<?php

// Render list options (body, right)
$vmerchantrefund_list->ListOptions->render("body", "right", $vmerchantrefund_list->RowCount);
?>
	</tr>
<?php
	}
	if (!$vmerchantrefund_list->isGridAdd())
		$vmerchantrefund_list->Recordset->moveNext();
}
?>
</tbody>
</table><!-- /.ew-table -->
<?php } ?>
</div><!-- /.ew-grid-middle-panel -->
<?php if (!$vmerchantrefund->CurrentAction) { ?>
<input type="hidden" name="action" id="action" value="">
<?php } ?>
</form><!-- /.ew-list-form -->
<?php

// Close recordset
if ($vmerchantrefund_list->Recordset)
	$vmerchantrefund_list->Recordset->Close();
?>
<?php if (!$vmerchantrefund_list->isExport()) { ?>
<div class="card-footer ew-grid-lower-panel">
<?php if (!$vmerchantrefund_list->isGridAdd()) { ?>
<form name="ew-pager-form" class="form-inline ew-form ew-pager-form" action="<?php echo CurrentPageName() ?>">
<?php echo $vmerchantrefund_list->Pager->render() ?>
</form>
<?php } ?>
<div class="ew-list-other-options">
<?php $vmerchantrefund_list->OtherOptions->render("body", "bottom") ?>
</div>
<div class="clearfix"></div>
</div>
<?php } ?>
</div><!-- /.ew-grid -->
<?php } ?>
<?php if ($vmerchantrefund_list->TotalRecords == 0 && !$vmerchantrefund->CurrentAction) { // Show other options ?>
<div class="ew-list-other-options">
<?php $vmerchantrefund_list->OtherOptions->render("body") ?>
</div>
<div class="clearfix"></div>
<?php } ?>
<?php
$vmerchantrefund_list->showPageFooter();
if (Config("DEBUG"))
	echo GetDebugMessage();
?>
<?php if (!$vmerchantrefund_list->isExport()) { ?>
<script>
loadjs.ready("load", function() {

	// Startup script
	// Write your table-specific startup script here
	// console.log("page loaded");

});
</script>
<?php } ?>
<?php include_once "footer.php"; ?>
<?php
$vmerchantrefund_list->terminate();
?>