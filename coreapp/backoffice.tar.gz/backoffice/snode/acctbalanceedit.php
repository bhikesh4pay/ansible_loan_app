<?php
namespace PHPMaker2020\_4payadmin;

// Autoload
include_once "autoload.php";

// Session
if (session_status() !== PHP_SESSION_ACTIVE)
	\Delight\Cookie\Session::start(Config("COOKIE_SAMESITE")); // Init session data

// Output buffering
ob_start();
?>
<?php

// Write header
WriteHeader(FALSE);

// Create page object
$acctbalance_edit = new acctbalance_edit();

// Run the page
$acctbalance_edit->run();

// Setup login status
SetupLoginStatus();
SetClientVar("login", LoginStatus());

// Global Page Rendering event (in userfn*.php)
Page_Rendering();

// Page Rendering event
$acctbalance_edit->Page_Render();
?>
<?php include_once "header.php"; ?>
<script>
var facctbalanceedit, currentPageID;
loadjs.ready("head", function() {

	// Form object
	currentPageID = ew.PAGE_ID = "edit";
	facctbalanceedit = currentForm = new ew.Form("facctbalanceedit", "edit");

	// Validate form
	facctbalanceedit.validate = function() {
		if (!this.validateRequired)
			return true; // Ignore validation
		var $ = jQuery, fobj = this.getForm(), $fobj = $(fobj);
		if ($fobj.find("#confirm").val() == "confirm")
			return true;
		var elm, felm, uelm, addcnt = 0;
		var $k = $fobj.find("#" + this.formKeyCountName); // Get key_count
		var rowcnt = ($k[0]) ? parseInt($k.val(), 10) : 1;
		var startcnt = (rowcnt == 0) ? 0 : 1; // Check rowcnt == 0 => Inline-Add
		var gridinsert = ["insert", "gridinsert"].includes($fobj.find("#action").val()) && $k[0];
		for (var i = startcnt; i <= rowcnt; i++) {
			var infix = ($k[0]) ? String(i) : "";
			$fobj.data("rowindex", infix);
			<?php if ($acctbalance_edit->acctID->Required) { ?>
				elm = this.getElements("x" + infix + "_acctID");
				if (elm && !ew.isHidden(elm) && !ew.hasValue(elm))
					return this.onError(elm, "<?php echo JsEncode(str_replace("%s", $acctbalance_edit->acctID->caption(), $acctbalance_edit->acctID->RequiredErrorMessage)) ?>");
			<?php } ?>
				elm = this.getElements("x" + infix + "_acctID");
				if (elm && !ew.checkInteger(elm.value))
					return this.onError(elm, "<?php echo JsEncode($acctbalance_edit->acctID->errorMessage()) ?>");
			<?php if ($acctbalance_edit->currCode->Required) { ?>
				elm = this.getElements("x" + infix + "_currCode");
				if (elm && !ew.isHidden(elm) && !ew.hasValue(elm))
					return this.onError(elm, "<?php echo JsEncode(str_replace("%s", $acctbalance_edit->currCode->caption(), $acctbalance_edit->currCode->RequiredErrorMessage)) ?>");
			<?php } ?>
			<?php if ($acctbalance_edit->balance->Required) { ?>
				elm = this.getElements("x" + infix + "_balance");
				if (elm && !ew.isHidden(elm) && !ew.hasValue(elm))
					return this.onError(elm, "<?php echo JsEncode(str_replace("%s", $acctbalance_edit->balance->caption(), $acctbalance_edit->balance->RequiredErrorMessage)) ?>");
			<?php } ?>
				elm = this.getElements("x" + infix + "_balance");
				if (elm && !ew.checkNumber(elm.value))
					return this.onError(elm, "<?php echo JsEncode($acctbalance_edit->balance->errorMessage()) ?>");
			<?php if ($acctbalance_edit->unavailableBalance->Required) { ?>
				elm = this.getElements("x" + infix + "_unavailableBalance");
				if (elm && !ew.isHidden(elm) && !ew.hasValue(elm))
					return this.onError(elm, "<?php echo JsEncode(str_replace("%s", $acctbalance_edit->unavailableBalance->caption(), $acctbalance_edit->unavailableBalance->RequiredErrorMessage)) ?>");
			<?php } ?>
				elm = this.getElements("x" + infix + "_unavailableBalance");
				if (elm && !ew.checkNumber(elm.value))
					return this.onError(elm, "<?php echo JsEncode($acctbalance_edit->unavailableBalance->errorMessage()) ?>");
			<?php if ($acctbalance_edit->lastUpdate->Required) { ?>
				elm = this.getElements("x" + infix + "_lastUpdate");
				if (elm && !ew.isHidden(elm) && !ew.hasValue(elm))
					return this.onError(elm, "<?php echo JsEncode(str_replace("%s", $acctbalance_edit->lastUpdate->caption(), $acctbalance_edit->lastUpdate->RequiredErrorMessage)) ?>");
			<?php } ?>
				elm = this.getElements("x" + infix + "_lastUpdate");
				if (elm && !ew.checkDateDef(elm.value))
					return this.onError(elm, "<?php echo JsEncode($acctbalance_edit->lastUpdate->errorMessage()) ?>");

				// Call Form_CustomValidate event
				if (!this.Form_CustomValidate(fobj))
					return false;
		}

		// Process detail forms
		var dfs = $fobj.find("input[name='detailpage']").get();
		for (var i = 0; i < dfs.length; i++) {
			var df = dfs[i], val = df.value;
			if (val && ew.forms[val])
				if (!ew.forms[val].validate())
					return false;
		}
		return true;
	}

	// Form_CustomValidate
	facctbalanceedit.Form_CustomValidate = function(fobj) { // DO NOT CHANGE THIS LINE!

		// Your custom validation code here, return false if invalid.
		return true;
	}

	// Use JavaScript validation or not
	facctbalanceedit.validateRequired = <?php echo Config("CLIENT_VALIDATE") ? "true" : "false" ?>;

	// Dynamic selection lists
	facctbalanceedit.lists["x_acctID"] = <?php echo $acctbalance_edit->acctID->Lookup->toClientList($acctbalance_edit) ?>;
	facctbalanceedit.lists["x_acctID"].options = <?php echo JsonEncode($acctbalance_edit->acctID->lookupOptions()) ?>;
	facctbalanceedit.autoSuggests["x_acctID"] = <?php echo json_encode(["data" => "ajax=autosuggest"]) ?>;
	facctbalanceedit.lists["x_currCode"] = <?php echo $acctbalance_edit->currCode->Lookup->toClientList($acctbalance_edit) ?>;
	facctbalanceedit.lists["x_currCode"].options = <?php echo JsonEncode($acctbalance_edit->currCode->lookupOptions()) ?>;
	facctbalanceedit.autoSuggests["x_currCode"] = <?php echo json_encode(["data" => "ajax=autosuggest"]) ?>;
	loadjs.done("facctbalanceedit");
});
</script>
<script>
loadjs.ready("head", function() {

	// Client script
	// Write your client script here, no need to add script tags.

});
</script>
<?php $acctbalance_edit->showPageHeader(); ?>
<?php
$acctbalance_edit->showMessage();
?>
<form name="facctbalanceedit" id="facctbalanceedit" class="<?php echo $acctbalance_edit->FormClassName ?>" action="<?php echo CurrentPageName() ?>" method="post">
<?php if ($Page->CheckToken) { ?>
<input type="hidden" name="<?php echo Config("TOKEN_NAME") ?>" value="<?php echo $Page->Token ?>">
<?php } ?>
<input type="hidden" name="t" value="acctbalance">
<input type="hidden" name="action" id="action" value="update">
<input type="hidden" name="modal" value="<?php echo (int)$acctbalance_edit->IsModal ?>">
<?php if ($acctbalance->getCurrentMasterTable() == "user") { ?>
<input type="hidden" name="<?php echo Config("TABLE_SHOW_MASTER") ?>" value="user">
<input type="hidden" name="fk_accountID" value="<?php echo HtmlEncode($acctbalance_edit->acctID->getSessionValue()) ?>">
<?php } ?>
<?php if ($acctbalance->getCurrentMasterTable() == "acct") { ?>
<input type="hidden" name="<?php echo Config("TABLE_SHOW_MASTER") ?>" value="acct">
<input type="hidden" name="fk_acctID" value="<?php echo HtmlEncode($acctbalance_edit->acctID->getSessionValue()) ?>">
<?php } ?>
<div class="ew-edit-div"><!-- page* -->
<?php if ($acctbalance_edit->acctID->Visible) { // acctID ?>
	<div id="r_acctID" class="form-group row">
		<label id="elh_acctbalance_acctID" class="<?php echo $acctbalance_edit->LeftColumnClass ?>"><?php echo $acctbalance_edit->acctID->caption() ?><?php echo $acctbalance_edit->acctID->Required ? $Language->phrase("FieldRequiredIndicator") : "" ?></label>
		<div class="<?php echo $acctbalance_edit->RightColumnClass ?>"><div <?php echo $acctbalance_edit->acctID->cellAttributes() ?>>
<?php if ($acctbalance_edit->acctID->getSessionValue() != "") { ?>

<span id="el_acctbalance_acctID">
<span<?php echo $acctbalance_edit->acctID->viewAttributes() ?>><input type="text" readonly class="form-control-plaintext" value="<?php echo HtmlEncode(RemoveHtml($acctbalance_edit->acctID->EditValue)) ?>"></span>
</span>

<input type="hidden" id="x_acctID" name="x_acctID" value="<?php echo HtmlEncode($acctbalance_edit->acctID->CurrentValue) ?>">
<?php } else { ?>

<?php
$onchange = $acctbalance_edit->acctID->EditAttrs->prepend("onchange", "");
$onchange = ($onchange) ? ' onchange="' . JsEncode($onchange) . '"' : '';
$acctbalance_edit->acctID->EditAttrs["onchange"] = "";
?>
<span id="as_x_acctID">
	<input type="text" class="form-control" name="sv_x_acctID" id="sv_x_acctID" value="<?php echo RemoveHtml($acctbalance_edit->acctID->EditValue) ?>" size="30" placeholder="<?php echo HtmlEncode($acctbalance_edit->acctID->getPlaceHolder()) ?>" data-placeholder="<?php echo HtmlEncode($acctbalance_edit->acctID->getPlaceHolder()) ?>"<?php echo $acctbalance_edit->acctID->editAttributes() ?>>
</span>
<input type="hidden" data-table="acctbalance" data-field="x_acctID" data-value-separator="<?php echo $acctbalance_edit->acctID->displayValueSeparatorAttribute() ?>" name="x_acctID" id="x_acctID" value="<?php echo HtmlEncode($acctbalance_edit->acctID->CurrentValue) ?>"<?php echo $onchange ?>>
<script>
loadjs.ready(["facctbalanceedit"], function() {
	facctbalanceedit.createAutoSuggest({"id":"x_acctID","forceSelect":false});
});
</script>
<?php echo $acctbalance_edit->acctID->Lookup->getParamTag($acctbalance_edit, "p_x_acctID") ?>

<?php } ?>

<input type="hidden" data-table="acctbalance" data-field="x_acctID" name="o_acctID" id="o_acctID" value="<?php echo HtmlEncode($acctbalance_edit->acctID->OldValue != null ? $acctbalance_edit->acctID->OldValue : $acctbalance_edit->acctID->CurrentValue) ?>">
<?php echo $acctbalance_edit->acctID->CustomMsg ?></div></div>
	</div>
<?php } ?>
<?php if ($acctbalance_edit->currCode->Visible) { // currCode ?>
	<div id="r_currCode" class="form-group row">
		<label id="elh_acctbalance_currCode" class="<?php echo $acctbalance_edit->LeftColumnClass ?>"><?php echo $acctbalance_edit->currCode->caption() ?><?php echo $acctbalance_edit->currCode->Required ? $Language->phrase("FieldRequiredIndicator") : "" ?></label>
		<div class="<?php echo $acctbalance_edit->RightColumnClass ?>"><div <?php echo $acctbalance_edit->currCode->cellAttributes() ?>>
<?php
$onchange = $acctbalance_edit->currCode->EditAttrs->prepend("onchange", "");
$onchange = ($onchange) ? ' onchange="' . JsEncode($onchange) . '"' : '';
$acctbalance_edit->currCode->EditAttrs["onchange"] = "";
?>
<span id="as_x_currCode">
	<input type="text" class="form-control" name="sv_x_currCode" id="sv_x_currCode" value="<?php echo RemoveHtml($acctbalance_edit->currCode->EditValue) ?>" size="30" maxlength="3" placeholder="<?php echo HtmlEncode($acctbalance_edit->currCode->getPlaceHolder()) ?>" data-placeholder="<?php echo HtmlEncode($acctbalance_edit->currCode->getPlaceHolder()) ?>"<?php echo $acctbalance_edit->currCode->editAttributes() ?>>
</span>
<input type="hidden" data-table="acctbalance" data-field="x_currCode" data-value-separator="<?php echo $acctbalance_edit->currCode->displayValueSeparatorAttribute() ?>" name="x_currCode" id="x_currCode" value="<?php echo HtmlEncode($acctbalance_edit->currCode->CurrentValue) ?>"<?php echo $onchange ?>>
<script>
loadjs.ready(["facctbalanceedit"], function() {
	facctbalanceedit.createAutoSuggest({"id":"x_currCode","forceSelect":false});
});
</script>
<?php echo $acctbalance_edit->currCode->Lookup->getParamTag($acctbalance_edit, "p_x_currCode") ?>
<input type="hidden" data-table="acctbalance" data-field="x_currCode" name="o_currCode" id="o_currCode" value="<?php echo HtmlEncode($acctbalance_edit->currCode->OldValue != null ? $acctbalance_edit->currCode->OldValue : $acctbalance_edit->currCode->CurrentValue) ?>">
<?php echo $acctbalance_edit->currCode->CustomMsg ?></div></div>
	</div>
<?php } ?>
<?php if ($acctbalance_edit->balance->Visible) { // balance ?>
	<div id="r_balance" class="form-group row">
		<label id="elh_acctbalance_balance" for="x_balance" class="<?php echo $acctbalance_edit->LeftColumnClass ?>"><?php echo $acctbalance_edit->balance->caption() ?><?php echo $acctbalance_edit->balance->Required ? $Language->phrase("FieldRequiredIndicator") : "" ?></label>
		<div class="<?php echo $acctbalance_edit->RightColumnClass ?>"><div <?php echo $acctbalance_edit->balance->cellAttributes() ?>>
<span id="el_acctbalance_balance">
<input type="text" data-table="acctbalance" data-field="x_balance" name="x_balance" id="x_balance" size="30" placeholder="<?php echo HtmlEncode($acctbalance_edit->balance->getPlaceHolder()) ?>" value="<?php echo $acctbalance_edit->balance->EditValue ?>"<?php echo $acctbalance_edit->balance->editAttributes() ?>>
</span>
<?php echo $acctbalance_edit->balance->CustomMsg ?></div></div>
	</div>
<?php } ?>
<?php if ($acctbalance_edit->unavailableBalance->Visible) { // unavailableBalance ?>
	<div id="r_unavailableBalance" class="form-group row">
		<label id="elh_acctbalance_unavailableBalance" for="x_unavailableBalance" class="<?php echo $acctbalance_edit->LeftColumnClass ?>"><?php echo $acctbalance_edit->unavailableBalance->caption() ?><?php echo $acctbalance_edit->unavailableBalance->Required ? $Language->phrase("FieldRequiredIndicator") : "" ?></label>
		<div class="<?php echo $acctbalance_edit->RightColumnClass ?>"><div <?php echo $acctbalance_edit->unavailableBalance->cellAttributes() ?>>
<span id="el_acctbalance_unavailableBalance">
<input type="text" data-table="acctbalance" data-field="x_unavailableBalance" name="x_unavailableBalance" id="x_unavailableBalance" size="30" placeholder="<?php echo HtmlEncode($acctbalance_edit->unavailableBalance->getPlaceHolder()) ?>" value="<?php echo $acctbalance_edit->unavailableBalance->EditValue ?>"<?php echo $acctbalance_edit->unavailableBalance->editAttributes() ?>>
</span>
<?php echo $acctbalance_edit->unavailableBalance->CustomMsg ?></div></div>
	</div>
<?php } ?>
<?php if ($acctbalance_edit->lastUpdate->Visible) { // lastUpdate ?>
	<div id="r_lastUpdate" class="form-group row">
		<label id="elh_acctbalance_lastUpdate" for="x_lastUpdate" class="<?php echo $acctbalance_edit->LeftColumnClass ?>"><?php echo $acctbalance_edit->lastUpdate->caption() ?><?php echo $acctbalance_edit->lastUpdate->Required ? $Language->phrase("FieldRequiredIndicator") : "" ?></label>
		<div class="<?php echo $acctbalance_edit->RightColumnClass ?>"><div <?php echo $acctbalance_edit->lastUpdate->cellAttributes() ?>>
<span id="el_acctbalance_lastUpdate">
<input type="text" data-table="acctbalance" data-field="x_lastUpdate" data-format="1" name="x_lastUpdate" id="x_lastUpdate" placeholder="<?php echo HtmlEncode($acctbalance_edit->lastUpdate->getPlaceHolder()) ?>" value="<?php echo $acctbalance_edit->lastUpdate->EditValue ?>"<?php echo $acctbalance_edit->lastUpdate->editAttributes() ?>>
<?php if (!$acctbalance_edit->lastUpdate->ReadOnly && !$acctbalance_edit->lastUpdate->Disabled && !isset($acctbalance_edit->lastUpdate->EditAttrs["readonly"]) && !isset($acctbalance_edit->lastUpdate->EditAttrs["disabled"])) { ?>
<script>
loadjs.ready(["facctbalanceedit", "datetimepicker"], function() {
	ew.createDateTimePicker("facctbalanceedit", "x_lastUpdate", {"ignoreReadonly":true,"useCurrent":false,"format":1});
});
</script>
<?php } ?>
</span>
<?php echo $acctbalance_edit->lastUpdate->CustomMsg ?></div></div>
	</div>
<?php } ?>
</div><!-- /page* -->
<?php
	if (in_array("vtranshistory", explode(",", $acctbalance->getCurrentDetailTable())) && $vtranshistory->DetailEdit) {
?>
<?php if ($acctbalance->getCurrentDetailTable() != "") { ?>
<h4 class="ew-detail-caption"><?php echo $Language->tablePhrase("vtranshistory", "TblCaption") ?></h4>
<?php } ?>
<?php include_once "vtranshistorygrid.php" ?>
<?php } ?>
<?php
	if (in_array("vnodetransferpool2", explode(",", $acctbalance->getCurrentDetailTable())) && $vnodetransferpool2->DetailEdit) {
?>
<?php if ($acctbalance->getCurrentDetailTable() != "") { ?>
<h4 class="ew-detail-caption"><?php echo $Language->tablePhrase("vnodetransferpool2", "TblCaption") ?></h4>
<?php } ?>
<?php include_once "vnodetransferpool2grid.php" ?>
<?php } ?>
<?php if (!$acctbalance_edit->IsModal) { ?>
<div class="form-group row"><!-- buttons .form-group -->
	<div class="<?php echo $acctbalance_edit->OffsetColumnClass ?>"><!-- buttons offset -->
<button class="btn btn-primary ew-btn" name="btn-action" id="btn-action" type="submit"><?php echo $Language->phrase("SaveBtn") ?></button>
<button class="btn btn-default ew-btn" name="btn-cancel" id="btn-cancel" type="button" data-href="<?php echo $acctbalance_edit->getReturnUrl() ?>"><?php echo $Language->phrase("CancelBtn") ?></button>
	</div><!-- /buttons offset -->
</div><!-- /buttons .form-group -->
<?php } ?>
</form>
<?php
$acctbalance_edit->showPageFooter();
if (Config("DEBUG"))
	echo GetDebugMessage();
?>
<script>
loadjs.ready("load", function() {

	// Startup script
	// Write your table-specific startup script here
	// console.log("page loaded");

});
</script>
<?php include_once "footer.php"; ?>
<?php
$acctbalance_edit->terminate();
?>