<?php
namespace PHPMaker2020\_4payadmin;

// Autoload
include_once "autoload.php";

// Session
if (session_status() !== PHP_SESSION_ACTIVE)
	\Delight\Cookie\Session::start(Config("COOKIE_SAMESITE")); // Init session data

// Output buffering
ob_start();
?>
<?php

// Write header
WriteHeader(FALSE);

// Create page object
$vtranshistorybyuserwithnames_list = new vtranshistorybyuserwithnames_list();

// Run the page
$vtranshistorybyuserwithnames_list->run();

// Setup login status
SetupLoginStatus();
SetClientVar("login", LoginStatus());

// Global Page Rendering event (in userfn*.php)
Page_Rendering();

// Page Rendering event
$vtranshistorybyuserwithnames_list->Page_Render();
?>
<?php include_once "header.php"; ?>
<?php if (!$vtranshistorybyuserwithnames_list->isExport()) { ?>
<script>
var fvtranshistorybyuserwithnameslist, currentPageID;
loadjs.ready("head", function() {

	// Form object
	currentPageID = ew.PAGE_ID = "list";
	fvtranshistorybyuserwithnameslist = currentForm = new ew.Form("fvtranshistorybyuserwithnameslist", "list");
	fvtranshistorybyuserwithnameslist.formKeyCountName = '<?php echo $vtranshistorybyuserwithnames_list->FormKeyCountName ?>';
	loadjs.done("fvtranshistorybyuserwithnameslist");
});
var fvtranshistorybyuserwithnameslistsrch;
loadjs.ready("head", function() {

	// Form object for search
	fvtranshistorybyuserwithnameslistsrch = currentSearchForm = new ew.Form("fvtranshistorybyuserwithnameslistsrch");

	// Dynamic selection lists
	// Filters

	fvtranshistorybyuserwithnameslistsrch.filterList = <?php echo $vtranshistorybyuserwithnames_list->getFilterList() ?>;

	// Init search panel as collapsed
	fvtranshistorybyuserwithnameslistsrch.initSearchPanel = true;
	loadjs.done("fvtranshistorybyuserwithnameslistsrch");
});
</script>
<style type="text/css">
.ew-table-preview-row { /* main table preview row color */
	background-color: #FFFFFF; /* preview row color */
}
.ew-table-preview-row .ew-grid {
	display: table;
}
</style>
<div id="ew-preview" class="d-none"><!-- preview -->
	<div class="ew-nav-tabs"><!-- .ew-nav-tabs -->
		<ul class="nav nav-tabs"></ul>
		<div class="tab-content"><!-- .tab-content -->
			<div class="tab-pane fade active show"></div>
		</div><!-- /.tab-content -->
	</div><!-- /.ew-nav-tabs -->
</div><!-- /preview -->
<script>
loadjs.ready("head", function() {
	ew.PREVIEW_PLACEMENT = ew.CSS_FLIP ? "right" : "left";
	ew.PREVIEW_SINGLE_ROW = false;
	ew.PREVIEW_OVERLAY = false;
	loadjs("js/ewpreview.js", "preview");
});
</script>
<script>
loadjs.ready("head", function() {

	// Client script
	// Write your client script here, no need to add script tags.

});
</script>
<?php } ?>
<?php if (!$vtranshistorybyuserwithnames_list->isExport()) { ?>
<div class="btn-toolbar ew-toolbar">
<?php if ($vtranshistorybyuserwithnames_list->TotalRecords > 0 && $vtranshistorybyuserwithnames_list->ExportOptions->visible()) { ?>
<?php $vtranshistorybyuserwithnames_list->ExportOptions->render("body") ?>
<?php } ?>
<?php if ($vtranshistorybyuserwithnames_list->ImportOptions->visible()) { ?>
<?php $vtranshistorybyuserwithnames_list->ImportOptions->render("body") ?>
<?php } ?>
<?php if ($vtranshistorybyuserwithnames_list->SearchOptions->visible()) { ?>
<?php $vtranshistorybyuserwithnames_list->SearchOptions->render("body") ?>
<?php } ?>
<?php if ($vtranshistorybyuserwithnames_list->FilterOptions->visible()) { ?>
<?php $vtranshistorybyuserwithnames_list->FilterOptions->render("body") ?>
<?php } ?>
<div class="clearfix"></div>
</div>
<?php } ?>
<?php
$vtranshistorybyuserwithnames_list->renderOtherOptions();
?>
<?php if ($Security->CanSearch()) { ?>
<?php if (!$vtranshistorybyuserwithnames_list->isExport() && !$vtranshistorybyuserwithnames->CurrentAction) { ?>
<form name="fvtranshistorybyuserwithnameslistsrch" id="fvtranshistorybyuserwithnameslistsrch" class="form-inline ew-form ew-ext-search-form" action="<?php echo CurrentPageName() ?>">
<div id="fvtranshistorybyuserwithnameslistsrch-search-panel" class="<?php echo $vtranshistorybyuserwithnames_list->SearchPanelClass ?>">
<input type="hidden" name="cmd" value="search">
<input type="hidden" name="t" value="vtranshistorybyuserwithnames">
	<div class="ew-extended-search">
<div id="xsr_<?php echo $vtranshistorybyuserwithnames_list->SearchRowCount + 1 ?>" class="ew-row d-sm-flex">
	<div class="ew-quick-search input-group">
		<input type="text" name="<?php echo Config("TABLE_BASIC_SEARCH") ?>" id="<?php echo Config("TABLE_BASIC_SEARCH") ?>" class="form-control" value="<?php echo HtmlEncode($vtranshistorybyuserwithnames_list->BasicSearch->getKeyword()) ?>" placeholder="<?php echo HtmlEncode($Language->phrase("Search")) ?>">
		<input type="hidden" name="<?php echo Config("TABLE_BASIC_SEARCH_TYPE") ?>" id="<?php echo Config("TABLE_BASIC_SEARCH_TYPE") ?>" value="<?php echo HtmlEncode($vtranshistorybyuserwithnames_list->BasicSearch->getType()) ?>">
		<div class="input-group-append">
			<button class="btn btn-primary" name="btn-submit" id="btn-submit" type="submit"><?php echo $Language->phrase("SearchBtn") ?></button>
			<button type="button" data-toggle="dropdown" class="btn btn-primary dropdown-toggle dropdown-toggle-split" aria-haspopup="true" aria-expanded="false"><span id="searchtype"><?php echo $vtranshistorybyuserwithnames_list->BasicSearch->getTypeNameShort() ?></span></button>
			<div class="dropdown-menu dropdown-menu-right">
				<a class="dropdown-item<?php if ($vtranshistorybyuserwithnames_list->BasicSearch->getType() == "") { ?> active<?php } ?>" href="#" onclick="return ew.setSearchType(this);"><?php echo $Language->phrase("QuickSearchAuto") ?></a>
				<a class="dropdown-item<?php if ($vtranshistorybyuserwithnames_list->BasicSearch->getType() == "=") { ?> active<?php } ?>" href="#" onclick="return ew.setSearchType(this, '=');"><?php echo $Language->phrase("QuickSearchExact") ?></a>
				<a class="dropdown-item<?php if ($vtranshistorybyuserwithnames_list->BasicSearch->getType() == "AND") { ?> active<?php } ?>" href="#" onclick="return ew.setSearchType(this, 'AND');"><?php echo $Language->phrase("QuickSearchAll") ?></a>
				<a class="dropdown-item<?php if ($vtranshistorybyuserwithnames_list->BasicSearch->getType() == "OR") { ?> active<?php } ?>" href="#" onclick="return ew.setSearchType(this, 'OR');"><?php echo $Language->phrase("QuickSearchAny") ?></a>
			</div>
		</div>
	</div>
</div>
	</div><!-- /.ew-extended-search -->
</div><!-- /.ew-search-panel -->
</form>
<?php } ?>
<?php } ?>
<?php $vtranshistorybyuserwithnames_list->showPageHeader(); ?>
<?php
$vtranshistorybyuserwithnames_list->showMessage();
?>
<?php if ($vtranshistorybyuserwithnames_list->TotalRecords > 0 || $vtranshistorybyuserwithnames->CurrentAction) { ?>
<div class="card ew-card ew-grid<?php if ($vtranshistorybyuserwithnames_list->isAddOrEdit()) { ?> ew-grid-add-edit<?php } ?> vtranshistorybyuserwithnames">
<form name="fvtranshistorybyuserwithnameslist" id="fvtranshistorybyuserwithnameslist" class="form-inline ew-form ew-list-form" action="<?php echo CurrentPageName() ?>" method="post">
<?php if ($Page->CheckToken) { ?>
<input type="hidden" name="<?php echo Config("TOKEN_NAME") ?>" value="<?php echo $Page->Token ?>">
<?php } ?>
<input type="hidden" name="t" value="vtranshistorybyuserwithnames">
<div id="gmp_vtranshistorybyuserwithnames" class="<?php echo ResponsiveTableClass() ?>card-body ew-grid-middle-panel">
<?php if ($vtranshistorybyuserwithnames_list->TotalRecords > 0 || $vtranshistorybyuserwithnames_list->isGridEdit()) { ?>
<table id="tbl_vtranshistorybyuserwithnameslist" class="table ew-table"><!-- .ew-table -->
<thead>
	<tr class="ew-table-header">
<?php

// Header row
$vtranshistorybyuserwithnames->RowType = ROWTYPE_HEADER;

// Render list options
$vtranshistorybyuserwithnames_list->renderListOptions();

// Render list options (header, left)
$vtranshistorybyuserwithnames_list->ListOptions->render("header", "left");
?>
<?php if ($vtranshistorybyuserwithnames_list->rolename->Visible) { // rolename ?>
	<?php if ($vtranshistorybyuserwithnames_list->SortUrl($vtranshistorybyuserwithnames_list->rolename) == "") { ?>
		<th data-name="rolename" class="<?php echo $vtranshistorybyuserwithnames_list->rolename->headerCellClass() ?>"><div id="elh_vtranshistorybyuserwithnames_rolename" class="vtranshistorybyuserwithnames_rolename"><div class="ew-table-header-caption"><?php echo $vtranshistorybyuserwithnames_list->rolename->caption() ?></div></div></th>
	<?php } else { ?>
		<th data-name="rolename" class="<?php echo $vtranshistorybyuserwithnames_list->rolename->headerCellClass() ?>"><div class="ew-pointer" onclick="ew.sort(event, '<?php echo $vtranshistorybyuserwithnames_list->SortUrl($vtranshistorybyuserwithnames_list->rolename) ?>', 1);"><div id="elh_vtranshistorybyuserwithnames_rolename" class="vtranshistorybyuserwithnames_rolename">
			<div class="ew-table-header-btn"><span class="ew-table-header-caption"><?php echo $vtranshistorybyuserwithnames_list->rolename->caption() ?><?php echo $Language->phrase("SrchLegend") ?></span><span class="ew-table-header-sort"><?php if ($vtranshistorybyuserwithnames_list->rolename->getSort() == "ASC") { ?><i class="fas fa-sort-up"></i><?php } elseif ($vtranshistorybyuserwithnames_list->rolename->getSort() == "DESC") { ?><i class="fas fa-sort-down"></i><?php } ?></span></div>
		</div></div></th>
	<?php } ?>
<?php } ?>
<?php if ($vtranshistorybyuserwithnames_list->roleid->Visible) { // roleid ?>
	<?php if ($vtranshistorybyuserwithnames_list->SortUrl($vtranshistorybyuserwithnames_list->roleid) == "") { ?>
		<th data-name="roleid" class="<?php echo $vtranshistorybyuserwithnames_list->roleid->headerCellClass() ?>"><div id="elh_vtranshistorybyuserwithnames_roleid" class="vtranshistorybyuserwithnames_roleid"><div class="ew-table-header-caption"><?php echo $vtranshistorybyuserwithnames_list->roleid->caption() ?></div></div></th>
	<?php } else { ?>
		<th data-name="roleid" class="<?php echo $vtranshistorybyuserwithnames_list->roleid->headerCellClass() ?>"><div class="ew-pointer" onclick="ew.sort(event, '<?php echo $vtranshistorybyuserwithnames_list->SortUrl($vtranshistorybyuserwithnames_list->roleid) ?>', 1);"><div id="elh_vtranshistorybyuserwithnames_roleid" class="vtranshistorybyuserwithnames_roleid">
			<div class="ew-table-header-btn"><span class="ew-table-header-caption"><?php echo $vtranshistorybyuserwithnames_list->roleid->caption() ?></span><span class="ew-table-header-sort"><?php if ($vtranshistorybyuserwithnames_list->roleid->getSort() == "ASC") { ?><i class="fas fa-sort-up"></i><?php } elseif ($vtranshistorybyuserwithnames_list->roleid->getSort() == "DESC") { ?><i class="fas fa-sort-down"></i><?php } ?></span></div>
		</div></div></th>
	<?php } ?>
<?php } ?>
<?php if ($vtranshistorybyuserwithnames_list->sourceUserID->Visible) { // sourceUserID ?>
	<?php if ($vtranshistorybyuserwithnames_list->SortUrl($vtranshistorybyuserwithnames_list->sourceUserID) == "") { ?>
		<th data-name="sourceUserID" class="<?php echo $vtranshistorybyuserwithnames_list->sourceUserID->headerCellClass() ?>"><div id="elh_vtranshistorybyuserwithnames_sourceUserID" class="vtranshistorybyuserwithnames_sourceUserID"><div class="ew-table-header-caption"><?php echo $vtranshistorybyuserwithnames_list->sourceUserID->caption() ?></div></div></th>
	<?php } else { ?>
		<th data-name="sourceUserID" class="<?php echo $vtranshistorybyuserwithnames_list->sourceUserID->headerCellClass() ?>"><div class="ew-pointer" onclick="ew.sort(event, '<?php echo $vtranshistorybyuserwithnames_list->SortUrl($vtranshistorybyuserwithnames_list->sourceUserID) ?>', 1);"><div id="elh_vtranshistorybyuserwithnames_sourceUserID" class="vtranshistorybyuserwithnames_sourceUserID">
			<div class="ew-table-header-btn"><span class="ew-table-header-caption"><?php echo $vtranshistorybyuserwithnames_list->sourceUserID->caption() ?></span><span class="ew-table-header-sort"><?php if ($vtranshistorybyuserwithnames_list->sourceUserID->getSort() == "ASC") { ?><i class="fas fa-sort-up"></i><?php } elseif ($vtranshistorybyuserwithnames_list->sourceUserID->getSort() == "DESC") { ?><i class="fas fa-sort-down"></i><?php } ?></span></div>
		</div></div></th>
	<?php } ?>
<?php } ?>
<?php if ($vtranshistorybyuserwithnames_list->acctID->Visible) { // acctID ?>
	<?php if ($vtranshistorybyuserwithnames_list->SortUrl($vtranshistorybyuserwithnames_list->acctID) == "") { ?>
		<th data-name="acctID" class="<?php echo $vtranshistorybyuserwithnames_list->acctID->headerCellClass() ?>"><div id="elh_vtranshistorybyuserwithnames_acctID" class="vtranshistorybyuserwithnames_acctID"><div class="ew-table-header-caption"><?php echo $vtranshistorybyuserwithnames_list->acctID->caption() ?></div></div></th>
	<?php } else { ?>
		<th data-name="acctID" class="<?php echo $vtranshistorybyuserwithnames_list->acctID->headerCellClass() ?>"><div class="ew-pointer" onclick="ew.sort(event, '<?php echo $vtranshistorybyuserwithnames_list->SortUrl($vtranshistorybyuserwithnames_list->acctID) ?>', 1);"><div id="elh_vtranshistorybyuserwithnames_acctID" class="vtranshistorybyuserwithnames_acctID">
			<div class="ew-table-header-btn"><span class="ew-table-header-caption"><?php echo $vtranshistorybyuserwithnames_list->acctID->caption() ?></span><span class="ew-table-header-sort"><?php if ($vtranshistorybyuserwithnames_list->acctID->getSort() == "ASC") { ?><i class="fas fa-sort-up"></i><?php } elseif ($vtranshistorybyuserwithnames_list->acctID->getSort() == "DESC") { ?><i class="fas fa-sort-down"></i><?php } ?></span></div>
		</div></div></th>
	<?php } ?>
<?php } ?>
<?php if ($vtranshistorybyuserwithnames_list->currID->Visible) { // currID ?>
	<?php if ($vtranshistorybyuserwithnames_list->SortUrl($vtranshistorybyuserwithnames_list->currID) == "") { ?>
		<th data-name="currID" class="<?php echo $vtranshistorybyuserwithnames_list->currID->headerCellClass() ?>"><div id="elh_vtranshistorybyuserwithnames_currID" class="vtranshistorybyuserwithnames_currID"><div class="ew-table-header-caption"><?php echo $vtranshistorybyuserwithnames_list->currID->caption() ?></div></div></th>
	<?php } else { ?>
		<th data-name="currID" class="<?php echo $vtranshistorybyuserwithnames_list->currID->headerCellClass() ?>"><div class="ew-pointer" onclick="ew.sort(event, '<?php echo $vtranshistorybyuserwithnames_list->SortUrl($vtranshistorybyuserwithnames_list->currID) ?>', 1);"><div id="elh_vtranshistorybyuserwithnames_currID" class="vtranshistorybyuserwithnames_currID">
			<div class="ew-table-header-btn"><span class="ew-table-header-caption"><?php echo $vtranshistorybyuserwithnames_list->currID->caption() ?><?php echo $Language->phrase("SrchLegend") ?></span><span class="ew-table-header-sort"><?php if ($vtranshistorybyuserwithnames_list->currID->getSort() == "ASC") { ?><i class="fas fa-sort-up"></i><?php } elseif ($vtranshistorybyuserwithnames_list->currID->getSort() == "DESC") { ?><i class="fas fa-sort-down"></i><?php } ?></span></div>
		</div></div></th>
	<?php } ?>
<?php } ?>
<?php if ($vtranshistorybyuserwithnames_list->amount->Visible) { // amount ?>
	<?php if ($vtranshistorybyuserwithnames_list->SortUrl($vtranshistorybyuserwithnames_list->amount) == "") { ?>
		<th data-name="amount" class="<?php echo $vtranshistorybyuserwithnames_list->amount->headerCellClass() ?>"><div id="elh_vtranshistorybyuserwithnames_amount" class="vtranshistorybyuserwithnames_amount"><div class="ew-table-header-caption"><?php echo $vtranshistorybyuserwithnames_list->amount->caption() ?></div></div></th>
	<?php } else { ?>
		<th data-name="amount" class="<?php echo $vtranshistorybyuserwithnames_list->amount->headerCellClass() ?>"><div class="ew-pointer" onclick="ew.sort(event, '<?php echo $vtranshistorybyuserwithnames_list->SortUrl($vtranshistorybyuserwithnames_list->amount) ?>', 1);"><div id="elh_vtranshistorybyuserwithnames_amount" class="vtranshistorybyuserwithnames_amount">
			<div class="ew-table-header-btn"><span class="ew-table-header-caption"><?php echo $vtranshistorybyuserwithnames_list->amount->caption() ?></span><span class="ew-table-header-sort"><?php if ($vtranshistorybyuserwithnames_list->amount->getSort() == "ASC") { ?><i class="fas fa-sort-up"></i><?php } elseif ($vtranshistorybyuserwithnames_list->amount->getSort() == "DESC") { ?><i class="fas fa-sort-down"></i><?php } ?></span></div>
		</div></div></th>
	<?php } ?>
<?php } ?>
<?php if ($vtranshistorybyuserwithnames_list->transTime->Visible) { // transTime ?>
	<?php if ($vtranshistorybyuserwithnames_list->SortUrl($vtranshistorybyuserwithnames_list->transTime) == "") { ?>
		<th data-name="transTime" class="<?php echo $vtranshistorybyuserwithnames_list->transTime->headerCellClass() ?>"><div id="elh_vtranshistorybyuserwithnames_transTime" class="vtranshistorybyuserwithnames_transTime"><div class="ew-table-header-caption"><?php echo $vtranshistorybyuserwithnames_list->transTime->caption() ?></div></div></th>
	<?php } else { ?>
		<th data-name="transTime" class="<?php echo $vtranshistorybyuserwithnames_list->transTime->headerCellClass() ?>"><div class="ew-pointer" onclick="ew.sort(event, '<?php echo $vtranshistorybyuserwithnames_list->SortUrl($vtranshistorybyuserwithnames_list->transTime) ?>', 1);"><div id="elh_vtranshistorybyuserwithnames_transTime" class="vtranshistorybyuserwithnames_transTime">
			<div class="ew-table-header-btn"><span class="ew-table-header-caption"><?php echo $vtranshistorybyuserwithnames_list->transTime->caption() ?></span><span class="ew-table-header-sort"><?php if ($vtranshistorybyuserwithnames_list->transTime->getSort() == "ASC") { ?><i class="fas fa-sort-up"></i><?php } elseif ($vtranshistorybyuserwithnames_list->transTime->getSort() == "DESC") { ?><i class="fas fa-sort-down"></i><?php } ?></span></div>
		</div></div></th>
	<?php } ?>
<?php } ?>
<?php if ($vtranshistorybyuserwithnames_list->transType->Visible) { // transType ?>
	<?php if ($vtranshistorybyuserwithnames_list->SortUrl($vtranshistorybyuserwithnames_list->transType) == "") { ?>
		<th data-name="transType" class="<?php echo $vtranshistorybyuserwithnames_list->transType->headerCellClass() ?>"><div id="elh_vtranshistorybyuserwithnames_transType" class="vtranshistorybyuserwithnames_transType"><div class="ew-table-header-caption"><?php echo $vtranshistorybyuserwithnames_list->transType->caption() ?></div></div></th>
	<?php } else { ?>
		<th data-name="transType" class="<?php echo $vtranshistorybyuserwithnames_list->transType->headerCellClass() ?>"><div class="ew-pointer" onclick="ew.sort(event, '<?php echo $vtranshistorybyuserwithnames_list->SortUrl($vtranshistorybyuserwithnames_list->transType) ?>', 1);"><div id="elh_vtranshistorybyuserwithnames_transType" class="vtranshistorybyuserwithnames_transType">
			<div class="ew-table-header-btn"><span class="ew-table-header-caption"><?php echo $vtranshistorybyuserwithnames_list->transType->caption() ?></span><span class="ew-table-header-sort"><?php if ($vtranshistorybyuserwithnames_list->transType->getSort() == "ASC") { ?><i class="fas fa-sort-up"></i><?php } elseif ($vtranshistorybyuserwithnames_list->transType->getSort() == "DESC") { ?><i class="fas fa-sort-down"></i><?php } ?></span></div>
		</div></div></th>
	<?php } ?>
<?php } ?>
<?php if ($vtranshistorybyuserwithnames_list->destinationUserID->Visible) { // destinationUserID ?>
	<?php if ($vtranshistorybyuserwithnames_list->SortUrl($vtranshistorybyuserwithnames_list->destinationUserID) == "") { ?>
		<th data-name="destinationUserID" class="<?php echo $vtranshistorybyuserwithnames_list->destinationUserID->headerCellClass() ?>"><div id="elh_vtranshistorybyuserwithnames_destinationUserID" class="vtranshistorybyuserwithnames_destinationUserID"><div class="ew-table-header-caption"><?php echo $vtranshistorybyuserwithnames_list->destinationUserID->caption() ?></div></div></th>
	<?php } else { ?>
		<th data-name="destinationUserID" class="<?php echo $vtranshistorybyuserwithnames_list->destinationUserID->headerCellClass() ?>"><div class="ew-pointer" onclick="ew.sort(event, '<?php echo $vtranshistorybyuserwithnames_list->SortUrl($vtranshistorybyuserwithnames_list->destinationUserID) ?>', 1);"><div id="elh_vtranshistorybyuserwithnames_destinationUserID" class="vtranshistorybyuserwithnames_destinationUserID">
			<div class="ew-table-header-btn"><span class="ew-table-header-caption"><?php echo $vtranshistorybyuserwithnames_list->destinationUserID->caption() ?></span><span class="ew-table-header-sort"><?php if ($vtranshistorybyuserwithnames_list->destinationUserID->getSort() == "ASC") { ?><i class="fas fa-sort-up"></i><?php } elseif ($vtranshistorybyuserwithnames_list->destinationUserID->getSort() == "DESC") { ?><i class="fas fa-sort-down"></i><?php } ?></span></div>
		</div></div></th>
	<?php } ?>
<?php } ?>
<?php if ($vtranshistorybyuserwithnames_list->referenceTXID->Visible) { // referenceTXID ?>
	<?php if ($vtranshistorybyuserwithnames_list->SortUrl($vtranshistorybyuserwithnames_list->referenceTXID) == "") { ?>
		<th data-name="referenceTXID" class="<?php echo $vtranshistorybyuserwithnames_list->referenceTXID->headerCellClass() ?>"><div id="elh_vtranshistorybyuserwithnames_referenceTXID" class="vtranshistorybyuserwithnames_referenceTXID"><div class="ew-table-header-caption"><?php echo $vtranshistorybyuserwithnames_list->referenceTXID->caption() ?></div></div></th>
	<?php } else { ?>
		<th data-name="referenceTXID" class="<?php echo $vtranshistorybyuserwithnames_list->referenceTXID->headerCellClass() ?>"><div class="ew-pointer" onclick="ew.sort(event, '<?php echo $vtranshistorybyuserwithnames_list->SortUrl($vtranshistorybyuserwithnames_list->referenceTXID) ?>', 1);"><div id="elh_vtranshistorybyuserwithnames_referenceTXID" class="vtranshistorybyuserwithnames_referenceTXID">
			<div class="ew-table-header-btn"><span class="ew-table-header-caption"><?php echo $vtranshistorybyuserwithnames_list->referenceTXID->caption() ?><?php echo $Language->phrase("SrchLegend") ?></span><span class="ew-table-header-sort"><?php if ($vtranshistorybyuserwithnames_list->referenceTXID->getSort() == "ASC") { ?><i class="fas fa-sort-up"></i><?php } elseif ($vtranshistorybyuserwithnames_list->referenceTXID->getSort() == "DESC") { ?><i class="fas fa-sort-down"></i><?php } ?></span></div>
		</div></div></th>
	<?php } ?>
<?php } ?>
<?php if ($vtranshistorybyuserwithnames_list->langID->Visible) { // langID ?>
	<?php if ($vtranshistorybyuserwithnames_list->SortUrl($vtranshistorybyuserwithnames_list->langID) == "") { ?>
		<th data-name="langID" class="<?php echo $vtranshistorybyuserwithnames_list->langID->headerCellClass() ?>"><div id="elh_vtranshistorybyuserwithnames_langID" class="vtranshistorybyuserwithnames_langID"><div class="ew-table-header-caption"><?php echo $vtranshistorybyuserwithnames_list->langID->caption() ?></div></div></th>
	<?php } else { ?>
		<th data-name="langID" class="<?php echo $vtranshistorybyuserwithnames_list->langID->headerCellClass() ?>"><div class="ew-pointer" onclick="ew.sort(event, '<?php echo $vtranshistorybyuserwithnames_list->SortUrl($vtranshistorybyuserwithnames_list->langID) ?>', 1);"><div id="elh_vtranshistorybyuserwithnames_langID" class="vtranshistorybyuserwithnames_langID">
			<div class="ew-table-header-btn"><span class="ew-table-header-caption"><?php echo $vtranshistorybyuserwithnames_list->langID->caption() ?><?php echo $Language->phrase("SrchLegend") ?></span><span class="ew-table-header-sort"><?php if ($vtranshistorybyuserwithnames_list->langID->getSort() == "ASC") { ?><i class="fas fa-sort-up"></i><?php } elseif ($vtranshistorybyuserwithnames_list->langID->getSort() == "DESC") { ?><i class="fas fa-sort-down"></i><?php } ?></span></div>
		</div></div></th>
	<?php } ?>
<?php } ?>
<?php if ($vtranshistorybyuserwithnames_list->transID->Visible) { // transID ?>
	<?php if ($vtranshistorybyuserwithnames_list->SortUrl($vtranshistorybyuserwithnames_list->transID) == "") { ?>
		<th data-name="transID" class="<?php echo $vtranshistorybyuserwithnames_list->transID->headerCellClass() ?>"><div id="elh_vtranshistorybyuserwithnames_transID" class="vtranshistorybyuserwithnames_transID"><div class="ew-table-header-caption"><?php echo $vtranshistorybyuserwithnames_list->transID->caption() ?></div></div></th>
	<?php } else { ?>
		<th data-name="transID" class="<?php echo $vtranshistorybyuserwithnames_list->transID->headerCellClass() ?>"><div class="ew-pointer" onclick="ew.sort(event, '<?php echo $vtranshistorybyuserwithnames_list->SortUrl($vtranshistorybyuserwithnames_list->transID) ?>', 1);"><div id="elh_vtranshistorybyuserwithnames_transID" class="vtranshistorybyuserwithnames_transID">
			<div class="ew-table-header-btn"><span class="ew-table-header-caption"><?php echo $vtranshistorybyuserwithnames_list->transID->caption() ?></span><span class="ew-table-header-sort"><?php if ($vtranshistorybyuserwithnames_list->transID->getSort() == "ASC") { ?><i class="fas fa-sort-up"></i><?php } elseif ($vtranshistorybyuserwithnames_list->transID->getSort() == "DESC") { ?><i class="fas fa-sort-down"></i><?php } ?></span></div>
		</div></div></th>
	<?php } ?>
<?php } ?>
<?php if ($vtranshistorybyuserwithnames_list->filterusrid->Visible) { // filterusrid ?>
	<?php if ($vtranshistorybyuserwithnames_list->SortUrl($vtranshistorybyuserwithnames_list->filterusrid) == "") { ?>
		<th data-name="filterusrid" class="<?php echo $vtranshistorybyuserwithnames_list->filterusrid->headerCellClass() ?>"><div id="elh_vtranshistorybyuserwithnames_filterusrid" class="vtranshistorybyuserwithnames_filterusrid"><div class="ew-table-header-caption"><?php echo $vtranshistorybyuserwithnames_list->filterusrid->caption() ?></div></div></th>
	<?php } else { ?>
		<th data-name="filterusrid" class="<?php echo $vtranshistorybyuserwithnames_list->filterusrid->headerCellClass() ?>"><div class="ew-pointer" onclick="ew.sort(event, '<?php echo $vtranshistorybyuserwithnames_list->SortUrl($vtranshistorybyuserwithnames_list->filterusrid) ?>', 1);"><div id="elh_vtranshistorybyuserwithnames_filterusrid" class="vtranshistorybyuserwithnames_filterusrid">
			<div class="ew-table-header-btn"><span class="ew-table-header-caption"><?php echo $vtranshistorybyuserwithnames_list->filterusrid->caption() ?></span><span class="ew-table-header-sort"><?php if ($vtranshistorybyuserwithnames_list->filterusrid->getSort() == "ASC") { ?><i class="fas fa-sort-up"></i><?php } elseif ($vtranshistorybyuserwithnames_list->filterusrid->getSort() == "DESC") { ?><i class="fas fa-sort-down"></i><?php } ?></span></div>
		</div></div></th>
	<?php } ?>
<?php } ?>
<?php if ($vtranshistorybyuserwithnames_list->firstName->Visible) { // firstName ?>
	<?php if ($vtranshistorybyuserwithnames_list->SortUrl($vtranshistorybyuserwithnames_list->firstName) == "") { ?>
		<th data-name="firstName" class="<?php echo $vtranshistorybyuserwithnames_list->firstName->headerCellClass() ?>"><div id="elh_vtranshistorybyuserwithnames_firstName" class="vtranshistorybyuserwithnames_firstName"><div class="ew-table-header-caption"><?php echo $vtranshistorybyuserwithnames_list->firstName->caption() ?></div></div></th>
	<?php } else { ?>
		<th data-name="firstName" class="<?php echo $vtranshistorybyuserwithnames_list->firstName->headerCellClass() ?>"><div class="ew-pointer" onclick="ew.sort(event, '<?php echo $vtranshistorybyuserwithnames_list->SortUrl($vtranshistorybyuserwithnames_list->firstName) ?>', 1);"><div id="elh_vtranshistorybyuserwithnames_firstName" class="vtranshistorybyuserwithnames_firstName">
			<div class="ew-table-header-btn"><span class="ew-table-header-caption"><?php echo $vtranshistorybyuserwithnames_list->firstName->caption() ?><?php echo $Language->phrase("SrchLegend") ?></span><span class="ew-table-header-sort"><?php if ($vtranshistorybyuserwithnames_list->firstName->getSort() == "ASC") { ?><i class="fas fa-sort-up"></i><?php } elseif ($vtranshistorybyuserwithnames_list->firstName->getSort() == "DESC") { ?><i class="fas fa-sort-down"></i><?php } ?></span></div>
		</div></div></th>
	<?php } ?>
<?php } ?>
<?php if ($vtranshistorybyuserwithnames_list->lastName->Visible) { // lastName ?>
	<?php if ($vtranshistorybyuserwithnames_list->SortUrl($vtranshistorybyuserwithnames_list->lastName) == "") { ?>
		<th data-name="lastName" class="<?php echo $vtranshistorybyuserwithnames_list->lastName->headerCellClass() ?>"><div id="elh_vtranshistorybyuserwithnames_lastName" class="vtranshistorybyuserwithnames_lastName"><div class="ew-table-header-caption"><?php echo $vtranshistorybyuserwithnames_list->lastName->caption() ?></div></div></th>
	<?php } else { ?>
		<th data-name="lastName" class="<?php echo $vtranshistorybyuserwithnames_list->lastName->headerCellClass() ?>"><div class="ew-pointer" onclick="ew.sort(event, '<?php echo $vtranshistorybyuserwithnames_list->SortUrl($vtranshistorybyuserwithnames_list->lastName) ?>', 1);"><div id="elh_vtranshistorybyuserwithnames_lastName" class="vtranshistorybyuserwithnames_lastName">
			<div class="ew-table-header-btn"><span class="ew-table-header-caption"><?php echo $vtranshistorybyuserwithnames_list->lastName->caption() ?><?php echo $Language->phrase("SrchLegend") ?></span><span class="ew-table-header-sort"><?php if ($vtranshistorybyuserwithnames_list->lastName->getSort() == "ASC") { ?><i class="fas fa-sort-up"></i><?php } elseif ($vtranshistorybyuserwithnames_list->lastName->getSort() == "DESC") { ?><i class="fas fa-sort-down"></i><?php } ?></span></div>
		</div></div></th>
	<?php } ?>
<?php } ?>
<?php if ($vtranshistorybyuserwithnames_list->address2->Visible) { // address2 ?>
	<?php if ($vtranshistorybyuserwithnames_list->SortUrl($vtranshistorybyuserwithnames_list->address2) == "") { ?>
		<th data-name="address2" class="<?php echo $vtranshistorybyuserwithnames_list->address2->headerCellClass() ?>"><div id="elh_vtranshistorybyuserwithnames_address2" class="vtranshistorybyuserwithnames_address2"><div class="ew-table-header-caption"><?php echo $vtranshistorybyuserwithnames_list->address2->caption() ?></div></div></th>
	<?php } else { ?>
		<th data-name="address2" class="<?php echo $vtranshistorybyuserwithnames_list->address2->headerCellClass() ?>"><div class="ew-pointer" onclick="ew.sort(event, '<?php echo $vtranshistorybyuserwithnames_list->SortUrl($vtranshistorybyuserwithnames_list->address2) ?>', 1);"><div id="elh_vtranshistorybyuserwithnames_address2" class="vtranshistorybyuserwithnames_address2">
			<div class="ew-table-header-btn"><span class="ew-table-header-caption"><?php echo $vtranshistorybyuserwithnames_list->address2->caption() ?><?php echo $Language->phrase("SrchLegend") ?></span><span class="ew-table-header-sort"><?php if ($vtranshistorybyuserwithnames_list->address2->getSort() == "ASC") { ?><i class="fas fa-sort-up"></i><?php } elseif ($vtranshistorybyuserwithnames_list->address2->getSort() == "DESC") { ?><i class="fas fa-sort-down"></i><?php } ?></span></div>
		</div></div></th>
	<?php } ?>
<?php } ?>
<?php if ($vtranshistorybyuserwithnames_list->address1->Visible) { // address1 ?>
	<?php if ($vtranshistorybyuserwithnames_list->SortUrl($vtranshistorybyuserwithnames_list->address1) == "") { ?>
		<th data-name="address1" class="<?php echo $vtranshistorybyuserwithnames_list->address1->headerCellClass() ?>"><div id="elh_vtranshistorybyuserwithnames_address1" class="vtranshistorybyuserwithnames_address1"><div class="ew-table-header-caption"><?php echo $vtranshistorybyuserwithnames_list->address1->caption() ?></div></div></th>
	<?php } else { ?>
		<th data-name="address1" class="<?php echo $vtranshistorybyuserwithnames_list->address1->headerCellClass() ?>"><div class="ew-pointer" onclick="ew.sort(event, '<?php echo $vtranshistorybyuserwithnames_list->SortUrl($vtranshistorybyuserwithnames_list->address1) ?>', 1);"><div id="elh_vtranshistorybyuserwithnames_address1" class="vtranshistorybyuserwithnames_address1">
			<div class="ew-table-header-btn"><span class="ew-table-header-caption"><?php echo $vtranshistorybyuserwithnames_list->address1->caption() ?><?php echo $Language->phrase("SrchLegend") ?></span><span class="ew-table-header-sort"><?php if ($vtranshistorybyuserwithnames_list->address1->getSort() == "ASC") { ?><i class="fas fa-sort-up"></i><?php } elseif ($vtranshistorybyuserwithnames_list->address1->getSort() == "DESC") { ?><i class="fas fa-sort-down"></i><?php } ?></span></div>
		</div></div></th>
	<?php } ?>
<?php } ?>
<?php if ($vtranshistorybyuserwithnames_list->cityname->Visible) { // cityname ?>
	<?php if ($vtranshistorybyuserwithnames_list->SortUrl($vtranshistorybyuserwithnames_list->cityname) == "") { ?>
		<th data-name="cityname" class="<?php echo $vtranshistorybyuserwithnames_list->cityname->headerCellClass() ?>"><div id="elh_vtranshistorybyuserwithnames_cityname" class="vtranshistorybyuserwithnames_cityname"><div class="ew-table-header-caption"><?php echo $vtranshistorybyuserwithnames_list->cityname->caption() ?></div></div></th>
	<?php } else { ?>
		<th data-name="cityname" class="<?php echo $vtranshistorybyuserwithnames_list->cityname->headerCellClass() ?>"><div class="ew-pointer" onclick="ew.sort(event, '<?php echo $vtranshistorybyuserwithnames_list->SortUrl($vtranshistorybyuserwithnames_list->cityname) ?>', 1);"><div id="elh_vtranshistorybyuserwithnames_cityname" class="vtranshistorybyuserwithnames_cityname">
			<div class="ew-table-header-btn"><span class="ew-table-header-caption"><?php echo $vtranshistorybyuserwithnames_list->cityname->caption() ?><?php echo $Language->phrase("SrchLegend") ?></span><span class="ew-table-header-sort"><?php if ($vtranshistorybyuserwithnames_list->cityname->getSort() == "ASC") { ?><i class="fas fa-sort-up"></i><?php } elseif ($vtranshistorybyuserwithnames_list->cityname->getSort() == "DESC") { ?><i class="fas fa-sort-down"></i><?php } ?></span></div>
		</div></div></th>
	<?php } ?>
<?php } ?>
<?php if ($vtranshistorybyuserwithnames_list->stateid->Visible) { // stateid ?>
	<?php if ($vtranshistorybyuserwithnames_list->SortUrl($vtranshistorybyuserwithnames_list->stateid) == "") { ?>
		<th data-name="stateid" class="<?php echo $vtranshistorybyuserwithnames_list->stateid->headerCellClass() ?>"><div id="elh_vtranshistorybyuserwithnames_stateid" class="vtranshistorybyuserwithnames_stateid"><div class="ew-table-header-caption"><?php echo $vtranshistorybyuserwithnames_list->stateid->caption() ?></div></div></th>
	<?php } else { ?>
		<th data-name="stateid" class="<?php echo $vtranshistorybyuserwithnames_list->stateid->headerCellClass() ?>"><div class="ew-pointer" onclick="ew.sort(event, '<?php echo $vtranshistorybyuserwithnames_list->SortUrl($vtranshistorybyuserwithnames_list->stateid) ?>', 1);"><div id="elh_vtranshistorybyuserwithnames_stateid" class="vtranshistorybyuserwithnames_stateid">
			<div class="ew-table-header-btn"><span class="ew-table-header-caption"><?php echo $vtranshistorybyuserwithnames_list->stateid->caption() ?><?php echo $Language->phrase("SrchLegend") ?></span><span class="ew-table-header-sort"><?php if ($vtranshistorybyuserwithnames_list->stateid->getSort() == "ASC") { ?><i class="fas fa-sort-up"></i><?php } elseif ($vtranshistorybyuserwithnames_list->stateid->getSort() == "DESC") { ?><i class="fas fa-sort-down"></i><?php } ?></span></div>
		</div></div></th>
	<?php } ?>
<?php } ?>
<?php if ($vtranshistorybyuserwithnames_list->countryid->Visible) { // countryid ?>
	<?php if ($vtranshistorybyuserwithnames_list->SortUrl($vtranshistorybyuserwithnames_list->countryid) == "") { ?>
		<th data-name="countryid" class="<?php echo $vtranshistorybyuserwithnames_list->countryid->headerCellClass() ?>"><div id="elh_vtranshistorybyuserwithnames_countryid" class="vtranshistorybyuserwithnames_countryid"><div class="ew-table-header-caption"><?php echo $vtranshistorybyuserwithnames_list->countryid->caption() ?></div></div></th>
	<?php } else { ?>
		<th data-name="countryid" class="<?php echo $vtranshistorybyuserwithnames_list->countryid->headerCellClass() ?>"><div class="ew-pointer" onclick="ew.sort(event, '<?php echo $vtranshistorybyuserwithnames_list->SortUrl($vtranshistorybyuserwithnames_list->countryid) ?>', 1);"><div id="elh_vtranshistorybyuserwithnames_countryid" class="vtranshistorybyuserwithnames_countryid">
			<div class="ew-table-header-btn"><span class="ew-table-header-caption"><?php echo $vtranshistorybyuserwithnames_list->countryid->caption() ?><?php echo $Language->phrase("SrchLegend") ?></span><span class="ew-table-header-sort"><?php if ($vtranshistorybyuserwithnames_list->countryid->getSort() == "ASC") { ?><i class="fas fa-sort-up"></i><?php } elseif ($vtranshistorybyuserwithnames_list->countryid->getSort() == "DESC") { ?><i class="fas fa-sort-down"></i><?php } ?></span></div>
		</div></div></th>
	<?php } ?>
<?php } ?>
<?php if ($vtranshistorybyuserwithnames_list->zip->Visible) { // zip ?>
	<?php if ($vtranshistorybyuserwithnames_list->SortUrl($vtranshistorybyuserwithnames_list->zip) == "") { ?>
		<th data-name="zip" class="<?php echo $vtranshistorybyuserwithnames_list->zip->headerCellClass() ?>"><div id="elh_vtranshistorybyuserwithnames_zip" class="vtranshistorybyuserwithnames_zip"><div class="ew-table-header-caption"><?php echo $vtranshistorybyuserwithnames_list->zip->caption() ?></div></div></th>
	<?php } else { ?>
		<th data-name="zip" class="<?php echo $vtranshistorybyuserwithnames_list->zip->headerCellClass() ?>"><div class="ew-pointer" onclick="ew.sort(event, '<?php echo $vtranshistorybyuserwithnames_list->SortUrl($vtranshistorybyuserwithnames_list->zip) ?>', 1);"><div id="elh_vtranshistorybyuserwithnames_zip" class="vtranshistorybyuserwithnames_zip">
			<div class="ew-table-header-btn"><span class="ew-table-header-caption"><?php echo $vtranshistorybyuserwithnames_list->zip->caption() ?><?php echo $Language->phrase("SrchLegend") ?></span><span class="ew-table-header-sort"><?php if ($vtranshistorybyuserwithnames_list->zip->getSort() == "ASC") { ?><i class="fas fa-sort-up"></i><?php } elseif ($vtranshistorybyuserwithnames_list->zip->getSort() == "DESC") { ?><i class="fas fa-sort-down"></i><?php } ?></span></div>
		</div></div></th>
	<?php } ?>
<?php } ?>
<?php if ($vtranshistorybyuserwithnames_list->countryname->Visible) { // countryname ?>
	<?php if ($vtranshistorybyuserwithnames_list->SortUrl($vtranshistorybyuserwithnames_list->countryname) == "") { ?>
		<th data-name="countryname" class="<?php echo $vtranshistorybyuserwithnames_list->countryname->headerCellClass() ?>"><div id="elh_vtranshistorybyuserwithnames_countryname" class="vtranshistorybyuserwithnames_countryname"><div class="ew-table-header-caption"><?php echo $vtranshistorybyuserwithnames_list->countryname->caption() ?></div></div></th>
	<?php } else { ?>
		<th data-name="countryname" class="<?php echo $vtranshistorybyuserwithnames_list->countryname->headerCellClass() ?>"><div class="ew-pointer" onclick="ew.sort(event, '<?php echo $vtranshistorybyuserwithnames_list->SortUrl($vtranshistorybyuserwithnames_list->countryname) ?>', 1);"><div id="elh_vtranshistorybyuserwithnames_countryname" class="vtranshistorybyuserwithnames_countryname">
			<div class="ew-table-header-btn"><span class="ew-table-header-caption"><?php echo $vtranshistorybyuserwithnames_list->countryname->caption() ?><?php echo $Language->phrase("SrchLegend") ?></span><span class="ew-table-header-sort"><?php if ($vtranshistorybyuserwithnames_list->countryname->getSort() == "ASC") { ?><i class="fas fa-sort-up"></i><?php } elseif ($vtranshistorybyuserwithnames_list->countryname->getSort() == "DESC") { ?><i class="fas fa-sort-down"></i><?php } ?></span></div>
		</div></div></th>
	<?php } ?>
<?php } ?>
<?php if ($vtranshistorybyuserwithnames_list->parentuserid->Visible) { // parentuserid ?>
	<?php if ($vtranshistorybyuserwithnames_list->SortUrl($vtranshistorybyuserwithnames_list->parentuserid) == "") { ?>
		<th data-name="parentuserid" class="<?php echo $vtranshistorybyuserwithnames_list->parentuserid->headerCellClass() ?>"><div id="elh_vtranshistorybyuserwithnames_parentuserid" class="vtranshistorybyuserwithnames_parentuserid"><div class="ew-table-header-caption"><?php echo $vtranshistorybyuserwithnames_list->parentuserid->caption() ?></div></div></th>
	<?php } else { ?>
		<th data-name="parentuserid" class="<?php echo $vtranshistorybyuserwithnames_list->parentuserid->headerCellClass() ?>"><div class="ew-pointer" onclick="ew.sort(event, '<?php echo $vtranshistorybyuserwithnames_list->SortUrl($vtranshistorybyuserwithnames_list->parentuserid) ?>', 1);"><div id="elh_vtranshistorybyuserwithnames_parentuserid" class="vtranshistorybyuserwithnames_parentuserid">
			<div class="ew-table-header-btn"><span class="ew-table-header-caption"><?php echo $vtranshistorybyuserwithnames_list->parentuserid->caption() ?></span><span class="ew-table-header-sort"><?php if ($vtranshistorybyuserwithnames_list->parentuserid->getSort() == "ASC") { ?><i class="fas fa-sort-up"></i><?php } elseif ($vtranshistorybyuserwithnames_list->parentuserid->getSort() == "DESC") { ?><i class="fas fa-sort-down"></i><?php } ?></span></div>
		</div></div></th>
	<?php } ?>
<?php } ?>
<?php if ($vtranshistorybyuserwithnames_list->emailAccount->Visible) { // emailAccount ?>
	<?php if ($vtranshistorybyuserwithnames_list->SortUrl($vtranshistorybyuserwithnames_list->emailAccount) == "") { ?>
		<th data-name="emailAccount" class="<?php echo $vtranshistorybyuserwithnames_list->emailAccount->headerCellClass() ?>"><div id="elh_vtranshistorybyuserwithnames_emailAccount" class="vtranshistorybyuserwithnames_emailAccount"><div class="ew-table-header-caption"><?php echo $vtranshistorybyuserwithnames_list->emailAccount->caption() ?></div></div></th>
	<?php } else { ?>
		<th data-name="emailAccount" class="<?php echo $vtranshistorybyuserwithnames_list->emailAccount->headerCellClass() ?>"><div class="ew-pointer" onclick="ew.sort(event, '<?php echo $vtranshistorybyuserwithnames_list->SortUrl($vtranshistorybyuserwithnames_list->emailAccount) ?>', 1);"><div id="elh_vtranshistorybyuserwithnames_emailAccount" class="vtranshistorybyuserwithnames_emailAccount">
			<div class="ew-table-header-btn"><span class="ew-table-header-caption"><?php echo $vtranshistorybyuserwithnames_list->emailAccount->caption() ?><?php echo $Language->phrase("SrchLegend") ?></span><span class="ew-table-header-sort"><?php if ($vtranshistorybyuserwithnames_list->emailAccount->getSort() == "ASC") { ?><i class="fas fa-sort-up"></i><?php } elseif ($vtranshistorybyuserwithnames_list->emailAccount->getSort() == "DESC") { ?><i class="fas fa-sort-down"></i><?php } ?></span></div>
		</div></div></th>
	<?php } ?>
<?php } ?>
<?php if ($vtranshistorybyuserwithnames_list->statename->Visible) { // statename ?>
	<?php if ($vtranshistorybyuserwithnames_list->SortUrl($vtranshistorybyuserwithnames_list->statename) == "") { ?>
		<th data-name="statename" class="<?php echo $vtranshistorybyuserwithnames_list->statename->headerCellClass() ?>"><div id="elh_vtranshistorybyuserwithnames_statename" class="vtranshistorybyuserwithnames_statename"><div class="ew-table-header-caption"><?php echo $vtranshistorybyuserwithnames_list->statename->caption() ?></div></div></th>
	<?php } else { ?>
		<th data-name="statename" class="<?php echo $vtranshistorybyuserwithnames_list->statename->headerCellClass() ?>"><div class="ew-pointer" onclick="ew.sort(event, '<?php echo $vtranshistorybyuserwithnames_list->SortUrl($vtranshistorybyuserwithnames_list->statename) ?>', 1);"><div id="elh_vtranshistorybyuserwithnames_statename" class="vtranshistorybyuserwithnames_statename">
			<div class="ew-table-header-btn"><span class="ew-table-header-caption"><?php echo $vtranshistorybyuserwithnames_list->statename->caption() ?><?php echo $Language->phrase("SrchLegend") ?></span><span class="ew-table-header-sort"><?php if ($vtranshistorybyuserwithnames_list->statename->getSort() == "ASC") { ?><i class="fas fa-sort-up"></i><?php } elseif ($vtranshistorybyuserwithnames_list->statename->getSort() == "DESC") { ?><i class="fas fa-sort-down"></i><?php } ?></span></div>
		</div></div></th>
	<?php } ?>
<?php } ?>
<?php

// Render list options (header, right)
$vtranshistorybyuserwithnames_list->ListOptions->render("header", "right");
?>
	</tr>
</thead>
<tbody>
<?php
if ($vtranshistorybyuserwithnames_list->ExportAll && $vtranshistorybyuserwithnames_list->isExport()) {
	$vtranshistorybyuserwithnames_list->StopRecord = $vtranshistorybyuserwithnames_list->TotalRecords;
} else {

	// Set the last record to display
	if ($vtranshistorybyuserwithnames_list->TotalRecords > $vtranshistorybyuserwithnames_list->StartRecord + $vtranshistorybyuserwithnames_list->DisplayRecords - 1)
		$vtranshistorybyuserwithnames_list->StopRecord = $vtranshistorybyuserwithnames_list->StartRecord + $vtranshistorybyuserwithnames_list->DisplayRecords - 1;
	else
		$vtranshistorybyuserwithnames_list->StopRecord = $vtranshistorybyuserwithnames_list->TotalRecords;
}
$vtranshistorybyuserwithnames_list->RecordCount = $vtranshistorybyuserwithnames_list->StartRecord - 1;
if ($vtranshistorybyuserwithnames_list->Recordset && !$vtranshistorybyuserwithnames_list->Recordset->EOF) {
	$vtranshistorybyuserwithnames_list->Recordset->moveFirst();
	$selectLimit = $vtranshistorybyuserwithnames_list->UseSelectLimit;
	if (!$selectLimit && $vtranshistorybyuserwithnames_list->StartRecord > 1)
		$vtranshistorybyuserwithnames_list->Recordset->move($vtranshistorybyuserwithnames_list->StartRecord - 1);
} elseif (!$vtranshistorybyuserwithnames->AllowAddDeleteRow && $vtranshistorybyuserwithnames_list->StopRecord == 0) {
	$vtranshistorybyuserwithnames_list->StopRecord = $vtranshistorybyuserwithnames->GridAddRowCount;
}

// Initialize aggregate
$vtranshistorybyuserwithnames->RowType = ROWTYPE_AGGREGATEINIT;
$vtranshistorybyuserwithnames->resetAttributes();
$vtranshistorybyuserwithnames_list->renderRow();
while ($vtranshistorybyuserwithnames_list->RecordCount < $vtranshistorybyuserwithnames_list->StopRecord) {
	$vtranshistorybyuserwithnames_list->RecordCount++;
	if ($vtranshistorybyuserwithnames_list->RecordCount >= $vtranshistorybyuserwithnames_list->StartRecord) {
		$vtranshistorybyuserwithnames_list->RowCount++;

		// Set up key count
		$vtranshistorybyuserwithnames_list->KeyCount = $vtranshistorybyuserwithnames_list->RowIndex;

		// Init row class and style
		$vtranshistorybyuserwithnames->resetAttributes();
		$vtranshistorybyuserwithnames->CssClass = "";
		if ($vtranshistorybyuserwithnames_list->isGridAdd()) {
		} else {
			$vtranshistorybyuserwithnames_list->loadRowValues($vtranshistorybyuserwithnames_list->Recordset); // Load row values
		}
		$vtranshistorybyuserwithnames->RowType = ROWTYPE_VIEW; // Render view

		// Set up row id / data-rowindex
		$vtranshistorybyuserwithnames->RowAttrs->merge(["data-rowindex" => $vtranshistorybyuserwithnames_list->RowCount, "id" => "r" . $vtranshistorybyuserwithnames_list->RowCount . "_vtranshistorybyuserwithnames", "data-rowtype" => $vtranshistorybyuserwithnames->RowType]);

		// Render row
		$vtranshistorybyuserwithnames_list->renderRow();

		// Render list options
		$vtranshistorybyuserwithnames_list->renderListOptions();
?>
	<tr <?php echo $vtranshistorybyuserwithnames->rowAttributes() ?>>
<?php

// Render list options (body, left)
$vtranshistorybyuserwithnames_list->ListOptions->render("body", "left", $vtranshistorybyuserwithnames_list->RowCount);
?>
	<?php if ($vtranshistorybyuserwithnames_list->rolename->Visible) { // rolename ?>
		<td data-name="rolename" <?php echo $vtranshistorybyuserwithnames_list->rolename->cellAttributes() ?>>
<span id="el<?php echo $vtranshistorybyuserwithnames_list->RowCount ?>_vtranshistorybyuserwithnames_rolename">
<span<?php echo $vtranshistorybyuserwithnames_list->rolename->viewAttributes() ?>><?php echo $vtranshistorybyuserwithnames_list->rolename->getViewValue() ?></span>
</span>
</td>
	<?php } ?>
	<?php if ($vtranshistorybyuserwithnames_list->roleid->Visible) { // roleid ?>
		<td data-name="roleid" <?php echo $vtranshistorybyuserwithnames_list->roleid->cellAttributes() ?>>
<span id="el<?php echo $vtranshistorybyuserwithnames_list->RowCount ?>_vtranshistorybyuserwithnames_roleid">
<span<?php echo $vtranshistorybyuserwithnames_list->roleid->viewAttributes() ?>><?php echo $vtranshistorybyuserwithnames_list->roleid->getViewValue() ?></span>
</span>
</td>
	<?php } ?>
	<?php if ($vtranshistorybyuserwithnames_list->sourceUserID->Visible) { // sourceUserID ?>
		<td data-name="sourceUserID" <?php echo $vtranshistorybyuserwithnames_list->sourceUserID->cellAttributes() ?>>
<span id="el<?php echo $vtranshistorybyuserwithnames_list->RowCount ?>_vtranshistorybyuserwithnames_sourceUserID">
<span<?php echo $vtranshistorybyuserwithnames_list->sourceUserID->viewAttributes() ?>><?php echo $vtranshistorybyuserwithnames_list->sourceUserID->getViewValue() ?></span>
</span>
</td>
	<?php } ?>
	<?php if ($vtranshistorybyuserwithnames_list->acctID->Visible) { // acctID ?>
		<td data-name="acctID" <?php echo $vtranshistorybyuserwithnames_list->acctID->cellAttributes() ?>>
<span id="el<?php echo $vtranshistorybyuserwithnames_list->RowCount ?>_vtranshistorybyuserwithnames_acctID">
<span<?php echo $vtranshistorybyuserwithnames_list->acctID->viewAttributes() ?>><?php echo $vtranshistorybyuserwithnames_list->acctID->getViewValue() ?></span>
</span>
</td>
	<?php } ?>
	<?php if ($vtranshistorybyuserwithnames_list->currID->Visible) { // currID ?>
		<td data-name="currID" <?php echo $vtranshistorybyuserwithnames_list->currID->cellAttributes() ?>>
<span id="el<?php echo $vtranshistorybyuserwithnames_list->RowCount ?>_vtranshistorybyuserwithnames_currID">
<span<?php echo $vtranshistorybyuserwithnames_list->currID->viewAttributes() ?>><?php echo $vtranshistorybyuserwithnames_list->currID->getViewValue() ?></span>
</span>
</td>
	<?php } ?>
	<?php if ($vtranshistorybyuserwithnames_list->amount->Visible) { // amount ?>
		<td data-name="amount" <?php echo $vtranshistorybyuserwithnames_list->amount->cellAttributes() ?>>
<span id="el<?php echo $vtranshistorybyuserwithnames_list->RowCount ?>_vtranshistorybyuserwithnames_amount">
<span<?php echo $vtranshistorybyuserwithnames_list->amount->viewAttributes() ?>><?php echo $vtranshistorybyuserwithnames_list->amount->getViewValue() ?></span>
</span>
</td>
	<?php } ?>
	<?php if ($vtranshistorybyuserwithnames_list->transTime->Visible) { // transTime ?>
		<td data-name="transTime" <?php echo $vtranshistorybyuserwithnames_list->transTime->cellAttributes() ?>>
<span id="el<?php echo $vtranshistorybyuserwithnames_list->RowCount ?>_vtranshistorybyuserwithnames_transTime">
<span<?php echo $vtranshistorybyuserwithnames_list->transTime->viewAttributes() ?>><?php echo $vtranshistorybyuserwithnames_list->transTime->getViewValue() ?></span>
</span>
</td>
	<?php } ?>
	<?php if ($vtranshistorybyuserwithnames_list->transType->Visible) { // transType ?>
		<td data-name="transType" <?php echo $vtranshistorybyuserwithnames_list->transType->cellAttributes() ?>>
<span id="el<?php echo $vtranshistorybyuserwithnames_list->RowCount ?>_vtranshistorybyuserwithnames_transType">
<span<?php echo $vtranshistorybyuserwithnames_list->transType->viewAttributes() ?>><?php echo $vtranshistorybyuserwithnames_list->transType->getViewValue() ?></span>
</span>
</td>
	<?php } ?>
	<?php if ($vtranshistorybyuserwithnames_list->destinationUserID->Visible) { // destinationUserID ?>
		<td data-name="destinationUserID" <?php echo $vtranshistorybyuserwithnames_list->destinationUserID->cellAttributes() ?>>
<span id="el<?php echo $vtranshistorybyuserwithnames_list->RowCount ?>_vtranshistorybyuserwithnames_destinationUserID">
<span<?php echo $vtranshistorybyuserwithnames_list->destinationUserID->viewAttributes() ?>><?php echo $vtranshistorybyuserwithnames_list->destinationUserID->getViewValue() ?></span>
</span>
</td>
	<?php } ?>
	<?php if ($vtranshistorybyuserwithnames_list->referenceTXID->Visible) { // referenceTXID ?>
		<td data-name="referenceTXID" <?php echo $vtranshistorybyuserwithnames_list->referenceTXID->cellAttributes() ?>>
<span id="el<?php echo $vtranshistorybyuserwithnames_list->RowCount ?>_vtranshistorybyuserwithnames_referenceTXID">
<span<?php echo $vtranshistorybyuserwithnames_list->referenceTXID->viewAttributes() ?>><?php echo $vtranshistorybyuserwithnames_list->referenceTXID->getViewValue() ?></span>
</span>
</td>
	<?php } ?>
	<?php if ($vtranshistorybyuserwithnames_list->langID->Visible) { // langID ?>
		<td data-name="langID" <?php echo $vtranshistorybyuserwithnames_list->langID->cellAttributes() ?>>
<span id="el<?php echo $vtranshistorybyuserwithnames_list->RowCount ?>_vtranshistorybyuserwithnames_langID">
<span<?php echo $vtranshistorybyuserwithnames_list->langID->viewAttributes() ?>><?php echo $vtranshistorybyuserwithnames_list->langID->getViewValue() ?></span>
</span>
</td>
	<?php } ?>
	<?php if ($vtranshistorybyuserwithnames_list->transID->Visible) { // transID ?>
		<td data-name="transID" <?php echo $vtranshistorybyuserwithnames_list->transID->cellAttributes() ?>>
<span id="el<?php echo $vtranshistorybyuserwithnames_list->RowCount ?>_vtranshistorybyuserwithnames_transID">
<span<?php echo $vtranshistorybyuserwithnames_list->transID->viewAttributes() ?>><?php echo $vtranshistorybyuserwithnames_list->transID->getViewValue() ?></span>
</span>
</td>
	<?php } ?>
	<?php if ($vtranshistorybyuserwithnames_list->filterusrid->Visible) { // filterusrid ?>
		<td data-name="filterusrid" <?php echo $vtranshistorybyuserwithnames_list->filterusrid->cellAttributes() ?>>
<span id="el<?php echo $vtranshistorybyuserwithnames_list->RowCount ?>_vtranshistorybyuserwithnames_filterusrid">
<span<?php echo $vtranshistorybyuserwithnames_list->filterusrid->viewAttributes() ?>><?php echo $vtranshistorybyuserwithnames_list->filterusrid->getViewValue() ?></span>
</span>
</td>
	<?php } ?>
	<?php if ($vtranshistorybyuserwithnames_list->firstName->Visible) { // firstName ?>
		<td data-name="firstName" <?php echo $vtranshistorybyuserwithnames_list->firstName->cellAttributes() ?>>
<span id="el<?php echo $vtranshistorybyuserwithnames_list->RowCount ?>_vtranshistorybyuserwithnames_firstName">
<span<?php echo $vtranshistorybyuserwithnames_list->firstName->viewAttributes() ?>><?php echo $vtranshistorybyuserwithnames_list->firstName->getViewValue() ?></span>
</span>
</td>
	<?php } ?>
	<?php if ($vtranshistorybyuserwithnames_list->lastName->Visible) { // lastName ?>
		<td data-name="lastName" <?php echo $vtranshistorybyuserwithnames_list->lastName->cellAttributes() ?>>
<span id="el<?php echo $vtranshistorybyuserwithnames_list->RowCount ?>_vtranshistorybyuserwithnames_lastName">
<span<?php echo $vtranshistorybyuserwithnames_list->lastName->viewAttributes() ?>><?php echo $vtranshistorybyuserwithnames_list->lastName->getViewValue() ?></span>
</span>
</td>
	<?php } ?>
	<?php if ($vtranshistorybyuserwithnames_list->address2->Visible) { // address2 ?>
		<td data-name="address2" <?php echo $vtranshistorybyuserwithnames_list->address2->cellAttributes() ?>>
<span id="el<?php echo $vtranshistorybyuserwithnames_list->RowCount ?>_vtranshistorybyuserwithnames_address2">
<span<?php echo $vtranshistorybyuserwithnames_list->address2->viewAttributes() ?>><?php echo $vtranshistorybyuserwithnames_list->address2->getViewValue() ?></span>
</span>
</td>
	<?php } ?>
	<?php if ($vtranshistorybyuserwithnames_list->address1->Visible) { // address1 ?>
		<td data-name="address1" <?php echo $vtranshistorybyuserwithnames_list->address1->cellAttributes() ?>>
<span id="el<?php echo $vtranshistorybyuserwithnames_list->RowCount ?>_vtranshistorybyuserwithnames_address1">
<span<?php echo $vtranshistorybyuserwithnames_list->address1->viewAttributes() ?>><?php echo $vtranshistorybyuserwithnames_list->address1->getViewValue() ?></span>
</span>
</td>
	<?php } ?>
	<?php if ($vtranshistorybyuserwithnames_list->cityname->Visible) { // cityname ?>
		<td data-name="cityname" <?php echo $vtranshistorybyuserwithnames_list->cityname->cellAttributes() ?>>
<span id="el<?php echo $vtranshistorybyuserwithnames_list->RowCount ?>_vtranshistorybyuserwithnames_cityname">
<span<?php echo $vtranshistorybyuserwithnames_list->cityname->viewAttributes() ?>><?php echo $vtranshistorybyuserwithnames_list->cityname->getViewValue() ?></span>
</span>
</td>
	<?php } ?>
	<?php if ($vtranshistorybyuserwithnames_list->stateid->Visible) { // stateid ?>
		<td data-name="stateid" <?php echo $vtranshistorybyuserwithnames_list->stateid->cellAttributes() ?>>
<span id="el<?php echo $vtranshistorybyuserwithnames_list->RowCount ?>_vtranshistorybyuserwithnames_stateid">
<span<?php echo $vtranshistorybyuserwithnames_list->stateid->viewAttributes() ?>><?php echo $vtranshistorybyuserwithnames_list->stateid->getViewValue() ?></span>
</span>
</td>
	<?php } ?>
	<?php if ($vtranshistorybyuserwithnames_list->countryid->Visible) { // countryid ?>
		<td data-name="countryid" <?php echo $vtranshistorybyuserwithnames_list->countryid->cellAttributes() ?>>
<span id="el<?php echo $vtranshistorybyuserwithnames_list->RowCount ?>_vtranshistorybyuserwithnames_countryid">
<span<?php echo $vtranshistorybyuserwithnames_list->countryid->viewAttributes() ?>><?php echo $vtranshistorybyuserwithnames_list->countryid->getViewValue() ?></span>
</span>
</td>
	<?php } ?>
	<?php if ($vtranshistorybyuserwithnames_list->zip->Visible) { // zip ?>
		<td data-name="zip" <?php echo $vtranshistorybyuserwithnames_list->zip->cellAttributes() ?>>
<span id="el<?php echo $vtranshistorybyuserwithnames_list->RowCount ?>_vtranshistorybyuserwithnames_zip">
<span<?php echo $vtranshistorybyuserwithnames_list->zip->viewAttributes() ?>><?php echo $vtranshistorybyuserwithnames_list->zip->getViewValue() ?></span>
</span>
</td>
	<?php } ?>
	<?php if ($vtranshistorybyuserwithnames_list->countryname->Visible) { // countryname ?>
		<td data-name="countryname" <?php echo $vtranshistorybyuserwithnames_list->countryname->cellAttributes() ?>>
<span id="el<?php echo $vtranshistorybyuserwithnames_list->RowCount ?>_vtranshistorybyuserwithnames_countryname">
<span<?php echo $vtranshistorybyuserwithnames_list->countryname->viewAttributes() ?>><?php echo $vtranshistorybyuserwithnames_list->countryname->getViewValue() ?></span>
</span>
</td>
	<?php } ?>
	<?php if ($vtranshistorybyuserwithnames_list->parentuserid->Visible) { // parentuserid ?>
		<td data-name="parentuserid" <?php echo $vtranshistorybyuserwithnames_list->parentuserid->cellAttributes() ?>>
<span id="el<?php echo $vtranshistorybyuserwithnames_list->RowCount ?>_vtranshistorybyuserwithnames_parentuserid">
<span<?php echo $vtranshistorybyuserwithnames_list->parentuserid->viewAttributes() ?>><?php echo $vtranshistorybyuserwithnames_list->parentuserid->getViewValue() ?></span>
</span>
</td>
	<?php } ?>
	<?php if ($vtranshistorybyuserwithnames_list->emailAccount->Visible) { // emailAccount ?>
		<td data-name="emailAccount" <?php echo $vtranshistorybyuserwithnames_list->emailAccount->cellAttributes() ?>>
<span id="el<?php echo $vtranshistorybyuserwithnames_list->RowCount ?>_vtranshistorybyuserwithnames_emailAccount">
<span<?php echo $vtranshistorybyuserwithnames_list->emailAccount->viewAttributes() ?>><?php echo $vtranshistorybyuserwithnames_list->emailAccount->getViewValue() ?></span>
</span>
</td>
	<?php } ?>
	<?php if ($vtranshistorybyuserwithnames_list->statename->Visible) { // statename ?>
		<td data-name="statename" <?php echo $vtranshistorybyuserwithnames_list->statename->cellAttributes() ?>>
<span id="el<?php echo $vtranshistorybyuserwithnames_list->RowCount ?>_vtranshistorybyuserwithnames_statename">
<span<?php echo $vtranshistorybyuserwithnames_list->statename->viewAttributes() ?>><?php echo $vtranshistorybyuserwithnames_list->statename->getViewValue() ?></span>
</span>
</td>
	<?php } ?>
<?php

// Render list options (body, right)
$vtranshistorybyuserwithnames_list->ListOptions->render("body", "right", $vtranshistorybyuserwithnames_list->RowCount);
?>
	</tr>
<?php
	}
	if (!$vtranshistorybyuserwithnames_list->isGridAdd())
		$vtranshistorybyuserwithnames_list->Recordset->moveNext();
}
?>
</tbody>
</table><!-- /.ew-table -->
<?php } ?>
</div><!-- /.ew-grid-middle-panel -->
<?php if (!$vtranshistorybyuserwithnames->CurrentAction) { ?>
<input type="hidden" name="action" id="action" value="">
<?php } ?>
</form><!-- /.ew-list-form -->
<?php

// Close recordset
if ($vtranshistorybyuserwithnames_list->Recordset)
	$vtranshistorybyuserwithnames_list->Recordset->Close();
?>
<?php if (!$vtranshistorybyuserwithnames_list->isExport()) { ?>
<div class="card-footer ew-grid-lower-panel">
<?php if (!$vtranshistorybyuserwithnames_list->isGridAdd()) { ?>
<form name="ew-pager-form" class="form-inline ew-form ew-pager-form" action="<?php echo CurrentPageName() ?>">
<?php echo $vtranshistorybyuserwithnames_list->Pager->render() ?>
</form>
<?php } ?>
<div class="ew-list-other-options">
<?php $vtranshistorybyuserwithnames_list->OtherOptions->render("body", "bottom") ?>
</div>
<div class="clearfix"></div>
</div>
<?php } ?>
</div><!-- /.ew-grid -->
<?php } ?>
<?php if ($vtranshistorybyuserwithnames_list->TotalRecords == 0 && !$vtranshistorybyuserwithnames->CurrentAction) { // Show other options ?>
<div class="ew-list-other-options">
<?php $vtranshistorybyuserwithnames_list->OtherOptions->render("body") ?>
</div>
<div class="clearfix"></div>
<?php } ?>
<?php
$vtranshistorybyuserwithnames_list->showPageFooter();
if (Config("DEBUG"))
	echo GetDebugMessage();
?>
<?php if (!$vtranshistorybyuserwithnames_list->isExport()) { ?>
<script>
loadjs.ready("load", function() {

	// Startup script
	// Write your table-specific startup script here
	// console.log("page loaded");

});
</script>
<?php } ?>
<?php include_once "footer.php"; ?>
<?php
$vtranshistorybyuserwithnames_list->terminate();
?>