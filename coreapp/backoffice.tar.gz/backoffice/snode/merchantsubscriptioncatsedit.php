<?php
namespace PHPMaker2020\_4payadmin;

// Autoload
include_once "autoload.php";

// Session
if (session_status() !== PHP_SESSION_ACTIVE)
	\Delight\Cookie\Session::start(Config("COOKIE_SAMESITE")); // Init session data

// Output buffering
ob_start();
?>
<?php

// Write header
WriteHeader(FALSE);

// Create page object
$merchantsubscriptioncats_edit = new merchantsubscriptioncats_edit();

// Run the page
$merchantsubscriptioncats_edit->run();

// Setup login status
SetupLoginStatus();
SetClientVar("login", LoginStatus());

// Global Page Rendering event (in userfn*.php)
Page_Rendering();

// Page Rendering event
$merchantsubscriptioncats_edit->Page_Render();
?>
<?php include_once "header.php"; ?>
<script>
var fmerchantsubscriptioncatsedit, currentPageID;
loadjs.ready("head", function() {

	// Form object
	currentPageID = ew.PAGE_ID = "edit";
	fmerchantsubscriptioncatsedit = currentForm = new ew.Form("fmerchantsubscriptioncatsedit", "edit");

	// Validate form
	fmerchantsubscriptioncatsedit.validate = function() {
		if (!this.validateRequired)
			return true; // Ignore validation
		var $ = jQuery, fobj = this.getForm(), $fobj = $(fobj);
		if ($fobj.find("#confirm").val() == "confirm")
			return true;
		var elm, felm, uelm, addcnt = 0;
		var $k = $fobj.find("#" + this.formKeyCountName); // Get key_count
		var rowcnt = ($k[0]) ? parseInt($k.val(), 10) : 1;
		var startcnt = (rowcnt == 0) ? 0 : 1; // Check rowcnt == 0 => Inline-Add
		var gridinsert = ["insert", "gridinsert"].includes($fobj.find("#action").val()) && $k[0];
		for (var i = startcnt; i <= rowcnt; i++) {
			var infix = ($k[0]) ? String(i) : "";
			$fobj.data("rowindex", infix);
			<?php if ($merchantsubscriptioncats_edit->categoryid->Required) { ?>
				elm = this.getElements("x" + infix + "_categoryid");
				if (elm && !ew.isHidden(elm) && !ew.hasValue(elm))
					return this.onError(elm, "<?php echo JsEncode(str_replace("%s", $merchantsubscriptioncats_edit->categoryid->caption(), $merchantsubscriptioncats_edit->categoryid->RequiredErrorMessage)) ?>");
			<?php } ?>
			<?php if ($merchantsubscriptioncats_edit->merchantid->Required) { ?>
				elm = this.getElements("x" + infix + "_merchantid");
				if (elm && !ew.isHidden(elm) && !ew.hasValue(elm))
					return this.onError(elm, "<?php echo JsEncode(str_replace("%s", $merchantsubscriptioncats_edit->merchantid->caption(), $merchantsubscriptioncats_edit->merchantid->RequiredErrorMessage)) ?>");
			<?php } ?>
				elm = this.getElements("x" + infix + "_merchantid");
				if (elm && !ew.checkInteger(elm.value))
					return this.onError(elm, "<?php echo JsEncode($merchantsubscriptioncats_edit->merchantid->errorMessage()) ?>");
			<?php if ($merchantsubscriptioncats_edit->label->Required) { ?>
				elm = this.getElements("x" + infix + "_label");
				if (elm && !ew.isHidden(elm) && !ew.hasValue(elm))
					return this.onError(elm, "<?php echo JsEncode(str_replace("%s", $merchantsubscriptioncats_edit->label->caption(), $merchantsubscriptioncats_edit->label->RequiredErrorMessage)) ?>");
			<?php } ?>
			<?php if ($merchantsubscriptioncats_edit->active->Required) { ?>
				elm = this.getElements("x" + infix + "_active");
				if (elm && !ew.isHidden(elm) && !ew.hasValue(elm))
					return this.onError(elm, "<?php echo JsEncode(str_replace("%s", $merchantsubscriptioncats_edit->active->caption(), $merchantsubscriptioncats_edit->active->RequiredErrorMessage)) ?>");
			<?php } ?>
				elm = this.getElements("x" + infix + "_active");
				if (elm && !ew.checkInteger(elm.value))
					return this.onError(elm, "<?php echo JsEncode($merchantsubscriptioncats_edit->active->errorMessage()) ?>");
			<?php if ($merchantsubscriptioncats_edit->lastupdatedate->Required) { ?>
				elm = this.getElements("x" + infix + "_lastupdatedate");
				if (elm && !ew.isHidden(elm) && !ew.hasValue(elm))
					return this.onError(elm, "<?php echo JsEncode(str_replace("%s", $merchantsubscriptioncats_edit->lastupdatedate->caption(), $merchantsubscriptioncats_edit->lastupdatedate->RequiredErrorMessage)) ?>");
			<?php } ?>
				elm = this.getElements("x" + infix + "_lastupdatedate");
				if (elm && !ew.checkDateDef(elm.value))
					return this.onError(elm, "<?php echo JsEncode($merchantsubscriptioncats_edit->lastupdatedate->errorMessage()) ?>");

				// Call Form_CustomValidate event
				if (!this.Form_CustomValidate(fobj))
					return false;
		}

		// Process detail forms
		var dfs = $fobj.find("input[name='detailpage']").get();
		for (var i = 0; i < dfs.length; i++) {
			var df = dfs[i], val = df.value;
			if (val && ew.forms[val])
				if (!ew.forms[val].validate())
					return false;
		}
		return true;
	}

	// Form_CustomValidate
	fmerchantsubscriptioncatsedit.Form_CustomValidate = function(fobj) { // DO NOT CHANGE THIS LINE!

		// Your custom validation code here, return false if invalid.
		return true;
	}

	// Use JavaScript validation or not
	fmerchantsubscriptioncatsedit.validateRequired = <?php echo Config("CLIENT_VALIDATE") ? "true" : "false" ?>;

	// Dynamic selection lists
	loadjs.done("fmerchantsubscriptioncatsedit");
});
</script>
<script>
loadjs.ready("head", function() {

	// Client script
	// Write your client script here, no need to add script tags.

});
</script>
<?php $merchantsubscriptioncats_edit->showPageHeader(); ?>
<?php
$merchantsubscriptioncats_edit->showMessage();
?>
<form name="fmerchantsubscriptioncatsedit" id="fmerchantsubscriptioncatsedit" class="<?php echo $merchantsubscriptioncats_edit->FormClassName ?>" action="<?php echo CurrentPageName() ?>" method="post">
<?php if ($Page->CheckToken) { ?>
<input type="hidden" name="<?php echo Config("TOKEN_NAME") ?>" value="<?php echo $Page->Token ?>">
<?php } ?>
<input type="hidden" name="t" value="merchantsubscriptioncats">
<input type="hidden" name="action" id="action" value="update">
<input type="hidden" name="modal" value="<?php echo (int)$merchantsubscriptioncats_edit->IsModal ?>">
<div class="ew-edit-div"><!-- page* -->
<?php if ($merchantsubscriptioncats_edit->categoryid->Visible) { // categoryid ?>
	<div id="r_categoryid" class="form-group row">
		<label id="elh_merchantsubscriptioncats_categoryid" class="<?php echo $merchantsubscriptioncats_edit->LeftColumnClass ?>"><?php echo $merchantsubscriptioncats_edit->categoryid->caption() ?><?php echo $merchantsubscriptioncats_edit->categoryid->Required ? $Language->phrase("FieldRequiredIndicator") : "" ?></label>
		<div class="<?php echo $merchantsubscriptioncats_edit->RightColumnClass ?>"><div <?php echo $merchantsubscriptioncats_edit->categoryid->cellAttributes() ?>>
<span id="el_merchantsubscriptioncats_categoryid">
<span<?php echo $merchantsubscriptioncats_edit->categoryid->viewAttributes() ?>><input type="text" readonly class="form-control-plaintext" value="<?php echo HtmlEncode(RemoveHtml($merchantsubscriptioncats_edit->categoryid->EditValue)) ?>"></span>
</span>
<input type="hidden" data-table="merchantsubscriptioncats" data-field="x_categoryid" name="x_categoryid" id="x_categoryid" value="<?php echo HtmlEncode($merchantsubscriptioncats_edit->categoryid->CurrentValue) ?>">
<?php echo $merchantsubscriptioncats_edit->categoryid->CustomMsg ?></div></div>
	</div>
<?php } ?>
<?php if ($merchantsubscriptioncats_edit->merchantid->Visible) { // merchantid ?>
	<div id="r_merchantid" class="form-group row">
		<label id="elh_merchantsubscriptioncats_merchantid" for="x_merchantid" class="<?php echo $merchantsubscriptioncats_edit->LeftColumnClass ?>"><?php echo $merchantsubscriptioncats_edit->merchantid->caption() ?><?php echo $merchantsubscriptioncats_edit->merchantid->Required ? $Language->phrase("FieldRequiredIndicator") : "" ?></label>
		<div class="<?php echo $merchantsubscriptioncats_edit->RightColumnClass ?>"><div <?php echo $merchantsubscriptioncats_edit->merchantid->cellAttributes() ?>>
<span id="el_merchantsubscriptioncats_merchantid">
<input type="text" data-table="merchantsubscriptioncats" data-field="x_merchantid" name="x_merchantid" id="x_merchantid" size="30" placeholder="<?php echo HtmlEncode($merchantsubscriptioncats_edit->merchantid->getPlaceHolder()) ?>" value="<?php echo $merchantsubscriptioncats_edit->merchantid->EditValue ?>"<?php echo $merchantsubscriptioncats_edit->merchantid->editAttributes() ?>>
</span>
<?php echo $merchantsubscriptioncats_edit->merchantid->CustomMsg ?></div></div>
	</div>
<?php } ?>
<?php if ($merchantsubscriptioncats_edit->label->Visible) { // label ?>
	<div id="r_label" class="form-group row">
		<label id="elh_merchantsubscriptioncats_label" for="x_label" class="<?php echo $merchantsubscriptioncats_edit->LeftColumnClass ?>"><?php echo $merchantsubscriptioncats_edit->label->caption() ?><?php echo $merchantsubscriptioncats_edit->label->Required ? $Language->phrase("FieldRequiredIndicator") : "" ?></label>
		<div class="<?php echo $merchantsubscriptioncats_edit->RightColumnClass ?>"><div <?php echo $merchantsubscriptioncats_edit->label->cellAttributes() ?>>
<span id="el_merchantsubscriptioncats_label">
<input type="text" data-table="merchantsubscriptioncats" data-field="x_label" name="x_label" id="x_label" size="30" maxlength="30" placeholder="<?php echo HtmlEncode($merchantsubscriptioncats_edit->label->getPlaceHolder()) ?>" value="<?php echo $merchantsubscriptioncats_edit->label->EditValue ?>"<?php echo $merchantsubscriptioncats_edit->label->editAttributes() ?>>
</span>
<?php echo $merchantsubscriptioncats_edit->label->CustomMsg ?></div></div>
	</div>
<?php } ?>
<?php if ($merchantsubscriptioncats_edit->active->Visible) { // active ?>
	<div id="r_active" class="form-group row">
		<label id="elh_merchantsubscriptioncats_active" for="x_active" class="<?php echo $merchantsubscriptioncats_edit->LeftColumnClass ?>"><?php echo $merchantsubscriptioncats_edit->active->caption() ?><?php echo $merchantsubscriptioncats_edit->active->Required ? $Language->phrase("FieldRequiredIndicator") : "" ?></label>
		<div class="<?php echo $merchantsubscriptioncats_edit->RightColumnClass ?>"><div <?php echo $merchantsubscriptioncats_edit->active->cellAttributes() ?>>
<span id="el_merchantsubscriptioncats_active">
<input type="text" data-table="merchantsubscriptioncats" data-field="x_active" name="x_active" id="x_active" size="30" placeholder="<?php echo HtmlEncode($merchantsubscriptioncats_edit->active->getPlaceHolder()) ?>" value="<?php echo $merchantsubscriptioncats_edit->active->EditValue ?>"<?php echo $merchantsubscriptioncats_edit->active->editAttributes() ?>>
</span>
<?php echo $merchantsubscriptioncats_edit->active->CustomMsg ?></div></div>
	</div>
<?php } ?>
<?php if ($merchantsubscriptioncats_edit->lastupdatedate->Visible) { // lastupdatedate ?>
	<div id="r_lastupdatedate" class="form-group row">
		<label id="elh_merchantsubscriptioncats_lastupdatedate" for="x_lastupdatedate" class="<?php echo $merchantsubscriptioncats_edit->LeftColumnClass ?>"><?php echo $merchantsubscriptioncats_edit->lastupdatedate->caption() ?><?php echo $merchantsubscriptioncats_edit->lastupdatedate->Required ? $Language->phrase("FieldRequiredIndicator") : "" ?></label>
		<div class="<?php echo $merchantsubscriptioncats_edit->RightColumnClass ?>"><div <?php echo $merchantsubscriptioncats_edit->lastupdatedate->cellAttributes() ?>>
<span id="el_merchantsubscriptioncats_lastupdatedate">
<input type="text" data-table="merchantsubscriptioncats" data-field="x_lastupdatedate" name="x_lastupdatedate" id="x_lastupdatedate" placeholder="<?php echo HtmlEncode($merchantsubscriptioncats_edit->lastupdatedate->getPlaceHolder()) ?>" value="<?php echo $merchantsubscriptioncats_edit->lastupdatedate->EditValue ?>"<?php echo $merchantsubscriptioncats_edit->lastupdatedate->editAttributes() ?>>
</span>
<?php echo $merchantsubscriptioncats_edit->lastupdatedate->CustomMsg ?></div></div>
	</div>
<?php } ?>
</div><!-- /page* -->
<?php if (!$merchantsubscriptioncats_edit->IsModal) { ?>
<div class="form-group row"><!-- buttons .form-group -->
	<div class="<?php echo $merchantsubscriptioncats_edit->OffsetColumnClass ?>"><!-- buttons offset -->
<button class="btn btn-primary ew-btn" name="btn-action" id="btn-action" type="submit"><?php echo $Language->phrase("SaveBtn") ?></button>
<button class="btn btn-default ew-btn" name="btn-cancel" id="btn-cancel" type="button" data-href="<?php echo $merchantsubscriptioncats_edit->getReturnUrl() ?>"><?php echo $Language->phrase("CancelBtn") ?></button>
	</div><!-- /buttons offset -->
</div><!-- /buttons .form-group -->
<?php } ?>
</form>
<?php
$merchantsubscriptioncats_edit->showPageFooter();
if (Config("DEBUG"))
	echo GetDebugMessage();
?>
<script>
loadjs.ready("load", function() {

	// Startup script
	// Write your table-specific startup script here
	// console.log("page loaded");

});
</script>
<?php include_once "footer.php"; ?>
<?php
$merchantsubscriptioncats_edit->terminate();
?>