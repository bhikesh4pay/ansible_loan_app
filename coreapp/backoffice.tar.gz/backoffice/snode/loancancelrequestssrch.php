<?php
namespace PHPMaker2020\_4payadmin;

// Autoload
include_once "autoload.php";

// Session
if (session_status() !== PHP_SESSION_ACTIVE)
	\Delight\Cookie\Session::start(Config("COOKIE_SAMESITE")); // Init session data

// Output buffering
ob_start();
?>
<?php

// Write header
WriteHeader(FALSE);

// Create page object
$loancancelrequests_search = new loancancelrequests_search();

// Run the page
$loancancelrequests_search->run();

// Setup login status
SetupLoginStatus();
SetClientVar("login", LoginStatus());

// Global Page Rendering event (in userfn*.php)
Page_Rendering();

// Page Rendering event
$loancancelrequests_search->Page_Render();
?>
<?php include_once "header.php"; ?>
<script>
var floancancelrequestssearch, currentPageID;
loadjs.ready("head", function() {

	// Form object for search
	<?php if ($loancancelrequests_search->IsModal) { ?>
	floancancelrequestssearch = currentAdvancedSearchForm = new ew.Form("floancancelrequestssearch", "search");
	<?php } else { ?>
	floancancelrequestssearch = currentForm = new ew.Form("floancancelrequestssearch", "search");
	<?php } ?>
	currentPageID = ew.PAGE_ID = "search";

	// Validate function for search
	floancancelrequestssearch.validate = function(fobj) {
		if (!this.validateRequired)
			return true; // Ignore validation
		fobj = fobj || this._form;
		var infix = "";
		elm = this.getElements("x" + infix + "_requestid");
		if (elm && !ew.checkInteger(elm.value))
			return this.onError(elm, "<?php echo JsEncode($loancancelrequests_search->requestid->errorMessage()) ?>");
		elm = this.getElements("x" + infix + "__userid");
		if (elm && !ew.checkInteger(elm.value))
			return this.onError(elm, "<?php echo JsEncode($loancancelrequests_search->_userid->errorMessage()) ?>");
		elm = this.getElements("x" + infix + "_requestdate");
		if (elm && !ew.checkDateDef(elm.value))
			return this.onError(elm, "<?php echo JsEncode($loancancelrequests_search->requestdate->errorMessage()) ?>");
		elm = this.getElements("x" + infix + "_requestloanid");
		if (elm && !ew.checkInteger(elm.value))
			return this.onError(elm, "<?php echo JsEncode($loancancelrequests_search->requestloanid->errorMessage()) ?>");
		elm = this.getElements("x" + infix + "_cancelledloanid");
		if (elm && !ew.checkInteger(elm.value))
			return this.onError(elm, "<?php echo JsEncode($loancancelrequests_search->cancelledloanid->errorMessage()) ?>");

		// Call Form_CustomValidate event
		if (!this.Form_CustomValidate(fobj))
			return false;
		return true;
	}

	// Form_CustomValidate
	floancancelrequestssearch.Form_CustomValidate = function(fobj) { // DO NOT CHANGE THIS LINE!

		// Your custom validation code here, return false if invalid.
		return true;
	}

	// Use JavaScript validation or not
	floancancelrequestssearch.validateRequired = <?php echo Config("CLIENT_VALIDATE") ? "true" : "false" ?>;

	// Dynamic selection lists
	floancancelrequestssearch.lists["x_success"] = <?php echo $loancancelrequests_search->success->Lookup->toClientList($loancancelrequests_search) ?>;
	floancancelrequestssearch.lists["x_success"].options = <?php echo JsonEncode($loancancelrequests_search->success->lookupOptions()) ?>;
	loadjs.done("floancancelrequestssearch");
});
</script>
<script>
loadjs.ready("head", function() {

	// Client script
	// Write your client script here, no need to add script tags.

});
</script>
<?php $loancancelrequests_search->showPageHeader(); ?>
<?php
$loancancelrequests_search->showMessage();
?>
<form name="floancancelrequestssearch" id="floancancelrequestssearch" class="<?php echo $loancancelrequests_search->FormClassName ?>" action="<?php echo CurrentPageName() ?>" method="post">
<?php if ($Page->CheckToken) { ?>
<input type="hidden" name="<?php echo Config("TOKEN_NAME") ?>" value="<?php echo $Page->Token ?>">
<?php } ?>
<input type="hidden" name="t" value="loancancelrequests">
<input type="hidden" name="action" id="action" value="search">
<input type="hidden" name="modal" value="<?php echo (int)$loancancelrequests_search->IsModal ?>">
<div class="ew-search-div"><!-- page* -->
<?php if ($loancancelrequests_search->requestid->Visible) { // requestid ?>
	<div id="r_requestid" class="form-group row">
		<label for="x_requestid" class="<?php echo $loancancelrequests_search->LeftColumnClass ?>"><span id="elh_loancancelrequests_requestid"><?php echo $loancancelrequests_search->requestid->caption() ?></span>
		<span class="ew-search-operator">
<?php echo $Language->phrase("=") ?>
<input type="hidden" name="z_requestid" id="z_requestid" value="=">
</span>
		</label>
		<div class="<?php echo $loancancelrequests_search->RightColumnClass ?>"><div <?php echo $loancancelrequests_search->requestid->cellAttributes() ?>>
			<span id="el_loancancelrequests_requestid" class="ew-search-field">
<input type="text" data-table="loancancelrequests" data-field="x_requestid" name="x_requestid" id="x_requestid" maxlength="15" placeholder="<?php echo HtmlEncode($loancancelrequests_search->requestid->getPlaceHolder()) ?>" value="<?php echo $loancancelrequests_search->requestid->EditValue ?>"<?php echo $loancancelrequests_search->requestid->editAttributes() ?>>
</span>
		</div></div>
	</div>
<?php } ?>
<?php if ($loancancelrequests_search->_userid->Visible) { // userid ?>
	<div id="r__userid" class="form-group row">
		<label for="x__userid" class="<?php echo $loancancelrequests_search->LeftColumnClass ?>"><span id="elh_loancancelrequests__userid"><?php echo $loancancelrequests_search->_userid->caption() ?></span>
		<span class="ew-search-operator">
<?php echo $Language->phrase("=") ?>
<input type="hidden" name="z__userid" id="z__userid" value="=">
</span>
		</label>
		<div class="<?php echo $loancancelrequests_search->RightColumnClass ?>"><div <?php echo $loancancelrequests_search->_userid->cellAttributes() ?>>
			<span id="el_loancancelrequests__userid" class="ew-search-field">
<input type="text" data-table="loancancelrequests" data-field="x__userid" name="x__userid" id="x__userid" size="30" maxlength="15" placeholder="<?php echo HtmlEncode($loancancelrequests_search->_userid->getPlaceHolder()) ?>" value="<?php echo $loancancelrequests_search->_userid->EditValue ?>"<?php echo $loancancelrequests_search->_userid->editAttributes() ?>>
</span>
		</div></div>
	</div>
<?php } ?>
<?php if ($loancancelrequests_search->requestdate->Visible) { // requestdate ?>
	<div id="r_requestdate" class="form-group row">
		<label for="x_requestdate" class="<?php echo $loancancelrequests_search->LeftColumnClass ?>"><span id="elh_loancancelrequests_requestdate"><?php echo $loancancelrequests_search->requestdate->caption() ?></span>
		<span class="ew-search-operator">
<?php echo $Language->phrase("=") ?>
<input type="hidden" name="z_requestdate" id="z_requestdate" value="=">
</span>
		</label>
		<div class="<?php echo $loancancelrequests_search->RightColumnClass ?>"><div <?php echo $loancancelrequests_search->requestdate->cellAttributes() ?>>
			<span id="el_loancancelrequests_requestdate" class="ew-search-field">
<input type="text" data-table="loancancelrequests" data-field="x_requestdate" name="x_requestdate" id="x_requestdate" maxlength="19" placeholder="<?php echo HtmlEncode($loancancelrequests_search->requestdate->getPlaceHolder()) ?>" value="<?php echo $loancancelrequests_search->requestdate->EditValue ?>"<?php echo $loancancelrequests_search->requestdate->editAttributes() ?>>
<?php if (!$loancancelrequests_search->requestdate->ReadOnly && !$loancancelrequests_search->requestdate->Disabled && !isset($loancancelrequests_search->requestdate->EditAttrs["readonly"]) && !isset($loancancelrequests_search->requestdate->EditAttrs["disabled"])) { ?>
<script>
loadjs.ready(["floancancelrequestssearch", "datetimepicker"], function() {
	ew.createDateTimePicker("floancancelrequestssearch", "x_requestdate", {"ignoreReadonly":true,"useCurrent":false,"format":0});
});
</script>
<?php } ?>
</span>
		</div></div>
	</div>
<?php } ?>
<?php if ($loancancelrequests_search->requestloanid->Visible) { // requestloanid ?>
	<div id="r_requestloanid" class="form-group row">
		<label for="x_requestloanid" class="<?php echo $loancancelrequests_search->LeftColumnClass ?>"><span id="elh_loancancelrequests_requestloanid"><?php echo $loancancelrequests_search->requestloanid->caption() ?></span>
		<span class="ew-search-operator">
<?php echo $Language->phrase("=") ?>
<input type="hidden" name="z_requestloanid" id="z_requestloanid" value="=">
</span>
		</label>
		<div class="<?php echo $loancancelrequests_search->RightColumnClass ?>"><div <?php echo $loancancelrequests_search->requestloanid->cellAttributes() ?>>
			<span id="el_loancancelrequests_requestloanid" class="ew-search-field">
<input type="text" data-table="loancancelrequests" data-field="x_requestloanid" name="x_requestloanid" id="x_requestloanid" size="30" maxlength="15" placeholder="<?php echo HtmlEncode($loancancelrequests_search->requestloanid->getPlaceHolder()) ?>" value="<?php echo $loancancelrequests_search->requestloanid->EditValue ?>"<?php echo $loancancelrequests_search->requestloanid->editAttributes() ?>>
</span>
		</div></div>
	</div>
<?php } ?>
<?php if ($loancancelrequests_search->cancellationrequestexternalrefno->Visible) { // cancellationrequestexternalrefno ?>
	<div id="r_cancellationrequestexternalrefno" class="form-group row">
		<label for="x_cancellationrequestexternalrefno" class="<?php echo $loancancelrequests_search->LeftColumnClass ?>"><span id="elh_loancancelrequests_cancellationrequestexternalrefno"><?php echo $loancancelrequests_search->cancellationrequestexternalrefno->caption() ?></span>
		<span class="ew-search-operator">
<?php echo $Language->phrase("LIKE") ?>
<input type="hidden" name="z_cancellationrequestexternalrefno" id="z_cancellationrequestexternalrefno" value="LIKE">
</span>
		</label>
		<div class="<?php echo $loancancelrequests_search->RightColumnClass ?>"><div <?php echo $loancancelrequests_search->cancellationrequestexternalrefno->cellAttributes() ?>>
			<span id="el_loancancelrequests_cancellationrequestexternalrefno" class="ew-search-field">
<input type="text" data-table="loancancelrequests" data-field="x_cancellationrequestexternalrefno" name="x_cancellationrequestexternalrefno" id="x_cancellationrequestexternalrefno" size="30" maxlength="50" placeholder="<?php echo HtmlEncode($loancancelrequests_search->cancellationrequestexternalrefno->getPlaceHolder()) ?>" value="<?php echo $loancancelrequests_search->cancellationrequestexternalrefno->EditValue ?>"<?php echo $loancancelrequests_search->cancellationrequestexternalrefno->editAttributes() ?>>
</span>
		</div></div>
	</div>
<?php } ?>
<?php if ($loancancelrequests_search->originalloanrequestexternalrefno->Visible) { // originalloanrequestexternalrefno ?>
	<div id="r_originalloanrequestexternalrefno" class="form-group row">
		<label for="x_originalloanrequestexternalrefno" class="<?php echo $loancancelrequests_search->LeftColumnClass ?>"><span id="elh_loancancelrequests_originalloanrequestexternalrefno"><?php echo $loancancelrequests_search->originalloanrequestexternalrefno->caption() ?></span>
		<span class="ew-search-operator">
<?php echo $Language->phrase("LIKE") ?>
<input type="hidden" name="z_originalloanrequestexternalrefno" id="z_originalloanrequestexternalrefno" value="LIKE">
</span>
		</label>
		<div class="<?php echo $loancancelrequests_search->RightColumnClass ?>"><div <?php echo $loancancelrequests_search->originalloanrequestexternalrefno->cellAttributes() ?>>
			<span id="el_loancancelrequests_originalloanrequestexternalrefno" class="ew-search-field">
<input type="text" data-table="loancancelrequests" data-field="x_originalloanrequestexternalrefno" name="x_originalloanrequestexternalrefno" id="x_originalloanrequestexternalrefno" size="30" maxlength="50" placeholder="<?php echo HtmlEncode($loancancelrequests_search->originalloanrequestexternalrefno->getPlaceHolder()) ?>" value="<?php echo $loancancelrequests_search->originalloanrequestexternalrefno->EditValue ?>"<?php echo $loancancelrequests_search->originalloanrequestexternalrefno->editAttributes() ?>>
</span>
		</div></div>
	</div>
<?php } ?>
<?php if ($loancancelrequests_search->cancellationreason->Visible) { // cancellationreason ?>
	<div id="r_cancellationreason" class="form-group row">
		<label for="x_cancellationreason" class="<?php echo $loancancelrequests_search->LeftColumnClass ?>"><span id="elh_loancancelrequests_cancellationreason"><?php echo $loancancelrequests_search->cancellationreason->caption() ?></span>
		<span class="ew-search-operator">
<?php echo $Language->phrase("LIKE") ?>
<input type="hidden" name="z_cancellationreason" id="z_cancellationreason" value="LIKE">
</span>
		</label>
		<div class="<?php echo $loancancelrequests_search->RightColumnClass ?>"><div <?php echo $loancancelrequests_search->cancellationreason->cellAttributes() ?>>
			<span id="el_loancancelrequests_cancellationreason" class="ew-search-field">
<input type="text" data-table="loancancelrequests" data-field="x_cancellationreason" name="x_cancellationreason" id="x_cancellationreason" size="300" maxlength="300" placeholder="<?php echo HtmlEncode($loancancelrequests_search->cancellationreason->getPlaceHolder()) ?>" value="<?php echo $loancancelrequests_search->cancellationreason->EditValue ?>"<?php echo $loancancelrequests_search->cancellationreason->editAttributes() ?>>
</span>
		</div></div>
	</div>
<?php } ?>
<?php if ($loancancelrequests_search->cancelledloanid->Visible) { // cancelledloanid ?>
	<div id="r_cancelledloanid" class="form-group row">
		<label for="x_cancelledloanid" class="<?php echo $loancancelrequests_search->LeftColumnClass ?>"><span id="elh_loancancelrequests_cancelledloanid"><?php echo $loancancelrequests_search->cancelledloanid->caption() ?></span>
		<span class="ew-search-operator">
<?php echo $Language->phrase("=") ?>
<input type="hidden" name="z_cancelledloanid" id="z_cancelledloanid" value="=">
</span>
		</label>
		<div class="<?php echo $loancancelrequests_search->RightColumnClass ?>"><div <?php echo $loancancelrequests_search->cancelledloanid->cellAttributes() ?>>
			<span id="el_loancancelrequests_cancelledloanid" class="ew-search-field">
<input type="text" data-table="loancancelrequests" data-field="x_cancelledloanid" name="x_cancelledloanid" id="x_cancelledloanid" size="30" maxlength="15" placeholder="<?php echo HtmlEncode($loancancelrequests_search->cancelledloanid->getPlaceHolder()) ?>" value="<?php echo $loancancelrequests_search->cancelledloanid->EditValue ?>"<?php echo $loancancelrequests_search->cancelledloanid->editAttributes() ?>>
</span>
		</div></div>
	</div>
<?php } ?>
<?php if ($loancancelrequests_search->success->Visible) { // success ?>
	<div id="r_success" class="form-group row">
		<label class="<?php echo $loancancelrequests_search->LeftColumnClass ?>"><span id="elh_loancancelrequests_success"><?php echo $loancancelrequests_search->success->caption() ?></span>
		<span class="ew-search-operator">
<?php echo $Language->phrase("=") ?>
<input type="hidden" name="z_success" id="z_success" value="=">
</span>
		</label>
		<div class="<?php echo $loancancelrequests_search->RightColumnClass ?>"><div <?php echo $loancancelrequests_search->success->cellAttributes() ?>>
			<span id="el_loancancelrequests_success" class="ew-search-field">
<div id="tp_x_success" class="ew-template"><input type="radio" class="custom-control-input" data-table="loancancelrequests" data-field="x_success" data-value-separator="<?php echo $loancancelrequests_search->success->displayValueSeparatorAttribute() ?>" name="x_success" id="x_success" value="{value}"<?php echo $loancancelrequests_search->success->editAttributes() ?>></div>
<div id="dsl_x_success" data-repeatcolumn="5" class="ew-item-list d-none"><div>
<?php echo $loancancelrequests_search->success->radioButtonListHtml(FALSE, "x_success") ?>
</div></div>
<?php echo $loancancelrequests_search->success->Lookup->getParamTag($loancancelrequests_search, "p_x_success") ?>
</span>
		</div></div>
	</div>
<?php } ?>
</div><!-- /page* -->
<?php if (!$loancancelrequests_search->IsModal) { ?>
<div class="form-group row"><!-- buttons .form-group -->
	<div class="<?php echo $loancancelrequests_search->OffsetColumnClass ?>"><!-- buttons offset -->
<button class="btn btn-primary ew-btn" name="btn-action" id="btn-action" type="submit"><?php echo $Language->phrase("Search") ?></button>
<button class="btn btn-default ew-btn" name="btn-reset" id="btn-reset" type="button" onclick="ew.clearForm(this.form);"><?php echo $Language->phrase("Reset") ?></button>
	</div><!-- /buttons offset -->
</div><!-- /buttons .form-group -->
<?php } ?>
</form>
<?php
$loancancelrequests_search->showPageFooter();
if (Config("DEBUG"))
	echo GetDebugMessage();
?>
<script>
loadjs.ready("load", function() {

	// Startup script
	// Write your table-specific startup script here
	// console.log("page loaded");

});
</script>
<?php include_once "footer.php"; ?>
<?php
$loancancelrequests_search->terminate();
?>