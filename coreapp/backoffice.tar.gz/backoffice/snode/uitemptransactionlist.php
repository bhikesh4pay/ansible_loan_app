<?php
namespace PHPMaker2020\_4payadmin;

// Autoload
include_once "autoload.php";

// Session
if (session_status() !== PHP_SESSION_ACTIVE)
	\Delight\Cookie\Session::start(Config("COOKIE_SAMESITE")); // Init session data

// Output buffering
ob_start();
?>
<?php

// Write header
WriteHeader(FALSE);

// Create page object
$uitemptransaction_list = new uitemptransaction_list();

// Run the page
$uitemptransaction_list->run();

// Setup login status
SetupLoginStatus();
SetClientVar("login", LoginStatus());

// Global Page Rendering event (in userfn*.php)
Page_Rendering();

// Page Rendering event
$uitemptransaction_list->Page_Render();
?>
<?php include_once "header.php"; ?>
<?php if (!$uitemptransaction_list->isExport()) { ?>
<script>
var fuitemptransactionlist, currentPageID;
loadjs.ready("head", function() {

	// Form object
	currentPageID = ew.PAGE_ID = "list";
	fuitemptransactionlist = currentForm = new ew.Form("fuitemptransactionlist", "list");
	fuitemptransactionlist.formKeyCountName = '<?php echo $uitemptransaction_list->FormKeyCountName ?>';
	loadjs.done("fuitemptransactionlist");
});
var fuitemptransactionlistsrch;
loadjs.ready("head", function() {

	// Form object for search
	fuitemptransactionlistsrch = currentSearchForm = new ew.Form("fuitemptransactionlistsrch");

	// Dynamic selection lists
	// Filters

	fuitemptransactionlistsrch.filterList = <?php echo $uitemptransaction_list->getFilterList() ?>;

	// Init search panel as collapsed
	fuitemptransactionlistsrch.initSearchPanel = true;
	loadjs.done("fuitemptransactionlistsrch");
});
</script>
<style type="text/css">
.ew-table-preview-row { /* main table preview row color */
	background-color: #FFFFFF; /* preview row color */
}
.ew-table-preview-row .ew-grid {
	display: table;
}
</style>
<div id="ew-preview" class="d-none"><!-- preview -->
	<div class="ew-nav-tabs"><!-- .ew-nav-tabs -->
		<ul class="nav nav-tabs"></ul>
		<div class="tab-content"><!-- .tab-content -->
			<div class="tab-pane fade active show"></div>
		</div><!-- /.tab-content -->
	</div><!-- /.ew-nav-tabs -->
</div><!-- /preview -->
<script>
loadjs.ready("head", function() {
	ew.PREVIEW_PLACEMENT = ew.CSS_FLIP ? "right" : "left";
	ew.PREVIEW_SINGLE_ROW = false;
	ew.PREVIEW_OVERLAY = false;
	loadjs("js/ewpreview.js", "preview");
});
</script>
<script>
loadjs.ready("head", function() {

	// Client script
	// Write your client script here, no need to add script tags.

});
</script>
<?php } ?>
<?php if (!$uitemptransaction_list->isExport()) { ?>
<div class="btn-toolbar ew-toolbar">
<?php if ($uitemptransaction_list->TotalRecords > 0 && $uitemptransaction_list->ExportOptions->visible()) { ?>
<?php $uitemptransaction_list->ExportOptions->render("body") ?>
<?php } ?>
<?php if ($uitemptransaction_list->ImportOptions->visible()) { ?>
<?php $uitemptransaction_list->ImportOptions->render("body") ?>
<?php } ?>
<?php if ($uitemptransaction_list->SearchOptions->visible()) { ?>
<?php $uitemptransaction_list->SearchOptions->render("body") ?>
<?php } ?>
<?php if ($uitemptransaction_list->FilterOptions->visible()) { ?>
<?php $uitemptransaction_list->FilterOptions->render("body") ?>
<?php } ?>
<div class="clearfix"></div>
</div>
<?php } ?>
<?php
$uitemptransaction_list->renderOtherOptions();
?>
<?php if ($Security->CanSearch()) { ?>
<?php if (!$uitemptransaction_list->isExport() && !$uitemptransaction->CurrentAction) { ?>
<form name="fuitemptransactionlistsrch" id="fuitemptransactionlistsrch" class="form-inline ew-form ew-ext-search-form" action="<?php echo CurrentPageName() ?>">
<div id="fuitemptransactionlistsrch-search-panel" class="<?php echo $uitemptransaction_list->SearchPanelClass ?>">
<input type="hidden" name="cmd" value="search">
<input type="hidden" name="t" value="uitemptransaction">
	<div class="ew-extended-search">
<div id="xsr_<?php echo $uitemptransaction_list->SearchRowCount + 1 ?>" class="ew-row d-sm-flex">
	<div class="ew-quick-search input-group">
		<input type="text" name="<?php echo Config("TABLE_BASIC_SEARCH") ?>" id="<?php echo Config("TABLE_BASIC_SEARCH") ?>" class="form-control" value="<?php echo HtmlEncode($uitemptransaction_list->BasicSearch->getKeyword()) ?>" placeholder="<?php echo HtmlEncode($Language->phrase("Search")) ?>">
		<input type="hidden" name="<?php echo Config("TABLE_BASIC_SEARCH_TYPE") ?>" id="<?php echo Config("TABLE_BASIC_SEARCH_TYPE") ?>" value="<?php echo HtmlEncode($uitemptransaction_list->BasicSearch->getType()) ?>">
		<div class="input-group-append">
			<button class="btn btn-primary" name="btn-submit" id="btn-submit" type="submit"><?php echo $Language->phrase("SearchBtn") ?></button>
			<button type="button" data-toggle="dropdown" class="btn btn-primary dropdown-toggle dropdown-toggle-split" aria-haspopup="true" aria-expanded="false"><span id="searchtype"><?php echo $uitemptransaction_list->BasicSearch->getTypeNameShort() ?></span></button>
			<div class="dropdown-menu dropdown-menu-right">
				<a class="dropdown-item<?php if ($uitemptransaction_list->BasicSearch->getType() == "") { ?> active<?php } ?>" href="#" onclick="return ew.setSearchType(this);"><?php echo $Language->phrase("QuickSearchAuto") ?></a>
				<a class="dropdown-item<?php if ($uitemptransaction_list->BasicSearch->getType() == "=") { ?> active<?php } ?>" href="#" onclick="return ew.setSearchType(this, '=');"><?php echo $Language->phrase("QuickSearchExact") ?></a>
				<a class="dropdown-item<?php if ($uitemptransaction_list->BasicSearch->getType() == "AND") { ?> active<?php } ?>" href="#" onclick="return ew.setSearchType(this, 'AND');"><?php echo $Language->phrase("QuickSearchAll") ?></a>
				<a class="dropdown-item<?php if ($uitemptransaction_list->BasicSearch->getType() == "OR") { ?> active<?php } ?>" href="#" onclick="return ew.setSearchType(this, 'OR');"><?php echo $Language->phrase("QuickSearchAny") ?></a>
			</div>
		</div>
	</div>
</div>
	</div><!-- /.ew-extended-search -->
</div><!-- /.ew-search-panel -->
</form>
<?php } ?>
<?php } ?>
<?php $uitemptransaction_list->showPageHeader(); ?>
<?php
$uitemptransaction_list->showMessage();
?>
<?php if ($uitemptransaction_list->TotalRecords > 0 || $uitemptransaction->CurrentAction) { ?>
<div class="card ew-card ew-grid<?php if ($uitemptransaction_list->isAddOrEdit()) { ?> ew-grid-add-edit<?php } ?> uitemptransaction">
<form name="fuitemptransactionlist" id="fuitemptransactionlist" class="form-inline ew-form ew-list-form" action="<?php echo CurrentPageName() ?>" method="post">
<?php if ($Page->CheckToken) { ?>
<input type="hidden" name="<?php echo Config("TOKEN_NAME") ?>" value="<?php echo $Page->Token ?>">
<?php } ?>
<input type="hidden" name="t" value="uitemptransaction">
<div id="gmp_uitemptransaction" class="<?php echo ResponsiveTableClass() ?>card-body ew-grid-middle-panel">
<?php if ($uitemptransaction_list->TotalRecords > 0 || $uitemptransaction_list->isGridEdit()) { ?>
<table id="tbl_uitemptransactionlist" class="table ew-table"><!-- .ew-table -->
<thead>
	<tr class="ew-table-header">
<?php

// Header row
$uitemptransaction->RowType = ROWTYPE_HEADER;

// Render list options
$uitemptransaction_list->renderListOptions();

// Render list options (header, left)
$uitemptransaction_list->ListOptions->render("header", "left");
?>
<?php if ($uitemptransaction_list->recid->Visible) { // recid ?>
	<?php if ($uitemptransaction_list->SortUrl($uitemptransaction_list->recid) == "") { ?>
		<th data-name="recid" class="<?php echo $uitemptransaction_list->recid->headerCellClass() ?>"><div id="elh_uitemptransaction_recid" class="uitemptransaction_recid"><div class="ew-table-header-caption"><?php echo $uitemptransaction_list->recid->caption() ?></div></div></th>
	<?php } else { ?>
		<th data-name="recid" class="<?php echo $uitemptransaction_list->recid->headerCellClass() ?>"><div class="ew-pointer" onclick="ew.sort(event, '<?php echo $uitemptransaction_list->SortUrl($uitemptransaction_list->recid) ?>', 1);"><div id="elh_uitemptransaction_recid" class="uitemptransaction_recid">
			<div class="ew-table-header-btn"><span class="ew-table-header-caption"><?php echo $uitemptransaction_list->recid->caption() ?></span><span class="ew-table-header-sort"><?php if ($uitemptransaction_list->recid->getSort() == "ASC") { ?><i class="fas fa-sort-up"></i><?php } elseif ($uitemptransaction_list->recid->getSort() == "DESC") { ?><i class="fas fa-sort-down"></i><?php } ?></span></div>
		</div></div></th>
	<?php } ?>
<?php } ?>
<?php if ($uitemptransaction_list->_userid->Visible) { // userid ?>
	<?php if ($uitemptransaction_list->SortUrl($uitemptransaction_list->_userid) == "") { ?>
		<th data-name="_userid" class="<?php echo $uitemptransaction_list->_userid->headerCellClass() ?>"><div id="elh_uitemptransaction__userid" class="uitemptransaction__userid"><div class="ew-table-header-caption"><?php echo $uitemptransaction_list->_userid->caption() ?></div></div></th>
	<?php } else { ?>
		<th data-name="_userid" class="<?php echo $uitemptransaction_list->_userid->headerCellClass() ?>"><div class="ew-pointer" onclick="ew.sort(event, '<?php echo $uitemptransaction_list->SortUrl($uitemptransaction_list->_userid) ?>', 1);"><div id="elh_uitemptransaction__userid" class="uitemptransaction__userid">
			<div class="ew-table-header-btn"><span class="ew-table-header-caption"><?php echo $uitemptransaction_list->_userid->caption() ?></span><span class="ew-table-header-sort"><?php if ($uitemptransaction_list->_userid->getSort() == "ASC") { ?><i class="fas fa-sort-up"></i><?php } elseif ($uitemptransaction_list->_userid->getSort() == "DESC") { ?><i class="fas fa-sort-down"></i><?php } ?></span></div>
		</div></div></th>
	<?php } ?>
<?php } ?>
<?php if ($uitemptransaction_list->refdata->Visible) { // refdata ?>
	<?php if ($uitemptransaction_list->SortUrl($uitemptransaction_list->refdata) == "") { ?>
		<th data-name="refdata" class="<?php echo $uitemptransaction_list->refdata->headerCellClass() ?>"><div id="elh_uitemptransaction_refdata" class="uitemptransaction_refdata"><div class="ew-table-header-caption"><?php echo $uitemptransaction_list->refdata->caption() ?></div></div></th>
	<?php } else { ?>
		<th data-name="refdata" class="<?php echo $uitemptransaction_list->refdata->headerCellClass() ?>"><div class="ew-pointer" onclick="ew.sort(event, '<?php echo $uitemptransaction_list->SortUrl($uitemptransaction_list->refdata) ?>', 1);"><div id="elh_uitemptransaction_refdata" class="uitemptransaction_refdata">
			<div class="ew-table-header-btn"><span class="ew-table-header-caption"><?php echo $uitemptransaction_list->refdata->caption() ?><?php echo $Language->phrase("SrchLegend") ?></span><span class="ew-table-header-sort"><?php if ($uitemptransaction_list->refdata->getSort() == "ASC") { ?><i class="fas fa-sort-up"></i><?php } elseif ($uitemptransaction_list->refdata->getSort() == "DESC") { ?><i class="fas fa-sort-down"></i><?php } ?></span></div>
		</div></div></th>
	<?php } ?>
<?php } ?>
<?php if ($uitemptransaction_list->creationtime->Visible) { // creationtime ?>
	<?php if ($uitemptransaction_list->SortUrl($uitemptransaction_list->creationtime) == "") { ?>
		<th data-name="creationtime" class="<?php echo $uitemptransaction_list->creationtime->headerCellClass() ?>"><div id="elh_uitemptransaction_creationtime" class="uitemptransaction_creationtime"><div class="ew-table-header-caption"><?php echo $uitemptransaction_list->creationtime->caption() ?></div></div></th>
	<?php } else { ?>
		<th data-name="creationtime" class="<?php echo $uitemptransaction_list->creationtime->headerCellClass() ?>"><div class="ew-pointer" onclick="ew.sort(event, '<?php echo $uitemptransaction_list->SortUrl($uitemptransaction_list->creationtime) ?>', 1);"><div id="elh_uitemptransaction_creationtime" class="uitemptransaction_creationtime">
			<div class="ew-table-header-btn"><span class="ew-table-header-caption"><?php echo $uitemptransaction_list->creationtime->caption() ?></span><span class="ew-table-header-sort"><?php if ($uitemptransaction_list->creationtime->getSort() == "ASC") { ?><i class="fas fa-sort-up"></i><?php } elseif ($uitemptransaction_list->creationtime->getSort() == "DESC") { ?><i class="fas fa-sort-down"></i><?php } ?></span></div>
		</div></div></th>
	<?php } ?>
<?php } ?>
<?php if ($uitemptransaction_list->expirytime->Visible) { // expirytime ?>
	<?php if ($uitemptransaction_list->SortUrl($uitemptransaction_list->expirytime) == "") { ?>
		<th data-name="expirytime" class="<?php echo $uitemptransaction_list->expirytime->headerCellClass() ?>"><div id="elh_uitemptransaction_expirytime" class="uitemptransaction_expirytime"><div class="ew-table-header-caption"><?php echo $uitemptransaction_list->expirytime->caption() ?></div></div></th>
	<?php } else { ?>
		<th data-name="expirytime" class="<?php echo $uitemptransaction_list->expirytime->headerCellClass() ?>"><div class="ew-pointer" onclick="ew.sort(event, '<?php echo $uitemptransaction_list->SortUrl($uitemptransaction_list->expirytime) ?>', 1);"><div id="elh_uitemptransaction_expirytime" class="uitemptransaction_expirytime">
			<div class="ew-table-header-btn"><span class="ew-table-header-caption"><?php echo $uitemptransaction_list->expirytime->caption() ?></span><span class="ew-table-header-sort"><?php if ($uitemptransaction_list->expirytime->getSort() == "ASC") { ?><i class="fas fa-sort-up"></i><?php } elseif ($uitemptransaction_list->expirytime->getSort() == "DESC") { ?><i class="fas fa-sort-down"></i><?php } ?></span></div>
		</div></div></th>
	<?php } ?>
<?php } ?>
<?php

// Render list options (header, right)
$uitemptransaction_list->ListOptions->render("header", "right");
?>
	</tr>
</thead>
<tbody>
<?php
if ($uitemptransaction_list->ExportAll && $uitemptransaction_list->isExport()) {
	$uitemptransaction_list->StopRecord = $uitemptransaction_list->TotalRecords;
} else {

	// Set the last record to display
	if ($uitemptransaction_list->TotalRecords > $uitemptransaction_list->StartRecord + $uitemptransaction_list->DisplayRecords - 1)
		$uitemptransaction_list->StopRecord = $uitemptransaction_list->StartRecord + $uitemptransaction_list->DisplayRecords - 1;
	else
		$uitemptransaction_list->StopRecord = $uitemptransaction_list->TotalRecords;
}
$uitemptransaction_list->RecordCount = $uitemptransaction_list->StartRecord - 1;
if ($uitemptransaction_list->Recordset && !$uitemptransaction_list->Recordset->EOF) {
	$uitemptransaction_list->Recordset->moveFirst();
	$selectLimit = $uitemptransaction_list->UseSelectLimit;
	if (!$selectLimit && $uitemptransaction_list->StartRecord > 1)
		$uitemptransaction_list->Recordset->move($uitemptransaction_list->StartRecord - 1);
} elseif (!$uitemptransaction->AllowAddDeleteRow && $uitemptransaction_list->StopRecord == 0) {
	$uitemptransaction_list->StopRecord = $uitemptransaction->GridAddRowCount;
}

// Initialize aggregate
$uitemptransaction->RowType = ROWTYPE_AGGREGATEINIT;
$uitemptransaction->resetAttributes();
$uitemptransaction_list->renderRow();
while ($uitemptransaction_list->RecordCount < $uitemptransaction_list->StopRecord) {
	$uitemptransaction_list->RecordCount++;
	if ($uitemptransaction_list->RecordCount >= $uitemptransaction_list->StartRecord) {
		$uitemptransaction_list->RowCount++;

		// Set up key count
		$uitemptransaction_list->KeyCount = $uitemptransaction_list->RowIndex;

		// Init row class and style
		$uitemptransaction->resetAttributes();
		$uitemptransaction->CssClass = "";
		if ($uitemptransaction_list->isGridAdd()) {
		} else {
			$uitemptransaction_list->loadRowValues($uitemptransaction_list->Recordset); // Load row values
		}
		$uitemptransaction->RowType = ROWTYPE_VIEW; // Render view

		// Set up row id / data-rowindex
		$uitemptransaction->RowAttrs->merge(["data-rowindex" => $uitemptransaction_list->RowCount, "id" => "r" . $uitemptransaction_list->RowCount . "_uitemptransaction", "data-rowtype" => $uitemptransaction->RowType]);

		// Render row
		$uitemptransaction_list->renderRow();

		// Render list options
		$uitemptransaction_list->renderListOptions();
?>
	<tr <?php echo $uitemptransaction->rowAttributes() ?>>
<?php

// Render list options (body, left)
$uitemptransaction_list->ListOptions->render("body", "left", $uitemptransaction_list->RowCount);
?>
	<?php if ($uitemptransaction_list->recid->Visible) { // recid ?>
		<td data-name="recid" <?php echo $uitemptransaction_list->recid->cellAttributes() ?>>
<span id="el<?php echo $uitemptransaction_list->RowCount ?>_uitemptransaction_recid">
<span<?php echo $uitemptransaction_list->recid->viewAttributes() ?>><?php echo $uitemptransaction_list->recid->getViewValue() ?></span>
</span>
</td>
	<?php } ?>
	<?php if ($uitemptransaction_list->_userid->Visible) { // userid ?>
		<td data-name="_userid" <?php echo $uitemptransaction_list->_userid->cellAttributes() ?>>
<span id="el<?php echo $uitemptransaction_list->RowCount ?>_uitemptransaction__userid">
<span<?php echo $uitemptransaction_list->_userid->viewAttributes() ?>><?php echo $uitemptransaction_list->_userid->getViewValue() ?></span>
</span>
</td>
	<?php } ?>
	<?php if ($uitemptransaction_list->refdata->Visible) { // refdata ?>
		<td data-name="refdata" <?php echo $uitemptransaction_list->refdata->cellAttributes() ?>>
<span id="el<?php echo $uitemptransaction_list->RowCount ?>_uitemptransaction_refdata">
<span<?php echo $uitemptransaction_list->refdata->viewAttributes() ?>><?php echo $uitemptransaction_list->refdata->getViewValue() ?></span>
</span>
</td>
	<?php } ?>
	<?php if ($uitemptransaction_list->creationtime->Visible) { // creationtime ?>
		<td data-name="creationtime" <?php echo $uitemptransaction_list->creationtime->cellAttributes() ?>>
<span id="el<?php echo $uitemptransaction_list->RowCount ?>_uitemptransaction_creationtime">
<span<?php echo $uitemptransaction_list->creationtime->viewAttributes() ?>><?php echo $uitemptransaction_list->creationtime->getViewValue() ?></span>
</span>
</td>
	<?php } ?>
	<?php if ($uitemptransaction_list->expirytime->Visible) { // expirytime ?>
		<td data-name="expirytime" <?php echo $uitemptransaction_list->expirytime->cellAttributes() ?>>
<span id="el<?php echo $uitemptransaction_list->RowCount ?>_uitemptransaction_expirytime">
<span<?php echo $uitemptransaction_list->expirytime->viewAttributes() ?>><?php echo $uitemptransaction_list->expirytime->getViewValue() ?></span>
</span>
</td>
	<?php } ?>
<?php

// Render list options (body, right)
$uitemptransaction_list->ListOptions->render("body", "right", $uitemptransaction_list->RowCount);
?>
	</tr>
<?php
	}
	if (!$uitemptransaction_list->isGridAdd())
		$uitemptransaction_list->Recordset->moveNext();
}
?>
</tbody>
</table><!-- /.ew-table -->
<?php } ?>
</div><!-- /.ew-grid-middle-panel -->
<?php if (!$uitemptransaction->CurrentAction) { ?>
<input type="hidden" name="action" id="action" value="">
<?php } ?>
</form><!-- /.ew-list-form -->
<?php

// Close recordset
if ($uitemptransaction_list->Recordset)
	$uitemptransaction_list->Recordset->Close();
?>
<?php if (!$uitemptransaction_list->isExport()) { ?>
<div class="card-footer ew-grid-lower-panel">
<?php if (!$uitemptransaction_list->isGridAdd()) { ?>
<form name="ew-pager-form" class="form-inline ew-form ew-pager-form" action="<?php echo CurrentPageName() ?>">
<?php echo $uitemptransaction_list->Pager->render() ?>
</form>
<?php } ?>
<div class="ew-list-other-options">
<?php $uitemptransaction_list->OtherOptions->render("body", "bottom") ?>
</div>
<div class="clearfix"></div>
</div>
<?php } ?>
</div><!-- /.ew-grid -->
<?php } ?>
<?php if ($uitemptransaction_list->TotalRecords == 0 && !$uitemptransaction->CurrentAction) { // Show other options ?>
<div class="ew-list-other-options">
<?php $uitemptransaction_list->OtherOptions->render("body") ?>
</div>
<div class="clearfix"></div>
<?php } ?>
<?php
$uitemptransaction_list->showPageFooter();
if (Config("DEBUG"))
	echo GetDebugMessage();
?>
<?php if (!$uitemptransaction_list->isExport()) { ?>
<script>
loadjs.ready("load", function() {

	// Startup script
	// Write your table-specific startup script here
	// console.log("page loaded");

});
</script>
<?php } ?>
<?php include_once "footer.php"; ?>
<?php
$uitemptransaction_list->terminate();
?>