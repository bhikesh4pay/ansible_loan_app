<?php
namespace PHPMaker2020\_4payadmin;

// Autoload
include_once "autoload.php";

// Session
if (session_status() !== PHP_SESSION_ACTIVE)
	\Delight\Cookie\Session::start(Config("COOKIE_SAMESITE")); // Init session data

// Output buffering
ob_start();
?>
<?php

// Write header
WriteHeader(FALSE);

// Create page object
$userexternaldeposits_list = new userexternaldeposits_list();

// Run the page
$userexternaldeposits_list->run();

// Setup login status
SetupLoginStatus();
SetClientVar("login", LoginStatus());

// Global Page Rendering event (in userfn*.php)
Page_Rendering();

// Page Rendering event
$userexternaldeposits_list->Page_Render();
?>
<?php include_once "header.php"; ?>
<?php if (!$userexternaldeposits_list->isExport()) { ?>
<script>
var fuserexternaldepositslist, currentPageID;
loadjs.ready("head", function() {

	// Form object
	currentPageID = ew.PAGE_ID = "list";
	fuserexternaldepositslist = currentForm = new ew.Form("fuserexternaldepositslist", "list");
	fuserexternaldepositslist.formKeyCountName = '<?php echo $userexternaldeposits_list->FormKeyCountName ?>';
	loadjs.done("fuserexternaldepositslist");
});
var fuserexternaldepositslistsrch;
loadjs.ready("head", function() {

	// Form object for search
	fuserexternaldepositslistsrch = currentSearchForm = new ew.Form("fuserexternaldepositslistsrch");

	// Dynamic selection lists
	// Filters

	fuserexternaldepositslistsrch.filterList = <?php echo $userexternaldeposits_list->getFilterList() ?>;

	// Init search panel as collapsed
	fuserexternaldepositslistsrch.initSearchPanel = true;
	loadjs.done("fuserexternaldepositslistsrch");
});
</script>
<style type="text/css">
.ew-table-preview-row { /* main table preview row color */
	background-color: #FFFFFF; /* preview row color */
}
.ew-table-preview-row .ew-grid {
	display: table;
}
</style>
<div id="ew-preview" class="d-none"><!-- preview -->
	<div class="ew-nav-tabs"><!-- .ew-nav-tabs -->
		<ul class="nav nav-tabs"></ul>
		<div class="tab-content"><!-- .tab-content -->
			<div class="tab-pane fade active show"></div>
		</div><!-- /.tab-content -->
	</div><!-- /.ew-nav-tabs -->
</div><!-- /preview -->
<script>
loadjs.ready("head", function() {
	ew.PREVIEW_PLACEMENT = ew.CSS_FLIP ? "right" : "left";
	ew.PREVIEW_SINGLE_ROW = false;
	ew.PREVIEW_OVERLAY = false;
	loadjs("js/ewpreview.js", "preview");
});
</script>
<script>
loadjs.ready("head", function() {

	// Client script
	// Write your client script here, no need to add script tags.

});
</script>
<?php } ?>
<?php if (!$userexternaldeposits_list->isExport()) { ?>
<div class="btn-toolbar ew-toolbar">
<?php if ($userexternaldeposits_list->TotalRecords > 0 && $userexternaldeposits_list->ExportOptions->visible()) { ?>
<?php $userexternaldeposits_list->ExportOptions->render("body") ?>
<?php } ?>
<?php if ($userexternaldeposits_list->ImportOptions->visible()) { ?>
<?php $userexternaldeposits_list->ImportOptions->render("body") ?>
<?php } ?>
<?php if ($userexternaldeposits_list->SearchOptions->visible()) { ?>
<?php $userexternaldeposits_list->SearchOptions->render("body") ?>
<?php } ?>
<?php if ($userexternaldeposits_list->FilterOptions->visible()) { ?>
<?php $userexternaldeposits_list->FilterOptions->render("body") ?>
<?php } ?>
<div class="clearfix"></div>
</div>
<?php } ?>
<?php
$userexternaldeposits_list->renderOtherOptions();
?>
<?php if ($Security->CanSearch()) { ?>
<?php if (!$userexternaldeposits_list->isExport() && !$userexternaldeposits->CurrentAction) { ?>
<form name="fuserexternaldepositslistsrch" id="fuserexternaldepositslistsrch" class="form-inline ew-form ew-ext-search-form" action="<?php echo CurrentPageName() ?>">
<div id="fuserexternaldepositslistsrch-search-panel" class="<?php echo $userexternaldeposits_list->SearchPanelClass ?>">
<input type="hidden" name="cmd" value="search">
<input type="hidden" name="t" value="userexternaldeposits">
	<div class="ew-extended-search">
<div id="xsr_<?php echo $userexternaldeposits_list->SearchRowCount + 1 ?>" class="ew-row d-sm-flex">
	<div class="ew-quick-search input-group">
		<input type="text" name="<?php echo Config("TABLE_BASIC_SEARCH") ?>" id="<?php echo Config("TABLE_BASIC_SEARCH") ?>" class="form-control" value="<?php echo HtmlEncode($userexternaldeposits_list->BasicSearch->getKeyword()) ?>" placeholder="<?php echo HtmlEncode($Language->phrase("Search")) ?>">
		<input type="hidden" name="<?php echo Config("TABLE_BASIC_SEARCH_TYPE") ?>" id="<?php echo Config("TABLE_BASIC_SEARCH_TYPE") ?>" value="<?php echo HtmlEncode($userexternaldeposits_list->BasicSearch->getType()) ?>">
		<div class="input-group-append">
			<button class="btn btn-primary" name="btn-submit" id="btn-submit" type="submit"><?php echo $Language->phrase("SearchBtn") ?></button>
			<button type="button" data-toggle="dropdown" class="btn btn-primary dropdown-toggle dropdown-toggle-split" aria-haspopup="true" aria-expanded="false"><span id="searchtype"><?php echo $userexternaldeposits_list->BasicSearch->getTypeNameShort() ?></span></button>
			<div class="dropdown-menu dropdown-menu-right">
				<a class="dropdown-item<?php if ($userexternaldeposits_list->BasicSearch->getType() == "") { ?> active<?php } ?>" href="#" onclick="return ew.setSearchType(this);"><?php echo $Language->phrase("QuickSearchAuto") ?></a>
				<a class="dropdown-item<?php if ($userexternaldeposits_list->BasicSearch->getType() == "=") { ?> active<?php } ?>" href="#" onclick="return ew.setSearchType(this, '=');"><?php echo $Language->phrase("QuickSearchExact") ?></a>
				<a class="dropdown-item<?php if ($userexternaldeposits_list->BasicSearch->getType() == "AND") { ?> active<?php } ?>" href="#" onclick="return ew.setSearchType(this, 'AND');"><?php echo $Language->phrase("QuickSearchAll") ?></a>
				<a class="dropdown-item<?php if ($userexternaldeposits_list->BasicSearch->getType() == "OR") { ?> active<?php } ?>" href="#" onclick="return ew.setSearchType(this, 'OR');"><?php echo $Language->phrase("QuickSearchAny") ?></a>
			</div>
		</div>
	</div>
</div>
	</div><!-- /.ew-extended-search -->
</div><!-- /.ew-search-panel -->
</form>
<?php } ?>
<?php } ?>
<?php $userexternaldeposits_list->showPageHeader(); ?>
<?php
$userexternaldeposits_list->showMessage();
?>
<?php if ($userexternaldeposits_list->TotalRecords > 0 || $userexternaldeposits->CurrentAction) { ?>
<div class="card ew-card ew-grid<?php if ($userexternaldeposits_list->isAddOrEdit()) { ?> ew-grid-add-edit<?php } ?> userexternaldeposits">
<form name="fuserexternaldepositslist" id="fuserexternaldepositslist" class="form-inline ew-form ew-list-form" action="<?php echo CurrentPageName() ?>" method="post">
<?php if ($Page->CheckToken) { ?>
<input type="hidden" name="<?php echo Config("TOKEN_NAME") ?>" value="<?php echo $Page->Token ?>">
<?php } ?>
<input type="hidden" name="t" value="userexternaldeposits">
<div id="gmp_userexternaldeposits" class="<?php echo ResponsiveTableClass() ?>card-body ew-grid-middle-panel">
<?php if ($userexternaldeposits_list->TotalRecords > 0 || $userexternaldeposits_list->isGridEdit()) { ?>
<table id="tbl_userexternaldepositslist" class="table ew-table"><!-- .ew-table -->
<thead>
	<tr class="ew-table-header">
<?php

// Header row
$userexternaldeposits->RowType = ROWTYPE_HEADER;

// Render list options
$userexternaldeposits_list->renderListOptions();

// Render list options (header, left)
$userexternaldeposits_list->ListOptions->render("header", "left");
?>
<?php if ($userexternaldeposits_list->depositid->Visible) { // depositid ?>
	<?php if ($userexternaldeposits_list->SortUrl($userexternaldeposits_list->depositid) == "") { ?>
		<th data-name="depositid" class="<?php echo $userexternaldeposits_list->depositid->headerCellClass() ?>"><div id="elh_userexternaldeposits_depositid" class="userexternaldeposits_depositid"><div class="ew-table-header-caption"><?php echo $userexternaldeposits_list->depositid->caption() ?></div></div></th>
	<?php } else { ?>
		<th data-name="depositid" class="<?php echo $userexternaldeposits_list->depositid->headerCellClass() ?>"><div class="ew-pointer" onclick="ew.sort(event, '<?php echo $userexternaldeposits_list->SortUrl($userexternaldeposits_list->depositid) ?>', 1);"><div id="elh_userexternaldeposits_depositid" class="userexternaldeposits_depositid">
			<div class="ew-table-header-btn"><span class="ew-table-header-caption"><?php echo $userexternaldeposits_list->depositid->caption() ?></span><span class="ew-table-header-sort"><?php if ($userexternaldeposits_list->depositid->getSort() == "ASC") { ?><i class="fas fa-sort-up"></i><?php } elseif ($userexternaldeposits_list->depositid->getSort() == "DESC") { ?><i class="fas fa-sort-down"></i><?php } ?></span></div>
		</div></div></th>
	<?php } ?>
<?php } ?>
<?php if ($userexternaldeposits_list->_userid->Visible) { // userid ?>
	<?php if ($userexternaldeposits_list->SortUrl($userexternaldeposits_list->_userid) == "") { ?>
		<th data-name="_userid" class="<?php echo $userexternaldeposits_list->_userid->headerCellClass() ?>"><div id="elh_userexternaldeposits__userid" class="userexternaldeposits__userid"><div class="ew-table-header-caption"><?php echo $userexternaldeposits_list->_userid->caption() ?></div></div></th>
	<?php } else { ?>
		<th data-name="_userid" class="<?php echo $userexternaldeposits_list->_userid->headerCellClass() ?>"><div class="ew-pointer" onclick="ew.sort(event, '<?php echo $userexternaldeposits_list->SortUrl($userexternaldeposits_list->_userid) ?>', 1);"><div id="elh_userexternaldeposits__userid" class="userexternaldeposits__userid">
			<div class="ew-table-header-btn"><span class="ew-table-header-caption"><?php echo $userexternaldeposits_list->_userid->caption() ?></span><span class="ew-table-header-sort"><?php if ($userexternaldeposits_list->_userid->getSort() == "ASC") { ?><i class="fas fa-sort-up"></i><?php } elseif ($userexternaldeposits_list->_userid->getSort() == "DESC") { ?><i class="fas fa-sort-down"></i><?php } ?></span></div>
		</div></div></th>
	<?php } ?>
<?php } ?>
<?php if ($userexternaldeposits_list->refno->Visible) { // refno ?>
	<?php if ($userexternaldeposits_list->SortUrl($userexternaldeposits_list->refno) == "") { ?>
		<th data-name="refno" class="<?php echo $userexternaldeposits_list->refno->headerCellClass() ?>"><div id="elh_userexternaldeposits_refno" class="userexternaldeposits_refno"><div class="ew-table-header-caption"><?php echo $userexternaldeposits_list->refno->caption() ?></div></div></th>
	<?php } else { ?>
		<th data-name="refno" class="<?php echo $userexternaldeposits_list->refno->headerCellClass() ?>"><div class="ew-pointer" onclick="ew.sort(event, '<?php echo $userexternaldeposits_list->SortUrl($userexternaldeposits_list->refno) ?>', 1);"><div id="elh_userexternaldeposits_refno" class="userexternaldeposits_refno">
			<div class="ew-table-header-btn"><span class="ew-table-header-caption"><?php echo $userexternaldeposits_list->refno->caption() ?><?php echo $Language->phrase("SrchLegend") ?></span><span class="ew-table-header-sort"><?php if ($userexternaldeposits_list->refno->getSort() == "ASC") { ?><i class="fas fa-sort-up"></i><?php } elseif ($userexternaldeposits_list->refno->getSort() == "DESC") { ?><i class="fas fa-sort-down"></i><?php } ?></span></div>
		</div></div></th>
	<?php } ?>
<?php } ?>
<?php if ($userexternaldeposits_list->deposittime->Visible) { // deposittime ?>
	<?php if ($userexternaldeposits_list->SortUrl($userexternaldeposits_list->deposittime) == "") { ?>
		<th data-name="deposittime" class="<?php echo $userexternaldeposits_list->deposittime->headerCellClass() ?>"><div id="elh_userexternaldeposits_deposittime" class="userexternaldeposits_deposittime"><div class="ew-table-header-caption"><?php echo $userexternaldeposits_list->deposittime->caption() ?></div></div></th>
	<?php } else { ?>
		<th data-name="deposittime" class="<?php echo $userexternaldeposits_list->deposittime->headerCellClass() ?>"><div class="ew-pointer" onclick="ew.sort(event, '<?php echo $userexternaldeposits_list->SortUrl($userexternaldeposits_list->deposittime) ?>', 1);"><div id="elh_userexternaldeposits_deposittime" class="userexternaldeposits_deposittime">
			<div class="ew-table-header-btn"><span class="ew-table-header-caption"><?php echo $userexternaldeposits_list->deposittime->caption() ?></span><span class="ew-table-header-sort"><?php if ($userexternaldeposits_list->deposittime->getSort() == "ASC") { ?><i class="fas fa-sort-up"></i><?php } elseif ($userexternaldeposits_list->deposittime->getSort() == "DESC") { ?><i class="fas fa-sort-down"></i><?php } ?></span></div>
		</div></div></th>
	<?php } ?>
<?php } ?>
<?php if ($userexternaldeposits_list->source->Visible) { // source ?>
	<?php if ($userexternaldeposits_list->SortUrl($userexternaldeposits_list->source) == "") { ?>
		<th data-name="source" class="<?php echo $userexternaldeposits_list->source->headerCellClass() ?>"><div id="elh_userexternaldeposits_source" class="userexternaldeposits_source"><div class="ew-table-header-caption"><?php echo $userexternaldeposits_list->source->caption() ?></div></div></th>
	<?php } else { ?>
		<th data-name="source" class="<?php echo $userexternaldeposits_list->source->headerCellClass() ?>"><div class="ew-pointer" onclick="ew.sort(event, '<?php echo $userexternaldeposits_list->SortUrl($userexternaldeposits_list->source) ?>', 1);"><div id="elh_userexternaldeposits_source" class="userexternaldeposits_source">
			<div class="ew-table-header-btn"><span class="ew-table-header-caption"><?php echo $userexternaldeposits_list->source->caption() ?><?php echo $Language->phrase("SrchLegend") ?></span><span class="ew-table-header-sort"><?php if ($userexternaldeposits_list->source->getSort() == "ASC") { ?><i class="fas fa-sort-up"></i><?php } elseif ($userexternaldeposits_list->source->getSort() == "DESC") { ?><i class="fas fa-sort-down"></i><?php } ?></span></div>
		</div></div></th>
	<?php } ?>
<?php } ?>
<?php if ($userexternaldeposits_list->otherref->Visible) { // otherref ?>
	<?php if ($userexternaldeposits_list->SortUrl($userexternaldeposits_list->otherref) == "") { ?>
		<th data-name="otherref" class="<?php echo $userexternaldeposits_list->otherref->headerCellClass() ?>"><div id="elh_userexternaldeposits_otherref" class="userexternaldeposits_otherref"><div class="ew-table-header-caption"><?php echo $userexternaldeposits_list->otherref->caption() ?></div></div></th>
	<?php } else { ?>
		<th data-name="otherref" class="<?php echo $userexternaldeposits_list->otherref->headerCellClass() ?>"><div class="ew-pointer" onclick="ew.sort(event, '<?php echo $userexternaldeposits_list->SortUrl($userexternaldeposits_list->otherref) ?>', 1);"><div id="elh_userexternaldeposits_otherref" class="userexternaldeposits_otherref">
			<div class="ew-table-header-btn"><span class="ew-table-header-caption"><?php echo $userexternaldeposits_list->otherref->caption() ?><?php echo $Language->phrase("SrchLegend") ?></span><span class="ew-table-header-sort"><?php if ($userexternaldeposits_list->otherref->getSort() == "ASC") { ?><i class="fas fa-sort-up"></i><?php } elseif ($userexternaldeposits_list->otherref->getSort() == "DESC") { ?><i class="fas fa-sort-down"></i><?php } ?></span></div>
		</div></div></th>
	<?php } ?>
<?php } ?>
<?php if ($userexternaldeposits_list->curr->Visible) { // curr ?>
	<?php if ($userexternaldeposits_list->SortUrl($userexternaldeposits_list->curr) == "") { ?>
		<th data-name="curr" class="<?php echo $userexternaldeposits_list->curr->headerCellClass() ?>"><div id="elh_userexternaldeposits_curr" class="userexternaldeposits_curr"><div class="ew-table-header-caption"><?php echo $userexternaldeposits_list->curr->caption() ?></div></div></th>
	<?php } else { ?>
		<th data-name="curr" class="<?php echo $userexternaldeposits_list->curr->headerCellClass() ?>"><div class="ew-pointer" onclick="ew.sort(event, '<?php echo $userexternaldeposits_list->SortUrl($userexternaldeposits_list->curr) ?>', 1);"><div id="elh_userexternaldeposits_curr" class="userexternaldeposits_curr">
			<div class="ew-table-header-btn"><span class="ew-table-header-caption"><?php echo $userexternaldeposits_list->curr->caption() ?><?php echo $Language->phrase("SrchLegend") ?></span><span class="ew-table-header-sort"><?php if ($userexternaldeposits_list->curr->getSort() == "ASC") { ?><i class="fas fa-sort-up"></i><?php } elseif ($userexternaldeposits_list->curr->getSort() == "DESC") { ?><i class="fas fa-sort-down"></i><?php } ?></span></div>
		</div></div></th>
	<?php } ?>
<?php } ?>
<?php if ($userexternaldeposits_list->amount->Visible) { // amount ?>
	<?php if ($userexternaldeposits_list->SortUrl($userexternaldeposits_list->amount) == "") { ?>
		<th data-name="amount" class="<?php echo $userexternaldeposits_list->amount->headerCellClass() ?>"><div id="elh_userexternaldeposits_amount" class="userexternaldeposits_amount"><div class="ew-table-header-caption"><?php echo $userexternaldeposits_list->amount->caption() ?></div></div></th>
	<?php } else { ?>
		<th data-name="amount" class="<?php echo $userexternaldeposits_list->amount->headerCellClass() ?>"><div class="ew-pointer" onclick="ew.sort(event, '<?php echo $userexternaldeposits_list->SortUrl($userexternaldeposits_list->amount) ?>', 1);"><div id="elh_userexternaldeposits_amount" class="userexternaldeposits_amount">
			<div class="ew-table-header-btn"><span class="ew-table-header-caption"><?php echo $userexternaldeposits_list->amount->caption() ?></span><span class="ew-table-header-sort"><?php if ($userexternaldeposits_list->amount->getSort() == "ASC") { ?><i class="fas fa-sort-up"></i><?php } elseif ($userexternaldeposits_list->amount->getSort() == "DESC") { ?><i class="fas fa-sort-down"></i><?php } ?></span></div>
		</div></div></th>
	<?php } ?>
<?php } ?>
<?php if ($userexternaldeposits_list->piid->Visible) { // piid ?>
	<?php if ($userexternaldeposits_list->SortUrl($userexternaldeposits_list->piid) == "") { ?>
		<th data-name="piid" class="<?php echo $userexternaldeposits_list->piid->headerCellClass() ?>"><div id="elh_userexternaldeposits_piid" class="userexternaldeposits_piid"><div class="ew-table-header-caption"><?php echo $userexternaldeposits_list->piid->caption() ?></div></div></th>
	<?php } else { ?>
		<th data-name="piid" class="<?php echo $userexternaldeposits_list->piid->headerCellClass() ?>"><div class="ew-pointer" onclick="ew.sort(event, '<?php echo $userexternaldeposits_list->SortUrl($userexternaldeposits_list->piid) ?>', 1);"><div id="elh_userexternaldeposits_piid" class="userexternaldeposits_piid">
			<div class="ew-table-header-btn"><span class="ew-table-header-caption"><?php echo $userexternaldeposits_list->piid->caption() ?></span><span class="ew-table-header-sort"><?php if ($userexternaldeposits_list->piid->getSort() == "ASC") { ?><i class="fas fa-sort-up"></i><?php } elseif ($userexternaldeposits_list->piid->getSort() == "DESC") { ?><i class="fas fa-sort-down"></i><?php } ?></span></div>
		</div></div></th>
	<?php } ?>
<?php } ?>
<?php

// Render list options (header, right)
$userexternaldeposits_list->ListOptions->render("header", "right");
?>
	</tr>
</thead>
<tbody>
<?php
if ($userexternaldeposits_list->ExportAll && $userexternaldeposits_list->isExport()) {
	$userexternaldeposits_list->StopRecord = $userexternaldeposits_list->TotalRecords;
} else {

	// Set the last record to display
	if ($userexternaldeposits_list->TotalRecords > $userexternaldeposits_list->StartRecord + $userexternaldeposits_list->DisplayRecords - 1)
		$userexternaldeposits_list->StopRecord = $userexternaldeposits_list->StartRecord + $userexternaldeposits_list->DisplayRecords - 1;
	else
		$userexternaldeposits_list->StopRecord = $userexternaldeposits_list->TotalRecords;
}
$userexternaldeposits_list->RecordCount = $userexternaldeposits_list->StartRecord - 1;
if ($userexternaldeposits_list->Recordset && !$userexternaldeposits_list->Recordset->EOF) {
	$userexternaldeposits_list->Recordset->moveFirst();
	$selectLimit = $userexternaldeposits_list->UseSelectLimit;
	if (!$selectLimit && $userexternaldeposits_list->StartRecord > 1)
		$userexternaldeposits_list->Recordset->move($userexternaldeposits_list->StartRecord - 1);
} elseif (!$userexternaldeposits->AllowAddDeleteRow && $userexternaldeposits_list->StopRecord == 0) {
	$userexternaldeposits_list->StopRecord = $userexternaldeposits->GridAddRowCount;
}

// Initialize aggregate
$userexternaldeposits->RowType = ROWTYPE_AGGREGATEINIT;
$userexternaldeposits->resetAttributes();
$userexternaldeposits_list->renderRow();
while ($userexternaldeposits_list->RecordCount < $userexternaldeposits_list->StopRecord) {
	$userexternaldeposits_list->RecordCount++;
	if ($userexternaldeposits_list->RecordCount >= $userexternaldeposits_list->StartRecord) {
		$userexternaldeposits_list->RowCount++;

		// Set up key count
		$userexternaldeposits_list->KeyCount = $userexternaldeposits_list->RowIndex;

		// Init row class and style
		$userexternaldeposits->resetAttributes();
		$userexternaldeposits->CssClass = "";
		if ($userexternaldeposits_list->isGridAdd()) {
		} else {
			$userexternaldeposits_list->loadRowValues($userexternaldeposits_list->Recordset); // Load row values
		}
		$userexternaldeposits->RowType = ROWTYPE_VIEW; // Render view

		// Set up row id / data-rowindex
		$userexternaldeposits->RowAttrs->merge(["data-rowindex" => $userexternaldeposits_list->RowCount, "id" => "r" . $userexternaldeposits_list->RowCount . "_userexternaldeposits", "data-rowtype" => $userexternaldeposits->RowType]);

		// Render row
		$userexternaldeposits_list->renderRow();

		// Render list options
		$userexternaldeposits_list->renderListOptions();
?>
	<tr <?php echo $userexternaldeposits->rowAttributes() ?>>
<?php

// Render list options (body, left)
$userexternaldeposits_list->ListOptions->render("body", "left", $userexternaldeposits_list->RowCount);
?>
	<?php if ($userexternaldeposits_list->depositid->Visible) { // depositid ?>
		<td data-name="depositid" <?php echo $userexternaldeposits_list->depositid->cellAttributes() ?>>
<span id="el<?php echo $userexternaldeposits_list->RowCount ?>_userexternaldeposits_depositid">
<span<?php echo $userexternaldeposits_list->depositid->viewAttributes() ?>><?php echo $userexternaldeposits_list->depositid->getViewValue() ?></span>
</span>
</td>
	<?php } ?>
	<?php if ($userexternaldeposits_list->_userid->Visible) { // userid ?>
		<td data-name="_userid" <?php echo $userexternaldeposits_list->_userid->cellAttributes() ?>>
<span id="el<?php echo $userexternaldeposits_list->RowCount ?>_userexternaldeposits__userid">
<span<?php echo $userexternaldeposits_list->_userid->viewAttributes() ?>><?php echo $userexternaldeposits_list->_userid->getViewValue() ?></span>
</span>
</td>
	<?php } ?>
	<?php if ($userexternaldeposits_list->refno->Visible) { // refno ?>
		<td data-name="refno" <?php echo $userexternaldeposits_list->refno->cellAttributes() ?>>
<span id="el<?php echo $userexternaldeposits_list->RowCount ?>_userexternaldeposits_refno">
<span<?php echo $userexternaldeposits_list->refno->viewAttributes() ?>><?php echo $userexternaldeposits_list->refno->getViewValue() ?></span>
</span>
</td>
	<?php } ?>
	<?php if ($userexternaldeposits_list->deposittime->Visible) { // deposittime ?>
		<td data-name="deposittime" <?php echo $userexternaldeposits_list->deposittime->cellAttributes() ?>>
<span id="el<?php echo $userexternaldeposits_list->RowCount ?>_userexternaldeposits_deposittime">
<span<?php echo $userexternaldeposits_list->deposittime->viewAttributes() ?>><?php echo $userexternaldeposits_list->deposittime->getViewValue() ?></span>
</span>
</td>
	<?php } ?>
	<?php if ($userexternaldeposits_list->source->Visible) { // source ?>
		<td data-name="source" <?php echo $userexternaldeposits_list->source->cellAttributes() ?>>
<span id="el<?php echo $userexternaldeposits_list->RowCount ?>_userexternaldeposits_source">
<span<?php echo $userexternaldeposits_list->source->viewAttributes() ?>><?php echo $userexternaldeposits_list->source->getViewValue() ?></span>
</span>
</td>
	<?php } ?>
	<?php if ($userexternaldeposits_list->otherref->Visible) { // otherref ?>
		<td data-name="otherref" <?php echo $userexternaldeposits_list->otherref->cellAttributes() ?>>
<span id="el<?php echo $userexternaldeposits_list->RowCount ?>_userexternaldeposits_otherref">
<span<?php echo $userexternaldeposits_list->otherref->viewAttributes() ?>><?php echo $userexternaldeposits_list->otherref->getViewValue() ?></span>
</span>
</td>
	<?php } ?>
	<?php if ($userexternaldeposits_list->curr->Visible) { // curr ?>
		<td data-name="curr" <?php echo $userexternaldeposits_list->curr->cellAttributes() ?>>
<span id="el<?php echo $userexternaldeposits_list->RowCount ?>_userexternaldeposits_curr">
<span<?php echo $userexternaldeposits_list->curr->viewAttributes() ?>><?php echo $userexternaldeposits_list->curr->getViewValue() ?></span>
</span>
</td>
	<?php } ?>
	<?php if ($userexternaldeposits_list->amount->Visible) { // amount ?>
		<td data-name="amount" <?php echo $userexternaldeposits_list->amount->cellAttributes() ?>>
<span id="el<?php echo $userexternaldeposits_list->RowCount ?>_userexternaldeposits_amount">
<span<?php echo $userexternaldeposits_list->amount->viewAttributes() ?>><?php echo $userexternaldeposits_list->amount->getViewValue() ?></span>
</span>
</td>
	<?php } ?>
	<?php if ($userexternaldeposits_list->piid->Visible) { // piid ?>
		<td data-name="piid" <?php echo $userexternaldeposits_list->piid->cellAttributes() ?>>
<span id="el<?php echo $userexternaldeposits_list->RowCount ?>_userexternaldeposits_piid">
<span<?php echo $userexternaldeposits_list->piid->viewAttributes() ?>><?php echo $userexternaldeposits_list->piid->getViewValue() ?></span>
</span>
</td>
	<?php } ?>
<?php

// Render list options (body, right)
$userexternaldeposits_list->ListOptions->render("body", "right", $userexternaldeposits_list->RowCount);
?>
	</tr>
<?php
	}
	if (!$userexternaldeposits_list->isGridAdd())
		$userexternaldeposits_list->Recordset->moveNext();
}
?>
</tbody>
</table><!-- /.ew-table -->
<?php } ?>
</div><!-- /.ew-grid-middle-panel -->
<?php if (!$userexternaldeposits->CurrentAction) { ?>
<input type="hidden" name="action" id="action" value="">
<?php } ?>
</form><!-- /.ew-list-form -->
<?php

// Close recordset
if ($userexternaldeposits_list->Recordset)
	$userexternaldeposits_list->Recordset->Close();
?>
<?php if (!$userexternaldeposits_list->isExport()) { ?>
<div class="card-footer ew-grid-lower-panel">
<?php if (!$userexternaldeposits_list->isGridAdd()) { ?>
<form name="ew-pager-form" class="form-inline ew-form ew-pager-form" action="<?php echo CurrentPageName() ?>">
<?php echo $userexternaldeposits_list->Pager->render() ?>
</form>
<?php } ?>
<div class="ew-list-other-options">
<?php $userexternaldeposits_list->OtherOptions->render("body", "bottom") ?>
</div>
<div class="clearfix"></div>
</div>
<?php } ?>
</div><!-- /.ew-grid -->
<?php } ?>
<?php if ($userexternaldeposits_list->TotalRecords == 0 && !$userexternaldeposits->CurrentAction) { // Show other options ?>
<div class="ew-list-other-options">
<?php $userexternaldeposits_list->OtherOptions->render("body") ?>
</div>
<div class="clearfix"></div>
<?php } ?>
<?php
$userexternaldeposits_list->showPageFooter();
if (Config("DEBUG"))
	echo GetDebugMessage();
?>
<?php if (!$userexternaldeposits_list->isExport()) { ?>
<script>
loadjs.ready("load", function() {

	// Startup script
	// Write your table-specific startup script here
	// console.log("page loaded");

});
</script>
<?php } ?>
<?php include_once "footer.php"; ?>
<?php
$userexternaldeposits_list->terminate();
?>