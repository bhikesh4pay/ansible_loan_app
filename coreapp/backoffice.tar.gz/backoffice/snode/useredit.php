<?php
namespace PHPMaker2020\_4payadmin;

// Autoload
include_once "autoload.php";

// Session
if (session_status() !== PHP_SESSION_ACTIVE)
	\Delight\Cookie\Session::start(Config("COOKIE_SAMESITE")); // Init session data

// Output buffering
ob_start();
?>
<?php

// Write header
WriteHeader(FALSE);

// Create page object
$user_edit = new user_edit();

// Run the page
$user_edit->run();

// Setup login status
SetupLoginStatus();
SetClientVar("login", LoginStatus());

// Global Page Rendering event (in userfn*.php)
Page_Rendering();

// Page Rendering event
$user_edit->Page_Render();
?>
<?php include_once "header.php"; ?>
<script>
var fuseredit, currentPageID;
loadjs.ready("head", function() {

	// Form object
	currentPageID = ew.PAGE_ID = "edit";
	fuseredit = currentForm = new ew.Form("fuseredit", "edit");

	// Validate form
	fuseredit.validate = function() {
		if (!this.validateRequired)
			return true; // Ignore validation
		var $ = jQuery, fobj = this.getForm(), $fobj = $(fobj);
		if ($fobj.find("#confirm").val() == "confirm")
			return true;
		var elm, felm, uelm, addcnt = 0;
		var $k = $fobj.find("#" + this.formKeyCountName); // Get key_count
		var rowcnt = ($k[0]) ? parseInt($k.val(), 10) : 1;
		var startcnt = (rowcnt == 0) ? 0 : 1; // Check rowcnt == 0 => Inline-Add
		var gridinsert = ["insert", "gridinsert"].includes($fobj.find("#action").val()) && $k[0];
		for (var i = startcnt; i <= rowcnt; i++) {
			var infix = ($k[0]) ? String(i) : "";
			$fobj.data("rowindex", infix);
			<?php if ($user_edit->id->Required) { ?>
				elm = this.getElements("x" + infix + "_id");
				if (elm && !ew.isHidden(elm) && !ew.hasValue(elm))
					return this.onError(elm, "<?php echo JsEncode(str_replace("%s", $user_edit->id->caption(), $user_edit->id->RequiredErrorMessage)) ?>");
			<?php } ?>
				elm = this.getElements("x" + infix + "_id");
				if (elm && !ew.checkInteger(elm.value))
					return this.onError(elm, "<?php echo JsEncode($user_edit->id->errorMessage()) ?>");
			<?php if ($user_edit->firstName->Required) { ?>
				elm = this.getElements("x" + infix + "_firstName");
				if (elm && !ew.isHidden(elm) && !ew.hasValue(elm))
					return this.onError(elm, "<?php echo JsEncode(str_replace("%s", $user_edit->firstName->caption(), $user_edit->firstName->RequiredErrorMessage)) ?>");
			<?php } ?>
			<?php if ($user_edit->lastName->Required) { ?>
				elm = this.getElements("x" + infix + "_lastName");
				if (elm && !ew.isHidden(elm) && !ew.hasValue(elm))
					return this.onError(elm, "<?php echo JsEncode(str_replace("%s", $user_edit->lastName->caption(), $user_edit->lastName->RequiredErrorMessage)) ?>");
			<?php } ?>
			<?php if ($user_edit->otherNames->Required) { ?>
				elm = this.getElements("x" + infix + "_otherNames");
				if (elm && !ew.isHidden(elm) && !ew.hasValue(elm))
					return this.onError(elm, "<?php echo JsEncode(str_replace("%s", $user_edit->otherNames->caption(), $user_edit->otherNames->RequiredErrorMessage)) ?>");
			<?php } ?>
			<?php if ($user_edit->passwordRequireChange->Required) { ?>
				elm = this.getElements("x" + infix + "_passwordRequireChange");
				if (elm && !ew.isHidden(elm) && !ew.hasValue(elm))
					return this.onError(elm, "<?php echo JsEncode(str_replace("%s", $user_edit->passwordRequireChange->caption(), $user_edit->passwordRequireChange->RequiredErrorMessage)) ?>");
			<?php } ?>
			<?php if ($user_edit->franchiseeID->Required) { ?>
				elm = this.getElements("x" + infix + "_franchiseeID");
				if (elm && !ew.isHidden(elm) && !ew.hasValue(elm))
					return this.onError(elm, "<?php echo JsEncode(str_replace("%s", $user_edit->franchiseeID->caption(), $user_edit->franchiseeID->RequiredErrorMessage)) ?>");
			<?php } ?>
				elm = this.getElements("x" + infix + "_franchiseeID");
				if (elm && !ew.checkInteger(elm.value))
					return this.onError(elm, "<?php echo JsEncode($user_edit->franchiseeID->errorMessage()) ?>");
			<?php if ($user_edit->dateAdded->Required) { ?>
				elm = this.getElements("x" + infix + "_dateAdded");
				if (elm && !ew.isHidden(elm) && !ew.hasValue(elm))
					return this.onError(elm, "<?php echo JsEncode(str_replace("%s", $user_edit->dateAdded->caption(), $user_edit->dateAdded->RequiredErrorMessage)) ?>");
			<?php } ?>
				elm = this.getElements("x" + infix + "_dateAdded");
				if (elm && !ew.checkDateDef(elm.value))
					return this.onError(elm, "<?php echo JsEncode($user_edit->dateAdded->errorMessage()) ?>");
			<?php if ($user_edit->timezoneid->Required) { ?>
				elm = this.getElements("x" + infix + "_timezoneid");
				if (elm && !ew.isHidden(elm) && !ew.hasValue(elm))
					return this.onError(elm, "<?php echo JsEncode(str_replace("%s", $user_edit->timezoneid->caption(), $user_edit->timezoneid->RequiredErrorMessage)) ?>");
			<?php } ?>
			<?php if ($user_edit->contactPhoneNo->Required) { ?>
				elm = this.getElements("x" + infix + "_contactPhoneNo");
				if (elm && !ew.isHidden(elm) && !ew.hasValue(elm))
					return this.onError(elm, "<?php echo JsEncode(str_replace("%s", $user_edit->contactPhoneNo->caption(), $user_edit->contactPhoneNo->RequiredErrorMessage)) ?>");
			<?php } ?>
			<?php if ($user_edit->telephoneno->Required) { ?>
				elm = this.getElements("x" + infix + "_telephoneno");
				if (elm && !ew.isHidden(elm) && !ew.hasValue(elm))
					return this.onError(elm, "<?php echo JsEncode(str_replace("%s", $user_edit->telephoneno->caption(), $user_edit->telephoneno->RequiredErrorMessage)) ?>");
			<?php } ?>
			<?php if ($user_edit->telephoneverified->Required) { ?>
				elm = this.getElements("x" + infix + "_telephoneverified");
				if (elm && !ew.isHidden(elm) && !ew.hasValue(elm))
					return this.onError(elm, "<?php echo JsEncode(str_replace("%s", $user_edit->telephoneverified->caption(), $user_edit->telephoneverified->RequiredErrorMessage)) ?>");
			<?php } ?>
			<?php if ($user_edit->telephonereceivemessage->Required) { ?>
				elm = this.getElements("x" + infix + "_telephonereceivemessage");
				if (elm && !ew.isHidden(elm) && !ew.hasValue(elm))
					return this.onError(elm, "<?php echo JsEncode(str_replace("%s", $user_edit->telephonereceivemessage->caption(), $user_edit->telephonereceivemessage->RequiredErrorMessage)) ?>");
			<?php } ?>
			<?php if ($user_edit->verification1->Required) { ?>
				elm = this.getElements("x" + infix + "_verification1");
				if (elm && !ew.isHidden(elm) && !ew.hasValue(elm))
					return this.onError(elm, "<?php echo JsEncode(str_replace("%s", $user_edit->verification1->caption(), $user_edit->verification1->RequiredErrorMessage)) ?>");
			<?php } ?>
			<?php if ($user_edit->verification2->Required) { ?>
				elm = this.getElements("x" + infix + "_verification2");
				if (elm && !ew.isHidden(elm) && !ew.hasValue(elm))
					return this.onError(elm, "<?php echo JsEncode(str_replace("%s", $user_edit->verification2->caption(), $user_edit->verification2->RequiredErrorMessage)) ?>");
			<?php } ?>
			<?php if ($user_edit->verification3->Required) { ?>
				elm = this.getElements("x" + infix + "_verification3");
				if (elm && !ew.isHidden(elm) && !ew.hasValue(elm))
					return this.onError(elm, "<?php echo JsEncode(str_replace("%s", $user_edit->verification3->caption(), $user_edit->verification3->RequiredErrorMessage)) ?>");
			<?php } ?>
			<?php if ($user_edit->address1->Required) { ?>
				elm = this.getElements("x" + infix + "_address1");
				if (elm && !ew.isHidden(elm) && !ew.hasValue(elm))
					return this.onError(elm, "<?php echo JsEncode(str_replace("%s", $user_edit->address1->caption(), $user_edit->address1->RequiredErrorMessage)) ?>");
			<?php } ?>
			<?php if ($user_edit->address2->Required) { ?>
				elm = this.getElements("x" + infix + "_address2");
				if (elm && !ew.isHidden(elm) && !ew.hasValue(elm))
					return this.onError(elm, "<?php echo JsEncode(str_replace("%s", $user_edit->address2->caption(), $user_edit->address2->RequiredErrorMessage)) ?>");
			<?php } ?>
			<?php if ($user_edit->cityname->Required) { ?>
				elm = this.getElements("x" + infix + "_cityname");
				if (elm && !ew.isHidden(elm) && !ew.hasValue(elm))
					return this.onError(elm, "<?php echo JsEncode(str_replace("%s", $user_edit->cityname->caption(), $user_edit->cityname->RequiredErrorMessage)) ?>");
			<?php } ?>
			<?php if ($user_edit->countryid->Required) { ?>
				elm = this.getElements("x" + infix + "_countryid");
				if (elm && !ew.isHidden(elm) && !ew.hasValue(elm))
					return this.onError(elm, "<?php echo JsEncode(str_replace("%s", $user_edit->countryid->caption(), $user_edit->countryid->RequiredErrorMessage)) ?>");
			<?php } ?>
			<?php if ($user_edit->stateid->Required) { ?>
				elm = this.getElements("x" + infix + "_stateid");
				if (elm && !ew.isHidden(elm) && !ew.hasValue(elm))
					return this.onError(elm, "<?php echo JsEncode(str_replace("%s", $user_edit->stateid->caption(), $user_edit->stateid->RequiredErrorMessage)) ?>");
			<?php } ?>
			<?php if ($user_edit->defaultcurrency->Required) { ?>
				elm = this.getElements("x" + infix + "_defaultcurrency");
				if (elm && !ew.isHidden(elm) && !ew.hasValue(elm))
					return this.onError(elm, "<?php echo JsEncode(str_replace("%s", $user_edit->defaultcurrency->caption(), $user_edit->defaultcurrency->RequiredErrorMessage)) ?>");
			<?php } ?>
			<?php if ($user_edit->challengeq1->Required) { ?>
				elm = this.getElements("x" + infix + "_challengeq1");
				if (elm && !ew.isHidden(elm) && !ew.hasValue(elm))
					return this.onError(elm, "<?php echo JsEncode(str_replace("%s", $user_edit->challengeq1->caption(), $user_edit->challengeq1->RequiredErrorMessage)) ?>");
			<?php } ?>
				elm = this.getElements("x" + infix + "_challengeq1");
				if (elm && !ew.checkInteger(elm.value))
					return this.onError(elm, "<?php echo JsEncode($user_edit->challengeq1->errorMessage()) ?>");
			<?php if ($user_edit->challengea1->Required) { ?>
				elm = this.getElements("x" + infix + "_challengea1");
				if (elm && !ew.isHidden(elm) && !ew.hasValue(elm))
					return this.onError(elm, "<?php echo JsEncode(str_replace("%s", $user_edit->challengea1->caption(), $user_edit->challengea1->RequiredErrorMessage)) ?>");
			<?php } ?>
			<?php if ($user_edit->challengeq2->Required) { ?>
				elm = this.getElements("x" + infix + "_challengeq2");
				if (elm && !ew.isHidden(elm) && !ew.hasValue(elm))
					return this.onError(elm, "<?php echo JsEncode(str_replace("%s", $user_edit->challengeq2->caption(), $user_edit->challengeq2->RequiredErrorMessage)) ?>");
			<?php } ?>
				elm = this.getElements("x" + infix + "_challengeq2");
				if (elm && !ew.checkInteger(elm.value))
					return this.onError(elm, "<?php echo JsEncode($user_edit->challengeq2->errorMessage()) ?>");
			<?php if ($user_edit->challengea2->Required) { ?>
				elm = this.getElements("x" + infix + "_challengea2");
				if (elm && !ew.isHidden(elm) && !ew.hasValue(elm))
					return this.onError(elm, "<?php echo JsEncode(str_replace("%s", $user_edit->challengea2->caption(), $user_edit->challengea2->RequiredErrorMessage)) ?>");
			<?php } ?>
			<?php if ($user_edit->challengeq3->Required) { ?>
				elm = this.getElements("x" + infix + "_challengeq3");
				if (elm && !ew.isHidden(elm) && !ew.hasValue(elm))
					return this.onError(elm, "<?php echo JsEncode(str_replace("%s", $user_edit->challengeq3->caption(), $user_edit->challengeq3->RequiredErrorMessage)) ?>");
			<?php } ?>
				elm = this.getElements("x" + infix + "_challengeq3");
				if (elm && !ew.checkInteger(elm.value))
					return this.onError(elm, "<?php echo JsEncode($user_edit->challengeq3->errorMessage()) ?>");
			<?php if ($user_edit->challengea3->Required) { ?>
				elm = this.getElements("x" + infix + "_challengea3");
				if (elm && !ew.isHidden(elm) && !ew.hasValue(elm))
					return this.onError(elm, "<?php echo JsEncode(str_replace("%s", $user_edit->challengea3->caption(), $user_edit->challengea3->RequiredErrorMessage)) ?>");
			<?php } ?>
			<?php if ($user_edit->passwordCounter->Required) { ?>
				elm = this.getElements("x" + infix + "_passwordCounter");
				if (elm && !ew.isHidden(elm) && !ew.hasValue(elm))
					return this.onError(elm, "<?php echo JsEncode(str_replace("%s", $user_edit->passwordCounter->caption(), $user_edit->passwordCounter->RequiredErrorMessage)) ?>");
			<?php } ?>
				elm = this.getElements("x" + infix + "_passwordCounter");
				if (elm && !ew.checkInteger(elm.value))
					return this.onError(elm, "<?php echo JsEncode($user_edit->passwordCounter->errorMessage()) ?>");
			<?php if ($user_edit->passwordChangedDate->Required) { ?>
				elm = this.getElements("x" + infix + "_passwordChangedDate");
				if (elm && !ew.isHidden(elm) && !ew.hasValue(elm))
					return this.onError(elm, "<?php echo JsEncode(str_replace("%s", $user_edit->passwordChangedDate->caption(), $user_edit->passwordChangedDate->RequiredErrorMessage)) ?>");
			<?php } ?>
				elm = this.getElements("x" + infix + "_passwordChangedDate");
				if (elm && !ew.checkDateDef(elm.value))
					return this.onError(elm, "<?php echo JsEncode($user_edit->passwordChangedDate->errorMessage()) ?>");
			<?php if ($user_edit->pinCounter->Required) { ?>
				elm = this.getElements("x" + infix + "_pinCounter");
				if (elm && !ew.isHidden(elm) && !ew.hasValue(elm))
					return this.onError(elm, "<?php echo JsEncode(str_replace("%s", $user_edit->pinCounter->caption(), $user_edit->pinCounter->RequiredErrorMessage)) ?>");
			<?php } ?>
				elm = this.getElements("x" + infix + "_pinCounter");
				if (elm && !ew.checkInteger(elm.value))
					return this.onError(elm, "<?php echo JsEncode($user_edit->pinCounter->errorMessage()) ?>");
			<?php if ($user_edit->langID->Required) { ?>
				elm = this.getElements("x" + infix + "_langID");
				if (elm && !ew.isHidden(elm) && !ew.hasValue(elm))
					return this.onError(elm, "<?php echo JsEncode(str_replace("%s", $user_edit->langID->caption(), $user_edit->langID->RequiredErrorMessage)) ?>");
			<?php } ?>
			<?php if ($user_edit->photo->Required) { ?>
				felm = this.getElements("x" + infix + "_photo");
				elm = this.getElements("fn_x" + infix + "_photo");
				if (felm && elm && !ew.hasValue(elm))
					return this.onError(felm, "<?php echo JsEncode(str_replace("%s", $user_edit->photo->caption(), $user_edit->photo->RequiredErrorMessage)) ?>");
			<?php } ?>
			<?php if ($user_edit->status->Required) { ?>
				elm = this.getElements("x" + infix + "_status");
				if (elm && !ew.isHidden(elm) && !ew.hasValue(elm))
					return this.onError(elm, "<?php echo JsEncode(str_replace("%s", $user_edit->status->caption(), $user_edit->status->RequiredErrorMessage)) ?>");
			<?php } ?>
			<?php if ($user_edit->markedfordeletion->Required) { ?>
				elm = this.getElements("x" + infix + "_markedfordeletion");
				if (elm && !ew.isHidden(elm) && !ew.hasValue(elm))
					return this.onError(elm, "<?php echo JsEncode(str_replace("%s", $user_edit->markedfordeletion->caption(), $user_edit->markedfordeletion->RequiredErrorMessage)) ?>");
			<?php } ?>
				elm = this.getElements("x" + infix + "_markedfordeletion");
				if (elm && !ew.checkDateDef(elm.value))
					return this.onError(elm, "<?php echo JsEncode($user_edit->markedfordeletion->errorMessage()) ?>");
			<?php if ($user_edit->userType->Required) { ?>
				elm = this.getElements("x" + infix + "_userType");
				if (elm && !ew.isHidden(elm) && !ew.hasValue(elm))
					return this.onError(elm, "<?php echo JsEncode(str_replace("%s", $user_edit->userType->caption(), $user_edit->userType->RequiredErrorMessage)) ?>");
			<?php } ?>
			<?php if ($user_edit->usersubtype->Required) { ?>
				elm = this.getElements("x" + infix + "_usersubtype");
				if (elm && !ew.isHidden(elm) && !ew.hasValue(elm))
					return this.onError(elm, "<?php echo JsEncode(str_replace("%s", $user_edit->usersubtype->caption(), $user_edit->usersubtype->RequiredErrorMessage)) ?>");
			<?php } ?>
			<?php if ($user_edit->accountID->Required) { ?>
				elm = this.getElements("x" + infix + "_accountID");
				if (elm && !ew.isHidden(elm) && !ew.hasValue(elm))
					return this.onError(elm, "<?php echo JsEncode(str_replace("%s", $user_edit->accountID->caption(), $user_edit->accountID->RequiredErrorMessage)) ?>");
			<?php } ?>
				elm = this.getElements("x" + infix + "_accountID");
				if (elm && !ew.checkInteger(elm.value))
					return this.onError(elm, "<?php echo JsEncode($user_edit->accountID->errorMessage()) ?>");
			<?php if ($user_edit->brokerid->Required) { ?>
				elm = this.getElements("x" + infix + "_brokerid");
				if (elm && !ew.isHidden(elm) && !ew.hasValue(elm))
					return this.onError(elm, "<?php echo JsEncode(str_replace("%s", $user_edit->brokerid->caption(), $user_edit->brokerid->RequiredErrorMessage)) ?>");
			<?php } ?>
				elm = this.getElements("x" + infix + "_brokerid");
				if (elm && !ew.checkInteger(elm.value))
					return this.onError(elm, "<?php echo JsEncode($user_edit->brokerid->errorMessage()) ?>");
			<?php if ($user_edit->parentuserid->Required) { ?>
				elm = this.getElements("x" + infix + "_parentuserid");
				if (elm && !ew.isHidden(elm) && !ew.hasValue(elm))
					return this.onError(elm, "<?php echo JsEncode(str_replace("%s", $user_edit->parentuserid->caption(), $user_edit->parentuserid->RequiredErrorMessage)) ?>");
			<?php } ?>
				elm = this.getElements("x" + infix + "_parentuserid");
				if (elm && !ew.checkInteger(elm.value))
					return this.onError(elm, "<?php echo JsEncode($user_edit->parentuserid->errorMessage()) ?>");
			<?php if ($user_edit->corporate->Required) { ?>
				elm = this.getElements("x" + infix + "_corporate");
				if (elm && !ew.isHidden(elm) && !ew.hasValue(elm))
					return this.onError(elm, "<?php echo JsEncode(str_replace("%s", $user_edit->corporate->caption(), $user_edit->corporate->RequiredErrorMessage)) ?>");
			<?php } ?>
			<?php if ($user_edit->profilestatus->Required) { ?>
				elm = this.getElements("x" + infix + "_profilestatus");
				if (elm && !ew.isHidden(elm) && !ew.hasValue(elm))
					return this.onError(elm, "<?php echo JsEncode(str_replace("%s", $user_edit->profilestatus->caption(), $user_edit->profilestatus->RequiredErrorMessage)) ?>");
			<?php } ?>
			<?php if ($user_edit->jumpappid->Required) { ?>
				elm = this.getElements("x" + infix + "_jumpappid");
				if (elm && !ew.isHidden(elm) && !ew.hasValue(elm))
					return this.onError(elm, "<?php echo JsEncode(str_replace("%s", $user_edit->jumpappid->caption(), $user_edit->jumpappid->RequiredErrorMessage)) ?>");
			<?php } ?>
				elm = this.getElements("x" + infix + "_jumpappid");
				if (elm && !ew.checkInteger(elm.value))
					return this.onError(elm, "<?php echo JsEncode($user_edit->jumpappid->errorMessage()) ?>");
			<?php if ($user_edit->dateofbirth->Required) { ?>
				elm = this.getElements("x" + infix + "_dateofbirth");
				if (elm && !ew.isHidden(elm) && !ew.hasValue(elm))
					return this.onError(elm, "<?php echo JsEncode(str_replace("%s", $user_edit->dateofbirth->caption(), $user_edit->dateofbirth->RequiredErrorMessage)) ?>");
			<?php } ?>
				elm = this.getElements("x" + infix + "_dateofbirth");
				if (elm && !ew.checkDateDef(elm.value))
					return this.onError(elm, "<?php echo JsEncode($user_edit->dateofbirth->errorMessage()) ?>");
			<?php if ($user_edit->gender->Required) { ?>
				elm = this.getElements("x" + infix + "_gender");
				if (elm && !ew.isHidden(elm) && !ew.hasValue(elm))
					return this.onError(elm, "<?php echo JsEncode(str_replace("%s", $user_edit->gender->caption(), $user_edit->gender->RequiredErrorMessage)) ?>");
			<?php } ?>
			<?php if ($user_edit->lastupdatedate->Required) { ?>
				elm = this.getElements("x" + infix + "_lastupdatedate");
				if (elm && !ew.isHidden(elm) && !ew.hasValue(elm))
					return this.onError(elm, "<?php echo JsEncode(str_replace("%s", $user_edit->lastupdatedate->caption(), $user_edit->lastupdatedate->RequiredErrorMessage)) ?>");
			<?php } ?>
				elm = this.getElements("x" + infix + "_lastupdatedate");
				if (elm && !ew.checkDateDef(elm.value))
					return this.onError(elm, "<?php echo JsEncode($user_edit->lastupdatedate->errorMessage()) ?>");
			<?php if ($user_edit->jumprequiredatlogin->Required) { ?>
				elm = this.getElements("x" + infix + "_jumprequiredatlogin");
				if (elm && !ew.isHidden(elm) && !ew.hasValue(elm))
					return this.onError(elm, "<?php echo JsEncode(str_replace("%s", $user_edit->jumprequiredatlogin->caption(), $user_edit->jumprequiredatlogin->RequiredErrorMessage)) ?>");
			<?php } ?>
			<?php if ($user_edit->ccbypass->Required) { ?>
				elm = this.getElements("x" + infix + "_ccbypass");
				if (elm && !ew.isHidden(elm) && !ew.hasValue(elm))
					return this.onError(elm, "<?php echo JsEncode(str_replace("%s", $user_edit->ccbypass->caption(), $user_edit->ccbypass->RequiredErrorMessage)) ?>");
			<?php } ?>
			<?php if ($user_edit->zip->Required) { ?>
				elm = this.getElements("x" + infix + "_zip");
				if (elm && !ew.isHidden(elm) && !ew.hasValue(elm))
					return this.onError(elm, "<?php echo JsEncode(str_replace("%s", $user_edit->zip->caption(), $user_edit->zip->RequiredErrorMessage)) ?>");
			<?php } ?>
			<?php if ($user_edit->other1->Required) { ?>
				elm = this.getElements("x" + infix + "_other1");
				if (elm && !ew.isHidden(elm) && !ew.hasValue(elm))
					return this.onError(elm, "<?php echo JsEncode(str_replace("%s", $user_edit->other1->caption(), $user_edit->other1->RequiredErrorMessage)) ?>");
			<?php } ?>
			<?php if ($user_edit->other2->Required) { ?>
				elm = this.getElements("x" + infix + "_other2");
				if (elm && !ew.isHidden(elm) && !ew.hasValue(elm))
					return this.onError(elm, "<?php echo JsEncode(str_replace("%s", $user_edit->other2->caption(), $user_edit->other2->RequiredErrorMessage)) ?>");
			<?php } ?>
			<?php if ($user_edit->other3->Required) { ?>
				elm = this.getElements("x" + infix + "_other3");
				if (elm && !ew.isHidden(elm) && !ew.hasValue(elm))
					return this.onError(elm, "<?php echo JsEncode(str_replace("%s", $user_edit->other3->caption(), $user_edit->other3->RequiredErrorMessage)) ?>");
			<?php } ?>
			<?php if ($user_edit->other4->Required) { ?>
				elm = this.getElements("x" + infix + "_other4");
				if (elm && !ew.isHidden(elm) && !ew.hasValue(elm))
					return this.onError(elm, "<?php echo JsEncode(str_replace("%s", $user_edit->other4->caption(), $user_edit->other4->RequiredErrorMessage)) ?>");
			<?php } ?>
			<?php if ($user_edit->other5->Required) { ?>
				elm = this.getElements("x" + infix + "_other5");
				if (elm && !ew.isHidden(elm) && !ew.hasValue(elm))
					return this.onError(elm, "<?php echo JsEncode(str_replace("%s", $user_edit->other5->caption(), $user_edit->other5->RequiredErrorMessage)) ?>");
			<?php } ?>
			<?php if ($user_edit->other6->Required) { ?>
				elm = this.getElements("x" + infix + "_other6");
				if (elm && !ew.isHidden(elm) && !ew.hasValue(elm))
					return this.onError(elm, "<?php echo JsEncode(str_replace("%s", $user_edit->other6->caption(), $user_edit->other6->RequiredErrorMessage)) ?>");
			<?php } ?>
			<?php if ($user_edit->mincashamount->Required) { ?>
				elm = this.getElements("x" + infix + "_mincashamount");
				if (elm && !ew.isHidden(elm) && !ew.hasValue(elm))
					return this.onError(elm, "<?php echo JsEncode(str_replace("%s", $user_edit->mincashamount->caption(), $user_edit->mincashamount->RequiredErrorMessage)) ?>");
			<?php } ?>
				elm = this.getElements("x" + infix + "_mincashamount");
				if (elm && !ew.checkNumber(elm.value))
					return this.onError(elm, "<?php echo JsEncode($user_edit->mincashamount->errorMessage()) ?>");
			<?php if ($user_edit->maxcashamount->Required) { ?>
				elm = this.getElements("x" + infix + "_maxcashamount");
				if (elm && !ew.isHidden(elm) && !ew.hasValue(elm))
					return this.onError(elm, "<?php echo JsEncode(str_replace("%s", $user_edit->maxcashamount->caption(), $user_edit->maxcashamount->RequiredErrorMessage)) ?>");
			<?php } ?>
				elm = this.getElements("x" + infix + "_maxcashamount");
				if (elm && !ew.checkNumber(elm.value))
					return this.onError(elm, "<?php echo JsEncode($user_edit->maxcashamount->errorMessage()) ?>");
			<?php if ($user_edit->maxtransferinamount->Required) { ?>
				elm = this.getElements("x" + infix + "_maxtransferinamount");
				if (elm && !ew.isHidden(elm) && !ew.hasValue(elm))
					return this.onError(elm, "<?php echo JsEncode(str_replace("%s", $user_edit->maxtransferinamount->caption(), $user_edit->maxtransferinamount->RequiredErrorMessage)) ?>");
			<?php } ?>
				elm = this.getElements("x" + infix + "_maxtransferinamount");
				if (elm && !ew.checkNumber(elm.value))
					return this.onError(elm, "<?php echo JsEncode($user_edit->maxtransferinamount->errorMessage()) ?>");
			<?php if ($user_edit->maxtransferoutamount->Required) { ?>
				elm = this.getElements("x" + infix + "_maxtransferoutamount");
				if (elm && !ew.isHidden(elm) && !ew.hasValue(elm))
					return this.onError(elm, "<?php echo JsEncode(str_replace("%s", $user_edit->maxtransferoutamount->caption(), $user_edit->maxtransferoutamount->RequiredErrorMessage)) ?>");
			<?php } ?>
				elm = this.getElements("x" + infix + "_maxtransferoutamount");
				if (elm && !ew.checkNumber(elm.value))
					return this.onError(elm, "<?php echo JsEncode($user_edit->maxtransferoutamount->errorMessage()) ?>");
			<?php if ($user_edit->legalid->Required) { ?>
				elm = this.getElements("x" + infix + "_legalid");
				if (elm && !ew.isHidden(elm) && !ew.hasValue(elm))
					return this.onError(elm, "<?php echo JsEncode(str_replace("%s", $user_edit->legalid->caption(), $user_edit->legalid->RequiredErrorMessage)) ?>");
			<?php } ?>
				elm = this.getElements("x" + infix + "_legalid");
				if (elm && !ew.checkInteger(elm.value))
					return this.onError(elm, "<?php echo JsEncode($user_edit->legalid->errorMessage()) ?>");
			<?php if ($user_edit->userpiview->Required) { ?>
				elm = this.getElements("x" + infix + "_userpiview");
				if (elm && !ew.isHidden(elm) && !ew.hasValue(elm))
					return this.onError(elm, "<?php echo JsEncode(str_replace("%s", $user_edit->userpiview->caption(), $user_edit->userpiview->RequiredErrorMessage)) ?>");
			<?php } ?>
			<?php if ($user_edit->lastmsgid->Required) { ?>
				elm = this.getElements("x" + infix + "_lastmsgid");
				if (elm && !ew.isHidden(elm) && !ew.hasValue(elm))
					return this.onError(elm, "<?php echo JsEncode(str_replace("%s", $user_edit->lastmsgid->caption(), $user_edit->lastmsgid->RequiredErrorMessage)) ?>");
			<?php } ?>
				elm = this.getElements("x" + infix + "_lastmsgid");
				if (elm && !ew.checkInteger(elm.value))
					return this.onError(elm, "<?php echo JsEncode($user_edit->lastmsgid->errorMessage()) ?>");
			<?php if ($user_edit->otprequiredforphysicalcards->Required) { ?>
				elm = this.getElements("x" + infix + "_otprequiredforphysicalcards");
				if (elm && !ew.isHidden(elm) && !ew.hasValue(elm))
					return this.onError(elm, "<?php echo JsEncode(str_replace("%s", $user_edit->otprequiredforphysicalcards->caption(), $user_edit->otprequiredforphysicalcards->RequiredErrorMessage)) ?>");
			<?php } ?>
				elm = this.getElements("x" + infix + "_otprequiredforphysicalcards");
				if (elm && !ew.checkInteger(elm.value))
					return this.onError(elm, "<?php echo JsEncode($user_edit->otprequiredforphysicalcards->errorMessage()) ?>");
			<?php if ($user_edit->otpvaliduntil->Required) { ?>
				elm = this.getElements("x" + infix + "_otpvaliduntil");
				if (elm && !ew.isHidden(elm) && !ew.hasValue(elm))
					return this.onError(elm, "<?php echo JsEncode(str_replace("%s", $user_edit->otpvaliduntil->caption(), $user_edit->otpvaliduntil->RequiredErrorMessage)) ?>");
			<?php } ?>
				elm = this.getElements("x" + infix + "_otpvaliduntil");
				if (elm && !ew.checkDateDef(elm.value))
					return this.onError(elm, "<?php echo JsEncode($user_edit->otpvaliduntil->errorMessage()) ?>");
			<?php if ($user_edit->nationalitycountry->Required) { ?>
				elm = this.getElements("x" + infix + "_nationalitycountry");
				if (elm && !ew.isHidden(elm) && !ew.hasValue(elm))
					return this.onError(elm, "<?php echo JsEncode(str_replace("%s", $user_edit->nationalitycountry->caption(), $user_edit->nationalitycountry->RequiredErrorMessage)) ?>");
			<?php } ?>
			<?php if ($user_edit->classification->Required) { ?>
				elm = this.getElements("x" + infix + "_classification");
				if (elm && !ew.isHidden(elm) && !ew.hasValue(elm))
					return this.onError(elm, "<?php echo JsEncode(str_replace("%s", $user_edit->classification->caption(), $user_edit->classification->RequiredErrorMessage)) ?>");
			<?php } ?>
			<?php if ($user_edit->occupation->Required) { ?>
				elm = this.getElements("x" + infix + "_occupation");
				if (elm && !ew.isHidden(elm) && !ew.hasValue(elm))
					return this.onError(elm, "<?php echo JsEncode(str_replace("%s", $user_edit->occupation->caption(), $user_edit->occupation->RequiredErrorMessage)) ?>");
			<?php } ?>
			<?php if ($user_edit->sourceofincome->Required) { ?>
				elm = this.getElements("x" + infix + "_sourceofincome");
				if (elm && !ew.isHidden(elm) && !ew.hasValue(elm))
					return this.onError(elm, "<?php echo JsEncode(str_replace("%s", $user_edit->sourceofincome->caption(), $user_edit->sourceofincome->RequiredErrorMessage)) ?>");
			<?php } ?>
			<?php if ($user_edit->accountopeningdate->Required) { ?>
				elm = this.getElements("x" + infix + "_accountopeningdate");
				if (elm && !ew.isHidden(elm) && !ew.hasValue(elm))
					return this.onError(elm, "<?php echo JsEncode(str_replace("%s", $user_edit->accountopeningdate->caption(), $user_edit->accountopeningdate->RequiredErrorMessage)) ?>");
			<?php } ?>
				elm = this.getElements("x" + infix + "_accountopeningdate");
				if (elm && !ew.checkDateDef(elm.value))
					return this.onError(elm, "<?php echo JsEncode($user_edit->accountopeningdate->errorMessage()) ?>");
			<?php if ($user_edit->extendedfields->Required) { ?>
				elm = this.getElements("x" + infix + "_extendedfields");
				if (elm && !ew.isHidden(elm) && !ew.hasValue(elm))
					return this.onError(elm, "<?php echo JsEncode(str_replace("%s", $user_edit->extendedfields->caption(), $user_edit->extendedfields->RequiredErrorMessage)) ?>");
			<?php } ?>
			<?php if ($user_edit->lastprofilestatuschangedate->Required) { ?>
				elm = this.getElements("x" + infix + "_lastprofilestatuschangedate");
				if (elm && !ew.isHidden(elm) && !ew.hasValue(elm))
					return this.onError(elm, "<?php echo JsEncode(str_replace("%s", $user_edit->lastprofilestatuschangedate->caption(), $user_edit->lastprofilestatuschangedate->RequiredErrorMessage)) ?>");
			<?php } ?>
				elm = this.getElements("x" + infix + "_lastprofilestatuschangedate");
				if (elm && !ew.checkDateDef(elm.value))
					return this.onError(elm, "<?php echo JsEncode($user_edit->lastprofilestatuschangedate->errorMessage()) ?>");

				// Call Form_CustomValidate event
				if (!this.Form_CustomValidate(fobj))
					return false;
		}

		// Process detail forms
		var dfs = $fobj.find("input[name='detailpage']").get();
		for (var i = 0; i < dfs.length; i++) {
			var df = dfs[i], val = df.value;
			if (val && ew.forms[val])
				if (!ew.forms[val].validate())
					return false;
		}
		return true;
	}

	// Form_CustomValidate
	fuseredit.Form_CustomValidate = function(fobj) { // DO NOT CHANGE THIS LINE!

		// Your custom validation code here, return false if invalid.
		return true;
	}

	// Use JavaScript validation or not
	fuseredit.validateRequired = <?php echo Config("CLIENT_VALIDATE") ? "true" : "false" ?>;

	// Multi-Page
	fuseredit.multiPage = new ew.MultiPage("fuseredit");

	// Dynamic selection lists
	fuseredit.lists["x_passwordRequireChange"] = <?php echo $user_edit->passwordRequireChange->Lookup->toClientList($user_edit) ?>;
	fuseredit.lists["x_passwordRequireChange"].options = <?php echo JsonEncode($user_edit->passwordRequireChange->lookupOptions()) ?>;
	fuseredit.lists["x_timezoneid"] = <?php echo $user_edit->timezoneid->Lookup->toClientList($user_edit) ?>;
	fuseredit.lists["x_timezoneid"].options = <?php echo JsonEncode($user_edit->timezoneid->lookupOptions()) ?>;
	fuseredit.lists["x_telephoneverified"] = <?php echo $user_edit->telephoneverified->Lookup->toClientList($user_edit) ?>;
	fuseredit.lists["x_telephoneverified"].options = <?php echo JsonEncode($user_edit->telephoneverified->lookupOptions()) ?>;
	fuseredit.lists["x_telephonereceivemessage"] = <?php echo $user_edit->telephonereceivemessage->Lookup->toClientList($user_edit) ?>;
	fuseredit.lists["x_telephonereceivemessage"].options = <?php echo JsonEncode($user_edit->telephonereceivemessage->lookupOptions()) ?>;
	fuseredit.lists["x_countryid"] = <?php echo $user_edit->countryid->Lookup->toClientList($user_edit) ?>;
	fuseredit.lists["x_countryid"].options = <?php echo JsonEncode($user_edit->countryid->lookupOptions()) ?>;
	fuseredit.lists["x_stateid"] = <?php echo $user_edit->stateid->Lookup->toClientList($user_edit) ?>;
	fuseredit.lists["x_stateid"].options = <?php echo JsonEncode($user_edit->stateid->lookupOptions()) ?>;
	fuseredit.lists["x_defaultcurrency"] = <?php echo $user_edit->defaultcurrency->Lookup->toClientList($user_edit) ?>;
	fuseredit.lists["x_defaultcurrency"].options = <?php echo JsonEncode($user_edit->defaultcurrency->lookupOptions()) ?>;
	fuseredit.lists["x_langID"] = <?php echo $user_edit->langID->Lookup->toClientList($user_edit) ?>;
	fuseredit.lists["x_langID"].options = <?php echo JsonEncode($user_edit->langID->lookupOptions()) ?>;
	fuseredit.lists["x_status"] = <?php echo $user_edit->status->Lookup->toClientList($user_edit) ?>;
	fuseredit.lists["x_status"].options = <?php echo JsonEncode($user_edit->status->lookupOptions()) ?>;
	fuseredit.lists["x_userType"] = <?php echo $user_edit->userType->Lookup->toClientList($user_edit) ?>;
	fuseredit.lists["x_userType"].options = <?php echo JsonEncode($user_edit->userType->lookupOptions()) ?>;
	fuseredit.lists["x_usersubtype"] = <?php echo $user_edit->usersubtype->Lookup->toClientList($user_edit) ?>;
	fuseredit.lists["x_usersubtype"].options = <?php echo JsonEncode($user_edit->usersubtype->lookupOptions()) ?>;
	fuseredit.lists["x_corporate"] = <?php echo $user_edit->corporate->Lookup->toClientList($user_edit) ?>;
	fuseredit.lists["x_corporate"].options = <?php echo JsonEncode($user_edit->corporate->lookupOptions()) ?>;
	fuseredit.lists["x_profilestatus"] = <?php echo $user_edit->profilestatus->Lookup->toClientList($user_edit) ?>;
	fuseredit.lists["x_profilestatus"].options = <?php echo JsonEncode($user_edit->profilestatus->lookupOptions()) ?>;
	fuseredit.lists["x_gender"] = <?php echo $user_edit->gender->Lookup->toClientList($user_edit) ?>;
	fuseredit.lists["x_gender"].options = <?php echo JsonEncode($user_edit->gender->lookupOptions()) ?>;
	fuseredit.lists["x_jumprequiredatlogin"] = <?php echo $user_edit->jumprequiredatlogin->Lookup->toClientList($user_edit) ?>;
	fuseredit.lists["x_jumprequiredatlogin"].options = <?php echo JsonEncode($user_edit->jumprequiredatlogin->lookupOptions()) ?>;
	fuseredit.lists["x_ccbypass"] = <?php echo $user_edit->ccbypass->Lookup->toClientList($user_edit) ?>;
	fuseredit.lists["x_ccbypass"].options = <?php echo JsonEncode($user_edit->ccbypass->lookupOptions()) ?>;
	fuseredit.lists["x_userpiview"] = <?php echo $user_edit->userpiview->Lookup->toClientList($user_edit) ?>;
	fuseredit.lists["x_userpiview"].options = <?php echo JsonEncode($user_edit->userpiview->lookupOptions()) ?>;
	fuseredit.lists["x_nationalitycountry"] = <?php echo $user_edit->nationalitycountry->Lookup->toClientList($user_edit) ?>;
	fuseredit.lists["x_nationalitycountry"].options = <?php echo JsonEncode($user_edit->nationalitycountry->lookupOptions()) ?>;
	fuseredit.lists["x_classification"] = <?php echo $user_edit->classification->Lookup->toClientList($user_edit) ?>;
	fuseredit.lists["x_classification"].options = <?php echo JsonEncode($user_edit->classification->lookupOptions()) ?>;
	fuseredit.lists["x_occupation"] = <?php echo $user_edit->occupation->Lookup->toClientList($user_edit) ?>;
	fuseredit.lists["x_occupation"].options = <?php echo JsonEncode($user_edit->occupation->lookupOptions()) ?>;
	fuseredit.autoSuggests["x_occupation"] = <?php echo json_encode(["data" => "ajax=autosuggest"]) ?>;
	fuseredit.lists["x_sourceofincome"] = <?php echo $user_edit->sourceofincome->Lookup->toClientList($user_edit) ?>;
	fuseredit.lists["x_sourceofincome"].options = <?php echo JsonEncode($user_edit->sourceofincome->lookupOptions()) ?>;
	loadjs.done("fuseredit");
});
</script>
<script>
loadjs.ready("head", function() {

	// Client script
	// Write your client script here, no need to add script tags.

});
</script>
<?php $user_edit->showPageHeader(); ?>
<?php
$user_edit->showMessage();
?>
<form name="fuseredit" id="fuseredit" class="<?php echo $user_edit->FormClassName ?>" action="<?php echo CurrentPageName() ?>" method="post">
<?php if ($Page->CheckToken) { ?>
<input type="hidden" name="<?php echo Config("TOKEN_NAME") ?>" value="<?php echo $Page->Token ?>">
<?php } ?>
<input type="hidden" name="t" value="user">
<input type="hidden" name="action" id="action" value="update">
<input type="hidden" name="modal" value="<?php echo (int)$user_edit->IsModal ?>">
<div class="ew-multi-page"><!-- multi-page -->
<div class="ew-nav-tabs" id="user_edit"><!-- multi-page tabs -->
	<ul class="<?php echo $user_edit->MultiPages->navStyle() ?>">
		<li class="nav-item"><a class="nav-link<?php echo $user_edit->MultiPages->pageStyle(1) ?>" href="#tab_user1" data-toggle="tab"><?php echo $user->pageCaption(1) ?></a></li>
		<li class="nav-item"><a class="nav-link<?php echo $user_edit->MultiPages->pageStyle(2) ?>" href="#tab_user2" data-toggle="tab"><?php echo $user->pageCaption(2) ?></a></li>
		<li class="nav-item"><a class="nav-link<?php echo $user_edit->MultiPages->pageStyle(3) ?>" href="#tab_user3" data-toggle="tab"><?php echo $user->pageCaption(3) ?></a></li>
		<li class="nav-item"><a class="nav-link<?php echo $user_edit->MultiPages->pageStyle(4) ?>" href="#tab_user4" data-toggle="tab"><?php echo $user->pageCaption(4) ?></a></li>
	</ul>
	<div class="tab-content"><!-- multi-page tabs .tab-content -->
		<div class="tab-pane<?php echo $user_edit->MultiPages->pageStyle(1) ?>" id="tab_user1"><!-- multi-page .tab-pane -->
<div class="ew-edit-div"><!-- page* -->
<?php if ($user_edit->id->Visible) { // id ?>
	<div id="r_id" class="form-group row">
		<label id="elh_user_id" for="x_id" class="<?php echo $user_edit->LeftColumnClass ?>"><?php echo $user_edit->id->caption() ?><?php echo $user_edit->id->Required ? $Language->phrase("FieldRequiredIndicator") : "" ?></label>
		<div class="<?php echo $user_edit->RightColumnClass ?>"><div <?php echo $user_edit->id->cellAttributes() ?>>
<input type="text" data-table="user" data-field="x_id" data-page="1" name="x_id" id="x_id" size="30" placeholder="<?php echo HtmlEncode($user_edit->id->getPlaceHolder()) ?>" value="<?php echo $user_edit->id->EditValue ?>"<?php echo $user_edit->id->editAttributes() ?>>
<input type="hidden" data-table="user" data-field="x_id" data-page="1" name="o_id" id="o_id" value="<?php echo HtmlEncode($user_edit->id->OldValue != null ? $user_edit->id->OldValue : $user_edit->id->CurrentValue) ?>">
<?php echo $user_edit->id->CustomMsg ?></div></div>
	</div>
<?php } ?>
<?php if ($user_edit->firstName->Visible) { // firstName ?>
	<div id="r_firstName" class="form-group row">
		<label id="elh_user_firstName" for="x_firstName" class="<?php echo $user_edit->LeftColumnClass ?>"><?php echo $user_edit->firstName->caption() ?><?php echo $user_edit->firstName->Required ? $Language->phrase("FieldRequiredIndicator") : "" ?></label>
		<div class="<?php echo $user_edit->RightColumnClass ?>"><div <?php echo $user_edit->firstName->cellAttributes() ?>>
<span id="el_user_firstName">
<input type="text" data-table="user" data-field="x_firstName" data-page="1" name="x_firstName" id="x_firstName" size="30" maxlength="60" placeholder="<?php echo HtmlEncode($user_edit->firstName->getPlaceHolder()) ?>" value="<?php echo $user_edit->firstName->EditValue ?>"<?php echo $user_edit->firstName->editAttributes() ?>>
</span>
<?php echo $user_edit->firstName->CustomMsg ?></div></div>
	</div>
<?php } ?>
<?php if ($user_edit->lastName->Visible) { // lastName ?>
	<div id="r_lastName" class="form-group row">
		<label id="elh_user_lastName" for="x_lastName" class="<?php echo $user_edit->LeftColumnClass ?>"><?php echo $user_edit->lastName->caption() ?><?php echo $user_edit->lastName->Required ? $Language->phrase("FieldRequiredIndicator") : "" ?></label>
		<div class="<?php echo $user_edit->RightColumnClass ?>"><div <?php echo $user_edit->lastName->cellAttributes() ?>>
<span id="el_user_lastName">
<input type="text" data-table="user" data-field="x_lastName" data-page="1" name="x_lastName" id="x_lastName" size="30" maxlength="60" placeholder="<?php echo HtmlEncode($user_edit->lastName->getPlaceHolder()) ?>" value="<?php echo $user_edit->lastName->EditValue ?>"<?php echo $user_edit->lastName->editAttributes() ?>>
</span>
<?php echo $user_edit->lastName->CustomMsg ?></div></div>
	</div>
<?php } ?>
<?php if ($user_edit->otherNames->Visible) { // otherNames ?>
	<div id="r_otherNames" class="form-group row">
		<label id="elh_user_otherNames" for="x_otherNames" class="<?php echo $user_edit->LeftColumnClass ?>"><?php echo $user_edit->otherNames->caption() ?><?php echo $user_edit->otherNames->Required ? $Language->phrase("FieldRequiredIndicator") : "" ?></label>
		<div class="<?php echo $user_edit->RightColumnClass ?>"><div <?php echo $user_edit->otherNames->cellAttributes() ?>>
<span id="el_user_otherNames">
<input type="text" data-table="user" data-field="x_otherNames" data-page="1" name="x_otherNames" id="x_otherNames" size="30" maxlength="60" placeholder="<?php echo HtmlEncode($user_edit->otherNames->getPlaceHolder()) ?>" value="<?php echo $user_edit->otherNames->EditValue ?>"<?php echo $user_edit->otherNames->editAttributes() ?>>
</span>
<?php echo $user_edit->otherNames->CustomMsg ?></div></div>
	</div>
<?php } ?>
<?php if ($user_edit->passwordRequireChange->Visible) { // passwordRequireChange ?>
	<div id="r_passwordRequireChange" class="form-group row">
		<label id="elh_user_passwordRequireChange" class="<?php echo $user_edit->LeftColumnClass ?>"><?php echo $user_edit->passwordRequireChange->caption() ?><?php echo $user_edit->passwordRequireChange->Required ? $Language->phrase("FieldRequiredIndicator") : "" ?></label>
		<div class="<?php echo $user_edit->RightColumnClass ?>"><div <?php echo $user_edit->passwordRequireChange->cellAttributes() ?>>
<span id="el_user_passwordRequireChange">
<div id="tp_x_passwordRequireChange" class="ew-template"><input type="radio" class="custom-control-input" data-table="user" data-field="x_passwordRequireChange" data-page="1" data-value-separator="<?php echo $user_edit->passwordRequireChange->displayValueSeparatorAttribute() ?>" name="x_passwordRequireChange" id="x_passwordRequireChange" value="{value}"<?php echo $user_edit->passwordRequireChange->editAttributes() ?>></div>
<div id="dsl_x_passwordRequireChange" data-repeatcolumn="5" class="ew-item-list d-none"><div>
<?php echo $user_edit->passwordRequireChange->radioButtonListHtml(FALSE, "x_passwordRequireChange", 1) ?>
</div></div>
<?php echo $user_edit->passwordRequireChange->Lookup->getParamTag($user_edit, "p_x_passwordRequireChange") ?>
</span>
<?php echo $user_edit->passwordRequireChange->CustomMsg ?></div></div>
	</div>
<?php } ?>
<?php if ($user_edit->dateAdded->Visible) { // dateAdded ?>
	<div id="r_dateAdded" class="form-group row">
		<label id="elh_user_dateAdded" for="x_dateAdded" class="<?php echo $user_edit->LeftColumnClass ?>"><?php echo $user_edit->dateAdded->caption() ?><?php echo $user_edit->dateAdded->Required ? $Language->phrase("FieldRequiredIndicator") : "" ?></label>
		<div class="<?php echo $user_edit->RightColumnClass ?>"><div <?php echo $user_edit->dateAdded->cellAttributes() ?>>
<span id="el_user_dateAdded">
<input type="text" data-table="user" data-field="x_dateAdded" data-page="1" data-format="1" name="x_dateAdded" id="x_dateAdded" placeholder="<?php echo HtmlEncode($user_edit->dateAdded->getPlaceHolder()) ?>" value="<?php echo $user_edit->dateAdded->EditValue ?>"<?php echo $user_edit->dateAdded->editAttributes() ?>>
<?php if (!$user_edit->dateAdded->ReadOnly && !$user_edit->dateAdded->Disabled && !isset($user_edit->dateAdded->EditAttrs["readonly"]) && !isset($user_edit->dateAdded->EditAttrs["disabled"])) { ?>
<script>
loadjs.ready(["fuseredit", "datetimepicker"], function() {
	ew.createDateTimePicker("fuseredit", "x_dateAdded", {"ignoreReadonly":true,"useCurrent":false,"format":1});
});
</script>
<?php } ?>
</span>
<?php echo $user_edit->dateAdded->CustomMsg ?></div></div>
	</div>
<?php } ?>
<?php if ($user_edit->timezoneid->Visible) { // timezoneid ?>
	<div id="r_timezoneid" class="form-group row">
		<label id="elh_user_timezoneid" for="x_timezoneid" class="<?php echo $user_edit->LeftColumnClass ?>"><?php echo $user_edit->timezoneid->caption() ?><?php echo $user_edit->timezoneid->Required ? $Language->phrase("FieldRequiredIndicator") : "" ?></label>
		<div class="<?php echo $user_edit->RightColumnClass ?>"><div <?php echo $user_edit->timezoneid->cellAttributes() ?>>
<span id="el_user_timezoneid">
<div class="input-group">
	<select class="custom-select ew-custom-select" data-table="user" data-field="x_timezoneid" data-page="1" data-value-separator="<?php echo $user_edit->timezoneid->displayValueSeparatorAttribute() ?>" id="x_timezoneid" name="x_timezoneid"<?php echo $user_edit->timezoneid->editAttributes() ?>>
			<?php echo $user_edit->timezoneid->selectOptionListHtml("x_timezoneid") ?>
		</select>
</div>
<?php echo $user_edit->timezoneid->Lookup->getParamTag($user_edit, "p_x_timezoneid") ?>
</span>
<?php echo $user_edit->timezoneid->CustomMsg ?></div></div>
	</div>
<?php } ?>
<?php if ($user_edit->contactPhoneNo->Visible) { // contactPhoneNo ?>
	<div id="r_contactPhoneNo" class="form-group row">
		<label id="elh_user_contactPhoneNo" for="x_contactPhoneNo" class="<?php echo $user_edit->LeftColumnClass ?>"><?php echo $user_edit->contactPhoneNo->caption() ?><?php echo $user_edit->contactPhoneNo->Required ? $Language->phrase("FieldRequiredIndicator") : "" ?></label>
		<div class="<?php echo $user_edit->RightColumnClass ?>"><div <?php echo $user_edit->contactPhoneNo->cellAttributes() ?>>
<span id="el_user_contactPhoneNo">
<input type="text" data-table="user" data-field="x_contactPhoneNo" data-page="1" name="x_contactPhoneNo" id="x_contactPhoneNo" size="30" maxlength="20" placeholder="<?php echo HtmlEncode($user_edit->contactPhoneNo->getPlaceHolder()) ?>" value="<?php echo $user_edit->contactPhoneNo->EditValue ?>"<?php echo $user_edit->contactPhoneNo->editAttributes() ?>>
</span>
<?php echo $user_edit->contactPhoneNo->CustomMsg ?></div></div>
	</div>
<?php } ?>
<?php if ($user_edit->telephoneno->Visible) { // telephoneno ?>
	<div id="r_telephoneno" class="form-group row">
		<label id="elh_user_telephoneno" for="x_telephoneno" class="<?php echo $user_edit->LeftColumnClass ?>"><?php echo $user_edit->telephoneno->caption() ?><?php echo $user_edit->telephoneno->Required ? $Language->phrase("FieldRequiredIndicator") : "" ?></label>
		<div class="<?php echo $user_edit->RightColumnClass ?>"><div <?php echo $user_edit->telephoneno->cellAttributes() ?>>
<span id="el_user_telephoneno">
<input type="text" data-table="user" data-field="x_telephoneno" data-page="1" name="x_telephoneno" id="x_telephoneno" size="30" maxlength="20" placeholder="<?php echo HtmlEncode($user_edit->telephoneno->getPlaceHolder()) ?>" value="<?php echo $user_edit->telephoneno->EditValue ?>"<?php echo $user_edit->telephoneno->editAttributes() ?>>
</span>
<?php echo $user_edit->telephoneno->CustomMsg ?></div></div>
	</div>
<?php } ?>
<?php if ($user_edit->telephoneverified->Visible) { // telephoneverified ?>
	<div id="r_telephoneverified" class="form-group row">
		<label id="elh_user_telephoneverified" class="<?php echo $user_edit->LeftColumnClass ?>"><?php echo $user_edit->telephoneverified->caption() ?><?php echo $user_edit->telephoneverified->Required ? $Language->phrase("FieldRequiredIndicator") : "" ?></label>
		<div class="<?php echo $user_edit->RightColumnClass ?>"><div <?php echo $user_edit->telephoneverified->cellAttributes() ?>>
<span id="el_user_telephoneverified">
<div id="tp_x_telephoneverified" class="ew-template"><input type="radio" class="custom-control-input" data-table="user" data-field="x_telephoneverified" data-page="1" data-value-separator="<?php echo $user_edit->telephoneverified->displayValueSeparatorAttribute() ?>" name="x_telephoneverified" id="x_telephoneverified" value="{value}"<?php echo $user_edit->telephoneverified->editAttributes() ?>></div>
<div id="dsl_x_telephoneverified" data-repeatcolumn="5" class="ew-item-list d-none"><div>
<?php echo $user_edit->telephoneverified->radioButtonListHtml(FALSE, "x_telephoneverified", 1) ?>
</div></div>
<?php echo $user_edit->telephoneverified->Lookup->getParamTag($user_edit, "p_x_telephoneverified") ?>
</span>
<?php echo $user_edit->telephoneverified->CustomMsg ?></div></div>
	</div>
<?php } ?>
<?php if ($user_edit->address1->Visible) { // address1 ?>
	<div id="r_address1" class="form-group row">
		<label id="elh_user_address1" for="x_address1" class="<?php echo $user_edit->LeftColumnClass ?>"><?php echo $user_edit->address1->caption() ?><?php echo $user_edit->address1->Required ? $Language->phrase("FieldRequiredIndicator") : "" ?></label>
		<div class="<?php echo $user_edit->RightColumnClass ?>"><div <?php echo $user_edit->address1->cellAttributes() ?>>
<span id="el_user_address1">
<input type="text" data-table="user" data-field="x_address1" data-page="1" name="x_address1" id="x_address1" size="30" maxlength="60" placeholder="<?php echo HtmlEncode($user_edit->address1->getPlaceHolder()) ?>" value="<?php echo $user_edit->address1->EditValue ?>"<?php echo $user_edit->address1->editAttributes() ?>>
</span>
<?php echo $user_edit->address1->CustomMsg ?></div></div>
	</div>
<?php } ?>
<?php if ($user_edit->address2->Visible) { // address2 ?>
	<div id="r_address2" class="form-group row">
		<label id="elh_user_address2" for="x_address2" class="<?php echo $user_edit->LeftColumnClass ?>"><?php echo $user_edit->address2->caption() ?><?php echo $user_edit->address2->Required ? $Language->phrase("FieldRequiredIndicator") : "" ?></label>
		<div class="<?php echo $user_edit->RightColumnClass ?>"><div <?php echo $user_edit->address2->cellAttributes() ?>>
<span id="el_user_address2">
<input type="text" data-table="user" data-field="x_address2" data-page="1" name="x_address2" id="x_address2" size="30" maxlength="60" placeholder="<?php echo HtmlEncode($user_edit->address2->getPlaceHolder()) ?>" value="<?php echo $user_edit->address2->EditValue ?>"<?php echo $user_edit->address2->editAttributes() ?>>
</span>
<?php echo $user_edit->address2->CustomMsg ?></div></div>
	</div>
<?php } ?>
<?php if ($user_edit->cityname->Visible) { // cityname ?>
	<div id="r_cityname" class="form-group row">
		<label id="elh_user_cityname" for="x_cityname" class="<?php echo $user_edit->LeftColumnClass ?>"><?php echo $user_edit->cityname->caption() ?><?php echo $user_edit->cityname->Required ? $Language->phrase("FieldRequiredIndicator") : "" ?></label>
		<div class="<?php echo $user_edit->RightColumnClass ?>"><div <?php echo $user_edit->cityname->cellAttributes() ?>>
<span id="el_user_cityname">
<input type="text" data-table="user" data-field="x_cityname" data-page="1" name="x_cityname" id="x_cityname" size="30" maxlength="60" placeholder="<?php echo HtmlEncode($user_edit->cityname->getPlaceHolder()) ?>" value="<?php echo $user_edit->cityname->EditValue ?>"<?php echo $user_edit->cityname->editAttributes() ?>>
</span>
<?php echo $user_edit->cityname->CustomMsg ?></div></div>
	</div>
<?php } ?>
<?php if ($user_edit->countryid->Visible) { // countryid ?>
	<div id="r_countryid" class="form-group row">
		<label id="elh_user_countryid" for="x_countryid" class="<?php echo $user_edit->LeftColumnClass ?>"><?php echo $user_edit->countryid->caption() ?><?php echo $user_edit->countryid->Required ? $Language->phrase("FieldRequiredIndicator") : "" ?></label>
		<div class="<?php echo $user_edit->RightColumnClass ?>"><div <?php echo $user_edit->countryid->cellAttributes() ?>>
<span id="el_user_countryid">
<?php $user_edit->countryid->EditAttrs->prepend("onchange", "ew.updateOptions.call(this);"); ?>
<div class="input-group">
	<select class="custom-select ew-custom-select" data-table="user" data-field="x_countryid" data-page="1" data-value-separator="<?php echo $user_edit->countryid->displayValueSeparatorAttribute() ?>" id="x_countryid" name="x_countryid"<?php echo $user_edit->countryid->editAttributes() ?>>
			<?php echo $user_edit->countryid->selectOptionListHtml("x_countryid") ?>
		</select>
</div>
<?php echo $user_edit->countryid->Lookup->getParamTag($user_edit, "p_x_countryid") ?>
</span>
<?php echo $user_edit->countryid->CustomMsg ?></div></div>
	</div>
<?php } ?>
<?php if ($user_edit->stateid->Visible) { // stateid ?>
	<div id="r_stateid" class="form-group row">
		<label id="elh_user_stateid" for="x_stateid" class="<?php echo $user_edit->LeftColumnClass ?>"><?php echo $user_edit->stateid->caption() ?><?php echo $user_edit->stateid->Required ? $Language->phrase("FieldRequiredIndicator") : "" ?></label>
		<div class="<?php echo $user_edit->RightColumnClass ?>"><div <?php echo $user_edit->stateid->cellAttributes() ?>>
<span id="el_user_stateid">
<div class="input-group">
	<select class="custom-select ew-custom-select" data-table="user" data-field="x_stateid" data-page="1" data-value-separator="<?php echo $user_edit->stateid->displayValueSeparatorAttribute() ?>" id="x_stateid" name="x_stateid"<?php echo $user_edit->stateid->editAttributes() ?>>
			<?php echo $user_edit->stateid->selectOptionListHtml("x_stateid") ?>
		</select>
</div>
<?php echo $user_edit->stateid->Lookup->getParamTag($user_edit, "p_x_stateid") ?>
</span>
<?php echo $user_edit->stateid->CustomMsg ?></div></div>
	</div>
<?php } ?>
<?php if ($user_edit->defaultcurrency->Visible) { // defaultcurrency ?>
	<div id="r_defaultcurrency" class="form-group row">
		<label id="elh_user_defaultcurrency" for="x_defaultcurrency" class="<?php echo $user_edit->LeftColumnClass ?>"><?php echo $user_edit->defaultcurrency->caption() ?><?php echo $user_edit->defaultcurrency->Required ? $Language->phrase("FieldRequiredIndicator") : "" ?></label>
		<div class="<?php echo $user_edit->RightColumnClass ?>"><div <?php echo $user_edit->defaultcurrency->cellAttributes() ?>>
<span id="el_user_defaultcurrency">
<div class="input-group">
	<select class="custom-select ew-custom-select" data-table="user" data-field="x_defaultcurrency" data-page="1" data-value-separator="<?php echo $user_edit->defaultcurrency->displayValueSeparatorAttribute() ?>" id="x_defaultcurrency" name="x_defaultcurrency"<?php echo $user_edit->defaultcurrency->editAttributes() ?>>
			<?php echo $user_edit->defaultcurrency->selectOptionListHtml("x_defaultcurrency") ?>
		</select>
</div>
<?php echo $user_edit->defaultcurrency->Lookup->getParamTag($user_edit, "p_x_defaultcurrency") ?>
</span>
<?php echo $user_edit->defaultcurrency->CustomMsg ?></div></div>
	</div>
<?php } ?>
<?php if ($user_edit->accountID->Visible) { // accountID ?>
	<div id="r_accountID" class="form-group row">
		<label id="elh_user_accountID" for="x_accountID" class="<?php echo $user_edit->LeftColumnClass ?>"><?php echo $user_edit->accountID->caption() ?><?php echo $user_edit->accountID->Required ? $Language->phrase("FieldRequiredIndicator") : "" ?></label>
		<div class="<?php echo $user_edit->RightColumnClass ?>"><div <?php echo $user_edit->accountID->cellAttributes() ?>>
<span id="el_user_accountID">
<input type="text" data-table="user" data-field="x_accountID" data-page="1" name="x_accountID" id="x_accountID" size="30" placeholder="<?php echo HtmlEncode($user_edit->accountID->getPlaceHolder()) ?>" value="<?php echo $user_edit->accountID->EditValue ?>"<?php echo $user_edit->accountID->editAttributes() ?>>
</span>
<?php echo $user_edit->accountID->CustomMsg ?></div></div>
	</div>
<?php } ?>
<?php if ($user_edit->profilestatus->Visible) { // profilestatus ?>
	<div id="r_profilestatus" class="form-group row">
		<label id="elh_user_profilestatus" for="x_profilestatus" class="<?php echo $user_edit->LeftColumnClass ?>"><?php echo $user_edit->profilestatus->caption() ?><?php echo $user_edit->profilestatus->Required ? $Language->phrase("FieldRequiredIndicator") : "" ?></label>
		<div class="<?php echo $user_edit->RightColumnClass ?>"><div <?php echo $user_edit->profilestatus->cellAttributes() ?>>
<span id="el_user_profilestatus">
<div class="input-group">
	<select class="custom-select ew-custom-select" data-table="user" data-field="x_profilestatus" data-page="1" data-value-separator="<?php echo $user_edit->profilestatus->displayValueSeparatorAttribute() ?>" id="x_profilestatus" name="x_profilestatus"<?php echo $user_edit->profilestatus->editAttributes() ?>>
			<?php echo $user_edit->profilestatus->selectOptionListHtml("x_profilestatus") ?>
		</select>
</div>
<?php echo $user_edit->profilestatus->Lookup->getParamTag($user_edit, "p_x_profilestatus") ?>
</span>
<?php echo $user_edit->profilestatus->CustomMsg ?></div></div>
	</div>
<?php } ?>
<?php if ($user_edit->dateofbirth->Visible) { // dateofbirth ?>
	<div id="r_dateofbirth" class="form-group row">
		<label id="elh_user_dateofbirth" for="x_dateofbirth" class="<?php echo $user_edit->LeftColumnClass ?>"><?php echo $user_edit->dateofbirth->caption() ?><?php echo $user_edit->dateofbirth->Required ? $Language->phrase("FieldRequiredIndicator") : "" ?></label>
		<div class="<?php echo $user_edit->RightColumnClass ?>"><div <?php echo $user_edit->dateofbirth->cellAttributes() ?>>
<span id="el_user_dateofbirth">
<input type="text" data-table="user" data-field="x_dateofbirth" data-page="1" data-format="2" name="x_dateofbirth" id="x_dateofbirth" placeholder="<?php echo HtmlEncode($user_edit->dateofbirth->getPlaceHolder()) ?>" value="<?php echo $user_edit->dateofbirth->EditValue ?>"<?php echo $user_edit->dateofbirth->editAttributes() ?>>
<?php if (!$user_edit->dateofbirth->ReadOnly && !$user_edit->dateofbirth->Disabled && !isset($user_edit->dateofbirth->EditAttrs["readonly"]) && !isset($user_edit->dateofbirth->EditAttrs["disabled"])) { ?>
<script>
loadjs.ready(["fuseredit", "datetimepicker"], function() {
	ew.createDateTimePicker("fuseredit", "x_dateofbirth", {"ignoreReadonly":true,"useCurrent":false,"format":2});
});
</script>
<?php } ?>
</span>
<?php echo $user_edit->dateofbirth->CustomMsg ?></div></div>
	</div>
<?php } ?>
<?php if ($user_edit->gender->Visible) { // gender ?>
	<div id="r_gender" class="form-group row">
		<label id="elh_user_gender" for="x_gender" class="<?php echo $user_edit->LeftColumnClass ?>"><?php echo $user_edit->gender->caption() ?><?php echo $user_edit->gender->Required ? $Language->phrase("FieldRequiredIndicator") : "" ?></label>
		<div class="<?php echo $user_edit->RightColumnClass ?>"><div <?php echo $user_edit->gender->cellAttributes() ?>>
<span id="el_user_gender">
<div class="input-group">
	<select class="custom-select ew-custom-select" data-table="user" data-field="x_gender" data-page="1" data-value-separator="<?php echo $user_edit->gender->displayValueSeparatorAttribute() ?>" id="x_gender" name="x_gender"<?php echo $user_edit->gender->editAttributes() ?>>
			<?php echo $user_edit->gender->selectOptionListHtml("x_gender") ?>
		</select>
</div>
<?php echo $user_edit->gender->Lookup->getParamTag($user_edit, "p_x_gender") ?>
</span>
<?php echo $user_edit->gender->CustomMsg ?></div></div>
	</div>
<?php } ?>
<?php if ($user_edit->lastupdatedate->Visible) { // lastupdatedate ?>
	<div id="r_lastupdatedate" class="form-group row">
		<label id="elh_user_lastupdatedate" for="x_lastupdatedate" class="<?php echo $user_edit->LeftColumnClass ?>"><?php echo $user_edit->lastupdatedate->caption() ?><?php echo $user_edit->lastupdatedate->Required ? $Language->phrase("FieldRequiredIndicator") : "" ?></label>
		<div class="<?php echo $user_edit->RightColumnClass ?>"><div <?php echo $user_edit->lastupdatedate->cellAttributes() ?>>
<span id="el_user_lastupdatedate">
<input type="text" data-table="user" data-field="x_lastupdatedate" data-page="1" data-format="1" name="x_lastupdatedate" id="x_lastupdatedate" placeholder="<?php echo HtmlEncode($user_edit->lastupdatedate->getPlaceHolder()) ?>" value="<?php echo $user_edit->lastupdatedate->EditValue ?>"<?php echo $user_edit->lastupdatedate->editAttributes() ?>>
<?php if (!$user_edit->lastupdatedate->ReadOnly && !$user_edit->lastupdatedate->Disabled && !isset($user_edit->lastupdatedate->EditAttrs["readonly"]) && !isset($user_edit->lastupdatedate->EditAttrs["disabled"])) { ?>
<script>
loadjs.ready(["fuseredit", "datetimepicker"], function() {
	ew.createDateTimePicker("fuseredit", "x_lastupdatedate", {"ignoreReadonly":true,"useCurrent":false,"format":1});
});
</script>
<?php } ?>
</span>
<?php echo $user_edit->lastupdatedate->CustomMsg ?></div></div>
	</div>
<?php } ?>
<?php if ($user_edit->zip->Visible) { // zip ?>
	<div id="r_zip" class="form-group row">
		<label id="elh_user_zip" for="x_zip" class="<?php echo $user_edit->LeftColumnClass ?>"><?php echo $user_edit->zip->caption() ?><?php echo $user_edit->zip->Required ? $Language->phrase("FieldRequiredIndicator") : "" ?></label>
		<div class="<?php echo $user_edit->RightColumnClass ?>"><div <?php echo $user_edit->zip->cellAttributes() ?>>
<span id="el_user_zip">
<input type="text" data-table="user" data-field="x_zip" data-page="1" name="x_zip" id="x_zip" size="30" maxlength="10" placeholder="<?php echo HtmlEncode($user_edit->zip->getPlaceHolder()) ?>" value="<?php echo $user_edit->zip->EditValue ?>"<?php echo $user_edit->zip->editAttributes() ?>>
</span>
<?php echo $user_edit->zip->CustomMsg ?></div></div>
	</div>
<?php } ?>
<?php if ($user_edit->otprequiredforphysicalcards->Visible) { // otprequiredforphysicalcards ?>
	<div id="r_otprequiredforphysicalcards" class="form-group row">
		<label id="elh_user_otprequiredforphysicalcards" for="x_otprequiredforphysicalcards" class="<?php echo $user_edit->LeftColumnClass ?>"><?php echo $user_edit->otprequiredforphysicalcards->caption() ?><?php echo $user_edit->otprequiredforphysicalcards->Required ? $Language->phrase("FieldRequiredIndicator") : "" ?></label>
		<div class="<?php echo $user_edit->RightColumnClass ?>"><div <?php echo $user_edit->otprequiredforphysicalcards->cellAttributes() ?>>
<span id="el_user_otprequiredforphysicalcards">
<input type="text" data-table="user" data-field="x_otprequiredforphysicalcards" data-page="1" name="x_otprequiredforphysicalcards" id="x_otprequiredforphysicalcards" size="30" maxlength="1" placeholder="<?php echo HtmlEncode($user_edit->otprequiredforphysicalcards->getPlaceHolder()) ?>" value="<?php echo $user_edit->otprequiredforphysicalcards->EditValue ?>"<?php echo $user_edit->otprequiredforphysicalcards->editAttributes() ?>>
</span>
<?php echo $user_edit->otprequiredforphysicalcards->CustomMsg ?></div></div>
	</div>
<?php } ?>
<?php if ($user_edit->otpvaliduntil->Visible) { // otpvaliduntil ?>
	<div id="r_otpvaliduntil" class="form-group row">
		<label id="elh_user_otpvaliduntil" for="x_otpvaliduntil" class="<?php echo $user_edit->LeftColumnClass ?>"><?php echo $user_edit->otpvaliduntil->caption() ?><?php echo $user_edit->otpvaliduntil->Required ? $Language->phrase("FieldRequiredIndicator") : "" ?></label>
		<div class="<?php echo $user_edit->RightColumnClass ?>"><div <?php echo $user_edit->otpvaliduntil->cellAttributes() ?>>
<span id="el_user_otpvaliduntil">
<input type="text" data-table="user" data-field="x_otpvaliduntil" data-page="1" name="x_otpvaliduntil" id="x_otpvaliduntil" maxlength="19" placeholder="<?php echo HtmlEncode($user_edit->otpvaliduntil->getPlaceHolder()) ?>" value="<?php echo $user_edit->otpvaliduntil->EditValue ?>"<?php echo $user_edit->otpvaliduntil->editAttributes() ?>>
<?php if (!$user_edit->otpvaliduntil->ReadOnly && !$user_edit->otpvaliduntil->Disabled && !isset($user_edit->otpvaliduntil->EditAttrs["readonly"]) && !isset($user_edit->otpvaliduntil->EditAttrs["disabled"])) { ?>
<script>
loadjs.ready(["fuseredit", "datetimepicker"], function() {
	ew.createDateTimePicker("fuseredit", "x_otpvaliduntil", {"ignoreReadonly":true,"useCurrent":false,"format":0});
});
</script>
<?php } ?>
</span>
<?php echo $user_edit->otpvaliduntil->CustomMsg ?></div></div>
	</div>
<?php } ?>
<?php if ($user_edit->nationalitycountry->Visible) { // nationalitycountry ?>
	<div id="r_nationalitycountry" class="form-group row">
		<label id="elh_user_nationalitycountry" for="x_nationalitycountry" class="<?php echo $user_edit->LeftColumnClass ?>"><?php echo $user_edit->nationalitycountry->caption() ?><?php echo $user_edit->nationalitycountry->Required ? $Language->phrase("FieldRequiredIndicator") : "" ?></label>
		<div class="<?php echo $user_edit->RightColumnClass ?>"><div <?php echo $user_edit->nationalitycountry->cellAttributes() ?>>
<span id="el_user_nationalitycountry">
<div class="input-group">
	<select class="custom-select ew-custom-select" data-table="user" data-field="x_nationalitycountry" data-page="1" data-value-separator="<?php echo $user_edit->nationalitycountry->displayValueSeparatorAttribute() ?>" id="x_nationalitycountry" name="x_nationalitycountry"<?php echo $user_edit->nationalitycountry->editAttributes() ?>>
			<?php echo $user_edit->nationalitycountry->selectOptionListHtml("x_nationalitycountry") ?>
		</select>
</div>
<?php echo $user_edit->nationalitycountry->Lookup->getParamTag($user_edit, "p_x_nationalitycountry") ?>
</span>
<?php echo $user_edit->nationalitycountry->CustomMsg ?></div></div>
	</div>
<?php } ?>
<?php if ($user_edit->classification->Visible) { // classification ?>
	<div id="r_classification" class="form-group row">
		<label id="elh_user_classification" for="x_classification" class="<?php echo $user_edit->LeftColumnClass ?>"><?php echo $user_edit->classification->caption() ?><?php echo $user_edit->classification->Required ? $Language->phrase("FieldRequiredIndicator") : "" ?></label>
		<div class="<?php echo $user_edit->RightColumnClass ?>"><div <?php echo $user_edit->classification->cellAttributes() ?>>
<span id="el_user_classification">
<div class="input-group">
	<select class="custom-select ew-custom-select" data-table="user" data-field="x_classification" data-page="1" data-value-separator="<?php echo $user_edit->classification->displayValueSeparatorAttribute() ?>" id="x_classification" name="x_classification"<?php echo $user_edit->classification->editAttributes() ?>>
			<?php echo $user_edit->classification->selectOptionListHtml("x_classification") ?>
		</select>
</div>
<?php echo $user_edit->classification->Lookup->getParamTag($user_edit, "p_x_classification") ?>
</span>
<?php echo $user_edit->classification->CustomMsg ?></div></div>
	</div>
<?php } ?>
<?php if ($user_edit->occupation->Visible) { // occupation ?>
	<div id="r_occupation" class="form-group row">
		<label id="elh_user_occupation" class="<?php echo $user_edit->LeftColumnClass ?>"><?php echo $user_edit->occupation->caption() ?><?php echo $user_edit->occupation->Required ? $Language->phrase("FieldRequiredIndicator") : "" ?></label>
		<div class="<?php echo $user_edit->RightColumnClass ?>"><div <?php echo $user_edit->occupation->cellAttributes() ?>>
<span id="el_user_occupation">
<?php
$onchange = $user_edit->occupation->EditAttrs->prepend("onchange", "");
$onchange = ($onchange) ? ' onchange="' . JsEncode($onchange) . '"' : '';
$user_edit->occupation->EditAttrs["onchange"] = "";
?>
<span id="as_x_occupation">
	<input type="text" class="form-control" name="sv_x_occupation" id="sv_x_occupation" value="<?php echo RemoveHtml($user_edit->occupation->EditValue) ?>" size="30" maxlength="3" placeholder="<?php echo HtmlEncode($user_edit->occupation->getPlaceHolder()) ?>" data-placeholder="<?php echo HtmlEncode($user_edit->occupation->getPlaceHolder()) ?>"<?php echo $user_edit->occupation->editAttributes() ?>>
</span>
<input type="hidden" data-table="user" data-field="x_occupation" data-page="1" data-value-separator="<?php echo $user_edit->occupation->displayValueSeparatorAttribute() ?>" name="x_occupation" id="x_occupation" value="<?php echo HtmlEncode($user_edit->occupation->CurrentValue) ?>"<?php echo $onchange ?>>
<script>
loadjs.ready(["fuseredit"], function() {
	fuseredit.createAutoSuggest({"id":"x_occupation","forceSelect":false});
});
</script>
<?php echo $user_edit->occupation->Lookup->getParamTag($user_edit, "p_x_occupation") ?>
</span>
<?php echo $user_edit->occupation->CustomMsg ?></div></div>
	</div>
<?php } ?>
<?php if ($user_edit->sourceofincome->Visible) { // sourceofincome ?>
	<div id="r_sourceofincome" class="form-group row">
		<label id="elh_user_sourceofincome" for="x_sourceofincome" class="<?php echo $user_edit->LeftColumnClass ?>"><?php echo $user_edit->sourceofincome->caption() ?><?php echo $user_edit->sourceofincome->Required ? $Language->phrase("FieldRequiredIndicator") : "" ?></label>
		<div class="<?php echo $user_edit->RightColumnClass ?>"><div <?php echo $user_edit->sourceofincome->cellAttributes() ?>>
<span id="el_user_sourceofincome">
<div class="input-group">
	<select class="custom-select ew-custom-select" data-table="user" data-field="x_sourceofincome" data-page="1" data-value-separator="<?php echo $user_edit->sourceofincome->displayValueSeparatorAttribute() ?>" id="x_sourceofincome" name="x_sourceofincome"<?php echo $user_edit->sourceofincome->editAttributes() ?>>
			<?php echo $user_edit->sourceofincome->selectOptionListHtml("x_sourceofincome") ?>
		</select>
</div>
<?php echo $user_edit->sourceofincome->Lookup->getParamTag($user_edit, "p_x_sourceofincome") ?>
</span>
<?php echo $user_edit->sourceofincome->CustomMsg ?></div></div>
	</div>
<?php } ?>
<?php if ($user_edit->accountopeningdate->Visible) { // accountopeningdate ?>
	<div id="r_accountopeningdate" class="form-group row">
		<label id="elh_user_accountopeningdate" for="x_accountopeningdate" class="<?php echo $user_edit->LeftColumnClass ?>"><?php echo $user_edit->accountopeningdate->caption() ?><?php echo $user_edit->accountopeningdate->Required ? $Language->phrase("FieldRequiredIndicator") : "" ?></label>
		<div class="<?php echo $user_edit->RightColumnClass ?>"><div <?php echo $user_edit->accountopeningdate->cellAttributes() ?>>
<span id="el_user_accountopeningdate">
<input type="text" data-table="user" data-field="x_accountopeningdate" data-page="1" name="x_accountopeningdate" id="x_accountopeningdate" maxlength="10" placeholder="<?php echo HtmlEncode($user_edit->accountopeningdate->getPlaceHolder()) ?>" value="<?php echo $user_edit->accountopeningdate->EditValue ?>"<?php echo $user_edit->accountopeningdate->editAttributes() ?>>
<?php if (!$user_edit->accountopeningdate->ReadOnly && !$user_edit->accountopeningdate->Disabled && !isset($user_edit->accountopeningdate->EditAttrs["readonly"]) && !isset($user_edit->accountopeningdate->EditAttrs["disabled"])) { ?>
<script>
loadjs.ready(["fuseredit", "datetimepicker"], function() {
	ew.createDateTimePicker("fuseredit", "x_accountopeningdate", {"ignoreReadonly":true,"useCurrent":false,"format":0});
});
</script>
<?php } ?>
</span>
<?php echo $user_edit->accountopeningdate->CustomMsg ?></div></div>
	</div>
<?php } ?>
<?php if ($user_edit->extendedfields->Visible) { // extendedfields ?>
	<div id="r_extendedfields" class="form-group row">
		<label id="elh_user_extendedfields" for="x_extendedfields" class="<?php echo $user_edit->LeftColumnClass ?>"><?php echo $user_edit->extendedfields->caption() ?><?php echo $user_edit->extendedfields->Required ? $Language->phrase("FieldRequiredIndicator") : "" ?></label>
		<div class="<?php echo $user_edit->RightColumnClass ?>"><div <?php echo $user_edit->extendedfields->cellAttributes() ?>>
<span id="el_user_extendedfields">
<textarea data-table="user" data-field="x_extendedfields" data-page="1" name="x_extendedfields" id="x_extendedfields" cols="35" rows="4" placeholder="<?php echo HtmlEncode($user_edit->extendedfields->getPlaceHolder()) ?>"<?php echo $user_edit->extendedfields->editAttributes() ?>><?php echo $user_edit->extendedfields->EditValue ?></textarea>
</span>
<?php echo $user_edit->extendedfields->CustomMsg ?></div></div>
	</div>
<?php } ?>
<?php if ($user_edit->lastprofilestatuschangedate->Visible) { // lastprofilestatuschangedate ?>
	<div id="r_lastprofilestatuschangedate" class="form-group row">
		<label id="elh_user_lastprofilestatuschangedate" for="x_lastprofilestatuschangedate" class="<?php echo $user_edit->LeftColumnClass ?>"><?php echo $user_edit->lastprofilestatuschangedate->caption() ?><?php echo $user_edit->lastprofilestatuschangedate->Required ? $Language->phrase("FieldRequiredIndicator") : "" ?></label>
		<div class="<?php echo $user_edit->RightColumnClass ?>"><div <?php echo $user_edit->lastprofilestatuschangedate->cellAttributes() ?>>
<span id="el_user_lastprofilestatuschangedate">
<input type="text" data-table="user" data-field="x_lastprofilestatuschangedate" data-page="1" name="x_lastprofilestatuschangedate" id="x_lastprofilestatuschangedate" maxlength="19" placeholder="<?php echo HtmlEncode($user_edit->lastprofilestatuschangedate->getPlaceHolder()) ?>" value="<?php echo $user_edit->lastprofilestatuschangedate->EditValue ?>"<?php echo $user_edit->lastprofilestatuschangedate->editAttributes() ?>>
<?php if (!$user_edit->lastprofilestatuschangedate->ReadOnly && !$user_edit->lastprofilestatuschangedate->Disabled && !isset($user_edit->lastprofilestatuschangedate->EditAttrs["readonly"]) && !isset($user_edit->lastprofilestatuschangedate->EditAttrs["disabled"])) { ?>
<script>
loadjs.ready(["fuseredit", "datetimepicker"], function() {
	ew.createDateTimePicker("fuseredit", "x_lastprofilestatuschangedate", {"ignoreReadonly":true,"useCurrent":false,"format":0});
});
</script>
<?php } ?>
</span>
<?php echo $user_edit->lastprofilestatuschangedate->CustomMsg ?></div></div>
	</div>
<?php } ?>
</div><!-- /page* -->
		</div><!-- /multi-page .tab-pane -->
		<div class="tab-pane<?php echo $user_edit->MultiPages->pageStyle(2) ?>" id="tab_user2"><!-- multi-page .tab-pane -->
<div class="ew-edit-div"><!-- page* -->
<?php if ($user_edit->challengeq1->Visible) { // challengeq1 ?>
	<div id="r_challengeq1" class="form-group row">
		<label id="elh_user_challengeq1" for="x_challengeq1" class="<?php echo $user_edit->LeftColumnClass ?>"><?php echo $user_edit->challengeq1->caption() ?><?php echo $user_edit->challengeq1->Required ? $Language->phrase("FieldRequiredIndicator") : "" ?></label>
		<div class="<?php echo $user_edit->RightColumnClass ?>"><div <?php echo $user_edit->challengeq1->cellAttributes() ?>>
<span id="el_user_challengeq1">
<input type="text" data-table="user" data-field="x_challengeq1" data-page="2" name="x_challengeq1" id="x_challengeq1" size="30" placeholder="<?php echo HtmlEncode($user_edit->challengeq1->getPlaceHolder()) ?>" value="<?php echo $user_edit->challengeq1->EditValue ?>"<?php echo $user_edit->challengeq1->editAttributes() ?>>
</span>
<?php echo $user_edit->challengeq1->CustomMsg ?></div></div>
	</div>
<?php } ?>
<?php if ($user_edit->challengea1->Visible) { // challengea1 ?>
	<div id="r_challengea1" class="form-group row">
		<label id="elh_user_challengea1" for="x_challengea1" class="<?php echo $user_edit->LeftColumnClass ?>"><?php echo $user_edit->challengea1->caption() ?><?php echo $user_edit->challengea1->Required ? $Language->phrase("FieldRequiredIndicator") : "" ?></label>
		<div class="<?php echo $user_edit->RightColumnClass ?>"><div <?php echo $user_edit->challengea1->cellAttributes() ?>>
<span id="el_user_challengea1">
<input type="text" data-table="user" data-field="x_challengea1" data-page="2" name="x_challengea1" id="x_challengea1" size="30" maxlength="100" placeholder="<?php echo HtmlEncode($user_edit->challengea1->getPlaceHolder()) ?>" value="<?php echo $user_edit->challengea1->EditValue ?>"<?php echo $user_edit->challengea1->editAttributes() ?>>
</span>
<?php echo $user_edit->challengea1->CustomMsg ?></div></div>
	</div>
<?php } ?>
<?php if ($user_edit->challengeq2->Visible) { // challengeq2 ?>
	<div id="r_challengeq2" class="form-group row">
		<label id="elh_user_challengeq2" for="x_challengeq2" class="<?php echo $user_edit->LeftColumnClass ?>"><?php echo $user_edit->challengeq2->caption() ?><?php echo $user_edit->challengeq2->Required ? $Language->phrase("FieldRequiredIndicator") : "" ?></label>
		<div class="<?php echo $user_edit->RightColumnClass ?>"><div <?php echo $user_edit->challengeq2->cellAttributes() ?>>
<span id="el_user_challengeq2">
<input type="text" data-table="user" data-field="x_challengeq2" data-page="2" name="x_challengeq2" id="x_challengeq2" size="30" placeholder="<?php echo HtmlEncode($user_edit->challengeq2->getPlaceHolder()) ?>" value="<?php echo $user_edit->challengeq2->EditValue ?>"<?php echo $user_edit->challengeq2->editAttributes() ?>>
</span>
<?php echo $user_edit->challengeq2->CustomMsg ?></div></div>
	</div>
<?php } ?>
<?php if ($user_edit->challengea2->Visible) { // challengea2 ?>
	<div id="r_challengea2" class="form-group row">
		<label id="elh_user_challengea2" for="x_challengea2" class="<?php echo $user_edit->LeftColumnClass ?>"><?php echo $user_edit->challengea2->caption() ?><?php echo $user_edit->challengea2->Required ? $Language->phrase("FieldRequiredIndicator") : "" ?></label>
		<div class="<?php echo $user_edit->RightColumnClass ?>"><div <?php echo $user_edit->challengea2->cellAttributes() ?>>
<span id="el_user_challengea2">
<input type="text" data-table="user" data-field="x_challengea2" data-page="2" name="x_challengea2" id="x_challengea2" size="30" maxlength="100" placeholder="<?php echo HtmlEncode($user_edit->challengea2->getPlaceHolder()) ?>" value="<?php echo $user_edit->challengea2->EditValue ?>"<?php echo $user_edit->challengea2->editAttributes() ?>>
</span>
<?php echo $user_edit->challengea2->CustomMsg ?></div></div>
	</div>
<?php } ?>
<?php if ($user_edit->challengeq3->Visible) { // challengeq3 ?>
	<div id="r_challengeq3" class="form-group row">
		<label id="elh_user_challengeq3" for="x_challengeq3" class="<?php echo $user_edit->LeftColumnClass ?>"><?php echo $user_edit->challengeq3->caption() ?><?php echo $user_edit->challengeq3->Required ? $Language->phrase("FieldRequiredIndicator") : "" ?></label>
		<div class="<?php echo $user_edit->RightColumnClass ?>"><div <?php echo $user_edit->challengeq3->cellAttributes() ?>>
<span id="el_user_challengeq3">
<input type="text" data-table="user" data-field="x_challengeq3" data-page="2" name="x_challengeq3" id="x_challengeq3" size="30" placeholder="<?php echo HtmlEncode($user_edit->challengeq3->getPlaceHolder()) ?>" value="<?php echo $user_edit->challengeq3->EditValue ?>"<?php echo $user_edit->challengeq3->editAttributes() ?>>
</span>
<?php echo $user_edit->challengeq3->CustomMsg ?></div></div>
	</div>
<?php } ?>
<?php if ($user_edit->challengea3->Visible) { // challengea3 ?>
	<div id="r_challengea3" class="form-group row">
		<label id="elh_user_challengea3" for="x_challengea3" class="<?php echo $user_edit->LeftColumnClass ?>"><?php echo $user_edit->challengea3->caption() ?><?php echo $user_edit->challengea3->Required ? $Language->phrase("FieldRequiredIndicator") : "" ?></label>
		<div class="<?php echo $user_edit->RightColumnClass ?>"><div <?php echo $user_edit->challengea3->cellAttributes() ?>>
<span id="el_user_challengea3">
<input type="text" data-table="user" data-field="x_challengea3" data-page="2" name="x_challengea3" id="x_challengea3" size="30" maxlength="100" placeholder="<?php echo HtmlEncode($user_edit->challengea3->getPlaceHolder()) ?>" value="<?php echo $user_edit->challengea3->EditValue ?>"<?php echo $user_edit->challengea3->editAttributes() ?>>
</span>
<?php echo $user_edit->challengea3->CustomMsg ?></div></div>
	</div>
<?php } ?>
</div><!-- /page* -->
		</div><!-- /multi-page .tab-pane -->
		<div class="tab-pane<?php echo $user_edit->MultiPages->pageStyle(3) ?>" id="tab_user3"><!-- multi-page .tab-pane -->
<div class="ew-edit-div"><!-- page* -->
<?php if ($user_edit->franchiseeID->Visible) { // franchiseeID ?>
	<div id="r_franchiseeID" class="form-group row">
		<label id="elh_user_franchiseeID" for="x_franchiseeID" class="<?php echo $user_edit->LeftColumnClass ?>"><?php echo $user_edit->franchiseeID->caption() ?><?php echo $user_edit->franchiseeID->Required ? $Language->phrase("FieldRequiredIndicator") : "" ?></label>
		<div class="<?php echo $user_edit->RightColumnClass ?>"><div <?php echo $user_edit->franchiseeID->cellAttributes() ?>>
<span id="el_user_franchiseeID">
<input type="text" data-table="user" data-field="x_franchiseeID" data-page="3" name="x_franchiseeID" id="x_franchiseeID" size="30" placeholder="<?php echo HtmlEncode($user_edit->franchiseeID->getPlaceHolder()) ?>" value="<?php echo $user_edit->franchiseeID->EditValue ?>"<?php echo $user_edit->franchiseeID->editAttributes() ?>>
</span>
<?php echo $user_edit->franchiseeID->CustomMsg ?></div></div>
	</div>
<?php } ?>
<?php if ($user_edit->telephonereceivemessage->Visible) { // telephonereceivemessage ?>
	<div id="r_telephonereceivemessage" class="form-group row">
		<label id="elh_user_telephonereceivemessage" class="<?php echo $user_edit->LeftColumnClass ?>"><?php echo $user_edit->telephonereceivemessage->caption() ?><?php echo $user_edit->telephonereceivemessage->Required ? $Language->phrase("FieldRequiredIndicator") : "" ?></label>
		<div class="<?php echo $user_edit->RightColumnClass ?>"><div <?php echo $user_edit->telephonereceivemessage->cellAttributes() ?>>
<span id="el_user_telephonereceivemessage">
<div id="tp_x_telephonereceivemessage" class="ew-template"><input type="radio" class="custom-control-input" data-table="user" data-field="x_telephonereceivemessage" data-page="3" data-value-separator="<?php echo $user_edit->telephonereceivemessage->displayValueSeparatorAttribute() ?>" name="x_telephonereceivemessage" id="x_telephonereceivemessage" value="{value}"<?php echo $user_edit->telephonereceivemessage->editAttributes() ?>></div>
<div id="dsl_x_telephonereceivemessage" data-repeatcolumn="5" class="ew-item-list d-none"><div>
<?php echo $user_edit->telephonereceivemessage->radioButtonListHtml(FALSE, "x_telephonereceivemessage", 3) ?>
</div></div>
<?php echo $user_edit->telephonereceivemessage->Lookup->getParamTag($user_edit, "p_x_telephonereceivemessage") ?>
</span>
<?php echo $user_edit->telephonereceivemessage->CustomMsg ?></div></div>
	</div>
<?php } ?>
<?php if ($user_edit->verification1->Visible) { // verification1 ?>
	<div id="r_verification1" class="form-group row">
		<label id="elh_user_verification1" for="x_verification1" class="<?php echo $user_edit->LeftColumnClass ?>"><?php echo $user_edit->verification1->caption() ?><?php echo $user_edit->verification1->Required ? $Language->phrase("FieldRequiredIndicator") : "" ?></label>
		<div class="<?php echo $user_edit->RightColumnClass ?>"><div <?php echo $user_edit->verification1->cellAttributes() ?>>
<span id="el_user_verification1">
<input type="text" data-table="user" data-field="x_verification1" data-page="3" name="x_verification1" id="x_verification1" size="30" maxlength="60" placeholder="<?php echo HtmlEncode($user_edit->verification1->getPlaceHolder()) ?>" value="<?php echo $user_edit->verification1->EditValue ?>"<?php echo $user_edit->verification1->editAttributes() ?>>
</span>
<?php echo $user_edit->verification1->CustomMsg ?></div></div>
	</div>
<?php } ?>
<?php if ($user_edit->verification2->Visible) { // verification2 ?>
	<div id="r_verification2" class="form-group row">
		<label id="elh_user_verification2" for="x_verification2" class="<?php echo $user_edit->LeftColumnClass ?>"><?php echo $user_edit->verification2->caption() ?><?php echo $user_edit->verification2->Required ? $Language->phrase("FieldRequiredIndicator") : "" ?></label>
		<div class="<?php echo $user_edit->RightColumnClass ?>"><div <?php echo $user_edit->verification2->cellAttributes() ?>>
<span id="el_user_verification2">
<input type="text" data-table="user" data-field="x_verification2" data-page="3" name="x_verification2" id="x_verification2" size="30" maxlength="60" placeholder="<?php echo HtmlEncode($user_edit->verification2->getPlaceHolder()) ?>" value="<?php echo $user_edit->verification2->EditValue ?>"<?php echo $user_edit->verification2->editAttributes() ?>>
</span>
<?php echo $user_edit->verification2->CustomMsg ?></div></div>
	</div>
<?php } ?>
<?php if ($user_edit->verification3->Visible) { // verification3 ?>
	<div id="r_verification3" class="form-group row">
		<label id="elh_user_verification3" for="x_verification3" class="<?php echo $user_edit->LeftColumnClass ?>"><?php echo $user_edit->verification3->caption() ?><?php echo $user_edit->verification3->Required ? $Language->phrase("FieldRequiredIndicator") : "" ?></label>
		<div class="<?php echo $user_edit->RightColumnClass ?>"><div <?php echo $user_edit->verification3->cellAttributes() ?>>
<span id="el_user_verification3">
<input type="text" data-table="user" data-field="x_verification3" data-page="3" name="x_verification3" id="x_verification3" size="30" maxlength="60" placeholder="<?php echo HtmlEncode($user_edit->verification3->getPlaceHolder()) ?>" value="<?php echo $user_edit->verification3->EditValue ?>"<?php echo $user_edit->verification3->editAttributes() ?>>
</span>
<?php echo $user_edit->verification3->CustomMsg ?></div></div>
	</div>
<?php } ?>
<?php if ($user_edit->passwordCounter->Visible) { // passwordCounter ?>
	<div id="r_passwordCounter" class="form-group row">
		<label id="elh_user_passwordCounter" for="x_passwordCounter" class="<?php echo $user_edit->LeftColumnClass ?>"><?php echo $user_edit->passwordCounter->caption() ?><?php echo $user_edit->passwordCounter->Required ? $Language->phrase("FieldRequiredIndicator") : "" ?></label>
		<div class="<?php echo $user_edit->RightColumnClass ?>"><div <?php echo $user_edit->passwordCounter->cellAttributes() ?>>
<span id="el_user_passwordCounter">
<input type="text" data-table="user" data-field="x_passwordCounter" data-page="3" name="x_passwordCounter" id="x_passwordCounter" size="30" placeholder="<?php echo HtmlEncode($user_edit->passwordCounter->getPlaceHolder()) ?>" value="<?php echo $user_edit->passwordCounter->EditValue ?>"<?php echo $user_edit->passwordCounter->editAttributes() ?>>
</span>
<?php echo $user_edit->passwordCounter->CustomMsg ?></div></div>
	</div>
<?php } ?>
<?php if ($user_edit->passwordChangedDate->Visible) { // passwordChangedDate ?>
	<div id="r_passwordChangedDate" class="form-group row">
		<label id="elh_user_passwordChangedDate" for="x_passwordChangedDate" class="<?php echo $user_edit->LeftColumnClass ?>"><?php echo $user_edit->passwordChangedDate->caption() ?><?php echo $user_edit->passwordChangedDate->Required ? $Language->phrase("FieldRequiredIndicator") : "" ?></label>
		<div class="<?php echo $user_edit->RightColumnClass ?>"><div <?php echo $user_edit->passwordChangedDate->cellAttributes() ?>>
<span id="el_user_passwordChangedDate">
<input type="text" data-table="user" data-field="x_passwordChangedDate" data-page="3" data-format="1" name="x_passwordChangedDate" id="x_passwordChangedDate" placeholder="<?php echo HtmlEncode($user_edit->passwordChangedDate->getPlaceHolder()) ?>" value="<?php echo $user_edit->passwordChangedDate->EditValue ?>"<?php echo $user_edit->passwordChangedDate->editAttributes() ?>>
<?php if (!$user_edit->passwordChangedDate->ReadOnly && !$user_edit->passwordChangedDate->Disabled && !isset($user_edit->passwordChangedDate->EditAttrs["readonly"]) && !isset($user_edit->passwordChangedDate->EditAttrs["disabled"])) { ?>
<script>
loadjs.ready(["fuseredit", "datetimepicker"], function() {
	ew.createDateTimePicker("fuseredit", "x_passwordChangedDate", {"ignoreReadonly":true,"useCurrent":false,"format":1});
});
</script>
<?php } ?>
</span>
<?php echo $user_edit->passwordChangedDate->CustomMsg ?></div></div>
	</div>
<?php } ?>
<?php if ($user_edit->pinCounter->Visible) { // pinCounter ?>
	<div id="r_pinCounter" class="form-group row">
		<label id="elh_user_pinCounter" for="x_pinCounter" class="<?php echo $user_edit->LeftColumnClass ?>"><?php echo $user_edit->pinCounter->caption() ?><?php echo $user_edit->pinCounter->Required ? $Language->phrase("FieldRequiredIndicator") : "" ?></label>
		<div class="<?php echo $user_edit->RightColumnClass ?>"><div <?php echo $user_edit->pinCounter->cellAttributes() ?>>
<span id="el_user_pinCounter">
<input type="text" data-table="user" data-field="x_pinCounter" data-page="3" name="x_pinCounter" id="x_pinCounter" size="30" placeholder="<?php echo HtmlEncode($user_edit->pinCounter->getPlaceHolder()) ?>" value="<?php echo $user_edit->pinCounter->EditValue ?>"<?php echo $user_edit->pinCounter->editAttributes() ?>>
</span>
<?php echo $user_edit->pinCounter->CustomMsg ?></div></div>
	</div>
<?php } ?>
<?php if ($user_edit->langID->Visible) { // langID ?>
	<div id="r_langID" class="form-group row">
		<label id="elh_user_langID" for="x_langID" class="<?php echo $user_edit->LeftColumnClass ?>"><?php echo $user_edit->langID->caption() ?><?php echo $user_edit->langID->Required ? $Language->phrase("FieldRequiredIndicator") : "" ?></label>
		<div class="<?php echo $user_edit->RightColumnClass ?>"><div <?php echo $user_edit->langID->cellAttributes() ?>>
<span id="el_user_langID">
<div class="input-group">
	<select class="custom-select ew-custom-select" data-table="user" data-field="x_langID" data-page="3" data-value-separator="<?php echo $user_edit->langID->displayValueSeparatorAttribute() ?>" id="x_langID" name="x_langID"<?php echo $user_edit->langID->editAttributes() ?>>
			<?php echo $user_edit->langID->selectOptionListHtml("x_langID") ?>
		</select>
</div>
<?php echo $user_edit->langID->Lookup->getParamTag($user_edit, "p_x_langID") ?>
</span>
<?php echo $user_edit->langID->CustomMsg ?></div></div>
	</div>
<?php } ?>
<?php if ($user_edit->photo->Visible) { // photo ?>
	<div id="r_photo" class="form-group row">
		<label id="elh_user_photo" class="<?php echo $user_edit->LeftColumnClass ?>"><?php echo $user_edit->photo->caption() ?><?php echo $user_edit->photo->Required ? $Language->phrase("FieldRequiredIndicator") : "" ?></label>
		<div class="<?php echo $user_edit->RightColumnClass ?>"><div <?php echo $user_edit->photo->cellAttributes() ?>>
<span id="el_user_photo">
<div id="fd_x_photo">
<div class="input-group">
	<div class="custom-file">
		<input type="file" class="custom-file-input" title="<?php echo $user_edit->photo->title() ?>" data-table="user" data-field="x_photo" data-page="3" name="x_photo" id="x_photo" lang="<?php echo CurrentLanguageID() ?>"<?php echo $user_edit->photo->editAttributes() ?><?php if ($user_edit->photo->ReadOnly || $user_edit->photo->Disabled) echo " disabled"; ?>>
		<label class="custom-file-label ew-file-label" for="x_photo"><?php echo $Language->phrase("ChooseFile") ?></label>
	</div>
</div>
<input type="hidden" name="fn_x_photo" id= "fn_x_photo" value="<?php echo $user_edit->photo->Upload->FileName ?>">
<input type="hidden" name="fa_x_photo" id= "fa_x_photo" value="<?php echo (Post("fa_x_photo") == "0") ? "0" : "1" ?>">
<input type="hidden" name="fs_x_photo" id= "fs_x_photo" value="30">
<input type="hidden" name="fx_x_photo" id= "fx_x_photo" value="<?php echo $user_edit->photo->UploadAllowedFileExt ?>">
<input type="hidden" name="fm_x_photo" id= "fm_x_photo" value="<?php echo $user_edit->photo->UploadMaxFileSize ?>">
</div>
<table id="ft_x_photo" class="table table-sm float-left ew-upload-table"><tbody class="files"></tbody></table>
</span>
<?php echo $user_edit->photo->CustomMsg ?></div></div>
	</div>
<?php } ?>
<?php if ($user_edit->status->Visible) { // status ?>
	<div id="r_status" class="form-group row">
		<label id="elh_user_status" for="x_status" class="<?php echo $user_edit->LeftColumnClass ?>"><?php echo $user_edit->status->caption() ?><?php echo $user_edit->status->Required ? $Language->phrase("FieldRequiredIndicator") : "" ?></label>
		<div class="<?php echo $user_edit->RightColumnClass ?>"><div <?php echo $user_edit->status->cellAttributes() ?>>
<span id="el_user_status">
<div class="input-group">
	<select class="custom-select ew-custom-select" data-table="user" data-field="x_status" data-page="3" data-value-separator="<?php echo $user_edit->status->displayValueSeparatorAttribute() ?>" id="x_status" name="x_status"<?php echo $user_edit->status->editAttributes() ?>>
			<?php echo $user_edit->status->selectOptionListHtml("x_status") ?>
		</select>
</div>
<?php echo $user_edit->status->Lookup->getParamTag($user_edit, "p_x_status") ?>
</span>
<?php echo $user_edit->status->CustomMsg ?></div></div>
	</div>
<?php } ?>
<?php if ($user_edit->markedfordeletion->Visible) { // markedfordeletion ?>
	<div id="r_markedfordeletion" class="form-group row">
		<label id="elh_user_markedfordeletion" for="x_markedfordeletion" class="<?php echo $user_edit->LeftColumnClass ?>"><?php echo $user_edit->markedfordeletion->caption() ?><?php echo $user_edit->markedfordeletion->Required ? $Language->phrase("FieldRequiredIndicator") : "" ?></label>
		<div class="<?php echo $user_edit->RightColumnClass ?>"><div <?php echo $user_edit->markedfordeletion->cellAttributes() ?>>
<span id="el_user_markedfordeletion">
<input type="text" data-table="user" data-field="x_markedfordeletion" data-page="3" name="x_markedfordeletion" id="x_markedfordeletion" maxlength="10" placeholder="<?php echo HtmlEncode($user_edit->markedfordeletion->getPlaceHolder()) ?>" value="<?php echo $user_edit->markedfordeletion->EditValue ?>"<?php echo $user_edit->markedfordeletion->editAttributes() ?>>
<?php if (!$user_edit->markedfordeletion->ReadOnly && !$user_edit->markedfordeletion->Disabled && !isset($user_edit->markedfordeletion->EditAttrs["readonly"]) && !isset($user_edit->markedfordeletion->EditAttrs["disabled"])) { ?>
<script>
loadjs.ready(["fuseredit", "datetimepicker"], function() {
	ew.createDateTimePicker("fuseredit", "x_markedfordeletion", {"ignoreReadonly":true,"useCurrent":false,"format":0});
});
</script>
<?php } ?>
</span>
<?php echo $user_edit->markedfordeletion->CustomMsg ?></div></div>
	</div>
<?php } ?>
<?php if ($user_edit->userType->Visible) { // userType ?>
	<div id="r_userType" class="form-group row">
		<label id="elh_user_userType" for="x_userType" class="<?php echo $user_edit->LeftColumnClass ?>"><?php echo $user_edit->userType->caption() ?><?php echo $user_edit->userType->Required ? $Language->phrase("FieldRequiredIndicator") : "" ?></label>
		<div class="<?php echo $user_edit->RightColumnClass ?>"><div <?php echo $user_edit->userType->cellAttributes() ?>>
<span id="el_user_userType">
<?php $user_edit->userType->EditAttrs->prepend("onchange", "ew.updateOptions.call(this);"); ?>
<div class="input-group">
	<select class="custom-select ew-custom-select" data-table="user" data-field="x_userType" data-page="3" data-value-separator="<?php echo $user_edit->userType->displayValueSeparatorAttribute() ?>" id="x_userType" name="x_userType"<?php echo $user_edit->userType->editAttributes() ?>>
			<?php echo $user_edit->userType->selectOptionListHtml("x_userType") ?>
		</select>
</div>
<?php echo $user_edit->userType->Lookup->getParamTag($user_edit, "p_x_userType") ?>
</span>
<?php echo $user_edit->userType->CustomMsg ?></div></div>
	</div>
<?php } ?>
<?php if ($user_edit->usersubtype->Visible) { // usersubtype ?>
	<div id="r_usersubtype" class="form-group row">
		<label id="elh_user_usersubtype" for="x_usersubtype" class="<?php echo $user_edit->LeftColumnClass ?>"><?php echo $user_edit->usersubtype->caption() ?><?php echo $user_edit->usersubtype->Required ? $Language->phrase("FieldRequiredIndicator") : "" ?></label>
		<div class="<?php echo $user_edit->RightColumnClass ?>"><div <?php echo $user_edit->usersubtype->cellAttributes() ?>>
<span id="el_user_usersubtype">
<div class="input-group">
	<select class="custom-select ew-custom-select" data-table="user" data-field="x_usersubtype" data-page="3" data-value-separator="<?php echo $user_edit->usersubtype->displayValueSeparatorAttribute() ?>" id="x_usersubtype" name="x_usersubtype"<?php echo $user_edit->usersubtype->editAttributes() ?>>
			<?php echo $user_edit->usersubtype->selectOptionListHtml("x_usersubtype") ?>
		</select>
</div>
<?php echo $user_edit->usersubtype->Lookup->getParamTag($user_edit, "p_x_usersubtype") ?>
</span>
<?php echo $user_edit->usersubtype->CustomMsg ?></div></div>
	</div>
<?php } ?>
<?php if ($user_edit->brokerid->Visible) { // brokerid ?>
	<div id="r_brokerid" class="form-group row">
		<label id="elh_user_brokerid" for="x_brokerid" class="<?php echo $user_edit->LeftColumnClass ?>"><?php echo $user_edit->brokerid->caption() ?><?php echo $user_edit->brokerid->Required ? $Language->phrase("FieldRequiredIndicator") : "" ?></label>
		<div class="<?php echo $user_edit->RightColumnClass ?>"><div <?php echo $user_edit->brokerid->cellAttributes() ?>>
<span id="el_user_brokerid">
<input type="text" data-table="user" data-field="x_brokerid" data-page="3" name="x_brokerid" id="x_brokerid" size="30" placeholder="<?php echo HtmlEncode($user_edit->brokerid->getPlaceHolder()) ?>" value="<?php echo $user_edit->brokerid->EditValue ?>"<?php echo $user_edit->brokerid->editAttributes() ?>>
</span>
<?php echo $user_edit->brokerid->CustomMsg ?></div></div>
	</div>
<?php } ?>
<?php if ($user_edit->parentuserid->Visible) { // parentuserid ?>
	<div id="r_parentuserid" class="form-group row">
		<label id="elh_user_parentuserid" for="x_parentuserid" class="<?php echo $user_edit->LeftColumnClass ?>"><?php echo $user_edit->parentuserid->caption() ?><?php echo $user_edit->parentuserid->Required ? $Language->phrase("FieldRequiredIndicator") : "" ?></label>
		<div class="<?php echo $user_edit->RightColumnClass ?>"><div <?php echo $user_edit->parentuserid->cellAttributes() ?>>
<span id="el_user_parentuserid">
<input type="text" data-table="user" data-field="x_parentuserid" data-page="3" name="x_parentuserid" id="x_parentuserid" size="30" placeholder="<?php echo HtmlEncode($user_edit->parentuserid->getPlaceHolder()) ?>" value="<?php echo $user_edit->parentuserid->EditValue ?>"<?php echo $user_edit->parentuserid->editAttributes() ?>>
</span>
<?php echo $user_edit->parentuserid->CustomMsg ?></div></div>
	</div>
<?php } ?>
<?php if ($user_edit->corporate->Visible) { // corporate ?>
	<div id="r_corporate" class="form-group row">
		<label id="elh_user_corporate" class="<?php echo $user_edit->LeftColumnClass ?>"><?php echo $user_edit->corporate->caption() ?><?php echo $user_edit->corporate->Required ? $Language->phrase("FieldRequiredIndicator") : "" ?></label>
		<div class="<?php echo $user_edit->RightColumnClass ?>"><div <?php echo $user_edit->corporate->cellAttributes() ?>>
<span id="el_user_corporate">
<div id="tp_x_corporate" class="ew-template"><input type="radio" class="custom-control-input" data-table="user" data-field="x_corporate" data-page="3" data-value-separator="<?php echo $user_edit->corporate->displayValueSeparatorAttribute() ?>" name="x_corporate" id="x_corporate" value="{value}"<?php echo $user_edit->corporate->editAttributes() ?>></div>
<div id="dsl_x_corporate" data-repeatcolumn="5" class="ew-item-list d-none"><div>
<?php echo $user_edit->corporate->radioButtonListHtml(FALSE, "x_corporate", 3) ?>
</div></div>
<?php echo $user_edit->corporate->Lookup->getParamTag($user_edit, "p_x_corporate") ?>
</span>
<?php echo $user_edit->corporate->CustomMsg ?></div></div>
	</div>
<?php } ?>
<?php if ($user_edit->jumpappid->Visible) { // jumpappid ?>
	<div id="r_jumpappid" class="form-group row">
		<label id="elh_user_jumpappid" for="x_jumpappid" class="<?php echo $user_edit->LeftColumnClass ?>"><?php echo $user_edit->jumpappid->caption() ?><?php echo $user_edit->jumpappid->Required ? $Language->phrase("FieldRequiredIndicator") : "" ?></label>
		<div class="<?php echo $user_edit->RightColumnClass ?>"><div <?php echo $user_edit->jumpappid->cellAttributes() ?>>
<span id="el_user_jumpappid">
<input type="text" data-table="user" data-field="x_jumpappid" data-page="3" name="x_jumpappid" id="x_jumpappid" size="30" placeholder="<?php echo HtmlEncode($user_edit->jumpappid->getPlaceHolder()) ?>" value="<?php echo $user_edit->jumpappid->EditValue ?>"<?php echo $user_edit->jumpappid->editAttributes() ?>>
</span>
<?php echo $user_edit->jumpappid->CustomMsg ?></div></div>
	</div>
<?php } ?>
<?php if ($user_edit->jumprequiredatlogin->Visible) { // jumprequiredatlogin ?>
	<div id="r_jumprequiredatlogin" class="form-group row">
		<label id="elh_user_jumprequiredatlogin" class="<?php echo $user_edit->LeftColumnClass ?>"><?php echo $user_edit->jumprequiredatlogin->caption() ?><?php echo $user_edit->jumprequiredatlogin->Required ? $Language->phrase("FieldRequiredIndicator") : "" ?></label>
		<div class="<?php echo $user_edit->RightColumnClass ?>"><div <?php echo $user_edit->jumprequiredatlogin->cellAttributes() ?>>
<span id="el_user_jumprequiredatlogin">
<div id="tp_x_jumprequiredatlogin" class="ew-template"><input type="radio" class="custom-control-input" data-table="user" data-field="x_jumprequiredatlogin" data-page="3" data-value-separator="<?php echo $user_edit->jumprequiredatlogin->displayValueSeparatorAttribute() ?>" name="x_jumprequiredatlogin" id="x_jumprequiredatlogin" value="{value}"<?php echo $user_edit->jumprequiredatlogin->editAttributes() ?>></div>
<div id="dsl_x_jumprequiredatlogin" data-repeatcolumn="5" class="ew-item-list d-none"><div>
<?php echo $user_edit->jumprequiredatlogin->radioButtonListHtml(FALSE, "x_jumprequiredatlogin", 3) ?>
</div></div>
<?php echo $user_edit->jumprequiredatlogin->Lookup->getParamTag($user_edit, "p_x_jumprequiredatlogin") ?>
</span>
<?php echo $user_edit->jumprequiredatlogin->CustomMsg ?></div></div>
	</div>
<?php } ?>
<?php if ($user_edit->ccbypass->Visible) { // ccbypass ?>
	<div id="r_ccbypass" class="form-group row">
		<label id="elh_user_ccbypass" class="<?php echo $user_edit->LeftColumnClass ?>"><?php echo $user_edit->ccbypass->caption() ?><?php echo $user_edit->ccbypass->Required ? $Language->phrase("FieldRequiredIndicator") : "" ?></label>
		<div class="<?php echo $user_edit->RightColumnClass ?>"><div <?php echo $user_edit->ccbypass->cellAttributes() ?>>
<span id="el_user_ccbypass">
<div id="tp_x_ccbypass" class="ew-template"><input type="radio" class="custom-control-input" data-table="user" data-field="x_ccbypass" data-page="3" data-value-separator="<?php echo $user_edit->ccbypass->displayValueSeparatorAttribute() ?>" name="x_ccbypass" id="x_ccbypass" value="{value}"<?php echo $user_edit->ccbypass->editAttributes() ?>></div>
<div id="dsl_x_ccbypass" data-repeatcolumn="5" class="ew-item-list d-none"><div>
<?php echo $user_edit->ccbypass->radioButtonListHtml(FALSE, "x_ccbypass", 3) ?>
</div></div>
<?php echo $user_edit->ccbypass->Lookup->getParamTag($user_edit, "p_x_ccbypass") ?>
</span>
<?php echo $user_edit->ccbypass->CustomMsg ?></div></div>
	</div>
<?php } ?>
<?php if ($user_edit->other1->Visible) { // other1 ?>
	<div id="r_other1" class="form-group row">
		<label id="elh_user_other1" for="x_other1" class="<?php echo $user_edit->LeftColumnClass ?>"><?php echo $user_edit->other1->caption() ?><?php echo $user_edit->other1->Required ? $Language->phrase("FieldRequiredIndicator") : "" ?></label>
		<div class="<?php echo $user_edit->RightColumnClass ?>"><div <?php echo $user_edit->other1->cellAttributes() ?>>
<span id="el_user_other1">
<input type="text" data-table="user" data-field="x_other1" data-page="3" name="x_other1" id="x_other1" size="30" maxlength="25" placeholder="<?php echo HtmlEncode($user_edit->other1->getPlaceHolder()) ?>" value="<?php echo $user_edit->other1->EditValue ?>"<?php echo $user_edit->other1->editAttributes() ?>>
</span>
<?php echo $user_edit->other1->CustomMsg ?></div></div>
	</div>
<?php } ?>
<?php if ($user_edit->other2->Visible) { // other2 ?>
	<div id="r_other2" class="form-group row">
		<label id="elh_user_other2" for="x_other2" class="<?php echo $user_edit->LeftColumnClass ?>"><?php echo $user_edit->other2->caption() ?><?php echo $user_edit->other2->Required ? $Language->phrase("FieldRequiredIndicator") : "" ?></label>
		<div class="<?php echo $user_edit->RightColumnClass ?>"><div <?php echo $user_edit->other2->cellAttributes() ?>>
<span id="el_user_other2">
<input type="text" data-table="user" data-field="x_other2" data-page="3" name="x_other2" id="x_other2" size="30" maxlength="25" placeholder="<?php echo HtmlEncode($user_edit->other2->getPlaceHolder()) ?>" value="<?php echo $user_edit->other2->EditValue ?>"<?php echo $user_edit->other2->editAttributes() ?>>
</span>
<?php echo $user_edit->other2->CustomMsg ?></div></div>
	</div>
<?php } ?>
<?php if ($user_edit->other3->Visible) { // other3 ?>
	<div id="r_other3" class="form-group row">
		<label id="elh_user_other3" for="x_other3" class="<?php echo $user_edit->LeftColumnClass ?>"><?php echo $user_edit->other3->caption() ?><?php echo $user_edit->other3->Required ? $Language->phrase("FieldRequiredIndicator") : "" ?></label>
		<div class="<?php echo $user_edit->RightColumnClass ?>"><div <?php echo $user_edit->other3->cellAttributes() ?>>
<span id="el_user_other3">
<input type="text" data-table="user" data-field="x_other3" data-page="3" name="x_other3" id="x_other3" size="30" maxlength="25" placeholder="<?php echo HtmlEncode($user_edit->other3->getPlaceHolder()) ?>" value="<?php echo $user_edit->other3->EditValue ?>"<?php echo $user_edit->other3->editAttributes() ?>>
</span>
<?php echo $user_edit->other3->CustomMsg ?></div></div>
	</div>
<?php } ?>
<?php if ($user_edit->other4->Visible) { // other4 ?>
	<div id="r_other4" class="form-group row">
		<label id="elh_user_other4" for="x_other4" class="<?php echo $user_edit->LeftColumnClass ?>"><?php echo $user_edit->other4->caption() ?><?php echo $user_edit->other4->Required ? $Language->phrase("FieldRequiredIndicator") : "" ?></label>
		<div class="<?php echo $user_edit->RightColumnClass ?>"><div <?php echo $user_edit->other4->cellAttributes() ?>>
<span id="el_user_other4">
<input type="text" data-table="user" data-field="x_other4" data-page="3" name="x_other4" id="x_other4" size="30" maxlength="25" placeholder="<?php echo HtmlEncode($user_edit->other4->getPlaceHolder()) ?>" value="<?php echo $user_edit->other4->EditValue ?>"<?php echo $user_edit->other4->editAttributes() ?>>
</span>
<?php echo $user_edit->other4->CustomMsg ?></div></div>
	</div>
<?php } ?>
<?php if ($user_edit->other5->Visible) { // other5 ?>
	<div id="r_other5" class="form-group row">
		<label id="elh_user_other5" for="x_other5" class="<?php echo $user_edit->LeftColumnClass ?>"><?php echo $user_edit->other5->caption() ?><?php echo $user_edit->other5->Required ? $Language->phrase("FieldRequiredIndicator") : "" ?></label>
		<div class="<?php echo $user_edit->RightColumnClass ?>"><div <?php echo $user_edit->other5->cellAttributes() ?>>
<span id="el_user_other5">
<input type="text" data-table="user" data-field="x_other5" data-page="3" name="x_other5" id="x_other5" size="30" maxlength="25" placeholder="<?php echo HtmlEncode($user_edit->other5->getPlaceHolder()) ?>" value="<?php echo $user_edit->other5->EditValue ?>"<?php echo $user_edit->other5->editAttributes() ?>>
</span>
<?php echo $user_edit->other5->CustomMsg ?></div></div>
	</div>
<?php } ?>
<?php if ($user_edit->other6->Visible) { // other6 ?>
	<div id="r_other6" class="form-group row">
		<label id="elh_user_other6" for="x_other6" class="<?php echo $user_edit->LeftColumnClass ?>"><?php echo $user_edit->other6->caption() ?><?php echo $user_edit->other6->Required ? $Language->phrase("FieldRequiredIndicator") : "" ?></label>
		<div class="<?php echo $user_edit->RightColumnClass ?>"><div <?php echo $user_edit->other6->cellAttributes() ?>>
<span id="el_user_other6">
<input type="text" data-table="user" data-field="x_other6" data-page="3" name="x_other6" id="x_other6" size="30" maxlength="25" placeholder="<?php echo HtmlEncode($user_edit->other6->getPlaceHolder()) ?>" value="<?php echo $user_edit->other6->EditValue ?>"<?php echo $user_edit->other6->editAttributes() ?>>
</span>
<?php echo $user_edit->other6->CustomMsg ?></div></div>
	</div>
<?php } ?>
<?php if ($user_edit->legalid->Visible) { // legalid ?>
	<div id="r_legalid" class="form-group row">
		<label id="elh_user_legalid" for="x_legalid" class="<?php echo $user_edit->LeftColumnClass ?>"><?php echo $user_edit->legalid->caption() ?><?php echo $user_edit->legalid->Required ? $Language->phrase("FieldRequiredIndicator") : "" ?></label>
		<div class="<?php echo $user_edit->RightColumnClass ?>"><div <?php echo $user_edit->legalid->cellAttributes() ?>>
<span id="el_user_legalid">
<input type="text" data-table="user" data-field="x_legalid" data-page="3" name="x_legalid" id="x_legalid" size="30" placeholder="<?php echo HtmlEncode($user_edit->legalid->getPlaceHolder()) ?>" value="<?php echo $user_edit->legalid->EditValue ?>"<?php echo $user_edit->legalid->editAttributes() ?>>
</span>
<?php echo $user_edit->legalid->CustomMsg ?></div></div>
	</div>
<?php } ?>
<?php if ($user_edit->userpiview->Visible) { // userpiview ?>
	<div id="r_userpiview" class="form-group row">
		<label id="elh_user_userpiview" class="<?php echo $user_edit->LeftColumnClass ?>"><?php echo $user_edit->userpiview->caption() ?><?php echo $user_edit->userpiview->Required ? $Language->phrase("FieldRequiredIndicator") : "" ?></label>
		<div class="<?php echo $user_edit->RightColumnClass ?>"><div <?php echo $user_edit->userpiview->cellAttributes() ?>>
<span id="el_user_userpiview">
<div id="tp_x_userpiview" class="ew-template"><input type="radio" class="custom-control-input" data-table="user" data-field="x_userpiview" data-page="3" data-value-separator="<?php echo $user_edit->userpiview->displayValueSeparatorAttribute() ?>" name="x_userpiview" id="x_userpiview" value="{value}"<?php echo $user_edit->userpiview->editAttributes() ?>></div>
<div id="dsl_x_userpiview" data-repeatcolumn="5" class="ew-item-list d-none"><div>
<?php echo $user_edit->userpiview->radioButtonListHtml(FALSE, "x_userpiview", 3) ?>
</div></div>
<?php echo $user_edit->userpiview->Lookup->getParamTag($user_edit, "p_x_userpiview") ?>
</span>
<?php echo $user_edit->userpiview->CustomMsg ?></div></div>
	</div>
<?php } ?>
<?php if ($user_edit->lastmsgid->Visible) { // lastmsgid ?>
	<div id="r_lastmsgid" class="form-group row">
		<label id="elh_user_lastmsgid" for="x_lastmsgid" class="<?php echo $user_edit->LeftColumnClass ?>"><?php echo $user_edit->lastmsgid->caption() ?><?php echo $user_edit->lastmsgid->Required ? $Language->phrase("FieldRequiredIndicator") : "" ?></label>
		<div class="<?php echo $user_edit->RightColumnClass ?>"><div <?php echo $user_edit->lastmsgid->cellAttributes() ?>>
<span id="el_user_lastmsgid">
<input type="text" data-table="user" data-field="x_lastmsgid" data-page="3" name="x_lastmsgid" id="x_lastmsgid" size="30" placeholder="<?php echo HtmlEncode($user_edit->lastmsgid->getPlaceHolder()) ?>" value="<?php echo $user_edit->lastmsgid->EditValue ?>"<?php echo $user_edit->lastmsgid->editAttributes() ?>>
</span>
<?php echo $user_edit->lastmsgid->CustomMsg ?></div></div>
	</div>
<?php } ?>
</div><!-- /page* -->
		</div><!-- /multi-page .tab-pane -->
		<div class="tab-pane<?php echo $user_edit->MultiPages->pageStyle(4) ?>" id="tab_user4"><!-- multi-page .tab-pane -->
<div class="ew-edit-div"><!-- page* -->
<?php if ($user_edit->mincashamount->Visible) { // mincashamount ?>
	<div id="r_mincashamount" class="form-group row">
		<label id="elh_user_mincashamount" for="x_mincashamount" class="<?php echo $user_edit->LeftColumnClass ?>"><?php echo $user_edit->mincashamount->caption() ?><?php echo $user_edit->mincashamount->Required ? $Language->phrase("FieldRequiredIndicator") : "" ?></label>
		<div class="<?php echo $user_edit->RightColumnClass ?>"><div <?php echo $user_edit->mincashamount->cellAttributes() ?>>
<span id="el_user_mincashamount">
<input type="text" data-table="user" data-field="x_mincashamount" data-page="4" name="x_mincashamount" id="x_mincashamount" size="30" placeholder="<?php echo HtmlEncode($user_edit->mincashamount->getPlaceHolder()) ?>" value="<?php echo $user_edit->mincashamount->EditValue ?>"<?php echo $user_edit->mincashamount->editAttributes() ?>>
</span>
<?php echo $user_edit->mincashamount->CustomMsg ?></div></div>
	</div>
<?php } ?>
<?php if ($user_edit->maxcashamount->Visible) { // maxcashamount ?>
	<div id="r_maxcashamount" class="form-group row">
		<label id="elh_user_maxcashamount" for="x_maxcashamount" class="<?php echo $user_edit->LeftColumnClass ?>"><?php echo $user_edit->maxcashamount->caption() ?><?php echo $user_edit->maxcashamount->Required ? $Language->phrase("FieldRequiredIndicator") : "" ?></label>
		<div class="<?php echo $user_edit->RightColumnClass ?>"><div <?php echo $user_edit->maxcashamount->cellAttributes() ?>>
<span id="el_user_maxcashamount">
<input type="text" data-table="user" data-field="x_maxcashamount" data-page="4" name="x_maxcashamount" id="x_maxcashamount" size="30" placeholder="<?php echo HtmlEncode($user_edit->maxcashamount->getPlaceHolder()) ?>" value="<?php echo $user_edit->maxcashamount->EditValue ?>"<?php echo $user_edit->maxcashamount->editAttributes() ?>>
</span>
<?php echo $user_edit->maxcashamount->CustomMsg ?></div></div>
	</div>
<?php } ?>
<?php if ($user_edit->maxtransferinamount->Visible) { // maxtransferinamount ?>
	<div id="r_maxtransferinamount" class="form-group row">
		<label id="elh_user_maxtransferinamount" for="x_maxtransferinamount" class="<?php echo $user_edit->LeftColumnClass ?>"><?php echo $user_edit->maxtransferinamount->caption() ?><?php echo $user_edit->maxtransferinamount->Required ? $Language->phrase("FieldRequiredIndicator") : "" ?></label>
		<div class="<?php echo $user_edit->RightColumnClass ?>"><div <?php echo $user_edit->maxtransferinamount->cellAttributes() ?>>
<span id="el_user_maxtransferinamount">
<input type="text" data-table="user" data-field="x_maxtransferinamount" data-page="4" name="x_maxtransferinamount" id="x_maxtransferinamount" size="30" placeholder="<?php echo HtmlEncode($user_edit->maxtransferinamount->getPlaceHolder()) ?>" value="<?php echo $user_edit->maxtransferinamount->EditValue ?>"<?php echo $user_edit->maxtransferinamount->editAttributes() ?>>
</span>
<?php echo $user_edit->maxtransferinamount->CustomMsg ?></div></div>
	</div>
<?php } ?>
<?php if ($user_edit->maxtransferoutamount->Visible) { // maxtransferoutamount ?>
	<div id="r_maxtransferoutamount" class="form-group row">
		<label id="elh_user_maxtransferoutamount" for="x_maxtransferoutamount" class="<?php echo $user_edit->LeftColumnClass ?>"><?php echo $user_edit->maxtransferoutamount->caption() ?><?php echo $user_edit->maxtransferoutamount->Required ? $Language->phrase("FieldRequiredIndicator") : "" ?></label>
		<div class="<?php echo $user_edit->RightColumnClass ?>"><div <?php echo $user_edit->maxtransferoutamount->cellAttributes() ?>>
<span id="el_user_maxtransferoutamount">
<input type="text" data-table="user" data-field="x_maxtransferoutamount" data-page="4" name="x_maxtransferoutamount" id="x_maxtransferoutamount" size="30" placeholder="<?php echo HtmlEncode($user_edit->maxtransferoutamount->getPlaceHolder()) ?>" value="<?php echo $user_edit->maxtransferoutamount->EditValue ?>"<?php echo $user_edit->maxtransferoutamount->editAttributes() ?>>
</span>
<?php echo $user_edit->maxtransferoutamount->CustomMsg ?></div></div>
	</div>
<?php } ?>
</div><!-- /page* -->
		</div><!-- /multi-page .tab-pane -->
	</div><!-- /multi-page tabs .tab-content -->
</div><!-- /multi-page tabs -->
</div><!-- /multi-page -->
<?php if ($user->getCurrentDetailTable() != "") { ?>
<?php
	$user_edit->DetailPages->ValidKeys = explode(",", $user->getCurrentDetailTable());
	$firstActiveDetailTable = $user_edit->DetailPages->activePageIndex();
?>
<div class="ew-detail-pages"><!-- detail-pages -->
<div class="ew-nav-tabs" id="user_edit_details"><!-- tabs -->
	<ul class="<?php echo $user_edit->DetailPages->navStyle() ?>"><!-- .nav -->
<?php
	if (in_array("userpasswordhistory", explode(",", $user->getCurrentDetailTable())) && $userpasswordhistory->DetailEdit) {
		if ($firstActiveDetailTable == "" || $firstActiveDetailTable == "userpasswordhistory") {
			$firstActiveDetailTable = "userpasswordhistory";
		}
?>
		<li class="nav-item"><a class="nav-link <?php echo $user_edit->DetailPages->pageStyle("userpasswordhistory") ?>" href="#tab_userpasswordhistory" data-toggle="tab"><?php echo $Language->tablePhrase("userpasswordhistory", "TblCaption") ?></a></li>
<?php
	}
?>
<?php
	if (in_array("userpinhistory", explode(",", $user->getCurrentDetailTable())) && $userpinhistory->DetailEdit) {
		if ($firstActiveDetailTable == "" || $firstActiveDetailTable == "userpinhistory") {
			$firstActiveDetailTable = "userpinhistory";
		}
?>
		<li class="nav-item"><a class="nav-link <?php echo $user_edit->DetailPages->pageStyle("userpinhistory") ?>" href="#tab_userpinhistory" data-toggle="tab"><?php echo $Language->tablePhrase("userpinhistory", "TblCaption") ?></a></li>
<?php
	}
?>
<?php
	if (in_array("userchildren", explode(",", $user->getCurrentDetailTable())) && $userchildren->DetailEdit) {
		if ($firstActiveDetailTable == "" || $firstActiveDetailTable == "userchildren") {
			$firstActiveDetailTable = "userchildren";
		}
?>
		<li class="nav-item"><a class="nav-link <?php echo $user_edit->DetailPages->pageStyle("userchildren") ?>" href="#tab_userchildren" data-toggle="tab"><?php echo $Language->tablePhrase("userchildren", "TblCaption") ?></a></li>
<?php
	}
?>
<?php
	if (in_array("usercontactlist", explode(",", $user->getCurrentDetailTable())) && $usercontactlist->DetailEdit) {
		if ($firstActiveDetailTable == "" || $firstActiveDetailTable == "usercontactlist") {
			$firstActiveDetailTable = "usercontactlist";
		}
?>
		<li class="nav-item"><a class="nav-link <?php echo $user_edit->DetailPages->pageStyle("usercontactlist") ?>" href="#tab_usercontactlist" data-toggle="tab"><?php echo $Language->tablePhrase("usercontactlist", "TblCaption") ?></a></li>
<?php
	}
?>
<?php
	if (in_array("securityuserrole", explode(",", $user->getCurrentDetailTable())) && $securityuserrole->DetailEdit) {
		if ($firstActiveDetailTable == "" || $firstActiveDetailTable == "securityuserrole") {
			$firstActiveDetailTable = "securityuserrole";
		}
?>
		<li class="nav-item"><a class="nav-link <?php echo $user_edit->DetailPages->pageStyle("securityuserrole") ?>" href="#tab_securityuserrole" data-toggle="tab"><?php echo $Language->tablePhrase("securityuserrole", "TblCaption") ?></a></li>
<?php
	}
?>
<?php
	if (in_array("mailbox", explode(",", $user->getCurrentDetailTable())) && $mailbox->DetailEdit) {
		if ($firstActiveDetailTable == "" || $firstActiveDetailTable == "mailbox") {
			$firstActiveDetailTable = "mailbox";
		}
?>
		<li class="nav-item"><a class="nav-link <?php echo $user_edit->DetailPages->pageStyle("mailbox") ?>" href="#tab_mailbox" data-toggle="tab"><?php echo $Language->tablePhrase("mailbox", "TblCaption") ?></a></li>
<?php
	}
?>
<?php
	if (in_array("balanceinquiryhistory", explode(",", $user->getCurrentDetailTable())) && $balanceinquiryhistory->DetailEdit) {
		if ($firstActiveDetailTable == "" || $firstActiveDetailTable == "balanceinquiryhistory") {
			$firstActiveDetailTable = "balanceinquiryhistory";
		}
?>
		<li class="nav-item"><a class="nav-link <?php echo $user_edit->DetailPages->pageStyle("balanceinquiryhistory") ?>" href="#tab_balanceinquiryhistory" data-toggle="tab"><?php echo $Language->tablePhrase("balanceinquiryhistory", "TblCaption") ?></a></li>
<?php
	}
?>
<?php
	if (in_array("usersession", explode(",", $user->getCurrentDetailTable())) && $usersession->DetailEdit) {
		if ($firstActiveDetailTable == "" || $firstActiveDetailTable == "usersession") {
			$firstActiveDetailTable = "usersession";
		}
?>
		<li class="nav-item"><a class="nav-link <?php echo $user_edit->DetailPages->pageStyle("usersession") ?>" href="#tab_usersession" data-toggle="tab"><?php echo $Language->tablePhrase("usersession", "TblCaption") ?></a></li>
<?php
	}
?>
<?php
	if (in_array("vtranshistorybyuser", explode(",", $user->getCurrentDetailTable())) && $vtranshistorybyuser->DetailEdit) {
		if ($firstActiveDetailTable == "" || $firstActiveDetailTable == "vtranshistorybyuser") {
			$firstActiveDetailTable = "vtranshistorybyuser";
		}
?>
		<li class="nav-item"><a class="nav-link <?php echo $user_edit->DetailPages->pageStyle("vtranshistorybyuser") ?>" href="#tab_vtranshistorybyuser" data-toggle="tab"><?php echo $Language->tablePhrase("vtranshistorybyuser", "TblCaption") ?></a></li>
<?php
	}
?>
<?php
	if (in_array("vtranssummary", explode(",", $user->getCurrentDetailTable())) && $vtranssummary->DetailEdit) {
		if ($firstActiveDetailTable == "" || $firstActiveDetailTable == "vtranssummary") {
			$firstActiveDetailTable = "vtranssummary";
		}
?>
		<li class="nav-item"><a class="nav-link <?php echo $user_edit->DetailPages->pageStyle("vtranssummary") ?>" href="#tab_vtranssummary" data-toggle="tab"><?php echo $Language->tablePhrase("vtranssummary", "TblCaption") ?></a></li>
<?php
	}
?>
<?php
	if (in_array("useremailaccount", explode(",", $user->getCurrentDetailTable())) && $useremailaccount->DetailEdit) {
		if ($firstActiveDetailTable == "" || $firstActiveDetailTable == "useremailaccount") {
			$firstActiveDetailTable = "useremailaccount";
		}
?>
		<li class="nav-item"><a class="nav-link <?php echo $user_edit->DetailPages->pageStyle("useremailaccount") ?>" href="#tab_useremailaccount" data-toggle="tab"><?php echo $Language->tablePhrase("useremailaccount", "TblCaption") ?></a></li>
<?php
	}
?>
<?php
	if (in_array("userpi", explode(",", $user->getCurrentDetailTable())) && $userpi->DetailEdit) {
		if ($firstActiveDetailTable == "" || $firstActiveDetailTable == "userpi") {
			$firstActiveDetailTable = "userpi";
		}
?>
		<li class="nav-item"><a class="nav-link <?php echo $user_edit->DetailPages->pageStyle("userpi") ?>" href="#tab_userpi" data-toggle="tab"><?php echo $Language->tablePhrase("userpi", "TblCaption") ?></a></li>
<?php
	}
?>
<?php
	if (in_array("userpurchase", explode(",", $user->getCurrentDetailTable())) && $userpurchase->DetailEdit) {
		if ($firstActiveDetailTable == "" || $firstActiveDetailTable == "userpurchase") {
			$firstActiveDetailTable = "userpurchase";
		}
?>
		<li class="nav-item"><a class="nav-link <?php echo $user_edit->DetailPages->pageStyle("userpurchase") ?>" href="#tab_userpurchase" data-toggle="tab"><?php echo $Language->tablePhrase("userpurchase", "TblCaption") ?></a></li>
<?php
	}
?>
<?php
	if (in_array("loanlimits", explode(",", $user->getCurrentDetailTable())) && $loanlimits->DetailEdit) {
		if ($firstActiveDetailTable == "" || $firstActiveDetailTable == "loanlimits") {
			$firstActiveDetailTable = "loanlimits";
		}
?>
		<li class="nav-item"><a class="nav-link <?php echo $user_edit->DetailPages->pageStyle("loanlimits") ?>" href="#tab_loanlimits" data-toggle="tab"><?php echo $Language->tablePhrase("loanlimits", "TblCaption") ?></a></li>
<?php
	}
?>
<?php
	if (in_array("userkycdocs", explode(",", $user->getCurrentDetailTable())) && $userkycdocs->DetailEdit) {
		if ($firstActiveDetailTable == "" || $firstActiveDetailTable == "userkycdocs") {
			$firstActiveDetailTable = "userkycdocs";
		}
?>
		<li class="nav-item"><a class="nav-link <?php echo $user_edit->DetailPages->pageStyle("userkycdocs") ?>" href="#tab_userkycdocs" data-toggle="tab"><?php echo $Language->tablePhrase("userkycdocs", "TblCaption") ?></a></li>
<?php
	}
?>
<?php
	if (in_array("acctbalance", explode(",", $user->getCurrentDetailTable())) && $acctbalance->DetailEdit) {
		if ($firstActiveDetailTable == "" || $firstActiveDetailTable == "acctbalance") {
			$firstActiveDetailTable = "acctbalance";
		}
?>
		<li class="nav-item"><a class="nav-link <?php echo $user_edit->DetailPages->pageStyle("acctbalance") ?>" href="#tab_acctbalance" data-toggle="tab"><?php echo $Language->tablePhrase("acctbalance", "TblCaption") ?></a></li>
<?php
	}
?>
<?php
	if (in_array("userdevices", explode(",", $user->getCurrentDetailTable())) && $userdevices->DetailEdit) {
		if ($firstActiveDetailTable == "" || $firstActiveDetailTable == "userdevices") {
			$firstActiveDetailTable = "userdevices";
		}
?>
		<li class="nav-item"><a class="nav-link <?php echo $user_edit->DetailPages->pageStyle("userdevices") ?>" href="#tab_userdevices" data-toggle="tab"><?php echo $Language->tablePhrase("userdevices", "TblCaption") ?></a></li>
<?php
	}
?>
<?php
	if (in_array("usercommission", explode(",", $user->getCurrentDetailTable())) && $usercommission->DetailEdit) {
		if ($firstActiveDetailTable == "" || $firstActiveDetailTable == "usercommission") {
			$firstActiveDetailTable = "usercommission";
		}
?>
		<li class="nav-item"><a class="nav-link <?php echo $user_edit->DetailPages->pageStyle("usercommission") ?>" href="#tab_usercommission" data-toggle="tab"><?php echo $Language->tablePhrase("usercommission", "TblCaption") ?></a></li>
<?php
	}
?>
	</ul><!-- /.nav -->
	<div class="tab-content"><!-- .tab-content -->
<?php
	if (in_array("userpasswordhistory", explode(",", $user->getCurrentDetailTable())) && $userpasswordhistory->DetailEdit) {
		if ($firstActiveDetailTable == "" || $firstActiveDetailTable == "userpasswordhistory")
			$firstActiveDetailTable = "userpasswordhistory";
?>
		<div class="tab-pane <?php echo $user_edit->DetailPages->pageStyle("userpasswordhistory") ?>" id="tab_userpasswordhistory"><!-- page* -->
<?php include_once "userpasswordhistorygrid.php" ?>
		</div><!-- /page* -->
<?php } ?>
<?php
	if (in_array("userpinhistory", explode(",", $user->getCurrentDetailTable())) && $userpinhistory->DetailEdit) {
		if ($firstActiveDetailTable == "" || $firstActiveDetailTable == "userpinhistory")
			$firstActiveDetailTable = "userpinhistory";
?>
		<div class="tab-pane <?php echo $user_edit->DetailPages->pageStyle("userpinhistory") ?>" id="tab_userpinhistory"><!-- page* -->
<?php include_once "userpinhistorygrid.php" ?>
		</div><!-- /page* -->
<?php } ?>
<?php
	if (in_array("userchildren", explode(",", $user->getCurrentDetailTable())) && $userchildren->DetailEdit) {
		if ($firstActiveDetailTable == "" || $firstActiveDetailTable == "userchildren")
			$firstActiveDetailTable = "userchildren";
?>
		<div class="tab-pane <?php echo $user_edit->DetailPages->pageStyle("userchildren") ?>" id="tab_userchildren"><!-- page* -->
<?php include_once "userchildrengrid.php" ?>
		</div><!-- /page* -->
<?php } ?>
<?php
	if (in_array("usercontactlist", explode(",", $user->getCurrentDetailTable())) && $usercontactlist->DetailEdit) {
		if ($firstActiveDetailTable == "" || $firstActiveDetailTable == "usercontactlist")
			$firstActiveDetailTable = "usercontactlist";
?>
		<div class="tab-pane <?php echo $user_edit->DetailPages->pageStyle("usercontactlist") ?>" id="tab_usercontactlist"><!-- page* -->
<?php include_once "usercontactlistgrid.php" ?>
		</div><!-- /page* -->
<?php } ?>
<?php
	if (in_array("securityuserrole", explode(",", $user->getCurrentDetailTable())) && $securityuserrole->DetailEdit) {
		if ($firstActiveDetailTable == "" || $firstActiveDetailTable == "securityuserrole")
			$firstActiveDetailTable = "securityuserrole";
?>
		<div class="tab-pane <?php echo $user_edit->DetailPages->pageStyle("securityuserrole") ?>" id="tab_securityuserrole"><!-- page* -->
<?php include_once "securityuserrolegrid.php" ?>
		</div><!-- /page* -->
<?php } ?>
<?php
	if (in_array("mailbox", explode(",", $user->getCurrentDetailTable())) && $mailbox->DetailEdit) {
		if ($firstActiveDetailTable == "" || $firstActiveDetailTable == "mailbox")
			$firstActiveDetailTable = "mailbox";
?>
		<div class="tab-pane <?php echo $user_edit->DetailPages->pageStyle("mailbox") ?>" id="tab_mailbox"><!-- page* -->
<?php include_once "mailboxgrid.php" ?>
		</div><!-- /page* -->
<?php } ?>
<?php
	if (in_array("balanceinquiryhistory", explode(",", $user->getCurrentDetailTable())) && $balanceinquiryhistory->DetailEdit) {
		if ($firstActiveDetailTable == "" || $firstActiveDetailTable == "balanceinquiryhistory")
			$firstActiveDetailTable = "balanceinquiryhistory";
?>
		<div class="tab-pane <?php echo $user_edit->DetailPages->pageStyle("balanceinquiryhistory") ?>" id="tab_balanceinquiryhistory"><!-- page* -->
<?php include_once "balanceinquiryhistorygrid.php" ?>
		</div><!-- /page* -->
<?php } ?>
<?php
	if (in_array("usersession", explode(",", $user->getCurrentDetailTable())) && $usersession->DetailEdit) {
		if ($firstActiveDetailTable == "" || $firstActiveDetailTable == "usersession")
			$firstActiveDetailTable = "usersession";
?>
		<div class="tab-pane <?php echo $user_edit->DetailPages->pageStyle("usersession") ?>" id="tab_usersession"><!-- page* -->
<?php include_once "usersessiongrid.php" ?>
		</div><!-- /page* -->
<?php } ?>
<?php
	if (in_array("vtranshistorybyuser", explode(",", $user->getCurrentDetailTable())) && $vtranshistorybyuser->DetailEdit) {
		if ($firstActiveDetailTable == "" || $firstActiveDetailTable == "vtranshistorybyuser")
			$firstActiveDetailTable = "vtranshistorybyuser";
?>
		<div class="tab-pane <?php echo $user_edit->DetailPages->pageStyle("vtranshistorybyuser") ?>" id="tab_vtranshistorybyuser"><!-- page* -->
<?php include_once "vtranshistorybyusergrid.php" ?>
		</div><!-- /page* -->
<?php } ?>
<?php
	if (in_array("vtranssummary", explode(",", $user->getCurrentDetailTable())) && $vtranssummary->DetailEdit) {
		if ($firstActiveDetailTable == "" || $firstActiveDetailTable == "vtranssummary")
			$firstActiveDetailTable = "vtranssummary";
?>
		<div class="tab-pane <?php echo $user_edit->DetailPages->pageStyle("vtranssummary") ?>" id="tab_vtranssummary"><!-- page* -->
<?php include_once "vtranssummarygrid.php" ?>
		</div><!-- /page* -->
<?php } ?>
<?php
	if (in_array("useremailaccount", explode(",", $user->getCurrentDetailTable())) && $useremailaccount->DetailEdit) {
		if ($firstActiveDetailTable == "" || $firstActiveDetailTable == "useremailaccount")
			$firstActiveDetailTable = "useremailaccount";
?>
		<div class="tab-pane <?php echo $user_edit->DetailPages->pageStyle("useremailaccount") ?>" id="tab_useremailaccount"><!-- page* -->
<?php include_once "useremailaccountgrid.php" ?>
		</div><!-- /page* -->
<?php } ?>
<?php
	if (in_array("userpi", explode(",", $user->getCurrentDetailTable())) && $userpi->DetailEdit) {
		if ($firstActiveDetailTable == "" || $firstActiveDetailTable == "userpi")
			$firstActiveDetailTable = "userpi";
?>
		<div class="tab-pane <?php echo $user_edit->DetailPages->pageStyle("userpi") ?>" id="tab_userpi"><!-- page* -->
<?php include_once "userpigrid.php" ?>
		</div><!-- /page* -->
<?php } ?>
<?php
	if (in_array("userpurchase", explode(",", $user->getCurrentDetailTable())) && $userpurchase->DetailEdit) {
		if ($firstActiveDetailTable == "" || $firstActiveDetailTable == "userpurchase")
			$firstActiveDetailTable = "userpurchase";
?>
		<div class="tab-pane <?php echo $user_edit->DetailPages->pageStyle("userpurchase") ?>" id="tab_userpurchase"><!-- page* -->
<?php include_once "userpurchasegrid.php" ?>
		</div><!-- /page* -->
<?php } ?>
<?php
	if (in_array("loanlimits", explode(",", $user->getCurrentDetailTable())) && $loanlimits->DetailEdit) {
		if ($firstActiveDetailTable == "" || $firstActiveDetailTable == "loanlimits")
			$firstActiveDetailTable = "loanlimits";
?>
		<div class="tab-pane <?php echo $user_edit->DetailPages->pageStyle("loanlimits") ?>" id="tab_loanlimits"><!-- page* -->
<?php include_once "loanlimitsgrid.php" ?>
		</div><!-- /page* -->
<?php } ?>
<?php
	if (in_array("userkycdocs", explode(",", $user->getCurrentDetailTable())) && $userkycdocs->DetailEdit) {
		if ($firstActiveDetailTable == "" || $firstActiveDetailTable == "userkycdocs")
			$firstActiveDetailTable = "userkycdocs";
?>
		<div class="tab-pane <?php echo $user_edit->DetailPages->pageStyle("userkycdocs") ?>" id="tab_userkycdocs"><!-- page* -->
<?php include_once "userkycdocsgrid.php" ?>
		</div><!-- /page* -->
<?php } ?>
<?php
	if (in_array("acctbalance", explode(",", $user->getCurrentDetailTable())) && $acctbalance->DetailEdit) {
		if ($firstActiveDetailTable == "" || $firstActiveDetailTable == "acctbalance")
			$firstActiveDetailTable = "acctbalance";
?>
		<div class="tab-pane <?php echo $user_edit->DetailPages->pageStyle("acctbalance") ?>" id="tab_acctbalance"><!-- page* -->
<?php include_once "acctbalancegrid.php" ?>
		</div><!-- /page* -->
<?php } ?>
<?php
	if (in_array("userdevices", explode(",", $user->getCurrentDetailTable())) && $userdevices->DetailEdit) {
		if ($firstActiveDetailTable == "" || $firstActiveDetailTable == "userdevices")
			$firstActiveDetailTable = "userdevices";
?>
		<div class="tab-pane <?php echo $user_edit->DetailPages->pageStyle("userdevices") ?>" id="tab_userdevices"><!-- page* -->
<?php include_once "userdevicesgrid.php" ?>
		</div><!-- /page* -->
<?php } ?>
<?php
	if (in_array("usercommission", explode(",", $user->getCurrentDetailTable())) && $usercommission->DetailEdit) {
		if ($firstActiveDetailTable == "" || $firstActiveDetailTable == "usercommission")
			$firstActiveDetailTable = "usercommission";
?>
		<div class="tab-pane <?php echo $user_edit->DetailPages->pageStyle("usercommission") ?>" id="tab_usercommission"><!-- page* -->
<?php include_once "usercommissiongrid.php" ?>
		</div><!-- /page* -->
<?php } ?>
	</div><!-- /.tab-content -->
</div><!-- /tabs -->
</div><!-- /detail-pages -->
<?php } ?>
<?php if (!$user_edit->IsModal) { ?>
<div class="form-group row"><!-- buttons .form-group -->
	<div class="<?php echo $user_edit->OffsetColumnClass ?>"><!-- buttons offset -->
<button class="btn btn-primary ew-btn" name="btn-action" id="btn-action" type="submit"><?php echo $Language->phrase("SaveBtn") ?></button>
<button class="btn btn-default ew-btn" name="btn-cancel" id="btn-cancel" type="button" data-href="<?php echo $user_edit->getReturnUrl() ?>"><?php echo $Language->phrase("CancelBtn") ?></button>
	</div><!-- /buttons offset -->
</div><!-- /buttons .form-group -->
<?php } ?>
</form>
<?php
$user_edit->showPageFooter();
if (Config("DEBUG"))
	echo GetDebugMessage();
?>
<script>
loadjs.ready("load", function() {

	// Startup script
	// Write your table-specific startup script here
	// console.log("page loaded");

});
</script>
<?php include_once "footer.php"; ?>
<?php
$user_edit->terminate();
?>