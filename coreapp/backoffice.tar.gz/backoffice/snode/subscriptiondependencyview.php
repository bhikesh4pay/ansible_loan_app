<?php
namespace PHPMaker2020\_4payadmin;

// Autoload
include_once "autoload.php";

// Session
if (session_status() !== PHP_SESSION_ACTIVE)
	\Delight\Cookie\Session::start(Config("COOKIE_SAMESITE")); // Init session data

// Output buffering
ob_start();
?>
<?php

// Write header
WriteHeader(FALSE);

// Create page object
$subscriptiondependency_view = new subscriptiondependency_view();

// Run the page
$subscriptiondependency_view->run();

// Setup login status
SetupLoginStatus();
SetClientVar("login", LoginStatus());

// Global Page Rendering event (in userfn*.php)
Page_Rendering();

// Page Rendering event
$subscriptiondependency_view->Page_Render();
?>
<?php include_once "header.php"; ?>
<?php if (!$subscriptiondependency_view->isExport()) { ?>
<script>
var fsubscriptiondependencyview, currentPageID;
loadjs.ready("head", function() {

	// Form object
	currentPageID = ew.PAGE_ID = "view";
	fsubscriptiondependencyview = currentForm = new ew.Form("fsubscriptiondependencyview", "view");
	loadjs.done("fsubscriptiondependencyview");
});
</script>
<script>
loadjs.ready("head", function() {

	// Client script
	// Write your client script here, no need to add script tags.

});
</script>
<?php } ?>
<?php if (!$subscriptiondependency_view->isExport()) { ?>
<div class="btn-toolbar ew-toolbar">
<?php $subscriptiondependency_view->ExportOptions->render("body") ?>
<?php $subscriptiondependency_view->OtherOptions->render("body") ?>
<div class="clearfix"></div>
</div>
<?php } ?>
<?php $subscriptiondependency_view->showPageHeader(); ?>
<?php
$subscriptiondependency_view->showMessage();
?>
<form name="fsubscriptiondependencyview" id="fsubscriptiondependencyview" class="form-inline ew-form ew-view-form" action="<?php echo CurrentPageName() ?>" method="post">
<?php if ($Page->CheckToken) { ?>
<input type="hidden" name="<?php echo Config("TOKEN_NAME") ?>" value="<?php echo $Page->Token ?>">
<?php } ?>
<input type="hidden" name="t" value="subscriptiondependency">
<input type="hidden" name="modal" value="<?php echo (int)$subscriptiondependency_view->IsModal ?>">
<table class="table table-striped table-sm ew-view-table">
<?php if ($subscriptiondependency_view->subscriptionid->Visible) { // subscriptionid ?>
	<tr id="r_subscriptionid">
		<td class="<?php echo $subscriptiondependency_view->TableLeftColumnClass ?>"><span id="elh_subscriptiondependency_subscriptionid"><?php echo $subscriptiondependency_view->subscriptionid->caption() ?></span></td>
		<td data-name="subscriptionid" <?php echo $subscriptiondependency_view->subscriptionid->cellAttributes() ?>>
<span id="el_subscriptiondependency_subscriptionid">
<span<?php echo $subscriptiondependency_view->subscriptionid->viewAttributes() ?>><?php echo $subscriptiondependency_view->subscriptionid->getViewValue() ?></span>
</span>
</td>
	</tr>
<?php } ?>
<?php if ($subscriptiondependency_view->othersubscriptionid->Visible) { // othersubscriptionid ?>
	<tr id="r_othersubscriptionid">
		<td class="<?php echo $subscriptiondependency_view->TableLeftColumnClass ?>"><span id="elh_subscriptiondependency_othersubscriptionid"><?php echo $subscriptiondependency_view->othersubscriptionid->caption() ?></span></td>
		<td data-name="othersubscriptionid" <?php echo $subscriptiondependency_view->othersubscriptionid->cellAttributes() ?>>
<span id="el_subscriptiondependency_othersubscriptionid">
<span<?php echo $subscriptiondependency_view->othersubscriptionid->viewAttributes() ?>><?php echo $subscriptiondependency_view->othersubscriptionid->getViewValue() ?></span>
</span>
</td>
	</tr>
<?php } ?>
<?php if ($subscriptiondependency_view->active->Visible) { // active ?>
	<tr id="r_active">
		<td class="<?php echo $subscriptiondependency_view->TableLeftColumnClass ?>"><span id="elh_subscriptiondependency_active"><?php echo $subscriptiondependency_view->active->caption() ?></span></td>
		<td data-name="active" <?php echo $subscriptiondependency_view->active->cellAttributes() ?>>
<span id="el_subscriptiondependency_active">
<span<?php echo $subscriptiondependency_view->active->viewAttributes() ?>><?php echo $subscriptiondependency_view->active->getViewValue() ?></span>
</span>
</td>
	</tr>
<?php } ?>
</table>
</form>
<?php
$subscriptiondependency_view->showPageFooter();
if (Config("DEBUG"))
	echo GetDebugMessage();
?>
<?php if (!$subscriptiondependency_view->isExport()) { ?>
<script>
loadjs.ready("load", function() {

	// Startup script
	// Write your table-specific startup script here
	// console.log("page loaded");

});
</script>
<?php } ?>
<?php include_once "footer.php"; ?>
<?php
$subscriptiondependency_view->terminate();
?>