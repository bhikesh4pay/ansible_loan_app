<?php
namespace PHPMaker2020\_4payadmin;

// Autoload
include_once "autoload.php";

// Session
if (session_status() !== PHP_SESSION_ACTIVE)
	\Delight\Cookie\Session::start(Config("COOKIE_SAMESITE")); // Init session data

// Output buffering
ob_start();
?>
<?php

// Write header
WriteHeader(FALSE);

// Create page object
$loantierhistory_list = new loantierhistory_list();

// Run the page
$loantierhistory_list->run();

// Setup login status
SetupLoginStatus();
SetClientVar("login", LoginStatus());

// Global Page Rendering event (in userfn*.php)
Page_Rendering();

// Page Rendering event
$loantierhistory_list->Page_Render();
?>
<?php include_once "header.php"; ?>
<?php if (!$loantierhistory_list->isExport()) { ?>
<script>
var floantierhistorylist, currentPageID;
loadjs.ready("head", function() {

	// Form object
	currentPageID = ew.PAGE_ID = "list";
	floantierhistorylist = currentForm = new ew.Form("floantierhistorylist", "list");
	floantierhistorylist.formKeyCountName = '<?php echo $loantierhistory_list->FormKeyCountName ?>';
	loadjs.done("floantierhistorylist");
});
var floantierhistorylistsrch;
loadjs.ready("head", function() {

	// Form object for search
	floantierhistorylistsrch = currentSearchForm = new ew.Form("floantierhistorylistsrch");

	// Dynamic selection lists
	// Filters

	floantierhistorylistsrch.filterList = <?php echo $loantierhistory_list->getFilterList() ?>;
	loadjs.done("floantierhistorylistsrch");
});
</script>
<style type="text/css">
.ew-table-preview-row { /* main table preview row color */
	background-color: #FFFFFF; /* preview row color */
}
.ew-table-preview-row .ew-grid {
	display: table;
}
</style>
<div id="ew-preview" class="d-none"><!-- preview -->
	<div class="ew-nav-tabs"><!-- .ew-nav-tabs -->
		<ul class="nav nav-tabs"></ul>
		<div class="tab-content"><!-- .tab-content -->
			<div class="tab-pane fade active show"></div>
		</div><!-- /.tab-content -->
	</div><!-- /.ew-nav-tabs -->
</div><!-- /preview -->
<script>
loadjs.ready("head", function() {
	ew.PREVIEW_PLACEMENT = ew.CSS_FLIP ? "right" : "left";
	ew.PREVIEW_SINGLE_ROW = false;
	ew.PREVIEW_OVERLAY = false;
	loadjs("js/ewpreview.js", "preview");
});
</script>
<script>
loadjs.ready("head", function() {

	// Client script
	// Write your client script here, no need to add script tags.

});
</script>
<?php } ?>
<?php if (!$loantierhistory_list->isExport()) { ?>
<div class="btn-toolbar ew-toolbar">
<?php if ($loantierhistory_list->TotalRecords > 0 && $loantierhistory_list->ExportOptions->visible()) { ?>
<?php $loantierhistory_list->ExportOptions->render("body") ?>
<?php } ?>
<?php if ($loantierhistory_list->ImportOptions->visible()) { ?>
<?php $loantierhistory_list->ImportOptions->render("body") ?>
<?php } ?>
<?php if ($loantierhistory_list->SearchOptions->visible()) { ?>
<?php $loantierhistory_list->SearchOptions->render("body") ?>
<?php } ?>
<?php if ($loantierhistory_list->FilterOptions->visible()) { ?>
<?php $loantierhistory_list->FilterOptions->render("body") ?>
<?php } ?>
<div class="clearfix"></div>
</div>
<?php } ?>
<?php if (!$loantierhistory_list->isExport() || Config("EXPORT_MASTER_RECORD") && $loantierhistory_list->isExport("print")) { ?>
<?php
if ($loantierhistory_list->DbMasterFilter != "" && $loantierhistory->getCurrentMasterTable() == "loanlimits") {
	if ($loantierhistory_list->MasterRecordExists) {
		include_once "loanlimitsmaster.php";
	}
}
?>
<?php } ?>
<?php
$loantierhistory_list->renderOtherOptions();
?>
<?php $loantierhistory_list->showPageHeader(); ?>
<?php
$loantierhistory_list->showMessage();
?>
<?php if ($loantierhistory_list->TotalRecords > 0 || $loantierhistory->CurrentAction) { ?>
<div class="card ew-card ew-grid<?php if ($loantierhistory_list->isAddOrEdit()) { ?> ew-grid-add-edit<?php } ?> loantierhistory">
<form name="floantierhistorylist" id="floantierhistorylist" class="form-inline ew-form ew-list-form" action="<?php echo CurrentPageName() ?>" method="post">
<?php if ($Page->CheckToken) { ?>
<input type="hidden" name="<?php echo Config("TOKEN_NAME") ?>" value="<?php echo $Page->Token ?>">
<?php } ?>
<input type="hidden" name="t" value="loantierhistory">
<?php if ($loantierhistory->getCurrentMasterTable() == "loanlimits" && $loantierhistory->CurrentAction) { ?>
<input type="hidden" name="<?php echo Config("TABLE_SHOW_MASTER") ?>" value="loanlimits">
<input type="hidden" name="fk__userid" value="<?php echo HtmlEncode($loantierhistory_list->_userid->getSessionValue()) ?>">
<input type="hidden" name="fk_currcode" value="<?php echo HtmlEncode($loantierhistory_list->curr->getSessionValue()) ?>">
<?php } ?>
<div id="gmp_loantierhistory" class="<?php echo ResponsiveTableClass() ?>card-body ew-grid-middle-panel">
<?php if ($loantierhistory_list->TotalRecords > 0 || $loantierhistory_list->isGridEdit()) { ?>
<table id="tbl_loantierhistorylist" class="table ew-table"><!-- .ew-table -->
<thead>
	<tr class="ew-table-header">
<?php

// Header row
$loantierhistory->RowType = ROWTYPE_HEADER;

// Render list options
$loantierhistory_list->renderListOptions();

// Render list options (header, left)
$loantierhistory_list->ListOptions->render("header", "left");
?>
<?php if ($loantierhistory_list->changeid->Visible) { // changeid ?>
	<?php if ($loantierhistory_list->SortUrl($loantierhistory_list->changeid) == "") { ?>
		<th data-name="changeid" class="<?php echo $loantierhistory_list->changeid->headerCellClass() ?>"><div id="elh_loantierhistory_changeid" class="loantierhistory_changeid"><div class="ew-table-header-caption"><?php echo $loantierhistory_list->changeid->caption() ?></div></div></th>
	<?php } else { ?>
		<th data-name="changeid" class="<?php echo $loantierhistory_list->changeid->headerCellClass() ?>"><div class="ew-pointer" onclick="ew.sort(event, '<?php echo $loantierhistory_list->SortUrl($loantierhistory_list->changeid) ?>', 1);"><div id="elh_loantierhistory_changeid" class="loantierhistory_changeid">
			<div class="ew-table-header-btn"><span class="ew-table-header-caption"><?php echo $loantierhistory_list->changeid->caption() ?></span><span class="ew-table-header-sort"><?php if ($loantierhistory_list->changeid->getSort() == "ASC") { ?><i class="fas fa-sort-up"></i><?php } elseif ($loantierhistory_list->changeid->getSort() == "DESC") { ?><i class="fas fa-sort-down"></i><?php } ?></span></div>
		</div></div></th>
	<?php } ?>
<?php } ?>
<?php if ($loantierhistory_list->_userid->Visible) { // userid ?>
	<?php if ($loantierhistory_list->SortUrl($loantierhistory_list->_userid) == "") { ?>
		<th data-name="_userid" class="<?php echo $loantierhistory_list->_userid->headerCellClass() ?>"><div id="elh_loantierhistory__userid" class="loantierhistory__userid"><div class="ew-table-header-caption"><?php echo $loantierhistory_list->_userid->caption() ?></div></div></th>
	<?php } else { ?>
		<th data-name="_userid" class="<?php echo $loantierhistory_list->_userid->headerCellClass() ?>"><div class="ew-pointer" onclick="ew.sort(event, '<?php echo $loantierhistory_list->SortUrl($loantierhistory_list->_userid) ?>', 1);"><div id="elh_loantierhistory__userid" class="loantierhistory__userid">
			<div class="ew-table-header-btn"><span class="ew-table-header-caption"><?php echo $loantierhistory_list->_userid->caption() ?></span><span class="ew-table-header-sort"><?php if ($loantierhistory_list->_userid->getSort() == "ASC") { ?><i class="fas fa-sort-up"></i><?php } elseif ($loantierhistory_list->_userid->getSort() == "DESC") { ?><i class="fas fa-sort-down"></i><?php } ?></span></div>
		</div></div></th>
	<?php } ?>
<?php } ?>
<?php if ($loantierhistory_list->curr->Visible) { // curr ?>
	<?php if ($loantierhistory_list->SortUrl($loantierhistory_list->curr) == "") { ?>
		<th data-name="curr" class="<?php echo $loantierhistory_list->curr->headerCellClass() ?>"><div id="elh_loantierhistory_curr" class="loantierhistory_curr"><div class="ew-table-header-caption"><?php echo $loantierhistory_list->curr->caption() ?></div></div></th>
	<?php } else { ?>
		<th data-name="curr" class="<?php echo $loantierhistory_list->curr->headerCellClass() ?>"><div class="ew-pointer" onclick="ew.sort(event, '<?php echo $loantierhistory_list->SortUrl($loantierhistory_list->curr) ?>', 1);"><div id="elh_loantierhistory_curr" class="loantierhistory_curr">
			<div class="ew-table-header-btn"><span class="ew-table-header-caption"><?php echo $loantierhistory_list->curr->caption() ?></span><span class="ew-table-header-sort"><?php if ($loantierhistory_list->curr->getSort() == "ASC") { ?><i class="fas fa-sort-up"></i><?php } elseif ($loantierhistory_list->curr->getSort() == "DESC") { ?><i class="fas fa-sort-down"></i><?php } ?></span></div>
		</div></div></th>
	<?php } ?>
<?php } ?>
<?php if ($loantierhistory_list->fromtier->Visible) { // fromtier ?>
	<?php if ($loantierhistory_list->SortUrl($loantierhistory_list->fromtier) == "") { ?>
		<th data-name="fromtier" class="<?php echo $loantierhistory_list->fromtier->headerCellClass() ?>"><div id="elh_loantierhistory_fromtier" class="loantierhistory_fromtier"><div class="ew-table-header-caption"><?php echo $loantierhistory_list->fromtier->caption() ?></div></div></th>
	<?php } else { ?>
		<th data-name="fromtier" class="<?php echo $loantierhistory_list->fromtier->headerCellClass() ?>"><div class="ew-pointer" onclick="ew.sort(event, '<?php echo $loantierhistory_list->SortUrl($loantierhistory_list->fromtier) ?>', 1);"><div id="elh_loantierhistory_fromtier" class="loantierhistory_fromtier">
			<div class="ew-table-header-btn"><span class="ew-table-header-caption"><?php echo $loantierhistory_list->fromtier->caption() ?></span><span class="ew-table-header-sort"><?php if ($loantierhistory_list->fromtier->getSort() == "ASC") { ?><i class="fas fa-sort-up"></i><?php } elseif ($loantierhistory_list->fromtier->getSort() == "DESC") { ?><i class="fas fa-sort-down"></i><?php } ?></span></div>
		</div></div></th>
	<?php } ?>
<?php } ?>
<?php if ($loantierhistory_list->totier->Visible) { // totier ?>
	<?php if ($loantierhistory_list->SortUrl($loantierhistory_list->totier) == "") { ?>
		<th data-name="totier" class="<?php echo $loantierhistory_list->totier->headerCellClass() ?>"><div id="elh_loantierhistory_totier" class="loantierhistory_totier"><div class="ew-table-header-caption"><?php echo $loantierhistory_list->totier->caption() ?></div></div></th>
	<?php } else { ?>
		<th data-name="totier" class="<?php echo $loantierhistory_list->totier->headerCellClass() ?>"><div class="ew-pointer" onclick="ew.sort(event, '<?php echo $loantierhistory_list->SortUrl($loantierhistory_list->totier) ?>', 1);"><div id="elh_loantierhistory_totier" class="loantierhistory_totier">
			<div class="ew-table-header-btn"><span class="ew-table-header-caption"><?php echo $loantierhistory_list->totier->caption() ?></span><span class="ew-table-header-sort"><?php if ($loantierhistory_list->totier->getSort() == "ASC") { ?><i class="fas fa-sort-up"></i><?php } elseif ($loantierhistory_list->totier->getSort() == "DESC") { ?><i class="fas fa-sort-down"></i><?php } ?></span></div>
		</div></div></th>
	<?php } ?>
<?php } ?>
<?php if ($loantierhistory_list->changedate->Visible) { // changedate ?>
	<?php if ($loantierhistory_list->SortUrl($loantierhistory_list->changedate) == "") { ?>
		<th data-name="changedate" class="<?php echo $loantierhistory_list->changedate->headerCellClass() ?>"><div id="elh_loantierhistory_changedate" class="loantierhistory_changedate"><div class="ew-table-header-caption"><?php echo $loantierhistory_list->changedate->caption() ?></div></div></th>
	<?php } else { ?>
		<th data-name="changedate" class="<?php echo $loantierhistory_list->changedate->headerCellClass() ?>"><div class="ew-pointer" onclick="ew.sort(event, '<?php echo $loantierhistory_list->SortUrl($loantierhistory_list->changedate) ?>', 1);"><div id="elh_loantierhistory_changedate" class="loantierhistory_changedate">
			<div class="ew-table-header-btn"><span class="ew-table-header-caption"><?php echo $loantierhistory_list->changedate->caption() ?></span><span class="ew-table-header-sort"><?php if ($loantierhistory_list->changedate->getSort() == "ASC") { ?><i class="fas fa-sort-up"></i><?php } elseif ($loantierhistory_list->changedate->getSort() == "DESC") { ?><i class="fas fa-sort-down"></i><?php } ?></span></div>
		</div></div></th>
	<?php } ?>
<?php } ?>
<?php

// Render list options (header, right)
$loantierhistory_list->ListOptions->render("header", "right");
?>
	</tr>
</thead>
<tbody>
<?php
if ($loantierhistory_list->ExportAll && $loantierhistory_list->isExport()) {
	$loantierhistory_list->StopRecord = $loantierhistory_list->TotalRecords;
} else {

	// Set the last record to display
	if ($loantierhistory_list->TotalRecords > $loantierhistory_list->StartRecord + $loantierhistory_list->DisplayRecords - 1)
		$loantierhistory_list->StopRecord = $loantierhistory_list->StartRecord + $loantierhistory_list->DisplayRecords - 1;
	else
		$loantierhistory_list->StopRecord = $loantierhistory_list->TotalRecords;
}
$loantierhistory_list->RecordCount = $loantierhistory_list->StartRecord - 1;
if ($loantierhistory_list->Recordset && !$loantierhistory_list->Recordset->EOF) {
	$loantierhistory_list->Recordset->moveFirst();
	$selectLimit = $loantierhistory_list->UseSelectLimit;
	if (!$selectLimit && $loantierhistory_list->StartRecord > 1)
		$loantierhistory_list->Recordset->move($loantierhistory_list->StartRecord - 1);
} elseif (!$loantierhistory->AllowAddDeleteRow && $loantierhistory_list->StopRecord == 0) {
	$loantierhistory_list->StopRecord = $loantierhistory->GridAddRowCount;
}

// Initialize aggregate
$loantierhistory->RowType = ROWTYPE_AGGREGATEINIT;
$loantierhistory->resetAttributes();
$loantierhistory_list->renderRow();
while ($loantierhistory_list->RecordCount < $loantierhistory_list->StopRecord) {
	$loantierhistory_list->RecordCount++;
	if ($loantierhistory_list->RecordCount >= $loantierhistory_list->StartRecord) {
		$loantierhistory_list->RowCount++;

		// Set up key count
		$loantierhistory_list->KeyCount = $loantierhistory_list->RowIndex;

		// Init row class and style
		$loantierhistory->resetAttributes();
		$loantierhistory->CssClass = "";
		if ($loantierhistory_list->isGridAdd()) {
		} else {
			$loantierhistory_list->loadRowValues($loantierhistory_list->Recordset); // Load row values
		}
		$loantierhistory->RowType = ROWTYPE_VIEW; // Render view

		// Set up row id / data-rowindex
		$loantierhistory->RowAttrs->merge(["data-rowindex" => $loantierhistory_list->RowCount, "id" => "r" . $loantierhistory_list->RowCount . "_loantierhistory", "data-rowtype" => $loantierhistory->RowType]);

		// Render row
		$loantierhistory_list->renderRow();

		// Render list options
		$loantierhistory_list->renderListOptions();
?>
	<tr <?php echo $loantierhistory->rowAttributes() ?>>
<?php

// Render list options (body, left)
$loantierhistory_list->ListOptions->render("body", "left", $loantierhistory_list->RowCount);
?>
	<?php if ($loantierhistory_list->changeid->Visible) { // changeid ?>
		<td data-name="changeid" <?php echo $loantierhistory_list->changeid->cellAttributes() ?>>
<span id="el<?php echo $loantierhistory_list->RowCount ?>_loantierhistory_changeid">
<span<?php echo $loantierhistory_list->changeid->viewAttributes() ?>><?php echo $loantierhistory_list->changeid->getViewValue() ?></span>
</span>
</td>
	<?php } ?>
	<?php if ($loantierhistory_list->_userid->Visible) { // userid ?>
		<td data-name="_userid" <?php echo $loantierhistory_list->_userid->cellAttributes() ?>>
<span id="el<?php echo $loantierhistory_list->RowCount ?>_loantierhistory__userid">
<span<?php echo $loantierhistory_list->_userid->viewAttributes() ?>><?php if (!EmptyString($loantierhistory_list->_userid->getViewValue()) && $loantierhistory_list->_userid->linkAttributes() != "") { ?>
<a<?php echo $loantierhistory_list->_userid->linkAttributes() ?>><?php echo $loantierhistory_list->_userid->getViewValue() ?></a>
<?php } else { ?>
<?php echo $loantierhistory_list->_userid->getViewValue() ?>
<?php } ?></span>
</span>
</td>
	<?php } ?>
	<?php if ($loantierhistory_list->curr->Visible) { // curr ?>
		<td data-name="curr" <?php echo $loantierhistory_list->curr->cellAttributes() ?>>
<span id="el<?php echo $loantierhistory_list->RowCount ?>_loantierhistory_curr">
<span<?php echo $loantierhistory_list->curr->viewAttributes() ?>><?php echo $loantierhistory_list->curr->getViewValue() ?></span>
</span>
</td>
	<?php } ?>
	<?php if ($loantierhistory_list->fromtier->Visible) { // fromtier ?>
		<td data-name="fromtier" <?php echo $loantierhistory_list->fromtier->cellAttributes() ?>>
<span id="el<?php echo $loantierhistory_list->RowCount ?>_loantierhistory_fromtier">
<span<?php echo $loantierhistory_list->fromtier->viewAttributes() ?>><?php echo $loantierhistory_list->fromtier->getViewValue() ?></span>
</span>
</td>
	<?php } ?>
	<?php if ($loantierhistory_list->totier->Visible) { // totier ?>
		<td data-name="totier" <?php echo $loantierhistory_list->totier->cellAttributes() ?>>
<span id="el<?php echo $loantierhistory_list->RowCount ?>_loantierhistory_totier">
<span<?php echo $loantierhistory_list->totier->viewAttributes() ?>><?php echo $loantierhistory_list->totier->getViewValue() ?></span>
</span>
</td>
	<?php } ?>
	<?php if ($loantierhistory_list->changedate->Visible) { // changedate ?>
		<td data-name="changedate" <?php echo $loantierhistory_list->changedate->cellAttributes() ?>>
<span id="el<?php echo $loantierhistory_list->RowCount ?>_loantierhistory_changedate">
<span<?php echo $loantierhistory_list->changedate->viewAttributes() ?>><?php echo $loantierhistory_list->changedate->getViewValue() ?></span>
</span>
</td>
	<?php } ?>
<?php

// Render list options (body, right)
$loantierhistory_list->ListOptions->render("body", "right", $loantierhistory_list->RowCount);
?>
	</tr>
<?php
	}
	if (!$loantierhistory_list->isGridAdd())
		$loantierhistory_list->Recordset->moveNext();
}
?>
</tbody>
</table><!-- /.ew-table -->
<?php } ?>
</div><!-- /.ew-grid-middle-panel -->
<?php if (!$loantierhistory->CurrentAction) { ?>
<input type="hidden" name="action" id="action" value="">
<?php } ?>
</form><!-- /.ew-list-form -->
<?php

// Close recordset
if ($loantierhistory_list->Recordset)
	$loantierhistory_list->Recordset->Close();
?>
<?php if (!$loantierhistory_list->isExport()) { ?>
<div class="card-footer ew-grid-lower-panel">
<?php if (!$loantierhistory_list->isGridAdd()) { ?>
<form name="ew-pager-form" class="form-inline ew-form ew-pager-form" action="<?php echo CurrentPageName() ?>">
<?php echo $loantierhistory_list->Pager->render() ?>
</form>
<?php } ?>
<div class="ew-list-other-options">
<?php $loantierhistory_list->OtherOptions->render("body", "bottom") ?>
</div>
<div class="clearfix"></div>
</div>
<?php } ?>
</div><!-- /.ew-grid -->
<?php } ?>
<?php if ($loantierhistory_list->TotalRecords == 0 && !$loantierhistory->CurrentAction) { // Show other options ?>
<div class="ew-list-other-options">
<?php $loantierhistory_list->OtherOptions->render("body") ?>
</div>
<div class="clearfix"></div>
<?php } ?>
<?php
$loantierhistory_list->showPageFooter();
if (Config("DEBUG"))
	echo GetDebugMessage();
?>
<?php if (!$loantierhistory_list->isExport()) { ?>
<script>
loadjs.ready("load", function() {

	// Startup script
	// Write your table-specific startup script here
	// console.log("page loaded");

});
</script>
<?php } ?>
<?php include_once "footer.php"; ?>
<?php
$loantierhistory_list->terminate();
?>