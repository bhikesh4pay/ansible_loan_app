<?php
namespace PHPMaker2020\_4payadmin;

// Autoload
include_once "autoload.php";

// Session
if (session_status() !== PHP_SESSION_ACTIVE)
	\Delight\Cookie\Session::start(Config("COOKIE_SAMESITE")); // Init session data

// Output buffering
ob_start();
?>
<?php

// Write header
WriteHeader(FALSE);

// Create page object
$merchantsales_view = new merchantsales_view();

// Run the page
$merchantsales_view->run();

// Setup login status
SetupLoginStatus();
SetClientVar("login", LoginStatus());

// Global Page Rendering event (in userfn*.php)
Page_Rendering();

// Page Rendering event
$merchantsales_view->Page_Render();
?>
<?php include_once "header.php"; ?>
<?php if (!$merchantsales_view->isExport()) { ?>
<script>
var fmerchantsalesview, currentPageID;
loadjs.ready("head", function() {

	// Form object
	currentPageID = ew.PAGE_ID = "view";
	fmerchantsalesview = currentForm = new ew.Form("fmerchantsalesview", "view");
	loadjs.done("fmerchantsalesview");
});
</script>
<script>
loadjs.ready("head", function() {

	// Client script
	// Write your client script here, no need to add script tags.

});
</script>
<?php } ?>
<?php if (!$merchantsales_view->isExport()) { ?>
<div class="btn-toolbar ew-toolbar">
<?php $merchantsales_view->ExportOptions->render("body") ?>
<?php $merchantsales_view->OtherOptions->render("body") ?>
<div class="clearfix"></div>
</div>
<?php } ?>
<?php $merchantsales_view->showPageHeader(); ?>
<?php
$merchantsales_view->showMessage();
?>
<form name="fmerchantsalesview" id="fmerchantsalesview" class="form-inline ew-form ew-view-form" action="<?php echo CurrentPageName() ?>" method="post">
<?php if ($Page->CheckToken) { ?>
<input type="hidden" name="<?php echo Config("TOKEN_NAME") ?>" value="<?php echo $Page->Token ?>">
<?php } ?>
<input type="hidden" name="t" value="merchantsales">
<input type="hidden" name="modal" value="<?php echo (int)$merchantsales_view->IsModal ?>">
<table class="table table-striped table-sm ew-view-table">
<?php if ($merchantsales_view->transferID->Visible) { // transferID ?>
	<tr id="r_transferID">
		<td class="<?php echo $merchantsales_view->TableLeftColumnClass ?>"><span id="elh_merchantsales_transferID"><?php echo $merchantsales_view->transferID->caption() ?></span></td>
		<td data-name="transferID" <?php echo $merchantsales_view->transferID->cellAttributes() ?>>
<span id="el_merchantsales_transferID">
<span<?php echo $merchantsales_view->transferID->viewAttributes() ?>><?php echo $merchantsales_view->transferID->getViewValue() ?></span>
</span>
</td>
	</tr>
<?php } ?>
<?php if ($merchantsales_view->txid->Visible) { // txid ?>
	<tr id="r_txid">
		<td class="<?php echo $merchantsales_view->TableLeftColumnClass ?>"><span id="elh_merchantsales_txid"><?php echo $merchantsales_view->txid->caption() ?></span></td>
		<td data-name="txid" <?php echo $merchantsales_view->txid->cellAttributes() ?>>
<span id="el_merchantsales_txid">
<span<?php echo $merchantsales_view->txid->viewAttributes() ?>><?php echo $merchantsales_view->txid->getViewValue() ?></span>
</span>
</td>
	</tr>
<?php } ?>
<?php if ($merchantsales_view->merchantID->Visible) { // merchantID ?>
	<tr id="r_merchantID">
		<td class="<?php echo $merchantsales_view->TableLeftColumnClass ?>"><span id="elh_merchantsales_merchantID"><?php echo $merchantsales_view->merchantID->caption() ?></span></td>
		<td data-name="merchantID" <?php echo $merchantsales_view->merchantID->cellAttributes() ?>>
<span id="el_merchantsales_merchantID">
<span<?php echo $merchantsales_view->merchantID->viewAttributes() ?>><?php echo $merchantsales_view->merchantID->getViewValue() ?></span>
</span>
</td>
	</tr>
<?php } ?>
<?php if ($merchantsales_view->_userID->Visible) { // userID ?>
	<tr id="r__userID">
		<td class="<?php echo $merchantsales_view->TableLeftColumnClass ?>"><span id="elh_merchantsales__userID"><?php echo $merchantsales_view->_userID->caption() ?></span></td>
		<td data-name="_userID" <?php echo $merchantsales_view->_userID->cellAttributes() ?>>
<span id="el_merchantsales__userID">
<span<?php echo $merchantsales_view->_userID->viewAttributes() ?>><?php echo $merchantsales_view->_userID->getViewValue() ?></span>
</span>
</td>
	</tr>
<?php } ?>
<?php if ($merchantsales_view->transferTime->Visible) { // transferTime ?>
	<tr id="r_transferTime">
		<td class="<?php echo $merchantsales_view->TableLeftColumnClass ?>"><span id="elh_merchantsales_transferTime"><?php echo $merchantsales_view->transferTime->caption() ?></span></td>
		<td data-name="transferTime" <?php echo $merchantsales_view->transferTime->cellAttributes() ?>>
<span id="el_merchantsales_transferTime">
<span<?php echo $merchantsales_view->transferTime->viewAttributes() ?>><?php echo $merchantsales_view->transferTime->getViewValue() ?></span>
</span>
</td>
	</tr>
<?php } ?>
<?php if ($merchantsales_view->currID->Visible) { // currID ?>
	<tr id="r_currID">
		<td class="<?php echo $merchantsales_view->TableLeftColumnClass ?>"><span id="elh_merchantsales_currID"><?php echo $merchantsales_view->currID->caption() ?></span></td>
		<td data-name="currID" <?php echo $merchantsales_view->currID->cellAttributes() ?>>
<span id="el_merchantsales_currID">
<span<?php echo $merchantsales_view->currID->viewAttributes() ?>><?php echo $merchantsales_view->currID->getViewValue() ?></span>
</span>
</td>
	</tr>
<?php } ?>
<?php if ($merchantsales_view->purchaseAmount->Visible) { // purchaseAmount ?>
	<tr id="r_purchaseAmount">
		<td class="<?php echo $merchantsales_view->TableLeftColumnClass ?>"><span id="elh_merchantsales_purchaseAmount"><?php echo $merchantsales_view->purchaseAmount->caption() ?></span></td>
		<td data-name="purchaseAmount" <?php echo $merchantsales_view->purchaseAmount->cellAttributes() ?>>
<span id="el_merchantsales_purchaseAmount">
<span<?php echo $merchantsales_view->purchaseAmount->viewAttributes() ?>><?php echo $merchantsales_view->purchaseAmount->getViewValue() ?></span>
</span>
</td>
	</tr>
<?php } ?>
<?php if ($merchantsales_view->merchantSurcharge->Visible) { // merchantSurcharge ?>
	<tr id="r_merchantSurcharge">
		<td class="<?php echo $merchantsales_view->TableLeftColumnClass ?>"><span id="elh_merchantsales_merchantSurcharge"><?php echo $merchantsales_view->merchantSurcharge->caption() ?></span></td>
		<td data-name="merchantSurcharge" <?php echo $merchantsales_view->merchantSurcharge->cellAttributes() ?>>
<span id="el_merchantsales_merchantSurcharge">
<span<?php echo $merchantsales_view->merchantSurcharge->viewAttributes() ?>><?php echo $merchantsales_view->merchantSurcharge->getViewValue() ?></span>
</span>
</td>
	</tr>
<?php } ?>
<?php if ($merchantsales_view->taxAmount->Visible) { // taxAmount ?>
	<tr id="r_taxAmount">
		<td class="<?php echo $merchantsales_view->TableLeftColumnClass ?>"><span id="elh_merchantsales_taxAmount"><?php echo $merchantsales_view->taxAmount->caption() ?></span></td>
		<td data-name="taxAmount" <?php echo $merchantsales_view->taxAmount->cellAttributes() ?>>
<span id="el_merchantsales_taxAmount">
<span<?php echo $merchantsales_view->taxAmount->viewAttributes() ?>><?php echo $merchantsales_view->taxAmount->getViewValue() ?></span>
</span>
</td>
	</tr>
<?php } ?>
<?php if ($merchantsales_view->tipAmount->Visible) { // tipAmount ?>
	<tr id="r_tipAmount">
		<td class="<?php echo $merchantsales_view->TableLeftColumnClass ?>"><span id="elh_merchantsales_tipAmount"><?php echo $merchantsales_view->tipAmount->caption() ?></span></td>
		<td data-name="tipAmount" <?php echo $merchantsales_view->tipAmount->cellAttributes() ?>>
<span id="el_merchantsales_tipAmount">
<span<?php echo $merchantsales_view->tipAmount->viewAttributes() ?>><?php echo $merchantsales_view->tipAmount->getViewValue() ?></span>
</span>
</td>
	</tr>
<?php } ?>
<?php if ($merchantsales_view->serviceFeeToCustomer->Visible) { // serviceFeeToCustomer ?>
	<tr id="r_serviceFeeToCustomer">
		<td class="<?php echo $merchantsales_view->TableLeftColumnClass ?>"><span id="elh_merchantsales_serviceFeeToCustomer"><?php echo $merchantsales_view->serviceFeeToCustomer->caption() ?></span></td>
		<td data-name="serviceFeeToCustomer" <?php echo $merchantsales_view->serviceFeeToCustomer->cellAttributes() ?>>
<span id="el_merchantsales_serviceFeeToCustomer">
<span<?php echo $merchantsales_view->serviceFeeToCustomer->viewAttributes() ?>><?php echo $merchantsales_view->serviceFeeToCustomer->getViewValue() ?></span>
</span>
</td>
	</tr>
<?php } ?>
<?php if ($merchantsales_view->TotalAmountForCustomer->Visible) { // TotalAmountForCustomer ?>
	<tr id="r_TotalAmountForCustomer">
		<td class="<?php echo $merchantsales_view->TableLeftColumnClass ?>"><span id="elh_merchantsales_TotalAmountForCustomer"><?php echo $merchantsales_view->TotalAmountForCustomer->caption() ?></span></td>
		<td data-name="TotalAmountForCustomer" <?php echo $merchantsales_view->TotalAmountForCustomer->cellAttributes() ?>>
<span id="el_merchantsales_TotalAmountForCustomer">
<span<?php echo $merchantsales_view->TotalAmountForCustomer->viewAttributes() ?>><?php echo $merchantsales_view->TotalAmountForCustomer->getViewValue() ?></span>
</span>
</td>
	</tr>
<?php } ?>
<?php if ($merchantsales_view->serviceFeeToMerchant->Visible) { // serviceFeeToMerchant ?>
	<tr id="r_serviceFeeToMerchant">
		<td class="<?php echo $merchantsales_view->TableLeftColumnClass ?>"><span id="elh_merchantsales_serviceFeeToMerchant"><?php echo $merchantsales_view->serviceFeeToMerchant->caption() ?></span></td>
		<td data-name="serviceFeeToMerchant" <?php echo $merchantsales_view->serviceFeeToMerchant->cellAttributes() ?>>
<span id="el_merchantsales_serviceFeeToMerchant">
<span<?php echo $merchantsales_view->serviceFeeToMerchant->viewAttributes() ?>><?php echo $merchantsales_view->serviceFeeToMerchant->getViewValue() ?></span>
</span>
</td>
	</tr>
<?php } ?>
<?php if ($merchantsales_view->status->Visible) { // status ?>
	<tr id="r_status">
		<td class="<?php echo $merchantsales_view->TableLeftColumnClass ?>"><span id="elh_merchantsales_status"><?php echo $merchantsales_view->status->caption() ?></span></td>
		<td data-name="status" <?php echo $merchantsales_view->status->cellAttributes() ?>>
<span id="el_merchantsales_status">
<span<?php echo $merchantsales_view->status->viewAttributes() ?>><?php echo $merchantsales_view->status->getViewValue() ?></span>
</span>
</td>
	</tr>
<?php } ?>
<?php if ($merchantsales_view->shoppingCartID->Visible) { // shoppingCartID ?>
	<tr id="r_shoppingCartID">
		<td class="<?php echo $merchantsales_view->TableLeftColumnClass ?>"><span id="elh_merchantsales_shoppingCartID"><?php echo $merchantsales_view->shoppingCartID->caption() ?></span></td>
		<td data-name="shoppingCartID" <?php echo $merchantsales_view->shoppingCartID->cellAttributes() ?>>
<span id="el_merchantsales_shoppingCartID">
<span<?php echo $merchantsales_view->shoppingCartID->viewAttributes() ?>><?php echo $merchantsales_view->shoppingCartID->getViewValue() ?></span>
</span>
</td>
	</tr>
<?php } ?>
<?php if ($merchantsales_view->merchantRefID->Visible) { // merchantRefID ?>
	<tr id="r_merchantRefID">
		<td class="<?php echo $merchantsales_view->TableLeftColumnClass ?>"><span id="elh_merchantsales_merchantRefID"><?php echo $merchantsales_view->merchantRefID->caption() ?></span></td>
		<td data-name="merchantRefID" <?php echo $merchantsales_view->merchantRefID->cellAttributes() ?>>
<span id="el_merchantsales_merchantRefID">
<span<?php echo $merchantsales_view->merchantRefID->viewAttributes() ?>><?php echo $merchantsales_view->merchantRefID->getViewValue() ?></span>
</span>
</td>
	</tr>
<?php } ?>
<?php if ($merchantsales_view->feeid->Visible) { // feeid ?>
	<tr id="r_feeid">
		<td class="<?php echo $merchantsales_view->TableLeftColumnClass ?>"><span id="elh_merchantsales_feeid"><?php echo $merchantsales_view->feeid->caption() ?></span></td>
		<td data-name="feeid" <?php echo $merchantsales_view->feeid->cellAttributes() ?>>
<span id="el_merchantsales_feeid">
<span<?php echo $merchantsales_view->feeid->viewAttributes() ?>><?php echo $merchantsales_view->feeid->getViewValue() ?></span>
</span>
</td>
	</tr>
<?php } ?>
<?php if ($merchantsales_view->ratetabletype->Visible) { // ratetabletype ?>
	<tr id="r_ratetabletype">
		<td class="<?php echo $merchantsales_view->TableLeftColumnClass ?>"><span id="elh_merchantsales_ratetabletype"><?php echo $merchantsales_view->ratetabletype->caption() ?></span></td>
		<td data-name="ratetabletype" <?php echo $merchantsales_view->ratetabletype->cellAttributes() ?>>
<span id="el_merchantsales_ratetabletype">
<span<?php echo $merchantsales_view->ratetabletype->viewAttributes() ?>><?php echo $merchantsales_view->ratetabletype->getViewValue() ?></span>
</span>
</td>
	</tr>
<?php } ?>
<?php if ($merchantsales_view->pis->Visible) { // pis ?>
	<tr id="r_pis">
		<td class="<?php echo $merchantsales_view->TableLeftColumnClass ?>"><span id="elh_merchantsales_pis"><?php echo $merchantsales_view->pis->caption() ?></span></td>
		<td data-name="pis" <?php echo $merchantsales_view->pis->cellAttributes() ?>>
<span id="el_merchantsales_pis">
<span<?php echo $merchantsales_view->pis->viewAttributes() ?>><?php echo $merchantsales_view->pis->getViewValue() ?></span>
</span>
</td>
	</tr>
<?php } ?>
<?php if ($merchantsales_view->feesystemshare->Visible) { // feesystemshare ?>
	<tr id="r_feesystemshare">
		<td class="<?php echo $merchantsales_view->TableLeftColumnClass ?>"><span id="elh_merchantsales_feesystemshare"><?php echo $merchantsales_view->feesystemshare->caption() ?></span></td>
		<td data-name="feesystemshare" <?php echo $merchantsales_view->feesystemshare->cellAttributes() ?>>
<span id="el_merchantsales_feesystemshare">
<span<?php echo $merchantsales_view->feesystemshare->viewAttributes() ?>><?php echo $merchantsales_view->feesystemshare->getViewValue() ?></span>
</span>
</td>
	</tr>
<?php } ?>
<?php if ($merchantsales_view->feeexternalshare->Visible) { // feeexternalshare ?>
	<tr id="r_feeexternalshare">
		<td class="<?php echo $merchantsales_view->TableLeftColumnClass ?>"><span id="elh_merchantsales_feeexternalshare"><?php echo $merchantsales_view->feeexternalshare->caption() ?></span></td>
		<td data-name="feeexternalshare" <?php echo $merchantsales_view->feeexternalshare->cellAttributes() ?>>
<span id="el_merchantsales_feeexternalshare">
<span<?php echo $merchantsales_view->feeexternalshare->viewAttributes() ?>><?php echo $merchantsales_view->feeexternalshare->getViewValue() ?></span>
</span>
</td>
	</tr>
<?php } ?>
<?php if ($merchantsales_view->feefranchiseeshare->Visible) { // feefranchiseeshare ?>
	<tr id="r_feefranchiseeshare">
		<td class="<?php echo $merchantsales_view->TableLeftColumnClass ?>"><span id="elh_merchantsales_feefranchiseeshare"><?php echo $merchantsales_view->feefranchiseeshare->caption() ?></span></td>
		<td data-name="feefranchiseeshare" <?php echo $merchantsales_view->feefranchiseeshare->cellAttributes() ?>>
<span id="el_merchantsales_feefranchiseeshare">
<span<?php echo $merchantsales_view->feefranchiseeshare->viewAttributes() ?>><?php echo $merchantsales_view->feefranchiseeshare->getViewValue() ?></span>
</span>
</td>
	</tr>
<?php } ?>
<?php if ($merchantsales_view->feeresellershare->Visible) { // feeresellershare ?>
	<tr id="r_feeresellershare">
		<td class="<?php echo $merchantsales_view->TableLeftColumnClass ?>"><span id="elh_merchantsales_feeresellershare"><?php echo $merchantsales_view->feeresellershare->caption() ?></span></td>
		<td data-name="feeresellershare" <?php echo $merchantsales_view->feeresellershare->cellAttributes() ?>>
<span id="el_merchantsales_feeresellershare">
<span<?php echo $merchantsales_view->feeresellershare->viewAttributes() ?>><?php echo $merchantsales_view->feeresellershare->getViewValue() ?></span>
</span>
</td>
	</tr>
<?php } ?>
<?php if ($merchantsales_view->lastupdatetime->Visible) { // lastupdatetime ?>
	<tr id="r_lastupdatetime">
		<td class="<?php echo $merchantsales_view->TableLeftColumnClass ?>"><span id="elh_merchantsales_lastupdatetime"><?php echo $merchantsales_view->lastupdatetime->caption() ?></span></td>
		<td data-name="lastupdatetime" <?php echo $merchantsales_view->lastupdatetime->cellAttributes() ?>>
<span id="el_merchantsales_lastupdatetime">
<span<?php echo $merchantsales_view->lastupdatetime->viewAttributes() ?>><?php echo $merchantsales_view->lastupdatetime->getViewValue() ?></span>
</span>
</td>
	</tr>
<?php } ?>
<?php if ($merchantsales_view->expirationTimeInMinutes->Visible) { // expirationTimeInMinutes ?>
	<tr id="r_expirationTimeInMinutes">
		<td class="<?php echo $merchantsales_view->TableLeftColumnClass ?>"><span id="elh_merchantsales_expirationTimeInMinutes"><?php echo $merchantsales_view->expirationTimeInMinutes->caption() ?></span></td>
		<td data-name="expirationTimeInMinutes" <?php echo $merchantsales_view->expirationTimeInMinutes->cellAttributes() ?>>
<span id="el_merchantsales_expirationTimeInMinutes">
<span<?php echo $merchantsales_view->expirationTimeInMinutes->viewAttributes() ?>><?php echo $merchantsales_view->expirationTimeInMinutes->getViewValue() ?></span>
</span>
</td>
	</tr>
<?php } ?>
<?php if ($merchantsales_view->expirationTime->Visible) { // expirationTime ?>
	<tr id="r_expirationTime">
		<td class="<?php echo $merchantsales_view->TableLeftColumnClass ?>"><span id="elh_merchantsales_expirationTime"><?php echo $merchantsales_view->expirationTime->caption() ?></span></td>
		<td data-name="expirationTime" <?php echo $merchantsales_view->expirationTime->cellAttributes() ?>>
<span id="el_merchantsales_expirationTime">
<span<?php echo $merchantsales_view->expirationTime->viewAttributes() ?>><?php echo $merchantsales_view->expirationTime->getViewValue() ?></span>
</span>
</td>
	</tr>
<?php } ?>
<?php if ($merchantsales_view->customeruserid->Visible) { // customeruserid ?>
	<tr id="r_customeruserid">
		<td class="<?php echo $merchantsales_view->TableLeftColumnClass ?>"><span id="elh_merchantsales_customeruserid"><?php echo $merchantsales_view->customeruserid->caption() ?></span></td>
		<td data-name="customeruserid" <?php echo $merchantsales_view->customeruserid->cellAttributes() ?>>
<span id="el_merchantsales_customeruserid">
<span<?php echo $merchantsales_view->customeruserid->viewAttributes() ?>><?php echo $merchantsales_view->customeruserid->getViewValue() ?></span>
</span>
</td>
	</tr>
<?php } ?>
<?php if ($merchantsales_view->serviceFeeToCustomerbk1amt->Visible) { // serviceFeeToCustomerbk1amt ?>
	<tr id="r_serviceFeeToCustomerbk1amt">
		<td class="<?php echo $merchantsales_view->TableLeftColumnClass ?>"><span id="elh_merchantsales_serviceFeeToCustomerbk1amt"><?php echo $merchantsales_view->serviceFeeToCustomerbk1amt->caption() ?></span></td>
		<td data-name="serviceFeeToCustomerbk1amt" <?php echo $merchantsales_view->serviceFeeToCustomerbk1amt->cellAttributes() ?>>
<span id="el_merchantsales_serviceFeeToCustomerbk1amt">
<span<?php echo $merchantsales_view->serviceFeeToCustomerbk1amt->viewAttributes() ?>><?php echo $merchantsales_view->serviceFeeToCustomerbk1amt->getViewValue() ?></span>
</span>
</td>
	</tr>
<?php } ?>
<?php if ($merchantsales_view->serviceFeeToCustomerbk1type->Visible) { // serviceFeeToCustomerbk1type ?>
	<tr id="r_serviceFeeToCustomerbk1type">
		<td class="<?php echo $merchantsales_view->TableLeftColumnClass ?>"><span id="elh_merchantsales_serviceFeeToCustomerbk1type"><?php echo $merchantsales_view->serviceFeeToCustomerbk1type->caption() ?></span></td>
		<td data-name="serviceFeeToCustomerbk1type" <?php echo $merchantsales_view->serviceFeeToCustomerbk1type->cellAttributes() ?>>
<span id="el_merchantsales_serviceFeeToCustomerbk1type">
<span<?php echo $merchantsales_view->serviceFeeToCustomerbk1type->viewAttributes() ?>><?php echo $merchantsales_view->serviceFeeToCustomerbk1type->getViewValue() ?></span>
</span>
</td>
	</tr>
<?php } ?>
<?php if ($merchantsales_view->serviceFeeToCustomerbk2amt->Visible) { // serviceFeeToCustomerbk2amt ?>
	<tr id="r_serviceFeeToCustomerbk2amt">
		<td class="<?php echo $merchantsales_view->TableLeftColumnClass ?>"><span id="elh_merchantsales_serviceFeeToCustomerbk2amt"><?php echo $merchantsales_view->serviceFeeToCustomerbk2amt->caption() ?></span></td>
		<td data-name="serviceFeeToCustomerbk2amt" <?php echo $merchantsales_view->serviceFeeToCustomerbk2amt->cellAttributes() ?>>
<span id="el_merchantsales_serviceFeeToCustomerbk2amt">
<span<?php echo $merchantsales_view->serviceFeeToCustomerbk2amt->viewAttributes() ?>><?php echo $merchantsales_view->serviceFeeToCustomerbk2amt->getViewValue() ?></span>
</span>
</td>
	</tr>
<?php } ?>
<?php if ($merchantsales_view->serviceFeeToCustomerbk2type->Visible) { // serviceFeeToCustomerbk2type ?>
	<tr id="r_serviceFeeToCustomerbk2type">
		<td class="<?php echo $merchantsales_view->TableLeftColumnClass ?>"><span id="elh_merchantsales_serviceFeeToCustomerbk2type"><?php echo $merchantsales_view->serviceFeeToCustomerbk2type->caption() ?></span></td>
		<td data-name="serviceFeeToCustomerbk2type" <?php echo $merchantsales_view->serviceFeeToCustomerbk2type->cellAttributes() ?>>
<span id="el_merchantsales_serviceFeeToCustomerbk2type">
<span<?php echo $merchantsales_view->serviceFeeToCustomerbk2type->viewAttributes() ?>><?php echo $merchantsales_view->serviceFeeToCustomerbk2type->getViewValue() ?></span>
</span>
</td>
	</tr>
<?php } ?>
<?php if ($merchantsales_view->serviceFeeToCustomerbk3amt->Visible) { // serviceFeeToCustomerbk3amt ?>
	<tr id="r_serviceFeeToCustomerbk3amt">
		<td class="<?php echo $merchantsales_view->TableLeftColumnClass ?>"><span id="elh_merchantsales_serviceFeeToCustomerbk3amt"><?php echo $merchantsales_view->serviceFeeToCustomerbk3amt->caption() ?></span></td>
		<td data-name="serviceFeeToCustomerbk3amt" <?php echo $merchantsales_view->serviceFeeToCustomerbk3amt->cellAttributes() ?>>
<span id="el_merchantsales_serviceFeeToCustomerbk3amt">
<span<?php echo $merchantsales_view->serviceFeeToCustomerbk3amt->viewAttributes() ?>><?php echo $merchantsales_view->serviceFeeToCustomerbk3amt->getViewValue() ?></span>
</span>
</td>
	</tr>
<?php } ?>
<?php if ($merchantsales_view->serviceFeeToCustomerbk3type->Visible) { // serviceFeeToCustomerbk3type ?>
	<tr id="r_serviceFeeToCustomerbk3type">
		<td class="<?php echo $merchantsales_view->TableLeftColumnClass ?>"><span id="elh_merchantsales_serviceFeeToCustomerbk3type"><?php echo $merchantsales_view->serviceFeeToCustomerbk3type->caption() ?></span></td>
		<td data-name="serviceFeeToCustomerbk3type" <?php echo $merchantsales_view->serviceFeeToCustomerbk3type->cellAttributes() ?>>
<span id="el_merchantsales_serviceFeeToCustomerbk3type">
<span<?php echo $merchantsales_view->serviceFeeToCustomerbk3type->viewAttributes() ?>><?php echo $merchantsales_view->serviceFeeToCustomerbk3type->getViewValue() ?></span>
</span>
</td>
	</tr>
<?php } ?>
<?php if ($merchantsales_view->taxAmountbk1amt->Visible) { // taxAmountbk1amt ?>
	<tr id="r_taxAmountbk1amt">
		<td class="<?php echo $merchantsales_view->TableLeftColumnClass ?>"><span id="elh_merchantsales_taxAmountbk1amt"><?php echo $merchantsales_view->taxAmountbk1amt->caption() ?></span></td>
		<td data-name="taxAmountbk1amt" <?php echo $merchantsales_view->taxAmountbk1amt->cellAttributes() ?>>
<span id="el_merchantsales_taxAmountbk1amt">
<span<?php echo $merchantsales_view->taxAmountbk1amt->viewAttributes() ?>><?php echo $merchantsales_view->taxAmountbk1amt->getViewValue() ?></span>
</span>
</td>
	</tr>
<?php } ?>
<?php if ($merchantsales_view->taxAmountbk1type->Visible) { // taxAmountbk1type ?>
	<tr id="r_taxAmountbk1type">
		<td class="<?php echo $merchantsales_view->TableLeftColumnClass ?>"><span id="elh_merchantsales_taxAmountbk1type"><?php echo $merchantsales_view->taxAmountbk1type->caption() ?></span></td>
		<td data-name="taxAmountbk1type" <?php echo $merchantsales_view->taxAmountbk1type->cellAttributes() ?>>
<span id="el_merchantsales_taxAmountbk1type">
<span<?php echo $merchantsales_view->taxAmountbk1type->viewAttributes() ?>><?php echo $merchantsales_view->taxAmountbk1type->getViewValue() ?></span>
</span>
</td>
	</tr>
<?php } ?>
<?php if ($merchantsales_view->taxAmountbk2amt->Visible) { // taxAmountbk2amt ?>
	<tr id="r_taxAmountbk2amt">
		<td class="<?php echo $merchantsales_view->TableLeftColumnClass ?>"><span id="elh_merchantsales_taxAmountbk2amt"><?php echo $merchantsales_view->taxAmountbk2amt->caption() ?></span></td>
		<td data-name="taxAmountbk2amt" <?php echo $merchantsales_view->taxAmountbk2amt->cellAttributes() ?>>
<span id="el_merchantsales_taxAmountbk2amt">
<span<?php echo $merchantsales_view->taxAmountbk2amt->viewAttributes() ?>><?php echo $merchantsales_view->taxAmountbk2amt->getViewValue() ?></span>
</span>
</td>
	</tr>
<?php } ?>
<?php if ($merchantsales_view->taxAmountbk2type->Visible) { // taxAmountbk2type ?>
	<tr id="r_taxAmountbk2type">
		<td class="<?php echo $merchantsales_view->TableLeftColumnClass ?>"><span id="elh_merchantsales_taxAmountbk2type"><?php echo $merchantsales_view->taxAmountbk2type->caption() ?></span></td>
		<td data-name="taxAmountbk2type" <?php echo $merchantsales_view->taxAmountbk2type->cellAttributes() ?>>
<span id="el_merchantsales_taxAmountbk2type">
<span<?php echo $merchantsales_view->taxAmountbk2type->viewAttributes() ?>><?php echo $merchantsales_view->taxAmountbk2type->getViewValue() ?></span>
</span>
</td>
	</tr>
<?php } ?>
<?php if ($merchantsales_view->taxAmountbk3amt->Visible) { // taxAmountbk3amt ?>
	<tr id="r_taxAmountbk3amt">
		<td class="<?php echo $merchantsales_view->TableLeftColumnClass ?>"><span id="elh_merchantsales_taxAmountbk3amt"><?php echo $merchantsales_view->taxAmountbk3amt->caption() ?></span></td>
		<td data-name="taxAmountbk3amt" <?php echo $merchantsales_view->taxAmountbk3amt->cellAttributes() ?>>
<span id="el_merchantsales_taxAmountbk3amt">
<span<?php echo $merchantsales_view->taxAmountbk3amt->viewAttributes() ?>><?php echo $merchantsales_view->taxAmountbk3amt->getViewValue() ?></span>
</span>
</td>
	</tr>
<?php } ?>
<?php if ($merchantsales_view->taxAmountbk3type->Visible) { // taxAmountbk3type ?>
	<tr id="r_taxAmountbk3type">
		<td class="<?php echo $merchantsales_view->TableLeftColumnClass ?>"><span id="elh_merchantsales_taxAmountbk3type"><?php echo $merchantsales_view->taxAmountbk3type->caption() ?></span></td>
		<td data-name="taxAmountbk3type" <?php echo $merchantsales_view->taxAmountbk3type->cellAttributes() ?>>
<span id="el_merchantsales_taxAmountbk3type">
<span<?php echo $merchantsales_view->taxAmountbk3type->viewAttributes() ?>><?php echo $merchantsales_view->taxAmountbk3type->getViewValue() ?></span>
</span>
</td>
	</tr>
<?php } ?>
<?php if ($merchantsales_view->originalpurchaseamount->Visible) { // originalpurchaseamount ?>
	<tr id="r_originalpurchaseamount">
		<td class="<?php echo $merchantsales_view->TableLeftColumnClass ?>"><span id="elh_merchantsales_originalpurchaseamount"><?php echo $merchantsales_view->originalpurchaseamount->caption() ?></span></td>
		<td data-name="originalpurchaseamount" <?php echo $merchantsales_view->originalpurchaseamount->cellAttributes() ?>>
<span id="el_merchantsales_originalpurchaseamount">
<span<?php echo $merchantsales_view->originalpurchaseamount->viewAttributes() ?>><?php echo $merchantsales_view->originalpurchaseamount->getViewValue() ?></span>
</span>
</td>
	</tr>
<?php } ?>
<?php if ($merchantsales_view->discountamount->Visible) { // discountamount ?>
	<tr id="r_discountamount">
		<td class="<?php echo $merchantsales_view->TableLeftColumnClass ?>"><span id="elh_merchantsales_discountamount"><?php echo $merchantsales_view->discountamount->caption() ?></span></td>
		<td data-name="discountamount" <?php echo $merchantsales_view->discountamount->cellAttributes() ?>>
<span id="el_merchantsales_discountamount">
<span<?php echo $merchantsales_view->discountamount->viewAttributes() ?>><?php echo $merchantsales_view->discountamount->getViewValue() ?></span>
</span>
</td>
	</tr>
<?php } ?>
<?php if ($merchantsales_view->discountpercentage->Visible) { // discountpercentage ?>
	<tr id="r_discountpercentage">
		<td class="<?php echo $merchantsales_view->TableLeftColumnClass ?>"><span id="elh_merchantsales_discountpercentage"><?php echo $merchantsales_view->discountpercentage->caption() ?></span></td>
		<td data-name="discountpercentage" <?php echo $merchantsales_view->discountpercentage->cellAttributes() ?>>
<span id="el_merchantsales_discountpercentage">
<span<?php echo $merchantsales_view->discountpercentage->viewAttributes() ?>><?php echo $merchantsales_view->discountpercentage->getViewValue() ?></span>
</span>
</td>
	</tr>
<?php } ?>
<?php if ($merchantsales_view->customerpurchaseid->Visible) { // customerpurchaseid ?>
	<tr id="r_customerpurchaseid">
		<td class="<?php echo $merchantsales_view->TableLeftColumnClass ?>"><span id="elh_merchantsales_customerpurchaseid"><?php echo $merchantsales_view->customerpurchaseid->caption() ?></span></td>
		<td data-name="customerpurchaseid" <?php echo $merchantsales_view->customerpurchaseid->cellAttributes() ?>>
<span id="el_merchantsales_customerpurchaseid">
<span<?php echo $merchantsales_view->customerpurchaseid->viewAttributes() ?>><?php echo $merchantsales_view->customerpurchaseid->getViewValue() ?></span>
</span>
</td>
	</tr>
<?php } ?>
<?php if ($merchantsales_view->userpiid->Visible) { // userpiid ?>
	<tr id="r_userpiid">
		<td class="<?php echo $merchantsales_view->TableLeftColumnClass ?>"><span id="elh_merchantsales_userpiid"><?php echo $merchantsales_view->userpiid->caption() ?></span></td>
		<td data-name="userpiid" <?php echo $merchantsales_view->userpiid->cellAttributes() ?>>
<span id="el_merchantsales_userpiid">
<span<?php echo $merchantsales_view->userpiid->viewAttributes() ?>><?php echo $merchantsales_view->userpiid->getViewValue() ?></span>
</span>
</td>
	</tr>
<?php } ?>
<?php if ($merchantsales_view->originalMerchantSurcharge->Visible) { // originalMerchantSurcharge ?>
	<tr id="r_originalMerchantSurcharge">
		<td class="<?php echo $merchantsales_view->TableLeftColumnClass ?>"><span id="elh_merchantsales_originalMerchantSurcharge"><?php echo $merchantsales_view->originalMerchantSurcharge->caption() ?></span></td>
		<td data-name="originalMerchantSurcharge" <?php echo $merchantsales_view->originalMerchantSurcharge->cellAttributes() ?>>
<span id="el_merchantsales_originalMerchantSurcharge">
<span<?php echo $merchantsales_view->originalMerchantSurcharge->viewAttributes() ?>><?php echo $merchantsales_view->originalMerchantSurcharge->getViewValue() ?></span>
</span>
</td>
	</tr>
<?php } ?>
<?php if ($merchantsales_view->originalTaxAmount->Visible) { // originalTaxAmount ?>
	<tr id="r_originalTaxAmount">
		<td class="<?php echo $merchantsales_view->TableLeftColumnClass ?>"><span id="elh_merchantsales_originalTaxAmount"><?php echo $merchantsales_view->originalTaxAmount->caption() ?></span></td>
		<td data-name="originalTaxAmount" <?php echo $merchantsales_view->originalTaxAmount->cellAttributes() ?>>
<span id="el_merchantsales_originalTaxAmount">
<span<?php echo $merchantsales_view->originalTaxAmount->viewAttributes() ?>><?php echo $merchantsales_view->originalTaxAmount->getViewValue() ?></span>
</span>
</td>
	</tr>
<?php } ?>
<?php if ($merchantsales_view->originalServiceFeeToCustomer->Visible) { // originalServiceFeeToCustomer ?>
	<tr id="r_originalServiceFeeToCustomer">
		<td class="<?php echo $merchantsales_view->TableLeftColumnClass ?>"><span id="elh_merchantsales_originalServiceFeeToCustomer"><?php echo $merchantsales_view->originalServiceFeeToCustomer->caption() ?></span></td>
		<td data-name="originalServiceFeeToCustomer" <?php echo $merchantsales_view->originalServiceFeeToCustomer->cellAttributes() ?>>
<span id="el_merchantsales_originalServiceFeeToCustomer">
<span<?php echo $merchantsales_view->originalServiceFeeToCustomer->viewAttributes() ?>><?php echo $merchantsales_view->originalServiceFeeToCustomer->getViewValue() ?></span>
</span>
</td>
	</tr>
<?php } ?>
<?php if ($merchantsales_view->originalTotalAmountForCustomer->Visible) { // originalTotalAmountForCustomer ?>
	<tr id="r_originalTotalAmountForCustomer">
		<td class="<?php echo $merchantsales_view->TableLeftColumnClass ?>"><span id="elh_merchantsales_originalTotalAmountForCustomer"><?php echo $merchantsales_view->originalTotalAmountForCustomer->caption() ?></span></td>
		<td data-name="originalTotalAmountForCustomer" <?php echo $merchantsales_view->originalTotalAmountForCustomer->cellAttributes() ?>>
<span id="el_merchantsales_originalTotalAmountForCustomer">
<span<?php echo $merchantsales_view->originalTotalAmountForCustomer->viewAttributes() ?>><?php echo $merchantsales_view->originalTotalAmountForCustomer->getViewValue() ?></span>
</span>
</td>
	</tr>
<?php } ?>
<?php if ($merchantsales_view->originalServiceFeeToMerchant->Visible) { // originalServiceFeeToMerchant ?>
	<tr id="r_originalServiceFeeToMerchant">
		<td class="<?php echo $merchantsales_view->TableLeftColumnClass ?>"><span id="elh_merchantsales_originalServiceFeeToMerchant"><?php echo $merchantsales_view->originalServiceFeeToMerchant->caption() ?></span></td>
		<td data-name="originalServiceFeeToMerchant" <?php echo $merchantsales_view->originalServiceFeeToMerchant->cellAttributes() ?>>
<span id="el_merchantsales_originalServiceFeeToMerchant">
<span<?php echo $merchantsales_view->originalServiceFeeToMerchant->viewAttributes() ?>><?php echo $merchantsales_view->originalServiceFeeToMerchant->getViewValue() ?></span>
</span>
</td>
	</tr>
<?php } ?>
<?php if ($merchantsales_view->originalTipAmount->Visible) { // originalTipAmount ?>
	<tr id="r_originalTipAmount">
		<td class="<?php echo $merchantsales_view->TableLeftColumnClass ?>"><span id="elh_merchantsales_originalTipAmount"><?php echo $merchantsales_view->originalTipAmount->caption() ?></span></td>
		<td data-name="originalTipAmount" <?php echo $merchantsales_view->originalTipAmount->cellAttributes() ?>>
<span id="el_merchantsales_originalTipAmount">
<span<?php echo $merchantsales_view->originalTipAmount->viewAttributes() ?>><?php echo $merchantsales_view->originalTipAmount->getViewValue() ?></span>
</span>
</td>
	</tr>
<?php } ?>
</table>
</form>
<?php
$merchantsales_view->showPageFooter();
if (Config("DEBUG"))
	echo GetDebugMessage();
?>
<?php if (!$merchantsales_view->isExport()) { ?>
<script>
loadjs.ready("load", function() {

	// Startup script
	// Write your table-specific startup script here
	// console.log("page loaded");

});
</script>
<?php } ?>
<?php include_once "footer.php"; ?>
<?php
$merchantsales_view->terminate();
?>