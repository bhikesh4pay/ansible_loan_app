<?php
namespace PHPMaker2020\_4payadmin;

// Autoload
include_once "autoload.php";

// Session
if (session_status() !== PHP_SESSION_ACTIVE)
	\Delight\Cookie\Session::start(Config("COOKIE_SAMESITE")); // Init session data

// Output buffering
ob_start();
?>
<?php

// Write header
WriteHeader(FALSE);

// Create page object
$userexternaldeposits_edit = new userexternaldeposits_edit();

// Run the page
$userexternaldeposits_edit->run();

// Setup login status
SetupLoginStatus();
SetClientVar("login", LoginStatus());

// Global Page Rendering event (in userfn*.php)
Page_Rendering();

// Page Rendering event
$userexternaldeposits_edit->Page_Render();
?>
<?php include_once "header.php"; ?>
<script>
var fuserexternaldepositsedit, currentPageID;
loadjs.ready("head", function() {

	// Form object
	currentPageID = ew.PAGE_ID = "edit";
	fuserexternaldepositsedit = currentForm = new ew.Form("fuserexternaldepositsedit", "edit");

	// Validate form
	fuserexternaldepositsedit.validate = function() {
		if (!this.validateRequired)
			return true; // Ignore validation
		var $ = jQuery, fobj = this.getForm(), $fobj = $(fobj);
		if ($fobj.find("#confirm").val() == "confirm")
			return true;
		var elm, felm, uelm, addcnt = 0;
		var $k = $fobj.find("#" + this.formKeyCountName); // Get key_count
		var rowcnt = ($k[0]) ? parseInt($k.val(), 10) : 1;
		var startcnt = (rowcnt == 0) ? 0 : 1; // Check rowcnt == 0 => Inline-Add
		var gridinsert = ["insert", "gridinsert"].includes($fobj.find("#action").val()) && $k[0];
		for (var i = startcnt; i <= rowcnt; i++) {
			var infix = ($k[0]) ? String(i) : "";
			$fobj.data("rowindex", infix);
			<?php if ($userexternaldeposits_edit->depositid->Required) { ?>
				elm = this.getElements("x" + infix + "_depositid");
				if (elm && !ew.isHidden(elm) && !ew.hasValue(elm))
					return this.onError(elm, "<?php echo JsEncode(str_replace("%s", $userexternaldeposits_edit->depositid->caption(), $userexternaldeposits_edit->depositid->RequiredErrorMessage)) ?>");
			<?php } ?>
			<?php if ($userexternaldeposits_edit->_userid->Required) { ?>
				elm = this.getElements("x" + infix + "__userid");
				if (elm && !ew.isHidden(elm) && !ew.hasValue(elm))
					return this.onError(elm, "<?php echo JsEncode(str_replace("%s", $userexternaldeposits_edit->_userid->caption(), $userexternaldeposits_edit->_userid->RequiredErrorMessage)) ?>");
			<?php } ?>
				elm = this.getElements("x" + infix + "__userid");
				if (elm && !ew.checkInteger(elm.value))
					return this.onError(elm, "<?php echo JsEncode($userexternaldeposits_edit->_userid->errorMessage()) ?>");
			<?php if ($userexternaldeposits_edit->refno->Required) { ?>
				elm = this.getElements("x" + infix + "_refno");
				if (elm && !ew.isHidden(elm) && !ew.hasValue(elm))
					return this.onError(elm, "<?php echo JsEncode(str_replace("%s", $userexternaldeposits_edit->refno->caption(), $userexternaldeposits_edit->refno->RequiredErrorMessage)) ?>");
			<?php } ?>
			<?php if ($userexternaldeposits_edit->deposittime->Required) { ?>
				elm = this.getElements("x" + infix + "_deposittime");
				if (elm && !ew.isHidden(elm) && !ew.hasValue(elm))
					return this.onError(elm, "<?php echo JsEncode(str_replace("%s", $userexternaldeposits_edit->deposittime->caption(), $userexternaldeposits_edit->deposittime->RequiredErrorMessage)) ?>");
			<?php } ?>
				elm = this.getElements("x" + infix + "_deposittime");
				if (elm && !ew.checkDateDef(elm.value))
					return this.onError(elm, "<?php echo JsEncode($userexternaldeposits_edit->deposittime->errorMessage()) ?>");
			<?php if ($userexternaldeposits_edit->source->Required) { ?>
				elm = this.getElements("x" + infix + "_source");
				if (elm && !ew.isHidden(elm) && !ew.hasValue(elm))
					return this.onError(elm, "<?php echo JsEncode(str_replace("%s", $userexternaldeposits_edit->source->caption(), $userexternaldeposits_edit->source->RequiredErrorMessage)) ?>");
			<?php } ?>
			<?php if ($userexternaldeposits_edit->otherref->Required) { ?>
				elm = this.getElements("x" + infix + "_otherref");
				if (elm && !ew.isHidden(elm) && !ew.hasValue(elm))
					return this.onError(elm, "<?php echo JsEncode(str_replace("%s", $userexternaldeposits_edit->otherref->caption(), $userexternaldeposits_edit->otherref->RequiredErrorMessage)) ?>");
			<?php } ?>
			<?php if ($userexternaldeposits_edit->curr->Required) { ?>
				elm = this.getElements("x" + infix + "_curr");
				if (elm && !ew.isHidden(elm) && !ew.hasValue(elm))
					return this.onError(elm, "<?php echo JsEncode(str_replace("%s", $userexternaldeposits_edit->curr->caption(), $userexternaldeposits_edit->curr->RequiredErrorMessage)) ?>");
			<?php } ?>
			<?php if ($userexternaldeposits_edit->amount->Required) { ?>
				elm = this.getElements("x" + infix + "_amount");
				if (elm && !ew.isHidden(elm) && !ew.hasValue(elm))
					return this.onError(elm, "<?php echo JsEncode(str_replace("%s", $userexternaldeposits_edit->amount->caption(), $userexternaldeposits_edit->amount->RequiredErrorMessage)) ?>");
			<?php } ?>
				elm = this.getElements("x" + infix + "_amount");
				if (elm && !ew.checkNumber(elm.value))
					return this.onError(elm, "<?php echo JsEncode($userexternaldeposits_edit->amount->errorMessage()) ?>");
			<?php if ($userexternaldeposits_edit->piid->Required) { ?>
				elm = this.getElements("x" + infix + "_piid");
				if (elm && !ew.isHidden(elm) && !ew.hasValue(elm))
					return this.onError(elm, "<?php echo JsEncode(str_replace("%s", $userexternaldeposits_edit->piid->caption(), $userexternaldeposits_edit->piid->RequiredErrorMessage)) ?>");
			<?php } ?>
				elm = this.getElements("x" + infix + "_piid");
				if (elm && !ew.checkInteger(elm.value))
					return this.onError(elm, "<?php echo JsEncode($userexternaldeposits_edit->piid->errorMessage()) ?>");

				// Call Form_CustomValidate event
				if (!this.Form_CustomValidate(fobj))
					return false;
		}

		// Process detail forms
		var dfs = $fobj.find("input[name='detailpage']").get();
		for (var i = 0; i < dfs.length; i++) {
			var df = dfs[i], val = df.value;
			if (val && ew.forms[val])
				if (!ew.forms[val].validate())
					return false;
		}
		return true;
	}

	// Form_CustomValidate
	fuserexternaldepositsedit.Form_CustomValidate = function(fobj) { // DO NOT CHANGE THIS LINE!

		// Your custom validation code here, return false if invalid.
		return true;
	}

	// Use JavaScript validation or not
	fuserexternaldepositsedit.validateRequired = <?php echo Config("CLIENT_VALIDATE") ? "true" : "false" ?>;

	// Dynamic selection lists
	loadjs.done("fuserexternaldepositsedit");
});
</script>
<script>
loadjs.ready("head", function() {

	// Client script
	// Write your client script here, no need to add script tags.

});
</script>
<?php $userexternaldeposits_edit->showPageHeader(); ?>
<?php
$userexternaldeposits_edit->showMessage();
?>
<form name="fuserexternaldepositsedit" id="fuserexternaldepositsedit" class="<?php echo $userexternaldeposits_edit->FormClassName ?>" action="<?php echo CurrentPageName() ?>" method="post">
<?php if ($Page->CheckToken) { ?>
<input type="hidden" name="<?php echo Config("TOKEN_NAME") ?>" value="<?php echo $Page->Token ?>">
<?php } ?>
<input type="hidden" name="t" value="userexternaldeposits">
<input type="hidden" name="action" id="action" value="update">
<input type="hidden" name="modal" value="<?php echo (int)$userexternaldeposits_edit->IsModal ?>">
<div class="ew-edit-div"><!-- page* -->
<?php if ($userexternaldeposits_edit->depositid->Visible) { // depositid ?>
	<div id="r_depositid" class="form-group row">
		<label id="elh_userexternaldeposits_depositid" class="<?php echo $userexternaldeposits_edit->LeftColumnClass ?>"><?php echo $userexternaldeposits_edit->depositid->caption() ?><?php echo $userexternaldeposits_edit->depositid->Required ? $Language->phrase("FieldRequiredIndicator") : "" ?></label>
		<div class="<?php echo $userexternaldeposits_edit->RightColumnClass ?>"><div <?php echo $userexternaldeposits_edit->depositid->cellAttributes() ?>>
<span id="el_userexternaldeposits_depositid">
<span<?php echo $userexternaldeposits_edit->depositid->viewAttributes() ?>><input type="text" readonly class="form-control-plaintext" value="<?php echo HtmlEncode(RemoveHtml($userexternaldeposits_edit->depositid->EditValue)) ?>"></span>
</span>
<input type="hidden" data-table="userexternaldeposits" data-field="x_depositid" name="x_depositid" id="x_depositid" value="<?php echo HtmlEncode($userexternaldeposits_edit->depositid->CurrentValue) ?>">
<?php echo $userexternaldeposits_edit->depositid->CustomMsg ?></div></div>
	</div>
<?php } ?>
<?php if ($userexternaldeposits_edit->_userid->Visible) { // userid ?>
	<div id="r__userid" class="form-group row">
		<label id="elh_userexternaldeposits__userid" for="x__userid" class="<?php echo $userexternaldeposits_edit->LeftColumnClass ?>"><?php echo $userexternaldeposits_edit->_userid->caption() ?><?php echo $userexternaldeposits_edit->_userid->Required ? $Language->phrase("FieldRequiredIndicator") : "" ?></label>
		<div class="<?php echo $userexternaldeposits_edit->RightColumnClass ?>"><div <?php echo $userexternaldeposits_edit->_userid->cellAttributes() ?>>
<span id="el_userexternaldeposits__userid">
<input type="text" data-table="userexternaldeposits" data-field="x__userid" name="x__userid" id="x__userid" size="30" placeholder="<?php echo HtmlEncode($userexternaldeposits_edit->_userid->getPlaceHolder()) ?>" value="<?php echo $userexternaldeposits_edit->_userid->EditValue ?>"<?php echo $userexternaldeposits_edit->_userid->editAttributes() ?>>
</span>
<?php echo $userexternaldeposits_edit->_userid->CustomMsg ?></div></div>
	</div>
<?php } ?>
<?php if ($userexternaldeposits_edit->refno->Visible) { // refno ?>
	<div id="r_refno" class="form-group row">
		<label id="elh_userexternaldeposits_refno" for="x_refno" class="<?php echo $userexternaldeposits_edit->LeftColumnClass ?>"><?php echo $userexternaldeposits_edit->refno->caption() ?><?php echo $userexternaldeposits_edit->refno->Required ? $Language->phrase("FieldRequiredIndicator") : "" ?></label>
		<div class="<?php echo $userexternaldeposits_edit->RightColumnClass ?>"><div <?php echo $userexternaldeposits_edit->refno->cellAttributes() ?>>
<span id="el_userexternaldeposits_refno">
<input type="text" data-table="userexternaldeposits" data-field="x_refno" name="x_refno" id="x_refno" size="30" maxlength="20" placeholder="<?php echo HtmlEncode($userexternaldeposits_edit->refno->getPlaceHolder()) ?>" value="<?php echo $userexternaldeposits_edit->refno->EditValue ?>"<?php echo $userexternaldeposits_edit->refno->editAttributes() ?>>
</span>
<?php echo $userexternaldeposits_edit->refno->CustomMsg ?></div></div>
	</div>
<?php } ?>
<?php if ($userexternaldeposits_edit->deposittime->Visible) { // deposittime ?>
	<div id="r_deposittime" class="form-group row">
		<label id="elh_userexternaldeposits_deposittime" for="x_deposittime" class="<?php echo $userexternaldeposits_edit->LeftColumnClass ?>"><?php echo $userexternaldeposits_edit->deposittime->caption() ?><?php echo $userexternaldeposits_edit->deposittime->Required ? $Language->phrase("FieldRequiredIndicator") : "" ?></label>
		<div class="<?php echo $userexternaldeposits_edit->RightColumnClass ?>"><div <?php echo $userexternaldeposits_edit->deposittime->cellAttributes() ?>>
<span id="el_userexternaldeposits_deposittime">
<input type="text" data-table="userexternaldeposits" data-field="x_deposittime" name="x_deposittime" id="x_deposittime" placeholder="<?php echo HtmlEncode($userexternaldeposits_edit->deposittime->getPlaceHolder()) ?>" value="<?php echo $userexternaldeposits_edit->deposittime->EditValue ?>"<?php echo $userexternaldeposits_edit->deposittime->editAttributes() ?>>
</span>
<?php echo $userexternaldeposits_edit->deposittime->CustomMsg ?></div></div>
	</div>
<?php } ?>
<?php if ($userexternaldeposits_edit->source->Visible) { // source ?>
	<div id="r_source" class="form-group row">
		<label id="elh_userexternaldeposits_source" for="x_source" class="<?php echo $userexternaldeposits_edit->LeftColumnClass ?>"><?php echo $userexternaldeposits_edit->source->caption() ?><?php echo $userexternaldeposits_edit->source->Required ? $Language->phrase("FieldRequiredIndicator") : "" ?></label>
		<div class="<?php echo $userexternaldeposits_edit->RightColumnClass ?>"><div <?php echo $userexternaldeposits_edit->source->cellAttributes() ?>>
<span id="el_userexternaldeposits_source">
<input type="text" data-table="userexternaldeposits" data-field="x_source" name="x_source" id="x_source" size="30" maxlength="20" placeholder="<?php echo HtmlEncode($userexternaldeposits_edit->source->getPlaceHolder()) ?>" value="<?php echo $userexternaldeposits_edit->source->EditValue ?>"<?php echo $userexternaldeposits_edit->source->editAttributes() ?>>
</span>
<?php echo $userexternaldeposits_edit->source->CustomMsg ?></div></div>
	</div>
<?php } ?>
<?php if ($userexternaldeposits_edit->otherref->Visible) { // otherref ?>
	<div id="r_otherref" class="form-group row">
		<label id="elh_userexternaldeposits_otherref" for="x_otherref" class="<?php echo $userexternaldeposits_edit->LeftColumnClass ?>"><?php echo $userexternaldeposits_edit->otherref->caption() ?><?php echo $userexternaldeposits_edit->otherref->Required ? $Language->phrase("FieldRequiredIndicator") : "" ?></label>
		<div class="<?php echo $userexternaldeposits_edit->RightColumnClass ?>"><div <?php echo $userexternaldeposits_edit->otherref->cellAttributes() ?>>
<span id="el_userexternaldeposits_otherref">
<input type="text" data-table="userexternaldeposits" data-field="x_otherref" name="x_otherref" id="x_otherref" size="30" maxlength="20" placeholder="<?php echo HtmlEncode($userexternaldeposits_edit->otherref->getPlaceHolder()) ?>" value="<?php echo $userexternaldeposits_edit->otherref->EditValue ?>"<?php echo $userexternaldeposits_edit->otherref->editAttributes() ?>>
</span>
<?php echo $userexternaldeposits_edit->otherref->CustomMsg ?></div></div>
	</div>
<?php } ?>
<?php if ($userexternaldeposits_edit->curr->Visible) { // curr ?>
	<div id="r_curr" class="form-group row">
		<label id="elh_userexternaldeposits_curr" for="x_curr" class="<?php echo $userexternaldeposits_edit->LeftColumnClass ?>"><?php echo $userexternaldeposits_edit->curr->caption() ?><?php echo $userexternaldeposits_edit->curr->Required ? $Language->phrase("FieldRequiredIndicator") : "" ?></label>
		<div class="<?php echo $userexternaldeposits_edit->RightColumnClass ?>"><div <?php echo $userexternaldeposits_edit->curr->cellAttributes() ?>>
<span id="el_userexternaldeposits_curr">
<input type="text" data-table="userexternaldeposits" data-field="x_curr" name="x_curr" id="x_curr" size="30" maxlength="3" placeholder="<?php echo HtmlEncode($userexternaldeposits_edit->curr->getPlaceHolder()) ?>" value="<?php echo $userexternaldeposits_edit->curr->EditValue ?>"<?php echo $userexternaldeposits_edit->curr->editAttributes() ?>>
</span>
<?php echo $userexternaldeposits_edit->curr->CustomMsg ?></div></div>
	</div>
<?php } ?>
<?php if ($userexternaldeposits_edit->amount->Visible) { // amount ?>
	<div id="r_amount" class="form-group row">
		<label id="elh_userexternaldeposits_amount" for="x_amount" class="<?php echo $userexternaldeposits_edit->LeftColumnClass ?>"><?php echo $userexternaldeposits_edit->amount->caption() ?><?php echo $userexternaldeposits_edit->amount->Required ? $Language->phrase("FieldRequiredIndicator") : "" ?></label>
		<div class="<?php echo $userexternaldeposits_edit->RightColumnClass ?>"><div <?php echo $userexternaldeposits_edit->amount->cellAttributes() ?>>
<span id="el_userexternaldeposits_amount">
<input type="text" data-table="userexternaldeposits" data-field="x_amount" name="x_amount" id="x_amount" size="30" placeholder="<?php echo HtmlEncode($userexternaldeposits_edit->amount->getPlaceHolder()) ?>" value="<?php echo $userexternaldeposits_edit->amount->EditValue ?>"<?php echo $userexternaldeposits_edit->amount->editAttributes() ?>>
</span>
<?php echo $userexternaldeposits_edit->amount->CustomMsg ?></div></div>
	</div>
<?php } ?>
<?php if ($userexternaldeposits_edit->piid->Visible) { // piid ?>
	<div id="r_piid" class="form-group row">
		<label id="elh_userexternaldeposits_piid" for="x_piid" class="<?php echo $userexternaldeposits_edit->LeftColumnClass ?>"><?php echo $userexternaldeposits_edit->piid->caption() ?><?php echo $userexternaldeposits_edit->piid->Required ? $Language->phrase("FieldRequiredIndicator") : "" ?></label>
		<div class="<?php echo $userexternaldeposits_edit->RightColumnClass ?>"><div <?php echo $userexternaldeposits_edit->piid->cellAttributes() ?>>
<span id="el_userexternaldeposits_piid">
<input type="text" data-table="userexternaldeposits" data-field="x_piid" name="x_piid" id="x_piid" size="30" placeholder="<?php echo HtmlEncode($userexternaldeposits_edit->piid->getPlaceHolder()) ?>" value="<?php echo $userexternaldeposits_edit->piid->EditValue ?>"<?php echo $userexternaldeposits_edit->piid->editAttributes() ?>>
</span>
<?php echo $userexternaldeposits_edit->piid->CustomMsg ?></div></div>
	</div>
<?php } ?>
</div><!-- /page* -->
<?php if (!$userexternaldeposits_edit->IsModal) { ?>
<div class="form-group row"><!-- buttons .form-group -->
	<div class="<?php echo $userexternaldeposits_edit->OffsetColumnClass ?>"><!-- buttons offset -->
<button class="btn btn-primary ew-btn" name="btn-action" id="btn-action" type="submit"><?php echo $Language->phrase("SaveBtn") ?></button>
<button class="btn btn-default ew-btn" name="btn-cancel" id="btn-cancel" type="button" data-href="<?php echo $userexternaldeposits_edit->getReturnUrl() ?>"><?php echo $Language->phrase("CancelBtn") ?></button>
	</div><!-- /buttons offset -->
</div><!-- /buttons .form-group -->
<?php } ?>
</form>
<?php
$userexternaldeposits_edit->showPageFooter();
if (Config("DEBUG"))
	echo GetDebugMessage();
?>
<script>
loadjs.ready("load", function() {

	// Startup script
	// Write your table-specific startup script here
	// console.log("page loaded");

});
</script>
<?php include_once "footer.php"; ?>
<?php
$userexternaldeposits_edit->terminate();
?>