<?php
namespace PHPMaker2020\_4payadmin;

// Autoload
include_once "autoload.php";

// Session
if (session_status() !== PHP_SESSION_ACTIVE)
	\Delight\Cookie\Session::start(Config("COOKIE_SAMESITE")); // Init session data

// Output buffering
ob_start();
?>
<?php

// Write header
WriteHeader(FALSE);

// Create page object
$merchantsales_list = new merchantsales_list();

// Run the page
$merchantsales_list->run();

// Setup login status
SetupLoginStatus();
SetClientVar("login", LoginStatus());

// Global Page Rendering event (in userfn*.php)
Page_Rendering();

// Page Rendering event
$merchantsales_list->Page_Render();
?>
<?php include_once "header.php"; ?>
<?php if (!$merchantsales_list->isExport()) { ?>
<script>
var fmerchantsaleslist, currentPageID;
loadjs.ready("head", function() {

	// Form object
	currentPageID = ew.PAGE_ID = "list";
	fmerchantsaleslist = currentForm = new ew.Form("fmerchantsaleslist", "list");
	fmerchantsaleslist.formKeyCountName = '<?php echo $merchantsales_list->FormKeyCountName ?>';
	loadjs.done("fmerchantsaleslist");
});
var fmerchantsaleslistsrch;
loadjs.ready("head", function() {

	// Form object for search
	fmerchantsaleslistsrch = currentSearchForm = new ew.Form("fmerchantsaleslistsrch");

	// Validate function for search
	fmerchantsaleslistsrch.validate = function(fobj) {
		if (!this.validateRequired)
			return true; // Ignore validation
		fobj = fobj || this._form;
		var infix = "";
		elm = this.getElements("x" + infix + "_transferTime");
		if (elm && !ew.checkUSDate(elm.value))
			return this.onError(elm, "<?php echo JsEncode($merchantsales_list->transferTime->errorMessage()) ?>");
		elm = this.getElements("x" + infix + "_purchaseAmount");
		if (elm && !ew.checkNumber(elm.value))
			return this.onError(elm, "<?php echo JsEncode($merchantsales_list->purchaseAmount->errorMessage()) ?>");

		// Call Form_CustomValidate event
		if (!this.Form_CustomValidate(fobj))
			return false;
		return true;
	}

	// Form_CustomValidate
	fmerchantsaleslistsrch.Form_CustomValidate = function(fobj) { // DO NOT CHANGE THIS LINE!

		// Your custom validation code here, return false if invalid.
		return true;
	}

	// Use JavaScript validation or not
	fmerchantsaleslistsrch.validateRequired = <?php echo Config("CLIENT_VALIDATE") ? "true" : "false" ?>;

	// Dynamic selection lists
	fmerchantsaleslistsrch.lists["x_merchantID"] = <?php echo $merchantsales_list->merchantID->Lookup->toClientList($merchantsales_list) ?>;
	fmerchantsaleslistsrch.lists["x_merchantID"].options = <?php echo JsonEncode($merchantsales_list->merchantID->lookupOptions()) ?>;
	fmerchantsaleslistsrch.lists["x_status"] = <?php echo $merchantsales_list->status->Lookup->toClientList($merchantsales_list) ?>;
	fmerchantsaleslistsrch.lists["x_status"].options = <?php echo JsonEncode($merchantsales_list->status->options(FALSE, TRUE)) ?>;

	// Filters
	fmerchantsaleslistsrch.filterList = <?php echo $merchantsales_list->getFilterList() ?>;
	loadjs.done("fmerchantsaleslistsrch");
});
</script>
<style type="text/css">
.ew-table-preview-row { /* main table preview row color */
	background-color: #FFFFFF; /* preview row color */
}
.ew-table-preview-row .ew-grid {
	display: table;
}
</style>
<div id="ew-preview" class="d-none"><!-- preview -->
	<div class="ew-nav-tabs"><!-- .ew-nav-tabs -->
		<ul class="nav nav-tabs"></ul>
		<div class="tab-content"><!-- .tab-content -->
			<div class="tab-pane fade active show"></div>
		</div><!-- /.tab-content -->
	</div><!-- /.ew-nav-tabs -->
</div><!-- /preview -->
<script>
loadjs.ready("head", function() {
	ew.PREVIEW_PLACEMENT = ew.CSS_FLIP ? "right" : "left";
	ew.PREVIEW_SINGLE_ROW = false;
	ew.PREVIEW_OVERLAY = false;
	loadjs("js/ewpreview.js", "preview");
});
</script>
<script>
loadjs.ready("head", function() {

	// Client script
	// Write your client script here, no need to add script tags.

});
</script>
<?php } ?>
<?php if (!$merchantsales_list->isExport()) { ?>
<div class="btn-toolbar ew-toolbar">
<?php if ($merchantsales_list->TotalRecords > 0 && $merchantsales_list->ExportOptions->visible()) { ?>
<?php $merchantsales_list->ExportOptions->render("body") ?>
<?php } ?>
<?php if ($merchantsales_list->ImportOptions->visible()) { ?>
<?php $merchantsales_list->ImportOptions->render("body") ?>
<?php } ?>
<?php if ($merchantsales_list->SearchOptions->visible()) { ?>
<?php $merchantsales_list->SearchOptions->render("body") ?>
<?php } ?>
<?php if ($merchantsales_list->FilterOptions->visible()) { ?>
<?php $merchantsales_list->FilterOptions->render("body") ?>
<?php } ?>
<div class="clearfix"></div>
</div>
<?php } ?>
<?php if (!$merchantsales_list->isExport() || Config("EXPORT_MASTER_RECORD") && $merchantsales_list->isExport("print")) { ?>
<?php
if ($merchantsales_list->DbMasterFilter != "" && $merchantsales->getCurrentMasterTable() == "merchant") {
	if ($merchantsales_list->MasterRecordExists) {
		include_once "merchantmaster.php";
	}
}
?>
<?php } ?>
<?php
$merchantsales_list->renderOtherOptions();
?>
<?php if ($Security->CanSearch()) { ?>
<?php if (!$merchantsales_list->isExport() && !$merchantsales->CurrentAction) { ?>
<form name="fmerchantsaleslistsrch" id="fmerchantsaleslistsrch" class="form-inline ew-form ew-ext-search-form" action="<?php echo CurrentPageName() ?>">
<div id="fmerchantsaleslistsrch-search-panel" class="<?php echo $merchantsales_list->SearchPanelClass ?>">
<input type="hidden" name="cmd" value="search">
<input type="hidden" name="t" value="merchantsales">
	<div class="ew-extended-search">
<?php

// Render search row
$merchantsales->RowType = ROWTYPE_SEARCH;
$merchantsales->resetAttributes();
$merchantsales_list->renderRow();
?>
<?php if ($merchantsales_list->merchantID->Visible) { // merchantID ?>
	<?php
		$merchantsales_list->SearchColumnCount++;
		if (($merchantsales_list->SearchColumnCount - 1) % $merchantsales_list->SearchFieldsPerRow == 0) {
			$merchantsales_list->SearchRowCount++;
	?>
<div id="xsr_<?php echo $merchantsales_list->SearchRowCount ?>" class="ew-row d-sm-flex">
	<?php
		}
	 ?>
	<div id="xsc_merchantID" class="ew-cell form-group">
		<label for="x_merchantID" class="ew-search-caption ew-label"><?php echo $merchantsales_list->merchantID->caption() ?></label>
		<span class="ew-search-operator">
<?php echo $Language->phrase("=") ?>
<input type="hidden" name="z_merchantID" id="z_merchantID" value="=">
</span>
		<span id="el_merchantsales_merchantID" class="ew-search-field">
<div class="input-group">
	<select class="custom-select ew-custom-select" data-table="merchantsales" data-field="x_merchantID" data-value-separator="<?php echo $merchantsales_list->merchantID->displayValueSeparatorAttribute() ?>" id="x_merchantID" name="x_merchantID"<?php echo $merchantsales_list->merchantID->editAttributes() ?>>
			<?php echo $merchantsales_list->merchantID->selectOptionListHtml("x_merchantID") ?>
		</select>
</div>
<?php echo $merchantsales_list->merchantID->Lookup->getParamTag($merchantsales_list, "p_x_merchantID") ?>
</span>
	</div>
	<?php if ($merchantsales_list->SearchColumnCount % $merchantsales_list->SearchFieldsPerRow == 0) { ?>
</div>
	<?php } ?>
<?php } ?>
<?php if ($merchantsales_list->transferTime->Visible) { // transferTime ?>
	<?php
		$merchantsales_list->SearchColumnCount++;
		if (($merchantsales_list->SearchColumnCount - 1) % $merchantsales_list->SearchFieldsPerRow == 0) {
			$merchantsales_list->SearchRowCount++;
	?>
<div id="xsr_<?php echo $merchantsales_list->SearchRowCount ?>" class="ew-row d-sm-flex">
	<?php
		}
	 ?>
	<div id="xsc_transferTime" class="ew-cell form-group">
		<label for="x_transferTime" class="ew-search-caption ew-label"><?php echo $merchantsales_list->transferTime->caption() ?></label>
		<span class="ew-search-operator">
<select name="z_transferTime" id="z_transferTime" class="custom-select" onchange="ew.searchOperatorChanged(this);">
<option value="="<?php echo $merchantsales_list->transferTime->AdvancedSearch->SearchOperator == "=" ? " selected" : "" ?>><?php echo $Language->phrase("EQUAL") ?></option>
<option value="<>"<?php echo $merchantsales_list->transferTime->AdvancedSearch->SearchOperator == "<>" ? " selected" : "" ?>><?php echo $Language->phrase("<>") ?></option>
<option value="<"<?php echo $merchantsales_list->transferTime->AdvancedSearch->SearchOperator == "<" ? " selected" : "" ?>><?php echo $Language->phrase("<") ?></option>
<option value="<="<?php echo $merchantsales_list->transferTime->AdvancedSearch->SearchOperator == "<=" ? " selected" : "" ?>><?php echo $Language->phrase("<=") ?></option>
<option value=">"<?php echo $merchantsales_list->transferTime->AdvancedSearch->SearchOperator == ">" ? " selected" : "" ?>><?php echo $Language->phrase(">") ?></option>
<option value=">="<?php echo $merchantsales_list->transferTime->AdvancedSearch->SearchOperator == ">=" ? " selected" : "" ?>><?php echo $Language->phrase(">=") ?></option>
<option value="IS NULL"<?php echo $merchantsales_list->transferTime->AdvancedSearch->SearchOperator == "IS NULL" ? " selected" : "" ?>><?php echo $Language->phrase("IS NULL") ?></option>
<option value="IS NOT NULL"<?php echo $merchantsales_list->transferTime->AdvancedSearch->SearchOperator == "IS NOT NULL" ? " selected" : "" ?>><?php echo $Language->phrase("IS NOT NULL") ?></option>
<option value="BETWEEN"<?php echo $merchantsales_list->transferTime->AdvancedSearch->SearchOperator == "BETWEEN" ? " selected" : "" ?>><?php echo $Language->phrase("BETWEEN") ?></option>
</select>
</span>
		<span id="el_merchantsales_transferTime" class="ew-search-field">
<input type="text" data-table="merchantsales" data-field="x_transferTime" data-format="10" name="x_transferTime" id="x_transferTime" placeholder="<?php echo HtmlEncode($merchantsales_list->transferTime->getPlaceHolder()) ?>" value="<?php echo $merchantsales_list->transferTime->EditValue ?>"<?php echo $merchantsales_list->transferTime->editAttributes() ?>>
<?php if (!$merchantsales_list->transferTime->ReadOnly && !$merchantsales_list->transferTime->Disabled && !isset($merchantsales_list->transferTime->EditAttrs["readonly"]) && !isset($merchantsales_list->transferTime->EditAttrs["disabled"])) { ?>
<script>
loadjs.ready(["fmerchantsaleslistsrch", "datetimepicker"], function() {
	ew.createDateTimePicker("fmerchantsaleslistsrch", "x_transferTime", {"ignoreReadonly":true,"useCurrent":false,"format":10});
});
</script>
<?php } ?>
</span>
		<span class="ew-search-and d-none"><label><?php echo $Language->phrase("AND") ?></label></span>
		<span id="el2_merchantsales_transferTime" class="ew-search-field2 d-none">
<input type="text" data-table="merchantsales" data-field="x_transferTime" data-format="10" name="y_transferTime" id="y_transferTime" placeholder="<?php echo HtmlEncode($merchantsales_list->transferTime->getPlaceHolder()) ?>" value="<?php echo $merchantsales_list->transferTime->EditValue2 ?>"<?php echo $merchantsales_list->transferTime->editAttributes() ?>>
<?php if (!$merchantsales_list->transferTime->ReadOnly && !$merchantsales_list->transferTime->Disabled && !isset($merchantsales_list->transferTime->EditAttrs["readonly"]) && !isset($merchantsales_list->transferTime->EditAttrs["disabled"])) { ?>
<script>
loadjs.ready(["fmerchantsaleslistsrch", "datetimepicker"], function() {
	ew.createDateTimePicker("fmerchantsaleslistsrch", "y_transferTime", {"ignoreReadonly":true,"useCurrent":false,"format":10});
});
</script>
<?php } ?>
</span>
	</div>
	<?php if ($merchantsales_list->SearchColumnCount % $merchantsales_list->SearchFieldsPerRow == 0) { ?>
</div>
	<?php } ?>
<?php } ?>
<?php if ($merchantsales_list->purchaseAmount->Visible) { // purchaseAmount ?>
	<?php
		$merchantsales_list->SearchColumnCount++;
		if (($merchantsales_list->SearchColumnCount - 1) % $merchantsales_list->SearchFieldsPerRow == 0) {
			$merchantsales_list->SearchRowCount++;
	?>
<div id="xsr_<?php echo $merchantsales_list->SearchRowCount ?>" class="ew-row d-sm-flex">
	<?php
		}
	 ?>
	<div id="xsc_purchaseAmount" class="ew-cell form-group">
		<label for="x_purchaseAmount" class="ew-search-caption ew-label"><?php echo $merchantsales_list->purchaseAmount->caption() ?></label>
		<span class="ew-search-operator">
<select name="z_purchaseAmount" id="z_purchaseAmount" class="custom-select" onchange="ew.searchOperatorChanged(this);">
<option value="="<?php echo $merchantsales_list->purchaseAmount->AdvancedSearch->SearchOperator == "=" ? " selected" : "" ?>><?php echo $Language->phrase("EQUAL") ?></option>
<option value="<>"<?php echo $merchantsales_list->purchaseAmount->AdvancedSearch->SearchOperator == "<>" ? " selected" : "" ?>><?php echo $Language->phrase("<>") ?></option>
<option value="<"<?php echo $merchantsales_list->purchaseAmount->AdvancedSearch->SearchOperator == "<" ? " selected" : "" ?>><?php echo $Language->phrase("<") ?></option>
<option value="<="<?php echo $merchantsales_list->purchaseAmount->AdvancedSearch->SearchOperator == "<=" ? " selected" : "" ?>><?php echo $Language->phrase("<=") ?></option>
<option value=">"<?php echo $merchantsales_list->purchaseAmount->AdvancedSearch->SearchOperator == ">" ? " selected" : "" ?>><?php echo $Language->phrase(">") ?></option>
<option value=">="<?php echo $merchantsales_list->purchaseAmount->AdvancedSearch->SearchOperator == ">=" ? " selected" : "" ?>><?php echo $Language->phrase(">=") ?></option>
<option value="BETWEEN"<?php echo $merchantsales_list->purchaseAmount->AdvancedSearch->SearchOperator == "BETWEEN" ? " selected" : "" ?>><?php echo $Language->phrase("BETWEEN") ?></option>
</select>
</span>
		<span id="el_merchantsales_purchaseAmount" class="ew-search-field">
<input type="text" data-table="merchantsales" data-field="x_purchaseAmount" name="x_purchaseAmount" id="x_purchaseAmount" size="30" placeholder="<?php echo HtmlEncode($merchantsales_list->purchaseAmount->getPlaceHolder()) ?>" value="<?php echo $merchantsales_list->purchaseAmount->EditValue ?>"<?php echo $merchantsales_list->purchaseAmount->editAttributes() ?>>
</span>
		<span class="ew-search-and d-none"><label><?php echo $Language->phrase("AND") ?></label></span>
		<span id="el2_merchantsales_purchaseAmount" class="ew-search-field2 d-none">
<input type="text" data-table="merchantsales" data-field="x_purchaseAmount" name="y_purchaseAmount" id="y_purchaseAmount" size="30" placeholder="<?php echo HtmlEncode($merchantsales_list->purchaseAmount->getPlaceHolder()) ?>" value="<?php echo $merchantsales_list->purchaseAmount->EditValue2 ?>"<?php echo $merchantsales_list->purchaseAmount->editAttributes() ?>>
</span>
	</div>
	<?php if ($merchantsales_list->SearchColumnCount % $merchantsales_list->SearchFieldsPerRow == 0) { ?>
</div>
	<?php } ?>
<?php } ?>
<?php if ($merchantsales_list->status->Visible) { // status ?>
	<?php
		$merchantsales_list->SearchColumnCount++;
		if (($merchantsales_list->SearchColumnCount - 1) % $merchantsales_list->SearchFieldsPerRow == 0) {
			$merchantsales_list->SearchRowCount++;
	?>
<div id="xsr_<?php echo $merchantsales_list->SearchRowCount ?>" class="ew-row d-sm-flex">
	<?php
		}
	 ?>
	<div id="xsc_status" class="ew-cell form-group">
		<label for="x_status" class="ew-search-caption ew-label"><?php echo $merchantsales_list->status->caption() ?></label>
		<span class="ew-search-operator">
<?php echo $Language->phrase("=") ?>
<input type="hidden" name="z_status" id="z_status" value="=">
</span>
		<span id="el_merchantsales_status" class="ew-search-field">
<div class="input-group">
	<select class="custom-select ew-custom-select" data-table="merchantsales" data-field="x_status" data-value-separator="<?php echo $merchantsales_list->status->displayValueSeparatorAttribute() ?>" id="x_status" name="x_status"<?php echo $merchantsales_list->status->editAttributes() ?>>
			<?php echo $merchantsales_list->status->selectOptionListHtml("x_status") ?>
		</select>
</div>
</span>
	</div>
	<?php if ($merchantsales_list->SearchColumnCount % $merchantsales_list->SearchFieldsPerRow == 0) { ?>
</div>
	<?php } ?>
<?php } ?>
	<?php if ($merchantsales_list->SearchColumnCount % $merchantsales_list->SearchFieldsPerRow > 0) { ?>
</div>
	<?php } ?>
<div id="xsr_<?php echo $merchantsales_list->SearchRowCount + 1 ?>" class="ew-row d-sm-flex">
	<div class="ew-quick-search input-group">
		<input type="text" name="<?php echo Config("TABLE_BASIC_SEARCH") ?>" id="<?php echo Config("TABLE_BASIC_SEARCH") ?>" class="form-control" value="<?php echo HtmlEncode($merchantsales_list->BasicSearch->getKeyword()) ?>" placeholder="<?php echo HtmlEncode($Language->phrase("Search")) ?>">
		<input type="hidden" name="<?php echo Config("TABLE_BASIC_SEARCH_TYPE") ?>" id="<?php echo Config("TABLE_BASIC_SEARCH_TYPE") ?>" value="<?php echo HtmlEncode($merchantsales_list->BasicSearch->getType()) ?>">
		<div class="input-group-append">
			<button class="btn btn-primary" name="btn-submit" id="btn-submit" type="submit"><?php echo $Language->phrase("SearchBtn") ?></button>
			<button type="button" data-toggle="dropdown" class="btn btn-primary dropdown-toggle dropdown-toggle-split" aria-haspopup="true" aria-expanded="false"><span id="searchtype"><?php echo $merchantsales_list->BasicSearch->getTypeNameShort() ?></span></button>
			<div class="dropdown-menu dropdown-menu-right">
				<a class="dropdown-item<?php if ($merchantsales_list->BasicSearch->getType() == "") { ?> active<?php } ?>" href="#" onclick="return ew.setSearchType(this);"><?php echo $Language->phrase("QuickSearchAuto") ?></a>
				<a class="dropdown-item<?php if ($merchantsales_list->BasicSearch->getType() == "=") { ?> active<?php } ?>" href="#" onclick="return ew.setSearchType(this, '=');"><?php echo $Language->phrase("QuickSearchExact") ?></a>
				<a class="dropdown-item<?php if ($merchantsales_list->BasicSearch->getType() == "AND") { ?> active<?php } ?>" href="#" onclick="return ew.setSearchType(this, 'AND');"><?php echo $Language->phrase("QuickSearchAll") ?></a>
				<a class="dropdown-item<?php if ($merchantsales_list->BasicSearch->getType() == "OR") { ?> active<?php } ?>" href="#" onclick="return ew.setSearchType(this, 'OR');"><?php echo $Language->phrase("QuickSearchAny") ?></a>
			</div>
		</div>
	</div>
</div>
	</div><!-- /.ew-extended-search -->
</div><!-- /.ew-search-panel -->
</form>
<?php } ?>
<?php } ?>
<?php $merchantsales_list->showPageHeader(); ?>
<?php
$merchantsales_list->showMessage();
?>
<?php if ($merchantsales_list->TotalRecords > 0 || $merchantsales->CurrentAction) { ?>
<div class="card ew-card ew-grid<?php if ($merchantsales_list->isAddOrEdit()) { ?> ew-grid-add-edit<?php } ?> merchantsales">
<form name="fmerchantsaleslist" id="fmerchantsaleslist" class="form-inline ew-form ew-list-form" action="<?php echo CurrentPageName() ?>" method="post">
<?php if ($Page->CheckToken) { ?>
<input type="hidden" name="<?php echo Config("TOKEN_NAME") ?>" value="<?php echo $Page->Token ?>">
<?php } ?>
<input type="hidden" name="t" value="merchantsales">
<?php if ($merchantsales->getCurrentMasterTable() == "merchant" && $merchantsales->CurrentAction) { ?>
<input type="hidden" name="<?php echo Config("TABLE_SHOW_MASTER") ?>" value="merchant">
<input type="hidden" name="fk__userid" value="<?php echo HtmlEncode($merchantsales_list->merchantID->getSessionValue()) ?>">
<?php } ?>
<div id="gmp_merchantsales" class="<?php echo ResponsiveTableClass() ?>card-body ew-grid-middle-panel">
<?php if ($merchantsales_list->TotalRecords > 0 || $merchantsales_list->isGridEdit()) { ?>
<table id="tbl_merchantsaleslist" class="table ew-table"><!-- .ew-table -->
<thead>
	<tr class="ew-table-header">
<?php

// Header row
$merchantsales->RowType = ROWTYPE_HEADER;

// Render list options
$merchantsales_list->renderListOptions();

// Render list options (header, left)
$merchantsales_list->ListOptions->render("header", "left");
?>
<?php if ($merchantsales_list->transferID->Visible) { // transferID ?>
	<?php if ($merchantsales_list->SortUrl($merchantsales_list->transferID) == "") { ?>
		<th data-name="transferID" class="<?php echo $merchantsales_list->transferID->headerCellClass() ?>"><div id="elh_merchantsales_transferID" class="merchantsales_transferID"><div class="ew-table-header-caption"><?php echo $merchantsales_list->transferID->caption() ?></div></div></th>
	<?php } else { ?>
		<th data-name="transferID" class="<?php echo $merchantsales_list->transferID->headerCellClass() ?>"><div class="ew-pointer" onclick="ew.sort(event, '<?php echo $merchantsales_list->SortUrl($merchantsales_list->transferID) ?>', 1);"><div id="elh_merchantsales_transferID" class="merchantsales_transferID">
			<div class="ew-table-header-btn"><span class="ew-table-header-caption"><?php echo $merchantsales_list->transferID->caption() ?></span><span class="ew-table-header-sort"><?php if ($merchantsales_list->transferID->getSort() == "ASC") { ?><i class="fas fa-sort-up"></i><?php } elseif ($merchantsales_list->transferID->getSort() == "DESC") { ?><i class="fas fa-sort-down"></i><?php } ?></span></div>
		</div></div></th>
	<?php } ?>
<?php } ?>
<?php if ($merchantsales_list->txid->Visible) { // txid ?>
	<?php if ($merchantsales_list->SortUrl($merchantsales_list->txid) == "") { ?>
		<th data-name="txid" class="<?php echo $merchantsales_list->txid->headerCellClass() ?>"><div id="elh_merchantsales_txid" class="merchantsales_txid"><div class="ew-table-header-caption"><?php echo $merchantsales_list->txid->caption() ?></div></div></th>
	<?php } else { ?>
		<th data-name="txid" class="<?php echo $merchantsales_list->txid->headerCellClass() ?>"><div class="ew-pointer" onclick="ew.sort(event, '<?php echo $merchantsales_list->SortUrl($merchantsales_list->txid) ?>', 1);"><div id="elh_merchantsales_txid" class="merchantsales_txid">
			<div class="ew-table-header-btn"><span class="ew-table-header-caption"><?php echo $merchantsales_list->txid->caption() ?><?php echo $Language->phrase("SrchLegend") ?></span><span class="ew-table-header-sort"><?php if ($merchantsales_list->txid->getSort() == "ASC") { ?><i class="fas fa-sort-up"></i><?php } elseif ($merchantsales_list->txid->getSort() == "DESC") { ?><i class="fas fa-sort-down"></i><?php } ?></span></div>
		</div></div></th>
	<?php } ?>
<?php } ?>
<?php if ($merchantsales_list->merchantID->Visible) { // merchantID ?>
	<?php if ($merchantsales_list->SortUrl($merchantsales_list->merchantID) == "") { ?>
		<th data-name="merchantID" class="<?php echo $merchantsales_list->merchantID->headerCellClass() ?>"><div id="elh_merchantsales_merchantID" class="merchantsales_merchantID"><div class="ew-table-header-caption"><?php echo $merchantsales_list->merchantID->caption() ?></div></div></th>
	<?php } else { ?>
		<th data-name="merchantID" class="<?php echo $merchantsales_list->merchantID->headerCellClass() ?>"><div class="ew-pointer" onclick="ew.sort(event, '<?php echo $merchantsales_list->SortUrl($merchantsales_list->merchantID) ?>', 1);"><div id="elh_merchantsales_merchantID" class="merchantsales_merchantID">
			<div class="ew-table-header-btn"><span class="ew-table-header-caption"><?php echo $merchantsales_list->merchantID->caption() ?></span><span class="ew-table-header-sort"><?php if ($merchantsales_list->merchantID->getSort() == "ASC") { ?><i class="fas fa-sort-up"></i><?php } elseif ($merchantsales_list->merchantID->getSort() == "DESC") { ?><i class="fas fa-sort-down"></i><?php } ?></span></div>
		</div></div></th>
	<?php } ?>
<?php } ?>
<?php if ($merchantsales_list->_userID->Visible) { // userID ?>
	<?php if ($merchantsales_list->SortUrl($merchantsales_list->_userID) == "") { ?>
		<th data-name="_userID" class="<?php echo $merchantsales_list->_userID->headerCellClass() ?>"><div id="elh_merchantsales__userID" class="merchantsales__userID"><div class="ew-table-header-caption"><?php echo $merchantsales_list->_userID->caption() ?></div></div></th>
	<?php } else { ?>
		<th data-name="_userID" class="<?php echo $merchantsales_list->_userID->headerCellClass() ?>"><div class="ew-pointer" onclick="ew.sort(event, '<?php echo $merchantsales_list->SortUrl($merchantsales_list->_userID) ?>', 1);"><div id="elh_merchantsales__userID" class="merchantsales__userID">
			<div class="ew-table-header-btn"><span class="ew-table-header-caption"><?php echo $merchantsales_list->_userID->caption() ?></span><span class="ew-table-header-sort"><?php if ($merchantsales_list->_userID->getSort() == "ASC") { ?><i class="fas fa-sort-up"></i><?php } elseif ($merchantsales_list->_userID->getSort() == "DESC") { ?><i class="fas fa-sort-down"></i><?php } ?></span></div>
		</div></div></th>
	<?php } ?>
<?php } ?>
<?php if ($merchantsales_list->transferTime->Visible) { // transferTime ?>
	<?php if ($merchantsales_list->SortUrl($merchantsales_list->transferTime) == "") { ?>
		<th data-name="transferTime" class="<?php echo $merchantsales_list->transferTime->headerCellClass() ?>"><div id="elh_merchantsales_transferTime" class="merchantsales_transferTime"><div class="ew-table-header-caption"><?php echo $merchantsales_list->transferTime->caption() ?></div></div></th>
	<?php } else { ?>
		<th data-name="transferTime" class="<?php echo $merchantsales_list->transferTime->headerCellClass() ?>"><div class="ew-pointer" onclick="ew.sort(event, '<?php echo $merchantsales_list->SortUrl($merchantsales_list->transferTime) ?>', 1);"><div id="elh_merchantsales_transferTime" class="merchantsales_transferTime">
			<div class="ew-table-header-btn"><span class="ew-table-header-caption"><?php echo $merchantsales_list->transferTime->caption() ?></span><span class="ew-table-header-sort"><?php if ($merchantsales_list->transferTime->getSort() == "ASC") { ?><i class="fas fa-sort-up"></i><?php } elseif ($merchantsales_list->transferTime->getSort() == "DESC") { ?><i class="fas fa-sort-down"></i><?php } ?></span></div>
		</div></div></th>
	<?php } ?>
<?php } ?>
<?php if ($merchantsales_list->currID->Visible) { // currID ?>
	<?php if ($merchantsales_list->SortUrl($merchantsales_list->currID) == "") { ?>
		<th data-name="currID" class="<?php echo $merchantsales_list->currID->headerCellClass() ?>"><div id="elh_merchantsales_currID" class="merchantsales_currID"><div class="ew-table-header-caption"><?php echo $merchantsales_list->currID->caption() ?></div></div></th>
	<?php } else { ?>
		<th data-name="currID" class="<?php echo $merchantsales_list->currID->headerCellClass() ?>"><div class="ew-pointer" onclick="ew.sort(event, '<?php echo $merchantsales_list->SortUrl($merchantsales_list->currID) ?>', 1);"><div id="elh_merchantsales_currID" class="merchantsales_currID">
			<div class="ew-table-header-btn"><span class="ew-table-header-caption"><?php echo $merchantsales_list->currID->caption() ?><?php echo $Language->phrase("SrchLegend") ?></span><span class="ew-table-header-sort"><?php if ($merchantsales_list->currID->getSort() == "ASC") { ?><i class="fas fa-sort-up"></i><?php } elseif ($merchantsales_list->currID->getSort() == "DESC") { ?><i class="fas fa-sort-down"></i><?php } ?></span></div>
		</div></div></th>
	<?php } ?>
<?php } ?>
<?php if ($merchantsales_list->purchaseAmount->Visible) { // purchaseAmount ?>
	<?php if ($merchantsales_list->SortUrl($merchantsales_list->purchaseAmount) == "") { ?>
		<th data-name="purchaseAmount" class="<?php echo $merchantsales_list->purchaseAmount->headerCellClass() ?>"><div id="elh_merchantsales_purchaseAmount" class="merchantsales_purchaseAmount"><div class="ew-table-header-caption"><?php echo $merchantsales_list->purchaseAmount->caption() ?></div></div></th>
	<?php } else { ?>
		<th data-name="purchaseAmount" class="<?php echo $merchantsales_list->purchaseAmount->headerCellClass() ?>"><div class="ew-pointer" onclick="ew.sort(event, '<?php echo $merchantsales_list->SortUrl($merchantsales_list->purchaseAmount) ?>', 1);"><div id="elh_merchantsales_purchaseAmount" class="merchantsales_purchaseAmount">
			<div class="ew-table-header-btn"><span class="ew-table-header-caption"><?php echo $merchantsales_list->purchaseAmount->caption() ?></span><span class="ew-table-header-sort"><?php if ($merchantsales_list->purchaseAmount->getSort() == "ASC") { ?><i class="fas fa-sort-up"></i><?php } elseif ($merchantsales_list->purchaseAmount->getSort() == "DESC") { ?><i class="fas fa-sort-down"></i><?php } ?></span></div>
		</div></div></th>
	<?php } ?>
<?php } ?>
<?php if ($merchantsales_list->serviceFeeToMerchant->Visible) { // serviceFeeToMerchant ?>
	<?php if ($merchantsales_list->SortUrl($merchantsales_list->serviceFeeToMerchant) == "") { ?>
		<th data-name="serviceFeeToMerchant" class="<?php echo $merchantsales_list->serviceFeeToMerchant->headerCellClass() ?>"><div id="elh_merchantsales_serviceFeeToMerchant" class="merchantsales_serviceFeeToMerchant"><div class="ew-table-header-caption"><?php echo $merchantsales_list->serviceFeeToMerchant->caption() ?></div></div></th>
	<?php } else { ?>
		<th data-name="serviceFeeToMerchant" class="<?php echo $merchantsales_list->serviceFeeToMerchant->headerCellClass() ?>"><div class="ew-pointer" onclick="ew.sort(event, '<?php echo $merchantsales_list->SortUrl($merchantsales_list->serviceFeeToMerchant) ?>', 1);"><div id="elh_merchantsales_serviceFeeToMerchant" class="merchantsales_serviceFeeToMerchant">
			<div class="ew-table-header-btn"><span class="ew-table-header-caption"><?php echo $merchantsales_list->serviceFeeToMerchant->caption() ?><?php echo $Language->phrase("SrchLegend") ?></span><span class="ew-table-header-sort"><?php if ($merchantsales_list->serviceFeeToMerchant->getSort() == "ASC") { ?><i class="fas fa-sort-up"></i><?php } elseif ($merchantsales_list->serviceFeeToMerchant->getSort() == "DESC") { ?><i class="fas fa-sort-down"></i><?php } ?></span></div>
		</div></div></th>
	<?php } ?>
<?php } ?>
<?php if ($merchantsales_list->status->Visible) { // status ?>
	<?php if ($merchantsales_list->SortUrl($merchantsales_list->status) == "") { ?>
		<th data-name="status" class="<?php echo $merchantsales_list->status->headerCellClass() ?>"><div id="elh_merchantsales_status" class="merchantsales_status"><div class="ew-table-header-caption"><?php echo $merchantsales_list->status->caption() ?></div></div></th>
	<?php } else { ?>
		<th data-name="status" class="<?php echo $merchantsales_list->status->headerCellClass() ?>"><div class="ew-pointer" onclick="ew.sort(event, '<?php echo $merchantsales_list->SortUrl($merchantsales_list->status) ?>', 1);"><div id="elh_merchantsales_status" class="merchantsales_status">
			<div class="ew-table-header-btn"><span class="ew-table-header-caption"><?php echo $merchantsales_list->status->caption() ?></span><span class="ew-table-header-sort"><?php if ($merchantsales_list->status->getSort() == "ASC") { ?><i class="fas fa-sort-up"></i><?php } elseif ($merchantsales_list->status->getSort() == "DESC") { ?><i class="fas fa-sort-down"></i><?php } ?></span></div>
		</div></div></th>
	<?php } ?>
<?php } ?>
<?php

// Render list options (header, right)
$merchantsales_list->ListOptions->render("header", "right");
?>
	</tr>
</thead>
<tbody>
<?php
if ($merchantsales_list->ExportAll && $merchantsales_list->isExport()) {
	$merchantsales_list->StopRecord = $merchantsales_list->TotalRecords;
} else {

	// Set the last record to display
	if ($merchantsales_list->TotalRecords > $merchantsales_list->StartRecord + $merchantsales_list->DisplayRecords - 1)
		$merchantsales_list->StopRecord = $merchantsales_list->StartRecord + $merchantsales_list->DisplayRecords - 1;
	else
		$merchantsales_list->StopRecord = $merchantsales_list->TotalRecords;
}
$merchantsales_list->RecordCount = $merchantsales_list->StartRecord - 1;
if ($merchantsales_list->Recordset && !$merchantsales_list->Recordset->EOF) {
	$merchantsales_list->Recordset->moveFirst();
	$selectLimit = $merchantsales_list->UseSelectLimit;
	if (!$selectLimit && $merchantsales_list->StartRecord > 1)
		$merchantsales_list->Recordset->move($merchantsales_list->StartRecord - 1);
} elseif (!$merchantsales->AllowAddDeleteRow && $merchantsales_list->StopRecord == 0) {
	$merchantsales_list->StopRecord = $merchantsales->GridAddRowCount;
}

// Initialize aggregate
$merchantsales->RowType = ROWTYPE_AGGREGATEINIT;
$merchantsales->resetAttributes();
$merchantsales_list->renderRow();
while ($merchantsales_list->RecordCount < $merchantsales_list->StopRecord) {
	$merchantsales_list->RecordCount++;
	if ($merchantsales_list->RecordCount >= $merchantsales_list->StartRecord) {
		$merchantsales_list->RowCount++;

		// Set up key count
		$merchantsales_list->KeyCount = $merchantsales_list->RowIndex;

		// Init row class and style
		$merchantsales->resetAttributes();
		$merchantsales->CssClass = "";
		if ($merchantsales_list->isGridAdd()) {
		} else {
			$merchantsales_list->loadRowValues($merchantsales_list->Recordset); // Load row values
		}
		$merchantsales->RowType = ROWTYPE_VIEW; // Render view

		// Set up row id / data-rowindex
		$merchantsales->RowAttrs->merge(["data-rowindex" => $merchantsales_list->RowCount, "id" => "r" . $merchantsales_list->RowCount . "_merchantsales", "data-rowtype" => $merchantsales->RowType]);

		// Render row
		$merchantsales_list->renderRow();

		// Render list options
		$merchantsales_list->renderListOptions();
?>
	<tr <?php echo $merchantsales->rowAttributes() ?>>
<?php

// Render list options (body, left)
$merchantsales_list->ListOptions->render("body", "left", $merchantsales_list->RowCount);
?>
	<?php if ($merchantsales_list->transferID->Visible) { // transferID ?>
		<td data-name="transferID" <?php echo $merchantsales_list->transferID->cellAttributes() ?>>
<span id="el<?php echo $merchantsales_list->RowCount ?>_merchantsales_transferID">
<span<?php echo $merchantsales_list->transferID->viewAttributes() ?>><?php echo $merchantsales_list->transferID->getViewValue() ?></span>
</span>
</td>
	<?php } ?>
	<?php if ($merchantsales_list->txid->Visible) { // txid ?>
		<td data-name="txid" <?php echo $merchantsales_list->txid->cellAttributes() ?>>
<span id="el<?php echo $merchantsales_list->RowCount ?>_merchantsales_txid">
<span<?php echo $merchantsales_list->txid->viewAttributes() ?>><?php echo $merchantsales_list->txid->getViewValue() ?></span>
</span>
</td>
	<?php } ?>
	<?php if ($merchantsales_list->merchantID->Visible) { // merchantID ?>
		<td data-name="merchantID" <?php echo $merchantsales_list->merchantID->cellAttributes() ?>>
<span id="el<?php echo $merchantsales_list->RowCount ?>_merchantsales_merchantID">
<span<?php echo $merchantsales_list->merchantID->viewAttributes() ?>><?php echo $merchantsales_list->merchantID->getViewValue() ?></span>
</span>
</td>
	<?php } ?>
	<?php if ($merchantsales_list->_userID->Visible) { // userID ?>
		<td data-name="_userID" <?php echo $merchantsales_list->_userID->cellAttributes() ?>>
<span id="el<?php echo $merchantsales_list->RowCount ?>_merchantsales__userID">
<span<?php echo $merchantsales_list->_userID->viewAttributes() ?>><?php echo $merchantsales_list->_userID->getViewValue() ?></span>
</span>
</td>
	<?php } ?>
	<?php if ($merchantsales_list->transferTime->Visible) { // transferTime ?>
		<td data-name="transferTime" <?php echo $merchantsales_list->transferTime->cellAttributes() ?>>
<span id="el<?php echo $merchantsales_list->RowCount ?>_merchantsales_transferTime">
<span<?php echo $merchantsales_list->transferTime->viewAttributes() ?>><?php echo $merchantsales_list->transferTime->getViewValue() ?></span>
</span>
</td>
	<?php } ?>
	<?php if ($merchantsales_list->currID->Visible) { // currID ?>
		<td data-name="currID" <?php echo $merchantsales_list->currID->cellAttributes() ?>>
<span id="el<?php echo $merchantsales_list->RowCount ?>_merchantsales_currID">
<span<?php echo $merchantsales_list->currID->viewAttributes() ?>><?php echo $merchantsales_list->currID->getViewValue() ?></span>
</span>
</td>
	<?php } ?>
	<?php if ($merchantsales_list->purchaseAmount->Visible) { // purchaseAmount ?>
		<td data-name="purchaseAmount" <?php echo $merchantsales_list->purchaseAmount->cellAttributes() ?>>
<span id="el<?php echo $merchantsales_list->RowCount ?>_merchantsales_purchaseAmount">
<span<?php echo $merchantsales_list->purchaseAmount->viewAttributes() ?>><?php echo $merchantsales_list->purchaseAmount->getViewValue() ?></span>
</span>
</td>
	<?php } ?>
	<?php if ($merchantsales_list->serviceFeeToMerchant->Visible) { // serviceFeeToMerchant ?>
		<td data-name="serviceFeeToMerchant" <?php echo $merchantsales_list->serviceFeeToMerchant->cellAttributes() ?>>
<span id="el<?php echo $merchantsales_list->RowCount ?>_merchantsales_serviceFeeToMerchant">
<span<?php echo $merchantsales_list->serviceFeeToMerchant->viewAttributes() ?>><?php echo $merchantsales_list->serviceFeeToMerchant->getViewValue() ?></span>
</span>
</td>
	<?php } ?>
	<?php if ($merchantsales_list->status->Visible) { // status ?>
		<td data-name="status" <?php echo $merchantsales_list->status->cellAttributes() ?>>
<span id="el<?php echo $merchantsales_list->RowCount ?>_merchantsales_status">
<span<?php echo $merchantsales_list->status->viewAttributes() ?>><?php echo $merchantsales_list->status->getViewValue() ?></span>
</span>
</td>
	<?php } ?>
<?php

// Render list options (body, right)
$merchantsales_list->ListOptions->render("body", "right", $merchantsales_list->RowCount);
?>
	</tr>
<?php
	}
	if (!$merchantsales_list->isGridAdd())
		$merchantsales_list->Recordset->moveNext();
}
?>
</tbody>
<?php

// Render aggregate row
$merchantsales->RowType = ROWTYPE_AGGREGATE;
$merchantsales->resetAttributes();
$merchantsales_list->renderRow();
?>
<?php if ($merchantsales_list->TotalRecords > 0 && !$merchantsales_list->isGridAdd() && !$merchantsales_list->isGridEdit()) { ?>
<tfoot><!-- Table footer -->
	<tr class="ew-table-footer">
<?php

// Render list options
$merchantsales_list->renderListOptions();

// Render list options (footer, left)
$merchantsales_list->ListOptions->render("footer", "left");
?>
	<?php if ($merchantsales_list->transferID->Visible) { // transferID ?>
		<td data-name="transferID" class="<?php echo $merchantsales_list->transferID->footerCellClass() ?>"><span id="elf_merchantsales_transferID" class="merchantsales_transferID">
		&nbsp;
		</span></td>
	<?php } ?>
	<?php if ($merchantsales_list->txid->Visible) { // txid ?>
		<td data-name="txid" class="<?php echo $merchantsales_list->txid->footerCellClass() ?>"><span id="elf_merchantsales_txid" class="merchantsales_txid">
		&nbsp;
		</span></td>
	<?php } ?>
	<?php if ($merchantsales_list->merchantID->Visible) { // merchantID ?>
		<td data-name="merchantID" class="<?php echo $merchantsales_list->merchantID->footerCellClass() ?>"><span id="elf_merchantsales_merchantID" class="merchantsales_merchantID">
		&nbsp;
		</span></td>
	<?php } ?>
	<?php if ($merchantsales_list->_userID->Visible) { // userID ?>
		<td data-name="_userID" class="<?php echo $merchantsales_list->_userID->footerCellClass() ?>"><span id="elf_merchantsales__userID" class="merchantsales__userID">
		&nbsp;
		</span></td>
	<?php } ?>
	<?php if ($merchantsales_list->transferTime->Visible) { // transferTime ?>
		<td data-name="transferTime" class="<?php echo $merchantsales_list->transferTime->footerCellClass() ?>"><span id="elf_merchantsales_transferTime" class="merchantsales_transferTime">
		&nbsp;
		</span></td>
	<?php } ?>
	<?php if ($merchantsales_list->currID->Visible) { // currID ?>
		<td data-name="currID" class="<?php echo $merchantsales_list->currID->footerCellClass() ?>"><span id="elf_merchantsales_currID" class="merchantsales_currID">
		&nbsp;
		</span></td>
	<?php } ?>
	<?php if ($merchantsales_list->purchaseAmount->Visible) { // purchaseAmount ?>
		<td data-name="purchaseAmount" class="<?php echo $merchantsales_list->purchaseAmount->footerCellClass() ?>"><span id="elf_merchantsales_purchaseAmount" class="merchantsales_purchaseAmount">
		<span class="ew-aggregate"><?php echo $Language->phrase("TOTAL") ?></span><span class="ew-aggregate-value">
		<?php echo $merchantsales_list->purchaseAmount->ViewValue ?></span>
		</span></td>
	<?php } ?>
	<?php if ($merchantsales_list->serviceFeeToMerchant->Visible) { // serviceFeeToMerchant ?>
		<td data-name="serviceFeeToMerchant" class="<?php echo $merchantsales_list->serviceFeeToMerchant->footerCellClass() ?>"><span id="elf_merchantsales_serviceFeeToMerchant" class="merchantsales_serviceFeeToMerchant">
		<span class="ew-aggregate"><?php echo $Language->phrase("TOTAL") ?></span><span class="ew-aggregate-value">
		<?php echo $merchantsales_list->serviceFeeToMerchant->ViewValue ?></span>
		</span></td>
	<?php } ?>
	<?php if ($merchantsales_list->status->Visible) { // status ?>
		<td data-name="status" class="<?php echo $merchantsales_list->status->footerCellClass() ?>"><span id="elf_merchantsales_status" class="merchantsales_status">
		&nbsp;
		</span></td>
	<?php } ?>
<?php

// Render list options (footer, right)
$merchantsales_list->ListOptions->render("footer", "right");
?>
	</tr>
</tfoot>
<?php } ?>
</table><!-- /.ew-table -->
<?php } ?>
</div><!-- /.ew-grid-middle-panel -->
<?php if (!$merchantsales->CurrentAction) { ?>
<input type="hidden" name="action" id="action" value="">
<?php } ?>
</form><!-- /.ew-list-form -->
<?php

// Close recordset
if ($merchantsales_list->Recordset)
	$merchantsales_list->Recordset->Close();
?>
<?php if (!$merchantsales_list->isExport()) { ?>
<div class="card-footer ew-grid-lower-panel">
<?php if (!$merchantsales_list->isGridAdd()) { ?>
<form name="ew-pager-form" class="form-inline ew-form ew-pager-form" action="<?php echo CurrentPageName() ?>">
<?php echo $merchantsales_list->Pager->render() ?>
</form>
<?php } ?>
<div class="ew-list-other-options">
<?php $merchantsales_list->OtherOptions->render("body", "bottom") ?>
</div>
<div class="clearfix"></div>
</div>
<?php } ?>
</div><!-- /.ew-grid -->
<?php } ?>
<?php if ($merchantsales_list->TotalRecords == 0 && !$merchantsales->CurrentAction) { // Show other options ?>
<div class="ew-list-other-options">
<?php $merchantsales_list->OtherOptions->render("body") ?>
</div>
<div class="clearfix"></div>
<?php } ?>
<?php
$merchantsales_list->showPageFooter();
if (Config("DEBUG"))
	echo GetDebugMessage();
?>
<?php if (!$merchantsales_list->isExport()) { ?>
<script>
loadjs.ready("load", function() {

	// Startup script
	// Write your table-specific startup script here
	// console.log("page loaded");

});
</script>
<?php } ?>
<?php include_once "footer.php"; ?>
<?php
$merchantsales_list->terminate();
?>