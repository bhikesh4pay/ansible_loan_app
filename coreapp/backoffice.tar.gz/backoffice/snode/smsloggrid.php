<?php
namespace PHPMaker2020\_4payadmin;

// Write header
WriteHeader(FALSE);

// Create page object
if (!isset($smslog_grid))
	$smslog_grid = new smslog_grid();

// Run the page
$smslog_grid->run();

// Setup login status
SetupLoginStatus();
SetClientVar("login", LoginStatus());

// Global Page Rendering event (in userfn*.php)
Page_Rendering();

// Page Rendering event
$smslog_grid->Page_Render();
?>
<?php if (!$smslog_grid->isExport()) { ?>
<script>
var fsmsloggrid, currentPageID;
loadjs.ready("head", function() {

	// Form object
	fsmsloggrid = new ew.Form("fsmsloggrid", "grid");
	fsmsloggrid.formKeyCountName = '<?php echo $smslog_grid->FormKeyCountName ?>';

	// Validate form
	fsmsloggrid.validate = function() {
		if (!this.validateRequired)
			return true; // Ignore validation
		var $ = jQuery, fobj = this.getForm(), $fobj = $(fobj);
		if ($fobj.find("#confirm").val() == "confirm")
			return true;
		var elm, felm, uelm, addcnt = 0;
		var $k = $fobj.find("#" + this.formKeyCountName); // Get key_count
		var rowcnt = ($k[0]) ? parseInt($k.val(), 10) : 1;
		var startcnt = (rowcnt == 0) ? 0 : 1; // Check rowcnt == 0 => Inline-Add
		var gridinsert = ["insert", "gridinsert"].includes($fobj.find("#action").val()) && $k[0];
		for (var i = startcnt; i <= rowcnt; i++) {
			var infix = ($k[0]) ? String(i) : "";
			$fobj.data("rowindex", infix);
			var checkrow = (gridinsert) ? !this.emptyRow(infix) : true;
			if (checkrow) {
				addcnt++;
			<?php if ($smslog_grid->smsid->Required) { ?>
				elm = this.getElements("x" + infix + "_smsid");
				if (elm && !ew.isHidden(elm) && !ew.hasValue(elm))
					return this.onError(elm, "<?php echo JsEncode(str_replace("%s", $smslog_grid->smsid->caption(), $smslog_grid->smsid->RequiredErrorMessage)) ?>");
			<?php } ?>
			<?php if ($smslog_grid->_userid->Required) { ?>
				elm = this.getElements("x" + infix + "__userid");
				if (elm && !ew.isHidden(elm) && !ew.hasValue(elm))
					return this.onError(elm, "<?php echo JsEncode(str_replace("%s", $smslog_grid->_userid->caption(), $smslog_grid->_userid->RequiredErrorMessage)) ?>");
			<?php } ?>
				elm = this.getElements("x" + infix + "__userid");
				if (elm && !ew.checkInteger(elm.value))
					return this.onError(elm, "<?php echo JsEncode($smslog_grid->_userid->errorMessage()) ?>");
			<?php if ($smslog_grid->dt->Required) { ?>
				elm = this.getElements("x" + infix + "_dt");
				if (elm && !ew.isHidden(elm) && !ew.hasValue(elm))
					return this.onError(elm, "<?php echo JsEncode(str_replace("%s", $smslog_grid->dt->caption(), $smslog_grid->dt->RequiredErrorMessage)) ?>");
			<?php } ?>
				elm = this.getElements("x" + infix + "_dt");
				if (elm && !ew.checkDateDef(elm.value))
					return this.onError(elm, "<?php echo JsEncode($smslog_grid->dt->errorMessage()) ?>");
			<?php if ($smslog_grid->phoneno->Required) { ?>
				elm = this.getElements("x" + infix + "_phoneno");
				if (elm && !ew.isHidden(elm) && !ew.hasValue(elm))
					return this.onError(elm, "<?php echo JsEncode(str_replace("%s", $smslog_grid->phoneno->caption(), $smslog_grid->phoneno->RequiredErrorMessage)) ?>");
			<?php } ?>
			<?php if ($smslog_grid->phonetxt->Required) { ?>
				elm = this.getElements("x" + infix + "_phonetxt");
				if (elm && !ew.isHidden(elm) && !ew.hasValue(elm))
					return this.onError(elm, "<?php echo JsEncode(str_replace("%s", $smslog_grid->phonetxt->caption(), $smslog_grid->phonetxt->RequiredErrorMessage)) ?>");
			<?php } ?>
			<?php if ($smslog_grid->externalid->Required) { ?>
				elm = this.getElements("x" + infix + "_externalid");
				if (elm && !ew.isHidden(elm) && !ew.hasValue(elm))
					return this.onError(elm, "<?php echo JsEncode(str_replace("%s", $smslog_grid->externalid->caption(), $smslog_grid->externalid->RequiredErrorMessage)) ?>");
			<?php } ?>
			<?php if ($smslog_grid->statusmsg->Required) { ?>
				elm = this.getElements("x" + infix + "_statusmsg");
				if (elm && !ew.isHidden(elm) && !ew.hasValue(elm))
					return this.onError(elm, "<?php echo JsEncode(str_replace("%s", $smslog_grid->statusmsg->caption(), $smslog_grid->statusmsg->RequiredErrorMessage)) ?>");
			<?php } ?>
			<?php if ($smslog_grid->loanid->Required) { ?>
				elm = this.getElements("x" + infix + "_loanid");
				if (elm && !ew.isHidden(elm) && !ew.hasValue(elm))
					return this.onError(elm, "<?php echo JsEncode(str_replace("%s", $smslog_grid->loanid->caption(), $smslog_grid->loanid->RequiredErrorMessage)) ?>");
			<?php } ?>
				elm = this.getElements("x" + infix + "_loanid");
				if (elm && !ew.checkInteger(elm.value))
					return this.onError(elm, "<?php echo JsEncode($smslog_grid->loanid->errorMessage()) ?>");
			<?php if ($smslog_grid->gatewayid->Required) { ?>
				elm = this.getElements("x" + infix + "_gatewayid");
				if (elm && !ew.isHidden(elm) && !ew.hasValue(elm))
					return this.onError(elm, "<?php echo JsEncode(str_replace("%s", $smslog_grid->gatewayid->caption(), $smslog_grid->gatewayid->RequiredErrorMessage)) ?>");
			<?php } ?>
				elm = this.getElements("x" + infix + "_gatewayid");
				if (elm && !ew.checkInteger(elm.value))
					return this.onError(elm, "<?php echo JsEncode($smslog_grid->gatewayid->errorMessage()) ?>");

				// Call Form_CustomValidate event
				if (!this.Form_CustomValidate(fobj))
					return false;
			} // End Grid Add checking
		}
		return true;
	}

	// Check empty row
	fsmsloggrid.emptyRow = function(infix) {
		var fobj = this._form;
		if (ew.valueChanged(fobj, infix, "_userid", false)) return false;
		if (ew.valueChanged(fobj, infix, "dt", false)) return false;
		if (ew.valueChanged(fobj, infix, "phoneno", false)) return false;
		if (ew.valueChanged(fobj, infix, "phonetxt", false)) return false;
		if (ew.valueChanged(fobj, infix, "externalid", false)) return false;
		if (ew.valueChanged(fobj, infix, "statusmsg", false)) return false;
		if (ew.valueChanged(fobj, infix, "loanid", false)) return false;
		if (ew.valueChanged(fobj, infix, "gatewayid", false)) return false;
		return true;
	}

	// Form_CustomValidate
	fsmsloggrid.Form_CustomValidate = function(fobj) { // DO NOT CHANGE THIS LINE!

		// Your custom validation code here, return false if invalid.
		return true;
	}

	// Use JavaScript validation or not
	fsmsloggrid.validateRequired = <?php echo Config("CLIENT_VALIDATE") ? "true" : "false" ?>;

	// Dynamic selection lists
	loadjs.done("fsmsloggrid");
});
</script>
<?php } ?>
<?php
$smslog_grid->renderOtherOptions();
?>
<?php if ($smslog_grid->TotalRecords > 0 || $smslog->CurrentAction) { ?>
<div class="card ew-card ew-grid<?php if ($smslog_grid->isAddOrEdit()) { ?> ew-grid-add-edit<?php } ?> smslog">
<div id="fsmsloggrid" class="ew-form ew-list-form form-inline">
<div id="gmp_smslog" class="<?php echo ResponsiveTableClass() ?>card-body ew-grid-middle-panel">
<table id="tbl_smsloggrid" class="table ew-table"><!-- .ew-table -->
<thead>
	<tr class="ew-table-header">
<?php

// Header row
$smslog->RowType = ROWTYPE_HEADER;

// Render list options
$smslog_grid->renderListOptions();

// Render list options (header, left)
$smslog_grid->ListOptions->render("header", "left");
?>
<?php if ($smslog_grid->smsid->Visible) { // smsid ?>
	<?php if ($smslog_grid->SortUrl($smslog_grid->smsid) == "") { ?>
		<th data-name="smsid" class="<?php echo $smslog_grid->smsid->headerCellClass() ?>"><div id="elh_smslog_smsid" class="smslog_smsid"><div class="ew-table-header-caption"><?php echo $smslog_grid->smsid->caption() ?></div></div></th>
	<?php } else { ?>
		<th data-name="smsid" class="<?php echo $smslog_grid->smsid->headerCellClass() ?>"><div><div id="elh_smslog_smsid" class="smslog_smsid">
			<div class="ew-table-header-btn"><span class="ew-table-header-caption"><?php echo $smslog_grid->smsid->caption() ?></span><span class="ew-table-header-sort"><?php if ($smslog_grid->smsid->getSort() == "ASC") { ?><i class="fas fa-sort-up"></i><?php } elseif ($smslog_grid->smsid->getSort() == "DESC") { ?><i class="fas fa-sort-down"></i><?php } ?></span></div>
		</div></div></th>
	<?php } ?>
<?php } ?>
<?php if ($smslog_grid->_userid->Visible) { // userid ?>
	<?php if ($smslog_grid->SortUrl($smslog_grid->_userid) == "") { ?>
		<th data-name="_userid" class="<?php echo $smslog_grid->_userid->headerCellClass() ?>"><div id="elh_smslog__userid" class="smslog__userid"><div class="ew-table-header-caption"><?php echo $smslog_grid->_userid->caption() ?></div></div></th>
	<?php } else { ?>
		<th data-name="_userid" class="<?php echo $smslog_grid->_userid->headerCellClass() ?>"><div><div id="elh_smslog__userid" class="smslog__userid">
			<div class="ew-table-header-btn"><span class="ew-table-header-caption"><?php echo $smslog_grid->_userid->caption() ?></span><span class="ew-table-header-sort"><?php if ($smslog_grid->_userid->getSort() == "ASC") { ?><i class="fas fa-sort-up"></i><?php } elseif ($smslog_grid->_userid->getSort() == "DESC") { ?><i class="fas fa-sort-down"></i><?php } ?></span></div>
		</div></div></th>
	<?php } ?>
<?php } ?>
<?php if ($smslog_grid->dt->Visible) { // dt ?>
	<?php if ($smslog_grid->SortUrl($smslog_grid->dt) == "") { ?>
		<th data-name="dt" class="<?php echo $smslog_grid->dt->headerCellClass() ?>"><div id="elh_smslog_dt" class="smslog_dt"><div class="ew-table-header-caption"><?php echo $smslog_grid->dt->caption() ?></div></div></th>
	<?php } else { ?>
		<th data-name="dt" class="<?php echo $smslog_grid->dt->headerCellClass() ?>"><div><div id="elh_smslog_dt" class="smslog_dt">
			<div class="ew-table-header-btn"><span class="ew-table-header-caption"><?php echo $smslog_grid->dt->caption() ?></span><span class="ew-table-header-sort"><?php if ($smslog_grid->dt->getSort() == "ASC") { ?><i class="fas fa-sort-up"></i><?php } elseif ($smslog_grid->dt->getSort() == "DESC") { ?><i class="fas fa-sort-down"></i><?php } ?></span></div>
		</div></div></th>
	<?php } ?>
<?php } ?>
<?php if ($smslog_grid->phoneno->Visible) { // phoneno ?>
	<?php if ($smslog_grid->SortUrl($smslog_grid->phoneno) == "") { ?>
		<th data-name="phoneno" class="<?php echo $smslog_grid->phoneno->headerCellClass() ?>"><div id="elh_smslog_phoneno" class="smslog_phoneno"><div class="ew-table-header-caption"><?php echo $smslog_grid->phoneno->caption() ?></div></div></th>
	<?php } else { ?>
		<th data-name="phoneno" class="<?php echo $smslog_grid->phoneno->headerCellClass() ?>"><div><div id="elh_smslog_phoneno" class="smslog_phoneno">
			<div class="ew-table-header-btn"><span class="ew-table-header-caption"><?php echo $smslog_grid->phoneno->caption() ?></span><span class="ew-table-header-sort"><?php if ($smslog_grid->phoneno->getSort() == "ASC") { ?><i class="fas fa-sort-up"></i><?php } elseif ($smslog_grid->phoneno->getSort() == "DESC") { ?><i class="fas fa-sort-down"></i><?php } ?></span></div>
		</div></div></th>
	<?php } ?>
<?php } ?>
<?php if ($smslog_grid->phonetxt->Visible) { // phonetxt ?>
	<?php if ($smslog_grid->SortUrl($smslog_grid->phonetxt) == "") { ?>
		<th data-name="phonetxt" class="<?php echo $smslog_grid->phonetxt->headerCellClass() ?>"><div id="elh_smslog_phonetxt" class="smslog_phonetxt"><div class="ew-table-header-caption"><?php echo $smslog_grid->phonetxt->caption() ?></div></div></th>
	<?php } else { ?>
		<th data-name="phonetxt" class="<?php echo $smslog_grid->phonetxt->headerCellClass() ?>"><div><div id="elh_smslog_phonetxt" class="smslog_phonetxt">
			<div class="ew-table-header-btn"><span class="ew-table-header-caption"><?php echo $smslog_grid->phonetxt->caption() ?></span><span class="ew-table-header-sort"><?php if ($smslog_grid->phonetxt->getSort() == "ASC") { ?><i class="fas fa-sort-up"></i><?php } elseif ($smslog_grid->phonetxt->getSort() == "DESC") { ?><i class="fas fa-sort-down"></i><?php } ?></span></div>
		</div></div></th>
	<?php } ?>
<?php } ?>
<?php if ($smslog_grid->externalid->Visible) { // externalid ?>
	<?php if ($smslog_grid->SortUrl($smslog_grid->externalid) == "") { ?>
		<th data-name="externalid" class="<?php echo $smslog_grid->externalid->headerCellClass() ?>"><div id="elh_smslog_externalid" class="smslog_externalid"><div class="ew-table-header-caption"><?php echo $smslog_grid->externalid->caption() ?></div></div></th>
	<?php } else { ?>
		<th data-name="externalid" class="<?php echo $smslog_grid->externalid->headerCellClass() ?>"><div><div id="elh_smslog_externalid" class="smslog_externalid">
			<div class="ew-table-header-btn"><span class="ew-table-header-caption"><?php echo $smslog_grid->externalid->caption() ?></span><span class="ew-table-header-sort"><?php if ($smslog_grid->externalid->getSort() == "ASC") { ?><i class="fas fa-sort-up"></i><?php } elseif ($smslog_grid->externalid->getSort() == "DESC") { ?><i class="fas fa-sort-down"></i><?php } ?></span></div>
		</div></div></th>
	<?php } ?>
<?php } ?>
<?php if ($smslog_grid->statusmsg->Visible) { // statusmsg ?>
	<?php if ($smslog_grid->SortUrl($smslog_grid->statusmsg) == "") { ?>
		<th data-name="statusmsg" class="<?php echo $smslog_grid->statusmsg->headerCellClass() ?>"><div id="elh_smslog_statusmsg" class="smslog_statusmsg"><div class="ew-table-header-caption"><?php echo $smslog_grid->statusmsg->caption() ?></div></div></th>
	<?php } else { ?>
		<th data-name="statusmsg" class="<?php echo $smslog_grid->statusmsg->headerCellClass() ?>"><div><div id="elh_smslog_statusmsg" class="smslog_statusmsg">
			<div class="ew-table-header-btn"><span class="ew-table-header-caption"><?php echo $smslog_grid->statusmsg->caption() ?></span><span class="ew-table-header-sort"><?php if ($smslog_grid->statusmsg->getSort() == "ASC") { ?><i class="fas fa-sort-up"></i><?php } elseif ($smslog_grid->statusmsg->getSort() == "DESC") { ?><i class="fas fa-sort-down"></i><?php } ?></span></div>
		</div></div></th>
	<?php } ?>
<?php } ?>
<?php if ($smslog_grid->loanid->Visible) { // loanid ?>
	<?php if ($smslog_grid->SortUrl($smslog_grid->loanid) == "") { ?>
		<th data-name="loanid" class="<?php echo $smslog_grid->loanid->headerCellClass() ?>"><div id="elh_smslog_loanid" class="smslog_loanid"><div class="ew-table-header-caption"><?php echo $smslog_grid->loanid->caption() ?></div></div></th>
	<?php } else { ?>
		<th data-name="loanid" class="<?php echo $smslog_grid->loanid->headerCellClass() ?>"><div><div id="elh_smslog_loanid" class="smslog_loanid">
			<div class="ew-table-header-btn"><span class="ew-table-header-caption"><?php echo $smslog_grid->loanid->caption() ?></span><span class="ew-table-header-sort"><?php if ($smslog_grid->loanid->getSort() == "ASC") { ?><i class="fas fa-sort-up"></i><?php } elseif ($smslog_grid->loanid->getSort() == "DESC") { ?><i class="fas fa-sort-down"></i><?php } ?></span></div>
		</div></div></th>
	<?php } ?>
<?php } ?>
<?php if ($smslog_grid->gatewayid->Visible) { // gatewayid ?>
	<?php if ($smslog_grid->SortUrl($smslog_grid->gatewayid) == "") { ?>
		<th data-name="gatewayid" class="<?php echo $smslog_grid->gatewayid->headerCellClass() ?>"><div id="elh_smslog_gatewayid" class="smslog_gatewayid"><div class="ew-table-header-caption"><?php echo $smslog_grid->gatewayid->caption() ?></div></div></th>
	<?php } else { ?>
		<th data-name="gatewayid" class="<?php echo $smslog_grid->gatewayid->headerCellClass() ?>"><div><div id="elh_smslog_gatewayid" class="smslog_gatewayid">
			<div class="ew-table-header-btn"><span class="ew-table-header-caption"><?php echo $smslog_grid->gatewayid->caption() ?></span><span class="ew-table-header-sort"><?php if ($smslog_grid->gatewayid->getSort() == "ASC") { ?><i class="fas fa-sort-up"></i><?php } elseif ($smslog_grid->gatewayid->getSort() == "DESC") { ?><i class="fas fa-sort-down"></i><?php } ?></span></div>
		</div></div></th>
	<?php } ?>
<?php } ?>
<?php

// Render list options (header, right)
$smslog_grid->ListOptions->render("header", "right");
?>
	</tr>
</thead>
<tbody>
<?php
$smslog_grid->StartRecord = 1;
$smslog_grid->StopRecord = $smslog_grid->TotalRecords; // Show all records

// Restore number of post back records
if ($CurrentForm && ($smslog->isConfirm() || $smslog_grid->EventCancelled)) {
	$CurrentForm->Index = -1;
	if ($CurrentForm->hasValue($smslog_grid->FormKeyCountName) && ($smslog_grid->isGridAdd() || $smslog_grid->isGridEdit() || $smslog->isConfirm())) {
		$smslog_grid->KeyCount = $CurrentForm->getValue($smslog_grid->FormKeyCountName);
		$smslog_grid->StopRecord = $smslog_grid->StartRecord + $smslog_grid->KeyCount - 1;
	}
}
$smslog_grid->RecordCount = $smslog_grid->StartRecord - 1;
if ($smslog_grid->Recordset && !$smslog_grid->Recordset->EOF) {
	$smslog_grid->Recordset->moveFirst();
	$selectLimit = $smslog_grid->UseSelectLimit;
	if (!$selectLimit && $smslog_grid->StartRecord > 1)
		$smslog_grid->Recordset->move($smslog_grid->StartRecord - 1);
} elseif (!$smslog->AllowAddDeleteRow && $smslog_grid->StopRecord == 0) {
	$smslog_grid->StopRecord = $smslog->GridAddRowCount;
}

// Initialize aggregate
$smslog->RowType = ROWTYPE_AGGREGATEINIT;
$smslog->resetAttributes();
$smslog_grid->renderRow();
if ($smslog_grid->isGridAdd())
	$smslog_grid->RowIndex = 0;
if ($smslog_grid->isGridEdit())
	$smslog_grid->RowIndex = 0;
while ($smslog_grid->RecordCount < $smslog_grid->StopRecord) {
	$smslog_grid->RecordCount++;
	if ($smslog_grid->RecordCount >= $smslog_grid->StartRecord) {
		$smslog_grid->RowCount++;
		if ($smslog_grid->isGridAdd() || $smslog_grid->isGridEdit() || $smslog->isConfirm()) {
			$smslog_grid->RowIndex++;
			$CurrentForm->Index = $smslog_grid->RowIndex;
			if ($CurrentForm->hasValue($smslog_grid->FormActionName) && ($smslog->isConfirm() || $smslog_grid->EventCancelled))
				$smslog_grid->RowAction = strval($CurrentForm->getValue($smslog_grid->FormActionName));
			elseif ($smslog_grid->isGridAdd())
				$smslog_grid->RowAction = "insert";
			else
				$smslog_grid->RowAction = "";
		}

		// Set up key count
		$smslog_grid->KeyCount = $smslog_grid->RowIndex;

		// Init row class and style
		$smslog->resetAttributes();
		$smslog->CssClass = "";
		if ($smslog_grid->isGridAdd()) {
			if ($smslog->CurrentMode == "copy") {
				$smslog_grid->loadRowValues($smslog_grid->Recordset); // Load row values
				$smslog_grid->setRecordKey($smslog_grid->RowOldKey, $smslog_grid->Recordset); // Set old record key
			} else {
				$smslog_grid->loadRowValues(); // Load default values
				$smslog_grid->RowOldKey = ""; // Clear old key value
			}
		} else {
			$smslog_grid->loadRowValues($smslog_grid->Recordset); // Load row values
		}
		$smslog->RowType = ROWTYPE_VIEW; // Render view
		if ($smslog_grid->isGridAdd()) // Grid add
			$smslog->RowType = ROWTYPE_ADD; // Render add
		if ($smslog_grid->isGridAdd() && $smslog->EventCancelled && !$CurrentForm->hasValue("k_blankrow")) // Insert failed
			$smslog_grid->restoreCurrentRowFormValues($smslog_grid->RowIndex); // Restore form values
		if ($smslog_grid->isGridEdit()) { // Grid edit
			if ($smslog->EventCancelled)
				$smslog_grid->restoreCurrentRowFormValues($smslog_grid->RowIndex); // Restore form values
			if ($smslog_grid->RowAction == "insert")
				$smslog->RowType = ROWTYPE_ADD; // Render add
			else
				$smslog->RowType = ROWTYPE_EDIT; // Render edit
		}
		if ($smslog_grid->isGridEdit() && ($smslog->RowType == ROWTYPE_EDIT || $smslog->RowType == ROWTYPE_ADD) && $smslog->EventCancelled) // Update failed
			$smslog_grid->restoreCurrentRowFormValues($smslog_grid->RowIndex); // Restore form values
		if ($smslog->RowType == ROWTYPE_EDIT) // Edit row
			$smslog_grid->EditRowCount++;
		if ($smslog->isConfirm()) // Confirm row
			$smslog_grid->restoreCurrentRowFormValues($smslog_grid->RowIndex); // Restore form values

		// Set up row id / data-rowindex
		$smslog->RowAttrs->merge(["data-rowindex" => $smslog_grid->RowCount, "id" => "r" . $smslog_grid->RowCount . "_smslog", "data-rowtype" => $smslog->RowType]);

		// Render row
		$smslog_grid->renderRow();

		// Render list options
		$smslog_grid->renderListOptions();

		// Skip delete row / empty row for confirm page
		if ($smslog_grid->RowAction != "delete" && $smslog_grid->RowAction != "insertdelete" && !($smslog_grid->RowAction == "insert" && $smslog->isConfirm() && $smslog_grid->emptyRow())) {
?>
	<tr <?php echo $smslog->rowAttributes() ?>>
<?php

// Render list options (body, left)
$smslog_grid->ListOptions->render("body", "left", $smslog_grid->RowCount);
?>
	<?php if ($smslog_grid->smsid->Visible) { // smsid ?>
		<td data-name="smsid" <?php echo $smslog_grid->smsid->cellAttributes() ?>>
<?php if ($smslog->RowType == ROWTYPE_ADD) { // Add record ?>
<span id="el<?php echo $smslog_grid->RowCount ?>_smslog_smsid" class="form-group"></span>
<input type="hidden" data-table="smslog" data-field="x_smsid" name="o<?php echo $smslog_grid->RowIndex ?>_smsid" id="o<?php echo $smslog_grid->RowIndex ?>_smsid" value="<?php echo HtmlEncode($smslog_grid->smsid->OldValue) ?>">
<?php } ?>
<?php if ($smslog->RowType == ROWTYPE_EDIT) { // Edit record ?>
<span id="el<?php echo $smslog_grid->RowCount ?>_smslog_smsid" class="form-group">
<span<?php echo $smslog_grid->smsid->viewAttributes() ?>><input type="text" readonly class="form-control-plaintext" value="<?php echo HtmlEncode(RemoveHtml($smslog_grid->smsid->EditValue)) ?>"></span>
</span>
<input type="hidden" data-table="smslog" data-field="x_smsid" name="x<?php echo $smslog_grid->RowIndex ?>_smsid" id="x<?php echo $smslog_grid->RowIndex ?>_smsid" value="<?php echo HtmlEncode($smslog_grid->smsid->CurrentValue) ?>">
<?php } ?>
<?php if ($smslog->RowType == ROWTYPE_VIEW) { // View record ?>
<span id="el<?php echo $smslog_grid->RowCount ?>_smslog_smsid">
<span<?php echo $smslog_grid->smsid->viewAttributes() ?>><?php echo $smslog_grid->smsid->getViewValue() ?></span>
</span>
<?php if (!$smslog->isConfirm()) { ?>
<input type="hidden" data-table="smslog" data-field="x_smsid" name="x<?php echo $smslog_grid->RowIndex ?>_smsid" id="x<?php echo $smslog_grid->RowIndex ?>_smsid" value="<?php echo HtmlEncode($smslog_grid->smsid->FormValue) ?>">
<input type="hidden" data-table="smslog" data-field="x_smsid" name="o<?php echo $smslog_grid->RowIndex ?>_smsid" id="o<?php echo $smslog_grid->RowIndex ?>_smsid" value="<?php echo HtmlEncode($smslog_grid->smsid->OldValue) ?>">
<?php } else { ?>
<input type="hidden" data-table="smslog" data-field="x_smsid" name="fsmsloggrid$x<?php echo $smslog_grid->RowIndex ?>_smsid" id="fsmsloggrid$x<?php echo $smslog_grid->RowIndex ?>_smsid" value="<?php echo HtmlEncode($smslog_grid->smsid->FormValue) ?>">
<input type="hidden" data-table="smslog" data-field="x_smsid" name="fsmsloggrid$o<?php echo $smslog_grid->RowIndex ?>_smsid" id="fsmsloggrid$o<?php echo $smslog_grid->RowIndex ?>_smsid" value="<?php echo HtmlEncode($smslog_grid->smsid->OldValue) ?>">
<?php } ?>
<?php } ?>
</td>
	<?php } ?>
	<?php if ($smslog_grid->_userid->Visible) { // userid ?>
		<td data-name="_userid" <?php echo $smslog_grid->_userid->cellAttributes() ?>>
<?php if ($smslog->RowType == ROWTYPE_ADD) { // Add record ?>
<?php if ($smslog_grid->_userid->getSessionValue() != "") { ?>
<span id="el<?php echo $smslog_grid->RowCount ?>_smslog__userid" class="form-group">
<span<?php echo $smslog_grid->_userid->viewAttributes() ?>><input type="text" readonly class="form-control-plaintext" value="<?php echo HtmlEncode(RemoveHtml($smslog_grid->_userid->ViewValue)) ?>"></span>
</span>
<input type="hidden" id="x<?php echo $smslog_grid->RowIndex ?>__userid" name="x<?php echo $smslog_grid->RowIndex ?>__userid" value="<?php echo HtmlEncode($smslog_grid->_userid->CurrentValue) ?>">
<?php } else { ?>
<span id="el<?php echo $smslog_grid->RowCount ?>_smslog__userid" class="form-group">
<input type="text" data-table="smslog" data-field="x__userid" name="x<?php echo $smslog_grid->RowIndex ?>__userid" id="x<?php echo $smslog_grid->RowIndex ?>__userid" size="30" maxlength="12" placeholder="<?php echo HtmlEncode($smslog_grid->_userid->getPlaceHolder()) ?>" value="<?php echo $smslog_grid->_userid->EditValue ?>"<?php echo $smslog_grid->_userid->editAttributes() ?>>
</span>
<?php } ?>
<input type="hidden" data-table="smslog" data-field="x__userid" name="o<?php echo $smslog_grid->RowIndex ?>__userid" id="o<?php echo $smslog_grid->RowIndex ?>__userid" value="<?php echo HtmlEncode($smslog_grid->_userid->OldValue) ?>">
<?php } ?>
<?php if ($smslog->RowType == ROWTYPE_EDIT) { // Edit record ?>
<?php if ($smslog_grid->_userid->getSessionValue() != "") { ?>
<span id="el<?php echo $smslog_grid->RowCount ?>_smslog__userid" class="form-group">
<span<?php echo $smslog_grid->_userid->viewAttributes() ?>><input type="text" readonly class="form-control-plaintext" value="<?php echo HtmlEncode(RemoveHtml($smslog_grid->_userid->ViewValue)) ?>"></span>
</span>
<input type="hidden" id="x<?php echo $smslog_grid->RowIndex ?>__userid" name="x<?php echo $smslog_grid->RowIndex ?>__userid" value="<?php echo HtmlEncode($smslog_grid->_userid->CurrentValue) ?>">
<?php } else { ?>
<span id="el<?php echo $smslog_grid->RowCount ?>_smslog__userid" class="form-group">
<input type="text" data-table="smslog" data-field="x__userid" name="x<?php echo $smslog_grid->RowIndex ?>__userid" id="x<?php echo $smslog_grid->RowIndex ?>__userid" size="30" maxlength="12" placeholder="<?php echo HtmlEncode($smslog_grid->_userid->getPlaceHolder()) ?>" value="<?php echo $smslog_grid->_userid->EditValue ?>"<?php echo $smslog_grid->_userid->editAttributes() ?>>
</span>
<?php } ?>
<?php } ?>
<?php if ($smslog->RowType == ROWTYPE_VIEW) { // View record ?>
<span id="el<?php echo $smslog_grid->RowCount ?>_smslog__userid">
<span<?php echo $smslog_grid->_userid->viewAttributes() ?>><?php echo $smslog_grid->_userid->getViewValue() ?></span>
</span>
<?php if (!$smslog->isConfirm()) { ?>
<input type="hidden" data-table="smslog" data-field="x__userid" name="x<?php echo $smslog_grid->RowIndex ?>__userid" id="x<?php echo $smslog_grid->RowIndex ?>__userid" value="<?php echo HtmlEncode($smslog_grid->_userid->FormValue) ?>">
<input type="hidden" data-table="smslog" data-field="x__userid" name="o<?php echo $smslog_grid->RowIndex ?>__userid" id="o<?php echo $smslog_grid->RowIndex ?>__userid" value="<?php echo HtmlEncode($smslog_grid->_userid->OldValue) ?>">
<?php } else { ?>
<input type="hidden" data-table="smslog" data-field="x__userid" name="fsmsloggrid$x<?php echo $smslog_grid->RowIndex ?>__userid" id="fsmsloggrid$x<?php echo $smslog_grid->RowIndex ?>__userid" value="<?php echo HtmlEncode($smslog_grid->_userid->FormValue) ?>">
<input type="hidden" data-table="smslog" data-field="x__userid" name="fsmsloggrid$o<?php echo $smslog_grid->RowIndex ?>__userid" id="fsmsloggrid$o<?php echo $smslog_grid->RowIndex ?>__userid" value="<?php echo HtmlEncode($smslog_grid->_userid->OldValue) ?>">
<?php } ?>
<?php } ?>
</td>
	<?php } ?>
	<?php if ($smslog_grid->dt->Visible) { // dt ?>
		<td data-name="dt" <?php echo $smslog_grid->dt->cellAttributes() ?>>
<?php if ($smslog->RowType == ROWTYPE_ADD) { // Add record ?>
<span id="el<?php echo $smslog_grid->RowCount ?>_smslog_dt" class="form-group">
<input type="text" data-table="smslog" data-field="x_dt" name="x<?php echo $smslog_grid->RowIndex ?>_dt" id="x<?php echo $smslog_grid->RowIndex ?>_dt" maxlength="19" placeholder="<?php echo HtmlEncode($smslog_grid->dt->getPlaceHolder()) ?>" value="<?php echo $smslog_grid->dt->EditValue ?>"<?php echo $smslog_grid->dt->editAttributes() ?>>
<?php if (!$smslog_grid->dt->ReadOnly && !$smslog_grid->dt->Disabled && !isset($smslog_grid->dt->EditAttrs["readonly"]) && !isset($smslog_grid->dt->EditAttrs["disabled"])) { ?>
<script>
loadjs.ready(["fsmsloggrid", "datetimepicker"], function() {
	ew.createDateTimePicker("fsmsloggrid", "x<?php echo $smslog_grid->RowIndex ?>_dt", {"ignoreReadonly":true,"useCurrent":false,"format":0});
});
</script>
<?php } ?>
</span>
<input type="hidden" data-table="smslog" data-field="x_dt" name="o<?php echo $smslog_grid->RowIndex ?>_dt" id="o<?php echo $smslog_grid->RowIndex ?>_dt" value="<?php echo HtmlEncode($smslog_grid->dt->OldValue) ?>">
<?php } ?>
<?php if ($smslog->RowType == ROWTYPE_EDIT) { // Edit record ?>
<span id="el<?php echo $smslog_grid->RowCount ?>_smslog_dt" class="form-group">
<input type="text" data-table="smslog" data-field="x_dt" name="x<?php echo $smslog_grid->RowIndex ?>_dt" id="x<?php echo $smslog_grid->RowIndex ?>_dt" maxlength="19" placeholder="<?php echo HtmlEncode($smslog_grid->dt->getPlaceHolder()) ?>" value="<?php echo $smslog_grid->dt->EditValue ?>"<?php echo $smslog_grid->dt->editAttributes() ?>>
<?php if (!$smslog_grid->dt->ReadOnly && !$smslog_grid->dt->Disabled && !isset($smslog_grid->dt->EditAttrs["readonly"]) && !isset($smslog_grid->dt->EditAttrs["disabled"])) { ?>
<script>
loadjs.ready(["fsmsloggrid", "datetimepicker"], function() {
	ew.createDateTimePicker("fsmsloggrid", "x<?php echo $smslog_grid->RowIndex ?>_dt", {"ignoreReadonly":true,"useCurrent":false,"format":0});
});
</script>
<?php } ?>
</span>
<?php } ?>
<?php if ($smslog->RowType == ROWTYPE_VIEW) { // View record ?>
<span id="el<?php echo $smslog_grid->RowCount ?>_smslog_dt">
<span<?php echo $smslog_grid->dt->viewAttributes() ?>><?php echo $smslog_grid->dt->getViewValue() ?></span>
</span>
<?php if (!$smslog->isConfirm()) { ?>
<input type="hidden" data-table="smslog" data-field="x_dt" name="x<?php echo $smslog_grid->RowIndex ?>_dt" id="x<?php echo $smslog_grid->RowIndex ?>_dt" value="<?php echo HtmlEncode($smslog_grid->dt->FormValue) ?>">
<input type="hidden" data-table="smslog" data-field="x_dt" name="o<?php echo $smslog_grid->RowIndex ?>_dt" id="o<?php echo $smslog_grid->RowIndex ?>_dt" value="<?php echo HtmlEncode($smslog_grid->dt->OldValue) ?>">
<?php } else { ?>
<input type="hidden" data-table="smslog" data-field="x_dt" name="fsmsloggrid$x<?php echo $smslog_grid->RowIndex ?>_dt" id="fsmsloggrid$x<?php echo $smslog_grid->RowIndex ?>_dt" value="<?php echo HtmlEncode($smslog_grid->dt->FormValue) ?>">
<input type="hidden" data-table="smslog" data-field="x_dt" name="fsmsloggrid$o<?php echo $smslog_grid->RowIndex ?>_dt" id="fsmsloggrid$o<?php echo $smslog_grid->RowIndex ?>_dt" value="<?php echo HtmlEncode($smslog_grid->dt->OldValue) ?>">
<?php } ?>
<?php } ?>
</td>
	<?php } ?>
	<?php if ($smslog_grid->phoneno->Visible) { // phoneno ?>
		<td data-name="phoneno" <?php echo $smslog_grid->phoneno->cellAttributes() ?>>
<?php if ($smslog->RowType == ROWTYPE_ADD) { // Add record ?>
<span id="el<?php echo $smslog_grid->RowCount ?>_smslog_phoneno" class="form-group">
<input type="text" data-table="smslog" data-field="x_phoneno" name="x<?php echo $smslog_grid->RowIndex ?>_phoneno" id="x<?php echo $smslog_grid->RowIndex ?>_phoneno" size="30" maxlength="20" placeholder="<?php echo HtmlEncode($smslog_grid->phoneno->getPlaceHolder()) ?>" value="<?php echo $smslog_grid->phoneno->EditValue ?>"<?php echo $smslog_grid->phoneno->editAttributes() ?>>
</span>
<input type="hidden" data-table="smslog" data-field="x_phoneno" name="o<?php echo $smslog_grid->RowIndex ?>_phoneno" id="o<?php echo $smslog_grid->RowIndex ?>_phoneno" value="<?php echo HtmlEncode($smslog_grid->phoneno->OldValue) ?>">
<?php } ?>
<?php if ($smslog->RowType == ROWTYPE_EDIT) { // Edit record ?>
<span id="el<?php echo $smslog_grid->RowCount ?>_smslog_phoneno" class="form-group">
<input type="text" data-table="smslog" data-field="x_phoneno" name="x<?php echo $smslog_grid->RowIndex ?>_phoneno" id="x<?php echo $smslog_grid->RowIndex ?>_phoneno" size="30" maxlength="20" placeholder="<?php echo HtmlEncode($smslog_grid->phoneno->getPlaceHolder()) ?>" value="<?php echo $smslog_grid->phoneno->EditValue ?>"<?php echo $smslog_grid->phoneno->editAttributes() ?>>
</span>
<?php } ?>
<?php if ($smslog->RowType == ROWTYPE_VIEW) { // View record ?>
<span id="el<?php echo $smslog_grid->RowCount ?>_smslog_phoneno">
<span<?php echo $smslog_grid->phoneno->viewAttributes() ?>><?php echo $smslog_grid->phoneno->getViewValue() ?></span>
</span>
<?php if (!$smslog->isConfirm()) { ?>
<input type="hidden" data-table="smslog" data-field="x_phoneno" name="x<?php echo $smslog_grid->RowIndex ?>_phoneno" id="x<?php echo $smslog_grid->RowIndex ?>_phoneno" value="<?php echo HtmlEncode($smslog_grid->phoneno->FormValue) ?>">
<input type="hidden" data-table="smslog" data-field="x_phoneno" name="o<?php echo $smslog_grid->RowIndex ?>_phoneno" id="o<?php echo $smslog_grid->RowIndex ?>_phoneno" value="<?php echo HtmlEncode($smslog_grid->phoneno->OldValue) ?>">
<?php } else { ?>
<input type="hidden" data-table="smslog" data-field="x_phoneno" name="fsmsloggrid$x<?php echo $smslog_grid->RowIndex ?>_phoneno" id="fsmsloggrid$x<?php echo $smslog_grid->RowIndex ?>_phoneno" value="<?php echo HtmlEncode($smslog_grid->phoneno->FormValue) ?>">
<input type="hidden" data-table="smslog" data-field="x_phoneno" name="fsmsloggrid$o<?php echo $smslog_grid->RowIndex ?>_phoneno" id="fsmsloggrid$o<?php echo $smslog_grid->RowIndex ?>_phoneno" value="<?php echo HtmlEncode($smslog_grid->phoneno->OldValue) ?>">
<?php } ?>
<?php } ?>
</td>
	<?php } ?>
	<?php if ($smslog_grid->phonetxt->Visible) { // phonetxt ?>
		<td data-name="phonetxt" <?php echo $smslog_grid->phonetxt->cellAttributes() ?>>
<?php if ($smslog->RowType == ROWTYPE_ADD) { // Add record ?>
<span id="el<?php echo $smslog_grid->RowCount ?>_smslog_phonetxt" class="form-group">
<textarea data-table="smslog" data-field="x_phonetxt" name="x<?php echo $smslog_grid->RowIndex ?>_phonetxt" id="x<?php echo $smslog_grid->RowIndex ?>_phonetxt" cols="35" rows="4" placeholder="<?php echo HtmlEncode($smslog_grid->phonetxt->getPlaceHolder()) ?>"<?php echo $smslog_grid->phonetxt->editAttributes() ?>><?php echo $smslog_grid->phonetxt->EditValue ?></textarea>
</span>
<input type="hidden" data-table="smslog" data-field="x_phonetxt" name="o<?php echo $smslog_grid->RowIndex ?>_phonetxt" id="o<?php echo $smslog_grid->RowIndex ?>_phonetxt" value="<?php echo HtmlEncode($smslog_grid->phonetxt->OldValue) ?>">
<?php } ?>
<?php if ($smslog->RowType == ROWTYPE_EDIT) { // Edit record ?>
<span id="el<?php echo $smslog_grid->RowCount ?>_smslog_phonetxt" class="form-group">
<textarea data-table="smslog" data-field="x_phonetxt" name="x<?php echo $smslog_grid->RowIndex ?>_phonetxt" id="x<?php echo $smslog_grid->RowIndex ?>_phonetxt" cols="35" rows="4" placeholder="<?php echo HtmlEncode($smslog_grid->phonetxt->getPlaceHolder()) ?>"<?php echo $smslog_grid->phonetxt->editAttributes() ?>><?php echo $smslog_grid->phonetxt->EditValue ?></textarea>
</span>
<?php } ?>
<?php if ($smslog->RowType == ROWTYPE_VIEW) { // View record ?>
<span id="el<?php echo $smslog_grid->RowCount ?>_smslog_phonetxt">
<span<?php echo $smslog_grid->phonetxt->viewAttributes() ?>><?php echo $smslog_grid->phonetxt->getViewValue() ?></span>
</span>
<?php if (!$smslog->isConfirm()) { ?>
<input type="hidden" data-table="smslog" data-field="x_phonetxt" name="x<?php echo $smslog_grid->RowIndex ?>_phonetxt" id="x<?php echo $smslog_grid->RowIndex ?>_phonetxt" value="<?php echo HtmlEncode($smslog_grid->phonetxt->FormValue) ?>">
<input type="hidden" data-table="smslog" data-field="x_phonetxt" name="o<?php echo $smslog_grid->RowIndex ?>_phonetxt" id="o<?php echo $smslog_grid->RowIndex ?>_phonetxt" value="<?php echo HtmlEncode($smslog_grid->phonetxt->OldValue) ?>">
<?php } else { ?>
<input type="hidden" data-table="smslog" data-field="x_phonetxt" name="fsmsloggrid$x<?php echo $smslog_grid->RowIndex ?>_phonetxt" id="fsmsloggrid$x<?php echo $smslog_grid->RowIndex ?>_phonetxt" value="<?php echo HtmlEncode($smslog_grid->phonetxt->FormValue) ?>">
<input type="hidden" data-table="smslog" data-field="x_phonetxt" name="fsmsloggrid$o<?php echo $smslog_grid->RowIndex ?>_phonetxt" id="fsmsloggrid$o<?php echo $smslog_grid->RowIndex ?>_phonetxt" value="<?php echo HtmlEncode($smslog_grid->phonetxt->OldValue) ?>">
<?php } ?>
<?php } ?>
</td>
	<?php } ?>
	<?php if ($smslog_grid->externalid->Visible) { // externalid ?>
		<td data-name="externalid" <?php echo $smslog_grid->externalid->cellAttributes() ?>>
<?php if ($smslog->RowType == ROWTYPE_ADD) { // Add record ?>
<span id="el<?php echo $smslog_grid->RowCount ?>_smslog_externalid" class="form-group">
<input type="text" data-table="smslog" data-field="x_externalid" name="x<?php echo $smslog_grid->RowIndex ?>_externalid" id="x<?php echo $smslog_grid->RowIndex ?>_externalid" size="30" maxlength="50" placeholder="<?php echo HtmlEncode($smslog_grid->externalid->getPlaceHolder()) ?>" value="<?php echo $smslog_grid->externalid->EditValue ?>"<?php echo $smslog_grid->externalid->editAttributes() ?>>
</span>
<input type="hidden" data-table="smslog" data-field="x_externalid" name="o<?php echo $smslog_grid->RowIndex ?>_externalid" id="o<?php echo $smslog_grid->RowIndex ?>_externalid" value="<?php echo HtmlEncode($smslog_grid->externalid->OldValue) ?>">
<?php } ?>
<?php if ($smslog->RowType == ROWTYPE_EDIT) { // Edit record ?>
<span id="el<?php echo $smslog_grid->RowCount ?>_smslog_externalid" class="form-group">
<input type="text" data-table="smslog" data-field="x_externalid" name="x<?php echo $smslog_grid->RowIndex ?>_externalid" id="x<?php echo $smslog_grid->RowIndex ?>_externalid" size="30" maxlength="50" placeholder="<?php echo HtmlEncode($smslog_grid->externalid->getPlaceHolder()) ?>" value="<?php echo $smslog_grid->externalid->EditValue ?>"<?php echo $smslog_grid->externalid->editAttributes() ?>>
</span>
<?php } ?>
<?php if ($smslog->RowType == ROWTYPE_VIEW) { // View record ?>
<span id="el<?php echo $smslog_grid->RowCount ?>_smslog_externalid">
<span<?php echo $smslog_grid->externalid->viewAttributes() ?>><?php echo $smslog_grid->externalid->getViewValue() ?></span>
</span>
<?php if (!$smslog->isConfirm()) { ?>
<input type="hidden" data-table="smslog" data-field="x_externalid" name="x<?php echo $smslog_grid->RowIndex ?>_externalid" id="x<?php echo $smslog_grid->RowIndex ?>_externalid" value="<?php echo HtmlEncode($smslog_grid->externalid->FormValue) ?>">
<input type="hidden" data-table="smslog" data-field="x_externalid" name="o<?php echo $smslog_grid->RowIndex ?>_externalid" id="o<?php echo $smslog_grid->RowIndex ?>_externalid" value="<?php echo HtmlEncode($smslog_grid->externalid->OldValue) ?>">
<?php } else { ?>
<input type="hidden" data-table="smslog" data-field="x_externalid" name="fsmsloggrid$x<?php echo $smslog_grid->RowIndex ?>_externalid" id="fsmsloggrid$x<?php echo $smslog_grid->RowIndex ?>_externalid" value="<?php echo HtmlEncode($smslog_grid->externalid->FormValue) ?>">
<input type="hidden" data-table="smslog" data-field="x_externalid" name="fsmsloggrid$o<?php echo $smslog_grid->RowIndex ?>_externalid" id="fsmsloggrid$o<?php echo $smslog_grid->RowIndex ?>_externalid" value="<?php echo HtmlEncode($smslog_grid->externalid->OldValue) ?>">
<?php } ?>
<?php } ?>
</td>
	<?php } ?>
	<?php if ($smslog_grid->statusmsg->Visible) { // statusmsg ?>
		<td data-name="statusmsg" <?php echo $smslog_grid->statusmsg->cellAttributes() ?>>
<?php if ($smslog->RowType == ROWTYPE_ADD) { // Add record ?>
<span id="el<?php echo $smslog_grid->RowCount ?>_smslog_statusmsg" class="form-group">
<input type="text" data-table="smslog" data-field="x_statusmsg" name="x<?php echo $smslog_grid->RowIndex ?>_statusmsg" id="x<?php echo $smslog_grid->RowIndex ?>_statusmsg" size="30" maxlength="50" placeholder="<?php echo HtmlEncode($smslog_grid->statusmsg->getPlaceHolder()) ?>" value="<?php echo $smslog_grid->statusmsg->EditValue ?>"<?php echo $smslog_grid->statusmsg->editAttributes() ?>>
</span>
<input type="hidden" data-table="smslog" data-field="x_statusmsg" name="o<?php echo $smslog_grid->RowIndex ?>_statusmsg" id="o<?php echo $smslog_grid->RowIndex ?>_statusmsg" value="<?php echo HtmlEncode($smslog_grid->statusmsg->OldValue) ?>">
<?php } ?>
<?php if ($smslog->RowType == ROWTYPE_EDIT) { // Edit record ?>
<span id="el<?php echo $smslog_grid->RowCount ?>_smslog_statusmsg" class="form-group">
<input type="text" data-table="smslog" data-field="x_statusmsg" name="x<?php echo $smslog_grid->RowIndex ?>_statusmsg" id="x<?php echo $smslog_grid->RowIndex ?>_statusmsg" size="30" maxlength="50" placeholder="<?php echo HtmlEncode($smslog_grid->statusmsg->getPlaceHolder()) ?>" value="<?php echo $smslog_grid->statusmsg->EditValue ?>"<?php echo $smslog_grid->statusmsg->editAttributes() ?>>
</span>
<?php } ?>
<?php if ($smslog->RowType == ROWTYPE_VIEW) { // View record ?>
<span id="el<?php echo $smslog_grid->RowCount ?>_smslog_statusmsg">
<span<?php echo $smslog_grid->statusmsg->viewAttributes() ?>><?php echo $smslog_grid->statusmsg->getViewValue() ?></span>
</span>
<?php if (!$smslog->isConfirm()) { ?>
<input type="hidden" data-table="smslog" data-field="x_statusmsg" name="x<?php echo $smslog_grid->RowIndex ?>_statusmsg" id="x<?php echo $smslog_grid->RowIndex ?>_statusmsg" value="<?php echo HtmlEncode($smslog_grid->statusmsg->FormValue) ?>">
<input type="hidden" data-table="smslog" data-field="x_statusmsg" name="o<?php echo $smslog_grid->RowIndex ?>_statusmsg" id="o<?php echo $smslog_grid->RowIndex ?>_statusmsg" value="<?php echo HtmlEncode($smslog_grid->statusmsg->OldValue) ?>">
<?php } else { ?>
<input type="hidden" data-table="smslog" data-field="x_statusmsg" name="fsmsloggrid$x<?php echo $smslog_grid->RowIndex ?>_statusmsg" id="fsmsloggrid$x<?php echo $smslog_grid->RowIndex ?>_statusmsg" value="<?php echo HtmlEncode($smslog_grid->statusmsg->FormValue) ?>">
<input type="hidden" data-table="smslog" data-field="x_statusmsg" name="fsmsloggrid$o<?php echo $smslog_grid->RowIndex ?>_statusmsg" id="fsmsloggrid$o<?php echo $smslog_grid->RowIndex ?>_statusmsg" value="<?php echo HtmlEncode($smslog_grid->statusmsg->OldValue) ?>">
<?php } ?>
<?php } ?>
</td>
	<?php } ?>
	<?php if ($smslog_grid->loanid->Visible) { // loanid ?>
		<td data-name="loanid" <?php echo $smslog_grid->loanid->cellAttributes() ?>>
<?php if ($smslog->RowType == ROWTYPE_ADD) { // Add record ?>
<span id="el<?php echo $smslog_grid->RowCount ?>_smslog_loanid" class="form-group">
<input type="text" data-table="smslog" data-field="x_loanid" name="x<?php echo $smslog_grid->RowIndex ?>_loanid" id="x<?php echo $smslog_grid->RowIndex ?>_loanid" size="30" maxlength="12" placeholder="<?php echo HtmlEncode($smslog_grid->loanid->getPlaceHolder()) ?>" value="<?php echo $smslog_grid->loanid->EditValue ?>"<?php echo $smslog_grid->loanid->editAttributes() ?>>
</span>
<input type="hidden" data-table="smslog" data-field="x_loanid" name="o<?php echo $smslog_grid->RowIndex ?>_loanid" id="o<?php echo $smslog_grid->RowIndex ?>_loanid" value="<?php echo HtmlEncode($smslog_grid->loanid->OldValue) ?>">
<?php } ?>
<?php if ($smslog->RowType == ROWTYPE_EDIT) { // Edit record ?>
<span id="el<?php echo $smslog_grid->RowCount ?>_smslog_loanid" class="form-group">
<input type="text" data-table="smslog" data-field="x_loanid" name="x<?php echo $smslog_grid->RowIndex ?>_loanid" id="x<?php echo $smslog_grid->RowIndex ?>_loanid" size="30" maxlength="12" placeholder="<?php echo HtmlEncode($smslog_grid->loanid->getPlaceHolder()) ?>" value="<?php echo $smslog_grid->loanid->EditValue ?>"<?php echo $smslog_grid->loanid->editAttributes() ?>>
</span>
<?php } ?>
<?php if ($smslog->RowType == ROWTYPE_VIEW) { // View record ?>
<span id="el<?php echo $smslog_grid->RowCount ?>_smslog_loanid">
<span<?php echo $smslog_grid->loanid->viewAttributes() ?>><?php if (!EmptyString($smslog_grid->loanid->getViewValue()) && $smslog_grid->loanid->linkAttributes() != "") { ?>
<a<?php echo $smslog_grid->loanid->linkAttributes() ?>><?php echo $smslog_grid->loanid->getViewValue() ?></a>
<?php } else { ?>
<?php echo $smslog_grid->loanid->getViewValue() ?>
<?php } ?></span>
</span>
<?php if (!$smslog->isConfirm()) { ?>
<input type="hidden" data-table="smslog" data-field="x_loanid" name="x<?php echo $smslog_grid->RowIndex ?>_loanid" id="x<?php echo $smslog_grid->RowIndex ?>_loanid" value="<?php echo HtmlEncode($smslog_grid->loanid->FormValue) ?>">
<input type="hidden" data-table="smslog" data-field="x_loanid" name="o<?php echo $smslog_grid->RowIndex ?>_loanid" id="o<?php echo $smslog_grid->RowIndex ?>_loanid" value="<?php echo HtmlEncode($smslog_grid->loanid->OldValue) ?>">
<?php } else { ?>
<input type="hidden" data-table="smslog" data-field="x_loanid" name="fsmsloggrid$x<?php echo $smslog_grid->RowIndex ?>_loanid" id="fsmsloggrid$x<?php echo $smslog_grid->RowIndex ?>_loanid" value="<?php echo HtmlEncode($smslog_grid->loanid->FormValue) ?>">
<input type="hidden" data-table="smslog" data-field="x_loanid" name="fsmsloggrid$o<?php echo $smslog_grid->RowIndex ?>_loanid" id="fsmsloggrid$o<?php echo $smslog_grid->RowIndex ?>_loanid" value="<?php echo HtmlEncode($smslog_grid->loanid->OldValue) ?>">
<?php } ?>
<?php } ?>
</td>
	<?php } ?>
	<?php if ($smslog_grid->gatewayid->Visible) { // gatewayid ?>
		<td data-name="gatewayid" <?php echo $smslog_grid->gatewayid->cellAttributes() ?>>
<?php if ($smslog->RowType == ROWTYPE_ADD) { // Add record ?>
<span id="el<?php echo $smslog_grid->RowCount ?>_smslog_gatewayid" class="form-group">
<input type="text" data-table="smslog" data-field="x_gatewayid" name="x<?php echo $smslog_grid->RowIndex ?>_gatewayid" id="x<?php echo $smslog_grid->RowIndex ?>_gatewayid" size="30" maxlength="5" placeholder="<?php echo HtmlEncode($smslog_grid->gatewayid->getPlaceHolder()) ?>" value="<?php echo $smslog_grid->gatewayid->EditValue ?>"<?php echo $smslog_grid->gatewayid->editAttributes() ?>>
</span>
<input type="hidden" data-table="smslog" data-field="x_gatewayid" name="o<?php echo $smslog_grid->RowIndex ?>_gatewayid" id="o<?php echo $smslog_grid->RowIndex ?>_gatewayid" value="<?php echo HtmlEncode($smslog_grid->gatewayid->OldValue) ?>">
<?php } ?>
<?php if ($smslog->RowType == ROWTYPE_EDIT) { // Edit record ?>
<span id="el<?php echo $smslog_grid->RowCount ?>_smslog_gatewayid" class="form-group">
<input type="text" data-table="smslog" data-field="x_gatewayid" name="x<?php echo $smslog_grid->RowIndex ?>_gatewayid" id="x<?php echo $smslog_grid->RowIndex ?>_gatewayid" size="30" maxlength="5" placeholder="<?php echo HtmlEncode($smslog_grid->gatewayid->getPlaceHolder()) ?>" value="<?php echo $smslog_grid->gatewayid->EditValue ?>"<?php echo $smslog_grid->gatewayid->editAttributes() ?>>
</span>
<?php } ?>
<?php if ($smslog->RowType == ROWTYPE_VIEW) { // View record ?>
<span id="el<?php echo $smslog_grid->RowCount ?>_smslog_gatewayid">
<span<?php echo $smslog_grid->gatewayid->viewAttributes() ?>><?php echo $smslog_grid->gatewayid->getViewValue() ?></span>
</span>
<?php if (!$smslog->isConfirm()) { ?>
<input type="hidden" data-table="smslog" data-field="x_gatewayid" name="x<?php echo $smslog_grid->RowIndex ?>_gatewayid" id="x<?php echo $smslog_grid->RowIndex ?>_gatewayid" value="<?php echo HtmlEncode($smslog_grid->gatewayid->FormValue) ?>">
<input type="hidden" data-table="smslog" data-field="x_gatewayid" name="o<?php echo $smslog_grid->RowIndex ?>_gatewayid" id="o<?php echo $smslog_grid->RowIndex ?>_gatewayid" value="<?php echo HtmlEncode($smslog_grid->gatewayid->OldValue) ?>">
<?php } else { ?>
<input type="hidden" data-table="smslog" data-field="x_gatewayid" name="fsmsloggrid$x<?php echo $smslog_grid->RowIndex ?>_gatewayid" id="fsmsloggrid$x<?php echo $smslog_grid->RowIndex ?>_gatewayid" value="<?php echo HtmlEncode($smslog_grid->gatewayid->FormValue) ?>">
<input type="hidden" data-table="smslog" data-field="x_gatewayid" name="fsmsloggrid$o<?php echo $smslog_grid->RowIndex ?>_gatewayid" id="fsmsloggrid$o<?php echo $smslog_grid->RowIndex ?>_gatewayid" value="<?php echo HtmlEncode($smslog_grid->gatewayid->OldValue) ?>">
<?php } ?>
<?php } ?>
</td>
	<?php } ?>
<?php

// Render list options (body, right)
$smslog_grid->ListOptions->render("body", "right", $smslog_grid->RowCount);
?>
	</tr>
<?php if ($smslog->RowType == ROWTYPE_ADD || $smslog->RowType == ROWTYPE_EDIT) { ?>
<script>
loadjs.ready(["fsmsloggrid", "load"], function() {
	fsmsloggrid.updateLists(<?php echo $smslog_grid->RowIndex ?>);
});
</script>
<?php } ?>
<?php
	}
	} // End delete row checking
	if (!$smslog_grid->isGridAdd() || $smslog->CurrentMode == "copy")
		if (!$smslog_grid->Recordset->EOF)
			$smslog_grid->Recordset->moveNext();
}
?>
<?php
	if ($smslog->CurrentMode == "add" || $smslog->CurrentMode == "copy" || $smslog->CurrentMode == "edit") {
		$smslog_grid->RowIndex = '$rowindex$';
		$smslog_grid->loadRowValues();

		// Set row properties
		$smslog->resetAttributes();
		$smslog->RowAttrs->merge(["data-rowindex" => $smslog_grid->RowIndex, "id" => "r0_smslog", "data-rowtype" => ROWTYPE_ADD]);
		$smslog->RowAttrs->appendClass("ew-template");
		$smslog->RowType = ROWTYPE_ADD;

		// Render row
		$smslog_grid->renderRow();

		// Render list options
		$smslog_grid->renderListOptions();
		$smslog_grid->StartRowCount = 0;
?>
	<tr <?php echo $smslog->rowAttributes() ?>>
<?php

// Render list options (body, left)
$smslog_grid->ListOptions->render("body", "left", $smslog_grid->RowIndex);
?>
	<?php if ($smslog_grid->smsid->Visible) { // smsid ?>
		<td data-name="smsid">
<?php if (!$smslog->isConfirm()) { ?>
<span id="el$rowindex$_smslog_smsid" class="form-group smslog_smsid"></span>
<?php } else { ?>
<span id="el$rowindex$_smslog_smsid" class="form-group smslog_smsid">
<span<?php echo $smslog_grid->smsid->viewAttributes() ?>><input type="text" readonly class="form-control-plaintext" value="<?php echo HtmlEncode(RemoveHtml($smslog_grid->smsid->ViewValue)) ?>"></span>
</span>
<input type="hidden" data-table="smslog" data-field="x_smsid" name="x<?php echo $smslog_grid->RowIndex ?>_smsid" id="x<?php echo $smslog_grid->RowIndex ?>_smsid" value="<?php echo HtmlEncode($smslog_grid->smsid->FormValue) ?>">
<?php } ?>
<input type="hidden" data-table="smslog" data-field="x_smsid" name="o<?php echo $smslog_grid->RowIndex ?>_smsid" id="o<?php echo $smslog_grid->RowIndex ?>_smsid" value="<?php echo HtmlEncode($smslog_grid->smsid->OldValue) ?>">
</td>
	<?php } ?>
	<?php if ($smslog_grid->_userid->Visible) { // userid ?>
		<td data-name="_userid">
<?php if (!$smslog->isConfirm()) { ?>
<?php if ($smslog_grid->_userid->getSessionValue() != "") { ?>
<span id="el$rowindex$_smslog__userid" class="form-group smslog__userid">
<span<?php echo $smslog_grid->_userid->viewAttributes() ?>><input type="text" readonly class="form-control-plaintext" value="<?php echo HtmlEncode(RemoveHtml($smslog_grid->_userid->ViewValue)) ?>"></span>
</span>
<input type="hidden" id="x<?php echo $smslog_grid->RowIndex ?>__userid" name="x<?php echo $smslog_grid->RowIndex ?>__userid" value="<?php echo HtmlEncode($smslog_grid->_userid->CurrentValue) ?>">
<?php } else { ?>
<span id="el$rowindex$_smslog__userid" class="form-group smslog__userid">
<input type="text" data-table="smslog" data-field="x__userid" name="x<?php echo $smslog_grid->RowIndex ?>__userid" id="x<?php echo $smslog_grid->RowIndex ?>__userid" size="30" maxlength="12" placeholder="<?php echo HtmlEncode($smslog_grid->_userid->getPlaceHolder()) ?>" value="<?php echo $smslog_grid->_userid->EditValue ?>"<?php echo $smslog_grid->_userid->editAttributes() ?>>
</span>
<?php } ?>
<?php } else { ?>
<span id="el$rowindex$_smslog__userid" class="form-group smslog__userid">
<span<?php echo $smslog_grid->_userid->viewAttributes() ?>><input type="text" readonly class="form-control-plaintext" value="<?php echo HtmlEncode(RemoveHtml($smslog_grid->_userid->ViewValue)) ?>"></span>
</span>
<input type="hidden" data-table="smslog" data-field="x__userid" name="x<?php echo $smslog_grid->RowIndex ?>__userid" id="x<?php echo $smslog_grid->RowIndex ?>__userid" value="<?php echo HtmlEncode($smslog_grid->_userid->FormValue) ?>">
<?php } ?>
<input type="hidden" data-table="smslog" data-field="x__userid" name="o<?php echo $smslog_grid->RowIndex ?>__userid" id="o<?php echo $smslog_grid->RowIndex ?>__userid" value="<?php echo HtmlEncode($smslog_grid->_userid->OldValue) ?>">
</td>
	<?php } ?>
	<?php if ($smslog_grid->dt->Visible) { // dt ?>
		<td data-name="dt">
<?php if (!$smslog->isConfirm()) { ?>
<span id="el$rowindex$_smslog_dt" class="form-group smslog_dt">
<input type="text" data-table="smslog" data-field="x_dt" name="x<?php echo $smslog_grid->RowIndex ?>_dt" id="x<?php echo $smslog_grid->RowIndex ?>_dt" maxlength="19" placeholder="<?php echo HtmlEncode($smslog_grid->dt->getPlaceHolder()) ?>" value="<?php echo $smslog_grid->dt->EditValue ?>"<?php echo $smslog_grid->dt->editAttributes() ?>>
<?php if (!$smslog_grid->dt->ReadOnly && !$smslog_grid->dt->Disabled && !isset($smslog_grid->dt->EditAttrs["readonly"]) && !isset($smslog_grid->dt->EditAttrs["disabled"])) { ?>
<script>
loadjs.ready(["fsmsloggrid", "datetimepicker"], function() {
	ew.createDateTimePicker("fsmsloggrid", "x<?php echo $smslog_grid->RowIndex ?>_dt", {"ignoreReadonly":true,"useCurrent":false,"format":0});
});
</script>
<?php } ?>
</span>
<?php } else { ?>
<span id="el$rowindex$_smslog_dt" class="form-group smslog_dt">
<span<?php echo $smslog_grid->dt->viewAttributes() ?>><input type="text" readonly class="form-control-plaintext" value="<?php echo HtmlEncode(RemoveHtml($smslog_grid->dt->ViewValue)) ?>"></span>
</span>
<input type="hidden" data-table="smslog" data-field="x_dt" name="x<?php echo $smslog_grid->RowIndex ?>_dt" id="x<?php echo $smslog_grid->RowIndex ?>_dt" value="<?php echo HtmlEncode($smslog_grid->dt->FormValue) ?>">
<?php } ?>
<input type="hidden" data-table="smslog" data-field="x_dt" name="o<?php echo $smslog_grid->RowIndex ?>_dt" id="o<?php echo $smslog_grid->RowIndex ?>_dt" value="<?php echo HtmlEncode($smslog_grid->dt->OldValue) ?>">
</td>
	<?php } ?>
	<?php if ($smslog_grid->phoneno->Visible) { // phoneno ?>
		<td data-name="phoneno">
<?php if (!$smslog->isConfirm()) { ?>
<span id="el$rowindex$_smslog_phoneno" class="form-group smslog_phoneno">
<input type="text" data-table="smslog" data-field="x_phoneno" name="x<?php echo $smslog_grid->RowIndex ?>_phoneno" id="x<?php echo $smslog_grid->RowIndex ?>_phoneno" size="30" maxlength="20" placeholder="<?php echo HtmlEncode($smslog_grid->phoneno->getPlaceHolder()) ?>" value="<?php echo $smslog_grid->phoneno->EditValue ?>"<?php echo $smslog_grid->phoneno->editAttributes() ?>>
</span>
<?php } else { ?>
<span id="el$rowindex$_smslog_phoneno" class="form-group smslog_phoneno">
<span<?php echo $smslog_grid->phoneno->viewAttributes() ?>><input type="text" readonly class="form-control-plaintext" value="<?php echo HtmlEncode(RemoveHtml($smslog_grid->phoneno->ViewValue)) ?>"></span>
</span>
<input type="hidden" data-table="smslog" data-field="x_phoneno" name="x<?php echo $smslog_grid->RowIndex ?>_phoneno" id="x<?php echo $smslog_grid->RowIndex ?>_phoneno" value="<?php echo HtmlEncode($smslog_grid->phoneno->FormValue) ?>">
<?php } ?>
<input type="hidden" data-table="smslog" data-field="x_phoneno" name="o<?php echo $smslog_grid->RowIndex ?>_phoneno" id="o<?php echo $smslog_grid->RowIndex ?>_phoneno" value="<?php echo HtmlEncode($smslog_grid->phoneno->OldValue) ?>">
</td>
	<?php } ?>
	<?php if ($smslog_grid->phonetxt->Visible) { // phonetxt ?>
		<td data-name="phonetxt">
<?php if (!$smslog->isConfirm()) { ?>
<span id="el$rowindex$_smslog_phonetxt" class="form-group smslog_phonetxt">
<textarea data-table="smslog" data-field="x_phonetxt" name="x<?php echo $smslog_grid->RowIndex ?>_phonetxt" id="x<?php echo $smslog_grid->RowIndex ?>_phonetxt" cols="35" rows="4" placeholder="<?php echo HtmlEncode($smslog_grid->phonetxt->getPlaceHolder()) ?>"<?php echo $smslog_grid->phonetxt->editAttributes() ?>><?php echo $smslog_grid->phonetxt->EditValue ?></textarea>
</span>
<?php } else { ?>
<span id="el$rowindex$_smslog_phonetxt" class="form-group smslog_phonetxt">
<span<?php echo $smslog_grid->phonetxt->viewAttributes() ?>><?php echo $smslog_grid->phonetxt->ViewValue ?></span>
</span>
<input type="hidden" data-table="smslog" data-field="x_phonetxt" name="x<?php echo $smslog_grid->RowIndex ?>_phonetxt" id="x<?php echo $smslog_grid->RowIndex ?>_phonetxt" value="<?php echo HtmlEncode($smslog_grid->phonetxt->FormValue) ?>">
<?php } ?>
<input type="hidden" data-table="smslog" data-field="x_phonetxt" name="o<?php echo $smslog_grid->RowIndex ?>_phonetxt" id="o<?php echo $smslog_grid->RowIndex ?>_phonetxt" value="<?php echo HtmlEncode($smslog_grid->phonetxt->OldValue) ?>">
</td>
	<?php } ?>
	<?php if ($smslog_grid->externalid->Visible) { // externalid ?>
		<td data-name="externalid">
<?php if (!$smslog->isConfirm()) { ?>
<span id="el$rowindex$_smslog_externalid" class="form-group smslog_externalid">
<input type="text" data-table="smslog" data-field="x_externalid" name="x<?php echo $smslog_grid->RowIndex ?>_externalid" id="x<?php echo $smslog_grid->RowIndex ?>_externalid" size="30" maxlength="50" placeholder="<?php echo HtmlEncode($smslog_grid->externalid->getPlaceHolder()) ?>" value="<?php echo $smslog_grid->externalid->EditValue ?>"<?php echo $smslog_grid->externalid->editAttributes() ?>>
</span>
<?php } else { ?>
<span id="el$rowindex$_smslog_externalid" class="form-group smslog_externalid">
<span<?php echo $smslog_grid->externalid->viewAttributes() ?>><input type="text" readonly class="form-control-plaintext" value="<?php echo HtmlEncode(RemoveHtml($smslog_grid->externalid->ViewValue)) ?>"></span>
</span>
<input type="hidden" data-table="smslog" data-field="x_externalid" name="x<?php echo $smslog_grid->RowIndex ?>_externalid" id="x<?php echo $smslog_grid->RowIndex ?>_externalid" value="<?php echo HtmlEncode($smslog_grid->externalid->FormValue) ?>">
<?php } ?>
<input type="hidden" data-table="smslog" data-field="x_externalid" name="o<?php echo $smslog_grid->RowIndex ?>_externalid" id="o<?php echo $smslog_grid->RowIndex ?>_externalid" value="<?php echo HtmlEncode($smslog_grid->externalid->OldValue) ?>">
</td>
	<?php } ?>
	<?php if ($smslog_grid->statusmsg->Visible) { // statusmsg ?>
		<td data-name="statusmsg">
<?php if (!$smslog->isConfirm()) { ?>
<span id="el$rowindex$_smslog_statusmsg" class="form-group smslog_statusmsg">
<input type="text" data-table="smslog" data-field="x_statusmsg" name="x<?php echo $smslog_grid->RowIndex ?>_statusmsg" id="x<?php echo $smslog_grid->RowIndex ?>_statusmsg" size="30" maxlength="50" placeholder="<?php echo HtmlEncode($smslog_grid->statusmsg->getPlaceHolder()) ?>" value="<?php echo $smslog_grid->statusmsg->EditValue ?>"<?php echo $smslog_grid->statusmsg->editAttributes() ?>>
</span>
<?php } else { ?>
<span id="el$rowindex$_smslog_statusmsg" class="form-group smslog_statusmsg">
<span<?php echo $smslog_grid->statusmsg->viewAttributes() ?>><input type="text" readonly class="form-control-plaintext" value="<?php echo HtmlEncode(RemoveHtml($smslog_grid->statusmsg->ViewValue)) ?>"></span>
</span>
<input type="hidden" data-table="smslog" data-field="x_statusmsg" name="x<?php echo $smslog_grid->RowIndex ?>_statusmsg" id="x<?php echo $smslog_grid->RowIndex ?>_statusmsg" value="<?php echo HtmlEncode($smslog_grid->statusmsg->FormValue) ?>">
<?php } ?>
<input type="hidden" data-table="smslog" data-field="x_statusmsg" name="o<?php echo $smslog_grid->RowIndex ?>_statusmsg" id="o<?php echo $smslog_grid->RowIndex ?>_statusmsg" value="<?php echo HtmlEncode($smslog_grid->statusmsg->OldValue) ?>">
</td>
	<?php } ?>
	<?php if ($smslog_grid->loanid->Visible) { // loanid ?>
		<td data-name="loanid">
<?php if (!$smslog->isConfirm()) { ?>
<span id="el$rowindex$_smslog_loanid" class="form-group smslog_loanid">
<input type="text" data-table="smslog" data-field="x_loanid" name="x<?php echo $smslog_grid->RowIndex ?>_loanid" id="x<?php echo $smslog_grid->RowIndex ?>_loanid" size="30" maxlength="12" placeholder="<?php echo HtmlEncode($smslog_grid->loanid->getPlaceHolder()) ?>" value="<?php echo $smslog_grid->loanid->EditValue ?>"<?php echo $smslog_grid->loanid->editAttributes() ?>>
</span>
<?php } else { ?>
<span id="el$rowindex$_smslog_loanid" class="form-group smslog_loanid">
<span<?php echo $smslog_grid->loanid->viewAttributes() ?>><?php if (!EmptyString($smslog_grid->loanid->ViewValue) && $smslog_grid->loanid->linkAttributes() != "") { ?>
<a<?php echo $smslog_grid->loanid->linkAttributes() ?>><input type="text" readonly class="form-control-plaintext" value="<?php echo HtmlEncode(RemoveHtml($smslog_grid->loanid->ViewValue)) ?>"></a>
<?php } else { ?>
<input type="text" readonly class="form-control-plaintext" value="<?php echo HtmlEncode(RemoveHtml($smslog_grid->loanid->ViewValue)) ?>">
<?php } ?></span>
</span>
<input type="hidden" data-table="smslog" data-field="x_loanid" name="x<?php echo $smslog_grid->RowIndex ?>_loanid" id="x<?php echo $smslog_grid->RowIndex ?>_loanid" value="<?php echo HtmlEncode($smslog_grid->loanid->FormValue) ?>">
<?php } ?>
<input type="hidden" data-table="smslog" data-field="x_loanid" name="o<?php echo $smslog_grid->RowIndex ?>_loanid" id="o<?php echo $smslog_grid->RowIndex ?>_loanid" value="<?php echo HtmlEncode($smslog_grid->loanid->OldValue) ?>">
</td>
	<?php } ?>
	<?php if ($smslog_grid->gatewayid->Visible) { // gatewayid ?>
		<td data-name="gatewayid">
<?php if (!$smslog->isConfirm()) { ?>
<span id="el$rowindex$_smslog_gatewayid" class="form-group smslog_gatewayid">
<input type="text" data-table="smslog" data-field="x_gatewayid" name="x<?php echo $smslog_grid->RowIndex ?>_gatewayid" id="x<?php echo $smslog_grid->RowIndex ?>_gatewayid" size="30" maxlength="5" placeholder="<?php echo HtmlEncode($smslog_grid->gatewayid->getPlaceHolder()) ?>" value="<?php echo $smslog_grid->gatewayid->EditValue ?>"<?php echo $smslog_grid->gatewayid->editAttributes() ?>>
</span>
<?php } else { ?>
<span id="el$rowindex$_smslog_gatewayid" class="form-group smslog_gatewayid">
<span<?php echo $smslog_grid->gatewayid->viewAttributes() ?>><input type="text" readonly class="form-control-plaintext" value="<?php echo HtmlEncode(RemoveHtml($smslog_grid->gatewayid->ViewValue)) ?>"></span>
</span>
<input type="hidden" data-table="smslog" data-field="x_gatewayid" name="x<?php echo $smslog_grid->RowIndex ?>_gatewayid" id="x<?php echo $smslog_grid->RowIndex ?>_gatewayid" value="<?php echo HtmlEncode($smslog_grid->gatewayid->FormValue) ?>">
<?php } ?>
<input type="hidden" data-table="smslog" data-field="x_gatewayid" name="o<?php echo $smslog_grid->RowIndex ?>_gatewayid" id="o<?php echo $smslog_grid->RowIndex ?>_gatewayid" value="<?php echo HtmlEncode($smslog_grid->gatewayid->OldValue) ?>">
</td>
	<?php } ?>
<?php

// Render list options (body, right)
$smslog_grid->ListOptions->render("body", "right", $smslog_grid->RowIndex);
?>
<script>
loadjs.ready(["fsmsloggrid", "load"], function() {
	fsmsloggrid.updateLists(<?php echo $smslog_grid->RowIndex ?>);
});
</script>
	</tr>
<?php
	}
?>
</tbody>
</table><!-- /.ew-table -->
</div><!-- /.ew-grid-middle-panel -->
<?php if ($smslog->CurrentMode == "add" || $smslog->CurrentMode == "copy") { ?>
<input type="hidden" name="<?php echo $smslog_grid->FormKeyCountName ?>" id="<?php echo $smslog_grid->FormKeyCountName ?>" value="<?php echo $smslog_grid->KeyCount ?>">
<?php echo $smslog_grid->MultiSelectKey ?>
<?php } ?>
<?php if ($smslog->CurrentMode == "edit") { ?>
<input type="hidden" name="<?php echo $smslog_grid->FormKeyCountName ?>" id="<?php echo $smslog_grid->FormKeyCountName ?>" value="<?php echo $smslog_grid->KeyCount ?>">
<?php echo $smslog_grid->MultiSelectKey ?>
<?php } ?>
<?php if ($smslog->CurrentMode == "") { ?>
<input type="hidden" name="action" id="action" value="">
<?php } ?>
<input type="hidden" name="detailpage" value="fsmsloggrid">
</div><!-- /.ew-list-form -->
<?php

// Close recordset
if ($smslog_grid->Recordset)
	$smslog_grid->Recordset->Close();
?>
<?php if ($smslog_grid->ShowOtherOptions) { ?>
<div class="card-footer ew-grid-lower-panel">
<?php $smslog_grid->OtherOptions->render("body", "bottom") ?>
</div>
<div class="clearfix"></div>
<?php } ?>
</div><!-- /.ew-grid -->
<?php } ?>
<?php if ($smslog_grid->TotalRecords == 0 && !$smslog->CurrentAction) { // Show other options ?>
<div class="ew-list-other-options">
<?php $smslog_grid->OtherOptions->render("body") ?>
</div>
<div class="clearfix"></div>
<?php } ?>
<?php if (!$smslog_grid->isExport()) { ?>
<script>
loadjs.ready("load", function() {

	// Startup script
	// Write your table-specific startup script here
	// console.log("page loaded");

});
</script>
<?php } ?>
<?php
$smslog_grid->terminate();
?>