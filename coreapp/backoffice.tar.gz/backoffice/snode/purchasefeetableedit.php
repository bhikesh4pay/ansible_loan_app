<?php
namespace PHPMaker2020\_4payadmin;

// Autoload
include_once "autoload.php";

// Session
if (session_status() !== PHP_SESSION_ACTIVE)
	\Delight\Cookie\Session::start(Config("COOKIE_SAMESITE")); // Init session data

// Output buffering
ob_start();
?>
<?php

// Write header
WriteHeader(FALSE);

// Create page object
$purchasefeetable_edit = new purchasefeetable_edit();

// Run the page
$purchasefeetable_edit->run();

// Setup login status
SetupLoginStatus();
SetClientVar("login", LoginStatus());

// Global Page Rendering event (in userfn*.php)
Page_Rendering();

// Page Rendering event
$purchasefeetable_edit->Page_Render();
?>
<?php include_once "header.php"; ?>
<script>
var fpurchasefeetableedit, currentPageID;
loadjs.ready("head", function() {

	// Form object
	currentPageID = ew.PAGE_ID = "edit";
	fpurchasefeetableedit = currentForm = new ew.Form("fpurchasefeetableedit", "edit");

	// Validate form
	fpurchasefeetableedit.validate = function() {
		if (!this.validateRequired)
			return true; // Ignore validation
		var $ = jQuery, fobj = this.getForm(), $fobj = $(fobj);
		if ($fobj.find("#confirm").val() == "confirm")
			return true;
		var elm, felm, uelm, addcnt = 0;
		var $k = $fobj.find("#" + this.formKeyCountName); // Get key_count
		var rowcnt = ($k[0]) ? parseInt($k.val(), 10) : 1;
		var startcnt = (rowcnt == 0) ? 0 : 1; // Check rowcnt == 0 => Inline-Add
		var gridinsert = ["insert", "gridinsert"].includes($fobj.find("#action").val()) && $k[0];
		for (var i = startcnt; i <= rowcnt; i++) {
			var infix = ($k[0]) ? String(i) : "";
			$fobj.data("rowindex", infix);
			<?php if ($purchasefeetable_edit->tableid->Required) { ?>
				elm = this.getElements("x" + infix + "_tableid");
				if (elm && !ew.isHidden(elm) && !ew.hasValue(elm))
					return this.onError(elm, "<?php echo JsEncode(str_replace("%s", $purchasefeetable_edit->tableid->caption(), $purchasefeetable_edit->tableid->RequiredErrorMessage)) ?>");
			<?php } ?>
			<?php if ($purchasefeetable_edit->active->Required) { ?>
				elm = this.getElements("x" + infix + "_active");
				if (elm && !ew.isHidden(elm) && !ew.hasValue(elm))
					return this.onError(elm, "<?php echo JsEncode(str_replace("%s", $purchasefeetable_edit->active->caption(), $purchasefeetable_edit->active->RequiredErrorMessage)) ?>");
			<?php } ?>
				elm = this.getElements("x" + infix + "_active");
				if (elm && !ew.checkInteger(elm.value))
					return this.onError(elm, "<?php echo JsEncode($purchasefeetable_edit->active->errorMessage()) ?>");
			<?php if ($purchasefeetable_edit->description->Required) { ?>
				elm = this.getElements("x" + infix + "_description");
				if (elm && !ew.isHidden(elm) && !ew.hasValue(elm))
					return this.onError(elm, "<?php echo JsEncode(str_replace("%s", $purchasefeetable_edit->description->caption(), $purchasefeetable_edit->description->RequiredErrorMessage)) ?>");
			<?php } ?>

				// Call Form_CustomValidate event
				if (!this.Form_CustomValidate(fobj))
					return false;
		}

		// Process detail forms
		var dfs = $fobj.find("input[name='detailpage']").get();
		for (var i = 0; i < dfs.length; i++) {
			var df = dfs[i], val = df.value;
			if (val && ew.forms[val])
				if (!ew.forms[val].validate())
					return false;
		}
		return true;
	}

	// Form_CustomValidate
	fpurchasefeetableedit.Form_CustomValidate = function(fobj) { // DO NOT CHANGE THIS LINE!

		// Your custom validation code here, return false if invalid.
		return true;
	}

	// Use JavaScript validation or not
	fpurchasefeetableedit.validateRequired = <?php echo Config("CLIENT_VALIDATE") ? "true" : "false" ?>;

	// Dynamic selection lists
	loadjs.done("fpurchasefeetableedit");
});
</script>
<script>
loadjs.ready("head", function() {

	// Client script
	// Write your client script here, no need to add script tags.

});
</script>
<?php $purchasefeetable_edit->showPageHeader(); ?>
<?php
$purchasefeetable_edit->showMessage();
?>
<form name="fpurchasefeetableedit" id="fpurchasefeetableedit" class="<?php echo $purchasefeetable_edit->FormClassName ?>" action="<?php echo CurrentPageName() ?>" method="post">
<?php if ($Page->CheckToken) { ?>
<input type="hidden" name="<?php echo Config("TOKEN_NAME") ?>" value="<?php echo $Page->Token ?>">
<?php } ?>
<input type="hidden" name="t" value="purchasefeetable">
<input type="hidden" name="action" id="action" value="update">
<input type="hidden" name="modal" value="<?php echo (int)$purchasefeetable_edit->IsModal ?>">
<div class="ew-edit-div"><!-- page* -->
<?php if ($purchasefeetable_edit->tableid->Visible) { // tableid ?>
	<div id="r_tableid" class="form-group row">
		<label id="elh_purchasefeetable_tableid" class="<?php echo $purchasefeetable_edit->LeftColumnClass ?>"><?php echo $purchasefeetable_edit->tableid->caption() ?><?php echo $purchasefeetable_edit->tableid->Required ? $Language->phrase("FieldRequiredIndicator") : "" ?></label>
		<div class="<?php echo $purchasefeetable_edit->RightColumnClass ?>"><div <?php echo $purchasefeetable_edit->tableid->cellAttributes() ?>>
<span id="el_purchasefeetable_tableid">
<span<?php echo $purchasefeetable_edit->tableid->viewAttributes() ?>><input type="text" readonly class="form-control-plaintext" value="<?php echo HtmlEncode(RemoveHtml($purchasefeetable_edit->tableid->EditValue)) ?>"></span>
</span>
<input type="hidden" data-table="purchasefeetable" data-field="x_tableid" name="x_tableid" id="x_tableid" value="<?php echo HtmlEncode($purchasefeetable_edit->tableid->CurrentValue) ?>">
<?php echo $purchasefeetable_edit->tableid->CustomMsg ?></div></div>
	</div>
<?php } ?>
<?php if ($purchasefeetable_edit->active->Visible) { // active ?>
	<div id="r_active" class="form-group row">
		<label id="elh_purchasefeetable_active" for="x_active" class="<?php echo $purchasefeetable_edit->LeftColumnClass ?>"><?php echo $purchasefeetable_edit->active->caption() ?><?php echo $purchasefeetable_edit->active->Required ? $Language->phrase("FieldRequiredIndicator") : "" ?></label>
		<div class="<?php echo $purchasefeetable_edit->RightColumnClass ?>"><div <?php echo $purchasefeetable_edit->active->cellAttributes() ?>>
<span id="el_purchasefeetable_active">
<input type="text" data-table="purchasefeetable" data-field="x_active" name="x_active" id="x_active" size="30" maxlength="1" placeholder="<?php echo HtmlEncode($purchasefeetable_edit->active->getPlaceHolder()) ?>" value="<?php echo $purchasefeetable_edit->active->EditValue ?>"<?php echo $purchasefeetable_edit->active->editAttributes() ?>>
</span>
<?php echo $purchasefeetable_edit->active->CustomMsg ?></div></div>
	</div>
<?php } ?>
<?php if ($purchasefeetable_edit->description->Visible) { // description ?>
	<div id="r_description" class="form-group row">
		<label id="elh_purchasefeetable_description" for="x_description" class="<?php echo $purchasefeetable_edit->LeftColumnClass ?>"><?php echo $purchasefeetable_edit->description->caption() ?><?php echo $purchasefeetable_edit->description->Required ? $Language->phrase("FieldRequiredIndicator") : "" ?></label>
		<div class="<?php echo $purchasefeetable_edit->RightColumnClass ?>"><div <?php echo $purchasefeetable_edit->description->cellAttributes() ?>>
<span id="el_purchasefeetable_description">
<input type="text" data-table="purchasefeetable" data-field="x_description" name="x_description" id="x_description" size="30" maxlength="60" placeholder="<?php echo HtmlEncode($purchasefeetable_edit->description->getPlaceHolder()) ?>" value="<?php echo $purchasefeetable_edit->description->EditValue ?>"<?php echo $purchasefeetable_edit->description->editAttributes() ?>>
</span>
<?php echo $purchasefeetable_edit->description->CustomMsg ?></div></div>
	</div>
<?php } ?>
</div><!-- /page* -->
<?php if (!$purchasefeetable_edit->IsModal) { ?>
<div class="form-group row"><!-- buttons .form-group -->
	<div class="<?php echo $purchasefeetable_edit->OffsetColumnClass ?>"><!-- buttons offset -->
<button class="btn btn-primary ew-btn" name="btn-action" id="btn-action" type="submit"><?php echo $Language->phrase("SaveBtn") ?></button>
<button class="btn btn-default ew-btn" name="btn-cancel" id="btn-cancel" type="button" data-href="<?php echo $purchasefeetable_edit->getReturnUrl() ?>"><?php echo $Language->phrase("CancelBtn") ?></button>
	</div><!-- /buttons offset -->
</div><!-- /buttons .form-group -->
<?php } ?>
</form>
<?php
$purchasefeetable_edit->showPageFooter();
if (Config("DEBUG"))
	echo GetDebugMessage();
?>
<script>
loadjs.ready("load", function() {

	// Startup script
	// Write your table-specific startup script here
	// console.log("page loaded");

});
</script>
<?php include_once "footer.php"; ?>
<?php
$purchasefeetable_edit->terminate();
?>