<?php
namespace PHPMaker2020\_4payadmin;

// Autoload
include_once "autoload.php";

// Session
if (session_status() !== PHP_SESSION_ACTIVE)
	\Delight\Cookie\Session::start(Config("COOKIE_SAMESITE")); // Init session data

// Output buffering
ob_start();
?>
<?php

// Write header
WriteHeader(FALSE);

// Create page object
$loanlimitsjournal_add = new loanlimitsjournal_add();

// Run the page
$loanlimitsjournal_add->run();

// Setup login status
SetupLoginStatus();
SetClientVar("login", LoginStatus());

// Global Page Rendering event (in userfn*.php)
Page_Rendering();

// Page Rendering event
$loanlimitsjournal_add->Page_Render();
?>
<?php include_once "header.php"; ?>
<script>
var floanlimitsjournaladd, currentPageID;
loadjs.ready("head", function() {

	// Form object
	currentPageID = ew.PAGE_ID = "add";
	floanlimitsjournaladd = currentForm = new ew.Form("floanlimitsjournaladd", "add");

	// Validate form
	floanlimitsjournaladd.validate = function() {
		if (!this.validateRequired)
			return true; // Ignore validation
		var $ = jQuery, fobj = this.getForm(), $fobj = $(fobj);
		if ($fobj.find("#confirm").val() == "confirm")
			return true;
		var elm, felm, uelm, addcnt = 0;
		var $k = $fobj.find("#" + this.formKeyCountName); // Get key_count
		var rowcnt = ($k[0]) ? parseInt($k.val(), 10) : 1;
		var startcnt = (rowcnt == 0) ? 0 : 1; // Check rowcnt == 0 => Inline-Add
		var gridinsert = ["insert", "gridinsert"].includes($fobj.find("#action").val()) && $k[0];
		for (var i = startcnt; i <= rowcnt; i++) {
			var infix = ($k[0]) ? String(i) : "";
			$fobj.data("rowindex", infix);
			<?php if ($loanlimitsjournal_add->_userid->Required) { ?>
				elm = this.getElements("x" + infix + "__userid");
				if (elm && !ew.isHidden(elm) && !ew.hasValue(elm))
					return this.onError(elm, "<?php echo JsEncode(str_replace("%s", $loanlimitsjournal_add->_userid->caption(), $loanlimitsjournal_add->_userid->RequiredErrorMessage)) ?>");
			<?php } ?>
				elm = this.getElements("x" + infix + "__userid");
				if (elm && !ew.checkInteger(elm.value))
					return this.onError(elm, "<?php echo JsEncode($loanlimitsjournal_add->_userid->errorMessage()) ?>");
			<?php if ($loanlimitsjournal_add->currcode->Required) { ?>
				elm = this.getElements("x" + infix + "_currcode");
				if (elm && !ew.isHidden(elm) && !ew.hasValue(elm))
					return this.onError(elm, "<?php echo JsEncode(str_replace("%s", $loanlimitsjournal_add->currcode->caption(), $loanlimitsjournal_add->currcode->RequiredErrorMessage)) ?>");
			<?php } ?>
			<?php if ($loanlimitsjournal_add->changetime->Required) { ?>
				elm = this.getElements("x" + infix + "_changetime");
				if (elm && !ew.isHidden(elm) && !ew.hasValue(elm))
					return this.onError(elm, "<?php echo JsEncode(str_replace("%s", $loanlimitsjournal_add->changetime->caption(), $loanlimitsjournal_add->changetime->RequiredErrorMessage)) ?>");
			<?php } ?>
				elm = this.getElements("x" + infix + "_changetime");
				if (elm && !ew.checkDateDef(elm.value))
					return this.onError(elm, "<?php echo JsEncode($loanlimitsjournal_add->changetime->errorMessage()) ?>");

				// Call Form_CustomValidate event
				if (!this.Form_CustomValidate(fobj))
					return false;
		}

		// Process detail forms
		var dfs = $fobj.find("input[name='detailpage']").get();
		for (var i = 0; i < dfs.length; i++) {
			var df = dfs[i], val = df.value;
			if (val && ew.forms[val])
				if (!ew.forms[val].validate())
					return false;
		}
		return true;
	}

	// Form_CustomValidate
	floanlimitsjournaladd.Form_CustomValidate = function(fobj) { // DO NOT CHANGE THIS LINE!

		// Your custom validation code here, return false if invalid.
		return true;
	}

	// Use JavaScript validation or not
	floanlimitsjournaladd.validateRequired = <?php echo Config("CLIENT_VALIDATE") ? "true" : "false" ?>;

	// Dynamic selection lists
	loadjs.done("floanlimitsjournaladd");
});
</script>
<script>
loadjs.ready("head", function() {

	// Client script
	// Write your client script here, no need to add script tags.

});
</script>
<?php $loanlimitsjournal_add->showPageHeader(); ?>
<?php
$loanlimitsjournal_add->showMessage();
?>
<form name="floanlimitsjournaladd" id="floanlimitsjournaladd" class="<?php echo $loanlimitsjournal_add->FormClassName ?>" action="<?php echo CurrentPageName() ?>" method="post">
<?php if ($Page->CheckToken) { ?>
<input type="hidden" name="<?php echo Config("TOKEN_NAME") ?>" value="<?php echo $Page->Token ?>">
<?php } ?>
<input type="hidden" name="t" value="loanlimitsjournal">
<input type="hidden" name="action" id="action" value="insert">
<input type="hidden" name="modal" value="<?php echo (int)$loanlimitsjournal_add->IsModal ?>">
<div class="ew-add-div"><!-- page* -->
<?php if ($loanlimitsjournal_add->_userid->Visible) { // userid ?>
	<div id="r__userid" class="form-group row">
		<label id="elh_loanlimitsjournal__userid" for="x__userid" class="<?php echo $loanlimitsjournal_add->LeftColumnClass ?>"><?php echo $loanlimitsjournal_add->_userid->caption() ?><?php echo $loanlimitsjournal_add->_userid->Required ? $Language->phrase("FieldRequiredIndicator") : "" ?></label>
		<div class="<?php echo $loanlimitsjournal_add->RightColumnClass ?>"><div <?php echo $loanlimitsjournal_add->_userid->cellAttributes() ?>>
<span id="el_loanlimitsjournal__userid">
<input type="text" data-table="loanlimitsjournal" data-field="x__userid" name="x__userid" id="x__userid" size="30" maxlength="12" placeholder="<?php echo HtmlEncode($loanlimitsjournal_add->_userid->getPlaceHolder()) ?>" value="<?php echo $loanlimitsjournal_add->_userid->EditValue ?>"<?php echo $loanlimitsjournal_add->_userid->editAttributes() ?>>
</span>
<?php echo $loanlimitsjournal_add->_userid->CustomMsg ?></div></div>
	</div>
<?php } ?>
<?php if ($loanlimitsjournal_add->currcode->Visible) { // currcode ?>
	<div id="r_currcode" class="form-group row">
		<label id="elh_loanlimitsjournal_currcode" for="x_currcode" class="<?php echo $loanlimitsjournal_add->LeftColumnClass ?>"><?php echo $loanlimitsjournal_add->currcode->caption() ?><?php echo $loanlimitsjournal_add->currcode->Required ? $Language->phrase("FieldRequiredIndicator") : "" ?></label>
		<div class="<?php echo $loanlimitsjournal_add->RightColumnClass ?>"><div <?php echo $loanlimitsjournal_add->currcode->cellAttributes() ?>>
<span id="el_loanlimitsjournal_currcode">
<input type="text" data-table="loanlimitsjournal" data-field="x_currcode" name="x_currcode" id="x_currcode" size="30" maxlength="3" placeholder="<?php echo HtmlEncode($loanlimitsjournal_add->currcode->getPlaceHolder()) ?>" value="<?php echo $loanlimitsjournal_add->currcode->EditValue ?>"<?php echo $loanlimitsjournal_add->currcode->editAttributes() ?>>
</span>
<?php echo $loanlimitsjournal_add->currcode->CustomMsg ?></div></div>
	</div>
<?php } ?>
<?php if ($loanlimitsjournal_add->changetime->Visible) { // changetime ?>
	<div id="r_changetime" class="form-group row">
		<label id="elh_loanlimitsjournal_changetime" for="x_changetime" class="<?php echo $loanlimitsjournal_add->LeftColumnClass ?>"><?php echo $loanlimitsjournal_add->changetime->caption() ?><?php echo $loanlimitsjournal_add->changetime->Required ? $Language->phrase("FieldRequiredIndicator") : "" ?></label>
		<div class="<?php echo $loanlimitsjournal_add->RightColumnClass ?>"><div <?php echo $loanlimitsjournal_add->changetime->cellAttributes() ?>>
<span id="el_loanlimitsjournal_changetime">
<input type="text" data-table="loanlimitsjournal" data-field="x_changetime" name="x_changetime" id="x_changetime" maxlength="19" placeholder="<?php echo HtmlEncode($loanlimitsjournal_add->changetime->getPlaceHolder()) ?>" value="<?php echo $loanlimitsjournal_add->changetime->EditValue ?>"<?php echo $loanlimitsjournal_add->changetime->editAttributes() ?>>
<?php if (!$loanlimitsjournal_add->changetime->ReadOnly && !$loanlimitsjournal_add->changetime->Disabled && !isset($loanlimitsjournal_add->changetime->EditAttrs["readonly"]) && !isset($loanlimitsjournal_add->changetime->EditAttrs["disabled"])) { ?>
<script>
loadjs.ready(["floanlimitsjournaladd", "datetimepicker"], function() {
	ew.createDateTimePicker("floanlimitsjournaladd", "x_changetime", {"ignoreReadonly":true,"useCurrent":false,"format":0});
});
</script>
<?php } ?>
</span>
<?php echo $loanlimitsjournal_add->changetime->CustomMsg ?></div></div>
	</div>
<?php } ?>
</div><!-- /page* -->
<?php if (!$loanlimitsjournal_add->IsModal) { ?>
<div class="form-group row"><!-- buttons .form-group -->
	<div class="<?php echo $loanlimitsjournal_add->OffsetColumnClass ?>"><!-- buttons offset -->
<button class="btn btn-primary ew-btn" name="btn-action" id="btn-action" type="submit"><?php echo $Language->phrase("AddBtn") ?></button>
<button class="btn btn-default ew-btn" name="btn-cancel" id="btn-cancel" type="button" data-href="<?php echo $loanlimitsjournal_add->getReturnUrl() ?>"><?php echo $Language->phrase("CancelBtn") ?></button>
	</div><!-- /buttons offset -->
</div><!-- /buttons .form-group -->
<?php } ?>
</form>
<?php
$loanlimitsjournal_add->showPageFooter();
if (Config("DEBUG"))
	echo GetDebugMessage();
?>
<script>
loadjs.ready("load", function() {

	// Startup script
	// Write your table-specific startup script here
	// console.log("page loaded");

});
</script>
<?php include_once "footer.php"; ?>
<?php
$loanlimitsjournal_add->terminate();
?>