<?php
namespace PHPMaker2020\_4payadmin;

// Autoload
include_once "autoload.php";

// Session
if (session_status() !== PHP_SESSION_ACTIVE)
	\Delight\Cookie\Session::start(Config("COOKIE_SAMESITE")); // Init session data

// Output buffering
ob_start();
?>
<?php

// Write header
WriteHeader(FALSE);

// Create page object
$loansimulatorcases_edit = new loansimulatorcases_edit();

// Run the page
$loansimulatorcases_edit->run();

// Setup login status
SetupLoginStatus();
SetClientVar("login", LoginStatus());

// Global Page Rendering event (in userfn*.php)
Page_Rendering();

// Page Rendering event
$loansimulatorcases_edit->Page_Render();
?>
<?php include_once "header.php"; ?>
<script>
var floansimulatorcasesedit, currentPageID;
loadjs.ready("head", function() {

	// Form object
	currentPageID = ew.PAGE_ID = "edit";
	floansimulatorcasesedit = currentForm = new ew.Form("floansimulatorcasesedit", "edit");

	// Validate form
	floansimulatorcasesedit.validate = function() {
		if (!this.validateRequired)
			return true; // Ignore validation
		var $ = jQuery, fobj = this.getForm(), $fobj = $(fobj);
		if ($fobj.find("#confirm").val() == "confirm")
			return true;
		var elm, felm, uelm, addcnt = 0;
		var $k = $fobj.find("#" + this.formKeyCountName); // Get key_count
		var rowcnt = ($k[0]) ? parseInt($k.val(), 10) : 1;
		var startcnt = (rowcnt == 0) ? 0 : 1; // Check rowcnt == 0 => Inline-Add
		var gridinsert = ["insert", "gridinsert"].includes($fobj.find("#action").val()) && $k[0];
		for (var i = startcnt; i <= rowcnt; i++) {
			var infix = ($k[0]) ? String(i) : "";
			$fobj.data("rowindex", infix);
			<?php if ($loansimulatorcases_edit->caseid->Required) { ?>
				elm = this.getElements("x" + infix + "_caseid");
				if (elm && !ew.isHidden(elm) && !ew.hasValue(elm))
					return this.onError(elm, "<?php echo JsEncode(str_replace("%s", $loansimulatorcases_edit->caseid->caption(), $loansimulatorcases_edit->caseid->RequiredErrorMessage)) ?>");
			<?php } ?>
			<?php if ($loansimulatorcases_edit->loandate->Required) { ?>
				elm = this.getElements("x" + infix + "_loandate");
				if (elm && !ew.isHidden(elm) && !ew.hasValue(elm))
					return this.onError(elm, "<?php echo JsEncode(str_replace("%s", $loansimulatorcases_edit->loandate->caption(), $loansimulatorcases_edit->loandate->RequiredErrorMessage)) ?>");
			<?php } ?>
				elm = this.getElements("x" + infix + "_loandate");
				if (elm && !ew.checkDateDef(elm.value))
					return this.onError(elm, "<?php echo JsEncode($loansimulatorcases_edit->loandate->errorMessage()) ?>");
			<?php if ($loansimulatorcases_edit->externalusertype->Required) { ?>
				elm = this.getElements("x" + infix + "_externalusertype");
				if (elm && !ew.isHidden(elm) && !ew.hasValue(elm))
					return this.onError(elm, "<?php echo JsEncode(str_replace("%s", $loansimulatorcases_edit->externalusertype->caption(), $loansimulatorcases_edit->externalusertype->RequiredErrorMessage)) ?>");
			<?php } ?>
				elm = this.getElements("x" + infix + "_externalusertype");
				if (elm && !ew.checkInteger(elm.value))
					return this.onError(elm, "<?php echo JsEncode($loansimulatorcases_edit->externalusertype->errorMessage()) ?>");
			<?php if ($loansimulatorcases_edit->_userid->Required) { ?>
				elm = this.getElements("x" + infix + "__userid");
				if (elm && !ew.isHidden(elm) && !ew.hasValue(elm))
					return this.onError(elm, "<?php echo JsEncode(str_replace("%s", $loansimulatorcases_edit->_userid->caption(), $loansimulatorcases_edit->_userid->RequiredErrorMessage)) ?>");
			<?php } ?>
			<?php if ($loansimulatorcases_edit->_action->Required) { ?>
				elm = this.getElements("x" + infix + "__action");
				if (elm && !ew.isHidden(elm) && !ew.hasValue(elm))
					return this.onError(elm, "<?php echo JsEncode(str_replace("%s", $loansimulatorcases_edit->_action->caption(), $loansimulatorcases_edit->_action->RequiredErrorMessage)) ?>");
			<?php } ?>
			<?php if ($loansimulatorcases_edit->curr->Required) { ?>
				elm = this.getElements("x" + infix + "_curr");
				if (elm && !ew.isHidden(elm) && !ew.hasValue(elm))
					return this.onError(elm, "<?php echo JsEncode(str_replace("%s", $loansimulatorcases_edit->curr->caption(), $loansimulatorcases_edit->curr->RequiredErrorMessage)) ?>");
			<?php } ?>
			<?php if ($loansimulatorcases_edit->amount->Required) { ?>
				elm = this.getElements("x" + infix + "_amount");
				if (elm && !ew.isHidden(elm) && !ew.hasValue(elm))
					return this.onError(elm, "<?php echo JsEncode(str_replace("%s", $loansimulatorcases_edit->amount->caption(), $loansimulatorcases_edit->amount->RequiredErrorMessage)) ?>");
			<?php } ?>
				elm = this.getElements("x" + infix + "_amount");
				if (elm && !ew.checkNumber(elm.value))
					return this.onError(elm, "<?php echo JsEncode($loansimulatorcases_edit->amount->errorMessage()) ?>");
			<?php if ($loansimulatorcases_edit->loantype->Required) { ?>
				elm = this.getElements("x" + infix + "_loantype");
				if (elm && !ew.isHidden(elm) && !ew.hasValue(elm))
					return this.onError(elm, "<?php echo JsEncode(str_replace("%s", $loansimulatorcases_edit->loantype->caption(), $loansimulatorcases_edit->loantype->RequiredErrorMessage)) ?>");
			<?php } ?>
			<?php if ($loansimulatorcases_edit->timeslot->Required) { ?>
				elm = this.getElements("x" + infix + "_timeslot");
				if (elm && !ew.isHidden(elm) && !ew.hasValue(elm))
					return this.onError(elm, "<?php echo JsEncode(str_replace("%s", $loansimulatorcases_edit->timeslot->caption(), $loansimulatorcases_edit->timeslot->RequiredErrorMessage)) ?>");
			<?php } ?>
			<?php if ($loansimulatorcases_edit->sequence->Required) { ?>
				elm = this.getElements("x" + infix + "_sequence");
				if (elm && !ew.isHidden(elm) && !ew.hasValue(elm))
					return this.onError(elm, "<?php echo JsEncode(str_replace("%s", $loansimulatorcases_edit->sequence->caption(), $loansimulatorcases_edit->sequence->RequiredErrorMessage)) ?>");
			<?php } ?>
				elm = this.getElements("x" + infix + "_sequence");
				if (elm && !ew.checkInteger(elm.value))
					return this.onError(elm, "<?php echo JsEncode($loansimulatorcases_edit->sequence->errorMessage()) ?>");
			<?php if ($loansimulatorcases_edit->uselastloanid->Required) { ?>
				elm = this.getElements("x" + infix + "_uselastloanid");
				if (elm && !ew.isHidden(elm) && !ew.hasValue(elm))
					return this.onError(elm, "<?php echo JsEncode(str_replace("%s", $loansimulatorcases_edit->uselastloanid->caption(), $loansimulatorcases_edit->uselastloanid->RequiredErrorMessage)) ?>");
			<?php } ?>

				// Call Form_CustomValidate event
				if (!this.Form_CustomValidate(fobj))
					return false;
		}

		// Process detail forms
		var dfs = $fobj.find("input[name='detailpage']").get();
		for (var i = 0; i < dfs.length; i++) {
			var df = dfs[i], val = df.value;
			if (val && ew.forms[val])
				if (!ew.forms[val].validate())
					return false;
		}
		return true;
	}

	// Form_CustomValidate
	floansimulatorcasesedit.Form_CustomValidate = function(fobj) { // DO NOT CHANGE THIS LINE!

		// Your custom validation code here, return false if invalid.
		return true;
	}

	// Use JavaScript validation or not
	floansimulatorcasesedit.validateRequired = <?php echo Config("CLIENT_VALIDATE") ? "true" : "false" ?>;

	// Dynamic selection lists
	floansimulatorcasesedit.lists["x__action"] = <?php echo $loansimulatorcases_edit->_action->Lookup->toClientList($loansimulatorcases_edit) ?>;
	floansimulatorcasesedit.lists["x__action"].options = <?php echo JsonEncode($loansimulatorcases_edit->_action->options(FALSE, TRUE)) ?>;
	floansimulatorcasesedit.lists["x_curr"] = <?php echo $loansimulatorcases_edit->curr->Lookup->toClientList($loansimulatorcases_edit) ?>;
	floansimulatorcasesedit.lists["x_curr"].options = <?php echo JsonEncode($loansimulatorcases_edit->curr->lookupOptions()) ?>;
	floansimulatorcasesedit.lists["x_loantype"] = <?php echo $loansimulatorcases_edit->loantype->Lookup->toClientList($loansimulatorcases_edit) ?>;
	floansimulatorcasesedit.lists["x_loantype"].options = <?php echo JsonEncode($loansimulatorcases_edit->loantype->lookupOptions()) ?>;
	floansimulatorcasesedit.lists["x_timeslot"] = <?php echo $loansimulatorcases_edit->timeslot->Lookup->toClientList($loansimulatorcases_edit) ?>;
	floansimulatorcasesedit.lists["x_timeslot"].options = <?php echo JsonEncode($loansimulatorcases_edit->timeslot->options(FALSE, TRUE)) ?>;
	floansimulatorcasesedit.lists["x_uselastloanid"] = <?php echo $loansimulatorcases_edit->uselastloanid->Lookup->toClientList($loansimulatorcases_edit) ?>;
	floansimulatorcasesedit.lists["x_uselastloanid"].options = <?php echo JsonEncode($loansimulatorcases_edit->uselastloanid->lookupOptions()) ?>;
	loadjs.done("floansimulatorcasesedit");
});
</script>
<script>
loadjs.ready("head", function() {

	// Client script
	// Write your client script here, no need to add script tags.

});
</script>
<?php $loansimulatorcases_edit->showPageHeader(); ?>
<?php
$loansimulatorcases_edit->showMessage();
?>
<form name="floansimulatorcasesedit" id="floansimulatorcasesedit" class="<?php echo $loansimulatorcases_edit->FormClassName ?>" action="<?php echo CurrentPageName() ?>" method="post">
<?php if ($Page->CheckToken) { ?>
<input type="hidden" name="<?php echo Config("TOKEN_NAME") ?>" value="<?php echo $Page->Token ?>">
<?php } ?>
<input type="hidden" name="t" value="loansimulatorcases">
<input type="hidden" name="action" id="action" value="update">
<input type="hidden" name="modal" value="<?php echo (int)$loansimulatorcases_edit->IsModal ?>">
<div class="ew-edit-div"><!-- page* -->
<?php if ($loansimulatorcases_edit->caseid->Visible) { // caseid ?>
	<div id="r_caseid" class="form-group row">
		<label id="elh_loansimulatorcases_caseid" class="<?php echo $loansimulatorcases_edit->LeftColumnClass ?>"><?php echo $loansimulatorcases_edit->caseid->caption() ?><?php echo $loansimulatorcases_edit->caseid->Required ? $Language->phrase("FieldRequiredIndicator") : "" ?></label>
		<div class="<?php echo $loansimulatorcases_edit->RightColumnClass ?>"><div <?php echo $loansimulatorcases_edit->caseid->cellAttributes() ?>>
<span id="el_loansimulatorcases_caseid">
<span<?php echo $loansimulatorcases_edit->caseid->viewAttributes() ?>><input type="text" readonly class="form-control-plaintext" value="<?php echo HtmlEncode(RemoveHtml($loansimulatorcases_edit->caseid->EditValue)) ?>"></span>
</span>
<input type="hidden" data-table="loansimulatorcases" data-field="x_caseid" name="x_caseid" id="x_caseid" value="<?php echo HtmlEncode($loansimulatorcases_edit->caseid->CurrentValue) ?>">
<?php echo $loansimulatorcases_edit->caseid->CustomMsg ?></div></div>
	</div>
<?php } ?>
<?php if ($loansimulatorcases_edit->loandate->Visible) { // loandate ?>
	<div id="r_loandate" class="form-group row">
		<label id="elh_loansimulatorcases_loandate" for="x_loandate" class="<?php echo $loansimulatorcases_edit->LeftColumnClass ?>"><?php echo $loansimulatorcases_edit->loandate->caption() ?><?php echo $loansimulatorcases_edit->loandate->Required ? $Language->phrase("FieldRequiredIndicator") : "" ?></label>
		<div class="<?php echo $loansimulatorcases_edit->RightColumnClass ?>"><div <?php echo $loansimulatorcases_edit->loandate->cellAttributes() ?>>
<span id="el_loansimulatorcases_loandate">
<input type="text" data-table="loansimulatorcases" data-field="x_loandate" data-format="2" name="x_loandate" id="x_loandate" maxlength="10" placeholder="<?php echo HtmlEncode($loansimulatorcases_edit->loandate->getPlaceHolder()) ?>" value="<?php echo $loansimulatorcases_edit->loandate->EditValue ?>"<?php echo $loansimulatorcases_edit->loandate->editAttributes() ?>>
<?php if (!$loansimulatorcases_edit->loandate->ReadOnly && !$loansimulatorcases_edit->loandate->Disabled && !isset($loansimulatorcases_edit->loandate->EditAttrs["readonly"]) && !isset($loansimulatorcases_edit->loandate->EditAttrs["disabled"])) { ?>
<script>
loadjs.ready(["floansimulatorcasesedit", "datetimepicker"], function() {
	ew.createDateTimePicker("floansimulatorcasesedit", "x_loandate", {"ignoreReadonly":true,"useCurrent":false,"format":2});
});
</script>
<?php } ?>
</span>
<?php echo $loansimulatorcases_edit->loandate->CustomMsg ?></div></div>
	</div>
<?php } ?>
<?php if ($loansimulatorcases_edit->externalusertype->Visible) { // externalusertype ?>
	<div id="r_externalusertype" class="form-group row">
		<label id="elh_loansimulatorcases_externalusertype" for="x_externalusertype" class="<?php echo $loansimulatorcases_edit->LeftColumnClass ?>"><?php echo $loansimulatorcases_edit->externalusertype->caption() ?><?php echo $loansimulatorcases_edit->externalusertype->Required ? $Language->phrase("FieldRequiredIndicator") : "" ?></label>
		<div class="<?php echo $loansimulatorcases_edit->RightColumnClass ?>"><div <?php echo $loansimulatorcases_edit->externalusertype->cellAttributes() ?>>
<span id="el_loansimulatorcases_externalusertype">
<input type="text" data-table="loansimulatorcases" data-field="x_externalusertype" name="x_externalusertype" id="x_externalusertype" size="30" maxlength="5" placeholder="<?php echo HtmlEncode($loansimulatorcases_edit->externalusertype->getPlaceHolder()) ?>" value="<?php echo $loansimulatorcases_edit->externalusertype->EditValue ?>"<?php echo $loansimulatorcases_edit->externalusertype->editAttributes() ?>>
</span>
<?php echo $loansimulatorcases_edit->externalusertype->CustomMsg ?></div></div>
	</div>
<?php } ?>
<?php if ($loansimulatorcases_edit->_userid->Visible) { // userid ?>
	<div id="r__userid" class="form-group row">
		<label id="elh_loansimulatorcases__userid" for="x__userid" class="<?php echo $loansimulatorcases_edit->LeftColumnClass ?>"><?php echo $loansimulatorcases_edit->_userid->caption() ?><?php echo $loansimulatorcases_edit->_userid->Required ? $Language->phrase("FieldRequiredIndicator") : "" ?></label>
		<div class="<?php echo $loansimulatorcases_edit->RightColumnClass ?>"><div <?php echo $loansimulatorcases_edit->_userid->cellAttributes() ?>>
<span id="el_loansimulatorcases__userid">
<input type="text" data-table="loansimulatorcases" data-field="x__userid" name="x__userid" id="x__userid" size="30" maxlength="20" placeholder="<?php echo HtmlEncode($loansimulatorcases_edit->_userid->getPlaceHolder()) ?>" value="<?php echo $loansimulatorcases_edit->_userid->EditValue ?>"<?php echo $loansimulatorcases_edit->_userid->editAttributes() ?>>
</span>
<?php echo $loansimulatorcases_edit->_userid->CustomMsg ?></div></div>
	</div>
<?php } ?>
<?php if ($loansimulatorcases_edit->_action->Visible) { // action ?>
	<div id="r__action" class="form-group row">
		<label id="elh_loansimulatorcases__action" for="x__action" class="<?php echo $loansimulatorcases_edit->LeftColumnClass ?>"><?php echo $loansimulatorcases_edit->_action->caption() ?><?php echo $loansimulatorcases_edit->_action->Required ? $Language->phrase("FieldRequiredIndicator") : "" ?></label>
		<div class="<?php echo $loansimulatorcases_edit->RightColumnClass ?>"><div <?php echo $loansimulatorcases_edit->_action->cellAttributes() ?>>
<span id="el_loansimulatorcases__action">
<div class="input-group">
	<select class="custom-select ew-custom-select" data-table="loansimulatorcases" data-field="x__action" data-value-separator="<?php echo $loansimulatorcases_edit->_action->displayValueSeparatorAttribute() ?>" id="x__action" name="x__action"<?php echo $loansimulatorcases_edit->_action->editAttributes() ?>>
			<?php echo $loansimulatorcases_edit->_action->selectOptionListHtml("x__action") ?>
		</select>
</div>
</span>
<?php echo $loansimulatorcases_edit->_action->CustomMsg ?></div></div>
	</div>
<?php } ?>
<?php if ($loansimulatorcases_edit->curr->Visible) { // curr ?>
	<div id="r_curr" class="form-group row">
		<label id="elh_loansimulatorcases_curr" for="x_curr" class="<?php echo $loansimulatorcases_edit->LeftColumnClass ?>"><?php echo $loansimulatorcases_edit->curr->caption() ?><?php echo $loansimulatorcases_edit->curr->Required ? $Language->phrase("FieldRequiredIndicator") : "" ?></label>
		<div class="<?php echo $loansimulatorcases_edit->RightColumnClass ?>"><div <?php echo $loansimulatorcases_edit->curr->cellAttributes() ?>>
<span id="el_loansimulatorcases_curr">
<?php $loansimulatorcases_edit->curr->EditAttrs->prepend("onchange", "ew.updateOptions.call(this);"); ?>
<div class="input-group">
	<select class="custom-select ew-custom-select" data-table="loansimulatorcases" data-field="x_curr" data-value-separator="<?php echo $loansimulatorcases_edit->curr->displayValueSeparatorAttribute() ?>" id="x_curr" name="x_curr"<?php echo $loansimulatorcases_edit->curr->editAttributes() ?>>
			<?php echo $loansimulatorcases_edit->curr->selectOptionListHtml("x_curr") ?>
		</select>
</div>
<?php echo $loansimulatorcases_edit->curr->Lookup->getParamTag($loansimulatorcases_edit, "p_x_curr") ?>
</span>
<?php echo $loansimulatorcases_edit->curr->CustomMsg ?></div></div>
	</div>
<?php } ?>
<?php if ($loansimulatorcases_edit->amount->Visible) { // amount ?>
	<div id="r_amount" class="form-group row">
		<label id="elh_loansimulatorcases_amount" for="x_amount" class="<?php echo $loansimulatorcases_edit->LeftColumnClass ?>"><?php echo $loansimulatorcases_edit->amount->caption() ?><?php echo $loansimulatorcases_edit->amount->Required ? $Language->phrase("FieldRequiredIndicator") : "" ?></label>
		<div class="<?php echo $loansimulatorcases_edit->RightColumnClass ?>"><div <?php echo $loansimulatorcases_edit->amount->cellAttributes() ?>>
<span id="el_loansimulatorcases_amount">
<input type="text" data-table="loansimulatorcases" data-field="x_amount" name="x_amount" id="x_amount" size="30" maxlength="12" placeholder="<?php echo HtmlEncode($loansimulatorcases_edit->amount->getPlaceHolder()) ?>" value="<?php echo $loansimulatorcases_edit->amount->EditValue ?>"<?php echo $loansimulatorcases_edit->amount->editAttributes() ?>>
</span>
<?php echo $loansimulatorcases_edit->amount->CustomMsg ?></div></div>
	</div>
<?php } ?>
<?php if ($loansimulatorcases_edit->loantype->Visible) { // loantype ?>
	<div id="r_loantype" class="form-group row">
		<label id="elh_loansimulatorcases_loantype" for="x_loantype" class="<?php echo $loansimulatorcases_edit->LeftColumnClass ?>"><?php echo $loansimulatorcases_edit->loantype->caption() ?><?php echo $loansimulatorcases_edit->loantype->Required ? $Language->phrase("FieldRequiredIndicator") : "" ?></label>
		<div class="<?php echo $loansimulatorcases_edit->RightColumnClass ?>"><div <?php echo $loansimulatorcases_edit->loantype->cellAttributes() ?>>
<span id="el_loansimulatorcases_loantype">
<div class="input-group">
	<select class="custom-select ew-custom-select" data-table="loansimulatorcases" data-field="x_loantype" data-value-separator="<?php echo $loansimulatorcases_edit->loantype->displayValueSeparatorAttribute() ?>" id="x_loantype" name="x_loantype"<?php echo $loansimulatorcases_edit->loantype->editAttributes() ?>>
			<?php echo $loansimulatorcases_edit->loantype->selectOptionListHtml("x_loantype") ?>
		</select>
</div>
<?php echo $loansimulatorcases_edit->loantype->Lookup->getParamTag($loansimulatorcases_edit, "p_x_loantype") ?>
</span>
<?php echo $loansimulatorcases_edit->loantype->CustomMsg ?></div></div>
	</div>
<?php } ?>
<?php if ($loansimulatorcases_edit->timeslot->Visible) { // timeslot ?>
	<div id="r_timeslot" class="form-group row">
		<label id="elh_loansimulatorcases_timeslot" for="x_timeslot" class="<?php echo $loansimulatorcases_edit->LeftColumnClass ?>"><?php echo $loansimulatorcases_edit->timeslot->caption() ?><?php echo $loansimulatorcases_edit->timeslot->Required ? $Language->phrase("FieldRequiredIndicator") : "" ?></label>
		<div class="<?php echo $loansimulatorcases_edit->RightColumnClass ?>"><div <?php echo $loansimulatorcases_edit->timeslot->cellAttributes() ?>>
<span id="el_loansimulatorcases_timeslot">
<div class="input-group">
	<select class="custom-select ew-custom-select" data-table="loansimulatorcases" data-field="x_timeslot" data-value-separator="<?php echo $loansimulatorcases_edit->timeslot->displayValueSeparatorAttribute() ?>" id="x_timeslot" name="x_timeslot"<?php echo $loansimulatorcases_edit->timeslot->editAttributes() ?>>
			<?php echo $loansimulatorcases_edit->timeslot->selectOptionListHtml("x_timeslot") ?>
		</select>
</div>
</span>
<?php echo $loansimulatorcases_edit->timeslot->CustomMsg ?></div></div>
	</div>
<?php } ?>
<?php if ($loansimulatorcases_edit->sequence->Visible) { // sequence ?>
	<div id="r_sequence" class="form-group row">
		<label id="elh_loansimulatorcases_sequence" for="x_sequence" class="<?php echo $loansimulatorcases_edit->LeftColumnClass ?>"><?php echo $loansimulatorcases_edit->sequence->caption() ?><?php echo $loansimulatorcases_edit->sequence->Required ? $Language->phrase("FieldRequiredIndicator") : "" ?></label>
		<div class="<?php echo $loansimulatorcases_edit->RightColumnClass ?>"><div <?php echo $loansimulatorcases_edit->sequence->cellAttributes() ?>>
<span id="el_loansimulatorcases_sequence">
<input type="text" data-table="loansimulatorcases" data-field="x_sequence" name="x_sequence" id="x_sequence" size="30" maxlength="5" placeholder="<?php echo HtmlEncode($loansimulatorcases_edit->sequence->getPlaceHolder()) ?>" value="<?php echo $loansimulatorcases_edit->sequence->EditValue ?>"<?php echo $loansimulatorcases_edit->sequence->editAttributes() ?>>
</span>
<?php echo $loansimulatorcases_edit->sequence->CustomMsg ?></div></div>
	</div>
<?php } ?>
<?php if ($loansimulatorcases_edit->uselastloanid->Visible) { // uselastloanid ?>
	<div id="r_uselastloanid" class="form-group row">
		<label id="elh_loansimulatorcases_uselastloanid" class="<?php echo $loansimulatorcases_edit->LeftColumnClass ?>"><?php echo $loansimulatorcases_edit->uselastloanid->caption() ?><?php echo $loansimulatorcases_edit->uselastloanid->Required ? $Language->phrase("FieldRequiredIndicator") : "" ?></label>
		<div class="<?php echo $loansimulatorcases_edit->RightColumnClass ?>"><div <?php echo $loansimulatorcases_edit->uselastloanid->cellAttributes() ?>>
<span id="el_loansimulatorcases_uselastloanid">
<div id="tp_x_uselastloanid" class="ew-template"><input type="radio" class="custom-control-input" data-table="loansimulatorcases" data-field="x_uselastloanid" data-value-separator="<?php echo $loansimulatorcases_edit->uselastloanid->displayValueSeparatorAttribute() ?>" name="x_uselastloanid" id="x_uselastloanid" value="{value}"<?php echo $loansimulatorcases_edit->uselastloanid->editAttributes() ?>></div>
<div id="dsl_x_uselastloanid" data-repeatcolumn="5" class="ew-item-list d-none"><div>
<?php echo $loansimulatorcases_edit->uselastloanid->radioButtonListHtml(FALSE, "x_uselastloanid") ?>
</div></div>
<?php echo $loansimulatorcases_edit->uselastloanid->Lookup->getParamTag($loansimulatorcases_edit, "p_x_uselastloanid") ?>
</span>
<?php echo $loansimulatorcases_edit->uselastloanid->CustomMsg ?></div></div>
	</div>
<?php } ?>
</div><!-- /page* -->
<?php if (!$loansimulatorcases_edit->IsModal) { ?>
<div class="form-group row"><!-- buttons .form-group -->
	<div class="<?php echo $loansimulatorcases_edit->OffsetColumnClass ?>"><!-- buttons offset -->
<button class="btn btn-primary ew-btn" name="btn-action" id="btn-action" type="submit"><?php echo $Language->phrase("SaveBtn") ?></button>
<button class="btn btn-default ew-btn" name="btn-cancel" id="btn-cancel" type="button" data-href="<?php echo $loansimulatorcases_edit->getReturnUrl() ?>"><?php echo $Language->phrase("CancelBtn") ?></button>
	</div><!-- /buttons offset -->
</div><!-- /buttons .form-group -->
<?php } ?>
</form>
<?php
$loansimulatorcases_edit->showPageFooter();
if (Config("DEBUG"))
	echo GetDebugMessage();
?>
<script>
loadjs.ready("load", function() {

	// Startup script
	// Write your table-specific startup script here
	// console.log("page loaded");

});
</script>
<?php include_once "footer.php"; ?>
<?php
$loansimulatorcases_edit->terminate();
?>