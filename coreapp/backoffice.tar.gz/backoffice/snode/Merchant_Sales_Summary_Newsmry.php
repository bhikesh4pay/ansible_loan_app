<?php
namespace PHPMaker2020\_4payadmin;

// Autoload
include_once "autoload.php";

// Session
if (session_status() !== PHP_SESSION_ACTIVE)
	\Delight\Cookie\Session::start(Config("COOKIE_SAMESITE")); // Init session data

// Output buffering
ob_start();
?>
<?php

// Write header
WriteHeader(FALSE);

// Create page object
$Merchant_Sales_Summary_New_summary = new Merchant_Sales_Summary_New_summary();

// Run the page
$Merchant_Sales_Summary_New_summary->run();

// Setup login status
SetupLoginStatus();
SetClientVar("login", LoginStatus());

// Global Page Rendering event (in userfn*.php)
Page_Rendering();

// Page Rendering event
$Merchant_Sales_Summary_New_summary->Page_Render();
?>
<?php if (!$DashboardReport) { ?>
<?php include_once "header.php"; ?>
<?php } ?>
<?php if (!$Merchant_Sales_Summary_New_summary->isExport() && !$Merchant_Sales_Summary_New_summary->DrillDown && !$DashboardReport) { ?>
<script>
var fsummary, currentPageID;
loadjs.ready("head", function() {

	// Form object for search
	fsummary = currentForm = new ew.Form("fsummary", "summary");
	currentPageID = ew.PAGE_ID = "summary";

	// Validate function for search
	fsummary.validate = function(fobj) {
		if (!this.validateRequired)
			return true; // Ignore validation
		fobj = fobj || this._form;
		var infix = "";
		elm = this.getElements("x" + infix + "_transtime");
		if (elm && !ew.checkDateDef(elm.value))
			return this.onError(elm, "<?php echo JsEncode($Merchant_Sales_Summary_New_summary->transtime->errorMessage()) ?>");

		// Call Form_CustomValidate event
		if (!this.Form_CustomValidate(fobj))
			return false;
		return true;
	}

	// Form_CustomValidate
	fsummary.Form_CustomValidate = function(fobj) { // DO NOT CHANGE THIS LINE!

		// Your custom validation code here, return false if invalid.
		return true;
	}

	// Use JavaScript validation or not
	fsummary.validateRequired = <?php echo Config("CLIENT_VALIDATE") ? "true" : "false" ?>;

	// Dynamic selection lists
	fsummary.lists["x_currID"] = <?php echo $Merchant_Sales_Summary_New_summary->currID->Lookup->toClientList($Merchant_Sales_Summary_New_summary) ?>;
	fsummary.lists["x_currID"].options = <?php echo JsonEncode($Merchant_Sales_Summary_New_summary->currID->lookupOptions()) ?>;

	// Filters
	fsummary.filterList = <?php echo $Merchant_Sales_Summary_New_summary->getFilterList() ?>;
	loadjs.done("fsummary");
});
</script>
<script>
loadjs.ready("head", function() {

	// Client script
	// Write your client script here, no need to add script tags.

});
</script>
<?php } ?>
<a id="top"></a>
<?php if ((!$Merchant_Sales_Summary_New_summary->isExport() || $Merchant_Sales_Summary_New_summary->isExport("print")) && !$DashboardReport) { ?>
<!-- Content Container -->
<div id="ew-report" class="ew-report container-fluid">
<?php } ?>
<?php if ($Merchant_Sales_Summary_New_summary->ShowCurrentFilter) { ?>
<?php $Merchant_Sales_Summary_New_summary->showFilterList() ?>
<?php } ?>
<div class="btn-toolbar ew-toolbar">
<?php
if (!$Merchant_Sales_Summary_New_summary->DrillDownInPanel) {
	$Merchant_Sales_Summary_New_summary->ExportOptions->render("body");
	$Merchant_Sales_Summary_New_summary->SearchOptions->render("body");
	$Merchant_Sales_Summary_New_summary->FilterOptions->render("body");
}
?>
</div>
<?php $Merchant_Sales_Summary_New_summary->showPageHeader(); ?>
<?php
$Merchant_Sales_Summary_New_summary->showMessage();
?>
<?php if ((!$Merchant_Sales_Summary_New_summary->isExport() || $Merchant_Sales_Summary_New_summary->isExport("print")) && !$DashboardReport) { ?>
<div class="row">
<?php } ?>
<?php if ((!$Merchant_Sales_Summary_New_summary->isExport() || $Merchant_Sales_Summary_New_summary->isExport("print")) && !$DashboardReport) { ?>
<!-- Center Container -->
<div id="ew-center" class="<?php echo $Merchant_Sales_Summary_New_summary->CenterContentClass ?>">
<?php } ?>
<!-- Summary report (begin) -->
<div id="report_summary">
<?php if (!$Merchant_Sales_Summary_New_summary->isExport() && !$Merchant_Sales_Summary_New_summary->DrillDown && !$DashboardReport) { ?>
<?php if ($Security->CanSearch()) { ?>
<?php if (!$Merchant_Sales_Summary_New_summary->isExport() && !$Merchant_Sales_Summary_New->CurrentAction) { ?>
<form name="fsummary" id="fsummary" class="form-inline ew-form ew-ext-search-form" action="<?php echo CurrentPageName() ?>">
<div id="fsummary-search-panel" class="<?php echo $Merchant_Sales_Summary_New_summary->SearchPanelClass ?>">
<input type="hidden" name="cmd" value="search">
<input type="hidden" name="t" value="Merchant_Sales_Summary_New">
	<div class="ew-extended-search">
<?php

// Render search row
$Merchant_Sales_Summary_New->RowType = ROWTYPE_SEARCH;
$Merchant_Sales_Summary_New->resetAttributes();
$Merchant_Sales_Summary_New_summary->renderRow();
?>
<?php if ($Merchant_Sales_Summary_New_summary->transtime->Visible) { // transtime ?>
	<?php
		$Merchant_Sales_Summary_New_summary->SearchColumnCount++;
		if (($Merchant_Sales_Summary_New_summary->SearchColumnCount - 1) % $Merchant_Sales_Summary_New_summary->SearchFieldsPerRow == 0) {
			$Merchant_Sales_Summary_New_summary->SearchRowCount++;
	?>
<div id="xsr_<?php echo $Merchant_Sales_Summary_New_summary->SearchRowCount ?>" class="ew-row d-sm-flex">
	<?php
		}
	 ?>
	<div id="xsc_transtime" class="ew-cell form-group">
		<label for="x_transtime" class="ew-search-caption ew-label"><?php echo $Merchant_Sales_Summary_New_summary->transtime->caption() ?></label>
		<span class="ew-search-operator">
<?php echo $Language->phrase("BETWEEN") ?>
<input type="hidden" name="z_transtime" id="z_transtime" value="BETWEEN">
</span>
		<span id="el_Merchant_Sales_Summary_New_transtime" class="ew-search-field">
<input type="text" data-table="Merchant_Sales_Summary_New" data-field="x_transtime" data-format="1" name="x_transtime" id="x_transtime" maxlength="19" placeholder="<?php echo HtmlEncode($Merchant_Sales_Summary_New_summary->transtime->getPlaceHolder()) ?>" value="<?php echo $Merchant_Sales_Summary_New_summary->transtime->EditValue ?>"<?php echo $Merchant_Sales_Summary_New_summary->transtime->editAttributes() ?>>
<?php if (!$Merchant_Sales_Summary_New_summary->transtime->ReadOnly && !$Merchant_Sales_Summary_New_summary->transtime->Disabled && !isset($Merchant_Sales_Summary_New_summary->transtime->EditAttrs["readonly"]) && !isset($Merchant_Sales_Summary_New_summary->transtime->EditAttrs["disabled"])) { ?>
<script>
loadjs.ready(["fsummary", "datetimepicker"], function() {
	ew.createDateTimePicker("fsummary", "x_transtime", {"ignoreReadonly":true,"useCurrent":false,"format":1});
});
</script>
<?php } ?>
</span>
		<span class="ew-search-and"><label><?php echo $Language->phrase("AND") ?></label></span>
		<span id="el2_Merchant_Sales_Summary_New_transtime" class="ew-search-field2">
<input type="text" data-table="Merchant_Sales_Summary_New" data-field="x_transtime" data-format="1" name="y_transtime" id="y_transtime" maxlength="19" placeholder="<?php echo HtmlEncode($Merchant_Sales_Summary_New_summary->transtime->getPlaceHolder()) ?>" value="<?php echo $Merchant_Sales_Summary_New_summary->transtime->EditValue2 ?>"<?php echo $Merchant_Sales_Summary_New_summary->transtime->editAttributes() ?>>
<?php if (!$Merchant_Sales_Summary_New_summary->transtime->ReadOnly && !$Merchant_Sales_Summary_New_summary->transtime->Disabled && !isset($Merchant_Sales_Summary_New_summary->transtime->EditAttrs["readonly"]) && !isset($Merchant_Sales_Summary_New_summary->transtime->EditAttrs["disabled"])) { ?>
<script>
loadjs.ready(["fsummary", "datetimepicker"], function() {
	ew.createDateTimePicker("fsummary", "y_transtime", {"ignoreReadonly":true,"useCurrent":false,"format":1});
});
</script>
<?php } ?>
</span>
	</div>
	<?php if ($Merchant_Sales_Summary_New_summary->SearchColumnCount % $Merchant_Sales_Summary_New_summary->SearchFieldsPerRow == 0) { ?>
</div>
	<?php } ?>
<?php } ?>
<?php if ($Merchant_Sales_Summary_New_summary->currID->Visible) { // currID ?>
	<?php
		$Merchant_Sales_Summary_New_summary->SearchColumnCount++;
		if (($Merchant_Sales_Summary_New_summary->SearchColumnCount - 1) % $Merchant_Sales_Summary_New_summary->SearchFieldsPerRow == 0) {
			$Merchant_Sales_Summary_New_summary->SearchRowCount++;
	?>
<div id="xsr_<?php echo $Merchant_Sales_Summary_New_summary->SearchRowCount ?>" class="ew-row d-sm-flex">
	<?php
		}
	 ?>
	<div id="xsc_currID" class="ew-cell form-group">
		<label for="x_currID" class="ew-search-caption ew-label"><?php echo $Merchant_Sales_Summary_New_summary->currID->caption() ?></label>
		<span id="el_Merchant_Sales_Summary_New_currID" class="ew-search-field">
<div class="input-group">
	<select class="custom-select ew-custom-select" data-table="Merchant_Sales_Summary_New" data-field="x_currID" data-value-separator="<?php echo $Merchant_Sales_Summary_New_summary->currID->displayValueSeparatorAttribute() ?>" id="x_currID" name="x_currID"<?php echo $Merchant_Sales_Summary_New_summary->currID->editAttributes() ?>>
			<?php echo $Merchant_Sales_Summary_New_summary->currID->selectOptionListHtml("x_currID") ?>
		</select>
</div>
<?php echo $Merchant_Sales_Summary_New_summary->currID->Lookup->getParamTag($Merchant_Sales_Summary_New_summary, "p_x_currID") ?>
</span>
	</div>
	<?php if ($Merchant_Sales_Summary_New_summary->SearchColumnCount % $Merchant_Sales_Summary_New_summary->SearchFieldsPerRow == 0) { ?>
</div>
	<?php } ?>
<?php } ?>
	<?php if ($Merchant_Sales_Summary_New_summary->SearchColumnCount % $Merchant_Sales_Summary_New_summary->SearchFieldsPerRow > 0) { ?>
</div>
	<?php } ?>
<div id="xsr_<?php echo $Merchant_Sales_Summary_New_summary->SearchRowCount + 1 ?>" class="ew-row d-sm-flex">
	<button class="btn btn-primary" name="btn-submit" id="btn-submit" type="submit"><?php echo $Language->phrase("SearchBtn") ?></button>
</div>
	</div><!-- /.ew-extended-search -->
</div><!-- /.ew-search-panel -->
</form>
<?php } ?>
<?php } ?>
<?php } ?>
<?php
while ($Merchant_Sales_Summary_New_summary->GroupCount <= count($Merchant_Sales_Summary_New_summary->GroupRecords) && $Merchant_Sales_Summary_New_summary->GroupCount <= $Merchant_Sales_Summary_New_summary->DisplayGroups) {
?>
<?php

	// Show header
	if ($Merchant_Sales_Summary_New_summary->ShowHeader) {
?>
<?php if ($Merchant_Sales_Summary_New_summary->GroupCount > 1) { ?>
</tbody>
</table>
</div>
<!-- /.ew-grid-middle-panel -->
<!-- Report grid (end) -->
<?php if (!$Merchant_Sales_Summary_New_summary->isExport() && !($Merchant_Sales_Summary_New_summary->DrillDown && $Merchant_Sales_Summary_New_summary->TotalGroups > 0)) { ?>
<!-- Bottom pager -->
<div class="card-footer ew-grid-lower-panel">
<form name="ew-pager-form" class="form-inline ew-form ew-pager-form" action="<?php echo CurrentPageName() ?>">
<?php echo $Merchant_Sales_Summary_New_summary->Pager->render() ?>
</form>
<div class="clearfix"></div>
</div>
<?php } ?>
</div>
<!-- /.ew-grid -->
<?php echo $Merchant_Sales_Summary_New_summary->PageBreakContent ?>
<?php } ?>
<div class="<?php if (!$Merchant_Sales_Summary_New_summary->isExport("word") && !$Merchant_Sales_Summary_New_summary->isExport("excel")) { ?>card ew-card <?php } ?>ew-grid"<?php echo $Merchant_Sales_Summary_New_summary->ReportTableStyle ?>>
<!-- Report grid (begin) -->
<div id="gmp_Merchant_Sales_Summary_New" class="<?php echo ResponsiveTableClass() ?>card-body ew-grid-middle-panel">
<table class="<?php echo $Merchant_Sales_Summary_New_summary->ReportTableClass ?>">
<thead>
	<!-- Table header -->
	<tr class="ew-table-header">
<?php if ($Merchant_Sales_Summary_New_summary->businessname->Visible) { ?>
	<?php if ($Merchant_Sales_Summary_New_summary->businessname->ShowGroupHeaderAsRow) { ?>
	<th data-name="businessname">&nbsp;</th>
	<?php } else { ?>
		<?php if ($Merchant_Sales_Summary_New_summary->sortUrl($Merchant_Sales_Summary_New_summary->businessname) == "") { ?>
	<th data-name="businessname" class="<?php echo $Merchant_Sales_Summary_New_summary->businessname->headerCellClass() ?>"><div class="Merchant_Sales_Summary_New_businessname"><div class="ew-table-header-caption"><?php echo $Merchant_Sales_Summary_New_summary->businessname->caption() ?></div></div></th>
		<?php } else { ?>
	<th data-name="businessname" class="<?php echo $Merchant_Sales_Summary_New_summary->businessname->headerCellClass() ?>"><div class="ew-pointer" onclick="ew.sort(event, '<?php echo $Merchant_Sales_Summary_New_summary->sortUrl($Merchant_Sales_Summary_New_summary->businessname) ?>', 1);"><div class="Merchant_Sales_Summary_New_businessname">
		<div class="ew-table-header-btn"><span class="ew-table-header-caption"><?php echo $Merchant_Sales_Summary_New_summary->businessname->caption() ?></span><span class="ew-table-header-sort"><?php if ($Merchant_Sales_Summary_New_summary->businessname->getSort() == "ASC") { ?><i class="fas fa-sort-up"></i><?php } elseif ($Merchant_Sales_Summary_New_summary->businessname->getSort() == "DESC") { ?><i class="fas fa-sort-down"></i><?php } ?></span></div>
	</div></div></th>
		<?php } ?>
	<?php } ?>
<?php } ?>
<?php if ($Merchant_Sales_Summary_New_summary->transtype->Visible) { ?>
	<?php if ($Merchant_Sales_Summary_New_summary->transtype->ShowGroupHeaderAsRow) { ?>
	<th data-name="transtype">&nbsp;</th>
	<?php } else { ?>
		<?php if ($Merchant_Sales_Summary_New_summary->sortUrl($Merchant_Sales_Summary_New_summary->transtype) == "") { ?>
	<th data-name="transtype" class="<?php echo $Merchant_Sales_Summary_New_summary->transtype->headerCellClass() ?>"><div class="Merchant_Sales_Summary_New_transtype"><div class="ew-table-header-caption"><?php echo $Merchant_Sales_Summary_New_summary->transtype->caption() ?></div></div></th>
		<?php } else { ?>
	<th data-name="transtype" class="<?php echo $Merchant_Sales_Summary_New_summary->transtype->headerCellClass() ?>"><div class="ew-pointer" onclick="ew.sort(event, '<?php echo $Merchant_Sales_Summary_New_summary->sortUrl($Merchant_Sales_Summary_New_summary->transtype) ?>', 1);"><div class="Merchant_Sales_Summary_New_transtype">
		<div class="ew-table-header-btn"><span class="ew-table-header-caption"><?php echo $Merchant_Sales_Summary_New_summary->transtype->caption() ?></span><span class="ew-table-header-sort"><?php if ($Merchant_Sales_Summary_New_summary->transtype->getSort() == "ASC") { ?><i class="fas fa-sort-up"></i><?php } elseif ($Merchant_Sales_Summary_New_summary->transtype->getSort() == "DESC") { ?><i class="fas fa-sort-down"></i><?php } ?></span></div>
	</div></div></th>
		<?php } ?>
	<?php } ?>
<?php } ?>
<?php if ($Merchant_Sales_Summary_New_summary->purchaseamount->Visible) { ?>
	<th data-name="purchaseamount" class="<?php echo $Merchant_Sales_Summary_New_summary->purchaseamount->headerCellClass() ?>"><div class="ew-table-header-btn"><div class="ew-table-header-caption"><?php echo $Merchant_Sales_Summary_New_summary->purchaseamount->caption() ?> (<?php echo $Language->phrase("RptSum") ?>)</div></div></th>
<?php } ?>
<?php if ($Merchant_Sales_Summary_New_summary->discountamount->Visible) { ?>
	<th data-name="discountamount" class="<?php echo $Merchant_Sales_Summary_New_summary->discountamount->headerCellClass() ?>"><div class="ew-table-header-btn"><div class="ew-table-header-caption"><?php echo $Merchant_Sales_Summary_New_summary->discountamount->caption() ?> (<?php echo $Language->phrase("RptSum") ?>)</div></div></th>
<?php } ?>
<?php if ($Merchant_Sales_Summary_New_summary->MerchantSurcharge->Visible) { ?>
	<th data-name="MerchantSurcharge" class="<?php echo $Merchant_Sales_Summary_New_summary->MerchantSurcharge->headerCellClass() ?>"><div class="ew-table-header-btn"><div class="ew-table-header-caption"><?php echo $Merchant_Sales_Summary_New_summary->MerchantSurcharge->caption() ?> (<?php echo $Language->phrase("RptSum") ?>)</div></div></th>
<?php } ?>
<?php if ($Merchant_Sales_Summary_New_summary->TipAmount->Visible) { ?>
	<th data-name="TipAmount" class="<?php echo $Merchant_Sales_Summary_New_summary->TipAmount->headerCellClass() ?>"><div class="ew-table-header-btn"><div class="ew-table-header-caption"><?php echo $Merchant_Sales_Summary_New_summary->TipAmount->caption() ?> (<?php echo $Language->phrase("RptSum") ?>)</div></div></th>
<?php } ?>
<?php if ($Merchant_Sales_Summary_New_summary->TaxAmount->Visible) { ?>
	<th data-name="TaxAmount" class="<?php echo $Merchant_Sales_Summary_New_summary->TaxAmount->headerCellClass() ?>"><div class="ew-table-header-btn"><div class="ew-table-header-caption"><?php echo $Merchant_Sales_Summary_New_summary->TaxAmount->caption() ?> (<?php echo $Language->phrase("RptSum") ?>)</div></div></th>
<?php } ?>
<?php if ($Merchant_Sales_Summary_New_summary->ServiceFeeToCustomer->Visible) { ?>
	<th data-name="ServiceFeeToCustomer" class="<?php echo $Merchant_Sales_Summary_New_summary->ServiceFeeToCustomer->headerCellClass() ?>"><div class="ew-table-header-btn"><div class="ew-table-header-caption"><?php echo $Merchant_Sales_Summary_New_summary->ServiceFeeToCustomer->caption() ?> (<?php echo $Language->phrase("RptSum") ?>)</div></div></th>
<?php } ?>
<?php if ($Merchant_Sales_Summary_New_summary->TotalAmountForCustomer->Visible) { ?>
	<th data-name="TotalAmountForCustomer" class="<?php echo $Merchant_Sales_Summary_New_summary->TotalAmountForCustomer->headerCellClass() ?>"><div class="ew-table-header-btn"><div class="ew-table-header-caption"><?php echo $Merchant_Sales_Summary_New_summary->TotalAmountForCustomer->caption() ?> (<?php echo $Language->phrase("RptSum") ?>)</div></div></th>
<?php } ?>
<?php if ($Merchant_Sales_Summary_New_summary->ServiceFeeToMerchant->Visible) { ?>
	<th data-name="ServiceFeeToMerchant" class="<?php echo $Merchant_Sales_Summary_New_summary->ServiceFeeToMerchant->headerCellClass() ?>"><div class="ew-table-header-btn"><div class="ew-table-header-caption"><?php echo $Merchant_Sales_Summary_New_summary->ServiceFeeToMerchant->caption() ?> (<?php echo $Language->phrase("RptSum") ?>)</div></div></th>
<?php } ?>
<?php if ($Merchant_Sales_Summary_New_summary->TotalAmountForMerchant->Visible) { ?>
	<th data-name="TotalAmountForMerchant" class="<?php echo $Merchant_Sales_Summary_New_summary->TotalAmountForMerchant->headerCellClass() ?>"><div class="ew-table-header-btn"><div class="ew-table-header-caption"><?php echo $Merchant_Sales_Summary_New_summary->TotalAmountForMerchant->caption() ?> (<?php echo $Language->phrase("RptSum") ?>)</div></div></th>
<?php } ?>
	</tr>
</thead>
<tbody>
<?php
		if ($Merchant_Sales_Summary_New_summary->TotalGroups == 0)
			break; // Show header only
		$Merchant_Sales_Summary_New_summary->ShowHeader = FALSE;
	} // End show header
?>
<?php

	// Build detail SQL
	$where = DetailFilterSql($Merchant_Sales_Summary_New_summary->businessname, $Merchant_Sales_Summary_New_summary->getSqlFirstGroupField(), $Merchant_Sales_Summary_New_summary->businessname->groupValue(), $Merchant_Sales_Summary_New_summary->Dbid);
	if ($Merchant_Sales_Summary_New_summary->PageFirstGroupFilter != "") $Merchant_Sales_Summary_New_summary->PageFirstGroupFilter .= " OR ";
	$Merchant_Sales_Summary_New_summary->PageFirstGroupFilter .= $where;
	if ($Merchant_Sales_Summary_New_summary->Filter != "")
		$where = "($Merchant_Sales_Summary_New_summary->Filter) AND ($where)";
	$sql = BuildReportSql($Merchant_Sales_Summary_New_summary->getSqlSelect(), $Merchant_Sales_Summary_New_summary->getSqlWhere(), $Merchant_Sales_Summary_New_summary->getSqlGroupBy(), $Merchant_Sales_Summary_New_summary->getSqlHaving(), $Merchant_Sales_Summary_New_summary->getSqlOrderBy(), $where, $Merchant_Sales_Summary_New_summary->Sort);
	$rs = $Merchant_Sales_Summary_New_summary->getRecordset($sql);
	$Merchant_Sales_Summary_New_summary->DetailRecords = $rs ? $rs->getRows() : [];
	$Merchant_Sales_Summary_New_summary->DetailRecordCount = count($Merchant_Sales_Summary_New_summary->DetailRecords);

	// Load detail records
	$Merchant_Sales_Summary_New_summary->businessname->Records = &$Merchant_Sales_Summary_New_summary->DetailRecords;
	$Merchant_Sales_Summary_New_summary->businessname->LevelBreak = TRUE; // Set field level break
		$Merchant_Sales_Summary_New_summary->GroupCounter[1] = $Merchant_Sales_Summary_New_summary->GroupCount;
		$Merchant_Sales_Summary_New_summary->businessname->getCnt($Merchant_Sales_Summary_New_summary->businessname->Records); // Get record count
?>
<?php if ($Merchant_Sales_Summary_New_summary->businessname->Visible && $Merchant_Sales_Summary_New_summary->businessname->ShowGroupHeaderAsRow) { ?>
<?php

		// Render header row
		$Merchant_Sales_Summary_New_summary->resetAttributes();
		$Merchant_Sales_Summary_New_summary->RowType = ROWTYPE_TOTAL;
		$Merchant_Sales_Summary_New_summary->RowTotalType = ROWTOTAL_GROUP;
		$Merchant_Sales_Summary_New_summary->RowTotalSubType = ROWTOTAL_HEADER;
		$Merchant_Sales_Summary_New_summary->RowGroupLevel = 1;
		$Merchant_Sales_Summary_New_summary->renderRow();
?>
	<tr<?php echo $Merchant_Sales_Summary_New_summary->rowAttributes(); ?>>
<?php if ($Merchant_Sales_Summary_New_summary->businessname->Visible) { ?>
		<td data-field="businessname"<?php echo $Merchant_Sales_Summary_New_summary->businessname->cellAttributes(); ?>><span class="ew-group-toggle icon-collapse"></span></td>
<?php } ?>
		<td data-field="businessname" colspan="<?php echo ($Page->GroupColumnCount + $Page->DetailColumnCount - 1) ?>"<?php echo $Merchant_Sales_Summary_New_summary->businessname->cellAttributes() ?>>
<?php if ($Merchant_Sales_Summary_New_summary->sortUrl($Merchant_Sales_Summary_New_summary->businessname) == "") { ?>
		<span class="ew-summary-caption Merchant_Sales_Summary_New_businessname"><span class="ew-table-header-caption"><?php echo $Merchant_Sales_Summary_New_summary->businessname->caption() ?></span></span>
<?php } else { ?>
		<span class="ew-table-header-btn ew-pointer ew-summary-caption Merchant_Sales_Summary_New_businessname" onclick="ew.sort(event, '<?php echo $Merchant_Sales_Summary_New_summary->sortUrl($Merchant_Sales_Summary_New_summary->businessname) ?>', 1);">
			<span class="ew-table-header-caption"><?php echo $Merchant_Sales_Summary_New_summary->businessname->caption() ?></span>
			<span class="ew-table-header-sort"><?php if ($Merchant_Sales_Summary_New_summary->businessname->getSort() == "ASC") { ?><i class="fas fa-sort-up"></i><?php } elseif ($Merchant_Sales_Summary_New_summary->businessname->getSort() == "DESC") { ?><i class="fas fa-sort-down"></i><?php } ?></span>
		</span>
<?php } ?>
		<?php echo $Language->phrase("SummaryColon") ?><span<?php echo $Merchant_Sales_Summary_New_summary->businessname->viewAttributes() ?>><?php echo $Merchant_Sales_Summary_New_summary->businessname->GroupViewValue ?></span>
		<span class="ew-summary-count">(<span class="ew-aggregate-caption"><?php echo $Language->phrase("RptCnt") ?></span><?php echo $Language->phrase("AggregateEqual") ?><span class="ew-aggregate-value"><?php echo FormatNumber($Merchant_Sales_Summary_New_summary->businessname->Count, 0); ?></span>)</span>
		</td>
	</tr>
<?php } ?>
<?php
	$Merchant_Sales_Summary_New_summary->transtype->getDistinctValues($Merchant_Sales_Summary_New_summary->businessname->Records);
	$Merchant_Sales_Summary_New_summary->setGroupCount(count($Merchant_Sales_Summary_New_summary->transtype->DistinctValues), $Merchant_Sales_Summary_New_summary->GroupCounter[1]);
	$Merchant_Sales_Summary_New_summary->GroupCounter[2] = 0; // Init group count index
	foreach ($Merchant_Sales_Summary_New_summary->transtype->DistinctValues as $transtype) { // Load records for this distinct value
		$Merchant_Sales_Summary_New_summary->transtype->setGroupValue($transtype); // Set group value
		$Merchant_Sales_Summary_New_summary->transtype->getDistinctRecords($Merchant_Sales_Summary_New_summary->businessname->Records, $Merchant_Sales_Summary_New_summary->transtype->groupValue());
		$Merchant_Sales_Summary_New_summary->transtype->LevelBreak = TRUE; // Set field level break
		$Merchant_Sales_Summary_New_summary->GroupCounter[2]++;
		$Merchant_Sales_Summary_New_summary->transtype->getCnt($Merchant_Sales_Summary_New_summary->transtype->Records); // Get record count
		$Merchant_Sales_Summary_New_summary->setGroupCount($Merchant_Sales_Summary_New_summary->transtype->Count, $Merchant_Sales_Summary_New_summary->GroupCounter[1], $Merchant_Sales_Summary_New_summary->GroupCounter[2]);
?>
<?php if ($Merchant_Sales_Summary_New_summary->transtype->Visible && $Merchant_Sales_Summary_New_summary->transtype->ShowGroupHeaderAsRow) { ?>
<?php

		// Render header row
		$Merchant_Sales_Summary_New_summary->transtype->setDbValue($transtype); // Set current value for transtype
		$Merchant_Sales_Summary_New_summary->resetAttributes();
		$Merchant_Sales_Summary_New_summary->RowType = ROWTYPE_TOTAL;
		$Merchant_Sales_Summary_New_summary->RowTotalType = ROWTOTAL_GROUP;
		$Merchant_Sales_Summary_New_summary->RowTotalSubType = ROWTOTAL_HEADER;
		$Merchant_Sales_Summary_New_summary->RowGroupLevel = 2;
		$Merchant_Sales_Summary_New_summary->renderRow();
?>
	<tr<?php echo $Merchant_Sales_Summary_New_summary->rowAttributes(); ?>>
<?php if ($Merchant_Sales_Summary_New_summary->businessname->Visible) { ?>
		<td data-field="businessname"<?php echo $Merchant_Sales_Summary_New_summary->businessname->cellAttributes(); ?>></td>
<?php } ?>
<?php if ($Merchant_Sales_Summary_New_summary->transtype->Visible) { ?>
		<td data-field="transtype"<?php echo $Merchant_Sales_Summary_New_summary->transtype->cellAttributes(); ?>><span class="ew-group-toggle icon-collapse"></span></td>
<?php } ?>
		<td data-field="transtype" colspan="<?php echo ($Page->GroupColumnCount + $Page->DetailColumnCount - 2) ?>"<?php echo $Merchant_Sales_Summary_New_summary->transtype->cellAttributes() ?>>
<?php if ($Merchant_Sales_Summary_New_summary->sortUrl($Merchant_Sales_Summary_New_summary->transtype) == "") { ?>
		<span class="ew-summary-caption Merchant_Sales_Summary_New_transtype"><span class="ew-table-header-caption"><?php echo $Merchant_Sales_Summary_New_summary->transtype->caption() ?></span></span>
<?php } else { ?>
		<span class="ew-table-header-btn ew-pointer ew-summary-caption Merchant_Sales_Summary_New_transtype" onclick="ew.sort(event, '<?php echo $Merchant_Sales_Summary_New_summary->sortUrl($Merchant_Sales_Summary_New_summary->transtype) ?>', 1);">
			<span class="ew-table-header-caption"><?php echo $Merchant_Sales_Summary_New_summary->transtype->caption() ?></span>
			<span class="ew-table-header-sort"><?php if ($Merchant_Sales_Summary_New_summary->transtype->getSort() == "ASC") { ?><i class="fas fa-sort-up"></i><?php } elseif ($Merchant_Sales_Summary_New_summary->transtype->getSort() == "DESC") { ?><i class="fas fa-sort-down"></i><?php } ?></span>
		</span>
<?php } ?>
		<?php echo $Language->phrase("SummaryColon") ?><span<?php echo $Merchant_Sales_Summary_New_summary->transtype->viewAttributes() ?>><?php echo $Merchant_Sales_Summary_New_summary->transtype->GroupViewValue ?></span>
		<span class="ew-summary-count">(<span class="ew-aggregate-caption"><?php echo $Language->phrase("RptCnt") ?></span><?php echo $Language->phrase("AggregateEqual") ?><span class="ew-aggregate-value"><?php echo FormatNumber($Merchant_Sales_Summary_New_summary->transtype->Count, 0); ?></span>)</span>
		</td>
	</tr>
<?php } ?>
<?php
	$Merchant_Sales_Summary_New_summary->RecordCount = 0; // Reset record count
	foreach ($Merchant_Sales_Summary_New_summary->transtype->Records as $record) {
		$Merchant_Sales_Summary_New_summary->RecordCount++;
		$Merchant_Sales_Summary_New_summary->RecordIndex++;
		$Merchant_Sales_Summary_New_summary->loadRowValues($record);
?>
<?php
	}
?>
<?php if ($Merchant_Sales_Summary_New_summary->TotalGroups > 0) { ?>
<?php
	$Merchant_Sales_Summary_New_summary->purchaseamount->getSum($Merchant_Sales_Summary_New_summary->transtype->Records); // Get Sum
	$Merchant_Sales_Summary_New_summary->discountamount->getSum($Merchant_Sales_Summary_New_summary->transtype->Records); // Get Sum
	$Merchant_Sales_Summary_New_summary->MerchantSurcharge->getSum($Merchant_Sales_Summary_New_summary->transtype->Records); // Get Sum
	$Merchant_Sales_Summary_New_summary->TipAmount->getSum($Merchant_Sales_Summary_New_summary->transtype->Records); // Get Sum
	$Merchant_Sales_Summary_New_summary->TaxAmount->getSum($Merchant_Sales_Summary_New_summary->transtype->Records); // Get Sum
	$Merchant_Sales_Summary_New_summary->ServiceFeeToCustomer->getSum($Merchant_Sales_Summary_New_summary->transtype->Records); // Get Sum
	$Merchant_Sales_Summary_New_summary->TotalAmountForCustomer->getSum($Merchant_Sales_Summary_New_summary->transtype->Records); // Get Sum
	$Merchant_Sales_Summary_New_summary->ServiceFeeToMerchant->getSum($Merchant_Sales_Summary_New_summary->transtype->Records); // Get Sum
	$Merchant_Sales_Summary_New_summary->TotalAmountForMerchant->getSum($Merchant_Sales_Summary_New_summary->transtype->Records); // Get Sum
	$Merchant_Sales_Summary_New_summary->resetAttributes();
	$Merchant_Sales_Summary_New_summary->RowType = ROWTYPE_TOTAL;
	$Merchant_Sales_Summary_New_summary->RowTotalType = ROWTOTAL_GROUP;
	$Merchant_Sales_Summary_New_summary->RowTotalSubType = ROWTOTAL_FOOTER;
	$Merchant_Sales_Summary_New_summary->RowGroupLevel = 2;
	$Merchant_Sales_Summary_New_summary->renderRow();
?>
	<tr<?php echo $Merchant_Sales_Summary_New_summary->rowAttributes(); ?>>
<?php if ($Merchant_Sales_Summary_New_summary->businessname->Visible) { ?>
		<td data-field="businessname"<?php echo $Merchant_Sales_Summary_New_summary->businessname->cellAttributes() ?>>
<span<?php echo $Merchant_Sales_Summary_New_summary->businessname->viewAttributes() ?>><?php echo $Merchant_Sales_Summary_New_summary->businessname->GroupViewValue ?></span></td>
<?php } ?>
<?php if ($Merchant_Sales_Summary_New_summary->transtype->Visible) { ?>
		<td data-field="transtype"<?php echo $Merchant_Sales_Summary_New_summary->transtype->cellAttributes() ?>><span<?php echo $Merchant_Sales_Summary_New_summary->transtype->viewAttributes() ?>><?php echo $Merchant_Sales_Summary_New_summary->transtype->GroupViewValue ?></span>&nbsp;<span class="ew-detail-count">(<?php echo FormatNumber($Merchant_Sales_Summary_New_summary->transtype->Count, 0); ?><?php echo $Language->phrase("RptDtlRec") ?>)</span></td>
<?php } ?>
<?php if ($Merchant_Sales_Summary_New_summary->purchaseamount->Visible) { ?>
		<td data-field="purchaseamount"<?php echo $Merchant_Sales_Summary_New_summary->purchaseamount->cellAttributes() ?>>
<span<?php echo $Merchant_Sales_Summary_New_summary->purchaseamount->viewAttributes() ?>><?php echo $Merchant_Sales_Summary_New_summary->purchaseamount->SumViewValue ?></span>
</td>
<?php } ?>
<?php if ($Merchant_Sales_Summary_New_summary->discountamount->Visible) { ?>
		<td data-field="discountamount"<?php echo $Merchant_Sales_Summary_New_summary->discountamount->cellAttributes() ?>>
<span<?php echo $Merchant_Sales_Summary_New_summary->discountamount->viewAttributes() ?>><?php echo $Merchant_Sales_Summary_New_summary->discountamount->SumViewValue ?></span>
</td>
<?php } ?>
<?php if ($Merchant_Sales_Summary_New_summary->MerchantSurcharge->Visible) { ?>
		<td data-field="MerchantSurcharge"<?php echo $Merchant_Sales_Summary_New_summary->MerchantSurcharge->cellAttributes() ?>>
<span<?php echo $Merchant_Sales_Summary_New_summary->MerchantSurcharge->viewAttributes() ?>><?php echo $Merchant_Sales_Summary_New_summary->MerchantSurcharge->SumViewValue ?></span>
</td>
<?php } ?>
<?php if ($Merchant_Sales_Summary_New_summary->TipAmount->Visible) { ?>
		<td data-field="TipAmount"<?php echo $Merchant_Sales_Summary_New_summary->TipAmount->cellAttributes() ?>>
<span<?php echo $Merchant_Sales_Summary_New_summary->TipAmount->viewAttributes() ?>><?php echo $Merchant_Sales_Summary_New_summary->TipAmount->SumViewValue ?></span>
</td>
<?php } ?>
<?php if ($Merchant_Sales_Summary_New_summary->TaxAmount->Visible) { ?>
		<td data-field="TaxAmount"<?php echo $Merchant_Sales_Summary_New_summary->TaxAmount->cellAttributes() ?>>
<span<?php echo $Merchant_Sales_Summary_New_summary->TaxAmount->viewAttributes() ?>><?php echo $Merchant_Sales_Summary_New_summary->TaxAmount->SumViewValue ?></span>
</td>
<?php } ?>
<?php if ($Merchant_Sales_Summary_New_summary->ServiceFeeToCustomer->Visible) { ?>
		<td data-field="ServiceFeeToCustomer"<?php echo $Merchant_Sales_Summary_New_summary->ServiceFeeToCustomer->cellAttributes() ?>>
<span<?php echo $Merchant_Sales_Summary_New_summary->ServiceFeeToCustomer->viewAttributes() ?>><?php echo $Merchant_Sales_Summary_New_summary->ServiceFeeToCustomer->SumViewValue ?></span>
</td>
<?php } ?>
<?php if ($Merchant_Sales_Summary_New_summary->TotalAmountForCustomer->Visible) { ?>
		<td data-field="TotalAmountForCustomer"<?php echo $Merchant_Sales_Summary_New_summary->TotalAmountForCustomer->cellAttributes() ?>>
<span<?php echo $Merchant_Sales_Summary_New_summary->TotalAmountForCustomer->viewAttributes() ?>><?php echo $Merchant_Sales_Summary_New_summary->TotalAmountForCustomer->SumViewValue ?></span>
</td>
<?php } ?>
<?php if ($Merchant_Sales_Summary_New_summary->ServiceFeeToMerchant->Visible) { ?>
		<td data-field="ServiceFeeToMerchant"<?php echo $Merchant_Sales_Summary_New_summary->ServiceFeeToMerchant->cellAttributes() ?>>
<span<?php echo $Merchant_Sales_Summary_New_summary->ServiceFeeToMerchant->viewAttributes() ?>><?php echo $Merchant_Sales_Summary_New_summary->ServiceFeeToMerchant->SumViewValue ?></span>
</td>
<?php } ?>
<?php if ($Merchant_Sales_Summary_New_summary->TotalAmountForMerchant->Visible) { ?>
		<td data-field="TotalAmountForMerchant"<?php echo $Merchant_Sales_Summary_New_summary->TotalAmountForMerchant->cellAttributes() ?>>
<span<?php echo $Merchant_Sales_Summary_New_summary->TotalAmountForMerchant->viewAttributes() ?>><?php echo $Merchant_Sales_Summary_New_summary->TotalAmountForMerchant->SumViewValue ?></span>
</td>
<?php } ?>
	</tr>
<?php } ?>
<?php
	} // End group level 1
?>
<?php if ($Merchant_Sales_Summary_New_summary->TotalGroups > 0) { ?>
<?php
	$Merchant_Sales_Summary_New_summary->purchaseamount->getSum($Merchant_Sales_Summary_New_summary->businessname->Records); // Get Sum
	$Merchant_Sales_Summary_New_summary->discountamount->getSum($Merchant_Sales_Summary_New_summary->businessname->Records); // Get Sum
	$Merchant_Sales_Summary_New_summary->MerchantSurcharge->getSum($Merchant_Sales_Summary_New_summary->businessname->Records); // Get Sum
	$Merchant_Sales_Summary_New_summary->TipAmount->getSum($Merchant_Sales_Summary_New_summary->businessname->Records); // Get Sum
	$Merchant_Sales_Summary_New_summary->TaxAmount->getSum($Merchant_Sales_Summary_New_summary->businessname->Records); // Get Sum
	$Merchant_Sales_Summary_New_summary->ServiceFeeToCustomer->getSum($Merchant_Sales_Summary_New_summary->businessname->Records); // Get Sum
	$Merchant_Sales_Summary_New_summary->TotalAmountForCustomer->getSum($Merchant_Sales_Summary_New_summary->businessname->Records); // Get Sum
	$Merchant_Sales_Summary_New_summary->ServiceFeeToMerchant->getSum($Merchant_Sales_Summary_New_summary->businessname->Records); // Get Sum
	$Merchant_Sales_Summary_New_summary->TotalAmountForMerchant->getSum($Merchant_Sales_Summary_New_summary->businessname->Records); // Get Sum
	$Merchant_Sales_Summary_New_summary->resetAttributes();
	$Merchant_Sales_Summary_New_summary->RowType = ROWTYPE_TOTAL;
	$Merchant_Sales_Summary_New_summary->RowTotalType = ROWTOTAL_GROUP;
	$Merchant_Sales_Summary_New_summary->RowTotalSubType = ROWTOTAL_FOOTER;
	$Merchant_Sales_Summary_New_summary->RowGroupLevel = 1;
	$Merchant_Sales_Summary_New_summary->renderRow();
?>
	<tr<?php echo $Merchant_Sales_Summary_New_summary->rowAttributes(); ?>>
<?php if ($Merchant_Sales_Summary_New_summary->businessname->Visible) { ?>
		<td data-field="businessname"<?php echo $Merchant_Sales_Summary_New_summary->businessname->cellAttributes() ?>><span class="ew-summary-text"><?php echo $Language->phrase("Summary") ?></span>&nbsp;<span class="ew-summary-value"><span<?php echo $Merchant_Sales_Summary_New_summary->businessname->viewAttributes() ?>><?php echo $Merchant_Sales_Summary_New_summary->businessname->GroupViewValue ?></span></span>&nbsp;<span class="ew-detail-count">(<?php echo FormatNumber($Merchant_Sales_Summary_New_summary->businessname->Count, 0); ?><?php echo $Language->phrase("RptDtlRec") ?>)</span></td>
<?php } ?>
<?php if ($Merchant_Sales_Summary_New_summary->transtype->Visible) { ?>
		<td data-field="transtype"<?php echo $Merchant_Sales_Summary_New_summary->businessname->cellAttributes() ?>>&nbsp;</td>
<?php } ?>
<?php if ($Merchant_Sales_Summary_New_summary->purchaseamount->Visible) { ?>
		<td data-field="purchaseamount"<?php echo $Merchant_Sales_Summary_New_summary->purchaseamount->cellAttributes() ?>>
<span<?php echo $Merchant_Sales_Summary_New_summary->purchaseamount->viewAttributes() ?>><?php echo $Merchant_Sales_Summary_New_summary->purchaseamount->SumViewValue ?></span>
</td>
<?php } ?>
<?php if ($Merchant_Sales_Summary_New_summary->discountamount->Visible) { ?>
		<td data-field="discountamount"<?php echo $Merchant_Sales_Summary_New_summary->discountamount->cellAttributes() ?>>
<span<?php echo $Merchant_Sales_Summary_New_summary->discountamount->viewAttributes() ?>><?php echo $Merchant_Sales_Summary_New_summary->discountamount->SumViewValue ?></span>
</td>
<?php } ?>
<?php if ($Merchant_Sales_Summary_New_summary->MerchantSurcharge->Visible) { ?>
		<td data-field="MerchantSurcharge"<?php echo $Merchant_Sales_Summary_New_summary->MerchantSurcharge->cellAttributes() ?>>
<span<?php echo $Merchant_Sales_Summary_New_summary->MerchantSurcharge->viewAttributes() ?>><?php echo $Merchant_Sales_Summary_New_summary->MerchantSurcharge->SumViewValue ?></span>
</td>
<?php } ?>
<?php if ($Merchant_Sales_Summary_New_summary->TipAmount->Visible) { ?>
		<td data-field="TipAmount"<?php echo $Merchant_Sales_Summary_New_summary->TipAmount->cellAttributes() ?>>
<span<?php echo $Merchant_Sales_Summary_New_summary->TipAmount->viewAttributes() ?>><?php echo $Merchant_Sales_Summary_New_summary->TipAmount->SumViewValue ?></span>
</td>
<?php } ?>
<?php if ($Merchant_Sales_Summary_New_summary->TaxAmount->Visible) { ?>
		<td data-field="TaxAmount"<?php echo $Merchant_Sales_Summary_New_summary->TaxAmount->cellAttributes() ?>>
<span<?php echo $Merchant_Sales_Summary_New_summary->TaxAmount->viewAttributes() ?>><?php echo $Merchant_Sales_Summary_New_summary->TaxAmount->SumViewValue ?></span>
</td>
<?php } ?>
<?php if ($Merchant_Sales_Summary_New_summary->ServiceFeeToCustomer->Visible) { ?>
		<td data-field="ServiceFeeToCustomer"<?php echo $Merchant_Sales_Summary_New_summary->ServiceFeeToCustomer->cellAttributes() ?>>
<span<?php echo $Merchant_Sales_Summary_New_summary->ServiceFeeToCustomer->viewAttributes() ?>><?php echo $Merchant_Sales_Summary_New_summary->ServiceFeeToCustomer->SumViewValue ?></span>
</td>
<?php } ?>
<?php if ($Merchant_Sales_Summary_New_summary->TotalAmountForCustomer->Visible) { ?>
		<td data-field="TotalAmountForCustomer"<?php echo $Merchant_Sales_Summary_New_summary->TotalAmountForCustomer->cellAttributes() ?>>
<span<?php echo $Merchant_Sales_Summary_New_summary->TotalAmountForCustomer->viewAttributes() ?>><?php echo $Merchant_Sales_Summary_New_summary->TotalAmountForCustomer->SumViewValue ?></span>
</td>
<?php } ?>
<?php if ($Merchant_Sales_Summary_New_summary->ServiceFeeToMerchant->Visible) { ?>
		<td data-field="ServiceFeeToMerchant"<?php echo $Merchant_Sales_Summary_New_summary->ServiceFeeToMerchant->cellAttributes() ?>>
<span<?php echo $Merchant_Sales_Summary_New_summary->ServiceFeeToMerchant->viewAttributes() ?>><?php echo $Merchant_Sales_Summary_New_summary->ServiceFeeToMerchant->SumViewValue ?></span>
</td>
<?php } ?>
<?php if ($Merchant_Sales_Summary_New_summary->TotalAmountForMerchant->Visible) { ?>
		<td data-field="TotalAmountForMerchant"<?php echo $Merchant_Sales_Summary_New_summary->TotalAmountForMerchant->cellAttributes() ?>>
<span<?php echo $Merchant_Sales_Summary_New_summary->TotalAmountForMerchant->viewAttributes() ?>><?php echo $Merchant_Sales_Summary_New_summary->TotalAmountForMerchant->SumViewValue ?></span>
</td>
<?php } ?>
	</tr>
<?php } ?>
<?php
?>
<?php

	// Next group
	$Merchant_Sales_Summary_New_summary->loadGroupRowValues();

	// Show header if page break
	if ($Merchant_Sales_Summary_New_summary->isExport())
		$Merchant_Sales_Summary_New_summary->ShowHeader = ($Merchant_Sales_Summary_New_summary->ExportPageBreakCount == 0) ? FALSE : ($Merchant_Sales_Summary_New_summary->GroupCount % $Merchant_Sales_Summary_New_summary->ExportPageBreakCount == 0);

	// Page_Breaking server event
	if ($Merchant_Sales_Summary_New_summary->ShowHeader)
		$Merchant_Sales_Summary_New_summary->Page_Breaking($Merchant_Sales_Summary_New_summary->ShowHeader, $Merchant_Sales_Summary_New_summary->PageBreakContent);
	$Merchant_Sales_Summary_New_summary->GroupCount++;
} // End while
?>
<?php if ($Merchant_Sales_Summary_New_summary->TotalGroups > 0) { ?>
</tbody>
<tfoot>
<?php
	$Merchant_Sales_Summary_New_summary->resetAttributes();
	$Merchant_Sales_Summary_New_summary->RowType = ROWTYPE_TOTAL;
	$Merchant_Sales_Summary_New_summary->RowTotalType = ROWTOTAL_GRAND;
	$Merchant_Sales_Summary_New_summary->RowTotalSubType = ROWTOTAL_FOOTER;
	$Merchant_Sales_Summary_New_summary->RowAttrs["class"] = "ew-rpt-grand-summary";
	$Merchant_Sales_Summary_New_summary->renderRow();
?>
	<tr<?php echo $Merchant_Sales_Summary_New_summary->rowAttributes(); ?>>
		<td><?php echo $Language->phrase("RptGrandSummary") ?>&nbsp;<span class="ew-detail-count">(<?php echo FormatNumber($Merchant_Sales_Summary_New_summary->TotalCount, 0); ?><?php echo $Language->phrase("RptDtlRec") ?>)</span></td>
<?php if ($Merchant_Sales_Summary_New_summary->transtype->Visible) { ?>
		<td data-field="transtype">&nbsp;</td>
<?php } ?>
<?php if ($Merchant_Sales_Summary_New_summary->purchaseamount->Visible) { ?>
		<td data-field="purchaseamount"<?php echo $Merchant_Sales_Summary_New_summary->purchaseamount->cellAttributes() ?>>
<span<?php echo $Merchant_Sales_Summary_New_summary->purchaseamount->viewAttributes() ?>><?php echo $Merchant_Sales_Summary_New_summary->purchaseamount->SumViewValue ?></span>
</td>
<?php } ?>
<?php if ($Merchant_Sales_Summary_New_summary->discountamount->Visible) { ?>
		<td data-field="discountamount"<?php echo $Merchant_Sales_Summary_New_summary->discountamount->cellAttributes() ?>>
<span<?php echo $Merchant_Sales_Summary_New_summary->discountamount->viewAttributes() ?>><?php echo $Merchant_Sales_Summary_New_summary->discountamount->SumViewValue ?></span>
</td>
<?php } ?>
<?php if ($Merchant_Sales_Summary_New_summary->MerchantSurcharge->Visible) { ?>
		<td data-field="MerchantSurcharge"<?php echo $Merchant_Sales_Summary_New_summary->MerchantSurcharge->cellAttributes() ?>>
<span<?php echo $Merchant_Sales_Summary_New_summary->MerchantSurcharge->viewAttributes() ?>><?php echo $Merchant_Sales_Summary_New_summary->MerchantSurcharge->SumViewValue ?></span>
</td>
<?php } ?>
<?php if ($Merchant_Sales_Summary_New_summary->TipAmount->Visible) { ?>
		<td data-field="TipAmount"<?php echo $Merchant_Sales_Summary_New_summary->TipAmount->cellAttributes() ?>>
<span<?php echo $Merchant_Sales_Summary_New_summary->TipAmount->viewAttributes() ?>><?php echo $Merchant_Sales_Summary_New_summary->TipAmount->SumViewValue ?></span>
</td>
<?php } ?>
<?php if ($Merchant_Sales_Summary_New_summary->TaxAmount->Visible) { ?>
		<td data-field="TaxAmount"<?php echo $Merchant_Sales_Summary_New_summary->TaxAmount->cellAttributes() ?>>
<span<?php echo $Merchant_Sales_Summary_New_summary->TaxAmount->viewAttributes() ?>><?php echo $Merchant_Sales_Summary_New_summary->TaxAmount->SumViewValue ?></span>
</td>
<?php } ?>
<?php if ($Merchant_Sales_Summary_New_summary->ServiceFeeToCustomer->Visible) { ?>
		<td data-field="ServiceFeeToCustomer"<?php echo $Merchant_Sales_Summary_New_summary->ServiceFeeToCustomer->cellAttributes() ?>>
<span<?php echo $Merchant_Sales_Summary_New_summary->ServiceFeeToCustomer->viewAttributes() ?>><?php echo $Merchant_Sales_Summary_New_summary->ServiceFeeToCustomer->SumViewValue ?></span>
</td>
<?php } ?>
<?php if ($Merchant_Sales_Summary_New_summary->TotalAmountForCustomer->Visible) { ?>
		<td data-field="TotalAmountForCustomer"<?php echo $Merchant_Sales_Summary_New_summary->TotalAmountForCustomer->cellAttributes() ?>>
<span<?php echo $Merchant_Sales_Summary_New_summary->TotalAmountForCustomer->viewAttributes() ?>><?php echo $Merchant_Sales_Summary_New_summary->TotalAmountForCustomer->SumViewValue ?></span>
</td>
<?php } ?>
<?php if ($Merchant_Sales_Summary_New_summary->ServiceFeeToMerchant->Visible) { ?>
		<td data-field="ServiceFeeToMerchant"<?php echo $Merchant_Sales_Summary_New_summary->ServiceFeeToMerchant->cellAttributes() ?>>
<span<?php echo $Merchant_Sales_Summary_New_summary->ServiceFeeToMerchant->viewAttributes() ?>><?php echo $Merchant_Sales_Summary_New_summary->ServiceFeeToMerchant->SumViewValue ?></span>
</td>
<?php } ?>
<?php if ($Merchant_Sales_Summary_New_summary->TotalAmountForMerchant->Visible) { ?>
		<td data-field="TotalAmountForMerchant"<?php echo $Merchant_Sales_Summary_New_summary->TotalAmountForMerchant->cellAttributes() ?>>
<span<?php echo $Merchant_Sales_Summary_New_summary->TotalAmountForMerchant->viewAttributes() ?>><?php echo $Merchant_Sales_Summary_New_summary->TotalAmountForMerchant->SumViewValue ?></span>
</td>
<?php } ?>
	</tr>
</tfoot>
</table>
</div>
<!-- /.ew-grid-middle-panel -->
<!-- Report grid (end) -->
<?php if (!$Merchant_Sales_Summary_New_summary->isExport() && !($Merchant_Sales_Summary_New_summary->DrillDown && $Merchant_Sales_Summary_New_summary->TotalGroups > 0)) { ?>
<!-- Bottom pager -->
<div class="card-footer ew-grid-lower-panel">
<form name="ew-pager-form" class="form-inline ew-form ew-pager-form" action="<?php echo CurrentPageName() ?>">
<?php echo $Merchant_Sales_Summary_New_summary->Pager->render() ?>
</form>
<div class="clearfix"></div>
</div>
<?php } ?>
</div>
<!-- /.ew-grid -->
<?php } ?>
</div>
<!-- /#report-summary -->
<!-- Summary report (end) -->
<?php if ((!$Merchant_Sales_Summary_New_summary->isExport() || $Merchant_Sales_Summary_New_summary->isExport("print")) && !$DashboardReport) { ?>
</div>
<!-- /#ew-center -->
<?php } ?>
<?php if ((!$Merchant_Sales_Summary_New_summary->isExport() || $Merchant_Sales_Summary_New_summary->isExport("print")) && !$DashboardReport) { ?>
</div>
<!-- /.row -->
<?php } ?>
<?php if ((!$Merchant_Sales_Summary_New_summary->isExport() || $Merchant_Sales_Summary_New_summary->isExport("print")) && !$DashboardReport) { ?>
</div>
<!-- /.ew-report -->
<?php } ?>
<?php
$Merchant_Sales_Summary_New_summary->showPageFooter();
if (Config("DEBUG"))
	echo GetDebugMessage();
?>
<?php if (!$Merchant_Sales_Summary_New_summary->isExport() && !$Merchant_Sales_Summary_New_summary->DrillDown && !$DashboardReport) { ?>
<script>
loadjs.ready("load", function() {

	// Startup script
	// Write your table-specific startup script here
	// console.log("page loaded");

});
</script>
<?php } ?>
<?php if (!$DashboardReport) { ?>
<?php include_once "footer.php"; ?>
<?php } ?>
<?php
$Merchant_Sales_Summary_New_summary->terminate();
?>