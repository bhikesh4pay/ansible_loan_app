<?php
namespace PHPMaker2020\_4payadmin;

// Autoload
include_once "autoload.php";

// Session
if (session_status() !== PHP_SESSION_ACTIVE)
	\Delight\Cookie\Session::start(Config("COOKIE_SAMESITE")); // Init session data

// Output buffering
ob_start();
?>
<?php

// Write header
WriteHeader(FALSE);

// Create page object
$loanconfirmationlog_list = new loanconfirmationlog_list();

// Run the page
$loanconfirmationlog_list->run();

// Setup login status
SetupLoginStatus();
SetClientVar("login", LoginStatus());

// Global Page Rendering event (in userfn*.php)
Page_Rendering();

// Page Rendering event
$loanconfirmationlog_list->Page_Render();
?>
<?php include_once "header.php"; ?>
<?php if (!$loanconfirmationlog_list->isExport()) { ?>
<script>
var floanconfirmationloglist, currentPageID;
loadjs.ready("head", function() {

	// Form object
	currentPageID = ew.PAGE_ID = "list";
	floanconfirmationloglist = currentForm = new ew.Form("floanconfirmationloglist", "list");
	floanconfirmationloglist.formKeyCountName = '<?php echo $loanconfirmationlog_list->FormKeyCountName ?>';
	loadjs.done("floanconfirmationloglist");
});
</script>
<style type="text/css">
.ew-table-preview-row { /* main table preview row color */
	background-color: #FFFFFF; /* preview row color */
}
.ew-table-preview-row .ew-grid {
	display: table;
}
</style>
<div id="ew-preview" class="d-none"><!-- preview -->
	<div class="ew-nav-tabs"><!-- .ew-nav-tabs -->
		<ul class="nav nav-tabs"></ul>
		<div class="tab-content"><!-- .tab-content -->
			<div class="tab-pane fade active show"></div>
		</div><!-- /.tab-content -->
	</div><!-- /.ew-nav-tabs -->
</div><!-- /preview -->
<script>
loadjs.ready("head", function() {
	ew.PREVIEW_PLACEMENT = ew.CSS_FLIP ? "right" : "left";
	ew.PREVIEW_SINGLE_ROW = false;
	ew.PREVIEW_OVERLAY = false;
	loadjs("js/ewpreview.js", "preview");
});
</script>
<script>
loadjs.ready("head", function() {

	// Client script
	// Write your client script here, no need to add script tags.

});
</script>
<?php } ?>
<?php if (!$loanconfirmationlog_list->isExport()) { ?>
<div class="btn-toolbar ew-toolbar">
<?php if ($loanconfirmationlog_list->TotalRecords > 0 && $loanconfirmationlog_list->ExportOptions->visible()) { ?>
<?php $loanconfirmationlog_list->ExportOptions->render("body") ?>
<?php } ?>
<?php if ($loanconfirmationlog_list->ImportOptions->visible()) { ?>
<?php $loanconfirmationlog_list->ImportOptions->render("body") ?>
<?php } ?>
<div class="clearfix"></div>
</div>
<?php } ?>
<?php
$loanconfirmationlog_list->renderOtherOptions();
?>
<?php $loanconfirmationlog_list->showPageHeader(); ?>
<?php
$loanconfirmationlog_list->showMessage();
?>
<?php if ($loanconfirmationlog_list->TotalRecords > 0 || $loanconfirmationlog->CurrentAction) { ?>
<div class="card ew-card ew-grid<?php if ($loanconfirmationlog_list->isAddOrEdit()) { ?> ew-grid-add-edit<?php } ?> loanconfirmationlog">
<form name="floanconfirmationloglist" id="floanconfirmationloglist" class="form-inline ew-form ew-list-form" action="<?php echo CurrentPageName() ?>" method="post">
<?php if ($Page->CheckToken) { ?>
<input type="hidden" name="<?php echo Config("TOKEN_NAME") ?>" value="<?php echo $Page->Token ?>">
<?php } ?>
<input type="hidden" name="t" value="loanconfirmationlog">
<div id="gmp_loanconfirmationlog" class="<?php echo ResponsiveTableClass() ?>card-body ew-grid-middle-panel">
<?php if ($loanconfirmationlog_list->TotalRecords > 0 || $loanconfirmationlog_list->isGridEdit()) { ?>
<table id="tbl_loanconfirmationloglist" class="table ew-table"><!-- .ew-table -->
<thead>
	<tr class="ew-table-header">
<?php

// Header row
$loanconfirmationlog->RowType = ROWTYPE_HEADER;

// Render list options
$loanconfirmationlog_list->renderListOptions();

// Render list options (header, left)
$loanconfirmationlog_list->ListOptions->render("header", "left");
?>
<?php if ($loanconfirmationlog_list->id->Visible) { // id ?>
	<?php if ($loanconfirmationlog_list->SortUrl($loanconfirmationlog_list->id) == "") { ?>
		<th data-name="id" class="<?php echo $loanconfirmationlog_list->id->headerCellClass() ?>"><div id="elh_loanconfirmationlog_id" class="loanconfirmationlog_id"><div class="ew-table-header-caption"><?php echo $loanconfirmationlog_list->id->caption() ?></div></div></th>
	<?php } else { ?>
		<th data-name="id" class="<?php echo $loanconfirmationlog_list->id->headerCellClass() ?>"><div class="ew-pointer" onclick="ew.sort(event, '<?php echo $loanconfirmationlog_list->SortUrl($loanconfirmationlog_list->id) ?>', 1);"><div id="elh_loanconfirmationlog_id" class="loanconfirmationlog_id">
			<div class="ew-table-header-btn"><span class="ew-table-header-caption"><?php echo $loanconfirmationlog_list->id->caption() ?></span><span class="ew-table-header-sort"><?php if ($loanconfirmationlog_list->id->getSort() == "ASC") { ?><i class="fas fa-sort-up"></i><?php } elseif ($loanconfirmationlog_list->id->getSort() == "DESC") { ?><i class="fas fa-sort-down"></i><?php } ?></span></div>
		</div></div></th>
	<?php } ?>
<?php } ?>
<?php if ($loanconfirmationlog_list->loanid->Visible) { // loanid ?>
	<?php if ($loanconfirmationlog_list->SortUrl($loanconfirmationlog_list->loanid) == "") { ?>
		<th data-name="loanid" class="<?php echo $loanconfirmationlog_list->loanid->headerCellClass() ?>"><div id="elh_loanconfirmationlog_loanid" class="loanconfirmationlog_loanid"><div class="ew-table-header-caption"><?php echo $loanconfirmationlog_list->loanid->caption() ?></div></div></th>
	<?php } else { ?>
		<th data-name="loanid" class="<?php echo $loanconfirmationlog_list->loanid->headerCellClass() ?>"><div class="ew-pointer" onclick="ew.sort(event, '<?php echo $loanconfirmationlog_list->SortUrl($loanconfirmationlog_list->loanid) ?>', 1);"><div id="elh_loanconfirmationlog_loanid" class="loanconfirmationlog_loanid">
			<div class="ew-table-header-btn"><span class="ew-table-header-caption"><?php echo $loanconfirmationlog_list->loanid->caption() ?></span><span class="ew-table-header-sort"><?php if ($loanconfirmationlog_list->loanid->getSort() == "ASC") { ?><i class="fas fa-sort-up"></i><?php } elseif ($loanconfirmationlog_list->loanid->getSort() == "DESC") { ?><i class="fas fa-sort-down"></i><?php } ?></span></div>
		</div></div></th>
	<?php } ?>
<?php } ?>
<?php if ($loanconfirmationlog_list->confirmationtime->Visible) { // confirmationtime ?>
	<?php if ($loanconfirmationlog_list->SortUrl($loanconfirmationlog_list->confirmationtime) == "") { ?>
		<th data-name="confirmationtime" class="<?php echo $loanconfirmationlog_list->confirmationtime->headerCellClass() ?>"><div id="elh_loanconfirmationlog_confirmationtime" class="loanconfirmationlog_confirmationtime"><div class="ew-table-header-caption"><?php echo $loanconfirmationlog_list->confirmationtime->caption() ?></div></div></th>
	<?php } else { ?>
		<th data-name="confirmationtime" class="<?php echo $loanconfirmationlog_list->confirmationtime->headerCellClass() ?>"><div class="ew-pointer" onclick="ew.sort(event, '<?php echo $loanconfirmationlog_list->SortUrl($loanconfirmationlog_list->confirmationtime) ?>', 1);"><div id="elh_loanconfirmationlog_confirmationtime" class="loanconfirmationlog_confirmationtime">
			<div class="ew-table-header-btn"><span class="ew-table-header-caption"><?php echo $loanconfirmationlog_list->confirmationtime->caption() ?></span><span class="ew-table-header-sort"><?php if ($loanconfirmationlog_list->confirmationtime->getSort() == "ASC") { ?><i class="fas fa-sort-up"></i><?php } elseif ($loanconfirmationlog_list->confirmationtime->getSort() == "DESC") { ?><i class="fas fa-sort-down"></i><?php } ?></span></div>
		</div></div></th>
	<?php } ?>
<?php } ?>
<?php

// Render list options (header, right)
$loanconfirmationlog_list->ListOptions->render("header", "right");
?>
	</tr>
</thead>
<tbody>
<?php
if ($loanconfirmationlog_list->ExportAll && $loanconfirmationlog_list->isExport()) {
	$loanconfirmationlog_list->StopRecord = $loanconfirmationlog_list->TotalRecords;
} else {

	// Set the last record to display
	if ($loanconfirmationlog_list->TotalRecords > $loanconfirmationlog_list->StartRecord + $loanconfirmationlog_list->DisplayRecords - 1)
		$loanconfirmationlog_list->StopRecord = $loanconfirmationlog_list->StartRecord + $loanconfirmationlog_list->DisplayRecords - 1;
	else
		$loanconfirmationlog_list->StopRecord = $loanconfirmationlog_list->TotalRecords;
}
$loanconfirmationlog_list->RecordCount = $loanconfirmationlog_list->StartRecord - 1;
if ($loanconfirmationlog_list->Recordset && !$loanconfirmationlog_list->Recordset->EOF) {
	$loanconfirmationlog_list->Recordset->moveFirst();
	$selectLimit = $loanconfirmationlog_list->UseSelectLimit;
	if (!$selectLimit && $loanconfirmationlog_list->StartRecord > 1)
		$loanconfirmationlog_list->Recordset->move($loanconfirmationlog_list->StartRecord - 1);
} elseif (!$loanconfirmationlog->AllowAddDeleteRow && $loanconfirmationlog_list->StopRecord == 0) {
	$loanconfirmationlog_list->StopRecord = $loanconfirmationlog->GridAddRowCount;
}

// Initialize aggregate
$loanconfirmationlog->RowType = ROWTYPE_AGGREGATEINIT;
$loanconfirmationlog->resetAttributes();
$loanconfirmationlog_list->renderRow();
while ($loanconfirmationlog_list->RecordCount < $loanconfirmationlog_list->StopRecord) {
	$loanconfirmationlog_list->RecordCount++;
	if ($loanconfirmationlog_list->RecordCount >= $loanconfirmationlog_list->StartRecord) {
		$loanconfirmationlog_list->RowCount++;

		// Set up key count
		$loanconfirmationlog_list->KeyCount = $loanconfirmationlog_list->RowIndex;

		// Init row class and style
		$loanconfirmationlog->resetAttributes();
		$loanconfirmationlog->CssClass = "";
		if ($loanconfirmationlog_list->isGridAdd()) {
		} else {
			$loanconfirmationlog_list->loadRowValues($loanconfirmationlog_list->Recordset); // Load row values
		}
		$loanconfirmationlog->RowType = ROWTYPE_VIEW; // Render view

		// Set up row id / data-rowindex
		$loanconfirmationlog->RowAttrs->merge(["data-rowindex" => $loanconfirmationlog_list->RowCount, "id" => "r" . $loanconfirmationlog_list->RowCount . "_loanconfirmationlog", "data-rowtype" => $loanconfirmationlog->RowType]);

		// Render row
		$loanconfirmationlog_list->renderRow();

		// Render list options
		$loanconfirmationlog_list->renderListOptions();
?>
	<tr <?php echo $loanconfirmationlog->rowAttributes() ?>>
<?php

// Render list options (body, left)
$loanconfirmationlog_list->ListOptions->render("body", "left", $loanconfirmationlog_list->RowCount);
?>
	<?php if ($loanconfirmationlog_list->id->Visible) { // id ?>
		<td data-name="id" <?php echo $loanconfirmationlog_list->id->cellAttributes() ?>>
<span id="el<?php echo $loanconfirmationlog_list->RowCount ?>_loanconfirmationlog_id">
<span<?php echo $loanconfirmationlog_list->id->viewAttributes() ?>><?php echo $loanconfirmationlog_list->id->getViewValue() ?></span>
</span>
</td>
	<?php } ?>
	<?php if ($loanconfirmationlog_list->loanid->Visible) { // loanid ?>
		<td data-name="loanid" <?php echo $loanconfirmationlog_list->loanid->cellAttributes() ?>>
<span id="el<?php echo $loanconfirmationlog_list->RowCount ?>_loanconfirmationlog_loanid">
<span<?php echo $loanconfirmationlog_list->loanid->viewAttributes() ?>><?php echo $loanconfirmationlog_list->loanid->getViewValue() ?></span>
</span>
</td>
	<?php } ?>
	<?php if ($loanconfirmationlog_list->confirmationtime->Visible) { // confirmationtime ?>
		<td data-name="confirmationtime" <?php echo $loanconfirmationlog_list->confirmationtime->cellAttributes() ?>>
<span id="el<?php echo $loanconfirmationlog_list->RowCount ?>_loanconfirmationlog_confirmationtime">
<span<?php echo $loanconfirmationlog_list->confirmationtime->viewAttributes() ?>><?php echo $loanconfirmationlog_list->confirmationtime->getViewValue() ?></span>
</span>
</td>
	<?php } ?>
<?php

// Render list options (body, right)
$loanconfirmationlog_list->ListOptions->render("body", "right", $loanconfirmationlog_list->RowCount);
?>
	</tr>
<?php
	}
	if (!$loanconfirmationlog_list->isGridAdd())
		$loanconfirmationlog_list->Recordset->moveNext();
}
?>
</tbody>
</table><!-- /.ew-table -->
<?php } ?>
</div><!-- /.ew-grid-middle-panel -->
<?php if (!$loanconfirmationlog->CurrentAction) { ?>
<input type="hidden" name="action" id="action" value="">
<?php } ?>
</form><!-- /.ew-list-form -->
<?php

// Close recordset
if ($loanconfirmationlog_list->Recordset)
	$loanconfirmationlog_list->Recordset->Close();
?>
<?php if (!$loanconfirmationlog_list->isExport()) { ?>
<div class="card-footer ew-grid-lower-panel">
<?php if (!$loanconfirmationlog_list->isGridAdd()) { ?>
<form name="ew-pager-form" class="form-inline ew-form ew-pager-form" action="<?php echo CurrentPageName() ?>">
<?php echo $loanconfirmationlog_list->Pager->render() ?>
</form>
<?php } ?>
<div class="ew-list-other-options">
<?php $loanconfirmationlog_list->OtherOptions->render("body", "bottom") ?>
</div>
<div class="clearfix"></div>
</div>
<?php } ?>
</div><!-- /.ew-grid -->
<?php } ?>
<?php if ($loanconfirmationlog_list->TotalRecords == 0 && !$loanconfirmationlog->CurrentAction) { // Show other options ?>
<div class="ew-list-other-options">
<?php $loanconfirmationlog_list->OtherOptions->render("body") ?>
</div>
<div class="clearfix"></div>
<?php } ?>
<?php
$loanconfirmationlog_list->showPageFooter();
if (Config("DEBUG"))
	echo GetDebugMessage();
?>
<?php if (!$loanconfirmationlog_list->isExport()) { ?>
<script>
loadjs.ready("load", function() {

	// Startup script
	// Write your table-specific startup script here
	// console.log("page loaded");

});
</script>
<?php } ?>
<?php include_once "footer.php"; ?>
<?php
$loanconfirmationlog_list->terminate();
?>