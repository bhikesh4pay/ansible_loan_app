<?php
namespace PHPMaker2020\_4payadmin;

// Autoload
include_once "autoload.php";

// Session
if (session_status() !== PHP_SESSION_ACTIVE)
	\Delight\Cookie\Session::start(Config("COOKIE_SAMESITE")); // Init session data

// Output buffering
ob_start();
?>
<?php

// Write header
WriteHeader(FALSE);

// Create page object
$emaillog_view = new emaillog_view();

// Run the page
$emaillog_view->run();

// Setup login status
SetupLoginStatus();
SetClientVar("login", LoginStatus());

// Global Page Rendering event (in userfn*.php)
Page_Rendering();

// Page Rendering event
$emaillog_view->Page_Render();
?>
<?php include_once "header.php"; ?>
<?php if (!$emaillog_view->isExport()) { ?>
<script>
var femaillogview, currentPageID;
loadjs.ready("head", function() {

	// Form object
	currentPageID = ew.PAGE_ID = "view";
	femaillogview = currentForm = new ew.Form("femaillogview", "view");
	loadjs.done("femaillogview");
});
</script>
<script>
loadjs.ready("head", function() {

	// Client script
	// Write your client script here, no need to add script tags.

});
</script>
<?php } ?>
<?php if (!$emaillog_view->isExport()) { ?>
<div class="btn-toolbar ew-toolbar">
<?php $emaillog_view->ExportOptions->render("body") ?>
<?php $emaillog_view->OtherOptions->render("body") ?>
<div class="clearfix"></div>
</div>
<?php } ?>
<?php $emaillog_view->showPageHeader(); ?>
<?php
$emaillog_view->showMessage();
?>
<form name="femaillogview" id="femaillogview" class="form-inline ew-form ew-view-form" action="<?php echo CurrentPageName() ?>" method="post">
<?php if ($Page->CheckToken) { ?>
<input type="hidden" name="<?php echo Config("TOKEN_NAME") ?>" value="<?php echo $Page->Token ?>">
<?php } ?>
<input type="hidden" name="t" value="emaillog">
<input type="hidden" name="modal" value="<?php echo (int)$emaillog_view->IsModal ?>">
<table class="table table-striped table-sm ew-view-table">
<?php if ($emaillog_view->emailid->Visible) { // emailid ?>
	<tr id="r_emailid">
		<td class="<?php echo $emaillog_view->TableLeftColumnClass ?>"><span id="elh_emaillog_emailid"><?php echo $emaillog_view->emailid->caption() ?></span></td>
		<td data-name="emailid" <?php echo $emaillog_view->emailid->cellAttributes() ?>>
<span id="el_emaillog_emailid">
<span<?php echo $emaillog_view->emailid->viewAttributes() ?>><?php echo $emaillog_view->emailid->getViewValue() ?></span>
</span>
</td>
	</tr>
<?php } ?>
<?php if ($emaillog_view->_userid->Visible) { // userid ?>
	<tr id="r__userid">
		<td class="<?php echo $emaillog_view->TableLeftColumnClass ?>"><span id="elh_emaillog__userid"><?php echo $emaillog_view->_userid->caption() ?></span></td>
		<td data-name="_userid" <?php echo $emaillog_view->_userid->cellAttributes() ?>>
<span id="el_emaillog__userid">
<span<?php echo $emaillog_view->_userid->viewAttributes() ?>><?php echo $emaillog_view->_userid->getViewValue() ?></span>
</span>
</td>
	</tr>
<?php } ?>
<?php if ($emaillog_view->_email->Visible) { // email ?>
	<tr id="r__email">
		<td class="<?php echo $emaillog_view->TableLeftColumnClass ?>"><span id="elh_emaillog__email"><?php echo $emaillog_view->_email->caption() ?></span></td>
		<td data-name="_email" <?php echo $emaillog_view->_email->cellAttributes() ?>>
<span id="el_emaillog__email">
<span<?php echo $emaillog_view->_email->viewAttributes() ?>><?php echo $emaillog_view->_email->getViewValue() ?></span>
</span>
</td>
	</tr>
<?php } ?>
<?php if ($emaillog_view->emailtext->Visible) { // emailtext ?>
	<tr id="r_emailtext">
		<td class="<?php echo $emaillog_view->TableLeftColumnClass ?>"><span id="elh_emaillog_emailtext"><?php echo $emaillog_view->emailtext->caption() ?></span></td>
		<td data-name="emailtext" <?php echo $emaillog_view->emailtext->cellAttributes() ?>>
<span id="el_emaillog_emailtext">
<span<?php echo $emaillog_view->emailtext->viewAttributes() ?>><?php echo $emaillog_view->emailtext->getViewValue() ?></span>
</span>
</td>
	</tr>
<?php } ?>
<?php if ($emaillog_view->emailtime->Visible) { // emailtime ?>
	<tr id="r_emailtime">
		<td class="<?php echo $emaillog_view->TableLeftColumnClass ?>"><span id="elh_emaillog_emailtime"><?php echo $emaillog_view->emailtime->caption() ?></span></td>
		<td data-name="emailtime" <?php echo $emaillog_view->emailtime->cellAttributes() ?>>
<span id="el_emaillog_emailtime">
<span<?php echo $emaillog_view->emailtime->viewAttributes() ?>><?php echo $emaillog_view->emailtime->getViewValue() ?></span>
</span>
</td>
	</tr>
<?php } ?>
<?php if ($emaillog_view->trackingid->Visible) { // trackingid ?>
	<tr id="r_trackingid">
		<td class="<?php echo $emaillog_view->TableLeftColumnClass ?>"><span id="elh_emaillog_trackingid"><?php echo $emaillog_view->trackingid->caption() ?></span></td>
		<td data-name="trackingid" <?php echo $emaillog_view->trackingid->cellAttributes() ?>>
<span id="el_emaillog_trackingid">
<span<?php echo $emaillog_view->trackingid->viewAttributes() ?>><?php echo $emaillog_view->trackingid->getViewValue() ?></span>
</span>
</td>
	</tr>
<?php } ?>
<?php if ($emaillog_view->emailsubject->Visible) { // emailsubject ?>
	<tr id="r_emailsubject">
		<td class="<?php echo $emaillog_view->TableLeftColumnClass ?>"><span id="elh_emaillog_emailsubject"><?php echo $emaillog_view->emailsubject->caption() ?></span></td>
		<td data-name="emailsubject" <?php echo $emaillog_view->emailsubject->cellAttributes() ?>>
<span id="el_emaillog_emailsubject">
<span<?php echo $emaillog_view->emailsubject->viewAttributes() ?>><?php echo $emaillog_view->emailsubject->getViewValue() ?></span>
</span>
</td>
	</tr>
<?php } ?>
</table>
</form>
<?php
$emaillog_view->showPageFooter();
if (Config("DEBUG"))
	echo GetDebugMessage();
?>
<?php if (!$emaillog_view->isExport()) { ?>
<script>
loadjs.ready("load", function() {

	// Startup script
	// Write your table-specific startup script here
	// console.log("page loaded");

});
</script>
<?php } ?>
<?php include_once "footer.php"; ?>
<?php
$emaillog_view->terminate();
?>