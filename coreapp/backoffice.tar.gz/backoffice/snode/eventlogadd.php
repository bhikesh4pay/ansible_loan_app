<?php
namespace PHPMaker2020\_4payadmin;

// Autoload
include_once "autoload.php";

// Session
if (session_status() !== PHP_SESSION_ACTIVE)
	\Delight\Cookie\Session::start(Config("COOKIE_SAMESITE")); // Init session data

// Output buffering
ob_start();
?>
<?php

// Write header
WriteHeader(FALSE);

// Create page object
$eventlog_add = new eventlog_add();

// Run the page
$eventlog_add->run();

// Setup login status
SetupLoginStatus();
SetClientVar("login", LoginStatus());

// Global Page Rendering event (in userfn*.php)
Page_Rendering();

// Page Rendering event
$eventlog_add->Page_Render();
?>
<?php include_once "header.php"; ?>
<script>
var feventlogadd, currentPageID;
loadjs.ready("head", function() {

	// Form object
	currentPageID = ew.PAGE_ID = "add";
	feventlogadd = currentForm = new ew.Form("feventlogadd", "add");

	// Validate form
	feventlogadd.validate = function() {
		if (!this.validateRequired)
			return true; // Ignore validation
		var $ = jQuery, fobj = this.getForm(), $fobj = $(fobj);
		if ($fobj.find("#confirm").val() == "confirm")
			return true;
		var elm, felm, uelm, addcnt = 0;
		var $k = $fobj.find("#" + this.formKeyCountName); // Get key_count
		var rowcnt = ($k[0]) ? parseInt($k.val(), 10) : 1;
		var startcnt = (rowcnt == 0) ? 0 : 1; // Check rowcnt == 0 => Inline-Add
		var gridinsert = ["insert", "gridinsert"].includes($fobj.find("#action").val()) && $k[0];
		for (var i = startcnt; i <= rowcnt; i++) {
			var infix = ($k[0]) ? String(i) : "";
			$fobj.data("rowindex", infix);
			<?php if ($eventlog_add->eventtype->Required) { ?>
				elm = this.getElements("x" + infix + "_eventtype");
				if (elm && !ew.isHidden(elm) && !ew.hasValue(elm))
					return this.onError(elm, "<?php echo JsEncode(str_replace("%s", $eventlog_add->eventtype->caption(), $eventlog_add->eventtype->RequiredErrorMessage)) ?>");
			<?php } ?>
				elm = this.getElements("x" + infix + "_eventtype");
				if (elm && !ew.checkInteger(elm.value))
					return this.onError(elm, "<?php echo JsEncode($eventlog_add->eventtype->errorMessage()) ?>");
			<?php if ($eventlog_add->_userid->Required) { ?>
				elm = this.getElements("x" + infix + "__userid");
				if (elm && !ew.isHidden(elm) && !ew.hasValue(elm))
					return this.onError(elm, "<?php echo JsEncode(str_replace("%s", $eventlog_add->_userid->caption(), $eventlog_add->_userid->RequiredErrorMessage)) ?>");
			<?php } ?>
				elm = this.getElements("x" + infix + "__userid");
				if (elm && !ew.checkInteger(elm.value))
					return this.onError(elm, "<?php echo JsEncode($eventlog_add->_userid->errorMessage()) ?>");
			<?php if ($eventlog_add->eventdatetime->Required) { ?>
				elm = this.getElements("x" + infix + "_eventdatetime");
				if (elm && !ew.isHidden(elm) && !ew.hasValue(elm))
					return this.onError(elm, "<?php echo JsEncode(str_replace("%s", $eventlog_add->eventdatetime->caption(), $eventlog_add->eventdatetime->RequiredErrorMessage)) ?>");
			<?php } ?>
				elm = this.getElements("x" + infix + "_eventdatetime");
				if (elm && !ew.checkDateDef(elm.value))
					return this.onError(elm, "<?php echo JsEncode($eventlog_add->eventdatetime->errorMessage()) ?>");
			<?php if ($eventlog_add->createdby->Required) { ?>
				elm = this.getElements("x" + infix + "_createdby");
				if (elm && !ew.isHidden(elm) && !ew.hasValue(elm))
					return this.onError(elm, "<?php echo JsEncode(str_replace("%s", $eventlog_add->createdby->caption(), $eventlog_add->createdby->RequiredErrorMessage)) ?>");
			<?php } ?>
				elm = this.getElements("x" + infix + "_createdby");
				if (elm && !ew.checkInteger(elm.value))
					return this.onError(elm, "<?php echo JsEncode($eventlog_add->createdby->errorMessage()) ?>");
			<?php if ($eventlog_add->notes->Required) { ?>
				elm = this.getElements("x" + infix + "_notes");
				if (elm && !ew.isHidden(elm) && !ew.hasValue(elm))
					return this.onError(elm, "<?php echo JsEncode(str_replace("%s", $eventlog_add->notes->caption(), $eventlog_add->notes->RequiredErrorMessage)) ?>");
			<?php } ?>

				// Call Form_CustomValidate event
				if (!this.Form_CustomValidate(fobj))
					return false;
		}

		// Process detail forms
		var dfs = $fobj.find("input[name='detailpage']").get();
		for (var i = 0; i < dfs.length; i++) {
			var df = dfs[i], val = df.value;
			if (val && ew.forms[val])
				if (!ew.forms[val].validate())
					return false;
		}
		return true;
	}

	// Form_CustomValidate
	feventlogadd.Form_CustomValidate = function(fobj) { // DO NOT CHANGE THIS LINE!

		// Your custom validation code here, return false if invalid.
		return true;
	}

	// Use JavaScript validation or not
	feventlogadd.validateRequired = <?php echo Config("CLIENT_VALIDATE") ? "true" : "false" ?>;

	// Dynamic selection lists
	feventlogadd.lists["x__userid"] = <?php echo $eventlog_add->_userid->Lookup->toClientList($eventlog_add) ?>;
	feventlogadd.lists["x__userid"].options = <?php echo JsonEncode($eventlog_add->_userid->lookupOptions()) ?>;
	feventlogadd.autoSuggests["x__userid"] = <?php echo json_encode(["data" => "ajax=autosuggest"]) ?>;
	feventlogadd.lists["x_createdby"] = <?php echo $eventlog_add->createdby->Lookup->toClientList($eventlog_add) ?>;
	feventlogadd.lists["x_createdby"].options = <?php echo JsonEncode($eventlog_add->createdby->lookupOptions()) ?>;
	feventlogadd.autoSuggests["x_createdby"] = <?php echo json_encode(["data" => "ajax=autosuggest"]) ?>;
	loadjs.done("feventlogadd");
});
</script>
<script>
loadjs.ready("head", function() {

	// Client script
	// Write your client script here, no need to add script tags.

});
</script>
<?php $eventlog_add->showPageHeader(); ?>
<?php
$eventlog_add->showMessage();
?>
<form name="feventlogadd" id="feventlogadd" class="<?php echo $eventlog_add->FormClassName ?>" action="<?php echo CurrentPageName() ?>" method="post">
<?php if ($Page->CheckToken) { ?>
<input type="hidden" name="<?php echo Config("TOKEN_NAME") ?>" value="<?php echo $Page->Token ?>">
<?php } ?>
<input type="hidden" name="t" value="eventlog">
<input type="hidden" name="action" id="action" value="insert">
<input type="hidden" name="modal" value="<?php echo (int)$eventlog_add->IsModal ?>">
<div class="ew-add-div"><!-- page* -->
<?php if ($eventlog_add->eventtype->Visible) { // eventtype ?>
	<div id="r_eventtype" class="form-group row">
		<label id="elh_eventlog_eventtype" for="x_eventtype" class="<?php echo $eventlog_add->LeftColumnClass ?>"><?php echo $eventlog_add->eventtype->caption() ?><?php echo $eventlog_add->eventtype->Required ? $Language->phrase("FieldRequiredIndicator") : "" ?></label>
		<div class="<?php echo $eventlog_add->RightColumnClass ?>"><div <?php echo $eventlog_add->eventtype->cellAttributes() ?>>
<span id="el_eventlog_eventtype">
<input type="text" data-table="eventlog" data-field="x_eventtype" name="x_eventtype" id="x_eventtype" size="30" maxlength="5" placeholder="<?php echo HtmlEncode($eventlog_add->eventtype->getPlaceHolder()) ?>" value="<?php echo $eventlog_add->eventtype->EditValue ?>"<?php echo $eventlog_add->eventtype->editAttributes() ?>>
</span>
<?php echo $eventlog_add->eventtype->CustomMsg ?></div></div>
	</div>
<?php } ?>
<?php if ($eventlog_add->_userid->Visible) { // userid ?>
	<div id="r__userid" class="form-group row">
		<label id="elh_eventlog__userid" class="<?php echo $eventlog_add->LeftColumnClass ?>"><?php echo $eventlog_add->_userid->caption() ?><?php echo $eventlog_add->_userid->Required ? $Language->phrase("FieldRequiredIndicator") : "" ?></label>
		<div class="<?php echo $eventlog_add->RightColumnClass ?>"><div <?php echo $eventlog_add->_userid->cellAttributes() ?>>
<span id="el_eventlog__userid">
<?php
$onchange = $eventlog_add->_userid->EditAttrs->prepend("onchange", "");
$onchange = ($onchange) ? ' onchange="' . JsEncode($onchange) . '"' : '';
$eventlog_add->_userid->EditAttrs["onchange"] = "";
?>
<span id="as_x__userid">
	<input type="text" class="form-control" name="sv_x__userid" id="sv_x__userid" value="<?php echo RemoveHtml($eventlog_add->_userid->EditValue) ?>" size="30" maxlength="12" placeholder="<?php echo HtmlEncode($eventlog_add->_userid->getPlaceHolder()) ?>" data-placeholder="<?php echo HtmlEncode($eventlog_add->_userid->getPlaceHolder()) ?>"<?php echo $eventlog_add->_userid->editAttributes() ?>>
</span>
<input type="hidden" data-table="eventlog" data-field="x__userid" data-value-separator="<?php echo $eventlog_add->_userid->displayValueSeparatorAttribute() ?>" name="x__userid" id="x__userid" value="<?php echo HtmlEncode($eventlog_add->_userid->CurrentValue) ?>"<?php echo $onchange ?>>
<script>
loadjs.ready(["feventlogadd"], function() {
	feventlogadd.createAutoSuggest({"id":"x__userid","forceSelect":false});
});
</script>
<?php echo $eventlog_add->_userid->Lookup->getParamTag($eventlog_add, "p_x__userid") ?>
</span>
<?php echo $eventlog_add->_userid->CustomMsg ?></div></div>
	</div>
<?php } ?>
<?php if ($eventlog_add->eventdatetime->Visible) { // eventdatetime ?>
	<div id="r_eventdatetime" class="form-group row">
		<label id="elh_eventlog_eventdatetime" for="x_eventdatetime" class="<?php echo $eventlog_add->LeftColumnClass ?>"><?php echo $eventlog_add->eventdatetime->caption() ?><?php echo $eventlog_add->eventdatetime->Required ? $Language->phrase("FieldRequiredIndicator") : "" ?></label>
		<div class="<?php echo $eventlog_add->RightColumnClass ?>"><div <?php echo $eventlog_add->eventdatetime->cellAttributes() ?>>
<span id="el_eventlog_eventdatetime">
<input type="text" data-table="eventlog" data-field="x_eventdatetime" name="x_eventdatetime" id="x_eventdatetime" maxlength="19" placeholder="<?php echo HtmlEncode($eventlog_add->eventdatetime->getPlaceHolder()) ?>" value="<?php echo $eventlog_add->eventdatetime->EditValue ?>"<?php echo $eventlog_add->eventdatetime->editAttributes() ?>>
<?php if (!$eventlog_add->eventdatetime->ReadOnly && !$eventlog_add->eventdatetime->Disabled && !isset($eventlog_add->eventdatetime->EditAttrs["readonly"]) && !isset($eventlog_add->eventdatetime->EditAttrs["disabled"])) { ?>
<script>
loadjs.ready(["feventlogadd", "datetimepicker"], function() {
	ew.createDateTimePicker("feventlogadd", "x_eventdatetime", {"ignoreReadonly":true,"useCurrent":false,"format":0});
});
</script>
<?php } ?>
</span>
<?php echo $eventlog_add->eventdatetime->CustomMsg ?></div></div>
	</div>
<?php } ?>
<?php if ($eventlog_add->createdby->Visible) { // createdby ?>
	<div id="r_createdby" class="form-group row">
		<label id="elh_eventlog_createdby" class="<?php echo $eventlog_add->LeftColumnClass ?>"><?php echo $eventlog_add->createdby->caption() ?><?php echo $eventlog_add->createdby->Required ? $Language->phrase("FieldRequiredIndicator") : "" ?></label>
		<div class="<?php echo $eventlog_add->RightColumnClass ?>"><div <?php echo $eventlog_add->createdby->cellAttributes() ?>>
<span id="el_eventlog_createdby">
<?php
$onchange = $eventlog_add->createdby->EditAttrs->prepend("onchange", "");
$onchange = ($onchange) ? ' onchange="' . JsEncode($onchange) . '"' : '';
$eventlog_add->createdby->EditAttrs["onchange"] = "";
?>
<span id="as_x_createdby">
	<input type="text" class="form-control" name="sv_x_createdby" id="sv_x_createdby" value="<?php echo RemoveHtml($eventlog_add->createdby->EditValue) ?>" size="30" maxlength="12" placeholder="<?php echo HtmlEncode($eventlog_add->createdby->getPlaceHolder()) ?>" data-placeholder="<?php echo HtmlEncode($eventlog_add->createdby->getPlaceHolder()) ?>"<?php echo $eventlog_add->createdby->editAttributes() ?>>
</span>
<input type="hidden" data-table="eventlog" data-field="x_createdby" data-value-separator="<?php echo $eventlog_add->createdby->displayValueSeparatorAttribute() ?>" name="x_createdby" id="x_createdby" value="<?php echo HtmlEncode($eventlog_add->createdby->CurrentValue) ?>"<?php echo $onchange ?>>
<script>
loadjs.ready(["feventlogadd"], function() {
	feventlogadd.createAutoSuggest({"id":"x_createdby","forceSelect":false});
});
</script>
<?php echo $eventlog_add->createdby->Lookup->getParamTag($eventlog_add, "p_x_createdby") ?>
</span>
<?php echo $eventlog_add->createdby->CustomMsg ?></div></div>
	</div>
<?php } ?>
<?php if ($eventlog_add->notes->Visible) { // notes ?>
	<div id="r_notes" class="form-group row">
		<label id="elh_eventlog_notes" for="x_notes" class="<?php echo $eventlog_add->LeftColumnClass ?>"><?php echo $eventlog_add->notes->caption() ?><?php echo $eventlog_add->notes->Required ? $Language->phrase("FieldRequiredIndicator") : "" ?></label>
		<div class="<?php echo $eventlog_add->RightColumnClass ?>"><div <?php echo $eventlog_add->notes->cellAttributes() ?>>
<span id="el_eventlog_notes">
<textarea data-table="eventlog" data-field="x_notes" name="x_notes" id="x_notes" cols="35" rows="4" placeholder="<?php echo HtmlEncode($eventlog_add->notes->getPlaceHolder()) ?>"<?php echo $eventlog_add->notes->editAttributes() ?>><?php echo $eventlog_add->notes->EditValue ?></textarea>
</span>
<?php echo $eventlog_add->notes->CustomMsg ?></div></div>
	</div>
<?php } ?>
</div><!-- /page* -->
<?php if (!$eventlog_add->IsModal) { ?>
<div class="form-group row"><!-- buttons .form-group -->
	<div class="<?php echo $eventlog_add->OffsetColumnClass ?>"><!-- buttons offset -->
<button class="btn btn-primary ew-btn" name="btn-action" id="btn-action" type="submit"><?php echo $Language->phrase("AddBtn") ?></button>
<button class="btn btn-default ew-btn" name="btn-cancel" id="btn-cancel" type="button" data-href="<?php echo $eventlog_add->getReturnUrl() ?>"><?php echo $Language->phrase("CancelBtn") ?></button>
	</div><!-- /buttons offset -->
</div><!-- /buttons .form-group -->
<?php } ?>
</form>
<?php
$eventlog_add->showPageFooter();
if (Config("DEBUG"))
	echo GetDebugMessage();
?>
<script>
loadjs.ready("load", function() {

	// Startup script
	// Write your table-specific startup script here
	// console.log("page loaded");

});
</script>
<?php include_once "footer.php"; ?>
<?php
$eventlog_add->terminate();
?>