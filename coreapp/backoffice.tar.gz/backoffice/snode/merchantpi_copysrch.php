<?php
namespace PHPMaker2020\_4payadmin;

// Autoload
include_once "autoload.php";

// Session
if (session_status() !== PHP_SESSION_ACTIVE)
	\Delight\Cookie\Session::start(Config("COOKIE_SAMESITE")); // Init session data

// Output buffering
ob_start();
?>
<?php

// Write header
WriteHeader(FALSE);

// Create page object
$merchantpi_copy_search = new merchantpi_copy_search();

// Run the page
$merchantpi_copy_search->run();

// Setup login status
SetupLoginStatus();
SetClientVar("login", LoginStatus());

// Global Page Rendering event (in userfn*.php)
Page_Rendering();

// Page Rendering event
$merchantpi_copy_search->Page_Render();
?>
<?php include_once "header.php"; ?>
<script>
var fmerchantpi_copysearch, currentPageID;
loadjs.ready("head", function() {

	// Form object for search
	<?php if ($merchantpi_copy_search->IsModal) { ?>
	fmerchantpi_copysearch = currentAdvancedSearchForm = new ew.Form("fmerchantpi_copysearch", "search");
	<?php } else { ?>
	fmerchantpi_copysearch = currentForm = new ew.Form("fmerchantpi_copysearch", "search");
	<?php } ?>
	currentPageID = ew.PAGE_ID = "search";

	// Validate function for search
	fmerchantpi_copysearch.validate = function(fobj) {
		if (!this.validateRequired)
			return true; // Ignore validation
		fobj = fobj || this._form;
		var infix = "";
		elm = this.getElements("x" + infix + "__userid");
		if (elm && !ew.checkInteger(elm.value))
			return this.onError(elm, "<?php echo JsEncode($merchantpi_copy_search->_userid->errorMessage()) ?>");
		elm = this.getElements("x" + infix + "_piid");
		if (elm && !ew.checkInteger(elm.value))
			return this.onError(elm, "<?php echo JsEncode($merchantpi_copy_search->piid->errorMessage()) ?>");
		elm = this.getElements("x" + infix + "_gatewayid");
		if (elm && !ew.checkInteger(elm.value))
			return this.onError(elm, "<?php echo JsEncode($merchantpi_copy_search->gatewayid->errorMessage()) ?>");
		elm = this.getElements("x" + infix + "_allowed");
		if (elm && !ew.checkInteger(elm.value))
			return this.onError(elm, "<?php echo JsEncode($merchantpi_copy_search->allowed->errorMessage()) ?>");
		elm = this.getElements("x" + infix + "_gatewayprofileid");
		if (elm && !ew.checkInteger(elm.value))
			return this.onError(elm, "<?php echo JsEncode($merchantpi_copy_search->gatewayprofileid->errorMessage()) ?>");

		// Call Form_CustomValidate event
		if (!this.Form_CustomValidate(fobj))
			return false;
		return true;
	}

	// Form_CustomValidate
	fmerchantpi_copysearch.Form_CustomValidate = function(fobj) { // DO NOT CHANGE THIS LINE!

		// Your custom validation code here, return false if invalid.
		return true;
	}

	// Use JavaScript validation or not
	fmerchantpi_copysearch.validateRequired = <?php echo Config("CLIENT_VALIDATE") ? "true" : "false" ?>;

	// Dynamic selection lists
	loadjs.done("fmerchantpi_copysearch");
});
</script>
<script>
loadjs.ready("head", function() {

	// Client script
	// Write your client script here, no need to add script tags.

});
</script>
<?php $merchantpi_copy_search->showPageHeader(); ?>
<?php
$merchantpi_copy_search->showMessage();
?>
<form name="fmerchantpi_copysearch" id="fmerchantpi_copysearch" class="<?php echo $merchantpi_copy_search->FormClassName ?>" action="<?php echo CurrentPageName() ?>" method="post">
<?php if ($Page->CheckToken) { ?>
<input type="hidden" name="<?php echo Config("TOKEN_NAME") ?>" value="<?php echo $Page->Token ?>">
<?php } ?>
<input type="hidden" name="t" value="merchantpi_copy">
<input type="hidden" name="action" id="action" value="search">
<input type="hidden" name="modal" value="<?php echo (int)$merchantpi_copy_search->IsModal ?>">
<div class="ew-search-div"><!-- page* -->
<?php if ($merchantpi_copy_search->_userid->Visible) { // userid ?>
	<div id="r__userid" class="form-group row">
		<label for="x__userid" class="<?php echo $merchantpi_copy_search->LeftColumnClass ?>"><span id="elh_merchantpi_copy__userid"><?php echo $merchantpi_copy_search->_userid->caption() ?></span>
		<span class="ew-search-operator">
<?php echo $Language->phrase("=") ?>
<input type="hidden" name="z__userid" id="z__userid" value="=">
</span>
		</label>
		<div class="<?php echo $merchantpi_copy_search->RightColumnClass ?>"><div <?php echo $merchantpi_copy_search->_userid->cellAttributes() ?>>
			<span id="el_merchantpi_copy__userid" class="ew-search-field">
<input type="text" data-table="merchantpi_copy" data-field="x__userid" name="x__userid" id="x__userid" size="30" maxlength="12" placeholder="<?php echo HtmlEncode($merchantpi_copy_search->_userid->getPlaceHolder()) ?>" value="<?php echo $merchantpi_copy_search->_userid->EditValue ?>"<?php echo $merchantpi_copy_search->_userid->editAttributes() ?>>
</span>
		</div></div>
	</div>
<?php } ?>
<?php if ($merchantpi_copy_search->piid->Visible) { // piid ?>
	<div id="r_piid" class="form-group row">
		<label for="x_piid" class="<?php echo $merchantpi_copy_search->LeftColumnClass ?>"><span id="elh_merchantpi_copy_piid"><?php echo $merchantpi_copy_search->piid->caption() ?></span>
		<span class="ew-search-operator">
<?php echo $Language->phrase("=") ?>
<input type="hidden" name="z_piid" id="z_piid" value="=">
</span>
		</label>
		<div class="<?php echo $merchantpi_copy_search->RightColumnClass ?>"><div <?php echo $merchantpi_copy_search->piid->cellAttributes() ?>>
			<span id="el_merchantpi_copy_piid" class="ew-search-field">
<input type="text" data-table="merchantpi_copy" data-field="x_piid" name="x_piid" id="x_piid" size="30" maxlength="5" placeholder="<?php echo HtmlEncode($merchantpi_copy_search->piid->getPlaceHolder()) ?>" value="<?php echo $merchantpi_copy_search->piid->EditValue ?>"<?php echo $merchantpi_copy_search->piid->editAttributes() ?>>
</span>
		</div></div>
	</div>
<?php } ?>
<?php if ($merchantpi_copy_search->currcode->Visible) { // currcode ?>
	<div id="r_currcode" class="form-group row">
		<label for="x_currcode" class="<?php echo $merchantpi_copy_search->LeftColumnClass ?>"><span id="elh_merchantpi_copy_currcode"><?php echo $merchantpi_copy_search->currcode->caption() ?></span>
		<span class="ew-search-operator">
<?php echo $Language->phrase("LIKE") ?>
<input type="hidden" name="z_currcode" id="z_currcode" value="LIKE">
</span>
		</label>
		<div class="<?php echo $merchantpi_copy_search->RightColumnClass ?>"><div <?php echo $merchantpi_copy_search->currcode->cellAttributes() ?>>
			<span id="el_merchantpi_copy_currcode" class="ew-search-field">
<input type="text" data-table="merchantpi_copy" data-field="x_currcode" name="x_currcode" id="x_currcode" size="30" maxlength="3" placeholder="<?php echo HtmlEncode($merchantpi_copy_search->currcode->getPlaceHolder()) ?>" value="<?php echo $merchantpi_copy_search->currcode->EditValue ?>"<?php echo $merchantpi_copy_search->currcode->editAttributes() ?>>
</span>
		</div></div>
	</div>
<?php } ?>
<?php if ($merchantpi_copy_search->gatewayid->Visible) { // gatewayid ?>
	<div id="r_gatewayid" class="form-group row">
		<label for="x_gatewayid" class="<?php echo $merchantpi_copy_search->LeftColumnClass ?>"><span id="elh_merchantpi_copy_gatewayid"><?php echo $merchantpi_copy_search->gatewayid->caption() ?></span>
		<span class="ew-search-operator">
<?php echo $Language->phrase("=") ?>
<input type="hidden" name="z_gatewayid" id="z_gatewayid" value="=">
</span>
		</label>
		<div class="<?php echo $merchantpi_copy_search->RightColumnClass ?>"><div <?php echo $merchantpi_copy_search->gatewayid->cellAttributes() ?>>
			<span id="el_merchantpi_copy_gatewayid" class="ew-search-field">
<input type="text" data-table="merchantpi_copy" data-field="x_gatewayid" name="x_gatewayid" id="x_gatewayid" size="30" maxlength="5" placeholder="<?php echo HtmlEncode($merchantpi_copy_search->gatewayid->getPlaceHolder()) ?>" value="<?php echo $merchantpi_copy_search->gatewayid->EditValue ?>"<?php echo $merchantpi_copy_search->gatewayid->editAttributes() ?>>
</span>
		</div></div>
	</div>
<?php } ?>
<?php if ($merchantpi_copy_search->allowed->Visible) { // allowed ?>
	<div id="r_allowed" class="form-group row">
		<label for="x_allowed" class="<?php echo $merchantpi_copy_search->LeftColumnClass ?>"><span id="elh_merchantpi_copy_allowed"><?php echo $merchantpi_copy_search->allowed->caption() ?></span>
		<span class="ew-search-operator">
<?php echo $Language->phrase("=") ?>
<input type="hidden" name="z_allowed" id="z_allowed" value="=">
</span>
		</label>
		<div class="<?php echo $merchantpi_copy_search->RightColumnClass ?>"><div <?php echo $merchantpi_copy_search->allowed->cellAttributes() ?>>
			<span id="el_merchantpi_copy_allowed" class="ew-search-field">
<input type="text" data-table="merchantpi_copy" data-field="x_allowed" name="x_allowed" id="x_allowed" size="30" maxlength="1" placeholder="<?php echo HtmlEncode($merchantpi_copy_search->allowed->getPlaceHolder()) ?>" value="<?php echo $merchantpi_copy_search->allowed->EditValue ?>"<?php echo $merchantpi_copy_search->allowed->editAttributes() ?>>
</span>
		</div></div>
	</div>
<?php } ?>
<?php if ($merchantpi_copy_search->gatewayprofileid->Visible) { // gatewayprofileid ?>
	<div id="r_gatewayprofileid" class="form-group row">
		<label for="x_gatewayprofileid" class="<?php echo $merchantpi_copy_search->LeftColumnClass ?>"><span id="elh_merchantpi_copy_gatewayprofileid"><?php echo $merchantpi_copy_search->gatewayprofileid->caption() ?></span>
		<span class="ew-search-operator">
<?php echo $Language->phrase("=") ?>
<input type="hidden" name="z_gatewayprofileid" id="z_gatewayprofileid" value="=">
</span>
		</label>
		<div class="<?php echo $merchantpi_copy_search->RightColumnClass ?>"><div <?php echo $merchantpi_copy_search->gatewayprofileid->cellAttributes() ?>>
			<span id="el_merchantpi_copy_gatewayprofileid" class="ew-search-field">
<input type="text" data-table="merchantpi_copy" data-field="x_gatewayprofileid" name="x_gatewayprofileid" id="x_gatewayprofileid" size="30" maxlength="12" placeholder="<?php echo HtmlEncode($merchantpi_copy_search->gatewayprofileid->getPlaceHolder()) ?>" value="<?php echo $merchantpi_copy_search->gatewayprofileid->EditValue ?>"<?php echo $merchantpi_copy_search->gatewayprofileid->editAttributes() ?>>
</span>
		</div></div>
	</div>
<?php } ?>
<?php if ($merchantpi_copy_search->externalcode->Visible) { // externalcode ?>
	<div id="r_externalcode" class="form-group row">
		<label for="x_externalcode" class="<?php echo $merchantpi_copy_search->LeftColumnClass ?>"><span id="elh_merchantpi_copy_externalcode"><?php echo $merchantpi_copy_search->externalcode->caption() ?></span>
		<span class="ew-search-operator">
<?php echo $Language->phrase("LIKE") ?>
<input type="hidden" name="z_externalcode" id="z_externalcode" value="LIKE">
</span>
		</label>
		<div class="<?php echo $merchantpi_copy_search->RightColumnClass ?>"><div <?php echo $merchantpi_copy_search->externalcode->cellAttributes() ?>>
			<span id="el_merchantpi_copy_externalcode" class="ew-search-field">
<input type="text" data-table="merchantpi_copy" data-field="x_externalcode" name="x_externalcode" id="x_externalcode" size="30" maxlength="20" placeholder="<?php echo HtmlEncode($merchantpi_copy_search->externalcode->getPlaceHolder()) ?>" value="<?php echo $merchantpi_copy_search->externalcode->EditValue ?>"<?php echo $merchantpi_copy_search->externalcode->editAttributes() ?>>
</span>
		</div></div>
	</div>
<?php } ?>
</div><!-- /page* -->
<?php if (!$merchantpi_copy_search->IsModal) { ?>
<div class="form-group row"><!-- buttons .form-group -->
	<div class="<?php echo $merchantpi_copy_search->OffsetColumnClass ?>"><!-- buttons offset -->
<button class="btn btn-primary ew-btn" name="btn-action" id="btn-action" type="submit"><?php echo $Language->phrase("Search") ?></button>
<button class="btn btn-default ew-btn" name="btn-reset" id="btn-reset" type="button" onclick="ew.clearForm(this.form);"><?php echo $Language->phrase("Reset") ?></button>
	</div><!-- /buttons offset -->
</div><!-- /buttons .form-group -->
<?php } ?>
</form>
<?php
$merchantpi_copy_search->showPageFooter();
if (Config("DEBUG"))
	echo GetDebugMessage();
?>
<script>
loadjs.ready("load", function() {

	// Startup script
	// Write your table-specific startup script here
	// console.log("page loaded");

});
</script>
<?php include_once "footer.php"; ?>
<?php
$merchantpi_copy_search->terminate();
?>