<?php
namespace PHPMaker2020\_4payadmin;

// Autoload
include_once "autoload.php";

// Session
if (session_status() !== PHP_SESSION_ACTIVE)
	\Delight\Cookie\Session::start(Config("COOKIE_SAMESITE")); // Init session data

// Output buffering
ob_start();
?>
<?php

// Write header
WriteHeader(FALSE);

// Create page object
$useridpool_delete = new useridpool_delete();

// Run the page
$useridpool_delete->run();

// Setup login status
SetupLoginStatus();
SetClientVar("login", LoginStatus());

// Global Page Rendering event (in userfn*.php)
Page_Rendering();

// Page Rendering event
$useridpool_delete->Page_Render();
?>
<?php include_once "header.php"; ?>
<script>
var fuseridpooldelete, currentPageID;
loadjs.ready("head", function() {

	// Form object
	currentPageID = ew.PAGE_ID = "delete";
	fuseridpooldelete = currentForm = new ew.Form("fuseridpooldelete", "delete");
	loadjs.done("fuseridpooldelete");
});
</script>
<script>
loadjs.ready("head", function() {

	// Client script
	// Write your client script here, no need to add script tags.

});
</script>
<?php $useridpool_delete->showPageHeader(); ?>
<?php
$useridpool_delete->showMessage();
?>
<form name="fuseridpooldelete" id="fuseridpooldelete" class="form-inline ew-form ew-delete-form" action="<?php echo CurrentPageName() ?>" method="post">
<?php if ($Page->CheckToken) { ?>
<input type="hidden" name="<?php echo Config("TOKEN_NAME") ?>" value="<?php echo $Page->Token ?>">
<?php } ?>
<input type="hidden" name="t" value="useridpool">
<input type="hidden" name="action" id="action" value="delete">
<?php foreach ($useridpool_delete->RecKeys as $key) { ?>
<?php $keyvalue = is_array($key) ? implode(Config("COMPOSITE_KEY_SEPARATOR"), $key) : $key; ?>
<input type="hidden" name="key_m[]" value="<?php echo HtmlEncode($keyvalue) ?>">
<?php } ?>
<div class="card ew-card ew-grid">
<div class="<?php echo ResponsiveTableClass() ?>card-body ew-grid-middle-panel">
<table class="table ew-table">
	<thead>
	<tr class="ew-table-header">
<?php if ($useridpool_delete->id->Visible) { // id ?>
		<th class="<?php echo $useridpool_delete->id->headerCellClass() ?>"><span id="elh_useridpool_id" class="useridpool_id"><?php echo $useridpool_delete->id->caption() ?></span></th>
<?php } ?>
<?php if ($useridpool_delete->_userid->Visible) { // userid ?>
		<th class="<?php echo $useridpool_delete->_userid->headerCellClass() ?>"><span id="elh_useridpool__userid" class="useridpool__userid"><?php echo $useridpool_delete->_userid->caption() ?></span></th>
<?php } ?>
<?php if ($useridpool_delete->txcode->Visible) { // txcode ?>
		<th class="<?php echo $useridpool_delete->txcode->headerCellClass() ?>"><span id="elh_useridpool_txcode" class="useridpool_txcode"><?php echo $useridpool_delete->txcode->caption() ?></span></th>
<?php } ?>
<?php if ($useridpool_delete->expirytime->Visible) { // expirytime ?>
		<th class="<?php echo $useridpool_delete->expirytime->headerCellClass() ?>"><span id="elh_useridpool_expirytime" class="useridpool_expirytime"><?php echo $useridpool_delete->expirytime->caption() ?></span></th>
<?php } ?>
	</tr>
	</thead>
	<tbody>
<?php
$useridpool_delete->RecordCount = 0;
$i = 0;
while (!$useridpool_delete->Recordset->EOF) {
	$useridpool_delete->RecordCount++;
	$useridpool_delete->RowCount++;

	// Set row properties
	$useridpool->resetAttributes();
	$useridpool->RowType = ROWTYPE_VIEW; // View

	// Get the field contents
	$useridpool_delete->loadRowValues($useridpool_delete->Recordset);

	// Render row
	$useridpool_delete->renderRow();
?>
	<tr <?php echo $useridpool->rowAttributes() ?>>
<?php if ($useridpool_delete->id->Visible) { // id ?>
		<td <?php echo $useridpool_delete->id->cellAttributes() ?>>
<span id="el<?php echo $useridpool_delete->RowCount ?>_useridpool_id" class="useridpool_id">
<span<?php echo $useridpool_delete->id->viewAttributes() ?>><?php echo $useridpool_delete->id->getViewValue() ?></span>
</span>
</td>
<?php } ?>
<?php if ($useridpool_delete->_userid->Visible) { // userid ?>
		<td <?php echo $useridpool_delete->_userid->cellAttributes() ?>>
<span id="el<?php echo $useridpool_delete->RowCount ?>_useridpool__userid" class="useridpool__userid">
<span<?php echo $useridpool_delete->_userid->viewAttributes() ?>><?php echo $useridpool_delete->_userid->getViewValue() ?></span>
</span>
</td>
<?php } ?>
<?php if ($useridpool_delete->txcode->Visible) { // txcode ?>
		<td <?php echo $useridpool_delete->txcode->cellAttributes() ?>>
<span id="el<?php echo $useridpool_delete->RowCount ?>_useridpool_txcode" class="useridpool_txcode">
<span<?php echo $useridpool_delete->txcode->viewAttributes() ?>><?php echo $useridpool_delete->txcode->getViewValue() ?></span>
</span>
</td>
<?php } ?>
<?php if ($useridpool_delete->expirytime->Visible) { // expirytime ?>
		<td <?php echo $useridpool_delete->expirytime->cellAttributes() ?>>
<span id="el<?php echo $useridpool_delete->RowCount ?>_useridpool_expirytime" class="useridpool_expirytime">
<span<?php echo $useridpool_delete->expirytime->viewAttributes() ?>><?php echo $useridpool_delete->expirytime->getViewValue() ?></span>
</span>
</td>
<?php } ?>
	</tr>
<?php
	$useridpool_delete->Recordset->moveNext();
}
$useridpool_delete->Recordset->close();
?>
</tbody>
</table>
</div>
</div>
<div>
<button class="btn btn-primary ew-btn" name="btn-action" id="btn-action" type="submit"><?php echo $Language->phrase("DeleteBtn") ?></button>
<button class="btn btn-default ew-btn" name="btn-cancel" id="btn-cancel" type="button" data-href="<?php echo $useridpool_delete->getReturnUrl() ?>"><?php echo $Language->phrase("CancelBtn") ?></button>
</div>
</form>
<?php
$useridpool_delete->showPageFooter();
if (Config("DEBUG"))
	echo GetDebugMessage();
?>
<script>
loadjs.ready("load", function() {

	// Startup script
	// Write your table-specific startup script here
	// console.log("page loaded");

});
</script>
<?php include_once "footer.php"; ?>
<?php
$useridpool_delete->terminate();
?>