<?php
namespace PHPMaker2020\_4payadmin;

// Autoload
include_once "autoload.php";

// Session
if (session_status() !== PHP_SESSION_ACTIVE)
	\Delight\Cookie\Session::start(Config("COOKIE_SAMESITE")); // Init session data

// Output buffering
ob_start();
?>
<?php

// Write header
WriteHeader(FALSE, "utf-8");

// Create page object
$loanlatefees_preview = new loanlatefees_preview();

// Run the page
$loanlatefees_preview->run();

// Setup login status
SetupLoginStatus();
SetClientVar("login", LoginStatus());

// Global Page Rendering event (in userfn*.php)
Page_Rendering();

// Page Rendering event
$loanlatefees_preview->Page_Render();
?>
<?php $loanlatefees_preview->showPageHeader(); ?>
<?php if ($loanlatefees_preview->TotalRecords > 0) { ?>
<div class="card ew-grid loanlatefees"><!-- .card -->
<div class="<?php echo ResponsiveTableClass() ?>card-body ew-grid-middle-panel ew-preview-middle-panel"><!-- .table-responsive -->
<table class="table ew-table ew-preview-table"><!-- .table -->
	<thead><!-- Table header -->
		<tr class="ew-table-header">
<?php

// Render list options
$loanlatefees_preview->renderListOptions();

// Render list options (header, left)
$loanlatefees_preview->ListOptions->render("header", "left");
?>
<?php if ($loanlatefees_preview->latefeeid->Visible) { // latefeeid ?>
	<?php if ($loanlatefees->SortUrl($loanlatefees_preview->latefeeid) == "") { ?>
		<th class="<?php echo $loanlatefees_preview->latefeeid->headerCellClass() ?>"><?php echo $loanlatefees_preview->latefeeid->caption() ?></th>
	<?php } else { ?>
		<th class="<?php echo $loanlatefees_preview->latefeeid->headerCellClass() ?>"><div class="ew-pointer" data-sort="<?php echo HtmlEncode($loanlatefees_preview->latefeeid->Name) ?>" data-sort-order="<?php echo $loanlatefees_preview->SortField == $loanlatefees_preview->latefeeid->Name && $loanlatefees_preview->SortOrder == "ASC" ? "DESC" : "ASC" ?>">
			<div class="ew-table-header-btn"><span class="ew-table-header-caption"><?php echo $loanlatefees_preview->latefeeid->caption() ?></span><span class="ew-table-header-sort"><?php if ($loanlatefees_preview->SortField == $loanlatefees_preview->latefeeid->Name) { ?><?php if ($loanlatefees_preview->SortOrder == "ASC") { ?><i class="fas fa-sort-up"></i><?php } elseif ($loanlatefees_preview->SortOrder == "DESC") { ?><i class="fas fa-sort-down"></i><?php } ?><?php } ?></span>
		</div></div></th>
	<?php } ?>
<?php } ?>
<?php if ($loanlatefees_preview->_userid->Visible) { // userid ?>
	<?php if ($loanlatefees->SortUrl($loanlatefees_preview->_userid) == "") { ?>
		<th class="<?php echo $loanlatefees_preview->_userid->headerCellClass() ?>"><?php echo $loanlatefees_preview->_userid->caption() ?></th>
	<?php } else { ?>
		<th class="<?php echo $loanlatefees_preview->_userid->headerCellClass() ?>"><div class="ew-pointer" data-sort="<?php echo HtmlEncode($loanlatefees_preview->_userid->Name) ?>" data-sort-order="<?php echo $loanlatefees_preview->SortField == $loanlatefees_preview->_userid->Name && $loanlatefees_preview->SortOrder == "ASC" ? "DESC" : "ASC" ?>">
			<div class="ew-table-header-btn"><span class="ew-table-header-caption"><?php echo $loanlatefees_preview->_userid->caption() ?></span><span class="ew-table-header-sort"><?php if ($loanlatefees_preview->SortField == $loanlatefees_preview->_userid->Name) { ?><?php if ($loanlatefees_preview->SortOrder == "ASC") { ?><i class="fas fa-sort-up"></i><?php } elseif ($loanlatefees_preview->SortOrder == "DESC") { ?><i class="fas fa-sort-down"></i><?php } ?><?php } ?></span>
		</div></div></th>
	<?php } ?>
<?php } ?>
<?php if ($loanlatefees_preview->transdate->Visible) { // transdate ?>
	<?php if ($loanlatefees->SortUrl($loanlatefees_preview->transdate) == "") { ?>
		<th class="<?php echo $loanlatefees_preview->transdate->headerCellClass() ?>"><?php echo $loanlatefees_preview->transdate->caption() ?></th>
	<?php } else { ?>
		<th class="<?php echo $loanlatefees_preview->transdate->headerCellClass() ?>"><div class="ew-pointer" data-sort="<?php echo HtmlEncode($loanlatefees_preview->transdate->Name) ?>" data-sort-order="<?php echo $loanlatefees_preview->SortField == $loanlatefees_preview->transdate->Name && $loanlatefees_preview->SortOrder == "ASC" ? "DESC" : "ASC" ?>">
			<div class="ew-table-header-btn"><span class="ew-table-header-caption"><?php echo $loanlatefees_preview->transdate->caption() ?></span><span class="ew-table-header-sort"><?php if ($loanlatefees_preview->SortField == $loanlatefees_preview->transdate->Name) { ?><?php if ($loanlatefees_preview->SortOrder == "ASC") { ?><i class="fas fa-sort-up"></i><?php } elseif ($loanlatefees_preview->SortOrder == "DESC") { ?><i class="fas fa-sort-down"></i><?php } ?><?php } ?></span>
		</div></div></th>
	<?php } ?>
<?php } ?>
<?php if ($loanlatefees_preview->currcode->Visible) { // currcode ?>
	<?php if ($loanlatefees->SortUrl($loanlatefees_preview->currcode) == "") { ?>
		<th class="<?php echo $loanlatefees_preview->currcode->headerCellClass() ?>"><?php echo $loanlatefees_preview->currcode->caption() ?></th>
	<?php } else { ?>
		<th class="<?php echo $loanlatefees_preview->currcode->headerCellClass() ?>"><div class="ew-pointer" data-sort="<?php echo HtmlEncode($loanlatefees_preview->currcode->Name) ?>" data-sort-order="<?php echo $loanlatefees_preview->SortField == $loanlatefees_preview->currcode->Name && $loanlatefees_preview->SortOrder == "ASC" ? "DESC" : "ASC" ?>">
			<div class="ew-table-header-btn"><span class="ew-table-header-caption"><?php echo $loanlatefees_preview->currcode->caption() ?></span><span class="ew-table-header-sort"><?php if ($loanlatefees_preview->SortField == $loanlatefees_preview->currcode->Name) { ?><?php if ($loanlatefees_preview->SortOrder == "ASC") { ?><i class="fas fa-sort-up"></i><?php } elseif ($loanlatefees_preview->SortOrder == "DESC") { ?><i class="fas fa-sort-down"></i><?php } ?><?php } ?></span>
		</div></div></th>
	<?php } ?>
<?php } ?>
<?php if ($loanlatefees_preview->outstandingamount->Visible) { // outstandingamount ?>
	<?php if ($loanlatefees->SortUrl($loanlatefees_preview->outstandingamount) == "") { ?>
		<th class="<?php echo $loanlatefees_preview->outstandingamount->headerCellClass() ?>"><?php echo $loanlatefees_preview->outstandingamount->caption() ?></th>
	<?php } else { ?>
		<th class="<?php echo $loanlatefees_preview->outstandingamount->headerCellClass() ?>"><div class="ew-pointer" data-sort="<?php echo HtmlEncode($loanlatefees_preview->outstandingamount->Name) ?>" data-sort-order="<?php echo $loanlatefees_preview->SortField == $loanlatefees_preview->outstandingamount->Name && $loanlatefees_preview->SortOrder == "ASC" ? "DESC" : "ASC" ?>">
			<div class="ew-table-header-btn"><span class="ew-table-header-caption"><?php echo $loanlatefees_preview->outstandingamount->caption() ?></span><span class="ew-table-header-sort"><?php if ($loanlatefees_preview->SortField == $loanlatefees_preview->outstandingamount->Name) { ?><?php if ($loanlatefees_preview->SortOrder == "ASC") { ?><i class="fas fa-sort-up"></i><?php } elseif ($loanlatefees_preview->SortOrder == "DESC") { ?><i class="fas fa-sort-down"></i><?php } ?><?php } ?></span>
		</div></div></th>
	<?php } ?>
<?php } ?>
<?php if ($loanlatefees_preview->latefee->Visible) { // latefee ?>
	<?php if ($loanlatefees->SortUrl($loanlatefees_preview->latefee) == "") { ?>
		<th class="<?php echo $loanlatefees_preview->latefee->headerCellClass() ?>"><?php echo $loanlatefees_preview->latefee->caption() ?></th>
	<?php } else { ?>
		<th class="<?php echo $loanlatefees_preview->latefee->headerCellClass() ?>"><div class="ew-pointer" data-sort="<?php echo HtmlEncode($loanlatefees_preview->latefee->Name) ?>" data-sort-order="<?php echo $loanlatefees_preview->SortField == $loanlatefees_preview->latefee->Name && $loanlatefees_preview->SortOrder == "ASC" ? "DESC" : "ASC" ?>">
			<div class="ew-table-header-btn"><span class="ew-table-header-caption"><?php echo $loanlatefees_preview->latefee->caption() ?></span><span class="ew-table-header-sort"><?php if ($loanlatefees_preview->SortField == $loanlatefees_preview->latefee->Name) { ?><?php if ($loanlatefees_preview->SortOrder == "ASC") { ?><i class="fas fa-sort-up"></i><?php } elseif ($loanlatefees_preview->SortOrder == "DESC") { ?><i class="fas fa-sort-down"></i><?php } ?><?php } ?></span>
		</div></div></th>
	<?php } ?>
<?php } ?>
<?php if ($loanlatefees_preview->paidamount->Visible) { // paidamount ?>
	<?php if ($loanlatefees->SortUrl($loanlatefees_preview->paidamount) == "") { ?>
		<th class="<?php echo $loanlatefees_preview->paidamount->headerCellClass() ?>"><?php echo $loanlatefees_preview->paidamount->caption() ?></th>
	<?php } else { ?>
		<th class="<?php echo $loanlatefees_preview->paidamount->headerCellClass() ?>"><div class="ew-pointer" data-sort="<?php echo HtmlEncode($loanlatefees_preview->paidamount->Name) ?>" data-sort-order="<?php echo $loanlatefees_preview->SortField == $loanlatefees_preview->paidamount->Name && $loanlatefees_preview->SortOrder == "ASC" ? "DESC" : "ASC" ?>">
			<div class="ew-table-header-btn"><span class="ew-table-header-caption"><?php echo $loanlatefees_preview->paidamount->caption() ?></span><span class="ew-table-header-sort"><?php if ($loanlatefees_preview->SortField == $loanlatefees_preview->paidamount->Name) { ?><?php if ($loanlatefees_preview->SortOrder == "ASC") { ?><i class="fas fa-sort-up"></i><?php } elseif ($loanlatefees_preview->SortOrder == "DESC") { ?><i class="fas fa-sort-down"></i><?php } ?><?php } ?></span>
		</div></div></th>
	<?php } ?>
<?php } ?>
<?php if ($loanlatefees_preview->fullypaid->Visible) { // fullypaid ?>
	<?php if ($loanlatefees->SortUrl($loanlatefees_preview->fullypaid) == "") { ?>
		<th class="<?php echo $loanlatefees_preview->fullypaid->headerCellClass() ?>"><?php echo $loanlatefees_preview->fullypaid->caption() ?></th>
	<?php } else { ?>
		<th class="<?php echo $loanlatefees_preview->fullypaid->headerCellClass() ?>"><div class="ew-pointer" data-sort="<?php echo HtmlEncode($loanlatefees_preview->fullypaid->Name) ?>" data-sort-order="<?php echo $loanlatefees_preview->SortField == $loanlatefees_preview->fullypaid->Name && $loanlatefees_preview->SortOrder == "ASC" ? "DESC" : "ASC" ?>">
			<div class="ew-table-header-btn"><span class="ew-table-header-caption"><?php echo $loanlatefees_preview->fullypaid->caption() ?></span><span class="ew-table-header-sort"><?php if ($loanlatefees_preview->SortField == $loanlatefees_preview->fullypaid->Name) { ?><?php if ($loanlatefees_preview->SortOrder == "ASC") { ?><i class="fas fa-sort-up"></i><?php } elseif ($loanlatefees_preview->SortOrder == "DESC") { ?><i class="fas fa-sort-down"></i><?php } ?><?php } ?></span>
		</div></div></th>
	<?php } ?>
<?php } ?>
<?php

// Render list options (header, right)
$loanlatefees_preview->ListOptions->render("header", "right");
?>
		</tr>
	</thead>
	<tbody><!-- Table body -->
<?php
$loanlatefees_preview->RecCount = 0;
$loanlatefees_preview->RowCount = 0;
while ($loanlatefees_preview->Recordset && !$loanlatefees_preview->Recordset->EOF) {

	// Init row class and style
	$loanlatefees_preview->RecCount++;
	$loanlatefees_preview->RowCount++;
	$loanlatefees_preview->CssStyle = "";
	$loanlatefees_preview->loadListRowValues($loanlatefees_preview->Recordset);

	// Render row
	$loanlatefees->RowType = ROWTYPE_PREVIEW; // Preview record
	$loanlatefees_preview->resetAttributes();
	$loanlatefees_preview->renderListRow();

	// Render list options
	$loanlatefees_preview->renderListOptions();
?>
	<tr <?php echo $loanlatefees->rowAttributes() ?>>
<?php

// Render list options (body, left)
$loanlatefees_preview->ListOptions->render("body", "left", $loanlatefees_preview->RowCount);
?>
<?php if ($loanlatefees_preview->latefeeid->Visible) { // latefeeid ?>
		<!-- latefeeid -->
		<td<?php echo $loanlatefees_preview->latefeeid->cellAttributes() ?>>
<span<?php echo $loanlatefees_preview->latefeeid->viewAttributes() ?>><?php echo $loanlatefees_preview->latefeeid->getViewValue() ?></span>
</td>
<?php } ?>
<?php if ($loanlatefees_preview->_userid->Visible) { // userid ?>
		<!-- userid -->
		<td<?php echo $loanlatefees_preview->_userid->cellAttributes() ?>>
<span<?php echo $loanlatefees_preview->_userid->viewAttributes() ?>><?php if (!EmptyString($loanlatefees_preview->_userid->getViewValue()) && $loanlatefees_preview->_userid->linkAttributes() != "") { ?>
<a<?php echo $loanlatefees_preview->_userid->linkAttributes() ?>><?php echo $loanlatefees_preview->_userid->getViewValue() ?></a>
<?php } else { ?>
<?php echo $loanlatefees_preview->_userid->getViewValue() ?>
<?php } ?></span>
</td>
<?php } ?>
<?php if ($loanlatefees_preview->transdate->Visible) { // transdate ?>
		<!-- transdate -->
		<td<?php echo $loanlatefees_preview->transdate->cellAttributes() ?>>
<span<?php echo $loanlatefees_preview->transdate->viewAttributes() ?>><?php echo $loanlatefees_preview->transdate->getViewValue() ?></span>
</td>
<?php } ?>
<?php if ($loanlatefees_preview->currcode->Visible) { // currcode ?>
		<!-- currcode -->
		<td<?php echo $loanlatefees_preview->currcode->cellAttributes() ?>>
<span<?php echo $loanlatefees_preview->currcode->viewAttributes() ?>><?php echo $loanlatefees_preview->currcode->getViewValue() ?></span>
</td>
<?php } ?>
<?php if ($loanlatefees_preview->outstandingamount->Visible) { // outstandingamount ?>
		<!-- outstandingamount -->
		<td<?php echo $loanlatefees_preview->outstandingamount->cellAttributes() ?>>
<span<?php echo $loanlatefees_preview->outstandingamount->viewAttributes() ?>><?php echo $loanlatefees_preview->outstandingamount->getViewValue() ?></span>
</td>
<?php } ?>
<?php if ($loanlatefees_preview->latefee->Visible) { // latefee ?>
		<!-- latefee -->
		<td<?php echo $loanlatefees_preview->latefee->cellAttributes() ?>>
<span<?php echo $loanlatefees_preview->latefee->viewAttributes() ?>><?php echo $loanlatefees_preview->latefee->getViewValue() ?></span>
</td>
<?php } ?>
<?php if ($loanlatefees_preview->paidamount->Visible) { // paidamount ?>
		<!-- paidamount -->
		<td<?php echo $loanlatefees_preview->paidamount->cellAttributes() ?>>
<span<?php echo $loanlatefees_preview->paidamount->viewAttributes() ?>><?php echo $loanlatefees_preview->paidamount->getViewValue() ?></span>
</td>
<?php } ?>
<?php if ($loanlatefees_preview->fullypaid->Visible) { // fullypaid ?>
		<!-- fullypaid -->
		<td<?php echo $loanlatefees_preview->fullypaid->cellAttributes() ?>>
<span<?php echo $loanlatefees_preview->fullypaid->viewAttributes() ?>><?php echo $loanlatefees_preview->fullypaid->getViewValue() ?></span>
</td>
<?php } ?>
<?php

// Render list options (body, right)
$loanlatefees_preview->ListOptions->render("body", "right", $loanlatefees_preview->RowCount);
?>
	</tr>
<?php
	$loanlatefees_preview->Recordset->MoveNext();
} // while
?>
	</tbody>
</table><!-- /.table -->
</div><!-- /.table-responsive -->
<div class="card-footer ew-grid-lower-panel ew-preview-lower-panel"><!-- .card-footer -->
<?php echo $loanlatefees_preview->Pager->render() ?>
<?php } else { // No record ?>
<div class="card no-border">
<div class="ew-detail-count"><?php echo $Language->phrase("NoRecord") ?></div>
<?php } ?>
<div class="ew-preview-other-options">
<?php
	foreach ($loanlatefees_preview->OtherOptions as $option)
		$option->render("body");
?>
</div>
<?php if ($loanlatefees_preview->TotalRecords > 0) { ?>
<div class="clearfix"></div>
</div><!-- /.card-footer -->
<?php } ?>
</div><!-- /.card -->
<?php
$loanlatefees_preview->showPageFooter();
if (Config("DEBUG"))
	echo GetDebugMessage();
?>
<?php
if ($loanlatefees_preview->Recordset)
	$loanlatefees_preview->Recordset->Close();

// Output
$content = ob_get_contents();
ob_end_clean();
echo ConvertToUtf8($content);
?>
<?php
$loanlatefees_preview->terminate();
?>