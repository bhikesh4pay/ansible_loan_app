<?php
namespace PHPMaker2020\_4payadmin;

// Autoload
include_once "autoload.php";

// Session
if (session_status() !== PHP_SESSION_ACTIVE)
	\Delight\Cookie\Session::start(Config("COOKIE_SAMESITE")); // Init session data

// Output buffering
ob_start();
?>
<?php

// Write header
WriteHeader(FALSE);

// Create page object
$merchantmemberplan_add = new merchantmemberplan_add();

// Run the page
$merchantmemberplan_add->run();

// Setup login status
SetupLoginStatus();
SetClientVar("login", LoginStatus());

// Global Page Rendering event (in userfn*.php)
Page_Rendering();

// Page Rendering event
$merchantmemberplan_add->Page_Render();
?>
<?php include_once "header.php"; ?>
<script>
var fmerchantmemberplanadd, currentPageID;
loadjs.ready("head", function() {

	// Form object
	currentPageID = ew.PAGE_ID = "add";
	fmerchantmemberplanadd = currentForm = new ew.Form("fmerchantmemberplanadd", "add");

	// Validate form
	fmerchantmemberplanadd.validate = function() {
		if (!this.validateRequired)
			return true; // Ignore validation
		var $ = jQuery, fobj = this.getForm(), $fobj = $(fobj);
		if ($fobj.find("#confirm").val() == "confirm")
			return true;
		var elm, felm, uelm, addcnt = 0;
		var $k = $fobj.find("#" + this.formKeyCountName); // Get key_count
		var rowcnt = ($k[0]) ? parseInt($k.val(), 10) : 1;
		var startcnt = (rowcnt == 0) ? 0 : 1; // Check rowcnt == 0 => Inline-Add
		var gridinsert = ["insert", "gridinsert"].includes($fobj.find("#action").val()) && $k[0];
		for (var i = startcnt; i <= rowcnt; i++) {
			var infix = ($k[0]) ? String(i) : "";
			$fobj.data("rowindex", infix);
			<?php if ($merchantmemberplan_add->merchantid->Required) { ?>
				elm = this.getElements("x" + infix + "_merchantid");
				if (elm && !ew.isHidden(elm) && !ew.hasValue(elm))
					return this.onError(elm, "<?php echo JsEncode(str_replace("%s", $merchantmemberplan_add->merchantid->caption(), $merchantmemberplan_add->merchantid->RequiredErrorMessage)) ?>");
			<?php } ?>
				elm = this.getElements("x" + infix + "_merchantid");
				if (elm && !ew.checkInteger(elm.value))
					return this.onError(elm, "<?php echo JsEncode($merchantmemberplan_add->merchantid->errorMessage()) ?>");
			<?php if ($merchantmemberplan_add->memberid->Required) { ?>
				elm = this.getElements("x" + infix + "_memberid");
				if (elm && !ew.isHidden(elm) && !ew.hasValue(elm))
					return this.onError(elm, "<?php echo JsEncode(str_replace("%s", $merchantmemberplan_add->memberid->caption(), $merchantmemberplan_add->memberid->RequiredErrorMessage)) ?>");
			<?php } ?>
				elm = this.getElements("x" + infix + "_memberid");
				if (elm && !ew.checkInteger(elm.value))
					return this.onError(elm, "<?php echo JsEncode($merchantmemberplan_add->memberid->errorMessage()) ?>");
			<?php if ($merchantmemberplan_add->planid->Required) { ?>
				elm = this.getElements("x" + infix + "_planid");
				if (elm && !ew.isHidden(elm) && !ew.hasValue(elm))
					return this.onError(elm, "<?php echo JsEncode(str_replace("%s", $merchantmemberplan_add->planid->caption(), $merchantmemberplan_add->planid->RequiredErrorMessage)) ?>");
			<?php } ?>
				elm = this.getElements("x" + infix + "_planid");
				if (elm && !ew.checkInteger(elm.value))
					return this.onError(elm, "<?php echo JsEncode($merchantmemberplan_add->planid->errorMessage()) ?>");
			<?php if ($merchantmemberplan_add->registrationdate->Required) { ?>
				elm = this.getElements("x" + infix + "_registrationdate");
				if (elm && !ew.isHidden(elm) && !ew.hasValue(elm))
					return this.onError(elm, "<?php echo JsEncode(str_replace("%s", $merchantmemberplan_add->registrationdate->caption(), $merchantmemberplan_add->registrationdate->RequiredErrorMessage)) ?>");
			<?php } ?>
				elm = this.getElements("x" + infix + "_registrationdate");
				if (elm && !ew.checkDateDef(elm.value))
					return this.onError(elm, "<?php echo JsEncode($merchantmemberplan_add->registrationdate->errorMessage()) ?>");
			<?php if ($merchantmemberplan_add->paymentdate->Required) { ?>
				elm = this.getElements("x" + infix + "_paymentdate");
				if (elm && !ew.isHidden(elm) && !ew.hasValue(elm))
					return this.onError(elm, "<?php echo JsEncode(str_replace("%s", $merchantmemberplan_add->paymentdate->caption(), $merchantmemberplan_add->paymentdate->RequiredErrorMessage)) ?>");
			<?php } ?>
				elm = this.getElements("x" + infix + "_paymentdate");
				if (elm && !ew.checkDateDef(elm.value))
					return this.onError(elm, "<?php echo JsEncode($merchantmemberplan_add->paymentdate->errorMessage()) ?>");
			<?php if ($merchantmemberplan_add->effectivedate->Required) { ?>
				elm = this.getElements("x" + infix + "_effectivedate");
				if (elm && !ew.isHidden(elm) && !ew.hasValue(elm))
					return this.onError(elm, "<?php echo JsEncode(str_replace("%s", $merchantmemberplan_add->effectivedate->caption(), $merchantmemberplan_add->effectivedate->RequiredErrorMessage)) ?>");
			<?php } ?>
				elm = this.getElements("x" + infix + "_effectivedate");
				if (elm && !ew.checkDateDef(elm.value))
					return this.onError(elm, "<?php echo JsEncode($merchantmemberplan_add->effectivedate->errorMessage()) ?>");
			<?php if ($merchantmemberplan_add->willexpire->Required) { ?>
				elm = this.getElements("x" + infix + "_willexpire");
				if (elm && !ew.isHidden(elm) && !ew.hasValue(elm))
					return this.onError(elm, "<?php echo JsEncode(str_replace("%s", $merchantmemberplan_add->willexpire->caption(), $merchantmemberplan_add->willexpire->RequiredErrorMessage)) ?>");
			<?php } ?>
				elm = this.getElements("x" + infix + "_willexpire");
				if (elm && !ew.checkInteger(elm.value))
					return this.onError(elm, "<?php echo JsEncode($merchantmemberplan_add->willexpire->errorMessage()) ?>");
			<?php if ($merchantmemberplan_add->expirydate->Required) { ?>
				elm = this.getElements("x" + infix + "_expirydate");
				if (elm && !ew.isHidden(elm) && !ew.hasValue(elm))
					return this.onError(elm, "<?php echo JsEncode(str_replace("%s", $merchantmemberplan_add->expirydate->caption(), $merchantmemberplan_add->expirydate->RequiredErrorMessage)) ?>");
			<?php } ?>
				elm = this.getElements("x" + infix + "_expirydate");
				if (elm && !ew.checkDateDef(elm.value))
					return this.onError(elm, "<?php echo JsEncode($merchantmemberplan_add->expirydate->errorMessage()) ?>");
			<?php if ($merchantmemberplan_add->renewalrequired->Required) { ?>
				elm = this.getElements("x" + infix + "_renewalrequired");
				if (elm && !ew.isHidden(elm) && !ew.hasValue(elm))
					return this.onError(elm, "<?php echo JsEncode(str_replace("%s", $merchantmemberplan_add->renewalrequired->caption(), $merchantmemberplan_add->renewalrequired->RequiredErrorMessage)) ?>");
			<?php } ?>
				elm = this.getElements("x" + infix + "_renewalrequired");
				if (elm && !ew.checkInteger(elm.value))
					return this.onError(elm, "<?php echo JsEncode($merchantmemberplan_add->renewalrequired->errorMessage()) ?>");
			<?php if ($merchantmemberplan_add->planidforrenewal->Required) { ?>
				elm = this.getElements("x" + infix + "_planidforrenewal");
				if (elm && !ew.isHidden(elm) && !ew.hasValue(elm))
					return this.onError(elm, "<?php echo JsEncode(str_replace("%s", $merchantmemberplan_add->planidforrenewal->caption(), $merchantmemberplan_add->planidforrenewal->RequiredErrorMessage)) ?>");
			<?php } ?>
				elm = this.getElements("x" + infix + "_planidforrenewal");
				if (elm && !ew.checkInteger(elm.value))
					return this.onError(elm, "<?php echo JsEncode($merchantmemberplan_add->planidforrenewal->errorMessage()) ?>");
			<?php if ($merchantmemberplan_add->planstatus->Required) { ?>
				elm = this.getElements("x" + infix + "_planstatus");
				if (elm && !ew.isHidden(elm) && !ew.hasValue(elm))
					return this.onError(elm, "<?php echo JsEncode(str_replace("%s", $merchantmemberplan_add->planstatus->caption(), $merchantmemberplan_add->planstatus->RequiredErrorMessage)) ?>");
			<?php } ?>
				elm = this.getElements("x" + infix + "_planstatus");
				if (elm && !ew.checkInteger(elm.value))
					return this.onError(elm, "<?php echo JsEncode($merchantmemberplan_add->planstatus->errorMessage()) ?>");
			<?php if ($merchantmemberplan_add->planstatusdate->Required) { ?>
				elm = this.getElements("x" + infix + "_planstatusdate");
				if (elm && !ew.isHidden(elm) && !ew.hasValue(elm))
					return this.onError(elm, "<?php echo JsEncode(str_replace("%s", $merchantmemberplan_add->planstatusdate->caption(), $merchantmemberplan_add->planstatusdate->RequiredErrorMessage)) ?>");
			<?php } ?>
				elm = this.getElements("x" + infix + "_planstatusdate");
				if (elm && !ew.checkDateDef(elm.value))
					return this.onError(elm, "<?php echo JsEncode($merchantmemberplan_add->planstatusdate->errorMessage()) ?>");
			<?php if ($merchantmemberplan_add->approvalstatus->Required) { ?>
				elm = this.getElements("x" + infix + "_approvalstatus");
				if (elm && !ew.isHidden(elm) && !ew.hasValue(elm))
					return this.onError(elm, "<?php echo JsEncode(str_replace("%s", $merchantmemberplan_add->approvalstatus->caption(), $merchantmemberplan_add->approvalstatus->RequiredErrorMessage)) ?>");
			<?php } ?>
				elm = this.getElements("x" + infix + "_approvalstatus");
				if (elm && !ew.checkInteger(elm.value))
					return this.onError(elm, "<?php echo JsEncode($merchantmemberplan_add->approvalstatus->errorMessage()) ?>");
			<?php if ($merchantmemberplan_add->approvaldatetime->Required) { ?>
				elm = this.getElements("x" + infix + "_approvaldatetime");
				if (elm && !ew.isHidden(elm) && !ew.hasValue(elm))
					return this.onError(elm, "<?php echo JsEncode(str_replace("%s", $merchantmemberplan_add->approvaldatetime->caption(), $merchantmemberplan_add->approvaldatetime->RequiredErrorMessage)) ?>");
			<?php } ?>
				elm = this.getElements("x" + infix + "_approvaldatetime");
				if (elm && !ew.checkDateDef(elm.value))
					return this.onError(elm, "<?php echo JsEncode($merchantmemberplan_add->approvaldatetime->errorMessage()) ?>");
			<?php if ($merchantmemberplan_add->approvalby->Required) { ?>
				elm = this.getElements("x" + infix + "_approvalby");
				if (elm && !ew.isHidden(elm) && !ew.hasValue(elm))
					return this.onError(elm, "<?php echo JsEncode(str_replace("%s", $merchantmemberplan_add->approvalby->caption(), $merchantmemberplan_add->approvalby->RequiredErrorMessage)) ?>");
			<?php } ?>
				elm = this.getElements("x" + infix + "_approvalby");
				if (elm && !ew.checkInteger(elm.value))
					return this.onError(elm, "<?php echo JsEncode($merchantmemberplan_add->approvalby->errorMessage()) ?>");
			<?php if ($merchantmemberplan_add->preauthorizedmemberpi->Required) { ?>
				elm = this.getElements("x" + infix + "_preauthorizedmemberpi");
				if (elm && !ew.isHidden(elm) && !ew.hasValue(elm))
					return this.onError(elm, "<?php echo JsEncode(str_replace("%s", $merchantmemberplan_add->preauthorizedmemberpi->caption(), $merchantmemberplan_add->preauthorizedmemberpi->RequiredErrorMessage)) ?>");
			<?php } ?>
				elm = this.getElements("x" + infix + "_preauthorizedmemberpi");
				if (elm && !ew.checkInteger(elm.value))
					return this.onError(elm, "<?php echo JsEncode($merchantmemberplan_add->preauthorizedmemberpi->errorMessage()) ?>");
			<?php if ($merchantmemberplan_add->pendingpayment->Required) { ?>
				elm = this.getElements("x" + infix + "_pendingpayment");
				if (elm && !ew.isHidden(elm) && !ew.hasValue(elm))
					return this.onError(elm, "<?php echo JsEncode(str_replace("%s", $merchantmemberplan_add->pendingpayment->caption(), $merchantmemberplan_add->pendingpayment->RequiredErrorMessage)) ?>");
			<?php } ?>
				elm = this.getElements("x" + infix + "_pendingpayment");
				if (elm && !ew.checkInteger(elm.value))
					return this.onError(elm, "<?php echo JsEncode($merchantmemberplan_add->pendingpayment->errorMessage()) ?>");
			<?php if ($merchantmemberplan_add->lastinvoiceid->Required) { ?>
				elm = this.getElements("x" + infix + "_lastinvoiceid");
				if (elm && !ew.isHidden(elm) && !ew.hasValue(elm))
					return this.onError(elm, "<?php echo JsEncode(str_replace("%s", $merchantmemberplan_add->lastinvoiceid->caption(), $merchantmemberplan_add->lastinvoiceid->RequiredErrorMessage)) ?>");
			<?php } ?>
				elm = this.getElements("x" + infix + "_lastinvoiceid");
				if (elm && !ew.checkInteger(elm.value))
					return this.onError(elm, "<?php echo JsEncode($merchantmemberplan_add->lastinvoiceid->errorMessage()) ?>");
			<?php if ($merchantmemberplan_add->lastupdatedate->Required) { ?>
				elm = this.getElements("x" + infix + "_lastupdatedate");
				if (elm && !ew.isHidden(elm) && !ew.hasValue(elm))
					return this.onError(elm, "<?php echo JsEncode(str_replace("%s", $merchantmemberplan_add->lastupdatedate->caption(), $merchantmemberplan_add->lastupdatedate->RequiredErrorMessage)) ?>");
			<?php } ?>
				elm = this.getElements("x" + infix + "_lastupdatedate");
				if (elm && !ew.checkDateDef(elm.value))
					return this.onError(elm, "<?php echo JsEncode($merchantmemberplan_add->lastupdatedate->errorMessage()) ?>");
			<?php if ($merchantmemberplan_add->pendingpaymentid->Required) { ?>
				elm = this.getElements("x" + infix + "_pendingpaymentid");
				if (elm && !ew.isHidden(elm) && !ew.hasValue(elm))
					return this.onError(elm, "<?php echo JsEncode(str_replace("%s", $merchantmemberplan_add->pendingpaymentid->caption(), $merchantmemberplan_add->pendingpaymentid->RequiredErrorMessage)) ?>");
			<?php } ?>
				elm = this.getElements("x" + infix + "_pendingpaymentid");
				if (elm && !ew.checkInteger(elm.value))
					return this.onError(elm, "<?php echo JsEncode($merchantmemberplan_add->pendingpaymentid->errorMessage()) ?>");
			<?php if ($merchantmemberplan_add->notes->Required) { ?>
				elm = this.getElements("x" + infix + "_notes");
				if (elm && !ew.isHidden(elm) && !ew.hasValue(elm))
					return this.onError(elm, "<?php echo JsEncode(str_replace("%s", $merchantmemberplan_add->notes->caption(), $merchantmemberplan_add->notes->RequiredErrorMessage)) ?>");
			<?php } ?>
			<?php if ($merchantmemberplan_add->field1->Required) { ?>
				elm = this.getElements("x" + infix + "_field1");
				if (elm && !ew.isHidden(elm) && !ew.hasValue(elm))
					return this.onError(elm, "<?php echo JsEncode(str_replace("%s", $merchantmemberplan_add->field1->caption(), $merchantmemberplan_add->field1->RequiredErrorMessage)) ?>");
			<?php } ?>
			<?php if ($merchantmemberplan_add->field2->Required) { ?>
				elm = this.getElements("x" + infix + "_field2");
				if (elm && !ew.isHidden(elm) && !ew.hasValue(elm))
					return this.onError(elm, "<?php echo JsEncode(str_replace("%s", $merchantmemberplan_add->field2->caption(), $merchantmemberplan_add->field2->RequiredErrorMessage)) ?>");
			<?php } ?>
			<?php if ($merchantmemberplan_add->field3->Required) { ?>
				elm = this.getElements("x" + infix + "_field3");
				if (elm && !ew.isHidden(elm) && !ew.hasValue(elm))
					return this.onError(elm, "<?php echo JsEncode(str_replace("%s", $merchantmemberplan_add->field3->caption(), $merchantmemberplan_add->field3->RequiredErrorMessage)) ?>");
			<?php } ?>
			<?php if ($merchantmemberplan_add->field4->Required) { ?>
				elm = this.getElements("x" + infix + "_field4");
				if (elm && !ew.isHidden(elm) && !ew.hasValue(elm))
					return this.onError(elm, "<?php echo JsEncode(str_replace("%s", $merchantmemberplan_add->field4->caption(), $merchantmemberplan_add->field4->RequiredErrorMessage)) ?>");
			<?php } ?>
			<?php if ($merchantmemberplan_add->field5->Required) { ?>
				elm = this.getElements("x" + infix + "_field5");
				if (elm && !ew.isHidden(elm) && !ew.hasValue(elm))
					return this.onError(elm, "<?php echo JsEncode(str_replace("%s", $merchantmemberplan_add->field5->caption(), $merchantmemberplan_add->field5->RequiredErrorMessage)) ?>");
			<?php } ?>
			<?php if ($merchantmemberplan_add->field6->Required) { ?>
				elm = this.getElements("x" + infix + "_field6");
				if (elm && !ew.isHidden(elm) && !ew.hasValue(elm))
					return this.onError(elm, "<?php echo JsEncode(str_replace("%s", $merchantmemberplan_add->field6->caption(), $merchantmemberplan_add->field6->RequiredErrorMessage)) ?>");
			<?php } ?>
			<?php if ($merchantmemberplan_add->field7->Required) { ?>
				elm = this.getElements("x" + infix + "_field7");
				if (elm && !ew.isHidden(elm) && !ew.hasValue(elm))
					return this.onError(elm, "<?php echo JsEncode(str_replace("%s", $merchantmemberplan_add->field7->caption(), $merchantmemberplan_add->field7->RequiredErrorMessage)) ?>");
			<?php } ?>
			<?php if ($merchantmemberplan_add->field8->Required) { ?>
				elm = this.getElements("x" + infix + "_field8");
				if (elm && !ew.isHidden(elm) && !ew.hasValue(elm))
					return this.onError(elm, "<?php echo JsEncode(str_replace("%s", $merchantmemberplan_add->field8->caption(), $merchantmemberplan_add->field8->RequiredErrorMessage)) ?>");
			<?php } ?>
			<?php if ($merchantmemberplan_add->field9->Required) { ?>
				elm = this.getElements("x" + infix + "_field9");
				if (elm && !ew.isHidden(elm) && !ew.hasValue(elm))
					return this.onError(elm, "<?php echo JsEncode(str_replace("%s", $merchantmemberplan_add->field9->caption(), $merchantmemberplan_add->field9->RequiredErrorMessage)) ?>");
			<?php } ?>
			<?php if ($merchantmemberplan_add->field10->Required) { ?>
				elm = this.getElements("x" + infix + "_field10");
				if (elm && !ew.isHidden(elm) && !ew.hasValue(elm))
					return this.onError(elm, "<?php echo JsEncode(str_replace("%s", $merchantmemberplan_add->field10->caption(), $merchantmemberplan_add->field10->RequiredErrorMessage)) ?>");
			<?php } ?>

				// Call Form_CustomValidate event
				if (!this.Form_CustomValidate(fobj))
					return false;
		}

		// Process detail forms
		var dfs = $fobj.find("input[name='detailpage']").get();
		for (var i = 0; i < dfs.length; i++) {
			var df = dfs[i], val = df.value;
			if (val && ew.forms[val])
				if (!ew.forms[val].validate())
					return false;
		}
		return true;
	}

	// Form_CustomValidate
	fmerchantmemberplanadd.Form_CustomValidate = function(fobj) { // DO NOT CHANGE THIS LINE!

		// Your custom validation code here, return false if invalid.
		return true;
	}

	// Use JavaScript validation or not
	fmerchantmemberplanadd.validateRequired = <?php echo Config("CLIENT_VALIDATE") ? "true" : "false" ?>;

	// Dynamic selection lists
	loadjs.done("fmerchantmemberplanadd");
});
</script>
<script>
loadjs.ready("head", function() {

	// Client script
	// Write your client script here, no need to add script tags.

});
</script>
<?php $merchantmemberplan_add->showPageHeader(); ?>
<?php
$merchantmemberplan_add->showMessage();
?>
<form name="fmerchantmemberplanadd" id="fmerchantmemberplanadd" class="<?php echo $merchantmemberplan_add->FormClassName ?>" action="<?php echo CurrentPageName() ?>" method="post">
<?php if ($Page->CheckToken) { ?>
<input type="hidden" name="<?php echo Config("TOKEN_NAME") ?>" value="<?php echo $Page->Token ?>">
<?php } ?>
<input type="hidden" name="t" value="merchantmemberplan">
<input type="hidden" name="action" id="action" value="insert">
<input type="hidden" name="modal" value="<?php echo (int)$merchantmemberplan_add->IsModal ?>">
<div class="ew-add-div"><!-- page* -->
<?php if ($merchantmemberplan_add->merchantid->Visible) { // merchantid ?>
	<div id="r_merchantid" class="form-group row">
		<label id="elh_merchantmemberplan_merchantid" for="x_merchantid" class="<?php echo $merchantmemberplan_add->LeftColumnClass ?>"><?php echo $merchantmemberplan_add->merchantid->caption() ?><?php echo $merchantmemberplan_add->merchantid->Required ? $Language->phrase("FieldRequiredIndicator") : "" ?></label>
		<div class="<?php echo $merchantmemberplan_add->RightColumnClass ?>"><div <?php echo $merchantmemberplan_add->merchantid->cellAttributes() ?>>
<span id="el_merchantmemberplan_merchantid">
<input type="text" data-table="merchantmemberplan" data-field="x_merchantid" name="x_merchantid" id="x_merchantid" size="30" placeholder="<?php echo HtmlEncode($merchantmemberplan_add->merchantid->getPlaceHolder()) ?>" value="<?php echo $merchantmemberplan_add->merchantid->EditValue ?>"<?php echo $merchantmemberplan_add->merchantid->editAttributes() ?>>
</span>
<?php echo $merchantmemberplan_add->merchantid->CustomMsg ?></div></div>
	</div>
<?php } ?>
<?php if ($merchantmemberplan_add->memberid->Visible) { // memberid ?>
	<div id="r_memberid" class="form-group row">
		<label id="elh_merchantmemberplan_memberid" for="x_memberid" class="<?php echo $merchantmemberplan_add->LeftColumnClass ?>"><?php echo $merchantmemberplan_add->memberid->caption() ?><?php echo $merchantmemberplan_add->memberid->Required ? $Language->phrase("FieldRequiredIndicator") : "" ?></label>
		<div class="<?php echo $merchantmemberplan_add->RightColumnClass ?>"><div <?php echo $merchantmemberplan_add->memberid->cellAttributes() ?>>
<span id="el_merchantmemberplan_memberid">
<input type="text" data-table="merchantmemberplan" data-field="x_memberid" name="x_memberid" id="x_memberid" size="30" placeholder="<?php echo HtmlEncode($merchantmemberplan_add->memberid->getPlaceHolder()) ?>" value="<?php echo $merchantmemberplan_add->memberid->EditValue ?>"<?php echo $merchantmemberplan_add->memberid->editAttributes() ?>>
</span>
<?php echo $merchantmemberplan_add->memberid->CustomMsg ?></div></div>
	</div>
<?php } ?>
<?php if ($merchantmemberplan_add->planid->Visible) { // planid ?>
	<div id="r_planid" class="form-group row">
		<label id="elh_merchantmemberplan_planid" for="x_planid" class="<?php echo $merchantmemberplan_add->LeftColumnClass ?>"><?php echo $merchantmemberplan_add->planid->caption() ?><?php echo $merchantmemberplan_add->planid->Required ? $Language->phrase("FieldRequiredIndicator") : "" ?></label>
		<div class="<?php echo $merchantmemberplan_add->RightColumnClass ?>"><div <?php echo $merchantmemberplan_add->planid->cellAttributes() ?>>
<span id="el_merchantmemberplan_planid">
<input type="text" data-table="merchantmemberplan" data-field="x_planid" name="x_planid" id="x_planid" size="30" placeholder="<?php echo HtmlEncode($merchantmemberplan_add->planid->getPlaceHolder()) ?>" value="<?php echo $merchantmemberplan_add->planid->EditValue ?>"<?php echo $merchantmemberplan_add->planid->editAttributes() ?>>
</span>
<?php echo $merchantmemberplan_add->planid->CustomMsg ?></div></div>
	</div>
<?php } ?>
<?php if ($merchantmemberplan_add->registrationdate->Visible) { // registrationdate ?>
	<div id="r_registrationdate" class="form-group row">
		<label id="elh_merchantmemberplan_registrationdate" for="x_registrationdate" class="<?php echo $merchantmemberplan_add->LeftColumnClass ?>"><?php echo $merchantmemberplan_add->registrationdate->caption() ?><?php echo $merchantmemberplan_add->registrationdate->Required ? $Language->phrase("FieldRequiredIndicator") : "" ?></label>
		<div class="<?php echo $merchantmemberplan_add->RightColumnClass ?>"><div <?php echo $merchantmemberplan_add->registrationdate->cellAttributes() ?>>
<span id="el_merchantmemberplan_registrationdate">
<input type="text" data-table="merchantmemberplan" data-field="x_registrationdate" name="x_registrationdate" id="x_registrationdate" placeholder="<?php echo HtmlEncode($merchantmemberplan_add->registrationdate->getPlaceHolder()) ?>" value="<?php echo $merchantmemberplan_add->registrationdate->EditValue ?>"<?php echo $merchantmemberplan_add->registrationdate->editAttributes() ?>>
</span>
<?php echo $merchantmemberplan_add->registrationdate->CustomMsg ?></div></div>
	</div>
<?php } ?>
<?php if ($merchantmemberplan_add->paymentdate->Visible) { // paymentdate ?>
	<div id="r_paymentdate" class="form-group row">
		<label id="elh_merchantmemberplan_paymentdate" for="x_paymentdate" class="<?php echo $merchantmemberplan_add->LeftColumnClass ?>"><?php echo $merchantmemberplan_add->paymentdate->caption() ?><?php echo $merchantmemberplan_add->paymentdate->Required ? $Language->phrase("FieldRequiredIndicator") : "" ?></label>
		<div class="<?php echo $merchantmemberplan_add->RightColumnClass ?>"><div <?php echo $merchantmemberplan_add->paymentdate->cellAttributes() ?>>
<span id="el_merchantmemberplan_paymentdate">
<input type="text" data-table="merchantmemberplan" data-field="x_paymentdate" name="x_paymentdate" id="x_paymentdate" placeholder="<?php echo HtmlEncode($merchantmemberplan_add->paymentdate->getPlaceHolder()) ?>" value="<?php echo $merchantmemberplan_add->paymentdate->EditValue ?>"<?php echo $merchantmemberplan_add->paymentdate->editAttributes() ?>>
</span>
<?php echo $merchantmemberplan_add->paymentdate->CustomMsg ?></div></div>
	</div>
<?php } ?>
<?php if ($merchantmemberplan_add->effectivedate->Visible) { // effectivedate ?>
	<div id="r_effectivedate" class="form-group row">
		<label id="elh_merchantmemberplan_effectivedate" for="x_effectivedate" class="<?php echo $merchantmemberplan_add->LeftColumnClass ?>"><?php echo $merchantmemberplan_add->effectivedate->caption() ?><?php echo $merchantmemberplan_add->effectivedate->Required ? $Language->phrase("FieldRequiredIndicator") : "" ?></label>
		<div class="<?php echo $merchantmemberplan_add->RightColumnClass ?>"><div <?php echo $merchantmemberplan_add->effectivedate->cellAttributes() ?>>
<span id="el_merchantmemberplan_effectivedate">
<input type="text" data-table="merchantmemberplan" data-field="x_effectivedate" name="x_effectivedate" id="x_effectivedate" placeholder="<?php echo HtmlEncode($merchantmemberplan_add->effectivedate->getPlaceHolder()) ?>" value="<?php echo $merchantmemberplan_add->effectivedate->EditValue ?>"<?php echo $merchantmemberplan_add->effectivedate->editAttributes() ?>>
</span>
<?php echo $merchantmemberplan_add->effectivedate->CustomMsg ?></div></div>
	</div>
<?php } ?>
<?php if ($merchantmemberplan_add->willexpire->Visible) { // willexpire ?>
	<div id="r_willexpire" class="form-group row">
		<label id="elh_merchantmemberplan_willexpire" for="x_willexpire" class="<?php echo $merchantmemberplan_add->LeftColumnClass ?>"><?php echo $merchantmemberplan_add->willexpire->caption() ?><?php echo $merchantmemberplan_add->willexpire->Required ? $Language->phrase("FieldRequiredIndicator") : "" ?></label>
		<div class="<?php echo $merchantmemberplan_add->RightColumnClass ?>"><div <?php echo $merchantmemberplan_add->willexpire->cellAttributes() ?>>
<span id="el_merchantmemberplan_willexpire">
<input type="text" data-table="merchantmemberplan" data-field="x_willexpire" name="x_willexpire" id="x_willexpire" size="30" placeholder="<?php echo HtmlEncode($merchantmemberplan_add->willexpire->getPlaceHolder()) ?>" value="<?php echo $merchantmemberplan_add->willexpire->EditValue ?>"<?php echo $merchantmemberplan_add->willexpire->editAttributes() ?>>
</span>
<?php echo $merchantmemberplan_add->willexpire->CustomMsg ?></div></div>
	</div>
<?php } ?>
<?php if ($merchantmemberplan_add->expirydate->Visible) { // expirydate ?>
	<div id="r_expirydate" class="form-group row">
		<label id="elh_merchantmemberplan_expirydate" for="x_expirydate" class="<?php echo $merchantmemberplan_add->LeftColumnClass ?>"><?php echo $merchantmemberplan_add->expirydate->caption() ?><?php echo $merchantmemberplan_add->expirydate->Required ? $Language->phrase("FieldRequiredIndicator") : "" ?></label>
		<div class="<?php echo $merchantmemberplan_add->RightColumnClass ?>"><div <?php echo $merchantmemberplan_add->expirydate->cellAttributes() ?>>
<span id="el_merchantmemberplan_expirydate">
<input type="text" data-table="merchantmemberplan" data-field="x_expirydate" name="x_expirydate" id="x_expirydate" placeholder="<?php echo HtmlEncode($merchantmemberplan_add->expirydate->getPlaceHolder()) ?>" value="<?php echo $merchantmemberplan_add->expirydate->EditValue ?>"<?php echo $merchantmemberplan_add->expirydate->editAttributes() ?>>
</span>
<?php echo $merchantmemberplan_add->expirydate->CustomMsg ?></div></div>
	</div>
<?php } ?>
<?php if ($merchantmemberplan_add->renewalrequired->Visible) { // renewalrequired ?>
	<div id="r_renewalrequired" class="form-group row">
		<label id="elh_merchantmemberplan_renewalrequired" for="x_renewalrequired" class="<?php echo $merchantmemberplan_add->LeftColumnClass ?>"><?php echo $merchantmemberplan_add->renewalrequired->caption() ?><?php echo $merchantmemberplan_add->renewalrequired->Required ? $Language->phrase("FieldRequiredIndicator") : "" ?></label>
		<div class="<?php echo $merchantmemberplan_add->RightColumnClass ?>"><div <?php echo $merchantmemberplan_add->renewalrequired->cellAttributes() ?>>
<span id="el_merchantmemberplan_renewalrequired">
<input type="text" data-table="merchantmemberplan" data-field="x_renewalrequired" name="x_renewalrequired" id="x_renewalrequired" size="30" placeholder="<?php echo HtmlEncode($merchantmemberplan_add->renewalrequired->getPlaceHolder()) ?>" value="<?php echo $merchantmemberplan_add->renewalrequired->EditValue ?>"<?php echo $merchantmemberplan_add->renewalrequired->editAttributes() ?>>
</span>
<?php echo $merchantmemberplan_add->renewalrequired->CustomMsg ?></div></div>
	</div>
<?php } ?>
<?php if ($merchantmemberplan_add->planidforrenewal->Visible) { // planidforrenewal ?>
	<div id="r_planidforrenewal" class="form-group row">
		<label id="elh_merchantmemberplan_planidforrenewal" for="x_planidforrenewal" class="<?php echo $merchantmemberplan_add->LeftColumnClass ?>"><?php echo $merchantmemberplan_add->planidforrenewal->caption() ?><?php echo $merchantmemberplan_add->planidforrenewal->Required ? $Language->phrase("FieldRequiredIndicator") : "" ?></label>
		<div class="<?php echo $merchantmemberplan_add->RightColumnClass ?>"><div <?php echo $merchantmemberplan_add->planidforrenewal->cellAttributes() ?>>
<span id="el_merchantmemberplan_planidforrenewal">
<input type="text" data-table="merchantmemberplan" data-field="x_planidforrenewal" name="x_planidforrenewal" id="x_planidforrenewal" size="30" placeholder="<?php echo HtmlEncode($merchantmemberplan_add->planidforrenewal->getPlaceHolder()) ?>" value="<?php echo $merchantmemberplan_add->planidforrenewal->EditValue ?>"<?php echo $merchantmemberplan_add->planidforrenewal->editAttributes() ?>>
</span>
<?php echo $merchantmemberplan_add->planidforrenewal->CustomMsg ?></div></div>
	</div>
<?php } ?>
<?php if ($merchantmemberplan_add->planstatus->Visible) { // planstatus ?>
	<div id="r_planstatus" class="form-group row">
		<label id="elh_merchantmemberplan_planstatus" for="x_planstatus" class="<?php echo $merchantmemberplan_add->LeftColumnClass ?>"><?php echo $merchantmemberplan_add->planstatus->caption() ?><?php echo $merchantmemberplan_add->planstatus->Required ? $Language->phrase("FieldRequiredIndicator") : "" ?></label>
		<div class="<?php echo $merchantmemberplan_add->RightColumnClass ?>"><div <?php echo $merchantmemberplan_add->planstatus->cellAttributes() ?>>
<span id="el_merchantmemberplan_planstatus">
<input type="text" data-table="merchantmemberplan" data-field="x_planstatus" name="x_planstatus" id="x_planstatus" size="30" placeholder="<?php echo HtmlEncode($merchantmemberplan_add->planstatus->getPlaceHolder()) ?>" value="<?php echo $merchantmemberplan_add->planstatus->EditValue ?>"<?php echo $merchantmemberplan_add->planstatus->editAttributes() ?>>
</span>
<?php echo $merchantmemberplan_add->planstatus->CustomMsg ?></div></div>
	</div>
<?php } ?>
<?php if ($merchantmemberplan_add->planstatusdate->Visible) { // planstatusdate ?>
	<div id="r_planstatusdate" class="form-group row">
		<label id="elh_merchantmemberplan_planstatusdate" for="x_planstatusdate" class="<?php echo $merchantmemberplan_add->LeftColumnClass ?>"><?php echo $merchantmemberplan_add->planstatusdate->caption() ?><?php echo $merchantmemberplan_add->planstatusdate->Required ? $Language->phrase("FieldRequiredIndicator") : "" ?></label>
		<div class="<?php echo $merchantmemberplan_add->RightColumnClass ?>"><div <?php echo $merchantmemberplan_add->planstatusdate->cellAttributes() ?>>
<span id="el_merchantmemberplan_planstatusdate">
<input type="text" data-table="merchantmemberplan" data-field="x_planstatusdate" name="x_planstatusdate" id="x_planstatusdate" placeholder="<?php echo HtmlEncode($merchantmemberplan_add->planstatusdate->getPlaceHolder()) ?>" value="<?php echo $merchantmemberplan_add->planstatusdate->EditValue ?>"<?php echo $merchantmemberplan_add->planstatusdate->editAttributes() ?>>
</span>
<?php echo $merchantmemberplan_add->planstatusdate->CustomMsg ?></div></div>
	</div>
<?php } ?>
<?php if ($merchantmemberplan_add->approvalstatus->Visible) { // approvalstatus ?>
	<div id="r_approvalstatus" class="form-group row">
		<label id="elh_merchantmemberplan_approvalstatus" for="x_approvalstatus" class="<?php echo $merchantmemberplan_add->LeftColumnClass ?>"><?php echo $merchantmemberplan_add->approvalstatus->caption() ?><?php echo $merchantmemberplan_add->approvalstatus->Required ? $Language->phrase("FieldRequiredIndicator") : "" ?></label>
		<div class="<?php echo $merchantmemberplan_add->RightColumnClass ?>"><div <?php echo $merchantmemberplan_add->approvalstatus->cellAttributes() ?>>
<span id="el_merchantmemberplan_approvalstatus">
<input type="text" data-table="merchantmemberplan" data-field="x_approvalstatus" name="x_approvalstatus" id="x_approvalstatus" size="30" placeholder="<?php echo HtmlEncode($merchantmemberplan_add->approvalstatus->getPlaceHolder()) ?>" value="<?php echo $merchantmemberplan_add->approvalstatus->EditValue ?>"<?php echo $merchantmemberplan_add->approvalstatus->editAttributes() ?>>
</span>
<?php echo $merchantmemberplan_add->approvalstatus->CustomMsg ?></div></div>
	</div>
<?php } ?>
<?php if ($merchantmemberplan_add->approvaldatetime->Visible) { // approvaldatetime ?>
	<div id="r_approvaldatetime" class="form-group row">
		<label id="elh_merchantmemberplan_approvaldatetime" for="x_approvaldatetime" class="<?php echo $merchantmemberplan_add->LeftColumnClass ?>"><?php echo $merchantmemberplan_add->approvaldatetime->caption() ?><?php echo $merchantmemberplan_add->approvaldatetime->Required ? $Language->phrase("FieldRequiredIndicator") : "" ?></label>
		<div class="<?php echo $merchantmemberplan_add->RightColumnClass ?>"><div <?php echo $merchantmemberplan_add->approvaldatetime->cellAttributes() ?>>
<span id="el_merchantmemberplan_approvaldatetime">
<input type="text" data-table="merchantmemberplan" data-field="x_approvaldatetime" name="x_approvaldatetime" id="x_approvaldatetime" placeholder="<?php echo HtmlEncode($merchantmemberplan_add->approvaldatetime->getPlaceHolder()) ?>" value="<?php echo $merchantmemberplan_add->approvaldatetime->EditValue ?>"<?php echo $merchantmemberplan_add->approvaldatetime->editAttributes() ?>>
</span>
<?php echo $merchantmemberplan_add->approvaldatetime->CustomMsg ?></div></div>
	</div>
<?php } ?>
<?php if ($merchantmemberplan_add->approvalby->Visible) { // approvalby ?>
	<div id="r_approvalby" class="form-group row">
		<label id="elh_merchantmemberplan_approvalby" for="x_approvalby" class="<?php echo $merchantmemberplan_add->LeftColumnClass ?>"><?php echo $merchantmemberplan_add->approvalby->caption() ?><?php echo $merchantmemberplan_add->approvalby->Required ? $Language->phrase("FieldRequiredIndicator") : "" ?></label>
		<div class="<?php echo $merchantmemberplan_add->RightColumnClass ?>"><div <?php echo $merchantmemberplan_add->approvalby->cellAttributes() ?>>
<span id="el_merchantmemberplan_approvalby">
<input type="text" data-table="merchantmemberplan" data-field="x_approvalby" name="x_approvalby" id="x_approvalby" size="30" placeholder="<?php echo HtmlEncode($merchantmemberplan_add->approvalby->getPlaceHolder()) ?>" value="<?php echo $merchantmemberplan_add->approvalby->EditValue ?>"<?php echo $merchantmemberplan_add->approvalby->editAttributes() ?>>
</span>
<?php echo $merchantmemberplan_add->approvalby->CustomMsg ?></div></div>
	</div>
<?php } ?>
<?php if ($merchantmemberplan_add->preauthorizedmemberpi->Visible) { // preauthorizedmemberpi ?>
	<div id="r_preauthorizedmemberpi" class="form-group row">
		<label id="elh_merchantmemberplan_preauthorizedmemberpi" for="x_preauthorizedmemberpi" class="<?php echo $merchantmemberplan_add->LeftColumnClass ?>"><?php echo $merchantmemberplan_add->preauthorizedmemberpi->caption() ?><?php echo $merchantmemberplan_add->preauthorizedmemberpi->Required ? $Language->phrase("FieldRequiredIndicator") : "" ?></label>
		<div class="<?php echo $merchantmemberplan_add->RightColumnClass ?>"><div <?php echo $merchantmemberplan_add->preauthorizedmemberpi->cellAttributes() ?>>
<span id="el_merchantmemberplan_preauthorizedmemberpi">
<input type="text" data-table="merchantmemberplan" data-field="x_preauthorizedmemberpi" name="x_preauthorizedmemberpi" id="x_preauthorizedmemberpi" size="30" placeholder="<?php echo HtmlEncode($merchantmemberplan_add->preauthorizedmemberpi->getPlaceHolder()) ?>" value="<?php echo $merchantmemberplan_add->preauthorizedmemberpi->EditValue ?>"<?php echo $merchantmemberplan_add->preauthorizedmemberpi->editAttributes() ?>>
</span>
<?php echo $merchantmemberplan_add->preauthorizedmemberpi->CustomMsg ?></div></div>
	</div>
<?php } ?>
<?php if ($merchantmemberplan_add->pendingpayment->Visible) { // pendingpayment ?>
	<div id="r_pendingpayment" class="form-group row">
		<label id="elh_merchantmemberplan_pendingpayment" for="x_pendingpayment" class="<?php echo $merchantmemberplan_add->LeftColumnClass ?>"><?php echo $merchantmemberplan_add->pendingpayment->caption() ?><?php echo $merchantmemberplan_add->pendingpayment->Required ? $Language->phrase("FieldRequiredIndicator") : "" ?></label>
		<div class="<?php echo $merchantmemberplan_add->RightColumnClass ?>"><div <?php echo $merchantmemberplan_add->pendingpayment->cellAttributes() ?>>
<span id="el_merchantmemberplan_pendingpayment">
<input type="text" data-table="merchantmemberplan" data-field="x_pendingpayment" name="x_pendingpayment" id="x_pendingpayment" size="30" placeholder="<?php echo HtmlEncode($merchantmemberplan_add->pendingpayment->getPlaceHolder()) ?>" value="<?php echo $merchantmemberplan_add->pendingpayment->EditValue ?>"<?php echo $merchantmemberplan_add->pendingpayment->editAttributes() ?>>
</span>
<?php echo $merchantmemberplan_add->pendingpayment->CustomMsg ?></div></div>
	</div>
<?php } ?>
<?php if ($merchantmemberplan_add->lastinvoiceid->Visible) { // lastinvoiceid ?>
	<div id="r_lastinvoiceid" class="form-group row">
		<label id="elh_merchantmemberplan_lastinvoiceid" for="x_lastinvoiceid" class="<?php echo $merchantmemberplan_add->LeftColumnClass ?>"><?php echo $merchantmemberplan_add->lastinvoiceid->caption() ?><?php echo $merchantmemberplan_add->lastinvoiceid->Required ? $Language->phrase("FieldRequiredIndicator") : "" ?></label>
		<div class="<?php echo $merchantmemberplan_add->RightColumnClass ?>"><div <?php echo $merchantmemberplan_add->lastinvoiceid->cellAttributes() ?>>
<span id="el_merchantmemberplan_lastinvoiceid">
<input type="text" data-table="merchantmemberplan" data-field="x_lastinvoiceid" name="x_lastinvoiceid" id="x_lastinvoiceid" size="30" placeholder="<?php echo HtmlEncode($merchantmemberplan_add->lastinvoiceid->getPlaceHolder()) ?>" value="<?php echo $merchantmemberplan_add->lastinvoiceid->EditValue ?>"<?php echo $merchantmemberplan_add->lastinvoiceid->editAttributes() ?>>
</span>
<?php echo $merchantmemberplan_add->lastinvoiceid->CustomMsg ?></div></div>
	</div>
<?php } ?>
<?php if ($merchantmemberplan_add->lastupdatedate->Visible) { // lastupdatedate ?>
	<div id="r_lastupdatedate" class="form-group row">
		<label id="elh_merchantmemberplan_lastupdatedate" for="x_lastupdatedate" class="<?php echo $merchantmemberplan_add->LeftColumnClass ?>"><?php echo $merchantmemberplan_add->lastupdatedate->caption() ?><?php echo $merchantmemberplan_add->lastupdatedate->Required ? $Language->phrase("FieldRequiredIndicator") : "" ?></label>
		<div class="<?php echo $merchantmemberplan_add->RightColumnClass ?>"><div <?php echo $merchantmemberplan_add->lastupdatedate->cellAttributes() ?>>
<span id="el_merchantmemberplan_lastupdatedate">
<input type="text" data-table="merchantmemberplan" data-field="x_lastupdatedate" name="x_lastupdatedate" id="x_lastupdatedate" placeholder="<?php echo HtmlEncode($merchantmemberplan_add->lastupdatedate->getPlaceHolder()) ?>" value="<?php echo $merchantmemberplan_add->lastupdatedate->EditValue ?>"<?php echo $merchantmemberplan_add->lastupdatedate->editAttributes() ?>>
</span>
<?php echo $merchantmemberplan_add->lastupdatedate->CustomMsg ?></div></div>
	</div>
<?php } ?>
<?php if ($merchantmemberplan_add->pendingpaymentid->Visible) { // pendingpaymentid ?>
	<div id="r_pendingpaymentid" class="form-group row">
		<label id="elh_merchantmemberplan_pendingpaymentid" for="x_pendingpaymentid" class="<?php echo $merchantmemberplan_add->LeftColumnClass ?>"><?php echo $merchantmemberplan_add->pendingpaymentid->caption() ?><?php echo $merchantmemberplan_add->pendingpaymentid->Required ? $Language->phrase("FieldRequiredIndicator") : "" ?></label>
		<div class="<?php echo $merchantmemberplan_add->RightColumnClass ?>"><div <?php echo $merchantmemberplan_add->pendingpaymentid->cellAttributes() ?>>
<span id="el_merchantmemberplan_pendingpaymentid">
<input type="text" data-table="merchantmemberplan" data-field="x_pendingpaymentid" name="x_pendingpaymentid" id="x_pendingpaymentid" size="30" placeholder="<?php echo HtmlEncode($merchantmemberplan_add->pendingpaymentid->getPlaceHolder()) ?>" value="<?php echo $merchantmemberplan_add->pendingpaymentid->EditValue ?>"<?php echo $merchantmemberplan_add->pendingpaymentid->editAttributes() ?>>
</span>
<?php echo $merchantmemberplan_add->pendingpaymentid->CustomMsg ?></div></div>
	</div>
<?php } ?>
<?php if ($merchantmemberplan_add->notes->Visible) { // notes ?>
	<div id="r_notes" class="form-group row">
		<label id="elh_merchantmemberplan_notes" for="x_notes" class="<?php echo $merchantmemberplan_add->LeftColumnClass ?>"><?php echo $merchantmemberplan_add->notes->caption() ?><?php echo $merchantmemberplan_add->notes->Required ? $Language->phrase("FieldRequiredIndicator") : "" ?></label>
		<div class="<?php echo $merchantmemberplan_add->RightColumnClass ?>"><div <?php echo $merchantmemberplan_add->notes->cellAttributes() ?>>
<span id="el_merchantmemberplan_notes">
<textarea data-table="merchantmemberplan" data-field="x_notes" name="x_notes" id="x_notes" cols="35" rows="4" placeholder="<?php echo HtmlEncode($merchantmemberplan_add->notes->getPlaceHolder()) ?>"<?php echo $merchantmemberplan_add->notes->editAttributes() ?>><?php echo $merchantmemberplan_add->notes->EditValue ?></textarea>
</span>
<?php echo $merchantmemberplan_add->notes->CustomMsg ?></div></div>
	</div>
<?php } ?>
<?php if ($merchantmemberplan_add->field1->Visible) { // field1 ?>
	<div id="r_field1" class="form-group row">
		<label id="elh_merchantmemberplan_field1" for="x_field1" class="<?php echo $merchantmemberplan_add->LeftColumnClass ?>"><?php echo $merchantmemberplan_add->field1->caption() ?><?php echo $merchantmemberplan_add->field1->Required ? $Language->phrase("FieldRequiredIndicator") : "" ?></label>
		<div class="<?php echo $merchantmemberplan_add->RightColumnClass ?>"><div <?php echo $merchantmemberplan_add->field1->cellAttributes() ?>>
<span id="el_merchantmemberplan_field1">
<input type="text" data-table="merchantmemberplan" data-field="x_field1" name="x_field1" id="x_field1" size="30" maxlength="100" placeholder="<?php echo HtmlEncode($merchantmemberplan_add->field1->getPlaceHolder()) ?>" value="<?php echo $merchantmemberplan_add->field1->EditValue ?>"<?php echo $merchantmemberplan_add->field1->editAttributes() ?>>
</span>
<?php echo $merchantmemberplan_add->field1->CustomMsg ?></div></div>
	</div>
<?php } ?>
<?php if ($merchantmemberplan_add->field2->Visible) { // field2 ?>
	<div id="r_field2" class="form-group row">
		<label id="elh_merchantmemberplan_field2" for="x_field2" class="<?php echo $merchantmemberplan_add->LeftColumnClass ?>"><?php echo $merchantmemberplan_add->field2->caption() ?><?php echo $merchantmemberplan_add->field2->Required ? $Language->phrase("FieldRequiredIndicator") : "" ?></label>
		<div class="<?php echo $merchantmemberplan_add->RightColumnClass ?>"><div <?php echo $merchantmemberplan_add->field2->cellAttributes() ?>>
<span id="el_merchantmemberplan_field2">
<input type="text" data-table="merchantmemberplan" data-field="x_field2" name="x_field2" id="x_field2" size="30" maxlength="100" placeholder="<?php echo HtmlEncode($merchantmemberplan_add->field2->getPlaceHolder()) ?>" value="<?php echo $merchantmemberplan_add->field2->EditValue ?>"<?php echo $merchantmemberplan_add->field2->editAttributes() ?>>
</span>
<?php echo $merchantmemberplan_add->field2->CustomMsg ?></div></div>
	</div>
<?php } ?>
<?php if ($merchantmemberplan_add->field3->Visible) { // field3 ?>
	<div id="r_field3" class="form-group row">
		<label id="elh_merchantmemberplan_field3" for="x_field3" class="<?php echo $merchantmemberplan_add->LeftColumnClass ?>"><?php echo $merchantmemberplan_add->field3->caption() ?><?php echo $merchantmemberplan_add->field3->Required ? $Language->phrase("FieldRequiredIndicator") : "" ?></label>
		<div class="<?php echo $merchantmemberplan_add->RightColumnClass ?>"><div <?php echo $merchantmemberplan_add->field3->cellAttributes() ?>>
<span id="el_merchantmemberplan_field3">
<input type="text" data-table="merchantmemberplan" data-field="x_field3" name="x_field3" id="x_field3" size="30" maxlength="100" placeholder="<?php echo HtmlEncode($merchantmemberplan_add->field3->getPlaceHolder()) ?>" value="<?php echo $merchantmemberplan_add->field3->EditValue ?>"<?php echo $merchantmemberplan_add->field3->editAttributes() ?>>
</span>
<?php echo $merchantmemberplan_add->field3->CustomMsg ?></div></div>
	</div>
<?php } ?>
<?php if ($merchantmemberplan_add->field4->Visible) { // field4 ?>
	<div id="r_field4" class="form-group row">
		<label id="elh_merchantmemberplan_field4" for="x_field4" class="<?php echo $merchantmemberplan_add->LeftColumnClass ?>"><?php echo $merchantmemberplan_add->field4->caption() ?><?php echo $merchantmemberplan_add->field4->Required ? $Language->phrase("FieldRequiredIndicator") : "" ?></label>
		<div class="<?php echo $merchantmemberplan_add->RightColumnClass ?>"><div <?php echo $merchantmemberplan_add->field4->cellAttributes() ?>>
<span id="el_merchantmemberplan_field4">
<input type="text" data-table="merchantmemberplan" data-field="x_field4" name="x_field4" id="x_field4" size="30" maxlength="100" placeholder="<?php echo HtmlEncode($merchantmemberplan_add->field4->getPlaceHolder()) ?>" value="<?php echo $merchantmemberplan_add->field4->EditValue ?>"<?php echo $merchantmemberplan_add->field4->editAttributes() ?>>
</span>
<?php echo $merchantmemberplan_add->field4->CustomMsg ?></div></div>
	</div>
<?php } ?>
<?php if ($merchantmemberplan_add->field5->Visible) { // field5 ?>
	<div id="r_field5" class="form-group row">
		<label id="elh_merchantmemberplan_field5" for="x_field5" class="<?php echo $merchantmemberplan_add->LeftColumnClass ?>"><?php echo $merchantmemberplan_add->field5->caption() ?><?php echo $merchantmemberplan_add->field5->Required ? $Language->phrase("FieldRequiredIndicator") : "" ?></label>
		<div class="<?php echo $merchantmemberplan_add->RightColumnClass ?>"><div <?php echo $merchantmemberplan_add->field5->cellAttributes() ?>>
<span id="el_merchantmemberplan_field5">
<input type="text" data-table="merchantmemberplan" data-field="x_field5" name="x_field5" id="x_field5" size="30" maxlength="100" placeholder="<?php echo HtmlEncode($merchantmemberplan_add->field5->getPlaceHolder()) ?>" value="<?php echo $merchantmemberplan_add->field5->EditValue ?>"<?php echo $merchantmemberplan_add->field5->editAttributes() ?>>
</span>
<?php echo $merchantmemberplan_add->field5->CustomMsg ?></div></div>
	</div>
<?php } ?>
<?php if ($merchantmemberplan_add->field6->Visible) { // field6 ?>
	<div id="r_field6" class="form-group row">
		<label id="elh_merchantmemberplan_field6" for="x_field6" class="<?php echo $merchantmemberplan_add->LeftColumnClass ?>"><?php echo $merchantmemberplan_add->field6->caption() ?><?php echo $merchantmemberplan_add->field6->Required ? $Language->phrase("FieldRequiredIndicator") : "" ?></label>
		<div class="<?php echo $merchantmemberplan_add->RightColumnClass ?>"><div <?php echo $merchantmemberplan_add->field6->cellAttributes() ?>>
<span id="el_merchantmemberplan_field6">
<input type="text" data-table="merchantmemberplan" data-field="x_field6" name="x_field6" id="x_field6" size="30" maxlength="100" placeholder="<?php echo HtmlEncode($merchantmemberplan_add->field6->getPlaceHolder()) ?>" value="<?php echo $merchantmemberplan_add->field6->EditValue ?>"<?php echo $merchantmemberplan_add->field6->editAttributes() ?>>
</span>
<?php echo $merchantmemberplan_add->field6->CustomMsg ?></div></div>
	</div>
<?php } ?>
<?php if ($merchantmemberplan_add->field7->Visible) { // field7 ?>
	<div id="r_field7" class="form-group row">
		<label id="elh_merchantmemberplan_field7" for="x_field7" class="<?php echo $merchantmemberplan_add->LeftColumnClass ?>"><?php echo $merchantmemberplan_add->field7->caption() ?><?php echo $merchantmemberplan_add->field7->Required ? $Language->phrase("FieldRequiredIndicator") : "" ?></label>
		<div class="<?php echo $merchantmemberplan_add->RightColumnClass ?>"><div <?php echo $merchantmemberplan_add->field7->cellAttributes() ?>>
<span id="el_merchantmemberplan_field7">
<input type="text" data-table="merchantmemberplan" data-field="x_field7" name="x_field7" id="x_field7" size="30" maxlength="100" placeholder="<?php echo HtmlEncode($merchantmemberplan_add->field7->getPlaceHolder()) ?>" value="<?php echo $merchantmemberplan_add->field7->EditValue ?>"<?php echo $merchantmemberplan_add->field7->editAttributes() ?>>
</span>
<?php echo $merchantmemberplan_add->field7->CustomMsg ?></div></div>
	</div>
<?php } ?>
<?php if ($merchantmemberplan_add->field8->Visible) { // field8 ?>
	<div id="r_field8" class="form-group row">
		<label id="elh_merchantmemberplan_field8" for="x_field8" class="<?php echo $merchantmemberplan_add->LeftColumnClass ?>"><?php echo $merchantmemberplan_add->field8->caption() ?><?php echo $merchantmemberplan_add->field8->Required ? $Language->phrase("FieldRequiredIndicator") : "" ?></label>
		<div class="<?php echo $merchantmemberplan_add->RightColumnClass ?>"><div <?php echo $merchantmemberplan_add->field8->cellAttributes() ?>>
<span id="el_merchantmemberplan_field8">
<input type="text" data-table="merchantmemberplan" data-field="x_field8" name="x_field8" id="x_field8" size="30" maxlength="100" placeholder="<?php echo HtmlEncode($merchantmemberplan_add->field8->getPlaceHolder()) ?>" value="<?php echo $merchantmemberplan_add->field8->EditValue ?>"<?php echo $merchantmemberplan_add->field8->editAttributes() ?>>
</span>
<?php echo $merchantmemberplan_add->field8->CustomMsg ?></div></div>
	</div>
<?php } ?>
<?php if ($merchantmemberplan_add->field9->Visible) { // field9 ?>
	<div id="r_field9" class="form-group row">
		<label id="elh_merchantmemberplan_field9" for="x_field9" class="<?php echo $merchantmemberplan_add->LeftColumnClass ?>"><?php echo $merchantmemberplan_add->field9->caption() ?><?php echo $merchantmemberplan_add->field9->Required ? $Language->phrase("FieldRequiredIndicator") : "" ?></label>
		<div class="<?php echo $merchantmemberplan_add->RightColumnClass ?>"><div <?php echo $merchantmemberplan_add->field9->cellAttributes() ?>>
<span id="el_merchantmemberplan_field9">
<input type="text" data-table="merchantmemberplan" data-field="x_field9" name="x_field9" id="x_field9" size="30" maxlength="100" placeholder="<?php echo HtmlEncode($merchantmemberplan_add->field9->getPlaceHolder()) ?>" value="<?php echo $merchantmemberplan_add->field9->EditValue ?>"<?php echo $merchantmemberplan_add->field9->editAttributes() ?>>
</span>
<?php echo $merchantmemberplan_add->field9->CustomMsg ?></div></div>
	</div>
<?php } ?>
<?php if ($merchantmemberplan_add->field10->Visible) { // field10 ?>
	<div id="r_field10" class="form-group row">
		<label id="elh_merchantmemberplan_field10" for="x_field10" class="<?php echo $merchantmemberplan_add->LeftColumnClass ?>"><?php echo $merchantmemberplan_add->field10->caption() ?><?php echo $merchantmemberplan_add->field10->Required ? $Language->phrase("FieldRequiredIndicator") : "" ?></label>
		<div class="<?php echo $merchantmemberplan_add->RightColumnClass ?>"><div <?php echo $merchantmemberplan_add->field10->cellAttributes() ?>>
<span id="el_merchantmemberplan_field10">
<input type="text" data-table="merchantmemberplan" data-field="x_field10" name="x_field10" id="x_field10" size="30" maxlength="100" placeholder="<?php echo HtmlEncode($merchantmemberplan_add->field10->getPlaceHolder()) ?>" value="<?php echo $merchantmemberplan_add->field10->EditValue ?>"<?php echo $merchantmemberplan_add->field10->editAttributes() ?>>
</span>
<?php echo $merchantmemberplan_add->field10->CustomMsg ?></div></div>
	</div>
<?php } ?>
</div><!-- /page* -->
<?php if (!$merchantmemberplan_add->IsModal) { ?>
<div class="form-group row"><!-- buttons .form-group -->
	<div class="<?php echo $merchantmemberplan_add->OffsetColumnClass ?>"><!-- buttons offset -->
<button class="btn btn-primary ew-btn" name="btn-action" id="btn-action" type="submit"><?php echo $Language->phrase("AddBtn") ?></button>
<button class="btn btn-default ew-btn" name="btn-cancel" id="btn-cancel" type="button" data-href="<?php echo $merchantmemberplan_add->getReturnUrl() ?>"><?php echo $Language->phrase("CancelBtn") ?></button>
	</div><!-- /buttons offset -->
</div><!-- /buttons .form-group -->
<?php } ?>
</form>
<?php
$merchantmemberplan_add->showPageFooter();
if (Config("DEBUG"))
	echo GetDebugMessage();
?>
<script>
loadjs.ready("load", function() {

	// Startup script
	// Write your table-specific startup script here
	// console.log("page loaded");

});
</script>
<?php include_once "footer.php"; ?>
<?php
$merchantmemberplan_add->terminate();
?>