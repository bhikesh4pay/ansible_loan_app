<?php
namespace PHPMaker2020\_4payadmin;

// Autoload
include_once "autoload.php";

// Session
if (session_status() !== PHP_SESSION_ACTIVE)
	\Delight\Cookie\Session::start(Config("COOKIE_SAMESITE")); // Init session data

// Output buffering
ob_start();
?>
<?php

// Write header
WriteHeader(FALSE);

// Create page object
$loanlimits_copy1_list = new loanlimits_copy1_list();

// Run the page
$loanlimits_copy1_list->run();

// Setup login status
SetupLoginStatus();
SetClientVar("login", LoginStatus());

// Global Page Rendering event (in userfn*.php)
Page_Rendering();

// Page Rendering event
$loanlimits_copy1_list->Page_Render();
?>
<?php include_once "header.php"; ?>
<?php if (!$loanlimits_copy1_list->isExport()) { ?>
<script>
var floanlimits_copy1list, currentPageID;
loadjs.ready("head", function() {

	// Form object
	currentPageID = ew.PAGE_ID = "list";
	floanlimits_copy1list = currentForm = new ew.Form("floanlimits_copy1list", "list");
	floanlimits_copy1list.formKeyCountName = '<?php echo $loanlimits_copy1_list->FormKeyCountName ?>';
	loadjs.done("floanlimits_copy1list");
});
var floanlimits_copy1listsrch;
loadjs.ready("head", function() {

	// Form object for search
	floanlimits_copy1listsrch = currentSearchForm = new ew.Form("floanlimits_copy1listsrch");

	// Dynamic selection lists
	// Filters

	floanlimits_copy1listsrch.filterList = <?php echo $loanlimits_copy1_list->getFilterList() ?>;

	// Init search panel as collapsed
	floanlimits_copy1listsrch.initSearchPanel = true;
	loadjs.done("floanlimits_copy1listsrch");
});
</script>
<style type="text/css">
.ew-table-preview-row { /* main table preview row color */
	background-color: #FFFFFF; /* preview row color */
}
.ew-table-preview-row .ew-grid {
	display: table;
}
</style>
<div id="ew-preview" class="d-none"><!-- preview -->
	<div class="ew-nav-tabs"><!-- .ew-nav-tabs -->
		<ul class="nav nav-tabs"></ul>
		<div class="tab-content"><!-- .tab-content -->
			<div class="tab-pane fade active show"></div>
		</div><!-- /.tab-content -->
	</div><!-- /.ew-nav-tabs -->
</div><!-- /preview -->
<script>
loadjs.ready("head", function() {
	ew.PREVIEW_PLACEMENT = ew.CSS_FLIP ? "right" : "left";
	ew.PREVIEW_SINGLE_ROW = false;
	ew.PREVIEW_OVERLAY = false;
	loadjs("js/ewpreview.js", "preview");
});
</script>
<script>
loadjs.ready("head", function() {

	// Client script
	// Write your client script here, no need to add script tags.

});
</script>
<?php } ?>
<?php if (!$loanlimits_copy1_list->isExport()) { ?>
<div class="btn-toolbar ew-toolbar">
<?php if ($loanlimits_copy1_list->TotalRecords > 0 && $loanlimits_copy1_list->ExportOptions->visible()) { ?>
<?php $loanlimits_copy1_list->ExportOptions->render("body") ?>
<?php } ?>
<?php if ($loanlimits_copy1_list->ImportOptions->visible()) { ?>
<?php $loanlimits_copy1_list->ImportOptions->render("body") ?>
<?php } ?>
<?php if ($loanlimits_copy1_list->SearchOptions->visible()) { ?>
<?php $loanlimits_copy1_list->SearchOptions->render("body") ?>
<?php } ?>
<?php if ($loanlimits_copy1_list->FilterOptions->visible()) { ?>
<?php $loanlimits_copy1_list->FilterOptions->render("body") ?>
<?php } ?>
<div class="clearfix"></div>
</div>
<?php } ?>
<?php
$loanlimits_copy1_list->renderOtherOptions();
?>
<?php if ($Security->CanSearch()) { ?>
<?php if (!$loanlimits_copy1_list->isExport() && !$loanlimits_copy1->CurrentAction) { ?>
<form name="floanlimits_copy1listsrch" id="floanlimits_copy1listsrch" class="form-inline ew-form ew-ext-search-form" action="<?php echo CurrentPageName() ?>">
<div id="floanlimits_copy1listsrch-search-panel" class="<?php echo $loanlimits_copy1_list->SearchPanelClass ?>">
<input type="hidden" name="cmd" value="search">
<input type="hidden" name="t" value="loanlimits_copy1">
	<div class="ew-extended-search">
<div id="xsr_<?php echo $loanlimits_copy1_list->SearchRowCount + 1 ?>" class="ew-row d-sm-flex">
	<div class="ew-quick-search input-group">
		<input type="text" name="<?php echo Config("TABLE_BASIC_SEARCH") ?>" id="<?php echo Config("TABLE_BASIC_SEARCH") ?>" class="form-control" value="<?php echo HtmlEncode($loanlimits_copy1_list->BasicSearch->getKeyword()) ?>" placeholder="<?php echo HtmlEncode($Language->phrase("Search")) ?>">
		<input type="hidden" name="<?php echo Config("TABLE_BASIC_SEARCH_TYPE") ?>" id="<?php echo Config("TABLE_BASIC_SEARCH_TYPE") ?>" value="<?php echo HtmlEncode($loanlimits_copy1_list->BasicSearch->getType()) ?>">
		<div class="input-group-append">
			<button class="btn btn-primary" name="btn-submit" id="btn-submit" type="submit"><?php echo $Language->phrase("SearchBtn") ?></button>
			<button type="button" data-toggle="dropdown" class="btn btn-primary dropdown-toggle dropdown-toggle-split" aria-haspopup="true" aria-expanded="false"><span id="searchtype"><?php echo $loanlimits_copy1_list->BasicSearch->getTypeNameShort() ?></span></button>
			<div class="dropdown-menu dropdown-menu-right">
				<a class="dropdown-item<?php if ($loanlimits_copy1_list->BasicSearch->getType() == "") { ?> active<?php } ?>" href="#" onclick="return ew.setSearchType(this);"><?php echo $Language->phrase("QuickSearchAuto") ?></a>
				<a class="dropdown-item<?php if ($loanlimits_copy1_list->BasicSearch->getType() == "=") { ?> active<?php } ?>" href="#" onclick="return ew.setSearchType(this, '=');"><?php echo $Language->phrase("QuickSearchExact") ?></a>
				<a class="dropdown-item<?php if ($loanlimits_copy1_list->BasicSearch->getType() == "AND") { ?> active<?php } ?>" href="#" onclick="return ew.setSearchType(this, 'AND');"><?php echo $Language->phrase("QuickSearchAll") ?></a>
				<a class="dropdown-item<?php if ($loanlimits_copy1_list->BasicSearch->getType() == "OR") { ?> active<?php } ?>" href="#" onclick="return ew.setSearchType(this, 'OR');"><?php echo $Language->phrase("QuickSearchAny") ?></a>
			</div>
		</div>
	</div>
</div>
	</div><!-- /.ew-extended-search -->
</div><!-- /.ew-search-panel -->
</form>
<?php } ?>
<?php } ?>
<?php $loanlimits_copy1_list->showPageHeader(); ?>
<?php
$loanlimits_copy1_list->showMessage();
?>
<?php if ($loanlimits_copy1_list->TotalRecords > 0 || $loanlimits_copy1->CurrentAction) { ?>
<div class="card ew-card ew-grid<?php if ($loanlimits_copy1_list->isAddOrEdit()) { ?> ew-grid-add-edit<?php } ?> loanlimits_copy1">
<form name="floanlimits_copy1list" id="floanlimits_copy1list" class="form-inline ew-form ew-list-form" action="<?php echo CurrentPageName() ?>" method="post">
<?php if ($Page->CheckToken) { ?>
<input type="hidden" name="<?php echo Config("TOKEN_NAME") ?>" value="<?php echo $Page->Token ?>">
<?php } ?>
<input type="hidden" name="t" value="loanlimits_copy1">
<div id="gmp_loanlimits_copy1" class="<?php echo ResponsiveTableClass() ?>card-body ew-grid-middle-panel">
<?php if ($loanlimits_copy1_list->TotalRecords > 0 || $loanlimits_copy1_list->isGridEdit()) { ?>
<table id="tbl_loanlimits_copy1list" class="table ew-table"><!-- .ew-table -->
<thead>
	<tr class="ew-table-header">
<?php

// Header row
$loanlimits_copy1->RowType = ROWTYPE_HEADER;

// Render list options
$loanlimits_copy1_list->renderListOptions();

// Render list options (header, left)
$loanlimits_copy1_list->ListOptions->render("header", "left");
?>
<?php if ($loanlimits_copy1_list->historyid->Visible) { // historyid ?>
	<?php if ($loanlimits_copy1_list->SortUrl($loanlimits_copy1_list->historyid) == "") { ?>
		<th data-name="historyid" class="<?php echo $loanlimits_copy1_list->historyid->headerCellClass() ?>"><div id="elh_loanlimits_copy1_historyid" class="loanlimits_copy1_historyid"><div class="ew-table-header-caption"><?php echo $loanlimits_copy1_list->historyid->caption() ?></div></div></th>
	<?php } else { ?>
		<th data-name="historyid" class="<?php echo $loanlimits_copy1_list->historyid->headerCellClass() ?>"><div class="ew-pointer" onclick="ew.sort(event, '<?php echo $loanlimits_copy1_list->SortUrl($loanlimits_copy1_list->historyid) ?>', 1);"><div id="elh_loanlimits_copy1_historyid" class="loanlimits_copy1_historyid">
			<div class="ew-table-header-btn"><span class="ew-table-header-caption"><?php echo $loanlimits_copy1_list->historyid->caption() ?></span><span class="ew-table-header-sort"><?php if ($loanlimits_copy1_list->historyid->getSort() == "ASC") { ?><i class="fas fa-sort-up"></i><?php } elseif ($loanlimits_copy1_list->historyid->getSort() == "DESC") { ?><i class="fas fa-sort-down"></i><?php } ?></span></div>
		</div></div></th>
	<?php } ?>
<?php } ?>
<?php if ($loanlimits_copy1_list->_userid->Visible) { // userid ?>
	<?php if ($loanlimits_copy1_list->SortUrl($loanlimits_copy1_list->_userid) == "") { ?>
		<th data-name="_userid" class="<?php echo $loanlimits_copy1_list->_userid->headerCellClass() ?>"><div id="elh_loanlimits_copy1__userid" class="loanlimits_copy1__userid"><div class="ew-table-header-caption"><?php echo $loanlimits_copy1_list->_userid->caption() ?></div></div></th>
	<?php } else { ?>
		<th data-name="_userid" class="<?php echo $loanlimits_copy1_list->_userid->headerCellClass() ?>"><div class="ew-pointer" onclick="ew.sort(event, '<?php echo $loanlimits_copy1_list->SortUrl($loanlimits_copy1_list->_userid) ?>', 1);"><div id="elh_loanlimits_copy1__userid" class="loanlimits_copy1__userid">
			<div class="ew-table-header-btn"><span class="ew-table-header-caption"><?php echo $loanlimits_copy1_list->_userid->caption() ?></span><span class="ew-table-header-sort"><?php if ($loanlimits_copy1_list->_userid->getSort() == "ASC") { ?><i class="fas fa-sort-up"></i><?php } elseif ($loanlimits_copy1_list->_userid->getSort() == "DESC") { ?><i class="fas fa-sort-down"></i><?php } ?></span></div>
		</div></div></th>
	<?php } ?>
<?php } ?>
<?php if ($loanlimits_copy1_list->currcode->Visible) { // currcode ?>
	<?php if ($loanlimits_copy1_list->SortUrl($loanlimits_copy1_list->currcode) == "") { ?>
		<th data-name="currcode" class="<?php echo $loanlimits_copy1_list->currcode->headerCellClass() ?>"><div id="elh_loanlimits_copy1_currcode" class="loanlimits_copy1_currcode"><div class="ew-table-header-caption"><?php echo $loanlimits_copy1_list->currcode->caption() ?></div></div></th>
	<?php } else { ?>
		<th data-name="currcode" class="<?php echo $loanlimits_copy1_list->currcode->headerCellClass() ?>"><div class="ew-pointer" onclick="ew.sort(event, '<?php echo $loanlimits_copy1_list->SortUrl($loanlimits_copy1_list->currcode) ?>', 1);"><div id="elh_loanlimits_copy1_currcode" class="loanlimits_copy1_currcode">
			<div class="ew-table-header-btn"><span class="ew-table-header-caption"><?php echo $loanlimits_copy1_list->currcode->caption() ?><?php echo $Language->phrase("SrchLegend") ?></span><span class="ew-table-header-sort"><?php if ($loanlimits_copy1_list->currcode->getSort() == "ASC") { ?><i class="fas fa-sort-up"></i><?php } elseif ($loanlimits_copy1_list->currcode->getSort() == "DESC") { ?><i class="fas fa-sort-down"></i><?php } ?></span></div>
		</div></div></th>
	<?php } ?>
<?php } ?>
<?php if ($loanlimits_copy1_list->eligiblelimit->Visible) { // eligiblelimit ?>
	<?php if ($loanlimits_copy1_list->SortUrl($loanlimits_copy1_list->eligiblelimit) == "") { ?>
		<th data-name="eligiblelimit" class="<?php echo $loanlimits_copy1_list->eligiblelimit->headerCellClass() ?>"><div id="elh_loanlimits_copy1_eligiblelimit" class="loanlimits_copy1_eligiblelimit"><div class="ew-table-header-caption"><?php echo $loanlimits_copy1_list->eligiblelimit->caption() ?></div></div></th>
	<?php } else { ?>
		<th data-name="eligiblelimit" class="<?php echo $loanlimits_copy1_list->eligiblelimit->headerCellClass() ?>"><div class="ew-pointer" onclick="ew.sort(event, '<?php echo $loanlimits_copy1_list->SortUrl($loanlimits_copy1_list->eligiblelimit) ?>', 1);"><div id="elh_loanlimits_copy1_eligiblelimit" class="loanlimits_copy1_eligiblelimit">
			<div class="ew-table-header-btn"><span class="ew-table-header-caption"><?php echo $loanlimits_copy1_list->eligiblelimit->caption() ?></span><span class="ew-table-header-sort"><?php if ($loanlimits_copy1_list->eligiblelimit->getSort() == "ASC") { ?><i class="fas fa-sort-up"></i><?php } elseif ($loanlimits_copy1_list->eligiblelimit->getSort() == "DESC") { ?><i class="fas fa-sort-down"></i><?php } ?></span></div>
		</div></div></th>
	<?php } ?>
<?php } ?>
<?php if ($loanlimits_copy1_list->lastupdatetime->Visible) { // lastupdatetime ?>
	<?php if ($loanlimits_copy1_list->SortUrl($loanlimits_copy1_list->lastupdatetime) == "") { ?>
		<th data-name="lastupdatetime" class="<?php echo $loanlimits_copy1_list->lastupdatetime->headerCellClass() ?>"><div id="elh_loanlimits_copy1_lastupdatetime" class="loanlimits_copy1_lastupdatetime"><div class="ew-table-header-caption"><?php echo $loanlimits_copy1_list->lastupdatetime->caption() ?></div></div></th>
	<?php } else { ?>
		<th data-name="lastupdatetime" class="<?php echo $loanlimits_copy1_list->lastupdatetime->headerCellClass() ?>"><div class="ew-pointer" onclick="ew.sort(event, '<?php echo $loanlimits_copy1_list->SortUrl($loanlimits_copy1_list->lastupdatetime) ?>', 1);"><div id="elh_loanlimits_copy1_lastupdatetime" class="loanlimits_copy1_lastupdatetime">
			<div class="ew-table-header-btn"><span class="ew-table-header-caption"><?php echo $loanlimits_copy1_list->lastupdatetime->caption() ?></span><span class="ew-table-header-sort"><?php if ($loanlimits_copy1_list->lastupdatetime->getSort() == "ASC") { ?><i class="fas fa-sort-up"></i><?php } elseif ($loanlimits_copy1_list->lastupdatetime->getSort() == "DESC") { ?><i class="fas fa-sort-down"></i><?php } ?></span></div>
		</div></div></th>
	<?php } ?>
<?php } ?>
<?php

// Render list options (header, right)
$loanlimits_copy1_list->ListOptions->render("header", "right");
?>
	</tr>
</thead>
<tbody>
<?php
if ($loanlimits_copy1_list->ExportAll && $loanlimits_copy1_list->isExport()) {
	$loanlimits_copy1_list->StopRecord = $loanlimits_copy1_list->TotalRecords;
} else {

	// Set the last record to display
	if ($loanlimits_copy1_list->TotalRecords > $loanlimits_copy1_list->StartRecord + $loanlimits_copy1_list->DisplayRecords - 1)
		$loanlimits_copy1_list->StopRecord = $loanlimits_copy1_list->StartRecord + $loanlimits_copy1_list->DisplayRecords - 1;
	else
		$loanlimits_copy1_list->StopRecord = $loanlimits_copy1_list->TotalRecords;
}
$loanlimits_copy1_list->RecordCount = $loanlimits_copy1_list->StartRecord - 1;
if ($loanlimits_copy1_list->Recordset && !$loanlimits_copy1_list->Recordset->EOF) {
	$loanlimits_copy1_list->Recordset->moveFirst();
	$selectLimit = $loanlimits_copy1_list->UseSelectLimit;
	if (!$selectLimit && $loanlimits_copy1_list->StartRecord > 1)
		$loanlimits_copy1_list->Recordset->move($loanlimits_copy1_list->StartRecord - 1);
} elseif (!$loanlimits_copy1->AllowAddDeleteRow && $loanlimits_copy1_list->StopRecord == 0) {
	$loanlimits_copy1_list->StopRecord = $loanlimits_copy1->GridAddRowCount;
}

// Initialize aggregate
$loanlimits_copy1->RowType = ROWTYPE_AGGREGATEINIT;
$loanlimits_copy1->resetAttributes();
$loanlimits_copy1_list->renderRow();
while ($loanlimits_copy1_list->RecordCount < $loanlimits_copy1_list->StopRecord) {
	$loanlimits_copy1_list->RecordCount++;
	if ($loanlimits_copy1_list->RecordCount >= $loanlimits_copy1_list->StartRecord) {
		$loanlimits_copy1_list->RowCount++;

		// Set up key count
		$loanlimits_copy1_list->KeyCount = $loanlimits_copy1_list->RowIndex;

		// Init row class and style
		$loanlimits_copy1->resetAttributes();
		$loanlimits_copy1->CssClass = "";
		if ($loanlimits_copy1_list->isGridAdd()) {
		} else {
			$loanlimits_copy1_list->loadRowValues($loanlimits_copy1_list->Recordset); // Load row values
		}
		$loanlimits_copy1->RowType = ROWTYPE_VIEW; // Render view

		// Set up row id / data-rowindex
		$loanlimits_copy1->RowAttrs->merge(["data-rowindex" => $loanlimits_copy1_list->RowCount, "id" => "r" . $loanlimits_copy1_list->RowCount . "_loanlimits_copy1", "data-rowtype" => $loanlimits_copy1->RowType]);

		// Render row
		$loanlimits_copy1_list->renderRow();

		// Render list options
		$loanlimits_copy1_list->renderListOptions();
?>
	<tr <?php echo $loanlimits_copy1->rowAttributes() ?>>
<?php

// Render list options (body, left)
$loanlimits_copy1_list->ListOptions->render("body", "left", $loanlimits_copy1_list->RowCount);
?>
	<?php if ($loanlimits_copy1_list->historyid->Visible) { // historyid ?>
		<td data-name="historyid" <?php echo $loanlimits_copy1_list->historyid->cellAttributes() ?>>
<span id="el<?php echo $loanlimits_copy1_list->RowCount ?>_loanlimits_copy1_historyid">
<span<?php echo $loanlimits_copy1_list->historyid->viewAttributes() ?>><?php echo $loanlimits_copy1_list->historyid->getViewValue() ?></span>
</span>
</td>
	<?php } ?>
	<?php if ($loanlimits_copy1_list->_userid->Visible) { // userid ?>
		<td data-name="_userid" <?php echo $loanlimits_copy1_list->_userid->cellAttributes() ?>>
<span id="el<?php echo $loanlimits_copy1_list->RowCount ?>_loanlimits_copy1__userid">
<span<?php echo $loanlimits_copy1_list->_userid->viewAttributes() ?>><?php echo $loanlimits_copy1_list->_userid->getViewValue() ?></span>
</span>
</td>
	<?php } ?>
	<?php if ($loanlimits_copy1_list->currcode->Visible) { // currcode ?>
		<td data-name="currcode" <?php echo $loanlimits_copy1_list->currcode->cellAttributes() ?>>
<span id="el<?php echo $loanlimits_copy1_list->RowCount ?>_loanlimits_copy1_currcode">
<span<?php echo $loanlimits_copy1_list->currcode->viewAttributes() ?>><?php echo $loanlimits_copy1_list->currcode->getViewValue() ?></span>
</span>
</td>
	<?php } ?>
	<?php if ($loanlimits_copy1_list->eligiblelimit->Visible) { // eligiblelimit ?>
		<td data-name="eligiblelimit" <?php echo $loanlimits_copy1_list->eligiblelimit->cellAttributes() ?>>
<span id="el<?php echo $loanlimits_copy1_list->RowCount ?>_loanlimits_copy1_eligiblelimit">
<span<?php echo $loanlimits_copy1_list->eligiblelimit->viewAttributes() ?>><?php echo $loanlimits_copy1_list->eligiblelimit->getViewValue() ?></span>
</span>
</td>
	<?php } ?>
	<?php if ($loanlimits_copy1_list->lastupdatetime->Visible) { // lastupdatetime ?>
		<td data-name="lastupdatetime" <?php echo $loanlimits_copy1_list->lastupdatetime->cellAttributes() ?>>
<span id="el<?php echo $loanlimits_copy1_list->RowCount ?>_loanlimits_copy1_lastupdatetime">
<span<?php echo $loanlimits_copy1_list->lastupdatetime->viewAttributes() ?>><?php echo $loanlimits_copy1_list->lastupdatetime->getViewValue() ?></span>
</span>
</td>
	<?php } ?>
<?php

// Render list options (body, right)
$loanlimits_copy1_list->ListOptions->render("body", "right", $loanlimits_copy1_list->RowCount);
?>
	</tr>
<?php
	}
	if (!$loanlimits_copy1_list->isGridAdd())
		$loanlimits_copy1_list->Recordset->moveNext();
}
?>
</tbody>
</table><!-- /.ew-table -->
<?php } ?>
</div><!-- /.ew-grid-middle-panel -->
<?php if (!$loanlimits_copy1->CurrentAction) { ?>
<input type="hidden" name="action" id="action" value="">
<?php } ?>
</form><!-- /.ew-list-form -->
<?php

// Close recordset
if ($loanlimits_copy1_list->Recordset)
	$loanlimits_copy1_list->Recordset->Close();
?>
<?php if (!$loanlimits_copy1_list->isExport()) { ?>
<div class="card-footer ew-grid-lower-panel">
<?php if (!$loanlimits_copy1_list->isGridAdd()) { ?>
<form name="ew-pager-form" class="form-inline ew-form ew-pager-form" action="<?php echo CurrentPageName() ?>">
<?php echo $loanlimits_copy1_list->Pager->render() ?>
</form>
<?php } ?>
<div class="ew-list-other-options">
<?php $loanlimits_copy1_list->OtherOptions->render("body", "bottom") ?>
</div>
<div class="clearfix"></div>
</div>
<?php } ?>
</div><!-- /.ew-grid -->
<?php } ?>
<?php if ($loanlimits_copy1_list->TotalRecords == 0 && !$loanlimits_copy1->CurrentAction) { // Show other options ?>
<div class="ew-list-other-options">
<?php $loanlimits_copy1_list->OtherOptions->render("body") ?>
</div>
<div class="clearfix"></div>
<?php } ?>
<?php
$loanlimits_copy1_list->showPageFooter();
if (Config("DEBUG"))
	echo GetDebugMessage();
?>
<?php if (!$loanlimits_copy1_list->isExport()) { ?>
<script>
loadjs.ready("load", function() {

	// Startup script
	// Write your table-specific startup script here
	// console.log("page loaded");

});
</script>
<?php } ?>
<?php include_once "footer.php"; ?>
<?php
$loanlimits_copy1_list->terminate();
?>