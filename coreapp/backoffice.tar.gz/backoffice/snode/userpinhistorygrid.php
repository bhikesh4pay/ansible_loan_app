<?php
namespace PHPMaker2020\_4payadmin;

// Write header
WriteHeader(FALSE);

// Create page object
if (!isset($userpinhistory_grid))
	$userpinhistory_grid = new userpinhistory_grid();

// Run the page
$userpinhistory_grid->run();

// Setup login status
SetupLoginStatus();
SetClientVar("login", LoginStatus());

// Global Page Rendering event (in userfn*.php)
Page_Rendering();

// Page Rendering event
$userpinhistory_grid->Page_Render();
?>
<?php if (!$userpinhistory_grid->isExport()) { ?>
<script>
var fuserpinhistorygrid, currentPageID;
loadjs.ready("head", function() {

	// Form object
	fuserpinhistorygrid = new ew.Form("fuserpinhistorygrid", "grid");
	fuserpinhistorygrid.formKeyCountName = '<?php echo $userpinhistory_grid->FormKeyCountName ?>';

	// Validate form
	fuserpinhistorygrid.validate = function() {
		if (!this.validateRequired)
			return true; // Ignore validation
		var $ = jQuery, fobj = this.getForm(), $fobj = $(fobj);
		if ($fobj.find("#confirm").val() == "confirm")
			return true;
		var elm, felm, uelm, addcnt = 0;
		var $k = $fobj.find("#" + this.formKeyCountName); // Get key_count
		var rowcnt = ($k[0]) ? parseInt($k.val(), 10) : 1;
		var startcnt = (rowcnt == 0) ? 0 : 1; // Check rowcnt == 0 => Inline-Add
		var gridinsert = ["insert", "gridinsert"].includes($fobj.find("#action").val()) && $k[0];
		for (var i = startcnt; i <= rowcnt; i++) {
			var infix = ($k[0]) ? String(i) : "";
			$fobj.data("rowindex", infix);
			var checkrow = (gridinsert) ? !this.emptyRow(infix) : true;
			if (checkrow) {
				addcnt++;
			<?php if ($userpinhistory_grid->_userID->Required) { ?>
				elm = this.getElements("x" + infix + "__userID");
				if (elm && !ew.isHidden(elm) && !ew.hasValue(elm))
					return this.onError(elm, "<?php echo JsEncode(str_replace("%s", $userpinhistory_grid->_userID->caption(), $userpinhistory_grid->_userID->RequiredErrorMessage)) ?>");
			<?php } ?>
				elm = this.getElements("x" + infix + "__userID");
				if (elm && !ew.checkInteger(elm.value))
					return this.onError(elm, "<?php echo JsEncode($userpinhistory_grid->_userID->errorMessage()) ?>");
			<?php if ($userpinhistory_grid->dateAdded->Required) { ?>
				elm = this.getElements("x" + infix + "_dateAdded");
				if (elm && !ew.isHidden(elm) && !ew.hasValue(elm))
					return this.onError(elm, "<?php echo JsEncode(str_replace("%s", $userpinhistory_grid->dateAdded->caption(), $userpinhistory_grid->dateAdded->RequiredErrorMessage)) ?>");
			<?php } ?>
				elm = this.getElements("x" + infix + "_dateAdded");
				if (elm && !ew.checkDateDef(elm.value))
					return this.onError(elm, "<?php echo JsEncode($userpinhistory_grid->dateAdded->errorMessage()) ?>");

				// Call Form_CustomValidate event
				if (!this.Form_CustomValidate(fobj))
					return false;
			} // End Grid Add checking
		}
		return true;
	}

	// Check empty row
	fuserpinhistorygrid.emptyRow = function(infix) {
		var fobj = this._form;
		if (ew.valueChanged(fobj, infix, "_userID", false)) return false;
		if (ew.valueChanged(fobj, infix, "dateAdded", false)) return false;
		return true;
	}

	// Form_CustomValidate
	fuserpinhistorygrid.Form_CustomValidate = function(fobj) { // DO NOT CHANGE THIS LINE!

		// Your custom validation code here, return false if invalid.
		return true;
	}

	// Use JavaScript validation or not
	fuserpinhistorygrid.validateRequired = <?php echo Config("CLIENT_VALIDATE") ? "true" : "false" ?>;

	// Dynamic selection lists
	loadjs.done("fuserpinhistorygrid");
});
</script>
<?php } ?>
<?php
$userpinhistory_grid->renderOtherOptions();
?>
<?php if ($userpinhistory_grid->TotalRecords > 0 || $userpinhistory->CurrentAction) { ?>
<div class="card ew-card ew-grid<?php if ($userpinhistory_grid->isAddOrEdit()) { ?> ew-grid-add-edit<?php } ?> userpinhistory">
<div id="fuserpinhistorygrid" class="ew-form ew-list-form form-inline">
<div id="gmp_userpinhistory" class="<?php echo ResponsiveTableClass() ?>card-body ew-grid-middle-panel">
<table id="tbl_userpinhistorygrid" class="table ew-table"><!-- .ew-table -->
<thead>
	<tr class="ew-table-header">
<?php

// Header row
$userpinhistory->RowType = ROWTYPE_HEADER;

// Render list options
$userpinhistory_grid->renderListOptions();

// Render list options (header, left)
$userpinhistory_grid->ListOptions->render("header", "left");
?>
<?php if ($userpinhistory_grid->_userID->Visible) { // userID ?>
	<?php if ($userpinhistory_grid->SortUrl($userpinhistory_grid->_userID) == "") { ?>
		<th data-name="_userID" class="<?php echo $userpinhistory_grid->_userID->headerCellClass() ?>"><div id="elh_userpinhistory__userID" class="userpinhistory__userID"><div class="ew-table-header-caption"><?php echo $userpinhistory_grid->_userID->caption() ?></div></div></th>
	<?php } else { ?>
		<th data-name="_userID" class="<?php echo $userpinhistory_grid->_userID->headerCellClass() ?>"><div><div id="elh_userpinhistory__userID" class="userpinhistory__userID">
			<div class="ew-table-header-btn"><span class="ew-table-header-caption"><?php echo $userpinhistory_grid->_userID->caption() ?></span><span class="ew-table-header-sort"><?php if ($userpinhistory_grid->_userID->getSort() == "ASC") { ?><i class="fas fa-sort-up"></i><?php } elseif ($userpinhistory_grid->_userID->getSort() == "DESC") { ?><i class="fas fa-sort-down"></i><?php } ?></span></div>
		</div></div></th>
	<?php } ?>
<?php } ?>
<?php if ($userpinhistory_grid->dateAdded->Visible) { // dateAdded ?>
	<?php if ($userpinhistory_grid->SortUrl($userpinhistory_grid->dateAdded) == "") { ?>
		<th data-name="dateAdded" class="<?php echo $userpinhistory_grid->dateAdded->headerCellClass() ?>"><div id="elh_userpinhistory_dateAdded" class="userpinhistory_dateAdded"><div class="ew-table-header-caption"><?php echo $userpinhistory_grid->dateAdded->caption() ?></div></div></th>
	<?php } else { ?>
		<th data-name="dateAdded" class="<?php echo $userpinhistory_grid->dateAdded->headerCellClass() ?>"><div><div id="elh_userpinhistory_dateAdded" class="userpinhistory_dateAdded">
			<div class="ew-table-header-btn"><span class="ew-table-header-caption"><?php echo $userpinhistory_grid->dateAdded->caption() ?></span><span class="ew-table-header-sort"><?php if ($userpinhistory_grid->dateAdded->getSort() == "ASC") { ?><i class="fas fa-sort-up"></i><?php } elseif ($userpinhistory_grid->dateAdded->getSort() == "DESC") { ?><i class="fas fa-sort-down"></i><?php } ?></span></div>
		</div></div></th>
	<?php } ?>
<?php } ?>
<?php

// Render list options (header, right)
$userpinhistory_grid->ListOptions->render("header", "right");
?>
	</tr>
</thead>
<tbody>
<?php
$userpinhistory_grid->StartRecord = 1;
$userpinhistory_grid->StopRecord = $userpinhistory_grid->TotalRecords; // Show all records

// Restore number of post back records
if ($CurrentForm && ($userpinhistory->isConfirm() || $userpinhistory_grid->EventCancelled)) {
	$CurrentForm->Index = -1;
	if ($CurrentForm->hasValue($userpinhistory_grid->FormKeyCountName) && ($userpinhistory_grid->isGridAdd() || $userpinhistory_grid->isGridEdit() || $userpinhistory->isConfirm())) {
		$userpinhistory_grid->KeyCount = $CurrentForm->getValue($userpinhistory_grid->FormKeyCountName);
		$userpinhistory_grid->StopRecord = $userpinhistory_grid->StartRecord + $userpinhistory_grid->KeyCount - 1;
	}
}
$userpinhistory_grid->RecordCount = $userpinhistory_grid->StartRecord - 1;
if ($userpinhistory_grid->Recordset && !$userpinhistory_grid->Recordset->EOF) {
	$userpinhistory_grid->Recordset->moveFirst();
	$selectLimit = $userpinhistory_grid->UseSelectLimit;
	if (!$selectLimit && $userpinhistory_grid->StartRecord > 1)
		$userpinhistory_grid->Recordset->move($userpinhistory_grid->StartRecord - 1);
} elseif (!$userpinhistory->AllowAddDeleteRow && $userpinhistory_grid->StopRecord == 0) {
	$userpinhistory_grid->StopRecord = $userpinhistory->GridAddRowCount;
}

// Initialize aggregate
$userpinhistory->RowType = ROWTYPE_AGGREGATEINIT;
$userpinhistory->resetAttributes();
$userpinhistory_grid->renderRow();
if ($userpinhistory_grid->isGridAdd())
	$userpinhistory_grid->RowIndex = 0;
if ($userpinhistory_grid->isGridEdit())
	$userpinhistory_grid->RowIndex = 0;
while ($userpinhistory_grid->RecordCount < $userpinhistory_grid->StopRecord) {
	$userpinhistory_grid->RecordCount++;
	if ($userpinhistory_grid->RecordCount >= $userpinhistory_grid->StartRecord) {
		$userpinhistory_grid->RowCount++;
		if ($userpinhistory_grid->isGridAdd() || $userpinhistory_grid->isGridEdit() || $userpinhistory->isConfirm()) {
			$userpinhistory_grid->RowIndex++;
			$CurrentForm->Index = $userpinhistory_grid->RowIndex;
			if ($CurrentForm->hasValue($userpinhistory_grid->FormActionName) && ($userpinhistory->isConfirm() || $userpinhistory_grid->EventCancelled))
				$userpinhistory_grid->RowAction = strval($CurrentForm->getValue($userpinhistory_grid->FormActionName));
			elseif ($userpinhistory_grid->isGridAdd())
				$userpinhistory_grid->RowAction = "insert";
			else
				$userpinhistory_grid->RowAction = "";
		}

		// Set up key count
		$userpinhistory_grid->KeyCount = $userpinhistory_grid->RowIndex;

		// Init row class and style
		$userpinhistory->resetAttributes();
		$userpinhistory->CssClass = "";
		if ($userpinhistory_grid->isGridAdd()) {
			if ($userpinhistory->CurrentMode == "copy") {
				$userpinhistory_grid->loadRowValues($userpinhistory_grid->Recordset); // Load row values
				$userpinhistory_grid->setRecordKey($userpinhistory_grid->RowOldKey, $userpinhistory_grid->Recordset); // Set old record key
			} else {
				$userpinhistory_grid->loadRowValues(); // Load default values
				$userpinhistory_grid->RowOldKey = ""; // Clear old key value
			}
		} else {
			$userpinhistory_grid->loadRowValues($userpinhistory_grid->Recordset); // Load row values
		}
		$userpinhistory->RowType = ROWTYPE_VIEW; // Render view
		if ($userpinhistory_grid->isGridAdd()) // Grid add
			$userpinhistory->RowType = ROWTYPE_ADD; // Render add
		if ($userpinhistory_grid->isGridAdd() && $userpinhistory->EventCancelled && !$CurrentForm->hasValue("k_blankrow")) // Insert failed
			$userpinhistory_grid->restoreCurrentRowFormValues($userpinhistory_grid->RowIndex); // Restore form values
		if ($userpinhistory_grid->isGridEdit()) { // Grid edit
			if ($userpinhistory->EventCancelled)
				$userpinhistory_grid->restoreCurrentRowFormValues($userpinhistory_grid->RowIndex); // Restore form values
			if ($userpinhistory_grid->RowAction == "insert")
				$userpinhistory->RowType = ROWTYPE_ADD; // Render add
			else
				$userpinhistory->RowType = ROWTYPE_EDIT; // Render edit
		}
		if ($userpinhistory_grid->isGridEdit() && ($userpinhistory->RowType == ROWTYPE_EDIT || $userpinhistory->RowType == ROWTYPE_ADD) && $userpinhistory->EventCancelled) // Update failed
			$userpinhistory_grid->restoreCurrentRowFormValues($userpinhistory_grid->RowIndex); // Restore form values
		if ($userpinhistory->RowType == ROWTYPE_EDIT) // Edit row
			$userpinhistory_grid->EditRowCount++;
		if ($userpinhistory->isConfirm()) // Confirm row
			$userpinhistory_grid->restoreCurrentRowFormValues($userpinhistory_grid->RowIndex); // Restore form values

		// Set up row id / data-rowindex
		$userpinhistory->RowAttrs->merge(["data-rowindex" => $userpinhistory_grid->RowCount, "id" => "r" . $userpinhistory_grid->RowCount . "_userpinhistory", "data-rowtype" => $userpinhistory->RowType]);

		// Render row
		$userpinhistory_grid->renderRow();

		// Render list options
		$userpinhistory_grid->renderListOptions();

		// Skip delete row / empty row for confirm page
		if ($userpinhistory_grid->RowAction != "delete" && $userpinhistory_grid->RowAction != "insertdelete" && !($userpinhistory_grid->RowAction == "insert" && $userpinhistory->isConfirm() && $userpinhistory_grid->emptyRow())) {
?>
	<tr <?php echo $userpinhistory->rowAttributes() ?>>
<?php

// Render list options (body, left)
$userpinhistory_grid->ListOptions->render("body", "left", $userpinhistory_grid->RowCount);
?>
	<?php if ($userpinhistory_grid->_userID->Visible) { // userID ?>
		<td data-name="_userID" <?php echo $userpinhistory_grid->_userID->cellAttributes() ?>>
<?php if ($userpinhistory->RowType == ROWTYPE_ADD) { // Add record ?>
<?php if ($userpinhistory_grid->_userID->getSessionValue() != "") { ?>
<span id="el<?php echo $userpinhistory_grid->RowCount ?>_userpinhistory__userID" class="form-group">
<span<?php echo $userpinhistory_grid->_userID->viewAttributes() ?>><input type="text" readonly class="form-control-plaintext" value="<?php echo HtmlEncode(RemoveHtml($userpinhistory_grid->_userID->ViewValue)) ?>"></span>
</span>
<input type="hidden" id="x<?php echo $userpinhistory_grid->RowIndex ?>__userID" name="x<?php echo $userpinhistory_grid->RowIndex ?>__userID" value="<?php echo HtmlEncode($userpinhistory_grid->_userID->CurrentValue) ?>">
<?php } else { ?>
<span id="el<?php echo $userpinhistory_grid->RowCount ?>_userpinhistory__userID" class="form-group">
<input type="text" data-table="userpinhistory" data-field="x__userID" name="x<?php echo $userpinhistory_grid->RowIndex ?>__userID" id="x<?php echo $userpinhistory_grid->RowIndex ?>__userID" size="30" placeholder="<?php echo HtmlEncode($userpinhistory_grid->_userID->getPlaceHolder()) ?>" value="<?php echo $userpinhistory_grid->_userID->EditValue ?>"<?php echo $userpinhistory_grid->_userID->editAttributes() ?>>
</span>
<?php } ?>
<input type="hidden" data-table="userpinhistory" data-field="x__userID" name="o<?php echo $userpinhistory_grid->RowIndex ?>__userID" id="o<?php echo $userpinhistory_grid->RowIndex ?>__userID" value="<?php echo HtmlEncode($userpinhistory_grid->_userID->OldValue) ?>">
<?php } ?>
<?php if ($userpinhistory->RowType == ROWTYPE_EDIT) { // Edit record ?>
<?php if ($userpinhistory_grid->_userID->getSessionValue() != "") { ?>

<span id="el<?php echo $userpinhistory_grid->RowCount ?>_userpinhistory__userID" class="form-group">
<span<?php echo $userpinhistory_grid->_userID->viewAttributes() ?>><input type="text" readonly class="form-control-plaintext" value="<?php echo HtmlEncode(RemoveHtml($userpinhistory_grid->_userID->EditValue)) ?>"></span>
</span>

<input type="hidden" id="x<?php echo $userpinhistory_grid->RowIndex ?>__userID" name="x<?php echo $userpinhistory_grid->RowIndex ?>__userID" value="<?php echo HtmlEncode($userpinhistory_grid->_userID->CurrentValue) ?>">
<?php } else { ?>

<input type="text" data-table="userpinhistory" data-field="x__userID" name="x<?php echo $userpinhistory_grid->RowIndex ?>__userID" id="x<?php echo $userpinhistory_grid->RowIndex ?>__userID" size="30" placeholder="<?php echo HtmlEncode($userpinhistory_grid->_userID->getPlaceHolder()) ?>" value="<?php echo $userpinhistory_grid->_userID->EditValue ?>"<?php echo $userpinhistory_grid->_userID->editAttributes() ?>>

<?php } ?>

<input type="hidden" data-table="userpinhistory" data-field="x__userID" name="o<?php echo $userpinhistory_grid->RowIndex ?>__userID" id="o<?php echo $userpinhistory_grid->RowIndex ?>__userID" value="<?php echo HtmlEncode($userpinhistory_grid->_userID->OldValue != null ? $userpinhistory_grid->_userID->OldValue : $userpinhistory_grid->_userID->CurrentValue) ?>">
<?php } ?>
<?php if ($userpinhistory->RowType == ROWTYPE_VIEW) { // View record ?>
<span id="el<?php echo $userpinhistory_grid->RowCount ?>_userpinhistory__userID">
<span<?php echo $userpinhistory_grid->_userID->viewAttributes() ?>><?php echo $userpinhistory_grid->_userID->getViewValue() ?></span>
</span>
<?php if (!$userpinhistory->isConfirm()) { ?>
<input type="hidden" data-table="userpinhistory" data-field="x__userID" name="x<?php echo $userpinhistory_grid->RowIndex ?>__userID" id="x<?php echo $userpinhistory_grid->RowIndex ?>__userID" value="<?php echo HtmlEncode($userpinhistory_grid->_userID->FormValue) ?>">
<input type="hidden" data-table="userpinhistory" data-field="x__userID" name="o<?php echo $userpinhistory_grid->RowIndex ?>__userID" id="o<?php echo $userpinhistory_grid->RowIndex ?>__userID" value="<?php echo HtmlEncode($userpinhistory_grid->_userID->OldValue) ?>">
<?php } else { ?>
<input type="hidden" data-table="userpinhistory" data-field="x__userID" name="fuserpinhistorygrid$x<?php echo $userpinhistory_grid->RowIndex ?>__userID" id="fuserpinhistorygrid$x<?php echo $userpinhistory_grid->RowIndex ?>__userID" value="<?php echo HtmlEncode($userpinhistory_grid->_userID->FormValue) ?>">
<input type="hidden" data-table="userpinhistory" data-field="x__userID" name="fuserpinhistorygrid$o<?php echo $userpinhistory_grid->RowIndex ?>__userID" id="fuserpinhistorygrid$o<?php echo $userpinhistory_grid->RowIndex ?>__userID" value="<?php echo HtmlEncode($userpinhistory_grid->_userID->OldValue) ?>">
<?php } ?>
<?php } ?>
</td>
	<?php } ?>
	<?php if ($userpinhistory_grid->dateAdded->Visible) { // dateAdded ?>
		<td data-name="dateAdded" <?php echo $userpinhistory_grid->dateAdded->cellAttributes() ?>>
<?php if ($userpinhistory->RowType == ROWTYPE_ADD) { // Add record ?>
<span id="el<?php echo $userpinhistory_grid->RowCount ?>_userpinhistory_dateAdded" class="form-group">
<input type="text" data-table="userpinhistory" data-field="x_dateAdded" data-format="1" name="x<?php echo $userpinhistory_grid->RowIndex ?>_dateAdded" id="x<?php echo $userpinhistory_grid->RowIndex ?>_dateAdded" placeholder="<?php echo HtmlEncode($userpinhistory_grid->dateAdded->getPlaceHolder()) ?>" value="<?php echo $userpinhistory_grid->dateAdded->EditValue ?>"<?php echo $userpinhistory_grid->dateAdded->editAttributes() ?>>
<?php if (!$userpinhistory_grid->dateAdded->ReadOnly && !$userpinhistory_grid->dateAdded->Disabled && !isset($userpinhistory_grid->dateAdded->EditAttrs["readonly"]) && !isset($userpinhistory_grid->dateAdded->EditAttrs["disabled"])) { ?>
<script>
loadjs.ready(["fuserpinhistorygrid", "datetimepicker"], function() {
	ew.createDateTimePicker("fuserpinhistorygrid", "x<?php echo $userpinhistory_grid->RowIndex ?>_dateAdded", {"ignoreReadonly":true,"useCurrent":false,"format":1});
});
</script>
<?php } ?>
</span>
<input type="hidden" data-table="userpinhistory" data-field="x_dateAdded" name="o<?php echo $userpinhistory_grid->RowIndex ?>_dateAdded" id="o<?php echo $userpinhistory_grid->RowIndex ?>_dateAdded" value="<?php echo HtmlEncode($userpinhistory_grid->dateAdded->OldValue) ?>">
<?php } ?>
<?php if ($userpinhistory->RowType == ROWTYPE_EDIT) { // Edit record ?>
<input type="text" data-table="userpinhistory" data-field="x_dateAdded" data-format="1" name="x<?php echo $userpinhistory_grid->RowIndex ?>_dateAdded" id="x<?php echo $userpinhistory_grid->RowIndex ?>_dateAdded" placeholder="<?php echo HtmlEncode($userpinhistory_grid->dateAdded->getPlaceHolder()) ?>" value="<?php echo $userpinhistory_grid->dateAdded->EditValue ?>"<?php echo $userpinhistory_grid->dateAdded->editAttributes() ?>>
<?php if (!$userpinhistory_grid->dateAdded->ReadOnly && !$userpinhistory_grid->dateAdded->Disabled && !isset($userpinhistory_grid->dateAdded->EditAttrs["readonly"]) && !isset($userpinhistory_grid->dateAdded->EditAttrs["disabled"])) { ?>
<script>
loadjs.ready(["fuserpinhistorygrid", "datetimepicker"], function() {
	ew.createDateTimePicker("fuserpinhistorygrid", "x<?php echo $userpinhistory_grid->RowIndex ?>_dateAdded", {"ignoreReadonly":true,"useCurrent":false,"format":1});
});
</script>
<?php } ?>
<input type="hidden" data-table="userpinhistory" data-field="x_dateAdded" name="o<?php echo $userpinhistory_grid->RowIndex ?>_dateAdded" id="o<?php echo $userpinhistory_grid->RowIndex ?>_dateAdded" value="<?php echo HtmlEncode($userpinhistory_grid->dateAdded->OldValue != null ? $userpinhistory_grid->dateAdded->OldValue : $userpinhistory_grid->dateAdded->CurrentValue) ?>">
<?php } ?>
<?php if ($userpinhistory->RowType == ROWTYPE_VIEW) { // View record ?>
<span id="el<?php echo $userpinhistory_grid->RowCount ?>_userpinhistory_dateAdded">
<span<?php echo $userpinhistory_grid->dateAdded->viewAttributes() ?>><?php echo $userpinhistory_grid->dateAdded->getViewValue() ?></span>
</span>
<?php if (!$userpinhistory->isConfirm()) { ?>
<input type="hidden" data-table="userpinhistory" data-field="x_dateAdded" name="x<?php echo $userpinhistory_grid->RowIndex ?>_dateAdded" id="x<?php echo $userpinhistory_grid->RowIndex ?>_dateAdded" value="<?php echo HtmlEncode($userpinhistory_grid->dateAdded->FormValue) ?>">
<input type="hidden" data-table="userpinhistory" data-field="x_dateAdded" name="o<?php echo $userpinhistory_grid->RowIndex ?>_dateAdded" id="o<?php echo $userpinhistory_grid->RowIndex ?>_dateAdded" value="<?php echo HtmlEncode($userpinhistory_grid->dateAdded->OldValue) ?>">
<?php } else { ?>
<input type="hidden" data-table="userpinhistory" data-field="x_dateAdded" name="fuserpinhistorygrid$x<?php echo $userpinhistory_grid->RowIndex ?>_dateAdded" id="fuserpinhistorygrid$x<?php echo $userpinhistory_grid->RowIndex ?>_dateAdded" value="<?php echo HtmlEncode($userpinhistory_grid->dateAdded->FormValue) ?>">
<input type="hidden" data-table="userpinhistory" data-field="x_dateAdded" name="fuserpinhistorygrid$o<?php echo $userpinhistory_grid->RowIndex ?>_dateAdded" id="fuserpinhistorygrid$o<?php echo $userpinhistory_grid->RowIndex ?>_dateAdded" value="<?php echo HtmlEncode($userpinhistory_grid->dateAdded->OldValue) ?>">
<?php } ?>
<?php } ?>
</td>
	<?php } ?>
<?php

// Render list options (body, right)
$userpinhistory_grid->ListOptions->render("body", "right", $userpinhistory_grid->RowCount);
?>
	</tr>
<?php if ($userpinhistory->RowType == ROWTYPE_ADD || $userpinhistory->RowType == ROWTYPE_EDIT) { ?>
<script>
loadjs.ready(["fuserpinhistorygrid", "load"], function() {
	fuserpinhistorygrid.updateLists(<?php echo $userpinhistory_grid->RowIndex ?>);
});
</script>
<?php } ?>
<?php
	}
	} // End delete row checking
	if (!$userpinhistory_grid->isGridAdd() || $userpinhistory->CurrentMode == "copy")
		if (!$userpinhistory_grid->Recordset->EOF)
			$userpinhistory_grid->Recordset->moveNext();
}
?>
<?php
	if ($userpinhistory->CurrentMode == "add" || $userpinhistory->CurrentMode == "copy" || $userpinhistory->CurrentMode == "edit") {
		$userpinhistory_grid->RowIndex = '$rowindex$';
		$userpinhistory_grid->loadRowValues();

		// Set row properties
		$userpinhistory->resetAttributes();
		$userpinhistory->RowAttrs->merge(["data-rowindex" => $userpinhistory_grid->RowIndex, "id" => "r0_userpinhistory", "data-rowtype" => ROWTYPE_ADD]);
		$userpinhistory->RowAttrs->appendClass("ew-template");
		$userpinhistory->RowType = ROWTYPE_ADD;

		// Render row
		$userpinhistory_grid->renderRow();

		// Render list options
		$userpinhistory_grid->renderListOptions();
		$userpinhistory_grid->StartRowCount = 0;
?>
	<tr <?php echo $userpinhistory->rowAttributes() ?>>
<?php

// Render list options (body, left)
$userpinhistory_grid->ListOptions->render("body", "left", $userpinhistory_grid->RowIndex);
?>
	<?php if ($userpinhistory_grid->_userID->Visible) { // userID ?>
		<td data-name="_userID">
<?php if (!$userpinhistory->isConfirm()) { ?>
<?php if ($userpinhistory_grid->_userID->getSessionValue() != "") { ?>
<span id="el$rowindex$_userpinhistory__userID" class="form-group userpinhistory__userID">
<span<?php echo $userpinhistory_grid->_userID->viewAttributes() ?>><input type="text" readonly class="form-control-plaintext" value="<?php echo HtmlEncode(RemoveHtml($userpinhistory_grid->_userID->ViewValue)) ?>"></span>
</span>
<input type="hidden" id="x<?php echo $userpinhistory_grid->RowIndex ?>__userID" name="x<?php echo $userpinhistory_grid->RowIndex ?>__userID" value="<?php echo HtmlEncode($userpinhistory_grid->_userID->CurrentValue) ?>">
<?php } else { ?>
<span id="el$rowindex$_userpinhistory__userID" class="form-group userpinhistory__userID">
<input type="text" data-table="userpinhistory" data-field="x__userID" name="x<?php echo $userpinhistory_grid->RowIndex ?>__userID" id="x<?php echo $userpinhistory_grid->RowIndex ?>__userID" size="30" placeholder="<?php echo HtmlEncode($userpinhistory_grid->_userID->getPlaceHolder()) ?>" value="<?php echo $userpinhistory_grid->_userID->EditValue ?>"<?php echo $userpinhistory_grid->_userID->editAttributes() ?>>
</span>
<?php } ?>
<?php } else { ?>
<span id="el$rowindex$_userpinhistory__userID" class="form-group userpinhistory__userID">
<span<?php echo $userpinhistory_grid->_userID->viewAttributes() ?>><input type="text" readonly class="form-control-plaintext" value="<?php echo HtmlEncode(RemoveHtml($userpinhistory_grid->_userID->ViewValue)) ?>"></span>
</span>
<input type="hidden" data-table="userpinhistory" data-field="x__userID" name="x<?php echo $userpinhistory_grid->RowIndex ?>__userID" id="x<?php echo $userpinhistory_grid->RowIndex ?>__userID" value="<?php echo HtmlEncode($userpinhistory_grid->_userID->FormValue) ?>">
<?php } ?>
<input type="hidden" data-table="userpinhistory" data-field="x__userID" name="o<?php echo $userpinhistory_grid->RowIndex ?>__userID" id="o<?php echo $userpinhistory_grid->RowIndex ?>__userID" value="<?php echo HtmlEncode($userpinhistory_grid->_userID->OldValue) ?>">
</td>
	<?php } ?>
	<?php if ($userpinhistory_grid->dateAdded->Visible) { // dateAdded ?>
		<td data-name="dateAdded">
<?php if (!$userpinhistory->isConfirm()) { ?>
<span id="el$rowindex$_userpinhistory_dateAdded" class="form-group userpinhistory_dateAdded">
<input type="text" data-table="userpinhistory" data-field="x_dateAdded" data-format="1" name="x<?php echo $userpinhistory_grid->RowIndex ?>_dateAdded" id="x<?php echo $userpinhistory_grid->RowIndex ?>_dateAdded" placeholder="<?php echo HtmlEncode($userpinhistory_grid->dateAdded->getPlaceHolder()) ?>" value="<?php echo $userpinhistory_grid->dateAdded->EditValue ?>"<?php echo $userpinhistory_grid->dateAdded->editAttributes() ?>>
<?php if (!$userpinhistory_grid->dateAdded->ReadOnly && !$userpinhistory_grid->dateAdded->Disabled && !isset($userpinhistory_grid->dateAdded->EditAttrs["readonly"]) && !isset($userpinhistory_grid->dateAdded->EditAttrs["disabled"])) { ?>
<script>
loadjs.ready(["fuserpinhistorygrid", "datetimepicker"], function() {
	ew.createDateTimePicker("fuserpinhistorygrid", "x<?php echo $userpinhistory_grid->RowIndex ?>_dateAdded", {"ignoreReadonly":true,"useCurrent":false,"format":1});
});
</script>
<?php } ?>
</span>
<?php } else { ?>
<span id="el$rowindex$_userpinhistory_dateAdded" class="form-group userpinhistory_dateAdded">
<span<?php echo $userpinhistory_grid->dateAdded->viewAttributes() ?>><input type="text" readonly class="form-control-plaintext" value="<?php echo HtmlEncode(RemoveHtml($userpinhistory_grid->dateAdded->ViewValue)) ?>"></span>
</span>
<input type="hidden" data-table="userpinhistory" data-field="x_dateAdded" name="x<?php echo $userpinhistory_grid->RowIndex ?>_dateAdded" id="x<?php echo $userpinhistory_grid->RowIndex ?>_dateAdded" value="<?php echo HtmlEncode($userpinhistory_grid->dateAdded->FormValue) ?>">
<?php } ?>
<input type="hidden" data-table="userpinhistory" data-field="x_dateAdded" name="o<?php echo $userpinhistory_grid->RowIndex ?>_dateAdded" id="o<?php echo $userpinhistory_grid->RowIndex ?>_dateAdded" value="<?php echo HtmlEncode($userpinhistory_grid->dateAdded->OldValue) ?>">
</td>
	<?php } ?>
<?php

// Render list options (body, right)
$userpinhistory_grid->ListOptions->render("body", "right", $userpinhistory_grid->RowIndex);
?>
<script>
loadjs.ready(["fuserpinhistorygrid", "load"], function() {
	fuserpinhistorygrid.updateLists(<?php echo $userpinhistory_grid->RowIndex ?>);
});
</script>
	</tr>
<?php
	}
?>
</tbody>
</table><!-- /.ew-table -->
</div><!-- /.ew-grid-middle-panel -->
<?php if ($userpinhistory->CurrentMode == "add" || $userpinhistory->CurrentMode == "copy") { ?>
<input type="hidden" name="<?php echo $userpinhistory_grid->FormKeyCountName ?>" id="<?php echo $userpinhistory_grid->FormKeyCountName ?>" value="<?php echo $userpinhistory_grid->KeyCount ?>">
<?php echo $userpinhistory_grid->MultiSelectKey ?>
<?php } ?>
<?php if ($userpinhistory->CurrentMode == "edit") { ?>
<input type="hidden" name="<?php echo $userpinhistory_grid->FormKeyCountName ?>" id="<?php echo $userpinhistory_grid->FormKeyCountName ?>" value="<?php echo $userpinhistory_grid->KeyCount ?>">
<?php echo $userpinhistory_grid->MultiSelectKey ?>
<?php } ?>
<?php if ($userpinhistory->CurrentMode == "") { ?>
<input type="hidden" name="action" id="action" value="">
<?php } ?>
<input type="hidden" name="detailpage" value="fuserpinhistorygrid">
</div><!-- /.ew-list-form -->
<?php

// Close recordset
if ($userpinhistory_grid->Recordset)
	$userpinhistory_grid->Recordset->Close();
?>
<?php if ($userpinhistory_grid->ShowOtherOptions) { ?>
<div class="card-footer ew-grid-lower-panel">
<?php $userpinhistory_grid->OtherOptions->render("body", "bottom") ?>
</div>
<div class="clearfix"></div>
<?php } ?>
</div><!-- /.ew-grid -->
<?php } ?>
<?php if ($userpinhistory_grid->TotalRecords == 0 && !$userpinhistory->CurrentAction) { // Show other options ?>
<div class="ew-list-other-options">
<?php $userpinhistory_grid->OtherOptions->render("body") ?>
</div>
<div class="clearfix"></div>
<?php } ?>
<?php if (!$userpinhistory_grid->isExport()) { ?>
<script>
loadjs.ready("load", function() {

	// Startup script
	// Write your table-specific startup script here
	// console.log("page loaded");

});
</script>
<?php } ?>
<?php
$userpinhistory_grid->terminate();
?>